                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module via
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _raw_hid_receive_kb
                                     12 	.globl _vialrgb_save
                                     13 	.globl _vialrgb_set_value
                                     14 	.globl _vialrgb_get_value
                                     15 	.globl _ak820_nvm_schema_fault
                                     16 	.globl _raw_hid_send
                                     17 	.globl _dynamic_keymap_macro_send
                                     18 	.globl _dynamic_keymap_macro_reset
                                     19 	.globl _dynamic_keymap_macro_set_buffer
                                     20 	.globl _dynamic_keymap_macro_get_buffer
                                     21 	.globl _dynamic_keymap_macro_get_buffer_size
                                     22 	.globl _dynamic_keymap_macro_get_count
                                     23 	.globl _dynamic_keymap_set_buffer
                                     24 	.globl _dynamic_keymap_get_buffer
                                     25 	.globl _dynamic_keymap_reset
                                     26 	.globl _dynamic_keymap_set_keycode
                                     27 	.globl _dynamic_keymap_get_keycode
                                     28 	.globl _dynamic_keymap_get_layer_count
                                     29 	.globl _vial_handle_cmd
                                     30 	.globl _eeprom_update_byte
                                     31 	.globl _eeprom_read_byte
                                     32 	.globl _bootloader_jump
                                     33 	.globl _timer_read32
                                     34 	.globl _matrix_get_row
                                     35 	.globl _mDelaymS
                                     36 	.globl _ADC_START
                                     37 	.globl _S0_R_FIFO
                                     38 	.globl _S0_T_FIFO
                                     39 	.globl _S0_FREE
                                     40 	.globl _S0_IF_BYTE
                                     41 	.globl _S0_IF_FIRST
                                     42 	.globl _S0_IF_OV
                                     43 	.globl _S0_FST_ACT
                                     44 	.globl _CP_RL2
                                     45 	.globl _C_T2
                                     46 	.globl _TR2
                                     47 	.globl _EXEN2
                                     48 	.globl _TCLK
                                     49 	.globl _RCLK
                                     50 	.globl _EXF2
                                     51 	.globl _CAP1F
                                     52 	.globl _TF2
                                     53 	.globl _RI
                                     54 	.globl _TI
                                     55 	.globl _RB8
                                     56 	.globl _TB8
                                     57 	.globl _REN
                                     58 	.globl _SM2
                                     59 	.globl _SM1
                                     60 	.globl _SM0
                                     61 	.globl _IT0
                                     62 	.globl _IE0
                                     63 	.globl _IT1
                                     64 	.globl _IE1
                                     65 	.globl _TR0
                                     66 	.globl _TF0
                                     67 	.globl _TR1
                                     68 	.globl _TF1
                                     69 	.globl _P4_0
                                     70 	.globl _P4_1
                                     71 	.globl _P4_2
                                     72 	.globl _P4_3
                                     73 	.globl _P4_4
                                     74 	.globl _P4_5
                                     75 	.globl _P4_6
                                     76 	.globl _RXD
                                     77 	.globl _TXD
                                     78 	.globl _INT0
                                     79 	.globl _INT1
                                     80 	.globl _T0
                                     81 	.globl _T1
                                     82 	.globl _MOSI1
                                     83 	.globl _MISO1
                                     84 	.globl _SCK1
                                     85 	.globl _P3_0
                                     86 	.globl _P3_1
                                     87 	.globl _P3_2
                                     88 	.globl _P3_3
                                     89 	.globl _P3_4
                                     90 	.globl _P3_5
                                     91 	.globl _P3_6
                                     92 	.globl _P3_7
                                     93 	.globl _CAP1_
                                     94 	.globl _T2_
                                     95 	.globl _CAP2_
                                     96 	.globl _T2EX_
                                     97 	.globl _RXD1
                                     98 	.globl _TXD1
                                     99 	.globl _P2_0
                                    100 	.globl _P2_1
                                    101 	.globl _P2_2
                                    102 	.globl _P2_3
                                    103 	.globl _P2_4
                                    104 	.globl _P2_5
                                    105 	.globl _P2_6
                                    106 	.globl _P2_7
                                    107 	.globl _AIN0
                                    108 	.globl _AIN1
                                    109 	.globl _AIN2
                                    110 	.globl _AIN3
                                    111 	.globl _AIN4
                                    112 	.globl _AIN5
                                    113 	.globl _AIN6
                                    114 	.globl _AIN7
                                    115 	.globl _CAP1
                                    116 	.globl _T2
                                    117 	.globl _CAP2
                                    118 	.globl _T2EX
                                    119 	.globl _INT0_
                                    120 	.globl _SCS
                                    121 	.globl _MOSI
                                    122 	.globl _MISO
                                    123 	.globl _SCK
                                    124 	.globl _RXD1_
                                    125 	.globl _TXD1_
                                    126 	.globl _P1_0
                                    127 	.globl _P1_1
                                    128 	.globl _P1_2
                                    129 	.globl _P1_3
                                    130 	.globl _P1_4
                                    131 	.globl _P1_5
                                    132 	.globl _P1_6
                                    133 	.globl _P1_7
                                    134 	.globl _AIN8
                                    135 	.globl _AIN9
                                    136 	.globl _AIN10
                                    137 	.globl _AIN11
                                    138 	.globl _AIN12
                                    139 	.globl _AIN13
                                    140 	.globl _RXD_
                                    141 	.globl _TXD_
                                    142 	.globl _SCL0
                                    143 	.globl _SDA0
                                    144 	.globl _P0_0
                                    145 	.globl _P0_1
                                    146 	.globl _P0_2
                                    147 	.globl _P0_3
                                    148 	.globl _P0_4
                                    149 	.globl _P0_5
                                    150 	.globl _P0_6
                                    151 	.globl _P0_7
                                    152 	.globl _IE_SPI0
                                    153 	.globl _IE_USB
                                    154 	.globl _IE_ADC
                                    155 	.globl _IE_UART1
                                    156 	.globl _IE_PWM_I2C
                                    157 	.globl _IE_GPIO
                                    158 	.globl _IE_WDOG
                                    159 	.globl _PX0
                                    160 	.globl _PT0
                                    161 	.globl _PX1
                                    162 	.globl _PT1
                                    163 	.globl _PS
                                    164 	.globl _PT2
                                    165 	.globl _PL_FLAG
                                    166 	.globl _PH_FLAG
                                    167 	.globl _EX0
                                    168 	.globl _ET0
                                    169 	.globl _EX1
                                    170 	.globl _ET1
                                    171 	.globl _ES
                                    172 	.globl _ET2
                                    173 	.globl _E_DIS
                                    174 	.globl _EA
                                    175 	.globl _P
                                    176 	.globl _F1
                                    177 	.globl _OV
                                    178 	.globl _RS0
                                    179 	.globl _RS1
                                    180 	.globl _F0
                                    181 	.globl _AC
                                    182 	.globl _CY
                                    183 	.globl _I2CS_INT_ST
                                    184 	.globl _I2CX_INT
                                    185 	.globl _LED_STATUS
                                    186 	.globl _LED_DMA_H
                                    187 	.globl _LED_DMA_L
                                    188 	.globl _LED_DMA
                                    189 	.globl _LED_PWM_OE
                                    190 	.globl _LED_COMMON
                                    191 	.globl _ADC_CHAN
                                    192 	.globl _ADC_DAT_H
                                    193 	.globl _ADC_DAT_L
                                    194 	.globl _ADC_DAT
                                    195 	.globl _ADC_CTRL
                                    196 	.globl _SPI1_CK_SE
                                    197 	.globl _SPI1_CTRL
                                    198 	.globl _SPI1_DATA
                                    199 	.globl _SPI1_STAT
                                    200 	.globl _SIF1
                                    201 	.globl _SBAUD1
                                    202 	.globl _SBUF1
                                    203 	.globl _SCON1
                                    204 	.globl _SPI0_SETUP
                                    205 	.globl _SPI0_CK_SE
                                    206 	.globl _SPI0_CTRL
                                    207 	.globl _SPI0_DATA
                                    208 	.globl _SPI0_STAT
                                    209 	.globl _T2CAP1H
                                    210 	.globl _T2CAP1L
                                    211 	.globl _T2CAP1
                                    212 	.globl _TH2
                                    213 	.globl _TL2
                                    214 	.globl _T2COUNT
                                    215 	.globl _RCAP2H
                                    216 	.globl _RCAP2L
                                    217 	.globl _RCAP2
                                    218 	.globl _T2MOD
                                    219 	.globl _T2CON
                                    220 	.globl _SBUF
                                    221 	.globl _SCON
                                    222 	.globl _TH1
                                    223 	.globl _TH0
                                    224 	.globl _TL1
                                    225 	.globl _TL0
                                    226 	.globl _TMOD
                                    227 	.globl _TCON
                                    228 	.globl _XBUS_AUX
                                    229 	.globl _P7
                                    230 	.globl _P6_DIR
                                    231 	.globl _P6_OUT_PU
                                    232 	.globl _P6_IN
                                    233 	.globl _P5_DIR
                                    234 	.globl _P5_OUT_PU
                                    235 	.globl _P5_IN
                                    236 	.globl _P4_LED_KEY
                                    237 	.globl _P4_DIR_PU
                                    238 	.globl _P4_MOD_OC
                                    239 	.globl _P4
                                    240 	.globl _P3_DIR_PU
                                    241 	.globl _P3_MOD_OC
                                    242 	.globl _P3
                                    243 	.globl _P2_DIR_PU
                                    244 	.globl _P2_MOD_OC
                                    245 	.globl _P2
                                    246 	.globl _P1_DIR_PU
                                    247 	.globl _P1_MOD_OC
                                    248 	.globl _P1
                                    249 	.globl _P0_DIR_PU
                                    250 	.globl _P0_MOD_OC
                                    251 	.globl _P0
                                    252 	.globl _ROM_CTRL
                                    253 	.globl _ROM_DATA_HH
                                    254 	.globl _ROM_DATA_HL
                                    255 	.globl _ROM_DATA_HI
                                    256 	.globl _ROM_ADDR_H
                                    257 	.globl _ROM_ADDR_L
                                    258 	.globl _ROM_ADDR
                                    259 	.globl _GPIO_IE
                                    260 	.globl _IP_EX
                                    261 	.globl _IE_EX
                                    262 	.globl _IP
                                    263 	.globl _IE
                                    264 	.globl _WDOG_COUNT
                                    265 	.globl _RESET_KEEP
                                    266 	.globl _WAKE_CTRL
                                    267 	.globl _CLOCK_CFG
                                    268 	.globl _POWER_CFG
                                    269 	.globl _PCON
                                    270 	.globl _GLOBAL_CFG
                                    271 	.globl _SAFE_MOD
                                    272 	.globl _DPH
                                    273 	.globl _DPL
                                    274 	.globl _SP
                                    275 	.globl _A_INV
                                    276 	.globl _B
                                    277 	.globl _ACC
                                    278 	.globl _PSW
                                    279 	.globl _raw_hid_receive_PARM_2
                                    280 	.globl _raw_hid_receive_kb_PARM_2
                                    281 	.globl _process_record_via_PARM_2
                                    282 	.globl _via_eeprom_is_valid
                                    283 	.globl _via_eeprom_set_valid
                                    284 	.globl _via_init
                                    285 	.globl _eeconfig_init_via
                                    286 	.globl _via_get_layout_options
                                    287 	.globl _via_set_layout_options_kb
                                    288 	.globl _via_set_layout_options
                                    289 	.globl _process_record_via
                                    290 	.globl _raw_hid_receive
                                    291 ;--------------------------------------------------------
                                    292 ; special function registers
                                    293 ;--------------------------------------------------------
                                    294 	.area RSEG    (ABS,DATA)
      000000                        295 	.org 0x0000
                           0000D0   296 _PSW	=	0x00d0
                           0000E0   297 _ACC	=	0x00e0
                           0000F0   298 _B	=	0x00f0
                           0000FD   299 _A_INV	=	0x00fd
                           000081   300 _SP	=	0x0081
                           000082   301 _DPL	=	0x0082
                           000083   302 _DPH	=	0x0083
                           0000A1   303 _SAFE_MOD	=	0x00a1
                           0000B1   304 _GLOBAL_CFG	=	0x00b1
                           000087   305 _PCON	=	0x0087
                           0000BA   306 _POWER_CFG	=	0x00ba
                           0000B9   307 _CLOCK_CFG	=	0x00b9
                           0000A9   308 _WAKE_CTRL	=	0x00a9
                           0000FE   309 _RESET_KEEP	=	0x00fe
                           0000FF   310 _WDOG_COUNT	=	0x00ff
                           0000A8   311 _IE	=	0x00a8
                           0000B8   312 _IP	=	0x00b8
                           0000E8   313 _IE_EX	=	0x00e8
                           0000E9   314 _IP_EX	=	0x00e9
                           0000B2   315 _GPIO_IE	=	0x00b2
                           008584   316 _ROM_ADDR	=	0x8584
                           000084   317 _ROM_ADDR_L	=	0x0084
                           000085   318 _ROM_ADDR_H	=	0x0085
                           008F8E   319 _ROM_DATA_HI	=	0x8f8e
                           00008E   320 _ROM_DATA_HL	=	0x008e
                           00008F   321 _ROM_DATA_HH	=	0x008f
                           000086   322 _ROM_CTRL	=	0x0086
                           000080   323 _P0	=	0x0080
                           0000C4   324 _P0_MOD_OC	=	0x00c4
                           0000C5   325 _P0_DIR_PU	=	0x00c5
                           000090   326 _P1	=	0x0090
                           000092   327 _P1_MOD_OC	=	0x0092
                           000093   328 _P1_DIR_PU	=	0x0093
                           0000A0   329 _P2	=	0x00a0
                           000094   330 _P2_MOD_OC	=	0x0094
                           000095   331 _P2_DIR_PU	=	0x0095
                           0000B0   332 _P3	=	0x00b0
                           000096   333 _P3_MOD_OC	=	0x0096
                           000097   334 _P3_DIR_PU	=	0x0097
                           0000C0   335 _P4	=	0x00c0
                           0000C2   336 _P4_MOD_OC	=	0x00c2
                           0000C3   337 _P4_DIR_PU	=	0x00c3
                           0000C1   338 _P4_LED_KEY	=	0x00c1
                           0000AA   339 _P5_IN	=	0x00aa
                           0000AB   340 _P5_OUT_PU	=	0x00ab
                           0000AC   341 _P5_DIR	=	0x00ac
                           0000AD   342 _P6_IN	=	0x00ad
                           0000AE   343 _P6_OUT_PU	=	0x00ae
                           0000AF   344 _P6_DIR	=	0x00af
                           0000F1   345 _P7	=	0x00f1
                           0000A2   346 _XBUS_AUX	=	0x00a2
                           000088   347 _TCON	=	0x0088
                           000089   348 _TMOD	=	0x0089
                           00008A   349 _TL0	=	0x008a
                           00008B   350 _TL1	=	0x008b
                           00008C   351 _TH0	=	0x008c
                           00008D   352 _TH1	=	0x008d
                           000098   353 _SCON	=	0x0098
                           000099   354 _SBUF	=	0x0099
                           0000C8   355 _T2CON	=	0x00c8
                           0000C9   356 _T2MOD	=	0x00c9
                           00CBCA   357 _RCAP2	=	0xcbca
                           0000CA   358 _RCAP2L	=	0x00ca
                           0000CB   359 _RCAP2H	=	0x00cb
                           00CDCC   360 _T2COUNT	=	0xcdcc
                           0000CC   361 _TL2	=	0x00cc
                           0000CD   362 _TH2	=	0x00cd
                           00CFCE   363 _T2CAP1	=	0xcfce
                           0000CE   364 _T2CAP1L	=	0x00ce
                           0000CF   365 _T2CAP1H	=	0x00cf
                           0000F8   366 _SPI0_STAT	=	0x00f8
                           0000F9   367 _SPI0_DATA	=	0x00f9
                           0000FA   368 _SPI0_CTRL	=	0x00fa
                           0000FB   369 _SPI0_CK_SE	=	0x00fb
                           0000FC   370 _SPI0_SETUP	=	0x00fc
                           0000BC   371 _SCON1	=	0x00bc
                           0000BD   372 _SBUF1	=	0x00bd
                           0000BE   373 _SBAUD1	=	0x00be
                           0000BF   374 _SIF1	=	0x00bf
                           0000B4   375 _SPI1_STAT	=	0x00b4
                           0000B5   376 _SPI1_DATA	=	0x00b5
                           0000B6   377 _SPI1_CTRL	=	0x00b6
                           0000B7   378 _SPI1_CK_SE	=	0x00b7
                           0000F3   379 _ADC_CTRL	=	0x00f3
                           00F5F4   380 _ADC_DAT	=	0xf5f4
                           0000F4   381 _ADC_DAT_L	=	0x00f4
                           0000F5   382 _ADC_DAT_H	=	0x00f5
                           0000F6   383 _ADC_CHAN	=	0x00f6
                           0000A6   384 _LED_COMMON	=	0x00a6
                           0000A7   385 _LED_PWM_OE	=	0x00a7
                           00C7C6   386 _LED_DMA	=	0xc7c6
                           0000C6   387 _LED_DMA_L	=	0x00c6
                           0000C7   388 _LED_DMA_H	=	0x00c7
                           0000F7   389 _LED_STATUS	=	0x00f7
                           0000B3   390 _I2CX_INT	=	0x00b3
                           0000BB   391 _I2CS_INT_ST	=	0x00bb
                                    392 ;--------------------------------------------------------
                                    393 ; special function bits
                                    394 ;--------------------------------------------------------
                                    395 	.area RSEG    (ABS,DATA)
      000000                        396 	.org 0x0000
                           0000D7   397 _CY	=	0x00d7
                           0000D6   398 _AC	=	0x00d6
                           0000D5   399 _F0	=	0x00d5
                           0000D4   400 _RS1	=	0x00d4
                           0000D3   401 _RS0	=	0x00d3
                           0000D2   402 _OV	=	0x00d2
                           0000D1   403 _F1	=	0x00d1
                           0000D0   404 _P	=	0x00d0
                           0000AF   405 _EA	=	0x00af
                           0000AE   406 _E_DIS	=	0x00ae
                           0000AD   407 _ET2	=	0x00ad
                           0000AC   408 _ES	=	0x00ac
                           0000AB   409 _ET1	=	0x00ab
                           0000AA   410 _EX1	=	0x00aa
                           0000A9   411 _ET0	=	0x00a9
                           0000A8   412 _EX0	=	0x00a8
                           0000BF   413 _PH_FLAG	=	0x00bf
                           0000BE   414 _PL_FLAG	=	0x00be
                           0000BD   415 _PT2	=	0x00bd
                           0000BC   416 _PS	=	0x00bc
                           0000BB   417 _PT1	=	0x00bb
                           0000BA   418 _PX1	=	0x00ba
                           0000B9   419 _PT0	=	0x00b9
                           0000B8   420 _PX0	=	0x00b8
                           0000EF   421 _IE_WDOG	=	0x00ef
                           0000EE   422 _IE_GPIO	=	0x00ee
                           0000ED   423 _IE_PWM_I2C	=	0x00ed
                           0000EC   424 _IE_UART1	=	0x00ec
                           0000EB   425 _IE_ADC	=	0x00eb
                           0000E9   426 _IE_USB	=	0x00e9
                           0000E8   427 _IE_SPI0	=	0x00e8
                           000087   428 _P0_7	=	0x0087
                           000086   429 _P0_6	=	0x0086
                           000085   430 _P0_5	=	0x0085
                           000084   431 _P0_4	=	0x0084
                           000083   432 _P0_3	=	0x0083
                           000082   433 _P0_2	=	0x0082
                           000081   434 _P0_1	=	0x0081
                           000080   435 _P0_0	=	0x0080
                           000081   436 _SDA0	=	0x0081
                           000080   437 _SCL0	=	0x0080
                           000083   438 _TXD_	=	0x0083
                           000082   439 _RXD_	=	0x0082
                           000085   440 _AIN13	=	0x0085
                           000084   441 _AIN12	=	0x0084
                           000083   442 _AIN11	=	0x0083
                           000082   443 _AIN10	=	0x0082
                           000081   444 _AIN9	=	0x0081
                           000080   445 _AIN8	=	0x0080
                           000097   446 _P1_7	=	0x0097
                           000096   447 _P1_6	=	0x0096
                           000095   448 _P1_5	=	0x0095
                           000094   449 _P1_4	=	0x0094
                           000093   450 _P1_3	=	0x0093
                           000092   451 _P1_2	=	0x0092
                           000091   452 _P1_1	=	0x0091
                           000090   453 _P1_0	=	0x0090
                           000097   454 _TXD1_	=	0x0097
                           000096   455 _RXD1_	=	0x0096
                           000097   456 _SCK	=	0x0097
                           000096   457 _MISO	=	0x0096
                           000095   458 _MOSI	=	0x0095
                           000094   459 _SCS	=	0x0094
                           000092   460 _INT0_	=	0x0092
                           000091   461 _T2EX	=	0x0091
                           000091   462 _CAP2	=	0x0091
                           000090   463 _T2	=	0x0090
                           000090   464 _CAP1	=	0x0090
                           000097   465 _AIN7	=	0x0097
                           000096   466 _AIN6	=	0x0096
                           000095   467 _AIN5	=	0x0095
                           000094   468 _AIN4	=	0x0094
                           000093   469 _AIN3	=	0x0093
                           000092   470 _AIN2	=	0x0092
                           000091   471 _AIN1	=	0x0091
                           000090   472 _AIN0	=	0x0090
                           0000A7   473 _P2_7	=	0x00a7
                           0000A6   474 _P2_6	=	0x00a6
                           0000A5   475 _P2_5	=	0x00a5
                           0000A4   476 _P2_4	=	0x00a4
                           0000A3   477 _P2_3	=	0x00a3
                           0000A2   478 _P2_2	=	0x00a2
                           0000A1   479 _P2_1	=	0x00a1
                           0000A0   480 _P2_0	=	0x00a0
                           0000A7   481 _TXD1	=	0x00a7
                           0000A6   482 _RXD1	=	0x00a6
                           0000A5   483 _T2EX_	=	0x00a5
                           0000A5   484 _CAP2_	=	0x00a5
                           0000A4   485 _T2_	=	0x00a4
                           0000A4   486 _CAP1_	=	0x00a4
                           0000B7   487 _P3_7	=	0x00b7
                           0000B6   488 _P3_6	=	0x00b6
                           0000B5   489 _P3_5	=	0x00b5
                           0000B4   490 _P3_4	=	0x00b4
                           0000B3   491 _P3_3	=	0x00b3
                           0000B2   492 _P3_2	=	0x00b2
                           0000B1   493 _P3_1	=	0x00b1
                           0000B0   494 _P3_0	=	0x00b0
                           0000B7   495 _SCK1	=	0x00b7
                           0000B6   496 _MISO1	=	0x00b6
                           0000B5   497 _MOSI1	=	0x00b5
                           0000B5   498 _T1	=	0x00b5
                           0000B4   499 _T0	=	0x00b4
                           0000B3   500 _INT1	=	0x00b3
                           0000B2   501 _INT0	=	0x00b2
                           0000B1   502 _TXD	=	0x00b1
                           0000B0   503 _RXD	=	0x00b0
                           0000C6   504 _P4_6	=	0x00c6
                           0000C5   505 _P4_5	=	0x00c5
                           0000C4   506 _P4_4	=	0x00c4
                           0000C3   507 _P4_3	=	0x00c3
                           0000C2   508 _P4_2	=	0x00c2
                           0000C1   509 _P4_1	=	0x00c1
                           0000C0   510 _P4_0	=	0x00c0
                           00008F   511 _TF1	=	0x008f
                           00008E   512 _TR1	=	0x008e
                           00008D   513 _TF0	=	0x008d
                           00008C   514 _TR0	=	0x008c
                           00008B   515 _IE1	=	0x008b
                           00008A   516 _IT1	=	0x008a
                           000089   517 _IE0	=	0x0089
                           000088   518 _IT0	=	0x0088
                           00009F   519 _SM0	=	0x009f
                           00009E   520 _SM1	=	0x009e
                           00009D   521 _SM2	=	0x009d
                           00009C   522 _REN	=	0x009c
                           00009B   523 _TB8	=	0x009b
                           00009A   524 _RB8	=	0x009a
                           000099   525 _TI	=	0x0099
                           000098   526 _RI	=	0x0098
                           0000CF   527 _TF2	=	0x00cf
                           0000CF   528 _CAP1F	=	0x00cf
                           0000CE   529 _EXF2	=	0x00ce
                           0000CD   530 _RCLK	=	0x00cd
                           0000CC   531 _TCLK	=	0x00cc
                           0000CB   532 _EXEN2	=	0x00cb
                           0000CA   533 _TR2	=	0x00ca
                           0000C9   534 _C_T2	=	0x00c9
                           0000C8   535 _CP_RL2	=	0x00c8
                           0000FF   536 _S0_FST_ACT	=	0x00ff
                           0000FE   537 _S0_IF_OV	=	0x00fe
                           0000FD   538 _S0_IF_FIRST	=	0x00fd
                           0000FC   539 _S0_IF_BYTE	=	0x00fc
                           0000FB   540 _S0_FREE	=	0x00fb
                           0000FA   541 _S0_T_FIFO	=	0x00fa
                           0000F8   542 _S0_R_FIFO	=	0x00f8
                           0000F7   543 _ADC_START	=	0x00f7
                                    544 ;--------------------------------------------------------
                                    545 ; overlayable register banks
                                    546 ;--------------------------------------------------------
                                    547 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        548 	.ds 8
                                    549 ;--------------------------------------------------------
                                    550 ; internal ram data
                                    551 ;--------------------------------------------------------
                                    552 	.area DSEG    (DATA)
      000038                        553 _raw_hid_receive_sloc0_1_0:
      000038                        554 	.ds 4
      00003C                        555 _raw_hid_receive_sloc1_1_0:
      00003C                        556 	.ds 1
      00003D                        557 _raw_hid_receive_sloc2_1_0:
      00003D                        558 	.ds 1
      00003E                        559 _raw_hid_receive_sloc3_1_0:
      00003E                        560 	.ds 2
      000040                        561 _raw_hid_receive_sloc4_1_0:
      000040                        562 	.ds 2
                                    563 ;--------------------------------------------------------
                                    564 ; overlayable items in internal ram
                                    565 ;--------------------------------------------------------
                                    566 ;--------------------------------------------------------
                                    567 ; indirectly addressable internal ram data
                                    568 ;--------------------------------------------------------
                                    569 	.area ISEG    (DATA)
                                    570 ;--------------------------------------------------------
                                    571 ; absolute internal ram data
                                    572 ;--------------------------------------------------------
                                    573 	.area IABS    (ABS,DATA)
                                    574 	.area IABS    (ABS,DATA)
                                    575 ;--------------------------------------------------------
                                    576 ; bit data
                                    577 ;--------------------------------------------------------
                                    578 	.area BSEG    (BIT)
      000029                        579 _via_eeprom_is_valid_sloc0_1_0:
      000029                        580 	.ds 1
                                    581 ;--------------------------------------------------------
                                    582 ; paged external ram data
                                    583 ;--------------------------------------------------------
                                    584 	.area PSEG    (PAG,XDATA)
                                    585 ;--------------------------------------------------------
                                    586 ; uninitialized external ram data
                                    587 ;--------------------------------------------------------
                                    588 	.area XSEG    (XDATA)
      000C48                        589 _via_eeprom_set_valid_valid_10000_609:
      000C48                        590 	.ds 1
      000C49                        591 _via_set_layout_options_value_10000_625:
      000C49                        592 	.ds 4
      000C4D                        593 _process_record_via_PARM_2:
      000C4D                        594 	.ds 3
      000C50                        595 _process_record_via_keycode_10000_627:
      000C50                        596 	.ds 2
      000C52                        597 _raw_hid_receive_kb_PARM_2:
      000C52                        598 	.ds 1
      000C53                        599 _raw_hid_receive_kb_data_10000_633:
      000C53                        600 	.ds 3
      000C56                        601 _raw_hid_receive_PARM_2:
      000C56                        602 	.ds 1
      000C57                        603 _raw_hid_receive_packet_10000_635:
      000C57                        604 	.ds 3
                                    605 ;--------------------------------------------------------
                                    606 ; absolute external ram data
                                    607 ;--------------------------------------------------------
                                    608 	.area XABS    (ABS,XDATA)
                                    609 ;--------------------------------------------------------
                                    610 ; initialized external ram data
                                    611 ;--------------------------------------------------------
                                    612 	.area XISEG   (XDATA)
                                    613 	.area HOME    (CODE)
                                    614 	.area GSINIT0 (CODE)
                                    615 	.area GSINIT1 (CODE)
                                    616 	.area GSINIT2 (CODE)
                                    617 	.area GSINIT3 (CODE)
                                    618 	.area GSINIT4 (CODE)
                                    619 	.area GSINIT5 (CODE)
                                    620 	.area GSINIT  (CODE)
                                    621 	.area GSFINAL (CODE)
                                    622 	.area CSEG    (CODE)
                                    623 ;--------------------------------------------------------
                                    624 ; global & static initialisations
                                    625 ;--------------------------------------------------------
                                    626 	.area HOME    (CODE)
                                    627 	.area GSINIT  (CODE)
                                    628 	.area GSFINAL (CODE)
                                    629 	.area GSINIT  (CODE)
                                    630 ;--------------------------------------------------------
                                    631 ; Home
                                    632 ;--------------------------------------------------------
                                    633 	.area HOME    (CODE)
                                    634 	.area HOME    (CODE)
                                    635 ;--------------------------------------------------------
                                    636 ; code
                                    637 ;--------------------------------------------------------
                                    638 	.area CSEG    (CODE)
                                    639 ;------------------------------------------------------------
                                    640 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    641 ;------------------------------------------------------------
                                    642 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_193'
                                    643 ;------------------------------------------------------------
                                    644 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    645 ;	-----------------------------------------
                           000007   646 	ar7 = 0x07
                           000006   647 	ar6 = 0x06
                           000005   648 	ar5 = 0x05
                           000004   649 	ar4 = 0x04
                           000003   650 	ar3 = 0x03
                           000002   651 	ar2 = 0x02
                           000001   652 	ar1 = 0x01
                           000000   653 	ar0 = 0x00
                                    654 ;	 function via_eeprom_is_valid
                                    655 ;	-----------------------------------------
      00A513                        656 _via_eeprom_is_valid:
                                    657 ;	quantum/via.c:103: return (eeprom_read_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 0) == magic0 && eeprom_read_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 1) == magic1 && eeprom_read_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 2) == magic2);
      00A513 90 00 25         [24]  658 	mov	dptr,#0x0025
      00A516 75 F0 00         [24]  659 	mov	b, #0x00
      00A519 12 40 74         [24]  660 	lcall	_eeprom_read_byte
      00A51C AF 82            [24]  661 	mov	r7, dpl
      00A51E BF 02 1E         [24]  662 	cjne	r7,#0x02,00103$
      00A521 90 00 26         [24]  663 	mov	dptr,#0x0026
      00A524 75 F0 00         [24]  664 	mov	b, #0x00
      00A527 12 40 74         [24]  665 	lcall	_eeprom_read_byte
      00A52A AF 82            [24]  666 	mov	r7, dpl
      00A52C BF 20 10         [24]  667 	cjne	r7,#0x20,00103$
      00A52F 90 00 27         [24]  668 	mov	dptr,#0x0027
      00A532 75 F0 00         [24]  669 	mov	b, #0x00
      00A535 12 40 74         [24]  670 	lcall	_eeprom_read_byte
      00A538 AF 82            [24]  671 	mov	r7, dpl
      00A53A BF 08 02         [24]  672 	cjne	r7,#0x08,00126$
      00A53D 80 04            [24]  673 	sjmp	00104$
      00A53F                        674 00126$:
      00A53F                        675 00103$:
                                    676 ;	assignBit
      00A53F C2 29            [12]  677 	clr	_via_eeprom_is_valid_sloc0_1_0
      00A541 80 02            [24]  678 	sjmp	00105$
      00A543                        679 00104$:
                                    680 ;	assignBit
      00A543 D2 29            [12]  681 	setb	_via_eeprom_is_valid_sloc0_1_0
      00A545                        682 00105$:
      00A545 A2 29            [12]  683 	mov	c,_via_eeprom_is_valid_sloc0_1_0
      00A547 12 38 B1         [24]  684 	lcall	_ak820_outline_0159
                                    685 ;	quantum/via.c:104: }
      00A54A 22               [24]  686 	ret
                                    687 ;------------------------------------------------------------
                                    688 ;Allocation info for local variables in function 'via_eeprom_set_valid'
                                    689 ;------------------------------------------------------------
                                    690 ;valid         Allocated with name '_via_eeprom_set_valid_valid_10000_609'
                                    691 ;magic0        Allocated with name '_via_eeprom_set_valid_magic0_10000_610'
                                    692 ;magic1        Allocated with name '_via_eeprom_set_valid_magic1_10000_610'
                                    693 ;magic2        Allocated with name '_via_eeprom_set_valid_magic2_10000_610'
                                    694 ;------------------------------------------------------------
                                    695 ;	quantum/via.c:108: void via_eeprom_set_valid(__xdata bool valid) {
                                    696 ;	-----------------------------------------
                                    697 ;	 function via_eeprom_set_valid
                                    698 ;	-----------------------------------------
      00A54B                        699 _via_eeprom_set_valid:
      00A54B E5 82            [12]  700 	mov	a,dpl
      00A54D 90 0C 48         [24]  701 	mov	dptr,#_via_eeprom_set_valid_valid_10000_609
      00A550 F0               [24]  702 	movx	@dptr,a
                                    703 ;	quantum/via.c:120: eeprom_update_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 0, valid ? magic0 : 0xFF);
      00A551 E0               [24]  704 	movx	a,@dptr
      00A552 60 04            [24]  705 	jz	00103$
      00A554 7F 02            [12]  706 	mov	r7,#0x02
      00A556 80 02            [24]  707 	sjmp	00104$
      00A558                        708 00103$:
      00A558 7F FF            [12]  709 	mov	r7,#0xff
      00A55A                        710 00104$:
      00A55A 90 06 9B         [24]  711 	mov	dptr,#_eeprom_update_byte_PARM_2
      00A55D EF               [12]  712 	mov	a,r7
      00A55E F0               [24]  713 	movx	@dptr,a
      00A55F 90 00 25         [24]  714 	mov	dptr,#0x0025
      00A562 75 F0 00         [24]  715 	mov	b, #0x00
      00A565 12 4D DD         [24]  716 	lcall	_eeprom_update_byte
                                    717 ;	quantum/via.c:121: eeprom_update_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 1, valid ? magic1 : 0xFF);
      00A568 90 0C 48         [24]  718 	mov	dptr,#_via_eeprom_set_valid_valid_10000_609
      00A56B E0               [24]  719 	movx	a,@dptr
      00A56C 60 04            [24]  720 	jz	00105$
      00A56E 7F 20            [12]  721 	mov	r7,#0x20
      00A570 80 02            [24]  722 	sjmp	00106$
      00A572                        723 00105$:
      00A572 7F FF            [12]  724 	mov	r7,#0xff
      00A574                        725 00106$:
      00A574 90 06 9B         [24]  726 	mov	dptr,#_eeprom_update_byte_PARM_2
      00A577 EF               [12]  727 	mov	a,r7
      00A578 F0               [24]  728 	movx	@dptr,a
      00A579 90 00 26         [24]  729 	mov	dptr,#0x0026
      00A57C 75 F0 00         [24]  730 	mov	b, #0x00
      00A57F 12 4D DD         [24]  731 	lcall	_eeprom_update_byte
                                    732 ;	quantum/via.c:122: eeprom_update_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 2, valid ? magic2 : 0xFF);
      00A582 90 0C 48         [24]  733 	mov	dptr,#_via_eeprom_set_valid_valid_10000_609
      00A585 E0               [24]  734 	movx	a,@dptr
      00A586 60 04            [24]  735 	jz	00107$
      00A588 7F 08            [12]  736 	mov	r7,#0x08
      00A58A 80 02            [24]  737 	sjmp	00108$
      00A58C                        738 00107$:
      00A58C 7F FF            [12]  739 	mov	r7,#0xff
      00A58E                        740 00108$:
      00A58E 90 06 9B         [24]  741 	mov	dptr,#_eeprom_update_byte_PARM_2
      00A591 EF               [12]  742 	mov	a,r7
      00A592 F0               [24]  743 	movx	@dptr,a
      00A593 90 00 27         [24]  744 	mov	dptr,#0x0027
      00A596 75 F0 00         [24]  745 	mov	b, #0x00
                                    746 ;	quantum/via.c:123: }
      00A599 02 4D DD         [24]  747 	ljmp	_eeprom_update_byte
                                    748 ;------------------------------------------------------------
                                    749 ;Allocation info for local variables in function 'via_init_kb'
                                    750 ;------------------------------------------------------------
                                    751 ;	quantum/via.c:131: __attribute__((weak)) void via_init_kb(void) {}
                                    752 ;	-----------------------------------------
                                    753 ;	 function via_init
                                    754 ;	-----------------------------------------
      00A59C                        755 _via_init:
                                    756 ;	quantum/via.c:138: via_set_layout_options_kb(via_get_layout_options());
      00A59C 12 A5 C5         [24]  757 	lcall	_via_get_layout_options
      00A59F 12 A5 DD         [24]  758 	lcall	_via_set_layout_options_kb
                                    759 ;	quantum/via.c:142: if (!via_eeprom_is_valid()) {
      00A5A2 12 A5 13         [24]  760 	lcall	_via_eeprom_is_valid
      00A5A5 E5 82            [12]  761 	mov	a, dpl
      00A5A7 70 03            [24]  762 	jnz	00103$
                                    763 ;	quantum/via.c:147: ak820_nvm_schema_fault();
                                    764 ;	quantum/via.c:152: }
      00A5A9 02 3E 23         [24]  765 	ljmp	_ak820_nvm_schema_fault
      00A5AC                        766 00103$:
      00A5AC 22               [24]  767 	ret
                                    768 ;------------------------------------------------------------
                                    769 ;Allocation info for local variables in function 'eeconfig_init_via'
                                    770 ;------------------------------------------------------------
                                    771 ;	quantum/via.c:154: void eeconfig_init_via(void) {
                                    772 ;	-----------------------------------------
                                    773 ;	 function eeconfig_init_via
                                    774 ;	-----------------------------------------
      00A5AD                        775 _eeconfig_init_via:
                                    776 ;	quantum/via.c:156: via_eeprom_set_valid(false);
      00A5AD 75 82 00         [24]  777 	mov	dpl, #0x00
      00A5B0 12 A5 4B         [24]  778 	lcall	_via_eeprom_set_valid
                                    779 ;	quantum/via.c:158: via_set_layout_options(VIA_EEPROM_LAYOUT_OPTIONS_DEFAULT);
      00A5B3 12 8F FA         [24]  780 	lcall	_ak820_outline_0155
      00A5B6 12 A5 DE         [24]  781 	lcall	_via_set_layout_options
                                    782 ;	quantum/via.c:160: dynamic_keymap_reset();
      00A5B9 12 86 80         [24]  783 	lcall	_dynamic_keymap_reset
                                    784 ;	quantum/via.c:162: dynamic_keymap_macro_reset();
      00A5BC 12 8A F3         [24]  785 	lcall	_dynamic_keymap_macro_reset
                                    786 ;	quantum/via.c:164: via_eeprom_set_valid(true);
      00A5BF 75 82 01         [24]  787 	mov	dpl, #0x01
                                    788 ;	quantum/via.c:165: }
      00A5C2 02 A5 4B         [24]  789 	ljmp	_via_eeprom_set_valid
                                    790 ;------------------------------------------------------------
                                    791 ;Allocation info for local variables in function 'via_get_layout_options'
                                    792 ;------------------------------------------------------------
                                    793 ;	quantum/via.c:169: uint32_t via_get_layout_options(void) {
                                    794 ;	-----------------------------------------
                                    795 ;	 function via_get_layout_options
                                    796 ;	-----------------------------------------
      00A5C5                        797 _via_get_layout_options:
                                    798 ;	quantum/via.c:173: return eeprom_read_byte((uint8_t *)VIA_EEPROM_LAYOUT_OPTIONS_ADDR);
      00A5C5 90 00 28         [24]  799 	mov	dptr,#0x0028
      00A5C8 75 F0 00         [24]  800 	mov	b, #0x00
      00A5CB 12 40 74         [24]  801 	lcall	_eeprom_read_byte
      00A5CE AF 82            [24]  802 	mov	r7, dpl
      00A5D0 7E 00            [12]  803 	mov	r6,#0x00
      00A5D2 7D 00            [12]  804 	mov	r5,#0x00
      00A5D4 7C 00            [12]  805 	mov	r4,#0x00
      00A5D6 12 43 72         [24]  806 	lcall	_ak820_outline_0161
      00A5D9 8D F0            [24]  807 	mov	b, r5
      00A5DB EC               [12]  808 	mov	a, r4
                                    809 ;	quantum/via.c:185: }
      00A5DC 22               [24]  810 	ret
                                    811 ;------------------------------------------------------------
                                    812 ;Allocation info for local variables in function 'via_set_layout_options_kb'
                                    813 ;------------------------------------------------------------
                                    814 ;value         Allocated with name '_via_set_layout_options_kb_value_10000_622'
                                    815 ;------------------------------------------------------------
                                    816 ;	quantum/via.c:187: __attribute__((weak)) void via_set_layout_options_kb(uint32_t value) {}
                                    817 ;	-----------------------------------------
                                    818 ;	 function via_set_layout_options_kb
                                    819 ;	-----------------------------------------
      00A5DD                        820 _via_set_layout_options_kb:
      00A5DD 22               [24]  821 	ret
                                    822 ;------------------------------------------------------------
                                    823 ;Allocation info for local variables in function 'via_set_layout_options'
                                    824 ;------------------------------------------------------------
                                    825 ;value         Allocated with name '_via_set_layout_options_value_10000_625'
                                    826 ;------------------------------------------------------------
                                    827 ;	quantum/via.c:189: void via_set_layout_options(uint32_t value) {
                                    828 ;	-----------------------------------------
                                    829 ;	 function via_set_layout_options
                                    830 ;	-----------------------------------------
      00A5DE                        831 _via_set_layout_options:
      00A5DE 12 8F F2         [24]  832 	lcall	_ak820_outline_0122
      00A5E1 90 0C 49         [24]  833 	mov	dptr,#_via_set_layout_options_value_10000_625
      00A5E4 12 8F E0         [24]  834 	lcall	_ak820_outline_0044
                                    835 ;	quantum/via.c:192: eeprom_update_byte((uint8_t *)VIA_EEPROM_LAYOUT_OPTIONS_ADDR, (uint8_t)value);
      00A5E7 90 0C 49         [24]  836 	mov	dptr,#_via_set_layout_options_value_10000_625
      00A5EA E0               [24]  837 	movx	a,@dptr
      00A5EB 90 06 9B         [24]  838 	mov	dptr,#_eeprom_update_byte_PARM_2
      00A5EE F0               [24]  839 	movx	@dptr,a
      00A5EF 90 00 28         [24]  840 	mov	dptr,#0x0028
      00A5F2 75 F0 00         [24]  841 	mov	b, #0x00
                                    842 ;	quantum/via.c:202: }
      00A5F5 02 4D DD         [24]  843 	ljmp	_eeprom_update_byte
                                    844 ;------------------------------------------------------------
                                    845 ;Allocation info for local variables in function 'process_record_via'
                                    846 ;------------------------------------------------------------
                                    847 ;record        Allocated with name '_process_record_via_PARM_2'
                                    848 ;keycode       Allocated with name '_process_record_via_keycode_10000_627'
                                    849 ;id            Allocated with name '_process_record_via_id_50000_632'
                                    850 ;------------------------------------------------------------
                                    851 ;	quantum/via.c:205: bool process_record_via(uint16_t keycode, keyrecord_t *record) {
                                    852 ;	-----------------------------------------
                                    853 ;	 function process_record_via
                                    854 ;	-----------------------------------------
      00A5F8                        855 _process_record_via:
      00A5F8 12 38 82         [24]  856 	lcall	_ak820_outline_0109
      00A5FB 90 0C 50         [24]  857 	mov	dptr,#_process_record_via_keycode_10000_627
      00A5FE 12 38 87         [24]  858 	lcall	_ak820_outline_0110
                                    859 ;	quantum/via.c:207: if (record->event.pressed) {
      00A601 90 0C 4D         [24]  860 	mov	dptr,#_process_record_via_PARM_2
      00A604 12 4E E9         [24]  861 	lcall	_ak820_outline_0012
      00A607 74 05            [12]  862 	mov	a,#0x05
      00A609 12 38 BB         [24]  863 	lcall	_ak820_outline_0163
      00A60C 12 6D 59         [24]  864 	lcall	_ak820_outline_0059
      00A60F 12 B8 86         [24]  865 	lcall	__gptrget
      00A612 60 1D            [24]  866 	jz	00105$
                                    867 ;	quantum/via.c:208: if (keycode >= QK_MACRO && keycode <= QK_MACRO_MAX) {
      00A614 90 0C 50         [24]  868 	mov	dptr,#_process_record_via_keycode_10000_627
      00A617 12 48 26         [24]  869 	lcall	_ak820_outline_0008
      00A61A 74 89            [12]  870 	mov	a,#0x100 - 0x77
      00A61C 2D               [12]  871 	add	a,r5
      00A61D 50 12            [24]  872 	jnc	00105$
      00A61F C3               [12]  873 	clr	c
      00A620 74 7F            [12]  874 	mov	a,#0x7f
      00A622 9C               [12]  875 	subb	a,r4
      00A623 74 77            [12]  876 	mov	a,#0x77
      00A625 9D               [12]  877 	subb	a,r5
      00A626 40 09            [24]  878 	jc	00105$
                                    879 ;	free result
                                    880 ;	quantum/via.c:209: uint8_t id = keycode - QK_MACRO;
                                    881 ;	quantum/via.c:210: dynamic_keymap_macro_send(id);
      00A628 8E 82            [24]  882 	mov	dpl, r6
      00A62A 12 8B 19         [24]  883 	lcall	_dynamic_keymap_macro_send
                                    884 ;	quantum/via.c:211: return false;
      00A62D 75 82 00         [24]  885 	mov	dpl, #0x00
      00A630 22               [24]  886 	ret
      00A631                        887 00105$:
                                    888 ;	quantum/via.c:215: return true;
      00A631 75 82 01         [24]  889 	mov	dpl, #0x01
                                    890 ;	quantum/via.c:216: }
      00A634 22               [24]  891 	ret
                                    892 ;------------------------------------------------------------
                                    893 ;Allocation info for local variables in function 'raw_hid_receive_kb'
                                    894 ;------------------------------------------------------------
                                    895 ;length        Allocated with name '_raw_hid_receive_kb_PARM_2'
                                    896 ;data          Allocated with name '_raw_hid_receive_kb_data_10000_633'
                                    897 ;command_id    Allocated with name '_raw_hid_receive_kb_command_id_10000_634'
                                    898 ;------------------------------------------------------------
                                    899 ;	quantum/via.c:221: __attribute__((weak)) void raw_hid_receive_kb(uint8_t *data, uint8_t length) {
                                    900 ;	-----------------------------------------
                                    901 ;	 function raw_hid_receive_kb
                                    902 ;	-----------------------------------------
      00A635                        903 _raw_hid_receive_kb:
      00A635 12 43 13         [24]  904 	lcall	_ak820_outline_0036
      00A638 90 0C 53         [24]  905 	mov	dptr,#_raw_hid_receive_kb_data_10000_633
      00A63B 12 38 1F         [24]  906 	lcall	_ak820_outline_0016
                                    907 ;	quantum/via.c:222: uint8_t *command_id = &(data[0]);
      00A63E 90 0C 53         [24]  908 	mov	dptr,#_raw_hid_receive_kb_data_10000_633
      00A641 12 4E C3         [24]  909 	lcall	_ak820_outline_0001
                                    910 ;	quantum/via.c:223: *command_id         = id_unhandled;
      00A644 74 FF            [12]  911 	mov	a,#0xff
                                    912 ;	quantum/via.c:224: }
      00A646 02 B8 4B         [24]  913 	ljmp	__gptrput
                                    914 ;------------------------------------------------------------
                                    915 ;Allocation info for local variables in function 'raw_hid_receive'
                                    916 ;------------------------------------------------------------
                                    917 ;sloc0         Allocated with name '_raw_hid_receive_sloc0_1_0'
                                    918 ;sloc1         Allocated with name '_raw_hid_receive_sloc1_1_0'
                                    919 ;sloc2         Allocated with name '_raw_hid_receive_sloc2_1_0'
                                    920 ;sloc3         Allocated with name '_raw_hid_receive_sloc3_1_0'
                                    921 ;sloc4         Allocated with name '_raw_hid_receive_sloc4_1_0'
                                    922 ;length        Allocated with name '_raw_hid_receive_PARM_2'
                                    923 ;packet        Allocated with name '_raw_hid_receive_packet_10000_635'
                                    924 ;data          Allocated with name '_raw_hid_receive_data_10000_636'
                                    925 ;command_id    Allocated with name '_raw_hid_receive_command_id_10000_636'
                                    926 ;command_data  Allocated with name '_raw_hid_receive_command_data_10000_636'
                                    927 ;cmd           Allocated with name '_raw_hid_receive_cmd_30001_642'
                                    928 ;value         Allocated with name '_raw_hid_receive_value_70000_650'
                                    929 ;value         Allocated with name '_raw_hid_receive_value_70000_651'
                                    930 ;i             Allocated with name '_raw_hid_receive_i_70001_654'
                                    931 ;row           Allocated with name '_raw_hid_receive_row_80001_655'
                                    932 ;value         Allocated with name '_raw_hid_receive_value_90001_656'
                                    933 ;value         Allocated with name '_raw_hid_receive_value_70000_661'
                                    934 ;keycode       Allocated with name '_raw_hid_receive_keycode_40000_663'
                                    935 ;size          Allocated with name '_raw_hid_receive_size_40000_672'
                                    936 ;offset        Allocated with name '_raw_hid_receive_offset_40000_673'
                                    937 ;size          Allocated with name '_raw_hid_receive_size_40000_673'
                                    938 ;offset        Allocated with name '_raw_hid_receive_offset_40001_678'
                                    939 ;size          Allocated with name '_raw_hid_receive_size_40001_678'
                                    940 ;offset        Allocated with name '_raw_hid_receive_offset_40000_683'
                                    941 ;size          Allocated with name '_raw_hid_receive_size_40000_683'
                                    942 ;offset        Allocated with name '_raw_hid_receive_offset_40000_685'
                                    943 ;size          Allocated with name '_raw_hid_receive_size_40000_685'
                                    944 ;i             Allocated with name '_raw_hid_receive_i_60000_690'
                                    945 ;------------------------------------------------------------
                                    946 ;	quantum/via.c:233: void raw_hid_receive(uint8_t *packet, uint8_t length) {
                                    947 ;	-----------------------------------------
                                    948 ;	 function raw_hid_receive
                                    949 ;	-----------------------------------------
      00A649                        950 _raw_hid_receive:
      00A649 12 43 13         [24]  951 	lcall	_ak820_outline_0036
      00A64C 90 0C 57         [24]  952 	mov	dptr,#_raw_hid_receive_packet_10000_635
      00A64F 12 38 1F         [24]  953 	lcall	_ak820_outline_0016
                                    954 ;	quantum/via.c:236: uint8_t __xdata *data = (uint8_t __xdata *)packet;
      00A652 90 0C 57         [24]  955 	mov	dptr,#_raw_hid_receive_packet_10000_635
      00A655 12 38 41         [24]  956 	lcall	_ak820_outline_0052
                                    957 ;	quantum/via.c:238: uint8_t __xdata *command_data = &data[1];
      00A658 74 01            [12]  958 	mov	a,#0x01
      00A65A 12 43 77         [24]  959 	lcall	_ak820_outline_0164
                                    960 ;	quantum/via.c:245: if (length != 32) return;
      00A65D 90 0C 56         [24]  961 	mov	dptr,#_raw_hid_receive_PARM_2
      00A660 E0               [24]  962 	movx	a,@dptr
      00A661 FB               [12]  963 	mov	r3,a
      00A662 BB 20 02         [24]  964 	cjne	r3,#0x20,00520$
      00A665 80 01            [24]  965 	sjmp	00102$
      00A667                        966 00520$:
      00A667 22               [24]  967 	ret
      00A668                        968 00102$:
                                    969 ;	quantum/via.c:249: if (vial_unlock_in_progress) {
      00A668 90 0E 25         [24]  970 	mov	dptr,#_vial_unlock_in_progress
      00A66B E0               [24]  971 	movx	a,@dptr
      00A66C 60 32            [24]  972 	jz	00114$
                                    973 ;	quantum/via.c:250: if (data[0] != id_vial_prefix) {
      00A66E 12 38 8C         [24]  974 	lcall	_ak820_outline_0120
      00A671 E0               [24]  975 	movx	a,@dptr
      00A672 FA               [12]  976 	mov	r2,a
      00A673 BA FE 02         [24]  977 	cjne	r2,#0xfe,00522$
      00A676 80 01            [24]  978 	sjmp	00104$
      00A678                        979 00522$:
                                    980 ;	quantum/via.c:252: return;
      00A678 22               [24]  981 	ret
      00A679                        982 00104$:
                                    983 ;	quantum/via.c:257: uint8_t cmd = data[1];
      00A679 12 43 44         [24]  984 	lcall	_ak820_outline_0096
                                    985 ;	quantum/via.c:258: if (cmd != vial_get_keyboard_id && cmd != vial_get_size && cmd != vial_get_def && cmd != vial_get_unlock_status && cmd != vial_unlock_start && cmd != vial_unlock_poll && cmd != vial_lock)
      00A67C FA               [12]  986 	mov	r2,a
      00A67D 60 21            [24]  987 	jz	00114$
      00A67F BA 01 02         [24]  988 	cjne	r2,#0x01,00524$
      00A682 80 1C            [24]  989 	sjmp	00114$
      00A684                        990 00524$:
      00A684 BA 02 02         [24]  991 	cjne	r2,#0x02,00525$
      00A687 80 17            [24]  992 	sjmp	00114$
      00A689                        993 00525$:
      00A689 BA 05 02         [24]  994 	cjne	r2,#0x05,00526$
      00A68C 80 12            [24]  995 	sjmp	00114$
      00A68E                        996 00526$:
      00A68E BA 06 02         [24]  997 	cjne	r2,#0x06,00527$
      00A691 80 0D            [24]  998 	sjmp	00114$
      00A693                        999 00527$:
      00A693 BA 07 02         [24] 1000 	cjne	r2,#0x07,00528$
      00A696 80 08            [24] 1001 	sjmp	00114$
      00A698                       1002 00528$:
      00A698 BA 08 02         [24] 1003 	cjne	r2,#0x08,00529$
      00A69B 80 03            [24] 1004 	sjmp	00530$
      00A69D                       1005 00529$:
      00A69D 02 AB D5         [24] 1006 	ljmp	00171$
      00A6A0                       1007 00530$:
                                   1008 ;	quantum/via.c:259: goto skip;
      00A6A0                       1009 00114$:
                                   1010 ;	quantum/via.c:263: switch (*command_id) {
      00A6A0 12 38 8C         [24] 1011 	lcall	_ak820_outline_0120
      00A6A3 E0               [24] 1012 	movx	a,@dptr
      00A6A4 FA               [12] 1013 	mov	r2,a
      00A6A5 BA 01 02         [24] 1014 	cjne	r2,#0x01,00531$
      00A6A8 80 6E            [24] 1015 	sjmp	00115$
      00A6AA                       1016 00531$:
      00A6AA BA 02 02         [24] 1017 	cjne	r2,#0x02,00532$
      00A6AD 80 76            [24] 1018 	sjmp	00116$
      00A6AF                       1019 00532$:
      00A6AF BA 03 03         [24] 1020 	cjne	r2,#0x03,00533$
      00A6B2 02 A7 E7         [24] 1021 	ljmp	00125$
      00A6B5                       1022 00533$:
      00A6B5 BA 04 03         [24] 1023 	cjne	r2,#0x04,00534$
      00A6B8 02 A8 7C         [24] 1024 	ljmp	00129$
      00A6BB                       1025 00534$:
      00A6BB BA 05 03         [24] 1026 	cjne	r2,#0x05,00535$
      00A6BE 02 A8 B6         [24] 1027 	ljmp	00130$
      00A6C1                       1028 00535$:
      00A6C1 BA 06 03         [24] 1029 	cjne	r2,#0x06,00536$
      00A6C4 02 A9 22         [24] 1030 	ljmp	00135$
      00A6C7                       1031 00536$:
      00A6C7 BA 07 03         [24] 1032 	cjne	r2,#0x07,00537$
      00A6CA 02 A9 34         [24] 1033 	ljmp	00136$
      00A6CD                       1034 00537$:
      00A6CD BA 08 03         [24] 1035 	cjne	r2,#0x08,00538$
      00A6D0 02 A9 4F         [24] 1036 	ljmp	00137$
      00A6D3                       1037 00538$:
      00A6D3 BA 09 03         [24] 1038 	cjne	r2,#0x09,00539$
      00A6D6 02 A9 6A         [24] 1039 	ljmp	00138$
      00A6D9                       1040 00539$:
      00A6D9 BA 0B 03         [24] 1041 	cjne	r2,#0x0b,00540$
      00A6DC 02 AB 63         [24] 1042 	ljmp	00161$
      00A6DF                       1043 00540$:
      00A6DF BA 0C 03         [24] 1044 	cjne	r2,#0x0c,00541$
      00A6E2 02 A9 85         [24] 1045 	ljmp	00139$
      00A6E5                       1046 00541$:
      00A6E5 BA 0D 03         [24] 1047 	cjne	r2,#0x0d,00542$
      00A6E8 02 A9 A6         [24] 1048 	ljmp	00140$
      00A6EB                       1049 00542$:
      00A6EB BA 0E 03         [24] 1050 	cjne	r2,#0x0e,00543$
      00A6EE 02 A9 CF         [24] 1051 	ljmp	00141$
      00A6F1                       1052 00543$:
      00A6F1 BA 0F 03         [24] 1053 	cjne	r2,#0x0f,00544$
      00A6F4 02 AA 17         [24] 1054 	ljmp	00144$
      00A6F7                       1055 00544$:
      00A6F7 BA 10 03         [24] 1056 	cjne	r2,#0x10,00545$
      00A6FA 02 AA 86         [24] 1057 	ljmp	00151$
      00A6FD                       1058 00545$:
      00A6FD BA 11 03         [24] 1059 	cjne	r2,#0x11,00546$
      00A700 02 AA 9F         [24] 1060 	ljmp	00154$
      00A703                       1061 00546$:
      00A703 BA 12 03         [24] 1062 	cjne	r2,#0x12,00547$
      00A706 02 AA C0         [24] 1063 	ljmp	00155$
      00A709                       1064 00547$:
      00A709 BA 13 03         [24] 1065 	cjne	r2,#0x13,00548$
      00A70C 02 AB 08         [24] 1066 	ljmp	00158$
      00A70F                       1067 00548$:
      00A70F BA FE 03         [24] 1068 	cjne	r2,#0xfe,00549$
      00A712 02 AB A3         [24] 1069 	ljmp	00168$
      00A715                       1070 00549$:
      00A715 02 AB BD         [24] 1071 	ljmp	00169$
                                   1072 ;	quantum/via.c:264: case id_get_protocol_version: {
      00A718                       1073 00115$:
                                   1074 ;	quantum/via.c:265: command_data[0] = VIA_PROTOCOL_VERSION >> 8;
      00A718 12 38 97         [24] 1075 	lcall	_ak820_outline_0126
      00A71B E4               [12] 1076 	clr	a
      00A71C 12 43 0B         [24] 1077 	lcall	_ak820_outline_0031
                                   1078 ;	quantum/via.c:266: command_data[1] = VIA_PROTOCOL_VERSION & 0xFF;
      00A71F 74 09            [12] 1079 	mov	a,#0x09
      00A721 F0               [24] 1080 	movx	@dptr,a
                                   1081 ;	quantum/via.c:267: break;
      00A722 02 AB D5         [24] 1082 	ljmp	00171$
                                   1083 ;	quantum/via.c:269: case id_get_keyboard_value: {
      00A725                       1084 00116$:
                                   1085 ;	quantum/via.c:270: switch (command_data[0]) {
      00A725 12 43 44         [24] 1086 	lcall	_ak820_outline_0096
      00A728 FA               [12] 1087 	mov	r2,a
      00A729 BA 01 02         [24] 1088 	cjne	r2,#0x01,00550$
      00A72C 80 0E            [24] 1089 	sjmp	00117$
      00A72E                       1090 00550$:
      00A72E BA 02 02         [24] 1091 	cjne	r2,#0x02,00551$
      00A731 80 34            [24] 1092 	sjmp	00118$
      00A733                       1093 00551$:
      00A733 BA 03 03         [24] 1094 	cjne	r2,#0x03,00552$
      00A736 02 A7 A2         [24] 1095 	ljmp	00119$
      00A739                       1096 00552$:
      00A739 02 A7 CC         [24] 1097 	ljmp	00123$
                                   1098 ;	quantum/via.c:271: case id_uptime: {
      00A73C                       1099 00117$:
                                   1100 ;	quantum/via.c:272: uint32_t value  = timer_read32();
      00A73C 12 49 05         [24] 1101 	lcall	_timer_read32
      00A73F 85 82 38         [24] 1102 	mov	_raw_hid_receive_sloc0_1_0,dpl
      00A742 85 83 39         [24] 1103 	mov	(_raw_hid_receive_sloc0_1_0 + 1),dph
      00A745 85 F0 3A         [24] 1104 	mov	(_raw_hid_receive_sloc0_1_0 + 2),b
      00A748 F5 3B            [12] 1105 	mov	(_raw_hid_receive_sloc0_1_0 + 3),a
                                   1106 ;	quantum/via.c:273: command_data[1] = (value >> 24) & 0xFF;
      00A74A 12 38 8C         [24] 1107 	lcall	_ak820_outline_0120
      00A74D A3               [24] 1108 	inc	dptr
      00A74E A3               [24] 1109 	inc	dptr
      00A74F E5 3B            [12] 1110 	mov	a,(_raw_hid_receive_sloc0_1_0 + 3)
      00A751 12 43 0B         [24] 1111 	lcall	_ak820_outline_0031
                                   1112 ;	quantum/via.c:274: command_data[2] = (value >> 16) & 0xFF;
      00A754 A3               [24] 1113 	inc	dptr
      00A755 E5 3A            [12] 1114 	mov	a,(_raw_hid_receive_sloc0_1_0 + 2)
      00A757 F0               [24] 1115 	movx	@dptr,a
                                   1116 ;	quantum/via.c:275: command_data[3] = (value >> 8) & 0xFF;
      00A758 12 AC 02         [24] 1117 	lcall	_ak820_outline_0023
      00A75B E5 39            [12] 1118 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00A75D F0               [24] 1119 	movx	@dptr,a
                                   1120 ;	quantum/via.c:276: command_data[4] = value & 0xFF;
      00A75E 12 43 01         [24] 1121 	lcall	_ak820_outline_0011
      00A761 E5 38            [12] 1122 	mov	a,_raw_hid_receive_sloc0_1_0
      00A763 F0               [24] 1123 	movx	@dptr,a
                                   1124 ;	quantum/via.c:277: break;
      00A764 02 AB D5         [24] 1125 	ljmp	00171$
                                   1126 ;	quantum/via.c:279: case id_layout_options: {
      00A767                       1127 00118$:
                                   1128 ;	quantum/via.c:280: uint32_t value  = via_get_layout_options();
      00A767 C0 03            [24] 1129 	push	ar3
      00A769 C0 07            [24] 1130 	push	ar7
      00A76B C0 06            [24] 1131 	push	ar6
      00A76D C0 03            [24] 1132 	push	ar3
      00A76F 12 A5 C5         [24] 1133 	lcall	_via_get_layout_options
      00A772 85 82 38         [24] 1134 	mov	_raw_hid_receive_sloc0_1_0,dpl
      00A775 85 83 39         [24] 1135 	mov	(_raw_hid_receive_sloc0_1_0 + 1),dph
      00A778 85 F0 3A         [24] 1136 	mov	(_raw_hid_receive_sloc0_1_0 + 2),b
      00A77B F5 3B            [12] 1137 	mov	(_raw_hid_receive_sloc0_1_0 + 3),a
      00A77D D0 03            [24] 1138 	pop	ar3
      00A77F D0 06            [24] 1139 	pop	ar6
      00A781 D0 07            [24] 1140 	pop	ar7
                                   1141 ;	quantum/via.c:281: command_data[1] = (value >> 24) & 0xFF;
      00A783 12 38 8C         [24] 1142 	lcall	_ak820_outline_0120
      00A786 A3               [24] 1143 	inc	dptr
      00A787 A3               [24] 1144 	inc	dptr
      00A788 E5 3B            [12] 1145 	mov	a,(_raw_hid_receive_sloc0_1_0 + 3)
      00A78A 12 43 0B         [24] 1146 	lcall	_ak820_outline_0031
                                   1147 ;	quantum/via.c:282: command_data[2] = (value >> 16) & 0xFF;
      00A78D A3               [24] 1148 	inc	dptr
      00A78E E5 3A            [12] 1149 	mov	a,(_raw_hid_receive_sloc0_1_0 + 2)
      00A790 F0               [24] 1150 	movx	@dptr,a
                                   1151 ;	quantum/via.c:283: command_data[3] = (value >> 8) & 0xFF;
      00A791 12 AC 02         [24] 1152 	lcall	_ak820_outline_0023
      00A794 E5 39            [12] 1153 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00A796 F0               [24] 1154 	movx	@dptr,a
                                   1155 ;	quantum/via.c:284: command_data[4] = value & 0xFF;
      00A797 12 43 01         [24] 1156 	lcall	_ak820_outline_0011
      00A79A E5 38            [12] 1157 	mov	a,_raw_hid_receive_sloc0_1_0
      00A79C F0               [24] 1158 	movx	@dptr,a
                                   1159 ;	quantum/via.c:285: break;
      00A79D D0 03            [24] 1160 	pop	ar3
      00A79F 02 AB D5         [24] 1161 	ljmp	00171$
                                   1162 ;	quantum/via.c:287: case id_switch_matrix_state: {
      00A7A2                       1163 00119$:
                                   1164 ;	quantum/via.c:290: if (!vial_unlocked)
      00A7A2 90 0E 24         [24] 1165 	mov	dptr,#_vial_unlocked
      00A7A5 E0               [24] 1166 	movx	a,@dptr
      00A7A6 70 03            [24] 1167 	jnz	00553$
      00A7A8 02 AB D5         [24] 1168 	ljmp	00171$
      00A7AB                       1169 00553$:
                                   1170 ;	quantum/via.c:296: for (uint8_t row = 0; row < MATRIX_ROWS; row++) {
      00A7AB 7A 01            [12] 1171 	mov	r2,#0x01
      00A7AD 79 00            [12] 1172 	mov	r1,#0x00
      00A7AF                       1173 00173$:
      00A7AF B9 10 00         [24] 1174 	cjne	r1,#0x10,00554$
      00A7B2                       1175 00554$:
      00A7B2 40 03            [24] 1176 	jc	00555$
      00A7B4 02 AB D5         [24] 1177 	ljmp	00171$
      00A7B7                       1178 00555$:
                                   1179 ;	quantum/via.c:297: matrix_row_t value = matrix_get_row(row);
      00A7B7 89 82            [24] 1180 	mov	dpl, r1
      00A7B9 12 59 7E         [24] 1181 	lcall	_matrix_get_row
      00A7BC A8 82            [24] 1182 	mov	r0, dpl
                                   1183 ;	quantum/via.c:307: command_data[i++] = value & 0xFF;
      00A7BE EA               [12] 1184 	mov	a,r2
      00A7BF 2C               [12] 1185 	add	a, r4
      00A7C0 F5 82            [12] 1186 	mov	dpl,a
      00A7C2 E4               [12] 1187 	clr	a
      00A7C3 3D               [12] 1188 	addc	a, r5
      00A7C4 F5 83            [12] 1189 	mov	dph,a
      00A7C6 0A               [12] 1190 	inc	r2
      00A7C7 E8               [12] 1191 	mov	a,r0
      00A7C8 F0               [24] 1192 	movx	@dptr,a
                                   1193 ;	quantum/via.c:296: for (uint8_t row = 0; row < MATRIX_ROWS; row++) {
      00A7C9 09               [12] 1194 	inc	r1
                                   1195 ;	quantum/via.c:312: default: {
      00A7CA 80 E3            [24] 1196 	sjmp	00173$
      00A7CC                       1197 00123$:
                                   1198 ;	quantum/via.c:313: raw_hid_receive_kb(data, length);
      00A7CC 12 48 89         [24] 1199 	lcall	_ak820_outline_0076
      00A7CF 90 0C 52         [24] 1200 	mov	dptr,#_raw_hid_receive_kb_PARM_2
      00A7D2 12 AC 0B         [24] 1201 	lcall	_ak820_outline_0041
      00A7D5 C0 07            [24] 1202 	push	ar7
      00A7D7 C0 06            [24] 1203 	push	ar6
      00A7D9 C0 03            [24] 1204 	push	ar3
      00A7DB 12 A6 35         [24] 1205 	lcall	_raw_hid_receive_kb
      00A7DE D0 03            [24] 1206 	pop	ar3
      00A7E0 D0 06            [24] 1207 	pop	ar6
      00A7E2 D0 07            [24] 1208 	pop	ar7
                                   1209 ;	quantum/via.c:317: break;
      00A7E4 02 AB D5         [24] 1210 	ljmp	00171$
                                   1211 ;	quantum/via.c:319: case id_set_keyboard_value: {
      00A7E7                       1212 00125$:
                                   1213 ;	quantum/via.c:320: switch (command_data[0]) {
      00A7E7 12 43 44         [24] 1214 	lcall	_ak820_outline_0096
      00A7EA FA               [12] 1215 	mov	r2,a
      00A7EB BA 02 02         [24] 1216 	cjne	r2,#0x02,00556$
      00A7EE 80 03            [24] 1217 	sjmp	00557$
      00A7F0                       1218 00556$:
      00A7F0 02 A8 61         [24] 1219 	ljmp	00127$
      00A7F3                       1220 00557$:
                                   1221 ;	quantum/via.c:322: uint32_t value = ((uint32_t)command_data[1] << 24) | ((uint32_t)command_data[2] << 16) | ((uint32_t)command_data[3] << 8) | (uint32_t)command_data[4];
      00A7F3 C0 03            [24] 1222 	push	ar3
      00A7F5 12 38 39         [24] 1223 	lcall	_ak820_outline_0037
      00A7F8 F8               [12] 1224 	mov	r0,a
      00A7F9 79 00            [12] 1225 	mov	r1,#0x00
      00A7FB 7B 00            [12] 1226 	mov	r3,#0x00
      00A7FD 88 3B            [24] 1227 	mov	(_raw_hid_receive_sloc0_1_0 + 3),r0
      00A7FF 8B 38            [24] 1228 	mov	_raw_hid_receive_sloc0_1_0,r3
      00A801 8B 39            [24] 1229 	mov	(_raw_hid_receive_sloc0_1_0 + 1),r3
      00A803 8B 3A            [24] 1230 	mov	(_raw_hid_receive_sloc0_1_0 + 2),r3
      00A805 12 AB F9         [24] 1231 	lcall	_ak820_outline_0018
      00A808 F8               [12] 1232 	mov	r0,a
      00A809 89 03            [24] 1233 	mov	ar3,r1
      00A80B 88 02            [24] 1234 	mov	ar2,r0
      00A80D E4               [12] 1235 	clr	a
      00A80E 42 38            [12] 1236 	orl	_raw_hid_receive_sloc0_1_0,a
      00A810 E9               [12] 1237 	mov	a,r1
      00A811 42 39            [12] 1238 	orl	(_raw_hid_receive_sloc0_1_0 + 1),a
      00A813 EA               [12] 1239 	mov	a,r2
      00A814 42 3A            [12] 1240 	orl	(_raw_hid_receive_sloc0_1_0 + 2),a
      00A816 EB               [12] 1241 	mov	a,r3
      00A817 42 3B            [12] 1242 	orl	(_raw_hid_receive_sloc0_1_0 + 3),a
      00A819 12 AC 02         [24] 1243 	lcall	_ak820_outline_0023
      00A81C E0               [24] 1244 	movx	a,@dptr
      00A81D F8               [12] 1245 	mov	r0,a
      00A81E 79 00            [12] 1246 	mov	r1,#0x00
      00A820 7A 00            [12] 1247 	mov	r2,#0x00
      00A822 8A 03            [24] 1248 	mov	ar3,r2
      00A824 89 02            [24] 1249 	mov	ar2,r1
      00A826 88 01            [24] 1250 	mov	ar1,r0
      00A828 E4               [12] 1251 	clr	a
      00A829 42 38            [12] 1252 	orl	_raw_hid_receive_sloc0_1_0,a
      00A82B E9               [12] 1253 	mov	a,r1
      00A82C 42 39            [12] 1254 	orl	(_raw_hid_receive_sloc0_1_0 + 1),a
      00A82E EA               [12] 1255 	mov	a,r2
      00A82F 42 3A            [12] 1256 	orl	(_raw_hid_receive_sloc0_1_0 + 2),a
      00A831 EB               [12] 1257 	mov	a,r3
      00A832 42 3B            [12] 1258 	orl	(_raw_hid_receive_sloc0_1_0 + 3),a
      00A834 12 43 01         [24] 1259 	lcall	_ak820_outline_0011
      00A837 E0               [24] 1260 	movx	a,@dptr
      00A838 F8               [12] 1261 	mov	r0,a
      00A839 E4               [12] 1262 	clr	a
      00A83A F9               [12] 1263 	mov	r1,a
      00A83B FA               [12] 1264 	mov	r2,a
      00A83C FB               [12] 1265 	mov	r3,a
      00A83D E5 39            [12] 1266 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00A83F 42 01            [12] 1267 	orl	ar1,a
      00A841 E5 3A            [12] 1268 	mov	a,(_raw_hid_receive_sloc0_1_0 + 2)
      00A843 42 02            [12] 1269 	orl	ar2,a
      00A845 E5 3B            [12] 1270 	mov	a,(_raw_hid_receive_sloc0_1_0 + 3)
      00A847 42 03            [12] 1271 	orl	ar3,a
                                   1272 ;	quantum/via.c:323: via_set_layout_options(value);
      00A849 12 48 B2         [24] 1273 	lcall	_ak820_outline_0114
      00A84C EB               [12] 1274 	mov	a, r3
      00A84D C0 07            [24] 1275 	push	ar7
      00A84F C0 06            [24] 1276 	push	ar6
      00A851 C0 03            [24] 1277 	push	ar3
      00A853 12 A5 DE         [24] 1278 	lcall	_via_set_layout_options
      00A856 D0 03            [24] 1279 	pop	ar3
      00A858 D0 06            [24] 1280 	pop	ar6
      00A85A D0 07            [24] 1281 	pop	ar7
                                   1282 ;	quantum/via.c:324: break;
      00A85C D0 03            [24] 1283 	pop	ar3
      00A85E 02 AB D5         [24] 1284 	ljmp	00171$
                                   1285 ;	quantum/via.c:326: default: {
      00A861                       1286 00127$:
                                   1287 ;	quantum/via.c:327: raw_hid_receive_kb(data, length);
      00A861 12 48 89         [24] 1288 	lcall	_ak820_outline_0076
      00A864 90 0C 52         [24] 1289 	mov	dptr,#_raw_hid_receive_kb_PARM_2
      00A867 12 AC 0B         [24] 1290 	lcall	_ak820_outline_0041
      00A86A C0 07            [24] 1291 	push	ar7
      00A86C C0 06            [24] 1292 	push	ar6
      00A86E C0 03            [24] 1293 	push	ar3
      00A870 12 A6 35         [24] 1294 	lcall	_raw_hid_receive_kb
      00A873 D0 03            [24] 1295 	pop	ar3
      00A875 D0 06            [24] 1296 	pop	ar6
      00A877 D0 07            [24] 1297 	pop	ar7
                                   1298 ;	quantum/via.c:331: break;
      00A879 02 AB D5         [24] 1299 	ljmp	00171$
                                   1300 ;	quantum/via.c:333: case id_dynamic_keymap_get_keycode: {
      00A87C                       1301 00129$:
                                   1302 ;	quantum/via.c:334: uint16_t keycode = dynamic_keymap_get_keycode(command_data[0], command_data[1], command_data[2]);
      00A87C 12 43 44         [24] 1303 	lcall	_ak820_outline_0096
      00A87F FA               [12] 1304 	mov	r2,a
      00A880 12 38 39         [24] 1305 	lcall	_ak820_outline_0037
      00A883 F9               [12] 1306 	mov	r1,a
      00A884 12 AB F9         [24] 1307 	lcall	_ak820_outline_0018
      00A887 F8               [12] 1308 	mov	r0,a
      00A888 90 0A DF         [24] 1309 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      00A88B E9               [12] 1310 	mov	a,r1
      00A88C F0               [24] 1311 	movx	@dptr,a
      00A88D 90 0A E0         [24] 1312 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      00A890 E8               [12] 1313 	mov	a,r0
      00A891 F0               [24] 1314 	movx	@dptr,a
      00A892 8A 82            [24] 1315 	mov	dpl, r2
      00A894 C0 07            [24] 1316 	push	ar7
      00A896 C0 06            [24] 1317 	push	ar6
      00A898 C0 03            [24] 1318 	push	ar3
      00A89A 12 83 AB         [24] 1319 	lcall	_dynamic_keymap_get_keycode
      00A89D A9 82            [24] 1320 	mov	r1, dpl
      00A89F AA 83            [24] 1321 	mov	r2, dph
      00A8A1 D0 03            [24] 1322 	pop	ar3
      00A8A3 D0 06            [24] 1323 	pop	ar6
      00A8A5 D0 07            [24] 1324 	pop	ar7
                                   1325 ;	quantum/via.c:335: command_data[3]  = keycode >> 8;
      00A8A7 12 AC 02         [24] 1326 	lcall	_ak820_outline_0023
      00A8AA 8A 00            [24] 1327 	mov	ar0,r2
      00A8AC E8               [12] 1328 	mov	a,r0
      00A8AD F0               [24] 1329 	movx	@dptr,a
                                   1330 ;	quantum/via.c:336: command_data[4]  = keycode & 0xFF;
      00A8AE 12 43 01         [24] 1331 	lcall	_ak820_outline_0011
      00A8B1 E9               [12] 1332 	mov	a,r1
      00A8B2 F0               [24] 1333 	movx	@dptr,a
                                   1334 ;	quantum/via.c:337: break;
      00A8B3 02 AB D5         [24] 1335 	ljmp	00171$
                                   1336 ;	quantum/via.c:339: case id_dynamic_keymap_set_keycode: {
      00A8B6                       1337 00130$:
                                   1338 ;	quantum/via.c:343: if (!vial_unlocked && command_data[3] == (QK_BOOT >> 8) && command_data[4] == (QK_BOOT & 0xFF)) {
      00A8B6 90 0E 24         [24] 1339 	mov	dptr,#_vial_unlocked
      00A8B9 E0               [24] 1340 	movx	a,@dptr
      00A8BA 70 19            [24] 1341 	jnz	00132$
      00A8BC 12 AC 02         [24] 1342 	lcall	_ak820_outline_0023
      00A8BF E0               [24] 1343 	movx	a,@dptr
      00A8C0 FA               [12] 1344 	mov	r2,a
      00A8C1 BA 7C 11         [24] 1345 	cjne	r2,#0x7c,00132$
      00A8C4 74 05            [12] 1346 	mov	a,#0x05
      00A8C6 2E               [12] 1347 	add	a, r6
      00A8C7 12 38 27         [24] 1348 	lcall	_ak820_outline_0017
      00A8CA 70 09            [24] 1349 	jnz	00132$
                                   1350 ;	quantum/via.c:344: *command_id = id_unhandled;
      00A8CC 12 38 8C         [24] 1351 	lcall	_ak820_outline_0120
      00A8CF 74 FF            [12] 1352 	mov	a,#0xff
      00A8D1 F0               [24] 1353 	movx	@dptr,a
                                   1354 ;	quantum/via.c:345: break;
      00A8D2 02 AB D5         [24] 1355 	ljmp	00171$
      00A8D5                       1356 00132$:
                                   1357 ;	quantum/via.c:348: dynamic_keymap_set_keycode(command_data[0], command_data[1], command_data[2], (command_data[3] << 8) | command_data[4]);
      00A8D5 C0 03            [24] 1358 	push	ar3
      00A8D7 12 43 44         [24] 1359 	lcall	_ak820_outline_0096
      00A8DA F5 3D            [12] 1360 	mov	_raw_hid_receive_sloc2_1_0,a
      00A8DC 12 38 39         [24] 1361 	lcall	_ak820_outline_0037
      00A8DF F5 3C            [12] 1362 	mov	_raw_hid_receive_sloc1_1_0,a
      00A8E1 12 AB F9         [24] 1363 	lcall	_ak820_outline_0018
      00A8E4 F5 38            [12] 1364 	mov	_raw_hid_receive_sloc0_1_0,a
      00A8E6 12 AC 02         [24] 1365 	lcall	_ak820_outline_0023
      00A8E9 E0               [24] 1366 	movx	a,@dptr
      00A8EA FB               [12] 1367 	mov	r3,a
      00A8EB 78 00            [12] 1368 	mov	r0,#0x00
      00A8ED 12 43 01         [24] 1369 	lcall	_ak820_outline_0011
      00A8F0 E0               [24] 1370 	movx	a,@dptr
      00A8F1 7A 00            [12] 1371 	mov	r2,#0x00
      00A8F3 42 00            [12] 1372 	orl	ar0,a
      00A8F5 EA               [12] 1373 	mov	a,r2
      00A8F6 42 03            [12] 1374 	orl	ar3,a
      00A8F8 90 0A E2         [24] 1375 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      00A8FB E5 3C            [12] 1376 	mov	a,_raw_hid_receive_sloc1_1_0
      00A8FD F0               [24] 1377 	movx	@dptr,a
      00A8FE 90 0A E3         [24] 1378 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      00A901 E5 38            [12] 1379 	mov	a,_raw_hid_receive_sloc0_1_0
      00A903 F0               [24] 1380 	movx	@dptr,a
      00A904 90 0A E4         [24] 1381 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      00A907 E8               [12] 1382 	mov	a,r0
      00A908 12 77 30         [24] 1383 	lcall	_ak820_outline_0189
      00A90B 85 3D 82         [24] 1384 	mov	dpl, _raw_hid_receive_sloc2_1_0
      00A90E C0 07            [24] 1385 	push	ar7
      00A910 C0 06            [24] 1386 	push	ar6
      00A912 C0 03            [24] 1387 	push	ar3
      00A914 12 83 F9         [24] 1388 	lcall	_dynamic_keymap_set_keycode
      00A917 D0 03            [24] 1389 	pop	ar3
      00A919 D0 06            [24] 1390 	pop	ar6
      00A91B D0 07            [24] 1391 	pop	ar7
                                   1392 ;	quantum/via.c:349: break;
      00A91D D0 03            [24] 1393 	pop	ar3
      00A91F 02 AB D5         [24] 1394 	ljmp	00171$
                                   1395 ;	quantum/via.c:351: case id_dynamic_keymap_reset: {
      00A922                       1396 00135$:
                                   1397 ;	quantum/via.c:352: dynamic_keymap_reset();
      00A922 C0 07            [24] 1398 	push	ar7
      00A924 C0 06            [24] 1399 	push	ar6
      00A926 C0 03            [24] 1400 	push	ar3
      00A928 12 86 80         [24] 1401 	lcall	_dynamic_keymap_reset
      00A92B D0 03            [24] 1402 	pop	ar3
      00A92D D0 06            [24] 1403 	pop	ar6
      00A92F D0 07            [24] 1404 	pop	ar7
                                   1405 ;	quantum/via.c:353: break;
      00A931 02 AB D5         [24] 1406 	ljmp	00171$
                                   1407 ;	quantum/via.c:355: case id_lighting_set_value: {
      00A934                       1408 00136$:
                                   1409 ;	quantum/via.c:363: vialrgb_set_value(data, length);
      00A934 12 48 89         [24] 1410 	lcall	_ak820_outline_0076
      00A937 90 0D 9D         [24] 1411 	mov	dptr,#_vialrgb_set_value_PARM_2
      00A93A 12 AC 0B         [24] 1412 	lcall	_ak820_outline_0041
      00A93D C0 07            [24] 1413 	push	ar7
      00A93F C0 06            [24] 1414 	push	ar6
      00A941 C0 03            [24] 1415 	push	ar3
      00A943 12 B6 21         [24] 1416 	lcall	_vialrgb_set_value
      00A946 D0 03            [24] 1417 	pop	ar3
      00A948 D0 06            [24] 1418 	pop	ar6
      00A94A D0 07            [24] 1419 	pop	ar7
                                   1420 ;	quantum/via.c:375: break;
      00A94C 02 AB D5         [24] 1421 	ljmp	00171$
                                   1422 ;	quantum/via.c:377: case id_lighting_get_value: {
      00A94F                       1423 00137$:
                                   1424 ;	quantum/via.c:385: vialrgb_get_value(data, length);
      00A94F 12 48 89         [24] 1425 	lcall	_ak820_outline_0076
      00A952 90 0D 99         [24] 1426 	mov	dptr,#_vialrgb_get_value_PARM_2
      00A955 12 AC 0B         [24] 1427 	lcall	_ak820_outline_0041
      00A958 C0 07            [24] 1428 	push	ar7
      00A95A C0 06            [24] 1429 	push	ar6
      00A95C C0 03            [24] 1430 	push	ar3
      00A95E 12 B4 B6         [24] 1431 	lcall	_vialrgb_get_value
      00A961 D0 03            [24] 1432 	pop	ar3
      00A963 D0 06            [24] 1433 	pop	ar6
      00A965 D0 07            [24] 1434 	pop	ar7
                                   1435 ;	quantum/via.c:397: break;
      00A967 02 AB D5         [24] 1436 	ljmp	00171$
                                   1437 ;	quantum/via.c:399: case id_lighting_save: {
      00A96A                       1438 00138$:
                                   1439 ;	quantum/via.c:407: vialrgb_save(data, length);
      00A96A 12 48 89         [24] 1440 	lcall	_ak820_outline_0076
      00A96D 90 0D A1         [24] 1441 	mov	dptr,#_vialrgb_save_PARM_2
      00A970 12 AC 0B         [24] 1442 	lcall	_ak820_outline_0041
      00A973 C0 07            [24] 1443 	push	ar7
      00A975 C0 06            [24] 1444 	push	ar6
      00A977 C0 03            [24] 1445 	push	ar3
      00A979 12 B6 AF         [24] 1446 	lcall	_vialrgb_save
      00A97C D0 03            [24] 1447 	pop	ar3
      00A97E D0 06            [24] 1448 	pop	ar6
      00A980 D0 07            [24] 1449 	pop	ar7
                                   1450 ;	quantum/via.c:419: break;
      00A982 02 AB D5         [24] 1451 	ljmp	00171$
                                   1452 ;	quantum/via.c:428: case id_dynamic_keymap_macro_get_count: {
      00A985                       1453 00139$:
                                   1454 ;	quantum/via.c:429: command_data[0] = dynamic_keymap_macro_get_count();
      00A985 C0 07            [24] 1455 	push	ar7
      00A987 C0 06            [24] 1456 	push	ar6
      00A989 C0 05            [24] 1457 	push	ar5
      00A98B C0 04            [24] 1458 	push	ar4
      00A98D C0 03            [24] 1459 	push	ar3
      00A98F 12 8A 6F         [24] 1460 	lcall	_dynamic_keymap_macro_get_count
      00A992 AA 82            [24] 1461 	mov	r2, dpl
      00A994 D0 03            [24] 1462 	pop	ar3
      00A996 D0 04            [24] 1463 	pop	ar4
      00A998 D0 05            [24] 1464 	pop	ar5
      00A99A D0 06            [24] 1465 	pop	ar6
      00A99C D0 07            [24] 1466 	pop	ar7
      00A99E 12 38 97         [24] 1467 	lcall	_ak820_outline_0126
      00A9A1 EA               [12] 1468 	mov	a,r2
      00A9A2 F0               [24] 1469 	movx	@dptr,a
                                   1470 ;	quantum/via.c:430: break;
      00A9A3 02 AB D5         [24] 1471 	ljmp	00171$
                                   1472 ;	quantum/via.c:432: case id_dynamic_keymap_macro_get_buffer_size: {
      00A9A6                       1473 00140$:
                                   1474 ;	quantum/via.c:433: uint16_t size   = dynamic_keymap_macro_get_buffer_size();
      00A9A6 C0 07            [24] 1475 	push	ar7
      00A9A8 C0 06            [24] 1476 	push	ar6
      00A9AA C0 05            [24] 1477 	push	ar5
      00A9AC C0 04            [24] 1478 	push	ar4
      00A9AE C0 03            [24] 1479 	push	ar3
      00A9B0 12 8A 73         [24] 1480 	lcall	_dynamic_keymap_macro_get_buffer_size
      00A9B3 A9 82            [24] 1481 	mov	r1, dpl
      00A9B5 AA 83            [24] 1482 	mov	r2, dph
      00A9B7 D0 03            [24] 1483 	pop	ar3
      00A9B9 D0 04            [24] 1484 	pop	ar4
      00A9BB D0 05            [24] 1485 	pop	ar5
      00A9BD D0 06            [24] 1486 	pop	ar6
      00A9BF D0 07            [24] 1487 	pop	ar7
                                   1488 ;	quantum/via.c:434: command_data[0] = size >> 8;
      00A9C1 8A 00            [24] 1489 	mov	ar0,r2
      00A9C3 12 38 97         [24] 1490 	lcall	_ak820_outline_0126
      00A9C6 E8               [12] 1491 	mov	a,r0
      00A9C7 12 43 0B         [24] 1492 	lcall	_ak820_outline_0031
                                   1493 ;	quantum/via.c:435: command_data[1] = size & 0xFF;
      00A9CA E9               [12] 1494 	mov	a,r1
      00A9CB F0               [24] 1495 	movx	@dptr,a
                                   1496 ;	quantum/via.c:436: break;
      00A9CC 02 AB D5         [24] 1497 	ljmp	00171$
                                   1498 ;	quantum/via.c:438: case id_dynamic_keymap_macro_get_buffer: {
      00A9CF                       1499 00141$:
                                   1500 ;	quantum/via.c:439: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00A9CF C0 03            [24] 1501 	push	ar3
      00A9D1 12 AB E2         [24] 1502 	lcall	_ak820_outline_0003
      00A9D4 89 38            [24] 1503 	mov	_raw_hid_receive_sloc0_1_0,r1
      00A9D6 8A 39            [24] 1504 	mov	(_raw_hid_receive_sloc0_1_0 + 1),r2
                                   1505 ;	quantum/via.c:440: uint16_t size   = command_data[2]; // size <= 28
      00A9D8 12 AB F9         [24] 1506 	lcall	_ak820_outline_0018
      00A9DB FB               [12] 1507 	mov	r3,a
                                   1508 ;	quantum/via.c:441: if (size <= 28)
      00A9DC 8B 3E            [24] 1509 	mov	_raw_hid_receive_sloc3_1_0,r3
      00A9DE 75 3F 00         [24] 1510 	mov	(_raw_hid_receive_sloc3_1_0 + 1),#0x00
      00A9E1 C3               [12] 1511 	clr	c
      00A9E2 74 1C            [12] 1512 	mov	a,#0x1c
      00A9E4 9B               [12] 1513 	subb	a,r3
      00A9E5 D0 03            [24] 1514 	pop	ar3
      00A9E7 50 03            [24] 1515 	jnc	00562$
      00A9E9 02 AB D5         [24] 1516 	ljmp	00171$
      00A9EC                       1517 00562$:
                                   1518 ;	free result
                                   1519 ;	quantum/via.c:442: dynamic_keymap_macro_get_buffer(offset, size, &command_data[3]);
      00A9EC 12 AC 14         [24] 1520 	lcall	_ak820_outline_0069
      00A9EF 90 0B 31         [24] 1521 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_2
      00A9F2 E5 3E            [12] 1522 	mov	a,_raw_hid_receive_sloc3_1_0
      00A9F4 F0               [24] 1523 	movx	@dptr,a
      00A9F5 E5 3F            [12] 1524 	mov	a,(_raw_hid_receive_sloc3_1_0 + 1)
      00A9F7 A3               [24] 1525 	inc	dptr
      00A9F8 F0               [24] 1526 	movx	@dptr,a
      00A9F9 90 0B 33         [24] 1527 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_3
      00A9FC 12 AC 1E         [24] 1528 	lcall	_ak820_outline_0088
      00A9FF 85 38 82         [24] 1529 	mov	dpl, _raw_hid_receive_sloc0_1_0
      00AA02 85 39 83         [24] 1530 	mov	dph, (_raw_hid_receive_sloc0_1_0 + 1)
      00AA05 C0 07            [24] 1531 	push	ar7
      00AA07 C0 06            [24] 1532 	push	ar6
      00AA09 C0 03            [24] 1533 	push	ar3
      00AA0B 12 8A 77         [24] 1534 	lcall	_dynamic_keymap_macro_get_buffer
      00AA0E D0 03            [24] 1535 	pop	ar3
      00AA10 D0 06            [24] 1536 	pop	ar6
      00AA12 D0 07            [24] 1537 	pop	ar7
                                   1538 ;	quantum/via.c:443: break;
      00AA14 02 AB D5         [24] 1539 	ljmp	00171$
                                   1540 ;	quantum/via.c:445: case id_dynamic_keymap_macro_set_buffer: {
      00AA17                       1541 00144$:
                                   1542 ;	quantum/via.c:448: if (!vial_unlocked) {
      00AA17 90 0E 24         [24] 1543 	mov	dptr,#_vial_unlocked
      00AA1A E0               [24] 1544 	movx	a,@dptr
      00AA1B 70 01            [24] 1545 	jnz	00146$
                                   1546 ;	quantum/via.c:450: return;
      00AA1D 22               [24] 1547 	ret
      00AA1E                       1548 00146$:
                                   1549 ;	quantum/via.c:456: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00AA1E C0 03            [24] 1550 	push	ar3
      00AA20 12 AB E2         [24] 1551 	lcall	_ak820_outline_0003
      00AA23 89 3E            [24] 1552 	mov	_raw_hid_receive_sloc3_1_0,r1
      00AA25 8A 3F            [24] 1553 	mov	(_raw_hid_receive_sloc3_1_0 + 1),r2
                                   1554 ;	quantum/via.c:457: uint16_t size   = command_data[2]; // size <= 28
      00AA27 12 AB F9         [24] 1555 	lcall	_ak820_outline_0018
      00AA2A F5 38            [12] 1556 	mov	_raw_hid_receive_sloc0_1_0, a
      00AA2C 75 39 00         [24] 1557 	mov	(_raw_hid_receive_sloc0_1_0 + 1),#0x00
                                   1558 ;	quantum/via.c:461: if (size > 28 || size > length - 4 || !dynamic_keymap_macro_set_buffer(offset, size, &command_data[3])) return;
      00AA2F 85 38 40         [24] 1559 	mov	_raw_hid_receive_sloc4_1_0,_raw_hid_receive_sloc0_1_0
      00AA32 85 39 41         [24] 1560 	mov	(_raw_hid_receive_sloc4_1_0 + 1),(_raw_hid_receive_sloc0_1_0 + 1)
      00AA35 C3               [12] 1561 	clr	c
      00AA36 74 1C            [12] 1562 	mov	a,#0x1c
      00AA38 95 40            [12] 1563 	subb	a,_raw_hid_receive_sloc4_1_0
      00AA3A E4               [12] 1564 	clr	a
      00AA3B 95 41            [12] 1565 	subb	a,(_raw_hid_receive_sloc4_1_0 + 1)
      00AA3D D0 03            [24] 1566 	pop	ar3
      00AA3F 40 44            [24] 1567 	jc	00147$
                                   1568 ;	free result
      00AA41 8B 01            [24] 1569 	mov	ar1,r3
      00AA43 7A 00            [12] 1570 	mov	r2,#0x00
      00AA45 E9               [12] 1571 	mov	a,r1
      00AA46 24 FC            [12] 1572 	add	a,#0xfc
      00AA48 F9               [12] 1573 	mov	r1,a
      00AA49 EA               [12] 1574 	mov	a,r2
      00AA4A 34 FF            [12] 1575 	addc	a,#0xff
      00AA4C FA               [12] 1576 	mov	r2,a
      00AA4D C3               [12] 1577 	clr	c
      00AA4E E9               [12] 1578 	mov	a,r1
      00AA4F 95 40            [12] 1579 	subb	a,_raw_hid_receive_sloc4_1_0
      00AA51 EA               [12] 1580 	mov	a,r2
      00AA52 95 41            [12] 1581 	subb	a,(_raw_hid_receive_sloc4_1_0 + 1)
      00AA54 40 2F            [24] 1582 	jc	00147$
                                   1583 ;	free result
      00AA56 12 AC 14         [24] 1584 	lcall	_ak820_outline_0069
      00AA59 90 0B 38         [24] 1585 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_2
      00AA5C E5 38            [12] 1586 	mov	a,_raw_hid_receive_sloc0_1_0
      00AA5E F0               [24] 1587 	movx	@dptr,a
      00AA5F E5 39            [12] 1588 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00AA61 A3               [24] 1589 	inc	dptr
      00AA62 F0               [24] 1590 	movx	@dptr,a
      00AA63 90 0B 3A         [24] 1591 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_3
      00AA66 12 AC 1E         [24] 1592 	lcall	_ak820_outline_0088
      00AA69 85 3E 82         [24] 1593 	mov	dpl, _raw_hid_receive_sloc3_1_0
      00AA6C 85 3F 83         [24] 1594 	mov	dph, (_raw_hid_receive_sloc3_1_0 + 1)
      00AA6F C0 07            [24] 1595 	push	ar7
      00AA71 C0 06            [24] 1596 	push	ar6
      00AA73 C0 03            [24] 1597 	push	ar3
      00AA75 12 8A C5         [24] 1598 	lcall	_dynamic_keymap_macro_set_buffer
      00AA78 E5 82            [12] 1599 	mov	a, dpl
      00AA7A D0 03            [24] 1600 	pop	ar3
      00AA7C D0 06            [24] 1601 	pop	ar6
      00AA7E D0 07            [24] 1602 	pop	ar7
      00AA80 60 03            [24] 1603 	jz	00566$
      00AA82 02 AB D5         [24] 1604 	ljmp	00171$
      00AA85                       1605 00566$:
      00AA85                       1606 00147$:
      00AA85 22               [24] 1607 	ret
                                   1608 ;	quantum/via.c:468: case id_dynamic_keymap_macro_reset: {
      00AA86                       1609 00151$:
                                   1610 ;	quantum/via.c:470: if (!vial_unlocked) return;
      00AA86 90 0E 24         [24] 1611 	mov	dptr,#_vial_unlocked
      00AA89 E0               [24] 1612 	movx	a,@dptr
      00AA8A 70 01            [24] 1613 	jnz	00153$
      00AA8C 22               [24] 1614 	ret
      00AA8D                       1615 00153$:
                                   1616 ;	quantum/via.c:472: dynamic_keymap_macro_reset();
      00AA8D C0 07            [24] 1617 	push	ar7
      00AA8F C0 06            [24] 1618 	push	ar6
      00AA91 C0 03            [24] 1619 	push	ar3
      00AA93 12 8A F3         [24] 1620 	lcall	_dynamic_keymap_macro_reset
      00AA96 D0 03            [24] 1621 	pop	ar3
      00AA98 D0 06            [24] 1622 	pop	ar6
      00AA9A D0 07            [24] 1623 	pop	ar7
                                   1624 ;	quantum/via.c:473: break;
      00AA9C 02 AB D5         [24] 1625 	ljmp	00171$
                                   1626 ;	quantum/via.c:475: case id_dynamic_keymap_get_layer_count: {
      00AA9F                       1627 00154$:
                                   1628 ;	quantum/via.c:476: command_data[0] = dynamic_keymap_get_layer_count();
      00AA9F C0 07            [24] 1629 	push	ar7
      00AAA1 C0 06            [24] 1630 	push	ar6
      00AAA3 C0 05            [24] 1631 	push	ar5
      00AAA5 C0 04            [24] 1632 	push	ar4
      00AAA7 C0 03            [24] 1633 	push	ar3
      00AAA9 12 83 72         [24] 1634 	lcall	_dynamic_keymap_get_layer_count
      00AAAC AA 82            [24] 1635 	mov	r2, dpl
      00AAAE D0 03            [24] 1636 	pop	ar3
      00AAB0 D0 04            [24] 1637 	pop	ar4
      00AAB2 D0 05            [24] 1638 	pop	ar5
      00AAB4 D0 06            [24] 1639 	pop	ar6
      00AAB6 D0 07            [24] 1640 	pop	ar7
      00AAB8 12 38 97         [24] 1641 	lcall	_ak820_outline_0126
      00AABB EA               [12] 1642 	mov	a,r2
      00AABC F0               [24] 1643 	movx	@dptr,a
                                   1644 ;	quantum/via.c:477: break;
      00AABD 02 AB D5         [24] 1645 	ljmp	00171$
                                   1646 ;	quantum/via.c:479: case id_dynamic_keymap_get_buffer: {
      00AAC0                       1647 00155$:
                                   1648 ;	quantum/via.c:480: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00AAC0 C0 03            [24] 1649 	push	ar3
      00AAC2 12 AB E2         [24] 1650 	lcall	_ak820_outline_0003
      00AAC5 89 40            [24] 1651 	mov	_raw_hid_receive_sloc4_1_0,r1
      00AAC7 8A 41            [24] 1652 	mov	(_raw_hid_receive_sloc4_1_0 + 1),r2
                                   1653 ;	quantum/via.c:481: uint16_t size   = command_data[2]; // size <= 28
      00AAC9 12 AB F9         [24] 1654 	lcall	_ak820_outline_0018
      00AACC FB               [12] 1655 	mov	r3,a
                                   1656 ;	quantum/via.c:482: if (size <= 28)
      00AACD 8B 3E            [24] 1657 	mov	_raw_hid_receive_sloc3_1_0,r3
      00AACF 75 3F 00         [24] 1658 	mov	(_raw_hid_receive_sloc3_1_0 + 1),#0x00
      00AAD2 C3               [12] 1659 	clr	c
      00AAD3 74 1C            [12] 1660 	mov	a,#0x1c
      00AAD5 9B               [12] 1661 	subb	a,r3
      00AAD6 D0 03            [24] 1662 	pop	ar3
      00AAD8 50 03            [24] 1663 	jnc	00568$
      00AADA 02 AB D5         [24] 1664 	ljmp	00171$
      00AADD                       1665 00568$:
                                   1666 ;	free result
                                   1667 ;	quantum/via.c:483: dynamic_keymap_get_buffer(offset, size, &command_data[3]);
      00AADD 12 AC 14         [24] 1668 	lcall	_ak820_outline_0069
      00AAE0 90 0B 1A         [24] 1669 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_2
      00AAE3 E5 3E            [12] 1670 	mov	a,_raw_hid_receive_sloc3_1_0
      00AAE5 F0               [24] 1671 	movx	@dptr,a
      00AAE6 E5 3F            [12] 1672 	mov	a,(_raw_hid_receive_sloc3_1_0 + 1)
      00AAE8 A3               [24] 1673 	inc	dptr
      00AAE9 F0               [24] 1674 	movx	@dptr,a
      00AAEA 90 0B 1C         [24] 1675 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_3
      00AAED 12 AC 1E         [24] 1676 	lcall	_ak820_outline_0088
      00AAF0 85 40 82         [24] 1677 	mov	dpl, _raw_hid_receive_sloc4_1_0
      00AAF3 85 41 83         [24] 1678 	mov	dph, (_raw_hid_receive_sloc4_1_0 + 1)
      00AAF6 C0 07            [24] 1679 	push	ar7
      00AAF8 C0 06            [24] 1680 	push	ar6
      00AAFA C0 03            [24] 1681 	push	ar3
      00AAFC 12 88 3F         [24] 1682 	lcall	_dynamic_keymap_get_buffer
      00AAFF D0 03            [24] 1683 	pop	ar3
      00AB01 D0 06            [24] 1684 	pop	ar6
      00AB03 D0 07            [24] 1685 	pop	ar7
                                   1686 ;	quantum/via.c:484: break;
      00AB05 02 AB D5         [24] 1687 	ljmp	00171$
                                   1688 ;	quantum/via.c:486: case id_dynamic_keymap_set_buffer: {
      00AB08                       1689 00158$:
                                   1690 ;	quantum/via.c:487: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00AB08 12 43 44         [24] 1691 	lcall	_ak820_outline_0096
      00AB0B FD               [12] 1692 	mov	r5,a
      00AB0C 7C 00            [12] 1693 	mov	r4,#0x00
      00AB0E 12 38 39         [24] 1694 	lcall	_ak820_outline_0037
      00AB11 7A 00            [12] 1695 	mov	r2,#0x00
      00AB13 42 04            [12] 1696 	orl	ar4,a
      00AB15 EA               [12] 1697 	mov	a,r2
      00AB16 42 05            [12] 1698 	orl	ar5,a
      00AB18 8C 40            [24] 1699 	mov	_raw_hid_receive_sloc4_1_0,r4
      00AB1A 8D 41            [24] 1700 	mov	(_raw_hid_receive_sloc4_1_0 + 1),r5
                                   1701 ;	quantum/via.c:488: uint16_t size   = command_data[2]; // size <= 28
      00AB1C 12 AB F9         [24] 1702 	lcall	_ak820_outline_0018
      00AB1F F9               [12] 1703 	mov	r1,a
      00AB20 7A 00            [12] 1704 	mov	r2,#0x00
                                   1705 ;	quantum/via.c:489: if (size <= 28)
      00AB22 89 00            [24] 1706 	mov	ar0,r1
      00AB24 E8               [12] 1707 	mov	a,r0
      00AB25 24 E3            [12] 1708 	add	a,#0xff - 0x1c
      00AB27 50 03            [24] 1709 	jnc	00569$
      00AB29 02 AB D5         [24] 1710 	ljmp	00171$
      00AB2C                       1711 00569$:
                                   1712 ;	free result
                                   1713 ;	quantum/via.c:490: dynamic_keymap_set_buffer(offset, size, &command_data[3]);
      00AB2C C0 03            [24] 1714 	push	ar3
      00AB2E 74 04            [12] 1715 	mov	a,#0x04
      00AB30 2E               [12] 1716 	add	a, r6
      00AB31 F8               [12] 1717 	mov	r0,a
      00AB32 E4               [12] 1718 	clr	a
      00AB33 3F               [12] 1719 	addc	a, r7
      00AB34 FB               [12] 1720 	mov	r3,a
      00AB35 7D 00            [12] 1721 	mov	r5,#0x00
      00AB37 90 0B 21         [24] 1722 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_2
      00AB3A E9               [12] 1723 	mov	a,r1
      00AB3B F0               [24] 1724 	movx	@dptr,a
      00AB3C EA               [12] 1725 	mov	a,r2
      00AB3D A3               [24] 1726 	inc	dptr
      00AB3E F0               [24] 1727 	movx	@dptr,a
      00AB3F 90 0B 23         [24] 1728 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_3
      00AB42 E8               [12] 1729 	mov	a,r0
      00AB43 12 77 30         [24] 1730 	lcall	_ak820_outline_0189
      00AB46 ED               [12] 1731 	mov	a,r5
      00AB47 A3               [24] 1732 	inc	dptr
      00AB48 F0               [24] 1733 	movx	@dptr,a
      00AB49 85 40 82         [24] 1734 	mov	dpl, _raw_hid_receive_sloc4_1_0
      00AB4C 85 41 83         [24] 1735 	mov	dph, (_raw_hid_receive_sloc4_1_0 + 1)
      00AB4F C0 07            [24] 1736 	push	ar7
      00AB51 C0 06            [24] 1737 	push	ar6
      00AB53 C0 03            [24] 1738 	push	ar3
      00AB55 12 88 7D         [24] 1739 	lcall	_dynamic_keymap_set_buffer
      00AB58 D0 03            [24] 1740 	pop	ar3
      00AB5A D0 06            [24] 1741 	pop	ar6
      00AB5C D0 07            [24] 1742 	pop	ar7
                                   1743 ;	quantum/via.c:491: break;
      00AB5E D0 03            [24] 1744 	pop	ar3
      00AB60 02 AB D5         [24] 1745 	ljmp	00171$
                                   1746 ;	quantum/via.c:495: case id_bootloader_jump: {
      00AB63                       1747 00161$:
                                   1748 ;	quantum/via.c:497: if (!vial_unlocked)
      00AB63 90 0E 24         [24] 1749 	mov	dptr,#_vial_unlocked
      00AB66 E0               [24] 1750 	movx	a,@dptr
      00AB67 70 03            [24] 1751 	jnz	00570$
      00AB69 02 AB D5         [24] 1752 	ljmp	00171$
      00AB6C                       1753 00570$:
                                   1754 ;	quantum/via.c:501: raw_hid_send(data, length);
      00AB6C 12 AC 30         [24] 1755 	lcall	_ak820_outline_0152
      00AB6F 90 06 75         [24] 1756 	mov	dptr,#_raw_hid_send_PARM_2
      00AB72 12 AC 27         [24] 1757 	lcall	_ak820_outline_0089
      00AB75 C0 07            [24] 1758 	push	ar7
      00AB77 C0 06            [24] 1759 	push	ar6
      00AB79 C0 03            [24] 1760 	push	ar3
      00AB7B 12 4A F1         [24] 1761 	lcall	_raw_hid_send
      00AB7E D0 03            [24] 1762 	pop	ar3
      00AB80 D0 06            [24] 1763 	pop	ar6
      00AB82 D0 07            [24] 1764 	pop	ar7
                                   1765 ;	quantum/via.c:503: wait_ms(100);
      00AB84 7D 64            [12] 1766 	mov	r5,#0x64
      00AB86                       1767 00176$:
      00AB86 ED               [12] 1768 	mov	a,r5
      00AB87 60 09            [24] 1769 	jz	00166$
      00AB89 90 00 01         [24] 1770 	mov	dptr,#0x0001
      00AB8C 12 58 BD         [24] 1771 	lcall	_mDelaymS
      00AB8F 1D               [12] 1772 	dec	r5
      00AB90 80 F4            [24] 1773 	sjmp	00176$
      00AB92                       1774 00166$:
                                   1775 ;	quantum/via.c:504: bootloader_jump();
      00AB92 C0 07            [24] 1776 	push	ar7
      00AB94 C0 06            [24] 1777 	push	ar6
      00AB96 C0 03            [24] 1778 	push	ar3
      00AB98 12 34 0E         [24] 1779 	lcall	_bootloader_jump
      00AB9B D0 03            [24] 1780 	pop	ar3
      00AB9D D0 06            [24] 1781 	pop	ar6
      00AB9F D0 07            [24] 1782 	pop	ar7
                                   1783 ;	quantum/via.c:505: break;
                                   1784 ;	quantum/via.c:509: case id_vial_prefix: {
      00ABA1 80 32            [24] 1785 	sjmp	00171$
      00ABA3                       1786 00168$:
                                   1787 ;	quantum/via.c:510: vial_handle_cmd(data, length);
      00ABA3 12 AC 30         [24] 1788 	lcall	_ak820_outline_0152
      00ABA6 90 0C 64         [24] 1789 	mov	dptr,#_vial_handle_cmd_PARM_2
      00ABA9 12 AC 27         [24] 1790 	lcall	_ak820_outline_0089
      00ABAC C0 07            [24] 1791 	push	ar7
      00ABAE C0 06            [24] 1792 	push	ar6
      00ABB0 C0 03            [24] 1793 	push	ar3
      00ABB2 12 AD 1D         [24] 1794 	lcall	_vial_handle_cmd
      00ABB5 D0 03            [24] 1795 	pop	ar3
      00ABB7 D0 06            [24] 1796 	pop	ar6
      00ABB9 D0 07            [24] 1797 	pop	ar7
                                   1798 ;	quantum/via.c:511: break;
                                   1799 ;	quantum/via.c:514: default: {
      00ABBB 80 18            [24] 1800 	sjmp	00171$
      00ABBD                       1801 00169$:
                                   1802 ;	quantum/via.c:516: raw_hid_receive_kb(data, length);
      00ABBD 12 AC 30         [24] 1803 	lcall	_ak820_outline_0152
      00ABC0 90 0C 52         [24] 1804 	mov	dptr,#_raw_hid_receive_kb_PARM_2
      00ABC3 12 AC 27         [24] 1805 	lcall	_ak820_outline_0089
      00ABC6 C0 07            [24] 1806 	push	ar7
      00ABC8 C0 06            [24] 1807 	push	ar6
      00ABCA C0 03            [24] 1808 	push	ar3
      00ABCC 12 A6 35         [24] 1809 	lcall	_raw_hid_receive_kb
      00ABCF D0 03            [24] 1810 	pop	ar3
      00ABD1 D0 06            [24] 1811 	pop	ar6
      00ABD3 D0 07            [24] 1812 	pop	ar7
                                   1813 ;	quantum/via.c:521: skip:
      00ABD5                       1814 00171$:
                                   1815 ;	quantum/via.c:525: raw_hid_send(data, length);
      00ABD5 7D 00            [12] 1816 	mov	r5,#0x00
      00ABD7 90 06 75         [24] 1817 	mov	dptr,#_raw_hid_send_PARM_2
      00ABDA EB               [12] 1818 	mov	a,r3
      00ABDB F0               [24] 1819 	movx	@dptr,a
      00ABDC 12 6F 7E         [24] 1820 	lcall	_ak820_outline_0050
                                   1821 ;	quantum/via.c:526: }
      00ABDF 02 4A F1         [24] 1822 	ljmp	_raw_hid_send
                                   1823 	.area CSEG    (CODE)
                                   1824 	.area CONST   (CODE)
                                   1825 	.area XINIT   (CODE)
                                   1826 	.area CABS    (ABS,CODE)
                                   1827 
                                   1828 ; Experimental exact instruction outlining.
                                   1829 	.globl _ak820_outline_0001
                                   1830 	.globl _ak820_outline_0003
                                   1831 	.globl _ak820_outline_0008
                                   1832 	.globl _ak820_outline_0011
                                   1833 	.globl _ak820_outline_0012
                                   1834 	.globl _ak820_outline_0016
                                   1835 	.globl _ak820_outline_0017
                                   1836 	.globl _ak820_outline_0018
                                   1837 	.globl _ak820_outline_0023
                                   1838 	.globl _ak820_outline_0031
                                   1839 	.globl _ak820_outline_0036
                                   1840 	.globl _ak820_outline_0037
                                   1841 	.globl _ak820_outline_0041
                                   1842 	.globl _ak820_outline_0044
                                   1843 	.globl _ak820_outline_0050
                                   1844 	.globl _ak820_outline_0052
                                   1845 	.globl _ak820_outline_0059
                                   1846 	.globl _ak820_outline_0069
                                   1847 	.globl _ak820_outline_0076
                                   1848 	.globl _ak820_outline_0088
                                   1849 	.globl _ak820_outline_0089
                                   1850 	.globl _ak820_outline_0096
                                   1851 	.globl _ak820_outline_0109
                                   1852 	.globl _ak820_outline_0110
                                   1853 	.globl _ak820_outline_0114
                                   1854 	.globl _ak820_outline_0120
                                   1855 	.globl _ak820_outline_0122
                                   1856 	.globl _ak820_outline_0126
                                   1857 	.globl _ak820_outline_0152
                                   1858 	.globl _ak820_outline_0155
                                   1859 	.globl _ak820_outline_0159
                                   1860 	.globl _ak820_outline_0161
                                   1861 	.globl _ak820_outline_0163
                                   1862 	.globl _ak820_outline_0164
                                   1863 	.globl _ak820_outline_0189
                                   1864 
                                   1865 	.area CSEG (CODE)
                                   1866 ; function ak820_outline_0003
      00ABE2                       1867 _ak820_outline_0003:
      00ABE2 8C 82            [24] 1868 	mov	dpl,r4
      00ABE4 8D 83            [24] 1869 	mov	dph,r5
      00ABE6 E0               [24] 1870 	movx	a,@dptr
      00ABE7 FA               [12] 1871 	mov	r2,a
      00ABE8 79 00            [12] 1872 	mov	r1,#0x00
      00ABEA 8E 82            [24] 1873 	mov	dpl,r6
      00ABEC 8F 83            [24] 1874 	mov	dph,r7
      00ABEE A3               [24] 1875 	inc	dptr
      00ABEF A3               [24] 1876 	inc	dptr
      00ABF0 E0               [24] 1877 	movx	a,@dptr
      00ABF1 7B 00            [12] 1878 	mov	r3,#0x00
      00ABF3 42 01            [12] 1879 	orl	ar1,a
      00ABF5 EB               [12] 1880 	mov	a,r3
      00ABF6 42 02            [12] 1881 	orl	ar2,a
      00ABF8 22               [24] 1882 	ret
                                   1883 
                                   1884 	.area CSEG (CODE)
                                   1885 ; function ak820_outline_0018
      00ABF9                       1886 _ak820_outline_0018:
      00ABF9 8E 82            [24] 1887 	mov	dpl,r6
      00ABFB 8F 83            [24] 1888 	mov	dph,r7
      00ABFD A3               [24] 1889 	inc	dptr
      00ABFE A3               [24] 1890 	inc	dptr
      00ABFF A3               [24] 1891 	inc	dptr
      00AC00 E0               [24] 1892 	movx	a,@dptr
      00AC01 22               [24] 1893 	ret
                                   1894 
                                   1895 	.area CSEG (CODE)
                                   1896 ; function ak820_outline_0023
      00AC02                       1897 _ak820_outline_0023:
      00AC02 8E 82            [24] 1898 	mov	dpl,r6
      00AC04 8F 83            [24] 1899 	mov	dph,r7
      00AC06 A3               [24] 1900 	inc	dptr
      00AC07 A3               [24] 1901 	inc	dptr
      00AC08 A3               [24] 1902 	inc	dptr
      00AC09 A3               [24] 1903 	inc	dptr
      00AC0A 22               [24] 1904 	ret
                                   1905 
                                   1906 	.area CSEG (CODE)
                                   1907 ; function ak820_outline_0041
      00AC0B                       1908 _ak820_outline_0041:
      00AC0B EB               [12] 1909 	mov	a,r3
      00AC0C F0               [24] 1910 	movx	@dptr,a
      00AC0D 88 82            [24] 1911 	mov	dpl,r0
      00AC0F 89 83            [24] 1912 	mov	dph,r1
      00AC11 8A F0            [24] 1913 	mov	b,r2
      00AC13 22               [24] 1914 	ret
                                   1915 
                                   1916 	.area CSEG (CODE)
                                   1917 ; function ak820_outline_0069
      00AC14                       1918 _ak820_outline_0069:
      00AC14 74 04            [12] 1919 	mov	a,#0x04
      00AC16 2E               [12] 1920 	add	a,r6
      00AC17 F9               [12] 1921 	mov	r1,a
      00AC18 E4               [12] 1922 	clr	a
      00AC19 3F               [12] 1923 	addc	a,r7
      00AC1A F8               [12] 1924 	mov	r0,a
      00AC1B 7A 00            [12] 1925 	mov	r2,#0x00
      00AC1D 22               [24] 1926 	ret
                                   1927 
                                   1928 	.area CSEG (CODE)
                                   1929 ; function ak820_outline_0088
      00AC1E                       1930 _ak820_outline_0088:
      00AC1E E9               [12] 1931 	mov	a,r1
      00AC1F F0               [24] 1932 	movx	@dptr,a
      00AC20 E8               [12] 1933 	mov	a,r0
      00AC21 A3               [24] 1934 	inc	dptr
      00AC22 F0               [24] 1935 	movx	@dptr,a
      00AC23 EA               [12] 1936 	mov	a,r2
      00AC24 A3               [24] 1937 	inc	dptr
      00AC25 F0               [24] 1938 	movx	@dptr,a
      00AC26 22               [24] 1939 	ret
                                   1940 
                                   1941 	.area CSEG (CODE)
                                   1942 ; function ak820_outline_0089
      00AC27                       1943 _ak820_outline_0089:
      00AC27 EB               [12] 1944 	mov	a,r3
      00AC28 F0               [24] 1945 	movx	@dptr,a
      00AC29 8A 82            [24] 1946 	mov	dpl,r2
      00AC2B 8C 83            [24] 1947 	mov	dph,r4
      00AC2D 8D F0            [24] 1948 	mov	b,r5
      00AC2F 22               [24] 1949 	ret
                                   1950 
                                   1951 	.area CSEG (CODE)
                                   1952 ; function ak820_outline_0152
      00AC30                       1953 _ak820_outline_0152:
      00AC30 8E 02            [24] 1954 	mov	ar2,r6
      00AC32 8F 04            [24] 1955 	mov	ar4,r7
      00AC34 7D 00            [12] 1956 	mov	r5,#0x00
      00AC36 22               [24] 1957 	ret
