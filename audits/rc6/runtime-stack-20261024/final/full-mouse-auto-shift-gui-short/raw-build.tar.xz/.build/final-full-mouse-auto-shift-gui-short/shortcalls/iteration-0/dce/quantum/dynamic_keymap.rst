                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module dynamic_keymap
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _dynamic_keymap_encoder_to_eeprom_address
                                     12 	.globl _ak820_combo_valid
                                     13 	.globl _ak820_eeprom_write_block_xdata
                                     14 	.globl _ak820_eeprom_read_block_xdata
                                     15 	.globl _ak820_nvm_flush
                                     16 	.globl _ak820_nvm_ok
                                     17 	.globl _ak820_macro_reset
                                     18 	.globl _ak820_macro_write
                                     19 	.globl _ak820_macro_length
                                     20 	.globl _ak820_macro_ready
                                     21 	.globl _send_char
                                     22 	.globl _keycode_at_encodermap_location_raw
                                     23 	.globl _keycode_at_keymap_location_raw
                                     24 	.globl _vial_keycode_tap
                                     25 	.globl _vial_keycode_up
                                     26 	.globl _vial_keycode_down
                                     27 	.globl _clear_keyboard
                                     28 	.globl _tap_code
                                     29 	.globl _unregister_code
                                     30 	.globl _register_code
                                     31 	.globl _mDelaymS
                                     32 	.globl ___memcpy
                                     33 	.globl _memset
                                     34 	.globl _eeprom_update_byte
                                     35 	.globl _eeprom_read_byte
                                     36 	.globl _ADC_START
                                     37 	.globl _S0_R_FIFO
                                     38 	.globl _S0_T_FIFO
                                     39 	.globl _S0_FREE
                                     40 	.globl _S0_IF_BYTE
                                     41 	.globl _S0_IF_FIRST
                                     42 	.globl _S0_IF_OV
                                     43 	.globl _S0_FST_ACT
                                     44 	.globl _CP_RL2
                                     45 	.globl _C_T2
                                     46 	.globl _TR2
                                     47 	.globl _EXEN2
                                     48 	.globl _TCLK
                                     49 	.globl _RCLK
                                     50 	.globl _EXF2
                                     51 	.globl _CAP1F
                                     52 	.globl _TF2
                                     53 	.globl _RI
                                     54 	.globl _TI
                                     55 	.globl _RB8
                                     56 	.globl _TB8
                                     57 	.globl _REN
                                     58 	.globl _SM2
                                     59 	.globl _SM1
                                     60 	.globl _SM0
                                     61 	.globl _IT0
                                     62 	.globl _IE0
                                     63 	.globl _IT1
                                     64 	.globl _IE1
                                     65 	.globl _TR0
                                     66 	.globl _TF0
                                     67 	.globl _TR1
                                     68 	.globl _TF1
                                     69 	.globl _P4_0
                                     70 	.globl _P4_1
                                     71 	.globl _P4_2
                                     72 	.globl _P4_3
                                     73 	.globl _P4_4
                                     74 	.globl _P4_5
                                     75 	.globl _P4_6
                                     76 	.globl _RXD
                                     77 	.globl _TXD
                                     78 	.globl _INT0
                                     79 	.globl _INT1
                                     80 	.globl _T0
                                     81 	.globl _T1
                                     82 	.globl _MOSI1
                                     83 	.globl _MISO1
                                     84 	.globl _SCK1
                                     85 	.globl _P3_0
                                     86 	.globl _P3_1
                                     87 	.globl _P3_2
                                     88 	.globl _P3_3
                                     89 	.globl _P3_4
                                     90 	.globl _P3_5
                                     91 	.globl _P3_6
                                     92 	.globl _P3_7
                                     93 	.globl _CAP1_
                                     94 	.globl _T2_
                                     95 	.globl _CAP2_
                                     96 	.globl _T2EX_
                                     97 	.globl _RXD1
                                     98 	.globl _TXD1
                                     99 	.globl _P2_0
                                    100 	.globl _P2_1
                                    101 	.globl _P2_2
                                    102 	.globl _P2_3
                                    103 	.globl _P2_4
                                    104 	.globl _P2_5
                                    105 	.globl _P2_6
                                    106 	.globl _P2_7
                                    107 	.globl _AIN0
                                    108 	.globl _AIN1
                                    109 	.globl _AIN2
                                    110 	.globl _AIN3
                                    111 	.globl _AIN4
                                    112 	.globl _AIN5
                                    113 	.globl _AIN6
                                    114 	.globl _AIN7
                                    115 	.globl _CAP1
                                    116 	.globl _T2
                                    117 	.globl _CAP2
                                    118 	.globl _T2EX
                                    119 	.globl _INT0_
                                    120 	.globl _SCS
                                    121 	.globl _MOSI
                                    122 	.globl _MISO
                                    123 	.globl _SCK
                                    124 	.globl _RXD1_
                                    125 	.globl _TXD1_
                                    126 	.globl _P1_0
                                    127 	.globl _P1_1
                                    128 	.globl _P1_2
                                    129 	.globl _P1_3
                                    130 	.globl _P1_4
                                    131 	.globl _P1_5
                                    132 	.globl _P1_6
                                    133 	.globl _P1_7
                                    134 	.globl _AIN8
                                    135 	.globl _AIN9
                                    136 	.globl _AIN10
                                    137 	.globl _AIN11
                                    138 	.globl _AIN12
                                    139 	.globl _AIN13
                                    140 	.globl _RXD_
                                    141 	.globl _TXD_
                                    142 	.globl _SCL0
                                    143 	.globl _SDA0
                                    144 	.globl _P0_0
                                    145 	.globl _P0_1
                                    146 	.globl _P0_2
                                    147 	.globl _P0_3
                                    148 	.globl _P0_4
                                    149 	.globl _P0_5
                                    150 	.globl _P0_6
                                    151 	.globl _P0_7
                                    152 	.globl _IE_SPI0
                                    153 	.globl _IE_USB
                                    154 	.globl _IE_ADC
                                    155 	.globl _IE_UART1
                                    156 	.globl _IE_PWM_I2C
                                    157 	.globl _IE_GPIO
                                    158 	.globl _IE_WDOG
                                    159 	.globl _PX0
                                    160 	.globl _PT0
                                    161 	.globl _PX1
                                    162 	.globl _PT1
                                    163 	.globl _PS
                                    164 	.globl _PT2
                                    165 	.globl _PL_FLAG
                                    166 	.globl _PH_FLAG
                                    167 	.globl _EX0
                                    168 	.globl _ET0
                                    169 	.globl _EX1
                                    170 	.globl _ET1
                                    171 	.globl _ES
                                    172 	.globl _ET2
                                    173 	.globl _E_DIS
                                    174 	.globl _EA
                                    175 	.globl _P
                                    176 	.globl _F1
                                    177 	.globl _OV
                                    178 	.globl _RS0
                                    179 	.globl _RS1
                                    180 	.globl _F0
                                    181 	.globl _AC
                                    182 	.globl _CY
                                    183 	.globl _I2CS_INT_ST
                                    184 	.globl _I2CX_INT
                                    185 	.globl _LED_STATUS
                                    186 	.globl _LED_DMA_H
                                    187 	.globl _LED_DMA_L
                                    188 	.globl _LED_DMA
                                    189 	.globl _LED_PWM_OE
                                    190 	.globl _LED_COMMON
                                    191 	.globl _ADC_CHAN
                                    192 	.globl _ADC_DAT_H
                                    193 	.globl _ADC_DAT_L
                                    194 	.globl _ADC_DAT
                                    195 	.globl _ADC_CTRL
                                    196 	.globl _SPI1_CK_SE
                                    197 	.globl _SPI1_CTRL
                                    198 	.globl _SPI1_DATA
                                    199 	.globl _SPI1_STAT
                                    200 	.globl _SIF1
                                    201 	.globl _SBAUD1
                                    202 	.globl _SBUF1
                                    203 	.globl _SCON1
                                    204 	.globl _SPI0_SETUP
                                    205 	.globl _SPI0_CK_SE
                                    206 	.globl _SPI0_CTRL
                                    207 	.globl _SPI0_DATA
                                    208 	.globl _SPI0_STAT
                                    209 	.globl _T2CAP1H
                                    210 	.globl _T2CAP1L
                                    211 	.globl _T2CAP1
                                    212 	.globl _TH2
                                    213 	.globl _TL2
                                    214 	.globl _T2COUNT
                                    215 	.globl _RCAP2H
                                    216 	.globl _RCAP2L
                                    217 	.globl _RCAP2
                                    218 	.globl _T2MOD
                                    219 	.globl _T2CON
                                    220 	.globl _SBUF
                                    221 	.globl _SCON
                                    222 	.globl _TH1
                                    223 	.globl _TH0
                                    224 	.globl _TL1
                                    225 	.globl _TL0
                                    226 	.globl _TMOD
                                    227 	.globl _TCON
                                    228 	.globl _XBUS_AUX
                                    229 	.globl _P7
                                    230 	.globl _P6_DIR
                                    231 	.globl _P6_OUT_PU
                                    232 	.globl _P6_IN
                                    233 	.globl _P5_DIR
                                    234 	.globl _P5_OUT_PU
                                    235 	.globl _P5_IN
                                    236 	.globl _P4_LED_KEY
                                    237 	.globl _P4_DIR_PU
                                    238 	.globl _P4_MOD_OC
                                    239 	.globl _P4
                                    240 	.globl _P3_DIR_PU
                                    241 	.globl _P3_MOD_OC
                                    242 	.globl _P3
                                    243 	.globl _P2_DIR_PU
                                    244 	.globl _P2_MOD_OC
                                    245 	.globl _P2
                                    246 	.globl _P1_DIR_PU
                                    247 	.globl _P1_MOD_OC
                                    248 	.globl _P1
                                    249 	.globl _P0_DIR_PU
                                    250 	.globl _P0_MOD_OC
                                    251 	.globl _P0
                                    252 	.globl _ROM_CTRL
                                    253 	.globl _ROM_DATA_HH
                                    254 	.globl _ROM_DATA_HL
                                    255 	.globl _ROM_DATA_HI
                                    256 	.globl _ROM_ADDR_H
                                    257 	.globl _ROM_ADDR_L
                                    258 	.globl _ROM_ADDR
                                    259 	.globl _GPIO_IE
                                    260 	.globl _IP_EX
                                    261 	.globl _IE_EX
                                    262 	.globl _IP
                                    263 	.globl _IE
                                    264 	.globl _WDOG_COUNT
                                    265 	.globl _RESET_KEEP
                                    266 	.globl _WAKE_CTRL
                                    267 	.globl _CLOCK_CFG
                                    268 	.globl _POWER_CFG
                                    269 	.globl _PCON
                                    270 	.globl _GLOBAL_CFG
                                    271 	.globl _SAFE_MOD
                                    272 	.globl _DPH
                                    273 	.globl _DPL
                                    274 	.globl _SP
                                    275 	.globl _A_INV
                                    276 	.globl _B
                                    277 	.globl _ACC
                                    278 	.globl _PSW
                                    279 	.globl _dynamic_keymap_macro_set_buffer_PARM_3
                                    280 	.globl _dynamic_keymap_macro_set_buffer_PARM_2
                                    281 	.globl _dynamic_keymap_macro_get_buffer_PARM_3
                                    282 	.globl _dynamic_keymap_macro_get_buffer_PARM_2
                                    283 	.globl _keycode_at_encodermap_location_PARM_3
                                    284 	.globl _keycode_at_encodermap_location_PARM_2
                                    285 	.globl _keycode_at_keymap_location_PARM_3
                                    286 	.globl _keycode_at_keymap_location_PARM_2
                                    287 	.globl _dynamic_keymap_set_buffer_PARM_3
                                    288 	.globl _dynamic_keymap_set_buffer_PARM_2
                                    289 	.globl _dynamic_keymap_get_buffer_PARM_3
                                    290 	.globl _dynamic_keymap_get_buffer_PARM_2
                                    291 	.globl _dynamic_keymap_set_combo_PARM_2
                                    292 	.globl _dynamic_keymap_get_combo_PARM_2
                                    293 	.globl _dynamic_keymap_set_encoder_PARM_4
                                    294 	.globl _dynamic_keymap_set_encoder_PARM_3
                                    295 	.globl _dynamic_keymap_set_encoder_PARM_2
                                    296 	.globl _dynamic_keymap_get_encoder_PARM_3
                                    297 	.globl _dynamic_keymap_get_encoder_PARM_2
                                    298 	.globl _dynamic_keymap_encoder_to_eeprom_address_PARM_2
                                    299 	.globl _dynamic_keymap_set_keycode_PARM_4
                                    300 	.globl _dynamic_keymap_set_keycode_PARM_3
                                    301 	.globl _dynamic_keymap_set_keycode_PARM_2
                                    302 	.globl _dynamic_keymap_get_keycode_PARM_3
                                    303 	.globl _dynamic_keymap_get_keycode_PARM_2
                                    304 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_3
                                    305 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_2
                                    306 	.globl _dynamic_keymap_get_layer_count
                                    307 	.globl _dynamic_keymap_key_to_eeprom_address
                                    308 	.globl _dynamic_keymap_get_keycode
                                    309 	.globl _dynamic_keymap_set_keycode
                                    310 	.globl _dynamic_keymap_get_encoder
                                    311 	.globl _dynamic_keymap_set_encoder
                                    312 	.globl _dynamic_keymap_get_combo
                                    313 	.globl _dynamic_keymap_set_combo
                                    314 	.globl _dynamic_keymap_reset
                                    315 	.globl _dynamic_keymap_get_buffer
                                    316 	.globl _dynamic_keymap_set_buffer
                                    317 	.globl _keycode_at_keymap_location
                                    318 	.globl _keycode_at_encodermap_location
                                    319 	.globl _dynamic_keymap_macro_get_count
                                    320 	.globl _dynamic_keymap_macro_get_buffer_size
                                    321 	.globl _dynamic_keymap_macro_get_buffer
                                    322 	.globl _dynamic_keymap_macro_set_buffer
                                    323 	.globl _dynamic_keymap_macro_reset
                                    324 	.globl _dynamic_keymap_macro_send
                                    325 ;--------------------------------------------------------
                                    326 ; special function registers
                                    327 ;--------------------------------------------------------
                                    328 	.area RSEG    (ABS,DATA)
      000000                        329 	.org 0x0000
                           0000D0   330 _PSW	=	0x00d0
                           0000E0   331 _ACC	=	0x00e0
                           0000F0   332 _B	=	0x00f0
                           0000FD   333 _A_INV	=	0x00fd
                           000081   334 _SP	=	0x0081
                           000082   335 _DPL	=	0x0082
                           000083   336 _DPH	=	0x0083
                           0000A1   337 _SAFE_MOD	=	0x00a1
                           0000B1   338 _GLOBAL_CFG	=	0x00b1
                           000087   339 _PCON	=	0x0087
                           0000BA   340 _POWER_CFG	=	0x00ba
                           0000B9   341 _CLOCK_CFG	=	0x00b9
                           0000A9   342 _WAKE_CTRL	=	0x00a9
                           0000FE   343 _RESET_KEEP	=	0x00fe
                           0000FF   344 _WDOG_COUNT	=	0x00ff
                           0000A8   345 _IE	=	0x00a8
                           0000B8   346 _IP	=	0x00b8
                           0000E8   347 _IE_EX	=	0x00e8
                           0000E9   348 _IP_EX	=	0x00e9
                           0000B2   349 _GPIO_IE	=	0x00b2
                           008584   350 _ROM_ADDR	=	0x8584
                           000084   351 _ROM_ADDR_L	=	0x0084
                           000085   352 _ROM_ADDR_H	=	0x0085
                           008F8E   353 _ROM_DATA_HI	=	0x8f8e
                           00008E   354 _ROM_DATA_HL	=	0x008e
                           00008F   355 _ROM_DATA_HH	=	0x008f
                           000086   356 _ROM_CTRL	=	0x0086
                           000080   357 _P0	=	0x0080
                           0000C4   358 _P0_MOD_OC	=	0x00c4
                           0000C5   359 _P0_DIR_PU	=	0x00c5
                           000090   360 _P1	=	0x0090
                           000092   361 _P1_MOD_OC	=	0x0092
                           000093   362 _P1_DIR_PU	=	0x0093
                           0000A0   363 _P2	=	0x00a0
                           000094   364 _P2_MOD_OC	=	0x0094
                           000095   365 _P2_DIR_PU	=	0x0095
                           0000B0   366 _P3	=	0x00b0
                           000096   367 _P3_MOD_OC	=	0x0096
                           000097   368 _P3_DIR_PU	=	0x0097
                           0000C0   369 _P4	=	0x00c0
                           0000C2   370 _P4_MOD_OC	=	0x00c2
                           0000C3   371 _P4_DIR_PU	=	0x00c3
                           0000C1   372 _P4_LED_KEY	=	0x00c1
                           0000AA   373 _P5_IN	=	0x00aa
                           0000AB   374 _P5_OUT_PU	=	0x00ab
                           0000AC   375 _P5_DIR	=	0x00ac
                           0000AD   376 _P6_IN	=	0x00ad
                           0000AE   377 _P6_OUT_PU	=	0x00ae
                           0000AF   378 _P6_DIR	=	0x00af
                           0000F1   379 _P7	=	0x00f1
                           0000A2   380 _XBUS_AUX	=	0x00a2
                           000088   381 _TCON	=	0x0088
                           000089   382 _TMOD	=	0x0089
                           00008A   383 _TL0	=	0x008a
                           00008B   384 _TL1	=	0x008b
                           00008C   385 _TH0	=	0x008c
                           00008D   386 _TH1	=	0x008d
                           000098   387 _SCON	=	0x0098
                           000099   388 _SBUF	=	0x0099
                           0000C8   389 _T2CON	=	0x00c8
                           0000C9   390 _T2MOD	=	0x00c9
                           00CBCA   391 _RCAP2	=	0xcbca
                           0000CA   392 _RCAP2L	=	0x00ca
                           0000CB   393 _RCAP2H	=	0x00cb
                           00CDCC   394 _T2COUNT	=	0xcdcc
                           0000CC   395 _TL2	=	0x00cc
                           0000CD   396 _TH2	=	0x00cd
                           00CFCE   397 _T2CAP1	=	0xcfce
                           0000CE   398 _T2CAP1L	=	0x00ce
                           0000CF   399 _T2CAP1H	=	0x00cf
                           0000F8   400 _SPI0_STAT	=	0x00f8
                           0000F9   401 _SPI0_DATA	=	0x00f9
                           0000FA   402 _SPI0_CTRL	=	0x00fa
                           0000FB   403 _SPI0_CK_SE	=	0x00fb
                           0000FC   404 _SPI0_SETUP	=	0x00fc
                           0000BC   405 _SCON1	=	0x00bc
                           0000BD   406 _SBUF1	=	0x00bd
                           0000BE   407 _SBAUD1	=	0x00be
                           0000BF   408 _SIF1	=	0x00bf
                           0000B4   409 _SPI1_STAT	=	0x00b4
                           0000B5   410 _SPI1_DATA	=	0x00b5
                           0000B6   411 _SPI1_CTRL	=	0x00b6
                           0000B7   412 _SPI1_CK_SE	=	0x00b7
                           0000F3   413 _ADC_CTRL	=	0x00f3
                           00F5F4   414 _ADC_DAT	=	0xf5f4
                           0000F4   415 _ADC_DAT_L	=	0x00f4
                           0000F5   416 _ADC_DAT_H	=	0x00f5
                           0000F6   417 _ADC_CHAN	=	0x00f6
                           0000A6   418 _LED_COMMON	=	0x00a6
                           0000A7   419 _LED_PWM_OE	=	0x00a7
                           00C7C6   420 _LED_DMA	=	0xc7c6
                           0000C6   421 _LED_DMA_L	=	0x00c6
                           0000C7   422 _LED_DMA_H	=	0x00c7
                           0000F7   423 _LED_STATUS	=	0x00f7
                           0000B3   424 _I2CX_INT	=	0x00b3
                           0000BB   425 _I2CS_INT_ST	=	0x00bb
                                    426 ;--------------------------------------------------------
                                    427 ; special function bits
                                    428 ;--------------------------------------------------------
                                    429 	.area RSEG    (ABS,DATA)
      000000                        430 	.org 0x0000
                           0000D7   431 _CY	=	0x00d7
                           0000D6   432 _AC	=	0x00d6
                           0000D5   433 _F0	=	0x00d5
                           0000D4   434 _RS1	=	0x00d4
                           0000D3   435 _RS0	=	0x00d3
                           0000D2   436 _OV	=	0x00d2
                           0000D1   437 _F1	=	0x00d1
                           0000D0   438 _P	=	0x00d0
                           0000AF   439 _EA	=	0x00af
                           0000AE   440 _E_DIS	=	0x00ae
                           0000AD   441 _ET2	=	0x00ad
                           0000AC   442 _ES	=	0x00ac
                           0000AB   443 _ET1	=	0x00ab
                           0000AA   444 _EX1	=	0x00aa
                           0000A9   445 _ET0	=	0x00a9
                           0000A8   446 _EX0	=	0x00a8
                           0000BF   447 _PH_FLAG	=	0x00bf
                           0000BE   448 _PL_FLAG	=	0x00be
                           0000BD   449 _PT2	=	0x00bd
                           0000BC   450 _PS	=	0x00bc
                           0000BB   451 _PT1	=	0x00bb
                           0000BA   452 _PX1	=	0x00ba
                           0000B9   453 _PT0	=	0x00b9
                           0000B8   454 _PX0	=	0x00b8
                           0000EF   455 _IE_WDOG	=	0x00ef
                           0000EE   456 _IE_GPIO	=	0x00ee
                           0000ED   457 _IE_PWM_I2C	=	0x00ed
                           0000EC   458 _IE_UART1	=	0x00ec
                           0000EB   459 _IE_ADC	=	0x00eb
                           0000E9   460 _IE_USB	=	0x00e9
                           0000E8   461 _IE_SPI0	=	0x00e8
                           000087   462 _P0_7	=	0x0087
                           000086   463 _P0_6	=	0x0086
                           000085   464 _P0_5	=	0x0085
                           000084   465 _P0_4	=	0x0084
                           000083   466 _P0_3	=	0x0083
                           000082   467 _P0_2	=	0x0082
                           000081   468 _P0_1	=	0x0081
                           000080   469 _P0_0	=	0x0080
                           000081   470 _SDA0	=	0x0081
                           000080   471 _SCL0	=	0x0080
                           000083   472 _TXD_	=	0x0083
                           000082   473 _RXD_	=	0x0082
                           000085   474 _AIN13	=	0x0085
                           000084   475 _AIN12	=	0x0084
                           000083   476 _AIN11	=	0x0083
                           000082   477 _AIN10	=	0x0082
                           000081   478 _AIN9	=	0x0081
                           000080   479 _AIN8	=	0x0080
                           000097   480 _P1_7	=	0x0097
                           000096   481 _P1_6	=	0x0096
                           000095   482 _P1_5	=	0x0095
                           000094   483 _P1_4	=	0x0094
                           000093   484 _P1_3	=	0x0093
                           000092   485 _P1_2	=	0x0092
                           000091   486 _P1_1	=	0x0091
                           000090   487 _P1_0	=	0x0090
                           000097   488 _TXD1_	=	0x0097
                           000096   489 _RXD1_	=	0x0096
                           000097   490 _SCK	=	0x0097
                           000096   491 _MISO	=	0x0096
                           000095   492 _MOSI	=	0x0095
                           000094   493 _SCS	=	0x0094
                           000092   494 _INT0_	=	0x0092
                           000091   495 _T2EX	=	0x0091
                           000091   496 _CAP2	=	0x0091
                           000090   497 _T2	=	0x0090
                           000090   498 _CAP1	=	0x0090
                           000097   499 _AIN7	=	0x0097
                           000096   500 _AIN6	=	0x0096
                           000095   501 _AIN5	=	0x0095
                           000094   502 _AIN4	=	0x0094
                           000093   503 _AIN3	=	0x0093
                           000092   504 _AIN2	=	0x0092
                           000091   505 _AIN1	=	0x0091
                           000090   506 _AIN0	=	0x0090
                           0000A7   507 _P2_7	=	0x00a7
                           0000A6   508 _P2_6	=	0x00a6
                           0000A5   509 _P2_5	=	0x00a5
                           0000A4   510 _P2_4	=	0x00a4
                           0000A3   511 _P2_3	=	0x00a3
                           0000A2   512 _P2_2	=	0x00a2
                           0000A1   513 _P2_1	=	0x00a1
                           0000A0   514 _P2_0	=	0x00a0
                           0000A7   515 _TXD1	=	0x00a7
                           0000A6   516 _RXD1	=	0x00a6
                           0000A5   517 _T2EX_	=	0x00a5
                           0000A5   518 _CAP2_	=	0x00a5
                           0000A4   519 _T2_	=	0x00a4
                           0000A4   520 _CAP1_	=	0x00a4
                           0000B7   521 _P3_7	=	0x00b7
                           0000B6   522 _P3_6	=	0x00b6
                           0000B5   523 _P3_5	=	0x00b5
                           0000B4   524 _P3_4	=	0x00b4
                           0000B3   525 _P3_3	=	0x00b3
                           0000B2   526 _P3_2	=	0x00b2
                           0000B1   527 _P3_1	=	0x00b1
                           0000B0   528 _P3_0	=	0x00b0
                           0000B7   529 _SCK1	=	0x00b7
                           0000B6   530 _MISO1	=	0x00b6
                           0000B5   531 _MOSI1	=	0x00b5
                           0000B5   532 _T1	=	0x00b5
                           0000B4   533 _T0	=	0x00b4
                           0000B3   534 _INT1	=	0x00b3
                           0000B2   535 _INT0	=	0x00b2
                           0000B1   536 _TXD	=	0x00b1
                           0000B0   537 _RXD	=	0x00b0
                           0000C6   538 _P4_6	=	0x00c6
                           0000C5   539 _P4_5	=	0x00c5
                           0000C4   540 _P4_4	=	0x00c4
                           0000C3   541 _P4_3	=	0x00c3
                           0000C2   542 _P4_2	=	0x00c2
                           0000C1   543 _P4_1	=	0x00c1
                           0000C0   544 _P4_0	=	0x00c0
                           00008F   545 _TF1	=	0x008f
                           00008E   546 _TR1	=	0x008e
                           00008D   547 _TF0	=	0x008d
                           00008C   548 _TR0	=	0x008c
                           00008B   549 _IE1	=	0x008b
                           00008A   550 _IT1	=	0x008a
                           000089   551 _IE0	=	0x0089
                           000088   552 _IT0	=	0x0088
                           00009F   553 _SM0	=	0x009f
                           00009E   554 _SM1	=	0x009e
                           00009D   555 _SM2	=	0x009d
                           00009C   556 _REN	=	0x009c
                           00009B   557 _TB8	=	0x009b
                           00009A   558 _RB8	=	0x009a
                           000099   559 _TI	=	0x0099
                           000098   560 _RI	=	0x0098
                           0000CF   561 _TF2	=	0x00cf
                           0000CF   562 _CAP1F	=	0x00cf
                           0000CE   563 _EXF2	=	0x00ce
                           0000CD   564 _RCLK	=	0x00cd
                           0000CC   565 _TCLK	=	0x00cc
                           0000CB   566 _EXEN2	=	0x00cb
                           0000CA   567 _TR2	=	0x00ca
                           0000C9   568 _C_T2	=	0x00c9
                           0000C8   569 _CP_RL2	=	0x00c8
                           0000FF   570 _S0_FST_ACT	=	0x00ff
                           0000FE   571 _S0_IF_OV	=	0x00fe
                           0000FD   572 _S0_IF_FIRST	=	0x00fd
                           0000FC   573 _S0_IF_BYTE	=	0x00fc
                           0000FB   574 _S0_FREE	=	0x00fb
                           0000FA   575 _S0_T_FIFO	=	0x00fa
                           0000F8   576 _S0_R_FIFO	=	0x00f8
                           0000F7   577 _ADC_START	=	0x00f7
                                    578 ;--------------------------------------------------------
                                    579 ; overlayable register banks
                                    580 ;--------------------------------------------------------
                                    581 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        582 	.ds 8
                                    583 ;--------------------------------------------------------
                                    584 ; internal ram data
                                    585 ;--------------------------------------------------------
                                    586 	.area DSEG    (DATA)
      000029                        587 _dynamic_keymap_set_encoder_sloc0_1_0:
      000029                        588 	.ds 2
      00002B                        589 _dynamic_keymap_get_combo_sloc0_1_0:
      00002B                        590 	.ds 1
      00002C                        591 _ak820_dynamic_read_buffer_sloc0_1_0:
      00002C                        592 	.ds 1
      00002D                        593 _dynamic_keymap_set_buffer_sloc0_1_0:
      00002D                        594 	.ds 2
      00002F                        595 _dynamic_keymap_set_buffer_sloc1_1_0:
      00002F                        596 	.ds 2
      000031                        597 _dynamic_keymap_set_buffer_sloc2_1_0:
      000031                        598 	.ds 1
      000032                        599 _dynamic_keymap_macro_get_buffer_sloc0_1_0:
      000032                        600 	.ds 2
                                    601 ;--------------------------------------------------------
                                    602 ; overlayable items in internal ram
                                    603 ;--------------------------------------------------------
                                    604 ;--------------------------------------------------------
                                    605 ; indirectly addressable internal ram data
                                    606 ;--------------------------------------------------------
                                    607 	.area ISEG    (DATA)
                                    608 ;--------------------------------------------------------
                                    609 ; absolute internal ram data
                                    610 ;--------------------------------------------------------
                                    611 	.area IABS    (ABS,DATA)
                                    612 	.area IABS    (ABS,DATA)
                                    613 ;--------------------------------------------------------
                                    614 ; bit data
                                    615 ;--------------------------------------------------------
                                    616 	.area BSEG    (BIT)
      000027                        617 _dynamic_keymap_macro_send_sloc0_1_0:
      000027                        618 	.ds 1
                                    619 ;--------------------------------------------------------
                                    620 ; paged external ram data
                                    621 ;--------------------------------------------------------
                                    622 	.area PSEG    (PAG,XDATA)
                                    623 ;--------------------------------------------------------
                                    624 ; uninitialized external ram data
                                    625 ;--------------------------------------------------------
                                    626 	.area XSEG    (XDATA)
      000B0D                        627 _dynamic_keymap_key_to_eeprom_address_PARM_2:
      000B0D                        628 	.ds 1
      000B0E                        629 _dynamic_keymap_key_to_eeprom_address_PARM_3:
      000B0E                        630 	.ds 1
      000B0F                        631 _dynamic_keymap_key_to_eeprom_address_layer_10000_366:
      000B0F                        632 	.ds 1
      000B10                        633 _dynamic_keymap_get_keycode_PARM_2:
      000B10                        634 	.ds 1
      000B11                        635 _dynamic_keymap_get_keycode_PARM_3:
      000B11                        636 	.ds 1
      000B12                        637 _dynamic_keymap_get_keycode_layer_10000_368:
      000B12                        638 	.ds 1
      000B13                        639 _dynamic_keymap_set_keycode_PARM_2:
      000B13                        640 	.ds 1
      000B14                        641 _dynamic_keymap_set_keycode_PARM_3:
      000B14                        642 	.ds 1
      000B15                        643 _dynamic_keymap_set_keycode_PARM_4:
      000B15                        644 	.ds 2
      000B17                        645 _dynamic_keymap_set_keycode_layer_10000_372:
      000B17                        646 	.ds 1
      000B18                        647 _dynamic_keymap_encoder_to_eeprom_address_PARM_2:
      000B18                        648 	.ds 1
      000B19                        649 _dynamic_keymap_encoder_to_eeprom_address_layer_10000_376:
      000B19                        650 	.ds 1
      000B1A                        651 _dynamic_keymap_get_encoder_PARM_2:
      000B1A                        652 	.ds 1
      000B1B                        653 _dynamic_keymap_get_encoder_PARM_3:
      000B1B                        654 	.ds 1
      000B1C                        655 _dynamic_keymap_get_encoder_layer_10000_378:
      000B1C                        656 	.ds 1
      000B1D                        657 _dynamic_keymap_set_encoder_PARM_2:
      000B1D                        658 	.ds 1
      000B1E                        659 _dynamic_keymap_set_encoder_PARM_3:
      000B1E                        660 	.ds 1
      000B1F                        661 _dynamic_keymap_set_encoder_PARM_4:
      000B1F                        662 	.ds 2
      000B21                        663 _dynamic_keymap_set_encoder_layer_10000_382:
      000B21                        664 	.ds 1
      000B22                        665 _dynamic_keymap_get_combo_PARM_2:
      000B22                        666 	.ds 3
      000B25                        667 _dynamic_keymap_get_combo_index_10000_386:
      000B25                        668 	.ds 1
      000B26                        669 _dynamic_keymap_set_combo_PARM_2:
      000B26                        670 	.ds 3
      000B29                        671 _dynamic_keymap_set_combo_index_10000_392:
      000B29                        672 	.ds 1
      000B2A                        673 _dynamic_keymap_set_combo_stored_10002_397:
      000B2A                        674 	.ds 10
      000B34                        675 _dynamic_keymap_reset_vial_unlocked_prev_10000_400:
      000B34                        676 	.ds 1
      000B35                        677 _dynamic_keymap_reset_combo_10001_409:
      000B35                        678 	.ds 10
      000B3F                        679 _ak820_dynamic_read_buffer_PARM_2:
      000B3F                        680 	.ds 2
      000B41                        681 _ak820_dynamic_read_buffer_PARM_3:
      000B41                        682 	.ds 2
      000B43                        683 _ak820_dynamic_read_buffer_PARM_4:
      000B43                        684 	.ds 2
      000B45                        685 _ak820_dynamic_read_buffer_PARM_5:
      000B45                        686 	.ds 3
      000B48                        687 _ak820_dynamic_read_buffer_base_10000_411:
      000B48                        688 	.ds 2
      000B4A                        689 _ak820_dynamic_read_buffer_available_10000_412:
      000B4A                        690 	.ds 1
      000B4B                        691 _dynamic_keymap_get_buffer_PARM_2:
      000B4B                        692 	.ds 2
      000B4D                        693 _dynamic_keymap_get_buffer_PARM_3:
      000B4D                        694 	.ds 3
      000B50                        695 _dynamic_keymap_get_buffer_offset_10000_418:
      000B50                        696 	.ds 2
      000B52                        697 _dynamic_keymap_set_buffer_PARM_2:
      000B52                        698 	.ds 2
      000B54                        699 _dynamic_keymap_set_buffer_PARM_3:
      000B54                        700 	.ds 3
      000B57                        701 _dynamic_keymap_set_buffer_offset_10000_420:
      000B57                        702 	.ds 2
      000B59                        703 _dynamic_keymap_set_buffer_chk_offset_30001_427:
      000B59                        704 	.ds 1
      000B5A                        705 _dynamic_keymap_set_buffer_chk_sz_30001_427:
      000B5A                        706 	.ds 1
      000B5B                        707 _dynamic_keymap_set_buffer_i_40001_434:
      000B5B                        708 	.ds 1
      000B5C                        709 _keycode_at_keymap_location_PARM_2:
      000B5C                        710 	.ds 1
      000B5D                        711 _keycode_at_keymap_location_PARM_3:
      000B5D                        712 	.ds 1
      000B5E                        713 _keycode_at_keymap_location_layer_num_10000_438:
      000B5E                        714 	.ds 1
      000B5F                        715 _keycode_at_encodermap_location_PARM_2:
      000B5F                        716 	.ds 1
      000B60                        717 _keycode_at_encodermap_location_PARM_3:
      000B60                        718 	.ds 1
      000B61                        719 _keycode_at_encodermap_location_layer_num_10000_442:
      000B61                        720 	.ds 1
      000B62                        721 _dynamic_keymap_macro_get_buffer_PARM_2:
      000B62                        722 	.ds 2
      000B64                        723 _dynamic_keymap_macro_get_buffer_PARM_3:
      000B64                        724 	.ds 3
      000B67                        725 _dynamic_keymap_macro_get_buffer_offset_10000_450:
      000B67                        726 	.ds 2
      000B69                        727 _dynamic_keymap_macro_set_buffer_PARM_2:
      000B69                        728 	.ds 2
      000B6B                        729 _dynamic_keymap_macro_set_buffer_PARM_3:
      000B6B                        730 	.ds 3
      000B6E                        731 _dynamic_keymap_macro_set_buffer_offset_10000_452:
      000B6E                        732 	.ds 2
      000B70                        733 _decode_keycode_kc_10000_456:
      000B70                        734 	.ds 2
      000B72                        735 _dynamic_keymap_macro_send_id_10000_459:
      000B72                        736 	.ds 1
      000B73                        737 _dynamic_keymap_macro_send_sending_10000_460:
      000B73                        738 	.ds 1
      000B74                        739 _dynamic_keymap_macro_send_p_10001_465:
      000B74                        740 	.ds 2
      000B76                        741 _dynamic_keymap_macro_send_data_10003_472:
      000B76                        742 	.ds 4
                                    743 ;--------------------------------------------------------
                                    744 ; absolute external ram data
                                    745 ;--------------------------------------------------------
                                    746 	.area XABS    (ABS,XDATA)
                                    747 ;--------------------------------------------------------
                                    748 ; initialized external ram data
                                    749 ;--------------------------------------------------------
                                    750 	.area XISEG   (XDATA)
                                    751 	.area HOME    (CODE)
                                    752 	.area GSINIT0 (CODE)
                                    753 	.area GSINIT1 (CODE)
                                    754 	.area GSINIT2 (CODE)
                                    755 	.area GSINIT3 (CODE)
                                    756 	.area GSINIT4 (CODE)
                                    757 	.area GSINIT5 (CODE)
                                    758 	.area GSINIT  (CODE)
                                    759 	.area GSFINAL (CODE)
                                    760 	.area CSEG    (CODE)
                                    761 ;--------------------------------------------------------
                                    762 ; global & static initialisations
                                    763 ;--------------------------------------------------------
                                    764 	.area HOME    (CODE)
                                    765 	.area GSINIT  (CODE)
                                    766 	.area GSFINAL (CODE)
                                    767 	.area GSINIT  (CODE)
                                    768 ;--------------------------------------------------------
                                    769 ; Home
                                    770 ;--------------------------------------------------------
                                    771 	.area HOME    (CODE)
                                    772 	.area HOME    (CODE)
                                    773 ;--------------------------------------------------------
                                    774 ; code
                                    775 ;--------------------------------------------------------
                                    776 	.area CSEG    (CODE)
                                    777 ;------------------------------------------------------------
                                    778 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    779 ;------------------------------------------------------------
                                    780 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_230'
                                    781 ;------------------------------------------------------------
                                    782 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    783 ;	-----------------------------------------
                           000007   784 	ar7 = 0x07
                           000006   785 	ar6 = 0x06
                           000005   786 	ar5 = 0x05
                           000004   787 	ar4 = 0x04
                           000003   788 	ar3 = 0x03
                           000002   789 	ar2 = 0x02
                           000001   790 	ar1 = 0x01
                           000000   791 	ar0 = 0x00
                                    792 ;	 function dynamic_keymap_get_layer_count
                                    793 ;	-----------------------------------------
      0088E9                        794 _dynamic_keymap_get_layer_count:
                                    795 ;	quantum/dynamic_keymap.c:178: return DYNAMIC_KEYMAP_LAYER_COUNT;
      0088E9 75 82 06         [24]  796 	mov	dpl, #0x06
                                    797 ;	quantum/dynamic_keymap.c:179: }
      0088EC 22               [24]  798 	ret
                                    799 ;------------------------------------------------------------
                                    800 ;Allocation info for local variables in function 'dynamic_keymap_key_to_eeprom_address'
                                    801 ;------------------------------------------------------------
                                    802 ;row           Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_2'
                                    803 ;column        Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_3'
                                    804 ;layer         Allocated with name '_dynamic_keymap_key_to_eeprom_address_layer_10000_366'
                                    805 ;------------------------------------------------------------
                                    806 ;	quantum/dynamic_keymap.c:181: void *dynamic_keymap_key_to_eeprom_address(uint8_t layer, uint8_t row, uint8_t column) {
                                    807 ;	-----------------------------------------
                                    808 ;	 function dynamic_keymap_key_to_eeprom_address
                                    809 ;	-----------------------------------------
      0088ED                        810 _dynamic_keymap_key_to_eeprom_address:
      0088ED E5 82            [12]  811 	mov	a,dpl
      0088EF 90 0B 0F         [24]  812 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_layer_10000_366
      0088F2 F0               [24]  813 	movx	@dptr,a
                                    814 ;	quantum/dynamic_keymap.c:183: return ((uint8_t *)DYNAMIC_KEYMAP_EEPROM_ADDR) + (layer * MATRIX_ROWS * MATRIX_COLS * 2) + (row * MATRIX_COLS * 2) + (column * 2);
      0088F3 E0               [24]  815 	movx	a,@dptr
      0088F4 FF               [12]  816 	mov	r7,a
      0088F5 7E 00            [12]  817 	mov	r6,#0x00
      0088F7 74 40            [12]  818 	mov	a,#0x40
      0088F9 12 45 9C         [24]  819 	lcall	_ak820_outline_0139
      0088FC 7D 00            [12]  820 	mov	r5,#0x00
      0088FE 90 0B 0D         [24]  821 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      008901 E0               [24]  822 	movx	a,@dptr
      008902 75 F0 10         [24]  823 	mov	b,#0x10
      008905 A4               [48]  824 	mul	ab
      008906 2E               [12]  825 	add	a, r6
      008907 FE               [12]  826 	mov	r6,a
      008908 EF               [12]  827 	mov	a,r7
      008909 35 F0            [12]  828 	addc	a, b
      00890B FF               [12]  829 	mov	r7,a
      00890C 90 0B 0E         [24]  830 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      00890F E0               [24]  831 	movx	a,@dptr
      008910 7C 00            [12]  832 	mov	r4,#0x00
      008912 25 E0            [12]  833 	add	a,acc
      008914 FB               [12]  834 	mov	r3,a
      008915 EC               [12]  835 	mov	a,r4
      008916 33               [12]  836 	rlc	a
      008917 FC               [12]  837 	mov	r4,a
      008918 EB               [12]  838 	mov	a,r3
      008919 2E               [12]  839 	add	a, r6
      00891A FE               [12]  840 	mov	r6,a
      00891B EC               [12]  841 	mov	a,r4
      00891C 3F               [12]  842 	addc	a, r7
      00891D FF               [12]  843 	mov	r7,a
      00891E 12 74 44         [24]  844 	lcall	_ak820_outline_0050
                                    845 ;	quantum/dynamic_keymap.c:184: }
      008921 22               [24]  846 	ret
                                    847 ;------------------------------------------------------------
                                    848 ;Allocation info for local variables in function 'dynamic_keymap_get_keycode'
                                    849 ;------------------------------------------------------------
                                    850 ;row           Allocated with name '_dynamic_keymap_get_keycode_PARM_2'
                                    851 ;column        Allocated with name '_dynamic_keymap_get_keycode_PARM_3'
                                    852 ;layer         Allocated with name '_dynamic_keymap_get_keycode_layer_10000_368'
                                    853 ;address       Allocated with name '_dynamic_keymap_get_keycode_address_10001_371'
                                    854 ;keycode       Allocated with name '_dynamic_keymap_get_keycode_keycode_10001_371'
                                    855 ;------------------------------------------------------------
                                    856 ;	quantum/dynamic_keymap.c:186: uint16_t dynamic_keymap_get_keycode(uint8_t layer, uint8_t row, uint8_t column) {
                                    857 ;	-----------------------------------------
                                    858 ;	 function dynamic_keymap_get_keycode
                                    859 ;	-----------------------------------------
      008922                        860 _dynamic_keymap_get_keycode:
      008922 E5 82            [12]  861 	mov	a,dpl
      008924 90 0B 12         [24]  862 	mov	dptr,#_dynamic_keymap_get_keycode_layer_10000_368
      008927 F0               [24]  863 	movx	@dptr,a
                                    864 ;	quantum/dynamic_keymap.c:187: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return KC_NO;
      008928 E0               [24]  865 	movx	a,@dptr
      008929 FF               [12]  866 	mov	r7,a
      00892A BF 06 00         [24]  867 	cjne	r7,#0x06,00121$
      00892D                        868 00121$:
      00892D 50 14            [24]  869 	jnc	00101$
      00892F 90 0B 10         [24]  870 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      008932 E0               [24]  871 	movx	a,@dptr
      008933 FE               [12]  872 	mov	r6,a
      008934 BE 10 00         [24]  873 	cjne	r6,#0x10,00123$
      008937                        874 00123$:
      008937 50 0A            [24]  875 	jnc	00101$
      008939 90 0B 11         [24]  876 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      00893C E0               [24]  877 	movx	a,@dptr
      00893D FD               [12]  878 	mov	r5,a
      00893E BD 08 00         [24]  879 	cjne	r5,#0x08,00125$
      008941                        880 00125$:
      008941 40 04            [24]  881 	jc	00102$
      008943                        882 00101$:
      008943 90 00 00         [24]  883 	mov	dptr,#0x0000
      008946 22               [24]  884 	ret
      008947                        885 00102$:
                                    886 ;	quantum/dynamic_keymap.c:188: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      008947 12 93 5E         [24]  887 	lcall	_ak820_outline_0100
      00894A 11 ED            [12]  888 	acall	_dynamic_keymap_key_to_eeprom_address
                                    889 ;	quantum/dynamic_keymap.c:190: uint16_t keycode = eeprom_read_byte(address) << 8;
      00894C 12 93 72         [24]  890 	lcall	_ak820_outline_0118
      00894F 12 42 B6         [24]  891 	lcall	_eeprom_read_byte
      008952 AB 82            [24]  892 	mov	r3,dpl
      008954 7C 00            [12]  893 	mov	r4,#0x00
                                    894 ;	quantum/dynamic_keymap.c:191: keycode |= eeprom_read_byte(address + 1);
      008956 0D               [12]  895 	inc	r5
      008957 BD 00 01         [24]  896 	cjne	r5,#0x00,00127$
      00895A 0E               [12]  897 	inc	r6
      00895B                        898 00127$:
      00895B 12 72 22         [24]  899 	lcall	_ak820_outline_0059
      00895E 12 42 B6         [24]  900 	lcall	_eeprom_read_byte
      008961 AF 82            [24]  901 	mov	r7, dpl
      008963 7E 00            [12]  902 	mov	r6,#0x00
      008965 EF               [12]  903 	mov	a,r7
      008966 42 04            [12]  904 	orl	ar4,a
      008968 EE               [12]  905 	mov	a,r6
      008969 42 03            [12]  906 	orl	ar3,a
                                    907 ;	quantum/dynamic_keymap.c:192: return keycode;
      00896B 12 45 C3         [24]  908 	lcall	_ak820_outline_0186
                                    909 ;	quantum/dynamic_keymap.c:193: }
      00896E 22               [24]  910 	ret
                                    911 ;------------------------------------------------------------
                                    912 ;Allocation info for local variables in function 'dynamic_keymap_set_keycode'
                                    913 ;------------------------------------------------------------
                                    914 ;row           Allocated with name '_dynamic_keymap_set_keycode_PARM_2'
                                    915 ;column        Allocated with name '_dynamic_keymap_set_keycode_PARM_3'
                                    916 ;keycode       Allocated with name '_dynamic_keymap_set_keycode_PARM_4'
                                    917 ;layer         Allocated with name '_dynamic_keymap_set_keycode_layer_10000_372'
                                    918 ;address       Allocated with name '_dynamic_keymap_set_keycode_address_10001_375'
                                    919 ;------------------------------------------------------------
                                    920 ;	quantum/dynamic_keymap.c:195: void dynamic_keymap_set_keycode(uint8_t layer, uint8_t row, uint8_t column, uint16_t keycode) {
                                    921 ;	-----------------------------------------
                                    922 ;	 function dynamic_keymap_set_keycode
                                    923 ;	-----------------------------------------
      00896F                        924 _dynamic_keymap_set_keycode:
      00896F E5 82            [12]  925 	mov	a,dpl
      008971 90 0B 17         [24]  926 	mov	dptr,#_dynamic_keymap_set_keycode_layer_10000_372
      008974 F0               [24]  927 	movx	@dptr,a
                                    928 ;	quantum/dynamic_keymap.c:196: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return;
      008975 E0               [24]  929 	movx	a,@dptr
      008976 FF               [12]  930 	mov	r7,a
      008977 BF 06 00         [24]  931 	cjne	r7,#0x06,00121$
      00897A                        932 00121$:
      00897A 50 14            [24]  933 	jnc	00101$
      00897C 90 0B 13         [24]  934 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      00897F E0               [24]  935 	movx	a,@dptr
      008980 FE               [12]  936 	mov	r6,a
      008981 BE 10 00         [24]  937 	cjne	r6,#0x10,00123$
      008984                        938 00123$:
      008984 50 0A            [24]  939 	jnc	00101$
      008986 90 0B 14         [24]  940 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      008989 E0               [24]  941 	movx	a,@dptr
      00898A FD               [12]  942 	mov	r5,a
      00898B BD 08 00         [24]  943 	cjne	r5,#0x08,00125$
      00898E                        944 00125$:
      00898E 40 01            [24]  945 	jc	00102$
      008990                        946 00101$:
      008990 22               [24]  947 	ret
      008991                        948 00102$:
                                    949 ;	quantum/dynamic_keymap.c:197: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      008991 12 93 5E         [24]  950 	lcall	_ak820_outline_0100
      008994 11 ED            [12]  951 	acall	_dynamic_keymap_key_to_eeprom_address
      008996 12 93 72         [24]  952 	lcall	_ak820_outline_0118
                                    953 ;	quantum/dynamic_keymap.c:199: eeprom_update_byte(address, (uint8_t)(keycode >> 8));
      008999 90 0B 15         [24]  954 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      00899C E0               [24]  955 	movx	a,@dptr
      00899D FB               [12]  956 	mov	r3,a
      00899E A3               [24]  957 	inc	dptr
      00899F E0               [24]  958 	movx	a,@dptr
      0089A0 90 06 AE         [24]  959 	mov	dptr,#_eeprom_update_byte_PARM_2
      0089A3 12 51 6C         [24]  960 	lcall	_ak820_outline_0034
      0089A6 12 50 57         [24]  961 	lcall	_eeprom_update_byte
                                    962 ;	quantum/dynamic_keymap.c:200: eeprom_update_byte(address + 1, (uint8_t)(keycode & 0xFF));
      0089A9 0D               [12]  963 	inc	r5
      0089AA BD 00 01         [24]  964 	cjne	r5,#0x00,00127$
      0089AD 0E               [12]  965 	inc	r6
      0089AE                        966 00127$:
      0089AE 90 06 AE         [24]  967 	mov	dptr,#_eeprom_update_byte_PARM_2
      0089B1 EB               [12]  968 	mov	a,r3
      0089B2 12 51 6C         [24]  969 	lcall	_ak820_outline_0034
                                    970 ;	quantum/dynamic_keymap.c:201: }
      0089B5 02 50 57         [24]  971 	ljmp	_eeprom_update_byte
                                    972 ;------------------------------------------------------------
                                    973 ;Allocation info for local variables in function 'dynamic_keymap_encoder_to_eeprom_address'
                                    974 ;------------------------------------------------------------
                                    975 ;encoder_id    Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_PARM_2'
                                    976 ;layer         Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_layer_10000_376'
                                    977 ;------------------------------------------------------------
                                    978 ;	quantum/dynamic_keymap.c:204: void *dynamic_keymap_encoder_to_eeprom_address(uint8_t layer, uint8_t encoder_id) {
                                    979 ;	-----------------------------------------
                                    980 ;	 function dynamic_keymap_encoder_to_eeprom_address
                                    981 ;	-----------------------------------------
      0089B8                        982 _dynamic_keymap_encoder_to_eeprom_address:
      0089B8 E5 82            [12]  983 	mov	a,dpl
      0089BA 90 0B 19         [24]  984 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_layer_10000_376
      0089BD F0               [24]  985 	movx	@dptr,a
                                    986 ;	quantum/dynamic_keymap.c:205: return ((uint8_t *)DYNAMIC_KEYMAP_ENCODER_EEPROM_ADDR) + (layer * NUM_ENCODERS * 2 * 2) + (encoder_id * 2 * 2);
      0089BE E0               [24]  987 	movx	a,@dptr
      0089BF 75 F0 04         [24]  988 	mov	b,#0x04
      0089C2 A4               [48]  989 	mul	ab
      0089C3 24 40            [12]  990 	add	a, #0x40
      0089C5 FD               [12]  991 	mov	r5,a
      0089C6 74 06            [12]  992 	mov	a,#0x06
      0089C8 35 F0            [12]  993 	addc	a, b
      0089CA FE               [12]  994 	mov	r6,a
      0089CB 7F 00            [12]  995 	mov	r7,#0x00
      0089CD 90 0B 18         [24]  996 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      0089D0 E0               [24]  997 	movx	a,@dptr
      0089D1 75 F0 04         [24]  998 	mov	b,#0x04
      0089D4 A4               [48]  999 	mul	ab
      0089D5 2D               [12] 1000 	add	a, r5
      0089D6 FD               [12] 1001 	mov	r5,a
      0089D7 EE               [12] 1002 	mov	a,r6
      0089D8 35 F0            [12] 1003 	addc	a, b
      0089DA FE               [12] 1004 	mov	r6,a
      0089DB 12 72 22         [24] 1005 	lcall	_ak820_outline_0059
                                   1006 ;	quantum/dynamic_keymap.c:206: }
      0089DE 22               [24] 1007 	ret
                                   1008 ;------------------------------------------------------------
                                   1009 ;Allocation info for local variables in function 'dynamic_keymap_get_encoder'
                                   1010 ;------------------------------------------------------------
                                   1011 ;encoder_id    Allocated with name '_dynamic_keymap_get_encoder_PARM_2'
                                   1012 ;clockwise     Allocated with name '_dynamic_keymap_get_encoder_PARM_3'
                                   1013 ;layer         Allocated with name '_dynamic_keymap_get_encoder_layer_10000_378'
                                   1014 ;address       Allocated with name '_dynamic_keymap_get_encoder_address_10001_381'
                                   1015 ;keycode       Allocated with name '_dynamic_keymap_get_encoder_keycode_10001_381'
                                   1016 ;------------------------------------------------------------
                                   1017 ;	quantum/dynamic_keymap.c:208: uint16_t dynamic_keymap_get_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise) {
                                   1018 ;	-----------------------------------------
                                   1019 ;	 function dynamic_keymap_get_encoder
                                   1020 ;	-----------------------------------------
      0089DF                       1021 _dynamic_keymap_get_encoder:
      0089DF E5 82            [12] 1022 	mov	a,dpl
      0089E1 90 0B 1C         [24] 1023 	mov	dptr,#_dynamic_keymap_get_encoder_layer_10000_378
      0089E4 F0               [24] 1024 	movx	@dptr,a
                                   1025 ;	quantum/dynamic_keymap.c:209: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return KC_NO;
      0089E5 E0               [24] 1026 	movx	a,@dptr
      0089E6 FF               [12] 1027 	mov	r7,a
      0089E7 BF 06 00         [24] 1028 	cjne	r7,#0x06,00131$
      0089EA                       1029 00131$:
      0089EA 50 0A            [24] 1030 	jnc	00101$
      0089EC 90 0B 1A         [24] 1031 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      0089EF E0               [24] 1032 	movx	a,@dptr
      0089F0 FE               [12] 1033 	mov	r6,a
      0089F1 BE 01 00         [24] 1034 	cjne	r6,#0x01,00133$
      0089F4                       1035 00133$:
      0089F4 40 04            [24] 1036 	jc	00102$
      0089F6                       1037 00101$:
      0089F6 90 00 00         [24] 1038 	mov	dptr,#0x0000
      0089F9 22               [24] 1039 	ret
      0089FA                       1040 00102$:
                                   1041 ;	quantum/dynamic_keymap.c:210: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      0089FA 90 0B 18         [24] 1042 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      0089FD 12 7C 72         [24] 1043 	lcall	_ak820_outline_0191
      008A00 31 B8            [12] 1044 	acall	_dynamic_keymap_encoder_to_eeprom_address
      008A02 12 93 72         [24] 1045 	lcall	_ak820_outline_0118
                                   1046 ;	quantum/dynamic_keymap.c:212: uint16_t keycode = ((uint16_t)eeprom_read_byte(address + (clockwise ? 0 : 2))) << 8;
      008A05 90 0B 1B         [24] 1047 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      008A08 E0               [24] 1048 	movx	a,@dptr
      008A09 FC               [12] 1049 	mov	r4,a
      008A0A E0               [24] 1050 	movx	a,@dptr
      008A0B 60 04            [24] 1051 	jz	00106$
      008A0D 7B 00            [12] 1052 	mov	r3,#0x00
      008A0F 80 02            [24] 1053 	sjmp	00107$
      008A11                       1054 00106$:
      008A11 7B 02            [12] 1055 	mov	r3,#0x02
      008A13                       1056 00107$:
      008A13 EB               [12] 1057 	mov	a,r3
      008A14 12 7B EB         [24] 1058 	lcall	_ak820_outline_0013
      008A17 12 42 B6         [24] 1059 	lcall	_eeprom_read_byte
      008A1A AA 82            [24] 1060 	mov	r2,dpl
      008A1C 7B 00            [12] 1061 	mov	r3,#0x00
                                   1062 ;	quantum/dynamic_keymap.c:213: keycode |= eeprom_read_byte(address + (clockwise ? 0 : 2) + 1);
      008A1E EC               [12] 1063 	mov	a,r4
      008A1F 60 04            [24] 1064 	jz	00108$
      008A21 7C 00            [12] 1065 	mov	r4,#0x00
      008A23 80 02            [24] 1066 	sjmp	00109$
      008A25                       1067 00108$:
      008A25 7C 02            [12] 1068 	mov	r4,#0x02
      008A27                       1069 00109$:
      008A27 EC               [12] 1070 	mov	a,r4
      008A28 12 3A FB         [24] 1071 	lcall	_ak820_outline_0165
      008A2B 0D               [12] 1072 	inc	r5
      008A2C BD 00 01         [24] 1073 	cjne	r5,#0x00,00137$
      008A2F 0E               [12] 1074 	inc	r6
      008A30                       1075 00137$:
      008A30 12 72 22         [24] 1076 	lcall	_ak820_outline_0059
      008A33 12 42 B6         [24] 1077 	lcall	_eeprom_read_byte
      008A36 AF 82            [24] 1078 	mov	r7, dpl
      008A38 7E 00            [12] 1079 	mov	r6,#0x00
      008A3A EF               [12] 1080 	mov	a,r7
      008A3B 42 03            [12] 1081 	orl	ar3,a
      008A3D EE               [12] 1082 	mov	a,r6
      008A3E 42 02            [12] 1083 	orl	ar2,a
                                   1084 ;	quantum/dynamic_keymap.c:214: return keycode;
      008A40 8B 82            [24] 1085 	mov	dpl, r3
      008A42 8A 83            [24] 1086 	mov	dph, r2
                                   1087 ;	quantum/dynamic_keymap.c:215: }
      008A44 22               [24] 1088 	ret
                                   1089 ;------------------------------------------------------------
                                   1090 ;Allocation info for local variables in function 'dynamic_keymap_set_encoder'
                                   1091 ;------------------------------------------------------------
                                   1092 ;sloc0         Allocated with name '_dynamic_keymap_set_encoder_sloc0_1_0'
                                   1093 ;encoder_id    Allocated with name '_dynamic_keymap_set_encoder_PARM_2'
                                   1094 ;clockwise     Allocated with name '_dynamic_keymap_set_encoder_PARM_3'
                                   1095 ;keycode       Allocated with name '_dynamic_keymap_set_encoder_PARM_4'
                                   1096 ;layer         Allocated with name '_dynamic_keymap_set_encoder_layer_10000_382'
                                   1097 ;address       Allocated with name '_dynamic_keymap_set_encoder_address_10001_385'
                                   1098 ;------------------------------------------------------------
                                   1099 ;	quantum/dynamic_keymap.c:217: void dynamic_keymap_set_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise, uint16_t keycode) {
                                   1100 ;	-----------------------------------------
                                   1101 ;	 function dynamic_keymap_set_encoder
                                   1102 ;	-----------------------------------------
      008A45                       1103 _dynamic_keymap_set_encoder:
      008A45 E5 82            [12] 1104 	mov	a,dpl
      008A47 90 0B 21         [24] 1105 	mov	dptr,#_dynamic_keymap_set_encoder_layer_10000_382
      008A4A F0               [24] 1106 	movx	@dptr,a
                                   1107 ;	quantum/dynamic_keymap.c:218: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return;
      008A4B E0               [24] 1108 	movx	a,@dptr
      008A4C FF               [12] 1109 	mov	r7,a
      008A4D BF 06 00         [24] 1110 	cjne	r7,#0x06,00131$
      008A50                       1111 00131$:
      008A50 50 0A            [24] 1112 	jnc	00101$
      008A52 90 0B 1D         [24] 1113 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      008A55 E0               [24] 1114 	movx	a,@dptr
      008A56 FE               [12] 1115 	mov	r6,a
      008A57 BE 01 00         [24] 1116 	cjne	r6,#0x01,00133$
      008A5A                       1117 00133$:
      008A5A 40 01            [24] 1118 	jc	00102$
      008A5C                       1119 00101$:
      008A5C 22               [24] 1120 	ret
      008A5D                       1121 00102$:
                                   1122 ;	quantum/dynamic_keymap.c:219: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      008A5D 90 0B 18         [24] 1123 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      008A60 12 7C 72         [24] 1124 	lcall	_ak820_outline_0191
      008A63 31 B8            [12] 1125 	acall	_dynamic_keymap_encoder_to_eeprom_address
      008A65 12 93 72         [24] 1126 	lcall	_ak820_outline_0118
                                   1127 ;	quantum/dynamic_keymap.c:221: eeprom_update_byte(address + (clockwise ? 0 : 2), (uint8_t)(keycode >> 8));
      008A68 90 0B 1E         [24] 1128 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      008A6B E0               [24] 1129 	movx	a,@dptr
      008A6C FC               [12] 1130 	mov	r4,a
      008A6D E0               [24] 1131 	movx	a,@dptr
      008A6E 60 04            [24] 1132 	jz	00106$
      008A70 7B 00            [12] 1133 	mov	r3,#0x00
      008A72 80 02            [24] 1134 	sjmp	00107$
      008A74                       1135 00106$:
      008A74 7B 02            [12] 1136 	mov	r3,#0x02
      008A76                       1137 00107$:
      008A76 EB               [12] 1138 	mov	a,r3
      008A77 12 93 84         [24] 1139 	lcall	_ak820_outline_0138
      008A7A 8F 03            [24] 1140 	mov	ar3,r7
      008A7C 90 0B 1F         [24] 1141 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008A7F E0               [24] 1142 	movx	a,@dptr
      008A80 F5 29            [12] 1143 	mov	_dynamic_keymap_set_encoder_sloc0_1_0,a
      008A82 A3               [24] 1144 	inc	dptr
      008A83 E0               [24] 1145 	movx	a,@dptr
      008A84 F5 2A            [12] 1146 	mov	(_dynamic_keymap_set_encoder_sloc0_1_0 + 1),a
      008A86 90 06 AE         [24] 1147 	mov	dptr,#_eeprom_update_byte_PARM_2
      008A89 F0               [24] 1148 	movx	@dptr,a
      008A8A 12 45 BE         [24] 1149 	lcall	_ak820_outline_0185
      008A8D 8B F0            [24] 1150 	mov	b, r3
      008A8F 12 50 57         [24] 1151 	lcall	_eeprom_update_byte
                                   1152 ;	quantum/dynamic_keymap.c:222: eeprom_update_byte(address + (clockwise ? 0 : 2) + 1, (uint8_t)(keycode & 0xFF));
      008A92 EC               [12] 1153 	mov	a,r4
      008A93 60 04            [24] 1154 	jz	00108$
      008A95 7C 00            [12] 1155 	mov	r4,#0x00
      008A97 80 02            [24] 1156 	sjmp	00109$
      008A99                       1157 00108$:
      008A99 7C 02            [12] 1158 	mov	r4,#0x02
      008A9B                       1159 00109$:
      008A9B EC               [12] 1160 	mov	a,r4
      008A9C 12 3A FB         [24] 1161 	lcall	_ak820_outline_0165
      008A9F 0D               [12] 1162 	inc	r5
      008AA0 BD 00 01         [24] 1163 	cjne	r5,#0x00,00137$
      008AA3 0E               [12] 1164 	inc	r6
      008AA4                       1165 00137$:
      008AA4 90 06 AE         [24] 1166 	mov	dptr,#_eeprom_update_byte_PARM_2
      008AA7 E5 29            [12] 1167 	mov	a,_dynamic_keymap_set_encoder_sloc0_1_0
      008AA9 12 51 6C         [24] 1168 	lcall	_ak820_outline_0034
                                   1169 ;	quantum/dynamic_keymap.c:223: }
      008AAC 02 50 57         [24] 1170 	ljmp	_eeprom_update_byte
                                   1171 ;------------------------------------------------------------
                                   1172 ;Allocation info for local variables in function 'dynamic_keymap_get_combo'
                                   1173 ;------------------------------------------------------------
                                   1174 ;sloc0         Allocated with name '_dynamic_keymap_get_combo_sloc0_1_0'
                                   1175 ;buffer        Allocated with name '_dynamic_keymap_get_combo_PARM_2'
                                   1176 ;index         Allocated with name '_dynamic_keymap_get_combo_index_10000_386'
                                   1177 ;entry         Allocated with name '_dynamic_keymap_get_combo_entry_10000_387'
                                   1178 ;address       Allocated with name '_dynamic_keymap_get_combo_address_10001_389'
                                   1179 ;marked        Allocated with name '_dynamic_keymap_get_combo_marked_10002_390'
                                   1180 ;------------------------------------------------------------
                                   1181 ;	quantum/dynamic_keymap.c:267: int dynamic_keymap_get_combo(uint8_t index, vial_combo_entry_t *buffer) {
                                   1182 ;	-----------------------------------------
                                   1183 ;	 function dynamic_keymap_get_combo
                                   1184 ;	-----------------------------------------
      008AAF                       1185 _dynamic_keymap_get_combo:
      008AAF E5 82            [12] 1186 	mov	a,dpl
      008AB1 90 0B 25         [24] 1187 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_386
      008AB4 F0               [24] 1188 	movx	@dptr,a
                                   1189 ;	quantum/dynamic_keymap.c:270: vial_combo_entry_t AK820_STATE_MEM *entry = (vial_combo_entry_t AK820_STATE_MEM *)buffer;
      008AB5 90 0B 22         [24] 1190 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      008AB8 12 3A 81         [24] 1191 	lcall	_ak820_outline_0052
                                   1192 ;	quantum/dynamic_keymap.c:274: if (index >= VIAL_COMBO_ENTRIES)
      008ABB 90 0B 25         [24] 1193 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_386
      008ABE E0               [24] 1194 	movx	a,@dptr
      008ABF FD               [12] 1195 	mov	r5,a
      008AC0 BD 08 00         [24] 1196 	cjne	r5,#0x08,00132$
      008AC3                       1197 00132$:
      008AC3 40 04            [24] 1198 	jc	00102$
                                   1199 ;	quantum/dynamic_keymap.c:275: return -1;
      008AC5 90 FF FF         [24] 1200 	mov	dptr,#0xffff
      008AC8 22               [24] 1201 	ret
      008AC9                       1202 00102$:
                                   1203 ;	quantum/dynamic_keymap.c:277: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      008AC9 12 93 4A         [24] 1204 	lcall	_ak820_outline_0080
                                   1205 ;	quantum/dynamic_keymap.c:279: ak820_eeprom_read_block_xdata(entry, address, sizeof(vial_combo_entry_t));
      008ACC 8E 02            [24] 1206 	mov	ar2,r6
      008ACE 8F 03            [24] 1207 	mov	ar3,r7
      008AD0 90 05 95         [24] 1208 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      008AD3 12 3A 9E         [24] 1209 	lcall	_ak820_outline_0072
      008AD6 E4               [12] 1210 	clr	a
      008AD7 A3               [24] 1211 	inc	dptr
      008AD8 F0               [24] 1212 	movx	@dptr,a
      008AD9 90 05 98         [24] 1213 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      008ADC 12 93 6B         [24] 1214 	lcall	_ak820_outline_0113
      008ADF 12 3A EC         [24] 1215 	lcall	_ak820_outline_0147
      008AE2 C0 07            [24] 1216 	push	ar7
      008AE4 C0 06            [24] 1217 	push	ar6
      008AE6 12 42 F1         [24] 1218 	lcall	_ak820_eeprom_read_block_xdata
      008AE9 D0 06            [24] 1219 	pop	ar6
      008AEB D0 07            [24] 1220 	pop	ar7
                                   1221 ;	quantum/dynamic_keymap.c:284: bool marked = entry->input[2] == AK820_COMBO_MARKER && entry->input[3] == AK820_COMBO_VERSION;
      008AED 74 04            [12] 1222 	mov	a,#0x04
      008AEF 12 4A B8         [24] 1223 	lcall	_ak820_outline_0033
      008AF2 FA               [12] 1224 	mov	r2,a
      008AF3 A3               [24] 1225 	inc	dptr
      008AF4 E0               [24] 1226 	movx	a,@dptr
      008AF5 FB               [12] 1227 	mov	r3,a
      008AF6 BA 20 13         [24] 1228 	cjne	r2,#0x20,00108$
      008AF9 BB 08 10         [24] 1229 	cjne	r3,#0x08,00108$
      008AFC 74 06            [12] 1230 	mov	a,#0x06
      008AFE 12 3A 71         [24] 1231 	lcall	_ak820_outline_0021
      008B01 12 45 85         [24] 1232 	lcall	_ak820_outline_0105
      008B04 BA 01 05         [24] 1233 	cjne	r2,#0x01,00136$
      008B07 BB 00 02         [24] 1234 	cjne	r3,#0x00,00136$
      008B0A 80 05            [24] 1235 	sjmp	00109$
      008B0C                       1236 00136$:
      008B0C                       1237 00108$:
      008B0C 75 2B 00         [24] 1238 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x00
      008B0F 80 03            [24] 1239 	sjmp	00110$
      008B11                       1240 00109$:
      008B11 75 2B 01         [24] 1241 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x01
      008B14                       1242 00110$:
                                   1243 ;	quantum/dynamic_keymap.c:285: entry->input[2] = entry->input[3] = 0;
      008B14 74 06            [12] 1244 	mov	a,#0x06
      008B16 12 3A 71         [24] 1245 	lcall	_ak820_outline_0021
      008B19 E4               [12] 1246 	clr	a
      008B1A F0               [24] 1247 	movx	@dptr,a
      008B1B A3               [24] 1248 	inc	dptr
      008B1C 12 3A B6         [24] 1249 	lcall	_ak820_outline_0101
      008B1F F0               [24] 1250 	movx	@dptr,a
      008B20 A3               [24] 1251 	inc	dptr
      008B21 F0               [24] 1252 	movx	@dptr,a
                                   1253 ;	quantum/dynamic_keymap.c:286: if (!marked || !ak820_combo_valid(entry)) memset(entry, 0, sizeof(*entry));
      008B22 E5 2B            [12] 1254 	mov	a,_dynamic_keymap_get_combo_sloc0_1_0
      008B24 60 12            [24] 1255 	jz	00103$
      008B26 12 3A CC         [24] 1256 	lcall	_ak820_outline_0120
      008B29 C0 07            [24] 1257 	push	ar7
      008B2B C0 06            [24] 1258 	push	ar6
      008B2D 12 37 1B         [24] 1259 	lcall	_ak820_combo_valid
      008B30 E5 82            [12] 1260 	mov	a, dpl
      008B32 D0 06            [24] 1261 	pop	ar6
      008B34 D0 07            [24] 1262 	pop	ar7
      008B36 70 13            [24] 1263 	jnz	00104$
      008B38                       1264 00103$:
      008B38 7D 00            [12] 1265 	mov	r5,#0x00
      008B3A 90 0D DD         [24] 1266 	mov	dptr,#_memset_PARM_2
      008B3D E4               [12] 1267 	clr	a
      008B3E F0               [24] 1268 	movx	@dptr,a
      008B3F 90 0D DE         [24] 1269 	mov	dptr,#_memset_PARM_3
      008B42 12 93 6B         [24] 1270 	lcall	_ak820_outline_0113
      008B45 12 74 44         [24] 1271 	lcall	_ak820_outline_0050
      008B48 12 BD 76         [24] 1272 	lcall	_memset
      008B4B                       1273 00104$:
                                   1274 ;	quantum/dynamic_keymap.c:289: return 0;
      008B4B 90 00 00         [24] 1275 	mov	dptr,#0x0000
                                   1276 ;	quantum/dynamic_keymap.c:290: }
      008B4E 22               [24] 1277 	ret
                                   1278 ;------------------------------------------------------------
                                   1279 ;Allocation info for local variables in function 'dynamic_keymap_set_combo'
                                   1280 ;------------------------------------------------------------
                                   1281 ;buffer        Allocated with name '_dynamic_keymap_set_combo_PARM_2'
                                   1282 ;index         Allocated with name '_dynamic_keymap_set_combo_index_10000_392'
                                   1283 ;entry         Allocated with name '_dynamic_keymap_set_combo_entry_10000_393'
                                   1284 ;address       Allocated with name '_dynamic_keymap_set_combo_address_10001_396'
                                   1285 ;stored        Allocated with name '_dynamic_keymap_set_combo_stored_10002_397'
                                   1286 ;------------------------------------------------------------
                                   1287 ;	quantum/dynamic_keymap.c:292: int dynamic_keymap_set_combo(uint8_t index, const vial_combo_entry_t *buffer) {
                                   1288 ;	-----------------------------------------
                                   1289 ;	 function dynamic_keymap_set_combo
                                   1290 ;	-----------------------------------------
      008B4F                       1291 _dynamic_keymap_set_combo:
      008B4F E5 82            [12] 1292 	mov	a,dpl
      008B51 90 0B 29         [24] 1293 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_392
      008B54 F0               [24] 1294 	movx	@dptr,a
                                   1295 ;	quantum/dynamic_keymap.c:294: const vial_combo_entry_t AK820_STATE_MEM *entry = (const vial_combo_entry_t AK820_STATE_MEM *)buffer;
      008B55 90 0B 26         [24] 1296 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      008B58 12 3A 34         [24] 1297 	lcall	_ak820_outline_0005
                                   1298 ;	quantum/dynamic_keymap.c:299: if (!ak820_combo_valid(entry) || !ak820_nvm_ok()) return -1;
      008B5B C0 07            [24] 1299 	push	ar7
      008B5D C0 06            [24] 1300 	push	ar6
      008B5F 12 37 1B         [24] 1301 	lcall	_ak820_combo_valid
      008B62 E5 82            [12] 1302 	mov	a, dpl
      008B64 D0 06            [24] 1303 	pop	ar6
      008B66 D0 07            [24] 1304 	pop	ar7
      008B68 60 07            [24] 1305 	jz	00101$
      008B6A 12 40 5C         [24] 1306 	lcall	_ak820_nvm_ok
      008B6D E5 82            [12] 1307 	mov	a, dpl
      008B6F 70 04            [24] 1308 	jnz	00102$
      008B71                       1309 00101$:
      008B71 90 FF FF         [24] 1310 	mov	dptr,#0xffff
      008B74 22               [24] 1311 	ret
      008B75                       1312 00102$:
                                   1313 ;	quantum/dynamic_keymap.c:301: if (index >= VIAL_COMBO_ENTRIES)
      008B75 90 0B 29         [24] 1314 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_392
      008B78 E0               [24] 1315 	movx	a,@dptr
      008B79 FD               [12] 1316 	mov	r5,a
      008B7A BD 08 00         [24] 1317 	cjne	r5,#0x08,00133$
      008B7D                       1318 00133$:
      008B7D 40 04            [24] 1319 	jc	00105$
                                   1320 ;	quantum/dynamic_keymap.c:302: return -1;
      008B7F 90 FF FF         [24] 1321 	mov	dptr,#0xffff
      008B82 22               [24] 1322 	ret
      008B83                       1323 00105$:
                                   1324 ;	quantum/dynamic_keymap.c:304: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      008B83 12 93 4A         [24] 1325 	lcall	_ak820_outline_0080
                                   1326 ;	quantum/dynamic_keymap.c:306: clear_keyboard();
      008B86 C0 07            [24] 1327 	push	ar7
      008B88 C0 06            [24] 1328 	push	ar6
      008B8A C0 05            [24] 1329 	push	ar5
      008B8C C0 04            [24] 1330 	push	ar4
      008B8E 12 7B 9D         [24] 1331 	lcall	_clear_keyboard
      008B91 D0 04            [24] 1332 	pop	ar4
      008B93 D0 05            [24] 1333 	pop	ar5
      008B95 D0 06            [24] 1334 	pop	ar6
      008B97 D0 07            [24] 1335 	pop	ar7
                                   1336 ;	quantum/dynamic_keymap.c:307: vial_combo_entry_t stored = *entry;
      008B99 90 0D D5         [24] 1337 	mov	dptr,#___memcpy_PARM_2
      008B9C 12 4A CB         [24] 1338 	lcall	_ak820_outline_0060
      008B9F E4               [12] 1339 	clr	a
      008BA0 A3               [24] 1340 	inc	dptr
      008BA1 F0               [24] 1341 	movx	@dptr,a
      008BA2 90 0D D8         [24] 1342 	mov	dptr,#___memcpy_PARM_3
      008BA5 12 93 6B         [24] 1343 	lcall	_ak820_outline_0113
      008BA8 90 0B 2A         [24] 1344 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_397
      008BAB F5 F0            [12] 1345 	mov	b,a
      008BAD C0 05            [24] 1346 	push	ar5
      008BAF C0 04            [24] 1347 	push	ar4
      008BB1 12 BD 00         [24] 1348 	lcall	___memcpy
      008BB4 D0 04            [24] 1349 	pop	ar4
      008BB6 D0 05            [24] 1350 	pop	ar5
                                   1351 ;	quantum/dynamic_keymap.c:308: stored.input[2] = AK820_COMBO_MARKER;
      008BB8 90 0B 2E         [24] 1352 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_397 + 0x0004)
      008BBB 74 20            [12] 1353 	mov	a,#0x20
      008BBD F0               [24] 1354 	movx	@dptr,a
      008BBE 74 08            [12] 1355 	mov	a,#0x08
      008BC0 A3               [24] 1356 	inc	dptr
      008BC1 F0               [24] 1357 	movx	@dptr,a
                                   1358 ;	quantum/dynamic_keymap.c:309: stored.input[3] = AK820_COMBO_VERSION;
      008BC2 90 0B 30         [24] 1359 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_397 + 0x0006)
      008BC5 74 01            [12] 1360 	mov	a,#0x01
      008BC7 12 3A E1         [24] 1361 	lcall	_ak820_outline_0137
                                   1362 ;	quantum/dynamic_keymap.c:310: ak820_eeprom_write_block_xdata(&stored, address, sizeof(stored));
      008BCA 90 05 9E         [24] 1363 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      008BCD 12 3A 9E         [24] 1364 	lcall	_ak820_outline_0072
      008BD0 E4               [12] 1365 	clr	a
      008BD1 A3               [24] 1366 	inc	dptr
      008BD2 F0               [24] 1367 	movx	@dptr,a
      008BD3 90 05 A1         [24] 1368 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      008BD6 12 93 6B         [24] 1369 	lcall	_ak820_outline_0113
      008BD9 90 0B 2A         [24] 1370 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_397
      008BDC 12 43 7D         [24] 1371 	lcall	_ak820_eeprom_write_block_xdata
                                   1372 ;	quantum/dynamic_keymap.c:315: ak820_nvm_flush();
      008BDF 12 40 6B         [24] 1373 	lcall	_ak820_nvm_flush
                                   1374 ;	quantum/dynamic_keymap.c:316: if (!ak820_nvm_ok()) return -1;
      008BE2 12 40 5C         [24] 1375 	lcall	_ak820_nvm_ok
      008BE5 E5 82            [12] 1376 	mov	a, dpl
      008BE7 70 04            [24] 1377 	jnz	00107$
      008BE9 90 FF FF         [24] 1378 	mov	dptr,#0xffff
      008BEC 22               [24] 1379 	ret
      008BED                       1380 00107$:
                                   1381 ;	quantum/dynamic_keymap.c:320: return 0;
      008BED 90 00 00         [24] 1382 	mov	dptr,#0x0000
                                   1383 ;	quantum/dynamic_keymap.c:321: }
      008BF0 22               [24] 1384 	ret
                                   1385 ;------------------------------------------------------------
                                   1386 ;Allocation info for local variables in function 'dynamic_keymap_reset'
                                   1387 ;------------------------------------------------------------
                                   1388 ;vial_unlocked_prev Allocated with name '_dynamic_keymap_reset_vial_unlocked_prev_10000_400'
                                   1389 ;layer         Allocated with name '_dynamic_keymap_reset_layer_20000_401'
                                   1390 ;row           Allocated with name '_dynamic_keymap_reset_row_40000_403'
                                   1391 ;column        Allocated with name '_dynamic_keymap_reset_column_60000_405'
                                   1392 ;encoder       Allocated with name '_dynamic_keymap_reset_encoder_40000_407'
                                   1393 ;combo         Allocated with name '_dynamic_keymap_reset_combo_10001_409'
                                   1394 ;i             Allocated with name '_dynamic_keymap_reset_i_20001_410'
                                   1395 ;------------------------------------------------------------
                                   1396 ;	quantum/dynamic_keymap.c:346: void dynamic_keymap_reset(void) {
                                   1397 ;	-----------------------------------------
                                   1398 ;	 function dynamic_keymap_reset
                                   1399 ;	-----------------------------------------
      008BF1                       1400 _dynamic_keymap_reset:
                                   1401 ;	quantum/dynamic_keymap.c:357: bool vial_unlocked_prev = vial_unlocked;
      008BF1 90 0E 56         [24] 1402 	mov	dptr,#_vial_unlocked
      008BF4 E0               [24] 1403 	movx	a,@dptr
      008BF5 90 0B 34         [24] 1404 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_400
      008BF8 F0               [24] 1405 	movx	@dptr,a
                                   1406 ;	quantum/dynamic_keymap.c:358: vial_unlocked = 1;
      008BF9 90 0E 56         [24] 1407 	mov	dptr,#_vial_unlocked
      008BFC 74 01            [12] 1408 	mov	a,#0x01
      008BFE F0               [24] 1409 	movx	@dptr,a
                                   1410 ;	quantum/dynamic_keymap.c:362: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      008BFF 7F 00            [12] 1411 	mov	r7,#0x00
      008C01                       1412 00116$:
      008C01 BF 06 00         [24] 1413 	cjne	r7,#0x06,00198$
      008C04                       1414 00198$:
      008C04 40 02            [24] 1415 	jc	00199$
      008C06 81 AF            [12] 1416 	ajmp	00104$
      008C08                       1417 00199$:
                                   1418 ;	quantum/dynamic_keymap.c:363: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      008C08 7E 00            [12] 1419 	mov	r6,#0x00
      008C0A                       1420 00110$:
      008C0A BE 10 00         [24] 1421 	cjne	r6,#0x10,00200$
      008C0D                       1422 00200$:
      008C0D 50 4C            [24] 1423 	jnc	00102$
                                   1424 ;	quantum/dynamic_keymap.c:364: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      008C0F 7D 00            [12] 1425 	mov	r5,#0x00
      008C11                       1426 00107$:
      008C11 BD 08 00         [24] 1427 	cjne	r5,#0x08,00202$
      008C14                       1428 00202$:
      008C14 50 42            [24] 1429 	jnc	00111$
                                   1430 ;	quantum/dynamic_keymap.c:365: dynamic_keymap_set_keycode(layer, row, column, keycode_at_keymap_location_raw(layer, row, column));
      008C16 90 0B D0         [24] 1431 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_2
      008C19 EE               [12] 1432 	mov	a,r6
      008C1A F0               [24] 1433 	movx	@dptr,a
      008C1B 90 0B D1         [24] 1434 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_3
      008C1E ED               [12] 1435 	mov	a,r5
      008C1F F0               [24] 1436 	movx	@dptr,a
      008C20 8F 82            [24] 1437 	mov	dpl, r7
      008C22 C0 07            [24] 1438 	push	ar7
      008C24 C0 06            [24] 1439 	push	ar6
      008C26 C0 05            [24] 1440 	push	ar5
      008C28 12 9B 81         [24] 1441 	lcall	_keycode_at_keymap_location_raw
      008C2B AB 82            [24] 1442 	mov	r3, dpl
      008C2D AC 83            [24] 1443 	mov	r4, dph
      008C2F D0 05            [24] 1444 	pop	ar5
      008C31 D0 06            [24] 1445 	pop	ar6
      008C33 D0 07            [24] 1446 	pop	ar7
      008C35 90 0B 13         [24] 1447 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      008C38 EE               [12] 1448 	mov	a,r6
      008C39 F0               [24] 1449 	movx	@dptr,a
      008C3A 90 0B 14         [24] 1450 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      008C3D ED               [12] 1451 	mov	a,r5
      008C3E F0               [24] 1452 	movx	@dptr,a
      008C3F 90 0B 15         [24] 1453 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      008C42 12 3A A4         [24] 1454 	lcall	_ak820_outline_0084
      008C45 8F 82            [24] 1455 	mov	dpl, r7
      008C47 C0 07            [24] 1456 	push	ar7
      008C49 C0 06            [24] 1457 	push	ar6
      008C4B C0 05            [24] 1458 	push	ar5
      008C4D 31 6F            [12] 1459 	acall	_dynamic_keymap_set_keycode
      008C4F D0 05            [24] 1460 	pop	ar5
      008C51 D0 06            [24] 1461 	pop	ar6
      008C53 D0 07            [24] 1462 	pop	ar7
                                   1463 ;	quantum/dynamic_keymap.c:364: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      008C55 0D               [12] 1464 	inc	r5
      008C56 80 B9            [24] 1465 	sjmp	00107$
      008C58                       1466 00111$:
                                   1467 ;	quantum/dynamic_keymap.c:363: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      008C58 0E               [12] 1468 	inc	r6
      008C59 80 AF            [24] 1469 	sjmp	00110$
      008C5B                       1470 00102$:
                                   1471 ;	quantum/dynamic_keymap.c:369: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      008C5B 7E 00            [12] 1472 	mov	r6,#0x00
      008C5D                       1473 00113$:
      008C5D BE 01 00         [24] 1474 	cjne	r6,#0x01,00204$
      008C60                       1475 00204$:
      008C60 50 4A            [24] 1476 	jnc	00117$
                                   1477 ;	quantum/dynamic_keymap.c:370: dynamic_keymap_set_encoder(layer, encoder, true, keycode_at_encodermap_location_raw(layer, encoder, true));
      008C62 12 93 A0         [24] 1478 	lcall	_ak820_outline_0180
      008C65 04               [12] 1479 	inc	a
      008C66 F0               [24] 1480 	movx	@dptr,a
      008C67 8F 82            [24] 1481 	mov	dpl, r7
      008C69 C0 07            [24] 1482 	push	ar7
      008C6B 12 9B C6         [24] 1483 	lcall	_keycode_at_encodermap_location_raw
      008C6E 12 45 A8         [24] 1484 	lcall	_ak820_outline_0154
      008C71 D0 07            [24] 1485 	pop	ar7
      008C73 12 93 97         [24] 1486 	lcall	_ak820_outline_0179
      008C76 04               [12] 1487 	inc	a
      008C77 F0               [24] 1488 	movx	@dptr,a
      008C78 90 0B 1F         [24] 1489 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008C7B 12 3A 9E         [24] 1490 	lcall	_ak820_outline_0072
      008C7E 8F 82            [24] 1491 	mov	dpl, r7
      008C80 C0 07            [24] 1492 	push	ar7
      008C82 51 45            [24] 1493 	acall	_dynamic_keymap_set_encoder
      008C84 D0 07            [24] 1494 	pop	ar7
                                   1495 ;	quantum/dynamic_keymap.c:371: dynamic_keymap_set_encoder(layer, encoder, false, keycode_at_encodermap_location_raw(layer, encoder, false));
      008C86 12 93 A0         [24] 1496 	lcall	_ak820_outline_0180
      008C89 F0               [24] 1497 	movx	@dptr,a
      008C8A 8F 82            [24] 1498 	mov	dpl, r7
      008C8C C0 07            [24] 1499 	push	ar7
      008C8E 12 9B C6         [24] 1500 	lcall	_keycode_at_encodermap_location_raw
      008C91 12 45 A8         [24] 1501 	lcall	_ak820_outline_0154
      008C94 D0 07            [24] 1502 	pop	ar7
      008C96 12 93 97         [24] 1503 	lcall	_ak820_outline_0179
      008C99 F0               [24] 1504 	movx	@dptr,a
      008C9A 90 0B 1F         [24] 1505 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008C9D 12 3A 9E         [24] 1506 	lcall	_ak820_outline_0072
      008CA0 8F 82            [24] 1507 	mov	dpl, r7
      008CA2 C0 07            [24] 1508 	push	ar7
      008CA4 51 45            [24] 1509 	acall	_dynamic_keymap_set_encoder
      008CA6 D0 07            [24] 1510 	pop	ar7
                                   1511 ;	quantum/dynamic_keymap.c:369: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      008CA8 7E 01            [12] 1512 	mov	r6,#0x01
      008CAA 80 B1            [24] 1513 	sjmp	00113$
      008CAC                       1514 00117$:
                                   1515 ;	quantum/dynamic_keymap.c:362: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      008CAC 0F               [12] 1516 	inc	r7
      008CAD 81 01            [12] 1517 	ajmp	00116$
      008CAF                       1518 00104$:
                                   1519 ;	quantum/dynamic_keymap.c:388: vial_combo_entry_t combo = { { 0 }, 0 };
      008CAF 90 0B 35         [24] 1520 	mov	dptr,#_dynamic_keymap_reset_combo_10001_409
      008CB2 12 51 B6         [24] 1521 	lcall	_ak820_outline_0184
      008CB5 90 0B 37         [24] 1522 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_409 + 0x0002)
      008CB8 F0               [24] 1523 	movx	@dptr,a
      008CB9 A3               [24] 1524 	inc	dptr
      008CBA F0               [24] 1525 	movx	@dptr,a
      008CBB 90 0B 39         [24] 1526 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_409 + 0x0004)
      008CBE F0               [24] 1527 	movx	@dptr,a
      008CBF A3               [24] 1528 	inc	dptr
      008CC0 F0               [24] 1529 	movx	@dptr,a
      008CC1 90 0B 3B         [24] 1530 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_409 + 0x0006)
      008CC4 F0               [24] 1531 	movx	@dptr,a
      008CC5 A3               [24] 1532 	inc	dptr
      008CC6 F0               [24] 1533 	movx	@dptr,a
      008CC7 90 0B 3D         [24] 1534 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_409 + 0x0008)
      008CCA F0               [24] 1535 	movx	@dptr,a
      008CCB A3               [24] 1536 	inc	dptr
      008CCC F0               [24] 1537 	movx	@dptr,a
                                   1538 ;	quantum/dynamic_keymap.c:389: for (size_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      008CCD FF               [12] 1539 	mov	r7,a
      008CCE                       1540 00119$:
      008CCE BF 08 00         [24] 1541 	cjne	r7,#0x08,00206$
      008CD1                       1542 00206$:
      008CD1 50 18            [24] 1543 	jnc	00105$
                                   1544 ;	quantum/dynamic_keymap.c:390: dynamic_keymap_set_combo(i, &combo);
      008CD3 8F 06            [24] 1545 	mov	ar6,r7
      008CD5 90 0B 26         [24] 1546 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      008CD8 74 35            [12] 1547 	mov	a,#_dynamic_keymap_reset_combo_10001_409
      008CDA F0               [24] 1548 	movx	@dptr,a
      008CDB 74 0B            [12] 1549 	mov	a,#(_dynamic_keymap_reset_combo_10001_409 >> 8)
      008CDD 12 3A B0         [24] 1550 	lcall	_ak820_outline_0093
      008CE0 8E 82            [24] 1551 	mov	dpl, r6
      008CE2 C0 07            [24] 1552 	push	ar7
      008CE4 71 4F            [24] 1553 	acall	_dynamic_keymap_set_combo
      008CE6 D0 07            [24] 1554 	pop	ar7
                                   1555 ;	quantum/dynamic_keymap.c:389: for (size_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      008CE8 0F               [12] 1556 	inc	r7
      008CE9 80 E3            [24] 1557 	sjmp	00119$
      008CEB                       1558 00105$:
                                   1559 ;	quantum/dynamic_keymap.c:403: vial_unlocked = vial_unlocked_prev;
      008CEB 90 0B 34         [24] 1560 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_400
      008CEE E0               [24] 1561 	movx	a,@dptr
      008CEF 90 0E 56         [24] 1562 	mov	dptr,#_vial_unlocked
      008CF2 F0               [24] 1563 	movx	@dptr,a
                                   1564 ;	quantum/dynamic_keymap.c:405: }
      008CF3 22               [24] 1565 	ret
                                   1566 ;------------------------------------------------------------
                                   1567 ;Allocation info for local variables in function 'ak820_dynamic_read_buffer'
                                   1568 ;------------------------------------------------------------
                                   1569 ;sloc0         Allocated with name '_ak820_dynamic_read_buffer_sloc0_1_0'
                                   1570 ;limit         Allocated with name '_ak820_dynamic_read_buffer_PARM_2'
                                   1571 ;offset        Allocated with name '_ak820_dynamic_read_buffer_PARM_3'
                                   1572 ;size          Allocated with name '_ak820_dynamic_read_buffer_PARM_4'
                                   1573 ;data          Allocated with name '_ak820_dynamic_read_buffer_PARM_5'
                                   1574 ;base          Allocated with name '_ak820_dynamic_read_buffer_base_10000_411'
                                   1575 ;target        Allocated with name '_ak820_dynamic_read_buffer_target_10000_412'
                                   1576 ;available     Allocated with name '_ak820_dynamic_read_buffer_available_10000_412'
                                   1577 ;remaining     Allocated with name '_ak820_dynamic_read_buffer_remaining_30000_415'
                                   1578 ;i             Allocated with name '_ak820_dynamic_read_buffer_i_20000_417'
                                   1579 ;------------------------------------------------------------
                                   1580 ;	quantum/dynamic_keymap.c:410: static void ak820_dynamic_read_buffer(uint16_t base, uint16_t limit, uint16_t offset, uint16_t size, uint8_t *data) {
                                   1581 ;	-----------------------------------------
                                   1582 ;	 function ak820_dynamic_read_buffer
                                   1583 ;	-----------------------------------------
      008CF4                       1584 _ak820_dynamic_read_buffer:
      008CF4 12 3A C2         [24] 1585 	lcall	_ak820_outline_0109
      008CF7 90 0B 48         [24] 1586 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_411
      008CFA 12 3A C7         [24] 1587 	lcall	_ak820_outline_0110
                                   1588 ;	quantum/dynamic_keymap.c:411: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      008CFD 90 0B 45         [24] 1589 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008D00 12 3A 81         [24] 1590 	lcall	_ak820_outline_0052
                                   1591 ;	quantum/dynamic_keymap.c:412: uint8_t available = 0;
      008D03 90 0B 4A         [24] 1592 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_412
      008D06 E4               [12] 1593 	clr	a
      008D07 F0               [24] 1594 	movx	@dptr,a
                                   1595 ;	quantum/dynamic_keymap.c:413: if (size > 28) return;
      008D08 90 0B 43         [24] 1596 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008D0B 12 3A 98         [24] 1597 	lcall	_ak820_outline_0061
      008D0E 8C 02            [24] 1598 	mov	ar2,r4
      008D10 8D 03            [24] 1599 	mov	ar3,r5
      008D12 C3               [12] 1600 	clr	c
      008D13 74 1C            [12] 1601 	mov	a,#0x1c
      008D15 9A               [12] 1602 	subb	a,r2
      008D16 E4               [12] 1603 	clr	a
      008D17 9B               [12] 1604 	subb	a,r3
      008D18 50 01            [24] 1605 	jnc	00102$
                                   1606 ;	free result
      008D1A 22               [24] 1607 	ret
      008D1B                       1608 00102$:
                                   1609 ;	quantum/dynamic_keymap.c:414: if (offset < limit) {
      008D1B 90 0B 41         [24] 1610 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008D1E 12 45 85         [24] 1611 	lcall	_ak820_outline_0105
      008D21 90 0B 3F         [24] 1612 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008D24 12 3A BC         [24] 1613 	lcall	_ak820_outline_0104
      008D27 C3               [12] 1614 	clr	c
      008D28 EA               [12] 1615 	mov	a,r2
      008D29 98               [12] 1616 	subb	a,r0
      008D2A EB               [12] 1617 	mov	a,r3
      008D2B 99               [12] 1618 	subb	a,r1
      008D2C 50 17            [24] 1619 	jnc	00104$
                                   1620 ;	quantum/dynamic_keymap.c:415: uint16_t remaining = limit - offset;
      008D2E E8               [12] 1621 	mov	a,r0
      008D2F C3               [12] 1622 	clr	c
      008D30 9A               [12] 1623 	subb	a,r2
      008D31 F8               [12] 1624 	mov	r0,a
      008D32 E9               [12] 1625 	mov	a,r1
      008D33 9B               [12] 1626 	subb	a,r3
      008D34 F9               [12] 1627 	mov	r1,a
                                   1628 ;	quantum/dynamic_keymap.c:416: available = remaining < size ? remaining : size;
      008D35 C3               [12] 1629 	clr	c
      008D36 E8               [12] 1630 	mov	a,r0
      008D37 9C               [12] 1631 	subb	a,r4
      008D38 E9               [12] 1632 	mov	a,r1
      008D39 9D               [12] 1633 	subb	a,r5
      008D3A 40 04            [24] 1634 	jc	00114$
      008D3C 8C 00            [24] 1635 	mov	ar0,r4
      008D3E 8D 01            [24] 1636 	mov	ar1,r5
      008D40                       1637 00114$:
      008D40 90 0B 4A         [24] 1638 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_412
      008D43 E8               [12] 1639 	mov	a,r0
      008D44 F0               [24] 1640 	movx	@dptr,a
      008D45                       1641 00104$:
                                   1642 ;	quantum/dynamic_keymap.c:418: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      008D45 90 0B 4A         [24] 1643 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_412
      008D48 E0               [24] 1644 	movx	a,@dptr
      008D49 F5 2C            [12] 1645 	mov	_ak820_dynamic_read_buffer_sloc0_1_0,a
      008D4B E0               [24] 1646 	movx	a,@dptr
      008D4C 60 42            [24] 1647 	jz	00106$
      008D4E C0 04            [24] 1648 	push	ar4
      008D50 C0 05            [24] 1649 	push	ar5
      008D52 8E 00            [24] 1650 	mov	ar0,r6
      008D54 8F 05            [24] 1651 	mov	ar5,r7
      008D56 90 0B 48         [24] 1652 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_411
      008D59 E0               [24] 1653 	movx	a,@dptr
      008D5A F9               [12] 1654 	mov	r1,a
      008D5B A3               [24] 1655 	inc	dptr
      008D5C E0               [24] 1656 	movx	a,@dptr
      008D5D FC               [12] 1657 	mov	r4,a
      008D5E EA               [12] 1658 	mov	a,r2
      008D5F 29               [12] 1659 	add	a, r1
      008D60 FA               [12] 1660 	mov	r2,a
      008D61 EB               [12] 1661 	mov	a,r3
      008D62 3C               [12] 1662 	addc	a, r4
      008D63 FB               [12] 1663 	mov	r3,a
      008D64 90 05 95         [24] 1664 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      008D67 EA               [12] 1665 	mov	a,r2
      008D68 F0               [24] 1666 	movx	@dptr,a
      008D69 EB               [12] 1667 	mov	a,r3
      008D6A 12 3A B0         [24] 1668 	lcall	_ak820_outline_0093
      008D6D 90 05 98         [24] 1669 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      008D70 E5 2C            [12] 1670 	mov	a,_ak820_dynamic_read_buffer_sloc0_1_0
      008D72 12 3A E1         [24] 1671 	lcall	_ak820_outline_0137
      008D75 88 82            [24] 1672 	mov	dpl, r0
      008D77 8D 83            [24] 1673 	mov	dph, r5
      008D79 C0 07            [24] 1674 	push	ar7
      008D7B C0 06            [24] 1675 	push	ar6
      008D7D C0 05            [24] 1676 	push	ar5
      008D7F C0 04            [24] 1677 	push	ar4
      008D81 12 42 F1         [24] 1678 	lcall	_ak820_eeprom_read_block_xdata
      008D84 D0 04            [24] 1679 	pop	ar4
      008D86 D0 05            [24] 1680 	pop	ar5
      008D88 D0 06            [24] 1681 	pop	ar6
      008D8A D0 07            [24] 1682 	pop	ar7
                                   1683 ;	quantum/dynamic_keymap.c:419: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      008D8C D0 05            [24] 1684 	pop	ar5
      008D8E D0 04            [24] 1685 	pop	ar4
                                   1686 ;	quantum/dynamic_keymap.c:418: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      008D90                       1687 00106$:
                                   1688 ;	quantum/dynamic_keymap.c:419: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      008D90 90 0B 4A         [24] 1689 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_412
      008D93 E0               [24] 1690 	movx	a,@dptr
      008D94 FB               [12] 1691 	mov	r3,a
      008D95                       1692 00109$:
      008D95 8B 01            [24] 1693 	mov	ar1,r3
      008D97 7A 00            [12] 1694 	mov	r2,#0x00
      008D99 C3               [12] 1695 	clr	c
      008D9A E9               [12] 1696 	mov	a,r1
      008D9B 9C               [12] 1697 	subb	a,r4
      008D9C EA               [12] 1698 	mov	a,r2
      008D9D 9D               [12] 1699 	subb	a,r5
      008D9E 50 09            [24] 1700 	jnc	00111$
      008DA0 EB               [12] 1701 	mov	a,r3
      008DA1 12 3A 71         [24] 1702 	lcall	_ak820_outline_0021
      008DA4 E4               [12] 1703 	clr	a
      008DA5 F0               [24] 1704 	movx	@dptr,a
      008DA6 0B               [12] 1705 	inc	r3
      008DA7 80 EC            [24] 1706 	sjmp	00109$
      008DA9                       1707 00111$:
                                   1708 ;	quantum/dynamic_keymap.c:420: }
      008DA9 22               [24] 1709 	ret
                                   1710 ;------------------------------------------------------------
                                   1711 ;Allocation info for local variables in function 'dynamic_keymap_get_buffer'
                                   1712 ;------------------------------------------------------------
                                   1713 ;size          Allocated with name '_dynamic_keymap_get_buffer_PARM_2'
                                   1714 ;data          Allocated with name '_dynamic_keymap_get_buffer_PARM_3'
                                   1715 ;offset        Allocated with name '_dynamic_keymap_get_buffer_offset_10000_418'
                                   1716 ;------------------------------------------------------------
                                   1717 ;	quantum/dynamic_keymap.c:423: void dynamic_keymap_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   1718 ;	-----------------------------------------
                                   1719 ;	 function dynamic_keymap_get_buffer
                                   1720 ;	-----------------------------------------
      008DAA                       1721 _dynamic_keymap_get_buffer:
      008DAA 12 3A C2         [24] 1722 	lcall	_ak820_outline_0109
      008DAD 90 0B 50         [24] 1723 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_418
      008DB0 12 3A C7         [24] 1724 	lcall	_ak820_outline_0110
                                   1725 ;	quantum/dynamic_keymap.c:426: DYNAMIC_KEYMAP_LAYER_COUNT * MATRIX_ROWS * MATRIX_COLS * 2, offset, size, data);
      008DB3 90 0B 50         [24] 1726 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_418
      008DB6 12 3A 81         [24] 1727 	lcall	_ak820_outline_0052
      008DB9 90 0B 4B         [24] 1728 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_2
      008DBC 12 3A 98         [24] 1729 	lcall	_ak820_outline_0061
      008DBF 90 0B 4D         [24] 1730 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_3
      008DC2 12 51 96         [24] 1731 	lcall	_ak820_outline_0091
      008DC5 90 0B 3F         [24] 1732 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008DC8 E4               [12] 1733 	clr	a
      008DC9 F0               [24] 1734 	movx	@dptr,a
      008DCA 74 06            [12] 1735 	mov	a,#0x06
      008DCC A3               [24] 1736 	inc	dptr
      008DCD F0               [24] 1737 	movx	@dptr,a
      008DCE 90 0B 41         [24] 1738 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008DD1 12 4A CB         [24] 1739 	lcall	_ak820_outline_0060
      008DD4 90 0B 43         [24] 1740 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008DD7 12 3A 9E         [24] 1741 	lcall	_ak820_outline_0072
      008DDA 90 0B 45         [24] 1742 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008DDD E9               [12] 1743 	mov	a,r1
      008DDE 12 51 AF         [24] 1744 	lcall	_ak820_outline_0161
      008DE1 F0               [24] 1745 	movx	@dptr,a
      008DE2 90 00 40         [24] 1746 	mov	dptr,#0x0040
                                   1747 ;	quantum/dynamic_keymap.c:448: }
      008DE5 81 F4            [12] 1748 	ajmp	_ak820_dynamic_read_buffer
                                   1749 ;------------------------------------------------------------
                                   1750 ;Allocation info for local variables in function 'dynamic_keymap_set_buffer'
                                   1751 ;------------------------------------------------------------
                                   1752 ;sloc0         Allocated with name '_dynamic_keymap_set_buffer_sloc0_1_0'
                                   1753 ;sloc1         Allocated with name '_dynamic_keymap_set_buffer_sloc1_1_0'
                                   1754 ;sloc2         Allocated with name '_dynamic_keymap_set_buffer_sloc2_1_0'
                                   1755 ;size          Allocated with name '_dynamic_keymap_set_buffer_PARM_2'
                                   1756 ;data          Allocated with name '_dynamic_keymap_set_buffer_PARM_3'
                                   1757 ;offset        Allocated with name '_dynamic_keymap_set_buffer_offset_10000_420'
                                   1758 ;dynamic_keymap_eeprom_size Allocated with name '_dynamic_keymap_set_buffer_dynamic_keymap_eeprom_size_10000_421'
                                   1759 ;target        Allocated with name '_dynamic_keymap_set_buffer_target_10000_421'
                                   1760 ;buffer        Allocated with name '_dynamic_keymap_set_buffer_buffer_10000_421'
                                   1761 ;count         Allocated with name '_dynamic_keymap_set_buffer_count_10001_424'
                                   1762 ;chk_offset    Allocated with name '_dynamic_keymap_set_buffer_chk_offset_30001_427'
                                   1763 ;chk_sz        Allocated with name '_dynamic_keymap_set_buffer_chk_sz_30001_427'
                                   1764 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_429'
                                   1765 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_432'
                                   1766 ;i             Allocated with name '_dynamic_keymap_set_buffer_i_40001_434'
                                   1767 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_435'
                                   1768 ;------------------------------------------------------------
                                   1769 ;	quantum/dynamic_keymap.c:450: void dynamic_keymap_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   1770 ;	-----------------------------------------
                                   1771 ;	 function dynamic_keymap_set_buffer
                                   1772 ;	-----------------------------------------
      008DE7                       1773 _dynamic_keymap_set_buffer:
      008DE7 12 3A C2         [24] 1774 	lcall	_ak820_outline_0109
      008DEA 90 0B 57         [24] 1775 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_420
      008DED 12 3A C7         [24] 1776 	lcall	_ak820_outline_0110
                                   1777 ;	quantum/dynamic_keymap.c:452: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset);
      008DF0 90 0B 57         [24] 1778 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_420
      008DF3 12 4A 6F         [24] 1779 	lcall	_ak820_outline_0008
      008DF6 74 40            [12] 1780 	mov	a,#0x40
      008DF8 2C               [12] 1781 	add	a, r4
      008DF9 FA               [12] 1782 	mov	r2,a
      008DFA E4               [12] 1783 	clr	a
      008DFB 3D               [12] 1784 	addc	a, r5
      008DFC FB               [12] 1785 	mov	r3,a
                                   1786 ;	quantum/dynamic_keymap.c:453: uint8_t DYNAMIC_BUFFER_MEM *buffer = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      008DFD 90 0B 54         [24] 1787 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_3
      008E00 12 3A BC         [24] 1788 	lcall	_ak820_outline_0104
                                   1789 ;	quantum/dynamic_keymap.c:457: if (!size) return;
      008E03 90 0B 52         [24] 1790 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_2
      008E06 E0               [24] 1791 	movx	a,@dptr
      008E07 F5 2D            [12] 1792 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,a
      008E09 A3               [24] 1793 	inc	dptr
      008E0A E0               [24] 1794 	movx	a,@dptr
      008E0B F5 2E            [12] 1795 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),a
      008E0D E5 2D            [12] 1796 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008E0F 45 2E            [12] 1797 	orl	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008E11 70 01            [24] 1798 	jnz	00102$
      008E13 22               [24] 1799 	ret
      008E14                       1800 00102$:
                                   1801 ;	quantum/dynamic_keymap.c:459: if (size > 28) return;
      008E14 85 2D 2F         [24] 1802 	mov	_dynamic_keymap_set_buffer_sloc1_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
      008E17 85 2E 30         [24] 1803 	mov	(_dynamic_keymap_set_buffer_sloc1_1_0 + 1),(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008E1A C3               [12] 1804 	clr	c
      008E1B 74 1C            [12] 1805 	mov	a,#0x1c
      008E1D 95 2F            [12] 1806 	subb	a,_dynamic_keymap_set_buffer_sloc1_1_0
      008E1F E4               [12] 1807 	clr	a
      008E20 95 30            [12] 1808 	subb	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      008E22 50 01            [24] 1809 	jnc	00104$
                                   1810 ;	free result
      008E24 22               [24] 1811 	ret
      008E25                       1812 00104$:
                                   1813 ;	quantum/dynamic_keymap.c:461: dynamic_buffer_size_t count = size;
      008E25 85 2D 31         [24] 1814 	mov	_dynamic_keymap_set_buffer_sloc2_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
                                   1815 ;	quantum/dynamic_keymap.c:465: if (offset >= dynamic_keymap_eeprom_size || dynamic_keymap_eeprom_size - offset < size)
      008E28 74 FA            [12] 1816 	mov	a,#0x100 - 0x06
      008E2A 2F               [12] 1817 	add	a,r7
      008E2B 40 11            [24] 1818 	jc	00105$
      008E2D E4               [12] 1819 	clr	a
      008E2E C3               [12] 1820 	clr	c
      008E2F 9E               [12] 1821 	subb	a,r6
      008E30 FE               [12] 1822 	mov	r6,a
      008E31 74 06            [12] 1823 	mov	a,#0x06
      008E33 9F               [12] 1824 	subb	a,r7
      008E34 FF               [12] 1825 	mov	r7,a
      008E35 C3               [12] 1826 	clr	c
      008E36 EE               [12] 1827 	mov	a,r6
      008E37 95 2D            [12] 1828 	subb	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008E39 EF               [12] 1829 	mov	a,r7
      008E3A 95 2E            [12] 1830 	subb	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008E3C 50 01            [24] 1831 	jnc	00106$
      008E3E                       1832 00105$:
                                   1833 ;	quantum/dynamic_keymap.c:466: return;
      008E3E 22               [24] 1834 	ret
      008E3F                       1835 00106$:
                                   1836 ;	quantum/dynamic_keymap.c:470: if (!vial_unlocked) {
      008E3F 90 0E 56         [24] 1837 	mov	dptr,#_vial_unlocked
      008E42 E0               [24] 1838 	movx	a,@dptr
      008E43 60 02            [24] 1839 	jz	00207$
      008E45 E1 50            [12] 1840 	ajmp	00120$
      008E47                       1841 00207$:
                                   1842 ;	quantum/dynamic_keymap.c:472: dynamic_buffer_size_t chk_offset = 0;
      008E47 90 0B 59         [24] 1843 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_427
      008E4A E4               [12] 1844 	clr	a
      008E4B F0               [24] 1845 	movx	@dptr,a
                                   1846 ;	quantum/dynamic_keymap.c:473: dynamic_buffer_size_t chk_sz = count;
      008E4C 90 0B 5A         [24] 1847 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_427
      008E4F E5 31            [12] 1848 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008E51 F0               [24] 1849 	movx	@dptr,a
                                   1850 ;	quantum/dynamic_keymap.c:476: if (offset % 2 != 0) {
      008E52 EC               [12] 1851 	mov	a,r4
      008E53 30 E0 31         [24] 1852 	jnb	acc.0,00111$
                                   1853 ;	quantum/dynamic_keymap.c:477: uint16_t kc = (eeprom_read_byte(target - 1) << 8) | buffer[0];
      008E56 EA               [12] 1854 	mov	a,r2
      008E57 24 FF            [12] 1855 	add	a,#0xff
      008E59 FE               [12] 1856 	mov	r6,a
      008E5A EB               [12] 1857 	mov	a,r3
      008E5B 34 FF            [12] 1858 	addc	a,#0xff
      008E5D FF               [12] 1859 	mov	r7,a
      008E5E 7D 00            [12] 1860 	mov	r5,#0x00
      008E60 12 74 44         [24] 1861 	lcall	_ak820_outline_0050
      008E63 12 42 B6         [24] 1862 	lcall	_eeprom_read_byte
      008E66 AE 82            [24] 1863 	mov	r6,dpl
      008E68 7F 00            [12] 1864 	mov	r7,#0x00
      008E6A 12 3A F6         [24] 1865 	lcall	_ak820_outline_0163
      008E6D E0               [24] 1866 	movx	a,@dptr
      008E6E 7C 00            [12] 1867 	mov	r4,#0x00
      008E70 42 07            [12] 1868 	orl	ar7,a
      008E72 EC               [12] 1869 	mov	a,r4
      008E73 42 06            [12] 1870 	orl	ar6,a
                                   1871 ;	quantum/dynamic_keymap.c:478: if (kc == QK_BOOT)
      008E75 BF 00 09         [24] 1872 	cjne	r7,#0x00,00109$
      008E78 BE 7C 06         [24] 1873 	cjne	r6,#0x7c,00109$
                                   1874 ;	quantum/dynamic_keymap.c:479: buffer[0] = 0xFF;
      008E7B 12 3A F6         [24] 1875 	lcall	_ak820_outline_0163
      008E7E 74 FF            [12] 1876 	mov	a,#0xff
      008E80 F0               [24] 1877 	movx	@dptr,a
      008E81                       1878 00109$:
                                   1879 ;	quantum/dynamic_keymap.c:482: chk_offset += 1;
      008E81 90 0B 59         [24] 1880 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_427
      008E84 74 01            [12] 1881 	mov	a,#0x01
      008E86 F0               [24] 1882 	movx	@dptr,a
      008E87                       1883 00111$:
                                   1884 ;	quantum/dynamic_keymap.c:486: if ((offset + size) % 2 != 0) {
      008E87 90 0B 57         [24] 1885 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_420
      008E8A 12 3A 81         [24] 1886 	lcall	_ak820_outline_0052
      008E8D E5 2D            [12] 1887 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008E8F 2E               [12] 1888 	add	a, r6
      008E90 FE               [12] 1889 	mov	r6,a
      008E91 E5 2E            [12] 1890 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008E93 3F               [12] 1891 	addc	a, r7
      008E94 EE               [12] 1892 	mov	a,r6
      008E95 30 E0 5A         [24] 1893 	jnb	acc.0,00115$
                                   1894 ;	quantum/dynamic_keymap.c:487: uint16_t kc = (buffer[count - 1] << 8) | eeprom_read_byte(target + count);
      008E98 AE 31            [24] 1895 	mov	r6,_dynamic_keymap_set_buffer_sloc2_1_0
      008E9A 7F 00            [12] 1896 	mov	r7,#0x00
      008E9C EE               [12] 1897 	mov	a,r6
      008E9D 24 FF            [12] 1898 	add	a,#0xff
      008E9F FC               [12] 1899 	mov	r4,a
      008EA0 EF               [12] 1900 	mov	a,r7
      008EA1 34 FF            [12] 1901 	addc	a,#0xff
      008EA3 FD               [12] 1902 	mov	r5,a
      008EA4 EC               [12] 1903 	mov	a,r4
      008EA5 28               [12] 1904 	add	a, r0
      008EA6 F5 82            [12] 1905 	mov	dpl,a
      008EA8 ED               [12] 1906 	mov	a,r5
      008EA9 39               [12] 1907 	addc	a, r1
      008EAA F5 83            [12] 1908 	mov	dph,a
      008EAC E0               [24] 1909 	movx	a,@dptr
      008EAD FC               [12] 1910 	mov	r4,a
      008EAE 7D 00            [12] 1911 	mov	r5,#0x00
      008EB0 E5 31            [12] 1912 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008EB2 2A               [12] 1913 	add	a, r2
      008EB3 FA               [12] 1914 	mov	r2,a
      008EB4 E4               [12] 1915 	clr	a
      008EB5 3B               [12] 1916 	addc	a, r3
      008EB6 FB               [12] 1917 	mov	r3,a
      008EB7 C0 00            [24] 1918 	push	ar0
      008EB9 C0 01            [24] 1919 	push	ar1
      008EBB 8B 01            [24] 1920 	mov	ar1,r3
      008EBD 7B 00            [12] 1921 	mov	r3,#0x00
      008EBF 8A 82            [24] 1922 	mov	dpl, r2
      008EC1 89 83            [24] 1923 	mov	dph, r1
      008EC3 8B F0            [24] 1924 	mov	b, r3
      008EC5 12 42 B6         [24] 1925 	lcall	_eeprom_read_byte
      008EC8 AB 82            [24] 1926 	mov	r3, dpl
      008ECA 7A 00            [12] 1927 	mov	r2,#0x00
      008ECC EB               [12] 1928 	mov	a,r3
      008ECD 12 45 A2         [24] 1929 	lcall	_ak820_outline_0146
                                   1930 ;	quantum/dynamic_keymap.c:488: if (kc == QK_BOOT)
      008ED0 BD 00 05         [24] 1931 	cjne	r5,#0x00,00212$
      008ED3 BC 7C 02         [24] 1932 	cjne	r4,#0x7c,00212$
      008ED6 80 06            [24] 1933 	sjmp	00213$
      008ED8                       1934 00212$:
      008ED8 D0 01            [24] 1935 	pop	ar1
      008EDA D0 00            [24] 1936 	pop	ar0
      008EDC 80 0D            [24] 1937 	sjmp	00113$
      008EDE                       1938 00213$:
      008EDE D0 01            [24] 1939 	pop	ar1
      008EE0 D0 00            [24] 1940 	pop	ar0
                                   1941 ;	quantum/dynamic_keymap.c:489: buffer[count - 1] = 0xFF;
      008EE2 1E               [12] 1942 	dec	r6
      008EE3 BE FF 01         [24] 1943 	cjne	r6,#0xff,00214$
      008EE6 1F               [12] 1944 	dec	r7
      008EE7                       1945 00214$:
      008EE7 EE               [12] 1946 	mov	a,r6
      008EE8 12 93 79         [24] 1947 	lcall	_ak820_outline_0130
      008EEB                       1948 00113$:
                                   1949 ;	quantum/dynamic_keymap.c:492: chk_sz -= 1;
      008EEB E5 31            [12] 1950 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008EED 14               [12] 1951 	dec	a
      008EEE 90 0B 5A         [24] 1952 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_427
      008EF1 F0               [24] 1953 	movx	@dptr,a
      008EF2                       1954 00115$:
                                   1955 ;	quantum/dynamic_keymap.c:496: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      008EF2 90 0B 59         [24] 1956 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_427
      008EF5 E0               [24] 1957 	movx	a,@dptr
      008EF6 90 0B 5B         [24] 1958 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_434
      008EF9 F0               [24] 1959 	movx	@dptr,a
      008EFA                       1960 00122$:
      008EFA 90 0B 5B         [24] 1961 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_434
      008EFD E0               [24] 1962 	movx	a,@dptr
      008EFE FF               [12] 1963 	mov	r7,a
      008EFF 90 0B 5A         [24] 1964 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_427
      008F02 E0               [24] 1965 	movx	a,@dptr
      008F03 FE               [12] 1966 	mov	r6,a
      008F04 C3               [12] 1967 	clr	c
      008F05 EF               [12] 1968 	mov	a,r7
      008F06 9E               [12] 1969 	subb	a,r6
      008F07 50 47            [24] 1970 	jnc	00120$
                                   1971 ;	quantum/dynamic_keymap.c:497: uint16_t kc = (buffer[i] << 8) | buffer[i + 1];
      008F09 EF               [12] 1972 	mov	a,r7
      008F0A 28               [12] 1973 	add	a, r0
      008F0B FD               [12] 1974 	mov	r5,a
      008F0C E4               [12] 1975 	clr	a
      008F0D 39               [12] 1976 	addc	a, r1
      008F0E 12 4A C3         [24] 1977 	lcall	_ak820_outline_0057
      008F11 7B 00            [12] 1978 	mov	r3,#0x00
      008F13 8C 2E            [24] 1979 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),r4
      008F15 8B 2D            [24] 1980 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,r3
      008F17 8F 02            [24] 1981 	mov	ar2,r7
      008F19 7F 00            [12] 1982 	mov	r7,#0x00
      008F1B 74 01            [12] 1983 	mov	a,#0x01
      008F1D 2A               [12] 1984 	add	a, r2
      008F1E FB               [12] 1985 	mov	r3,a
      008F1F E4               [12] 1986 	clr	a
      008F20 3F               [12] 1987 	addc	a, r7
      008F21 FC               [12] 1988 	mov	r4,a
      008F22 EB               [12] 1989 	mov	a,r3
      008F23 28               [12] 1990 	add	a, r0
      008F24 F5 82            [12] 1991 	mov	dpl,a
      008F26 EC               [12] 1992 	mov	a,r4
      008F27 39               [12] 1993 	addc	a, r1
      008F28 F5 83            [12] 1994 	mov	dph,a
      008F2A E0               [24] 1995 	movx	a,@dptr
      008F2B FC               [12] 1996 	mov	r4,a
      008F2C 7B 00            [12] 1997 	mov	r3,#0x00
      008F2E E5 2E            [12] 1998 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008F30 42 03            [12] 1999 	orl	ar3,a
                                   2000 ;	quantum/dynamic_keymap.c:498: if (kc == QK_BOOT) {
      008F32 BC 00 12         [24] 2001 	cjne	r4,#0x00,00123$
      008F35 BB 7C 0F         [24] 2002 	cjne	r3,#0x7c,00123$
                                   2003 ;	quantum/dynamic_keymap.c:499: buffer[i] = 0xFF;
      008F38 12 3A DC         [24] 2004 	lcall	_ak820_outline_0135
      008F3B 74 FF            [12] 2005 	mov	a,#0xff
      008F3D F0               [24] 2006 	movx	@dptr,a
                                   2007 ;	quantum/dynamic_keymap.c:500: buffer[i + 1] = 0xFF;
      008F3E 0A               [12] 2008 	inc	r2
      008F3F BA 00 01         [24] 2009 	cjne	r2,#0x00,00218$
      008F42 0F               [12] 2010 	inc	r7
      008F43                       2011 00218$:
      008F43 EA               [12] 2012 	mov	a,r2
      008F44 12 93 79         [24] 2013 	lcall	_ak820_outline_0130
      008F47                       2014 00123$:
                                   2015 ;	quantum/dynamic_keymap.c:496: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      008F47 90 0B 5B         [24] 2016 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_434
      008F4A E0               [24] 2017 	movx	a,@dptr
      008F4B 24 02            [12] 2018 	add	a,#0x02
      008F4D F0               [24] 2019 	movx	@dptr,a
      008F4E 80 AA            [24] 2020 	sjmp	00122$
      008F50                       2021 00120$:
                                   2022 ;	quantum/dynamic_keymap.c:511: ak820_eeprom_write_block_xdata(buffer, (void *)(uintptr_t)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset), size);
      008F50 90 0B 57         [24] 2023 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_420
      008F53 12 3A 81         [24] 2024 	lcall	_ak820_outline_0052
      008F56 74 40            [12] 2025 	mov	a,#0x40
      008F58 12 45 9C         [24] 2026 	lcall	_ak820_outline_0139
      008F5B 90 05 9E         [24] 2027 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      008F5E 12 4A CB         [24] 2028 	lcall	_ak820_outline_0060
      008F61 E4               [12] 2029 	clr	a
      008F62 A3               [24] 2030 	inc	dptr
      008F63 F0               [24] 2031 	movx	@dptr,a
      008F64 90 05 A1         [24] 2032 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      008F67 E5 2F            [12] 2033 	mov	a,_dynamic_keymap_set_buffer_sloc1_1_0
      008F69 F0               [24] 2034 	movx	@dptr,a
      008F6A E5 30            [12] 2035 	mov	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      008F6C A3               [24] 2036 	inc	dptr
      008F6D F0               [24] 2037 	movx	@dptr,a
      008F6E 12 3A F6         [24] 2038 	lcall	_ak820_outline_0163
                                   2039 ;	quantum/dynamic_keymap.c:521: }
      008F71 02 43 7D         [24] 2040 	ljmp	_ak820_eeprom_write_block_xdata
                                   2041 ;------------------------------------------------------------
                                   2042 ;Allocation info for local variables in function 'keycode_at_keymap_location'
                                   2043 ;------------------------------------------------------------
                                   2044 ;row           Allocated with name '_keycode_at_keymap_location_PARM_2'
                                   2045 ;column        Allocated with name '_keycode_at_keymap_location_PARM_3'
                                   2046 ;layer_num     Allocated with name '_keycode_at_keymap_location_layer_num_10000_438'
                                   2047 ;------------------------------------------------------------
                                   2048 ;	quantum/dynamic_keymap.c:523: uint16_t keycode_at_keymap_location(uint8_t layer_num, uint8_t row, uint8_t column) {
                                   2049 ;	-----------------------------------------
                                   2050 ;	 function keycode_at_keymap_location
                                   2051 ;	-----------------------------------------
      008F74                       2052 _keycode_at_keymap_location:
      008F74 E5 82            [12] 2053 	mov	a,dpl
      008F76 90 0B 5E         [24] 2054 	mov	dptr,#_keycode_at_keymap_location_layer_num_10000_438
      008F79 F0               [24] 2055 	movx	@dptr,a
                                   2056 ;	quantum/dynamic_keymap.c:524: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && row < MATRIX_ROWS && column < MATRIX_COLS) {
      008F7A E0               [24] 2057 	movx	a,@dptr
      008F7B FF               [12] 2058 	mov	r7,a
      008F7C BF 06 00         [24] 2059 	cjne	r7,#0x06,00128$
      008F7F                       2060 00128$:
      008F7F 50 23            [24] 2061 	jnc	00102$
      008F81 90 0B 5C         [24] 2062 	mov	dptr,#_keycode_at_keymap_location_PARM_2
      008F84 E0               [24] 2063 	movx	a,@dptr
      008F85 FE               [12] 2064 	mov	r6,a
      008F86 BE 10 00         [24] 2065 	cjne	r6,#0x10,00130$
      008F89                       2066 00130$:
      008F89 50 19            [24] 2067 	jnc	00102$
      008F8B 90 0B 5D         [24] 2068 	mov	dptr,#_keycode_at_keymap_location_PARM_3
      008F8E E0               [24] 2069 	movx	a,@dptr
      008F8F FD               [12] 2070 	mov	r5,a
      008F90 BD 08 00         [24] 2071 	cjne	r5,#0x08,00132$
      008F93                       2072 00132$:
      008F93 50 0F            [24] 2073 	jnc	00102$
                                   2074 ;	quantum/dynamic_keymap.c:525: return dynamic_keymap_get_keycode(layer_num, row, column);
      008F95 90 0B 10         [24] 2075 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      008F98 EE               [12] 2076 	mov	a,r6
      008F99 F0               [24] 2077 	movx	@dptr,a
      008F9A 90 0B 11         [24] 2078 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      008F9D ED               [12] 2079 	mov	a,r5
      008F9E F0               [24] 2080 	movx	@dptr,a
      008F9F 8F 82            [24] 2081 	mov	dpl, r7
      008FA1 02 89 22         [24] 2082 	ljmp	_dynamic_keymap_get_keycode
      008FA4                       2083 00102$:
                                   2084 ;	quantum/dynamic_keymap.c:527: return KC_NO;
      008FA4 90 00 00         [24] 2085 	mov	dptr,#0x0000
                                   2086 ;	quantum/dynamic_keymap.c:528: }
      008FA7 22               [24] 2087 	ret
                                   2088 ;------------------------------------------------------------
                                   2089 ;Allocation info for local variables in function 'keycode_at_encodermap_location'
                                   2090 ;------------------------------------------------------------
                                   2091 ;encoder_idx   Allocated with name '_keycode_at_encodermap_location_PARM_2'
                                   2092 ;clockwise     Allocated with name '_keycode_at_encodermap_location_PARM_3'
                                   2093 ;layer_num     Allocated with name '_keycode_at_encodermap_location_layer_num_10000_442'
                                   2094 ;------------------------------------------------------------
                                   2095 ;	quantum/dynamic_keymap.c:531: uint16_t keycode_at_encodermap_location(uint8_t layer_num, uint8_t encoder_idx, bool clockwise) {
                                   2096 ;	-----------------------------------------
                                   2097 ;	 function keycode_at_encodermap_location
                                   2098 ;	-----------------------------------------
      008FA8                       2099 _keycode_at_encodermap_location:
      008FA8 E5 82            [12] 2100 	mov	a,dpl
      008FAA 90 0B 61         [24] 2101 	mov	dptr,#_keycode_at_encodermap_location_layer_num_10000_442
      008FAD F0               [24] 2102 	movx	@dptr,a
                                   2103 ;	quantum/dynamic_keymap.c:532: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && encoder_idx < NUM_ENCODERS) {
      008FAE E0               [24] 2104 	movx	a,@dptr
      008FAF FF               [12] 2105 	mov	r7,a
      008FB0 BF 06 00         [24] 2106 	cjne	r7,#0x06,00120$
      008FB3                       2107 00120$:
      008FB3 50 1E            [24] 2108 	jnc	00102$
      008FB5 90 0B 5F         [24] 2109 	mov	dptr,#_keycode_at_encodermap_location_PARM_2
      008FB8 E0               [24] 2110 	movx	a,@dptr
      008FB9 FE               [12] 2111 	mov	r6,a
      008FBA BE 01 00         [24] 2112 	cjne	r6,#0x01,00122$
      008FBD                       2113 00122$:
      008FBD 50 14            [24] 2114 	jnc	00102$
                                   2115 ;	quantum/dynamic_keymap.c:533: return dynamic_keymap_get_encoder(layer_num, encoder_idx, clockwise);
      008FBF 90 0B 60         [24] 2116 	mov	dptr,#_keycode_at_encodermap_location_PARM_3
      008FC2 E0               [24] 2117 	movx	a,@dptr
      008FC3 FE               [12] 2118 	mov	r6,a
      008FC4 90 0B 1A         [24] 2119 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      008FC7 E4               [12] 2120 	clr	a
      008FC8 F0               [24] 2121 	movx	@dptr,a
      008FC9 90 0B 1B         [24] 2122 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      008FCC EE               [12] 2123 	mov	a,r6
      008FCD F0               [24] 2124 	movx	@dptr,a
      008FCE 8F 82            [24] 2125 	mov	dpl, r7
      008FD0 02 89 DF         [24] 2126 	ljmp	_dynamic_keymap_get_encoder
      008FD3                       2127 00102$:
                                   2128 ;	quantum/dynamic_keymap.c:535: return KC_NO;
      008FD3 90 00 00         [24] 2129 	mov	dptr,#0x0000
                                   2130 ;	quantum/dynamic_keymap.c:536: }
      008FD6 22               [24] 2131 	ret
                                   2132 ;------------------------------------------------------------
                                   2133 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_count'
                                   2134 ;------------------------------------------------------------
                                   2135 ;	quantum/dynamic_keymap.c:539: uint8_t dynamic_keymap_macro_get_count(void) {
                                   2136 ;	-----------------------------------------
                                   2137 ;	 function dynamic_keymap_macro_get_count
                                   2138 ;	-----------------------------------------
      008FD7                       2139 _dynamic_keymap_macro_get_count:
                                   2140 ;	quantum/dynamic_keymap.c:540: return DYNAMIC_KEYMAP_MACRO_COUNT;
      008FD7 75 82 10         [24] 2141 	mov	dpl, #0x10
                                   2142 ;	quantum/dynamic_keymap.c:541: }
      008FDA 22               [24] 2143 	ret
                                   2144 ;------------------------------------------------------------
                                   2145 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer_size'
                                   2146 ;------------------------------------------------------------
                                   2147 ;	quantum/dynamic_keymap.c:543: uint16_t dynamic_keymap_macro_get_buffer_size(void) {
                                   2148 ;	-----------------------------------------
                                   2149 ;	 function dynamic_keymap_macro_get_buffer_size
                                   2150 ;	-----------------------------------------
      008FDB                       2151 _dynamic_keymap_macro_get_buffer_size:
                                   2152 ;	quantum/dynamic_keymap.c:544: return DYNAMIC_KEYMAP_MACRO_EEPROM_SIZE;
      008FDB 90 20 00         [24] 2153 	mov	dptr,#0x2000
                                   2154 ;	quantum/dynamic_keymap.c:545: }
      008FDE 22               [24] 2155 	ret
                                   2156 ;------------------------------------------------------------
                                   2157 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer'
                                   2158 ;------------------------------------------------------------
                                   2159 ;sloc0         Allocated with name '_dynamic_keymap_macro_get_buffer_sloc0_1_0'
                                   2160 ;size          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_2'
                                   2161 ;data          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_3'
                                   2162 ;offset        Allocated with name '_dynamic_keymap_macro_get_buffer_offset_10000_450'
                                   2163 ;------------------------------------------------------------
                                   2164 ;	quantum/dynamic_keymap.c:547: void dynamic_keymap_macro_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2165 ;	-----------------------------------------
                                   2166 ;	 function dynamic_keymap_macro_get_buffer
                                   2167 ;	-----------------------------------------
      008FDF                       2168 _dynamic_keymap_macro_get_buffer:
      008FDF 12 3A C2         [24] 2169 	lcall	_ak820_outline_0109
      008FE2 90 0B 67         [24] 2170 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_450
      008FE5 12 3A C7         [24] 2171 	lcall	_ak820_outline_0110
                                   2172 ;	quantum/dynamic_keymap.c:550: ak820_macro_length(), offset, size, data);
      008FE8 12 2B 2B         [24] 2173 	lcall	_ak820_macro_length
      008FEB 12 45 97         [24] 2174 	lcall	_ak820_outline_0136
      008FEE 90 0B 67         [24] 2175 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_450
      008FF1 12 3A 98         [24] 2176 	lcall	_ak820_outline_0061
      008FF4 90 0B 62         [24] 2177 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_2
      008FF7 E0               [24] 2178 	movx	a,@dptr
      008FF8 F5 32            [12] 2179 	mov	_dynamic_keymap_macro_get_buffer_sloc0_1_0,a
      008FFA A3               [24] 2180 	inc	dptr
      008FFB E0               [24] 2181 	movx	a,@dptr
      008FFC F5 33            [12] 2182 	mov	(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1),a
      008FFE 90 0B 64         [24] 2183 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_3
      009001 12 3A BC         [24] 2184 	lcall	_ak820_outline_0104
      009004 A3               [24] 2185 	inc	dptr
      009005 E0               [24] 2186 	movx	a,@dptr
      009006 FB               [12] 2187 	mov	r3,a
      009007 90 0B 3F         [24] 2188 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      00900A 12 4A CB         [24] 2189 	lcall	_ak820_outline_0060
      00900D 90 0B 41         [24] 2190 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      009010 12 3A 9E         [24] 2191 	lcall	_ak820_outline_0072
      009013 90 0B 43         [24] 2192 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      009016 E5 32            [12] 2193 	mov	a,_dynamic_keymap_macro_get_buffer_sloc0_1_0
      009018 F0               [24] 2194 	movx	@dptr,a
      009019 E5 33            [12] 2195 	mov	a,(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1)
      00901B A3               [24] 2196 	inc	dptr
      00901C F0               [24] 2197 	movx	@dptr,a
      00901D 90 0B 45         [24] 2198 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      009020 E8               [12] 2199 	mov	a,r0
      009021 F0               [24] 2200 	movx	@dptr,a
      009022 E9               [12] 2201 	mov	a,r1
      009023 A3               [24] 2202 	inc	dptr
      009024 12 7C 6D         [24] 2203 	lcall	_ak820_outline_0189
      009027 90 08 00         [24] 2204 	mov	dptr,#0x0800
                                   2205 ;	quantum/dynamic_keymap.c:572: }
      00902A 02 8C F4         [24] 2206 	ljmp	_ak820_dynamic_read_buffer
                                   2207 ;------------------------------------------------------------
                                   2208 ;Allocation info for local variables in function 'dynamic_keymap_macro_set_buffer'
                                   2209 ;------------------------------------------------------------
                                   2210 ;size          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_2'
                                   2211 ;data          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_3'
                                   2212 ;offset        Allocated with name '_dynamic_keymap_macro_set_buffer_offset_10000_452'
                                   2213 ;------------------------------------------------------------
                                   2214 ;	quantum/dynamic_keymap.c:575: bool dynamic_keymap_macro_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2215 ;	-----------------------------------------
                                   2216 ;	 function dynamic_keymap_macro_set_buffer
                                   2217 ;	-----------------------------------------
      00902D                       2218 _dynamic_keymap_macro_set_buffer:
      00902D 12 3A C2         [24] 2219 	lcall	_ak820_outline_0109
      009030 90 0B 6E         [24] 2220 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_452
      009033 12 3A C7         [24] 2221 	lcall	_ak820_outline_0110
                                   2222 ;	quantum/dynamic_keymap.c:576: return ak820_macro_write(offset, size, data);
      009036 90 0B 6E         [24] 2223 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_452
      009039 12 3A 81         [24] 2224 	lcall	_ak820_outline_0052
      00903C 90 0B 69         [24] 2225 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_2
      00903F 12 3A 98         [24] 2226 	lcall	_ak820_outline_0061
      009042 90 0B 6B         [24] 2227 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_3
      009045 12 51 96         [24] 2228 	lcall	_ak820_outline_0091
      009048 90 05 24         [24] 2229 	mov	dptr,#_ak820_macro_write_PARM_2
      00904B 12 3A 9E         [24] 2230 	lcall	_ak820_outline_0072
      00904E 90 05 26         [24] 2231 	mov	dptr,#_ak820_macro_write_PARM_3
      009051 E9               [12] 2232 	mov	a,r1
      009052 12 51 AF         [24] 2233 	lcall	_ak820_outline_0161
      009055 12 45 79         [24] 2234 	lcall	_ak820_outline_0078
                                   2235 ;	quantum/dynamic_keymap.c:577: }
      009058 02 2B 45         [24] 2236 	ljmp	_ak820_macro_write
                                   2237 ;------------------------------------------------------------
                                   2238 ;Allocation info for local variables in function 'dynamic_keymap_macro_reset'
                                   2239 ;------------------------------------------------------------
                                   2240 ;	quantum/dynamic_keymap.c:592: void dynamic_keymap_macro_reset(void) {
                                   2241 ;	-----------------------------------------
                                   2242 ;	 function dynamic_keymap_macro_reset
                                   2243 ;	-----------------------------------------
      00905B                       2244 _dynamic_keymap_macro_reset:
                                   2245 ;	quantum/dynamic_keymap.c:594: ak820_macro_reset();
                                   2246 ;	quantum/dynamic_keymap.c:603: }
      00905B 02 2E 64         [24] 2247 	ljmp	_ak820_macro_reset
                                   2248 ;------------------------------------------------------------
                                   2249 ;Allocation info for local variables in function 'decode_keycode'
                                   2250 ;------------------------------------------------------------
                                   2251 ;kc            Allocated with name '_decode_keycode_kc_10000_456'
                                   2252 ;------------------------------------------------------------
                                   2253 ;	quantum/dynamic_keymap.c:605: static uint16_t decode_keycode(uint16_t kc) {
                                   2254 ;	-----------------------------------------
                                   2255 ;	 function decode_keycode
                                   2256 ;	-----------------------------------------
      00905E                       2257 _decode_keycode:
      00905E 12 3A C2         [24] 2258 	lcall	_ak820_outline_0109
      009061 90 0B 70         [24] 2259 	mov	dptr,#_decode_keycode_kc_10000_456
      009064 12 3A C7         [24] 2260 	lcall	_ak820_outline_0110
                                   2261 ;	quantum/dynamic_keymap.c:607: if (kc > 0xFF00)
      009067 90 0B 70         [24] 2262 	mov	dptr,#_decode_keycode_kc_10000_456
      00906A 12 4A 6F         [24] 2263 	lcall	_ak820_outline_0008
      00906D C3               [12] 2264 	clr	c
      00906E E4               [12] 2265 	clr	a
      00906F 9C               [12] 2266 	subb	a,r4
      009070 74 FF            [12] 2267 	mov	a,#0xff
      009072 9D               [12] 2268 	subb	a,r5
      009073 50 08            [24] 2269 	jnc	00102$
                                   2270 ;	free result
                                   2271 ;	quantum/dynamic_keymap.c:608: return (kc & 0xFF) << 8;
      009075 8C 05            [24] 2272 	mov	ar5,r4
      009077 7C 00            [12] 2273 	mov	r4,#0x00
      009079 12 3A D7         [24] 2274 	lcall	_ak820_outline_0126
      00907C 22               [24] 2275 	ret
      00907D                       2276 00102$:
                                   2277 ;	quantum/dynamic_keymap.c:609: return kc;
      00907D 12 3A CC         [24] 2278 	lcall	_ak820_outline_0120
                                   2279 ;	quantum/dynamic_keymap.c:610: }
      009080 22               [24] 2280 	ret
                                   2281 ;------------------------------------------------------------
                                   2282 ;Allocation info for local variables in function 'dynamic_keymap_macro_send'
                                   2283 ;------------------------------------------------------------
                                   2284 ;id            Allocated with name '_dynamic_keymap_macro_send_id_10000_459'
                                   2285 ;sending       Allocated with name '_dynamic_keymap_macro_send_sending_10000_460'
                                   2286 ;p             Allocated with name '_dynamic_keymap_macro_send_p_10001_465'
                                   2287 ;end           Allocated with name '_dynamic_keymap_macro_send_end_10002_466'
                                   2288 ;data          Allocated with name '_dynamic_keymap_macro_send_data_10003_472'
                                   2289 ;kc            Allocated with name '_dynamic_keymap_macro_send_kc_110003_490'
                                   2290 ;d0            Allocated with name '_dynamic_keymap_macro_send_d0_80003_494'
                                   2291 ;d1            Allocated with name '_dynamic_keymap_macro_send_d1_80003_494'
                                   2292 ;ms            Allocated with name '_dynamic_keymap_macro_send_ms_80004_496'
                                   2293 ;i             Allocated with name '_dynamic_keymap_macro_send_i_100004_498'
                                   2294 ;delay         Allocated with name '_dynamic_keymap_macro_send_delay_50003_502'
                                   2295 ;i             Allocated with name '_dynamic_keymap_macro_send_i_70003_504'
                                   2296 ;------------------------------------------------------------
                                   2297 ;	quantum/dynamic_keymap.c:612: void dynamic_keymap_macro_send(uint8_t id) {
                                   2298 ;	-----------------------------------------
                                   2299 ;	 function dynamic_keymap_macro_send
                                   2300 ;	-----------------------------------------
      009081                       2301 _dynamic_keymap_macro_send:
      009081 E5 82            [12] 2302 	mov	a,dpl
      009083 90 0B 72         [24] 2303 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_459
      009086 F0               [24] 2304 	movx	@dptr,a
                                   2305 ;	quantum/dynamic_keymap.c:617: if (sending) return;
      009087 90 0B 73         [24] 2306 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_460
      00908A E0               [24] 2307 	movx	a,@dptr
      00908B 60 01            [24] 2308 	jz	00102$
      00908D 22               [24] 2309 	ret
      00908E                       2310 00102$:
                                   2311 ;	quantum/dynamic_keymap.c:619: if (id >= DYNAMIC_KEYMAP_MACRO_COUNT) {
      00908E 90 0B 72         [24] 2312 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_459
      009091 E0               [24] 2313 	movx	a,@dptr
      009092 FF               [12] 2314 	mov	r7,a
      009093 BF 10 00         [24] 2315 	cjne	r7,#0x10,00422$
      009096                       2316 00422$:
      009096 40 01            [24] 2317 	jc	00104$
                                   2318 ;	quantum/dynamic_keymap.c:620: return;
      009098 22               [24] 2319 	ret
      009099                       2320 00104$:
                                   2321 ;	quantum/dynamic_keymap.c:626: if (!ak820_macro_ready()) return;
      009099 C0 07            [24] 2322 	push	ar7
      00909B 12 2A F2         [24] 2323 	lcall	_ak820_macro_ready
      00909E E5 82            [12] 2324 	mov	a, dpl
      0090A0 D0 07            [24] 2325 	pop	ar7
      0090A2 70 01            [24] 2326 	jnz	00106$
      0090A4 22               [24] 2327 	ret
      0090A5                       2328 00106$:
                                   2329 ;	quantum/dynamic_keymap.c:643: p = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR;
      0090A5 90 0B 74         [24] 2330 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_465
      0090A8 E4               [12] 2331 	clr	a
      0090A9 F0               [24] 2332 	movx	@dptr,a
      0090AA 74 08            [12] 2333 	mov	a,#0x08
      0090AC A3               [24] 2334 	inc	dptr
      0090AD F0               [24] 2335 	movx	@dptr,a
                                   2336 ;	quantum/dynamic_keymap.c:644: uint16_t end = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR + ak820_macro_length();
      0090AE C0 07            [24] 2337 	push	ar7
      0090B0 12 2B 2B         [24] 2338 	lcall	_ak820_macro_length
      0090B3 AD 82            [24] 2339 	mov	r5, dpl
      0090B5 AE 83            [24] 2340 	mov	r6, dph
      0090B7 D0 07            [24] 2341 	pop	ar7
      0090B9 74 08            [12] 2342 	mov	a,#0x08
      0090BB 2E               [12] 2343 	add	a, r6
      0090BC FE               [12] 2344 	mov	r6,a
                                   2345 ;	quantum/dynamic_keymap.c:649: while (id > 0) {
      0090BD 7B 00            [12] 2346 	mov	r3,#0x00
      0090BF 7C 08            [12] 2347 	mov	r4,#0x08
      0090C1                       2348 00111$:
      0090C1 EF               [12] 2349 	mov	a,r7
      0090C2 60 31            [24] 2350 	jz	00113$
                                   2351 ;	quantum/dynamic_keymap.c:653: if (p == end) {
      0090C4 EB               [12] 2352 	mov	a,r3
      0090C5 B5 05 05         [24] 2353 	cjne	a,ar5,00108$
      0090C8 EC               [12] 2354 	mov	a,r4
      0090C9 B5 06 01         [24] 2355 	cjne	a,ar6,00108$
                                   2356 ;	quantum/dynamic_keymap.c:654: return;
      0090CC 22               [24] 2357 	ret
      0090CD                       2358 00108$:
                                   2359 ;	quantum/dynamic_keymap.c:656: if (eeprom_read_byte((const uint8_t *)(uintptr_t)p) == 0) {
      0090CD 8B 01            [24] 2360 	mov	ar1,r3
      0090CF 8C 02            [24] 2361 	mov	ar2,r4
      0090D1 8A 00            [24] 2362 	mov	ar0,r2
      0090D3 7A 00            [12] 2363 	mov	r2,#0x00
      0090D5 89 82            [24] 2364 	mov	dpl, r1
      0090D7 88 83            [24] 2365 	mov	dph, r0
      0090D9 8A F0            [24] 2366 	mov	b, r2
      0090DB 12 42 B6         [24] 2367 	lcall	_eeprom_read_byte
      0090DE E5 82            [12] 2368 	mov	a, dpl
      0090E0 70 06            [24] 2369 	jnz	00110$
                                   2370 ;	quantum/dynamic_keymap.c:657: --id;
      0090E2 1F               [12] 2371 	dec	r7
      0090E3 90 0B 72         [24] 2372 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_459
      0090E6 EF               [12] 2373 	mov	a,r7
      0090E7 F0               [24] 2374 	movx	@dptr,a
      0090E8                       2375 00110$:
                                   2376 ;	quantum/dynamic_keymap.c:659: ++p;
      0090E8 0B               [12] 2377 	inc	r3
      0090E9 BB 00 01         [24] 2378 	cjne	r3,#0x00,00429$
      0090EC 0C               [12] 2379 	inc	r4
      0090ED                       2380 00429$:
      0090ED 90 0B 74         [24] 2381 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_465
      0090F0 12 3A A4         [24] 2382 	lcall	_ak820_outline_0084
      0090F3 80 CC            [24] 2383 	sjmp	00111$
      0090F5                       2384 00113$:
                                   2385 ;	quantum/dynamic_keymap.c:665: sending = true;
      0090F5 90 0B 73         [24] 2386 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_460
      0090F8 74 01            [12] 2387 	mov	a,#0x01
      0090FA F0               [24] 2388 	movx	@dptr,a
                                   2389 ;	quantum/dynamic_keymap.c:667: ak820_macro_cancelled = ak820_macro_primitive = false;
      0090FB 12 93 91         [24] 2390 	lcall	_ak820_outline_0170
      0090FE 90 09 BC         [24] 2391 	mov	dptr,#_ak820_macro_cancelled
      009101 F0               [24] 2392 	movx	@dptr,a
                                   2393 ;	quantum/dynamic_keymap.c:672: char data[4] = {0, 0, 0, 0};
      009102 90 0B 76         [24] 2394 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_472
      009105 F0               [24] 2395 	movx	@dptr,a
      009106 90 0B 77         [24] 2396 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_472 + 0x0001)
      009109 F0               [24] 2397 	movx	@dptr,a
      00910A 90 0B 78         [24] 2398 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_472 + 0x0002)
      00910D F0               [24] 2399 	movx	@dptr,a
      00910E 90 0B 79         [24] 2400 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_472 + 0x0003)
      009111 F0               [24] 2401 	movx	@dptr,a
                                   2402 ;	quantum/dynamic_keymap.c:675: while (p < end
      009112                       2403 00167$:
                                   2404 ;	quantum/dynamic_keymap.c:677: && !ak820_macro_cancelled
      009112 90 0B 74         [24] 2405 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_465
      009115 E0               [24] 2406 	movx	a,@dptr
      009116 FC               [12] 2407 	mov	r4,a
      009117 A3               [24] 2408 	inc	dptr
      009118 E0               [24] 2409 	movx	a,@dptr
      009119 FF               [12] 2410 	mov	r7,a
      00911A C3               [12] 2411 	clr	c
      00911B EC               [12] 2412 	mov	a,r4
      00911C 9D               [12] 2413 	subb	a,r5
      00911D EF               [12] 2414 	mov	a,r7
      00911E 9E               [12] 2415 	subb	a,r6
      00911F 40 02            [24] 2416 	jc	00430$
      009121 61 26            [12] 2417 	ajmp	00169$
      009123                       2418 00430$:
      009123 90 09 BC         [24] 2419 	mov	dptr,#_ak820_macro_cancelled
      009126 E0               [24] 2420 	movx	a,@dptr
      009127 60 02            [24] 2421 	jz	00431$
      009129 61 26            [12] 2422 	ajmp	00169$
      00912B                       2423 00431$:
                                   2424 ;	quantum/dynamic_keymap.c:680: data[0] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      00912B 8C 02            [24] 2425 	mov	ar2,r4
      00912D 8F 03            [24] 2426 	mov	ar3,r7
      00912F 90 0B 74         [24] 2427 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_465
      009132 74 01            [12] 2428 	mov	a,#0x01
      009134 2C               [12] 2429 	add	a, r4
      009135 F0               [24] 2430 	movx	@dptr,a
      009136 E4               [12] 2431 	clr	a
      009137 3F               [12] 2432 	addc	a, r7
      009138 A3               [24] 2433 	inc	dptr
      009139 F0               [24] 2434 	movx	@dptr,a
      00913A 7F 00            [12] 2435 	mov	r7,#0x00
      00913C 12 3A EC         [24] 2436 	lcall	_ak820_outline_0147
      00913F 8F F0            [24] 2437 	mov	b, r7
      009141 12 42 B6         [24] 2438 	lcall	_eeprom_read_byte
      009144 AF 82            [24] 2439 	mov	r7, dpl
      009146 90 0B 76         [24] 2440 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_472
      009149 EF               [12] 2441 	mov	a,r7
      00914A F0               [24] 2442 	movx	@dptr,a
                                   2443 ;	quantum/dynamic_keymap.c:681: data[1] = 0;
      00914B 90 0B 77         [24] 2444 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_472 + 0x0001)
      00914E E4               [12] 2445 	clr	a
      00914F F0               [24] 2446 	movx	@dptr,a
                                   2447 ;	quantum/dynamic_keymap.c:683: if (data[0] == 0) {
      009150 90 0B 76         [24] 2448 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_472
      009153 E0               [24] 2449 	movx	a,@dptr
      009154 70 02            [24] 2450 	jnz	00432$
      009156 61 26            [12] 2451 	ajmp	00169$
      009158                       2452 00432$:
                                   2453 ;	quantum/dynamic_keymap.c:686: if (data[0] == SS_QMK_PREFIX) {
      009158 90 0B 76         [24] 2454 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_472
      00915B E0               [24] 2455 	movx	a,@dptr
      00915C FF               [12] 2456 	mov	r7,a
      00915D BF 01 02         [24] 2457 	cjne	r7,#0x01,00433$
      009160 80 02            [24] 2458 	sjmp	00434$
      009162                       2459 00433$:
      009162 61 09            [12] 2460 	ajmp	00164$
      009164                       2461 00434$:
                                   2462 ;	quantum/dynamic_keymap.c:689: data[1] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      009164 12 93 2E         [24] 2463 	lcall	_ak820_outline_0000
      009167 12 42 B6         [24] 2464 	lcall	_eeprom_read_byte
      00916A AF 82            [24] 2465 	mov	r7, dpl
      00916C 90 0B 77         [24] 2466 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_472 + 0x0001)
      00916F EF               [12] 2467 	mov	a,r7
      009170 F0               [24] 2468 	movx	@dptr,a
                                   2469 ;	quantum/dynamic_keymap.c:690: if (data[1] == 0)
      009171 EF               [12] 2470 	mov	a,r7
      009172 70 02            [24] 2471 	jnz	00435$
      009174 61 26            [12] 2472 	ajmp	00169$
      009176                       2473 00435$:
                                   2474 ;	quantum/dynamic_keymap.c:692: if (data[1] == SS_TAP_CODE || data[1] == SS_DOWN_CODE || data[1] == SS_UP_CODE) {
      009176 12 93 58         [24] 2475 	lcall	_ak820_outline_0094
      009179 BF 01 02         [24] 2476 	cjne	r7,#0x01,00436$
      00917C 80 12            [24] 2477 	sjmp	00151$
      00917E                       2478 00436$:
      00917E 12 93 58         [24] 2479 	lcall	_ak820_outline_0094
      009181 BF 02 02         [24] 2480 	cjne	r7,#0x02,00437$
      009184 80 0A            [24] 2481 	sjmp	00151$
      009186                       2482 00437$:
      009186 12 93 58         [24] 2483 	lcall	_ak820_outline_0094
      009189 BF 03 02         [24] 2484 	cjne	r7,#0x03,00438$
      00918C 80 02            [24] 2485 	sjmp	00439$
      00918E                       2486 00438$:
      00918E 21 EF            [12] 2487 	ajmp	00152$
      009190                       2488 00439$:
      009190                       2489 00151$:
                                   2490 ;	quantum/dynamic_keymap.c:694: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      009190 12 93 2E         [24] 2491 	lcall	_ak820_outline_0000
      009193 12 42 B6         [24] 2492 	lcall	_eeprom_read_byte
      009196 12 93 A9         [24] 2493 	lcall	_ak820_outline_0183
                                   2494 ;	quantum/dynamic_keymap.c:698: if (data[2] != 0) {
      009199 70 02            [24] 2495 	jnz	00440$
      00919B 21 12            [12] 2496 	ajmp	00167$
      00919D                       2497 00440$:
                                   2498 ;	quantum/dynamic_keymap.c:700: ak820_macro_primitive = data[1] != SS_TAP_CODE;
      00919D 12 93 58         [24] 2499 	lcall	_ak820_outline_0094
      0091A0 BF 01 03         [24] 2500 	cjne	r7,#0x01,00441$
      0091A3 D3               [12] 2501 	setb	c
      0091A4 80 01            [24] 2502 	sjmp	00442$
      0091A6                       2503 00441$:
      0091A6 C3               [12] 2504 	clr	c
      0091A7                       2505 00442$:
      0091A7 92 27            [24] 2506 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      0091A9 90 09 BB         [24] 2507 	mov	dptr,#_ak820_macro_primitive
      0091AC B3               [12] 2508 	cpl	c
      0091AD E4               [12] 2509 	clr	a
      0091AE 33               [12] 2510 	rlc	a
      0091AF F0               [24] 2511 	movx	@dptr,a
                                   2512 ;	quantum/dynamic_keymap.c:702: if (data[1] == SS_TAP_CODE) tap_code((uint8_t)data[2]);
      0091B0 12 93 58         [24] 2513 	lcall	_ak820_outline_0094
      0091B3 BF 01 10         [24] 2514 	cjne	r7,#0x01,00122$
      0091B6 12 93 8A         [24] 2515 	lcall	_ak820_outline_0157
      0091B9 C0 06            [24] 2516 	push	ar6
      0091BB C0 05            [24] 2517 	push	ar5
      0091BD 12 7B 31         [24] 2518 	lcall	_tap_code
      0091C0 D0 05            [24] 2519 	pop	ar5
      0091C2 D0 06            [24] 2520 	pop	ar6
      0091C4 80 24            [24] 2521 	sjmp	00123$
      0091C6                       2522 00122$:
                                   2523 ;	quantum/dynamic_keymap.c:703: else if (data[1] == SS_DOWN_CODE) register_code((uint8_t)data[2]);
      0091C6 12 93 58         [24] 2524 	lcall	_ak820_outline_0094
      0091C9 BF 02 10         [24] 2525 	cjne	r7,#0x02,00119$
      0091CC 12 93 8A         [24] 2526 	lcall	_ak820_outline_0157
      0091CF C0 06            [24] 2527 	push	ar6
      0091D1 C0 05            [24] 2528 	push	ar5
      0091D3 12 7A 00         [24] 2529 	lcall	_register_code
      0091D6 D0 05            [24] 2530 	pop	ar5
      0091D8 D0 06            [24] 2531 	pop	ar6
      0091DA 80 0E            [24] 2532 	sjmp	00123$
      0091DC                       2533 00119$:
                                   2534 ;	quantum/dynamic_keymap.c:704: else unregister_code((uint8_t)data[2]);
      0091DC 12 93 8A         [24] 2535 	lcall	_ak820_outline_0157
      0091DF C0 06            [24] 2536 	push	ar6
      0091E1 C0 05            [24] 2537 	push	ar5
      0091E3 12 7A 85         [24] 2538 	lcall	_unregister_code
      0091E6 D0 05            [24] 2539 	pop	ar5
      0091E8 D0 06            [24] 2540 	pop	ar6
      0091EA                       2541 00123$:
                                   2542 ;	quantum/dynamic_keymap.c:706: ak820_macro_primitive = false;
      0091EA 12 93 91         [24] 2543 	lcall	_ak820_outline_0170
      0091ED 21 12            [12] 2544 	ajmp	00167$
      0091EF                       2545 00152$:
                                   2546 ;	quantum/dynamic_keymap.c:714: } else if (data[1] == VIAL_MACRO_EXT_TAP || data[1] == VIAL_MACRO_EXT_DOWN || data[1] == VIAL_MACRO_EXT_UP) {
      0091EF 12 93 58         [24] 2547 	lcall	_ak820_outline_0094
      0091F2 BF 05 02         [24] 2548 	cjne	r7,#0x05,00447$
      0091F5 80 12            [24] 2549 	sjmp	00146$
      0091F7                       2550 00447$:
      0091F7 12 93 58         [24] 2551 	lcall	_ak820_outline_0094
      0091FA BF 06 02         [24] 2552 	cjne	r7,#0x06,00448$
      0091FD 80 0A            [24] 2553 	sjmp	00146$
      0091FF                       2554 00448$:
      0091FF 12 93 58         [24] 2555 	lcall	_ak820_outline_0094
      009202 BF 07 02         [24] 2556 	cjne	r7,#0x07,00449$
      009205 80 02            [24] 2557 	sjmp	00450$
      009207                       2558 00449$:
      009207 41 AB            [12] 2559 	ajmp	00147$
      009209                       2560 00450$:
      009209                       2561 00146$:
                                   2562 ;	quantum/dynamic_keymap.c:715: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      009209 12 93 2E         [24] 2563 	lcall	_ak820_outline_0000
      00920C 12 42 B6         [24] 2564 	lcall	_eeprom_read_byte
      00920F 12 93 A9         [24] 2565 	lcall	_ak820_outline_0183
                                   2566 ;	quantum/dynamic_keymap.c:716: if (data[2] != 0) {
      009212 70 02            [24] 2567 	jnz	00451$
      009214 21 12            [12] 2568 	ajmp	00167$
      009216                       2569 00451$:
                                   2570 ;	quantum/dynamic_keymap.c:717: data[3] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      009216 12 93 2E         [24] 2571 	lcall	_ak820_outline_0000
      009219 12 42 B6         [24] 2572 	lcall	_eeprom_read_byte
      00921C AF 82            [24] 2573 	mov	r7, dpl
      00921E 90 0B 79         [24] 2574 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_472 + 0x0003)
      009221 EF               [12] 2575 	mov	a,r7
      009222 F0               [24] 2576 	movx	@dptr,a
                                   2577 ;	quantum/dynamic_keymap.c:718: if (data[3] != 0) {
      009223 EF               [12] 2578 	mov	a,r7
      009224 70 02            [24] 2579 	jnz	00452$
      009226 21 12            [12] 2580 	ajmp	00167$
      009228                       2581 00452$:
                                   2582 ;	quantum/dynamic_keymap.c:721: kc = (uint8_t)data[2] | ((uint16_t)(uint8_t)data[3] << 8);
      009228 90 0B 78         [24] 2583 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_472 + 0x0002)
      00922B E0               [24] 2584 	movx	a,@dptr
      00922C FF               [12] 2585 	mov	r7,a
      00922D 90 0B 79         [24] 2586 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_472 + 0x0003)
      009230 E0               [24] 2587 	movx	a,@dptr
      009231 FB               [12] 2588 	mov	r3,a
      009232 E4               [12] 2589 	clr	a
      009233 FC               [12] 2590 	mov	r4,a
      009234 FA               [12] 2591 	mov	r2,a
      009235 EF               [12] 2592 	mov	a,r7
      009236 42 04            [12] 2593 	orl	ar4,a
      009238 EA               [12] 2594 	mov	a,r2
      009239 42 03            [12] 2595 	orl	ar3,a
                                   2596 ;	quantum/dynamic_keymap.c:725: kc = decode_keycode(kc);
      00923B 12 45 C3         [24] 2597 	lcall	_ak820_outline_0186
      00923E C0 06            [24] 2598 	push	ar6
      009240 C0 05            [24] 2599 	push	ar5
      009242 11 5E            [12] 2600 	acall	_decode_keycode
      009244 AC 82            [24] 2601 	mov	r4, dpl
      009246 AF 83            [24] 2602 	mov	r7, dph
      009248 D0 05            [24] 2603 	pop	ar5
      00924A D0 06            [24] 2604 	pop	ar6
                                   2605 ;	quantum/dynamic_keymap.c:727: ak820_macro_primitive = data[1] != VIAL_MACRO_EXT_TAP;
      00924C 90 0B 77         [24] 2606 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_472 + 0x0001)
      00924F E0               [24] 2607 	movx	a,@dptr
      009250 FB               [12] 2608 	mov	r3,a
      009251 BB 05 03         [24] 2609 	cjne	r3,#0x05,00453$
      009254 D3               [12] 2610 	setb	c
      009255 80 01            [24] 2611 	sjmp	00454$
      009257                       2612 00453$:
      009257 C3               [12] 2613 	clr	c
      009258                       2614 00454$:
      009258 92 27            [24] 2615 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      00925A 90 09 BB         [24] 2616 	mov	dptr,#_ak820_macro_primitive
      00925D B3               [12] 2617 	cpl	c
      00925E E4               [12] 2618 	clr	a
      00925F 33               [12] 2619 	rlc	a
      009260 F0               [24] 2620 	movx	@dptr,a
                                   2621 ;	quantum/dynamic_keymap.c:729: switch (data[1]) {
      009261 90 0B 77         [24] 2622 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_472 + 0x0001)
      009264 E0               [24] 2623 	movx	a,@dptr
      009265 FB               [12] 2624 	mov	r3,a
      009266 BB 05 02         [24] 2625 	cjne	r3,#0x05,00455$
      009269 80 0A            [24] 2626 	sjmp	00126$
      00926B                       2627 00455$:
      00926B BB 06 02         [24] 2628 	cjne	r3,#0x06,00456$
      00926E 80 16            [24] 2629 	sjmp	00127$
      009270                       2630 00456$:
                                   2631 ;	quantum/dynamic_keymap.c:730: case VIAL_MACRO_EXT_TAP:
      009270 BB 07 33         [24] 2632 	cjne	r3,#0x07,00129$
      009273 80 22            [24] 2633 	sjmp	00128$
      009275                       2634 00126$:
                                   2635 ;	quantum/dynamic_keymap.c:731: vial_keycode_tap(kc);
      009275 8C 82            [24] 2636 	mov	dpl, r4
      009277 8F 83            [24] 2637 	mov	dph, r7
      009279 C0 06            [24] 2638 	push	ar6
      00927B C0 05            [24] 2639 	push	ar5
      00927D 12 B7 09         [24] 2640 	lcall	_vial_keycode_tap
      009280 D0 05            [24] 2641 	pop	ar5
      009282 D0 06            [24] 2642 	pop	ar6
                                   2643 ;	quantum/dynamic_keymap.c:732: break;
                                   2644 ;	quantum/dynamic_keymap.c:733: case VIAL_MACRO_EXT_DOWN:
      009284 80 20            [24] 2645 	sjmp	00129$
      009286                       2646 00127$:
                                   2647 ;	quantum/dynamic_keymap.c:734: vial_keycode_down(kc);
      009286 8C 82            [24] 2648 	mov	dpl, r4
      009288 8F 83            [24] 2649 	mov	dph, r7
      00928A C0 06            [24] 2650 	push	ar6
      00928C C0 05            [24] 2651 	push	ar5
      00928E 12 B6 3E         [24] 2652 	lcall	_vial_keycode_down
      009291 D0 05            [24] 2653 	pop	ar5
      009293 D0 06            [24] 2654 	pop	ar6
                                   2655 ;	quantum/dynamic_keymap.c:735: break;
                                   2656 ;	quantum/dynamic_keymap.c:736: case VIAL_MACRO_EXT_UP:
      009295 80 0F            [24] 2657 	sjmp	00129$
      009297                       2658 00128$:
                                   2659 ;	quantum/dynamic_keymap.c:737: vial_keycode_up(kc);
      009297 8C 82            [24] 2660 	mov	dpl, r4
      009299 8F 83            [24] 2661 	mov	dph, r7
      00929B C0 06            [24] 2662 	push	ar6
      00929D C0 05            [24] 2663 	push	ar5
      00929F 12 B6 A4         [24] 2664 	lcall	_vial_keycode_up
      0092A2 D0 05            [24] 2665 	pop	ar5
      0092A4 D0 06            [24] 2666 	pop	ar6
                                   2667 ;	quantum/dynamic_keymap.c:739: }
      0092A6                       2668 00129$:
                                   2669 ;	quantum/dynamic_keymap.c:741: ak820_macro_primitive = false;
      0092A6 12 93 91         [24] 2670 	lcall	_ak820_outline_0170
      0092A9 21 12            [12] 2671 	ajmp	00167$
      0092AB                       2672 00147$:
                                   2673 ;	quantum/dynamic_keymap.c:745: } else if (data[1] == SS_DELAY_CODE) {
      0092AB 12 93 58         [24] 2674 	lcall	_ak820_outline_0094
      0092AE BF 04 02         [24] 2675 	cjne	r7,#0x04,00458$
      0092B1 80 02            [24] 2676 	sjmp	00459$
      0092B3                       2677 00458$:
      0092B3 21 12            [12] 2678 	ajmp	00167$
      0092B5                       2679 00459$:
                                   2680 ;	quantum/dynamic_keymap.c:747: uint8_t d0 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      0092B5 12 93 2E         [24] 2681 	lcall	_ak820_outline_0000
      0092B8 12 42 B6         [24] 2682 	lcall	_eeprom_read_byte
      0092BB AF 82            [24] 2683 	mov	r7, dpl
                                   2684 ;	quantum/dynamic_keymap.c:748: uint8_t d1 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      0092BD 90 0B 74         [24] 2685 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_465
      0092C0 12 3A D1         [24] 2686 	lcall	_ak820_outline_0124
      0092C3 90 0B 74         [24] 2687 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_465
      0092C6 74 01            [12] 2688 	mov	a,#0x01
      0092C8 2B               [12] 2689 	add	a, r3
      0092C9 F0               [24] 2690 	movx	@dptr,a
      0092CA E4               [12] 2691 	clr	a
      0092CB 3C               [12] 2692 	addc	a, r4
      0092CC A3               [24] 2693 	inc	dptr
      0092CD F0               [24] 2694 	movx	@dptr,a
      0092CE 7A 00            [12] 2695 	mov	r2,#0x00
      0092D0 12 36 47         [24] 2696 	lcall	_ak820_outline_0125
      0092D3 8A F0            [24] 2697 	mov	b, r2
      0092D5 12 42 B6         [24] 2698 	lcall	_eeprom_read_byte
      0092D8 AC 82            [24] 2699 	mov	r4, dpl
                                   2700 ;	quantum/dynamic_keymap.c:749: if (d0 == 0 || d1 == 0)
      0092DA EF               [12] 2701 	mov	a,r7
      0092DB 60 49            [24] 2702 	jz	00169$
      0092DD EC               [12] 2703 	mov	a,r4
      0092DE 60 46            [24] 2704 	jz	00169$
                                   2705 ;	quantum/dynamic_keymap.c:752: uint16_t ms = (uint16_t)(d0 - 1) + (uint16_t)(d1 - 1) * 255u;
      0092E0 1F               [12] 2706 	dec	r7
      0092E1 1C               [12] 2707 	dec	r4
      0092E2 EC               [12] 2708 	mov	a,r4
      0092E3 75 F0 FF         [24] 2709 	mov	b,#0xff
      0092E6 A4               [48] 2710 	mul	ab
      0092E7 FC               [12] 2711 	mov	r4,a
      0092E8 AB F0            [24] 2712 	mov	r3,b
      0092EA 7A 00            [12] 2713 	mov	r2,#0x00
      0092EC EC               [12] 2714 	mov	a,r4
      0092ED 2F               [12] 2715 	add	a, r7
      0092EE FC               [12] 2716 	mov	r4,a
      0092EF EB               [12] 2717 	mov	a,r3
      0092F0 3A               [12] 2718 	addc	a, r2
      0092F1 FB               [12] 2719 	mov	r3,a
                                   2720 ;	quantum/dynamic_keymap.c:753: while (ms--) wait_ms(1);
      0092F2                       2721 00141$:
      0092F2 8C 02            [24] 2722 	mov	ar2,r4
      0092F4 8B 07            [24] 2723 	mov	ar7,r3
      0092F6 1C               [12] 2724 	dec	r4
      0092F7 BC FF 01         [24] 2725 	cjne	r4,#0xff,00462$
      0092FA 1B               [12] 2726 	dec	r3
      0092FB                       2727 00462$:
      0092FB EA               [12] 2728 	mov	a,r2
      0092FC 4F               [12] 2729 	orl	a,r7
      0092FD 70 02            [24] 2730 	jnz	00463$
      0092FF 21 12            [12] 2731 	ajmp	00167$
      009301                       2732 00463$:
      009301 90 00 01         [24] 2733 	mov	dptr,#0x0001
      009304 12 5D 82         [24] 2734 	lcall	_mDelaymS
      009307 80 E9            [24] 2735 	sjmp	00141$
      009309                       2736 00164$:
                                   2737 ;	quantum/dynamic_keymap.c:759: if ((uint8_t)data[0] >= 128) break;
      009309 90 0B 76         [24] 2738 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_472
      00930C E0               [24] 2739 	movx	a,@dptr
      00930D FF               [12] 2740 	mov	r7,a
      00930E BF 80 00         [24] 2741 	cjne	r7,#0x80,00464$
      009311                       2742 00464$:
      009311 50 13            [24] 2743 	jnc	00169$
                                   2744 ;	quantum/dynamic_keymap.c:763: send_char(data[0]);
      009313 90 0B 76         [24] 2745 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_472
      009316 E0               [24] 2746 	movx	a,@dptr
      009317 F5 82            [12] 2747 	mov	dpl,a
      009319 C0 06            [24] 2748 	push	ar6
      00931B C0 05            [24] 2749 	push	ar5
      00931D 12 A9 D2         [24] 2750 	lcall	_send_char
      009320 D0 05            [24] 2751 	pop	ar5
      009322 D0 06            [24] 2752 	pop	ar6
                                   2753 ;	quantum/dynamic_keymap.c:764: for (uint8_t delay = DYNAMIC_KEYMAP_MACRO_DELAY; delay; --delay) wait_ms(1);
      009324 21 12            [12] 2754 	ajmp	00167$
      009326                       2755 00169$:
                                   2756 ;	quantum/dynamic_keymap.c:772: ak820_macro_primitive = false;
      009326 12 93 91         [24] 2757 	lcall	_ak820_outline_0170
                                   2758 ;	quantum/dynamic_keymap.c:774: sending = false;
      009329 90 0B 73         [24] 2759 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_460
      00932C F0               [24] 2760 	movx	@dptr,a
                                   2761 ;	quantum/dynamic_keymap.c:776: }
      00932D 22               [24] 2762 	ret
                                   2763 	.area CSEG    (CODE)
                                   2764 	.area CONST   (CODE)
                                   2765 	.area XINIT   (CODE)
                                   2766 	.area CABS    (ABS,CODE)
                                   2767 
                                   2768 ; Experimental exact instruction outlining.
                                   2769 	.globl _ak820_outline_0000
                                   2770 	.globl _ak820_outline_0005
                                   2771 	.globl _ak820_outline_0008
                                   2772 	.globl _ak820_outline_0013
                                   2773 	.globl _ak820_outline_0021
                                   2774 	.globl _ak820_outline_0033
                                   2775 	.globl _ak820_outline_0034
                                   2776 	.globl _ak820_outline_0050
                                   2777 	.globl _ak820_outline_0052
                                   2778 	.globl _ak820_outline_0057
                                   2779 	.globl _ak820_outline_0059
                                   2780 	.globl _ak820_outline_0060
                                   2781 	.globl _ak820_outline_0061
                                   2782 	.globl _ak820_outline_0072
                                   2783 	.globl _ak820_outline_0078
                                   2784 	.globl _ak820_outline_0080
                                   2785 	.globl _ak820_outline_0084
                                   2786 	.globl _ak820_outline_0091
                                   2787 	.globl _ak820_outline_0093
                                   2788 	.globl _ak820_outline_0094
                                   2789 	.globl _ak820_outline_0100
                                   2790 	.globl _ak820_outline_0101
                                   2791 	.globl _ak820_outline_0104
                                   2792 	.globl _ak820_outline_0105
                                   2793 	.globl _ak820_outline_0109
                                   2794 	.globl _ak820_outline_0110
                                   2795 	.globl _ak820_outline_0113
                                   2796 	.globl _ak820_outline_0118
                                   2797 	.globl _ak820_outline_0120
                                   2798 	.globl _ak820_outline_0124
                                   2799 	.globl _ak820_outline_0125
                                   2800 	.globl _ak820_outline_0126
                                   2801 	.globl _ak820_outline_0130
                                   2802 	.globl _ak820_outline_0135
                                   2803 	.globl _ak820_outline_0136
                                   2804 	.globl _ak820_outline_0137
                                   2805 	.globl _ak820_outline_0138
                                   2806 	.globl _ak820_outline_0139
                                   2807 	.globl _ak820_outline_0146
                                   2808 	.globl _ak820_outline_0147
                                   2809 	.globl _ak820_outline_0154
                                   2810 	.globl _ak820_outline_0157
                                   2811 	.globl _ak820_outline_0161
                                   2812 	.globl _ak820_outline_0163
                                   2813 	.globl _ak820_outline_0165
                                   2814 	.globl _ak820_outline_0170
                                   2815 	.globl _ak820_outline_0179
                                   2816 	.globl _ak820_outline_0180
                                   2817 	.globl _ak820_outline_0183
                                   2818 	.globl _ak820_outline_0184
                                   2819 	.globl _ak820_outline_0185
                                   2820 	.globl _ak820_outline_0186
                                   2821 	.globl _ak820_outline_0189
                                   2822 	.globl _ak820_outline_0191
                                   2823 
                                   2824 	.area CSEG (CODE)
                                   2825 ; function ak820_outline_0000
      00932E                       2826 _ak820_outline_0000:
      00932E 90 0B 74         [24] 2827 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_465
      009331 E0               [24] 2828 	movx	a,@dptr
      009332 FC               [12] 2829 	mov	r4,a
      009333 A3               [24] 2830 	inc	dptr
      009334 E0               [24] 2831 	movx	a,@dptr
      009335 FF               [12] 2832 	mov	r7,a
      009336 90 0B 74         [24] 2833 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_465
      009339 74 01            [12] 2834 	mov	a,#0x01
      00933B 2C               [12] 2835 	add	a,r4
      00933C F0               [24] 2836 	movx	@dptr,a
      00933D E4               [12] 2837 	clr	a
      00933E 3F               [12] 2838 	addc	a,r7
      00933F A3               [24] 2839 	inc	dptr
      009340 F0               [24] 2840 	movx	@dptr,a
      009341 7B 00            [12] 2841 	mov	r3,#0x00
      009343 8C 82            [24] 2842 	mov	dpl,r4
      009345 8F 83            [24] 2843 	mov	dph,r7
      009347 8B F0            [24] 2844 	mov	b,r3
      009349 22               [24] 2845 	ret
                                   2846 
                                   2847 	.area CSEG (CODE)
                                   2848 ; function ak820_outline_0080
      00934A                       2849 _ak820_outline_0080:
      00934A ED               [12] 2850 	mov	a,r5
      00934B 75 F0 0A         [24] 2851 	mov	b,#0x0a
      00934E A4               [48] 2852 	mul	ab
      00934F 24 58            [12] 2853 	add	a,#0x58
      009351 FC               [12] 2854 	mov	r4,a
      009352 74 06            [12] 2855 	mov	a,#0x06
      009354 35 F0            [12] 2856 	addc	a,b
      009356 FD               [12] 2857 	mov	r5,a
      009357 22               [24] 2858 	ret
                                   2859 
                                   2860 	.area CSEG (CODE)
                                   2861 ; function ak820_outline_0094
      009358                       2862 _ak820_outline_0094:
      009358 90 0B 77         [24] 2863 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_472+0x0001)
      00935B E0               [24] 2864 	movx	a,@dptr
      00935C FF               [12] 2865 	mov	r7,a
      00935D 22               [24] 2866 	ret
                                   2867 
                                   2868 	.area CSEG (CODE)
                                   2869 ; function ak820_outline_0100
      00935E                       2870 _ak820_outline_0100:
      00935E 90 0B 0D         [24] 2871 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      009361 EE               [12] 2872 	mov	a,r6
      009362 F0               [24] 2873 	movx	@dptr,a
      009363 90 0B 0E         [24] 2874 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      009366 ED               [12] 2875 	mov	a,r5
      009367 F0               [24] 2876 	movx	@dptr,a
      009368 8F 82            [24] 2877 	mov	dpl,r7
      00936A 22               [24] 2878 	ret
                                   2879 
                                   2880 	.area CSEG (CODE)
                                   2881 ; function ak820_outline_0113
      00936B                       2882 _ak820_outline_0113:
      00936B 74 0A            [12] 2883 	mov	a,#0x0a
      00936D F0               [24] 2884 	movx	@dptr,a
      00936E E4               [12] 2885 	clr	a
      00936F A3               [24] 2886 	inc	dptr
      009370 F0               [24] 2887 	movx	@dptr,a
      009371 22               [24] 2888 	ret
                                   2889 
                                   2890 	.area CSEG (CODE)
                                   2891 ; function ak820_outline_0118
      009372                       2892 _ak820_outline_0118:
      009372 AD 82            [24] 2893 	mov	r5,dpl
      009374 AE 83            [24] 2894 	mov	r6,dph
      009376 AF F0            [24] 2895 	mov	r7,b
      009378 22               [24] 2896 	ret
                                   2897 
                                   2898 	.area CSEG (CODE)
                                   2899 ; function ak820_outline_0130
      009379                       2900 _ak820_outline_0130:
      009379 28               [12] 2901 	add	a,r0
      00937A F5 82            [12] 2902 	mov	dpl,a
      00937C EF               [12] 2903 	mov	a,r7
      00937D 39               [12] 2904 	addc	a,r1
      00937E F5 83            [12] 2905 	mov	dph,a
      009380 74 FF            [12] 2906 	mov	a,#0xff
      009382 F0               [24] 2907 	movx	@dptr,a
      009383 22               [24] 2908 	ret
                                   2909 
                                   2910 	.area CSEG (CODE)
                                   2911 ; function ak820_outline_0138
      009384                       2912 _ak820_outline_0138:
      009384 2D               [12] 2913 	add	a,r5
      009385 F9               [12] 2914 	mov	r1,a
      009386 E4               [12] 2915 	clr	a
      009387 3E               [12] 2916 	addc	a,r6
      009388 FA               [12] 2917 	mov	r2,a
      009389 22               [24] 2918 	ret
                                   2919 
                                   2920 	.area CSEG (CODE)
                                   2921 ; function ak820_outline_0157
      00938A                       2922 _ak820_outline_0157:
      00938A 90 0B 78         [24] 2923 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_472+0x0002)
      00938D E0               [24] 2924 	movx	a,@dptr
      00938E F5 82            [12] 2925 	mov	dpl,a
      009390 22               [24] 2926 	ret
                                   2927 
                                   2928 	.area CSEG (CODE)
                                   2929 ; function ak820_outline_0170
      009391                       2930 _ak820_outline_0170:
      009391 90 09 BB         [24] 2931 	mov	dptr,#_ak820_macro_primitive
      009394 E4               [12] 2932 	clr	a
      009395 F0               [24] 2933 	movx	@dptr,a
      009396 22               [24] 2934 	ret
                                   2935 
                                   2936 	.area CSEG (CODE)
                                   2937 ; function ak820_outline_0179
      009397                       2938 _ak820_outline_0179:
      009397 90 0B 1D         [24] 2939 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      00939A E4               [12] 2940 	clr	a
      00939B F0               [24] 2941 	movx	@dptr,a
      00939C 90 0B 1E         [24] 2942 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      00939F 22               [24] 2943 	ret
                                   2944 
                                   2945 	.area CSEG (CODE)
                                   2946 ; function ak820_outline_0180
      0093A0                       2947 _ak820_outline_0180:
      0093A0 90 0B D3         [24] 2948 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_2
      0093A3 E4               [12] 2949 	clr	a
      0093A4 F0               [24] 2950 	movx	@dptr,a
      0093A5 90 0B D4         [24] 2951 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_3
      0093A8 22               [24] 2952 	ret
                                   2953 
                                   2954 	.area CSEG (CODE)
                                   2955 ; function ak820_outline_0183
      0093A9                       2956 _ak820_outline_0183:
      0093A9 AF 82            [24] 2957 	mov	r7,dpl
      0093AB 90 0B 78         [24] 2958 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_472+0x0002)
      0093AE EF               [12] 2959 	mov	a,r7
      0093AF F0               [24] 2960 	movx	@dptr,a
      0093B0 EF               [12] 2961 	mov	a,r7
      0093B1 22               [24] 2962 	ret
