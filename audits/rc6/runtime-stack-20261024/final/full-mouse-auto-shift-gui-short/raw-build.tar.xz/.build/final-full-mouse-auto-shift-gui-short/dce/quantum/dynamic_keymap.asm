;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (Linux)
;--------------------------------------------------------
	.module dynamic_keymap
	
	.optsdcc -mmcs51 --model-large
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _dynamic_keymap_encoder_to_eeprom_address
	.globl _ak820_combo_valid
	.globl _ak820_eeprom_write_block_xdata
	.globl _ak820_eeprom_read_block_xdata
	.globl _ak820_nvm_flush
	.globl _ak820_nvm_ok
	.globl _ak820_macro_reset
	.globl _ak820_macro_write
	.globl _ak820_macro_length
	.globl _ak820_macro_ready
	.globl _send_char
	.globl _keycode_at_encodermap_location_raw
	.globl _keycode_at_keymap_location_raw
	.globl _vial_keycode_tap
	.globl _vial_keycode_up
	.globl _vial_keycode_down
	.globl _clear_keyboard
	.globl _tap_code
	.globl _unregister_code
	.globl _register_code
	.globl _mDelaymS
	.globl ___memcpy
	.globl _memset
	.globl _eeprom_update_byte
	.globl _eeprom_read_byte
	.globl _ADC_START
	.globl _S0_R_FIFO
	.globl _S0_T_FIFO
	.globl _S0_FREE
	.globl _S0_IF_BYTE
	.globl _S0_IF_FIRST
	.globl _S0_IF_OV
	.globl _S0_FST_ACT
	.globl _CP_RL2
	.globl _C_T2
	.globl _TR2
	.globl _EXEN2
	.globl _TCLK
	.globl _RCLK
	.globl _EXF2
	.globl _CAP1F
	.globl _TF2
	.globl _RI
	.globl _TI
	.globl _RB8
	.globl _TB8
	.globl _REN
	.globl _SM2
	.globl _SM1
	.globl _SM0
	.globl _IT0
	.globl _IE0
	.globl _IT1
	.globl _IE1
	.globl _TR0
	.globl _TF0
	.globl _TR1
	.globl _TF1
	.globl _P4_0
	.globl _P4_1
	.globl _P4_2
	.globl _P4_3
	.globl _P4_4
	.globl _P4_5
	.globl _P4_6
	.globl _RXD
	.globl _TXD
	.globl _INT0
	.globl _INT1
	.globl _T0
	.globl _T1
	.globl _MOSI1
	.globl _MISO1
	.globl _SCK1
	.globl _P3_0
	.globl _P3_1
	.globl _P3_2
	.globl _P3_3
	.globl _P3_4
	.globl _P3_5
	.globl _P3_6
	.globl _P3_7
	.globl _CAP1_
	.globl _T2_
	.globl _CAP2_
	.globl _T2EX_
	.globl _RXD1
	.globl _TXD1
	.globl _P2_0
	.globl _P2_1
	.globl _P2_2
	.globl _P2_3
	.globl _P2_4
	.globl _P2_5
	.globl _P2_6
	.globl _P2_7
	.globl _AIN0
	.globl _AIN1
	.globl _AIN2
	.globl _AIN3
	.globl _AIN4
	.globl _AIN5
	.globl _AIN6
	.globl _AIN7
	.globl _CAP1
	.globl _T2
	.globl _CAP2
	.globl _T2EX
	.globl _INT0_
	.globl _SCS
	.globl _MOSI
	.globl _MISO
	.globl _SCK
	.globl _RXD1_
	.globl _TXD1_
	.globl _P1_0
	.globl _P1_1
	.globl _P1_2
	.globl _P1_3
	.globl _P1_4
	.globl _P1_5
	.globl _P1_6
	.globl _P1_7
	.globl _AIN8
	.globl _AIN9
	.globl _AIN10
	.globl _AIN11
	.globl _AIN12
	.globl _AIN13
	.globl _RXD_
	.globl _TXD_
	.globl _SCL0
	.globl _SDA0
	.globl _P0_0
	.globl _P0_1
	.globl _P0_2
	.globl _P0_3
	.globl _P0_4
	.globl _P0_5
	.globl _P0_6
	.globl _P0_7
	.globl _IE_SPI0
	.globl _IE_USB
	.globl _IE_ADC
	.globl _IE_UART1
	.globl _IE_PWM_I2C
	.globl _IE_GPIO
	.globl _IE_WDOG
	.globl _PX0
	.globl _PT0
	.globl _PX1
	.globl _PT1
	.globl _PS
	.globl _PT2
	.globl _PL_FLAG
	.globl _PH_FLAG
	.globl _EX0
	.globl _ET0
	.globl _EX1
	.globl _ET1
	.globl _ES
	.globl _ET2
	.globl _E_DIS
	.globl _EA
	.globl _P
	.globl _F1
	.globl _OV
	.globl _RS0
	.globl _RS1
	.globl _F0
	.globl _AC
	.globl _CY
	.globl _I2CS_INT_ST
	.globl _I2CX_INT
	.globl _LED_STATUS
	.globl _LED_DMA_H
	.globl _LED_DMA_L
	.globl _LED_DMA
	.globl _LED_PWM_OE
	.globl _LED_COMMON
	.globl _ADC_CHAN
	.globl _ADC_DAT_H
	.globl _ADC_DAT_L
	.globl _ADC_DAT
	.globl _ADC_CTRL
	.globl _SPI1_CK_SE
	.globl _SPI1_CTRL
	.globl _SPI1_DATA
	.globl _SPI1_STAT
	.globl _SIF1
	.globl _SBAUD1
	.globl _SBUF1
	.globl _SCON1
	.globl _SPI0_SETUP
	.globl _SPI0_CK_SE
	.globl _SPI0_CTRL
	.globl _SPI0_DATA
	.globl _SPI0_STAT
	.globl _T2CAP1H
	.globl _T2CAP1L
	.globl _T2CAP1
	.globl _TH2
	.globl _TL2
	.globl _T2COUNT
	.globl _RCAP2H
	.globl _RCAP2L
	.globl _RCAP2
	.globl _T2MOD
	.globl _T2CON
	.globl _SBUF
	.globl _SCON
	.globl _TH1
	.globl _TH0
	.globl _TL1
	.globl _TL0
	.globl _TMOD
	.globl _TCON
	.globl _XBUS_AUX
	.globl _P7
	.globl _P6_DIR
	.globl _P6_OUT_PU
	.globl _P6_IN
	.globl _P5_DIR
	.globl _P5_OUT_PU
	.globl _P5_IN
	.globl _P4_LED_KEY
	.globl _P4_DIR_PU
	.globl _P4_MOD_OC
	.globl _P4
	.globl _P3_DIR_PU
	.globl _P3_MOD_OC
	.globl _P3
	.globl _P2_DIR_PU
	.globl _P2_MOD_OC
	.globl _P2
	.globl _P1_DIR_PU
	.globl _P1_MOD_OC
	.globl _P1
	.globl _P0_DIR_PU
	.globl _P0_MOD_OC
	.globl _P0
	.globl _ROM_CTRL
	.globl _ROM_DATA_HH
	.globl _ROM_DATA_HL
	.globl _ROM_DATA_HI
	.globl _ROM_ADDR_H
	.globl _ROM_ADDR_L
	.globl _ROM_ADDR
	.globl _GPIO_IE
	.globl _IP_EX
	.globl _IE_EX
	.globl _IP
	.globl _IE
	.globl _WDOG_COUNT
	.globl _RESET_KEEP
	.globl _WAKE_CTRL
	.globl _CLOCK_CFG
	.globl _POWER_CFG
	.globl _PCON
	.globl _GLOBAL_CFG
	.globl _SAFE_MOD
	.globl _DPH
	.globl _DPL
	.globl _SP
	.globl _A_INV
	.globl _B
	.globl _ACC
	.globl _PSW
	.globl _dynamic_keymap_macro_set_buffer_PARM_3
	.globl _dynamic_keymap_macro_set_buffer_PARM_2
	.globl _dynamic_keymap_macro_get_buffer_PARM_3
	.globl _dynamic_keymap_macro_get_buffer_PARM_2
	.globl _keycode_at_encodermap_location_PARM_3
	.globl _keycode_at_encodermap_location_PARM_2
	.globl _keycode_at_keymap_location_PARM_3
	.globl _keycode_at_keymap_location_PARM_2
	.globl _dynamic_keymap_set_buffer_PARM_3
	.globl _dynamic_keymap_set_buffer_PARM_2
	.globl _dynamic_keymap_get_buffer_PARM_3
	.globl _dynamic_keymap_get_buffer_PARM_2
	.globl _dynamic_keymap_set_combo_PARM_2
	.globl _dynamic_keymap_get_combo_PARM_2
	.globl _dynamic_keymap_set_encoder_PARM_4
	.globl _dynamic_keymap_set_encoder_PARM_3
	.globl _dynamic_keymap_set_encoder_PARM_2
	.globl _dynamic_keymap_get_encoder_PARM_3
	.globl _dynamic_keymap_get_encoder_PARM_2
	.globl _dynamic_keymap_encoder_to_eeprom_address_PARM_2
	.globl _dynamic_keymap_set_keycode_PARM_4
	.globl _dynamic_keymap_set_keycode_PARM_3
	.globl _dynamic_keymap_set_keycode_PARM_2
	.globl _dynamic_keymap_get_keycode_PARM_3
	.globl _dynamic_keymap_get_keycode_PARM_2
	.globl _dynamic_keymap_key_to_eeprom_address_PARM_3
	.globl _dynamic_keymap_key_to_eeprom_address_PARM_2
	.globl _dynamic_keymap_get_layer_count
	.globl _dynamic_keymap_key_to_eeprom_address
	.globl _dynamic_keymap_get_keycode
	.globl _dynamic_keymap_set_keycode
	.globl _dynamic_keymap_get_encoder
	.globl _dynamic_keymap_set_encoder
	.globl _dynamic_keymap_get_combo
	.globl _dynamic_keymap_set_combo
	.globl _dynamic_keymap_reset
	.globl _dynamic_keymap_get_buffer
	.globl _dynamic_keymap_set_buffer
	.globl _keycode_at_keymap_location
	.globl _keycode_at_encodermap_location
	.globl _dynamic_keymap_macro_get_count
	.globl _dynamic_keymap_macro_get_buffer_size
	.globl _dynamic_keymap_macro_get_buffer
	.globl _dynamic_keymap_macro_set_buffer
	.globl _dynamic_keymap_macro_reset
	.globl _dynamic_keymap_macro_send
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
_PSW	=	0x00d0
_ACC	=	0x00e0
_B	=	0x00f0
_A_INV	=	0x00fd
_SP	=	0x0081
_DPL	=	0x0082
_DPH	=	0x0083
_SAFE_MOD	=	0x00a1
_GLOBAL_CFG	=	0x00b1
_PCON	=	0x0087
_POWER_CFG	=	0x00ba
_CLOCK_CFG	=	0x00b9
_WAKE_CTRL	=	0x00a9
_RESET_KEEP	=	0x00fe
_WDOG_COUNT	=	0x00ff
_IE	=	0x00a8
_IP	=	0x00b8
_IE_EX	=	0x00e8
_IP_EX	=	0x00e9
_GPIO_IE	=	0x00b2
_ROM_ADDR	=	0x8584
_ROM_ADDR_L	=	0x0084
_ROM_ADDR_H	=	0x0085
_ROM_DATA_HI	=	0x8f8e
_ROM_DATA_HL	=	0x008e
_ROM_DATA_HH	=	0x008f
_ROM_CTRL	=	0x0086
_P0	=	0x0080
_P0_MOD_OC	=	0x00c4
_P0_DIR_PU	=	0x00c5
_P1	=	0x0090
_P1_MOD_OC	=	0x0092
_P1_DIR_PU	=	0x0093
_P2	=	0x00a0
_P2_MOD_OC	=	0x0094
_P2_DIR_PU	=	0x0095
_P3	=	0x00b0
_P3_MOD_OC	=	0x0096
_P3_DIR_PU	=	0x0097
_P4	=	0x00c0
_P4_MOD_OC	=	0x00c2
_P4_DIR_PU	=	0x00c3
_P4_LED_KEY	=	0x00c1
_P5_IN	=	0x00aa
_P5_OUT_PU	=	0x00ab
_P5_DIR	=	0x00ac
_P6_IN	=	0x00ad
_P6_OUT_PU	=	0x00ae
_P6_DIR	=	0x00af
_P7	=	0x00f1
_XBUS_AUX	=	0x00a2
_TCON	=	0x0088
_TMOD	=	0x0089
_TL0	=	0x008a
_TL1	=	0x008b
_TH0	=	0x008c
_TH1	=	0x008d
_SCON	=	0x0098
_SBUF	=	0x0099
_T2CON	=	0x00c8
_T2MOD	=	0x00c9
_RCAP2	=	0xcbca
_RCAP2L	=	0x00ca
_RCAP2H	=	0x00cb
_T2COUNT	=	0xcdcc
_TL2	=	0x00cc
_TH2	=	0x00cd
_T2CAP1	=	0xcfce
_T2CAP1L	=	0x00ce
_T2CAP1H	=	0x00cf
_SPI0_STAT	=	0x00f8
_SPI0_DATA	=	0x00f9
_SPI0_CTRL	=	0x00fa
_SPI0_CK_SE	=	0x00fb
_SPI0_SETUP	=	0x00fc
_SCON1	=	0x00bc
_SBUF1	=	0x00bd
_SBAUD1	=	0x00be
_SIF1	=	0x00bf
_SPI1_STAT	=	0x00b4
_SPI1_DATA	=	0x00b5
_SPI1_CTRL	=	0x00b6
_SPI1_CK_SE	=	0x00b7
_ADC_CTRL	=	0x00f3
_ADC_DAT	=	0xf5f4
_ADC_DAT_L	=	0x00f4
_ADC_DAT_H	=	0x00f5
_ADC_CHAN	=	0x00f6
_LED_COMMON	=	0x00a6
_LED_PWM_OE	=	0x00a7
_LED_DMA	=	0xc7c6
_LED_DMA_L	=	0x00c6
_LED_DMA_H	=	0x00c7
_LED_STATUS	=	0x00f7
_I2CX_INT	=	0x00b3
_I2CS_INT_ST	=	0x00bb
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
_CY	=	0x00d7
_AC	=	0x00d6
_F0	=	0x00d5
_RS1	=	0x00d4
_RS0	=	0x00d3
_OV	=	0x00d2
_F1	=	0x00d1
_P	=	0x00d0
_EA	=	0x00af
_E_DIS	=	0x00ae
_ET2	=	0x00ad
_ES	=	0x00ac
_ET1	=	0x00ab
_EX1	=	0x00aa
_ET0	=	0x00a9
_EX0	=	0x00a8
_PH_FLAG	=	0x00bf
_PL_FLAG	=	0x00be
_PT2	=	0x00bd
_PS	=	0x00bc
_PT1	=	0x00bb
_PX1	=	0x00ba
_PT0	=	0x00b9
_PX0	=	0x00b8
_IE_WDOG	=	0x00ef
_IE_GPIO	=	0x00ee
_IE_PWM_I2C	=	0x00ed
_IE_UART1	=	0x00ec
_IE_ADC	=	0x00eb
_IE_USB	=	0x00e9
_IE_SPI0	=	0x00e8
_P0_7	=	0x0087
_P0_6	=	0x0086
_P0_5	=	0x0085
_P0_4	=	0x0084
_P0_3	=	0x0083
_P0_2	=	0x0082
_P0_1	=	0x0081
_P0_0	=	0x0080
_SDA0	=	0x0081
_SCL0	=	0x0080
_TXD_	=	0x0083
_RXD_	=	0x0082
_AIN13	=	0x0085
_AIN12	=	0x0084
_AIN11	=	0x0083
_AIN10	=	0x0082
_AIN9	=	0x0081
_AIN8	=	0x0080
_P1_7	=	0x0097
_P1_6	=	0x0096
_P1_5	=	0x0095
_P1_4	=	0x0094
_P1_3	=	0x0093
_P1_2	=	0x0092
_P1_1	=	0x0091
_P1_0	=	0x0090
_TXD1_	=	0x0097
_RXD1_	=	0x0096
_SCK	=	0x0097
_MISO	=	0x0096
_MOSI	=	0x0095
_SCS	=	0x0094
_INT0_	=	0x0092
_T2EX	=	0x0091
_CAP2	=	0x0091
_T2	=	0x0090
_CAP1	=	0x0090
_AIN7	=	0x0097
_AIN6	=	0x0096
_AIN5	=	0x0095
_AIN4	=	0x0094
_AIN3	=	0x0093
_AIN2	=	0x0092
_AIN1	=	0x0091
_AIN0	=	0x0090
_P2_7	=	0x00a7
_P2_6	=	0x00a6
_P2_5	=	0x00a5
_P2_4	=	0x00a4
_P2_3	=	0x00a3
_P2_2	=	0x00a2
_P2_1	=	0x00a1
_P2_0	=	0x00a0
_TXD1	=	0x00a7
_RXD1	=	0x00a6
_T2EX_	=	0x00a5
_CAP2_	=	0x00a5
_T2_	=	0x00a4
_CAP1_	=	0x00a4
_P3_7	=	0x00b7
_P3_6	=	0x00b6
_P3_5	=	0x00b5
_P3_4	=	0x00b4
_P3_3	=	0x00b3
_P3_2	=	0x00b2
_P3_1	=	0x00b1
_P3_0	=	0x00b0
_SCK1	=	0x00b7
_MISO1	=	0x00b6
_MOSI1	=	0x00b5
_T1	=	0x00b5
_T0	=	0x00b4
_INT1	=	0x00b3
_INT0	=	0x00b2
_TXD	=	0x00b1
_RXD	=	0x00b0
_P4_6	=	0x00c6
_P4_5	=	0x00c5
_P4_4	=	0x00c4
_P4_3	=	0x00c3
_P4_2	=	0x00c2
_P4_1	=	0x00c1
_P4_0	=	0x00c0
_TF1	=	0x008f
_TR1	=	0x008e
_TF0	=	0x008d
_TR0	=	0x008c
_IE1	=	0x008b
_IT1	=	0x008a
_IE0	=	0x0089
_IT0	=	0x0088
_SM0	=	0x009f
_SM1	=	0x009e
_SM2	=	0x009d
_REN	=	0x009c
_TB8	=	0x009b
_RB8	=	0x009a
_TI	=	0x0099
_RI	=	0x0098
_TF2	=	0x00cf
_CAP1F	=	0x00cf
_EXF2	=	0x00ce
_RCLK	=	0x00cd
_TCLK	=	0x00cc
_EXEN2	=	0x00cb
_TR2	=	0x00ca
_C_T2	=	0x00c9
_CP_RL2	=	0x00c8
_S0_FST_ACT	=	0x00ff
_S0_IF_OV	=	0x00fe
_S0_IF_FIRST	=	0x00fd
_S0_IF_BYTE	=	0x00fc
_S0_FREE	=	0x00fb
_S0_T_FIFO	=	0x00fa
_S0_R_FIFO	=	0x00f8
_ADC_START	=	0x00f7
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
_dynamic_keymap_set_encoder_sloc0_1_0:
	.ds 2
_dynamic_keymap_get_combo_sloc0_1_0:
	.ds 1
_ak820_dynamic_read_buffer_sloc0_1_0:
	.ds 1
_dynamic_keymap_set_buffer_sloc0_1_0:
	.ds 2
_dynamic_keymap_set_buffer_sloc1_1_0:
	.ds 2
_dynamic_keymap_set_buffer_sloc2_1_0:
	.ds 1
_dynamic_keymap_macro_get_buffer_sloc0_1_0:
	.ds 2
;--------------------------------------------------------
; overlayable items in internal ram
;--------------------------------------------------------
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; absolute internal ram data
;--------------------------------------------------------
	.area IABS    (ABS,DATA)
	.area IABS    (ABS,DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
_dynamic_keymap_macro_send_sloc0_1_0:
	.ds 1
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; uninitialized external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
_dynamic_keymap_key_to_eeprom_address_PARM_2:
	.ds 1
_dynamic_keymap_key_to_eeprom_address_PARM_3:
	.ds 1
_dynamic_keymap_key_to_eeprom_address_layer_10000_366:
	.ds 1
_dynamic_keymap_get_keycode_PARM_2:
	.ds 1
_dynamic_keymap_get_keycode_PARM_3:
	.ds 1
_dynamic_keymap_get_keycode_layer_10000_368:
	.ds 1
_dynamic_keymap_set_keycode_PARM_2:
	.ds 1
_dynamic_keymap_set_keycode_PARM_3:
	.ds 1
_dynamic_keymap_set_keycode_PARM_4:
	.ds 2
_dynamic_keymap_set_keycode_layer_10000_372:
	.ds 1
_dynamic_keymap_encoder_to_eeprom_address_PARM_2:
	.ds 1
_dynamic_keymap_encoder_to_eeprom_address_layer_10000_376:
	.ds 1
_dynamic_keymap_get_encoder_PARM_2:
	.ds 1
_dynamic_keymap_get_encoder_PARM_3:
	.ds 1
_dynamic_keymap_get_encoder_layer_10000_378:
	.ds 1
_dynamic_keymap_set_encoder_PARM_2:
	.ds 1
_dynamic_keymap_set_encoder_PARM_3:
	.ds 1
_dynamic_keymap_set_encoder_PARM_4:
	.ds 2
_dynamic_keymap_set_encoder_layer_10000_382:
	.ds 1
_dynamic_keymap_get_combo_PARM_2:
	.ds 3
_dynamic_keymap_get_combo_index_10000_386:
	.ds 1
_dynamic_keymap_set_combo_PARM_2:
	.ds 3
_dynamic_keymap_set_combo_index_10000_392:
	.ds 1
_dynamic_keymap_set_combo_stored_10002_397:
	.ds 10
_dynamic_keymap_reset_vial_unlocked_prev_10000_400:
	.ds 1
_dynamic_keymap_reset_combo_10001_409:
	.ds 10
_ak820_dynamic_read_buffer_PARM_2:
	.ds 2
_ak820_dynamic_read_buffer_PARM_3:
	.ds 2
_ak820_dynamic_read_buffer_PARM_4:
	.ds 2
_ak820_dynamic_read_buffer_PARM_5:
	.ds 3
_ak820_dynamic_read_buffer_base_10000_411:
	.ds 2
_ak820_dynamic_read_buffer_available_10000_412:
	.ds 1
_dynamic_keymap_get_buffer_PARM_2:
	.ds 2
_dynamic_keymap_get_buffer_PARM_3:
	.ds 3
_dynamic_keymap_get_buffer_offset_10000_418:
	.ds 2
_dynamic_keymap_set_buffer_PARM_2:
	.ds 2
_dynamic_keymap_set_buffer_PARM_3:
	.ds 3
_dynamic_keymap_set_buffer_offset_10000_420:
	.ds 2
_dynamic_keymap_set_buffer_chk_offset_30001_427:
	.ds 1
_dynamic_keymap_set_buffer_chk_sz_30001_427:
	.ds 1
_dynamic_keymap_set_buffer_i_40001_434:
	.ds 1
_keycode_at_keymap_location_PARM_2:
	.ds 1
_keycode_at_keymap_location_PARM_3:
	.ds 1
_keycode_at_keymap_location_layer_num_10000_438:
	.ds 1
_keycode_at_encodermap_location_PARM_2:
	.ds 1
_keycode_at_encodermap_location_PARM_3:
	.ds 1
_keycode_at_encodermap_location_layer_num_10000_442:
	.ds 1
_dynamic_keymap_macro_get_buffer_PARM_2:
	.ds 2
_dynamic_keymap_macro_get_buffer_PARM_3:
	.ds 3
_dynamic_keymap_macro_get_buffer_offset_10000_450:
	.ds 2
_dynamic_keymap_macro_set_buffer_PARM_2:
	.ds 2
_dynamic_keymap_macro_set_buffer_PARM_3:
	.ds 3
_dynamic_keymap_macro_set_buffer_offset_10000_452:
	.ds 2
_decode_keycode_kc_10000_456:
	.ds 2
_dynamic_keymap_macro_send_id_10000_459:
	.ds 1
_dynamic_keymap_macro_send_sending_10000_460:
	.ds 1
_dynamic_keymap_macro_send_p_10001_465:
	.ds 2
_dynamic_keymap_macro_send_data_10003_472:
	.ds 4
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area XABS    (ABS,XDATA)
;--------------------------------------------------------
; initialized external ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area HOME    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'KEYCODE2SYSTEM'
;------------------------------------------------------------
;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_230'
;------------------------------------------------------------
;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
;	-----------------------------------------
	ar7 = 0x07
	ar6 = 0x06
	ar5 = 0x05
	ar4 = 0x04
	ar3 = 0x03
	ar2 = 0x02
	ar1 = 0x01
	ar0 = 0x00
;	 function dynamic_keymap_get_layer_count
;	-----------------------------------------
_dynamic_keymap_get_layer_count:
;	quantum/dynamic_keymap.c:178: return DYNAMIC_KEYMAP_LAYER_COUNT;
	mov	dpl, #0x06
;	quantum/dynamic_keymap.c:179: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'dynamic_keymap_key_to_eeprom_address'
;------------------------------------------------------------
;row           Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_2'
;column        Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_3'
;layer         Allocated with name '_dynamic_keymap_key_to_eeprom_address_layer_10000_366'
;------------------------------------------------------------
;	quantum/dynamic_keymap.c:181: void *dynamic_keymap_key_to_eeprom_address(uint8_t layer, uint8_t row, uint8_t column) {
;	-----------------------------------------
;	 function dynamic_keymap_key_to_eeprom_address
;	-----------------------------------------
_dynamic_keymap_key_to_eeprom_address:
	mov	a,dpl
	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_layer_10000_366
	movx	@dptr,a
;	quantum/dynamic_keymap.c:183: return ((uint8_t *)DYNAMIC_KEYMAP_EEPROM_ADDR) + (layer * MATRIX_ROWS * MATRIX_COLS * 2) + (row * MATRIX_COLS * 2) + (column * 2);
	movx	a,@dptr
	mov	r7,a
	mov	r6,#0x00
	mov	a,#0x40
	lcall	_ak820_outline_0139
	mov	r5,#0x00
	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
	movx	a,@dptr
	mov	b,#0x10
	mul	ab
	add	a, r6
	mov	r6,a
	mov	a,r7
	addc	a, b
	mov	r7,a
	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
	movx	a,@dptr
	mov	r4,#0x00
	add	a,acc
	mov	r3,a
	mov	a,r4
	rlc	a
	mov	r4,a
	mov	a,r3
	add	a, r6
	mov	r6,a
	mov	a,r4
	addc	a, r7
	mov	r7,a
	lcall	_ak820_outline_0050
;	quantum/dynamic_keymap.c:184: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'dynamic_keymap_get_keycode'
;------------------------------------------------------------
;row           Allocated with name '_dynamic_keymap_get_keycode_PARM_2'
;column        Allocated with name '_dynamic_keymap_get_keycode_PARM_3'
;layer         Allocated with name '_dynamic_keymap_get_keycode_layer_10000_368'
;address       Allocated with name '_dynamic_keymap_get_keycode_address_10001_371'
;keycode       Allocated with name '_dynamic_keymap_get_keycode_keycode_10001_371'
;------------------------------------------------------------
;	quantum/dynamic_keymap.c:186: uint16_t dynamic_keymap_get_keycode(uint8_t layer, uint8_t row, uint8_t column) {
;	-----------------------------------------
;	 function dynamic_keymap_get_keycode
;	-----------------------------------------
_dynamic_keymap_get_keycode:
	mov	a,dpl
	mov	dptr,#_dynamic_keymap_get_keycode_layer_10000_368
	movx	@dptr,a
;	quantum/dynamic_keymap.c:187: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return KC_NO;
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0x06,00121$
00121$:
	jnc	00101$
	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
	movx	a,@dptr
	mov	r6,a
	cjne	r6,#0x10,00123$
00123$:
	jnc	00101$
	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
	movx	a,@dptr
	mov	r5,a
	cjne	r5,#0x08,00125$
00125$:
	jc	00102$
00101$:
	mov	dptr,#0x0000
	ret
00102$:
;	quantum/dynamic_keymap.c:188: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
	lcall	_ak820_outline_0100
	acall	_dynamic_keymap_key_to_eeprom_address
;	quantum/dynamic_keymap.c:190: uint16_t keycode = eeprom_read_byte(address) << 8;
	lcall	_ak820_outline_0118
	lcall	_eeprom_read_byte
	mov	r3,dpl
	mov	r4,#0x00
;	quantum/dynamic_keymap.c:191: keycode |= eeprom_read_byte(address + 1);
	inc	r5
	cjne	r5,#0x00,00127$
	inc	r6
00127$:
	lcall	_ak820_outline_0059
	lcall	_eeprom_read_byte
	mov	r7, dpl
	mov	r6,#0x00
	mov	a,r7
	orl	ar4,a
	mov	a,r6
	orl	ar3,a
;	quantum/dynamic_keymap.c:192: return keycode;
	lcall	_ak820_outline_0186
;	quantum/dynamic_keymap.c:193: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'dynamic_keymap_set_keycode'
;------------------------------------------------------------
;row           Allocated with name '_dynamic_keymap_set_keycode_PARM_2'
;column        Allocated with name '_dynamic_keymap_set_keycode_PARM_3'
;keycode       Allocated with name '_dynamic_keymap_set_keycode_PARM_4'
;layer         Allocated with name '_dynamic_keymap_set_keycode_layer_10000_372'
;address       Allocated with name '_dynamic_keymap_set_keycode_address_10001_375'
;------------------------------------------------------------
;	quantum/dynamic_keymap.c:195: void dynamic_keymap_set_keycode(uint8_t layer, uint8_t row, uint8_t column, uint16_t keycode) {
;	-----------------------------------------
;	 function dynamic_keymap_set_keycode
;	-----------------------------------------
_dynamic_keymap_set_keycode:
	mov	a,dpl
	mov	dptr,#_dynamic_keymap_set_keycode_layer_10000_372
	movx	@dptr,a
;	quantum/dynamic_keymap.c:196: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return;
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0x06,00121$
00121$:
	jnc	00101$
	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
	movx	a,@dptr
	mov	r6,a
	cjne	r6,#0x10,00123$
00123$:
	jnc	00101$
	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
	movx	a,@dptr
	mov	r5,a
	cjne	r5,#0x08,00125$
00125$:
	jc	00102$
00101$:
	ret
00102$:
;	quantum/dynamic_keymap.c:197: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
	lcall	_ak820_outline_0100
	acall	_dynamic_keymap_key_to_eeprom_address
	lcall	_ak820_outline_0118
;	quantum/dynamic_keymap.c:199: eeprom_update_byte(address, (uint8_t)(keycode >> 8));
	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	dptr,#_eeprom_update_byte_PARM_2
	lcall	_ak820_outline_0034
	lcall	_eeprom_update_byte
;	quantum/dynamic_keymap.c:200: eeprom_update_byte(address + 1, (uint8_t)(keycode & 0xFF));
	inc	r5
	cjne	r5,#0x00,00127$
	inc	r6
00127$:
	mov	dptr,#_eeprom_update_byte_PARM_2
	mov	a,r3
	lcall	_ak820_outline_0034
;	quantum/dynamic_keymap.c:201: }
	ljmp	_eeprom_update_byte
;------------------------------------------------------------
;Allocation info for local variables in function 'dynamic_keymap_encoder_to_eeprom_address'
;------------------------------------------------------------
;encoder_id    Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_PARM_2'
;layer         Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_layer_10000_376'
;------------------------------------------------------------
;	quantum/dynamic_keymap.c:204: void *dynamic_keymap_encoder_to_eeprom_address(uint8_t layer, uint8_t encoder_id) {
;	-----------------------------------------
;	 function dynamic_keymap_encoder_to_eeprom_address
;	-----------------------------------------
_dynamic_keymap_encoder_to_eeprom_address:
	mov	a,dpl
	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_layer_10000_376
	movx	@dptr,a
;	quantum/dynamic_keymap.c:205: return ((uint8_t *)DYNAMIC_KEYMAP_ENCODER_EEPROM_ADDR) + (layer * NUM_ENCODERS * 2 * 2) + (encoder_id * 2 * 2);
	movx	a,@dptr
	mov	b,#0x04
	mul	ab
	add	a, #0x40
	mov	r5,a
	mov	a,#0x06
	addc	a, b
	mov	r6,a
	mov	r7,#0x00
	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
	movx	a,@dptr
	mov	b,#0x04
	mul	ab
	add	a, r5
	mov	r5,a
	mov	a,r6
	addc	a, b
	mov	r6,a
	lcall	_ak820_outline_0059
;	quantum/dynamic_keymap.c:206: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'dynamic_keymap_get_encoder'
;------------------------------------------------------------
;encoder_id    Allocated with name '_dynamic_keymap_get_encoder_PARM_2'
;clockwise     Allocated with name '_dynamic_keymap_get_encoder_PARM_3'
;layer         Allocated with name '_dynamic_keymap_get_encoder_layer_10000_378'
;address       Allocated with name '_dynamic_keymap_get_encoder_address_10001_381'
;keycode       Allocated with name '_dynamic_keymap_get_encoder_keycode_10001_381'
;------------------------------------------------------------
;	quantum/dynamic_keymap.c:208: uint16_t dynamic_keymap_get_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise) {
;	-----------------------------------------
;	 function dynamic_keymap_get_encoder
;	-----------------------------------------
_dynamic_keymap_get_encoder:
	mov	a,dpl
	mov	dptr,#_dynamic_keymap_get_encoder_layer_10000_378
	movx	@dptr,a
;	quantum/dynamic_keymap.c:209: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return KC_NO;
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0x06,00131$
00131$:
	jnc	00101$
	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
	movx	a,@dptr
	mov	r6,a
	cjne	r6,#0x01,00133$
00133$:
	jc	00102$
00101$:
	mov	dptr,#0x0000
	ret
00102$:
;	quantum/dynamic_keymap.c:210: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
	lcall	_ak820_outline_0191
	acall	_dynamic_keymap_encoder_to_eeprom_address
	lcall	_ak820_outline_0118
;	quantum/dynamic_keymap.c:212: uint16_t keycode = ((uint16_t)eeprom_read_byte(address + (clockwise ? 0 : 2))) << 8;
	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
	movx	a,@dptr
	mov	r4,a
	movx	a,@dptr
	jz	00106$
	mov	r3,#0x00
	sjmp	00107$
00106$:
	mov	r3,#0x02
00107$:
	mov	a,r3
	lcall	_ak820_outline_0013
	lcall	_eeprom_read_byte
	mov	r2,dpl
	mov	r3,#0x00
;	quantum/dynamic_keymap.c:213: keycode |= eeprom_read_byte(address + (clockwise ? 0 : 2) + 1);
	mov	a,r4
	jz	00108$
	mov	r4,#0x00
	sjmp	00109$
00108$:
	mov	r4,#0x02
00109$:
	mov	a,r4
	lcall	_ak820_outline_0165
	inc	r5
	cjne	r5,#0x00,00137$
	inc	r6
00137$:
	lcall	_ak820_outline_0059
	lcall	_eeprom_read_byte
	mov	r7, dpl
	mov	r6,#0x00
	mov	a,r7
	orl	ar3,a
	mov	a,r6
	orl	ar2,a
;	quantum/dynamic_keymap.c:214: return keycode;
	mov	dpl, r3
	mov	dph, r2
;	quantum/dynamic_keymap.c:215: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'dynamic_keymap_set_encoder'
;------------------------------------------------------------
;sloc0         Allocated with name '_dynamic_keymap_set_encoder_sloc0_1_0'
;encoder_id    Allocated with name '_dynamic_keymap_set_encoder_PARM_2'
;clockwise     Allocated with name '_dynamic_keymap_set_encoder_PARM_3'
;keycode       Allocated with name '_dynamic_keymap_set_encoder_PARM_4'
;layer         Allocated with name '_dynamic_keymap_set_encoder_layer_10000_382'
;address       Allocated with name '_dynamic_keymap_set_encoder_address_10001_385'
;------------------------------------------------------------
;	quantum/dynamic_keymap.c:217: void dynamic_keymap_set_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise, uint16_t keycode) {
;	-----------------------------------------
;	 function dynamic_keymap_set_encoder
;	-----------------------------------------
_dynamic_keymap_set_encoder:
	mov	a,dpl
	mov	dptr,#_dynamic_keymap_set_encoder_layer_10000_382
	movx	@dptr,a
;	quantum/dynamic_keymap.c:218: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return;
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0x06,00131$
00131$:
	jnc	00101$
	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
	movx	a,@dptr
	mov	r6,a
	cjne	r6,#0x01,00133$
00133$:
	jc	00102$
00101$:
	ret
00102$:
;	quantum/dynamic_keymap.c:219: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
	lcall	_ak820_outline_0191
	acall	_dynamic_keymap_encoder_to_eeprom_address
	lcall	_ak820_outline_0118
;	quantum/dynamic_keymap.c:221: eeprom_update_byte(address + (clockwise ? 0 : 2), (uint8_t)(keycode >> 8));
	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
	movx	a,@dptr
	mov	r4,a
	movx	a,@dptr
	jz	00106$
	mov	r3,#0x00
	sjmp	00107$
00106$:
	mov	r3,#0x02
00107$:
	mov	a,r3
	lcall	_ak820_outline_0138
	mov	ar3,r7
	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
	movx	a,@dptr
	mov	_dynamic_keymap_set_encoder_sloc0_1_0,a
	inc	dptr
	movx	a,@dptr
	mov	(_dynamic_keymap_set_encoder_sloc0_1_0 + 1),a
	mov	dptr,#_eeprom_update_byte_PARM_2
	movx	@dptr,a
	lcall	_ak820_outline_0185
	mov	b, r3
	lcall	_eeprom_update_byte
;	quantum/dynamic_keymap.c:222: eeprom_update_byte(address + (clockwise ? 0 : 2) + 1, (uint8_t)(keycode & 0xFF));
	mov	a,r4
	jz	00108$
	mov	r4,#0x00
	sjmp	00109$
00108$:
	mov	r4,#0x02
00109$:
	mov	a,r4
	lcall	_ak820_outline_0165
	inc	r5
	cjne	r5,#0x00,00137$
	inc	r6
00137$:
	mov	dptr,#_eeprom_update_byte_PARM_2
	mov	a,_dynamic_keymap_set_encoder_sloc0_1_0
	lcall	_ak820_outline_0034
;	quantum/dynamic_keymap.c:223: }
	ljmp	_eeprom_update_byte
;------------------------------------------------------------
;Allocation info for local variables in function 'dynamic_keymap_get_combo'
;------------------------------------------------------------
;sloc0         Allocated with name '_dynamic_keymap_get_combo_sloc0_1_0'
;buffer        Allocated with name '_dynamic_keymap_get_combo_PARM_2'
;index         Allocated with name '_dynamic_keymap_get_combo_index_10000_386'
;entry         Allocated with name '_dynamic_keymap_get_combo_entry_10000_387'
;address       Allocated with name '_dynamic_keymap_get_combo_address_10001_389'
;marked        Allocated with name '_dynamic_keymap_get_combo_marked_10002_390'
;------------------------------------------------------------
;	quantum/dynamic_keymap.c:267: int dynamic_keymap_get_combo(uint8_t index, vial_combo_entry_t *buffer) {
;	-----------------------------------------
;	 function dynamic_keymap_get_combo
;	-----------------------------------------
_dynamic_keymap_get_combo:
	mov	a,dpl
	mov	dptr,#_dynamic_keymap_get_combo_index_10000_386
	movx	@dptr,a
;	quantum/dynamic_keymap.c:270: vial_combo_entry_t AK820_STATE_MEM *entry = (vial_combo_entry_t AK820_STATE_MEM *)buffer;
	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
	lcall	_ak820_outline_0052
;	quantum/dynamic_keymap.c:274: if (index >= VIAL_COMBO_ENTRIES)
	mov	dptr,#_dynamic_keymap_get_combo_index_10000_386
	movx	a,@dptr
	mov	r5,a
	cjne	r5,#0x08,00132$
00132$:
	jc	00102$
;	quantum/dynamic_keymap.c:275: return -1;
	mov	dptr,#0xffff
	ret
00102$:
;	quantum/dynamic_keymap.c:277: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
	lcall	_ak820_outline_0080
;	quantum/dynamic_keymap.c:279: ak820_eeprom_read_block_xdata(entry, address, sizeof(vial_combo_entry_t));
	mov	ar2,r6
	mov	ar3,r7
	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
	lcall	_ak820_outline_0072
	clr	a
	inc	dptr
	movx	@dptr,a
	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
	lcall	_ak820_outline_0113
	lcall	_ak820_outline_0147
	push	ar7
	push	ar6
	lcall	_ak820_eeprom_read_block_xdata
	pop	ar6
	pop	ar7
;	quantum/dynamic_keymap.c:284: bool marked = entry->input[2] == AK820_COMBO_MARKER && entry->input[3] == AK820_COMBO_VERSION;
	mov	a,#0x04
	lcall	_ak820_outline_0033
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	cjne	r2,#0x20,00108$
	cjne	r3,#0x08,00108$
	mov	a,#0x06
	lcall	_ak820_outline_0021
	lcall	_ak820_outline_0105
	cjne	r2,#0x01,00136$
	cjne	r3,#0x00,00136$
	sjmp	00109$
00136$:
00108$:
	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x00
	sjmp	00110$
00109$:
	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x01
00110$:
;	quantum/dynamic_keymap.c:285: entry->input[2] = entry->input[3] = 0;
	mov	a,#0x06
	lcall	_ak820_outline_0021
	clr	a
	movx	@dptr,a
	inc	dptr
	lcall	_ak820_outline_0101
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
;	quantum/dynamic_keymap.c:286: if (!marked || !ak820_combo_valid(entry)) memset(entry, 0, sizeof(*entry));
	mov	a,_dynamic_keymap_get_combo_sloc0_1_0
	jz	00103$
	lcall	_ak820_outline_0120
	push	ar7
	push	ar6
	lcall	_ak820_combo_valid
	mov	a, dpl
	pop	ar6
	pop	ar7
	jnz	00104$
00103$:
	mov	r5,#0x00
	mov	dptr,#_memset_PARM_2
	clr	a
	movx	@dptr,a
	mov	dptr,#_memset_PARM_3
	lcall	_ak820_outline_0113
	lcall	_ak820_outline_0050
	lcall	_memset
00104$:
;	quantum/dynamic_keymap.c:289: return 0;
	mov	dptr,#0x0000
;	quantum/dynamic_keymap.c:290: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'dynamic_keymap_set_combo'
;------------------------------------------------------------
;buffer        Allocated with name '_dynamic_keymap_set_combo_PARM_2'
;index         Allocated with name '_dynamic_keymap_set_combo_index_10000_392'
;entry         Allocated with name '_dynamic_keymap_set_combo_entry_10000_393'
;address       Allocated with name '_dynamic_keymap_set_combo_address_10001_396'
;stored        Allocated with name '_dynamic_keymap_set_combo_stored_10002_397'
;------------------------------------------------------------
;	quantum/dynamic_keymap.c:292: int dynamic_keymap_set_combo(uint8_t index, const vial_combo_entry_t *buffer) {
;	-----------------------------------------
;	 function dynamic_keymap_set_combo
;	-----------------------------------------
_dynamic_keymap_set_combo:
	mov	a,dpl
	mov	dptr,#_dynamic_keymap_set_combo_index_10000_392
	movx	@dptr,a
;	quantum/dynamic_keymap.c:294: const vial_combo_entry_t AK820_STATE_MEM *entry = (const vial_combo_entry_t AK820_STATE_MEM *)buffer;
	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
	lcall	_ak820_outline_0005
;	quantum/dynamic_keymap.c:299: if (!ak820_combo_valid(entry) || !ak820_nvm_ok()) return -1;
	push	ar7
	push	ar6
	lcall	_ak820_combo_valid
	mov	a, dpl
	pop	ar6
	pop	ar7
	jz	00101$
	lcall	_ak820_nvm_ok
	mov	a, dpl
	jnz	00102$
00101$:
	mov	dptr,#0xffff
	ret
00102$:
;	quantum/dynamic_keymap.c:301: if (index >= VIAL_COMBO_ENTRIES)
	mov	dptr,#_dynamic_keymap_set_combo_index_10000_392
	movx	a,@dptr
	mov	r5,a
	cjne	r5,#0x08,00133$
00133$:
	jc	00105$
;	quantum/dynamic_keymap.c:302: return -1;
	mov	dptr,#0xffff
	ret
00105$:
;	quantum/dynamic_keymap.c:304: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
	lcall	_ak820_outline_0080
;	quantum/dynamic_keymap.c:306: clear_keyboard();
	push	ar7
	push	ar6
	push	ar5
	push	ar4
	lcall	_clear_keyboard
	pop	ar4
	pop	ar5
	pop	ar6
	pop	ar7
;	quantum/dynamic_keymap.c:307: vial_combo_entry_t stored = *entry;
	mov	dptr,#___memcpy_PARM_2
	lcall	_ak820_outline_0060
	clr	a
	inc	dptr
	movx	@dptr,a
	mov	dptr,#___memcpy_PARM_3
	lcall	_ak820_outline_0113
	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_397
	mov	b,a
	push	ar5
	push	ar4
	lcall	___memcpy
	pop	ar4
	pop	ar5
;	quantum/dynamic_keymap.c:308: stored.input[2] = AK820_COMBO_MARKER;
	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_397 + 0x0004)
	mov	a,#0x20
	movx	@dptr,a
	mov	a,#0x08
	inc	dptr
	movx	@dptr,a
;	quantum/dynamic_keymap.c:309: stored.input[3] = AK820_COMBO_VERSION;
	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_397 + 0x0006)
	mov	a,#0x01
	lcall	_ak820_outline_0137
;	quantum/dynamic_keymap.c:310: ak820_eeprom_write_block_xdata(&stored, address, sizeof(stored));
	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
	lcall	_ak820_outline_0072
	clr	a
	inc	dptr
	movx	@dptr,a
	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
	lcall	_ak820_outline_0113
	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_397
	lcall	_ak820_eeprom_write_block_xdata
;	quantum/dynamic_keymap.c:315: ak820_nvm_flush();
	lcall	_ak820_nvm_flush
;	quantum/dynamic_keymap.c:316: if (!ak820_nvm_ok()) return -1;
	lcall	_ak820_nvm_ok
	mov	a, dpl
	jnz	00107$
	mov	dptr,#0xffff
	ret
00107$:
;	quantum/dynamic_keymap.c:320: return 0;
	mov	dptr,#0x0000
;	quantum/dynamic_keymap.c:321: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'dynamic_keymap_reset'
;------------------------------------------------------------
;vial_unlocked_prev Allocated with name '_dynamic_keymap_reset_vial_unlocked_prev_10000_400'
;layer         Allocated with name '_dynamic_keymap_reset_layer_20000_401'
;row           Allocated with name '_dynamic_keymap_reset_row_40000_403'
;column        Allocated with name '_dynamic_keymap_reset_column_60000_405'
;encoder       Allocated with name '_dynamic_keymap_reset_encoder_40000_407'
;combo         Allocated with name '_dynamic_keymap_reset_combo_10001_409'
;i             Allocated with name '_dynamic_keymap_reset_i_20001_410'
;------------------------------------------------------------
;	quantum/dynamic_keymap.c:346: void dynamic_keymap_reset(void) {
;	-----------------------------------------
;	 function dynamic_keymap_reset
;	-----------------------------------------
_dynamic_keymap_reset:
;	quantum/dynamic_keymap.c:357: bool vial_unlocked_prev = vial_unlocked;
	mov	dptr,#_vial_unlocked
	movx	a,@dptr
	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_400
	movx	@dptr,a
;	quantum/dynamic_keymap.c:358: vial_unlocked = 1;
	mov	dptr,#_vial_unlocked
	mov	a,#0x01
	movx	@dptr,a
;	quantum/dynamic_keymap.c:362: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
	mov	r7,#0x00
00116$:
	cjne	r7,#0x06,00198$
00198$:
	jc	00199$
	ajmp	00104$
00199$:
;	quantum/dynamic_keymap.c:363: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
	mov	r6,#0x00
00110$:
	cjne	r6,#0x10,00200$
00200$:
	jnc	00102$
;	quantum/dynamic_keymap.c:364: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
	mov	r5,#0x00
00107$:
	cjne	r5,#0x08,00202$
00202$:
	jnc	00111$
;	quantum/dynamic_keymap.c:365: dynamic_keymap_set_keycode(layer, row, column, keycode_at_keymap_location_raw(layer, row, column));
	mov	dptr,#_keycode_at_keymap_location_raw_PARM_2
	mov	a,r6
	movx	@dptr,a
	mov	dptr,#_keycode_at_keymap_location_raw_PARM_3
	mov	a,r5
	movx	@dptr,a
	mov	dpl, r7
	push	ar7
	push	ar6
	push	ar5
	lcall	_keycode_at_keymap_location_raw
	mov	r3, dpl
	mov	r4, dph
	pop	ar5
	pop	ar6
	pop	ar7
	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
	mov	a,r6
	movx	@dptr,a
	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
	mov	a,r5
	movx	@dptr,a
	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
	lcall	_ak820_outline_0084
	mov	dpl, r7
	push	ar7
	push	ar6
	push	ar5
	acall	_dynamic_keymap_set_keycode
	pop	ar5
	pop	ar6
	pop	ar7
;	quantum/dynamic_keymap.c:364: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
	inc	r5
	sjmp	00107$
00111$:
;	quantum/dynamic_keymap.c:363: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
	inc	r6
	sjmp	00110$
00102$:
;	quantum/dynamic_keymap.c:369: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
	mov	r6,#0x00
00113$:
	cjne	r6,#0x01,00204$
00204$:
	jnc	00117$
;	quantum/dynamic_keymap.c:370: dynamic_keymap_set_encoder(layer, encoder, true, keycode_at_encodermap_location_raw(layer, encoder, true));
	lcall	_ak820_outline_0180
	inc	a
	movx	@dptr,a
	mov	dpl, r7
	push	ar7
	lcall	_keycode_at_encodermap_location_raw
	lcall	_ak820_outline_0154
	pop	ar7
	lcall	_ak820_outline_0179
	inc	a
	movx	@dptr,a
	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
	lcall	_ak820_outline_0072
	mov	dpl, r7
	push	ar7
	acall	_dynamic_keymap_set_encoder
	pop	ar7
;	quantum/dynamic_keymap.c:371: dynamic_keymap_set_encoder(layer, encoder, false, keycode_at_encodermap_location_raw(layer, encoder, false));
	lcall	_ak820_outline_0180
	movx	@dptr,a
	mov	dpl, r7
	push	ar7
	lcall	_keycode_at_encodermap_location_raw
	lcall	_ak820_outline_0154
	pop	ar7
	lcall	_ak820_outline_0179
	movx	@dptr,a
	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
	lcall	_ak820_outline_0072
	mov	dpl, r7
	push	ar7
	acall	_dynamic_keymap_set_encoder
	pop	ar7
;	quantum/dynamic_keymap.c:369: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
	mov	r6,#0x01
	sjmp	00113$
00117$:
;	quantum/dynamic_keymap.c:362: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
	inc	r7
	ajmp	00116$
00104$:
;	quantum/dynamic_keymap.c:388: vial_combo_entry_t combo = { { 0 }, 0 };
	mov	dptr,#_dynamic_keymap_reset_combo_10001_409
	lcall	_ak820_outline_0184
	mov	dptr,#(_dynamic_keymap_reset_combo_10001_409 + 0x0002)
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
	mov	dptr,#(_dynamic_keymap_reset_combo_10001_409 + 0x0004)
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
	mov	dptr,#(_dynamic_keymap_reset_combo_10001_409 + 0x0006)
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
	mov	dptr,#(_dynamic_keymap_reset_combo_10001_409 + 0x0008)
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
;	quantum/dynamic_keymap.c:389: for (size_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
	mov	r7,a
00119$:
	cjne	r7,#0x08,00206$
00206$:
	jnc	00105$
;	quantum/dynamic_keymap.c:390: dynamic_keymap_set_combo(i, &combo);
	mov	ar6,r7
	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
	mov	a,#_dynamic_keymap_reset_combo_10001_409
	movx	@dptr,a
	mov	a,#(_dynamic_keymap_reset_combo_10001_409 >> 8)
	lcall	_ak820_outline_0093
	mov	dpl, r6
	push	ar7
	acall	_dynamic_keymap_set_combo
	pop	ar7
;	quantum/dynamic_keymap.c:389: for (size_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
	inc	r7
	sjmp	00119$
00105$:
;	quantum/dynamic_keymap.c:403: vial_unlocked = vial_unlocked_prev;
	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_400
	movx	a,@dptr
	mov	dptr,#_vial_unlocked
	movx	@dptr,a
;	quantum/dynamic_keymap.c:405: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_dynamic_read_buffer'
;------------------------------------------------------------
;sloc0         Allocated with name '_ak820_dynamic_read_buffer_sloc0_1_0'
;limit         Allocated with name '_ak820_dynamic_read_buffer_PARM_2'
;offset        Allocated with name '_ak820_dynamic_read_buffer_PARM_3'
;size          Allocated with name '_ak820_dynamic_read_buffer_PARM_4'
;data          Allocated with name '_ak820_dynamic_read_buffer_PARM_5'
;base          Allocated with name '_ak820_dynamic_read_buffer_base_10000_411'
;target        Allocated with name '_ak820_dynamic_read_buffer_target_10000_412'
;available     Allocated with name '_ak820_dynamic_read_buffer_available_10000_412'
;remaining     Allocated with name '_ak820_dynamic_read_buffer_remaining_30000_415'
;i             Allocated with name '_ak820_dynamic_read_buffer_i_20000_417'
;------------------------------------------------------------
;	quantum/dynamic_keymap.c:410: static void ak820_dynamic_read_buffer(uint16_t base, uint16_t limit, uint16_t offset, uint16_t size, uint8_t *data) {
;	-----------------------------------------
;	 function ak820_dynamic_read_buffer
;	-----------------------------------------
_ak820_dynamic_read_buffer:
	lcall	_ak820_outline_0109
	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_411
	lcall	_ak820_outline_0110
;	quantum/dynamic_keymap.c:411: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)data;
	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
	lcall	_ak820_outline_0052
;	quantum/dynamic_keymap.c:412: uint8_t available = 0;
	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_412
	clr	a
	movx	@dptr,a
;	quantum/dynamic_keymap.c:413: if (size > 28) return;
	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
	lcall	_ak820_outline_0061
	mov	ar2,r4
	mov	ar3,r5
	clr	c
	mov	a,#0x1c
	subb	a,r2
	clr	a
	subb	a,r3
	jnc	00102$
;	free result
	ret
00102$:
;	quantum/dynamic_keymap.c:414: if (offset < limit) {
	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
	lcall	_ak820_outline_0105
	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
	lcall	_ak820_outline_0104
	clr	c
	mov	a,r2
	subb	a,r0
	mov	a,r3
	subb	a,r1
	jnc	00104$
;	quantum/dynamic_keymap.c:415: uint16_t remaining = limit - offset;
	mov	a,r0
	clr	c
	subb	a,r2
	mov	r0,a
	mov	a,r1
	subb	a,r3
	mov	r1,a
;	quantum/dynamic_keymap.c:416: available = remaining < size ? remaining : size;
	clr	c
	mov	a,r0
	subb	a,r4
	mov	a,r1
	subb	a,r5
	jc	00114$
	mov	ar0,r4
	mov	ar1,r5
00114$:
	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_412
	mov	a,r0
	movx	@dptr,a
00104$:
;	quantum/dynamic_keymap.c:418: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_412
	movx	a,@dptr
	mov	_ak820_dynamic_read_buffer_sloc0_1_0,a
	movx	a,@dptr
	jz	00106$
	push	ar4
	push	ar5
	mov	ar0,r6
	mov	ar5,r7
	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_411
	movx	a,@dptr
	mov	r1,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	mov	a,r2
	add	a, r1
	mov	r2,a
	mov	a,r3
	addc	a, r4
	mov	r3,a
	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
	mov	a,r2
	movx	@dptr,a
	mov	a,r3
	lcall	_ak820_outline_0093
	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
	mov	a,_ak820_dynamic_read_buffer_sloc0_1_0
	lcall	_ak820_outline_0137
	mov	dpl, r0
	mov	dph, r5
	push	ar7
	push	ar6
	push	ar5
	push	ar4
	lcall	_ak820_eeprom_read_block_xdata
	pop	ar4
	pop	ar5
	pop	ar6
	pop	ar7
;	quantum/dynamic_keymap.c:419: for (uint8_t i = available; i < size; ++i) target[i] = 0;
	pop	ar5
	pop	ar4
;	quantum/dynamic_keymap.c:418: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
00106$:
;	quantum/dynamic_keymap.c:419: for (uint8_t i = available; i < size; ++i) target[i] = 0;
	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_412
	movx	a,@dptr
	mov	r3,a
00109$:
	mov	ar1,r3
	mov	r2,#0x00
	clr	c
	mov	a,r1
	subb	a,r4
	mov	a,r2
	subb	a,r5
	jnc	00111$
	mov	a,r3
	lcall	_ak820_outline_0021
	clr	a
	movx	@dptr,a
	inc	r3
	sjmp	00109$
00111$:
;	quantum/dynamic_keymap.c:420: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'dynamic_keymap_get_buffer'
;------------------------------------------------------------
;size          Allocated with name '_dynamic_keymap_get_buffer_PARM_2'
;data          Allocated with name '_dynamic_keymap_get_buffer_PARM_3'
;offset        Allocated with name '_dynamic_keymap_get_buffer_offset_10000_418'
;------------------------------------------------------------
;	quantum/dynamic_keymap.c:423: void dynamic_keymap_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
;	-----------------------------------------
;	 function dynamic_keymap_get_buffer
;	-----------------------------------------
_dynamic_keymap_get_buffer:
	lcall	_ak820_outline_0109
	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_418
	lcall	_ak820_outline_0110
;	quantum/dynamic_keymap.c:426: DYNAMIC_KEYMAP_LAYER_COUNT * MATRIX_ROWS * MATRIX_COLS * 2, offset, size, data);
	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_418
	lcall	_ak820_outline_0052
	mov	dptr,#_dynamic_keymap_get_buffer_PARM_2
	lcall	_ak820_outline_0061
	mov	dptr,#_dynamic_keymap_get_buffer_PARM_3
	lcall	_ak820_outline_0091
	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
	clr	a
	movx	@dptr,a
	mov	a,#0x06
	inc	dptr
	movx	@dptr,a
	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
	lcall	_ak820_outline_0060
	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
	lcall	_ak820_outline_0072
	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
	mov	a,r1
	lcall	_ak820_outline_0161
	movx	@dptr,a
	mov	dptr,#0x0040
;	quantum/dynamic_keymap.c:448: }
	ajmp	_ak820_dynamic_read_buffer
;------------------------------------------------------------
;Allocation info for local variables in function 'dynamic_keymap_set_buffer'
;------------------------------------------------------------
;sloc0         Allocated with name '_dynamic_keymap_set_buffer_sloc0_1_0'
;sloc1         Allocated with name '_dynamic_keymap_set_buffer_sloc1_1_0'
;sloc2         Allocated with name '_dynamic_keymap_set_buffer_sloc2_1_0'
;size          Allocated with name '_dynamic_keymap_set_buffer_PARM_2'
;data          Allocated with name '_dynamic_keymap_set_buffer_PARM_3'
;offset        Allocated with name '_dynamic_keymap_set_buffer_offset_10000_420'
;dynamic_keymap_eeprom_size Allocated with name '_dynamic_keymap_set_buffer_dynamic_keymap_eeprom_size_10000_421'
;target        Allocated with name '_dynamic_keymap_set_buffer_target_10000_421'
;buffer        Allocated with name '_dynamic_keymap_set_buffer_buffer_10000_421'
;count         Allocated with name '_dynamic_keymap_set_buffer_count_10001_424'
;chk_offset    Allocated with name '_dynamic_keymap_set_buffer_chk_offset_30001_427'
;chk_sz        Allocated with name '_dynamic_keymap_set_buffer_chk_sz_30001_427'
;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_429'
;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_432'
;i             Allocated with name '_dynamic_keymap_set_buffer_i_40001_434'
;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_435'
;------------------------------------------------------------
;	quantum/dynamic_keymap.c:450: void dynamic_keymap_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
;	-----------------------------------------
;	 function dynamic_keymap_set_buffer
;	-----------------------------------------
_dynamic_keymap_set_buffer:
	lcall	_ak820_outline_0109
	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_420
	lcall	_ak820_outline_0110
;	quantum/dynamic_keymap.c:452: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset);
	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_420
	lcall	_ak820_outline_0008
	mov	a,#0x40
	add	a, r4
	mov	r2,a
	clr	a
	addc	a, r5
	mov	r3,a
;	quantum/dynamic_keymap.c:453: uint8_t DYNAMIC_BUFFER_MEM *buffer = (uint8_t DYNAMIC_BUFFER_MEM *)data;
	mov	dptr,#_dynamic_keymap_set_buffer_PARM_3
	lcall	_ak820_outline_0104
;	quantum/dynamic_keymap.c:457: if (!size) return;
	mov	dptr,#_dynamic_keymap_set_buffer_PARM_2
	movx	a,@dptr
	mov	_dynamic_keymap_set_buffer_sloc0_1_0,a
	inc	dptr
	movx	a,@dptr
	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),a
	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
	orl	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
	jnz	00102$
	ret
00102$:
;	quantum/dynamic_keymap.c:459: if (size > 28) return;
	mov	_dynamic_keymap_set_buffer_sloc1_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
	mov	(_dynamic_keymap_set_buffer_sloc1_1_0 + 1),(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
	clr	c
	mov	a,#0x1c
	subb	a,_dynamic_keymap_set_buffer_sloc1_1_0
	clr	a
	subb	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
	jnc	00104$
;	free result
	ret
00104$:
;	quantum/dynamic_keymap.c:461: dynamic_buffer_size_t count = size;
	mov	_dynamic_keymap_set_buffer_sloc2_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
;	quantum/dynamic_keymap.c:465: if (offset >= dynamic_keymap_eeprom_size || dynamic_keymap_eeprom_size - offset < size)
	mov	a,#0x100 - 0x06
	add	a,r7
	jc	00105$
	clr	a
	clr	c
	subb	a,r6
	mov	r6,a
	mov	a,#0x06
	subb	a,r7
	mov	r7,a
	clr	c
	mov	a,r6
	subb	a,_dynamic_keymap_set_buffer_sloc0_1_0
	mov	a,r7
	subb	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
	jnc	00106$
00105$:
;	quantum/dynamic_keymap.c:466: return;
	ret
00106$:
;	quantum/dynamic_keymap.c:470: if (!vial_unlocked) {
	mov	dptr,#_vial_unlocked
	movx	a,@dptr
	jz	00207$
	ajmp	00120$
00207$:
;	quantum/dynamic_keymap.c:472: dynamic_buffer_size_t chk_offset = 0;
	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_427
	clr	a
	movx	@dptr,a
;	quantum/dynamic_keymap.c:473: dynamic_buffer_size_t chk_sz = count;
	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_427
	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
	movx	@dptr,a
;	quantum/dynamic_keymap.c:476: if (offset % 2 != 0) {
	mov	a,r4
	jnb	acc.0,00111$
;	quantum/dynamic_keymap.c:477: uint16_t kc = (eeprom_read_byte(target - 1) << 8) | buffer[0];
	mov	a,r2
	add	a,#0xff
	mov	r6,a
	mov	a,r3
	addc	a,#0xff
	mov	r7,a
	mov	r5,#0x00
	lcall	_ak820_outline_0050
	lcall	_eeprom_read_byte
	mov	r6,dpl
	mov	r7,#0x00
	lcall	_ak820_outline_0163
	movx	a,@dptr
	mov	r4,#0x00
	orl	ar7,a
	mov	a,r4
	orl	ar6,a
;	quantum/dynamic_keymap.c:478: if (kc == QK_BOOT)
	cjne	r7,#0x00,00109$
	cjne	r6,#0x7c,00109$
;	quantum/dynamic_keymap.c:479: buffer[0] = 0xFF;
	lcall	_ak820_outline_0163
	mov	a,#0xff
	movx	@dptr,a
00109$:
;	quantum/dynamic_keymap.c:482: chk_offset += 1;
	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_427
	mov	a,#0x01
	movx	@dptr,a
00111$:
;	quantum/dynamic_keymap.c:486: if ((offset + size) % 2 != 0) {
	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_420
	lcall	_ak820_outline_0052
	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
	add	a, r6
	mov	r6,a
	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
	addc	a, r7
	mov	a,r6
	jnb	acc.0,00115$
;	quantum/dynamic_keymap.c:487: uint16_t kc = (buffer[count - 1] << 8) | eeprom_read_byte(target + count);
	mov	r6,_dynamic_keymap_set_buffer_sloc2_1_0
	mov	r7,#0x00
	mov	a,r6
	add	a,#0xff
	mov	r4,a
	mov	a,r7
	addc	a,#0xff
	mov	r5,a
	mov	a,r4
	add	a, r0
	mov	dpl,a
	mov	a,r5
	addc	a, r1
	mov	dph,a
	movx	a,@dptr
	mov	r4,a
	mov	r5,#0x00
	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
	add	a, r2
	mov	r2,a
	clr	a
	addc	a, r3
	mov	r3,a
	push	ar0
	push	ar1
	mov	ar1,r3
	mov	r3,#0x00
	mov	dpl, r2
	mov	dph, r1
	mov	b, r3
	lcall	_eeprom_read_byte
	mov	r3, dpl
	mov	r2,#0x00
	mov	a,r3
	lcall	_ak820_outline_0146
;	quantum/dynamic_keymap.c:488: if (kc == QK_BOOT)
	cjne	r5,#0x00,00212$
	cjne	r4,#0x7c,00212$
	sjmp	00213$
00212$:
	pop	ar1
	pop	ar0
	sjmp	00113$
00213$:
	pop	ar1
	pop	ar0
;	quantum/dynamic_keymap.c:489: buffer[count - 1] = 0xFF;
	dec	r6
	cjne	r6,#0xff,00214$
	dec	r7
00214$:
	mov	a,r6
	lcall	_ak820_outline_0130
00113$:
;	quantum/dynamic_keymap.c:492: chk_sz -= 1;
	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
	dec	a
	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_427
	movx	@dptr,a
00115$:
;	quantum/dynamic_keymap.c:496: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_427
	movx	a,@dptr
	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_434
	movx	@dptr,a
00122$:
	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_434
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_427
	movx	a,@dptr
	mov	r6,a
	clr	c
	mov	a,r7
	subb	a,r6
	jnc	00120$
;	quantum/dynamic_keymap.c:497: uint16_t kc = (buffer[i] << 8) | buffer[i + 1];
	mov	a,r7
	add	a, r0
	mov	r5,a
	clr	a
	addc	a, r1
	lcall	_ak820_outline_0057
	mov	r3,#0x00
	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),r4
	mov	_dynamic_keymap_set_buffer_sloc0_1_0,r3
	mov	ar2,r7
	mov	r7,#0x00
	mov	a,#0x01
	add	a, r2
	mov	r3,a
	clr	a
	addc	a, r7
	mov	r4,a
	mov	a,r3
	add	a, r0
	mov	dpl,a
	mov	a,r4
	addc	a, r1
	mov	dph,a
	movx	a,@dptr
	mov	r4,a
	mov	r3,#0x00
	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
	orl	ar3,a
;	quantum/dynamic_keymap.c:498: if (kc == QK_BOOT) {
	cjne	r4,#0x00,00123$
	cjne	r3,#0x7c,00123$
;	quantum/dynamic_keymap.c:499: buffer[i] = 0xFF;
	lcall	_ak820_outline_0135
	mov	a,#0xff
	movx	@dptr,a
;	quantum/dynamic_keymap.c:500: buffer[i + 1] = 0xFF;
	inc	r2
	cjne	r2,#0x00,00218$
	inc	r7
00218$:
	mov	a,r2
	lcall	_ak820_outline_0130
00123$:
;	quantum/dynamic_keymap.c:496: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_434
	movx	a,@dptr
	add	a,#0x02
	movx	@dptr,a
	sjmp	00122$
00120$:
;	quantum/dynamic_keymap.c:511: ak820_eeprom_write_block_xdata(buffer, (void *)(uintptr_t)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset), size);
	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_420
	lcall	_ak820_outline_0052
	mov	a,#0x40
	lcall	_ak820_outline_0139
	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
	lcall	_ak820_outline_0060
	clr	a
	inc	dptr
	movx	@dptr,a
	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
	mov	a,_dynamic_keymap_set_buffer_sloc1_1_0
	movx	@dptr,a
	mov	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
	inc	dptr
	movx	@dptr,a
	lcall	_ak820_outline_0163
;	quantum/dynamic_keymap.c:521: }
	ljmp	_ak820_eeprom_write_block_xdata
;------------------------------------------------------------
;Allocation info for local variables in function 'keycode_at_keymap_location'
;------------------------------------------------------------
;row           Allocated with name '_keycode_at_keymap_location_PARM_2'
;column        Allocated with name '_keycode_at_keymap_location_PARM_3'
;layer_num     Allocated with name '_keycode_at_keymap_location_layer_num_10000_438'
;------------------------------------------------------------
;	quantum/dynamic_keymap.c:523: uint16_t keycode_at_keymap_location(uint8_t layer_num, uint8_t row, uint8_t column) {
;	-----------------------------------------
;	 function keycode_at_keymap_location
;	-----------------------------------------
_keycode_at_keymap_location:
	mov	a,dpl
	mov	dptr,#_keycode_at_keymap_location_layer_num_10000_438
	movx	@dptr,a
;	quantum/dynamic_keymap.c:524: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && row < MATRIX_ROWS && column < MATRIX_COLS) {
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0x06,00128$
00128$:
	jnc	00102$
	mov	dptr,#_keycode_at_keymap_location_PARM_2
	movx	a,@dptr
	mov	r6,a
	cjne	r6,#0x10,00130$
00130$:
	jnc	00102$
	mov	dptr,#_keycode_at_keymap_location_PARM_3
	movx	a,@dptr
	mov	r5,a
	cjne	r5,#0x08,00132$
00132$:
	jnc	00102$
;	quantum/dynamic_keymap.c:525: return dynamic_keymap_get_keycode(layer_num, row, column);
	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
	mov	a,r6
	movx	@dptr,a
	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
	mov	a,r5
	movx	@dptr,a
	mov	dpl, r7
	ljmp	_dynamic_keymap_get_keycode
00102$:
;	quantum/dynamic_keymap.c:527: return KC_NO;
	mov	dptr,#0x0000
;	quantum/dynamic_keymap.c:528: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'keycode_at_encodermap_location'
;------------------------------------------------------------
;encoder_idx   Allocated with name '_keycode_at_encodermap_location_PARM_2'
;clockwise     Allocated with name '_keycode_at_encodermap_location_PARM_3'
;layer_num     Allocated with name '_keycode_at_encodermap_location_layer_num_10000_442'
;------------------------------------------------------------
;	quantum/dynamic_keymap.c:531: uint16_t keycode_at_encodermap_location(uint8_t layer_num, uint8_t encoder_idx, bool clockwise) {
;	-----------------------------------------
;	 function keycode_at_encodermap_location
;	-----------------------------------------
_keycode_at_encodermap_location:
	mov	a,dpl
	mov	dptr,#_keycode_at_encodermap_location_layer_num_10000_442
	movx	@dptr,a
;	quantum/dynamic_keymap.c:532: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && encoder_idx < NUM_ENCODERS) {
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0x06,00120$
00120$:
	jnc	00102$
	mov	dptr,#_keycode_at_encodermap_location_PARM_2
	movx	a,@dptr
	mov	r6,a
	cjne	r6,#0x01,00122$
00122$:
	jnc	00102$
;	quantum/dynamic_keymap.c:533: return dynamic_keymap_get_encoder(layer_num, encoder_idx, clockwise);
	mov	dptr,#_keycode_at_encodermap_location_PARM_3
	movx	a,@dptr
	mov	r6,a
	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
	clr	a
	movx	@dptr,a
	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
	mov	a,r6
	movx	@dptr,a
	mov	dpl, r7
	ljmp	_dynamic_keymap_get_encoder
00102$:
;	quantum/dynamic_keymap.c:535: return KC_NO;
	mov	dptr,#0x0000
;	quantum/dynamic_keymap.c:536: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'dynamic_keymap_macro_get_count'
;------------------------------------------------------------
;	quantum/dynamic_keymap.c:539: uint8_t dynamic_keymap_macro_get_count(void) {
;	-----------------------------------------
;	 function dynamic_keymap_macro_get_count
;	-----------------------------------------
_dynamic_keymap_macro_get_count:
;	quantum/dynamic_keymap.c:540: return DYNAMIC_KEYMAP_MACRO_COUNT;
	mov	dpl, #0x10
;	quantum/dynamic_keymap.c:541: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer_size'
;------------------------------------------------------------
;	quantum/dynamic_keymap.c:543: uint16_t dynamic_keymap_macro_get_buffer_size(void) {
;	-----------------------------------------
;	 function dynamic_keymap_macro_get_buffer_size
;	-----------------------------------------
_dynamic_keymap_macro_get_buffer_size:
;	quantum/dynamic_keymap.c:544: return DYNAMIC_KEYMAP_MACRO_EEPROM_SIZE;
	mov	dptr,#0x2000
;	quantum/dynamic_keymap.c:545: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer'
;------------------------------------------------------------
;sloc0         Allocated with name '_dynamic_keymap_macro_get_buffer_sloc0_1_0'
;size          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_2'
;data          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_3'
;offset        Allocated with name '_dynamic_keymap_macro_get_buffer_offset_10000_450'
;------------------------------------------------------------
;	quantum/dynamic_keymap.c:547: void dynamic_keymap_macro_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
;	-----------------------------------------
;	 function dynamic_keymap_macro_get_buffer
;	-----------------------------------------
_dynamic_keymap_macro_get_buffer:
	lcall	_ak820_outline_0109
	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_450
	lcall	_ak820_outline_0110
;	quantum/dynamic_keymap.c:550: ak820_macro_length(), offset, size, data);
	lcall	_ak820_macro_length
	lcall	_ak820_outline_0136
	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_450
	lcall	_ak820_outline_0061
	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_2
	movx	a,@dptr
	mov	_dynamic_keymap_macro_get_buffer_sloc0_1_0,a
	inc	dptr
	movx	a,@dptr
	mov	(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1),a
	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_3
	lcall	_ak820_outline_0104
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
	lcall	_ak820_outline_0060
	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
	lcall	_ak820_outline_0072
	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
	mov	a,_dynamic_keymap_macro_get_buffer_sloc0_1_0
	movx	@dptr,a
	mov	a,(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1)
	inc	dptr
	movx	@dptr,a
	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
	mov	a,r0
	movx	@dptr,a
	mov	a,r1
	inc	dptr
	lcall	_ak820_outline_0189
	mov	dptr,#0x0800
;	quantum/dynamic_keymap.c:572: }
	ljmp	_ak820_dynamic_read_buffer
;------------------------------------------------------------
;Allocation info for local variables in function 'dynamic_keymap_macro_set_buffer'
;------------------------------------------------------------
;size          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_2'
;data          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_3'
;offset        Allocated with name '_dynamic_keymap_macro_set_buffer_offset_10000_452'
;------------------------------------------------------------
;	quantum/dynamic_keymap.c:575: bool dynamic_keymap_macro_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
;	-----------------------------------------
;	 function dynamic_keymap_macro_set_buffer
;	-----------------------------------------
_dynamic_keymap_macro_set_buffer:
	lcall	_ak820_outline_0109
	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_452
	lcall	_ak820_outline_0110
;	quantum/dynamic_keymap.c:576: return ak820_macro_write(offset, size, data);
	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_452
	lcall	_ak820_outline_0052
	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_2
	lcall	_ak820_outline_0061
	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_3
	lcall	_ak820_outline_0091
	mov	dptr,#_ak820_macro_write_PARM_2
	lcall	_ak820_outline_0072
	mov	dptr,#_ak820_macro_write_PARM_3
	mov	a,r1
	lcall	_ak820_outline_0161
	lcall	_ak820_outline_0078
;	quantum/dynamic_keymap.c:577: }
	ljmp	_ak820_macro_write
;------------------------------------------------------------
;Allocation info for local variables in function 'dynamic_keymap_macro_reset'
;------------------------------------------------------------
;	quantum/dynamic_keymap.c:592: void dynamic_keymap_macro_reset(void) {
;	-----------------------------------------
;	 function dynamic_keymap_macro_reset
;	-----------------------------------------
_dynamic_keymap_macro_reset:
;	quantum/dynamic_keymap.c:594: ak820_macro_reset();
;	quantum/dynamic_keymap.c:603: }
	ljmp	_ak820_macro_reset
;------------------------------------------------------------
;Allocation info for local variables in function 'decode_keycode'
;------------------------------------------------------------
;kc            Allocated with name '_decode_keycode_kc_10000_456'
;------------------------------------------------------------
;	quantum/dynamic_keymap.c:605: static uint16_t decode_keycode(uint16_t kc) {
;	-----------------------------------------
;	 function decode_keycode
;	-----------------------------------------
_decode_keycode:
	lcall	_ak820_outline_0109
	mov	dptr,#_decode_keycode_kc_10000_456
	lcall	_ak820_outline_0110
;	quantum/dynamic_keymap.c:607: if (kc > 0xFF00)
	mov	dptr,#_decode_keycode_kc_10000_456
	lcall	_ak820_outline_0008
	clr	c
	clr	a
	subb	a,r4
	mov	a,#0xff
	subb	a,r5
	jnc	00102$
;	free result
;	quantum/dynamic_keymap.c:608: return (kc & 0xFF) << 8;
	mov	ar5,r4
	mov	r4,#0x00
	lcall	_ak820_outline_0126
	ret
00102$:
;	quantum/dynamic_keymap.c:609: return kc;
	lcall	_ak820_outline_0120
;	quantum/dynamic_keymap.c:610: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'dynamic_keymap_macro_send'
;------------------------------------------------------------
;id            Allocated with name '_dynamic_keymap_macro_send_id_10000_459'
;sending       Allocated with name '_dynamic_keymap_macro_send_sending_10000_460'
;p             Allocated with name '_dynamic_keymap_macro_send_p_10001_465'
;end           Allocated with name '_dynamic_keymap_macro_send_end_10002_466'
;data          Allocated with name '_dynamic_keymap_macro_send_data_10003_472'
;kc            Allocated with name '_dynamic_keymap_macro_send_kc_110003_490'
;d0            Allocated with name '_dynamic_keymap_macro_send_d0_80003_494'
;d1            Allocated with name '_dynamic_keymap_macro_send_d1_80003_494'
;ms            Allocated with name '_dynamic_keymap_macro_send_ms_80004_496'
;i             Allocated with name '_dynamic_keymap_macro_send_i_100004_498'
;delay         Allocated with name '_dynamic_keymap_macro_send_delay_50003_502'
;i             Allocated with name '_dynamic_keymap_macro_send_i_70003_504'
;------------------------------------------------------------
;	quantum/dynamic_keymap.c:612: void dynamic_keymap_macro_send(uint8_t id) {
;	-----------------------------------------
;	 function dynamic_keymap_macro_send
;	-----------------------------------------
_dynamic_keymap_macro_send:
	mov	a,dpl
	mov	dptr,#_dynamic_keymap_macro_send_id_10000_459
	movx	@dptr,a
;	quantum/dynamic_keymap.c:617: if (sending) return;
	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_460
	movx	a,@dptr
	jz	00102$
	ret
00102$:
;	quantum/dynamic_keymap.c:619: if (id >= DYNAMIC_KEYMAP_MACRO_COUNT) {
	mov	dptr,#_dynamic_keymap_macro_send_id_10000_459
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0x10,00422$
00422$:
	jc	00104$
;	quantum/dynamic_keymap.c:620: return;
	ret
00104$:
;	quantum/dynamic_keymap.c:626: if (!ak820_macro_ready()) return;
	push	ar7
	lcall	_ak820_macro_ready
	mov	a, dpl
	pop	ar7
	jnz	00106$
	ret
00106$:
;	quantum/dynamic_keymap.c:643: p = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR;
	mov	dptr,#_dynamic_keymap_macro_send_p_10001_465
	clr	a
	movx	@dptr,a
	mov	a,#0x08
	inc	dptr
	movx	@dptr,a
;	quantum/dynamic_keymap.c:644: uint16_t end = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR + ak820_macro_length();
	push	ar7
	lcall	_ak820_macro_length
	mov	r5, dpl
	mov	r6, dph
	pop	ar7
	mov	a,#0x08
	add	a, r6
	mov	r6,a
;	quantum/dynamic_keymap.c:649: while (id > 0) {
	mov	r3,#0x00
	mov	r4,#0x08
00111$:
	mov	a,r7
	jz	00113$
;	quantum/dynamic_keymap.c:653: if (p == end) {
	mov	a,r3
	cjne	a,ar5,00108$
	mov	a,r4
	cjne	a,ar6,00108$
;	quantum/dynamic_keymap.c:654: return;
	ret
00108$:
;	quantum/dynamic_keymap.c:656: if (eeprom_read_byte((const uint8_t *)(uintptr_t)p) == 0) {
	mov	ar1,r3
	mov	ar2,r4
	mov	ar0,r2
	mov	r2,#0x00
	mov	dpl, r1
	mov	dph, r0
	mov	b, r2
	lcall	_eeprom_read_byte
	mov	a, dpl
	jnz	00110$
;	quantum/dynamic_keymap.c:657: --id;
	dec	r7
	mov	dptr,#_dynamic_keymap_macro_send_id_10000_459
	mov	a,r7
	movx	@dptr,a
00110$:
;	quantum/dynamic_keymap.c:659: ++p;
	inc	r3
	cjne	r3,#0x00,00429$
	inc	r4
00429$:
	mov	dptr,#_dynamic_keymap_macro_send_p_10001_465
	lcall	_ak820_outline_0084
	sjmp	00111$
00113$:
;	quantum/dynamic_keymap.c:665: sending = true;
	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_460
	mov	a,#0x01
	movx	@dptr,a
;	quantum/dynamic_keymap.c:667: ak820_macro_cancelled = ak820_macro_primitive = false;
	lcall	_ak820_outline_0170
	mov	dptr,#_ak820_macro_cancelled
	movx	@dptr,a
;	quantum/dynamic_keymap.c:672: char data[4] = {0, 0, 0, 0};
	mov	dptr,#_dynamic_keymap_macro_send_data_10003_472
	movx	@dptr,a
	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_472 + 0x0001)
	movx	@dptr,a
	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_472 + 0x0002)
	movx	@dptr,a
	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_472 + 0x0003)
	movx	@dptr,a
;	quantum/dynamic_keymap.c:675: while (p < end
00167$:
;	quantum/dynamic_keymap.c:677: && !ak820_macro_cancelled
	mov	dptr,#_dynamic_keymap_macro_send_p_10001_465
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	clr	c
	mov	a,r4
	subb	a,r5
	mov	a,r7
	subb	a,r6
	jc	00430$
	ajmp	00169$
00430$:
	mov	dptr,#_ak820_macro_cancelled
	movx	a,@dptr
	jz	00431$
	ajmp	00169$
00431$:
;	quantum/dynamic_keymap.c:680: data[0] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
	mov	ar2,r4
	mov	ar3,r7
	mov	dptr,#_dynamic_keymap_macro_send_p_10001_465
	mov	a,#0x01
	add	a, r4
	movx	@dptr,a
	clr	a
	addc	a, r7
	inc	dptr
	movx	@dptr,a
	mov	r7,#0x00
	lcall	_ak820_outline_0147
	mov	b, r7
	lcall	_eeprom_read_byte
	mov	r7, dpl
	mov	dptr,#_dynamic_keymap_macro_send_data_10003_472
	mov	a,r7
	movx	@dptr,a
;	quantum/dynamic_keymap.c:681: data[1] = 0;
	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_472 + 0x0001)
	clr	a
	movx	@dptr,a
;	quantum/dynamic_keymap.c:683: if (data[0] == 0) {
	mov	dptr,#_dynamic_keymap_macro_send_data_10003_472
	movx	a,@dptr
	jnz	00432$
	ajmp	00169$
00432$:
;	quantum/dynamic_keymap.c:686: if (data[0] == SS_QMK_PREFIX) {
	mov	dptr,#_dynamic_keymap_macro_send_data_10003_472
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0x01,00433$
	sjmp	00434$
00433$:
	ajmp	00164$
00434$:
;	quantum/dynamic_keymap.c:689: data[1] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
	lcall	_ak820_outline_0000
	lcall	_eeprom_read_byte
	mov	r7, dpl
	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_472 + 0x0001)
	mov	a,r7
	movx	@dptr,a
;	quantum/dynamic_keymap.c:690: if (data[1] == 0)
	mov	a,r7
	jnz	00435$
	ajmp	00169$
00435$:
;	quantum/dynamic_keymap.c:692: if (data[1] == SS_TAP_CODE || data[1] == SS_DOWN_CODE || data[1] == SS_UP_CODE) {
	lcall	_ak820_outline_0094
	cjne	r7,#0x01,00436$
	sjmp	00151$
00436$:
	lcall	_ak820_outline_0094
	cjne	r7,#0x02,00437$
	sjmp	00151$
00437$:
	lcall	_ak820_outline_0094
	cjne	r7,#0x03,00438$
	sjmp	00439$
00438$:
	ajmp	00152$
00439$:
00151$:
;	quantum/dynamic_keymap.c:694: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
	lcall	_ak820_outline_0000
	lcall	_eeprom_read_byte
	lcall	_ak820_outline_0183
;	quantum/dynamic_keymap.c:698: if (data[2] != 0) {
	jnz	00440$
	ajmp	00167$
00440$:
;	quantum/dynamic_keymap.c:700: ak820_macro_primitive = data[1] != SS_TAP_CODE;
	lcall	_ak820_outline_0094
	cjne	r7,#0x01,00441$
	setb	c
	sjmp	00442$
00441$:
	clr	c
00442$:
	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
	mov	dptr,#_ak820_macro_primitive
	cpl	c
	clr	a
	rlc	a
	movx	@dptr,a
;	quantum/dynamic_keymap.c:702: if (data[1] == SS_TAP_CODE) tap_code((uint8_t)data[2]);
	lcall	_ak820_outline_0094
	cjne	r7,#0x01,00122$
	lcall	_ak820_outline_0157
	push	ar6
	push	ar5
	lcall	_tap_code
	pop	ar5
	pop	ar6
	sjmp	00123$
00122$:
;	quantum/dynamic_keymap.c:703: else if (data[1] == SS_DOWN_CODE) register_code((uint8_t)data[2]);
	lcall	_ak820_outline_0094
	cjne	r7,#0x02,00119$
	lcall	_ak820_outline_0157
	push	ar6
	push	ar5
	lcall	_register_code
	pop	ar5
	pop	ar6
	sjmp	00123$
00119$:
;	quantum/dynamic_keymap.c:704: else unregister_code((uint8_t)data[2]);
	lcall	_ak820_outline_0157
	push	ar6
	push	ar5
	lcall	_unregister_code
	pop	ar5
	pop	ar6
00123$:
;	quantum/dynamic_keymap.c:706: ak820_macro_primitive = false;
	lcall	_ak820_outline_0170
	ajmp	00167$
00152$:
;	quantum/dynamic_keymap.c:714: } else if (data[1] == VIAL_MACRO_EXT_TAP || data[1] == VIAL_MACRO_EXT_DOWN || data[1] == VIAL_MACRO_EXT_UP) {
	lcall	_ak820_outline_0094
	cjne	r7,#0x05,00447$
	sjmp	00146$
00447$:
	lcall	_ak820_outline_0094
	cjne	r7,#0x06,00448$
	sjmp	00146$
00448$:
	lcall	_ak820_outline_0094
	cjne	r7,#0x07,00449$
	sjmp	00450$
00449$:
	ajmp	00147$
00450$:
00146$:
;	quantum/dynamic_keymap.c:715: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
	lcall	_ak820_outline_0000
	lcall	_eeprom_read_byte
	lcall	_ak820_outline_0183
;	quantum/dynamic_keymap.c:716: if (data[2] != 0) {
	jnz	00451$
	ajmp	00167$
00451$:
;	quantum/dynamic_keymap.c:717: data[3] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
	lcall	_ak820_outline_0000
	lcall	_eeprom_read_byte
	mov	r7, dpl
	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_472 + 0x0003)
	mov	a,r7
	movx	@dptr,a
;	quantum/dynamic_keymap.c:718: if (data[3] != 0) {
	mov	a,r7
	jnz	00452$
	ajmp	00167$
00452$:
;	quantum/dynamic_keymap.c:721: kc = (uint8_t)data[2] | ((uint16_t)(uint8_t)data[3] << 8);
	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_472 + 0x0002)
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_472 + 0x0003)
	movx	a,@dptr
	mov	r3,a
	clr	a
	mov	r4,a
	mov	r2,a
	mov	a,r7
	orl	ar4,a
	mov	a,r2
	orl	ar3,a
;	quantum/dynamic_keymap.c:725: kc = decode_keycode(kc);
	lcall	_ak820_outline_0186
	push	ar6
	push	ar5
	acall	_decode_keycode
	mov	r4, dpl
	mov	r7, dph
	pop	ar5
	pop	ar6
;	quantum/dynamic_keymap.c:727: ak820_macro_primitive = data[1] != VIAL_MACRO_EXT_TAP;
	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_472 + 0x0001)
	movx	a,@dptr
	mov	r3,a
	cjne	r3,#0x05,00453$
	setb	c
	sjmp	00454$
00453$:
	clr	c
00454$:
	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
	mov	dptr,#_ak820_macro_primitive
	cpl	c
	clr	a
	rlc	a
	movx	@dptr,a
;	quantum/dynamic_keymap.c:729: switch (data[1]) {
	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_472 + 0x0001)
	movx	a,@dptr
	mov	r3,a
	cjne	r3,#0x05,00455$
	sjmp	00126$
00455$:
	cjne	r3,#0x06,00456$
	sjmp	00127$
00456$:
;	quantum/dynamic_keymap.c:730: case VIAL_MACRO_EXT_TAP:
	cjne	r3,#0x07,00129$
	sjmp	00128$
00126$:
;	quantum/dynamic_keymap.c:731: vial_keycode_tap(kc);
	mov	dpl, r4
	mov	dph, r7
	push	ar6
	push	ar5
	lcall	_vial_keycode_tap
	pop	ar5
	pop	ar6
;	quantum/dynamic_keymap.c:732: break;
;	quantum/dynamic_keymap.c:733: case VIAL_MACRO_EXT_DOWN:
	sjmp	00129$
00127$:
;	quantum/dynamic_keymap.c:734: vial_keycode_down(kc);
	mov	dpl, r4
	mov	dph, r7
	push	ar6
	push	ar5
	lcall	_vial_keycode_down
	pop	ar5
	pop	ar6
;	quantum/dynamic_keymap.c:735: break;
;	quantum/dynamic_keymap.c:736: case VIAL_MACRO_EXT_UP:
	sjmp	00129$
00128$:
;	quantum/dynamic_keymap.c:737: vial_keycode_up(kc);
	mov	dpl, r4
	mov	dph, r7
	push	ar6
	push	ar5
	lcall	_vial_keycode_up
	pop	ar5
	pop	ar6
;	quantum/dynamic_keymap.c:739: }
00129$:
;	quantum/dynamic_keymap.c:741: ak820_macro_primitive = false;
	lcall	_ak820_outline_0170
	ajmp	00167$
00147$:
;	quantum/dynamic_keymap.c:745: } else if (data[1] == SS_DELAY_CODE) {
	lcall	_ak820_outline_0094
	cjne	r7,#0x04,00458$
	sjmp	00459$
00458$:
	ajmp	00167$
00459$:
;	quantum/dynamic_keymap.c:747: uint8_t d0 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
	lcall	_ak820_outline_0000
	lcall	_eeprom_read_byte
	mov	r7, dpl
;	quantum/dynamic_keymap.c:748: uint8_t d1 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
	mov	dptr,#_dynamic_keymap_macro_send_p_10001_465
	lcall	_ak820_outline_0124
	mov	dptr,#_dynamic_keymap_macro_send_p_10001_465
	mov	a,#0x01
	add	a, r3
	movx	@dptr,a
	clr	a
	addc	a, r4
	inc	dptr
	movx	@dptr,a
	mov	r2,#0x00
	lcall	_ak820_outline_0125
	mov	b, r2
	lcall	_eeprom_read_byte
	mov	r4, dpl
;	quantum/dynamic_keymap.c:749: if (d0 == 0 || d1 == 0)
	mov	a,r7
	jz	00169$
	mov	a,r4
	jz	00169$
;	quantum/dynamic_keymap.c:752: uint16_t ms = (uint16_t)(d0 - 1) + (uint16_t)(d1 - 1) * 255u;
	dec	r7
	dec	r4
	mov	a,r4
	mov	b,#0xff
	mul	ab
	mov	r4,a
	mov	r3,b
	mov	r2,#0x00
	mov	a,r4
	add	a, r7
	mov	r4,a
	mov	a,r3
	addc	a, r2
	mov	r3,a
;	quantum/dynamic_keymap.c:753: while (ms--) wait_ms(1);
00141$:
	mov	ar2,r4
	mov	ar7,r3
	dec	r4
	cjne	r4,#0xff,00462$
	dec	r3
00462$:
	mov	a,r2
	orl	a,r7
	jnz	00463$
	ajmp	00167$
00463$:
	mov	dptr,#0x0001
	lcall	_mDelaymS
	sjmp	00141$
00164$:
;	quantum/dynamic_keymap.c:759: if ((uint8_t)data[0] >= 128) break;
	mov	dptr,#_dynamic_keymap_macro_send_data_10003_472
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0x80,00464$
00464$:
	jnc	00169$
;	quantum/dynamic_keymap.c:763: send_char(data[0]);
	mov	dptr,#_dynamic_keymap_macro_send_data_10003_472
	movx	a,@dptr
	mov	dpl,a
	push	ar6
	push	ar5
	lcall	_send_char
	pop	ar5
	pop	ar6
;	quantum/dynamic_keymap.c:764: for (uint8_t delay = DYNAMIC_KEYMAP_MACRO_DELAY; delay; --delay) wait_ms(1);
	ajmp	00167$
00169$:
;	quantum/dynamic_keymap.c:772: ak820_macro_primitive = false;
	lcall	_ak820_outline_0170
;	quantum/dynamic_keymap.c:774: sending = false;
	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_460
	movx	@dptr,a
;	quantum/dynamic_keymap.c:776: }
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
	.area CABS    (ABS,CODE)

; Experimental exact instruction outlining.
	.globl _ak820_outline_0000
	.globl _ak820_outline_0005
	.globl _ak820_outline_0008
	.globl _ak820_outline_0013
	.globl _ak820_outline_0021
	.globl _ak820_outline_0033
	.globl _ak820_outline_0034
	.globl _ak820_outline_0050
	.globl _ak820_outline_0052
	.globl _ak820_outline_0057
	.globl _ak820_outline_0059
	.globl _ak820_outline_0060
	.globl _ak820_outline_0061
	.globl _ak820_outline_0072
	.globl _ak820_outline_0078
	.globl _ak820_outline_0080
	.globl _ak820_outline_0084
	.globl _ak820_outline_0091
	.globl _ak820_outline_0093
	.globl _ak820_outline_0094
	.globl _ak820_outline_0100
	.globl _ak820_outline_0101
	.globl _ak820_outline_0104
	.globl _ak820_outline_0105
	.globl _ak820_outline_0109
	.globl _ak820_outline_0110
	.globl _ak820_outline_0113
	.globl _ak820_outline_0118
	.globl _ak820_outline_0120
	.globl _ak820_outline_0124
	.globl _ak820_outline_0125
	.globl _ak820_outline_0126
	.globl _ak820_outline_0130
	.globl _ak820_outline_0135
	.globl _ak820_outline_0136
	.globl _ak820_outline_0137
	.globl _ak820_outline_0138
	.globl _ak820_outline_0139
	.globl _ak820_outline_0146
	.globl _ak820_outline_0147
	.globl _ak820_outline_0154
	.globl _ak820_outline_0157
	.globl _ak820_outline_0161
	.globl _ak820_outline_0163
	.globl _ak820_outline_0165
	.globl _ak820_outline_0170
	.globl _ak820_outline_0179
	.globl _ak820_outline_0180
	.globl _ak820_outline_0183
	.globl _ak820_outline_0184
	.globl _ak820_outline_0185
	.globl _ak820_outline_0186
	.globl _ak820_outline_0189
	.globl _ak820_outline_0191

	.area CSEG (CODE)
; function ak820_outline_0000
_ak820_outline_0000:
	mov	dptr,#_dynamic_keymap_macro_send_p_10001_465
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_dynamic_keymap_macro_send_p_10001_465
	mov	a,#0x01
	add	a,r4
	movx	@dptr,a
	clr	a
	addc	a,r7
	inc	dptr
	movx	@dptr,a
	mov	r3,#0x00
	mov	dpl,r4
	mov	dph,r7
	mov	b,r3
	ret

	.area CSEG (CODE)
; function ak820_outline_0080
_ak820_outline_0080:
	mov	a,r5
	mov	b,#0x0a
	mul	ab
	add	a,#0x58
	mov	r4,a
	mov	a,#0x06
	addc	a,b
	mov	r5,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0094
_ak820_outline_0094:
	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_472+0x0001)
	movx	a,@dptr
	mov	r7,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0100
_ak820_outline_0100:
	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
	mov	a,r6
	movx	@dptr,a
	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
	mov	a,r5
	movx	@dptr,a
	mov	dpl,r7
	ret

	.area CSEG (CODE)
; function ak820_outline_0113
_ak820_outline_0113:
	mov	a,#0x0a
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0118
_ak820_outline_0118:
	mov	r5,dpl
	mov	r6,dph
	mov	r7,b
	ret

	.area CSEG (CODE)
; function ak820_outline_0130
_ak820_outline_0130:
	add	a,r0
	mov	dpl,a
	mov	a,r7
	addc	a,r1
	mov	dph,a
	mov	a,#0xff
	movx	@dptr,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0138
_ak820_outline_0138:
	add	a,r5
	mov	r1,a
	clr	a
	addc	a,r6
	mov	r2,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0157
_ak820_outline_0157:
	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_472+0x0002)
	movx	a,@dptr
	mov	dpl,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0170
_ak820_outline_0170:
	mov	dptr,#_ak820_macro_primitive
	clr	a
	movx	@dptr,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0179
_ak820_outline_0179:
	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
	clr	a
	movx	@dptr,a
	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
	ret

	.area CSEG (CODE)
; function ak820_outline_0180
_ak820_outline_0180:
	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_2
	clr	a
	movx	@dptr,a
	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_3
	ret

	.area CSEG (CODE)
; function ak820_outline_0183
_ak820_outline_0183:
	mov	r7,dpl
	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_472+0x0002)
	mov	a,r7
	movx	@dptr,a
	mov	a,r7
	ret
