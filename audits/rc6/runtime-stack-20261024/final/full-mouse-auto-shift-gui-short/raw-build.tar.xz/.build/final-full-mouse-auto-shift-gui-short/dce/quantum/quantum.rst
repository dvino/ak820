                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module quantum
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _shutdown_quantum
                                     12 	.globl _extract_mod_bits
                                     13 	.globl _process_tri_layer
                                     14 	.globl _process_rgb
                                     15 	.globl _process_grave_esc
                                     16 	.globl _ak820_combo_process
                                     17 	.globl _process_repeat_key
                                     18 	.globl _process_last_key
                                     19 	.globl _process_caps_word
                                     20 	.globl _process_record_via
                                     21 	.globl _ak820_gui_process
                                     22 	.globl _mcu_reset
                                     23 	.globl _bootloader_jump
                                     24 	.globl _ak820_resolve_key
                                     25 	.globl _default_layer_set
                                     26 	.globl _clear_keyboard
                                     27 	.globl _unregister_weak_mods
                                     28 	.globl _register_weak_mods
                                     29 	.globl _unregister_mods
                                     30 	.globl _register_mods
                                     31 	.globl _unregister_code
                                     32 	.globl _register_code
                                     33 	.globl _eeconfig_disable
                                     34 	.globl _rgb_matrix_set_suspend_state
                                     35 	.globl _rgb_matrix_task
                                     36 	.globl _mDelaymS
                                     37 	.globl _ADC_START
                                     38 	.globl _S0_R_FIFO
                                     39 	.globl _S0_T_FIFO
                                     40 	.globl _S0_FREE
                                     41 	.globl _S0_IF_BYTE
                                     42 	.globl _S0_IF_FIRST
                                     43 	.globl _S0_IF_OV
                                     44 	.globl _S0_FST_ACT
                                     45 	.globl _CP_RL2
                                     46 	.globl _C_T2
                                     47 	.globl _TR2
                                     48 	.globl _EXEN2
                                     49 	.globl _TCLK
                                     50 	.globl _RCLK
                                     51 	.globl _EXF2
                                     52 	.globl _CAP1F
                                     53 	.globl _TF2
                                     54 	.globl _RI
                                     55 	.globl _TI
                                     56 	.globl _RB8
                                     57 	.globl _TB8
                                     58 	.globl _REN
                                     59 	.globl _SM2
                                     60 	.globl _SM1
                                     61 	.globl _SM0
                                     62 	.globl _IT0
                                     63 	.globl _IE0
                                     64 	.globl _IT1
                                     65 	.globl _IE1
                                     66 	.globl _TR0
                                     67 	.globl _TF0
                                     68 	.globl _TR1
                                     69 	.globl _TF1
                                     70 	.globl _P4_0
                                     71 	.globl _P4_1
                                     72 	.globl _P4_2
                                     73 	.globl _P4_3
                                     74 	.globl _P4_4
                                     75 	.globl _P4_5
                                     76 	.globl _P4_6
                                     77 	.globl _RXD
                                     78 	.globl _TXD
                                     79 	.globl _INT0
                                     80 	.globl _INT1
                                     81 	.globl _T0
                                     82 	.globl _T1
                                     83 	.globl _MOSI1
                                     84 	.globl _MISO1
                                     85 	.globl _SCK1
                                     86 	.globl _P3_0
                                     87 	.globl _P3_1
                                     88 	.globl _P3_2
                                     89 	.globl _P3_3
                                     90 	.globl _P3_4
                                     91 	.globl _P3_5
                                     92 	.globl _P3_6
                                     93 	.globl _P3_7
                                     94 	.globl _CAP1_
                                     95 	.globl _T2_
                                     96 	.globl _CAP2_
                                     97 	.globl _T2EX_
                                     98 	.globl _RXD1
                                     99 	.globl _TXD1
                                    100 	.globl _P2_0
                                    101 	.globl _P2_1
                                    102 	.globl _P2_2
                                    103 	.globl _P2_3
                                    104 	.globl _P2_4
                                    105 	.globl _P2_5
                                    106 	.globl _P2_6
                                    107 	.globl _P2_7
                                    108 	.globl _AIN0
                                    109 	.globl _AIN1
                                    110 	.globl _AIN2
                                    111 	.globl _AIN3
                                    112 	.globl _AIN4
                                    113 	.globl _AIN5
                                    114 	.globl _AIN6
                                    115 	.globl _AIN7
                                    116 	.globl _CAP1
                                    117 	.globl _T2
                                    118 	.globl _CAP2
                                    119 	.globl _T2EX
                                    120 	.globl _INT0_
                                    121 	.globl _SCS
                                    122 	.globl _MOSI
                                    123 	.globl _MISO
                                    124 	.globl _SCK
                                    125 	.globl _RXD1_
                                    126 	.globl _TXD1_
                                    127 	.globl _P1_0
                                    128 	.globl _P1_1
                                    129 	.globl _P1_2
                                    130 	.globl _P1_3
                                    131 	.globl _P1_4
                                    132 	.globl _P1_5
                                    133 	.globl _P1_6
                                    134 	.globl _P1_7
                                    135 	.globl _AIN8
                                    136 	.globl _AIN9
                                    137 	.globl _AIN10
                                    138 	.globl _AIN11
                                    139 	.globl _AIN12
                                    140 	.globl _AIN13
                                    141 	.globl _RXD_
                                    142 	.globl _TXD_
                                    143 	.globl _SCL0
                                    144 	.globl _SDA0
                                    145 	.globl _P0_0
                                    146 	.globl _P0_1
                                    147 	.globl _P0_2
                                    148 	.globl _P0_3
                                    149 	.globl _P0_4
                                    150 	.globl _P0_5
                                    151 	.globl _P0_6
                                    152 	.globl _P0_7
                                    153 	.globl _IE_SPI0
                                    154 	.globl _IE_USB
                                    155 	.globl _IE_ADC
                                    156 	.globl _IE_UART1
                                    157 	.globl _IE_PWM_I2C
                                    158 	.globl _IE_GPIO
                                    159 	.globl _IE_WDOG
                                    160 	.globl _PX0
                                    161 	.globl _PT0
                                    162 	.globl _PX1
                                    163 	.globl _PT1
                                    164 	.globl _PS
                                    165 	.globl _PT2
                                    166 	.globl _PL_FLAG
                                    167 	.globl _PH_FLAG
                                    168 	.globl _EX0
                                    169 	.globl _ET0
                                    170 	.globl _EX1
                                    171 	.globl _ET1
                                    172 	.globl _ES
                                    173 	.globl _ET2
                                    174 	.globl _E_DIS
                                    175 	.globl _EA
                                    176 	.globl _P
                                    177 	.globl _F1
                                    178 	.globl _OV
                                    179 	.globl _RS0
                                    180 	.globl _RS1
                                    181 	.globl _F0
                                    182 	.globl _AC
                                    183 	.globl _CY
                                    184 	.globl _I2CS_INT_ST
                                    185 	.globl _I2CX_INT
                                    186 	.globl _LED_STATUS
                                    187 	.globl _LED_DMA_H
                                    188 	.globl _LED_DMA_L
                                    189 	.globl _LED_DMA
                                    190 	.globl _LED_PWM_OE
                                    191 	.globl _LED_COMMON
                                    192 	.globl _ADC_CHAN
                                    193 	.globl _ADC_DAT_H
                                    194 	.globl _ADC_DAT_L
                                    195 	.globl _ADC_DAT
                                    196 	.globl _ADC_CTRL
                                    197 	.globl _SPI1_CK_SE
                                    198 	.globl _SPI1_CTRL
                                    199 	.globl _SPI1_DATA
                                    200 	.globl _SPI1_STAT
                                    201 	.globl _SIF1
                                    202 	.globl _SBAUD1
                                    203 	.globl _SBUF1
                                    204 	.globl _SCON1
                                    205 	.globl _SPI0_SETUP
                                    206 	.globl _SPI0_CK_SE
                                    207 	.globl _SPI0_CTRL
                                    208 	.globl _SPI0_DATA
                                    209 	.globl _SPI0_STAT
                                    210 	.globl _T2CAP1H
                                    211 	.globl _T2CAP1L
                                    212 	.globl _T2CAP1
                                    213 	.globl _TH2
                                    214 	.globl _TL2
                                    215 	.globl _T2COUNT
                                    216 	.globl _RCAP2H
                                    217 	.globl _RCAP2L
                                    218 	.globl _RCAP2
                                    219 	.globl _T2MOD
                                    220 	.globl _T2CON
                                    221 	.globl _SBUF
                                    222 	.globl _SCON
                                    223 	.globl _TH1
                                    224 	.globl _TH0
                                    225 	.globl _TL1
                                    226 	.globl _TL0
                                    227 	.globl _TMOD
                                    228 	.globl _TCON
                                    229 	.globl _XBUS_AUX
                                    230 	.globl _P7
                                    231 	.globl _P6_DIR
                                    232 	.globl _P6_OUT_PU
                                    233 	.globl _P6_IN
                                    234 	.globl _P5_DIR
                                    235 	.globl _P5_OUT_PU
                                    236 	.globl _P5_IN
                                    237 	.globl _P4_LED_KEY
                                    238 	.globl _P4_DIR_PU
                                    239 	.globl _P4_MOD_OC
                                    240 	.globl _P4
                                    241 	.globl _P3_DIR_PU
                                    242 	.globl _P3_MOD_OC
                                    243 	.globl _P3
                                    244 	.globl _P2_DIR_PU
                                    245 	.globl _P2_MOD_OC
                                    246 	.globl _P2
                                    247 	.globl _P1_DIR_PU
                                    248 	.globl _P1_MOD_OC
                                    249 	.globl _P1
                                    250 	.globl _P0_DIR_PU
                                    251 	.globl _P0_MOD_OC
                                    252 	.globl _P0
                                    253 	.globl _ROM_CTRL
                                    254 	.globl _ROM_DATA_HH
                                    255 	.globl _ROM_DATA_HL
                                    256 	.globl _ROM_DATA_HI
                                    257 	.globl _ROM_ADDR_H
                                    258 	.globl _ROM_ADDR_L
                                    259 	.globl _ROM_ADDR
                                    260 	.globl _GPIO_IE
                                    261 	.globl _IP_EX
                                    262 	.globl _IE_EX
                                    263 	.globl _IP
                                    264 	.globl _IE
                                    265 	.globl _WDOG_COUNT
                                    266 	.globl _RESET_KEEP
                                    267 	.globl _WAKE_CTRL
                                    268 	.globl _CLOCK_CFG
                                    269 	.globl _POWER_CFG
                                    270 	.globl _PCON
                                    271 	.globl _GLOBAL_CFG
                                    272 	.globl _SAFE_MOD
                                    273 	.globl _DPH
                                    274 	.globl _DPL
                                    275 	.globl _SP
                                    276 	.globl _A_INV
                                    277 	.globl _B
                                    278 	.globl _ACC
                                    279 	.globl _PSW
                                    280 	.globl _process_record_quantum_helper_PARM_2
                                    281 	.globl _get_record_keycode_PARM_2
                                    282 	.globl _post_process_record_user_PARM_2
                                    283 	.globl _post_process_record_kb_PARM_2
                                    284 	.globl _process_record_user_PARM_2
                                    285 	.globl _process_record_kb_PARM_2
                                    286 	.globl _pre_process_record_user_PARM_2
                                    287 	.globl _pre_process_record_kb_PARM_2
                                    288 	.globl _register_code16
                                    289 	.globl _unregister_code16
                                    290 	.globl _pre_process_record_kb
                                    291 	.globl _pre_process_record_user
                                    292 	.globl _process_action_kb
                                    293 	.globl _process_record_kb
                                    294 	.globl _process_record_user
                                    295 	.globl _post_process_record_kb
                                    296 	.globl _post_process_record_user
                                    297 	.globl _reset_keyboard
                                    298 	.globl _soft_reset_keyboard
                                    299 	.globl _get_record_keycode
                                    300 	.globl _pre_process_record_quantum
                                    301 	.globl _post_process_record_quantum
                                    302 	.globl _process_record_quantum
                                    303 	.globl _process_record_quantum_helper
                                    304 	.globl _shutdown_user
                                    305 ;--------------------------------------------------------
                                    306 ; special function registers
                                    307 ;--------------------------------------------------------
                                    308 	.area RSEG    (ABS,DATA)
      000000                        309 	.org 0x0000
                           0000D0   310 _PSW	=	0x00d0
                           0000E0   311 _ACC	=	0x00e0
                           0000F0   312 _B	=	0x00f0
                           0000FD   313 _A_INV	=	0x00fd
                           000081   314 _SP	=	0x0081
                           000082   315 _DPL	=	0x0082
                           000083   316 _DPH	=	0x0083
                           0000A1   317 _SAFE_MOD	=	0x00a1
                           0000B1   318 _GLOBAL_CFG	=	0x00b1
                           000087   319 _PCON	=	0x0087
                           0000BA   320 _POWER_CFG	=	0x00ba
                           0000B9   321 _CLOCK_CFG	=	0x00b9
                           0000A9   322 _WAKE_CTRL	=	0x00a9
                           0000FE   323 _RESET_KEEP	=	0x00fe
                           0000FF   324 _WDOG_COUNT	=	0x00ff
                           0000A8   325 _IE	=	0x00a8
                           0000B8   326 _IP	=	0x00b8
                           0000E8   327 _IE_EX	=	0x00e8
                           0000E9   328 _IP_EX	=	0x00e9
                           0000B2   329 _GPIO_IE	=	0x00b2
                           008584   330 _ROM_ADDR	=	0x8584
                           000084   331 _ROM_ADDR_L	=	0x0084
                           000085   332 _ROM_ADDR_H	=	0x0085
                           008F8E   333 _ROM_DATA_HI	=	0x8f8e
                           00008E   334 _ROM_DATA_HL	=	0x008e
                           00008F   335 _ROM_DATA_HH	=	0x008f
                           000086   336 _ROM_CTRL	=	0x0086
                           000080   337 _P0	=	0x0080
                           0000C4   338 _P0_MOD_OC	=	0x00c4
                           0000C5   339 _P0_DIR_PU	=	0x00c5
                           000090   340 _P1	=	0x0090
                           000092   341 _P1_MOD_OC	=	0x0092
                           000093   342 _P1_DIR_PU	=	0x0093
                           0000A0   343 _P2	=	0x00a0
                           000094   344 _P2_MOD_OC	=	0x0094
                           000095   345 _P2_DIR_PU	=	0x0095
                           0000B0   346 _P3	=	0x00b0
                           000096   347 _P3_MOD_OC	=	0x0096
                           000097   348 _P3_DIR_PU	=	0x0097
                           0000C0   349 _P4	=	0x00c0
                           0000C2   350 _P4_MOD_OC	=	0x00c2
                           0000C3   351 _P4_DIR_PU	=	0x00c3
                           0000C1   352 _P4_LED_KEY	=	0x00c1
                           0000AA   353 _P5_IN	=	0x00aa
                           0000AB   354 _P5_OUT_PU	=	0x00ab
                           0000AC   355 _P5_DIR	=	0x00ac
                           0000AD   356 _P6_IN	=	0x00ad
                           0000AE   357 _P6_OUT_PU	=	0x00ae
                           0000AF   358 _P6_DIR	=	0x00af
                           0000F1   359 _P7	=	0x00f1
                           0000A2   360 _XBUS_AUX	=	0x00a2
                           000088   361 _TCON	=	0x0088
                           000089   362 _TMOD	=	0x0089
                           00008A   363 _TL0	=	0x008a
                           00008B   364 _TL1	=	0x008b
                           00008C   365 _TH0	=	0x008c
                           00008D   366 _TH1	=	0x008d
                           000098   367 _SCON	=	0x0098
                           000099   368 _SBUF	=	0x0099
                           0000C8   369 _T2CON	=	0x00c8
                           0000C9   370 _T2MOD	=	0x00c9
                           00CBCA   371 _RCAP2	=	0xcbca
                           0000CA   372 _RCAP2L	=	0x00ca
                           0000CB   373 _RCAP2H	=	0x00cb
                           00CDCC   374 _T2COUNT	=	0xcdcc
                           0000CC   375 _TL2	=	0x00cc
                           0000CD   376 _TH2	=	0x00cd
                           00CFCE   377 _T2CAP1	=	0xcfce
                           0000CE   378 _T2CAP1L	=	0x00ce
                           0000CF   379 _T2CAP1H	=	0x00cf
                           0000F8   380 _SPI0_STAT	=	0x00f8
                           0000F9   381 _SPI0_DATA	=	0x00f9
                           0000FA   382 _SPI0_CTRL	=	0x00fa
                           0000FB   383 _SPI0_CK_SE	=	0x00fb
                           0000FC   384 _SPI0_SETUP	=	0x00fc
                           0000BC   385 _SCON1	=	0x00bc
                           0000BD   386 _SBUF1	=	0x00bd
                           0000BE   387 _SBAUD1	=	0x00be
                           0000BF   388 _SIF1	=	0x00bf
                           0000B4   389 _SPI1_STAT	=	0x00b4
                           0000B5   390 _SPI1_DATA	=	0x00b5
                           0000B6   391 _SPI1_CTRL	=	0x00b6
                           0000B7   392 _SPI1_CK_SE	=	0x00b7
                           0000F3   393 _ADC_CTRL	=	0x00f3
                           00F5F4   394 _ADC_DAT	=	0xf5f4
                           0000F4   395 _ADC_DAT_L	=	0x00f4
                           0000F5   396 _ADC_DAT_H	=	0x00f5
                           0000F6   397 _ADC_CHAN	=	0x00f6
                           0000A6   398 _LED_COMMON	=	0x00a6
                           0000A7   399 _LED_PWM_OE	=	0x00a7
                           00C7C6   400 _LED_DMA	=	0xc7c6
                           0000C6   401 _LED_DMA_L	=	0x00c6
                           0000C7   402 _LED_DMA_H	=	0x00c7
                           0000F7   403 _LED_STATUS	=	0x00f7
                           0000B3   404 _I2CX_INT	=	0x00b3
                           0000BB   405 _I2CS_INT_ST	=	0x00bb
                                    406 ;--------------------------------------------------------
                                    407 ; special function bits
                                    408 ;--------------------------------------------------------
                                    409 	.area RSEG    (ABS,DATA)
      000000                        410 	.org 0x0000
                           0000D7   411 _CY	=	0x00d7
                           0000D6   412 _AC	=	0x00d6
                           0000D5   413 _F0	=	0x00d5
                           0000D4   414 _RS1	=	0x00d4
                           0000D3   415 _RS0	=	0x00d3
                           0000D2   416 _OV	=	0x00d2
                           0000D1   417 _F1	=	0x00d1
                           0000D0   418 _P	=	0x00d0
                           0000AF   419 _EA	=	0x00af
                           0000AE   420 _E_DIS	=	0x00ae
                           0000AD   421 _ET2	=	0x00ad
                           0000AC   422 _ES	=	0x00ac
                           0000AB   423 _ET1	=	0x00ab
                           0000AA   424 _EX1	=	0x00aa
                           0000A9   425 _ET0	=	0x00a9
                           0000A8   426 _EX0	=	0x00a8
                           0000BF   427 _PH_FLAG	=	0x00bf
                           0000BE   428 _PL_FLAG	=	0x00be
                           0000BD   429 _PT2	=	0x00bd
                           0000BC   430 _PS	=	0x00bc
                           0000BB   431 _PT1	=	0x00bb
                           0000BA   432 _PX1	=	0x00ba
                           0000B9   433 _PT0	=	0x00b9
                           0000B8   434 _PX0	=	0x00b8
                           0000EF   435 _IE_WDOG	=	0x00ef
                           0000EE   436 _IE_GPIO	=	0x00ee
                           0000ED   437 _IE_PWM_I2C	=	0x00ed
                           0000EC   438 _IE_UART1	=	0x00ec
                           0000EB   439 _IE_ADC	=	0x00eb
                           0000E9   440 _IE_USB	=	0x00e9
                           0000E8   441 _IE_SPI0	=	0x00e8
                           000087   442 _P0_7	=	0x0087
                           000086   443 _P0_6	=	0x0086
                           000085   444 _P0_5	=	0x0085
                           000084   445 _P0_4	=	0x0084
                           000083   446 _P0_3	=	0x0083
                           000082   447 _P0_2	=	0x0082
                           000081   448 _P0_1	=	0x0081
                           000080   449 _P0_0	=	0x0080
                           000081   450 _SDA0	=	0x0081
                           000080   451 _SCL0	=	0x0080
                           000083   452 _TXD_	=	0x0083
                           000082   453 _RXD_	=	0x0082
                           000085   454 _AIN13	=	0x0085
                           000084   455 _AIN12	=	0x0084
                           000083   456 _AIN11	=	0x0083
                           000082   457 _AIN10	=	0x0082
                           000081   458 _AIN9	=	0x0081
                           000080   459 _AIN8	=	0x0080
                           000097   460 _P1_7	=	0x0097
                           000096   461 _P1_6	=	0x0096
                           000095   462 _P1_5	=	0x0095
                           000094   463 _P1_4	=	0x0094
                           000093   464 _P1_3	=	0x0093
                           000092   465 _P1_2	=	0x0092
                           000091   466 _P1_1	=	0x0091
                           000090   467 _P1_0	=	0x0090
                           000097   468 _TXD1_	=	0x0097
                           000096   469 _RXD1_	=	0x0096
                           000097   470 _SCK	=	0x0097
                           000096   471 _MISO	=	0x0096
                           000095   472 _MOSI	=	0x0095
                           000094   473 _SCS	=	0x0094
                           000092   474 _INT0_	=	0x0092
                           000091   475 _T2EX	=	0x0091
                           000091   476 _CAP2	=	0x0091
                           000090   477 _T2	=	0x0090
                           000090   478 _CAP1	=	0x0090
                           000097   479 _AIN7	=	0x0097
                           000096   480 _AIN6	=	0x0096
                           000095   481 _AIN5	=	0x0095
                           000094   482 _AIN4	=	0x0094
                           000093   483 _AIN3	=	0x0093
                           000092   484 _AIN2	=	0x0092
                           000091   485 _AIN1	=	0x0091
                           000090   486 _AIN0	=	0x0090
                           0000A7   487 _P2_7	=	0x00a7
                           0000A6   488 _P2_6	=	0x00a6
                           0000A5   489 _P2_5	=	0x00a5
                           0000A4   490 _P2_4	=	0x00a4
                           0000A3   491 _P2_3	=	0x00a3
                           0000A2   492 _P2_2	=	0x00a2
                           0000A1   493 _P2_1	=	0x00a1
                           0000A0   494 _P2_0	=	0x00a0
                           0000A7   495 _TXD1	=	0x00a7
                           0000A6   496 _RXD1	=	0x00a6
                           0000A5   497 _T2EX_	=	0x00a5
                           0000A5   498 _CAP2_	=	0x00a5
                           0000A4   499 _T2_	=	0x00a4
                           0000A4   500 _CAP1_	=	0x00a4
                           0000B7   501 _P3_7	=	0x00b7
                           0000B6   502 _P3_6	=	0x00b6
                           0000B5   503 _P3_5	=	0x00b5
                           0000B4   504 _P3_4	=	0x00b4
                           0000B3   505 _P3_3	=	0x00b3
                           0000B2   506 _P3_2	=	0x00b2
                           0000B1   507 _P3_1	=	0x00b1
                           0000B0   508 _P3_0	=	0x00b0
                           0000B7   509 _SCK1	=	0x00b7
                           0000B6   510 _MISO1	=	0x00b6
                           0000B5   511 _MOSI1	=	0x00b5
                           0000B5   512 _T1	=	0x00b5
                           0000B4   513 _T0	=	0x00b4
                           0000B3   514 _INT1	=	0x00b3
                           0000B2   515 _INT0	=	0x00b2
                           0000B1   516 _TXD	=	0x00b1
                           0000B0   517 _RXD	=	0x00b0
                           0000C6   518 _P4_6	=	0x00c6
                           0000C5   519 _P4_5	=	0x00c5
                           0000C4   520 _P4_4	=	0x00c4
                           0000C3   521 _P4_3	=	0x00c3
                           0000C2   522 _P4_2	=	0x00c2
                           0000C1   523 _P4_1	=	0x00c1
                           0000C0   524 _P4_0	=	0x00c0
                           00008F   525 _TF1	=	0x008f
                           00008E   526 _TR1	=	0x008e
                           00008D   527 _TF0	=	0x008d
                           00008C   528 _TR0	=	0x008c
                           00008B   529 _IE1	=	0x008b
                           00008A   530 _IT1	=	0x008a
                           000089   531 _IE0	=	0x0089
                           000088   532 _IT0	=	0x0088
                           00009F   533 _SM0	=	0x009f
                           00009E   534 _SM1	=	0x009e
                           00009D   535 _SM2	=	0x009d
                           00009C   536 _REN	=	0x009c
                           00009B   537 _TB8	=	0x009b
                           00009A   538 _RB8	=	0x009a
                           000099   539 _TI	=	0x0099
                           000098   540 _RI	=	0x0098
                           0000CF   541 _TF2	=	0x00cf
                           0000CF   542 _CAP1F	=	0x00cf
                           0000CE   543 _EXF2	=	0x00ce
                           0000CD   544 _RCLK	=	0x00cd
                           0000CC   545 _TCLK	=	0x00cc
                           0000CB   546 _EXEN2	=	0x00cb
                           0000CA   547 _TR2	=	0x00ca
                           0000C9   548 _C_T2	=	0x00c9
                           0000C8   549 _CP_RL2	=	0x00c8
                           0000FF   550 _S0_FST_ACT	=	0x00ff
                           0000FE   551 _S0_IF_OV	=	0x00fe
                           0000FD   552 _S0_IF_FIRST	=	0x00fd
                           0000FC   553 _S0_IF_BYTE	=	0x00fc
                           0000FB   554 _S0_FREE	=	0x00fb
                           0000FA   555 _S0_T_FIFO	=	0x00fa
                           0000F8   556 _S0_R_FIFO	=	0x00f8
                           0000F7   557 _ADC_START	=	0x00f7
                                    558 ;--------------------------------------------------------
                                    559 ; overlayable register banks
                                    560 ;--------------------------------------------------------
                                    561 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        562 	.ds 8
                                    563 ;--------------------------------------------------------
                                    564 ; internal ram data
                                    565 ;--------------------------------------------------------
                                    566 	.area DSEG    (DATA)
                                    567 ;--------------------------------------------------------
                                    568 ; overlayable items in internal ram
                                    569 ;--------------------------------------------------------
                                    570 ;--------------------------------------------------------
                                    571 ; indirectly addressable internal ram data
                                    572 ;--------------------------------------------------------
                                    573 	.area ISEG    (DATA)
                                    574 ;--------------------------------------------------------
                                    575 ; absolute internal ram data
                                    576 ;--------------------------------------------------------
                                    577 	.area IABS    (ABS,DATA)
                                    578 	.area IABS    (ABS,DATA)
                                    579 ;--------------------------------------------------------
                                    580 ; bit data
                                    581 ;--------------------------------------------------------
                                    582 	.area BSEG    (BIT)
      000028                        583 _get_record_keycode_sloc0_1_0:
      000028                        584 	.ds 1
      000029                        585 _pre_process_record_quantum_sloc0_1_0:
      000029                        586 	.ds 1
      00002A                        587 _process_ak820_nkro_sloc0_1_0:
      00002A                        588 	.ds 1
                                    589 ;--------------------------------------------------------
                                    590 ; paged external ram data
                                    591 ;--------------------------------------------------------
                                    592 	.area PSEG    (PAG,XDATA)
                                    593 ;--------------------------------------------------------
                                    594 ; uninitialized external ram data
                                    595 ;--------------------------------------------------------
                                    596 	.area XSEG    (XDATA)
      000C0E                        597 _extract_mod_bits_code_10000_601:
      000C0E                        598 	.ds 2
      000C10                        599 _register_code16_code_10000_607:
      000C10                        600 	.ds 2
      000C12                        601 _unregister_code16_code_10000_612:
      000C12                        602 	.ds 2
      000C14                        603 _pre_process_record_kb_PARM_2:
      000C14                        604 	.ds 3
      000C17                        605 _pre_process_record_kb_keycode_10000_626:
      000C17                        606 	.ds 2
      000C19                        607 _pre_process_record_user_PARM_2:
      000C19                        608 	.ds 3
      000C1C                        609 _process_record_kb_PARM_2:
      000C1C                        610 	.ds 3
      000C1F                        611 _process_record_kb_keycode_10000_632:
      000C1F                        612 	.ds 2
      000C21                        613 _process_record_user_PARM_2:
      000C21                        614 	.ds 3
      000C24                        615 _post_process_record_kb_PARM_2:
      000C24                        616 	.ds 3
      000C27                        617 _post_process_record_kb_keycode_10000_636:
      000C27                        618 	.ds 2
      000C29                        619 _post_process_record_user_PARM_2:
      000C29                        620 	.ds 3
      000C2C                        621 _get_record_keycode_PARM_2:
      000C2C                        622 	.ds 1
      000C2D                        623 _get_record_keycode_record_argument_10000_650:
      000C2D                        624 	.ds 3
      000C30                        625 _pre_process_record_quantum_record_argument_10000_656:
      000C30                        626 	.ds 3
      000C33                        627 _post_process_record_quantum_record_10000_658:
      000C33                        628 	.ds 3
      000C36                        629 _process_record_quantum_record_10000_660:
      000C36                        630 	.ds 3
      000C39                        631 _process_ak820_nkro_PARM_2:
      000C39                        632 	.ds 3
      000C3C                        633 _process_ak820_nkro_keycode_10000_662:
      000C3C                        634 	.ds 2
      000C3E                        635 _process_record_quantum_helper_PARM_2:
      000C3E                        636 	.ds 3
      000C41                        637 _process_record_quantum_helper_keycode_10000_667:
      000C41                        638 	.ds 2
      000C43                        639 _get_u8_str_last_num_10000_693:
      000C43                        640 	.ds 1
      000C44                        641 _get_u16_str_last_num_10000_697:
      000C44                        642 	.ds 2
                                    643 ;--------------------------------------------------------
                                    644 ; absolute external ram data
                                    645 ;--------------------------------------------------------
                                    646 	.area XABS    (ABS,XDATA)
                                    647 ;--------------------------------------------------------
                                    648 ; initialized external ram data
                                    649 ;--------------------------------------------------------
                                    650 	.area XISEG   (XDATA)
                                    651 	.area HOME    (CODE)
                                    652 	.area GSINIT0 (CODE)
                                    653 	.area GSINIT1 (CODE)
                                    654 	.area GSINIT2 (CODE)
                                    655 	.area GSINIT3 (CODE)
                                    656 	.area GSINIT4 (CODE)
                                    657 	.area GSINIT5 (CODE)
                                    658 	.area GSINIT  (CODE)
                                    659 	.area GSFINAL (CODE)
                                    660 	.area CSEG    (CODE)
                                    661 ;--------------------------------------------------------
                                    662 ; global & static initialisations
                                    663 ;--------------------------------------------------------
                                    664 	.area HOME    (CODE)
                                    665 	.area GSINIT  (CODE)
                                    666 	.area GSFINAL (CODE)
                                    667 	.area GSINIT  (CODE)
                                    668 ;------------------------------------------------------------
                                    669 ;Allocation info for local variables in function 'get_u8_str'
                                    670 ;------------------------------------------------------------
                                    671 ;curr_pad      Allocated with name '_get_u8_str_PARM_2'
                                    672 ;curr_num      Allocated with name '_get_u8_str_curr_num_10000_692'
                                    673 ;buf           Allocated with name '_get_u8_str_buf_10000_693'
                                    674 ;last_num      Allocated with name '_get_u8_str_last_num_10000_693'
                                    675 ;last_pad      Allocated with name '_get_u8_str_last_pad_10000_693'
                                    676 ;------------------------------------------------------------
                                    677 ;	quantum/quantum.c:739: static uint8_t last_num = 0xFF;
      0030F3 90 0C 43         [24]  678 	mov	dptr,#_get_u8_str_last_num_10000_693
      0030F6 74 FF            [12]  679 	mov	a,#0xff
      0030F8 F0               [24]  680 	movx	@dptr,a
                                    681 ;------------------------------------------------------------
                                    682 ;Allocation info for local variables in function 'get_u16_str'
                                    683 ;------------------------------------------------------------
                                    684 ;curr_pad      Allocated with name '_get_u16_str_PARM_2'
                                    685 ;curr_num      Allocated with name '_get_u16_str_curr_num_10000_696'
                                    686 ;buf           Allocated with name '_get_u16_str_buf_10000_697'
                                    687 ;last_num      Allocated with name '_get_u16_str_last_num_10000_697'
                                    688 ;last_pad      Allocated with name '_get_u16_str_last_pad_10000_697'
                                    689 ;------------------------------------------------------------
                                    690 ;	quantum/quantum.c:759: static uint16_t last_num = 0xFF;
      0030F9 90 0C 44         [24]  691 	mov	dptr,#_get_u16_str_last_num_10000_697
      0030FC 74 FF            [12]  692 	mov	a,#0xff
      0030FE F0               [24]  693 	movx	@dptr,a
      0030FF E4               [12]  694 	clr	a
      003100 A3               [24]  695 	inc	dptr
      003101 F0               [24]  696 	movx	@dptr,a
                                    697 ;--------------------------------------------------------
                                    698 ; Home
                                    699 ;--------------------------------------------------------
                                    700 	.area HOME    (CODE)
                                    701 	.area HOME    (CODE)
                                    702 ;--------------------------------------------------------
                                    703 ; code
                                    704 ;--------------------------------------------------------
                                    705 	.area CSEG    (CODE)
                                    706 ;------------------------------------------------------------
                                    707 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    708 ;------------------------------------------------------------
                                    709 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_193'
                                    710 ;------------------------------------------------------------
                                    711 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    712 ;	-----------------------------------------
                           000007   713 	ar7 = 0x07
                           000006   714 	ar6 = 0x06
                           000005   715 	ar5 = 0x05
                           000004   716 	ar4 = 0x04
                           000003   717 	ar3 = 0x03
                           000002   718 	ar2 = 0x02
                           000001   719 	ar1 = 0x01
                           000000   720 	ar0 = 0x00
                                    721 ;	 function extract_mod_bits
                                    722 ;	-----------------------------------------
      00A21B                        723 _extract_mod_bits:
      00A21B 12 3A C2         [24]  724 	lcall	_ak820_outline_0109
      00A21E 90 0C 0E         [24]  725 	mov	dptr,#_extract_mod_bits_code_10000_601
      00A221 12 3A C7         [24]  726 	lcall	_ak820_outline_0110
                                    727 ;	quantum/quantum.c:104: uint8_t mods = (uint8_t)(code >> 8);
      00A224 90 0C 0E         [24]  728 	mov	dptr,#_extract_mod_bits_code_10000_601
      00A227 E0               [24]  729 	movx	a,@dptr
      00A228 A3               [24]  730 	inc	dptr
      00A229 E0               [24]  731 	movx	a,@dptr
                                    732 ;	quantum/quantum.c:105: if (!mods || mods > (QK_MODS_MAX >> 8)) return 0;
      00A22A FF               [12]  733 	mov	r7,a
      00A22B 60 05            [24]  734 	jz	00101$
      00A22D EF               [12]  735 	mov	a,r7
      00A22E 24 E0            [12]  736 	add	a,#0xff - 0x1f
      00A230 50 04            [24]  737 	jnc	00102$
                                    738 ;	free result
      00A232                        739 00101$:
      00A232 75 82 00         [24]  740 	mov	dpl, #0x00
      00A235 22               [24]  741 	ret
      00A236                        742 00102$:
                                    743 ;	quantum/quantum.c:106: return (mods & 0x10) ? (uint8_t)(mods << 4) : mods;
      00A236 EF               [12]  744 	mov	a,r7
      00A237 30 E4 07         [24]  745 	jnb	acc.4,00106$
      00A23A EF               [12]  746 	mov	a,r7
      00A23B C4               [12]  747 	swap	a
      00A23C 54 F0            [12]  748 	anl	a,#0xf0
      00A23E FE               [12]  749 	mov	r6,a
      00A23F 80 02            [24]  750 	sjmp	00107$
      00A241                        751 00106$:
      00A241 8F 06            [24]  752 	mov	ar6,r7
      00A243                        753 00107$:
      00A243 8E 82            [24]  754 	mov	dpl, r6
                                    755 ;	quantum/quantum.c:134: }
      00A245 22               [24]  756 	ret
                                    757 ;------------------------------------------------------------
                                    758 ;Allocation info for local variables in function 'do_code16'
                                    759 ;------------------------------------------------------------
                                    760 ;f             Allocated with name '_do_code16_PARM_2'
                                    761 ;code          Allocated with name '_do_code16_code_10000_604'
                                    762 ;------------------------------------------------------------
                                    763 ;	quantum/quantum.c:136: void do_code16(uint16_t code, void (*f)(uint8_t)) {
                                    764 ;	-----------------------------------------
                                    765 ;	 function register_code16
                                    766 ;	-----------------------------------------
      00A246                        767 _register_code16:
      00A246 12 3A C2         [24]  768 	lcall	_ak820_outline_0109
      00A249 90 0C 10         [24]  769 	mov	dptr,#_register_code16_code_10000_607
      00A24C 12 3A C7         [24]  770 	lcall	_ak820_outline_0110
                                    771 ;	quantum/quantum.c:142: uint8_t mods = extract_mod_bits(code);
      00A24F 90 0C 10         [24]  772 	mov	dptr,#_register_code16_code_10000_607
      00A252 12 3A 34         [24]  773 	lcall	_ak820_outline_0005
      00A255 C0 07            [24]  774 	push	ar7
      00A257 C0 06            [24]  775 	push	ar6
      00A259 51 1B            [12]  776 	acall	_extract_mod_bits
      00A25B AD 82            [24]  777 	mov	r5, dpl
      00A25D D0 06            [24]  778 	pop	ar6
      00A25F D0 07            [24]  779 	pop	ar7
                                    780 ;	quantum/quantum.c:143: if (IS_MODIFIER_KEYCODE(code) || code == KC_NO) {
      00A261 12 A0 56         [24]  781 	lcall	_ak820_outline_0121
      00A264 40 07            [24]  782 	jc	00105$
      00A266 74 E7            [12]  783 	mov	a,#0xe7
      00A268 9E               [12]  784 	subb	a,r6
      00A269 E4               [12]  785 	clr	a
      00A26A 9F               [12]  786 	subb	a,r7
      00A26B 50 08            [24]  787 	jnc	00101$
                                    788 ;	free result
      00A26D                        789 00105$:
      00A26D 90 0C 10         [24]  790 	mov	dptr,#_register_code16_code_10000_607
      00A270 12 72 1B         [24]  791 	lcall	_ak820_outline_0040
      00A273 70 07            [24]  792 	jnz	00102$
      00A275                        793 00101$:
                                    794 ;	quantum/quantum.c:144: register_mods(mods);
      00A275 8D 82            [24]  795 	mov	dpl, r5
      00A277 12 7B 4E         [24]  796 	lcall	_register_mods
      00A27A 80 05            [24]  797 	sjmp	00103$
      00A27C                        798 00102$:
                                    799 ;	quantum/quantum.c:146: register_weak_mods(mods);
      00A27C 8D 82            [24]  800 	mov	dpl, r5
      00A27E 12 7B 76         [24]  801 	lcall	_register_weak_mods
      00A281                        802 00103$:
                                    803 ;	quantum/quantum.c:148: register_code(code);
      00A281 90 0C 10         [24]  804 	mov	dptr,#_register_code16_code_10000_607
      00A284 E0               [24]  805 	movx	a,@dptr
      00A285 F5 82            [12]  806 	mov	dpl,a
                                    807 ;	quantum/quantum.c:158: }
      00A287 02 7A 01         [24]  808 	ljmp	_register_code
                                    809 ;------------------------------------------------------------
                                    810 ;Allocation info for local variables in function 'unregister_code16'
                                    811 ;------------------------------------------------------------
                                    812 ;code          Allocated with name '_unregister_code16_code_10000_612'
                                    813 ;mods          Allocated with name '_unregister_code16_mods_10000_613'
                                    814 ;------------------------------------------------------------
                                    815 ;	quantum/quantum.c:160: __attribute__((weak)) void unregister_code16(uint16_t code) {
                                    816 ;	-----------------------------------------
                                    817 ;	 function unregister_code16
                                    818 ;	-----------------------------------------
      00A28A                        819 _unregister_code16:
      00A28A 12 3A C2         [24]  820 	lcall	_ak820_outline_0109
      00A28D 90 0C 12         [24]  821 	mov	dptr,#_unregister_code16_code_10000_612
      00A290 12 3A C7         [24]  822 	lcall	_ak820_outline_0110
                                    823 ;	quantum/quantum.c:162: uint8_t mods = extract_mod_bits(code);
      00A293 90 0C 12         [24]  824 	mov	dptr,#_unregister_code16_code_10000_612
      00A296 12 3A 34         [24]  825 	lcall	_ak820_outline_0005
      00A299 C0 07            [24]  826 	push	ar7
      00A29B C0 06            [24]  827 	push	ar6
      00A29D 51 1B            [12]  828 	acall	_extract_mod_bits
      00A29F AD 82            [24]  829 	mov	r5, dpl
      00A2A1 D0 06            [24]  830 	pop	ar6
                                    831 ;	quantum/quantum.c:163: unregister_code(code);
      00A2A3 8E 04            [24]  832 	mov	ar4,r6
      00A2A5 8C 82            [24]  833 	mov	dpl, r4
      00A2A7 C0 06            [24]  834 	push	ar6
      00A2A9 C0 05            [24]  835 	push	ar5
      00A2AB 12 7A 86         [24]  836 	lcall	_unregister_code
      00A2AE D0 05            [24]  837 	pop	ar5
      00A2B0 D0 06            [24]  838 	pop	ar6
      00A2B2 D0 07            [24]  839 	pop	ar7
                                    840 ;	quantum/quantum.c:164: if (IS_MODIFIER_KEYCODE(code) || code == KC_NO) {
      00A2B4 12 A0 56         [24]  841 	lcall	_ak820_outline_0121
      00A2B7 40 07            [24]  842 	jc	00105$
      00A2B9 74 E7            [12]  843 	mov	a,#0xe7
      00A2BB 9E               [12]  844 	subb	a,r6
      00A2BC E4               [12]  845 	clr	a
      00A2BD 9F               [12]  846 	subb	a,r7
      00A2BE 50 08            [24]  847 	jnc	00101$
                                    848 ;	free result
      00A2C0                        849 00105$:
      00A2C0 90 0C 12         [24]  850 	mov	dptr,#_unregister_code16_code_10000_612
      00A2C3 12 72 1B         [24]  851 	lcall	_ak820_outline_0040
      00A2C6 70 05            [24]  852 	jnz	00102$
      00A2C8                        853 00101$:
                                    854 ;	quantum/quantum.c:165: unregister_mods(mods);
      00A2C8 8D 82            [24]  855 	mov	dpl, r5
      00A2CA 02 7B 62         [24]  856 	ljmp	_unregister_mods
      00A2CD                        857 00102$:
                                    858 ;	quantum/quantum.c:167: unregister_weak_mods(mods);
      00A2CD 8D 82            [24]  859 	mov	dpl, r5
                                    860 ;	quantum/quantum.c:178: }
      00A2CF 02 7B 8A         [24]  861 	ljmp	_unregister_weak_mods
                                    862 ;------------------------------------------------------------
                                    863 ;Allocation info for local variables in function 'tap_code16_delay'
                                    864 ;------------------------------------------------------------
                                    865 ;delay         Allocated with name '_tap_code16_delay_PARM_2'
                                    866 ;code          Allocated with name '_tap_code16_delay_code_10000_617'
                                    867 ;i             Allocated with name '_tap_code16_delay_i_20000_619'
                                    868 ;i             Allocated with name '_tap_code16_delay_i_50000_622'
                                    869 ;------------------------------------------------------------
                                    870 ;	quantum/quantum.c:185: __attribute__((weak)) void tap_code16_delay(uint16_t code, uint16_t delay) {
                                    871 ;	-----------------------------------------
                                    872 ;	 function pre_process_record_kb
                                    873 ;	-----------------------------------------
      00A2D2                        874 _pre_process_record_kb:
      00A2D2 12 3A C2         [24]  875 	lcall	_ak820_outline_0109
      00A2D5 90 0C 17         [24]  876 	mov	dptr,#_pre_process_record_kb_keycode_10000_626
      00A2D8 12 3A C7         [24]  877 	lcall	_ak820_outline_0110
                                    878 ;	quantum/quantum.c:202: return pre_process_record_user(keycode, record);
      00A2DB 90 0C 17         [24]  879 	mov	dptr,#_pre_process_record_kb_keycode_10000_626
      00A2DE 12 3A 81         [24]  880 	lcall	_ak820_outline_0052
      00A2E1 90 0C 14         [24]  881 	mov	dptr,#_pre_process_record_kb_PARM_2
      00A2E4 12 A0 4D         [24]  882 	lcall	_ak820_outline_0025
      00A2E7 90 0C 19         [24]  883 	mov	dptr,#_pre_process_record_user_PARM_2
      00A2EA 12 A6 8C         [24]  884 	lcall	_ak820_outline_0010
                                    885 ;	quantum/quantum.c:203: }
      00A2ED 41 EF            [12]  886 	ajmp	_pre_process_record_user
                                    887 ;------------------------------------------------------------
                                    888 ;Allocation info for local variables in function 'pre_process_record_user'
                                    889 ;------------------------------------------------------------
                                    890 ;record        Allocated with name '_pre_process_record_user_PARM_2'
                                    891 ;keycode       Allocated with name '_pre_process_record_user_keycode_10000_628'
                                    892 ;------------------------------------------------------------
                                    893 ;	quantum/quantum.c:205: __attribute__((weak)) bool pre_process_record_user(uint16_t keycode, keyrecord_t *record) {
                                    894 ;	-----------------------------------------
                                    895 ;	 function pre_process_record_user
                                    896 ;	-----------------------------------------
      00A2EF                        897 _pre_process_record_user:
                                    898 ;	quantum/quantum.c:206: return true;
      00A2EF 75 82 01         [24]  899 	mov	dpl, #0x01
                                    900 ;	quantum/quantum.c:207: }
      00A2F2 22               [24]  901 	ret
                                    902 ;------------------------------------------------------------
                                    903 ;Allocation info for local variables in function 'process_action_kb'
                                    904 ;------------------------------------------------------------
                                    905 ;record        Allocated with name '_process_action_kb_record_10000_630'
                                    906 ;------------------------------------------------------------
                                    907 ;	quantum/quantum.c:209: __attribute__((weak)) bool process_action_kb(keyrecord_t *record) {
                                    908 ;	-----------------------------------------
                                    909 ;	 function process_action_kb
                                    910 ;	-----------------------------------------
      00A2F3                        911 _process_action_kb:
                                    912 ;	quantum/quantum.c:210: return true;
      00A2F3 75 82 01         [24]  913 	mov	dpl, #0x01
                                    914 ;	quantum/quantum.c:211: }
      00A2F6 22               [24]  915 	ret
                                    916 ;------------------------------------------------------------
                                    917 ;Allocation info for local variables in function 'process_record_kb'
                                    918 ;------------------------------------------------------------
                                    919 ;record        Allocated with name '_process_record_kb_PARM_2'
                                    920 ;keycode       Allocated with name '_process_record_kb_keycode_10000_632'
                                    921 ;------------------------------------------------------------
                                    922 ;	quantum/quantum.c:213: __attribute__((weak)) bool process_record_kb(uint16_t keycode, keyrecord_t *record) {
                                    923 ;	-----------------------------------------
                                    924 ;	 function process_record_kb
                                    925 ;	-----------------------------------------
      00A2F7                        926 _process_record_kb:
      00A2F7 12 3A C2         [24]  927 	lcall	_ak820_outline_0109
      00A2FA 90 0C 1F         [24]  928 	mov	dptr,#_process_record_kb_keycode_10000_632
      00A2FD 12 3A C7         [24]  929 	lcall	_ak820_outline_0110
                                    930 ;	quantum/quantum.c:214: return process_record_user(keycode, record);
      00A300 90 0C 1F         [24]  931 	mov	dptr,#_process_record_kb_keycode_10000_632
      00A303 12 3A 81         [24]  932 	lcall	_ak820_outline_0052
      00A306 90 0C 1C         [24]  933 	mov	dptr,#_process_record_kb_PARM_2
      00A309 12 A0 4D         [24]  934 	lcall	_ak820_outline_0025
      00A30C 90 0C 21         [24]  935 	mov	dptr,#_process_record_user_PARM_2
      00A30F 12 A6 8C         [24]  936 	lcall	_ak820_outline_0010
                                    937 ;	quantum/quantum.c:215: }
      00A312 61 14            [12]  938 	ajmp	_process_record_user
                                    939 ;------------------------------------------------------------
                                    940 ;Allocation info for local variables in function 'process_record_user'
                                    941 ;------------------------------------------------------------
                                    942 ;record        Allocated with name '_process_record_user_PARM_2'
                                    943 ;keycode       Allocated with name '_process_record_user_keycode_10000_634'
                                    944 ;------------------------------------------------------------
                                    945 ;	quantum/quantum.c:217: __attribute__((weak)) bool process_record_user(uint16_t keycode, keyrecord_t *record) {
                                    946 ;	-----------------------------------------
                                    947 ;	 function process_record_user
                                    948 ;	-----------------------------------------
      00A314                        949 _process_record_user:
                                    950 ;	quantum/quantum.c:218: return true;
      00A314 75 82 01         [24]  951 	mov	dpl, #0x01
                                    952 ;	quantum/quantum.c:219: }
      00A317 22               [24]  953 	ret
                                    954 ;------------------------------------------------------------
                                    955 ;Allocation info for local variables in function 'post_process_record_kb'
                                    956 ;------------------------------------------------------------
                                    957 ;record        Allocated with name '_post_process_record_kb_PARM_2'
                                    958 ;keycode       Allocated with name '_post_process_record_kb_keycode_10000_636'
                                    959 ;------------------------------------------------------------
                                    960 ;	quantum/quantum.c:221: __attribute__((weak)) void post_process_record_kb(uint16_t keycode, keyrecord_t *record) {
                                    961 ;	-----------------------------------------
                                    962 ;	 function post_process_record_kb
                                    963 ;	-----------------------------------------
      00A318                        964 _post_process_record_kb:
      00A318 12 3A C2         [24]  965 	lcall	_ak820_outline_0109
      00A31B 90 0C 27         [24]  966 	mov	dptr,#_post_process_record_kb_keycode_10000_636
      00A31E 12 3A C7         [24]  967 	lcall	_ak820_outline_0110
                                    968 ;	quantum/quantum.c:222: post_process_record_user(keycode, record);
      00A321 90 0C 27         [24]  969 	mov	dptr,#_post_process_record_kb_keycode_10000_636
      00A324 12 3A 81         [24]  970 	lcall	_ak820_outline_0052
      00A327 90 0C 24         [24]  971 	mov	dptr,#_post_process_record_kb_PARM_2
      00A32A 12 A0 4D         [24]  972 	lcall	_ak820_outline_0025
      00A32D 90 0C 29         [24]  973 	mov	dptr,#_post_process_record_user_PARM_2
      00A330 12 A6 8C         [24]  974 	lcall	_ak820_outline_0010
                                    975 ;	quantum/quantum.c:223: }
      00A333 61 35            [24]  976 	ajmp	_post_process_record_user
                                    977 ;------------------------------------------------------------
                                    978 ;Allocation info for local variables in function 'post_process_record_user'
                                    979 ;------------------------------------------------------------
                                    980 ;record        Allocated with name '_post_process_record_user_PARM_2'
                                    981 ;keycode       Allocated with name '_post_process_record_user_keycode_10000_638'
                                    982 ;------------------------------------------------------------
                                    983 ;	quantum/quantum.c:225: __attribute__((weak)) void post_process_record_user(uint16_t keycode, keyrecord_t *record) {}
                                    984 ;	-----------------------------------------
                                    985 ;	 function post_process_record_user
                                    986 ;	-----------------------------------------
      00A335                        987 _post_process_record_user:
      00A335 22               [24]  988 	ret
                                    989 ;------------------------------------------------------------
                                    990 ;Allocation info for local variables in function 'shutdown_quantum'
                                    991 ;------------------------------------------------------------
                                    992 ;i             Allocated with name '_shutdown_quantum_i_30000_644'
                                    993 ;------------------------------------------------------------
                                    994 ;	quantum/quantum.c:227: void shutdown_quantum(void) {
                                    995 ;	-----------------------------------------
                                    996 ;	 function shutdown_quantum
                                    997 ;	-----------------------------------------
      00A336                        998 _shutdown_quantum:
                                    999 ;	quantum/quantum.c:228: clear_keyboard();
      00A336 12 7B 9E         [24] 1000 	lcall	_clear_keyboard
                                   1001 ;	quantum/quantum.c:243: shutdown_user();
      00A339 D1 7E            [12] 1002 	acall	_shutdown_user
                                   1003 ;	quantum/quantum.c:244: wait_ms(250);
      00A33B 7F FA            [12] 1004 	mov	r7,#0xfa
      00A33D                       1005 00106$:
      00A33D EF               [12] 1006 	mov	a,r7
      00A33E 60 09            [24] 1007 	jz	00108$
      00A340 90 00 01         [24] 1008 	mov	dptr,#0x0001
      00A343 12 5D 83         [24] 1009 	lcall	_mDelaymS
      00A346 1F               [12] 1010 	dec	r7
      00A347 80 F4            [24] 1011 	sjmp	00106$
      00A349                       1012 00108$:
                                   1013 ;	quantum/quantum.c:249: }
      00A349 22               [24] 1014 	ret
                                   1015 ;------------------------------------------------------------
                                   1016 ;Allocation info for local variables in function 'reset_keyboard'
                                   1017 ;------------------------------------------------------------
                                   1018 ;	quantum/quantum.c:251: void reset_keyboard(void) {
                                   1019 ;	-----------------------------------------
                                   1020 ;	 function reset_keyboard
                                   1021 ;	-----------------------------------------
      00A34A                       1022 _reset_keyboard:
                                   1023 ;	quantum/quantum.c:252: shutdown_quantum();
      00A34A 71 36            [24] 1024 	acall	_shutdown_quantum
                                   1025 ;	quantum/quantum.c:253: bootloader_jump();
                                   1026 ;	quantum/quantum.c:254: }
      00A34C 02 36 59         [24] 1027 	ljmp	_bootloader_jump
                                   1028 ;------------------------------------------------------------
                                   1029 ;Allocation info for local variables in function 'soft_reset_keyboard'
                                   1030 ;------------------------------------------------------------
                                   1031 ;	quantum/quantum.c:256: void soft_reset_keyboard(void) {
                                   1032 ;	-----------------------------------------
                                   1033 ;	 function soft_reset_keyboard
                                   1034 ;	-----------------------------------------
      00A34F                       1035 _soft_reset_keyboard:
                                   1036 ;	quantum/quantum.c:257: shutdown_quantum();
      00A34F 71 36            [24] 1037 	acall	_shutdown_quantum
                                   1038 ;	quantum/quantum.c:258: mcu_reset();
                                   1039 ;	quantum/quantum.c:259: }
      00A351 02 36 4C         [24] 1040 	ljmp	_mcu_reset
                                   1041 ;------------------------------------------------------------
                                   1042 ;Allocation info for local variables in function 'get_record_keycode'
                                   1043 ;------------------------------------------------------------
                                   1044 ;update_layer_cache Allocated with name '_get_record_keycode_PARM_2'
                                   1045 ;record_argument Allocated with name '_get_record_keycode_record_argument_10000_650'
                                   1046 ;record        Allocated with name '_get_record_keycode_record_10000_651'
                                   1047 ;------------------------------------------------------------
                                   1048 ;	quantum/quantum.c:262: uint16_t get_record_keycode(keyrecord_t *record_argument, bool update_layer_cache) {
                                   1049 ;	-----------------------------------------
                                   1050 ;	 function get_record_keycode
                                   1051 ;	-----------------------------------------
      00A354                       1052 _get_record_keycode:
      00A354 12 45 55         [24] 1053 	lcall	_ak820_outline_0036
      00A357 90 0C 2D         [24] 1054 	mov	dptr,#_get_record_keycode_record_argument_10000_650
      00A35A 12 3A 5F         [24] 1055 	lcall	_ak820_outline_0016
                                   1056 ;	quantum/quantum.c:264: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A35D 90 0C 2D         [24] 1057 	mov	dptr,#_get_record_keycode_record_argument_10000_650
      00A360 12 3A 3E         [24] 1058 	lcall	_ak820_outline_0007
                                   1059 ;	quantum/quantum.c:269: if (record->keycode) {
      00A363 4C               [12] 1060 	orl	a,r4
      00A364 60 04            [24] 1061 	jz	00102$
                                   1062 ;	quantum/quantum.c:270: return record->keycode;
      00A366 12 3A D7         [24] 1063 	lcall	_ak820_outline_0126
      00A369 22               [24] 1064 	ret
      00A36A                       1065 00102$:
                                   1066 ;	quantum/quantum.c:274: return ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed && update_layer_cache);
      00A36A 12 7C 08         [24] 1067 	lcall	_ak820_outline_0020
      00A36D 7A 00            [12] 1068 	mov	r2,#0x00
      00A36F 12 45 A2         [24] 1069 	lcall	_ak820_outline_0146
      00A372 12 3A 52         [24] 1070 	lcall	_ak820_outline_0009
      00A375 60 06            [24] 1071 	jz	00105$
      00A377 90 0C 2C         [24] 1072 	mov	dptr,#_get_record_keycode_PARM_2
      00A37A E0               [24] 1073 	movx	a,@dptr
      00A37B 70 04            [24] 1074 	jnz	00106$
      00A37D                       1075 00105$:
                                   1076 ;	assignBit
      00A37D C2 28            [12] 1077 	clr	_get_record_keycode_sloc0_1_0
      00A37F 80 02            [24] 1078 	sjmp	00107$
      00A381                       1079 00106$:
                                   1080 ;	assignBit
      00A381 D2 28            [12] 1081 	setb	_get_record_keycode_sloc0_1_0
      00A383                       1082 00107$:
      00A383 90 09 9E         [24] 1083 	mov	dptr,#_ak820_resolve_key_PARM_2
      00A386 A2 28            [12] 1084 	mov	c,_get_record_keycode_sloc0_1_0
      00A388 E4               [12] 1085 	clr	a
      00A389 33               [12] 1086 	rlc	a
      00A38A F0               [24] 1087 	movx	@dptr,a
      00A38B 8D 82            [24] 1088 	mov	dpl, r5
      00A38D 8C 83            [24] 1089 	mov	dph, r4
                                   1090 ;	quantum/quantum.c:278: }
      00A38F 02 7F 9D         [24] 1091 	ljmp	_ak820_resolve_key
                                   1092 ;------------------------------------------------------------
                                   1093 ;Allocation info for local variables in function 'get_event_keycode'
                                   1094 ;------------------------------------------------------------
                                   1095 ;event         Allocated with name '_get_event_keycode_PARM_1'
                                   1096 ;update_layer_cache Allocated with name '_get_event_keycode_update_layer_cache_10000_654'
                                   1097 ;------------------------------------------------------------
                                   1098 ;	quantum/quantum.c:286: uint16_t get_event_keycode(keyevent_t event, bool update_layer_cache) {
                                   1099 ;	-----------------------------------------
                                   1100 ;	 function pre_process_record_quantum
                                   1101 ;	-----------------------------------------
      00A392                       1102 _pre_process_record_quantum:
      00A392 12 45 55         [24] 1103 	lcall	_ak820_outline_0036
      00A395 90 0C 30         [24] 1104 	mov	dptr,#_pre_process_record_quantum_record_argument_10000_656
      00A398 12 3A 5F         [24] 1105 	lcall	_ak820_outline_0016
                                   1106 ;	quantum/quantum.c:319: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A39B 90 0C 30         [24] 1107 	mov	dptr,#_pre_process_record_quantum_record_argument_10000_656
      00A39E 12 3A 81         [24] 1108 	lcall	_ak820_outline_0052
                                   1109 ;	quantum/quantum.c:323: uint16_t keycode = get_record_keycode(record, true);
      00A3A1 12 74 67         [24] 1110 	lcall	_ak820_outline_0156
      00A3A4 90 0C 2C         [24] 1111 	mov	dptr,#_get_record_keycode_PARM_2
      00A3A7 74 01            [12] 1112 	mov	a,#0x01
      00A3A9 12 74 4C         [24] 1113 	lcall	_ak820_outline_0103
      00A3AC 8D F0            [24] 1114 	mov	b, r5
      00A3AE C0 07            [24] 1115 	push	ar7
      00A3B0 C0 06            [24] 1116 	push	ar6
      00A3B2 71 54            [24] 1117 	acall	_get_record_keycode
      00A3B4 12 45 A8         [24] 1118 	lcall	_ak820_outline_0154
      00A3B7 D0 06            [24] 1119 	pop	ar6
      00A3B9 D0 07            [24] 1120 	pop	ar7
                                   1121 ;	quantum/quantum.c:325: record->keycode = keycode;
      00A3BB 74 07            [12] 1122 	mov	a,#0x07
      00A3BD 12 3A 71         [24] 1123 	lcall	_ak820_outline_0021
      00A3C0 12 3A 9E         [24] 1124 	lcall	_ak820_outline_0072
                                   1125 ;	quantum/quantum.c:327: return pre_process_record_kb(keycode, record) &&
      00A3C3 90 0C 14         [24] 1126 	mov	dptr,#_pre_process_record_kb_PARM_2
      00A3C6 12 A6 7F         [24] 1127 	lcall	_ak820_outline_0002
      00A3C9 C0 07            [24] 1128 	push	ar7
      00A3CB C0 06            [24] 1129 	push	ar6
      00A3CD 51 D2            [12] 1130 	acall	_pre_process_record_kb
      00A3CF E5 82            [12] 1131 	mov	a, dpl
      00A3D1 D0 06            [24] 1132 	pop	ar6
      00A3D3 D0 07            [24] 1133 	pop	ar7
      00A3D5 60 0A            [24] 1134 	jz	00103$
                                   1135 ;	quantum/quantum.c:330: ak820_combo_process((keyrecord_t AK820_STATE_MEM *)record) &&
      00A3D7 12 3A CC         [24] 1136 	lcall	_ak820_outline_0120
      00A3DA 12 38 81         [24] 1137 	lcall	_ak820_combo_process
      00A3DD E5 82            [12] 1138 	mov	a, dpl
      00A3DF 70 04            [24] 1139 	jnz	00104$
                                   1140 ;	quantum/quantum.c:335: true;
      00A3E1                       1141 00103$:
                                   1142 ;	assignBit
      00A3E1 C2 29            [12] 1143 	clr	_pre_process_record_quantum_sloc0_1_0
      00A3E3 80 02            [24] 1144 	sjmp	00105$
      00A3E5                       1145 00104$:
                                   1146 ;	assignBit
      00A3E5 D2 29            [12] 1147 	setb	_pre_process_record_quantum_sloc0_1_0
      00A3E7                       1148 00105$:
      00A3E7 A2 29            [12] 1149 	mov	c,_pre_process_record_quantum_sloc0_1_0
      00A3E9 12 3A F1         [24] 1150 	lcall	_ak820_outline_0162
                                   1151 ;	quantum/quantum.c:336: }
      00A3EC 22               [24] 1152 	ret
                                   1153 ;------------------------------------------------------------
                                   1154 ;Allocation info for local variables in function 'post_process_record_quantum'
                                   1155 ;------------------------------------------------------------
                                   1156 ;record        Allocated with name '_post_process_record_quantum_record_10000_658'
                                   1157 ;keycode       Allocated with name '_post_process_record_quantum_keycode_10000_659'
                                   1158 ;------------------------------------------------------------
                                   1159 ;	quantum/quantum.c:339: void post_process_record_quantum(keyrecord_t *record) {
                                   1160 ;	-----------------------------------------
                                   1161 ;	 function post_process_record_quantum
                                   1162 ;	-----------------------------------------
      00A3ED                       1163 _post_process_record_quantum:
      00A3ED 12 45 55         [24] 1164 	lcall	_ak820_outline_0036
      00A3F0 90 0C 33         [24] 1165 	mov	dptr,#_post_process_record_quantum_record_10000_658
      00A3F3 12 3A 5F         [24] 1166 	lcall	_ak820_outline_0016
                                   1167 ;	quantum/quantum.c:340: uint16_t keycode = get_record_keycode(record, false);
      00A3F6 90 0C 33         [24] 1168 	mov	dptr,#_post_process_record_quantum_record_10000_658
      00A3F9 12 51 63         [24] 1169 	lcall	_ak820_outline_0012
      00A3FC 90 0C 2C         [24] 1170 	mov	dptr,#_get_record_keycode_PARM_2
      00A3FF E4               [12] 1171 	clr	a
      00A400 12 51 6C         [24] 1172 	lcall	_ak820_outline_0034
      00A403 71 54            [24] 1173 	acall	_get_record_keycode
      00A405 12 45 97         [24] 1174 	lcall	_ak820_outline_0136
                                   1175 ;	quantum/quantum.c:341: post_process_record_kb(keycode, record);
      00A408 90 0C 33         [24] 1176 	mov	dptr,#_post_process_record_quantum_record_10000_658
      00A40B 12 A0 4D         [24] 1177 	lcall	_ak820_outline_0025
      00A40E 90 0C 24         [24] 1178 	mov	dptr,#_post_process_record_kb_PARM_2
      00A411 12 A6 8C         [24] 1179 	lcall	_ak820_outline_0010
                                   1180 ;	quantum/quantum.c:342: }
      00A414 61 18            [12] 1181 	ajmp	_post_process_record_kb
                                   1182 ;------------------------------------------------------------
                                   1183 ;Allocation info for local variables in function 'process_record_quantum'
                                   1184 ;------------------------------------------------------------
                                   1185 ;record        Allocated with name '_process_record_quantum_record_10000_660'
                                   1186 ;keycode       Allocated with name '_process_record_quantum_keycode_10000_661'
                                   1187 ;------------------------------------------------------------
                                   1188 ;	quantum/quantum.c:344: bool process_record_quantum(keyrecord_t *record) {
                                   1189 ;	-----------------------------------------
                                   1190 ;	 function process_record_quantum
                                   1191 ;	-----------------------------------------
      00A416                       1192 _process_record_quantum:
      00A416 12 45 55         [24] 1193 	lcall	_ak820_outline_0036
      00A419 90 0C 36         [24] 1194 	mov	dptr,#_process_record_quantum_record_10000_660
      00A41C 12 3A 5F         [24] 1195 	lcall	_ak820_outline_0016
                                   1196 ;	quantum/quantum.c:346: uint16_t keycode = get_record_keycode(record, false);
      00A41F 90 0C 36         [24] 1197 	mov	dptr,#_process_record_quantum_record_10000_660
      00A422 12 51 63         [24] 1198 	lcall	_ak820_outline_0012
      00A425 90 0C 2C         [24] 1199 	mov	dptr,#_get_record_keycode_PARM_2
      00A428 E4               [12] 1200 	clr	a
      00A429 12 51 6C         [24] 1201 	lcall	_ak820_outline_0034
      00A42C 71 54            [24] 1202 	acall	_get_record_keycode
      00A42E 12 45 97         [24] 1203 	lcall	_ak820_outline_0136
                                   1204 ;	quantum/quantum.c:350: return process_record_quantum_helper(keycode, record);
      00A431 90 0C 36         [24] 1205 	mov	dptr,#_process_record_quantum_record_10000_660
      00A434 12 A0 4D         [24] 1206 	lcall	_ak820_outline_0025
      00A437 90 0C 3E         [24] 1207 	mov	dptr,#_process_record_quantum_helper_PARM_2
      00A43A 12 A6 8C         [24] 1208 	lcall	_ak820_outline_0010
                                   1209 ;	quantum/quantum.c:351: }
      00A43D 81 AA            [24] 1210 	ajmp	_process_record_quantum_helper
                                   1211 ;------------------------------------------------------------
                                   1212 ;Allocation info for local variables in function 'process_ak820_nkro'
                                   1213 ;------------------------------------------------------------
                                   1214 ;record_argument Allocated with name '_process_ak820_nkro_PARM_2'
                                   1215 ;keycode       Allocated with name '_process_ak820_nkro_keycode_10000_662'
                                   1216 ;record        Allocated with name '_process_ak820_nkro_record_10000_663'
                                   1217 ;------------------------------------------------------------
                                   1218 ;	quantum/quantum.c:358: static bool process_ak820_nkro(uint16_t keycode, keyrecord_t *record_argument) {
                                   1219 ;	-----------------------------------------
                                   1220 ;	 function process_ak820_nkro
                                   1221 ;	-----------------------------------------
      00A43F                       1222 _process_ak820_nkro:
      00A43F 12 3A C2         [24] 1223 	lcall	_ak820_outline_0109
      00A442 90 0C 3C         [24] 1224 	mov	dptr,#_process_ak820_nkro_keycode_10000_662
      00A445 12 3A C7         [24] 1225 	lcall	_ak820_outline_0110
                                   1226 ;	quantum/quantum.c:360: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A448 90 0C 39         [24] 1227 	mov	dptr,#_process_ak820_nkro_PARM_2
      00A44B 12 3A 81         [24] 1228 	lcall	_ak820_outline_0052
                                   1229 ;	quantum/quantum.c:364: if (keycode < QK_MAGIC_NKRO_ON || keycode > QK_MAGIC_TOGGLE_NKRO) return true;
      00A44E 90 0C 3C         [24] 1230 	mov	dptr,#_process_ak820_nkro_keycode_10000_662
      00A451 12 3A 98         [24] 1231 	lcall	_ak820_outline_0061
      00A454 C3               [12] 1232 	clr	c
      00A455 EC               [12] 1233 	mov	a,r4
      00A456 94 11            [12] 1234 	subb	a,#0x11
      00A458 ED               [12] 1235 	mov	a,r5
      00A459 94 70            [12] 1236 	subb	a,#0x70
      00A45B 40 08            [24] 1237 	jc	00101$
      00A45D 74 13            [12] 1238 	mov	a,#0x13
      00A45F 9C               [12] 1239 	subb	a,r4
      00A460 74 70            [12] 1240 	mov	a,#0x70
      00A462 9D               [12] 1241 	subb	a,r5
      00A463 50 04            [24] 1242 	jnc	00102$
                                   1243 ;	free result
      00A465                       1244 00101$:
      00A465 75 82 01         [24] 1245 	mov	dpl, #0x01
      00A468 22               [24] 1246 	ret
      00A469                       1247 00102$:
                                   1248 ;	quantum/quantum.c:365: if (record->event.pressed) {
      00A469 12 3A 52         [24] 1249 	lcall	_ak820_outline_0009
      00A46C 60 38            [24] 1250 	jz	00105$
                                   1251 ;	quantum/quantum.c:366: clear_keyboard();
      00A46E C0 05            [24] 1252 	push	ar5
      00A470 C0 04            [24] 1253 	push	ar4
      00A472 12 7B 9E         [24] 1254 	lcall	_clear_keyboard
      00A475 D0 04            [24] 1255 	pop	ar4
      00A477 D0 05            [24] 1256 	pop	ar5
                                   1257 ;	quantum/quantum.c:367: keymap_config.nkro = keycode == QK_MAGIC_TOGGLE_NKRO ? !keymap_config.nkro : keycode == QK_MAGIC_NKRO_ON;
      00A479 BC 13 14         [24] 1258 	cjne	r4,#0x13,00108$
      00A47C BD 70 11         [24] 1259 	cjne	r5,#0x70,00108$
      00A47F 90 0A F3         [24] 1260 	mov	dptr,#_keymap_config
      00A482 E0               [24] 1261 	movx	a,@dptr
      00A483 23               [12] 1262 	rl	a
      00A484 54 01            [12] 1263 	anl	a,#0x01
      00A486 B4 01 00         [24] 1264 	cjne	a,#0x01,00136$
      00A489                       1265 00136$:
      00A489 92 2A            [24] 1266 	mov  _process_ak820_nkro_sloc0_1_0,c
      00A48B E4               [12] 1267 	clr	a
      00A48C 33               [12] 1268 	rlc	a
      00A48D FF               [12] 1269 	mov	r7,a
      00A48E 80 09            [24] 1270 	sjmp	00109$
      00A490                       1271 00108$:
      00A490 E4               [12] 1272 	clr	a
      00A491 BC 11 04         [24] 1273 	cjne	r4,#0x11,00137$
      00A494 BD 70 01         [24] 1274 	cjne	r5,#0x70,00137$
      00A497 04               [12] 1275 	inc	a
      00A498                       1276 00137$:
      00A498 FF               [12] 1277 	mov	r7,a
      00A499                       1278 00109$:
                                   1279 ;	assignBit
      00A499 EF               [12] 1280 	mov	a,r7
      00A49A 24 FF            [12] 1281 	add	a,#0xff
      00A49C E4               [12] 1282 	clr	a
      00A49D 33               [12] 1283 	rlc	a
      00A49E 90 0A F3         [24] 1284 	mov	dptr,#_keymap_config
      00A4A1 13               [12] 1285 	rrc	a
      00A4A2 E0               [24] 1286 	movx	a,@dptr
      00A4A3 92 E7            [24] 1287 	mov	acc.7,c
      00A4A5 F0               [24] 1288 	movx	@dptr,a
      00A4A6                       1289 00105$:
                                   1290 ;	quantum/quantum.c:369: return false;
      00A4A6 75 82 00         [24] 1291 	mov	dpl, #0x00
                                   1292 ;	quantum/quantum.c:370: }
      00A4A9 22               [24] 1293 	ret
                                   1294 ;------------------------------------------------------------
                                   1295 ;Allocation info for local variables in function 'process_record_quantum_helper'
                                   1296 ;------------------------------------------------------------
                                   1297 ;record_argument Allocated with name '_process_record_quantum_helper_PARM_2'
                                   1298 ;keycode       Allocated with name '_process_record_quantum_helper_keycode_10000_667'
                                   1299 ;record        Allocated with name '_process_record_quantum_helper_record_10000_668'
                                   1300 ;------------------------------------------------------------
                                   1301 ;	quantum/quantum.c:373: bool process_record_quantum_helper(uint16_t keycode, keyrecord_t *record_argument) {
                                   1302 ;	-----------------------------------------
                                   1303 ;	 function process_record_quantum_helper
                                   1304 ;	-----------------------------------------
      00A4AA                       1305 _process_record_quantum_helper:
      00A4AA 12 3A C2         [24] 1306 	lcall	_ak820_outline_0109
      00A4AD 90 0C 41         [24] 1307 	mov	dptr,#_process_record_quantum_helper_keycode_10000_667
      00A4B0 12 3A C7         [24] 1308 	lcall	_ak820_outline_0110
                                   1309 ;	quantum/quantum.c:375: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A4B3 90 0C 3E         [24] 1310 	mov	dptr,#_process_record_quantum_helper_PARM_2
      00A4B6 12 3A 81         [24] 1311 	lcall	_ak820_outline_0052
                                   1312 ;	quantum/quantum.c:415: ak820_gui_process(keycode, record->event.pressed) &&
      00A4B9 90 0C 41         [24] 1313 	mov	dptr,#_process_record_quantum_helper_keycode_10000_667
      00A4BC 12 3A 98         [24] 1314 	lcall	_ak820_outline_0061
      00A4BF 74 05            [12] 1315 	mov	a,#0x05
      00A4C1 12 4A AD         [24] 1316 	lcall	_ak820_outline_0032
      00A4C4 90 09 A4         [24] 1317 	mov	dptr,#_ak820_gui_process_PARM_2
      00A4C7 12 3A B6         [24] 1318 	lcall	_ak820_outline_0101
      00A4CA C0 07            [24] 1319 	push	ar7
      00A4CC C0 06            [24] 1320 	push	ar6
      00A4CE C0 05            [24] 1321 	push	ar5
      00A4D0 C0 04            [24] 1322 	push	ar4
      00A4D2 C0 03            [24] 1323 	push	ar3
      00A4D4 C0 02            [24] 1324 	push	ar2
      00A4D6 12 80 7A         [24] 1325 	lcall	_ak820_gui_process
      00A4D9 E5 82            [12] 1326 	mov	a, dpl
      00A4DB D0 02            [24] 1327 	pop	ar2
      00A4DD D0 03            [24] 1328 	pop	ar3
      00A4DF D0 04            [24] 1329 	pop	ar4
      00A4E1 D0 05            [24] 1330 	pop	ar5
      00A4E3 D0 06            [24] 1331 	pop	ar6
      00A4E5 D0 07            [24] 1332 	pop	ar7
      00A4E7 70 02            [24] 1333 	jnz	00212$
      00A4E9 C1 40            [12] 1334 	ajmp	00101$
      00A4EB                       1335 00212$:
                                   1336 ;	quantum/quantum.c:418: process_ak820_nkro(keycode, record) &&
      00A4EB 90 0C 39         [24] 1337 	mov	dptr,#_process_ak820_nkro_PARM_2
      00A4EE 12 A6 7F         [24] 1338 	lcall	_ak820_outline_0002
      00A4F1 C0 07            [24] 1339 	push	ar7
      00A4F3 C0 06            [24] 1340 	push	ar6
      00A4F5 C0 05            [24] 1341 	push	ar5
      00A4F7 C0 04            [24] 1342 	push	ar4
      00A4F9 C0 03            [24] 1343 	push	ar3
      00A4FB C0 02            [24] 1344 	push	ar2
      00A4FD 91 3F            [24] 1345 	acall	_process_ak820_nkro
      00A4FF E5 82            [12] 1346 	mov	a, dpl
      00A501 D0 02            [24] 1347 	pop	ar2
      00A503 D0 03            [24] 1348 	pop	ar3
      00A505 D0 04            [24] 1349 	pop	ar4
      00A507 D0 05            [24] 1350 	pop	ar5
      00A509 D0 06            [24] 1351 	pop	ar6
      00A50B D0 07            [24] 1352 	pop	ar7
      00A50D 70 02            [24] 1353 	jnz	00213$
      00A50F C1 40            [12] 1354 	ajmp	00101$
      00A511                       1355 00213$:
                                   1356 ;	quantum/quantum.c:429: process_last_key(keycode, record) && process_repeat_key(keycode, record) &&
      00A511 90 0B F7         [24] 1357 	mov	dptr,#_process_last_key_PARM_2
      00A514 12 A6 7F         [24] 1358 	lcall	_ak820_outline_0002
      00A517 C0 07            [24] 1359 	push	ar7
      00A519 C0 06            [24] 1360 	push	ar6
      00A51B C0 05            [24] 1361 	push	ar5
      00A51D C0 04            [24] 1362 	push	ar4
      00A51F C0 03            [24] 1363 	push	ar3
      00A521 C0 02            [24] 1364 	push	ar2
      00A523 12 9F 87         [24] 1365 	lcall	_process_last_key
      00A526 E5 82            [12] 1366 	mov	a, dpl
      00A528 D0 02            [24] 1367 	pop	ar2
      00A52A D0 03            [24] 1368 	pop	ar3
      00A52C D0 04            [24] 1369 	pop	ar4
      00A52E D0 05            [24] 1370 	pop	ar5
      00A530 D0 06            [24] 1371 	pop	ar6
      00A532 D0 07            [24] 1372 	pop	ar7
      00A534 70 02            [24] 1373 	jnz	00214$
      00A536 C1 40            [12] 1374 	ajmp	00101$
      00A538                       1375 00214$:
      00A538 90 0B FD         [24] 1376 	mov	dptr,#_process_repeat_key_PARM_2
      00A53B 12 A6 7F         [24] 1377 	lcall	_ak820_outline_0002
      00A53E C0 07            [24] 1378 	push	ar7
      00A540 C0 06            [24] 1379 	push	ar6
      00A542 C0 05            [24] 1380 	push	ar5
      00A544 C0 04            [24] 1381 	push	ar4
      00A546 C0 03            [24] 1382 	push	ar3
      00A548 C0 02            [24] 1383 	push	ar2
      00A54A 12 A0 05         [24] 1384 	lcall	_process_repeat_key
      00A54D E5 82            [12] 1385 	mov	a, dpl
      00A54F D0 02            [24] 1386 	pop	ar2
      00A551 D0 03            [24] 1387 	pop	ar3
      00A553 D0 04            [24] 1388 	pop	ar4
      00A555 D0 05            [24] 1389 	pop	ar5
      00A557 D0 06            [24] 1390 	pop	ar6
      00A559 D0 07            [24] 1391 	pop	ar7
      00A55B 70 02            [24] 1392 	jnz	00215$
      00A55D C1 40            [12] 1393 	ajmp	00101$
      00A55F                       1394 00215$:
                                   1395 ;	quantum/quantum.c:438: process_record_via(keycode, record) &&
      00A55F 90 0C 7E         [24] 1396 	mov	dptr,#_process_record_via_PARM_2
      00A562 12 A6 7F         [24] 1397 	lcall	_ak820_outline_0002
      00A565 C0 07            [24] 1398 	push	ar7
      00A567 C0 06            [24] 1399 	push	ar6
      00A569 C0 05            [24] 1400 	push	ar5
      00A56B C0 04            [24] 1401 	push	ar4
      00A56D C0 03            [24] 1402 	push	ar3
      00A56F C0 02            [24] 1403 	push	ar2
      00A571 12 AB 84         [24] 1404 	lcall	_process_record_via
      00A574 E5 82            [12] 1405 	mov	a, dpl
      00A576 D0 02            [24] 1406 	pop	ar2
      00A578 D0 03            [24] 1407 	pop	ar3
      00A57A D0 04            [24] 1408 	pop	ar4
      00A57C D0 05            [24] 1409 	pop	ar5
      00A57E D0 06            [24] 1410 	pop	ar6
      00A580 D0 07            [24] 1411 	pop	ar7
      00A582 70 02            [24] 1412 	jnz	00216$
      00A584 C1 40            [12] 1413 	ajmp	00101$
      00A586                       1414 00216$:
                                   1415 ;	quantum/quantum.c:448: process_record_kb(keycode, record) &&
      00A586 90 0C 1C         [24] 1416 	mov	dptr,#_process_record_kb_PARM_2
      00A589 12 A6 7F         [24] 1417 	lcall	_ak820_outline_0002
      00A58C C0 07            [24] 1418 	push	ar7
      00A58E C0 06            [24] 1419 	push	ar6
      00A590 C0 05            [24] 1420 	push	ar5
      00A592 C0 04            [24] 1421 	push	ar4
      00A594 C0 03            [24] 1422 	push	ar3
      00A596 C0 02            [24] 1423 	push	ar2
      00A598 51 F7            [12] 1424 	acall	_process_record_kb
      00A59A E5 82            [12] 1425 	mov	a, dpl
      00A59C D0 02            [24] 1426 	pop	ar2
      00A59E D0 03            [24] 1427 	pop	ar3
      00A5A0 D0 04            [24] 1428 	pop	ar4
      00A5A2 D0 05            [24] 1429 	pop	ar5
      00A5A4 D0 06            [24] 1430 	pop	ar6
      00A5A6 D0 07            [24] 1431 	pop	ar7
      00A5A8 70 02            [24] 1432 	jnz	00217$
      00A5AA C1 40            [12] 1433 	ajmp	00101$
      00A5AC                       1434 00217$:
                                   1435 ;	quantum/quantum.c:471: process_caps_word(keycode, record) &&
      00A5AC 90 0B DF         [24] 1436 	mov	dptr,#_process_caps_word_PARM_2
      00A5AF 12 A6 7F         [24] 1437 	lcall	_ak820_outline_0002
      00A5B2 C0 07            [24] 1438 	push	ar7
      00A5B4 C0 06            [24] 1439 	push	ar6
      00A5B6 C0 05            [24] 1440 	push	ar5
      00A5B8 C0 04            [24] 1441 	push	ar4
      00A5BA C0 03            [24] 1442 	push	ar3
      00A5BC C0 02            [24] 1443 	push	ar2
      00A5BE 12 9D 12         [24] 1444 	lcall	_process_caps_word
      00A5C1 E5 82            [12] 1445 	mov	a, dpl
      00A5C3 D0 02            [24] 1446 	pop	ar2
      00A5C5 D0 03            [24] 1447 	pop	ar3
      00A5C7 D0 04            [24] 1448 	pop	ar4
      00A5C9 D0 05            [24] 1449 	pop	ar5
      00A5CB D0 06            [24] 1450 	pop	ar6
      00A5CD D0 07            [24] 1451 	pop	ar7
      00A5CF 70 02            [24] 1452 	jnz	00218$
      00A5D1 C1 40            [12] 1453 	ajmp	00101$
      00A5D3                       1454 00218$:
                                   1455 ;	quantum/quantum.c:498: process_grave_esc(keycode, record) &&
      00A5D3 90 0B E4         [24] 1456 	mov	dptr,#_process_grave_esc_PARM_2
      00A5D6 12 A6 7F         [24] 1457 	lcall	_ak820_outline_0002
      00A5D9 C0 07            [24] 1458 	push	ar7
      00A5DB C0 06            [24] 1459 	push	ar6
      00A5DD C0 05            [24] 1460 	push	ar5
      00A5DF C0 04            [24] 1461 	push	ar4
      00A5E1 C0 03            [24] 1462 	push	ar3
      00A5E3 C0 02            [24] 1463 	push	ar2
      00A5E5 12 9E 24         [24] 1464 	lcall	_process_grave_esc
      00A5E8 E5 82            [12] 1465 	mov	a, dpl
      00A5EA D0 02            [24] 1466 	pop	ar2
      00A5EC D0 03            [24] 1467 	pop	ar3
      00A5EE D0 04            [24] 1468 	pop	ar4
      00A5F0 D0 05            [24] 1469 	pop	ar5
      00A5F2 D0 06            [24] 1470 	pop	ar6
      00A5F4 D0 07            [24] 1471 	pop	ar7
      00A5F6 60 48            [24] 1472 	jz	00101$
                                   1473 ;	quantum/quantum.c:501: process_rgb(keycode, record) &&
      00A5F8 90 0C 02         [24] 1474 	mov	dptr,#_process_rgb_PARM_2
      00A5FB 12 A6 7F         [24] 1475 	lcall	_ak820_outline_0002
      00A5FE C0 07            [24] 1476 	push	ar7
      00A600 C0 06            [24] 1477 	push	ar6
      00A602 C0 05            [24] 1478 	push	ar5
      00A604 C0 04            [24] 1479 	push	ar4
      00A606 C0 03            [24] 1480 	push	ar3
      00A608 C0 02            [24] 1481 	push	ar2
      00A60A 11 5E            [12] 1482 	acall	_process_rgb
      00A60C E5 82            [12] 1483 	mov	a, dpl
      00A60E D0 02            [24] 1484 	pop	ar2
      00A610 D0 03            [24] 1485 	pop	ar3
      00A612 D0 04            [24] 1486 	pop	ar4
      00A614 D0 05            [24] 1487 	pop	ar5
      00A616 D0 06            [24] 1488 	pop	ar6
      00A618 D0 07            [24] 1489 	pop	ar7
      00A61A 60 24            [24] 1490 	jz	00101$
                                   1491 ;	quantum/quantum.c:513: process_tri_layer(keycode, record) &&
      00A61C 90 0C 08         [24] 1492 	mov	dptr,#_process_tri_layer_PARM_2
      00A61F 12 A6 7F         [24] 1493 	lcall	_ak820_outline_0002
      00A622 C0 07            [24] 1494 	push	ar7
      00A624 C0 06            [24] 1495 	push	ar6
      00A626 C0 05            [24] 1496 	push	ar5
      00A628 C0 04            [24] 1497 	push	ar4
      00A62A C0 03            [24] 1498 	push	ar3
      00A62C C0 02            [24] 1499 	push	ar2
      00A62E 31 0F            [12] 1500 	acall	_process_tri_layer
      00A630 E5 82            [12] 1501 	mov	a, dpl
      00A632 D0 02            [24] 1502 	pop	ar2
      00A634 D0 03            [24] 1503 	pop	ar3
      00A636 D0 04            [24] 1504 	pop	ar4
      00A638 D0 05            [24] 1505 	pop	ar5
      00A63A D0 06            [24] 1506 	pop	ar6
      00A63C D0 07            [24] 1507 	pop	ar7
      00A63E 70 04            [24] 1508 	jnz	00102$
                                   1509 ;	quantum/quantum.c:515: true)) {
      00A640                       1510 00101$:
                                   1511 ;	quantum/quantum.c:516: return false;
      00A640 75 82 00         [24] 1512 	mov	dpl, #0x00
      00A643 22               [24] 1513 	ret
      00A644                       1514 00102$:
                                   1515 ;	quantum/quantum.c:519: if (record->event.pressed) {
      00A644 12 3A EC         [24] 1516 	lcall	_ak820_outline_0147
      00A647 E0               [24] 1517 	movx	a,@dptr
      00A648 60 2D            [24] 1518 	jz	00118$
                                   1519 ;	quantum/quantum.c:520: switch (keycode) {
      00A64A BC 00 05         [24] 1520 	cjne	r4,#0x00,00223$
      00A64D BD 7C 02         [24] 1521 	cjne	r5,#0x7c,00223$
      00A650 80 10            [24] 1522 	sjmp	00113$
      00A652                       1523 00223$:
      00A652 BC 01 05         [24] 1524 	cjne	r4,#0x01,00224$
      00A655 BD 7C 02         [24] 1525 	cjne	r5,#0x7c,00224$
      00A658 80 0E            [24] 1526 	sjmp	00114$
      00A65A                       1527 00224$:
                                   1528 ;	quantum/quantum.c:522: case QK_BOOTLOADER:
      00A65A BC 03 1A         [24] 1529 	cjne	r4,#0x03,00118$
      00A65D BD 7C 17         [24] 1530 	cjne	r5,#0x7c,00118$
      00A660 80 0C            [24] 1531 	sjmp	00115$
      00A662                       1532 00113$:
                                   1533 ;	quantum/quantum.c:523: reset_keyboard();
      00A662 71 4A            [24] 1534 	acall	_reset_keyboard
                                   1535 ;	quantum/quantum.c:524: return false;
      00A664 75 82 00         [24] 1536 	mov	dpl, #0x00
                                   1537 ;	quantum/quantum.c:525: case QK_REBOOT:
      00A667 22               [24] 1538 	ret
      00A668                       1539 00114$:
                                   1540 ;	quantum/quantum.c:526: soft_reset_keyboard();
      00A668 71 4F            [24] 1541 	acall	_soft_reset_keyboard
                                   1542 ;	quantum/quantum.c:527: return false;
      00A66A 75 82 00         [24] 1543 	mov	dpl, #0x00
                                   1544 ;	quantum/quantum.c:539: case QK_CLEAR_EEPROM:
      00A66D 22               [24] 1545 	ret
      00A66E                       1546 00115$:
                                   1547 ;	quantum/quantum.c:546: eeconfig_disable();
      00A66E 12 94 8F         [24] 1548 	lcall	_eeconfig_disable
                                   1549 ;	quantum/quantum.c:547: soft_reset_keyboard();
      00A671 71 4F            [24] 1550 	acall	_soft_reset_keyboard
                                   1551 ;	quantum/quantum.c:549: return false;
      00A673 75 82 00         [24] 1552 	mov	dpl, #0x00
                                   1553 ;	quantum/quantum.c:604: }
      00A676 22               [24] 1554 	ret
      00A677                       1555 00118$:
                                   1556 ;	quantum/quantum.c:607: return process_action_kb(record);
      00A677 7D 00            [12] 1557 	mov	r5,#0x00
      00A679 12 74 45         [24] 1558 	lcall	_ak820_outline_0050
                                   1559 ;	quantum/quantum.c:608: }
      00A67C 41 F3            [12] 1560 	ajmp	_process_action_kb
                                   1561 ;------------------------------------------------------------
                                   1562 ;Allocation info for local variables in function 'set_single_persistent_default_layer'
                                   1563 ;------------------------------------------------------------
                                   1564 ;default_layer Allocated with name '_set_single_persistent_default_layer_default_layer_10000_675'
                                   1565 ;------------------------------------------------------------
                                   1566 ;	quantum/quantum.c:610: void set_single_persistent_default_layer(uint8_t default_layer) {
                                   1567 ;	-----------------------------------------
                                   1568 ;	 function shutdown_user
                                   1569 ;	-----------------------------------------
      00A67E                       1570 _shutdown_user:
      00A67E 22               [24] 1571 	ret
                                   1572 ;------------------------------------------------------------
                                   1573 ;Allocation info for local variables in function 'suspend_power_down_quantum'
                                   1574 ;------------------------------------------------------------
                                   1575 ;	quantum/quantum.c:626: void suspend_power_down_quantum(void) {
                                   1576 ;	-----------------------------------------
                                   1577 	.area CSEG    (CODE)
                                   1578 	.area CONST   (CODE)
                                   1579 	.area XINIT   (CODE)
                                   1580 	.area CABS    (ABS,CODE)
                                   1581 
                                   1582 ; Experimental exact instruction outlining.
                                   1583 	.globl _ak820_outline_0002
                                   1584 	.globl _ak820_outline_0005
                                   1585 	.globl _ak820_outline_0007
                                   1586 	.globl _ak820_outline_0009
                                   1587 	.globl _ak820_outline_0010
                                   1588 	.globl _ak820_outline_0012
                                   1589 	.globl _ak820_outline_0016
                                   1590 	.globl _ak820_outline_0020
                                   1591 	.globl _ak820_outline_0021
                                   1592 	.globl _ak820_outline_0025
                                   1593 	.globl _ak820_outline_0032
                                   1594 	.globl _ak820_outline_0034
                                   1595 	.globl _ak820_outline_0036
                                   1596 	.globl _ak820_outline_0040
                                   1597 	.globl _ak820_outline_0050
                                   1598 	.globl _ak820_outline_0052
                                   1599 	.globl _ak820_outline_0061
                                   1600 	.globl _ak820_outline_0072
                                   1601 	.globl _ak820_outline_0101
                                   1602 	.globl _ak820_outline_0103
                                   1603 	.globl _ak820_outline_0109
                                   1604 	.globl _ak820_outline_0110
                                   1605 	.globl _ak820_outline_0120
                                   1606 	.globl _ak820_outline_0121
                                   1607 	.globl _ak820_outline_0126
                                   1608 	.globl _ak820_outline_0136
                                   1609 	.globl _ak820_outline_0146
                                   1610 	.globl _ak820_outline_0147
                                   1611 	.globl _ak820_outline_0154
                                   1612 	.globl _ak820_outline_0156
                                   1613 	.globl _ak820_outline_0162
                                   1614 
                                   1615 	.area CSEG (CODE)
                                   1616 ; function ak820_outline_0002
      00A67F                       1617 _ak820_outline_0002:
      00A67F EE               [12] 1618 	mov	a,r6
      00A680 F0               [24] 1619 	movx	@dptr,a
      00A681 EF               [12] 1620 	mov	a,r7
      00A682 A3               [24] 1621 	inc	dptr
      00A683 F0               [24] 1622 	movx	@dptr,a
      00A684 E4               [12] 1623 	clr	a
      00A685 A3               [24] 1624 	inc	dptr
      00A686 F0               [24] 1625 	movx	@dptr,a
      00A687 8C 82            [24] 1626 	mov	dpl,r4
      00A689 8D 83            [24] 1627 	mov	dph,r5
      00A68B 22               [24] 1628 	ret
                                   1629 
                                   1630 	.area CSEG (CODE)
                                   1631 ; function ak820_outline_0010
      00A68C                       1632 _ak820_outline_0010:
      00A68C EB               [12] 1633 	mov	a,r3
      00A68D F0               [24] 1634 	movx	@dptr,a
      00A68E EC               [12] 1635 	mov	a,r4
      00A68F A3               [24] 1636 	inc	dptr
      00A690 F0               [24] 1637 	movx	@dptr,a
      00A691 ED               [12] 1638 	mov	a,r5
      00A692 A3               [24] 1639 	inc	dptr
      00A693 F0               [24] 1640 	movx	@dptr,a
      00A694 8E 82            [24] 1641 	mov	dpl,r6
      00A696 8F 83            [24] 1642 	mov	dph,r7
      00A698 22               [24] 1643 	ret
