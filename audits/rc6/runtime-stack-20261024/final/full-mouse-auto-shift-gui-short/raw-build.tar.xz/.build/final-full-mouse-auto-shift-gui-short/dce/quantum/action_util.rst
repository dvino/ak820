                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action_util
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _host_consumer_send
                                     12 	.globl _host_system_send
                                     13 	.globl _host_keyboard_send
                                     14 	.globl _clear_keys_from_report
                                     15 	.globl _del_key_from_report
                                     16 	.globl _add_key_to_report
                                     17 	.globl _KEYCODE2CONSUMER
                                     18 	.globl _ADC_START
                                     19 	.globl _S0_R_FIFO
                                     20 	.globl _S0_T_FIFO
                                     21 	.globl _S0_FREE
                                     22 	.globl _S0_IF_BYTE
                                     23 	.globl _S0_IF_FIRST
                                     24 	.globl _S0_IF_OV
                                     25 	.globl _S0_FST_ACT
                                     26 	.globl _CP_RL2
                                     27 	.globl _C_T2
                                     28 	.globl _TR2
                                     29 	.globl _EXEN2
                                     30 	.globl _TCLK
                                     31 	.globl _RCLK
                                     32 	.globl _EXF2
                                     33 	.globl _CAP1F
                                     34 	.globl _TF2
                                     35 	.globl _RI
                                     36 	.globl _TI
                                     37 	.globl _RB8
                                     38 	.globl _TB8
                                     39 	.globl _REN
                                     40 	.globl _SM2
                                     41 	.globl _SM1
                                     42 	.globl _SM0
                                     43 	.globl _IT0
                                     44 	.globl _IE0
                                     45 	.globl _IT1
                                     46 	.globl _IE1
                                     47 	.globl _TR0
                                     48 	.globl _TF0
                                     49 	.globl _TR1
                                     50 	.globl _TF1
                                     51 	.globl _P4_0
                                     52 	.globl _P4_1
                                     53 	.globl _P4_2
                                     54 	.globl _P4_3
                                     55 	.globl _P4_4
                                     56 	.globl _P4_5
                                     57 	.globl _P4_6
                                     58 	.globl _RXD
                                     59 	.globl _TXD
                                     60 	.globl _INT0
                                     61 	.globl _INT1
                                     62 	.globl _T0
                                     63 	.globl _T1
                                     64 	.globl _MOSI1
                                     65 	.globl _MISO1
                                     66 	.globl _SCK1
                                     67 	.globl _P3_0
                                     68 	.globl _P3_1
                                     69 	.globl _P3_2
                                     70 	.globl _P3_3
                                     71 	.globl _P3_4
                                     72 	.globl _P3_5
                                     73 	.globl _P3_6
                                     74 	.globl _P3_7
                                     75 	.globl _CAP1_
                                     76 	.globl _T2_
                                     77 	.globl _CAP2_
                                     78 	.globl _T2EX_
                                     79 	.globl _RXD1
                                     80 	.globl _TXD1
                                     81 	.globl _P2_0
                                     82 	.globl _P2_1
                                     83 	.globl _P2_2
                                     84 	.globl _P2_3
                                     85 	.globl _P2_4
                                     86 	.globl _P2_5
                                     87 	.globl _P2_6
                                     88 	.globl _P2_7
                                     89 	.globl _AIN0
                                     90 	.globl _AIN1
                                     91 	.globl _AIN2
                                     92 	.globl _AIN3
                                     93 	.globl _AIN4
                                     94 	.globl _AIN5
                                     95 	.globl _AIN6
                                     96 	.globl _AIN7
                                     97 	.globl _CAP1
                                     98 	.globl _T2
                                     99 	.globl _CAP2
                                    100 	.globl _T2EX
                                    101 	.globl _INT0_
                                    102 	.globl _SCS
                                    103 	.globl _MOSI
                                    104 	.globl _MISO
                                    105 	.globl _SCK
                                    106 	.globl _RXD1_
                                    107 	.globl _TXD1_
                                    108 	.globl _P1_0
                                    109 	.globl _P1_1
                                    110 	.globl _P1_2
                                    111 	.globl _P1_3
                                    112 	.globl _P1_4
                                    113 	.globl _P1_5
                                    114 	.globl _P1_6
                                    115 	.globl _P1_7
                                    116 	.globl _AIN8
                                    117 	.globl _AIN9
                                    118 	.globl _AIN10
                                    119 	.globl _AIN11
                                    120 	.globl _AIN12
                                    121 	.globl _AIN13
                                    122 	.globl _RXD_
                                    123 	.globl _TXD_
                                    124 	.globl _SCL0
                                    125 	.globl _SDA0
                                    126 	.globl _P0_0
                                    127 	.globl _P0_1
                                    128 	.globl _P0_2
                                    129 	.globl _P0_3
                                    130 	.globl _P0_4
                                    131 	.globl _P0_5
                                    132 	.globl _P0_6
                                    133 	.globl _P0_7
                                    134 	.globl _IE_SPI0
                                    135 	.globl _IE_USB
                                    136 	.globl _IE_ADC
                                    137 	.globl _IE_UART1
                                    138 	.globl _IE_PWM_I2C
                                    139 	.globl _IE_GPIO
                                    140 	.globl _IE_WDOG
                                    141 	.globl _PX0
                                    142 	.globl _PT0
                                    143 	.globl _PX1
                                    144 	.globl _PT1
                                    145 	.globl _PS
                                    146 	.globl _PT2
                                    147 	.globl _PL_FLAG
                                    148 	.globl _PH_FLAG
                                    149 	.globl _EX0
                                    150 	.globl _ET0
                                    151 	.globl _EX1
                                    152 	.globl _ET1
                                    153 	.globl _ES
                                    154 	.globl _ET2
                                    155 	.globl _E_DIS
                                    156 	.globl _EA
                                    157 	.globl _P
                                    158 	.globl _F1
                                    159 	.globl _OV
                                    160 	.globl _RS0
                                    161 	.globl _RS1
                                    162 	.globl _F0
                                    163 	.globl _AC
                                    164 	.globl _CY
                                    165 	.globl _I2CS_INT_ST
                                    166 	.globl _I2CX_INT
                                    167 	.globl _LED_STATUS
                                    168 	.globl _LED_DMA_H
                                    169 	.globl _LED_DMA_L
                                    170 	.globl _LED_DMA
                                    171 	.globl _LED_PWM_OE
                                    172 	.globl _LED_COMMON
                                    173 	.globl _ADC_CHAN
                                    174 	.globl _ADC_DAT_H
                                    175 	.globl _ADC_DAT_L
                                    176 	.globl _ADC_DAT
                                    177 	.globl _ADC_CTRL
                                    178 	.globl _SPI1_CK_SE
                                    179 	.globl _SPI1_CTRL
                                    180 	.globl _SPI1_DATA
                                    181 	.globl _SPI1_STAT
                                    182 	.globl _SIF1
                                    183 	.globl _SBAUD1
                                    184 	.globl _SBUF1
                                    185 	.globl _SCON1
                                    186 	.globl _SPI0_SETUP
                                    187 	.globl _SPI0_CK_SE
                                    188 	.globl _SPI0_CTRL
                                    189 	.globl _SPI0_DATA
                                    190 	.globl _SPI0_STAT
                                    191 	.globl _T2CAP1H
                                    192 	.globl _T2CAP1L
                                    193 	.globl _T2CAP1
                                    194 	.globl _TH2
                                    195 	.globl _TL2
                                    196 	.globl _T2COUNT
                                    197 	.globl _RCAP2H
                                    198 	.globl _RCAP2L
                                    199 	.globl _RCAP2
                                    200 	.globl _T2MOD
                                    201 	.globl _T2CON
                                    202 	.globl _SBUF
                                    203 	.globl _SCON
                                    204 	.globl _TH1
                                    205 	.globl _TH0
                                    206 	.globl _TL1
                                    207 	.globl _TL0
                                    208 	.globl _TMOD
                                    209 	.globl _TCON
                                    210 	.globl _XBUS_AUX
                                    211 	.globl _P7
                                    212 	.globl _P6_DIR
                                    213 	.globl _P6_OUT_PU
                                    214 	.globl _P6_IN
                                    215 	.globl _P5_DIR
                                    216 	.globl _P5_OUT_PU
                                    217 	.globl _P5_IN
                                    218 	.globl _P4_LED_KEY
                                    219 	.globl _P4_DIR_PU
                                    220 	.globl _P4_MOD_OC
                                    221 	.globl _P4
                                    222 	.globl _P3_DIR_PU
                                    223 	.globl _P3_MOD_OC
                                    224 	.globl _P3
                                    225 	.globl _P2_DIR_PU
                                    226 	.globl _P2_MOD_OC
                                    227 	.globl _P2
                                    228 	.globl _P1_DIR_PU
                                    229 	.globl _P1_MOD_OC
                                    230 	.globl _P1
                                    231 	.globl _P0_DIR_PU
                                    232 	.globl _P0_MOD_OC
                                    233 	.globl _P0
                                    234 	.globl _ROM_CTRL
                                    235 	.globl _ROM_DATA_HH
                                    236 	.globl _ROM_DATA_HL
                                    237 	.globl _ROM_DATA_HI
                                    238 	.globl _ROM_ADDR_H
                                    239 	.globl _ROM_ADDR_L
                                    240 	.globl _ROM_ADDR
                                    241 	.globl _GPIO_IE
                                    242 	.globl _IP_EX
                                    243 	.globl _IE_EX
                                    244 	.globl _IP
                                    245 	.globl _IE
                                    246 	.globl _WDOG_COUNT
                                    247 	.globl _RESET_KEEP
                                    248 	.globl _WAKE_CTRL
                                    249 	.globl _CLOCK_CFG
                                    250 	.globl _POWER_CFG
                                    251 	.globl _PCON
                                    252 	.globl _GLOBAL_CFG
                                    253 	.globl _SAFE_MOD
                                    254 	.globl _DPH
                                    255 	.globl _DPL
                                    256 	.globl _SP
                                    257 	.globl _A_INV
                                    258 	.globl _B
                                    259 	.globl _ACC
                                    260 	.globl _PSW
                                    261 	.globl _actual_keyboard_report
                                    262 	.globl _owned_usage_key_PARM_2
                                    263 	.globl _ak820_macro_change_PARM_3
                                    264 	.globl _ak820_macro_change_PARM_2
                                    265 	.globl _ak820_macro_cancelled
                                    266 	.globl _ak820_macro_primitive
                                    267 	.globl _ak820_gui_process_PARM_2
                                    268 	.globl _ak820_gui_process
                                    269 	.globl _ak820_macro_change
                                    270 	.globl _add_owned_mods
                                    271 	.globl _del_owned_mods
                                    272 	.globl _add_owned_weak_mods
                                    273 	.globl _del_owned_weak_mods
                                    274 	.globl _clear_owned_mods
                                    275 	.globl _clear_owned_keys
                                    276 	.globl _add_owned_key
                                    277 	.globl _del_owned_key
                                    278 	.globl _clear_owned_usages
                                    279 	.globl _owned_usage_key
                                    280 	.globl _send_keyboard_report
                                    281 	.globl _get_mods
                                    282 	.globl _clear_mods
                                    283 	.globl _get_weak_mods
                                    284 	.globl _add_weak_mods
                                    285 	.globl _del_weak_mods
                                    286 	.globl _clear_weak_mods
                                    287 ;--------------------------------------------------------
                                    288 ; special function registers
                                    289 ;--------------------------------------------------------
                                    290 	.area RSEG    (ABS,DATA)
      000000                        291 	.org 0x0000
                           0000D0   292 _PSW	=	0x00d0
                           0000E0   293 _ACC	=	0x00e0
                           0000F0   294 _B	=	0x00f0
                           0000FD   295 _A_INV	=	0x00fd
                           000081   296 _SP	=	0x0081
                           000082   297 _DPL	=	0x0082
                           000083   298 _DPH	=	0x0083
                           0000A1   299 _SAFE_MOD	=	0x00a1
                           0000B1   300 _GLOBAL_CFG	=	0x00b1
                           000087   301 _PCON	=	0x0087
                           0000BA   302 _POWER_CFG	=	0x00ba
                           0000B9   303 _CLOCK_CFG	=	0x00b9
                           0000A9   304 _WAKE_CTRL	=	0x00a9
                           0000FE   305 _RESET_KEEP	=	0x00fe
                           0000FF   306 _WDOG_COUNT	=	0x00ff
                           0000A8   307 _IE	=	0x00a8
                           0000B8   308 _IP	=	0x00b8
                           0000E8   309 _IE_EX	=	0x00e8
                           0000E9   310 _IP_EX	=	0x00e9
                           0000B2   311 _GPIO_IE	=	0x00b2
                           008584   312 _ROM_ADDR	=	0x8584
                           000084   313 _ROM_ADDR_L	=	0x0084
                           000085   314 _ROM_ADDR_H	=	0x0085
                           008F8E   315 _ROM_DATA_HI	=	0x8f8e
                           00008E   316 _ROM_DATA_HL	=	0x008e
                           00008F   317 _ROM_DATA_HH	=	0x008f
                           000086   318 _ROM_CTRL	=	0x0086
                           000080   319 _P0	=	0x0080
                           0000C4   320 _P0_MOD_OC	=	0x00c4
                           0000C5   321 _P0_DIR_PU	=	0x00c5
                           000090   322 _P1	=	0x0090
                           000092   323 _P1_MOD_OC	=	0x0092
                           000093   324 _P1_DIR_PU	=	0x0093
                           0000A0   325 _P2	=	0x00a0
                           000094   326 _P2_MOD_OC	=	0x0094
                           000095   327 _P2_DIR_PU	=	0x0095
                           0000B0   328 _P3	=	0x00b0
                           000096   329 _P3_MOD_OC	=	0x0096
                           000097   330 _P3_DIR_PU	=	0x0097
                           0000C0   331 _P4	=	0x00c0
                           0000C2   332 _P4_MOD_OC	=	0x00c2
                           0000C3   333 _P4_DIR_PU	=	0x00c3
                           0000C1   334 _P4_LED_KEY	=	0x00c1
                           0000AA   335 _P5_IN	=	0x00aa
                           0000AB   336 _P5_OUT_PU	=	0x00ab
                           0000AC   337 _P5_DIR	=	0x00ac
                           0000AD   338 _P6_IN	=	0x00ad
                           0000AE   339 _P6_OUT_PU	=	0x00ae
                           0000AF   340 _P6_DIR	=	0x00af
                           0000F1   341 _P7	=	0x00f1
                           0000A2   342 _XBUS_AUX	=	0x00a2
                           000088   343 _TCON	=	0x0088
                           000089   344 _TMOD	=	0x0089
                           00008A   345 _TL0	=	0x008a
                           00008B   346 _TL1	=	0x008b
                           00008C   347 _TH0	=	0x008c
                           00008D   348 _TH1	=	0x008d
                           000098   349 _SCON	=	0x0098
                           000099   350 _SBUF	=	0x0099
                           0000C8   351 _T2CON	=	0x00c8
                           0000C9   352 _T2MOD	=	0x00c9
                           00CBCA   353 _RCAP2	=	0xcbca
                           0000CA   354 _RCAP2L	=	0x00ca
                           0000CB   355 _RCAP2H	=	0x00cb
                           00CDCC   356 _T2COUNT	=	0xcdcc
                           0000CC   357 _TL2	=	0x00cc
                           0000CD   358 _TH2	=	0x00cd
                           00CFCE   359 _T2CAP1	=	0xcfce
                           0000CE   360 _T2CAP1L	=	0x00ce
                           0000CF   361 _T2CAP1H	=	0x00cf
                           0000F8   362 _SPI0_STAT	=	0x00f8
                           0000F9   363 _SPI0_DATA	=	0x00f9
                           0000FA   364 _SPI0_CTRL	=	0x00fa
                           0000FB   365 _SPI0_CK_SE	=	0x00fb
                           0000FC   366 _SPI0_SETUP	=	0x00fc
                           0000BC   367 _SCON1	=	0x00bc
                           0000BD   368 _SBUF1	=	0x00bd
                           0000BE   369 _SBAUD1	=	0x00be
                           0000BF   370 _SIF1	=	0x00bf
                           0000B4   371 _SPI1_STAT	=	0x00b4
                           0000B5   372 _SPI1_DATA	=	0x00b5
                           0000B6   373 _SPI1_CTRL	=	0x00b6
                           0000B7   374 _SPI1_CK_SE	=	0x00b7
                           0000F3   375 _ADC_CTRL	=	0x00f3
                           00F5F4   376 _ADC_DAT	=	0xf5f4
                           0000F4   377 _ADC_DAT_L	=	0x00f4
                           0000F5   378 _ADC_DAT_H	=	0x00f5
                           0000F6   379 _ADC_CHAN	=	0x00f6
                           0000A6   380 _LED_COMMON	=	0x00a6
                           0000A7   381 _LED_PWM_OE	=	0x00a7
                           00C7C6   382 _LED_DMA	=	0xc7c6
                           0000C6   383 _LED_DMA_L	=	0x00c6
                           0000C7   384 _LED_DMA_H	=	0x00c7
                           0000F7   385 _LED_STATUS	=	0x00f7
                           0000B3   386 _I2CX_INT	=	0x00b3
                           0000BB   387 _I2CS_INT_ST	=	0x00bb
                                    388 ;--------------------------------------------------------
                                    389 ; special function bits
                                    390 ;--------------------------------------------------------
                                    391 	.area RSEG    (ABS,DATA)
      000000                        392 	.org 0x0000
                           0000D7   393 _CY	=	0x00d7
                           0000D6   394 _AC	=	0x00d6
                           0000D5   395 _F0	=	0x00d5
                           0000D4   396 _RS1	=	0x00d4
                           0000D3   397 _RS0	=	0x00d3
                           0000D2   398 _OV	=	0x00d2
                           0000D1   399 _F1	=	0x00d1
                           0000D0   400 _P	=	0x00d0
                           0000AF   401 _EA	=	0x00af
                           0000AE   402 _E_DIS	=	0x00ae
                           0000AD   403 _ET2	=	0x00ad
                           0000AC   404 _ES	=	0x00ac
                           0000AB   405 _ET1	=	0x00ab
                           0000AA   406 _EX1	=	0x00aa
                           0000A9   407 _ET0	=	0x00a9
                           0000A8   408 _EX0	=	0x00a8
                           0000BF   409 _PH_FLAG	=	0x00bf
                           0000BE   410 _PL_FLAG	=	0x00be
                           0000BD   411 _PT2	=	0x00bd
                           0000BC   412 _PS	=	0x00bc
                           0000BB   413 _PT1	=	0x00bb
                           0000BA   414 _PX1	=	0x00ba
                           0000B9   415 _PT0	=	0x00b9
                           0000B8   416 _PX0	=	0x00b8
                           0000EF   417 _IE_WDOG	=	0x00ef
                           0000EE   418 _IE_GPIO	=	0x00ee
                           0000ED   419 _IE_PWM_I2C	=	0x00ed
                           0000EC   420 _IE_UART1	=	0x00ec
                           0000EB   421 _IE_ADC	=	0x00eb
                           0000E9   422 _IE_USB	=	0x00e9
                           0000E8   423 _IE_SPI0	=	0x00e8
                           000087   424 _P0_7	=	0x0087
                           000086   425 _P0_6	=	0x0086
                           000085   426 _P0_5	=	0x0085
                           000084   427 _P0_4	=	0x0084
                           000083   428 _P0_3	=	0x0083
                           000082   429 _P0_2	=	0x0082
                           000081   430 _P0_1	=	0x0081
                           000080   431 _P0_0	=	0x0080
                           000081   432 _SDA0	=	0x0081
                           000080   433 _SCL0	=	0x0080
                           000083   434 _TXD_	=	0x0083
                           000082   435 _RXD_	=	0x0082
                           000085   436 _AIN13	=	0x0085
                           000084   437 _AIN12	=	0x0084
                           000083   438 _AIN11	=	0x0083
                           000082   439 _AIN10	=	0x0082
                           000081   440 _AIN9	=	0x0081
                           000080   441 _AIN8	=	0x0080
                           000097   442 _P1_7	=	0x0097
                           000096   443 _P1_6	=	0x0096
                           000095   444 _P1_5	=	0x0095
                           000094   445 _P1_4	=	0x0094
                           000093   446 _P1_3	=	0x0093
                           000092   447 _P1_2	=	0x0092
                           000091   448 _P1_1	=	0x0091
                           000090   449 _P1_0	=	0x0090
                           000097   450 _TXD1_	=	0x0097
                           000096   451 _RXD1_	=	0x0096
                           000097   452 _SCK	=	0x0097
                           000096   453 _MISO	=	0x0096
                           000095   454 _MOSI	=	0x0095
                           000094   455 _SCS	=	0x0094
                           000092   456 _INT0_	=	0x0092
                           000091   457 _T2EX	=	0x0091
                           000091   458 _CAP2	=	0x0091
                           000090   459 _T2	=	0x0090
                           000090   460 _CAP1	=	0x0090
                           000097   461 _AIN7	=	0x0097
                           000096   462 _AIN6	=	0x0096
                           000095   463 _AIN5	=	0x0095
                           000094   464 _AIN4	=	0x0094
                           000093   465 _AIN3	=	0x0093
                           000092   466 _AIN2	=	0x0092
                           000091   467 _AIN1	=	0x0091
                           000090   468 _AIN0	=	0x0090
                           0000A7   469 _P2_7	=	0x00a7
                           0000A6   470 _P2_6	=	0x00a6
                           0000A5   471 _P2_5	=	0x00a5
                           0000A4   472 _P2_4	=	0x00a4
                           0000A3   473 _P2_3	=	0x00a3
                           0000A2   474 _P2_2	=	0x00a2
                           0000A1   475 _P2_1	=	0x00a1
                           0000A0   476 _P2_0	=	0x00a0
                           0000A7   477 _TXD1	=	0x00a7
                           0000A6   478 _RXD1	=	0x00a6
                           0000A5   479 _T2EX_	=	0x00a5
                           0000A5   480 _CAP2_	=	0x00a5
                           0000A4   481 _T2_	=	0x00a4
                           0000A4   482 _CAP1_	=	0x00a4
                           0000B7   483 _P3_7	=	0x00b7
                           0000B6   484 _P3_6	=	0x00b6
                           0000B5   485 _P3_5	=	0x00b5
                           0000B4   486 _P3_4	=	0x00b4
                           0000B3   487 _P3_3	=	0x00b3
                           0000B2   488 _P3_2	=	0x00b2
                           0000B1   489 _P3_1	=	0x00b1
                           0000B0   490 _P3_0	=	0x00b0
                           0000B7   491 _SCK1	=	0x00b7
                           0000B6   492 _MISO1	=	0x00b6
                           0000B5   493 _MOSI1	=	0x00b5
                           0000B5   494 _T1	=	0x00b5
                           0000B4   495 _T0	=	0x00b4
                           0000B3   496 _INT1	=	0x00b3
                           0000B2   497 _INT0	=	0x00b2
                           0000B1   498 _TXD	=	0x00b1
                           0000B0   499 _RXD	=	0x00b0
                           0000C6   500 _P4_6	=	0x00c6
                           0000C5   501 _P4_5	=	0x00c5
                           0000C4   502 _P4_4	=	0x00c4
                           0000C3   503 _P4_3	=	0x00c3
                           0000C2   504 _P4_2	=	0x00c2
                           0000C1   505 _P4_1	=	0x00c1
                           0000C0   506 _P4_0	=	0x00c0
                           00008F   507 _TF1	=	0x008f
                           00008E   508 _TR1	=	0x008e
                           00008D   509 _TF0	=	0x008d
                           00008C   510 _TR0	=	0x008c
                           00008B   511 _IE1	=	0x008b
                           00008A   512 _IT1	=	0x008a
                           000089   513 _IE0	=	0x0089
                           000088   514 _IT0	=	0x0088
                           00009F   515 _SM0	=	0x009f
                           00009E   516 _SM1	=	0x009e
                           00009D   517 _SM2	=	0x009d
                           00009C   518 _REN	=	0x009c
                           00009B   519 _TB8	=	0x009b
                           00009A   520 _RB8	=	0x009a
                           000099   521 _TI	=	0x0099
                           000098   522 _RI	=	0x0098
                           0000CF   523 _TF2	=	0x00cf
                           0000CF   524 _CAP1F	=	0x00cf
                           0000CE   525 _EXF2	=	0x00ce
                           0000CD   526 _RCLK	=	0x00cd
                           0000CC   527 _TCLK	=	0x00cc
                           0000CB   528 _EXEN2	=	0x00cb
                           0000CA   529 _TR2	=	0x00ca
                           0000C9   530 _C_T2	=	0x00c9
                           0000C8   531 _CP_RL2	=	0x00c8
                           0000FF   532 _S0_FST_ACT	=	0x00ff
                           0000FE   533 _S0_IF_OV	=	0x00fe
                           0000FD   534 _S0_IF_FIRST	=	0x00fd
                           0000FC   535 _S0_IF_BYTE	=	0x00fc
                           0000FB   536 _S0_FREE	=	0x00fb
                           0000FA   537 _S0_T_FIFO	=	0x00fa
                           0000F8   538 _S0_R_FIFO	=	0x00f8
                           0000F7   539 _ADC_START	=	0x00f7
                                    540 ;--------------------------------------------------------
                                    541 ; overlayable register banks
                                    542 ;--------------------------------------------------------
                                    543 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        544 	.ds 8
                                    545 ;--------------------------------------------------------
                                    546 ; internal ram data
                                    547 ;--------------------------------------------------------
                                    548 	.area DSEG    (DATA)
                                    549 ;--------------------------------------------------------
                                    550 ; overlayable items in internal ram
                                    551 ;--------------------------------------------------------
                                    552 	.area	OSEG    (OVR,DATA)
      000054                        553 _change_owned_sloc1_1_0:
      000054                        554 	.ds 1
                                    555 ;--------------------------------------------------------
                                    556 ; indirectly addressable internal ram data
                                    557 ;--------------------------------------------------------
                                    558 	.area ISEG    (DATA)
                                    559 ;--------------------------------------------------------
                                    560 ; absolute internal ram data
                                    561 ;--------------------------------------------------------
                                    562 	.area IABS    (ABS,DATA)
                                    563 	.area IABS    (ABS,DATA)
                                    564 ;--------------------------------------------------------
                                    565 ; bit data
                                    566 ;--------------------------------------------------------
                                    567 	.area BSEG    (BIT)
      000021                        568 _gui_disabled:
      000021                        569 	.ds 1
      000022                        570 _ak820_gui_process_sloc0_1_0:
      000022                        571 	.ds 1
      000023                        572 _ak820_macro_change_sloc0_1_0:
      000023                        573 	.ds 1
      000024                        574 _change_owned_sloc0_1_0:
      000024                        575 	.ds 1
      000025                        576 _owned_usage_key_sloc0_1_0:
      000025                        577 	.ds 1
                                    578 ;--------------------------------------------------------
                                    579 ; paged external ram data
                                    580 ;--------------------------------------------------------
                                    581 	.area PSEG    (PAG,XDATA)
                                    582 ;--------------------------------------------------------
                                    583 ; uninitialized external ram data
                                    584 ;--------------------------------------------------------
                                    585 	.area XSEG    (XDATA)
      0009A4                        586 _ak820_gui_process_PARM_2:
      0009A4                        587 	.ds 1
      0009A5                        588 _ak820_gui_process_code_10000_295:
      0009A5                        589 	.ds 2
      0009A7                        590 _owned_mod_refs:
      0009A7                        591 	.ds 8
      0009AF                        592 _owned_weak_refs:
      0009AF                        593 	.ds 8
      0009B7                        594 _owned_mods:
      0009B7                        595 	.ds 1
      0009B8                        596 _owned_weak_mods:
      0009B8                        597 	.ds 1
      0009B9                        598 _macro_mods:
      0009B9                        599 	.ds 2
      0009BB                        600 _ak820_macro_primitive::
      0009BB                        601 	.ds 1
      0009BC                        602 _ak820_macro_cancelled::
      0009BC                        603 	.ds 1
      0009BD                        604 _ak820_macro_change_PARM_2:
      0009BD                        605 	.ds 1
      0009BE                        606 _ak820_macro_change_PARM_3:
      0009BE                        607 	.ds 1
      0009BF                        608 _ak820_macro_change_bits_10000_300:
      0009BF                        609 	.ds 2
      0009C1                        610 _change_owned_PARM_2:
      0009C1                        611 	.ds 1
      0009C2                        612 _change_owned_mods_10000_305:
      0009C2                        613 	.ds 1
      0009C3                        614 _change_owned_result_10001_309:
      0009C3                        615 	.ds 1
      0009C4                        616 _change_owned_bit_20001_310:
      0009C4                        617 	.ds 1
      0009C5                        618 _add_owned_mods_mods_10000_318:
      0009C5                        619 	.ds 1
      0009C6                        620 _del_owned_mods_mods_10000_320:
      0009C6                        621 	.ds 1
      0009C7                        622 _add_owned_weak_mods_mods_10000_322:
      0009C7                        623 	.ds 1
      0009C8                        624 _del_owned_weak_mods_mods_10000_324:
      0009C8                        625 	.ds 1
      0009C9                        626 _key_refs:
      0009C9                        627 	.ds 165
      000A6E                        628 _distinct_keys:
      000A6E                        629 	.ds 1
      000A6F                        630 _macro_keys:
      000A6F                        631 	.ds 21
      000A84                        632 _add_owned_key_code_10000_333:
      000A84                        633 	.ds 1
      000A85                        634 _del_owned_key_code_10000_348:
      000A85                        635 	.ds 1
      000A86                        636 _usage_refs:
      000A86                        637 	.ds 30
      000AA4                        638 _usage_order:
      000AA4                        639 	.ds 30
      000AC2                        640 _usage_lengths:
      000AC2                        641 	.ds 2
      000AC4                        642 _macro_usages:
      000AC4                        643 	.ds 4
      000AC8                        644 _owned_usage_key_PARM_2:
      000AC8                        645 	.ds 1
      000AC9                        646 _owned_usage_key_code_10000_375:
      000AC9                        647 	.ds 1
      000ACA                        648 _owned_usage_key___200000085_20000_376:
      000ACA                        649 	.ds 2
      000ACC                        650 _owned_usage_key_which_10000_376:
      000ACC                        651 	.ds 1
      000ACD                        652 _owned_usage_key_count_10000_376:
      000ACD                        653 	.ds 1
      000ACE                        654 _owned_usage_key_pos_30001_383:
      000ACE                        655 	.ds 1
      000ACF                        656 _owned_usage_key_key_40000_388:
      000ACF                        657 	.ds 1
      000AD0                        658 _send_keyboard_report_last_report_10001_396:
      000AD0                        659 	.ds 32
      000AF0                        660 _send_keyboard_report_changed_10001_396:
      000AF0                        661 	.ds 1
      000AF1                        662 _add_weak_mods_mods_10000_414:
      000AF1                        663 	.ds 1
      000AF2                        664 _del_weak_mods_mods_10000_416:
      000AF2                        665 	.ds 1
                                    666 ;--------------------------------------------------------
                                    667 ; absolute external ram data
                                    668 ;--------------------------------------------------------
                                    669 	.area XABS    (ABS,XDATA)
                                    670 ;--------------------------------------------------------
                                    671 ; initialized external ram data
                                    672 ;--------------------------------------------------------
                                    673 	.area XISEG   (XDATA)
      000DF9                        674 _real_mods:
      000DF9                        675 	.ds 1
      000DFA                        676 _weak_mods:
      000DFA                        677 	.ds 1
      000DFB                        678 _actual_keyboard_report::
      000DFB                        679 	.ds 32
                                    680 	.area HOME    (CODE)
                                    681 	.area GSINIT0 (CODE)
                                    682 	.area GSINIT1 (CODE)
                                    683 	.area GSINIT2 (CODE)
                                    684 	.area GSINIT3 (CODE)
                                    685 	.area GSINIT4 (CODE)
                                    686 	.area GSINIT5 (CODE)
                                    687 	.area GSINIT  (CODE)
                                    688 	.area GSFINAL (CODE)
                                    689 	.area CSEG    (CODE)
                                    690 ;--------------------------------------------------------
                                    691 ; global & static initialisations
                                    692 ;--------------------------------------------------------
                                    693 	.area HOME    (CODE)
                                    694 	.area GSINIT  (CODE)
                                    695 	.area GSFINAL (CODE)
                                    696 	.area GSINIT  (CODE)
                                    697 ;--------------------------------------------------------
                                    698 ; Home
                                    699 ;--------------------------------------------------------
                                    700 	.area HOME    (CODE)
                                    701 	.area HOME    (CODE)
                                    702 ;--------------------------------------------------------
                                    703 ; code
                                    704 ;--------------------------------------------------------
                                    705 	.area CSEG    (CODE)
                                    706 ;------------------------------------------------------------
                                    707 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    708 ;------------------------------------------------------------
                                    709 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    710 ;------------------------------------------------------------
                                    711 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    712 ;	-----------------------------------------
                           000007   713 	ar7 = 0x07
                           000006   714 	ar6 = 0x06
                           000005   715 	ar5 = 0x05
                           000004   716 	ar4 = 0x04
                           000003   717 	ar3 = 0x03
                           000002   718 	ar2 = 0x02
                           000001   719 	ar1 = 0x01
                           000000   720 	ar0 = 0x00
                                    721 ;	 function ak820_gui_process
                                    722 ;	-----------------------------------------
      00807A                        723 _ak820_gui_process:
      00807A 12 3A C2         [24]  724 	lcall	_ak820_outline_0109
      00807D 90 09 A5         [24]  725 	mov	dptr,#_ak820_gui_process_code_10000_295
      008080 12 3A C7         [24]  726 	lcall	_ak820_outline_0110
                                    727 ;	quantum/action_util.c:60: if (code < QK_MAGIC_GUI_ON || code > QK_MAGIC_TOGGLE_GUI) return true;
      008083 90 09 A5         [24]  728 	mov	dptr,#_ak820_gui_process_code_10000_295
      008086 12 3A 81         [24]  729 	lcall	_ak820_outline_0052
      008089 C3               [12]  730 	clr	c
      00808A EE               [12]  731 	mov	a,r6
      00808B 94 09            [12]  732 	subb	a,#0x09
      00808D EF               [12]  733 	mov	a,r7
      00808E 94 70            [12]  734 	subb	a,#0x70
      008090 40 08            [24]  735 	jc	00101$
      008092 74 0B            [12]  736 	mov	a,#0x0b
      008094 9E               [12]  737 	subb	a,r6
      008095 74 70            [12]  738 	mov	a,#0x70
      008097 9F               [12]  739 	subb	a,r7
      008098 50 04            [24]  740 	jnc	00102$
                                    741 ;	free result
      00809A                        742 00101$:
      00809A 75 82 01         [24]  743 	mov	dpl, #0x01
      00809D 22               [24]  744 	ret
      00809E                        745 00102$:
                                    746 ;	quantum/action_util.c:61: if (pressed) {
      00809E 90 09 A4         [24]  747 	mov	dptr,#_ak820_gui_process_PARM_2
      0080A1 E0               [24]  748 	movx	a,@dptr
      0080A2 60 20            [24]  749 	jz	00105$
                                    750 ;	quantum/action_util.c:62: gui_disabled = code == QK_MAGIC_TOGGLE_GUI ? !gui_disabled : code == QK_MAGIC_GUI_OFF;
      0080A4 BE 0B 0D         [24]  751 	cjne	r6,#0x0b,00108$
      0080A7 BF 70 0A         [24]  752 	cjne	r7,#0x70,00108$
      0080AA A2 21            [12]  753 	mov	c,_gui_disabled
      0080AC B3               [12]  754 	cpl	c
      0080AD 92 22            [24]  755 	mov  _ak820_gui_process_sloc0_1_0,c
      0080AF E4               [12]  756 	clr	a
      0080B0 33               [12]  757 	rlc	a
      0080B1 FD               [12]  758 	mov	r5,a
      0080B2 80 09            [24]  759 	sjmp	00109$
      0080B4                        760 00108$:
      0080B4 E4               [12]  761 	clr	a
      0080B5 BE 0A 04         [24]  762 	cjne	r6,#0x0a,00136$
      0080B8 BF 70 01         [24]  763 	cjne	r7,#0x70,00136$
      0080BB 04               [12]  764 	inc	a
      0080BC                        765 00136$:
      0080BC FD               [12]  766 	mov	r5,a
      0080BD                        767 00109$:
                                    768 ;	assignBit
      0080BD ED               [12]  769 	mov	a,r5
      0080BE 24 FF            [12]  770 	add	a,#0xff
      0080C0 92 21            [24]  771 	mov	_gui_disabled,c
                                    772 ;	quantum/action_util.c:63: send_keyboard_report();
      0080C2 B1 3F            [12]  773 	acall	_send_keyboard_report
      0080C4                        774 00105$:
                                    775 ;	quantum/action_util.c:65: return false;
      0080C4 75 82 00         [24]  776 	mov	dpl, #0x00
                                    777 ;	quantum/action_util.c:69: }
      0080C7 22               [24]  778 	ret
                                    779 ;------------------------------------------------------------
                                    780 ;Allocation info for local variables in function 'ak820_macro_change'
                                    781 ;------------------------------------------------------------
                                    782 ;index         Allocated with name '_ak820_macro_change_PARM_2'
                                    783 ;pressed       Allocated with name '_ak820_macro_change_PARM_3'
                                    784 ;bits          Allocated with name '_ak820_macro_change_bits_10000_300'
                                    785 ;mask          Allocated with name '_ak820_macro_change_mask_10001_303'
                                    786 ;------------------------------------------------------------
                                    787 ;	quantum/action_util.c:78: bool ak820_macro_change(uint8_t AK820_STATE_MEM *bits, uint8_t index, bool pressed) {
                                    788 ;	-----------------------------------------
                                    789 ;	 function ak820_macro_change
                                    790 ;	-----------------------------------------
      0080C8                        791 _ak820_macro_change:
      0080C8 12 3A C2         [24]  792 	lcall	_ak820_outline_0109
      0080CB 90 09 BF         [24]  793 	mov	dptr,#_ak820_macro_change_bits_10000_300
      0080CE 12 3A C7         [24]  794 	lcall	_ak820_outline_0110
                                    795 ;	quantum/action_util.c:79: if (!ak820_macro_primitive) return true;
      0080D1 90 09 BB         [24]  796 	mov	dptr,#_ak820_macro_primitive
      0080D4 E0               [24]  797 	movx	a,@dptr
      0080D5 70 04            [24]  798 	jnz	00102$
      0080D7 75 82 01         [24]  799 	mov	dpl, #0x01
      0080DA 22               [24]  800 	ret
      0080DB                        801 00102$:
                                    802 ;	quantum/action_util.c:80: uint8_t mask = 1u << (index & 7);
      0080DB 90 09 BD         [24]  803 	mov	dptr,#_ak820_macro_change_PARM_2
      0080DE E0               [24]  804 	movx	a,@dptr
      0080DF FF               [12]  805 	mov	r7,a
      0080E0 74 07            [12]  806 	mov	a,#0x07
      0080E2 5F               [12]  807 	anl	a,r7
      0080E3 12 7C 20         [24]  808 	lcall	_ak820_outline_0063
      0080E6 80 02            [24]  809 	sjmp	00123$
      0080E8                        810 00122$:
      0080E8 25 E0            [12]  811 	add	a,acc
      0080EA                        812 00123$:
      0080EA D5 F0 FB         [24]  813 	djnz	b,00122$
      0080ED FE               [12]  814 	mov	r6,a
                                    815 ;	quantum/action_util.c:81: bits += index >> 3;
      0080EE EF               [12]  816 	mov	a,r7
      0080EF 12 5B FC         [24]  817 	lcall	_ak820_outline_0190
      0080F2 FF               [12]  818 	mov	r7,a
      0080F3 90 09 BF         [24]  819 	mov	dptr,#_ak820_macro_change_bits_10000_300
      0080F6 12 3A 98         [24]  820 	lcall	_ak820_outline_0061
      0080F9 90 09 BF         [24]  821 	mov	dptr,#_ak820_macro_change_bits_10000_300
      0080FC EF               [12]  822 	mov	a,r7
      0080FD 2C               [12]  823 	add	a, r4
      0080FE F0               [24]  824 	movx	@dptr,a
      0080FF E4               [12]  825 	clr	a
      008100 3D               [12]  826 	addc	a, r5
      008101 A3               [24]  827 	inc	dptr
      008102 F0               [24]  828 	movx	@dptr,a
                                    829 ;	quantum/action_util.c:82: if (((*bits & mask) != 0) == pressed) return false;
      008103 90 09 BF         [24]  830 	mov	dptr,#_ak820_macro_change_bits_10000_300
      008106 E0               [24]  831 	movx	a,@dptr
      008107 FD               [12]  832 	mov	r5,a
      008108 A3               [24]  833 	inc	dptr
      008109 E0               [24]  834 	movx	a,@dptr
      00810A FF               [12]  835 	mov	r7,a
      00810B 12 86 57         [24]  836 	lcall	_ak820_outline_0192
      00810E E0               [24]  837 	movx	a,@dptr
      00810F FC               [12]  838 	mov	r4,a
      008110 EE               [12]  839 	mov	a,r6
      008111 5C               [12]  840 	anl	a,r4
      008112 B4 01 00         [24]  841 	cjne	a,#0x01,00124$
      008115                        842 00124$:
      008115 B3               [12]  843 	cpl	c
      008116 92 23            [24]  844 	mov	_ak820_macro_change_sloc0_1_0,c
      008118 90 09 BE         [24]  845 	mov	dptr,#_ak820_macro_change_PARM_3
      00811B E0               [24]  846 	movx	a,@dptr
      00811C FB               [12]  847 	mov	r3,a
      00811D A2 23            [12]  848 	mov	c,_ak820_macro_change_sloc0_1_0
      00811F E4               [12]  849 	clr	a
      008120 33               [12]  850 	rlc	a
      008121 B5 03 04         [24]  851 	cjne	a,ar3,00104$
      008124 75 82 00         [24]  852 	mov	dpl, #0x00
      008127 22               [24]  853 	ret
      008128                        854 00104$:
                                    855 ;	quantum/action_util.c:83: *bits ^= mask;
      008128 EC               [12]  856 	mov	a,r4
      008129 62 06            [12]  857 	xrl	ar6,a
      00812B 12 86 57         [24]  858 	lcall	_ak820_outline_0192
      00812E EE               [12]  859 	mov	a,r6
      00812F F0               [24]  860 	movx	@dptr,a
                                    861 ;	quantum/action_util.c:84: return true;
      008130 75 82 01         [24]  862 	mov	dpl, #0x01
                                    863 ;	quantum/action_util.c:85: }
      008133 22               [24]  864 	ret
                                    865 ;------------------------------------------------------------
                                    866 ;Allocation info for local variables in function 'change_owned'
                                    867 ;------------------------------------------------------------
                                    868 ;mode          Allocated with name '_change_owned_PARM_2'
                                    869 ;mods          Allocated with name '_change_owned_mods_10000_305'
                                    870 ;kind          Allocated with name '_change_owned_kind_10000_306'
                                    871 ;pressed       Allocated with name '_change_owned_pressed_10000_306'
                                    872 ;refs          Allocated with name '_change_owned_refs_10000_306'
                                    873 ;old           Allocated with name '_change_owned_old_30000_308'
                                    874 ;result        Allocated with name '_change_owned_result_10001_309'
                                    875 ;i             Allocated with name '_change_owned_i_20001_310'
                                    876 ;bit           Allocated with name '_change_owned_bit_20001_310'
                                    877 ;sloc1         Allocated with name '_change_owned_sloc1_1_0'
                                    878 ;------------------------------------------------------------
                                    879 ;	quantum/action_util.c:86: static void change_owned(uint8_t mods, uint8_t mode) {
                                    880 ;	-----------------------------------------
                                    881 ;	 function change_owned
                                    882 ;	-----------------------------------------
      008134                        883 _change_owned:
      008134 E5 82            [12]  884 	mov	a,dpl
      008136 90 09 C2         [24]  885 	mov	dptr,#_change_owned_mods_10000_305
      008139 F0               [24]  886 	movx	@dptr,a
                                    887 ;	quantum/action_util.c:87: uint8_t kind = mode >> 1;
      00813A 90 09 C1         [24]  888 	mov	dptr,#_change_owned_PARM_2
      00813D E0               [24]  889 	movx	a,@dptr
      00813E FF               [12]  890 	mov	r7,a
      00813F C3               [12]  891 	clr	c
      008140 13               [12]  892 	rrc	a
      008141 FE               [12]  893 	mov	r6,a
                                    894 ;	quantum/action_util.c:88: bool pressed = (mode & 1) != 0;
      008142 53 07 01         [24]  895 	anl	ar7,#0x01
      008145 EF               [12]  896 	mov	a,r7
      008146 B4 01 00         [24]  897 	cjne	a,#0x01,00205$
      008149                        898 00205$:
      008149 92 24            [24]  899 	mov  _change_owned_sloc0_1_0,c
      00814B B3               [12]  900 	cpl	c
      00814C E4               [12]  901 	clr	a
      00814D 33               [12]  902 	rlc	a
      00814E F5 54            [12]  903 	mov	_change_owned_sloc1_1_0,a
                                    904 ;	quantum/action_util.c:89: uint8_t AK820_STATE_MEM *refs = kind ? owned_weak_refs : owned_mod_refs;
      008150 EE               [12]  905 	mov	a,r6
      008151 60 06            [24]  906 	jz	00121$
      008153 7D AF            [12]  907 	mov	r5,#_owned_weak_refs
      008155 7F 09            [12]  908 	mov	r7,#(_owned_weak_refs >> 8)
      008157 80 04            [24]  909 	sjmp	00122$
      008159                        910 00121$:
      008159 7D A7            [12]  911 	mov	r5,#_owned_mod_refs
      00815B 7F 09            [12]  912 	mov	r7,#(_owned_mod_refs >> 8)
      00815D                        913 00122$:
                                    914 ;	quantum/action_util.c:90: if (ak820_macro_primitive) {
      00815D 90 09 BB         [24]  915 	mov	dptr,#_ak820_macro_primitive
      008160 E0               [24]  916 	movx	a,@dptr
      008161 60 37            [24]  917 	jz	00102$
                                    918 ;	quantum/action_util.c:91: uint8_t old = macro_mods[kind];
      008163 EE               [12]  919 	mov	a,r6
      008164 24 B9            [12]  920 	add	a, #_macro_mods
      008166 FB               [12]  921 	mov	r3,a
      008167 E4               [12]  922 	clr	a
      008168 34 09            [12]  923 	addc	a, #(_macro_mods >> 8)
      00816A FC               [12]  924 	mov	r4,a
      00816B 12 4A D1         [24]  925 	lcall	_ak820_outline_0065
                                    926 ;	quantum/action_util.c:92: macro_mods[kind] = pressed ? old | mods : old & ~mods;
      00816E E5 54            [12]  927 	mov	a,_change_owned_sloc1_1_0
      008170 60 0A            [24]  928 	jz	00123$
      008172 90 09 C2         [24]  929 	mov	dptr,#_change_owned_mods_10000_305
      008175 E0               [24]  930 	movx	a,@dptr
      008176 F9               [12]  931 	mov	r1,a
      008177 EA               [12]  932 	mov	a,r2
      008178 42 01            [12]  933 	orl	ar1,a
      00817A 80 07            [24]  934 	sjmp	00124$
      00817C                        935 00123$:
      00817C 90 09 C2         [24]  936 	mov	dptr,#_change_owned_mods_10000_305
      00817F E0               [24]  937 	movx	a,@dptr
      008180 F4               [12]  938 	cpl	a
      008181 5A               [12]  939 	anl	a,r2
      008182 F9               [12]  940 	mov	r1,a
      008183                        941 00124$:
      008183 12 36 47         [24]  942 	lcall	_ak820_outline_0125
      008186 E9               [12]  943 	mov	a,r1
      008187 F0               [24]  944 	movx	@dptr,a
                                    945 ;	quantum/action_util.c:93: mods &= pressed ? ~old : old;
      008188 E5 54            [12]  946 	mov	a,_change_owned_sloc1_1_0
      00818A 60 06            [24]  947 	jz	00125$
      00818C 74 FF            [12]  948 	mov	a,#0xff
      00818E 6A               [12]  949 	xrl	a,r2
      00818F FC               [12]  950 	mov	r4,a
      008190 80 02            [24]  951 	sjmp	00126$
      008192                        952 00125$:
      008192 8A 04            [24]  953 	mov	ar4,r2
      008194                        954 00126$:
      008194 90 09 C2         [24]  955 	mov	dptr,#_change_owned_mods_10000_305
      008197 E0               [24]  956 	movx	a,@dptr
      008198 5C               [12]  957 	anl	a,r4
      008199 F0               [24]  958 	movx	@dptr,a
      00819A                        959 00102$:
                                    960 ;	quantum/action_util.c:95: uint8_t result = 0;
      00819A 90 09 C3         [24]  961 	mov	dptr,#_change_owned_result_10001_309
      00819D E4               [12]  962 	clr	a
      00819E F0               [24]  963 	movx	@dptr,a
                                    964 ;	quantum/action_util.c:96: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      00819F 90 09 C4         [24]  965 	mov	dptr,#_change_owned_bit_20001_310
      0081A2 04               [12]  966 	inc	a
      0081A3 F0               [24]  967 	movx	@dptr,a
      0081A4 90 09 C2         [24]  968 	mov	dptr,#_change_owned_mods_10000_305
      0081A7 E0               [24]  969 	movx	a,@dptr
      0081A8 FC               [12]  970 	mov	r4,a
      0081A9 7B 00            [12]  971 	mov	r3,#0x00
      0081AB                        972 00117$:
      0081AB BB 08 00         [24]  973 	cjne	r3,#0x08,00210$
      0081AE                        974 00210$:
      0081AE 50 3F            [24]  975 	jnc	00112$
                                    976 ;	quantum/action_util.c:97: if (mods & bit) {
      0081B0 90 09 C4         [24]  977 	mov	dptr,#_change_owned_bit_20001_310
      0081B3 E0               [24]  978 	movx	a,@dptr
      0081B4 5C               [12]  979 	anl	a,r4
      0081B5 60 1C            [24]  980 	jz	00109$
                                    981 ;	quantum/action_util.c:98: if (pressed) ++refs[i];
      0081B7 E5 54            [12]  982 	mov	a,_change_owned_sloc1_1_0
      0081B9 60 0C            [24]  983 	jz	00106$
      0081BB EB               [12]  984 	mov	a,r3
      0081BC 2D               [12]  985 	add	a, r5
      0081BD 12 3A 67         [24]  986 	lcall	_ak820_outline_0017
      0081C0 F8               [12]  987 	mov	r0,a
      0081C1 08               [12]  988 	inc	r0
      0081C2 12 86 14         [24]  989 	lcall	_ak820_outline_0064
      0081C5 80 0C            [24]  990 	sjmp	00109$
      0081C7                        991 00106$:
                                    992 ;	quantum/action_util.c:99: else if (refs[i]) --refs[i];
      0081C7 EB               [12]  993 	mov	a,r3
      0081C8 2D               [12]  994 	add	a, r5
      0081C9 12 3A 67         [24]  995 	lcall	_ak820_outline_0017
      0081CC F8               [12]  996 	mov	r0,a
      0081CD 60 04            [24]  997 	jz	00109$
      0081CF 18               [12]  998 	dec	r0
      0081D0 12 86 14         [24]  999 	lcall	_ak820_outline_0064
      0081D3                       1000 00109$:
                                   1001 ;	quantum/action_util.c:101: if (refs[i]) result |= bit;
      0081D3 EB               [12] 1002 	mov	a,r3
      0081D4 2D               [12] 1003 	add	a, r5
      0081D5 12 3A 67         [24] 1004 	lcall	_ak820_outline_0017
      0081D8 60 0B            [24] 1005 	jz	00118$
      0081DA 90 09 C4         [24] 1006 	mov	dptr,#_change_owned_bit_20001_310
      0081DD E0               [24] 1007 	movx	a,@dptr
      0081DE FA               [12] 1008 	mov	r2,a
      0081DF 90 09 C3         [24] 1009 	mov	dptr,#_change_owned_result_10001_309
      0081E2 E0               [24] 1010 	movx	a,@dptr
      0081E3 4A               [12] 1011 	orl	a,r2
      0081E4 F0               [24] 1012 	movx	@dptr,a
      0081E5                       1013 00118$:
                                   1014 ;	quantum/action_util.c:96: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      0081E5 0B               [12] 1015 	inc	r3
      0081E6 90 09 C4         [24] 1016 	mov	dptr,#_change_owned_bit_20001_310
      0081E9 E0               [24] 1017 	movx	a,@dptr
      0081EA 25 E0            [12] 1018 	add	a,acc
      0081EC F0               [24] 1019 	movx	@dptr,a
      0081ED 80 BC            [24] 1020 	sjmp	00117$
      0081EF                       1021 00112$:
                                   1022 ;	quantum/action_util.c:103: if (kind) owned_weak_mods = result;
      0081EF EE               [12] 1023 	mov	a,r6
      0081F0 60 09            [24] 1024 	jz	00114$
      0081F2 90 09 C3         [24] 1025 	mov	dptr,#_change_owned_result_10001_309
      0081F5 E0               [24] 1026 	movx	a,@dptr
      0081F6 90 09 B8         [24] 1027 	mov	dptr,#_owned_weak_mods
      0081F9 F0               [24] 1028 	movx	@dptr,a
      0081FA 22               [24] 1029 	ret
      0081FB                       1030 00114$:
                                   1031 ;	quantum/action_util.c:104: else owned_mods = result;
      0081FB 90 09 C3         [24] 1032 	mov	dptr,#_change_owned_result_10001_309
      0081FE E0               [24] 1033 	movx	a,@dptr
      0081FF 90 09 B7         [24] 1034 	mov	dptr,#_owned_mods
      008202 F0               [24] 1035 	movx	@dptr,a
                                   1036 ;	quantum/action_util.c:105: }
      008203 22               [24] 1037 	ret
                                   1038 ;------------------------------------------------------------
                                   1039 ;Allocation info for local variables in function 'add_owned_mods'
                                   1040 ;------------------------------------------------------------
                                   1041 ;mods          Allocated with name '_add_owned_mods_mods_10000_318'
                                   1042 ;------------------------------------------------------------
                                   1043 ;	quantum/action_util.c:106: void add_owned_mods(uint8_t mods) { change_owned(mods, 1); }
                                   1044 ;	-----------------------------------------
                                   1045 ;	 function add_owned_mods
                                   1046 ;	-----------------------------------------
      008204                       1047 _add_owned_mods:
      008204 E5 82            [12] 1048 	mov	a,dpl
      008206 90 09 C5         [24] 1049 	mov	dptr,#_add_owned_mods_mods_10000_318
      008209 12 86 34         [24] 1050 	lcall	_ak820_outline_0119
      00820C 74 01            [12] 1051 	mov	a,#0x01
      00820E F0               [24] 1052 	movx	@dptr,a
      00820F 8F 82            [24] 1053 	mov	dpl, r7
      008211 21 34            [12] 1054 	ajmp	_change_owned
                                   1055 ;------------------------------------------------------------
                                   1056 ;Allocation info for local variables in function 'del_owned_mods'
                                   1057 ;------------------------------------------------------------
                                   1058 ;mods          Allocated with name '_del_owned_mods_mods_10000_320'
                                   1059 ;------------------------------------------------------------
                                   1060 ;	quantum/action_util.c:107: void del_owned_mods(uint8_t mods) { change_owned(mods, 0); }
                                   1061 ;	-----------------------------------------
                                   1062 ;	 function del_owned_mods
                                   1063 ;	-----------------------------------------
      008213                       1064 _del_owned_mods:
      008213 E5 82            [12] 1065 	mov	a,dpl
      008215 90 09 C6         [24] 1066 	mov	dptr,#_del_owned_mods_mods_10000_320
      008218 12 86 34         [24] 1067 	lcall	_ak820_outline_0119
      00821B 12 7C 73         [24] 1068 	lcall	_ak820_outline_0191
      00821E 21 34            [12] 1069 	ajmp	_change_owned
                                   1070 ;------------------------------------------------------------
                                   1071 ;Allocation info for local variables in function 'add_owned_weak_mods'
                                   1072 ;------------------------------------------------------------
                                   1073 ;mods          Allocated with name '_add_owned_weak_mods_mods_10000_322'
                                   1074 ;------------------------------------------------------------
                                   1075 ;	quantum/action_util.c:108: void add_owned_weak_mods(uint8_t mods) { change_owned(mods, 3); }
                                   1076 ;	-----------------------------------------
                                   1077 ;	 function add_owned_weak_mods
                                   1078 ;	-----------------------------------------
      008220                       1079 _add_owned_weak_mods:
      008220 E5 82            [12] 1080 	mov	a,dpl
      008222 90 09 C7         [24] 1081 	mov	dptr,#_add_owned_weak_mods_mods_10000_322
      008225 12 86 34         [24] 1082 	lcall	_ak820_outline_0119
      008228 74 03            [12] 1083 	mov	a,#0x03
      00822A F0               [24] 1084 	movx	@dptr,a
      00822B 8F 82            [24] 1085 	mov	dpl, r7
      00822D 21 34            [12] 1086 	ajmp	_change_owned
                                   1087 ;------------------------------------------------------------
                                   1088 ;Allocation info for local variables in function 'del_owned_weak_mods'
                                   1089 ;------------------------------------------------------------
                                   1090 ;mods          Allocated with name '_del_owned_weak_mods_mods_10000_324'
                                   1091 ;------------------------------------------------------------
                                   1092 ;	quantum/action_util.c:109: void del_owned_weak_mods(uint8_t mods) { change_owned(mods, 2); }
                                   1093 ;	-----------------------------------------
                                   1094 ;	 function del_owned_weak_mods
                                   1095 ;	-----------------------------------------
      00822F                       1096 _del_owned_weak_mods:
      00822F E5 82            [12] 1097 	mov	a,dpl
      008231 90 09 C8         [24] 1098 	mov	dptr,#_del_owned_weak_mods_mods_10000_324
      008234 12 86 34         [24] 1099 	lcall	_ak820_outline_0119
      008237 74 02            [12] 1100 	mov	a,#0x02
      008239 F0               [24] 1101 	movx	@dptr,a
      00823A 8F 82            [24] 1102 	mov	dpl, r7
      00823C 21 34            [12] 1103 	ajmp	_change_owned
                                   1104 ;------------------------------------------------------------
                                   1105 ;Allocation info for local variables in function 'clear_owned_mods'
                                   1106 ;------------------------------------------------------------
                                   1107 ;i             Allocated with name '_clear_owned_mods_i_20000_328'
                                   1108 ;------------------------------------------------------------
                                   1109 ;	quantum/action_util.c:110: void clear_owned_mods(void) {
                                   1110 ;	-----------------------------------------
                                   1111 ;	 function clear_owned_mods
                                   1112 ;	-----------------------------------------
      00823E                       1113 _clear_owned_mods:
                                   1114 ;	quantum/action_util.c:111: for (uint8_t i = 0; i < 8; ++i) owned_mod_refs[i] = owned_weak_refs[i] = 0;
      00823E 7F 00            [12] 1115 	mov	r7,#0x00
      008240                       1116 00103$:
      008240 BF 08 00         [24] 1117 	cjne	r7,#0x08,00122$
      008243                       1118 00122$:
      008243 50 1A            [24] 1119 	jnc	00101$
      008245 EF               [12] 1120 	mov	a,r7
      008246 24 A7            [12] 1121 	add	a, #_owned_mod_refs
      008248 FD               [12] 1122 	mov	r5,a
      008249 E4               [12] 1123 	clr	a
      00824A 34 09            [12] 1124 	addc	a, #(_owned_mod_refs >> 8)
      00824C FE               [12] 1125 	mov	r6,a
      00824D EF               [12] 1126 	mov	a,r7
      00824E 24 AF            [12] 1127 	add	a, #_owned_weak_refs
      008250 F5 82            [12] 1128 	mov	dpl,a
      008252 E4               [12] 1129 	clr	a
      008253 34 09            [12] 1130 	addc	a, #(_owned_weak_refs >> 8)
      008255 F5 83            [12] 1131 	mov	dph,a
      008257 E4               [12] 1132 	clr	a
      008258 F0               [24] 1133 	movx	@dptr,a
      008259 12 86 3B         [24] 1134 	lcall	_ak820_outline_0123
      00825C 0F               [12] 1135 	inc	r7
      00825D 80 E1            [24] 1136 	sjmp	00103$
      00825F                       1137 00101$:
                                   1138 ;	quantum/action_util.c:112: owned_mods = owned_weak_mods = macro_mods[0] = macro_mods[1] = 0;
      00825F 90 09 BA         [24] 1139 	mov	dptr,#(_macro_mods + 0x0001)
      008262 E4               [12] 1140 	clr	a
      008263 F0               [24] 1141 	movx	@dptr,a
      008264 90 09 B9         [24] 1142 	mov	dptr,#_macro_mods
      008267 F0               [24] 1143 	movx	@dptr,a
      008268 90 09 B8         [24] 1144 	mov	dptr,#_owned_weak_mods
      00826B F0               [24] 1145 	movx	@dptr,a
      00826C 90 09 B7         [24] 1146 	mov	dptr,#_owned_mods
      00826F F0               [24] 1147 	movx	@dptr,a
                                   1148 ;	quantum/action_util.c:113: ak820_macro_cancelled = true;
      008270 90 09 BC         [24] 1149 	mov	dptr,#_ak820_macro_cancelled
      008273 04               [12] 1150 	inc	a
      008274 F0               [24] 1151 	movx	@dptr,a
                                   1152 ;	quantum/action_util.c:114: }
      008275 22               [24] 1153 	ret
                                   1154 ;------------------------------------------------------------
                                   1155 ;Allocation info for local variables in function 'clear_owned_keys'
                                   1156 ;------------------------------------------------------------
                                   1157 ;i             Allocated with name '_clear_owned_keys_i_20000_331'
                                   1158 ;i             Allocated with name '_clear_owned_keys_i_20000_332'
                                   1159 ;------------------------------------------------------------
                                   1160 ;	quantum/action_util.c:120: void clear_owned_keys(void) {
                                   1161 ;	-----------------------------------------
                                   1162 ;	 function clear_owned_keys
                                   1163 ;	-----------------------------------------
      008276                       1164 _clear_owned_keys:
                                   1165 ;	quantum/action_util.c:121: for (uint8_t i = 0; i <= KC_EXSEL; ++i) key_refs[i] = 0;
      008276 7F 00            [12] 1166 	mov	r7,#0x00
      008278                       1167 00104$:
      008278 EF               [12] 1168 	mov	a,r7
      008279 24 5B            [12] 1169 	add	a,#0xff - 0xa4
      00827B 40 0D            [24] 1170 	jc	00101$
                                   1171 ;	free result
      00827D EF               [12] 1172 	mov	a,r7
      00827E 24 C9            [12] 1173 	add	a, #_key_refs
      008280 F5 82            [12] 1174 	mov	dpl,a
      008282 E4               [12] 1175 	clr	a
      008283 34 09            [12] 1176 	addc	a, #(_key_refs >> 8)
      008285 12 80 6B         [24] 1177 	lcall	_ak820_outline_0168
      008288 80 EE            [24] 1178 	sjmp	00104$
      00828A                       1179 00101$:
                                   1180 ;	quantum/action_util.c:122: distinct_keys = 0;
      00828A 90 0A 6E         [24] 1181 	mov	dptr,#_distinct_keys
      00828D E4               [12] 1182 	clr	a
      00828E F0               [24] 1183 	movx	@dptr,a
                                   1184 ;	quantum/action_util.c:123: for (uint8_t i = 0; i < sizeof(macro_keys); ++i) macro_keys[i] = 0;
      00828F FF               [12] 1185 	mov	r7,a
      008290                       1186 00107$:
      008290 BF 15 00         [24] 1187 	cjne	r7,#0x15,00142$
      008293                       1188 00142$:
      008293 50 0D            [24] 1189 	jnc	00109$
      008295 EF               [12] 1190 	mov	a,r7
      008296 24 6F            [12] 1191 	add	a, #_macro_keys
      008298 F5 82            [12] 1192 	mov	dpl,a
      00829A E4               [12] 1193 	clr	a
      00829B 34 0A            [12] 1194 	addc	a, #(_macro_keys >> 8)
      00829D 12 80 6B         [24] 1195 	lcall	_ak820_outline_0168
      0082A0 80 EE            [24] 1196 	sjmp	00107$
      0082A2                       1197 00109$:
                                   1198 ;	quantum/action_util.c:124: }
      0082A2 22               [24] 1199 	ret
                                   1200 ;------------------------------------------------------------
                                   1201 ;Allocation info for local variables in function 'add_owned_key'
                                   1202 ;------------------------------------------------------------
                                   1203 ;code          Allocated with name '_add_owned_key_code_10000_333'
                                   1204 ;__400000074   Allocated with name '_add_owned_key___400000074_40000_342'
                                   1205 ;key           Allocated with name '_add_owned_key_key_50000_343'
                                   1206 ;i             Allocated with name '_add_owned_key_i_40000_341'
                                   1207 ;__300000076   Allocated with name '_add_owned_key___300000076_30000_345'
                                   1208 ;key           Allocated with name '_add_owned_key_key_40000_346'
                                   1209 ;------------------------------------------------------------
                                   1210 ;	quantum/action_util.c:125: bool add_owned_key(uint8_t code) {
                                   1211 ;	-----------------------------------------
                                   1212 ;	 function add_owned_key
                                   1213 ;	-----------------------------------------
      0082A3                       1214 _add_owned_key:
      0082A3 E5 82            [12] 1215 	mov	a,dpl
      0082A5 90 0A 84         [24] 1216 	mov	dptr,#_add_owned_key_code_10000_333
      0082A8 12 86 4C         [24] 1217 	lcall	_ak820_outline_0134
                                   1218 ;	quantum/action_util.c:126: if (!ak820_macro_change(macro_keys, code, true)) return false;
      0082AB 74 01            [12] 1219 	mov	a,#0x01
      0082AD F0               [24] 1220 	movx	@dptr,a
      0082AE 90 0A 6F         [24] 1221 	mov	dptr,#_macro_keys
      0082B1 C0 07            [24] 1222 	push	ar7
      0082B3 11 C8            [12] 1223 	acall	_ak820_macro_change
      0082B5 E5 82            [12] 1224 	mov	a, dpl
      0082B7 D0 07            [24] 1225 	pop	ar7
      0082B9 70 03            [24] 1226 	jnz	00102$
      0082BB F5 82            [12] 1227 	mov	dpl,a
      0082BD 22               [24] 1228 	ret
      0082BE                       1229 00102$:
                                   1230 ;	quantum/action_util.c:127: if (key_refs[code]++) return false;
      0082BE 12 85 FE         [24] 1231 	lcall	_ak820_outline_0030
      0082C1 FC               [12] 1232 	mov	r4,a
      0082C2 04               [12] 1233 	inc	a
      0082C3 12 86 3B         [24] 1234 	lcall	_ak820_outline_0123
      0082C6 EC               [12] 1235 	mov	a,r4
      0082C7 60 04            [24] 1236 	jz	00104$
      0082C9 75 82 00         [24] 1237 	mov	dpl, #0x00
      0082CC 22               [24] 1238 	ret
      0082CD                       1239 00104$:
                                   1240 ;	quantum/action_util.c:128: ++distinct_keys;
      0082CD 90 0A 6E         [24] 1241 	mov	dptr,#_distinct_keys
      0082D0 E0               [24] 1242 	movx	a,@dptr
      0082D1 24 01            [12] 1243 	add	a, #0x01
      0082D3 F0               [24] 1244 	movx	@dptr,a
                                   1245 ;	quantum/action_util.c:130: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      0082D4 90 0D E8         [24] 1246 	mov	dptr,#_keyboard_protocol
      0082D7 E0               [24] 1247 	movx	a,@dptr
      0082D8 60 15            [24] 1248 	jz	00106$
      0082DA 90 0A F3         [24] 1249 	mov	dptr,#_keymap_config
      0082DD E0               [24] 1250 	movx	a,@dptr
      0082DE 30 E7 0E         [24] 1251 	jnb	acc.7,00106$
                                   1252 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      0082E1 90 08 2F         [24] 1253 	mov	dptr,#_add_key_to_report_PARM_2
      0082E4 EF               [12] 1254 	mov	a,r7
      0082E5 12 86 0C         [24] 1255 	lcall	_ak820_outline_0058
      0082E8 12 73 6E         [24] 1256 	lcall	_add_key_to_report
                                   1257 ;	quantum/action_util.c:130: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      0082EB 75 82 01         [24] 1258 	mov	dpl, #0x01
      0082EE 22               [24] 1259 	ret
      0082EF                       1260 00106$:
                                   1261 ;	quantum/action_util.c:132: if (distinct_keys > KEYBOARD_REPORT_KEYS) {
      0082EF 90 0A 6E         [24] 1262 	mov	dptr,#_distinct_keys
      0082F2 E0               [24] 1263 	movx	a,@dptr
      0082F3 24 F9            [12] 1264 	add	a,#0xff - 0x06
      0082F5 50 17            [24] 1265 	jnc	00110$
                                   1266 ;	free result
                                   1267 ;	quantum/action_util.c:133: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; ++i) keyboard_report->keys[i] = 1; /* HID ErrorRollOver */
      0082F7 7F 00            [12] 1268 	mov	r7,#0x00
      0082F9                       1269 00115$:
      0082F9 BF 06 00         [24] 1270 	cjne	r7,#0x06,00174$
      0082FC                       1271 00174$:
      0082FC 50 1D            [24] 1272 	jnc	00111$
      0082FE EF               [12] 1273 	mov	a,r7
      0082FF 24 FD            [12] 1274 	add	a, #(_actual_keyboard_report + 0x0002)
      008301 F5 82            [12] 1275 	mov	dpl,a
      008303 E4               [12] 1276 	clr	a
      008304 34 0D            [12] 1277 	addc	a, #((_actual_keyboard_report + 0x0002) >> 8)
      008306 F5 83            [12] 1278 	mov	dph,a
      008308 74 01            [12] 1279 	mov	a,#0x01
      00830A F0               [24] 1280 	movx	@dptr,a
      00830B 0F               [12] 1281 	inc	r7
      00830C 80 EB            [24] 1282 	sjmp	00115$
      00830E                       1283 00110$:
                                   1284 ;	quantum/action_util.c:134: } else add_key(code);
      00830E 90 0A 84         [24] 1285 	mov	dptr,#_add_owned_key_code_10000_333
      008311 E0               [24] 1286 	movx	a,@dptr
                                   1287 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      008312 90 08 2F         [24] 1288 	mov	dptr,#_add_key_to_report_PARM_2
      008315 12 86 0C         [24] 1289 	lcall	_ak820_outline_0058
      008318 12 73 6E         [24] 1290 	lcall	_add_key_to_report
                                   1291 ;	quantum/action_util.c:134: } else add_key(code);
      00831B                       1292 00111$:
                                   1293 ;	quantum/action_util.c:135: return true;
      00831B 75 82 01         [24] 1294 	mov	dpl, #0x01
                                   1295 ;	quantum/action_util.c:136: }
      00831E 22               [24] 1296 	ret
                                   1297 ;------------------------------------------------------------
                                   1298 ;Allocation info for local variables in function 'del_owned_key'
                                   1299 ;------------------------------------------------------------
                                   1300 ;code          Allocated with name '_del_owned_key_code_10000_348'
                                   1301 ;__400000078   Allocated with name '_del_owned_key___400000078_40000_359'
                                   1302 ;key           Allocated with name '_del_owned_key_key_50000_360'
                                   1303 ;key           Allocated with name '_del_owned_key_key_40000_357'
                                   1304 ;__600000081   Allocated with name '_del_owned_key___600000081_60000_365'
                                   1305 ;key           Allocated with name '_del_owned_key_key_70000_366'
                                   1306 ;__300000083   Allocated with name '_del_owned_key___300000083_30000_368'
                                   1307 ;key           Allocated with name '_del_owned_key_key_40000_369'
                                   1308 ;------------------------------------------------------------
                                   1309 ;	quantum/action_util.c:137: bool del_owned_key(uint8_t code) {
                                   1310 ;	-----------------------------------------
                                   1311 ;	 function del_owned_key
                                   1312 ;	-----------------------------------------
      00831F                       1313 _del_owned_key:
      00831F E5 82            [12] 1314 	mov	a,dpl
      008321 90 0A 85         [24] 1315 	mov	dptr,#_del_owned_key_code_10000_348
      008324 12 86 4C         [24] 1316 	lcall	_ak820_outline_0134
                                   1317 ;	quantum/action_util.c:138: if (!ak820_macro_change(macro_keys, code, false)) return false;
      008327 E4               [12] 1318 	clr	a
      008328 F0               [24] 1319 	movx	@dptr,a
      008329 90 0A 6F         [24] 1320 	mov	dptr,#_macro_keys
      00832C C0 07            [24] 1321 	push	ar7
      00832E 11 C8            [12] 1322 	acall	_ak820_macro_change
      008330 E5 82            [12] 1323 	mov	a, dpl
      008332 D0 07            [24] 1324 	pop	ar7
      008334 70 03            [24] 1325 	jnz	00102$
      008336 F5 82            [12] 1326 	mov	dpl,a
      008338 22               [24] 1327 	ret
      008339                       1328 00102$:
                                   1329 ;	quantum/action_util.c:139: if (!key_refs[code] || --key_refs[code]) return false;
      008339 12 85 FE         [24] 1330 	lcall	_ak820_outline_0030
      00833C FC               [12] 1331 	mov	r4,a
      00833D 60 09            [24] 1332 	jz	00103$
      00833F 1C               [12] 1333 	dec	r4
      008340 12 3A DC         [24] 1334 	lcall	_ak820_outline_0135
      008343 EC               [12] 1335 	mov	a,r4
      008344 F0               [24] 1336 	movx	@dptr,a
      008345 EC               [12] 1337 	mov	a,r4
      008346 60 04            [24] 1338 	jz	00104$
      008348                       1339 00103$:
      008348 75 82 00         [24] 1340 	mov	dpl, #0x00
      00834B 22               [24] 1341 	ret
      00834C                       1342 00104$:
                                   1343 ;	quantum/action_util.c:140: --distinct_keys;
      00834C 90 0A 6E         [24] 1344 	mov	dptr,#_distinct_keys
      00834F E0               [24] 1345 	movx	a,@dptr
      008350 14               [12] 1346 	dec	a
      008351 F0               [24] 1347 	movx	@dptr,a
                                   1348 ;	quantum/action_util.c:142: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      008352 90 0D E8         [24] 1349 	mov	dptr,#_keyboard_protocol
      008355 E0               [24] 1350 	movx	a,@dptr
      008356 60 15            [24] 1351 	jz	00107$
      008358 90 0A F3         [24] 1352 	mov	dptr,#_keymap_config
      00835B E0               [24] 1353 	movx	a,@dptr
      00835C 30 E7 0E         [24] 1354 	jnb	acc.7,00107$
                                   1355 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      00835F 90 08 33         [24] 1356 	mov	dptr,#_del_key_from_report_PARM_2
      008362 EF               [12] 1357 	mov	a,r7
      008363 12 86 0C         [24] 1358 	lcall	_ak820_outline_0058
      008366 12 73 AA         [24] 1359 	lcall	_del_key_from_report
                                   1360 ;	quantum/action_util.c:142: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      008369 75 82 01         [24] 1361 	mov	dpl, #0x01
      00836C 22               [24] 1362 	ret
      00836D                       1363 00107$:
                                   1364 ;	quantum/action_util.c:144: if (distinct_keys > KEYBOARD_REPORT_KEYS) return true;
      00836D 90 0A 6E         [24] 1365 	mov	dptr,#_distinct_keys
      008370 E0               [24] 1366 	movx	a,@dptr
      008371 FF               [12] 1367 	mov  r7,a
      008372 24 F9            [12] 1368 	add	a,#0xff - 0x06
      008374 50 04            [24] 1369 	jnc	00110$
                                   1370 ;	free result
      008376 75 82 01         [24] 1371 	mov	dpl, #0x01
      008379 22               [24] 1372 	ret
      00837A                       1373 00110$:
                                   1374 ;	quantum/action_util.c:145: if (distinct_keys == KEYBOARD_REPORT_KEYS) {
      00837A BF 06 26         [24] 1375 	cjne	r7,#0x06,00115$
                                   1376 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      00837D 90 0D FB         [24] 1377 	mov	dptr,#_actual_keyboard_report
      008380 75 F0 00         [24] 1378 	mov	b, #0x00
      008383 12 73 E6         [24] 1379 	lcall	_clear_keys_from_report
                                   1380 ;	quantum/action_util.c:148: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      008386 7F 04            [12] 1381 	mov	r7,#0x04
      008388                       1382 00122$:
      008388 EF               [12] 1383 	mov	a,r7
      008389 24 5B            [12] 1384 	add	a,#0xff - 0xa4
      00838B 40 23            [24] 1385 	jc	00116$
                                   1386 ;	free result
      00838D 12 85 FE         [24] 1387 	lcall	_ak820_outline_0030
      008390 60 0E            [24] 1388 	jz	00123$
                                   1389 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      008392 90 08 2F         [24] 1390 	mov	dptr,#_add_key_to_report_PARM_2
      008395 EF               [12] 1391 	mov	a,r7
      008396 12 86 0C         [24] 1392 	lcall	_ak820_outline_0058
      008399 C0 07            [24] 1393 	push	ar7
      00839B 12 73 6E         [24] 1394 	lcall	_add_key_to_report
      00839E D0 07            [24] 1395 	pop	ar7
                                   1396 ;	quantum/action_util.c:148: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      0083A0                       1397 00123$:
      0083A0 0F               [12] 1398 	inc	r7
      0083A1 80 E5            [24] 1399 	sjmp	00122$
      0083A3                       1400 00115$:
                                   1401 ;	quantum/action_util.c:149: } else del_key(code);
      0083A3 90 0A 85         [24] 1402 	mov	dptr,#_del_owned_key_code_10000_348
      0083A6 E0               [24] 1403 	movx	a,@dptr
                                   1404 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      0083A7 90 08 33         [24] 1405 	mov	dptr,#_del_key_from_report_PARM_2
      0083AA 12 86 0C         [24] 1406 	lcall	_ak820_outline_0058
      0083AD 12 73 AA         [24] 1407 	lcall	_del_key_from_report
                                   1408 ;	quantum/action_util.c:149: } else del_key(code);
      0083B0                       1409 00116$:
                                   1410 ;	quantum/action_util.c:150: return true;
      0083B0 75 82 01         [24] 1411 	mov	dpl, #0x01
                                   1412 ;	quantum/action_util.c:151: }
      0083B3 22               [24] 1413 	ret
                                   1414 ;------------------------------------------------------------
                                   1415 ;Allocation info for local variables in function 'clear_owned_usages'
                                   1416 ;------------------------------------------------------------
                                   1417 ;i             Allocated with name '_clear_owned_usages_i_20000_373'
                                   1418 ;i             Allocated with name '_clear_owned_usages_i_20000_374'
                                   1419 ;------------------------------------------------------------
                                   1420 ;	quantum/action_util.c:161: void clear_owned_usages(void) {
                                   1421 ;	-----------------------------------------
                                   1422 ;	 function clear_owned_usages
                                   1423 ;	-----------------------------------------
      0083B4                       1424 _clear_owned_usages:
                                   1425 ;	quantum/action_util.c:162: for (uint8_t i = 0; i < USAGE_COUNT; ++i) usage_refs[i] = usage_order[i] = 0;
      0083B4 7F 00            [12] 1426 	mov	r7,#0x00
      0083B6                       1427 00104$:
      0083B6 BF 1E 00         [24] 1428 	cjne	r7,#0x1e,00141$
      0083B9                       1429 00141$:
      0083B9 50 14            [24] 1430 	jnc	00101$
      0083BB EF               [12] 1431 	mov	a,r7
      0083BC 24 86            [12] 1432 	add	a, #_usage_refs
      0083BE FD               [12] 1433 	mov	r5,a
      0083BF E4               [12] 1434 	clr	a
      0083C0 34 0A            [12] 1435 	addc	a, #(_usage_refs >> 8)
      0083C2 FE               [12] 1436 	mov	r6,a
      0083C3 EF               [12] 1437 	mov	a,r7
      0083C4 12 86 1B         [24] 1438 	lcall	_ak820_outline_0068
      0083C7 E4               [12] 1439 	clr	a
      0083C8 F0               [24] 1440 	movx	@dptr,a
      0083C9 12 86 3B         [24] 1441 	lcall	_ak820_outline_0123
      0083CC 0F               [12] 1442 	inc	r7
      0083CD 80 E7            [24] 1443 	sjmp	00104$
      0083CF                       1444 00101$:
                                   1445 ;	quantum/action_util.c:163: usage_lengths[0] = usage_lengths[1] = 0;
      0083CF 90 0A C3         [24] 1446 	mov	dptr,#(_usage_lengths + 0x0001)
      0083D2 E4               [12] 1447 	clr	a
      0083D3 F0               [24] 1448 	movx	@dptr,a
      0083D4 90 0A C2         [24] 1449 	mov	dptr,#_usage_lengths
      0083D7 F0               [24] 1450 	movx	@dptr,a
                                   1451 ;	quantum/action_util.c:164: for (uint8_t i = 0; i < sizeof(macro_usages); ++i) macro_usages[i] = 0;
      0083D8 FF               [12] 1452 	mov	r7,a
      0083D9                       1453 00107$:
      0083D9 BF 04 00         [24] 1454 	cjne	r7,#0x04,00143$
      0083DC                       1455 00143$:
      0083DC 50 0D            [24] 1456 	jnc	00109$
      0083DE EF               [12] 1457 	mov	a,r7
      0083DF 24 C4            [12] 1458 	add	a, #_macro_usages
      0083E1 F5 82            [12] 1459 	mov	dpl,a
      0083E3 E4               [12] 1460 	clr	a
      0083E4 34 0A            [12] 1461 	addc	a, #(_macro_usages >> 8)
      0083E6 12 80 6B         [24] 1462 	lcall	_ak820_outline_0168
      0083E9 80 EE            [24] 1463 	sjmp	00107$
      0083EB                       1464 00109$:
                                   1465 ;	quantum/action_util.c:165: }
      0083EB 22               [24] 1466 	ret
                                   1467 ;------------------------------------------------------------
                                   1468 ;Allocation info for local variables in function 'owned_usage_key'
                                   1469 ;------------------------------------------------------------
                                   1470 ;pressed       Allocated with name '_owned_usage_key_PARM_2'
                                   1471 ;code          Allocated with name '_owned_usage_key_code_10000_375'
                                   1472 ;__200000085   Allocated with name '_owned_usage_key___200000085_20000_376'
                                   1473 ;which         Allocated with name '_owned_usage_key_which_10000_376'
                                   1474 ;base          Allocated with name '_owned_usage_key_base_10000_376'
                                   1475 ;count         Allocated with name '_owned_usage_key_count_10000_376'
                                   1476 ;index         Allocated with name '_owned_usage_key_index_10000_376'
                                   1477 ;pos           Allocated with name '_owned_usage_key_pos_30001_383'
                                   1478 ;i             Allocated with name '_owned_usage_key_i_40001_384'
                                   1479 ;__300000086   Allocated with name '_owned_usage_key___300000086_30000_387'
                                   1480 ;key           Allocated with name '_owned_usage_key_key_40000_388'
                                   1481 ;------------------------------------------------------------
                                   1482 ;	quantum/action_util.c:166: void owned_usage_key(uint8_t code, bool pressed) {
                                   1483 ;	-----------------------------------------
                                   1484 ;	 function owned_usage_key
                                   1485 ;	-----------------------------------------
      0083EC                       1486 _owned_usage_key:
      0083EC E5 82            [12] 1487 	mov	a,dpl
      0083EE 90 0A C9         [24] 1488 	mov	dptr,#_owned_usage_key_code_10000_375
      0083F1 F0               [24] 1489 	movx	@dptr,a
                                   1490 ;	quantum/action_util.c:167: uint8_t which = code >= KC_AUDIO_MUTE;
      0083F2 E0               [24] 1491 	movx	a,@dptr
      0083F3 FF               [12] 1492 	mov	r7,a
      0083F4 BF A8 00         [24] 1493 	cjne	r7,#0xa8,00244$
      0083F7                       1494 00244$:
      0083F7 B3               [12] 1495 	cpl	c
      0083F8 92 25            [24] 1496 	mov	_owned_usage_key_sloc0_1_0,c
      0083FA E4               [12] 1497 	clr	a
      0083FB 33               [12] 1498 	rlc	a
      0083FC FF               [12] 1499 	mov	r7,a
      0083FD 90 0A CC         [24] 1500 	mov	dptr,#_owned_usage_key_which_10000_376
      008400 F0               [24] 1501 	movx	@dptr,a
                                   1502 ;	quantum/action_util.c:168: uint8_t base = which ? SYSTEM_COUNT : 0;
      008401 EF               [12] 1503 	mov	a,r7
      008402 60 02            [24] 1504 	jz	00129$
      008404 74 03            [12] 1505 	mov	a,#0x03
      008406                       1506 00129$:
      008406 FE               [12] 1507 	mov	r6,a
                                   1508 ;	quantum/action_util.c:169: uint8_t count = usage_lengths[which];
      008407 EF               [12] 1509 	mov	a,r7
      008408 24 C2            [12] 1510 	add	a, #_usage_lengths
      00840A FD               [12] 1511 	mov	r5,a
      00840B E4               [12] 1512 	clr	a
      00840C 34 0A            [12] 1513 	addc	a, #(_usage_lengths >> 8)
      00840E FF               [12] 1514 	mov	r7,a
      00840F 12 86 57         [24] 1515 	lcall	_ak820_outline_0192
      008412 E0               [24] 1516 	movx	a,@dptr
      008413 FC               [12] 1517 	mov	r4,a
                                   1518 ;	quantum/action_util.c:170: uint8_t index = code - KC_SYSTEM_POWER;
      008414 90 0A C9         [24] 1519 	mov	dptr,#_owned_usage_key_code_10000_375
      008417 E0               [24] 1520 	movx	a,@dptr
      008418 24 5B            [12] 1521 	add	a,#0x5b
      00841A FB               [12] 1522 	mov	r3,a
                                   1523 ;	quantum/action_util.c:171: if (!ak820_macro_change(macro_usages, index, pressed)) return;
      00841B 90 0A C8         [24] 1524 	mov	dptr,#_owned_usage_key_PARM_2
      00841E E0               [24] 1525 	movx	a,@dptr
      00841F FA               [12] 1526 	mov	r2,a
      008420 90 09 BD         [24] 1527 	mov	dptr,#_ak820_macro_change_PARM_2
      008423 EB               [12] 1528 	mov	a,r3
      008424 F0               [24] 1529 	movx	@dptr,a
      008425 90 09 BE         [24] 1530 	mov	dptr,#_ak820_macro_change_PARM_3
      008428 EA               [12] 1531 	mov	a,r2
      008429 F0               [24] 1532 	movx	@dptr,a
      00842A 90 0A C4         [24] 1533 	mov	dptr,#_macro_usages
      00842D C0 07            [24] 1534 	push	ar7
      00842F C0 06            [24] 1535 	push	ar6
      008431 C0 05            [24] 1536 	push	ar5
      008433 C0 04            [24] 1537 	push	ar4
      008435 C0 03            [24] 1538 	push	ar3
      008437 C0 02            [24] 1539 	push	ar2
      008439 11 C8            [12] 1540 	acall	_ak820_macro_change
      00843B E5 82            [12] 1541 	mov	a, dpl
      00843D D0 02            [24] 1542 	pop	ar2
      00843F D0 03            [24] 1543 	pop	ar3
      008441 D0 04            [24] 1544 	pop	ar4
      008443 D0 05            [24] 1545 	pop	ar5
      008445 D0 06            [24] 1546 	pop	ar6
      008447 D0 07            [24] 1547 	pop	ar7
      008449 70 01            [24] 1548 	jnz	00102$
      00844B 22               [24] 1549 	ret
      00844C                       1550 00102$:
                                   1551 ;	quantum/action_util.c:172: if (pressed) {
      00844C EA               [12] 1552 	mov	a,r2
      00844D 60 1A            [24] 1553 	jz	00115$
                                   1554 ;	quantum/action_util.c:173: if (usage_refs[index]++) return;
      00844F 12 86 25         [24] 1555 	lcall	_ak820_outline_0075
      008452 04               [12] 1556 	inc	a
      008453 12 70 EC         [24] 1557 	lcall	_ak820_outline_0141
      008456 E8               [12] 1558 	mov	a,r0
      008457 60 01            [24] 1559 	jz	00104$
      008459 22               [24] 1560 	ret
      00845A                       1561 00104$:
                                   1562 ;	quantum/action_util.c:174: usage_order[base + count++] = index;
      00845A 90 0A CD         [24] 1563 	mov	dptr,#_owned_usage_key_count_10000_376
      00845D EC               [12] 1564 	mov	a,r4
      00845E 04               [12] 1565 	inc	a
      00845F F0               [24] 1566 	movx	@dptr,a
      008460 EC               [12] 1567 	mov	a,r4
      008461 2E               [12] 1568 	add	a, r6
      008462 12 86 1B         [24] 1569 	lcall	_ak820_outline_0068
      008465 EB               [12] 1570 	mov	a,r3
      008466 F0               [24] 1571 	movx	@dptr,a
      008467 81 CA            [12] 1572 	ajmp	00116$
      008469                       1573 00115$:
                                   1574 ;	quantum/action_util.c:176: if (!usage_refs[index] || --usage_refs[index]) return;
      008469 12 86 25         [24] 1575 	lcall	_ak820_outline_0075
      00846C 60 07            [24] 1576 	jz	00105$
      00846E 18               [12] 1577 	dec	r0
      00846F 12 86 14         [24] 1578 	lcall	_ak820_outline_0064
      008472 E8               [12] 1579 	mov	a,r0
      008473 60 01            [24] 1580 	jz	00106$
      008475                       1581 00105$:
      008475 22               [24] 1582 	ret
      008476                       1583 00106$:
                                   1584 ;	quantum/action_util.c:178: while (usage_order[base + pos] != index) ++pos;
      008476 7A 00            [12] 1585 	mov	r2,#0x00
      008478                       1586 00108$:
      008478 EA               [12] 1587 	mov	a,r2
      008479 2E               [12] 1588 	add	a, r6
      00847A 12 86 1B         [24] 1589 	lcall	_ak820_outline_0068
      00847D E0               [24] 1590 	movx	a,@dptr
      00847E B5 03 02         [24] 1591 	cjne	a,ar3,00251$
      008481 80 03            [24] 1592 	sjmp	00167$
      008483                       1593 00251$:
      008483 0A               [12] 1594 	inc	r2
      008484 80 F2            [24] 1595 	sjmp	00108$
      008486                       1596 00167$:
      008486 90 0A CE         [24] 1597 	mov	dptr,#_owned_usage_key_pos_30001_383
      008489 EA               [12] 1598 	mov	a,r2
      00848A F0               [24] 1599 	movx	@dptr,a
                                   1600 ;	quantum/action_util.c:179: --count;
      00848B 1C               [12] 1601 	dec	r4
      00848C 90 0A CD         [24] 1602 	mov	dptr,#_owned_usage_key_count_10000_376
      00848F EC               [12] 1603 	mov	a,r4
      008490 F0               [24] 1604 	movx	@dptr,a
                                   1605 ;	quantum/action_util.c:180: for (uint8_t i = pos; i < count; ++i) usage_order[base + i] = usage_order[base + i + 1];
      008491 8A 03            [24] 1606 	mov	ar3,r2
      008493                       1607 00125$:
      008493 C3               [12] 1608 	clr	c
      008494 EB               [12] 1609 	mov	a,r3
      008495 9C               [12] 1610 	subb	a,r4
      008496 50 23            [24] 1611 	jnc	00111$
      008498 C0 05            [24] 1612 	push	ar5
      00849A C0 07            [24] 1613 	push	ar7
      00849C EB               [12] 1614 	mov	a,r3
      00849D 2E               [12] 1615 	add	a, r6
      00849E FA               [12] 1616 	mov	r2,a
      00849F 24 A4            [12] 1617 	add	a, #_usage_order
      0084A1 F8               [12] 1618 	mov	r0,a
      0084A2 E4               [12] 1619 	clr	a
      0084A3 34 0A            [12] 1620 	addc	a, #(_usage_order >> 8)
      0084A5 F9               [12] 1621 	mov	r1,a
      0084A6 0A               [12] 1622 	inc	r2
      0084A7 EA               [12] 1623 	mov	a,r2
      0084A8 33               [12] 1624 	rlc	a
      0084A9 95 E0            [12] 1625 	subb	a,acc
      0084AB FF               [12] 1626 	mov	r7,a
      0084AC EA               [12] 1627 	mov	a,r2
      0084AD 12 86 41         [24] 1628 	lcall	_ak820_outline_0127
      0084B0 12 3A F6         [24] 1629 	lcall	_ak820_outline_0163
      0084B3 F0               [24] 1630 	movx	@dptr,a
      0084B4 0B               [12] 1631 	inc	r3
      0084B5 D0 07            [24] 1632 	pop	ar7
      0084B7 D0 05            [24] 1633 	pop	ar5
      0084B9 80 D8            [24] 1634 	sjmp	00125$
      0084BB                       1635 00111$:
                                   1636 ;	quantum/action_util.c:181: usage_lengths[which] = count;
      0084BB 12 86 57         [24] 1637 	lcall	_ak820_outline_0192
      0084BE EC               [12] 1638 	mov	a,r4
      0084BF F0               [24] 1639 	movx	@dptr,a
                                   1640 ;	quantum/action_util.c:182: if (pos != count) return; /* A non-winning owner changed only storage. */
      0084C0 90 0A CE         [24] 1641 	mov	dptr,#_owned_usage_key_pos_30001_383
      0084C3 E0               [24] 1642 	movx	a,@dptr
      0084C4 B5 04 02         [24] 1643 	cjne	a,ar4,00253$
      0084C7 80 01            [24] 1644 	sjmp	00116$
      0084C9                       1645 00253$:
      0084C9 22               [24] 1646 	ret
      0084CA                       1647 00116$:
                                   1648 ;	quantum/action_util.c:184: usage_lengths[which] = count;
      0084CA 90 0A CD         [24] 1649 	mov	dptr,#_owned_usage_key_count_10000_376
      0084CD E0               [24] 1650 	movx	a,@dptr
      0084CE FC               [12] 1651 	mov	r4,a
      0084CF 12 86 57         [24] 1652 	lcall	_ak820_outline_0192
      0084D2 F0               [24] 1653 	movx	@dptr,a
                                   1654 ;	quantum/action_util.c:185: code = count ? usage_order[base + count - 1] + KC_SYSTEM_POWER : 0;
      0084D3 EC               [12] 1655 	mov	a,r4
      0084D4 60 15            [24] 1656 	jz	00131$
      0084D6 EC               [12] 1657 	mov	a,r4
      0084D7 2E               [12] 1658 	add	a, r6
      0084D8 FE               [12] 1659 	mov	r6,a
      0084D9 1E               [12] 1660 	dec	r6
      0084DA EE               [12] 1661 	mov	a,r6
      0084DB 33               [12] 1662 	rlc	a
      0084DC 95 E0            [12] 1663 	subb	a,acc
      0084DE FF               [12] 1664 	mov	r7,a
      0084DF EE               [12] 1665 	mov	a,r6
      0084E0 12 86 41         [24] 1666 	lcall	_ak820_outline_0127
      0084E3 24 A5            [12] 1667 	add	a,#0xa5
      0084E5 FE               [12] 1668 	mov	r6,a
      0084E6 33               [12] 1669 	rlc	a
      0084E7 95 E0            [12] 1670 	subb	a,acc
      0084E9 80 02            [24] 1671 	sjmp	00132$
      0084EB                       1672 00131$:
      0084EB 7E 00            [12] 1673 	mov	r6,#0x00
      0084ED                       1674 00132$:
      0084ED 90 0A C9         [24] 1675 	mov	dptr,#_owned_usage_key_code_10000_375
      0084F0 EE               [12] 1676 	mov	a,r6
      0084F1 F0               [24] 1677 	movx	@dptr,a
                                   1678 ;	quantum/action_util.c:186: if (which) host_consumer_send(code ? KEYCODE2CONSUMER(code) : 0);
      0084F2 90 0A CC         [24] 1679 	mov	dptr,#_owned_usage_key_which_10000_376
      0084F5 E0               [24] 1680 	movx	a,@dptr
      0084F6 60 18            [24] 1681 	jz	00118$
      0084F8 EE               [12] 1682 	mov	a,r6
      0084F9 60 0B            [24] 1683 	jz	00133$
      0084FB 8E 82            [24] 1684 	mov	dpl, r6
      0084FD 12 72 2A         [24] 1685 	lcall	_KEYCODE2CONSUMER
      008500 AD 82            [24] 1686 	mov	r5, dpl
      008502 AF 83            [24] 1687 	mov	r7, dph
      008504 80 04            [24] 1688 	sjmp	00134$
      008506                       1689 00133$:
      008506 7D 00            [12] 1690 	mov	r5,#0x00
      008508 7F 00            [12] 1691 	mov	r7,#0x00
      00850A                       1692 00134$:
      00850A 12 86 57         [24] 1693 	lcall	_ak820_outline_0192
      00850D 02 71 DE         [24] 1694 	ljmp	_host_consumer_send
      008510                       1695 00118$:
                                   1696 ;	quantum/action_util.c:187: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      008510 EE               [12] 1697 	mov	a,r6
      008511 60 22            [24] 1698 	jz	00135$
                                   1699 ;	tmk_core/protocol/report.h:264: if (key < KC_SYSTEM_POWER || key > KC_SYSTEM_WAKE) return 0;
      008513 BE A5 00         [24] 1700 	cjne	r6,#0xa5,00258$
      008516                       1701 00258$:
      008516 40 05            [24] 1702 	jc	00121$
      008518 EE               [12] 1703 	mov	a,r6
      008519 24 58            [12] 1704 	add	a,#0xff - 0xa7
      00851B 50 08            [24] 1705 	jnc	00122$
                                   1706 ;	free result
      00851D                       1707 00121$:
      00851D 90 0A CA         [24] 1708 	mov	dptr,#_owned_usage_key___200000085_20000_376
      008520 12 51 B6         [24] 1709 	lcall	_ak820_outline_0184
      008523 80 09            [24] 1710 	sjmp	00123$
      008525                       1711 00122$:
                                   1712 ;	tmk_core/protocol/report.h:265: return SYSTEM_POWER_DOWN + (key - KC_SYSTEM_POWER);
      008525 74 DC            [12] 1713 	mov	a,#0xdc
      008527 2E               [12] 1714 	add	a, r6
      008528 90 0A CA         [24] 1715 	mov	dptr,#_owned_usage_key___200000085_20000_376
      00852B 12 3A E1         [24] 1716 	lcall	_ak820_outline_0137
                                   1717 ;	quantum/action_util.c:187: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      00852E                       1718 00123$:
      00852E 90 0A CA         [24] 1719 	mov	dptr,#_owned_usage_key___200000085_20000_376
      008531 E0               [24] 1720 	movx	a,@dptr
      008532 FF               [12] 1721 	mov	r7,a
      008533 80 02            [24] 1722 	sjmp	00136$
      008535                       1723 00135$:
      008535 7F 00            [12] 1724 	mov	r7,#0x00
      008537                       1725 00136$:
      008537 7E 00            [12] 1726 	mov	r6,#0x00
      008539 12 45 AD         [24] 1727 	lcall	_ak820_outline_0164
                                   1728 ;	quantum/action_util.c:188: }
      00853C 02 71 AF         [24] 1729 	ljmp	_host_system_send
                                   1730 ;------------------------------------------------------------
                                   1731 ;Allocation info for local variables in function 'send_keyboard_report'
                                   1732 ;------------------------------------------------------------
                                   1733 ;last_report   Allocated with name '_send_keyboard_report_last_report_10001_396'
                                   1734 ;changed       Allocated with name '_send_keyboard_report_changed_10001_396'
                                   1735 ;dest          Allocated with name '_send_keyboard_report_dest_10001_396'
                                   1736 ;src           Allocated with name '_send_keyboard_report_src_10001_396'
                                   1737 ;i             Allocated with name '_send_keyboard_report_i_20001_397'
                                   1738 ;------------------------------------------------------------
                                   1739 ;	quantum/action_util.c:410: void send_keyboard_report(void) {
                                   1740 ;	-----------------------------------------
                                   1741 ;	 function send_keyboard_report
                                   1742 ;	-----------------------------------------
      00853F                       1743 _send_keyboard_report:
                                   1744 ;	quantum/action_util.c:411: keyboard_report->mods = real_mods;
      00853F 90 0D F9         [24] 1745 	mov	dptr,#_real_mods
      008542 E0               [24] 1746 	movx	a,@dptr
      008543 FF               [12] 1747 	mov	r7,a
      008544 90 0D FB         [24] 1748 	mov	dptr,#_actual_keyboard_report
      008547 F0               [24] 1749 	movx	@dptr,a
                                   1750 ;	quantum/action_util.c:412: keyboard_report->mods |= weak_mods;
      008548 90 0D FA         [24] 1751 	mov	dptr,#_weak_mods
      00854B E0               [24] 1752 	movx	a,@dptr
      00854C 42 07            [12] 1753 	orl	ar7,a
      00854E 90 0D FB         [24] 1754 	mov	dptr,#_actual_keyboard_report
      008551 EF               [12] 1755 	mov	a,r7
      008552 F0               [24] 1756 	movx	@dptr,a
                                   1757 ;	quantum/action_util.c:414: keyboard_report->mods |= owned_mods | owned_weak_mods;
      008553 90 09 B8         [24] 1758 	mov	dptr,#_owned_weak_mods
      008556 E0               [24] 1759 	movx	a,@dptr
      008557 FE               [12] 1760 	mov	r6,a
      008558 90 09 B7         [24] 1761 	mov	dptr,#_owned_mods
      00855B E0               [24] 1762 	movx	a,@dptr
      00855C 4E               [12] 1763 	orl	a,r6
      00855D 42 07            [12] 1764 	orl	ar7,a
      00855F 90 0D FB         [24] 1765 	mov	dptr,#_actual_keyboard_report
      008562 EF               [12] 1766 	mov	a,r7
      008563 F0               [24] 1767 	movx	@dptr,a
                                   1768 ;	quantum/action_util.c:444: if (gui_disabled) keyboard_report->mods &= ~(MOD_BIT(KC_LGUI) | MOD_BIT(KC_RGUI));
      008564 30 21 07         [24] 1769 	jnb	_gui_disabled,00102$
      008567 90 0D FB         [24] 1770 	mov	dptr,#_actual_keyboard_report
      00856A E0               [24] 1771 	movx	a,@dptr
      00856B 54 77            [12] 1772 	anl	a,#0x77
      00856D F0               [24] 1773 	movx	@dptr,a
      00856E                       1774 00102$:
                                   1775 ;	quantum/action_util.c:455: bool changed = false;
      00856E 90 0A F0         [24] 1776 	mov	dptr,#_send_keyboard_report_changed_10001_396
      008571 E4               [12] 1777 	clr	a
      008572 F0               [24] 1778 	movx	@dptr,a
                                   1779 ;	quantum/action_util.c:457: uint8_t __xdata *dest = (uint8_t __xdata *)&last_report;
                                   1780 ;	quantum/action_util.c:458: const uint8_t __xdata *src = (const uint8_t __xdata *)keyboard_report;
                                   1781 ;	quantum/action_util.c:463: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      008573 FF               [12] 1782 	mov	r7,a
      008574                       1783 00109$:
      008574 BF 20 00         [24] 1784 	cjne	r7,#0x20,00150$
      008577                       1785 00150$:
      008577 50 2A            [24] 1786 	jnc	00105$
                                   1787 ;	quantum/action_util.c:464: if (dest[i] != src[i]) {
      008579 EF               [12] 1788 	mov	a,r7
      00857A 24 D0            [12] 1789 	add	a, #_send_keyboard_report_last_report_10001_396
      00857C FD               [12] 1790 	mov	r5,a
      00857D E4               [12] 1791 	clr	a
      00857E 34 0A            [12] 1792 	addc	a, #(_send_keyboard_report_last_report_10001_396 >> 8)
      008580 12 4A C3         [24] 1793 	lcall	_ak820_outline_0057
      008583 EF               [12] 1794 	mov	a,r7
      008584 24 FB            [12] 1795 	add	a, #_actual_keyboard_report
      008586 F5 82            [12] 1796 	mov	dpl,a
      008588 E4               [12] 1797 	clr	a
      008589 34 0D            [12] 1798 	addc	a, #(_actual_keyboard_report >> 8)
      00858B F5 83            [12] 1799 	mov	dph,a
      00858D E0               [24] 1800 	movx	a,@dptr
      00858E FB               [12] 1801 	mov	r3,a
      00858F EC               [12] 1802 	mov	a,r4
      008590 B5 03 02         [24] 1803 	cjne	a,ar3,00152$
      008593 80 0B            [24] 1804 	sjmp	00110$
      008595                       1805 00152$:
                                   1806 ;	quantum/action_util.c:465: dest[i] = src[i];
      008595 12 3A DC         [24] 1807 	lcall	_ak820_outline_0135
      008598 EB               [12] 1808 	mov	a,r3
      008599 F0               [24] 1809 	movx	@dptr,a
                                   1810 ;	quantum/action_util.c:466: changed = true;
      00859A 90 0A F0         [24] 1811 	mov	dptr,#_send_keyboard_report_changed_10001_396
      00859D 74 01            [12] 1812 	mov	a,#0x01
      00859F F0               [24] 1813 	movx	@dptr,a
      0085A0                       1814 00110$:
                                   1815 ;	quantum/action_util.c:463: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      0085A0 0F               [12] 1816 	inc	r7
      0085A1 80 D1            [24] 1817 	sjmp	00109$
      0085A3                       1818 00105$:
                                   1819 ;	quantum/action_util.c:469: if (changed) host_keyboard_send(keyboard_report);
      0085A3 90 0A F0         [24] 1820 	mov	dptr,#_send_keyboard_report_changed_10001_396
      0085A6 E0               [24] 1821 	movx	a,@dptr
      0085A7 60 09            [24] 1822 	jz	00111$
      0085A9 90 0D FB         [24] 1823 	mov	dptr,#_actual_keyboard_report
      0085AC 75 F0 00         [24] 1824 	mov	b, #0x00
                                   1825 ;	quantum/action_util.c:477: }
      0085AF 02 71 24         [24] 1826 	ljmp	_host_keyboard_send
      0085B2                       1827 00111$:
      0085B2 22               [24] 1828 	ret
                                   1829 ;------------------------------------------------------------
                                   1830 ;Allocation info for local variables in function 'get_mods'
                                   1831 ;------------------------------------------------------------
                                   1832 ;	quantum/action_util.c:483: uint8_t get_mods(void) {
                                   1833 ;	-----------------------------------------
                                   1834 ;	 function get_mods
                                   1835 ;	-----------------------------------------
      0085B3                       1836 _get_mods:
      0085B3 C0 07            [24] 1837 	push	ar7
                                   1838 ;	quantum/action_util.c:488: ;
      0085B5 90 09 B7         [24] 1839 	mov	dptr,#_owned_mods
      0085B8 E0               [24] 1840 	movx	a,@dptr
      0085B9 FF               [12] 1841 	mov	r7,a
      0085BA 90 0D F9         [24] 1842 	mov	dptr,#_real_mods
      0085BD 12 80 65         [24] 1843 	lcall	_ak820_outline_0145
                                   1844 ;	quantum/action_util.c:489: }
      0085C0 D0 07            [24] 1845 	pop	ar7
      0085C2 22               [24] 1846 	ret
                                   1847 ;------------------------------------------------------------
                                   1848 ;Allocation info for local variables in function 'add_mods'
                                   1849 ;------------------------------------------------------------
                                   1850 ;mods          Allocated with name '_add_mods_mods_10000_404'
                                   1851 ;------------------------------------------------------------
                                   1852 ;	quantum/action_util.c:494: void add_mods(uint8_t mods) {
                                   1853 ;	-----------------------------------------
                                   1854 ;	 function clear_mods
                                   1855 ;	-----------------------------------------
      0085C3                       1856 _clear_mods:
                                   1857 ;	quantum/action_util.c:516: real_mods = 0;
      0085C3 90 0D F9         [24] 1858 	mov	dptr,#_real_mods
      0085C6 E4               [12] 1859 	clr	a
      0085C7 F0               [24] 1860 	movx	@dptr,a
                                   1861 ;	quantum/action_util.c:517: }
      0085C8 22               [24] 1862 	ret
                                   1863 ;------------------------------------------------------------
                                   1864 ;Allocation info for local variables in function 'get_weak_mods'
                                   1865 ;------------------------------------------------------------
                                   1866 ;	quantum/action_util.c:523: uint8_t get_weak_mods(void) {
                                   1867 ;	-----------------------------------------
                                   1868 ;	 function get_weak_mods
                                   1869 ;	-----------------------------------------
      0085C9                       1870 _get_weak_mods:
      0085C9 C0 07            [24] 1871 	push	ar7
                                   1872 ;	quantum/action_util.c:528: ;
      0085CB 90 09 B8         [24] 1873 	mov	dptr,#_owned_weak_mods
      0085CE E0               [24] 1874 	movx	a,@dptr
      0085CF FF               [12] 1875 	mov	r7,a
      0085D0 90 0D FA         [24] 1876 	mov	dptr,#_weak_mods
      0085D3 12 80 65         [24] 1877 	lcall	_ak820_outline_0145
                                   1878 ;	quantum/action_util.c:529: }
      0085D6 D0 07            [24] 1879 	pop	ar7
      0085D8 22               [24] 1880 	ret
                                   1881 ;------------------------------------------------------------
                                   1882 ;Allocation info for local variables in function 'add_weak_mods'
                                   1883 ;------------------------------------------------------------
                                   1884 ;mods          Allocated with name '_add_weak_mods_mods_10000_414'
                                   1885 ;------------------------------------------------------------
                                   1886 ;	quantum/action_util.c:534: void add_weak_mods(uint8_t mods) {
                                   1887 ;	-----------------------------------------
                                   1888 ;	 function add_weak_mods
                                   1889 ;	-----------------------------------------
      0085D9                       1890 _add_weak_mods:
      0085D9 E5 82            [12] 1891 	mov	a,dpl
      0085DB 90 0A F1         [24] 1892 	mov	dptr,#_add_weak_mods_mods_10000_414
      0085DE F0               [24] 1893 	movx	@dptr,a
                                   1894 ;	quantum/action_util.c:535: weak_mods |= mods;
      0085DF E0               [24] 1895 	movx	a,@dptr
      0085E0 FF               [12] 1896 	mov	r7,a
      0085E1 90 0D FA         [24] 1897 	mov	dptr,#_weak_mods
      0085E4 E0               [24] 1898 	movx	a,@dptr
      0085E5 4F               [12] 1899 	orl	a,r7
      0085E6 F0               [24] 1900 	movx	@dptr,a
                                   1901 ;	quantum/action_util.c:536: }
      0085E7 22               [24] 1902 	ret
                                   1903 ;------------------------------------------------------------
                                   1904 ;Allocation info for local variables in function 'del_weak_mods'
                                   1905 ;------------------------------------------------------------
                                   1906 ;mods          Allocated with name '_del_weak_mods_mods_10000_416'
                                   1907 ;------------------------------------------------------------
                                   1908 ;	quantum/action_util.c:541: void del_weak_mods(uint8_t mods) {
                                   1909 ;	-----------------------------------------
                                   1910 ;	 function del_weak_mods
                                   1911 ;	-----------------------------------------
      0085E8                       1912 _del_weak_mods:
      0085E8 E5 82            [12] 1913 	mov	a,dpl
      0085EA 90 0A F2         [24] 1914 	mov	dptr,#_del_weak_mods_mods_10000_416
      0085ED F0               [24] 1915 	movx	@dptr,a
                                   1916 ;	quantum/action_util.c:542: weak_mods &= ~mods;
      0085EE E0               [24] 1917 	movx	a,@dptr
      0085EF F4               [12] 1918 	cpl	a
      0085F0 FF               [12] 1919 	mov	r7,a
      0085F1 90 0D FA         [24] 1920 	mov	dptr,#_weak_mods
      0085F4 E0               [24] 1921 	movx	a,@dptr
      0085F5 5F               [12] 1922 	anl	a,r7
      0085F6 F0               [24] 1923 	movx	@dptr,a
                                   1924 ;	quantum/action_util.c:543: }
      0085F7 22               [24] 1925 	ret
                                   1926 ;------------------------------------------------------------
                                   1927 ;Allocation info for local variables in function 'set_weak_mods'
                                   1928 ;------------------------------------------------------------
                                   1929 ;mods          Allocated with name '_set_weak_mods_mods_10000_418'
                                   1930 ;------------------------------------------------------------
                                   1931 ;	quantum/action_util.c:548: void set_weak_mods(uint8_t mods) {
                                   1932 ;	-----------------------------------------
                                   1933 ;	 function clear_weak_mods
                                   1934 ;	-----------------------------------------
      0085F8                       1935 _clear_weak_mods:
                                   1936 ;	quantum/action_util.c:556: weak_mods = 0;
      0085F8 90 0D FA         [24] 1937 	mov	dptr,#_weak_mods
      0085FB E4               [12] 1938 	clr	a
      0085FC F0               [24] 1939 	movx	@dptr,a
                                   1940 ;	quantum/action_util.c:557: }
      0085FD 22               [24] 1941 	ret
                                   1942 ;------------------------------------------------------------
                                   1943 ;Allocation info for local variables in function 'oneshot_locked_mods_changed_user'
                                   1944 ;------------------------------------------------------------
                                   1945 ;mods          Allocated with name '_oneshot_locked_mods_changed_user_mods_10000_422'
                                   1946 ;------------------------------------------------------------
                                   1947 ;	quantum/action_util.c:639: __attribute__((weak)) void oneshot_locked_mods_changed_user(uint8_t mods) {}
                                   1948 ;	-----------------------------------------
                                   1949 	.area CSEG    (CODE)
                                   1950 	.area CONST   (CODE)
                                   1951 	.area XINIT   (CODE)
      00C63B                       1952 __xinit__real_mods:
      00C63B 00                    1953 	.db #0x00	; 0
      00C63C                       1954 __xinit__weak_mods:
      00C63C 00                    1955 	.db #0x00	; 0
      00C63D                       1956 __xinit__actual_keyboard_report:
      00C63D 00                    1957 	.db #0x00	; 0
      00C63E 00                    1958 	.db #0x00	; 0
      00C63F 00                    1959 	.db #0x00	; 0
      00C640 00                    1960 	.db #0x00	; 0
      00C641 00                    1961 	.db #0x00	; 0
      00C642 00                    1962 	.db #0x00	; 0
      00C643 00                    1963 	.db #0x00	; 0
      00C644 00                    1964 	.db #0x00	; 0
      00C645 00                    1965 	.db 0x00
      00C646 00                    1966 	.db 0x00
      00C647 00                    1967 	.db 0x00
      00C648 00                    1968 	.db 0x00
      00C649 00                    1969 	.db 0x00
      00C64A 00                    1970 	.db 0x00
      00C64B 00                    1971 	.db 0x00
      00C64C 00                    1972 	.db 0x00
      00C64D 00                    1973 	.db 0x00
      00C64E 00                    1974 	.db 0x00
      00C64F 00                    1975 	.db 0x00
      00C650 00                    1976 	.db 0x00
      00C651 00                    1977 	.db 0x00
      00C652 00                    1978 	.db 0x00
      00C653 00                    1979 	.db 0x00
      00C654 00                    1980 	.db 0x00
      00C655 00                    1981 	.db 0x00
      00C656 00                    1982 	.db 0x00
      00C657 00                    1983 	.db 0x00
      00C658 00                    1984 	.db 0x00
      00C659 00                    1985 	.db 0x00
      00C65A 00                    1986 	.db 0x00
      00C65B 00                    1987 	.db 0x00
      00C65C 00                    1988 	.db 0x00
                                   1989 	.area CABS    (ABS,CODE)
                                   1990 
                                   1991 ; Experimental exact instruction outlining.
                                   1992 	.globl _ak820_outline_0017
                                   1993 	.globl _ak820_outline_0030
                                   1994 	.globl _ak820_outline_0052
                                   1995 	.globl _ak820_outline_0057
                                   1996 	.globl _ak820_outline_0058
                                   1997 	.globl _ak820_outline_0061
                                   1998 	.globl _ak820_outline_0063
                                   1999 	.globl _ak820_outline_0064
                                   2000 	.globl _ak820_outline_0065
                                   2001 	.globl _ak820_outline_0068
                                   2002 	.globl _ak820_outline_0075
                                   2003 	.globl _ak820_outline_0109
                                   2004 	.globl _ak820_outline_0110
                                   2005 	.globl _ak820_outline_0119
                                   2006 	.globl _ak820_outline_0123
                                   2007 	.globl _ak820_outline_0125
                                   2008 	.globl _ak820_outline_0127
                                   2009 	.globl _ak820_outline_0134
                                   2010 	.globl _ak820_outline_0135
                                   2011 	.globl _ak820_outline_0137
                                   2012 	.globl _ak820_outline_0141
                                   2013 	.globl _ak820_outline_0145
                                   2014 	.globl _ak820_outline_0163
                                   2015 	.globl _ak820_outline_0164
                                   2016 	.globl _ak820_outline_0168
                                   2017 	.globl _ak820_outline_0184
                                   2018 	.globl _ak820_outline_0190
                                   2019 	.globl _ak820_outline_0191
                                   2020 	.globl _ak820_outline_0192
                                   2021 
                                   2022 	.area CSEG (CODE)
                                   2023 ; function ak820_outline_0030
      0085FE                       2024 _ak820_outline_0030:
      0085FE EF               [12] 2025 	mov	a,r7
      0085FF 24 C9            [12] 2026 	add	a,#_key_refs
      008601 FD               [12] 2027 	mov	r5,a
      008602 E4               [12] 2028 	clr	a
      008603 34 09            [12] 2029 	addc	a,#(_key_refs>>8)
      008605 FE               [12] 2030 	mov	r6,a
      008606 8D 82            [24] 2031 	mov	dpl,r5
      008608 8E 83            [24] 2032 	mov	dph,r6
      00860A E0               [24] 2033 	movx	a,@dptr
      00860B 22               [24] 2034 	ret
                                   2035 
                                   2036 	.area CSEG (CODE)
                                   2037 ; function ak820_outline_0058
      00860C                       2038 _ak820_outline_0058:
      00860C F0               [24] 2039 	movx	@dptr,a
      00860D 90 0D FB         [24] 2040 	mov	dptr,#_actual_keyboard_report
      008610 75 F0 00         [24] 2041 	mov	b,#0x00
      008613 22               [24] 2042 	ret
                                   2043 
                                   2044 	.area CSEG (CODE)
                                   2045 ; function ak820_outline_0064
      008614                       2046 _ak820_outline_0064:
      008614 89 82            [24] 2047 	mov	dpl,r1
      008616 8A 83            [24] 2048 	mov	dph,r2
      008618 E8               [12] 2049 	mov	a,r0
      008619 F0               [24] 2050 	movx	@dptr,a
      00861A 22               [24] 2051 	ret
                                   2052 
                                   2053 	.area CSEG (CODE)
                                   2054 ; function ak820_outline_0068
      00861B                       2055 _ak820_outline_0068:
      00861B 24 A4            [12] 2056 	add	a,#_usage_order
      00861D F5 82            [12] 2057 	mov	dpl,a
      00861F E4               [12] 2058 	clr	a
      008620 34 0A            [12] 2059 	addc	a,#(_usage_order>>8)
      008622 F5 83            [12] 2060 	mov	dph,a
      008624 22               [24] 2061 	ret
                                   2062 
                                   2063 	.area CSEG (CODE)
                                   2064 ; function ak820_outline_0075
      008625                       2065 _ak820_outline_0075:
      008625 EB               [12] 2066 	mov	a,r3
      008626 24 86            [12] 2067 	add	a,#_usage_refs
      008628 F9               [12] 2068 	mov	r1,a
      008629 E4               [12] 2069 	clr	a
      00862A 34 0A            [12] 2070 	addc	a,#(_usage_refs>>8)
      00862C FA               [12] 2071 	mov	r2,a
      00862D 89 82            [24] 2072 	mov	dpl,r1
      00862F 8A 83            [24] 2073 	mov	dph,r2
      008631 E0               [24] 2074 	movx	a,@dptr
      008632 F8               [12] 2075 	mov	r0,a
      008633 22               [24] 2076 	ret
                                   2077 
                                   2078 	.area CSEG (CODE)
                                   2079 ; function ak820_outline_0119
      008634                       2080 _ak820_outline_0119:
      008634 F0               [24] 2081 	movx	@dptr,a
      008635 E0               [24] 2082 	movx	a,@dptr
      008636 FF               [12] 2083 	mov	r7,a
      008637 90 09 C1         [24] 2084 	mov	dptr,#_change_owned_PARM_2
      00863A 22               [24] 2085 	ret
                                   2086 
                                   2087 	.area CSEG (CODE)
                                   2088 ; function ak820_outline_0123
      00863B                       2089 _ak820_outline_0123:
      00863B 8D 82            [24] 2090 	mov	dpl,r5
      00863D 8E 83            [24] 2091 	mov	dph,r6
      00863F F0               [24] 2092 	movx	@dptr,a
      008640 22               [24] 2093 	ret
                                   2094 
                                   2095 	.area CSEG (CODE)
                                   2096 ; function ak820_outline_0127
      008641                       2097 _ak820_outline_0127:
      008641 24 A4            [12] 2098 	add	a,#_usage_order
      008643 F5 82            [12] 2099 	mov	dpl,a
      008645 EF               [12] 2100 	mov	a,r7
      008646 34 0A            [12] 2101 	addc	a,#(_usage_order>>8)
      008648 F5 83            [12] 2102 	mov	dph,a
      00864A E0               [24] 2103 	movx	a,@dptr
      00864B 22               [24] 2104 	ret
                                   2105 
                                   2106 	.area CSEG (CODE)
                                   2107 ; function ak820_outline_0134
      00864C                       2108 _ak820_outline_0134:
      00864C F0               [24] 2109 	movx	@dptr,a
      00864D E0               [24] 2110 	movx	a,@dptr
      00864E FF               [12] 2111 	mov	r7,a
      00864F 90 09 BD         [24] 2112 	mov	dptr,#_ak820_macro_change_PARM_2
      008652 F0               [24] 2113 	movx	@dptr,a
      008653 90 09 BE         [24] 2114 	mov	dptr,#_ak820_macro_change_PARM_3
      008656 22               [24] 2115 	ret
                                   2116 
                                   2117 	.area CSEG (CODE)
                                   2118 ; function ak820_outline_0192
      008657                       2119 _ak820_outline_0192:
      008657 8D 82            [24] 2120 	mov	dpl,r5
      008659 8F 83            [24] 2121 	mov	dph,r7
      00865B 22               [24] 2122 	ret
