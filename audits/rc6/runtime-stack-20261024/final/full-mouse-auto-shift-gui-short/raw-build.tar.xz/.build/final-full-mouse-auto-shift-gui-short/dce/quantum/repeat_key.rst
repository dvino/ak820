                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module repeat_key
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _unregister_weak_mods
                                     12 	.globl _register_weak_mods
                                     13 	.globl _process_record
                                     14 	.globl _memset
                                     15 	.globl _ADC_START
                                     16 	.globl _S0_R_FIFO
                                     17 	.globl _S0_T_FIFO
                                     18 	.globl _S0_FREE
                                     19 	.globl _S0_IF_BYTE
                                     20 	.globl _S0_IF_FIRST
                                     21 	.globl _S0_IF_OV
                                     22 	.globl _S0_FST_ACT
                                     23 	.globl _CP_RL2
                                     24 	.globl _C_T2
                                     25 	.globl _TR2
                                     26 	.globl _EXEN2
                                     27 	.globl _TCLK
                                     28 	.globl _RCLK
                                     29 	.globl _EXF2
                                     30 	.globl _CAP1F
                                     31 	.globl _TF2
                                     32 	.globl _RI
                                     33 	.globl _TI
                                     34 	.globl _RB8
                                     35 	.globl _TB8
                                     36 	.globl _REN
                                     37 	.globl _SM2
                                     38 	.globl _SM1
                                     39 	.globl _SM0
                                     40 	.globl _IT0
                                     41 	.globl _IE0
                                     42 	.globl _IT1
                                     43 	.globl _IE1
                                     44 	.globl _TR0
                                     45 	.globl _TF0
                                     46 	.globl _TR1
                                     47 	.globl _TF1
                                     48 	.globl _P4_0
                                     49 	.globl _P4_1
                                     50 	.globl _P4_2
                                     51 	.globl _P4_3
                                     52 	.globl _P4_4
                                     53 	.globl _P4_5
                                     54 	.globl _P4_6
                                     55 	.globl _RXD
                                     56 	.globl _TXD
                                     57 	.globl _INT0
                                     58 	.globl _INT1
                                     59 	.globl _T0
                                     60 	.globl _T1
                                     61 	.globl _MOSI1
                                     62 	.globl _MISO1
                                     63 	.globl _SCK1
                                     64 	.globl _P3_0
                                     65 	.globl _P3_1
                                     66 	.globl _P3_2
                                     67 	.globl _P3_3
                                     68 	.globl _P3_4
                                     69 	.globl _P3_5
                                     70 	.globl _P3_6
                                     71 	.globl _P3_7
                                     72 	.globl _CAP1_
                                     73 	.globl _T2_
                                     74 	.globl _CAP2_
                                     75 	.globl _T2EX_
                                     76 	.globl _RXD1
                                     77 	.globl _TXD1
                                     78 	.globl _P2_0
                                     79 	.globl _P2_1
                                     80 	.globl _P2_2
                                     81 	.globl _P2_3
                                     82 	.globl _P2_4
                                     83 	.globl _P2_5
                                     84 	.globl _P2_6
                                     85 	.globl _P2_7
                                     86 	.globl _AIN0
                                     87 	.globl _AIN1
                                     88 	.globl _AIN2
                                     89 	.globl _AIN3
                                     90 	.globl _AIN4
                                     91 	.globl _AIN5
                                     92 	.globl _AIN6
                                     93 	.globl _AIN7
                                     94 	.globl _CAP1
                                     95 	.globl _T2
                                     96 	.globl _CAP2
                                     97 	.globl _T2EX
                                     98 	.globl _INT0_
                                     99 	.globl _SCS
                                    100 	.globl _MOSI
                                    101 	.globl _MISO
                                    102 	.globl _SCK
                                    103 	.globl _RXD1_
                                    104 	.globl _TXD1_
                                    105 	.globl _P1_0
                                    106 	.globl _P1_1
                                    107 	.globl _P1_2
                                    108 	.globl _P1_3
                                    109 	.globl _P1_4
                                    110 	.globl _P1_5
                                    111 	.globl _P1_6
                                    112 	.globl _P1_7
                                    113 	.globl _AIN8
                                    114 	.globl _AIN9
                                    115 	.globl _AIN10
                                    116 	.globl _AIN11
                                    117 	.globl _AIN12
                                    118 	.globl _AIN13
                                    119 	.globl _RXD_
                                    120 	.globl _TXD_
                                    121 	.globl _SCL0
                                    122 	.globl _SDA0
                                    123 	.globl _P0_0
                                    124 	.globl _P0_1
                                    125 	.globl _P0_2
                                    126 	.globl _P0_3
                                    127 	.globl _P0_4
                                    128 	.globl _P0_5
                                    129 	.globl _P0_6
                                    130 	.globl _P0_7
                                    131 	.globl _IE_SPI0
                                    132 	.globl _IE_USB
                                    133 	.globl _IE_ADC
                                    134 	.globl _IE_UART1
                                    135 	.globl _IE_PWM_I2C
                                    136 	.globl _IE_GPIO
                                    137 	.globl _IE_WDOG
                                    138 	.globl _PX0
                                    139 	.globl _PT0
                                    140 	.globl _PX1
                                    141 	.globl _PT1
                                    142 	.globl _PS
                                    143 	.globl _PT2
                                    144 	.globl _PL_FLAG
                                    145 	.globl _PH_FLAG
                                    146 	.globl _EX0
                                    147 	.globl _ET0
                                    148 	.globl _EX1
                                    149 	.globl _ET1
                                    150 	.globl _ES
                                    151 	.globl _ET2
                                    152 	.globl _E_DIS
                                    153 	.globl _EA
                                    154 	.globl _P
                                    155 	.globl _F1
                                    156 	.globl _OV
                                    157 	.globl _RS0
                                    158 	.globl _RS1
                                    159 	.globl _F0
                                    160 	.globl _AC
                                    161 	.globl _CY
                                    162 	.globl _I2CS_INT_ST
                                    163 	.globl _I2CX_INT
                                    164 	.globl _LED_STATUS
                                    165 	.globl _LED_DMA_H
                                    166 	.globl _LED_DMA_L
                                    167 	.globl _LED_DMA
                                    168 	.globl _LED_PWM_OE
                                    169 	.globl _LED_COMMON
                                    170 	.globl _ADC_CHAN
                                    171 	.globl _ADC_DAT_H
                                    172 	.globl _ADC_DAT_L
                                    173 	.globl _ADC_DAT
                                    174 	.globl _ADC_CTRL
                                    175 	.globl _SPI1_CK_SE
                                    176 	.globl _SPI1_CTRL
                                    177 	.globl _SPI1_DATA
                                    178 	.globl _SPI1_STAT
                                    179 	.globl _SIF1
                                    180 	.globl _SBAUD1
                                    181 	.globl _SBUF1
                                    182 	.globl _SCON1
                                    183 	.globl _SPI0_SETUP
                                    184 	.globl _SPI0_CK_SE
                                    185 	.globl _SPI0_CTRL
                                    186 	.globl _SPI0_DATA
                                    187 	.globl _SPI0_STAT
                                    188 	.globl _T2CAP1H
                                    189 	.globl _T2CAP1L
                                    190 	.globl _T2CAP1
                                    191 	.globl _TH2
                                    192 	.globl _TL2
                                    193 	.globl _T2COUNT
                                    194 	.globl _RCAP2H
                                    195 	.globl _RCAP2L
                                    196 	.globl _RCAP2
                                    197 	.globl _T2MOD
                                    198 	.globl _T2CON
                                    199 	.globl _SBUF
                                    200 	.globl _SCON
                                    201 	.globl _TH1
                                    202 	.globl _TH0
                                    203 	.globl _TL1
                                    204 	.globl _TL0
                                    205 	.globl _TMOD
                                    206 	.globl _TCON
                                    207 	.globl _XBUS_AUX
                                    208 	.globl _P7
                                    209 	.globl _P6_DIR
                                    210 	.globl _P6_OUT_PU
                                    211 	.globl _P6_IN
                                    212 	.globl _P5_DIR
                                    213 	.globl _P5_OUT_PU
                                    214 	.globl _P5_IN
                                    215 	.globl _P4_LED_KEY
                                    216 	.globl _P4_DIR_PU
                                    217 	.globl _P4_MOD_OC
                                    218 	.globl _P4
                                    219 	.globl _P3_DIR_PU
                                    220 	.globl _P3_MOD_OC
                                    221 	.globl _P3
                                    222 	.globl _P2_DIR_PU
                                    223 	.globl _P2_MOD_OC
                                    224 	.globl _P2
                                    225 	.globl _P1_DIR_PU
                                    226 	.globl _P1_MOD_OC
                                    227 	.globl _P1
                                    228 	.globl _P0_DIR_PU
                                    229 	.globl _P0_MOD_OC
                                    230 	.globl _P0
                                    231 	.globl _ROM_CTRL
                                    232 	.globl _ROM_DATA_HH
                                    233 	.globl _ROM_DATA_HL
                                    234 	.globl _ROM_DATA_HI
                                    235 	.globl _ROM_ADDR_H
                                    236 	.globl _ROM_ADDR_L
                                    237 	.globl _ROM_ADDR
                                    238 	.globl _GPIO_IE
                                    239 	.globl _IP_EX
                                    240 	.globl _IE_EX
                                    241 	.globl _IP
                                    242 	.globl _IE
                                    243 	.globl _WDOG_COUNT
                                    244 	.globl _RESET_KEEP
                                    245 	.globl _WAKE_CTRL
                                    246 	.globl _CLOCK_CFG
                                    247 	.globl _POWER_CFG
                                    248 	.globl _PCON
                                    249 	.globl _GLOBAL_CFG
                                    250 	.globl _SAFE_MOD
                                    251 	.globl _DPH
                                    252 	.globl _DPL
                                    253 	.globl _SP
                                    254 	.globl _A_INV
                                    255 	.globl _B
                                    256 	.globl _ACC
                                    257 	.globl _PSW
                                    258 	.globl _get_alt_repeat_key_keycode_user_PARM_2
                                    259 	.globl _set_last_record_PARM_2
                                    260 	.globl _repeat_key_cancel
                                    261 	.globl _set_last_mods
                                    262 	.globl _set_last_record
                                    263 	.globl _get_repeat_key_count
                                    264 	.globl _repeat_key_invoke
                                    265 	.globl _get_alt_repeat_key_keycode
                                    266 	.globl _alt_repeat_key_invoke
                                    267 	.globl _get_alt_repeat_key_keycode_user
                                    268 ;--------------------------------------------------------
                                    269 ; special function registers
                                    270 ;--------------------------------------------------------
                                    271 	.area RSEG    (ABS,DATA)
      000000                        272 	.org 0x0000
                           0000D0   273 _PSW	=	0x00d0
                           0000E0   274 _ACC	=	0x00e0
                           0000F0   275 _B	=	0x00f0
                           0000FD   276 _A_INV	=	0x00fd
                           000081   277 _SP	=	0x0081
                           000082   278 _DPL	=	0x0082
                           000083   279 _DPH	=	0x0083
                           0000A1   280 _SAFE_MOD	=	0x00a1
                           0000B1   281 _GLOBAL_CFG	=	0x00b1
                           000087   282 _PCON	=	0x0087
                           0000BA   283 _POWER_CFG	=	0x00ba
                           0000B9   284 _CLOCK_CFG	=	0x00b9
                           0000A9   285 _WAKE_CTRL	=	0x00a9
                           0000FE   286 _RESET_KEEP	=	0x00fe
                           0000FF   287 _WDOG_COUNT	=	0x00ff
                           0000A8   288 _IE	=	0x00a8
                           0000B8   289 _IP	=	0x00b8
                           0000E8   290 _IE_EX	=	0x00e8
                           0000E9   291 _IP_EX	=	0x00e9
                           0000B2   292 _GPIO_IE	=	0x00b2
                           008584   293 _ROM_ADDR	=	0x8584
                           000084   294 _ROM_ADDR_L	=	0x0084
                           000085   295 _ROM_ADDR_H	=	0x0085
                           008F8E   296 _ROM_DATA_HI	=	0x8f8e
                           00008E   297 _ROM_DATA_HL	=	0x008e
                           00008F   298 _ROM_DATA_HH	=	0x008f
                           000086   299 _ROM_CTRL	=	0x0086
                           000080   300 _P0	=	0x0080
                           0000C4   301 _P0_MOD_OC	=	0x00c4
                           0000C5   302 _P0_DIR_PU	=	0x00c5
                           000090   303 _P1	=	0x0090
                           000092   304 _P1_MOD_OC	=	0x0092
                           000093   305 _P1_DIR_PU	=	0x0093
                           0000A0   306 _P2	=	0x00a0
                           000094   307 _P2_MOD_OC	=	0x0094
                           000095   308 _P2_DIR_PU	=	0x0095
                           0000B0   309 _P3	=	0x00b0
                           000096   310 _P3_MOD_OC	=	0x0096
                           000097   311 _P3_DIR_PU	=	0x0097
                           0000C0   312 _P4	=	0x00c0
                           0000C2   313 _P4_MOD_OC	=	0x00c2
                           0000C3   314 _P4_DIR_PU	=	0x00c3
                           0000C1   315 _P4_LED_KEY	=	0x00c1
                           0000AA   316 _P5_IN	=	0x00aa
                           0000AB   317 _P5_OUT_PU	=	0x00ab
                           0000AC   318 _P5_DIR	=	0x00ac
                           0000AD   319 _P6_IN	=	0x00ad
                           0000AE   320 _P6_OUT_PU	=	0x00ae
                           0000AF   321 _P6_DIR	=	0x00af
                           0000F1   322 _P7	=	0x00f1
                           0000A2   323 _XBUS_AUX	=	0x00a2
                           000088   324 _TCON	=	0x0088
                           000089   325 _TMOD	=	0x0089
                           00008A   326 _TL0	=	0x008a
                           00008B   327 _TL1	=	0x008b
                           00008C   328 _TH0	=	0x008c
                           00008D   329 _TH1	=	0x008d
                           000098   330 _SCON	=	0x0098
                           000099   331 _SBUF	=	0x0099
                           0000C8   332 _T2CON	=	0x00c8
                           0000C9   333 _T2MOD	=	0x00c9
                           00CBCA   334 _RCAP2	=	0xcbca
                           0000CA   335 _RCAP2L	=	0x00ca
                           0000CB   336 _RCAP2H	=	0x00cb
                           00CDCC   337 _T2COUNT	=	0xcdcc
                           0000CC   338 _TL2	=	0x00cc
                           0000CD   339 _TH2	=	0x00cd
                           00CFCE   340 _T2CAP1	=	0xcfce
                           0000CE   341 _T2CAP1L	=	0x00ce
                           0000CF   342 _T2CAP1H	=	0x00cf
                           0000F8   343 _SPI0_STAT	=	0x00f8
                           0000F9   344 _SPI0_DATA	=	0x00f9
                           0000FA   345 _SPI0_CTRL	=	0x00fa
                           0000FB   346 _SPI0_CK_SE	=	0x00fb
                           0000FC   347 _SPI0_SETUP	=	0x00fc
                           0000BC   348 _SCON1	=	0x00bc
                           0000BD   349 _SBUF1	=	0x00bd
                           0000BE   350 _SBAUD1	=	0x00be
                           0000BF   351 _SIF1	=	0x00bf
                           0000B4   352 _SPI1_STAT	=	0x00b4
                           0000B5   353 _SPI1_DATA	=	0x00b5
                           0000B6   354 _SPI1_CTRL	=	0x00b6
                           0000B7   355 _SPI1_CK_SE	=	0x00b7
                           0000F3   356 _ADC_CTRL	=	0x00f3
                           00F5F4   357 _ADC_DAT	=	0xf5f4
                           0000F4   358 _ADC_DAT_L	=	0x00f4
                           0000F5   359 _ADC_DAT_H	=	0x00f5
                           0000F6   360 _ADC_CHAN	=	0x00f6
                           0000A6   361 _LED_COMMON	=	0x00a6
                           0000A7   362 _LED_PWM_OE	=	0x00a7
                           00C7C6   363 _LED_DMA	=	0xc7c6
                           0000C6   364 _LED_DMA_L	=	0x00c6
                           0000C7   365 _LED_DMA_H	=	0x00c7
                           0000F7   366 _LED_STATUS	=	0x00f7
                           0000B3   367 _I2CX_INT	=	0x00b3
                           0000BB   368 _I2CS_INT_ST	=	0x00bb
                                    369 ;--------------------------------------------------------
                                    370 ; special function bits
                                    371 ;--------------------------------------------------------
                                    372 	.area RSEG    (ABS,DATA)
      000000                        373 	.org 0x0000
                           0000D7   374 _CY	=	0x00d7
                           0000D6   375 _AC	=	0x00d6
                           0000D5   376 _F0	=	0x00d5
                           0000D4   377 _RS1	=	0x00d4
                           0000D3   378 _RS0	=	0x00d3
                           0000D2   379 _OV	=	0x00d2
                           0000D1   380 _F1	=	0x00d1
                           0000D0   381 _P	=	0x00d0
                           0000AF   382 _EA	=	0x00af
                           0000AE   383 _E_DIS	=	0x00ae
                           0000AD   384 _ET2	=	0x00ad
                           0000AC   385 _ES	=	0x00ac
                           0000AB   386 _ET1	=	0x00ab
                           0000AA   387 _EX1	=	0x00aa
                           0000A9   388 _ET0	=	0x00a9
                           0000A8   389 _EX0	=	0x00a8
                           0000BF   390 _PH_FLAG	=	0x00bf
                           0000BE   391 _PL_FLAG	=	0x00be
                           0000BD   392 _PT2	=	0x00bd
                           0000BC   393 _PS	=	0x00bc
                           0000BB   394 _PT1	=	0x00bb
                           0000BA   395 _PX1	=	0x00ba
                           0000B9   396 _PT0	=	0x00b9
                           0000B8   397 _PX0	=	0x00b8
                           0000EF   398 _IE_WDOG	=	0x00ef
                           0000EE   399 _IE_GPIO	=	0x00ee
                           0000ED   400 _IE_PWM_I2C	=	0x00ed
                           0000EC   401 _IE_UART1	=	0x00ec
                           0000EB   402 _IE_ADC	=	0x00eb
                           0000E9   403 _IE_USB	=	0x00e9
                           0000E8   404 _IE_SPI0	=	0x00e8
                           000087   405 _P0_7	=	0x0087
                           000086   406 _P0_6	=	0x0086
                           000085   407 _P0_5	=	0x0085
                           000084   408 _P0_4	=	0x0084
                           000083   409 _P0_3	=	0x0083
                           000082   410 _P0_2	=	0x0082
                           000081   411 _P0_1	=	0x0081
                           000080   412 _P0_0	=	0x0080
                           000081   413 _SDA0	=	0x0081
                           000080   414 _SCL0	=	0x0080
                           000083   415 _TXD_	=	0x0083
                           000082   416 _RXD_	=	0x0082
                           000085   417 _AIN13	=	0x0085
                           000084   418 _AIN12	=	0x0084
                           000083   419 _AIN11	=	0x0083
                           000082   420 _AIN10	=	0x0082
                           000081   421 _AIN9	=	0x0081
                           000080   422 _AIN8	=	0x0080
                           000097   423 _P1_7	=	0x0097
                           000096   424 _P1_6	=	0x0096
                           000095   425 _P1_5	=	0x0095
                           000094   426 _P1_4	=	0x0094
                           000093   427 _P1_3	=	0x0093
                           000092   428 _P1_2	=	0x0092
                           000091   429 _P1_1	=	0x0091
                           000090   430 _P1_0	=	0x0090
                           000097   431 _TXD1_	=	0x0097
                           000096   432 _RXD1_	=	0x0096
                           000097   433 _SCK	=	0x0097
                           000096   434 _MISO	=	0x0096
                           000095   435 _MOSI	=	0x0095
                           000094   436 _SCS	=	0x0094
                           000092   437 _INT0_	=	0x0092
                           000091   438 _T2EX	=	0x0091
                           000091   439 _CAP2	=	0x0091
                           000090   440 _T2	=	0x0090
                           000090   441 _CAP1	=	0x0090
                           000097   442 _AIN7	=	0x0097
                           000096   443 _AIN6	=	0x0096
                           000095   444 _AIN5	=	0x0095
                           000094   445 _AIN4	=	0x0094
                           000093   446 _AIN3	=	0x0093
                           000092   447 _AIN2	=	0x0092
                           000091   448 _AIN1	=	0x0091
                           000090   449 _AIN0	=	0x0090
                           0000A7   450 _P2_7	=	0x00a7
                           0000A6   451 _P2_6	=	0x00a6
                           0000A5   452 _P2_5	=	0x00a5
                           0000A4   453 _P2_4	=	0x00a4
                           0000A3   454 _P2_3	=	0x00a3
                           0000A2   455 _P2_2	=	0x00a2
                           0000A1   456 _P2_1	=	0x00a1
                           0000A0   457 _P2_0	=	0x00a0
                           0000A7   458 _TXD1	=	0x00a7
                           0000A6   459 _RXD1	=	0x00a6
                           0000A5   460 _T2EX_	=	0x00a5
                           0000A5   461 _CAP2_	=	0x00a5
                           0000A4   462 _T2_	=	0x00a4
                           0000A4   463 _CAP1_	=	0x00a4
                           0000B7   464 _P3_7	=	0x00b7
                           0000B6   465 _P3_6	=	0x00b6
                           0000B5   466 _P3_5	=	0x00b5
                           0000B4   467 _P3_4	=	0x00b4
                           0000B3   468 _P3_3	=	0x00b3
                           0000B2   469 _P3_2	=	0x00b2
                           0000B1   470 _P3_1	=	0x00b1
                           0000B0   471 _P3_0	=	0x00b0
                           0000B7   472 _SCK1	=	0x00b7
                           0000B6   473 _MISO1	=	0x00b6
                           0000B5   474 _MOSI1	=	0x00b5
                           0000B5   475 _T1	=	0x00b5
                           0000B4   476 _T0	=	0x00b4
                           0000B3   477 _INT1	=	0x00b3
                           0000B2   478 _INT0	=	0x00b2
                           0000B1   479 _TXD	=	0x00b1
                           0000B0   480 _RXD	=	0x00b0
                           0000C6   481 _P4_6	=	0x00c6
                           0000C5   482 _P4_5	=	0x00c5
                           0000C4   483 _P4_4	=	0x00c4
                           0000C3   484 _P4_3	=	0x00c3
                           0000C2   485 _P4_2	=	0x00c2
                           0000C1   486 _P4_1	=	0x00c1
                           0000C0   487 _P4_0	=	0x00c0
                           00008F   488 _TF1	=	0x008f
                           00008E   489 _TR1	=	0x008e
                           00008D   490 _TF0	=	0x008d
                           00008C   491 _TR0	=	0x008c
                           00008B   492 _IE1	=	0x008b
                           00008A   493 _IT1	=	0x008a
                           000089   494 _IE0	=	0x0089
                           000088   495 _IT0	=	0x0088
                           00009F   496 _SM0	=	0x009f
                           00009E   497 _SM1	=	0x009e
                           00009D   498 _SM2	=	0x009d
                           00009C   499 _REN	=	0x009c
                           00009B   500 _TB8	=	0x009b
                           00009A   501 _RB8	=	0x009a
                           000099   502 _TI	=	0x0099
                           000098   503 _RI	=	0x0098
                           0000CF   504 _TF2	=	0x00cf
                           0000CF   505 _CAP1F	=	0x00cf
                           0000CE   506 _EXF2	=	0x00ce
                           0000CD   507 _RCLK	=	0x00cd
                           0000CC   508 _TCLK	=	0x00cc
                           0000CB   509 _EXEN2	=	0x00cb
                           0000CA   510 _TR2	=	0x00ca
                           0000C9   511 _C_T2	=	0x00c9
                           0000C8   512 _CP_RL2	=	0x00c8
                           0000FF   513 _S0_FST_ACT	=	0x00ff
                           0000FE   514 _S0_IF_OV	=	0x00fe
                           0000FD   515 _S0_IF_FIRST	=	0x00fd
                           0000FC   516 _S0_IF_BYTE	=	0x00fc
                           0000FB   517 _S0_FREE	=	0x00fb
                           0000FA   518 _S0_T_FIFO	=	0x00fa
                           0000F8   519 _S0_R_FIFO	=	0x00f8
                           0000F7   520 _ADC_START	=	0x00f7
                                    521 ;--------------------------------------------------------
                                    522 ; overlayable register banks
                                    523 ;--------------------------------------------------------
                                    524 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        525 	.ds 8
                                    526 ;--------------------------------------------------------
                                    527 ; internal ram data
                                    528 ;--------------------------------------------------------
                                    529 	.area DSEG    (DATA)
                                    530 ;--------------------------------------------------------
                                    531 ; overlayable items in internal ram
                                    532 ;--------------------------------------------------------
                                    533 ;--------------------------------------------------------
                                    534 ; indirectly addressable internal ram data
                                    535 ;--------------------------------------------------------
                                    536 	.area ISEG    (DATA)
                                    537 ;--------------------------------------------------------
                                    538 ; absolute internal ram data
                                    539 ;--------------------------------------------------------
                                    540 	.area IABS    (ABS,DATA)
                                    541 	.area IABS    (ABS,DATA)
                                    542 ;--------------------------------------------------------
                                    543 ; bit data
                                    544 ;--------------------------------------------------------
                                    545 	.area BSEG    (BIT)
                                    546 ;--------------------------------------------------------
                                    547 ; paged external ram data
                                    548 ;--------------------------------------------------------
                                    549 	.area PSEG    (PAG,XDATA)
                                    550 ;--------------------------------------------------------
                                    551 ; uninitialized external ram data
                                    552 ;--------------------------------------------------------
                                    553 	.area XSEG    (XDATA)
      000C46                        554 _last_record:
      000C46                        555 	.ds 9
      000C4F                        556 _ak820_repeat_invoking:
      000C4F                        557 	.ds 1
      000C50                        558 _registered_record:
      000C50                        559 	.ds 9
      000C59                        560 _registered_repeat_count:
      000C59                        561 	.ds 1
      000C5A                        562 _registered_mods:
      000C5A                        563 	.ds 1
      000C5B                        564 _set_last_mods_mods_10000_170:
      000C5B                        565 	.ds 1
      000C5C                        566 _set_last_record_PARM_2:
      000C5C                        567 	.ds 3
      000C5F                        568 _set_last_record_keycode_10000_172:
      000C5F                        569 	.ds 2
      000C61                        570 _update_last_repeat_count_dir_10000_174:
      000C61                        571 	.ds 1
      000C62                        572 _repeat_invoke_PARM_2:
      000C62                        573 	.ds 1
      000C63                        574 _repeat_invoke_event_10000_182:
      000C63                        575 	.ds 3
      000C66                        576 _repeat_key_invoke_event_10000_197:
      000C66                        577 	.ds 3
      000C69                        578 _find_alt_keycode_PARM_2:
      000C69                        579 	.ds 1
      000C6A                        580 _find_alt_keycode_PARM_3:
      000C6A                        581 	.ds 1
      000C6B                        582 _find_alt_keycode_table_10000_199:
      000C6B                        583 	.ds 3
      000C6E                        584 _get_alt_repeat_key_keycode_keycode_10000_206:
      000C6E                        585 	.ds 2
      000C70                        586 _get_alt_repeat_key_keycode_mods_10000_206:
      000C70                        587 	.ds 1
      000C71                        588 _get_alt_repeat_key_keycode_alt_keycode_10000_206:
      000C71                        589 	.ds 2
      000C73                        590 _alt_repeat_key_invoke_event_10000_220:
      000C73                        591 	.ds 3
      000C76                        592 _get_alt_repeat_key_keycode_user_PARM_2:
      000C76                        593 	.ds 1
                                    594 ;--------------------------------------------------------
                                    595 ; absolute external ram data
                                    596 ;--------------------------------------------------------
                                    597 	.area XABS    (ABS,XDATA)
                                    598 ;--------------------------------------------------------
                                    599 ; initialized external ram data
                                    600 ;--------------------------------------------------------
                                    601 	.area XISEG   (XDATA)
      000E4E                        602 _last_mods:
      000E4E                        603 	.ds 1
      000E4F                        604 _last_repeat_count:
      000E4F                        605 	.ds 1
      000E50                        606 _processing_repeat_count:
      000E50                        607 	.ds 1
                                    608 	.area HOME    (CODE)
                                    609 	.area GSINIT0 (CODE)
                                    610 	.area GSINIT1 (CODE)
                                    611 	.area GSINIT2 (CODE)
                                    612 	.area GSINIT3 (CODE)
                                    613 	.area GSINIT4 (CODE)
                                    614 	.area GSINIT5 (CODE)
                                    615 	.area GSINIT  (CODE)
                                    616 	.area GSFINAL (CODE)
                                    617 	.area CSEG    (CODE)
                                    618 ;--------------------------------------------------------
                                    619 ; global & static initialisations
                                    620 ;--------------------------------------------------------
                                    621 	.area HOME    (CODE)
                                    622 	.area GSINIT  (CODE)
                                    623 	.area GSFINAL (CODE)
                                    624 	.area GSINIT  (CODE)
                                    625 ;--------------------------------------------------------
                                    626 ; Home
                                    627 ;--------------------------------------------------------
                                    628 	.area HOME    (CODE)
                                    629 	.area HOME    (CODE)
                                    630 ;--------------------------------------------------------
                                    631 ; code
                                    632 ;--------------------------------------------------------
                                    633 	.area CSEG    (CODE)
                                    634 ;------------------------------------------------------------
                                    635 ;Allocation info for local variables in function 'repeat_key_cancel'
                                    636 ;------------------------------------------------------------
                                    637 ;	quantum/repeat_key.c:44: void repeat_key_cancel(void) {
                                    638 ;	-----------------------------------------
                                    639 ;	 function repeat_key_cancel
                                    640 ;	-----------------------------------------
      00A699                        641 _repeat_key_cancel:
                           000007   642 	ar7 = 0x07
                           000006   643 	ar6 = 0x06
                           000005   644 	ar5 = 0x05
                           000004   645 	ar4 = 0x04
                           000003   646 	ar3 = 0x03
                           000002   647 	ar2 = 0x02
                           000001   648 	ar1 = 0x01
                           000000   649 	ar0 = 0x00
                                    650 ;	quantum/repeat_key.c:45: registered_record.keycode = 0;
      00A699 90 0C 57         [24]  651 	mov	dptr,#(_registered_record + 0x0007)
      00A69C 12 51 B6         [24]  652 	lcall	_ak820_outline_0184
                                    653 ;	quantum/repeat_key.c:46: }
      00A69F 22               [24]  654 	ret
                                    655 ;------------------------------------------------------------
                                    656 ;Allocation info for local variables in function 'get_last_keycode'
                                    657 ;------------------------------------------------------------
                                    658 ;	quantum/repeat_key.c:48: uint16_t get_last_keycode(void) {
                                    659 ;	-----------------------------------------
                                    660 ;	 function set_last_mods
                                    661 ;	-----------------------------------------
      00A6A0                        662 _set_last_mods:
      00A6A0 E5 82            [12]  663 	mov	a,dpl
      00A6A2 90 0C 5B         [24]  664 	mov	dptr,#_set_last_mods_mods_10000_170
      00A6A5 F0               [24]  665 	movx	@dptr,a
                                    666 ;	quantum/repeat_key.c:66: last_mods = mods;
      00A6A6 E0               [24]  667 	movx	a,@dptr
      00A6A7 90 0E 4E         [24]  668 	mov	dptr,#_last_mods
      00A6AA F0               [24]  669 	movx	@dptr,a
                                    670 ;	quantum/repeat_key.c:67: }
      00A6AB 22               [24]  671 	ret
                                    672 ;------------------------------------------------------------
                                    673 ;Allocation info for local variables in function 'set_last_record'
                                    674 ;------------------------------------------------------------
                                    675 ;record        Allocated with name '_set_last_record_PARM_2'
                                    676 ;keycode       Allocated with name '_set_last_record_keycode_10000_172'
                                    677 ;------------------------------------------------------------
                                    678 ;	quantum/repeat_key.c:69: void set_last_record(uint16_t keycode, keyrecord_t* record) {
                                    679 ;	-----------------------------------------
                                    680 ;	 function set_last_record
                                    681 ;	-----------------------------------------
      00A6AC                        682 _set_last_record:
      00A6AC 12 3A C2         [24]  683 	lcall	_ak820_outline_0109
      00A6AF 90 0C 5F         [24]  684 	mov	dptr,#_set_last_record_keycode_10000_172
      00A6B2 12 3A C7         [24]  685 	lcall	_ak820_outline_0110
                                    686 ;	quantum/repeat_key.c:70: last_record         = *record;
      00A6B5 90 0C 5C         [24]  687 	mov	dptr,#_set_last_record_PARM_2
      00A6B8 12 51 63         [24]  688 	lcall	_ak820_outline_0012
      00A6BB 90 0D D5         [24]  689 	mov	dptr,#___memcpy_PARM_2
      00A6BE ED               [12]  690 	mov	a,r5
      00A6BF 12 3A 5F         [24]  691 	lcall	_ak820_outline_0016
      00A6C2 90 0D D8         [24]  692 	mov	dptr,#___memcpy_PARM_3
      00A6C5 74 09            [12]  693 	mov	a,#0x09
      00A6C7 12 3A E1         [24]  694 	lcall	_ak820_outline_0137
      00A6CA 90 0C 46         [24]  695 	mov	dptr,#_last_record
      00A6CD F5 F0            [12]  696 	mov	b,a
      00A6CF 12 BD 16         [24]  697 	lcall	___memcpy
                                    698 ;	quantum/repeat_key.c:71: last_record.keycode = keycode;
      00A6D2 90 0C 5F         [24]  699 	mov	dptr,#_set_last_record_keycode_10000_172
      00A6D5 12 3A 81         [24]  700 	lcall	_ak820_outline_0052
      00A6D8 90 0C 4D         [24]  701 	mov	dptr,#(_last_record + 0x0007)
      00A6DB 12 4A CB         [24]  702 	lcall	_ak820_outline_0060
                                    703 ;	quantum/repeat_key.c:72: last_repeat_count   = 0;
      00A6DE 90 0E 4F         [24]  704 	mov	dptr,#_last_repeat_count
      00A6E1 E4               [12]  705 	clr	a
      00A6E2 F0               [24]  706 	movx	@dptr,a
                                    707 ;	quantum/repeat_key.c:73: }
      00A6E3 22               [24]  708 	ret
                                    709 ;------------------------------------------------------------
                                    710 ;Allocation info for local variables in function 'update_last_repeat_count'
                                    711 ;------------------------------------------------------------
                                    712 ;dir           Allocated with name '_update_last_repeat_count_dir_10000_174'
                                    713 ;------------------------------------------------------------
                                    714 ;	quantum/repeat_key.c:76: static void update_last_repeat_count(int8_t dir) {
                                    715 ;	-----------------------------------------
                                    716 ;	 function update_last_repeat_count
                                    717 ;	-----------------------------------------
      00A6E4                        718 _update_last_repeat_count:
      00A6E4 E5 82            [12]  719 	mov	a,dpl
      00A6E6 90 0C 61         [24]  720 	mov	dptr,#_update_last_repeat_count_dir_10000_174
      00A6E9 F0               [24]  721 	movx	@dptr,a
                                    722 ;	quantum/repeat_key.c:77: if ((dir < 0) != (last_repeat_count < 0)) {
      00A6EA E0               [24]  723 	movx	a,@dptr
      00A6EB FF               [12]  724 	mov	r7,a
      00A6EC 33               [12]  725 	rlc	a
      00A6ED E4               [12]  726 	clr	a
      00A6EE 33               [12]  727 	rlc	a
      00A6EF FE               [12]  728 	mov	r6,a
      00A6F0 90 0E 4F         [24]  729 	mov	dptr,#_last_repeat_count
      00A6F3 E0               [24]  730 	movx	a,@dptr
      00A6F4 FD               [12]  731 	mov	r5,a
      00A6F5 33               [12]  732 	rlc	a
      00A6F6 E4               [12]  733 	clr	a
      00A6F7 33               [12]  734 	rlc	a
      00A6F8 FC               [12]  735 	mov	r4,a
      00A6F9 EE               [12]  736 	mov	a,r6
      00A6FA B5 04 02         [24]  737 	cjne	a,ar4,00131$
      00A6FD 80 06            [24]  738 	sjmp	00104$
      00A6FF                        739 00131$:
                                    740 ;	quantum/repeat_key.c:78: last_repeat_count = dir;
      00A6FF 90 0E 4F         [24]  741 	mov	dptr,#_last_repeat_count
      00A702 EF               [12]  742 	mov	a,r7
      00A703 F0               [24]  743 	movx	@dptr,a
      00A704 22               [24]  744 	ret
      00A705                        745 00104$:
                                    746 ;	quantum/repeat_key.c:79: } else if (dir < 0 ? last_repeat_count > -127 : last_repeat_count < 127) {
      00A705 EE               [12]  747 	mov	a,r6
      00A706 60 0F            [24]  748 	jz	00108$
      00A708 C3               [12]  749 	clr	c
      00A709 74 01            [12]  750 	mov	a,#(0x81 ^ 0x80)
      00A70B 8D F0            [24]  751 	mov	b,r5
      00A70D 63 F0 80         [24]  752 	xrl	b,#0x80
      00A710 95 F0            [12]  753 	subb	a,b
      00A712 E4               [12]  754 	clr	a
      00A713 33               [12]  755 	rlc	a
      00A714 FF               [12]  756 	mov	r7,a
                                    757 ;	free result
      00A715 80 09            [24]  758 	sjmp	00109$
      00A717                        759 00108$:
      00A717 C3               [12]  760 	clr	c
      00A718 ED               [12]  761 	mov	a,r5
      00A719 64 80            [12]  762 	xrl	a,#0x80
      00A71B 94 FF            [12]  763 	subb	a,#0xff
      00A71D E4               [12]  764 	clr	a
      00A71E 33               [12]  765 	rlc	a
      00A71F FF               [12]  766 	mov	r7,a
      00A720                        767 00109$:
      00A720 EF               [12]  768 	mov	a,r7
      00A721 60 09            [24]  769 	jz	00106$
                                    770 ;	quantum/repeat_key.c:80: last_repeat_count += dir;
      00A723 90 0C 61         [24]  771 	mov	dptr,#_update_last_repeat_count_dir_10000_174
      00A726 E0               [24]  772 	movx	a,@dptr
      00A727 90 0E 4F         [24]  773 	mov	dptr,#_last_repeat_count
      00A72A 2D               [12]  774 	add	a, r5
      00A72B F0               [24]  775 	movx	@dptr,a
      00A72C                        776 00106$:
                                    777 ;	quantum/repeat_key.c:82: }
      00A72C 22               [24]  778 	ret
                                    779 ;------------------------------------------------------------
                                    780 ;Allocation info for local variables in function 'get_repeat_key_count'
                                    781 ;------------------------------------------------------------
                                    782 ;	quantum/repeat_key.c:84: int8_t get_repeat_key_count(void) {
                                    783 ;	-----------------------------------------
                                    784 ;	 function get_repeat_key_count
                                    785 ;	-----------------------------------------
      00A72D                        786 _get_repeat_key_count:
                                    787 ;	quantum/repeat_key.c:85: return processing_repeat_count;
      00A72D 90 0E 50         [24]  788 	mov	dptr,#_processing_repeat_count
      00A730 E0               [24]  789 	movx	a,@dptr
                                    790 ;	quantum/repeat_key.c:86: }
      00A731 F5 82            [12]  791 	mov	dpl,a
      00A733 22               [24]  792 	ret
                                    793 ;------------------------------------------------------------
                                    794 ;Allocation info for local variables in function 'repeat_invoke'
                                    795 ;------------------------------------------------------------
                                    796 ;alternate     Allocated with name '_repeat_invoke_PARM_2'
                                    797 ;event         Allocated with name '_repeat_invoke_event_10000_182'
                                    798 ;------------------------------------------------------------
                                    799 ;	quantum/repeat_key.c:88: static void repeat_invoke(const keyevent_t* event, bool alternate) {
                                    800 ;	-----------------------------------------
                                    801 ;	 function repeat_invoke
                                    802 ;	-----------------------------------------
      00A734                        803 _repeat_invoke:
      00A734 12 45 55         [24]  804 	lcall	_ak820_outline_0036
      00A737 90 0C 63         [24]  805 	mov	dptr,#_repeat_invoke_event_10000_182
      00A73A 12 3A 5F         [24]  806 	lcall	_ak820_outline_0016
                                    807 ;	quantum/repeat_key.c:97: if (ak820_repeat_invoking) return;
      00A73D 90 0C 4F         [24]  808 	mov	dptr,#_ak820_repeat_invoking
      00A740 E0               [24]  809 	movx	a,@dptr
      00A741 60 01            [24]  810 	jz	00102$
      00A743 22               [24]  811 	ret
      00A744                        812 00102$:
                                    813 ;	quantum/repeat_key.c:99: if (processing_repeat_count) {
      00A744 90 0E 50         [24]  814 	mov	dptr,#_processing_repeat_count
      00A747 E0               [24]  815 	movx	a,@dptr
      00A748 60 01            [24]  816 	jz	00104$
                                    817 ;	quantum/repeat_key.c:100: return;
      00A74A 22               [24]  818 	ret
      00A74B                        819 00104$:
                                    820 ;	quantum/repeat_key.c:103: if (event->pressed) {
      00A74B 90 0C 63         [24]  821 	mov	dptr,#_repeat_invoke_event_10000_182
      00A74E 12 51 63         [24]  822 	lcall	_ak820_outline_0012
      00A751 74 05            [12]  823 	mov	a,#0x05
      00A753 12 7B FA         [24]  824 	lcall	_ak820_outline_0014
      00A756 12 BD EF         [24]  825 	lcall	__gptrget
      00A759 70 02            [24]  826 	jnz	00197$
      00A75B E1 D5            [24]  827 	ajmp	00117$
      00A75D                        828 00197$:
                                    829 ;	quantum/repeat_key.c:106: if (registered_record.keycode || !last_record.keycode) return;
      00A75D 12 A9 D9         [24]  830 	lcall	_ak820_outline_0175
      00A760 70 0A            [24]  831 	jnz	00105$
      00A762 90 0C 4D         [24]  832 	mov	dptr,#(_last_record + 0x0007)
      00A765 E0               [24]  833 	movx	a,@dptr
      00A766 FB               [12]  834 	mov	r3,a
      00A767 A3               [24]  835 	inc	dptr
      00A768 E0               [24]  836 	movx	a,@dptr
      00A769 4B               [12]  837 	orl	a,r3
      00A76A 70 01            [24]  838 	jnz	00106$
      00A76C                        839 00105$:
      00A76C 22               [24]  840 	ret
      00A76D                        841 00106$:
                                    842 ;	quantum/repeat_key.c:107: registered_record = last_record;
      00A76D 90 0D D5         [24]  843 	mov	dptr,#___memcpy_PARM_2
      00A770 74 46            [12]  844 	mov	a,#_last_record
      00A772 F0               [24]  845 	movx	@dptr,a
      00A773 74 0C            [12]  846 	mov	a,#(_last_record >> 8)
      00A775 12 3A B0         [24]  847 	lcall	_ak820_outline_0093
      00A778 90 0D D8         [24]  848 	mov	dptr,#___memcpy_PARM_3
      00A77B 74 09            [12]  849 	mov	a,#0x09
      00A77D 12 3A E1         [24]  850 	lcall	_ak820_outline_0137
      00A780 90 0C 50         [24]  851 	mov	dptr,#_registered_record
      00A783 F5 F0            [12]  852 	mov	b,a
      00A785 12 BD 16         [24]  853 	lcall	___memcpy
                                    854 ;	quantum/repeat_key.c:108: registered_mods = last_mods;
      00A788 90 0E 4E         [24]  855 	mov	dptr,#_last_mods
      00A78B E0               [24]  856 	movx	a,@dptr
      00A78C 90 0C 5A         [24]  857 	mov	dptr,#_registered_mods
      00A78F F0               [24]  858 	movx	@dptr,a
                                    859 ;	quantum/repeat_key.c:110: if (alternate) {
      00A790 90 0C 62         [24]  860 	mov	dptr,#_repeat_invoke_PARM_2
      00A793 E0               [24]  861 	movx	a,@dptr
      00A794 FC               [12]  862 	mov	r4,a
      00A795 E0               [24]  863 	movx	a,@dptr
      00A796 60 1C            [24]  864 	jz	00111$
                                    865 ;	quantum/repeat_key.c:111: registered_record.keycode = get_alt_repeat_key_keycode();
      00A798 C0 04            [24]  866 	push	ar4
      00A79A 12 A8 A8         [24]  867 	lcall	_get_alt_repeat_key_keycode
      00A79D AA 82            [24]  868 	mov	r2, dpl
      00A79F AB 83            [24]  869 	mov	r3, dph
      00A7A1 D0 04            [24]  870 	pop	ar4
      00A7A3 90 0C 57         [24]  871 	mov	dptr,#(_registered_record + 0x0007)
      00A7A6 EA               [12]  872 	mov	a,r2
      00A7A7 12 7C 6E         [24]  873 	lcall	_ak820_outline_0189
                                    874 ;	quantum/repeat_key.c:112: if (!registered_record.keycode) return;
      00A7AA EA               [12]  875 	mov	a,r2
      00A7AB 4B               [12]  876 	orl	a,r3
      00A7AC 70 01            [24]  877 	jnz	00109$
      00A7AE 22               [24]  878 	ret
      00A7AF                        879 00109$:
                                    880 ;	quantum/repeat_key.c:114: registered_mods = 0;
      00A7AF 90 0C 5A         [24]  881 	mov	dptr,#_registered_mods
      00A7B2 E4               [12]  882 	clr	a
      00A7B3 F0               [24]  883 	movx	@dptr,a
      00A7B4                        884 00111$:
                                    885 ;	quantum/repeat_key.c:117: update_last_repeat_count(alternate ? -1 : 1);
      00A7B4 EC               [12]  886 	mov	a,r4
      00A7B5 60 04            [24]  887 	jz	00123$
      00A7B7 7C FF            [12]  888 	mov	r4,#0xff
      00A7B9 80 02            [24]  889 	sjmp	00124$
      00A7BB                        890 00123$:
      00A7BB 7C 01            [12]  891 	mov	r4,#0x01
      00A7BD                        892 00124$:
      00A7BD 8C 82            [24]  893 	mov	dpl, r4
      00A7BF 12 A6 E4         [24]  894 	lcall	_update_last_repeat_count
                                    895 ;	quantum/repeat_key.c:118: register_weak_mods(registered_mods);
      00A7C2 90 0C 5A         [24]  896 	mov	dptr,#_registered_mods
      00A7C5 E0               [24]  897 	movx	a,@dptr
      00A7C6 F5 82            [12]  898 	mov	dpl,a
      00A7C8 12 7B 76         [24]  899 	lcall	_register_weak_mods
                                    900 ;	quantum/repeat_key.c:119: registered_repeat_count = last_repeat_count;
      00A7CB 90 0E 4F         [24]  901 	mov	dptr,#_last_repeat_count
      00A7CE E0               [24]  902 	movx	a,@dptr
      00A7CF 90 0C 59         [24]  903 	mov	dptr,#_registered_repeat_count
      00A7D2 F0               [24]  904 	movx	@dptr,a
      00A7D3 80 2A            [24]  905 	sjmp	00118$
      00A7D5                        906 00117$:
                                    907 ;	quantum/repeat_key.c:122: if (!registered_record.keycode || event->key.row != registered_record.event.key.row ||
      00A7D5 12 A9 D9         [24]  908 	lcall	_ak820_outline_0175
      00A7D8 60 24            [24]  909 	jz	00112$
      00A7DA 74 01            [12]  910 	mov	a,#0x01
      00A7DC 12 7B FA         [24]  911 	lcall	_ak820_outline_0014
      00A7DF 12 BD EF         [24]  912 	lcall	__gptrget
      00A7E2 FA               [12]  913 	mov	r2,a
      00A7E3 90 0C 51         [24]  914 	mov	dptr,#(_registered_record + 0x0001)
      00A7E6 E0               [24]  915 	movx	a,@dptr
      00A7E7 FC               [12]  916 	mov	r4,a
      00A7E8 EA               [12]  917 	mov	a,r2
      00A7E9 B5 04 12         [24]  918 	cjne	a,ar4,00112$
                                    919 ;	quantum/repeat_key.c:123: event->key.col != registered_record.event.key.col) return;
      00A7EC 12 72 23         [24]  920 	lcall	_ak820_outline_0059
      00A7EF 12 BD EF         [24]  921 	lcall	__gptrget
      00A7F2 FD               [12]  922 	mov	r5,a
      00A7F3 90 0C 50         [24]  923 	mov	dptr,#_registered_record
      00A7F6 E0               [24]  924 	movx	a,@dptr
      00A7F7 FF               [12]  925 	mov	r7,a
      00A7F8 ED               [12]  926 	mov	a,r5
      00A7F9 B5 07 02         [24]  927 	cjne	a,ar7,00206$
      00A7FC 80 01            [24]  928 	sjmp	00118$
      00A7FE                        929 00206$:
      00A7FE                        930 00112$:
      00A7FE 22               [24]  931 	ret
      00A7FF                        932 00118$:
                                    933 ;	quantum/repeat_key.c:127: registered_record.event = *event;
      00A7FF 90 0C 63         [24]  934 	mov	dptr,#_repeat_invoke_event_10000_182
      00A802 12 51 63         [24]  935 	lcall	_ak820_outline_0012
      00A805 90 0D D5         [24]  936 	mov	dptr,#___memcpy_PARM_2
      00A808 ED               [12]  937 	mov	a,r5
      00A809 12 3A 5F         [24]  938 	lcall	_ak820_outline_0016
      00A80C 90 0D D8         [24]  939 	mov	dptr,#___memcpy_PARM_3
      00A80F 74 06            [12]  940 	mov	a,#0x06
      00A811 12 3A E1         [24]  941 	lcall	_ak820_outline_0137
      00A814 90 0C 50         [24]  942 	mov	dptr,#_registered_record
      00A817 F5 F0            [12]  943 	mov	b,a
      00A819 12 BD 16         [24]  944 	lcall	___memcpy
                                    945 ;	quantum/repeat_key.c:128: processing_repeat_count = registered_repeat_count;
      00A81C 90 0C 59         [24]  946 	mov	dptr,#_registered_repeat_count
      00A81F E0               [24]  947 	movx	a,@dptr
      00A820 90 0E 50         [24]  948 	mov	dptr,#_processing_repeat_count
      00A823 F0               [24]  949 	movx	@dptr,a
                                    950 ;	quantum/repeat_key.c:130: ak820_repeat_invoking = true;
      00A824 90 0C 4F         [24]  951 	mov	dptr,#_ak820_repeat_invoking
      00A827 74 01            [12]  952 	mov	a,#0x01
      00A829 F0               [24]  953 	movx	@dptr,a
                                    954 ;	quantum/repeat_key.c:132: process_record(&registered_record);
      00A82A 90 0C 50         [24]  955 	mov	dptr,#_registered_record
      00A82D 75 F0 00         [24]  956 	mov	b, #0x00
      00A830 12 75 92         [24]  957 	lcall	_process_record
                                    958 ;	quantum/repeat_key.c:134: ak820_repeat_invoking = false;
      00A833 90 0C 4F         [24]  959 	mov	dptr,#_ak820_repeat_invoking
      00A836 E4               [12]  960 	clr	a
      00A837 F0               [24]  961 	movx	@dptr,a
                                    962 ;	quantum/repeat_key.c:136: processing_repeat_count = 0;
      00A838 90 0E 50         [24]  963 	mov	dptr,#_processing_repeat_count
      00A83B F0               [24]  964 	movx	@dptr,a
                                    965 ;	quantum/repeat_key.c:142: if (!registered_record.event.pressed) {
      00A83C 90 0C 55         [24]  966 	mov	dptr,#(_registered_record + 0x0005)
      00A83F E0               [24]  967 	movx	a,@dptr
      00A840 70 0F            [24]  968 	jnz	00121$
                                    969 ;	quantum/repeat_key.c:143: unregister_weak_mods(registered_mods);
      00A842 90 0C 5A         [24]  970 	mov	dptr,#_registered_mods
      00A845 E0               [24]  971 	movx	a,@dptr
      00A846 F5 82            [12]  972 	mov	dpl,a
      00A848 12 7B 8A         [24]  973 	lcall	_unregister_weak_mods
                                    974 ;	quantum/repeat_key.c:144: registered_record.keycode = 0;
      00A84B 90 0C 57         [24]  975 	mov	dptr,#(_registered_record + 0x0007)
      00A84E 12 51 B6         [24]  976 	lcall	_ak820_outline_0184
      00A851                        977 00121$:
                                    978 ;	quantum/repeat_key.c:146: }
      00A851 22               [24]  979 	ret
                                    980 ;------------------------------------------------------------
                                    981 ;Allocation info for local variables in function 'repeat_key_invoke'
                                    982 ;------------------------------------------------------------
                                    983 ;event         Allocated with name '_repeat_key_invoke_event_10000_197'
                                    984 ;------------------------------------------------------------
                                    985 ;	quantum/repeat_key.c:148: void repeat_key_invoke(const keyevent_t* event) {
                                    986 ;	-----------------------------------------
                                    987 ;	 function repeat_key_invoke
                                    988 ;	-----------------------------------------
      00A852                        989 _repeat_key_invoke:
      00A852 12 45 55         [24]  990 	lcall	_ak820_outline_0036
      00A855 90 0C 66         [24]  991 	mov	dptr,#_repeat_key_invoke_event_10000_197
      00A858 12 3A 5F         [24]  992 	lcall	_ak820_outline_0016
                                    993 ;	quantum/repeat_key.c:149: repeat_invoke(event, false);
      00A85B 90 0C 66         [24]  994 	mov	dptr,#_repeat_key_invoke_event_10000_197
      00A85E 12 51 63         [24]  995 	lcall	_ak820_outline_0012
      00A861 90 0C 62         [24]  996 	mov	dptr,#_repeat_invoke_PARM_2
      00A864 E4               [12]  997 	clr	a
      00A865 12 51 6C         [24]  998 	lcall	_ak820_outline_0034
                                    999 ;	quantum/repeat_key.c:150: }
      00A868 02 A7 34         [24] 1000 	ljmp	_repeat_invoke
                                   1001 ;------------------------------------------------------------
                                   1002 ;Allocation info for local variables in function 'find_alt_keycode'
                                   1003 ;------------------------------------------------------------
                                   1004 ;table_size_bytes Allocated with name '_find_alt_keycode_PARM_2'
                                   1005 ;target        Allocated with name '_find_alt_keycode_PARM_3'
                                   1006 ;table         Allocated with name '_find_alt_keycode_table_10000_199'
                                   1007 ;keycodes      Allocated with name '_find_alt_keycode_keycodes_10000_200'
                                   1008 ;i             Allocated with name '_find_alt_keycode_i_20000_201'
                                   1009 ;------------------------------------------------------------
                                   1010 ;	quantum/repeat_key.c:166: static uint8_t find_alt_keycode(const uint8_t (*table)[2], uint8_t table_size_bytes, uint8_t target) {
                                   1011 ;	-----------------------------------------
                                   1012 ;	 function find_alt_keycode
                                   1013 ;	-----------------------------------------
      00A86B                       1014 _find_alt_keycode:
      00A86B 12 45 55         [24] 1015 	lcall	_ak820_outline_0036
      00A86E 90 0C 6B         [24] 1016 	mov	dptr,#_find_alt_keycode_table_10000_199
      00A871 12 3A 5F         [24] 1017 	lcall	_ak820_outline_0016
                                   1018 ;	quantum/repeat_key.c:167: const uint8_t* keycodes = (const uint8_t*)table;
      00A874 90 0C 6B         [24] 1019 	mov	dptr,#_find_alt_keycode_table_10000_199
      00A877 12 51 63         [24] 1020 	lcall	_ak820_outline_0012
                                   1021 ;	quantum/repeat_key.c:168: for (uint8_t i = 0; i < table_size_bytes; ++i) {
      00A87A 7C 00            [12] 1022 	mov	r4,#0x00
      00A87C                       1023 00105$:
      00A87C 90 0C 69         [24] 1024 	mov	dptr,#_find_alt_keycode_PARM_2
      00A87F E0               [24] 1025 	movx	a,@dptr
      00A880 FB               [12] 1026 	mov	r3,a
      00A881 C3               [12] 1027 	clr	c
      00A882 EC               [12] 1028 	mov	a,r4
      00A883 9B               [12] 1029 	subb	a,r3
      00A884 50 1E            [24] 1030 	jnc	00103$
                                   1031 ;	quantum/repeat_key.c:169: if (target == pgm_read_byte(keycodes + i)) {
      00A886 EC               [12] 1032 	mov	a,r4
      00A887 12 7B EC         [24] 1033 	lcall	_ak820_outline_0013
      00A88A 12 BD EF         [24] 1034 	lcall	__gptrget
      00A88D F9               [12] 1035 	mov	r1,a
      00A88E 90 0C 6A         [24] 1036 	mov	dptr,#_find_alt_keycode_PARM_3
      00A891 E0               [24] 1037 	movx	a,@dptr
      00A892 B5 01 0C         [24] 1038 	cjne	a,ar1,00106$
                                   1039 ;	quantum/repeat_key.c:171: return pgm_read_byte(keycodes + (i ^ 1));
      00A895 74 01            [12] 1040 	mov	a,#0x01
      00A897 6C               [12] 1041 	xrl	a,r4
      00A898 12 7B EC         [24] 1042 	lcall	_ak820_outline_0013
      00A89B 12 BD EF         [24] 1043 	lcall	__gptrget
      00A89E F5 82            [12] 1044 	mov	dpl,a
      00A8A0 22               [24] 1045 	ret
      00A8A1                       1046 00106$:
                                   1047 ;	quantum/repeat_key.c:168: for (uint8_t i = 0; i < table_size_bytes; ++i) {
      00A8A1 0C               [12] 1048 	inc	r4
      00A8A2 80 D8            [24] 1049 	sjmp	00105$
      00A8A4                       1050 00103$:
                                   1051 ;	quantum/repeat_key.c:174: return KC_NO;
      00A8A4 75 82 00         [24] 1052 	mov	dpl, #0x00
                                   1053 ;	quantum/repeat_key.c:175: }
      00A8A7 22               [24] 1054 	ret
                                   1055 ;------------------------------------------------------------
                                   1056 ;Allocation info for local variables in function 'get_alt_repeat_key_keycode'
                                   1057 ;------------------------------------------------------------
                                   1058 ;keycode       Allocated with name '_get_alt_repeat_key_keycode_keycode_10000_206'
                                   1059 ;mods          Allocated with name '_get_alt_repeat_key_keycode_mods_10000_206'
                                   1060 ;alt_keycode   Allocated with name '_get_alt_repeat_key_keycode_alt_keycode_10000_206'
                                   1061 ;------------------------------------------------------------
                                   1062 ;	quantum/repeat_key.c:177: uint16_t get_alt_repeat_key_keycode(void) {
                                   1063 ;	-----------------------------------------
                                   1064 ;	 function get_alt_repeat_key_keycode
                                   1065 ;	-----------------------------------------
      00A8A8                       1066 _get_alt_repeat_key_keycode:
                                   1067 ;	quantum/repeat_key.c:178: uint16_t keycode = last_record.keycode;
      00A8A8 90 0C 4D         [24] 1068 	mov	dptr,#(_last_record + 0x0007)
      00A8AB 12 3A 81         [24] 1069 	lcall	_ak820_outline_0052
      00A8AE 90 0C 6E         [24] 1070 	mov	dptr,#_get_alt_repeat_key_keycode_keycode_10000_206
      00A8B1 12 4A CB         [24] 1071 	lcall	_ak820_outline_0060
                                   1072 ;	quantum/repeat_key.c:179: uint8_t  mods    = last_mods;
      00A8B4 90 0E 4E         [24] 1073 	mov	dptr,#_last_mods
      00A8B7 E0               [24] 1074 	movx	a,@dptr
      00A8B8 FD               [12] 1075 	mov	r5,a
      00A8B9 90 0C 70         [24] 1076 	mov	dptr,#_get_alt_repeat_key_keycode_mods_10000_206
      00A8BC F0               [24] 1077 	movx	@dptr,a
                                   1078 ;	quantum/repeat_key.c:183: uint16_t alt_keycode = get_alt_repeat_key_keycode_user(keycode, mods);
      00A8BD 90 0C 76         [24] 1079 	mov	dptr,#_get_alt_repeat_key_keycode_user_PARM_2
      00A8C0 ED               [12] 1080 	mov	a,r5
      00A8C1 12 45 79         [24] 1081 	lcall	_ak820_outline_0078
      00A8C4 C0 07            [24] 1082 	push	ar7
      00A8C6 C0 06            [24] 1083 	push	ar6
      00A8C8 31 CA            [12] 1084 	acall	_get_alt_repeat_key_keycode_user
      00A8CA 12 45 A8         [24] 1085 	lcall	_ak820_outline_0154
      00A8CD D0 06            [24] 1086 	pop	ar6
      00A8CF D0 07            [24] 1087 	pop	ar7
                                   1088 ;	quantum/repeat_key.c:185: if (alt_keycode != KC_TRANSPARENT) {
      00A8D1 8C 02            [24] 1089 	mov	ar2,r4
      00A8D3 8D 03            [24] 1090 	mov	ar3,r5
      00A8D5 BA 01 05         [24] 1091 	cjne	r2,#0x01,00176$
      00A8D8 BB 00 02         [24] 1092 	cjne	r3,#0x00,00176$
      00A8DB 80 04            [24] 1093 	sjmp	00102$
      00A8DD                       1094 00176$:
                                   1095 ;	quantum/repeat_key.c:186: return alt_keycode;
      00A8DD 12 3A D7         [24] 1096 	lcall	_ak820_outline_0126
      00A8E0 22               [24] 1097 	ret
      00A8E1                       1098 00102$:
                                   1099 ;	quantum/repeat_key.c:191: mods = ((mods & 0xf0) ? /* set right hand bit */ 0x10 : 0)
      00A8E1 90 0C 70         [24] 1100 	mov	dptr,#_get_alt_repeat_key_keycode_mods_10000_206
      00A8E4 E0               [24] 1101 	movx	a,@dptr
      00A8E5 54 F0            [12] 1102 	anl	a,#0xf0
      00A8E7 60 02            [24] 1103 	jz	00118$
      00A8E9 74 10            [12] 1104 	mov	a,#0x10
      00A8EB                       1105 00118$:
      00A8EB FD               [12] 1106 	mov	r5,a
                                   1107 ;	quantum/repeat_key.c:193: | (((mods >> 4) | mods) & 0xf);
      00A8EC 90 0C 70         [24] 1108 	mov	dptr,#_get_alt_repeat_key_keycode_mods_10000_206
      00A8EF E0               [24] 1109 	movx	a,@dptr
      00A8F0 FC               [12] 1110 	mov	r4,a
      00A8F1 C4               [12] 1111 	swap	a
      00A8F2 54 0F            [12] 1112 	anl	a,#0x0f
      00A8F4 4C               [12] 1113 	orl	a,r4
      00A8F5 54 0F            [12] 1114 	anl	a,#0x0f
      00A8F7 4D               [12] 1115 	orl	a,r5
      00A8F8 F0               [24] 1116 	movx	@dptr,a
                                   1117 ;	quantum/repeat_key.c:196: if (keycode >= QK_MODS && keycode <= QK_MODS_MAX) {
      00A8F9 8E 04            [24] 1118 	mov	ar4,r6
      00A8FB 8F 05            [24] 1119 	mov	ar5,r7
      00A8FD 74 FF            [12] 1120 	mov	a,#0x100 - 0x01
      00A8FF 2D               [12] 1121 	add	a,r5
      00A900 50 1C            [24] 1122 	jnc	00115$
      00A902 C3               [12] 1123 	clr	c
      00A903 74 FF            [12] 1124 	mov	a,#0xff
      00A905 9C               [12] 1125 	subb	a,r4
      00A906 74 1F            [12] 1126 	mov	a,#0x1f
      00A908 9D               [12] 1127 	subb	a,r5
      00A909 40 13            [24] 1128 	jc	00115$
                                   1129 ;	free result
                                   1130 ;	quantum/repeat_key.c:197: mods |= QK_MODS_GET_MODS(keycode);
      00A90B 8F 06            [24] 1131 	mov	ar6,r7
      00A90D 53 06 1F         [24] 1132 	anl	ar6,#0x1f
      00A910 90 0C 70         [24] 1133 	mov	dptr,#_get_alt_repeat_key_keycode_mods_10000_206
      00A913 E0               [24] 1134 	movx	a,@dptr
      00A914 4E               [12] 1135 	orl	a,r6
      00A915 F0               [24] 1136 	movx	@dptr,a
                                   1137 ;	quantum/repeat_key.c:198: keycode = QK_MODS_GET_BASIC_KEYCODE(keycode);
      00A916 7D 00            [12] 1138 	mov	r5,#0x00
      00A918 90 0C 6E         [24] 1139 	mov	dptr,#_get_alt_repeat_key_keycode_keycode_10000_206
      00A91B 12 3A 9E         [24] 1140 	lcall	_ak820_outline_0072
                                   1141 ;	quantum/repeat_key.c:214: if (IS_QK_BASIC(keycode)) {
      00A91E                       1142 00115$:
      00A91E 90 0C 6E         [24] 1143 	mov	dptr,#_get_alt_repeat_key_keycode_keycode_10000_206
      00A921 12 4A 6F         [24] 1144 	lcall	_ak820_outline_0008
      00A924 C3               [12] 1145 	clr	c
      00A925 74 FF            [12] 1146 	mov	a,#0xff
      00A927 9C               [12] 1147 	subb	a,r4
      00A928 E4               [12] 1148 	clr	a
      00A929 9D               [12] 1149 	subb	a,r5
      00A92A 50 02            [24] 1150 	jnc	00180$
      00A92C 21 AC            [12] 1151 	ajmp	00114$
      00A92E                       1152 00180$:
                                   1153 ;	free result
                                   1154 ;	quantum/repeat_key.c:215: if ((mods & (MOD_LCTL | MOD_LALT | MOD_LGUI))) {
      00A92E 90 0C 70         [24] 1155 	mov	dptr,#_get_alt_repeat_key_keycode_mods_10000_206
      00A931 E0               [24] 1156 	movx	a,@dptr
      00A932 54 0D            [12] 1157 	anl	a,#0x0d
      00A934 60 20            [24] 1158 	jz	00107$
                                   1159 ;	quantum/repeat_key.c:230: alt_keycode = find_alt_keycode(pairs, sizeof(pairs), keycode);
      00A936 8E 05            [24] 1160 	mov	ar5,r6
      00A938 90 0C 69         [24] 1161 	mov	dptr,#_find_alt_keycode_PARM_2
      00A93B 74 0A            [12] 1162 	mov	a,#0x0a
      00A93D F0               [24] 1163 	movx	@dptr,a
      00A93E 90 0C 6A         [24] 1164 	mov	dptr,#_find_alt_keycode_PARM_3
      00A941 ED               [12] 1165 	mov	a,r5
      00A942 F0               [24] 1166 	movx	@dptr,a
      00A943 90 C1 B4         [24] 1167 	mov	dptr,#_get_alt_repeat_key_keycode_pairs_50000_214
      00A946 75 F0 80         [24] 1168 	mov	b, #0x80
      00A949 11 6B            [24] 1169 	acall	_find_alt_keycode
      00A94B AD 82            [24] 1170 	mov	r5, dpl
      00A94D 90 0C 71         [24] 1171 	mov	dptr,#_get_alt_repeat_key_keycode_alt_keycode_10000_206
      00A950 ED               [12] 1172 	mov	a,r5
      00A951 12 3A E1         [24] 1173 	lcall	_ak820_outline_0137
      00A954 80 16            [24] 1174 	sjmp	00108$
      00A956                       1175 00107$:
                                   1176 ;	quantum/repeat_key.c:243: alt_keycode = find_alt_keycode(pairs, sizeof(pairs), keycode);
      00A956 90 0C 69         [24] 1177 	mov	dptr,#_find_alt_keycode_PARM_2
      00A959 74 08            [12] 1178 	mov	a,#0x08
      00A95B F0               [24] 1179 	movx	@dptr,a
      00A95C 90 0C 6A         [24] 1180 	mov	dptr,#_find_alt_keycode_PARM_3
      00A95F EE               [12] 1181 	mov	a,r6
      00A960 F0               [24] 1182 	movx	@dptr,a
      00A961 90 C1 BE         [24] 1183 	mov	dptr,#_get_alt_repeat_key_keycode_pairs_50000_215
      00A964 75 F0 80         [24] 1184 	mov	b, #0x80
      00A967 11 6B            [24] 1185 	acall	_find_alt_keycode
      00A969 12 A9 CE         [24] 1186 	lcall	_ak820_outline_0133
      00A96C                       1187 00108$:
                                   1188 ;	quantum/repeat_key.c:246: if (!alt_keycode) {
      00A96C 90 0C 71         [24] 1189 	mov	dptr,#_get_alt_repeat_key_keycode_alt_keycode_10000_206
      00A96F 12 72 1B         [24] 1190 	lcall	_ak820_outline_0040
      00A972 70 1B            [24] 1191 	jnz	00110$
                                   1192 ;	quantum/repeat_key.c:271: alt_keycode = find_alt_keycode(pairs, sizeof(pairs), keycode);
      00A974 90 0C 6E         [24] 1193 	mov	dptr,#_get_alt_repeat_key_keycode_keycode_10000_206
      00A977 E0               [24] 1194 	movx	a,@dptr
      00A978 FF               [12] 1195 	mov	r7,a
      00A979 90 0C 69         [24] 1196 	mov	dptr,#_find_alt_keycode_PARM_2
      00A97C 74 1E            [12] 1197 	mov	a,#0x1e
      00A97E F0               [24] 1198 	movx	@dptr,a
      00A97F 90 0C 6A         [24] 1199 	mov	dptr,#_find_alt_keycode_PARM_3
      00A982 EF               [12] 1200 	mov	a,r7
      00A983 F0               [24] 1201 	movx	@dptr,a
      00A984 90 C1 C6         [24] 1202 	mov	dptr,#_get_alt_repeat_key_keycode_pairs_50000_217
      00A987 75 F0 80         [24] 1203 	mov	b, #0x80
      00A98A 11 6B            [24] 1204 	acall	_find_alt_keycode
      00A98C 12 A9 CE         [24] 1205 	lcall	_ak820_outline_0133
      00A98F                       1206 00110$:
                                   1207 ;	quantum/repeat_key.c:274: if (alt_keycode) {
      00A98F 90 0C 71         [24] 1208 	mov	dptr,#_get_alt_repeat_key_keycode_alt_keycode_10000_206
      00A992 12 3A 81         [24] 1209 	lcall	_ak820_outline_0052
      00A995 90 0C 71         [24] 1210 	mov	dptr,#_get_alt_repeat_key_keycode_alt_keycode_10000_206
      00A998 12 72 1B         [24] 1211 	lcall	_ak820_outline_0040
      00A99B 60 0F            [24] 1212 	jz	00114$
                                   1213 ;	quantum/repeat_key.c:276: return (mods << 8) | alt_keycode;
      00A99D 90 0C 70         [24] 1214 	mov	dptr,#_get_alt_repeat_key_keycode_mods_10000_206
      00A9A0 E0               [24] 1215 	movx	a,@dptr
      00A9A1 FD               [12] 1216 	mov	r5,a
      00A9A2 E4               [12] 1217 	clr	a
      00A9A3 42 06            [12] 1218 	orl	ar6,a
      00A9A5 ED               [12] 1219 	mov	a,r5
      00A9A6 42 07            [12] 1220 	orl	ar7,a
      00A9A8 12 3A CC         [24] 1221 	lcall	_ak820_outline_0120
      00A9AB 22               [24] 1222 	ret
      00A9AC                       1223 00114$:
                                   1224 ;	quantum/repeat_key.c:280: return KC_NO; // No alternate key found.
      00A9AC 90 00 00         [24] 1225 	mov	dptr,#0x0000
                                   1226 ;	quantum/repeat_key.c:281: }
      00A9AF 22               [24] 1227 	ret
                                   1228 ;------------------------------------------------------------
                                   1229 ;Allocation info for local variables in function 'alt_repeat_key_invoke'
                                   1230 ;------------------------------------------------------------
                                   1231 ;event         Allocated with name '_alt_repeat_key_invoke_event_10000_220'
                                   1232 ;------------------------------------------------------------
                                   1233 ;	quantum/repeat_key.c:283: void alt_repeat_key_invoke(const keyevent_t* event) {
                                   1234 ;	-----------------------------------------
                                   1235 ;	 function alt_repeat_key_invoke
                                   1236 ;	-----------------------------------------
      00A9B0                       1237 _alt_repeat_key_invoke:
      00A9B0 12 45 55         [24] 1238 	lcall	_ak820_outline_0036
      00A9B3 90 0C 73         [24] 1239 	mov	dptr,#_alt_repeat_key_invoke_event_10000_220
      00A9B6 12 3A 5F         [24] 1240 	lcall	_ak820_outline_0016
                                   1241 ;	quantum/repeat_key.c:285: repeat_invoke(event, true);
      00A9B9 90 0C 73         [24] 1242 	mov	dptr,#_alt_repeat_key_invoke_event_10000_220
      00A9BC 12 51 63         [24] 1243 	lcall	_ak820_outline_0012
      00A9BF 90 0C 62         [24] 1244 	mov	dptr,#_repeat_invoke_PARM_2
      00A9C2 74 01            [12] 1245 	mov	a,#0x01
      00A9C4 12 51 6C         [24] 1246 	lcall	_ak820_outline_0034
                                   1247 ;	quantum/repeat_key.c:286: }
      00A9C7 02 A7 34         [24] 1248 	ljmp	_repeat_invoke
                                   1249 ;------------------------------------------------------------
                                   1250 ;Allocation info for local variables in function 'get_alt_repeat_key_keycode_user'
                                   1251 ;------------------------------------------------------------
                                   1252 ;mods          Allocated with name '_get_alt_repeat_key_keycode_user_PARM_2'
                                   1253 ;keycode       Allocated with name '_get_alt_repeat_key_keycode_user_keycode_10000_222'
                                   1254 ;------------------------------------------------------------
                                   1255 ;	quantum/repeat_key.c:289: __attribute__((weak)) uint16_t get_alt_repeat_key_keycode_user(uint16_t keycode, uint8_t mods) {
                                   1256 ;	-----------------------------------------
                                   1257 ;	 function get_alt_repeat_key_keycode_user
                                   1258 ;	-----------------------------------------
      00A9CA                       1259 _get_alt_repeat_key_keycode_user:
                                   1260 ;	quantum/repeat_key.c:290: return KC_TRANSPARENT;
      00A9CA 90 00 01         [24] 1261 	mov	dptr,#0x0001
                                   1262 ;	quantum/repeat_key.c:291: }
      00A9CD 22               [24] 1263 	ret
                                   1264 	.area CSEG    (CODE)
                                   1265 	.area CONST   (CODE)
                                   1266 	.area CONST   (CODE)
      00C1B4                       1267 _get_alt_repeat_key_keycode_pairs_50000_214:
      00C1B4 09                    1268 	.db #0x09	; 9
      00C1B5 05                    1269 	.db #0x05	; 5
      00C1B6 07                    1270 	.db #0x07	; 7
      00C1B7 18                    1271 	.db #0x18	; 24
      00C1B8 11                    1272 	.db #0x11	; 17
      00C1B9 13                    1273 	.db #0x13	; 19
      00C1BA 04                    1274 	.db #0x04	; 4
      00C1BB 08                    1275 	.db #0x08	; 8
      00C1BC 12                    1276 	.db #0x12	; 18
      00C1BD 0C                    1277 	.db #0x0c	; 12
                                   1278 	.area CSEG    (CODE)
                                   1279 	.area CONST   (CODE)
      00C1BE                       1280 _get_alt_repeat_key_keycode_pairs_50000_215:
      00C1BE 0D                    1281 	.db #0x0d	; 13
      00C1BF 0E                    1282 	.db #0x0e	; 14
      00C1C0 0B                    1283 	.db #0x0b	; 11
      00C1C1 0F                    1284 	.db #0x0f	; 15
      00C1C2 1A                    1285 	.db #0x1a	; 26
      00C1C3 05                    1286 	.db #0x05	; 5
      00C1C4 08                    1287 	.db #0x08	; 8
      00C1C5 05                    1288 	.db #0x05	; 5
                                   1289 	.area CSEG    (CODE)
                                   1290 	.area CONST   (CODE)
      00C1C6                       1291 _get_alt_repeat_key_keycode_pairs_50000_217:
      00C1C6 50                    1292 	.db #0x50	; 80	'P'
      00C1C7 4F                    1293 	.db #0x4f	; 79	'O'
      00C1C8 52                    1294 	.db #0x52	; 82	'R'
      00C1C9 51                    1295 	.db #0x51	; 81	'Q'
      00C1CA 4A                    1296 	.db #0x4a	; 74	'J'
      00C1CB 4D                    1297 	.db #0x4d	; 77	'M'
      00C1CC 4B                    1298 	.db #0x4b	; 75	'K'
      00C1CD 4E                    1299 	.db #0x4e	; 78	'N'
      00C1CE 2A                    1300 	.db #0x2a	; 42
      00C1CF 4C                    1301 	.db #0x4c	; 76	'L'
      00C1D0 2F                    1302 	.db #0x2f	; 47
      00C1D1 30                    1303 	.db #0x30	; 48	'0'
      00C1D2 B6                    1304 	.db #0xb6	; 182
      00C1D3 B7                    1305 	.db #0xb7	; 183
      00C1D4 AB                    1306 	.db #0xab	; 171
      00C1D5 AC                    1307 	.db #0xac	; 172
      00C1D6 BB                    1308 	.db #0xbb	; 187
      00C1D7 BC                    1309 	.db #0xbc	; 188
      00C1D8 A9                    1310 	.db #0xa9	; 169
      00C1D9 AA                    1311 	.db #0xaa	; 170
      00C1DA BD                    1312 	.db #0xbd	; 189
      00C1DB BE                    1313 	.db #0xbe	; 190
      00C1DC CF                    1314 	.db #0xcf	; 207
      00C1DD D0                    1315 	.db #0xd0	; 208
      00C1DE CD                    1316 	.db #0xcd	; 205
      00C1DF CE                    1317 	.db #0xce	; 206
      00C1E0 DB                    1318 	.db #0xdb	; 219
      00C1E1 DC                    1319 	.db #0xdc	; 220
      00C1E2 D9                    1320 	.db #0xd9	; 217
      00C1E3 DA                    1321 	.db #0xda	; 218
                                   1322 	.area CSEG    (CODE)
                                   1323 	.area XINIT   (CODE)
      00C690                       1324 __xinit__last_mods:
      00C690 00                    1325 	.db #0x00	; 0
      00C691                       1326 __xinit__last_repeat_count:
      00C691 00                    1327 	.db #0x00	;  0
      00C692                       1328 __xinit__processing_repeat_count:
      00C692 00                    1329 	.db #0x00	;  0
                                   1330 	.area CABS    (ABS,CODE)
                                   1331 
                                   1332 ; Experimental exact instruction outlining.
                                   1333 	.globl _ak820_outline_0008
                                   1334 	.globl _ak820_outline_0012
                                   1335 	.globl _ak820_outline_0013
                                   1336 	.globl _ak820_outline_0014
                                   1337 	.globl _ak820_outline_0016
                                   1338 	.globl _ak820_outline_0034
                                   1339 	.globl _ak820_outline_0036
                                   1340 	.globl _ak820_outline_0040
                                   1341 	.globl _ak820_outline_0052
                                   1342 	.globl _ak820_outline_0059
                                   1343 	.globl _ak820_outline_0060
                                   1344 	.globl _ak820_outline_0072
                                   1345 	.globl _ak820_outline_0078
                                   1346 	.globl _ak820_outline_0093
                                   1347 	.globl _ak820_outline_0109
                                   1348 	.globl _ak820_outline_0110
                                   1349 	.globl _ak820_outline_0120
                                   1350 	.globl _ak820_outline_0126
                                   1351 	.globl _ak820_outline_0133
                                   1352 	.globl _ak820_outline_0137
                                   1353 	.globl _ak820_outline_0154
                                   1354 	.globl _ak820_outline_0175
                                   1355 	.globl _ak820_outline_0184
                                   1356 	.globl _ak820_outline_0189
                                   1357 
                                   1358 	.area CSEG (CODE)
                                   1359 ; function ak820_outline_0133
      00A9CE                       1360 _ak820_outline_0133:
      00A9CE AF 82            [24] 1361 	mov	r7,dpl
      00A9D0 90 0C 71         [24] 1362 	mov	dptr,#_get_alt_repeat_key_keycode_alt_keycode_10000_206
      00A9D3 EF               [12] 1363 	mov	a,r7
      00A9D4 F0               [24] 1364 	movx	@dptr,a
      00A9D5 E4               [12] 1365 	clr	a
      00A9D6 A3               [24] 1366 	inc	dptr
      00A9D7 F0               [24] 1367 	movx	@dptr,a
      00A9D8 22               [24] 1368 	ret
                                   1369 
                                   1370 	.area CSEG (CODE)
                                   1371 ; function ak820_outline_0175
      00A9D9                       1372 _ak820_outline_0175:
      00A9D9 90 0C 57         [24] 1373 	mov	dptr,#(_registered_record+0x0007)
      00A9DC E0               [24] 1374 	movx	a,@dptr
      00A9DD FB               [12] 1375 	mov	r3,a
      00A9DE A3               [24] 1376 	inc	dptr
      00A9DF E0               [24] 1377 	movx	a,@dptr
      00A9E0 4B               [12] 1378 	orl	a,r3
      00A9E1 22               [24] 1379 	ret
