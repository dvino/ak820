                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _register_mouse
                                     12 	.globl _ak820_combo_cancel
                                     13 	.globl _ak820_combo_tick
                                     14 	.globl _ak820_autoshift_cancel
                                     15 	.globl _ak820_autoshift_process
                                     16 	.globl _ak820_autoshift_before
                                     17 	.globl _ak820_oneshot_cancel
                                     18 	.globl _ak820_oneshot_post
                                     19 	.globl _ak820_oneshot_process
                                     20 	.globl _ak820_tapping_source
                                     21 	.globl _ak820_tapping_cancel
                                     22 	.globl _ak820_tapping_process
                                     23 	.globl _ak820_tapping_before
                                     24 	.globl _pre_process_record_quantum
                                     25 	.globl _get_record_keycode
                                     26 	.globl _repeat_key_cancel
                                     27 	.globl _clear_owned_usages
                                     28 	.globl _owned_usage_key
                                     29 	.globl _clear_owned_keys
                                     30 	.globl _del_owned_key
                                     31 	.globl _add_owned_key
                                     32 	.globl _clear_owned_mods
                                     33 	.globl _del_owned_weak_mods
                                     34 	.globl _add_owned_weak_mods
                                     35 	.globl _del_owned_mods
                                     36 	.globl _add_owned_mods
                                     37 	.globl _clear_weak_mods
                                     38 	.globl _clear_mods
                                     39 	.globl _send_keyboard_report
                                     40 	.globl _layer_hold_clear
                                     41 	.globl _layer_hold_off
                                     42 	.globl _layer_hold_on
                                     43 	.globl _ak820_resolve_key
                                     44 	.globl _layer_xor
                                     45 	.globl _layer_and
                                     46 	.globl _layer_or
                                     47 	.globl _layer_off
                                     48 	.globl _layer_on
                                     49 	.globl _layer_move
                                     50 	.globl _layer_clear
                                     51 	.globl _layer_state_set
                                     52 	.globl _default_layer_xor
                                     53 	.globl _default_layer_and
                                     54 	.globl _default_layer_or
                                     55 	.globl _default_layer_set
                                     56 	.globl _post_process_record_quantum
                                     57 	.globl _process_record_quantum
                                     58 	.globl _action_for_keycode
                                     59 	.globl _mousekey_send
                                     60 	.globl _mousekey_clear
                                     61 	.globl _mousekey_off
                                     62 	.globl _mousekey_on
                                     63 	.globl _mDelaymS
                                     64 	.globl _host_consumer_send
                                     65 	.globl _host_system_send
                                     66 	.globl _host_keyboard_leds
                                     67 	.globl _led_set
                                     68 	.globl _clear_keys_from_report
                                     69 	.globl ___memcpy
                                     70 	.globl _ADC_START
                                     71 	.globl _S0_R_FIFO
                                     72 	.globl _S0_T_FIFO
                                     73 	.globl _S0_FREE
                                     74 	.globl _S0_IF_BYTE
                                     75 	.globl _S0_IF_FIRST
                                     76 	.globl _S0_IF_OV
                                     77 	.globl _S0_FST_ACT
                                     78 	.globl _CP_RL2
                                     79 	.globl _C_T2
                                     80 	.globl _TR2
                                     81 	.globl _EXEN2
                                     82 	.globl _TCLK
                                     83 	.globl _RCLK
                                     84 	.globl _EXF2
                                     85 	.globl _CAP1F
                                     86 	.globl _TF2
                                     87 	.globl _RI
                                     88 	.globl _TI
                                     89 	.globl _RB8
                                     90 	.globl _TB8
                                     91 	.globl _REN
                                     92 	.globl _SM2
                                     93 	.globl _SM1
                                     94 	.globl _SM0
                                     95 	.globl _IT0
                                     96 	.globl _IE0
                                     97 	.globl _IT1
                                     98 	.globl _IE1
                                     99 	.globl _TR0
                                    100 	.globl _TF0
                                    101 	.globl _TR1
                                    102 	.globl _TF1
                                    103 	.globl _P4_0
                                    104 	.globl _P4_1
                                    105 	.globl _P4_2
                                    106 	.globl _P4_3
                                    107 	.globl _P4_4
                                    108 	.globl _P4_5
                                    109 	.globl _P4_6
                                    110 	.globl _RXD
                                    111 	.globl _TXD
                                    112 	.globl _INT0
                                    113 	.globl _INT1
                                    114 	.globl _T0
                                    115 	.globl _T1
                                    116 	.globl _MOSI1
                                    117 	.globl _MISO1
                                    118 	.globl _SCK1
                                    119 	.globl _P3_0
                                    120 	.globl _P3_1
                                    121 	.globl _P3_2
                                    122 	.globl _P3_3
                                    123 	.globl _P3_4
                                    124 	.globl _P3_5
                                    125 	.globl _P3_6
                                    126 	.globl _P3_7
                                    127 	.globl _CAP1_
                                    128 	.globl _T2_
                                    129 	.globl _CAP2_
                                    130 	.globl _T2EX_
                                    131 	.globl _RXD1
                                    132 	.globl _TXD1
                                    133 	.globl _P2_0
                                    134 	.globl _P2_1
                                    135 	.globl _P2_2
                                    136 	.globl _P2_3
                                    137 	.globl _P2_4
                                    138 	.globl _P2_5
                                    139 	.globl _P2_6
                                    140 	.globl _P2_7
                                    141 	.globl _AIN0
                                    142 	.globl _AIN1
                                    143 	.globl _AIN2
                                    144 	.globl _AIN3
                                    145 	.globl _AIN4
                                    146 	.globl _AIN5
                                    147 	.globl _AIN6
                                    148 	.globl _AIN7
                                    149 	.globl _CAP1
                                    150 	.globl _T2
                                    151 	.globl _CAP2
                                    152 	.globl _T2EX
                                    153 	.globl _INT0_
                                    154 	.globl _SCS
                                    155 	.globl _MOSI
                                    156 	.globl _MISO
                                    157 	.globl _SCK
                                    158 	.globl _RXD1_
                                    159 	.globl _TXD1_
                                    160 	.globl _P1_0
                                    161 	.globl _P1_1
                                    162 	.globl _P1_2
                                    163 	.globl _P1_3
                                    164 	.globl _P1_4
                                    165 	.globl _P1_5
                                    166 	.globl _P1_6
                                    167 	.globl _P1_7
                                    168 	.globl _AIN8
                                    169 	.globl _AIN9
                                    170 	.globl _AIN10
                                    171 	.globl _AIN11
                                    172 	.globl _AIN12
                                    173 	.globl _AIN13
                                    174 	.globl _RXD_
                                    175 	.globl _TXD_
                                    176 	.globl _SCL0
                                    177 	.globl _SDA0
                                    178 	.globl _P0_0
                                    179 	.globl _P0_1
                                    180 	.globl _P0_2
                                    181 	.globl _P0_3
                                    182 	.globl _P0_4
                                    183 	.globl _P0_5
                                    184 	.globl _P0_6
                                    185 	.globl _P0_7
                                    186 	.globl _IE_SPI0
                                    187 	.globl _IE_USB
                                    188 	.globl _IE_ADC
                                    189 	.globl _IE_UART1
                                    190 	.globl _IE_PWM_I2C
                                    191 	.globl _IE_GPIO
                                    192 	.globl _IE_WDOG
                                    193 	.globl _PX0
                                    194 	.globl _PT0
                                    195 	.globl _PX1
                                    196 	.globl _PT1
                                    197 	.globl _PS
                                    198 	.globl _PT2
                                    199 	.globl _PL_FLAG
                                    200 	.globl _PH_FLAG
                                    201 	.globl _EX0
                                    202 	.globl _ET0
                                    203 	.globl _EX1
                                    204 	.globl _ET1
                                    205 	.globl _ES
                                    206 	.globl _ET2
                                    207 	.globl _E_DIS
                                    208 	.globl _EA
                                    209 	.globl _P
                                    210 	.globl _F1
                                    211 	.globl _OV
                                    212 	.globl _RS0
                                    213 	.globl _RS1
                                    214 	.globl _F0
                                    215 	.globl _AC
                                    216 	.globl _CY
                                    217 	.globl _I2CS_INT_ST
                                    218 	.globl _I2CX_INT
                                    219 	.globl _LED_STATUS
                                    220 	.globl _LED_DMA_H
                                    221 	.globl _LED_DMA_L
                                    222 	.globl _LED_DMA
                                    223 	.globl _LED_PWM_OE
                                    224 	.globl _LED_COMMON
                                    225 	.globl _ADC_CHAN
                                    226 	.globl _ADC_DAT_H
                                    227 	.globl _ADC_DAT_L
                                    228 	.globl _ADC_DAT
                                    229 	.globl _ADC_CTRL
                                    230 	.globl _SPI1_CK_SE
                                    231 	.globl _SPI1_CTRL
                                    232 	.globl _SPI1_DATA
                                    233 	.globl _SPI1_STAT
                                    234 	.globl _SIF1
                                    235 	.globl _SBAUD1
                                    236 	.globl _SBUF1
                                    237 	.globl _SCON1
                                    238 	.globl _SPI0_SETUP
                                    239 	.globl _SPI0_CK_SE
                                    240 	.globl _SPI0_CTRL
                                    241 	.globl _SPI0_DATA
                                    242 	.globl _SPI0_STAT
                                    243 	.globl _T2CAP1H
                                    244 	.globl _T2CAP1L
                                    245 	.globl _T2CAP1
                                    246 	.globl _TH2
                                    247 	.globl _TL2
                                    248 	.globl _T2COUNT
                                    249 	.globl _RCAP2H
                                    250 	.globl _RCAP2L
                                    251 	.globl _RCAP2
                                    252 	.globl _T2MOD
                                    253 	.globl _T2CON
                                    254 	.globl _SBUF
                                    255 	.globl _SCON
                                    256 	.globl _TH1
                                    257 	.globl _TH0
                                    258 	.globl _TL1
                                    259 	.globl _TL0
                                    260 	.globl _TMOD
                                    261 	.globl _TCON
                                    262 	.globl _XBUS_AUX
                                    263 	.globl _P7
                                    264 	.globl _P6_DIR
                                    265 	.globl _P6_OUT_PU
                                    266 	.globl _P6_IN
                                    267 	.globl _P5_DIR
                                    268 	.globl _P5_OUT_PU
                                    269 	.globl _P5_IN
                                    270 	.globl _P4_LED_KEY
                                    271 	.globl _P4_DIR_PU
                                    272 	.globl _P4_MOD_OC
                                    273 	.globl _P4
                                    274 	.globl _P3_DIR_PU
                                    275 	.globl _P3_MOD_OC
                                    276 	.globl _P3
                                    277 	.globl _P2_DIR_PU
                                    278 	.globl _P2_MOD_OC
                                    279 	.globl _P2
                                    280 	.globl _P1_DIR_PU
                                    281 	.globl _P1_MOD_OC
                                    282 	.globl _P1
                                    283 	.globl _P0_DIR_PU
                                    284 	.globl _P0_MOD_OC
                                    285 	.globl _P0
                                    286 	.globl _ROM_CTRL
                                    287 	.globl _ROM_DATA_HH
                                    288 	.globl _ROM_DATA_HL
                                    289 	.globl _ROM_DATA_HI
                                    290 	.globl _ROM_ADDR_H
                                    291 	.globl _ROM_ADDR_L
                                    292 	.globl _ROM_ADDR
                                    293 	.globl _GPIO_IE
                                    294 	.globl _IP_EX
                                    295 	.globl _IE_EX
                                    296 	.globl _IP
                                    297 	.globl _IE
                                    298 	.globl _WDOG_COUNT
                                    299 	.globl _RESET_KEEP
                                    300 	.globl _WAKE_CTRL
                                    301 	.globl _CLOCK_CFG
                                    302 	.globl _POWER_CFG
                                    303 	.globl _PCON
                                    304 	.globl _GLOBAL_CFG
                                    305 	.globl _SAFE_MOD
                                    306 	.globl _DPH
                                    307 	.globl _DPL
                                    308 	.globl _SP
                                    309 	.globl _A_INV
                                    310 	.globl _B
                                    311 	.globl _ACC
                                    312 	.globl _PSW
                                    313 	.globl _disable_action_cache
                                    314 	.globl _tap_code_delay_PARM_2
                                    315 	.globl _process_action_PARM_2
                                    316 	.globl _register_mouse_PARM_2
                                    317 	.globl _action_exec_PARM_1
                                    318 	.globl _tp_buttons
                                    319 	.globl _action_exec
                                    320 	.globl _ak820_action_exec
                                    321 	.globl _process_record
                                    322 	.globl _process_record_handler
                                    323 	.globl _process_action
                                    324 	.globl _register_code
                                    325 	.globl _unregister_code
                                    326 	.globl _tap_code_delay
                                    327 	.globl _tap_code
                                    328 	.globl _register_mods
                                    329 	.globl _unregister_mods
                                    330 	.globl _register_weak_mods
                                    331 	.globl _unregister_weak_mods
                                    332 	.globl _clear_keyboard
                                    333 	.globl _clear_keyboard_but_mods
                                    334 	.globl _clear_keyboard_but_mods_and_keys
                                    335 ;--------------------------------------------------------
                                    336 ; special function registers
                                    337 ;--------------------------------------------------------
                                    338 	.area RSEG    (ABS,DATA)
      000000                        339 	.org 0x0000
                           0000D0   340 _PSW	=	0x00d0
                           0000E0   341 _ACC	=	0x00e0
                           0000F0   342 _B	=	0x00f0
                           0000FD   343 _A_INV	=	0x00fd
                           000081   344 _SP	=	0x0081
                           000082   345 _DPL	=	0x0082
                           000083   346 _DPH	=	0x0083
                           0000A1   347 _SAFE_MOD	=	0x00a1
                           0000B1   348 _GLOBAL_CFG	=	0x00b1
                           000087   349 _PCON	=	0x0087
                           0000BA   350 _POWER_CFG	=	0x00ba
                           0000B9   351 _CLOCK_CFG	=	0x00b9
                           0000A9   352 _WAKE_CTRL	=	0x00a9
                           0000FE   353 _RESET_KEEP	=	0x00fe
                           0000FF   354 _WDOG_COUNT	=	0x00ff
                           0000A8   355 _IE	=	0x00a8
                           0000B8   356 _IP	=	0x00b8
                           0000E8   357 _IE_EX	=	0x00e8
                           0000E9   358 _IP_EX	=	0x00e9
                           0000B2   359 _GPIO_IE	=	0x00b2
                           008584   360 _ROM_ADDR	=	0x8584
                           000084   361 _ROM_ADDR_L	=	0x0084
                           000085   362 _ROM_ADDR_H	=	0x0085
                           008F8E   363 _ROM_DATA_HI	=	0x8f8e
                           00008E   364 _ROM_DATA_HL	=	0x008e
                           00008F   365 _ROM_DATA_HH	=	0x008f
                           000086   366 _ROM_CTRL	=	0x0086
                           000080   367 _P0	=	0x0080
                           0000C4   368 _P0_MOD_OC	=	0x00c4
                           0000C5   369 _P0_DIR_PU	=	0x00c5
                           000090   370 _P1	=	0x0090
                           000092   371 _P1_MOD_OC	=	0x0092
                           000093   372 _P1_DIR_PU	=	0x0093
                           0000A0   373 _P2	=	0x00a0
                           000094   374 _P2_MOD_OC	=	0x0094
                           000095   375 _P2_DIR_PU	=	0x0095
                           0000B0   376 _P3	=	0x00b0
                           000096   377 _P3_MOD_OC	=	0x0096
                           000097   378 _P3_DIR_PU	=	0x0097
                           0000C0   379 _P4	=	0x00c0
                           0000C2   380 _P4_MOD_OC	=	0x00c2
                           0000C3   381 _P4_DIR_PU	=	0x00c3
                           0000C1   382 _P4_LED_KEY	=	0x00c1
                           0000AA   383 _P5_IN	=	0x00aa
                           0000AB   384 _P5_OUT_PU	=	0x00ab
                           0000AC   385 _P5_DIR	=	0x00ac
                           0000AD   386 _P6_IN	=	0x00ad
                           0000AE   387 _P6_OUT_PU	=	0x00ae
                           0000AF   388 _P6_DIR	=	0x00af
                           0000F1   389 _P7	=	0x00f1
                           0000A2   390 _XBUS_AUX	=	0x00a2
                           000088   391 _TCON	=	0x0088
                           000089   392 _TMOD	=	0x0089
                           00008A   393 _TL0	=	0x008a
                           00008B   394 _TL1	=	0x008b
                           00008C   395 _TH0	=	0x008c
                           00008D   396 _TH1	=	0x008d
                           000098   397 _SCON	=	0x0098
                           000099   398 _SBUF	=	0x0099
                           0000C8   399 _T2CON	=	0x00c8
                           0000C9   400 _T2MOD	=	0x00c9
                           00CBCA   401 _RCAP2	=	0xcbca
                           0000CA   402 _RCAP2L	=	0x00ca
                           0000CB   403 _RCAP2H	=	0x00cb
                           00CDCC   404 _T2COUNT	=	0xcdcc
                           0000CC   405 _TL2	=	0x00cc
                           0000CD   406 _TH2	=	0x00cd
                           00CFCE   407 _T2CAP1	=	0xcfce
                           0000CE   408 _T2CAP1L	=	0x00ce
                           0000CF   409 _T2CAP1H	=	0x00cf
                           0000F8   410 _SPI0_STAT	=	0x00f8
                           0000F9   411 _SPI0_DATA	=	0x00f9
                           0000FA   412 _SPI0_CTRL	=	0x00fa
                           0000FB   413 _SPI0_CK_SE	=	0x00fb
                           0000FC   414 _SPI0_SETUP	=	0x00fc
                           0000BC   415 _SCON1	=	0x00bc
                           0000BD   416 _SBUF1	=	0x00bd
                           0000BE   417 _SBAUD1	=	0x00be
                           0000BF   418 _SIF1	=	0x00bf
                           0000B4   419 _SPI1_STAT	=	0x00b4
                           0000B5   420 _SPI1_DATA	=	0x00b5
                           0000B6   421 _SPI1_CTRL	=	0x00b6
                           0000B7   422 _SPI1_CK_SE	=	0x00b7
                           0000F3   423 _ADC_CTRL	=	0x00f3
                           00F5F4   424 _ADC_DAT	=	0xf5f4
                           0000F4   425 _ADC_DAT_L	=	0x00f4
                           0000F5   426 _ADC_DAT_H	=	0x00f5
                           0000F6   427 _ADC_CHAN	=	0x00f6
                           0000A6   428 _LED_COMMON	=	0x00a6
                           0000A7   429 _LED_PWM_OE	=	0x00a7
                           00C7C6   430 _LED_DMA	=	0xc7c6
                           0000C6   431 _LED_DMA_L	=	0x00c6
                           0000C7   432 _LED_DMA_H	=	0x00c7
                           0000F7   433 _LED_STATUS	=	0x00f7
                           0000B3   434 _I2CX_INT	=	0x00b3
                           0000BB   435 _I2CS_INT_ST	=	0x00bb
                                    436 ;--------------------------------------------------------
                                    437 ; special function bits
                                    438 ;--------------------------------------------------------
                                    439 	.area RSEG    (ABS,DATA)
      000000                        440 	.org 0x0000
                           0000D7   441 _CY	=	0x00d7
                           0000D6   442 _AC	=	0x00d6
                           0000D5   443 _F0	=	0x00d5
                           0000D4   444 _RS1	=	0x00d4
                           0000D3   445 _RS0	=	0x00d3
                           0000D2   446 _OV	=	0x00d2
                           0000D1   447 _F1	=	0x00d1
                           0000D0   448 _P	=	0x00d0
                           0000AF   449 _EA	=	0x00af
                           0000AE   450 _E_DIS	=	0x00ae
                           0000AD   451 _ET2	=	0x00ad
                           0000AC   452 _ES	=	0x00ac
                           0000AB   453 _ET1	=	0x00ab
                           0000AA   454 _EX1	=	0x00aa
                           0000A9   455 _ET0	=	0x00a9
                           0000A8   456 _EX0	=	0x00a8
                           0000BF   457 _PH_FLAG	=	0x00bf
                           0000BE   458 _PL_FLAG	=	0x00be
                           0000BD   459 _PT2	=	0x00bd
                           0000BC   460 _PS	=	0x00bc
                           0000BB   461 _PT1	=	0x00bb
                           0000BA   462 _PX1	=	0x00ba
                           0000B9   463 _PT0	=	0x00b9
                           0000B8   464 _PX0	=	0x00b8
                           0000EF   465 _IE_WDOG	=	0x00ef
                           0000EE   466 _IE_GPIO	=	0x00ee
                           0000ED   467 _IE_PWM_I2C	=	0x00ed
                           0000EC   468 _IE_UART1	=	0x00ec
                           0000EB   469 _IE_ADC	=	0x00eb
                           0000E9   470 _IE_USB	=	0x00e9
                           0000E8   471 _IE_SPI0	=	0x00e8
                           000087   472 _P0_7	=	0x0087
                           000086   473 _P0_6	=	0x0086
                           000085   474 _P0_5	=	0x0085
                           000084   475 _P0_4	=	0x0084
                           000083   476 _P0_3	=	0x0083
                           000082   477 _P0_2	=	0x0082
                           000081   478 _P0_1	=	0x0081
                           000080   479 _P0_0	=	0x0080
                           000081   480 _SDA0	=	0x0081
                           000080   481 _SCL0	=	0x0080
                           000083   482 _TXD_	=	0x0083
                           000082   483 _RXD_	=	0x0082
                           000085   484 _AIN13	=	0x0085
                           000084   485 _AIN12	=	0x0084
                           000083   486 _AIN11	=	0x0083
                           000082   487 _AIN10	=	0x0082
                           000081   488 _AIN9	=	0x0081
                           000080   489 _AIN8	=	0x0080
                           000097   490 _P1_7	=	0x0097
                           000096   491 _P1_6	=	0x0096
                           000095   492 _P1_5	=	0x0095
                           000094   493 _P1_4	=	0x0094
                           000093   494 _P1_3	=	0x0093
                           000092   495 _P1_2	=	0x0092
                           000091   496 _P1_1	=	0x0091
                           000090   497 _P1_0	=	0x0090
                           000097   498 _TXD1_	=	0x0097
                           000096   499 _RXD1_	=	0x0096
                           000097   500 _SCK	=	0x0097
                           000096   501 _MISO	=	0x0096
                           000095   502 _MOSI	=	0x0095
                           000094   503 _SCS	=	0x0094
                           000092   504 _INT0_	=	0x0092
                           000091   505 _T2EX	=	0x0091
                           000091   506 _CAP2	=	0x0091
                           000090   507 _T2	=	0x0090
                           000090   508 _CAP1	=	0x0090
                           000097   509 _AIN7	=	0x0097
                           000096   510 _AIN6	=	0x0096
                           000095   511 _AIN5	=	0x0095
                           000094   512 _AIN4	=	0x0094
                           000093   513 _AIN3	=	0x0093
                           000092   514 _AIN2	=	0x0092
                           000091   515 _AIN1	=	0x0091
                           000090   516 _AIN0	=	0x0090
                           0000A7   517 _P2_7	=	0x00a7
                           0000A6   518 _P2_6	=	0x00a6
                           0000A5   519 _P2_5	=	0x00a5
                           0000A4   520 _P2_4	=	0x00a4
                           0000A3   521 _P2_3	=	0x00a3
                           0000A2   522 _P2_2	=	0x00a2
                           0000A1   523 _P2_1	=	0x00a1
                           0000A0   524 _P2_0	=	0x00a0
                           0000A7   525 _TXD1	=	0x00a7
                           0000A6   526 _RXD1	=	0x00a6
                           0000A5   527 _T2EX_	=	0x00a5
                           0000A5   528 _CAP2_	=	0x00a5
                           0000A4   529 _T2_	=	0x00a4
                           0000A4   530 _CAP1_	=	0x00a4
                           0000B7   531 _P3_7	=	0x00b7
                           0000B6   532 _P3_6	=	0x00b6
                           0000B5   533 _P3_5	=	0x00b5
                           0000B4   534 _P3_4	=	0x00b4
                           0000B3   535 _P3_3	=	0x00b3
                           0000B2   536 _P3_2	=	0x00b2
                           0000B1   537 _P3_1	=	0x00b1
                           0000B0   538 _P3_0	=	0x00b0
                           0000B7   539 _SCK1	=	0x00b7
                           0000B6   540 _MISO1	=	0x00b6
                           0000B5   541 _MOSI1	=	0x00b5
                           0000B5   542 _T1	=	0x00b5
                           0000B4   543 _T0	=	0x00b4
                           0000B3   544 _INT1	=	0x00b3
                           0000B2   545 _INT0	=	0x00b2
                           0000B1   546 _TXD	=	0x00b1
                           0000B0   547 _RXD	=	0x00b0
                           0000C6   548 _P4_6	=	0x00c6
                           0000C5   549 _P4_5	=	0x00c5
                           0000C4   550 _P4_4	=	0x00c4
                           0000C3   551 _P4_3	=	0x00c3
                           0000C2   552 _P4_2	=	0x00c2
                           0000C1   553 _P4_1	=	0x00c1
                           0000C0   554 _P4_0	=	0x00c0
                           00008F   555 _TF1	=	0x008f
                           00008E   556 _TR1	=	0x008e
                           00008D   557 _TF0	=	0x008d
                           00008C   558 _TR0	=	0x008c
                           00008B   559 _IE1	=	0x008b
                           00008A   560 _IT1	=	0x008a
                           000089   561 _IE0	=	0x0089
                           000088   562 _IT0	=	0x0088
                           00009F   563 _SM0	=	0x009f
                           00009E   564 _SM1	=	0x009e
                           00009D   565 _SM2	=	0x009d
                           00009C   566 _REN	=	0x009c
                           00009B   567 _TB8	=	0x009b
                           00009A   568 _RB8	=	0x009a
                           000099   569 _TI	=	0x0099
                           000098   570 _RI	=	0x0098
                           0000CF   571 _TF2	=	0x00cf
                           0000CF   572 _CAP1F	=	0x00cf
                           0000CE   573 _EXF2	=	0x00ce
                           0000CD   574 _RCLK	=	0x00cd
                           0000CC   575 _TCLK	=	0x00cc
                           0000CB   576 _EXEN2	=	0x00cb
                           0000CA   577 _TR2	=	0x00ca
                           0000C9   578 _C_T2	=	0x00c9
                           0000C8   579 _CP_RL2	=	0x00c8
                           0000FF   580 _S0_FST_ACT	=	0x00ff
                           0000FE   581 _S0_IF_OV	=	0x00fe
                           0000FD   582 _S0_IF_FIRST	=	0x00fd
                           0000FC   583 _S0_IF_BYTE	=	0x00fc
                           0000FB   584 _S0_FREE	=	0x00fb
                           0000FA   585 _S0_T_FIFO	=	0x00fa
                           0000F8   586 _S0_R_FIFO	=	0x00f8
                           0000F7   587 _ADC_START	=	0x00f7
                                    588 ;--------------------------------------------------------
                                    589 ; overlayable register banks
                                    590 ;--------------------------------------------------------
                                    591 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        592 	.ds 8
                                    593 ;--------------------------------------------------------
                                    594 ; internal ram data
                                    595 ;--------------------------------------------------------
                                    596 	.area DSEG    (DATA)
      000027                        597 _process_action_sloc0_1_0:
      000027                        598 	.ds 1
                                    599 ;--------------------------------------------------------
                                    600 ; overlayable items in internal ram
                                    601 ;--------------------------------------------------------
                                    602 ;--------------------------------------------------------
                                    603 ; indirectly addressable internal ram data
                                    604 ;--------------------------------------------------------
                                    605 	.area ISEG    (DATA)
                                    606 ;--------------------------------------------------------
                                    607 ; absolute internal ram data
                                    608 ;--------------------------------------------------------
                                    609 	.area IABS    (ABS,DATA)
                                    610 	.area IABS    (ABS,DATA)
                                    611 ;--------------------------------------------------------
                                    612 ; bit data
                                    613 ;--------------------------------------------------------
                                    614 	.area BSEG    (BIT)
      000020                        615 _process_action_sloc1_1_0:
      000020                        616 	.ds 1
                                    617 ;--------------------------------------------------------
                                    618 ; paged external ram data
                                    619 ;--------------------------------------------------------
                                    620 	.area PSEG    (PAG,XDATA)
                                    621 ;--------------------------------------------------------
                                    622 ; uninitialized external ram data
                                    623 ;--------------------------------------------------------
                                    624 	.area XSEG    (XDATA)
      000841                        625 _tp_buttons::
      000841                        626 	.ds 2
      000843                        627 _action_exec_PARM_1:
      000843                        628 	.ds 6
      000849                        629 _action_exec_record_10001_630:
      000849                        630 	.ds 9
      000852                        631 _ak820_action_exec_event_10000_635:
      000852                        632 	.ds 2
      000854                        633 _ak820_action_exec_snapshot_10000_636:
      000854                        634 	.ds 6
      00085A                        635 _process_record_record_10000_639:
      00085A                        636 	.ds 3
      00085D                        637 _process_record_handler_record_argument_10000_647:
      00085D                        638 	.ds 3
      000860                        639 _process_record_handler_action_10000_648:
      000860                        640 	.ds 2
      000862                        641 _register_mouse_PARM_2:
      000862                        642 	.ds 1
      000863                        643 _register_mouse_mouse_keycode_10000_656:
      000863                        644 	.ds 1
      000864                        645 _process_action_PARM_2:
      000864                        646 	.ds 2
      000866                        647 _process_action_record_argument_10000_663:
      000866                        648 	.ds 3
      000869                        649 _process_action_on_40000_686:
      000869                        650 	.ds 1
      00086A                        651 _register_code_code_10000_720:
      00086A                        652 	.ds 1
      00086B                        653 _unregister_code_code_10000_734:
      00086B                        654 	.ds 1
      00086C                        655 _tap_code_delay_PARM_2:
      00086C                        656 	.ds 2
      00086E                        657 _tap_code_delay_code_10000_747:
      00086E                        658 	.ds 1
      00086F                        659 _tap_code_code_10000_754:
      00086F                        660 	.ds 1
      000870                        661 _register_mods_mods_10000_756:
      000870                        662 	.ds 1
      000871                        663 _unregister_mods_mods_10000_760:
      000871                        664 	.ds 1
      000872                        665 _register_weak_mods_mods_10000_764:
      000872                        666 	.ds 1
      000873                        667 _unregister_weak_mods_mods_10000_768:
      000873                        668 	.ds 1
                                    669 ;--------------------------------------------------------
                                    670 ; absolute external ram data
                                    671 ;--------------------------------------------------------
                                    672 	.area XABS    (ABS,XDATA)
                                    673 ;--------------------------------------------------------
                                    674 ; initialized external ram data
                                    675 ;--------------------------------------------------------
                                    676 	.area XISEG   (XDATA)
      000DF6                        677 _disable_action_cache::
      000DF6                        678 	.ds 1
                                    679 	.area HOME    (CODE)
                                    680 	.area GSINIT0 (CODE)
                                    681 	.area GSINIT1 (CODE)
                                    682 	.area GSINIT2 (CODE)
                                    683 	.area GSINIT3 (CODE)
                                    684 	.area GSINIT4 (CODE)
                                    685 	.area GSINIT5 (CODE)
                                    686 	.area GSINIT  (CODE)
                                    687 	.area GSFINAL (CODE)
                                    688 	.area CSEG    (CODE)
                                    689 ;--------------------------------------------------------
                                    690 ; global & static initialisations
                                    691 ;--------------------------------------------------------
                                    692 	.area HOME    (CODE)
                                    693 	.area GSINIT  (CODE)
                                    694 	.area GSFINAL (CODE)
                                    695 	.area GSINIT  (CODE)
                                    696 ;--------------------------------------------------------
                                    697 ; Home
                                    698 ;--------------------------------------------------------
                                    699 	.area HOME    (CODE)
                                    700 	.area HOME    (CODE)
                                    701 ;--------------------------------------------------------
                                    702 ; code
                                    703 ;--------------------------------------------------------
                                    704 	.area CSEG    (CODE)
                                    705 ;------------------------------------------------------------
                                    706 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    707 ;------------------------------------------------------------
                                    708 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    709 ;------------------------------------------------------------
                                    710 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    711 ;	-----------------------------------------
                           000007   712 	ar7 = 0x07
                           000006   713 	ar6 = 0x06
                           000005   714 	ar5 = 0x05
                           000004   715 	ar4 = 0x04
                           000003   716 	ar3 = 0x03
                           000002   717 	ar2 = 0x02
                           000001   718 	ar1 = 0x01
                           000000   719 	ar0 = 0x00
                                    720 ;	 function action_exec
                                    721 ;	-----------------------------------------
      0074DA                        722 _action_exec:
                                    723 ;	quantum/action.c:92: ak820_combo_tick(event.time);
      0074DA 90 08 45         [24]  724 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      0074DD 12 3A 34         [24]  725 	lcall	_ak820_outline_0005
      0074E0 12 38 4B         [24]  726 	lcall	_ak820_combo_tick
                                    727 ;	quantum/action.c:95: if (!ak820_tapping_before(&event)) return;
      0074E3 90 08 43         [24]  728 	mov	dptr,#_action_exec_PARM_1
      0074E6 12 46 8D         [24]  729 	lcall	_ak820_tapping_before
      0074E9 E5 82            [12]  730 	mov	a, dpl
      0074EB 70 01            [24]  731 	jnz	00102$
      0074ED 22               [24]  732 	ret
      0074EE                        733 00102$:
                                    734 ;	quantum/action.c:97: if (!ak820_autoshift_before(&event)) return;
      0074EE 90 08 43         [24]  735 	mov	dptr,#_action_exec_PARM_1
      0074F1 12 31 2D         [24]  736 	lcall	_ak820_autoshift_before
      0074F4 E5 82            [12]  737 	mov	a, dpl
      0074F6 70 01            [24]  738 	jnz	00104$
      0074F8 22               [24]  739 	ret
      0074F9                        740 00104$:
                                    741 ;	quantum/action.c:113: if (event.pressed) {
      0074F9 90 08 48         [24]  742 	mov	dptr,#(_action_exec_PARM_1 + 0x0005)
      0074FC E0               [24]  743 	movx	a,@dptr
      0074FD 60 03            [24]  744 	jz	00106$
                                    745 ;	quantum/action.c:115: clear_weak_mods();
      0074FF 12 85 F8         [24]  746 	lcall	_clear_weak_mods
      007502                        747 00106$:
                                    748 ;	quantum/action.c:127: record.event = event;
      007502 90 0D D5         [24]  749 	mov	dptr,#___memcpy_PARM_2
      007505 74 43            [12]  750 	mov	a,#_action_exec_PARM_1
      007507 F0               [24]  751 	movx	@dptr,a
      007508 74 08            [12]  752 	mov	a,#(_action_exec_PARM_1 >> 8)
      00750A 12 3A B0         [24]  753 	lcall	_ak820_outline_0093
      00750D 12 7C 27         [24]  754 	lcall	_ak820_outline_0071
      007510 90 08 49         [24]  755 	mov	dptr,#_action_exec_record_10001_630
      007513 F5 F0            [12]  756 	mov	b,a
      007515 12 BD 16         [24]  757 	lcall	___memcpy
                                    758 ;	quantum/action.c:129: record.tap.count = 0;
      007518 90 08 4F         [24]  759 	mov	dptr,#(_action_exec_record_10001_630 + 0x0006)
      00751B E0               [24]  760 	movx	a,@dptr
      00751C 54 0F            [12]  761 	anl	a,#0x0f
      00751E F0               [24]  762 	movx	@dptr,a
                                    763 ;	quantum/action.c:134: record.keycode = 0;
      00751F 90 08 50         [24]  764 	mov	dptr,#(_action_exec_record_10001_630 + 0x0007)
      007522 12 51 B6         [24]  765 	lcall	_ak820_outline_0184
                                    766 ;	quantum/action.c:165: if (IS_NOEVENT(record.event) || pre_process_record_quantum(&record)) {
      007525 90 08 4D         [24]  767 	mov	dptr,#(_action_exec_record_10001_630 + 0x0004)
      007528 E0               [24]  768 	movx	a,@dptr
      007529 60 0D            [24]  769 	jz	00111$
      00752B 90 08 49         [24]  770 	mov	dptr,#_action_exec_record_10001_630
      00752E 75 F0 00         [24]  771 	mov	b, #0x00
      007531 12 A3 92         [24]  772 	lcall	_pre_process_record_quantum
      007534 E5 82            [12]  773 	mov	a, dpl
      007536 60 1E            [24]  774 	jz	00114$
      007538                        775 00111$:
                                    776 ;	quantum/action.c:167: if (!ak820_tapping_process(&record)) return;
      007538 90 08 49         [24]  777 	mov	dptr,#_action_exec_record_10001_630
      00753B 12 47 6A         [24]  778 	lcall	_ak820_tapping_process
      00753E E5 82            [12]  779 	mov	a, dpl
      007540 70 01            [24]  780 	jnz	00108$
      007542 22               [24]  781 	ret
      007543                        782 00108$:
                                    783 ;	quantum/action.c:169: if (!ak820_autoshift_process(&record)) return;
      007543 90 08 49         [24]  784 	mov	dptr,#_action_exec_record_10001_630
      007546 12 32 35         [24]  785 	lcall	_ak820_autoshift_process
      007549 E5 82            [12]  786 	mov	a, dpl
      00754B 70 01            [24]  787 	jnz	00110$
      00754D 22               [24]  788 	ret
      00754E                        789 00110$:
                                    790 ;	quantum/action.c:172: process_record(&record);
      00754E 90 08 49         [24]  791 	mov	dptr,#_action_exec_record_10001_630
      007551 75 F0 00         [24]  792 	mov	b, #0x00
                                    793 ;	quantum/action.c:182: }
      007554 A1 92            [12]  794 	ajmp	_process_record
      007556                        795 00114$:
      007556 22               [24]  796 	ret
                                    797 ;------------------------------------------------------------
                                    798 ;Allocation info for local variables in function 'ak820_action_exec'
                                    799 ;------------------------------------------------------------
                                    800 ;event         Allocated with name '_ak820_action_exec_event_10000_635'
                                    801 ;snapshot      Allocated with name '_ak820_action_exec_snapshot_10000_636'
                                    802 ;------------------------------------------------------------
                                    803 ;	quantum/action.c:185: void ak820_action_exec(const keyevent_t __xdata *event) {
                                    804 ;	-----------------------------------------
                                    805 ;	 function ak820_action_exec
                                    806 ;	-----------------------------------------
      007557                        807 _ak820_action_exec:
      007557 12 3A C2         [24]  808 	lcall	_ak820_outline_0109
      00755A 90 08 52         [24]  809 	mov	dptr,#_ak820_action_exec_event_10000_635
      00755D 12 3A C7         [24]  810 	lcall	_ak820_outline_0110
                                    811 ;	quantum/action.c:188: keyevent_t snapshot = *event;
      007560 90 08 52         [24]  812 	mov	dptr,#_ak820_action_exec_event_10000_635
      007563 12 3A AA         [24]  813 	lcall	_ak820_outline_0085
      007566 7F 00            [12]  814 	mov	r7,#0x00
      007568 90 0D D5         [24]  815 	mov	dptr,#___memcpy_PARM_2
      00756B ED               [12]  816 	mov	a,r5
      00756C 12 3A 5F         [24]  817 	lcall	_ak820_outline_0016
      00756F 12 7C 27         [24]  818 	lcall	_ak820_outline_0071
      007572 90 08 54         [24]  819 	mov	dptr,#_ak820_action_exec_snapshot_10000_636
      007575 F5 F0            [12]  820 	mov	b,a
      007577 12 BD 16         [24]  821 	lcall	___memcpy
                                    822 ;	quantum/action.c:189: action_exec(snapshot);
      00757A 90 0D D5         [24]  823 	mov	dptr,#___memcpy_PARM_2
      00757D 74 54            [12]  824 	mov	a,#_ak820_action_exec_snapshot_10000_636
      00757F F0               [24]  825 	movx	@dptr,a
      007580 74 08            [12]  826 	mov	a,#(_ak820_action_exec_snapshot_10000_636 >> 8)
      007582 12 3A B0         [24]  827 	lcall	_ak820_outline_0093
      007585 12 7C 27         [24]  828 	lcall	_ak820_outline_0071
      007588 90 08 43         [24]  829 	mov	dptr,#_action_exec_PARM_1
      00758B F5 F0            [12]  830 	mov	b,a
      00758D 12 BD 16         [24]  831 	lcall	___memcpy
                                    832 ;	quantum/action.c:190: }
      007590 81 DA            [12]  833 	ajmp	_action_exec
                                    834 ;------------------------------------------------------------
                                    835 ;Allocation info for local variables in function 'process_record_nocache'
                                    836 ;------------------------------------------------------------
                                    837 ;record        Allocated with name '_process_record_nocache_record_10000_637'
                                    838 ;------------------------------------------------------------
                                    839 ;	quantum/action.c:275: void process_record_nocache(keyrecord_t *record) {
                                    840 ;	-----------------------------------------
                                    841 ;	 function process_record
                                    842 ;	-----------------------------------------
      007592                        843 _process_record:
      007592 12 45 55         [24]  844 	lcall	_ak820_outline_0036
      007595 90 08 5A         [24]  845 	mov	dptr,#_process_record_record_10000_639
      007598 12 3A 5F         [24]  846 	lcall	_ak820_outline_0016
                                    847 ;	quantum/action.c:329: if (IS_NOEVENT(record->event)) {
      00759B 90 08 5A         [24]  848 	mov	dptr,#_process_record_record_10000_639
      00759E 12 51 63         [24]  849 	lcall	_ak820_outline_0012
      0075A1 74 04            [12]  850 	mov	a,#0x04
      0075A3 12 7B FA         [24]  851 	lcall	_ak820_outline_0014
      0075A6 12 BD EF         [24]  852 	lcall	__gptrget
      0075A9 70 01            [24]  853 	jnz	00102$
                                    854 ;	quantum/action.c:330: return;
      0075AB 22               [24]  855 	ret
      0075AC                        856 00102$:
                                    857 ;	quantum/action.c:338: uint8_t oneshot_source = ak820_tapping_source(record->event.key);
      0075AC 8D 02            [24]  858 	mov	ar2,r5
      0075AE 8E 03            [24]  859 	mov	ar3,r6
      0075B0 8F 04            [24]  860 	mov	ar4,r7
      0075B2 90 0D D5         [24]  861 	mov	dptr,#___memcpy_PARM_2
      0075B5 EA               [12]  862 	mov	a,r2
      0075B6 12 7C 6E         [24]  863 	lcall	_ak820_outline_0189
      0075B9 EC               [12]  864 	mov	a,r4
      0075BA A3               [24]  865 	inc	dptr
      0075BB F0               [24]  866 	movx	@dptr,a
      0075BC 90 0D D8         [24]  867 	mov	dptr,#___memcpy_PARM_3
      0075BF 12 51 A8         [24]  868 	lcall	_ak820_outline_0112
      0075C2 90 06 34         [24]  869 	mov	dptr,#_ak820_tapping_source_PARM_1
      0075C5 F5 F0            [12]  870 	mov	b,a
      0075C7 C0 07            [24]  871 	push	ar7
      0075C9 C0 06            [24]  872 	push	ar6
      0075CB C0 05            [24]  873 	push	ar5
      0075CD 12 BD 16         [24]  874 	lcall	___memcpy
      0075D0 12 45 C8         [24]  875 	lcall	_ak820_tapping_source
      0075D3 AC 82            [24]  876 	mov	r4, dpl
      0075D5 D0 05            [24]  877 	pop	ar5
      0075D7 D0 06            [24]  878 	pop	ar6
      0075D9 D0 07            [24]  879 	pop	ar7
                                    880 ;	quantum/action.c:339: bool oneshot_pressed = record->event.pressed;
      0075DB 74 05            [12]  881 	mov	a,#0x05
      0075DD 12 7B EC         [24]  882 	lcall	_ak820_outline_0013
      0075E0 12 BD EF         [24]  883 	lcall	__gptrget
      0075E3 FB               [12]  884 	mov	r3,a
                                    885 ;	quantum/action.c:340: record->keycode = get_record_keycode(record, true);
      0075E4 12 7C 5F         [24]  886 	lcall	_ak820_outline_0150
      0075E7 90 0C 2C         [24]  887 	mov	dptr,#_get_record_keycode_PARM_2
      0075EA 74 01            [12]  888 	mov	a,#0x01
      0075EC 12 51 6C         [24]  889 	lcall	_ak820_outline_0034
      0075EF C0 04            [24]  890 	push	ar4
      0075F1 C0 03            [24]  891 	push	ar3
      0075F3 C0 02            [24]  892 	push	ar2
      0075F5 C0 01            [24]  893 	push	ar1
      0075F7 C0 00            [24]  894 	push	ar0
      0075F9 12 A3 54         [24]  895 	lcall	_get_record_keycode
      0075FC 12 45 97         [24]  896 	lcall	_ak820_outline_0136
      0075FF D0 00            [24]  897 	pop	ar0
      007601 D0 01            [24]  898 	pop	ar1
      007603 D0 02            [24]  899 	pop	ar2
      007605 D0 03            [24]  900 	pop	ar3
      007607 D0 04            [24]  901 	pop	ar4
      007609 12 4B 01         [24]  902 	lcall	_ak820_outline_0114
      00760C EE               [12]  903 	mov	a,r6
      00760D 12 BD B4         [24]  904 	lcall	__gptrput
      007610 A3               [24]  905 	inc	dptr
      007611 EF               [12]  906 	mov	a,r7
      007612 12 BD B4         [24]  907 	lcall	__gptrput
                                    908 ;	quantum/action.c:341: if (!ak820_oneshot_process(record->keycode, oneshot_source, oneshot_pressed)) return;
      007615 90 08 5A         [24]  909 	mov	dptr,#_process_record_record_10000_639
      007618 12 51 63         [24]  910 	lcall	_ak820_outline_0012
      00761B 12 7C 5F         [24]  911 	lcall	_ak820_outline_0150
      00761E 12 4B 01         [24]  912 	lcall	_ak820_outline_0114
      007621 12 BD EF         [24]  913 	lcall	__gptrget
      007624 F8               [12]  914 	mov	r0,a
      007625 A3               [24]  915 	inc	dptr
      007626 12 BD EF         [24]  916 	lcall	__gptrget
      007629 F9               [12]  917 	mov	r1,a
      00762A 90 06 44         [24]  918 	mov	dptr,#_ak820_oneshot_process_PARM_2
      00762D EC               [12]  919 	mov	a,r4
      00762E F0               [24]  920 	movx	@dptr,a
      00762F 90 06 45         [24]  921 	mov	dptr,#_ak820_oneshot_process_PARM_3
      007632 EB               [12]  922 	mov	a,r3
      007633 F0               [24]  923 	movx	@dptr,a
      007634 12 3A F6         [24]  924 	lcall	_ak820_outline_0163
      007637 C0 07            [24]  925 	push	ar7
      007639 C0 06            [24]  926 	push	ar6
      00763B C0 05            [24]  927 	push	ar5
      00763D C0 04            [24]  928 	push	ar4
      00763F C0 03            [24]  929 	push	ar3
      007641 12 49 20         [24]  930 	lcall	_ak820_oneshot_process
      007644 E5 82            [12]  931 	mov	a, dpl
      007646 D0 03            [24]  932 	pop	ar3
      007648 D0 04            [24]  933 	pop	ar4
      00764A D0 05            [24]  934 	pop	ar5
      00764C D0 06            [24]  935 	pop	ar6
      00764E D0 07            [24]  936 	pop	ar7
      007650 70 01            [24]  937 	jnz	00104$
      007652 22               [24]  938 	ret
      007653                        939 00104$:
                                    940 ;	quantum/action.c:343: if (!process_record_quantum(record)) {
      007653 12 72 23         [24]  941 	lcall	_ak820_outline_0059
      007656 C0 04            [24]  942 	push	ar4
      007658 C0 03            [24]  943 	push	ar3
      00765A 12 A4 16         [24]  944 	lcall	_process_record_quantum
      00765D E5 82            [12]  945 	mov	a, dpl
      00765F D0 03            [24]  946 	pop	ar3
      007661 D0 04            [24]  947 	pop	ar4
      007663 70 0A            [24]  948 	jnz	00106$
                                    949 ;	quantum/action.c:345: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      007665 90 05 AC         [24]  950 	mov	dptr,#_ak820_oneshot_post_PARM_2
      007668 EB               [12]  951 	mov	a,r3
      007669 F0               [24]  952 	movx	@dptr,a
      00766A 8C 82            [24]  953 	mov	dpl, r4
                                    954 ;	quantum/action.c:352: return;
      00766C 02 2E BB         [24]  955 	ljmp	_ak820_oneshot_post
      00766F                        956 00106$:
                                    957 ;	quantum/action.c:358: process_record_handler(record);
      00766F 90 08 5A         [24]  958 	mov	dptr,#_process_record_record_10000_639
      007672 12 51 3D         [24]  959 	lcall	_ak820_outline_0001
      007675 C0 04            [24]  960 	push	ar4
      007677 C0 03            [24]  961 	push	ar3
      007679 D1 92            [24]  962 	acall	_process_record_handler
                                    963 ;	quantum/action.c:362: post_process_record_quantum(record);
      00767B 90 08 5A         [24]  964 	mov	dptr,#_process_record_record_10000_639
      00767E 12 51 3D         [24]  965 	lcall	_ak820_outline_0001
      007681 12 A3 ED         [24]  966 	lcall	_post_process_record_quantum
      007684 D0 03            [24]  967 	pop	ar3
      007686 D0 04            [24]  968 	pop	ar4
                                    969 ;	quantum/action.c:364: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      007688 90 05 AC         [24]  970 	mov	dptr,#_ak820_oneshot_post_PARM_2
      00768B EB               [12]  971 	mov	a,r3
      00768C F0               [24]  972 	movx	@dptr,a
      00768D 8C 82            [24]  973 	mov	dpl, r4
                                    974 ;	quantum/action.c:366: }
      00768F 02 2E BB         [24]  975 	ljmp	_ak820_oneshot_post
                                    976 ;------------------------------------------------------------
                                    977 ;Allocation info for local variables in function 'process_record_handler'
                                    978 ;------------------------------------------------------------
                                    979 ;record_argument Allocated with name '_process_record_handler_record_argument_10000_647'
                                    980 ;record        Allocated with name '_process_record_handler_record_10000_648'
                                    981 ;action        Allocated with name '_process_record_handler_action_10000_648'
                                    982 ;------------------------------------------------------------
                                    983 ;	quantum/action.c:368: void process_record_handler(keyrecord_t *record_argument) {
                                    984 ;	-----------------------------------------
                                    985 ;	 function process_record_handler
                                    986 ;	-----------------------------------------
      007692                        987 _process_record_handler:
      007692 12 45 55         [24]  988 	lcall	_ak820_outline_0036
      007695 90 08 5D         [24]  989 	mov	dptr,#_process_record_handler_record_argument_10000_647
      007698 12 3A 5F         [24]  990 	lcall	_ak820_outline_0016
                                    991 ;	quantum/action.c:372: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00769B 90 08 5D         [24]  992 	mov	dptr,#_process_record_handler_record_argument_10000_647
      00769E 12 3A 3E         [24]  993 	lcall	_ak820_outline_0007
                                    994 ;	quantum/action.c:379: if (record->keycode) {
      0076A1 4C               [12]  995 	orl	a,r4
      0076A2 60 19            [24]  996 	jz	00102$
                                    997 ;	quantum/action.c:380: action.code = action_for_keycode(record->keycode);
      0076A4 12 3A D7         [24]  998 	lcall	_ak820_outline_0126
      0076A7 C0 07            [24]  999 	push	ar7
      0076A9 C0 06            [24] 1000 	push	ar6
      0076AB 12 99 A5         [24] 1001 	lcall	_action_for_keycode
      0076AE 12 45 A8         [24] 1002 	lcall	_ak820_outline_0154
      0076B1 D0 06            [24] 1003 	pop	ar6
      0076B3 D0 07            [24] 1004 	pop	ar7
      0076B5 90 08 60         [24] 1005 	mov	dptr,#_process_record_handler_action_10000_648
      0076B8 12 3A 9E         [24] 1006 	lcall	_ak820_outline_0072
      0076BB 80 2B            [24] 1007 	sjmp	00104$
      0076BD                       1008 00102$:
                                   1009 ;	quantum/action.c:383: action.code = action_for_keycode(ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed));
      0076BD 12 7C 08         [24] 1010 	lcall	_ak820_outline_0020
      0076C0 7A 00            [12] 1011 	mov	r2,#0x00
      0076C2 12 45 A2         [24] 1012 	lcall	_ak820_outline_0146
      0076C5 12 45 43         [24] 1013 	lcall	_ak820_outline_0011
      0076C8 E0               [24] 1014 	movx	a,@dptr
      0076C9 90 09 9E         [24] 1015 	mov	dptr,#_ak820_resolve_key_PARM_2
      0076CC F0               [24] 1016 	movx	@dptr,a
      0076CD 8D 82            [24] 1017 	mov	dpl, r5
      0076CF 8C 83            [24] 1018 	mov	dph, r4
      0076D1 C0 07            [24] 1019 	push	ar7
      0076D3 C0 06            [24] 1020 	push	ar6
      0076D5 12 7F 9D         [24] 1021 	lcall	_ak820_resolve_key
      0076D8 12 99 A5         [24] 1022 	lcall	_action_for_keycode
      0076DB 12 45 A8         [24] 1023 	lcall	_ak820_outline_0154
      0076DE D0 06            [24] 1024 	pop	ar6
      0076E0 D0 07            [24] 1025 	pop	ar7
      0076E2 90 08 60         [24] 1026 	mov	dptr,#_process_record_handler_action_10000_648
      0076E5 12 3A 9E         [24] 1027 	lcall	_ak820_outline_0072
                                   1028 ;	quantum/action.c:392: ac_dprintf("ACTION: ");
      0076E8                       1029 00104$:
                                   1030 ;	quantum/action.c:403: process_action(record, action);
      0076E8 7D 00            [12] 1031 	mov	r5,#0x00
      0076EA 90 0D D5         [24] 1032 	mov	dptr,#___memcpy_PARM_2
      0076ED 74 60            [12] 1033 	mov	a,#_process_record_handler_action_10000_648
      0076EF F0               [24] 1034 	movx	@dptr,a
      0076F0 74 08            [12] 1035 	mov	a,#(_process_record_handler_action_10000_648 >> 8)
      0076F2 12 3A B0         [24] 1036 	lcall	_ak820_outline_0093
      0076F5 90 0D D8         [24] 1037 	mov	dptr,#___memcpy_PARM_3
      0076F8 12 51 A8         [24] 1038 	lcall	_ak820_outline_0112
      0076FB 90 08 64         [24] 1039 	mov	dptr,#_process_action_PARM_2
      0076FE F5 F0            [12] 1040 	mov	b,a
      007700 C0 07            [24] 1041 	push	ar7
      007702 C0 06            [24] 1042 	push	ar6
      007704 C0 05            [24] 1043 	push	ar5
      007706 12 BD 16         [24] 1044 	lcall	___memcpy
      007709 D0 05            [24] 1045 	pop	ar5
      00770B D0 06            [24] 1046 	pop	ar6
      00770D D0 07            [24] 1047 	pop	ar7
      00770F 12 74 45         [24] 1048 	lcall	_ak820_outline_0050
                                   1049 ;	quantum/action.c:404: }
      007712 E1 37            [24] 1050 	ajmp	_process_action
                                   1051 ;------------------------------------------------------------
                                   1052 ;Allocation info for local variables in function 'register_mouse'
                                   1053 ;------------------------------------------------------------
                                   1054 ;pressed       Allocated with name '_register_mouse_PARM_2'
                                   1055 ;mouse_keycode Allocated with name '_register_mouse_mouse_keycode_10000_656'
                                   1056 ;------------------------------------------------------------
                                   1057 ;	quantum/action.c:416: void register_mouse(uint8_t mouse_keycode, bool pressed) {
                                   1058 ;	-----------------------------------------
                                   1059 ;	 function register_mouse
                                   1060 ;	-----------------------------------------
      007714                       1061 _register_mouse:
      007714 E5 82            [12] 1062 	mov	a,dpl
      007716 90 08 63         [24] 1063 	mov	dptr,#_register_mouse_mouse_keycode_10000_656
      007719 F0               [24] 1064 	movx	@dptr,a
                                   1065 ;	quantum/action.c:419: if (pressed) {
      00771A 90 08 62         [24] 1066 	mov	dptr,#_register_mouse_PARM_2
      00771D E0               [24] 1067 	movx	a,@dptr
      00771E 60 0B            [24] 1068 	jz	00102$
                                   1069 ;	quantum/action.c:420: mousekey_on(mouse_keycode);
      007720 90 08 63         [24] 1070 	mov	dptr,#_register_mouse_mouse_keycode_10000_656
      007723 E0               [24] 1071 	movx	a,@dptr
      007724 F5 82            [12] 1072 	mov	dpl,a
      007726 12 52 06         [24] 1073 	lcall	_mousekey_on
      007729 80 09            [24] 1074 	sjmp	00103$
      00772B                       1075 00102$:
                                   1076 ;	quantum/action.c:422: mousekey_off(mouse_keycode);
      00772B 90 08 63         [24] 1077 	mov	dptr,#_register_mouse_mouse_keycode_10000_656
      00772E E0               [24] 1078 	movx	a,@dptr
      00772F F5 82            [12] 1079 	mov	dpl,a
      007731 12 52 7A         [24] 1080 	lcall	_mousekey_off
      007734                       1081 00103$:
                                   1082 ;	quantum/action.c:443: mousekey_send();
                                   1083 ;	quantum/action.c:445: }
                                   1084 ;	quantum/action.c:461: }
      007734 02 52 D9         [24] 1085 	ljmp	_mousekey_send
                                   1086 ;------------------------------------------------------------
                                   1087 ;Allocation info for local variables in function 'process_action'
                                   1088 ;------------------------------------------------------------
                                   1089 ;sloc0         Allocated with name '_process_action_sloc0_1_0'
                                   1090 ;action        Allocated with name '_process_action_PARM_2'
                                   1091 ;record_argument Allocated with name '_process_action_record_argument_10000_663'
                                   1092 ;record        Allocated with name '_process_action_record_10000_664'
                                   1093 ;pressed       Allocated with name '_process_action_pressed_10000_664'
                                   1094 ;mods          Allocated with name '_process_action_mods_10000_664'
                                   1095 ;on            Allocated with name '_process_action_on_40000_686'
                                   1096 ;shift         Allocated with name '_process_action_shift_60000_688'
                                   1097 ;bits          Allocated with name '_process_action_bits_60000_688'
                                   1098 ;mask          Allocated with name '_process_action_mask_60000_688'
                                   1099 ;i             Allocated with name '_process_action_i_110000_712'
                                   1100 ;i             Allocated with name '_process_action_i_110000_716'
                                   1101 ;------------------------------------------------------------
                                   1102 ;	quantum/action.c:467: void process_action(keyrecord_t *record_argument, action_t action) {
                                   1103 ;	-----------------------------------------
                                   1104 ;	 function process_action
                                   1105 ;	-----------------------------------------
      007737                       1106 _process_action:
      007737 12 45 55         [24] 1107 	lcall	_ak820_outline_0036
      00773A 90 08 66         [24] 1108 	mov	dptr,#_process_action_record_argument_10000_663
      00773D 12 3A 5F         [24] 1109 	lcall	_ak820_outline_0016
                                   1110 ;	quantum/action.c:469: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      007740 90 08 66         [24] 1111 	mov	dptr,#_process_action_record_argument_10000_663
      007743 12 3A 34         [24] 1112 	lcall	_ak820_outline_0005
                                   1113 ;	quantum/action.c:475: pressed = record->event.pressed;
      007746 A3               [24] 1114 	inc	dptr
      007747 A3               [24] 1115 	inc	dptr
      007748 A3               [24] 1116 	inc	dptr
      007749 A3               [24] 1117 	inc	dptr
      00774A A3               [24] 1118 	inc	dptr
      00774B E0               [24] 1119 	movx	a,@dptr
      00774C F5 27            [12] 1120 	mov	_process_action_sloc0_1_0,a
                                   1121 ;	quantum/action.c:499: switch (action.kind.id) {
      00774E 90 08 65         [24] 1122 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007751 E0               [24] 1123 	movx	a,@dptr
      007752 C4               [12] 1124 	swap	a
      007753 54 0F            [12] 1125 	anl	a,#0x0f
      007755 FD               [12] 1126 	mov  r5,a
      007756 24 F4            [12] 1127 	add	a,#0xff - 0x0b
      007758 50 03            [24] 1128 	jnc	00434$
      00775A 02 79 EA         [24] 1129 	ljmp	00181$
      00775D                       1130 00434$:
                                   1131 ;	free result
      00775D ED               [12] 1132 	mov	a,r5
      00775E 24 0A            [12] 1133 	add	a,#(00435$-3-.)
      007760 83               [24] 1134 	movc	a,@a+pc
      007761 F5 82            [12] 1135 	mov	dpl,a
      007763 ED               [12] 1136 	mov	a,r5
      007764 24 10            [12] 1137 	add	a,#(00436$-3-.)
      007766 83               [24] 1138 	movc	a,@a+pc
      007767 F5 83            [12] 1139 	mov	dph,a
      007769 E4               [12] 1140 	clr	a
      00776A 73               [24] 1141 	jmp	@a+dptr
      00776B                       1142 00435$:
      00776B 83                    1143 	.db	00102$
      00776C 83                    1144 	.db	00102$
      00776D EA                    1145 	.db	00181$
      00776E EA                    1146 	.db	00181$
      00776F 0D                    1147 	.db	00123$
      007770 6D                    1148 	.db	00130$
      007771 EA                    1149 	.db	00181$
      007772 EA                    1150 	.db	00181$
      007773 7F                    1151 	.db	00131$
      007774 51                    1152 	.db	00147$
      007775 77                    1153 	.db	00152$
      007776 77                    1154 	.db	00152$
      007777                       1155 00436$:
      007777 77                    1156 	.db	00102$>>8
      007778 77                    1157 	.db	00102$>>8
      007779 79                    1158 	.db	00181$>>8
      00777A 79                    1159 	.db	00181$>>8
      00777B 78                    1160 	.db	00123$>>8
      00777C 78                    1161 	.db	00130$>>8
      00777D 79                    1162 	.db	00181$>>8
      00777E 79                    1163 	.db	00181$>>8
      00777F 78                    1164 	.db	00131$>>8
      007780 79                    1165 	.db	00147$>>8
      007781 79                    1166 	.db	00152$>>8
      007782 79                    1167 	.db	00152$>>8
                                   1168 ;	quantum/action.c:502: case ACT_RMODS: {
      007783                       1169 00102$:
                                   1170 ;	quantum/action.c:503: mods = (action.kind.id == ACT_LMODS) ? action.key.mods : action.key.mods << 4;
      007783 90 08 65         [24] 1171 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007786 E0               [24] 1172 	movx	a,@dptr
      007787 54 F0            [12] 1173 	anl	a,#0xf0
      007789 70 06            [24] 1174 	jnz	00194$
      00778B 12 7C 41         [24] 1175 	lcall	_ak820_outline_0115
      00778E FD               [12] 1176 	mov	r5,a
      00778F 80 07            [24] 1177 	sjmp	00195$
      007791                       1178 00194$:
      007791 12 7C 41         [24] 1179 	lcall	_ak820_outline_0115
      007794 C4               [12] 1180 	swap	a
      007795 54 F0            [12] 1181 	anl	a,#0xf0
      007797 FD               [12] 1182 	mov	r5,a
      007798                       1183 00195$:
                                   1184 ;	quantum/action.c:505: if (pressed) {
      007798 E5 27            [12] 1185 	mov	a,_process_action_sloc0_1_0
      00779A 60 35            [24] 1186 	jz	00119$
                                   1187 ;	quantum/action.c:506: if (mods) {
      00779C ED               [12] 1188 	mov	a,r5
      00779D 60 29            [24] 1189 	jz	00110$
                                   1190 ;	quantum/action.c:507: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      00779F 12 7C 69         [24] 1191 	lcall	_ak820_outline_0153
      0077A2 FC               [12] 1192 	mov	r4,a
      0077A3 BC E0 00         [24] 1193 	cjne	r4,#0xe0,00440$
      0077A6                       1194 00440$:
      0077A6 40 07            [24] 1195 	jc	00108$
      0077A8 12 7C 69         [24] 1196 	lcall	_ak820_outline_0153
      0077AB 24 18            [12] 1197 	add	a,#0xff - 0xe7
      0077AD 50 0A            [24] 1198 	jnc	00104$
                                   1199 ;	free result
      0077AF                       1200 00108$:
      0077AF 7B 64            [12] 1201 	mov	r3,#_process_action_PARM_2
      0077B1 7C 08            [12] 1202 	mov	r4,#(_process_action_PARM_2 >> 8)
      0077B3 12 36 47         [24] 1203 	lcall	_ak820_outline_0125
      0077B6 E0               [24] 1204 	movx	a,@dptr
      0077B7 70 07            [24] 1205 	jnz	00105$
      0077B9                       1206 00104$:
                                   1207 ;	quantum/action.c:511: add_owned_mods(mods);
      0077B9 8D 82            [24] 1208 	mov	dpl, r5
      0077BB 12 82 04         [24] 1209 	lcall	_add_owned_mods
      0077BE 80 05            [24] 1210 	sjmp	00106$
      0077C0                       1211 00105$:
                                   1212 ;	quantum/action.c:513: add_owned_weak_mods(mods);
      0077C0 8D 82            [24] 1213 	mov	dpl, r5
      0077C2 12 82 20         [24] 1214 	lcall	_add_owned_weak_mods
      0077C5                       1215 00106$:
                                   1216 ;	quantum/action.c:515: send_keyboard_report();
      0077C5 12 85 3F         [24] 1217 	lcall	_send_keyboard_report
      0077C8                       1218 00110$:
                                   1219 ;	quantum/action.c:517: register_code(action.key.code);
      0077C8 12 7C 31         [24] 1220 	lcall	_ak820_outline_0077
      0077CB 12 7A 01         [24] 1221 	lcall	_register_code
      0077CE 02 79 EA         [24] 1222 	ljmp	00181$
      0077D1                       1223 00119$:
                                   1224 ;	quantum/action.c:519: unregister_code(action.key.code);
      0077D1 12 7C 31         [24] 1225 	lcall	_ak820_outline_0077
      0077D4 C0 05            [24] 1226 	push	ar5
      0077D6 12 7A 86         [24] 1227 	lcall	_unregister_code
      0077D9 D0 05            [24] 1228 	pop	ar5
                                   1229 ;	quantum/action.c:520: if (mods) {
      0077DB ED               [12] 1230 	mov	a,r5
      0077DC 70 03            [24] 1231 	jnz	00444$
      0077DE 02 79 EA         [24] 1232 	ljmp	00181$
      0077E1                       1233 00444$:
                                   1234 ;	quantum/action.c:521: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      0077E1 12 7C 69         [24] 1235 	lcall	_ak820_outline_0153
      0077E4 FC               [12] 1236 	mov	r4,a
      0077E5 BC E0 00         [24] 1237 	cjne	r4,#0xe0,00445$
      0077E8                       1238 00445$:
      0077E8 40 07            [24] 1239 	jc	00115$
      0077EA 12 7C 69         [24] 1240 	lcall	_ak820_outline_0153
      0077ED 24 18            [12] 1241 	add	a,#0xff - 0xe7
      0077EF 50 0A            [24] 1242 	jnc	00111$
                                   1243 ;	free result
      0077F1                       1244 00115$:
      0077F1 7B 64            [12] 1245 	mov	r3,#_process_action_PARM_2
      0077F3 7C 08            [12] 1246 	mov	r4,#(_process_action_PARM_2 >> 8)
      0077F5 12 36 47         [24] 1247 	lcall	_ak820_outline_0125
      0077F8 E0               [24] 1248 	movx	a,@dptr
      0077F9 70 07            [24] 1249 	jnz	00112$
      0077FB                       1250 00111$:
                                   1251 ;	quantum/action.c:522: del_owned_mods(mods);
      0077FB 8D 82            [24] 1252 	mov	dpl, r5
      0077FD 12 82 13         [24] 1253 	lcall	_del_owned_mods
      007800 80 05            [24] 1254 	sjmp	00113$
      007802                       1255 00112$:
                                   1256 ;	quantum/action.c:524: del_owned_weak_mods(mods);
      007802 8D 82            [24] 1257 	mov	dpl, r5
      007804 12 82 2F         [24] 1258 	lcall	_del_owned_weak_mods
      007807                       1259 00113$:
                                   1260 ;	quantum/action.c:526: send_keyboard_report();
      007807 12 85 3F         [24] 1261 	lcall	_send_keyboard_report
                                   1262 ;	quantum/action.c:529: } break;
      00780A 02 79 EA         [24] 1263 	ljmp	00181$
                                   1264 ;	quantum/action.c:606: case ACT_USAGE:
      00780D                       1265 00123$:
                                   1266 ;	quantum/action.c:612: if (record->keycode >= KC_SYSTEM_POWER && record->keycode <= KC_LAUNCHPAD) {
      00780D 74 07            [12] 1267 	mov	a,#0x07
      00780F 12 3A 71         [24] 1268 	lcall	_ak820_outline_0021
      007812 12 4A 6F         [24] 1269 	lcall	_ak820_outline_0008
      007815 C3               [12] 1270 	clr	c
      007816 EC               [12] 1271 	mov	a,r4
      007817 94 A5            [12] 1272 	subb	a,#0xa5
      007819 ED               [12] 1273 	mov	a,r5
      00781A 94 00            [12] 1274 	subb	a,#0x00
      00781C 40 15            [24] 1275 	jc	00125$
      00781E 74 C2            [12] 1276 	mov	a,#0xc2
      007820 9C               [12] 1277 	subb	a,r4
      007821 E4               [12] 1278 	clr	a
      007822 9D               [12] 1279 	subb	a,r5
      007823 40 0E            [24] 1280 	jc	00125$
                                   1281 ;	free result
                                   1282 ;	quantum/action.c:613: owned_usage_key((uint8_t)record->keycode, pressed);
      007825 90 0A C8         [24] 1283 	mov	dptr,#_owned_usage_key_PARM_2
      007828 E5 27            [12] 1284 	mov	a,_process_action_sloc0_1_0
      00782A F0               [24] 1285 	movx	@dptr,a
      00782B 8E 82            [24] 1286 	mov	dpl, r6
      00782D 12 83 EC         [24] 1287 	lcall	_owned_usage_key
                                   1288 ;	quantum/action.c:614: break;
      007830 02 79 EA         [24] 1289 	ljmp	00181$
      007833                       1290 00125$:
                                   1291 ;	quantum/action.c:617: switch (action.usage.page) {
      007833 12 7C 38         [24] 1292 	lcall	_ak820_outline_0089
      007836 FF               [12] 1293 	mov	r7,a
      007837 60 08            [24] 1294 	jz	00127$
      007839 BF 01 02         [24] 1295 	cjne	r7,#0x01,00452$
      00783C 80 19            [24] 1296 	sjmp	00128$
      00783E                       1297 00452$:
      00783E 02 79 EA         [24] 1298 	ljmp	00181$
                                   1299 ;	quantum/action.c:618: case PAGE_SYSTEM:
      007841                       1300 00127$:
                                   1301 ;	quantum/action.c:619: host_system_send(pressed ? action.usage.code : 0);
      007841 E5 27            [12] 1302 	mov	a,_process_action_sloc0_1_0
      007843 60 05            [24] 1303 	jz	00196$
      007845 12 7C 48         [24] 1304 	lcall	_ak820_outline_0132
      007848 80 04            [24] 1305 	sjmp	00197$
      00784A                       1306 00196$:
      00784A 7E 00            [12] 1307 	mov	r6,#0x00
      00784C 7F 00            [12] 1308 	mov	r7,#0x00
      00784E                       1309 00197$:
      00784E 12 3A CC         [24] 1310 	lcall	_ak820_outline_0120
      007851 12 71 AF         [24] 1311 	lcall	_host_system_send
                                   1312 ;	quantum/action.c:620: break;
      007854 02 79 EA         [24] 1313 	ljmp	00181$
                                   1314 ;	quantum/action.c:621: case PAGE_CONSUMER:
      007857                       1315 00128$:
                                   1316 ;	quantum/action.c:622: host_consumer_send(pressed ? action.usage.code : 0);
      007857 E5 27            [12] 1317 	mov	a,_process_action_sloc0_1_0
      007859 60 05            [24] 1318 	jz	00198$
      00785B 12 7C 48         [24] 1319 	lcall	_ak820_outline_0132
      00785E 80 04            [24] 1320 	sjmp	00199$
      007860                       1321 00198$:
      007860 7E 00            [12] 1322 	mov	r6,#0x00
      007862 7F 00            [12] 1323 	mov	r7,#0x00
      007864                       1324 00199$:
      007864 12 3A CC         [24] 1325 	lcall	_ak820_outline_0120
      007867 12 71 DE         [24] 1326 	lcall	_host_consumer_send
                                   1327 ;	quantum/action.c:625: break;
      00786A 02 79 EA         [24] 1328 	ljmp	00181$
                                   1329 ;	quantum/action.c:628: case ACT_MOUSEKEY:
      00786D                       1330 00130$:
                                   1331 ;	quantum/action.c:629: register_mouse(action.key.code, pressed);
      00786D 12 7C 69         [24] 1332 	lcall	_ak820_outline_0153
      007870 FF               [12] 1333 	mov	r7,a
      007871 90 08 62         [24] 1334 	mov	dptr,#_register_mouse_PARM_2
      007874 E5 27            [12] 1335 	mov	a,_process_action_sloc0_1_0
      007876 F0               [24] 1336 	movx	@dptr,a
      007877 8F 82            [24] 1337 	mov	dpl, r7
      007879 12 77 14         [24] 1338 	lcall	_register_mouse
                                   1339 ;	quantum/action.c:630: break;
      00787C 02 79 EA         [24] 1340 	ljmp	00181$
                                   1341 ;	quantum/action.c:632: case ACT_LAYER: {
      00787F                       1342 00131$:
                                   1343 ;	quantum/action.c:633: uint8_t on = action.layer_bitop.on;
      00787F 90 08 65         [24] 1344 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007882 E0               [24] 1345 	movx	a,@dptr
      007883 54 03            [12] 1346 	anl	a,#0x03
      007885 90 08 69         [24] 1347 	mov	dptr,#_process_action_on_40000_686
      007888 F0               [24] 1348 	movx	@dptr,a
                                   1349 ;	quantum/action.c:636: if (on ? (pressed ? (on & ON_PRESS) : (on & ON_RELEASE)) : !pressed) {
      007889 E0               [24] 1350 	movx	a,@dptr
      00788A FF               [12] 1351 	mov	r7,a
      00788B 60 11            [24] 1352 	jz	00200$
      00788D E5 27            [12] 1353 	mov	a,_process_action_sloc0_1_0
      00788F 60 07            [24] 1354 	jz	00202$
      007891 8F 06            [24] 1355 	mov	ar6,r7
      007893 53 06 01         [24] 1356 	anl	ar6,#0x01
      007896 80 10            [24] 1357 	sjmp	00201$
      007898                       1358 00202$:
      007898 74 02            [12] 1359 	mov	a,#0x02
      00789A 5F               [12] 1360 	anl	a,r7
      00789B FE               [12] 1361 	mov	r6,a
      00789C 80 0A            [24] 1362 	sjmp	00201$
      00789E                       1363 00200$:
      00789E E5 27            [12] 1364 	mov	a,_process_action_sloc0_1_0
      0078A0 B4 01 00         [24] 1365 	cjne	a,#0x01,00457$
      0078A3                       1366 00457$:
      0078A3 92 20            [24] 1367 	mov  _process_action_sloc1_1_0,c
      0078A5 E4               [12] 1368 	clr	a
      0078A6 33               [12] 1369 	rlc	a
      0078A7 FE               [12] 1370 	mov	r6,a
      0078A8                       1371 00201$:
      0078A8 EE               [12] 1372 	mov	a,r6
      0078A9 70 03            [24] 1373 	jnz	00458$
      0078AB 02 79 EA         [24] 1374 	ljmp	00181$
      0078AE                       1375 00458$:
                                   1376 ;	quantum/action.c:637: uint8_t shift = action.layer_bitop.part * 4;
      0078AE 12 7C 69         [24] 1377 	lcall	_ak820_outline_0153
      0078B1 C4               [12] 1378 	swap	a
      0078B2 03               [12] 1379 	rr	a
      0078B3 54 07            [12] 1380 	anl	a,#0x07
      0078B5 25 E0            [12] 1381 	add	a,acc
      0078B7 25 E0            [12] 1382 	add	a,acc
      0078B9 FF               [12] 1383 	mov	r7,a
                                   1384 ;	quantum/action.c:638: layer_state_t bits = ((layer_state_t)action.layer_bitop.bits) << shift;
      0078BA 12 7C 69         [24] 1385 	lcall	_ak820_outline_0153
      0078BD 54 0F            [12] 1386 	anl	a,#0x0f
      0078BF FE               [12] 1387 	mov	r6,a
      0078C0 8F F0            [24] 1388 	mov	b,r7
      0078C2 05 F0            [12] 1389 	inc	b
      0078C4 EE               [12] 1390 	mov	a,r6
      0078C5 80 02            [24] 1391 	sjmp	00460$
      0078C7                       1392 00459$:
      0078C7 25 E0            [12] 1393 	add	a,acc
      0078C9                       1394 00460$:
      0078C9 D5 F0 FB         [24] 1395 	djnz	b,00459$
      0078CC FE               [12] 1396 	mov	r6,a
                                   1397 ;	quantum/action.c:639: layer_state_t mask = action.layer_bitop.xbit ? ~(((layer_state_t)0xf) << shift) : 0;
      0078CD 12 7C 69         [24] 1398 	lcall	_ak820_outline_0153
      0078D0 30 E4 11         [24] 1399 	jnb	acc.4,00204$
      0078D3 8F F0            [24] 1400 	mov	b,r7
      0078D5 05 F0            [12] 1401 	inc	b
      0078D7 74 0F            [12] 1402 	mov	a,#0x0f
      0078D9 80 02            [24] 1403 	sjmp	00463$
      0078DB                       1404 00462$:
      0078DB 25 E0            [12] 1405 	add	a,acc
      0078DD                       1406 00463$:
      0078DD D5 F0 FB         [24] 1407 	djnz	b,00462$
      0078E0 F4               [12] 1408 	cpl	a
      0078E1 FF               [12] 1409 	mov	r7,a
      0078E2 80 02            [24] 1410 	sjmp	00205$
      0078E4                       1411 00204$:
      0078E4 7F 00            [12] 1412 	mov	r7,#0x00
      0078E6                       1413 00205$:
                                   1414 ;	quantum/action.c:640: bits |= mask;
      0078E6 EE               [12] 1415 	mov	a,r6
      0078E7 42 07            [12] 1416 	orl	ar7,a
                                   1417 ;	quantum/action.c:641: if (!on) {
      0078E9 90 08 69         [24] 1418 	mov	dptr,#_process_action_on_40000_686
      0078EC E0               [24] 1419 	movx	a,@dptr
      0078ED 70 31            [24] 1420 	jnz	00143$
                                   1421 ;	quantum/action.c:642: switch (action.layer_bitop.op) {
      0078EF 12 7C 38         [24] 1422 	lcall	_ak820_outline_0089
      0078F2 FE               [12] 1423 	mov	r6,a
      0078F3 2E               [12] 1424 	add	a,r6
                                   1425 ;	quantum/action.c:643: case OP_BIT_AND: default_layer_and(bits); break;
      0078F4 90 78 F8         [24] 1426 	mov	dptr,#00465$
      0078F7 73               [24] 1427 	jmp	@a+dptr
      0078F8                       1428 00465$:
      0078F8 80 06            [24] 1429 	sjmp	00132$
      0078FA 80 0C            [24] 1430 	sjmp	00133$
      0078FC 80 12            [24] 1431 	sjmp	00134$
      0078FE 80 18            [24] 1432 	sjmp	00135$
      007900                       1433 00132$:
      007900 8F 82            [24] 1434 	mov	dpl, r7
      007902 12 7C BD         [24] 1435 	lcall	_default_layer_and
      007905 02 79 EA         [24] 1436 	ljmp	00181$
                                   1437 ;	quantum/action.c:644: case OP_BIT_OR: default_layer_or(bits); break;
      007908                       1438 00133$:
      007908 8F 82            [24] 1439 	mov	dpl, r7
      00790A 12 7C AD         [24] 1440 	lcall	_default_layer_or
      00790D 02 79 EA         [24] 1441 	ljmp	00181$
                                   1442 ;	quantum/action.c:645: case OP_BIT_XOR: default_layer_xor(bits); break;
      007910                       1443 00134$:
      007910 8F 82            [24] 1444 	mov	dpl, r7
      007912 12 7C D2         [24] 1445 	lcall	_default_layer_xor
      007915 02 79 EA         [24] 1446 	ljmp	00181$
                                   1447 ;	quantum/action.c:646: case OP_BIT_SET: default_layer_set(bits); break;
      007918                       1448 00135$:
      007918 8F 82            [24] 1449 	mov	dpl, r7
      00791A 12 7C A3         [24] 1450 	lcall	_default_layer_set
                                   1451 ;	quantum/action.c:647: }
      00791D 02 79 EA         [24] 1452 	ljmp	00181$
      007920                       1453 00143$:
                                   1454 ;	quantum/action.c:649: switch (action.layer_bitop.op) {
      007920 12 7C 38         [24] 1455 	lcall	_ak820_outline_0089
      007923 FE               [12] 1456 	mov	r6,a
      007924 2E               [12] 1457 	add	a,r6
                                   1458 ;	quantum/action.c:650: case OP_BIT_AND: layer_and(bits); break;
      007925 90 79 29         [24] 1459 	mov	dptr,#00466$
      007928 73               [24] 1460 	jmp	@a+dptr
      007929                       1461 00466$:
      007929 80 06            [24] 1462 	sjmp	00137$
      00792B 80 0C            [24] 1463 	sjmp	00138$
      00792D 80 12            [24] 1464 	sjmp	00139$
      00792F 80 18            [24] 1465 	sjmp	00140$
      007931                       1466 00137$:
      007931 8F 82            [24] 1467 	mov	dpl, r7
      007933 12 7E 4A         [24] 1468 	lcall	_layer_and
      007936 02 79 EA         [24] 1469 	ljmp	00181$
                                   1470 ;	quantum/action.c:651: case OP_BIT_OR: layer_or(bits); break;
      007939                       1471 00138$:
      007939 8F 82            [24] 1472 	mov	dpl, r7
      00793B 12 7E 3A         [24] 1473 	lcall	_layer_or
      00793E 02 79 EA         [24] 1474 	ljmp	00181$
                                   1475 ;	quantum/action.c:652: case OP_BIT_XOR: layer_xor(bits); break;
      007941                       1476 00139$:
      007941 8F 82            [24] 1477 	mov	dpl, r7
      007943 12 7E 5F         [24] 1478 	lcall	_layer_xor
      007946 02 79 EA         [24] 1479 	ljmp	00181$
                                   1480 ;	quantum/action.c:653: case OP_BIT_SET: layer_state_set(bits); break;
      007949                       1481 00140$:
      007949 8F 82            [24] 1482 	mov	dpl, r7
      00794B 12 7D DC         [24] 1483 	lcall	_layer_state_set
                                   1484 ;	quantum/action.c:657: break;
      00794E 02 79 EA         [24] 1485 	ljmp	00181$
                                   1486 ;	quantum/action.c:659: case ACT_LAYER_MODS:
      007951                       1487 00147$:
                                   1488 ;	quantum/action.c:660: if (pressed) {
      007951 E5 27            [12] 1489 	mov	a,_process_action_sloc0_1_0
      007953 60 11            [24] 1490 	jz	00149$
                                   1491 ;	quantum/action.c:661: layer_hold_on(action.layer_mods.layer);
      007955 12 7C 41         [24] 1492 	lcall	_ak820_outline_0115
      007958 F5 82            [12] 1493 	mov	dpl,a
      00795A 12 7D 40         [24] 1494 	lcall	_layer_hold_on
                                   1495 ;	quantum/action.c:662: register_mods(action.layer_mods.mods);
      00795D 12 7C 31         [24] 1496 	lcall	_ak820_outline_0077
      007960 12 7B 4E         [24] 1497 	lcall	_register_mods
      007963 02 79 EA         [24] 1498 	ljmp	00181$
      007966                       1499 00149$:
                                   1500 ;	quantum/action.c:664: unregister_mods(action.layer_mods.mods);
      007966 12 7C 31         [24] 1501 	lcall	_ak820_outline_0077
      007969 12 7B 62         [24] 1502 	lcall	_unregister_mods
                                   1503 ;	quantum/action.c:665: layer_hold_off(action.layer_mods.layer);
      00796C 12 7C 41         [24] 1504 	lcall	_ak820_outline_0115
      00796F F5 82            [12] 1505 	mov	dpl,a
      007971 12 7D 77         [24] 1506 	lcall	_layer_hold_off
                                   1507 ;	quantum/action.c:667: break;
      007974 02 79 EA         [24] 1508 	ljmp	00181$
                                   1509 ;	quantum/action.c:669: case ACT_LAYER_TAP_EXT:
      007977                       1510 00152$:
                                   1511 ;	quantum/action.c:670: switch (action.layer_tap.code) {
      007977 12 7C 69         [24] 1512 	lcall	_ak820_outline_0153
      00797A FF               [12] 1513 	mov	r7,a
      00797B BF F1 02         [24] 1514 	cjne	r7,#0xf1,00468$
      00797E 80 0A            [24] 1515 	sjmp	00154$
      007980                       1516 00468$:
      007980 BF F2 02         [24] 1517 	cjne	r7,#0xf2,00469$
      007983 80 19            [24] 1518 	sjmp	00155$
      007985                       1519 00469$:
                                   1520 ;	quantum/action.c:686: momentary_layer_action:
      007985 BF F3 3B         [24] 1521 	cjne	r7,#0xf3,00160$
      007988 80 28            [24] 1522 	sjmp	00156$
      00798A                       1523 00154$:
                                   1524 ;	quantum/action.c:687: pressed ? layer_hold_on(action.layer_tap.val) : layer_hold_off(action.layer_tap.val);
      00798A E5 27            [12] 1525 	mov	a,_process_action_sloc0_1_0
      00798C 60 08            [24] 1526 	jz	00206$
      00798E 12 7C 17         [24] 1527 	lcall	_ak820_outline_0042
      007991 12 7D 40         [24] 1528 	lcall	_layer_hold_on
      007994 80 54            [24] 1529 	sjmp	00181$
      007996                       1530 00206$:
      007996 12 7C 17         [24] 1531 	lcall	_ak820_outline_0042
      007999 12 7D 77         [24] 1532 	lcall	_layer_hold_off
                                   1533 ;	quantum/action.c:688: break;
                                   1534 ;	quantum/action.c:689: case OP_OFF_ON:
      00799C 80 4C            [24] 1535 	sjmp	00181$
      00799E                       1536 00155$:
                                   1537 ;	quantum/action.c:690: pressed ? layer_off(action.layer_tap.val) : layer_on(action.layer_tap.val);
      00799E E5 27            [12] 1538 	mov	a,_process_action_sloc0_1_0
      0079A0 60 08            [24] 1539 	jz	00208$
      0079A2 12 7C 17         [24] 1540 	lcall	_ak820_outline_0042
      0079A5 12 7E 1D         [24] 1541 	lcall	_layer_off
      0079A8 80 40            [24] 1542 	sjmp	00181$
      0079AA                       1543 00208$:
      0079AA 12 7C 17         [24] 1544 	lcall	_ak820_outline_0042
      0079AD 12 7E 03         [24] 1545 	lcall	_layer_on
                                   1546 ;	quantum/action.c:691: break;
                                   1547 ;	quantum/action.c:692: case OP_SET_CLEAR:
      0079B0 80 38            [24] 1548 	sjmp	00181$
      0079B2                       1549 00156$:
                                   1550 ;	quantum/action.c:693: pressed ? layer_move(action.layer_tap.val) : layer_clear();
      0079B2 E5 27            [12] 1551 	mov	a,_process_action_sloc0_1_0
      0079B4 60 08            [24] 1552 	jz	00210$
      0079B6 12 7C 17         [24] 1553 	lcall	_ak820_outline_0042
      0079B9 12 7D EE         [24] 1554 	lcall	_layer_move
      0079BC 80 2C            [24] 1555 	sjmp	00181$
      0079BE                       1556 00210$:
      0079BE 12 7D E9         [24] 1557 	lcall	_layer_clear
                                   1558 ;	quantum/action.c:694: break;
                                   1559 ;	quantum/action.c:740: default:
      0079C1 80 27            [24] 1560 	sjmp	00181$
      0079C3                       1561 00160$:
                                   1562 ;	quantum/action.c:747: if (pressed) {
      0079C3 E5 27            [12] 1563 	mov	a,_process_action_sloc0_1_0
      0079C5 60 08            [24] 1564 	jz	00163$
                                   1565 ;	quantum/action.c:749: register_code(action.layer_tap.code);
      0079C7 12 7C 31         [24] 1566 	lcall	_ak820_outline_0077
      0079CA 12 7A 01         [24] 1567 	lcall	_register_code
                                   1568 ;	quantum/action.c:751: ac_dprintf("KEYMAP_TAP_KEY: Tap: unregister_code\n");
      0079CD 80 1B            [24] 1569 	sjmp	00181$
      0079CF                       1570 00163$:
                                   1571 ;	quantum/action.c:752: if (action.layer_tap.code == KC_CAPS) {
      0079CF 12 7C 69         [24] 1572 	lcall	_ak820_outline_0153
      0079D2 FF               [12] 1573 	mov	r7,a
      0079D3 BF 39 0E         [24] 1574 	cjne	r7,#0x39,00175$
                                   1575 ;	quantum/action.c:753: wait_ms(TAP_HOLD_CAPS_DELAY);
      0079D6 7F 50            [12] 1576 	mov	r7,#0x50
      0079D8                       1577 00187$:
      0079D8 EF               [12] 1578 	mov	a,r7
      0079D9 60 09            [24] 1579 	jz	00175$
      0079DB 90 00 01         [24] 1580 	mov	dptr,#0x0001
      0079DE 12 5D 83         [24] 1581 	lcall	_mDelaymS
      0079E1 1F               [12] 1582 	dec	r7
                                   1583 ;	quantum/action.c:755: wait_ms(TAP_CODE_DELAY);
      0079E2 80 F4            [24] 1584 	sjmp	00187$
      0079E4                       1585 00175$:
                                   1586 ;	quantum/action.c:757: unregister_code(action.layer_tap.code);
      0079E4 12 7C 31         [24] 1587 	lcall	_ak820_outline_0077
      0079E7 12 7A 86         [24] 1588 	lcall	_unregister_code
                                   1589 ;	quantum/action.c:840: }
      0079EA                       1590 00181$:
                                   1591 ;	quantum/action.c:861: switch (action.kind.id) {
      0079EA 90 08 65         [24] 1592 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0079ED E0               [24] 1593 	movx	a,@dptr
      0079EE C4               [12] 1594 	swap	a
      0079EF 54 0F            [12] 1595 	anl	a,#0x0f
      0079F1 FF               [12] 1596 	mov	r7,a
      0079F2 BF 08 02         [24] 1597 	cjne	r7,#0x08,00478$
      0079F5 80 03            [24] 1598 	sjmp	00183$
      0079F7                       1599 00478$:
      0079F7 BF 09 06         [24] 1600 	cjne	r7,#0x09,00192$
                                   1601 ;	quantum/action.c:863: case ACT_LAYER_MODS:
      0079FA                       1602 00183$:
                                   1603 ;	quantum/action.c:868: led_set(host_keyboard_leds());
      0079FA 12 71 14         [24] 1604 	lcall	_host_keyboard_leds
                                   1605 ;	quantum/action.c:872: }
                                   1606 ;	quantum/action.c:925: }
      0079FD 02 9C 58         [24] 1607 	ljmp	_led_set
      007A00                       1608 00192$:
      007A00 22               [24] 1609 	ret
                                   1610 ;------------------------------------------------------------
                                   1611 ;Allocation info for local variables in function 'register_code'
                                   1612 ;------------------------------------------------------------
                                   1613 ;code          Allocated with name '_register_code_code_10000_720'
                                   1614 ;------------------------------------------------------------
                                   1615 ;	quantum/action.c:931: __attribute__((weak)) void register_code(uint8_t code) {
                                   1616 ;	-----------------------------------------
                                   1617 ;	 function register_code
                                   1618 ;	-----------------------------------------
      007A01                       1619 _register_code:
      007A01 E5 82            [12] 1620 	mov	a,dpl
      007A03 90 08 6A         [24] 1621 	mov	dptr,#_register_code_code_10000_720
      007A06 F0               [24] 1622 	movx	@dptr,a
                                   1623 ;	quantum/action.c:932: if (code == KC_NO) {
      007A07 E0               [24] 1624 	movx	a,@dptr
      007A08 FF               [12] 1625 	mov	r7,a
      007A09 70 01            [24] 1626 	jnz	00123$
                                   1627 ;	quantum/action.c:933: return;
      007A0B 22               [24] 1628 	ret
      007A0C                       1629 00123$:
                                   1630 ;	quantum/action.c:968: } else if (IS_BASIC_KEYCODE(code)) {
      007A0C BF 04 00         [24] 1631 	cjne	r7,#0x04,00198$
      007A0F                       1632 00198$:
      007A0F 40 12            [24] 1633 	jc	00119$
      007A11 EF               [12] 1634 	mov	a,r7
      007A12 24 5B            [12] 1635 	add	a,#0xff - 0xa4
      007A14 40 0D            [24] 1636 	jc	00119$
                                   1637 ;	free result
                                   1638 ;	quantum/action.c:973: if (!add_owned_key(code)) return;
      007A16 8F 82            [24] 1639 	mov	dpl, r7
      007A18 12 82 A3         [24] 1640 	lcall	_add_owned_key
      007A1B E5 82            [12] 1641 	mov	a, dpl
      007A1D 70 01            [24] 1642 	jnz	00104$
      007A1F 22               [24] 1643 	ret
      007A20                       1644 00104$:
                                   1645 ;	quantum/action.c:987: send_keyboard_report();
      007A20 02 85 3F         [24] 1646 	ljmp	_send_keyboard_report
      007A23                       1647 00119$:
                                   1648 ;	quantum/action.c:988: } else if (IS_MODIFIER_KEYCODE(code)) {
      007A23 12 7C 53         [24] 1649 	lcall	_ak820_outline_0143
      007A26 BF E0 00         [24] 1650 	cjne	r7,#0xe0,00202$
      007A29                       1651 00202$:
      007A29 40 1A            [24] 1652 	jc	00115$
      007A2B EF               [12] 1653 	mov	a,r7
      007A2C 24 18            [12] 1654 	add	a,#0xff - 0xe7
      007A2E 40 15            [24] 1655 	jc	00115$
                                   1656 ;	free result
                                   1657 ;	quantum/action.c:989: add_owned_mods(MOD_BIT(code));
      007A30 74 07            [12] 1658 	mov	a,#0x07
      007A32 5F               [12] 1659 	anl	a,r7
      007A33 12 7C 20         [24] 1660 	lcall	_ak820_outline_0063
      007A36 80 02            [24] 1661 	sjmp	00206$
      007A38                       1662 00205$:
      007A38 25 E0            [12] 1663 	add	a,acc
      007A3A                       1664 00206$:
      007A3A D5 F0 FB         [24] 1665 	djnz	b,00205$
      007A3D F5 82            [12] 1666 	mov	dpl,a
      007A3F 12 82 04         [24] 1667 	lcall	_add_owned_mods
                                   1668 ;	quantum/action.c:990: send_keyboard_report();
      007A42 02 85 3F         [24] 1669 	ljmp	_send_keyboard_report
      007A45                       1670 00115$:
                                   1671 ;	quantum/action.c:993: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      007A45 12 7C 53         [24] 1672 	lcall	_ak820_outline_0143
      007A48 BF A5 00         [24] 1673 	cjne	r7,#0xa5,00207$
      007A4B                       1674 00207$:
      007A4B 40 05            [24] 1675 	jc	00113$
      007A4D EF               [12] 1676 	mov	a,r7
      007A4E 24 58            [12] 1677 	add	a,#0xff - 0xa7
      007A50 50 0D            [24] 1678 	jnc	00108$
                                   1679 ;	free result
      007A52                       1680 00113$:
      007A52 12 7C 53         [24] 1681 	lcall	_ak820_outline_0143
      007A55 BF A8 00         [24] 1682 	cjne	r7,#0xa8,00210$
      007A58                       1683 00210$:
      007A58 40 13            [24] 1684 	jc	00109$
      007A5A EF               [12] 1685 	mov	a,r7
      007A5B 24 3D            [12] 1686 	add	a,#0xff - 0xc2
      007A5D 40 0E            [24] 1687 	jc	00109$
                                   1688 ;	free result
      007A5F                       1689 00108$:
                                   1690 ;	quantum/action.c:995: owned_usage_key(code, true);
      007A5F 12 7C 53         [24] 1691 	lcall	_ak820_outline_0143
      007A62 90 0A C8         [24] 1692 	mov	dptr,#_owned_usage_key_PARM_2
      007A65 74 01            [12] 1693 	mov	a,#0x01
      007A67 F0               [24] 1694 	movx	@dptr,a
      007A68 8F 82            [24] 1695 	mov	dpl, r7
      007A6A 02 83 EC         [24] 1696 	ljmp	_owned_usage_key
      007A6D                       1697 00109$:
                                   1698 ;	quantum/action.c:1002: } else if (IS_MOUSE_KEYCODE(code)) {
      007A6D 12 7C 53         [24] 1699 	lcall	_ak820_outline_0143
      007A70 BF CD 00         [24] 1700 	cjne	r7,#0xcd,00213$
      007A73                       1701 00213$:
      007A73 40 10            [24] 1702 	jc	00125$
      007A75 EF               [12] 1703 	mov	a,r7
      007A76 24 20            [12] 1704 	add	a,#0xff - 0xdf
      007A78 40 0B            [24] 1705 	jc	00125$
                                   1706 ;	free result
                                   1707 ;	quantum/action.c:1003: register_mouse(code, true);
      007A7A 90 08 62         [24] 1708 	mov	dptr,#_register_mouse_PARM_2
      007A7D 74 01            [12] 1709 	mov	a,#0x01
      007A7F F0               [24] 1710 	movx	@dptr,a
      007A80 8F 82            [24] 1711 	mov	dpl, r7
                                   1712 ;	quantum/action.c:1005: }
      007A82 02 77 14         [24] 1713 	ljmp	_register_mouse
      007A85                       1714 00125$:
      007A85 22               [24] 1715 	ret
                                   1716 ;------------------------------------------------------------
                                   1717 ;Allocation info for local variables in function 'unregister_code'
                                   1718 ;------------------------------------------------------------
                                   1719 ;code          Allocated with name '_unregister_code_code_10000_734'
                                   1720 ;------------------------------------------------------------
                                   1721 ;	quantum/action.c:1011: __attribute__((weak)) void unregister_code(uint8_t code) {
                                   1722 ;	-----------------------------------------
                                   1723 ;	 function unregister_code
                                   1724 ;	-----------------------------------------
      007A86                       1725 _unregister_code:
      007A86 E5 82            [12] 1726 	mov	a,dpl
      007A88 90 08 6B         [24] 1727 	mov	dptr,#_unregister_code_code_10000_734
      007A8B F0               [24] 1728 	movx	@dptr,a
                                   1729 ;	quantum/action.c:1012: if (code == KC_NO) {
      007A8C E0               [24] 1730 	movx	a,@dptr
      007A8D FF               [12] 1731 	mov	r7,a
      007A8E 70 01            [24] 1732 	jnz	00121$
                                   1733 ;	quantum/action.c:1013: return;
      007A90 22               [24] 1734 	ret
      007A91                       1735 00121$:
                                   1736 ;	quantum/action.c:1045: } else if (IS_BASIC_KEYCODE(code)) {
      007A91 BF 04 00         [24] 1737 	cjne	r7,#0x04,00196$
      007A94                       1738 00196$:
      007A94 40 12            [24] 1739 	jc	00117$
      007A96 EF               [12] 1740 	mov	a,r7
      007A97 24 5B            [12] 1741 	add	a,#0xff - 0xa4
      007A99 40 0D            [24] 1742 	jc	00117$
                                   1743 ;	free result
                                   1744 ;	quantum/action.c:1047: if (!del_owned_key(code)) return;
      007A9B 8F 82            [24] 1745 	mov	dpl, r7
      007A9D 12 83 1F         [24] 1746 	lcall	_del_owned_key
      007AA0 E5 82            [12] 1747 	mov	a, dpl
      007AA2 70 01            [24] 1748 	jnz	00102$
      007AA4 22               [24] 1749 	ret
      007AA5                       1750 00102$:
                                   1751 ;	quantum/action.c:1054: send_keyboard_report();
      007AA5 02 85 3F         [24] 1752 	ljmp	_send_keyboard_report
      007AA8                       1753 00117$:
                                   1754 ;	quantum/action.c:1055: } else if (IS_MODIFIER_KEYCODE(code)) {
      007AA8 12 7C 59         [24] 1755 	lcall	_ak820_outline_0144
      007AAB BF E0 00         [24] 1756 	cjne	r7,#0xe0,00200$
      007AAE                       1757 00200$:
      007AAE 40 1A            [24] 1758 	jc	00113$
      007AB0 EF               [12] 1759 	mov	a,r7
      007AB1 24 18            [12] 1760 	add	a,#0xff - 0xe7
      007AB3 40 15            [24] 1761 	jc	00113$
                                   1762 ;	free result
                                   1763 ;	quantum/action.c:1056: del_owned_mods(MOD_BIT(code));
      007AB5 74 07            [12] 1764 	mov	a,#0x07
      007AB7 5F               [12] 1765 	anl	a,r7
      007AB8 12 7C 20         [24] 1766 	lcall	_ak820_outline_0063
      007ABB 80 02            [24] 1767 	sjmp	00204$
      007ABD                       1768 00203$:
      007ABD 25 E0            [12] 1769 	add	a,acc
      007ABF                       1770 00204$:
      007ABF D5 F0 FB         [24] 1771 	djnz	b,00203$
      007AC2 F5 82            [12] 1772 	mov	dpl,a
      007AC4 12 82 13         [24] 1773 	lcall	_del_owned_mods
                                   1774 ;	quantum/action.c:1057: send_keyboard_report();
      007AC7 02 85 3F         [24] 1775 	ljmp	_send_keyboard_report
      007ACA                       1776 00113$:
                                   1777 ;	quantum/action.c:1060: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      007ACA 12 7C 59         [24] 1778 	lcall	_ak820_outline_0144
      007ACD BF A5 00         [24] 1779 	cjne	r7,#0xa5,00205$
      007AD0                       1780 00205$:
      007AD0 40 05            [24] 1781 	jc	00111$
      007AD2 EF               [12] 1782 	mov	a,r7
      007AD3 24 58            [12] 1783 	add	a,#0xff - 0xa7
      007AD5 50 0D            [24] 1784 	jnc	00106$
                                   1785 ;	free result
      007AD7                       1786 00111$:
      007AD7 12 7C 59         [24] 1787 	lcall	_ak820_outline_0144
      007ADA BF A8 00         [24] 1788 	cjne	r7,#0xa8,00208$
      007ADD                       1789 00208$:
      007ADD 40 11            [24] 1790 	jc	00107$
      007ADF EF               [12] 1791 	mov	a,r7
      007AE0 24 3D            [12] 1792 	add	a,#0xff - 0xc2
      007AE2 40 0C            [24] 1793 	jc	00107$
                                   1794 ;	free result
      007AE4                       1795 00106$:
                                   1796 ;	quantum/action.c:1062: owned_usage_key(code, false);
      007AE4 12 7C 59         [24] 1797 	lcall	_ak820_outline_0144
      007AE7 90 0A C8         [24] 1798 	mov	dptr,#_owned_usage_key_PARM_2
      007AEA 12 7C 73         [24] 1799 	lcall	_ak820_outline_0191
      007AED 02 83 EC         [24] 1800 	ljmp	_owned_usage_key
      007AF0                       1801 00107$:
                                   1802 ;	quantum/action.c:1069: } else if (IS_MOUSE_KEYCODE(code)) {
      007AF0 12 7C 59         [24] 1803 	lcall	_ak820_outline_0144
      007AF3 BF CD 00         [24] 1804 	cjne	r7,#0xcd,00211$
      007AF6                       1805 00211$:
      007AF6 40 0E            [24] 1806 	jc	00123$
      007AF8 EF               [12] 1807 	mov	a,r7
      007AF9 24 20            [12] 1808 	add	a,#0xff - 0xdf
      007AFB 40 09            [24] 1809 	jc	00123$
                                   1810 ;	free result
                                   1811 ;	quantum/action.c:1070: register_mouse(code, false);
      007AFD 90 08 62         [24] 1812 	mov	dptr,#_register_mouse_PARM_2
      007B00 12 7C 73         [24] 1813 	lcall	_ak820_outline_0191
                                   1814 ;	quantum/action.c:1072: }
      007B03 02 77 14         [24] 1815 	ljmp	_register_mouse
      007B06                       1816 00123$:
      007B06 22               [24] 1817 	ret
                                   1818 ;------------------------------------------------------------
                                   1819 ;Allocation info for local variables in function 'tap_code_delay'
                                   1820 ;------------------------------------------------------------
                                   1821 ;delay         Allocated with name '_tap_code_delay_PARM_2'
                                   1822 ;code          Allocated with name '_tap_code_delay_code_10000_747'
                                   1823 ;i             Allocated with name '_tap_code_delay_i_20000_749'
                                   1824 ;i             Allocated with name '_tap_code_delay_i_50000_752'
                                   1825 ;------------------------------------------------------------
                                   1826 ;	quantum/action.c:1079: __attribute__((weak)) void tap_code_delay(uint8_t code, uint16_t delay) {
                                   1827 ;	-----------------------------------------
                                   1828 ;	 function tap_code_delay
                                   1829 ;	-----------------------------------------
      007B07                       1830 _tap_code_delay:
      007B07 E5 82            [12] 1831 	mov	a,dpl
      007B09 90 08 6E         [24] 1832 	mov	dptr,#_tap_code_delay_code_10000_747
      007B0C F0               [24] 1833 	movx	@dptr,a
                                   1834 ;	quantum/action.c:1080: register_code(code);
      007B0D E0               [24] 1835 	movx	a,@dptr
      007B0E FF               [12] 1836 	mov	r7,a
      007B0F F5 82            [12] 1837 	mov	dpl,a
      007B11 C0 07            [24] 1838 	push	ar7
      007B13 51 01            [12] 1839 	acall	_register_code
      007B15 D0 07            [24] 1840 	pop	ar7
                                   1841 ;	quantum/action.c:1081: for (uint16_t i = delay; i > 0; i--) {
      007B17 90 08 6C         [24] 1842 	mov	dptr,#_tap_code_delay_PARM_2
      007B1A 12 3A AA         [24] 1843 	lcall	_ak820_outline_0085
      007B1D                       1844 00110$:
      007B1D ED               [12] 1845 	mov	a,r5
      007B1E 4E               [12] 1846 	orl	a,r6
      007B1F 60 0D            [24] 1847 	jz	00105$
                                   1848 ;	quantum/action.c:1082: wait_ms(1);
      007B21 90 00 01         [24] 1849 	mov	dptr,#0x0001
      007B24 12 5D 83         [24] 1850 	lcall	_mDelaymS
                                   1851 ;	quantum/action.c:1081: for (uint16_t i = delay; i > 0; i--) {
      007B27 1D               [12] 1852 	dec	r5
      007B28 BD FF 01         [24] 1853 	cjne	r5,#0xff,00141$
      007B2B 1E               [12] 1854 	dec	r6
      007B2C                       1855 00141$:
      007B2C 80 EF            [24] 1856 	sjmp	00110$
      007B2E                       1857 00105$:
                                   1858 ;	quantum/action.c:1084: unregister_code(code);
      007B2E 8F 82            [24] 1859 	mov	dpl, r7
                                   1860 ;	quantum/action.c:1085: }
      007B30 41 86            [12] 1861 	ajmp	_unregister_code
                                   1862 ;------------------------------------------------------------
                                   1863 ;Allocation info for local variables in function 'tap_code'
                                   1864 ;------------------------------------------------------------
                                   1865 ;code          Allocated with name '_tap_code_code_10000_754'
                                   1866 ;------------------------------------------------------------
                                   1867 ;	quantum/action.c:1091: __attribute__((weak)) void tap_code(uint8_t code) {
                                   1868 ;	-----------------------------------------
                                   1869 ;	 function tap_code
                                   1870 ;	-----------------------------------------
      007B32                       1871 _tap_code:
      007B32 E5 82            [12] 1872 	mov	a,dpl
      007B34 90 08 6F         [24] 1873 	mov	dptr,#_tap_code_code_10000_754
      007B37 F0               [24] 1874 	movx	@dptr,a
                                   1875 ;	quantum/action.c:1092: tap_code_delay(code, code == KC_CAPS ? QS_tap_hold_caps_delay : QS_tap_code_delay);
      007B38 E0               [24] 1876 	movx	a,@dptr
      007B39 FF               [12] 1877 	mov	r7,a
      007B3A BF 39 04         [24] 1878 	cjne	r7,#0x39,00103$
      007B3D 7E 50            [12] 1879 	mov	r6,#0x50
      007B3F 80 02            [24] 1880 	sjmp	00104$
      007B41                       1881 00103$:
      007B41 7E 00            [12] 1882 	mov	r6,#0x00
      007B43                       1883 00104$:
      007B43 90 08 6C         [24] 1884 	mov	dptr,#_tap_code_delay_PARM_2
      007B46 EE               [12] 1885 	mov	a,r6
      007B47 12 3A E1         [24] 1886 	lcall	_ak820_outline_0137
      007B4A 8F 82            [24] 1887 	mov	dpl, r7
                                   1888 ;	quantum/action.c:1093: }
      007B4C 61 07            [12] 1889 	ajmp	_tap_code_delay
                                   1890 ;------------------------------------------------------------
                                   1891 ;Allocation info for local variables in function 'register_mods'
                                   1892 ;------------------------------------------------------------
                                   1893 ;mods          Allocated with name '_register_mods_mods_10000_756'
                                   1894 ;------------------------------------------------------------
                                   1895 ;	quantum/action.c:1099: __attribute__((weak)) void register_mods(uint8_t mods) {
                                   1896 ;	-----------------------------------------
                                   1897 ;	 function register_mods
                                   1898 ;	-----------------------------------------
      007B4E                       1899 _register_mods:
      007B4E E5 82            [12] 1900 	mov	a,dpl
      007B50 90 08 70         [24] 1901 	mov	dptr,#_register_mods_mods_10000_756
      007B53 F0               [24] 1902 	movx	@dptr,a
                                   1903 ;	quantum/action.c:1100: if (mods) {
      007B54 E0               [24] 1904 	movx	a,@dptr
      007B55 FF               [12] 1905 	mov	r7,a
      007B56 E0               [24] 1906 	movx	a,@dptr
      007B57 60 08            [24] 1907 	jz	00103$
                                   1908 ;	quantum/action.c:1101: add_owned_mods(mods);
      007B59 8F 82            [24] 1909 	mov	dpl, r7
      007B5B 12 82 04         [24] 1910 	lcall	_add_owned_mods
                                   1911 ;	quantum/action.c:1102: send_keyboard_report();
                                   1912 ;	quantum/action.c:1104: }
      007B5E 02 85 3F         [24] 1913 	ljmp	_send_keyboard_report
      007B61                       1914 00103$:
      007B61 22               [24] 1915 	ret
                                   1916 ;------------------------------------------------------------
                                   1917 ;Allocation info for local variables in function 'unregister_mods'
                                   1918 ;------------------------------------------------------------
                                   1919 ;mods          Allocated with name '_unregister_mods_mods_10000_760'
                                   1920 ;------------------------------------------------------------
                                   1921 ;	quantum/action.c:1110: __attribute__((weak)) void unregister_mods(uint8_t mods) {
                                   1922 ;	-----------------------------------------
                                   1923 ;	 function unregister_mods
                                   1924 ;	-----------------------------------------
      007B62                       1925 _unregister_mods:
      007B62 E5 82            [12] 1926 	mov	a,dpl
      007B64 90 08 71         [24] 1927 	mov	dptr,#_unregister_mods_mods_10000_760
      007B67 F0               [24] 1928 	movx	@dptr,a
                                   1929 ;	quantum/action.c:1111: if (mods) {
      007B68 E0               [24] 1930 	movx	a,@dptr
      007B69 FF               [12] 1931 	mov	r7,a
      007B6A E0               [24] 1932 	movx	a,@dptr
      007B6B 60 08            [24] 1933 	jz	00103$
                                   1934 ;	quantum/action.c:1112: del_owned_mods(mods);
      007B6D 8F 82            [24] 1935 	mov	dpl, r7
      007B6F 12 82 13         [24] 1936 	lcall	_del_owned_mods
                                   1937 ;	quantum/action.c:1113: send_keyboard_report();
                                   1938 ;	quantum/action.c:1115: }
      007B72 02 85 3F         [24] 1939 	ljmp	_send_keyboard_report
      007B75                       1940 00103$:
      007B75 22               [24] 1941 	ret
                                   1942 ;------------------------------------------------------------
                                   1943 ;Allocation info for local variables in function 'register_weak_mods'
                                   1944 ;------------------------------------------------------------
                                   1945 ;mods          Allocated with name '_register_weak_mods_mods_10000_764'
                                   1946 ;------------------------------------------------------------
                                   1947 ;	quantum/action.c:1121: __attribute__((weak)) void register_weak_mods(uint8_t mods) {
                                   1948 ;	-----------------------------------------
                                   1949 ;	 function register_weak_mods
                                   1950 ;	-----------------------------------------
      007B76                       1951 _register_weak_mods:
      007B76 E5 82            [12] 1952 	mov	a,dpl
      007B78 90 08 72         [24] 1953 	mov	dptr,#_register_weak_mods_mods_10000_764
      007B7B F0               [24] 1954 	movx	@dptr,a
                                   1955 ;	quantum/action.c:1122: if (mods) {
      007B7C E0               [24] 1956 	movx	a,@dptr
      007B7D FF               [12] 1957 	mov	r7,a
      007B7E E0               [24] 1958 	movx	a,@dptr
      007B7F 60 08            [24] 1959 	jz	00103$
                                   1960 ;	quantum/action.c:1123: add_owned_weak_mods(mods);
      007B81 8F 82            [24] 1961 	mov	dpl, r7
      007B83 12 82 20         [24] 1962 	lcall	_add_owned_weak_mods
                                   1963 ;	quantum/action.c:1124: send_keyboard_report();
                                   1964 ;	quantum/action.c:1126: }
      007B86 02 85 3F         [24] 1965 	ljmp	_send_keyboard_report
      007B89                       1966 00103$:
      007B89 22               [24] 1967 	ret
                                   1968 ;------------------------------------------------------------
                                   1969 ;Allocation info for local variables in function 'unregister_weak_mods'
                                   1970 ;------------------------------------------------------------
                                   1971 ;mods          Allocated with name '_unregister_weak_mods_mods_10000_768'
                                   1972 ;------------------------------------------------------------
                                   1973 ;	quantum/action.c:1132: __attribute__((weak)) void unregister_weak_mods(uint8_t mods) {
                                   1974 ;	-----------------------------------------
                                   1975 ;	 function unregister_weak_mods
                                   1976 ;	-----------------------------------------
      007B8A                       1977 _unregister_weak_mods:
      007B8A E5 82            [12] 1978 	mov	a,dpl
      007B8C 90 08 73         [24] 1979 	mov	dptr,#_unregister_weak_mods_mods_10000_768
      007B8F F0               [24] 1980 	movx	@dptr,a
                                   1981 ;	quantum/action.c:1133: if (mods) {
      007B90 E0               [24] 1982 	movx	a,@dptr
      007B91 FF               [12] 1983 	mov	r7,a
      007B92 E0               [24] 1984 	movx	a,@dptr
      007B93 60 08            [24] 1985 	jz	00103$
                                   1986 ;	quantum/action.c:1134: del_owned_weak_mods(mods);
      007B95 8F 82            [24] 1987 	mov	dpl, r7
      007B97 12 82 2F         [24] 1988 	lcall	_del_owned_weak_mods
                                   1989 ;	quantum/action.c:1135: send_keyboard_report();
                                   1990 ;	quantum/action.c:1137: }
      007B9A 02 85 3F         [24] 1991 	ljmp	_send_keyboard_report
      007B9D                       1992 00103$:
      007B9D 22               [24] 1993 	ret
                                   1994 ;------------------------------------------------------------
                                   1995 ;Allocation info for local variables in function 'clear_keyboard'
                                   1996 ;------------------------------------------------------------
                                   1997 ;	quantum/action.c:1143: void clear_keyboard(void) {
                                   1998 ;	-----------------------------------------
                                   1999 ;	 function clear_keyboard
                                   2000 ;	-----------------------------------------
      007B9E                       2001 _clear_keyboard:
                                   2002 ;	quantum/action.c:1144: clear_mods();
      007B9E 12 85 C3         [24] 2003 	lcall	_clear_mods
                                   2004 ;	quantum/action.c:1145: clear_keyboard_but_mods();
                                   2005 ;	quantum/action.c:1146: }
      007BA1 61 A3            [12] 2006 	ajmp	_clear_keyboard_but_mods
                                   2007 ;------------------------------------------------------------
                                   2008 ;Allocation info for local variables in function 'clear_keyboard_but_mods'
                                   2009 ;------------------------------------------------------------
                                   2010 ;	quantum/action.c:1152: void clear_keyboard_but_mods(void) {
                                   2011 ;	-----------------------------------------
                                   2012 ;	 function clear_keyboard_but_mods
                                   2013 ;	-----------------------------------------
      007BA3                       2014 _clear_keyboard_but_mods:
                                   2015 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007BA3 90 0D FB         [24] 2016 	mov	dptr,#_actual_keyboard_report
      007BA6 75 F0 00         [24] 2017 	mov	b, #0x00
      007BA9 12 73 E6         [24] 2018 	lcall	_clear_keys_from_report
                                   2019 ;	quantum/action.c:1154: clear_keyboard_but_mods_and_keys();
                                   2020 ;	quantum/action.c:1155: }
      007BAC 61 AE            [12] 2021 	ajmp	_clear_keyboard_but_mods_and_keys
                                   2022 ;------------------------------------------------------------
                                   2023 ;Allocation info for local variables in function 'clear_keyboard_but_mods_and_keys'
                                   2024 ;------------------------------------------------------------
                                   2025 ;	quantum/action.c:1161: void clear_keyboard_but_mods_and_keys(void) {
                                   2026 ;	-----------------------------------------
                                   2027 ;	 function clear_keyboard_but_mods_and_keys
                                   2028 ;	-----------------------------------------
      007BAE                       2029 _clear_keyboard_but_mods_and_keys:
                                   2030 ;	quantum/action.c:1163: ak820_tapping_cancel();
      007BAE 12 48 F8         [24] 2031 	lcall	_ak820_tapping_cancel
                                   2032 ;	quantum/action.c:1168: ak820_autoshift_cancel();
      007BB1 12 33 4A         [24] 2033 	lcall	_ak820_autoshift_cancel
                                   2034 ;	quantum/action.c:1171: ak820_oneshot_cancel();
      007BB4 12 2E F0         [24] 2035 	lcall	_ak820_oneshot_cancel
                                   2036 ;	quantum/action.c:1174: ak820_combo_cancel();
      007BB7 12 37 B7         [24] 2037 	lcall	_ak820_combo_cancel
                                   2038 ;	quantum/action.c:1177: repeat_key_cancel();
      007BBA 12 A6 99         [24] 2039 	lcall	_repeat_key_cancel
                                   2040 ;	quantum/action.c:1179: clear_owned_mods();
      007BBD 12 82 3E         [24] 2041 	lcall	_clear_owned_mods
                                   2042 ;	quantum/action.c:1180: clear_owned_keys();
      007BC0 12 82 76         [24] 2043 	lcall	_clear_owned_keys
                                   2044 ;	quantum/action.c:1181: clear_owned_usages();
      007BC3 12 83 B4         [24] 2045 	lcall	_clear_owned_usages
                                   2046 ;	quantum/action.c:1182: layer_hold_clear();
      007BC6 B1 AF            [12] 2047 	acall	_layer_hold_clear
                                   2048 ;	quantum/action.c:1184: clear_macro_tri_layer();
      007BC8 12 A1 04         [24] 2049 	lcall	_clear_macro_tri_layer
                                   2050 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007BCB 90 0D FB         [24] 2051 	mov	dptr,#_actual_keyboard_report
      007BCE 75 F0 00         [24] 2052 	mov	b, #0x00
      007BD1 12 73 E6         [24] 2053 	lcall	_clear_keys_from_report
                                   2054 ;	quantum/action.c:1189: host_system_send(0);
      007BD4 90 00 00         [24] 2055 	mov	dptr,#0x0000
      007BD7 12 71 AF         [24] 2056 	lcall	_host_system_send
                                   2057 ;	quantum/action.c:1190: host_consumer_send(0);
      007BDA 90 00 00         [24] 2058 	mov	dptr,#0x0000
      007BDD 12 71 DE         [24] 2059 	lcall	_host_consumer_send
                                   2060 ;	quantum/action.c:1192: clear_weak_mods();
      007BE0 12 85 F8         [24] 2061 	lcall	_clear_weak_mods
                                   2062 ;	quantum/action.c:1193: send_keyboard_report();
      007BE3 12 85 3F         [24] 2063 	lcall	_send_keyboard_report
                                   2064 ;	quantum/action.c:1195: mousekey_clear();
      007BE6 12 54 11         [24] 2065 	lcall	_mousekey_clear
                                   2066 ;	quantum/action.c:1196: mousekey_send();
                                   2067 ;	quantum/action.c:1201: }
      007BE9 02 52 D9         [24] 2068 	ljmp	_mousekey_send
                                   2069 ;------------------------------------------------------------
                                   2070 ;Allocation info for local variables in function 'is_tap_record'
                                   2071 ;------------------------------------------------------------
                                   2072 ;record        Allocated with name '_is_tap_record_record_10000_784'
                                   2073 ;action        Allocated with name '_is_tap_record_action_10001_788'
                                   2074 ;------------------------------------------------------------
                                   2075 ;	quantum/action.c:1207: bool is_tap_record(keyrecord_t *record) {
                                   2076 ;	-----------------------------------------
                                   2077 	.area CSEG    (CODE)
                                   2078 	.area CONST   (CODE)
                                   2079 	.area XINIT   (CODE)
      00C638                       2080 __xinit__disable_action_cache:
      00C638 00                    2081 	.db #0x00	;  0
                                   2082 	.area CABS    (ABS,CODE)
                                   2083 
                                   2084 ; Experimental exact instruction outlining.
                                   2085 	.globl _ak820_outline_0001
                                   2086 	.globl _ak820_outline_0005
                                   2087 	.globl _ak820_outline_0007
                                   2088 	.globl _ak820_outline_0008
                                   2089 	.globl _ak820_outline_0011
                                   2090 	.globl _ak820_outline_0012
                                   2091 	.globl _ak820_outline_0013
                                   2092 	.globl _ak820_outline_0014
                                   2093 	.globl _ak820_outline_0016
                                   2094 	.globl _ak820_outline_0020
                                   2095 	.globl _ak820_outline_0021
                                   2096 	.globl _ak820_outline_0034
                                   2097 	.globl _ak820_outline_0036
                                   2098 	.globl _ak820_outline_0042
                                   2099 	.globl _ak820_outline_0050
                                   2100 	.globl _ak820_outline_0059
                                   2101 	.globl _ak820_outline_0063
                                   2102 	.globl _ak820_outline_0071
                                   2103 	.globl _ak820_outline_0072
                                   2104 	.globl _ak820_outline_0077
                                   2105 	.globl _ak820_outline_0085
                                   2106 	.globl _ak820_outline_0089
                                   2107 	.globl _ak820_outline_0093
                                   2108 	.globl _ak820_outline_0109
                                   2109 	.globl _ak820_outline_0110
                                   2110 	.globl _ak820_outline_0112
                                   2111 	.globl _ak820_outline_0114
                                   2112 	.globl _ak820_outline_0115
                                   2113 	.globl _ak820_outline_0120
                                   2114 	.globl _ak820_outline_0125
                                   2115 	.globl _ak820_outline_0126
                                   2116 	.globl _ak820_outline_0132
                                   2117 	.globl _ak820_outline_0136
                                   2118 	.globl _ak820_outline_0137
                                   2119 	.globl _ak820_outline_0143
                                   2120 	.globl _ak820_outline_0144
                                   2121 	.globl _ak820_outline_0146
                                   2122 	.globl _ak820_outline_0150
                                   2123 	.globl _ak820_outline_0153
                                   2124 	.globl _ak820_outline_0154
                                   2125 	.globl _ak820_outline_0163
                                   2126 	.globl _ak820_outline_0184
                                   2127 	.globl _ak820_outline_0189
                                   2128 	.globl _ak820_outline_0191
                                   2129 
                                   2130 	.area CSEG (CODE)
                                   2131 ; function ak820_outline_0013
      007BEC                       2132 _ak820_outline_0013:
      007BEC 2D               [12] 2133 	add	a,r5
      007BED F9               [12] 2134 	mov	r1,a
      007BEE E4               [12] 2135 	clr	a
      007BEF 3E               [12] 2136 	addc	a,r6
      007BF0 FA               [12] 2137 	mov	r2,a
      007BF1 8F 03            [24] 2138 	mov	ar3,r7
      007BF3 89 82            [24] 2139 	mov	dpl,r1
      007BF5 8A 83            [24] 2140 	mov	dph,r2
      007BF7 8B F0            [24] 2141 	mov	b,r3
      007BF9 22               [24] 2142 	ret
                                   2143 
                                   2144 	.area CSEG (CODE)
                                   2145 ; function ak820_outline_0014
      007BFA                       2146 _ak820_outline_0014:
      007BFA 2D               [12] 2147 	add	a,r5
      007BFB FA               [12] 2148 	mov	r2,a
      007BFC E4               [12] 2149 	clr	a
      007BFD 3E               [12] 2150 	addc	a,r6
      007BFE FB               [12] 2151 	mov	r3,a
      007BFF 8F 04            [24] 2152 	mov	ar4,r7
      007C01 8A 82            [24] 2153 	mov	dpl,r2
      007C03 8B 83            [24] 2154 	mov	dph,r3
      007C05 8C F0            [24] 2155 	mov	b,r4
      007C07 22               [24] 2156 	ret
                                   2157 
                                   2158 	.area CSEG (CODE)
                                   2159 ; function ak820_outline_0020
      007C08                       2160 _ak820_outline_0020:
      007C08 8E 82            [24] 2161 	mov	dpl,r6
      007C0A 8F 83            [24] 2162 	mov	dph,r7
      007C0C A3               [24] 2163 	inc	dptr
      007C0D E0               [24] 2164 	movx	a,@dptr
      007C0E FC               [12] 2165 	mov	r4,a
      007C0F 7D 00            [12] 2166 	mov	r5,#0x00
      007C11 8E 82            [24] 2167 	mov	dpl,r6
      007C13 8F 83            [24] 2168 	mov	dph,r7
      007C15 E0               [24] 2169 	movx	a,@dptr
      007C16 22               [24] 2170 	ret
                                   2171 
                                   2172 	.area CSEG (CODE)
                                   2173 ; function ak820_outline_0042
      007C17                       2174 _ak820_outline_0042:
      007C17 90 08 65         [24] 2175 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007C1A E0               [24] 2176 	movx	a,@dptr
      007C1B 54 1F            [12] 2177 	anl	a,#0x1f
      007C1D F5 82            [12] 2178 	mov	dpl,a
      007C1F 22               [24] 2179 	ret
                                   2180 
                                   2181 	.area CSEG (CODE)
                                   2182 ; function ak820_outline_0063
      007C20                       2183 _ak820_outline_0063:
      007C20 F5 F0            [12] 2184 	mov	b,a
      007C22 05 F0            [12] 2185 	inc	b
      007C24 74 01            [12] 2186 	mov	a,#0x01
      007C26 22               [24] 2187 	ret
                                   2188 
                                   2189 	.area CSEG (CODE)
                                   2190 ; function ak820_outline_0071
      007C27                       2191 _ak820_outline_0071:
      007C27 90 0D D8         [24] 2192 	mov	dptr,#___memcpy_PARM_3
      007C2A 74 06            [12] 2193 	mov	a,#0x06
      007C2C F0               [24] 2194 	movx	@dptr,a
      007C2D E4               [12] 2195 	clr	a
      007C2E A3               [24] 2196 	inc	dptr
      007C2F F0               [24] 2197 	movx	@dptr,a
      007C30 22               [24] 2198 	ret
                                   2199 
                                   2200 	.area CSEG (CODE)
                                   2201 ; function ak820_outline_0077
      007C31                       2202 _ak820_outline_0077:
      007C31 90 08 64         [24] 2203 	mov	dptr,#_process_action_PARM_2
      007C34 E0               [24] 2204 	movx	a,@dptr
      007C35 F5 82            [12] 2205 	mov	dpl,a
      007C37 22               [24] 2206 	ret
                                   2207 
                                   2208 	.area CSEG (CODE)
                                   2209 ; function ak820_outline_0089
      007C38                       2210 _ak820_outline_0089:
      007C38 90 08 65         [24] 2211 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007C3B E0               [24] 2212 	movx	a,@dptr
      007C3C 03               [12] 2213 	rr	a
      007C3D 03               [12] 2214 	rr	a
      007C3E 54 03            [12] 2215 	anl	a,#0x03
      007C40 22               [24] 2216 	ret
                                   2217 
                                   2218 	.area CSEG (CODE)
                                   2219 ; function ak820_outline_0115
      007C41                       2220 _ak820_outline_0115:
      007C41 90 08 65         [24] 2221 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007C44 E0               [24] 2222 	movx	a,@dptr
      007C45 54 0F            [12] 2223 	anl	a,#0x0f
      007C47 22               [24] 2224 	ret
                                   2225 
                                   2226 	.area CSEG (CODE)
                                   2227 ; function ak820_outline_0132
      007C48                       2228 _ak820_outline_0132:
      007C48 90 08 64         [24] 2229 	mov	dptr,#_process_action_PARM_2
      007C4B E0               [24] 2230 	movx	a,@dptr
      007C4C FE               [12] 2231 	mov	r6,a
      007C4D A3               [24] 2232 	inc	dptr
      007C4E E0               [24] 2233 	movx	a,@dptr
      007C4F 54 03            [12] 2234 	anl	a,#0x03
      007C51 FF               [12] 2235 	mov	r7,a
      007C52 22               [24] 2236 	ret
                                   2237 
                                   2238 	.area CSEG (CODE)
                                   2239 ; function ak820_outline_0143
      007C53                       2240 _ak820_outline_0143:
      007C53 90 08 6A         [24] 2241 	mov	dptr,#_register_code_code_10000_720
      007C56 E0               [24] 2242 	movx	a,@dptr
      007C57 FF               [12] 2243 	mov	r7,a
      007C58 22               [24] 2244 	ret
                                   2245 
                                   2246 	.area CSEG (CODE)
                                   2247 ; function ak820_outline_0144
      007C59                       2248 _ak820_outline_0144:
      007C59 90 08 6B         [24] 2249 	mov	dptr,#_unregister_code_code_10000_734
      007C5C E0               [24] 2250 	movx	a,@dptr
      007C5D FF               [12] 2251 	mov	r7,a
      007C5E 22               [24] 2252 	ret
                                   2253 
                                   2254 	.area CSEG (CODE)
                                   2255 ; function ak820_outline_0150
      007C5F                       2256 _ak820_outline_0150:
      007C5F 74 07            [12] 2257 	mov	a,#0x07
      007C61 2D               [12] 2258 	add	a,r5
      007C62 F8               [12] 2259 	mov	r0,a
      007C63 E4               [12] 2260 	clr	a
      007C64 3E               [12] 2261 	addc	a,r6
      007C65 F9               [12] 2262 	mov	r1,a
      007C66 8F 02            [24] 2263 	mov	ar2,r7
      007C68 22               [24] 2264 	ret
                                   2265 
                                   2266 	.area CSEG (CODE)
                                   2267 ; function ak820_outline_0153
      007C69                       2268 _ak820_outline_0153:
      007C69 90 08 64         [24] 2269 	mov	dptr,#_process_action_PARM_2
      007C6C E0               [24] 2270 	movx	a,@dptr
      007C6D 22               [24] 2271 	ret
                                   2272 
                                   2273 	.area CSEG (CODE)
                                   2274 ; function ak820_outline_0189
      007C6E                       2275 _ak820_outline_0189:
      007C6E F0               [24] 2276 	movx	@dptr,a
      007C6F EB               [12] 2277 	mov	a,r3
      007C70 A3               [24] 2278 	inc	dptr
      007C71 F0               [24] 2279 	movx	@dptr,a
      007C72 22               [24] 2280 	ret
                                   2281 
                                   2282 	.area CSEG (CODE)
                                   2283 ; function ak820_outline_0191
      007C73                       2284 _ak820_outline_0191:
      007C73 E4               [12] 2285 	clr	a
      007C74 F0               [24] 2286 	movx	@dptr,a
      007C75 8F 82            [24] 2287 	mov	dpl,r7
      007C77 22               [24] 2288 	ret
