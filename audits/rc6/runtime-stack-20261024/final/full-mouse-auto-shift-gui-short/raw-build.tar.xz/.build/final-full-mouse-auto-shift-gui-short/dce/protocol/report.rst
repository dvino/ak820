                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module report
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _memset
                                     12 	.globl _ADC_START
                                     13 	.globl _S0_R_FIFO
                                     14 	.globl _S0_T_FIFO
                                     15 	.globl _S0_FREE
                                     16 	.globl _S0_IF_BYTE
                                     17 	.globl _S0_IF_FIRST
                                     18 	.globl _S0_IF_OV
                                     19 	.globl _S0_FST_ACT
                                     20 	.globl _CP_RL2
                                     21 	.globl _C_T2
                                     22 	.globl _TR2
                                     23 	.globl _EXEN2
                                     24 	.globl _TCLK
                                     25 	.globl _RCLK
                                     26 	.globl _EXF2
                                     27 	.globl _CAP1F
                                     28 	.globl _TF2
                                     29 	.globl _RI
                                     30 	.globl _TI
                                     31 	.globl _RB8
                                     32 	.globl _TB8
                                     33 	.globl _REN
                                     34 	.globl _SM2
                                     35 	.globl _SM1
                                     36 	.globl _SM0
                                     37 	.globl _IT0
                                     38 	.globl _IE0
                                     39 	.globl _IT1
                                     40 	.globl _IE1
                                     41 	.globl _TR0
                                     42 	.globl _TF0
                                     43 	.globl _TR1
                                     44 	.globl _TF1
                                     45 	.globl _P4_0
                                     46 	.globl _P4_1
                                     47 	.globl _P4_2
                                     48 	.globl _P4_3
                                     49 	.globl _P4_4
                                     50 	.globl _P4_5
                                     51 	.globl _P4_6
                                     52 	.globl _RXD
                                     53 	.globl _TXD
                                     54 	.globl _INT0
                                     55 	.globl _INT1
                                     56 	.globl _T0
                                     57 	.globl _T1
                                     58 	.globl _MOSI1
                                     59 	.globl _MISO1
                                     60 	.globl _SCK1
                                     61 	.globl _P3_0
                                     62 	.globl _P3_1
                                     63 	.globl _P3_2
                                     64 	.globl _P3_3
                                     65 	.globl _P3_4
                                     66 	.globl _P3_5
                                     67 	.globl _P3_6
                                     68 	.globl _P3_7
                                     69 	.globl _CAP1_
                                     70 	.globl _T2_
                                     71 	.globl _CAP2_
                                     72 	.globl _T2EX_
                                     73 	.globl _RXD1
                                     74 	.globl _TXD1
                                     75 	.globl _P2_0
                                     76 	.globl _P2_1
                                     77 	.globl _P2_2
                                     78 	.globl _P2_3
                                     79 	.globl _P2_4
                                     80 	.globl _P2_5
                                     81 	.globl _P2_6
                                     82 	.globl _P2_7
                                     83 	.globl _AIN0
                                     84 	.globl _AIN1
                                     85 	.globl _AIN2
                                     86 	.globl _AIN3
                                     87 	.globl _AIN4
                                     88 	.globl _AIN5
                                     89 	.globl _AIN6
                                     90 	.globl _AIN7
                                     91 	.globl _CAP1
                                     92 	.globl _T2
                                     93 	.globl _CAP2
                                     94 	.globl _T2EX
                                     95 	.globl _INT0_
                                     96 	.globl _SCS
                                     97 	.globl _MOSI
                                     98 	.globl _MISO
                                     99 	.globl _SCK
                                    100 	.globl _RXD1_
                                    101 	.globl _TXD1_
                                    102 	.globl _P1_0
                                    103 	.globl _P1_1
                                    104 	.globl _P1_2
                                    105 	.globl _P1_3
                                    106 	.globl _P1_4
                                    107 	.globl _P1_5
                                    108 	.globl _P1_6
                                    109 	.globl _P1_7
                                    110 	.globl _AIN8
                                    111 	.globl _AIN9
                                    112 	.globl _AIN10
                                    113 	.globl _AIN11
                                    114 	.globl _AIN12
                                    115 	.globl _AIN13
                                    116 	.globl _RXD_
                                    117 	.globl _TXD_
                                    118 	.globl _SCL0
                                    119 	.globl _SDA0
                                    120 	.globl _P0_0
                                    121 	.globl _P0_1
                                    122 	.globl _P0_2
                                    123 	.globl _P0_3
                                    124 	.globl _P0_4
                                    125 	.globl _P0_5
                                    126 	.globl _P0_6
                                    127 	.globl _P0_7
                                    128 	.globl _IE_SPI0
                                    129 	.globl _IE_USB
                                    130 	.globl _IE_ADC
                                    131 	.globl _IE_UART1
                                    132 	.globl _IE_PWM_I2C
                                    133 	.globl _IE_GPIO
                                    134 	.globl _IE_WDOG
                                    135 	.globl _PX0
                                    136 	.globl _PT0
                                    137 	.globl _PX1
                                    138 	.globl _PT1
                                    139 	.globl _PS
                                    140 	.globl _PT2
                                    141 	.globl _PL_FLAG
                                    142 	.globl _PH_FLAG
                                    143 	.globl _EX0
                                    144 	.globl _ET0
                                    145 	.globl _EX1
                                    146 	.globl _ET1
                                    147 	.globl _ES
                                    148 	.globl _ET2
                                    149 	.globl _E_DIS
                                    150 	.globl _EA
                                    151 	.globl _P
                                    152 	.globl _F1
                                    153 	.globl _OV
                                    154 	.globl _RS0
                                    155 	.globl _RS1
                                    156 	.globl _F0
                                    157 	.globl _AC
                                    158 	.globl _CY
                                    159 	.globl _I2CS_INT_ST
                                    160 	.globl _I2CX_INT
                                    161 	.globl _LED_STATUS
                                    162 	.globl _LED_DMA_H
                                    163 	.globl _LED_DMA_L
                                    164 	.globl _LED_DMA
                                    165 	.globl _LED_PWM_OE
                                    166 	.globl _LED_COMMON
                                    167 	.globl _ADC_CHAN
                                    168 	.globl _ADC_DAT_H
                                    169 	.globl _ADC_DAT_L
                                    170 	.globl _ADC_DAT
                                    171 	.globl _ADC_CTRL
                                    172 	.globl _SPI1_CK_SE
                                    173 	.globl _SPI1_CTRL
                                    174 	.globl _SPI1_DATA
                                    175 	.globl _SPI1_STAT
                                    176 	.globl _SIF1
                                    177 	.globl _SBAUD1
                                    178 	.globl _SBUF1
                                    179 	.globl _SCON1
                                    180 	.globl _SPI0_SETUP
                                    181 	.globl _SPI0_CK_SE
                                    182 	.globl _SPI0_CTRL
                                    183 	.globl _SPI0_DATA
                                    184 	.globl _SPI0_STAT
                                    185 	.globl _T2CAP1H
                                    186 	.globl _T2CAP1L
                                    187 	.globl _T2CAP1
                                    188 	.globl _TH2
                                    189 	.globl _TL2
                                    190 	.globl _T2COUNT
                                    191 	.globl _RCAP2H
                                    192 	.globl _RCAP2L
                                    193 	.globl _RCAP2
                                    194 	.globl _T2MOD
                                    195 	.globl _T2CON
                                    196 	.globl _SBUF
                                    197 	.globl _SCON
                                    198 	.globl _TH1
                                    199 	.globl _TH0
                                    200 	.globl _TL1
                                    201 	.globl _TL0
                                    202 	.globl _TMOD
                                    203 	.globl _TCON
                                    204 	.globl _XBUS_AUX
                                    205 	.globl _P7
                                    206 	.globl _P6_DIR
                                    207 	.globl _P6_OUT_PU
                                    208 	.globl _P6_IN
                                    209 	.globl _P5_DIR
                                    210 	.globl _P5_OUT_PU
                                    211 	.globl _P5_IN
                                    212 	.globl _P4_LED_KEY
                                    213 	.globl _P4_DIR_PU
                                    214 	.globl _P4_MOD_OC
                                    215 	.globl _P4
                                    216 	.globl _P3_DIR_PU
                                    217 	.globl _P3_MOD_OC
                                    218 	.globl _P3
                                    219 	.globl _P2_DIR_PU
                                    220 	.globl _P2_MOD_OC
                                    221 	.globl _P2
                                    222 	.globl _P1_DIR_PU
                                    223 	.globl _P1_MOD_OC
                                    224 	.globl _P1
                                    225 	.globl _P0_DIR_PU
                                    226 	.globl _P0_MOD_OC
                                    227 	.globl _P0
                                    228 	.globl _ROM_CTRL
                                    229 	.globl _ROM_DATA_HH
                                    230 	.globl _ROM_DATA_HL
                                    231 	.globl _ROM_DATA_HI
                                    232 	.globl _ROM_ADDR_H
                                    233 	.globl _ROM_ADDR_L
                                    234 	.globl _ROM_ADDR
                                    235 	.globl _GPIO_IE
                                    236 	.globl _IP_EX
                                    237 	.globl _IE_EX
                                    238 	.globl _IP
                                    239 	.globl _IE
                                    240 	.globl _WDOG_COUNT
                                    241 	.globl _RESET_KEEP
                                    242 	.globl _WAKE_CTRL
                                    243 	.globl _CLOCK_CFG
                                    244 	.globl _POWER_CFG
                                    245 	.globl _PCON
                                    246 	.globl _GLOBAL_CFG
                                    247 	.globl _SAFE_MOD
                                    248 	.globl _DPH
                                    249 	.globl _DPL
                                    250 	.globl _SP
                                    251 	.globl _A_INV
                                    252 	.globl _B
                                    253 	.globl _ACC
                                    254 	.globl _PSW
                                    255 	.globl _del_key_from_report_PARM_2
                                    256 	.globl _add_key_to_report_PARM_2
                                    257 	.globl _del_key_bit_PARM_2
                                    258 	.globl _add_key_bit_PARM_2
                                    259 	.globl _del_key_byte_PARM_2
                                    260 	.globl _add_key_byte_PARM_2
                                    261 	.globl _KEYCODE2CONSUMER
                                    262 	.globl _add_key_byte
                                    263 	.globl _del_key_byte
                                    264 	.globl _add_key_bit
                                    265 	.globl _del_key_bit
                                    266 	.globl _add_key_to_report
                                    267 	.globl _del_key_from_report
                                    268 	.globl _clear_keys_from_report
                                    269 ;--------------------------------------------------------
                                    270 ; special function registers
                                    271 ;--------------------------------------------------------
                                    272 	.area RSEG    (ABS,DATA)
      000000                        273 	.org 0x0000
                           0000D0   274 _PSW	=	0x00d0
                           0000E0   275 _ACC	=	0x00e0
                           0000F0   276 _B	=	0x00f0
                           0000FD   277 _A_INV	=	0x00fd
                           000081   278 _SP	=	0x0081
                           000082   279 _DPL	=	0x0082
                           000083   280 _DPH	=	0x0083
                           0000A1   281 _SAFE_MOD	=	0x00a1
                           0000B1   282 _GLOBAL_CFG	=	0x00b1
                           000087   283 _PCON	=	0x0087
                           0000BA   284 _POWER_CFG	=	0x00ba
                           0000B9   285 _CLOCK_CFG	=	0x00b9
                           0000A9   286 _WAKE_CTRL	=	0x00a9
                           0000FE   287 _RESET_KEEP	=	0x00fe
                           0000FF   288 _WDOG_COUNT	=	0x00ff
                           0000A8   289 _IE	=	0x00a8
                           0000B8   290 _IP	=	0x00b8
                           0000E8   291 _IE_EX	=	0x00e8
                           0000E9   292 _IP_EX	=	0x00e9
                           0000B2   293 _GPIO_IE	=	0x00b2
                           008584   294 _ROM_ADDR	=	0x8584
                           000084   295 _ROM_ADDR_L	=	0x0084
                           000085   296 _ROM_ADDR_H	=	0x0085
                           008F8E   297 _ROM_DATA_HI	=	0x8f8e
                           00008E   298 _ROM_DATA_HL	=	0x008e
                           00008F   299 _ROM_DATA_HH	=	0x008f
                           000086   300 _ROM_CTRL	=	0x0086
                           000080   301 _P0	=	0x0080
                           0000C4   302 _P0_MOD_OC	=	0x00c4
                           0000C5   303 _P0_DIR_PU	=	0x00c5
                           000090   304 _P1	=	0x0090
                           000092   305 _P1_MOD_OC	=	0x0092
                           000093   306 _P1_DIR_PU	=	0x0093
                           0000A0   307 _P2	=	0x00a0
                           000094   308 _P2_MOD_OC	=	0x0094
                           000095   309 _P2_DIR_PU	=	0x0095
                           0000B0   310 _P3	=	0x00b0
                           000096   311 _P3_MOD_OC	=	0x0096
                           000097   312 _P3_DIR_PU	=	0x0097
                           0000C0   313 _P4	=	0x00c0
                           0000C2   314 _P4_MOD_OC	=	0x00c2
                           0000C3   315 _P4_DIR_PU	=	0x00c3
                           0000C1   316 _P4_LED_KEY	=	0x00c1
                           0000AA   317 _P5_IN	=	0x00aa
                           0000AB   318 _P5_OUT_PU	=	0x00ab
                           0000AC   319 _P5_DIR	=	0x00ac
                           0000AD   320 _P6_IN	=	0x00ad
                           0000AE   321 _P6_OUT_PU	=	0x00ae
                           0000AF   322 _P6_DIR	=	0x00af
                           0000F1   323 _P7	=	0x00f1
                           0000A2   324 _XBUS_AUX	=	0x00a2
                           000088   325 _TCON	=	0x0088
                           000089   326 _TMOD	=	0x0089
                           00008A   327 _TL0	=	0x008a
                           00008B   328 _TL1	=	0x008b
                           00008C   329 _TH0	=	0x008c
                           00008D   330 _TH1	=	0x008d
                           000098   331 _SCON	=	0x0098
                           000099   332 _SBUF	=	0x0099
                           0000C8   333 _T2CON	=	0x00c8
                           0000C9   334 _T2MOD	=	0x00c9
                           00CBCA   335 _RCAP2	=	0xcbca
                           0000CA   336 _RCAP2L	=	0x00ca
                           0000CB   337 _RCAP2H	=	0x00cb
                           00CDCC   338 _T2COUNT	=	0xcdcc
                           0000CC   339 _TL2	=	0x00cc
                           0000CD   340 _TH2	=	0x00cd
                           00CFCE   341 _T2CAP1	=	0xcfce
                           0000CE   342 _T2CAP1L	=	0x00ce
                           0000CF   343 _T2CAP1H	=	0x00cf
                           0000F8   344 _SPI0_STAT	=	0x00f8
                           0000F9   345 _SPI0_DATA	=	0x00f9
                           0000FA   346 _SPI0_CTRL	=	0x00fa
                           0000FB   347 _SPI0_CK_SE	=	0x00fb
                           0000FC   348 _SPI0_SETUP	=	0x00fc
                           0000BC   349 _SCON1	=	0x00bc
                           0000BD   350 _SBUF1	=	0x00bd
                           0000BE   351 _SBAUD1	=	0x00be
                           0000BF   352 _SIF1	=	0x00bf
                           0000B4   353 _SPI1_STAT	=	0x00b4
                           0000B5   354 _SPI1_DATA	=	0x00b5
                           0000B6   355 _SPI1_CTRL	=	0x00b6
                           0000B7   356 _SPI1_CK_SE	=	0x00b7
                           0000F3   357 _ADC_CTRL	=	0x00f3
                           00F5F4   358 _ADC_DAT	=	0xf5f4
                           0000F4   359 _ADC_DAT_L	=	0x00f4
                           0000F5   360 _ADC_DAT_H	=	0x00f5
                           0000F6   361 _ADC_CHAN	=	0x00f6
                           0000A6   362 _LED_COMMON	=	0x00a6
                           0000A7   363 _LED_PWM_OE	=	0x00a7
                           00C7C6   364 _LED_DMA	=	0xc7c6
                           0000C6   365 _LED_DMA_L	=	0x00c6
                           0000C7   366 _LED_DMA_H	=	0x00c7
                           0000F7   367 _LED_STATUS	=	0x00f7
                           0000B3   368 _I2CX_INT	=	0x00b3
                           0000BB   369 _I2CS_INT_ST	=	0x00bb
                                    370 ;--------------------------------------------------------
                                    371 ; special function bits
                                    372 ;--------------------------------------------------------
                                    373 	.area RSEG    (ABS,DATA)
      000000                        374 	.org 0x0000
                           0000D7   375 _CY	=	0x00d7
                           0000D6   376 _AC	=	0x00d6
                           0000D5   377 _F0	=	0x00d5
                           0000D4   378 _RS1	=	0x00d4
                           0000D3   379 _RS0	=	0x00d3
                           0000D2   380 _OV	=	0x00d2
                           0000D1   381 _F1	=	0x00d1
                           0000D0   382 _P	=	0x00d0
                           0000AF   383 _EA	=	0x00af
                           0000AE   384 _E_DIS	=	0x00ae
                           0000AD   385 _ET2	=	0x00ad
                           0000AC   386 _ES	=	0x00ac
                           0000AB   387 _ET1	=	0x00ab
                           0000AA   388 _EX1	=	0x00aa
                           0000A9   389 _ET0	=	0x00a9
                           0000A8   390 _EX0	=	0x00a8
                           0000BF   391 _PH_FLAG	=	0x00bf
                           0000BE   392 _PL_FLAG	=	0x00be
                           0000BD   393 _PT2	=	0x00bd
                           0000BC   394 _PS	=	0x00bc
                           0000BB   395 _PT1	=	0x00bb
                           0000BA   396 _PX1	=	0x00ba
                           0000B9   397 _PT0	=	0x00b9
                           0000B8   398 _PX0	=	0x00b8
                           0000EF   399 _IE_WDOG	=	0x00ef
                           0000EE   400 _IE_GPIO	=	0x00ee
                           0000ED   401 _IE_PWM_I2C	=	0x00ed
                           0000EC   402 _IE_UART1	=	0x00ec
                           0000EB   403 _IE_ADC	=	0x00eb
                           0000E9   404 _IE_USB	=	0x00e9
                           0000E8   405 _IE_SPI0	=	0x00e8
                           000087   406 _P0_7	=	0x0087
                           000086   407 _P0_6	=	0x0086
                           000085   408 _P0_5	=	0x0085
                           000084   409 _P0_4	=	0x0084
                           000083   410 _P0_3	=	0x0083
                           000082   411 _P0_2	=	0x0082
                           000081   412 _P0_1	=	0x0081
                           000080   413 _P0_0	=	0x0080
                           000081   414 _SDA0	=	0x0081
                           000080   415 _SCL0	=	0x0080
                           000083   416 _TXD_	=	0x0083
                           000082   417 _RXD_	=	0x0082
                           000085   418 _AIN13	=	0x0085
                           000084   419 _AIN12	=	0x0084
                           000083   420 _AIN11	=	0x0083
                           000082   421 _AIN10	=	0x0082
                           000081   422 _AIN9	=	0x0081
                           000080   423 _AIN8	=	0x0080
                           000097   424 _P1_7	=	0x0097
                           000096   425 _P1_6	=	0x0096
                           000095   426 _P1_5	=	0x0095
                           000094   427 _P1_4	=	0x0094
                           000093   428 _P1_3	=	0x0093
                           000092   429 _P1_2	=	0x0092
                           000091   430 _P1_1	=	0x0091
                           000090   431 _P1_0	=	0x0090
                           000097   432 _TXD1_	=	0x0097
                           000096   433 _RXD1_	=	0x0096
                           000097   434 _SCK	=	0x0097
                           000096   435 _MISO	=	0x0096
                           000095   436 _MOSI	=	0x0095
                           000094   437 _SCS	=	0x0094
                           000092   438 _INT0_	=	0x0092
                           000091   439 _T2EX	=	0x0091
                           000091   440 _CAP2	=	0x0091
                           000090   441 _T2	=	0x0090
                           000090   442 _CAP1	=	0x0090
                           000097   443 _AIN7	=	0x0097
                           000096   444 _AIN6	=	0x0096
                           000095   445 _AIN5	=	0x0095
                           000094   446 _AIN4	=	0x0094
                           000093   447 _AIN3	=	0x0093
                           000092   448 _AIN2	=	0x0092
                           000091   449 _AIN1	=	0x0091
                           000090   450 _AIN0	=	0x0090
                           0000A7   451 _P2_7	=	0x00a7
                           0000A6   452 _P2_6	=	0x00a6
                           0000A5   453 _P2_5	=	0x00a5
                           0000A4   454 _P2_4	=	0x00a4
                           0000A3   455 _P2_3	=	0x00a3
                           0000A2   456 _P2_2	=	0x00a2
                           0000A1   457 _P2_1	=	0x00a1
                           0000A0   458 _P2_0	=	0x00a0
                           0000A7   459 _TXD1	=	0x00a7
                           0000A6   460 _RXD1	=	0x00a6
                           0000A5   461 _T2EX_	=	0x00a5
                           0000A5   462 _CAP2_	=	0x00a5
                           0000A4   463 _T2_	=	0x00a4
                           0000A4   464 _CAP1_	=	0x00a4
                           0000B7   465 _P3_7	=	0x00b7
                           0000B6   466 _P3_6	=	0x00b6
                           0000B5   467 _P3_5	=	0x00b5
                           0000B4   468 _P3_4	=	0x00b4
                           0000B3   469 _P3_3	=	0x00b3
                           0000B2   470 _P3_2	=	0x00b2
                           0000B1   471 _P3_1	=	0x00b1
                           0000B0   472 _P3_0	=	0x00b0
                           0000B7   473 _SCK1	=	0x00b7
                           0000B6   474 _MISO1	=	0x00b6
                           0000B5   475 _MOSI1	=	0x00b5
                           0000B5   476 _T1	=	0x00b5
                           0000B4   477 _T0	=	0x00b4
                           0000B3   478 _INT1	=	0x00b3
                           0000B2   479 _INT0	=	0x00b2
                           0000B1   480 _TXD	=	0x00b1
                           0000B0   481 _RXD	=	0x00b0
                           0000C6   482 _P4_6	=	0x00c6
                           0000C5   483 _P4_5	=	0x00c5
                           0000C4   484 _P4_4	=	0x00c4
                           0000C3   485 _P4_3	=	0x00c3
                           0000C2   486 _P4_2	=	0x00c2
                           0000C1   487 _P4_1	=	0x00c1
                           0000C0   488 _P4_0	=	0x00c0
                           00008F   489 _TF1	=	0x008f
                           00008E   490 _TR1	=	0x008e
                           00008D   491 _TF0	=	0x008d
                           00008C   492 _TR0	=	0x008c
                           00008B   493 _IE1	=	0x008b
                           00008A   494 _IT1	=	0x008a
                           000089   495 _IE0	=	0x0089
                           000088   496 _IT0	=	0x0088
                           00009F   497 _SM0	=	0x009f
                           00009E   498 _SM1	=	0x009e
                           00009D   499 _SM2	=	0x009d
                           00009C   500 _REN	=	0x009c
                           00009B   501 _TB8	=	0x009b
                           00009A   502 _RB8	=	0x009a
                           000099   503 _TI	=	0x0099
                           000098   504 _RI	=	0x0098
                           0000CF   505 _TF2	=	0x00cf
                           0000CF   506 _CAP1F	=	0x00cf
                           0000CE   507 _EXF2	=	0x00ce
                           0000CD   508 _RCLK	=	0x00cd
                           0000CC   509 _TCLK	=	0x00cc
                           0000CB   510 _EXEN2	=	0x00cb
                           0000CA   511 _TR2	=	0x00ca
                           0000C9   512 _C_T2	=	0x00c9
                           0000C8   513 _CP_RL2	=	0x00c8
                           0000FF   514 _S0_FST_ACT	=	0x00ff
                           0000FE   515 _S0_IF_OV	=	0x00fe
                           0000FD   516 _S0_IF_FIRST	=	0x00fd
                           0000FC   517 _S0_IF_BYTE	=	0x00fc
                           0000FB   518 _S0_FREE	=	0x00fb
                           0000FA   519 _S0_T_FIFO	=	0x00fa
                           0000F8   520 _S0_R_FIFO	=	0x00f8
                           0000F7   521 _ADC_START	=	0x00f7
                                    522 ;--------------------------------------------------------
                                    523 ; overlayable register banks
                                    524 ;--------------------------------------------------------
                                    525 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        526 	.ds 8
                                    527 ;--------------------------------------------------------
                                    528 ; internal ram data
                                    529 ;--------------------------------------------------------
                                    530 	.area DSEG    (DATA)
                                    531 ;--------------------------------------------------------
                                    532 ; overlayable items in internal ram
                                    533 ;--------------------------------------------------------
                                    534 	.area	OSEG    (OVR,DATA)
                                    535 ;--------------------------------------------------------
                                    536 ; indirectly addressable internal ram data
                                    537 ;--------------------------------------------------------
                                    538 	.area ISEG    (DATA)
                                    539 ;--------------------------------------------------------
                                    540 ; absolute internal ram data
                                    541 ;--------------------------------------------------------
                                    542 	.area IABS    (ABS,DATA)
                                    543 	.area IABS    (ABS,DATA)
                                    544 ;--------------------------------------------------------
                                    545 ; bit data
                                    546 ;--------------------------------------------------------
                                    547 	.area BSEG    (BIT)
                                    548 ;--------------------------------------------------------
                                    549 ; paged external ram data
                                    550 ;--------------------------------------------------------
                                    551 	.area PSEG    (PAG,XDATA)
                                    552 ;--------------------------------------------------------
                                    553 ; uninitialized external ram data
                                    554 ;--------------------------------------------------------
                                    555 	.area XSEG    (XDATA)
      00081D                        556 _KEYCODE2CONSUMER_key_10000_118:
      00081D                        557 	.ds 1
      00081E                        558 _add_key_byte_PARM_2:
      00081E                        559 	.ds 1
      00081F                        560 _add_key_byte_report_arg_10000_145:
      00081F                        561 	.ds 3
      000822                        562 _add_key_byte_empty_10000_146:
      000822                        563 	.ds 1
      000823                        564 _del_key_byte_PARM_2:
      000823                        565 	.ds 1
      000824                        566 _del_key_byte_report_arg_10000_157:
      000824                        567 	.ds 3
      000827                        568 _add_key_bit_PARM_2:
      000827                        569 	.ds 1
      000828                        570 _add_key_bit_report_arg_10000_163:
      000828                        571 	.ds 3
      00082B                        572 _del_key_bit_PARM_2:
      00082B                        573 	.ds 1
      00082C                        574 _del_key_bit_report_arg_10000_168:
      00082C                        575 	.ds 3
      00082F                        576 _add_key_to_report_PARM_2:
      00082F                        577 	.ds 1
      000830                        578 _add_key_to_report_report_arg_10000_173:
      000830                        579 	.ds 3
      000833                        580 _del_key_from_report_PARM_2:
      000833                        581 	.ds 1
      000834                        582 _del_key_from_report_report_arg_10000_177:
      000834                        583 	.ds 3
      000837                        584 _clear_keys_from_report_report_arg_10000_181:
      000837                        585 	.ds 3
                                    586 ;--------------------------------------------------------
                                    587 ; absolute external ram data
                                    588 ;--------------------------------------------------------
                                    589 	.area XABS    (ABS,XDATA)
                                    590 ;--------------------------------------------------------
                                    591 ; initialized external ram data
                                    592 ;--------------------------------------------------------
                                    593 	.area XISEG   (XDATA)
                                    594 	.area HOME    (CODE)
                                    595 	.area GSINIT0 (CODE)
                                    596 	.area GSINIT1 (CODE)
                                    597 	.area GSINIT2 (CODE)
                                    598 	.area GSINIT3 (CODE)
                                    599 	.area GSINIT4 (CODE)
                                    600 	.area GSINIT5 (CODE)
                                    601 	.area GSINIT  (CODE)
                                    602 	.area GSFINAL (CODE)
                                    603 	.area CSEG    (CODE)
                                    604 ;--------------------------------------------------------
                                    605 ; global & static initialisations
                                    606 ;--------------------------------------------------------
                                    607 	.area HOME    (CODE)
                                    608 	.area GSINIT  (CODE)
                                    609 	.area GSFINAL (CODE)
                                    610 	.area GSINIT  (CODE)
                                    611 ;--------------------------------------------------------
                                    612 ; Home
                                    613 ;--------------------------------------------------------
                                    614 	.area HOME    (CODE)
                                    615 	.area HOME    (CODE)
                                    616 ;--------------------------------------------------------
                                    617 ; code
                                    618 ;--------------------------------------------------------
                                    619 	.area CSEG    (CODE)
                                    620 ;------------------------------------------------------------
                                    621 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    622 ;------------------------------------------------------------
                                    623 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    624 ;------------------------------------------------------------
                                    625 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    626 ;	-----------------------------------------
                           000007   627 	ar7 = 0x07
                           000006   628 	ar6 = 0x06
                           000005   629 	ar5 = 0x05
                           000004   630 	ar4 = 0x04
                           000003   631 	ar3 = 0x03
                           000002   632 	ar2 = 0x02
                           000001   633 	ar1 = 0x01
                           000000   634 	ar0 = 0x00
                                    635 ;	 function KEYCODE2CONSUMER
                                    636 ;	-----------------------------------------
      00722A                        637 _KEYCODE2CONSUMER:
      00722A E5 82            [12]  638 	mov	a,dpl
      00722C 90 08 1D         [24]  639 	mov	dptr,#_KEYCODE2CONSUMER_key_10000_118
      00722F F0               [24]  640 	movx	@dptr,a
                                    641 ;	tmk_core/protocol/report.c:52: if (key < KC_AUDIO_MUTE || key > KC_LAUNCHPAD) return 0;
      007230 E0               [24]  642 	movx	a,@dptr
      007231 FF               [12]  643 	mov	r7,a
      007232 BF A8 00         [24]  644 	cjne	r7,#0xa8,00113$
      007235                        645 00113$:
      007235 40 05            [24]  646 	jc	00101$
      007237 EF               [12]  647 	mov	a,r7
      007238 24 3D            [12]  648 	add	a,#0xff - 0xc2
      00723A 50 04            [24]  649 	jnc	00102$
                                    650 ;	free result
      00723C                        651 00101$:
      00723C 90 00 00         [24]  652 	mov	dptr,#0x0000
      00723F 22               [24]  653 	ret
      007240                        654 00102$:
                                    655 ;	tmk_core/protocol/report.c:53: return usages[key - KC_AUDIO_MUTE];
      007240 EF               [12]  656 	mov	a,r7
      007241 24 58            [12]  657 	add	a,#0x58
      007243 FF               [12]  658 	mov	r7,a
      007244 C2 D5            [12]  659 	clr	F0
      007246 75 F0 02         [24]  660 	mov	b,#0x02
      007249 EF               [12]  661 	mov	a,r7
      00724A 30 E7 04         [24]  662 	jnb	acc.7,00116$
      00724D B2 D5            [12]  663 	cpl	F0
      00724F F4               [12]  664 	cpl	a
      007250 04               [12]  665 	inc	a
      007251                        666 00116$:
      007251 A4               [48]  667 	mul	ab
      007252 30 D5 03         [24]  668 	jnb	F0,00117$
      007255 12 74 52         [24]  669 	lcall	_ak820_outline_0131
      007258                        670 00117$:
      007258 24 9B            [12]  671 	add	a, #_KEYCODE2CONSUMER_usages_10000_119
      00725A F5 82            [12]  672 	mov	dpl,a
      00725C 74 BE            [12]  673 	mov	a,#(_KEYCODE2CONSUMER_usages_10000_119 >> 8)
      00725E 12 5B C6         [24]  674 	lcall	_ak820_outline_0111
      007261 FE               [12]  675 	mov	r6,a
      007262 A3               [24]  676 	inc	dptr
      007263 E4               [12]  677 	clr	a
      007264 93               [24]  678 	movc	a,@a+dptr
                                    679 ;	tmk_core/protocol/report.c:54: }
      007265 8E 82            [24]  680 	mov	dpl,r6
      007267 F5 83            [12]  681 	mov	dph,a
      007269 22               [24]  682 	ret
                                    683 ;------------------------------------------------------------
                                    684 ;Allocation info for local variables in function 'has_anykey'
                                    685 ;------------------------------------------------------------
                                    686 ;report_arg    Allocated with name '_has_anykey_report_arg_10000_121'
                                    687 ;keyboard_report Allocated with name '_has_anykey_keyboard_report_10000_122'
                                    688 ;cnt           Allocated with name '_has_anykey_cnt_10000_122'
                                    689 ;p             Allocated with name '_has_anykey_p_10000_122'
                                    690 ;lp            Allocated with name '_has_anykey_lp_10000_122'
                                    691 ;------------------------------------------------------------
                                    692 ;	tmk_core/protocol/report.c:71: uint8_t has_anykey(report_keyboard_t* report_arg) {
                                    693 ;	-----------------------------------------
                                    694 ;	 function add_key_byte
                                    695 ;	-----------------------------------------
      00726A                        696 _add_key_byte:
      00726A 12 45 55         [24]  697 	lcall	_ak820_outline_0036
      00726D 90 08 1F         [24]  698 	mov	dptr,#_add_key_byte_report_arg_10000_145
      007270 12 3A 5F         [24]  699 	lcall	_ak820_outline_0016
                                    700 ;	tmk_core/protocol/report.c:148: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      007273 90 08 1F         [24]  701 	mov	dptr,#_add_key_byte_report_arg_10000_145
      007276 12 3A 81         [24]  702 	lcall	_ak820_outline_0052
                                    703 ;	tmk_core/protocol/report.c:194: int8_t empty = -1;
      007279 90 08 22         [24]  704 	mov	dptr,#_add_key_byte_empty_10000_146
      00727C 74 FF            [12]  705 	mov	a,#0xff
      00727E F0               [24]  706 	movx	@dptr,a
                                    707 ;	tmk_core/protocol/report.c:209: }
      00727F 7D 00            [12]  708 	mov	r5,#0x00
      007281                        709 00112$:
                                    710 ;	tmk_core/protocol/report.c:195: for (; i < KEYBOARD_REPORT_KEYS; i++) {
      007281 C3               [12]  711 	clr	c
      007282 ED               [12]  712 	mov	a,r5
      007283 64 80            [12]  713 	xrl	a,#0x80
      007285 94 86            [12]  714 	subb	a,#0x86
      007287 50 29            [24]  715 	jnc	00106$
                                    716 ;	tmk_core/protocol/report.c:196: if (keyboard_report->keys[i] == code) {
      007289 12 74 5D         [24]  717 	lcall	_ak820_outline_0149
      00728C F5 82            [12]  718 	mov	dpl,a
      00728E E4               [12]  719 	clr	a
      00728F 3C               [12]  720 	addc	a, r4
      007290 F5 83            [12]  721 	mov	dph,a
      007292 E0               [24]  722 	movx	a,@dptr
      007293 FC               [12]  723 	mov	r4,a
      007294 90 08 1E         [24]  724 	mov	dptr,#_add_key_byte_PARM_2
      007297 E0               [24]  725 	movx	a,@dptr
      007298 FB               [12]  726 	mov	r3,a
      007299 EC               [12]  727 	mov	a,r4
      00729A B5 03 02         [24]  728 	cjne	a,ar3,00167$
      00729D 80 13            [24]  729 	sjmp	00106$
      00729F                        730 00167$:
                                    731 ;	tmk_core/protocol/report.c:199: if (empty == -1 && keyboard_report->keys[i] == 0) {
      00729F 90 08 22         [24]  732 	mov	dptr,#_add_key_byte_empty_10000_146
      0072A2 E0               [24]  733 	movx	a,@dptr
      0072A3 FB               [12]  734 	mov	r3,a
      0072A4 BB FF 08         [24]  735 	cjne	r3,#0xff,00113$
      0072A7 EC               [12]  736 	mov	a,r4
      0072A8 70 05            [24]  737 	jnz	00113$
                                    738 ;	tmk_core/protocol/report.c:200: empty = i;
      0072AA 90 08 22         [24]  739 	mov	dptr,#_add_key_byte_empty_10000_146
      0072AD ED               [12]  740 	mov	a,r5
      0072AE F0               [24]  741 	movx	@dptr,a
      0072AF                        742 00113$:
                                    743 ;	tmk_core/protocol/report.c:195: for (; i < KEYBOARD_REPORT_KEYS; i++) {
      0072AF 0D               [12]  744 	inc	r5
      0072B0 80 CF            [24]  745 	sjmp	00112$
      0072B2                        746 00106$:
                                    747 ;	tmk_core/protocol/report.c:203: if (i == KEYBOARD_REPORT_KEYS) {
      0072B2 BD 06 1D         [24]  748 	cjne	r5,#0x06,00114$
                                    749 ;	tmk_core/protocol/report.c:204: if (empty != -1) {
      0072B5 90 08 22         [24]  750 	mov	dptr,#_add_key_byte_empty_10000_146
      0072B8 E0               [24]  751 	movx	a,@dptr
      0072B9 FD               [12]  752 	mov	r5,a
      0072BA BD FF 01         [24]  753 	cjne	r5,#0xff,00173$
      0072BD 22               [24]  754 	ret
      0072BE                        755 00173$:
                                    756 ;	tmk_core/protocol/report.c:205: keyboard_report->keys[empty] = code;
      0072BE 74 02            [12]  757 	mov	a,#0x02
      0072C0 12 45 9C         [24]  758 	lcall	_ak820_outline_0139
      0072C3 ED               [12]  759 	mov	a,r5
      0072C4 2E               [12]  760 	add	a, r6
      0072C5 FD               [12]  761 	mov	r5,a
      0072C6 E4               [12]  762 	clr	a
      0072C7 3F               [12]  763 	addc	a, r7
      0072C8 FC               [12]  764 	mov	r4,a
      0072C9 90 08 1E         [24]  765 	mov	dptr,#_add_key_byte_PARM_2
      0072CC E0               [24]  766 	movx	a,@dptr
      0072CD 8D 82            [24]  767 	mov	dpl,r5
      0072CF 8C 83            [24]  768 	mov	dph,r4
      0072D1 F0               [24]  769 	movx	@dptr,a
      0072D2                        770 00114$:
                                    771 ;	tmk_core/protocol/report.c:209: }
      0072D2 22               [24]  772 	ret
                                    773 ;------------------------------------------------------------
                                    774 ;Allocation info for local variables in function 'del_key_byte'
                                    775 ;------------------------------------------------------------
                                    776 ;code          Allocated with name '_del_key_byte_PARM_2'
                                    777 ;report_arg    Allocated with name '_del_key_byte_report_arg_10000_157'
                                    778 ;keyboard_report Allocated with name '_del_key_byte_keyboard_report_10000_158'
                                    779 ;i             Allocated with name '_del_key_byte_i_20000_159'
                                    780 ;------------------------------------------------------------
                                    781 ;	tmk_core/protocol/report.c:215: void del_key_byte(report_keyboard_t* report_arg, uint8_t code) {
                                    782 ;	-----------------------------------------
                                    783 ;	 function del_key_byte
                                    784 ;	-----------------------------------------
      0072D3                        785 _del_key_byte:
      0072D3 12 45 55         [24]  786 	lcall	_ak820_outline_0036
      0072D6 90 08 24         [24]  787 	mov	dptr,#_del_key_byte_report_arg_10000_157
      0072D9 12 3A 5F         [24]  788 	lcall	_ak820_outline_0016
                                    789 ;	tmk_core/protocol/report.c:216: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      0072DC 90 08 24         [24]  790 	mov	dptr,#_del_key_byte_report_arg_10000_157
      0072DF 12 3A 81         [24]  791 	lcall	_ak820_outline_0052
                                    792 ;	tmk_core/protocol/report.c:243: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; i++) {
      0072E2 7D 00            [12]  793 	mov	r5,#0x00
      0072E4                        794 00105$:
      0072E4 BD 06 00         [24]  795 	cjne	r5,#0x06,00131$
      0072E7                        796 00131$:
      0072E7 50 1B            [24]  797 	jnc	00107$
                                    798 ;	tmk_core/protocol/report.c:244: if (keyboard_report->keys[i] == code) {
      0072E9 12 74 5D         [24]  799 	lcall	_ak820_outline_0149
      0072EC FB               [12]  800 	mov	r3,a
      0072ED E4               [12]  801 	clr	a
      0072EE 3C               [12]  802 	addc	a, r4
      0072EF FC               [12]  803 	mov	r4,a
      0072F0 12 4A D1         [24]  804 	lcall	_ak820_outline_0065
      0072F3 90 08 23         [24]  805 	mov	dptr,#_del_key_byte_PARM_2
      0072F6 E0               [24]  806 	movx	a,@dptr
      0072F7 F9               [12]  807 	mov	r1,a
      0072F8 EA               [12]  808 	mov	a,r2
      0072F9 B5 01 05         [24]  809 	cjne	a,ar1,00106$
                                    810 ;	tmk_core/protocol/report.c:245: keyboard_report->keys[i] = 0;
      0072FC 12 36 47         [24]  811 	lcall	_ak820_outline_0125
      0072FF E4               [12]  812 	clr	a
      007300 F0               [24]  813 	movx	@dptr,a
      007301                        814 00106$:
                                    815 ;	tmk_core/protocol/report.c:243: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; i++) {
      007301 0D               [12]  816 	inc	r5
      007302 80 E0            [24]  817 	sjmp	00105$
      007304                        818 00107$:
                                    819 ;	tmk_core/protocol/report.c:249: }
      007304 22               [24]  820 	ret
                                    821 ;------------------------------------------------------------
                                    822 ;Allocation info for local variables in function 'add_key_bit'
                                    823 ;------------------------------------------------------------
                                    824 ;code          Allocated with name '_add_key_bit_PARM_2'
                                    825 ;report_arg    Allocated with name '_add_key_bit_report_arg_10000_163'
                                    826 ;keyboard_report Allocated with name '_add_key_bit_keyboard_report_10000_164'
                                    827 ;------------------------------------------------------------
                                    828 ;	tmk_core/protocol/report.c:256: void add_key_bit(report_keyboard_t* report_arg, uint8_t code) {
                                    829 ;	-----------------------------------------
                                    830 ;	 function add_key_bit
                                    831 ;	-----------------------------------------
      007305                        832 _add_key_bit:
      007305 12 45 55         [24]  833 	lcall	_ak820_outline_0036
      007308 90 08 28         [24]  834 	mov	dptr,#_add_key_bit_report_arg_10000_163
      00730B 12 3A 5F         [24]  835 	lcall	_ak820_outline_0016
                                    836 ;	tmk_core/protocol/report.c:257: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      00730E 90 08 28         [24]  837 	mov	dptr,#_add_key_bit_report_arg_10000_163
      007311 12 3A 81         [24]  838 	lcall	_ak820_outline_0052
                                    839 ;	tmk_core/protocol/report.c:258: if ((code >> 3) < KEYBOARD_REPORT_BITS) {
      007314 90 08 27         [24]  840 	mov	dptr,#_add_key_bit_PARM_2
      007317 E0               [24]  841 	movx	a,@dptr
      007318 FD               [12]  842 	mov	r5,a
      007319 12 5B FC         [24]  843 	lcall	_ak820_outline_0190
      00731C FC               [12]  844 	mov	r4,a
      00731D BC 1E 00         [24]  845 	cjne	r4,#0x1e,00112$
      007320                        846 00112$:
      007320 50 16            [24]  847 	jnc	00103$
                                    848 ;	tmk_core/protocol/report.c:259: keyboard_report->nkro.bits[code >> 3] |= 1 << (code & 7);
      007322 12 74 2E         [24]  849 	lcall	_ak820_outline_0035
      007325 80 02            [24]  850 	sjmp	00115$
      007327                        851 00114$:
      007327 25 E0            [12]  852 	add	a,acc
      007329                        853 00115$:
      007329 D5 F0 FB         [24]  854 	djnz	b,00114$
      00732C FF               [12]  855 	mov	r7,a
      00732D 12 45 C3         [24]  856 	lcall	_ak820_outline_0186
      007330 E0               [24]  857 	movx	a,@dptr
      007331 42 07            [12]  858 	orl	ar7,a
      007333 12 45 C3         [24]  859 	lcall	_ak820_outline_0186
      007336 EF               [12]  860 	mov	a,r7
      007337 F0               [24]  861 	movx	@dptr,a
      007338                        862 00103$:
                                    863 ;	tmk_core/protocol/report.c:263: }
      007338 22               [24]  864 	ret
                                    865 ;------------------------------------------------------------
                                    866 ;Allocation info for local variables in function 'del_key_bit'
                                    867 ;------------------------------------------------------------
                                    868 ;code          Allocated with name '_del_key_bit_PARM_2'
                                    869 ;report_arg    Allocated with name '_del_key_bit_report_arg_10000_168'
                                    870 ;keyboard_report Allocated with name '_del_key_bit_keyboard_report_10000_169'
                                    871 ;------------------------------------------------------------
                                    872 ;	tmk_core/protocol/report.c:269: void del_key_bit(report_keyboard_t* report_arg, uint8_t code) {
                                    873 ;	-----------------------------------------
                                    874 ;	 function del_key_bit
                                    875 ;	-----------------------------------------
      007339                        876 _del_key_bit:
      007339 12 45 55         [24]  877 	lcall	_ak820_outline_0036
      00733C 90 08 2C         [24]  878 	mov	dptr,#_del_key_bit_report_arg_10000_168
      00733F 12 3A 5F         [24]  879 	lcall	_ak820_outline_0016
                                    880 ;	tmk_core/protocol/report.c:270: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      007342 90 08 2C         [24]  881 	mov	dptr,#_del_key_bit_report_arg_10000_168
      007345 12 3A 81         [24]  882 	lcall	_ak820_outline_0052
                                    883 ;	tmk_core/protocol/report.c:271: if ((code >> 3) < KEYBOARD_REPORT_BITS) {
      007348 90 08 2B         [24]  884 	mov	dptr,#_del_key_bit_PARM_2
      00734B E0               [24]  885 	movx	a,@dptr
      00734C FD               [12]  886 	mov	r5,a
      00734D 12 5B FC         [24]  887 	lcall	_ak820_outline_0190
      007350 FC               [12]  888 	mov	r4,a
      007351 BC 1E 00         [24]  889 	cjne	r4,#0x1e,00112$
      007354                        890 00112$:
      007354 50 17            [24]  891 	jnc	00103$
                                    892 ;	tmk_core/protocol/report.c:272: keyboard_report->nkro.bits[code >> 3] &= ~(1 << (code & 7));
      007356 12 74 2E         [24]  893 	lcall	_ak820_outline_0035
      007359 80 02            [24]  894 	sjmp	00115$
      00735B                        895 00114$:
      00735B 25 E0            [12]  896 	add	a,acc
      00735D                        897 00115$:
      00735D D5 F0 FB         [24]  898 	djnz	b,00114$
      007360 F4               [12]  899 	cpl	a
      007361 FF               [12]  900 	mov	r7,a
      007362 12 45 C3         [24]  901 	lcall	_ak820_outline_0186
      007365 E0               [24]  902 	movx	a,@dptr
      007366 52 07            [12]  903 	anl	ar7,a
      007368 12 45 C3         [24]  904 	lcall	_ak820_outline_0186
      00736B EF               [12]  905 	mov	a,r7
      00736C F0               [24]  906 	movx	@dptr,a
      00736D                        907 00103$:
                                    908 ;	tmk_core/protocol/report.c:276: }
      00736D 22               [24]  909 	ret
                                    910 ;------------------------------------------------------------
                                    911 ;Allocation info for local variables in function 'add_key_to_report'
                                    912 ;------------------------------------------------------------
                                    913 ;key           Allocated with name '_add_key_to_report_PARM_2'
                                    914 ;report_arg    Allocated with name '_add_key_to_report_report_arg_10000_173'
                                    915 ;keyboard_report Allocated with name '_add_key_to_report_keyboard_report_10000_174'
                                    916 ;------------------------------------------------------------
                                    917 ;	tmk_core/protocol/report.c:283: void add_key_to_report(report_keyboard_t* report_arg, uint8_t key) {
                                    918 ;	-----------------------------------------
                                    919 ;	 function add_key_to_report
                                    920 ;	-----------------------------------------
      00736E                        921 _add_key_to_report:
      00736E 12 45 55         [24]  922 	lcall	_ak820_outline_0036
      007371 90 08 30         [24]  923 	mov	dptr,#_add_key_to_report_report_arg_10000_173
      007374 12 3A 5F         [24]  924 	lcall	_ak820_outline_0016
                                    925 ;	tmk_core/protocol/report.c:284: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      007377 90 08 30         [24]  926 	mov	dptr,#_add_key_to_report_report_arg_10000_173
      00737A 12 3A 81         [24]  927 	lcall	_ak820_outline_0052
                                    928 ;	tmk_core/protocol/report.c:286: if (keyboard_protocol && keymap_config.nkro) {
      00737D 90 0D E8         [24]  929 	mov	dptr,#_keyboard_protocol
      007380 E0               [24]  930 	movx	a,@dptr
      007381 60 18            [24]  931 	jz	00102$
      007383 90 0A F3         [24]  932 	mov	dptr,#_keymap_config
      007386 E0               [24]  933 	movx	a,@dptr
      007387 30 E7 11         [24]  934 	jnb	acc.7,00102$
                                    935 ;	tmk_core/protocol/report.c:287: add_key_bit(keyboard_report, key);
      00738A 12 74 67         [24]  936 	lcall	_ak820_outline_0156
      00738D 90 08 2F         [24]  937 	mov	dptr,#_add_key_to_report_PARM_2
      007390 E0               [24]  938 	movx	a,@dptr
      007391 90 08 27         [24]  939 	mov	dptr,#_add_key_bit_PARM_2
      007394 12 74 4C         [24]  940 	lcall	_ak820_outline_0103
      007397 8D F0            [24]  941 	mov	b, r5
                                    942 ;	tmk_core/protocol/report.c:288: return;
      007399 61 05            [12]  943 	ajmp	_add_key_bit
      00739B                        944 00102$:
                                    945 ;	tmk_core/protocol/report.c:291: add_key_byte(keyboard_report, key);
      00739B 7D 00            [12]  946 	mov	r5,#0x00
      00739D 90 08 2F         [24]  947 	mov	dptr,#_add_key_to_report_PARM_2
      0073A0 E0               [24]  948 	movx	a,@dptr
      0073A1 90 08 1E         [24]  949 	mov	dptr,#_add_key_byte_PARM_2
      0073A4 F0               [24]  950 	movx	@dptr,a
      0073A5 12 74 45         [24]  951 	lcall	_ak820_outline_0050
                                    952 ;	tmk_core/protocol/report.c:292: }
      0073A8 41 6A            [12]  953 	ajmp	_add_key_byte
                                    954 ;------------------------------------------------------------
                                    955 ;Allocation info for local variables in function 'del_key_from_report'
                                    956 ;------------------------------------------------------------
                                    957 ;key           Allocated with name '_del_key_from_report_PARM_2'
                                    958 ;report_arg    Allocated with name '_del_key_from_report_report_arg_10000_177'
                                    959 ;keyboard_report Allocated with name '_del_key_from_report_keyboard_report_10000_178'
                                    960 ;------------------------------------------------------------
                                    961 ;	tmk_core/protocol/report.c:298: void del_key_from_report(report_keyboard_t* report_arg, uint8_t key) {
                                    962 ;	-----------------------------------------
                                    963 ;	 function del_key_from_report
                                    964 ;	-----------------------------------------
      0073AA                        965 _del_key_from_report:
      0073AA 12 45 55         [24]  966 	lcall	_ak820_outline_0036
      0073AD 90 08 34         [24]  967 	mov	dptr,#_del_key_from_report_report_arg_10000_177
      0073B0 12 3A 5F         [24]  968 	lcall	_ak820_outline_0016
                                    969 ;	tmk_core/protocol/report.c:299: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      0073B3 90 08 34         [24]  970 	mov	dptr,#_del_key_from_report_report_arg_10000_177
      0073B6 12 3A 81         [24]  971 	lcall	_ak820_outline_0052
                                    972 ;	tmk_core/protocol/report.c:301: if (keyboard_protocol && keymap_config.nkro) {
      0073B9 90 0D E8         [24]  973 	mov	dptr,#_keyboard_protocol
      0073BC E0               [24]  974 	movx	a,@dptr
      0073BD 60 18            [24]  975 	jz	00102$
      0073BF 90 0A F3         [24]  976 	mov	dptr,#_keymap_config
      0073C2 E0               [24]  977 	movx	a,@dptr
      0073C3 30 E7 11         [24]  978 	jnb	acc.7,00102$
                                    979 ;	tmk_core/protocol/report.c:302: del_key_bit(keyboard_report, key);
      0073C6 12 74 67         [24]  980 	lcall	_ak820_outline_0156
      0073C9 90 08 33         [24]  981 	mov	dptr,#_del_key_from_report_PARM_2
      0073CC E0               [24]  982 	movx	a,@dptr
      0073CD 90 08 2B         [24]  983 	mov	dptr,#_del_key_bit_PARM_2
      0073D0 12 74 4C         [24]  984 	lcall	_ak820_outline_0103
      0073D3 8D F0            [24]  985 	mov	b, r5
                                    986 ;	tmk_core/protocol/report.c:303: return;
      0073D5 61 39            [24]  987 	ajmp	_del_key_bit
      0073D7                        988 00102$:
                                    989 ;	tmk_core/protocol/report.c:306: del_key_byte(keyboard_report, key);
      0073D7 7D 00            [12]  990 	mov	r5,#0x00
      0073D9 90 08 33         [24]  991 	mov	dptr,#_del_key_from_report_PARM_2
      0073DC E0               [24]  992 	movx	a,@dptr
      0073DD 90 08 23         [24]  993 	mov	dptr,#_del_key_byte_PARM_2
      0073E0 F0               [24]  994 	movx	@dptr,a
      0073E1 12 74 45         [24]  995 	lcall	_ak820_outline_0050
                                    996 ;	tmk_core/protocol/report.c:307: }
      0073E4 41 D3            [12]  997 	ajmp	_del_key_byte
                                    998 ;------------------------------------------------------------
                                    999 ;Allocation info for local variables in function 'clear_keys_from_report'
                                   1000 ;------------------------------------------------------------
                                   1001 ;report_arg    Allocated with name '_clear_keys_from_report_report_arg_10000_181'
                                   1002 ;keyboard_report Allocated with name '_clear_keys_from_report_keyboard_report_10000_182'
                                   1003 ;------------------------------------------------------------
                                   1004 ;	tmk_core/protocol/report.c:313: void clear_keys_from_report(report_keyboard_t* report_arg) {
                                   1005 ;	-----------------------------------------
                                   1006 ;	 function clear_keys_from_report
                                   1007 ;	-----------------------------------------
      0073E6                       1008 _clear_keys_from_report:
      0073E6 12 45 55         [24] 1009 	lcall	_ak820_outline_0036
      0073E9 90 08 37         [24] 1010 	mov	dptr,#_clear_keys_from_report_report_arg_10000_181
      0073EC 12 3A 5F         [24] 1011 	lcall	_ak820_outline_0016
                                   1012 ;	tmk_core/protocol/report.c:314: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      0073EF 90 08 37         [24] 1013 	mov	dptr,#_clear_keys_from_report_report_arg_10000_181
      0073F2 12 3A 81         [24] 1014 	lcall	_ak820_outline_0052
                                   1015 ;	tmk_core/protocol/report.c:317: if (keyboard_protocol && keymap_config.nkro) {
      0073F5 90 0D E8         [24] 1016 	mov	dptr,#_keyboard_protocol
      0073F8 E0               [24] 1017 	movx	a,@dptr
      0073F9 60 1E            [24] 1018 	jz	00102$
      0073FB 90 0A F3         [24] 1019 	mov	dptr,#_keymap_config
      0073FE E0               [24] 1020 	movx	a,@dptr
      0073FF 30 E7 17         [24] 1021 	jnb	acc.7,00102$
                                   1022 ;	tmk_core/protocol/report.c:318: memset(keyboard_report->nkro.bits, 0, sizeof(keyboard_report->nkro.bits));
      007402 74 02            [12] 1023 	mov	a,#0x02
      007404 12 45 B2         [24] 1024 	lcall	_ak820_outline_0166
      007407 7B 00            [12] 1025 	mov	r3,#0x00
      007409 12 74 6E         [24] 1026 	lcall	_ak820_outline_0182
      00740C 74 1E            [12] 1027 	mov	a,#0x1e
      00740E F0               [24] 1028 	movx	@dptr,a
      00740F E4               [12] 1029 	clr	a
      007410 A3               [24] 1030 	inc	dptr
      007411 12 3A B6         [24] 1031 	lcall	_ak820_outline_0101
      007414 8B F0            [24] 1032 	mov	b, r3
                                   1033 ;	tmk_core/protocol/report.c:319: return;
      007416 02 BD 8C         [24] 1034 	ljmp	_memset
      007419                       1035 00102$:
                                   1036 ;	tmk_core/protocol/report.c:322: memset(keyboard_report->keys, 0, sizeof(keyboard_report->keys));
      007419 74 02            [12] 1037 	mov	a,#0x02
      00741B 12 45 9C         [24] 1038 	lcall	_ak820_outline_0139
      00741E 7D 00            [12] 1039 	mov	r5,#0x00
      007420 12 74 6E         [24] 1040 	lcall	_ak820_outline_0182
      007423 74 06            [12] 1041 	mov	a,#0x06
      007425 12 3A E1         [24] 1042 	lcall	_ak820_outline_0137
      007428 12 74 45         [24] 1043 	lcall	_ak820_outline_0050
                                   1044 ;	tmk_core/protocol/report.c:323: }
      00742B 02 BD 8C         [24] 1045 	ljmp	_memset
                                   1046 ;------------------------------------------------------------
                                   1047 ;Allocation info for local variables in function 'has_mouse_report_changed'
                                   1048 ;------------------------------------------------------------
                                   1049 ;old_report    Allocated with name '_has_mouse_report_changed_PARM_2'
                                   1050 ;new_report    Allocated with name '_has_mouse_report_changed_new_report_10000_185'
                                   1051 ;changed       Allocated with name '_has_mouse_report_changed_changed_10000_186'
                                   1052 ;sloc0         Allocated with name '_has_mouse_report_changed_sloc0_1_0'
                                   1053 ;sloc1         Allocated with name '_has_mouse_report_changed_sloc1_1_0'
                                   1054 ;------------------------------------------------------------
                                   1055 ;	tmk_core/protocol/report.c:334: __attribute__((weak)) bool has_mouse_report_changed(report_mouse_t* new_report, report_mouse_t* old_report) {
                                   1056 ;	-----------------------------------------
                                   1057 	.area CSEG    (CODE)
                                   1058 	.area CONST   (CODE)
                                   1059 	.area CONST   (CODE)
      00BE9B                       1060 _KEYCODE2CONSUMER_usages_10000_119:
      00BE9B E2 00                 1061 	.byte #0xe2, #0x00	; 226
      00BE9D E9 00                 1062 	.byte #0xe9, #0x00	; 233
      00BE9F EA 00                 1063 	.byte #0xea, #0x00	; 234
      00BEA1 B5 00                 1064 	.byte #0xb5, #0x00	; 181
      00BEA3 B6 00                 1065 	.byte #0xb6, #0x00	; 182
      00BEA5 B7 00                 1066 	.byte #0xb7, #0x00	; 183
      00BEA7 CD 00                 1067 	.byte #0xcd, #0x00	; 205
      00BEA9 83 01                 1068 	.byte #0x83, #0x01	; 387
      00BEAB CC 00                 1069 	.byte #0xcc, #0x00	; 204
      00BEAD 8A 01                 1070 	.byte #0x8a, #0x01	; 394
      00BEAF 92 01                 1071 	.byte #0x92, #0x01	; 402
      00BEB1 94 01                 1072 	.byte #0x94, #0x01	; 404
      00BEB3 21 02                 1073 	.byte #0x21, #0x02	; 545
      00BEB5 23 02                 1074 	.byte #0x23, #0x02	; 547
      00BEB7 24 02                 1075 	.byte #0x24, #0x02	; 548
      00BEB9 25 02                 1076 	.byte #0x25, #0x02	; 549
      00BEBB 26 02                 1077 	.byte #0x26, #0x02	; 550
      00BEBD 27 02                 1078 	.byte #0x27, #0x02	; 551
      00BEBF 2A 02                 1079 	.byte #0x2a, #0x02	; 554
      00BEC1 B3 00                 1080 	.byte #0xb3, #0x00	; 179
      00BEC3 B4 00                 1081 	.byte #0xb4, #0x00	; 180
      00BEC5 6F 00                 1082 	.byte #0x6f, #0x00	; 111
      00BEC7 70 00                 1083 	.byte #0x70, #0x00	; 112
      00BEC9 9F 01                 1084 	.byte #0x9f, #0x01	; 415
      00BECB CB 01                 1085 	.byte #0xcb, #0x01	; 459
      00BECD 9F 02                 1086 	.byte #0x9f, #0x02	; 671
      00BECF A0 02                 1087 	.byte #0xa0, #0x02	; 672
                                   1088 	.area CSEG    (CODE)
                                   1089 	.area XINIT   (CODE)
                                   1090 	.area CABS    (ABS,CODE)
                                   1091 
                                   1092 ; Experimental exact instruction outlining.
                                   1093 	.globl _ak820_outline_0016
                                   1094 	.globl _ak820_outline_0035
                                   1095 	.globl _ak820_outline_0036
                                   1096 	.globl _ak820_outline_0050
                                   1097 	.globl _ak820_outline_0052
                                   1098 	.globl _ak820_outline_0065
                                   1099 	.globl _ak820_outline_0101
                                   1100 	.globl _ak820_outline_0103
                                   1101 	.globl _ak820_outline_0111
                                   1102 	.globl _ak820_outline_0125
                                   1103 	.globl _ak820_outline_0131
                                   1104 	.globl _ak820_outline_0137
                                   1105 	.globl _ak820_outline_0139
                                   1106 	.globl _ak820_outline_0149
                                   1107 	.globl _ak820_outline_0156
                                   1108 	.globl _ak820_outline_0166
                                   1109 	.globl _ak820_outline_0182
                                   1110 	.globl _ak820_outline_0186
                                   1111 	.globl _ak820_outline_0190
                                   1112 
                                   1113 	.area CSEG (CODE)
                                   1114 ; function ak820_outline_0035
      00742E                       1115 _ak820_outline_0035:
      00742E 74 02            [12] 1116 	mov	a,#0x02
      007430 2E               [12] 1117 	add	a,r6
      007431 FE               [12] 1118 	mov	r6,a
      007432 E4               [12] 1119 	clr	a
      007433 3F               [12] 1120 	addc	a,r7
      007434 FF               [12] 1121 	mov	r7,a
      007435 EC               [12] 1122 	mov	a,r4
      007436 2E               [12] 1123 	add	a,r6
      007437 FC               [12] 1124 	mov	r4,a
      007438 E4               [12] 1125 	clr	a
      007439 3F               [12] 1126 	addc	a,r7
      00743A FB               [12] 1127 	mov	r3,a
      00743B 74 07            [12] 1128 	mov	a,#0x07
      00743D 5D               [12] 1129 	anl	a,r5
      00743E F5 F0            [12] 1130 	mov	b,a
      007440 05 F0            [12] 1131 	inc	b
      007442 74 01            [12] 1132 	mov	a,#0x01
      007444 22               [24] 1133 	ret
                                   1134 
                                   1135 	.area CSEG (CODE)
                                   1136 ; function ak820_outline_0050
      007445                       1137 _ak820_outline_0050:
      007445 8E 82            [24] 1138 	mov	dpl,r6
      007447 8F 83            [24] 1139 	mov	dph,r7
      007449 8D F0            [24] 1140 	mov	b,r5
      00744B 22               [24] 1141 	ret
                                   1142 
                                   1143 	.area CSEG (CODE)
                                   1144 ; function ak820_outline_0103
      00744C                       1145 _ak820_outline_0103:
      00744C F0               [24] 1146 	movx	@dptr,a
      00744D 8B 82            [24] 1147 	mov	dpl,r3
      00744F 8C 83            [24] 1148 	mov	dph,r4
      007451 22               [24] 1149 	ret
                                   1150 
                                   1151 	.area CSEG (CODE)
                                   1152 ; function ak820_outline_0131
      007452                       1153 _ak820_outline_0131:
      007452 F4               [12] 1154 	cpl	a
      007453 24 01            [12] 1155 	add	a,#0x01
      007455 C5 F0            [12] 1156 	xch	a,b
      007457 F4               [12] 1157 	cpl	a
      007458 34 00            [12] 1158 	addc	a,#0x00
      00745A C5 F0            [12] 1159 	xch	a,b
      00745C 22               [24] 1160 	ret
                                   1161 
                                   1162 	.area CSEG (CODE)
                                   1163 ; function ak820_outline_0149
      00745D                       1164 _ak820_outline_0149:
      00745D 74 02            [12] 1165 	mov	a,#0x02
      00745F 2E               [12] 1166 	add	a,r6
      007460 FB               [12] 1167 	mov	r3,a
      007461 E4               [12] 1168 	clr	a
      007462 3F               [12] 1169 	addc	a,r7
      007463 FC               [12] 1170 	mov	r4,a
      007464 ED               [12] 1171 	mov	a,r5
      007465 2B               [12] 1172 	add	a,r3
      007466 22               [24] 1173 	ret
                                   1174 
                                   1175 	.area CSEG (CODE)
                                   1176 ; function ak820_outline_0156
      007467                       1177 _ak820_outline_0156:
      007467 8E 03            [24] 1178 	mov	ar3,r6
      007469 8F 04            [24] 1179 	mov	ar4,r7
      00746B 7D 00            [12] 1180 	mov	r5,#0x00
      00746D 22               [24] 1181 	ret
                                   1182 
                                   1183 	.area CSEG (CODE)
                                   1184 ; function ak820_outline_0182
      00746E                       1185 _ak820_outline_0182:
      00746E 90 0D DD         [24] 1186 	mov	dptr,#_memset_PARM_2
      007471 E4               [12] 1187 	clr	a
      007472 F0               [24] 1188 	movx	@dptr,a
      007473 90 0D DE         [24] 1189 	mov	dptr,#_memset_PARM_3
      007476 22               [24] 1190 	ret
