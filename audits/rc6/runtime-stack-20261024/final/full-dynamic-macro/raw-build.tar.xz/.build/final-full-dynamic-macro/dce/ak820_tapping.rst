                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_tapping
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _get_repeat_key_count
                                     12 	.globl _del_owned_mods
                                     13 	.globl _add_owned_mods
                                     14 	.globl _send_keyboard_report
                                     15 	.globl _layer_hold_off
                                     16 	.globl _layer_hold_on
                                     17 	.globl _unregister_mods
                                     18 	.globl _register_mods
                                     19 	.globl _process_record
                                     20 	.globl _ADC_START
                                     21 	.globl _S0_R_FIFO
                                     22 	.globl _S0_T_FIFO
                                     23 	.globl _S0_FREE
                                     24 	.globl _S0_IF_BYTE
                                     25 	.globl _S0_IF_FIRST
                                     26 	.globl _S0_IF_OV
                                     27 	.globl _S0_FST_ACT
                                     28 	.globl _CP_RL2
                                     29 	.globl _C_T2
                                     30 	.globl _TR2
                                     31 	.globl _EXEN2
                                     32 	.globl _TCLK
                                     33 	.globl _RCLK
                                     34 	.globl _EXF2
                                     35 	.globl _CAP1F
                                     36 	.globl _TF2
                                     37 	.globl _RI
                                     38 	.globl _TI
                                     39 	.globl _RB8
                                     40 	.globl _TB8
                                     41 	.globl _REN
                                     42 	.globl _SM2
                                     43 	.globl _SM1
                                     44 	.globl _SM0
                                     45 	.globl _IT0
                                     46 	.globl _IE0
                                     47 	.globl _IT1
                                     48 	.globl _IE1
                                     49 	.globl _TR0
                                     50 	.globl _TF0
                                     51 	.globl _TR1
                                     52 	.globl _TF1
                                     53 	.globl _P4_0
                                     54 	.globl _P4_1
                                     55 	.globl _P4_2
                                     56 	.globl _P4_3
                                     57 	.globl _P4_4
                                     58 	.globl _P4_5
                                     59 	.globl _P4_6
                                     60 	.globl _RXD
                                     61 	.globl _TXD
                                     62 	.globl _INT0
                                     63 	.globl _INT1
                                     64 	.globl _T0
                                     65 	.globl _T1
                                     66 	.globl _MOSI1
                                     67 	.globl _MISO1
                                     68 	.globl _SCK1
                                     69 	.globl _P3_0
                                     70 	.globl _P3_1
                                     71 	.globl _P3_2
                                     72 	.globl _P3_3
                                     73 	.globl _P3_4
                                     74 	.globl _P3_5
                                     75 	.globl _P3_6
                                     76 	.globl _P3_7
                                     77 	.globl _CAP1_
                                     78 	.globl _T2_
                                     79 	.globl _CAP2_
                                     80 	.globl _T2EX_
                                     81 	.globl _RXD1
                                     82 	.globl _TXD1
                                     83 	.globl _P2_0
                                     84 	.globl _P2_1
                                     85 	.globl _P2_2
                                     86 	.globl _P2_3
                                     87 	.globl _P2_4
                                     88 	.globl _P2_5
                                     89 	.globl _P2_6
                                     90 	.globl _P2_7
                                     91 	.globl _AIN0
                                     92 	.globl _AIN1
                                     93 	.globl _AIN2
                                     94 	.globl _AIN3
                                     95 	.globl _AIN4
                                     96 	.globl _AIN5
                                     97 	.globl _AIN6
                                     98 	.globl _AIN7
                                     99 	.globl _CAP1
                                    100 	.globl _T2
                                    101 	.globl _CAP2
                                    102 	.globl _T2EX
                                    103 	.globl _INT0_
                                    104 	.globl _SCS
                                    105 	.globl _MOSI
                                    106 	.globl _MISO
                                    107 	.globl _SCK
                                    108 	.globl _RXD1_
                                    109 	.globl _TXD1_
                                    110 	.globl _P1_0
                                    111 	.globl _P1_1
                                    112 	.globl _P1_2
                                    113 	.globl _P1_3
                                    114 	.globl _P1_4
                                    115 	.globl _P1_5
                                    116 	.globl _P1_6
                                    117 	.globl _P1_7
                                    118 	.globl _AIN8
                                    119 	.globl _AIN9
                                    120 	.globl _AIN10
                                    121 	.globl _AIN11
                                    122 	.globl _AIN12
                                    123 	.globl _AIN13
                                    124 	.globl _RXD_
                                    125 	.globl _TXD_
                                    126 	.globl _SCL0
                                    127 	.globl _SDA0
                                    128 	.globl _P0_0
                                    129 	.globl _P0_1
                                    130 	.globl _P0_2
                                    131 	.globl _P0_3
                                    132 	.globl _P0_4
                                    133 	.globl _P0_5
                                    134 	.globl _P0_6
                                    135 	.globl _P0_7
                                    136 	.globl _IE_SPI0
                                    137 	.globl _IE_USB
                                    138 	.globl _IE_ADC
                                    139 	.globl _IE_UART1
                                    140 	.globl _IE_PWM_I2C
                                    141 	.globl _IE_GPIO
                                    142 	.globl _IE_WDOG
                                    143 	.globl _PX0
                                    144 	.globl _PT0
                                    145 	.globl _PX1
                                    146 	.globl _PT1
                                    147 	.globl _PS
                                    148 	.globl _PT2
                                    149 	.globl _PL_FLAG
                                    150 	.globl _PH_FLAG
                                    151 	.globl _EX0
                                    152 	.globl _ET0
                                    153 	.globl _EX1
                                    154 	.globl _ET1
                                    155 	.globl _ES
                                    156 	.globl _ET2
                                    157 	.globl _E_DIS
                                    158 	.globl _EA
                                    159 	.globl _P
                                    160 	.globl _F1
                                    161 	.globl _OV
                                    162 	.globl _RS0
                                    163 	.globl _RS1
                                    164 	.globl _F0
                                    165 	.globl _AC
                                    166 	.globl _CY
                                    167 	.globl _I2CS_INT_ST
                                    168 	.globl _I2CX_INT
                                    169 	.globl _LED_STATUS
                                    170 	.globl _LED_DMA_H
                                    171 	.globl _LED_DMA_L
                                    172 	.globl _LED_DMA
                                    173 	.globl _LED_PWM_OE
                                    174 	.globl _LED_COMMON
                                    175 	.globl _ADC_CHAN
                                    176 	.globl _ADC_DAT_H
                                    177 	.globl _ADC_DAT_L
                                    178 	.globl _ADC_DAT
                                    179 	.globl _ADC_CTRL
                                    180 	.globl _SPI1_CK_SE
                                    181 	.globl _SPI1_CTRL
                                    182 	.globl _SPI1_DATA
                                    183 	.globl _SPI1_STAT
                                    184 	.globl _SIF1
                                    185 	.globl _SBAUD1
                                    186 	.globl _SBUF1
                                    187 	.globl _SCON1
                                    188 	.globl _SPI0_SETUP
                                    189 	.globl _SPI0_CK_SE
                                    190 	.globl _SPI0_CTRL
                                    191 	.globl _SPI0_DATA
                                    192 	.globl _SPI0_STAT
                                    193 	.globl _T2CAP1H
                                    194 	.globl _T2CAP1L
                                    195 	.globl _T2CAP1
                                    196 	.globl _TH2
                                    197 	.globl _TL2
                                    198 	.globl _T2COUNT
                                    199 	.globl _RCAP2H
                                    200 	.globl _RCAP2L
                                    201 	.globl _RCAP2
                                    202 	.globl _T2MOD
                                    203 	.globl _T2CON
                                    204 	.globl _SBUF
                                    205 	.globl _SCON
                                    206 	.globl _TH1
                                    207 	.globl _TH0
                                    208 	.globl _TL1
                                    209 	.globl _TL0
                                    210 	.globl _TMOD
                                    211 	.globl _TCON
                                    212 	.globl _XBUS_AUX
                                    213 	.globl _P7
                                    214 	.globl _P6_DIR
                                    215 	.globl _P6_OUT_PU
                                    216 	.globl _P6_IN
                                    217 	.globl _P5_DIR
                                    218 	.globl _P5_OUT_PU
                                    219 	.globl _P5_IN
                                    220 	.globl _P4_LED_KEY
                                    221 	.globl _P4_DIR_PU
                                    222 	.globl _P4_MOD_OC
                                    223 	.globl _P4
                                    224 	.globl _P3_DIR_PU
                                    225 	.globl _P3_MOD_OC
                                    226 	.globl _P3
                                    227 	.globl _P2_DIR_PU
                                    228 	.globl _P2_MOD_OC
                                    229 	.globl _P2
                                    230 	.globl _P1_DIR_PU
                                    231 	.globl _P1_MOD_OC
                                    232 	.globl _P1
                                    233 	.globl _P0_DIR_PU
                                    234 	.globl _P0_MOD_OC
                                    235 	.globl _P0
                                    236 	.globl _ROM_CTRL
                                    237 	.globl _ROM_DATA_HH
                                    238 	.globl _ROM_DATA_HL
                                    239 	.globl _ROM_DATA_HI
                                    240 	.globl _ROM_ADDR_H
                                    241 	.globl _ROM_ADDR_L
                                    242 	.globl _ROM_ADDR
                                    243 	.globl _GPIO_IE
                                    244 	.globl _IP_EX
                                    245 	.globl _IE_EX
                                    246 	.globl _IP
                                    247 	.globl _IE
                                    248 	.globl _WDOG_COUNT
                                    249 	.globl _RESET_KEEP
                                    250 	.globl _WAKE_CTRL
                                    251 	.globl _CLOCK_CFG
                                    252 	.globl _POWER_CFG
                                    253 	.globl _PCON
                                    254 	.globl _GLOBAL_CFG
                                    255 	.globl _SAFE_MOD
                                    256 	.globl _DPH
                                    257 	.globl _DPL
                                    258 	.globl _SP
                                    259 	.globl _A_INV
                                    260 	.globl _B
                                    261 	.globl _ACC
                                    262 	.globl _PSW
                                    263 	.globl _ak820_oneshot_target
                                    264 	.globl _ak820_oneshot_process_PARM_3
                                    265 	.globl _ak820_oneshot_process_PARM_2
                                    266 	.globl _ak820_oneshot_consumed
                                    267 	.globl _ak820_oneshot_mods
                                    268 	.globl _ak820_tapping_source_PARM_1
                                    269 	.globl _ak820_tapping_source
                                    270 	.globl _ak820_tapping_before
                                    271 	.globl _ak820_tapping_process
                                    272 	.globl _ak820_tapping_cancel
                                    273 	.globl _ak820_oneshot_process
                                    274 ;--------------------------------------------------------
                                    275 ; special function registers
                                    276 ;--------------------------------------------------------
                                    277 	.area RSEG    (ABS,DATA)
      000000                        278 	.org 0x0000
                           0000D0   279 _PSW	=	0x00d0
                           0000E0   280 _ACC	=	0x00e0
                           0000F0   281 _B	=	0x00f0
                           0000FD   282 _A_INV	=	0x00fd
                           000081   283 _SP	=	0x0081
                           000082   284 _DPL	=	0x0082
                           000083   285 _DPH	=	0x0083
                           0000A1   286 _SAFE_MOD	=	0x00a1
                           0000B1   287 _GLOBAL_CFG	=	0x00b1
                           000087   288 _PCON	=	0x0087
                           0000BA   289 _POWER_CFG	=	0x00ba
                           0000B9   290 _CLOCK_CFG	=	0x00b9
                           0000A9   291 _WAKE_CTRL	=	0x00a9
                           0000FE   292 _RESET_KEEP	=	0x00fe
                           0000FF   293 _WDOG_COUNT	=	0x00ff
                           0000A8   294 _IE	=	0x00a8
                           0000B8   295 _IP	=	0x00b8
                           0000E8   296 _IE_EX	=	0x00e8
                           0000E9   297 _IP_EX	=	0x00e9
                           0000B2   298 _GPIO_IE	=	0x00b2
                           008584   299 _ROM_ADDR	=	0x8584
                           000084   300 _ROM_ADDR_L	=	0x0084
                           000085   301 _ROM_ADDR_H	=	0x0085
                           008F8E   302 _ROM_DATA_HI	=	0x8f8e
                           00008E   303 _ROM_DATA_HL	=	0x008e
                           00008F   304 _ROM_DATA_HH	=	0x008f
                           000086   305 _ROM_CTRL	=	0x0086
                           000080   306 _P0	=	0x0080
                           0000C4   307 _P0_MOD_OC	=	0x00c4
                           0000C5   308 _P0_DIR_PU	=	0x00c5
                           000090   309 _P1	=	0x0090
                           000092   310 _P1_MOD_OC	=	0x0092
                           000093   311 _P1_DIR_PU	=	0x0093
                           0000A0   312 _P2	=	0x00a0
                           000094   313 _P2_MOD_OC	=	0x0094
                           000095   314 _P2_DIR_PU	=	0x0095
                           0000B0   315 _P3	=	0x00b0
                           000096   316 _P3_MOD_OC	=	0x0096
                           000097   317 _P3_DIR_PU	=	0x0097
                           0000C0   318 _P4	=	0x00c0
                           0000C2   319 _P4_MOD_OC	=	0x00c2
                           0000C3   320 _P4_DIR_PU	=	0x00c3
                           0000C1   321 _P4_LED_KEY	=	0x00c1
                           0000AA   322 _P5_IN	=	0x00aa
                           0000AB   323 _P5_OUT_PU	=	0x00ab
                           0000AC   324 _P5_DIR	=	0x00ac
                           0000AD   325 _P6_IN	=	0x00ad
                           0000AE   326 _P6_OUT_PU	=	0x00ae
                           0000AF   327 _P6_DIR	=	0x00af
                           0000F1   328 _P7	=	0x00f1
                           0000A2   329 _XBUS_AUX	=	0x00a2
                           000088   330 _TCON	=	0x0088
                           000089   331 _TMOD	=	0x0089
                           00008A   332 _TL0	=	0x008a
                           00008B   333 _TL1	=	0x008b
                           00008C   334 _TH0	=	0x008c
                           00008D   335 _TH1	=	0x008d
                           000098   336 _SCON	=	0x0098
                           000099   337 _SBUF	=	0x0099
                           0000C8   338 _T2CON	=	0x00c8
                           0000C9   339 _T2MOD	=	0x00c9
                           00CBCA   340 _RCAP2	=	0xcbca
                           0000CA   341 _RCAP2L	=	0x00ca
                           0000CB   342 _RCAP2H	=	0x00cb
                           00CDCC   343 _T2COUNT	=	0xcdcc
                           0000CC   344 _TL2	=	0x00cc
                           0000CD   345 _TH2	=	0x00cd
                           00CFCE   346 _T2CAP1	=	0xcfce
                           0000CE   347 _T2CAP1L	=	0x00ce
                           0000CF   348 _T2CAP1H	=	0x00cf
                           0000F8   349 _SPI0_STAT	=	0x00f8
                           0000F9   350 _SPI0_DATA	=	0x00f9
                           0000FA   351 _SPI0_CTRL	=	0x00fa
                           0000FB   352 _SPI0_CK_SE	=	0x00fb
                           0000FC   353 _SPI0_SETUP	=	0x00fc
                           0000BC   354 _SCON1	=	0x00bc
                           0000BD   355 _SBUF1	=	0x00bd
                           0000BE   356 _SBAUD1	=	0x00be
                           0000BF   357 _SIF1	=	0x00bf
                           0000B4   358 _SPI1_STAT	=	0x00b4
                           0000B5   359 _SPI1_DATA	=	0x00b5
                           0000B6   360 _SPI1_CTRL	=	0x00b6
                           0000B7   361 _SPI1_CK_SE	=	0x00b7
                           0000F3   362 _ADC_CTRL	=	0x00f3
                           00F5F4   363 _ADC_DAT	=	0xf5f4
                           0000F4   364 _ADC_DAT_L	=	0x00f4
                           0000F5   365 _ADC_DAT_H	=	0x00f5
                           0000F6   366 _ADC_CHAN	=	0x00f6
                           0000A6   367 _LED_COMMON	=	0x00a6
                           0000A7   368 _LED_PWM_OE	=	0x00a7
                           00C7C6   369 _LED_DMA	=	0xc7c6
                           0000C6   370 _LED_DMA_L	=	0x00c6
                           0000C7   371 _LED_DMA_H	=	0x00c7
                           0000F7   372 _LED_STATUS	=	0x00f7
                           0000B3   373 _I2CX_INT	=	0x00b3
                           0000BB   374 _I2CS_INT_ST	=	0x00bb
                                    375 ;--------------------------------------------------------
                                    376 ; special function bits
                                    377 ;--------------------------------------------------------
                                    378 	.area RSEG    (ABS,DATA)
      000000                        379 	.org 0x0000
                           0000D7   380 _CY	=	0x00d7
                           0000D6   381 _AC	=	0x00d6
                           0000D5   382 _F0	=	0x00d5
                           0000D4   383 _RS1	=	0x00d4
                           0000D3   384 _RS0	=	0x00d3
                           0000D2   385 _OV	=	0x00d2
                           0000D1   386 _F1	=	0x00d1
                           0000D0   387 _P	=	0x00d0
                           0000AF   388 _EA	=	0x00af
                           0000AE   389 _E_DIS	=	0x00ae
                           0000AD   390 _ET2	=	0x00ad
                           0000AC   391 _ES	=	0x00ac
                           0000AB   392 _ET1	=	0x00ab
                           0000AA   393 _EX1	=	0x00aa
                           0000A9   394 _ET0	=	0x00a9
                           0000A8   395 _EX0	=	0x00a8
                           0000BF   396 _PH_FLAG	=	0x00bf
                           0000BE   397 _PL_FLAG	=	0x00be
                           0000BD   398 _PT2	=	0x00bd
                           0000BC   399 _PS	=	0x00bc
                           0000BB   400 _PT1	=	0x00bb
                           0000BA   401 _PX1	=	0x00ba
                           0000B9   402 _PT0	=	0x00b9
                           0000B8   403 _PX0	=	0x00b8
                           0000EF   404 _IE_WDOG	=	0x00ef
                           0000EE   405 _IE_GPIO	=	0x00ee
                           0000ED   406 _IE_PWM_I2C	=	0x00ed
                           0000EC   407 _IE_UART1	=	0x00ec
                           0000EB   408 _IE_ADC	=	0x00eb
                           0000E9   409 _IE_USB	=	0x00e9
                           0000E8   410 _IE_SPI0	=	0x00e8
                           000087   411 _P0_7	=	0x0087
                           000086   412 _P0_6	=	0x0086
                           000085   413 _P0_5	=	0x0085
                           000084   414 _P0_4	=	0x0084
                           000083   415 _P0_3	=	0x0083
                           000082   416 _P0_2	=	0x0082
                           000081   417 _P0_1	=	0x0081
                           000080   418 _P0_0	=	0x0080
                           000081   419 _SDA0	=	0x0081
                           000080   420 _SCL0	=	0x0080
                           000083   421 _TXD_	=	0x0083
                           000082   422 _RXD_	=	0x0082
                           000085   423 _AIN13	=	0x0085
                           000084   424 _AIN12	=	0x0084
                           000083   425 _AIN11	=	0x0083
                           000082   426 _AIN10	=	0x0082
                           000081   427 _AIN9	=	0x0081
                           000080   428 _AIN8	=	0x0080
                           000097   429 _P1_7	=	0x0097
                           000096   430 _P1_6	=	0x0096
                           000095   431 _P1_5	=	0x0095
                           000094   432 _P1_4	=	0x0094
                           000093   433 _P1_3	=	0x0093
                           000092   434 _P1_2	=	0x0092
                           000091   435 _P1_1	=	0x0091
                           000090   436 _P1_0	=	0x0090
                           000097   437 _TXD1_	=	0x0097
                           000096   438 _RXD1_	=	0x0096
                           000097   439 _SCK	=	0x0097
                           000096   440 _MISO	=	0x0096
                           000095   441 _MOSI	=	0x0095
                           000094   442 _SCS	=	0x0094
                           000092   443 _INT0_	=	0x0092
                           000091   444 _T2EX	=	0x0091
                           000091   445 _CAP2	=	0x0091
                           000090   446 _T2	=	0x0090
                           000090   447 _CAP1	=	0x0090
                           000097   448 _AIN7	=	0x0097
                           000096   449 _AIN6	=	0x0096
                           000095   450 _AIN5	=	0x0095
                           000094   451 _AIN4	=	0x0094
                           000093   452 _AIN3	=	0x0093
                           000092   453 _AIN2	=	0x0092
                           000091   454 _AIN1	=	0x0091
                           000090   455 _AIN0	=	0x0090
                           0000A7   456 _P2_7	=	0x00a7
                           0000A6   457 _P2_6	=	0x00a6
                           0000A5   458 _P2_5	=	0x00a5
                           0000A4   459 _P2_4	=	0x00a4
                           0000A3   460 _P2_3	=	0x00a3
                           0000A2   461 _P2_2	=	0x00a2
                           0000A1   462 _P2_1	=	0x00a1
                           0000A0   463 _P2_0	=	0x00a0
                           0000A7   464 _TXD1	=	0x00a7
                           0000A6   465 _RXD1	=	0x00a6
                           0000A5   466 _T2EX_	=	0x00a5
                           0000A5   467 _CAP2_	=	0x00a5
                           0000A4   468 _T2_	=	0x00a4
                           0000A4   469 _CAP1_	=	0x00a4
                           0000B7   470 _P3_7	=	0x00b7
                           0000B6   471 _P3_6	=	0x00b6
                           0000B5   472 _P3_5	=	0x00b5
                           0000B4   473 _P3_4	=	0x00b4
                           0000B3   474 _P3_3	=	0x00b3
                           0000B2   475 _P3_2	=	0x00b2
                           0000B1   476 _P3_1	=	0x00b1
                           0000B0   477 _P3_0	=	0x00b0
                           0000B7   478 _SCK1	=	0x00b7
                           0000B6   479 _MISO1	=	0x00b6
                           0000B5   480 _MOSI1	=	0x00b5
                           0000B5   481 _T1	=	0x00b5
                           0000B4   482 _T0	=	0x00b4
                           0000B3   483 _INT1	=	0x00b3
                           0000B2   484 _INT0	=	0x00b2
                           0000B1   485 _TXD	=	0x00b1
                           0000B0   486 _RXD	=	0x00b0
                           0000C6   487 _P4_6	=	0x00c6
                           0000C5   488 _P4_5	=	0x00c5
                           0000C4   489 _P4_4	=	0x00c4
                           0000C3   490 _P4_3	=	0x00c3
                           0000C2   491 _P4_2	=	0x00c2
                           0000C1   492 _P4_1	=	0x00c1
                           0000C0   493 _P4_0	=	0x00c0
                           00008F   494 _TF1	=	0x008f
                           00008E   495 _TR1	=	0x008e
                           00008D   496 _TF0	=	0x008d
                           00008C   497 _TR0	=	0x008c
                           00008B   498 _IE1	=	0x008b
                           00008A   499 _IT1	=	0x008a
                           000089   500 _IE0	=	0x0089
                           000088   501 _IT0	=	0x0088
                           00009F   502 _SM0	=	0x009f
                           00009E   503 _SM1	=	0x009e
                           00009D   504 _SM2	=	0x009d
                           00009C   505 _REN	=	0x009c
                           00009B   506 _TB8	=	0x009b
                           00009A   507 _RB8	=	0x009a
                           000099   508 _TI	=	0x0099
                           000098   509 _RI	=	0x0098
                           0000CF   510 _TF2	=	0x00cf
                           0000CF   511 _CAP1F	=	0x00cf
                           0000CE   512 _EXF2	=	0x00ce
                           0000CD   513 _RCLK	=	0x00cd
                           0000CC   514 _TCLK	=	0x00cc
                           0000CB   515 _EXEN2	=	0x00cb
                           0000CA   516 _TR2	=	0x00ca
                           0000C9   517 _C_T2	=	0x00c9
                           0000C8   518 _CP_RL2	=	0x00c8
                           0000FF   519 _S0_FST_ACT	=	0x00ff
                           0000FE   520 _S0_IF_OV	=	0x00fe
                           0000FD   521 _S0_IF_FIRST	=	0x00fd
                           0000FC   522 _S0_IF_BYTE	=	0x00fc
                           0000FB   523 _S0_FREE	=	0x00fb
                           0000FA   524 _S0_T_FIFO	=	0x00fa
                           0000F8   525 _S0_R_FIFO	=	0x00f8
                           0000F7   526 _ADC_START	=	0x00f7
                                    527 ;--------------------------------------------------------
                                    528 ; overlayable register banks
                                    529 ;--------------------------------------------------------
                                    530 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        531 	.ds 8
                                    532 ;--------------------------------------------------------
                                    533 ; internal ram data
                                    534 ;--------------------------------------------------------
                                    535 	.area DSEG    (DATA)
                                    536 ;--------------------------------------------------------
                                    537 ; overlayable items in internal ram
                                    538 ;--------------------------------------------------------
                                    539 ;--------------------------------------------------------
                                    540 ; indirectly addressable internal ram data
                                    541 ;--------------------------------------------------------
                                    542 	.area ISEG    (DATA)
                                    543 ;--------------------------------------------------------
                                    544 ; absolute internal ram data
                                    545 ;--------------------------------------------------------
                                    546 	.area IABS    (ABS,DATA)
                                    547 	.area IABS    (ABS,DATA)
                                    548 ;--------------------------------------------------------
                                    549 ; bit data
                                    550 ;--------------------------------------------------------
                                    551 	.area BSEG    (BIT)
      00000E                        552 _ak820_tapping_before_sloc0_1_0:
      00000E                        553 	.ds 1
                                    554 ;--------------------------------------------------------
                                    555 ; paged external ram data
                                    556 ;--------------------------------------------------------
                                    557 	.area PSEG    (PAG,XDATA)
                                    558 ;--------------------------------------------------------
                                    559 ; uninitialized external ram data
                                    560 ;--------------------------------------------------------
                                    561 	.area XSEG    (XDATA)
      0005F4                        562 _source_state:
      0005F4                        563 	.ds 130
      000676                        564 _pending_time:
      000676                        565 	.ds 2
      000678                        566 _pending_code:
      000678                        567 	.ds 2
      00067A                        568 _ak820_tapping_source_PARM_1:
      00067A                        569 	.ds 2
      00067C                        570 _hold_PARM_2:
      00067C                        571 	.ds 1
      00067D                        572 _hold_code_10000_601:
      00067D                        573 	.ds 2
      00067F                        574 _hold_mods_30000_604:
      00067F                        575 	.ds 1
      000680                        576 _commit_pending_id_10000_610:
      000680                        577 	.ds 1
      000681                        578 _ak820_tapping_before_event_10000_611:
      000681                        579 	.ds 2
      000683                        580 _ak820_tapping_process_record_10000_622:
      000683                        581 	.ds 2
      000685                        582 _ak820_tapping_process_code_10000_623:
      000685                        583 	.ds 2
      000687                        584 _ak820_tapping_process_sc_mods_10000_623:
      000687                        585 	.ds 1
      000688                        586 _ak820_oneshot_mods::
      000688                        587 	.ds 1
      000689                        588 _ak820_oneshot_consumed::
      000689                        589 	.ds 1
      00068A                        590 _ak820_oneshot_process_PARM_2:
      00068A                        591 	.ds 1
      00068B                        592 _ak820_oneshot_process_PARM_3:
      00068B                        593 	.ds 1
      00068C                        594 _ak820_oneshot_process_code_10000_648:
      00068C                        595 	.ds 2
      00068E                        596 _ak820_oneshot_process_mods_10000_649:
      00068E                        597 	.ds 1
                                    598 ;--------------------------------------------------------
                                    599 ; absolute external ram data
                                    600 ;--------------------------------------------------------
                                    601 	.area XABS    (ABS,XDATA)
                                    602 ;--------------------------------------------------------
                                    603 ; initialized external ram data
                                    604 ;--------------------------------------------------------
                                    605 	.area XISEG   (XDATA)
      000E0A                        606 _pending:
      000E0A                        607 	.ds 1
      000E0B                        608 _ak820_oneshot_target::
      000E0B                        609 	.ds 1
                                    610 	.area HOME    (CODE)
                                    611 	.area GSINIT0 (CODE)
                                    612 	.area GSINIT1 (CODE)
                                    613 	.area GSINIT2 (CODE)
                                    614 	.area GSINIT3 (CODE)
                                    615 	.area GSINIT4 (CODE)
                                    616 	.area GSINIT5 (CODE)
                                    617 	.area GSINIT  (CODE)
                                    618 	.area GSFINAL (CODE)
                                    619 	.area CSEG    (CODE)
                                    620 ;--------------------------------------------------------
                                    621 ; global & static initialisations
                                    622 ;--------------------------------------------------------
                                    623 	.area HOME    (CODE)
                                    624 	.area GSINIT  (CODE)
                                    625 	.area GSFINAL (CODE)
                                    626 	.area GSINIT  (CODE)
                                    627 ;--------------------------------------------------------
                                    628 ; Home
                                    629 ;--------------------------------------------------------
                                    630 	.area HOME    (CODE)
                                    631 	.area HOME    (CODE)
                                    632 ;--------------------------------------------------------
                                    633 ; code
                                    634 ;--------------------------------------------------------
                                    635 	.area CSEG    (CODE)
                                    636 ;------------------------------------------------------------
                                    637 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    638 ;------------------------------------------------------------
                                    639 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    640 ;------------------------------------------------------------
                                    641 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    642 ;	-----------------------------------------
                           000007   643 	ar7 = 0x07
                           000006   644 	ar6 = 0x06
                           000005   645 	ar5 = 0x05
                           000004   646 	ar4 = 0x04
                           000003   647 	ar3 = 0x03
                           000002   648 	ar2 = 0x02
                           000001   649 	ar1 = 0x01
                           000000   650 	ar0 = 0x00
                                    651 ;	 function ak820_tapping_source
                                    652 ;	-----------------------------------------
      0046DA                        653 _ak820_tapping_source:
                                    654 ;	keyboards/ajazz/ak820/ak820_tapping.c:34: if (key.row < MATRIX_ROWS && key.col < MATRIX_COLS) return key.row * MATRIX_COLS + key.col;
      0046DA 90 06 7B         [24]  655 	mov	dptr,#(_ak820_tapping_source_PARM_1 + 0x0001)
      0046DD E0               [24]  656 	movx	a,@dptr
      0046DE FF               [12]  657 	mov	r7,a
      0046DF BF 10 00         [24]  658 	cjne	r7,#0x10,00147$
      0046E2                        659 00147$:
      0046E2 50 14            [24]  660 	jnc	00102$
      0046E4 90 06 7A         [24]  661 	mov	dptr,#_ak820_tapping_source_PARM_1
      0046E7 E0               [24]  662 	movx	a,@dptr
      0046E8 FE               [12]  663 	mov	r6,a
      0046E9 BE 08 00         [24]  664 	cjne	r6,#0x08,00149$
      0046EC                        665 00149$:
      0046EC 50 0A            [24]  666 	jnc	00102$
      0046EE 8F 05            [24]  667 	mov	ar5,r7
      0046F0 ED               [12]  668 	mov	a,r5
      0046F1 12 38 C6         [24]  669 	lcall	_ak820_outline_0192
      0046F4 2E               [12]  670 	add	a,r6
      0046F5 F5 82            [12]  671 	mov	dpl,a
      0046F7 22               [24]  672 	ret
      0046F8                        673 00102$:
                                    674 ;	keyboards/ajazz/ak820/ak820_tapping.c:35: if (key.col < NUM_ENCODERS) {
      0046F8 90 06 7A         [24]  675 	mov	dptr,#_ak820_tapping_source_PARM_1
      0046FB E0               [24]  676 	movx	a,@dptr
      0046FC FE               [12]  677 	mov	r6,a
      0046FD BE 01 00         [24]  678 	cjne	r6,#0x01,00151$
      004700                        679 00151$:
      004700 50 0E            [24]  680 	jnc	00109$
                                    681 ;	keyboards/ajazz/ak820/ak820_tapping.c:36: if (key.row == KEYLOC_ENCODER_CW) return MATRIX_ROWS * MATRIX_COLS + key.col;
      004702 BF FD 04         [24]  682 	cjne	r7,#0xfd,00105$
      004705 75 82 80         [24]  683 	mov	dpl, #0x80
      004708 22               [24]  684 	ret
      004709                        685 00105$:
                                    686 ;	keyboards/ajazz/ak820/ak820_tapping.c:37: if (key.row == KEYLOC_ENCODER_CCW) return MATRIX_ROWS * MATRIX_COLS + NUM_ENCODERS + key.col;
      004709 BF FC 04         [24]  687 	cjne	r7,#0xfc,00109$
      00470C 75 82 81         [24]  688 	mov	dpl, #0x81
      00470F 22               [24]  689 	ret
      004710                        690 00109$:
                                    691 ;	keyboards/ajazz/ak820/ak820_tapping.c:39: return NONE;
      004710 75 82 FF         [24]  692 	mov	dpl, #0xff
                                    693 ;	keyboards/ajazz/ak820/ak820_tapping.c:40: }
      004713 22               [24]  694 	ret
                                    695 ;------------------------------------------------------------
                                    696 ;Allocation info for local variables in function 'hold'
                                    697 ;------------------------------------------------------------
                                    698 ;pressed       Allocated with name '_hold_PARM_2'
                                    699 ;code          Allocated with name '_hold_code_10000_601'
                                    700 ;mods          Allocated with name '_hold_mods_30000_604'
                                    701 ;layer         Allocated with name '_hold_layer_30000_607'
                                    702 ;------------------------------------------------------------
                                    703 ;	keyboards/ajazz/ak820/ak820_tapping.c:41: static void hold(uint16_t code, bool pressed) {
                                    704 ;	-----------------------------------------
                                    705 ;	 function hold
                                    706 ;	-----------------------------------------
      004714                        707 _hold:
      004714 12 38 82         [24]  708 	lcall	_ak820_outline_0110
      004717 90 06 7D         [24]  709 	mov	dptr,#_hold_code_10000_601
      00471A 12 38 87         [24]  710 	lcall	_ak820_outline_0111
                                    711 ;	keyboards/ajazz/ak820/ak820_tapping.c:42: if (code < QK_LAYER_TAP) {
      00471D 90 06 7D         [24]  712 	mov	dptr,#_hold_code_10000_601
      004720 12 4B 75         [24]  713 	lcall	_ak820_outline_0009
      004723 74 C0            [12]  714 	mov	a,#0x100 - 0x40
      004725 2D               [12]  715 	add	a,r5
      004726 40 2E            [24]  716 	jc	00110$
                                    717 ;	keyboards/ajazz/ak820/ak820_tapping.c:43: uint8_t mods = (code >> 8) & 31;
      004728 8F 05            [24]  718 	mov	ar5,r7
      00472A 53 05 1F         [24]  719 	anl	ar5,#0x1f
      00472D 90 06 7F         [24]  720 	mov	dptr,#_hold_mods_30000_604
      004730 ED               [12]  721 	mov	a,r5
      004731 F0               [24]  722 	movx	@dptr,a
                                    723 ;	keyboards/ajazz/ak820/ak820_tapping.c:44: if (mods & 16) mods <<= 4;
      004732 ED               [12]  724 	mov	a,r5
      004733 30 E4 08         [24]  725 	jnb	acc.4,00102$
      004736 ED               [12]  726 	mov	a,r5
      004737 C4               [12]  727 	swap	a
      004738 54 F0            [12]  728 	anl	a,#0xf0
      00473A 90 06 7F         [24]  729 	mov	dptr,#_hold_mods_30000_604
      00473D F0               [24]  730 	movx	@dptr,a
      00473E                        731 00102$:
                                    732 ;	keyboards/ajazz/ak820/ak820_tapping.c:45: if (pressed) register_mods(mods);
      00473E 90 06 7C         [24]  733 	mov	dptr,#_hold_PARM_2
      004741 E0               [24]  734 	movx	a,@dptr
      004742 60 09            [24]  735 	jz	00104$
      004744 90 06 7F         [24]  736 	mov	dptr,#_hold_mods_30000_604
      004747 E0               [24]  737 	movx	a,@dptr
      004748 F5 82            [12]  738 	mov	dpl,a
      00474A 02 7A 6B         [24]  739 	ljmp	_register_mods
      00474D                        740 00104$:
                                    741 ;	keyboards/ajazz/ak820/ak820_tapping.c:46: else unregister_mods(mods);
      00474D 90 06 7F         [24]  742 	mov	dptr,#_hold_mods_30000_604
      004750 E0               [24]  743 	movx	a,@dptr
      004751 F5 82            [12]  744 	mov	dpl,a
      004753 02 7A 7F         [24]  745 	ljmp	_unregister_mods
      004756                        746 00110$:
                                    747 ;	keyboards/ajazz/ak820/ak820_tapping.c:48: uint8_t layer = (code >> 8) & 15;
      004756 8F 06            [24]  748 	mov	ar6,r7
      004758 74 0F            [12]  749 	mov	a,#0x0f
      00475A 5E               [12]  750 	anl	a,r6
      00475B FF               [12]  751 	mov	r7,a
                                    752 ;	keyboards/ajazz/ak820/ak820_tapping.c:49: if (pressed) layer_hold_on(layer);
      00475C 90 06 7C         [24]  753 	mov	dptr,#_hold_PARM_2
      00475F E0               [24]  754 	movx	a,@dptr
      004760 60 05            [24]  755 	jz	00107$
      004762 8F 82            [24]  756 	mov	dpl, r7
      004764 02 7C 6F         [24]  757 	ljmp	_layer_hold_on
      004767                        758 00107$:
                                    759 ;	keyboards/ajazz/ak820/ak820_tapping.c:50: else layer_hold_off(layer);
      004767 8F 82            [24]  760 	mov	dpl, r7
                                    761 ;	keyboards/ajazz/ak820/ak820_tapping.c:52: }
      004769 02 7C A7         [24]  762 	ljmp	_layer_hold_off
                                    763 ;------------------------------------------------------------
                                    764 ;Allocation info for local variables in function 'commit_pending'
                                    765 ;------------------------------------------------------------
                                    766 ;id            Allocated with name '_commit_pending_id_10000_610'
                                    767 ;------------------------------------------------------------
                                    768 ;	keyboards/ajazz/ak820/ak820_tapping.c:53: static void commit_pending(void) {
                                    769 ;	-----------------------------------------
                                    770 ;	 function commit_pending
                                    771 ;	-----------------------------------------
      00476C                        772 _commit_pending:
                                    773 ;	keyboards/ajazz/ak820/ak820_tapping.c:54: uint8_t id = pending;
      00476C 90 0E 0A         [24]  774 	mov	dptr,#_pending
      00476F E0               [24]  775 	movx	a,@dptr
      004770 90 06 80         [24]  776 	mov	dptr,#_commit_pending_id_10000_610
      004773 F0               [24]  777 	movx	@dptr,a
                                    778 ;	keyboards/ajazz/ak820/ak820_tapping.c:55: pending = NONE; /* A report callback cannot resurrect the decision. */
      004774 12 4C 01         [24]  779 	lcall	_ak820_outline_0157
                                    780 ;	keyboards/ajazz/ak820/ak820_tapping.c:56: source_state[id] |= SOURCE_HELD;
      004777 90 06 80         [24]  781 	mov	dptr,#_commit_pending_id_10000_610
      00477A E0               [24]  782 	movx	a,@dptr
      00477B 24 F4            [12]  783 	add	a,#_source_state
      00477D FF               [12]  784 	mov	r7,a
      00477E E4               [12]  785 	clr	a
      00477F 34 05            [12]  786 	addc	a, #(_source_state >> 8)
      004781 FE               [12]  787 	mov	r6,a
      004782 12 46 BF         [24]  788 	lcall	_ak820_outline_0160
      004785 E0               [24]  789 	movx	a,@dptr
      004786 FD               [12]  790 	mov	r5,a
      004787 43 05 04         [24]  791 	orl	ar5,#0x04
      00478A 12 46 BF         [24]  792 	lcall	_ak820_outline_0160
      00478D ED               [12]  793 	mov	a,r5
      00478E F0               [24]  794 	movx	@dptr,a
                                    795 ;	keyboards/ajazz/ak820/ak820_tapping.c:57: hold(pending_code, true);
      00478F 90 06 78         [24]  796 	mov	dptr,#_pending_code
      004792 12 38 41         [24]  797 	lcall	_ak820_outline_0053
      004795 90 06 7C         [24]  798 	mov	dptr,#_hold_PARM_2
      004798 74 01            [12]  799 	mov	a,#0x01
      00479A 12 46 8B         [24]  800 	lcall	_ak820_outline_0076
                                    801 ;	keyboards/ajazz/ak820/ak820_tapping.c:58: }
      00479D 02 47 14         [24]  802 	ljmp	_hold
                                    803 ;------------------------------------------------------------
                                    804 ;Allocation info for local variables in function 'ak820_tapping_before'
                                    805 ;------------------------------------------------------------
                                    806 ;event         Allocated with name '_ak820_tapping_before_event_10000_611'
                                    807 ;id            Allocated with name '_ak820_tapping_before_id_10000_612'
                                    808 ;------------------------------------------------------------
                                    809 ;	keyboards/ajazz/ak820/ak820_tapping.c:59: bool ak820_tapping_before(const keyevent_t AK820_STATE_MEM *event) {
                                    810 ;	-----------------------------------------
                                    811 ;	 function ak820_tapping_before
                                    812 ;	-----------------------------------------
      0047A0                        813 _ak820_tapping_before:
      0047A0 12 38 82         [24]  814 	lcall	_ak820_outline_0110
      0047A3 90 06 81         [24]  815 	mov	dptr,#_ak820_tapping_before_event_10000_611
      0047A6 12 38 87         [24]  816 	lcall	_ak820_outline_0111
                                    817 ;	keyboards/ajazz/ak820/ak820_tapping.c:60: uint8_t id = ak820_tapping_source(event->key);
      0047A9 90 06 81         [24]  818 	mov	dptr,#_ak820_tapping_before_event_10000_611
      0047AC 12 4B 75         [24]  819 	lcall	_ak820_outline_0009
      0047AF 12 4B 9A         [24]  820 	lcall	_ak820_outline_0025
      0047B2 C0 07            [24]  821 	push	ar7
      0047B4 C0 06            [24]  822 	push	ar6
      0047B6 12 BC 0D         [24]  823 	lcall	___memcpy
      0047B9 12 46 DA         [24]  824 	lcall	_ak820_tapping_source
      0047BC AD 82            [24]  825 	mov	r5, dpl
      0047BE D0 06            [24]  826 	pop	ar6
      0047C0 D0 07            [24]  827 	pop	ar7
                                    828 ;	keyboards/ajazz/ak820/ak820_tapping.c:62: if (vial_unlock_in_progress) {
      0047C2 90 0E 7B         [24]  829 	mov	dptr,#_vial_unlock_in_progress
      0047C5 E0               [24]  830 	movx	a,@dptr
      0047C6 60 26            [24]  831 	jz	00106$
                                    832 ;	keyboards/ajazz/ak820/ak820_tapping.c:63: if (IS_EVENT(*event) && id != NONE && !event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      0047C8 12 4B F4         [24]  833 	lcall	_ak820_outline_0100
      0047CB 60 1D            [24]  834 	jz	00102$
      0047CD BD FF 02         [24]  835 	cjne	r5,#0xff,00218$
      0047D0 80 18            [24]  836 	sjmp	00102$
      0047D2                        837 00218$:
      0047D2 12 4B 7F         [24]  838 	lcall	_ak820_outline_0015
      0047D5 E0               [24]  839 	movx	a,@dptr
      0047D6 70 12            [24]  840 	jnz	00102$
      0047D8 ED               [12]  841 	mov	a,r5
      0047D9 24 F4            [12]  842 	add	a, #_source_state
      0047DB FB               [12]  843 	mov	r3,a
      0047DC E4               [12]  844 	clr	a
      0047DD 34 05            [12]  845 	addc	a, #(_source_state >> 8)
      0047DF 12 4B CA         [24]  846 	lcall	_ak820_outline_0057
      0047E2 53 02 FD         [24]  847 	anl	ar2,#0xfd
      0047E5 12 33 FC         [24]  848 	lcall	_ak820_outline_0125
      0047E8 EA               [12]  849 	mov	a,r2
      0047E9 F0               [24]  850 	movx	@dptr,a
      0047EA                        851 00102$:
                                    852 ;	keyboards/ajazz/ak820/ak820_tapping.c:64: return false;
      0047EA 75 82 00         [24]  853 	mov	dpl, #0x00
      0047ED 22               [24]  854 	ret
      0047EE                        855 00106$:
                                    856 ;	keyboards/ajazz/ak820/ak820_tapping.c:67: if (pending != NONE && ((uint16_t)(event->time - pending_time) >= 200 ||
      0047EE 90 0E 0A         [24]  857 	mov	dptr,#_pending
      0047F1 E0               [24]  858 	movx	a,@dptr
      0047F2 FC               [12]  859 	mov	r4,a
      0047F3 BC FF 02         [24]  860 	cjne	r4,#0xff,00220$
      0047F6 80 3B            [24]  861 	sjmp	00108$
      0047F8                        862 00220$:
      0047F8 12 38 39         [24]  863 	lcall	_ak820_outline_0037
      0047FB FA               [12]  864 	mov	r2,a
      0047FC A3               [24]  865 	inc	dptr
      0047FD E0               [24]  866 	movx	a,@dptr
      0047FE FB               [12]  867 	mov	r3,a
      0047FF 90 06 76         [24]  868 	mov	dptr,#_pending_time
      004802 12 38 7C         [24]  869 	lcall	_ak820_outline_0105
      004805 EA               [12]  870 	mov	a,r2
      004806 C3               [12]  871 	clr	c
      004807 98               [12]  872 	subb	a,r0
      004808 FA               [12]  873 	mov	r2,a
      004809 EB               [12]  874 	mov	a,r3
      00480A 99               [12]  875 	subb	a,r1
      00480B FB               [12]  876 	mov	r3,a
      00480C C3               [12]  877 	clr	c
      00480D EA               [12]  878 	mov	a,r2
      00480E 94 C8            [12]  879 	subb	a,#0xc8
      004810 EB               [12]  880 	mov	a,r3
      004811 94 00            [12]  881 	subb	a,#0x00
      004813 50 17            [24]  882 	jnc	00107$
                                    883 ;	keyboards/ajazz/ak820/ak820_tapping.c:68: (IS_EVENT(*event) && event->pressed && (id == NONE || id != pending)))) commit_pending();
      004815 74 04            [12]  884 	mov	a,#0x04
      004817 12 4B B4         [24]  885 	lcall	_ak820_outline_0033
      00481A 60 17            [24]  886 	jz	00108$
      00481C 12 38 12         [24]  887 	lcall	_ak820_outline_0010
      00481F 60 12            [24]  888 	jz	00108$
      004821 BD FF 02         [24]  889 	cjne	r5,#0xff,00224$
      004824 80 06            [24]  890 	sjmp	00107$
      004826                        891 00224$:
      004826 ED               [12]  892 	mov	a,r5
      004827 B5 04 02         [24]  893 	cjne	a,ar4,00225$
      00482A 80 07            [24]  894 	sjmp	00108$
      00482C                        895 00225$:
      00482C                        896 00107$:
      00482C C0 05            [24]  897 	push	ar5
      00482E 12 47 6C         [24]  898 	lcall	_commit_pending
      004831 D0 05            [24]  899 	pop	ar5
      004833                        900 00108$:
                                    901 ;	keyboards/ajazz/ak820/ak820_tapping.c:69: if (IS_NOEVENT(*event) || id == NONE) return true;
      004833 90 06 81         [24]  902 	mov	dptr,#_ak820_tapping_before_event_10000_611
      004836 12 38 41         [24]  903 	lcall	_ak820_outline_0053
      004839 12 4B F4         [24]  904 	lcall	_ak820_outline_0100
      00483C 60 03            [24]  905 	jz	00114$
      00483E BD FF 04         [24]  906 	cjne	r5,#0xff,00115$
      004841                        907 00114$:
      004841 75 82 01         [24]  908 	mov	dpl, #0x01
      004844 22               [24]  909 	ret
      004845                        910 00115$:
                                    911 ;	keyboards/ajazz/ak820/ak820_tapping.c:70: if ((source_state[id] & SOURCE_BLOCKED)) {
      004845 ED               [12]  912 	mov	a,r5
      004846 12 4B E6         [24]  913 	lcall	_ak820_outline_0081
      004849 30 E1 13         [24]  914 	jnb	acc.1,00120$
                                    915 ;	keyboards/ajazz/ak820/ak820_tapping.c:71: if (!event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      00484C 74 05            [12]  916 	mov	a,#0x05
      00484E 2E               [12]  917 	add	a, r6
      00484F 12 38 27         [24]  918 	lcall	_ak820_outline_0017
      004852 70 07            [24]  919 	jnz	00118$
      004854 74 FD            [12]  920 	mov	a,#0xfd
      004856 5B               [12]  921 	anl	a,r3
      004857 12 38 97         [24]  922 	lcall	_ak820_outline_0126
      00485A F0               [24]  923 	movx	@dptr,a
      00485B                        924 00118$:
                                    925 ;	keyboards/ajazz/ak820/ak820_tapping.c:72: return false;
      00485B 75 82 00         [24]  926 	mov	dpl, #0x00
      00485E 22               [24]  927 	ret
      00485F                        928 00120$:
                                    929 ;	keyboards/ajazz/ak820/ak820_tapping.c:75: if (event->pressed == ((source_state[id] & SOURCE_ACTIVE) != 0)) return false;
      00485F 12 46 4E         [24]  930 	lcall	_ak820_outline_0012
      004862 E0               [24]  931 	movx	a,@dptr
      004863 FF               [12]  932 	mov	r7,a
      004864 8B 06            [24]  933 	mov	ar6,r3
      004866 53 06 01         [24]  934 	anl	ar6,#0x01
      004869 EE               [12]  935 	mov	a,r6
      00486A B4 01 00         [24]  936 	cjne	a,#0x01,00231$
      00486D                        937 00231$:
      00486D B3               [12]  938 	cpl	c
      00486E 92 0E            [24]  939 	mov	_ak820_tapping_before_sloc0_1_0,c
      004870 8F F0            [24]  940 	mov	b,r7
      004872 E4               [12]  941 	clr	a
      004873 33               [12]  942 	rlc	a
      004874 B5 F0 04         [24]  943 	cjne	a,b,00122$
      004877 75 82 00         [24]  944 	mov	dpl, #0x00
      00487A 22               [24]  945 	ret
      00487B                        946 00122$:
                                    947 ;	keyboards/ajazz/ak820/ak820_tapping.c:76: source_state[id] ^= SOURCE_ACTIVE;
      00487B 63 03 01         [24]  948 	xrl	ar3,#0x01
      00487E 12 38 97         [24]  949 	lcall	_ak820_outline_0126
      004881 EB               [12]  950 	mov	a,r3
      004882 F0               [24]  951 	movx	@dptr,a
                                    952 ;	keyboards/ajazz/ak820/ak820_tapping.c:77: return true;
      004883 75 82 01         [24]  953 	mov	dpl, #0x01
                                    954 ;	keyboards/ajazz/ak820/ak820_tapping.c:78: }
      004886 22               [24]  955 	ret
                                    956 ;------------------------------------------------------------
                                    957 ;Allocation info for local variables in function 'ak820_tapping_process'
                                    958 ;------------------------------------------------------------
                                    959 ;record        Allocated with name '_ak820_tapping_process_record_10000_622'
                                    960 ;id            Allocated with name '_ak820_tapping_process_id_10000_623'
                                    961 ;kind          Allocated with name '_ak820_tapping_process_kind_10000_623'
                                    962 ;code          Allocated with name '_ak820_tapping_process_code_10000_623'
                                    963 ;sc_mods       Allocated with name '_ak820_tapping_process_sc_mods_10000_623'
                                    964 ;------------------------------------------------------------
                                    965 ;	keyboards/ajazz/ak820/ak820_tapping.c:79: bool ak820_tapping_process(keyrecord_t AK820_STATE_MEM *record) {
                                    966 ;	-----------------------------------------
                                    967 ;	 function ak820_tapping_process
                                    968 ;	-----------------------------------------
      004887                        969 _ak820_tapping_process:
      004887 12 38 82         [24]  970 	lcall	_ak820_outline_0110
      00488A 90 06 83         [24]  971 	mov	dptr,#_ak820_tapping_process_record_10000_622
      00488D 12 38 87         [24]  972 	lcall	_ak820_outline_0111
                                    973 ;	keyboards/ajazz/ak820/ak820_tapping.c:83: uint8_t sc_mods = 0;
      004890 90 06 87         [24]  974 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_623
      004893 E4               [12]  975 	clr	a
      004894 F0               [24]  976 	movx	@dptr,a
                                    977 ;	keyboards/ajazz/ak820/ak820_tapping.c:85: if (IS_NOEVENT(record->event)) return true;
      004895 90 06 83         [24]  978 	mov	dptr,#_ak820_tapping_process_record_10000_622
      004898 12 38 41         [24]  979 	lcall	_ak820_outline_0053
      00489B 74 04            [12]  980 	mov	a,#0x04
      00489D 12 4B BF         [24]  981 	lcall	_ak820_outline_0034
      0048A0 70 04            [24]  982 	jnz	00102$
      0048A2 75 82 01         [24]  983 	mov	dpl, #0x01
      0048A5 22               [24]  984 	ret
      0048A6                        985 00102$:
                                    986 ;	keyboards/ajazz/ak820/ak820_tapping.c:86: id = ak820_tapping_source(record->event.key);
      0048A6 8E 04            [24]  987 	mov	ar4,r6
      0048A8 8F 05            [24]  988 	mov	ar5,r7
      0048AA 12 4B 9A         [24]  989 	lcall	_ak820_outline_0025
      0048AD C0 07            [24]  990 	push	ar7
      0048AF C0 06            [24]  991 	push	ar6
      0048B1 12 BC 0D         [24]  992 	lcall	___memcpy
      0048B4 12 46 DA         [24]  993 	lcall	_ak820_tapping_source
      0048B7 AD 82            [24]  994 	mov	r5, dpl
      0048B9 D0 06            [24]  995 	pop	ar6
      0048BB D0 07            [24]  996 	pop	ar7
                                    997 ;	keyboards/ajazz/ak820/ak820_tapping.c:87: if (id == NONE) return true;
      0048BD BD FF 04         [24]  998 	cjne	r5,#0xff,00104$
      0048C0 75 82 01         [24]  999 	mov	dpl, #0x01
      0048C3 22               [24] 1000 	ret
      0048C4                       1001 00104$:
                                   1002 ;	keyboards/ajazz/ak820/ak820_tapping.c:88: code = record->keycode;
      0048C4 74 07            [12] 1003 	mov	a,#0x07
      0048C6 12 38 31         [24] 1004 	lcall	_ak820_outline_0022
      0048C9 12 38 41         [24] 1005 	lcall	_ak820_outline_0053
      0048CC 90 06 85         [24] 1006 	mov	dptr,#_ak820_tapping_process_code_10000_623
      0048CF 12 4B D2         [24] 1007 	lcall	_ak820_outline_0060
                                   1008 ;	keyboards/ajazz/ak820/ak820_tapping.c:90: if (code == SC_LSPO) { code = MT(MOD_LSFT, KC_9); sc_mods = MOD_BIT(KC_LEFT_SHIFT); }
      0048D2 BE 1A 15         [24] 1009 	cjne	r6,#0x1a,00111$
      0048D5 BF 7C 12         [24] 1010 	cjne	r7,#0x7c,00111$
      0048D8 90 06 85         [24] 1011 	mov	dptr,#_ak820_tapping_process_code_10000_623
      0048DB 74 26            [12] 1012 	mov	a,#0x26
      0048DD F0               [24] 1013 	movx	@dptr,a
      0048DE 74 22            [12] 1014 	mov	a,#0x22
      0048E0 A3               [24] 1015 	inc	dptr
      0048E1 F0               [24] 1016 	movx	@dptr,a
      0048E2 90 06 87         [24] 1017 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_623
      0048E5 74 02            [12] 1018 	mov	a,#0x02
      0048E7 F0               [24] 1019 	movx	@dptr,a
      0048E8 80 28            [24] 1020 	sjmp	00112$
      0048EA                       1021 00111$:
                                   1022 ;	keyboards/ajazz/ak820/ak820_tapping.c:91: else if (code == SC_RSPC) { code = MT(MOD_RSFT, KC_0); sc_mods = MOD_BIT(KC_RIGHT_SHIFT); }
      0048EA BE 1B 15         [24] 1023 	cjne	r6,#0x1b,00108$
      0048ED BF 7C 12         [24] 1024 	cjne	r7,#0x7c,00108$
      0048F0 90 06 85         [24] 1025 	mov	dptr,#_ak820_tapping_process_code_10000_623
      0048F3 74 27            [12] 1026 	mov	a,#0x27
      0048F5 F0               [24] 1027 	movx	@dptr,a
      0048F6 74 32            [12] 1028 	mov	a,#0x32
      0048F8 A3               [24] 1029 	inc	dptr
      0048F9 F0               [24] 1030 	movx	@dptr,a
      0048FA 90 06 87         [24] 1031 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_623
      0048FD 74 20            [12] 1032 	mov	a,#0x20
      0048FF F0               [24] 1033 	movx	@dptr,a
      004900 80 10            [24] 1034 	sjmp	00112$
      004902                       1035 00108$:
                                   1036 ;	keyboards/ajazz/ak820/ak820_tapping.c:92: else if (code == SC_SENT) code = MT(MOD_RSFT, KC_ENTER);
      004902 BE 1E 0D         [24] 1037 	cjne	r6,#0x1e,00112$
      004905 BF 7C 0A         [24] 1038 	cjne	r7,#0x7c,00112$
      004908 90 06 85         [24] 1039 	mov	dptr,#_ak820_tapping_process_code_10000_623
      00490B 74 28            [12] 1040 	mov	a,#0x28
      00490D F0               [24] 1041 	movx	@dptr,a
      00490E 74 32            [12] 1042 	mov	a,#0x32
      004910 A3               [24] 1043 	inc	dptr
      004911 F0               [24] 1044 	movx	@dptr,a
      004912                       1045 00112$:
                                   1046 ;	keyboards/ajazz/ak820/ak820_tapping.c:94: kind = code >> 8;
      004912 90 06 85         [24] 1047 	mov	dptr,#_ak820_tapping_process_code_10000_623
      004915 E0               [24] 1048 	movx	a,@dptr
      004916 A3               [24] 1049 	inc	dptr
      004917 E0               [24] 1050 	movx	a,@dptr
      004918 FF               [12] 1051 	mov	r7,a
                                   1052 ;	keyboards/ajazz/ak820/ak820_tapping.c:95: if (kind < 0x20 || kind >= 0x50) return true;
      004919 BF 20 00         [24] 1053 	cjne	r7,#0x20,00242$
      00491C                       1054 00242$:
      00491C 40 05            [24] 1055 	jc	00113$
      00491E BF 50 00         [24] 1056 	cjne	r7,#0x50,00244$
      004921                       1057 00244$:
      004921 40 04            [24] 1058 	jc	00114$
      004923                       1059 00113$:
      004923 75 82 01         [24] 1060 	mov	dpl, #0x01
      004926 22               [24] 1061 	ret
      004927                       1062 00114$:
                                   1063 ;	keyboards/ajazz/ak820/ak820_tapping.c:96: if (kind >= 0x40 && (kind & 15) >= MAX_LAYER) return false;
      004927 BF 40 00         [24] 1064 	cjne	r7,#0x40,00246$
      00492A                       1065 00246$:
      00492A 40 0C            [24] 1066 	jc	00117$
      00492C 53 07 0F         [24] 1067 	anl	ar7,#0x0f
      00492F BF 06 00         [24] 1068 	cjne	r7,#0x06,00248$
      004932                       1069 00248$:
      004932 40 04            [24] 1070 	jc	00117$
      004934 75 82 00         [24] 1071 	mov	dpl, #0x00
      004937 22               [24] 1072 	ret
      004938                       1073 00117$:
                                   1074 ;	keyboards/ajazz/ak820/ak820_tapping.c:97: if (record->event.pressed) {
      004938 90 06 83         [24] 1075 	mov	dptr,#_ak820_tapping_process_record_10000_622
      00493B 12 38 41         [24] 1076 	lcall	_ak820_outline_0053
      00493E 12 4B 7F         [24] 1077 	lcall	_ak820_outline_0015
      004941 E0               [24] 1078 	movx	a,@dptr
      004942 60 1F            [24] 1079 	jz	00131$
                                   1080 ;	keyboards/ajazz/ak820/ak820_tapping.c:98: pending = id;
      004944 90 0E 0A         [24] 1081 	mov	dptr,#_pending
      004947 ED               [12] 1082 	mov	a,r5
      004948 12 46 58         [24] 1083 	lcall	_ak820_outline_0032
                                   1084 ;	keyboards/ajazz/ak820/ak820_tapping.c:99: pending_time = record->event.time;
      00494B 12 38 41         [24] 1085 	lcall	_ak820_outline_0053
      00494E 90 06 76         [24] 1086 	mov	dptr,#_pending_time
      004951 12 4B D2         [24] 1087 	lcall	_ak820_outline_0060
                                   1088 ;	keyboards/ajazz/ak820/ak820_tapping.c:100: pending_code = code;
      004954 90 06 85         [24] 1089 	mov	dptr,#_ak820_tapping_process_code_10000_623
      004957 12 38 41         [24] 1090 	lcall	_ak820_outline_0053
      00495A 90 06 78         [24] 1091 	mov	dptr,#_pending_code
      00495D 12 4B D2         [24] 1092 	lcall	_ak820_outline_0060
      004960 02 4A 16         [24] 1093 	ljmp	00132$
      004963                       1094 00131$:
                                   1095 ;	keyboards/ajazz/ak820/ak820_tapping.c:101: } else if (id == pending) {
      004963 90 0E 0A         [24] 1096 	mov	dptr,#_pending
      004966 E0               [24] 1097 	movx	a,@dptr
      004967 FF               [12] 1098 	mov	r7,a
      004968 ED               [12] 1099 	mov	a,r5
      004969 B5 07 02         [24] 1100 	cjne	a,ar7,00251$
      00496C 80 03            [24] 1101 	sjmp	00252$
      00496E                       1102 00251$:
      00496E 02 49 EE         [24] 1103 	ljmp	00128$
      004971                       1104 00252$:
                                   1105 ;	keyboards/ajazz/ak820/ak820_tapping.c:102: pending = NONE;
      004971 12 4C 01         [24] 1106 	lcall	_ak820_outline_0157
                                   1107 ;	keyboards/ajazz/ak820/ak820_tapping.c:104: if (sc_mods) add_owned_mods(sc_mods);
      004974 90 06 87         [24] 1108 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_623
      004977 E0               [24] 1109 	movx	a,@dptr
      004978 FF               [12] 1110 	mov	r7,a
      004979 E0               [24] 1111 	movx	a,@dptr
      00497A 60 05            [24] 1112 	jz	00120$
      00497C 8F 82            [24] 1113 	mov	dpl, r7
      00497E 12 80 F5         [24] 1114 	lcall	_add_owned_mods
      004981                       1115 00120$:
                                   1116 ;	keyboards/ajazz/ak820/ak820_tapping.c:108: record->keycode = (uint8_t)code;
      004981 90 06 83         [24] 1117 	mov	dptr,#_ak820_tapping_process_record_10000_622
      004984 12 38 41         [24] 1118 	lcall	_ak820_outline_0053
      004987 74 07            [12] 1119 	mov	a,#0x07
      004989 2E               [12] 1120 	add	a, r6
      00498A FB               [12] 1121 	mov	r3,a
      00498B E4               [12] 1122 	clr	a
      00498C 3F               [12] 1123 	addc	a, r7
      00498D FC               [12] 1124 	mov	r4,a
      00498E 90 06 85         [24] 1125 	mov	dptr,#_ak820_tapping_process_code_10000_623
      004991 E0               [24] 1126 	movx	a,@dptr
      004992 F9               [12] 1127 	mov	r1,a
      004993 7A 00            [12] 1128 	mov	r2,#0x00
      004995 12 33 FC         [24] 1129 	lcall	_ak820_outline_0125
      004998 E9               [12] 1130 	mov	a,r1
      004999 F0               [24] 1131 	movx	@dptr,a
      00499A EA               [12] 1132 	mov	a,r2
      00499B A3               [24] 1133 	inc	dptr
      00499C F0               [24] 1134 	movx	@dptr,a
                                   1135 ;	keyboards/ajazz/ak820/ak820_tapping.c:109: if (record->keycode > KC_TRANSPARENT) {
      00499D C3               [12] 1136 	clr	c
      00499E 04               [12] 1137 	inc	a
      00499F 99               [12] 1138 	subb	a,r1
      0049A0 50 3A            [24] 1139 	jnc	00122$
                                   1140 ;	free result
                                   1141 ;	keyboards/ajazz/ak820/ak820_tapping.c:110: record->tap.count = 1;
      0049A2 74 06            [12] 1142 	mov	a,#0x06
      0049A4 12 38 31         [24] 1143 	lcall	_ak820_outline_0022
      0049A7 E0               [24] 1144 	movx	a,@dptr
      0049A8 54 0F            [12] 1145 	anl	a,#0x0f
      0049AA 44 10            [12] 1146 	orl	a,#0x10
      0049AC F0               [24] 1147 	movx	@dptr,a
                                   1148 ;	keyboards/ajazz/ak820/ak820_tapping.c:111: record->event.pressed = true;
      0049AD 12 4B 7F         [24] 1149 	lcall	_ak820_outline_0015
      0049B0 74 01            [12] 1150 	mov	a,#0x01
      0049B2 F0               [24] 1151 	movx	@dptr,a
                                   1152 ;	keyboards/ajazz/ak820/ak820_tapping.c:112: process_record(record);
      0049B3 12 4B D8         [24] 1153 	lcall	_ak820_outline_0077
      0049B6 12 38 B1         [24] 1154 	lcall	_ak820_outline_0146
      0049B9 8A F0            [24] 1155 	mov	b, r2
      0049BB C0 07            [24] 1156 	push	ar7
      0049BD C0 06            [24] 1157 	push	ar6
      0049BF C0 04            [24] 1158 	push	ar4
      0049C1 C0 03            [24] 1159 	push	ar3
      0049C3 12 74 45         [24] 1160 	lcall	_process_record
      0049C6 D0 03            [24] 1161 	pop	ar3
      0049C8 D0 04            [24] 1162 	pop	ar4
      0049CA D0 06            [24] 1163 	pop	ar6
      0049CC D0 07            [24] 1164 	pop	ar7
                                   1165 ;	keyboards/ajazz/ak820/ak820_tapping.c:113: record->event.pressed = false;
      0049CE 12 33 FC         [24] 1166 	lcall	_ak820_outline_0125
      0049D1 E4               [12] 1167 	clr	a
      0049D2 F0               [24] 1168 	movx	@dptr,a
                                   1169 ;	keyboards/ajazz/ak820/ak820_tapping.c:114: process_record(record);
      0049D3 FC               [12] 1170 	mov	r4,a
      0049D4 12 38 8C         [24] 1171 	lcall	_ak820_outline_0120
      0049D7 8C F0            [24] 1172 	mov	b, r4
      0049D9 12 74 45         [24] 1173 	lcall	_process_record
      0049DC                       1174 00122$:
                                   1175 ;	keyboards/ajazz/ak820/ak820_tapping.c:117: if (sc_mods) {
      0049DC 90 06 87         [24] 1176 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_623
      0049DF E0               [24] 1177 	movx	a,@dptr
      0049E0 FF               [12] 1178 	mov	r7,a
      0049E1 E0               [24] 1179 	movx	a,@dptr
      0049E2 60 32            [24] 1180 	jz	00132$
                                   1181 ;	keyboards/ajazz/ak820/ak820_tapping.c:118: del_owned_mods(sc_mods);
      0049E4 8F 82            [24] 1182 	mov	dpl, r7
      0049E6 12 81 05         [24] 1183 	lcall	_del_owned_mods
                                   1184 ;	keyboards/ajazz/ak820/ak820_tapping.c:119: send_keyboard_report();
      0049E9 12 84 36         [24] 1185 	lcall	_send_keyboard_report
      0049EC 80 28            [24] 1186 	sjmp	00132$
      0049EE                       1187 00128$:
                                   1188 ;	keyboards/ajazz/ak820/ak820_tapping.c:122: } else if ((source_state[id] & SOURCE_HELD)) {
      0049EE ED               [12] 1189 	mov	a,r5
      0049EF 24 F4            [12] 1190 	add	a, #_source_state
      0049F1 FE               [12] 1191 	mov	r6,a
      0049F2 E4               [12] 1192 	clr	a
      0049F3 34 05            [12] 1193 	addc	a, #(_source_state >> 8)
      0049F5 FF               [12] 1194 	mov	r7,a
      0049F6 12 38 8C         [24] 1195 	lcall	_ak820_outline_0120
      0049F9 E0               [24] 1196 	movx	a,@dptr
      0049FA FD               [12] 1197 	mov	r5,a
      0049FB 30 E2 18         [24] 1198 	jnb	acc.2,00132$
                                   1199 ;	keyboards/ajazz/ak820/ak820_tapping.c:123: source_state[id] &= ~SOURCE_HELD;
      0049FE 53 05 FB         [24] 1200 	anl	ar5,#0xfb
      004A01 12 38 8C         [24] 1201 	lcall	_ak820_outline_0120
      004A04 ED               [12] 1202 	mov	a,r5
      004A05 F0               [24] 1203 	movx	@dptr,a
                                   1204 ;	keyboards/ajazz/ak820/ak820_tapping.c:124: hold(code, false);
      004A06 90 06 85         [24] 1205 	mov	dptr,#_ak820_tapping_process_code_10000_623
      004A09 12 38 41         [24] 1206 	lcall	_ak820_outline_0053
      004A0C 90 06 7C         [24] 1207 	mov	dptr,#_hold_PARM_2
      004A0F E4               [12] 1208 	clr	a
      004A10 12 46 8B         [24] 1209 	lcall	_ak820_outline_0076
      004A13 12 47 14         [24] 1210 	lcall	_hold
      004A16                       1211 00132$:
                                   1212 ;	keyboards/ajazz/ak820/ak820_tapping.c:126: return false;
      004A16 75 82 00         [24] 1213 	mov	dpl, #0x00
                                   1214 ;	keyboards/ajazz/ak820/ak820_tapping.c:127: }
      004A19 22               [24] 1215 	ret
                                   1216 ;------------------------------------------------------------
                                   1217 ;Allocation info for local variables in function 'ak820_tapping_cancel'
                                   1218 ;------------------------------------------------------------
                                   1219 ;i             Allocated with name '_ak820_tapping_cancel_i_20000_646'
                                   1220 ;state         Allocated with name '_ak820_tapping_cancel_state_30000_647'
                                   1221 ;------------------------------------------------------------
                                   1222 ;	keyboards/ajazz/ak820/ak820_tapping.c:128: void ak820_tapping_cancel(void) {
                                   1223 ;	-----------------------------------------
                                   1224 ;	 function ak820_tapping_cancel
                                   1225 ;	-----------------------------------------
      004A1A                       1226 _ak820_tapping_cancel:
                                   1227 ;	keyboards/ajazz/ak820/ak820_tapping.c:129: pending = NONE;
      004A1A 12 4C 01         [24] 1228 	lcall	_ak820_outline_0157
                                   1229 ;	keyboards/ajazz/ak820/ak820_tapping.c:130: for (uint8_t i = 0; i < SOURCES; ++i) {
      004A1D 7F 00            [12] 1230 	mov	r7,#0x00
      004A1F                       1231 00103$:
      004A1F BF 82 00         [24] 1232 	cjne	r7,#0x82,00122$
      004A22                       1233 00122$:
      004A22 50 16            [24] 1234 	jnc	00105$
                                   1235 ;	keyboards/ajazz/ak820/ak820_tapping.c:131: uint8_t state = source_state[i];
      004A24 12 4B 8B         [24] 1236 	lcall	_ak820_outline_0020
                                   1237 ;	keyboards/ajazz/ak820/ak820_tapping.c:132: source_state[i] = (state & SOURCE_BLOCKED) | ((state & SOURCE_ACTIVE) << 1);
      004A27 74 02            [12] 1238 	mov	a,#0x02
      004A29 5C               [12] 1239 	anl	a,r4
      004A2A FB               [12] 1240 	mov	r3,a
      004A2B 53 04 01         [24] 1241 	anl	ar4,#0x01
      004A2E EC               [12] 1242 	mov	a,r4
      004A2F 2C               [12] 1243 	add	a,r4
      004A30 42 03            [12] 1244 	orl	ar3,a
      004A32 12 38 A1         [24] 1245 	lcall	_ak820_outline_0137
      004A35 EB               [12] 1246 	mov	a,r3
      004A36 F0               [24] 1247 	movx	@dptr,a
                                   1248 ;	keyboards/ajazz/ak820/ak820_tapping.c:130: for (uint8_t i = 0; i < SOURCES; ++i) {
      004A37 0F               [12] 1249 	inc	r7
      004A38 80 E5            [24] 1250 	sjmp	00103$
      004A3A                       1251 00105$:
                                   1252 ;	keyboards/ajazz/ak820/ak820_tapping.c:134: }
      004A3A 22               [24] 1253 	ret
                                   1254 ;------------------------------------------------------------
                                   1255 ;Allocation info for local variables in function 'ak820_oneshot_process'
                                   1256 ;------------------------------------------------------------
                                   1257 ;id            Allocated with name '_ak820_oneshot_process_PARM_2'
                                   1258 ;pressed       Allocated with name '_ak820_oneshot_process_PARM_3'
                                   1259 ;code          Allocated with name '_ak820_oneshot_process_code_10000_648'
                                   1260 ;mods          Allocated with name '_ak820_oneshot_process_mods_10000_649'
                                   1261 ;i             Allocated with name '_ak820_oneshot_process_i_40000_663'
                                   1262 ;------------------------------------------------------------
                                   1263 ;	keyboards/ajazz/ak820/ak820_tapping.c:143: bool ak820_oneshot_process(uint16_t code, uint8_t id, bool pressed) {
                                   1264 ;	-----------------------------------------
                                   1265 ;	 function ak820_oneshot_process
                                   1266 ;	-----------------------------------------
      004A3B                       1267 _ak820_oneshot_process:
      004A3B 12 38 82         [24] 1268 	lcall	_ak820_outline_0110
      004A3E 90 06 8C         [24] 1269 	mov	dptr,#_ak820_oneshot_process_code_10000_648
      004A41 12 38 87         [24] 1270 	lcall	_ak820_outline_0111
                                   1271 ;	keyboards/ajazz/ak820/ak820_tapping.c:145: if (id == NONE || get_repeat_key_count()) return true;
      004A44 90 06 8A         [24] 1272 	mov	dptr,#_ak820_oneshot_process_PARM_2
      004A47 E0               [24] 1273 	movx	a,@dptr
      004A48 FF               [12] 1274 	mov	r7,a
      004A49 BF FF 02         [24] 1275 	cjne	r7,#0xff,00248$
      004A4C 80 0B            [24] 1276 	sjmp	00101$
      004A4E                       1277 00248$:
      004A4E C0 07            [24] 1278 	push	ar7
      004A50 12 A5 F0         [24] 1279 	lcall	_get_repeat_key_count
      004A53 E5 82            [12] 1280 	mov	a, dpl
      004A55 D0 07            [24] 1281 	pop	ar7
      004A57 60 04            [24] 1282 	jz	00102$
      004A59                       1283 00101$:
      004A59 75 82 01         [24] 1284 	mov	dpl, #0x01
      004A5C 22               [24] 1285 	ret
      004A5D                       1286 00102$:
                                   1287 ;	keyboards/ajazz/ak820/ak820_tapping.c:154: if ((code >> 8) == 0x52 && ((uint8_t)code & 0xe0) == 0xa0) {
      004A5D 90 06 8C         [24] 1288 	mov	dptr,#_ak820_oneshot_process_code_10000_648
      004A60 E0               [24] 1289 	movx	a,@dptr
      004A61 FD               [12] 1290 	mov	r5,a
      004A62 A3               [24] 1291 	inc	dptr
      004A63 E0               [24] 1292 	movx	a,@dptr
      004A64 FB               [12] 1293 	mov	r3,a
      004A65 BB 52 02         [24] 1294 	cjne	r3,#0x52,00250$
      004A68 80 03            [24] 1295 	sjmp	00251$
      004A6A                       1296 00250$:
      004A6A 02 4B 0F         [24] 1297 	ljmp	00116$
      004A6D                       1298 00251$:
      004A6D 8D 04            [24] 1299 	mov	ar4,r5
      004A6F 53 04 E0         [24] 1300 	anl	ar4,#0xe0
      004A72 BC A0 02         [24] 1301 	cjne	r4,#0xa0,00252$
      004A75 80 03            [24] 1302 	sjmp	00253$
      004A77                       1303 00252$:
      004A77 02 4B 0F         [24] 1304 	ljmp	00116$
      004A7A                       1305 00253$:
                                   1306 ;	keyboards/ajazz/ak820/ak820_tapping.c:155: mods = code & 15;
      004A7A 8D 04            [24] 1307 	mov	ar4,r5
      004A7C 53 04 0F         [24] 1308 	anl	ar4,#0x0f
      004A7F 90 06 8E         [24] 1309 	mov	dptr,#_ak820_oneshot_process_mods_10000_649
      004A82 EC               [12] 1310 	mov	a,r4
      004A83 F0               [24] 1311 	movx	@dptr,a
                                   1312 ;	keyboards/ajazz/ak820/ak820_tapping.c:156: if (code & 16) mods <<= 4;
      004A84 ED               [12] 1313 	mov	a,r5
      004A85 30 E4 08         [24] 1314 	jnb	acc.4,00105$
      004A88 EC               [12] 1315 	mov	a,r4
      004A89 C4               [12] 1316 	swap	a
      004A8A 54 F0            [12] 1317 	anl	a,#0xf0
      004A8C 90 06 8E         [24] 1318 	mov	dptr,#_ak820_oneshot_process_mods_10000_649
      004A8F F0               [24] 1319 	movx	@dptr,a
      004A90                       1320 00105$:
                                   1321 ;	keyboards/ajazz/ak820/ak820_tapping.c:157: if (pressed) {
      004A90 90 06 8B         [24] 1322 	mov	dptr,#_ak820_oneshot_process_PARM_3
      004A93 E0               [24] 1323 	movx	a,@dptr
      004A94 60 2D            [24] 1324 	jz	00113$
                                   1325 ;	keyboards/ajazz/ak820/ak820_tapping.c:158: source_state[id] |= SOURCE_ONESHOT;
      004A96 12 4B 8B         [24] 1326 	lcall	_ak820_outline_0020
      004A99 43 04 08         [24] 1327 	orl	ar4,#0x08
      004A9C 12 46 84         [24] 1328 	lcall	_ak820_outline_0065
                                   1329 ;	keyboards/ajazz/ak820/ak820_tapping.c:159: source_state[id] &= ~SOURCE_ONESHOT_USED;
      004A9F 53 04 EF         [24] 1330 	anl	ar4,#0xef
      004AA2 12 46 84         [24] 1331 	lcall	_ak820_outline_0065
                                   1332 ;	keyboards/ajazz/ak820/ak820_tapping.c:160: if (ak820_oneshot_target != NONE) source_state[id] |= SOURCE_ONESHOT_USED;
      004AA5 90 0E 0B         [24] 1333 	mov	dptr,#_ak820_oneshot_target
      004AA8 E0               [24] 1334 	movx	a,@dptr
      004AA9 FC               [12] 1335 	mov	r4,a
      004AAA BC FF 02         [24] 1336 	cjne	r4,#0xff,00256$
      004AAD 80 09            [24] 1337 	sjmp	00107$
      004AAF                       1338 00256$:
      004AAF 12 4B DF         [24] 1339 	lcall	_ak820_outline_0078
      004AB2 43 04 10         [24] 1340 	orl	ar4,#0x10
      004AB5 12 46 84         [24] 1341 	lcall	_ak820_outline_0065
      004AB8                       1342 00107$:
                                   1343 ;	keyboards/ajazz/ak820/ak820_tapping.c:161: register_mods(mods);
      004AB8 90 06 8E         [24] 1344 	mov	dptr,#_ak820_oneshot_process_mods_10000_649
      004ABB E0               [24] 1345 	movx	a,@dptr
      004ABC F5 82            [12] 1346 	mov	dpl,a
      004ABE 12 7A 6B         [24] 1347 	lcall	_register_mods
      004AC1 80 48            [24] 1348 	sjmp	00114$
      004AC3                       1349 00113$:
                                   1350 ;	keyboards/ajazz/ak820/ak820_tapping.c:162: } else if (source_state[id] & SOURCE_ONESHOT) {
      004AC3 12 4B 8B         [24] 1351 	lcall	_ak820_outline_0020
      004AC6 30 E3 42         [24] 1352 	jnb	acc.3,00114$
                                   1353 ;	keyboards/ajazz/ak820/ak820_tapping.c:163: if (!(source_state[id] & SOURCE_ONESHOT_USED)) {
      004AC9 EC               [12] 1354 	mov	a,r4
      004ACA 20 E4 24         [24] 1355 	jb	acc.4,00109$
                                   1356 ;	keyboards/ajazz/ak820/ak820_tapping.c:164: add_owned_mods(mods & ~ak820_oneshot_mods);
      004ACD 90 06 88         [24] 1357 	mov	dptr,#_ak820_oneshot_mods
      004AD0 E0               [24] 1358 	movx	a,@dptr
      004AD1 F4               [12] 1359 	cpl	a
      004AD2 FC               [12] 1360 	mov	r4,a
      004AD3 90 06 8E         [24] 1361 	mov	dptr,#_ak820_oneshot_process_mods_10000_649
      004AD6 E0               [24] 1362 	movx	a,@dptr
      004AD7 FB               [12] 1363 	mov	r3,a
      004AD8 52 04            [12] 1364 	anl	ar4,a
      004ADA 8C 82            [24] 1365 	mov	dpl, r4
      004ADC C0 06            [24] 1366 	push	ar6
      004ADE C0 05            [24] 1367 	push	ar5
      004AE0 C0 03            [24] 1368 	push	ar3
      004AE2 12 80 F5         [24] 1369 	lcall	_add_owned_mods
      004AE5 D0 03            [24] 1370 	pop	ar3
      004AE7 D0 05            [24] 1371 	pop	ar5
      004AE9 D0 06            [24] 1372 	pop	ar6
                                   1373 ;	keyboards/ajazz/ak820/ak820_tapping.c:165: ak820_oneshot_mods |= mods;
      004AEB 90 06 88         [24] 1374 	mov	dptr,#_ak820_oneshot_mods
      004AEE E0               [24] 1375 	movx	a,@dptr
      004AEF 4B               [12] 1376 	orl	a,r3
      004AF0 F0               [24] 1377 	movx	@dptr,a
      004AF1                       1378 00109$:
                                   1379 ;	keyboards/ajazz/ak820/ak820_tapping.c:167: unregister_mods(mods);
      004AF1 90 06 8E         [24] 1380 	mov	dptr,#_ak820_oneshot_process_mods_10000_649
      004AF4 E0               [24] 1381 	movx	a,@dptr
      004AF5 F5 82            [12] 1382 	mov	dpl,a
      004AF7 C0 06            [24] 1383 	push	ar6
      004AF9 C0 05            [24] 1384 	push	ar5
      004AFB 12 7A 7F         [24] 1385 	lcall	_unregister_mods
      004AFE D0 05            [24] 1386 	pop	ar5
      004B00 D0 06            [24] 1387 	pop	ar6
                                   1388 ;	keyboards/ajazz/ak820/ak820_tapping.c:168: source_state[id] &= ~(SOURCE_ONESHOT | SOURCE_ONESHOT_USED);
      004B02 12 4B DF         [24] 1389 	lcall	_ak820_outline_0078
      004B05 53 04 E7         [24] 1390 	anl	ar4,#0xe7
      004B08 12 46 84         [24] 1391 	lcall	_ak820_outline_0065
      004B0B                       1392 00114$:
                                   1393 ;	keyboards/ajazz/ak820/ak820_tapping.c:170: return false;
      004B0B 75 82 00         [24] 1394 	mov	dpl, #0x00
      004B0E 22               [24] 1395 	ret
      004B0F                       1396 00116$:
                                   1397 ;	keyboards/ajazz/ak820/ak820_tapping.c:172: if (pressed && code > KC_TRANSPARENT &&
      004B0F 90 06 8B         [24] 1398 	mov	dptr,#_ak820_oneshot_process_PARM_3
      004B12 E0               [24] 1399 	movx	a,@dptr
      004B13 60 5C            [24] 1400 	jz	00124$
      004B15 90 06 8C         [24] 1401 	mov	dptr,#_ak820_oneshot_process_code_10000_648
      004B18 12 38 64         [24] 1402 	lcall	_ak820_outline_0080
      004B1B C3               [12] 1403 	clr	c
      004B1C 74 01            [12] 1404 	mov	a,#0x01
      004B1E 9D               [12] 1405 	subb	a,r5
      004B1F E4               [12] 1406 	clr	a
      004B20 9E               [12] 1407 	subb	a,r6
      004B21 50 4E            [24] 1408 	jnc	00124$
                                   1409 ;	free result
                                   1410 ;	keyboards/ajazz/ak820/ak820_tapping.c:173: !(code >= KC_LCTL && code <= KC_RGUI) &&
      004B23 C3               [12] 1411 	clr	c
      004B24 ED               [12] 1412 	mov	a,r5
      004B25 94 E0            [12] 1413 	subb	a,#0xe0
      004B27 EE               [12] 1414 	mov	a,r6
      004B28 94 00            [12] 1415 	subb	a,#0x00
      004B2A 40 07            [24] 1416 	jc	00129$
      004B2C 74 E7            [12] 1417 	mov	a,#0xe7
      004B2E 9D               [12] 1418 	subb	a,r5
      004B2F E4               [12] 1419 	clr	a
      004B30 9E               [12] 1420 	subb	a,r6
      004B31 50 3E            [24] 1421 	jnc	00124$
                                   1422 ;	free result
      004B33                       1423 00129$:
                                   1424 ;	keyboards/ajazz/ak820/ak820_tapping.c:174: !(code >= QK_TO && code <= QK_LAYER_TAP_TOGGLE_MAX)) {
      004B33 74 AE            [12] 1425 	mov	a,#0x100 - 0x52
      004B35 2E               [12] 1426 	add	a,r6
      004B36 50 09            [24] 1427 	jnc	00165$
      004B38 C3               [12] 1428 	clr	c
      004B39 74 DF            [12] 1429 	mov	a,#0xdf
      004B3B 9D               [12] 1430 	subb	a,r5
      004B3C 74 52            [12] 1431 	mov	a,#0x52
      004B3E 9E               [12] 1432 	subb	a,r6
      004B3F 50 30            [24] 1433 	jnc	00124$
                                   1434 ;	free result
                                   1435 ;	keyboards/ajazz/ak820/ak820_tapping.c:175: for (uint8_t i = 0; i < SOURCES; ++i)
      004B41                       1436 00165$:
      004B41 7E 00            [12] 1437 	mov	r6,#0x00
      004B43                       1438 00131$:
      004B43 BE 82 00         [24] 1439 	cjne	r6,#0x82,00265$
      004B46                       1440 00265$:
      004B46 50 12            [24] 1441 	jnc	00120$
                                   1442 ;	keyboards/ajazz/ak820/ak820_tapping.c:176: if (source_state[i] & SOURCE_ONESHOT) source_state[i] |= SOURCE_ONESHOT_USED;
      004B48 EE               [12] 1443 	mov	a,r6
      004B49 12 4B E6         [24] 1444 	lcall	_ak820_outline_0081
      004B4C 30 E3 08         [24] 1445 	jnb	acc.3,00132$
      004B4F 43 03 10         [24] 1446 	orl	ar3,#0x10
      004B52 12 38 97         [24] 1447 	lcall	_ak820_outline_0126
      004B55 EB               [12] 1448 	mov	a,r3
      004B56 F0               [24] 1449 	movx	@dptr,a
      004B57                       1450 00132$:
                                   1451 ;	keyboards/ajazz/ak820/ak820_tapping.c:175: for (uint8_t i = 0; i < SOURCES; ++i)
      004B57 0E               [12] 1452 	inc	r6
      004B58 80 E9            [24] 1453 	sjmp	00131$
      004B5A                       1454 00120$:
                                   1455 ;	keyboards/ajazz/ak820/ak820_tapping.c:177: if (ak820_oneshot_mods) {
      004B5A 90 06 88         [24] 1456 	mov	dptr,#_ak820_oneshot_mods
      004B5D E0               [24] 1457 	movx	a,@dptr
      004B5E FE               [12] 1458 	mov	r6,a
      004B5F E0               [24] 1459 	movx	a,@dptr
      004B60 60 0F            [24] 1460 	jz	00124$
                                   1461 ;	keyboards/ajazz/ak820/ak820_tapping.c:178: ak820_oneshot_consumed = ak820_oneshot_mods;
      004B62 90 06 89         [24] 1462 	mov	dptr,#_ak820_oneshot_consumed
      004B65 EE               [12] 1463 	mov	a,r6
      004B66 F0               [24] 1464 	movx	@dptr,a
                                   1465 ;	keyboards/ajazz/ak820/ak820_tapping.c:179: ak820_oneshot_target = id;
      004B67 90 0E 0B         [24] 1466 	mov	dptr,#_ak820_oneshot_target
      004B6A EF               [12] 1467 	mov	a,r7
      004B6B F0               [24] 1468 	movx	@dptr,a
                                   1469 ;	keyboards/ajazz/ak820/ak820_tapping.c:180: ak820_oneshot_mods = 0;
      004B6C 90 06 88         [24] 1470 	mov	dptr,#_ak820_oneshot_mods
      004B6F E4               [12] 1471 	clr	a
      004B70 F0               [24] 1472 	movx	@dptr,a
      004B71                       1473 00124$:
                                   1474 ;	keyboards/ajazz/ak820/ak820_tapping.c:183: return true;
      004B71 75 82 01         [24] 1475 	mov	dpl, #0x01
                                   1476 ;	keyboards/ajazz/ak820/ak820_tapping.c:184: }
      004B74 22               [24] 1477 	ret
                                   1478 	.area CSEG    (CODE)
                                   1479 	.area CONST   (CODE)
                                   1480 	.area XINIT   (CODE)
      00C4CD                       1481 __xinit__pending:
      00C4CD FF                    1482 	.db #0xff	; 255
      00C4CE                       1483 __xinit__ak820_oneshot_target:
      00C4CE FF                    1484 	.db #0xff	; 255
                                   1485 	.area CABS    (ABS,CODE)
                                   1486 
                                   1487 ; Experimental exact instruction outlining.
                                   1488 	.globl _ak820_outline_0009
                                   1489 	.globl _ak820_outline_0010
                                   1490 	.globl _ak820_outline_0012
                                   1491 	.globl _ak820_outline_0015
                                   1492 	.globl _ak820_outline_0017
                                   1493 	.globl _ak820_outline_0020
                                   1494 	.globl _ak820_outline_0022
                                   1495 	.globl _ak820_outline_0025
                                   1496 	.globl _ak820_outline_0032
                                   1497 	.globl _ak820_outline_0033
                                   1498 	.globl _ak820_outline_0034
                                   1499 	.globl _ak820_outline_0037
                                   1500 	.globl _ak820_outline_0053
                                   1501 	.globl _ak820_outline_0057
                                   1502 	.globl _ak820_outline_0060
                                   1503 	.globl _ak820_outline_0065
                                   1504 	.globl _ak820_outline_0076
                                   1505 	.globl _ak820_outline_0077
                                   1506 	.globl _ak820_outline_0078
                                   1507 	.globl _ak820_outline_0080
                                   1508 	.globl _ak820_outline_0081
                                   1509 	.globl _ak820_outline_0100
                                   1510 	.globl _ak820_outline_0105
                                   1511 	.globl _ak820_outline_0110
                                   1512 	.globl _ak820_outline_0111
                                   1513 	.globl _ak820_outline_0120
                                   1514 	.globl _ak820_outline_0125
                                   1515 	.globl _ak820_outline_0126
                                   1516 	.globl _ak820_outline_0137
                                   1517 	.globl _ak820_outline_0146
                                   1518 	.globl _ak820_outline_0157
                                   1519 	.globl _ak820_outline_0160
                                   1520 	.globl _ak820_outline_0192
                                   1521 
                                   1522 	.area CSEG (CODE)
                                   1523 ; function ak820_outline_0009
      004B75                       1524 _ak820_outline_0009:
      004B75 E0               [24] 1525 	movx	a,@dptr
      004B76 FE               [12] 1526 	mov	r6,a
      004B77 A3               [24] 1527 	inc	dptr
      004B78 E0               [24] 1528 	movx	a,@dptr
      004B79 FF               [12] 1529 	mov	r7,a
      004B7A 8E 04            [24] 1530 	mov	ar4,r6
      004B7C 8F 05            [24] 1531 	mov	ar5,r7
      004B7E 22               [24] 1532 	ret
                                   1533 
                                   1534 	.area CSEG (CODE)
                                   1535 ; function ak820_outline_0015
      004B7F                       1536 _ak820_outline_0015:
      004B7F 74 05            [12] 1537 	mov	a,#0x05
      004B81 2E               [12] 1538 	add	a,r6
      004B82 FB               [12] 1539 	mov	r3,a
      004B83 E4               [12] 1540 	clr	a
      004B84 3F               [12] 1541 	addc	a,r7
      004B85 FC               [12] 1542 	mov	r4,a
      004B86 8B 82            [24] 1543 	mov	dpl,r3
      004B88 8C 83            [24] 1544 	mov	dph,r4
      004B8A 22               [24] 1545 	ret
                                   1546 
                                   1547 	.area CSEG (CODE)
                                   1548 ; function ak820_outline_0020
      004B8B                       1549 _ak820_outline_0020:
      004B8B EF               [12] 1550 	mov	a,r7
      004B8C 24 F4            [12] 1551 	add	a,#_source_state
      004B8E FD               [12] 1552 	mov	r5,a
      004B8F E4               [12] 1553 	clr	a
      004B90 34 05            [12] 1554 	addc	a,#(_source_state>>8)
      004B92 FE               [12] 1555 	mov	r6,a
      004B93 8D 82            [24] 1556 	mov	dpl,r5
      004B95 8E 83            [24] 1557 	mov	dph,r6
      004B97 E0               [24] 1558 	movx	a,@dptr
      004B98 FC               [12] 1559 	mov	r4,a
      004B99 22               [24] 1560 	ret
                                   1561 
                                   1562 	.area CSEG (CODE)
                                   1563 ; function ak820_outline_0025
      004B9A                       1564 _ak820_outline_0025:
      004B9A 90 0D FA         [24] 1565 	mov	dptr,#___memcpy_PARM_2
      004B9D EC               [12] 1566 	mov	a,r4
      004B9E F0               [24] 1567 	movx	@dptr,a
      004B9F ED               [12] 1568 	mov	a,r5
      004BA0 A3               [24] 1569 	inc	dptr
      004BA1 F0               [24] 1570 	movx	@dptr,a
      004BA2 E4               [12] 1571 	clr	a
      004BA3 A3               [24] 1572 	inc	dptr
      004BA4 F0               [24] 1573 	movx	@dptr,a
      004BA5 90 0D FD         [24] 1574 	mov	dptr,#___memcpy_PARM_3
      004BA8 74 02            [12] 1575 	mov	a,#0x02
      004BAA F0               [24] 1576 	movx	@dptr,a
      004BAB E4               [12] 1577 	clr	a
      004BAC A3               [24] 1578 	inc	dptr
      004BAD F0               [24] 1579 	movx	@dptr,a
      004BAE 90 06 7A         [24] 1580 	mov	dptr,#_ak820_tapping_source_PARM_1
      004BB1 F5 F0            [12] 1581 	mov	b,a
      004BB3 22               [24] 1582 	ret
                                   1583 
                                   1584 	.area CSEG (CODE)
                                   1585 ; function ak820_outline_0033
      004BB4                       1586 _ak820_outline_0033:
      004BB4 2E               [12] 1587 	add	a,r6
      004BB5 FA               [12] 1588 	mov	r2,a
      004BB6 E4               [12] 1589 	clr	a
      004BB7 3F               [12] 1590 	addc	a,r7
      004BB8 FB               [12] 1591 	mov	r3,a
      004BB9 8A 82            [24] 1592 	mov	dpl,r2
      004BBB 8B 83            [24] 1593 	mov	dph,r3
      004BBD E0               [24] 1594 	movx	a,@dptr
      004BBE 22               [24] 1595 	ret
                                   1596 
                                   1597 	.area CSEG (CODE)
                                   1598 ; function ak820_outline_0034
      004BBF                       1599 _ak820_outline_0034:
      004BBF 2E               [12] 1600 	add	a,r6
      004BC0 FC               [12] 1601 	mov	r4,a
      004BC1 E4               [12] 1602 	clr	a
      004BC2 3F               [12] 1603 	addc	a,r7
      004BC3 FD               [12] 1604 	mov	r5,a
      004BC4 8C 82            [24] 1605 	mov	dpl,r4
      004BC6 8D 83            [24] 1606 	mov	dph,r5
      004BC8 E0               [24] 1607 	movx	a,@dptr
      004BC9 22               [24] 1608 	ret
                                   1609 
                                   1610 	.area CSEG (CODE)
                                   1611 ; function ak820_outline_0057
      004BCA                       1612 _ak820_outline_0057:
      004BCA FC               [12] 1613 	mov	r4,a
      004BCB 8B 82            [24] 1614 	mov	dpl,r3
      004BCD 8C 83            [24] 1615 	mov	dph,r4
      004BCF E0               [24] 1616 	movx	a,@dptr
      004BD0 FA               [12] 1617 	mov	r2,a
      004BD1 22               [24] 1618 	ret
                                   1619 
                                   1620 	.area CSEG (CODE)
                                   1621 ; function ak820_outline_0060
      004BD2                       1622 _ak820_outline_0060:
      004BD2 EE               [12] 1623 	mov	a,r6
      004BD3 F0               [24] 1624 	movx	@dptr,a
      004BD4 EF               [12] 1625 	mov	a,r7
      004BD5 A3               [24] 1626 	inc	dptr
      004BD6 F0               [24] 1627 	movx	@dptr,a
      004BD7 22               [24] 1628 	ret
                                   1629 
                                   1630 	.area CSEG (CODE)
                                   1631 ; function ak820_outline_0077
      004BD8                       1632 _ak820_outline_0077:
      004BD8 8E 00            [24] 1633 	mov	ar0,r6
      004BDA 8F 01            [24] 1634 	mov	ar1,r7
      004BDC 7A 00            [12] 1635 	mov	r2,#0x00
      004BDE 22               [24] 1636 	ret
                                   1637 
                                   1638 	.area CSEG (CODE)
                                   1639 ; function ak820_outline_0078
      004BDF                       1640 _ak820_outline_0078:
      004BDF 8D 82            [24] 1641 	mov	dpl,r5
      004BE1 8E 83            [24] 1642 	mov	dph,r6
      004BE3 E0               [24] 1643 	movx	a,@dptr
      004BE4 FC               [12] 1644 	mov	r4,a
      004BE5 22               [24] 1645 	ret
                                   1646 
                                   1647 	.area CSEG (CODE)
                                   1648 ; function ak820_outline_0081
      004BE6                       1649 _ak820_outline_0081:
      004BE6 24 F4            [12] 1650 	add	a,#_source_state
      004BE8 FC               [12] 1651 	mov	r4,a
      004BE9 E4               [12] 1652 	clr	a
      004BEA 34 05            [12] 1653 	addc	a,#(_source_state>>8)
      004BEC FD               [12] 1654 	mov	r5,a
      004BED 8C 82            [24] 1655 	mov	dpl,r4
      004BEF 8D 83            [24] 1656 	mov	dph,r5
      004BF1 E0               [24] 1657 	movx	a,@dptr
      004BF2 FB               [12] 1658 	mov	r3,a
      004BF3 22               [24] 1659 	ret
                                   1660 
                                   1661 	.area CSEG (CODE)
                                   1662 ; function ak820_outline_0100
      004BF4                       1663 _ak820_outline_0100:
      004BF4 74 04            [12] 1664 	mov	a,#0x04
      004BF6 2E               [12] 1665 	add	a,r6
      004BF7 FB               [12] 1666 	mov	r3,a
      004BF8 E4               [12] 1667 	clr	a
      004BF9 3F               [12] 1668 	addc	a,r7
      004BFA FC               [12] 1669 	mov	r4,a
      004BFB 8B 82            [24] 1670 	mov	dpl,r3
      004BFD 8C 83            [24] 1671 	mov	dph,r4
      004BFF E0               [24] 1672 	movx	a,@dptr
      004C00 22               [24] 1673 	ret
                                   1674 
                                   1675 	.area CSEG (CODE)
                                   1676 ; function ak820_outline_0157
      004C01                       1677 _ak820_outline_0157:
      004C01 90 0E 0A         [24] 1678 	mov	dptr,#_pending
      004C04 74 FF            [12] 1679 	mov	a,#0xff
      004C06 F0               [24] 1680 	movx	@dptr,a
      004C07 22               [24] 1681 	ret
