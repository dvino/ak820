                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_tapping
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _get_repeat_key_count
                                     12 	.globl _del_owned_mods
                                     13 	.globl _add_owned_mods
                                     14 	.globl _send_keyboard_report
                                     15 	.globl _layer_hold_off
                                     16 	.globl _layer_hold_on
                                     17 	.globl _unregister_mods
                                     18 	.globl _register_mods
                                     19 	.globl _process_record
                                     20 	.globl _ADC_START
                                     21 	.globl _S0_R_FIFO
                                     22 	.globl _S0_T_FIFO
                                     23 	.globl _S0_FREE
                                     24 	.globl _S0_IF_BYTE
                                     25 	.globl _S0_IF_FIRST
                                     26 	.globl _S0_IF_OV
                                     27 	.globl _S0_FST_ACT
                                     28 	.globl _CP_RL2
                                     29 	.globl _C_T2
                                     30 	.globl _TR2
                                     31 	.globl _EXEN2
                                     32 	.globl _TCLK
                                     33 	.globl _RCLK
                                     34 	.globl _EXF2
                                     35 	.globl _CAP1F
                                     36 	.globl _TF2
                                     37 	.globl _RI
                                     38 	.globl _TI
                                     39 	.globl _RB8
                                     40 	.globl _TB8
                                     41 	.globl _REN
                                     42 	.globl _SM2
                                     43 	.globl _SM1
                                     44 	.globl _SM0
                                     45 	.globl _IT0
                                     46 	.globl _IE0
                                     47 	.globl _IT1
                                     48 	.globl _IE1
                                     49 	.globl _TR0
                                     50 	.globl _TF0
                                     51 	.globl _TR1
                                     52 	.globl _TF1
                                     53 	.globl _P4_0
                                     54 	.globl _P4_1
                                     55 	.globl _P4_2
                                     56 	.globl _P4_3
                                     57 	.globl _P4_4
                                     58 	.globl _P4_5
                                     59 	.globl _P4_6
                                     60 	.globl _RXD
                                     61 	.globl _TXD
                                     62 	.globl _INT0
                                     63 	.globl _INT1
                                     64 	.globl _T0
                                     65 	.globl _T1
                                     66 	.globl _MOSI1
                                     67 	.globl _MISO1
                                     68 	.globl _SCK1
                                     69 	.globl _P3_0
                                     70 	.globl _P3_1
                                     71 	.globl _P3_2
                                     72 	.globl _P3_3
                                     73 	.globl _P3_4
                                     74 	.globl _P3_5
                                     75 	.globl _P3_6
                                     76 	.globl _P3_7
                                     77 	.globl _CAP1_
                                     78 	.globl _T2_
                                     79 	.globl _CAP2_
                                     80 	.globl _T2EX_
                                     81 	.globl _RXD1
                                     82 	.globl _TXD1
                                     83 	.globl _P2_0
                                     84 	.globl _P2_1
                                     85 	.globl _P2_2
                                     86 	.globl _P2_3
                                     87 	.globl _P2_4
                                     88 	.globl _P2_5
                                     89 	.globl _P2_6
                                     90 	.globl _P2_7
                                     91 	.globl _AIN0
                                     92 	.globl _AIN1
                                     93 	.globl _AIN2
                                     94 	.globl _AIN3
                                     95 	.globl _AIN4
                                     96 	.globl _AIN5
                                     97 	.globl _AIN6
                                     98 	.globl _AIN7
                                     99 	.globl _CAP1
                                    100 	.globl _T2
                                    101 	.globl _CAP2
                                    102 	.globl _T2EX
                                    103 	.globl _INT0_
                                    104 	.globl _SCS
                                    105 	.globl _MOSI
                                    106 	.globl _MISO
                                    107 	.globl _SCK
                                    108 	.globl _RXD1_
                                    109 	.globl _TXD1_
                                    110 	.globl _P1_0
                                    111 	.globl _P1_1
                                    112 	.globl _P1_2
                                    113 	.globl _P1_3
                                    114 	.globl _P1_4
                                    115 	.globl _P1_5
                                    116 	.globl _P1_6
                                    117 	.globl _P1_7
                                    118 	.globl _AIN8
                                    119 	.globl _AIN9
                                    120 	.globl _AIN10
                                    121 	.globl _AIN11
                                    122 	.globl _AIN12
                                    123 	.globl _AIN13
                                    124 	.globl _RXD_
                                    125 	.globl _TXD_
                                    126 	.globl _SCL0
                                    127 	.globl _SDA0
                                    128 	.globl _P0_0
                                    129 	.globl _P0_1
                                    130 	.globl _P0_2
                                    131 	.globl _P0_3
                                    132 	.globl _P0_4
                                    133 	.globl _P0_5
                                    134 	.globl _P0_6
                                    135 	.globl _P0_7
                                    136 	.globl _IE_SPI0
                                    137 	.globl _IE_USB
                                    138 	.globl _IE_ADC
                                    139 	.globl _IE_UART1
                                    140 	.globl _IE_PWM_I2C
                                    141 	.globl _IE_GPIO
                                    142 	.globl _IE_WDOG
                                    143 	.globl _PX0
                                    144 	.globl _PT0
                                    145 	.globl _PX1
                                    146 	.globl _PT1
                                    147 	.globl _PS
                                    148 	.globl _PT2
                                    149 	.globl _PL_FLAG
                                    150 	.globl _PH_FLAG
                                    151 	.globl _EX0
                                    152 	.globl _ET0
                                    153 	.globl _EX1
                                    154 	.globl _ET1
                                    155 	.globl _ES
                                    156 	.globl _ET2
                                    157 	.globl _E_DIS
                                    158 	.globl _EA
                                    159 	.globl _P
                                    160 	.globl _F1
                                    161 	.globl _OV
                                    162 	.globl _RS0
                                    163 	.globl _RS1
                                    164 	.globl _F0
                                    165 	.globl _AC
                                    166 	.globl _CY
                                    167 	.globl _I2CS_INT_ST
                                    168 	.globl _I2CX_INT
                                    169 	.globl _LED_STATUS
                                    170 	.globl _LED_DMA_H
                                    171 	.globl _LED_DMA_L
                                    172 	.globl _LED_DMA
                                    173 	.globl _LED_PWM_OE
                                    174 	.globl _LED_COMMON
                                    175 	.globl _ADC_CHAN
                                    176 	.globl _ADC_DAT_H
                                    177 	.globl _ADC_DAT_L
                                    178 	.globl _ADC_DAT
                                    179 	.globl _ADC_CTRL
                                    180 	.globl _SPI1_CK_SE
                                    181 	.globl _SPI1_CTRL
                                    182 	.globl _SPI1_DATA
                                    183 	.globl _SPI1_STAT
                                    184 	.globl _SIF1
                                    185 	.globl _SBAUD1
                                    186 	.globl _SBUF1
                                    187 	.globl _SCON1
                                    188 	.globl _SPI0_SETUP
                                    189 	.globl _SPI0_CK_SE
                                    190 	.globl _SPI0_CTRL
                                    191 	.globl _SPI0_DATA
                                    192 	.globl _SPI0_STAT
                                    193 	.globl _T2CAP1H
                                    194 	.globl _T2CAP1L
                                    195 	.globl _T2CAP1
                                    196 	.globl _TH2
                                    197 	.globl _TL2
                                    198 	.globl _T2COUNT
                                    199 	.globl _RCAP2H
                                    200 	.globl _RCAP2L
                                    201 	.globl _RCAP2
                                    202 	.globl _T2MOD
                                    203 	.globl _T2CON
                                    204 	.globl _SBUF
                                    205 	.globl _SCON
                                    206 	.globl _TH1
                                    207 	.globl _TH0
                                    208 	.globl _TL1
                                    209 	.globl _TL0
                                    210 	.globl _TMOD
                                    211 	.globl _TCON
                                    212 	.globl _XBUS_AUX
                                    213 	.globl _P7
                                    214 	.globl _P6_DIR
                                    215 	.globl _P6_OUT_PU
                                    216 	.globl _P6_IN
                                    217 	.globl _P5_DIR
                                    218 	.globl _P5_OUT_PU
                                    219 	.globl _P5_IN
                                    220 	.globl _P4_LED_KEY
                                    221 	.globl _P4_DIR_PU
                                    222 	.globl _P4_MOD_OC
                                    223 	.globl _P4
                                    224 	.globl _P3_DIR_PU
                                    225 	.globl _P3_MOD_OC
                                    226 	.globl _P3
                                    227 	.globl _P2_DIR_PU
                                    228 	.globl _P2_MOD_OC
                                    229 	.globl _P2
                                    230 	.globl _P1_DIR_PU
                                    231 	.globl _P1_MOD_OC
                                    232 	.globl _P1
                                    233 	.globl _P0_DIR_PU
                                    234 	.globl _P0_MOD_OC
                                    235 	.globl _P0
                                    236 	.globl _ROM_CTRL
                                    237 	.globl _ROM_DATA_HH
                                    238 	.globl _ROM_DATA_HL
                                    239 	.globl _ROM_DATA_HI
                                    240 	.globl _ROM_ADDR_H
                                    241 	.globl _ROM_ADDR_L
                                    242 	.globl _ROM_ADDR
                                    243 	.globl _GPIO_IE
                                    244 	.globl _IP_EX
                                    245 	.globl _IE_EX
                                    246 	.globl _IP
                                    247 	.globl _IE
                                    248 	.globl _WDOG_COUNT
                                    249 	.globl _RESET_KEEP
                                    250 	.globl _WAKE_CTRL
                                    251 	.globl _CLOCK_CFG
                                    252 	.globl _POWER_CFG
                                    253 	.globl _PCON
                                    254 	.globl _GLOBAL_CFG
                                    255 	.globl _SAFE_MOD
                                    256 	.globl _DPH
                                    257 	.globl _DPL
                                    258 	.globl _SP
                                    259 	.globl _A_INV
                                    260 	.globl _B
                                    261 	.globl _ACC
                                    262 	.globl _PSW
                                    263 	.globl _ak820_oneshot_target
                                    264 	.globl _ak820_oneshot_process_PARM_3
                                    265 	.globl _ak820_oneshot_process_PARM_2
                                    266 	.globl _ak820_oneshot_consumed
                                    267 	.globl _ak820_oneshot_mods
                                    268 	.globl _ak820_tapping_source_PARM_1
                                    269 	.globl _ak820_tapping_source
                                    270 	.globl _ak820_tapping_before
                                    271 	.globl _ak820_tapping_process
                                    272 	.globl _ak820_tapping_cancel
                                    273 	.globl _ak820_oneshot_process
                                    274 ;--------------------------------------------------------
                                    275 ; special function registers
                                    276 ;--------------------------------------------------------
                                    277 	.area RSEG    (ABS,DATA)
      000000                        278 	.org 0x0000
                           0000D0   279 _PSW	=	0x00d0
                           0000E0   280 _ACC	=	0x00e0
                           0000F0   281 _B	=	0x00f0
                           0000FD   282 _A_INV	=	0x00fd
                           000081   283 _SP	=	0x0081
                           000082   284 _DPL	=	0x0082
                           000083   285 _DPH	=	0x0083
                           0000A1   286 _SAFE_MOD	=	0x00a1
                           0000B1   287 _GLOBAL_CFG	=	0x00b1
                           000087   288 _PCON	=	0x0087
                           0000BA   289 _POWER_CFG	=	0x00ba
                           0000B9   290 _CLOCK_CFG	=	0x00b9
                           0000A9   291 _WAKE_CTRL	=	0x00a9
                           0000FE   292 _RESET_KEEP	=	0x00fe
                           0000FF   293 _WDOG_COUNT	=	0x00ff
                           0000A8   294 _IE	=	0x00a8
                           0000B8   295 _IP	=	0x00b8
                           0000E8   296 _IE_EX	=	0x00e8
                           0000E9   297 _IP_EX	=	0x00e9
                           0000B2   298 _GPIO_IE	=	0x00b2
                           008584   299 _ROM_ADDR	=	0x8584
                           000084   300 _ROM_ADDR_L	=	0x0084
                           000085   301 _ROM_ADDR_H	=	0x0085
                           008F8E   302 _ROM_DATA_HI	=	0x8f8e
                           00008E   303 _ROM_DATA_HL	=	0x008e
                           00008F   304 _ROM_DATA_HH	=	0x008f
                           000086   305 _ROM_CTRL	=	0x0086
                           000080   306 _P0	=	0x0080
                           0000C4   307 _P0_MOD_OC	=	0x00c4
                           0000C5   308 _P0_DIR_PU	=	0x00c5
                           000090   309 _P1	=	0x0090
                           000092   310 _P1_MOD_OC	=	0x0092
                           000093   311 _P1_DIR_PU	=	0x0093
                           0000A0   312 _P2	=	0x00a0
                           000094   313 _P2_MOD_OC	=	0x0094
                           000095   314 _P2_DIR_PU	=	0x0095
                           0000B0   315 _P3	=	0x00b0
                           000096   316 _P3_MOD_OC	=	0x0096
                           000097   317 _P3_DIR_PU	=	0x0097
                           0000C0   318 _P4	=	0x00c0
                           0000C2   319 _P4_MOD_OC	=	0x00c2
                           0000C3   320 _P4_DIR_PU	=	0x00c3
                           0000C1   321 _P4_LED_KEY	=	0x00c1
                           0000AA   322 _P5_IN	=	0x00aa
                           0000AB   323 _P5_OUT_PU	=	0x00ab
                           0000AC   324 _P5_DIR	=	0x00ac
                           0000AD   325 _P6_IN	=	0x00ad
                           0000AE   326 _P6_OUT_PU	=	0x00ae
                           0000AF   327 _P6_DIR	=	0x00af
                           0000F1   328 _P7	=	0x00f1
                           0000A2   329 _XBUS_AUX	=	0x00a2
                           000088   330 _TCON	=	0x0088
                           000089   331 _TMOD	=	0x0089
                           00008A   332 _TL0	=	0x008a
                           00008B   333 _TL1	=	0x008b
                           00008C   334 _TH0	=	0x008c
                           00008D   335 _TH1	=	0x008d
                           000098   336 _SCON	=	0x0098
                           000099   337 _SBUF	=	0x0099
                           0000C8   338 _T2CON	=	0x00c8
                           0000C9   339 _T2MOD	=	0x00c9
                           00CBCA   340 _RCAP2	=	0xcbca
                           0000CA   341 _RCAP2L	=	0x00ca
                           0000CB   342 _RCAP2H	=	0x00cb
                           00CDCC   343 _T2COUNT	=	0xcdcc
                           0000CC   344 _TL2	=	0x00cc
                           0000CD   345 _TH2	=	0x00cd
                           00CFCE   346 _T2CAP1	=	0xcfce
                           0000CE   347 _T2CAP1L	=	0x00ce
                           0000CF   348 _T2CAP1H	=	0x00cf
                           0000F8   349 _SPI0_STAT	=	0x00f8
                           0000F9   350 _SPI0_DATA	=	0x00f9
                           0000FA   351 _SPI0_CTRL	=	0x00fa
                           0000FB   352 _SPI0_CK_SE	=	0x00fb
                           0000FC   353 _SPI0_SETUP	=	0x00fc
                           0000BC   354 _SCON1	=	0x00bc
                           0000BD   355 _SBUF1	=	0x00bd
                           0000BE   356 _SBAUD1	=	0x00be
                           0000BF   357 _SIF1	=	0x00bf
                           0000B4   358 _SPI1_STAT	=	0x00b4
                           0000B5   359 _SPI1_DATA	=	0x00b5
                           0000B6   360 _SPI1_CTRL	=	0x00b6
                           0000B7   361 _SPI1_CK_SE	=	0x00b7
                           0000F3   362 _ADC_CTRL	=	0x00f3
                           00F5F4   363 _ADC_DAT	=	0xf5f4
                           0000F4   364 _ADC_DAT_L	=	0x00f4
                           0000F5   365 _ADC_DAT_H	=	0x00f5
                           0000F6   366 _ADC_CHAN	=	0x00f6
                           0000A6   367 _LED_COMMON	=	0x00a6
                           0000A7   368 _LED_PWM_OE	=	0x00a7
                           00C7C6   369 _LED_DMA	=	0xc7c6
                           0000C6   370 _LED_DMA_L	=	0x00c6
                           0000C7   371 _LED_DMA_H	=	0x00c7
                           0000F7   372 _LED_STATUS	=	0x00f7
                           0000B3   373 _I2CX_INT	=	0x00b3
                           0000BB   374 _I2CS_INT_ST	=	0x00bb
                                    375 ;--------------------------------------------------------
                                    376 ; special function bits
                                    377 ;--------------------------------------------------------
                                    378 	.area RSEG    (ABS,DATA)
      000000                        379 	.org 0x0000
                           0000D7   380 _CY	=	0x00d7
                           0000D6   381 _AC	=	0x00d6
                           0000D5   382 _F0	=	0x00d5
                           0000D4   383 _RS1	=	0x00d4
                           0000D3   384 _RS0	=	0x00d3
                           0000D2   385 _OV	=	0x00d2
                           0000D1   386 _F1	=	0x00d1
                           0000D0   387 _P	=	0x00d0
                           0000AF   388 _EA	=	0x00af
                           0000AE   389 _E_DIS	=	0x00ae
                           0000AD   390 _ET2	=	0x00ad
                           0000AC   391 _ES	=	0x00ac
                           0000AB   392 _ET1	=	0x00ab
                           0000AA   393 _EX1	=	0x00aa
                           0000A9   394 _ET0	=	0x00a9
                           0000A8   395 _EX0	=	0x00a8
                           0000BF   396 _PH_FLAG	=	0x00bf
                           0000BE   397 _PL_FLAG	=	0x00be
                           0000BD   398 _PT2	=	0x00bd
                           0000BC   399 _PS	=	0x00bc
                           0000BB   400 _PT1	=	0x00bb
                           0000BA   401 _PX1	=	0x00ba
                           0000B9   402 _PT0	=	0x00b9
                           0000B8   403 _PX0	=	0x00b8
                           0000EF   404 _IE_WDOG	=	0x00ef
                           0000EE   405 _IE_GPIO	=	0x00ee
                           0000ED   406 _IE_PWM_I2C	=	0x00ed
                           0000EC   407 _IE_UART1	=	0x00ec
                           0000EB   408 _IE_ADC	=	0x00eb
                           0000E9   409 _IE_USB	=	0x00e9
                           0000E8   410 _IE_SPI0	=	0x00e8
                           000087   411 _P0_7	=	0x0087
                           000086   412 _P0_6	=	0x0086
                           000085   413 _P0_5	=	0x0085
                           000084   414 _P0_4	=	0x0084
                           000083   415 _P0_3	=	0x0083
                           000082   416 _P0_2	=	0x0082
                           000081   417 _P0_1	=	0x0081
                           000080   418 _P0_0	=	0x0080
                           000081   419 _SDA0	=	0x0081
                           000080   420 _SCL0	=	0x0080
                           000083   421 _TXD_	=	0x0083
                           000082   422 _RXD_	=	0x0082
                           000085   423 _AIN13	=	0x0085
                           000084   424 _AIN12	=	0x0084
                           000083   425 _AIN11	=	0x0083
                           000082   426 _AIN10	=	0x0082
                           000081   427 _AIN9	=	0x0081
                           000080   428 _AIN8	=	0x0080
                           000097   429 _P1_7	=	0x0097
                           000096   430 _P1_6	=	0x0096
                           000095   431 _P1_5	=	0x0095
                           000094   432 _P1_4	=	0x0094
                           000093   433 _P1_3	=	0x0093
                           000092   434 _P1_2	=	0x0092
                           000091   435 _P1_1	=	0x0091
                           000090   436 _P1_0	=	0x0090
                           000097   437 _TXD1_	=	0x0097
                           000096   438 _RXD1_	=	0x0096
                           000097   439 _SCK	=	0x0097
                           000096   440 _MISO	=	0x0096
                           000095   441 _MOSI	=	0x0095
                           000094   442 _SCS	=	0x0094
                           000092   443 _INT0_	=	0x0092
                           000091   444 _T2EX	=	0x0091
                           000091   445 _CAP2	=	0x0091
                           000090   446 _T2	=	0x0090
                           000090   447 _CAP1	=	0x0090
                           000097   448 _AIN7	=	0x0097
                           000096   449 _AIN6	=	0x0096
                           000095   450 _AIN5	=	0x0095
                           000094   451 _AIN4	=	0x0094
                           000093   452 _AIN3	=	0x0093
                           000092   453 _AIN2	=	0x0092
                           000091   454 _AIN1	=	0x0091
                           000090   455 _AIN0	=	0x0090
                           0000A7   456 _P2_7	=	0x00a7
                           0000A6   457 _P2_6	=	0x00a6
                           0000A5   458 _P2_5	=	0x00a5
                           0000A4   459 _P2_4	=	0x00a4
                           0000A3   460 _P2_3	=	0x00a3
                           0000A2   461 _P2_2	=	0x00a2
                           0000A1   462 _P2_1	=	0x00a1
                           0000A0   463 _P2_0	=	0x00a0
                           0000A7   464 _TXD1	=	0x00a7
                           0000A6   465 _RXD1	=	0x00a6
                           0000A5   466 _T2EX_	=	0x00a5
                           0000A5   467 _CAP2_	=	0x00a5
                           0000A4   468 _T2_	=	0x00a4
                           0000A4   469 _CAP1_	=	0x00a4
                           0000B7   470 _P3_7	=	0x00b7
                           0000B6   471 _P3_6	=	0x00b6
                           0000B5   472 _P3_5	=	0x00b5
                           0000B4   473 _P3_4	=	0x00b4
                           0000B3   474 _P3_3	=	0x00b3
                           0000B2   475 _P3_2	=	0x00b2
                           0000B1   476 _P3_1	=	0x00b1
                           0000B0   477 _P3_0	=	0x00b0
                           0000B7   478 _SCK1	=	0x00b7
                           0000B6   479 _MISO1	=	0x00b6
                           0000B5   480 _MOSI1	=	0x00b5
                           0000B5   481 _T1	=	0x00b5
                           0000B4   482 _T0	=	0x00b4
                           0000B3   483 _INT1	=	0x00b3
                           0000B2   484 _INT0	=	0x00b2
                           0000B1   485 _TXD	=	0x00b1
                           0000B0   486 _RXD	=	0x00b0
                           0000C6   487 _P4_6	=	0x00c6
                           0000C5   488 _P4_5	=	0x00c5
                           0000C4   489 _P4_4	=	0x00c4
                           0000C3   490 _P4_3	=	0x00c3
                           0000C2   491 _P4_2	=	0x00c2
                           0000C1   492 _P4_1	=	0x00c1
                           0000C0   493 _P4_0	=	0x00c0
                           00008F   494 _TF1	=	0x008f
                           00008E   495 _TR1	=	0x008e
                           00008D   496 _TF0	=	0x008d
                           00008C   497 _TR0	=	0x008c
                           00008B   498 _IE1	=	0x008b
                           00008A   499 _IT1	=	0x008a
                           000089   500 _IE0	=	0x0089
                           000088   501 _IT0	=	0x0088
                           00009F   502 _SM0	=	0x009f
                           00009E   503 _SM1	=	0x009e
                           00009D   504 _SM2	=	0x009d
                           00009C   505 _REN	=	0x009c
                           00009B   506 _TB8	=	0x009b
                           00009A   507 _RB8	=	0x009a
                           000099   508 _TI	=	0x0099
                           000098   509 _RI	=	0x0098
                           0000CF   510 _TF2	=	0x00cf
                           0000CF   511 _CAP1F	=	0x00cf
                           0000CE   512 _EXF2	=	0x00ce
                           0000CD   513 _RCLK	=	0x00cd
                           0000CC   514 _TCLK	=	0x00cc
                           0000CB   515 _EXEN2	=	0x00cb
                           0000CA   516 _TR2	=	0x00ca
                           0000C9   517 _C_T2	=	0x00c9
                           0000C8   518 _CP_RL2	=	0x00c8
                           0000FF   519 _S0_FST_ACT	=	0x00ff
                           0000FE   520 _S0_IF_OV	=	0x00fe
                           0000FD   521 _S0_IF_FIRST	=	0x00fd
                           0000FC   522 _S0_IF_BYTE	=	0x00fc
                           0000FB   523 _S0_FREE	=	0x00fb
                           0000FA   524 _S0_T_FIFO	=	0x00fa
                           0000F8   525 _S0_R_FIFO	=	0x00f8
                           0000F7   526 _ADC_START	=	0x00f7
                                    527 ;--------------------------------------------------------
                                    528 ; overlayable register banks
                                    529 ;--------------------------------------------------------
                                    530 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        531 	.ds 8
                                    532 ;--------------------------------------------------------
                                    533 ; internal ram data
                                    534 ;--------------------------------------------------------
                                    535 	.area DSEG    (DATA)
                                    536 ;--------------------------------------------------------
                                    537 ; overlayable items in internal ram
                                    538 ;--------------------------------------------------------
                                    539 ;--------------------------------------------------------
                                    540 ; indirectly addressable internal ram data
                                    541 ;--------------------------------------------------------
                                    542 	.area ISEG    (DATA)
                                    543 ;--------------------------------------------------------
                                    544 ; absolute internal ram data
                                    545 ;--------------------------------------------------------
                                    546 	.area IABS    (ABS,DATA)
                                    547 	.area IABS    (ABS,DATA)
                                    548 ;--------------------------------------------------------
                                    549 ; bit data
                                    550 ;--------------------------------------------------------
                                    551 	.area BSEG    (BIT)
      00000E                        552 _ak820_tapping_before_sloc0_1_0:
      00000E                        553 	.ds 1
                                    554 ;--------------------------------------------------------
                                    555 ; paged external ram data
                                    556 ;--------------------------------------------------------
                                    557 	.area PSEG    (PAG,XDATA)
                                    558 ;--------------------------------------------------------
                                    559 ; uninitialized external ram data
                                    560 ;--------------------------------------------------------
                                    561 	.area XSEG    (XDATA)
      0005F4                        562 _source_state:
      0005F4                        563 	.ds 130
      000676                        564 _pending_time:
      000676                        565 	.ds 2
      000678                        566 _pending_code:
      000678                        567 	.ds 2
      00067A                        568 _ak820_tapping_source_PARM_1:
      00067A                        569 	.ds 2
      00067C                        570 _hold_PARM_2:
      00067C                        571 	.ds 1
      00067D                        572 _hold_code_10000_602:
      00067D                        573 	.ds 2
      00067F                        574 _hold_mods_30000_605:
      00067F                        575 	.ds 1
      000680                        576 _commit_pending_id_10000_611:
      000680                        577 	.ds 1
      000681                        578 _ak820_tapping_before_event_10000_612:
      000681                        579 	.ds 2
      000683                        580 _ak820_tapping_process_record_10000_623:
      000683                        581 	.ds 2
      000685                        582 _ak820_tapping_process_code_10000_624:
      000685                        583 	.ds 2
      000687                        584 _ak820_tapping_process_sc_mods_10000_624:
      000687                        585 	.ds 1
      000688                        586 _ak820_oneshot_mods::
      000688                        587 	.ds 1
      000689                        588 _ak820_oneshot_consumed::
      000689                        589 	.ds 1
      00068A                        590 _ak820_oneshot_process_PARM_2:
      00068A                        591 	.ds 1
      00068B                        592 _ak820_oneshot_process_PARM_3:
      00068B                        593 	.ds 1
      00068C                        594 _ak820_oneshot_process_code_10000_649:
      00068C                        595 	.ds 2
      00068E                        596 _ak820_oneshot_process_mods_10000_650:
      00068E                        597 	.ds 1
                                    598 ;--------------------------------------------------------
                                    599 ; absolute external ram data
                                    600 ;--------------------------------------------------------
                                    601 	.area XABS    (ABS,XDATA)
                                    602 ;--------------------------------------------------------
                                    603 ; initialized external ram data
                                    604 ;--------------------------------------------------------
                                    605 	.area XISEG   (XDATA)
      000E0D                        606 _pending:
      000E0D                        607 	.ds 1
      000E0E                        608 _ak820_oneshot_target::
      000E0E                        609 	.ds 1
                                    610 	.area HOME    (CODE)
                                    611 	.area GSINIT0 (CODE)
                                    612 	.area GSINIT1 (CODE)
                                    613 	.area GSINIT2 (CODE)
                                    614 	.area GSINIT3 (CODE)
                                    615 	.area GSINIT4 (CODE)
                                    616 	.area GSINIT5 (CODE)
                                    617 	.area GSINIT  (CODE)
                                    618 	.area GSFINAL (CODE)
                                    619 	.area CSEG    (CODE)
                                    620 ;--------------------------------------------------------
                                    621 ; global & static initialisations
                                    622 ;--------------------------------------------------------
                                    623 	.area HOME    (CODE)
                                    624 	.area GSINIT  (CODE)
                                    625 	.area GSFINAL (CODE)
                                    626 	.area GSINIT  (CODE)
                                    627 ;--------------------------------------------------------
                                    628 ; Home
                                    629 ;--------------------------------------------------------
                                    630 	.area HOME    (CODE)
                                    631 	.area HOME    (CODE)
                                    632 ;--------------------------------------------------------
                                    633 ; code
                                    634 ;--------------------------------------------------------
                                    635 	.area CSEG    (CODE)
                                    636 ;------------------------------------------------------------
                                    637 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    638 ;------------------------------------------------------------
                                    639 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    640 ;------------------------------------------------------------
                                    641 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    642 ;	-----------------------------------------
                           000007   643 	ar7 = 0x07
                           000006   644 	ar6 = 0x06
                           000005   645 	ar5 = 0x05
                           000004   646 	ar4 = 0x04
                           000003   647 	ar3 = 0x03
                           000002   648 	ar2 = 0x02
                           000001   649 	ar1 = 0x01
                           000000   650 	ar0 = 0x00
                                    651 ;	 function ak820_tapping_source
                                    652 ;	-----------------------------------------
      0046D5                        653 _ak820_tapping_source:
                                    654 ;	keyboards/ajazz/ak820/ak820_tapping.c:34: if (key.row < MATRIX_ROWS && key.col < MATRIX_COLS) return key.row * MATRIX_COLS + key.col;
      0046D5 90 06 7B         [24]  655 	mov	dptr,#(_ak820_tapping_source_PARM_1 + 0x0001)
      0046D8 E0               [24]  656 	movx	a,@dptr
      0046D9 FF               [12]  657 	mov	r7,a
      0046DA BF 10 00         [24]  658 	cjne	r7,#0x10,00147$
      0046DD                        659 00147$:
      0046DD 50 14            [24]  660 	jnc	00102$
      0046DF 90 06 7A         [24]  661 	mov	dptr,#_ak820_tapping_source_PARM_1
      0046E2 E0               [24]  662 	movx	a,@dptr
      0046E3 FE               [12]  663 	mov	r6,a
      0046E4 BE 08 00         [24]  664 	cjne	r6,#0x08,00149$
      0046E7                        665 00149$:
      0046E7 50 0A            [24]  666 	jnc	00102$
      0046E9 8F 05            [24]  667 	mov	ar5,r7
      0046EB ED               [12]  668 	mov	a,r5
      0046EC 12 38 C6         [24]  669 	lcall	_ak820_outline_0192
      0046EF 2E               [12]  670 	add	a,r6
      0046F0 F5 82            [12]  671 	mov	dpl,a
      0046F2 22               [24]  672 	ret
      0046F3                        673 00102$:
                                    674 ;	keyboards/ajazz/ak820/ak820_tapping.c:35: if (key.col < NUM_ENCODERS) {
      0046F3 90 06 7A         [24]  675 	mov	dptr,#_ak820_tapping_source_PARM_1
      0046F6 E0               [24]  676 	movx	a,@dptr
      0046F7 FE               [12]  677 	mov	r6,a
      0046F8 BE 01 00         [24]  678 	cjne	r6,#0x01,00151$
      0046FB                        679 00151$:
      0046FB 50 0E            [24]  680 	jnc	00109$
                                    681 ;	keyboards/ajazz/ak820/ak820_tapping.c:36: if (key.row == KEYLOC_ENCODER_CW) return MATRIX_ROWS * MATRIX_COLS + key.col;
      0046FD BF FD 04         [24]  682 	cjne	r7,#0xfd,00105$
      004700 75 82 80         [24]  683 	mov	dpl, #0x80
      004703 22               [24]  684 	ret
      004704                        685 00105$:
                                    686 ;	keyboards/ajazz/ak820/ak820_tapping.c:37: if (key.row == KEYLOC_ENCODER_CCW) return MATRIX_ROWS * MATRIX_COLS + NUM_ENCODERS + key.col;
      004704 BF FC 04         [24]  687 	cjne	r7,#0xfc,00109$
      004707 75 82 81         [24]  688 	mov	dpl, #0x81
      00470A 22               [24]  689 	ret
      00470B                        690 00109$:
                                    691 ;	keyboards/ajazz/ak820/ak820_tapping.c:39: return NONE;
      00470B 75 82 FF         [24]  692 	mov	dpl, #0xff
                                    693 ;	keyboards/ajazz/ak820/ak820_tapping.c:40: }
      00470E 22               [24]  694 	ret
                                    695 ;------------------------------------------------------------
                                    696 ;Allocation info for local variables in function 'hold'
                                    697 ;------------------------------------------------------------
                                    698 ;pressed       Allocated with name '_hold_PARM_2'
                                    699 ;code          Allocated with name '_hold_code_10000_602'
                                    700 ;mods          Allocated with name '_hold_mods_30000_605'
                                    701 ;layer         Allocated with name '_hold_layer_30000_608'
                                    702 ;------------------------------------------------------------
                                    703 ;	keyboards/ajazz/ak820/ak820_tapping.c:41: static void hold(uint16_t code, bool pressed) {
                                    704 ;	-----------------------------------------
                                    705 ;	 function hold
                                    706 ;	-----------------------------------------
      00470F                        707 _hold:
      00470F 12 38 82         [24]  708 	lcall	_ak820_outline_0110
      004712 90 06 7D         [24]  709 	mov	dptr,#_hold_code_10000_602
      004715 12 38 87         [24]  710 	lcall	_ak820_outline_0111
                                    711 ;	keyboards/ajazz/ak820/ak820_tapping.c:42: if (code < QK_LAYER_TAP) {
      004718 90 06 7D         [24]  712 	mov	dptr,#_hold_code_10000_602
      00471B 12 4B 86         [24]  713 	lcall	_ak820_outline_0009
      00471E 74 C0            [12]  714 	mov	a,#0x100 - 0x40
      004720 2D               [12]  715 	add	a,r5
      004721 40 2E            [24]  716 	jc	00110$
                                    717 ;	keyboards/ajazz/ak820/ak820_tapping.c:43: uint8_t mods = (code >> 8) & 31;
      004723 8F 05            [24]  718 	mov	ar5,r7
      004725 53 05 1F         [24]  719 	anl	ar5,#0x1f
      004728 90 06 7F         [24]  720 	mov	dptr,#_hold_mods_30000_605
      00472B ED               [12]  721 	mov	a,r5
      00472C F0               [24]  722 	movx	@dptr,a
                                    723 ;	keyboards/ajazz/ak820/ak820_tapping.c:44: if (mods & 16) mods <<= 4;
      00472D ED               [12]  724 	mov	a,r5
      00472E 30 E4 08         [24]  725 	jnb	acc.4,00102$
      004731 ED               [12]  726 	mov	a,r5
      004732 C4               [12]  727 	swap	a
      004733 54 F0            [12]  728 	anl	a,#0xf0
      004735 90 06 7F         [24]  729 	mov	dptr,#_hold_mods_30000_605
      004738 F0               [24]  730 	movx	@dptr,a
      004739                        731 00102$:
                                    732 ;	keyboards/ajazz/ak820/ak820_tapping.c:45: if (pressed) register_mods(mods);
      004739 90 06 7C         [24]  733 	mov	dptr,#_hold_PARM_2
      00473C E0               [24]  734 	movx	a,@dptr
      00473D 60 09            [24]  735 	jz	00104$
      00473F 90 06 7F         [24]  736 	mov	dptr,#_hold_mods_30000_605
      004742 E0               [24]  737 	movx	a,@dptr
      004743 F5 82            [12]  738 	mov	dpl,a
      004745 02 7A 83         [24]  739 	ljmp	_register_mods
      004748                        740 00104$:
                                    741 ;	keyboards/ajazz/ak820/ak820_tapping.c:46: else unregister_mods(mods);
      004748 90 06 7F         [24]  742 	mov	dptr,#_hold_mods_30000_605
      00474B E0               [24]  743 	movx	a,@dptr
      00474C F5 82            [12]  744 	mov	dpl,a
      00474E 02 7A 97         [24]  745 	ljmp	_unregister_mods
      004751                        746 00110$:
                                    747 ;	keyboards/ajazz/ak820/ak820_tapping.c:48: uint8_t layer = (code >> 8) & 15;
      004751 8F 06            [24]  748 	mov	ar6,r7
      004753 74 0F            [12]  749 	mov	a,#0x0f
      004755 5E               [12]  750 	anl	a,r6
      004756 FF               [12]  751 	mov	r7,a
                                    752 ;	keyboards/ajazz/ak820/ak820_tapping.c:49: if (pressed) layer_hold_on(layer);
      004757 90 06 7C         [24]  753 	mov	dptr,#_hold_PARM_2
      00475A E0               [24]  754 	movx	a,@dptr
      00475B 60 05            [24]  755 	jz	00107$
      00475D 8F 82            [24]  756 	mov	dpl, r7
      00475F 02 7C 87         [24]  757 	ljmp	_layer_hold_on
      004762                        758 00107$:
                                    759 ;	keyboards/ajazz/ak820/ak820_tapping.c:50: else layer_hold_off(layer);
      004762 8F 82            [24]  760 	mov	dpl, r7
                                    761 ;	keyboards/ajazz/ak820/ak820_tapping.c:52: }
      004764 02 7C BF         [24]  762 	ljmp	_layer_hold_off
                                    763 ;------------------------------------------------------------
                                    764 ;Allocation info for local variables in function 'commit_pending'
                                    765 ;------------------------------------------------------------
                                    766 ;id            Allocated with name '_commit_pending_id_10000_611'
                                    767 ;------------------------------------------------------------
                                    768 ;	keyboards/ajazz/ak820/ak820_tapping.c:53: static void commit_pending(void) {
                                    769 ;	-----------------------------------------
                                    770 ;	 function commit_pending
                                    771 ;	-----------------------------------------
      004767                        772 _commit_pending:
                                    773 ;	keyboards/ajazz/ak820/ak820_tapping.c:54: uint8_t id = pending;
      004767 90 0E 0D         [24]  774 	mov	dptr,#_pending
      00476A E0               [24]  775 	movx	a,@dptr
      00476B 90 06 80         [24]  776 	mov	dptr,#_commit_pending_id_10000_611
      00476E F0               [24]  777 	movx	@dptr,a
                                    778 ;	keyboards/ajazz/ak820/ak820_tapping.c:55: pending = NONE; /* A report callback cannot resurrect the decision. */
      00476F 12 4C 18         [24]  779 	lcall	_ak820_outline_0157
                                    780 ;	keyboards/ajazz/ak820/ak820_tapping.c:56: source_state[id] |= SOURCE_HELD;
      004772 90 06 80         [24]  781 	mov	dptr,#_commit_pending_id_10000_611
      004775 E0               [24]  782 	movx	a,@dptr
      004776 24 F4            [12]  783 	add	a,#_source_state
      004778 FF               [12]  784 	mov	r7,a
      004779 E4               [12]  785 	clr	a
      00477A 34 05            [12]  786 	addc	a, #(_source_state >> 8)
      00477C FE               [12]  787 	mov	r6,a
      00477D 12 46 BA         [24]  788 	lcall	_ak820_outline_0160
      004780 E0               [24]  789 	movx	a,@dptr
      004781 FD               [12]  790 	mov	r5,a
      004782 43 05 04         [24]  791 	orl	ar5,#0x04
      004785 12 46 BA         [24]  792 	lcall	_ak820_outline_0160
      004788 ED               [12]  793 	mov	a,r5
      004789 F0               [24]  794 	movx	@dptr,a
                                    795 ;	keyboards/ajazz/ak820/ak820_tapping.c:57: hold(pending_code, true);
      00478A 90 06 78         [24]  796 	mov	dptr,#_pending_code
      00478D 12 38 41         [24]  797 	lcall	_ak820_outline_0053
      004790 90 06 7C         [24]  798 	mov	dptr,#_hold_PARM_2
      004793 74 01            [12]  799 	mov	a,#0x01
      004795 12 46 86         [24]  800 	lcall	_ak820_outline_0076
                                    801 ;	keyboards/ajazz/ak820/ak820_tapping.c:58: }
      004798 02 47 0F         [24]  802 	ljmp	_hold
                                    803 ;------------------------------------------------------------
                                    804 ;Allocation info for local variables in function 'ak820_tapping_before'
                                    805 ;------------------------------------------------------------
                                    806 ;event         Allocated with name '_ak820_tapping_before_event_10000_612'
                                    807 ;id            Allocated with name '_ak820_tapping_before_id_10000_613'
                                    808 ;------------------------------------------------------------
                                    809 ;	keyboards/ajazz/ak820/ak820_tapping.c:59: bool ak820_tapping_before(const keyevent_t AK820_STATE_MEM *event) {
                                    810 ;	-----------------------------------------
                                    811 ;	 function ak820_tapping_before
                                    812 ;	-----------------------------------------
      00479B                        813 _ak820_tapping_before:
      00479B 12 38 82         [24]  814 	lcall	_ak820_outline_0110
      00479E 90 06 81         [24]  815 	mov	dptr,#_ak820_tapping_before_event_10000_612
      0047A1 12 38 87         [24]  816 	lcall	_ak820_outline_0111
                                    817 ;	keyboards/ajazz/ak820/ak820_tapping.c:60: uint8_t id = ak820_tapping_source(event->key);
      0047A4 90 06 81         [24]  818 	mov	dptr,#_ak820_tapping_before_event_10000_612
      0047A7 12 4B 86         [24]  819 	lcall	_ak820_outline_0009
      0047AA 12 4B 9C         [24]  820 	lcall	_ak820_outline_0024
      0047AD C0 07            [24]  821 	push	ar7
      0047AF C0 06            [24]  822 	push	ar6
      0047B1 12 BC F8         [24]  823 	lcall	___memcpy
      0047B4 12 46 D5         [24]  824 	lcall	_ak820_tapping_source
      0047B7 AD 82            [24]  825 	mov	r5, dpl
      0047B9 D0 06            [24]  826 	pop	ar6
      0047BB D0 07            [24]  827 	pop	ar7
                                    828 ;	keyboards/ajazz/ak820/ak820_tapping.c:62: if (vial_unlock_in_progress) {
      0047BD 90 0E 7E         [24]  829 	mov	dptr,#_vial_unlock_in_progress
      0047C0 E0               [24]  830 	movx	a,@dptr
      0047C1 60 1E            [24]  831 	jz	00106$
                                    832 ;	keyboards/ajazz/ak820/ak820_tapping.c:63: if (IS_EVENT(*event) && id != NONE && !event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      0047C3 12 4C 0B         [24]  833 	lcall	_ak820_outline_0100
      0047C6 60 15            [24]  834 	jz	00102$
      0047C8 BD FF 02         [24]  835 	cjne	r5,#0xff,00218$
      0047CB 80 10            [24]  836 	sjmp	00102$
      0047CD                        837 00218$:
      0047CD 12 4B 90         [24]  838 	lcall	_ak820_outline_0015
      0047D0 E0               [24]  839 	movx	a,@dptr
      0047D1 70 0A            [24]  840 	jnz	00102$
      0047D3 ED               [12]  841 	mov	a,r5
      0047D4 12 4B B6         [24]  842 	lcall	_ak820_outline_0026
      0047D7 53 02 FD         [24]  843 	anl	ar2,#0xfd
      0047DA 12 4C 04         [24]  844 	lcall	_ak820_outline_0096
      0047DD                        845 00102$:
                                    846 ;	keyboards/ajazz/ak820/ak820_tapping.c:64: return false;
      0047DD 75 82 00         [24]  847 	mov	dpl, #0x00
      0047E0 22               [24]  848 	ret
      0047E1                        849 00106$:
                                    850 ;	keyboards/ajazz/ak820/ak820_tapping.c:67: if (pending != NONE && ((uint16_t)(event->time - pending_time) >= 200 ||
      0047E1 90 0E 0D         [24]  851 	mov	dptr,#_pending
      0047E4 E0               [24]  852 	movx	a,@dptr
      0047E5 FC               [12]  853 	mov	r4,a
      0047E6 BC FF 02         [24]  854 	cjne	r4,#0xff,00220$
      0047E9 80 3B            [24]  855 	sjmp	00108$
      0047EB                        856 00220$:
      0047EB 12 38 39         [24]  857 	lcall	_ak820_outline_0037
      0047EE FA               [12]  858 	mov	r2,a
      0047EF A3               [24]  859 	inc	dptr
      0047F0 E0               [24]  860 	movx	a,@dptr
      0047F1 FB               [12]  861 	mov	r3,a
      0047F2 90 06 76         [24]  862 	mov	dptr,#_pending_time
      0047F5 12 38 7C         [24]  863 	lcall	_ak820_outline_0105
      0047F8 EA               [12]  864 	mov	a,r2
      0047F9 C3               [12]  865 	clr	c
      0047FA 98               [12]  866 	subb	a,r0
      0047FB FA               [12]  867 	mov	r2,a
      0047FC EB               [12]  868 	mov	a,r3
      0047FD 99               [12]  869 	subb	a,r1
      0047FE FB               [12]  870 	mov	r3,a
      0047FF C3               [12]  871 	clr	c
      004800 EA               [12]  872 	mov	a,r2
      004801 94 C8            [12]  873 	subb	a,#0xc8
      004803 EB               [12]  874 	mov	a,r3
      004804 94 00            [12]  875 	subb	a,#0x00
      004806 50 17            [24]  876 	jnc	00107$
                                    877 ;	keyboards/ajazz/ak820/ak820_tapping.c:68: (IS_EVENT(*event) && event->pressed && (id == NONE || id != pending)))) commit_pending();
      004808 74 04            [12]  878 	mov	a,#0x04
      00480A 12 4B C4         [24]  879 	lcall	_ak820_outline_0033
      00480D 60 17            [24]  880 	jz	00108$
      00480F 12 38 12         [24]  881 	lcall	_ak820_outline_0010
      004812 60 12            [24]  882 	jz	00108$
      004814 BD FF 02         [24]  883 	cjne	r5,#0xff,00224$
      004817 80 06            [24]  884 	sjmp	00107$
      004819                        885 00224$:
      004819 ED               [12]  886 	mov	a,r5
      00481A B5 04 02         [24]  887 	cjne	a,ar4,00225$
      00481D 80 07            [24]  888 	sjmp	00108$
      00481F                        889 00225$:
      00481F                        890 00107$:
      00481F C0 05            [24]  891 	push	ar5
      004821 12 47 67         [24]  892 	lcall	_commit_pending
      004824 D0 05            [24]  893 	pop	ar5
      004826                        894 00108$:
                                    895 ;	keyboards/ajazz/ak820/ak820_tapping.c:69: if (IS_NOEVENT(*event) || id == NONE) return true;
      004826 90 06 81         [24]  896 	mov	dptr,#_ak820_tapping_before_event_10000_612
      004829 12 38 41         [24]  897 	lcall	_ak820_outline_0053
      00482C 12 4C 0B         [24]  898 	lcall	_ak820_outline_0100
      00482F 60 03            [24]  899 	jz	00114$
      004831 BD FF 04         [24]  900 	cjne	r5,#0xff,00115$
      004834                        901 00114$:
      004834 75 82 01         [24]  902 	mov	dpl, #0x01
      004837 22               [24]  903 	ret
      004838                        904 00115$:
                                    905 ;	keyboards/ajazz/ak820/ak820_tapping.c:70: if ((source_state[id] & SOURCE_BLOCKED)) {
      004838 ED               [12]  906 	mov	a,r5
      004839 12 4B F6         [24]  907 	lcall	_ak820_outline_0079
      00483C 30 E1 13         [24]  908 	jnb	acc.1,00120$
                                    909 ;	keyboards/ajazz/ak820/ak820_tapping.c:71: if (!event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      00483F 74 05            [12]  910 	mov	a,#0x05
      004841 2E               [12]  911 	add	a, r6
      004842 12 38 27         [24]  912 	lcall	_ak820_outline_0017
      004845 70 07            [24]  913 	jnz	00118$
      004847 74 FD            [12]  914 	mov	a,#0xfd
      004849 5B               [12]  915 	anl	a,r3
      00484A 12 38 97         [24]  916 	lcall	_ak820_outline_0126
      00484D F0               [24]  917 	movx	@dptr,a
      00484E                        918 00118$:
                                    919 ;	keyboards/ajazz/ak820/ak820_tapping.c:72: return false;
      00484E 75 82 00         [24]  920 	mov	dpl, #0x00
      004851 22               [24]  921 	ret
      004852                        922 00120$:
                                    923 ;	keyboards/ajazz/ak820/ak820_tapping.c:75: if (event->pressed == ((source_state[id] & SOURCE_ACTIVE) != 0)) return false;
      004852 12 46 50         [24]  924 	lcall	_ak820_outline_0012
      004855 E0               [24]  925 	movx	a,@dptr
      004856 FF               [12]  926 	mov	r7,a
      004857 8B 06            [24]  927 	mov	ar6,r3
      004859 53 06 01         [24]  928 	anl	ar6,#0x01
      00485C EE               [12]  929 	mov	a,r6
      00485D B4 01 00         [24]  930 	cjne	a,#0x01,00231$
      004860                        931 00231$:
      004860 B3               [12]  932 	cpl	c
      004861 92 0E            [24]  933 	mov	_ak820_tapping_before_sloc0_1_0,c
      004863 8F F0            [24]  934 	mov	b,r7
      004865 E4               [12]  935 	clr	a
      004866 33               [12]  936 	rlc	a
      004867 B5 F0 04         [24]  937 	cjne	a,b,00122$
      00486A 75 82 00         [24]  938 	mov	dpl, #0x00
      00486D 22               [24]  939 	ret
      00486E                        940 00122$:
                                    941 ;	keyboards/ajazz/ak820/ak820_tapping.c:76: source_state[id] ^= SOURCE_ACTIVE;
      00486E 63 03 01         [24]  942 	xrl	ar3,#0x01
      004871 12 38 97         [24]  943 	lcall	_ak820_outline_0126
      004874 EB               [12]  944 	mov	a,r3
      004875 F0               [24]  945 	movx	@dptr,a
                                    946 ;	keyboards/ajazz/ak820/ak820_tapping.c:77: return true;
      004876 75 82 01         [24]  947 	mov	dpl, #0x01
                                    948 ;	keyboards/ajazz/ak820/ak820_tapping.c:78: }
      004879 22               [24]  949 	ret
                                    950 ;------------------------------------------------------------
                                    951 ;Allocation info for local variables in function 'ak820_tapping_process'
                                    952 ;------------------------------------------------------------
                                    953 ;record        Allocated with name '_ak820_tapping_process_record_10000_623'
                                    954 ;id            Allocated with name '_ak820_tapping_process_id_10000_624'
                                    955 ;kind          Allocated with name '_ak820_tapping_process_kind_10000_624'
                                    956 ;code          Allocated with name '_ak820_tapping_process_code_10000_624'
                                    957 ;sc_mods       Allocated with name '_ak820_tapping_process_sc_mods_10000_624'
                                    958 ;------------------------------------------------------------
                                    959 ;	keyboards/ajazz/ak820/ak820_tapping.c:79: bool ak820_tapping_process(keyrecord_t AK820_STATE_MEM *record) {
                                    960 ;	-----------------------------------------
                                    961 ;	 function ak820_tapping_process
                                    962 ;	-----------------------------------------
      00487A                        963 _ak820_tapping_process:
      00487A 12 38 82         [24]  964 	lcall	_ak820_outline_0110
      00487D 90 06 83         [24]  965 	mov	dptr,#_ak820_tapping_process_record_10000_623
      004880 12 38 87         [24]  966 	lcall	_ak820_outline_0111
                                    967 ;	keyboards/ajazz/ak820/ak820_tapping.c:83: uint8_t sc_mods = 0;
      004883 90 06 87         [24]  968 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_624
      004886 E4               [12]  969 	clr	a
      004887 F0               [24]  970 	movx	@dptr,a
                                    971 ;	keyboards/ajazz/ak820/ak820_tapping.c:85: if (IS_NOEVENT(record->event)) return true;
      004888 90 06 83         [24]  972 	mov	dptr,#_ak820_tapping_process_record_10000_623
      00488B 12 38 41         [24]  973 	lcall	_ak820_outline_0053
      00488E 74 04            [12]  974 	mov	a,#0x04
      004890 12 4B CF         [24]  975 	lcall	_ak820_outline_0034
      004893 70 04            [24]  976 	jnz	00102$
      004895 75 82 01         [24]  977 	mov	dpl, #0x01
      004898 22               [24]  978 	ret
      004899                        979 00102$:
                                    980 ;	keyboards/ajazz/ak820/ak820_tapping.c:86: id = ak820_tapping_source(record->event.key);
      004899 8E 04            [24]  981 	mov	ar4,r6
      00489B 8F 05            [24]  982 	mov	ar5,r7
      00489D 12 4B 9C         [24]  983 	lcall	_ak820_outline_0024
      0048A0 C0 07            [24]  984 	push	ar7
      0048A2 C0 06            [24]  985 	push	ar6
      0048A4 12 BC F8         [24]  986 	lcall	___memcpy
      0048A7 12 46 D5         [24]  987 	lcall	_ak820_tapping_source
      0048AA AD 82            [24]  988 	mov	r5, dpl
      0048AC D0 06            [24]  989 	pop	ar6
      0048AE D0 07            [24]  990 	pop	ar7
                                    991 ;	keyboards/ajazz/ak820/ak820_tapping.c:87: if (id == NONE) return true;
      0048B0 BD FF 04         [24]  992 	cjne	r5,#0xff,00104$
      0048B3 75 82 01         [24]  993 	mov	dpl, #0x01
      0048B6 22               [24]  994 	ret
      0048B7                        995 00104$:
                                    996 ;	keyboards/ajazz/ak820/ak820_tapping.c:88: code = record->keycode;
      0048B7 74 07            [12]  997 	mov	a,#0x07
      0048B9 12 38 31         [24]  998 	lcall	_ak820_outline_0021
      0048BC 12 38 41         [24]  999 	lcall	_ak820_outline_0053
      0048BF 90 06 85         [24] 1000 	mov	dptr,#_ak820_tapping_process_code_10000_624
      0048C2 12 4B E2         [24] 1001 	lcall	_ak820_outline_0060
                                   1002 ;	keyboards/ajazz/ak820/ak820_tapping.c:90: if (code == SC_LSPO) { code = MT(MOD_LSFT, KC_9); sc_mods = MOD_BIT(KC_LEFT_SHIFT); }
      0048C5 BE 1A 15         [24] 1003 	cjne	r6,#0x1a,00111$
      0048C8 BF 7C 12         [24] 1004 	cjne	r7,#0x7c,00111$
      0048CB 90 06 85         [24] 1005 	mov	dptr,#_ak820_tapping_process_code_10000_624
      0048CE 74 26            [12] 1006 	mov	a,#0x26
      0048D0 F0               [24] 1007 	movx	@dptr,a
      0048D1 74 22            [12] 1008 	mov	a,#0x22
      0048D3 A3               [24] 1009 	inc	dptr
      0048D4 F0               [24] 1010 	movx	@dptr,a
      0048D5 90 06 87         [24] 1011 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_624
      0048D8 74 02            [12] 1012 	mov	a,#0x02
      0048DA F0               [24] 1013 	movx	@dptr,a
      0048DB 80 28            [24] 1014 	sjmp	00112$
      0048DD                       1015 00111$:
                                   1016 ;	keyboards/ajazz/ak820/ak820_tapping.c:91: else if (code == SC_RSPC) { code = MT(MOD_RSFT, KC_0); sc_mods = MOD_BIT(KC_RIGHT_SHIFT); }
      0048DD BE 1B 15         [24] 1017 	cjne	r6,#0x1b,00108$
      0048E0 BF 7C 12         [24] 1018 	cjne	r7,#0x7c,00108$
      0048E3 90 06 85         [24] 1019 	mov	dptr,#_ak820_tapping_process_code_10000_624
      0048E6 74 27            [12] 1020 	mov	a,#0x27
      0048E8 F0               [24] 1021 	movx	@dptr,a
      0048E9 74 32            [12] 1022 	mov	a,#0x32
      0048EB A3               [24] 1023 	inc	dptr
      0048EC F0               [24] 1024 	movx	@dptr,a
      0048ED 90 06 87         [24] 1025 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_624
      0048F0 74 20            [12] 1026 	mov	a,#0x20
      0048F2 F0               [24] 1027 	movx	@dptr,a
      0048F3 80 10            [24] 1028 	sjmp	00112$
      0048F5                       1029 00108$:
                                   1030 ;	keyboards/ajazz/ak820/ak820_tapping.c:92: else if (code == SC_SENT) code = MT(MOD_RSFT, KC_ENTER);
      0048F5 BE 1E 0D         [24] 1031 	cjne	r6,#0x1e,00112$
      0048F8 BF 7C 0A         [24] 1032 	cjne	r7,#0x7c,00112$
      0048FB 90 06 85         [24] 1033 	mov	dptr,#_ak820_tapping_process_code_10000_624
      0048FE 74 28            [12] 1034 	mov	a,#0x28
      004900 F0               [24] 1035 	movx	@dptr,a
      004901 74 32            [12] 1036 	mov	a,#0x32
      004903 A3               [24] 1037 	inc	dptr
      004904 F0               [24] 1038 	movx	@dptr,a
      004905                       1039 00112$:
                                   1040 ;	keyboards/ajazz/ak820/ak820_tapping.c:94: kind = code >> 8;
      004905 90 06 85         [24] 1041 	mov	dptr,#_ak820_tapping_process_code_10000_624
      004908 E0               [24] 1042 	movx	a,@dptr
      004909 A3               [24] 1043 	inc	dptr
      00490A E0               [24] 1044 	movx	a,@dptr
      00490B FF               [12] 1045 	mov	r7,a
                                   1046 ;	keyboards/ajazz/ak820/ak820_tapping.c:95: if (kind < 0x20 || kind >= 0x50) return true;
      00490C BF 20 00         [24] 1047 	cjne	r7,#0x20,00242$
      00490F                       1048 00242$:
      00490F 40 05            [24] 1049 	jc	00113$
      004911 BF 50 00         [24] 1050 	cjne	r7,#0x50,00244$
      004914                       1051 00244$:
      004914 40 04            [24] 1052 	jc	00114$
      004916                       1053 00113$:
      004916 75 82 01         [24] 1054 	mov	dpl, #0x01
      004919 22               [24] 1055 	ret
      00491A                       1056 00114$:
                                   1057 ;	keyboards/ajazz/ak820/ak820_tapping.c:96: if (kind >= 0x40 && (kind & 15) >= MAX_LAYER) return false;
      00491A BF 40 00         [24] 1058 	cjne	r7,#0x40,00246$
      00491D                       1059 00246$:
      00491D 40 0C            [24] 1060 	jc	00117$
      00491F 53 07 0F         [24] 1061 	anl	ar7,#0x0f
      004922 BF 06 00         [24] 1062 	cjne	r7,#0x06,00248$
      004925                       1063 00248$:
      004925 40 04            [24] 1064 	jc	00117$
      004927 75 82 00         [24] 1065 	mov	dpl, #0x00
      00492A 22               [24] 1066 	ret
      00492B                       1067 00117$:
                                   1068 ;	keyboards/ajazz/ak820/ak820_tapping.c:97: if (record->event.pressed) {
      00492B 90 06 83         [24] 1069 	mov	dptr,#_ak820_tapping_process_record_10000_623
      00492E 12 38 41         [24] 1070 	lcall	_ak820_outline_0053
      004931 12 4B 90         [24] 1071 	lcall	_ak820_outline_0015
      004934 E0               [24] 1072 	movx	a,@dptr
      004935 60 1F            [24] 1073 	jz	00131$
                                   1074 ;	keyboards/ajazz/ak820/ak820_tapping.c:98: pending = id;
      004937 90 0E 0D         [24] 1075 	mov	dptr,#_pending
      00493A ED               [12] 1076 	mov	a,r5
      00493B 12 46 5A         [24] 1077 	lcall	_ak820_outline_0032
                                   1078 ;	keyboards/ajazz/ak820/ak820_tapping.c:99: pending_time = record->event.time;
      00493E 12 38 41         [24] 1079 	lcall	_ak820_outline_0053
      004941 90 06 76         [24] 1080 	mov	dptr,#_pending_time
      004944 12 4B E2         [24] 1081 	lcall	_ak820_outline_0060
                                   1082 ;	keyboards/ajazz/ak820/ak820_tapping.c:100: pending_code = code;
      004947 90 06 85         [24] 1083 	mov	dptr,#_ak820_tapping_process_code_10000_624
      00494A 12 38 41         [24] 1084 	lcall	_ak820_outline_0053
      00494D 90 06 78         [24] 1085 	mov	dptr,#_pending_code
      004950 12 4B E2         [24] 1086 	lcall	_ak820_outline_0060
      004953 02 4A 09         [24] 1087 	ljmp	00132$
      004956                       1088 00131$:
                                   1089 ;	keyboards/ajazz/ak820/ak820_tapping.c:101: } else if (id == pending) {
      004956 90 0E 0D         [24] 1090 	mov	dptr,#_pending
      004959 E0               [24] 1091 	movx	a,@dptr
      00495A FF               [12] 1092 	mov	r7,a
      00495B ED               [12] 1093 	mov	a,r5
      00495C B5 07 02         [24] 1094 	cjne	a,ar7,00251$
      00495F 80 03            [24] 1095 	sjmp	00252$
      004961                       1096 00251$:
      004961 02 49 E1         [24] 1097 	ljmp	00128$
      004964                       1098 00252$:
                                   1099 ;	keyboards/ajazz/ak820/ak820_tapping.c:102: pending = NONE;
      004964 12 4C 18         [24] 1100 	lcall	_ak820_outline_0157
                                   1101 ;	keyboards/ajazz/ak820/ak820_tapping.c:104: if (sc_mods) add_owned_mods(sc_mods);
      004967 90 06 87         [24] 1102 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_624
      00496A E0               [24] 1103 	movx	a,@dptr
      00496B FF               [12] 1104 	mov	r7,a
      00496C E0               [24] 1105 	movx	a,@dptr
      00496D 60 05            [24] 1106 	jz	00120$
      00496F 8F 82            [24] 1107 	mov	dpl, r7
      004971 12 81 5D         [24] 1108 	lcall	_add_owned_mods
      004974                       1109 00120$:
                                   1110 ;	keyboards/ajazz/ak820/ak820_tapping.c:108: record->keycode = (uint8_t)code;
      004974 90 06 83         [24] 1111 	mov	dptr,#_ak820_tapping_process_record_10000_623
      004977 12 38 41         [24] 1112 	lcall	_ak820_outline_0053
      00497A 74 07            [12] 1113 	mov	a,#0x07
      00497C 2E               [12] 1114 	add	a, r6
      00497D FB               [12] 1115 	mov	r3,a
      00497E E4               [12] 1116 	clr	a
      00497F 3F               [12] 1117 	addc	a, r7
      004980 FC               [12] 1118 	mov	r4,a
      004981 90 06 85         [24] 1119 	mov	dptr,#_ak820_tapping_process_code_10000_624
      004984 E0               [24] 1120 	movx	a,@dptr
      004985 F9               [12] 1121 	mov	r1,a
      004986 7A 00            [12] 1122 	mov	r2,#0x00
      004988 12 33 FC         [24] 1123 	lcall	_ak820_outline_0125
      00498B E9               [12] 1124 	mov	a,r1
      00498C F0               [24] 1125 	movx	@dptr,a
      00498D EA               [12] 1126 	mov	a,r2
      00498E A3               [24] 1127 	inc	dptr
      00498F F0               [24] 1128 	movx	@dptr,a
                                   1129 ;	keyboards/ajazz/ak820/ak820_tapping.c:109: if (record->keycode > KC_TRANSPARENT) {
      004990 C3               [12] 1130 	clr	c
      004991 04               [12] 1131 	inc	a
      004992 99               [12] 1132 	subb	a,r1
      004993 50 3A            [24] 1133 	jnc	00122$
                                   1134 ;	free result
                                   1135 ;	keyboards/ajazz/ak820/ak820_tapping.c:110: record->tap.count = 1;
      004995 74 06            [12] 1136 	mov	a,#0x06
      004997 12 38 31         [24] 1137 	lcall	_ak820_outline_0021
      00499A E0               [24] 1138 	movx	a,@dptr
      00499B 54 0F            [12] 1139 	anl	a,#0x0f
      00499D 44 10            [12] 1140 	orl	a,#0x10
      00499F F0               [24] 1141 	movx	@dptr,a
                                   1142 ;	keyboards/ajazz/ak820/ak820_tapping.c:111: record->event.pressed = true;
      0049A0 12 4B 90         [24] 1143 	lcall	_ak820_outline_0015
      0049A3 74 01            [12] 1144 	mov	a,#0x01
      0049A5 F0               [24] 1145 	movx	@dptr,a
                                   1146 ;	keyboards/ajazz/ak820/ak820_tapping.c:112: process_record(record);
      0049A6 12 4B EF         [24] 1147 	lcall	_ak820_outline_0077
      0049A9 12 38 B1         [24] 1148 	lcall	_ak820_outline_0146
      0049AC 8A F0            [24] 1149 	mov	b, r2
      0049AE C0 07            [24] 1150 	push	ar7
      0049B0 C0 06            [24] 1151 	push	ar6
      0049B2 C0 04            [24] 1152 	push	ar4
      0049B4 C0 03            [24] 1153 	push	ar3
      0049B6 12 74 5D         [24] 1154 	lcall	_process_record
      0049B9 D0 03            [24] 1155 	pop	ar3
      0049BB D0 04            [24] 1156 	pop	ar4
      0049BD D0 06            [24] 1157 	pop	ar6
      0049BF D0 07            [24] 1158 	pop	ar7
                                   1159 ;	keyboards/ajazz/ak820/ak820_tapping.c:113: record->event.pressed = false;
      0049C1 12 33 FC         [24] 1160 	lcall	_ak820_outline_0125
      0049C4 E4               [12] 1161 	clr	a
      0049C5 F0               [24] 1162 	movx	@dptr,a
                                   1163 ;	keyboards/ajazz/ak820/ak820_tapping.c:114: process_record(record);
      0049C6 FC               [12] 1164 	mov	r4,a
      0049C7 12 38 8C         [24] 1165 	lcall	_ak820_outline_0120
      0049CA 8C F0            [24] 1166 	mov	b, r4
      0049CC 12 74 5D         [24] 1167 	lcall	_process_record
      0049CF                       1168 00122$:
                                   1169 ;	keyboards/ajazz/ak820/ak820_tapping.c:117: if (sc_mods) {
      0049CF 90 06 87         [24] 1170 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_624
      0049D2 E0               [24] 1171 	movx	a,@dptr
      0049D3 FF               [12] 1172 	mov	r7,a
      0049D4 E0               [24] 1173 	movx	a,@dptr
      0049D5 60 32            [24] 1174 	jz	00132$
                                   1175 ;	keyboards/ajazz/ak820/ak820_tapping.c:118: del_owned_mods(sc_mods);
      0049D7 8F 82            [24] 1176 	mov	dpl, r7
      0049D9 12 81 6D         [24] 1177 	lcall	_del_owned_mods
                                   1178 ;	keyboards/ajazz/ak820/ak820_tapping.c:119: send_keyboard_report();
      0049DC 12 84 A0         [24] 1179 	lcall	_send_keyboard_report
      0049DF 80 28            [24] 1180 	sjmp	00132$
      0049E1                       1181 00128$:
                                   1182 ;	keyboards/ajazz/ak820/ak820_tapping.c:122: } else if ((source_state[id] & SOURCE_HELD)) {
      0049E1 ED               [12] 1183 	mov	a,r5
      0049E2 24 F4            [12] 1184 	add	a, #_source_state
      0049E4 FE               [12] 1185 	mov	r6,a
      0049E5 E4               [12] 1186 	clr	a
      0049E6 34 05            [12] 1187 	addc	a, #(_source_state >> 8)
      0049E8 FF               [12] 1188 	mov	r7,a
      0049E9 12 38 8C         [24] 1189 	lcall	_ak820_outline_0120
      0049EC E0               [24] 1190 	movx	a,@dptr
      0049ED FD               [12] 1191 	mov	r5,a
      0049EE 30 E2 18         [24] 1192 	jnb	acc.2,00132$
                                   1193 ;	keyboards/ajazz/ak820/ak820_tapping.c:123: source_state[id] &= ~SOURCE_HELD;
      0049F1 53 05 FB         [24] 1194 	anl	ar5,#0xfb
      0049F4 12 38 8C         [24] 1195 	lcall	_ak820_outline_0120
      0049F7 ED               [12] 1196 	mov	a,r5
      0049F8 F0               [24] 1197 	movx	@dptr,a
                                   1198 ;	keyboards/ajazz/ak820/ak820_tapping.c:124: hold(code, false);
      0049F9 90 06 85         [24] 1199 	mov	dptr,#_ak820_tapping_process_code_10000_624
      0049FC 12 38 41         [24] 1200 	lcall	_ak820_outline_0053
      0049FF 90 06 7C         [24] 1201 	mov	dptr,#_hold_PARM_2
      004A02 E4               [12] 1202 	clr	a
      004A03 12 46 86         [24] 1203 	lcall	_ak820_outline_0076
      004A06 12 47 0F         [24] 1204 	lcall	_hold
      004A09                       1205 00132$:
                                   1206 ;	keyboards/ajazz/ak820/ak820_tapping.c:126: return false;
      004A09 75 82 00         [24] 1207 	mov	dpl, #0x00
                                   1208 ;	keyboards/ajazz/ak820/ak820_tapping.c:127: }
      004A0C 22               [24] 1209 	ret
                                   1210 ;------------------------------------------------------------
                                   1211 ;Allocation info for local variables in function 'ak820_tapping_cancel'
                                   1212 ;------------------------------------------------------------
                                   1213 ;i             Allocated with name '_ak820_tapping_cancel_i_20000_647'
                                   1214 ;state         Allocated with name '_ak820_tapping_cancel_state_30000_648'
                                   1215 ;------------------------------------------------------------
                                   1216 ;	keyboards/ajazz/ak820/ak820_tapping.c:128: void ak820_tapping_cancel(void) {
                                   1217 ;	-----------------------------------------
                                   1218 ;	 function ak820_tapping_cancel
                                   1219 ;	-----------------------------------------
      004A0D                       1220 _ak820_tapping_cancel:
                                   1221 ;	keyboards/ajazz/ak820/ak820_tapping.c:129: pending = NONE;
      004A0D 12 4C 18         [24] 1222 	lcall	_ak820_outline_0157
                                   1223 ;	keyboards/ajazz/ak820/ak820_tapping.c:130: for (uint8_t i = 0; i < SOURCES; ++i) {
      004A10 7F 00            [12] 1224 	mov	r7,#0x00
      004A12                       1225 00103$:
      004A12 BF 82 00         [24] 1226 	cjne	r7,#0x82,00122$
      004A15                       1227 00122$:
      004A15 50 1D            [24] 1228 	jnc	00105$
                                   1229 ;	keyboards/ajazz/ak820/ak820_tapping.c:131: uint8_t state = source_state[i];
      004A17 EF               [12] 1230 	mov	a,r7
      004A18 24 F4            [12] 1231 	add	a, #_source_state
      004A1A FD               [12] 1232 	mov	r5,a
      004A1B E4               [12] 1233 	clr	a
      004A1C 34 05            [12] 1234 	addc	a, #(_source_state >> 8)
      004A1E 12 4B DA         [24] 1235 	lcall	_ak820_outline_0058
                                   1236 ;	keyboards/ajazz/ak820/ak820_tapping.c:132: source_state[i] = (state & SOURCE_BLOCKED) | ((state & SOURCE_ACTIVE) << 1);
      004A21 74 02            [12] 1237 	mov	a,#0x02
      004A23 5C               [12] 1238 	anl	a,r4
      004A24 FB               [12] 1239 	mov	r3,a
      004A25 53 04 01         [24] 1240 	anl	ar4,#0x01
      004A28 EC               [12] 1241 	mov	a,r4
      004A29 2C               [12] 1242 	add	a,r4
      004A2A 42 03            [12] 1243 	orl	ar3,a
      004A2C 12 38 9C         [24] 1244 	lcall	_ak820_outline_0136
      004A2F EB               [12] 1245 	mov	a,r3
      004A30 F0               [24] 1246 	movx	@dptr,a
                                   1247 ;	keyboards/ajazz/ak820/ak820_tapping.c:130: for (uint8_t i = 0; i < SOURCES; ++i) {
      004A31 0F               [12] 1248 	inc	r7
      004A32 80 DE            [24] 1249 	sjmp	00103$
      004A34                       1250 00105$:
                                   1251 ;	keyboards/ajazz/ak820/ak820_tapping.c:134: }
      004A34 22               [24] 1252 	ret
                                   1253 ;------------------------------------------------------------
                                   1254 ;Allocation info for local variables in function 'ak820_oneshot_process'
                                   1255 ;------------------------------------------------------------
                                   1256 ;id            Allocated with name '_ak820_oneshot_process_PARM_2'
                                   1257 ;pressed       Allocated with name '_ak820_oneshot_process_PARM_3'
                                   1258 ;code          Allocated with name '_ak820_oneshot_process_code_10000_649'
                                   1259 ;mods          Allocated with name '_ak820_oneshot_process_mods_10000_650'
                                   1260 ;i             Allocated with name '_ak820_oneshot_process_i_40000_665'
                                   1261 ;------------------------------------------------------------
                                   1262 ;	keyboards/ajazz/ak820/ak820_tapping.c:143: bool ak820_oneshot_process(uint16_t code, uint8_t id, bool pressed) {
                                   1263 ;	-----------------------------------------
                                   1264 ;	 function ak820_oneshot_process
                                   1265 ;	-----------------------------------------
      004A35                       1266 _ak820_oneshot_process:
      004A35 12 38 82         [24] 1267 	lcall	_ak820_outline_0110
      004A38 90 06 8C         [24] 1268 	mov	dptr,#_ak820_oneshot_process_code_10000_649
      004A3B 12 38 87         [24] 1269 	lcall	_ak820_outline_0111
                                   1270 ;	keyboards/ajazz/ak820/ak820_tapping.c:145: if (id == NONE || get_repeat_key_count()) return true;
      004A3E 90 06 8A         [24] 1271 	mov	dptr,#_ak820_oneshot_process_PARM_2
      004A41 E0               [24] 1272 	movx	a,@dptr
      004A42 FF               [12] 1273 	mov	r7,a
      004A43 BF FF 02         [24] 1274 	cjne	r7,#0xff,00265$
      004A46 80 0B            [24] 1275 	sjmp	00101$
      004A48                       1276 00265$:
      004A48 C0 07            [24] 1277 	push	ar7
      004A4A 12 A6 DC         [24] 1278 	lcall	_get_repeat_key_count
      004A4D E5 82            [12] 1279 	mov	a, dpl
      004A4F D0 07            [24] 1280 	pop	ar7
      004A51 60 04            [24] 1281 	jz	00102$
      004A53                       1282 00101$:
      004A53 75 82 01         [24] 1283 	mov	dpl, #0x01
      004A56 22               [24] 1284 	ret
      004A57                       1285 00102$:
                                   1286 ;	keyboards/ajazz/ak820/ak820_tapping.c:148: if (code >= QK_MAGIC_GUI_ON && code <= QK_MAGIC_TOGGLE_GUI) return true;
      004A57 90 06 8C         [24] 1287 	mov	dptr,#_ak820_oneshot_process_code_10000_649
      004A5A 12 38 6A         [24] 1288 	lcall	_ak820_outline_0086
      004A5D C3               [12] 1289 	clr	c
      004A5E ED               [12] 1290 	mov	a,r5
      004A5F 94 09            [12] 1291 	subb	a,#0x09
      004A61 EE               [12] 1292 	mov	a,r6
      004A62 94 70            [12] 1293 	subb	a,#0x70
      004A64 40 0C            [24] 1294 	jc	00105$
      004A66 74 0B            [12] 1295 	mov	a,#0x0b
      004A68 9D               [12] 1296 	subb	a,r5
      004A69 74 70            [12] 1297 	mov	a,#0x70
      004A6B 9E               [12] 1298 	subb	a,r6
      004A6C 40 04            [24] 1299 	jc	00105$
                                   1300 ;	free result
      004A6E 75 82 01         [24] 1301 	mov	dpl, #0x01
      004A71 22               [24] 1302 	ret
      004A72                       1303 00105$:
                                   1304 ;	keyboards/ajazz/ak820/ak820_tapping.c:154: if ((code >> 8) == 0x52 && ((uint8_t)code & 0xe0) == 0xa0) {
      004A72 90 06 8C         [24] 1305 	mov	dptr,#_ak820_oneshot_process_code_10000_649
      004A75 E0               [24] 1306 	movx	a,@dptr
      004A76 FB               [12] 1307 	mov	r3,a
      004A77 A3               [24] 1308 	inc	dptr
      004A78 E0               [24] 1309 	movx	a,@dptr
      004A79 F9               [12] 1310 	mov	r1,a
      004A7A B9 52 02         [24] 1311 	cjne	r1,#0x52,00269$
      004A7D 80 03            [24] 1312 	sjmp	00270$
      004A7F                       1313 00269$:
      004A7F 02 4B 26         [24] 1314 	ljmp	00119$
      004A82                       1315 00270$:
      004A82 8B 02            [24] 1316 	mov	ar2,r3
      004A84 53 02 E0         [24] 1317 	anl	ar2,#0xe0
      004A87 BA A0 02         [24] 1318 	cjne	r2,#0xa0,00271$
      004A8A 80 03            [24] 1319 	sjmp	00272$
      004A8C                       1320 00271$:
      004A8C 02 4B 26         [24] 1321 	ljmp	00119$
      004A8F                       1322 00272$:
                                   1323 ;	keyboards/ajazz/ak820/ak820_tapping.c:155: mods = code & 15;
      004A8F 8B 02            [24] 1324 	mov	ar2,r3
      004A91 53 02 0F         [24] 1325 	anl	ar2,#0x0f
      004A94 90 06 8E         [24] 1326 	mov	dptr,#_ak820_oneshot_process_mods_10000_650
      004A97 EA               [12] 1327 	mov	a,r2
      004A98 F0               [24] 1328 	movx	@dptr,a
                                   1329 ;	keyboards/ajazz/ak820/ak820_tapping.c:156: if (code & 16) mods <<= 4;
      004A99 EB               [12] 1330 	mov	a,r3
      004A9A 30 E4 08         [24] 1331 	jnb	acc.4,00108$
      004A9D EA               [12] 1332 	mov	a,r2
      004A9E C4               [12] 1333 	swap	a
      004A9F 54 F0            [12] 1334 	anl	a,#0xf0
      004AA1 90 06 8E         [24] 1335 	mov	dptr,#_ak820_oneshot_process_mods_10000_650
      004AA4 F0               [24] 1336 	movx	@dptr,a
      004AA5                       1337 00108$:
                                   1338 ;	keyboards/ajazz/ak820/ak820_tapping.c:157: if (pressed) {
      004AA5 90 06 8B         [24] 1339 	mov	dptr,#_ak820_oneshot_process_PARM_3
      004AA8 E0               [24] 1340 	movx	a,@dptr
      004AA9 60 2E            [24] 1341 	jz	00116$
                                   1342 ;	keyboards/ajazz/ak820/ak820_tapping.c:158: source_state[id] |= SOURCE_ONESHOT;
      004AAB EF               [12] 1343 	mov	a,r7
      004AAC 12 4B B6         [24] 1344 	lcall	_ak820_outline_0026
      004AAF 43 02 08         [24] 1345 	orl	ar2,#0x08
      004AB2 12 4C 04         [24] 1346 	lcall	_ak820_outline_0096
                                   1347 ;	keyboards/ajazz/ak820/ak820_tapping.c:159: source_state[id] &= ~SOURCE_ONESHOT_USED;
      004AB5 53 02 EF         [24] 1348 	anl	ar2,#0xef
      004AB8 12 4C 04         [24] 1349 	lcall	_ak820_outline_0096
                                   1350 ;	keyboards/ajazz/ak820/ak820_tapping.c:160: if (ak820_oneshot_target != NONE) source_state[id] |= SOURCE_ONESHOT_USED;
      004ABB 90 0E 0E         [24] 1351 	mov	dptr,#_ak820_oneshot_target
      004ABE E0               [24] 1352 	movx	a,@dptr
      004ABF FA               [12] 1353 	mov	r2,a
      004AC0 BA FF 02         [24] 1354 	cjne	r2,#0xff,00275$
      004AC3 80 09            [24] 1355 	sjmp	00110$
      004AC5                       1356 00275$:
      004AC5 12 4B E8         [24] 1357 	lcall	_ak820_outline_0065
      004AC8 43 02 10         [24] 1358 	orl	ar2,#0x10
      004ACB 12 4C 04         [24] 1359 	lcall	_ak820_outline_0096
      004ACE                       1360 00110$:
                                   1361 ;	keyboards/ajazz/ak820/ak820_tapping.c:161: register_mods(mods);
      004ACE 90 06 8E         [24] 1362 	mov	dptr,#_ak820_oneshot_process_mods_10000_650
      004AD1 E0               [24] 1363 	movx	a,@dptr
      004AD2 F5 82            [12] 1364 	mov	dpl,a
      004AD4 12 7A 83         [24] 1365 	lcall	_register_mods
      004AD7 80 49            [24] 1366 	sjmp	00117$
      004AD9                       1367 00116$:
                                   1368 ;	keyboards/ajazz/ak820/ak820_tapping.c:162: } else if (source_state[id] & SOURCE_ONESHOT) {
      004AD9 EF               [12] 1369 	mov	a,r7
      004ADA 12 4B B6         [24] 1370 	lcall	_ak820_outline_0026
      004ADD 30 E3 42         [24] 1371 	jnb	acc.3,00117$
                                   1372 ;	keyboards/ajazz/ak820/ak820_tapping.c:163: if (!(source_state[id] & SOURCE_ONESHOT_USED)) {
      004AE0 EA               [12] 1373 	mov	a,r2
      004AE1 20 E4 24         [24] 1374 	jb	acc.4,00112$
                                   1375 ;	keyboards/ajazz/ak820/ak820_tapping.c:164: add_owned_mods(mods & ~ak820_oneshot_mods);
      004AE4 90 06 88         [24] 1376 	mov	dptr,#_ak820_oneshot_mods
      004AE7 E0               [24] 1377 	movx	a,@dptr
      004AE8 F4               [12] 1378 	cpl	a
      004AE9 FA               [12] 1379 	mov	r2,a
      004AEA 90 06 8E         [24] 1380 	mov	dptr,#_ak820_oneshot_process_mods_10000_650
      004AED E0               [24] 1381 	movx	a,@dptr
      004AEE F9               [12] 1382 	mov	r1,a
      004AEF 52 02            [12] 1383 	anl	ar2,a
      004AF1 8A 82            [24] 1384 	mov	dpl, r2
      004AF3 C0 04            [24] 1385 	push	ar4
      004AF5 C0 03            [24] 1386 	push	ar3
      004AF7 C0 01            [24] 1387 	push	ar1
      004AF9 12 81 5D         [24] 1388 	lcall	_add_owned_mods
      004AFC D0 01            [24] 1389 	pop	ar1
      004AFE D0 03            [24] 1390 	pop	ar3
      004B00 D0 04            [24] 1391 	pop	ar4
                                   1392 ;	keyboards/ajazz/ak820/ak820_tapping.c:165: ak820_oneshot_mods |= mods;
      004B02 90 06 88         [24] 1393 	mov	dptr,#_ak820_oneshot_mods
      004B05 E0               [24] 1394 	movx	a,@dptr
      004B06 49               [12] 1395 	orl	a,r1
      004B07 F0               [24] 1396 	movx	@dptr,a
      004B08                       1397 00112$:
                                   1398 ;	keyboards/ajazz/ak820/ak820_tapping.c:167: unregister_mods(mods);
      004B08 90 06 8E         [24] 1399 	mov	dptr,#_ak820_oneshot_process_mods_10000_650
      004B0B E0               [24] 1400 	movx	a,@dptr
      004B0C F5 82            [12] 1401 	mov	dpl,a
      004B0E C0 04            [24] 1402 	push	ar4
      004B10 C0 03            [24] 1403 	push	ar3
      004B12 12 7A 97         [24] 1404 	lcall	_unregister_mods
      004B15 D0 03            [24] 1405 	pop	ar3
      004B17 D0 04            [24] 1406 	pop	ar4
                                   1407 ;	keyboards/ajazz/ak820/ak820_tapping.c:168: source_state[id] &= ~(SOURCE_ONESHOT | SOURCE_ONESHOT_USED);
      004B19 12 4B E8         [24] 1408 	lcall	_ak820_outline_0065
      004B1C 53 02 E7         [24] 1409 	anl	ar2,#0xe7
      004B1F 12 4C 04         [24] 1410 	lcall	_ak820_outline_0096
      004B22                       1411 00117$:
                                   1412 ;	keyboards/ajazz/ak820/ak820_tapping.c:170: return false;
      004B22 75 82 00         [24] 1413 	mov	dpl, #0x00
      004B25 22               [24] 1414 	ret
      004B26                       1415 00119$:
                                   1416 ;	keyboards/ajazz/ak820/ak820_tapping.c:172: if (pressed && code > KC_TRANSPARENT &&
      004B26 90 06 8B         [24] 1417 	mov	dptr,#_ak820_oneshot_process_PARM_3
      004B29 E0               [24] 1418 	movx	a,@dptr
      004B2A 60 56            [24] 1419 	jz	00127$
      004B2C C3               [12] 1420 	clr	c
      004B2D 74 01            [12] 1421 	mov	a,#0x01
      004B2F 9D               [12] 1422 	subb	a,r5
      004B30 E4               [12] 1423 	clr	a
      004B31 9E               [12] 1424 	subb	a,r6
      004B32 50 4E            [24] 1425 	jnc	00127$
                                   1426 ;	free result
                                   1427 ;	keyboards/ajazz/ak820/ak820_tapping.c:173: !(code >= KC_LCTL && code <= KC_RGUI) &&
      004B34 C3               [12] 1428 	clr	c
      004B35 ED               [12] 1429 	mov	a,r5
      004B36 94 E0            [12] 1430 	subb	a,#0xe0
      004B38 EE               [12] 1431 	mov	a,r6
      004B39 94 00            [12] 1432 	subb	a,#0x00
      004B3B 40 07            [24] 1433 	jc	00132$
      004B3D 74 E7            [12] 1434 	mov	a,#0xe7
      004B3F 9D               [12] 1435 	subb	a,r5
      004B40 E4               [12] 1436 	clr	a
      004B41 9E               [12] 1437 	subb	a,r6
      004B42 50 3E            [24] 1438 	jnc	00127$
                                   1439 ;	free result
      004B44                       1440 00132$:
                                   1441 ;	keyboards/ajazz/ak820/ak820_tapping.c:174: !(code >= QK_TO && code <= QK_LAYER_TAP_TOGGLE_MAX)) {
      004B44 74 AE            [12] 1442 	mov	a,#0x100 - 0x52
      004B46 2E               [12] 1443 	add	a,r6
      004B47 50 09            [24] 1444 	jnc	00172$
      004B49 C3               [12] 1445 	clr	c
      004B4A 74 DF            [12] 1446 	mov	a,#0xdf
      004B4C 9D               [12] 1447 	subb	a,r5
      004B4D 74 52            [12] 1448 	mov	a,#0x52
      004B4F 9E               [12] 1449 	subb	a,r6
      004B50 50 30            [24] 1450 	jnc	00127$
                                   1451 ;	free result
                                   1452 ;	keyboards/ajazz/ak820/ak820_tapping.c:175: for (uint8_t i = 0; i < SOURCES; ++i)
      004B52                       1453 00172$:
      004B52 7E 00            [12] 1454 	mov	r6,#0x00
      004B54                       1455 00134$:
      004B54 BE 82 00         [24] 1456 	cjne	r6,#0x82,00284$
      004B57                       1457 00284$:
      004B57 50 12            [24] 1458 	jnc	00123$
                                   1459 ;	keyboards/ajazz/ak820/ak820_tapping.c:176: if (source_state[i] & SOURCE_ONESHOT) source_state[i] |= SOURCE_ONESHOT_USED;
      004B59 EE               [12] 1460 	mov	a,r6
      004B5A 12 4B F6         [24] 1461 	lcall	_ak820_outline_0079
      004B5D 30 E3 08         [24] 1462 	jnb	acc.3,00135$
      004B60 43 03 10         [24] 1463 	orl	ar3,#0x10
      004B63 12 38 97         [24] 1464 	lcall	_ak820_outline_0126
      004B66 EB               [12] 1465 	mov	a,r3
      004B67 F0               [24] 1466 	movx	@dptr,a
      004B68                       1467 00135$:
                                   1468 ;	keyboards/ajazz/ak820/ak820_tapping.c:175: for (uint8_t i = 0; i < SOURCES; ++i)
      004B68 0E               [12] 1469 	inc	r6
      004B69 80 E9            [24] 1470 	sjmp	00134$
      004B6B                       1471 00123$:
                                   1472 ;	keyboards/ajazz/ak820/ak820_tapping.c:177: if (ak820_oneshot_mods) {
      004B6B 90 06 88         [24] 1473 	mov	dptr,#_ak820_oneshot_mods
      004B6E E0               [24] 1474 	movx	a,@dptr
      004B6F FE               [12] 1475 	mov	r6,a
      004B70 E0               [24] 1476 	movx	a,@dptr
      004B71 60 0F            [24] 1477 	jz	00127$
                                   1478 ;	keyboards/ajazz/ak820/ak820_tapping.c:178: ak820_oneshot_consumed = ak820_oneshot_mods;
      004B73 90 06 89         [24] 1479 	mov	dptr,#_ak820_oneshot_consumed
      004B76 EE               [12] 1480 	mov	a,r6
      004B77 F0               [24] 1481 	movx	@dptr,a
                                   1482 ;	keyboards/ajazz/ak820/ak820_tapping.c:179: ak820_oneshot_target = id;
      004B78 90 0E 0E         [24] 1483 	mov	dptr,#_ak820_oneshot_target
      004B7B EF               [12] 1484 	mov	a,r7
      004B7C F0               [24] 1485 	movx	@dptr,a
                                   1486 ;	keyboards/ajazz/ak820/ak820_tapping.c:180: ak820_oneshot_mods = 0;
      004B7D 90 06 88         [24] 1487 	mov	dptr,#_ak820_oneshot_mods
      004B80 E4               [12] 1488 	clr	a
      004B81 F0               [24] 1489 	movx	@dptr,a
      004B82                       1490 00127$:
                                   1491 ;	keyboards/ajazz/ak820/ak820_tapping.c:183: return true;
      004B82 75 82 01         [24] 1492 	mov	dpl, #0x01
                                   1493 ;	keyboards/ajazz/ak820/ak820_tapping.c:184: }
      004B85 22               [24] 1494 	ret
                                   1495 	.area CSEG    (CODE)
                                   1496 	.area CONST   (CODE)
                                   1497 	.area XINIT   (CODE)
      00C5B8                       1498 __xinit__pending:
      00C5B8 FF                    1499 	.db #0xff	; 255
      00C5B9                       1500 __xinit__ak820_oneshot_target:
      00C5B9 FF                    1501 	.db #0xff	; 255
                                   1502 	.area CABS    (ABS,CODE)
                                   1503 
                                   1504 ; Experimental exact instruction outlining.
                                   1505 	.globl _ak820_outline_0009
                                   1506 	.globl _ak820_outline_0010
                                   1507 	.globl _ak820_outline_0012
                                   1508 	.globl _ak820_outline_0015
                                   1509 	.globl _ak820_outline_0017
                                   1510 	.globl _ak820_outline_0021
                                   1511 	.globl _ak820_outline_0024
                                   1512 	.globl _ak820_outline_0026
                                   1513 	.globl _ak820_outline_0032
                                   1514 	.globl _ak820_outline_0033
                                   1515 	.globl _ak820_outline_0034
                                   1516 	.globl _ak820_outline_0037
                                   1517 	.globl _ak820_outline_0053
                                   1518 	.globl _ak820_outline_0058
                                   1519 	.globl _ak820_outline_0060
                                   1520 	.globl _ak820_outline_0065
                                   1521 	.globl _ak820_outline_0076
                                   1522 	.globl _ak820_outline_0077
                                   1523 	.globl _ak820_outline_0079
                                   1524 	.globl _ak820_outline_0086
                                   1525 	.globl _ak820_outline_0096
                                   1526 	.globl _ak820_outline_0100
                                   1527 	.globl _ak820_outline_0105
                                   1528 	.globl _ak820_outline_0110
                                   1529 	.globl _ak820_outline_0111
                                   1530 	.globl _ak820_outline_0120
                                   1531 	.globl _ak820_outline_0125
                                   1532 	.globl _ak820_outline_0126
                                   1533 	.globl _ak820_outline_0136
                                   1534 	.globl _ak820_outline_0146
                                   1535 	.globl _ak820_outline_0157
                                   1536 	.globl _ak820_outline_0160
                                   1537 	.globl _ak820_outline_0192
                                   1538 
                                   1539 	.area CSEG (CODE)
                                   1540 ; function ak820_outline_0009
      004B86                       1541 _ak820_outline_0009:
      004B86 E0               [24] 1542 	movx	a,@dptr
      004B87 FE               [12] 1543 	mov	r6,a
      004B88 A3               [24] 1544 	inc	dptr
      004B89 E0               [24] 1545 	movx	a,@dptr
      004B8A FF               [12] 1546 	mov	r7,a
      004B8B 8E 04            [24] 1547 	mov	ar4,r6
      004B8D 8F 05            [24] 1548 	mov	ar5,r7
      004B8F 22               [24] 1549 	ret
                                   1550 
                                   1551 	.area CSEG (CODE)
                                   1552 ; function ak820_outline_0015
      004B90                       1553 _ak820_outline_0015:
      004B90 74 05            [12] 1554 	mov	a,#0x05
      004B92 2E               [12] 1555 	add	a,r6
      004B93 FB               [12] 1556 	mov	r3,a
      004B94 E4               [12] 1557 	clr	a
      004B95 3F               [12] 1558 	addc	a,r7
      004B96 FC               [12] 1559 	mov	r4,a
      004B97 8B 82            [24] 1560 	mov	dpl,r3
      004B99 8C 83            [24] 1561 	mov	dph,r4
      004B9B 22               [24] 1562 	ret
                                   1563 
                                   1564 	.area CSEG (CODE)
                                   1565 ; function ak820_outline_0024
      004B9C                       1566 _ak820_outline_0024:
      004B9C 90 0D FD         [24] 1567 	mov	dptr,#___memcpy_PARM_2
      004B9F EC               [12] 1568 	mov	a,r4
      004BA0 F0               [24] 1569 	movx	@dptr,a
      004BA1 ED               [12] 1570 	mov	a,r5
      004BA2 A3               [24] 1571 	inc	dptr
      004BA3 F0               [24] 1572 	movx	@dptr,a
      004BA4 E4               [12] 1573 	clr	a
      004BA5 A3               [24] 1574 	inc	dptr
      004BA6 F0               [24] 1575 	movx	@dptr,a
      004BA7 90 0E 00         [24] 1576 	mov	dptr,#___memcpy_PARM_3
      004BAA 74 02            [12] 1577 	mov	a,#0x02
      004BAC F0               [24] 1578 	movx	@dptr,a
      004BAD E4               [12] 1579 	clr	a
      004BAE A3               [24] 1580 	inc	dptr
      004BAF F0               [24] 1581 	movx	@dptr,a
      004BB0 90 06 7A         [24] 1582 	mov	dptr,#_ak820_tapping_source_PARM_1
      004BB3 F5 F0            [12] 1583 	mov	b,a
      004BB5 22               [24] 1584 	ret
                                   1585 
                                   1586 	.area CSEG (CODE)
                                   1587 ; function ak820_outline_0026
      004BB6                       1588 _ak820_outline_0026:
      004BB6 24 F4            [12] 1589 	add	a,#_source_state
      004BB8 FB               [12] 1590 	mov	r3,a
      004BB9 E4               [12] 1591 	clr	a
      004BBA 34 05            [12] 1592 	addc	a,#(_source_state>>8)
      004BBC FC               [12] 1593 	mov	r4,a
      004BBD 8B 82            [24] 1594 	mov	dpl,r3
      004BBF 8C 83            [24] 1595 	mov	dph,r4
      004BC1 E0               [24] 1596 	movx	a,@dptr
      004BC2 FA               [12] 1597 	mov	r2,a
      004BC3 22               [24] 1598 	ret
                                   1599 
                                   1600 	.area CSEG (CODE)
                                   1601 ; function ak820_outline_0033
      004BC4                       1602 _ak820_outline_0033:
      004BC4 2E               [12] 1603 	add	a,r6
      004BC5 FA               [12] 1604 	mov	r2,a
      004BC6 E4               [12] 1605 	clr	a
      004BC7 3F               [12] 1606 	addc	a,r7
      004BC8 FB               [12] 1607 	mov	r3,a
      004BC9 8A 82            [24] 1608 	mov	dpl,r2
      004BCB 8B 83            [24] 1609 	mov	dph,r3
      004BCD E0               [24] 1610 	movx	a,@dptr
      004BCE 22               [24] 1611 	ret
                                   1612 
                                   1613 	.area CSEG (CODE)
                                   1614 ; function ak820_outline_0034
      004BCF                       1615 _ak820_outline_0034:
      004BCF 2E               [12] 1616 	add	a,r6
      004BD0 FC               [12] 1617 	mov	r4,a
      004BD1 E4               [12] 1618 	clr	a
      004BD2 3F               [12] 1619 	addc	a,r7
      004BD3 FD               [12] 1620 	mov	r5,a
      004BD4 8C 82            [24] 1621 	mov	dpl,r4
      004BD6 8D 83            [24] 1622 	mov	dph,r5
      004BD8 E0               [24] 1623 	movx	a,@dptr
      004BD9 22               [24] 1624 	ret
                                   1625 
                                   1626 	.area CSEG (CODE)
                                   1627 ; function ak820_outline_0058
      004BDA                       1628 _ak820_outline_0058:
      004BDA FE               [12] 1629 	mov	r6,a
      004BDB 8D 82            [24] 1630 	mov	dpl,r5
      004BDD 8E 83            [24] 1631 	mov	dph,r6
      004BDF E0               [24] 1632 	movx	a,@dptr
      004BE0 FC               [12] 1633 	mov	r4,a
      004BE1 22               [24] 1634 	ret
                                   1635 
                                   1636 	.area CSEG (CODE)
                                   1637 ; function ak820_outline_0060
      004BE2                       1638 _ak820_outline_0060:
      004BE2 EE               [12] 1639 	mov	a,r6
      004BE3 F0               [24] 1640 	movx	@dptr,a
      004BE4 EF               [12] 1641 	mov	a,r7
      004BE5 A3               [24] 1642 	inc	dptr
      004BE6 F0               [24] 1643 	movx	@dptr,a
      004BE7 22               [24] 1644 	ret
                                   1645 
                                   1646 	.area CSEG (CODE)
                                   1647 ; function ak820_outline_0065
      004BE8                       1648 _ak820_outline_0065:
      004BE8 8B 82            [24] 1649 	mov	dpl,r3
      004BEA 8C 83            [24] 1650 	mov	dph,r4
      004BEC E0               [24] 1651 	movx	a,@dptr
      004BED FA               [12] 1652 	mov	r2,a
      004BEE 22               [24] 1653 	ret
                                   1654 
                                   1655 	.area CSEG (CODE)
                                   1656 ; function ak820_outline_0077
      004BEF                       1657 _ak820_outline_0077:
      004BEF 8E 00            [24] 1658 	mov	ar0,r6
      004BF1 8F 01            [24] 1659 	mov	ar1,r7
      004BF3 7A 00            [12] 1660 	mov	r2,#0x00
      004BF5 22               [24] 1661 	ret
                                   1662 
                                   1663 	.area CSEG (CODE)
                                   1664 ; function ak820_outline_0079
      004BF6                       1665 _ak820_outline_0079:
      004BF6 24 F4            [12] 1666 	add	a,#_source_state
      004BF8 FC               [12] 1667 	mov	r4,a
      004BF9 E4               [12] 1668 	clr	a
      004BFA 34 05            [12] 1669 	addc	a,#(_source_state>>8)
      004BFC FD               [12] 1670 	mov	r5,a
      004BFD 8C 82            [24] 1671 	mov	dpl,r4
      004BFF 8D 83            [24] 1672 	mov	dph,r5
      004C01 E0               [24] 1673 	movx	a,@dptr
      004C02 FB               [12] 1674 	mov	r3,a
      004C03 22               [24] 1675 	ret
                                   1676 
                                   1677 	.area CSEG (CODE)
                                   1678 ; function ak820_outline_0096
      004C04                       1679 _ak820_outline_0096:
      004C04 8B 82            [24] 1680 	mov	dpl,r3
      004C06 8C 83            [24] 1681 	mov	dph,r4
      004C08 EA               [12] 1682 	mov	a,r2
      004C09 F0               [24] 1683 	movx	@dptr,a
      004C0A 22               [24] 1684 	ret
                                   1685 
                                   1686 	.area CSEG (CODE)
                                   1687 ; function ak820_outline_0100
      004C0B                       1688 _ak820_outline_0100:
      004C0B 74 04            [12] 1689 	mov	a,#0x04
      004C0D 2E               [12] 1690 	add	a,r6
      004C0E FB               [12] 1691 	mov	r3,a
      004C0F E4               [12] 1692 	clr	a
      004C10 3F               [12] 1693 	addc	a,r7
      004C11 FC               [12] 1694 	mov	r4,a
      004C12 8B 82            [24] 1695 	mov	dpl,r3
      004C14 8C 83            [24] 1696 	mov	dph,r4
      004C16 E0               [24] 1697 	movx	a,@dptr
      004C17 22               [24] 1698 	ret
                                   1699 
                                   1700 	.area CSEG (CODE)
                                   1701 ; function ak820_outline_0157
      004C18                       1702 _ak820_outline_0157:
      004C18 90 0E 0D         [24] 1703 	mov	dptr,#_pending
      004C1B 74 FF            [12] 1704 	mov	a,#0xff
      004C1D F0               [24] 1705 	movx	@dptr,a
      004C1E 22               [24] 1706 	ret
