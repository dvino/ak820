                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_combo_cancel
                                     12 	.globl _ak820_combo_tick
                                     13 	.globl _ak820_oneshot_cancel
                                     14 	.globl _ak820_oneshot_post
                                     15 	.globl _ak820_oneshot_process
                                     16 	.globl _ak820_tapping_source
                                     17 	.globl _ak820_tapping_cancel
                                     18 	.globl _ak820_tapping_process
                                     19 	.globl _ak820_tapping_before
                                     20 	.globl _ak820_dynamic_macro_cancel
                                     21 	.globl _ak820_dynamic_macro_task
                                     22 	.globl _ak820_dynamic_macro_observe
                                     23 	.globl _ak820_dynamic_macro_process
                                     24 	.globl _pre_process_record_quantum
                                     25 	.globl _get_record_keycode
                                     26 	.globl _get_repeat_key_count
                                     27 	.globl _repeat_key_cancel
                                     28 	.globl _clear_owned_usages
                                     29 	.globl _owned_usage_key
                                     30 	.globl _clear_owned_keys
                                     31 	.globl _del_owned_key
                                     32 	.globl _add_owned_key
                                     33 	.globl _clear_owned_mods
                                     34 	.globl _del_owned_weak_mods
                                     35 	.globl _add_owned_weak_mods
                                     36 	.globl _del_owned_mods
                                     37 	.globl _add_owned_mods
                                     38 	.globl _clear_weak_mods
                                     39 	.globl _clear_mods
                                     40 	.globl _send_keyboard_report
                                     41 	.globl _layer_hold_clear
                                     42 	.globl _layer_hold_off
                                     43 	.globl _layer_hold_on
                                     44 	.globl _ak820_resolve_key
                                     45 	.globl _layer_xor
                                     46 	.globl _layer_and
                                     47 	.globl _layer_or
                                     48 	.globl _layer_off
                                     49 	.globl _layer_on
                                     50 	.globl _layer_move
                                     51 	.globl _layer_clear
                                     52 	.globl _layer_state_set
                                     53 	.globl _default_layer_xor
                                     54 	.globl _default_layer_and
                                     55 	.globl _default_layer_or
                                     56 	.globl _default_layer_set
                                     57 	.globl _post_process_record_quantum
                                     58 	.globl _process_record_quantum
                                     59 	.globl _action_for_keycode
                                     60 	.globl _mDelaymS
                                     61 	.globl _host_consumer_send
                                     62 	.globl _host_system_send
                                     63 	.globl _host_keyboard_leds
                                     64 	.globl _led_set
                                     65 	.globl _clear_keys_from_report
                                     66 	.globl ___memcpy
                                     67 	.globl _ADC_START
                                     68 	.globl _S0_R_FIFO
                                     69 	.globl _S0_T_FIFO
                                     70 	.globl _S0_FREE
                                     71 	.globl _S0_IF_BYTE
                                     72 	.globl _S0_IF_FIRST
                                     73 	.globl _S0_IF_OV
                                     74 	.globl _S0_FST_ACT
                                     75 	.globl _CP_RL2
                                     76 	.globl _C_T2
                                     77 	.globl _TR2
                                     78 	.globl _EXEN2
                                     79 	.globl _TCLK
                                     80 	.globl _RCLK
                                     81 	.globl _EXF2
                                     82 	.globl _CAP1F
                                     83 	.globl _TF2
                                     84 	.globl _RI
                                     85 	.globl _TI
                                     86 	.globl _RB8
                                     87 	.globl _TB8
                                     88 	.globl _REN
                                     89 	.globl _SM2
                                     90 	.globl _SM1
                                     91 	.globl _SM0
                                     92 	.globl _IT0
                                     93 	.globl _IE0
                                     94 	.globl _IT1
                                     95 	.globl _IE1
                                     96 	.globl _TR0
                                     97 	.globl _TF0
                                     98 	.globl _TR1
                                     99 	.globl _TF1
                                    100 	.globl _P4_0
                                    101 	.globl _P4_1
                                    102 	.globl _P4_2
                                    103 	.globl _P4_3
                                    104 	.globl _P4_4
                                    105 	.globl _P4_5
                                    106 	.globl _P4_6
                                    107 	.globl _RXD
                                    108 	.globl _TXD
                                    109 	.globl _INT0
                                    110 	.globl _INT1
                                    111 	.globl _T0
                                    112 	.globl _T1
                                    113 	.globl _MOSI1
                                    114 	.globl _MISO1
                                    115 	.globl _SCK1
                                    116 	.globl _P3_0
                                    117 	.globl _P3_1
                                    118 	.globl _P3_2
                                    119 	.globl _P3_3
                                    120 	.globl _P3_4
                                    121 	.globl _P3_5
                                    122 	.globl _P3_6
                                    123 	.globl _P3_7
                                    124 	.globl _CAP1_
                                    125 	.globl _T2_
                                    126 	.globl _CAP2_
                                    127 	.globl _T2EX_
                                    128 	.globl _RXD1
                                    129 	.globl _TXD1
                                    130 	.globl _P2_0
                                    131 	.globl _P2_1
                                    132 	.globl _P2_2
                                    133 	.globl _P2_3
                                    134 	.globl _P2_4
                                    135 	.globl _P2_5
                                    136 	.globl _P2_6
                                    137 	.globl _P2_7
                                    138 	.globl _AIN0
                                    139 	.globl _AIN1
                                    140 	.globl _AIN2
                                    141 	.globl _AIN3
                                    142 	.globl _AIN4
                                    143 	.globl _AIN5
                                    144 	.globl _AIN6
                                    145 	.globl _AIN7
                                    146 	.globl _CAP1
                                    147 	.globl _T2
                                    148 	.globl _CAP2
                                    149 	.globl _T2EX
                                    150 	.globl _INT0_
                                    151 	.globl _SCS
                                    152 	.globl _MOSI
                                    153 	.globl _MISO
                                    154 	.globl _SCK
                                    155 	.globl _RXD1_
                                    156 	.globl _TXD1_
                                    157 	.globl _P1_0
                                    158 	.globl _P1_1
                                    159 	.globl _P1_2
                                    160 	.globl _P1_3
                                    161 	.globl _P1_4
                                    162 	.globl _P1_5
                                    163 	.globl _P1_6
                                    164 	.globl _P1_7
                                    165 	.globl _AIN8
                                    166 	.globl _AIN9
                                    167 	.globl _AIN10
                                    168 	.globl _AIN11
                                    169 	.globl _AIN12
                                    170 	.globl _AIN13
                                    171 	.globl _RXD_
                                    172 	.globl _TXD_
                                    173 	.globl _SCL0
                                    174 	.globl _SDA0
                                    175 	.globl _P0_0
                                    176 	.globl _P0_1
                                    177 	.globl _P0_2
                                    178 	.globl _P0_3
                                    179 	.globl _P0_4
                                    180 	.globl _P0_5
                                    181 	.globl _P0_6
                                    182 	.globl _P0_7
                                    183 	.globl _IE_SPI0
                                    184 	.globl _IE_USB
                                    185 	.globl _IE_ADC
                                    186 	.globl _IE_UART1
                                    187 	.globl _IE_PWM_I2C
                                    188 	.globl _IE_GPIO
                                    189 	.globl _IE_WDOG
                                    190 	.globl _PX0
                                    191 	.globl _PT0
                                    192 	.globl _PX1
                                    193 	.globl _PT1
                                    194 	.globl _PS
                                    195 	.globl _PT2
                                    196 	.globl _PL_FLAG
                                    197 	.globl _PH_FLAG
                                    198 	.globl _EX0
                                    199 	.globl _ET0
                                    200 	.globl _EX1
                                    201 	.globl _ET1
                                    202 	.globl _ES
                                    203 	.globl _ET2
                                    204 	.globl _E_DIS
                                    205 	.globl _EA
                                    206 	.globl _P
                                    207 	.globl _F1
                                    208 	.globl _OV
                                    209 	.globl _RS0
                                    210 	.globl _RS1
                                    211 	.globl _F0
                                    212 	.globl _AC
                                    213 	.globl _CY
                                    214 	.globl _I2CS_INT_ST
                                    215 	.globl _I2CX_INT
                                    216 	.globl _LED_STATUS
                                    217 	.globl _LED_DMA_H
                                    218 	.globl _LED_DMA_L
                                    219 	.globl _LED_DMA
                                    220 	.globl _LED_PWM_OE
                                    221 	.globl _LED_COMMON
                                    222 	.globl _ADC_CHAN
                                    223 	.globl _ADC_DAT_H
                                    224 	.globl _ADC_DAT_L
                                    225 	.globl _ADC_DAT
                                    226 	.globl _ADC_CTRL
                                    227 	.globl _SPI1_CK_SE
                                    228 	.globl _SPI1_CTRL
                                    229 	.globl _SPI1_DATA
                                    230 	.globl _SPI1_STAT
                                    231 	.globl _SIF1
                                    232 	.globl _SBAUD1
                                    233 	.globl _SBUF1
                                    234 	.globl _SCON1
                                    235 	.globl _SPI0_SETUP
                                    236 	.globl _SPI0_CK_SE
                                    237 	.globl _SPI0_CTRL
                                    238 	.globl _SPI0_DATA
                                    239 	.globl _SPI0_STAT
                                    240 	.globl _T2CAP1H
                                    241 	.globl _T2CAP1L
                                    242 	.globl _T2CAP1
                                    243 	.globl _TH2
                                    244 	.globl _TL2
                                    245 	.globl _T2COUNT
                                    246 	.globl _RCAP2H
                                    247 	.globl _RCAP2L
                                    248 	.globl _RCAP2
                                    249 	.globl _T2MOD
                                    250 	.globl _T2CON
                                    251 	.globl _SBUF
                                    252 	.globl _SCON
                                    253 	.globl _TH1
                                    254 	.globl _TH0
                                    255 	.globl _TL1
                                    256 	.globl _TL0
                                    257 	.globl _TMOD
                                    258 	.globl _TCON
                                    259 	.globl _XBUS_AUX
                                    260 	.globl _P7
                                    261 	.globl _P6_DIR
                                    262 	.globl _P6_OUT_PU
                                    263 	.globl _P6_IN
                                    264 	.globl _P5_DIR
                                    265 	.globl _P5_OUT_PU
                                    266 	.globl _P5_IN
                                    267 	.globl _P4_LED_KEY
                                    268 	.globl _P4_DIR_PU
                                    269 	.globl _P4_MOD_OC
                                    270 	.globl _P4
                                    271 	.globl _P3_DIR_PU
                                    272 	.globl _P3_MOD_OC
                                    273 	.globl _P3
                                    274 	.globl _P2_DIR_PU
                                    275 	.globl _P2_MOD_OC
                                    276 	.globl _P2
                                    277 	.globl _P1_DIR_PU
                                    278 	.globl _P1_MOD_OC
                                    279 	.globl _P1
                                    280 	.globl _P0_DIR_PU
                                    281 	.globl _P0_MOD_OC
                                    282 	.globl _P0
                                    283 	.globl _ROM_CTRL
                                    284 	.globl _ROM_DATA_HH
                                    285 	.globl _ROM_DATA_HL
                                    286 	.globl _ROM_DATA_HI
                                    287 	.globl _ROM_ADDR_H
                                    288 	.globl _ROM_ADDR_L
                                    289 	.globl _ROM_ADDR
                                    290 	.globl _GPIO_IE
                                    291 	.globl _IP_EX
                                    292 	.globl _IE_EX
                                    293 	.globl _IP
                                    294 	.globl _IE
                                    295 	.globl _WDOG_COUNT
                                    296 	.globl _RESET_KEEP
                                    297 	.globl _WAKE_CTRL
                                    298 	.globl _CLOCK_CFG
                                    299 	.globl _POWER_CFG
                                    300 	.globl _PCON
                                    301 	.globl _GLOBAL_CFG
                                    302 	.globl _SAFE_MOD
                                    303 	.globl _DPH
                                    304 	.globl _DPL
                                    305 	.globl _SP
                                    306 	.globl _A_INV
                                    307 	.globl _B
                                    308 	.globl _ACC
                                    309 	.globl _PSW
                                    310 	.globl _disable_action_cache
                                    311 	.globl _tap_code_delay_PARM_2
                                    312 	.globl _process_action_PARM_2
                                    313 	.globl _action_exec_PARM_1
                                    314 	.globl _tp_buttons
                                    315 	.globl _action_exec
                                    316 	.globl _ak820_action_exec
                                    317 	.globl _process_record
                                    318 	.globl _process_record_handler
                                    319 	.globl _process_action
                                    320 	.globl _register_code
                                    321 	.globl _unregister_code
                                    322 	.globl _tap_code_delay
                                    323 	.globl _tap_code
                                    324 	.globl _register_mods
                                    325 	.globl _unregister_mods
                                    326 	.globl _register_weak_mods
                                    327 	.globl _unregister_weak_mods
                                    328 	.globl _clear_keyboard
                                    329 	.globl _clear_keyboard_but_mods
                                    330 	.globl _clear_keyboard_but_mods_and_keys
                                    331 ;--------------------------------------------------------
                                    332 ; special function registers
                                    333 ;--------------------------------------------------------
                                    334 	.area RSEG    (ABS,DATA)
      000000                        335 	.org 0x0000
                           0000D0   336 _PSW	=	0x00d0
                           0000E0   337 _ACC	=	0x00e0
                           0000F0   338 _B	=	0x00f0
                           0000FD   339 _A_INV	=	0x00fd
                           000081   340 _SP	=	0x0081
                           000082   341 _DPL	=	0x0082
                           000083   342 _DPH	=	0x0083
                           0000A1   343 _SAFE_MOD	=	0x00a1
                           0000B1   344 _GLOBAL_CFG	=	0x00b1
                           000087   345 _PCON	=	0x0087
                           0000BA   346 _POWER_CFG	=	0x00ba
                           0000B9   347 _CLOCK_CFG	=	0x00b9
                           0000A9   348 _WAKE_CTRL	=	0x00a9
                           0000FE   349 _RESET_KEEP	=	0x00fe
                           0000FF   350 _WDOG_COUNT	=	0x00ff
                           0000A8   351 _IE	=	0x00a8
                           0000B8   352 _IP	=	0x00b8
                           0000E8   353 _IE_EX	=	0x00e8
                           0000E9   354 _IP_EX	=	0x00e9
                           0000B2   355 _GPIO_IE	=	0x00b2
                           008584   356 _ROM_ADDR	=	0x8584
                           000084   357 _ROM_ADDR_L	=	0x0084
                           000085   358 _ROM_ADDR_H	=	0x0085
                           008F8E   359 _ROM_DATA_HI	=	0x8f8e
                           00008E   360 _ROM_DATA_HL	=	0x008e
                           00008F   361 _ROM_DATA_HH	=	0x008f
                           000086   362 _ROM_CTRL	=	0x0086
                           000080   363 _P0	=	0x0080
                           0000C4   364 _P0_MOD_OC	=	0x00c4
                           0000C5   365 _P0_DIR_PU	=	0x00c5
                           000090   366 _P1	=	0x0090
                           000092   367 _P1_MOD_OC	=	0x0092
                           000093   368 _P1_DIR_PU	=	0x0093
                           0000A0   369 _P2	=	0x00a0
                           000094   370 _P2_MOD_OC	=	0x0094
                           000095   371 _P2_DIR_PU	=	0x0095
                           0000B0   372 _P3	=	0x00b0
                           000096   373 _P3_MOD_OC	=	0x0096
                           000097   374 _P3_DIR_PU	=	0x0097
                           0000C0   375 _P4	=	0x00c0
                           0000C2   376 _P4_MOD_OC	=	0x00c2
                           0000C3   377 _P4_DIR_PU	=	0x00c3
                           0000C1   378 _P4_LED_KEY	=	0x00c1
                           0000AA   379 _P5_IN	=	0x00aa
                           0000AB   380 _P5_OUT_PU	=	0x00ab
                           0000AC   381 _P5_DIR	=	0x00ac
                           0000AD   382 _P6_IN	=	0x00ad
                           0000AE   383 _P6_OUT_PU	=	0x00ae
                           0000AF   384 _P6_DIR	=	0x00af
                           0000F1   385 _P7	=	0x00f1
                           0000A2   386 _XBUS_AUX	=	0x00a2
                           000088   387 _TCON	=	0x0088
                           000089   388 _TMOD	=	0x0089
                           00008A   389 _TL0	=	0x008a
                           00008B   390 _TL1	=	0x008b
                           00008C   391 _TH0	=	0x008c
                           00008D   392 _TH1	=	0x008d
                           000098   393 _SCON	=	0x0098
                           000099   394 _SBUF	=	0x0099
                           0000C8   395 _T2CON	=	0x00c8
                           0000C9   396 _T2MOD	=	0x00c9
                           00CBCA   397 _RCAP2	=	0xcbca
                           0000CA   398 _RCAP2L	=	0x00ca
                           0000CB   399 _RCAP2H	=	0x00cb
                           00CDCC   400 _T2COUNT	=	0xcdcc
                           0000CC   401 _TL2	=	0x00cc
                           0000CD   402 _TH2	=	0x00cd
                           00CFCE   403 _T2CAP1	=	0xcfce
                           0000CE   404 _T2CAP1L	=	0x00ce
                           0000CF   405 _T2CAP1H	=	0x00cf
                           0000F8   406 _SPI0_STAT	=	0x00f8
                           0000F9   407 _SPI0_DATA	=	0x00f9
                           0000FA   408 _SPI0_CTRL	=	0x00fa
                           0000FB   409 _SPI0_CK_SE	=	0x00fb
                           0000FC   410 _SPI0_SETUP	=	0x00fc
                           0000BC   411 _SCON1	=	0x00bc
                           0000BD   412 _SBUF1	=	0x00bd
                           0000BE   413 _SBAUD1	=	0x00be
                           0000BF   414 _SIF1	=	0x00bf
                           0000B4   415 _SPI1_STAT	=	0x00b4
                           0000B5   416 _SPI1_DATA	=	0x00b5
                           0000B6   417 _SPI1_CTRL	=	0x00b6
                           0000B7   418 _SPI1_CK_SE	=	0x00b7
                           0000F3   419 _ADC_CTRL	=	0x00f3
                           00F5F4   420 _ADC_DAT	=	0xf5f4
                           0000F4   421 _ADC_DAT_L	=	0x00f4
                           0000F5   422 _ADC_DAT_H	=	0x00f5
                           0000F6   423 _ADC_CHAN	=	0x00f6
                           0000A6   424 _LED_COMMON	=	0x00a6
                           0000A7   425 _LED_PWM_OE	=	0x00a7
                           00C7C6   426 _LED_DMA	=	0xc7c6
                           0000C6   427 _LED_DMA_L	=	0x00c6
                           0000C7   428 _LED_DMA_H	=	0x00c7
                           0000F7   429 _LED_STATUS	=	0x00f7
                           0000B3   430 _I2CX_INT	=	0x00b3
                           0000BB   431 _I2CS_INT_ST	=	0x00bb
                                    432 ;--------------------------------------------------------
                                    433 ; special function bits
                                    434 ;--------------------------------------------------------
                                    435 	.area RSEG    (ABS,DATA)
      000000                        436 	.org 0x0000
                           0000D7   437 _CY	=	0x00d7
                           0000D6   438 _AC	=	0x00d6
                           0000D5   439 _F0	=	0x00d5
                           0000D4   440 _RS1	=	0x00d4
                           0000D3   441 _RS0	=	0x00d3
                           0000D2   442 _OV	=	0x00d2
                           0000D1   443 _F1	=	0x00d1
                           0000D0   444 _P	=	0x00d0
                           0000AF   445 _EA	=	0x00af
                           0000AE   446 _E_DIS	=	0x00ae
                           0000AD   447 _ET2	=	0x00ad
                           0000AC   448 _ES	=	0x00ac
                           0000AB   449 _ET1	=	0x00ab
                           0000AA   450 _EX1	=	0x00aa
                           0000A9   451 _ET0	=	0x00a9
                           0000A8   452 _EX0	=	0x00a8
                           0000BF   453 _PH_FLAG	=	0x00bf
                           0000BE   454 _PL_FLAG	=	0x00be
                           0000BD   455 _PT2	=	0x00bd
                           0000BC   456 _PS	=	0x00bc
                           0000BB   457 _PT1	=	0x00bb
                           0000BA   458 _PX1	=	0x00ba
                           0000B9   459 _PT0	=	0x00b9
                           0000B8   460 _PX0	=	0x00b8
                           0000EF   461 _IE_WDOG	=	0x00ef
                           0000EE   462 _IE_GPIO	=	0x00ee
                           0000ED   463 _IE_PWM_I2C	=	0x00ed
                           0000EC   464 _IE_UART1	=	0x00ec
                           0000EB   465 _IE_ADC	=	0x00eb
                           0000E9   466 _IE_USB	=	0x00e9
                           0000E8   467 _IE_SPI0	=	0x00e8
                           000087   468 _P0_7	=	0x0087
                           000086   469 _P0_6	=	0x0086
                           000085   470 _P0_5	=	0x0085
                           000084   471 _P0_4	=	0x0084
                           000083   472 _P0_3	=	0x0083
                           000082   473 _P0_2	=	0x0082
                           000081   474 _P0_1	=	0x0081
                           000080   475 _P0_0	=	0x0080
                           000081   476 _SDA0	=	0x0081
                           000080   477 _SCL0	=	0x0080
                           000083   478 _TXD_	=	0x0083
                           000082   479 _RXD_	=	0x0082
                           000085   480 _AIN13	=	0x0085
                           000084   481 _AIN12	=	0x0084
                           000083   482 _AIN11	=	0x0083
                           000082   483 _AIN10	=	0x0082
                           000081   484 _AIN9	=	0x0081
                           000080   485 _AIN8	=	0x0080
                           000097   486 _P1_7	=	0x0097
                           000096   487 _P1_6	=	0x0096
                           000095   488 _P1_5	=	0x0095
                           000094   489 _P1_4	=	0x0094
                           000093   490 _P1_3	=	0x0093
                           000092   491 _P1_2	=	0x0092
                           000091   492 _P1_1	=	0x0091
                           000090   493 _P1_0	=	0x0090
                           000097   494 _TXD1_	=	0x0097
                           000096   495 _RXD1_	=	0x0096
                           000097   496 _SCK	=	0x0097
                           000096   497 _MISO	=	0x0096
                           000095   498 _MOSI	=	0x0095
                           000094   499 _SCS	=	0x0094
                           000092   500 _INT0_	=	0x0092
                           000091   501 _T2EX	=	0x0091
                           000091   502 _CAP2	=	0x0091
                           000090   503 _T2	=	0x0090
                           000090   504 _CAP1	=	0x0090
                           000097   505 _AIN7	=	0x0097
                           000096   506 _AIN6	=	0x0096
                           000095   507 _AIN5	=	0x0095
                           000094   508 _AIN4	=	0x0094
                           000093   509 _AIN3	=	0x0093
                           000092   510 _AIN2	=	0x0092
                           000091   511 _AIN1	=	0x0091
                           000090   512 _AIN0	=	0x0090
                           0000A7   513 _P2_7	=	0x00a7
                           0000A6   514 _P2_6	=	0x00a6
                           0000A5   515 _P2_5	=	0x00a5
                           0000A4   516 _P2_4	=	0x00a4
                           0000A3   517 _P2_3	=	0x00a3
                           0000A2   518 _P2_2	=	0x00a2
                           0000A1   519 _P2_1	=	0x00a1
                           0000A0   520 _P2_0	=	0x00a0
                           0000A7   521 _TXD1	=	0x00a7
                           0000A6   522 _RXD1	=	0x00a6
                           0000A5   523 _T2EX_	=	0x00a5
                           0000A5   524 _CAP2_	=	0x00a5
                           0000A4   525 _T2_	=	0x00a4
                           0000A4   526 _CAP1_	=	0x00a4
                           0000B7   527 _P3_7	=	0x00b7
                           0000B6   528 _P3_6	=	0x00b6
                           0000B5   529 _P3_5	=	0x00b5
                           0000B4   530 _P3_4	=	0x00b4
                           0000B3   531 _P3_3	=	0x00b3
                           0000B2   532 _P3_2	=	0x00b2
                           0000B1   533 _P3_1	=	0x00b1
                           0000B0   534 _P3_0	=	0x00b0
                           0000B7   535 _SCK1	=	0x00b7
                           0000B6   536 _MISO1	=	0x00b6
                           0000B5   537 _MOSI1	=	0x00b5
                           0000B5   538 _T1	=	0x00b5
                           0000B4   539 _T0	=	0x00b4
                           0000B3   540 _INT1	=	0x00b3
                           0000B2   541 _INT0	=	0x00b2
                           0000B1   542 _TXD	=	0x00b1
                           0000B0   543 _RXD	=	0x00b0
                           0000C6   544 _P4_6	=	0x00c6
                           0000C5   545 _P4_5	=	0x00c5
                           0000C4   546 _P4_4	=	0x00c4
                           0000C3   547 _P4_3	=	0x00c3
                           0000C2   548 _P4_2	=	0x00c2
                           0000C1   549 _P4_1	=	0x00c1
                           0000C0   550 _P4_0	=	0x00c0
                           00008F   551 _TF1	=	0x008f
                           00008E   552 _TR1	=	0x008e
                           00008D   553 _TF0	=	0x008d
                           00008C   554 _TR0	=	0x008c
                           00008B   555 _IE1	=	0x008b
                           00008A   556 _IT1	=	0x008a
                           000089   557 _IE0	=	0x0089
                           000088   558 _IT0	=	0x0088
                           00009F   559 _SM0	=	0x009f
                           00009E   560 _SM1	=	0x009e
                           00009D   561 _SM2	=	0x009d
                           00009C   562 _REN	=	0x009c
                           00009B   563 _TB8	=	0x009b
                           00009A   564 _RB8	=	0x009a
                           000099   565 _TI	=	0x0099
                           000098   566 _RI	=	0x0098
                           0000CF   567 _TF2	=	0x00cf
                           0000CF   568 _CAP1F	=	0x00cf
                           0000CE   569 _EXF2	=	0x00ce
                           0000CD   570 _RCLK	=	0x00cd
                           0000CC   571 _TCLK	=	0x00cc
                           0000CB   572 _EXEN2	=	0x00cb
                           0000CA   573 _TR2	=	0x00ca
                           0000C9   574 _C_T2	=	0x00c9
                           0000C8   575 _CP_RL2	=	0x00c8
                           0000FF   576 _S0_FST_ACT	=	0x00ff
                           0000FE   577 _S0_IF_OV	=	0x00fe
                           0000FD   578 _S0_IF_FIRST	=	0x00fd
                           0000FC   579 _S0_IF_BYTE	=	0x00fc
                           0000FB   580 _S0_FREE	=	0x00fb
                           0000FA   581 _S0_T_FIFO	=	0x00fa
                           0000F8   582 _S0_R_FIFO	=	0x00f8
                           0000F7   583 _ADC_START	=	0x00f7
                                    584 ;--------------------------------------------------------
                                    585 ; overlayable register banks
                                    586 ;--------------------------------------------------------
                                    587 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        588 	.ds 8
                                    589 ;--------------------------------------------------------
                                    590 ; internal ram data
                                    591 ;--------------------------------------------------------
                                    592 	.area DSEG    (DATA)
      000027                        593 _process_record_sloc0_1_0:
      000027                        594 	.ds 1
      000028                        595 _process_action_sloc0_1_0:
      000028                        596 	.ds 1
                                    597 ;--------------------------------------------------------
                                    598 ; overlayable items in internal ram
                                    599 ;--------------------------------------------------------
                                    600 ;--------------------------------------------------------
                                    601 ; indirectly addressable internal ram data
                                    602 ;--------------------------------------------------------
                                    603 	.area ISEG    (DATA)
                                    604 ;--------------------------------------------------------
                                    605 ; absolute internal ram data
                                    606 ;--------------------------------------------------------
                                    607 	.area IABS    (ABS,DATA)
                                    608 	.area IABS    (ABS,DATA)
                                    609 ;--------------------------------------------------------
                                    610 ; bit data
                                    611 ;--------------------------------------------------------
                                    612 	.area BSEG    (BIT)
      000021                        613 _process_action_sloc1_1_0:
      000021                        614 	.ds 1
                                    615 ;--------------------------------------------------------
                                    616 ; paged external ram data
                                    617 ;--------------------------------------------------------
                                    618 	.area PSEG    (PAG,XDATA)
                                    619 ;--------------------------------------------------------
                                    620 ; uninitialized external ram data
                                    621 ;--------------------------------------------------------
                                    622 	.area XSEG    (XDATA)
      00086B                        623 _tp_buttons::
      00086B                        624 	.ds 2
      00086D                        625 _action_exec_PARM_1:
      00086D                        626 	.ds 6
      000873                        627 _action_exec_record_10001_630:
      000873                        628 	.ds 9
      00087C                        629 _ak820_action_exec_event_10000_634:
      00087C                        630 	.ds 2
      00087E                        631 _ak820_action_exec_snapshot_10000_635:
      00087E                        632 	.ds 6
      000884                        633 _process_record_record_10000_638:
      000884                        634 	.ds 3
      000887                        635 _process_record_handler_record_argument_10000_647:
      000887                        636 	.ds 3
      00088A                        637 _process_record_handler_action_10000_648:
      00088A                        638 	.ds 2
      00088C                        639 _process_action_PARM_2:
      00088C                        640 	.ds 2
      00088E                        641 _process_action_record_argument_10000_659:
      00088E                        642 	.ds 3
      000891                        643 _process_action_on_40000_682:
      000891                        644 	.ds 1
      000892                        645 _register_code_code_10000_716:
      000892                        646 	.ds 1
      000893                        647 _unregister_code_code_10000_730:
      000893                        648 	.ds 1
      000894                        649 _tap_code_delay_PARM_2:
      000894                        650 	.ds 2
      000896                        651 _tap_code_delay_code_10000_743:
      000896                        652 	.ds 1
      000897                        653 _tap_code_code_10000_750:
      000897                        654 	.ds 1
      000898                        655 _register_mods_mods_10000_752:
      000898                        656 	.ds 1
      000899                        657 _unregister_mods_mods_10000_756:
      000899                        658 	.ds 1
      00089A                        659 _register_weak_mods_mods_10000_760:
      00089A                        660 	.ds 1
      00089B                        661 _unregister_weak_mods_mods_10000_764:
      00089B                        662 	.ds 1
                                    663 ;--------------------------------------------------------
                                    664 ; absolute external ram data
                                    665 ;--------------------------------------------------------
                                    666 	.area XABS    (ABS,XDATA)
                                    667 ;--------------------------------------------------------
                                    668 ; initialized external ram data
                                    669 ;--------------------------------------------------------
                                    670 	.area XISEG   (XDATA)
      000E1D                        671 _disable_action_cache::
      000E1D                        672 	.ds 1
                                    673 	.area HOME    (CODE)
                                    674 	.area GSINIT0 (CODE)
                                    675 	.area GSINIT1 (CODE)
                                    676 	.area GSINIT2 (CODE)
                                    677 	.area GSINIT3 (CODE)
                                    678 	.area GSINIT4 (CODE)
                                    679 	.area GSINIT5 (CODE)
                                    680 	.area GSINIT  (CODE)
                                    681 	.area GSFINAL (CODE)
                                    682 	.area CSEG    (CODE)
                                    683 ;--------------------------------------------------------
                                    684 ; global & static initialisations
                                    685 ;--------------------------------------------------------
                                    686 	.area HOME    (CODE)
                                    687 	.area GSINIT  (CODE)
                                    688 	.area GSFINAL (CODE)
                                    689 	.area GSINIT  (CODE)
                                    690 ;--------------------------------------------------------
                                    691 ; Home
                                    692 ;--------------------------------------------------------
                                    693 	.area HOME    (CODE)
                                    694 	.area HOME    (CODE)
                                    695 ;--------------------------------------------------------
                                    696 ; code
                                    697 ;--------------------------------------------------------
                                    698 	.area CSEG    (CODE)
                                    699 ;------------------------------------------------------------
                                    700 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    701 ;------------------------------------------------------------
                                    702 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    703 ;------------------------------------------------------------
                                    704 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    705 ;	-----------------------------------------
                           000007   706 	ar7 = 0x07
                           000006   707 	ar6 = 0x06
                           000005   708 	ar5 = 0x05
                           000004   709 	ar4 = 0x04
                           000003   710 	ar3 = 0x03
                           000002   711 	ar2 = 0x02
                           000001   712 	ar1 = 0x01
                           000000   713 	ar0 = 0x00
                                    714 ;	 function action_exec
                                    715 ;	-----------------------------------------
      0073B0                        716 _action_exec:
                                    717 ;	quantum/action.c:89: ak820_dynamic_macro_task(event.time);
      0073B0 90 08 6F         [24]  718 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      0073B3 12 37 F4         [24]  719 	lcall	_ak820_outline_0005
      0073B6 12 3B 26         [24]  720 	lcall	_ak820_dynamic_macro_task
                                    721 ;	quantum/action.c:92: ak820_combo_tick(event.time);
      0073B9 90 08 6F         [24]  722 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      0073BC 12 37 F4         [24]  723 	lcall	_ak820_outline_0005
      0073BF 12 36 04         [24]  724 	lcall	_ak820_combo_tick
                                    725 ;	quantum/action.c:95: if (!ak820_tapping_before(&event)) return;
      0073C2 90 08 6D         [24]  726 	mov	dptr,#_action_exec_PARM_1
      0073C5 12 47 9B         [24]  727 	lcall	_ak820_tapping_before
      0073C8 E5 82            [12]  728 	mov	a, dpl
      0073CA 70 01            [24]  729 	jnz	00102$
      0073CC 22               [24]  730 	ret
      0073CD                        731 00102$:
                                    732 ;	quantum/action.c:113: if (event.pressed) {
      0073CD 90 08 72         [24]  733 	mov	dptr,#(_action_exec_PARM_1 + 0x0005)
      0073D0 E0               [24]  734 	movx	a,@dptr
      0073D1 60 03            [24]  735 	jz	00104$
                                    736 ;	quantum/action.c:115: clear_weak_mods();
      0073D3 12 85 59         [24]  737 	lcall	_clear_weak_mods
      0073D6                        738 00104$:
                                    739 ;	quantum/action.c:127: record.event = event;
      0073D6 90 0D FD         [24]  740 	mov	dptr,#___memcpy_PARM_2
      0073D9 74 6D            [12]  741 	mov	a,#_action_exec_PARM_1
      0073DB F0               [24]  742 	movx	@dptr,a
      0073DC 74 08            [12]  743 	mov	a,#(_action_exec_PARM_1 >> 8)
      0073DE 12 38 70         [24]  744 	lcall	_ak820_outline_0094
      0073E1 12 7B 62         [24]  745 	lcall	_ak820_outline_0071
      0073E4 90 08 73         [24]  746 	mov	dptr,#_action_exec_record_10001_630
      0073E7 F5 F0            [12]  747 	mov	b,a
      0073E9 12 BC F8         [24]  748 	lcall	___memcpy
                                    749 ;	quantum/action.c:129: record.tap.count = 0;
      0073EC 90 08 79         [24]  750 	mov	dptr,#(_action_exec_record_10001_630 + 0x0006)
      0073EF E0               [24]  751 	movx	a,@dptr
      0073F0 54 0F            [12]  752 	anl	a,#0x0f
      0073F2 F0               [24]  753 	movx	@dptr,a
                                    754 ;	quantum/action.c:134: record.keycode = 0;
      0073F3 90 08 7A         [24]  755 	mov	dptr,#(_action_exec_record_10001_630 + 0x0007)
      0073F6 12 52 B7         [24]  756 	lcall	_ak820_outline_0183
                                    757 ;	quantum/action.c:165: if (IS_NOEVENT(record.event) || pre_process_record_quantum(&record)) {
      0073F9 90 08 77         [24]  758 	mov	dptr,#(_action_exec_record_10001_630 + 0x0004)
      0073FC E0               [24]  759 	movx	a,@dptr
      0073FD 60 0D            [24]  760 	jz	00107$
      0073FF 90 08 73         [24]  761 	mov	dptr,#_action_exec_record_10001_630
      007402 75 F0 00         [24]  762 	mov	b, #0x00
      007405 12 A3 2D         [24]  763 	lcall	_pre_process_record_quantum
      007408 E5 82            [12]  764 	mov	a, dpl
      00740A 60 14            [24]  765 	jz	00110$
      00740C                        766 00107$:
                                    767 ;	quantum/action.c:167: if (!ak820_tapping_process(&record)) return;
      00740C 90 08 73         [24]  768 	mov	dptr,#_action_exec_record_10001_630
      00740F 12 48 7A         [24]  769 	lcall	_ak820_tapping_process
      007412 E5 82            [12]  770 	mov	a, dpl
      007414 70 01            [24]  771 	jnz	00106$
      007416 22               [24]  772 	ret
      007417                        773 00106$:
                                    774 ;	quantum/action.c:172: process_record(&record);
      007417 90 08 73         [24]  775 	mov	dptr,#_action_exec_record_10001_630
      00741A 75 F0 00         [24]  776 	mov	b, #0x00
                                    777 ;	quantum/action.c:182: }
      00741D 02 74 5D         [24]  778 	ljmp	_process_record
      007420                        779 00110$:
      007420 22               [24]  780 	ret
                                    781 ;------------------------------------------------------------
                                    782 ;Allocation info for local variables in function 'ak820_action_exec'
                                    783 ;------------------------------------------------------------
                                    784 ;event         Allocated with name '_ak820_action_exec_event_10000_634'
                                    785 ;snapshot      Allocated with name '_ak820_action_exec_snapshot_10000_635'
                                    786 ;------------------------------------------------------------
                                    787 ;	quantum/action.c:185: void ak820_action_exec(const keyevent_t __xdata *event) {
                                    788 ;	-----------------------------------------
                                    789 ;	 function ak820_action_exec
                                    790 ;	-----------------------------------------
      007421                        791 _ak820_action_exec:
      007421 12 38 82         [24]  792 	lcall	_ak820_outline_0110
      007424 90 08 7C         [24]  793 	mov	dptr,#_ak820_action_exec_event_10000_634
      007427 12 38 87         [24]  794 	lcall	_ak820_outline_0111
                                    795 ;	quantum/action.c:188: keyevent_t snapshot = *event;
      00742A 90 08 7C         [24]  796 	mov	dptr,#_ak820_action_exec_event_10000_634
      00742D 12 38 6A         [24]  797 	lcall	_ak820_outline_0086
      007430 7F 00            [12]  798 	mov	r7,#0x00
      007432 90 0D FD         [24]  799 	mov	dptr,#___memcpy_PARM_2
      007435 ED               [12]  800 	mov	a,r5
      007436 12 38 1F         [24]  801 	lcall	_ak820_outline_0016
      007439 12 7B 62         [24]  802 	lcall	_ak820_outline_0071
      00743C 90 08 7E         [24]  803 	mov	dptr,#_ak820_action_exec_snapshot_10000_635
      00743F F5 F0            [12]  804 	mov	b,a
      007441 12 BC F8         [24]  805 	lcall	___memcpy
                                    806 ;	quantum/action.c:189: action_exec(snapshot);
      007444 90 0D FD         [24]  807 	mov	dptr,#___memcpy_PARM_2
      007447 74 7E            [12]  808 	mov	a,#_ak820_action_exec_snapshot_10000_635
      007449 F0               [24]  809 	movx	@dptr,a
      00744A 74 08            [12]  810 	mov	a,#(_ak820_action_exec_snapshot_10000_635 >> 8)
      00744C 12 38 70         [24]  811 	lcall	_ak820_outline_0094
      00744F 12 7B 62         [24]  812 	lcall	_ak820_outline_0071
      007452 90 08 6D         [24]  813 	mov	dptr,#_action_exec_PARM_1
      007455 F5 F0            [12]  814 	mov	b,a
      007457 12 BC F8         [24]  815 	lcall	___memcpy
                                    816 ;	quantum/action.c:190: }
      00745A 02 73 B0         [24]  817 	ljmp	_action_exec
                                    818 ;------------------------------------------------------------
                                    819 ;Allocation info for local variables in function 'process_record_nocache'
                                    820 ;------------------------------------------------------------
                                    821 ;record        Allocated with name '_process_record_nocache_record_10000_636'
                                    822 ;------------------------------------------------------------
                                    823 ;	quantum/action.c:275: void process_record_nocache(keyrecord_t *record) {
                                    824 ;	-----------------------------------------
                                    825 ;	 function process_record
                                    826 ;	-----------------------------------------
      00745D                        827 _process_record:
      00745D 12 46 62         [24]  828 	lcall	_ak820_outline_0036
      007460 90 08 84         [24]  829 	mov	dptr,#_process_record_record_10000_638
      007463 12 38 1F         [24]  830 	lcall	_ak820_outline_0016
                                    831 ;	quantum/action.c:329: if (IS_NOEVENT(record->event)) {
      007466 90 08 84         [24]  832 	mov	dptr,#_process_record_record_10000_638
      007469 12 52 64         [24]  833 	lcall	_ak820_outline_0013
      00746C 74 04            [12]  834 	mov	a,#0x04
      00746E 12 7B 1E         [24]  835 	lcall	_ak820_outline_0006
      007471 12 BD D1         [24]  836 	lcall	__gptrget
      007474 70 01            [24]  837 	jnz	00102$
                                    838 ;	quantum/action.c:330: return;
      007476 22               [24]  839 	ret
      007477                        840 00102$:
                                    841 ;	quantum/action.c:334: if (record->event.key.row < MATRIX_ROWS && record->event.key.col < MATRIX_COLS && !ak820_macro_primitive &&
      007477 74 01            [12]  842 	mov	a,#0x01
      007479 12 7B 1E         [24]  843 	lcall	_ak820_outline_0006
      00747C 12 BD D1         [24]  844 	lcall	__gptrget
      00747F FA               [12]  845 	mov	r2,a
      007480 BA 10 00         [24]  846 	cjne	r2,#0x10,00192$
      007483                        847 00192$:
      007483 50 49            [24]  848 	jnc	00104$
      007485 8D 02            [24]  849 	mov	ar2,r5
      007487 8E 03            [24]  850 	mov	ar3,r6
      007489 8F 04            [24]  851 	mov	ar4,r7
      00748B 12 38 A6         [24]  852 	lcall	_ak820_outline_0138
      00748E 8C F0            [24]  853 	mov	b,r4
      007490 12 BD D1         [24]  854 	lcall	__gptrget
      007493 FA               [12]  855 	mov	r2,a
      007494 BA 08 00         [24]  856 	cjne	r2,#0x08,00194$
      007497                        857 00194$:
      007497 50 35            [24]  858 	jnc	00104$
      007499 90 09 E3         [24]  859 	mov	dptr,#_ak820_macro_primitive
      00749C E0               [24]  860 	movx	a,@dptr
      00749D 70 2F            [24]  861 	jnz	00104$
                                    862 ;	quantum/action.c:335: !ak820_dynamic_macro_process(get_record_keycode(record, true), record->event.pressed)) return;
      00749F 90 0C 54         [24]  863 	mov	dptr,#_get_record_keycode_PARM_2
      0074A2 74 01            [12]  864 	mov	a,#0x01
      0074A4 12 52 6D         [24]  865 	lcall	_ak820_outline_0031
      0074A7 12 A2 EF         [24]  866 	lcall	_get_record_keycode
      0074AA 12 46 A4         [24]  867 	lcall	_ak820_outline_0127
      0074AD 90 08 84         [24]  868 	mov	dptr,#_process_record_record_10000_638
      0074B0 12 7B 49         [24]  869 	lcall	_ak820_outline_0023
      0074B3 74 05            [12]  870 	mov	a,#0x05
      0074B5 2B               [12]  871 	add	a, r3
      0074B6 FB               [12]  872 	mov	r3,a
      0074B7 E4               [12]  873 	clr	a
      0074B8 3C               [12]  874 	addc	a, r4
      0074B9 FC               [12]  875 	mov	r4,a
      0074BA 12 73 21         [24]  876 	lcall	_ak820_outline_0097
      0074BD 12 BD D1         [24]  877 	lcall	__gptrget
      0074C0 90 04 AE         [24]  878 	mov	dptr,#_ak820_dynamic_macro_process_PARM_2
      0074C3 12 46 86         [24]  879 	lcall	_ak820_outline_0076
      0074C6 12 39 7D         [24]  880 	lcall	_ak820_dynamic_macro_process
      0074C9 E5 82            [12]  881 	mov	a, dpl
      0074CB 70 01            [24]  882 	jnz	00104$
      0074CD 22               [24]  883 	ret
      0074CE                        884 00104$:
                                    885 ;	quantum/action.c:338: uint8_t oneshot_source = ak820_tapping_source(record->event.key);
      0074CE 90 08 84         [24]  886 	mov	dptr,#_process_record_record_10000_638
      0074D1 12 52 64         [24]  887 	lcall	_ak820_outline_0013
      0074D4 8D 02            [24]  888 	mov	ar2,r5
      0074D6 8E 03            [24]  889 	mov	ar3,r6
      0074D8 8F 04            [24]  890 	mov	ar4,r7
      0074DA 90 0D FD         [24]  891 	mov	dptr,#___memcpy_PARM_2
      0074DD EA               [12]  892 	mov	a,r2
      0074DE 12 7B AD         [24]  893 	lcall	_ak820_outline_0188
      0074E1 EC               [12]  894 	mov	a,r4
      0074E2 A3               [24]  895 	inc	dptr
      0074E3 F0               [24]  896 	movx	@dptr,a
      0074E4 90 0E 00         [24]  897 	mov	dptr,#___memcpy_PARM_3
      0074E7 12 52 A9         [24]  898 	lcall	_ak820_outline_0113
      0074EA 90 06 7A         [24]  899 	mov	dptr,#_ak820_tapping_source_PARM_1
      0074ED F5 F0            [12]  900 	mov	b,a
      0074EF C0 07            [24]  901 	push	ar7
      0074F1 C0 06            [24]  902 	push	ar6
      0074F3 C0 05            [24]  903 	push	ar5
      0074F5 12 BC F8         [24]  904 	lcall	___memcpy
      0074F8 12 46 D5         [24]  905 	lcall	_ak820_tapping_source
      0074FB AC 82            [24]  906 	mov	r4, dpl
      0074FD D0 05            [24]  907 	pop	ar5
      0074FF D0 06            [24]  908 	pop	ar6
      007501 D0 07            [24]  909 	pop	ar7
                                    910 ;	quantum/action.c:339: bool oneshot_pressed = record->event.pressed;
      007503 74 05            [12]  911 	mov	a,#0x05
      007505 12 7B 2C         [24]  912 	lcall	_ak820_outline_0014
      007508 12 BD D1         [24]  913 	lcall	__gptrget
      00750B FB               [12]  914 	mov	r3,a
                                    915 ;	quantum/action.c:340: record->keycode = get_record_keycode(record, true);
      00750C 74 07            [12]  916 	mov	a,#0x07
      00750E 2D               [12]  917 	add	a, r5
      00750F F8               [12]  918 	mov	r0,a
      007510 E4               [12]  919 	clr	a
      007511 3E               [12]  920 	addc	a, r6
      007512 F9               [12]  921 	mov	r1,a
      007513 8F 02            [24]  922 	mov	ar2,r7
      007515 90 0C 54         [24]  923 	mov	dptr,#_get_record_keycode_PARM_2
      007518 74 01            [12]  924 	mov	a,#0x01
      00751A 12 52 6D         [24]  925 	lcall	_ak820_outline_0031
      00751D C0 04            [24]  926 	push	ar4
      00751F C0 03            [24]  927 	push	ar3
      007521 C0 02            [24]  928 	push	ar2
      007523 C0 01            [24]  929 	push	ar1
      007525 C0 00            [24]  930 	push	ar0
      007527 12 A2 EF         [24]  931 	lcall	_get_record_keycode
      00752A 12 46 A4         [24]  932 	lcall	_ak820_outline_0127
      00752D D0 00            [24]  933 	pop	ar0
      00752F D0 01            [24]  934 	pop	ar1
      007531 D0 02            [24]  935 	pop	ar2
      007533 D0 03            [24]  936 	pop	ar3
      007535 D0 04            [24]  937 	pop	ar4
      007537 12 38 B1         [24]  938 	lcall	_ak820_outline_0146
      00753A 8A F0            [24]  939 	mov	b,r2
      00753C EE               [12]  940 	mov	a,r6
      00753D 12 BD 96         [24]  941 	lcall	__gptrput
      007540 A3               [24]  942 	inc	dptr
      007541 EF               [12]  943 	mov	a,r7
      007542 12 BD 96         [24]  944 	lcall	__gptrput
                                    945 ;	quantum/action.c:341: if (!ak820_oneshot_process(record->keycode, oneshot_source, oneshot_pressed)) return;
      007545 90 08 84         [24]  946 	mov	dptr,#_process_record_record_10000_638
      007548 12 52 64         [24]  947 	lcall	_ak820_outline_0013
      00754B 74 07            [12]  948 	mov	a,#0x07
      00754D 12 7B 73         [24]  949 	lcall	_ak820_outline_0080
      007550 12 BD D1         [24]  950 	lcall	__gptrget
      007553 F8               [12]  951 	mov	r0,a
      007554 A3               [24]  952 	inc	dptr
      007555 12 BD D1         [24]  953 	lcall	__gptrget
      007558 F9               [12]  954 	mov	r1,a
      007559 90 06 8A         [24]  955 	mov	dptr,#_ak820_oneshot_process_PARM_2
      00755C EC               [12]  956 	mov	a,r4
      00755D F0               [24]  957 	movx	@dptr,a
      00755E 90 06 8B         [24]  958 	mov	dptr,#_ak820_oneshot_process_PARM_3
      007561 EB               [12]  959 	mov	a,r3
      007562 F0               [24]  960 	movx	@dptr,a
      007563 12 38 B1         [24]  961 	lcall	_ak820_outline_0146
      007566 C0 07            [24]  962 	push	ar7
      007568 C0 06            [24]  963 	push	ar6
      00756A C0 05            [24]  964 	push	ar5
      00756C C0 04            [24]  965 	push	ar4
      00756E C0 03            [24]  966 	push	ar3
      007570 12 4A 35         [24]  967 	lcall	_ak820_oneshot_process
      007573 E5 82            [12]  968 	mov	a, dpl
      007575 D0 03            [24]  969 	pop	ar3
      007577 D0 04            [24]  970 	pop	ar4
      007579 D0 05            [24]  971 	pop	ar5
      00757B D0 06            [24]  972 	pop	ar6
      00757D D0 07            [24]  973 	pop	ar7
      00757F 70 01            [24]  974 	jnz	00109$
      007581 22               [24]  975 	ret
      007582                        976 00109$:
                                    977 ;	quantum/action.c:343: if (!process_record_quantum(record)) {
      007582 12 70 F6         [24]  978 	lcall	_ak820_outline_0050
      007585 C0 04            [24]  979 	push	ar4
      007587 C0 03            [24]  980 	push	ar3
      007589 12 A3 B4         [24]  981 	lcall	_process_record_quantum
      00758C E5 82            [12]  982 	mov	a, dpl
      00758E D0 03            [24]  983 	pop	ar3
      007590 D0 04            [24]  984 	pop	ar4
      007592 70 0A            [24]  985 	jnz	00111$
                                    986 ;	quantum/action.c:345: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      007594 90 05 F2         [24]  987 	mov	dptr,#_ak820_oneshot_post_PARM_2
      007597 EB               [12]  988 	mov	a,r3
      007598 F0               [24]  989 	movx	@dptr,a
      007599 8C 82            [24]  990 	mov	dpl, r4
                                    991 ;	quantum/action.c:352: return;
      00759B 02 2E BB         [24]  992 	ljmp	_ak820_oneshot_post
      00759E                        993 00111$:
                                    994 ;	quantum/action.c:356: ak820_dynamic_macro_source = record->event.key.row < MATRIX_ROWS && record->event.key.col < MATRIX_COLS && !get_repeat_key_count() && !ak820_macro_primitive;
      00759E 90 08 84         [24]  995 	mov	dptr,#_process_record_record_10000_638
      0075A1 12 52 64         [24]  996 	lcall	_ak820_outline_0013
      0075A4 74 01            [12]  997 	mov	a,#0x01
      0075A6 12 7B 73         [24]  998 	lcall	_ak820_outline_0080
      0075A9 12 BD D1         [24]  999 	lcall	__gptrget
      0075AC F8               [12] 1000 	mov	r0,a
      0075AD B8 10 00         [24] 1001 	cjne	r0,#0x10,00200$
      0075B0                       1002 00200$:
      0075B0 50 21            [24] 1003 	jnc	00114$
      0075B2 12 70 F6         [24] 1004 	lcall	_ak820_outline_0050
      0075B5 12 BD D1         [24] 1005 	lcall	__gptrget
      0075B8 FD               [12] 1006 	mov	r5,a
      0075B9 BD 08 00         [24] 1007 	cjne	r5,#0x08,00202$
      0075BC                       1008 00202$:
      0075BC 50 15            [24] 1009 	jnc	00114$
      0075BE C0 04            [24] 1010 	push	ar4
      0075C0 C0 03            [24] 1011 	push	ar3
      0075C2 12 A6 DC         [24] 1012 	lcall	_get_repeat_key_count
      0075C5 E5 82            [12] 1013 	mov	a, dpl
      0075C7 D0 03            [24] 1014 	pop	ar3
      0075C9 D0 04            [24] 1015 	pop	ar4
      0075CB 70 06            [24] 1016 	jnz	00114$
      0075CD 90 09 E3         [24] 1017 	mov	dptr,#_ak820_macro_primitive
      0075D0 E0               [24] 1018 	movx	a,@dptr
      0075D1 60 05            [24] 1019 	jz	00115$
      0075D3                       1020 00114$:
      0075D3 75 27 00         [24] 1021 	mov	_process_record_sloc0_1_0,#0x00
      0075D6 80 03            [24] 1022 	sjmp	00116$
      0075D8                       1023 00115$:
      0075D8 75 27 01         [24] 1024 	mov	_process_record_sloc0_1_0,#0x01
      0075DB                       1025 00116$:
      0075DB 90 04 AD         [24] 1026 	mov	dptr,#_ak820_dynamic_macro_source
      0075DE E5 27            [12] 1027 	mov	a,_process_record_sloc0_1_0
      0075E0 F0               [24] 1028 	movx	@dptr,a
                                   1029 ;	quantum/action.c:358: process_record_handler(record);
      0075E1 90 08 84         [24] 1030 	mov	dptr,#_process_record_record_10000_638
      0075E4 12 52 3E         [24] 1031 	lcall	_ak820_outline_0001
      0075E7 C0 04            [24] 1032 	push	ar4
      0075E9 C0 03            [24] 1033 	push	ar3
      0075EB 12 76 0A         [24] 1034 	lcall	_process_record_handler
                                   1035 ;	quantum/action.c:360: ak820_dynamic_macro_source = false;
      0075EE 90 04 AD         [24] 1036 	mov	dptr,#_ak820_dynamic_macro_source
      0075F1 E4               [12] 1037 	clr	a
      0075F2 F0               [24] 1038 	movx	@dptr,a
                                   1039 ;	quantum/action.c:362: post_process_record_quantum(record);
      0075F3 90 08 84         [24] 1040 	mov	dptr,#_process_record_record_10000_638
      0075F6 12 52 3E         [24] 1041 	lcall	_ak820_outline_0001
      0075F9 12 A3 89         [24] 1042 	lcall	_post_process_record_quantum
      0075FC D0 03            [24] 1043 	pop	ar3
      0075FE D0 04            [24] 1044 	pop	ar4
                                   1045 ;	quantum/action.c:364: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      007600 90 05 F2         [24] 1046 	mov	dptr,#_ak820_oneshot_post_PARM_2
      007603 EB               [12] 1047 	mov	a,r3
      007604 F0               [24] 1048 	movx	@dptr,a
      007605 8C 82            [24] 1049 	mov	dpl, r4
                                   1050 ;	quantum/action.c:366: }
      007607 02 2E BB         [24] 1051 	ljmp	_ak820_oneshot_post
                                   1052 ;------------------------------------------------------------
                                   1053 ;Allocation info for local variables in function 'process_record_handler'
                                   1054 ;------------------------------------------------------------
                                   1055 ;record_argument Allocated with name '_process_record_handler_record_argument_10000_647'
                                   1056 ;record        Allocated with name '_process_record_handler_record_10000_648'
                                   1057 ;action        Allocated with name '_process_record_handler_action_10000_648'
                                   1058 ;------------------------------------------------------------
                                   1059 ;	quantum/action.c:368: void process_record_handler(keyrecord_t *record_argument) {
                                   1060 ;	-----------------------------------------
                                   1061 ;	 function process_record_handler
                                   1062 ;	-----------------------------------------
      00760A                       1063 _process_record_handler:
      00760A 12 46 62         [24] 1064 	lcall	_ak820_outline_0036
      00760D 90 08 87         [24] 1065 	mov	dptr,#_process_record_handler_record_argument_10000_647
      007610 12 38 1F         [24] 1066 	lcall	_ak820_outline_0016
                                   1067 ;	quantum/action.c:372: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      007613 90 08 87         [24] 1068 	mov	dptr,#_process_record_handler_record_argument_10000_647
      007616 12 37 FE         [24] 1069 	lcall	_ak820_outline_0008
                                   1070 ;	quantum/action.c:379: if (record->keycode) {
      007619 4C               [12] 1071 	orl	a,r4
      00761A 60 19            [24] 1072 	jz	00102$
                                   1073 ;	quantum/action.c:380: action.code = action_for_keycode(record->keycode);
      00761C 12 38 97         [24] 1074 	lcall	_ak820_outline_0126
      00761F C0 07            [24] 1075 	push	ar7
      007621 C0 06            [24] 1076 	push	ar6
      007623 12 99 36         [24] 1077 	lcall	_action_for_keycode
      007626 12 46 B5         [24] 1078 	lcall	_ak820_outline_0151
      007629 D0 06            [24] 1079 	pop	ar6
      00762B D0 07            [24] 1080 	pop	ar7
      00762D 90 08 8A         [24] 1081 	mov	dptr,#_process_record_handler_action_10000_648
      007630 12 38 5E         [24] 1082 	lcall	_ak820_outline_0072
      007633 80 2B            [24] 1083 	sjmp	00104$
      007635                       1084 00102$:
                                   1085 ;	quantum/action.c:383: action.code = action_for_keycode(ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed));
      007635 12 7B 3A         [24] 1086 	lcall	_ak820_outline_0020
      007638 7A 00            [12] 1087 	mov	r2,#0x00
      00763A 12 46 AF         [24] 1088 	lcall	_ak820_outline_0145
      00763D 12 46 50         [24] 1089 	lcall	_ak820_outline_0012
      007640 E0               [24] 1090 	movx	a,@dptr
      007641 90 09 C6         [24] 1091 	mov	dptr,#_ak820_resolve_key_PARM_2
      007644 F0               [24] 1092 	movx	@dptr,a
      007645 8D 82            [24] 1093 	mov	dpl, r5
      007647 8C 83            [24] 1094 	mov	dph, r4
      007649 C0 07            [24] 1095 	push	ar7
      00764B C0 06            [24] 1096 	push	ar6
      00764D 12 7E F3         [24] 1097 	lcall	_ak820_resolve_key
      007650 12 99 36         [24] 1098 	lcall	_action_for_keycode
      007653 12 46 B5         [24] 1099 	lcall	_ak820_outline_0151
      007656 D0 06            [24] 1100 	pop	ar6
      007658 D0 07            [24] 1101 	pop	ar7
      00765A 90 08 8A         [24] 1102 	mov	dptr,#_process_record_handler_action_10000_648
      00765D 12 38 5E         [24] 1103 	lcall	_ak820_outline_0072
                                   1104 ;	quantum/action.c:392: ac_dprintf("ACTION: ");
      007660                       1105 00104$:
                                   1106 ;	quantum/action.c:403: process_action(record, action);
      007660 7D 00            [12] 1107 	mov	r5,#0x00
      007662 90 0D FD         [24] 1108 	mov	dptr,#___memcpy_PARM_2
      007665 74 8A            [12] 1109 	mov	a,#_process_record_handler_action_10000_648
      007667 F0               [24] 1110 	movx	@dptr,a
      007668 74 08            [12] 1111 	mov	a,#(_process_record_handler_action_10000_648 >> 8)
      00766A 12 38 70         [24] 1112 	lcall	_ak820_outline_0094
      00766D 90 0E 00         [24] 1113 	mov	dptr,#___memcpy_PARM_3
      007670 12 52 A9         [24] 1114 	lcall	_ak820_outline_0113
      007673 90 08 8C         [24] 1115 	mov	dptr,#_process_action_PARM_2
      007676 F5 F0            [12] 1116 	mov	b,a
      007678 C0 07            [24] 1117 	push	ar7
      00767A C0 06            [24] 1118 	push	ar6
      00767C C0 05            [24] 1119 	push	ar5
      00767E 12 BC F8         [24] 1120 	lcall	___memcpy
      007681 D0 05            [24] 1121 	pop	ar5
      007683 D0 06            [24] 1122 	pop	ar6
      007685 D0 07            [24] 1123 	pop	ar7
      007687 12 73 1A         [24] 1124 	lcall	_ak820_outline_0051
                                   1125 ;	quantum/action.c:404: }
      00768A 02 76 8D         [24] 1126 	ljmp	_process_action
                                   1127 ;------------------------------------------------------------
                                   1128 ;Allocation info for local variables in function 'register_mouse'
                                   1129 ;------------------------------------------------------------
                                   1130 ;pressed       Allocated with name '_register_mouse_PARM_2'
                                   1131 ;mouse_keycode Allocated with name '_register_mouse_mouse_keycode_10000_656'
                                   1132 ;------------------------------------------------------------
                                   1133 ;	quantum/action.c:416: void register_mouse(uint8_t mouse_keycode, bool pressed) {
                                   1134 ;	-----------------------------------------
                                   1135 ;	 function process_action
                                   1136 ;	-----------------------------------------
      00768D                       1137 _process_action:
      00768D 12 46 62         [24] 1138 	lcall	_ak820_outline_0036
      007690 90 08 8E         [24] 1139 	mov	dptr,#_process_action_record_argument_10000_659
      007693 12 38 1F         [24] 1140 	lcall	_ak820_outline_0016
                                   1141 ;	quantum/action.c:469: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      007696 90 08 8E         [24] 1142 	mov	dptr,#_process_action_record_argument_10000_659
      007699 12 37 F4         [24] 1143 	lcall	_ak820_outline_0005
                                   1144 ;	quantum/action.c:475: pressed = record->event.pressed;
      00769C A3               [24] 1145 	inc	dptr
      00769D A3               [24] 1146 	inc	dptr
      00769E A3               [24] 1147 	inc	dptr
      00769F A3               [24] 1148 	inc	dptr
      0076A0 A3               [24] 1149 	inc	dptr
      0076A1 E0               [24] 1150 	movx	a,@dptr
      0076A2 F5 28            [12] 1151 	mov	_process_action_sloc0_1_0,a
                                   1152 ;	quantum/action.c:499: switch (action.kind.id) {
      0076A4 90 08 8D         [24] 1153 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0076A7 E0               [24] 1154 	movx	a,@dptr
      0076A8 C4               [12] 1155 	swap	a
      0076A9 54 0F            [12] 1156 	anl	a,#0x0f
      0076AB FD               [12] 1157 	mov  r5,a
      0076AC 24 F4            [12] 1158 	add	a,#0xff - 0x0b
      0076AE 50 03            [24] 1159 	jnc	00434$
      0076B0 02 79 2E         [24] 1160 	ljmp	00181$
      0076B3                       1161 00434$:
                                   1162 ;	free result
      0076B3 ED               [12] 1163 	mov	a,r5
      0076B4 24 0A            [12] 1164 	add	a,#(00435$-3-.)
      0076B6 83               [24] 1165 	movc	a,@a+pc
      0076B7 F5 82            [12] 1166 	mov	dpl,a
      0076B9 ED               [12] 1167 	mov	a,r5
      0076BA 24 10            [12] 1168 	add	a,#(00436$-3-.)
      0076BC 83               [24] 1169 	movc	a,@a+pc
      0076BD F5 83            [12] 1170 	mov	dph,a
      0076BF E4               [12] 1171 	clr	a
      0076C0 73               [24] 1172 	jmp	@a+dptr
      0076C1                       1173 00435$:
      0076C1 D9                    1174 	.db	00102$
      0076C2 D9                    1175 	.db	00102$
      0076C3 2E                    1176 	.db	00181$
      0076C4 2E                    1177 	.db	00181$
      0076C5 63                    1178 	.db	00123$
      0076C6 2E                    1179 	.db	00181$
      0076C7 2E                    1180 	.db	00181$
      0076C8 2E                    1181 	.db	00181$
      0076C9 C3                    1182 	.db	00131$
      0076CA 95                    1183 	.db	00147$
      0076CB BB                    1184 	.db	00152$
      0076CC BB                    1185 	.db	00152$
      0076CD                       1186 00436$:
      0076CD 76                    1187 	.db	00102$>>8
      0076CE 76                    1188 	.db	00102$>>8
      0076CF 79                    1189 	.db	00181$>>8
      0076D0 79                    1190 	.db	00181$>>8
      0076D1 77                    1191 	.db	00123$>>8
      0076D2 79                    1192 	.db	00181$>>8
      0076D3 79                    1193 	.db	00181$>>8
      0076D4 79                    1194 	.db	00181$>>8
      0076D5 77                    1195 	.db	00131$>>8
      0076D6 78                    1196 	.db	00147$>>8
      0076D7 78                    1197 	.db	00152$>>8
      0076D8 78                    1198 	.db	00152$>>8
                                   1199 ;	quantum/action.c:502: case ACT_RMODS: {
      0076D9                       1200 00102$:
                                   1201 ;	quantum/action.c:503: mods = (action.kind.id == ACT_LMODS) ? action.key.mods : action.key.mods << 4;
      0076D9 90 08 8D         [24] 1202 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0076DC E0               [24] 1203 	movx	a,@dptr
      0076DD 54 F0            [12] 1204 	anl	a,#0xf0
      0076DF 70 06            [24] 1205 	jnz	00194$
      0076E1 12 7B 8A         [24] 1206 	lcall	_ak820_outline_0115
      0076E4 FD               [12] 1207 	mov	r5,a
      0076E5 80 07            [24] 1208 	sjmp	00195$
      0076E7                       1209 00194$:
      0076E7 12 7B 8A         [24] 1210 	lcall	_ak820_outline_0115
      0076EA C4               [12] 1211 	swap	a
      0076EB 54 F0            [12] 1212 	anl	a,#0xf0
      0076ED FD               [12] 1213 	mov	r5,a
      0076EE                       1214 00195$:
                                   1215 ;	quantum/action.c:505: if (pressed) {
      0076EE E5 28            [12] 1216 	mov	a,_process_action_sloc0_1_0
      0076F0 60 35            [24] 1217 	jz	00119$
                                   1218 ;	quantum/action.c:506: if (mods) {
      0076F2 ED               [12] 1219 	mov	a,r5
      0076F3 60 29            [24] 1220 	jz	00110$
                                   1221 ;	quantum/action.c:507: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      0076F5 12 7B 9C         [24] 1222 	lcall	_ak820_outline_0161
      0076F8 FC               [12] 1223 	mov	r4,a
      0076F9 BC E0 00         [24] 1224 	cjne	r4,#0xe0,00440$
      0076FC                       1225 00440$:
      0076FC 40 07            [24] 1226 	jc	00108$
      0076FE 12 7B 9C         [24] 1227 	lcall	_ak820_outline_0161
      007701 24 18            [12] 1228 	add	a,#0xff - 0xe7
      007703 50 0A            [24] 1229 	jnc	00104$
                                   1230 ;	free result
      007705                       1231 00108$:
      007705 7B 8C            [12] 1232 	mov	r3,#_process_action_PARM_2
      007707 7C 08            [12] 1233 	mov	r4,#(_process_action_PARM_2 >> 8)
      007709 12 33 FC         [24] 1234 	lcall	_ak820_outline_0125
      00770C E0               [24] 1235 	movx	a,@dptr
      00770D 70 07            [24] 1236 	jnz	00105$
      00770F                       1237 00104$:
                                   1238 ;	quantum/action.c:511: add_owned_mods(mods);
      00770F 8D 82            [24] 1239 	mov	dpl, r5
      007711 12 81 5D         [24] 1240 	lcall	_add_owned_mods
      007714 80 05            [24] 1241 	sjmp	00106$
      007716                       1242 00105$:
                                   1243 ;	quantum/action.c:513: add_owned_weak_mods(mods);
      007716 8D 82            [24] 1244 	mov	dpl, r5
      007718 12 81 7B         [24] 1245 	lcall	_add_owned_weak_mods
      00771B                       1246 00106$:
                                   1247 ;	quantum/action.c:515: send_keyboard_report();
      00771B 12 84 A0         [24] 1248 	lcall	_send_keyboard_report
      00771E                       1249 00110$:
                                   1250 ;	quantum/action.c:517: register_code(action.key.code);
      00771E 12 7B 6C         [24] 1251 	lcall	_ak820_outline_0078
      007721 12 79 45         [24] 1252 	lcall	_register_code
      007724 02 79 2E         [24] 1253 	ljmp	00181$
      007727                       1254 00119$:
                                   1255 ;	quantum/action.c:519: unregister_code(action.key.code);
      007727 12 7B 6C         [24] 1256 	lcall	_ak820_outline_0078
      00772A C0 05            [24] 1257 	push	ar5
      00772C 12 79 C1         [24] 1258 	lcall	_unregister_code
      00772F D0 05            [24] 1259 	pop	ar5
                                   1260 ;	quantum/action.c:520: if (mods) {
      007731 ED               [12] 1261 	mov	a,r5
      007732 70 03            [24] 1262 	jnz	00444$
      007734 02 79 2E         [24] 1263 	ljmp	00181$
      007737                       1264 00444$:
                                   1265 ;	quantum/action.c:521: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      007737 12 7B 9C         [24] 1266 	lcall	_ak820_outline_0161
      00773A FC               [12] 1267 	mov	r4,a
      00773B BC E0 00         [24] 1268 	cjne	r4,#0xe0,00445$
      00773E                       1269 00445$:
      00773E 40 07            [24] 1270 	jc	00115$
      007740 12 7B 9C         [24] 1271 	lcall	_ak820_outline_0161
      007743 24 18            [12] 1272 	add	a,#0xff - 0xe7
      007745 50 0A            [24] 1273 	jnc	00111$
                                   1274 ;	free result
      007747                       1275 00115$:
      007747 7B 8C            [12] 1276 	mov	r3,#_process_action_PARM_2
      007749 7C 08            [12] 1277 	mov	r4,#(_process_action_PARM_2 >> 8)
      00774B 12 33 FC         [24] 1278 	lcall	_ak820_outline_0125
      00774E E0               [24] 1279 	movx	a,@dptr
      00774F 70 07            [24] 1280 	jnz	00112$
      007751                       1281 00111$:
                                   1282 ;	quantum/action.c:522: del_owned_mods(mods);
      007751 8D 82            [24] 1283 	mov	dpl, r5
      007753 12 81 6D         [24] 1284 	lcall	_del_owned_mods
      007756 80 05            [24] 1285 	sjmp	00113$
      007758                       1286 00112$:
                                   1287 ;	quantum/action.c:524: del_owned_weak_mods(mods);
      007758 8D 82            [24] 1288 	mov	dpl, r5
      00775A 12 81 8B         [24] 1289 	lcall	_del_owned_weak_mods
      00775D                       1290 00113$:
                                   1291 ;	quantum/action.c:526: send_keyboard_report();
      00775D 12 84 A0         [24] 1292 	lcall	_send_keyboard_report
                                   1293 ;	quantum/action.c:529: } break;
      007760 02 79 2E         [24] 1294 	ljmp	00181$
                                   1295 ;	quantum/action.c:606: case ACT_USAGE:
      007763                       1296 00123$:
                                   1297 ;	quantum/action.c:612: if (record->keycode >= KC_SYSTEM_POWER && record->keycode <= KC_LAUNCHPAD) {
      007763 74 07            [12] 1298 	mov	a,#0x07
      007765 12 38 31         [24] 1299 	lcall	_ak820_outline_0021
      007768 12 4B 86         [24] 1300 	lcall	_ak820_outline_0009
      00776B C3               [12] 1301 	clr	c
      00776C EC               [12] 1302 	mov	a,r4
      00776D 94 A5            [12] 1303 	subb	a,#0xa5
      00776F ED               [12] 1304 	mov	a,r5
      007770 94 00            [12] 1305 	subb	a,#0x00
      007772 40 15            [24] 1306 	jc	00125$
      007774 74 C2            [12] 1307 	mov	a,#0xc2
      007776 9C               [12] 1308 	subb	a,r4
      007777 E4               [12] 1309 	clr	a
      007778 9D               [12] 1310 	subb	a,r5
      007779 40 0E            [24] 1311 	jc	00125$
                                   1312 ;	free result
                                   1313 ;	quantum/action.c:613: owned_usage_key((uint8_t)record->keycode, pressed);
      00777B 90 0A F0         [24] 1314 	mov	dptr,#_owned_usage_key_PARM_2
      00777E E5 28            [12] 1315 	mov	a,_process_action_sloc0_1_0
      007780 F0               [24] 1316 	movx	@dptr,a
      007781 8E 82            [24] 1317 	mov	dpl, r6
      007783 12 83 4B         [24] 1318 	lcall	_owned_usage_key
                                   1319 ;	quantum/action.c:614: break;
      007786 02 79 2E         [24] 1320 	ljmp	00181$
      007789                       1321 00125$:
                                   1322 ;	quantum/action.c:617: switch (action.usage.page) {
      007789 12 7B 81         [24] 1323 	lcall	_ak820_outline_0090
      00778C FF               [12] 1324 	mov	r7,a
      00778D 60 08            [24] 1325 	jz	00127$
      00778F BF 01 02         [24] 1326 	cjne	r7,#0x01,00452$
      007792 80 19            [24] 1327 	sjmp	00128$
      007794                       1328 00452$:
      007794 02 79 2E         [24] 1329 	ljmp	00181$
                                   1330 ;	quantum/action.c:618: case PAGE_SYSTEM:
      007797                       1331 00127$:
                                   1332 ;	quantum/action.c:619: host_system_send(pressed ? action.usage.code : 0);
      007797 E5 28            [12] 1333 	mov	a,_process_action_sloc0_1_0
      007799 60 05            [24] 1334 	jz	00196$
      00779B 12 7B 91         [24] 1335 	lcall	_ak820_outline_0133
      00779E 80 04            [24] 1336 	sjmp	00197$
      0077A0                       1337 00196$:
      0077A0 7E 00            [12] 1338 	mov	r6,#0x00
      0077A2 7F 00            [12] 1339 	mov	r7,#0x00
      0077A4                       1340 00197$:
      0077A4 12 38 8C         [24] 1341 	lcall	_ak820_outline_0120
      0077A7 12 70 80         [24] 1342 	lcall	_host_system_send
                                   1343 ;	quantum/action.c:620: break;
      0077AA 02 79 2E         [24] 1344 	ljmp	00181$
                                   1345 ;	quantum/action.c:621: case PAGE_CONSUMER:
      0077AD                       1346 00128$:
                                   1347 ;	quantum/action.c:622: host_consumer_send(pressed ? action.usage.code : 0);
      0077AD E5 28            [12] 1348 	mov	a,_process_action_sloc0_1_0
      0077AF 60 05            [24] 1349 	jz	00198$
      0077B1 12 7B 91         [24] 1350 	lcall	_ak820_outline_0133
      0077B4 80 04            [24] 1351 	sjmp	00199$
      0077B6                       1352 00198$:
      0077B6 7E 00            [12] 1353 	mov	r6,#0x00
      0077B8 7F 00            [12] 1354 	mov	r7,#0x00
      0077BA                       1355 00199$:
      0077BA 12 38 8C         [24] 1356 	lcall	_ak820_outline_0120
      0077BD 12 70 B0         [24] 1357 	lcall	_host_consumer_send
                                   1358 ;	quantum/action.c:625: break;
      0077C0 02 79 2E         [24] 1359 	ljmp	00181$
                                   1360 ;	quantum/action.c:632: case ACT_LAYER: {
      0077C3                       1361 00131$:
                                   1362 ;	quantum/action.c:633: uint8_t on = action.layer_bitop.on;
      0077C3 90 08 8D         [24] 1363 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0077C6 E0               [24] 1364 	movx	a,@dptr
      0077C7 54 03            [12] 1365 	anl	a,#0x03
      0077C9 90 08 91         [24] 1366 	mov	dptr,#_process_action_on_40000_682
      0077CC F0               [24] 1367 	movx	@dptr,a
                                   1368 ;	quantum/action.c:636: if (on ? (pressed ? (on & ON_PRESS) : (on & ON_RELEASE)) : !pressed) {
      0077CD E0               [24] 1369 	movx	a,@dptr
      0077CE FF               [12] 1370 	mov	r7,a
      0077CF 60 11            [24] 1371 	jz	00200$
      0077D1 E5 28            [12] 1372 	mov	a,_process_action_sloc0_1_0
      0077D3 60 07            [24] 1373 	jz	00202$
      0077D5 8F 06            [24] 1374 	mov	ar6,r7
      0077D7 53 06 01         [24] 1375 	anl	ar6,#0x01
      0077DA 80 10            [24] 1376 	sjmp	00201$
      0077DC                       1377 00202$:
      0077DC 74 02            [12] 1378 	mov	a,#0x02
      0077DE 5F               [12] 1379 	anl	a,r7
      0077DF FE               [12] 1380 	mov	r6,a
      0077E0 80 0A            [24] 1381 	sjmp	00201$
      0077E2                       1382 00200$:
      0077E2 E5 28            [12] 1383 	mov	a,_process_action_sloc0_1_0
      0077E4 B4 01 00         [24] 1384 	cjne	a,#0x01,00457$
      0077E7                       1385 00457$:
      0077E7 92 21            [24] 1386 	mov  _process_action_sloc1_1_0,c
      0077E9 E4               [12] 1387 	clr	a
      0077EA 33               [12] 1388 	rlc	a
      0077EB FE               [12] 1389 	mov	r6,a
      0077EC                       1390 00201$:
      0077EC EE               [12] 1391 	mov	a,r6
      0077ED 70 03            [24] 1392 	jnz	00458$
      0077EF 02 79 2E         [24] 1393 	ljmp	00181$
      0077F2                       1394 00458$:
                                   1395 ;	quantum/action.c:637: uint8_t shift = action.layer_bitop.part * 4;
      0077F2 12 7B 9C         [24] 1396 	lcall	_ak820_outline_0161
      0077F5 C4               [12] 1397 	swap	a
      0077F6 03               [12] 1398 	rr	a
      0077F7 54 07            [12] 1399 	anl	a,#0x07
      0077F9 25 E0            [12] 1400 	add	a,acc
      0077FB 25 E0            [12] 1401 	add	a,acc
      0077FD FF               [12] 1402 	mov	r7,a
                                   1403 ;	quantum/action.c:638: layer_state_t bits = ((layer_state_t)action.layer_bitop.bits) << shift;
      0077FE 12 7B 9C         [24] 1404 	lcall	_ak820_outline_0161
      007801 54 0F            [12] 1405 	anl	a,#0x0f
      007803 FE               [12] 1406 	mov	r6,a
      007804 8F F0            [24] 1407 	mov	b,r7
      007806 05 F0            [12] 1408 	inc	b
      007808 EE               [12] 1409 	mov	a,r6
      007809 80 02            [24] 1410 	sjmp	00460$
      00780B                       1411 00459$:
      00780B 25 E0            [12] 1412 	add	a,acc
      00780D                       1413 00460$:
      00780D D5 F0 FB         [24] 1414 	djnz	b,00459$
      007810 FE               [12] 1415 	mov	r6,a
                                   1416 ;	quantum/action.c:639: layer_state_t mask = action.layer_bitop.xbit ? ~(((layer_state_t)0xf) << shift) : 0;
      007811 12 7B 9C         [24] 1417 	lcall	_ak820_outline_0161
      007814 30 E4 11         [24] 1418 	jnb	acc.4,00204$
      007817 8F F0            [24] 1419 	mov	b,r7
      007819 05 F0            [12] 1420 	inc	b
      00781B 74 0F            [12] 1421 	mov	a,#0x0f
      00781D 80 02            [24] 1422 	sjmp	00463$
      00781F                       1423 00462$:
      00781F 25 E0            [12] 1424 	add	a,acc
      007821                       1425 00463$:
      007821 D5 F0 FB         [24] 1426 	djnz	b,00462$
      007824 F4               [12] 1427 	cpl	a
      007825 FF               [12] 1428 	mov	r7,a
      007826 80 02            [24] 1429 	sjmp	00205$
      007828                       1430 00204$:
      007828 7F 00            [12] 1431 	mov	r7,#0x00
      00782A                       1432 00205$:
                                   1433 ;	quantum/action.c:640: bits |= mask;
      00782A EE               [12] 1434 	mov	a,r6
      00782B 42 07            [12] 1435 	orl	ar7,a
                                   1436 ;	quantum/action.c:641: if (!on) {
      00782D 90 08 91         [24] 1437 	mov	dptr,#_process_action_on_40000_682
      007830 E0               [24] 1438 	movx	a,@dptr
      007831 70 31            [24] 1439 	jnz	00143$
                                   1440 ;	quantum/action.c:642: switch (action.layer_bitop.op) {
      007833 12 7B 81         [24] 1441 	lcall	_ak820_outline_0090
      007836 FE               [12] 1442 	mov	r6,a
      007837 2E               [12] 1443 	add	a,r6
                                   1444 ;	quantum/action.c:643: case OP_BIT_AND: default_layer_and(bits); break;
      007838 90 78 3C         [24] 1445 	mov	dptr,#00465$
      00783B 73               [24] 1446 	jmp	@a+dptr
      00783C                       1447 00465$:
      00783C 80 06            [24] 1448 	sjmp	00132$
      00783E 80 0C            [24] 1449 	sjmp	00133$
      007840 80 12            [24] 1450 	sjmp	00134$
      007842 80 18            [24] 1451 	sjmp	00135$
      007844                       1452 00132$:
      007844 8F 82            [24] 1453 	mov	dpl, r7
      007846 12 7C 01         [24] 1454 	lcall	_default_layer_and
      007849 02 79 2E         [24] 1455 	ljmp	00181$
                                   1456 ;	quantum/action.c:644: case OP_BIT_OR: default_layer_or(bits); break;
      00784C                       1457 00133$:
      00784C 8F 82            [24] 1458 	mov	dpl, r7
      00784E 12 7B F0         [24] 1459 	lcall	_default_layer_or
      007851 02 79 2E         [24] 1460 	ljmp	00181$
                                   1461 ;	quantum/action.c:645: case OP_BIT_XOR: default_layer_xor(bits); break;
      007854                       1462 00134$:
      007854 8F 82            [24] 1463 	mov	dpl, r7
      007856 12 7C 17         [24] 1464 	lcall	_default_layer_xor
      007859 02 79 2E         [24] 1465 	ljmp	00181$
                                   1466 ;	quantum/action.c:646: case OP_BIT_SET: default_layer_set(bits); break;
      00785C                       1467 00135$:
      00785C 8F 82            [24] 1468 	mov	dpl, r7
      00785E 12 7B E5         [24] 1469 	lcall	_default_layer_set
                                   1470 ;	quantum/action.c:647: }
      007861 02 79 2E         [24] 1471 	ljmp	00181$
      007864                       1472 00143$:
                                   1473 ;	quantum/action.c:649: switch (action.layer_bitop.op) {
      007864 12 7B 81         [24] 1474 	lcall	_ak820_outline_0090
      007867 FE               [12] 1475 	mov	r6,a
      007868 2E               [12] 1476 	add	a,r6
                                   1477 ;	quantum/action.c:650: case OP_BIT_AND: layer_and(bits); break;
      007869 90 78 6D         [24] 1478 	mov	dptr,#00466$
      00786C 73               [24] 1479 	jmp	@a+dptr
      00786D                       1480 00466$:
      00786D 80 06            [24] 1481 	sjmp	00137$
      00786F 80 0C            [24] 1482 	sjmp	00138$
      007871 80 12            [24] 1483 	sjmp	00139$
      007873 80 18            [24] 1484 	sjmp	00140$
      007875                       1485 00137$:
      007875 8F 82            [24] 1486 	mov	dpl, r7
      007877 12 7D 9B         [24] 1487 	lcall	_layer_and
      00787A 02 79 2E         [24] 1488 	ljmp	00181$
                                   1489 ;	quantum/action.c:651: case OP_BIT_OR: layer_or(bits); break;
      00787D                       1490 00138$:
      00787D 8F 82            [24] 1491 	mov	dpl, r7
      00787F 12 7D 8A         [24] 1492 	lcall	_layer_or
      007882 02 79 2E         [24] 1493 	ljmp	00181$
                                   1494 ;	quantum/action.c:652: case OP_BIT_XOR: layer_xor(bits); break;
      007885                       1495 00139$:
      007885 8F 82            [24] 1496 	mov	dpl, r7
      007887 12 7D B1         [24] 1497 	lcall	_layer_xor
      00788A 02 79 2E         [24] 1498 	ljmp	00181$
                                   1499 ;	quantum/action.c:653: case OP_BIT_SET: layer_state_set(bits); break;
      00788D                       1500 00140$:
      00788D 8F 82            [24] 1501 	mov	dpl, r7
      00788F 12 7D 27         [24] 1502 	lcall	_layer_state_set
                                   1503 ;	quantum/action.c:657: break;
      007892 02 79 2E         [24] 1504 	ljmp	00181$
                                   1505 ;	quantum/action.c:659: case ACT_LAYER_MODS:
      007895                       1506 00147$:
                                   1507 ;	quantum/action.c:660: if (pressed) {
      007895 E5 28            [12] 1508 	mov	a,_process_action_sloc0_1_0
      007897 60 11            [24] 1509 	jz	00149$
                                   1510 ;	quantum/action.c:661: layer_hold_on(action.layer_mods.layer);
      007899 12 7B 8A         [24] 1511 	lcall	_ak820_outline_0115
      00789C F5 82            [12] 1512 	mov	dpl,a
      00789E 12 7C 87         [24] 1513 	lcall	_layer_hold_on
                                   1514 ;	quantum/action.c:662: register_mods(action.layer_mods.mods);
      0078A1 12 7B 6C         [24] 1515 	lcall	_ak820_outline_0078
      0078A4 12 7A 83         [24] 1516 	lcall	_register_mods
      0078A7 02 79 2E         [24] 1517 	ljmp	00181$
      0078AA                       1518 00149$:
                                   1519 ;	quantum/action.c:664: unregister_mods(action.layer_mods.mods);
      0078AA 12 7B 6C         [24] 1520 	lcall	_ak820_outline_0078
      0078AD 12 7A 97         [24] 1521 	lcall	_unregister_mods
                                   1522 ;	quantum/action.c:665: layer_hold_off(action.layer_mods.layer);
      0078B0 12 7B 8A         [24] 1523 	lcall	_ak820_outline_0115
      0078B3 F5 82            [12] 1524 	mov	dpl,a
      0078B5 12 7C BF         [24] 1525 	lcall	_layer_hold_off
                                   1526 ;	quantum/action.c:667: break;
      0078B8 02 79 2E         [24] 1527 	ljmp	00181$
                                   1528 ;	quantum/action.c:669: case ACT_LAYER_TAP_EXT:
      0078BB                       1529 00152$:
                                   1530 ;	quantum/action.c:670: switch (action.layer_tap.code) {
      0078BB 12 7B 9C         [24] 1531 	lcall	_ak820_outline_0161
      0078BE FF               [12] 1532 	mov	r7,a
      0078BF BF F1 02         [24] 1533 	cjne	r7,#0xf1,00468$
      0078C2 80 0A            [24] 1534 	sjmp	00154$
      0078C4                       1535 00468$:
      0078C4 BF F2 02         [24] 1536 	cjne	r7,#0xf2,00469$
      0078C7 80 19            [24] 1537 	sjmp	00155$
      0078C9                       1538 00469$:
                                   1539 ;	quantum/action.c:686: momentary_layer_action:
      0078C9 BF F3 3B         [24] 1540 	cjne	r7,#0xf3,00160$
      0078CC 80 28            [24] 1541 	sjmp	00156$
      0078CE                       1542 00154$:
                                   1543 ;	quantum/action.c:687: pressed ? layer_hold_on(action.layer_tap.val) : layer_hold_off(action.layer_tap.val);
      0078CE E5 28            [12] 1544 	mov	a,_process_action_sloc0_1_0
      0078D0 60 08            [24] 1545 	jz	00206$
      0078D2 12 7B 52         [24] 1546 	lcall	_ak820_outline_0042
      0078D5 12 7C 87         [24] 1547 	lcall	_layer_hold_on
      0078D8 80 54            [24] 1548 	sjmp	00181$
      0078DA                       1549 00206$:
      0078DA 12 7B 52         [24] 1550 	lcall	_ak820_outline_0042
      0078DD 12 7C BF         [24] 1551 	lcall	_layer_hold_off
                                   1552 ;	quantum/action.c:688: break;
                                   1553 ;	quantum/action.c:689: case OP_OFF_ON:
      0078E0 80 4C            [24] 1554 	sjmp	00181$
      0078E2                       1555 00155$:
                                   1556 ;	quantum/action.c:690: pressed ? layer_off(action.layer_tap.val) : layer_on(action.layer_tap.val);
      0078E2 E5 28            [12] 1557 	mov	a,_process_action_sloc0_1_0
      0078E4 60 08            [24] 1558 	jz	00208$
      0078E6 12 7B 52         [24] 1559 	lcall	_ak820_outline_0042
      0078E9 12 7D 6C         [24] 1560 	lcall	_layer_off
      0078EC 80 40            [24] 1561 	sjmp	00181$
      0078EE                       1562 00208$:
      0078EE 12 7B 52         [24] 1563 	lcall	_ak820_outline_0042
      0078F1 12 7D 51         [24] 1564 	lcall	_layer_on
                                   1565 ;	quantum/action.c:691: break;
                                   1566 ;	quantum/action.c:692: case OP_SET_CLEAR:
      0078F4 80 38            [24] 1567 	sjmp	00181$
      0078F6                       1568 00156$:
                                   1569 ;	quantum/action.c:693: pressed ? layer_move(action.layer_tap.val) : layer_clear();
      0078F6 E5 28            [12] 1570 	mov	a,_process_action_sloc0_1_0
      0078F8 60 08            [24] 1571 	jz	00210$
      0078FA 12 7B 52         [24] 1572 	lcall	_ak820_outline_0042
      0078FD 12 7D 3B         [24] 1573 	lcall	_layer_move
      007900 80 2C            [24] 1574 	sjmp	00181$
      007902                       1575 00210$:
      007902 12 7D 35         [24] 1576 	lcall	_layer_clear
                                   1577 ;	quantum/action.c:694: break;
                                   1578 ;	quantum/action.c:740: default:
      007905 80 27            [24] 1579 	sjmp	00181$
      007907                       1580 00160$:
                                   1581 ;	quantum/action.c:747: if (pressed) {
      007907 E5 28            [12] 1582 	mov	a,_process_action_sloc0_1_0
      007909 60 08            [24] 1583 	jz	00163$
                                   1584 ;	quantum/action.c:749: register_code(action.layer_tap.code);
      00790B 12 7B 6C         [24] 1585 	lcall	_ak820_outline_0078
      00790E 12 79 45         [24] 1586 	lcall	_register_code
                                   1587 ;	quantum/action.c:751: ac_dprintf("KEYMAP_TAP_KEY: Tap: unregister_code\n");
      007911 80 1B            [24] 1588 	sjmp	00181$
      007913                       1589 00163$:
                                   1590 ;	quantum/action.c:752: if (action.layer_tap.code == KC_CAPS) {
      007913 12 7B 9C         [24] 1591 	lcall	_ak820_outline_0161
      007916 FF               [12] 1592 	mov	r7,a
      007917 BF 39 0E         [24] 1593 	cjne	r7,#0x39,00175$
                                   1594 ;	quantum/action.c:753: wait_ms(TAP_HOLD_CAPS_DELAY);
      00791A 7F 50            [12] 1595 	mov	r7,#0x50
      00791C                       1596 00187$:
      00791C EF               [12] 1597 	mov	a,r7
      00791D 60 09            [24] 1598 	jz	00175$
      00791F 90 00 01         [24] 1599 	mov	dptr,#0x0001
      007922 12 5C 38         [24] 1600 	lcall	_mDelaymS
      007925 1F               [12] 1601 	dec	r7
                                   1602 ;	quantum/action.c:755: wait_ms(TAP_CODE_DELAY);
      007926 80 F4            [24] 1603 	sjmp	00187$
      007928                       1604 00175$:
                                   1605 ;	quantum/action.c:757: unregister_code(action.layer_tap.code);
      007928 12 7B 6C         [24] 1606 	lcall	_ak820_outline_0078
      00792B 12 79 C1         [24] 1607 	lcall	_unregister_code
                                   1608 ;	quantum/action.c:840: }
      00792E                       1609 00181$:
                                   1610 ;	quantum/action.c:861: switch (action.kind.id) {
      00792E 90 08 8D         [24] 1611 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007931 E0               [24] 1612 	movx	a,@dptr
      007932 C4               [12] 1613 	swap	a
      007933 54 0F            [12] 1614 	anl	a,#0x0f
      007935 FF               [12] 1615 	mov	r7,a
      007936 BF 08 02         [24] 1616 	cjne	r7,#0x08,00478$
      007939 80 03            [24] 1617 	sjmp	00183$
      00793B                       1618 00478$:
      00793B BF 09 06         [24] 1619 	cjne	r7,#0x09,00192$
                                   1620 ;	quantum/action.c:863: case ACT_LAYER_MODS:
      00793E                       1621 00183$:
                                   1622 ;	quantum/action.c:868: led_set(host_keyboard_leds());
      00793E 12 6F E5         [24] 1623 	lcall	_host_keyboard_leds
                                   1624 ;	quantum/action.c:872: }
                                   1625 ;	quantum/action.c:925: }
      007941 02 9B EB         [24] 1626 	ljmp	_led_set
      007944                       1627 00192$:
      007944 22               [24] 1628 	ret
                                   1629 ;------------------------------------------------------------
                                   1630 ;Allocation info for local variables in function 'register_code'
                                   1631 ;------------------------------------------------------------
                                   1632 ;code          Allocated with name '_register_code_code_10000_716'
                                   1633 ;------------------------------------------------------------
                                   1634 ;	quantum/action.c:931: __attribute__((weak)) void register_code(uint8_t code) {
                                   1635 ;	-----------------------------------------
                                   1636 ;	 function register_code
                                   1637 ;	-----------------------------------------
      007945                       1638 _register_code:
      007945 E5 82            [12] 1639 	mov	a,dpl
      007947 90 08 92         [24] 1640 	mov	dptr,#_register_code_code_10000_716
      00794A F0               [24] 1641 	movx	@dptr,a
                                   1642 ;	quantum/action.c:932: if (code == KC_NO) {
      00794B E0               [24] 1643 	movx	a,@dptr
      00794C FF               [12] 1644 	mov	r7,a
      00794D 70 01            [24] 1645 	jnz	00123$
                                   1646 ;	quantum/action.c:933: return;
      00794F 22               [24] 1647 	ret
      007950                       1648 00123$:
                                   1649 ;	quantum/action.c:968: } else if (IS_BASIC_KEYCODE(code)) {
      007950 BF 04 00         [24] 1650 	cjne	r7,#0x04,00186$
      007953                       1651 00186$:
      007953 40 21            [24] 1652 	jc	00119$
      007955 EF               [12] 1653 	mov	a,r7
      007956 24 5B            [12] 1654 	add	a,#0xff - 0xa4
      007958 40 1C            [24] 1655 	jc	00119$
                                   1656 ;	free result
                                   1657 ;	quantum/action.c:973: if (!add_owned_key(code)) return;
      00795A 8F 82            [24] 1658 	mov	dpl, r7
      00795C C0 07            [24] 1659 	push	ar7
      00795E 12 82 00         [24] 1660 	lcall	_add_owned_key
      007961 E5 82            [12] 1661 	mov	a, dpl
      007963 D0 07            [24] 1662 	pop	ar7
      007965 70 01            [24] 1663 	jnz	00104$
      007967 22               [24] 1664 	ret
      007968                       1665 00104$:
                                   1666 ;	quantum/action.c:975: ak820_dynamic_macro_observe(code, true);
      007968 90 04 B1         [24] 1667 	mov	dptr,#_ak820_dynamic_macro_observe_PARM_2
      00796B 74 01            [12] 1668 	mov	a,#0x01
      00796D F0               [24] 1669 	movx	@dptr,a
      00796E 8F 82            [24] 1670 	mov	dpl, r7
      007970 12 3A 3B         [24] 1671 	lcall	_ak820_dynamic_macro_observe
                                   1672 ;	quantum/action.c:987: send_keyboard_report();
      007973 02 84 A0         [24] 1673 	ljmp	_send_keyboard_report
      007976                       1674 00119$:
                                   1675 ;	quantum/action.c:988: } else if (IS_MODIFIER_KEYCODE(code)) {
      007976 12 7B A1         [24] 1676 	lcall	_ak820_outline_0169
      007979 BF E0 00         [24] 1677 	cjne	r7,#0xe0,00190$
      00797C                       1678 00190$:
      00797C 40 1A            [24] 1679 	jc	00115$
      00797E EF               [12] 1680 	mov	a,r7
      00797F 24 18            [12] 1681 	add	a,#0xff - 0xe7
      007981 40 15            [24] 1682 	jc	00115$
                                   1683 ;	free result
                                   1684 ;	quantum/action.c:989: add_owned_mods(MOD_BIT(code));
      007983 74 07            [12] 1685 	mov	a,#0x07
      007985 5F               [12] 1686 	anl	a,r7
      007986 12 7B 5B         [24] 1687 	lcall	_ak820_outline_0063
      007989 80 02            [24] 1688 	sjmp	00194$
      00798B                       1689 00193$:
      00798B 25 E0            [12] 1690 	add	a,acc
      00798D                       1691 00194$:
      00798D D5 F0 FB         [24] 1692 	djnz	b,00193$
      007990 F5 82            [12] 1693 	mov	dpl,a
      007992 12 81 5D         [24] 1694 	lcall	_add_owned_mods
                                   1695 ;	quantum/action.c:990: send_keyboard_report();
      007995 02 84 A0         [24] 1696 	ljmp	_send_keyboard_report
      007998                       1697 00115$:
                                   1698 ;	quantum/action.c:993: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      007998 12 7B A1         [24] 1699 	lcall	_ak820_outline_0169
      00799B BF A5 00         [24] 1700 	cjne	r7,#0xa5,00195$
      00799E                       1701 00195$:
      00799E 40 05            [24] 1702 	jc	00113$
      0079A0 EF               [12] 1703 	mov	a,r7
      0079A1 24 58            [12] 1704 	add	a,#0xff - 0xa7
      0079A3 50 0D            [24] 1705 	jnc	00108$
                                   1706 ;	free result
      0079A5                       1707 00113$:
      0079A5 12 7B A1         [24] 1708 	lcall	_ak820_outline_0169
      0079A8 BF A8 00         [24] 1709 	cjne	r7,#0xa8,00198$
      0079AB                       1710 00198$:
      0079AB 40 13            [24] 1711 	jc	00125$
      0079AD EF               [12] 1712 	mov	a,r7
      0079AE 24 3D            [12] 1713 	add	a,#0xff - 0xc2
      0079B0 40 0E            [24] 1714 	jc	00125$
                                   1715 ;	free result
      0079B2                       1716 00108$:
                                   1717 ;	quantum/action.c:995: owned_usage_key(code, true);
      0079B2 12 7B A1         [24] 1718 	lcall	_ak820_outline_0169
      0079B5 90 0A F0         [24] 1719 	mov	dptr,#_owned_usage_key_PARM_2
      0079B8 74 01            [12] 1720 	mov	a,#0x01
      0079BA F0               [24] 1721 	movx	@dptr,a
      0079BB 8F 82            [24] 1722 	mov	dpl, r7
                                   1723 ;	quantum/action.c:1003: register_mouse(code, true);
                                   1724 ;	quantum/action.c:1005: }
      0079BD 02 83 4B         [24] 1725 	ljmp	_owned_usage_key
      0079C0                       1726 00125$:
      0079C0 22               [24] 1727 	ret
                                   1728 ;------------------------------------------------------------
                                   1729 ;Allocation info for local variables in function 'unregister_code'
                                   1730 ;------------------------------------------------------------
                                   1731 ;code          Allocated with name '_unregister_code_code_10000_730'
                                   1732 ;------------------------------------------------------------
                                   1733 ;	quantum/action.c:1011: __attribute__((weak)) void unregister_code(uint8_t code) {
                                   1734 ;	-----------------------------------------
                                   1735 ;	 function unregister_code
                                   1736 ;	-----------------------------------------
      0079C1                       1737 _unregister_code:
      0079C1 E5 82            [12] 1738 	mov	a,dpl
      0079C3 90 08 93         [24] 1739 	mov	dptr,#_unregister_code_code_10000_730
      0079C6 F0               [24] 1740 	movx	@dptr,a
                                   1741 ;	quantum/action.c:1012: if (code == KC_NO) {
      0079C7 E0               [24] 1742 	movx	a,@dptr
      0079C8 FF               [12] 1743 	mov	r7,a
      0079C9 70 01            [24] 1744 	jnz	00121$
                                   1745 ;	quantum/action.c:1013: return;
      0079CB 22               [24] 1746 	ret
      0079CC                       1747 00121$:
                                   1748 ;	quantum/action.c:1045: } else if (IS_BASIC_KEYCODE(code)) {
      0079CC BF 04 00         [24] 1749 	cjne	r7,#0x04,00184$
      0079CF                       1750 00184$:
      0079CF 40 1F            [24] 1751 	jc	00117$
      0079D1 EF               [12] 1752 	mov	a,r7
      0079D2 24 5B            [12] 1753 	add	a,#0xff - 0xa4
      0079D4 40 1A            [24] 1754 	jc	00117$
                                   1755 ;	free result
                                   1756 ;	quantum/action.c:1047: if (!del_owned_key(code)) return;
      0079D6 8F 82            [24] 1757 	mov	dpl, r7
      0079D8 C0 07            [24] 1758 	push	ar7
      0079DA 12 82 7D         [24] 1759 	lcall	_del_owned_key
      0079DD E5 82            [12] 1760 	mov	a, dpl
      0079DF D0 07            [24] 1761 	pop	ar7
      0079E1 70 01            [24] 1762 	jnz	00102$
      0079E3 22               [24] 1763 	ret
      0079E4                       1764 00102$:
                                   1765 ;	quantum/action.c:1049: ak820_dynamic_macro_observe(code, false);
      0079E4 90 04 B1         [24] 1766 	mov	dptr,#_ak820_dynamic_macro_observe_PARM_2
      0079E7 12 7B B2         [24] 1767 	lcall	_ak820_outline_0190
      0079EA 12 3A 3B         [24] 1768 	lcall	_ak820_dynamic_macro_observe
                                   1769 ;	quantum/action.c:1054: send_keyboard_report();
      0079ED 02 84 A0         [24] 1770 	ljmp	_send_keyboard_report
      0079F0                       1771 00117$:
                                   1772 ;	quantum/action.c:1055: } else if (IS_MODIFIER_KEYCODE(code)) {
      0079F0 12 7B A7         [24] 1773 	lcall	_ak820_outline_0170
      0079F3 BF E0 00         [24] 1774 	cjne	r7,#0xe0,00188$
      0079F6                       1775 00188$:
      0079F6 40 1A            [24] 1776 	jc	00113$
      0079F8 EF               [12] 1777 	mov	a,r7
      0079F9 24 18            [12] 1778 	add	a,#0xff - 0xe7
      0079FB 40 15            [24] 1779 	jc	00113$
                                   1780 ;	free result
                                   1781 ;	quantum/action.c:1056: del_owned_mods(MOD_BIT(code));
      0079FD 74 07            [12] 1782 	mov	a,#0x07
      0079FF 5F               [12] 1783 	anl	a,r7
      007A00 12 7B 5B         [24] 1784 	lcall	_ak820_outline_0063
      007A03 80 02            [24] 1785 	sjmp	00192$
      007A05                       1786 00191$:
      007A05 25 E0            [12] 1787 	add	a,acc
      007A07                       1788 00192$:
      007A07 D5 F0 FB         [24] 1789 	djnz	b,00191$
      007A0A F5 82            [12] 1790 	mov	dpl,a
      007A0C 12 81 6D         [24] 1791 	lcall	_del_owned_mods
                                   1792 ;	quantum/action.c:1057: send_keyboard_report();
      007A0F 02 84 A0         [24] 1793 	ljmp	_send_keyboard_report
      007A12                       1794 00113$:
                                   1795 ;	quantum/action.c:1060: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      007A12 12 7B A7         [24] 1796 	lcall	_ak820_outline_0170
      007A15 BF A5 00         [24] 1797 	cjne	r7,#0xa5,00193$
      007A18                       1798 00193$:
      007A18 40 05            [24] 1799 	jc	00111$
      007A1A EF               [12] 1800 	mov	a,r7
      007A1B 24 58            [12] 1801 	add	a,#0xff - 0xa7
      007A1D 50 0D            [24] 1802 	jnc	00106$
                                   1803 ;	free result
      007A1F                       1804 00111$:
      007A1F 12 7B A7         [24] 1805 	lcall	_ak820_outline_0170
      007A22 BF A8 00         [24] 1806 	cjne	r7,#0xa8,00196$
      007A25                       1807 00196$:
      007A25 40 11            [24] 1808 	jc	00123$
      007A27 EF               [12] 1809 	mov	a,r7
      007A28 24 3D            [12] 1810 	add	a,#0xff - 0xc2
      007A2A 40 0C            [24] 1811 	jc	00123$
                                   1812 ;	free result
      007A2C                       1813 00106$:
                                   1814 ;	quantum/action.c:1062: owned_usage_key(code, false);
      007A2C 12 7B A7         [24] 1815 	lcall	_ak820_outline_0170
      007A2F 90 0A F0         [24] 1816 	mov	dptr,#_owned_usage_key_PARM_2
      007A32 12 7B B2         [24] 1817 	lcall	_ak820_outline_0190
                                   1818 ;	quantum/action.c:1070: register_mouse(code, false);
                                   1819 ;	quantum/action.c:1072: }
      007A35 02 83 4B         [24] 1820 	ljmp	_owned_usage_key
      007A38                       1821 00123$:
      007A38 22               [24] 1822 	ret
                                   1823 ;------------------------------------------------------------
                                   1824 ;Allocation info for local variables in function 'tap_code_delay'
                                   1825 ;------------------------------------------------------------
                                   1826 ;delay         Allocated with name '_tap_code_delay_PARM_2'
                                   1827 ;code          Allocated with name '_tap_code_delay_code_10000_743'
                                   1828 ;i             Allocated with name '_tap_code_delay_i_20000_745'
                                   1829 ;i             Allocated with name '_tap_code_delay_i_50000_748'
                                   1830 ;------------------------------------------------------------
                                   1831 ;	quantum/action.c:1079: __attribute__((weak)) void tap_code_delay(uint8_t code, uint16_t delay) {
                                   1832 ;	-----------------------------------------
                                   1833 ;	 function tap_code_delay
                                   1834 ;	-----------------------------------------
      007A39                       1835 _tap_code_delay:
      007A39 E5 82            [12] 1836 	mov	a,dpl
      007A3B 90 08 96         [24] 1837 	mov	dptr,#_tap_code_delay_code_10000_743
      007A3E F0               [24] 1838 	movx	@dptr,a
                                   1839 ;	quantum/action.c:1080: register_code(code);
      007A3F E0               [24] 1840 	movx	a,@dptr
      007A40 FF               [12] 1841 	mov	r7,a
      007A41 F5 82            [12] 1842 	mov	dpl,a
      007A43 C0 07            [24] 1843 	push	ar7
      007A45 12 79 45         [24] 1844 	lcall	_register_code
      007A48 D0 07            [24] 1845 	pop	ar7
                                   1846 ;	quantum/action.c:1081: for (uint16_t i = delay; i > 0; i--) {
      007A4A 90 08 94         [24] 1847 	mov	dptr,#_tap_code_delay_PARM_2
      007A4D 12 38 6A         [24] 1848 	lcall	_ak820_outline_0086
      007A50                       1849 00110$:
      007A50 ED               [12] 1850 	mov	a,r5
      007A51 4E               [12] 1851 	orl	a,r6
      007A52 60 0D            [24] 1852 	jz	00105$
                                   1853 ;	quantum/action.c:1082: wait_ms(1);
      007A54 90 00 01         [24] 1854 	mov	dptr,#0x0001
      007A57 12 5C 38         [24] 1855 	lcall	_mDelaymS
                                   1856 ;	quantum/action.c:1081: for (uint16_t i = delay; i > 0; i--) {
      007A5A 1D               [12] 1857 	dec	r5
      007A5B BD FF 01         [24] 1858 	cjne	r5,#0xff,00141$
      007A5E 1E               [12] 1859 	dec	r6
      007A5F                       1860 00141$:
      007A5F 80 EF            [24] 1861 	sjmp	00110$
      007A61                       1862 00105$:
                                   1863 ;	quantum/action.c:1084: unregister_code(code);
      007A61 8F 82            [24] 1864 	mov	dpl, r7
                                   1865 ;	quantum/action.c:1085: }
      007A63 02 79 C1         [24] 1866 	ljmp	_unregister_code
                                   1867 ;------------------------------------------------------------
                                   1868 ;Allocation info for local variables in function 'tap_code'
                                   1869 ;------------------------------------------------------------
                                   1870 ;code          Allocated with name '_tap_code_code_10000_750'
                                   1871 ;------------------------------------------------------------
                                   1872 ;	quantum/action.c:1091: __attribute__((weak)) void tap_code(uint8_t code) {
                                   1873 ;	-----------------------------------------
                                   1874 ;	 function tap_code
                                   1875 ;	-----------------------------------------
      007A66                       1876 _tap_code:
      007A66 E5 82            [12] 1877 	mov	a,dpl
      007A68 90 08 97         [24] 1878 	mov	dptr,#_tap_code_code_10000_750
      007A6B F0               [24] 1879 	movx	@dptr,a
                                   1880 ;	quantum/action.c:1092: tap_code_delay(code, code == KC_CAPS ? QS_tap_hold_caps_delay : QS_tap_code_delay);
      007A6C E0               [24] 1881 	movx	a,@dptr
      007A6D FF               [12] 1882 	mov	r7,a
      007A6E BF 39 04         [24] 1883 	cjne	r7,#0x39,00103$
      007A71 7E 50            [12] 1884 	mov	r6,#0x50
      007A73 80 02            [24] 1885 	sjmp	00104$
      007A75                       1886 00103$:
      007A75 7E 00            [12] 1887 	mov	r6,#0x00
      007A77                       1888 00104$:
      007A77 90 08 94         [24] 1889 	mov	dptr,#_tap_code_delay_PARM_2
      007A7A EE               [12] 1890 	mov	a,r6
      007A7B 12 38 A1         [24] 1891 	lcall	_ak820_outline_0137
      007A7E 8F 82            [24] 1892 	mov	dpl, r7
                                   1893 ;	quantum/action.c:1093: }
      007A80 02 7A 39         [24] 1894 	ljmp	_tap_code_delay
                                   1895 ;------------------------------------------------------------
                                   1896 ;Allocation info for local variables in function 'register_mods'
                                   1897 ;------------------------------------------------------------
                                   1898 ;mods          Allocated with name '_register_mods_mods_10000_752'
                                   1899 ;------------------------------------------------------------
                                   1900 ;	quantum/action.c:1099: __attribute__((weak)) void register_mods(uint8_t mods) {
                                   1901 ;	-----------------------------------------
                                   1902 ;	 function register_mods
                                   1903 ;	-----------------------------------------
      007A83                       1904 _register_mods:
      007A83 E5 82            [12] 1905 	mov	a,dpl
      007A85 90 08 98         [24] 1906 	mov	dptr,#_register_mods_mods_10000_752
      007A88 F0               [24] 1907 	movx	@dptr,a
                                   1908 ;	quantum/action.c:1100: if (mods) {
      007A89 E0               [24] 1909 	movx	a,@dptr
      007A8A FF               [12] 1910 	mov	r7,a
      007A8B E0               [24] 1911 	movx	a,@dptr
      007A8C 60 08            [24] 1912 	jz	00103$
                                   1913 ;	quantum/action.c:1101: add_owned_mods(mods);
      007A8E 8F 82            [24] 1914 	mov	dpl, r7
      007A90 12 81 5D         [24] 1915 	lcall	_add_owned_mods
                                   1916 ;	quantum/action.c:1102: send_keyboard_report();
                                   1917 ;	quantum/action.c:1104: }
      007A93 02 84 A0         [24] 1918 	ljmp	_send_keyboard_report
      007A96                       1919 00103$:
      007A96 22               [24] 1920 	ret
                                   1921 ;------------------------------------------------------------
                                   1922 ;Allocation info for local variables in function 'unregister_mods'
                                   1923 ;------------------------------------------------------------
                                   1924 ;mods          Allocated with name '_unregister_mods_mods_10000_756'
                                   1925 ;------------------------------------------------------------
                                   1926 ;	quantum/action.c:1110: __attribute__((weak)) void unregister_mods(uint8_t mods) {
                                   1927 ;	-----------------------------------------
                                   1928 ;	 function unregister_mods
                                   1929 ;	-----------------------------------------
      007A97                       1930 _unregister_mods:
      007A97 E5 82            [12] 1931 	mov	a,dpl
      007A99 90 08 99         [24] 1932 	mov	dptr,#_unregister_mods_mods_10000_756
      007A9C F0               [24] 1933 	movx	@dptr,a
                                   1934 ;	quantum/action.c:1111: if (mods) {
      007A9D E0               [24] 1935 	movx	a,@dptr
      007A9E FF               [12] 1936 	mov	r7,a
      007A9F E0               [24] 1937 	movx	a,@dptr
      007AA0 60 08            [24] 1938 	jz	00103$
                                   1939 ;	quantum/action.c:1112: del_owned_mods(mods);
      007AA2 8F 82            [24] 1940 	mov	dpl, r7
      007AA4 12 81 6D         [24] 1941 	lcall	_del_owned_mods
                                   1942 ;	quantum/action.c:1113: send_keyboard_report();
                                   1943 ;	quantum/action.c:1115: }
      007AA7 02 84 A0         [24] 1944 	ljmp	_send_keyboard_report
      007AAA                       1945 00103$:
      007AAA 22               [24] 1946 	ret
                                   1947 ;------------------------------------------------------------
                                   1948 ;Allocation info for local variables in function 'register_weak_mods'
                                   1949 ;------------------------------------------------------------
                                   1950 ;mods          Allocated with name '_register_weak_mods_mods_10000_760'
                                   1951 ;------------------------------------------------------------
                                   1952 ;	quantum/action.c:1121: __attribute__((weak)) void register_weak_mods(uint8_t mods) {
                                   1953 ;	-----------------------------------------
                                   1954 ;	 function register_weak_mods
                                   1955 ;	-----------------------------------------
      007AAB                       1956 _register_weak_mods:
      007AAB E5 82            [12] 1957 	mov	a,dpl
      007AAD 90 08 9A         [24] 1958 	mov	dptr,#_register_weak_mods_mods_10000_760
      007AB0 F0               [24] 1959 	movx	@dptr,a
                                   1960 ;	quantum/action.c:1122: if (mods) {
      007AB1 E0               [24] 1961 	movx	a,@dptr
      007AB2 FF               [12] 1962 	mov	r7,a
      007AB3 E0               [24] 1963 	movx	a,@dptr
      007AB4 60 08            [24] 1964 	jz	00103$
                                   1965 ;	quantum/action.c:1123: add_owned_weak_mods(mods);
      007AB6 8F 82            [24] 1966 	mov	dpl, r7
      007AB8 12 81 7B         [24] 1967 	lcall	_add_owned_weak_mods
                                   1968 ;	quantum/action.c:1124: send_keyboard_report();
                                   1969 ;	quantum/action.c:1126: }
      007ABB 02 84 A0         [24] 1970 	ljmp	_send_keyboard_report
      007ABE                       1971 00103$:
      007ABE 22               [24] 1972 	ret
                                   1973 ;------------------------------------------------------------
                                   1974 ;Allocation info for local variables in function 'unregister_weak_mods'
                                   1975 ;------------------------------------------------------------
                                   1976 ;mods          Allocated with name '_unregister_weak_mods_mods_10000_764'
                                   1977 ;------------------------------------------------------------
                                   1978 ;	quantum/action.c:1132: __attribute__((weak)) void unregister_weak_mods(uint8_t mods) {
                                   1979 ;	-----------------------------------------
                                   1980 ;	 function unregister_weak_mods
                                   1981 ;	-----------------------------------------
      007ABF                       1982 _unregister_weak_mods:
      007ABF E5 82            [12] 1983 	mov	a,dpl
      007AC1 90 08 9B         [24] 1984 	mov	dptr,#_unregister_weak_mods_mods_10000_764
      007AC4 F0               [24] 1985 	movx	@dptr,a
                                   1986 ;	quantum/action.c:1133: if (mods) {
      007AC5 E0               [24] 1987 	movx	a,@dptr
      007AC6 FF               [12] 1988 	mov	r7,a
      007AC7 E0               [24] 1989 	movx	a,@dptr
      007AC8 60 08            [24] 1990 	jz	00103$
                                   1991 ;	quantum/action.c:1134: del_owned_weak_mods(mods);
      007ACA 8F 82            [24] 1992 	mov	dpl, r7
      007ACC 12 81 8B         [24] 1993 	lcall	_del_owned_weak_mods
                                   1994 ;	quantum/action.c:1135: send_keyboard_report();
                                   1995 ;	quantum/action.c:1137: }
      007ACF 02 84 A0         [24] 1996 	ljmp	_send_keyboard_report
      007AD2                       1997 00103$:
      007AD2 22               [24] 1998 	ret
                                   1999 ;------------------------------------------------------------
                                   2000 ;Allocation info for local variables in function 'clear_keyboard'
                                   2001 ;------------------------------------------------------------
                                   2002 ;	quantum/action.c:1143: void clear_keyboard(void) {
                                   2003 ;	-----------------------------------------
                                   2004 ;	 function clear_keyboard
                                   2005 ;	-----------------------------------------
      007AD3                       2006 _clear_keyboard:
                                   2007 ;	quantum/action.c:1144: clear_mods();
      007AD3 12 85 24         [24] 2008 	lcall	_clear_mods
                                   2009 ;	quantum/action.c:1145: clear_keyboard_but_mods();
                                   2010 ;	quantum/action.c:1146: }
      007AD6 02 7A D9         [24] 2011 	ljmp	_clear_keyboard_but_mods
                                   2012 ;------------------------------------------------------------
                                   2013 ;Allocation info for local variables in function 'clear_keyboard_but_mods'
                                   2014 ;------------------------------------------------------------
                                   2015 ;	quantum/action.c:1152: void clear_keyboard_but_mods(void) {
                                   2016 ;	-----------------------------------------
                                   2017 ;	 function clear_keyboard_but_mods
                                   2018 ;	-----------------------------------------
      007AD9                       2019 _clear_keyboard_but_mods:
                                   2020 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007AD9 90 0E 22         [24] 2021 	mov	dptr,#_actual_keyboard_report
      007ADC 75 F0 00         [24] 2022 	mov	b, #0x00
      007ADF 12 72 BB         [24] 2023 	lcall	_clear_keys_from_report
                                   2024 ;	quantum/action.c:1154: clear_keyboard_but_mods_and_keys();
                                   2025 ;	quantum/action.c:1155: }
      007AE2 02 7A E5         [24] 2026 	ljmp	_clear_keyboard_but_mods_and_keys
                                   2027 ;------------------------------------------------------------
                                   2028 ;Allocation info for local variables in function 'clear_keyboard_but_mods_and_keys'
                                   2029 ;------------------------------------------------------------
                                   2030 ;	quantum/action.c:1161: void clear_keyboard_but_mods_and_keys(void) {
                                   2031 ;	-----------------------------------------
                                   2032 ;	 function clear_keyboard_but_mods_and_keys
                                   2033 ;	-----------------------------------------
      007AE5                       2034 _clear_keyboard_but_mods_and_keys:
                                   2035 ;	quantum/action.c:1163: ak820_tapping_cancel();
      007AE5 12 4A 0D         [24] 2036 	lcall	_ak820_tapping_cancel
                                   2037 ;	quantum/action.c:1165: ak820_dynamic_macro_cancel();
      007AE8 12 39 6C         [24] 2038 	lcall	_ak820_dynamic_macro_cancel
                                   2039 ;	quantum/action.c:1171: ak820_oneshot_cancel();
      007AEB 12 2E F0         [24] 2040 	lcall	_ak820_oneshot_cancel
                                   2041 ;	quantum/action.c:1174: ak820_combo_cancel();
      007AEE 12 35 70         [24] 2042 	lcall	_ak820_combo_cancel
                                   2043 ;	quantum/action.c:1177: repeat_key_cancel();
      007AF1 12 A6 48         [24] 2044 	lcall	_repeat_key_cancel
                                   2045 ;	quantum/action.c:1179: clear_owned_mods();
      007AF4 12 81 9B         [24] 2046 	lcall	_clear_owned_mods
                                   2047 ;	quantum/action.c:1180: clear_owned_keys();
      007AF7 12 81 D3         [24] 2048 	lcall	_clear_owned_keys
                                   2049 ;	quantum/action.c:1181: clear_owned_usages();
      007AFA 12 83 13         [24] 2050 	lcall	_clear_owned_usages
                                   2051 ;	quantum/action.c:1182: layer_hold_clear();
      007AFD 12 7C F8         [24] 2052 	lcall	_layer_hold_clear
                                   2053 ;	quantum/action.c:1184: clear_macro_tri_layer();
      007B00 12 A0 95         [24] 2054 	lcall	_clear_macro_tri_layer
                                   2055 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007B03 90 0E 22         [24] 2056 	mov	dptr,#_actual_keyboard_report
      007B06 75 F0 00         [24] 2057 	mov	b, #0x00
      007B09 12 72 BB         [24] 2058 	lcall	_clear_keys_from_report
                                   2059 ;	quantum/action.c:1189: host_system_send(0);
      007B0C 90 00 00         [24] 2060 	mov	dptr,#0x0000
      007B0F 12 70 80         [24] 2061 	lcall	_host_system_send
                                   2062 ;	quantum/action.c:1190: host_consumer_send(0);
      007B12 90 00 00         [24] 2063 	mov	dptr,#0x0000
      007B15 12 70 B0         [24] 2064 	lcall	_host_consumer_send
                                   2065 ;	quantum/action.c:1192: clear_weak_mods();
      007B18 12 85 59         [24] 2066 	lcall	_clear_weak_mods
                                   2067 ;	quantum/action.c:1193: send_keyboard_report();
                                   2068 ;	quantum/action.c:1201: }
      007B1B 02 84 A0         [24] 2069 	ljmp	_send_keyboard_report
                                   2070 ;------------------------------------------------------------
                                   2071 ;Allocation info for local variables in function 'is_tap_record'
                                   2072 ;------------------------------------------------------------
                                   2073 ;record        Allocated with name '_is_tap_record_record_10000_780'
                                   2074 ;action        Allocated with name '_is_tap_record_action_10001_784'
                                   2075 ;------------------------------------------------------------
                                   2076 ;	quantum/action.c:1207: bool is_tap_record(keyrecord_t *record) {
                                   2077 ;	-----------------------------------------
                                   2078 	.area CSEG    (CODE)
                                   2079 	.area CONST   (CODE)
                                   2080 	.area XINIT   (CODE)
      00C5C8                       2081 __xinit__disable_action_cache:
      00C5C8 00                    2082 	.db #0x00	;  0
                                   2083 	.area CABS    (ABS,CODE)
                                   2084 
                                   2085 ; Experimental exact instruction outlining.
                                   2086 	.globl _ak820_outline_0001
                                   2087 	.globl _ak820_outline_0005
                                   2088 	.globl _ak820_outline_0006
                                   2089 	.globl _ak820_outline_0008
                                   2090 	.globl _ak820_outline_0009
                                   2091 	.globl _ak820_outline_0012
                                   2092 	.globl _ak820_outline_0013
                                   2093 	.globl _ak820_outline_0014
                                   2094 	.globl _ak820_outline_0016
                                   2095 	.globl _ak820_outline_0020
                                   2096 	.globl _ak820_outline_0021
                                   2097 	.globl _ak820_outline_0023
                                   2098 	.globl _ak820_outline_0031
                                   2099 	.globl _ak820_outline_0036
                                   2100 	.globl _ak820_outline_0042
                                   2101 	.globl _ak820_outline_0050
                                   2102 	.globl _ak820_outline_0051
                                   2103 	.globl _ak820_outline_0063
                                   2104 	.globl _ak820_outline_0071
                                   2105 	.globl _ak820_outline_0072
                                   2106 	.globl _ak820_outline_0076
                                   2107 	.globl _ak820_outline_0078
                                   2108 	.globl _ak820_outline_0080
                                   2109 	.globl _ak820_outline_0086
                                   2110 	.globl _ak820_outline_0090
                                   2111 	.globl _ak820_outline_0094
                                   2112 	.globl _ak820_outline_0097
                                   2113 	.globl _ak820_outline_0110
                                   2114 	.globl _ak820_outline_0111
                                   2115 	.globl _ak820_outline_0113
                                   2116 	.globl _ak820_outline_0115
                                   2117 	.globl _ak820_outline_0120
                                   2118 	.globl _ak820_outline_0125
                                   2119 	.globl _ak820_outline_0126
                                   2120 	.globl _ak820_outline_0127
                                   2121 	.globl _ak820_outline_0133
                                   2122 	.globl _ak820_outline_0137
                                   2123 	.globl _ak820_outline_0138
                                   2124 	.globl _ak820_outline_0145
                                   2125 	.globl _ak820_outline_0146
                                   2126 	.globl _ak820_outline_0151
                                   2127 	.globl _ak820_outline_0161
                                   2128 	.globl _ak820_outline_0169
                                   2129 	.globl _ak820_outline_0170
                                   2130 	.globl _ak820_outline_0183
                                   2131 	.globl _ak820_outline_0188
                                   2132 	.globl _ak820_outline_0190
                                   2133 
                                   2134 	.area CSEG (CODE)
                                   2135 ; function ak820_outline_0006
      007B1E                       2136 _ak820_outline_0006:
      007B1E 2D               [12] 2137 	add	a,r5
      007B1F FA               [12] 2138 	mov	r2,a
      007B20 E4               [12] 2139 	clr	a
      007B21 3E               [12] 2140 	addc	a,r6
      007B22 FB               [12] 2141 	mov	r3,a
      007B23 8F 04            [24] 2142 	mov	ar4,r7
      007B25 8A 82            [24] 2143 	mov	dpl,r2
      007B27 8B 83            [24] 2144 	mov	dph,r3
      007B29 8C F0            [24] 2145 	mov	b,r4
      007B2B 22               [24] 2146 	ret
                                   2147 
                                   2148 	.area CSEG (CODE)
                                   2149 ; function ak820_outline_0014
      007B2C                       2150 _ak820_outline_0014:
      007B2C 2D               [12] 2151 	add	a,r5
      007B2D F9               [12] 2152 	mov	r1,a
      007B2E E4               [12] 2153 	clr	a
      007B2F 3E               [12] 2154 	addc	a,r6
      007B30 FA               [12] 2155 	mov	r2,a
      007B31 8F 03            [24] 2156 	mov	ar3,r7
      007B33 89 82            [24] 2157 	mov	dpl,r1
      007B35 8A 83            [24] 2158 	mov	dph,r2
      007B37 8B F0            [24] 2159 	mov	b,r3
      007B39 22               [24] 2160 	ret
                                   2161 
                                   2162 	.area CSEG (CODE)
                                   2163 ; function ak820_outline_0020
      007B3A                       2164 _ak820_outline_0020:
      007B3A 8E 82            [24] 2165 	mov	dpl,r6
      007B3C 8F 83            [24] 2166 	mov	dph,r7
      007B3E A3               [24] 2167 	inc	dptr
      007B3F E0               [24] 2168 	movx	a,@dptr
      007B40 FC               [12] 2169 	mov	r4,a
      007B41 7D 00            [12] 2170 	mov	r5,#0x00
      007B43 8E 82            [24] 2171 	mov	dpl,r6
      007B45 8F 83            [24] 2172 	mov	dph,r7
      007B47 E0               [24] 2173 	movx	a,@dptr
      007B48 22               [24] 2174 	ret
                                   2175 
                                   2176 	.area CSEG (CODE)
                                   2177 ; function ak820_outline_0023
      007B49                       2178 _ak820_outline_0023:
      007B49 E0               [24] 2179 	movx	a,@dptr
      007B4A FB               [12] 2180 	mov	r3,a
      007B4B A3               [24] 2181 	inc	dptr
      007B4C E0               [24] 2182 	movx	a,@dptr
      007B4D FC               [12] 2183 	mov	r4,a
      007B4E A3               [24] 2184 	inc	dptr
      007B4F E0               [24] 2185 	movx	a,@dptr
      007B50 FD               [12] 2186 	mov	r5,a
      007B51 22               [24] 2187 	ret
                                   2188 
                                   2189 	.area CSEG (CODE)
                                   2190 ; function ak820_outline_0042
      007B52                       2191 _ak820_outline_0042:
      007B52 90 08 8D         [24] 2192 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007B55 E0               [24] 2193 	movx	a,@dptr
      007B56 54 1F            [12] 2194 	anl	a,#0x1f
      007B58 F5 82            [12] 2195 	mov	dpl,a
      007B5A 22               [24] 2196 	ret
                                   2197 
                                   2198 	.area CSEG (CODE)
                                   2199 ; function ak820_outline_0063
      007B5B                       2200 _ak820_outline_0063:
      007B5B F5 F0            [12] 2201 	mov	b,a
      007B5D 05 F0            [12] 2202 	inc	b
      007B5F 74 01            [12] 2203 	mov	a,#0x01
      007B61 22               [24] 2204 	ret
                                   2205 
                                   2206 	.area CSEG (CODE)
                                   2207 ; function ak820_outline_0071
      007B62                       2208 _ak820_outline_0071:
      007B62 90 0E 00         [24] 2209 	mov	dptr,#___memcpy_PARM_3
      007B65 74 06            [12] 2210 	mov	a,#0x06
      007B67 F0               [24] 2211 	movx	@dptr,a
      007B68 E4               [12] 2212 	clr	a
      007B69 A3               [24] 2213 	inc	dptr
      007B6A F0               [24] 2214 	movx	@dptr,a
      007B6B 22               [24] 2215 	ret
                                   2216 
                                   2217 	.area CSEG (CODE)
                                   2218 ; function ak820_outline_0078
      007B6C                       2219 _ak820_outline_0078:
      007B6C 90 08 8C         [24] 2220 	mov	dptr,#_process_action_PARM_2
      007B6F E0               [24] 2221 	movx	a,@dptr
      007B70 F5 82            [12] 2222 	mov	dpl,a
      007B72 22               [24] 2223 	ret
                                   2224 
                                   2225 	.area CSEG (CODE)
                                   2226 ; function ak820_outline_0080
      007B73                       2227 _ak820_outline_0080:
      007B73 2D               [12] 2228 	add	a,r5
      007B74 F8               [12] 2229 	mov	r0,a
      007B75 E4               [12] 2230 	clr	a
      007B76 3E               [12] 2231 	addc	a,r6
      007B77 F9               [12] 2232 	mov	r1,a
      007B78 8F 02            [24] 2233 	mov	ar2,r7
      007B7A 88 82            [24] 2234 	mov	dpl,r0
      007B7C 89 83            [24] 2235 	mov	dph,r1
      007B7E 8A F0            [24] 2236 	mov	b,r2
      007B80 22               [24] 2237 	ret
                                   2238 
                                   2239 	.area CSEG (CODE)
                                   2240 ; function ak820_outline_0090
      007B81                       2241 _ak820_outline_0090:
      007B81 90 08 8D         [24] 2242 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007B84 E0               [24] 2243 	movx	a,@dptr
      007B85 03               [12] 2244 	rr	a
      007B86 03               [12] 2245 	rr	a
      007B87 54 03            [12] 2246 	anl	a,#0x03
      007B89 22               [24] 2247 	ret
                                   2248 
                                   2249 	.area CSEG (CODE)
                                   2250 ; function ak820_outline_0115
      007B8A                       2251 _ak820_outline_0115:
      007B8A 90 08 8D         [24] 2252 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007B8D E0               [24] 2253 	movx	a,@dptr
      007B8E 54 0F            [12] 2254 	anl	a,#0x0f
      007B90 22               [24] 2255 	ret
                                   2256 
                                   2257 	.area CSEG (CODE)
                                   2258 ; function ak820_outline_0133
      007B91                       2259 _ak820_outline_0133:
      007B91 90 08 8C         [24] 2260 	mov	dptr,#_process_action_PARM_2
      007B94 E0               [24] 2261 	movx	a,@dptr
      007B95 FE               [12] 2262 	mov	r6,a
      007B96 A3               [24] 2263 	inc	dptr
      007B97 E0               [24] 2264 	movx	a,@dptr
      007B98 54 03            [12] 2265 	anl	a,#0x03
      007B9A FF               [12] 2266 	mov	r7,a
      007B9B 22               [24] 2267 	ret
                                   2268 
                                   2269 	.area CSEG (CODE)
                                   2270 ; function ak820_outline_0161
      007B9C                       2271 _ak820_outline_0161:
      007B9C 90 08 8C         [24] 2272 	mov	dptr,#_process_action_PARM_2
      007B9F E0               [24] 2273 	movx	a,@dptr
      007BA0 22               [24] 2274 	ret
                                   2275 
                                   2276 	.area CSEG (CODE)
                                   2277 ; function ak820_outline_0169
      007BA1                       2278 _ak820_outline_0169:
      007BA1 90 08 92         [24] 2279 	mov	dptr,#_register_code_code_10000_716
      007BA4 E0               [24] 2280 	movx	a,@dptr
      007BA5 FF               [12] 2281 	mov	r7,a
      007BA6 22               [24] 2282 	ret
                                   2283 
                                   2284 	.area CSEG (CODE)
                                   2285 ; function ak820_outline_0170
      007BA7                       2286 _ak820_outline_0170:
      007BA7 90 08 93         [24] 2287 	mov	dptr,#_unregister_code_code_10000_730
      007BAA E0               [24] 2288 	movx	a,@dptr
      007BAB FF               [12] 2289 	mov	r7,a
      007BAC 22               [24] 2290 	ret
                                   2291 
                                   2292 	.area CSEG (CODE)
                                   2293 ; function ak820_outline_0188
      007BAD                       2294 _ak820_outline_0188:
      007BAD F0               [24] 2295 	movx	@dptr,a
      007BAE EB               [12] 2296 	mov	a,r3
      007BAF A3               [24] 2297 	inc	dptr
      007BB0 F0               [24] 2298 	movx	@dptr,a
      007BB1 22               [24] 2299 	ret
                                   2300 
                                   2301 	.area CSEG (CODE)
                                   2302 ; function ak820_outline_0190
      007BB2                       2303 _ak820_outline_0190:
      007BB2 E4               [12] 2304 	clr	a
      007BB3 F0               [24] 2305 	movx	@dptr,a
      007BB4 8F 82            [24] 2306 	mov	dpl,r7
      007BB6 22               [24] 2307 	ret
