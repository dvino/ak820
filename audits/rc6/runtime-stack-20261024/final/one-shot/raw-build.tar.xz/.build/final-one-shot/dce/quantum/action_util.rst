                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action_util
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _host_consumer_send
                                     12 	.globl _host_system_send
                                     13 	.globl _host_keyboard_send
                                     14 	.globl _clear_keys_from_report
                                     15 	.globl _del_key_from_report
                                     16 	.globl _add_key_to_report
                                     17 	.globl _KEYCODE2CONSUMER
                                     18 	.globl _ADC_START
                                     19 	.globl _S0_R_FIFO
                                     20 	.globl _S0_T_FIFO
                                     21 	.globl _S0_FREE
                                     22 	.globl _S0_IF_BYTE
                                     23 	.globl _S0_IF_FIRST
                                     24 	.globl _S0_IF_OV
                                     25 	.globl _S0_FST_ACT
                                     26 	.globl _CP_RL2
                                     27 	.globl _C_T2
                                     28 	.globl _TR2
                                     29 	.globl _EXEN2
                                     30 	.globl _TCLK
                                     31 	.globl _RCLK
                                     32 	.globl _EXF2
                                     33 	.globl _CAP1F
                                     34 	.globl _TF2
                                     35 	.globl _RI
                                     36 	.globl _TI
                                     37 	.globl _RB8
                                     38 	.globl _TB8
                                     39 	.globl _REN
                                     40 	.globl _SM2
                                     41 	.globl _SM1
                                     42 	.globl _SM0
                                     43 	.globl _IT0
                                     44 	.globl _IE0
                                     45 	.globl _IT1
                                     46 	.globl _IE1
                                     47 	.globl _TR0
                                     48 	.globl _TF0
                                     49 	.globl _TR1
                                     50 	.globl _TF1
                                     51 	.globl _P4_0
                                     52 	.globl _P4_1
                                     53 	.globl _P4_2
                                     54 	.globl _P4_3
                                     55 	.globl _P4_4
                                     56 	.globl _P4_5
                                     57 	.globl _P4_6
                                     58 	.globl _RXD
                                     59 	.globl _TXD
                                     60 	.globl _INT0
                                     61 	.globl _INT1
                                     62 	.globl _T0
                                     63 	.globl _T1
                                     64 	.globl _MOSI1
                                     65 	.globl _MISO1
                                     66 	.globl _SCK1
                                     67 	.globl _P3_0
                                     68 	.globl _P3_1
                                     69 	.globl _P3_2
                                     70 	.globl _P3_3
                                     71 	.globl _P3_4
                                     72 	.globl _P3_5
                                     73 	.globl _P3_6
                                     74 	.globl _P3_7
                                     75 	.globl _CAP1_
                                     76 	.globl _T2_
                                     77 	.globl _CAP2_
                                     78 	.globl _T2EX_
                                     79 	.globl _RXD1
                                     80 	.globl _TXD1
                                     81 	.globl _P2_0
                                     82 	.globl _P2_1
                                     83 	.globl _P2_2
                                     84 	.globl _P2_3
                                     85 	.globl _P2_4
                                     86 	.globl _P2_5
                                     87 	.globl _P2_6
                                     88 	.globl _P2_7
                                     89 	.globl _AIN0
                                     90 	.globl _AIN1
                                     91 	.globl _AIN2
                                     92 	.globl _AIN3
                                     93 	.globl _AIN4
                                     94 	.globl _AIN5
                                     95 	.globl _AIN6
                                     96 	.globl _AIN7
                                     97 	.globl _CAP1
                                     98 	.globl _T2
                                     99 	.globl _CAP2
                                    100 	.globl _T2EX
                                    101 	.globl _INT0_
                                    102 	.globl _SCS
                                    103 	.globl _MOSI
                                    104 	.globl _MISO
                                    105 	.globl _SCK
                                    106 	.globl _RXD1_
                                    107 	.globl _TXD1_
                                    108 	.globl _P1_0
                                    109 	.globl _P1_1
                                    110 	.globl _P1_2
                                    111 	.globl _P1_3
                                    112 	.globl _P1_4
                                    113 	.globl _P1_5
                                    114 	.globl _P1_6
                                    115 	.globl _P1_7
                                    116 	.globl _AIN8
                                    117 	.globl _AIN9
                                    118 	.globl _AIN10
                                    119 	.globl _AIN11
                                    120 	.globl _AIN12
                                    121 	.globl _AIN13
                                    122 	.globl _RXD_
                                    123 	.globl _TXD_
                                    124 	.globl _SCL0
                                    125 	.globl _SDA0
                                    126 	.globl _P0_0
                                    127 	.globl _P0_1
                                    128 	.globl _P0_2
                                    129 	.globl _P0_3
                                    130 	.globl _P0_4
                                    131 	.globl _P0_5
                                    132 	.globl _P0_6
                                    133 	.globl _P0_7
                                    134 	.globl _IE_SPI0
                                    135 	.globl _IE_USB
                                    136 	.globl _IE_ADC
                                    137 	.globl _IE_UART1
                                    138 	.globl _IE_PWM_I2C
                                    139 	.globl _IE_GPIO
                                    140 	.globl _IE_WDOG
                                    141 	.globl _PX0
                                    142 	.globl _PT0
                                    143 	.globl _PX1
                                    144 	.globl _PT1
                                    145 	.globl _PS
                                    146 	.globl _PT2
                                    147 	.globl _PL_FLAG
                                    148 	.globl _PH_FLAG
                                    149 	.globl _EX0
                                    150 	.globl _ET0
                                    151 	.globl _EX1
                                    152 	.globl _ET1
                                    153 	.globl _ES
                                    154 	.globl _ET2
                                    155 	.globl _E_DIS
                                    156 	.globl _EA
                                    157 	.globl _P
                                    158 	.globl _F1
                                    159 	.globl _OV
                                    160 	.globl _RS0
                                    161 	.globl _RS1
                                    162 	.globl _F0
                                    163 	.globl _AC
                                    164 	.globl _CY
                                    165 	.globl _I2CS_INT_ST
                                    166 	.globl _I2CX_INT
                                    167 	.globl _LED_STATUS
                                    168 	.globl _LED_DMA_H
                                    169 	.globl _LED_DMA_L
                                    170 	.globl _LED_DMA
                                    171 	.globl _LED_PWM_OE
                                    172 	.globl _LED_COMMON
                                    173 	.globl _ADC_CHAN
                                    174 	.globl _ADC_DAT_H
                                    175 	.globl _ADC_DAT_L
                                    176 	.globl _ADC_DAT
                                    177 	.globl _ADC_CTRL
                                    178 	.globl _SPI1_CK_SE
                                    179 	.globl _SPI1_CTRL
                                    180 	.globl _SPI1_DATA
                                    181 	.globl _SPI1_STAT
                                    182 	.globl _SIF1
                                    183 	.globl _SBAUD1
                                    184 	.globl _SBUF1
                                    185 	.globl _SCON1
                                    186 	.globl _SPI0_SETUP
                                    187 	.globl _SPI0_CK_SE
                                    188 	.globl _SPI0_CTRL
                                    189 	.globl _SPI0_DATA
                                    190 	.globl _SPI0_STAT
                                    191 	.globl _T2CAP1H
                                    192 	.globl _T2CAP1L
                                    193 	.globl _T2CAP1
                                    194 	.globl _TH2
                                    195 	.globl _TL2
                                    196 	.globl _T2COUNT
                                    197 	.globl _RCAP2H
                                    198 	.globl _RCAP2L
                                    199 	.globl _RCAP2
                                    200 	.globl _T2MOD
                                    201 	.globl _T2CON
                                    202 	.globl _SBUF
                                    203 	.globl _SCON
                                    204 	.globl _TH1
                                    205 	.globl _TH0
                                    206 	.globl _TL1
                                    207 	.globl _TL0
                                    208 	.globl _TMOD
                                    209 	.globl _TCON
                                    210 	.globl _XBUS_AUX
                                    211 	.globl _P7
                                    212 	.globl _P6_DIR
                                    213 	.globl _P6_OUT_PU
                                    214 	.globl _P6_IN
                                    215 	.globl _P5_DIR
                                    216 	.globl _P5_OUT_PU
                                    217 	.globl _P5_IN
                                    218 	.globl _P4_LED_KEY
                                    219 	.globl _P4_DIR_PU
                                    220 	.globl _P4_MOD_OC
                                    221 	.globl _P4
                                    222 	.globl _P3_DIR_PU
                                    223 	.globl _P3_MOD_OC
                                    224 	.globl _P3
                                    225 	.globl _P2_DIR_PU
                                    226 	.globl _P2_MOD_OC
                                    227 	.globl _P2
                                    228 	.globl _P1_DIR_PU
                                    229 	.globl _P1_MOD_OC
                                    230 	.globl _P1
                                    231 	.globl _P0_DIR_PU
                                    232 	.globl _P0_MOD_OC
                                    233 	.globl _P0
                                    234 	.globl _ROM_CTRL
                                    235 	.globl _ROM_DATA_HH
                                    236 	.globl _ROM_DATA_HL
                                    237 	.globl _ROM_DATA_HI
                                    238 	.globl _ROM_ADDR_H
                                    239 	.globl _ROM_ADDR_L
                                    240 	.globl _ROM_ADDR
                                    241 	.globl _GPIO_IE
                                    242 	.globl _IP_EX
                                    243 	.globl _IE_EX
                                    244 	.globl _IP
                                    245 	.globl _IE
                                    246 	.globl _WDOG_COUNT
                                    247 	.globl _RESET_KEEP
                                    248 	.globl _WAKE_CTRL
                                    249 	.globl _CLOCK_CFG
                                    250 	.globl _POWER_CFG
                                    251 	.globl _PCON
                                    252 	.globl _GLOBAL_CFG
                                    253 	.globl _SAFE_MOD
                                    254 	.globl _DPH
                                    255 	.globl _DPL
                                    256 	.globl _SP
                                    257 	.globl _A_INV
                                    258 	.globl _B
                                    259 	.globl _ACC
                                    260 	.globl _PSW
                                    261 	.globl _actual_keyboard_report
                                    262 	.globl _owned_usage_key_PARM_2
                                    263 	.globl _ak820_macro_change_PARM_3
                                    264 	.globl _ak820_macro_change_PARM_2
                                    265 	.globl _ak820_macro_cancelled
                                    266 	.globl _ak820_macro_primitive
                                    267 	.globl _ak820_macro_change
                                    268 	.globl _add_owned_mods
                                    269 	.globl _del_owned_mods
                                    270 	.globl _add_owned_weak_mods
                                    271 	.globl _del_owned_weak_mods
                                    272 	.globl _clear_owned_mods
                                    273 	.globl _clear_owned_keys
                                    274 	.globl _add_owned_key
                                    275 	.globl _del_owned_key
                                    276 	.globl _clear_owned_usages
                                    277 	.globl _owned_usage_key
                                    278 	.globl _send_keyboard_report
                                    279 	.globl _get_mods
                                    280 	.globl _clear_mods
                                    281 	.globl _get_weak_mods
                                    282 	.globl _add_weak_mods
                                    283 	.globl _del_weak_mods
                                    284 	.globl _clear_weak_mods
                                    285 ;--------------------------------------------------------
                                    286 ; special function registers
                                    287 ;--------------------------------------------------------
                                    288 	.area RSEG    (ABS,DATA)
      000000                        289 	.org 0x0000
                           0000D0   290 _PSW	=	0x00d0
                           0000E0   291 _ACC	=	0x00e0
                           0000F0   292 _B	=	0x00f0
                           0000FD   293 _A_INV	=	0x00fd
                           000081   294 _SP	=	0x0081
                           000082   295 _DPL	=	0x0082
                           000083   296 _DPH	=	0x0083
                           0000A1   297 _SAFE_MOD	=	0x00a1
                           0000B1   298 _GLOBAL_CFG	=	0x00b1
                           000087   299 _PCON	=	0x0087
                           0000BA   300 _POWER_CFG	=	0x00ba
                           0000B9   301 _CLOCK_CFG	=	0x00b9
                           0000A9   302 _WAKE_CTRL	=	0x00a9
                           0000FE   303 _RESET_KEEP	=	0x00fe
                           0000FF   304 _WDOG_COUNT	=	0x00ff
                           0000A8   305 _IE	=	0x00a8
                           0000B8   306 _IP	=	0x00b8
                           0000E8   307 _IE_EX	=	0x00e8
                           0000E9   308 _IP_EX	=	0x00e9
                           0000B2   309 _GPIO_IE	=	0x00b2
                           008584   310 _ROM_ADDR	=	0x8584
                           000084   311 _ROM_ADDR_L	=	0x0084
                           000085   312 _ROM_ADDR_H	=	0x0085
                           008F8E   313 _ROM_DATA_HI	=	0x8f8e
                           00008E   314 _ROM_DATA_HL	=	0x008e
                           00008F   315 _ROM_DATA_HH	=	0x008f
                           000086   316 _ROM_CTRL	=	0x0086
                           000080   317 _P0	=	0x0080
                           0000C4   318 _P0_MOD_OC	=	0x00c4
                           0000C5   319 _P0_DIR_PU	=	0x00c5
                           000090   320 _P1	=	0x0090
                           000092   321 _P1_MOD_OC	=	0x0092
                           000093   322 _P1_DIR_PU	=	0x0093
                           0000A0   323 _P2	=	0x00a0
                           000094   324 _P2_MOD_OC	=	0x0094
                           000095   325 _P2_DIR_PU	=	0x0095
                           0000B0   326 _P3	=	0x00b0
                           000096   327 _P3_MOD_OC	=	0x0096
                           000097   328 _P3_DIR_PU	=	0x0097
                           0000C0   329 _P4	=	0x00c0
                           0000C2   330 _P4_MOD_OC	=	0x00c2
                           0000C3   331 _P4_DIR_PU	=	0x00c3
                           0000C1   332 _P4_LED_KEY	=	0x00c1
                           0000AA   333 _P5_IN	=	0x00aa
                           0000AB   334 _P5_OUT_PU	=	0x00ab
                           0000AC   335 _P5_DIR	=	0x00ac
                           0000AD   336 _P6_IN	=	0x00ad
                           0000AE   337 _P6_OUT_PU	=	0x00ae
                           0000AF   338 _P6_DIR	=	0x00af
                           0000F1   339 _P7	=	0x00f1
                           0000A2   340 _XBUS_AUX	=	0x00a2
                           000088   341 _TCON	=	0x0088
                           000089   342 _TMOD	=	0x0089
                           00008A   343 _TL0	=	0x008a
                           00008B   344 _TL1	=	0x008b
                           00008C   345 _TH0	=	0x008c
                           00008D   346 _TH1	=	0x008d
                           000098   347 _SCON	=	0x0098
                           000099   348 _SBUF	=	0x0099
                           0000C8   349 _T2CON	=	0x00c8
                           0000C9   350 _T2MOD	=	0x00c9
                           00CBCA   351 _RCAP2	=	0xcbca
                           0000CA   352 _RCAP2L	=	0x00ca
                           0000CB   353 _RCAP2H	=	0x00cb
                           00CDCC   354 _T2COUNT	=	0xcdcc
                           0000CC   355 _TL2	=	0x00cc
                           0000CD   356 _TH2	=	0x00cd
                           00CFCE   357 _T2CAP1	=	0xcfce
                           0000CE   358 _T2CAP1L	=	0x00ce
                           0000CF   359 _T2CAP1H	=	0x00cf
                           0000F8   360 _SPI0_STAT	=	0x00f8
                           0000F9   361 _SPI0_DATA	=	0x00f9
                           0000FA   362 _SPI0_CTRL	=	0x00fa
                           0000FB   363 _SPI0_CK_SE	=	0x00fb
                           0000FC   364 _SPI0_SETUP	=	0x00fc
                           0000BC   365 _SCON1	=	0x00bc
                           0000BD   366 _SBUF1	=	0x00bd
                           0000BE   367 _SBAUD1	=	0x00be
                           0000BF   368 _SIF1	=	0x00bf
                           0000B4   369 _SPI1_STAT	=	0x00b4
                           0000B5   370 _SPI1_DATA	=	0x00b5
                           0000B6   371 _SPI1_CTRL	=	0x00b6
                           0000B7   372 _SPI1_CK_SE	=	0x00b7
                           0000F3   373 _ADC_CTRL	=	0x00f3
                           00F5F4   374 _ADC_DAT	=	0xf5f4
                           0000F4   375 _ADC_DAT_L	=	0x00f4
                           0000F5   376 _ADC_DAT_H	=	0x00f5
                           0000F6   377 _ADC_CHAN	=	0x00f6
                           0000A6   378 _LED_COMMON	=	0x00a6
                           0000A7   379 _LED_PWM_OE	=	0x00a7
                           00C7C6   380 _LED_DMA	=	0xc7c6
                           0000C6   381 _LED_DMA_L	=	0x00c6
                           0000C7   382 _LED_DMA_H	=	0x00c7
                           0000F7   383 _LED_STATUS	=	0x00f7
                           0000B3   384 _I2CX_INT	=	0x00b3
                           0000BB   385 _I2CS_INT_ST	=	0x00bb
                                    386 ;--------------------------------------------------------
                                    387 ; special function bits
                                    388 ;--------------------------------------------------------
                                    389 	.area RSEG    (ABS,DATA)
      000000                        390 	.org 0x0000
                           0000D7   391 _CY	=	0x00d7
                           0000D6   392 _AC	=	0x00d6
                           0000D5   393 _F0	=	0x00d5
                           0000D4   394 _RS1	=	0x00d4
                           0000D3   395 _RS0	=	0x00d3
                           0000D2   396 _OV	=	0x00d2
                           0000D1   397 _F1	=	0x00d1
                           0000D0   398 _P	=	0x00d0
                           0000AF   399 _EA	=	0x00af
                           0000AE   400 _E_DIS	=	0x00ae
                           0000AD   401 _ET2	=	0x00ad
                           0000AC   402 _ES	=	0x00ac
                           0000AB   403 _ET1	=	0x00ab
                           0000AA   404 _EX1	=	0x00aa
                           0000A9   405 _ET0	=	0x00a9
                           0000A8   406 _EX0	=	0x00a8
                           0000BF   407 _PH_FLAG	=	0x00bf
                           0000BE   408 _PL_FLAG	=	0x00be
                           0000BD   409 _PT2	=	0x00bd
                           0000BC   410 _PS	=	0x00bc
                           0000BB   411 _PT1	=	0x00bb
                           0000BA   412 _PX1	=	0x00ba
                           0000B9   413 _PT0	=	0x00b9
                           0000B8   414 _PX0	=	0x00b8
                           0000EF   415 _IE_WDOG	=	0x00ef
                           0000EE   416 _IE_GPIO	=	0x00ee
                           0000ED   417 _IE_PWM_I2C	=	0x00ed
                           0000EC   418 _IE_UART1	=	0x00ec
                           0000EB   419 _IE_ADC	=	0x00eb
                           0000E9   420 _IE_USB	=	0x00e9
                           0000E8   421 _IE_SPI0	=	0x00e8
                           000087   422 _P0_7	=	0x0087
                           000086   423 _P0_6	=	0x0086
                           000085   424 _P0_5	=	0x0085
                           000084   425 _P0_4	=	0x0084
                           000083   426 _P0_3	=	0x0083
                           000082   427 _P0_2	=	0x0082
                           000081   428 _P0_1	=	0x0081
                           000080   429 _P0_0	=	0x0080
                           000081   430 _SDA0	=	0x0081
                           000080   431 _SCL0	=	0x0080
                           000083   432 _TXD_	=	0x0083
                           000082   433 _RXD_	=	0x0082
                           000085   434 _AIN13	=	0x0085
                           000084   435 _AIN12	=	0x0084
                           000083   436 _AIN11	=	0x0083
                           000082   437 _AIN10	=	0x0082
                           000081   438 _AIN9	=	0x0081
                           000080   439 _AIN8	=	0x0080
                           000097   440 _P1_7	=	0x0097
                           000096   441 _P1_6	=	0x0096
                           000095   442 _P1_5	=	0x0095
                           000094   443 _P1_4	=	0x0094
                           000093   444 _P1_3	=	0x0093
                           000092   445 _P1_2	=	0x0092
                           000091   446 _P1_1	=	0x0091
                           000090   447 _P1_0	=	0x0090
                           000097   448 _TXD1_	=	0x0097
                           000096   449 _RXD1_	=	0x0096
                           000097   450 _SCK	=	0x0097
                           000096   451 _MISO	=	0x0096
                           000095   452 _MOSI	=	0x0095
                           000094   453 _SCS	=	0x0094
                           000092   454 _INT0_	=	0x0092
                           000091   455 _T2EX	=	0x0091
                           000091   456 _CAP2	=	0x0091
                           000090   457 _T2	=	0x0090
                           000090   458 _CAP1	=	0x0090
                           000097   459 _AIN7	=	0x0097
                           000096   460 _AIN6	=	0x0096
                           000095   461 _AIN5	=	0x0095
                           000094   462 _AIN4	=	0x0094
                           000093   463 _AIN3	=	0x0093
                           000092   464 _AIN2	=	0x0092
                           000091   465 _AIN1	=	0x0091
                           000090   466 _AIN0	=	0x0090
                           0000A7   467 _P2_7	=	0x00a7
                           0000A6   468 _P2_6	=	0x00a6
                           0000A5   469 _P2_5	=	0x00a5
                           0000A4   470 _P2_4	=	0x00a4
                           0000A3   471 _P2_3	=	0x00a3
                           0000A2   472 _P2_2	=	0x00a2
                           0000A1   473 _P2_1	=	0x00a1
                           0000A0   474 _P2_0	=	0x00a0
                           0000A7   475 _TXD1	=	0x00a7
                           0000A6   476 _RXD1	=	0x00a6
                           0000A5   477 _T2EX_	=	0x00a5
                           0000A5   478 _CAP2_	=	0x00a5
                           0000A4   479 _T2_	=	0x00a4
                           0000A4   480 _CAP1_	=	0x00a4
                           0000B7   481 _P3_7	=	0x00b7
                           0000B6   482 _P3_6	=	0x00b6
                           0000B5   483 _P3_5	=	0x00b5
                           0000B4   484 _P3_4	=	0x00b4
                           0000B3   485 _P3_3	=	0x00b3
                           0000B2   486 _P3_2	=	0x00b2
                           0000B1   487 _P3_1	=	0x00b1
                           0000B0   488 _P3_0	=	0x00b0
                           0000B7   489 _SCK1	=	0x00b7
                           0000B6   490 _MISO1	=	0x00b6
                           0000B5   491 _MOSI1	=	0x00b5
                           0000B5   492 _T1	=	0x00b5
                           0000B4   493 _T0	=	0x00b4
                           0000B3   494 _INT1	=	0x00b3
                           0000B2   495 _INT0	=	0x00b2
                           0000B1   496 _TXD	=	0x00b1
                           0000B0   497 _RXD	=	0x00b0
                           0000C6   498 _P4_6	=	0x00c6
                           0000C5   499 _P4_5	=	0x00c5
                           0000C4   500 _P4_4	=	0x00c4
                           0000C3   501 _P4_3	=	0x00c3
                           0000C2   502 _P4_2	=	0x00c2
                           0000C1   503 _P4_1	=	0x00c1
                           0000C0   504 _P4_0	=	0x00c0
                           00008F   505 _TF1	=	0x008f
                           00008E   506 _TR1	=	0x008e
                           00008D   507 _TF0	=	0x008d
                           00008C   508 _TR0	=	0x008c
                           00008B   509 _IE1	=	0x008b
                           00008A   510 _IT1	=	0x008a
                           000089   511 _IE0	=	0x0089
                           000088   512 _IT0	=	0x0088
                           00009F   513 _SM0	=	0x009f
                           00009E   514 _SM1	=	0x009e
                           00009D   515 _SM2	=	0x009d
                           00009C   516 _REN	=	0x009c
                           00009B   517 _TB8	=	0x009b
                           00009A   518 _RB8	=	0x009a
                           000099   519 _TI	=	0x0099
                           000098   520 _RI	=	0x0098
                           0000CF   521 _TF2	=	0x00cf
                           0000CF   522 _CAP1F	=	0x00cf
                           0000CE   523 _EXF2	=	0x00ce
                           0000CD   524 _RCLK	=	0x00cd
                           0000CC   525 _TCLK	=	0x00cc
                           0000CB   526 _EXEN2	=	0x00cb
                           0000CA   527 _TR2	=	0x00ca
                           0000C9   528 _C_T2	=	0x00c9
                           0000C8   529 _CP_RL2	=	0x00c8
                           0000FF   530 _S0_FST_ACT	=	0x00ff
                           0000FE   531 _S0_IF_OV	=	0x00fe
                           0000FD   532 _S0_IF_FIRST	=	0x00fd
                           0000FC   533 _S0_IF_BYTE	=	0x00fc
                           0000FB   534 _S0_FREE	=	0x00fb
                           0000FA   535 _S0_T_FIFO	=	0x00fa
                           0000F8   536 _S0_R_FIFO	=	0x00f8
                           0000F7   537 _ADC_START	=	0x00f7
                                    538 ;--------------------------------------------------------
                                    539 ; overlayable register banks
                                    540 ;--------------------------------------------------------
                                    541 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        542 	.ds 8
                                    543 ;--------------------------------------------------------
                                    544 ; internal ram data
                                    545 ;--------------------------------------------------------
                                    546 	.area DSEG    (DATA)
                                    547 ;--------------------------------------------------------
                                    548 ; overlayable items in internal ram
                                    549 ;--------------------------------------------------------
                                    550 	.area	OSEG    (OVR,DATA)
      000058                        551 _change_owned_sloc1_1_0:
      000058                        552 	.ds 1
                                    553 ;--------------------------------------------------------
                                    554 ; indirectly addressable internal ram data
                                    555 ;--------------------------------------------------------
                                    556 	.area ISEG    (DATA)
                                    557 ;--------------------------------------------------------
                                    558 ; absolute internal ram data
                                    559 ;--------------------------------------------------------
                                    560 	.area IABS    (ABS,DATA)
                                    561 	.area IABS    (ABS,DATA)
                                    562 ;--------------------------------------------------------
                                    563 ; bit data
                                    564 ;--------------------------------------------------------
                                    565 	.area BSEG    (BIT)
      000020                        566 _ak820_macro_change_sloc0_1_0:
      000020                        567 	.ds 1
      000021                        568 _change_owned_sloc0_1_0:
      000021                        569 	.ds 1
      000022                        570 _owned_usage_key_sloc0_1_0:
      000022                        571 	.ds 1
                                    572 ;--------------------------------------------------------
                                    573 ; paged external ram data
                                    574 ;--------------------------------------------------------
                                    575 	.area PSEG    (PAG,XDATA)
                                    576 ;--------------------------------------------------------
                                    577 ; uninitialized external ram data
                                    578 ;--------------------------------------------------------
                                    579 	.area XSEG    (XDATA)
      000973                        580 _owned_mod_refs:
      000973                        581 	.ds 8
      00097B                        582 _owned_weak_refs:
      00097B                        583 	.ds 8
      000983                        584 _owned_mods:
      000983                        585 	.ds 1
      000984                        586 _owned_weak_mods:
      000984                        587 	.ds 1
      000985                        588 _macro_mods:
      000985                        589 	.ds 2
      000987                        590 _ak820_macro_primitive::
      000987                        591 	.ds 1
      000988                        592 _ak820_macro_cancelled::
      000988                        593 	.ds 1
      000989                        594 _ak820_macro_change_PARM_2:
      000989                        595 	.ds 1
      00098A                        596 _ak820_macro_change_PARM_3:
      00098A                        597 	.ds 1
      00098B                        598 _ak820_macro_change_bits_10000_293:
      00098B                        599 	.ds 2
      00098D                        600 _change_owned_PARM_2:
      00098D                        601 	.ds 1
      00098E                        602 _change_owned_mods_10000_298:
      00098E                        603 	.ds 1
      00098F                        604 _change_owned_result_10001_302:
      00098F                        605 	.ds 1
      000990                        606 _change_owned_bit_20001_303:
      000990                        607 	.ds 1
      000991                        608 _add_owned_mods_mods_10000_311:
      000991                        609 	.ds 1
      000992                        610 _del_owned_mods_mods_10000_313:
      000992                        611 	.ds 1
      000993                        612 _add_owned_weak_mods_mods_10000_315:
      000993                        613 	.ds 1
      000994                        614 _del_owned_weak_mods_mods_10000_317:
      000994                        615 	.ds 1
      000995                        616 _key_refs:
      000995                        617 	.ds 165
      000A3A                        618 _distinct_keys:
      000A3A                        619 	.ds 1
      000A3B                        620 _macro_keys:
      000A3B                        621 	.ds 21
      000A50                        622 _add_owned_key_code_10000_326:
      000A50                        623 	.ds 1
      000A51                        624 _del_owned_key_code_10000_341:
      000A51                        625 	.ds 1
      000A52                        626 _usage_refs:
      000A52                        627 	.ds 30
      000A70                        628 _usage_order:
      000A70                        629 	.ds 30
      000A8E                        630 _usage_lengths:
      000A8E                        631 	.ds 2
      000A90                        632 _macro_usages:
      000A90                        633 	.ds 4
      000A94                        634 _owned_usage_key_PARM_2:
      000A94                        635 	.ds 1
      000A95                        636 _owned_usage_key_code_10000_368:
      000A95                        637 	.ds 1
      000A96                        638 _owned_usage_key___200000085_20000_369:
      000A96                        639 	.ds 2
      000A98                        640 _owned_usage_key_which_10000_369:
      000A98                        641 	.ds 1
      000A99                        642 _owned_usage_key_count_10000_369:
      000A99                        643 	.ds 1
      000A9A                        644 _owned_usage_key_pos_30001_376:
      000A9A                        645 	.ds 1
      000A9B                        646 _owned_usage_key_key_40000_381:
      000A9B                        647 	.ds 1
      000A9C                        648 _send_keyboard_report_last_report_10001_388:
      000A9C                        649 	.ds 32
      000ABC                        650 _send_keyboard_report_changed_10001_388:
      000ABC                        651 	.ds 1
      000ABD                        652 _add_weak_mods_mods_10000_406:
      000ABD                        653 	.ds 1
      000ABE                        654 _del_weak_mods_mods_10000_408:
      000ABE                        655 	.ds 1
                                    656 ;--------------------------------------------------------
                                    657 ; absolute external ram data
                                    658 ;--------------------------------------------------------
                                    659 	.area XABS    (ABS,XDATA)
                                    660 ;--------------------------------------------------------
                                    661 ; initialized external ram data
                                    662 ;--------------------------------------------------------
                                    663 	.area XISEG   (XDATA)
      000DBF                        664 _real_mods:
      000DBF                        665 	.ds 1
      000DC0                        666 _weak_mods:
      000DC0                        667 	.ds 1
      000DC1                        668 _actual_keyboard_report::
      000DC1                        669 	.ds 32
                                    670 	.area HOME    (CODE)
                                    671 	.area GSINIT0 (CODE)
                                    672 	.area GSINIT1 (CODE)
                                    673 	.area GSINIT2 (CODE)
                                    674 	.area GSINIT3 (CODE)
                                    675 	.area GSINIT4 (CODE)
                                    676 	.area GSINIT5 (CODE)
                                    677 	.area GSINIT  (CODE)
                                    678 	.area GSFINAL (CODE)
                                    679 	.area CSEG    (CODE)
                                    680 ;--------------------------------------------------------
                                    681 ; global & static initialisations
                                    682 ;--------------------------------------------------------
                                    683 	.area HOME    (CODE)
                                    684 	.area GSINIT  (CODE)
                                    685 	.area GSFINAL (CODE)
                                    686 	.area GSINIT  (CODE)
                                    687 ;--------------------------------------------------------
                                    688 ; Home
                                    689 ;--------------------------------------------------------
                                    690 	.area HOME    (CODE)
                                    691 	.area HOME    (CODE)
                                    692 ;--------------------------------------------------------
                                    693 ; code
                                    694 ;--------------------------------------------------------
                                    695 	.area CSEG    (CODE)
                                    696 ;------------------------------------------------------------
                                    697 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    698 ;------------------------------------------------------------
                                    699 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    700 ;------------------------------------------------------------
                                    701 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    702 ;	-----------------------------------------
                           000007   703 	ar7 = 0x07
                           000006   704 	ar6 = 0x06
                           000005   705 	ar5 = 0x05
                           000004   706 	ar4 = 0x04
                           000003   707 	ar3 = 0x03
                           000002   708 	ar2 = 0x02
                           000001   709 	ar1 = 0x01
                           000000   710 	ar0 = 0x00
                                    711 ;	 function ak820_macro_change
                                    712 ;	-----------------------------------------
      007AD2                        713 _ak820_macro_change:
      007AD2 12 38 8D         [24]  714 	lcall	_ak820_outline_0118
      007AD5 90 09 8B         [24]  715 	mov	dptr,#_ak820_macro_change_bits_10000_293
      007AD8 12 38 88         [24]  716 	lcall	_ak820_outline_0109
                                    717 ;	quantum/action_util.c:79: if (!ak820_macro_primitive) return true;
      007ADB 90 09 87         [24]  718 	mov	dptr,#_ak820_macro_primitive
      007ADE E0               [24]  719 	movx	a,@dptr
      007ADF 70 04            [24]  720 	jnz	00102$
      007AE1 75 82 01         [24]  721 	mov	dpl, #0x01
      007AE4 22               [24]  722 	ret
      007AE5                        723 00102$:
                                    724 ;	quantum/action_util.c:80: uint8_t mask = 1u << (index & 7);
      007AE5 90 09 89         [24]  725 	mov	dptr,#_ak820_macro_change_PARM_2
      007AE8 E0               [24]  726 	movx	a,@dptr
      007AE9 FF               [12]  727 	mov	r7,a
      007AEA 74 07            [12]  728 	mov	a,#0x07
      007AEC 5F               [12]  729 	anl	a,r7
      007AED 12 76 64         [24]  730 	lcall	_ak820_outline_0063
      007AF0 80 02            [24]  731 	sjmp	00123$
      007AF2                        732 00122$:
      007AF2 25 E0            [12]  733 	add	a,acc
      007AF4                        734 00123$:
      007AF4 D5 F0 FB         [24]  735 	djnz	b,00122$
      007AF7 FE               [12]  736 	mov	r6,a
                                    737 ;	quantum/action_util.c:81: bits += index >> 3;
      007AF8 EF               [12]  738 	mov	a,r7
      007AF9 12 56 BD         [24]  739 	lcall	_ak820_outline_0189
      007AFC FF               [12]  740 	mov	r7,a
      007AFD 90 09 8B         [24]  741 	mov	dptr,#_ak820_macro_change_bits_10000_293
      007B00 12 38 58         [24]  742 	lcall	_ak820_outline_0061
      007B03 90 09 8B         [24]  743 	mov	dptr,#_ak820_macro_change_bits_10000_293
      007B06 EF               [12]  744 	mov	a,r7
      007B07 2C               [12]  745 	add	a, r4
      007B08 F0               [24]  746 	movx	@dptr,a
      007B09 E4               [12]  747 	clr	a
      007B0A 3D               [12]  748 	addc	a, r5
      007B0B A3               [24]  749 	inc	dptr
      007B0C F0               [24]  750 	movx	@dptr,a
                                    751 ;	quantum/action_util.c:82: if (((*bits & mask) != 0) == pressed) return false;
      007B0D 90 09 8B         [24]  752 	mov	dptr,#_ak820_macro_change_bits_10000_293
      007B10 E0               [24]  753 	movx	a,@dptr
      007B11 FD               [12]  754 	mov	r5,a
      007B12 A3               [24]  755 	inc	dptr
      007B13 E0               [24]  756 	movx	a,@dptr
      007B14 FF               [12]  757 	mov	r7,a
      007B15 12 80 5E         [24]  758 	lcall	_ak820_outline_0190
      007B18 E0               [24]  759 	movx	a,@dptr
      007B19 FC               [12]  760 	mov	r4,a
      007B1A EE               [12]  761 	mov	a,r6
      007B1B 5C               [12]  762 	anl	a,r4
      007B1C B4 01 00         [24]  763 	cjne	a,#0x01,00124$
      007B1F                        764 00124$:
      007B1F B3               [12]  765 	cpl	c
      007B20 92 20            [24]  766 	mov	_ak820_macro_change_sloc0_1_0,c
      007B22 90 09 8A         [24]  767 	mov	dptr,#_ak820_macro_change_PARM_3
      007B25 E0               [24]  768 	movx	a,@dptr
      007B26 FB               [12]  769 	mov	r3,a
      007B27 A2 20            [12]  770 	mov	c,_ak820_macro_change_sloc0_1_0
      007B29 E4               [12]  771 	clr	a
      007B2A 33               [12]  772 	rlc	a
      007B2B B5 03 04         [24]  773 	cjne	a,ar3,00104$
      007B2E 75 82 00         [24]  774 	mov	dpl, #0x00
      007B31 22               [24]  775 	ret
      007B32                        776 00104$:
                                    777 ;	quantum/action_util.c:83: *bits ^= mask;
      007B32 EC               [12]  778 	mov	a,r4
      007B33 62 06            [12]  779 	xrl	ar6,a
      007B35 12 80 5E         [24]  780 	lcall	_ak820_outline_0190
      007B38 EE               [12]  781 	mov	a,r6
      007B39 F0               [24]  782 	movx	@dptr,a
                                    783 ;	quantum/action_util.c:84: return true;
      007B3A 75 82 01         [24]  784 	mov	dpl, #0x01
                                    785 ;	quantum/action_util.c:85: }
      007B3D 22               [24]  786 	ret
                                    787 ;------------------------------------------------------------
                                    788 ;Allocation info for local variables in function 'change_owned'
                                    789 ;------------------------------------------------------------
                                    790 ;mode          Allocated with name '_change_owned_PARM_2'
                                    791 ;mods          Allocated with name '_change_owned_mods_10000_298'
                                    792 ;kind          Allocated with name '_change_owned_kind_10000_299'
                                    793 ;pressed       Allocated with name '_change_owned_pressed_10000_299'
                                    794 ;refs          Allocated with name '_change_owned_refs_10000_299'
                                    795 ;old           Allocated with name '_change_owned_old_30000_301'
                                    796 ;result        Allocated with name '_change_owned_result_10001_302'
                                    797 ;i             Allocated with name '_change_owned_i_20001_303'
                                    798 ;bit           Allocated with name '_change_owned_bit_20001_303'
                                    799 ;sloc1         Allocated with name '_change_owned_sloc1_1_0'
                                    800 ;------------------------------------------------------------
                                    801 ;	quantum/action_util.c:86: static void change_owned(uint8_t mods, uint8_t mode) {
                                    802 ;	-----------------------------------------
                                    803 ;	 function change_owned
                                    804 ;	-----------------------------------------
      007B3E                        805 _change_owned:
      007B3E E5 82            [12]  806 	mov	a,dpl
      007B40 90 09 8E         [24]  807 	mov	dptr,#_change_owned_mods_10000_298
      007B43 F0               [24]  808 	movx	@dptr,a
                                    809 ;	quantum/action_util.c:87: uint8_t kind = mode >> 1;
      007B44 90 09 8D         [24]  810 	mov	dptr,#_change_owned_PARM_2
      007B47 E0               [24]  811 	movx	a,@dptr
      007B48 FF               [12]  812 	mov	r7,a
      007B49 C3               [12]  813 	clr	c
      007B4A 13               [12]  814 	rrc	a
      007B4B FE               [12]  815 	mov	r6,a
                                    816 ;	quantum/action_util.c:88: bool pressed = (mode & 1) != 0;
      007B4C 53 07 01         [24]  817 	anl	ar7,#0x01
      007B4F EF               [12]  818 	mov	a,r7
      007B50 B4 01 00         [24]  819 	cjne	a,#0x01,00205$
      007B53                        820 00205$:
      007B53 92 21            [24]  821 	mov  _change_owned_sloc0_1_0,c
      007B55 B3               [12]  822 	cpl	c
      007B56 E4               [12]  823 	clr	a
      007B57 33               [12]  824 	rlc	a
      007B58 F5 58            [12]  825 	mov	_change_owned_sloc1_1_0,a
                                    826 ;	quantum/action_util.c:89: uint8_t AK820_STATE_MEM *refs = kind ? owned_weak_refs : owned_mod_refs;
      007B5A EE               [12]  827 	mov	a,r6
      007B5B 60 06            [24]  828 	jz	00121$
      007B5D 7D 7B            [12]  829 	mov	r5,#_owned_weak_refs
      007B5F 7F 09            [12]  830 	mov	r7,#(_owned_weak_refs >> 8)
      007B61 80 04            [24]  831 	sjmp	00122$
      007B63                        832 00121$:
      007B63 7D 73            [12]  833 	mov	r5,#_owned_mod_refs
      007B65 7F 09            [12]  834 	mov	r7,#(_owned_mod_refs >> 8)
      007B67                        835 00122$:
                                    836 ;	quantum/action_util.c:90: if (ak820_macro_primitive) {
      007B67 90 09 87         [24]  837 	mov	dptr,#_ak820_macro_primitive
      007B6A E0               [24]  838 	movx	a,@dptr
      007B6B 60 36            [24]  839 	jz	00102$
                                    840 ;	quantum/action_util.c:91: uint8_t old = macro_mods[kind];
      007B6D EE               [12]  841 	mov	a,r6
      007B6E 24 85            [12]  842 	add	a, #_macro_mods
      007B70 FB               [12]  843 	mov	r3,a
      007B71 E4               [12]  844 	clr	a
      007B72 34 09            [12]  845 	addc	a, #(_macro_mods >> 8)
      007B74 12 48 0F         [24]  846 	lcall	_ak820_outline_0056
                                    847 ;	quantum/action_util.c:92: macro_mods[kind] = pressed ? old | mods : old & ~mods;
      007B77 E5 58            [12]  848 	mov	a,_change_owned_sloc1_1_0
      007B79 60 0A            [24]  849 	jz	00123$
      007B7B 90 09 8E         [24]  850 	mov	dptr,#_change_owned_mods_10000_298
      007B7E E0               [24]  851 	movx	a,@dptr
      007B7F F9               [12]  852 	mov	r1,a
      007B80 EA               [12]  853 	mov	a,r2
      007B81 42 01            [12]  854 	orl	ar1,a
      007B83 80 07            [24]  855 	sjmp	00124$
      007B85                        856 00123$:
      007B85 90 09 8E         [24]  857 	mov	dptr,#_change_owned_mods_10000_298
      007B88 E0               [24]  858 	movx	a,@dptr
      007B89 F4               [12]  859 	cpl	a
      007B8A 5A               [12]  860 	anl	a,r2
      007B8B F9               [12]  861 	mov	r1,a
      007B8C                        862 00124$:
      007B8C 12 33 FC         [24]  863 	lcall	_ak820_outline_0124
      007B8F E9               [12]  864 	mov	a,r1
      007B90 F0               [24]  865 	movx	@dptr,a
                                    866 ;	quantum/action_util.c:93: mods &= pressed ? ~old : old;
      007B91 E5 58            [12]  867 	mov	a,_change_owned_sloc1_1_0
      007B93 60 06            [24]  868 	jz	00125$
      007B95 74 FF            [12]  869 	mov	a,#0xff
      007B97 6A               [12]  870 	xrl	a,r2
      007B98 FC               [12]  871 	mov	r4,a
      007B99 80 02            [24]  872 	sjmp	00126$
      007B9B                        873 00125$:
      007B9B 8A 04            [24]  874 	mov	ar4,r2
      007B9D                        875 00126$:
      007B9D 90 09 8E         [24]  876 	mov	dptr,#_change_owned_mods_10000_298
      007BA0 E0               [24]  877 	movx	a,@dptr
      007BA1 5C               [12]  878 	anl	a,r4
      007BA2 F0               [24]  879 	movx	@dptr,a
      007BA3                        880 00102$:
                                    881 ;	quantum/action_util.c:95: uint8_t result = 0;
      007BA3 90 09 8F         [24]  882 	mov	dptr,#_change_owned_result_10001_302
      007BA6 E4               [12]  883 	clr	a
      007BA7 F0               [24]  884 	movx	@dptr,a
                                    885 ;	quantum/action_util.c:96: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      007BA8 90 09 90         [24]  886 	mov	dptr,#_change_owned_bit_20001_303
      007BAB 04               [12]  887 	inc	a
      007BAC F0               [24]  888 	movx	@dptr,a
      007BAD 90 09 8E         [24]  889 	mov	dptr,#_change_owned_mods_10000_298
      007BB0 E0               [24]  890 	movx	a,@dptr
      007BB1 FC               [12]  891 	mov	r4,a
      007BB2 7B 00            [12]  892 	mov	r3,#0x00
      007BB4                        893 00117$:
      007BB4 BB 08 00         [24]  894 	cjne	r3,#0x08,00210$
      007BB7                        895 00210$:
      007BB7 50 3F            [24]  896 	jnc	00112$
                                    897 ;	quantum/action_util.c:97: if (mods & bit) {
      007BB9 90 09 90         [24]  898 	mov	dptr,#_change_owned_bit_20001_303
      007BBC E0               [24]  899 	movx	a,@dptr
      007BBD 5C               [12]  900 	anl	a,r4
      007BBE 60 1C            [24]  901 	jz	00109$
                                    902 ;	quantum/action_util.c:98: if (pressed) ++refs[i];
      007BC0 E5 58            [12]  903 	mov	a,_change_owned_sloc1_1_0
      007BC2 60 0C            [24]  904 	jz	00106$
      007BC4 EB               [12]  905 	mov	a,r3
      007BC5 2D               [12]  906 	add	a, r5
      007BC6 12 38 27         [24]  907 	lcall	_ak820_outline_0016
      007BC9 F8               [12]  908 	mov	r0,a
      007BCA 08               [12]  909 	inc	r0
      007BCB 12 80 1B         [24]  910 	lcall	_ak820_outline_0064
      007BCE 80 0C            [24]  911 	sjmp	00109$
      007BD0                        912 00106$:
                                    913 ;	quantum/action_util.c:99: else if (refs[i]) --refs[i];
      007BD0 EB               [12]  914 	mov	a,r3
      007BD1 2D               [12]  915 	add	a, r5
      007BD2 12 38 27         [24]  916 	lcall	_ak820_outline_0016
      007BD5 F8               [12]  917 	mov	r0,a
      007BD6 60 04            [24]  918 	jz	00109$
      007BD8 18               [12]  919 	dec	r0
      007BD9 12 80 1B         [24]  920 	lcall	_ak820_outline_0064
      007BDC                        921 00109$:
                                    922 ;	quantum/action_util.c:101: if (refs[i]) result |= bit;
      007BDC EB               [12]  923 	mov	a,r3
      007BDD 2D               [12]  924 	add	a, r5
      007BDE 12 38 27         [24]  925 	lcall	_ak820_outline_0016
      007BE1 60 0B            [24]  926 	jz	00118$
      007BE3 90 09 90         [24]  927 	mov	dptr,#_change_owned_bit_20001_303
      007BE6 E0               [24]  928 	movx	a,@dptr
      007BE7 FA               [12]  929 	mov	r2,a
      007BE8 90 09 8F         [24]  930 	mov	dptr,#_change_owned_result_10001_302
      007BEB E0               [24]  931 	movx	a,@dptr
      007BEC 4A               [12]  932 	orl	a,r2
      007BED F0               [24]  933 	movx	@dptr,a
      007BEE                        934 00118$:
                                    935 ;	quantum/action_util.c:96: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      007BEE 0B               [12]  936 	inc	r3
      007BEF 90 09 90         [24]  937 	mov	dptr,#_change_owned_bit_20001_303
      007BF2 E0               [24]  938 	movx	a,@dptr
      007BF3 25 E0            [12]  939 	add	a,acc
      007BF5 F0               [24]  940 	movx	@dptr,a
      007BF6 80 BC            [24]  941 	sjmp	00117$
      007BF8                        942 00112$:
                                    943 ;	quantum/action_util.c:103: if (kind) owned_weak_mods = result;
      007BF8 EE               [12]  944 	mov	a,r6
      007BF9 60 09            [24]  945 	jz	00114$
      007BFB 90 09 8F         [24]  946 	mov	dptr,#_change_owned_result_10001_302
      007BFE E0               [24]  947 	movx	a,@dptr
      007BFF 90 09 84         [24]  948 	mov	dptr,#_owned_weak_mods
      007C02 F0               [24]  949 	movx	@dptr,a
      007C03 22               [24]  950 	ret
      007C04                        951 00114$:
                                    952 ;	quantum/action_util.c:104: else owned_mods = result;
      007C04 90 09 8F         [24]  953 	mov	dptr,#_change_owned_result_10001_302
      007C07 E0               [24]  954 	movx	a,@dptr
      007C08 90 09 83         [24]  955 	mov	dptr,#_owned_mods
      007C0B F0               [24]  956 	movx	@dptr,a
                                    957 ;	quantum/action_util.c:105: }
      007C0C 22               [24]  958 	ret
                                    959 ;------------------------------------------------------------
                                    960 ;Allocation info for local variables in function 'add_owned_mods'
                                    961 ;------------------------------------------------------------
                                    962 ;mods          Allocated with name '_add_owned_mods_mods_10000_311'
                                    963 ;------------------------------------------------------------
                                    964 ;	quantum/action_util.c:106: void add_owned_mods(uint8_t mods) { change_owned(mods, 1); }
                                    965 ;	-----------------------------------------
                                    966 ;	 function add_owned_mods
                                    967 ;	-----------------------------------------
      007C0D                        968 _add_owned_mods:
      007C0D E5 82            [12]  969 	mov	a,dpl
      007C0F 90 09 91         [24]  970 	mov	dptr,#_add_owned_mods_mods_10000_311
      007C12 12 80 3B         [24]  971 	lcall	_ak820_outline_0117
      007C15 74 01            [12]  972 	mov	a,#0x01
      007C17 F0               [24]  973 	movx	@dptr,a
      007C18 8F 82            [24]  974 	mov	dpl, r7
      007C1A 02 7B 3E         [24]  975 	ljmp	_change_owned
                                    976 ;------------------------------------------------------------
                                    977 ;Allocation info for local variables in function 'del_owned_mods'
                                    978 ;------------------------------------------------------------
                                    979 ;mods          Allocated with name '_del_owned_mods_mods_10000_313'
                                    980 ;------------------------------------------------------------
                                    981 ;	quantum/action_util.c:107: void del_owned_mods(uint8_t mods) { change_owned(mods, 0); }
                                    982 ;	-----------------------------------------
                                    983 ;	 function del_owned_mods
                                    984 ;	-----------------------------------------
      007C1D                        985 _del_owned_mods:
      007C1D E5 82            [12]  986 	mov	a,dpl
      007C1F 90 09 92         [24]  987 	mov	dptr,#_del_owned_mods_mods_10000_313
      007C22 12 80 3B         [24]  988 	lcall	_ak820_outline_0117
      007C25 E4               [12]  989 	clr	a
      007C26 F0               [24]  990 	movx	@dptr,a
      007C27 8F 82            [24]  991 	mov	dpl, r7
      007C29 02 7B 3E         [24]  992 	ljmp	_change_owned
                                    993 ;------------------------------------------------------------
                                    994 ;Allocation info for local variables in function 'add_owned_weak_mods'
                                    995 ;------------------------------------------------------------
                                    996 ;mods          Allocated with name '_add_owned_weak_mods_mods_10000_315'
                                    997 ;------------------------------------------------------------
                                    998 ;	quantum/action_util.c:108: void add_owned_weak_mods(uint8_t mods) { change_owned(mods, 3); }
                                    999 ;	-----------------------------------------
                                   1000 ;	 function add_owned_weak_mods
                                   1001 ;	-----------------------------------------
      007C2C                       1002 _add_owned_weak_mods:
      007C2C E5 82            [12] 1003 	mov	a,dpl
      007C2E 90 09 93         [24] 1004 	mov	dptr,#_add_owned_weak_mods_mods_10000_315
      007C31 12 80 3B         [24] 1005 	lcall	_ak820_outline_0117
      007C34 74 03            [12] 1006 	mov	a,#0x03
      007C36 F0               [24] 1007 	movx	@dptr,a
      007C37 8F 82            [24] 1008 	mov	dpl, r7
      007C39 02 7B 3E         [24] 1009 	ljmp	_change_owned
                                   1010 ;------------------------------------------------------------
                                   1011 ;Allocation info for local variables in function 'del_owned_weak_mods'
                                   1012 ;------------------------------------------------------------
                                   1013 ;mods          Allocated with name '_del_owned_weak_mods_mods_10000_317'
                                   1014 ;------------------------------------------------------------
                                   1015 ;	quantum/action_util.c:109: void del_owned_weak_mods(uint8_t mods) { change_owned(mods, 2); }
                                   1016 ;	-----------------------------------------
                                   1017 ;	 function del_owned_weak_mods
                                   1018 ;	-----------------------------------------
      007C3C                       1019 _del_owned_weak_mods:
      007C3C E5 82            [12] 1020 	mov	a,dpl
      007C3E 90 09 94         [24] 1021 	mov	dptr,#_del_owned_weak_mods_mods_10000_317
      007C41 12 80 3B         [24] 1022 	lcall	_ak820_outline_0117
      007C44 74 02            [12] 1023 	mov	a,#0x02
      007C46 F0               [24] 1024 	movx	@dptr,a
      007C47 8F 82            [24] 1025 	mov	dpl, r7
      007C49 02 7B 3E         [24] 1026 	ljmp	_change_owned
                                   1027 ;------------------------------------------------------------
                                   1028 ;Allocation info for local variables in function 'clear_owned_mods'
                                   1029 ;------------------------------------------------------------
                                   1030 ;i             Allocated with name '_clear_owned_mods_i_20000_321'
                                   1031 ;------------------------------------------------------------
                                   1032 ;	quantum/action_util.c:110: void clear_owned_mods(void) {
                                   1033 ;	-----------------------------------------
                                   1034 ;	 function clear_owned_mods
                                   1035 ;	-----------------------------------------
      007C4C                       1036 _clear_owned_mods:
                                   1037 ;	quantum/action_util.c:111: for (uint8_t i = 0; i < 8; ++i) owned_mod_refs[i] = owned_weak_refs[i] = 0;
      007C4C 7F 00            [12] 1038 	mov	r7,#0x00
      007C4E                       1039 00103$:
      007C4E BF 08 00         [24] 1040 	cjne	r7,#0x08,00122$
      007C51                       1041 00122$:
      007C51 50 1A            [24] 1042 	jnc	00101$
      007C53 EF               [12] 1043 	mov	a,r7
      007C54 24 73            [12] 1044 	add	a, #_owned_mod_refs
      007C56 FD               [12] 1045 	mov	r5,a
      007C57 E4               [12] 1046 	clr	a
      007C58 34 09            [12] 1047 	addc	a, #(_owned_mod_refs >> 8)
      007C5A FE               [12] 1048 	mov	r6,a
      007C5B EF               [12] 1049 	mov	a,r7
      007C5C 24 7B            [12] 1050 	add	a, #_owned_weak_refs
      007C5E F5 82            [12] 1051 	mov	dpl,a
      007C60 E4               [12] 1052 	clr	a
      007C61 34 09            [12] 1053 	addc	a, #(_owned_weak_refs >> 8)
      007C63 F5 83            [12] 1054 	mov	dph,a
      007C65 E4               [12] 1055 	clr	a
      007C66 F0               [24] 1056 	movx	@dptr,a
      007C67 12 80 42         [24] 1057 	lcall	_ak820_outline_0123
      007C6A 0F               [12] 1058 	inc	r7
      007C6B 80 E1            [24] 1059 	sjmp	00103$
      007C6D                       1060 00101$:
                                   1061 ;	quantum/action_util.c:112: owned_mods = owned_weak_mods = macro_mods[0] = macro_mods[1] = 0;
      007C6D 90 09 86         [24] 1062 	mov	dptr,#(_macro_mods + 0x0001)
      007C70 E4               [12] 1063 	clr	a
      007C71 F0               [24] 1064 	movx	@dptr,a
      007C72 90 09 85         [24] 1065 	mov	dptr,#_macro_mods
      007C75 F0               [24] 1066 	movx	@dptr,a
      007C76 90 09 84         [24] 1067 	mov	dptr,#_owned_weak_mods
      007C79 F0               [24] 1068 	movx	@dptr,a
      007C7A 90 09 83         [24] 1069 	mov	dptr,#_owned_mods
      007C7D F0               [24] 1070 	movx	@dptr,a
                                   1071 ;	quantum/action_util.c:113: ak820_macro_cancelled = true;
      007C7E 90 09 88         [24] 1072 	mov	dptr,#_ak820_macro_cancelled
      007C81 04               [12] 1073 	inc	a
      007C82 F0               [24] 1074 	movx	@dptr,a
                                   1075 ;	quantum/action_util.c:114: }
      007C83 22               [24] 1076 	ret
                                   1077 ;------------------------------------------------------------
                                   1078 ;Allocation info for local variables in function 'clear_owned_keys'
                                   1079 ;------------------------------------------------------------
                                   1080 ;i             Allocated with name '_clear_owned_keys_i_20000_324'
                                   1081 ;i             Allocated with name '_clear_owned_keys_i_20000_325'
                                   1082 ;------------------------------------------------------------
                                   1083 ;	quantum/action_util.c:120: void clear_owned_keys(void) {
                                   1084 ;	-----------------------------------------
                                   1085 ;	 function clear_owned_keys
                                   1086 ;	-----------------------------------------
      007C84                       1087 _clear_owned_keys:
                                   1088 ;	quantum/action_util.c:121: for (uint8_t i = 0; i <= KC_EXSEL; ++i) key_refs[i] = 0;
      007C84 7F 00            [12] 1089 	mov	r7,#0x00
      007C86                       1090 00104$:
      007C86 EF               [12] 1091 	mov	a,r7
      007C87 24 5B            [12] 1092 	add	a,#0xff - 0xa4
      007C89 40 0D            [24] 1093 	jc	00101$
                                   1094 ;	free result
      007C8B EF               [12] 1095 	mov	a,r7
      007C8C 24 95            [12] 1096 	add	a, #_key_refs
      007C8E F5 82            [12] 1097 	mov	dpl,a
      007C90 E4               [12] 1098 	clr	a
      007C91 34 09            [12] 1099 	addc	a, #(_key_refs >> 8)
      007C93 12 7A C3         [24] 1100 	lcall	_ak820_outline_0165
      007C96 80 EE            [24] 1101 	sjmp	00104$
      007C98                       1102 00101$:
                                   1103 ;	quantum/action_util.c:122: distinct_keys = 0;
      007C98 90 0A 3A         [24] 1104 	mov	dptr,#_distinct_keys
      007C9B E4               [12] 1105 	clr	a
      007C9C F0               [24] 1106 	movx	@dptr,a
                                   1107 ;	quantum/action_util.c:123: for (uint8_t i = 0; i < sizeof(macro_keys); ++i) macro_keys[i] = 0;
      007C9D FF               [12] 1108 	mov	r7,a
      007C9E                       1109 00107$:
      007C9E BF 15 00         [24] 1110 	cjne	r7,#0x15,00142$
      007CA1                       1111 00142$:
      007CA1 50 0D            [24] 1112 	jnc	00109$
      007CA3 EF               [12] 1113 	mov	a,r7
      007CA4 24 3B            [12] 1114 	add	a, #_macro_keys
      007CA6 F5 82            [12] 1115 	mov	dpl,a
      007CA8 E4               [12] 1116 	clr	a
      007CA9 34 0A            [12] 1117 	addc	a, #(_macro_keys >> 8)
      007CAB 12 7A C3         [24] 1118 	lcall	_ak820_outline_0165
      007CAE 80 EE            [24] 1119 	sjmp	00107$
      007CB0                       1120 00109$:
                                   1121 ;	quantum/action_util.c:124: }
      007CB0 22               [24] 1122 	ret
                                   1123 ;------------------------------------------------------------
                                   1124 ;Allocation info for local variables in function 'add_owned_key'
                                   1125 ;------------------------------------------------------------
                                   1126 ;code          Allocated with name '_add_owned_key_code_10000_326'
                                   1127 ;__400000074   Allocated with name '_add_owned_key___400000074_40000_335'
                                   1128 ;key           Allocated with name '_add_owned_key_key_50000_336'
                                   1129 ;i             Allocated with name '_add_owned_key_i_40000_334'
                                   1130 ;__300000076   Allocated with name '_add_owned_key___300000076_30000_338'
                                   1131 ;key           Allocated with name '_add_owned_key_key_40000_339'
                                   1132 ;------------------------------------------------------------
                                   1133 ;	quantum/action_util.c:125: bool add_owned_key(uint8_t code) {
                                   1134 ;	-----------------------------------------
                                   1135 ;	 function add_owned_key
                                   1136 ;	-----------------------------------------
      007CB1                       1137 _add_owned_key:
      007CB1 E5 82            [12] 1138 	mov	a,dpl
      007CB3 90 0A 50         [24] 1139 	mov	dptr,#_add_owned_key_code_10000_326
      007CB6 12 80 53         [24] 1140 	lcall	_ak820_outline_0133
                                   1141 ;	quantum/action_util.c:126: if (!ak820_macro_change(macro_keys, code, true)) return false;
      007CB9 74 01            [12] 1142 	mov	a,#0x01
      007CBB F0               [24] 1143 	movx	@dptr,a
      007CBC 90 0A 3B         [24] 1144 	mov	dptr,#_macro_keys
      007CBF C0 07            [24] 1145 	push	ar7
      007CC1 12 7A D2         [24] 1146 	lcall	_ak820_macro_change
      007CC4 E5 82            [12] 1147 	mov	a, dpl
      007CC6 D0 07            [24] 1148 	pop	ar7
      007CC8 70 03            [24] 1149 	jnz	00102$
      007CCA F5 82            [12] 1150 	mov	dpl,a
      007CCC 22               [24] 1151 	ret
      007CCD                       1152 00102$:
                                   1153 ;	quantum/action_util.c:127: if (key_refs[code]++) return false;
      007CCD 12 80 05         [24] 1154 	lcall	_ak820_outline_0030
      007CD0 FC               [12] 1155 	mov	r4,a
      007CD1 04               [12] 1156 	inc	a
      007CD2 12 80 42         [24] 1157 	lcall	_ak820_outline_0123
      007CD5 EC               [12] 1158 	mov	a,r4
      007CD6 60 04            [24] 1159 	jz	00104$
      007CD8 75 82 00         [24] 1160 	mov	dpl, #0x00
      007CDB 22               [24] 1161 	ret
      007CDC                       1162 00104$:
                                   1163 ;	quantum/action_util.c:128: ++distinct_keys;
      007CDC 90 0A 3A         [24] 1164 	mov	dptr,#_distinct_keys
      007CDF E0               [24] 1165 	movx	a,@dptr
      007CE0 24 01            [12] 1166 	add	a, #0x01
      007CE2 F0               [24] 1167 	movx	@dptr,a
                                   1168 ;	quantum/action_util.c:130: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      007CE3 90 0D AE         [24] 1169 	mov	dptr,#_keyboard_protocol
      007CE6 E0               [24] 1170 	movx	a,@dptr
      007CE7 60 15            [24] 1171 	jz	00106$
      007CE9 90 0A BF         [24] 1172 	mov	dptr,#_keymap_config
      007CEC E0               [24] 1173 	movx	a,@dptr
      007CED 30 E7 0E         [24] 1174 	jnb	acc.7,00106$
                                   1175 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      007CF0 90 08 00         [24] 1176 	mov	dptr,#_add_key_to_report_PARM_2
      007CF3 EF               [12] 1177 	mov	a,r7
      007CF4 12 80 13         [24] 1178 	lcall	_ak820_outline_0058
      007CF7 12 6E 28         [24] 1179 	lcall	_add_key_to_report
                                   1180 ;	quantum/action_util.c:130: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      007CFA 75 82 01         [24] 1181 	mov	dpl, #0x01
      007CFD 22               [24] 1182 	ret
      007CFE                       1183 00106$:
                                   1184 ;	quantum/action_util.c:132: if (distinct_keys > KEYBOARD_REPORT_KEYS) {
      007CFE 90 0A 3A         [24] 1185 	mov	dptr,#_distinct_keys
      007D01 E0               [24] 1186 	movx	a,@dptr
      007D02 24 F9            [12] 1187 	add	a,#0xff - 0x06
      007D04 50 17            [24] 1188 	jnc	00110$
                                   1189 ;	free result
                                   1190 ;	quantum/action_util.c:133: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; ++i) keyboard_report->keys[i] = 1; /* HID ErrorRollOver */
      007D06 7F 00            [12] 1191 	mov	r7,#0x00
      007D08                       1192 00115$:
      007D08 BF 06 00         [24] 1193 	cjne	r7,#0x06,00174$
      007D0B                       1194 00174$:
      007D0B 50 1D            [24] 1195 	jnc	00111$
      007D0D EF               [12] 1196 	mov	a,r7
      007D0E 24 C3            [12] 1197 	add	a, #(_actual_keyboard_report + 0x0002)
      007D10 F5 82            [12] 1198 	mov	dpl,a
      007D12 E4               [12] 1199 	clr	a
      007D13 34 0D            [12] 1200 	addc	a, #((_actual_keyboard_report + 0x0002) >> 8)
      007D15 F5 83            [12] 1201 	mov	dph,a
      007D17 74 01            [12] 1202 	mov	a,#0x01
      007D19 F0               [24] 1203 	movx	@dptr,a
      007D1A 0F               [12] 1204 	inc	r7
      007D1B 80 EB            [24] 1205 	sjmp	00115$
      007D1D                       1206 00110$:
                                   1207 ;	quantum/action_util.c:134: } else add_key(code);
      007D1D 90 0A 50         [24] 1208 	mov	dptr,#_add_owned_key_code_10000_326
      007D20 E0               [24] 1209 	movx	a,@dptr
                                   1210 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      007D21 90 08 00         [24] 1211 	mov	dptr,#_add_key_to_report_PARM_2
      007D24 12 80 13         [24] 1212 	lcall	_ak820_outline_0058
      007D27 12 6E 28         [24] 1213 	lcall	_add_key_to_report
                                   1214 ;	quantum/action_util.c:134: } else add_key(code);
      007D2A                       1215 00111$:
                                   1216 ;	quantum/action_util.c:135: return true;
      007D2A 75 82 01         [24] 1217 	mov	dpl, #0x01
                                   1218 ;	quantum/action_util.c:136: }
      007D2D 22               [24] 1219 	ret
                                   1220 ;------------------------------------------------------------
                                   1221 ;Allocation info for local variables in function 'del_owned_key'
                                   1222 ;------------------------------------------------------------
                                   1223 ;code          Allocated with name '_del_owned_key_code_10000_341'
                                   1224 ;__400000078   Allocated with name '_del_owned_key___400000078_40000_352'
                                   1225 ;key           Allocated with name '_del_owned_key_key_50000_353'
                                   1226 ;key           Allocated with name '_del_owned_key_key_40000_350'
                                   1227 ;__600000081   Allocated with name '_del_owned_key___600000081_60000_358'
                                   1228 ;key           Allocated with name '_del_owned_key_key_70000_359'
                                   1229 ;__300000083   Allocated with name '_del_owned_key___300000083_30000_361'
                                   1230 ;key           Allocated with name '_del_owned_key_key_40000_362'
                                   1231 ;------------------------------------------------------------
                                   1232 ;	quantum/action_util.c:137: bool del_owned_key(uint8_t code) {
                                   1233 ;	-----------------------------------------
                                   1234 ;	 function del_owned_key
                                   1235 ;	-----------------------------------------
      007D2E                       1236 _del_owned_key:
      007D2E E5 82            [12] 1237 	mov	a,dpl
      007D30 90 0A 51         [24] 1238 	mov	dptr,#_del_owned_key_code_10000_341
      007D33 12 80 53         [24] 1239 	lcall	_ak820_outline_0133
                                   1240 ;	quantum/action_util.c:138: if (!ak820_macro_change(macro_keys, code, false)) return false;
      007D36 E4               [12] 1241 	clr	a
      007D37 F0               [24] 1242 	movx	@dptr,a
      007D38 90 0A 3B         [24] 1243 	mov	dptr,#_macro_keys
      007D3B C0 07            [24] 1244 	push	ar7
      007D3D 12 7A D2         [24] 1245 	lcall	_ak820_macro_change
      007D40 E5 82            [12] 1246 	mov	a, dpl
      007D42 D0 07            [24] 1247 	pop	ar7
      007D44 70 03            [24] 1248 	jnz	00102$
      007D46 F5 82            [12] 1249 	mov	dpl,a
      007D48 22               [24] 1250 	ret
      007D49                       1251 00102$:
                                   1252 ;	quantum/action_util.c:139: if (!key_refs[code] || --key_refs[code]) return false;
      007D49 12 80 05         [24] 1253 	lcall	_ak820_outline_0030
      007D4C FC               [12] 1254 	mov	r4,a
      007D4D 60 07            [24] 1255 	jz	00103$
      007D4F 1C               [12] 1256 	dec	r4
      007D50 12 43 37         [24] 1257 	lcall	_ak820_outline_0065
      007D53 EC               [12] 1258 	mov	a,r4
      007D54 60 04            [24] 1259 	jz	00104$
      007D56                       1260 00103$:
      007D56 75 82 00         [24] 1261 	mov	dpl, #0x00
      007D59 22               [24] 1262 	ret
      007D5A                       1263 00104$:
                                   1264 ;	quantum/action_util.c:140: --distinct_keys;
      007D5A 90 0A 3A         [24] 1265 	mov	dptr,#_distinct_keys
      007D5D E0               [24] 1266 	movx	a,@dptr
      007D5E 14               [12] 1267 	dec	a
      007D5F F0               [24] 1268 	movx	@dptr,a
                                   1269 ;	quantum/action_util.c:142: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      007D60 90 0D AE         [24] 1270 	mov	dptr,#_keyboard_protocol
      007D63 E0               [24] 1271 	movx	a,@dptr
      007D64 60 15            [24] 1272 	jz	00107$
      007D66 90 0A BF         [24] 1273 	mov	dptr,#_keymap_config
      007D69 E0               [24] 1274 	movx	a,@dptr
      007D6A 30 E7 0E         [24] 1275 	jnb	acc.7,00107$
                                   1276 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      007D6D 90 08 04         [24] 1277 	mov	dptr,#_del_key_from_report_PARM_2
      007D70 EF               [12] 1278 	mov	a,r7
      007D71 12 80 13         [24] 1279 	lcall	_ak820_outline_0058
      007D74 12 6E 66         [24] 1280 	lcall	_del_key_from_report
                                   1281 ;	quantum/action_util.c:142: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      007D77 75 82 01         [24] 1282 	mov	dpl, #0x01
      007D7A 22               [24] 1283 	ret
      007D7B                       1284 00107$:
                                   1285 ;	quantum/action_util.c:144: if (distinct_keys > KEYBOARD_REPORT_KEYS) return true;
      007D7B 90 0A 3A         [24] 1286 	mov	dptr,#_distinct_keys
      007D7E E0               [24] 1287 	movx	a,@dptr
      007D7F FF               [12] 1288 	mov  r7,a
      007D80 24 F9            [12] 1289 	add	a,#0xff - 0x06
      007D82 50 04            [24] 1290 	jnc	00110$
                                   1291 ;	free result
      007D84 75 82 01         [24] 1292 	mov	dpl, #0x01
      007D87 22               [24] 1293 	ret
      007D88                       1294 00110$:
                                   1295 ;	quantum/action_util.c:145: if (distinct_keys == KEYBOARD_REPORT_KEYS) {
      007D88 BF 06 26         [24] 1296 	cjne	r7,#0x06,00115$
                                   1297 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007D8B 90 0D C1         [24] 1298 	mov	dptr,#_actual_keyboard_report
      007D8E 75 F0 00         [24] 1299 	mov	b, #0x00
      007D91 12 6E A4         [24] 1300 	lcall	_clear_keys_from_report
                                   1301 ;	quantum/action_util.c:148: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      007D94 7F 04            [12] 1302 	mov	r7,#0x04
      007D96                       1303 00122$:
      007D96 EF               [12] 1304 	mov	a,r7
      007D97 24 5B            [12] 1305 	add	a,#0xff - 0xa4
      007D99 40 23            [24] 1306 	jc	00116$
                                   1307 ;	free result
      007D9B 12 80 05         [24] 1308 	lcall	_ak820_outline_0030
      007D9E 60 0E            [24] 1309 	jz	00123$
                                   1310 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      007DA0 90 08 00         [24] 1311 	mov	dptr,#_add_key_to_report_PARM_2
      007DA3 EF               [12] 1312 	mov	a,r7
      007DA4 12 80 13         [24] 1313 	lcall	_ak820_outline_0058
      007DA7 C0 07            [24] 1314 	push	ar7
      007DA9 12 6E 28         [24] 1315 	lcall	_add_key_to_report
      007DAC D0 07            [24] 1316 	pop	ar7
                                   1317 ;	quantum/action_util.c:148: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      007DAE                       1318 00123$:
      007DAE 0F               [12] 1319 	inc	r7
      007DAF 80 E5            [24] 1320 	sjmp	00122$
      007DB1                       1321 00115$:
                                   1322 ;	quantum/action_util.c:149: } else del_key(code);
      007DB1 90 0A 51         [24] 1323 	mov	dptr,#_del_owned_key_code_10000_341
      007DB4 E0               [24] 1324 	movx	a,@dptr
                                   1325 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      007DB5 90 08 04         [24] 1326 	mov	dptr,#_del_key_from_report_PARM_2
      007DB8 12 80 13         [24] 1327 	lcall	_ak820_outline_0058
      007DBB 12 6E 66         [24] 1328 	lcall	_del_key_from_report
                                   1329 ;	quantum/action_util.c:149: } else del_key(code);
      007DBE                       1330 00116$:
                                   1331 ;	quantum/action_util.c:150: return true;
      007DBE 75 82 01         [24] 1332 	mov	dpl, #0x01
                                   1333 ;	quantum/action_util.c:151: }
      007DC1 22               [24] 1334 	ret
                                   1335 ;------------------------------------------------------------
                                   1336 ;Allocation info for local variables in function 'clear_owned_usages'
                                   1337 ;------------------------------------------------------------
                                   1338 ;i             Allocated with name '_clear_owned_usages_i_20000_366'
                                   1339 ;i             Allocated with name '_clear_owned_usages_i_20000_367'
                                   1340 ;------------------------------------------------------------
                                   1341 ;	quantum/action_util.c:161: void clear_owned_usages(void) {
                                   1342 ;	-----------------------------------------
                                   1343 ;	 function clear_owned_usages
                                   1344 ;	-----------------------------------------
      007DC2                       1345 _clear_owned_usages:
                                   1346 ;	quantum/action_util.c:162: for (uint8_t i = 0; i < USAGE_COUNT; ++i) usage_refs[i] = usage_order[i] = 0;
      007DC2 7F 00            [12] 1347 	mov	r7,#0x00
      007DC4                       1348 00104$:
      007DC4 BF 1E 00         [24] 1349 	cjne	r7,#0x1e,00141$
      007DC7                       1350 00141$:
      007DC7 50 14            [24] 1351 	jnc	00101$
      007DC9 EF               [12] 1352 	mov	a,r7
      007DCA 24 52            [12] 1353 	add	a, #_usage_refs
      007DCC FD               [12] 1354 	mov	r5,a
      007DCD E4               [12] 1355 	clr	a
      007DCE 34 0A            [12] 1356 	addc	a, #(_usage_refs >> 8)
      007DD0 FE               [12] 1357 	mov	r6,a
      007DD1 EF               [12] 1358 	mov	a,r7
      007DD2 12 80 22         [24] 1359 	lcall	_ak820_outline_0068
      007DD5 E4               [12] 1360 	clr	a
      007DD6 F0               [24] 1361 	movx	@dptr,a
      007DD7 12 80 42         [24] 1362 	lcall	_ak820_outline_0123
      007DDA 0F               [12] 1363 	inc	r7
      007DDB 80 E7            [24] 1364 	sjmp	00104$
      007DDD                       1365 00101$:
                                   1366 ;	quantum/action_util.c:163: usage_lengths[0] = usage_lengths[1] = 0;
      007DDD 90 0A 8F         [24] 1367 	mov	dptr,#(_usage_lengths + 0x0001)
      007DE0 E4               [12] 1368 	clr	a
      007DE1 F0               [24] 1369 	movx	@dptr,a
      007DE2 90 0A 8E         [24] 1370 	mov	dptr,#_usage_lengths
      007DE5 F0               [24] 1371 	movx	@dptr,a
                                   1372 ;	quantum/action_util.c:164: for (uint8_t i = 0; i < sizeof(macro_usages); ++i) macro_usages[i] = 0;
      007DE6 FF               [12] 1373 	mov	r7,a
      007DE7                       1374 00107$:
      007DE7 BF 04 00         [24] 1375 	cjne	r7,#0x04,00143$
      007DEA                       1376 00143$:
      007DEA 50 0D            [24] 1377 	jnc	00109$
      007DEC EF               [12] 1378 	mov	a,r7
      007DED 24 90            [12] 1379 	add	a, #_macro_usages
      007DEF F5 82            [12] 1380 	mov	dpl,a
      007DF1 E4               [12] 1381 	clr	a
      007DF2 34 0A            [12] 1382 	addc	a, #(_macro_usages >> 8)
      007DF4 12 7A C3         [24] 1383 	lcall	_ak820_outline_0165
      007DF7 80 EE            [24] 1384 	sjmp	00107$
      007DF9                       1385 00109$:
                                   1386 ;	quantum/action_util.c:165: }
      007DF9 22               [24] 1387 	ret
                                   1388 ;------------------------------------------------------------
                                   1389 ;Allocation info for local variables in function 'owned_usage_key'
                                   1390 ;------------------------------------------------------------
                                   1391 ;pressed       Allocated with name '_owned_usage_key_PARM_2'
                                   1392 ;code          Allocated with name '_owned_usage_key_code_10000_368'
                                   1393 ;__200000085   Allocated with name '_owned_usage_key___200000085_20000_369'
                                   1394 ;which         Allocated with name '_owned_usage_key_which_10000_369'
                                   1395 ;base          Allocated with name '_owned_usage_key_base_10000_369'
                                   1396 ;count         Allocated with name '_owned_usage_key_count_10000_369'
                                   1397 ;index         Allocated with name '_owned_usage_key_index_10000_369'
                                   1398 ;pos           Allocated with name '_owned_usage_key_pos_30001_376'
                                   1399 ;i             Allocated with name '_owned_usage_key_i_40001_377'
                                   1400 ;__300000086   Allocated with name '_owned_usage_key___300000086_30000_380'
                                   1401 ;key           Allocated with name '_owned_usage_key_key_40000_381'
                                   1402 ;------------------------------------------------------------
                                   1403 ;	quantum/action_util.c:166: void owned_usage_key(uint8_t code, bool pressed) {
                                   1404 ;	-----------------------------------------
                                   1405 ;	 function owned_usage_key
                                   1406 ;	-----------------------------------------
      007DFA                       1407 _owned_usage_key:
      007DFA E5 82            [12] 1408 	mov	a,dpl
      007DFC 90 0A 95         [24] 1409 	mov	dptr,#_owned_usage_key_code_10000_368
      007DFF F0               [24] 1410 	movx	@dptr,a
                                   1411 ;	quantum/action_util.c:167: uint8_t which = code >= KC_AUDIO_MUTE;
      007E00 E0               [24] 1412 	movx	a,@dptr
      007E01 FF               [12] 1413 	mov	r7,a
      007E02 BF A8 00         [24] 1414 	cjne	r7,#0xa8,00244$
      007E05                       1415 00244$:
      007E05 B3               [12] 1416 	cpl	c
      007E06 92 22            [24] 1417 	mov	_owned_usage_key_sloc0_1_0,c
      007E08 E4               [12] 1418 	clr	a
      007E09 33               [12] 1419 	rlc	a
      007E0A FF               [12] 1420 	mov	r7,a
      007E0B 90 0A 98         [24] 1421 	mov	dptr,#_owned_usage_key_which_10000_369
      007E0E F0               [24] 1422 	movx	@dptr,a
                                   1423 ;	quantum/action_util.c:168: uint8_t base = which ? SYSTEM_COUNT : 0;
      007E0F EF               [12] 1424 	mov	a,r7
      007E10 60 02            [24] 1425 	jz	00129$
      007E12 74 03            [12] 1426 	mov	a,#0x03
      007E14                       1427 00129$:
      007E14 FE               [12] 1428 	mov	r6,a
                                   1429 ;	quantum/action_util.c:169: uint8_t count = usage_lengths[which];
      007E15 EF               [12] 1430 	mov	a,r7
      007E16 24 8E            [12] 1431 	add	a, #_usage_lengths
      007E18 FD               [12] 1432 	mov	r5,a
      007E19 E4               [12] 1433 	clr	a
      007E1A 34 0A            [12] 1434 	addc	a, #(_usage_lengths >> 8)
      007E1C FF               [12] 1435 	mov	r7,a
      007E1D 12 80 5E         [24] 1436 	lcall	_ak820_outline_0190
      007E20 E0               [24] 1437 	movx	a,@dptr
      007E21 FC               [12] 1438 	mov	r4,a
                                   1439 ;	quantum/action_util.c:170: uint8_t index = code - KC_SYSTEM_POWER;
      007E22 90 0A 95         [24] 1440 	mov	dptr,#_owned_usage_key_code_10000_368
      007E25 E0               [24] 1441 	movx	a,@dptr
      007E26 24 5B            [12] 1442 	add	a,#0x5b
      007E28 FB               [12] 1443 	mov	r3,a
                                   1444 ;	quantum/action_util.c:171: if (!ak820_macro_change(macro_usages, index, pressed)) return;
      007E29 90 0A 94         [24] 1445 	mov	dptr,#_owned_usage_key_PARM_2
      007E2C E0               [24] 1446 	movx	a,@dptr
      007E2D FA               [12] 1447 	mov	r2,a
      007E2E 90 09 89         [24] 1448 	mov	dptr,#_ak820_macro_change_PARM_2
      007E31 EB               [12] 1449 	mov	a,r3
      007E32 F0               [24] 1450 	movx	@dptr,a
      007E33 90 09 8A         [24] 1451 	mov	dptr,#_ak820_macro_change_PARM_3
      007E36 EA               [12] 1452 	mov	a,r2
      007E37 F0               [24] 1453 	movx	@dptr,a
      007E38 90 0A 90         [24] 1454 	mov	dptr,#_macro_usages
      007E3B C0 07            [24] 1455 	push	ar7
      007E3D C0 06            [24] 1456 	push	ar6
      007E3F C0 05            [24] 1457 	push	ar5
      007E41 C0 04            [24] 1458 	push	ar4
      007E43 C0 03            [24] 1459 	push	ar3
      007E45 C0 02            [24] 1460 	push	ar2
      007E47 12 7A D2         [24] 1461 	lcall	_ak820_macro_change
      007E4A E5 82            [12] 1462 	mov	a, dpl
      007E4C D0 02            [24] 1463 	pop	ar2
      007E4E D0 03            [24] 1464 	pop	ar3
      007E50 D0 04            [24] 1465 	pop	ar4
      007E52 D0 05            [24] 1466 	pop	ar5
      007E54 D0 06            [24] 1467 	pop	ar6
      007E56 D0 07            [24] 1468 	pop	ar7
      007E58 70 01            [24] 1469 	jnz	00102$
      007E5A 22               [24] 1470 	ret
      007E5B                       1471 00102$:
                                   1472 ;	quantum/action_util.c:172: if (pressed) {
      007E5B EA               [12] 1473 	mov	a,r2
      007E5C 60 1B            [24] 1474 	jz	00115$
                                   1475 ;	quantum/action_util.c:173: if (usage_refs[index]++) return;
      007E5E 12 80 2C         [24] 1476 	lcall	_ak820_outline_0075
      007E61 04               [12] 1477 	inc	a
      007E62 12 6B A7         [24] 1478 	lcall	_ak820_outline_0140
      007E65 E8               [12] 1479 	mov	a,r0
      007E66 60 01            [24] 1480 	jz	00104$
      007E68 22               [24] 1481 	ret
      007E69                       1482 00104$:
                                   1483 ;	quantum/action_util.c:174: usage_order[base + count++] = index;
      007E69 90 0A 99         [24] 1484 	mov	dptr,#_owned_usage_key_count_10000_369
      007E6C EC               [12] 1485 	mov	a,r4
      007E6D 04               [12] 1486 	inc	a
      007E6E F0               [24] 1487 	movx	@dptr,a
      007E6F EC               [12] 1488 	mov	a,r4
      007E70 2E               [12] 1489 	add	a, r6
      007E71 12 80 22         [24] 1490 	lcall	_ak820_outline_0068
      007E74 EB               [12] 1491 	mov	a,r3
      007E75 F0               [24] 1492 	movx	@dptr,a
      007E76 02 7E DA         [24] 1493 	ljmp	00116$
      007E79                       1494 00115$:
                                   1495 ;	quantum/action_util.c:176: if (!usage_refs[index] || --usage_refs[index]) return;
      007E79 12 80 2C         [24] 1496 	lcall	_ak820_outline_0075
      007E7C 60 07            [24] 1497 	jz	00105$
      007E7E 18               [12] 1498 	dec	r0
      007E7F 12 80 1B         [24] 1499 	lcall	_ak820_outline_0064
      007E82 E8               [12] 1500 	mov	a,r0
      007E83 60 01            [24] 1501 	jz	00106$
      007E85                       1502 00105$:
      007E85 22               [24] 1503 	ret
      007E86                       1504 00106$:
                                   1505 ;	quantum/action_util.c:178: while (usage_order[base + pos] != index) ++pos;
      007E86 7A 00            [12] 1506 	mov	r2,#0x00
      007E88                       1507 00108$:
      007E88 EA               [12] 1508 	mov	a,r2
      007E89 2E               [12] 1509 	add	a, r6
      007E8A 12 80 22         [24] 1510 	lcall	_ak820_outline_0068
      007E8D E0               [24] 1511 	movx	a,@dptr
      007E8E B5 03 02         [24] 1512 	cjne	a,ar3,00251$
      007E91 80 03            [24] 1513 	sjmp	00167$
      007E93                       1514 00251$:
      007E93 0A               [12] 1515 	inc	r2
      007E94 80 F2            [24] 1516 	sjmp	00108$
      007E96                       1517 00167$:
      007E96 90 0A 9A         [24] 1518 	mov	dptr,#_owned_usage_key_pos_30001_376
      007E99 EA               [12] 1519 	mov	a,r2
      007E9A F0               [24] 1520 	movx	@dptr,a
                                   1521 ;	quantum/action_util.c:179: --count;
      007E9B 1C               [12] 1522 	dec	r4
      007E9C 90 0A 99         [24] 1523 	mov	dptr,#_owned_usage_key_count_10000_369
      007E9F EC               [12] 1524 	mov	a,r4
      007EA0 F0               [24] 1525 	movx	@dptr,a
                                   1526 ;	quantum/action_util.c:180: for (uint8_t i = pos; i < count; ++i) usage_order[base + i] = usage_order[base + i + 1];
      007EA1 8A 03            [24] 1527 	mov	ar3,r2
      007EA3                       1528 00125$:
      007EA3 C3               [12] 1529 	clr	c
      007EA4 EB               [12] 1530 	mov	a,r3
      007EA5 9C               [12] 1531 	subb	a,r4
      007EA6 50 23            [24] 1532 	jnc	00111$
      007EA8 C0 05            [24] 1533 	push	ar5
      007EAA C0 07            [24] 1534 	push	ar7
      007EAC EB               [12] 1535 	mov	a,r3
      007EAD 2E               [12] 1536 	add	a, r6
      007EAE FA               [12] 1537 	mov	r2,a
      007EAF 24 70            [12] 1538 	add	a, #_usage_order
      007EB1 F8               [12] 1539 	mov	r0,a
      007EB2 E4               [12] 1540 	clr	a
      007EB3 34 0A            [12] 1541 	addc	a, #(_usage_order >> 8)
      007EB5 F9               [12] 1542 	mov	r1,a
      007EB6 0A               [12] 1543 	inc	r2
      007EB7 EA               [12] 1544 	mov	a,r2
      007EB8 33               [12] 1545 	rlc	a
      007EB9 95 E0            [12] 1546 	subb	a,acc
      007EBB FF               [12] 1547 	mov	r7,a
      007EBC EA               [12] 1548 	mov	a,r2
      007EBD 12 80 48         [24] 1549 	lcall	_ak820_outline_0126
      007EC0 12 38 B1         [24] 1550 	lcall	_ak820_outline_0145
      007EC3 F0               [24] 1551 	movx	@dptr,a
      007EC4 0B               [12] 1552 	inc	r3
      007EC5 D0 07            [24] 1553 	pop	ar7
      007EC7 D0 05            [24] 1554 	pop	ar5
      007EC9 80 D8            [24] 1555 	sjmp	00125$
      007ECB                       1556 00111$:
                                   1557 ;	quantum/action_util.c:181: usage_lengths[which] = count;
      007ECB 12 80 5E         [24] 1558 	lcall	_ak820_outline_0190
      007ECE EC               [12] 1559 	mov	a,r4
      007ECF F0               [24] 1560 	movx	@dptr,a
                                   1561 ;	quantum/action_util.c:182: if (pos != count) return; /* A non-winning owner changed only storage. */
      007ED0 90 0A 9A         [24] 1562 	mov	dptr,#_owned_usage_key_pos_30001_376
      007ED3 E0               [24] 1563 	movx	a,@dptr
      007ED4 B5 04 02         [24] 1564 	cjne	a,ar4,00253$
      007ED7 80 01            [24] 1565 	sjmp	00116$
      007ED9                       1566 00253$:
      007ED9 22               [24] 1567 	ret
      007EDA                       1568 00116$:
                                   1569 ;	quantum/action_util.c:184: usage_lengths[which] = count;
      007EDA 90 0A 99         [24] 1570 	mov	dptr,#_owned_usage_key_count_10000_369
      007EDD E0               [24] 1571 	movx	a,@dptr
      007EDE FC               [12] 1572 	mov	r4,a
      007EDF 12 80 5E         [24] 1573 	lcall	_ak820_outline_0190
      007EE2 F0               [24] 1574 	movx	@dptr,a
                                   1575 ;	quantum/action_util.c:185: code = count ? usage_order[base + count - 1] + KC_SYSTEM_POWER : 0;
      007EE3 EC               [12] 1576 	mov	a,r4
      007EE4 60 15            [24] 1577 	jz	00131$
      007EE6 EC               [12] 1578 	mov	a,r4
      007EE7 2E               [12] 1579 	add	a, r6
      007EE8 FE               [12] 1580 	mov	r6,a
      007EE9 1E               [12] 1581 	dec	r6
      007EEA EE               [12] 1582 	mov	a,r6
      007EEB 33               [12] 1583 	rlc	a
      007EEC 95 E0            [12] 1584 	subb	a,acc
      007EEE FF               [12] 1585 	mov	r7,a
      007EEF EE               [12] 1586 	mov	a,r6
      007EF0 12 80 48         [24] 1587 	lcall	_ak820_outline_0126
      007EF3 24 A5            [12] 1588 	add	a,#0xa5
      007EF5 FE               [12] 1589 	mov	r6,a
      007EF6 33               [12] 1590 	rlc	a
      007EF7 95 E0            [12] 1591 	subb	a,acc
      007EF9 80 02            [24] 1592 	sjmp	00132$
      007EFB                       1593 00131$:
      007EFB 7E 00            [12] 1594 	mov	r6,#0x00
      007EFD                       1595 00132$:
      007EFD 90 0A 95         [24] 1596 	mov	dptr,#_owned_usage_key_code_10000_368
      007F00 EE               [12] 1597 	mov	a,r6
      007F01 F0               [24] 1598 	movx	@dptr,a
                                   1599 ;	quantum/action_util.c:186: if (which) host_consumer_send(code ? KEYCODE2CONSUMER(code) : 0);
      007F02 90 0A 98         [24] 1600 	mov	dptr,#_owned_usage_key_which_10000_369
      007F05 E0               [24] 1601 	movx	a,@dptr
      007F06 60 18            [24] 1602 	jz	00118$
      007F08 EE               [12] 1603 	mov	a,r6
      007F09 60 0B            [24] 1604 	jz	00133$
      007F0B 8E 82            [24] 1605 	mov	dpl, r6
      007F0D 12 6C E7         [24] 1606 	lcall	_KEYCODE2CONSUMER
      007F10 AD 82            [24] 1607 	mov	r5, dpl
      007F12 AF 83            [24] 1608 	mov	r7, dph
      007F14 80 04            [24] 1609 	sjmp	00134$
      007F16                       1610 00133$:
      007F16 7D 00            [12] 1611 	mov	r5,#0x00
      007F18 7F 00            [12] 1612 	mov	r7,#0x00
      007F1A                       1613 00134$:
      007F1A 12 80 5E         [24] 1614 	lcall	_ak820_outline_0190
      007F1D 02 6C 9A         [24] 1615 	ljmp	_host_consumer_send
      007F20                       1616 00118$:
                                   1617 ;	quantum/action_util.c:187: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      007F20 EE               [12] 1618 	mov	a,r6
      007F21 60 22            [24] 1619 	jz	00135$
                                   1620 ;	tmk_core/protocol/report.h:264: if (key < KC_SYSTEM_POWER || key > KC_SYSTEM_WAKE) return 0;
      007F23 BE A5 00         [24] 1621 	cjne	r6,#0xa5,00258$
      007F26                       1622 00258$:
      007F26 40 05            [24] 1623 	jc	00121$
      007F28 EE               [12] 1624 	mov	a,r6
      007F29 24 58            [12] 1625 	add	a,#0xff - 0xa7
      007F2B 50 08            [24] 1626 	jnc	00122$
                                   1627 ;	free result
      007F2D                       1628 00121$:
      007F2D 90 0A 96         [24] 1629 	mov	dptr,#_owned_usage_key___200000085_20000_369
      007F30 12 4E C3         [24] 1630 	lcall	_ak820_outline_0184
      007F33 80 09            [24] 1631 	sjmp	00123$
      007F35                       1632 00122$:
                                   1633 ;	tmk_core/protocol/report.h:265: return SYSTEM_POWER_DOWN + (key - KC_SYSTEM_POWER);
      007F35 74 DC            [12] 1634 	mov	a,#0xdc
      007F37 2E               [12] 1635 	add	a, r6
      007F38 90 0A 96         [24] 1636 	mov	dptr,#_owned_usage_key___200000085_20000_369
      007F3B 12 38 9C         [24] 1637 	lcall	_ak820_outline_0135
                                   1638 ;	quantum/action_util.c:187: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      007F3E                       1639 00123$:
      007F3E 90 0A 96         [24] 1640 	mov	dptr,#_owned_usage_key___200000085_20000_369
      007F41 E0               [24] 1641 	movx	a,@dptr
      007F42 FF               [12] 1642 	mov	r7,a
      007F43 80 02            [24] 1643 	sjmp	00136$
      007F45                       1644 00135$:
      007F45 7F 00            [12] 1645 	mov	r7,#0x00
      007F47                       1646 00136$:
      007F47 7E 00            [12] 1647 	mov	r6,#0x00
      007F49 12 43 77         [24] 1648 	lcall	_ak820_outline_0160
                                   1649 ;	quantum/action_util.c:188: }
      007F4C 02 6C 6A         [24] 1650 	ljmp	_host_system_send
                                   1651 ;------------------------------------------------------------
                                   1652 ;Allocation info for local variables in function 'send_keyboard_report'
                                   1653 ;------------------------------------------------------------
                                   1654 ;last_report   Allocated with name '_send_keyboard_report_last_report_10001_388'
                                   1655 ;changed       Allocated with name '_send_keyboard_report_changed_10001_388'
                                   1656 ;dest          Allocated with name '_send_keyboard_report_dest_10001_388'
                                   1657 ;src           Allocated with name '_send_keyboard_report_src_10001_388'
                                   1658 ;i             Allocated with name '_send_keyboard_report_i_20001_389'
                                   1659 ;------------------------------------------------------------
                                   1660 ;	quantum/action_util.c:410: void send_keyboard_report(void) {
                                   1661 ;	-----------------------------------------
                                   1662 ;	 function send_keyboard_report
                                   1663 ;	-----------------------------------------
      007F4F                       1664 _send_keyboard_report:
                                   1665 ;	quantum/action_util.c:411: keyboard_report->mods = real_mods;
      007F4F 90 0D BF         [24] 1666 	mov	dptr,#_real_mods
      007F52 E0               [24] 1667 	movx	a,@dptr
      007F53 FF               [12] 1668 	mov	r7,a
      007F54 90 0D C1         [24] 1669 	mov	dptr,#_actual_keyboard_report
      007F57 F0               [24] 1670 	movx	@dptr,a
                                   1671 ;	quantum/action_util.c:412: keyboard_report->mods |= weak_mods;
      007F58 90 0D C0         [24] 1672 	mov	dptr,#_weak_mods
      007F5B E0               [24] 1673 	movx	a,@dptr
      007F5C 42 07            [12] 1674 	orl	ar7,a
      007F5E 90 0D C1         [24] 1675 	mov	dptr,#_actual_keyboard_report
      007F61 EF               [12] 1676 	mov	a,r7
      007F62 F0               [24] 1677 	movx	@dptr,a
                                   1678 ;	quantum/action_util.c:414: keyboard_report->mods |= owned_mods | owned_weak_mods;
      007F63 90 09 84         [24] 1679 	mov	dptr,#_owned_weak_mods
      007F66 E0               [24] 1680 	movx	a,@dptr
      007F67 FE               [12] 1681 	mov	r6,a
      007F68 90 09 83         [24] 1682 	mov	dptr,#_owned_mods
      007F6B E0               [24] 1683 	movx	a,@dptr
      007F6C 4E               [12] 1684 	orl	a,r6
      007F6D 42 07            [12] 1685 	orl	ar7,a
      007F6F 90 0D C1         [24] 1686 	mov	dptr,#_actual_keyboard_report
      007F72 EF               [12] 1687 	mov	a,r7
      007F73 F0               [24] 1688 	movx	@dptr,a
                                   1689 ;	quantum/action_util.c:455: bool changed = false;
      007F74 90 0A BC         [24] 1690 	mov	dptr,#_send_keyboard_report_changed_10001_388
      007F77 E4               [12] 1691 	clr	a
      007F78 F0               [24] 1692 	movx	@dptr,a
                                   1693 ;	quantum/action_util.c:457: uint8_t __xdata *dest = (uint8_t __xdata *)&last_report;
                                   1694 ;	quantum/action_util.c:458: const uint8_t __xdata *src = (const uint8_t __xdata *)keyboard_report;
                                   1695 ;	quantum/action_util.c:463: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      007F79 FF               [12] 1696 	mov	r7,a
      007F7A                       1697 00107$:
      007F7A BF 20 00         [24] 1698 	cjne	r7,#0x20,00140$
      007F7D                       1699 00140$:
      007F7D 50 2B            [24] 1700 	jnc	00103$
                                   1701 ;	quantum/action_util.c:464: if (dest[i] != src[i]) {
      007F7F EF               [12] 1702 	mov	a,r7
      007F80 24 9C            [12] 1703 	add	a, #_send_keyboard_report_last_report_10001_388
      007F82 FD               [12] 1704 	mov	r5,a
      007F83 E4               [12] 1705 	clr	a
      007F84 34 0A            [12] 1706 	addc	a, #(_send_keyboard_report_last_report_10001_388 >> 8)
      007F86 FE               [12] 1707 	mov	r6,a
      007F87 12 48 1D         [24] 1708 	lcall	_ak820_outline_0076
      007F8A EF               [12] 1709 	mov	a,r7
      007F8B 24 C1            [12] 1710 	add	a, #_actual_keyboard_report
      007F8D F5 82            [12] 1711 	mov	dpl,a
      007F8F E4               [12] 1712 	clr	a
      007F90 34 0D            [12] 1713 	addc	a, #(_actual_keyboard_report >> 8)
      007F92 F5 83            [12] 1714 	mov	dph,a
      007F94 E0               [24] 1715 	movx	a,@dptr
      007F95 FB               [12] 1716 	mov	r3,a
      007F96 EC               [12] 1717 	mov	a,r4
      007F97 B5 03 02         [24] 1718 	cjne	a,ar3,00142$
      007F9A 80 0B            [24] 1719 	sjmp	00108$
      007F9C                       1720 00142$:
                                   1721 ;	quantum/action_util.c:465: dest[i] = src[i];
      007F9C 12 38 A1         [24] 1722 	lcall	_ak820_outline_0136
      007F9F EB               [12] 1723 	mov	a,r3
      007FA0 F0               [24] 1724 	movx	@dptr,a
                                   1725 ;	quantum/action_util.c:466: changed = true;
      007FA1 90 0A BC         [24] 1726 	mov	dptr,#_send_keyboard_report_changed_10001_388
      007FA4 74 01            [12] 1727 	mov	a,#0x01
      007FA6 F0               [24] 1728 	movx	@dptr,a
      007FA7                       1729 00108$:
                                   1730 ;	quantum/action_util.c:463: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      007FA7 0F               [12] 1731 	inc	r7
      007FA8 80 D0            [24] 1732 	sjmp	00107$
      007FAA                       1733 00103$:
                                   1734 ;	quantum/action_util.c:469: if (changed) host_keyboard_send(keyboard_report);
      007FAA 90 0A BC         [24] 1735 	mov	dptr,#_send_keyboard_report_changed_10001_388
      007FAD E0               [24] 1736 	movx	a,@dptr
      007FAE 60 09            [24] 1737 	jz	00109$
      007FB0 90 0D C1         [24] 1738 	mov	dptr,#_actual_keyboard_report
      007FB3 75 F0 00         [24] 1739 	mov	b, #0x00
                                   1740 ;	quantum/action_util.c:477: }
      007FB6 02 6B DF         [24] 1741 	ljmp	_host_keyboard_send
      007FB9                       1742 00109$:
      007FB9 22               [24] 1743 	ret
                                   1744 ;------------------------------------------------------------
                                   1745 ;Allocation info for local variables in function 'get_mods'
                                   1746 ;------------------------------------------------------------
                                   1747 ;	quantum/action_util.c:483: uint8_t get_mods(void) {
                                   1748 ;	-----------------------------------------
                                   1749 ;	 function get_mods
                                   1750 ;	-----------------------------------------
      007FBA                       1751 _get_mods:
      007FBA C0 07            [24] 1752 	push	ar7
                                   1753 ;	quantum/action_util.c:488: ;
      007FBC 90 09 83         [24] 1754 	mov	dptr,#_owned_mods
      007FBF E0               [24] 1755 	movx	a,@dptr
      007FC0 FF               [12] 1756 	mov	r7,a
      007FC1 90 0D BF         [24] 1757 	mov	dptr,#_real_mods
      007FC4 12 7A BD         [24] 1758 	lcall	_ak820_outline_0142
                                   1759 ;	quantum/action_util.c:489: }
      007FC7 D0 07            [24] 1760 	pop	ar7
      007FC9 22               [24] 1761 	ret
                                   1762 ;------------------------------------------------------------
                                   1763 ;Allocation info for local variables in function 'add_mods'
                                   1764 ;------------------------------------------------------------
                                   1765 ;mods          Allocated with name '_add_mods_mods_10000_396'
                                   1766 ;------------------------------------------------------------
                                   1767 ;	quantum/action_util.c:494: void add_mods(uint8_t mods) {
                                   1768 ;	-----------------------------------------
                                   1769 ;	 function clear_mods
                                   1770 ;	-----------------------------------------
      007FCA                       1771 _clear_mods:
                                   1772 ;	quantum/action_util.c:516: real_mods = 0;
      007FCA 90 0D BF         [24] 1773 	mov	dptr,#_real_mods
      007FCD E4               [12] 1774 	clr	a
      007FCE F0               [24] 1775 	movx	@dptr,a
                                   1776 ;	quantum/action_util.c:517: }
      007FCF 22               [24] 1777 	ret
                                   1778 ;------------------------------------------------------------
                                   1779 ;Allocation info for local variables in function 'get_weak_mods'
                                   1780 ;------------------------------------------------------------
                                   1781 ;	quantum/action_util.c:523: uint8_t get_weak_mods(void) {
                                   1782 ;	-----------------------------------------
                                   1783 ;	 function get_weak_mods
                                   1784 ;	-----------------------------------------
      007FD0                       1785 _get_weak_mods:
      007FD0 C0 07            [24] 1786 	push	ar7
                                   1787 ;	quantum/action_util.c:528: ;
      007FD2 90 09 84         [24] 1788 	mov	dptr,#_owned_weak_mods
      007FD5 E0               [24] 1789 	movx	a,@dptr
      007FD6 FF               [12] 1790 	mov	r7,a
      007FD7 90 0D C0         [24] 1791 	mov	dptr,#_weak_mods
      007FDA 12 7A BD         [24] 1792 	lcall	_ak820_outline_0142
                                   1793 ;	quantum/action_util.c:529: }
      007FDD D0 07            [24] 1794 	pop	ar7
      007FDF 22               [24] 1795 	ret
                                   1796 ;------------------------------------------------------------
                                   1797 ;Allocation info for local variables in function 'add_weak_mods'
                                   1798 ;------------------------------------------------------------
                                   1799 ;mods          Allocated with name '_add_weak_mods_mods_10000_406'
                                   1800 ;------------------------------------------------------------
                                   1801 ;	quantum/action_util.c:534: void add_weak_mods(uint8_t mods) {
                                   1802 ;	-----------------------------------------
                                   1803 ;	 function add_weak_mods
                                   1804 ;	-----------------------------------------
      007FE0                       1805 _add_weak_mods:
      007FE0 E5 82            [12] 1806 	mov	a,dpl
      007FE2 90 0A BD         [24] 1807 	mov	dptr,#_add_weak_mods_mods_10000_406
      007FE5 F0               [24] 1808 	movx	@dptr,a
                                   1809 ;	quantum/action_util.c:535: weak_mods |= mods;
      007FE6 E0               [24] 1810 	movx	a,@dptr
      007FE7 FF               [12] 1811 	mov	r7,a
      007FE8 90 0D C0         [24] 1812 	mov	dptr,#_weak_mods
      007FEB E0               [24] 1813 	movx	a,@dptr
      007FEC 4F               [12] 1814 	orl	a,r7
      007FED F0               [24] 1815 	movx	@dptr,a
                                   1816 ;	quantum/action_util.c:536: }
      007FEE 22               [24] 1817 	ret
                                   1818 ;------------------------------------------------------------
                                   1819 ;Allocation info for local variables in function 'del_weak_mods'
                                   1820 ;------------------------------------------------------------
                                   1821 ;mods          Allocated with name '_del_weak_mods_mods_10000_408'
                                   1822 ;------------------------------------------------------------
                                   1823 ;	quantum/action_util.c:541: void del_weak_mods(uint8_t mods) {
                                   1824 ;	-----------------------------------------
                                   1825 ;	 function del_weak_mods
                                   1826 ;	-----------------------------------------
      007FEF                       1827 _del_weak_mods:
      007FEF E5 82            [12] 1828 	mov	a,dpl
      007FF1 90 0A BE         [24] 1829 	mov	dptr,#_del_weak_mods_mods_10000_408
      007FF4 F0               [24] 1830 	movx	@dptr,a
                                   1831 ;	quantum/action_util.c:542: weak_mods &= ~mods;
      007FF5 E0               [24] 1832 	movx	a,@dptr
      007FF6 F4               [12] 1833 	cpl	a
      007FF7 FF               [12] 1834 	mov	r7,a
      007FF8 90 0D C0         [24] 1835 	mov	dptr,#_weak_mods
      007FFB E0               [24] 1836 	movx	a,@dptr
      007FFC 5F               [12] 1837 	anl	a,r7
      007FFD F0               [24] 1838 	movx	@dptr,a
                                   1839 ;	quantum/action_util.c:543: }
      007FFE 22               [24] 1840 	ret
                                   1841 ;------------------------------------------------------------
                                   1842 ;Allocation info for local variables in function 'set_weak_mods'
                                   1843 ;------------------------------------------------------------
                                   1844 ;mods          Allocated with name '_set_weak_mods_mods_10000_410'
                                   1845 ;------------------------------------------------------------
                                   1846 ;	quantum/action_util.c:548: void set_weak_mods(uint8_t mods) {
                                   1847 ;	-----------------------------------------
                                   1848 ;	 function clear_weak_mods
                                   1849 ;	-----------------------------------------
      007FFF                       1850 _clear_weak_mods:
                                   1851 ;	quantum/action_util.c:556: weak_mods = 0;
      007FFF 90 0D C0         [24] 1852 	mov	dptr,#_weak_mods
      008002 E4               [12] 1853 	clr	a
      008003 F0               [24] 1854 	movx	@dptr,a
                                   1855 ;	quantum/action_util.c:557: }
      008004 22               [24] 1856 	ret
                                   1857 ;------------------------------------------------------------
                                   1858 ;Allocation info for local variables in function 'oneshot_locked_mods_changed_user'
                                   1859 ;------------------------------------------------------------
                                   1860 ;mods          Allocated with name '_oneshot_locked_mods_changed_user_mods_10000_414'
                                   1861 ;------------------------------------------------------------
                                   1862 ;	quantum/action_util.c:639: __attribute__((weak)) void oneshot_locked_mods_changed_user(uint8_t mods) {}
                                   1863 ;	-----------------------------------------
                                   1864 	.area CSEG    (CODE)
                                   1865 	.area CONST   (CODE)
                                   1866 	.area XINIT   (CODE)
      00BF82                       1867 __xinit__real_mods:
      00BF82 00                    1868 	.db #0x00	; 0
      00BF83                       1869 __xinit__weak_mods:
      00BF83 00                    1870 	.db #0x00	; 0
      00BF84                       1871 __xinit__actual_keyboard_report:
      00BF84 00                    1872 	.db #0x00	; 0
      00BF85 00                    1873 	.db #0x00	; 0
      00BF86 00                    1874 	.db #0x00	; 0
      00BF87 00                    1875 	.db #0x00	; 0
      00BF88 00                    1876 	.db #0x00	; 0
      00BF89 00                    1877 	.db #0x00	; 0
      00BF8A 00                    1878 	.db #0x00	; 0
      00BF8B 00                    1879 	.db #0x00	; 0
      00BF8C 00                    1880 	.db 0x00
      00BF8D 00                    1881 	.db 0x00
      00BF8E 00                    1882 	.db 0x00
      00BF8F 00                    1883 	.db 0x00
      00BF90 00                    1884 	.db 0x00
      00BF91 00                    1885 	.db 0x00
      00BF92 00                    1886 	.db 0x00
      00BF93 00                    1887 	.db 0x00
      00BF94 00                    1888 	.db 0x00
      00BF95 00                    1889 	.db 0x00
      00BF96 00                    1890 	.db 0x00
      00BF97 00                    1891 	.db 0x00
      00BF98 00                    1892 	.db 0x00
      00BF99 00                    1893 	.db 0x00
      00BF9A 00                    1894 	.db 0x00
      00BF9B 00                    1895 	.db 0x00
      00BF9C 00                    1896 	.db 0x00
      00BF9D 00                    1897 	.db 0x00
      00BF9E 00                    1898 	.db 0x00
      00BF9F 00                    1899 	.db 0x00
      00BFA0 00                    1900 	.db 0x00
      00BFA1 00                    1901 	.db 0x00
      00BFA2 00                    1902 	.db 0x00
      00BFA3 00                    1903 	.db 0x00
                                   1904 	.area CABS    (ABS,CODE)
                                   1905 
                                   1906 ; Experimental exact instruction outlining.
                                   1907 	.globl _ak820_outline_0016
                                   1908 	.globl _ak820_outline_0030
                                   1909 	.globl _ak820_outline_0056
                                   1910 	.globl _ak820_outline_0058
                                   1911 	.globl _ak820_outline_0061
                                   1912 	.globl _ak820_outline_0063
                                   1913 	.globl _ak820_outline_0064
                                   1914 	.globl _ak820_outline_0065
                                   1915 	.globl _ak820_outline_0068
                                   1916 	.globl _ak820_outline_0075
                                   1917 	.globl _ak820_outline_0076
                                   1918 	.globl _ak820_outline_0109
                                   1919 	.globl _ak820_outline_0117
                                   1920 	.globl _ak820_outline_0118
                                   1921 	.globl _ak820_outline_0123
                                   1922 	.globl _ak820_outline_0124
                                   1923 	.globl _ak820_outline_0126
                                   1924 	.globl _ak820_outline_0133
                                   1925 	.globl _ak820_outline_0135
                                   1926 	.globl _ak820_outline_0136
                                   1927 	.globl _ak820_outline_0140
                                   1928 	.globl _ak820_outline_0142
                                   1929 	.globl _ak820_outline_0145
                                   1930 	.globl _ak820_outline_0160
                                   1931 	.globl _ak820_outline_0165
                                   1932 	.globl _ak820_outline_0184
                                   1933 	.globl _ak820_outline_0189
                                   1934 	.globl _ak820_outline_0190
                                   1935 
                                   1936 	.area CSEG (CODE)
                                   1937 ; function ak820_outline_0030
      008005                       1938 _ak820_outline_0030:
      008005 EF               [12] 1939 	mov	a,r7
      008006 24 95            [12] 1940 	add	a,#_key_refs
      008008 FD               [12] 1941 	mov	r5,a
      008009 E4               [12] 1942 	clr	a
      00800A 34 09            [12] 1943 	addc	a,#(_key_refs>>8)
      00800C FE               [12] 1944 	mov	r6,a
      00800D 8D 82            [24] 1945 	mov	dpl,r5
      00800F 8E 83            [24] 1946 	mov	dph,r6
      008011 E0               [24] 1947 	movx	a,@dptr
      008012 22               [24] 1948 	ret
                                   1949 
                                   1950 	.area CSEG (CODE)
                                   1951 ; function ak820_outline_0058
      008013                       1952 _ak820_outline_0058:
      008013 F0               [24] 1953 	movx	@dptr,a
      008014 90 0D C1         [24] 1954 	mov	dptr,#_actual_keyboard_report
      008017 75 F0 00         [24] 1955 	mov	b,#0x00
      00801A 22               [24] 1956 	ret
                                   1957 
                                   1958 	.area CSEG (CODE)
                                   1959 ; function ak820_outline_0064
      00801B                       1960 _ak820_outline_0064:
      00801B 89 82            [24] 1961 	mov	dpl,r1
      00801D 8A 83            [24] 1962 	mov	dph,r2
      00801F E8               [12] 1963 	mov	a,r0
      008020 F0               [24] 1964 	movx	@dptr,a
      008021 22               [24] 1965 	ret
                                   1966 
                                   1967 	.area CSEG (CODE)
                                   1968 ; function ak820_outline_0068
      008022                       1969 _ak820_outline_0068:
      008022 24 70            [12] 1970 	add	a,#_usage_order
      008024 F5 82            [12] 1971 	mov	dpl,a
      008026 E4               [12] 1972 	clr	a
      008027 34 0A            [12] 1973 	addc	a,#(_usage_order>>8)
      008029 F5 83            [12] 1974 	mov	dph,a
      00802B 22               [24] 1975 	ret
                                   1976 
                                   1977 	.area CSEG (CODE)
                                   1978 ; function ak820_outline_0075
      00802C                       1979 _ak820_outline_0075:
      00802C EB               [12] 1980 	mov	a,r3
      00802D 24 52            [12] 1981 	add	a,#_usage_refs
      00802F F9               [12] 1982 	mov	r1,a
      008030 E4               [12] 1983 	clr	a
      008031 34 0A            [12] 1984 	addc	a,#(_usage_refs>>8)
      008033 FA               [12] 1985 	mov	r2,a
      008034 89 82            [24] 1986 	mov	dpl,r1
      008036 8A 83            [24] 1987 	mov	dph,r2
      008038 E0               [24] 1988 	movx	a,@dptr
      008039 F8               [12] 1989 	mov	r0,a
      00803A 22               [24] 1990 	ret
                                   1991 
                                   1992 	.area CSEG (CODE)
                                   1993 ; function ak820_outline_0117
      00803B                       1994 _ak820_outline_0117:
      00803B F0               [24] 1995 	movx	@dptr,a
      00803C E0               [24] 1996 	movx	a,@dptr
      00803D FF               [12] 1997 	mov	r7,a
      00803E 90 09 8D         [24] 1998 	mov	dptr,#_change_owned_PARM_2
      008041 22               [24] 1999 	ret
                                   2000 
                                   2001 	.area CSEG (CODE)
                                   2002 ; function ak820_outline_0123
      008042                       2003 _ak820_outline_0123:
      008042 8D 82            [24] 2004 	mov	dpl,r5
      008044 8E 83            [24] 2005 	mov	dph,r6
      008046 F0               [24] 2006 	movx	@dptr,a
      008047 22               [24] 2007 	ret
                                   2008 
                                   2009 	.area CSEG (CODE)
                                   2010 ; function ak820_outline_0126
      008048                       2011 _ak820_outline_0126:
      008048 24 70            [12] 2012 	add	a,#_usage_order
      00804A F5 82            [12] 2013 	mov	dpl,a
      00804C EF               [12] 2014 	mov	a,r7
      00804D 34 0A            [12] 2015 	addc	a,#(_usage_order>>8)
      00804F F5 83            [12] 2016 	mov	dph,a
      008051 E0               [24] 2017 	movx	a,@dptr
      008052 22               [24] 2018 	ret
                                   2019 
                                   2020 	.area CSEG (CODE)
                                   2021 ; function ak820_outline_0133
      008053                       2022 _ak820_outline_0133:
      008053 F0               [24] 2023 	movx	@dptr,a
      008054 E0               [24] 2024 	movx	a,@dptr
      008055 FF               [12] 2025 	mov	r7,a
      008056 90 09 89         [24] 2026 	mov	dptr,#_ak820_macro_change_PARM_2
      008059 F0               [24] 2027 	movx	@dptr,a
      00805A 90 09 8A         [24] 2028 	mov	dptr,#_ak820_macro_change_PARM_3
      00805D 22               [24] 2029 	ret
                                   2030 
                                   2031 	.area CSEG (CODE)
                                   2032 ; function ak820_outline_0190
      00805E                       2033 _ak820_outline_0190:
      00805E 8D 82            [24] 2034 	mov	dpl,r5
      008060 8F 83            [24] 2035 	mov	dph,r7
      008062 22               [24] 2036 	ret
