                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action_util
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _host_consumer_send
                                     12 	.globl _host_system_send
                                     13 	.globl _host_keyboard_send
                                     14 	.globl _clear_keys_from_report
                                     15 	.globl _del_key_from_report
                                     16 	.globl _add_key_to_report
                                     17 	.globl _KEYCODE2CONSUMER
                                     18 	.globl _ADC_START
                                     19 	.globl _S0_R_FIFO
                                     20 	.globl _S0_T_FIFO
                                     21 	.globl _S0_FREE
                                     22 	.globl _S0_IF_BYTE
                                     23 	.globl _S0_IF_FIRST
                                     24 	.globl _S0_IF_OV
                                     25 	.globl _S0_FST_ACT
                                     26 	.globl _CP_RL2
                                     27 	.globl _C_T2
                                     28 	.globl _TR2
                                     29 	.globl _EXEN2
                                     30 	.globl _TCLK
                                     31 	.globl _RCLK
                                     32 	.globl _EXF2
                                     33 	.globl _CAP1F
                                     34 	.globl _TF2
                                     35 	.globl _RI
                                     36 	.globl _TI
                                     37 	.globl _RB8
                                     38 	.globl _TB8
                                     39 	.globl _REN
                                     40 	.globl _SM2
                                     41 	.globl _SM1
                                     42 	.globl _SM0
                                     43 	.globl _IT0
                                     44 	.globl _IE0
                                     45 	.globl _IT1
                                     46 	.globl _IE1
                                     47 	.globl _TR0
                                     48 	.globl _TF0
                                     49 	.globl _TR1
                                     50 	.globl _TF1
                                     51 	.globl _P4_0
                                     52 	.globl _P4_1
                                     53 	.globl _P4_2
                                     54 	.globl _P4_3
                                     55 	.globl _P4_4
                                     56 	.globl _P4_5
                                     57 	.globl _P4_6
                                     58 	.globl _RXD
                                     59 	.globl _TXD
                                     60 	.globl _INT0
                                     61 	.globl _INT1
                                     62 	.globl _T0
                                     63 	.globl _T1
                                     64 	.globl _MOSI1
                                     65 	.globl _MISO1
                                     66 	.globl _SCK1
                                     67 	.globl _P3_0
                                     68 	.globl _P3_1
                                     69 	.globl _P3_2
                                     70 	.globl _P3_3
                                     71 	.globl _P3_4
                                     72 	.globl _P3_5
                                     73 	.globl _P3_6
                                     74 	.globl _P3_7
                                     75 	.globl _CAP1_
                                     76 	.globl _T2_
                                     77 	.globl _CAP2_
                                     78 	.globl _T2EX_
                                     79 	.globl _RXD1
                                     80 	.globl _TXD1
                                     81 	.globl _P2_0
                                     82 	.globl _P2_1
                                     83 	.globl _P2_2
                                     84 	.globl _P2_3
                                     85 	.globl _P2_4
                                     86 	.globl _P2_5
                                     87 	.globl _P2_6
                                     88 	.globl _P2_7
                                     89 	.globl _AIN0
                                     90 	.globl _AIN1
                                     91 	.globl _AIN2
                                     92 	.globl _AIN3
                                     93 	.globl _AIN4
                                     94 	.globl _AIN5
                                     95 	.globl _AIN6
                                     96 	.globl _AIN7
                                     97 	.globl _CAP1
                                     98 	.globl _T2
                                     99 	.globl _CAP2
                                    100 	.globl _T2EX
                                    101 	.globl _INT0_
                                    102 	.globl _SCS
                                    103 	.globl _MOSI
                                    104 	.globl _MISO
                                    105 	.globl _SCK
                                    106 	.globl _RXD1_
                                    107 	.globl _TXD1_
                                    108 	.globl _P1_0
                                    109 	.globl _P1_1
                                    110 	.globl _P1_2
                                    111 	.globl _P1_3
                                    112 	.globl _P1_4
                                    113 	.globl _P1_5
                                    114 	.globl _P1_6
                                    115 	.globl _P1_7
                                    116 	.globl _AIN8
                                    117 	.globl _AIN9
                                    118 	.globl _AIN10
                                    119 	.globl _AIN11
                                    120 	.globl _AIN12
                                    121 	.globl _AIN13
                                    122 	.globl _RXD_
                                    123 	.globl _TXD_
                                    124 	.globl _SCL0
                                    125 	.globl _SDA0
                                    126 	.globl _P0_0
                                    127 	.globl _P0_1
                                    128 	.globl _P0_2
                                    129 	.globl _P0_3
                                    130 	.globl _P0_4
                                    131 	.globl _P0_5
                                    132 	.globl _P0_6
                                    133 	.globl _P0_7
                                    134 	.globl _IE_SPI0
                                    135 	.globl _IE_USB
                                    136 	.globl _IE_ADC
                                    137 	.globl _IE_UART1
                                    138 	.globl _IE_PWM_I2C
                                    139 	.globl _IE_GPIO
                                    140 	.globl _IE_WDOG
                                    141 	.globl _PX0
                                    142 	.globl _PT0
                                    143 	.globl _PX1
                                    144 	.globl _PT1
                                    145 	.globl _PS
                                    146 	.globl _PT2
                                    147 	.globl _PL_FLAG
                                    148 	.globl _PH_FLAG
                                    149 	.globl _EX0
                                    150 	.globl _ET0
                                    151 	.globl _EX1
                                    152 	.globl _ET1
                                    153 	.globl _ES
                                    154 	.globl _ET2
                                    155 	.globl _E_DIS
                                    156 	.globl _EA
                                    157 	.globl _P
                                    158 	.globl _F1
                                    159 	.globl _OV
                                    160 	.globl _RS0
                                    161 	.globl _RS1
                                    162 	.globl _F0
                                    163 	.globl _AC
                                    164 	.globl _CY
                                    165 	.globl _I2CS_INT_ST
                                    166 	.globl _I2CX_INT
                                    167 	.globl _LED_STATUS
                                    168 	.globl _LED_DMA_H
                                    169 	.globl _LED_DMA_L
                                    170 	.globl _LED_DMA
                                    171 	.globl _LED_PWM_OE
                                    172 	.globl _LED_COMMON
                                    173 	.globl _ADC_CHAN
                                    174 	.globl _ADC_DAT_H
                                    175 	.globl _ADC_DAT_L
                                    176 	.globl _ADC_DAT
                                    177 	.globl _ADC_CTRL
                                    178 	.globl _SPI1_CK_SE
                                    179 	.globl _SPI1_CTRL
                                    180 	.globl _SPI1_DATA
                                    181 	.globl _SPI1_STAT
                                    182 	.globl _SIF1
                                    183 	.globl _SBAUD1
                                    184 	.globl _SBUF1
                                    185 	.globl _SCON1
                                    186 	.globl _SPI0_SETUP
                                    187 	.globl _SPI0_CK_SE
                                    188 	.globl _SPI0_CTRL
                                    189 	.globl _SPI0_DATA
                                    190 	.globl _SPI0_STAT
                                    191 	.globl _T2CAP1H
                                    192 	.globl _T2CAP1L
                                    193 	.globl _T2CAP1
                                    194 	.globl _TH2
                                    195 	.globl _TL2
                                    196 	.globl _T2COUNT
                                    197 	.globl _RCAP2H
                                    198 	.globl _RCAP2L
                                    199 	.globl _RCAP2
                                    200 	.globl _T2MOD
                                    201 	.globl _T2CON
                                    202 	.globl _SBUF
                                    203 	.globl _SCON
                                    204 	.globl _TH1
                                    205 	.globl _TH0
                                    206 	.globl _TL1
                                    207 	.globl _TL0
                                    208 	.globl _TMOD
                                    209 	.globl _TCON
                                    210 	.globl _XBUS_AUX
                                    211 	.globl _P7
                                    212 	.globl _P6_DIR
                                    213 	.globl _P6_OUT_PU
                                    214 	.globl _P6_IN
                                    215 	.globl _P5_DIR
                                    216 	.globl _P5_OUT_PU
                                    217 	.globl _P5_IN
                                    218 	.globl _P4_LED_KEY
                                    219 	.globl _P4_DIR_PU
                                    220 	.globl _P4_MOD_OC
                                    221 	.globl _P4
                                    222 	.globl _P3_DIR_PU
                                    223 	.globl _P3_MOD_OC
                                    224 	.globl _P3
                                    225 	.globl _P2_DIR_PU
                                    226 	.globl _P2_MOD_OC
                                    227 	.globl _P2
                                    228 	.globl _P1_DIR_PU
                                    229 	.globl _P1_MOD_OC
                                    230 	.globl _P1
                                    231 	.globl _P0_DIR_PU
                                    232 	.globl _P0_MOD_OC
                                    233 	.globl _P0
                                    234 	.globl _ROM_CTRL
                                    235 	.globl _ROM_DATA_HH
                                    236 	.globl _ROM_DATA_HL
                                    237 	.globl _ROM_DATA_HI
                                    238 	.globl _ROM_ADDR_H
                                    239 	.globl _ROM_ADDR_L
                                    240 	.globl _ROM_ADDR
                                    241 	.globl _GPIO_IE
                                    242 	.globl _IP_EX
                                    243 	.globl _IE_EX
                                    244 	.globl _IP
                                    245 	.globl _IE
                                    246 	.globl _WDOG_COUNT
                                    247 	.globl _RESET_KEEP
                                    248 	.globl _WAKE_CTRL
                                    249 	.globl _CLOCK_CFG
                                    250 	.globl _POWER_CFG
                                    251 	.globl _PCON
                                    252 	.globl _GLOBAL_CFG
                                    253 	.globl _SAFE_MOD
                                    254 	.globl _DPH
                                    255 	.globl _DPL
                                    256 	.globl _SP
                                    257 	.globl _A_INV
                                    258 	.globl _B
                                    259 	.globl _ACC
                                    260 	.globl _PSW
                                    261 	.globl _actual_keyboard_report
                                    262 	.globl _owned_usage_key_PARM_2
                                    263 	.globl _ak820_macro_change_PARM_3
                                    264 	.globl _ak820_macro_change_PARM_2
                                    265 	.globl _ak820_macro_cancelled
                                    266 	.globl _ak820_macro_primitive
                                    267 	.globl _ak820_macro_change
                                    268 	.globl _add_owned_mods
                                    269 	.globl _del_owned_mods
                                    270 	.globl _add_owned_weak_mods
                                    271 	.globl _del_owned_weak_mods
                                    272 	.globl _clear_owned_mods
                                    273 	.globl _clear_owned_keys
                                    274 	.globl _add_owned_key
                                    275 	.globl _del_owned_key
                                    276 	.globl _clear_owned_usages
                                    277 	.globl _owned_usage_key
                                    278 	.globl _send_keyboard_report
                                    279 	.globl _get_mods
                                    280 	.globl _clear_mods
                                    281 	.globl _get_weak_mods
                                    282 	.globl _add_weak_mods
                                    283 	.globl _del_weak_mods
                                    284 	.globl _clear_weak_mods
                                    285 ;--------------------------------------------------------
                                    286 ; special function registers
                                    287 ;--------------------------------------------------------
                                    288 	.area RSEG    (ABS,DATA)
      000000                        289 	.org 0x0000
                           0000D0   290 _PSW	=	0x00d0
                           0000E0   291 _ACC	=	0x00e0
                           0000F0   292 _B	=	0x00f0
                           0000FD   293 _A_INV	=	0x00fd
                           000081   294 _SP	=	0x0081
                           000082   295 _DPL	=	0x0082
                           000083   296 _DPH	=	0x0083
                           0000A1   297 _SAFE_MOD	=	0x00a1
                           0000B1   298 _GLOBAL_CFG	=	0x00b1
                           000087   299 _PCON	=	0x0087
                           0000BA   300 _POWER_CFG	=	0x00ba
                           0000B9   301 _CLOCK_CFG	=	0x00b9
                           0000A9   302 _WAKE_CTRL	=	0x00a9
                           0000FE   303 _RESET_KEEP	=	0x00fe
                           0000FF   304 _WDOG_COUNT	=	0x00ff
                           0000A8   305 _IE	=	0x00a8
                           0000B8   306 _IP	=	0x00b8
                           0000E8   307 _IE_EX	=	0x00e8
                           0000E9   308 _IP_EX	=	0x00e9
                           0000B2   309 _GPIO_IE	=	0x00b2
                           008584   310 _ROM_ADDR	=	0x8584
                           000084   311 _ROM_ADDR_L	=	0x0084
                           000085   312 _ROM_ADDR_H	=	0x0085
                           008F8E   313 _ROM_DATA_HI	=	0x8f8e
                           00008E   314 _ROM_DATA_HL	=	0x008e
                           00008F   315 _ROM_DATA_HH	=	0x008f
                           000086   316 _ROM_CTRL	=	0x0086
                           000080   317 _P0	=	0x0080
                           0000C4   318 _P0_MOD_OC	=	0x00c4
                           0000C5   319 _P0_DIR_PU	=	0x00c5
                           000090   320 _P1	=	0x0090
                           000092   321 _P1_MOD_OC	=	0x0092
                           000093   322 _P1_DIR_PU	=	0x0093
                           0000A0   323 _P2	=	0x00a0
                           000094   324 _P2_MOD_OC	=	0x0094
                           000095   325 _P2_DIR_PU	=	0x0095
                           0000B0   326 _P3	=	0x00b0
                           000096   327 _P3_MOD_OC	=	0x0096
                           000097   328 _P3_DIR_PU	=	0x0097
                           0000C0   329 _P4	=	0x00c0
                           0000C2   330 _P4_MOD_OC	=	0x00c2
                           0000C3   331 _P4_DIR_PU	=	0x00c3
                           0000C1   332 _P4_LED_KEY	=	0x00c1
                           0000AA   333 _P5_IN	=	0x00aa
                           0000AB   334 _P5_OUT_PU	=	0x00ab
                           0000AC   335 _P5_DIR	=	0x00ac
                           0000AD   336 _P6_IN	=	0x00ad
                           0000AE   337 _P6_OUT_PU	=	0x00ae
                           0000AF   338 _P6_DIR	=	0x00af
                           0000F1   339 _P7	=	0x00f1
                           0000A2   340 _XBUS_AUX	=	0x00a2
                           000088   341 _TCON	=	0x0088
                           000089   342 _TMOD	=	0x0089
                           00008A   343 _TL0	=	0x008a
                           00008B   344 _TL1	=	0x008b
                           00008C   345 _TH0	=	0x008c
                           00008D   346 _TH1	=	0x008d
                           000098   347 _SCON	=	0x0098
                           000099   348 _SBUF	=	0x0099
                           0000C8   349 _T2CON	=	0x00c8
                           0000C9   350 _T2MOD	=	0x00c9
                           00CBCA   351 _RCAP2	=	0xcbca
                           0000CA   352 _RCAP2L	=	0x00ca
                           0000CB   353 _RCAP2H	=	0x00cb
                           00CDCC   354 _T2COUNT	=	0xcdcc
                           0000CC   355 _TL2	=	0x00cc
                           0000CD   356 _TH2	=	0x00cd
                           00CFCE   357 _T2CAP1	=	0xcfce
                           0000CE   358 _T2CAP1L	=	0x00ce
                           0000CF   359 _T2CAP1H	=	0x00cf
                           0000F8   360 _SPI0_STAT	=	0x00f8
                           0000F9   361 _SPI0_DATA	=	0x00f9
                           0000FA   362 _SPI0_CTRL	=	0x00fa
                           0000FB   363 _SPI0_CK_SE	=	0x00fb
                           0000FC   364 _SPI0_SETUP	=	0x00fc
                           0000BC   365 _SCON1	=	0x00bc
                           0000BD   366 _SBUF1	=	0x00bd
                           0000BE   367 _SBAUD1	=	0x00be
                           0000BF   368 _SIF1	=	0x00bf
                           0000B4   369 _SPI1_STAT	=	0x00b4
                           0000B5   370 _SPI1_DATA	=	0x00b5
                           0000B6   371 _SPI1_CTRL	=	0x00b6
                           0000B7   372 _SPI1_CK_SE	=	0x00b7
                           0000F3   373 _ADC_CTRL	=	0x00f3
                           00F5F4   374 _ADC_DAT	=	0xf5f4
                           0000F4   375 _ADC_DAT_L	=	0x00f4
                           0000F5   376 _ADC_DAT_H	=	0x00f5
                           0000F6   377 _ADC_CHAN	=	0x00f6
                           0000A6   378 _LED_COMMON	=	0x00a6
                           0000A7   379 _LED_PWM_OE	=	0x00a7
                           00C7C6   380 _LED_DMA	=	0xc7c6
                           0000C6   381 _LED_DMA_L	=	0x00c6
                           0000C7   382 _LED_DMA_H	=	0x00c7
                           0000F7   383 _LED_STATUS	=	0x00f7
                           0000B3   384 _I2CX_INT	=	0x00b3
                           0000BB   385 _I2CS_INT_ST	=	0x00bb
                                    386 ;--------------------------------------------------------
                                    387 ; special function bits
                                    388 ;--------------------------------------------------------
                                    389 	.area RSEG    (ABS,DATA)
      000000                        390 	.org 0x0000
                           0000D7   391 _CY	=	0x00d7
                           0000D6   392 _AC	=	0x00d6
                           0000D5   393 _F0	=	0x00d5
                           0000D4   394 _RS1	=	0x00d4
                           0000D3   395 _RS0	=	0x00d3
                           0000D2   396 _OV	=	0x00d2
                           0000D1   397 _F1	=	0x00d1
                           0000D0   398 _P	=	0x00d0
                           0000AF   399 _EA	=	0x00af
                           0000AE   400 _E_DIS	=	0x00ae
                           0000AD   401 _ET2	=	0x00ad
                           0000AC   402 _ES	=	0x00ac
                           0000AB   403 _ET1	=	0x00ab
                           0000AA   404 _EX1	=	0x00aa
                           0000A9   405 _ET0	=	0x00a9
                           0000A8   406 _EX0	=	0x00a8
                           0000BF   407 _PH_FLAG	=	0x00bf
                           0000BE   408 _PL_FLAG	=	0x00be
                           0000BD   409 _PT2	=	0x00bd
                           0000BC   410 _PS	=	0x00bc
                           0000BB   411 _PT1	=	0x00bb
                           0000BA   412 _PX1	=	0x00ba
                           0000B9   413 _PT0	=	0x00b9
                           0000B8   414 _PX0	=	0x00b8
                           0000EF   415 _IE_WDOG	=	0x00ef
                           0000EE   416 _IE_GPIO	=	0x00ee
                           0000ED   417 _IE_PWM_I2C	=	0x00ed
                           0000EC   418 _IE_UART1	=	0x00ec
                           0000EB   419 _IE_ADC	=	0x00eb
                           0000E9   420 _IE_USB	=	0x00e9
                           0000E8   421 _IE_SPI0	=	0x00e8
                           000087   422 _P0_7	=	0x0087
                           000086   423 _P0_6	=	0x0086
                           000085   424 _P0_5	=	0x0085
                           000084   425 _P0_4	=	0x0084
                           000083   426 _P0_3	=	0x0083
                           000082   427 _P0_2	=	0x0082
                           000081   428 _P0_1	=	0x0081
                           000080   429 _P0_0	=	0x0080
                           000081   430 _SDA0	=	0x0081
                           000080   431 _SCL0	=	0x0080
                           000083   432 _TXD_	=	0x0083
                           000082   433 _RXD_	=	0x0082
                           000085   434 _AIN13	=	0x0085
                           000084   435 _AIN12	=	0x0084
                           000083   436 _AIN11	=	0x0083
                           000082   437 _AIN10	=	0x0082
                           000081   438 _AIN9	=	0x0081
                           000080   439 _AIN8	=	0x0080
                           000097   440 _P1_7	=	0x0097
                           000096   441 _P1_6	=	0x0096
                           000095   442 _P1_5	=	0x0095
                           000094   443 _P1_4	=	0x0094
                           000093   444 _P1_3	=	0x0093
                           000092   445 _P1_2	=	0x0092
                           000091   446 _P1_1	=	0x0091
                           000090   447 _P1_0	=	0x0090
                           000097   448 _TXD1_	=	0x0097
                           000096   449 _RXD1_	=	0x0096
                           000097   450 _SCK	=	0x0097
                           000096   451 _MISO	=	0x0096
                           000095   452 _MOSI	=	0x0095
                           000094   453 _SCS	=	0x0094
                           000092   454 _INT0_	=	0x0092
                           000091   455 _T2EX	=	0x0091
                           000091   456 _CAP2	=	0x0091
                           000090   457 _T2	=	0x0090
                           000090   458 _CAP1	=	0x0090
                           000097   459 _AIN7	=	0x0097
                           000096   460 _AIN6	=	0x0096
                           000095   461 _AIN5	=	0x0095
                           000094   462 _AIN4	=	0x0094
                           000093   463 _AIN3	=	0x0093
                           000092   464 _AIN2	=	0x0092
                           000091   465 _AIN1	=	0x0091
                           000090   466 _AIN0	=	0x0090
                           0000A7   467 _P2_7	=	0x00a7
                           0000A6   468 _P2_6	=	0x00a6
                           0000A5   469 _P2_5	=	0x00a5
                           0000A4   470 _P2_4	=	0x00a4
                           0000A3   471 _P2_3	=	0x00a3
                           0000A2   472 _P2_2	=	0x00a2
                           0000A1   473 _P2_1	=	0x00a1
                           0000A0   474 _P2_0	=	0x00a0
                           0000A7   475 _TXD1	=	0x00a7
                           0000A6   476 _RXD1	=	0x00a6
                           0000A5   477 _T2EX_	=	0x00a5
                           0000A5   478 _CAP2_	=	0x00a5
                           0000A4   479 _T2_	=	0x00a4
                           0000A4   480 _CAP1_	=	0x00a4
                           0000B7   481 _P3_7	=	0x00b7
                           0000B6   482 _P3_6	=	0x00b6
                           0000B5   483 _P3_5	=	0x00b5
                           0000B4   484 _P3_4	=	0x00b4
                           0000B3   485 _P3_3	=	0x00b3
                           0000B2   486 _P3_2	=	0x00b2
                           0000B1   487 _P3_1	=	0x00b1
                           0000B0   488 _P3_0	=	0x00b0
                           0000B7   489 _SCK1	=	0x00b7
                           0000B6   490 _MISO1	=	0x00b6
                           0000B5   491 _MOSI1	=	0x00b5
                           0000B5   492 _T1	=	0x00b5
                           0000B4   493 _T0	=	0x00b4
                           0000B3   494 _INT1	=	0x00b3
                           0000B2   495 _INT0	=	0x00b2
                           0000B1   496 _TXD	=	0x00b1
                           0000B0   497 _RXD	=	0x00b0
                           0000C6   498 _P4_6	=	0x00c6
                           0000C5   499 _P4_5	=	0x00c5
                           0000C4   500 _P4_4	=	0x00c4
                           0000C3   501 _P4_3	=	0x00c3
                           0000C2   502 _P4_2	=	0x00c2
                           0000C1   503 _P4_1	=	0x00c1
                           0000C0   504 _P4_0	=	0x00c0
                           00008F   505 _TF1	=	0x008f
                           00008E   506 _TR1	=	0x008e
                           00008D   507 _TF0	=	0x008d
                           00008C   508 _TR0	=	0x008c
                           00008B   509 _IE1	=	0x008b
                           00008A   510 _IT1	=	0x008a
                           000089   511 _IE0	=	0x0089
                           000088   512 _IT0	=	0x0088
                           00009F   513 _SM0	=	0x009f
                           00009E   514 _SM1	=	0x009e
                           00009D   515 _SM2	=	0x009d
                           00009C   516 _REN	=	0x009c
                           00009B   517 _TB8	=	0x009b
                           00009A   518 _RB8	=	0x009a
                           000099   519 _TI	=	0x0099
                           000098   520 _RI	=	0x0098
                           0000CF   521 _TF2	=	0x00cf
                           0000CF   522 _CAP1F	=	0x00cf
                           0000CE   523 _EXF2	=	0x00ce
                           0000CD   524 _RCLK	=	0x00cd
                           0000CC   525 _TCLK	=	0x00cc
                           0000CB   526 _EXEN2	=	0x00cb
                           0000CA   527 _TR2	=	0x00ca
                           0000C9   528 _C_T2	=	0x00c9
                           0000C8   529 _CP_RL2	=	0x00c8
                           0000FF   530 _S0_FST_ACT	=	0x00ff
                           0000FE   531 _S0_IF_OV	=	0x00fe
                           0000FD   532 _S0_IF_FIRST	=	0x00fd
                           0000FC   533 _S0_IF_BYTE	=	0x00fc
                           0000FB   534 _S0_FREE	=	0x00fb
                           0000FA   535 _S0_T_FIFO	=	0x00fa
                           0000F8   536 _S0_R_FIFO	=	0x00f8
                           0000F7   537 _ADC_START	=	0x00f7
                                    538 ;--------------------------------------------------------
                                    539 ; overlayable register banks
                                    540 ;--------------------------------------------------------
                                    541 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        542 	.ds 8
                                    543 ;--------------------------------------------------------
                                    544 ; internal ram data
                                    545 ;--------------------------------------------------------
                                    546 	.area DSEG    (DATA)
                                    547 ;--------------------------------------------------------
                                    548 ; overlayable items in internal ram
                                    549 ;--------------------------------------------------------
                                    550 	.area	OSEG    (OVR,DATA)
      000055                        551 _change_owned_sloc1_1_0:
      000055                        552 	.ds 1
                                    553 ;--------------------------------------------------------
                                    554 ; indirectly addressable internal ram data
                                    555 ;--------------------------------------------------------
                                    556 	.area ISEG    (DATA)
                                    557 ;--------------------------------------------------------
                                    558 ; absolute internal ram data
                                    559 ;--------------------------------------------------------
                                    560 	.area IABS    (ABS,DATA)
                                    561 	.area IABS    (ABS,DATA)
                                    562 ;--------------------------------------------------------
                                    563 ; bit data
                                    564 ;--------------------------------------------------------
                                    565 	.area BSEG    (BIT)
      000023                        566 _ak820_macro_change_sloc0_1_0:
      000023                        567 	.ds 1
      000024                        568 _change_owned_sloc0_1_0:
      000024                        569 	.ds 1
      000025                        570 _owned_usage_key_sloc0_1_0:
      000025                        571 	.ds 1
                                    572 ;--------------------------------------------------------
                                    573 ; paged external ram data
                                    574 ;--------------------------------------------------------
                                    575 	.area PSEG    (PAG,XDATA)
                                    576 ;--------------------------------------------------------
                                    577 ; uninitialized external ram data
                                    578 ;--------------------------------------------------------
                                    579 	.area XSEG    (XDATA)
      0009DC                        580 _owned_mod_refs:
      0009DC                        581 	.ds 8
      0009E4                        582 _owned_weak_refs:
      0009E4                        583 	.ds 8
      0009EC                        584 _owned_mods:
      0009EC                        585 	.ds 1
      0009ED                        586 _owned_weak_mods:
      0009ED                        587 	.ds 1
      0009EE                        588 _macro_mods:
      0009EE                        589 	.ds 2
      0009F0                        590 _ak820_macro_primitive::
      0009F0                        591 	.ds 1
      0009F1                        592 _ak820_macro_cancelled::
      0009F1                        593 	.ds 1
      0009F2                        594 _ak820_macro_change_PARM_2:
      0009F2                        595 	.ds 1
      0009F3                        596 _ak820_macro_change_PARM_3:
      0009F3                        597 	.ds 1
      0009F4                        598 _ak820_macro_change_bits_10000_293:
      0009F4                        599 	.ds 2
      0009F6                        600 _change_owned_PARM_2:
      0009F6                        601 	.ds 1
      0009F7                        602 _change_owned_mods_10000_298:
      0009F7                        603 	.ds 1
      0009F8                        604 _change_owned_result_10001_302:
      0009F8                        605 	.ds 1
      0009F9                        606 _change_owned_bit_20001_303:
      0009F9                        607 	.ds 1
      0009FA                        608 _add_owned_mods_mods_10000_311:
      0009FA                        609 	.ds 1
      0009FB                        610 _del_owned_mods_mods_10000_313:
      0009FB                        611 	.ds 1
      0009FC                        612 _add_owned_weak_mods_mods_10000_315:
      0009FC                        613 	.ds 1
      0009FD                        614 _del_owned_weak_mods_mods_10000_317:
      0009FD                        615 	.ds 1
      0009FE                        616 _key_refs:
      0009FE                        617 	.ds 165
      000AA3                        618 _distinct_keys:
      000AA3                        619 	.ds 1
      000AA4                        620 _macro_keys:
      000AA4                        621 	.ds 21
      000AB9                        622 _add_owned_key_code_10000_326:
      000AB9                        623 	.ds 1
      000ABA                        624 _del_owned_key_code_10000_341:
      000ABA                        625 	.ds 1
      000ABB                        626 _usage_refs:
      000ABB                        627 	.ds 30
      000AD9                        628 _usage_order:
      000AD9                        629 	.ds 30
      000AF7                        630 _usage_lengths:
      000AF7                        631 	.ds 2
      000AF9                        632 _macro_usages:
      000AF9                        633 	.ds 4
      000AFD                        634 _owned_usage_key_PARM_2:
      000AFD                        635 	.ds 1
      000AFE                        636 _owned_usage_key_code_10000_368:
      000AFE                        637 	.ds 1
      000AFF                        638 _owned_usage_key___200000085_20000_369:
      000AFF                        639 	.ds 2
      000B01                        640 _owned_usage_key_which_10000_369:
      000B01                        641 	.ds 1
      000B02                        642 _owned_usage_key_count_10000_369:
      000B02                        643 	.ds 1
      000B03                        644 _owned_usage_key_pos_30001_376:
      000B03                        645 	.ds 1
      000B04                        646 _owned_usage_key_key_40000_381:
      000B04                        647 	.ds 1
      000B05                        648 _send_keyboard_report_last_report_10001_388:
      000B05                        649 	.ds 32
      000B25                        650 _send_keyboard_report_changed_10001_388:
      000B25                        651 	.ds 1
      000B26                        652 _add_weak_mods_mods_10000_406:
      000B26                        653 	.ds 1
      000B27                        654 _del_weak_mods_mods_10000_408:
      000B27                        655 	.ds 1
                                    656 ;--------------------------------------------------------
                                    657 ; absolute external ram data
                                    658 ;--------------------------------------------------------
                                    659 	.area XABS    (ABS,XDATA)
                                    660 ;--------------------------------------------------------
                                    661 ; initialized external ram data
                                    662 ;--------------------------------------------------------
                                    663 	.area XISEG   (XDATA)
      000E2E                        664 _real_mods:
      000E2E                        665 	.ds 1
      000E2F                        666 _weak_mods:
      000E2F                        667 	.ds 1
      000E30                        668 _actual_keyboard_report::
      000E30                        669 	.ds 32
                                    670 	.area HOME    (CODE)
                                    671 	.area GSINIT0 (CODE)
                                    672 	.area GSINIT1 (CODE)
                                    673 	.area GSINIT2 (CODE)
                                    674 	.area GSINIT3 (CODE)
                                    675 	.area GSINIT4 (CODE)
                                    676 	.area GSINIT5 (CODE)
                                    677 	.area GSINIT  (CODE)
                                    678 	.area GSFINAL (CODE)
                                    679 	.area CSEG    (CODE)
                                    680 ;--------------------------------------------------------
                                    681 ; global & static initialisations
                                    682 ;--------------------------------------------------------
                                    683 	.area HOME    (CODE)
                                    684 	.area GSINIT  (CODE)
                                    685 	.area GSFINAL (CODE)
                                    686 	.area GSINIT  (CODE)
                                    687 ;--------------------------------------------------------
                                    688 ; Home
                                    689 ;--------------------------------------------------------
                                    690 	.area HOME    (CODE)
                                    691 	.area HOME    (CODE)
                                    692 ;--------------------------------------------------------
                                    693 ; code
                                    694 ;--------------------------------------------------------
                                    695 	.area CSEG    (CODE)
                                    696 ;------------------------------------------------------------
                                    697 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    698 ;------------------------------------------------------------
                                    699 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    700 ;------------------------------------------------------------
                                    701 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    702 ;	-----------------------------------------
                           000007   703 	ar7 = 0x07
                           000006   704 	ar6 = 0x06
                           000005   705 	ar5 = 0x05
                           000004   706 	ar4 = 0x04
                           000003   707 	ar3 = 0x03
                           000002   708 	ar2 = 0x02
                           000001   709 	ar1 = 0x01
                           000000   710 	ar0 = 0x00
                                    711 ;	 function ak820_macro_change
                                    712 ;	-----------------------------------------
      0081C8                        713 _ak820_macro_change:
      0081C8 12 3A C2         [24]  714 	lcall	_ak820_outline_0110
      0081CB 90 09 F4         [24]  715 	mov	dptr,#_ak820_macro_change_bits_10000_293
      0081CE 12 3A C7         [24]  716 	lcall	_ak820_outline_0111
                                    717 ;	quantum/action_util.c:79: if (!ak820_macro_primitive) return true;
      0081D1 90 09 F0         [24]  718 	mov	dptr,#_ak820_macro_primitive
      0081D4 E0               [24]  719 	movx	a,@dptr
      0081D5 70 04            [24]  720 	jnz	00102$
      0081D7 75 82 01         [24]  721 	mov	dpl, #0x01
      0081DA 22               [24]  722 	ret
      0081DB                        723 00102$:
                                    724 ;	quantum/action_util.c:80: uint8_t mask = 1u << (index & 7);
      0081DB 90 09 F2         [24]  725 	mov	dptr,#_ak820_macro_change_PARM_2
      0081DE E0               [24]  726 	movx	a,@dptr
      0081DF FF               [12]  727 	mov	r7,a
      0081E0 74 07            [12]  728 	mov	a,#0x07
      0081E2 5F               [12]  729 	anl	a,r7
      0081E3 12 7D 6B         [24]  730 	lcall	_ak820_outline_0063
      0081E6 80 02            [24]  731 	sjmp	00123$
      0081E8                        732 00122$:
      0081E8 25 E0            [12]  733 	add	a,acc
      0081EA                        734 00123$:
      0081EA D5 F0 FB         [24]  735 	djnz	b,00122$
      0081ED FE               [12]  736 	mov	r6,a
                                    737 ;	quantum/action_util.c:81: bits += index >> 3;
      0081EE EF               [12]  738 	mov	a,r7
      0081EF 12 5C B9         [24]  739 	lcall	_ak820_outline_0189
      0081F2 FF               [12]  740 	mov	r7,a
      0081F3 90 09 F4         [24]  741 	mov	dptr,#_ak820_macro_change_bits_10000_293
      0081F6 12 3A 98         [24]  742 	lcall	_ak820_outline_0061
      0081F9 90 09 F4         [24]  743 	mov	dptr,#_ak820_macro_change_bits_10000_293
      0081FC EF               [12]  744 	mov	a,r7
      0081FD 2C               [12]  745 	add	a, r4
      0081FE F0               [24]  746 	movx	@dptr,a
      0081FF E4               [12]  747 	clr	a
      008200 3D               [12]  748 	addc	a, r5
      008201 A3               [24]  749 	inc	dptr
      008202 F0               [24]  750 	movx	@dptr,a
                                    751 ;	quantum/action_util.c:82: if (((*bits & mask) != 0) == pressed) return false;
      008203 90 09 F4         [24]  752 	mov	dptr,#_ak820_macro_change_bits_10000_293
      008206 E0               [24]  753 	movx	a,@dptr
      008207 FD               [12]  754 	mov	r5,a
      008208 A3               [24]  755 	inc	dptr
      008209 E0               [24]  756 	movx	a,@dptr
      00820A FF               [12]  757 	mov	r7,a
      00820B 12 87 4B         [24]  758 	lcall	_ak820_outline_0191
      00820E E0               [24]  759 	movx	a,@dptr
      00820F FC               [12]  760 	mov	r4,a
      008210 EE               [12]  761 	mov	a,r6
      008211 5C               [12]  762 	anl	a,r4
      008212 B4 01 00         [24]  763 	cjne	a,#0x01,00124$
      008215                        764 00124$:
      008215 B3               [12]  765 	cpl	c
      008216 92 23            [24]  766 	mov	_ak820_macro_change_sloc0_1_0,c
      008218 90 09 F3         [24]  767 	mov	dptr,#_ak820_macro_change_PARM_3
      00821B E0               [24]  768 	movx	a,@dptr
      00821C FB               [12]  769 	mov	r3,a
      00821D A2 23            [12]  770 	mov	c,_ak820_macro_change_sloc0_1_0
      00821F E4               [12]  771 	clr	a
      008220 33               [12]  772 	rlc	a
      008221 B5 03 04         [24]  773 	cjne	a,ar3,00104$
      008224 75 82 00         [24]  774 	mov	dpl, #0x00
      008227 22               [24]  775 	ret
      008228                        776 00104$:
                                    777 ;	quantum/action_util.c:83: *bits ^= mask;
      008228 EC               [12]  778 	mov	a,r4
      008229 62 06            [12]  779 	xrl	ar6,a
      00822B 12 87 4B         [24]  780 	lcall	_ak820_outline_0191
      00822E EE               [12]  781 	mov	a,r6
      00822F F0               [24]  782 	movx	@dptr,a
                                    783 ;	quantum/action_util.c:84: return true;
      008230 75 82 01         [24]  784 	mov	dpl, #0x01
                                    785 ;	quantum/action_util.c:85: }
      008233 22               [24]  786 	ret
                                    787 ;------------------------------------------------------------
                                    788 ;Allocation info for local variables in function 'change_owned'
                                    789 ;------------------------------------------------------------
                                    790 ;mode          Allocated with name '_change_owned_PARM_2'
                                    791 ;mods          Allocated with name '_change_owned_mods_10000_298'
                                    792 ;kind          Allocated with name '_change_owned_kind_10000_299'
                                    793 ;pressed       Allocated with name '_change_owned_pressed_10000_299'
                                    794 ;refs          Allocated with name '_change_owned_refs_10000_299'
                                    795 ;old           Allocated with name '_change_owned_old_30000_301'
                                    796 ;result        Allocated with name '_change_owned_result_10001_302'
                                    797 ;i             Allocated with name '_change_owned_i_20001_303'
                                    798 ;bit           Allocated with name '_change_owned_bit_20001_303'
                                    799 ;sloc1         Allocated with name '_change_owned_sloc1_1_0'
                                    800 ;------------------------------------------------------------
                                    801 ;	quantum/action_util.c:86: static void change_owned(uint8_t mods, uint8_t mode) {
                                    802 ;	-----------------------------------------
                                    803 ;	 function change_owned
                                    804 ;	-----------------------------------------
      008234                        805 _change_owned:
      008234 E5 82            [12]  806 	mov	a,dpl
      008236 90 09 F7         [24]  807 	mov	dptr,#_change_owned_mods_10000_298
      008239 F0               [24]  808 	movx	@dptr,a
                                    809 ;	quantum/action_util.c:87: uint8_t kind = mode >> 1;
      00823A 90 09 F6         [24]  810 	mov	dptr,#_change_owned_PARM_2
      00823D E0               [24]  811 	movx	a,@dptr
      00823E FF               [12]  812 	mov	r7,a
      00823F C3               [12]  813 	clr	c
      008240 13               [12]  814 	rrc	a
      008241 FE               [12]  815 	mov	r6,a
                                    816 ;	quantum/action_util.c:88: bool pressed = (mode & 1) != 0;
      008242 53 07 01         [24]  817 	anl	ar7,#0x01
      008245 EF               [12]  818 	mov	a,r7
      008246 B4 01 00         [24]  819 	cjne	a,#0x01,00205$
      008249                        820 00205$:
      008249 92 24            [24]  821 	mov  _change_owned_sloc0_1_0,c
      00824B B3               [12]  822 	cpl	c
      00824C E4               [12]  823 	clr	a
      00824D 33               [12]  824 	rlc	a
      00824E F5 55            [12]  825 	mov	_change_owned_sloc1_1_0,a
                                    826 ;	quantum/action_util.c:89: uint8_t AK820_STATE_MEM *refs = kind ? owned_weak_refs : owned_mod_refs;
      008250 EE               [12]  827 	mov	a,r6
      008251 60 06            [24]  828 	jz	00121$
      008253 7D E4            [12]  829 	mov	r5,#_owned_weak_refs
      008255 7F 09            [12]  830 	mov	r7,#(_owned_weak_refs >> 8)
      008257 80 04            [24]  831 	sjmp	00122$
      008259                        832 00121$:
      008259 7D DC            [12]  833 	mov	r5,#_owned_mod_refs
      00825B 7F 09            [12]  834 	mov	r7,#(_owned_mod_refs >> 8)
      00825D                        835 00122$:
                                    836 ;	quantum/action_util.c:90: if (ak820_macro_primitive) {
      00825D 90 09 F0         [24]  837 	mov	dptr,#_ak820_macro_primitive
      008260 E0               [24]  838 	movx	a,@dptr
      008261 60 36            [24]  839 	jz	00102$
                                    840 ;	quantum/action_util.c:91: uint8_t old = macro_mods[kind];
      008263 EE               [12]  841 	mov	a,r6
      008264 24 EE            [12]  842 	add	a, #_macro_mods
      008266 FB               [12]  843 	mov	r3,a
      008267 E4               [12]  844 	clr	a
      008268 34 09            [12]  845 	addc	a, #(_macro_mods >> 8)
      00826A 12 4E 01         [24]  846 	lcall	_ak820_outline_0057
                                    847 ;	quantum/action_util.c:92: macro_mods[kind] = pressed ? old | mods : old & ~mods;
      00826D E5 55            [12]  848 	mov	a,_change_owned_sloc1_1_0
      00826F 60 0A            [24]  849 	jz	00123$
      008271 90 09 F7         [24]  850 	mov	dptr,#_change_owned_mods_10000_298
      008274 E0               [24]  851 	movx	a,@dptr
      008275 F9               [12]  852 	mov	r1,a
      008276 EA               [12]  853 	mov	a,r2
      008277 42 01            [12]  854 	orl	ar1,a
      008279 80 07            [24]  855 	sjmp	00124$
      00827B                        856 00123$:
      00827B 90 09 F7         [24]  857 	mov	dptr,#_change_owned_mods_10000_298
      00827E E0               [24]  858 	movx	a,@dptr
      00827F F4               [12]  859 	cpl	a
      008280 5A               [12]  860 	anl	a,r2
      008281 F9               [12]  861 	mov	r1,a
      008282                        862 00124$:
      008282 12 36 47         [24]  863 	lcall	_ak820_outline_0125
      008285 E9               [12]  864 	mov	a,r1
      008286 F0               [24]  865 	movx	@dptr,a
                                    866 ;	quantum/action_util.c:93: mods &= pressed ? ~old : old;
      008287 E5 55            [12]  867 	mov	a,_change_owned_sloc1_1_0
      008289 60 06            [24]  868 	jz	00125$
      00828B 74 FF            [12]  869 	mov	a,#0xff
      00828D 6A               [12]  870 	xrl	a,r2
      00828E FC               [12]  871 	mov	r4,a
      00828F 80 02            [24]  872 	sjmp	00126$
      008291                        873 00125$:
      008291 8A 04            [24]  874 	mov	ar4,r2
      008293                        875 00126$:
      008293 90 09 F7         [24]  876 	mov	dptr,#_change_owned_mods_10000_298
      008296 E0               [24]  877 	movx	a,@dptr
      008297 5C               [12]  878 	anl	a,r4
      008298 F0               [24]  879 	movx	@dptr,a
      008299                        880 00102$:
                                    881 ;	quantum/action_util.c:95: uint8_t result = 0;
      008299 90 09 F8         [24]  882 	mov	dptr,#_change_owned_result_10001_302
      00829C E4               [12]  883 	clr	a
      00829D F0               [24]  884 	movx	@dptr,a
                                    885 ;	quantum/action_util.c:96: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      00829E 90 09 F9         [24]  886 	mov	dptr,#_change_owned_bit_20001_303
      0082A1 04               [12]  887 	inc	a
      0082A2 F0               [24]  888 	movx	@dptr,a
      0082A3 90 09 F7         [24]  889 	mov	dptr,#_change_owned_mods_10000_298
      0082A6 E0               [24]  890 	movx	a,@dptr
      0082A7 FC               [12]  891 	mov	r4,a
      0082A8 7B 00            [12]  892 	mov	r3,#0x00
      0082AA                        893 00117$:
      0082AA BB 08 00         [24]  894 	cjne	r3,#0x08,00210$
      0082AD                        895 00210$:
      0082AD 50 3F            [24]  896 	jnc	00112$
                                    897 ;	quantum/action_util.c:97: if (mods & bit) {
      0082AF 90 09 F9         [24]  898 	mov	dptr,#_change_owned_bit_20001_303
      0082B2 E0               [24]  899 	movx	a,@dptr
      0082B3 5C               [12]  900 	anl	a,r4
      0082B4 60 1C            [24]  901 	jz	00109$
                                    902 ;	quantum/action_util.c:98: if (pressed) ++refs[i];
      0082B6 E5 55            [12]  903 	mov	a,_change_owned_sloc1_1_0
      0082B8 60 0C            [24]  904 	jz	00106$
      0082BA EB               [12]  905 	mov	a,r3
      0082BB 2D               [12]  906 	add	a, r5
      0082BC 12 3A 67         [24]  907 	lcall	_ak820_outline_0017
      0082BF F8               [12]  908 	mov	r0,a
      0082C0 08               [12]  909 	inc	r0
      0082C1 12 87 08         [24]  910 	lcall	_ak820_outline_0064
      0082C4 80 0C            [24]  911 	sjmp	00109$
      0082C6                        912 00106$:
                                    913 ;	quantum/action_util.c:99: else if (refs[i]) --refs[i];
      0082C6 EB               [12]  914 	mov	a,r3
      0082C7 2D               [12]  915 	add	a, r5
      0082C8 12 3A 67         [24]  916 	lcall	_ak820_outline_0017
      0082CB F8               [12]  917 	mov	r0,a
      0082CC 60 04            [24]  918 	jz	00109$
      0082CE 18               [12]  919 	dec	r0
      0082CF 12 87 08         [24]  920 	lcall	_ak820_outline_0064
      0082D2                        921 00109$:
                                    922 ;	quantum/action_util.c:101: if (refs[i]) result |= bit;
      0082D2 EB               [12]  923 	mov	a,r3
      0082D3 2D               [12]  924 	add	a, r5
      0082D4 12 3A 67         [24]  925 	lcall	_ak820_outline_0017
      0082D7 60 0B            [24]  926 	jz	00118$
      0082D9 90 09 F9         [24]  927 	mov	dptr,#_change_owned_bit_20001_303
      0082DC E0               [24]  928 	movx	a,@dptr
      0082DD FA               [12]  929 	mov	r2,a
      0082DE 90 09 F8         [24]  930 	mov	dptr,#_change_owned_result_10001_302
      0082E1 E0               [24]  931 	movx	a,@dptr
      0082E2 4A               [12]  932 	orl	a,r2
      0082E3 F0               [24]  933 	movx	@dptr,a
      0082E4                        934 00118$:
                                    935 ;	quantum/action_util.c:96: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      0082E4 0B               [12]  936 	inc	r3
      0082E5 90 09 F9         [24]  937 	mov	dptr,#_change_owned_bit_20001_303
      0082E8 E0               [24]  938 	movx	a,@dptr
      0082E9 25 E0            [12]  939 	add	a,acc
      0082EB F0               [24]  940 	movx	@dptr,a
      0082EC 80 BC            [24]  941 	sjmp	00117$
      0082EE                        942 00112$:
                                    943 ;	quantum/action_util.c:103: if (kind) owned_weak_mods = result;
      0082EE EE               [12]  944 	mov	a,r6
      0082EF 60 09            [24]  945 	jz	00114$
      0082F1 90 09 F8         [24]  946 	mov	dptr,#_change_owned_result_10001_302
      0082F4 E0               [24]  947 	movx	a,@dptr
      0082F5 90 09 ED         [24]  948 	mov	dptr,#_owned_weak_mods
      0082F8 F0               [24]  949 	movx	@dptr,a
      0082F9 22               [24]  950 	ret
      0082FA                        951 00114$:
                                    952 ;	quantum/action_util.c:104: else owned_mods = result;
      0082FA 90 09 F8         [24]  953 	mov	dptr,#_change_owned_result_10001_302
      0082FD E0               [24]  954 	movx	a,@dptr
      0082FE 90 09 EC         [24]  955 	mov	dptr,#_owned_mods
      008301 F0               [24]  956 	movx	@dptr,a
                                    957 ;	quantum/action_util.c:105: }
      008302 22               [24]  958 	ret
                                    959 ;------------------------------------------------------------
                                    960 ;Allocation info for local variables in function 'add_owned_mods'
                                    961 ;------------------------------------------------------------
                                    962 ;mods          Allocated with name '_add_owned_mods_mods_10000_311'
                                    963 ;------------------------------------------------------------
                                    964 ;	quantum/action_util.c:106: void add_owned_mods(uint8_t mods) { change_owned(mods, 1); }
                                    965 ;	-----------------------------------------
                                    966 ;	 function add_owned_mods
                                    967 ;	-----------------------------------------
      008303                        968 _add_owned_mods:
      008303 E5 82            [12]  969 	mov	a,dpl
      008305 90 09 FA         [24]  970 	mov	dptr,#_add_owned_mods_mods_10000_311
      008308 12 87 28         [24]  971 	lcall	_ak820_outline_0119
      00830B 74 01            [12]  972 	mov	a,#0x01
      00830D F0               [24]  973 	movx	@dptr,a
      00830E 8F 82            [24]  974 	mov	dpl, r7
      008310 41 34            [12]  975 	ajmp	_change_owned
                                    976 ;------------------------------------------------------------
                                    977 ;Allocation info for local variables in function 'del_owned_mods'
                                    978 ;------------------------------------------------------------
                                    979 ;mods          Allocated with name '_del_owned_mods_mods_10000_313'
                                    980 ;------------------------------------------------------------
                                    981 ;	quantum/action_util.c:107: void del_owned_mods(uint8_t mods) { change_owned(mods, 0); }
                                    982 ;	-----------------------------------------
                                    983 ;	 function del_owned_mods
                                    984 ;	-----------------------------------------
      008312                        985 _del_owned_mods:
      008312 E5 82            [12]  986 	mov	a,dpl
      008314 90 09 FB         [24]  987 	mov	dptr,#_del_owned_mods_mods_10000_313
      008317 12 87 28         [24]  988 	lcall	_ak820_outline_0119
      00831A 12 7D C2         [24]  989 	lcall	_ak820_outline_0190
      00831D 41 34            [12]  990 	ajmp	_change_owned
                                    991 ;------------------------------------------------------------
                                    992 ;Allocation info for local variables in function 'add_owned_weak_mods'
                                    993 ;------------------------------------------------------------
                                    994 ;mods          Allocated with name '_add_owned_weak_mods_mods_10000_315'
                                    995 ;------------------------------------------------------------
                                    996 ;	quantum/action_util.c:108: void add_owned_weak_mods(uint8_t mods) { change_owned(mods, 3); }
                                    997 ;	-----------------------------------------
                                    998 ;	 function add_owned_weak_mods
                                    999 ;	-----------------------------------------
      00831F                       1000 _add_owned_weak_mods:
      00831F E5 82            [12] 1001 	mov	a,dpl
      008321 90 09 FC         [24] 1002 	mov	dptr,#_add_owned_weak_mods_mods_10000_315
      008324 12 87 28         [24] 1003 	lcall	_ak820_outline_0119
      008327 74 03            [12] 1004 	mov	a,#0x03
      008329 F0               [24] 1005 	movx	@dptr,a
      00832A 8F 82            [24] 1006 	mov	dpl, r7
      00832C 41 34            [12] 1007 	ajmp	_change_owned
                                   1008 ;------------------------------------------------------------
                                   1009 ;Allocation info for local variables in function 'del_owned_weak_mods'
                                   1010 ;------------------------------------------------------------
                                   1011 ;mods          Allocated with name '_del_owned_weak_mods_mods_10000_317'
                                   1012 ;------------------------------------------------------------
                                   1013 ;	quantum/action_util.c:109: void del_owned_weak_mods(uint8_t mods) { change_owned(mods, 2); }
                                   1014 ;	-----------------------------------------
                                   1015 ;	 function del_owned_weak_mods
                                   1016 ;	-----------------------------------------
      00832E                       1017 _del_owned_weak_mods:
      00832E E5 82            [12] 1018 	mov	a,dpl
      008330 90 09 FD         [24] 1019 	mov	dptr,#_del_owned_weak_mods_mods_10000_317
      008333 12 87 28         [24] 1020 	lcall	_ak820_outline_0119
      008336 74 02            [12] 1021 	mov	a,#0x02
      008338 F0               [24] 1022 	movx	@dptr,a
      008339 8F 82            [24] 1023 	mov	dpl, r7
      00833B 41 34            [12] 1024 	ajmp	_change_owned
                                   1025 ;------------------------------------------------------------
                                   1026 ;Allocation info for local variables in function 'clear_owned_mods'
                                   1027 ;------------------------------------------------------------
                                   1028 ;i             Allocated with name '_clear_owned_mods_i_20000_321'
                                   1029 ;------------------------------------------------------------
                                   1030 ;	quantum/action_util.c:110: void clear_owned_mods(void) {
                                   1031 ;	-----------------------------------------
                                   1032 ;	 function clear_owned_mods
                                   1033 ;	-----------------------------------------
      00833D                       1034 _clear_owned_mods:
                                   1035 ;	quantum/action_util.c:111: for (uint8_t i = 0; i < 8; ++i) owned_mod_refs[i] = owned_weak_refs[i] = 0;
      00833D 7F 00            [12] 1036 	mov	r7,#0x00
      00833F                       1037 00103$:
      00833F BF 08 00         [24] 1038 	cjne	r7,#0x08,00122$
      008342                       1039 00122$:
      008342 50 1A            [24] 1040 	jnc	00101$
      008344 EF               [12] 1041 	mov	a,r7
      008345 24 DC            [12] 1042 	add	a, #_owned_mod_refs
      008347 FD               [12] 1043 	mov	r5,a
      008348 E4               [12] 1044 	clr	a
      008349 34 09            [12] 1045 	addc	a, #(_owned_mod_refs >> 8)
      00834B FE               [12] 1046 	mov	r6,a
      00834C EF               [12] 1047 	mov	a,r7
      00834D 24 E4            [12] 1048 	add	a, #_owned_weak_refs
      00834F F5 82            [12] 1049 	mov	dpl,a
      008351 E4               [12] 1050 	clr	a
      008352 34 09            [12] 1051 	addc	a, #(_owned_weak_refs >> 8)
      008354 F5 83            [12] 1052 	mov	dph,a
      008356 E4               [12] 1053 	clr	a
      008357 F0               [24] 1054 	movx	@dptr,a
      008358 12 87 2F         [24] 1055 	lcall	_ak820_outline_0123
      00835B 0F               [12] 1056 	inc	r7
      00835C 80 E1            [24] 1057 	sjmp	00103$
      00835E                       1058 00101$:
                                   1059 ;	quantum/action_util.c:112: owned_mods = owned_weak_mods = macro_mods[0] = macro_mods[1] = 0;
      00835E 90 09 EF         [24] 1060 	mov	dptr,#(_macro_mods + 0x0001)
      008361 E4               [12] 1061 	clr	a
      008362 F0               [24] 1062 	movx	@dptr,a
      008363 90 09 EE         [24] 1063 	mov	dptr,#_macro_mods
      008366 F0               [24] 1064 	movx	@dptr,a
      008367 90 09 ED         [24] 1065 	mov	dptr,#_owned_weak_mods
      00836A F0               [24] 1066 	movx	@dptr,a
      00836B 90 09 EC         [24] 1067 	mov	dptr,#_owned_mods
      00836E F0               [24] 1068 	movx	@dptr,a
                                   1069 ;	quantum/action_util.c:113: ak820_macro_cancelled = true;
      00836F 90 09 F1         [24] 1070 	mov	dptr,#_ak820_macro_cancelled
      008372 04               [12] 1071 	inc	a
      008373 F0               [24] 1072 	movx	@dptr,a
                                   1073 ;	quantum/action_util.c:114: }
      008374 22               [24] 1074 	ret
                                   1075 ;------------------------------------------------------------
                                   1076 ;Allocation info for local variables in function 'clear_owned_keys'
                                   1077 ;------------------------------------------------------------
                                   1078 ;i             Allocated with name '_clear_owned_keys_i_20000_324'
                                   1079 ;i             Allocated with name '_clear_owned_keys_i_20000_325'
                                   1080 ;------------------------------------------------------------
                                   1081 ;	quantum/action_util.c:120: void clear_owned_keys(void) {
                                   1082 ;	-----------------------------------------
                                   1083 ;	 function clear_owned_keys
                                   1084 ;	-----------------------------------------
      008375                       1085 _clear_owned_keys:
                                   1086 ;	quantum/action_util.c:121: for (uint8_t i = 0; i <= KC_EXSEL; ++i) key_refs[i] = 0;
      008375 7F 00            [12] 1087 	mov	r7,#0x00
      008377                       1088 00104$:
      008377 EF               [12] 1089 	mov	a,r7
      008378 24 5B            [12] 1090 	add	a,#0xff - 0xa4
      00837A 40 0D            [24] 1091 	jc	00101$
                                   1092 ;	free result
      00837C EF               [12] 1093 	mov	a,r7
      00837D 24 FE            [12] 1094 	add	a, #_key_refs
      00837F F5 82            [12] 1095 	mov	dpl,a
      008381 E4               [12] 1096 	clr	a
      008382 34 09            [12] 1097 	addc	a, #(_key_refs >> 8)
      008384 12 81 B9         [24] 1098 	lcall	_ak820_outline_0165
      008387 80 EE            [24] 1099 	sjmp	00104$
      008389                       1100 00101$:
                                   1101 ;	quantum/action_util.c:122: distinct_keys = 0;
      008389 90 0A A3         [24] 1102 	mov	dptr,#_distinct_keys
      00838C E4               [12] 1103 	clr	a
      00838D F0               [24] 1104 	movx	@dptr,a
                                   1105 ;	quantum/action_util.c:123: for (uint8_t i = 0; i < sizeof(macro_keys); ++i) macro_keys[i] = 0;
      00838E FF               [12] 1106 	mov	r7,a
      00838F                       1107 00107$:
      00838F BF 15 00         [24] 1108 	cjne	r7,#0x15,00142$
      008392                       1109 00142$:
      008392 50 0D            [24] 1110 	jnc	00109$
      008394 EF               [12] 1111 	mov	a,r7
      008395 24 A4            [12] 1112 	add	a, #_macro_keys
      008397 F5 82            [12] 1113 	mov	dpl,a
      008399 E4               [12] 1114 	clr	a
      00839A 34 0A            [12] 1115 	addc	a, #(_macro_keys >> 8)
      00839C 12 81 B9         [24] 1116 	lcall	_ak820_outline_0165
      00839F 80 EE            [24] 1117 	sjmp	00107$
      0083A1                       1118 00109$:
                                   1119 ;	quantum/action_util.c:124: }
      0083A1 22               [24] 1120 	ret
                                   1121 ;------------------------------------------------------------
                                   1122 ;Allocation info for local variables in function 'add_owned_key'
                                   1123 ;------------------------------------------------------------
                                   1124 ;code          Allocated with name '_add_owned_key_code_10000_326'
                                   1125 ;__400000074   Allocated with name '_add_owned_key___400000074_40000_335'
                                   1126 ;key           Allocated with name '_add_owned_key_key_50000_336'
                                   1127 ;i             Allocated with name '_add_owned_key_i_40000_334'
                                   1128 ;__300000076   Allocated with name '_add_owned_key___300000076_30000_338'
                                   1129 ;key           Allocated with name '_add_owned_key_key_40000_339'
                                   1130 ;------------------------------------------------------------
                                   1131 ;	quantum/action_util.c:125: bool add_owned_key(uint8_t code) {
                                   1132 ;	-----------------------------------------
                                   1133 ;	 function add_owned_key
                                   1134 ;	-----------------------------------------
      0083A2                       1135 _add_owned_key:
      0083A2 E5 82            [12] 1136 	mov	a,dpl
      0083A4 90 0A B9         [24] 1137 	mov	dptr,#_add_owned_key_code_10000_326
      0083A7 12 87 40         [24] 1138 	lcall	_ak820_outline_0135
                                   1139 ;	quantum/action_util.c:126: if (!ak820_macro_change(macro_keys, code, true)) return false;
      0083AA 74 01            [12] 1140 	mov	a,#0x01
      0083AC F0               [24] 1141 	movx	@dptr,a
      0083AD 90 0A A4         [24] 1142 	mov	dptr,#_macro_keys
      0083B0 C0 07            [24] 1143 	push	ar7
      0083B2 31 C8            [12] 1144 	acall	_ak820_macro_change
      0083B4 E5 82            [12] 1145 	mov	a, dpl
      0083B6 D0 07            [24] 1146 	pop	ar7
      0083B8 70 03            [24] 1147 	jnz	00102$
      0083BA F5 82            [12] 1148 	mov	dpl,a
      0083BC 22               [24] 1149 	ret
      0083BD                       1150 00102$:
                                   1151 ;	quantum/action_util.c:127: if (key_refs[code]++) return false;
      0083BD 12 86 F2         [24] 1152 	lcall	_ak820_outline_0030
      0083C0 FC               [12] 1153 	mov	r4,a
      0083C1 04               [12] 1154 	inc	a
      0083C2 12 87 2F         [24] 1155 	lcall	_ak820_outline_0123
      0083C5 EC               [12] 1156 	mov	a,r4
      0083C6 60 04            [24] 1157 	jz	00104$
      0083C8 75 82 00         [24] 1158 	mov	dpl, #0x00
      0083CB 22               [24] 1159 	ret
      0083CC                       1160 00104$:
                                   1161 ;	quantum/action_util.c:128: ++distinct_keys;
      0083CC 90 0A A3         [24] 1162 	mov	dptr,#_distinct_keys
      0083CF E0               [24] 1163 	movx	a,@dptr
      0083D0 24 01            [12] 1164 	add	a, #0x01
      0083D2 F0               [24] 1165 	movx	@dptr,a
                                   1166 ;	quantum/action_util.c:130: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      0083D3 90 0E 1D         [24] 1167 	mov	dptr,#_keyboard_protocol
      0083D6 E0               [24] 1168 	movx	a,@dptr
      0083D7 60 15            [24] 1169 	jz	00106$
      0083D9 90 0B 28         [24] 1170 	mov	dptr,#_keymap_config
      0083DC E0               [24] 1171 	movx	a,@dptr
      0083DD 30 E7 0E         [24] 1172 	jnb	acc.7,00106$
                                   1173 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      0083E0 90 08 69         [24] 1174 	mov	dptr,#_add_key_to_report_PARM_2
      0083E3 EF               [12] 1175 	mov	a,r7
      0083E4 12 87 00         [24] 1176 	lcall	_ak820_outline_0059
      0083E7 12 74 46         [24] 1177 	lcall	_add_key_to_report
                                   1178 ;	quantum/action_util.c:130: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      0083EA 75 82 01         [24] 1179 	mov	dpl, #0x01
      0083ED 22               [24] 1180 	ret
      0083EE                       1181 00106$:
                                   1182 ;	quantum/action_util.c:132: if (distinct_keys > KEYBOARD_REPORT_KEYS) {
      0083EE 90 0A A3         [24] 1183 	mov	dptr,#_distinct_keys
      0083F1 E0               [24] 1184 	movx	a,@dptr
      0083F2 24 F9            [12] 1185 	add	a,#0xff - 0x06
      0083F4 50 17            [24] 1186 	jnc	00110$
                                   1187 ;	free result
                                   1188 ;	quantum/action_util.c:133: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; ++i) keyboard_report->keys[i] = 1; /* HID ErrorRollOver */
      0083F6 7F 00            [12] 1189 	mov	r7,#0x00
      0083F8                       1190 00115$:
      0083F8 BF 06 00         [24] 1191 	cjne	r7,#0x06,00174$
      0083FB                       1192 00174$:
      0083FB 50 1D            [24] 1193 	jnc	00111$
      0083FD EF               [12] 1194 	mov	a,r7
      0083FE 24 32            [12] 1195 	add	a, #(_actual_keyboard_report + 0x0002)
      008400 F5 82            [12] 1196 	mov	dpl,a
      008402 E4               [12] 1197 	clr	a
      008403 34 0E            [12] 1198 	addc	a, #((_actual_keyboard_report + 0x0002) >> 8)
      008405 F5 83            [12] 1199 	mov	dph,a
      008407 74 01            [12] 1200 	mov	a,#0x01
      008409 F0               [24] 1201 	movx	@dptr,a
      00840A 0F               [12] 1202 	inc	r7
      00840B 80 EB            [24] 1203 	sjmp	00115$
      00840D                       1204 00110$:
                                   1205 ;	quantum/action_util.c:134: } else add_key(code);
      00840D 90 0A B9         [24] 1206 	mov	dptr,#_add_owned_key_code_10000_326
      008410 E0               [24] 1207 	movx	a,@dptr
                                   1208 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      008411 90 08 69         [24] 1209 	mov	dptr,#_add_key_to_report_PARM_2
      008414 12 87 00         [24] 1210 	lcall	_ak820_outline_0059
      008417 12 74 46         [24] 1211 	lcall	_add_key_to_report
                                   1212 ;	quantum/action_util.c:134: } else add_key(code);
      00841A                       1213 00111$:
                                   1214 ;	quantum/action_util.c:135: return true;
      00841A 75 82 01         [24] 1215 	mov	dpl, #0x01
                                   1216 ;	quantum/action_util.c:136: }
      00841D 22               [24] 1217 	ret
                                   1218 ;------------------------------------------------------------
                                   1219 ;Allocation info for local variables in function 'del_owned_key'
                                   1220 ;------------------------------------------------------------
                                   1221 ;code          Allocated with name '_del_owned_key_code_10000_341'
                                   1222 ;__400000078   Allocated with name '_del_owned_key___400000078_40000_352'
                                   1223 ;key           Allocated with name '_del_owned_key_key_50000_353'
                                   1224 ;key           Allocated with name '_del_owned_key_key_40000_350'
                                   1225 ;__600000081   Allocated with name '_del_owned_key___600000081_60000_358'
                                   1226 ;key           Allocated with name '_del_owned_key_key_70000_359'
                                   1227 ;__300000083   Allocated with name '_del_owned_key___300000083_30000_361'
                                   1228 ;key           Allocated with name '_del_owned_key_key_40000_362'
                                   1229 ;------------------------------------------------------------
                                   1230 ;	quantum/action_util.c:137: bool del_owned_key(uint8_t code) {
                                   1231 ;	-----------------------------------------
                                   1232 ;	 function del_owned_key
                                   1233 ;	-----------------------------------------
      00841E                       1234 _del_owned_key:
      00841E E5 82            [12] 1235 	mov	a,dpl
      008420 90 0A BA         [24] 1236 	mov	dptr,#_del_owned_key_code_10000_341
      008423 12 87 40         [24] 1237 	lcall	_ak820_outline_0135
                                   1238 ;	quantum/action_util.c:138: if (!ak820_macro_change(macro_keys, code, false)) return false;
      008426 E4               [12] 1239 	clr	a
      008427 F0               [24] 1240 	movx	@dptr,a
      008428 90 0A A4         [24] 1241 	mov	dptr,#_macro_keys
      00842B C0 07            [24] 1242 	push	ar7
      00842D 31 C8            [12] 1243 	acall	_ak820_macro_change
      00842F E5 82            [12] 1244 	mov	a, dpl
      008431 D0 07            [24] 1245 	pop	ar7
      008433 70 03            [24] 1246 	jnz	00102$
      008435 F5 82            [12] 1247 	mov	dpl,a
      008437 22               [24] 1248 	ret
      008438                       1249 00102$:
                                   1250 ;	quantum/action_util.c:139: if (!key_refs[code] || --key_refs[code]) return false;
      008438 12 86 F2         [24] 1251 	lcall	_ak820_outline_0030
      00843B FC               [12] 1252 	mov	r4,a
      00843C 60 07            [24] 1253 	jz	00103$
      00843E 1C               [12] 1254 	dec	r4
      00843F 12 48 C4         [24] 1255 	lcall	_ak820_outline_0065
      008442 EC               [12] 1256 	mov	a,r4
      008443 60 04            [24] 1257 	jz	00104$
      008445                       1258 00103$:
      008445 75 82 00         [24] 1259 	mov	dpl, #0x00
      008448 22               [24] 1260 	ret
      008449                       1261 00104$:
                                   1262 ;	quantum/action_util.c:140: --distinct_keys;
      008449 90 0A A3         [24] 1263 	mov	dptr,#_distinct_keys
      00844C E0               [24] 1264 	movx	a,@dptr
      00844D 14               [12] 1265 	dec	a
      00844E F0               [24] 1266 	movx	@dptr,a
                                   1267 ;	quantum/action_util.c:142: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      00844F 90 0E 1D         [24] 1268 	mov	dptr,#_keyboard_protocol
      008452 E0               [24] 1269 	movx	a,@dptr
      008453 60 15            [24] 1270 	jz	00107$
      008455 90 0B 28         [24] 1271 	mov	dptr,#_keymap_config
      008458 E0               [24] 1272 	movx	a,@dptr
      008459 30 E7 0E         [24] 1273 	jnb	acc.7,00107$
                                   1274 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      00845C 90 08 6D         [24] 1275 	mov	dptr,#_del_key_from_report_PARM_2
      00845F EF               [12] 1276 	mov	a,r7
      008460 12 87 00         [24] 1277 	lcall	_ak820_outline_0059
      008463 12 74 81         [24] 1278 	lcall	_del_key_from_report
                                   1279 ;	quantum/action_util.c:142: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      008466 75 82 01         [24] 1280 	mov	dpl, #0x01
      008469 22               [24] 1281 	ret
      00846A                       1282 00107$:
                                   1283 ;	quantum/action_util.c:144: if (distinct_keys > KEYBOARD_REPORT_KEYS) return true;
      00846A 90 0A A3         [24] 1284 	mov	dptr,#_distinct_keys
      00846D E0               [24] 1285 	movx	a,@dptr
      00846E FF               [12] 1286 	mov  r7,a
      00846F 24 F9            [12] 1287 	add	a,#0xff - 0x06
      008471 50 04            [24] 1288 	jnc	00110$
                                   1289 ;	free result
      008473 75 82 01         [24] 1290 	mov	dpl, #0x01
      008476 22               [24] 1291 	ret
      008477                       1292 00110$:
                                   1293 ;	quantum/action_util.c:145: if (distinct_keys == KEYBOARD_REPORT_KEYS) {
      008477 BF 06 26         [24] 1294 	cjne	r7,#0x06,00115$
                                   1295 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      00847A 90 0E 30         [24] 1296 	mov	dptr,#_actual_keyboard_report
      00847D 75 F0 00         [24] 1297 	mov	b, #0x00
      008480 12 74 BC         [24] 1298 	lcall	_clear_keys_from_report
                                   1299 ;	quantum/action_util.c:148: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      008483 7F 04            [12] 1300 	mov	r7,#0x04
      008485                       1301 00122$:
      008485 EF               [12] 1302 	mov	a,r7
      008486 24 5B            [12] 1303 	add	a,#0xff - 0xa4
      008488 40 23            [24] 1304 	jc	00116$
                                   1305 ;	free result
      00848A 12 86 F2         [24] 1306 	lcall	_ak820_outline_0030
      00848D 60 0E            [24] 1307 	jz	00123$
                                   1308 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      00848F 90 08 69         [24] 1309 	mov	dptr,#_add_key_to_report_PARM_2
      008492 EF               [12] 1310 	mov	a,r7
      008493 12 87 00         [24] 1311 	lcall	_ak820_outline_0059
      008496 C0 07            [24] 1312 	push	ar7
      008498 12 74 46         [24] 1313 	lcall	_add_key_to_report
      00849B D0 07            [24] 1314 	pop	ar7
                                   1315 ;	quantum/action_util.c:148: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      00849D                       1316 00123$:
      00849D 0F               [12] 1317 	inc	r7
      00849E 80 E5            [24] 1318 	sjmp	00122$
      0084A0                       1319 00115$:
                                   1320 ;	quantum/action_util.c:149: } else del_key(code);
      0084A0 90 0A BA         [24] 1321 	mov	dptr,#_del_owned_key_code_10000_341
      0084A3 E0               [24] 1322 	movx	a,@dptr
                                   1323 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      0084A4 90 08 6D         [24] 1324 	mov	dptr,#_del_key_from_report_PARM_2
      0084A7 12 87 00         [24] 1325 	lcall	_ak820_outline_0059
      0084AA 12 74 81         [24] 1326 	lcall	_del_key_from_report
                                   1327 ;	quantum/action_util.c:149: } else del_key(code);
      0084AD                       1328 00116$:
                                   1329 ;	quantum/action_util.c:150: return true;
      0084AD 75 82 01         [24] 1330 	mov	dpl, #0x01
                                   1331 ;	quantum/action_util.c:151: }
      0084B0 22               [24] 1332 	ret
                                   1333 ;------------------------------------------------------------
                                   1334 ;Allocation info for local variables in function 'clear_owned_usages'
                                   1335 ;------------------------------------------------------------
                                   1336 ;i             Allocated with name '_clear_owned_usages_i_20000_366'
                                   1337 ;i             Allocated with name '_clear_owned_usages_i_20000_367'
                                   1338 ;------------------------------------------------------------
                                   1339 ;	quantum/action_util.c:161: void clear_owned_usages(void) {
                                   1340 ;	-----------------------------------------
                                   1341 ;	 function clear_owned_usages
                                   1342 ;	-----------------------------------------
      0084B1                       1343 _clear_owned_usages:
                                   1344 ;	quantum/action_util.c:162: for (uint8_t i = 0; i < USAGE_COUNT; ++i) usage_refs[i] = usage_order[i] = 0;
      0084B1 7F 00            [12] 1345 	mov	r7,#0x00
      0084B3                       1346 00104$:
      0084B3 BF 1E 00         [24] 1347 	cjne	r7,#0x1e,00141$
      0084B6                       1348 00141$:
      0084B6 50 14            [24] 1349 	jnc	00101$
      0084B8 EF               [12] 1350 	mov	a,r7
      0084B9 24 BB            [12] 1351 	add	a, #_usage_refs
      0084BB FD               [12] 1352 	mov	r5,a
      0084BC E4               [12] 1353 	clr	a
      0084BD 34 0A            [12] 1354 	addc	a, #(_usage_refs >> 8)
      0084BF FE               [12] 1355 	mov	r6,a
      0084C0 EF               [12] 1356 	mov	a,r7
      0084C1 12 87 0F         [24] 1357 	lcall	_ak820_outline_0068
      0084C4 E4               [12] 1358 	clr	a
      0084C5 F0               [24] 1359 	movx	@dptr,a
      0084C6 12 87 2F         [24] 1360 	lcall	_ak820_outline_0123
      0084C9 0F               [12] 1361 	inc	r7
      0084CA 80 E7            [24] 1362 	sjmp	00104$
      0084CC                       1363 00101$:
                                   1364 ;	quantum/action_util.c:163: usage_lengths[0] = usage_lengths[1] = 0;
      0084CC 90 0A F8         [24] 1365 	mov	dptr,#(_usage_lengths + 0x0001)
      0084CF E4               [12] 1366 	clr	a
      0084D0 F0               [24] 1367 	movx	@dptr,a
      0084D1 90 0A F7         [24] 1368 	mov	dptr,#_usage_lengths
      0084D4 F0               [24] 1369 	movx	@dptr,a
                                   1370 ;	quantum/action_util.c:164: for (uint8_t i = 0; i < sizeof(macro_usages); ++i) macro_usages[i] = 0;
      0084D5 FF               [12] 1371 	mov	r7,a
      0084D6                       1372 00107$:
      0084D6 BF 04 00         [24] 1373 	cjne	r7,#0x04,00143$
      0084D9                       1374 00143$:
      0084D9 50 0D            [24] 1375 	jnc	00109$
      0084DB EF               [12] 1376 	mov	a,r7
      0084DC 24 F9            [12] 1377 	add	a, #_macro_usages
      0084DE F5 82            [12] 1378 	mov	dpl,a
      0084E0 E4               [12] 1379 	clr	a
      0084E1 34 0A            [12] 1380 	addc	a, #(_macro_usages >> 8)
      0084E3 12 81 B9         [24] 1381 	lcall	_ak820_outline_0165
      0084E6 80 EE            [24] 1382 	sjmp	00107$
      0084E8                       1383 00109$:
                                   1384 ;	quantum/action_util.c:165: }
      0084E8 22               [24] 1385 	ret
                                   1386 ;------------------------------------------------------------
                                   1387 ;Allocation info for local variables in function 'owned_usage_key'
                                   1388 ;------------------------------------------------------------
                                   1389 ;pressed       Allocated with name '_owned_usage_key_PARM_2'
                                   1390 ;code          Allocated with name '_owned_usage_key_code_10000_368'
                                   1391 ;__200000085   Allocated with name '_owned_usage_key___200000085_20000_369'
                                   1392 ;which         Allocated with name '_owned_usage_key_which_10000_369'
                                   1393 ;base          Allocated with name '_owned_usage_key_base_10000_369'
                                   1394 ;count         Allocated with name '_owned_usage_key_count_10000_369'
                                   1395 ;index         Allocated with name '_owned_usage_key_index_10000_369'
                                   1396 ;pos           Allocated with name '_owned_usage_key_pos_30001_376'
                                   1397 ;i             Allocated with name '_owned_usage_key_i_40001_377'
                                   1398 ;__300000086   Allocated with name '_owned_usage_key___300000086_30000_380'
                                   1399 ;key           Allocated with name '_owned_usage_key_key_40000_381'
                                   1400 ;------------------------------------------------------------
                                   1401 ;	quantum/action_util.c:166: void owned_usage_key(uint8_t code, bool pressed) {
                                   1402 ;	-----------------------------------------
                                   1403 ;	 function owned_usage_key
                                   1404 ;	-----------------------------------------
      0084E9                       1405 _owned_usage_key:
      0084E9 E5 82            [12] 1406 	mov	a,dpl
      0084EB 90 0A FE         [24] 1407 	mov	dptr,#_owned_usage_key_code_10000_368
      0084EE F0               [24] 1408 	movx	@dptr,a
                                   1409 ;	quantum/action_util.c:167: uint8_t which = code >= KC_AUDIO_MUTE;
      0084EF E0               [24] 1410 	movx	a,@dptr
      0084F0 FF               [12] 1411 	mov	r7,a
      0084F1 BF A8 00         [24] 1412 	cjne	r7,#0xa8,00244$
      0084F4                       1413 00244$:
      0084F4 B3               [12] 1414 	cpl	c
      0084F5 92 25            [24] 1415 	mov	_owned_usage_key_sloc0_1_0,c
      0084F7 E4               [12] 1416 	clr	a
      0084F8 33               [12] 1417 	rlc	a
      0084F9 FF               [12] 1418 	mov	r7,a
      0084FA 90 0B 01         [24] 1419 	mov	dptr,#_owned_usage_key_which_10000_369
      0084FD F0               [24] 1420 	movx	@dptr,a
                                   1421 ;	quantum/action_util.c:168: uint8_t base = which ? SYSTEM_COUNT : 0;
      0084FE EF               [12] 1422 	mov	a,r7
      0084FF 60 02            [24] 1423 	jz	00129$
      008501 74 03            [12] 1424 	mov	a,#0x03
      008503                       1425 00129$:
      008503 FE               [12] 1426 	mov	r6,a
                                   1427 ;	quantum/action_util.c:169: uint8_t count = usage_lengths[which];
      008504 EF               [12] 1428 	mov	a,r7
      008505 24 F7            [12] 1429 	add	a, #_usage_lengths
      008507 FD               [12] 1430 	mov	r5,a
      008508 E4               [12] 1431 	clr	a
      008509 34 0A            [12] 1432 	addc	a, #(_usage_lengths >> 8)
      00850B FF               [12] 1433 	mov	r7,a
      00850C 12 87 4B         [24] 1434 	lcall	_ak820_outline_0191
      00850F E0               [24] 1435 	movx	a,@dptr
      008510 FC               [12] 1436 	mov	r4,a
                                   1437 ;	quantum/action_util.c:170: uint8_t index = code - KC_SYSTEM_POWER;
      008511 90 0A FE         [24] 1438 	mov	dptr,#_owned_usage_key_code_10000_368
      008514 E0               [24] 1439 	movx	a,@dptr
      008515 24 5B            [12] 1440 	add	a,#0x5b
      008517 FB               [12] 1441 	mov	r3,a
                                   1442 ;	quantum/action_util.c:171: if (!ak820_macro_change(macro_usages, index, pressed)) return;
      008518 90 0A FD         [24] 1443 	mov	dptr,#_owned_usage_key_PARM_2
      00851B E0               [24] 1444 	movx	a,@dptr
      00851C FA               [12] 1445 	mov	r2,a
      00851D 90 09 F2         [24] 1446 	mov	dptr,#_ak820_macro_change_PARM_2
      008520 EB               [12] 1447 	mov	a,r3
      008521 F0               [24] 1448 	movx	@dptr,a
      008522 90 09 F3         [24] 1449 	mov	dptr,#_ak820_macro_change_PARM_3
      008525 EA               [12] 1450 	mov	a,r2
      008526 F0               [24] 1451 	movx	@dptr,a
      008527 90 0A F9         [24] 1452 	mov	dptr,#_macro_usages
      00852A C0 07            [24] 1453 	push	ar7
      00852C C0 06            [24] 1454 	push	ar6
      00852E C0 05            [24] 1455 	push	ar5
      008530 C0 04            [24] 1456 	push	ar4
      008532 C0 03            [24] 1457 	push	ar3
      008534 C0 02            [24] 1458 	push	ar2
      008536 31 C8            [12] 1459 	acall	_ak820_macro_change
      008538 E5 82            [12] 1460 	mov	a, dpl
      00853A D0 02            [24] 1461 	pop	ar2
      00853C D0 03            [24] 1462 	pop	ar3
      00853E D0 04            [24] 1463 	pop	ar4
      008540 D0 05            [24] 1464 	pop	ar5
      008542 D0 06            [24] 1465 	pop	ar6
      008544 D0 07            [24] 1466 	pop	ar7
      008546 70 01            [24] 1467 	jnz	00102$
      008548 22               [24] 1468 	ret
      008549                       1469 00102$:
                                   1470 ;	quantum/action_util.c:172: if (pressed) {
      008549 EA               [12] 1471 	mov	a,r2
      00854A 60 1A            [24] 1472 	jz	00115$
                                   1473 ;	quantum/action_util.c:173: if (usage_refs[index]++) return;
      00854C 12 87 19         [24] 1474 	lcall	_ak820_outline_0075
      00854F 04               [12] 1475 	inc	a
      008550 12 71 C5         [24] 1476 	lcall	_ak820_outline_0141
      008553 E8               [12] 1477 	mov	a,r0
      008554 60 01            [24] 1478 	jz	00104$
      008556 22               [24] 1479 	ret
      008557                       1480 00104$:
                                   1481 ;	quantum/action_util.c:174: usage_order[base + count++] = index;
      008557 90 0B 02         [24] 1482 	mov	dptr,#_owned_usage_key_count_10000_369
      00855A EC               [12] 1483 	mov	a,r4
      00855B 04               [12] 1484 	inc	a
      00855C F0               [24] 1485 	movx	@dptr,a
      00855D EC               [12] 1486 	mov	a,r4
      00855E 2E               [12] 1487 	add	a, r6
      00855F 12 87 0F         [24] 1488 	lcall	_ak820_outline_0068
      008562 EB               [12] 1489 	mov	a,r3
      008563 F0               [24] 1490 	movx	@dptr,a
      008564 A1 C7            [12] 1491 	ajmp	00116$
      008566                       1492 00115$:
                                   1493 ;	quantum/action_util.c:176: if (!usage_refs[index] || --usage_refs[index]) return;
      008566 12 87 19         [24] 1494 	lcall	_ak820_outline_0075
      008569 60 07            [24] 1495 	jz	00105$
      00856B 18               [12] 1496 	dec	r0
      00856C 12 87 08         [24] 1497 	lcall	_ak820_outline_0064
      00856F E8               [12] 1498 	mov	a,r0
      008570 60 01            [24] 1499 	jz	00106$
      008572                       1500 00105$:
      008572 22               [24] 1501 	ret
      008573                       1502 00106$:
                                   1503 ;	quantum/action_util.c:178: while (usage_order[base + pos] != index) ++pos;
      008573 7A 00            [12] 1504 	mov	r2,#0x00
      008575                       1505 00108$:
      008575 EA               [12] 1506 	mov	a,r2
      008576 2E               [12] 1507 	add	a, r6
      008577 12 87 0F         [24] 1508 	lcall	_ak820_outline_0068
      00857A E0               [24] 1509 	movx	a,@dptr
      00857B B5 03 02         [24] 1510 	cjne	a,ar3,00251$
      00857E 80 03            [24] 1511 	sjmp	00167$
      008580                       1512 00251$:
      008580 0A               [12] 1513 	inc	r2
      008581 80 F2            [24] 1514 	sjmp	00108$
      008583                       1515 00167$:
      008583 90 0B 03         [24] 1516 	mov	dptr,#_owned_usage_key_pos_30001_376
      008586 EA               [12] 1517 	mov	a,r2
      008587 F0               [24] 1518 	movx	@dptr,a
                                   1519 ;	quantum/action_util.c:179: --count;
      008588 1C               [12] 1520 	dec	r4
      008589 90 0B 02         [24] 1521 	mov	dptr,#_owned_usage_key_count_10000_369
      00858C EC               [12] 1522 	mov	a,r4
      00858D F0               [24] 1523 	movx	@dptr,a
                                   1524 ;	quantum/action_util.c:180: for (uint8_t i = pos; i < count; ++i) usage_order[base + i] = usage_order[base + i + 1];
      00858E 8A 03            [24] 1525 	mov	ar3,r2
      008590                       1526 00125$:
      008590 C3               [12] 1527 	clr	c
      008591 EB               [12] 1528 	mov	a,r3
      008592 9C               [12] 1529 	subb	a,r4
      008593 50 23            [24] 1530 	jnc	00111$
      008595 C0 05            [24] 1531 	push	ar5
      008597 C0 07            [24] 1532 	push	ar7
      008599 EB               [12] 1533 	mov	a,r3
      00859A 2E               [12] 1534 	add	a, r6
      00859B FA               [12] 1535 	mov	r2,a
      00859C 24 D9            [12] 1536 	add	a, #_usage_order
      00859E F8               [12] 1537 	mov	r0,a
      00859F E4               [12] 1538 	clr	a
      0085A0 34 0A            [12] 1539 	addc	a, #(_usage_order >> 8)
      0085A2 F9               [12] 1540 	mov	r1,a
      0085A3 0A               [12] 1541 	inc	r2
      0085A4 EA               [12] 1542 	mov	a,r2
      0085A5 33               [12] 1543 	rlc	a
      0085A6 95 E0            [12] 1544 	subb	a,acc
      0085A8 FF               [12] 1545 	mov	r7,a
      0085A9 EA               [12] 1546 	mov	a,r2
      0085AA 12 87 35         [24] 1547 	lcall	_ak820_outline_0128
      0085AD 12 3A F1         [24] 1548 	lcall	_ak820_outline_0146
      0085B0 F0               [24] 1549 	movx	@dptr,a
      0085B1 0B               [12] 1550 	inc	r3
      0085B2 D0 07            [24] 1551 	pop	ar7
      0085B4 D0 05            [24] 1552 	pop	ar5
      0085B6 80 D8            [24] 1553 	sjmp	00125$
      0085B8                       1554 00111$:
                                   1555 ;	quantum/action_util.c:181: usage_lengths[which] = count;
      0085B8 12 87 4B         [24] 1556 	lcall	_ak820_outline_0191
      0085BB EC               [12] 1557 	mov	a,r4
      0085BC F0               [24] 1558 	movx	@dptr,a
                                   1559 ;	quantum/action_util.c:182: if (pos != count) return; /* A non-winning owner changed only storage. */
      0085BD 90 0B 03         [24] 1560 	mov	dptr,#_owned_usage_key_pos_30001_376
      0085C0 E0               [24] 1561 	movx	a,@dptr
      0085C1 B5 04 02         [24] 1562 	cjne	a,ar4,00253$
      0085C4 80 01            [24] 1563 	sjmp	00116$
      0085C6                       1564 00253$:
      0085C6 22               [24] 1565 	ret
      0085C7                       1566 00116$:
                                   1567 ;	quantum/action_util.c:184: usage_lengths[which] = count;
      0085C7 90 0B 02         [24] 1568 	mov	dptr,#_owned_usage_key_count_10000_369
      0085CA E0               [24] 1569 	movx	a,@dptr
      0085CB FC               [12] 1570 	mov	r4,a
      0085CC 12 87 4B         [24] 1571 	lcall	_ak820_outline_0191
      0085CF F0               [24] 1572 	movx	@dptr,a
                                   1573 ;	quantum/action_util.c:185: code = count ? usage_order[base + count - 1] + KC_SYSTEM_POWER : 0;
      0085D0 EC               [12] 1574 	mov	a,r4
      0085D1 60 15            [24] 1575 	jz	00131$
      0085D3 EC               [12] 1576 	mov	a,r4
      0085D4 2E               [12] 1577 	add	a, r6
      0085D5 FE               [12] 1578 	mov	r6,a
      0085D6 1E               [12] 1579 	dec	r6
      0085D7 EE               [12] 1580 	mov	a,r6
      0085D8 33               [12] 1581 	rlc	a
      0085D9 95 E0            [12] 1582 	subb	a,acc
      0085DB FF               [12] 1583 	mov	r7,a
      0085DC EE               [12] 1584 	mov	a,r6
      0085DD 12 87 35         [24] 1585 	lcall	_ak820_outline_0128
      0085E0 24 A5            [12] 1586 	add	a,#0xa5
      0085E2 FE               [12] 1587 	mov	r6,a
      0085E3 33               [12] 1588 	rlc	a
      0085E4 95 E0            [12] 1589 	subb	a,acc
      0085E6 80 02            [24] 1590 	sjmp	00132$
      0085E8                       1591 00131$:
      0085E8 7E 00            [12] 1592 	mov	r6,#0x00
      0085EA                       1593 00132$:
      0085EA 90 0A FE         [24] 1594 	mov	dptr,#_owned_usage_key_code_10000_368
      0085ED EE               [12] 1595 	mov	a,r6
      0085EE F0               [24] 1596 	movx	@dptr,a
                                   1597 ;	quantum/action_util.c:186: if (which) host_consumer_send(code ? KEYCODE2CONSUMER(code) : 0);
      0085EF 90 0B 01         [24] 1598 	mov	dptr,#_owned_usage_key_which_10000_369
      0085F2 E0               [24] 1599 	movx	a,@dptr
      0085F3 60 18            [24] 1600 	jz	00118$
      0085F5 EE               [12] 1601 	mov	a,r6
      0085F6 60 0B            [24] 1602 	jz	00133$
      0085F8 8E 82            [24] 1603 	mov	dpl, r6
      0085FA 12 73 03         [24] 1604 	lcall	_KEYCODE2CONSUMER
      0085FD AD 82            [24] 1605 	mov	r5, dpl
      0085FF AF 83            [24] 1606 	mov	r7, dph
      008601 80 04            [24] 1607 	sjmp	00134$
      008603                       1608 00133$:
      008603 7D 00            [12] 1609 	mov	r5,#0x00
      008605 7F 00            [12] 1610 	mov	r7,#0x00
      008607                       1611 00134$:
      008607 12 87 4B         [24] 1612 	lcall	_ak820_outline_0191
      00860A 02 72 B7         [24] 1613 	ljmp	_host_consumer_send
      00860D                       1614 00118$:
                                   1615 ;	quantum/action_util.c:187: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      00860D EE               [12] 1616 	mov	a,r6
      00860E 60 22            [24] 1617 	jz	00135$
                                   1618 ;	tmk_core/protocol/report.h:264: if (key < KC_SYSTEM_POWER || key > KC_SYSTEM_WAKE) return 0;
      008610 BE A5 00         [24] 1619 	cjne	r6,#0xa5,00258$
      008613                       1620 00258$:
      008613 40 05            [24] 1621 	jc	00121$
      008615 EE               [12] 1622 	mov	a,r6
      008616 24 58            [12] 1623 	add	a,#0xff - 0xa7
      008618 50 08            [24] 1624 	jnc	00122$
                                   1625 ;	free result
      00861A                       1626 00121$:
      00861A 90 0A FF         [24] 1627 	mov	dptr,#_owned_usage_key___200000085_20000_369
      00861D 12 54 D7         [24] 1628 	lcall	_ak820_outline_0183
      008620 80 09            [24] 1629 	sjmp	00123$
      008622                       1630 00122$:
                                   1631 ;	tmk_core/protocol/report.h:265: return SYSTEM_POWER_DOWN + (key - KC_SYSTEM_POWER);
      008622 74 DC            [12] 1632 	mov	a,#0xdc
      008624 2E               [12] 1633 	add	a, r6
      008625 90 0A FF         [24] 1634 	mov	dptr,#_owned_usage_key___200000085_20000_369
      008628 12 3A DC         [24] 1635 	lcall	_ak820_outline_0136
                                   1636 ;	quantum/action_util.c:187: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      00862B                       1637 00123$:
      00862B 90 0A FF         [24] 1638 	mov	dptr,#_owned_usage_key___200000085_20000_369
      00862E E0               [24] 1639 	movx	a,@dptr
      00862F FF               [12] 1640 	mov	r7,a
      008630 80 02            [24] 1641 	sjmp	00136$
      008632                       1642 00135$:
      008632 7F 00            [12] 1643 	mov	r7,#0x00
      008634                       1644 00136$:
      008634 7E 00            [12] 1645 	mov	r6,#0x00
      008636 12 48 FF         [24] 1646 	lcall	_ak820_outline_0160
                                   1647 ;	quantum/action_util.c:188: }
      008639 02 72 88         [24] 1648 	ljmp	_host_system_send
                                   1649 ;------------------------------------------------------------
                                   1650 ;Allocation info for local variables in function 'send_keyboard_report'
                                   1651 ;------------------------------------------------------------
                                   1652 ;last_report   Allocated with name '_send_keyboard_report_last_report_10001_388'
                                   1653 ;changed       Allocated with name '_send_keyboard_report_changed_10001_388'
                                   1654 ;dest          Allocated with name '_send_keyboard_report_dest_10001_388'
                                   1655 ;src           Allocated with name '_send_keyboard_report_src_10001_388'
                                   1656 ;i             Allocated with name '_send_keyboard_report_i_20001_389'
                                   1657 ;------------------------------------------------------------
                                   1658 ;	quantum/action_util.c:410: void send_keyboard_report(void) {
                                   1659 ;	-----------------------------------------
                                   1660 ;	 function send_keyboard_report
                                   1661 ;	-----------------------------------------
      00863C                       1662 _send_keyboard_report:
                                   1663 ;	quantum/action_util.c:411: keyboard_report->mods = real_mods;
      00863C 90 0E 2E         [24] 1664 	mov	dptr,#_real_mods
      00863F E0               [24] 1665 	movx	a,@dptr
      008640 FF               [12] 1666 	mov	r7,a
      008641 90 0E 30         [24] 1667 	mov	dptr,#_actual_keyboard_report
      008644 F0               [24] 1668 	movx	@dptr,a
                                   1669 ;	quantum/action_util.c:412: keyboard_report->mods |= weak_mods;
      008645 90 0E 2F         [24] 1670 	mov	dptr,#_weak_mods
      008648 E0               [24] 1671 	movx	a,@dptr
      008649 42 07            [12] 1672 	orl	ar7,a
      00864B 90 0E 30         [24] 1673 	mov	dptr,#_actual_keyboard_report
      00864E EF               [12] 1674 	mov	a,r7
      00864F F0               [24] 1675 	movx	@dptr,a
                                   1676 ;	quantum/action_util.c:414: keyboard_report->mods |= owned_mods | owned_weak_mods;
      008650 90 09 ED         [24] 1677 	mov	dptr,#_owned_weak_mods
      008653 E0               [24] 1678 	movx	a,@dptr
      008654 FE               [12] 1679 	mov	r6,a
      008655 90 09 EC         [24] 1680 	mov	dptr,#_owned_mods
      008658 E0               [24] 1681 	movx	a,@dptr
      008659 4E               [12] 1682 	orl	a,r6
      00865A 42 07            [12] 1683 	orl	ar7,a
      00865C 90 0E 30         [24] 1684 	mov	dptr,#_actual_keyboard_report
      00865F EF               [12] 1685 	mov	a,r7
      008660 F0               [24] 1686 	movx	@dptr,a
                                   1687 ;	quantum/action_util.c:455: bool changed = false;
      008661 90 0B 25         [24] 1688 	mov	dptr,#_send_keyboard_report_changed_10001_388
      008664 E4               [12] 1689 	clr	a
      008665 F0               [24] 1690 	movx	@dptr,a
                                   1691 ;	quantum/action_util.c:457: uint8_t __xdata *dest = (uint8_t __xdata *)&last_report;
                                   1692 ;	quantum/action_util.c:458: const uint8_t __xdata *src = (const uint8_t __xdata *)keyboard_report;
                                   1693 ;	quantum/action_util.c:463: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      008666 FF               [12] 1694 	mov	r7,a
      008667                       1695 00107$:
      008667 BF 20 00         [24] 1696 	cjne	r7,#0x20,00140$
      00866A                       1697 00140$:
      00866A 50 2B            [24] 1698 	jnc	00103$
                                   1699 ;	quantum/action_util.c:464: if (dest[i] != src[i]) {
      00866C EF               [12] 1700 	mov	a,r7
      00866D 24 05            [12] 1701 	add	a, #_send_keyboard_report_last_report_10001_388
      00866F FD               [12] 1702 	mov	r5,a
      008670 E4               [12] 1703 	clr	a
      008671 34 0B            [12] 1704 	addc	a, #(_send_keyboard_report_last_report_10001_388 >> 8)
      008673 FE               [12] 1705 	mov	r6,a
      008674 12 4E 16         [24] 1706 	lcall	_ak820_outline_0078
      008677 EF               [12] 1707 	mov	a,r7
      008678 24 30            [12] 1708 	add	a, #_actual_keyboard_report
      00867A F5 82            [12] 1709 	mov	dpl,a
      00867C E4               [12] 1710 	clr	a
      00867D 34 0E            [12] 1711 	addc	a, #(_actual_keyboard_report >> 8)
      00867F F5 83            [12] 1712 	mov	dph,a
      008681 E0               [24] 1713 	movx	a,@dptr
      008682 FB               [12] 1714 	mov	r3,a
      008683 EC               [12] 1715 	mov	a,r4
      008684 B5 03 02         [24] 1716 	cjne	a,ar3,00142$
      008687 80 0B            [24] 1717 	sjmp	00108$
      008689                       1718 00142$:
                                   1719 ;	quantum/action_util.c:465: dest[i] = src[i];
      008689 12 3A E1         [24] 1720 	lcall	_ak820_outline_0137
      00868C EB               [12] 1721 	mov	a,r3
      00868D F0               [24] 1722 	movx	@dptr,a
                                   1723 ;	quantum/action_util.c:466: changed = true;
      00868E 90 0B 25         [24] 1724 	mov	dptr,#_send_keyboard_report_changed_10001_388
      008691 74 01            [12] 1725 	mov	a,#0x01
      008693 F0               [24] 1726 	movx	@dptr,a
      008694                       1727 00108$:
                                   1728 ;	quantum/action_util.c:463: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      008694 0F               [12] 1729 	inc	r7
      008695 80 D0            [24] 1730 	sjmp	00107$
      008697                       1731 00103$:
                                   1732 ;	quantum/action_util.c:469: if (changed) host_keyboard_send(keyboard_report);
      008697 90 0B 25         [24] 1733 	mov	dptr,#_send_keyboard_report_changed_10001_388
      00869A E0               [24] 1734 	movx	a,@dptr
      00869B 60 09            [24] 1735 	jz	00109$
      00869D 90 0E 30         [24] 1736 	mov	dptr,#_actual_keyboard_report
      0086A0 75 F0 00         [24] 1737 	mov	b, #0x00
                                   1738 ;	quantum/action_util.c:477: }
      0086A3 02 71 FD         [24] 1739 	ljmp	_host_keyboard_send
      0086A6                       1740 00109$:
      0086A6 22               [24] 1741 	ret
                                   1742 ;------------------------------------------------------------
                                   1743 ;Allocation info for local variables in function 'get_mods'
                                   1744 ;------------------------------------------------------------
                                   1745 ;	quantum/action_util.c:483: uint8_t get_mods(void) {
                                   1746 ;	-----------------------------------------
                                   1747 ;	 function get_mods
                                   1748 ;	-----------------------------------------
      0086A7                       1749 _get_mods:
      0086A7 C0 07            [24] 1750 	push	ar7
                                   1751 ;	quantum/action_util.c:488: ;
      0086A9 90 09 EC         [24] 1752 	mov	dptr,#_owned_mods
      0086AC E0               [24] 1753 	movx	a,@dptr
      0086AD FF               [12] 1754 	mov	r7,a
      0086AE 90 0E 2E         [24] 1755 	mov	dptr,#_real_mods
      0086B1 12 81 B3         [24] 1756 	lcall	_ak820_outline_0143
                                   1757 ;	quantum/action_util.c:489: }
      0086B4 D0 07            [24] 1758 	pop	ar7
      0086B6 22               [24] 1759 	ret
                                   1760 ;------------------------------------------------------------
                                   1761 ;Allocation info for local variables in function 'add_mods'
                                   1762 ;------------------------------------------------------------
                                   1763 ;mods          Allocated with name '_add_mods_mods_10000_396'
                                   1764 ;------------------------------------------------------------
                                   1765 ;	quantum/action_util.c:494: void add_mods(uint8_t mods) {
                                   1766 ;	-----------------------------------------
                                   1767 ;	 function clear_mods
                                   1768 ;	-----------------------------------------
      0086B7                       1769 _clear_mods:
                                   1770 ;	quantum/action_util.c:516: real_mods = 0;
      0086B7 90 0E 2E         [24] 1771 	mov	dptr,#_real_mods
      0086BA E4               [12] 1772 	clr	a
      0086BB F0               [24] 1773 	movx	@dptr,a
                                   1774 ;	quantum/action_util.c:517: }
      0086BC 22               [24] 1775 	ret
                                   1776 ;------------------------------------------------------------
                                   1777 ;Allocation info for local variables in function 'get_weak_mods'
                                   1778 ;------------------------------------------------------------
                                   1779 ;	quantum/action_util.c:523: uint8_t get_weak_mods(void) {
                                   1780 ;	-----------------------------------------
                                   1781 ;	 function get_weak_mods
                                   1782 ;	-----------------------------------------
      0086BD                       1783 _get_weak_mods:
      0086BD C0 07            [24] 1784 	push	ar7
                                   1785 ;	quantum/action_util.c:528: ;
      0086BF 90 09 ED         [24] 1786 	mov	dptr,#_owned_weak_mods
      0086C2 E0               [24] 1787 	movx	a,@dptr
      0086C3 FF               [12] 1788 	mov	r7,a
      0086C4 90 0E 2F         [24] 1789 	mov	dptr,#_weak_mods
      0086C7 12 81 B3         [24] 1790 	lcall	_ak820_outline_0143
                                   1791 ;	quantum/action_util.c:529: }
      0086CA D0 07            [24] 1792 	pop	ar7
      0086CC 22               [24] 1793 	ret
                                   1794 ;------------------------------------------------------------
                                   1795 ;Allocation info for local variables in function 'add_weak_mods'
                                   1796 ;------------------------------------------------------------
                                   1797 ;mods          Allocated with name '_add_weak_mods_mods_10000_406'
                                   1798 ;------------------------------------------------------------
                                   1799 ;	quantum/action_util.c:534: void add_weak_mods(uint8_t mods) {
                                   1800 ;	-----------------------------------------
                                   1801 ;	 function add_weak_mods
                                   1802 ;	-----------------------------------------
      0086CD                       1803 _add_weak_mods:
      0086CD E5 82            [12] 1804 	mov	a,dpl
      0086CF 90 0B 26         [24] 1805 	mov	dptr,#_add_weak_mods_mods_10000_406
      0086D2 F0               [24] 1806 	movx	@dptr,a
                                   1807 ;	quantum/action_util.c:535: weak_mods |= mods;
      0086D3 E0               [24] 1808 	movx	a,@dptr
      0086D4 FF               [12] 1809 	mov	r7,a
      0086D5 90 0E 2F         [24] 1810 	mov	dptr,#_weak_mods
      0086D8 E0               [24] 1811 	movx	a,@dptr
      0086D9 4F               [12] 1812 	orl	a,r7
      0086DA F0               [24] 1813 	movx	@dptr,a
                                   1814 ;	quantum/action_util.c:536: }
      0086DB 22               [24] 1815 	ret
                                   1816 ;------------------------------------------------------------
                                   1817 ;Allocation info for local variables in function 'del_weak_mods'
                                   1818 ;------------------------------------------------------------
                                   1819 ;mods          Allocated with name '_del_weak_mods_mods_10000_408'
                                   1820 ;------------------------------------------------------------
                                   1821 ;	quantum/action_util.c:541: void del_weak_mods(uint8_t mods) {
                                   1822 ;	-----------------------------------------
                                   1823 ;	 function del_weak_mods
                                   1824 ;	-----------------------------------------
      0086DC                       1825 _del_weak_mods:
      0086DC E5 82            [12] 1826 	mov	a,dpl
      0086DE 90 0B 27         [24] 1827 	mov	dptr,#_del_weak_mods_mods_10000_408
      0086E1 F0               [24] 1828 	movx	@dptr,a
                                   1829 ;	quantum/action_util.c:542: weak_mods &= ~mods;
      0086E2 E0               [24] 1830 	movx	a,@dptr
      0086E3 F4               [12] 1831 	cpl	a
      0086E4 FF               [12] 1832 	mov	r7,a
      0086E5 90 0E 2F         [24] 1833 	mov	dptr,#_weak_mods
      0086E8 E0               [24] 1834 	movx	a,@dptr
      0086E9 5F               [12] 1835 	anl	a,r7
      0086EA F0               [24] 1836 	movx	@dptr,a
                                   1837 ;	quantum/action_util.c:543: }
      0086EB 22               [24] 1838 	ret
                                   1839 ;------------------------------------------------------------
                                   1840 ;Allocation info for local variables in function 'set_weak_mods'
                                   1841 ;------------------------------------------------------------
                                   1842 ;mods          Allocated with name '_set_weak_mods_mods_10000_410'
                                   1843 ;------------------------------------------------------------
                                   1844 ;	quantum/action_util.c:548: void set_weak_mods(uint8_t mods) {
                                   1845 ;	-----------------------------------------
                                   1846 ;	 function clear_weak_mods
                                   1847 ;	-----------------------------------------
      0086EC                       1848 _clear_weak_mods:
                                   1849 ;	quantum/action_util.c:556: weak_mods = 0;
      0086EC 90 0E 2F         [24] 1850 	mov	dptr,#_weak_mods
      0086EF E4               [12] 1851 	clr	a
      0086F0 F0               [24] 1852 	movx	@dptr,a
                                   1853 ;	quantum/action_util.c:557: }
      0086F1 22               [24] 1854 	ret
                                   1855 ;------------------------------------------------------------
                                   1856 ;Allocation info for local variables in function 'oneshot_locked_mods_changed_user'
                                   1857 ;------------------------------------------------------------
                                   1858 ;mods          Allocated with name '_oneshot_locked_mods_changed_user_mods_10000_414'
                                   1859 ;------------------------------------------------------------
                                   1860 ;	quantum/action_util.c:639: __attribute__((weak)) void oneshot_locked_mods_changed_user(uint8_t mods) {}
                                   1861 ;	-----------------------------------------
                                   1862 	.area CSEG    (CODE)
                                   1863 	.area CONST   (CODE)
                                   1864 	.area XINIT   (CODE)
      00C649                       1865 __xinit__real_mods:
      00C649 00                    1866 	.db #0x00	; 0
      00C64A                       1867 __xinit__weak_mods:
      00C64A 00                    1868 	.db #0x00	; 0
      00C64B                       1869 __xinit__actual_keyboard_report:
      00C64B 00                    1870 	.db #0x00	; 0
      00C64C 00                    1871 	.db #0x00	; 0
      00C64D 00                    1872 	.db #0x00	; 0
      00C64E 00                    1873 	.db #0x00	; 0
      00C64F 00                    1874 	.db #0x00	; 0
      00C650 00                    1875 	.db #0x00	; 0
      00C651 00                    1876 	.db #0x00	; 0
      00C652 00                    1877 	.db #0x00	; 0
      00C653 00                    1878 	.db 0x00
      00C654 00                    1879 	.db 0x00
      00C655 00                    1880 	.db 0x00
      00C656 00                    1881 	.db 0x00
      00C657 00                    1882 	.db 0x00
      00C658 00                    1883 	.db 0x00
      00C659 00                    1884 	.db 0x00
      00C65A 00                    1885 	.db 0x00
      00C65B 00                    1886 	.db 0x00
      00C65C 00                    1887 	.db 0x00
      00C65D 00                    1888 	.db 0x00
      00C65E 00                    1889 	.db 0x00
      00C65F 00                    1890 	.db 0x00
      00C660 00                    1891 	.db 0x00
      00C661 00                    1892 	.db 0x00
      00C662 00                    1893 	.db 0x00
      00C663 00                    1894 	.db 0x00
      00C664 00                    1895 	.db 0x00
      00C665 00                    1896 	.db 0x00
      00C666 00                    1897 	.db 0x00
      00C667 00                    1898 	.db 0x00
      00C668 00                    1899 	.db 0x00
      00C669 00                    1900 	.db 0x00
      00C66A 00                    1901 	.db 0x00
                                   1902 	.area CABS    (ABS,CODE)
                                   1903 
                                   1904 ; Experimental exact instruction outlining.
                                   1905 	.globl _ak820_outline_0017
                                   1906 	.globl _ak820_outline_0030
                                   1907 	.globl _ak820_outline_0057
                                   1908 	.globl _ak820_outline_0059
                                   1909 	.globl _ak820_outline_0061
                                   1910 	.globl _ak820_outline_0063
                                   1911 	.globl _ak820_outline_0064
                                   1912 	.globl _ak820_outline_0065
                                   1913 	.globl _ak820_outline_0068
                                   1914 	.globl _ak820_outline_0075
                                   1915 	.globl _ak820_outline_0078
                                   1916 	.globl _ak820_outline_0110
                                   1917 	.globl _ak820_outline_0111
                                   1918 	.globl _ak820_outline_0119
                                   1919 	.globl _ak820_outline_0123
                                   1920 	.globl _ak820_outline_0125
                                   1921 	.globl _ak820_outline_0128
                                   1922 	.globl _ak820_outline_0135
                                   1923 	.globl _ak820_outline_0136
                                   1924 	.globl _ak820_outline_0137
                                   1925 	.globl _ak820_outline_0141
                                   1926 	.globl _ak820_outline_0143
                                   1927 	.globl _ak820_outline_0146
                                   1928 	.globl _ak820_outline_0160
                                   1929 	.globl _ak820_outline_0165
                                   1930 	.globl _ak820_outline_0183
                                   1931 	.globl _ak820_outline_0189
                                   1932 	.globl _ak820_outline_0190
                                   1933 	.globl _ak820_outline_0191
                                   1934 
                                   1935 	.area CSEG (CODE)
                                   1936 ; function ak820_outline_0030
      0086F2                       1937 _ak820_outline_0030:
      0086F2 EF               [12] 1938 	mov	a,r7
      0086F3 24 FE            [12] 1939 	add	a,#_key_refs
      0086F5 FD               [12] 1940 	mov	r5,a
      0086F6 E4               [12] 1941 	clr	a
      0086F7 34 09            [12] 1942 	addc	a,#(_key_refs>>8)
      0086F9 FE               [12] 1943 	mov	r6,a
      0086FA 8D 82            [24] 1944 	mov	dpl,r5
      0086FC 8E 83            [24] 1945 	mov	dph,r6
      0086FE E0               [24] 1946 	movx	a,@dptr
      0086FF 22               [24] 1947 	ret
                                   1948 
                                   1949 	.area CSEG (CODE)
                                   1950 ; function ak820_outline_0059
      008700                       1951 _ak820_outline_0059:
      008700 F0               [24] 1952 	movx	@dptr,a
      008701 90 0E 30         [24] 1953 	mov	dptr,#_actual_keyboard_report
      008704 75 F0 00         [24] 1954 	mov	b,#0x00
      008707 22               [24] 1955 	ret
                                   1956 
                                   1957 	.area CSEG (CODE)
                                   1958 ; function ak820_outline_0064
      008708                       1959 _ak820_outline_0064:
      008708 89 82            [24] 1960 	mov	dpl,r1
      00870A 8A 83            [24] 1961 	mov	dph,r2
      00870C E8               [12] 1962 	mov	a,r0
      00870D F0               [24] 1963 	movx	@dptr,a
      00870E 22               [24] 1964 	ret
                                   1965 
                                   1966 	.area CSEG (CODE)
                                   1967 ; function ak820_outline_0068
      00870F                       1968 _ak820_outline_0068:
      00870F 24 D9            [12] 1969 	add	a,#_usage_order
      008711 F5 82            [12] 1970 	mov	dpl,a
      008713 E4               [12] 1971 	clr	a
      008714 34 0A            [12] 1972 	addc	a,#(_usage_order>>8)
      008716 F5 83            [12] 1973 	mov	dph,a
      008718 22               [24] 1974 	ret
                                   1975 
                                   1976 	.area CSEG (CODE)
                                   1977 ; function ak820_outline_0075
      008719                       1978 _ak820_outline_0075:
      008719 EB               [12] 1979 	mov	a,r3
      00871A 24 BB            [12] 1980 	add	a,#_usage_refs
      00871C F9               [12] 1981 	mov	r1,a
      00871D E4               [12] 1982 	clr	a
      00871E 34 0A            [12] 1983 	addc	a,#(_usage_refs>>8)
      008720 FA               [12] 1984 	mov	r2,a
      008721 89 82            [24] 1985 	mov	dpl,r1
      008723 8A 83            [24] 1986 	mov	dph,r2
      008725 E0               [24] 1987 	movx	a,@dptr
      008726 F8               [12] 1988 	mov	r0,a
      008727 22               [24] 1989 	ret
                                   1990 
                                   1991 	.area CSEG (CODE)
                                   1992 ; function ak820_outline_0119
      008728                       1993 _ak820_outline_0119:
      008728 F0               [24] 1994 	movx	@dptr,a
      008729 E0               [24] 1995 	movx	a,@dptr
      00872A FF               [12] 1996 	mov	r7,a
      00872B 90 09 F6         [24] 1997 	mov	dptr,#_change_owned_PARM_2
      00872E 22               [24] 1998 	ret
                                   1999 
                                   2000 	.area CSEG (CODE)
                                   2001 ; function ak820_outline_0123
      00872F                       2002 _ak820_outline_0123:
      00872F 8D 82            [24] 2003 	mov	dpl,r5
      008731 8E 83            [24] 2004 	mov	dph,r6
      008733 F0               [24] 2005 	movx	@dptr,a
      008734 22               [24] 2006 	ret
                                   2007 
                                   2008 	.area CSEG (CODE)
                                   2009 ; function ak820_outline_0128
      008735                       2010 _ak820_outline_0128:
      008735 24 D9            [12] 2011 	add	a,#_usage_order
      008737 F5 82            [12] 2012 	mov	dpl,a
      008739 EF               [12] 2013 	mov	a,r7
      00873A 34 0A            [12] 2014 	addc	a,#(_usage_order>>8)
      00873C F5 83            [12] 2015 	mov	dph,a
      00873E E0               [24] 2016 	movx	a,@dptr
      00873F 22               [24] 2017 	ret
                                   2018 
                                   2019 	.area CSEG (CODE)
                                   2020 ; function ak820_outline_0135
      008740                       2021 _ak820_outline_0135:
      008740 F0               [24] 2022 	movx	@dptr,a
      008741 E0               [24] 2023 	movx	a,@dptr
      008742 FF               [12] 2024 	mov	r7,a
      008743 90 09 F2         [24] 2025 	mov	dptr,#_ak820_macro_change_PARM_2
      008746 F0               [24] 2026 	movx	@dptr,a
      008747 90 09 F3         [24] 2027 	mov	dptr,#_ak820_macro_change_PARM_3
      00874A 22               [24] 2028 	ret
                                   2029 
                                   2030 	.area CSEG (CODE)
                                   2031 ; function ak820_outline_0191
      00874B                       2032 _ak820_outline_0191:
      00874B 8D 82            [24] 2033 	mov	dpl,r5
      00874D 8F 83            [24] 2034 	mov	dph,r7
      00874F 22               [24] 2035 	ret
