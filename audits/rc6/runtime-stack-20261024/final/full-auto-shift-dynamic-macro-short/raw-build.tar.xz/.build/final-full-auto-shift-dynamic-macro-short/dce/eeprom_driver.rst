                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module eeprom_driver
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_eeprom_write_block_xdata
                                     12 	.globl _ak820_eeprom_read_block_xdata
                                     13 	.globl _eeprom_read_byte
                                     14 	.globl _eeprom_update_dword_PARM_2
                                     15 	.globl _eeprom_update_word_PARM_2
                                     16 	.globl _eeprom_update_byte_PARM_2
                                     17 	.globl _eeprom_write_dword_PARM_2
                                     18 	.globl _eeprom_write_word_PARM_2
                                     19 	.globl _eeprom_write_byte_PARM_2
                                     20 	.globl _eeprom_read_word
                                     21 	.globl _eeprom_read_dword
                                     22 	.globl _eeprom_write_byte
                                     23 	.globl _eeprom_write_word
                                     24 	.globl _eeprom_write_dword
                                     25 	.globl _eeprom_update_byte
                                     26 	.globl _eeprom_update_word
                                     27 	.globl _eeprom_update_dword
                                     28 ;--------------------------------------------------------
                                     29 ; special function registers
                                     30 ;--------------------------------------------------------
                                     31 	.area RSEG    (ABS,DATA)
      000000                         32 	.org 0x0000
                                     33 ;--------------------------------------------------------
                                     34 ; special function bits
                                     35 ;--------------------------------------------------------
                                     36 	.area RSEG    (ABS,DATA)
      000000                         37 	.org 0x0000
                                     38 ;--------------------------------------------------------
                                     39 ; overlayable register banks
                                     40 ;--------------------------------------------------------
                                     41 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         42 	.ds 8
                                     43 ;--------------------------------------------------------
                                     44 ; overlayable bit register bank
                                     45 ;--------------------------------------------------------
                                     46 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         47 bits:
      000026                         48 	.ds 1
                           008000    49 	b0 = bits[0]
                           008100    50 	b1 = bits[1]
                           008200    51 	b2 = bits[2]
                           008300    52 	b3 = bits[3]
                           008400    53 	b4 = bits[4]
                           008500    54 	b5 = bits[5]
                           008600    55 	b6 = bits[6]
                           008700    56 	b7 = bits[7]
                                     57 ;--------------------------------------------------------
                                     58 ; internal ram data
                                     59 ;--------------------------------------------------------
                                     60 	.area DSEG    (DATA)
                                     61 ;--------------------------------------------------------
                                     62 ; overlayable items in internal ram
                                     63 ;--------------------------------------------------------
                                     64 ;--------------------------------------------------------
                                     65 ; indirectly addressable internal ram data
                                     66 ;--------------------------------------------------------
                                     67 	.area ISEG    (DATA)
                                     68 ;--------------------------------------------------------
                                     69 ; absolute internal ram data
                                     70 ;--------------------------------------------------------
                                     71 	.area IABS    (ABS,DATA)
                                     72 	.area IABS    (ABS,DATA)
                                     73 ;--------------------------------------------------------
                                     74 ; bit data
                                     75 ;--------------------------------------------------------
                                     76 	.area BSEG    (BIT)
                                     77 ;--------------------------------------------------------
                                     78 ; paged external ram data
                                     79 ;--------------------------------------------------------
                                     80 	.area PSEG    (PAG,XDATA)
                                     81 ;--------------------------------------------------------
                                     82 ; uninitialized external ram data
                                     83 ;--------------------------------------------------------
                                     84 	.area XSEG    (XDATA)
      0006E5                         85 _eeprom_read_word_addr_10000_91:
      0006E5                         86 	.ds 3
      0006E8                         87 _eeprom_read_word_ret_10000_92:
      0006E8                         88 	.ds 2
      0006EA                         89 _eeprom_read_dword_addr_10000_93:
      0006EA                         90 	.ds 3
      0006ED                         91 _eeprom_read_dword_ret_10000_94:
      0006ED                         92 	.ds 4
      0006F1                         93 _eeprom_write_byte_PARM_2:
      0006F1                         94 	.ds 1
      0006F2                         95 _eeprom_write_byte_addr_10000_95:
      0006F2                         96 	.ds 3
      0006F5                         97 _eeprom_write_word_PARM_2:
      0006F5                         98 	.ds 2
      0006F7                         99 _eeprom_write_word_addr_10000_97:
      0006F7                        100 	.ds 3
      0006FA                        101 _eeprom_write_dword_PARM_2:
      0006FA                        102 	.ds 4
      0006FE                        103 _eeprom_write_dword_addr_10000_99:
      0006FE                        104 	.ds 3
      000701                        105 _eeprom_update_byte_PARM_2:
      000701                        106 	.ds 1
      000702                        107 _eeprom_update_byte_addr_10000_107:
      000702                        108 	.ds 3
      000705                        109 _eeprom_update_word_PARM_2:
      000705                        110 	.ds 2
      000707                        111 _eeprom_update_word_addr_10000_111:
      000707                        112 	.ds 3
      00070A                        113 _eeprom_update_dword_PARM_2:
      00070A                        114 	.ds 4
      00070E                        115 _eeprom_update_dword_addr_10000_115:
      00070E                        116 	.ds 3
                                    117 ;--------------------------------------------------------
                                    118 ; absolute external ram data
                                    119 ;--------------------------------------------------------
                                    120 	.area XABS    (ABS,XDATA)
                                    121 ;--------------------------------------------------------
                                    122 ; initialized external ram data
                                    123 ;--------------------------------------------------------
                                    124 	.area XISEG   (XDATA)
                                    125 	.area HOME    (CODE)
                                    126 	.area GSINIT0 (CODE)
                                    127 	.area GSINIT1 (CODE)
                                    128 	.area GSINIT2 (CODE)
                                    129 	.area GSINIT3 (CODE)
                                    130 	.area GSINIT4 (CODE)
                                    131 	.area GSINIT5 (CODE)
                                    132 	.area GSINIT  (CODE)
                                    133 	.area GSFINAL (CODE)
                                    134 	.area CSEG    (CODE)
                                    135 ;--------------------------------------------------------
                                    136 ; global & static initialisations
                                    137 ;--------------------------------------------------------
                                    138 	.area HOME    (CODE)
                                    139 	.area GSINIT  (CODE)
                                    140 	.area GSFINAL (CODE)
                                    141 	.area GSINIT  (CODE)
                                    142 ;--------------------------------------------------------
                                    143 ; Home
                                    144 ;--------------------------------------------------------
                                    145 	.area HOME    (CODE)
                                    146 	.area HOME    (CODE)
                                    147 ;--------------------------------------------------------
                                    148 ; code
                                    149 ;--------------------------------------------------------
                                    150 	.area CSEG    (CODE)
                                    151 ;------------------------------------------------------------
                                    152 ;Allocation info for local variables in function 'eeprom_read_word'
                                    153 ;------------------------------------------------------------
                                    154 ;addr          Allocated with name '_eeprom_read_word_addr_10000_91'
                                    155 ;ret           Allocated with name '_eeprom_read_word_ret_10000_92'
                                    156 ;------------------------------------------------------------
                                    157 ;	drivers/eeprom/eeprom_driver.c:44: uint16_t eeprom_read_word(const uint16_t *addr) {
                                    158 ;	-----------------------------------------
                                    159 ;	 function eeprom_read_word
                                    160 ;	-----------------------------------------
      0052CC                        161 _eeprom_read_word:
                           000007   162 	ar7 = 0x07
                           000006   163 	ar6 = 0x06
                           000005   164 	ar5 = 0x05
                           000004   165 	ar4 = 0x04
                           000003   166 	ar3 = 0x03
                           000002   167 	ar2 = 0x02
                           000001   168 	ar1 = 0x01
                           000000   169 	ar0 = 0x00
      0052CC 12 48 A0         [24]  170 	lcall	_ak820_outline_0036
      0052CF 90 06 E5         [24]  171 	mov	dptr,#_eeprom_read_word_addr_10000_91
      0052D2 12 3A 5F         [24]  172 	lcall	_ak820_outline_0016
                                    173 ;	drivers/eeprom/eeprom_driver.c:45: uint16_t ret = 0;
      0052D5 90 06 E8         [24]  174 	mov	dptr,#_eeprom_read_word_ret_10000_92
      0052D8 12 54 D7         [24]  175 	lcall	_ak820_outline_0183
                                    176 ;	drivers/eeprom/eeprom_driver.c:46: EEPROM_LOCAL_READ(&ret, addr, 2);
      0052DB 90 06 E5         [24]  177 	mov	dptr,#_eeprom_read_word_addr_10000_91
      0052DE 12 54 84         [24]  178 	lcall	_ak820_outline_0013
      0052E1 90 05 EB         [24]  179 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      0052E4 ED               [12]  180 	mov	a,r5
      0052E5 12 3A 5F         [24]  181 	lcall	_ak820_outline_0016
      0052E8 90 05 EE         [24]  182 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      0052EB 12 54 C9         [24]  183 	lcall	_ak820_outline_0113
      0052EE 90 06 E8         [24]  184 	mov	dptr,#_eeprom_read_word_ret_10000_92
      0052F1 12 46 3C         [24]  185 	lcall	_ak820_eeprom_read_block_xdata
                                    186 ;	drivers/eeprom/eeprom_driver.c:47: return ret;
      0052F4 90 06 E8         [24]  187 	mov	dptr,#_eeprom_read_word_ret_10000_92
      0052F7 12 54 C0         [24]  188 	lcall	_ak820_outline_0094
                                    189 ;	drivers/eeprom/eeprom_driver.c:48: }
      0052FA 22               [24]  190 	ret
                                    191 ;------------------------------------------------------------
                                    192 ;Allocation info for local variables in function 'eeprom_read_dword'
                                    193 ;------------------------------------------------------------
                                    194 ;addr          Allocated with name '_eeprom_read_dword_addr_10000_93'
                                    195 ;ret           Allocated with name '_eeprom_read_dword_ret_10000_94'
                                    196 ;------------------------------------------------------------
                                    197 ;	drivers/eeprom/eeprom_driver.c:50: uint32_t eeprom_read_dword(const uint32_t *addr) {
                                    198 ;	-----------------------------------------
                                    199 ;	 function eeprom_read_dword
                                    200 ;	-----------------------------------------
      0052FB                        201 _eeprom_read_dword:
      0052FB 12 48 A0         [24]  202 	lcall	_ak820_outline_0036
      0052FE 90 06 EA         [24]  203 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      005301 12 3A 5F         [24]  204 	lcall	_ak820_outline_0016
                                    205 ;	drivers/eeprom/eeprom_driver.c:51: uint32_t ret = 0;
      005304 90 06 ED         [24]  206 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      005307 12 54 95         [24]  207 	lcall	_ak820_outline_0052
                                    208 ;	drivers/eeprom/eeprom_driver.c:52: EEPROM_LOCAL_READ(&ret, addr, 4);
      00530A 90 06 EA         [24]  209 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      00530D 12 54 84         [24]  210 	lcall	_ak820_outline_0013
      005310 90 05 EB         [24]  211 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      005313 ED               [12]  212 	mov	a,r5
      005314 12 3A 5F         [24]  213 	lcall	_ak820_outline_0016
      005317 90 05 EE         [24]  214 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      00531A 74 04            [12]  215 	mov	a,#0x04
      00531C 12 3A DC         [24]  216 	lcall	_ak820_outline_0136
      00531F 90 06 ED         [24]  217 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      005322 12 46 3C         [24]  218 	lcall	_ak820_eeprom_read_block_xdata
                                    219 ;	drivers/eeprom/eeprom_driver.c:53: return ret;
      005325 90 06 ED         [24]  220 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      005328 12 54 9E         [24]  221 	lcall	_ak820_outline_0056
                                    222 ;	drivers/eeprom/eeprom_driver.c:54: }
      00532B 22               [24]  223 	ret
                                    224 ;------------------------------------------------------------
                                    225 ;Allocation info for local variables in function 'eeprom_write_byte'
                                    226 ;------------------------------------------------------------
                                    227 ;value         Allocated with name '_eeprom_write_byte_PARM_2'
                                    228 ;addr          Allocated with name '_eeprom_write_byte_addr_10000_95'
                                    229 ;------------------------------------------------------------
                                    230 ;	drivers/eeprom/eeprom_driver.c:56: void eeprom_write_byte(uint8_t *addr, uint8_t value) {
                                    231 ;	-----------------------------------------
                                    232 ;	 function eeprom_write_byte
                                    233 ;	-----------------------------------------
      00532C                        234 _eeprom_write_byte:
      00532C 12 48 A0         [24]  235 	lcall	_ak820_outline_0036
      00532F 90 06 F2         [24]  236 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      005332 12 3A 5F         [24]  237 	lcall	_ak820_outline_0016
                                    238 ;	drivers/eeprom/eeprom_driver.c:57: EEPROM_LOCAL_WRITE(&value, addr, 1);
      005335 90 06 F2         [24]  239 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      005338 12 54 6D         [24]  240 	lcall	_ak820_outline_0004
      00533B 74 01            [12]  241 	mov	a,#0x01
      00533D 12 3A DC         [24]  242 	lcall	_ak820_outline_0136
      005340 90 06 F1         [24]  243 	mov	dptr,#_eeprom_write_byte_PARM_2
                                    244 ;	drivers/eeprom/eeprom_driver.c:58: }
      005343 02 46 C8         [24]  245 	ljmp	_ak820_eeprom_write_block_xdata
                                    246 ;------------------------------------------------------------
                                    247 ;Allocation info for local variables in function 'eeprom_write_word'
                                    248 ;------------------------------------------------------------
                                    249 ;value         Allocated with name '_eeprom_write_word_PARM_2'
                                    250 ;addr          Allocated with name '_eeprom_write_word_addr_10000_97'
                                    251 ;------------------------------------------------------------
                                    252 ;	drivers/eeprom/eeprom_driver.c:60: void eeprom_write_word(uint16_t *addr, uint16_t value) {
                                    253 ;	-----------------------------------------
                                    254 ;	 function eeprom_write_word
                                    255 ;	-----------------------------------------
      005346                        256 _eeprom_write_word:
      005346 12 48 A0         [24]  257 	lcall	_ak820_outline_0036
      005349 90 06 F7         [24]  258 	mov	dptr,#_eeprom_write_word_addr_10000_97
      00534C 12 3A 5F         [24]  259 	lcall	_ak820_outline_0016
                                    260 ;	drivers/eeprom/eeprom_driver.c:61: EEPROM_LOCAL_WRITE(&value, addr, 2);
      00534F 90 06 F7         [24]  261 	mov	dptr,#_eeprom_write_word_addr_10000_97
      005352 12 54 6D         [24]  262 	lcall	_ak820_outline_0004
      005355 12 54 C9         [24]  263 	lcall	_ak820_outline_0113
      005358 90 06 F5         [24]  264 	mov	dptr,#_eeprom_write_word_PARM_2
                                    265 ;	drivers/eeprom/eeprom_driver.c:62: }
      00535B 02 46 C8         [24]  266 	ljmp	_ak820_eeprom_write_block_xdata
                                    267 ;------------------------------------------------------------
                                    268 ;Allocation info for local variables in function 'eeprom_write_dword'
                                    269 ;------------------------------------------------------------
                                    270 ;value         Allocated with name '_eeprom_write_dword_PARM_2'
                                    271 ;addr          Allocated with name '_eeprom_write_dword_addr_10000_99'
                                    272 ;------------------------------------------------------------
                                    273 ;	drivers/eeprom/eeprom_driver.c:64: void eeprom_write_dword(uint32_t *addr, uint32_t value) {
                                    274 ;	-----------------------------------------
                                    275 ;	 function eeprom_write_dword
                                    276 ;	-----------------------------------------
      00535E                        277 _eeprom_write_dword:
      00535E 12 48 A0         [24]  278 	lcall	_ak820_outline_0036
      005361 90 06 FE         [24]  279 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      005364 12 3A 5F         [24]  280 	lcall	_ak820_outline_0016
                                    281 ;	drivers/eeprom/eeprom_driver.c:65: EEPROM_LOCAL_WRITE(&value, addr, 4);
      005367 90 06 FE         [24]  282 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      00536A 12 54 6D         [24]  283 	lcall	_ak820_outline_0004
      00536D 74 04            [12]  284 	mov	a,#0x04
      00536F 12 3A DC         [24]  285 	lcall	_ak820_outline_0136
      005372 90 06 FA         [24]  286 	mov	dptr,#_eeprom_write_dword_PARM_2
                                    287 ;	drivers/eeprom/eeprom_driver.c:66: }
      005375 02 46 C8         [24]  288 	ljmp	_ak820_eeprom_write_block_xdata
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'eeprom_update_block'
                                    291 ;------------------------------------------------------------
                                    292 ;sloc0         Allocated with name '_eeprom_update_block_sloc0_1_0'
                                    293 ;sloc1         Allocated with name '_eeprom_update_block_sloc1_1_0'
                                    294 ;sloc2         Allocated with name '_eeprom_update_block_sloc2_1_0'
                                    295 ;sloc3         Allocated with name '_eeprom_update_block_sloc3_1_0'
                                    296 ;addr          Allocated with name '_eeprom_update_block_PARM_2'
                                    297 ;len           Allocated with name '_eeprom_update_block_PARM_3'
                                    298 ;buf           Allocated with name '_eeprom_update_block_buf_10000_101'
                                    299 ;source        Allocated with name '_eeprom_update_block_source_10000_102'
                                    300 ;target        Allocated with name '_eeprom_update_block_target_10000_102'
                                    301 ;i             Allocated with name '_eeprom_update_block_i_10000_102'
                                    302 ;------------------------------------------------------------
                                    303 ;	drivers/eeprom/eeprom_driver.c:68: void eeprom_update_block(const void *buf, void *addr, size_t len) {
                                    304 ;	-----------------------------------------
                                    305 ;	 function eeprom_update_byte
                                    306 ;	-----------------------------------------
      005378                        307 _eeprom_update_byte:
      005378 C0 07            [24]  308 	push	ar7
      00537A C0 06            [24]  309 	push	ar6
      00537C C0 05            [24]  310 	push	ar5
      00537E C0 04            [24]  311 	push	ar4
      005380 12 48 A0         [24]  312 	lcall	_ak820_outline_0036
      005383 90 07 02         [24]  313 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      005386 12 3A 5F         [24]  314 	lcall	_ak820_outline_0016
                                    315 ;	drivers/eeprom/eeprom_driver.c:83: uint8_t orig = eeprom_read_byte(addr);
      005389 90 07 02         [24]  316 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      00538C 12 54 5E         [24]  317 	lcall	_ak820_outline_0001
      00538F 12 46 01         [24]  318 	lcall	_eeprom_read_byte
      005392 AF 82            [24]  319 	mov	r7, dpl
                                    320 ;	drivers/eeprom/eeprom_driver.c:84: if (orig != value) {
      005394 90 07 01         [24]  321 	mov	dptr,#_eeprom_update_byte_PARM_2
      005397 E0               [24]  322 	movx	a,@dptr
      005398 FE               [12]  323 	mov	r6,a
      005399 EF               [12]  324 	mov	a,r7
      00539A B5 06 02         [24]  325 	cjne	a,ar6,00112$
      00539D 80 35            [24]  326 	sjmp	00103$
      00539F                        327 00112$:
                                    328 ;	drivers/eeprom/eeprom_driver.c:85: eeprom_write_byte(addr, value);
      00539F 90 07 02         [24]  329 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      0053A2 12 3A 98         [24]  330 	lcall	_ak820_outline_0061
      0053A5 A3               [24]  331 	inc	dptr
      0053A6 E0               [24]  332 	movx	a,@dptr
      0053A7 FF               [12]  333 	mov	r7,a
      0053A8 90 06 F1         [24]  334 	mov	dptr,#_eeprom_write_byte_PARM_2
      0053AB EE               [12]  335 	mov	a,r6
      0053AC 12 3A B6         [24]  336 	lcall	_ak820_outline_0104
      0053AF 8F F0            [24]  337 	mov	b, r7
      0053B1 C0 07            [24]  338 	push	ar7
      0053B3 C0 06            [24]  339 	push	ar6
      0053B5 C0 05            [24]  340 	push	ar5
      0053B7 C0 04            [24]  341 	push	ar4
      0053B9 C0 03            [24]  342 	push	ar3
      0053BB C0 02            [24]  343 	push	ar2
      0053BD C0 01            [24]  344 	push	ar1
      0053BF C0 00            [24]  345 	push	ar0
      0053C1 12 53 2C         [24]  346 	lcall	_eeprom_write_byte
      0053C4 D0 00            [24]  347 	pop	ar0
      0053C6 D0 01            [24]  348 	pop	ar1
      0053C8 D0 02            [24]  349 	pop	ar2
      0053CA D0 03            [24]  350 	pop	ar3
      0053CC D0 04            [24]  351 	pop	ar4
      0053CE D0 05            [24]  352 	pop	ar5
      0053D0 D0 06            [24]  353 	pop	ar6
      0053D2 D0 07            [24]  354 	pop	ar7
      0053D4                        355 00103$:
                                    356 ;	drivers/eeprom/eeprom_driver.c:87: }
      0053D4 D0 04            [24]  357 	pop	ar4
      0053D6 D0 05            [24]  358 	pop	ar5
      0053D8 D0 06            [24]  359 	pop	ar6
      0053DA D0 07            [24]  360 	pop	ar7
      0053DC 22               [24]  361 	ret
                                    362 ;------------------------------------------------------------
                                    363 ;Allocation info for local variables in function 'eeprom_update_word'
                                    364 ;------------------------------------------------------------
                                    365 ;value         Allocated with name '_eeprom_update_word_PARM_2'
                                    366 ;addr          Allocated with name '_eeprom_update_word_addr_10000_111'
                                    367 ;orig          Allocated with name '_eeprom_update_word_orig_10000_112'
                                    368 ;------------------------------------------------------------
                                    369 ;	drivers/eeprom/eeprom_driver.c:89: void eeprom_update_word(uint16_t *addr, uint16_t value) {
                                    370 ;	-----------------------------------------
                                    371 ;	 function eeprom_update_word
                                    372 ;	-----------------------------------------
      0053DD                        373 _eeprom_update_word:
      0053DD 12 48 A0         [24]  374 	lcall	_ak820_outline_0036
      0053E0 90 07 07         [24]  375 	mov	dptr,#_eeprom_update_word_addr_10000_111
      0053E3 12 3A 5F         [24]  376 	lcall	_ak820_outline_0016
                                    377 ;	drivers/eeprom/eeprom_driver.c:90: uint16_t orig = eeprom_read_word(addr);
      0053E6 90 07 07         [24]  378 	mov	dptr,#_eeprom_update_word_addr_10000_111
      0053E9 12 54 5E         [24]  379 	lcall	_ak820_outline_0001
      0053EC 12 52 CC         [24]  380 	lcall	_eeprom_read_word
      0053EF 12 48 E9         [24]  381 	lcall	_ak820_outline_0127
                                    382 ;	drivers/eeprom/eeprom_driver.c:91: if (orig != value) {
      0053F2 90 07 05         [24]  383 	mov	dptr,#_eeprom_update_word_PARM_2
      0053F5 12 3A 98         [24]  384 	lcall	_ak820_outline_0061
      0053F8 EE               [12]  385 	mov	a,r6
      0053F9 B5 04 05         [24]  386 	cjne	a,ar4,00112$
      0053FC EF               [12]  387 	mov	a,r7
      0053FD B5 05 01         [24]  388 	cjne	a,ar5,00112$
      005400 22               [24]  389 	ret
      005401                        390 00112$:
                                    391 ;	drivers/eeprom/eeprom_driver.c:92: eeprom_write_word(addr, value);
      005401 90 07 07         [24]  392 	mov	dptr,#_eeprom_update_word_addr_10000_111
      005404 E0               [24]  393 	movx	a,@dptr
      005405 FB               [12]  394 	mov	r3,a
      005406 A3               [24]  395 	inc	dptr
      005407 12 3A 81         [24]  396 	lcall	_ak820_outline_0053
      00540A 90 06 F5         [24]  397 	mov	dptr,#_eeprom_write_word_PARM_2
      00540D 12 3A 9E         [24]  398 	lcall	_ak820_outline_0072
      005410 8B 82            [24]  399 	mov	dpl, r3
      005412 8E 83            [24]  400 	mov	dph, r6
      005414 8F F0            [24]  401 	mov	b, r7
                                    402 ;	drivers/eeprom/eeprom_driver.c:94: }
      005416 02 53 46         [24]  403 	ljmp	_eeprom_write_word
                                    404 ;------------------------------------------------------------
                                    405 ;Allocation info for local variables in function 'eeprom_update_dword'
                                    406 ;------------------------------------------------------------
                                    407 ;value         Allocated with name '_eeprom_update_dword_PARM_2'
                                    408 ;addr          Allocated with name '_eeprom_update_dword_addr_10000_115'
                                    409 ;orig          Allocated with name '_eeprom_update_dword_orig_10000_116'
                                    410 ;------------------------------------------------------------
                                    411 ;	drivers/eeprom/eeprom_driver.c:96: void eeprom_update_dword(uint32_t *addr, uint32_t value) {
                                    412 ;	-----------------------------------------
                                    413 ;	 function eeprom_update_dword
                                    414 ;	-----------------------------------------
      005419                        415 _eeprom_update_dword:
      005419 12 48 A0         [24]  416 	lcall	_ak820_outline_0036
      00541C 90 07 0E         [24]  417 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      00541F 12 3A 5F         [24]  418 	lcall	_ak820_outline_0016
                                    419 ;	drivers/eeprom/eeprom_driver.c:97: uint32_t orig = eeprom_read_dword(addr);
      005422 90 07 0E         [24]  420 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      005425 12 54 5E         [24]  421 	lcall	_ak820_outline_0001
      005428 12 52 FB         [24]  422 	lcall	_eeprom_read_dword
      00542B 12 54 AF         [24]  423 	lcall	_ak820_outline_0058
                                    424 ;	drivers/eeprom/eeprom_driver.c:98: if (orig != value) {
      00542E 90 07 0A         [24]  425 	mov	dptr,#_eeprom_update_dword_PARM_2
      005431 E0               [24]  426 	movx	a,@dptr
      005432 F8               [12]  427 	mov	r0,a
      005433 A3               [24]  428 	inc	dptr
      005434 12 54 B7         [24]  429 	lcall	_ak820_outline_0093
      005437 EC               [12]  430 	mov	a,r4
      005438 B5 00 0D         [24]  431 	cjne	a,ar0,00112$
      00543B ED               [12]  432 	mov	a,r5
      00543C B5 01 09         [24]  433 	cjne	a,ar1,00112$
      00543F EE               [12]  434 	mov	a,r6
      005440 B5 02 05         [24]  435 	cjne	a,ar2,00112$
      005443 EF               [12]  436 	mov	a,r7
      005444 B5 03 01         [24]  437 	cjne	a,ar3,00112$
      005447 22               [24]  438 	ret
      005448                        439 00112$:
                                    440 ;	drivers/eeprom/eeprom_driver.c:99: eeprom_write_dword(addr, value);
      005448 90 07 0E         [24]  441 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      00544B 12 54 84         [24]  442 	lcall	_ak820_outline_0013
      00544E 90 06 FA         [24]  443 	mov	dptr,#_eeprom_write_dword_PARM_2
      005451 E8               [12]  444 	mov	a,r0
      005452 F0               [24]  445 	movx	@dptr,a
      005453 E9               [12]  446 	mov	a,r1
      005454 A3               [24]  447 	inc	dptr
      005455 12 54 D0         [24]  448 	lcall	_ak820_outline_0158
      005458 12 54 8D         [24]  449 	lcall	_ak820_outline_0031
                                    450 ;	drivers/eeprom/eeprom_driver.c:101: }
      00545B 02 53 5E         [24]  451 	ljmp	_eeprom_write_dword
                                    452 	.area CSEG    (CODE)
                                    453 	.area CONST   (CODE)
                                    454 	.area XINIT   (CODE)
                                    455 	.area CABS    (ABS,CODE)
                                    456 
                                    457 ; Experimental exact instruction outlining.
                                    458 	.globl _ak820_outline_0001
                                    459 	.globl _ak820_outline_0004
                                    460 	.globl _ak820_outline_0013
                                    461 	.globl _ak820_outline_0016
                                    462 	.globl _ak820_outline_0031
                                    463 	.globl _ak820_outline_0036
                                    464 	.globl _ak820_outline_0052
                                    465 	.globl _ak820_outline_0053
                                    466 	.globl _ak820_outline_0056
                                    467 	.globl _ak820_outline_0058
                                    468 	.globl _ak820_outline_0061
                                    469 	.globl _ak820_outline_0072
                                    470 	.globl _ak820_outline_0093
                                    471 	.globl _ak820_outline_0094
                                    472 	.globl _ak820_outline_0104
                                    473 	.globl _ak820_outline_0113
                                    474 	.globl _ak820_outline_0127
                                    475 	.globl _ak820_outline_0136
                                    476 	.globl _ak820_outline_0158
                                    477 	.globl _ak820_outline_0183
                                    478 
                                    479 	.area CSEG (CODE)
                                    480 ; function ak820_outline_0001
      00545E                        481 _ak820_outline_0001:
      00545E E0               [24]  482 	movx	a,@dptr
      00545F FD               [12]  483 	mov	r5,a
      005460 A3               [24]  484 	inc	dptr
      005461 E0               [24]  485 	movx	a,@dptr
      005462 FE               [12]  486 	mov	r6,a
      005463 A3               [24]  487 	inc	dptr
      005464 E0               [24]  488 	movx	a,@dptr
      005465 FF               [12]  489 	mov	r7,a
      005466 8D 82            [24]  490 	mov	dpl,r5
      005468 8E 83            [24]  491 	mov	dph,r6
      00546A 8F F0            [24]  492 	mov	b,r7
      00546C 22               [24]  493 	ret
                                    494 
                                    495 	.area CSEG (CODE)
                                    496 ; function ak820_outline_0004
      00546D                        497 _ak820_outline_0004:
      00546D E0               [24]  498 	movx	a,@dptr
      00546E FD               [12]  499 	mov	r5,a
      00546F A3               [24]  500 	inc	dptr
      005470 E0               [24]  501 	movx	a,@dptr
      005471 FE               [12]  502 	mov	r6,a
      005472 A3               [24]  503 	inc	dptr
      005473 E0               [24]  504 	movx	a,@dptr
      005474 FF               [12]  505 	mov	r7,a
      005475 90 05 F4         [24]  506 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      005478 ED               [12]  507 	mov	a,r5
      005479 F0               [24]  508 	movx	@dptr,a
      00547A EE               [12]  509 	mov	a,r6
      00547B A3               [24]  510 	inc	dptr
      00547C F0               [24]  511 	movx	@dptr,a
      00547D EF               [12]  512 	mov	a,r7
      00547E A3               [24]  513 	inc	dptr
      00547F F0               [24]  514 	movx	@dptr,a
      005480 90 05 F7         [24]  515 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      005483 22               [24]  516 	ret
                                    517 
                                    518 	.area CSEG (CODE)
                                    519 ; function ak820_outline_0013
      005484                        520 _ak820_outline_0013:
      005484 E0               [24]  521 	movx	a,@dptr
      005485 FD               [12]  522 	mov	r5,a
      005486 A3               [24]  523 	inc	dptr
      005487 E0               [24]  524 	movx	a,@dptr
      005488 FE               [12]  525 	mov	r6,a
      005489 A3               [24]  526 	inc	dptr
      00548A E0               [24]  527 	movx	a,@dptr
      00548B FF               [12]  528 	mov	r7,a
      00548C 22               [24]  529 	ret
                                    530 
                                    531 	.area CSEG (CODE)
                                    532 ; function ak820_outline_0031
      00548D                        533 _ak820_outline_0031:
      00548D F0               [24]  534 	movx	@dptr,a
      00548E 8D 82            [24]  535 	mov	dpl,r5
      005490 8E 83            [24]  536 	mov	dph,r6
      005492 8F F0            [24]  537 	mov	b,r7
      005494 22               [24]  538 	ret
                                    539 
                                    540 	.area CSEG (CODE)
                                    541 ; function ak820_outline_0052
      005495                        542 _ak820_outline_0052:
      005495 E4               [12]  543 	clr	a
      005496 F0               [24]  544 	movx	@dptr,a
      005497 A3               [24]  545 	inc	dptr
      005498 F0               [24]  546 	movx	@dptr,a
      005499 A3               [24]  547 	inc	dptr
      00549A F0               [24]  548 	movx	@dptr,a
      00549B A3               [24]  549 	inc	dptr
      00549C F0               [24]  550 	movx	@dptr,a
      00549D 22               [24]  551 	ret
                                    552 
                                    553 	.area CSEG (CODE)
                                    554 ; function ak820_outline_0056
      00549E                        555 _ak820_outline_0056:
      00549E E0               [24]  556 	movx	a,@dptr
      00549F FC               [12]  557 	mov	r4,a
      0054A0 A3               [24]  558 	inc	dptr
      0054A1 E0               [24]  559 	movx	a,@dptr
      0054A2 FD               [12]  560 	mov	r5,a
      0054A3 A3               [24]  561 	inc	dptr
      0054A4 E0               [24]  562 	movx	a,@dptr
      0054A5 FE               [12]  563 	mov	r6,a
      0054A6 A3               [24]  564 	inc	dptr
      0054A7 E0               [24]  565 	movx	a,@dptr
      0054A8 8C 82            [24]  566 	mov	dpl,r4
      0054AA 8D 83            [24]  567 	mov	dph,r5
      0054AC 8E F0            [24]  568 	mov	b,r6
      0054AE 22               [24]  569 	ret
                                    570 
                                    571 	.area CSEG (CODE)
                                    572 ; function ak820_outline_0058
      0054AF                        573 _ak820_outline_0058:
      0054AF AC 82            [24]  574 	mov	r4,dpl
      0054B1 AD 83            [24]  575 	mov	r5,dph
      0054B3 AE F0            [24]  576 	mov	r6,b
      0054B5 FF               [12]  577 	mov	r7,a
      0054B6 22               [24]  578 	ret
                                    579 
                                    580 	.area CSEG (CODE)
                                    581 ; function ak820_outline_0093
      0054B7                        582 _ak820_outline_0093:
      0054B7 E0               [24]  583 	movx	a,@dptr
      0054B8 F9               [12]  584 	mov	r1,a
      0054B9 A3               [24]  585 	inc	dptr
      0054BA E0               [24]  586 	movx	a,@dptr
      0054BB FA               [12]  587 	mov	r2,a
      0054BC A3               [24]  588 	inc	dptr
      0054BD E0               [24]  589 	movx	a,@dptr
      0054BE FB               [12]  590 	mov	r3,a
      0054BF 22               [24]  591 	ret
                                    592 
                                    593 	.area CSEG (CODE)
                                    594 ; function ak820_outline_0094
      0054C0                        595 _ak820_outline_0094:
      0054C0 E0               [24]  596 	movx	a,@dptr
      0054C1 FE               [12]  597 	mov	r6,a
      0054C2 A3               [24]  598 	inc	dptr
      0054C3 E0               [24]  599 	movx	a,@dptr
      0054C4 8E 82            [24]  600 	mov	dpl,r6
      0054C6 F5 83            [12]  601 	mov	dph,a
      0054C8 22               [24]  602 	ret
                                    603 
                                    604 	.area CSEG (CODE)
                                    605 ; function ak820_outline_0113
      0054C9                        606 _ak820_outline_0113:
      0054C9 74 02            [12]  607 	mov	a,#0x02
      0054CB F0               [24]  608 	movx	@dptr,a
      0054CC E4               [12]  609 	clr	a
      0054CD A3               [24]  610 	inc	dptr
      0054CE F0               [24]  611 	movx	@dptr,a
      0054CF 22               [24]  612 	ret
                                    613 
                                    614 	.area CSEG (CODE)
                                    615 ; function ak820_outline_0158
      0054D0                        616 _ak820_outline_0158:
      0054D0 F0               [24]  617 	movx	@dptr,a
      0054D1 EA               [12]  618 	mov	a,r2
      0054D2 A3               [24]  619 	inc	dptr
      0054D3 F0               [24]  620 	movx	@dptr,a
      0054D4 EB               [12]  621 	mov	a,r3
      0054D5 A3               [24]  622 	inc	dptr
      0054D6 22               [24]  623 	ret
                                    624 
                                    625 	.area CSEG (CODE)
                                    626 ; function ak820_outline_0183
      0054D7                        627 _ak820_outline_0183:
      0054D7 E4               [12]  628 	clr	a
      0054D8 F0               [24]  629 	movx	@dptr,a
      0054D9 A3               [24]  630 	inc	dptr
      0054DA F0               [24]  631 	movx	@dptr,a
      0054DB 22               [24]  632 	ret
