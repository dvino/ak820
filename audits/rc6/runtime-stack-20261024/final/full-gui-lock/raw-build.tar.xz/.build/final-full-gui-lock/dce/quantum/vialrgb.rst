                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module vialrgb
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _rgb_matrix_get_speed
                                     12 	.globl _rgb_matrix_set_speed_noeeprom
                                     13 	.globl _rgb_matrix_get_val
                                     14 	.globl _rgb_matrix_get_sat
                                     15 	.globl _rgb_matrix_get_hue
                                     16 	.globl _rgb_matrix_sethsv_noeeprom
                                     17 	.globl _rgb_matrix_get_mode
                                     18 	.globl _rgb_matrix_mode_noeeprom
                                     19 	.globl _rgb_matrix_is_enabled
                                     20 	.globl _rgb_matrix_disable_noeeprom
                                     21 	.globl _rgb_matrix_enable_noeeprom
                                     22 	.globl _eeconfig_update_rgb_matrix
                                     23 	.globl _ADC_START
                                     24 	.globl _S0_R_FIFO
                                     25 	.globl _S0_T_FIFO
                                     26 	.globl _S0_FREE
                                     27 	.globl _S0_IF_BYTE
                                     28 	.globl _S0_IF_FIRST
                                     29 	.globl _S0_IF_OV
                                     30 	.globl _S0_FST_ACT
                                     31 	.globl _CP_RL2
                                     32 	.globl _C_T2
                                     33 	.globl _TR2
                                     34 	.globl _EXEN2
                                     35 	.globl _TCLK
                                     36 	.globl _RCLK
                                     37 	.globl _EXF2
                                     38 	.globl _CAP1F
                                     39 	.globl _TF2
                                     40 	.globl _RI
                                     41 	.globl _TI
                                     42 	.globl _RB8
                                     43 	.globl _TB8
                                     44 	.globl _REN
                                     45 	.globl _SM2
                                     46 	.globl _SM1
                                     47 	.globl _SM0
                                     48 	.globl _IT0
                                     49 	.globl _IE0
                                     50 	.globl _IT1
                                     51 	.globl _IE1
                                     52 	.globl _TR0
                                     53 	.globl _TF0
                                     54 	.globl _TR1
                                     55 	.globl _TF1
                                     56 	.globl _P4_0
                                     57 	.globl _P4_1
                                     58 	.globl _P4_2
                                     59 	.globl _P4_3
                                     60 	.globl _P4_4
                                     61 	.globl _P4_5
                                     62 	.globl _P4_6
                                     63 	.globl _RXD
                                     64 	.globl _TXD
                                     65 	.globl _INT0
                                     66 	.globl _INT1
                                     67 	.globl _T0
                                     68 	.globl _T1
                                     69 	.globl _MOSI1
                                     70 	.globl _MISO1
                                     71 	.globl _SCK1
                                     72 	.globl _P3_0
                                     73 	.globl _P3_1
                                     74 	.globl _P3_2
                                     75 	.globl _P3_3
                                     76 	.globl _P3_4
                                     77 	.globl _P3_5
                                     78 	.globl _P3_6
                                     79 	.globl _P3_7
                                     80 	.globl _CAP1_
                                     81 	.globl _T2_
                                     82 	.globl _CAP2_
                                     83 	.globl _T2EX_
                                     84 	.globl _RXD1
                                     85 	.globl _TXD1
                                     86 	.globl _P2_0
                                     87 	.globl _P2_1
                                     88 	.globl _P2_2
                                     89 	.globl _P2_3
                                     90 	.globl _P2_4
                                     91 	.globl _P2_5
                                     92 	.globl _P2_6
                                     93 	.globl _P2_7
                                     94 	.globl _AIN0
                                     95 	.globl _AIN1
                                     96 	.globl _AIN2
                                     97 	.globl _AIN3
                                     98 	.globl _AIN4
                                     99 	.globl _AIN5
                                    100 	.globl _AIN6
                                    101 	.globl _AIN7
                                    102 	.globl _CAP1
                                    103 	.globl _T2
                                    104 	.globl _CAP2
                                    105 	.globl _T2EX
                                    106 	.globl _INT0_
                                    107 	.globl _SCS
                                    108 	.globl _MOSI
                                    109 	.globl _MISO
                                    110 	.globl _SCK
                                    111 	.globl _RXD1_
                                    112 	.globl _TXD1_
                                    113 	.globl _P1_0
                                    114 	.globl _P1_1
                                    115 	.globl _P1_2
                                    116 	.globl _P1_3
                                    117 	.globl _P1_4
                                    118 	.globl _P1_5
                                    119 	.globl _P1_6
                                    120 	.globl _P1_7
                                    121 	.globl _AIN8
                                    122 	.globl _AIN9
                                    123 	.globl _AIN10
                                    124 	.globl _AIN11
                                    125 	.globl _AIN12
                                    126 	.globl _AIN13
                                    127 	.globl _RXD_
                                    128 	.globl _TXD_
                                    129 	.globl _SCL0
                                    130 	.globl _SDA0
                                    131 	.globl _P0_0
                                    132 	.globl _P0_1
                                    133 	.globl _P0_2
                                    134 	.globl _P0_3
                                    135 	.globl _P0_4
                                    136 	.globl _P0_5
                                    137 	.globl _P0_6
                                    138 	.globl _P0_7
                                    139 	.globl _IE_SPI0
                                    140 	.globl _IE_USB
                                    141 	.globl _IE_ADC
                                    142 	.globl _IE_UART1
                                    143 	.globl _IE_PWM_I2C
                                    144 	.globl _IE_GPIO
                                    145 	.globl _IE_WDOG
                                    146 	.globl _PX0
                                    147 	.globl _PT0
                                    148 	.globl _PX1
                                    149 	.globl _PT1
                                    150 	.globl _PS
                                    151 	.globl _PT2
                                    152 	.globl _PL_FLAG
                                    153 	.globl _PH_FLAG
                                    154 	.globl _EX0
                                    155 	.globl _ET0
                                    156 	.globl _EX1
                                    157 	.globl _ET1
                                    158 	.globl _ES
                                    159 	.globl _ET2
                                    160 	.globl _E_DIS
                                    161 	.globl _EA
                                    162 	.globl _P
                                    163 	.globl _F1
                                    164 	.globl _OV
                                    165 	.globl _RS0
                                    166 	.globl _RS1
                                    167 	.globl _F0
                                    168 	.globl _AC
                                    169 	.globl _CY
                                    170 	.globl _I2CS_INT_ST
                                    171 	.globl _I2CX_INT
                                    172 	.globl _LED_STATUS
                                    173 	.globl _LED_DMA_H
                                    174 	.globl _LED_DMA_L
                                    175 	.globl _LED_DMA
                                    176 	.globl _LED_PWM_OE
                                    177 	.globl _LED_COMMON
                                    178 	.globl _ADC_CHAN
                                    179 	.globl _ADC_DAT_H
                                    180 	.globl _ADC_DAT_L
                                    181 	.globl _ADC_DAT
                                    182 	.globl _ADC_CTRL
                                    183 	.globl _SPI1_CK_SE
                                    184 	.globl _SPI1_CTRL
                                    185 	.globl _SPI1_DATA
                                    186 	.globl _SPI1_STAT
                                    187 	.globl _SIF1
                                    188 	.globl _SBAUD1
                                    189 	.globl _SBUF1
                                    190 	.globl _SCON1
                                    191 	.globl _SPI0_SETUP
                                    192 	.globl _SPI0_CK_SE
                                    193 	.globl _SPI0_CTRL
                                    194 	.globl _SPI0_DATA
                                    195 	.globl _SPI0_STAT
                                    196 	.globl _T2CAP1H
                                    197 	.globl _T2CAP1L
                                    198 	.globl _T2CAP1
                                    199 	.globl _TH2
                                    200 	.globl _TL2
                                    201 	.globl _T2COUNT
                                    202 	.globl _RCAP2H
                                    203 	.globl _RCAP2L
                                    204 	.globl _RCAP2
                                    205 	.globl _T2MOD
                                    206 	.globl _T2CON
                                    207 	.globl _SBUF
                                    208 	.globl _SCON
                                    209 	.globl _TH1
                                    210 	.globl _TH0
                                    211 	.globl _TL1
                                    212 	.globl _TL0
                                    213 	.globl _TMOD
                                    214 	.globl _TCON
                                    215 	.globl _XBUS_AUX
                                    216 	.globl _P7
                                    217 	.globl _P6_DIR
                                    218 	.globl _P6_OUT_PU
                                    219 	.globl _P6_IN
                                    220 	.globl _P5_DIR
                                    221 	.globl _P5_OUT_PU
                                    222 	.globl _P5_IN
                                    223 	.globl _P4_LED_KEY
                                    224 	.globl _P4_DIR_PU
                                    225 	.globl _P4_MOD_OC
                                    226 	.globl _P4
                                    227 	.globl _P3_DIR_PU
                                    228 	.globl _P3_MOD_OC
                                    229 	.globl _P3
                                    230 	.globl _P2_DIR_PU
                                    231 	.globl _P2_MOD_OC
                                    232 	.globl _P2
                                    233 	.globl _P1_DIR_PU
                                    234 	.globl _P1_MOD_OC
                                    235 	.globl _P1
                                    236 	.globl _P0_DIR_PU
                                    237 	.globl _P0_MOD_OC
                                    238 	.globl _P0
                                    239 	.globl _ROM_CTRL
                                    240 	.globl _ROM_DATA_HH
                                    241 	.globl _ROM_DATA_HL
                                    242 	.globl _ROM_DATA_HI
                                    243 	.globl _ROM_ADDR_H
                                    244 	.globl _ROM_ADDR_L
                                    245 	.globl _ROM_ADDR
                                    246 	.globl _GPIO_IE
                                    247 	.globl _IP_EX
                                    248 	.globl _IE_EX
                                    249 	.globl _IP
                                    250 	.globl _IE
                                    251 	.globl _WDOG_COUNT
                                    252 	.globl _RESET_KEEP
                                    253 	.globl _WAKE_CTRL
                                    254 	.globl _CLOCK_CFG
                                    255 	.globl _POWER_CFG
                                    256 	.globl _PCON
                                    257 	.globl _GLOBAL_CFG
                                    258 	.globl _SAFE_MOD
                                    259 	.globl _DPH
                                    260 	.globl _DPL
                                    261 	.globl _SP
                                    262 	.globl _A_INV
                                    263 	.globl _B
                                    264 	.globl _ACC
                                    265 	.globl _PSW
                                    266 	.globl _vialrgb_save_PARM_2
                                    267 	.globl _vialrgb_set_value_PARM_2
                                    268 	.globl _vialrgb_get_value_PARM_2
                                    269 	.globl _g_direct_mode_colors
                                    270 	.globl _vialrgb_get_value
                                    271 	.globl _vialrgb_set_value
                                    272 	.globl _vialrgb_save
                                    273 ;--------------------------------------------------------
                                    274 ; special function registers
                                    275 ;--------------------------------------------------------
                                    276 	.area RSEG    (ABS,DATA)
      000000                        277 	.org 0x0000
                           0000D0   278 _PSW	=	0x00d0
                           0000E0   279 _ACC	=	0x00e0
                           0000F0   280 _B	=	0x00f0
                           0000FD   281 _A_INV	=	0x00fd
                           000081   282 _SP	=	0x0081
                           000082   283 _DPL	=	0x0082
                           000083   284 _DPH	=	0x0083
                           0000A1   285 _SAFE_MOD	=	0x00a1
                           0000B1   286 _GLOBAL_CFG	=	0x00b1
                           000087   287 _PCON	=	0x0087
                           0000BA   288 _POWER_CFG	=	0x00ba
                           0000B9   289 _CLOCK_CFG	=	0x00b9
                           0000A9   290 _WAKE_CTRL	=	0x00a9
                           0000FE   291 _RESET_KEEP	=	0x00fe
                           0000FF   292 _WDOG_COUNT	=	0x00ff
                           0000A8   293 _IE	=	0x00a8
                           0000B8   294 _IP	=	0x00b8
                           0000E8   295 _IE_EX	=	0x00e8
                           0000E9   296 _IP_EX	=	0x00e9
                           0000B2   297 _GPIO_IE	=	0x00b2
                           008584   298 _ROM_ADDR	=	0x8584
                           000084   299 _ROM_ADDR_L	=	0x0084
                           000085   300 _ROM_ADDR_H	=	0x0085
                           008F8E   301 _ROM_DATA_HI	=	0x8f8e
                           00008E   302 _ROM_DATA_HL	=	0x008e
                           00008F   303 _ROM_DATA_HH	=	0x008f
                           000086   304 _ROM_CTRL	=	0x0086
                           000080   305 _P0	=	0x0080
                           0000C4   306 _P0_MOD_OC	=	0x00c4
                           0000C5   307 _P0_DIR_PU	=	0x00c5
                           000090   308 _P1	=	0x0090
                           000092   309 _P1_MOD_OC	=	0x0092
                           000093   310 _P1_DIR_PU	=	0x0093
                           0000A0   311 _P2	=	0x00a0
                           000094   312 _P2_MOD_OC	=	0x0094
                           000095   313 _P2_DIR_PU	=	0x0095
                           0000B0   314 _P3	=	0x00b0
                           000096   315 _P3_MOD_OC	=	0x0096
                           000097   316 _P3_DIR_PU	=	0x0097
                           0000C0   317 _P4	=	0x00c0
                           0000C2   318 _P4_MOD_OC	=	0x00c2
                           0000C3   319 _P4_DIR_PU	=	0x00c3
                           0000C1   320 _P4_LED_KEY	=	0x00c1
                           0000AA   321 _P5_IN	=	0x00aa
                           0000AB   322 _P5_OUT_PU	=	0x00ab
                           0000AC   323 _P5_DIR	=	0x00ac
                           0000AD   324 _P6_IN	=	0x00ad
                           0000AE   325 _P6_OUT_PU	=	0x00ae
                           0000AF   326 _P6_DIR	=	0x00af
                           0000F1   327 _P7	=	0x00f1
                           0000A2   328 _XBUS_AUX	=	0x00a2
                           000088   329 _TCON	=	0x0088
                           000089   330 _TMOD	=	0x0089
                           00008A   331 _TL0	=	0x008a
                           00008B   332 _TL1	=	0x008b
                           00008C   333 _TH0	=	0x008c
                           00008D   334 _TH1	=	0x008d
                           000098   335 _SCON	=	0x0098
                           000099   336 _SBUF	=	0x0099
                           0000C8   337 _T2CON	=	0x00c8
                           0000C9   338 _T2MOD	=	0x00c9
                           00CBCA   339 _RCAP2	=	0xcbca
                           0000CA   340 _RCAP2L	=	0x00ca
                           0000CB   341 _RCAP2H	=	0x00cb
                           00CDCC   342 _T2COUNT	=	0xcdcc
                           0000CC   343 _TL2	=	0x00cc
                           0000CD   344 _TH2	=	0x00cd
                           00CFCE   345 _T2CAP1	=	0xcfce
                           0000CE   346 _T2CAP1L	=	0x00ce
                           0000CF   347 _T2CAP1H	=	0x00cf
                           0000F8   348 _SPI0_STAT	=	0x00f8
                           0000F9   349 _SPI0_DATA	=	0x00f9
                           0000FA   350 _SPI0_CTRL	=	0x00fa
                           0000FB   351 _SPI0_CK_SE	=	0x00fb
                           0000FC   352 _SPI0_SETUP	=	0x00fc
                           0000BC   353 _SCON1	=	0x00bc
                           0000BD   354 _SBUF1	=	0x00bd
                           0000BE   355 _SBAUD1	=	0x00be
                           0000BF   356 _SIF1	=	0x00bf
                           0000B4   357 _SPI1_STAT	=	0x00b4
                           0000B5   358 _SPI1_DATA	=	0x00b5
                           0000B6   359 _SPI1_CTRL	=	0x00b6
                           0000B7   360 _SPI1_CK_SE	=	0x00b7
                           0000F3   361 _ADC_CTRL	=	0x00f3
                           00F5F4   362 _ADC_DAT	=	0xf5f4
                           0000F4   363 _ADC_DAT_L	=	0x00f4
                           0000F5   364 _ADC_DAT_H	=	0x00f5
                           0000F6   365 _ADC_CHAN	=	0x00f6
                           0000A6   366 _LED_COMMON	=	0x00a6
                           0000A7   367 _LED_PWM_OE	=	0x00a7
                           00C7C6   368 _LED_DMA	=	0xc7c6
                           0000C6   369 _LED_DMA_L	=	0x00c6
                           0000C7   370 _LED_DMA_H	=	0x00c7
                           0000F7   371 _LED_STATUS	=	0x00f7
                           0000B3   372 _I2CX_INT	=	0x00b3
                           0000BB   373 _I2CS_INT_ST	=	0x00bb
                                    374 ;--------------------------------------------------------
                                    375 ; special function bits
                                    376 ;--------------------------------------------------------
                                    377 	.area RSEG    (ABS,DATA)
      000000                        378 	.org 0x0000
                           0000D7   379 _CY	=	0x00d7
                           0000D6   380 _AC	=	0x00d6
                           0000D5   381 _F0	=	0x00d5
                           0000D4   382 _RS1	=	0x00d4
                           0000D3   383 _RS0	=	0x00d3
                           0000D2   384 _OV	=	0x00d2
                           0000D1   385 _F1	=	0x00d1
                           0000D0   386 _P	=	0x00d0
                           0000AF   387 _EA	=	0x00af
                           0000AE   388 _E_DIS	=	0x00ae
                           0000AD   389 _ET2	=	0x00ad
                           0000AC   390 _ES	=	0x00ac
                           0000AB   391 _ET1	=	0x00ab
                           0000AA   392 _EX1	=	0x00aa
                           0000A9   393 _ET0	=	0x00a9
                           0000A8   394 _EX0	=	0x00a8
                           0000BF   395 _PH_FLAG	=	0x00bf
                           0000BE   396 _PL_FLAG	=	0x00be
                           0000BD   397 _PT2	=	0x00bd
                           0000BC   398 _PS	=	0x00bc
                           0000BB   399 _PT1	=	0x00bb
                           0000BA   400 _PX1	=	0x00ba
                           0000B9   401 _PT0	=	0x00b9
                           0000B8   402 _PX0	=	0x00b8
                           0000EF   403 _IE_WDOG	=	0x00ef
                           0000EE   404 _IE_GPIO	=	0x00ee
                           0000ED   405 _IE_PWM_I2C	=	0x00ed
                           0000EC   406 _IE_UART1	=	0x00ec
                           0000EB   407 _IE_ADC	=	0x00eb
                           0000E9   408 _IE_USB	=	0x00e9
                           0000E8   409 _IE_SPI0	=	0x00e8
                           000087   410 _P0_7	=	0x0087
                           000086   411 _P0_6	=	0x0086
                           000085   412 _P0_5	=	0x0085
                           000084   413 _P0_4	=	0x0084
                           000083   414 _P0_3	=	0x0083
                           000082   415 _P0_2	=	0x0082
                           000081   416 _P0_1	=	0x0081
                           000080   417 _P0_0	=	0x0080
                           000081   418 _SDA0	=	0x0081
                           000080   419 _SCL0	=	0x0080
                           000083   420 _TXD_	=	0x0083
                           000082   421 _RXD_	=	0x0082
                           000085   422 _AIN13	=	0x0085
                           000084   423 _AIN12	=	0x0084
                           000083   424 _AIN11	=	0x0083
                           000082   425 _AIN10	=	0x0082
                           000081   426 _AIN9	=	0x0081
                           000080   427 _AIN8	=	0x0080
                           000097   428 _P1_7	=	0x0097
                           000096   429 _P1_6	=	0x0096
                           000095   430 _P1_5	=	0x0095
                           000094   431 _P1_4	=	0x0094
                           000093   432 _P1_3	=	0x0093
                           000092   433 _P1_2	=	0x0092
                           000091   434 _P1_1	=	0x0091
                           000090   435 _P1_0	=	0x0090
                           000097   436 _TXD1_	=	0x0097
                           000096   437 _RXD1_	=	0x0096
                           000097   438 _SCK	=	0x0097
                           000096   439 _MISO	=	0x0096
                           000095   440 _MOSI	=	0x0095
                           000094   441 _SCS	=	0x0094
                           000092   442 _INT0_	=	0x0092
                           000091   443 _T2EX	=	0x0091
                           000091   444 _CAP2	=	0x0091
                           000090   445 _T2	=	0x0090
                           000090   446 _CAP1	=	0x0090
                           000097   447 _AIN7	=	0x0097
                           000096   448 _AIN6	=	0x0096
                           000095   449 _AIN5	=	0x0095
                           000094   450 _AIN4	=	0x0094
                           000093   451 _AIN3	=	0x0093
                           000092   452 _AIN2	=	0x0092
                           000091   453 _AIN1	=	0x0091
                           000090   454 _AIN0	=	0x0090
                           0000A7   455 _P2_7	=	0x00a7
                           0000A6   456 _P2_6	=	0x00a6
                           0000A5   457 _P2_5	=	0x00a5
                           0000A4   458 _P2_4	=	0x00a4
                           0000A3   459 _P2_3	=	0x00a3
                           0000A2   460 _P2_2	=	0x00a2
                           0000A1   461 _P2_1	=	0x00a1
                           0000A0   462 _P2_0	=	0x00a0
                           0000A7   463 _TXD1	=	0x00a7
                           0000A6   464 _RXD1	=	0x00a6
                           0000A5   465 _T2EX_	=	0x00a5
                           0000A5   466 _CAP2_	=	0x00a5
                           0000A4   467 _T2_	=	0x00a4
                           0000A4   468 _CAP1_	=	0x00a4
                           0000B7   469 _P3_7	=	0x00b7
                           0000B6   470 _P3_6	=	0x00b6
                           0000B5   471 _P3_5	=	0x00b5
                           0000B4   472 _P3_4	=	0x00b4
                           0000B3   473 _P3_3	=	0x00b3
                           0000B2   474 _P3_2	=	0x00b2
                           0000B1   475 _P3_1	=	0x00b1
                           0000B0   476 _P3_0	=	0x00b0
                           0000B7   477 _SCK1	=	0x00b7
                           0000B6   478 _MISO1	=	0x00b6
                           0000B5   479 _MOSI1	=	0x00b5
                           0000B5   480 _T1	=	0x00b5
                           0000B4   481 _T0	=	0x00b4
                           0000B3   482 _INT1	=	0x00b3
                           0000B2   483 _INT0	=	0x00b2
                           0000B1   484 _TXD	=	0x00b1
                           0000B0   485 _RXD	=	0x00b0
                           0000C6   486 _P4_6	=	0x00c6
                           0000C5   487 _P4_5	=	0x00c5
                           0000C4   488 _P4_4	=	0x00c4
                           0000C3   489 _P4_3	=	0x00c3
                           0000C2   490 _P4_2	=	0x00c2
                           0000C1   491 _P4_1	=	0x00c1
                           0000C0   492 _P4_0	=	0x00c0
                           00008F   493 _TF1	=	0x008f
                           00008E   494 _TR1	=	0x008e
                           00008D   495 _TF0	=	0x008d
                           00008C   496 _TR0	=	0x008c
                           00008B   497 _IE1	=	0x008b
                           00008A   498 _IT1	=	0x008a
                           000089   499 _IE0	=	0x0089
                           000088   500 _IT0	=	0x0088
                           00009F   501 _SM0	=	0x009f
                           00009E   502 _SM1	=	0x009e
                           00009D   503 _SM2	=	0x009d
                           00009C   504 _REN	=	0x009c
                           00009B   505 _TB8	=	0x009b
                           00009A   506 _RB8	=	0x009a
                           000099   507 _TI	=	0x0099
                           000098   508 _RI	=	0x0098
                           0000CF   509 _TF2	=	0x00cf
                           0000CF   510 _CAP1F	=	0x00cf
                           0000CE   511 _EXF2	=	0x00ce
                           0000CD   512 _RCLK	=	0x00cd
                           0000CC   513 _TCLK	=	0x00cc
                           0000CB   514 _EXEN2	=	0x00cb
                           0000CA   515 _TR2	=	0x00ca
                           0000C9   516 _C_T2	=	0x00c9
                           0000C8   517 _CP_RL2	=	0x00c8
                           0000FF   518 _S0_FST_ACT	=	0x00ff
                           0000FE   519 _S0_IF_OV	=	0x00fe
                           0000FD   520 _S0_IF_FIRST	=	0x00fd
                           0000FC   521 _S0_IF_BYTE	=	0x00fc
                           0000FB   522 _S0_FREE	=	0x00fb
                           0000FA   523 _S0_T_FIFO	=	0x00fa
                           0000F8   524 _S0_R_FIFO	=	0x00f8
                           0000F7   525 _ADC_START	=	0x00f7
                                    526 ;--------------------------------------------------------
                                    527 ; overlayable register banks
                                    528 ;--------------------------------------------------------
                                    529 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        530 	.ds 8
                                    531 ;--------------------------------------------------------
                                    532 ; internal ram data
                                    533 ;--------------------------------------------------------
                                    534 	.area DSEG    (DATA)
      00004A                        535 _fast_set_leds_sloc0_1_0:
      00004A                        536 	.ds 2
      00004C                        537 _fast_set_leds_sloc1_1_0:
      00004C                        538 	.ds 2
      00004E                        539 _vialrgb_get_value_sloc0_1_0:
      00004E                        540 	.ds 2
      000050                        541 _vialrgb_get_value_sloc1_1_0:
      000050                        542 	.ds 2
      000052                        543 _vialrgb_set_value_sloc0_1_0:
      000052                        544 	.ds 2
                                    545 ;--------------------------------------------------------
                                    546 ; overlayable items in internal ram
                                    547 ;--------------------------------------------------------
                                    548 ;--------------------------------------------------------
                                    549 ; indirectly addressable internal ram data
                                    550 ;--------------------------------------------------------
                                    551 	.area ISEG    (DATA)
                                    552 ;--------------------------------------------------------
                                    553 ; absolute internal ram data
                                    554 ;--------------------------------------------------------
                                    555 	.area IABS    (ABS,DATA)
                                    556 	.area IABS    (ABS,DATA)
                                    557 ;--------------------------------------------------------
                                    558 ; bit data
                                    559 ;--------------------------------------------------------
                                    560 	.area BSEG    (BIT)
                                    561 ;--------------------------------------------------------
                                    562 ; paged external ram data
                                    563 ;--------------------------------------------------------
                                    564 	.area PSEG    (PAG,XDATA)
                                    565 ;--------------------------------------------------------
                                    566 ; uninitialized external ram data
                                    567 ;--------------------------------------------------------
                                    568 	.area XSEG    (XDATA)
      000C93                        569 _g_direct_mode_colors::
      000C93                        570 	.ds 246
      000D89                        571 _get_supported_PARM_2:
      000D89                        572 	.ds 1
      000D8A                        573 _get_supported_args_10000_255:
      000D8A                        574 	.ds 2
      000D8C                        575 _qmk_id_to_vialrgb_id_id_10000_262:
      000D8C                        576 	.ds 2
      000D8E                        577 _vialrgb_id_to_qmk_id_id_10000_267:
      000D8E                        578 	.ds 2
      000D90                        579 _set_mode_mode_10000_275:
      000D90                        580 	.ds 2
      000D92                        581 _get_matrix_pos_for_led_PARM_2:
      000D92                        582 	.ds 2
      000D94                        583 _get_matrix_pos_for_led_led_10000_280:
      000D94                        584 	.ds 2
      000D96                        585 _fast_set_leds_PARM_2:
      000D96                        586 	.ds 1
      000D97                        587 _fast_set_leds_args_10000_282:
      000D97                        588 	.ds 2
      000D99                        589 _fast_set_leds_first_index_10001_285:
      000D99                        590 	.ds 2
      000D9B                        591 _fast_set_leds_num_leds_10001_285:
      000D9B                        592 	.ds 1
      000D9C                        593 _vialrgb_get_value_PARM_2:
      000D9C                        594 	.ds 1
      000D9D                        595 _vialrgb_get_value_data_10000_291:
      000D9D                        596 	.ds 3
      000DA0                        597 _vialrgb_set_value_PARM_2:
      000DA0                        598 	.ds 1
      000DA1                        599 _vialrgb_set_value_data_10000_302:
      000DA1                        600 	.ds 3
      000DA4                        601 _vialrgb_save_PARM_2:
      000DA4                        602 	.ds 1
                                    603 ;--------------------------------------------------------
                                    604 ; absolute external ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area XABS    (ABS,XDATA)
                                    607 ;--------------------------------------------------------
                                    608 ; initialized external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area XISEG   (XDATA)
                                    611 	.area HOME    (CODE)
                                    612 	.area GSINIT0 (CODE)
                                    613 	.area GSINIT1 (CODE)
                                    614 	.area GSINIT2 (CODE)
                                    615 	.area GSINIT3 (CODE)
                                    616 	.area GSINIT4 (CODE)
                                    617 	.area GSINIT5 (CODE)
                                    618 	.area GSINIT  (CODE)
                                    619 	.area GSFINAL (CODE)
                                    620 	.area CSEG    (CODE)
                                    621 ;--------------------------------------------------------
                                    622 ; global & static initialisations
                                    623 ;--------------------------------------------------------
                                    624 	.area HOME    (CODE)
                                    625 	.area GSINIT  (CODE)
                                    626 	.area GSFINAL (CODE)
                                    627 	.area GSINIT  (CODE)
                                    628 ;--------------------------------------------------------
                                    629 ; Home
                                    630 ;--------------------------------------------------------
                                    631 	.area HOME    (CODE)
                                    632 	.area HOME    (CODE)
                                    633 ;--------------------------------------------------------
                                    634 ; code
                                    635 ;--------------------------------------------------------
                                    636 	.area CSEG    (CODE)
                                    637 ;------------------------------------------------------------
                                    638 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    639 ;------------------------------------------------------------
                                    640 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_167'
                                    641 ;------------------------------------------------------------
                                    642 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    643 ;	-----------------------------------------
                           000007   644 	ar7 = 0x07
                           000006   645 	ar6 = 0x06
                           000005   646 	ar5 = 0x05
                           000004   647 	ar4 = 0x04
                           000003   648 	ar3 = 0x03
                           000002   649 	ar2 = 0x02
                           000001   650 	ar1 = 0x01
                           000000   651 	ar0 = 0x00
                                    652 ;	 function get_supported
                                    653 ;	-----------------------------------------
      00B2F3                        654 _get_supported:
      00B2F3 12 38 82         [24]  655 	lcall	_ak820_outline_0109
      00B2F6 90 0D 8A         [24]  656 	mov	dptr,#_get_supported_args_10000_255
      00B2F9 12 38 87         [24]  657 	lcall	_ak820_outline_0110
                                    658 ;	quantum/vialrgb.c:44: uint16_t gt = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00B2FC 90 0D 8A         [24]  659 	mov	dptr,#_get_supported_args_10000_255
      00B2FF 12 37 F4         [24]  660 	lcall	_ak820_outline_0005
      00B302 E0               [24]  661 	movx	a,@dptr
      00B303 FD               [12]  662 	mov	r5,a
      00B304 7C 00            [12]  663 	mov	r4,#0x00
      00B306 12 38 8C         [24]  664 	lcall	_ak820_outline_0120
      00B309 A3               [24]  665 	inc	dptr
      00B30A E0               [24]  666 	movx	a,@dptr
      00B30B FA               [12]  667 	mov	r2,a
      00B30C E4               [12]  668 	clr	a
      00B30D 12 43 62         [24]  669 	lcall	_ak820_outline_0144
                                    670 ;	quantum/vialrgb.c:45: for (uint8_t i = 0; i < length; ++i) args[i] = 0xff;
      00B310 90 0D 89         [24]  671 	mov	dptr,#_get_supported_PARM_2
      00B313 E0               [24]  672 	movx	a,@dptr
      00B314 FB               [12]  673 	mov	r3,a
      00B315 7A 00            [12]  674 	mov	r2,#0x00
      00B317                        675 00107$:
      00B317 C3               [12]  676 	clr	c
      00B318 EA               [12]  677 	mov	a,r2
      00B319 9B               [12]  678 	subb	a,r3
      00B31A 50 0A            [24]  679 	jnc	00101$
      00B31C EA               [12]  680 	mov	a,r2
      00B31D 12 38 31         [24]  681 	lcall	_ak820_outline_0021
      00B320 74 FF            [12]  682 	mov	a,#0xff
      00B322 F0               [24]  683 	movx	@dptr,a
      00B323 0A               [12]  684 	inc	r2
      00B324 80 F1            [24]  685 	sjmp	00107$
      00B326                        686 00101$:
                                    687 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B326 8D 06            [24]  688 	mov	ar6,r5
      00B328 8C 07            [24]  689 	mov	ar7,r4
      00B32A 8B 05            [24]  690 	mov	ar5,r3
      00B32C 90 0D 8A         [24]  691 	mov	dptr,#_get_supported_args_10000_255
      00B32F 12 38 91         [24]  692 	lcall	_ak820_outline_0124
      00B332 7A 00            [12]  693 	mov	r2,#0x00
      00B334                        694 00110$:
      00B334 BA 07 00         [24]  695 	cjne	r2,#0x07,00159$
      00B337                        696 00159$:
      00B337 50 45            [24]  697 	jnc	00127$
                                    698 ;	quantum/vialrgb.c:47: uint16_t id = READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00B339 EA               [12]  699 	mov	a,r2
      00B33A 75 F0 02         [24]  700 	mov	b,#0x02
      00B33D A4               [48]  701 	mul	ab
      00B33E 24 9A            [12]  702 	add	a, #_supported_modes
      00B340 F5 82            [12]  703 	mov	dpl,a
      00B342 74 BF            [12]  704 	mov	a,#(_supported_modes >> 8)
      00B344 12 57 17         [24]  705 	lcall	_ak820_outline_0111
      00B347 F8               [12]  706 	mov	r0,a
      00B348 79 00            [12]  707 	mov	r1,#0x00
                                    708 ;	quantum/vialrgb.c:48: if (id > gt && length >= sizeof(id)) {
      00B34A C3               [12]  709 	clr	c
      00B34B EE               [12]  710 	mov	a,r6
      00B34C 98               [12]  711 	subb	a,r0
      00B34D EF               [12]  712 	mov	a,r7
      00B34E 99               [12]  713 	subb	a,r1
      00B34F 50 2A            [24]  714 	jnc	00111$
                                    715 ;	free result
      00B351 BD 02 00         [24]  716 	cjne	r5,#0x02,00162$
      00B354                        717 00162$:
      00B354 40 25            [24]  718 	jc	00111$
                                    719 ;	quantum/vialrgb.c:49: args[0] = id;
      00B356 C0 06            [24]  720 	push	ar6
      00B358 C0 07            [24]  721 	push	ar7
      00B35A 88 07            [24]  722 	mov	ar7,r0
      00B35C 12 33 FC         [24]  723 	lcall	_ak820_outline_0125
      00B35F EF               [12]  724 	mov	a,r7
      00B360 12 6F 9D         [24]  725 	lcall	_ak820_outline_0103
                                    726 ;	quantum/vialrgb.c:50: args[1] = id >> 8;
      00B363 A3               [24]  727 	inc	dptr
      00B364 89 00            [24]  728 	mov	ar0,r1
      00B366 E8               [12]  729 	mov	a,r0
      00B367 F0               [24]  730 	movx	@dptr,a
                                    731 ;	quantum/vialrgb.c:51: length -= sizeof(id);
      00B368 1D               [12]  732 	dec	r5
      00B369 1D               [12]  733 	dec	r5
                                    734 ;	quantum/vialrgb.c:52: args += sizeof(id);
      00B36A 74 02            [12]  735 	mov	a,#0x02
      00B36C 2B               [12]  736 	add	a, r3
      00B36D FB               [12]  737 	mov	r3,a
      00B36E E4               [12]  738 	clr	a
      00B36F 3C               [12]  739 	addc	a, r4
      00B370 FC               [12]  740 	mov	r4,a
      00B371 90 0D 8A         [24]  741 	mov	dptr,#_get_supported_args_10000_255
      00B374 12 38 64         [24]  742 	lcall	_ak820_outline_0084
                                    743 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B377 D0 07            [24]  744 	pop	ar7
      00B379 D0 06            [24]  745 	pop	ar6
                                    746 ;	quantum/vialrgb.c:52: args += sizeof(id);
      00B37B                        747 00111$:
                                    748 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B37B 0A               [12]  749 	inc	r2
      00B37C 80 B6            [24]  750 	sjmp	00110$
      00B37E                        751 00127$:
      00B37E 90 0D 8A         [24]  752 	mov	dptr,#_get_supported_args_10000_255
      00B381 12 38 64         [24]  753 	lcall	_ak820_outline_0084
                                    754 ;	quantum/vialrgb.c:55: }
      00B384 22               [24]  755 	ret
                                    756 ;------------------------------------------------------------
                                    757 ;Allocation info for local variables in function 'qmk_id_to_vialrgb_id'
                                    758 ;------------------------------------------------------------
                                    759 ;id            Allocated with name '_qmk_id_to_vialrgb_id_id_10000_262'
                                    760 ;i             Allocated with name '_qmk_id_to_vialrgb_id_i_20000_264'
                                    761 ;qmk_id        Allocated with name '_qmk_id_to_vialrgb_id_qmk_id_30000_265'
                                    762 ;------------------------------------------------------------
                                    763 ;	quantum/vialrgb.c:57: static uint16_t qmk_id_to_vialrgb_id(uint16_t id) {
                                    764 ;	-----------------------------------------
                                    765 ;	 function qmk_id_to_vialrgb_id
                                    766 ;	-----------------------------------------
      00B385                        767 _qmk_id_to_vialrgb_id:
      00B385 12 38 82         [24]  768 	lcall	_ak820_outline_0109
      00B388 90 0D 8C         [24]  769 	mov	dptr,#_qmk_id_to_vialrgb_id_id_10000_262
      00B38B 12 38 87         [24]  770 	lcall	_ak820_outline_0110
                                    771 ;	quantum/vialrgb.c:58: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B38E 90 0D 8C         [24]  772 	mov	dptr,#_qmk_id_to_vialrgb_id_id_10000_262
      00B391 12 38 41         [24]  773 	lcall	_ak820_outline_0052
      00B394 7D 00            [12]  774 	mov	r5,#0x00
      00B396                        775 00105$:
      00B396 BD 07 00         [24]  776 	cjne	r5,#0x07,00130$
      00B399                        777 00130$:
      00B399 50 19            [24]  778 	jnc	00103$
                                    779 ;	quantum/vialrgb.c:59: uint16_t qmk_id = READ_MODE_ID(&supported_modes[i].qmk_id);
      00B39B 12 B7 B9         [24]  780 	lcall	_ak820_outline_0047
      00B39E A3               [24]  781 	inc	dptr
      00B39F E4               [12]  782 	clr	a
      00B3A0 93               [24]  783 	movc	a,@a+dptr
                                    784 ;	quantum/vialrgb.c:60: if (qmk_id == id)
      00B3A1 7A 00            [12]  785 	mov	r2,#0x00
      00B3A3 B5 06 0B         [24]  786 	cjne	a,ar6,00106$
      00B3A6 EA               [12]  787 	mov	a,r2
      00B3A7 B5 07 07         [24]  788 	cjne	a,ar7,00106$
                                    789 ;	quantum/vialrgb.c:61: return READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00B3AA 12 33 FC         [24]  790 	lcall	_ak820_outline_0125
      00B3AD 12 B7 E5         [24]  791 	lcall	_ak820_outline_0146
      00B3B0 22               [24]  792 	ret
      00B3B1                        793 00106$:
                                    794 ;	quantum/vialrgb.c:58: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B3B1 0D               [12]  795 	inc	r5
      00B3B2 80 E2            [24]  796 	sjmp	00105$
      00B3B4                        797 00103$:
                                    798 ;	quantum/vialrgb.c:63: return 0;
      00B3B4 90 00 00         [24]  799 	mov	dptr,#0x0000
                                    800 ;	quantum/vialrgb.c:64: }
      00B3B7 22               [24]  801 	ret
                                    802 ;------------------------------------------------------------
                                    803 ;Allocation info for local variables in function 'vialrgb_id_to_qmk_id'
                                    804 ;------------------------------------------------------------
                                    805 ;id            Allocated with name '_vialrgb_id_to_qmk_id_id_10000_267'
                                    806 ;i             Allocated with name '_vialrgb_id_to_qmk_id_i_20000_269'
                                    807 ;vialrgb_id    Allocated with name '_vialrgb_id_to_qmk_id_vialrgb_id_30000_270'
                                    808 ;------------------------------------------------------------
                                    809 ;	quantum/vialrgb.c:66: static uint16_t vialrgb_id_to_qmk_id(uint16_t id) {
                                    810 ;	-----------------------------------------
                                    811 ;	 function vialrgb_id_to_qmk_id
                                    812 ;	-----------------------------------------
      00B3B8                        813 _vialrgb_id_to_qmk_id:
      00B3B8 12 38 82         [24]  814 	lcall	_ak820_outline_0109
      00B3BB 90 0D 8E         [24]  815 	mov	dptr,#_vialrgb_id_to_qmk_id_id_10000_267
      00B3BE 12 38 87         [24]  816 	lcall	_ak820_outline_0110
                                    817 ;	quantum/vialrgb.c:67: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B3C1 90 0D 8E         [24]  818 	mov	dptr,#_vialrgb_id_to_qmk_id_id_10000_267
      00B3C4 12 38 41         [24]  819 	lcall	_ak820_outline_0052
      00B3C7 7D 00            [12]  820 	mov	r5,#0x00
      00B3C9                        821 00105$:
      00B3C9 BD 07 00         [24]  822 	cjne	r5,#0x07,00130$
      00B3CC                        823 00130$:
      00B3CC 50 19            [24]  824 	jnc	00103$
                                    825 ;	quantum/vialrgb.c:68: uint16_t vialrgb_id = READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00B3CE 12 B7 B9         [24]  826 	lcall	_ak820_outline_0047
      00B3D1 E4               [12]  827 	clr	a
      00B3D2 93               [24]  828 	movc	a,@a+dptr
                                    829 ;	quantum/vialrgb.c:69: if (vialrgb_id == id)
      00B3D3 7A 00            [12]  830 	mov	r2,#0x00
      00B3D5 B5 06 0C         [24]  831 	cjne	a,ar6,00106$
      00B3D8 EA               [12]  832 	mov	a,r2
      00B3D9 B5 07 08         [24]  833 	cjne	a,ar7,00106$
                                    834 ;	quantum/vialrgb.c:70: return READ_MODE_ID(&supported_modes[i].qmk_id);
      00B3DC 12 33 FC         [24]  835 	lcall	_ak820_outline_0125
      00B3DF A3               [24]  836 	inc	dptr
      00B3E0 12 B7 E5         [24]  837 	lcall	_ak820_outline_0146
      00B3E3 22               [24]  838 	ret
      00B3E4                        839 00106$:
                                    840 ;	quantum/vialrgb.c:67: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B3E4 0D               [12]  841 	inc	r5
      00B3E5 80 E2            [24]  842 	sjmp	00105$
      00B3E7                        843 00103$:
                                    844 ;	quantum/vialrgb.c:72: return 0;
      00B3E7 90 00 00         [24]  845 	mov	dptr,#0x0000
                                    846 ;	quantum/vialrgb.c:73: }
      00B3EA 22               [24]  847 	ret
                                    848 ;------------------------------------------------------------
                                    849 ;Allocation info for local variables in function 'get_mode'
                                    850 ;------------------------------------------------------------
                                    851 ;	quantum/vialrgb.c:75: static uint16_t get_mode(void) {
                                    852 ;	-----------------------------------------
                                    853 ;	 function get_mode
                                    854 ;	-----------------------------------------
      00B3EB                        855 _get_mode:
                                    856 ;	quantum/vialrgb.c:77: if (!rgb_matrix_is_enabled())
      00B3EB 12 54 FD         [24]  857 	lcall	_rgb_matrix_is_enabled
      00B3EE E5 82            [12]  858 	mov	a, dpl
      00B3F0 70 04            [24]  859 	jnz	00102$
                                    860 ;	quantum/vialrgb.c:78: return VIALRGB_EFFECT_OFF;
      00B3F2 90 00 00         [24]  861 	mov	dptr,#0x0000
      00B3F5 22               [24]  862 	ret
      00B3F6                        863 00102$:
                                    864 ;	quantum/vialrgb.c:79: return qmk_id_to_vialrgb_id(rgb_matrix_get_mode());
      00B3F6 12 55 03         [24]  865 	lcall	_rgb_matrix_get_mode
      00B3F9 7E 00            [12]  866 	mov	r6,#0x00
      00B3FB 8E 83            [24]  867 	mov	dph, r6
                                    868 ;	quantum/vialrgb.c:80: }
      00B3FD 02 B3 85         [24]  869 	ljmp	_qmk_id_to_vialrgb_id
                                    870 ;------------------------------------------------------------
                                    871 ;Allocation info for local variables in function 'set_mode'
                                    872 ;------------------------------------------------------------
                                    873 ;mode          Allocated with name '_set_mode_mode_10000_275'
                                    874 ;------------------------------------------------------------
                                    875 ;	quantum/vialrgb.c:82: static void set_mode(uint16_t mode) {
                                    876 ;	-----------------------------------------
                                    877 ;	 function set_mode
                                    878 ;	-----------------------------------------
      00B400                        879 _set_mode:
      00B400 12 38 82         [24]  880 	lcall	_ak820_outline_0109
      00B403 90 0D 90         [24]  881 	mov	dptr,#_set_mode_mode_10000_275
      00B406 12 38 87         [24]  882 	lcall	_ak820_outline_0110
                                    883 ;	quantum/vialrgb.c:84: if (mode == VIALRGB_EFFECT_OFF) {
      00B409 90 0D 90         [24]  884 	mov	dptr,#_set_mode_mode_10000_275
      00B40C 12 38 41         [24]  885 	lcall	_ak820_outline_0052
      00B40F 90 0D 90         [24]  886 	mov	dptr,#_set_mode_mode_10000_275
      00B412 12 6D 68         [24]  887 	lcall	_ak820_outline_0040
      00B415 70 03            [24]  888 	jnz	00102$
                                    889 ;	quantum/vialrgb.c:85: rgb_matrix_disable_noeeprom();
      00B417 02 55 50         [24]  890 	ljmp	_rgb_matrix_disable_noeeprom
      00B41A                        891 00102$:
                                    892 ;	quantum/vialrgb.c:87: rgb_matrix_enable_noeeprom();
      00B41A C0 07            [24]  893 	push	ar7
      00B41C C0 06            [24]  894 	push	ar6
      00B41E 12 55 3F         [24]  895 	lcall	_rgb_matrix_enable_noeeprom
      00B421 D0 06            [24]  896 	pop	ar6
      00B423 D0 07            [24]  897 	pop	ar7
                                    898 ;	quantum/vialrgb.c:88: rgb_matrix_mode_noeeprom(vialrgb_id_to_qmk_id(mode));
      00B425 12 38 8C         [24]  899 	lcall	_ak820_outline_0120
      00B428 12 B3 B8         [24]  900 	lcall	_vialrgb_id_to_qmk_id
                                    901 ;	quantum/vialrgb.c:90: }
      00B42B 02 55 59         [24]  902 	ljmp	_rgb_matrix_mode_noeeprom
                                    903 ;------------------------------------------------------------
                                    904 ;Allocation info for local variables in function 'get_matrix_pos_for_led'
                                    905 ;------------------------------------------------------------
                                    906 ;output        Allocated with name '_get_matrix_pos_for_led_PARM_2'
                                    907 ;led           Allocated with name '_get_matrix_pos_for_led_led_10000_280'
                                    908 ;slot          Allocated with name '_get_matrix_pos_for_led_slot_10000_281'
                                    909 ;------------------------------------------------------------
                                    910 ;	quantum/vialrgb.c:93: static void get_matrix_pos_for_led(uint16_t led, uint8_t VIALRGB_BUFFER *output) {
                                    911 ;	-----------------------------------------
                                    912 ;	 function get_matrix_pos_for_led
                                    913 ;	-----------------------------------------
      00B42E                        914 _get_matrix_pos_for_led:
      00B42E 12 38 82         [24]  915 	lcall	_ak820_outline_0109
      00B431 90 0D 94         [24]  916 	mov	dptr,#_get_matrix_pos_for_led_led_10000_280
      00B434 12 38 87         [24]  917 	lcall	_ak820_outline_0110
                                    918 ;	quantum/vialrgb.c:95: uint8_t slot = ak820_rgb_slots[led];
      00B437 90 0D 94         [24]  919 	mov	dptr,#_get_matrix_pos_for_led_led_10000_280
      00B43A 12 38 41         [24]  920 	lcall	_ak820_outline_0052
      00B43D EE               [12]  921 	mov	a,r6
      00B43E 24 A1            [12]  922 	add	a, #_ak820_rgb_slots
      00B440 F5 82            [12]  923 	mov	dpl,a
      00B442 EF               [12]  924 	mov	a,r7
      00B443 34 B9            [12]  925 	addc	a, #(_ak820_rgb_slots >> 8)
      00B445 F5 83            [12]  926 	mov	dph,a
      00B447 E4               [12]  927 	clr	a
      00B448 93               [24]  928 	movc	a,@a+dptr
      00B449 FF               [12]  929 	mov	r7,a
                                    930 ;	quantum/vialrgb.c:96: output[0] = slot >> 3;
      00B44A 90 0D 92         [24]  931 	mov	dptr,#_get_matrix_pos_for_led_PARM_2
      00B44D 12 38 6A         [24]  932 	lcall	_ak820_outline_0085
      00B450 EF               [12]  933 	mov	a,r7
      00B451 12 57 4D         [24]  934 	lcall	_ak820_outline_0190
      00B454 12 81 33         [24]  935 	lcall	_ak820_outline_0123
                                    936 ;	quantum/vialrgb.c:97: output[1] = slot & 7;
      00B457 12 38 9C         [24]  937 	lcall	_ak820_outline_0135
      00B45A A3               [24]  938 	inc	dptr
      00B45B 53 07 07         [24]  939 	anl	ar7,#0x07
      00B45E EF               [12]  940 	mov	a,r7
      00B45F F0               [24]  941 	movx	@dptr,a
                                    942 ;	quantum/vialrgb.c:110: }
      00B460 22               [24]  943 	ret
                                    944 ;------------------------------------------------------------
                                    945 ;Allocation info for local variables in function 'fast_set_leds'
                                    946 ;------------------------------------------------------------
                                    947 ;sloc0         Allocated with name '_fast_set_leds_sloc0_1_0'
                                    948 ;sloc1         Allocated with name '_fast_set_leds_sloc1_1_0'
                                    949 ;length        Allocated with name '_fast_set_leds_PARM_2'
                                    950 ;args          Allocated with name '_fast_set_leds_args_10000_282'
                                    951 ;first_index   Allocated with name '_fast_set_leds_first_index_10001_285'
                                    952 ;num_leds      Allocated with name '_fast_set_leds_num_leds_10001_285'
                                    953 ;i             Allocated with name '_fast_set_leds_i_20001_288'
                                    954 ;color         Allocated with name '_fast_set_leds_color_30001_289'
                                    955 ;val           Allocated with name '_fast_set_leds_val_30002_290'
                                    956 ;------------------------------------------------------------
                                    957 ;	quantum/vialrgb.c:112: static void fast_set_leds(uint8_t VIALRGB_BUFFER *args, uint8_t length) {
                                    958 ;	-----------------------------------------
                                    959 ;	 function fast_set_leds
                                    960 ;	-----------------------------------------
      00B461                        961 _fast_set_leds:
      00B461 12 38 82         [24]  962 	lcall	_ak820_outline_0109
      00B464 90 0D 97         [24]  963 	mov	dptr,#_fast_set_leds_args_10000_282
      00B467 12 38 87         [24]  964 	lcall	_ak820_outline_0110
                                    965 ;	quantum/vialrgb.c:115: if (length < 3) return;
      00B46A 90 0D 96         [24]  966 	mov	dptr,#_fast_set_leds_PARM_2
      00B46D E0               [24]  967 	movx	a,@dptr
      00B46E FF               [12]  968 	mov	r7,a
      00B46F BF 03 00         [24]  969 	cjne	r7,#0x03,00159$
      00B472                        970 00159$:
      00B472 50 01            [24]  971 	jnc	00102$
      00B474 22               [24]  972 	ret
      00B475                        973 00102$:
                                    974 ;	quantum/vialrgb.c:117: uint16_t first_index = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00B475 90 0D 97         [24]  975 	mov	dptr,#_fast_set_leds_args_10000_282
      00B478 E0               [24]  976 	movx	a,@dptr
      00B479 FD               [12]  977 	mov	r5,a
      00B47A A3               [24]  978 	inc	dptr
      00B47B E0               [24]  979 	movx	a,@dptr
      00B47C 12 48 8B         [24]  980 	lcall	_ak820_outline_0057
      00B47F 7B 00            [12]  981 	mov	r3,#0x00
      00B481 12 38 9C         [24]  982 	lcall	_ak820_outline_0135
      00B484 A3               [24]  983 	inc	dptr
      00B485 E0               [24]  984 	movx	a,@dptr
      00B486 FA               [12]  985 	mov	r2,a
      00B487 79 00            [12]  986 	mov	r1,#0x00
      00B489 90 0D 99         [24]  987 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00B48C E9               [12]  988 	mov	a,r1
      00B48D 4C               [12]  989 	orl	a,r4
      00B48E F0               [24]  990 	movx	@dptr,a
      00B48F EA               [12]  991 	mov	a,r2
      00B490 4B               [12]  992 	orl	a,r3
      00B491 A3               [24]  993 	inc	dptr
      00B492 F0               [24]  994 	movx	@dptr,a
                                    995 ;	quantum/vialrgb.c:118: uint8_t num_leds = args[2];
      00B493 12 38 9C         [24]  996 	lcall	_ak820_outline_0135
      00B496 A3               [24]  997 	inc	dptr
      00B497 A3               [24]  998 	inc	dptr
      00B498 E0               [24]  999 	movx	a,@dptr
      00B499 90 0D 9B         [24] 1000 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B49C F0               [24] 1001 	movx	@dptr,a
                                   1002 ;	quantum/vialrgb.c:119: length -= 3;
      00B49D EF               [12] 1003 	mov	a,r7
      00B49E 24 FD            [12] 1004 	add	a,#0xfd
      00B4A0 90 0D 96         [24] 1005 	mov	dptr,#_fast_set_leds_PARM_2
      00B4A3 F0               [24] 1006 	movx	@dptr,a
                                   1007 ;	quantum/vialrgb.c:120: args += 3;
      00B4A4 90 0D 97         [24] 1008 	mov	dptr,#_fast_set_leds_args_10000_282
      00B4A7 74 03            [12] 1009 	mov	a,#0x03
      00B4A9 2D               [12] 1010 	add	a, r5
      00B4AA F0               [24] 1011 	movx	@dptr,a
      00B4AB E4               [12] 1012 	clr	a
      00B4AC 3E               [12] 1013 	addc	a, r6
      00B4AD A3               [24] 1014 	inc	dptr
      00B4AE F0               [24] 1015 	movx	@dptr,a
                                   1016 ;	quantum/vialrgb.c:123: if ((uint16_t)num_leds * 3u > length || first_index >= RGB_MATRIX_LED_COUNT) return;
      00B4AF 90 0D 9B         [24] 1017 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B4B2 E0               [24] 1018 	movx	a,@dptr
      00B4B3 FF               [12] 1019 	mov	r7,a
      00B4B4 75 F0 03         [24] 1020 	mov	b,#0x03
      00B4B7 A4               [48] 1021 	mul	ab
      00B4B8 FE               [12] 1022 	mov	r6,a
      00B4B9 AD F0            [24] 1023 	mov	r5,b
      00B4BB 90 0D 96         [24] 1024 	mov	dptr,#_fast_set_leds_PARM_2
      00B4BE E0               [24] 1025 	movx	a,@dptr
      00B4BF FB               [12] 1026 	mov	r3,a
      00B4C0 7C 00            [12] 1027 	mov	r4,#0x00
      00B4C2 C3               [12] 1028 	clr	c
      00B4C3 EB               [12] 1029 	mov	a,r3
      00B4C4 9E               [12] 1030 	subb	a,r6
      00B4C5 EC               [12] 1031 	mov	a,r4
      00B4C6 9D               [12] 1032 	subb	a,r5
      00B4C7 40 13            [24] 1033 	jc	00103$
                                   1034 ;	free result
      00B4C9 90 0D 99         [24] 1035 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00B4CC 12 38 6A         [24] 1036 	lcall	_ak820_outline_0085
      00B4CF 8D 03            [24] 1037 	mov	ar3,r5
      00B4D1 8E 04            [24] 1038 	mov	ar4,r6
      00B4D3 C3               [12] 1039 	clr	c
      00B4D4 EB               [12] 1040 	mov	a,r3
      00B4D5 94 52            [12] 1041 	subb	a,#0x52
      00B4D7 EC               [12] 1042 	mov	a,r4
      00B4D8 94 00            [12] 1043 	subb	a,#0x00
      00B4DA 40 01            [24] 1044 	jc	00104$
      00B4DC                       1045 00103$:
      00B4DC 22               [24] 1046 	ret
      00B4DD                       1047 00104$:
                                   1048 ;	quantum/vialrgb.c:124: if (num_leds > RGB_MATRIX_LED_COUNT - first_index) num_leds = RGB_MATRIX_LED_COUNT - first_index;
      00B4DD 74 52            [12] 1049 	mov	a,#0x52
      00B4DF C3               [12] 1050 	clr	c
      00B4E0 9D               [12] 1051 	subb	a,r5
      00B4E1 FB               [12] 1052 	mov	r3,a
      00B4E2 E4               [12] 1053 	clr	a
      00B4E3 9E               [12] 1054 	subb	a,r6
      00B4E4 FC               [12] 1055 	mov	r4,a
      00B4E5 7A 00            [12] 1056 	mov	r2,#0x00
      00B4E7 C3               [12] 1057 	clr	c
      00B4E8 EB               [12] 1058 	mov	a,r3
      00B4E9 9F               [12] 1059 	subb	a,r7
      00B4EA EC               [12] 1060 	mov	a,r4
      00B4EB 9A               [12] 1061 	subb	a,r2
      00B4EC 50 08            [24] 1062 	jnc	00127$
                                   1063 ;	free result
      00B4EE 90 0D 9B         [24] 1064 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B4F1 74 52            [12] 1065 	mov	a,#0x52
      00B4F3 C3               [12] 1066 	clr	c
      00B4F4 9D               [12] 1067 	subb	a,r5
      00B4F5 F0               [24] 1068 	movx	@dptr,a
                                   1069 ;	quantum/vialrgb.c:126: for (uint8_t i = 0; i < num_leds; ++i) {
      00B4F6                       1070 00127$:
      00B4F6 90 0D 9B         [24] 1071 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B4F9 E0               [24] 1072 	movx	a,@dptr
      00B4FA FF               [12] 1073 	mov	r7,a
      00B4FB 90 0D 99         [24] 1074 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00B4FE 12 38 6A         [24] 1075 	lcall	_ak820_outline_0085
      00B501 7C 00            [12] 1076 	mov	r4,#0x00
      00B503                       1077 00110$:
      00B503 C3               [12] 1078 	clr	c
      00B504 EC               [12] 1079 	mov	a,r4
      00B505 9F               [12] 1080 	subb	a,r7
      00B506 40 01            [24] 1081 	jc	00164$
      00B508 22               [24] 1082 	ret
      00B509                       1083 00164$:
                                   1084 ;	quantum/vialrgb.c:127: HSV VIALRGB_BUFFER *color = &g_direct_mode_colors[first_index++];
      00B509 C0 07            [24] 1085 	push	ar7
      00B50B 90 0D B3         [24] 1086 	mov	dptr,#__mulint_PARM_2
      00B50E 12 43 78         [24] 1087 	lcall	_ak820_outline_0165
      00B511 90 00 03         [24] 1088 	mov	dptr,#0x0003
      00B514 C0 07            [24] 1089 	push	ar7
      00B516 C0 06            [24] 1090 	push	ar6
      00B518 C0 05            [24] 1091 	push	ar5
      00B51A C0 04            [24] 1092 	push	ar4
      00B51C 12 B9 51         [24] 1093 	lcall	__mulint
      00B51F AA 82            [24] 1094 	mov	r2, dpl
      00B521 AB 83            [24] 1095 	mov	r3, dph
      00B523 D0 04            [24] 1096 	pop	ar4
      00B525 D0 05            [24] 1097 	pop	ar5
      00B527 D0 06            [24] 1098 	pop	ar6
      00B529 D0 07            [24] 1099 	pop	ar7
      00B52B 0D               [12] 1100 	inc	r5
      00B52C BD 00 01         [24] 1101 	cjne	r5,#0x00,00165$
      00B52F 0E               [12] 1102 	inc	r6
      00B530                       1103 00165$:
      00B530 EA               [12] 1104 	mov	a,r2
      00B531 24 93            [12] 1105 	add	a, #_g_direct_mode_colors
      00B533 FA               [12] 1106 	mov	r2,a
      00B534 EB               [12] 1107 	mov	a,r3
      00B535 34 0C            [12] 1108 	addc	a, #(_g_direct_mode_colors >> 8)
      00B537 FB               [12] 1109 	mov	r3,a
                                   1110 ;	quantum/vialrgb.c:128: color->h = *args++;
      00B538 8A 4A            [24] 1111 	mov	_fast_set_leds_sloc0_1_0,r2
      00B53A 8B 4B            [24] 1112 	mov	(_fast_set_leds_sloc0_1_0 + 1),r3
      00B53C 12 B7 CB         [24] 1113 	lcall	_ak820_outline_0083
      00B53F F8               [12] 1114 	mov	r0,a
      00B540 12 B7 D9         [24] 1115 	lcall	_ak820_outline_0108
      00B543 85 4A 82         [24] 1116 	mov	dpl,_fast_set_leds_sloc0_1_0
      00B546 85 4B 83         [24] 1117 	mov	dph,(_fast_set_leds_sloc0_1_0 + 1)
      00B549 E8               [12] 1118 	mov	a,r0
      00B54A F0               [24] 1119 	movx	@dptr,a
                                   1120 ;	quantum/vialrgb.c:129: color->s = *args++;
      00B54B 74 01            [12] 1121 	mov	a,#0x01
      00B54D 2A               [12] 1122 	add	a, r2
      00B54E F5 4A            [12] 1123 	mov	_fast_set_leds_sloc0_1_0,a
      00B550 E4               [12] 1124 	clr	a
      00B551 3B               [12] 1125 	addc	a, r3
      00B552 F5 4B            [12] 1126 	mov	(_fast_set_leds_sloc0_1_0 + 1),a
      00B554 90 0D 97         [24] 1127 	mov	dptr,#_fast_set_leds_args_10000_282
      00B557 E0               [24] 1128 	movx	a,@dptr
      00B558 F8               [12] 1129 	mov	r0,a
      00B559 A3               [24] 1130 	inc	dptr
      00B55A E0               [24] 1131 	movx	a,@dptr
      00B55B FF               [12] 1132 	mov	r7,a
      00B55C 88 82            [24] 1133 	mov	dpl,r0
      00B55E 8F 83            [24] 1134 	mov	dph,r7
      00B560 E0               [24] 1135 	movx	a,@dptr
      00B561 F9               [12] 1136 	mov	r1,a
      00B562 90 0D 97         [24] 1137 	mov	dptr,#_fast_set_leds_args_10000_282
      00B565 74 01            [12] 1138 	mov	a,#0x01
      00B567 28               [12] 1139 	add	a, r0
      00B568 F0               [24] 1140 	movx	@dptr,a
      00B569 E4               [12] 1141 	clr	a
      00B56A 3F               [12] 1142 	addc	a, r7
      00B56B A3               [24] 1143 	inc	dptr
      00B56C F0               [24] 1144 	movx	@dptr,a
      00B56D 85 4A 82         [24] 1145 	mov	dpl,_fast_set_leds_sloc0_1_0
      00B570 85 4B 83         [24] 1146 	mov	dph,(_fast_set_leds_sloc0_1_0 + 1)
      00B573 E9               [12] 1147 	mov	a,r1
      00B574 F0               [24] 1148 	movx	@dptr,a
                                   1149 ;	quantum/vialrgb.c:130: uint8_t val = *args++;
      00B575 12 B7 CB         [24] 1150 	lcall	_ak820_outline_0083
      00B578 F5 4A            [12] 1151 	mov	_fast_set_leds_sloc0_1_0,a
      00B57A 12 B7 D9         [24] 1152 	lcall	_ak820_outline_0108
                                   1153 ;	quantum/vialrgb.c:131: color->v = (val > RGB_MATRIX_MAXIMUM_BRIGHTNESS) ? RGB_MATRIX_MAXIMUM_BRIGHTNESS : val;
      00B57D 74 02            [12] 1154 	mov	a,#0x02
      00B57F 2A               [12] 1155 	add	a, r2
      00B580 F5 4C            [12] 1156 	mov	_fast_set_leds_sloc1_1_0,a
      00B582 E4               [12] 1157 	clr	a
      00B583 3B               [12] 1158 	addc	a, r3
      00B584 F5 4D            [12] 1159 	mov	(_fast_set_leds_sloc1_1_0 + 1),a
      00B586 C3               [12] 1160 	clr	c
      00B587 74 A0            [12] 1161 	mov	a,#0xa0
      00B589 95 4A            [12] 1162 	subb	a,_fast_set_leds_sloc0_1_0
      00B58B D0 07            [24] 1163 	pop	ar7
      00B58D 50 04            [24] 1164 	jnc	00114$
                                   1165 ;	free result
      00B58F 7B A0            [12] 1166 	mov	r3,#0xa0
      00B591 80 04            [24] 1167 	sjmp	00115$
      00B593                       1168 00114$:
      00B593 AA 4A            [24] 1169 	mov	r2,_fast_set_leds_sloc0_1_0
      00B595 8A 03            [24] 1170 	mov	ar3,r2
      00B597                       1171 00115$:
      00B597 85 4C 82         [24] 1172 	mov	dpl,_fast_set_leds_sloc1_1_0
      00B59A 85 4D 83         [24] 1173 	mov	dph,(_fast_set_leds_sloc1_1_0 + 1)
      00B59D EB               [12] 1174 	mov	a,r3
      00B59E F0               [24] 1175 	movx	@dptr,a
                                   1176 ;	quantum/vialrgb.c:126: for (uint8_t i = 0; i < num_leds; ++i) {
      00B59F 0C               [12] 1177 	inc	r4
                                   1178 ;	quantum/vialrgb.c:133: }
      00B5A0 02 B5 03         [24] 1179 	ljmp	00110$
                                   1180 ;------------------------------------------------------------
                                   1181 ;Allocation info for local variables in function 'vialrgb_get_value'
                                   1182 ;------------------------------------------------------------
                                   1183 ;sloc0         Allocated with name '_vialrgb_get_value_sloc0_1_0'
                                   1184 ;sloc1         Allocated with name '_vialrgb_get_value_sloc1_1_0'
                                   1185 ;length        Allocated with name '_vialrgb_get_value_PARM_2'
                                   1186 ;data          Allocated with name '_vialrgb_get_value_data_10000_291'
                                   1187 ;args          Allocated with name '_vialrgb_get_value_args_10001_294'
                                   1188 ;cmd           Allocated with name '_vialrgb_get_value_cmd_10001_294'
                                   1189 ;vialrgb_id    Allocated with name '_vialrgb_get_value_vialrgb_id_40001_297'
                                   1190 ;led           Allocated with name '_vialrgb_get_value_led_40001_300'
                                   1191 ;------------------------------------------------------------
                                   1192 ;	quantum/vialrgb.c:136: void vialrgb_get_value(uint8_t *data, uint8_t length) {
                                   1193 ;	-----------------------------------------
                                   1194 ;	 function vialrgb_get_value
                                   1195 ;	-----------------------------------------
      00B5A3                       1196 _vialrgb_get_value:
      00B5A3 12 43 15         [24] 1197 	lcall	_ak820_outline_0036
      00B5A6 90 0D 9D         [24] 1198 	mov	dptr,#_vialrgb_get_value_data_10000_291
      00B5A9 12 38 1F         [24] 1199 	lcall	_ak820_outline_0016
                                   1200 ;	quantum/vialrgb.c:137: if (length != VIAL_RAW_EPSIZE) return;
      00B5AC 90 0D 9C         [24] 1201 	mov	dptr,#_vialrgb_get_value_PARM_2
      00B5AF E0               [24] 1202 	movx	a,@dptr
      00B5B0 FF               [12] 1203 	mov	r7,a
      00B5B1 BF 20 02         [24] 1204 	cjne	r7,#0x20,00162$
      00B5B4 80 01            [24] 1205 	sjmp	00102$
      00B5B6                       1206 00162$:
      00B5B6 22               [24] 1207 	ret
      00B5B7                       1208 00102$:
                                   1209 ;	quantum/vialrgb.c:140: uint8_t VIALRGB_BUFFER *args = (uint8_t VIALRGB_BUFFER *)data + 2;
      00B5B7 90 0D 9D         [24] 1210 	mov	dptr,#_vialrgb_get_value_data_10000_291
      00B5BA 12 B7 A5         [24] 1211 	lcall	_ak820_outline_0046
                                   1212 ;	quantum/vialrgb.c:141: uint8_t cmd = args[-1];
                                   1213 ;	quantum/vialrgb.c:142: switch (cmd) {
      00B5BD BA 40 02         [24] 1214 	cjne	r2,#0x40,00163$
      00B5C0 80 18            [24] 1215 	sjmp	00103$
      00B5C2                       1216 00163$:
      00B5C2 BA 41 02         [24] 1217 	cjne	r2,#0x41,00164$
      00B5C5 80 26            [24] 1218 	sjmp	00104$
      00B5C7                       1219 00164$:
      00B5C7 BA 42 03         [24] 1220 	cjne	r2,#0x42,00165$
      00B5CA 02 B6 7F         [24] 1221 	ljmp	00105$
      00B5CD                       1222 00165$:
      00B5CD BA 43 03         [24] 1223 	cjne	r2,#0x43,00166$
      00B5D0 02 B6 8B         [24] 1224 	ljmp	00106$
      00B5D3                       1225 00166$:
      00B5D3 BA 44 03         [24] 1226 	cjne	r2,#0x44,00167$
      00B5D6 02 B6 97         [24] 1227 	ljmp	00107$
      00B5D9                       1228 00167$:
      00B5D9 22               [24] 1229 	ret
                                   1230 ;	quantum/vialrgb.c:143: case vialrgb_get_info:
      00B5DA                       1231 00103$:
                                   1232 ;	quantum/vialrgb.c:144: args[0] = VIALRGB_PROTOCOL_VERSION & 0xFF;
      00B5DA 12 33 FC         [24] 1233 	lcall	_ak820_outline_0125
      00B5DD 74 01            [12] 1234 	mov	a,#0x01
      00B5DF F0               [24] 1235 	movx	@dptr,a
                                   1236 ;	quantum/vialrgb.c:145: args[1] = VIALRGB_PROTOCOL_VERSION >> 8;
      00B5E0 12 B7 9D         [24] 1237 	lcall	_ak820_outline_0039
      00B5E3 E4               [12] 1238 	clr	a
      00B5E4 F0               [24] 1239 	movx	@dptr,a
                                   1240 ;	quantum/vialrgb.c:146: args[2] = RGB_MATRIX_MAXIMUM_BRIGHTNESS;
      00B5E5 12 B7 9D         [24] 1241 	lcall	_ak820_outline_0039
      00B5E8 A3               [24] 1242 	inc	dptr
      00B5E9 74 A0            [12] 1243 	mov	a,#0xa0
      00B5EB F0               [24] 1244 	movx	@dptr,a
                                   1245 ;	quantum/vialrgb.c:147: break;
      00B5EC 22               [24] 1246 	ret
                                   1247 ;	quantum/vialrgb.c:148: case vialrgb_get_mode: {
      00B5ED                       1248 00104$:
                                   1249 ;	quantum/vialrgb.c:149: uint16_t vialrgb_id = get_mode();
      00B5ED C0 06            [24] 1250 	push	ar6
      00B5EF C0 05            [24] 1251 	push	ar5
      00B5F1 C0 04            [24] 1252 	push	ar4
      00B5F3 C0 03            [24] 1253 	push	ar3
      00B5F5 12 B3 EB         [24] 1254 	lcall	_get_mode
      00B5F8 A9 82            [24] 1255 	mov	r1, dpl
      00B5FA AA 83            [24] 1256 	mov	r2, dph
      00B5FC D0 03            [24] 1257 	pop	ar3
      00B5FE D0 04            [24] 1258 	pop	ar4
      00B600 D0 05            [24] 1259 	pop	ar5
      00B602 D0 06            [24] 1260 	pop	ar6
                                   1261 ;	quantum/vialrgb.c:150: args[0] = vialrgb_id & 0xFF;
      00B604 89 00            [24] 1262 	mov	ar0,r1
      00B606 12 33 FC         [24] 1263 	lcall	_ak820_outline_0125
      00B609 E8               [12] 1264 	mov	a,r0
      00B60A F0               [24] 1265 	movx	@dptr,a
                                   1266 ;	quantum/vialrgb.c:151: args[1] = vialrgb_id >> 8;
      00B60B 12 B7 9D         [24] 1267 	lcall	_ak820_outline_0039
      00B60E 8A 01            [24] 1268 	mov	ar1,r2
      00B610 E9               [12] 1269 	mov	a,r1
      00B611 F0               [24] 1270 	movx	@dptr,a
                                   1271 ;	quantum/vialrgb.c:152: args[2] = rgb_matrix_get_speed();
      00B612 74 04            [12] 1272 	mov	a,#0x04
      00B614 12 8E 9E         [24] 1273 	lcall	_ak820_outline_0138
      00B617 C0 06            [24] 1274 	push	ar6
      00B619 C0 05            [24] 1275 	push	ar5
      00B61B C0 02            [24] 1276 	push	ar2
      00B61D C0 01            [24] 1277 	push	ar1
      00B61F 12 55 1E         [24] 1278 	lcall	_rgb_matrix_get_speed
      00B622 A8 82            [24] 1279 	mov	r0, dpl
      00B624 D0 01            [24] 1280 	pop	ar1
      00B626 D0 02            [24] 1281 	pop	ar2
      00B628 D0 05            [24] 1282 	pop	ar5
      00B62A D0 06            [24] 1283 	pop	ar6
      00B62C 12 81 0C         [24] 1284 	lcall	_ak820_outline_0064
                                   1285 ;	quantum/vialrgb.c:153: args[3] = rgb_matrix_get_hue();
      00B62F 74 05            [12] 1286 	mov	a,#0x05
      00B631 12 8E 9E         [24] 1287 	lcall	_ak820_outline_0138
      00B634 C0 06            [24] 1288 	push	ar6
      00B636 C0 05            [24] 1289 	push	ar5
      00B638 C0 02            [24] 1290 	push	ar2
      00B63A C0 01            [24] 1291 	push	ar1
      00B63C 12 55 09         [24] 1292 	lcall	_rgb_matrix_get_hue
      00B63F A8 82            [24] 1293 	mov	r0, dpl
      00B641 D0 01            [24] 1294 	pop	ar1
      00B643 D0 02            [24] 1295 	pop	ar2
      00B645 D0 05            [24] 1296 	pop	ar5
      00B647 D0 06            [24] 1297 	pop	ar6
      00B649 12 81 0C         [24] 1298 	lcall	_ak820_outline_0064
                                   1299 ;	quantum/vialrgb.c:154: args[4] = rgb_matrix_get_sat();
      00B64C 74 06            [12] 1300 	mov	a,#0x06
      00B64E 12 8E 9E         [24] 1301 	lcall	_ak820_outline_0138
      00B651 C0 06            [24] 1302 	push	ar6
      00B653 C0 05            [24] 1303 	push	ar5
      00B655 C0 02            [24] 1304 	push	ar2
      00B657 C0 01            [24] 1305 	push	ar1
      00B659 12 55 10         [24] 1306 	lcall	_rgb_matrix_get_sat
      00B65C A8 82            [24] 1307 	mov	r0, dpl
      00B65E D0 01            [24] 1308 	pop	ar1
      00B660 D0 02            [24] 1309 	pop	ar2
      00B662 D0 05            [24] 1310 	pop	ar5
      00B664 D0 06            [24] 1311 	pop	ar6
      00B666 12 81 0C         [24] 1312 	lcall	_ak820_outline_0064
                                   1313 ;	quantum/vialrgb.c:155: args[5] = rgb_matrix_get_val();
      00B669 74 07            [12] 1314 	mov	a,#0x07
      00B66B 12 8E 9E         [24] 1315 	lcall	_ak820_outline_0138
      00B66E C0 02            [24] 1316 	push	ar2
      00B670 C0 01            [24] 1317 	push	ar1
      00B672 12 55 17         [24] 1318 	lcall	_rgb_matrix_get_val
      00B675 A8 82            [24] 1319 	mov	r0, dpl
      00B677 D0 01            [24] 1320 	pop	ar1
      00B679 D0 02            [24] 1321 	pop	ar2
      00B67B 12 81 0C         [24] 1322 	lcall	_ak820_outline_0064
                                   1323 ;	quantum/vialrgb.c:156: break;
      00B67E 22               [24] 1324 	ret
                                   1325 ;	quantum/vialrgb.c:158: case vialrgb_get_supported: {
      00B67F                       1326 00105$:
                                   1327 ;	quantum/vialrgb.c:159: get_supported(args, length - 2);
      00B67F EF               [12] 1328 	mov	a,r7
      00B680 24 FE            [12] 1329 	add	a,#0xfe
      00B682 90 0D 89         [24] 1330 	mov	dptr,#_get_supported_PARM_2
      00B685 12 6F 9D         [24] 1331 	lcall	_ak820_outline_0103
                                   1332 ;	quantum/vialrgb.c:160: break;
      00B688 02 B2 F3         [24] 1333 	ljmp	_get_supported
                                   1334 ;	quantum/vialrgb.c:163: case vialrgb_get_number_leds: {
      00B68B                       1335 00106$:
                                   1336 ;	quantum/vialrgb.c:164: args[0] = RGB_MATRIX_LED_COUNT & 0xFF;
      00B68B 12 33 FC         [24] 1337 	lcall	_ak820_outline_0125
      00B68E 74 52            [12] 1338 	mov	a,#0x52
      00B690 F0               [24] 1339 	movx	@dptr,a
                                   1340 ;	quantum/vialrgb.c:165: args[1] = RGB_MATRIX_LED_COUNT >> 8;
      00B691 12 B7 9D         [24] 1341 	lcall	_ak820_outline_0039
      00B694 E4               [12] 1342 	clr	a
      00B695 F0               [24] 1343 	movx	@dptr,a
                                   1344 ;	quantum/vialrgb.c:166: break;
      00B696 22               [24] 1345 	ret
                                   1346 ;	quantum/vialrgb.c:168: case vialrgb_get_led_info: {
      00B697                       1347 00107$:
                                   1348 ;	quantum/vialrgb.c:169: uint16_t led = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00B697 12 33 FC         [24] 1349 	lcall	_ak820_outline_0125
      00B69A E0               [24] 1350 	movx	a,@dptr
      00B69B FF               [12] 1351 	mov	r7,a
      00B69C 7A 00            [12] 1352 	mov	r2,#0x00
      00B69E 74 03            [12] 1353 	mov	a,#0x03
      00B6A0 2D               [12] 1354 	add	a, r5
      00B6A1 F8               [12] 1355 	mov	r0,a
      00B6A2 E4               [12] 1356 	clr	a
      00B6A3 3E               [12] 1357 	addc	a, r6
      00B6A4 F9               [12] 1358 	mov	r1,a
      00B6A5 C0 03            [24] 1359 	push	ar3
      00B6A7 C0 04            [24] 1360 	push	ar4
      00B6A9 12 38 B6         [24] 1361 	lcall	_ak820_outline_0160
      00B6AC E0               [24] 1362 	movx	a,@dptr
      00B6AD FB               [12] 1363 	mov	r3,a
      00B6AE E4               [12] 1364 	clr	a
      00B6AF 4F               [12] 1365 	orl	a,r7
      00B6B0 F5 4E            [12] 1366 	mov	_vialrgb_get_value_sloc0_1_0,a
      00B6B2 EB               [12] 1367 	mov	a,r3
      00B6B3 4A               [12] 1368 	orl	a,r2
      00B6B4 F5 4F            [12] 1369 	mov	(_vialrgb_get_value_sloc0_1_0 + 1),a
                                   1370 ;	quantum/vialrgb.c:170: if (led >= RGB_MATRIX_LED_COUNT) return;
      00B6B6 AC 4E            [24] 1371 	mov	r4,_vialrgb_get_value_sloc0_1_0
      00B6B8 AF 4F            [24] 1372 	mov	r7,(_vialrgb_get_value_sloc0_1_0 + 1)
      00B6BA C3               [12] 1373 	clr	c
      00B6BB EC               [12] 1374 	mov	a,r4
      00B6BC 94 52            [12] 1375 	subb	a,#0x52
      00B6BE EF               [12] 1376 	mov	a,r7
      00B6BF 94 00            [12] 1377 	subb	a,#0x00
      00B6C1 D0 04            [24] 1378 	pop	ar4
      00B6C3 D0 03            [24] 1379 	pop	ar3
      00B6C5 40 01            [24] 1380 	jc	00109$
      00B6C7 22               [24] 1381 	ret
      00B6C8                       1382 00109$:
                                   1383 ;	quantum/vialrgb.c:172: args[0] = ak820_led_points[led].x;
      00B6C8 E5 4E            [12] 1384 	mov	a,_vialrgb_get_value_sloc0_1_0
      00B6CA 25 4E            [12] 1385 	add	a,_vialrgb_get_value_sloc0_1_0
      00B6CC FA               [12] 1386 	mov	r2,a
      00B6CD E5 4F            [12] 1387 	mov	a,(_vialrgb_get_value_sloc0_1_0 + 1)
      00B6CF 33               [12] 1388 	rlc	a
      00B6D0 FF               [12] 1389 	mov	r7,a
      00B6D1 EA               [12] 1390 	mov	a,r2
      00B6D2 24 5B            [12] 1391 	add	a, #_ak820_led_points
      00B6D4 F5 50            [12] 1392 	mov	_vialrgb_get_value_sloc1_1_0,a
      00B6D6 EF               [12] 1393 	mov	a,r7
      00B6D7 34 BC            [12] 1394 	addc	a, #(_ak820_led_points >> 8)
      00B6D9 F5 51            [12] 1395 	mov	(_vialrgb_get_value_sloc1_1_0 + 1),a
      00B6DB 85 50 82         [24] 1396 	mov	dpl,_vialrgb_get_value_sloc1_1_0
      00B6DE 85 51 83         [24] 1397 	mov	dph,(_vialrgb_get_value_sloc1_1_0 + 1)
      00B6E1 E4               [12] 1398 	clr	a
      00B6E2 93               [24] 1399 	movc	a,@a+dptr
      00B6E3 12 33 FC         [24] 1400 	lcall	_ak820_outline_0125
      00B6E6 F0               [24] 1401 	movx	@dptr,a
                                   1402 ;	quantum/vialrgb.c:173: args[1] = ak820_led_points[led].y;
      00B6E7 85 50 82         [24] 1403 	mov	dpl,_vialrgb_get_value_sloc1_1_0
      00B6EA 85 51 83         [24] 1404 	mov	dph,(_vialrgb_get_value_sloc1_1_0 + 1)
      00B6ED A3               [24] 1405 	inc	dptr
      00B6EE E4               [12] 1406 	clr	a
      00B6EF 93               [24] 1407 	movc	a,@a+dptr
      00B6F0 12 38 B6         [24] 1408 	lcall	_ak820_outline_0160
      00B6F3 F0               [24] 1409 	movx	@dptr,a
                                   1410 ;	quantum/vialrgb.c:174: args[2] = LED_FLAG_KEYLIGHT;
      00B6F4 12 B7 9D         [24] 1411 	lcall	_ak820_outline_0039
      00B6F7 A3               [24] 1412 	inc	dptr
      00B6F8 74 04            [12] 1413 	mov	a,#0x04
      00B6FA F0               [24] 1414 	movx	@dptr,a
                                   1415 ;	quantum/vialrgb.c:183: get_matrix_pos_for_led(led, &args[3]);
      00B6FB 90 0D 92         [24] 1416 	mov	dptr,#_get_matrix_pos_for_led_PARM_2
      00B6FE 04               [12] 1417 	inc	a
      00B6FF 2D               [12] 1418 	add	a, r5
      00B700 F0               [24] 1419 	movx	@dptr,a
      00B701 E4               [12] 1420 	clr	a
      00B702 3E               [12] 1421 	addc	a, r6
      00B703 A3               [24] 1422 	inc	dptr
      00B704 F0               [24] 1423 	movx	@dptr,a
      00B705 85 4E 82         [24] 1424 	mov	dpl, _vialrgb_get_value_sloc0_1_0
      00B708 85 4F 83         [24] 1425 	mov	dph, (_vialrgb_get_value_sloc0_1_0 + 1)
                                   1426 ;	quantum/vialrgb.c:187: }
                                   1427 ;	quantum/vialrgb.c:188: }
      00B70B 02 B4 2E         [24] 1428 	ljmp	_get_matrix_pos_for_led
                                   1429 ;------------------------------------------------------------
                                   1430 ;Allocation info for local variables in function 'vialrgb_set_value'
                                   1431 ;------------------------------------------------------------
                                   1432 ;sloc0         Allocated with name '_vialrgb_set_value_sloc0_1_0'
                                   1433 ;length        Allocated with name '_vialrgb_set_value_PARM_2'
                                   1434 ;data          Allocated with name '_vialrgb_set_value_data_10000_302'
                                   1435 ;args          Allocated with name '_vialrgb_set_value_args_10001_305'
                                   1436 ;cmd           Allocated with name '_vialrgb_set_value_cmd_10001_305'
                                   1437 ;vialrgb_id    Allocated with name '_vialrgb_set_value_vialrgb_id_40001_308'
                                   1438 ;------------------------------------------------------------
                                   1439 ;	quantum/vialrgb.c:190: void vialrgb_set_value(uint8_t *data, uint8_t length) {
                                   1440 ;	-----------------------------------------
                                   1441 ;	 function vialrgb_set_value
                                   1442 ;	-----------------------------------------
      00B70E                       1443 _vialrgb_set_value:
      00B70E 12 43 15         [24] 1444 	lcall	_ak820_outline_0036
      00B711 90 0D A1         [24] 1445 	mov	dptr,#_vialrgb_set_value_data_10000_302
      00B714 12 38 1F         [24] 1446 	lcall	_ak820_outline_0016
                                   1447 ;	quantum/vialrgb.c:191: if (length != VIAL_RAW_EPSIZE) return;
      00B717 90 0D A0         [24] 1448 	mov	dptr,#_vialrgb_set_value_PARM_2
      00B71A E0               [24] 1449 	movx	a,@dptr
      00B71B FF               [12] 1450 	mov	r7,a
      00B71C BF 20 02         [24] 1451 	cjne	r7,#0x20,00129$
      00B71F 80 01            [24] 1452 	sjmp	00102$
      00B721                       1453 00129$:
      00B721 22               [24] 1454 	ret
      00B722                       1455 00102$:
                                   1456 ;	quantum/vialrgb.c:194: uint8_t VIALRGB_BUFFER *args = (uint8_t VIALRGB_BUFFER *)data + 2;
      00B722 90 0D A1         [24] 1457 	mov	dptr,#_vialrgb_set_value_data_10000_302
      00B725 12 B7 A5         [24] 1458 	lcall	_ak820_outline_0046
                                   1459 ;	quantum/vialrgb.c:195: uint8_t cmd = args[-1];
                                   1460 ;	quantum/vialrgb.c:196: switch (cmd) {
      00B728 BA 41 02         [24] 1461 	cjne	r2,#0x41,00130$
      00B72B 80 06            [24] 1462 	sjmp	00103$
      00B72D                       1463 00130$:
      00B72D BA 42 02         [24] 1464 	cjne	r2,#0x42,00131$
      00B730 80 5C            [24] 1465 	sjmp	00104$
      00B732                       1466 00131$:
      00B732 22               [24] 1467 	ret
                                   1468 ;	quantum/vialrgb.c:197: case vialrgb_set_mode: {
      00B733                       1469 00103$:
                                   1470 ;	quantum/vialrgb.c:198: uint16_t vialrgb_id = args[0] | (args[1] << 8);
      00B733 12 48 99         [24] 1471 	lcall	_ak820_outline_0065
      00B736 12 B7 9D         [24] 1472 	lcall	_ak820_outline_0039
      00B739 E0               [24] 1473 	movx	a,@dptr
      00B73A F8               [12] 1474 	mov	r0,a
      00B73B 79 00            [12] 1475 	mov	r1,#0x00
      00B73D 88 53            [24] 1476 	mov	(_vialrgb_set_value_sloc0_1_0 + 1),r0
      00B73F 89 52            [24] 1477 	mov	_vialrgb_set_value_sloc0_1_0,r1
      00B741 8A 01            [24] 1478 	mov	ar1,r2
      00B743 7A 00            [12] 1479 	mov	r2,#0x00
      00B745 E5 53            [12] 1480 	mov	a,(_vialrgb_set_value_sloc0_1_0 + 1)
      00B747 42 02            [12] 1481 	orl	ar2,a
                                   1482 ;	quantum/vialrgb.c:199: set_mode(vialrgb_id);
      00B749 12 43 7E         [24] 1483 	lcall	_ak820_outline_0185
      00B74C C0 06            [24] 1484 	push	ar6
      00B74E C0 05            [24] 1485 	push	ar5
      00B750 12 B4 00         [24] 1486 	lcall	_set_mode
      00B753 D0 05            [24] 1487 	pop	ar5
      00B755 D0 06            [24] 1488 	pop	ar6
                                   1489 ;	quantum/vialrgb.c:200: rgb_matrix_set_speed_noeeprom(args[2]);
      00B757 12 B7 9D         [24] 1490 	lcall	_ak820_outline_0039
      00B75A A3               [24] 1491 	inc	dptr
      00B75B E0               [24] 1492 	movx	a,@dptr
      00B75C F5 82            [12] 1493 	mov	dpl,a
      00B75E C0 06            [24] 1494 	push	ar6
      00B760 C0 05            [24] 1495 	push	ar5
      00B762 12 55 EC         [24] 1496 	lcall	_rgb_matrix_set_speed_noeeprom
      00B765 D0 05            [24] 1497 	pop	ar5
      00B767 D0 06            [24] 1498 	pop	ar6
                                   1499 ;	quantum/vialrgb.c:201: rgb_matrix_sethsv_noeeprom(args[3], args[4], args[5]);
      00B769 12 B7 9D         [24] 1500 	lcall	_ak820_outline_0039
      00B76C A3               [24] 1501 	inc	dptr
      00B76D A3               [24] 1502 	inc	dptr
      00B76E E0               [24] 1503 	movx	a,@dptr
      00B76F F9               [12] 1504 	mov	r1,a
      00B770 7A 00            [12] 1505 	mov	r2,#0x00
      00B772 74 06            [12] 1506 	mov	a,#0x06
      00B774 12 B7 EF         [24] 1507 	lcall	_ak820_outline_0174
      00B777 F8               [12] 1508 	mov	r0,a
      00B778 74 07            [12] 1509 	mov	a,#0x07
      00B77A 12 B7 EF         [24] 1510 	lcall	_ak820_outline_0174
      00B77D FE               [12] 1511 	mov	r6,a
      00B77E 90 07 30         [24] 1512 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_2
      00B781 E8               [12] 1513 	mov	a,r0
      00B782 F0               [24] 1514 	movx	@dptr,a
      00B783 90 07 31         [24] 1515 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_3
      00B786 EE               [12] 1516 	mov	a,r6
      00B787 F0               [24] 1517 	movx	@dptr,a
      00B788 12 43 7E         [24] 1518 	lcall	_ak820_outline_0185
                                   1519 ;	quantum/vialrgb.c:202: break;
                                   1520 ;	quantum/vialrgb.c:205: case vialrgb_direct_fastset: {
      00B78B 02 55 BD         [24] 1521 	ljmp	_rgb_matrix_sethsv_noeeprom
      00B78E                       1522 00104$:
                                   1523 ;	quantum/vialrgb.c:206: fast_set_leds(args, length - 2);
      00B78E EF               [12] 1524 	mov	a,r7
      00B78F 24 FE            [12] 1525 	add	a,#0xfe
      00B791 90 0D 96         [24] 1526 	mov	dptr,#_fast_set_leds_PARM_2
      00B794 12 6F 9D         [24] 1527 	lcall	_ak820_outline_0103
                                   1528 ;	quantum/vialrgb.c:210: }
                                   1529 ;	quantum/vialrgb.c:211: }
      00B797 02 B4 61         [24] 1530 	ljmp	_fast_set_leds
                                   1531 ;------------------------------------------------------------
                                   1532 ;Allocation info for local variables in function 'vialrgb_save'
                                   1533 ;------------------------------------------------------------
                                   1534 ;length        Allocated with name '_vialrgb_save_PARM_2'
                                   1535 ;data          Allocated with name '_vialrgb_save_data_10000_310'
                                   1536 ;------------------------------------------------------------
                                   1537 ;	quantum/vialrgb.c:213: void vialrgb_save(uint8_t *data, uint8_t length) {
                                   1538 ;	-----------------------------------------
                                   1539 ;	 function vialrgb_save
                                   1540 ;	-----------------------------------------
      00B79A                       1541 _vialrgb_save:
                                   1542 ;	quantum/vialrgb.c:217: eeconfig_update_rgb_matrix();
                                   1543 ;	quantum/vialrgb.c:218: }
      00B79A 02 50 44         [24] 1544 	ljmp	_eeconfig_update_rgb_matrix
                                   1545 	.area CSEG    (CODE)
                                   1546 	.area CONST   (CODE)
                                   1547 	.area CONST   (CODE)
      00BF9A                       1548 _supported_modes:
      00BF9A 00                    1549 	.db #0x00	; 0
      00BF9B 00                    1550 	.db #0x00	; 0
      00BF9C 01                    1551 	.db #0x01	; 1
      00BF9D 05                    1552 	.db #0x05	; 5
      00BF9E 02                    1553 	.db #0x02	; 2
      00BF9F 01                    1554 	.db #0x01	; 1
      00BFA0 06                    1555 	.db #0x06	; 6
      00BFA1 02                    1556 	.db #0x02	; 2
      00BFA2 0D                    1557 	.db #0x0d	; 13
      00BFA3 03                    1558 	.db #0x03	; 3
      00BFA4 0E                    1559 	.db #0x0e	; 14
      00BFA5 04                    1560 	.db #0x04	; 4
      00BFA6 1F                    1561 	.db #0x1f	; 31
      00BFA7 06                    1562 	.db #0x06	; 6
                                   1563 	.area CSEG    (CODE)
                                   1564 	.area XINIT   (CODE)
                                   1565 	.area CABS    (ABS,CODE)
                                   1566 
                                   1567 ; Experimental exact instruction outlining.
                                   1568 	.globl _ak820_outline_0005
                                   1569 	.globl _ak820_outline_0016
                                   1570 	.globl _ak820_outline_0021
                                   1571 	.globl _ak820_outline_0036
                                   1572 	.globl _ak820_outline_0039
                                   1573 	.globl _ak820_outline_0040
                                   1574 	.globl _ak820_outline_0046
                                   1575 	.globl _ak820_outline_0047
                                   1576 	.globl _ak820_outline_0052
                                   1577 	.globl _ak820_outline_0057
                                   1578 	.globl _ak820_outline_0064
                                   1579 	.globl _ak820_outline_0065
                                   1580 	.globl _ak820_outline_0083
                                   1581 	.globl _ak820_outline_0084
                                   1582 	.globl _ak820_outline_0085
                                   1583 	.globl _ak820_outline_0103
                                   1584 	.globl _ak820_outline_0108
                                   1585 	.globl _ak820_outline_0109
                                   1586 	.globl _ak820_outline_0110
                                   1587 	.globl _ak820_outline_0111
                                   1588 	.globl _ak820_outline_0120
                                   1589 	.globl _ak820_outline_0123
                                   1590 	.globl _ak820_outline_0124
                                   1591 	.globl _ak820_outline_0125
                                   1592 	.globl _ak820_outline_0135
                                   1593 	.globl _ak820_outline_0138
                                   1594 	.globl _ak820_outline_0144
                                   1595 	.globl _ak820_outline_0146
                                   1596 	.globl _ak820_outline_0160
                                   1597 	.globl _ak820_outline_0165
                                   1598 	.globl _ak820_outline_0174
                                   1599 	.globl _ak820_outline_0185
                                   1600 	.globl _ak820_outline_0190
                                   1601 
                                   1602 	.area CSEG (CODE)
                                   1603 ; function ak820_outline_0039
      00B79D                       1604 _ak820_outline_0039:
      00B79D 8D 82            [24] 1605 	mov	dpl,r5
      00B79F 8E 83            [24] 1606 	mov	dph,r6
      00B7A1 A3               [24] 1607 	inc	dptr
      00B7A2 A3               [24] 1608 	inc	dptr
      00B7A3 A3               [24] 1609 	inc	dptr
      00B7A4 22               [24] 1610 	ret
                                   1611 
                                   1612 	.area CSEG (CODE)
                                   1613 ; function ak820_outline_0046
      00B7A5                       1614 _ak820_outline_0046:
      00B7A5 E0               [24] 1615 	movx	a,@dptr
      00B7A6 FD               [12] 1616 	mov	r5,a
      00B7A7 A3               [24] 1617 	inc	dptr
      00B7A8 E0               [24] 1618 	movx	a,@dptr
      00B7A9 FE               [12] 1619 	mov	r6,a
      00B7AA 74 02            [12] 1620 	mov	a,#0x02
      00B7AC 2D               [12] 1621 	add	a,r5
      00B7AD FB               [12] 1622 	mov	r3,a
      00B7AE E4               [12] 1623 	clr	a
      00B7AF 3E               [12] 1624 	addc	a,r6
      00B7B0 FC               [12] 1625 	mov	r4,a
      00B7B1 8D 82            [24] 1626 	mov	dpl,r5
      00B7B3 8E 83            [24] 1627 	mov	dph,r6
      00B7B5 A3               [24] 1628 	inc	dptr
      00B7B6 E0               [24] 1629 	movx	a,@dptr
      00B7B7 FA               [12] 1630 	mov	r2,a
      00B7B8 22               [24] 1631 	ret
                                   1632 
                                   1633 	.area CSEG (CODE)
                                   1634 ; function ak820_outline_0047
      00B7B9                       1635 _ak820_outline_0047:
      00B7B9 ED               [12] 1636 	mov	a,r5
      00B7BA 75 F0 02         [24] 1637 	mov	b,#0x02
      00B7BD A4               [48] 1638 	mul	ab
      00B7BE 24 9A            [12] 1639 	add	a,#_supported_modes
      00B7C0 FB               [12] 1640 	mov	r3,a
      00B7C1 74 BF            [12] 1641 	mov	a,#(_supported_modes>>8)
      00B7C3 35 F0            [12] 1642 	addc	a,b
      00B7C5 FC               [12] 1643 	mov	r4,a
      00B7C6 8B 82            [24] 1644 	mov	dpl,r3
      00B7C8 8C 83            [24] 1645 	mov	dph,r4
      00B7CA 22               [24] 1646 	ret
                                   1647 
                                   1648 	.area CSEG (CODE)
                                   1649 ; function ak820_outline_0083
      00B7CB                       1650 _ak820_outline_0083:
      00B7CB 90 0D 97         [24] 1651 	mov	dptr,#_fast_set_leds_args_10000_282
      00B7CE E0               [24] 1652 	movx	a,@dptr
      00B7CF F9               [12] 1653 	mov	r1,a
      00B7D0 A3               [24] 1654 	inc	dptr
      00B7D1 E0               [24] 1655 	movx	a,@dptr
      00B7D2 FF               [12] 1656 	mov	r7,a
      00B7D3 89 82            [24] 1657 	mov	dpl,r1
      00B7D5 8F 83            [24] 1658 	mov	dph,r7
      00B7D7 E0               [24] 1659 	movx	a,@dptr
      00B7D8 22               [24] 1660 	ret
                                   1661 
                                   1662 	.area CSEG (CODE)
                                   1663 ; function ak820_outline_0108
      00B7D9                       1664 _ak820_outline_0108:
      00B7D9 90 0D 97         [24] 1665 	mov	dptr,#_fast_set_leds_args_10000_282
      00B7DC 74 01            [12] 1666 	mov	a,#0x01
      00B7DE 29               [12] 1667 	add	a,r1
      00B7DF F0               [24] 1668 	movx	@dptr,a
      00B7E0 E4               [12] 1669 	clr	a
      00B7E1 3F               [12] 1670 	addc	a,r7
      00B7E2 A3               [24] 1671 	inc	dptr
      00B7E3 F0               [24] 1672 	movx	@dptr,a
      00B7E4 22               [24] 1673 	ret
                                   1674 
                                   1675 	.area CSEG (CODE)
                                   1676 ; function ak820_outline_0146
      00B7E5                       1677 _ak820_outline_0146:
      00B7E5 E4               [12] 1678 	clr	a
      00B7E6 93               [24] 1679 	movc	a,@a+dptr
      00B7E7 FC               [12] 1680 	mov	r4,a
      00B7E8 7B 00            [12] 1681 	mov	r3,#0x00
      00B7EA 8C 82            [24] 1682 	mov	dpl,r4
      00B7EC 8B 83            [24] 1683 	mov	dph,r3
      00B7EE 22               [24] 1684 	ret
                                   1685 
                                   1686 	.area CSEG (CODE)
                                   1687 ; function ak820_outline_0174
      00B7EF                       1688 _ak820_outline_0174:
      00B7EF 2D               [12] 1689 	add	a,r5
      00B7F0 F5 82            [12] 1690 	mov	dpl,a
      00B7F2 E4               [12] 1691 	clr	a
      00B7F3 3E               [12] 1692 	addc	a,r6
      00B7F4 F5 83            [12] 1693 	mov	dph,a
      00B7F6 E0               [24] 1694 	movx	a,@dptr
      00B7F7 22               [24] 1695 	ret
