                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action_util
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _host_consumer_send
                                     12 	.globl _host_system_send
                                     13 	.globl _host_keyboard_send
                                     14 	.globl _clear_keys_from_report
                                     15 	.globl _del_key_from_report
                                     16 	.globl _add_key_to_report
                                     17 	.globl _KEYCODE2CONSUMER
                                     18 	.globl _ADC_START
                                     19 	.globl _S0_R_FIFO
                                     20 	.globl _S0_T_FIFO
                                     21 	.globl _S0_FREE
                                     22 	.globl _S0_IF_BYTE
                                     23 	.globl _S0_IF_FIRST
                                     24 	.globl _S0_IF_OV
                                     25 	.globl _S0_FST_ACT
                                     26 	.globl _CP_RL2
                                     27 	.globl _C_T2
                                     28 	.globl _TR2
                                     29 	.globl _EXEN2
                                     30 	.globl _TCLK
                                     31 	.globl _RCLK
                                     32 	.globl _EXF2
                                     33 	.globl _CAP1F
                                     34 	.globl _TF2
                                     35 	.globl _RI
                                     36 	.globl _TI
                                     37 	.globl _RB8
                                     38 	.globl _TB8
                                     39 	.globl _REN
                                     40 	.globl _SM2
                                     41 	.globl _SM1
                                     42 	.globl _SM0
                                     43 	.globl _IT0
                                     44 	.globl _IE0
                                     45 	.globl _IT1
                                     46 	.globl _IE1
                                     47 	.globl _TR0
                                     48 	.globl _TF0
                                     49 	.globl _TR1
                                     50 	.globl _TF1
                                     51 	.globl _P4_0
                                     52 	.globl _P4_1
                                     53 	.globl _P4_2
                                     54 	.globl _P4_3
                                     55 	.globl _P4_4
                                     56 	.globl _P4_5
                                     57 	.globl _P4_6
                                     58 	.globl _RXD
                                     59 	.globl _TXD
                                     60 	.globl _INT0
                                     61 	.globl _INT1
                                     62 	.globl _T0
                                     63 	.globl _T1
                                     64 	.globl _MOSI1
                                     65 	.globl _MISO1
                                     66 	.globl _SCK1
                                     67 	.globl _P3_0
                                     68 	.globl _P3_1
                                     69 	.globl _P3_2
                                     70 	.globl _P3_3
                                     71 	.globl _P3_4
                                     72 	.globl _P3_5
                                     73 	.globl _P3_6
                                     74 	.globl _P3_7
                                     75 	.globl _CAP1_
                                     76 	.globl _T2_
                                     77 	.globl _CAP2_
                                     78 	.globl _T2EX_
                                     79 	.globl _RXD1
                                     80 	.globl _TXD1
                                     81 	.globl _P2_0
                                     82 	.globl _P2_1
                                     83 	.globl _P2_2
                                     84 	.globl _P2_3
                                     85 	.globl _P2_4
                                     86 	.globl _P2_5
                                     87 	.globl _P2_6
                                     88 	.globl _P2_7
                                     89 	.globl _AIN0
                                     90 	.globl _AIN1
                                     91 	.globl _AIN2
                                     92 	.globl _AIN3
                                     93 	.globl _AIN4
                                     94 	.globl _AIN5
                                     95 	.globl _AIN6
                                     96 	.globl _AIN7
                                     97 	.globl _CAP1
                                     98 	.globl _T2
                                     99 	.globl _CAP2
                                    100 	.globl _T2EX
                                    101 	.globl _INT0_
                                    102 	.globl _SCS
                                    103 	.globl _MOSI
                                    104 	.globl _MISO
                                    105 	.globl _SCK
                                    106 	.globl _RXD1_
                                    107 	.globl _TXD1_
                                    108 	.globl _P1_0
                                    109 	.globl _P1_1
                                    110 	.globl _P1_2
                                    111 	.globl _P1_3
                                    112 	.globl _P1_4
                                    113 	.globl _P1_5
                                    114 	.globl _P1_6
                                    115 	.globl _P1_7
                                    116 	.globl _AIN8
                                    117 	.globl _AIN9
                                    118 	.globl _AIN10
                                    119 	.globl _AIN11
                                    120 	.globl _AIN12
                                    121 	.globl _AIN13
                                    122 	.globl _RXD_
                                    123 	.globl _TXD_
                                    124 	.globl _SCL0
                                    125 	.globl _SDA0
                                    126 	.globl _P0_0
                                    127 	.globl _P0_1
                                    128 	.globl _P0_2
                                    129 	.globl _P0_3
                                    130 	.globl _P0_4
                                    131 	.globl _P0_5
                                    132 	.globl _P0_6
                                    133 	.globl _P0_7
                                    134 	.globl _IE_SPI0
                                    135 	.globl _IE_USB
                                    136 	.globl _IE_ADC
                                    137 	.globl _IE_UART1
                                    138 	.globl _IE_PWM_I2C
                                    139 	.globl _IE_GPIO
                                    140 	.globl _IE_WDOG
                                    141 	.globl _PX0
                                    142 	.globl _PT0
                                    143 	.globl _PX1
                                    144 	.globl _PT1
                                    145 	.globl _PS
                                    146 	.globl _PT2
                                    147 	.globl _PL_FLAG
                                    148 	.globl _PH_FLAG
                                    149 	.globl _EX0
                                    150 	.globl _ET0
                                    151 	.globl _EX1
                                    152 	.globl _ET1
                                    153 	.globl _ES
                                    154 	.globl _ET2
                                    155 	.globl _E_DIS
                                    156 	.globl _EA
                                    157 	.globl _P
                                    158 	.globl _F1
                                    159 	.globl _OV
                                    160 	.globl _RS0
                                    161 	.globl _RS1
                                    162 	.globl _F0
                                    163 	.globl _AC
                                    164 	.globl _CY
                                    165 	.globl _I2CS_INT_ST
                                    166 	.globl _I2CX_INT
                                    167 	.globl _LED_STATUS
                                    168 	.globl _LED_DMA_H
                                    169 	.globl _LED_DMA_L
                                    170 	.globl _LED_DMA
                                    171 	.globl _LED_PWM_OE
                                    172 	.globl _LED_COMMON
                                    173 	.globl _ADC_CHAN
                                    174 	.globl _ADC_DAT_H
                                    175 	.globl _ADC_DAT_L
                                    176 	.globl _ADC_DAT
                                    177 	.globl _ADC_CTRL
                                    178 	.globl _SPI1_CK_SE
                                    179 	.globl _SPI1_CTRL
                                    180 	.globl _SPI1_DATA
                                    181 	.globl _SPI1_STAT
                                    182 	.globl _SIF1
                                    183 	.globl _SBAUD1
                                    184 	.globl _SBUF1
                                    185 	.globl _SCON1
                                    186 	.globl _SPI0_SETUP
                                    187 	.globl _SPI0_CK_SE
                                    188 	.globl _SPI0_CTRL
                                    189 	.globl _SPI0_DATA
                                    190 	.globl _SPI0_STAT
                                    191 	.globl _T2CAP1H
                                    192 	.globl _T2CAP1L
                                    193 	.globl _T2CAP1
                                    194 	.globl _TH2
                                    195 	.globl _TL2
                                    196 	.globl _T2COUNT
                                    197 	.globl _RCAP2H
                                    198 	.globl _RCAP2L
                                    199 	.globl _RCAP2
                                    200 	.globl _T2MOD
                                    201 	.globl _T2CON
                                    202 	.globl _SBUF
                                    203 	.globl _SCON
                                    204 	.globl _TH1
                                    205 	.globl _TH0
                                    206 	.globl _TL1
                                    207 	.globl _TL0
                                    208 	.globl _TMOD
                                    209 	.globl _TCON
                                    210 	.globl _XBUS_AUX
                                    211 	.globl _P7
                                    212 	.globl _P6_DIR
                                    213 	.globl _P6_OUT_PU
                                    214 	.globl _P6_IN
                                    215 	.globl _P5_DIR
                                    216 	.globl _P5_OUT_PU
                                    217 	.globl _P5_IN
                                    218 	.globl _P4_LED_KEY
                                    219 	.globl _P4_DIR_PU
                                    220 	.globl _P4_MOD_OC
                                    221 	.globl _P4
                                    222 	.globl _P3_DIR_PU
                                    223 	.globl _P3_MOD_OC
                                    224 	.globl _P3
                                    225 	.globl _P2_DIR_PU
                                    226 	.globl _P2_MOD_OC
                                    227 	.globl _P2
                                    228 	.globl _P1_DIR_PU
                                    229 	.globl _P1_MOD_OC
                                    230 	.globl _P1
                                    231 	.globl _P0_DIR_PU
                                    232 	.globl _P0_MOD_OC
                                    233 	.globl _P0
                                    234 	.globl _ROM_CTRL
                                    235 	.globl _ROM_DATA_HH
                                    236 	.globl _ROM_DATA_HL
                                    237 	.globl _ROM_DATA_HI
                                    238 	.globl _ROM_ADDR_H
                                    239 	.globl _ROM_ADDR_L
                                    240 	.globl _ROM_ADDR
                                    241 	.globl _GPIO_IE
                                    242 	.globl _IP_EX
                                    243 	.globl _IE_EX
                                    244 	.globl _IP
                                    245 	.globl _IE
                                    246 	.globl _WDOG_COUNT
                                    247 	.globl _RESET_KEEP
                                    248 	.globl _WAKE_CTRL
                                    249 	.globl _CLOCK_CFG
                                    250 	.globl _POWER_CFG
                                    251 	.globl _PCON
                                    252 	.globl _GLOBAL_CFG
                                    253 	.globl _SAFE_MOD
                                    254 	.globl _DPH
                                    255 	.globl _DPL
                                    256 	.globl _SP
                                    257 	.globl _A_INV
                                    258 	.globl _B
                                    259 	.globl _ACC
                                    260 	.globl _PSW
                                    261 	.globl _actual_keyboard_report
                                    262 	.globl _owned_usage_key_PARM_2
                                    263 	.globl _ak820_macro_change_PARM_3
                                    264 	.globl _ak820_macro_change_PARM_2
                                    265 	.globl _ak820_macro_cancelled
                                    266 	.globl _ak820_macro_primitive
                                    267 	.globl _ak820_gui_process_PARM_2
                                    268 	.globl _ak820_gui_process
                                    269 	.globl _ak820_macro_change
                                    270 	.globl _add_owned_mods
                                    271 	.globl _del_owned_mods
                                    272 	.globl _add_owned_weak_mods
                                    273 	.globl _del_owned_weak_mods
                                    274 	.globl _clear_owned_mods
                                    275 	.globl _clear_owned_keys
                                    276 	.globl _add_owned_key
                                    277 	.globl _del_owned_key
                                    278 	.globl _clear_owned_usages
                                    279 	.globl _owned_usage_key
                                    280 	.globl _send_keyboard_report
                                    281 	.globl _get_mods
                                    282 	.globl _clear_mods
                                    283 	.globl _get_weak_mods
                                    284 	.globl _add_weak_mods
                                    285 	.globl _del_weak_mods
                                    286 	.globl _clear_weak_mods
                                    287 ;--------------------------------------------------------
                                    288 ; special function registers
                                    289 ;--------------------------------------------------------
                                    290 	.area RSEG    (ABS,DATA)
      000000                        291 	.org 0x0000
                           0000D0   292 _PSW	=	0x00d0
                           0000E0   293 _ACC	=	0x00e0
                           0000F0   294 _B	=	0x00f0
                           0000FD   295 _A_INV	=	0x00fd
                           000081   296 _SP	=	0x0081
                           000082   297 _DPL	=	0x0082
                           000083   298 _DPH	=	0x0083
                           0000A1   299 _SAFE_MOD	=	0x00a1
                           0000B1   300 _GLOBAL_CFG	=	0x00b1
                           000087   301 _PCON	=	0x0087
                           0000BA   302 _POWER_CFG	=	0x00ba
                           0000B9   303 _CLOCK_CFG	=	0x00b9
                           0000A9   304 _WAKE_CTRL	=	0x00a9
                           0000FE   305 _RESET_KEEP	=	0x00fe
                           0000FF   306 _WDOG_COUNT	=	0x00ff
                           0000A8   307 _IE	=	0x00a8
                           0000B8   308 _IP	=	0x00b8
                           0000E8   309 _IE_EX	=	0x00e8
                           0000E9   310 _IP_EX	=	0x00e9
                           0000B2   311 _GPIO_IE	=	0x00b2
                           008584   312 _ROM_ADDR	=	0x8584
                           000084   313 _ROM_ADDR_L	=	0x0084
                           000085   314 _ROM_ADDR_H	=	0x0085
                           008F8E   315 _ROM_DATA_HI	=	0x8f8e
                           00008E   316 _ROM_DATA_HL	=	0x008e
                           00008F   317 _ROM_DATA_HH	=	0x008f
                           000086   318 _ROM_CTRL	=	0x0086
                           000080   319 _P0	=	0x0080
                           0000C4   320 _P0_MOD_OC	=	0x00c4
                           0000C5   321 _P0_DIR_PU	=	0x00c5
                           000090   322 _P1	=	0x0090
                           000092   323 _P1_MOD_OC	=	0x0092
                           000093   324 _P1_DIR_PU	=	0x0093
                           0000A0   325 _P2	=	0x00a0
                           000094   326 _P2_MOD_OC	=	0x0094
                           000095   327 _P2_DIR_PU	=	0x0095
                           0000B0   328 _P3	=	0x00b0
                           000096   329 _P3_MOD_OC	=	0x0096
                           000097   330 _P3_DIR_PU	=	0x0097
                           0000C0   331 _P4	=	0x00c0
                           0000C2   332 _P4_MOD_OC	=	0x00c2
                           0000C3   333 _P4_DIR_PU	=	0x00c3
                           0000C1   334 _P4_LED_KEY	=	0x00c1
                           0000AA   335 _P5_IN	=	0x00aa
                           0000AB   336 _P5_OUT_PU	=	0x00ab
                           0000AC   337 _P5_DIR	=	0x00ac
                           0000AD   338 _P6_IN	=	0x00ad
                           0000AE   339 _P6_OUT_PU	=	0x00ae
                           0000AF   340 _P6_DIR	=	0x00af
                           0000F1   341 _P7	=	0x00f1
                           0000A2   342 _XBUS_AUX	=	0x00a2
                           000088   343 _TCON	=	0x0088
                           000089   344 _TMOD	=	0x0089
                           00008A   345 _TL0	=	0x008a
                           00008B   346 _TL1	=	0x008b
                           00008C   347 _TH0	=	0x008c
                           00008D   348 _TH1	=	0x008d
                           000098   349 _SCON	=	0x0098
                           000099   350 _SBUF	=	0x0099
                           0000C8   351 _T2CON	=	0x00c8
                           0000C9   352 _T2MOD	=	0x00c9
                           00CBCA   353 _RCAP2	=	0xcbca
                           0000CA   354 _RCAP2L	=	0x00ca
                           0000CB   355 _RCAP2H	=	0x00cb
                           00CDCC   356 _T2COUNT	=	0xcdcc
                           0000CC   357 _TL2	=	0x00cc
                           0000CD   358 _TH2	=	0x00cd
                           00CFCE   359 _T2CAP1	=	0xcfce
                           0000CE   360 _T2CAP1L	=	0x00ce
                           0000CF   361 _T2CAP1H	=	0x00cf
                           0000F8   362 _SPI0_STAT	=	0x00f8
                           0000F9   363 _SPI0_DATA	=	0x00f9
                           0000FA   364 _SPI0_CTRL	=	0x00fa
                           0000FB   365 _SPI0_CK_SE	=	0x00fb
                           0000FC   366 _SPI0_SETUP	=	0x00fc
                           0000BC   367 _SCON1	=	0x00bc
                           0000BD   368 _SBUF1	=	0x00bd
                           0000BE   369 _SBAUD1	=	0x00be
                           0000BF   370 _SIF1	=	0x00bf
                           0000B4   371 _SPI1_STAT	=	0x00b4
                           0000B5   372 _SPI1_DATA	=	0x00b5
                           0000B6   373 _SPI1_CTRL	=	0x00b6
                           0000B7   374 _SPI1_CK_SE	=	0x00b7
                           0000F3   375 _ADC_CTRL	=	0x00f3
                           00F5F4   376 _ADC_DAT	=	0xf5f4
                           0000F4   377 _ADC_DAT_L	=	0x00f4
                           0000F5   378 _ADC_DAT_H	=	0x00f5
                           0000F6   379 _ADC_CHAN	=	0x00f6
                           0000A6   380 _LED_COMMON	=	0x00a6
                           0000A7   381 _LED_PWM_OE	=	0x00a7
                           00C7C6   382 _LED_DMA	=	0xc7c6
                           0000C6   383 _LED_DMA_L	=	0x00c6
                           0000C7   384 _LED_DMA_H	=	0x00c7
                           0000F7   385 _LED_STATUS	=	0x00f7
                           0000B3   386 _I2CX_INT	=	0x00b3
                           0000BB   387 _I2CS_INT_ST	=	0x00bb
                                    388 ;--------------------------------------------------------
                                    389 ; special function bits
                                    390 ;--------------------------------------------------------
                                    391 	.area RSEG    (ABS,DATA)
      000000                        392 	.org 0x0000
                           0000D7   393 _CY	=	0x00d7
                           0000D6   394 _AC	=	0x00d6
                           0000D5   395 _F0	=	0x00d5
                           0000D4   396 _RS1	=	0x00d4
                           0000D3   397 _RS0	=	0x00d3
                           0000D2   398 _OV	=	0x00d2
                           0000D1   399 _F1	=	0x00d1
                           0000D0   400 _P	=	0x00d0
                           0000AF   401 _EA	=	0x00af
                           0000AE   402 _E_DIS	=	0x00ae
                           0000AD   403 _ET2	=	0x00ad
                           0000AC   404 _ES	=	0x00ac
                           0000AB   405 _ET1	=	0x00ab
                           0000AA   406 _EX1	=	0x00aa
                           0000A9   407 _ET0	=	0x00a9
                           0000A8   408 _EX0	=	0x00a8
                           0000BF   409 _PH_FLAG	=	0x00bf
                           0000BE   410 _PL_FLAG	=	0x00be
                           0000BD   411 _PT2	=	0x00bd
                           0000BC   412 _PS	=	0x00bc
                           0000BB   413 _PT1	=	0x00bb
                           0000BA   414 _PX1	=	0x00ba
                           0000B9   415 _PT0	=	0x00b9
                           0000B8   416 _PX0	=	0x00b8
                           0000EF   417 _IE_WDOG	=	0x00ef
                           0000EE   418 _IE_GPIO	=	0x00ee
                           0000ED   419 _IE_PWM_I2C	=	0x00ed
                           0000EC   420 _IE_UART1	=	0x00ec
                           0000EB   421 _IE_ADC	=	0x00eb
                           0000E9   422 _IE_USB	=	0x00e9
                           0000E8   423 _IE_SPI0	=	0x00e8
                           000087   424 _P0_7	=	0x0087
                           000086   425 _P0_6	=	0x0086
                           000085   426 _P0_5	=	0x0085
                           000084   427 _P0_4	=	0x0084
                           000083   428 _P0_3	=	0x0083
                           000082   429 _P0_2	=	0x0082
                           000081   430 _P0_1	=	0x0081
                           000080   431 _P0_0	=	0x0080
                           000081   432 _SDA0	=	0x0081
                           000080   433 _SCL0	=	0x0080
                           000083   434 _TXD_	=	0x0083
                           000082   435 _RXD_	=	0x0082
                           000085   436 _AIN13	=	0x0085
                           000084   437 _AIN12	=	0x0084
                           000083   438 _AIN11	=	0x0083
                           000082   439 _AIN10	=	0x0082
                           000081   440 _AIN9	=	0x0081
                           000080   441 _AIN8	=	0x0080
                           000097   442 _P1_7	=	0x0097
                           000096   443 _P1_6	=	0x0096
                           000095   444 _P1_5	=	0x0095
                           000094   445 _P1_4	=	0x0094
                           000093   446 _P1_3	=	0x0093
                           000092   447 _P1_2	=	0x0092
                           000091   448 _P1_1	=	0x0091
                           000090   449 _P1_0	=	0x0090
                           000097   450 _TXD1_	=	0x0097
                           000096   451 _RXD1_	=	0x0096
                           000097   452 _SCK	=	0x0097
                           000096   453 _MISO	=	0x0096
                           000095   454 _MOSI	=	0x0095
                           000094   455 _SCS	=	0x0094
                           000092   456 _INT0_	=	0x0092
                           000091   457 _T2EX	=	0x0091
                           000091   458 _CAP2	=	0x0091
                           000090   459 _T2	=	0x0090
                           000090   460 _CAP1	=	0x0090
                           000097   461 _AIN7	=	0x0097
                           000096   462 _AIN6	=	0x0096
                           000095   463 _AIN5	=	0x0095
                           000094   464 _AIN4	=	0x0094
                           000093   465 _AIN3	=	0x0093
                           000092   466 _AIN2	=	0x0092
                           000091   467 _AIN1	=	0x0091
                           000090   468 _AIN0	=	0x0090
                           0000A7   469 _P2_7	=	0x00a7
                           0000A6   470 _P2_6	=	0x00a6
                           0000A5   471 _P2_5	=	0x00a5
                           0000A4   472 _P2_4	=	0x00a4
                           0000A3   473 _P2_3	=	0x00a3
                           0000A2   474 _P2_2	=	0x00a2
                           0000A1   475 _P2_1	=	0x00a1
                           0000A0   476 _P2_0	=	0x00a0
                           0000A7   477 _TXD1	=	0x00a7
                           0000A6   478 _RXD1	=	0x00a6
                           0000A5   479 _T2EX_	=	0x00a5
                           0000A5   480 _CAP2_	=	0x00a5
                           0000A4   481 _T2_	=	0x00a4
                           0000A4   482 _CAP1_	=	0x00a4
                           0000B7   483 _P3_7	=	0x00b7
                           0000B6   484 _P3_6	=	0x00b6
                           0000B5   485 _P3_5	=	0x00b5
                           0000B4   486 _P3_4	=	0x00b4
                           0000B3   487 _P3_3	=	0x00b3
                           0000B2   488 _P3_2	=	0x00b2
                           0000B1   489 _P3_1	=	0x00b1
                           0000B0   490 _P3_0	=	0x00b0
                           0000B7   491 _SCK1	=	0x00b7
                           0000B6   492 _MISO1	=	0x00b6
                           0000B5   493 _MOSI1	=	0x00b5
                           0000B5   494 _T1	=	0x00b5
                           0000B4   495 _T0	=	0x00b4
                           0000B3   496 _INT1	=	0x00b3
                           0000B2   497 _INT0	=	0x00b2
                           0000B1   498 _TXD	=	0x00b1
                           0000B0   499 _RXD	=	0x00b0
                           0000C6   500 _P4_6	=	0x00c6
                           0000C5   501 _P4_5	=	0x00c5
                           0000C4   502 _P4_4	=	0x00c4
                           0000C3   503 _P4_3	=	0x00c3
                           0000C2   504 _P4_2	=	0x00c2
                           0000C1   505 _P4_1	=	0x00c1
                           0000C0   506 _P4_0	=	0x00c0
                           00008F   507 _TF1	=	0x008f
                           00008E   508 _TR1	=	0x008e
                           00008D   509 _TF0	=	0x008d
                           00008C   510 _TR0	=	0x008c
                           00008B   511 _IE1	=	0x008b
                           00008A   512 _IT1	=	0x008a
                           000089   513 _IE0	=	0x0089
                           000088   514 _IT0	=	0x0088
                           00009F   515 _SM0	=	0x009f
                           00009E   516 _SM1	=	0x009e
                           00009D   517 _SM2	=	0x009d
                           00009C   518 _REN	=	0x009c
                           00009B   519 _TB8	=	0x009b
                           00009A   520 _RB8	=	0x009a
                           000099   521 _TI	=	0x0099
                           000098   522 _RI	=	0x0098
                           0000CF   523 _TF2	=	0x00cf
                           0000CF   524 _CAP1F	=	0x00cf
                           0000CE   525 _EXF2	=	0x00ce
                           0000CD   526 _RCLK	=	0x00cd
                           0000CC   527 _TCLK	=	0x00cc
                           0000CB   528 _EXEN2	=	0x00cb
                           0000CA   529 _TR2	=	0x00ca
                           0000C9   530 _C_T2	=	0x00c9
                           0000C8   531 _CP_RL2	=	0x00c8
                           0000FF   532 _S0_FST_ACT	=	0x00ff
                           0000FE   533 _S0_IF_OV	=	0x00fe
                           0000FD   534 _S0_IF_FIRST	=	0x00fd
                           0000FC   535 _S0_IF_BYTE	=	0x00fc
                           0000FB   536 _S0_FREE	=	0x00fb
                           0000FA   537 _S0_T_FIFO	=	0x00fa
                           0000F8   538 _S0_R_FIFO	=	0x00f8
                           0000F7   539 _ADC_START	=	0x00f7
                                    540 ;--------------------------------------------------------
                                    541 ; overlayable register banks
                                    542 ;--------------------------------------------------------
                                    543 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        544 	.ds 8
                                    545 ;--------------------------------------------------------
                                    546 ; internal ram data
                                    547 ;--------------------------------------------------------
                                    548 	.area DSEG    (DATA)
                                    549 ;--------------------------------------------------------
                                    550 ; overlayable items in internal ram
                                    551 ;--------------------------------------------------------
                                    552 	.area	OSEG    (OVR,DATA)
      000054                        553 _change_owned_sloc1_1_0:
      000054                        554 	.ds 1
                                    555 ;--------------------------------------------------------
                                    556 ; indirectly addressable internal ram data
                                    557 ;--------------------------------------------------------
                                    558 	.area ISEG    (DATA)
                                    559 ;--------------------------------------------------------
                                    560 ; absolute internal ram data
                                    561 ;--------------------------------------------------------
                                    562 	.area IABS    (ABS,DATA)
                                    563 	.area IABS    (ABS,DATA)
                                    564 ;--------------------------------------------------------
                                    565 ; bit data
                                    566 ;--------------------------------------------------------
                                    567 	.area BSEG    (BIT)
      000020                        568 _gui_disabled:
      000020                        569 	.ds 1
      000021                        570 _ak820_gui_process_sloc0_1_0:
      000021                        571 	.ds 1
      000022                        572 _ak820_macro_change_sloc0_1_0:
      000022                        573 	.ds 1
      000023                        574 _change_owned_sloc0_1_0:
      000023                        575 	.ds 1
      000024                        576 _owned_usage_key_sloc0_1_0:
      000024                        577 	.ds 1
                                    578 ;--------------------------------------------------------
                                    579 ; paged external ram data
                                    580 ;--------------------------------------------------------
                                    581 	.area PSEG    (PAG,XDATA)
                                    582 ;--------------------------------------------------------
                                    583 ; uninitialized external ram data
                                    584 ;--------------------------------------------------------
                                    585 	.area XSEG    (XDATA)
      000976                        586 _ak820_gui_process_PARM_2:
      000976                        587 	.ds 1
      000977                        588 _ak820_gui_process_code_10000_294:
      000977                        589 	.ds 2
      000979                        590 _owned_mod_refs:
      000979                        591 	.ds 8
      000981                        592 _owned_weak_refs:
      000981                        593 	.ds 8
      000989                        594 _owned_mods:
      000989                        595 	.ds 1
      00098A                        596 _owned_weak_mods:
      00098A                        597 	.ds 1
      00098B                        598 _macro_mods:
      00098B                        599 	.ds 2
      00098D                        600 _ak820_macro_primitive::
      00098D                        601 	.ds 1
      00098E                        602 _ak820_macro_cancelled::
      00098E                        603 	.ds 1
      00098F                        604 _ak820_macro_change_PARM_2:
      00098F                        605 	.ds 1
      000990                        606 _ak820_macro_change_PARM_3:
      000990                        607 	.ds 1
      000991                        608 _ak820_macro_change_bits_10000_299:
      000991                        609 	.ds 2
      000993                        610 _change_owned_PARM_2:
      000993                        611 	.ds 1
      000994                        612 _change_owned_mods_10000_304:
      000994                        613 	.ds 1
      000995                        614 _change_owned_result_10001_308:
      000995                        615 	.ds 1
      000996                        616 _change_owned_bit_20001_309:
      000996                        617 	.ds 1
      000997                        618 _add_owned_mods_mods_10000_317:
      000997                        619 	.ds 1
      000998                        620 _del_owned_mods_mods_10000_319:
      000998                        621 	.ds 1
      000999                        622 _add_owned_weak_mods_mods_10000_321:
      000999                        623 	.ds 1
      00099A                        624 _del_owned_weak_mods_mods_10000_323:
      00099A                        625 	.ds 1
      00099B                        626 _key_refs:
      00099B                        627 	.ds 165
      000A40                        628 _distinct_keys:
      000A40                        629 	.ds 1
      000A41                        630 _macro_keys:
      000A41                        631 	.ds 21
      000A56                        632 _add_owned_key_code_10000_332:
      000A56                        633 	.ds 1
      000A57                        634 _del_owned_key_code_10000_347:
      000A57                        635 	.ds 1
      000A58                        636 _usage_refs:
      000A58                        637 	.ds 30
      000A76                        638 _usage_order:
      000A76                        639 	.ds 30
      000A94                        640 _usage_lengths:
      000A94                        641 	.ds 2
      000A96                        642 _macro_usages:
      000A96                        643 	.ds 4
      000A9A                        644 _owned_usage_key_PARM_2:
      000A9A                        645 	.ds 1
      000A9B                        646 _owned_usage_key_code_10000_374:
      000A9B                        647 	.ds 1
      000A9C                        648 _owned_usage_key___200000085_20000_375:
      000A9C                        649 	.ds 2
      000A9E                        650 _owned_usage_key_which_10000_375:
      000A9E                        651 	.ds 1
      000A9F                        652 _owned_usage_key_count_10000_375:
      000A9F                        653 	.ds 1
      000AA0                        654 _owned_usage_key_pos_30001_382:
      000AA0                        655 	.ds 1
      000AA1                        656 _owned_usage_key_key_40000_387:
      000AA1                        657 	.ds 1
      000AA2                        658 _send_keyboard_report_last_report_10001_395:
      000AA2                        659 	.ds 32
      000AC2                        660 _send_keyboard_report_changed_10001_395:
      000AC2                        661 	.ds 1
      000AC3                        662 _add_weak_mods_mods_10000_413:
      000AC3                        663 	.ds 1
      000AC4                        664 _del_weak_mods_mods_10000_415:
      000AC4                        665 	.ds 1
                                    666 ;--------------------------------------------------------
                                    667 ; absolute external ram data
                                    668 ;--------------------------------------------------------
                                    669 	.area XABS    (ABS,XDATA)
                                    670 ;--------------------------------------------------------
                                    671 ; initialized external ram data
                                    672 ;--------------------------------------------------------
                                    673 	.area XISEG   (XDATA)
      000DCA                        674 _real_mods:
      000DCA                        675 	.ds 1
      000DCB                        676 _weak_mods:
      000DCB                        677 	.ds 1
      000DCC                        678 _actual_keyboard_report::
      000DCC                        679 	.ds 32
                                    680 	.area HOME    (CODE)
                                    681 	.area GSINIT0 (CODE)
                                    682 	.area GSINIT1 (CODE)
                                    683 	.area GSINIT2 (CODE)
                                    684 	.area GSINIT3 (CODE)
                                    685 	.area GSINIT4 (CODE)
                                    686 	.area GSINIT5 (CODE)
                                    687 	.area GSINIT  (CODE)
                                    688 	.area GSFINAL (CODE)
                                    689 	.area CSEG    (CODE)
                                    690 ;--------------------------------------------------------
                                    691 ; global & static initialisations
                                    692 ;--------------------------------------------------------
                                    693 	.area HOME    (CODE)
                                    694 	.area GSINIT  (CODE)
                                    695 	.area GSFINAL (CODE)
                                    696 	.area GSINIT  (CODE)
                                    697 ;--------------------------------------------------------
                                    698 ; Home
                                    699 ;--------------------------------------------------------
                                    700 	.area HOME    (CODE)
                                    701 	.area HOME    (CODE)
                                    702 ;--------------------------------------------------------
                                    703 ; code
                                    704 ;--------------------------------------------------------
                                    705 	.area CSEG    (CODE)
                                    706 ;------------------------------------------------------------
                                    707 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    708 ;------------------------------------------------------------
                                    709 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    710 ;------------------------------------------------------------
                                    711 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    712 ;	-----------------------------------------
                           000007   713 	ar7 = 0x07
                           000006   714 	ar6 = 0x06
                           000005   715 	ar5 = 0x05
                           000004   716 	ar4 = 0x04
                           000003   717 	ar3 = 0x03
                           000002   718 	ar2 = 0x02
                           000001   719 	ar1 = 0x01
                           000000   720 	ar0 = 0x00
                                    721 ;	 function ak820_gui_process
                                    722 ;	-----------------------------------------
      007B68                        723 _ak820_gui_process:
      007B68 12 38 82         [24]  724 	lcall	_ak820_outline_0109
      007B6B 90 09 77         [24]  725 	mov	dptr,#_ak820_gui_process_code_10000_294
      007B6E 12 38 87         [24]  726 	lcall	_ak820_outline_0110
                                    727 ;	quantum/action_util.c:60: if (code < QK_MAGIC_GUI_ON || code > QK_MAGIC_TOGGLE_GUI) return true;
      007B71 90 09 77         [24]  728 	mov	dptr,#_ak820_gui_process_code_10000_294
      007B74 12 38 41         [24]  729 	lcall	_ak820_outline_0052
      007B77 C3               [12]  730 	clr	c
      007B78 EE               [12]  731 	mov	a,r6
      007B79 94 09            [12]  732 	subb	a,#0x09
      007B7B EF               [12]  733 	mov	a,r7
      007B7C 94 70            [12]  734 	subb	a,#0x70
      007B7E 40 08            [24]  735 	jc	00101$
      007B80 74 0B            [12]  736 	mov	a,#0x0b
      007B82 9E               [12]  737 	subb	a,r6
      007B83 74 70            [12]  738 	mov	a,#0x70
      007B85 9F               [12]  739 	subb	a,r7
      007B86 50 04            [24]  740 	jnc	00102$
                                    741 ;	free result
      007B88                        742 00101$:
      007B88 75 82 01         [24]  743 	mov	dpl, #0x01
      007B8B 22               [24]  744 	ret
      007B8C                        745 00102$:
                                    746 ;	quantum/action_util.c:61: if (pressed) {
      007B8C 90 09 76         [24]  747 	mov	dptr,#_ak820_gui_process_PARM_2
      007B8F E0               [24]  748 	movx	a,@dptr
      007B90 60 21            [24]  749 	jz	00105$
                                    750 ;	quantum/action_util.c:62: gui_disabled = code == QK_MAGIC_TOGGLE_GUI ? !gui_disabled : code == QK_MAGIC_GUI_OFF;
      007B92 BE 0B 0D         [24]  751 	cjne	r6,#0x0b,00108$
      007B95 BF 70 0A         [24]  752 	cjne	r7,#0x70,00108$
      007B98 A2 20            [12]  753 	mov	c,_gui_disabled
      007B9A B3               [12]  754 	cpl	c
      007B9B 92 21            [24]  755 	mov  _ak820_gui_process_sloc0_1_0,c
      007B9D E4               [12]  756 	clr	a
      007B9E 33               [12]  757 	rlc	a
      007B9F FD               [12]  758 	mov	r5,a
      007BA0 80 09            [24]  759 	sjmp	00109$
      007BA2                        760 00108$:
      007BA2 E4               [12]  761 	clr	a
      007BA3 BE 0A 04         [24]  762 	cjne	r6,#0x0a,00136$
      007BA6 BF 70 01         [24]  763 	cjne	r7,#0x70,00136$
      007BA9 04               [12]  764 	inc	a
      007BAA                        765 00136$:
      007BAA FD               [12]  766 	mov	r5,a
      007BAB                        767 00109$:
                                    768 ;	assignBit
      007BAB ED               [12]  769 	mov	a,r5
      007BAC 24 FF            [12]  770 	add	a,#0xff
      007BAE 92 20            [24]  771 	mov	_gui_disabled,c
                                    772 ;	quantum/action_util.c:63: send_keyboard_report();
      007BB0 12 80 37         [24]  773 	lcall	_send_keyboard_report
      007BB3                        774 00105$:
                                    775 ;	quantum/action_util.c:65: return false;
      007BB3 75 82 00         [24]  776 	mov	dpl, #0x00
                                    777 ;	quantum/action_util.c:69: }
      007BB6 22               [24]  778 	ret
                                    779 ;------------------------------------------------------------
                                    780 ;Allocation info for local variables in function 'ak820_macro_change'
                                    781 ;------------------------------------------------------------
                                    782 ;index         Allocated with name '_ak820_macro_change_PARM_2'
                                    783 ;pressed       Allocated with name '_ak820_macro_change_PARM_3'
                                    784 ;bits          Allocated with name '_ak820_macro_change_bits_10000_299'
                                    785 ;mask          Allocated with name '_ak820_macro_change_mask_10001_302'
                                    786 ;------------------------------------------------------------
                                    787 ;	quantum/action_util.c:78: bool ak820_macro_change(uint8_t AK820_STATE_MEM *bits, uint8_t index, bool pressed) {
                                    788 ;	-----------------------------------------
                                    789 ;	 function ak820_macro_change
                                    790 ;	-----------------------------------------
      007BB7                        791 _ak820_macro_change:
      007BB7 12 38 82         [24]  792 	lcall	_ak820_outline_0109
      007BBA 90 09 91         [24]  793 	mov	dptr,#_ak820_macro_change_bits_10000_299
      007BBD 12 38 87         [24]  794 	lcall	_ak820_outline_0110
                                    795 ;	quantum/action_util.c:79: if (!ak820_macro_primitive) return true;
      007BC0 90 09 8D         [24]  796 	mov	dptr,#_ak820_macro_primitive
      007BC3 E0               [24]  797 	movx	a,@dptr
      007BC4 70 04            [24]  798 	jnz	00102$
      007BC6 75 82 01         [24]  799 	mov	dpl, #0x01
      007BC9 22               [24]  800 	ret
      007BCA                        801 00102$:
                                    802 ;	quantum/action_util.c:80: uint8_t mask = 1u << (index & 7);
      007BCA 90 09 8F         [24]  803 	mov	dptr,#_ak820_macro_change_PARM_2
      007BCD E0               [24]  804 	movx	a,@dptr
      007BCE FF               [12]  805 	mov	r7,a
      007BCF 74 07            [12]  806 	mov	a,#0x07
      007BD1 5F               [12]  807 	anl	a,r7
      007BD2 12 76 FA         [24]  808 	lcall	_ak820_outline_0063
      007BD5 80 02            [24]  809 	sjmp	00123$
      007BD7                        810 00122$:
      007BD7 25 E0            [12]  811 	add	a,acc
      007BD9                        812 00123$:
      007BD9 D5 F0 FB         [24]  813 	djnz	b,00122$
      007BDC FE               [12]  814 	mov	r6,a
                                    815 ;	quantum/action_util.c:81: bits += index >> 3;
      007BDD EF               [12]  816 	mov	a,r7
      007BDE 12 57 4D         [24]  817 	lcall	_ak820_outline_0190
      007BE1 FF               [12]  818 	mov	r7,a
      007BE2 90 09 91         [24]  819 	mov	dptr,#_ak820_macro_change_bits_10000_299
      007BE5 12 38 58         [24]  820 	lcall	_ak820_outline_0061
      007BE8 90 09 91         [24]  821 	mov	dptr,#_ak820_macro_change_bits_10000_299
      007BEB EF               [12]  822 	mov	a,r7
      007BEC 2C               [12]  823 	add	a, r4
      007BED F0               [24]  824 	movx	@dptr,a
      007BEE E4               [12]  825 	clr	a
      007BEF 3D               [12]  826 	addc	a, r5
      007BF0 A3               [24]  827 	inc	dptr
      007BF1 F0               [24]  828 	movx	@dptr,a
                                    829 ;	quantum/action_util.c:82: if (((*bits & mask) != 0) == pressed) return false;
      007BF2 90 09 91         [24]  830 	mov	dptr,#_ak820_macro_change_bits_10000_299
      007BF5 E0               [24]  831 	movx	a,@dptr
      007BF6 FD               [12]  832 	mov	r5,a
      007BF7 A3               [24]  833 	inc	dptr
      007BF8 E0               [24]  834 	movx	a,@dptr
      007BF9 FF               [12]  835 	mov	r7,a
      007BFA 12 81 4F         [24]  836 	lcall	_ak820_outline_0191
      007BFD E0               [24]  837 	movx	a,@dptr
      007BFE FC               [12]  838 	mov	r4,a
      007BFF EE               [12]  839 	mov	a,r6
      007C00 5C               [12]  840 	anl	a,r4
      007C01 B4 01 00         [24]  841 	cjne	a,#0x01,00124$
      007C04                        842 00124$:
      007C04 B3               [12]  843 	cpl	c
      007C05 92 22            [24]  844 	mov	_ak820_macro_change_sloc0_1_0,c
      007C07 90 09 90         [24]  845 	mov	dptr,#_ak820_macro_change_PARM_3
      007C0A E0               [24]  846 	movx	a,@dptr
      007C0B FB               [12]  847 	mov	r3,a
      007C0C A2 22            [12]  848 	mov	c,_ak820_macro_change_sloc0_1_0
      007C0E E4               [12]  849 	clr	a
      007C0F 33               [12]  850 	rlc	a
      007C10 B5 03 04         [24]  851 	cjne	a,ar3,00104$
      007C13 75 82 00         [24]  852 	mov	dpl, #0x00
      007C16 22               [24]  853 	ret
      007C17                        854 00104$:
                                    855 ;	quantum/action_util.c:83: *bits ^= mask;
      007C17 EC               [12]  856 	mov	a,r4
      007C18 62 06            [12]  857 	xrl	ar6,a
      007C1A 12 81 4F         [24]  858 	lcall	_ak820_outline_0191
      007C1D EE               [12]  859 	mov	a,r6
      007C1E F0               [24]  860 	movx	@dptr,a
                                    861 ;	quantum/action_util.c:84: return true;
      007C1F 75 82 01         [24]  862 	mov	dpl, #0x01
                                    863 ;	quantum/action_util.c:85: }
      007C22 22               [24]  864 	ret
                                    865 ;------------------------------------------------------------
                                    866 ;Allocation info for local variables in function 'change_owned'
                                    867 ;------------------------------------------------------------
                                    868 ;mode          Allocated with name '_change_owned_PARM_2'
                                    869 ;mods          Allocated with name '_change_owned_mods_10000_304'
                                    870 ;kind          Allocated with name '_change_owned_kind_10000_305'
                                    871 ;pressed       Allocated with name '_change_owned_pressed_10000_305'
                                    872 ;refs          Allocated with name '_change_owned_refs_10000_305'
                                    873 ;old           Allocated with name '_change_owned_old_30000_307'
                                    874 ;result        Allocated with name '_change_owned_result_10001_308'
                                    875 ;i             Allocated with name '_change_owned_i_20001_309'
                                    876 ;bit           Allocated with name '_change_owned_bit_20001_309'
                                    877 ;sloc1         Allocated with name '_change_owned_sloc1_1_0'
                                    878 ;------------------------------------------------------------
                                    879 ;	quantum/action_util.c:86: static void change_owned(uint8_t mods, uint8_t mode) {
                                    880 ;	-----------------------------------------
                                    881 ;	 function change_owned
                                    882 ;	-----------------------------------------
      007C23                        883 _change_owned:
      007C23 E5 82            [12]  884 	mov	a,dpl
      007C25 90 09 94         [24]  885 	mov	dptr,#_change_owned_mods_10000_304
      007C28 F0               [24]  886 	movx	@dptr,a
                                    887 ;	quantum/action_util.c:87: uint8_t kind = mode >> 1;
      007C29 90 09 93         [24]  888 	mov	dptr,#_change_owned_PARM_2
      007C2C E0               [24]  889 	movx	a,@dptr
      007C2D FF               [12]  890 	mov	r7,a
      007C2E C3               [12]  891 	clr	c
      007C2F 13               [12]  892 	rrc	a
      007C30 FE               [12]  893 	mov	r6,a
                                    894 ;	quantum/action_util.c:88: bool pressed = (mode & 1) != 0;
      007C31 53 07 01         [24]  895 	anl	ar7,#0x01
      007C34 EF               [12]  896 	mov	a,r7
      007C35 B4 01 00         [24]  897 	cjne	a,#0x01,00205$
      007C38                        898 00205$:
      007C38 92 23            [24]  899 	mov  _change_owned_sloc0_1_0,c
      007C3A B3               [12]  900 	cpl	c
      007C3B E4               [12]  901 	clr	a
      007C3C 33               [12]  902 	rlc	a
      007C3D F5 54            [12]  903 	mov	_change_owned_sloc1_1_0,a
                                    904 ;	quantum/action_util.c:89: uint8_t AK820_STATE_MEM *refs = kind ? owned_weak_refs : owned_mod_refs;
      007C3F EE               [12]  905 	mov	a,r6
      007C40 60 06            [24]  906 	jz	00121$
      007C42 7D 81            [12]  907 	mov	r5,#_owned_weak_refs
      007C44 7F 09            [12]  908 	mov	r7,#(_owned_weak_refs >> 8)
      007C46 80 04            [24]  909 	sjmp	00122$
      007C48                        910 00121$:
      007C48 7D 79            [12]  911 	mov	r5,#_owned_mod_refs
      007C4A 7F 09            [12]  912 	mov	r7,#(_owned_mod_refs >> 8)
      007C4C                        913 00122$:
                                    914 ;	quantum/action_util.c:90: if (ak820_macro_primitive) {
      007C4C 90 09 8D         [24]  915 	mov	dptr,#_ak820_macro_primitive
      007C4F E0               [24]  916 	movx	a,@dptr
      007C50 60 37            [24]  917 	jz	00102$
                                    918 ;	quantum/action_util.c:91: uint8_t old = macro_mods[kind];
      007C52 EE               [12]  919 	mov	a,r6
      007C53 24 8B            [12]  920 	add	a, #_macro_mods
      007C55 FB               [12]  921 	mov	r3,a
      007C56 E4               [12]  922 	clr	a
      007C57 34 09            [12]  923 	addc	a, #(_macro_mods >> 8)
      007C59 FC               [12]  924 	mov	r4,a
      007C5A 12 48 99         [24]  925 	lcall	_ak820_outline_0065
                                    926 ;	quantum/action_util.c:92: macro_mods[kind] = pressed ? old | mods : old & ~mods;
      007C5D E5 54            [12]  927 	mov	a,_change_owned_sloc1_1_0
      007C5F 60 0A            [24]  928 	jz	00123$
      007C61 90 09 94         [24]  929 	mov	dptr,#_change_owned_mods_10000_304
      007C64 E0               [24]  930 	movx	a,@dptr
      007C65 F9               [12]  931 	mov	r1,a
      007C66 EA               [12]  932 	mov	a,r2
      007C67 42 01            [12]  933 	orl	ar1,a
      007C69 80 07            [24]  934 	sjmp	00124$
      007C6B                        935 00123$:
      007C6B 90 09 94         [24]  936 	mov	dptr,#_change_owned_mods_10000_304
      007C6E E0               [24]  937 	movx	a,@dptr
      007C6F F4               [12]  938 	cpl	a
      007C70 5A               [12]  939 	anl	a,r2
      007C71 F9               [12]  940 	mov	r1,a
      007C72                        941 00124$:
      007C72 12 33 FC         [24]  942 	lcall	_ak820_outline_0125
      007C75 E9               [12]  943 	mov	a,r1
      007C76 F0               [24]  944 	movx	@dptr,a
                                    945 ;	quantum/action_util.c:93: mods &= pressed ? ~old : old;
      007C77 E5 54            [12]  946 	mov	a,_change_owned_sloc1_1_0
      007C79 60 06            [24]  947 	jz	00125$
      007C7B 74 FF            [12]  948 	mov	a,#0xff
      007C7D 6A               [12]  949 	xrl	a,r2
      007C7E FC               [12]  950 	mov	r4,a
      007C7F 80 02            [24]  951 	sjmp	00126$
      007C81                        952 00125$:
      007C81 8A 04            [24]  953 	mov	ar4,r2
      007C83                        954 00126$:
      007C83 90 09 94         [24]  955 	mov	dptr,#_change_owned_mods_10000_304
      007C86 E0               [24]  956 	movx	a,@dptr
      007C87 5C               [12]  957 	anl	a,r4
      007C88 F0               [24]  958 	movx	@dptr,a
      007C89                        959 00102$:
                                    960 ;	quantum/action_util.c:95: uint8_t result = 0;
      007C89 90 09 95         [24]  961 	mov	dptr,#_change_owned_result_10001_308
      007C8C E4               [12]  962 	clr	a
      007C8D F0               [24]  963 	movx	@dptr,a
                                    964 ;	quantum/action_util.c:96: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      007C8E 90 09 96         [24]  965 	mov	dptr,#_change_owned_bit_20001_309
      007C91 04               [12]  966 	inc	a
      007C92 F0               [24]  967 	movx	@dptr,a
      007C93 90 09 94         [24]  968 	mov	dptr,#_change_owned_mods_10000_304
      007C96 E0               [24]  969 	movx	a,@dptr
      007C97 FC               [12]  970 	mov	r4,a
      007C98 7B 00            [12]  971 	mov	r3,#0x00
      007C9A                        972 00117$:
      007C9A BB 08 00         [24]  973 	cjne	r3,#0x08,00210$
      007C9D                        974 00210$:
      007C9D 50 3F            [24]  975 	jnc	00112$
                                    976 ;	quantum/action_util.c:97: if (mods & bit) {
      007C9F 90 09 96         [24]  977 	mov	dptr,#_change_owned_bit_20001_309
      007CA2 E0               [24]  978 	movx	a,@dptr
      007CA3 5C               [12]  979 	anl	a,r4
      007CA4 60 1C            [24]  980 	jz	00109$
                                    981 ;	quantum/action_util.c:98: if (pressed) ++refs[i];
      007CA6 E5 54            [12]  982 	mov	a,_change_owned_sloc1_1_0
      007CA8 60 0C            [24]  983 	jz	00106$
      007CAA EB               [12]  984 	mov	a,r3
      007CAB 2D               [12]  985 	add	a, r5
      007CAC 12 38 27         [24]  986 	lcall	_ak820_outline_0017
      007CAF F8               [12]  987 	mov	r0,a
      007CB0 08               [12]  988 	inc	r0
      007CB1 12 81 0C         [24]  989 	lcall	_ak820_outline_0064
      007CB4 80 0C            [24]  990 	sjmp	00109$
      007CB6                        991 00106$:
                                    992 ;	quantum/action_util.c:99: else if (refs[i]) --refs[i];
      007CB6 EB               [12]  993 	mov	a,r3
      007CB7 2D               [12]  994 	add	a, r5
      007CB8 12 38 27         [24]  995 	lcall	_ak820_outline_0017
      007CBB F8               [12]  996 	mov	r0,a
      007CBC 60 04            [24]  997 	jz	00109$
      007CBE 18               [12]  998 	dec	r0
      007CBF 12 81 0C         [24]  999 	lcall	_ak820_outline_0064
      007CC2                       1000 00109$:
                                   1001 ;	quantum/action_util.c:101: if (refs[i]) result |= bit;
      007CC2 EB               [12] 1002 	mov	a,r3
      007CC3 2D               [12] 1003 	add	a, r5
      007CC4 12 38 27         [24] 1004 	lcall	_ak820_outline_0017
      007CC7 60 0B            [24] 1005 	jz	00118$
      007CC9 90 09 96         [24] 1006 	mov	dptr,#_change_owned_bit_20001_309
      007CCC E0               [24] 1007 	movx	a,@dptr
      007CCD FA               [12] 1008 	mov	r2,a
      007CCE 90 09 95         [24] 1009 	mov	dptr,#_change_owned_result_10001_308
      007CD1 E0               [24] 1010 	movx	a,@dptr
      007CD2 4A               [12] 1011 	orl	a,r2
      007CD3 F0               [24] 1012 	movx	@dptr,a
      007CD4                       1013 00118$:
                                   1014 ;	quantum/action_util.c:96: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      007CD4 0B               [12] 1015 	inc	r3
      007CD5 90 09 96         [24] 1016 	mov	dptr,#_change_owned_bit_20001_309
      007CD8 E0               [24] 1017 	movx	a,@dptr
      007CD9 25 E0            [12] 1018 	add	a,acc
      007CDB F0               [24] 1019 	movx	@dptr,a
      007CDC 80 BC            [24] 1020 	sjmp	00117$
      007CDE                       1021 00112$:
                                   1022 ;	quantum/action_util.c:103: if (kind) owned_weak_mods = result;
      007CDE EE               [12] 1023 	mov	a,r6
      007CDF 60 09            [24] 1024 	jz	00114$
      007CE1 90 09 95         [24] 1025 	mov	dptr,#_change_owned_result_10001_308
      007CE4 E0               [24] 1026 	movx	a,@dptr
      007CE5 90 09 8A         [24] 1027 	mov	dptr,#_owned_weak_mods
      007CE8 F0               [24] 1028 	movx	@dptr,a
      007CE9 22               [24] 1029 	ret
      007CEA                       1030 00114$:
                                   1031 ;	quantum/action_util.c:104: else owned_mods = result;
      007CEA 90 09 95         [24] 1032 	mov	dptr,#_change_owned_result_10001_308
      007CED E0               [24] 1033 	movx	a,@dptr
      007CEE 90 09 89         [24] 1034 	mov	dptr,#_owned_mods
      007CF1 F0               [24] 1035 	movx	@dptr,a
                                   1036 ;	quantum/action_util.c:105: }
      007CF2 22               [24] 1037 	ret
                                   1038 ;------------------------------------------------------------
                                   1039 ;Allocation info for local variables in function 'add_owned_mods'
                                   1040 ;------------------------------------------------------------
                                   1041 ;mods          Allocated with name '_add_owned_mods_mods_10000_317'
                                   1042 ;------------------------------------------------------------
                                   1043 ;	quantum/action_util.c:106: void add_owned_mods(uint8_t mods) { change_owned(mods, 1); }
                                   1044 ;	-----------------------------------------
                                   1045 ;	 function add_owned_mods
                                   1046 ;	-----------------------------------------
      007CF3                       1047 _add_owned_mods:
      007CF3 E5 82            [12] 1048 	mov	a,dpl
      007CF5 90 09 97         [24] 1049 	mov	dptr,#_add_owned_mods_mods_10000_317
      007CF8 12 81 2C         [24] 1050 	lcall	_ak820_outline_0119
      007CFB 74 01            [12] 1051 	mov	a,#0x01
      007CFD F0               [24] 1052 	movx	@dptr,a
      007CFE 8F 82            [24] 1053 	mov	dpl, r7
      007D00 02 7C 23         [24] 1054 	ljmp	_change_owned
                                   1055 ;------------------------------------------------------------
                                   1056 ;Allocation info for local variables in function 'del_owned_mods'
                                   1057 ;------------------------------------------------------------
                                   1058 ;mods          Allocated with name '_del_owned_mods_mods_10000_319'
                                   1059 ;------------------------------------------------------------
                                   1060 ;	quantum/action_util.c:107: void del_owned_mods(uint8_t mods) { change_owned(mods, 0); }
                                   1061 ;	-----------------------------------------
                                   1062 ;	 function del_owned_mods
                                   1063 ;	-----------------------------------------
      007D03                       1064 _del_owned_mods:
      007D03 E5 82            [12] 1065 	mov	a,dpl
      007D05 90 09 98         [24] 1066 	mov	dptr,#_del_owned_mods_mods_10000_319
      007D08 12 81 2C         [24] 1067 	lcall	_ak820_outline_0119
      007D0B E4               [12] 1068 	clr	a
      007D0C F0               [24] 1069 	movx	@dptr,a
      007D0D 8F 82            [24] 1070 	mov	dpl, r7
      007D0F 02 7C 23         [24] 1071 	ljmp	_change_owned
                                   1072 ;------------------------------------------------------------
                                   1073 ;Allocation info for local variables in function 'add_owned_weak_mods'
                                   1074 ;------------------------------------------------------------
                                   1075 ;mods          Allocated with name '_add_owned_weak_mods_mods_10000_321'
                                   1076 ;------------------------------------------------------------
                                   1077 ;	quantum/action_util.c:108: void add_owned_weak_mods(uint8_t mods) { change_owned(mods, 3); }
                                   1078 ;	-----------------------------------------
                                   1079 ;	 function add_owned_weak_mods
                                   1080 ;	-----------------------------------------
      007D12                       1081 _add_owned_weak_mods:
      007D12 E5 82            [12] 1082 	mov	a,dpl
      007D14 90 09 99         [24] 1083 	mov	dptr,#_add_owned_weak_mods_mods_10000_321
      007D17 12 81 2C         [24] 1084 	lcall	_ak820_outline_0119
      007D1A 74 03            [12] 1085 	mov	a,#0x03
      007D1C F0               [24] 1086 	movx	@dptr,a
      007D1D 8F 82            [24] 1087 	mov	dpl, r7
      007D1F 02 7C 23         [24] 1088 	ljmp	_change_owned
                                   1089 ;------------------------------------------------------------
                                   1090 ;Allocation info for local variables in function 'del_owned_weak_mods'
                                   1091 ;------------------------------------------------------------
                                   1092 ;mods          Allocated with name '_del_owned_weak_mods_mods_10000_323'
                                   1093 ;------------------------------------------------------------
                                   1094 ;	quantum/action_util.c:109: void del_owned_weak_mods(uint8_t mods) { change_owned(mods, 2); }
                                   1095 ;	-----------------------------------------
                                   1096 ;	 function del_owned_weak_mods
                                   1097 ;	-----------------------------------------
      007D22                       1098 _del_owned_weak_mods:
      007D22 E5 82            [12] 1099 	mov	a,dpl
      007D24 90 09 9A         [24] 1100 	mov	dptr,#_del_owned_weak_mods_mods_10000_323
      007D27 12 81 2C         [24] 1101 	lcall	_ak820_outline_0119
      007D2A 74 02            [12] 1102 	mov	a,#0x02
      007D2C F0               [24] 1103 	movx	@dptr,a
      007D2D 8F 82            [24] 1104 	mov	dpl, r7
      007D2F 02 7C 23         [24] 1105 	ljmp	_change_owned
                                   1106 ;------------------------------------------------------------
                                   1107 ;Allocation info for local variables in function 'clear_owned_mods'
                                   1108 ;------------------------------------------------------------
                                   1109 ;i             Allocated with name '_clear_owned_mods_i_20000_327'
                                   1110 ;------------------------------------------------------------
                                   1111 ;	quantum/action_util.c:110: void clear_owned_mods(void) {
                                   1112 ;	-----------------------------------------
                                   1113 ;	 function clear_owned_mods
                                   1114 ;	-----------------------------------------
      007D32                       1115 _clear_owned_mods:
                                   1116 ;	quantum/action_util.c:111: for (uint8_t i = 0; i < 8; ++i) owned_mod_refs[i] = owned_weak_refs[i] = 0;
      007D32 7F 00            [12] 1117 	mov	r7,#0x00
      007D34                       1118 00103$:
      007D34 BF 08 00         [24] 1119 	cjne	r7,#0x08,00122$
      007D37                       1120 00122$:
      007D37 50 1A            [24] 1121 	jnc	00101$
      007D39 EF               [12] 1122 	mov	a,r7
      007D3A 24 79            [12] 1123 	add	a, #_owned_mod_refs
      007D3C FD               [12] 1124 	mov	r5,a
      007D3D E4               [12] 1125 	clr	a
      007D3E 34 09            [12] 1126 	addc	a, #(_owned_mod_refs >> 8)
      007D40 FE               [12] 1127 	mov	r6,a
      007D41 EF               [12] 1128 	mov	a,r7
      007D42 24 81            [12] 1129 	add	a, #_owned_weak_refs
      007D44 F5 82            [12] 1130 	mov	dpl,a
      007D46 E4               [12] 1131 	clr	a
      007D47 34 09            [12] 1132 	addc	a, #(_owned_weak_refs >> 8)
      007D49 F5 83            [12] 1133 	mov	dph,a
      007D4B E4               [12] 1134 	clr	a
      007D4C F0               [24] 1135 	movx	@dptr,a
      007D4D 12 81 33         [24] 1136 	lcall	_ak820_outline_0123
      007D50 0F               [12] 1137 	inc	r7
      007D51 80 E1            [24] 1138 	sjmp	00103$
      007D53                       1139 00101$:
                                   1140 ;	quantum/action_util.c:112: owned_mods = owned_weak_mods = macro_mods[0] = macro_mods[1] = 0;
      007D53 90 09 8C         [24] 1141 	mov	dptr,#(_macro_mods + 0x0001)
      007D56 E4               [12] 1142 	clr	a
      007D57 F0               [24] 1143 	movx	@dptr,a
      007D58 90 09 8B         [24] 1144 	mov	dptr,#_macro_mods
      007D5B F0               [24] 1145 	movx	@dptr,a
      007D5C 90 09 8A         [24] 1146 	mov	dptr,#_owned_weak_mods
      007D5F F0               [24] 1147 	movx	@dptr,a
      007D60 90 09 89         [24] 1148 	mov	dptr,#_owned_mods
      007D63 F0               [24] 1149 	movx	@dptr,a
                                   1150 ;	quantum/action_util.c:113: ak820_macro_cancelled = true;
      007D64 90 09 8E         [24] 1151 	mov	dptr,#_ak820_macro_cancelled
      007D67 04               [12] 1152 	inc	a
      007D68 F0               [24] 1153 	movx	@dptr,a
                                   1154 ;	quantum/action_util.c:114: }
      007D69 22               [24] 1155 	ret
                                   1156 ;------------------------------------------------------------
                                   1157 ;Allocation info for local variables in function 'clear_owned_keys'
                                   1158 ;------------------------------------------------------------
                                   1159 ;i             Allocated with name '_clear_owned_keys_i_20000_330'
                                   1160 ;i             Allocated with name '_clear_owned_keys_i_20000_331'
                                   1161 ;------------------------------------------------------------
                                   1162 ;	quantum/action_util.c:120: void clear_owned_keys(void) {
                                   1163 ;	-----------------------------------------
                                   1164 ;	 function clear_owned_keys
                                   1165 ;	-----------------------------------------
      007D6A                       1166 _clear_owned_keys:
                                   1167 ;	quantum/action_util.c:121: for (uint8_t i = 0; i <= KC_EXSEL; ++i) key_refs[i] = 0;
      007D6A 7F 00            [12] 1168 	mov	r7,#0x00
      007D6C                       1169 00104$:
      007D6C EF               [12] 1170 	mov	a,r7
      007D6D 24 5B            [12] 1171 	add	a,#0xff - 0xa4
      007D6F 40 0D            [24] 1172 	jc	00101$
                                   1173 ;	free result
      007D71 EF               [12] 1174 	mov	a,r7
      007D72 24 9B            [12] 1175 	add	a, #_key_refs
      007D74 F5 82            [12] 1176 	mov	dpl,a
      007D76 E4               [12] 1177 	clr	a
      007D77 34 09            [12] 1178 	addc	a, #(_key_refs >> 8)
      007D79 12 7B 59         [24] 1179 	lcall	_ak820_outline_0166
      007D7C 80 EE            [24] 1180 	sjmp	00104$
      007D7E                       1181 00101$:
                                   1182 ;	quantum/action_util.c:122: distinct_keys = 0;
      007D7E 90 0A 40         [24] 1183 	mov	dptr,#_distinct_keys
      007D81 E4               [12] 1184 	clr	a
      007D82 F0               [24] 1185 	movx	@dptr,a
                                   1186 ;	quantum/action_util.c:123: for (uint8_t i = 0; i < sizeof(macro_keys); ++i) macro_keys[i] = 0;
      007D83 FF               [12] 1187 	mov	r7,a
      007D84                       1188 00107$:
      007D84 BF 15 00         [24] 1189 	cjne	r7,#0x15,00142$
      007D87                       1190 00142$:
      007D87 50 0D            [24] 1191 	jnc	00109$
      007D89 EF               [12] 1192 	mov	a,r7
      007D8A 24 41            [12] 1193 	add	a, #_macro_keys
      007D8C F5 82            [12] 1194 	mov	dpl,a
      007D8E E4               [12] 1195 	clr	a
      007D8F 34 0A            [12] 1196 	addc	a, #(_macro_keys >> 8)
      007D91 12 7B 59         [24] 1197 	lcall	_ak820_outline_0166
      007D94 80 EE            [24] 1198 	sjmp	00107$
      007D96                       1199 00109$:
                                   1200 ;	quantum/action_util.c:124: }
      007D96 22               [24] 1201 	ret
                                   1202 ;------------------------------------------------------------
                                   1203 ;Allocation info for local variables in function 'add_owned_key'
                                   1204 ;------------------------------------------------------------
                                   1205 ;code          Allocated with name '_add_owned_key_code_10000_332'
                                   1206 ;__400000074   Allocated with name '_add_owned_key___400000074_40000_341'
                                   1207 ;key           Allocated with name '_add_owned_key_key_50000_342'
                                   1208 ;i             Allocated with name '_add_owned_key_i_40000_340'
                                   1209 ;__300000076   Allocated with name '_add_owned_key___300000076_30000_344'
                                   1210 ;key           Allocated with name '_add_owned_key_key_40000_345'
                                   1211 ;------------------------------------------------------------
                                   1212 ;	quantum/action_util.c:125: bool add_owned_key(uint8_t code) {
                                   1213 ;	-----------------------------------------
                                   1214 ;	 function add_owned_key
                                   1215 ;	-----------------------------------------
      007D97                       1216 _add_owned_key:
      007D97 E5 82            [12] 1217 	mov	a,dpl
      007D99 90 0A 56         [24] 1218 	mov	dptr,#_add_owned_key_code_10000_332
      007D9C 12 81 44         [24] 1219 	lcall	_ak820_outline_0134
                                   1220 ;	quantum/action_util.c:126: if (!ak820_macro_change(macro_keys, code, true)) return false;
      007D9F 74 01            [12] 1221 	mov	a,#0x01
      007DA1 F0               [24] 1222 	movx	@dptr,a
      007DA2 90 0A 41         [24] 1223 	mov	dptr,#_macro_keys
      007DA5 C0 07            [24] 1224 	push	ar7
      007DA7 12 7B B7         [24] 1225 	lcall	_ak820_macro_change
      007DAA E5 82            [12] 1226 	mov	a, dpl
      007DAC D0 07            [24] 1227 	pop	ar7
      007DAE 70 03            [24] 1228 	jnz	00102$
      007DB0 F5 82            [12] 1229 	mov	dpl,a
      007DB2 22               [24] 1230 	ret
      007DB3                       1231 00102$:
                                   1232 ;	quantum/action_util.c:127: if (key_refs[code]++) return false;
      007DB3 12 80 F6         [24] 1233 	lcall	_ak820_outline_0030
      007DB6 FC               [12] 1234 	mov	r4,a
      007DB7 04               [12] 1235 	inc	a
      007DB8 12 81 33         [24] 1236 	lcall	_ak820_outline_0123
      007DBB EC               [12] 1237 	mov	a,r4
      007DBC 60 04            [24] 1238 	jz	00104$
      007DBE 75 82 00         [24] 1239 	mov	dpl, #0x00
      007DC1 22               [24] 1240 	ret
      007DC2                       1241 00104$:
                                   1242 ;	quantum/action_util.c:128: ++distinct_keys;
      007DC2 90 0A 40         [24] 1243 	mov	dptr,#_distinct_keys
      007DC5 E0               [24] 1244 	movx	a,@dptr
      007DC6 24 01            [12] 1245 	add	a, #0x01
      007DC8 F0               [24] 1246 	movx	@dptr,a
                                   1247 ;	quantum/action_util.c:130: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      007DC9 90 0D B9         [24] 1248 	mov	dptr,#_keyboard_protocol
      007DCC E0               [24] 1249 	movx	a,@dptr
      007DCD 60 15            [24] 1250 	jz	00106$
      007DCF 90 0A C5         [24] 1251 	mov	dptr,#_keymap_config
      007DD2 E0               [24] 1252 	movx	a,@dptr
      007DD3 30 E7 0E         [24] 1253 	jnb	acc.7,00106$
                                   1254 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      007DD6 90 08 03         [24] 1255 	mov	dptr,#_add_key_to_report_PARM_2
      007DD9 EF               [12] 1256 	mov	a,r7
      007DDA 12 81 04         [24] 1257 	lcall	_ak820_outline_0058
      007DDD 12 6E BB         [24] 1258 	lcall	_add_key_to_report
                                   1259 ;	quantum/action_util.c:130: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      007DE0 75 82 01         [24] 1260 	mov	dpl, #0x01
      007DE3 22               [24] 1261 	ret
      007DE4                       1262 00106$:
                                   1263 ;	quantum/action_util.c:132: if (distinct_keys > KEYBOARD_REPORT_KEYS) {
      007DE4 90 0A 40         [24] 1264 	mov	dptr,#_distinct_keys
      007DE7 E0               [24] 1265 	movx	a,@dptr
      007DE8 24 F9            [12] 1266 	add	a,#0xff - 0x06
      007DEA 50 17            [24] 1267 	jnc	00110$
                                   1268 ;	free result
                                   1269 ;	quantum/action_util.c:133: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; ++i) keyboard_report->keys[i] = 1; /* HID ErrorRollOver */
      007DEC 7F 00            [12] 1270 	mov	r7,#0x00
      007DEE                       1271 00115$:
      007DEE BF 06 00         [24] 1272 	cjne	r7,#0x06,00174$
      007DF1                       1273 00174$:
      007DF1 50 1D            [24] 1274 	jnc	00111$
      007DF3 EF               [12] 1275 	mov	a,r7
      007DF4 24 CE            [12] 1276 	add	a, #(_actual_keyboard_report + 0x0002)
      007DF6 F5 82            [12] 1277 	mov	dpl,a
      007DF8 E4               [12] 1278 	clr	a
      007DF9 34 0D            [12] 1279 	addc	a, #((_actual_keyboard_report + 0x0002) >> 8)
      007DFB F5 83            [12] 1280 	mov	dph,a
      007DFD 74 01            [12] 1281 	mov	a,#0x01
      007DFF F0               [24] 1282 	movx	@dptr,a
      007E00 0F               [12] 1283 	inc	r7
      007E01 80 EB            [24] 1284 	sjmp	00115$
      007E03                       1285 00110$:
                                   1286 ;	quantum/action_util.c:134: } else add_key(code);
      007E03 90 0A 56         [24] 1287 	mov	dptr,#_add_owned_key_code_10000_332
      007E06 E0               [24] 1288 	movx	a,@dptr
                                   1289 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      007E07 90 08 03         [24] 1290 	mov	dptr,#_add_key_to_report_PARM_2
      007E0A 12 81 04         [24] 1291 	lcall	_ak820_outline_0058
      007E0D 12 6E BB         [24] 1292 	lcall	_add_key_to_report
                                   1293 ;	quantum/action_util.c:134: } else add_key(code);
      007E10                       1294 00111$:
                                   1295 ;	quantum/action_util.c:135: return true;
      007E10 75 82 01         [24] 1296 	mov	dpl, #0x01
                                   1297 ;	quantum/action_util.c:136: }
      007E13 22               [24] 1298 	ret
                                   1299 ;------------------------------------------------------------
                                   1300 ;Allocation info for local variables in function 'del_owned_key'
                                   1301 ;------------------------------------------------------------
                                   1302 ;code          Allocated with name '_del_owned_key_code_10000_347'
                                   1303 ;__400000078   Allocated with name '_del_owned_key___400000078_40000_358'
                                   1304 ;key           Allocated with name '_del_owned_key_key_50000_359'
                                   1305 ;key           Allocated with name '_del_owned_key_key_40000_356'
                                   1306 ;__600000081   Allocated with name '_del_owned_key___600000081_60000_364'
                                   1307 ;key           Allocated with name '_del_owned_key_key_70000_365'
                                   1308 ;__300000083   Allocated with name '_del_owned_key___300000083_30000_367'
                                   1309 ;key           Allocated with name '_del_owned_key_key_40000_368'
                                   1310 ;------------------------------------------------------------
                                   1311 ;	quantum/action_util.c:137: bool del_owned_key(uint8_t code) {
                                   1312 ;	-----------------------------------------
                                   1313 ;	 function del_owned_key
                                   1314 ;	-----------------------------------------
      007E14                       1315 _del_owned_key:
      007E14 E5 82            [12] 1316 	mov	a,dpl
      007E16 90 0A 57         [24] 1317 	mov	dptr,#_del_owned_key_code_10000_347
      007E19 12 81 44         [24] 1318 	lcall	_ak820_outline_0134
                                   1319 ;	quantum/action_util.c:138: if (!ak820_macro_change(macro_keys, code, false)) return false;
      007E1C E4               [12] 1320 	clr	a
      007E1D F0               [24] 1321 	movx	@dptr,a
      007E1E 90 0A 41         [24] 1322 	mov	dptr,#_macro_keys
      007E21 C0 07            [24] 1323 	push	ar7
      007E23 12 7B B7         [24] 1324 	lcall	_ak820_macro_change
      007E26 E5 82            [12] 1325 	mov	a, dpl
      007E28 D0 07            [24] 1326 	pop	ar7
      007E2A 70 03            [24] 1327 	jnz	00102$
      007E2C F5 82            [12] 1328 	mov	dpl,a
      007E2E 22               [24] 1329 	ret
      007E2F                       1330 00102$:
                                   1331 ;	quantum/action_util.c:139: if (!key_refs[code] || --key_refs[code]) return false;
      007E2F 12 80 F6         [24] 1332 	lcall	_ak820_outline_0030
      007E32 FC               [12] 1333 	mov	r4,a
      007E33 60 09            [24] 1334 	jz	00103$
      007E35 1C               [12] 1335 	dec	r4
      007E36 12 38 9C         [24] 1336 	lcall	_ak820_outline_0135
      007E39 EC               [12] 1337 	mov	a,r4
      007E3A F0               [24] 1338 	movx	@dptr,a
      007E3B EC               [12] 1339 	mov	a,r4
      007E3C 60 04            [24] 1340 	jz	00104$
      007E3E                       1341 00103$:
      007E3E 75 82 00         [24] 1342 	mov	dpl, #0x00
      007E41 22               [24] 1343 	ret
      007E42                       1344 00104$:
                                   1345 ;	quantum/action_util.c:140: --distinct_keys;
      007E42 90 0A 40         [24] 1346 	mov	dptr,#_distinct_keys
      007E45 E0               [24] 1347 	movx	a,@dptr
      007E46 14               [12] 1348 	dec	a
      007E47 F0               [24] 1349 	movx	@dptr,a
                                   1350 ;	quantum/action_util.c:142: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      007E48 90 0D B9         [24] 1351 	mov	dptr,#_keyboard_protocol
      007E4B E0               [24] 1352 	movx	a,@dptr
      007E4C 60 15            [24] 1353 	jz	00107$
      007E4E 90 0A C5         [24] 1354 	mov	dptr,#_keymap_config
      007E51 E0               [24] 1355 	movx	a,@dptr
      007E52 30 E7 0E         [24] 1356 	jnb	acc.7,00107$
                                   1357 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      007E55 90 08 07         [24] 1358 	mov	dptr,#_del_key_from_report_PARM_2
      007E58 EF               [12] 1359 	mov	a,r7
      007E59 12 81 04         [24] 1360 	lcall	_ak820_outline_0058
      007E5C 12 6E F9         [24] 1361 	lcall	_del_key_from_report
                                   1362 ;	quantum/action_util.c:142: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      007E5F 75 82 01         [24] 1363 	mov	dpl, #0x01
      007E62 22               [24] 1364 	ret
      007E63                       1365 00107$:
                                   1366 ;	quantum/action_util.c:144: if (distinct_keys > KEYBOARD_REPORT_KEYS) return true;
      007E63 90 0A 40         [24] 1367 	mov	dptr,#_distinct_keys
      007E66 E0               [24] 1368 	movx	a,@dptr
      007E67 FF               [12] 1369 	mov  r7,a
      007E68 24 F9            [12] 1370 	add	a,#0xff - 0x06
      007E6A 50 04            [24] 1371 	jnc	00110$
                                   1372 ;	free result
      007E6C 75 82 01         [24] 1373 	mov	dpl, #0x01
      007E6F 22               [24] 1374 	ret
      007E70                       1375 00110$:
                                   1376 ;	quantum/action_util.c:145: if (distinct_keys == KEYBOARD_REPORT_KEYS) {
      007E70 BF 06 26         [24] 1377 	cjne	r7,#0x06,00115$
                                   1378 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007E73 90 0D CC         [24] 1379 	mov	dptr,#_actual_keyboard_report
      007E76 75 F0 00         [24] 1380 	mov	b, #0x00
      007E79 12 6F 37         [24] 1381 	lcall	_clear_keys_from_report
                                   1382 ;	quantum/action_util.c:148: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      007E7C 7F 04            [12] 1383 	mov	r7,#0x04
      007E7E                       1384 00122$:
      007E7E EF               [12] 1385 	mov	a,r7
      007E7F 24 5B            [12] 1386 	add	a,#0xff - 0xa4
      007E81 40 23            [24] 1387 	jc	00116$
                                   1388 ;	free result
      007E83 12 80 F6         [24] 1389 	lcall	_ak820_outline_0030
      007E86 60 0E            [24] 1390 	jz	00123$
                                   1391 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      007E88 90 08 03         [24] 1392 	mov	dptr,#_add_key_to_report_PARM_2
      007E8B EF               [12] 1393 	mov	a,r7
      007E8C 12 81 04         [24] 1394 	lcall	_ak820_outline_0058
      007E8F C0 07            [24] 1395 	push	ar7
      007E91 12 6E BB         [24] 1396 	lcall	_add_key_to_report
      007E94 D0 07            [24] 1397 	pop	ar7
                                   1398 ;	quantum/action_util.c:148: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      007E96                       1399 00123$:
      007E96 0F               [12] 1400 	inc	r7
      007E97 80 E5            [24] 1401 	sjmp	00122$
      007E99                       1402 00115$:
                                   1403 ;	quantum/action_util.c:149: } else del_key(code);
      007E99 90 0A 57         [24] 1404 	mov	dptr,#_del_owned_key_code_10000_347
      007E9C E0               [24] 1405 	movx	a,@dptr
                                   1406 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      007E9D 90 08 07         [24] 1407 	mov	dptr,#_del_key_from_report_PARM_2
      007EA0 12 81 04         [24] 1408 	lcall	_ak820_outline_0058
      007EA3 12 6E F9         [24] 1409 	lcall	_del_key_from_report
                                   1410 ;	quantum/action_util.c:149: } else del_key(code);
      007EA6                       1411 00116$:
                                   1412 ;	quantum/action_util.c:150: return true;
      007EA6 75 82 01         [24] 1413 	mov	dpl, #0x01
                                   1414 ;	quantum/action_util.c:151: }
      007EA9 22               [24] 1415 	ret
                                   1416 ;------------------------------------------------------------
                                   1417 ;Allocation info for local variables in function 'clear_owned_usages'
                                   1418 ;------------------------------------------------------------
                                   1419 ;i             Allocated with name '_clear_owned_usages_i_20000_372'
                                   1420 ;i             Allocated with name '_clear_owned_usages_i_20000_373'
                                   1421 ;------------------------------------------------------------
                                   1422 ;	quantum/action_util.c:161: void clear_owned_usages(void) {
                                   1423 ;	-----------------------------------------
                                   1424 ;	 function clear_owned_usages
                                   1425 ;	-----------------------------------------
      007EAA                       1426 _clear_owned_usages:
                                   1427 ;	quantum/action_util.c:162: for (uint8_t i = 0; i < USAGE_COUNT; ++i) usage_refs[i] = usage_order[i] = 0;
      007EAA 7F 00            [12] 1428 	mov	r7,#0x00
      007EAC                       1429 00104$:
      007EAC BF 1E 00         [24] 1430 	cjne	r7,#0x1e,00141$
      007EAF                       1431 00141$:
      007EAF 50 14            [24] 1432 	jnc	00101$
      007EB1 EF               [12] 1433 	mov	a,r7
      007EB2 24 58            [12] 1434 	add	a, #_usage_refs
      007EB4 FD               [12] 1435 	mov	r5,a
      007EB5 E4               [12] 1436 	clr	a
      007EB6 34 0A            [12] 1437 	addc	a, #(_usage_refs >> 8)
      007EB8 FE               [12] 1438 	mov	r6,a
      007EB9 EF               [12] 1439 	mov	a,r7
      007EBA 12 81 13         [24] 1440 	lcall	_ak820_outline_0068
      007EBD E4               [12] 1441 	clr	a
      007EBE F0               [24] 1442 	movx	@dptr,a
      007EBF 12 81 33         [24] 1443 	lcall	_ak820_outline_0123
      007EC2 0F               [12] 1444 	inc	r7
      007EC3 80 E7            [24] 1445 	sjmp	00104$
      007EC5                       1446 00101$:
                                   1447 ;	quantum/action_util.c:163: usage_lengths[0] = usage_lengths[1] = 0;
      007EC5 90 0A 95         [24] 1448 	mov	dptr,#(_usage_lengths + 0x0001)
      007EC8 E4               [12] 1449 	clr	a
      007EC9 F0               [24] 1450 	movx	@dptr,a
      007ECA 90 0A 94         [24] 1451 	mov	dptr,#_usage_lengths
      007ECD F0               [24] 1452 	movx	@dptr,a
                                   1453 ;	quantum/action_util.c:164: for (uint8_t i = 0; i < sizeof(macro_usages); ++i) macro_usages[i] = 0;
      007ECE FF               [12] 1454 	mov	r7,a
      007ECF                       1455 00107$:
      007ECF BF 04 00         [24] 1456 	cjne	r7,#0x04,00143$
      007ED2                       1457 00143$:
      007ED2 50 0D            [24] 1458 	jnc	00109$
      007ED4 EF               [12] 1459 	mov	a,r7
      007ED5 24 96            [12] 1460 	add	a, #_macro_usages
      007ED7 F5 82            [12] 1461 	mov	dpl,a
      007ED9 E4               [12] 1462 	clr	a
      007EDA 34 0A            [12] 1463 	addc	a, #(_macro_usages >> 8)
      007EDC 12 7B 59         [24] 1464 	lcall	_ak820_outline_0166
      007EDF 80 EE            [24] 1465 	sjmp	00107$
      007EE1                       1466 00109$:
                                   1467 ;	quantum/action_util.c:165: }
      007EE1 22               [24] 1468 	ret
                                   1469 ;------------------------------------------------------------
                                   1470 ;Allocation info for local variables in function 'owned_usage_key'
                                   1471 ;------------------------------------------------------------
                                   1472 ;pressed       Allocated with name '_owned_usage_key_PARM_2'
                                   1473 ;code          Allocated with name '_owned_usage_key_code_10000_374'
                                   1474 ;__200000085   Allocated with name '_owned_usage_key___200000085_20000_375'
                                   1475 ;which         Allocated with name '_owned_usage_key_which_10000_375'
                                   1476 ;base          Allocated with name '_owned_usage_key_base_10000_375'
                                   1477 ;count         Allocated with name '_owned_usage_key_count_10000_375'
                                   1478 ;index         Allocated with name '_owned_usage_key_index_10000_375'
                                   1479 ;pos           Allocated with name '_owned_usage_key_pos_30001_382'
                                   1480 ;i             Allocated with name '_owned_usage_key_i_40001_383'
                                   1481 ;__300000086   Allocated with name '_owned_usage_key___300000086_30000_386'
                                   1482 ;key           Allocated with name '_owned_usage_key_key_40000_387'
                                   1483 ;------------------------------------------------------------
                                   1484 ;	quantum/action_util.c:166: void owned_usage_key(uint8_t code, bool pressed) {
                                   1485 ;	-----------------------------------------
                                   1486 ;	 function owned_usage_key
                                   1487 ;	-----------------------------------------
      007EE2                       1488 _owned_usage_key:
      007EE2 E5 82            [12] 1489 	mov	a,dpl
      007EE4 90 0A 9B         [24] 1490 	mov	dptr,#_owned_usage_key_code_10000_374
      007EE7 F0               [24] 1491 	movx	@dptr,a
                                   1492 ;	quantum/action_util.c:167: uint8_t which = code >= KC_AUDIO_MUTE;
      007EE8 E0               [24] 1493 	movx	a,@dptr
      007EE9 FF               [12] 1494 	mov	r7,a
      007EEA BF A8 00         [24] 1495 	cjne	r7,#0xa8,00244$
      007EED                       1496 00244$:
      007EED B3               [12] 1497 	cpl	c
      007EEE 92 24            [24] 1498 	mov	_owned_usage_key_sloc0_1_0,c
      007EF0 E4               [12] 1499 	clr	a
      007EF1 33               [12] 1500 	rlc	a
      007EF2 FF               [12] 1501 	mov	r7,a
      007EF3 90 0A 9E         [24] 1502 	mov	dptr,#_owned_usage_key_which_10000_375
      007EF6 F0               [24] 1503 	movx	@dptr,a
                                   1504 ;	quantum/action_util.c:168: uint8_t base = which ? SYSTEM_COUNT : 0;
      007EF7 EF               [12] 1505 	mov	a,r7
      007EF8 60 02            [24] 1506 	jz	00129$
      007EFA 74 03            [12] 1507 	mov	a,#0x03
      007EFC                       1508 00129$:
      007EFC FE               [12] 1509 	mov	r6,a
                                   1510 ;	quantum/action_util.c:169: uint8_t count = usage_lengths[which];
      007EFD EF               [12] 1511 	mov	a,r7
      007EFE 24 94            [12] 1512 	add	a, #_usage_lengths
      007F00 FD               [12] 1513 	mov	r5,a
      007F01 E4               [12] 1514 	clr	a
      007F02 34 0A            [12] 1515 	addc	a, #(_usage_lengths >> 8)
      007F04 FF               [12] 1516 	mov	r7,a
      007F05 12 81 4F         [24] 1517 	lcall	_ak820_outline_0191
      007F08 E0               [24] 1518 	movx	a,@dptr
      007F09 FC               [12] 1519 	mov	r4,a
                                   1520 ;	quantum/action_util.c:170: uint8_t index = code - KC_SYSTEM_POWER;
      007F0A 90 0A 9B         [24] 1521 	mov	dptr,#_owned_usage_key_code_10000_374
      007F0D E0               [24] 1522 	movx	a,@dptr
      007F0E 24 5B            [12] 1523 	add	a,#0x5b
      007F10 FB               [12] 1524 	mov	r3,a
                                   1525 ;	quantum/action_util.c:171: if (!ak820_macro_change(macro_usages, index, pressed)) return;
      007F11 90 0A 9A         [24] 1526 	mov	dptr,#_owned_usage_key_PARM_2
      007F14 E0               [24] 1527 	movx	a,@dptr
      007F15 FA               [12] 1528 	mov	r2,a
      007F16 90 09 8F         [24] 1529 	mov	dptr,#_ak820_macro_change_PARM_2
      007F19 EB               [12] 1530 	mov	a,r3
      007F1A F0               [24] 1531 	movx	@dptr,a
      007F1B 90 09 90         [24] 1532 	mov	dptr,#_ak820_macro_change_PARM_3
      007F1E EA               [12] 1533 	mov	a,r2
      007F1F F0               [24] 1534 	movx	@dptr,a
      007F20 90 0A 96         [24] 1535 	mov	dptr,#_macro_usages
      007F23 C0 07            [24] 1536 	push	ar7
      007F25 C0 06            [24] 1537 	push	ar6
      007F27 C0 05            [24] 1538 	push	ar5
      007F29 C0 04            [24] 1539 	push	ar4
      007F2B C0 03            [24] 1540 	push	ar3
      007F2D C0 02            [24] 1541 	push	ar2
      007F2F 12 7B B7         [24] 1542 	lcall	_ak820_macro_change
      007F32 E5 82            [12] 1543 	mov	a, dpl
      007F34 D0 02            [24] 1544 	pop	ar2
      007F36 D0 03            [24] 1545 	pop	ar3
      007F38 D0 04            [24] 1546 	pop	ar4
      007F3A D0 05            [24] 1547 	pop	ar5
      007F3C D0 06            [24] 1548 	pop	ar6
      007F3E D0 07            [24] 1549 	pop	ar7
      007F40 70 01            [24] 1550 	jnz	00102$
      007F42 22               [24] 1551 	ret
      007F43                       1552 00102$:
                                   1553 ;	quantum/action_util.c:172: if (pressed) {
      007F43 EA               [12] 1554 	mov	a,r2
      007F44 60 1B            [24] 1555 	jz	00115$
                                   1556 ;	quantum/action_util.c:173: if (usage_refs[index]++) return;
      007F46 12 81 1D         [24] 1557 	lcall	_ak820_outline_0075
      007F49 04               [12] 1558 	inc	a
      007F4A 12 6C 37         [24] 1559 	lcall	_ak820_outline_0141
      007F4D E8               [12] 1560 	mov	a,r0
      007F4E 60 01            [24] 1561 	jz	00104$
      007F50 22               [24] 1562 	ret
      007F51                       1563 00104$:
                                   1564 ;	quantum/action_util.c:174: usage_order[base + count++] = index;
      007F51 90 0A 9F         [24] 1565 	mov	dptr,#_owned_usage_key_count_10000_375
      007F54 EC               [12] 1566 	mov	a,r4
      007F55 04               [12] 1567 	inc	a
      007F56 F0               [24] 1568 	movx	@dptr,a
      007F57 EC               [12] 1569 	mov	a,r4
      007F58 2E               [12] 1570 	add	a, r6
      007F59 12 81 13         [24] 1571 	lcall	_ak820_outline_0068
      007F5C EB               [12] 1572 	mov	a,r3
      007F5D F0               [24] 1573 	movx	@dptr,a
      007F5E 02 7F C2         [24] 1574 	ljmp	00116$
      007F61                       1575 00115$:
                                   1576 ;	quantum/action_util.c:176: if (!usage_refs[index] || --usage_refs[index]) return;
      007F61 12 81 1D         [24] 1577 	lcall	_ak820_outline_0075
      007F64 60 07            [24] 1578 	jz	00105$
      007F66 18               [12] 1579 	dec	r0
      007F67 12 81 0C         [24] 1580 	lcall	_ak820_outline_0064
      007F6A E8               [12] 1581 	mov	a,r0
      007F6B 60 01            [24] 1582 	jz	00106$
      007F6D                       1583 00105$:
      007F6D 22               [24] 1584 	ret
      007F6E                       1585 00106$:
                                   1586 ;	quantum/action_util.c:178: while (usage_order[base + pos] != index) ++pos;
      007F6E 7A 00            [12] 1587 	mov	r2,#0x00
      007F70                       1588 00108$:
      007F70 EA               [12] 1589 	mov	a,r2
      007F71 2E               [12] 1590 	add	a, r6
      007F72 12 81 13         [24] 1591 	lcall	_ak820_outline_0068
      007F75 E0               [24] 1592 	movx	a,@dptr
      007F76 B5 03 02         [24] 1593 	cjne	a,ar3,00251$
      007F79 80 03            [24] 1594 	sjmp	00167$
      007F7B                       1595 00251$:
      007F7B 0A               [12] 1596 	inc	r2
      007F7C 80 F2            [24] 1597 	sjmp	00108$
      007F7E                       1598 00167$:
      007F7E 90 0A A0         [24] 1599 	mov	dptr,#_owned_usage_key_pos_30001_382
      007F81 EA               [12] 1600 	mov	a,r2
      007F82 F0               [24] 1601 	movx	@dptr,a
                                   1602 ;	quantum/action_util.c:179: --count;
      007F83 1C               [12] 1603 	dec	r4
      007F84 90 0A 9F         [24] 1604 	mov	dptr,#_owned_usage_key_count_10000_375
      007F87 EC               [12] 1605 	mov	a,r4
      007F88 F0               [24] 1606 	movx	@dptr,a
                                   1607 ;	quantum/action_util.c:180: for (uint8_t i = pos; i < count; ++i) usage_order[base + i] = usage_order[base + i + 1];
      007F89 8A 03            [24] 1608 	mov	ar3,r2
      007F8B                       1609 00125$:
      007F8B C3               [12] 1610 	clr	c
      007F8C EB               [12] 1611 	mov	a,r3
      007F8D 9C               [12] 1612 	subb	a,r4
      007F8E 50 23            [24] 1613 	jnc	00111$
      007F90 C0 05            [24] 1614 	push	ar5
      007F92 C0 07            [24] 1615 	push	ar7
      007F94 EB               [12] 1616 	mov	a,r3
      007F95 2E               [12] 1617 	add	a, r6
      007F96 FA               [12] 1618 	mov	r2,a
      007F97 24 76            [12] 1619 	add	a, #_usage_order
      007F99 F8               [12] 1620 	mov	r0,a
      007F9A E4               [12] 1621 	clr	a
      007F9B 34 0A            [12] 1622 	addc	a, #(_usage_order >> 8)
      007F9D F9               [12] 1623 	mov	r1,a
      007F9E 0A               [12] 1624 	inc	r2
      007F9F EA               [12] 1625 	mov	a,r2
      007FA0 33               [12] 1626 	rlc	a
      007FA1 95 E0            [12] 1627 	subb	a,acc
      007FA3 FF               [12] 1628 	mov	r7,a
      007FA4 EA               [12] 1629 	mov	a,r2
      007FA5 12 81 39         [24] 1630 	lcall	_ak820_outline_0127
      007FA8 12 38 B6         [24] 1631 	lcall	_ak820_outline_0160
      007FAB F0               [24] 1632 	movx	@dptr,a
      007FAC 0B               [12] 1633 	inc	r3
      007FAD D0 07            [24] 1634 	pop	ar7
      007FAF D0 05            [24] 1635 	pop	ar5
      007FB1 80 D8            [24] 1636 	sjmp	00125$
      007FB3                       1637 00111$:
                                   1638 ;	quantum/action_util.c:181: usage_lengths[which] = count;
      007FB3 12 81 4F         [24] 1639 	lcall	_ak820_outline_0191
      007FB6 EC               [12] 1640 	mov	a,r4
      007FB7 F0               [24] 1641 	movx	@dptr,a
                                   1642 ;	quantum/action_util.c:182: if (pos != count) return; /* A non-winning owner changed only storage. */
      007FB8 90 0A A0         [24] 1643 	mov	dptr,#_owned_usage_key_pos_30001_382
      007FBB E0               [24] 1644 	movx	a,@dptr
      007FBC B5 04 02         [24] 1645 	cjne	a,ar4,00253$
      007FBF 80 01            [24] 1646 	sjmp	00116$
      007FC1                       1647 00253$:
      007FC1 22               [24] 1648 	ret
      007FC2                       1649 00116$:
                                   1650 ;	quantum/action_util.c:184: usage_lengths[which] = count;
      007FC2 90 0A 9F         [24] 1651 	mov	dptr,#_owned_usage_key_count_10000_375
      007FC5 E0               [24] 1652 	movx	a,@dptr
      007FC6 FC               [12] 1653 	mov	r4,a
      007FC7 12 81 4F         [24] 1654 	lcall	_ak820_outline_0191
      007FCA F0               [24] 1655 	movx	@dptr,a
                                   1656 ;	quantum/action_util.c:185: code = count ? usage_order[base + count - 1] + KC_SYSTEM_POWER : 0;
      007FCB EC               [12] 1657 	mov	a,r4
      007FCC 60 15            [24] 1658 	jz	00131$
      007FCE EC               [12] 1659 	mov	a,r4
      007FCF 2E               [12] 1660 	add	a, r6
      007FD0 FE               [12] 1661 	mov	r6,a
      007FD1 1E               [12] 1662 	dec	r6
      007FD2 EE               [12] 1663 	mov	a,r6
      007FD3 33               [12] 1664 	rlc	a
      007FD4 95 E0            [12] 1665 	subb	a,acc
      007FD6 FF               [12] 1666 	mov	r7,a
      007FD7 EE               [12] 1667 	mov	a,r6
      007FD8 12 81 39         [24] 1668 	lcall	_ak820_outline_0127
      007FDB 24 A5            [12] 1669 	add	a,#0xa5
      007FDD FE               [12] 1670 	mov	r6,a
      007FDE 33               [12] 1671 	rlc	a
      007FDF 95 E0            [12] 1672 	subb	a,acc
      007FE1 80 02            [24] 1673 	sjmp	00132$
      007FE3                       1674 00131$:
      007FE3 7E 00            [12] 1675 	mov	r6,#0x00
      007FE5                       1676 00132$:
      007FE5 90 0A 9B         [24] 1677 	mov	dptr,#_owned_usage_key_code_10000_374
      007FE8 EE               [12] 1678 	mov	a,r6
      007FE9 F0               [24] 1679 	movx	@dptr,a
                                   1680 ;	quantum/action_util.c:186: if (which) host_consumer_send(code ? KEYCODE2CONSUMER(code) : 0);
      007FEA 90 0A 9E         [24] 1681 	mov	dptr,#_owned_usage_key_which_10000_375
      007FED E0               [24] 1682 	movx	a,@dptr
      007FEE 60 18            [24] 1683 	jz	00118$
      007FF0 EE               [12] 1684 	mov	a,r6
      007FF1 60 0B            [24] 1685 	jz	00133$
      007FF3 8E 82            [24] 1686 	mov	dpl, r6
      007FF5 12 6D 77         [24] 1687 	lcall	_KEYCODE2CONSUMER
      007FF8 AD 82            [24] 1688 	mov	r5, dpl
      007FFA AF 83            [24] 1689 	mov	r7, dph
      007FFC 80 04            [24] 1690 	sjmp	00134$
      007FFE                       1691 00133$:
      007FFE 7D 00            [12] 1692 	mov	r5,#0x00
      008000 7F 00            [12] 1693 	mov	r7,#0x00
      008002                       1694 00134$:
      008002 12 81 4F         [24] 1695 	lcall	_ak820_outline_0191
      008005 02 6D 2A         [24] 1696 	ljmp	_host_consumer_send
      008008                       1697 00118$:
                                   1698 ;	quantum/action_util.c:187: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      008008 EE               [12] 1699 	mov	a,r6
      008009 60 22            [24] 1700 	jz	00135$
                                   1701 ;	tmk_core/protocol/report.h:264: if (key < KC_SYSTEM_POWER || key > KC_SYSTEM_WAKE) return 0;
      00800B BE A5 00         [24] 1702 	cjne	r6,#0xa5,00258$
      00800E                       1703 00258$:
      00800E 40 05            [24] 1704 	jc	00121$
      008010 EE               [12] 1705 	mov	a,r6
      008011 24 58            [12] 1706 	add	a,#0xff - 0xa7
      008013 50 08            [24] 1707 	jnc	00122$
                                   1708 ;	free result
      008015                       1709 00121$:
      008015 90 0A 9C         [24] 1710 	mov	dptr,#_owned_usage_key___200000085_20000_375
      008018 12 4F 53         [24] 1711 	lcall	_ak820_outline_0184
      00801B 80 09            [24] 1712 	sjmp	00123$
      00801D                       1713 00122$:
                                   1714 ;	tmk_core/protocol/report.h:265: return SYSTEM_POWER_DOWN + (key - KC_SYSTEM_POWER);
      00801D 74 DC            [12] 1715 	mov	a,#0xdc
      00801F 2E               [12] 1716 	add	a, r6
      008020 90 0A 9C         [24] 1717 	mov	dptr,#_owned_usage_key___200000085_20000_375
      008023 12 38 A1         [24] 1718 	lcall	_ak820_outline_0137
                                   1719 ;	quantum/action_util.c:187: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      008026                       1720 00123$:
      008026 90 0A 9C         [24] 1721 	mov	dptr,#_owned_usage_key___200000085_20000_375
      008029 E0               [24] 1722 	movx	a,@dptr
      00802A FF               [12] 1723 	mov	r7,a
      00802B 80 02            [24] 1724 	sjmp	00136$
      00802D                       1725 00135$:
      00802D 7F 00            [12] 1726 	mov	r7,#0x00
      00802F                       1727 00136$:
      00802F 7E 00            [12] 1728 	mov	r6,#0x00
      008031 12 43 6D         [24] 1729 	lcall	_ak820_outline_0161
                                   1730 ;	quantum/action_util.c:188: }
      008034 02 6C FA         [24] 1731 	ljmp	_host_system_send
                                   1732 ;------------------------------------------------------------
                                   1733 ;Allocation info for local variables in function 'send_keyboard_report'
                                   1734 ;------------------------------------------------------------
                                   1735 ;last_report   Allocated with name '_send_keyboard_report_last_report_10001_395'
                                   1736 ;changed       Allocated with name '_send_keyboard_report_changed_10001_395'
                                   1737 ;dest          Allocated with name '_send_keyboard_report_dest_10001_395'
                                   1738 ;src           Allocated with name '_send_keyboard_report_src_10001_395'
                                   1739 ;i             Allocated with name '_send_keyboard_report_i_20001_396'
                                   1740 ;------------------------------------------------------------
                                   1741 ;	quantum/action_util.c:410: void send_keyboard_report(void) {
                                   1742 ;	-----------------------------------------
                                   1743 ;	 function send_keyboard_report
                                   1744 ;	-----------------------------------------
      008037                       1745 _send_keyboard_report:
                                   1746 ;	quantum/action_util.c:411: keyboard_report->mods = real_mods;
      008037 90 0D CA         [24] 1747 	mov	dptr,#_real_mods
      00803A E0               [24] 1748 	movx	a,@dptr
      00803B FF               [12] 1749 	mov	r7,a
      00803C 90 0D CC         [24] 1750 	mov	dptr,#_actual_keyboard_report
      00803F F0               [24] 1751 	movx	@dptr,a
                                   1752 ;	quantum/action_util.c:412: keyboard_report->mods |= weak_mods;
      008040 90 0D CB         [24] 1753 	mov	dptr,#_weak_mods
      008043 E0               [24] 1754 	movx	a,@dptr
      008044 42 07            [12] 1755 	orl	ar7,a
      008046 90 0D CC         [24] 1756 	mov	dptr,#_actual_keyboard_report
      008049 EF               [12] 1757 	mov	a,r7
      00804A F0               [24] 1758 	movx	@dptr,a
                                   1759 ;	quantum/action_util.c:414: keyboard_report->mods |= owned_mods | owned_weak_mods;
      00804B 90 09 8A         [24] 1760 	mov	dptr,#_owned_weak_mods
      00804E E0               [24] 1761 	movx	a,@dptr
      00804F FE               [12] 1762 	mov	r6,a
      008050 90 09 89         [24] 1763 	mov	dptr,#_owned_mods
      008053 E0               [24] 1764 	movx	a,@dptr
      008054 4E               [12] 1765 	orl	a,r6
      008055 42 07            [12] 1766 	orl	ar7,a
      008057 90 0D CC         [24] 1767 	mov	dptr,#_actual_keyboard_report
      00805A EF               [12] 1768 	mov	a,r7
      00805B F0               [24] 1769 	movx	@dptr,a
                                   1770 ;	quantum/action_util.c:444: if (gui_disabled) keyboard_report->mods &= ~(MOD_BIT(KC_LGUI) | MOD_BIT(KC_RGUI));
      00805C 30 20 07         [24] 1771 	jnb	_gui_disabled,00102$
      00805F 90 0D CC         [24] 1772 	mov	dptr,#_actual_keyboard_report
      008062 E0               [24] 1773 	movx	a,@dptr
      008063 54 77            [12] 1774 	anl	a,#0x77
      008065 F0               [24] 1775 	movx	@dptr,a
      008066                       1776 00102$:
                                   1777 ;	quantum/action_util.c:455: bool changed = false;
      008066 90 0A C2         [24] 1778 	mov	dptr,#_send_keyboard_report_changed_10001_395
      008069 E4               [12] 1779 	clr	a
      00806A F0               [24] 1780 	movx	@dptr,a
                                   1781 ;	quantum/action_util.c:457: uint8_t __xdata *dest = (uint8_t __xdata *)&last_report;
                                   1782 ;	quantum/action_util.c:458: const uint8_t __xdata *src = (const uint8_t __xdata *)keyboard_report;
                                   1783 ;	quantum/action_util.c:463: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      00806B FF               [12] 1784 	mov	r7,a
      00806C                       1785 00109$:
      00806C BF 20 00         [24] 1786 	cjne	r7,#0x20,00150$
      00806F                       1787 00150$:
      00806F 50 2A            [24] 1788 	jnc	00105$
                                   1789 ;	quantum/action_util.c:464: if (dest[i] != src[i]) {
      008071 EF               [12] 1790 	mov	a,r7
      008072 24 A2            [12] 1791 	add	a, #_send_keyboard_report_last_report_10001_395
      008074 FD               [12] 1792 	mov	r5,a
      008075 E4               [12] 1793 	clr	a
      008076 34 0A            [12] 1794 	addc	a, #(_send_keyboard_report_last_report_10001_395 >> 8)
      008078 12 48 8B         [24] 1795 	lcall	_ak820_outline_0057
      00807B EF               [12] 1796 	mov	a,r7
      00807C 24 CC            [12] 1797 	add	a, #_actual_keyboard_report
      00807E F5 82            [12] 1798 	mov	dpl,a
      008080 E4               [12] 1799 	clr	a
      008081 34 0D            [12] 1800 	addc	a, #(_actual_keyboard_report >> 8)
      008083 F5 83            [12] 1801 	mov	dph,a
      008085 E0               [24] 1802 	movx	a,@dptr
      008086 FB               [12] 1803 	mov	r3,a
      008087 EC               [12] 1804 	mov	a,r4
      008088 B5 03 02         [24] 1805 	cjne	a,ar3,00152$
      00808B 80 0B            [24] 1806 	sjmp	00110$
      00808D                       1807 00152$:
                                   1808 ;	quantum/action_util.c:465: dest[i] = src[i];
      00808D 12 38 9C         [24] 1809 	lcall	_ak820_outline_0135
      008090 EB               [12] 1810 	mov	a,r3
      008091 F0               [24] 1811 	movx	@dptr,a
                                   1812 ;	quantum/action_util.c:466: changed = true;
      008092 90 0A C2         [24] 1813 	mov	dptr,#_send_keyboard_report_changed_10001_395
      008095 74 01            [12] 1814 	mov	a,#0x01
      008097 F0               [24] 1815 	movx	@dptr,a
      008098                       1816 00110$:
                                   1817 ;	quantum/action_util.c:463: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      008098 0F               [12] 1818 	inc	r7
      008099 80 D1            [24] 1819 	sjmp	00109$
      00809B                       1820 00105$:
                                   1821 ;	quantum/action_util.c:469: if (changed) host_keyboard_send(keyboard_report);
      00809B 90 0A C2         [24] 1822 	mov	dptr,#_send_keyboard_report_changed_10001_395
      00809E E0               [24] 1823 	movx	a,@dptr
      00809F 60 09            [24] 1824 	jz	00111$
      0080A1 90 0D CC         [24] 1825 	mov	dptr,#_actual_keyboard_report
      0080A4 75 F0 00         [24] 1826 	mov	b, #0x00
                                   1827 ;	quantum/action_util.c:477: }
      0080A7 02 6C 6F         [24] 1828 	ljmp	_host_keyboard_send
      0080AA                       1829 00111$:
      0080AA 22               [24] 1830 	ret
                                   1831 ;------------------------------------------------------------
                                   1832 ;Allocation info for local variables in function 'get_mods'
                                   1833 ;------------------------------------------------------------
                                   1834 ;	quantum/action_util.c:483: uint8_t get_mods(void) {
                                   1835 ;	-----------------------------------------
                                   1836 ;	 function get_mods
                                   1837 ;	-----------------------------------------
      0080AB                       1838 _get_mods:
      0080AB C0 07            [24] 1839 	push	ar7
                                   1840 ;	quantum/action_util.c:488: ;
      0080AD 90 09 89         [24] 1841 	mov	dptr,#_owned_mods
      0080B0 E0               [24] 1842 	movx	a,@dptr
      0080B1 FF               [12] 1843 	mov	r7,a
      0080B2 90 0D CA         [24] 1844 	mov	dptr,#_real_mods
      0080B5 12 7B 53         [24] 1845 	lcall	_ak820_outline_0143
                                   1846 ;	quantum/action_util.c:489: }
      0080B8 D0 07            [24] 1847 	pop	ar7
      0080BA 22               [24] 1848 	ret
                                   1849 ;------------------------------------------------------------
                                   1850 ;Allocation info for local variables in function 'add_mods'
                                   1851 ;------------------------------------------------------------
                                   1852 ;mods          Allocated with name '_add_mods_mods_10000_403'
                                   1853 ;------------------------------------------------------------
                                   1854 ;	quantum/action_util.c:494: void add_mods(uint8_t mods) {
                                   1855 ;	-----------------------------------------
                                   1856 ;	 function clear_mods
                                   1857 ;	-----------------------------------------
      0080BB                       1858 _clear_mods:
                                   1859 ;	quantum/action_util.c:516: real_mods = 0;
      0080BB 90 0D CA         [24] 1860 	mov	dptr,#_real_mods
      0080BE E4               [12] 1861 	clr	a
      0080BF F0               [24] 1862 	movx	@dptr,a
                                   1863 ;	quantum/action_util.c:517: }
      0080C0 22               [24] 1864 	ret
                                   1865 ;------------------------------------------------------------
                                   1866 ;Allocation info for local variables in function 'get_weak_mods'
                                   1867 ;------------------------------------------------------------
                                   1868 ;	quantum/action_util.c:523: uint8_t get_weak_mods(void) {
                                   1869 ;	-----------------------------------------
                                   1870 ;	 function get_weak_mods
                                   1871 ;	-----------------------------------------
      0080C1                       1872 _get_weak_mods:
      0080C1 C0 07            [24] 1873 	push	ar7
                                   1874 ;	quantum/action_util.c:528: ;
      0080C3 90 09 8A         [24] 1875 	mov	dptr,#_owned_weak_mods
      0080C6 E0               [24] 1876 	movx	a,@dptr
      0080C7 FF               [12] 1877 	mov	r7,a
      0080C8 90 0D CB         [24] 1878 	mov	dptr,#_weak_mods
      0080CB 12 7B 53         [24] 1879 	lcall	_ak820_outline_0143
                                   1880 ;	quantum/action_util.c:529: }
      0080CE D0 07            [24] 1881 	pop	ar7
      0080D0 22               [24] 1882 	ret
                                   1883 ;------------------------------------------------------------
                                   1884 ;Allocation info for local variables in function 'add_weak_mods'
                                   1885 ;------------------------------------------------------------
                                   1886 ;mods          Allocated with name '_add_weak_mods_mods_10000_413'
                                   1887 ;------------------------------------------------------------
                                   1888 ;	quantum/action_util.c:534: void add_weak_mods(uint8_t mods) {
                                   1889 ;	-----------------------------------------
                                   1890 ;	 function add_weak_mods
                                   1891 ;	-----------------------------------------
      0080D1                       1892 _add_weak_mods:
      0080D1 E5 82            [12] 1893 	mov	a,dpl
      0080D3 90 0A C3         [24] 1894 	mov	dptr,#_add_weak_mods_mods_10000_413
      0080D6 F0               [24] 1895 	movx	@dptr,a
                                   1896 ;	quantum/action_util.c:535: weak_mods |= mods;
      0080D7 E0               [24] 1897 	movx	a,@dptr
      0080D8 FF               [12] 1898 	mov	r7,a
      0080D9 90 0D CB         [24] 1899 	mov	dptr,#_weak_mods
      0080DC E0               [24] 1900 	movx	a,@dptr
      0080DD 4F               [12] 1901 	orl	a,r7
      0080DE F0               [24] 1902 	movx	@dptr,a
                                   1903 ;	quantum/action_util.c:536: }
      0080DF 22               [24] 1904 	ret
                                   1905 ;------------------------------------------------------------
                                   1906 ;Allocation info for local variables in function 'del_weak_mods'
                                   1907 ;------------------------------------------------------------
                                   1908 ;mods          Allocated with name '_del_weak_mods_mods_10000_415'
                                   1909 ;------------------------------------------------------------
                                   1910 ;	quantum/action_util.c:541: void del_weak_mods(uint8_t mods) {
                                   1911 ;	-----------------------------------------
                                   1912 ;	 function del_weak_mods
                                   1913 ;	-----------------------------------------
      0080E0                       1914 _del_weak_mods:
      0080E0 E5 82            [12] 1915 	mov	a,dpl
      0080E2 90 0A C4         [24] 1916 	mov	dptr,#_del_weak_mods_mods_10000_415
      0080E5 F0               [24] 1917 	movx	@dptr,a
                                   1918 ;	quantum/action_util.c:542: weak_mods &= ~mods;
      0080E6 E0               [24] 1919 	movx	a,@dptr
      0080E7 F4               [12] 1920 	cpl	a
      0080E8 FF               [12] 1921 	mov	r7,a
      0080E9 90 0D CB         [24] 1922 	mov	dptr,#_weak_mods
      0080EC E0               [24] 1923 	movx	a,@dptr
      0080ED 5F               [12] 1924 	anl	a,r7
      0080EE F0               [24] 1925 	movx	@dptr,a
                                   1926 ;	quantum/action_util.c:543: }
      0080EF 22               [24] 1927 	ret
                                   1928 ;------------------------------------------------------------
                                   1929 ;Allocation info for local variables in function 'set_weak_mods'
                                   1930 ;------------------------------------------------------------
                                   1931 ;mods          Allocated with name '_set_weak_mods_mods_10000_417'
                                   1932 ;------------------------------------------------------------
                                   1933 ;	quantum/action_util.c:548: void set_weak_mods(uint8_t mods) {
                                   1934 ;	-----------------------------------------
                                   1935 ;	 function clear_weak_mods
                                   1936 ;	-----------------------------------------
      0080F0                       1937 _clear_weak_mods:
                                   1938 ;	quantum/action_util.c:556: weak_mods = 0;
      0080F0 90 0D CB         [24] 1939 	mov	dptr,#_weak_mods
      0080F3 E4               [12] 1940 	clr	a
      0080F4 F0               [24] 1941 	movx	@dptr,a
                                   1942 ;	quantum/action_util.c:557: }
      0080F5 22               [24] 1943 	ret
                                   1944 ;------------------------------------------------------------
                                   1945 ;Allocation info for local variables in function 'oneshot_locked_mods_changed_user'
                                   1946 ;------------------------------------------------------------
                                   1947 ;mods          Allocated with name '_oneshot_locked_mods_changed_user_mods_10000_421'
                                   1948 ;------------------------------------------------------------
                                   1949 ;	quantum/action_util.c:639: __attribute__((weak)) void oneshot_locked_mods_changed_user(uint8_t mods) {}
                                   1950 ;	-----------------------------------------
                                   1951 	.area CSEG    (CODE)
                                   1952 	.area CONST   (CODE)
                                   1953 	.area XINIT   (CODE)
      00C16B                       1954 __xinit__real_mods:
      00C16B 00                    1955 	.db #0x00	; 0
      00C16C                       1956 __xinit__weak_mods:
      00C16C 00                    1957 	.db #0x00	; 0
      00C16D                       1958 __xinit__actual_keyboard_report:
      00C16D 00                    1959 	.db #0x00	; 0
      00C16E 00                    1960 	.db #0x00	; 0
      00C16F 00                    1961 	.db #0x00	; 0
      00C170 00                    1962 	.db #0x00	; 0
      00C171 00                    1963 	.db #0x00	; 0
      00C172 00                    1964 	.db #0x00	; 0
      00C173 00                    1965 	.db #0x00	; 0
      00C174 00                    1966 	.db #0x00	; 0
      00C175 00                    1967 	.db 0x00
      00C176 00                    1968 	.db 0x00
      00C177 00                    1969 	.db 0x00
      00C178 00                    1970 	.db 0x00
      00C179 00                    1971 	.db 0x00
      00C17A 00                    1972 	.db 0x00
      00C17B 00                    1973 	.db 0x00
      00C17C 00                    1974 	.db 0x00
      00C17D 00                    1975 	.db 0x00
      00C17E 00                    1976 	.db 0x00
      00C17F 00                    1977 	.db 0x00
      00C180 00                    1978 	.db 0x00
      00C181 00                    1979 	.db 0x00
      00C182 00                    1980 	.db 0x00
      00C183 00                    1981 	.db 0x00
      00C184 00                    1982 	.db 0x00
      00C185 00                    1983 	.db 0x00
      00C186 00                    1984 	.db 0x00
      00C187 00                    1985 	.db 0x00
      00C188 00                    1986 	.db 0x00
      00C189 00                    1987 	.db 0x00
      00C18A 00                    1988 	.db 0x00
      00C18B 00                    1989 	.db 0x00
      00C18C 00                    1990 	.db 0x00
                                   1991 	.area CABS    (ABS,CODE)
                                   1992 
                                   1993 ; Experimental exact instruction outlining.
                                   1994 	.globl _ak820_outline_0017
                                   1995 	.globl _ak820_outline_0030
                                   1996 	.globl _ak820_outline_0052
                                   1997 	.globl _ak820_outline_0057
                                   1998 	.globl _ak820_outline_0058
                                   1999 	.globl _ak820_outline_0061
                                   2000 	.globl _ak820_outline_0063
                                   2001 	.globl _ak820_outline_0064
                                   2002 	.globl _ak820_outline_0065
                                   2003 	.globl _ak820_outline_0068
                                   2004 	.globl _ak820_outline_0075
                                   2005 	.globl _ak820_outline_0109
                                   2006 	.globl _ak820_outline_0110
                                   2007 	.globl _ak820_outline_0119
                                   2008 	.globl _ak820_outline_0123
                                   2009 	.globl _ak820_outline_0125
                                   2010 	.globl _ak820_outline_0127
                                   2011 	.globl _ak820_outline_0134
                                   2012 	.globl _ak820_outline_0135
                                   2013 	.globl _ak820_outline_0137
                                   2014 	.globl _ak820_outline_0141
                                   2015 	.globl _ak820_outline_0143
                                   2016 	.globl _ak820_outline_0160
                                   2017 	.globl _ak820_outline_0161
                                   2018 	.globl _ak820_outline_0166
                                   2019 	.globl _ak820_outline_0184
                                   2020 	.globl _ak820_outline_0190
                                   2021 	.globl _ak820_outline_0191
                                   2022 
                                   2023 	.area CSEG (CODE)
                                   2024 ; function ak820_outline_0030
      0080F6                       2025 _ak820_outline_0030:
      0080F6 EF               [12] 2026 	mov	a,r7
      0080F7 24 9B            [12] 2027 	add	a,#_key_refs
      0080F9 FD               [12] 2028 	mov	r5,a
      0080FA E4               [12] 2029 	clr	a
      0080FB 34 09            [12] 2030 	addc	a,#(_key_refs>>8)
      0080FD FE               [12] 2031 	mov	r6,a
      0080FE 8D 82            [24] 2032 	mov	dpl,r5
      008100 8E 83            [24] 2033 	mov	dph,r6
      008102 E0               [24] 2034 	movx	a,@dptr
      008103 22               [24] 2035 	ret
                                   2036 
                                   2037 	.area CSEG (CODE)
                                   2038 ; function ak820_outline_0058
      008104                       2039 _ak820_outline_0058:
      008104 F0               [24] 2040 	movx	@dptr,a
      008105 90 0D CC         [24] 2041 	mov	dptr,#_actual_keyboard_report
      008108 75 F0 00         [24] 2042 	mov	b,#0x00
      00810B 22               [24] 2043 	ret
                                   2044 
                                   2045 	.area CSEG (CODE)
                                   2046 ; function ak820_outline_0064
      00810C                       2047 _ak820_outline_0064:
      00810C 89 82            [24] 2048 	mov	dpl,r1
      00810E 8A 83            [24] 2049 	mov	dph,r2
      008110 E8               [12] 2050 	mov	a,r0
      008111 F0               [24] 2051 	movx	@dptr,a
      008112 22               [24] 2052 	ret
                                   2053 
                                   2054 	.area CSEG (CODE)
                                   2055 ; function ak820_outline_0068
      008113                       2056 _ak820_outline_0068:
      008113 24 76            [12] 2057 	add	a,#_usage_order
      008115 F5 82            [12] 2058 	mov	dpl,a
      008117 E4               [12] 2059 	clr	a
      008118 34 0A            [12] 2060 	addc	a,#(_usage_order>>8)
      00811A F5 83            [12] 2061 	mov	dph,a
      00811C 22               [24] 2062 	ret
                                   2063 
                                   2064 	.area CSEG (CODE)
                                   2065 ; function ak820_outline_0075
      00811D                       2066 _ak820_outline_0075:
      00811D EB               [12] 2067 	mov	a,r3
      00811E 24 58            [12] 2068 	add	a,#_usage_refs
      008120 F9               [12] 2069 	mov	r1,a
      008121 E4               [12] 2070 	clr	a
      008122 34 0A            [12] 2071 	addc	a,#(_usage_refs>>8)
      008124 FA               [12] 2072 	mov	r2,a
      008125 89 82            [24] 2073 	mov	dpl,r1
      008127 8A 83            [24] 2074 	mov	dph,r2
      008129 E0               [24] 2075 	movx	a,@dptr
      00812A F8               [12] 2076 	mov	r0,a
      00812B 22               [24] 2077 	ret
                                   2078 
                                   2079 	.area CSEG (CODE)
                                   2080 ; function ak820_outline_0119
      00812C                       2081 _ak820_outline_0119:
      00812C F0               [24] 2082 	movx	@dptr,a
      00812D E0               [24] 2083 	movx	a,@dptr
      00812E FF               [12] 2084 	mov	r7,a
      00812F 90 09 93         [24] 2085 	mov	dptr,#_change_owned_PARM_2
      008132 22               [24] 2086 	ret
                                   2087 
                                   2088 	.area CSEG (CODE)
                                   2089 ; function ak820_outline_0123
      008133                       2090 _ak820_outline_0123:
      008133 8D 82            [24] 2091 	mov	dpl,r5
      008135 8E 83            [24] 2092 	mov	dph,r6
      008137 F0               [24] 2093 	movx	@dptr,a
      008138 22               [24] 2094 	ret
                                   2095 
                                   2096 	.area CSEG (CODE)
                                   2097 ; function ak820_outline_0127
      008139                       2098 _ak820_outline_0127:
      008139 24 76            [12] 2099 	add	a,#_usage_order
      00813B F5 82            [12] 2100 	mov	dpl,a
      00813D EF               [12] 2101 	mov	a,r7
      00813E 34 0A            [12] 2102 	addc	a,#(_usage_order>>8)
      008140 F5 83            [12] 2103 	mov	dph,a
      008142 E0               [24] 2104 	movx	a,@dptr
      008143 22               [24] 2105 	ret
                                   2106 
                                   2107 	.area CSEG (CODE)
                                   2108 ; function ak820_outline_0134
      008144                       2109 _ak820_outline_0134:
      008144 F0               [24] 2110 	movx	@dptr,a
      008145 E0               [24] 2111 	movx	a,@dptr
      008146 FF               [12] 2112 	mov	r7,a
      008147 90 09 8F         [24] 2113 	mov	dptr,#_ak820_macro_change_PARM_2
      00814A F0               [24] 2114 	movx	@dptr,a
      00814B 90 09 90         [24] 2115 	mov	dptr,#_ak820_macro_change_PARM_3
      00814E 22               [24] 2116 	ret
                                   2117 
                                   2118 	.area CSEG (CODE)
                                   2119 ; function ak820_outline_0191
      00814F                       2120 _ak820_outline_0191:
      00814F 8D 82            [24] 2121 	mov	dpl,r5
      008151 8F 83            [24] 2122 	mov	dph,r7
      008153 22               [24] 2123 	ret
