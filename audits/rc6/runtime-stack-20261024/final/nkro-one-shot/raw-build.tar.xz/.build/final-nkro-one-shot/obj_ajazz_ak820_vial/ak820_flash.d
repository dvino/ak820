ak820_flash.o: keyboards/ajazz/ak820/ak820_flash.c \
 keyboards/ajazz/ak820/config.h \
 .build/final-nkro-one-shot/obj_ajazz_ak820_vial/src/info_config.h \
 keyboards/ajazz/ak820/keymaps/vial/config.h \
 quantum/rgb_matrix/post_config.h lib/ch555/ch555.h \
 keyboards/ajazz/ak820/ak820_nvm.h \
 /workspace/scratch/97c35f9846c1/ak820/toolchains/sdcc-4.6.0/share/sdcc/include/stdbool.h \
 /workspace/scratch/97c35f9846c1/ak820/toolchains/sdcc-4.6.0/share/sdcc/include/stdint.h \
 /workspace/scratch/97c35f9846c1/ak820/toolchains/sdcc-4.6.0/share/sdcc/include/stddef.h
