                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_combo_cancel
                                     12 	.globl _ak820_combo_tick
                                     13 	.globl _ak820_oneshot_cancel
                                     14 	.globl _ak820_oneshot_post
                                     15 	.globl _ak820_oneshot_process
                                     16 	.globl _ak820_tapping_source
                                     17 	.globl _ak820_tapping_cancel
                                     18 	.globl _ak820_tapping_process
                                     19 	.globl _ak820_tapping_before
                                     20 	.globl _pre_process_record_quantum
                                     21 	.globl _get_record_keycode
                                     22 	.globl _repeat_key_cancel
                                     23 	.globl _clear_owned_usages
                                     24 	.globl _owned_usage_key
                                     25 	.globl _clear_owned_keys
                                     26 	.globl _del_owned_key
                                     27 	.globl _add_owned_key
                                     28 	.globl _clear_owned_mods
                                     29 	.globl _del_owned_weak_mods
                                     30 	.globl _add_owned_weak_mods
                                     31 	.globl _del_owned_mods
                                     32 	.globl _add_owned_mods
                                     33 	.globl _clear_weak_mods
                                     34 	.globl _clear_mods
                                     35 	.globl _send_keyboard_report
                                     36 	.globl _layer_hold_clear
                                     37 	.globl _layer_hold_off
                                     38 	.globl _layer_hold_on
                                     39 	.globl _ak820_resolve_key
                                     40 	.globl _layer_xor
                                     41 	.globl _layer_and
                                     42 	.globl _layer_or
                                     43 	.globl _layer_off
                                     44 	.globl _layer_on
                                     45 	.globl _layer_move
                                     46 	.globl _layer_clear
                                     47 	.globl _layer_state_set
                                     48 	.globl _default_layer_xor
                                     49 	.globl _default_layer_and
                                     50 	.globl _default_layer_or
                                     51 	.globl _default_layer_set
                                     52 	.globl _post_process_record_quantum
                                     53 	.globl _process_record_quantum
                                     54 	.globl _action_for_keycode
                                     55 	.globl _mDelaymS
                                     56 	.globl _host_consumer_send
                                     57 	.globl _host_system_send
                                     58 	.globl _host_keyboard_leds
                                     59 	.globl _led_set
                                     60 	.globl _clear_keys_from_report
                                     61 	.globl ___memcpy
                                     62 	.globl _ADC_START
                                     63 	.globl _S0_R_FIFO
                                     64 	.globl _S0_T_FIFO
                                     65 	.globl _S0_FREE
                                     66 	.globl _S0_IF_BYTE
                                     67 	.globl _S0_IF_FIRST
                                     68 	.globl _S0_IF_OV
                                     69 	.globl _S0_FST_ACT
                                     70 	.globl _CP_RL2
                                     71 	.globl _C_T2
                                     72 	.globl _TR2
                                     73 	.globl _EXEN2
                                     74 	.globl _TCLK
                                     75 	.globl _RCLK
                                     76 	.globl _EXF2
                                     77 	.globl _CAP1F
                                     78 	.globl _TF2
                                     79 	.globl _RI
                                     80 	.globl _TI
                                     81 	.globl _RB8
                                     82 	.globl _TB8
                                     83 	.globl _REN
                                     84 	.globl _SM2
                                     85 	.globl _SM1
                                     86 	.globl _SM0
                                     87 	.globl _IT0
                                     88 	.globl _IE0
                                     89 	.globl _IT1
                                     90 	.globl _IE1
                                     91 	.globl _TR0
                                     92 	.globl _TF0
                                     93 	.globl _TR1
                                     94 	.globl _TF1
                                     95 	.globl _P4_0
                                     96 	.globl _P4_1
                                     97 	.globl _P4_2
                                     98 	.globl _P4_3
                                     99 	.globl _P4_4
                                    100 	.globl _P4_5
                                    101 	.globl _P4_6
                                    102 	.globl _RXD
                                    103 	.globl _TXD
                                    104 	.globl _INT0
                                    105 	.globl _INT1
                                    106 	.globl _T0
                                    107 	.globl _T1
                                    108 	.globl _MOSI1
                                    109 	.globl _MISO1
                                    110 	.globl _SCK1
                                    111 	.globl _P3_0
                                    112 	.globl _P3_1
                                    113 	.globl _P3_2
                                    114 	.globl _P3_3
                                    115 	.globl _P3_4
                                    116 	.globl _P3_5
                                    117 	.globl _P3_6
                                    118 	.globl _P3_7
                                    119 	.globl _CAP1_
                                    120 	.globl _T2_
                                    121 	.globl _CAP2_
                                    122 	.globl _T2EX_
                                    123 	.globl _RXD1
                                    124 	.globl _TXD1
                                    125 	.globl _P2_0
                                    126 	.globl _P2_1
                                    127 	.globl _P2_2
                                    128 	.globl _P2_3
                                    129 	.globl _P2_4
                                    130 	.globl _P2_5
                                    131 	.globl _P2_6
                                    132 	.globl _P2_7
                                    133 	.globl _AIN0
                                    134 	.globl _AIN1
                                    135 	.globl _AIN2
                                    136 	.globl _AIN3
                                    137 	.globl _AIN4
                                    138 	.globl _AIN5
                                    139 	.globl _AIN6
                                    140 	.globl _AIN7
                                    141 	.globl _CAP1
                                    142 	.globl _T2
                                    143 	.globl _CAP2
                                    144 	.globl _T2EX
                                    145 	.globl _INT0_
                                    146 	.globl _SCS
                                    147 	.globl _MOSI
                                    148 	.globl _MISO
                                    149 	.globl _SCK
                                    150 	.globl _RXD1_
                                    151 	.globl _TXD1_
                                    152 	.globl _P1_0
                                    153 	.globl _P1_1
                                    154 	.globl _P1_2
                                    155 	.globl _P1_3
                                    156 	.globl _P1_4
                                    157 	.globl _P1_5
                                    158 	.globl _P1_6
                                    159 	.globl _P1_7
                                    160 	.globl _AIN8
                                    161 	.globl _AIN9
                                    162 	.globl _AIN10
                                    163 	.globl _AIN11
                                    164 	.globl _AIN12
                                    165 	.globl _AIN13
                                    166 	.globl _RXD_
                                    167 	.globl _TXD_
                                    168 	.globl _SCL0
                                    169 	.globl _SDA0
                                    170 	.globl _P0_0
                                    171 	.globl _P0_1
                                    172 	.globl _P0_2
                                    173 	.globl _P0_3
                                    174 	.globl _P0_4
                                    175 	.globl _P0_5
                                    176 	.globl _P0_6
                                    177 	.globl _P0_7
                                    178 	.globl _IE_SPI0
                                    179 	.globl _IE_USB
                                    180 	.globl _IE_ADC
                                    181 	.globl _IE_UART1
                                    182 	.globl _IE_PWM_I2C
                                    183 	.globl _IE_GPIO
                                    184 	.globl _IE_WDOG
                                    185 	.globl _PX0
                                    186 	.globl _PT0
                                    187 	.globl _PX1
                                    188 	.globl _PT1
                                    189 	.globl _PS
                                    190 	.globl _PT2
                                    191 	.globl _PL_FLAG
                                    192 	.globl _PH_FLAG
                                    193 	.globl _EX0
                                    194 	.globl _ET0
                                    195 	.globl _EX1
                                    196 	.globl _ET1
                                    197 	.globl _ES
                                    198 	.globl _ET2
                                    199 	.globl _E_DIS
                                    200 	.globl _EA
                                    201 	.globl _P
                                    202 	.globl _F1
                                    203 	.globl _OV
                                    204 	.globl _RS0
                                    205 	.globl _RS1
                                    206 	.globl _F0
                                    207 	.globl _AC
                                    208 	.globl _CY
                                    209 	.globl _I2CS_INT_ST
                                    210 	.globl _I2CX_INT
                                    211 	.globl _LED_STATUS
                                    212 	.globl _LED_DMA_H
                                    213 	.globl _LED_DMA_L
                                    214 	.globl _LED_DMA
                                    215 	.globl _LED_PWM_OE
                                    216 	.globl _LED_COMMON
                                    217 	.globl _ADC_CHAN
                                    218 	.globl _ADC_DAT_H
                                    219 	.globl _ADC_DAT_L
                                    220 	.globl _ADC_DAT
                                    221 	.globl _ADC_CTRL
                                    222 	.globl _SPI1_CK_SE
                                    223 	.globl _SPI1_CTRL
                                    224 	.globl _SPI1_DATA
                                    225 	.globl _SPI1_STAT
                                    226 	.globl _SIF1
                                    227 	.globl _SBAUD1
                                    228 	.globl _SBUF1
                                    229 	.globl _SCON1
                                    230 	.globl _SPI0_SETUP
                                    231 	.globl _SPI0_CK_SE
                                    232 	.globl _SPI0_CTRL
                                    233 	.globl _SPI0_DATA
                                    234 	.globl _SPI0_STAT
                                    235 	.globl _T2CAP1H
                                    236 	.globl _T2CAP1L
                                    237 	.globl _T2CAP1
                                    238 	.globl _TH2
                                    239 	.globl _TL2
                                    240 	.globl _T2COUNT
                                    241 	.globl _RCAP2H
                                    242 	.globl _RCAP2L
                                    243 	.globl _RCAP2
                                    244 	.globl _T2MOD
                                    245 	.globl _T2CON
                                    246 	.globl _SBUF
                                    247 	.globl _SCON
                                    248 	.globl _TH1
                                    249 	.globl _TH0
                                    250 	.globl _TL1
                                    251 	.globl _TL0
                                    252 	.globl _TMOD
                                    253 	.globl _TCON
                                    254 	.globl _XBUS_AUX
                                    255 	.globl _P7
                                    256 	.globl _P6_DIR
                                    257 	.globl _P6_OUT_PU
                                    258 	.globl _P6_IN
                                    259 	.globl _P5_DIR
                                    260 	.globl _P5_OUT_PU
                                    261 	.globl _P5_IN
                                    262 	.globl _P4_LED_KEY
                                    263 	.globl _P4_DIR_PU
                                    264 	.globl _P4_MOD_OC
                                    265 	.globl _P4
                                    266 	.globl _P3_DIR_PU
                                    267 	.globl _P3_MOD_OC
                                    268 	.globl _P3
                                    269 	.globl _P2_DIR_PU
                                    270 	.globl _P2_MOD_OC
                                    271 	.globl _P2
                                    272 	.globl _P1_DIR_PU
                                    273 	.globl _P1_MOD_OC
                                    274 	.globl _P1
                                    275 	.globl _P0_DIR_PU
                                    276 	.globl _P0_MOD_OC
                                    277 	.globl _P0
                                    278 	.globl _ROM_CTRL
                                    279 	.globl _ROM_DATA_HH
                                    280 	.globl _ROM_DATA_HL
                                    281 	.globl _ROM_DATA_HI
                                    282 	.globl _ROM_ADDR_H
                                    283 	.globl _ROM_ADDR_L
                                    284 	.globl _ROM_ADDR
                                    285 	.globl _GPIO_IE
                                    286 	.globl _IP_EX
                                    287 	.globl _IE_EX
                                    288 	.globl _IP
                                    289 	.globl _IE
                                    290 	.globl _WDOG_COUNT
                                    291 	.globl _RESET_KEEP
                                    292 	.globl _WAKE_CTRL
                                    293 	.globl _CLOCK_CFG
                                    294 	.globl _POWER_CFG
                                    295 	.globl _PCON
                                    296 	.globl _GLOBAL_CFG
                                    297 	.globl _SAFE_MOD
                                    298 	.globl _DPH
                                    299 	.globl _DPL
                                    300 	.globl _SP
                                    301 	.globl _A_INV
                                    302 	.globl _B
                                    303 	.globl _ACC
                                    304 	.globl _PSW
                                    305 	.globl _disable_action_cache
                                    306 	.globl _tap_code_delay_PARM_2
                                    307 	.globl _process_action_PARM_2
                                    308 	.globl _action_exec_PARM_1
                                    309 	.globl _tp_buttons
                                    310 	.globl _action_exec
                                    311 	.globl _ak820_action_exec
                                    312 	.globl _process_record
                                    313 	.globl _process_record_handler
                                    314 	.globl _process_action
                                    315 	.globl _register_code
                                    316 	.globl _unregister_code
                                    317 	.globl _tap_code_delay
                                    318 	.globl _tap_code
                                    319 	.globl _register_mods
                                    320 	.globl _unregister_mods
                                    321 	.globl _register_weak_mods
                                    322 	.globl _unregister_weak_mods
                                    323 	.globl _clear_keyboard
                                    324 	.globl _clear_keyboard_but_mods
                                    325 	.globl _clear_keyboard_but_mods_and_keys
                                    326 ;--------------------------------------------------------
                                    327 ; special function registers
                                    328 ;--------------------------------------------------------
                                    329 	.area RSEG    (ABS,DATA)
      000000                        330 	.org 0x0000
                           0000D0   331 _PSW	=	0x00d0
                           0000E0   332 _ACC	=	0x00e0
                           0000F0   333 _B	=	0x00f0
                           0000FD   334 _A_INV	=	0x00fd
                           000081   335 _SP	=	0x0081
                           000082   336 _DPL	=	0x0082
                           000083   337 _DPH	=	0x0083
                           0000A1   338 _SAFE_MOD	=	0x00a1
                           0000B1   339 _GLOBAL_CFG	=	0x00b1
                           000087   340 _PCON	=	0x0087
                           0000BA   341 _POWER_CFG	=	0x00ba
                           0000B9   342 _CLOCK_CFG	=	0x00b9
                           0000A9   343 _WAKE_CTRL	=	0x00a9
                           0000FE   344 _RESET_KEEP	=	0x00fe
                           0000FF   345 _WDOG_COUNT	=	0x00ff
                           0000A8   346 _IE	=	0x00a8
                           0000B8   347 _IP	=	0x00b8
                           0000E8   348 _IE_EX	=	0x00e8
                           0000E9   349 _IP_EX	=	0x00e9
                           0000B2   350 _GPIO_IE	=	0x00b2
                           008584   351 _ROM_ADDR	=	0x8584
                           000084   352 _ROM_ADDR_L	=	0x0084
                           000085   353 _ROM_ADDR_H	=	0x0085
                           008F8E   354 _ROM_DATA_HI	=	0x8f8e
                           00008E   355 _ROM_DATA_HL	=	0x008e
                           00008F   356 _ROM_DATA_HH	=	0x008f
                           000086   357 _ROM_CTRL	=	0x0086
                           000080   358 _P0	=	0x0080
                           0000C4   359 _P0_MOD_OC	=	0x00c4
                           0000C5   360 _P0_DIR_PU	=	0x00c5
                           000090   361 _P1	=	0x0090
                           000092   362 _P1_MOD_OC	=	0x0092
                           000093   363 _P1_DIR_PU	=	0x0093
                           0000A0   364 _P2	=	0x00a0
                           000094   365 _P2_MOD_OC	=	0x0094
                           000095   366 _P2_DIR_PU	=	0x0095
                           0000B0   367 _P3	=	0x00b0
                           000096   368 _P3_MOD_OC	=	0x0096
                           000097   369 _P3_DIR_PU	=	0x0097
                           0000C0   370 _P4	=	0x00c0
                           0000C2   371 _P4_MOD_OC	=	0x00c2
                           0000C3   372 _P4_DIR_PU	=	0x00c3
                           0000C1   373 _P4_LED_KEY	=	0x00c1
                           0000AA   374 _P5_IN	=	0x00aa
                           0000AB   375 _P5_OUT_PU	=	0x00ab
                           0000AC   376 _P5_DIR	=	0x00ac
                           0000AD   377 _P6_IN	=	0x00ad
                           0000AE   378 _P6_OUT_PU	=	0x00ae
                           0000AF   379 _P6_DIR	=	0x00af
                           0000F1   380 _P7	=	0x00f1
                           0000A2   381 _XBUS_AUX	=	0x00a2
                           000088   382 _TCON	=	0x0088
                           000089   383 _TMOD	=	0x0089
                           00008A   384 _TL0	=	0x008a
                           00008B   385 _TL1	=	0x008b
                           00008C   386 _TH0	=	0x008c
                           00008D   387 _TH1	=	0x008d
                           000098   388 _SCON	=	0x0098
                           000099   389 _SBUF	=	0x0099
                           0000C8   390 _T2CON	=	0x00c8
                           0000C9   391 _T2MOD	=	0x00c9
                           00CBCA   392 _RCAP2	=	0xcbca
                           0000CA   393 _RCAP2L	=	0x00ca
                           0000CB   394 _RCAP2H	=	0x00cb
                           00CDCC   395 _T2COUNT	=	0xcdcc
                           0000CC   396 _TL2	=	0x00cc
                           0000CD   397 _TH2	=	0x00cd
                           00CFCE   398 _T2CAP1	=	0xcfce
                           0000CE   399 _T2CAP1L	=	0x00ce
                           0000CF   400 _T2CAP1H	=	0x00cf
                           0000F8   401 _SPI0_STAT	=	0x00f8
                           0000F9   402 _SPI0_DATA	=	0x00f9
                           0000FA   403 _SPI0_CTRL	=	0x00fa
                           0000FB   404 _SPI0_CK_SE	=	0x00fb
                           0000FC   405 _SPI0_SETUP	=	0x00fc
                           0000BC   406 _SCON1	=	0x00bc
                           0000BD   407 _SBUF1	=	0x00bd
                           0000BE   408 _SBAUD1	=	0x00be
                           0000BF   409 _SIF1	=	0x00bf
                           0000B4   410 _SPI1_STAT	=	0x00b4
                           0000B5   411 _SPI1_DATA	=	0x00b5
                           0000B6   412 _SPI1_CTRL	=	0x00b6
                           0000B7   413 _SPI1_CK_SE	=	0x00b7
                           0000F3   414 _ADC_CTRL	=	0x00f3
                           00F5F4   415 _ADC_DAT	=	0xf5f4
                           0000F4   416 _ADC_DAT_L	=	0x00f4
                           0000F5   417 _ADC_DAT_H	=	0x00f5
                           0000F6   418 _ADC_CHAN	=	0x00f6
                           0000A6   419 _LED_COMMON	=	0x00a6
                           0000A7   420 _LED_PWM_OE	=	0x00a7
                           00C7C6   421 _LED_DMA	=	0xc7c6
                           0000C6   422 _LED_DMA_L	=	0x00c6
                           0000C7   423 _LED_DMA_H	=	0x00c7
                           0000F7   424 _LED_STATUS	=	0x00f7
                           0000B3   425 _I2CX_INT	=	0x00b3
                           0000BB   426 _I2CS_INT_ST	=	0x00bb
                                    427 ;--------------------------------------------------------
                                    428 ; special function bits
                                    429 ;--------------------------------------------------------
                                    430 	.area RSEG    (ABS,DATA)
      000000                        431 	.org 0x0000
                           0000D7   432 _CY	=	0x00d7
                           0000D6   433 _AC	=	0x00d6
                           0000D5   434 _F0	=	0x00d5
                           0000D4   435 _RS1	=	0x00d4
                           0000D3   436 _RS0	=	0x00d3
                           0000D2   437 _OV	=	0x00d2
                           0000D1   438 _F1	=	0x00d1
                           0000D0   439 _P	=	0x00d0
                           0000AF   440 _EA	=	0x00af
                           0000AE   441 _E_DIS	=	0x00ae
                           0000AD   442 _ET2	=	0x00ad
                           0000AC   443 _ES	=	0x00ac
                           0000AB   444 _ET1	=	0x00ab
                           0000AA   445 _EX1	=	0x00aa
                           0000A9   446 _ET0	=	0x00a9
                           0000A8   447 _EX0	=	0x00a8
                           0000BF   448 _PH_FLAG	=	0x00bf
                           0000BE   449 _PL_FLAG	=	0x00be
                           0000BD   450 _PT2	=	0x00bd
                           0000BC   451 _PS	=	0x00bc
                           0000BB   452 _PT1	=	0x00bb
                           0000BA   453 _PX1	=	0x00ba
                           0000B9   454 _PT0	=	0x00b9
                           0000B8   455 _PX0	=	0x00b8
                           0000EF   456 _IE_WDOG	=	0x00ef
                           0000EE   457 _IE_GPIO	=	0x00ee
                           0000ED   458 _IE_PWM_I2C	=	0x00ed
                           0000EC   459 _IE_UART1	=	0x00ec
                           0000EB   460 _IE_ADC	=	0x00eb
                           0000E9   461 _IE_USB	=	0x00e9
                           0000E8   462 _IE_SPI0	=	0x00e8
                           000087   463 _P0_7	=	0x0087
                           000086   464 _P0_6	=	0x0086
                           000085   465 _P0_5	=	0x0085
                           000084   466 _P0_4	=	0x0084
                           000083   467 _P0_3	=	0x0083
                           000082   468 _P0_2	=	0x0082
                           000081   469 _P0_1	=	0x0081
                           000080   470 _P0_0	=	0x0080
                           000081   471 _SDA0	=	0x0081
                           000080   472 _SCL0	=	0x0080
                           000083   473 _TXD_	=	0x0083
                           000082   474 _RXD_	=	0x0082
                           000085   475 _AIN13	=	0x0085
                           000084   476 _AIN12	=	0x0084
                           000083   477 _AIN11	=	0x0083
                           000082   478 _AIN10	=	0x0082
                           000081   479 _AIN9	=	0x0081
                           000080   480 _AIN8	=	0x0080
                           000097   481 _P1_7	=	0x0097
                           000096   482 _P1_6	=	0x0096
                           000095   483 _P1_5	=	0x0095
                           000094   484 _P1_4	=	0x0094
                           000093   485 _P1_3	=	0x0093
                           000092   486 _P1_2	=	0x0092
                           000091   487 _P1_1	=	0x0091
                           000090   488 _P1_0	=	0x0090
                           000097   489 _TXD1_	=	0x0097
                           000096   490 _RXD1_	=	0x0096
                           000097   491 _SCK	=	0x0097
                           000096   492 _MISO	=	0x0096
                           000095   493 _MOSI	=	0x0095
                           000094   494 _SCS	=	0x0094
                           000092   495 _INT0_	=	0x0092
                           000091   496 _T2EX	=	0x0091
                           000091   497 _CAP2	=	0x0091
                           000090   498 _T2	=	0x0090
                           000090   499 _CAP1	=	0x0090
                           000097   500 _AIN7	=	0x0097
                           000096   501 _AIN6	=	0x0096
                           000095   502 _AIN5	=	0x0095
                           000094   503 _AIN4	=	0x0094
                           000093   504 _AIN3	=	0x0093
                           000092   505 _AIN2	=	0x0092
                           000091   506 _AIN1	=	0x0091
                           000090   507 _AIN0	=	0x0090
                           0000A7   508 _P2_7	=	0x00a7
                           0000A6   509 _P2_6	=	0x00a6
                           0000A5   510 _P2_5	=	0x00a5
                           0000A4   511 _P2_4	=	0x00a4
                           0000A3   512 _P2_3	=	0x00a3
                           0000A2   513 _P2_2	=	0x00a2
                           0000A1   514 _P2_1	=	0x00a1
                           0000A0   515 _P2_0	=	0x00a0
                           0000A7   516 _TXD1	=	0x00a7
                           0000A6   517 _RXD1	=	0x00a6
                           0000A5   518 _T2EX_	=	0x00a5
                           0000A5   519 _CAP2_	=	0x00a5
                           0000A4   520 _T2_	=	0x00a4
                           0000A4   521 _CAP1_	=	0x00a4
                           0000B7   522 _P3_7	=	0x00b7
                           0000B6   523 _P3_6	=	0x00b6
                           0000B5   524 _P3_5	=	0x00b5
                           0000B4   525 _P3_4	=	0x00b4
                           0000B3   526 _P3_3	=	0x00b3
                           0000B2   527 _P3_2	=	0x00b2
                           0000B1   528 _P3_1	=	0x00b1
                           0000B0   529 _P3_0	=	0x00b0
                           0000B7   530 _SCK1	=	0x00b7
                           0000B6   531 _MISO1	=	0x00b6
                           0000B5   532 _MOSI1	=	0x00b5
                           0000B5   533 _T1	=	0x00b5
                           0000B4   534 _T0	=	0x00b4
                           0000B3   535 _INT1	=	0x00b3
                           0000B2   536 _INT0	=	0x00b2
                           0000B1   537 _TXD	=	0x00b1
                           0000B0   538 _RXD	=	0x00b0
                           0000C6   539 _P4_6	=	0x00c6
                           0000C5   540 _P4_5	=	0x00c5
                           0000C4   541 _P4_4	=	0x00c4
                           0000C3   542 _P4_3	=	0x00c3
                           0000C2   543 _P4_2	=	0x00c2
                           0000C1   544 _P4_1	=	0x00c1
                           0000C0   545 _P4_0	=	0x00c0
                           00008F   546 _TF1	=	0x008f
                           00008E   547 _TR1	=	0x008e
                           00008D   548 _TF0	=	0x008d
                           00008C   549 _TR0	=	0x008c
                           00008B   550 _IE1	=	0x008b
                           00008A   551 _IT1	=	0x008a
                           000089   552 _IE0	=	0x0089
                           000088   553 _IT0	=	0x0088
                           00009F   554 _SM0	=	0x009f
                           00009E   555 _SM1	=	0x009e
                           00009D   556 _SM2	=	0x009d
                           00009C   557 _REN	=	0x009c
                           00009B   558 _TB8	=	0x009b
                           00009A   559 _RB8	=	0x009a
                           000099   560 _TI	=	0x0099
                           000098   561 _RI	=	0x0098
                           0000CF   562 _TF2	=	0x00cf
                           0000CF   563 _CAP1F	=	0x00cf
                           0000CE   564 _EXF2	=	0x00ce
                           0000CD   565 _RCLK	=	0x00cd
                           0000CC   566 _TCLK	=	0x00cc
                           0000CB   567 _EXEN2	=	0x00cb
                           0000CA   568 _TR2	=	0x00ca
                           0000C9   569 _C_T2	=	0x00c9
                           0000C8   570 _CP_RL2	=	0x00c8
                           0000FF   571 _S0_FST_ACT	=	0x00ff
                           0000FE   572 _S0_IF_OV	=	0x00fe
                           0000FD   573 _S0_IF_FIRST	=	0x00fd
                           0000FC   574 _S0_IF_BYTE	=	0x00fc
                           0000FB   575 _S0_FREE	=	0x00fb
                           0000FA   576 _S0_T_FIFO	=	0x00fa
                           0000F8   577 _S0_R_FIFO	=	0x00f8
                           0000F7   578 _ADC_START	=	0x00f7
                                    579 ;--------------------------------------------------------
                                    580 ; overlayable register banks
                                    581 ;--------------------------------------------------------
                                    582 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        583 	.ds 8
                                    584 ;--------------------------------------------------------
                                    585 ; internal ram data
                                    586 ;--------------------------------------------------------
                                    587 	.area DSEG    (DATA)
      000018                        588 _process_action_sloc0_1_0:
      000018                        589 	.ds 1
                                    590 ;--------------------------------------------------------
                                    591 ; overlayable items in internal ram
                                    592 ;--------------------------------------------------------
                                    593 ;--------------------------------------------------------
                                    594 ; indirectly addressable internal ram data
                                    595 ;--------------------------------------------------------
                                    596 	.area ISEG    (DATA)
                                    597 ;--------------------------------------------------------
                                    598 ; absolute internal ram data
                                    599 ;--------------------------------------------------------
                                    600 	.area IABS    (ABS,DATA)
                                    601 	.area IABS    (ABS,DATA)
                                    602 ;--------------------------------------------------------
                                    603 ; bit data
                                    604 ;--------------------------------------------------------
                                    605 	.area BSEG    (BIT)
      00001F                        606 _process_action_sloc1_1_0:
      00001F                        607 	.ds 1
                                    608 ;--------------------------------------------------------
                                    609 ; paged external ram data
                                    610 ;--------------------------------------------------------
                                    611 	.area PSEG    (PAG,XDATA)
                                    612 ;--------------------------------------------------------
                                    613 ; uninitialized external ram data
                                    614 ;--------------------------------------------------------
                                    615 	.area XSEG    (XDATA)
      000812                        616 _tp_buttons::
      000812                        617 	.ds 2
      000814                        618 _action_exec_PARM_1:
      000814                        619 	.ds 6
      00081A                        620 _action_exec_record_10001_624:
      00081A                        621 	.ds 9
      000823                        622 _ak820_action_exec_event_10000_628:
      000823                        623 	.ds 2
      000825                        624 _ak820_action_exec_snapshot_10000_629:
      000825                        625 	.ds 6
      00082B                        626 _process_record_record_10000_632:
      00082B                        627 	.ds 3
      00082E                        628 _process_record_handler_record_argument_10000_640:
      00082E                        629 	.ds 3
      000831                        630 _process_record_handler_action_10000_641:
      000831                        631 	.ds 2
      000833                        632 _process_action_PARM_2:
      000833                        633 	.ds 2
      000835                        634 _process_action_record_argument_10000_652:
      000835                        635 	.ds 3
      000838                        636 _process_action_on_40000_675:
      000838                        637 	.ds 1
      000839                        638 _register_code_code_10000_709:
      000839                        639 	.ds 1
      00083A                        640 _unregister_code_code_10000_723:
      00083A                        641 	.ds 1
      00083B                        642 _tap_code_delay_PARM_2:
      00083B                        643 	.ds 2
      00083D                        644 _tap_code_delay_code_10000_736:
      00083D                        645 	.ds 1
      00083E                        646 _tap_code_code_10000_743:
      00083E                        647 	.ds 1
      00083F                        648 _register_mods_mods_10000_745:
      00083F                        649 	.ds 1
      000840                        650 _unregister_mods_mods_10000_749:
      000840                        651 	.ds 1
      000841                        652 _register_weak_mods_mods_10000_753:
      000841                        653 	.ds 1
      000842                        654 _unregister_weak_mods_mods_10000_757:
      000842                        655 	.ds 1
                                    656 ;--------------------------------------------------------
                                    657 ; absolute external ram data
                                    658 ;--------------------------------------------------------
                                    659 	.area XABS    (ABS,XDATA)
                                    660 ;--------------------------------------------------------
                                    661 ; initialized external ram data
                                    662 ;--------------------------------------------------------
                                    663 	.area XISEG   (XDATA)
      000DC1                        664 _disable_action_cache::
      000DC1                        665 	.ds 1
                                    666 	.area HOME    (CODE)
                                    667 	.area GSINIT0 (CODE)
                                    668 	.area GSINIT1 (CODE)
                                    669 	.area GSINIT2 (CODE)
                                    670 	.area GSINIT3 (CODE)
                                    671 	.area GSINIT4 (CODE)
                                    672 	.area GSINIT5 (CODE)
                                    673 	.area GSINIT  (CODE)
                                    674 	.area GSFINAL (CODE)
                                    675 	.area CSEG    (CODE)
                                    676 ;--------------------------------------------------------
                                    677 ; global & static initialisations
                                    678 ;--------------------------------------------------------
                                    679 	.area HOME    (CODE)
                                    680 	.area GSINIT  (CODE)
                                    681 	.area GSFINAL (CODE)
                                    682 	.area GSINIT  (CODE)
                                    683 ;--------------------------------------------------------
                                    684 ; Home
                                    685 ;--------------------------------------------------------
                                    686 	.area HOME    (CODE)
                                    687 	.area HOME    (CODE)
                                    688 ;--------------------------------------------------------
                                    689 ; code
                                    690 ;--------------------------------------------------------
                                    691 	.area CSEG    (CODE)
                                    692 ;------------------------------------------------------------
                                    693 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    694 ;------------------------------------------------------------
                                    695 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    696 ;------------------------------------------------------------
                                    697 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    698 ;	-----------------------------------------
                           000007   699 	ar7 = 0x07
                           000006   700 	ar6 = 0x06
                           000005   701 	ar5 = 0x05
                           000004   702 	ar4 = 0x04
                           000003   703 	ar3 = 0x03
                           000002   704 	ar2 = 0x02
                           000001   705 	ar1 = 0x01
                           000000   706 	ar0 = 0x00
                                    707 ;	 function action_exec
                                    708 ;	-----------------------------------------
      006F91                        709 _action_exec:
                                    710 ;	quantum/action.c:92: ak820_combo_tick(event.time);
      006F91 90 08 16         [24]  711 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      006F94 12 37 F4         [24]  712 	lcall	_ak820_outline_0005
      006F97 12 36 04         [24]  713 	lcall	_ak820_combo_tick
                                    714 ;	quantum/action.c:95: if (!ak820_tapping_before(&event)) return;
      006F9A 90 08 14         [24]  715 	mov	dptr,#_action_exec_PARM_1
      006F9D 12 44 53         [24]  716 	lcall	_ak820_tapping_before
      006FA0 E5 82            [12]  717 	mov	a, dpl
      006FA2 70 01            [24]  718 	jnz	00102$
      006FA4 22               [24]  719 	ret
      006FA5                        720 00102$:
                                    721 ;	quantum/action.c:113: if (event.pressed) {
      006FA5 90 08 19         [24]  722 	mov	dptr,#(_action_exec_PARM_1 + 0x0005)
      006FA8 E0               [24]  723 	movx	a,@dptr
      006FA9 60 03            [24]  724 	jz	00104$
                                    725 ;	quantum/action.c:115: clear_weak_mods();
      006FAB 12 7F FF         [24]  726 	lcall	_clear_weak_mods
      006FAE                        727 00104$:
                                    728 ;	quantum/action.c:127: record.event = event;
      006FAE 90 0D A1         [24]  729 	mov	dptr,#___memcpy_PARM_2
      006FB1 74 14            [12]  730 	mov	a,#_action_exec_PARM_1
      006FB3 F0               [24]  731 	movx	@dptr,a
      006FB4 74 08            [12]  732 	mov	a,#(_action_exec_PARM_1 >> 8)
      006FB6 12 38 70         [24]  733 	lcall	_ak820_outline_0093
      006FB9 12 76 6B         [24]  734 	lcall	_ak820_outline_0071
      006FBC 90 08 1A         [24]  735 	mov	dptr,#_action_exec_record_10001_624
      006FBF F5 F0            [12]  736 	mov	b,a
      006FC1 12 B7 3A         [24]  737 	lcall	___memcpy
                                    738 ;	quantum/action.c:129: record.tap.count = 0;
      006FC4 90 08 20         [24]  739 	mov	dptr,#(_action_exec_record_10001_624 + 0x0006)
      006FC7 E0               [24]  740 	movx	a,@dptr
      006FC8 54 0F            [12]  741 	anl	a,#0x0f
      006FCA F0               [24]  742 	movx	@dptr,a
                                    743 ;	quantum/action.c:134: record.keycode = 0;
      006FCB 90 08 21         [24]  744 	mov	dptr,#(_action_exec_record_10001_624 + 0x0007)
      006FCE 12 4E C3         [24]  745 	lcall	_ak820_outline_0184
                                    746 ;	quantum/action.c:165: if (IS_NOEVENT(record.event) || pre_process_record_quantum(&record)) {
      006FD1 90 08 1E         [24]  747 	mov	dptr,#(_action_exec_record_10001_624 + 0x0004)
      006FD4 E0               [24]  748 	movx	a,@dptr
      006FD5 60 0D            [24]  749 	jz	00107$
      006FD7 90 08 1A         [24]  750 	mov	dptr,#_action_exec_record_10001_624
      006FDA 75 F0 00         [24]  751 	mov	b, #0x00
      006FDD 12 9D E0         [24]  752 	lcall	_pre_process_record_quantum
      006FE0 E5 82            [12]  753 	mov	a, dpl
      006FE2 60 14            [24]  754 	jz	00110$
      006FE4                        755 00107$:
                                    756 ;	quantum/action.c:167: if (!ak820_tapping_process(&record)) return;
      006FE4 90 08 1A         [24]  757 	mov	dptr,#_action_exec_record_10001_624
      006FE7 12 45 3F         [24]  758 	lcall	_ak820_tapping_process
      006FEA E5 82            [12]  759 	mov	a, dpl
      006FEC 70 01            [24]  760 	jnz	00106$
      006FEE 22               [24]  761 	ret
      006FEF                        762 00106$:
                                    763 ;	quantum/action.c:172: process_record(&record);
      006FEF 90 08 1A         [24]  764 	mov	dptr,#_action_exec_record_10001_624
      006FF2 75 F0 00         [24]  765 	mov	b, #0x00
                                    766 ;	quantum/action.c:182: }
      006FF5 02 70 35         [24]  767 	ljmp	_process_record
      006FF8                        768 00110$:
      006FF8 22               [24]  769 	ret
                                    770 ;------------------------------------------------------------
                                    771 ;Allocation info for local variables in function 'ak820_action_exec'
                                    772 ;------------------------------------------------------------
                                    773 ;event         Allocated with name '_ak820_action_exec_event_10000_628'
                                    774 ;snapshot      Allocated with name '_ak820_action_exec_snapshot_10000_629'
                                    775 ;------------------------------------------------------------
                                    776 ;	quantum/action.c:185: void ak820_action_exec(const keyevent_t __xdata *event) {
                                    777 ;	-----------------------------------------
                                    778 ;	 function ak820_action_exec
                                    779 ;	-----------------------------------------
      006FF9                        780 _ak820_action_exec:
      006FF9 12 38 8D         [24]  781 	lcall	_ak820_outline_0110
      006FFC 90 08 23         [24]  782 	mov	dptr,#_ak820_action_exec_event_10000_628
      006FFF 12 38 88         [24]  783 	lcall	_ak820_outline_0109
                                    784 ;	quantum/action.c:188: keyevent_t snapshot = *event;
      007002 90 08 23         [24]  785 	mov	dptr,#_ak820_action_exec_event_10000_628
      007005 12 38 64         [24]  786 	lcall	_ak820_outline_0079
      007008 7F 00            [12]  787 	mov	r7,#0x00
      00700A 90 0D A1         [24]  788 	mov	dptr,#___memcpy_PARM_2
      00700D ED               [12]  789 	mov	a,r5
      00700E 12 38 1F         [24]  790 	lcall	_ak820_outline_0015
      007011 12 76 6B         [24]  791 	lcall	_ak820_outline_0071
      007014 90 08 25         [24]  792 	mov	dptr,#_ak820_action_exec_snapshot_10000_629
      007017 F5 F0            [12]  793 	mov	b,a
      007019 12 B7 3A         [24]  794 	lcall	___memcpy
                                    795 ;	quantum/action.c:189: action_exec(snapshot);
      00701C 90 0D A1         [24]  796 	mov	dptr,#___memcpy_PARM_2
      00701F 74 25            [12]  797 	mov	a,#_ak820_action_exec_snapshot_10000_629
      007021 F0               [24]  798 	movx	@dptr,a
      007022 74 08            [12]  799 	mov	a,#(_ak820_action_exec_snapshot_10000_629 >> 8)
      007024 12 38 70         [24]  800 	lcall	_ak820_outline_0093
      007027 12 76 6B         [24]  801 	lcall	_ak820_outline_0071
      00702A 90 08 14         [24]  802 	mov	dptr,#_action_exec_PARM_1
      00702D F5 F0            [12]  803 	mov	b,a
      00702F 12 B7 3A         [24]  804 	lcall	___memcpy
                                    805 ;	quantum/action.c:190: }
      007032 02 6F 91         [24]  806 	ljmp	_action_exec
                                    807 ;------------------------------------------------------------
                                    808 ;Allocation info for local variables in function 'process_record_nocache'
                                    809 ;------------------------------------------------------------
                                    810 ;record        Allocated with name '_process_record_nocache_record_10000_630'
                                    811 ;------------------------------------------------------------
                                    812 ;	quantum/action.c:275: void process_record_nocache(keyrecord_t *record) {
                                    813 ;	-----------------------------------------
                                    814 ;	 function process_record
                                    815 ;	-----------------------------------------
      007035                        816 _process_record:
      007035 12 43 13         [24]  817 	lcall	_ak820_outline_0036
      007038 90 08 2B         [24]  818 	mov	dptr,#_process_record_record_10000_632
      00703B 12 38 1F         [24]  819 	lcall	_ak820_outline_0015
                                    820 ;	quantum/action.c:329: if (IS_NOEVENT(record->event)) {
      00703E 90 08 2B         [24]  821 	mov	dptr,#_process_record_record_10000_632
      007041 12 4E 70         [24]  822 	lcall	_ak820_outline_0012
      007044 74 04            [12]  823 	mov	a,#0x04
      007046 12 76 3E         [24]  824 	lcall	_ak820_outline_0014
      007049 12 B8 13         [24]  825 	lcall	__gptrget
      00704C 70 01            [24]  826 	jnz	00102$
                                    827 ;	quantum/action.c:330: return;
      00704E 22               [24]  828 	ret
      00704F                        829 00102$:
                                    830 ;	quantum/action.c:338: uint8_t oneshot_source = ak820_tapping_source(record->event.key);
      00704F 8D 02            [24]  831 	mov	ar2,r5
      007051 8E 03            [24]  832 	mov	ar3,r6
      007053 8F 04            [24]  833 	mov	ar4,r7
      007055 90 0D A1         [24]  834 	mov	dptr,#___memcpy_PARM_2
      007058 EA               [12]  835 	mov	a,r2
      007059 12 76 B2         [24]  836 	lcall	_ak820_outline_0188
      00705C EC               [12]  837 	mov	a,r4
      00705D A3               [24]  838 	inc	dptr
      00705E F0               [24]  839 	movx	@dptr,a
      00705F 90 0D A4         [24]  840 	mov	dptr,#___memcpy_PARM_3
      007062 12 4E B5         [24]  841 	lcall	_ak820_outline_0112
      007065 90 06 24         [24]  842 	mov	dptr,#_ak820_tapping_source_PARM_1
      007068 F5 F0            [12]  843 	mov	b,a
      00706A C0 07            [24]  844 	push	ar7
      00706C C0 06            [24]  845 	push	ar6
      00706E C0 05            [24]  846 	push	ar5
      007070 12 B7 3A         [24]  847 	lcall	___memcpy
      007073 12 43 8D         [24]  848 	lcall	_ak820_tapping_source
      007076 AC 82            [24]  849 	mov	r4, dpl
      007078 D0 05            [24]  850 	pop	ar5
      00707A D0 06            [24]  851 	pop	ar6
      00707C D0 07            [24]  852 	pop	ar7
                                    853 ;	quantum/action.c:339: bool oneshot_pressed = record->event.pressed;
      00707E 74 05            [12]  854 	mov	a,#0x05
      007080 12 76 30         [24]  855 	lcall	_ak820_outline_0013
      007083 12 B8 13         [24]  856 	lcall	__gptrget
      007086 FB               [12]  857 	mov	r3,a
                                    858 ;	quantum/action.c:340: record->keycode = get_record_keycode(record, true);
      007087 12 76 97         [24]  859 	lcall	_ak820_outline_0147
      00708A 90 0B F8         [24]  860 	mov	dptr,#_get_record_keycode_PARM_2
      00708D 74 01            [12]  861 	mov	a,#0x01
      00708F 12 4E 79         [24]  862 	lcall	_ak820_outline_0033
      007092 C0 04            [24]  863 	push	ar4
      007094 C0 03            [24]  864 	push	ar3
      007096 C0 02            [24]  865 	push	ar2
      007098 C0 01            [24]  866 	push	ar1
      00709A C0 00            [24]  867 	push	ar0
      00709C 12 9D A2         [24]  868 	lcall	_get_record_keycode
      00709F 12 43 5C         [24]  869 	lcall	_ak820_outline_0134
      0070A2 D0 00            [24]  870 	pop	ar0
      0070A4 D0 01            [24]  871 	pop	ar1
      0070A6 D0 02            [24]  872 	pop	ar2
      0070A8 D0 03            [24]  873 	pop	ar3
      0070AA D0 04            [24]  874 	pop	ar4
      0070AC 12 38 B1         [24]  875 	lcall	_ak820_outline_0145
      0070AF 8A F0            [24]  876 	mov	b,r2
      0070B1 EE               [12]  877 	mov	a,r6
      0070B2 12 B7 D8         [24]  878 	lcall	__gptrput
      0070B5 A3               [24]  879 	inc	dptr
      0070B6 EF               [12]  880 	mov	a,r7
      0070B7 12 B7 D8         [24]  881 	lcall	__gptrput
                                    882 ;	quantum/action.c:341: if (!ak820_oneshot_process(record->keycode, oneshot_source, oneshot_pressed)) return;
      0070BA 90 08 2B         [24]  883 	mov	dptr,#_process_record_record_10000_632
      0070BD 12 4E 70         [24]  884 	lcall	_ak820_outline_0012
      0070C0 12 76 97         [24]  885 	lcall	_ak820_outline_0147
      0070C3 12 38 B1         [24]  886 	lcall	_ak820_outline_0145
      0070C6 8A F0            [24]  887 	mov	b,r2
      0070C8 12 B8 13         [24]  888 	lcall	__gptrget
      0070CB F8               [12]  889 	mov	r0,a
      0070CC A3               [24]  890 	inc	dptr
      0070CD 12 B8 13         [24]  891 	lcall	__gptrget
      0070D0 F9               [12]  892 	mov	r1,a
      0070D1 90 06 31         [24]  893 	mov	dptr,#_ak820_oneshot_process_PARM_2
      0070D4 EC               [12]  894 	mov	a,r4
      0070D5 F0               [24]  895 	movx	@dptr,a
      0070D6 90 06 32         [24]  896 	mov	dptr,#_ak820_oneshot_process_PARM_3
      0070D9 EB               [12]  897 	mov	a,r3
      0070DA F0               [24]  898 	movx	@dptr,a
      0070DB 12 38 B1         [24]  899 	lcall	_ak820_outline_0145
      0070DE C0 07            [24]  900 	push	ar7
      0070E0 C0 06            [24]  901 	push	ar6
      0070E2 C0 05            [24]  902 	push	ar5
      0070E4 C0 04            [24]  903 	push	ar4
      0070E6 C0 03            [24]  904 	push	ar3
      0070E8 12 46 81         [24]  905 	lcall	_ak820_oneshot_process
      0070EB E5 82            [12]  906 	mov	a, dpl
      0070ED D0 03            [24]  907 	pop	ar3
      0070EF D0 04            [24]  908 	pop	ar4
      0070F1 D0 05            [24]  909 	pop	ar5
      0070F3 D0 06            [24]  910 	pop	ar6
      0070F5 D0 07            [24]  911 	pop	ar7
      0070F7 70 01            [24]  912 	jnz	00104$
      0070F9 22               [24]  913 	ret
      0070FA                        914 00104$:
                                    915 ;	quantum/action.c:343: if (!process_record_quantum(record)) {
      0070FA 12 6C E0         [24]  916 	lcall	_ak820_outline_0059
      0070FD C0 04            [24]  917 	push	ar4
      0070FF C0 03            [24]  918 	push	ar3
      007101 12 9E 68         [24]  919 	lcall	_process_record_quantum
      007104 E5 82            [12]  920 	mov	a, dpl
      007106 D0 03            [24]  921 	pop	ar3
      007108 D0 04            [24]  922 	pop	ar4
      00710A 70 0A            [24]  923 	jnz	00106$
                                    924 ;	quantum/action.c:345: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      00710C 90 05 9C         [24]  925 	mov	dptr,#_ak820_oneshot_post_PARM_2
      00710F EB               [12]  926 	mov	a,r3
      007110 F0               [24]  927 	movx	@dptr,a
      007111 8C 82            [24]  928 	mov	dpl, r4
                                    929 ;	quantum/action.c:352: return;
      007113 02 2E BB         [24]  930 	ljmp	_ak820_oneshot_post
      007116                        931 00106$:
                                    932 ;	quantum/action.c:358: process_record_handler(record);
      007116 90 08 2B         [24]  933 	mov	dptr,#_process_record_record_10000_632
      007119 12 4E 4A         [24]  934 	lcall	_ak820_outline_0001
      00711C C0 04            [24]  935 	push	ar4
      00711E C0 03            [24]  936 	push	ar3
      007120 12 71 3A         [24]  937 	lcall	_process_record_handler
                                    938 ;	quantum/action.c:362: post_process_record_quantum(record);
      007123 90 08 2B         [24]  939 	mov	dptr,#_process_record_record_10000_632
      007126 12 4E 4A         [24]  940 	lcall	_ak820_outline_0001
      007129 12 9E 3D         [24]  941 	lcall	_post_process_record_quantum
      00712C D0 03            [24]  942 	pop	ar3
      00712E D0 04            [24]  943 	pop	ar4
                                    944 ;	quantum/action.c:364: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      007130 90 05 9C         [24]  945 	mov	dptr,#_ak820_oneshot_post_PARM_2
      007133 EB               [12]  946 	mov	a,r3
      007134 F0               [24]  947 	movx	@dptr,a
      007135 8C 82            [24]  948 	mov	dpl, r4
                                    949 ;	quantum/action.c:366: }
      007137 02 2E BB         [24]  950 	ljmp	_ak820_oneshot_post
                                    951 ;------------------------------------------------------------
                                    952 ;Allocation info for local variables in function 'process_record_handler'
                                    953 ;------------------------------------------------------------
                                    954 ;record_argument Allocated with name '_process_record_handler_record_argument_10000_640'
                                    955 ;record        Allocated with name '_process_record_handler_record_10000_641'
                                    956 ;action        Allocated with name '_process_record_handler_action_10000_641'
                                    957 ;------------------------------------------------------------
                                    958 ;	quantum/action.c:368: void process_record_handler(keyrecord_t *record_argument) {
                                    959 ;	-----------------------------------------
                                    960 ;	 function process_record_handler
                                    961 ;	-----------------------------------------
      00713A                        962 _process_record_handler:
      00713A 12 43 13         [24]  963 	lcall	_ak820_outline_0036
      00713D 90 08 2E         [24]  964 	mov	dptr,#_process_record_handler_record_argument_10000_640
      007140 12 38 1F         [24]  965 	lcall	_ak820_outline_0015
                                    966 ;	quantum/action.c:372: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      007143 90 08 2E         [24]  967 	mov	dptr,#_process_record_handler_record_argument_10000_640
      007146 12 37 FE         [24]  968 	lcall	_ak820_outline_0007
                                    969 ;	quantum/action.c:379: if (record->keycode) {
      007149 4C               [12]  970 	orl	a,r4
      00714A 60 19            [24]  971 	jz	00102$
                                    972 ;	quantum/action.c:380: action.code = action_for_keycode(record->keycode);
      00714C 12 38 97         [24]  973 	lcall	_ak820_outline_0125
      00714F C0 07            [24]  974 	push	ar7
      007151 C0 06            [24]  975 	push	ar6
      007153 12 93 DD         [24]  976 	lcall	_action_for_keycode
      007156 12 43 72         [24]  977 	lcall	_ak820_outline_0151
      007159 D0 06            [24]  978 	pop	ar6
      00715B D0 07            [24]  979 	pop	ar7
      00715D 90 08 31         [24]  980 	mov	dptr,#_process_record_handler_action_10000_641
      007160 12 38 5E         [24]  981 	lcall	_ak820_outline_0072
      007163 80 2B            [24]  982 	sjmp	00104$
      007165                        983 00102$:
                                    984 ;	quantum/action.c:383: action.code = action_for_keycode(ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed));
      007165 12 76 4C         [24]  985 	lcall	_ak820_outline_0021
      007168 7A 00            [12]  986 	mov	r2,#0x00
      00716A 12 43 67         [24]  987 	lcall	_ak820_outline_0143
      00716D 12 43 01         [24]  988 	lcall	_ak820_outline_0011
      007170 E0               [24]  989 	movx	a,@dptr
      007171 90 09 6D         [24]  990 	mov	dptr,#_ak820_resolve_key_PARM_2
      007174 F0               [24]  991 	movx	@dptr,a
      007175 8D 82            [24]  992 	mov	dpl, r5
      007177 8C 83            [24]  993 	mov	dph, r4
      007179 C0 07            [24]  994 	push	ar7
      00717B C0 06            [24]  995 	push	ar6
      00717D 12 79 F3         [24]  996 	lcall	_ak820_resolve_key
      007180 12 93 DD         [24]  997 	lcall	_action_for_keycode
      007183 12 43 72         [24]  998 	lcall	_ak820_outline_0151
      007186 D0 06            [24]  999 	pop	ar6
      007188 D0 07            [24] 1000 	pop	ar7
      00718A 90 08 31         [24] 1001 	mov	dptr,#_process_record_handler_action_10000_641
      00718D 12 38 5E         [24] 1002 	lcall	_ak820_outline_0072
                                   1003 ;	quantum/action.c:392: ac_dprintf("ACTION: ");
      007190                       1004 00104$:
                                   1005 ;	quantum/action.c:403: process_action(record, action);
      007190 7D 00            [12] 1006 	mov	r5,#0x00
      007192 90 0D A1         [24] 1007 	mov	dptr,#___memcpy_PARM_2
      007195 74 31            [12] 1008 	mov	a,#_process_record_handler_action_10000_641
      007197 F0               [24] 1009 	movx	@dptr,a
      007198 74 08            [12] 1010 	mov	a,#(_process_record_handler_action_10000_641 >> 8)
      00719A 12 38 70         [24] 1011 	lcall	_ak820_outline_0093
      00719D 90 0D A4         [24] 1012 	mov	dptr,#___memcpy_PARM_3
      0071A0 12 4E B5         [24] 1013 	lcall	_ak820_outline_0112
      0071A3 90 08 33         [24] 1014 	mov	dptr,#_process_action_PARM_2
      0071A6 F5 F0            [12] 1015 	mov	b,a
      0071A8 C0 07            [24] 1016 	push	ar7
      0071AA C0 06            [24] 1017 	push	ar6
      0071AC C0 05            [24] 1018 	push	ar5
      0071AE 12 B7 3A         [24] 1019 	lcall	___memcpy
      0071B1 D0 05            [24] 1020 	pop	ar5
      0071B3 D0 06            [24] 1021 	pop	ar6
      0071B5 D0 07            [24] 1022 	pop	ar7
      0071B7 12 6F 03         [24] 1023 	lcall	_ak820_outline_0050
                                   1024 ;	quantum/action.c:404: }
      0071BA 02 71 BD         [24] 1025 	ljmp	_process_action
                                   1026 ;------------------------------------------------------------
                                   1027 ;Allocation info for local variables in function 'register_mouse'
                                   1028 ;------------------------------------------------------------
                                   1029 ;pressed       Allocated with name '_register_mouse_PARM_2'
                                   1030 ;mouse_keycode Allocated with name '_register_mouse_mouse_keycode_10000_649'
                                   1031 ;------------------------------------------------------------
                                   1032 ;	quantum/action.c:416: void register_mouse(uint8_t mouse_keycode, bool pressed) {
                                   1033 ;	-----------------------------------------
                                   1034 ;	 function process_action
                                   1035 ;	-----------------------------------------
      0071BD                       1036 _process_action:
      0071BD 12 43 13         [24] 1037 	lcall	_ak820_outline_0036
      0071C0 90 08 35         [24] 1038 	mov	dptr,#_process_action_record_argument_10000_652
      0071C3 12 38 1F         [24] 1039 	lcall	_ak820_outline_0015
                                   1040 ;	quantum/action.c:469: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      0071C6 90 08 35         [24] 1041 	mov	dptr,#_process_action_record_argument_10000_652
      0071C9 12 37 F4         [24] 1042 	lcall	_ak820_outline_0005
                                   1043 ;	quantum/action.c:475: pressed = record->event.pressed;
      0071CC A3               [24] 1044 	inc	dptr
      0071CD A3               [24] 1045 	inc	dptr
      0071CE A3               [24] 1046 	inc	dptr
      0071CF A3               [24] 1047 	inc	dptr
      0071D0 A3               [24] 1048 	inc	dptr
      0071D1 E0               [24] 1049 	movx	a,@dptr
      0071D2 F5 18            [12] 1050 	mov	_process_action_sloc0_1_0,a
                                   1051 ;	quantum/action.c:499: switch (action.kind.id) {
      0071D4 90 08 34         [24] 1052 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0071D7 E0               [24] 1053 	movx	a,@dptr
      0071D8 C4               [12] 1054 	swap	a
      0071D9 54 0F            [12] 1055 	anl	a,#0x0f
      0071DB FD               [12] 1056 	mov  r5,a
      0071DC 24 F4            [12] 1057 	add	a,#0xff - 0x0b
      0071DE 50 03            [24] 1058 	jnc	00434$
      0071E0 02 74 5E         [24] 1059 	ljmp	00181$
      0071E3                       1060 00434$:
                                   1061 ;	free result
      0071E3 ED               [12] 1062 	mov	a,r5
      0071E4 24 0A            [12] 1063 	add	a,#(00435$-3-.)
      0071E6 83               [24] 1064 	movc	a,@a+pc
      0071E7 F5 82            [12] 1065 	mov	dpl,a
      0071E9 ED               [12] 1066 	mov	a,r5
      0071EA 24 10            [12] 1067 	add	a,#(00436$-3-.)
      0071EC 83               [24] 1068 	movc	a,@a+pc
      0071ED F5 83            [12] 1069 	mov	dph,a
      0071EF E4               [12] 1070 	clr	a
      0071F0 73               [24] 1071 	jmp	@a+dptr
      0071F1                       1072 00435$:
      0071F1 09                    1073 	.db	00102$
      0071F2 09                    1074 	.db	00102$
      0071F3 5E                    1075 	.db	00181$
      0071F4 5E                    1076 	.db	00181$
      0071F5 93                    1077 	.db	00123$
      0071F6 5E                    1078 	.db	00181$
      0071F7 5E                    1079 	.db	00181$
      0071F8 5E                    1080 	.db	00181$
      0071F9 F3                    1081 	.db	00131$
      0071FA C5                    1082 	.db	00147$
      0071FB EB                    1083 	.db	00152$
      0071FC EB                    1084 	.db	00152$
      0071FD                       1085 00436$:
      0071FD 72                    1086 	.db	00102$>>8
      0071FE 72                    1087 	.db	00102$>>8
      0071FF 74                    1088 	.db	00181$>>8
      007200 74                    1089 	.db	00181$>>8
      007201 72                    1090 	.db	00123$>>8
      007202 74                    1091 	.db	00181$>>8
      007203 74                    1092 	.db	00181$>>8
      007204 74                    1093 	.db	00181$>>8
      007205 72                    1094 	.db	00131$>>8
      007206 73                    1095 	.db	00147$>>8
      007207 73                    1096 	.db	00152$>>8
      007208 73                    1097 	.db	00152$>>8
                                   1098 ;	quantum/action.c:502: case ACT_RMODS: {
      007209                       1099 00102$:
                                   1100 ;	quantum/action.c:503: mods = (action.kind.id == ACT_LMODS) ? action.key.mods : action.key.mods << 4;
      007209 90 08 34         [24] 1101 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      00720C E0               [24] 1102 	movx	a,@dptr
      00720D 54 F0            [12] 1103 	anl	a,#0xf0
      00720F 70 06            [24] 1104 	jnz	00194$
      007211 12 76 85         [24] 1105 	lcall	_ak820_outline_0114
      007214 FD               [12] 1106 	mov	r5,a
      007215 80 07            [24] 1107 	sjmp	00195$
      007217                       1108 00194$:
      007217 12 76 85         [24] 1109 	lcall	_ak820_outline_0114
      00721A C4               [12] 1110 	swap	a
      00721B 54 F0            [12] 1111 	anl	a,#0xf0
      00721D FD               [12] 1112 	mov	r5,a
      00721E                       1113 00195$:
                                   1114 ;	quantum/action.c:505: if (pressed) {
      00721E E5 18            [12] 1115 	mov	a,_process_action_sloc0_1_0
      007220 60 35            [24] 1116 	jz	00119$
                                   1117 ;	quantum/action.c:506: if (mods) {
      007222 ED               [12] 1118 	mov	a,r5
      007223 60 29            [24] 1119 	jz	00110$
                                   1120 ;	quantum/action.c:507: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      007225 12 76 A1         [24] 1121 	lcall	_ak820_outline_0161
      007228 FC               [12] 1122 	mov	r4,a
      007229 BC E0 00         [24] 1123 	cjne	r4,#0xe0,00440$
      00722C                       1124 00440$:
      00722C 40 07            [24] 1125 	jc	00108$
      00722E 12 76 A1         [24] 1126 	lcall	_ak820_outline_0161
      007231 24 18            [12] 1127 	add	a,#0xff - 0xe7
      007233 50 0A            [24] 1128 	jnc	00104$
                                   1129 ;	free result
      007235                       1130 00108$:
      007235 7B 33            [12] 1131 	mov	r3,#_process_action_PARM_2
      007237 7C 08            [12] 1132 	mov	r4,#(_process_action_PARM_2 >> 8)
      007239 12 33 FC         [24] 1133 	lcall	_ak820_outline_0124
      00723C E0               [24] 1134 	movx	a,@dptr
      00723D 70 07            [24] 1135 	jnz	00105$
      00723F                       1136 00104$:
                                   1137 ;	quantum/action.c:511: add_owned_mods(mods);
      00723F 8D 82            [24] 1138 	mov	dpl, r5
      007241 12 7C 0D         [24] 1139 	lcall	_add_owned_mods
      007244 80 05            [24] 1140 	sjmp	00106$
      007246                       1141 00105$:
                                   1142 ;	quantum/action.c:513: add_owned_weak_mods(mods);
      007246 8D 82            [24] 1143 	mov	dpl, r5
      007248 12 7C 2C         [24] 1144 	lcall	_add_owned_weak_mods
      00724B                       1145 00106$:
                                   1146 ;	quantum/action.c:515: send_keyboard_report();
      00724B 12 7F 4F         [24] 1147 	lcall	_send_keyboard_report
      00724E                       1148 00110$:
                                   1149 ;	quantum/action.c:517: register_code(action.key.code);
      00724E 12 76 75         [24] 1150 	lcall	_ak820_outline_0077
      007251 12 74 75         [24] 1151 	lcall	_register_code
      007254 02 74 5E         [24] 1152 	ljmp	00181$
      007257                       1153 00119$:
                                   1154 ;	quantum/action.c:519: unregister_code(action.key.code);
      007257 12 76 75         [24] 1155 	lcall	_ak820_outline_0077
      00725A C0 05            [24] 1156 	push	ar5
      00725C 12 74 E2         [24] 1157 	lcall	_unregister_code
      00725F D0 05            [24] 1158 	pop	ar5
                                   1159 ;	quantum/action.c:520: if (mods) {
      007261 ED               [12] 1160 	mov	a,r5
      007262 70 03            [24] 1161 	jnz	00444$
      007264 02 74 5E         [24] 1162 	ljmp	00181$
      007267                       1163 00444$:
                                   1164 ;	quantum/action.c:521: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      007267 12 76 A1         [24] 1165 	lcall	_ak820_outline_0161
      00726A FC               [12] 1166 	mov	r4,a
      00726B BC E0 00         [24] 1167 	cjne	r4,#0xe0,00445$
      00726E                       1168 00445$:
      00726E 40 07            [24] 1169 	jc	00115$
      007270 12 76 A1         [24] 1170 	lcall	_ak820_outline_0161
      007273 24 18            [12] 1171 	add	a,#0xff - 0xe7
      007275 50 0A            [24] 1172 	jnc	00111$
                                   1173 ;	free result
      007277                       1174 00115$:
      007277 7B 33            [12] 1175 	mov	r3,#_process_action_PARM_2
      007279 7C 08            [12] 1176 	mov	r4,#(_process_action_PARM_2 >> 8)
      00727B 12 33 FC         [24] 1177 	lcall	_ak820_outline_0124
      00727E E0               [24] 1178 	movx	a,@dptr
      00727F 70 07            [24] 1179 	jnz	00112$
      007281                       1180 00111$:
                                   1181 ;	quantum/action.c:522: del_owned_mods(mods);
      007281 8D 82            [24] 1182 	mov	dpl, r5
      007283 12 7C 1D         [24] 1183 	lcall	_del_owned_mods
      007286 80 05            [24] 1184 	sjmp	00113$
      007288                       1185 00112$:
                                   1186 ;	quantum/action.c:524: del_owned_weak_mods(mods);
      007288 8D 82            [24] 1187 	mov	dpl, r5
      00728A 12 7C 3C         [24] 1188 	lcall	_del_owned_weak_mods
      00728D                       1189 00113$:
                                   1190 ;	quantum/action.c:526: send_keyboard_report();
      00728D 12 7F 4F         [24] 1191 	lcall	_send_keyboard_report
                                   1192 ;	quantum/action.c:529: } break;
      007290 02 74 5E         [24] 1193 	ljmp	00181$
                                   1194 ;	quantum/action.c:606: case ACT_USAGE:
      007293                       1195 00123$:
                                   1196 ;	quantum/action.c:612: if (record->keycode >= KC_SYSTEM_POWER && record->keycode <= KC_LAUNCHPAD) {
      007293 74 07            [12] 1197 	mov	a,#0x07
      007295 12 38 31         [24] 1198 	lcall	_ak820_outline_0023
      007298 12 47 BB         [24] 1199 	lcall	_ak820_outline_0008
      00729B C3               [12] 1200 	clr	c
      00729C EC               [12] 1201 	mov	a,r4
      00729D 94 A5            [12] 1202 	subb	a,#0xa5
      00729F ED               [12] 1203 	mov	a,r5
      0072A0 94 00            [12] 1204 	subb	a,#0x00
      0072A2 40 15            [24] 1205 	jc	00125$
      0072A4 74 C2            [12] 1206 	mov	a,#0xc2
      0072A6 9C               [12] 1207 	subb	a,r4
      0072A7 E4               [12] 1208 	clr	a
      0072A8 9D               [12] 1209 	subb	a,r5
      0072A9 40 0E            [24] 1210 	jc	00125$
                                   1211 ;	free result
                                   1212 ;	quantum/action.c:613: owned_usage_key((uint8_t)record->keycode, pressed);
      0072AB 90 0A 94         [24] 1213 	mov	dptr,#_owned_usage_key_PARM_2
      0072AE E5 18            [12] 1214 	mov	a,_process_action_sloc0_1_0
      0072B0 F0               [24] 1215 	movx	@dptr,a
      0072B1 8E 82            [24] 1216 	mov	dpl, r6
      0072B3 12 7D FA         [24] 1217 	lcall	_owned_usage_key
                                   1218 ;	quantum/action.c:614: break;
      0072B6 02 74 5E         [24] 1219 	ljmp	00181$
      0072B9                       1220 00125$:
                                   1221 ;	quantum/action.c:617: switch (action.usage.page) {
      0072B9 12 76 7C         [24] 1222 	lcall	_ak820_outline_0089
      0072BC FF               [12] 1223 	mov	r7,a
      0072BD 60 08            [24] 1224 	jz	00127$
      0072BF BF 01 02         [24] 1225 	cjne	r7,#0x01,00452$
      0072C2 80 19            [24] 1226 	sjmp	00128$
      0072C4                       1227 00452$:
      0072C4 02 74 5E         [24] 1228 	ljmp	00181$
                                   1229 ;	quantum/action.c:618: case PAGE_SYSTEM:
      0072C7                       1230 00127$:
                                   1231 ;	quantum/action.c:619: host_system_send(pressed ? action.usage.code : 0);
      0072C7 E5 18            [12] 1232 	mov	a,_process_action_sloc0_1_0
      0072C9 60 05            [24] 1233 	jz	00196$
      0072CB 12 76 8C         [24] 1234 	lcall	_ak820_outline_0131
      0072CE 80 04            [24] 1235 	sjmp	00197$
      0072D0                       1236 00196$:
      0072D0 7E 00            [12] 1237 	mov	r6,#0x00
      0072D2 7F 00            [12] 1238 	mov	r7,#0x00
      0072D4                       1239 00197$:
      0072D4 12 38 92         [24] 1240 	lcall	_ak820_outline_0119
      0072D7 12 6C 6A         [24] 1241 	lcall	_host_system_send
                                   1242 ;	quantum/action.c:620: break;
      0072DA 02 74 5E         [24] 1243 	ljmp	00181$
                                   1244 ;	quantum/action.c:621: case PAGE_CONSUMER:
      0072DD                       1245 00128$:
                                   1246 ;	quantum/action.c:622: host_consumer_send(pressed ? action.usage.code : 0);
      0072DD E5 18            [12] 1247 	mov	a,_process_action_sloc0_1_0
      0072DF 60 05            [24] 1248 	jz	00198$
      0072E1 12 76 8C         [24] 1249 	lcall	_ak820_outline_0131
      0072E4 80 04            [24] 1250 	sjmp	00199$
      0072E6                       1251 00198$:
      0072E6 7E 00            [12] 1252 	mov	r6,#0x00
      0072E8 7F 00            [12] 1253 	mov	r7,#0x00
      0072EA                       1254 00199$:
      0072EA 12 38 92         [24] 1255 	lcall	_ak820_outline_0119
      0072ED 12 6C 9A         [24] 1256 	lcall	_host_consumer_send
                                   1257 ;	quantum/action.c:625: break;
      0072F0 02 74 5E         [24] 1258 	ljmp	00181$
                                   1259 ;	quantum/action.c:632: case ACT_LAYER: {
      0072F3                       1260 00131$:
                                   1261 ;	quantum/action.c:633: uint8_t on = action.layer_bitop.on;
      0072F3 90 08 34         [24] 1262 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0072F6 E0               [24] 1263 	movx	a,@dptr
      0072F7 54 03            [12] 1264 	anl	a,#0x03
      0072F9 90 08 38         [24] 1265 	mov	dptr,#_process_action_on_40000_675
      0072FC F0               [24] 1266 	movx	@dptr,a
                                   1267 ;	quantum/action.c:636: if (on ? (pressed ? (on & ON_PRESS) : (on & ON_RELEASE)) : !pressed) {
      0072FD E0               [24] 1268 	movx	a,@dptr
      0072FE FF               [12] 1269 	mov	r7,a
      0072FF 60 11            [24] 1270 	jz	00200$
      007301 E5 18            [12] 1271 	mov	a,_process_action_sloc0_1_0
      007303 60 07            [24] 1272 	jz	00202$
      007305 8F 06            [24] 1273 	mov	ar6,r7
      007307 53 06 01         [24] 1274 	anl	ar6,#0x01
      00730A 80 10            [24] 1275 	sjmp	00201$
      00730C                       1276 00202$:
      00730C 74 02            [12] 1277 	mov	a,#0x02
      00730E 5F               [12] 1278 	anl	a,r7
      00730F FE               [12] 1279 	mov	r6,a
      007310 80 0A            [24] 1280 	sjmp	00201$
      007312                       1281 00200$:
      007312 E5 18            [12] 1282 	mov	a,_process_action_sloc0_1_0
      007314 B4 01 00         [24] 1283 	cjne	a,#0x01,00457$
      007317                       1284 00457$:
      007317 92 1F            [24] 1285 	mov  _process_action_sloc1_1_0,c
      007319 E4               [12] 1286 	clr	a
      00731A 33               [12] 1287 	rlc	a
      00731B FE               [12] 1288 	mov	r6,a
      00731C                       1289 00201$:
      00731C EE               [12] 1290 	mov	a,r6
      00731D 70 03            [24] 1291 	jnz	00458$
      00731F 02 74 5E         [24] 1292 	ljmp	00181$
      007322                       1293 00458$:
                                   1294 ;	quantum/action.c:637: uint8_t shift = action.layer_bitop.part * 4;
      007322 12 76 A1         [24] 1295 	lcall	_ak820_outline_0161
      007325 C4               [12] 1296 	swap	a
      007326 03               [12] 1297 	rr	a
      007327 54 07            [12] 1298 	anl	a,#0x07
      007329 25 E0            [12] 1299 	add	a,acc
      00732B 25 E0            [12] 1300 	add	a,acc
      00732D FF               [12] 1301 	mov	r7,a
                                   1302 ;	quantum/action.c:638: layer_state_t bits = ((layer_state_t)action.layer_bitop.bits) << shift;
      00732E 12 76 A1         [24] 1303 	lcall	_ak820_outline_0161
      007331 54 0F            [12] 1304 	anl	a,#0x0f
      007333 FE               [12] 1305 	mov	r6,a
      007334 8F F0            [24] 1306 	mov	b,r7
      007336 05 F0            [12] 1307 	inc	b
      007338 EE               [12] 1308 	mov	a,r6
      007339 80 02            [24] 1309 	sjmp	00460$
      00733B                       1310 00459$:
      00733B 25 E0            [12] 1311 	add	a,acc
      00733D                       1312 00460$:
      00733D D5 F0 FB         [24] 1313 	djnz	b,00459$
      007340 FE               [12] 1314 	mov	r6,a
                                   1315 ;	quantum/action.c:639: layer_state_t mask = action.layer_bitop.xbit ? ~(((layer_state_t)0xf) << shift) : 0;
      007341 12 76 A1         [24] 1316 	lcall	_ak820_outline_0161
      007344 30 E4 11         [24] 1317 	jnb	acc.4,00204$
      007347 8F F0            [24] 1318 	mov	b,r7
      007349 05 F0            [12] 1319 	inc	b
      00734B 74 0F            [12] 1320 	mov	a,#0x0f
      00734D 80 02            [24] 1321 	sjmp	00463$
      00734F                       1322 00462$:
      00734F 25 E0            [12] 1323 	add	a,acc
      007351                       1324 00463$:
      007351 D5 F0 FB         [24] 1325 	djnz	b,00462$
      007354 F4               [12] 1326 	cpl	a
      007355 FF               [12] 1327 	mov	r7,a
      007356 80 02            [24] 1328 	sjmp	00205$
      007358                       1329 00204$:
      007358 7F 00            [12] 1330 	mov	r7,#0x00
      00735A                       1331 00205$:
                                   1332 ;	quantum/action.c:640: bits |= mask;
      00735A EE               [12] 1333 	mov	a,r6
      00735B 42 07            [12] 1334 	orl	ar7,a
                                   1335 ;	quantum/action.c:641: if (!on) {
      00735D 90 08 38         [24] 1336 	mov	dptr,#_process_action_on_40000_675
      007360 E0               [24] 1337 	movx	a,@dptr
      007361 70 31            [24] 1338 	jnz	00143$
                                   1339 ;	quantum/action.c:642: switch (action.layer_bitop.op) {
      007363 12 76 7C         [24] 1340 	lcall	_ak820_outline_0089
      007366 FE               [12] 1341 	mov	r6,a
      007367 2E               [12] 1342 	add	a,r6
                                   1343 ;	quantum/action.c:643: case OP_BIT_AND: default_layer_and(bits); break;
      007368 90 73 6C         [24] 1344 	mov	dptr,#00465$
      00736B 73               [24] 1345 	jmp	@a+dptr
      00736C                       1346 00465$:
      00736C 80 06            [24] 1347 	sjmp	00132$
      00736E 80 0C            [24] 1348 	sjmp	00133$
      007370 80 12            [24] 1349 	sjmp	00134$
      007372 80 18            [24] 1350 	sjmp	00135$
      007374                       1351 00132$:
      007374 8F 82            [24] 1352 	mov	dpl, r7
      007376 12 77 01         [24] 1353 	lcall	_default_layer_and
      007379 02 74 5E         [24] 1354 	ljmp	00181$
                                   1355 ;	quantum/action.c:644: case OP_BIT_OR: default_layer_or(bits); break;
      00737C                       1356 00133$:
      00737C 8F 82            [24] 1357 	mov	dpl, r7
      00737E 12 76 F0         [24] 1358 	lcall	_default_layer_or
      007381 02 74 5E         [24] 1359 	ljmp	00181$
                                   1360 ;	quantum/action.c:645: case OP_BIT_XOR: default_layer_xor(bits); break;
      007384                       1361 00134$:
      007384 8F 82            [24] 1362 	mov	dpl, r7
      007386 12 77 17         [24] 1363 	lcall	_default_layer_xor
      007389 02 74 5E         [24] 1364 	ljmp	00181$
                                   1365 ;	quantum/action.c:646: case OP_BIT_SET: default_layer_set(bits); break;
      00738C                       1366 00135$:
      00738C 8F 82            [24] 1367 	mov	dpl, r7
      00738E 12 76 E5         [24] 1368 	lcall	_default_layer_set
                                   1369 ;	quantum/action.c:647: }
      007391 02 74 5E         [24] 1370 	ljmp	00181$
      007394                       1371 00143$:
                                   1372 ;	quantum/action.c:649: switch (action.layer_bitop.op) {
      007394 12 76 7C         [24] 1373 	lcall	_ak820_outline_0089
      007397 FE               [12] 1374 	mov	r6,a
      007398 2E               [12] 1375 	add	a,r6
                                   1376 ;	quantum/action.c:650: case OP_BIT_AND: layer_and(bits); break;
      007399 90 73 9D         [24] 1377 	mov	dptr,#00466$
      00739C 73               [24] 1378 	jmp	@a+dptr
      00739D                       1379 00466$:
      00739D 80 06            [24] 1380 	sjmp	00137$
      00739F 80 0C            [24] 1381 	sjmp	00138$
      0073A1 80 12            [24] 1382 	sjmp	00139$
      0073A3 80 18            [24] 1383 	sjmp	00140$
      0073A5                       1384 00137$:
      0073A5 8F 82            [24] 1385 	mov	dpl, r7
      0073A7 12 78 9B         [24] 1386 	lcall	_layer_and
      0073AA 02 74 5E         [24] 1387 	ljmp	00181$
                                   1388 ;	quantum/action.c:651: case OP_BIT_OR: layer_or(bits); break;
      0073AD                       1389 00138$:
      0073AD 8F 82            [24] 1390 	mov	dpl, r7
      0073AF 12 78 8A         [24] 1391 	lcall	_layer_or
      0073B2 02 74 5E         [24] 1392 	ljmp	00181$
                                   1393 ;	quantum/action.c:652: case OP_BIT_XOR: layer_xor(bits); break;
      0073B5                       1394 00139$:
      0073B5 8F 82            [24] 1395 	mov	dpl, r7
      0073B7 12 78 B1         [24] 1396 	lcall	_layer_xor
      0073BA 02 74 5E         [24] 1397 	ljmp	00181$
                                   1398 ;	quantum/action.c:653: case OP_BIT_SET: layer_state_set(bits); break;
      0073BD                       1399 00140$:
      0073BD 8F 82            [24] 1400 	mov	dpl, r7
      0073BF 12 78 27         [24] 1401 	lcall	_layer_state_set
                                   1402 ;	quantum/action.c:657: break;
      0073C2 02 74 5E         [24] 1403 	ljmp	00181$
                                   1404 ;	quantum/action.c:659: case ACT_LAYER_MODS:
      0073C5                       1405 00147$:
                                   1406 ;	quantum/action.c:660: if (pressed) {
      0073C5 E5 18            [12] 1407 	mov	a,_process_action_sloc0_1_0
      0073C7 60 11            [24] 1408 	jz	00149$
                                   1409 ;	quantum/action.c:661: layer_hold_on(action.layer_mods.layer);
      0073C9 12 76 85         [24] 1410 	lcall	_ak820_outline_0114
      0073CC F5 82            [12] 1411 	mov	dpl,a
      0073CE 12 77 87         [24] 1412 	lcall	_layer_hold_on
                                   1413 ;	quantum/action.c:662: register_mods(action.layer_mods.mods);
      0073D1 12 76 75         [24] 1414 	lcall	_ak820_outline_0077
      0073D4 12 75 98         [24] 1415 	lcall	_register_mods
      0073D7 02 74 5E         [24] 1416 	ljmp	00181$
      0073DA                       1417 00149$:
                                   1418 ;	quantum/action.c:664: unregister_mods(action.layer_mods.mods);
      0073DA 12 76 75         [24] 1419 	lcall	_ak820_outline_0077
      0073DD 12 75 AC         [24] 1420 	lcall	_unregister_mods
                                   1421 ;	quantum/action.c:665: layer_hold_off(action.layer_mods.layer);
      0073E0 12 76 85         [24] 1422 	lcall	_ak820_outline_0114
      0073E3 F5 82            [12] 1423 	mov	dpl,a
      0073E5 12 77 BF         [24] 1424 	lcall	_layer_hold_off
                                   1425 ;	quantum/action.c:667: break;
      0073E8 02 74 5E         [24] 1426 	ljmp	00181$
                                   1427 ;	quantum/action.c:669: case ACT_LAYER_TAP_EXT:
      0073EB                       1428 00152$:
                                   1429 ;	quantum/action.c:670: switch (action.layer_tap.code) {
      0073EB 12 76 A1         [24] 1430 	lcall	_ak820_outline_0161
      0073EE FF               [12] 1431 	mov	r7,a
      0073EF BF F1 02         [24] 1432 	cjne	r7,#0xf1,00468$
      0073F2 80 0A            [24] 1433 	sjmp	00154$
      0073F4                       1434 00468$:
      0073F4 BF F2 02         [24] 1435 	cjne	r7,#0xf2,00469$
      0073F7 80 19            [24] 1436 	sjmp	00155$
      0073F9                       1437 00469$:
                                   1438 ;	quantum/action.c:686: momentary_layer_action:
      0073F9 BF F3 3B         [24] 1439 	cjne	r7,#0xf3,00160$
      0073FC 80 28            [24] 1440 	sjmp	00156$
      0073FE                       1441 00154$:
                                   1442 ;	quantum/action.c:687: pressed ? layer_hold_on(action.layer_tap.val) : layer_hold_off(action.layer_tap.val);
      0073FE E5 18            [12] 1443 	mov	a,_process_action_sloc0_1_0
      007400 60 08            [24] 1444 	jz	00206$
      007402 12 76 5B         [24] 1445 	lcall	_ak820_outline_0042
      007405 12 77 87         [24] 1446 	lcall	_layer_hold_on
      007408 80 54            [24] 1447 	sjmp	00181$
      00740A                       1448 00206$:
      00740A 12 76 5B         [24] 1449 	lcall	_ak820_outline_0042
      00740D 12 77 BF         [24] 1450 	lcall	_layer_hold_off
                                   1451 ;	quantum/action.c:688: break;
                                   1452 ;	quantum/action.c:689: case OP_OFF_ON:
      007410 80 4C            [24] 1453 	sjmp	00181$
      007412                       1454 00155$:
                                   1455 ;	quantum/action.c:690: pressed ? layer_off(action.layer_tap.val) : layer_on(action.layer_tap.val);
      007412 E5 18            [12] 1456 	mov	a,_process_action_sloc0_1_0
      007414 60 08            [24] 1457 	jz	00208$
      007416 12 76 5B         [24] 1458 	lcall	_ak820_outline_0042
      007419 12 78 6C         [24] 1459 	lcall	_layer_off
      00741C 80 40            [24] 1460 	sjmp	00181$
      00741E                       1461 00208$:
      00741E 12 76 5B         [24] 1462 	lcall	_ak820_outline_0042
      007421 12 78 51         [24] 1463 	lcall	_layer_on
                                   1464 ;	quantum/action.c:691: break;
                                   1465 ;	quantum/action.c:692: case OP_SET_CLEAR:
      007424 80 38            [24] 1466 	sjmp	00181$
      007426                       1467 00156$:
                                   1468 ;	quantum/action.c:693: pressed ? layer_move(action.layer_tap.val) : layer_clear();
      007426 E5 18            [12] 1469 	mov	a,_process_action_sloc0_1_0
      007428 60 08            [24] 1470 	jz	00210$
      00742A 12 76 5B         [24] 1471 	lcall	_ak820_outline_0042
      00742D 12 78 3B         [24] 1472 	lcall	_layer_move
      007430 80 2C            [24] 1473 	sjmp	00181$
      007432                       1474 00210$:
      007432 12 78 35         [24] 1475 	lcall	_layer_clear
                                   1476 ;	quantum/action.c:694: break;
                                   1477 ;	quantum/action.c:740: default:
      007435 80 27            [24] 1478 	sjmp	00181$
      007437                       1479 00160$:
                                   1480 ;	quantum/action.c:747: if (pressed) {
      007437 E5 18            [12] 1481 	mov	a,_process_action_sloc0_1_0
      007439 60 08            [24] 1482 	jz	00163$
                                   1483 ;	quantum/action.c:749: register_code(action.layer_tap.code);
      00743B 12 76 75         [24] 1484 	lcall	_ak820_outline_0077
      00743E 12 74 75         [24] 1485 	lcall	_register_code
                                   1486 ;	quantum/action.c:751: ac_dprintf("KEYMAP_TAP_KEY: Tap: unregister_code\n");
      007441 80 1B            [24] 1487 	sjmp	00181$
      007443                       1488 00163$:
                                   1489 ;	quantum/action.c:752: if (action.layer_tap.code == KC_CAPS) {
      007443 12 76 A1         [24] 1490 	lcall	_ak820_outline_0161
      007446 FF               [12] 1491 	mov	r7,a
      007447 BF 39 0E         [24] 1492 	cjne	r7,#0x39,00175$
                                   1493 ;	quantum/action.c:753: wait_ms(TAP_HOLD_CAPS_DELAY);
      00744A 7F 50            [12] 1494 	mov	r7,#0x50
      00744C                       1495 00187$:
      00744C EF               [12] 1496 	mov	a,r7
      00744D 60 09            [24] 1497 	jz	00175$
      00744F 90 00 01         [24] 1498 	mov	dptr,#0x0001
      007452 12 58 44         [24] 1499 	lcall	_mDelaymS
      007455 1F               [12] 1500 	dec	r7
                                   1501 ;	quantum/action.c:755: wait_ms(TAP_CODE_DELAY);
      007456 80 F4            [24] 1502 	sjmp	00187$
      007458                       1503 00175$:
                                   1504 ;	quantum/action.c:757: unregister_code(action.layer_tap.code);
      007458 12 76 75         [24] 1505 	lcall	_ak820_outline_0077
      00745B 12 74 E2         [24] 1506 	lcall	_unregister_code
                                   1507 ;	quantum/action.c:840: }
      00745E                       1508 00181$:
                                   1509 ;	quantum/action.c:861: switch (action.kind.id) {
      00745E 90 08 34         [24] 1510 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007461 E0               [24] 1511 	movx	a,@dptr
      007462 C4               [12] 1512 	swap	a
      007463 54 0F            [12] 1513 	anl	a,#0x0f
      007465 FF               [12] 1514 	mov	r7,a
      007466 BF 08 02         [24] 1515 	cjne	r7,#0x08,00478$
      007469 80 03            [24] 1516 	sjmp	00183$
      00746B                       1517 00478$:
      00746B BF 09 06         [24] 1518 	cjne	r7,#0x09,00192$
                                   1519 ;	quantum/action.c:863: case ACT_LAYER_MODS:
      00746E                       1520 00183$:
                                   1521 ;	quantum/action.c:868: led_set(host_keyboard_leds());
      00746E 12 6B CF         [24] 1522 	lcall	_host_keyboard_leds
                                   1523 ;	quantum/action.c:872: }
                                   1524 ;	quantum/action.c:925: }
      007471 02 96 92         [24] 1525 	ljmp	_led_set
      007474                       1526 00192$:
      007474 22               [24] 1527 	ret
                                   1528 ;------------------------------------------------------------
                                   1529 ;Allocation info for local variables in function 'register_code'
                                   1530 ;------------------------------------------------------------
                                   1531 ;code          Allocated with name '_register_code_code_10000_709'
                                   1532 ;------------------------------------------------------------
                                   1533 ;	quantum/action.c:931: __attribute__((weak)) void register_code(uint8_t code) {
                                   1534 ;	-----------------------------------------
                                   1535 ;	 function register_code
                                   1536 ;	-----------------------------------------
      007475                       1537 _register_code:
      007475 E5 82            [12] 1538 	mov	a,dpl
      007477 90 08 39         [24] 1539 	mov	dptr,#_register_code_code_10000_709
      00747A F0               [24] 1540 	movx	@dptr,a
                                   1541 ;	quantum/action.c:932: if (code == KC_NO) {
      00747B E0               [24] 1542 	movx	a,@dptr
      00747C FF               [12] 1543 	mov	r7,a
      00747D 70 01            [24] 1544 	jnz	00123$
                                   1545 ;	quantum/action.c:933: return;
      00747F 22               [24] 1546 	ret
      007480                       1547 00123$:
                                   1548 ;	quantum/action.c:968: } else if (IS_BASIC_KEYCODE(code)) {
      007480 BF 04 00         [24] 1549 	cjne	r7,#0x04,00186$
      007483                       1550 00186$:
      007483 40 12            [24] 1551 	jc	00119$
      007485 EF               [12] 1552 	mov	a,r7
      007486 24 5B            [12] 1553 	add	a,#0xff - 0xa4
      007488 40 0D            [24] 1554 	jc	00119$
                                   1555 ;	free result
                                   1556 ;	quantum/action.c:973: if (!add_owned_key(code)) return;
      00748A 8F 82            [24] 1557 	mov	dpl, r7
      00748C 12 7C B1         [24] 1558 	lcall	_add_owned_key
      00748F E5 82            [12] 1559 	mov	a, dpl
      007491 70 01            [24] 1560 	jnz	00104$
      007493 22               [24] 1561 	ret
      007494                       1562 00104$:
                                   1563 ;	quantum/action.c:987: send_keyboard_report();
      007494 02 7F 4F         [24] 1564 	ljmp	_send_keyboard_report
      007497                       1565 00119$:
                                   1566 ;	quantum/action.c:988: } else if (IS_MODIFIER_KEYCODE(code)) {
      007497 12 76 A6         [24] 1567 	lcall	_ak820_outline_0169
      00749A BF E0 00         [24] 1568 	cjne	r7,#0xe0,00190$
      00749D                       1569 00190$:
      00749D 40 1A            [24] 1570 	jc	00115$
      00749F EF               [12] 1571 	mov	a,r7
      0074A0 24 18            [12] 1572 	add	a,#0xff - 0xe7
      0074A2 40 15            [24] 1573 	jc	00115$
                                   1574 ;	free result
                                   1575 ;	quantum/action.c:989: add_owned_mods(MOD_BIT(code));
      0074A4 74 07            [12] 1576 	mov	a,#0x07
      0074A6 5F               [12] 1577 	anl	a,r7
      0074A7 12 76 64         [24] 1578 	lcall	_ak820_outline_0063
      0074AA 80 02            [24] 1579 	sjmp	00194$
      0074AC                       1580 00193$:
      0074AC 25 E0            [12] 1581 	add	a,acc
      0074AE                       1582 00194$:
      0074AE D5 F0 FB         [24] 1583 	djnz	b,00193$
      0074B1 F5 82            [12] 1584 	mov	dpl,a
      0074B3 12 7C 0D         [24] 1585 	lcall	_add_owned_mods
                                   1586 ;	quantum/action.c:990: send_keyboard_report();
      0074B6 02 7F 4F         [24] 1587 	ljmp	_send_keyboard_report
      0074B9                       1588 00115$:
                                   1589 ;	quantum/action.c:993: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      0074B9 12 76 A6         [24] 1590 	lcall	_ak820_outline_0169
      0074BC BF A5 00         [24] 1591 	cjne	r7,#0xa5,00195$
      0074BF                       1592 00195$:
      0074BF 40 05            [24] 1593 	jc	00113$
      0074C1 EF               [12] 1594 	mov	a,r7
      0074C2 24 58            [12] 1595 	add	a,#0xff - 0xa7
      0074C4 50 0D            [24] 1596 	jnc	00108$
                                   1597 ;	free result
      0074C6                       1598 00113$:
      0074C6 12 76 A6         [24] 1599 	lcall	_ak820_outline_0169
      0074C9 BF A8 00         [24] 1600 	cjne	r7,#0xa8,00198$
      0074CC                       1601 00198$:
      0074CC 40 13            [24] 1602 	jc	00125$
      0074CE EF               [12] 1603 	mov	a,r7
      0074CF 24 3D            [12] 1604 	add	a,#0xff - 0xc2
      0074D1 40 0E            [24] 1605 	jc	00125$
                                   1606 ;	free result
      0074D3                       1607 00108$:
                                   1608 ;	quantum/action.c:995: owned_usage_key(code, true);
      0074D3 12 76 A6         [24] 1609 	lcall	_ak820_outline_0169
      0074D6 90 0A 94         [24] 1610 	mov	dptr,#_owned_usage_key_PARM_2
      0074D9 74 01            [12] 1611 	mov	a,#0x01
      0074DB F0               [24] 1612 	movx	@dptr,a
      0074DC 8F 82            [24] 1613 	mov	dpl, r7
                                   1614 ;	quantum/action.c:1003: register_mouse(code, true);
                                   1615 ;	quantum/action.c:1005: }
      0074DE 02 7D FA         [24] 1616 	ljmp	_owned_usage_key
      0074E1                       1617 00125$:
      0074E1 22               [24] 1618 	ret
                                   1619 ;------------------------------------------------------------
                                   1620 ;Allocation info for local variables in function 'unregister_code'
                                   1621 ;------------------------------------------------------------
                                   1622 ;code          Allocated with name '_unregister_code_code_10000_723'
                                   1623 ;------------------------------------------------------------
                                   1624 ;	quantum/action.c:1011: __attribute__((weak)) void unregister_code(uint8_t code) {
                                   1625 ;	-----------------------------------------
                                   1626 ;	 function unregister_code
                                   1627 ;	-----------------------------------------
      0074E2                       1628 _unregister_code:
      0074E2 E5 82            [12] 1629 	mov	a,dpl
      0074E4 90 08 3A         [24] 1630 	mov	dptr,#_unregister_code_code_10000_723
      0074E7 F0               [24] 1631 	movx	@dptr,a
                                   1632 ;	quantum/action.c:1012: if (code == KC_NO) {
      0074E8 E0               [24] 1633 	movx	a,@dptr
      0074E9 FF               [12] 1634 	mov	r7,a
      0074EA 70 01            [24] 1635 	jnz	00121$
                                   1636 ;	quantum/action.c:1013: return;
      0074EC 22               [24] 1637 	ret
      0074ED                       1638 00121$:
                                   1639 ;	quantum/action.c:1045: } else if (IS_BASIC_KEYCODE(code)) {
      0074ED BF 04 00         [24] 1640 	cjne	r7,#0x04,00184$
      0074F0                       1641 00184$:
      0074F0 40 12            [24] 1642 	jc	00117$
      0074F2 EF               [12] 1643 	mov	a,r7
      0074F3 24 5B            [12] 1644 	add	a,#0xff - 0xa4
      0074F5 40 0D            [24] 1645 	jc	00117$
                                   1646 ;	free result
                                   1647 ;	quantum/action.c:1047: if (!del_owned_key(code)) return;
      0074F7 8F 82            [24] 1648 	mov	dpl, r7
      0074F9 12 7D 2E         [24] 1649 	lcall	_del_owned_key
      0074FC E5 82            [12] 1650 	mov	a, dpl
      0074FE 70 01            [24] 1651 	jnz	00102$
      007500 22               [24] 1652 	ret
      007501                       1653 00102$:
                                   1654 ;	quantum/action.c:1054: send_keyboard_report();
      007501 02 7F 4F         [24] 1655 	ljmp	_send_keyboard_report
      007504                       1656 00117$:
                                   1657 ;	quantum/action.c:1055: } else if (IS_MODIFIER_KEYCODE(code)) {
      007504 12 76 AC         [24] 1658 	lcall	_ak820_outline_0170
      007507 BF E0 00         [24] 1659 	cjne	r7,#0xe0,00188$
      00750A                       1660 00188$:
      00750A 40 1A            [24] 1661 	jc	00113$
      00750C EF               [12] 1662 	mov	a,r7
      00750D 24 18            [12] 1663 	add	a,#0xff - 0xe7
      00750F 40 15            [24] 1664 	jc	00113$
                                   1665 ;	free result
                                   1666 ;	quantum/action.c:1056: del_owned_mods(MOD_BIT(code));
      007511 74 07            [12] 1667 	mov	a,#0x07
      007513 5F               [12] 1668 	anl	a,r7
      007514 12 76 64         [24] 1669 	lcall	_ak820_outline_0063
      007517 80 02            [24] 1670 	sjmp	00192$
      007519                       1671 00191$:
      007519 25 E0            [12] 1672 	add	a,acc
      00751B                       1673 00192$:
      00751B D5 F0 FB         [24] 1674 	djnz	b,00191$
      00751E F5 82            [12] 1675 	mov	dpl,a
      007520 12 7C 1D         [24] 1676 	lcall	_del_owned_mods
                                   1677 ;	quantum/action.c:1057: send_keyboard_report();
      007523 02 7F 4F         [24] 1678 	ljmp	_send_keyboard_report
      007526                       1679 00113$:
                                   1680 ;	quantum/action.c:1060: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      007526 12 76 AC         [24] 1681 	lcall	_ak820_outline_0170
      007529 BF A5 00         [24] 1682 	cjne	r7,#0xa5,00193$
      00752C                       1683 00193$:
      00752C 40 05            [24] 1684 	jc	00111$
      00752E EF               [12] 1685 	mov	a,r7
      00752F 24 58            [12] 1686 	add	a,#0xff - 0xa7
      007531 50 0D            [24] 1687 	jnc	00106$
                                   1688 ;	free result
      007533                       1689 00111$:
      007533 12 76 AC         [24] 1690 	lcall	_ak820_outline_0170
      007536 BF A8 00         [24] 1691 	cjne	r7,#0xa8,00196$
      007539                       1692 00196$:
      007539 40 12            [24] 1693 	jc	00123$
      00753B EF               [12] 1694 	mov	a,r7
      00753C 24 3D            [12] 1695 	add	a,#0xff - 0xc2
      00753E 40 0D            [24] 1696 	jc	00123$
                                   1697 ;	free result
      007540                       1698 00106$:
                                   1699 ;	quantum/action.c:1062: owned_usage_key(code, false);
      007540 12 76 AC         [24] 1700 	lcall	_ak820_outline_0170
      007543 90 0A 94         [24] 1701 	mov	dptr,#_owned_usage_key_PARM_2
      007546 E4               [12] 1702 	clr	a
      007547 F0               [24] 1703 	movx	@dptr,a
      007548 8F 82            [24] 1704 	mov	dpl, r7
                                   1705 ;	quantum/action.c:1070: register_mouse(code, false);
                                   1706 ;	quantum/action.c:1072: }
      00754A 02 7D FA         [24] 1707 	ljmp	_owned_usage_key
      00754D                       1708 00123$:
      00754D 22               [24] 1709 	ret
                                   1710 ;------------------------------------------------------------
                                   1711 ;Allocation info for local variables in function 'tap_code_delay'
                                   1712 ;------------------------------------------------------------
                                   1713 ;delay         Allocated with name '_tap_code_delay_PARM_2'
                                   1714 ;code          Allocated with name '_tap_code_delay_code_10000_736'
                                   1715 ;i             Allocated with name '_tap_code_delay_i_20000_738'
                                   1716 ;i             Allocated with name '_tap_code_delay_i_50000_741'
                                   1717 ;------------------------------------------------------------
                                   1718 ;	quantum/action.c:1079: __attribute__((weak)) void tap_code_delay(uint8_t code, uint16_t delay) {
                                   1719 ;	-----------------------------------------
                                   1720 ;	 function tap_code_delay
                                   1721 ;	-----------------------------------------
      00754E                       1722 _tap_code_delay:
      00754E E5 82            [12] 1723 	mov	a,dpl
      007550 90 08 3D         [24] 1724 	mov	dptr,#_tap_code_delay_code_10000_736
      007553 F0               [24] 1725 	movx	@dptr,a
                                   1726 ;	quantum/action.c:1080: register_code(code);
      007554 E0               [24] 1727 	movx	a,@dptr
      007555 FF               [12] 1728 	mov	r7,a
      007556 F5 82            [12] 1729 	mov	dpl,a
      007558 C0 07            [24] 1730 	push	ar7
      00755A 12 74 75         [24] 1731 	lcall	_register_code
      00755D D0 07            [24] 1732 	pop	ar7
                                   1733 ;	quantum/action.c:1081: for (uint16_t i = delay; i > 0; i--) {
      00755F 90 08 3B         [24] 1734 	mov	dptr,#_tap_code_delay_PARM_2
      007562 12 38 64         [24] 1735 	lcall	_ak820_outline_0079
      007565                       1736 00110$:
      007565 ED               [12] 1737 	mov	a,r5
      007566 4E               [12] 1738 	orl	a,r6
      007567 60 0D            [24] 1739 	jz	00105$
                                   1740 ;	quantum/action.c:1082: wait_ms(1);
      007569 90 00 01         [24] 1741 	mov	dptr,#0x0001
      00756C 12 58 44         [24] 1742 	lcall	_mDelaymS
                                   1743 ;	quantum/action.c:1081: for (uint16_t i = delay; i > 0; i--) {
      00756F 1D               [12] 1744 	dec	r5
      007570 BD FF 01         [24] 1745 	cjne	r5,#0xff,00141$
      007573 1E               [12] 1746 	dec	r6
      007574                       1747 00141$:
      007574 80 EF            [24] 1748 	sjmp	00110$
      007576                       1749 00105$:
                                   1750 ;	quantum/action.c:1084: unregister_code(code);
      007576 8F 82            [24] 1751 	mov	dpl, r7
                                   1752 ;	quantum/action.c:1085: }
      007578 02 74 E2         [24] 1753 	ljmp	_unregister_code
                                   1754 ;------------------------------------------------------------
                                   1755 ;Allocation info for local variables in function 'tap_code'
                                   1756 ;------------------------------------------------------------
                                   1757 ;code          Allocated with name '_tap_code_code_10000_743'
                                   1758 ;------------------------------------------------------------
                                   1759 ;	quantum/action.c:1091: __attribute__((weak)) void tap_code(uint8_t code) {
                                   1760 ;	-----------------------------------------
                                   1761 ;	 function tap_code
                                   1762 ;	-----------------------------------------
      00757B                       1763 _tap_code:
      00757B E5 82            [12] 1764 	mov	a,dpl
      00757D 90 08 3E         [24] 1765 	mov	dptr,#_tap_code_code_10000_743
      007580 F0               [24] 1766 	movx	@dptr,a
                                   1767 ;	quantum/action.c:1092: tap_code_delay(code, code == KC_CAPS ? QS_tap_hold_caps_delay : QS_tap_code_delay);
      007581 E0               [24] 1768 	movx	a,@dptr
      007582 FF               [12] 1769 	mov	r7,a
      007583 BF 39 04         [24] 1770 	cjne	r7,#0x39,00103$
      007586 7E 50            [12] 1771 	mov	r6,#0x50
      007588 80 02            [24] 1772 	sjmp	00104$
      00758A                       1773 00103$:
      00758A 7E 00            [12] 1774 	mov	r6,#0x00
      00758C                       1775 00104$:
      00758C 90 08 3B         [24] 1776 	mov	dptr,#_tap_code_delay_PARM_2
      00758F EE               [12] 1777 	mov	a,r6
      007590 12 38 9C         [24] 1778 	lcall	_ak820_outline_0135
      007593 8F 82            [24] 1779 	mov	dpl, r7
                                   1780 ;	quantum/action.c:1093: }
      007595 02 75 4E         [24] 1781 	ljmp	_tap_code_delay
                                   1782 ;------------------------------------------------------------
                                   1783 ;Allocation info for local variables in function 'register_mods'
                                   1784 ;------------------------------------------------------------
                                   1785 ;mods          Allocated with name '_register_mods_mods_10000_745'
                                   1786 ;------------------------------------------------------------
                                   1787 ;	quantum/action.c:1099: __attribute__((weak)) void register_mods(uint8_t mods) {
                                   1788 ;	-----------------------------------------
                                   1789 ;	 function register_mods
                                   1790 ;	-----------------------------------------
      007598                       1791 _register_mods:
      007598 E5 82            [12] 1792 	mov	a,dpl
      00759A 90 08 3F         [24] 1793 	mov	dptr,#_register_mods_mods_10000_745
      00759D F0               [24] 1794 	movx	@dptr,a
                                   1795 ;	quantum/action.c:1100: if (mods) {
      00759E E0               [24] 1796 	movx	a,@dptr
      00759F FF               [12] 1797 	mov	r7,a
      0075A0 E0               [24] 1798 	movx	a,@dptr
      0075A1 60 08            [24] 1799 	jz	00103$
                                   1800 ;	quantum/action.c:1101: add_owned_mods(mods);
      0075A3 8F 82            [24] 1801 	mov	dpl, r7
      0075A5 12 7C 0D         [24] 1802 	lcall	_add_owned_mods
                                   1803 ;	quantum/action.c:1102: send_keyboard_report();
                                   1804 ;	quantum/action.c:1104: }
      0075A8 02 7F 4F         [24] 1805 	ljmp	_send_keyboard_report
      0075AB                       1806 00103$:
      0075AB 22               [24] 1807 	ret
                                   1808 ;------------------------------------------------------------
                                   1809 ;Allocation info for local variables in function 'unregister_mods'
                                   1810 ;------------------------------------------------------------
                                   1811 ;mods          Allocated with name '_unregister_mods_mods_10000_749'
                                   1812 ;------------------------------------------------------------
                                   1813 ;	quantum/action.c:1110: __attribute__((weak)) void unregister_mods(uint8_t mods) {
                                   1814 ;	-----------------------------------------
                                   1815 ;	 function unregister_mods
                                   1816 ;	-----------------------------------------
      0075AC                       1817 _unregister_mods:
      0075AC E5 82            [12] 1818 	mov	a,dpl
      0075AE 90 08 40         [24] 1819 	mov	dptr,#_unregister_mods_mods_10000_749
      0075B1 F0               [24] 1820 	movx	@dptr,a
                                   1821 ;	quantum/action.c:1111: if (mods) {
      0075B2 E0               [24] 1822 	movx	a,@dptr
      0075B3 FF               [12] 1823 	mov	r7,a
      0075B4 E0               [24] 1824 	movx	a,@dptr
      0075B5 60 08            [24] 1825 	jz	00103$
                                   1826 ;	quantum/action.c:1112: del_owned_mods(mods);
      0075B7 8F 82            [24] 1827 	mov	dpl, r7
      0075B9 12 7C 1D         [24] 1828 	lcall	_del_owned_mods
                                   1829 ;	quantum/action.c:1113: send_keyboard_report();
                                   1830 ;	quantum/action.c:1115: }
      0075BC 02 7F 4F         [24] 1831 	ljmp	_send_keyboard_report
      0075BF                       1832 00103$:
      0075BF 22               [24] 1833 	ret
                                   1834 ;------------------------------------------------------------
                                   1835 ;Allocation info for local variables in function 'register_weak_mods'
                                   1836 ;------------------------------------------------------------
                                   1837 ;mods          Allocated with name '_register_weak_mods_mods_10000_753'
                                   1838 ;------------------------------------------------------------
                                   1839 ;	quantum/action.c:1121: __attribute__((weak)) void register_weak_mods(uint8_t mods) {
                                   1840 ;	-----------------------------------------
                                   1841 ;	 function register_weak_mods
                                   1842 ;	-----------------------------------------
      0075C0                       1843 _register_weak_mods:
      0075C0 E5 82            [12] 1844 	mov	a,dpl
      0075C2 90 08 41         [24] 1845 	mov	dptr,#_register_weak_mods_mods_10000_753
      0075C5 F0               [24] 1846 	movx	@dptr,a
                                   1847 ;	quantum/action.c:1122: if (mods) {
      0075C6 E0               [24] 1848 	movx	a,@dptr
      0075C7 FF               [12] 1849 	mov	r7,a
      0075C8 E0               [24] 1850 	movx	a,@dptr
      0075C9 60 08            [24] 1851 	jz	00103$
                                   1852 ;	quantum/action.c:1123: add_owned_weak_mods(mods);
      0075CB 8F 82            [24] 1853 	mov	dpl, r7
      0075CD 12 7C 2C         [24] 1854 	lcall	_add_owned_weak_mods
                                   1855 ;	quantum/action.c:1124: send_keyboard_report();
                                   1856 ;	quantum/action.c:1126: }
      0075D0 02 7F 4F         [24] 1857 	ljmp	_send_keyboard_report
      0075D3                       1858 00103$:
      0075D3 22               [24] 1859 	ret
                                   1860 ;------------------------------------------------------------
                                   1861 ;Allocation info for local variables in function 'unregister_weak_mods'
                                   1862 ;------------------------------------------------------------
                                   1863 ;mods          Allocated with name '_unregister_weak_mods_mods_10000_757'
                                   1864 ;------------------------------------------------------------
                                   1865 ;	quantum/action.c:1132: __attribute__((weak)) void unregister_weak_mods(uint8_t mods) {
                                   1866 ;	-----------------------------------------
                                   1867 ;	 function unregister_weak_mods
                                   1868 ;	-----------------------------------------
      0075D4                       1869 _unregister_weak_mods:
      0075D4 E5 82            [12] 1870 	mov	a,dpl
      0075D6 90 08 42         [24] 1871 	mov	dptr,#_unregister_weak_mods_mods_10000_757
      0075D9 F0               [24] 1872 	movx	@dptr,a
                                   1873 ;	quantum/action.c:1133: if (mods) {
      0075DA E0               [24] 1874 	movx	a,@dptr
      0075DB FF               [12] 1875 	mov	r7,a
      0075DC E0               [24] 1876 	movx	a,@dptr
      0075DD 60 08            [24] 1877 	jz	00103$
                                   1878 ;	quantum/action.c:1134: del_owned_weak_mods(mods);
      0075DF 8F 82            [24] 1879 	mov	dpl, r7
      0075E1 12 7C 3C         [24] 1880 	lcall	_del_owned_weak_mods
                                   1881 ;	quantum/action.c:1135: send_keyboard_report();
                                   1882 ;	quantum/action.c:1137: }
      0075E4 02 7F 4F         [24] 1883 	ljmp	_send_keyboard_report
      0075E7                       1884 00103$:
      0075E7 22               [24] 1885 	ret
                                   1886 ;------------------------------------------------------------
                                   1887 ;Allocation info for local variables in function 'clear_keyboard'
                                   1888 ;------------------------------------------------------------
                                   1889 ;	quantum/action.c:1143: void clear_keyboard(void) {
                                   1890 ;	-----------------------------------------
                                   1891 ;	 function clear_keyboard
                                   1892 ;	-----------------------------------------
      0075E8                       1893 _clear_keyboard:
                                   1894 ;	quantum/action.c:1144: clear_mods();
      0075E8 12 7F CA         [24] 1895 	lcall	_clear_mods
                                   1896 ;	quantum/action.c:1145: clear_keyboard_but_mods();
                                   1897 ;	quantum/action.c:1146: }
      0075EB 02 75 EE         [24] 1898 	ljmp	_clear_keyboard_but_mods
                                   1899 ;------------------------------------------------------------
                                   1900 ;Allocation info for local variables in function 'clear_keyboard_but_mods'
                                   1901 ;------------------------------------------------------------
                                   1902 ;	quantum/action.c:1152: void clear_keyboard_but_mods(void) {
                                   1903 ;	-----------------------------------------
                                   1904 ;	 function clear_keyboard_but_mods
                                   1905 ;	-----------------------------------------
      0075EE                       1906 _clear_keyboard_but_mods:
                                   1907 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      0075EE 90 0D C6         [24] 1908 	mov	dptr,#_actual_keyboard_report
      0075F1 75 F0 00         [24] 1909 	mov	b, #0x00
      0075F4 12 6E A4         [24] 1910 	lcall	_clear_keys_from_report
                                   1911 ;	quantum/action.c:1154: clear_keyboard_but_mods_and_keys();
                                   1912 ;	quantum/action.c:1155: }
      0075F7 02 75 FA         [24] 1913 	ljmp	_clear_keyboard_but_mods_and_keys
                                   1914 ;------------------------------------------------------------
                                   1915 ;Allocation info for local variables in function 'clear_keyboard_but_mods_and_keys'
                                   1916 ;------------------------------------------------------------
                                   1917 ;	quantum/action.c:1161: void clear_keyboard_but_mods_and_keys(void) {
                                   1918 ;	-----------------------------------------
                                   1919 ;	 function clear_keyboard_but_mods_and_keys
                                   1920 ;	-----------------------------------------
      0075FA                       1921 _clear_keyboard_but_mods_and_keys:
                                   1922 ;	quantum/action.c:1163: ak820_tapping_cancel();
      0075FA 12 46 60         [24] 1923 	lcall	_ak820_tapping_cancel
                                   1924 ;	quantum/action.c:1171: ak820_oneshot_cancel();
      0075FD 12 2E F0         [24] 1925 	lcall	_ak820_oneshot_cancel
                                   1926 ;	quantum/action.c:1174: ak820_combo_cancel();
      007600 12 35 70         [24] 1927 	lcall	_ak820_combo_cancel
                                   1928 ;	quantum/action.c:1177: repeat_key_cancel();
      007603 12 A0 85         [24] 1929 	lcall	_repeat_key_cancel
                                   1930 ;	quantum/action.c:1179: clear_owned_mods();
      007606 12 7C 4C         [24] 1931 	lcall	_clear_owned_mods
                                   1932 ;	quantum/action.c:1180: clear_owned_keys();
      007609 12 7C 84         [24] 1933 	lcall	_clear_owned_keys
                                   1934 ;	quantum/action.c:1181: clear_owned_usages();
      00760C 12 7D C2         [24] 1935 	lcall	_clear_owned_usages
                                   1936 ;	quantum/action.c:1182: layer_hold_clear();
      00760F 12 77 F8         [24] 1937 	lcall	_layer_hold_clear
                                   1938 ;	quantum/action.c:1184: clear_macro_tri_layer();
      007612 12 9B 48         [24] 1939 	lcall	_clear_macro_tri_layer
                                   1940 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007615 90 0D C6         [24] 1941 	mov	dptr,#_actual_keyboard_report
      007618 75 F0 00         [24] 1942 	mov	b, #0x00
      00761B 12 6E A4         [24] 1943 	lcall	_clear_keys_from_report
                                   1944 ;	quantum/action.c:1189: host_system_send(0);
      00761E 90 00 00         [24] 1945 	mov	dptr,#0x0000
      007621 12 6C 6A         [24] 1946 	lcall	_host_system_send
                                   1947 ;	quantum/action.c:1190: host_consumer_send(0);
      007624 90 00 00         [24] 1948 	mov	dptr,#0x0000
      007627 12 6C 9A         [24] 1949 	lcall	_host_consumer_send
                                   1950 ;	quantum/action.c:1192: clear_weak_mods();
      00762A 12 7F FF         [24] 1951 	lcall	_clear_weak_mods
                                   1952 ;	quantum/action.c:1193: send_keyboard_report();
                                   1953 ;	quantum/action.c:1201: }
      00762D 02 7F 4F         [24] 1954 	ljmp	_send_keyboard_report
                                   1955 ;------------------------------------------------------------
                                   1956 ;Allocation info for local variables in function 'is_tap_record'
                                   1957 ;------------------------------------------------------------
                                   1958 ;record        Allocated with name '_is_tap_record_record_10000_773'
                                   1959 ;action        Allocated with name '_is_tap_record_action_10001_777'
                                   1960 ;------------------------------------------------------------
                                   1961 ;	quantum/action.c:1207: bool is_tap_record(keyrecord_t *record) {
                                   1962 ;	-----------------------------------------
                                   1963 	.area CSEG    (CODE)
                                   1964 	.area CONST   (CODE)
                                   1965 	.area XINIT   (CODE)
      00C00A                       1966 __xinit__disable_action_cache:
      00C00A 00                    1967 	.db #0x00	;  0
                                   1968 	.area CABS    (ABS,CODE)
                                   1969 
                                   1970 ; Experimental exact instruction outlining.
                                   1971 	.globl _ak820_outline_0001
                                   1972 	.globl _ak820_outline_0005
                                   1973 	.globl _ak820_outline_0007
                                   1974 	.globl _ak820_outline_0008
                                   1975 	.globl _ak820_outline_0011
                                   1976 	.globl _ak820_outline_0012
                                   1977 	.globl _ak820_outline_0013
                                   1978 	.globl _ak820_outline_0014
                                   1979 	.globl _ak820_outline_0015
                                   1980 	.globl _ak820_outline_0021
                                   1981 	.globl _ak820_outline_0023
                                   1982 	.globl _ak820_outline_0033
                                   1983 	.globl _ak820_outline_0036
                                   1984 	.globl _ak820_outline_0042
                                   1985 	.globl _ak820_outline_0050
                                   1986 	.globl _ak820_outline_0059
                                   1987 	.globl _ak820_outline_0063
                                   1988 	.globl _ak820_outline_0071
                                   1989 	.globl _ak820_outline_0072
                                   1990 	.globl _ak820_outline_0077
                                   1991 	.globl _ak820_outline_0079
                                   1992 	.globl _ak820_outline_0089
                                   1993 	.globl _ak820_outline_0093
                                   1994 	.globl _ak820_outline_0109
                                   1995 	.globl _ak820_outline_0110
                                   1996 	.globl _ak820_outline_0112
                                   1997 	.globl _ak820_outline_0114
                                   1998 	.globl _ak820_outline_0119
                                   1999 	.globl _ak820_outline_0124
                                   2000 	.globl _ak820_outline_0125
                                   2001 	.globl _ak820_outline_0131
                                   2002 	.globl _ak820_outline_0134
                                   2003 	.globl _ak820_outline_0135
                                   2004 	.globl _ak820_outline_0143
                                   2005 	.globl _ak820_outline_0145
                                   2006 	.globl _ak820_outline_0147
                                   2007 	.globl _ak820_outline_0151
                                   2008 	.globl _ak820_outline_0161
                                   2009 	.globl _ak820_outline_0169
                                   2010 	.globl _ak820_outline_0170
                                   2011 	.globl _ak820_outline_0184
                                   2012 	.globl _ak820_outline_0188
                                   2013 
                                   2014 	.area CSEG (CODE)
                                   2015 ; function ak820_outline_0013
      007630                       2016 _ak820_outline_0013:
      007630 2D               [12] 2017 	add	a,r5
      007631 F9               [12] 2018 	mov	r1,a
      007632 E4               [12] 2019 	clr	a
      007633 3E               [12] 2020 	addc	a,r6
      007634 FA               [12] 2021 	mov	r2,a
      007635 8F 03            [24] 2022 	mov	ar3,r7
      007637 89 82            [24] 2023 	mov	dpl,r1
      007639 8A 83            [24] 2024 	mov	dph,r2
      00763B 8B F0            [24] 2025 	mov	b,r3
      00763D 22               [24] 2026 	ret
                                   2027 
                                   2028 	.area CSEG (CODE)
                                   2029 ; function ak820_outline_0014
      00763E                       2030 _ak820_outline_0014:
      00763E 2D               [12] 2031 	add	a,r5
      00763F FA               [12] 2032 	mov	r2,a
      007640 E4               [12] 2033 	clr	a
      007641 3E               [12] 2034 	addc	a,r6
      007642 FB               [12] 2035 	mov	r3,a
      007643 8F 04            [24] 2036 	mov	ar4,r7
      007645 8A 82            [24] 2037 	mov	dpl,r2
      007647 8B 83            [24] 2038 	mov	dph,r3
      007649 8C F0            [24] 2039 	mov	b,r4
      00764B 22               [24] 2040 	ret
                                   2041 
                                   2042 	.area CSEG (CODE)
                                   2043 ; function ak820_outline_0021
      00764C                       2044 _ak820_outline_0021:
      00764C 8E 82            [24] 2045 	mov	dpl,r6
      00764E 8F 83            [24] 2046 	mov	dph,r7
      007650 A3               [24] 2047 	inc	dptr
      007651 E0               [24] 2048 	movx	a,@dptr
      007652 FC               [12] 2049 	mov	r4,a
      007653 7D 00            [12] 2050 	mov	r5,#0x00
      007655 8E 82            [24] 2051 	mov	dpl,r6
      007657 8F 83            [24] 2052 	mov	dph,r7
      007659 E0               [24] 2053 	movx	a,@dptr
      00765A 22               [24] 2054 	ret
                                   2055 
                                   2056 	.area CSEG (CODE)
                                   2057 ; function ak820_outline_0042
      00765B                       2058 _ak820_outline_0042:
      00765B 90 08 34         [24] 2059 	mov	dptr,#(_process_action_PARM_2+0x0001)
      00765E E0               [24] 2060 	movx	a,@dptr
      00765F 54 1F            [12] 2061 	anl	a,#0x1f
      007661 F5 82            [12] 2062 	mov	dpl,a
      007663 22               [24] 2063 	ret
                                   2064 
                                   2065 	.area CSEG (CODE)
                                   2066 ; function ak820_outline_0063
      007664                       2067 _ak820_outline_0063:
      007664 F5 F0            [12] 2068 	mov	b,a
      007666 05 F0            [12] 2069 	inc	b
      007668 74 01            [12] 2070 	mov	a,#0x01
      00766A 22               [24] 2071 	ret
                                   2072 
                                   2073 	.area CSEG (CODE)
                                   2074 ; function ak820_outline_0071
      00766B                       2075 _ak820_outline_0071:
      00766B 90 0D A4         [24] 2076 	mov	dptr,#___memcpy_PARM_3
      00766E 74 06            [12] 2077 	mov	a,#0x06
      007670 F0               [24] 2078 	movx	@dptr,a
      007671 E4               [12] 2079 	clr	a
      007672 A3               [24] 2080 	inc	dptr
      007673 F0               [24] 2081 	movx	@dptr,a
      007674 22               [24] 2082 	ret
                                   2083 
                                   2084 	.area CSEG (CODE)
                                   2085 ; function ak820_outline_0077
      007675                       2086 _ak820_outline_0077:
      007675 90 08 33         [24] 2087 	mov	dptr,#_process_action_PARM_2
      007678 E0               [24] 2088 	movx	a,@dptr
      007679 F5 82            [12] 2089 	mov	dpl,a
      00767B 22               [24] 2090 	ret
                                   2091 
                                   2092 	.area CSEG (CODE)
                                   2093 ; function ak820_outline_0089
      00767C                       2094 _ak820_outline_0089:
      00767C 90 08 34         [24] 2095 	mov	dptr,#(_process_action_PARM_2+0x0001)
      00767F E0               [24] 2096 	movx	a,@dptr
      007680 03               [12] 2097 	rr	a
      007681 03               [12] 2098 	rr	a
      007682 54 03            [12] 2099 	anl	a,#0x03
      007684 22               [24] 2100 	ret
                                   2101 
                                   2102 	.area CSEG (CODE)
                                   2103 ; function ak820_outline_0114
      007685                       2104 _ak820_outline_0114:
      007685 90 08 34         [24] 2105 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007688 E0               [24] 2106 	movx	a,@dptr
      007689 54 0F            [12] 2107 	anl	a,#0x0f
      00768B 22               [24] 2108 	ret
                                   2109 
                                   2110 	.area CSEG (CODE)
                                   2111 ; function ak820_outline_0131
      00768C                       2112 _ak820_outline_0131:
      00768C 90 08 33         [24] 2113 	mov	dptr,#_process_action_PARM_2
      00768F E0               [24] 2114 	movx	a,@dptr
      007690 FE               [12] 2115 	mov	r6,a
      007691 A3               [24] 2116 	inc	dptr
      007692 E0               [24] 2117 	movx	a,@dptr
      007693 54 03            [12] 2118 	anl	a,#0x03
      007695 FF               [12] 2119 	mov	r7,a
      007696 22               [24] 2120 	ret
                                   2121 
                                   2122 	.area CSEG (CODE)
                                   2123 ; function ak820_outline_0147
      007697                       2124 _ak820_outline_0147:
      007697 74 07            [12] 2125 	mov	a,#0x07
      007699 2D               [12] 2126 	add	a,r5
      00769A F8               [12] 2127 	mov	r0,a
      00769B E4               [12] 2128 	clr	a
      00769C 3E               [12] 2129 	addc	a,r6
      00769D F9               [12] 2130 	mov	r1,a
      00769E 8F 02            [24] 2131 	mov	ar2,r7
      0076A0 22               [24] 2132 	ret
                                   2133 
                                   2134 	.area CSEG (CODE)
                                   2135 ; function ak820_outline_0161
      0076A1                       2136 _ak820_outline_0161:
      0076A1 90 08 33         [24] 2137 	mov	dptr,#_process_action_PARM_2
      0076A4 E0               [24] 2138 	movx	a,@dptr
      0076A5 22               [24] 2139 	ret
                                   2140 
                                   2141 	.area CSEG (CODE)
                                   2142 ; function ak820_outline_0169
      0076A6                       2143 _ak820_outline_0169:
      0076A6 90 08 39         [24] 2144 	mov	dptr,#_register_code_code_10000_709
      0076A9 E0               [24] 2145 	movx	a,@dptr
      0076AA FF               [12] 2146 	mov	r7,a
      0076AB 22               [24] 2147 	ret
                                   2148 
                                   2149 	.area CSEG (CODE)
                                   2150 ; function ak820_outline_0170
      0076AC                       2151 _ak820_outline_0170:
      0076AC 90 08 3A         [24] 2152 	mov	dptr,#_unregister_code_code_10000_723
      0076AF E0               [24] 2153 	movx	a,@dptr
      0076B0 FF               [12] 2154 	mov	r7,a
      0076B1 22               [24] 2155 	ret
                                   2156 
                                   2157 	.area CSEG (CODE)
                                   2158 ; function ak820_outline_0188
      0076B2                       2159 _ak820_outline_0188:
      0076B2 F0               [24] 2160 	movx	@dptr,a
      0076B3 EB               [12] 2161 	mov	a,r3
      0076B4 A3               [24] 2162 	inc	dptr
      0076B5 F0               [24] 2163 	movx	@dptr,a
      0076B6 22               [24] 2164 	ret
