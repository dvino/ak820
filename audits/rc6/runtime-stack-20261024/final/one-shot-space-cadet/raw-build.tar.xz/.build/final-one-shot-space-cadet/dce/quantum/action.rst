                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_combo_cancel
                                     12 	.globl _ak820_combo_tick
                                     13 	.globl _ak820_oneshot_cancel
                                     14 	.globl _ak820_oneshot_post
                                     15 	.globl _ak820_oneshot_process
                                     16 	.globl _ak820_tapping_source
                                     17 	.globl _ak820_tapping_cancel
                                     18 	.globl _ak820_tapping_process
                                     19 	.globl _ak820_tapping_before
                                     20 	.globl _pre_process_record_quantum
                                     21 	.globl _get_record_keycode
                                     22 	.globl _repeat_key_cancel
                                     23 	.globl _clear_owned_usages
                                     24 	.globl _owned_usage_key
                                     25 	.globl _clear_owned_keys
                                     26 	.globl _del_owned_key
                                     27 	.globl _add_owned_key
                                     28 	.globl _clear_owned_mods
                                     29 	.globl _del_owned_weak_mods
                                     30 	.globl _add_owned_weak_mods
                                     31 	.globl _del_owned_mods
                                     32 	.globl _add_owned_mods
                                     33 	.globl _clear_weak_mods
                                     34 	.globl _clear_mods
                                     35 	.globl _send_keyboard_report
                                     36 	.globl _layer_hold_clear
                                     37 	.globl _layer_hold_off
                                     38 	.globl _layer_hold_on
                                     39 	.globl _ak820_resolve_key
                                     40 	.globl _layer_xor
                                     41 	.globl _layer_and
                                     42 	.globl _layer_or
                                     43 	.globl _layer_off
                                     44 	.globl _layer_on
                                     45 	.globl _layer_move
                                     46 	.globl _layer_clear
                                     47 	.globl _layer_state_set
                                     48 	.globl _default_layer_xor
                                     49 	.globl _default_layer_and
                                     50 	.globl _default_layer_or
                                     51 	.globl _default_layer_set
                                     52 	.globl _post_process_record_quantum
                                     53 	.globl _process_record_quantum
                                     54 	.globl _action_for_keycode
                                     55 	.globl _mDelaymS
                                     56 	.globl _host_consumer_send
                                     57 	.globl _host_system_send
                                     58 	.globl _host_keyboard_leds
                                     59 	.globl _led_set
                                     60 	.globl _clear_keys_from_report
                                     61 	.globl ___memcpy
                                     62 	.globl _ADC_START
                                     63 	.globl _S0_R_FIFO
                                     64 	.globl _S0_T_FIFO
                                     65 	.globl _S0_FREE
                                     66 	.globl _S0_IF_BYTE
                                     67 	.globl _S0_IF_FIRST
                                     68 	.globl _S0_IF_OV
                                     69 	.globl _S0_FST_ACT
                                     70 	.globl _CP_RL2
                                     71 	.globl _C_T2
                                     72 	.globl _TR2
                                     73 	.globl _EXEN2
                                     74 	.globl _TCLK
                                     75 	.globl _RCLK
                                     76 	.globl _EXF2
                                     77 	.globl _CAP1F
                                     78 	.globl _TF2
                                     79 	.globl _RI
                                     80 	.globl _TI
                                     81 	.globl _RB8
                                     82 	.globl _TB8
                                     83 	.globl _REN
                                     84 	.globl _SM2
                                     85 	.globl _SM1
                                     86 	.globl _SM0
                                     87 	.globl _IT0
                                     88 	.globl _IE0
                                     89 	.globl _IT1
                                     90 	.globl _IE1
                                     91 	.globl _TR0
                                     92 	.globl _TF0
                                     93 	.globl _TR1
                                     94 	.globl _TF1
                                     95 	.globl _P4_0
                                     96 	.globl _P4_1
                                     97 	.globl _P4_2
                                     98 	.globl _P4_3
                                     99 	.globl _P4_4
                                    100 	.globl _P4_5
                                    101 	.globl _P4_6
                                    102 	.globl _RXD
                                    103 	.globl _TXD
                                    104 	.globl _INT0
                                    105 	.globl _INT1
                                    106 	.globl _T0
                                    107 	.globl _T1
                                    108 	.globl _MOSI1
                                    109 	.globl _MISO1
                                    110 	.globl _SCK1
                                    111 	.globl _P3_0
                                    112 	.globl _P3_1
                                    113 	.globl _P3_2
                                    114 	.globl _P3_3
                                    115 	.globl _P3_4
                                    116 	.globl _P3_5
                                    117 	.globl _P3_6
                                    118 	.globl _P3_7
                                    119 	.globl _CAP1_
                                    120 	.globl _T2_
                                    121 	.globl _CAP2_
                                    122 	.globl _T2EX_
                                    123 	.globl _RXD1
                                    124 	.globl _TXD1
                                    125 	.globl _P2_0
                                    126 	.globl _P2_1
                                    127 	.globl _P2_2
                                    128 	.globl _P2_3
                                    129 	.globl _P2_4
                                    130 	.globl _P2_5
                                    131 	.globl _P2_6
                                    132 	.globl _P2_7
                                    133 	.globl _AIN0
                                    134 	.globl _AIN1
                                    135 	.globl _AIN2
                                    136 	.globl _AIN3
                                    137 	.globl _AIN4
                                    138 	.globl _AIN5
                                    139 	.globl _AIN6
                                    140 	.globl _AIN7
                                    141 	.globl _CAP1
                                    142 	.globl _T2
                                    143 	.globl _CAP2
                                    144 	.globl _T2EX
                                    145 	.globl _INT0_
                                    146 	.globl _SCS
                                    147 	.globl _MOSI
                                    148 	.globl _MISO
                                    149 	.globl _SCK
                                    150 	.globl _RXD1_
                                    151 	.globl _TXD1_
                                    152 	.globl _P1_0
                                    153 	.globl _P1_1
                                    154 	.globl _P1_2
                                    155 	.globl _P1_3
                                    156 	.globl _P1_4
                                    157 	.globl _P1_5
                                    158 	.globl _P1_6
                                    159 	.globl _P1_7
                                    160 	.globl _AIN8
                                    161 	.globl _AIN9
                                    162 	.globl _AIN10
                                    163 	.globl _AIN11
                                    164 	.globl _AIN12
                                    165 	.globl _AIN13
                                    166 	.globl _RXD_
                                    167 	.globl _TXD_
                                    168 	.globl _SCL0
                                    169 	.globl _SDA0
                                    170 	.globl _P0_0
                                    171 	.globl _P0_1
                                    172 	.globl _P0_2
                                    173 	.globl _P0_3
                                    174 	.globl _P0_4
                                    175 	.globl _P0_5
                                    176 	.globl _P0_6
                                    177 	.globl _P0_7
                                    178 	.globl _IE_SPI0
                                    179 	.globl _IE_USB
                                    180 	.globl _IE_ADC
                                    181 	.globl _IE_UART1
                                    182 	.globl _IE_PWM_I2C
                                    183 	.globl _IE_GPIO
                                    184 	.globl _IE_WDOG
                                    185 	.globl _PX0
                                    186 	.globl _PT0
                                    187 	.globl _PX1
                                    188 	.globl _PT1
                                    189 	.globl _PS
                                    190 	.globl _PT2
                                    191 	.globl _PL_FLAG
                                    192 	.globl _PH_FLAG
                                    193 	.globl _EX0
                                    194 	.globl _ET0
                                    195 	.globl _EX1
                                    196 	.globl _ET1
                                    197 	.globl _ES
                                    198 	.globl _ET2
                                    199 	.globl _E_DIS
                                    200 	.globl _EA
                                    201 	.globl _P
                                    202 	.globl _F1
                                    203 	.globl _OV
                                    204 	.globl _RS0
                                    205 	.globl _RS1
                                    206 	.globl _F0
                                    207 	.globl _AC
                                    208 	.globl _CY
                                    209 	.globl _I2CS_INT_ST
                                    210 	.globl _I2CX_INT
                                    211 	.globl _LED_STATUS
                                    212 	.globl _LED_DMA_H
                                    213 	.globl _LED_DMA_L
                                    214 	.globl _LED_DMA
                                    215 	.globl _LED_PWM_OE
                                    216 	.globl _LED_COMMON
                                    217 	.globl _ADC_CHAN
                                    218 	.globl _ADC_DAT_H
                                    219 	.globl _ADC_DAT_L
                                    220 	.globl _ADC_DAT
                                    221 	.globl _ADC_CTRL
                                    222 	.globl _SPI1_CK_SE
                                    223 	.globl _SPI1_CTRL
                                    224 	.globl _SPI1_DATA
                                    225 	.globl _SPI1_STAT
                                    226 	.globl _SIF1
                                    227 	.globl _SBAUD1
                                    228 	.globl _SBUF1
                                    229 	.globl _SCON1
                                    230 	.globl _SPI0_SETUP
                                    231 	.globl _SPI0_CK_SE
                                    232 	.globl _SPI0_CTRL
                                    233 	.globl _SPI0_DATA
                                    234 	.globl _SPI0_STAT
                                    235 	.globl _T2CAP1H
                                    236 	.globl _T2CAP1L
                                    237 	.globl _T2CAP1
                                    238 	.globl _TH2
                                    239 	.globl _TL2
                                    240 	.globl _T2COUNT
                                    241 	.globl _RCAP2H
                                    242 	.globl _RCAP2L
                                    243 	.globl _RCAP2
                                    244 	.globl _T2MOD
                                    245 	.globl _T2CON
                                    246 	.globl _SBUF
                                    247 	.globl _SCON
                                    248 	.globl _TH1
                                    249 	.globl _TH0
                                    250 	.globl _TL1
                                    251 	.globl _TL0
                                    252 	.globl _TMOD
                                    253 	.globl _TCON
                                    254 	.globl _XBUS_AUX
                                    255 	.globl _P7
                                    256 	.globl _P6_DIR
                                    257 	.globl _P6_OUT_PU
                                    258 	.globl _P6_IN
                                    259 	.globl _P5_DIR
                                    260 	.globl _P5_OUT_PU
                                    261 	.globl _P5_IN
                                    262 	.globl _P4_LED_KEY
                                    263 	.globl _P4_DIR_PU
                                    264 	.globl _P4_MOD_OC
                                    265 	.globl _P4
                                    266 	.globl _P3_DIR_PU
                                    267 	.globl _P3_MOD_OC
                                    268 	.globl _P3
                                    269 	.globl _P2_DIR_PU
                                    270 	.globl _P2_MOD_OC
                                    271 	.globl _P2
                                    272 	.globl _P1_DIR_PU
                                    273 	.globl _P1_MOD_OC
                                    274 	.globl _P1
                                    275 	.globl _P0_DIR_PU
                                    276 	.globl _P0_MOD_OC
                                    277 	.globl _P0
                                    278 	.globl _ROM_CTRL
                                    279 	.globl _ROM_DATA_HH
                                    280 	.globl _ROM_DATA_HL
                                    281 	.globl _ROM_DATA_HI
                                    282 	.globl _ROM_ADDR_H
                                    283 	.globl _ROM_ADDR_L
                                    284 	.globl _ROM_ADDR
                                    285 	.globl _GPIO_IE
                                    286 	.globl _IP_EX
                                    287 	.globl _IE_EX
                                    288 	.globl _IP
                                    289 	.globl _IE
                                    290 	.globl _WDOG_COUNT
                                    291 	.globl _RESET_KEEP
                                    292 	.globl _WAKE_CTRL
                                    293 	.globl _CLOCK_CFG
                                    294 	.globl _POWER_CFG
                                    295 	.globl _PCON
                                    296 	.globl _GLOBAL_CFG
                                    297 	.globl _SAFE_MOD
                                    298 	.globl _DPH
                                    299 	.globl _DPL
                                    300 	.globl _SP
                                    301 	.globl _A_INV
                                    302 	.globl _B
                                    303 	.globl _ACC
                                    304 	.globl _PSW
                                    305 	.globl _disable_action_cache
                                    306 	.globl _tap_code_delay_PARM_2
                                    307 	.globl _process_action_PARM_2
                                    308 	.globl _action_exec_PARM_1
                                    309 	.globl _tp_buttons
                                    310 	.globl _action_exec
                                    311 	.globl _ak820_action_exec
                                    312 	.globl _process_record
                                    313 	.globl _process_record_handler
                                    314 	.globl _process_action
                                    315 	.globl _register_code
                                    316 	.globl _unregister_code
                                    317 	.globl _tap_code_delay
                                    318 	.globl _tap_code
                                    319 	.globl _register_mods
                                    320 	.globl _unregister_mods
                                    321 	.globl _register_weak_mods
                                    322 	.globl _unregister_weak_mods
                                    323 	.globl _clear_keyboard
                                    324 	.globl _clear_keyboard_but_mods
                                    325 	.globl _clear_keyboard_but_mods_and_keys
                                    326 ;--------------------------------------------------------
                                    327 ; special function registers
                                    328 ;--------------------------------------------------------
                                    329 	.area RSEG    (ABS,DATA)
      000000                        330 	.org 0x0000
                           0000D0   331 _PSW	=	0x00d0
                           0000E0   332 _ACC	=	0x00e0
                           0000F0   333 _B	=	0x00f0
                           0000FD   334 _A_INV	=	0x00fd
                           000081   335 _SP	=	0x0081
                           000082   336 _DPL	=	0x0082
                           000083   337 _DPH	=	0x0083
                           0000A1   338 _SAFE_MOD	=	0x00a1
                           0000B1   339 _GLOBAL_CFG	=	0x00b1
                           000087   340 _PCON	=	0x0087
                           0000BA   341 _POWER_CFG	=	0x00ba
                           0000B9   342 _CLOCK_CFG	=	0x00b9
                           0000A9   343 _WAKE_CTRL	=	0x00a9
                           0000FE   344 _RESET_KEEP	=	0x00fe
                           0000FF   345 _WDOG_COUNT	=	0x00ff
                           0000A8   346 _IE	=	0x00a8
                           0000B8   347 _IP	=	0x00b8
                           0000E8   348 _IE_EX	=	0x00e8
                           0000E9   349 _IP_EX	=	0x00e9
                           0000B2   350 _GPIO_IE	=	0x00b2
                           008584   351 _ROM_ADDR	=	0x8584
                           000084   352 _ROM_ADDR_L	=	0x0084
                           000085   353 _ROM_ADDR_H	=	0x0085
                           008F8E   354 _ROM_DATA_HI	=	0x8f8e
                           00008E   355 _ROM_DATA_HL	=	0x008e
                           00008F   356 _ROM_DATA_HH	=	0x008f
                           000086   357 _ROM_CTRL	=	0x0086
                           000080   358 _P0	=	0x0080
                           0000C4   359 _P0_MOD_OC	=	0x00c4
                           0000C5   360 _P0_DIR_PU	=	0x00c5
                           000090   361 _P1	=	0x0090
                           000092   362 _P1_MOD_OC	=	0x0092
                           000093   363 _P1_DIR_PU	=	0x0093
                           0000A0   364 _P2	=	0x00a0
                           000094   365 _P2_MOD_OC	=	0x0094
                           000095   366 _P2_DIR_PU	=	0x0095
                           0000B0   367 _P3	=	0x00b0
                           000096   368 _P3_MOD_OC	=	0x0096
                           000097   369 _P3_DIR_PU	=	0x0097
                           0000C0   370 _P4	=	0x00c0
                           0000C2   371 _P4_MOD_OC	=	0x00c2
                           0000C3   372 _P4_DIR_PU	=	0x00c3
                           0000C1   373 _P4_LED_KEY	=	0x00c1
                           0000AA   374 _P5_IN	=	0x00aa
                           0000AB   375 _P5_OUT_PU	=	0x00ab
                           0000AC   376 _P5_DIR	=	0x00ac
                           0000AD   377 _P6_IN	=	0x00ad
                           0000AE   378 _P6_OUT_PU	=	0x00ae
                           0000AF   379 _P6_DIR	=	0x00af
                           0000F1   380 _P7	=	0x00f1
                           0000A2   381 _XBUS_AUX	=	0x00a2
                           000088   382 _TCON	=	0x0088
                           000089   383 _TMOD	=	0x0089
                           00008A   384 _TL0	=	0x008a
                           00008B   385 _TL1	=	0x008b
                           00008C   386 _TH0	=	0x008c
                           00008D   387 _TH1	=	0x008d
                           000098   388 _SCON	=	0x0098
                           000099   389 _SBUF	=	0x0099
                           0000C8   390 _T2CON	=	0x00c8
                           0000C9   391 _T2MOD	=	0x00c9
                           00CBCA   392 _RCAP2	=	0xcbca
                           0000CA   393 _RCAP2L	=	0x00ca
                           0000CB   394 _RCAP2H	=	0x00cb
                           00CDCC   395 _T2COUNT	=	0xcdcc
                           0000CC   396 _TL2	=	0x00cc
                           0000CD   397 _TH2	=	0x00cd
                           00CFCE   398 _T2CAP1	=	0xcfce
                           0000CE   399 _T2CAP1L	=	0x00ce
                           0000CF   400 _T2CAP1H	=	0x00cf
                           0000F8   401 _SPI0_STAT	=	0x00f8
                           0000F9   402 _SPI0_DATA	=	0x00f9
                           0000FA   403 _SPI0_CTRL	=	0x00fa
                           0000FB   404 _SPI0_CK_SE	=	0x00fb
                           0000FC   405 _SPI0_SETUP	=	0x00fc
                           0000BC   406 _SCON1	=	0x00bc
                           0000BD   407 _SBUF1	=	0x00bd
                           0000BE   408 _SBAUD1	=	0x00be
                           0000BF   409 _SIF1	=	0x00bf
                           0000B4   410 _SPI1_STAT	=	0x00b4
                           0000B5   411 _SPI1_DATA	=	0x00b5
                           0000B6   412 _SPI1_CTRL	=	0x00b6
                           0000B7   413 _SPI1_CK_SE	=	0x00b7
                           0000F3   414 _ADC_CTRL	=	0x00f3
                           00F5F4   415 _ADC_DAT	=	0xf5f4
                           0000F4   416 _ADC_DAT_L	=	0x00f4
                           0000F5   417 _ADC_DAT_H	=	0x00f5
                           0000F6   418 _ADC_CHAN	=	0x00f6
                           0000A6   419 _LED_COMMON	=	0x00a6
                           0000A7   420 _LED_PWM_OE	=	0x00a7
                           00C7C6   421 _LED_DMA	=	0xc7c6
                           0000C6   422 _LED_DMA_L	=	0x00c6
                           0000C7   423 _LED_DMA_H	=	0x00c7
                           0000F7   424 _LED_STATUS	=	0x00f7
                           0000B3   425 _I2CX_INT	=	0x00b3
                           0000BB   426 _I2CS_INT_ST	=	0x00bb
                                    427 ;--------------------------------------------------------
                                    428 ; special function bits
                                    429 ;--------------------------------------------------------
                                    430 	.area RSEG    (ABS,DATA)
      000000                        431 	.org 0x0000
                           0000D7   432 _CY	=	0x00d7
                           0000D6   433 _AC	=	0x00d6
                           0000D5   434 _F0	=	0x00d5
                           0000D4   435 _RS1	=	0x00d4
                           0000D3   436 _RS0	=	0x00d3
                           0000D2   437 _OV	=	0x00d2
                           0000D1   438 _F1	=	0x00d1
                           0000D0   439 _P	=	0x00d0
                           0000AF   440 _EA	=	0x00af
                           0000AE   441 _E_DIS	=	0x00ae
                           0000AD   442 _ET2	=	0x00ad
                           0000AC   443 _ES	=	0x00ac
                           0000AB   444 _ET1	=	0x00ab
                           0000AA   445 _EX1	=	0x00aa
                           0000A9   446 _ET0	=	0x00a9
                           0000A8   447 _EX0	=	0x00a8
                           0000BF   448 _PH_FLAG	=	0x00bf
                           0000BE   449 _PL_FLAG	=	0x00be
                           0000BD   450 _PT2	=	0x00bd
                           0000BC   451 _PS	=	0x00bc
                           0000BB   452 _PT1	=	0x00bb
                           0000BA   453 _PX1	=	0x00ba
                           0000B9   454 _PT0	=	0x00b9
                           0000B8   455 _PX0	=	0x00b8
                           0000EF   456 _IE_WDOG	=	0x00ef
                           0000EE   457 _IE_GPIO	=	0x00ee
                           0000ED   458 _IE_PWM_I2C	=	0x00ed
                           0000EC   459 _IE_UART1	=	0x00ec
                           0000EB   460 _IE_ADC	=	0x00eb
                           0000E9   461 _IE_USB	=	0x00e9
                           0000E8   462 _IE_SPI0	=	0x00e8
                           000087   463 _P0_7	=	0x0087
                           000086   464 _P0_6	=	0x0086
                           000085   465 _P0_5	=	0x0085
                           000084   466 _P0_4	=	0x0084
                           000083   467 _P0_3	=	0x0083
                           000082   468 _P0_2	=	0x0082
                           000081   469 _P0_1	=	0x0081
                           000080   470 _P0_0	=	0x0080
                           000081   471 _SDA0	=	0x0081
                           000080   472 _SCL0	=	0x0080
                           000083   473 _TXD_	=	0x0083
                           000082   474 _RXD_	=	0x0082
                           000085   475 _AIN13	=	0x0085
                           000084   476 _AIN12	=	0x0084
                           000083   477 _AIN11	=	0x0083
                           000082   478 _AIN10	=	0x0082
                           000081   479 _AIN9	=	0x0081
                           000080   480 _AIN8	=	0x0080
                           000097   481 _P1_7	=	0x0097
                           000096   482 _P1_6	=	0x0096
                           000095   483 _P1_5	=	0x0095
                           000094   484 _P1_4	=	0x0094
                           000093   485 _P1_3	=	0x0093
                           000092   486 _P1_2	=	0x0092
                           000091   487 _P1_1	=	0x0091
                           000090   488 _P1_0	=	0x0090
                           000097   489 _TXD1_	=	0x0097
                           000096   490 _RXD1_	=	0x0096
                           000097   491 _SCK	=	0x0097
                           000096   492 _MISO	=	0x0096
                           000095   493 _MOSI	=	0x0095
                           000094   494 _SCS	=	0x0094
                           000092   495 _INT0_	=	0x0092
                           000091   496 _T2EX	=	0x0091
                           000091   497 _CAP2	=	0x0091
                           000090   498 _T2	=	0x0090
                           000090   499 _CAP1	=	0x0090
                           000097   500 _AIN7	=	0x0097
                           000096   501 _AIN6	=	0x0096
                           000095   502 _AIN5	=	0x0095
                           000094   503 _AIN4	=	0x0094
                           000093   504 _AIN3	=	0x0093
                           000092   505 _AIN2	=	0x0092
                           000091   506 _AIN1	=	0x0091
                           000090   507 _AIN0	=	0x0090
                           0000A7   508 _P2_7	=	0x00a7
                           0000A6   509 _P2_6	=	0x00a6
                           0000A5   510 _P2_5	=	0x00a5
                           0000A4   511 _P2_4	=	0x00a4
                           0000A3   512 _P2_3	=	0x00a3
                           0000A2   513 _P2_2	=	0x00a2
                           0000A1   514 _P2_1	=	0x00a1
                           0000A0   515 _P2_0	=	0x00a0
                           0000A7   516 _TXD1	=	0x00a7
                           0000A6   517 _RXD1	=	0x00a6
                           0000A5   518 _T2EX_	=	0x00a5
                           0000A5   519 _CAP2_	=	0x00a5
                           0000A4   520 _T2_	=	0x00a4
                           0000A4   521 _CAP1_	=	0x00a4
                           0000B7   522 _P3_7	=	0x00b7
                           0000B6   523 _P3_6	=	0x00b6
                           0000B5   524 _P3_5	=	0x00b5
                           0000B4   525 _P3_4	=	0x00b4
                           0000B3   526 _P3_3	=	0x00b3
                           0000B2   527 _P3_2	=	0x00b2
                           0000B1   528 _P3_1	=	0x00b1
                           0000B0   529 _P3_0	=	0x00b0
                           0000B7   530 _SCK1	=	0x00b7
                           0000B6   531 _MISO1	=	0x00b6
                           0000B5   532 _MOSI1	=	0x00b5
                           0000B5   533 _T1	=	0x00b5
                           0000B4   534 _T0	=	0x00b4
                           0000B3   535 _INT1	=	0x00b3
                           0000B2   536 _INT0	=	0x00b2
                           0000B1   537 _TXD	=	0x00b1
                           0000B0   538 _RXD	=	0x00b0
                           0000C6   539 _P4_6	=	0x00c6
                           0000C5   540 _P4_5	=	0x00c5
                           0000C4   541 _P4_4	=	0x00c4
                           0000C3   542 _P4_3	=	0x00c3
                           0000C2   543 _P4_2	=	0x00c2
                           0000C1   544 _P4_1	=	0x00c1
                           0000C0   545 _P4_0	=	0x00c0
                           00008F   546 _TF1	=	0x008f
                           00008E   547 _TR1	=	0x008e
                           00008D   548 _TF0	=	0x008d
                           00008C   549 _TR0	=	0x008c
                           00008B   550 _IE1	=	0x008b
                           00008A   551 _IT1	=	0x008a
                           000089   552 _IE0	=	0x0089
                           000088   553 _IT0	=	0x0088
                           00009F   554 _SM0	=	0x009f
                           00009E   555 _SM1	=	0x009e
                           00009D   556 _SM2	=	0x009d
                           00009C   557 _REN	=	0x009c
                           00009B   558 _TB8	=	0x009b
                           00009A   559 _RB8	=	0x009a
                           000099   560 _TI	=	0x0099
                           000098   561 _RI	=	0x0098
                           0000CF   562 _TF2	=	0x00cf
                           0000CF   563 _CAP1F	=	0x00cf
                           0000CE   564 _EXF2	=	0x00ce
                           0000CD   565 _RCLK	=	0x00cd
                           0000CC   566 _TCLK	=	0x00cc
                           0000CB   567 _EXEN2	=	0x00cb
                           0000CA   568 _TR2	=	0x00ca
                           0000C9   569 _C_T2	=	0x00c9
                           0000C8   570 _CP_RL2	=	0x00c8
                           0000FF   571 _S0_FST_ACT	=	0x00ff
                           0000FE   572 _S0_IF_OV	=	0x00fe
                           0000FD   573 _S0_IF_FIRST	=	0x00fd
                           0000FC   574 _S0_IF_BYTE	=	0x00fc
                           0000FB   575 _S0_FREE	=	0x00fb
                           0000FA   576 _S0_T_FIFO	=	0x00fa
                           0000F8   577 _S0_R_FIFO	=	0x00f8
                           0000F7   578 _ADC_START	=	0x00f7
                                    579 ;--------------------------------------------------------
                                    580 ; overlayable register banks
                                    581 ;--------------------------------------------------------
                                    582 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        583 	.ds 8
                                    584 ;--------------------------------------------------------
                                    585 ; internal ram data
                                    586 ;--------------------------------------------------------
                                    587 	.area DSEG    (DATA)
      000027                        588 _process_action_sloc0_1_0:
      000027                        589 	.ds 1
                                    590 ;--------------------------------------------------------
                                    591 ; overlayable items in internal ram
                                    592 ;--------------------------------------------------------
                                    593 ;--------------------------------------------------------
                                    594 ; indirectly addressable internal ram data
                                    595 ;--------------------------------------------------------
                                    596 	.area ISEG    (DATA)
                                    597 ;--------------------------------------------------------
                                    598 ; absolute internal ram data
                                    599 ;--------------------------------------------------------
                                    600 	.area IABS    (ABS,DATA)
                                    601 	.area IABS    (ABS,DATA)
                                    602 ;--------------------------------------------------------
                                    603 ; bit data
                                    604 ;--------------------------------------------------------
                                    605 	.area BSEG    (BIT)
      00001F                        606 _process_action_sloc1_1_0:
      00001F                        607 	.ds 1
                                    608 ;--------------------------------------------------------
                                    609 ; paged external ram data
                                    610 ;--------------------------------------------------------
                                    611 	.area PSEG    (PAG,XDATA)
                                    612 ;--------------------------------------------------------
                                    613 ; uninitialized external ram data
                                    614 ;--------------------------------------------------------
                                    615 	.area XSEG    (XDATA)
      000815                        616 _tp_buttons::
      000815                        617 	.ds 2
      000817                        618 _action_exec_PARM_1:
      000817                        619 	.ds 6
      00081D                        620 _action_exec_record_10001_624:
      00081D                        621 	.ds 9
      000826                        622 _ak820_action_exec_event_10000_628:
      000826                        623 	.ds 2
      000828                        624 _ak820_action_exec_snapshot_10000_629:
      000828                        625 	.ds 6
      00082E                        626 _process_record_record_10000_632:
      00082E                        627 	.ds 3
      000831                        628 _process_record_handler_record_argument_10000_640:
      000831                        629 	.ds 3
      000834                        630 _process_record_handler_action_10000_641:
      000834                        631 	.ds 2
      000836                        632 _process_action_PARM_2:
      000836                        633 	.ds 2
      000838                        634 _process_action_record_argument_10000_652:
      000838                        635 	.ds 3
      00083B                        636 _process_action_on_40000_675:
      00083B                        637 	.ds 1
      00083C                        638 _register_code_code_10000_709:
      00083C                        639 	.ds 1
      00083D                        640 _unregister_code_code_10000_723:
      00083D                        641 	.ds 1
      00083E                        642 _tap_code_delay_PARM_2:
      00083E                        643 	.ds 2
      000840                        644 _tap_code_delay_code_10000_736:
      000840                        645 	.ds 1
      000841                        646 _tap_code_code_10000_743:
      000841                        647 	.ds 1
      000842                        648 _register_mods_mods_10000_745:
      000842                        649 	.ds 1
      000843                        650 _unregister_mods_mods_10000_749:
      000843                        651 	.ds 1
      000844                        652 _register_weak_mods_mods_10000_753:
      000844                        653 	.ds 1
      000845                        654 _unregister_weak_mods_mods_10000_757:
      000845                        655 	.ds 1
                                    656 ;--------------------------------------------------------
                                    657 ; absolute external ram data
                                    658 ;--------------------------------------------------------
                                    659 	.area XABS    (ABS,XDATA)
                                    660 ;--------------------------------------------------------
                                    661 ; initialized external ram data
                                    662 ;--------------------------------------------------------
                                    663 	.area XISEG   (XDATA)
      000DBF                        664 _disable_action_cache::
      000DBF                        665 	.ds 1
                                    666 	.area HOME    (CODE)
                                    667 	.area GSINIT0 (CODE)
                                    668 	.area GSINIT1 (CODE)
                                    669 	.area GSINIT2 (CODE)
                                    670 	.area GSINIT3 (CODE)
                                    671 	.area GSINIT4 (CODE)
                                    672 	.area GSINIT5 (CODE)
                                    673 	.area GSINIT  (CODE)
                                    674 	.area GSFINAL (CODE)
                                    675 	.area CSEG    (CODE)
                                    676 ;--------------------------------------------------------
                                    677 ; global & static initialisations
                                    678 ;--------------------------------------------------------
                                    679 	.area HOME    (CODE)
                                    680 	.area GSINIT  (CODE)
                                    681 	.area GSFINAL (CODE)
                                    682 	.area GSINIT  (CODE)
                                    683 ;--------------------------------------------------------
                                    684 ; Home
                                    685 ;--------------------------------------------------------
                                    686 	.area HOME    (CODE)
                                    687 	.area HOME    (CODE)
                                    688 ;--------------------------------------------------------
                                    689 ; code
                                    690 ;--------------------------------------------------------
                                    691 	.area CSEG    (CODE)
                                    692 ;------------------------------------------------------------
                                    693 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    694 ;------------------------------------------------------------
                                    695 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    696 ;------------------------------------------------------------
                                    697 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    698 ;	-----------------------------------------
                           000007   699 	ar7 = 0x07
                           000006   700 	ar6 = 0x06
                           000005   701 	ar5 = 0x05
                           000004   702 	ar4 = 0x04
                           000003   703 	ar3 = 0x03
                           000002   704 	ar2 = 0x02
                           000001   705 	ar1 = 0x01
                           000000   706 	ar0 = 0x00
                                    707 ;	 function action_exec
                                    708 ;	-----------------------------------------
      007013                        709 _action_exec:
                                    710 ;	quantum/action.c:92: ak820_combo_tick(event.time);
      007013 90 08 19         [24]  711 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      007016 12 37 F4         [24]  712 	lcall	_ak820_outline_0005
      007019 12 36 04         [24]  713 	lcall	_ak820_combo_tick
                                    714 ;	quantum/action.c:95: if (!ak820_tapping_before(&event)) return;
      00701C 90 08 17         [24]  715 	mov	dptr,#_action_exec_PARM_1
      00701F 12 44 53         [24]  716 	lcall	_ak820_tapping_before
      007022 E5 82            [12]  717 	mov	a, dpl
      007024 70 01            [24]  718 	jnz	00102$
      007026 22               [24]  719 	ret
      007027                        720 00102$:
                                    721 ;	quantum/action.c:113: if (event.pressed) {
      007027 90 08 1C         [24]  722 	mov	dptr,#(_action_exec_PARM_1 + 0x0005)
      00702A E0               [24]  723 	movx	a,@dptr
      00702B 60 03            [24]  724 	jz	00104$
                                    725 ;	quantum/action.c:115: clear_weak_mods();
      00702D 12 80 7D         [24]  726 	lcall	_clear_weak_mods
      007030                        727 00104$:
                                    728 ;	quantum/action.c:127: record.event = event;
      007030 90 0D 9F         [24]  729 	mov	dptr,#___memcpy_PARM_2
      007033 74 17            [12]  730 	mov	a,#_action_exec_PARM_1
      007035 F0               [24]  731 	movx	@dptr,a
      007036 74 08            [12]  732 	mov	a,#(_action_exec_PARM_1 >> 8)
      007038 12 38 70         [24]  733 	lcall	_ak820_outline_0094
      00703B 12 76 E9         [24]  734 	lcall	_ak820_outline_0071
      00703E 90 08 1D         [24]  735 	mov	dptr,#_action_exec_record_10001_624
      007041 F5 F0            [12]  736 	mov	b,a
      007043 12 B7 22         [24]  737 	lcall	___memcpy
                                    738 ;	quantum/action.c:129: record.tap.count = 0;
      007046 90 08 23         [24]  739 	mov	dptr,#(_action_exec_record_10001_624 + 0x0006)
      007049 E0               [24]  740 	movx	a,@dptr
      00704A 54 0F            [12]  741 	anl	a,#0x0f
      00704C F0               [24]  742 	movx	@dptr,a
                                    743 ;	quantum/action.c:134: record.keycode = 0;
      00704D 90 08 24         [24]  744 	mov	dptr,#(_action_exec_record_10001_624 + 0x0007)
      007050 12 4F 3C         [24]  745 	lcall	_ak820_outline_0184
                                    746 ;	quantum/action.c:165: if (IS_NOEVENT(record.event) || pre_process_record_quantum(&record)) {
      007053 90 08 21         [24]  747 	mov	dptr,#(_action_exec_record_10001_624 + 0x0004)
      007056 E0               [24]  748 	movx	a,@dptr
      007057 60 0D            [24]  749 	jz	00107$
      007059 90 08 1D         [24]  750 	mov	dptr,#_action_exec_record_10001_624
      00705C 75 F0 00         [24]  751 	mov	b, #0x00
      00705F 12 9E 5C         [24]  752 	lcall	_pre_process_record_quantum
      007062 E5 82            [12]  753 	mov	a, dpl
      007064 60 14            [24]  754 	jz	00110$
      007066                        755 00107$:
                                    756 ;	quantum/action.c:167: if (!ak820_tapping_process(&record)) return;
      007066 90 08 1D         [24]  757 	mov	dptr,#_action_exec_record_10001_624
      007069 12 45 3A         [24]  758 	lcall	_ak820_tapping_process
      00706C E5 82            [12]  759 	mov	a, dpl
      00706E 70 01            [24]  760 	jnz	00106$
      007070 22               [24]  761 	ret
      007071                        762 00106$:
                                    763 ;	quantum/action.c:172: process_record(&record);
      007071 90 08 1D         [24]  764 	mov	dptr,#_action_exec_record_10001_624
      007074 75 F0 00         [24]  765 	mov	b, #0x00
                                    766 ;	quantum/action.c:182: }
      007077 02 70 B7         [24]  767 	ljmp	_process_record
      00707A                        768 00110$:
      00707A 22               [24]  769 	ret
                                    770 ;------------------------------------------------------------
                                    771 ;Allocation info for local variables in function 'ak820_action_exec'
                                    772 ;------------------------------------------------------------
                                    773 ;event         Allocated with name '_ak820_action_exec_event_10000_628'
                                    774 ;snapshot      Allocated with name '_ak820_action_exec_snapshot_10000_629'
                                    775 ;------------------------------------------------------------
                                    776 ;	quantum/action.c:185: void ak820_action_exec(const keyevent_t __xdata *event) {
                                    777 ;	-----------------------------------------
                                    778 ;	 function ak820_action_exec
                                    779 ;	-----------------------------------------
      00707B                        780 _ak820_action_exec:
      00707B 12 38 82         [24]  781 	lcall	_ak820_outline_0118
      00707E 90 08 26         [24]  782 	mov	dptr,#_ak820_action_exec_event_10000_628
      007081 12 38 87         [24]  783 	lcall	_ak820_outline_0119
                                    784 ;	quantum/action.c:188: keyevent_t snapshot = *event;
      007084 90 08 26         [24]  785 	mov	dptr,#_ak820_action_exec_event_10000_628
      007087 12 38 64         [24]  786 	lcall	_ak820_outline_0080
      00708A 7F 00            [12]  787 	mov	r7,#0x00
      00708C 90 0D 9F         [24]  788 	mov	dptr,#___memcpy_PARM_2
      00708F ED               [12]  789 	mov	a,r5
      007090 12 38 1F         [24]  790 	lcall	_ak820_outline_0016
      007093 12 76 E9         [24]  791 	lcall	_ak820_outline_0071
      007096 90 08 28         [24]  792 	mov	dptr,#_ak820_action_exec_snapshot_10000_629
      007099 F5 F0            [12]  793 	mov	b,a
      00709B 12 B7 22         [24]  794 	lcall	___memcpy
                                    795 ;	quantum/action.c:189: action_exec(snapshot);
      00709E 90 0D 9F         [24]  796 	mov	dptr,#___memcpy_PARM_2
      0070A1 74 28            [12]  797 	mov	a,#_ak820_action_exec_snapshot_10000_629
      0070A3 F0               [24]  798 	movx	@dptr,a
      0070A4 74 08            [12]  799 	mov	a,#(_ak820_action_exec_snapshot_10000_629 >> 8)
      0070A6 12 38 70         [24]  800 	lcall	_ak820_outline_0094
      0070A9 12 76 E9         [24]  801 	lcall	_ak820_outline_0071
      0070AC 90 08 17         [24]  802 	mov	dptr,#_action_exec_PARM_1
      0070AF F5 F0            [12]  803 	mov	b,a
      0070B1 12 B7 22         [24]  804 	lcall	___memcpy
                                    805 ;	quantum/action.c:190: }
      0070B4 02 70 13         [24]  806 	ljmp	_action_exec
                                    807 ;------------------------------------------------------------
                                    808 ;Allocation info for local variables in function 'process_record_nocache'
                                    809 ;------------------------------------------------------------
                                    810 ;record        Allocated with name '_process_record_nocache_record_10000_630'
                                    811 ;------------------------------------------------------------
                                    812 ;	quantum/action.c:275: void process_record_nocache(keyrecord_t *record) {
                                    813 ;	-----------------------------------------
                                    814 ;	 function process_record
                                    815 ;	-----------------------------------------
      0070B7                        816 _process_record:
      0070B7 12 43 13         [24]  817 	lcall	_ak820_outline_0036
      0070BA 90 08 2E         [24]  818 	mov	dptr,#_process_record_record_10000_632
      0070BD 12 38 1F         [24]  819 	lcall	_ak820_outline_0016
                                    820 ;	quantum/action.c:329: if (IS_NOEVENT(record->event)) {
      0070C0 90 08 2E         [24]  821 	mov	dptr,#_process_record_record_10000_632
      0070C3 12 4E E9         [24]  822 	lcall	_ak820_outline_0011
      0070C6 74 04            [12]  823 	mov	a,#0x04
      0070C8 12 76 BC         [24]  824 	lcall	_ak820_outline_0013
      0070CB 12 B7 FB         [24]  825 	lcall	__gptrget
      0070CE 70 01            [24]  826 	jnz	00102$
                                    827 ;	quantum/action.c:330: return;
      0070D0 22               [24]  828 	ret
      0070D1                        829 00102$:
                                    830 ;	quantum/action.c:338: uint8_t oneshot_source = ak820_tapping_source(record->event.key);
      0070D1 8D 02            [24]  831 	mov	ar2,r5
      0070D3 8E 03            [24]  832 	mov	ar3,r6
      0070D5 8F 04            [24]  833 	mov	ar4,r7
      0070D7 90 0D 9F         [24]  834 	mov	dptr,#___memcpy_PARM_2
      0070DA EA               [12]  835 	mov	a,r2
      0070DB 12 77 30         [24]  836 	lcall	_ak820_outline_0189
      0070DE EC               [12]  837 	mov	a,r4
      0070DF A3               [24]  838 	inc	dptr
      0070E0 F0               [24]  839 	movx	@dptr,a
      0070E1 90 0D A2         [24]  840 	mov	dptr,#___memcpy_PARM_3
      0070E4 12 4F 2E         [24]  841 	lcall	_ak820_outline_0110
      0070E7 90 06 24         [24]  842 	mov	dptr,#_ak820_tapping_source_PARM_1
      0070EA F5 F0            [12]  843 	mov	b,a
      0070EC C0 07            [24]  844 	push	ar7
      0070EE C0 06            [24]  845 	push	ar6
      0070F0 C0 05            [24]  846 	push	ar5
      0070F2 12 B7 22         [24]  847 	lcall	___memcpy
      0070F5 12 43 8D         [24]  848 	lcall	_ak820_tapping_source
      0070F8 AC 82            [24]  849 	mov	r4, dpl
      0070FA D0 05            [24]  850 	pop	ar5
      0070FC D0 06            [24]  851 	pop	ar6
      0070FE D0 07            [24]  852 	pop	ar7
                                    853 ;	quantum/action.c:339: bool oneshot_pressed = record->event.pressed;
      007100 74 05            [12]  854 	mov	a,#0x05
      007102 12 76 AE         [24]  855 	lcall	_ak820_outline_0012
      007105 12 B7 FB         [24]  856 	lcall	__gptrget
      007108 FB               [12]  857 	mov	r3,a
                                    858 ;	quantum/action.c:340: record->keycode = get_record_keycode(record, true);
      007109 12 77 15         [24]  859 	lcall	_ak820_outline_0148
      00710C 90 0B FB         [24]  860 	mov	dptr,#_get_record_keycode_PARM_2
      00710F 74 01            [12]  861 	mov	a,#0x01
      007111 12 4E F2         [24]  862 	lcall	_ak820_outline_0034
      007114 C0 04            [24]  863 	push	ar4
      007116 C0 03            [24]  864 	push	ar3
      007118 C0 02            [24]  865 	push	ar2
      00711A C0 01            [24]  866 	push	ar1
      00711C C0 00            [24]  867 	push	ar0
      00711E 12 9E 1E         [24]  868 	lcall	_get_record_keycode
      007121 12 43 5C         [24]  869 	lcall	_ak820_outline_0135
      007124 D0 00            [24]  870 	pop	ar0
      007126 D0 01            [24]  871 	pop	ar1
      007128 D0 02            [24]  872 	pop	ar2
      00712A D0 03            [24]  873 	pop	ar3
      00712C D0 04            [24]  874 	pop	ar4
      00712E 12 48 B2         [24]  875 	lcall	_ak820_outline_0112
      007131 EE               [12]  876 	mov	a,r6
      007132 12 B7 C0         [24]  877 	lcall	__gptrput
      007135 A3               [24]  878 	inc	dptr
      007136 EF               [12]  879 	mov	a,r7
      007137 12 B7 C0         [24]  880 	lcall	__gptrput
                                    881 ;	quantum/action.c:341: if (!ak820_oneshot_process(record->keycode, oneshot_source, oneshot_pressed)) return;
      00713A 90 08 2E         [24]  882 	mov	dptr,#_process_record_record_10000_632
      00713D 12 4E E9         [24]  883 	lcall	_ak820_outline_0011
      007140 12 77 15         [24]  884 	lcall	_ak820_outline_0148
      007143 12 48 B2         [24]  885 	lcall	_ak820_outline_0112
      007146 12 B7 FB         [24]  886 	lcall	__gptrget
      007149 F8               [12]  887 	mov	r0,a
      00714A A3               [24]  888 	inc	dptr
      00714B 12 B7 FB         [24]  889 	lcall	__gptrget
      00714E F9               [12]  890 	mov	r1,a
      00714F 90 06 34         [24]  891 	mov	dptr,#_ak820_oneshot_process_PARM_2
      007152 EC               [12]  892 	mov	a,r4
      007153 F0               [24]  893 	movx	@dptr,a
      007154 90 06 35         [24]  894 	mov	dptr,#_ak820_oneshot_process_PARM_3
      007157 EB               [12]  895 	mov	a,r3
      007158 F0               [24]  896 	movx	@dptr,a
      007159 12 38 B6         [24]  897 	lcall	_ak820_outline_0160
      00715C C0 07            [24]  898 	push	ar7
      00715E C0 06            [24]  899 	push	ar6
      007160 C0 05            [24]  900 	push	ar5
      007162 C0 04            [24]  901 	push	ar4
      007164 C0 03            [24]  902 	push	ar3
      007166 12 46 EC         [24]  903 	lcall	_ak820_oneshot_process
      007169 E5 82            [12]  904 	mov	a, dpl
      00716B D0 03            [24]  905 	pop	ar3
      00716D D0 04            [24]  906 	pop	ar4
      00716F D0 05            [24]  907 	pop	ar5
      007171 D0 06            [24]  908 	pop	ar6
      007173 D0 07            [24]  909 	pop	ar7
      007175 70 01            [24]  910 	jnz	00104$
      007177 22               [24]  911 	ret
      007178                        912 00104$:
                                    913 ;	quantum/action.c:343: if (!process_record_quantum(record)) {
      007178 12 6D 59         [24]  914 	lcall	_ak820_outline_0059
      00717B C0 04            [24]  915 	push	ar4
      00717D C0 03            [24]  916 	push	ar3
      00717F 12 9E E4         [24]  917 	lcall	_process_record_quantum
      007182 E5 82            [12]  918 	mov	a, dpl
      007184 D0 03            [24]  919 	pop	ar3
      007186 D0 04            [24]  920 	pop	ar4
      007188 70 0A            [24]  921 	jnz	00106$
                                    922 ;	quantum/action.c:345: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      00718A 90 05 9C         [24]  923 	mov	dptr,#_ak820_oneshot_post_PARM_2
      00718D EB               [12]  924 	mov	a,r3
      00718E F0               [24]  925 	movx	@dptr,a
      00718F 8C 82            [24]  926 	mov	dpl, r4
                                    927 ;	quantum/action.c:352: return;
      007191 02 2E BB         [24]  928 	ljmp	_ak820_oneshot_post
      007194                        929 00106$:
                                    930 ;	quantum/action.c:358: process_record_handler(record);
      007194 90 08 2E         [24]  931 	mov	dptr,#_process_record_record_10000_632
      007197 12 4E C3         [24]  932 	lcall	_ak820_outline_0001
      00719A C0 04            [24]  933 	push	ar4
      00719C C0 03            [24]  934 	push	ar3
      00719E 12 71 B8         [24]  935 	lcall	_process_record_handler
                                    936 ;	quantum/action.c:362: post_process_record_quantum(record);
      0071A1 90 08 2E         [24]  937 	mov	dptr,#_process_record_record_10000_632
      0071A4 12 4E C3         [24]  938 	lcall	_ak820_outline_0001
      0071A7 12 9E B9         [24]  939 	lcall	_post_process_record_quantum
      0071AA D0 03            [24]  940 	pop	ar3
      0071AC D0 04            [24]  941 	pop	ar4
                                    942 ;	quantum/action.c:364: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      0071AE 90 05 9C         [24]  943 	mov	dptr,#_ak820_oneshot_post_PARM_2
      0071B1 EB               [12]  944 	mov	a,r3
      0071B2 F0               [24]  945 	movx	@dptr,a
      0071B3 8C 82            [24]  946 	mov	dpl, r4
                                    947 ;	quantum/action.c:366: }
      0071B5 02 2E BB         [24]  948 	ljmp	_ak820_oneshot_post
                                    949 ;------------------------------------------------------------
                                    950 ;Allocation info for local variables in function 'process_record_handler'
                                    951 ;------------------------------------------------------------
                                    952 ;record_argument Allocated with name '_process_record_handler_record_argument_10000_640'
                                    953 ;record        Allocated with name '_process_record_handler_record_10000_641'
                                    954 ;action        Allocated with name '_process_record_handler_action_10000_641'
                                    955 ;------------------------------------------------------------
                                    956 ;	quantum/action.c:368: void process_record_handler(keyrecord_t *record_argument) {
                                    957 ;	-----------------------------------------
                                    958 ;	 function process_record_handler
                                    959 ;	-----------------------------------------
      0071B8                        960 _process_record_handler:
      0071B8 12 43 13         [24]  961 	lcall	_ak820_outline_0036
      0071BB 90 08 31         [24]  962 	mov	dptr,#_process_record_handler_record_argument_10000_640
      0071BE 12 38 1F         [24]  963 	lcall	_ak820_outline_0016
                                    964 ;	quantum/action.c:372: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      0071C1 90 08 31         [24]  965 	mov	dptr,#_process_record_handler_record_argument_10000_640
      0071C4 12 37 FE         [24]  966 	lcall	_ak820_outline_0007
                                    967 ;	quantum/action.c:379: if (record->keycode) {
      0071C7 4C               [12]  968 	orl	a,r4
      0071C8 60 19            [24]  969 	jz	00102$
                                    970 ;	quantum/action.c:380: action.code = action_for_keycode(record->keycode);
      0071CA 12 38 97         [24]  971 	lcall	_ak820_outline_0126
      0071CD C0 07            [24]  972 	push	ar7
      0071CF C0 06            [24]  973 	push	ar6
      0071D1 12 94 5B         [24]  974 	lcall	_action_for_keycode
      0071D4 12 43 6D         [24]  975 	lcall	_ak820_outline_0151
      0071D7 D0 06            [24]  976 	pop	ar6
      0071D9 D0 07            [24]  977 	pop	ar7
      0071DB 90 08 34         [24]  978 	mov	dptr,#_process_record_handler_action_10000_641
      0071DE 12 38 5E         [24]  979 	lcall	_ak820_outline_0072
      0071E1 80 2B            [24]  980 	sjmp	00104$
      0071E3                        981 00102$:
                                    982 ;	quantum/action.c:383: action.code = action_for_keycode(ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed));
      0071E3 12 76 CA         [24]  983 	lcall	_ak820_outline_0021
      0071E6 7A 00            [12]  984 	mov	r2,#0x00
      0071E8 12 43 67         [24]  985 	lcall	_ak820_outline_0144
      0071EB 12 43 01         [24]  986 	lcall	_ak820_outline_0010
      0071EE E0               [24]  987 	movx	a,@dptr
      0071EF 90 09 70         [24]  988 	mov	dptr,#_ak820_resolve_key_PARM_2
      0071F2 F0               [24]  989 	movx	@dptr,a
      0071F3 8D 82            [24]  990 	mov	dpl, r5
      0071F5 8C 83            [24]  991 	mov	dph, r4
      0071F7 C0 07            [24]  992 	push	ar7
      0071F9 C0 06            [24]  993 	push	ar6
      0071FB 12 7A 71         [24]  994 	lcall	_ak820_resolve_key
      0071FE 12 94 5B         [24]  995 	lcall	_action_for_keycode
      007201 12 43 6D         [24]  996 	lcall	_ak820_outline_0151
      007204 D0 06            [24]  997 	pop	ar6
      007206 D0 07            [24]  998 	pop	ar7
      007208 90 08 34         [24]  999 	mov	dptr,#_process_record_handler_action_10000_641
      00720B 12 38 5E         [24] 1000 	lcall	_ak820_outline_0072
                                   1001 ;	quantum/action.c:392: ac_dprintf("ACTION: ");
      00720E                       1002 00104$:
                                   1003 ;	quantum/action.c:403: process_action(record, action);
      00720E 7D 00            [12] 1004 	mov	r5,#0x00
      007210 90 0D 9F         [24] 1005 	mov	dptr,#___memcpy_PARM_2
      007213 74 34            [12] 1006 	mov	a,#_process_record_handler_action_10000_641
      007215 F0               [24] 1007 	movx	@dptr,a
      007216 74 08            [12] 1008 	mov	a,#(_process_record_handler_action_10000_641 >> 8)
      007218 12 38 70         [24] 1009 	lcall	_ak820_outline_0094
      00721B 90 0D A2         [24] 1010 	mov	dptr,#___memcpy_PARM_3
      00721E 12 4F 2E         [24] 1011 	lcall	_ak820_outline_0110
      007221 90 08 36         [24] 1012 	mov	dptr,#_process_action_PARM_2
      007224 F5 F0            [12] 1013 	mov	b,a
      007226 C0 07            [24] 1014 	push	ar7
      007228 C0 06            [24] 1015 	push	ar6
      00722A C0 05            [24] 1016 	push	ar5
      00722C 12 B7 22         [24] 1017 	lcall	___memcpy
      00722F D0 05            [24] 1018 	pop	ar5
      007231 D0 06            [24] 1019 	pop	ar6
      007233 D0 07            [24] 1020 	pop	ar7
      007235 12 6F 7E         [24] 1021 	lcall	_ak820_outline_0050
                                   1022 ;	quantum/action.c:404: }
      007238 02 72 3B         [24] 1023 	ljmp	_process_action
                                   1024 ;------------------------------------------------------------
                                   1025 ;Allocation info for local variables in function 'register_mouse'
                                   1026 ;------------------------------------------------------------
                                   1027 ;pressed       Allocated with name '_register_mouse_PARM_2'
                                   1028 ;mouse_keycode Allocated with name '_register_mouse_mouse_keycode_10000_649'
                                   1029 ;------------------------------------------------------------
                                   1030 ;	quantum/action.c:416: void register_mouse(uint8_t mouse_keycode, bool pressed) {
                                   1031 ;	-----------------------------------------
                                   1032 ;	 function process_action
                                   1033 ;	-----------------------------------------
      00723B                       1034 _process_action:
      00723B 12 43 13         [24] 1035 	lcall	_ak820_outline_0036
      00723E 90 08 38         [24] 1036 	mov	dptr,#_process_action_record_argument_10000_652
      007241 12 38 1F         [24] 1037 	lcall	_ak820_outline_0016
                                   1038 ;	quantum/action.c:469: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      007244 90 08 38         [24] 1039 	mov	dptr,#_process_action_record_argument_10000_652
      007247 12 37 F4         [24] 1040 	lcall	_ak820_outline_0005
                                   1041 ;	quantum/action.c:475: pressed = record->event.pressed;
      00724A A3               [24] 1042 	inc	dptr
      00724B A3               [24] 1043 	inc	dptr
      00724C A3               [24] 1044 	inc	dptr
      00724D A3               [24] 1045 	inc	dptr
      00724E A3               [24] 1046 	inc	dptr
      00724F E0               [24] 1047 	movx	a,@dptr
      007250 F5 27            [12] 1048 	mov	_process_action_sloc0_1_0,a
                                   1049 ;	quantum/action.c:499: switch (action.kind.id) {
      007252 90 08 37         [24] 1050 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007255 E0               [24] 1051 	movx	a,@dptr
      007256 C4               [12] 1052 	swap	a
      007257 54 0F            [12] 1053 	anl	a,#0x0f
      007259 FD               [12] 1054 	mov  r5,a
      00725A 24 F4            [12] 1055 	add	a,#0xff - 0x0b
      00725C 50 03            [24] 1056 	jnc	00434$
      00725E 02 74 DC         [24] 1057 	ljmp	00181$
      007261                       1058 00434$:
                                   1059 ;	free result
      007261 ED               [12] 1060 	mov	a,r5
      007262 24 0A            [12] 1061 	add	a,#(00435$-3-.)
      007264 83               [24] 1062 	movc	a,@a+pc
      007265 F5 82            [12] 1063 	mov	dpl,a
      007267 ED               [12] 1064 	mov	a,r5
      007268 24 10            [12] 1065 	add	a,#(00436$-3-.)
      00726A 83               [24] 1066 	movc	a,@a+pc
      00726B F5 83            [12] 1067 	mov	dph,a
      00726D E4               [12] 1068 	clr	a
      00726E 73               [24] 1069 	jmp	@a+dptr
      00726F                       1070 00435$:
      00726F 87                    1071 	.db	00102$
      007270 87                    1072 	.db	00102$
      007271 DC                    1073 	.db	00181$
      007272 DC                    1074 	.db	00181$
      007273 11                    1075 	.db	00123$
      007274 DC                    1076 	.db	00181$
      007275 DC                    1077 	.db	00181$
      007276 DC                    1078 	.db	00181$
      007277 71                    1079 	.db	00131$
      007278 43                    1080 	.db	00147$
      007279 69                    1081 	.db	00152$
      00727A 69                    1082 	.db	00152$
      00727B                       1083 00436$:
      00727B 72                    1084 	.db	00102$>>8
      00727C 72                    1085 	.db	00102$>>8
      00727D 74                    1086 	.db	00181$>>8
      00727E 74                    1087 	.db	00181$>>8
      00727F 73                    1088 	.db	00123$>>8
      007280 74                    1089 	.db	00181$>>8
      007281 74                    1090 	.db	00181$>>8
      007282 74                    1091 	.db	00181$>>8
      007283 73                    1092 	.db	00131$>>8
      007284 74                    1093 	.db	00147$>>8
      007285 74                    1094 	.db	00152$>>8
      007286 74                    1095 	.db	00152$>>8
                                   1096 ;	quantum/action.c:502: case ACT_RMODS: {
      007287                       1097 00102$:
                                   1098 ;	quantum/action.c:503: mods = (action.kind.id == ACT_LMODS) ? action.key.mods : action.key.mods << 4;
      007287 90 08 37         [24] 1099 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      00728A E0               [24] 1100 	movx	a,@dptr
      00728B 54 F0            [12] 1101 	anl	a,#0xf0
      00728D 70 06            [24] 1102 	jnz	00194$
      00728F 12 77 03         [24] 1103 	lcall	_ak820_outline_0113
      007292 FD               [12] 1104 	mov	r5,a
      007293 80 07            [24] 1105 	sjmp	00195$
      007295                       1106 00194$:
      007295 12 77 03         [24] 1107 	lcall	_ak820_outline_0113
      007298 C4               [12] 1108 	swap	a
      007299 54 F0            [12] 1109 	anl	a,#0xf0
      00729B FD               [12] 1110 	mov	r5,a
      00729C                       1111 00195$:
                                   1112 ;	quantum/action.c:505: if (pressed) {
      00729C E5 27            [12] 1113 	mov	a,_process_action_sloc0_1_0
      00729E 60 35            [24] 1114 	jz	00119$
                                   1115 ;	quantum/action.c:506: if (mods) {
      0072A0 ED               [12] 1116 	mov	a,r5
      0072A1 60 29            [24] 1117 	jz	00110$
                                   1118 ;	quantum/action.c:507: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      0072A3 12 77 1F         [24] 1119 	lcall	_ak820_outline_0162
      0072A6 FC               [12] 1120 	mov	r4,a
      0072A7 BC E0 00         [24] 1121 	cjne	r4,#0xe0,00440$
      0072AA                       1122 00440$:
      0072AA 40 07            [24] 1123 	jc	00108$
      0072AC 12 77 1F         [24] 1124 	lcall	_ak820_outline_0162
      0072AF 24 18            [12] 1125 	add	a,#0xff - 0xe7
      0072B1 50 0A            [24] 1126 	jnc	00104$
                                   1127 ;	free result
      0072B3                       1128 00108$:
      0072B3 7B 36            [12] 1129 	mov	r3,#_process_action_PARM_2
      0072B5 7C 08            [12] 1130 	mov	r4,#(_process_action_PARM_2 >> 8)
      0072B7 12 33 FC         [24] 1131 	lcall	_ak820_outline_0125
      0072BA E0               [24] 1132 	movx	a,@dptr
      0072BB 70 07            [24] 1133 	jnz	00105$
      0072BD                       1134 00104$:
                                   1135 ;	quantum/action.c:511: add_owned_mods(mods);
      0072BD 8D 82            [24] 1136 	mov	dpl, r5
      0072BF 12 7C 8B         [24] 1137 	lcall	_add_owned_mods
      0072C2 80 05            [24] 1138 	sjmp	00106$
      0072C4                       1139 00105$:
                                   1140 ;	quantum/action.c:513: add_owned_weak_mods(mods);
      0072C4 8D 82            [24] 1141 	mov	dpl, r5
      0072C6 12 7C AA         [24] 1142 	lcall	_add_owned_weak_mods
      0072C9                       1143 00106$:
                                   1144 ;	quantum/action.c:515: send_keyboard_report();
      0072C9 12 7F CD         [24] 1145 	lcall	_send_keyboard_report
      0072CC                       1146 00110$:
                                   1147 ;	quantum/action.c:517: register_code(action.key.code);
      0072CC 12 76 F3         [24] 1148 	lcall	_ak820_outline_0078
      0072CF 12 74 F3         [24] 1149 	lcall	_register_code
      0072D2 02 74 DC         [24] 1150 	ljmp	00181$
      0072D5                       1151 00119$:
                                   1152 ;	quantum/action.c:519: unregister_code(action.key.code);
      0072D5 12 76 F3         [24] 1153 	lcall	_ak820_outline_0078
      0072D8 C0 05            [24] 1154 	push	ar5
      0072DA 12 75 60         [24] 1155 	lcall	_unregister_code
      0072DD D0 05            [24] 1156 	pop	ar5
                                   1157 ;	quantum/action.c:520: if (mods) {
      0072DF ED               [12] 1158 	mov	a,r5
      0072E0 70 03            [24] 1159 	jnz	00444$
      0072E2 02 74 DC         [24] 1160 	ljmp	00181$
      0072E5                       1161 00444$:
                                   1162 ;	quantum/action.c:521: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      0072E5 12 77 1F         [24] 1163 	lcall	_ak820_outline_0162
      0072E8 FC               [12] 1164 	mov	r4,a
      0072E9 BC E0 00         [24] 1165 	cjne	r4,#0xe0,00445$
      0072EC                       1166 00445$:
      0072EC 40 07            [24] 1167 	jc	00115$
      0072EE 12 77 1F         [24] 1168 	lcall	_ak820_outline_0162
      0072F1 24 18            [12] 1169 	add	a,#0xff - 0xe7
      0072F3 50 0A            [24] 1170 	jnc	00111$
                                   1171 ;	free result
      0072F5                       1172 00115$:
      0072F5 7B 36            [12] 1173 	mov	r3,#_process_action_PARM_2
      0072F7 7C 08            [12] 1174 	mov	r4,#(_process_action_PARM_2 >> 8)
      0072F9 12 33 FC         [24] 1175 	lcall	_ak820_outline_0125
      0072FC E0               [24] 1176 	movx	a,@dptr
      0072FD 70 07            [24] 1177 	jnz	00112$
      0072FF                       1178 00111$:
                                   1179 ;	quantum/action.c:522: del_owned_mods(mods);
      0072FF 8D 82            [24] 1180 	mov	dpl, r5
      007301 12 7C 9B         [24] 1181 	lcall	_del_owned_mods
      007304 80 05            [24] 1182 	sjmp	00113$
      007306                       1183 00112$:
                                   1184 ;	quantum/action.c:524: del_owned_weak_mods(mods);
      007306 8D 82            [24] 1185 	mov	dpl, r5
      007308 12 7C BA         [24] 1186 	lcall	_del_owned_weak_mods
      00730B                       1187 00113$:
                                   1188 ;	quantum/action.c:526: send_keyboard_report();
      00730B 12 7F CD         [24] 1189 	lcall	_send_keyboard_report
                                   1190 ;	quantum/action.c:529: } break;
      00730E 02 74 DC         [24] 1191 	ljmp	00181$
                                   1192 ;	quantum/action.c:606: case ACT_USAGE:
      007311                       1193 00123$:
                                   1194 ;	quantum/action.c:612: if (record->keycode >= KC_SYSTEM_POWER && record->keycode <= KC_LAUNCHPAD) {
      007311 74 07            [12] 1195 	mov	a,#0x07
      007313 12 38 31         [24] 1196 	lcall	_ak820_outline_0022
      007316 12 48 26         [24] 1197 	lcall	_ak820_outline_0008
      007319 C3               [12] 1198 	clr	c
      00731A EC               [12] 1199 	mov	a,r4
      00731B 94 A5            [12] 1200 	subb	a,#0xa5
      00731D ED               [12] 1201 	mov	a,r5
      00731E 94 00            [12] 1202 	subb	a,#0x00
      007320 40 15            [24] 1203 	jc	00125$
      007322 74 C2            [12] 1204 	mov	a,#0xc2
      007324 9C               [12] 1205 	subb	a,r4
      007325 E4               [12] 1206 	clr	a
      007326 9D               [12] 1207 	subb	a,r5
      007327 40 0E            [24] 1208 	jc	00125$
                                   1209 ;	free result
                                   1210 ;	quantum/action.c:613: owned_usage_key((uint8_t)record->keycode, pressed);
      007329 90 0A 97         [24] 1211 	mov	dptr,#_owned_usage_key_PARM_2
      00732C E5 27            [12] 1212 	mov	a,_process_action_sloc0_1_0
      00732E F0               [24] 1213 	movx	@dptr,a
      00732F 8E 82            [24] 1214 	mov	dpl, r6
      007331 12 7E 78         [24] 1215 	lcall	_owned_usage_key
                                   1216 ;	quantum/action.c:614: break;
      007334 02 74 DC         [24] 1217 	ljmp	00181$
      007337                       1218 00125$:
                                   1219 ;	quantum/action.c:617: switch (action.usage.page) {
      007337 12 76 FA         [24] 1220 	lcall	_ak820_outline_0090
      00733A FF               [12] 1221 	mov	r7,a
      00733B 60 08            [24] 1222 	jz	00127$
      00733D BF 01 02         [24] 1223 	cjne	r7,#0x01,00452$
      007340 80 19            [24] 1224 	sjmp	00128$
      007342                       1225 00452$:
      007342 02 74 DC         [24] 1226 	ljmp	00181$
                                   1227 ;	quantum/action.c:618: case PAGE_SYSTEM:
      007345                       1228 00127$:
                                   1229 ;	quantum/action.c:619: host_system_send(pressed ? action.usage.code : 0);
      007345 E5 27            [12] 1230 	mov	a,_process_action_sloc0_1_0
      007347 60 05            [24] 1231 	jz	00196$
      007349 12 77 0A         [24] 1232 	lcall	_ak820_outline_0132
      00734C 80 04            [24] 1233 	sjmp	00197$
      00734E                       1234 00196$:
      00734E 7E 00            [12] 1235 	mov	r6,#0x00
      007350 7F 00            [12] 1236 	mov	r7,#0x00
      007352                       1237 00197$:
      007352 12 38 8C         [24] 1238 	lcall	_ak820_outline_0120
      007355 12 6C E3         [24] 1239 	lcall	_host_system_send
                                   1240 ;	quantum/action.c:620: break;
      007358 02 74 DC         [24] 1241 	ljmp	00181$
                                   1242 ;	quantum/action.c:621: case PAGE_CONSUMER:
      00735B                       1243 00128$:
                                   1244 ;	quantum/action.c:622: host_consumer_send(pressed ? action.usage.code : 0);
      00735B E5 27            [12] 1245 	mov	a,_process_action_sloc0_1_0
      00735D 60 05            [24] 1246 	jz	00198$
      00735F 12 77 0A         [24] 1247 	lcall	_ak820_outline_0132
      007362 80 04            [24] 1248 	sjmp	00199$
      007364                       1249 00198$:
      007364 7E 00            [12] 1250 	mov	r6,#0x00
      007366 7F 00            [12] 1251 	mov	r7,#0x00
      007368                       1252 00199$:
      007368 12 38 8C         [24] 1253 	lcall	_ak820_outline_0120
      00736B 12 6D 13         [24] 1254 	lcall	_host_consumer_send
                                   1255 ;	quantum/action.c:625: break;
      00736E 02 74 DC         [24] 1256 	ljmp	00181$
                                   1257 ;	quantum/action.c:632: case ACT_LAYER: {
      007371                       1258 00131$:
                                   1259 ;	quantum/action.c:633: uint8_t on = action.layer_bitop.on;
      007371 90 08 37         [24] 1260 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007374 E0               [24] 1261 	movx	a,@dptr
      007375 54 03            [12] 1262 	anl	a,#0x03
      007377 90 08 3B         [24] 1263 	mov	dptr,#_process_action_on_40000_675
      00737A F0               [24] 1264 	movx	@dptr,a
                                   1265 ;	quantum/action.c:636: if (on ? (pressed ? (on & ON_PRESS) : (on & ON_RELEASE)) : !pressed) {
      00737B E0               [24] 1266 	movx	a,@dptr
      00737C FF               [12] 1267 	mov	r7,a
      00737D 60 11            [24] 1268 	jz	00200$
      00737F E5 27            [12] 1269 	mov	a,_process_action_sloc0_1_0
      007381 60 07            [24] 1270 	jz	00202$
      007383 8F 06            [24] 1271 	mov	ar6,r7
      007385 53 06 01         [24] 1272 	anl	ar6,#0x01
      007388 80 10            [24] 1273 	sjmp	00201$
      00738A                       1274 00202$:
      00738A 74 02            [12] 1275 	mov	a,#0x02
      00738C 5F               [12] 1276 	anl	a,r7
      00738D FE               [12] 1277 	mov	r6,a
      00738E 80 0A            [24] 1278 	sjmp	00201$
      007390                       1279 00200$:
      007390 E5 27            [12] 1280 	mov	a,_process_action_sloc0_1_0
      007392 B4 01 00         [24] 1281 	cjne	a,#0x01,00457$
      007395                       1282 00457$:
      007395 92 1F            [24] 1283 	mov  _process_action_sloc1_1_0,c
      007397 E4               [12] 1284 	clr	a
      007398 33               [12] 1285 	rlc	a
      007399 FE               [12] 1286 	mov	r6,a
      00739A                       1287 00201$:
      00739A EE               [12] 1288 	mov	a,r6
      00739B 70 03            [24] 1289 	jnz	00458$
      00739D 02 74 DC         [24] 1290 	ljmp	00181$
      0073A0                       1291 00458$:
                                   1292 ;	quantum/action.c:637: uint8_t shift = action.layer_bitop.part * 4;
      0073A0 12 77 1F         [24] 1293 	lcall	_ak820_outline_0162
      0073A3 C4               [12] 1294 	swap	a
      0073A4 03               [12] 1295 	rr	a
      0073A5 54 07            [12] 1296 	anl	a,#0x07
      0073A7 25 E0            [12] 1297 	add	a,acc
      0073A9 25 E0            [12] 1298 	add	a,acc
      0073AB FF               [12] 1299 	mov	r7,a
                                   1300 ;	quantum/action.c:638: layer_state_t bits = ((layer_state_t)action.layer_bitop.bits) << shift;
      0073AC 12 77 1F         [24] 1301 	lcall	_ak820_outline_0162
      0073AF 54 0F            [12] 1302 	anl	a,#0x0f
      0073B1 FE               [12] 1303 	mov	r6,a
      0073B2 8F F0            [24] 1304 	mov	b,r7
      0073B4 05 F0            [12] 1305 	inc	b
      0073B6 EE               [12] 1306 	mov	a,r6
      0073B7 80 02            [24] 1307 	sjmp	00460$
      0073B9                       1308 00459$:
      0073B9 25 E0            [12] 1309 	add	a,acc
      0073BB                       1310 00460$:
      0073BB D5 F0 FB         [24] 1311 	djnz	b,00459$
      0073BE FE               [12] 1312 	mov	r6,a
                                   1313 ;	quantum/action.c:639: layer_state_t mask = action.layer_bitop.xbit ? ~(((layer_state_t)0xf) << shift) : 0;
      0073BF 12 77 1F         [24] 1314 	lcall	_ak820_outline_0162
      0073C2 30 E4 11         [24] 1315 	jnb	acc.4,00204$
      0073C5 8F F0            [24] 1316 	mov	b,r7
      0073C7 05 F0            [12] 1317 	inc	b
      0073C9 74 0F            [12] 1318 	mov	a,#0x0f
      0073CB 80 02            [24] 1319 	sjmp	00463$
      0073CD                       1320 00462$:
      0073CD 25 E0            [12] 1321 	add	a,acc
      0073CF                       1322 00463$:
      0073CF D5 F0 FB         [24] 1323 	djnz	b,00462$
      0073D2 F4               [12] 1324 	cpl	a
      0073D3 FF               [12] 1325 	mov	r7,a
      0073D4 80 02            [24] 1326 	sjmp	00205$
      0073D6                       1327 00204$:
      0073D6 7F 00            [12] 1328 	mov	r7,#0x00
      0073D8                       1329 00205$:
                                   1330 ;	quantum/action.c:640: bits |= mask;
      0073D8 EE               [12] 1331 	mov	a,r6
      0073D9 42 07            [12] 1332 	orl	ar7,a
                                   1333 ;	quantum/action.c:641: if (!on) {
      0073DB 90 08 3B         [24] 1334 	mov	dptr,#_process_action_on_40000_675
      0073DE E0               [24] 1335 	movx	a,@dptr
      0073DF 70 31            [24] 1336 	jnz	00143$
                                   1337 ;	quantum/action.c:642: switch (action.layer_bitop.op) {
      0073E1 12 76 FA         [24] 1338 	lcall	_ak820_outline_0090
      0073E4 FE               [12] 1339 	mov	r6,a
      0073E5 2E               [12] 1340 	add	a,r6
                                   1341 ;	quantum/action.c:643: case OP_BIT_AND: default_layer_and(bits); break;
      0073E6 90 73 EA         [24] 1342 	mov	dptr,#00465$
      0073E9 73               [24] 1343 	jmp	@a+dptr
      0073EA                       1344 00465$:
      0073EA 80 06            [24] 1345 	sjmp	00132$
      0073EC 80 0C            [24] 1346 	sjmp	00133$
      0073EE 80 12            [24] 1347 	sjmp	00134$
      0073F0 80 18            [24] 1348 	sjmp	00135$
      0073F2                       1349 00132$:
      0073F2 8F 82            [24] 1350 	mov	dpl, r7
      0073F4 12 77 7F         [24] 1351 	lcall	_default_layer_and
      0073F7 02 74 DC         [24] 1352 	ljmp	00181$
                                   1353 ;	quantum/action.c:644: case OP_BIT_OR: default_layer_or(bits); break;
      0073FA                       1354 00133$:
      0073FA 8F 82            [24] 1355 	mov	dpl, r7
      0073FC 12 77 6E         [24] 1356 	lcall	_default_layer_or
      0073FF 02 74 DC         [24] 1357 	ljmp	00181$
                                   1358 ;	quantum/action.c:645: case OP_BIT_XOR: default_layer_xor(bits); break;
      007402                       1359 00134$:
      007402 8F 82            [24] 1360 	mov	dpl, r7
      007404 12 77 95         [24] 1361 	lcall	_default_layer_xor
      007407 02 74 DC         [24] 1362 	ljmp	00181$
                                   1363 ;	quantum/action.c:646: case OP_BIT_SET: default_layer_set(bits); break;
      00740A                       1364 00135$:
      00740A 8F 82            [24] 1365 	mov	dpl, r7
      00740C 12 77 63         [24] 1366 	lcall	_default_layer_set
                                   1367 ;	quantum/action.c:647: }
      00740F 02 74 DC         [24] 1368 	ljmp	00181$
      007412                       1369 00143$:
                                   1370 ;	quantum/action.c:649: switch (action.layer_bitop.op) {
      007412 12 76 FA         [24] 1371 	lcall	_ak820_outline_0090
      007415 FE               [12] 1372 	mov	r6,a
      007416 2E               [12] 1373 	add	a,r6
                                   1374 ;	quantum/action.c:650: case OP_BIT_AND: layer_and(bits); break;
      007417 90 74 1B         [24] 1375 	mov	dptr,#00466$
      00741A 73               [24] 1376 	jmp	@a+dptr
      00741B                       1377 00466$:
      00741B 80 06            [24] 1378 	sjmp	00137$
      00741D 80 0C            [24] 1379 	sjmp	00138$
      00741F 80 12            [24] 1380 	sjmp	00139$
      007421 80 18            [24] 1381 	sjmp	00140$
      007423                       1382 00137$:
      007423 8F 82            [24] 1383 	mov	dpl, r7
      007425 12 79 19         [24] 1384 	lcall	_layer_and
      007428 02 74 DC         [24] 1385 	ljmp	00181$
                                   1386 ;	quantum/action.c:651: case OP_BIT_OR: layer_or(bits); break;
      00742B                       1387 00138$:
      00742B 8F 82            [24] 1388 	mov	dpl, r7
      00742D 12 79 08         [24] 1389 	lcall	_layer_or
      007430 02 74 DC         [24] 1390 	ljmp	00181$
                                   1391 ;	quantum/action.c:652: case OP_BIT_XOR: layer_xor(bits); break;
      007433                       1392 00139$:
      007433 8F 82            [24] 1393 	mov	dpl, r7
      007435 12 79 2F         [24] 1394 	lcall	_layer_xor
      007438 02 74 DC         [24] 1395 	ljmp	00181$
                                   1396 ;	quantum/action.c:653: case OP_BIT_SET: layer_state_set(bits); break;
      00743B                       1397 00140$:
      00743B 8F 82            [24] 1398 	mov	dpl, r7
      00743D 12 78 A5         [24] 1399 	lcall	_layer_state_set
                                   1400 ;	quantum/action.c:657: break;
      007440 02 74 DC         [24] 1401 	ljmp	00181$
                                   1402 ;	quantum/action.c:659: case ACT_LAYER_MODS:
      007443                       1403 00147$:
                                   1404 ;	quantum/action.c:660: if (pressed) {
      007443 E5 27            [12] 1405 	mov	a,_process_action_sloc0_1_0
      007445 60 11            [24] 1406 	jz	00149$
                                   1407 ;	quantum/action.c:661: layer_hold_on(action.layer_mods.layer);
      007447 12 77 03         [24] 1408 	lcall	_ak820_outline_0113
      00744A F5 82            [12] 1409 	mov	dpl,a
      00744C 12 78 05         [24] 1410 	lcall	_layer_hold_on
                                   1411 ;	quantum/action.c:662: register_mods(action.layer_mods.mods);
      00744F 12 76 F3         [24] 1412 	lcall	_ak820_outline_0078
      007452 12 76 16         [24] 1413 	lcall	_register_mods
      007455 02 74 DC         [24] 1414 	ljmp	00181$
      007458                       1415 00149$:
                                   1416 ;	quantum/action.c:664: unregister_mods(action.layer_mods.mods);
      007458 12 76 F3         [24] 1417 	lcall	_ak820_outline_0078
      00745B 12 76 2A         [24] 1418 	lcall	_unregister_mods
                                   1419 ;	quantum/action.c:665: layer_hold_off(action.layer_mods.layer);
      00745E 12 77 03         [24] 1420 	lcall	_ak820_outline_0113
      007461 F5 82            [12] 1421 	mov	dpl,a
      007463 12 78 3D         [24] 1422 	lcall	_layer_hold_off
                                   1423 ;	quantum/action.c:667: break;
      007466 02 74 DC         [24] 1424 	ljmp	00181$
                                   1425 ;	quantum/action.c:669: case ACT_LAYER_TAP_EXT:
      007469                       1426 00152$:
                                   1427 ;	quantum/action.c:670: switch (action.layer_tap.code) {
      007469 12 77 1F         [24] 1428 	lcall	_ak820_outline_0162
      00746C FF               [12] 1429 	mov	r7,a
      00746D BF F1 02         [24] 1430 	cjne	r7,#0xf1,00468$
      007470 80 0A            [24] 1431 	sjmp	00154$
      007472                       1432 00468$:
      007472 BF F2 02         [24] 1433 	cjne	r7,#0xf2,00469$
      007475 80 19            [24] 1434 	sjmp	00155$
      007477                       1435 00469$:
                                   1436 ;	quantum/action.c:686: momentary_layer_action:
      007477 BF F3 3B         [24] 1437 	cjne	r7,#0xf3,00160$
      00747A 80 28            [24] 1438 	sjmp	00156$
      00747C                       1439 00154$:
                                   1440 ;	quantum/action.c:687: pressed ? layer_hold_on(action.layer_tap.val) : layer_hold_off(action.layer_tap.val);
      00747C E5 27            [12] 1441 	mov	a,_process_action_sloc0_1_0
      00747E 60 08            [24] 1442 	jz	00206$
      007480 12 76 D9         [24] 1443 	lcall	_ak820_outline_0042
      007483 12 78 05         [24] 1444 	lcall	_layer_hold_on
      007486 80 54            [24] 1445 	sjmp	00181$
      007488                       1446 00206$:
      007488 12 76 D9         [24] 1447 	lcall	_ak820_outline_0042
      00748B 12 78 3D         [24] 1448 	lcall	_layer_hold_off
                                   1449 ;	quantum/action.c:688: break;
                                   1450 ;	quantum/action.c:689: case OP_OFF_ON:
      00748E 80 4C            [24] 1451 	sjmp	00181$
      007490                       1452 00155$:
                                   1453 ;	quantum/action.c:690: pressed ? layer_off(action.layer_tap.val) : layer_on(action.layer_tap.val);
      007490 E5 27            [12] 1454 	mov	a,_process_action_sloc0_1_0
      007492 60 08            [24] 1455 	jz	00208$
      007494 12 76 D9         [24] 1456 	lcall	_ak820_outline_0042
      007497 12 78 EA         [24] 1457 	lcall	_layer_off
      00749A 80 40            [24] 1458 	sjmp	00181$
      00749C                       1459 00208$:
      00749C 12 76 D9         [24] 1460 	lcall	_ak820_outline_0042
      00749F 12 78 CF         [24] 1461 	lcall	_layer_on
                                   1462 ;	quantum/action.c:691: break;
                                   1463 ;	quantum/action.c:692: case OP_SET_CLEAR:
      0074A2 80 38            [24] 1464 	sjmp	00181$
      0074A4                       1465 00156$:
                                   1466 ;	quantum/action.c:693: pressed ? layer_move(action.layer_tap.val) : layer_clear();
      0074A4 E5 27            [12] 1467 	mov	a,_process_action_sloc0_1_0
      0074A6 60 08            [24] 1468 	jz	00210$
      0074A8 12 76 D9         [24] 1469 	lcall	_ak820_outline_0042
      0074AB 12 78 B9         [24] 1470 	lcall	_layer_move
      0074AE 80 2C            [24] 1471 	sjmp	00181$
      0074B0                       1472 00210$:
      0074B0 12 78 B3         [24] 1473 	lcall	_layer_clear
                                   1474 ;	quantum/action.c:694: break;
                                   1475 ;	quantum/action.c:740: default:
      0074B3 80 27            [24] 1476 	sjmp	00181$
      0074B5                       1477 00160$:
                                   1478 ;	quantum/action.c:747: if (pressed) {
      0074B5 E5 27            [12] 1479 	mov	a,_process_action_sloc0_1_0
      0074B7 60 08            [24] 1480 	jz	00163$
                                   1481 ;	quantum/action.c:749: register_code(action.layer_tap.code);
      0074B9 12 76 F3         [24] 1482 	lcall	_ak820_outline_0078
      0074BC 12 74 F3         [24] 1483 	lcall	_register_code
                                   1484 ;	quantum/action.c:751: ac_dprintf("KEYMAP_TAP_KEY: Tap: unregister_code\n");
      0074BF 80 1B            [24] 1485 	sjmp	00181$
      0074C1                       1486 00163$:
                                   1487 ;	quantum/action.c:752: if (action.layer_tap.code == KC_CAPS) {
      0074C1 12 77 1F         [24] 1488 	lcall	_ak820_outline_0162
      0074C4 FF               [12] 1489 	mov	r7,a
      0074C5 BF 39 0E         [24] 1490 	cjne	r7,#0x39,00175$
                                   1491 ;	quantum/action.c:753: wait_ms(TAP_HOLD_CAPS_DELAY);
      0074C8 7F 50            [12] 1492 	mov	r7,#0x50
      0074CA                       1493 00187$:
      0074CA EF               [12] 1494 	mov	a,r7
      0074CB 60 09            [24] 1495 	jz	00175$
      0074CD 90 00 01         [24] 1496 	mov	dptr,#0x0001
      0074D0 12 58 BD         [24] 1497 	lcall	_mDelaymS
      0074D3 1F               [12] 1498 	dec	r7
                                   1499 ;	quantum/action.c:755: wait_ms(TAP_CODE_DELAY);
      0074D4 80 F4            [24] 1500 	sjmp	00187$
      0074D6                       1501 00175$:
                                   1502 ;	quantum/action.c:757: unregister_code(action.layer_tap.code);
      0074D6 12 76 F3         [24] 1503 	lcall	_ak820_outline_0078
      0074D9 12 75 60         [24] 1504 	lcall	_unregister_code
                                   1505 ;	quantum/action.c:840: }
      0074DC                       1506 00181$:
                                   1507 ;	quantum/action.c:861: switch (action.kind.id) {
      0074DC 90 08 37         [24] 1508 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0074DF E0               [24] 1509 	movx	a,@dptr
      0074E0 C4               [12] 1510 	swap	a
      0074E1 54 0F            [12] 1511 	anl	a,#0x0f
      0074E3 FF               [12] 1512 	mov	r7,a
      0074E4 BF 08 02         [24] 1513 	cjne	r7,#0x08,00478$
      0074E7 80 03            [24] 1514 	sjmp	00183$
      0074E9                       1515 00478$:
      0074E9 BF 09 06         [24] 1516 	cjne	r7,#0x09,00192$
                                   1517 ;	quantum/action.c:863: case ACT_LAYER_MODS:
      0074EC                       1518 00183$:
                                   1519 ;	quantum/action.c:868: led_set(host_keyboard_leds());
      0074EC 12 6C 48         [24] 1520 	lcall	_host_keyboard_leds
                                   1521 ;	quantum/action.c:872: }
                                   1522 ;	quantum/action.c:925: }
      0074EF 02 97 10         [24] 1523 	ljmp	_led_set
      0074F2                       1524 00192$:
      0074F2 22               [24] 1525 	ret
                                   1526 ;------------------------------------------------------------
                                   1527 ;Allocation info for local variables in function 'register_code'
                                   1528 ;------------------------------------------------------------
                                   1529 ;code          Allocated with name '_register_code_code_10000_709'
                                   1530 ;------------------------------------------------------------
                                   1531 ;	quantum/action.c:931: __attribute__((weak)) void register_code(uint8_t code) {
                                   1532 ;	-----------------------------------------
                                   1533 ;	 function register_code
                                   1534 ;	-----------------------------------------
      0074F3                       1535 _register_code:
      0074F3 E5 82            [12] 1536 	mov	a,dpl
      0074F5 90 08 3C         [24] 1537 	mov	dptr,#_register_code_code_10000_709
      0074F8 F0               [24] 1538 	movx	@dptr,a
                                   1539 ;	quantum/action.c:932: if (code == KC_NO) {
      0074F9 E0               [24] 1540 	movx	a,@dptr
      0074FA FF               [12] 1541 	mov	r7,a
      0074FB 70 01            [24] 1542 	jnz	00123$
                                   1543 ;	quantum/action.c:933: return;
      0074FD 22               [24] 1544 	ret
      0074FE                       1545 00123$:
                                   1546 ;	quantum/action.c:968: } else if (IS_BASIC_KEYCODE(code)) {
      0074FE BF 04 00         [24] 1547 	cjne	r7,#0x04,00186$
      007501                       1548 00186$:
      007501 40 12            [24] 1549 	jc	00119$
      007503 EF               [12] 1550 	mov	a,r7
      007504 24 5B            [12] 1551 	add	a,#0xff - 0xa4
      007506 40 0D            [24] 1552 	jc	00119$
                                   1553 ;	free result
                                   1554 ;	quantum/action.c:973: if (!add_owned_key(code)) return;
      007508 8F 82            [24] 1555 	mov	dpl, r7
      00750A 12 7D 2F         [24] 1556 	lcall	_add_owned_key
      00750D E5 82            [12] 1557 	mov	a, dpl
      00750F 70 01            [24] 1558 	jnz	00104$
      007511 22               [24] 1559 	ret
      007512                       1560 00104$:
                                   1561 ;	quantum/action.c:987: send_keyboard_report();
      007512 02 7F CD         [24] 1562 	ljmp	_send_keyboard_report
      007515                       1563 00119$:
                                   1564 ;	quantum/action.c:988: } else if (IS_MODIFIER_KEYCODE(code)) {
      007515 12 77 24         [24] 1565 	lcall	_ak820_outline_0170
      007518 BF E0 00         [24] 1566 	cjne	r7,#0xe0,00190$
      00751B                       1567 00190$:
      00751B 40 1A            [24] 1568 	jc	00115$
      00751D EF               [12] 1569 	mov	a,r7
      00751E 24 18            [12] 1570 	add	a,#0xff - 0xe7
      007520 40 15            [24] 1571 	jc	00115$
                                   1572 ;	free result
                                   1573 ;	quantum/action.c:989: add_owned_mods(MOD_BIT(code));
      007522 74 07            [12] 1574 	mov	a,#0x07
      007524 5F               [12] 1575 	anl	a,r7
      007525 12 76 E2         [24] 1576 	lcall	_ak820_outline_0063
      007528 80 02            [24] 1577 	sjmp	00194$
      00752A                       1578 00193$:
      00752A 25 E0            [12] 1579 	add	a,acc
      00752C                       1580 00194$:
      00752C D5 F0 FB         [24] 1581 	djnz	b,00193$
      00752F F5 82            [12] 1582 	mov	dpl,a
      007531 12 7C 8B         [24] 1583 	lcall	_add_owned_mods
                                   1584 ;	quantum/action.c:990: send_keyboard_report();
      007534 02 7F CD         [24] 1585 	ljmp	_send_keyboard_report
      007537                       1586 00115$:
                                   1587 ;	quantum/action.c:993: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      007537 12 77 24         [24] 1588 	lcall	_ak820_outline_0170
      00753A BF A5 00         [24] 1589 	cjne	r7,#0xa5,00195$
      00753D                       1590 00195$:
      00753D 40 05            [24] 1591 	jc	00113$
      00753F EF               [12] 1592 	mov	a,r7
      007540 24 58            [12] 1593 	add	a,#0xff - 0xa7
      007542 50 0D            [24] 1594 	jnc	00108$
                                   1595 ;	free result
      007544                       1596 00113$:
      007544 12 77 24         [24] 1597 	lcall	_ak820_outline_0170
      007547 BF A8 00         [24] 1598 	cjne	r7,#0xa8,00198$
      00754A                       1599 00198$:
      00754A 40 13            [24] 1600 	jc	00125$
      00754C EF               [12] 1601 	mov	a,r7
      00754D 24 3D            [12] 1602 	add	a,#0xff - 0xc2
      00754F 40 0E            [24] 1603 	jc	00125$
                                   1604 ;	free result
      007551                       1605 00108$:
                                   1606 ;	quantum/action.c:995: owned_usage_key(code, true);
      007551 12 77 24         [24] 1607 	lcall	_ak820_outline_0170
      007554 90 0A 97         [24] 1608 	mov	dptr,#_owned_usage_key_PARM_2
      007557 74 01            [12] 1609 	mov	a,#0x01
      007559 F0               [24] 1610 	movx	@dptr,a
      00755A 8F 82            [24] 1611 	mov	dpl, r7
                                   1612 ;	quantum/action.c:1003: register_mouse(code, true);
                                   1613 ;	quantum/action.c:1005: }
      00755C 02 7E 78         [24] 1614 	ljmp	_owned_usage_key
      00755F                       1615 00125$:
      00755F 22               [24] 1616 	ret
                                   1617 ;------------------------------------------------------------
                                   1618 ;Allocation info for local variables in function 'unregister_code'
                                   1619 ;------------------------------------------------------------
                                   1620 ;code          Allocated with name '_unregister_code_code_10000_723'
                                   1621 ;------------------------------------------------------------
                                   1622 ;	quantum/action.c:1011: __attribute__((weak)) void unregister_code(uint8_t code) {
                                   1623 ;	-----------------------------------------
                                   1624 ;	 function unregister_code
                                   1625 ;	-----------------------------------------
      007560                       1626 _unregister_code:
      007560 E5 82            [12] 1627 	mov	a,dpl
      007562 90 08 3D         [24] 1628 	mov	dptr,#_unregister_code_code_10000_723
      007565 F0               [24] 1629 	movx	@dptr,a
                                   1630 ;	quantum/action.c:1012: if (code == KC_NO) {
      007566 E0               [24] 1631 	movx	a,@dptr
      007567 FF               [12] 1632 	mov	r7,a
      007568 70 01            [24] 1633 	jnz	00121$
                                   1634 ;	quantum/action.c:1013: return;
      00756A 22               [24] 1635 	ret
      00756B                       1636 00121$:
                                   1637 ;	quantum/action.c:1045: } else if (IS_BASIC_KEYCODE(code)) {
      00756B BF 04 00         [24] 1638 	cjne	r7,#0x04,00184$
      00756E                       1639 00184$:
      00756E 40 12            [24] 1640 	jc	00117$
      007570 EF               [12] 1641 	mov	a,r7
      007571 24 5B            [12] 1642 	add	a,#0xff - 0xa4
      007573 40 0D            [24] 1643 	jc	00117$
                                   1644 ;	free result
                                   1645 ;	quantum/action.c:1047: if (!del_owned_key(code)) return;
      007575 8F 82            [24] 1646 	mov	dpl, r7
      007577 12 7D AC         [24] 1647 	lcall	_del_owned_key
      00757A E5 82            [12] 1648 	mov	a, dpl
      00757C 70 01            [24] 1649 	jnz	00102$
      00757E 22               [24] 1650 	ret
      00757F                       1651 00102$:
                                   1652 ;	quantum/action.c:1054: send_keyboard_report();
      00757F 02 7F CD         [24] 1653 	ljmp	_send_keyboard_report
      007582                       1654 00117$:
                                   1655 ;	quantum/action.c:1055: } else if (IS_MODIFIER_KEYCODE(code)) {
      007582 12 77 2A         [24] 1656 	lcall	_ak820_outline_0171
      007585 BF E0 00         [24] 1657 	cjne	r7,#0xe0,00188$
      007588                       1658 00188$:
      007588 40 1A            [24] 1659 	jc	00113$
      00758A EF               [12] 1660 	mov	a,r7
      00758B 24 18            [12] 1661 	add	a,#0xff - 0xe7
      00758D 40 15            [24] 1662 	jc	00113$
                                   1663 ;	free result
                                   1664 ;	quantum/action.c:1056: del_owned_mods(MOD_BIT(code));
      00758F 74 07            [12] 1665 	mov	a,#0x07
      007591 5F               [12] 1666 	anl	a,r7
      007592 12 76 E2         [24] 1667 	lcall	_ak820_outline_0063
      007595 80 02            [24] 1668 	sjmp	00192$
      007597                       1669 00191$:
      007597 25 E0            [12] 1670 	add	a,acc
      007599                       1671 00192$:
      007599 D5 F0 FB         [24] 1672 	djnz	b,00191$
      00759C F5 82            [12] 1673 	mov	dpl,a
      00759E 12 7C 9B         [24] 1674 	lcall	_del_owned_mods
                                   1675 ;	quantum/action.c:1057: send_keyboard_report();
      0075A1 02 7F CD         [24] 1676 	ljmp	_send_keyboard_report
      0075A4                       1677 00113$:
                                   1678 ;	quantum/action.c:1060: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      0075A4 12 77 2A         [24] 1679 	lcall	_ak820_outline_0171
      0075A7 BF A5 00         [24] 1680 	cjne	r7,#0xa5,00193$
      0075AA                       1681 00193$:
      0075AA 40 05            [24] 1682 	jc	00111$
      0075AC EF               [12] 1683 	mov	a,r7
      0075AD 24 58            [12] 1684 	add	a,#0xff - 0xa7
      0075AF 50 0D            [24] 1685 	jnc	00106$
                                   1686 ;	free result
      0075B1                       1687 00111$:
      0075B1 12 77 2A         [24] 1688 	lcall	_ak820_outline_0171
      0075B4 BF A8 00         [24] 1689 	cjne	r7,#0xa8,00196$
      0075B7                       1690 00196$:
      0075B7 40 12            [24] 1691 	jc	00123$
      0075B9 EF               [12] 1692 	mov	a,r7
      0075BA 24 3D            [12] 1693 	add	a,#0xff - 0xc2
      0075BC 40 0D            [24] 1694 	jc	00123$
                                   1695 ;	free result
      0075BE                       1696 00106$:
                                   1697 ;	quantum/action.c:1062: owned_usage_key(code, false);
      0075BE 12 77 2A         [24] 1698 	lcall	_ak820_outline_0171
      0075C1 90 0A 97         [24] 1699 	mov	dptr,#_owned_usage_key_PARM_2
      0075C4 E4               [12] 1700 	clr	a
      0075C5 F0               [24] 1701 	movx	@dptr,a
      0075C6 8F 82            [24] 1702 	mov	dpl, r7
                                   1703 ;	quantum/action.c:1070: register_mouse(code, false);
                                   1704 ;	quantum/action.c:1072: }
      0075C8 02 7E 78         [24] 1705 	ljmp	_owned_usage_key
      0075CB                       1706 00123$:
      0075CB 22               [24] 1707 	ret
                                   1708 ;------------------------------------------------------------
                                   1709 ;Allocation info for local variables in function 'tap_code_delay'
                                   1710 ;------------------------------------------------------------
                                   1711 ;delay         Allocated with name '_tap_code_delay_PARM_2'
                                   1712 ;code          Allocated with name '_tap_code_delay_code_10000_736'
                                   1713 ;i             Allocated with name '_tap_code_delay_i_20000_738'
                                   1714 ;i             Allocated with name '_tap_code_delay_i_50000_741'
                                   1715 ;------------------------------------------------------------
                                   1716 ;	quantum/action.c:1079: __attribute__((weak)) void tap_code_delay(uint8_t code, uint16_t delay) {
                                   1717 ;	-----------------------------------------
                                   1718 ;	 function tap_code_delay
                                   1719 ;	-----------------------------------------
      0075CC                       1720 _tap_code_delay:
      0075CC E5 82            [12] 1721 	mov	a,dpl
      0075CE 90 08 40         [24] 1722 	mov	dptr,#_tap_code_delay_code_10000_736
      0075D1 F0               [24] 1723 	movx	@dptr,a
                                   1724 ;	quantum/action.c:1080: register_code(code);
      0075D2 E0               [24] 1725 	movx	a,@dptr
      0075D3 FF               [12] 1726 	mov	r7,a
      0075D4 F5 82            [12] 1727 	mov	dpl,a
      0075D6 C0 07            [24] 1728 	push	ar7
      0075D8 12 74 F3         [24] 1729 	lcall	_register_code
      0075DB D0 07            [24] 1730 	pop	ar7
                                   1731 ;	quantum/action.c:1081: for (uint16_t i = delay; i > 0; i--) {
      0075DD 90 08 3E         [24] 1732 	mov	dptr,#_tap_code_delay_PARM_2
      0075E0 12 38 64         [24] 1733 	lcall	_ak820_outline_0080
      0075E3                       1734 00110$:
      0075E3 ED               [12] 1735 	mov	a,r5
      0075E4 4E               [12] 1736 	orl	a,r6
      0075E5 60 0D            [24] 1737 	jz	00105$
                                   1738 ;	quantum/action.c:1082: wait_ms(1);
      0075E7 90 00 01         [24] 1739 	mov	dptr,#0x0001
      0075EA 12 58 BD         [24] 1740 	lcall	_mDelaymS
                                   1741 ;	quantum/action.c:1081: for (uint16_t i = delay; i > 0; i--) {
      0075ED 1D               [12] 1742 	dec	r5
      0075EE BD FF 01         [24] 1743 	cjne	r5,#0xff,00141$
      0075F1 1E               [12] 1744 	dec	r6
      0075F2                       1745 00141$:
      0075F2 80 EF            [24] 1746 	sjmp	00110$
      0075F4                       1747 00105$:
                                   1748 ;	quantum/action.c:1084: unregister_code(code);
      0075F4 8F 82            [24] 1749 	mov	dpl, r7
                                   1750 ;	quantum/action.c:1085: }
      0075F6 02 75 60         [24] 1751 	ljmp	_unregister_code
                                   1752 ;------------------------------------------------------------
                                   1753 ;Allocation info for local variables in function 'tap_code'
                                   1754 ;------------------------------------------------------------
                                   1755 ;code          Allocated with name '_tap_code_code_10000_743'
                                   1756 ;------------------------------------------------------------
                                   1757 ;	quantum/action.c:1091: __attribute__((weak)) void tap_code(uint8_t code) {
                                   1758 ;	-----------------------------------------
                                   1759 ;	 function tap_code
                                   1760 ;	-----------------------------------------
      0075F9                       1761 _tap_code:
      0075F9 E5 82            [12] 1762 	mov	a,dpl
      0075FB 90 08 41         [24] 1763 	mov	dptr,#_tap_code_code_10000_743
      0075FE F0               [24] 1764 	movx	@dptr,a
                                   1765 ;	quantum/action.c:1092: tap_code_delay(code, code == KC_CAPS ? QS_tap_hold_caps_delay : QS_tap_code_delay);
      0075FF E0               [24] 1766 	movx	a,@dptr
      007600 FF               [12] 1767 	mov	r7,a
      007601 BF 39 04         [24] 1768 	cjne	r7,#0x39,00103$
      007604 7E 50            [12] 1769 	mov	r6,#0x50
      007606 80 02            [24] 1770 	sjmp	00104$
      007608                       1771 00103$:
      007608 7E 00            [12] 1772 	mov	r6,#0x00
      00760A                       1773 00104$:
      00760A 90 08 3E         [24] 1774 	mov	dptr,#_tap_code_delay_PARM_2
      00760D EE               [12] 1775 	mov	a,r6
      00760E 12 38 9C         [24] 1776 	lcall	_ak820_outline_0136
      007611 8F 82            [24] 1777 	mov	dpl, r7
                                   1778 ;	quantum/action.c:1093: }
      007613 02 75 CC         [24] 1779 	ljmp	_tap_code_delay
                                   1780 ;------------------------------------------------------------
                                   1781 ;Allocation info for local variables in function 'register_mods'
                                   1782 ;------------------------------------------------------------
                                   1783 ;mods          Allocated with name '_register_mods_mods_10000_745'
                                   1784 ;------------------------------------------------------------
                                   1785 ;	quantum/action.c:1099: __attribute__((weak)) void register_mods(uint8_t mods) {
                                   1786 ;	-----------------------------------------
                                   1787 ;	 function register_mods
                                   1788 ;	-----------------------------------------
      007616                       1789 _register_mods:
      007616 E5 82            [12] 1790 	mov	a,dpl
      007618 90 08 42         [24] 1791 	mov	dptr,#_register_mods_mods_10000_745
      00761B F0               [24] 1792 	movx	@dptr,a
                                   1793 ;	quantum/action.c:1100: if (mods) {
      00761C E0               [24] 1794 	movx	a,@dptr
      00761D FF               [12] 1795 	mov	r7,a
      00761E E0               [24] 1796 	movx	a,@dptr
      00761F 60 08            [24] 1797 	jz	00103$
                                   1798 ;	quantum/action.c:1101: add_owned_mods(mods);
      007621 8F 82            [24] 1799 	mov	dpl, r7
      007623 12 7C 8B         [24] 1800 	lcall	_add_owned_mods
                                   1801 ;	quantum/action.c:1102: send_keyboard_report();
                                   1802 ;	quantum/action.c:1104: }
      007626 02 7F CD         [24] 1803 	ljmp	_send_keyboard_report
      007629                       1804 00103$:
      007629 22               [24] 1805 	ret
                                   1806 ;------------------------------------------------------------
                                   1807 ;Allocation info for local variables in function 'unregister_mods'
                                   1808 ;------------------------------------------------------------
                                   1809 ;mods          Allocated with name '_unregister_mods_mods_10000_749'
                                   1810 ;------------------------------------------------------------
                                   1811 ;	quantum/action.c:1110: __attribute__((weak)) void unregister_mods(uint8_t mods) {
                                   1812 ;	-----------------------------------------
                                   1813 ;	 function unregister_mods
                                   1814 ;	-----------------------------------------
      00762A                       1815 _unregister_mods:
      00762A E5 82            [12] 1816 	mov	a,dpl
      00762C 90 08 43         [24] 1817 	mov	dptr,#_unregister_mods_mods_10000_749
      00762F F0               [24] 1818 	movx	@dptr,a
                                   1819 ;	quantum/action.c:1111: if (mods) {
      007630 E0               [24] 1820 	movx	a,@dptr
      007631 FF               [12] 1821 	mov	r7,a
      007632 E0               [24] 1822 	movx	a,@dptr
      007633 60 08            [24] 1823 	jz	00103$
                                   1824 ;	quantum/action.c:1112: del_owned_mods(mods);
      007635 8F 82            [24] 1825 	mov	dpl, r7
      007637 12 7C 9B         [24] 1826 	lcall	_del_owned_mods
                                   1827 ;	quantum/action.c:1113: send_keyboard_report();
                                   1828 ;	quantum/action.c:1115: }
      00763A 02 7F CD         [24] 1829 	ljmp	_send_keyboard_report
      00763D                       1830 00103$:
      00763D 22               [24] 1831 	ret
                                   1832 ;------------------------------------------------------------
                                   1833 ;Allocation info for local variables in function 'register_weak_mods'
                                   1834 ;------------------------------------------------------------
                                   1835 ;mods          Allocated with name '_register_weak_mods_mods_10000_753'
                                   1836 ;------------------------------------------------------------
                                   1837 ;	quantum/action.c:1121: __attribute__((weak)) void register_weak_mods(uint8_t mods) {
                                   1838 ;	-----------------------------------------
                                   1839 ;	 function register_weak_mods
                                   1840 ;	-----------------------------------------
      00763E                       1841 _register_weak_mods:
      00763E E5 82            [12] 1842 	mov	a,dpl
      007640 90 08 44         [24] 1843 	mov	dptr,#_register_weak_mods_mods_10000_753
      007643 F0               [24] 1844 	movx	@dptr,a
                                   1845 ;	quantum/action.c:1122: if (mods) {
      007644 E0               [24] 1846 	movx	a,@dptr
      007645 FF               [12] 1847 	mov	r7,a
      007646 E0               [24] 1848 	movx	a,@dptr
      007647 60 08            [24] 1849 	jz	00103$
                                   1850 ;	quantum/action.c:1123: add_owned_weak_mods(mods);
      007649 8F 82            [24] 1851 	mov	dpl, r7
      00764B 12 7C AA         [24] 1852 	lcall	_add_owned_weak_mods
                                   1853 ;	quantum/action.c:1124: send_keyboard_report();
                                   1854 ;	quantum/action.c:1126: }
      00764E 02 7F CD         [24] 1855 	ljmp	_send_keyboard_report
      007651                       1856 00103$:
      007651 22               [24] 1857 	ret
                                   1858 ;------------------------------------------------------------
                                   1859 ;Allocation info for local variables in function 'unregister_weak_mods'
                                   1860 ;------------------------------------------------------------
                                   1861 ;mods          Allocated with name '_unregister_weak_mods_mods_10000_757'
                                   1862 ;------------------------------------------------------------
                                   1863 ;	quantum/action.c:1132: __attribute__((weak)) void unregister_weak_mods(uint8_t mods) {
                                   1864 ;	-----------------------------------------
                                   1865 ;	 function unregister_weak_mods
                                   1866 ;	-----------------------------------------
      007652                       1867 _unregister_weak_mods:
      007652 E5 82            [12] 1868 	mov	a,dpl
      007654 90 08 45         [24] 1869 	mov	dptr,#_unregister_weak_mods_mods_10000_757
      007657 F0               [24] 1870 	movx	@dptr,a
                                   1871 ;	quantum/action.c:1133: if (mods) {
      007658 E0               [24] 1872 	movx	a,@dptr
      007659 FF               [12] 1873 	mov	r7,a
      00765A E0               [24] 1874 	movx	a,@dptr
      00765B 60 08            [24] 1875 	jz	00103$
                                   1876 ;	quantum/action.c:1134: del_owned_weak_mods(mods);
      00765D 8F 82            [24] 1877 	mov	dpl, r7
      00765F 12 7C BA         [24] 1878 	lcall	_del_owned_weak_mods
                                   1879 ;	quantum/action.c:1135: send_keyboard_report();
                                   1880 ;	quantum/action.c:1137: }
      007662 02 7F CD         [24] 1881 	ljmp	_send_keyboard_report
      007665                       1882 00103$:
      007665 22               [24] 1883 	ret
                                   1884 ;------------------------------------------------------------
                                   1885 ;Allocation info for local variables in function 'clear_keyboard'
                                   1886 ;------------------------------------------------------------
                                   1887 ;	quantum/action.c:1143: void clear_keyboard(void) {
                                   1888 ;	-----------------------------------------
                                   1889 ;	 function clear_keyboard
                                   1890 ;	-----------------------------------------
      007666                       1891 _clear_keyboard:
                                   1892 ;	quantum/action.c:1144: clear_mods();
      007666 12 80 48         [24] 1893 	lcall	_clear_mods
                                   1894 ;	quantum/action.c:1145: clear_keyboard_but_mods();
                                   1895 ;	quantum/action.c:1146: }
      007669 02 76 6C         [24] 1896 	ljmp	_clear_keyboard_but_mods
                                   1897 ;------------------------------------------------------------
                                   1898 ;Allocation info for local variables in function 'clear_keyboard_but_mods'
                                   1899 ;------------------------------------------------------------
                                   1900 ;	quantum/action.c:1152: void clear_keyboard_but_mods(void) {
                                   1901 ;	-----------------------------------------
                                   1902 ;	 function clear_keyboard_but_mods
                                   1903 ;	-----------------------------------------
      00766C                       1904 _clear_keyboard_but_mods:
                                   1905 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      00766C 90 0D C4         [24] 1906 	mov	dptr,#_actual_keyboard_report
      00766F 75 F0 00         [24] 1907 	mov	b, #0x00
      007672 12 6F 1F         [24] 1908 	lcall	_clear_keys_from_report
                                   1909 ;	quantum/action.c:1154: clear_keyboard_but_mods_and_keys();
                                   1910 ;	quantum/action.c:1155: }
      007675 02 76 78         [24] 1911 	ljmp	_clear_keyboard_but_mods_and_keys
                                   1912 ;------------------------------------------------------------
                                   1913 ;Allocation info for local variables in function 'clear_keyboard_but_mods_and_keys'
                                   1914 ;------------------------------------------------------------
                                   1915 ;	quantum/action.c:1161: void clear_keyboard_but_mods_and_keys(void) {
                                   1916 ;	-----------------------------------------
                                   1917 ;	 function clear_keyboard_but_mods_and_keys
                                   1918 ;	-----------------------------------------
      007678                       1919 _clear_keyboard_but_mods_and_keys:
                                   1920 ;	quantum/action.c:1163: ak820_tapping_cancel();
      007678 12 46 CB         [24] 1921 	lcall	_ak820_tapping_cancel
                                   1922 ;	quantum/action.c:1171: ak820_oneshot_cancel();
      00767B 12 2E F0         [24] 1923 	lcall	_ak820_oneshot_cancel
                                   1924 ;	quantum/action.c:1174: ak820_combo_cancel();
      00767E 12 35 70         [24] 1925 	lcall	_ak820_combo_cancel
                                   1926 ;	quantum/action.c:1177: repeat_key_cancel();
      007681 12 A0 76         [24] 1927 	lcall	_repeat_key_cancel
                                   1928 ;	quantum/action.c:1179: clear_owned_mods();
      007684 12 7C CA         [24] 1929 	lcall	_clear_owned_mods
                                   1930 ;	quantum/action.c:1180: clear_owned_keys();
      007687 12 7D 02         [24] 1931 	lcall	_clear_owned_keys
                                   1932 ;	quantum/action.c:1181: clear_owned_usages();
      00768A 12 7E 40         [24] 1933 	lcall	_clear_owned_usages
                                   1934 ;	quantum/action.c:1182: layer_hold_clear();
      00768D 12 78 76         [24] 1935 	lcall	_layer_hold_clear
                                   1936 ;	quantum/action.c:1184: clear_macro_tri_layer();
      007690 12 9B C5         [24] 1937 	lcall	_clear_macro_tri_layer
                                   1938 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007693 90 0D C4         [24] 1939 	mov	dptr,#_actual_keyboard_report
      007696 75 F0 00         [24] 1940 	mov	b, #0x00
      007699 12 6F 1F         [24] 1941 	lcall	_clear_keys_from_report
                                   1942 ;	quantum/action.c:1189: host_system_send(0);
      00769C 90 00 00         [24] 1943 	mov	dptr,#0x0000
      00769F 12 6C E3         [24] 1944 	lcall	_host_system_send
                                   1945 ;	quantum/action.c:1190: host_consumer_send(0);
      0076A2 90 00 00         [24] 1946 	mov	dptr,#0x0000
      0076A5 12 6D 13         [24] 1947 	lcall	_host_consumer_send
                                   1948 ;	quantum/action.c:1192: clear_weak_mods();
      0076A8 12 80 7D         [24] 1949 	lcall	_clear_weak_mods
                                   1950 ;	quantum/action.c:1193: send_keyboard_report();
                                   1951 ;	quantum/action.c:1201: }
      0076AB 02 7F CD         [24] 1952 	ljmp	_send_keyboard_report
                                   1953 ;------------------------------------------------------------
                                   1954 ;Allocation info for local variables in function 'is_tap_record'
                                   1955 ;------------------------------------------------------------
                                   1956 ;record        Allocated with name '_is_tap_record_record_10000_773'
                                   1957 ;action        Allocated with name '_is_tap_record_action_10001_777'
                                   1958 ;------------------------------------------------------------
                                   1959 ;	quantum/action.c:1207: bool is_tap_record(keyrecord_t *record) {
                                   1960 ;	-----------------------------------------
                                   1961 	.area CSEG    (CODE)
                                   1962 	.area CONST   (CODE)
                                   1963 	.area XINIT   (CODE)
      00BFF2                       1964 __xinit__disable_action_cache:
      00BFF2 00                    1965 	.db #0x00	;  0
                                   1966 	.area CABS    (ABS,CODE)
                                   1967 
                                   1968 ; Experimental exact instruction outlining.
                                   1969 	.globl _ak820_outline_0001
                                   1970 	.globl _ak820_outline_0005
                                   1971 	.globl _ak820_outline_0007
                                   1972 	.globl _ak820_outline_0008
                                   1973 	.globl _ak820_outline_0010
                                   1974 	.globl _ak820_outline_0011
                                   1975 	.globl _ak820_outline_0012
                                   1976 	.globl _ak820_outline_0013
                                   1977 	.globl _ak820_outline_0016
                                   1978 	.globl _ak820_outline_0021
                                   1979 	.globl _ak820_outline_0022
                                   1980 	.globl _ak820_outline_0034
                                   1981 	.globl _ak820_outline_0036
                                   1982 	.globl _ak820_outline_0042
                                   1983 	.globl _ak820_outline_0050
                                   1984 	.globl _ak820_outline_0059
                                   1985 	.globl _ak820_outline_0063
                                   1986 	.globl _ak820_outline_0071
                                   1987 	.globl _ak820_outline_0072
                                   1988 	.globl _ak820_outline_0078
                                   1989 	.globl _ak820_outline_0080
                                   1990 	.globl _ak820_outline_0090
                                   1991 	.globl _ak820_outline_0094
                                   1992 	.globl _ak820_outline_0110
                                   1993 	.globl _ak820_outline_0112
                                   1994 	.globl _ak820_outline_0113
                                   1995 	.globl _ak820_outline_0118
                                   1996 	.globl _ak820_outline_0119
                                   1997 	.globl _ak820_outline_0120
                                   1998 	.globl _ak820_outline_0125
                                   1999 	.globl _ak820_outline_0126
                                   2000 	.globl _ak820_outline_0132
                                   2001 	.globl _ak820_outline_0135
                                   2002 	.globl _ak820_outline_0136
                                   2003 	.globl _ak820_outline_0144
                                   2004 	.globl _ak820_outline_0148
                                   2005 	.globl _ak820_outline_0151
                                   2006 	.globl _ak820_outline_0160
                                   2007 	.globl _ak820_outline_0162
                                   2008 	.globl _ak820_outline_0170
                                   2009 	.globl _ak820_outline_0171
                                   2010 	.globl _ak820_outline_0184
                                   2011 	.globl _ak820_outline_0189
                                   2012 
                                   2013 	.area CSEG (CODE)
                                   2014 ; function ak820_outline_0012
      0076AE                       2015 _ak820_outline_0012:
      0076AE 2D               [12] 2016 	add	a,r5
      0076AF F9               [12] 2017 	mov	r1,a
      0076B0 E4               [12] 2018 	clr	a
      0076B1 3E               [12] 2019 	addc	a,r6
      0076B2 FA               [12] 2020 	mov	r2,a
      0076B3 8F 03            [24] 2021 	mov	ar3,r7
      0076B5 89 82            [24] 2022 	mov	dpl,r1
      0076B7 8A 83            [24] 2023 	mov	dph,r2
      0076B9 8B F0            [24] 2024 	mov	b,r3
      0076BB 22               [24] 2025 	ret
                                   2026 
                                   2027 	.area CSEG (CODE)
                                   2028 ; function ak820_outline_0013
      0076BC                       2029 _ak820_outline_0013:
      0076BC 2D               [12] 2030 	add	a,r5
      0076BD FA               [12] 2031 	mov	r2,a
      0076BE E4               [12] 2032 	clr	a
      0076BF 3E               [12] 2033 	addc	a,r6
      0076C0 FB               [12] 2034 	mov	r3,a
      0076C1 8F 04            [24] 2035 	mov	ar4,r7
      0076C3 8A 82            [24] 2036 	mov	dpl,r2
      0076C5 8B 83            [24] 2037 	mov	dph,r3
      0076C7 8C F0            [24] 2038 	mov	b,r4
      0076C9 22               [24] 2039 	ret
                                   2040 
                                   2041 	.area CSEG (CODE)
                                   2042 ; function ak820_outline_0021
      0076CA                       2043 _ak820_outline_0021:
      0076CA 8E 82            [24] 2044 	mov	dpl,r6
      0076CC 8F 83            [24] 2045 	mov	dph,r7
      0076CE A3               [24] 2046 	inc	dptr
      0076CF E0               [24] 2047 	movx	a,@dptr
      0076D0 FC               [12] 2048 	mov	r4,a
      0076D1 7D 00            [12] 2049 	mov	r5,#0x00
      0076D3 8E 82            [24] 2050 	mov	dpl,r6
      0076D5 8F 83            [24] 2051 	mov	dph,r7
      0076D7 E0               [24] 2052 	movx	a,@dptr
      0076D8 22               [24] 2053 	ret
                                   2054 
                                   2055 	.area CSEG (CODE)
                                   2056 ; function ak820_outline_0042
      0076D9                       2057 _ak820_outline_0042:
      0076D9 90 08 37         [24] 2058 	mov	dptr,#(_process_action_PARM_2+0x0001)
      0076DC E0               [24] 2059 	movx	a,@dptr
      0076DD 54 1F            [12] 2060 	anl	a,#0x1f
      0076DF F5 82            [12] 2061 	mov	dpl,a
      0076E1 22               [24] 2062 	ret
                                   2063 
                                   2064 	.area CSEG (CODE)
                                   2065 ; function ak820_outline_0063
      0076E2                       2066 _ak820_outline_0063:
      0076E2 F5 F0            [12] 2067 	mov	b,a
      0076E4 05 F0            [12] 2068 	inc	b
      0076E6 74 01            [12] 2069 	mov	a,#0x01
      0076E8 22               [24] 2070 	ret
                                   2071 
                                   2072 	.area CSEG (CODE)
                                   2073 ; function ak820_outline_0071
      0076E9                       2074 _ak820_outline_0071:
      0076E9 90 0D A2         [24] 2075 	mov	dptr,#___memcpy_PARM_3
      0076EC 74 06            [12] 2076 	mov	a,#0x06
      0076EE F0               [24] 2077 	movx	@dptr,a
      0076EF E4               [12] 2078 	clr	a
      0076F0 A3               [24] 2079 	inc	dptr
      0076F1 F0               [24] 2080 	movx	@dptr,a
      0076F2 22               [24] 2081 	ret
                                   2082 
                                   2083 	.area CSEG (CODE)
                                   2084 ; function ak820_outline_0078
      0076F3                       2085 _ak820_outline_0078:
      0076F3 90 08 36         [24] 2086 	mov	dptr,#_process_action_PARM_2
      0076F6 E0               [24] 2087 	movx	a,@dptr
      0076F7 F5 82            [12] 2088 	mov	dpl,a
      0076F9 22               [24] 2089 	ret
                                   2090 
                                   2091 	.area CSEG (CODE)
                                   2092 ; function ak820_outline_0090
      0076FA                       2093 _ak820_outline_0090:
      0076FA 90 08 37         [24] 2094 	mov	dptr,#(_process_action_PARM_2+0x0001)
      0076FD E0               [24] 2095 	movx	a,@dptr
      0076FE 03               [12] 2096 	rr	a
      0076FF 03               [12] 2097 	rr	a
      007700 54 03            [12] 2098 	anl	a,#0x03
      007702 22               [24] 2099 	ret
                                   2100 
                                   2101 	.area CSEG (CODE)
                                   2102 ; function ak820_outline_0113
      007703                       2103 _ak820_outline_0113:
      007703 90 08 37         [24] 2104 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007706 E0               [24] 2105 	movx	a,@dptr
      007707 54 0F            [12] 2106 	anl	a,#0x0f
      007709 22               [24] 2107 	ret
                                   2108 
                                   2109 	.area CSEG (CODE)
                                   2110 ; function ak820_outline_0132
      00770A                       2111 _ak820_outline_0132:
      00770A 90 08 36         [24] 2112 	mov	dptr,#_process_action_PARM_2
      00770D E0               [24] 2113 	movx	a,@dptr
      00770E FE               [12] 2114 	mov	r6,a
      00770F A3               [24] 2115 	inc	dptr
      007710 E0               [24] 2116 	movx	a,@dptr
      007711 54 03            [12] 2117 	anl	a,#0x03
      007713 FF               [12] 2118 	mov	r7,a
      007714 22               [24] 2119 	ret
                                   2120 
                                   2121 	.area CSEG (CODE)
                                   2122 ; function ak820_outline_0148
      007715                       2123 _ak820_outline_0148:
      007715 74 07            [12] 2124 	mov	a,#0x07
      007717 2D               [12] 2125 	add	a,r5
      007718 F8               [12] 2126 	mov	r0,a
      007719 E4               [12] 2127 	clr	a
      00771A 3E               [12] 2128 	addc	a,r6
      00771B F9               [12] 2129 	mov	r1,a
      00771C 8F 02            [24] 2130 	mov	ar2,r7
      00771E 22               [24] 2131 	ret
                                   2132 
                                   2133 	.area CSEG (CODE)
                                   2134 ; function ak820_outline_0162
      00771F                       2135 _ak820_outline_0162:
      00771F 90 08 36         [24] 2136 	mov	dptr,#_process_action_PARM_2
      007722 E0               [24] 2137 	movx	a,@dptr
      007723 22               [24] 2138 	ret
                                   2139 
                                   2140 	.area CSEG (CODE)
                                   2141 ; function ak820_outline_0170
      007724                       2142 _ak820_outline_0170:
      007724 90 08 3C         [24] 2143 	mov	dptr,#_register_code_code_10000_709
      007727 E0               [24] 2144 	movx	a,@dptr
      007728 FF               [12] 2145 	mov	r7,a
      007729 22               [24] 2146 	ret
                                   2147 
                                   2148 	.area CSEG (CODE)
                                   2149 ; function ak820_outline_0171
      00772A                       2150 _ak820_outline_0171:
      00772A 90 08 3D         [24] 2151 	mov	dptr,#_unregister_code_code_10000_723
      00772D E0               [24] 2152 	movx	a,@dptr
      00772E FF               [12] 2153 	mov	r7,a
      00772F 22               [24] 2154 	ret
                                   2155 
                                   2156 	.area CSEG (CODE)
                                   2157 ; function ak820_outline_0189
      007730                       2158 _ak820_outline_0189:
      007730 F0               [24] 2159 	movx	@dptr,a
      007731 EB               [12] 2160 	mov	a,r3
      007732 A3               [24] 2161 	inc	dptr
      007733 F0               [24] 2162 	movx	@dptr,a
      007734 22               [24] 2163 	ret
