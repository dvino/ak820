                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module via
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _raw_hid_receive_kb
                                     12 	.globl _vialrgb_save
                                     13 	.globl _vialrgb_set_value
                                     14 	.globl _vialrgb_get_value
                                     15 	.globl _ak820_nvm_schema_fault
                                     16 	.globl _raw_hid_send
                                     17 	.globl _dynamic_keymap_macro_send
                                     18 	.globl _dynamic_keymap_macro_reset
                                     19 	.globl _dynamic_keymap_macro_set_buffer
                                     20 	.globl _dynamic_keymap_macro_get_buffer
                                     21 	.globl _dynamic_keymap_macro_get_buffer_size
                                     22 	.globl _dynamic_keymap_macro_get_count
                                     23 	.globl _dynamic_keymap_set_buffer
                                     24 	.globl _dynamic_keymap_get_buffer
                                     25 	.globl _dynamic_keymap_reset
                                     26 	.globl _dynamic_keymap_set_keycode
                                     27 	.globl _dynamic_keymap_get_keycode
                                     28 	.globl _dynamic_keymap_get_layer_count
                                     29 	.globl _vial_handle_cmd
                                     30 	.globl _eeprom_update_byte
                                     31 	.globl _eeprom_read_byte
                                     32 	.globl _bootloader_jump
                                     33 	.globl _timer_read32
                                     34 	.globl _matrix_get_row
                                     35 	.globl _mDelaymS
                                     36 	.globl _ADC_START
                                     37 	.globl _S0_R_FIFO
                                     38 	.globl _S0_T_FIFO
                                     39 	.globl _S0_FREE
                                     40 	.globl _S0_IF_BYTE
                                     41 	.globl _S0_IF_FIRST
                                     42 	.globl _S0_IF_OV
                                     43 	.globl _S0_FST_ACT
                                     44 	.globl _CP_RL2
                                     45 	.globl _C_T2
                                     46 	.globl _TR2
                                     47 	.globl _EXEN2
                                     48 	.globl _TCLK
                                     49 	.globl _RCLK
                                     50 	.globl _EXF2
                                     51 	.globl _CAP1F
                                     52 	.globl _TF2
                                     53 	.globl _RI
                                     54 	.globl _TI
                                     55 	.globl _RB8
                                     56 	.globl _TB8
                                     57 	.globl _REN
                                     58 	.globl _SM2
                                     59 	.globl _SM1
                                     60 	.globl _SM0
                                     61 	.globl _IT0
                                     62 	.globl _IE0
                                     63 	.globl _IT1
                                     64 	.globl _IE1
                                     65 	.globl _TR0
                                     66 	.globl _TF0
                                     67 	.globl _TR1
                                     68 	.globl _TF1
                                     69 	.globl _P4_0
                                     70 	.globl _P4_1
                                     71 	.globl _P4_2
                                     72 	.globl _P4_3
                                     73 	.globl _P4_4
                                     74 	.globl _P4_5
                                     75 	.globl _P4_6
                                     76 	.globl _RXD
                                     77 	.globl _TXD
                                     78 	.globl _INT0
                                     79 	.globl _INT1
                                     80 	.globl _T0
                                     81 	.globl _T1
                                     82 	.globl _MOSI1
                                     83 	.globl _MISO1
                                     84 	.globl _SCK1
                                     85 	.globl _P3_0
                                     86 	.globl _P3_1
                                     87 	.globl _P3_2
                                     88 	.globl _P3_3
                                     89 	.globl _P3_4
                                     90 	.globl _P3_5
                                     91 	.globl _P3_6
                                     92 	.globl _P3_7
                                     93 	.globl _CAP1_
                                     94 	.globl _T2_
                                     95 	.globl _CAP2_
                                     96 	.globl _T2EX_
                                     97 	.globl _RXD1
                                     98 	.globl _TXD1
                                     99 	.globl _P2_0
                                    100 	.globl _P2_1
                                    101 	.globl _P2_2
                                    102 	.globl _P2_3
                                    103 	.globl _P2_4
                                    104 	.globl _P2_5
                                    105 	.globl _P2_6
                                    106 	.globl _P2_7
                                    107 	.globl _AIN0
                                    108 	.globl _AIN1
                                    109 	.globl _AIN2
                                    110 	.globl _AIN3
                                    111 	.globl _AIN4
                                    112 	.globl _AIN5
                                    113 	.globl _AIN6
                                    114 	.globl _AIN7
                                    115 	.globl _CAP1
                                    116 	.globl _T2
                                    117 	.globl _CAP2
                                    118 	.globl _T2EX
                                    119 	.globl _INT0_
                                    120 	.globl _SCS
                                    121 	.globl _MOSI
                                    122 	.globl _MISO
                                    123 	.globl _SCK
                                    124 	.globl _RXD1_
                                    125 	.globl _TXD1_
                                    126 	.globl _P1_0
                                    127 	.globl _P1_1
                                    128 	.globl _P1_2
                                    129 	.globl _P1_3
                                    130 	.globl _P1_4
                                    131 	.globl _P1_5
                                    132 	.globl _P1_6
                                    133 	.globl _P1_7
                                    134 	.globl _AIN8
                                    135 	.globl _AIN9
                                    136 	.globl _AIN10
                                    137 	.globl _AIN11
                                    138 	.globl _AIN12
                                    139 	.globl _AIN13
                                    140 	.globl _RXD_
                                    141 	.globl _TXD_
                                    142 	.globl _SCL0
                                    143 	.globl _SDA0
                                    144 	.globl _P0_0
                                    145 	.globl _P0_1
                                    146 	.globl _P0_2
                                    147 	.globl _P0_3
                                    148 	.globl _P0_4
                                    149 	.globl _P0_5
                                    150 	.globl _P0_6
                                    151 	.globl _P0_7
                                    152 	.globl _IE_SPI0
                                    153 	.globl _IE_USB
                                    154 	.globl _IE_ADC
                                    155 	.globl _IE_UART1
                                    156 	.globl _IE_PWM_I2C
                                    157 	.globl _IE_GPIO
                                    158 	.globl _IE_WDOG
                                    159 	.globl _PX0
                                    160 	.globl _PT0
                                    161 	.globl _PX1
                                    162 	.globl _PT1
                                    163 	.globl _PS
                                    164 	.globl _PT2
                                    165 	.globl _PL_FLAG
                                    166 	.globl _PH_FLAG
                                    167 	.globl _EX0
                                    168 	.globl _ET0
                                    169 	.globl _EX1
                                    170 	.globl _ET1
                                    171 	.globl _ES
                                    172 	.globl _ET2
                                    173 	.globl _E_DIS
                                    174 	.globl _EA
                                    175 	.globl _P
                                    176 	.globl _F1
                                    177 	.globl _OV
                                    178 	.globl _RS0
                                    179 	.globl _RS1
                                    180 	.globl _F0
                                    181 	.globl _AC
                                    182 	.globl _CY
                                    183 	.globl _I2CS_INT_ST
                                    184 	.globl _I2CX_INT
                                    185 	.globl _LED_STATUS
                                    186 	.globl _LED_DMA_H
                                    187 	.globl _LED_DMA_L
                                    188 	.globl _LED_DMA
                                    189 	.globl _LED_PWM_OE
                                    190 	.globl _LED_COMMON
                                    191 	.globl _ADC_CHAN
                                    192 	.globl _ADC_DAT_H
                                    193 	.globl _ADC_DAT_L
                                    194 	.globl _ADC_DAT
                                    195 	.globl _ADC_CTRL
                                    196 	.globl _SPI1_CK_SE
                                    197 	.globl _SPI1_CTRL
                                    198 	.globl _SPI1_DATA
                                    199 	.globl _SPI1_STAT
                                    200 	.globl _SIF1
                                    201 	.globl _SBAUD1
                                    202 	.globl _SBUF1
                                    203 	.globl _SCON1
                                    204 	.globl _SPI0_SETUP
                                    205 	.globl _SPI0_CK_SE
                                    206 	.globl _SPI0_CTRL
                                    207 	.globl _SPI0_DATA
                                    208 	.globl _SPI0_STAT
                                    209 	.globl _T2CAP1H
                                    210 	.globl _T2CAP1L
                                    211 	.globl _T2CAP1
                                    212 	.globl _TH2
                                    213 	.globl _TL2
                                    214 	.globl _T2COUNT
                                    215 	.globl _RCAP2H
                                    216 	.globl _RCAP2L
                                    217 	.globl _RCAP2
                                    218 	.globl _T2MOD
                                    219 	.globl _T2CON
                                    220 	.globl _SBUF
                                    221 	.globl _SCON
                                    222 	.globl _TH1
                                    223 	.globl _TH0
                                    224 	.globl _TL1
                                    225 	.globl _TL0
                                    226 	.globl _TMOD
                                    227 	.globl _TCON
                                    228 	.globl _XBUS_AUX
                                    229 	.globl _P7
                                    230 	.globl _P6_DIR
                                    231 	.globl _P6_OUT_PU
                                    232 	.globl _P6_IN
                                    233 	.globl _P5_DIR
                                    234 	.globl _P5_OUT_PU
                                    235 	.globl _P5_IN
                                    236 	.globl _P4_LED_KEY
                                    237 	.globl _P4_DIR_PU
                                    238 	.globl _P4_MOD_OC
                                    239 	.globl _P4
                                    240 	.globl _P3_DIR_PU
                                    241 	.globl _P3_MOD_OC
                                    242 	.globl _P3
                                    243 	.globl _P2_DIR_PU
                                    244 	.globl _P2_MOD_OC
                                    245 	.globl _P2
                                    246 	.globl _P1_DIR_PU
                                    247 	.globl _P1_MOD_OC
                                    248 	.globl _P1
                                    249 	.globl _P0_DIR_PU
                                    250 	.globl _P0_MOD_OC
                                    251 	.globl _P0
                                    252 	.globl _ROM_CTRL
                                    253 	.globl _ROM_DATA_HH
                                    254 	.globl _ROM_DATA_HL
                                    255 	.globl _ROM_DATA_HI
                                    256 	.globl _ROM_ADDR_H
                                    257 	.globl _ROM_ADDR_L
                                    258 	.globl _ROM_ADDR
                                    259 	.globl _GPIO_IE
                                    260 	.globl _IP_EX
                                    261 	.globl _IE_EX
                                    262 	.globl _IP
                                    263 	.globl _IE
                                    264 	.globl _WDOG_COUNT
                                    265 	.globl _RESET_KEEP
                                    266 	.globl _WAKE_CTRL
                                    267 	.globl _CLOCK_CFG
                                    268 	.globl _POWER_CFG
                                    269 	.globl _PCON
                                    270 	.globl _GLOBAL_CFG
                                    271 	.globl _SAFE_MOD
                                    272 	.globl _DPH
                                    273 	.globl _DPL
                                    274 	.globl _SP
                                    275 	.globl _A_INV
                                    276 	.globl _B
                                    277 	.globl _ACC
                                    278 	.globl _PSW
                                    279 	.globl _raw_hid_receive_PARM_2
                                    280 	.globl _raw_hid_receive_kb_PARM_2
                                    281 	.globl _process_record_via_PARM_2
                                    282 	.globl _via_eeprom_is_valid
                                    283 	.globl _via_eeprom_set_valid
                                    284 	.globl _via_init
                                    285 	.globl _eeconfig_init_via
                                    286 	.globl _via_get_layout_options
                                    287 	.globl _via_set_layout_options_kb
                                    288 	.globl _via_set_layout_options
                                    289 	.globl _process_record_via
                                    290 	.globl _raw_hid_receive
                                    291 ;--------------------------------------------------------
                                    292 ; special function registers
                                    293 ;--------------------------------------------------------
                                    294 	.area RSEG    (ABS,DATA)
      000000                        295 	.org 0x0000
                           0000D0   296 _PSW	=	0x00d0
                           0000E0   297 _ACC	=	0x00e0
                           0000F0   298 _B	=	0x00f0
                           0000FD   299 _A_INV	=	0x00fd
                           000081   300 _SP	=	0x0081
                           000082   301 _DPL	=	0x0082
                           000083   302 _DPH	=	0x0083
                           0000A1   303 _SAFE_MOD	=	0x00a1
                           0000B1   304 _GLOBAL_CFG	=	0x00b1
                           000087   305 _PCON	=	0x0087
                           0000BA   306 _POWER_CFG	=	0x00ba
                           0000B9   307 _CLOCK_CFG	=	0x00b9
                           0000A9   308 _WAKE_CTRL	=	0x00a9
                           0000FE   309 _RESET_KEEP	=	0x00fe
                           0000FF   310 _WDOG_COUNT	=	0x00ff
                           0000A8   311 _IE	=	0x00a8
                           0000B8   312 _IP	=	0x00b8
                           0000E8   313 _IE_EX	=	0x00e8
                           0000E9   314 _IP_EX	=	0x00e9
                           0000B2   315 _GPIO_IE	=	0x00b2
                           008584   316 _ROM_ADDR	=	0x8584
                           000084   317 _ROM_ADDR_L	=	0x0084
                           000085   318 _ROM_ADDR_H	=	0x0085
                           008F8E   319 _ROM_DATA_HI	=	0x8f8e
                           00008E   320 _ROM_DATA_HL	=	0x008e
                           00008F   321 _ROM_DATA_HH	=	0x008f
                           000086   322 _ROM_CTRL	=	0x0086
                           000080   323 _P0	=	0x0080
                           0000C4   324 _P0_MOD_OC	=	0x00c4
                           0000C5   325 _P0_DIR_PU	=	0x00c5
                           000090   326 _P1	=	0x0090
                           000092   327 _P1_MOD_OC	=	0x0092
                           000093   328 _P1_DIR_PU	=	0x0093
                           0000A0   329 _P2	=	0x00a0
                           000094   330 _P2_MOD_OC	=	0x0094
                           000095   331 _P2_DIR_PU	=	0x0095
                           0000B0   332 _P3	=	0x00b0
                           000096   333 _P3_MOD_OC	=	0x0096
                           000097   334 _P3_DIR_PU	=	0x0097
                           0000C0   335 _P4	=	0x00c0
                           0000C2   336 _P4_MOD_OC	=	0x00c2
                           0000C3   337 _P4_DIR_PU	=	0x00c3
                           0000C1   338 _P4_LED_KEY	=	0x00c1
                           0000AA   339 _P5_IN	=	0x00aa
                           0000AB   340 _P5_OUT_PU	=	0x00ab
                           0000AC   341 _P5_DIR	=	0x00ac
                           0000AD   342 _P6_IN	=	0x00ad
                           0000AE   343 _P6_OUT_PU	=	0x00ae
                           0000AF   344 _P6_DIR	=	0x00af
                           0000F1   345 _P7	=	0x00f1
                           0000A2   346 _XBUS_AUX	=	0x00a2
                           000088   347 _TCON	=	0x0088
                           000089   348 _TMOD	=	0x0089
                           00008A   349 _TL0	=	0x008a
                           00008B   350 _TL1	=	0x008b
                           00008C   351 _TH0	=	0x008c
                           00008D   352 _TH1	=	0x008d
                           000098   353 _SCON	=	0x0098
                           000099   354 _SBUF	=	0x0099
                           0000C8   355 _T2CON	=	0x00c8
                           0000C9   356 _T2MOD	=	0x00c9
                           00CBCA   357 _RCAP2	=	0xcbca
                           0000CA   358 _RCAP2L	=	0x00ca
                           0000CB   359 _RCAP2H	=	0x00cb
                           00CDCC   360 _T2COUNT	=	0xcdcc
                           0000CC   361 _TL2	=	0x00cc
                           0000CD   362 _TH2	=	0x00cd
                           00CFCE   363 _T2CAP1	=	0xcfce
                           0000CE   364 _T2CAP1L	=	0x00ce
                           0000CF   365 _T2CAP1H	=	0x00cf
                           0000F8   366 _SPI0_STAT	=	0x00f8
                           0000F9   367 _SPI0_DATA	=	0x00f9
                           0000FA   368 _SPI0_CTRL	=	0x00fa
                           0000FB   369 _SPI0_CK_SE	=	0x00fb
                           0000FC   370 _SPI0_SETUP	=	0x00fc
                           0000BC   371 _SCON1	=	0x00bc
                           0000BD   372 _SBUF1	=	0x00bd
                           0000BE   373 _SBAUD1	=	0x00be
                           0000BF   374 _SIF1	=	0x00bf
                           0000B4   375 _SPI1_STAT	=	0x00b4
                           0000B5   376 _SPI1_DATA	=	0x00b5
                           0000B6   377 _SPI1_CTRL	=	0x00b6
                           0000B7   378 _SPI1_CK_SE	=	0x00b7
                           0000F3   379 _ADC_CTRL	=	0x00f3
                           00F5F4   380 _ADC_DAT	=	0xf5f4
                           0000F4   381 _ADC_DAT_L	=	0x00f4
                           0000F5   382 _ADC_DAT_H	=	0x00f5
                           0000F6   383 _ADC_CHAN	=	0x00f6
                           0000A6   384 _LED_COMMON	=	0x00a6
                           0000A7   385 _LED_PWM_OE	=	0x00a7
                           00C7C6   386 _LED_DMA	=	0xc7c6
                           0000C6   387 _LED_DMA_L	=	0x00c6
                           0000C7   388 _LED_DMA_H	=	0x00c7
                           0000F7   389 _LED_STATUS	=	0x00f7
                           0000B3   390 _I2CX_INT	=	0x00b3
                           0000BB   391 _I2CS_INT_ST	=	0x00bb
                                    392 ;--------------------------------------------------------
                                    393 ; special function bits
                                    394 ;--------------------------------------------------------
                                    395 	.area RSEG    (ABS,DATA)
      000000                        396 	.org 0x0000
                           0000D7   397 _CY	=	0x00d7
                           0000D6   398 _AC	=	0x00d6
                           0000D5   399 _F0	=	0x00d5
                           0000D4   400 _RS1	=	0x00d4
                           0000D3   401 _RS0	=	0x00d3
                           0000D2   402 _OV	=	0x00d2
                           0000D1   403 _F1	=	0x00d1
                           0000D0   404 _P	=	0x00d0
                           0000AF   405 _EA	=	0x00af
                           0000AE   406 _E_DIS	=	0x00ae
                           0000AD   407 _ET2	=	0x00ad
                           0000AC   408 _ES	=	0x00ac
                           0000AB   409 _ET1	=	0x00ab
                           0000AA   410 _EX1	=	0x00aa
                           0000A9   411 _ET0	=	0x00a9
                           0000A8   412 _EX0	=	0x00a8
                           0000BF   413 _PH_FLAG	=	0x00bf
                           0000BE   414 _PL_FLAG	=	0x00be
                           0000BD   415 _PT2	=	0x00bd
                           0000BC   416 _PS	=	0x00bc
                           0000BB   417 _PT1	=	0x00bb
                           0000BA   418 _PX1	=	0x00ba
                           0000B9   419 _PT0	=	0x00b9
                           0000B8   420 _PX0	=	0x00b8
                           0000EF   421 _IE_WDOG	=	0x00ef
                           0000EE   422 _IE_GPIO	=	0x00ee
                           0000ED   423 _IE_PWM_I2C	=	0x00ed
                           0000EC   424 _IE_UART1	=	0x00ec
                           0000EB   425 _IE_ADC	=	0x00eb
                           0000E9   426 _IE_USB	=	0x00e9
                           0000E8   427 _IE_SPI0	=	0x00e8
                           000087   428 _P0_7	=	0x0087
                           000086   429 _P0_6	=	0x0086
                           000085   430 _P0_5	=	0x0085
                           000084   431 _P0_4	=	0x0084
                           000083   432 _P0_3	=	0x0083
                           000082   433 _P0_2	=	0x0082
                           000081   434 _P0_1	=	0x0081
                           000080   435 _P0_0	=	0x0080
                           000081   436 _SDA0	=	0x0081
                           000080   437 _SCL0	=	0x0080
                           000083   438 _TXD_	=	0x0083
                           000082   439 _RXD_	=	0x0082
                           000085   440 _AIN13	=	0x0085
                           000084   441 _AIN12	=	0x0084
                           000083   442 _AIN11	=	0x0083
                           000082   443 _AIN10	=	0x0082
                           000081   444 _AIN9	=	0x0081
                           000080   445 _AIN8	=	0x0080
                           000097   446 _P1_7	=	0x0097
                           000096   447 _P1_6	=	0x0096
                           000095   448 _P1_5	=	0x0095
                           000094   449 _P1_4	=	0x0094
                           000093   450 _P1_3	=	0x0093
                           000092   451 _P1_2	=	0x0092
                           000091   452 _P1_1	=	0x0091
                           000090   453 _P1_0	=	0x0090
                           000097   454 _TXD1_	=	0x0097
                           000096   455 _RXD1_	=	0x0096
                           000097   456 _SCK	=	0x0097
                           000096   457 _MISO	=	0x0096
                           000095   458 _MOSI	=	0x0095
                           000094   459 _SCS	=	0x0094
                           000092   460 _INT0_	=	0x0092
                           000091   461 _T2EX	=	0x0091
                           000091   462 _CAP2	=	0x0091
                           000090   463 _T2	=	0x0090
                           000090   464 _CAP1	=	0x0090
                           000097   465 _AIN7	=	0x0097
                           000096   466 _AIN6	=	0x0096
                           000095   467 _AIN5	=	0x0095
                           000094   468 _AIN4	=	0x0094
                           000093   469 _AIN3	=	0x0093
                           000092   470 _AIN2	=	0x0092
                           000091   471 _AIN1	=	0x0091
                           000090   472 _AIN0	=	0x0090
                           0000A7   473 _P2_7	=	0x00a7
                           0000A6   474 _P2_6	=	0x00a6
                           0000A5   475 _P2_5	=	0x00a5
                           0000A4   476 _P2_4	=	0x00a4
                           0000A3   477 _P2_3	=	0x00a3
                           0000A2   478 _P2_2	=	0x00a2
                           0000A1   479 _P2_1	=	0x00a1
                           0000A0   480 _P2_0	=	0x00a0
                           0000A7   481 _TXD1	=	0x00a7
                           0000A6   482 _RXD1	=	0x00a6
                           0000A5   483 _T2EX_	=	0x00a5
                           0000A5   484 _CAP2_	=	0x00a5
                           0000A4   485 _T2_	=	0x00a4
                           0000A4   486 _CAP1_	=	0x00a4
                           0000B7   487 _P3_7	=	0x00b7
                           0000B6   488 _P3_6	=	0x00b6
                           0000B5   489 _P3_5	=	0x00b5
                           0000B4   490 _P3_4	=	0x00b4
                           0000B3   491 _P3_3	=	0x00b3
                           0000B2   492 _P3_2	=	0x00b2
                           0000B1   493 _P3_1	=	0x00b1
                           0000B0   494 _P3_0	=	0x00b0
                           0000B7   495 _SCK1	=	0x00b7
                           0000B6   496 _MISO1	=	0x00b6
                           0000B5   497 _MOSI1	=	0x00b5
                           0000B5   498 _T1	=	0x00b5
                           0000B4   499 _T0	=	0x00b4
                           0000B3   500 _INT1	=	0x00b3
                           0000B2   501 _INT0	=	0x00b2
                           0000B1   502 _TXD	=	0x00b1
                           0000B0   503 _RXD	=	0x00b0
                           0000C6   504 _P4_6	=	0x00c6
                           0000C5   505 _P4_5	=	0x00c5
                           0000C4   506 _P4_4	=	0x00c4
                           0000C3   507 _P4_3	=	0x00c3
                           0000C2   508 _P4_2	=	0x00c2
                           0000C1   509 _P4_1	=	0x00c1
                           0000C0   510 _P4_0	=	0x00c0
                           00008F   511 _TF1	=	0x008f
                           00008E   512 _TR1	=	0x008e
                           00008D   513 _TF0	=	0x008d
                           00008C   514 _TR0	=	0x008c
                           00008B   515 _IE1	=	0x008b
                           00008A   516 _IT1	=	0x008a
                           000089   517 _IE0	=	0x0089
                           000088   518 _IT0	=	0x0088
                           00009F   519 _SM0	=	0x009f
                           00009E   520 _SM1	=	0x009e
                           00009D   521 _SM2	=	0x009d
                           00009C   522 _REN	=	0x009c
                           00009B   523 _TB8	=	0x009b
                           00009A   524 _RB8	=	0x009a
                           000099   525 _TI	=	0x0099
                           000098   526 _RI	=	0x0098
                           0000CF   527 _TF2	=	0x00cf
                           0000CF   528 _CAP1F	=	0x00cf
                           0000CE   529 _EXF2	=	0x00ce
                           0000CD   530 _RCLK	=	0x00cd
                           0000CC   531 _TCLK	=	0x00cc
                           0000CB   532 _EXEN2	=	0x00cb
                           0000CA   533 _TR2	=	0x00ca
                           0000C9   534 _C_T2	=	0x00c9
                           0000C8   535 _CP_RL2	=	0x00c8
                           0000FF   536 _S0_FST_ACT	=	0x00ff
                           0000FE   537 _S0_IF_OV	=	0x00fe
                           0000FD   538 _S0_IF_FIRST	=	0x00fd
                           0000FC   539 _S0_IF_BYTE	=	0x00fc
                           0000FB   540 _S0_FREE	=	0x00fb
                           0000FA   541 _S0_T_FIFO	=	0x00fa
                           0000F8   542 _S0_R_FIFO	=	0x00f8
                           0000F7   543 _ADC_START	=	0x00f7
                                    544 ;--------------------------------------------------------
                                    545 ; overlayable register banks
                                    546 ;--------------------------------------------------------
                                    547 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        548 	.ds 8
                                    549 ;--------------------------------------------------------
                                    550 ; internal ram data
                                    551 ;--------------------------------------------------------
                                    552 	.area DSEG    (DATA)
      000038                        553 _raw_hid_receive_sloc0_1_0:
      000038                        554 	.ds 4
      00003C                        555 _raw_hid_receive_sloc1_1_0:
      00003C                        556 	.ds 1
      00003D                        557 _raw_hid_receive_sloc2_1_0:
      00003D                        558 	.ds 1
      00003E                        559 _raw_hid_receive_sloc3_1_0:
      00003E                        560 	.ds 2
      000040                        561 _raw_hid_receive_sloc4_1_0:
      000040                        562 	.ds 2
                                    563 ;--------------------------------------------------------
                                    564 ; overlayable items in internal ram
                                    565 ;--------------------------------------------------------
                                    566 ;--------------------------------------------------------
                                    567 ; indirectly addressable internal ram data
                                    568 ;--------------------------------------------------------
                                    569 	.area ISEG    (DATA)
                                    570 ;--------------------------------------------------------
                                    571 ; absolute internal ram data
                                    572 ;--------------------------------------------------------
                                    573 	.area IABS    (ABS,DATA)
                                    574 	.area IABS    (ABS,DATA)
                                    575 ;--------------------------------------------------------
                                    576 ; bit data
                                    577 ;--------------------------------------------------------
                                    578 	.area BSEG    (BIT)
      000028                        579 _via_eeprom_is_valid_sloc0_1_0:
      000028                        580 	.ds 1
                                    581 ;--------------------------------------------------------
                                    582 ; paged external ram data
                                    583 ;--------------------------------------------------------
                                    584 	.area PSEG    (PAG,XDATA)
                                    585 ;--------------------------------------------------------
                                    586 ; uninitialized external ram data
                                    587 ;--------------------------------------------------------
                                    588 	.area XSEG    (XDATA)
      000C43                        589 _via_eeprom_set_valid_valid_10000_609:
      000C43                        590 	.ds 1
      000C44                        591 _via_set_layout_options_value_10000_625:
      000C44                        592 	.ds 4
      000C48                        593 _process_record_via_PARM_2:
      000C48                        594 	.ds 3
      000C4B                        595 _process_record_via_keycode_10000_627:
      000C4B                        596 	.ds 2
      000C4D                        597 _raw_hid_receive_kb_PARM_2:
      000C4D                        598 	.ds 1
      000C4E                        599 _raw_hid_receive_kb_data_10000_633:
      000C4E                        600 	.ds 3
      000C51                        601 _raw_hid_receive_PARM_2:
      000C51                        602 	.ds 1
      000C52                        603 _raw_hid_receive_packet_10000_635:
      000C52                        604 	.ds 3
                                    605 ;--------------------------------------------------------
                                    606 ; absolute external ram data
                                    607 ;--------------------------------------------------------
                                    608 	.area XABS    (ABS,XDATA)
                                    609 ;--------------------------------------------------------
                                    610 ; initialized external ram data
                                    611 ;--------------------------------------------------------
                                    612 	.area XISEG   (XDATA)
                                    613 	.area HOME    (CODE)
                                    614 	.area GSINIT0 (CODE)
                                    615 	.area GSINIT1 (CODE)
                                    616 	.area GSINIT2 (CODE)
                                    617 	.area GSINIT3 (CODE)
                                    618 	.area GSINIT4 (CODE)
                                    619 	.area GSINIT5 (CODE)
                                    620 	.area GSINIT  (CODE)
                                    621 	.area GSFINAL (CODE)
                                    622 	.area CSEG    (CODE)
                                    623 ;--------------------------------------------------------
                                    624 ; global & static initialisations
                                    625 ;--------------------------------------------------------
                                    626 	.area HOME    (CODE)
                                    627 	.area GSINIT  (CODE)
                                    628 	.area GSFINAL (CODE)
                                    629 	.area GSINIT  (CODE)
                                    630 ;--------------------------------------------------------
                                    631 ; Home
                                    632 ;--------------------------------------------------------
                                    633 	.area HOME    (CODE)
                                    634 	.area HOME    (CODE)
                                    635 ;--------------------------------------------------------
                                    636 ; code
                                    637 ;--------------------------------------------------------
                                    638 	.area CSEG    (CODE)
                                    639 ;------------------------------------------------------------
                                    640 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    641 ;------------------------------------------------------------
                                    642 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_193'
                                    643 ;------------------------------------------------------------
                                    644 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    645 ;	-----------------------------------------
                           000007   646 	ar7 = 0x07
                           000006   647 	ar6 = 0x06
                           000005   648 	ar5 = 0x05
                           000004   649 	ar4 = 0x04
                           000003   650 	ar3 = 0x03
                           000002   651 	ar2 = 0x02
                           000001   652 	ar1 = 0x01
                           000000   653 	ar0 = 0x00
                                    654 ;	 function via_eeprom_is_valid
                                    655 ;	-----------------------------------------
      00A488                        656 _via_eeprom_is_valid:
                                    657 ;	quantum/via.c:103: return (eeprom_read_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 0) == magic0 && eeprom_read_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 1) == magic1 && eeprom_read_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 2) == magic2);
      00A488 90 00 25         [24]  658 	mov	dptr,#0x0025
      00A48B 75 F0 00         [24]  659 	mov	b, #0x00
      00A48E 12 40 74         [24]  660 	lcall	_eeprom_read_byte
      00A491 AF 82            [24]  661 	mov	r7, dpl
      00A493 BF 02 1E         [24]  662 	cjne	r7,#0x02,00103$
      00A496 90 00 26         [24]  663 	mov	dptr,#0x0026
      00A499 75 F0 00         [24]  664 	mov	b, #0x00
      00A49C 12 40 74         [24]  665 	lcall	_eeprom_read_byte
      00A49F AF 82            [24]  666 	mov	r7, dpl
      00A4A1 BF 20 10         [24]  667 	cjne	r7,#0x20,00103$
      00A4A4 90 00 27         [24]  668 	mov	dptr,#0x0027
      00A4A7 75 F0 00         [24]  669 	mov	b, #0x00
      00A4AA 12 40 74         [24]  670 	lcall	_eeprom_read_byte
      00A4AD AF 82            [24]  671 	mov	r7, dpl
      00A4AF BF 08 02         [24]  672 	cjne	r7,#0x08,00126$
      00A4B2 80 04            [24]  673 	sjmp	00104$
      00A4B4                        674 00126$:
      00A4B4                        675 00103$:
                                    676 ;	assignBit
      00A4B4 C2 28            [12]  677 	clr	_via_eeprom_is_valid_sloc0_1_0
      00A4B6 80 02            [24]  678 	sjmp	00105$
      00A4B8                        679 00104$:
                                    680 ;	assignBit
      00A4B8 D2 28            [12]  681 	setb	_via_eeprom_is_valid_sloc0_1_0
      00A4BA                        682 00105$:
      00A4BA A2 28            [12]  683 	mov	c,_via_eeprom_is_valid_sloc0_1_0
      00A4BC 12 38 B1         [24]  684 	lcall	_ak820_outline_0159
                                    685 ;	quantum/via.c:104: }
      00A4BF 22               [24]  686 	ret
                                    687 ;------------------------------------------------------------
                                    688 ;Allocation info for local variables in function 'via_eeprom_set_valid'
                                    689 ;------------------------------------------------------------
                                    690 ;valid         Allocated with name '_via_eeprom_set_valid_valid_10000_609'
                                    691 ;magic0        Allocated with name '_via_eeprom_set_valid_magic0_10000_610'
                                    692 ;magic1        Allocated with name '_via_eeprom_set_valid_magic1_10000_610'
                                    693 ;magic2        Allocated with name '_via_eeprom_set_valid_magic2_10000_610'
                                    694 ;------------------------------------------------------------
                                    695 ;	quantum/via.c:108: void via_eeprom_set_valid(__xdata bool valid) {
                                    696 ;	-----------------------------------------
                                    697 ;	 function via_eeprom_set_valid
                                    698 ;	-----------------------------------------
      00A4C0                        699 _via_eeprom_set_valid:
      00A4C0 E5 82            [12]  700 	mov	a,dpl
      00A4C2 90 0C 43         [24]  701 	mov	dptr,#_via_eeprom_set_valid_valid_10000_609
      00A4C5 F0               [24]  702 	movx	@dptr,a
                                    703 ;	quantum/via.c:120: eeprom_update_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 0, valid ? magic0 : 0xFF);
      00A4C6 E0               [24]  704 	movx	a,@dptr
      00A4C7 60 04            [24]  705 	jz	00103$
      00A4C9 7F 02            [12]  706 	mov	r7,#0x02
      00A4CB 80 02            [24]  707 	sjmp	00104$
      00A4CD                        708 00103$:
      00A4CD 7F FF            [12]  709 	mov	r7,#0xff
      00A4CF                        710 00104$:
      00A4CF 90 06 9B         [24]  711 	mov	dptr,#_eeprom_update_byte_PARM_2
      00A4D2 EF               [12]  712 	mov	a,r7
      00A4D3 F0               [24]  713 	movx	@dptr,a
      00A4D4 90 00 25         [24]  714 	mov	dptr,#0x0025
      00A4D7 75 F0 00         [24]  715 	mov	b, #0x00
      00A4DA 12 4D DD         [24]  716 	lcall	_eeprom_update_byte
                                    717 ;	quantum/via.c:121: eeprom_update_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 1, valid ? magic1 : 0xFF);
      00A4DD 90 0C 43         [24]  718 	mov	dptr,#_via_eeprom_set_valid_valid_10000_609
      00A4E0 E0               [24]  719 	movx	a,@dptr
      00A4E1 60 04            [24]  720 	jz	00105$
      00A4E3 7F 20            [12]  721 	mov	r7,#0x20
      00A4E5 80 02            [24]  722 	sjmp	00106$
      00A4E7                        723 00105$:
      00A4E7 7F FF            [12]  724 	mov	r7,#0xff
      00A4E9                        725 00106$:
      00A4E9 90 06 9B         [24]  726 	mov	dptr,#_eeprom_update_byte_PARM_2
      00A4EC EF               [12]  727 	mov	a,r7
      00A4ED F0               [24]  728 	movx	@dptr,a
      00A4EE 90 00 26         [24]  729 	mov	dptr,#0x0026
      00A4F1 75 F0 00         [24]  730 	mov	b, #0x00
      00A4F4 12 4D DD         [24]  731 	lcall	_eeprom_update_byte
                                    732 ;	quantum/via.c:122: eeprom_update_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 2, valid ? magic2 : 0xFF);
      00A4F7 90 0C 43         [24]  733 	mov	dptr,#_via_eeprom_set_valid_valid_10000_609
      00A4FA E0               [24]  734 	movx	a,@dptr
      00A4FB 60 04            [24]  735 	jz	00107$
      00A4FD 7F 08            [12]  736 	mov	r7,#0x08
      00A4FF 80 02            [24]  737 	sjmp	00108$
      00A501                        738 00107$:
      00A501 7F FF            [12]  739 	mov	r7,#0xff
      00A503                        740 00108$:
      00A503 90 06 9B         [24]  741 	mov	dptr,#_eeprom_update_byte_PARM_2
      00A506 EF               [12]  742 	mov	a,r7
      00A507 F0               [24]  743 	movx	@dptr,a
      00A508 90 00 27         [24]  744 	mov	dptr,#0x0027
      00A50B 75 F0 00         [24]  745 	mov	b, #0x00
                                    746 ;	quantum/via.c:123: }
      00A50E 02 4D DD         [24]  747 	ljmp	_eeprom_update_byte
                                    748 ;------------------------------------------------------------
                                    749 ;Allocation info for local variables in function 'via_init_kb'
                                    750 ;------------------------------------------------------------
                                    751 ;	quantum/via.c:131: __attribute__((weak)) void via_init_kb(void) {}
                                    752 ;	-----------------------------------------
                                    753 ;	 function via_init
                                    754 ;	-----------------------------------------
      00A511                        755 _via_init:
                                    756 ;	quantum/via.c:138: via_set_layout_options_kb(via_get_layout_options());
      00A511 12 A5 3A         [24]  757 	lcall	_via_get_layout_options
      00A514 12 A5 52         [24]  758 	lcall	_via_set_layout_options_kb
                                    759 ;	quantum/via.c:142: if (!via_eeprom_is_valid()) {
      00A517 12 A4 88         [24]  760 	lcall	_via_eeprom_is_valid
      00A51A E5 82            [12]  761 	mov	a, dpl
      00A51C 70 03            [24]  762 	jnz	00103$
                                    763 ;	quantum/via.c:147: ak820_nvm_schema_fault();
                                    764 ;	quantum/via.c:152: }
      00A51E 02 3E 23         [24]  765 	ljmp	_ak820_nvm_schema_fault
      00A521                        766 00103$:
      00A521 22               [24]  767 	ret
                                    768 ;------------------------------------------------------------
                                    769 ;Allocation info for local variables in function 'eeconfig_init_via'
                                    770 ;------------------------------------------------------------
                                    771 ;	quantum/via.c:154: void eeconfig_init_via(void) {
                                    772 ;	-----------------------------------------
                                    773 ;	 function eeconfig_init_via
                                    774 ;	-----------------------------------------
      00A522                        775 _eeconfig_init_via:
                                    776 ;	quantum/via.c:156: via_eeprom_set_valid(false);
      00A522 75 82 00         [24]  777 	mov	dpl, #0x00
      00A525 12 A4 C0         [24]  778 	lcall	_via_eeprom_set_valid
                                    779 ;	quantum/via.c:158: via_set_layout_options(VIA_EEPROM_LAYOUT_OPTIONS_DEFAULT);
      00A528 12 8F FA         [24]  780 	lcall	_ak820_outline_0155
      00A52B 12 A5 53         [24]  781 	lcall	_via_set_layout_options
                                    782 ;	quantum/via.c:160: dynamic_keymap_reset();
      00A52E 12 86 80         [24]  783 	lcall	_dynamic_keymap_reset
                                    784 ;	quantum/via.c:162: dynamic_keymap_macro_reset();
      00A531 12 8A F3         [24]  785 	lcall	_dynamic_keymap_macro_reset
                                    786 ;	quantum/via.c:164: via_eeprom_set_valid(true);
      00A534 75 82 01         [24]  787 	mov	dpl, #0x01
                                    788 ;	quantum/via.c:165: }
      00A537 02 A4 C0         [24]  789 	ljmp	_via_eeprom_set_valid
                                    790 ;------------------------------------------------------------
                                    791 ;Allocation info for local variables in function 'via_get_layout_options'
                                    792 ;------------------------------------------------------------
                                    793 ;	quantum/via.c:169: uint32_t via_get_layout_options(void) {
                                    794 ;	-----------------------------------------
                                    795 ;	 function via_get_layout_options
                                    796 ;	-----------------------------------------
      00A53A                        797 _via_get_layout_options:
                                    798 ;	quantum/via.c:173: return eeprom_read_byte((uint8_t *)VIA_EEPROM_LAYOUT_OPTIONS_ADDR);
      00A53A 90 00 28         [24]  799 	mov	dptr,#0x0028
      00A53D 75 F0 00         [24]  800 	mov	b, #0x00
      00A540 12 40 74         [24]  801 	lcall	_eeprom_read_byte
      00A543 AF 82            [24]  802 	mov	r7, dpl
      00A545 7E 00            [12]  803 	mov	r6,#0x00
      00A547 7D 00            [12]  804 	mov	r5,#0x00
      00A549 7C 00            [12]  805 	mov	r4,#0x00
      00A54B 12 43 72         [24]  806 	lcall	_ak820_outline_0161
      00A54E 8D F0            [24]  807 	mov	b, r5
      00A550 EC               [12]  808 	mov	a, r4
                                    809 ;	quantum/via.c:185: }
      00A551 22               [24]  810 	ret
                                    811 ;------------------------------------------------------------
                                    812 ;Allocation info for local variables in function 'via_set_layout_options_kb'
                                    813 ;------------------------------------------------------------
                                    814 ;value         Allocated with name '_via_set_layout_options_kb_value_10000_622'
                                    815 ;------------------------------------------------------------
                                    816 ;	quantum/via.c:187: __attribute__((weak)) void via_set_layout_options_kb(uint32_t value) {}
                                    817 ;	-----------------------------------------
                                    818 ;	 function via_set_layout_options_kb
                                    819 ;	-----------------------------------------
      00A552                        820 _via_set_layout_options_kb:
      00A552 22               [24]  821 	ret
                                    822 ;------------------------------------------------------------
                                    823 ;Allocation info for local variables in function 'via_set_layout_options'
                                    824 ;------------------------------------------------------------
                                    825 ;value         Allocated with name '_via_set_layout_options_value_10000_625'
                                    826 ;------------------------------------------------------------
                                    827 ;	quantum/via.c:189: void via_set_layout_options(uint32_t value) {
                                    828 ;	-----------------------------------------
                                    829 ;	 function via_set_layout_options
                                    830 ;	-----------------------------------------
      00A553                        831 _via_set_layout_options:
      00A553 12 8F F2         [24]  832 	lcall	_ak820_outline_0122
      00A556 90 0C 44         [24]  833 	mov	dptr,#_via_set_layout_options_value_10000_625
      00A559 12 8F E0         [24]  834 	lcall	_ak820_outline_0044
                                    835 ;	quantum/via.c:192: eeprom_update_byte((uint8_t *)VIA_EEPROM_LAYOUT_OPTIONS_ADDR, (uint8_t)value);
      00A55C 90 0C 44         [24]  836 	mov	dptr,#_via_set_layout_options_value_10000_625
      00A55F E0               [24]  837 	movx	a,@dptr
      00A560 90 06 9B         [24]  838 	mov	dptr,#_eeprom_update_byte_PARM_2
      00A563 F0               [24]  839 	movx	@dptr,a
      00A564 90 00 28         [24]  840 	mov	dptr,#0x0028
      00A567 75 F0 00         [24]  841 	mov	b, #0x00
                                    842 ;	quantum/via.c:202: }
      00A56A 02 4D DD         [24]  843 	ljmp	_eeprom_update_byte
                                    844 ;------------------------------------------------------------
                                    845 ;Allocation info for local variables in function 'process_record_via'
                                    846 ;------------------------------------------------------------
                                    847 ;record        Allocated with name '_process_record_via_PARM_2'
                                    848 ;keycode       Allocated with name '_process_record_via_keycode_10000_627'
                                    849 ;id            Allocated with name '_process_record_via_id_50000_632'
                                    850 ;------------------------------------------------------------
                                    851 ;	quantum/via.c:205: bool process_record_via(uint16_t keycode, keyrecord_t *record) {
                                    852 ;	-----------------------------------------
                                    853 ;	 function process_record_via
                                    854 ;	-----------------------------------------
      00A56D                        855 _process_record_via:
      00A56D 12 38 82         [24]  856 	lcall	_ak820_outline_0118
      00A570 90 0C 4B         [24]  857 	mov	dptr,#_process_record_via_keycode_10000_627
      00A573 12 38 87         [24]  858 	lcall	_ak820_outline_0119
                                    859 ;	quantum/via.c:207: if (record->event.pressed) {
      00A576 90 0C 48         [24]  860 	mov	dptr,#_process_record_via_PARM_2
      00A579 12 4E E9         [24]  861 	lcall	_ak820_outline_0011
      00A57C 74 05            [12]  862 	mov	a,#0x05
      00A57E 12 38 BB         [24]  863 	lcall	_ak820_outline_0163
      00A581 12 6D 59         [24]  864 	lcall	_ak820_outline_0059
      00A584 12 B7 FB         [24]  865 	lcall	__gptrget
      00A587 60 1D            [24]  866 	jz	00105$
                                    867 ;	quantum/via.c:208: if (keycode >= QK_MACRO && keycode <= QK_MACRO_MAX) {
      00A589 90 0C 4B         [24]  868 	mov	dptr,#_process_record_via_keycode_10000_627
      00A58C 12 48 26         [24]  869 	lcall	_ak820_outline_0008
      00A58F 74 89            [12]  870 	mov	a,#0x100 - 0x77
      00A591 2D               [12]  871 	add	a,r5
      00A592 50 12            [24]  872 	jnc	00105$
      00A594 C3               [12]  873 	clr	c
      00A595 74 7F            [12]  874 	mov	a,#0x7f
      00A597 9C               [12]  875 	subb	a,r4
      00A598 74 77            [12]  876 	mov	a,#0x77
      00A59A 9D               [12]  877 	subb	a,r5
      00A59B 40 09            [24]  878 	jc	00105$
                                    879 ;	free result
                                    880 ;	quantum/via.c:209: uint8_t id = keycode - QK_MACRO;
                                    881 ;	quantum/via.c:210: dynamic_keymap_macro_send(id);
      00A59D 8E 82            [24]  882 	mov	dpl, r6
      00A59F 12 8B 19         [24]  883 	lcall	_dynamic_keymap_macro_send
                                    884 ;	quantum/via.c:211: return false;
      00A5A2 75 82 00         [24]  885 	mov	dpl, #0x00
      00A5A5 22               [24]  886 	ret
      00A5A6                        887 00105$:
                                    888 ;	quantum/via.c:215: return true;
      00A5A6 75 82 01         [24]  889 	mov	dpl, #0x01
                                    890 ;	quantum/via.c:216: }
      00A5A9 22               [24]  891 	ret
                                    892 ;------------------------------------------------------------
                                    893 ;Allocation info for local variables in function 'raw_hid_receive_kb'
                                    894 ;------------------------------------------------------------
                                    895 ;length        Allocated with name '_raw_hid_receive_kb_PARM_2'
                                    896 ;data          Allocated with name '_raw_hid_receive_kb_data_10000_633'
                                    897 ;command_id    Allocated with name '_raw_hid_receive_kb_command_id_10000_634'
                                    898 ;------------------------------------------------------------
                                    899 ;	quantum/via.c:221: __attribute__((weak)) void raw_hid_receive_kb(uint8_t *data, uint8_t length) {
                                    900 ;	-----------------------------------------
                                    901 ;	 function raw_hid_receive_kb
                                    902 ;	-----------------------------------------
      00A5AA                        903 _raw_hid_receive_kb:
      00A5AA 12 43 13         [24]  904 	lcall	_ak820_outline_0036
      00A5AD 90 0C 4E         [24]  905 	mov	dptr,#_raw_hid_receive_kb_data_10000_633
      00A5B0 12 38 1F         [24]  906 	lcall	_ak820_outline_0016
                                    907 ;	quantum/via.c:222: uint8_t *command_id = &(data[0]);
      00A5B3 90 0C 4E         [24]  908 	mov	dptr,#_raw_hid_receive_kb_data_10000_633
      00A5B6 12 4E C3         [24]  909 	lcall	_ak820_outline_0001
                                    910 ;	quantum/via.c:223: *command_id         = id_unhandled;
      00A5B9 74 FF            [12]  911 	mov	a,#0xff
                                    912 ;	quantum/via.c:224: }
      00A5BB 02 B7 C0         [24]  913 	ljmp	__gptrput
                                    914 ;------------------------------------------------------------
                                    915 ;Allocation info for local variables in function 'raw_hid_receive'
                                    916 ;------------------------------------------------------------
                                    917 ;sloc0         Allocated with name '_raw_hid_receive_sloc0_1_0'
                                    918 ;sloc1         Allocated with name '_raw_hid_receive_sloc1_1_0'
                                    919 ;sloc2         Allocated with name '_raw_hid_receive_sloc2_1_0'
                                    920 ;sloc3         Allocated with name '_raw_hid_receive_sloc3_1_0'
                                    921 ;sloc4         Allocated with name '_raw_hid_receive_sloc4_1_0'
                                    922 ;length        Allocated with name '_raw_hid_receive_PARM_2'
                                    923 ;packet        Allocated with name '_raw_hid_receive_packet_10000_635'
                                    924 ;data          Allocated with name '_raw_hid_receive_data_10000_636'
                                    925 ;command_id    Allocated with name '_raw_hid_receive_command_id_10000_636'
                                    926 ;command_data  Allocated with name '_raw_hid_receive_command_data_10000_636'
                                    927 ;cmd           Allocated with name '_raw_hid_receive_cmd_30001_642'
                                    928 ;value         Allocated with name '_raw_hid_receive_value_70000_650'
                                    929 ;value         Allocated with name '_raw_hid_receive_value_70000_651'
                                    930 ;i             Allocated with name '_raw_hid_receive_i_70001_654'
                                    931 ;row           Allocated with name '_raw_hid_receive_row_80001_655'
                                    932 ;value         Allocated with name '_raw_hid_receive_value_90001_656'
                                    933 ;value         Allocated with name '_raw_hid_receive_value_70000_661'
                                    934 ;keycode       Allocated with name '_raw_hid_receive_keycode_40000_663'
                                    935 ;size          Allocated with name '_raw_hid_receive_size_40000_672'
                                    936 ;offset        Allocated with name '_raw_hid_receive_offset_40000_673'
                                    937 ;size          Allocated with name '_raw_hid_receive_size_40000_673'
                                    938 ;offset        Allocated with name '_raw_hid_receive_offset_40001_678'
                                    939 ;size          Allocated with name '_raw_hid_receive_size_40001_678'
                                    940 ;offset        Allocated with name '_raw_hid_receive_offset_40000_683'
                                    941 ;size          Allocated with name '_raw_hid_receive_size_40000_683'
                                    942 ;offset        Allocated with name '_raw_hid_receive_offset_40000_685'
                                    943 ;size          Allocated with name '_raw_hid_receive_size_40000_685'
                                    944 ;i             Allocated with name '_raw_hid_receive_i_60000_690'
                                    945 ;------------------------------------------------------------
                                    946 ;	quantum/via.c:233: void raw_hid_receive(uint8_t *packet, uint8_t length) {
                                    947 ;	-----------------------------------------
                                    948 ;	 function raw_hid_receive
                                    949 ;	-----------------------------------------
      00A5BE                        950 _raw_hid_receive:
      00A5BE 12 43 13         [24]  951 	lcall	_ak820_outline_0036
      00A5C1 90 0C 52         [24]  952 	mov	dptr,#_raw_hid_receive_packet_10000_635
      00A5C4 12 38 1F         [24]  953 	lcall	_ak820_outline_0016
                                    954 ;	quantum/via.c:236: uint8_t __xdata *data = (uint8_t __xdata *)packet;
      00A5C7 90 0C 52         [24]  955 	mov	dptr,#_raw_hid_receive_packet_10000_635
      00A5CA 12 38 41         [24]  956 	lcall	_ak820_outline_0052
                                    957 ;	quantum/via.c:238: uint8_t __xdata *command_data = &data[1];
      00A5CD 74 01            [12]  958 	mov	a,#0x01
      00A5CF 12 43 77         [24]  959 	lcall	_ak820_outline_0164
                                    960 ;	quantum/via.c:245: if (length != 32) return;
      00A5D2 90 0C 51         [24]  961 	mov	dptr,#_raw_hid_receive_PARM_2
      00A5D5 E0               [24]  962 	movx	a,@dptr
      00A5D6 FB               [12]  963 	mov	r3,a
      00A5D7 BB 20 02         [24]  964 	cjne	r3,#0x20,00520$
      00A5DA 80 01            [24]  965 	sjmp	00102$
      00A5DC                        966 00520$:
      00A5DC 22               [24]  967 	ret
      00A5DD                        968 00102$:
                                    969 ;	quantum/via.c:249: if (vial_unlock_in_progress) {
      00A5DD 90 0E 20         [24]  970 	mov	dptr,#_vial_unlock_in_progress
      00A5E0 E0               [24]  971 	movx	a,@dptr
      00A5E1 60 32            [24]  972 	jz	00114$
                                    973 ;	quantum/via.c:250: if (data[0] != id_vial_prefix) {
      00A5E3 12 38 8C         [24]  974 	lcall	_ak820_outline_0120
      00A5E6 E0               [24]  975 	movx	a,@dptr
      00A5E7 FA               [12]  976 	mov	r2,a
      00A5E8 BA FE 02         [24]  977 	cjne	r2,#0xfe,00522$
      00A5EB 80 01            [24]  978 	sjmp	00104$
      00A5ED                        979 00522$:
                                    980 ;	quantum/via.c:252: return;
      00A5ED 22               [24]  981 	ret
      00A5EE                        982 00104$:
                                    983 ;	quantum/via.c:257: uint8_t cmd = data[1];
      00A5EE 12 43 44         [24]  984 	lcall	_ak820_outline_0096
                                    985 ;	quantum/via.c:258: if (cmd != vial_get_keyboard_id && cmd != vial_get_size && cmd != vial_get_def && cmd != vial_get_unlock_status && cmd != vial_unlock_start && cmd != vial_unlock_poll && cmd != vial_lock)
      00A5F1 FA               [12]  986 	mov	r2,a
      00A5F2 60 21            [24]  987 	jz	00114$
      00A5F4 BA 01 02         [24]  988 	cjne	r2,#0x01,00524$
      00A5F7 80 1C            [24]  989 	sjmp	00114$
      00A5F9                        990 00524$:
      00A5F9 BA 02 02         [24]  991 	cjne	r2,#0x02,00525$
      00A5FC 80 17            [24]  992 	sjmp	00114$
      00A5FE                        993 00525$:
      00A5FE BA 05 02         [24]  994 	cjne	r2,#0x05,00526$
      00A601 80 12            [24]  995 	sjmp	00114$
      00A603                        996 00526$:
      00A603 BA 06 02         [24]  997 	cjne	r2,#0x06,00527$
      00A606 80 0D            [24]  998 	sjmp	00114$
      00A608                        999 00527$:
      00A608 BA 07 02         [24] 1000 	cjne	r2,#0x07,00528$
      00A60B 80 08            [24] 1001 	sjmp	00114$
      00A60D                       1002 00528$:
      00A60D BA 08 02         [24] 1003 	cjne	r2,#0x08,00529$
      00A610 80 03            [24] 1004 	sjmp	00530$
      00A612                       1005 00529$:
      00A612 02 AB 4A         [24] 1006 	ljmp	00171$
      00A615                       1007 00530$:
                                   1008 ;	quantum/via.c:259: goto skip;
      00A615                       1009 00114$:
                                   1010 ;	quantum/via.c:263: switch (*command_id) {
      00A615 12 38 8C         [24] 1011 	lcall	_ak820_outline_0120
      00A618 E0               [24] 1012 	movx	a,@dptr
      00A619 FA               [12] 1013 	mov	r2,a
      00A61A BA 01 02         [24] 1014 	cjne	r2,#0x01,00531$
      00A61D 80 6E            [24] 1015 	sjmp	00115$
      00A61F                       1016 00531$:
      00A61F BA 02 02         [24] 1017 	cjne	r2,#0x02,00532$
      00A622 80 76            [24] 1018 	sjmp	00116$
      00A624                       1019 00532$:
      00A624 BA 03 03         [24] 1020 	cjne	r2,#0x03,00533$
      00A627 02 A7 5C         [24] 1021 	ljmp	00125$
      00A62A                       1022 00533$:
      00A62A BA 04 03         [24] 1023 	cjne	r2,#0x04,00534$
      00A62D 02 A7 F1         [24] 1024 	ljmp	00129$
      00A630                       1025 00534$:
      00A630 BA 05 03         [24] 1026 	cjne	r2,#0x05,00535$
      00A633 02 A8 2B         [24] 1027 	ljmp	00130$
      00A636                       1028 00535$:
      00A636 BA 06 03         [24] 1029 	cjne	r2,#0x06,00536$
      00A639 02 A8 97         [24] 1030 	ljmp	00135$
      00A63C                       1031 00536$:
      00A63C BA 07 03         [24] 1032 	cjne	r2,#0x07,00537$
      00A63F 02 A8 A9         [24] 1033 	ljmp	00136$
      00A642                       1034 00537$:
      00A642 BA 08 03         [24] 1035 	cjne	r2,#0x08,00538$
      00A645 02 A8 C4         [24] 1036 	ljmp	00137$
      00A648                       1037 00538$:
      00A648 BA 09 03         [24] 1038 	cjne	r2,#0x09,00539$
      00A64B 02 A8 DF         [24] 1039 	ljmp	00138$
      00A64E                       1040 00539$:
      00A64E BA 0B 03         [24] 1041 	cjne	r2,#0x0b,00540$
      00A651 02 AA D8         [24] 1042 	ljmp	00161$
      00A654                       1043 00540$:
      00A654 BA 0C 03         [24] 1044 	cjne	r2,#0x0c,00541$
      00A657 02 A8 FA         [24] 1045 	ljmp	00139$
      00A65A                       1046 00541$:
      00A65A BA 0D 03         [24] 1047 	cjne	r2,#0x0d,00542$
      00A65D 02 A9 1B         [24] 1048 	ljmp	00140$
      00A660                       1049 00542$:
      00A660 BA 0E 03         [24] 1050 	cjne	r2,#0x0e,00543$
      00A663 02 A9 44         [24] 1051 	ljmp	00141$
      00A666                       1052 00543$:
      00A666 BA 0F 03         [24] 1053 	cjne	r2,#0x0f,00544$
      00A669 02 A9 8C         [24] 1054 	ljmp	00144$
      00A66C                       1055 00544$:
      00A66C BA 10 03         [24] 1056 	cjne	r2,#0x10,00545$
      00A66F 02 A9 FB         [24] 1057 	ljmp	00151$
      00A672                       1058 00545$:
      00A672 BA 11 03         [24] 1059 	cjne	r2,#0x11,00546$
      00A675 02 AA 14         [24] 1060 	ljmp	00154$
      00A678                       1061 00546$:
      00A678 BA 12 03         [24] 1062 	cjne	r2,#0x12,00547$
      00A67B 02 AA 35         [24] 1063 	ljmp	00155$
      00A67E                       1064 00547$:
      00A67E BA 13 03         [24] 1065 	cjne	r2,#0x13,00548$
      00A681 02 AA 7D         [24] 1066 	ljmp	00158$
      00A684                       1067 00548$:
      00A684 BA FE 03         [24] 1068 	cjne	r2,#0xfe,00549$
      00A687 02 AB 18         [24] 1069 	ljmp	00168$
      00A68A                       1070 00549$:
      00A68A 02 AB 32         [24] 1071 	ljmp	00169$
                                   1072 ;	quantum/via.c:264: case id_get_protocol_version: {
      00A68D                       1073 00115$:
                                   1074 ;	quantum/via.c:265: command_data[0] = VIA_PROTOCOL_VERSION >> 8;
      00A68D 12 38 97         [24] 1075 	lcall	_ak820_outline_0126
      00A690 E4               [12] 1076 	clr	a
      00A691 12 43 0B         [24] 1077 	lcall	_ak820_outline_0031
                                   1078 ;	quantum/via.c:266: command_data[1] = VIA_PROTOCOL_VERSION & 0xFF;
      00A694 74 09            [12] 1079 	mov	a,#0x09
      00A696 F0               [24] 1080 	movx	@dptr,a
                                   1081 ;	quantum/via.c:267: break;
      00A697 02 AB 4A         [24] 1082 	ljmp	00171$
                                   1083 ;	quantum/via.c:269: case id_get_keyboard_value: {
      00A69A                       1084 00116$:
                                   1085 ;	quantum/via.c:270: switch (command_data[0]) {
      00A69A 12 43 44         [24] 1086 	lcall	_ak820_outline_0096
      00A69D FA               [12] 1087 	mov	r2,a
      00A69E BA 01 02         [24] 1088 	cjne	r2,#0x01,00550$
      00A6A1 80 0E            [24] 1089 	sjmp	00117$
      00A6A3                       1090 00550$:
      00A6A3 BA 02 02         [24] 1091 	cjne	r2,#0x02,00551$
      00A6A6 80 34            [24] 1092 	sjmp	00118$
      00A6A8                       1093 00551$:
      00A6A8 BA 03 03         [24] 1094 	cjne	r2,#0x03,00552$
      00A6AB 02 A7 17         [24] 1095 	ljmp	00119$
      00A6AE                       1096 00552$:
      00A6AE 02 A7 41         [24] 1097 	ljmp	00123$
                                   1098 ;	quantum/via.c:271: case id_uptime: {
      00A6B1                       1099 00117$:
                                   1100 ;	quantum/via.c:272: uint32_t value  = timer_read32();
      00A6B1 12 49 05         [24] 1101 	lcall	_timer_read32
      00A6B4 85 82 38         [24] 1102 	mov	_raw_hid_receive_sloc0_1_0,dpl
      00A6B7 85 83 39         [24] 1103 	mov	(_raw_hid_receive_sloc0_1_0 + 1),dph
      00A6BA 85 F0 3A         [24] 1104 	mov	(_raw_hid_receive_sloc0_1_0 + 2),b
      00A6BD F5 3B            [12] 1105 	mov	(_raw_hid_receive_sloc0_1_0 + 3),a
                                   1106 ;	quantum/via.c:273: command_data[1] = (value >> 24) & 0xFF;
      00A6BF 12 38 8C         [24] 1107 	lcall	_ak820_outline_0120
      00A6C2 A3               [24] 1108 	inc	dptr
      00A6C3 A3               [24] 1109 	inc	dptr
      00A6C4 E5 3B            [12] 1110 	mov	a,(_raw_hid_receive_sloc0_1_0 + 3)
      00A6C6 12 43 0B         [24] 1111 	lcall	_ak820_outline_0031
                                   1112 ;	quantum/via.c:274: command_data[2] = (value >> 16) & 0xFF;
      00A6C9 A3               [24] 1113 	inc	dptr
      00A6CA E5 3A            [12] 1114 	mov	a,(_raw_hid_receive_sloc0_1_0 + 2)
      00A6CC F0               [24] 1115 	movx	@dptr,a
                                   1116 ;	quantum/via.c:275: command_data[3] = (value >> 8) & 0xFF;
      00A6CD 12 AB 77         [24] 1117 	lcall	_ak820_outline_0023
      00A6D0 E5 39            [12] 1118 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00A6D2 F0               [24] 1119 	movx	@dptr,a
                                   1120 ;	quantum/via.c:276: command_data[4] = value & 0xFF;
      00A6D3 12 43 01         [24] 1121 	lcall	_ak820_outline_0010
      00A6D6 E5 38            [12] 1122 	mov	a,_raw_hid_receive_sloc0_1_0
      00A6D8 F0               [24] 1123 	movx	@dptr,a
                                   1124 ;	quantum/via.c:277: break;
      00A6D9 02 AB 4A         [24] 1125 	ljmp	00171$
                                   1126 ;	quantum/via.c:279: case id_layout_options: {
      00A6DC                       1127 00118$:
                                   1128 ;	quantum/via.c:280: uint32_t value  = via_get_layout_options();
      00A6DC C0 03            [24] 1129 	push	ar3
      00A6DE C0 07            [24] 1130 	push	ar7
      00A6E0 C0 06            [24] 1131 	push	ar6
      00A6E2 C0 03            [24] 1132 	push	ar3
      00A6E4 12 A5 3A         [24] 1133 	lcall	_via_get_layout_options
      00A6E7 85 82 38         [24] 1134 	mov	_raw_hid_receive_sloc0_1_0,dpl
      00A6EA 85 83 39         [24] 1135 	mov	(_raw_hid_receive_sloc0_1_0 + 1),dph
      00A6ED 85 F0 3A         [24] 1136 	mov	(_raw_hid_receive_sloc0_1_0 + 2),b
      00A6F0 F5 3B            [12] 1137 	mov	(_raw_hid_receive_sloc0_1_0 + 3),a
      00A6F2 D0 03            [24] 1138 	pop	ar3
      00A6F4 D0 06            [24] 1139 	pop	ar6
      00A6F6 D0 07            [24] 1140 	pop	ar7
                                   1141 ;	quantum/via.c:281: command_data[1] = (value >> 24) & 0xFF;
      00A6F8 12 38 8C         [24] 1142 	lcall	_ak820_outline_0120
      00A6FB A3               [24] 1143 	inc	dptr
      00A6FC A3               [24] 1144 	inc	dptr
      00A6FD E5 3B            [12] 1145 	mov	a,(_raw_hid_receive_sloc0_1_0 + 3)
      00A6FF 12 43 0B         [24] 1146 	lcall	_ak820_outline_0031
                                   1147 ;	quantum/via.c:282: command_data[2] = (value >> 16) & 0xFF;
      00A702 A3               [24] 1148 	inc	dptr
      00A703 E5 3A            [12] 1149 	mov	a,(_raw_hid_receive_sloc0_1_0 + 2)
      00A705 F0               [24] 1150 	movx	@dptr,a
                                   1151 ;	quantum/via.c:283: command_data[3] = (value >> 8) & 0xFF;
      00A706 12 AB 77         [24] 1152 	lcall	_ak820_outline_0023
      00A709 E5 39            [12] 1153 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00A70B F0               [24] 1154 	movx	@dptr,a
                                   1155 ;	quantum/via.c:284: command_data[4] = value & 0xFF;
      00A70C 12 43 01         [24] 1156 	lcall	_ak820_outline_0010
      00A70F E5 38            [12] 1157 	mov	a,_raw_hid_receive_sloc0_1_0
      00A711 F0               [24] 1158 	movx	@dptr,a
                                   1159 ;	quantum/via.c:285: break;
      00A712 D0 03            [24] 1160 	pop	ar3
      00A714 02 AB 4A         [24] 1161 	ljmp	00171$
                                   1162 ;	quantum/via.c:287: case id_switch_matrix_state: {
      00A717                       1163 00119$:
                                   1164 ;	quantum/via.c:290: if (!vial_unlocked)
      00A717 90 0E 1F         [24] 1165 	mov	dptr,#_vial_unlocked
      00A71A E0               [24] 1166 	movx	a,@dptr
      00A71B 70 03            [24] 1167 	jnz	00553$
      00A71D 02 AB 4A         [24] 1168 	ljmp	00171$
      00A720                       1169 00553$:
                                   1170 ;	quantum/via.c:296: for (uint8_t row = 0; row < MATRIX_ROWS; row++) {
      00A720 7A 01            [12] 1171 	mov	r2,#0x01
      00A722 79 00            [12] 1172 	mov	r1,#0x00
      00A724                       1173 00173$:
      00A724 B9 10 00         [24] 1174 	cjne	r1,#0x10,00554$
      00A727                       1175 00554$:
      00A727 40 03            [24] 1176 	jc	00555$
      00A729 02 AB 4A         [24] 1177 	ljmp	00171$
      00A72C                       1178 00555$:
                                   1179 ;	quantum/via.c:297: matrix_row_t value = matrix_get_row(row);
      00A72C 89 82            [24] 1180 	mov	dpl, r1
      00A72E 12 59 7E         [24] 1181 	lcall	_matrix_get_row
      00A731 A8 82            [24] 1182 	mov	r0, dpl
                                   1183 ;	quantum/via.c:307: command_data[i++] = value & 0xFF;
      00A733 EA               [12] 1184 	mov	a,r2
      00A734 2C               [12] 1185 	add	a, r4
      00A735 F5 82            [12] 1186 	mov	dpl,a
      00A737 E4               [12] 1187 	clr	a
      00A738 3D               [12] 1188 	addc	a, r5
      00A739 F5 83            [12] 1189 	mov	dph,a
      00A73B 0A               [12] 1190 	inc	r2
      00A73C E8               [12] 1191 	mov	a,r0
      00A73D F0               [24] 1192 	movx	@dptr,a
                                   1193 ;	quantum/via.c:296: for (uint8_t row = 0; row < MATRIX_ROWS; row++) {
      00A73E 09               [12] 1194 	inc	r1
                                   1195 ;	quantum/via.c:312: default: {
      00A73F 80 E3            [24] 1196 	sjmp	00173$
      00A741                       1197 00123$:
                                   1198 ;	quantum/via.c:313: raw_hid_receive_kb(data, length);
      00A741 12 48 89         [24] 1199 	lcall	_ak820_outline_0076
      00A744 90 0C 4D         [24] 1200 	mov	dptr,#_raw_hid_receive_kb_PARM_2
      00A747 12 AB 80         [24] 1201 	lcall	_ak820_outline_0041
      00A74A C0 07            [24] 1202 	push	ar7
      00A74C C0 06            [24] 1203 	push	ar6
      00A74E C0 03            [24] 1204 	push	ar3
      00A750 12 A5 AA         [24] 1205 	lcall	_raw_hid_receive_kb
      00A753 D0 03            [24] 1206 	pop	ar3
      00A755 D0 06            [24] 1207 	pop	ar6
      00A757 D0 07            [24] 1208 	pop	ar7
                                   1209 ;	quantum/via.c:317: break;
      00A759 02 AB 4A         [24] 1210 	ljmp	00171$
                                   1211 ;	quantum/via.c:319: case id_set_keyboard_value: {
      00A75C                       1212 00125$:
                                   1213 ;	quantum/via.c:320: switch (command_data[0]) {
      00A75C 12 43 44         [24] 1214 	lcall	_ak820_outline_0096
      00A75F FA               [12] 1215 	mov	r2,a
      00A760 BA 02 02         [24] 1216 	cjne	r2,#0x02,00556$
      00A763 80 03            [24] 1217 	sjmp	00557$
      00A765                       1218 00556$:
      00A765 02 A7 D6         [24] 1219 	ljmp	00127$
      00A768                       1220 00557$:
                                   1221 ;	quantum/via.c:322: uint32_t value = ((uint32_t)command_data[1] << 24) | ((uint32_t)command_data[2] << 16) | ((uint32_t)command_data[3] << 8) | (uint32_t)command_data[4];
      00A768 C0 03            [24] 1222 	push	ar3
      00A76A 12 38 39         [24] 1223 	lcall	_ak820_outline_0037
      00A76D F8               [12] 1224 	mov	r0,a
      00A76E 79 00            [12] 1225 	mov	r1,#0x00
      00A770 7B 00            [12] 1226 	mov	r3,#0x00
      00A772 88 3B            [24] 1227 	mov	(_raw_hid_receive_sloc0_1_0 + 3),r0
      00A774 8B 38            [24] 1228 	mov	_raw_hid_receive_sloc0_1_0,r3
      00A776 8B 39            [24] 1229 	mov	(_raw_hid_receive_sloc0_1_0 + 1),r3
      00A778 8B 3A            [24] 1230 	mov	(_raw_hid_receive_sloc0_1_0 + 2),r3
      00A77A 12 AB 6E         [24] 1231 	lcall	_ak820_outline_0018
      00A77D F8               [12] 1232 	mov	r0,a
      00A77E 89 03            [24] 1233 	mov	ar3,r1
      00A780 88 02            [24] 1234 	mov	ar2,r0
      00A782 E4               [12] 1235 	clr	a
      00A783 42 38            [12] 1236 	orl	_raw_hid_receive_sloc0_1_0,a
      00A785 E9               [12] 1237 	mov	a,r1
      00A786 42 39            [12] 1238 	orl	(_raw_hid_receive_sloc0_1_0 + 1),a
      00A788 EA               [12] 1239 	mov	a,r2
      00A789 42 3A            [12] 1240 	orl	(_raw_hid_receive_sloc0_1_0 + 2),a
      00A78B EB               [12] 1241 	mov	a,r3
      00A78C 42 3B            [12] 1242 	orl	(_raw_hid_receive_sloc0_1_0 + 3),a
      00A78E 12 AB 77         [24] 1243 	lcall	_ak820_outline_0023
      00A791 E0               [24] 1244 	movx	a,@dptr
      00A792 F8               [12] 1245 	mov	r0,a
      00A793 79 00            [12] 1246 	mov	r1,#0x00
      00A795 7A 00            [12] 1247 	mov	r2,#0x00
      00A797 8A 03            [24] 1248 	mov	ar3,r2
      00A799 89 02            [24] 1249 	mov	ar2,r1
      00A79B 88 01            [24] 1250 	mov	ar1,r0
      00A79D E4               [12] 1251 	clr	a
      00A79E 42 38            [12] 1252 	orl	_raw_hid_receive_sloc0_1_0,a
      00A7A0 E9               [12] 1253 	mov	a,r1
      00A7A1 42 39            [12] 1254 	orl	(_raw_hid_receive_sloc0_1_0 + 1),a
      00A7A3 EA               [12] 1255 	mov	a,r2
      00A7A4 42 3A            [12] 1256 	orl	(_raw_hid_receive_sloc0_1_0 + 2),a
      00A7A6 EB               [12] 1257 	mov	a,r3
      00A7A7 42 3B            [12] 1258 	orl	(_raw_hid_receive_sloc0_1_0 + 3),a
      00A7A9 12 43 01         [24] 1259 	lcall	_ak820_outline_0010
      00A7AC E0               [24] 1260 	movx	a,@dptr
      00A7AD F8               [12] 1261 	mov	r0,a
      00A7AE E4               [12] 1262 	clr	a
      00A7AF F9               [12] 1263 	mov	r1,a
      00A7B0 FA               [12] 1264 	mov	r2,a
      00A7B1 FB               [12] 1265 	mov	r3,a
      00A7B2 E5 39            [12] 1266 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00A7B4 42 01            [12] 1267 	orl	ar1,a
      00A7B6 E5 3A            [12] 1268 	mov	a,(_raw_hid_receive_sloc0_1_0 + 2)
      00A7B8 42 02            [12] 1269 	orl	ar2,a
      00A7BA E5 3B            [12] 1270 	mov	a,(_raw_hid_receive_sloc0_1_0 + 3)
      00A7BC 42 03            [12] 1271 	orl	ar3,a
                                   1272 ;	quantum/via.c:323: via_set_layout_options(value);
      00A7BE 12 48 B2         [24] 1273 	lcall	_ak820_outline_0112
      00A7C1 EB               [12] 1274 	mov	a, r3
      00A7C2 C0 07            [24] 1275 	push	ar7
      00A7C4 C0 06            [24] 1276 	push	ar6
      00A7C6 C0 03            [24] 1277 	push	ar3
      00A7C8 12 A5 53         [24] 1278 	lcall	_via_set_layout_options
      00A7CB D0 03            [24] 1279 	pop	ar3
      00A7CD D0 06            [24] 1280 	pop	ar6
      00A7CF D0 07            [24] 1281 	pop	ar7
                                   1282 ;	quantum/via.c:324: break;
      00A7D1 D0 03            [24] 1283 	pop	ar3
      00A7D3 02 AB 4A         [24] 1284 	ljmp	00171$
                                   1285 ;	quantum/via.c:326: default: {
      00A7D6                       1286 00127$:
                                   1287 ;	quantum/via.c:327: raw_hid_receive_kb(data, length);
      00A7D6 12 48 89         [24] 1288 	lcall	_ak820_outline_0076
      00A7D9 90 0C 4D         [24] 1289 	mov	dptr,#_raw_hid_receive_kb_PARM_2
      00A7DC 12 AB 80         [24] 1290 	lcall	_ak820_outline_0041
      00A7DF C0 07            [24] 1291 	push	ar7
      00A7E1 C0 06            [24] 1292 	push	ar6
      00A7E3 C0 03            [24] 1293 	push	ar3
      00A7E5 12 A5 AA         [24] 1294 	lcall	_raw_hid_receive_kb
      00A7E8 D0 03            [24] 1295 	pop	ar3
      00A7EA D0 06            [24] 1296 	pop	ar6
      00A7EC D0 07            [24] 1297 	pop	ar7
                                   1298 ;	quantum/via.c:331: break;
      00A7EE 02 AB 4A         [24] 1299 	ljmp	00171$
                                   1300 ;	quantum/via.c:333: case id_dynamic_keymap_get_keycode: {
      00A7F1                       1301 00129$:
                                   1302 ;	quantum/via.c:334: uint16_t keycode = dynamic_keymap_get_keycode(command_data[0], command_data[1], command_data[2]);
      00A7F1 12 43 44         [24] 1303 	lcall	_ak820_outline_0096
      00A7F4 FA               [12] 1304 	mov	r2,a
      00A7F5 12 38 39         [24] 1305 	lcall	_ak820_outline_0037
      00A7F8 F9               [12] 1306 	mov	r1,a
      00A7F9 12 AB 6E         [24] 1307 	lcall	_ak820_outline_0018
      00A7FC F8               [12] 1308 	mov	r0,a
      00A7FD 90 0A DF         [24] 1309 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      00A800 E9               [12] 1310 	mov	a,r1
      00A801 F0               [24] 1311 	movx	@dptr,a
      00A802 90 0A E0         [24] 1312 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      00A805 E8               [12] 1313 	mov	a,r0
      00A806 F0               [24] 1314 	movx	@dptr,a
      00A807 8A 82            [24] 1315 	mov	dpl, r2
      00A809 C0 07            [24] 1316 	push	ar7
      00A80B C0 06            [24] 1317 	push	ar6
      00A80D C0 03            [24] 1318 	push	ar3
      00A80F 12 83 AB         [24] 1319 	lcall	_dynamic_keymap_get_keycode
      00A812 A9 82            [24] 1320 	mov	r1, dpl
      00A814 AA 83            [24] 1321 	mov	r2, dph
      00A816 D0 03            [24] 1322 	pop	ar3
      00A818 D0 06            [24] 1323 	pop	ar6
      00A81A D0 07            [24] 1324 	pop	ar7
                                   1325 ;	quantum/via.c:335: command_data[3]  = keycode >> 8;
      00A81C 12 AB 77         [24] 1326 	lcall	_ak820_outline_0023
      00A81F 8A 00            [24] 1327 	mov	ar0,r2
      00A821 E8               [12] 1328 	mov	a,r0
      00A822 F0               [24] 1329 	movx	@dptr,a
                                   1330 ;	quantum/via.c:336: command_data[4]  = keycode & 0xFF;
      00A823 12 43 01         [24] 1331 	lcall	_ak820_outline_0010
      00A826 E9               [12] 1332 	mov	a,r1
      00A827 F0               [24] 1333 	movx	@dptr,a
                                   1334 ;	quantum/via.c:337: break;
      00A828 02 AB 4A         [24] 1335 	ljmp	00171$
                                   1336 ;	quantum/via.c:339: case id_dynamic_keymap_set_keycode: {
      00A82B                       1337 00130$:
                                   1338 ;	quantum/via.c:343: if (!vial_unlocked && command_data[3] == (QK_BOOT >> 8) && command_data[4] == (QK_BOOT & 0xFF)) {
      00A82B 90 0E 1F         [24] 1339 	mov	dptr,#_vial_unlocked
      00A82E E0               [24] 1340 	movx	a,@dptr
      00A82F 70 19            [24] 1341 	jnz	00132$
      00A831 12 AB 77         [24] 1342 	lcall	_ak820_outline_0023
      00A834 E0               [24] 1343 	movx	a,@dptr
      00A835 FA               [12] 1344 	mov	r2,a
      00A836 BA 7C 11         [24] 1345 	cjne	r2,#0x7c,00132$
      00A839 74 05            [12] 1346 	mov	a,#0x05
      00A83B 2E               [12] 1347 	add	a, r6
      00A83C 12 38 27         [24] 1348 	lcall	_ak820_outline_0017
      00A83F 70 09            [24] 1349 	jnz	00132$
                                   1350 ;	quantum/via.c:344: *command_id = id_unhandled;
      00A841 12 38 8C         [24] 1351 	lcall	_ak820_outline_0120
      00A844 74 FF            [12] 1352 	mov	a,#0xff
      00A846 F0               [24] 1353 	movx	@dptr,a
                                   1354 ;	quantum/via.c:345: break;
      00A847 02 AB 4A         [24] 1355 	ljmp	00171$
      00A84A                       1356 00132$:
                                   1357 ;	quantum/via.c:348: dynamic_keymap_set_keycode(command_data[0], command_data[1], command_data[2], (command_data[3] << 8) | command_data[4]);
      00A84A C0 03            [24] 1358 	push	ar3
      00A84C 12 43 44         [24] 1359 	lcall	_ak820_outline_0096
      00A84F F5 3D            [12] 1360 	mov	_raw_hid_receive_sloc2_1_0,a
      00A851 12 38 39         [24] 1361 	lcall	_ak820_outline_0037
      00A854 F5 3C            [12] 1362 	mov	_raw_hid_receive_sloc1_1_0,a
      00A856 12 AB 6E         [24] 1363 	lcall	_ak820_outline_0018
      00A859 F5 38            [12] 1364 	mov	_raw_hid_receive_sloc0_1_0,a
      00A85B 12 AB 77         [24] 1365 	lcall	_ak820_outline_0023
      00A85E E0               [24] 1366 	movx	a,@dptr
      00A85F FB               [12] 1367 	mov	r3,a
      00A860 78 00            [12] 1368 	mov	r0,#0x00
      00A862 12 43 01         [24] 1369 	lcall	_ak820_outline_0010
      00A865 E0               [24] 1370 	movx	a,@dptr
      00A866 7A 00            [12] 1371 	mov	r2,#0x00
      00A868 42 00            [12] 1372 	orl	ar0,a
      00A86A EA               [12] 1373 	mov	a,r2
      00A86B 42 03            [12] 1374 	orl	ar3,a
      00A86D 90 0A E2         [24] 1375 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      00A870 E5 3C            [12] 1376 	mov	a,_raw_hid_receive_sloc1_1_0
      00A872 F0               [24] 1377 	movx	@dptr,a
      00A873 90 0A E3         [24] 1378 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      00A876 E5 38            [12] 1379 	mov	a,_raw_hid_receive_sloc0_1_0
      00A878 F0               [24] 1380 	movx	@dptr,a
      00A879 90 0A E4         [24] 1381 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      00A87C E8               [12] 1382 	mov	a,r0
      00A87D 12 77 30         [24] 1383 	lcall	_ak820_outline_0189
      00A880 85 3D 82         [24] 1384 	mov	dpl, _raw_hid_receive_sloc2_1_0
      00A883 C0 07            [24] 1385 	push	ar7
      00A885 C0 06            [24] 1386 	push	ar6
      00A887 C0 03            [24] 1387 	push	ar3
      00A889 12 83 F9         [24] 1388 	lcall	_dynamic_keymap_set_keycode
      00A88C D0 03            [24] 1389 	pop	ar3
      00A88E D0 06            [24] 1390 	pop	ar6
      00A890 D0 07            [24] 1391 	pop	ar7
                                   1392 ;	quantum/via.c:349: break;
      00A892 D0 03            [24] 1393 	pop	ar3
      00A894 02 AB 4A         [24] 1394 	ljmp	00171$
                                   1395 ;	quantum/via.c:351: case id_dynamic_keymap_reset: {
      00A897                       1396 00135$:
                                   1397 ;	quantum/via.c:352: dynamic_keymap_reset();
      00A897 C0 07            [24] 1398 	push	ar7
      00A899 C0 06            [24] 1399 	push	ar6
      00A89B C0 03            [24] 1400 	push	ar3
      00A89D 12 86 80         [24] 1401 	lcall	_dynamic_keymap_reset
      00A8A0 D0 03            [24] 1402 	pop	ar3
      00A8A2 D0 06            [24] 1403 	pop	ar6
      00A8A4 D0 07            [24] 1404 	pop	ar7
                                   1405 ;	quantum/via.c:353: break;
      00A8A6 02 AB 4A         [24] 1406 	ljmp	00171$
                                   1407 ;	quantum/via.c:355: case id_lighting_set_value: {
      00A8A9                       1408 00136$:
                                   1409 ;	quantum/via.c:363: vialrgb_set_value(data, length);
      00A8A9 12 48 89         [24] 1410 	lcall	_ak820_outline_0076
      00A8AC 90 0D 98         [24] 1411 	mov	dptr,#_vialrgb_set_value_PARM_2
      00A8AF 12 AB 80         [24] 1412 	lcall	_ak820_outline_0041
      00A8B2 C0 07            [24] 1413 	push	ar7
      00A8B4 C0 06            [24] 1414 	push	ar6
      00A8B6 C0 03            [24] 1415 	push	ar3
      00A8B8 12 B5 96         [24] 1416 	lcall	_vialrgb_set_value
      00A8BB D0 03            [24] 1417 	pop	ar3
      00A8BD D0 06            [24] 1418 	pop	ar6
      00A8BF D0 07            [24] 1419 	pop	ar7
                                   1420 ;	quantum/via.c:375: break;
      00A8C1 02 AB 4A         [24] 1421 	ljmp	00171$
                                   1422 ;	quantum/via.c:377: case id_lighting_get_value: {
      00A8C4                       1423 00137$:
                                   1424 ;	quantum/via.c:385: vialrgb_get_value(data, length);
      00A8C4 12 48 89         [24] 1425 	lcall	_ak820_outline_0076
      00A8C7 90 0D 94         [24] 1426 	mov	dptr,#_vialrgb_get_value_PARM_2
      00A8CA 12 AB 80         [24] 1427 	lcall	_ak820_outline_0041
      00A8CD C0 07            [24] 1428 	push	ar7
      00A8CF C0 06            [24] 1429 	push	ar6
      00A8D1 C0 03            [24] 1430 	push	ar3
      00A8D3 12 B4 2B         [24] 1431 	lcall	_vialrgb_get_value
      00A8D6 D0 03            [24] 1432 	pop	ar3
      00A8D8 D0 06            [24] 1433 	pop	ar6
      00A8DA D0 07            [24] 1434 	pop	ar7
                                   1435 ;	quantum/via.c:397: break;
      00A8DC 02 AB 4A         [24] 1436 	ljmp	00171$
                                   1437 ;	quantum/via.c:399: case id_lighting_save: {
      00A8DF                       1438 00138$:
                                   1439 ;	quantum/via.c:407: vialrgb_save(data, length);
      00A8DF 12 48 89         [24] 1440 	lcall	_ak820_outline_0076
      00A8E2 90 0D 9C         [24] 1441 	mov	dptr,#_vialrgb_save_PARM_2
      00A8E5 12 AB 80         [24] 1442 	lcall	_ak820_outline_0041
      00A8E8 C0 07            [24] 1443 	push	ar7
      00A8EA C0 06            [24] 1444 	push	ar6
      00A8EC C0 03            [24] 1445 	push	ar3
      00A8EE 12 B6 24         [24] 1446 	lcall	_vialrgb_save
      00A8F1 D0 03            [24] 1447 	pop	ar3
      00A8F3 D0 06            [24] 1448 	pop	ar6
      00A8F5 D0 07            [24] 1449 	pop	ar7
                                   1450 ;	quantum/via.c:419: break;
      00A8F7 02 AB 4A         [24] 1451 	ljmp	00171$
                                   1452 ;	quantum/via.c:428: case id_dynamic_keymap_macro_get_count: {
      00A8FA                       1453 00139$:
                                   1454 ;	quantum/via.c:429: command_data[0] = dynamic_keymap_macro_get_count();
      00A8FA C0 07            [24] 1455 	push	ar7
      00A8FC C0 06            [24] 1456 	push	ar6
      00A8FE C0 05            [24] 1457 	push	ar5
      00A900 C0 04            [24] 1458 	push	ar4
      00A902 C0 03            [24] 1459 	push	ar3
      00A904 12 8A 6F         [24] 1460 	lcall	_dynamic_keymap_macro_get_count
      00A907 AA 82            [24] 1461 	mov	r2, dpl
      00A909 D0 03            [24] 1462 	pop	ar3
      00A90B D0 04            [24] 1463 	pop	ar4
      00A90D D0 05            [24] 1464 	pop	ar5
      00A90F D0 06            [24] 1465 	pop	ar6
      00A911 D0 07            [24] 1466 	pop	ar7
      00A913 12 38 97         [24] 1467 	lcall	_ak820_outline_0126
      00A916 EA               [12] 1468 	mov	a,r2
      00A917 F0               [24] 1469 	movx	@dptr,a
                                   1470 ;	quantum/via.c:430: break;
      00A918 02 AB 4A         [24] 1471 	ljmp	00171$
                                   1472 ;	quantum/via.c:432: case id_dynamic_keymap_macro_get_buffer_size: {
      00A91B                       1473 00140$:
                                   1474 ;	quantum/via.c:433: uint16_t size   = dynamic_keymap_macro_get_buffer_size();
      00A91B C0 07            [24] 1475 	push	ar7
      00A91D C0 06            [24] 1476 	push	ar6
      00A91F C0 05            [24] 1477 	push	ar5
      00A921 C0 04            [24] 1478 	push	ar4
      00A923 C0 03            [24] 1479 	push	ar3
      00A925 12 8A 73         [24] 1480 	lcall	_dynamic_keymap_macro_get_buffer_size
      00A928 A9 82            [24] 1481 	mov	r1, dpl
      00A92A AA 83            [24] 1482 	mov	r2, dph
      00A92C D0 03            [24] 1483 	pop	ar3
      00A92E D0 04            [24] 1484 	pop	ar4
      00A930 D0 05            [24] 1485 	pop	ar5
      00A932 D0 06            [24] 1486 	pop	ar6
      00A934 D0 07            [24] 1487 	pop	ar7
                                   1488 ;	quantum/via.c:434: command_data[0] = size >> 8;
      00A936 8A 00            [24] 1489 	mov	ar0,r2
      00A938 12 38 97         [24] 1490 	lcall	_ak820_outline_0126
      00A93B E8               [12] 1491 	mov	a,r0
      00A93C 12 43 0B         [24] 1492 	lcall	_ak820_outline_0031
                                   1493 ;	quantum/via.c:435: command_data[1] = size & 0xFF;
      00A93F E9               [12] 1494 	mov	a,r1
      00A940 F0               [24] 1495 	movx	@dptr,a
                                   1496 ;	quantum/via.c:436: break;
      00A941 02 AB 4A         [24] 1497 	ljmp	00171$
                                   1498 ;	quantum/via.c:438: case id_dynamic_keymap_macro_get_buffer: {
      00A944                       1499 00141$:
                                   1500 ;	quantum/via.c:439: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00A944 C0 03            [24] 1501 	push	ar3
      00A946 12 AB 57         [24] 1502 	lcall	_ak820_outline_0003
      00A949 89 38            [24] 1503 	mov	_raw_hid_receive_sloc0_1_0,r1
      00A94B 8A 39            [24] 1504 	mov	(_raw_hid_receive_sloc0_1_0 + 1),r2
                                   1505 ;	quantum/via.c:440: uint16_t size   = command_data[2]; // size <= 28
      00A94D 12 AB 6E         [24] 1506 	lcall	_ak820_outline_0018
      00A950 FB               [12] 1507 	mov	r3,a
                                   1508 ;	quantum/via.c:441: if (size <= 28)
      00A951 8B 3E            [24] 1509 	mov	_raw_hid_receive_sloc3_1_0,r3
      00A953 75 3F 00         [24] 1510 	mov	(_raw_hid_receive_sloc3_1_0 + 1),#0x00
      00A956 C3               [12] 1511 	clr	c
      00A957 74 1C            [12] 1512 	mov	a,#0x1c
      00A959 9B               [12] 1513 	subb	a,r3
      00A95A D0 03            [24] 1514 	pop	ar3
      00A95C 50 03            [24] 1515 	jnc	00562$
      00A95E 02 AB 4A         [24] 1516 	ljmp	00171$
      00A961                       1517 00562$:
                                   1518 ;	free result
                                   1519 ;	quantum/via.c:442: dynamic_keymap_macro_get_buffer(offset, size, &command_data[3]);
      00A961 12 AB 89         [24] 1520 	lcall	_ak820_outline_0069
      00A964 90 0B 31         [24] 1521 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_2
      00A967 E5 3E            [12] 1522 	mov	a,_raw_hid_receive_sloc3_1_0
      00A969 F0               [24] 1523 	movx	@dptr,a
      00A96A E5 3F            [12] 1524 	mov	a,(_raw_hid_receive_sloc3_1_0 + 1)
      00A96C A3               [24] 1525 	inc	dptr
      00A96D F0               [24] 1526 	movx	@dptr,a
      00A96E 90 0B 33         [24] 1527 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_3
      00A971 12 AB 93         [24] 1528 	lcall	_ak820_outline_0088
      00A974 85 38 82         [24] 1529 	mov	dpl, _raw_hid_receive_sloc0_1_0
      00A977 85 39 83         [24] 1530 	mov	dph, (_raw_hid_receive_sloc0_1_0 + 1)
      00A97A C0 07            [24] 1531 	push	ar7
      00A97C C0 06            [24] 1532 	push	ar6
      00A97E C0 03            [24] 1533 	push	ar3
      00A980 12 8A 77         [24] 1534 	lcall	_dynamic_keymap_macro_get_buffer
      00A983 D0 03            [24] 1535 	pop	ar3
      00A985 D0 06            [24] 1536 	pop	ar6
      00A987 D0 07            [24] 1537 	pop	ar7
                                   1538 ;	quantum/via.c:443: break;
      00A989 02 AB 4A         [24] 1539 	ljmp	00171$
                                   1540 ;	quantum/via.c:445: case id_dynamic_keymap_macro_set_buffer: {
      00A98C                       1541 00144$:
                                   1542 ;	quantum/via.c:448: if (!vial_unlocked) {
      00A98C 90 0E 1F         [24] 1543 	mov	dptr,#_vial_unlocked
      00A98F E0               [24] 1544 	movx	a,@dptr
      00A990 70 01            [24] 1545 	jnz	00146$
                                   1546 ;	quantum/via.c:450: return;
      00A992 22               [24] 1547 	ret
      00A993                       1548 00146$:
                                   1549 ;	quantum/via.c:456: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00A993 C0 03            [24] 1550 	push	ar3
      00A995 12 AB 57         [24] 1551 	lcall	_ak820_outline_0003
      00A998 89 3E            [24] 1552 	mov	_raw_hid_receive_sloc3_1_0,r1
      00A99A 8A 3F            [24] 1553 	mov	(_raw_hid_receive_sloc3_1_0 + 1),r2
                                   1554 ;	quantum/via.c:457: uint16_t size   = command_data[2]; // size <= 28
      00A99C 12 AB 6E         [24] 1555 	lcall	_ak820_outline_0018
      00A99F F5 38            [12] 1556 	mov	_raw_hid_receive_sloc0_1_0, a
      00A9A1 75 39 00         [24] 1557 	mov	(_raw_hid_receive_sloc0_1_0 + 1),#0x00
                                   1558 ;	quantum/via.c:461: if (size > 28 || size > length - 4 || !dynamic_keymap_macro_set_buffer(offset, size, &command_data[3])) return;
      00A9A4 85 38 40         [24] 1559 	mov	_raw_hid_receive_sloc4_1_0,_raw_hid_receive_sloc0_1_0
      00A9A7 85 39 41         [24] 1560 	mov	(_raw_hid_receive_sloc4_1_0 + 1),(_raw_hid_receive_sloc0_1_0 + 1)
      00A9AA C3               [12] 1561 	clr	c
      00A9AB 74 1C            [12] 1562 	mov	a,#0x1c
      00A9AD 95 40            [12] 1563 	subb	a,_raw_hid_receive_sloc4_1_0
      00A9AF E4               [12] 1564 	clr	a
      00A9B0 95 41            [12] 1565 	subb	a,(_raw_hid_receive_sloc4_1_0 + 1)
      00A9B2 D0 03            [24] 1566 	pop	ar3
      00A9B4 40 44            [24] 1567 	jc	00147$
                                   1568 ;	free result
      00A9B6 8B 01            [24] 1569 	mov	ar1,r3
      00A9B8 7A 00            [12] 1570 	mov	r2,#0x00
      00A9BA E9               [12] 1571 	mov	a,r1
      00A9BB 24 FC            [12] 1572 	add	a,#0xfc
      00A9BD F9               [12] 1573 	mov	r1,a
      00A9BE EA               [12] 1574 	mov	a,r2
      00A9BF 34 FF            [12] 1575 	addc	a,#0xff
      00A9C1 FA               [12] 1576 	mov	r2,a
      00A9C2 C3               [12] 1577 	clr	c
      00A9C3 E9               [12] 1578 	mov	a,r1
      00A9C4 95 40            [12] 1579 	subb	a,_raw_hid_receive_sloc4_1_0
      00A9C6 EA               [12] 1580 	mov	a,r2
      00A9C7 95 41            [12] 1581 	subb	a,(_raw_hid_receive_sloc4_1_0 + 1)
      00A9C9 40 2F            [24] 1582 	jc	00147$
                                   1583 ;	free result
      00A9CB 12 AB 89         [24] 1584 	lcall	_ak820_outline_0069
      00A9CE 90 0B 38         [24] 1585 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_2
      00A9D1 E5 38            [12] 1586 	mov	a,_raw_hid_receive_sloc0_1_0
      00A9D3 F0               [24] 1587 	movx	@dptr,a
      00A9D4 E5 39            [12] 1588 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00A9D6 A3               [24] 1589 	inc	dptr
      00A9D7 F0               [24] 1590 	movx	@dptr,a
      00A9D8 90 0B 3A         [24] 1591 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_3
      00A9DB 12 AB 93         [24] 1592 	lcall	_ak820_outline_0088
      00A9DE 85 3E 82         [24] 1593 	mov	dpl, _raw_hid_receive_sloc3_1_0
      00A9E1 85 3F 83         [24] 1594 	mov	dph, (_raw_hid_receive_sloc3_1_0 + 1)
      00A9E4 C0 07            [24] 1595 	push	ar7
      00A9E6 C0 06            [24] 1596 	push	ar6
      00A9E8 C0 03            [24] 1597 	push	ar3
      00A9EA 12 8A C5         [24] 1598 	lcall	_dynamic_keymap_macro_set_buffer
      00A9ED E5 82            [12] 1599 	mov	a, dpl
      00A9EF D0 03            [24] 1600 	pop	ar3
      00A9F1 D0 06            [24] 1601 	pop	ar6
      00A9F3 D0 07            [24] 1602 	pop	ar7
      00A9F5 60 03            [24] 1603 	jz	00566$
      00A9F7 02 AB 4A         [24] 1604 	ljmp	00171$
      00A9FA                       1605 00566$:
      00A9FA                       1606 00147$:
      00A9FA 22               [24] 1607 	ret
                                   1608 ;	quantum/via.c:468: case id_dynamic_keymap_macro_reset: {
      00A9FB                       1609 00151$:
                                   1610 ;	quantum/via.c:470: if (!vial_unlocked) return;
      00A9FB 90 0E 1F         [24] 1611 	mov	dptr,#_vial_unlocked
      00A9FE E0               [24] 1612 	movx	a,@dptr
      00A9FF 70 01            [24] 1613 	jnz	00153$
      00AA01 22               [24] 1614 	ret
      00AA02                       1615 00153$:
                                   1616 ;	quantum/via.c:472: dynamic_keymap_macro_reset();
      00AA02 C0 07            [24] 1617 	push	ar7
      00AA04 C0 06            [24] 1618 	push	ar6
      00AA06 C0 03            [24] 1619 	push	ar3
      00AA08 12 8A F3         [24] 1620 	lcall	_dynamic_keymap_macro_reset
      00AA0B D0 03            [24] 1621 	pop	ar3
      00AA0D D0 06            [24] 1622 	pop	ar6
      00AA0F D0 07            [24] 1623 	pop	ar7
                                   1624 ;	quantum/via.c:473: break;
      00AA11 02 AB 4A         [24] 1625 	ljmp	00171$
                                   1626 ;	quantum/via.c:475: case id_dynamic_keymap_get_layer_count: {
      00AA14                       1627 00154$:
                                   1628 ;	quantum/via.c:476: command_data[0] = dynamic_keymap_get_layer_count();
      00AA14 C0 07            [24] 1629 	push	ar7
      00AA16 C0 06            [24] 1630 	push	ar6
      00AA18 C0 05            [24] 1631 	push	ar5
      00AA1A C0 04            [24] 1632 	push	ar4
      00AA1C C0 03            [24] 1633 	push	ar3
      00AA1E 12 83 72         [24] 1634 	lcall	_dynamic_keymap_get_layer_count
      00AA21 AA 82            [24] 1635 	mov	r2, dpl
      00AA23 D0 03            [24] 1636 	pop	ar3
      00AA25 D0 04            [24] 1637 	pop	ar4
      00AA27 D0 05            [24] 1638 	pop	ar5
      00AA29 D0 06            [24] 1639 	pop	ar6
      00AA2B D0 07            [24] 1640 	pop	ar7
      00AA2D 12 38 97         [24] 1641 	lcall	_ak820_outline_0126
      00AA30 EA               [12] 1642 	mov	a,r2
      00AA31 F0               [24] 1643 	movx	@dptr,a
                                   1644 ;	quantum/via.c:477: break;
      00AA32 02 AB 4A         [24] 1645 	ljmp	00171$
                                   1646 ;	quantum/via.c:479: case id_dynamic_keymap_get_buffer: {
      00AA35                       1647 00155$:
                                   1648 ;	quantum/via.c:480: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00AA35 C0 03            [24] 1649 	push	ar3
      00AA37 12 AB 57         [24] 1650 	lcall	_ak820_outline_0003
      00AA3A 89 40            [24] 1651 	mov	_raw_hid_receive_sloc4_1_0,r1
      00AA3C 8A 41            [24] 1652 	mov	(_raw_hid_receive_sloc4_1_0 + 1),r2
                                   1653 ;	quantum/via.c:481: uint16_t size   = command_data[2]; // size <= 28
      00AA3E 12 AB 6E         [24] 1654 	lcall	_ak820_outline_0018
      00AA41 FB               [12] 1655 	mov	r3,a
                                   1656 ;	quantum/via.c:482: if (size <= 28)
      00AA42 8B 3E            [24] 1657 	mov	_raw_hid_receive_sloc3_1_0,r3
      00AA44 75 3F 00         [24] 1658 	mov	(_raw_hid_receive_sloc3_1_0 + 1),#0x00
      00AA47 C3               [12] 1659 	clr	c
      00AA48 74 1C            [12] 1660 	mov	a,#0x1c
      00AA4A 9B               [12] 1661 	subb	a,r3
      00AA4B D0 03            [24] 1662 	pop	ar3
      00AA4D 50 03            [24] 1663 	jnc	00568$
      00AA4F 02 AB 4A         [24] 1664 	ljmp	00171$
      00AA52                       1665 00568$:
                                   1666 ;	free result
                                   1667 ;	quantum/via.c:483: dynamic_keymap_get_buffer(offset, size, &command_data[3]);
      00AA52 12 AB 89         [24] 1668 	lcall	_ak820_outline_0069
      00AA55 90 0B 1A         [24] 1669 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_2
      00AA58 E5 3E            [12] 1670 	mov	a,_raw_hid_receive_sloc3_1_0
      00AA5A F0               [24] 1671 	movx	@dptr,a
      00AA5B E5 3F            [12] 1672 	mov	a,(_raw_hid_receive_sloc3_1_0 + 1)
      00AA5D A3               [24] 1673 	inc	dptr
      00AA5E F0               [24] 1674 	movx	@dptr,a
      00AA5F 90 0B 1C         [24] 1675 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_3
      00AA62 12 AB 93         [24] 1676 	lcall	_ak820_outline_0088
      00AA65 85 40 82         [24] 1677 	mov	dpl, _raw_hid_receive_sloc4_1_0
      00AA68 85 41 83         [24] 1678 	mov	dph, (_raw_hid_receive_sloc4_1_0 + 1)
      00AA6B C0 07            [24] 1679 	push	ar7
      00AA6D C0 06            [24] 1680 	push	ar6
      00AA6F C0 03            [24] 1681 	push	ar3
      00AA71 12 88 3F         [24] 1682 	lcall	_dynamic_keymap_get_buffer
      00AA74 D0 03            [24] 1683 	pop	ar3
      00AA76 D0 06            [24] 1684 	pop	ar6
      00AA78 D0 07            [24] 1685 	pop	ar7
                                   1686 ;	quantum/via.c:484: break;
      00AA7A 02 AB 4A         [24] 1687 	ljmp	00171$
                                   1688 ;	quantum/via.c:486: case id_dynamic_keymap_set_buffer: {
      00AA7D                       1689 00158$:
                                   1690 ;	quantum/via.c:487: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00AA7D 12 43 44         [24] 1691 	lcall	_ak820_outline_0096
      00AA80 FD               [12] 1692 	mov	r5,a
      00AA81 7C 00            [12] 1693 	mov	r4,#0x00
      00AA83 12 38 39         [24] 1694 	lcall	_ak820_outline_0037
      00AA86 7A 00            [12] 1695 	mov	r2,#0x00
      00AA88 42 04            [12] 1696 	orl	ar4,a
      00AA8A EA               [12] 1697 	mov	a,r2
      00AA8B 42 05            [12] 1698 	orl	ar5,a
      00AA8D 8C 40            [24] 1699 	mov	_raw_hid_receive_sloc4_1_0,r4
      00AA8F 8D 41            [24] 1700 	mov	(_raw_hid_receive_sloc4_1_0 + 1),r5
                                   1701 ;	quantum/via.c:488: uint16_t size   = command_data[2]; // size <= 28
      00AA91 12 AB 6E         [24] 1702 	lcall	_ak820_outline_0018
      00AA94 F9               [12] 1703 	mov	r1,a
      00AA95 7A 00            [12] 1704 	mov	r2,#0x00
                                   1705 ;	quantum/via.c:489: if (size <= 28)
      00AA97 89 00            [24] 1706 	mov	ar0,r1
      00AA99 E8               [12] 1707 	mov	a,r0
      00AA9A 24 E3            [12] 1708 	add	a,#0xff - 0x1c
      00AA9C 50 03            [24] 1709 	jnc	00569$
      00AA9E 02 AB 4A         [24] 1710 	ljmp	00171$
      00AAA1                       1711 00569$:
                                   1712 ;	free result
                                   1713 ;	quantum/via.c:490: dynamic_keymap_set_buffer(offset, size, &command_data[3]);
      00AAA1 C0 03            [24] 1714 	push	ar3
      00AAA3 74 04            [12] 1715 	mov	a,#0x04
      00AAA5 2E               [12] 1716 	add	a, r6
      00AAA6 F8               [12] 1717 	mov	r0,a
      00AAA7 E4               [12] 1718 	clr	a
      00AAA8 3F               [12] 1719 	addc	a, r7
      00AAA9 FB               [12] 1720 	mov	r3,a
      00AAAA 7D 00            [12] 1721 	mov	r5,#0x00
      00AAAC 90 0B 21         [24] 1722 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_2
      00AAAF E9               [12] 1723 	mov	a,r1
      00AAB0 F0               [24] 1724 	movx	@dptr,a
      00AAB1 EA               [12] 1725 	mov	a,r2
      00AAB2 A3               [24] 1726 	inc	dptr
      00AAB3 F0               [24] 1727 	movx	@dptr,a
      00AAB4 90 0B 23         [24] 1728 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_3
      00AAB7 E8               [12] 1729 	mov	a,r0
      00AAB8 12 77 30         [24] 1730 	lcall	_ak820_outline_0189
      00AABB ED               [12] 1731 	mov	a,r5
      00AABC A3               [24] 1732 	inc	dptr
      00AABD F0               [24] 1733 	movx	@dptr,a
      00AABE 85 40 82         [24] 1734 	mov	dpl, _raw_hid_receive_sloc4_1_0
      00AAC1 85 41 83         [24] 1735 	mov	dph, (_raw_hid_receive_sloc4_1_0 + 1)
      00AAC4 C0 07            [24] 1736 	push	ar7
      00AAC6 C0 06            [24] 1737 	push	ar6
      00AAC8 C0 03            [24] 1738 	push	ar3
      00AACA 12 88 7D         [24] 1739 	lcall	_dynamic_keymap_set_buffer
      00AACD D0 03            [24] 1740 	pop	ar3
      00AACF D0 06            [24] 1741 	pop	ar6
      00AAD1 D0 07            [24] 1742 	pop	ar7
                                   1743 ;	quantum/via.c:491: break;
      00AAD3 D0 03            [24] 1744 	pop	ar3
      00AAD5 02 AB 4A         [24] 1745 	ljmp	00171$
                                   1746 ;	quantum/via.c:495: case id_bootloader_jump: {
      00AAD8                       1747 00161$:
                                   1748 ;	quantum/via.c:497: if (!vial_unlocked)
      00AAD8 90 0E 1F         [24] 1749 	mov	dptr,#_vial_unlocked
      00AADB E0               [24] 1750 	movx	a,@dptr
      00AADC 70 03            [24] 1751 	jnz	00570$
      00AADE 02 AB 4A         [24] 1752 	ljmp	00171$
      00AAE1                       1753 00570$:
                                   1754 ;	quantum/via.c:501: raw_hid_send(data, length);
      00AAE1 12 AB A5         [24] 1755 	lcall	_ak820_outline_0152
      00AAE4 90 06 75         [24] 1756 	mov	dptr,#_raw_hid_send_PARM_2
      00AAE7 12 AB 9C         [24] 1757 	lcall	_ak820_outline_0089
      00AAEA C0 07            [24] 1758 	push	ar7
      00AAEC C0 06            [24] 1759 	push	ar6
      00AAEE C0 03            [24] 1760 	push	ar3
      00AAF0 12 4A F1         [24] 1761 	lcall	_raw_hid_send
      00AAF3 D0 03            [24] 1762 	pop	ar3
      00AAF5 D0 06            [24] 1763 	pop	ar6
      00AAF7 D0 07            [24] 1764 	pop	ar7
                                   1765 ;	quantum/via.c:503: wait_ms(100);
      00AAF9 7D 64            [12] 1766 	mov	r5,#0x64
      00AAFB                       1767 00176$:
      00AAFB ED               [12] 1768 	mov	a,r5
      00AAFC 60 09            [24] 1769 	jz	00166$
      00AAFE 90 00 01         [24] 1770 	mov	dptr,#0x0001
      00AB01 12 58 BD         [24] 1771 	lcall	_mDelaymS
      00AB04 1D               [12] 1772 	dec	r5
      00AB05 80 F4            [24] 1773 	sjmp	00176$
      00AB07                       1774 00166$:
                                   1775 ;	quantum/via.c:504: bootloader_jump();
      00AB07 C0 07            [24] 1776 	push	ar7
      00AB09 C0 06            [24] 1777 	push	ar6
      00AB0B C0 03            [24] 1778 	push	ar3
      00AB0D 12 34 0E         [24] 1779 	lcall	_bootloader_jump
      00AB10 D0 03            [24] 1780 	pop	ar3
      00AB12 D0 06            [24] 1781 	pop	ar6
      00AB14 D0 07            [24] 1782 	pop	ar7
                                   1783 ;	quantum/via.c:505: break;
                                   1784 ;	quantum/via.c:509: case id_vial_prefix: {
      00AB16 80 32            [24] 1785 	sjmp	00171$
      00AB18                       1786 00168$:
                                   1787 ;	quantum/via.c:510: vial_handle_cmd(data, length);
      00AB18 12 AB A5         [24] 1788 	lcall	_ak820_outline_0152
      00AB1B 90 0C 5F         [24] 1789 	mov	dptr,#_vial_handle_cmd_PARM_2
      00AB1E 12 AB 9C         [24] 1790 	lcall	_ak820_outline_0089
      00AB21 C0 07            [24] 1791 	push	ar7
      00AB23 C0 06            [24] 1792 	push	ar6
      00AB25 C0 03            [24] 1793 	push	ar3
      00AB27 12 AC 92         [24] 1794 	lcall	_vial_handle_cmd
      00AB2A D0 03            [24] 1795 	pop	ar3
      00AB2C D0 06            [24] 1796 	pop	ar6
      00AB2E D0 07            [24] 1797 	pop	ar7
                                   1798 ;	quantum/via.c:511: break;
                                   1799 ;	quantum/via.c:514: default: {
      00AB30 80 18            [24] 1800 	sjmp	00171$
      00AB32                       1801 00169$:
                                   1802 ;	quantum/via.c:516: raw_hid_receive_kb(data, length);
      00AB32 12 AB A5         [24] 1803 	lcall	_ak820_outline_0152
      00AB35 90 0C 4D         [24] 1804 	mov	dptr,#_raw_hid_receive_kb_PARM_2
      00AB38 12 AB 9C         [24] 1805 	lcall	_ak820_outline_0089
      00AB3B C0 07            [24] 1806 	push	ar7
      00AB3D C0 06            [24] 1807 	push	ar6
      00AB3F C0 03            [24] 1808 	push	ar3
      00AB41 12 A5 AA         [24] 1809 	lcall	_raw_hid_receive_kb
      00AB44 D0 03            [24] 1810 	pop	ar3
      00AB46 D0 06            [24] 1811 	pop	ar6
      00AB48 D0 07            [24] 1812 	pop	ar7
                                   1813 ;	quantum/via.c:521: skip:
      00AB4A                       1814 00171$:
                                   1815 ;	quantum/via.c:525: raw_hid_send(data, length);
      00AB4A 7D 00            [12] 1816 	mov	r5,#0x00
      00AB4C 90 06 75         [24] 1817 	mov	dptr,#_raw_hid_send_PARM_2
      00AB4F EB               [12] 1818 	mov	a,r3
      00AB50 F0               [24] 1819 	movx	@dptr,a
      00AB51 12 6F 7E         [24] 1820 	lcall	_ak820_outline_0050
                                   1821 ;	quantum/via.c:526: }
      00AB54 02 4A F1         [24] 1822 	ljmp	_raw_hid_send
                                   1823 	.area CSEG    (CODE)
                                   1824 	.area CONST   (CODE)
                                   1825 	.area XINIT   (CODE)
                                   1826 	.area CABS    (ABS,CODE)
                                   1827 
                                   1828 ; Experimental exact instruction outlining.
                                   1829 	.globl _ak820_outline_0001
                                   1830 	.globl _ak820_outline_0003
                                   1831 	.globl _ak820_outline_0008
                                   1832 	.globl _ak820_outline_0010
                                   1833 	.globl _ak820_outline_0011
                                   1834 	.globl _ak820_outline_0016
                                   1835 	.globl _ak820_outline_0017
                                   1836 	.globl _ak820_outline_0018
                                   1837 	.globl _ak820_outline_0023
                                   1838 	.globl _ak820_outline_0031
                                   1839 	.globl _ak820_outline_0036
                                   1840 	.globl _ak820_outline_0037
                                   1841 	.globl _ak820_outline_0041
                                   1842 	.globl _ak820_outline_0044
                                   1843 	.globl _ak820_outline_0050
                                   1844 	.globl _ak820_outline_0052
                                   1845 	.globl _ak820_outline_0059
                                   1846 	.globl _ak820_outline_0069
                                   1847 	.globl _ak820_outline_0076
                                   1848 	.globl _ak820_outline_0088
                                   1849 	.globl _ak820_outline_0089
                                   1850 	.globl _ak820_outline_0096
                                   1851 	.globl _ak820_outline_0112
                                   1852 	.globl _ak820_outline_0118
                                   1853 	.globl _ak820_outline_0119
                                   1854 	.globl _ak820_outline_0120
                                   1855 	.globl _ak820_outline_0122
                                   1856 	.globl _ak820_outline_0126
                                   1857 	.globl _ak820_outline_0152
                                   1858 	.globl _ak820_outline_0155
                                   1859 	.globl _ak820_outline_0159
                                   1860 	.globl _ak820_outline_0161
                                   1861 	.globl _ak820_outline_0163
                                   1862 	.globl _ak820_outline_0164
                                   1863 	.globl _ak820_outline_0189
                                   1864 
                                   1865 	.area CSEG (CODE)
                                   1866 ; function ak820_outline_0003
      00AB57                       1867 _ak820_outline_0003:
      00AB57 8C 82            [24] 1868 	mov	dpl,r4
      00AB59 8D 83            [24] 1869 	mov	dph,r5
      00AB5B E0               [24] 1870 	movx	a,@dptr
      00AB5C FA               [12] 1871 	mov	r2,a
      00AB5D 79 00            [12] 1872 	mov	r1,#0x00
      00AB5F 8E 82            [24] 1873 	mov	dpl,r6
      00AB61 8F 83            [24] 1874 	mov	dph,r7
      00AB63 A3               [24] 1875 	inc	dptr
      00AB64 A3               [24] 1876 	inc	dptr
      00AB65 E0               [24] 1877 	movx	a,@dptr
      00AB66 7B 00            [12] 1878 	mov	r3,#0x00
      00AB68 42 01            [12] 1879 	orl	ar1,a
      00AB6A EB               [12] 1880 	mov	a,r3
      00AB6B 42 02            [12] 1881 	orl	ar2,a
      00AB6D 22               [24] 1882 	ret
                                   1883 
                                   1884 	.area CSEG (CODE)
                                   1885 ; function ak820_outline_0018
      00AB6E                       1886 _ak820_outline_0018:
      00AB6E 8E 82            [24] 1887 	mov	dpl,r6
      00AB70 8F 83            [24] 1888 	mov	dph,r7
      00AB72 A3               [24] 1889 	inc	dptr
      00AB73 A3               [24] 1890 	inc	dptr
      00AB74 A3               [24] 1891 	inc	dptr
      00AB75 E0               [24] 1892 	movx	a,@dptr
      00AB76 22               [24] 1893 	ret
                                   1894 
                                   1895 	.area CSEG (CODE)
                                   1896 ; function ak820_outline_0023
      00AB77                       1897 _ak820_outline_0023:
      00AB77 8E 82            [24] 1898 	mov	dpl,r6
      00AB79 8F 83            [24] 1899 	mov	dph,r7
      00AB7B A3               [24] 1900 	inc	dptr
      00AB7C A3               [24] 1901 	inc	dptr
      00AB7D A3               [24] 1902 	inc	dptr
      00AB7E A3               [24] 1903 	inc	dptr
      00AB7F 22               [24] 1904 	ret
                                   1905 
                                   1906 	.area CSEG (CODE)
                                   1907 ; function ak820_outline_0041
      00AB80                       1908 _ak820_outline_0041:
      00AB80 EB               [12] 1909 	mov	a,r3
      00AB81 F0               [24] 1910 	movx	@dptr,a
      00AB82 88 82            [24] 1911 	mov	dpl,r0
      00AB84 89 83            [24] 1912 	mov	dph,r1
      00AB86 8A F0            [24] 1913 	mov	b,r2
      00AB88 22               [24] 1914 	ret
                                   1915 
                                   1916 	.area CSEG (CODE)
                                   1917 ; function ak820_outline_0069
      00AB89                       1918 _ak820_outline_0069:
      00AB89 74 04            [12] 1919 	mov	a,#0x04
      00AB8B 2E               [12] 1920 	add	a,r6
      00AB8C F9               [12] 1921 	mov	r1,a
      00AB8D E4               [12] 1922 	clr	a
      00AB8E 3F               [12] 1923 	addc	a,r7
      00AB8F F8               [12] 1924 	mov	r0,a
      00AB90 7A 00            [12] 1925 	mov	r2,#0x00
      00AB92 22               [24] 1926 	ret
                                   1927 
                                   1928 	.area CSEG (CODE)
                                   1929 ; function ak820_outline_0088
      00AB93                       1930 _ak820_outline_0088:
      00AB93 E9               [12] 1931 	mov	a,r1
      00AB94 F0               [24] 1932 	movx	@dptr,a
      00AB95 E8               [12] 1933 	mov	a,r0
      00AB96 A3               [24] 1934 	inc	dptr
      00AB97 F0               [24] 1935 	movx	@dptr,a
      00AB98 EA               [12] 1936 	mov	a,r2
      00AB99 A3               [24] 1937 	inc	dptr
      00AB9A F0               [24] 1938 	movx	@dptr,a
      00AB9B 22               [24] 1939 	ret
                                   1940 
                                   1941 	.area CSEG (CODE)
                                   1942 ; function ak820_outline_0089
      00AB9C                       1943 _ak820_outline_0089:
      00AB9C EB               [12] 1944 	mov	a,r3
      00AB9D F0               [24] 1945 	movx	@dptr,a
      00AB9E 8A 82            [24] 1946 	mov	dpl,r2
      00ABA0 8C 83            [24] 1947 	mov	dph,r4
      00ABA2 8D F0            [24] 1948 	mov	b,r5
      00ABA4 22               [24] 1949 	ret
                                   1950 
                                   1951 	.area CSEG (CODE)
                                   1952 ; function ak820_outline_0152
      00ABA5                       1953 _ak820_outline_0152:
      00ABA5 8E 02            [24] 1954 	mov	ar2,r6
      00ABA7 8F 04            [24] 1955 	mov	ar4,r7
      00ABA9 7D 00            [12] 1956 	mov	r5,#0x00
      00ABAB 22               [24] 1957 	ret
