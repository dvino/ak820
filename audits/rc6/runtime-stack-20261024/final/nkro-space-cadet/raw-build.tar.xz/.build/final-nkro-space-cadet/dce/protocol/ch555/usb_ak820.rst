                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module usb_ak820
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_nvm_end
                                     12 	.globl _ak820_nvm_flush
                                     13 	.globl _ak820_nvm_begin
                                     14 	.globl _ak820_nvm_ok
                                     15 	.globl _ak820_nvm_diagnostic
                                     16 	.globl _mDelaymS
                                     17 	.globl _mDelayuS
                                     18 	.globl _raw_hid_receive
                                     19 	.globl _ADC_START
                                     20 	.globl _S0_R_FIFO
                                     21 	.globl _S0_T_FIFO
                                     22 	.globl _S0_FREE
                                     23 	.globl _S0_IF_BYTE
                                     24 	.globl _S0_IF_FIRST
                                     25 	.globl _S0_IF_OV
                                     26 	.globl _S0_FST_ACT
                                     27 	.globl _CP_RL2
                                     28 	.globl _C_T2
                                     29 	.globl _TR2
                                     30 	.globl _EXEN2
                                     31 	.globl _TCLK
                                     32 	.globl _RCLK
                                     33 	.globl _EXF2
                                     34 	.globl _CAP1F
                                     35 	.globl _TF2
                                     36 	.globl _RI
                                     37 	.globl _TI
                                     38 	.globl _RB8
                                     39 	.globl _TB8
                                     40 	.globl _REN
                                     41 	.globl _SM2
                                     42 	.globl _SM1
                                     43 	.globl _SM0
                                     44 	.globl _IT0
                                     45 	.globl _IE0
                                     46 	.globl _IT1
                                     47 	.globl _IE1
                                     48 	.globl _TR0
                                     49 	.globl _TF0
                                     50 	.globl _TR1
                                     51 	.globl _TF1
                                     52 	.globl _P4_0
                                     53 	.globl _P4_1
                                     54 	.globl _P4_2
                                     55 	.globl _P4_3
                                     56 	.globl _P4_4
                                     57 	.globl _P4_5
                                     58 	.globl _P4_6
                                     59 	.globl _RXD
                                     60 	.globl _TXD
                                     61 	.globl _INT0
                                     62 	.globl _INT1
                                     63 	.globl _T0
                                     64 	.globl _T1
                                     65 	.globl _MOSI1
                                     66 	.globl _MISO1
                                     67 	.globl _SCK1
                                     68 	.globl _P3_0
                                     69 	.globl _P3_1
                                     70 	.globl _P3_2
                                     71 	.globl _P3_3
                                     72 	.globl _P3_4
                                     73 	.globl _P3_5
                                     74 	.globl _P3_6
                                     75 	.globl _P3_7
                                     76 	.globl _CAP1_
                                     77 	.globl _T2_
                                     78 	.globl _CAP2_
                                     79 	.globl _T2EX_
                                     80 	.globl _RXD1
                                     81 	.globl _TXD1
                                     82 	.globl _P2_0
                                     83 	.globl _P2_1
                                     84 	.globl _P2_2
                                     85 	.globl _P2_3
                                     86 	.globl _P2_4
                                     87 	.globl _P2_5
                                     88 	.globl _P2_6
                                     89 	.globl _P2_7
                                     90 	.globl _AIN0
                                     91 	.globl _AIN1
                                     92 	.globl _AIN2
                                     93 	.globl _AIN3
                                     94 	.globl _AIN4
                                     95 	.globl _AIN5
                                     96 	.globl _AIN6
                                     97 	.globl _AIN7
                                     98 	.globl _CAP1
                                     99 	.globl _T2
                                    100 	.globl _CAP2
                                    101 	.globl _T2EX
                                    102 	.globl _INT0_
                                    103 	.globl _SCS
                                    104 	.globl _MOSI
                                    105 	.globl _MISO
                                    106 	.globl _SCK
                                    107 	.globl _RXD1_
                                    108 	.globl _TXD1_
                                    109 	.globl _P1_0
                                    110 	.globl _P1_1
                                    111 	.globl _P1_2
                                    112 	.globl _P1_3
                                    113 	.globl _P1_4
                                    114 	.globl _P1_5
                                    115 	.globl _P1_6
                                    116 	.globl _P1_7
                                    117 	.globl _AIN8
                                    118 	.globl _AIN9
                                    119 	.globl _AIN10
                                    120 	.globl _AIN11
                                    121 	.globl _AIN12
                                    122 	.globl _AIN13
                                    123 	.globl _RXD_
                                    124 	.globl _TXD_
                                    125 	.globl _SCL0
                                    126 	.globl _SDA0
                                    127 	.globl _P0_0
                                    128 	.globl _P0_1
                                    129 	.globl _P0_2
                                    130 	.globl _P0_3
                                    131 	.globl _P0_4
                                    132 	.globl _P0_5
                                    133 	.globl _P0_6
                                    134 	.globl _P0_7
                                    135 	.globl _IE_SPI0
                                    136 	.globl _IE_USB
                                    137 	.globl _IE_ADC
                                    138 	.globl _IE_UART1
                                    139 	.globl _IE_PWM_I2C
                                    140 	.globl _IE_GPIO
                                    141 	.globl _IE_WDOG
                                    142 	.globl _PX0
                                    143 	.globl _PT0
                                    144 	.globl _PX1
                                    145 	.globl _PT1
                                    146 	.globl _PS
                                    147 	.globl _PT2
                                    148 	.globl _PL_FLAG
                                    149 	.globl _PH_FLAG
                                    150 	.globl _EX0
                                    151 	.globl _ET0
                                    152 	.globl _EX1
                                    153 	.globl _ET1
                                    154 	.globl _ES
                                    155 	.globl _ET2
                                    156 	.globl _E_DIS
                                    157 	.globl _EA
                                    158 	.globl _P
                                    159 	.globl _F1
                                    160 	.globl _OV
                                    161 	.globl _RS0
                                    162 	.globl _RS1
                                    163 	.globl _F0
                                    164 	.globl _AC
                                    165 	.globl _CY
                                    166 	.globl _I2CS_INT_ST
                                    167 	.globl _I2CX_INT
                                    168 	.globl _LED_STATUS
                                    169 	.globl _LED_DMA_H
                                    170 	.globl _LED_DMA_L
                                    171 	.globl _LED_DMA
                                    172 	.globl _LED_PWM_OE
                                    173 	.globl _LED_COMMON
                                    174 	.globl _ADC_CHAN
                                    175 	.globl _ADC_DAT_H
                                    176 	.globl _ADC_DAT_L
                                    177 	.globl _ADC_DAT
                                    178 	.globl _ADC_CTRL
                                    179 	.globl _SPI1_CK_SE
                                    180 	.globl _SPI1_CTRL
                                    181 	.globl _SPI1_DATA
                                    182 	.globl _SPI1_STAT
                                    183 	.globl _SIF1
                                    184 	.globl _SBAUD1
                                    185 	.globl _SBUF1
                                    186 	.globl _SCON1
                                    187 	.globl _SPI0_SETUP
                                    188 	.globl _SPI0_CK_SE
                                    189 	.globl _SPI0_CTRL
                                    190 	.globl _SPI0_DATA
                                    191 	.globl _SPI0_STAT
                                    192 	.globl _T2CAP1H
                                    193 	.globl _T2CAP1L
                                    194 	.globl _T2CAP1
                                    195 	.globl _TH2
                                    196 	.globl _TL2
                                    197 	.globl _T2COUNT
                                    198 	.globl _RCAP2H
                                    199 	.globl _RCAP2L
                                    200 	.globl _RCAP2
                                    201 	.globl _T2MOD
                                    202 	.globl _T2CON
                                    203 	.globl _SBUF
                                    204 	.globl _SCON
                                    205 	.globl _TH1
                                    206 	.globl _TH0
                                    207 	.globl _TL1
                                    208 	.globl _TL0
                                    209 	.globl _TMOD
                                    210 	.globl _TCON
                                    211 	.globl _XBUS_AUX
                                    212 	.globl _P7
                                    213 	.globl _P6_DIR
                                    214 	.globl _P6_OUT_PU
                                    215 	.globl _P6_IN
                                    216 	.globl _P5_DIR
                                    217 	.globl _P5_OUT_PU
                                    218 	.globl _P5_IN
                                    219 	.globl _P4_LED_KEY
                                    220 	.globl _P4_DIR_PU
                                    221 	.globl _P4_MOD_OC
                                    222 	.globl _P4
                                    223 	.globl _P3_DIR_PU
                                    224 	.globl _P3_MOD_OC
                                    225 	.globl _P3
                                    226 	.globl _P2_DIR_PU
                                    227 	.globl _P2_MOD_OC
                                    228 	.globl _P2
                                    229 	.globl _P1_DIR_PU
                                    230 	.globl _P1_MOD_OC
                                    231 	.globl _P1
                                    232 	.globl _P0_DIR_PU
                                    233 	.globl _P0_MOD_OC
                                    234 	.globl _P0
                                    235 	.globl _ROM_CTRL
                                    236 	.globl _ROM_DATA_HH
                                    237 	.globl _ROM_DATA_HL
                                    238 	.globl _ROM_DATA_HI
                                    239 	.globl _ROM_ADDR_H
                                    240 	.globl _ROM_ADDR_L
                                    241 	.globl _ROM_ADDR
                                    242 	.globl _GPIO_IE
                                    243 	.globl _IP_EX
                                    244 	.globl _IE_EX
                                    245 	.globl _IP
                                    246 	.globl _IE
                                    247 	.globl _WDOG_COUNT
                                    248 	.globl _RESET_KEEP
                                    249 	.globl _WAKE_CTRL
                                    250 	.globl _CLOCK_CFG
                                    251 	.globl _POWER_CFG
                                    252 	.globl _PCON
                                    253 	.globl _GLOBAL_CFG
                                    254 	.globl _SAFE_MOD
                                    255 	.globl _DPH
                                    256 	.globl _DPL
                                    257 	.globl _SP
                                    258 	.globl _A_INV
                                    259 	.globl _B
                                    260 	.globl _ACC
                                    261 	.globl _PSW
                                    262 	.globl _ak820_usb_raw_send_PARM_2
                                    263 	.globl _ak820_usb_try_send_PARM_3
                                    264 	.globl _ak820_usb_try_send_PARM_2
                                    265 	.globl _ak820_usb_send_PARM_3
                                    266 	.globl _ak820_usb_send_PARM_2
                                    267 	.globl _ak820_main_heartbeat
                                    268 	.globl _ak820_boot_stage
                                    269 	.globl _KB_USB_SetReport
                                    270 	.globl _KB_USB_UpStatus
                                    271 	.globl _MCU_Sleep_Operate
                                    272 	.globl _USB_SleepStatus
                                    273 	.globl _USB_EnumStatus
                                    274 	.globl _D0UsbConfig
                                    275 	.globl _pD0Descr
                                    276 	.globl _D0SetupLen
                                    277 	.globl _D0SetupReqCode
                                    278 	.globl _USB_DeviceInterrupt
                                    279 	.globl _USB_Device_Init
                                    280 	.globl _USB_WakeUp_PC
                                    281 	.globl _ak820_usb_send
                                    282 	.globl _ak820_usb_try_send
                                    283 	.globl _ak820_usb_raw_send
                                    284 	.globl _ak820_usb_raw_task
                                    285 	.globl _ak820_usb_take_keyboard_reset
                                    286 ;--------------------------------------------------------
                                    287 ; special function registers
                                    288 ;--------------------------------------------------------
                                    289 	.area RSEG    (ABS,DATA)
      000000                        290 	.org 0x0000
                           0000D0   291 _PSW	=	0x00d0
                           0000E0   292 _ACC	=	0x00e0
                           0000F0   293 _B	=	0x00f0
                           0000FD   294 _A_INV	=	0x00fd
                           000081   295 _SP	=	0x0081
                           000082   296 _DPL	=	0x0082
                           000083   297 _DPH	=	0x0083
                           0000A1   298 _SAFE_MOD	=	0x00a1
                           0000B1   299 _GLOBAL_CFG	=	0x00b1
                           000087   300 _PCON	=	0x0087
                           0000BA   301 _POWER_CFG	=	0x00ba
                           0000B9   302 _CLOCK_CFG	=	0x00b9
                           0000A9   303 _WAKE_CTRL	=	0x00a9
                           0000FE   304 _RESET_KEEP	=	0x00fe
                           0000FF   305 _WDOG_COUNT	=	0x00ff
                           0000A8   306 _IE	=	0x00a8
                           0000B8   307 _IP	=	0x00b8
                           0000E8   308 _IE_EX	=	0x00e8
                           0000E9   309 _IP_EX	=	0x00e9
                           0000B2   310 _GPIO_IE	=	0x00b2
                           008584   311 _ROM_ADDR	=	0x8584
                           000084   312 _ROM_ADDR_L	=	0x0084
                           000085   313 _ROM_ADDR_H	=	0x0085
                           008F8E   314 _ROM_DATA_HI	=	0x8f8e
                           00008E   315 _ROM_DATA_HL	=	0x008e
                           00008F   316 _ROM_DATA_HH	=	0x008f
                           000086   317 _ROM_CTRL	=	0x0086
                           000080   318 _P0	=	0x0080
                           0000C4   319 _P0_MOD_OC	=	0x00c4
                           0000C5   320 _P0_DIR_PU	=	0x00c5
                           000090   321 _P1	=	0x0090
                           000092   322 _P1_MOD_OC	=	0x0092
                           000093   323 _P1_DIR_PU	=	0x0093
                           0000A0   324 _P2	=	0x00a0
                           000094   325 _P2_MOD_OC	=	0x0094
                           000095   326 _P2_DIR_PU	=	0x0095
                           0000B0   327 _P3	=	0x00b0
                           000096   328 _P3_MOD_OC	=	0x0096
                           000097   329 _P3_DIR_PU	=	0x0097
                           0000C0   330 _P4	=	0x00c0
                           0000C2   331 _P4_MOD_OC	=	0x00c2
                           0000C3   332 _P4_DIR_PU	=	0x00c3
                           0000C1   333 _P4_LED_KEY	=	0x00c1
                           0000AA   334 _P5_IN	=	0x00aa
                           0000AB   335 _P5_OUT_PU	=	0x00ab
                           0000AC   336 _P5_DIR	=	0x00ac
                           0000AD   337 _P6_IN	=	0x00ad
                           0000AE   338 _P6_OUT_PU	=	0x00ae
                           0000AF   339 _P6_DIR	=	0x00af
                           0000F1   340 _P7	=	0x00f1
                           0000A2   341 _XBUS_AUX	=	0x00a2
                           000088   342 _TCON	=	0x0088
                           000089   343 _TMOD	=	0x0089
                           00008A   344 _TL0	=	0x008a
                           00008B   345 _TL1	=	0x008b
                           00008C   346 _TH0	=	0x008c
                           00008D   347 _TH1	=	0x008d
                           000098   348 _SCON	=	0x0098
                           000099   349 _SBUF	=	0x0099
                           0000C8   350 _T2CON	=	0x00c8
                           0000C9   351 _T2MOD	=	0x00c9
                           00CBCA   352 _RCAP2	=	0xcbca
                           0000CA   353 _RCAP2L	=	0x00ca
                           0000CB   354 _RCAP2H	=	0x00cb
                           00CDCC   355 _T2COUNT	=	0xcdcc
                           0000CC   356 _TL2	=	0x00cc
                           0000CD   357 _TH2	=	0x00cd
                           00CFCE   358 _T2CAP1	=	0xcfce
                           0000CE   359 _T2CAP1L	=	0x00ce
                           0000CF   360 _T2CAP1H	=	0x00cf
                           0000F8   361 _SPI0_STAT	=	0x00f8
                           0000F9   362 _SPI0_DATA	=	0x00f9
                           0000FA   363 _SPI0_CTRL	=	0x00fa
                           0000FB   364 _SPI0_CK_SE	=	0x00fb
                           0000FC   365 _SPI0_SETUP	=	0x00fc
                           0000BC   366 _SCON1	=	0x00bc
                           0000BD   367 _SBUF1	=	0x00bd
                           0000BE   368 _SBAUD1	=	0x00be
                           0000BF   369 _SIF1	=	0x00bf
                           0000B4   370 _SPI1_STAT	=	0x00b4
                           0000B5   371 _SPI1_DATA	=	0x00b5
                           0000B6   372 _SPI1_CTRL	=	0x00b6
                           0000B7   373 _SPI1_CK_SE	=	0x00b7
                           0000F3   374 _ADC_CTRL	=	0x00f3
                           00F5F4   375 _ADC_DAT	=	0xf5f4
                           0000F4   376 _ADC_DAT_L	=	0x00f4
                           0000F5   377 _ADC_DAT_H	=	0x00f5
                           0000F6   378 _ADC_CHAN	=	0x00f6
                           0000A6   379 _LED_COMMON	=	0x00a6
                           0000A7   380 _LED_PWM_OE	=	0x00a7
                           00C7C6   381 _LED_DMA	=	0xc7c6
                           0000C6   382 _LED_DMA_L	=	0x00c6
                           0000C7   383 _LED_DMA_H	=	0x00c7
                           0000F7   384 _LED_STATUS	=	0x00f7
                           0000B3   385 _I2CX_INT	=	0x00b3
                           0000BB   386 _I2CS_INT_ST	=	0x00bb
                                    387 ;--------------------------------------------------------
                                    388 ; special function bits
                                    389 ;--------------------------------------------------------
                                    390 	.area RSEG    (ABS,DATA)
      000000                        391 	.org 0x0000
                           0000D7   392 _CY	=	0x00d7
                           0000D6   393 _AC	=	0x00d6
                           0000D5   394 _F0	=	0x00d5
                           0000D4   395 _RS1	=	0x00d4
                           0000D3   396 _RS0	=	0x00d3
                           0000D2   397 _OV	=	0x00d2
                           0000D1   398 _F1	=	0x00d1
                           0000D0   399 _P	=	0x00d0
                           0000AF   400 _EA	=	0x00af
                           0000AE   401 _E_DIS	=	0x00ae
                           0000AD   402 _ET2	=	0x00ad
                           0000AC   403 _ES	=	0x00ac
                           0000AB   404 _ET1	=	0x00ab
                           0000AA   405 _EX1	=	0x00aa
                           0000A9   406 _ET0	=	0x00a9
                           0000A8   407 _EX0	=	0x00a8
                           0000BF   408 _PH_FLAG	=	0x00bf
                           0000BE   409 _PL_FLAG	=	0x00be
                           0000BD   410 _PT2	=	0x00bd
                           0000BC   411 _PS	=	0x00bc
                           0000BB   412 _PT1	=	0x00bb
                           0000BA   413 _PX1	=	0x00ba
                           0000B9   414 _PT0	=	0x00b9
                           0000B8   415 _PX0	=	0x00b8
                           0000EF   416 _IE_WDOG	=	0x00ef
                           0000EE   417 _IE_GPIO	=	0x00ee
                           0000ED   418 _IE_PWM_I2C	=	0x00ed
                           0000EC   419 _IE_UART1	=	0x00ec
                           0000EB   420 _IE_ADC	=	0x00eb
                           0000E9   421 _IE_USB	=	0x00e9
                           0000E8   422 _IE_SPI0	=	0x00e8
                           000087   423 _P0_7	=	0x0087
                           000086   424 _P0_6	=	0x0086
                           000085   425 _P0_5	=	0x0085
                           000084   426 _P0_4	=	0x0084
                           000083   427 _P0_3	=	0x0083
                           000082   428 _P0_2	=	0x0082
                           000081   429 _P0_1	=	0x0081
                           000080   430 _P0_0	=	0x0080
                           000081   431 _SDA0	=	0x0081
                           000080   432 _SCL0	=	0x0080
                           000083   433 _TXD_	=	0x0083
                           000082   434 _RXD_	=	0x0082
                           000085   435 _AIN13	=	0x0085
                           000084   436 _AIN12	=	0x0084
                           000083   437 _AIN11	=	0x0083
                           000082   438 _AIN10	=	0x0082
                           000081   439 _AIN9	=	0x0081
                           000080   440 _AIN8	=	0x0080
                           000097   441 _P1_7	=	0x0097
                           000096   442 _P1_6	=	0x0096
                           000095   443 _P1_5	=	0x0095
                           000094   444 _P1_4	=	0x0094
                           000093   445 _P1_3	=	0x0093
                           000092   446 _P1_2	=	0x0092
                           000091   447 _P1_1	=	0x0091
                           000090   448 _P1_0	=	0x0090
                           000097   449 _TXD1_	=	0x0097
                           000096   450 _RXD1_	=	0x0096
                           000097   451 _SCK	=	0x0097
                           000096   452 _MISO	=	0x0096
                           000095   453 _MOSI	=	0x0095
                           000094   454 _SCS	=	0x0094
                           000092   455 _INT0_	=	0x0092
                           000091   456 _T2EX	=	0x0091
                           000091   457 _CAP2	=	0x0091
                           000090   458 _T2	=	0x0090
                           000090   459 _CAP1	=	0x0090
                           000097   460 _AIN7	=	0x0097
                           000096   461 _AIN6	=	0x0096
                           000095   462 _AIN5	=	0x0095
                           000094   463 _AIN4	=	0x0094
                           000093   464 _AIN3	=	0x0093
                           000092   465 _AIN2	=	0x0092
                           000091   466 _AIN1	=	0x0091
                           000090   467 _AIN0	=	0x0090
                           0000A7   468 _P2_7	=	0x00a7
                           0000A6   469 _P2_6	=	0x00a6
                           0000A5   470 _P2_5	=	0x00a5
                           0000A4   471 _P2_4	=	0x00a4
                           0000A3   472 _P2_3	=	0x00a3
                           0000A2   473 _P2_2	=	0x00a2
                           0000A1   474 _P2_1	=	0x00a1
                           0000A0   475 _P2_0	=	0x00a0
                           0000A7   476 _TXD1	=	0x00a7
                           0000A6   477 _RXD1	=	0x00a6
                           0000A5   478 _T2EX_	=	0x00a5
                           0000A5   479 _CAP2_	=	0x00a5
                           0000A4   480 _T2_	=	0x00a4
                           0000A4   481 _CAP1_	=	0x00a4
                           0000B7   482 _P3_7	=	0x00b7
                           0000B6   483 _P3_6	=	0x00b6
                           0000B5   484 _P3_5	=	0x00b5
                           0000B4   485 _P3_4	=	0x00b4
                           0000B3   486 _P3_3	=	0x00b3
                           0000B2   487 _P3_2	=	0x00b2
                           0000B1   488 _P3_1	=	0x00b1
                           0000B0   489 _P3_0	=	0x00b0
                           0000B7   490 _SCK1	=	0x00b7
                           0000B6   491 _MISO1	=	0x00b6
                           0000B5   492 _MOSI1	=	0x00b5
                           0000B5   493 _T1	=	0x00b5
                           0000B4   494 _T0	=	0x00b4
                           0000B3   495 _INT1	=	0x00b3
                           0000B2   496 _INT0	=	0x00b2
                           0000B1   497 _TXD	=	0x00b1
                           0000B0   498 _RXD	=	0x00b0
                           0000C6   499 _P4_6	=	0x00c6
                           0000C5   500 _P4_5	=	0x00c5
                           0000C4   501 _P4_4	=	0x00c4
                           0000C3   502 _P4_3	=	0x00c3
                           0000C2   503 _P4_2	=	0x00c2
                           0000C1   504 _P4_1	=	0x00c1
                           0000C0   505 _P4_0	=	0x00c0
                           00008F   506 _TF1	=	0x008f
                           00008E   507 _TR1	=	0x008e
                           00008D   508 _TF0	=	0x008d
                           00008C   509 _TR0	=	0x008c
                           00008B   510 _IE1	=	0x008b
                           00008A   511 _IT1	=	0x008a
                           000089   512 _IE0	=	0x0089
                           000088   513 _IT0	=	0x0088
                           00009F   514 _SM0	=	0x009f
                           00009E   515 _SM1	=	0x009e
                           00009D   516 _SM2	=	0x009d
                           00009C   517 _REN	=	0x009c
                           00009B   518 _TB8	=	0x009b
                           00009A   519 _RB8	=	0x009a
                           000099   520 _TI	=	0x0099
                           000098   521 _RI	=	0x0098
                           0000CF   522 _TF2	=	0x00cf
                           0000CF   523 _CAP1F	=	0x00cf
                           0000CE   524 _EXF2	=	0x00ce
                           0000CD   525 _RCLK	=	0x00cd
                           0000CC   526 _TCLK	=	0x00cc
                           0000CB   527 _EXEN2	=	0x00cb
                           0000CA   528 _TR2	=	0x00ca
                           0000C9   529 _C_T2	=	0x00c9
                           0000C8   530 _CP_RL2	=	0x00c8
                           0000FF   531 _S0_FST_ACT	=	0x00ff
                           0000FE   532 _S0_IF_OV	=	0x00fe
                           0000FD   533 _S0_IF_FIRST	=	0x00fd
                           0000FC   534 _S0_IF_BYTE	=	0x00fc
                           0000FB   535 _S0_FREE	=	0x00fb
                           0000FA   536 _S0_T_FIFO	=	0x00fa
                           0000F8   537 _S0_R_FIFO	=	0x00f8
                           0000F7   538 _ADC_START	=	0x00f7
                                    539 ;--------------------------------------------------------
                                    540 ; overlayable register banks
                                    541 ;--------------------------------------------------------
                                    542 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        543 	.ds 8
                                    544 ;--------------------------------------------------------
                                    545 ; internal ram data
                                    546 ;--------------------------------------------------------
                                    547 	.area DSEG    (DATA)
      000016                        548 _control_setup_sloc1_1_0:
      000016                        549 	.ds 1
      000017                        550 _control_setup_sloc3_1_0:
      000017                        551 	.ds 2
      000019                        552 _control_setup_sloc4_1_0:
      000019                        553 	.ds 2
      00001B                        554 _ak820_usb_send_sloc0_1_0:
      00001B                        555 	.ds 2
      00001D                        556 _ak820_usb_send_sloc1_1_0:
      00001D                        557 	.ds 1
      00001E                        558 _ak820_usb_raw_task_sloc0_1_0:
      00001E                        559 	.ds 2
                                    560 ;--------------------------------------------------------
                                    561 ; overlayable items in internal ram
                                    562 ;--------------------------------------------------------
                                    563 ;--------------------------------------------------------
                                    564 ; indirectly addressable internal ram data
                                    565 ;--------------------------------------------------------
                                    566 	.area ISEG    (DATA)
                                    567 ;--------------------------------------------------------
                                    568 ; absolute internal ram data
                                    569 ;--------------------------------------------------------
                                    570 	.area IABS    (ABS,DATA)
                                    571 	.area IABS    (ABS,DATA)
                                    572 ;--------------------------------------------------------
                                    573 ; bit data
                                    574 ;--------------------------------------------------------
                                    575 	.area BSEG    (BIT)
      000016                        576 _control_setup_valid_interface_10000_286:
      000016                        577 	.ds 1
      000017                        578 _control_setup_zero_index_10000_286:
      000017                        579 	.ds 1
      000018                        580 _control_setup_zero_value_10000_286:
      000018                        581 	.ds 1
      000019                        582 _control_setup_zero_length_10000_286:
      000019                        583 	.ds 1
      00001A                        584 _control_setup_sloc0_1_0:
      00001A                        585 	.ds 1
      00001B                        586 _control_setup_sloc2_1_0:
      00001B                        587 	.ds 1
      00001C                        588 _ak820_usb_try_send_sloc0_1_0:
      00001C                        589 	.ds 1
      00001D                        590 _ak820_usb_raw_task_sloc1_1_0:
      00001D                        591 	.ds 1
      00001E                        592 _ak820_usb_take_keyboard_reset_sloc0_1_0:
      00001E                        593 	.ds 1
                                    594 ;--------------------------------------------------------
                                    595 ; paged external ram data
                                    596 ;--------------------------------------------------------
                                    597 	.area PSEG    (PAG,XDATA)
                                    598 ;--------------------------------------------------------
                                    599 ; uninitialized external ram data
                                    600 ;--------------------------------------------------------
                                    601 	.area XSEG    (XDATA)
      00075C                        602 _D0SetupReqCode::
      00075C                        603 	.ds 1
      00075D                        604 _D0SetupLen::
      00075D                        605 	.ds 2
      00075F                        606 _pD0Descr::
      00075F                        607 	.ds 3
      000762                        608 _D0UsbConfig::
      000762                        609 	.ds 1
      000763                        610 _USB_EnumStatus::
      000763                        611 	.ds 1
      000764                        612 _USB_SleepStatus::
      000764                        613 	.ds 1
      000765                        614 _MCU_Sleep_Operate::
      000765                        615 	.ds 1
      000766                        616 _KB_USB_UpStatus::
      000766                        617 	.ds 1
      000767                        618 _KB_USB_SetReport::
      000767                        619 	.ds 1
      000768                        620 _ak820_boot_stage::
      000768                        621 	.ds 1
      000769                        622 _ak820_main_heartbeat::
      000769                        623 	.ds 1
      00076A                        624 _raw_state:
      00076A                        625 	.ds 1
      00076B                        626 _raw_buffer:
      00076B                        627 	.ds 32
      00078B                        628 _raw_reply_without_nvm:
      00078B                        629 	.ds 1
      00078C                        630 _keyboard_reset:
      00078C                        631 	.ds 1
      00078D                        632 _input_snapshot:
      00078D                        633 	.ds 46
      0007BB                        634 _control_phase:
      0007BB                        635 	.ds 1
      0007BC                        636 _output_kind:
      0007BC                        637 	.ds 1
      0007BD                        638 _output_report_id:
      0007BD                        639 	.ds 1
      0007BE                        640 _control_zlp:
      0007BE                        641 	.ds 1
      0007BF                        642 _control_pointer:
      0007BF                        643 	.ds 2
      0007C1                        644 _descriptor_select_PARM_2:
      0007C1                        645 	.ds 1
      0007C2                        646 _descriptor_select_PARM_3:
      0007C2                        647 	.ds 2
      0007C4                        648 _descriptor_select_type_10000_268:
      0007C4                        649 	.ds 1
      0007C5                        650 _control_setup_length_10000_286:
      0007C5                        651 	.ds 2
      0007C7                        652 _control_setup_offset_10000_286:
      0007C7                        653 	.ds 1
      0007C8                        654 _ak820_usb_send_PARM_2:
      0007C8                        655 	.ds 2
      0007CA                        656 _ak820_usb_send_PARM_3:
      0007CA                        657 	.ds 1
      0007CB                        658 _ak820_usb_send_endpoint_10000_422:
      0007CB                        659 	.ds 1
      0007CC                        660 _ak820_usb_send_offset_10000_423:
      0007CC                        661 	.ds 1
      0007CD                        662 _ak820_usb_try_send_PARM_2:
      0007CD                        663 	.ds 2
      0007CF                        664 _ak820_usb_try_send_PARM_3:
      0007CF                        665 	.ds 1
      0007D0                        666 _ak820_usb_try_send_endpoint_10000_443:
      0007D0                        667 	.ds 1
      0007D1                        668 _ak820_usb_try_send_sent_10000_444:
      0007D1                        669 	.ds 1
      0007D2                        670 _ak820_usb_raw_send_PARM_2:
      0007D2                        671 	.ds 1
      0007D3                        672 _ak820_usb_raw_send_report_10000_459:
      0007D3                        673 	.ds 3
                                    674 ;--------------------------------------------------------
                                    675 ; absolute external ram data
                                    676 ;--------------------------------------------------------
                                    677 	.area XABS    (ABS,XDATA)
                                    678 ;--------------------------------------------------------
                                    679 ; initialized external ram data
                                    680 ;--------------------------------------------------------
                                    681 	.area XISEG   (XDATA)
                                    682 	.area HOME    (CODE)
                                    683 	.area GSINIT0 (CODE)
                                    684 	.area GSINIT1 (CODE)
                                    685 	.area GSINIT2 (CODE)
                                    686 	.area GSINIT3 (CODE)
                                    687 	.area GSINIT4 (CODE)
                                    688 	.area GSINIT5 (CODE)
                                    689 	.area GSINIT  (CODE)
                                    690 	.area GSFINAL (CODE)
                                    691 	.area CSEG    (CODE)
                                    692 ;--------------------------------------------------------
                                    693 ; global & static initialisations
                                    694 ;--------------------------------------------------------
                                    695 	.area HOME    (CODE)
                                    696 	.area GSINIT  (CODE)
                                    697 	.area GSFINAL (CODE)
                                    698 	.area GSINIT  (CODE)
                                    699 ;--------------------------------------------------------
                                    700 ; Home
                                    701 ;--------------------------------------------------------
                                    702 	.area HOME    (CODE)
                                    703 	.area HOME    (CODE)
                                    704 ;--------------------------------------------------------
                                    705 ; code
                                    706 ;--------------------------------------------------------
                                    707 	.area CSEG    (CODE)
                                    708 ;------------------------------------------------------------
                                    709 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    710 ;------------------------------------------------------------
                                    711 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_45'
                                    712 ;------------------------------------------------------------
                                    713 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    714 ;	-----------------------------------------
                           000007   715 	ar7 = 0x07
                           000006   716 	ar6 = 0x06
                           000005   717 	ar5 = 0x05
                           000004   718 	ar4 = 0x04
                           000003   719 	ar3 = 0x03
                           000002   720 	ar2 = 0x02
                           000001   721 	ar1 = 0x01
                           000000   722 	ar0 = 0x00
                                    723 ;	 function raw_abort
                                    724 ;	-----------------------------------------
      0058CC                        725 _raw_abort:
                                    726 ;	tmk_core/protocol/ch555/usb_ak820.c:94: if (raw_state == RAW_WORK || raw_state == RAW_TX_ACTIVE ||
      0058CC 90 07 6A         [24]  727 	mov	dptr,#_raw_state
      0058CF E0               [24]  728 	movx	a,@dptr
      0058D0 FF               [12]  729 	mov	r7,a
      0058D1 BF 03 02         [24]  730 	cjne	r7,#0x03,00130$
      0058D4 80 1C            [24]  731 	sjmp	00101$
      0058D6                        732 00130$:
      0058D6 90 07 6A         [24]  733 	mov	dptr,#_raw_state
      0058D9 E0               [24]  734 	movx	a,@dptr
      0058DA FF               [12]  735 	mov	r7,a
      0058DB BF 04 02         [24]  736 	cjne	r7,#0x04,00131$
      0058DE 80 12            [24]  737 	sjmp	00101$
      0058E0                        738 00131$:
                                    739 ;	tmk_core/protocol/ch555/usb_ak820.c:95: raw_state == RAW_DRAINED || raw_state == RAW_CANCELLED)
      0058E0 90 07 6A         [24]  740 	mov	dptr,#_raw_state
      0058E3 E0               [24]  741 	movx	a,@dptr
      0058E4 FF               [12]  742 	mov	r7,a
      0058E5 BF 06 02         [24]  743 	cjne	r7,#0x06,00132$
      0058E8 80 08            [24]  744 	sjmp	00101$
      0058EA                        745 00132$:
      0058EA 90 07 6A         [24]  746 	mov	dptr,#_raw_state
      0058ED E0               [24]  747 	movx	a,@dptr
      0058EE FF               [12]  748 	mov	r7,a
      0058EF BF 07 08         [24]  749 	cjne	r7,#0x07,00102$
      0058F2                        750 00101$:
                                    751 ;	tmk_core/protocol/ch555/usb_ak820.c:96: raw_state = RAW_CANCELLED;
      0058F2 90 07 6A         [24]  752 	mov	dptr,#_raw_state
      0058F5 74 07            [12]  753 	mov	a,#0x07
      0058F7 F0               [24]  754 	movx	@dptr,a
      0058F8 80 05            [24]  755 	sjmp	00103$
      0058FA                        756 00102$:
                                    757 ;	tmk_core/protocol/ch555/usb_ak820.c:98: raw_state = RAW_IDLE;
      0058FA 90 07 6A         [24]  758 	mov	dptr,#_raw_state
      0058FD E4               [12]  759 	clr	a
      0058FE F0               [24]  760 	movx	@dptr,a
      0058FF                        761 00103$:
                                    762 ;	tmk_core/protocol/ch555/usb_ak820.c:99: output_kind = OUTPUT_NONE;
      0058FF 90 07 BC         [24]  763 	mov	dptr,#_output_kind
      005902 E4               [12]  764 	clr	a
      005903 F0               [24]  765 	movx	@dptr,a
                                    766 ;	tmk_core/protocol/ch555/usb_ak820.c:100: }
      005904 22               [24]  767 	ret
                                    768 ;------------------------------------------------------------
                                    769 ;Allocation info for local variables in function 'raw_complete'
                                    770 ;------------------------------------------------------------
                                    771 ;	tmk_core/protocol/ch555/usb_ak820.c:102: static void raw_complete(void) {
                                    772 ;	-----------------------------------------
                                    773 ;	 function raw_complete
                                    774 ;	-----------------------------------------
      005905                        775 _raw_complete:
                                    776 ;	tmk_core/protocol/ch555/usb_ak820.c:103: if (raw_state == RAW_TX_ACTIVE) raw_state = RAW_DRAINED;
      005905 90 07 6A         [24]  777 	mov	dptr,#_raw_state
      005908 E0               [24]  778 	movx	a,@dptr
      005909 FF               [12]  779 	mov	r7,a
      00590A BF 04 07         [24]  780 	cjne	r7,#0x04,00104$
      00590D 90 07 6A         [24]  781 	mov	dptr,#_raw_state
      005910 74 06            [12]  782 	mov	a,#0x06
      005912 F0               [24]  783 	movx	@dptr,a
      005913 22               [24]  784 	ret
      005914                        785 00104$:
                                    786 ;	tmk_core/protocol/ch555/usb_ak820.c:104: else if (raw_state == RAW_TX_WAIT) raw_state = RAW_IDLE;
      005914 90 07 6A         [24]  787 	mov	dptr,#_raw_state
      005917 E0               [24]  788 	movx	a,@dptr
      005918 FF               [12]  789 	mov	r7,a
      005919 BF 05 05         [24]  790 	cjne	r7,#0x05,00106$
      00591C 90 07 6A         [24]  791 	mov	dptr,#_raw_state
      00591F E4               [12]  792 	clr	a
      005920 F0               [24]  793 	movx	@dptr,a
      005921                        794 00106$:
                                    795 ;	tmk_core/protocol/ch555/usb_ak820.c:105: }
      005921 22               [24]  796 	ret
                                    797 ;------------------------------------------------------------
                                    798 ;Allocation info for local variables in function 'endpoints_reset'
                                    799 ;------------------------------------------------------------
                                    800 ;i             Allocated with name '_endpoints_reset_i_10000_258'
                                    801 ;------------------------------------------------------------
                                    802 ;	tmk_core/protocol/ch555/usb_ak820.c:107: static void endpoints_reset(void) {
                                    803 ;	-----------------------------------------
                                    804 ;	 function endpoints_reset
                                    805 ;	-----------------------------------------
      005922                        806 _endpoints_reset:
                                    807 ;	tmk_core/protocol/ch555/usb_ak820.c:110: D0_EP_MOD = bUX_DEV_EN;
      005922 90 22 0C         [24]  808 	mov	dptr,#0x220c
      005925 74 01            [12]  809 	mov	a,#0x01
      005927 F0               [24]  810 	movx	@dptr,a
                                    811 ;	tmk_core/protocol/ch555/usb_ak820.c:111: D0_EP1RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      005928 F5 82            [12]  812 	mov	dpl,a
      00592A 74 12            [12]  813 	mov	a,#0x12
      00592C F0               [24]  814 	movx	@dptr,a
                                    815 ;	tmk_core/protocol/ch555/usb_ak820.c:112: D0_EP2RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      00592D A3               [24]  816 	inc	dptr
      00592E F0               [24]  817 	movx	@dptr,a
                                    818 ;	tmk_core/protocol/ch555/usb_ak820.c:113: D0_EP3RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      00592F A3               [24]  819 	inc	dptr
      005930 F0               [24]  820 	movx	@dptr,a
                                    821 ;	tmk_core/protocol/ch555/usb_ak820.c:114: D0_EP1T_L = D0_EP2T_L = D0_EP3T_L = 0;
      005931 90 22 0B         [24]  822 	mov	dptr,#0x220b
      005934 E4               [12]  823 	clr	a
      005935 F0               [24]  824 	movx	@dptr,a
      005936 15 82            [12]  825 	dec	dpl
      005938 F0               [24]  826 	movx	@dptr,a
      005939 15 82            [12]  827 	dec	dpl
      00593B F0               [24]  828 	movx	@dptr,a
                                    829 ;	tmk_core/protocol/ch555/usb_ak820.c:115: for (i = 0; i < SNAPSHOT_SIZE; ++i) input_snapshot[i] = 0;
      00593C FF               [12]  830 	mov	r7,a
      00593D                        831 00103$:
      00593D EF               [12]  832 	mov	a,r7
      00593E 24 8D            [12]  833 	add	a, #_input_snapshot
      005940 F5 82            [12]  834 	mov	dpl,a
      005942 E4               [12]  835 	clr	a
      005943 34 07            [12]  836 	addc	a, #(_input_snapshot >> 8)
      005945 F5 83            [12]  837 	mov	dph,a
      005947 E4               [12]  838 	clr	a
      005948 F0               [24]  839 	movx	@dptr,a
      005949 0F               [12]  840 	inc	r7
      00594A BF 2E 00         [24]  841 	cjne	r7,#0x2e,00139$
      00594D                        842 00139$:
      00594D 40 EE            [24]  843 	jc	00103$
                                    844 ;	tmk_core/protocol/ch555/usb_ak820.c:116: input_snapshot[SNAPSHOT_NKRO] = REPORT_ID_NKRO;
      00594F 90 07 95         [24]  845 	mov	dptr,#(_input_snapshot + 0x0008)
      005952 74 06            [12]  846 	mov	a,#0x06
      005954 F0               [24]  847 	movx	@dptr,a
                                    848 ;	tmk_core/protocol/ch555/usb_ak820.c:120: input_snapshot[SNAPSHOT_SYSTEM] = REPORT_ID_SYSTEM;
      005955 90 07 B5         [24]  849 	mov	dptr,#(_input_snapshot + 0x0028)
      005958 03               [12]  850 	rr	a
      005959 F0               [24]  851 	movx	@dptr,a
                                    852 ;	tmk_core/protocol/ch555/usb_ak820.c:121: input_snapshot[SNAPSHOT_CONSUMER] = REPORT_ID_CONSUMER;
      00595A 90 07 B8         [24]  853 	mov	dptr,#(_input_snapshot + 0x002b)
      00595D 04               [12]  854 	inc	a
      00595E F0               [24]  855 	movx	@dptr,a
                                    856 ;	tmk_core/protocol/ch555/usb_ak820.c:122: for (i = 0; i < RAW_EPSIZE; ++i) pUSB_BUF_DEV0[UX_EP3_ADDR + i] = 0;
      00595F 7F 00            [12]  857 	mov	r7,#0x00
      005961                        858 00105$:
      005961 8F 06            [24]  859 	mov	ar6,r7
      005963 74 C0            [12]  860 	mov	a,#0xc0
      005965 2E               [12]  861 	add	a, r6
      005966 F5 82            [12]  862 	mov	dpl,a
      005968 74 10            [12]  863 	mov	a,#0x10
      00596A 24 00            [12]  864 	add	a, #0x00
      00596C F5 83            [12]  865 	mov	dph,a
      00596E E4               [12]  866 	clr	a
      00596F F0               [24]  867 	movx	@dptr,a
      005970 0F               [12]  868 	inc	r7
      005971 BF 20 00         [24]  869 	cjne	r7,#0x20,00141$
      005974                        870 00141$:
      005974 40 EB            [24]  871 	jc	00105$
                                    872 ;	tmk_core/protocol/ch555/usb_ak820.c:123: raw_abort();
                                    873 ;	tmk_core/protocol/ch555/usb_ak820.c:124: }
      005976 02 58 CC         [24]  874 	ljmp	_raw_abort
                                    875 ;------------------------------------------------------------
                                    876 ;Allocation info for local variables in function 'control_stall'
                                    877 ;------------------------------------------------------------
                                    878 ;	tmk_core/protocol/ch555/usb_ak820.c:126: static void control_stall(void) {
                                    879 ;	-----------------------------------------
                                    880 ;	 function control_stall
                                    881 ;	-----------------------------------------
      005979                        882 _control_stall:
                                    883 ;	tmk_core/protocol/ch555/usb_ak820.c:127: if (raw_state == RAW_RX) raw_state = RAW_IDLE;
      005979 90 07 6A         [24]  884 	mov	dptr,#_raw_state
      00597C E0               [24]  885 	movx	a,@dptr
      00597D FF               [12]  886 	mov	r7,a
      00597E BF 01 05         [24]  887 	cjne	r7,#0x01,00102$
      005981 90 07 6A         [24]  888 	mov	dptr,#_raw_state
      005984 E4               [12]  889 	clr	a
      005985 F0               [24]  890 	movx	@dptr,a
      005986                        891 00102$:
                                    892 ;	tmk_core/protocol/ch555/usb_ak820.c:128: output_kind = OUTPUT_NONE;
      005986 90 07 BC         [24]  893 	mov	dptr,#_output_kind
      005989 E4               [12]  894 	clr	a
      00598A F0               [24]  895 	movx	@dptr,a
                                    896 ;	tmk_core/protocol/ch555/usb_ak820.c:129: control_phase = CTRL_IDLE;
      00598B 90 07 BB         [24]  897 	mov	dptr,#_control_phase
      00598E F0               [24]  898 	movx	@dptr,a
                                    899 ;	tmk_core/protocol/ch555/usb_ak820.c:130: D0SetupReqCode = 0xff;
      00598F 90 07 5C         [24]  900 	mov	dptr,#_D0SetupReqCode
      005992 14               [12]  901 	dec	a
      005993 F0               [24]  902 	movx	@dptr,a
                                    903 ;	tmk_core/protocol/ch555/usb_ak820.c:132: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_STALL | UEP_T_RES_STALL;
      005994 90 22 00         [24]  904 	mov	dptr,#0x2200
      005997 74 CF            [12]  905 	mov	a,#0xcf
      005999 F0               [24]  906 	movx	@dptr,a
                                    907 ;	tmk_core/protocol/ch555/usb_ak820.c:133: }
      00599A 22               [24]  908 	ret
                                    909 ;------------------------------------------------------------
                                    910 ;Allocation info for local variables in function 'control_next'
                                    911 ;------------------------------------------------------------
                                    912 ;i             Allocated with name '_control_next_i_10000_265'
                                    913 ;length        Allocated with name '_control_next_length_10000_265'
                                    914 ;------------------------------------------------------------
                                    915 ;	tmk_core/protocol/ch555/usb_ak820.c:135: static void control_next(void) {
                                    916 ;	-----------------------------------------
                                    917 ;	 function control_next
                                    918 ;	-----------------------------------------
      00599B                        919 _control_next:
                                    920 ;	tmk_core/protocol/ch555/usb_ak820.c:137: uint8_t length = D0SetupLen > DEF_ENDP0_SIZE ? DEF_ENDP0_SIZE : D0SetupLen;
      00599B 90 07 5D         [24]  921 	mov	dptr,#_D0SetupLen
      00599E E0               [24]  922 	movx	a,@dptr
      00599F FE               [12]  923 	mov	r6,a
      0059A0 A3               [24]  924 	inc	dptr
      0059A1 E0               [24]  925 	movx	a,@dptr
      0059A2 FF               [12]  926 	mov	r7,a
      0059A3 C3               [12]  927 	clr	c
      0059A4 74 40            [12]  928 	mov	a,#0x40
      0059A6 9E               [12]  929 	subb	a,r6
      0059A7 E4               [12]  930 	clr	a
      0059A8 9F               [12]  931 	subb	a,r7
      0059A9 50 04            [24]  932 	jnc	00109$
                                    933 ;	free result
      0059AB 7E 40            [12]  934 	mov	r6,#0x40
      0059AD 80 07            [24]  935 	sjmp	00110$
      0059AF                        936 00109$:
      0059AF 90 07 5D         [24]  937 	mov	dptr,#_D0SetupLen
      0059B2 E0               [24]  938 	movx	a,@dptr
      0059B3 FE               [12]  939 	mov	r6,a
      0059B4 A3               [24]  940 	inc	dptr
      0059B5 E0               [24]  941 	movx	a,@dptr
      0059B6                        942 00110$:
                                    943 ;	tmk_core/protocol/ch555/usb_ak820.c:138: for (i = 0; i < length; ++i) pD0_EP0_BUF[i] = *control_pointer++;
      0059B6 7F 00            [12]  944 	mov	r7,#0x00
      0059B8                        945 00105$:
      0059B8 C3               [12]  946 	clr	c
      0059B9 EF               [12]  947 	mov	a,r7
      0059BA 9E               [12]  948 	subb	a,r6
      0059BB 50 2A            [24]  949 	jnc	00101$
      0059BD 8F 04            [24]  950 	mov	ar4,r7
      0059BF 74 10            [12]  951 	mov	a,#0x10
      0059C1 24 00            [12]  952 	add	a, #0x00
      0059C3 FD               [12]  953 	mov	r5,a
      0059C4 90 07 BF         [24]  954 	mov	dptr,#_control_pointer
      0059C7 E0               [24]  955 	movx	a,@dptr
      0059C8 FA               [12]  956 	mov	r2,a
      0059C9 A3               [24]  957 	inc	dptr
      0059CA E0               [24]  958 	movx	a,@dptr
      0059CB FB               [12]  959 	mov	r3,a
      0059CC 8A 82            [24]  960 	mov	dpl,r2
      0059CE 8B 83            [24]  961 	mov	dph,r3
      0059D0 E4               [12]  962 	clr	a
      0059D1 93               [24]  963 	movc	a,@a+dptr
      0059D2 F9               [12]  964 	mov	r1,a
      0059D3 90 07 BF         [24]  965 	mov	dptr,#_control_pointer
      0059D6 74 01            [12]  966 	mov	a,#0x01
      0059D8 2A               [12]  967 	add	a, r2
      0059D9 F0               [24]  968 	movx	@dptr,a
      0059DA E4               [12]  969 	clr	a
      0059DB 3B               [12]  970 	addc	a, r3
      0059DC A3               [24]  971 	inc	dptr
      0059DD F0               [24]  972 	movx	@dptr,a
      0059DE 8C 82            [24]  973 	mov	dpl,r4
      0059E0 8D 83            [24]  974 	mov	dph,r5
      0059E2 E9               [12]  975 	mov	a,r1
      0059E3 F0               [24]  976 	movx	@dptr,a
      0059E4 0F               [12]  977 	inc	r7
      0059E5 80 D1            [24]  978 	sjmp	00105$
      0059E7                        979 00101$:
                                    980 ;	tmk_core/protocol/ch555/usb_ak820.c:139: D0SetupLen -= length;
      0059E7 8E 05            [24]  981 	mov	ar5,r6
      0059E9 7F 00            [12]  982 	mov	r7,#0x00
      0059EB 90 07 5D         [24]  983 	mov	dptr,#_D0SetupLen
      0059EE E0               [24]  984 	movx	a,@dptr
      0059EF FB               [12]  985 	mov	r3,a
      0059F0 A3               [24]  986 	inc	dptr
      0059F1 E0               [24]  987 	movx	a,@dptr
      0059F2 FC               [12]  988 	mov	r4,a
      0059F3 EB               [12]  989 	mov	a,r3
      0059F4 C3               [12]  990 	clr	c
      0059F5 9D               [12]  991 	subb	a,r5
      0059F6 FB               [12]  992 	mov	r3,a
      0059F7 EC               [12]  993 	mov	a,r4
      0059F8 9F               [12]  994 	subb	a,r7
      0059F9 FC               [12]  995 	mov	r4,a
      0059FA 90 07 5D         [24]  996 	mov	dptr,#_D0SetupLen
      0059FD EB               [12]  997 	mov	a,r3
      0059FE F0               [24]  998 	movx	@dptr,a
      0059FF EC               [12]  999 	mov	a,r4
      005A00 A3               [24] 1000 	inc	dptr
      005A01 F0               [24] 1001 	movx	@dptr,a
                                   1002 ;	tmk_core/protocol/ch555/usb_ak820.c:140: if (!length) control_zlp = 0;
      005A02 EE               [12] 1003 	mov	a,r6
      005A03 70 05            [24] 1004 	jnz	00103$
      005A05 90 07 BE         [24] 1005 	mov	dptr,#_control_zlp
      005A08 E4               [12] 1006 	clr	a
      005A09 F0               [24] 1007 	movx	@dptr,a
      005A0A                       1008 00103$:
                                   1009 ;	tmk_core/protocol/ch555/usb_ak820.c:141: D0_EP0T_L = length;
      005A0A 90 22 08         [24] 1010 	mov	dptr,#0x2208
      005A0D EE               [12] 1011 	mov	a,r6
      005A0E F0               [24] 1012 	movx	@dptr,a
                                   1013 ;	tmk_core/protocol/ch555/usb_ak820.c:142: D0_EP0RES = (D0_EP0RES & (bUEP_T_TOG | bUEP_R_TOG)) | UEP_T_RES_ACK | UEP_R_RES_ACK;
      005A0F 90 22 00         [24] 1014 	mov	dptr,#0x2200
      005A12 E0               [24] 1015 	movx	a,@dptr
      005A13 54 C0            [12] 1016 	anl	a,#0xc0
      005A15 F0               [24] 1017 	movx	@dptr,a
                                   1018 ;	tmk_core/protocol/ch555/usb_ak820.c:143: }
      005A16 22               [24] 1019 	ret
                                   1020 ;------------------------------------------------------------
                                   1021 ;Allocation info for local variables in function 'descriptor_select'
                                   1022 ;------------------------------------------------------------
                                   1023 ;index         Allocated with name '_descriptor_select_PARM_2'
                                   1024 ;interface     Allocated with name '_descriptor_select_PARM_3'
                                   1025 ;type          Allocated with name '_descriptor_select_type_10000_268'
                                   1026 ;hid           Allocated with name '_descriptor_select_hid_30000_281'
                                   1027 ;------------------------------------------------------------
                                   1028 ;	tmk_core/protocol/ch555/usb_ak820.c:160: static uint16_t descriptor_select(uint8_t type, uint8_t index, uint16_t interface) {
                                   1029 ;	-----------------------------------------
                                   1030 ;	 function descriptor_select
                                   1031 ;	-----------------------------------------
      005A17                       1032 _descriptor_select:
      005A17 E5 82            [12] 1033 	mov	a,dpl
      005A19 90 07 C4         [24] 1034 	mov	dptr,#_descriptor_select_type_10000_268
      005A1C F0               [24] 1035 	movx	@dptr,a
                                   1036 ;	tmk_core/protocol/ch555/usb_ak820.c:161: if (type == USB_DESCR_TYP_DEVICE && !index && !interface) {
      005A1D E0               [24] 1037 	movx	a,@dptr
      005A1E FF               [12] 1038 	mov	r7,a
      005A1F BF 01 20         [24] 1039 	cjne	r7,#0x01,00102$
      005A22 90 07 C1         [24] 1040 	mov	dptr,#_descriptor_select_PARM_2
      005A25 E0               [24] 1041 	movx	a,@dptr
      005A26 70 1A            [24] 1042 	jnz	00102$
      005A28 90 07 C2         [24] 1043 	mov	dptr,#_descriptor_select_PARM_3
      005A2B E0               [24] 1044 	movx	a,@dptr
      005A2C F5 F0            [12] 1045 	mov	b,a
      005A2E A3               [24] 1046 	inc	dptr
      005A2F E0               [24] 1047 	movx	a,@dptr
      005A30 45 F0            [12] 1048 	orl	a,b
      005A32 70 0E            [24] 1049 	jnz	00102$
                                   1050 ;	tmk_core/protocol/ch555/usb_ak820.c:162: control_pointer = (const uint8_t __code *)&DeviceDescriptor;
      005A34 90 07 BF         [24] 1051 	mov	dptr,#_control_pointer
      005A37 74 92            [12] 1052 	mov	a,#_DeviceDescriptor
      005A39 F0               [24] 1053 	movx	@dptr,a
      005A3A 74 BD            [12] 1054 	mov	a,#(_DeviceDescriptor >> 8)
      005A3C A3               [24] 1055 	inc	dptr
      005A3D F0               [24] 1056 	movx	@dptr,a
                                   1057 ;	tmk_core/protocol/ch555/usb_ak820.c:163: return sizeof(DeviceDescriptor);
      005A3E 90 00 12         [24] 1058 	mov	dptr,#0x0012
      005A41 22               [24] 1059 	ret
      005A42                       1060 00102$:
                                   1061 ;	tmk_core/protocol/ch555/usb_ak820.c:165: if (type == USB_DESCR_TYP_CONFIG && !index && !interface) {
      005A42 90 07 C4         [24] 1062 	mov	dptr,#_descriptor_select_type_10000_268
      005A45 E0               [24] 1063 	movx	a,@dptr
      005A46 FF               [12] 1064 	mov	r7,a
      005A47 BF 02 20         [24] 1065 	cjne	r7,#0x02,00106$
      005A4A 90 07 C1         [24] 1066 	mov	dptr,#_descriptor_select_PARM_2
      005A4D E0               [24] 1067 	movx	a,@dptr
      005A4E 70 1A            [24] 1068 	jnz	00106$
      005A50 90 07 C2         [24] 1069 	mov	dptr,#_descriptor_select_PARM_3
      005A53 E0               [24] 1070 	movx	a,@dptr
      005A54 F5 F0            [12] 1071 	mov	b,a
      005A56 A3               [24] 1072 	inc	dptr
      005A57 E0               [24] 1073 	movx	a,@dptr
      005A58 45 F0            [12] 1074 	orl	a,b
      005A5A 70 0E            [24] 1075 	jnz	00106$
                                   1076 ;	tmk_core/protocol/ch555/usb_ak820.c:166: control_pointer = (const uint8_t __code *)&ConfigurationDescriptor;
      005A5C 90 07 BF         [24] 1077 	mov	dptr,#_control_pointer
      005A5F 74 A4            [12] 1078 	mov	a,#_ConfigurationDescriptor
      005A61 F0               [24] 1079 	movx	@dptr,a
      005A62 74 BD            [12] 1080 	mov	a,#(_ConfigurationDescriptor >> 8)
      005A64 A3               [24] 1081 	inc	dptr
      005A65 F0               [24] 1082 	movx	@dptr,a
                                   1083 ;	tmk_core/protocol/ch555/usb_ak820.c:167: return sizeof(ConfigurationDescriptor);
      005A66 90 00 54         [24] 1084 	mov	dptr,#0x0054
      005A69 22               [24] 1085 	ret
      005A6A                       1086 00106$:
                                   1087 ;	tmk_core/protocol/ch555/usb_ak820.c:169: if (type == USB_DESCR_TYP_STRING) {
      005A6A 90 07 C4         [24] 1088 	mov	dptr,#_descriptor_select_type_10000_268
      005A6D E0               [24] 1089 	movx	a,@dptr
      005A6E FF               [12] 1090 	mov	r7,a
      005A6F BF 03 02         [24] 1091 	cjne	r7,#0x03,00238$
      005A72 80 03            [24] 1092 	sjmp	00239$
      005A74                       1093 00238$:
      005A74 02 5B 0E         [24] 1094 	ljmp	00119$
      005A77                       1095 00239$:
                                   1096 ;	tmk_core/protocol/ch555/usb_ak820.c:170: if (interface != 0 && interface != 0x0409) return 0;
      005A77 90 07 C2         [24] 1097 	mov	dptr,#_descriptor_select_PARM_3
      005A7A E0               [24] 1098 	movx	a,@dptr
      005A7B FD               [12] 1099 	mov	r5,a
      005A7C A3               [24] 1100 	inc	dptr
      005A7D E0               [24] 1101 	movx	a,@dptr
      005A7E FE               [12] 1102 	mov	r6,a
      005A7F 90 07 C2         [24] 1103 	mov	dptr,#_descriptor_select_PARM_3
      005A82 E0               [24] 1104 	movx	a,@dptr
      005A83 F5 F0            [12] 1105 	mov	b,a
      005A85 A3               [24] 1106 	inc	dptr
      005A86 E0               [24] 1107 	movx	a,@dptr
      005A87 45 F0            [12] 1108 	orl	a,b
      005A89 60 0C            [24] 1109 	jz	00110$
      005A8B BD 09 05         [24] 1110 	cjne	r5,#0x09,00241$
      005A8E BE 04 02         [24] 1111 	cjne	r6,#0x04,00241$
      005A91 80 04            [24] 1112 	sjmp	00110$
      005A93                       1113 00241$:
      005A93 90 00 00         [24] 1114 	mov	dptr,#0x0000
      005A96 22               [24] 1115 	ret
      005A97                       1116 00110$:
                                   1117 ;	tmk_core/protocol/ch555/usb_ak820.c:171: switch (index) {
      005A97 90 07 C1         [24] 1118 	mov	dptr,#_descriptor_select_PARM_2
      005A9A E0               [24] 1119 	movx	a,@dptr
      005A9B FE               [12] 1120 	mov  r6,a
      005A9C 24 FC            [12] 1121 	add	a,#0xff - 0x03
      005A9E 40 6A            [24] 1122 	jc	00116$
                                   1123 ;	free result
      005AA0 EE               [12] 1124 	mov	a,r6
      005AA1 2E               [12] 1125 	add	a,r6
                                   1126 ;	tmk_core/protocol/ch555/usb_ak820.c:172: case 0: control_pointer = (const uint8_t __code *)&LanguageString; return LanguageString.Header.Size;
      005AA2 90 5A A6         [24] 1127 	mov	dptr,#00243$
      005AA5 73               [24] 1128 	jmp	@a+dptr
      005AA6                       1129 00243$:
      005AA6 80 06            [24] 1130 	sjmp	00112$
      005AA8 80 1B            [24] 1131 	sjmp	00113$
      005AAA 80 30            [24] 1132 	sjmp	00114$
      005AAC 80 45            [24] 1133 	sjmp	00115$
      005AAE                       1134 00112$:
      005AAE 90 07 BF         [24] 1135 	mov	dptr,#_control_pointer
      005AB1 74 F8            [12] 1136 	mov	a,#_LanguageString
      005AB3 F0               [24] 1137 	movx	@dptr,a
      005AB4 74 BD            [12] 1138 	mov	a,#(_LanguageString >> 8)
      005AB6 A3               [24] 1139 	inc	dptr
      005AB7 F0               [24] 1140 	movx	@dptr,a
      005AB8 90 BD F8         [24] 1141 	mov	dptr,#_LanguageString
      005ABB E4               [12] 1142 	clr	a
      005ABC 93               [24] 1143 	movc	a,@a+dptr
      005ABD FE               [12] 1144 	mov	r6,a
      005ABE 7D 00            [12] 1145 	mov	r5,#0x00
      005AC0 8E 82            [24] 1146 	mov	dpl, r6
      005AC2 8D 83            [24] 1147 	mov	dph, r5
      005AC4 22               [24] 1148 	ret
                                   1149 ;	tmk_core/protocol/ch555/usb_ak820.c:173: case 1: control_pointer = (const uint8_t __code *)&ManufacturerString; return ManufacturerString.Header.Size;
      005AC5                       1150 00113$:
      005AC5 90 07 BF         [24] 1151 	mov	dptr,#_control_pointer
      005AC8 74 FC            [12] 1152 	mov	a,#_ManufacturerString
      005ACA F0               [24] 1153 	movx	@dptr,a
      005ACB 74 BD            [12] 1154 	mov	a,#(_ManufacturerString >> 8)
      005ACD A3               [24] 1155 	inc	dptr
      005ACE F0               [24] 1156 	movx	@dptr,a
      005ACF 90 BD FC         [24] 1157 	mov	dptr,#_ManufacturerString
      005AD2 E4               [12] 1158 	clr	a
      005AD3 93               [24] 1159 	movc	a,@a+dptr
      005AD4 FE               [12] 1160 	mov	r6,a
      005AD5 7D 00            [12] 1161 	mov	r5,#0x00
      005AD7 8E 82            [24] 1162 	mov	dpl, r6
      005AD9 8D 83            [24] 1163 	mov	dph, r5
      005ADB 22               [24] 1164 	ret
                                   1165 ;	tmk_core/protocol/ch555/usb_ak820.c:174: case 2: control_pointer = (const uint8_t __code *)&ProductString; return ProductString.Header.Size;
      005ADC                       1166 00114$:
      005ADC 90 07 BF         [24] 1167 	mov	dptr,#_control_pointer
      005ADF 74 0A            [12] 1168 	mov	a,#_ProductString
      005AE1 F0               [24] 1169 	movx	@dptr,a
      005AE2 74 BE            [12] 1170 	mov	a,#(_ProductString >> 8)
      005AE4 A3               [24] 1171 	inc	dptr
      005AE5 F0               [24] 1172 	movx	@dptr,a
      005AE6 90 BE 0A         [24] 1173 	mov	dptr,#_ProductString
      005AE9 E4               [12] 1174 	clr	a
      005AEA 93               [24] 1175 	movc	a,@a+dptr
      005AEB FE               [12] 1176 	mov	r6,a
      005AEC 7D 00            [12] 1177 	mov	r5,#0x00
      005AEE 8E 82            [24] 1178 	mov	dpl, r6
      005AF0 8D 83            [24] 1179 	mov	dph, r5
      005AF2 22               [24] 1180 	ret
                                   1181 ;	tmk_core/protocol/ch555/usb_ak820.c:176: case 3: control_pointer = (const uint8_t __code *)&SerialNumberString; return SerialNumberString.Header.Size;
      005AF3                       1182 00115$:
      005AF3 90 07 BF         [24] 1183 	mov	dptr,#_control_pointer
      005AF6 74 42            [12] 1184 	mov	a,#_SerialNumberString
      005AF8 F0               [24] 1185 	movx	@dptr,a
      005AF9 74 BE            [12] 1186 	mov	a,#(_SerialNumberString >> 8)
      005AFB A3               [24] 1187 	inc	dptr
      005AFC F0               [24] 1188 	movx	@dptr,a
      005AFD 90 BE 42         [24] 1189 	mov	dptr,#_SerialNumberString
      005B00 E4               [12] 1190 	clr	a
      005B01 93               [24] 1191 	movc	a,@a+dptr
      005B02 FE               [12] 1192 	mov	r6,a
      005B03 7D 00            [12] 1193 	mov	r5,#0x00
      005B05 8E 82            [24] 1194 	mov	dpl, r6
      005B07 8D 83            [24] 1195 	mov	dph, r5
      005B09 22               [24] 1196 	ret
                                   1197 ;	tmk_core/protocol/ch555/usb_ak820.c:178: default: return 0;
      005B0A                       1198 00116$:
      005B0A 90 00 00         [24] 1199 	mov	dptr,#0x0000
      005B0D 22               [24] 1200 	ret
                                   1201 ;	tmk_core/protocol/ch555/usb_ak820.c:179: }
      005B0E                       1202 00119$:
                                   1203 ;	tmk_core/protocol/ch555/usb_ak820.c:181: if (index || interface >= TOTAL_INTERFACES) return 0;
      005B0E 90 07 C1         [24] 1204 	mov	dptr,#_descriptor_select_PARM_2
      005B11 E0               [24] 1205 	movx	a,@dptr
      005B12 70 11            [24] 1206 	jnz	00120$
      005B14 90 07 C2         [24] 1207 	mov	dptr,#_descriptor_select_PARM_3
      005B17 E0               [24] 1208 	movx	a,@dptr
      005B18 FD               [12] 1209 	mov	r5,a
      005B19 A3               [24] 1210 	inc	dptr
      005B1A E0               [24] 1211 	movx	a,@dptr
      005B1B FE               [12] 1212 	mov	r6,a
      005B1C C3               [12] 1213 	clr	c
      005B1D ED               [12] 1214 	mov	a,r5
      005B1E 94 03            [12] 1215 	subb	a,#0x03
      005B20 EE               [12] 1216 	mov	a,r6
      005B21 94 00            [12] 1217 	subb	a,#0x00
      005B23 40 04            [24] 1218 	jc	00121$
      005B25                       1219 00120$:
      005B25 90 00 00         [24] 1220 	mov	dptr,#0x0000
      005B28 22               [24] 1221 	ret
      005B29                       1222 00121$:
                                   1223 ;	tmk_core/protocol/ch555/usb_ak820.c:182: if (type == USB_DESCR_TYP_REPORT || type == USB_DESCR_TYP_HID) {
      005B29 BF 22 02         [24] 1224 	cjne	r7,#0x22,00246$
      005B2C 80 03            [24] 1225 	sjmp	00127$
      005B2E                       1226 00246$:
      005B2E BF 21 5D         [24] 1227 	cjne	r7,#0x21,00128$
      005B31                       1228 00127$:
                                   1229 ;	tmk_core/protocol/ch555/usb_ak820.c:183: const USB_HID_Descriptor_HID_t __code *hid = interface_descriptors[(uint8_t)interface].hid;
      005B31 ED               [12] 1230 	mov	a,r5
      005B32 75 F0 04         [24] 1231 	mov	b,#0x04
      005B35 A4               [48] 1232 	mul	ab
      005B36 24 1B            [12] 1233 	add	a, #_interface_descriptors
      005B38 FE               [12] 1234 	mov	r6,a
      005B39 74 B7            [12] 1235 	mov	a,#(_interface_descriptors >> 8)
      005B3B 35 F0            [12] 1236 	addc	a, b
      005B3D FF               [12] 1237 	mov	r7,a
      005B3E 8E 82            [24] 1238 	mov	dpl,r6
      005B40 8F 83            [24] 1239 	mov	dph,r7
      005B42 A3               [24] 1240 	inc	dptr
      005B43 A3               [24] 1241 	inc	dptr
      005B44 E4               [12] 1242 	clr	a
      005B45 93               [24] 1243 	movc	a,@a+dptr
      005B46 FC               [12] 1244 	mov	r4,a
      005B47 A3               [24] 1245 	inc	dptr
      005B48 E4               [12] 1246 	clr	a
      005B49 93               [24] 1247 	movc	a,@a+dptr
                                   1248 ;	tmk_core/protocol/ch555/usb_ak820.c:184: if (!hid) return 0;
      005B4A FD               [12] 1249 	mov	r5,a
      005B4B 4C               [12] 1250 	orl	a,r4
      005B4C 70 04            [24] 1251 	jnz	00124$
      005B4E 90 00 00         [24] 1252 	mov	dptr,#0x0000
      005B51 22               [24] 1253 	ret
      005B52                       1254 00124$:
                                   1255 ;	tmk_core/protocol/ch555/usb_ak820.c:185: if (type == USB_DESCR_TYP_REPORT) {
      005B52 90 07 C4         [24] 1256 	mov	dptr,#_descriptor_select_type_10000_268
      005B55 E0               [24] 1257 	movx	a,@dptr
      005B56 FB               [12] 1258 	mov	r3,a
      005B57 BB 22 28         [24] 1259 	cjne	r3,#0x22,00126$
                                   1260 ;	tmk_core/protocol/ch555/usb_ak820.c:186: control_pointer = interface_descriptors[(uint8_t)interface].report;
      005B5A 8E 82            [24] 1261 	mov	dpl,r6
      005B5C 8F 83            [24] 1262 	mov	dph,r7
      005B5E E4               [12] 1263 	clr	a
      005B5F 93               [24] 1264 	movc	a,@a+dptr
      005B60 FE               [12] 1265 	mov	r6,a
      005B61 A3               [24] 1266 	inc	dptr
      005B62 E4               [12] 1267 	clr	a
      005B63 93               [24] 1268 	movc	a,@a+dptr
      005B64 FF               [12] 1269 	mov	r7,a
      005B65 90 07 BF         [24] 1270 	mov	dptr,#_control_pointer
      005B68 EE               [12] 1271 	mov	a,r6
      005B69 F0               [24] 1272 	movx	@dptr,a
      005B6A EF               [12] 1273 	mov	a,r7
      005B6B A3               [24] 1274 	inc	dptr
      005B6C F0               [24] 1275 	movx	@dptr,a
                                   1276 ;	tmk_core/protocol/ch555/usb_ak820.c:187: return hid->HIDReportLength;
      005B6D 74 07            [12] 1277 	mov	a,#0x07
      005B6F 2C               [12] 1278 	add	a, r4
      005B70 F5 82            [12] 1279 	mov	dpl,a
      005B72 E4               [12] 1280 	clr	a
      005B73 3D               [12] 1281 	addc	a, r5
      005B74 F5 83            [12] 1282 	mov	dph,a
      005B76 E4               [12] 1283 	clr	a
      005B77 93               [24] 1284 	movc	a,@a+dptr
      005B78 FE               [12] 1285 	mov	r6,a
      005B79 A3               [24] 1286 	inc	dptr
      005B7A E4               [12] 1287 	clr	a
      005B7B 93               [24] 1288 	movc	a,@a+dptr
      005B7C FF               [12] 1289 	mov	r7,a
      005B7D 8E 82            [24] 1290 	mov	dpl, r6
      005B7F 8F 83            [24] 1291 	mov	dph, r7
      005B81 22               [24] 1292 	ret
      005B82                       1293 00126$:
                                   1294 ;	tmk_core/protocol/ch555/usb_ak820.c:189: control_pointer = (const uint8_t __code *)hid;
      005B82 90 07 BF         [24] 1295 	mov	dptr,#_control_pointer
      005B85 EC               [12] 1296 	mov	a,r4
      005B86 F0               [24] 1297 	movx	@dptr,a
      005B87 ED               [12] 1298 	mov	a,r5
      005B88 A3               [24] 1299 	inc	dptr
      005B89 F0               [24] 1300 	movx	@dptr,a
                                   1301 ;	tmk_core/protocol/ch555/usb_ak820.c:190: return 9;
      005B8A 90 00 09         [24] 1302 	mov	dptr,#0x0009
      005B8D 22               [24] 1303 	ret
      005B8E                       1304 00128$:
                                   1305 ;	tmk_core/protocol/ch555/usb_ak820.c:192: return 0;
      005B8E 90 00 00         [24] 1306 	mov	dptr,#0x0000
                                   1307 ;	tmk_core/protocol/ch555/usb_ak820.c:193: }
      005B91 22               [24] 1308 	ret
                                   1309 ;------------------------------------------------------------
                                   1310 ;Allocation info for local variables in function 'control_setup'
                                   1311 ;------------------------------------------------------------
                                   1312 ;sloc1         Allocated with name '_control_setup_sloc1_1_0'
                                   1313 ;sloc3         Allocated with name '_control_setup_sloc3_1_0'
                                   1314 ;sloc4         Allocated with name '_control_setup_sloc4_1_0'
                                   1315 ;type          Allocated with name '_control_setup_type_10000_286'
                                   1316 ;value         Allocated with name '_control_setup_value_10000_286'
                                   1317 ;index         Allocated with name '_control_setup_index_10000_286'
                                   1318 ;length        Allocated with name '_control_setup_length_10000_286'
                                   1319 ;endpoint      Allocated with name '_control_setup_endpoint_10000_286'
                                   1320 ;i             Allocated with name '_control_setup_i_10000_286'
                                   1321 ;offset        Allocated with name '_control_setup_offset_10000_286'
                                   1322 ;report_id     Allocated with name '_control_setup_report_id_10000_286'
                                   1323 ;------------------------------------------------------------
                                   1324 ;	tmk_core/protocol/ch555/usb_ak820.c:195: static void control_setup(void) {
                                   1325 ;	-----------------------------------------
                                   1326 ;	 function control_setup
                                   1327 ;	-----------------------------------------
      005B92                       1328 _control_setup:
                                   1329 ;	tmk_core/protocol/ch555/usb_ak820.c:196: uint8_t type = pD0_SETUP_REQ->bRequestType;
      005B92 90 10 00         [24] 1330 	mov	dptr,#0x1000
      005B95 E0               [24] 1331 	movx	a,@dptr
      005B96 FF               [12] 1332 	mov	r7,a
                                   1333 ;	tmk_core/protocol/ch555/usb_ak820.c:197: uint16_t value = pD0_SETUP_REQ->wValueL | ((uint16_t)pD0_SETUP_REQ->wValueH << 8);
      005B97 A3               [24] 1334 	inc	dptr
      005B98 A3               [24] 1335 	inc	dptr
      005B99 E0               [24] 1336 	movx	a,@dptr
      005B9A FE               [12] 1337 	mov	r6,a
      005B9B A3               [24] 1338 	inc	dptr
      005B9C E0               [24] 1339 	movx	a,@dptr
      005B9D FC               [12] 1340 	mov	r4,a
      005B9E 7D 00            [12] 1341 	mov	r5,#0x00
      005BA0 8E 03            [24] 1342 	mov	ar3,r6
      005BA2 7E 00            [12] 1343 	mov	r6,#0x00
      005BA4 ED               [12] 1344 	mov	a,r5
      005BA5 4B               [12] 1345 	orl	a,r3
      005BA6 FD               [12] 1346 	mov	r5,a
      005BA7 EC               [12] 1347 	mov	a,r4
      005BA8 4E               [12] 1348 	orl	a,r6
      005BA9 FE               [12] 1349 	mov	r6,a
                                   1350 ;	tmk_core/protocol/ch555/usb_ak820.c:198: uint16_t index = pD0_SETUP_REQ->wIndexL | ((uint16_t)pD0_SETUP_REQ->wIndexH << 8);
      005BAA A3               [24] 1351 	inc	dptr
      005BAB E0               [24] 1352 	movx	a,@dptr
      005BAC FC               [12] 1353 	mov	r4,a
      005BAD A3               [24] 1354 	inc	dptr
      005BAE E0               [24] 1355 	movx	a,@dptr
      005BAF FA               [12] 1356 	mov	r2,a
      005BB0 7B 00            [12] 1357 	mov	r3,#0x00
      005BB2 8C 01            [24] 1358 	mov	ar1,r4
      005BB4 7C 00            [12] 1359 	mov	r4,#0x00
      005BB6 EB               [12] 1360 	mov	a,r3
      005BB7 49               [12] 1361 	orl	a,r1
      005BB8 FB               [12] 1362 	mov	r3,a
      005BB9 EA               [12] 1363 	mov	a,r2
      005BBA 4C               [12] 1364 	orl	a,r4
      005BBB FC               [12] 1365 	mov	r4,a
                                   1366 ;	tmk_core/protocol/ch555/usb_ak820.c:202: __bit valid_interface = index < TOTAL_INTERFACES;
      005BBC C3               [12] 1367 	clr	c
      005BBD EB               [12] 1368 	mov	a,r3
      005BBE 94 03            [12] 1369 	subb	a,#0x03
      005BC0 EC               [12] 1370 	mov	a,r4
      005BC1 94 00            [12] 1371 	subb	a,#0x00
      005BC3 92 16            [24] 1372 	mov	_control_setup_valid_interface_10000_286,c
                                   1373 ;	tmk_core/protocol/ch555/usb_ak820.c:203: __bit zero_index = !index;
      005BC5 EB               [12] 1374 	mov	a,r3
      005BC6 4C               [12] 1375 	orl	a,r4
      005BC7 B4 01 00         [24] 1376 	cjne	a,#0x01,01201$
      005BCA                       1377 01201$:
      005BCA 92 17            [24] 1378 	mov	_control_setup_zero_index_10000_286,c
                                   1379 ;	tmk_core/protocol/ch555/usb_ak820.c:204: __bit zero_value = !value;
      005BCC ED               [12] 1380 	mov	a,r5
      005BCD 4E               [12] 1381 	orl	a,r6
      005BCE B4 01 00         [24] 1382 	cjne	a,#0x01,01202$
      005BD1                       1383 01202$:
                                   1384 ;	assignBit
      005BD1 92 1A            [24] 1385 	mov  _control_setup_sloc0_1_0,c
      005BD3 92 18            [24] 1386 	mov	_control_setup_zero_value_10000_286,c
                                   1387 ;	tmk_core/protocol/ch555/usb_ak820.c:208: uint8_t offset = 0;
      005BD5 90 07 C7         [24] 1388 	mov	dptr,#_control_setup_offset_10000_286
      005BD8 E4               [12] 1389 	clr	a
      005BD9 F0               [24] 1390 	movx	@dptr,a
                                   1391 ;	tmk_core/protocol/ch555/usb_ak820.c:210: if (raw_state == RAW_RX) raw_state = RAW_IDLE; /* abort only unfinished OUT */
      005BDA 90 07 6A         [24] 1392 	mov	dptr,#_raw_state
      005BDD E0               [24] 1393 	movx	a,@dptr
      005BDE FA               [12] 1394 	mov	r2,a
      005BDF BA 01 05         [24] 1395 	cjne	r2,#0x01,00102$
      005BE2 90 07 6A         [24] 1396 	mov	dptr,#_raw_state
      005BE5 E4               [12] 1397 	clr	a
      005BE6 F0               [24] 1398 	movx	@dptr,a
      005BE7                       1399 00102$:
                                   1400 ;	tmk_core/protocol/ch555/usb_ak820.c:211: output_kind = OUTPUT_NONE;
      005BE7 C0 07            [24] 1401 	push	ar7
      005BE9 90 07 BC         [24] 1402 	mov	dptr,#_output_kind
      005BEC E4               [12] 1403 	clr	a
      005BED F0               [24] 1404 	movx	@dptr,a
                                   1405 ;	tmk_core/protocol/ch555/usb_ak820.c:212: control_phase = CTRL_IDLE;
      005BEE 90 07 BB         [24] 1406 	mov	dptr,#_control_phase
      005BF1 F0               [24] 1407 	movx	@dptr,a
                                   1408 ;	tmk_core/protocol/ch555/usb_ak820.c:213: control_zlp = 0;
      005BF2 90 07 BE         [24] 1409 	mov	dptr,#_control_zlp
      005BF5 F0               [24] 1410 	movx	@dptr,a
                                   1411 ;	tmk_core/protocol/ch555/usb_ak820.c:214: D0SetupReqCode = pD0_SETUP_REQ->bRequest;
      005BF6 90 10 01         [24] 1412 	mov	dptr,#0x1001
      005BF9 E0               [24] 1413 	movx	a,@dptr
      005BFA 90 07 5C         [24] 1414 	mov	dptr,#_D0SetupReqCode
      005BFD F0               [24] 1415 	movx	@dptr,a
                                   1416 ;	tmk_core/protocol/ch555/usb_ak820.c:215: D0SetupLen = pD0_SETUP_REQ->wLengthL | ((uint16_t)pD0_SETUP_REQ->wLengthH << 8);
      005BFE 90 10 06         [24] 1417 	mov	dptr,#0x1006
      005C01 E0               [24] 1418 	movx	a,@dptr
      005C02 FA               [12] 1419 	mov	r2,a
      005C03 A3               [24] 1420 	inc	dptr
      005C04 E0               [24] 1421 	movx	a,@dptr
      005C05 F9               [12] 1422 	mov	r1,a
      005C06 78 00            [12] 1423 	mov	r0,#0x00
      005C08 7F 00            [12] 1424 	mov	r7,#0x00
      005C0A 90 07 5D         [24] 1425 	mov	dptr,#_D0SetupLen
      005C0D E8               [12] 1426 	mov	a,r0
      005C0E 4A               [12] 1427 	orl	a,r2
      005C0F F0               [24] 1428 	movx	@dptr,a
      005C10 E9               [12] 1429 	mov	a,r1
      005C11 4F               [12] 1430 	orl	a,r7
      005C12 A3               [24] 1431 	inc	dptr
      005C13 F0               [24] 1432 	movx	@dptr,a
                                   1433 ;	tmk_core/protocol/ch555/usb_ak820.c:216: zero_length = !D0SetupLen;
      005C14 90 07 5D         [24] 1434 	mov	dptr,#_D0SetupLen
      005C17 E0               [24] 1435 	movx	a,@dptr
      005C18 FA               [12] 1436 	mov	r2,a
      005C19 A3               [24] 1437 	inc	dptr
      005C1A E0               [24] 1438 	movx	a,@dptr
      005C1B 4A               [12] 1439 	orl	a,r2
      005C1C B4 01 00         [24] 1440 	cjne	a,#0x01,01205$
      005C1F                       1441 01205$:
      005C1F 92 19            [24] 1442 	mov	_control_setup_zero_length_10000_286,c
                                   1443 ;	tmk_core/protocol/ch555/usb_ak820.c:217: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_ACK | UEP_T_RES_NAK;
      005C21 90 22 00         [24] 1444 	mov	dptr,#0x2200
      005C24 74 C2            [12] 1445 	mov	a,#0xc2
      005C26 F0               [24] 1446 	movx	@dptr,a
                                   1447 ;	tmk_core/protocol/ch555/usb_ak820.c:218: D0_EP0T_L = 0;
      005C27 90 22 08         [24] 1448 	mov	dptr,#0x2208
      005C2A E4               [12] 1449 	clr	a
      005C2B F0               [24] 1450 	movx	@dptr,a
                                   1451 ;	tmk_core/protocol/ch555/usb_ak820.c:222: switch (D0SetupReqCode) {
      005C2C 90 07 5C         [24] 1452 	mov	dptr,#_D0SetupReqCode
      005C2F E0               [24] 1453 	movx	a,@dptr
      005C30 F5 16            [12] 1454 	mov	_control_setup_sloc1_1_0,a
      005C32 C3               [12] 1455 	clr	c
      005C33 74 0B            [12] 1456 	mov	a,#0x0b
      005C35 95 16            [12] 1457 	subb	a,_control_setup_sloc1_1_0
      005C37 D0 07            [24] 1458 	pop	ar7
      005C39 50 03            [24] 1459 	jnc	01206$
      005C3B 02 59 79         [24] 1460 	ljmp	_control_stall
      005C3E                       1461 01206$:
                                   1462 ;	free result
      005C3E E5 16            [12] 1463 	mov	a,_control_setup_sloc1_1_0
      005C40 F5 F0            [12] 1464 	mov	b,a
      005C42 24 0B            [12] 1465 	add	a,#(01207$-3-.)
      005C44 83               [24] 1466 	movc	a,@a+pc
      005C45 F5 82            [12] 1467 	mov	dpl,a
      005C47 E5 F0            [12] 1468 	mov	a,b
      005C49 24 10            [12] 1469 	add	a,#(01208$-3-.)
      005C4B 83               [24] 1470 	movc	a,@a+pc
      005C4C F5 83            [12] 1471 	mov	dph,a
      005C4E E4               [12] 1472 	clr	a
      005C4F 73               [24] 1473 	jmp	@a+dptr
      005C50                       1474 01207$:
      005C50 F8                    1475 	.db	00188$
      005C51 9E                    1476 	.db	00205$
      005C52 E1                    1477 	.db	00282$
      005C53 9E                    1478 	.db	00205$
      005C54 25                    1479 	.db	00290$
      005C55 22                    1480 	.db	00116$
      005C56 68                    1481 	.db	00103$
      005C57 25                    1482 	.db	00290$
      005C58 27                    1483 	.db	00150$
      005C59 4B                    1484 	.db	00123$
      005C5A 57                    1485 	.db	00157$
      005C5B AA                    1486 	.db	00173$
      005C5C                       1487 01208$:
      005C5C 5E                    1488 	.db	00188$>>8
      005C5D 5F                    1489 	.db	00205$>>8
      005C5E 62                    1490 	.db	00282$>>8
      005C5F 5F                    1491 	.db	00205$>>8
      005C60 63                    1492 	.db	00290$>>8
      005C61 5D                    1493 	.db	00116$>>8
      005C62 5C                    1494 	.db	00103$>>8
      005C63 63                    1495 	.db	00290$>>8
      005C64 5E                    1496 	.db	00150$>>8
      005C65 5D                    1497 	.db	00123$>>8
      005C66 5E                    1498 	.db	00157$>>8
      005C67 5E                    1499 	.db	00173$>>8
                                   1500 ;	tmk_core/protocol/ch555/usb_ak820.c:223: case USB_GET_DESCRIPTOR:
      005C68                       1501 00103$:
                                   1502 ;	tmk_core/protocol/ch555/usb_ak820.c:224: if (type == 0x80 || type == 0x81) {
      005C68 BF 80 02         [24] 1503 	cjne	r7,#0x80,01209$
      005C6B 80 08            [24] 1504 	sjmp	00112$
      005C6D                       1505 01209$:
      005C6D BF 81 02         [24] 1506 	cjne	r7,#0x81,01210$
      005C70 80 03            [24] 1507 	sjmp	01211$
      005C72                       1508 01210$:
      005C72 02 59 79         [24] 1509 	ljmp	_control_stall
      005C75                       1510 01211$:
      005C75                       1511 00112$:
                                   1512 ;	tmk_core/protocol/ch555/usb_ak820.c:225: if (((value >> 8) == USB_DESCR_TYP_HID || (value >> 8) == USB_DESCR_TYP_REPORT) != (type == 0x81)) {
      005C75 8E 01            [24] 1513 	mov	ar1,r6
      005C77 B9 21 02         [24] 1514 	cjne	r1,#0x21,01212$
      005C7A 80 09            [24] 1515 	sjmp	00301$
      005C7C                       1516 01212$:
      005C7C B9 22 02         [24] 1517 	cjne	r1,#0x22,01213$
      005C7F 80 04            [24] 1518 	sjmp	00301$
      005C81                       1519 01213$:
                                   1520 ;	assignBit
      005C81 C2 1B            [12] 1521 	clr	_control_setup_sloc2_1_0
      005C83 80 02            [24] 1522 	sjmp	00302$
      005C85                       1523 00301$:
                                   1524 ;	assignBit
      005C85 D2 1B            [12] 1525 	setb	_control_setup_sloc2_1_0
      005C87                       1526 00302$:
      005C87 E4               [12] 1527 	clr	a
      005C88 BF 81 01         [24] 1528 	cjne	r7,#0x81,01214$
      005C8B 04               [12] 1529 	inc	a
      005C8C                       1530 01214$:
      005C8C FA               [12] 1531 	mov	r2,a
      005C8D A2 1B            [12] 1532 	mov	c,_control_setup_sloc2_1_0
      005C8F E4               [12] 1533 	clr	a
      005C90 33               [12] 1534 	rlc	a
      005C91 B5 02 02         [24] 1535 	cjne	a,ar2,01216$
      005C94 80 03            [24] 1536 	sjmp	00105$
      005C96                       1537 01216$:
                                   1538 ;	tmk_core/protocol/ch555/usb_ak820.c:226: control_stall(); return;
      005C96 02 59 79         [24] 1539 	ljmp	_control_stall
      005C99                       1540 00105$:
                                   1541 ;	tmk_core/protocol/ch555/usb_ak820.c:228: length = descriptor_select(value >> 8, value, index);
      005C99 8E 02            [24] 1542 	mov	ar2,r6
      005C9B 90 07 C1         [24] 1543 	mov	dptr,#_descriptor_select_PARM_2
      005C9E ED               [12] 1544 	mov	a,r5
      005C9F F0               [24] 1545 	movx	@dptr,a
      005CA0 90 07 C2         [24] 1546 	mov	dptr,#_descriptor_select_PARM_3
      005CA3 EB               [12] 1547 	mov	a,r3
      005CA4 F0               [24] 1548 	movx	@dptr,a
      005CA5 EC               [12] 1549 	mov	a,r4
      005CA6 A3               [24] 1550 	inc	dptr
      005CA7 F0               [24] 1551 	movx	@dptr,a
      005CA8 8A 82            [24] 1552 	mov	dpl, r2
      005CAA 12 5A 17         [24] 1553 	lcall	_descriptor_select
      005CAD 85 82 17         [24] 1554 	mov	_control_setup_sloc3_1_0,dpl
      005CB0 85 83 18         [24] 1555 	mov	(_control_setup_sloc3_1_0 + 1),dph
                                   1556 ;	tmk_core/protocol/ch555/usb_ak820.c:229: if (!length) { control_stall(); return; }
      005CB3 E5 17            [12] 1557 	mov	a,_control_setup_sloc3_1_0
      005CB5 45 18            [12] 1558 	orl	a,(_control_setup_sloc3_1_0 + 1)
      005CB7 70 03            [24] 1559 	jnz	00107$
      005CB9 02 59 79         [24] 1560 	ljmp	_control_stall
      005CBC                       1561 00107$:
                                   1562 ;	tmk_core/protocol/ch555/usb_ak820.c:230: control_zlp = length < D0SetupLen && !(length & (DEF_ENDP0_SIZE - 1));
      005CBC 90 07 5D         [24] 1563 	mov	dptr,#_D0SetupLen
      005CBF E0               [24] 1564 	movx	a,@dptr
      005CC0 F8               [12] 1565 	mov	r0,a
      005CC1 A3               [24] 1566 	inc	dptr
      005CC2 E0               [24] 1567 	movx	a,@dptr
      005CC3 FA               [12] 1568 	mov	r2,a
      005CC4 C3               [12] 1569 	clr	c
      005CC5 E5 17            [12] 1570 	mov	a,_control_setup_sloc3_1_0
      005CC7 98               [12] 1571 	subb	a,r0
      005CC8 E5 18            [12] 1572 	mov	a,(_control_setup_sloc3_1_0 + 1)
      005CCA 9A               [12] 1573 	subb	a,r2
      005CCB 50 06            [24] 1574 	jnc	00303$
      005CCD E5 17            [12] 1575 	mov	a,_control_setup_sloc3_1_0
      005CCF 54 3F            [12] 1576 	anl	a,#0x3f
      005CD1 60 04            [24] 1577 	jz	00304$
      005CD3                       1578 00303$:
                                   1579 ;	assignBit
      005CD3 C2 1B            [12] 1580 	clr	_control_setup_sloc2_1_0
      005CD5 80 02            [24] 1581 	sjmp	00305$
      005CD7                       1582 00304$:
                                   1583 ;	assignBit
      005CD7 D2 1B            [12] 1584 	setb	_control_setup_sloc2_1_0
      005CD9                       1585 00305$:
      005CD9 90 07 BE         [24] 1586 	mov	dptr,#_control_zlp
      005CDC A2 1B            [12] 1587 	mov	c,_control_setup_sloc2_1_0
      005CDE E4               [12] 1588 	clr	a
      005CDF 33               [12] 1589 	rlc	a
      005CE0 F0               [24] 1590 	movx	@dptr,a
                                   1591 ;	tmk_core/protocol/ch555/usb_ak820.c:231: if (D0SetupLen > length) D0SetupLen = length;
      005CE1 90 07 5D         [24] 1592 	mov	dptr,#_D0SetupLen
      005CE4 E0               [24] 1593 	movx	a,@dptr
      005CE5 F9               [12] 1594 	mov	r1,a
      005CE6 A3               [24] 1595 	inc	dptr
      005CE7 E0               [24] 1596 	movx	a,@dptr
      005CE8 FA               [12] 1597 	mov	r2,a
      005CE9 C3               [12] 1598 	clr	c
      005CEA E5 17            [12] 1599 	mov	a,_control_setup_sloc3_1_0
      005CEC 99               [12] 1600 	subb	a,r1
      005CED E5 18            [12] 1601 	mov	a,(_control_setup_sloc3_1_0 + 1)
      005CEF 9A               [12] 1602 	subb	a,r2
      005CF0 50 0A            [24] 1603 	jnc	00109$
                                   1604 ;	free result
      005CF2 90 07 5D         [24] 1605 	mov	dptr,#_D0SetupLen
      005CF5 E5 17            [12] 1606 	mov	a,_control_setup_sloc3_1_0
      005CF7 F0               [24] 1607 	movx	@dptr,a
      005CF8 E5 18            [12] 1608 	mov	a,(_control_setup_sloc3_1_0 + 1)
      005CFA A3               [24] 1609 	inc	dptr
      005CFB F0               [24] 1610 	movx	@dptr,a
      005CFC                       1611 00109$:
                                   1612 ;	tmk_core/protocol/ch555/usb_ak820.c:232: control_phase = D0SetupLen ? CTRL_DATA_IN : CTRL_STATUS_OUT;
      005CFC 90 07 5D         [24] 1613 	mov	dptr,#_D0SetupLen
      005CFF E0               [24] 1614 	movx	a,@dptr
      005D00 F9               [12] 1615 	mov	r1,a
      005D01 A3               [24] 1616 	inc	dptr
      005D02 E0               [24] 1617 	movx	a,@dptr
      005D03 49               [12] 1618 	orl	a,r1
      005D04 60 04            [24] 1619 	jz	00306$
      005D06 7A 01            [12] 1620 	mov	r2,#0x01
      005D08 80 02            [24] 1621 	sjmp	00307$
      005D0A                       1622 00306$:
      005D0A 7A 02            [12] 1623 	mov	r2,#0x02
      005D0C                       1624 00307$:
      005D0C 90 07 BB         [24] 1625 	mov	dptr,#_control_phase
      005D0F EA               [12] 1626 	mov	a,r2
      005D10 F0               [24] 1627 	movx	@dptr,a
                                   1628 ;	tmk_core/protocol/ch555/usb_ak820.c:233: if (D0SetupLen) control_next();
      005D11 90 07 5D         [24] 1629 	mov	dptr,#_D0SetupLen
      005D14 E0               [24] 1630 	movx	a,@dptr
      005D15 F9               [12] 1631 	mov	r1,a
      005D16 A3               [24] 1632 	inc	dptr
      005D17 E0               [24] 1633 	movx	a,@dptr
      005D18 49               [12] 1634 	orl	a,r1
      005D19 60 03            [24] 1635 	jz	00111$
                                   1636 ;	tmk_core/protocol/ch555/usb_ak820.c:234: return;
      005D1B 02 59 9B         [24] 1637 	ljmp	_control_next
      005D1E                       1638 00111$:
      005D1E 22               [24] 1639 	ret
                                   1640 ;	tmk_core/protocol/ch555/usb_ak820.c:235: } else { control_stall(); return; }
      005D1F 02 59 79         [24] 1641 	ljmp	_control_stall
                                   1642 ;	tmk_core/protocol/ch555/usb_ak820.c:236: case USB_SET_ADDRESS:
      005D22                       1643 00116$:
                                   1644 ;	tmk_core/protocol/ch555/usb_ak820.c:237: if (type == 0x00 && zero_index && zero_length && value <= 127) {
      005D22 EF               [12] 1645 	mov	a,r7
      005D23 70 23            [24] 1646 	jnz	00118$
      005D25 30 17 20         [24] 1647 	jnb	_control_setup_zero_index_10000_286,00118$
      005D28 30 19 1D         [24] 1648 	jnb	_control_setup_zero_length_10000_286,00118$
      005D2B 8D 01            [24] 1649 	mov	ar1,r5
      005D2D 8E 02            [24] 1650 	mov	ar2,r6
      005D2F C3               [12] 1651 	clr	c
      005D30 74 7F            [12] 1652 	mov	a,#0x7f
      005D32 99               [12] 1653 	subb	a,r1
      005D33 E4               [12] 1654 	clr	a
      005D34 9A               [12] 1655 	subb	a,r2
      005D35 40 11            [24] 1656 	jc	00118$
                                   1657 ;	free result
                                   1658 ;	tmk_core/protocol/ch555/usb_ak820.c:238: D0SetupLen = value; /* applied after status-IN ACK */
      005D37 90 07 5D         [24] 1659 	mov	dptr,#_D0SetupLen
      005D3A ED               [12] 1660 	mov	a,r5
      005D3B F0               [24] 1661 	movx	@dptr,a
      005D3C EE               [12] 1662 	mov	a,r6
      005D3D A3               [24] 1663 	inc	dptr
      005D3E F0               [24] 1664 	movx	@dptr,a
                                   1665 ;	tmk_core/protocol/ch555/usb_ak820.c:239: control_phase = CTRL_STATUS_IN;
      005D3F 90 07 BB         [24] 1666 	mov	dptr,#_control_phase
      005D42 74 03            [12] 1667 	mov	a,#0x03
      005D44 F0               [24] 1668 	movx	@dptr,a
      005D45 02 63 28         [24] 1669 	ljmp	00291$
      005D48                       1670 00118$:
                                   1671 ;	tmk_core/protocol/ch555/usb_ak820.c:240: } else { control_stall(); return; }
      005D48 02 59 79         [24] 1672 	ljmp	_control_stall
                                   1673 ;	tmk_core/protocol/ch555/usb_ak820.c:242: case USB_SET_CONFIGURATION: /* HID_SET_REPORT has the same request byte. */
      005D4B                       1674 00123$:
                                   1675 ;	tmk_core/protocol/ch555/usb_ak820.c:243: if (type == 0x00 && zero_index && zero_length && value <= 1) {
      005D4B EF               [12] 1676 	mov	a,r7
      005D4C 70 3C            [24] 1677 	jnz	00145$
      005D4E 30 17 39         [24] 1678 	jnb	_control_setup_zero_index_10000_286,00145$
      005D51 30 19 36         [24] 1679 	jnb	_control_setup_zero_length_10000_286,00145$
      005D54 8D 01            [24] 1680 	mov	ar1,r5
      005D56 8E 02            [24] 1681 	mov	ar2,r6
      005D58 C3               [12] 1682 	clr	c
      005D59 74 01            [12] 1683 	mov	a,#0x01
      005D5B 99               [12] 1684 	subb	a,r1
      005D5C E4               [12] 1685 	clr	a
      005D5D 9A               [12] 1686 	subb	a,r2
      005D5E 40 2A            [24] 1687 	jc	00145$
                                   1688 ;	free result
                                   1689 ;	tmk_core/protocol/ch555/usb_ak820.c:244: endpoints_reset();
      005D60 C0 06            [24] 1690 	push	ar6
      005D62 C0 05            [24] 1691 	push	ar5
      005D64 12 59 22         [24] 1692 	lcall	_endpoints_reset
      005D67 D0 05            [24] 1693 	pop	ar5
      005D69 D0 06            [24] 1694 	pop	ar6
                                   1695 ;	tmk_core/protocol/ch555/usb_ak820.c:245: D0UsbConfig = value;
      005D6B 90 07 62         [24] 1696 	mov	dptr,#_D0UsbConfig
      005D6E ED               [12] 1697 	mov	a,r5
      005D6F F0               [24] 1698 	movx	@dptr,a
                                   1699 ;	tmk_core/protocol/ch555/usb_ak820.c:246: USB_EnumStatus = value != 0;
      005D70 A2 1A            [12] 1700 	mov	c,_control_setup_sloc0_1_0
      005D72 B3               [12] 1701 	cpl	c
      005D73 92 1B            [24] 1702 	mov	_control_setup_sloc2_1_0,c
      005D75 90 07 63         [24] 1703 	mov	dptr,#_USB_EnumStatus
      005D78 E4               [12] 1704 	clr	a
      005D79 33               [12] 1705 	rlc	a
      005D7A F0               [24] 1706 	movx	@dptr,a
                                   1707 ;	tmk_core/protocol/ch555/usb_ak820.c:247: keyboard_reset = 1;
      005D7B 90 07 8C         [24] 1708 	mov	dptr,#_keyboard_reset
      005D7E 74 01            [12] 1709 	mov	a,#0x01
      005D80 F0               [24] 1710 	movx	@dptr,a
                                   1711 ;	tmk_core/protocol/ch555/usb_ak820.c:248: control_phase = CTRL_STATUS_IN;
      005D81 90 07 BB         [24] 1712 	mov	dptr,#_control_phase
      005D84 74 03            [12] 1713 	mov	a,#0x03
      005D86 F0               [24] 1714 	movx	@dptr,a
      005D87 02 63 28         [24] 1715 	ljmp	00291$
      005D8A                       1716 00145$:
                                   1717 ;	tmk_core/protocol/ch555/usb_ak820.c:249: } else if (type == 0x21 && D0UsbConfig) {
      005D8A BF 21 02         [24] 1718 	cjne	r7,#0x21,01231$
      005D8D 80 03            [24] 1719 	sjmp	01232$
      005D8F                       1720 01231$:
      005D8F 02 59 79         [24] 1721 	ljmp	_control_stall
      005D92                       1722 01232$:
      005D92 90 07 62         [24] 1723 	mov	dptr,#_D0UsbConfig
      005D95 E0               [24] 1724 	movx	a,@dptr
      005D96 70 03            [24] 1725 	jnz	01233$
      005D98 02 59 79         [24] 1726 	ljmp	_control_stall
      005D9B                       1727 01233$:
                                   1728 ;	tmk_core/protocol/ch555/usb_ak820.c:250: if (index == RAW_INTERFACE && value == 0x0200 && D0SetupLen == RAW_EPSIZE && raw_state == RAW_IDLE) {
      005D9B BB 01 2D         [24] 1729 	cjne	r3,#0x01,00135$
      005D9E BC 00 2A         [24] 1730 	cjne	r4,#0x00,00135$
      005DA1 8D 01            [24] 1731 	mov	ar1,r5
      005DA3 8E 02            [24] 1732 	mov	ar2,r6
      005DA5 B9 00 23         [24] 1733 	cjne	r1,#0x00,00135$
      005DA8 BA 02 20         [24] 1734 	cjne	r2,#0x02,00135$
      005DAB 90 07 5D         [24] 1735 	mov	dptr,#_D0SetupLen
      005DAE E0               [24] 1736 	movx	a,@dptr
      005DAF F9               [12] 1737 	mov	r1,a
      005DB0 A3               [24] 1738 	inc	dptr
      005DB1 E0               [24] 1739 	movx	a,@dptr
      005DB2 FA               [12] 1740 	mov	r2,a
      005DB3 B9 20 15         [24] 1741 	cjne	r1,#0x20,00135$
      005DB6 BA 00 12         [24] 1742 	cjne	r2,#0x00,00135$
      005DB9 90 07 6A         [24] 1743 	mov	dptr,#_raw_state
      005DBC E0               [24] 1744 	movx	a,@dptr
      005DBD 70 0C            [24] 1745 	jnz	00135$
                                   1746 ;	tmk_core/protocol/ch555/usb_ak820.c:251: raw_state = RAW_RX;
      005DBF 90 07 6A         [24] 1747 	mov	dptr,#_raw_state
      005DC2 74 01            [12] 1748 	mov	a,#0x01
      005DC4 F0               [24] 1749 	movx	@dptr,a
                                   1750 ;	tmk_core/protocol/ch555/usb_ak820.c:252: output_kind = OUTPUT_RAW;
      005DC5 90 07 BC         [24] 1751 	mov	dptr,#_output_kind
      005DC8 F0               [24] 1752 	movx	@dptr,a
      005DC9 80 52            [24] 1753 	sjmp	00136$
      005DCB                       1754 00135$:
                                   1755 ;	tmk_core/protocol/ch555/usb_ak820.c:253: } else if (index == KEYBOARD_INTERFACE && value == 0x0200 && D0SetupLen == 1) {
      005DCB EB               [12] 1756 	mov	a,r3
      005DCC 4C               [12] 1757 	orl	a,r4
      005DCD 70 20            [24] 1758 	jnz	00130$
      005DCF 8D 01            [24] 1759 	mov	ar1,r5
      005DD1 8E 02            [24] 1760 	mov	ar2,r6
      005DD3 B9 00 19         [24] 1761 	cjne	r1,#0x00,00130$
      005DD6 BA 02 16         [24] 1762 	cjne	r2,#0x02,00130$
      005DD9 90 07 5D         [24] 1763 	mov	dptr,#_D0SetupLen
      005DDC E0               [24] 1764 	movx	a,@dptr
      005DDD F9               [12] 1765 	mov	r1,a
      005DDE A3               [24] 1766 	inc	dptr
      005DDF E0               [24] 1767 	movx	a,@dptr
      005DE0 FA               [12] 1768 	mov	r2,a
      005DE1 B9 01 0B         [24] 1769 	cjne	r1,#0x01,00130$
      005DE4 BA 00 08         [24] 1770 	cjne	r2,#0x00,00130$
                                   1771 ;	tmk_core/protocol/ch555/usb_ak820.c:254: output_kind = OUTPUT_LED;
      005DE7 90 07 BC         [24] 1772 	mov	dptr,#_output_kind
      005DEA 74 02            [12] 1773 	mov	a,#0x02
      005DEC F0               [24] 1774 	movx	@dptr,a
      005DED 80 2E            [24] 1775 	sjmp	00136$
      005DEF                       1776 00130$:
                                   1777 ;	tmk_core/protocol/ch555/usb_ak820.c:256: } else if (index == SHARED_INTERFACE && value == (0x0200 | REPORT_ID_NKRO) && D0SetupLen == 2) {
      005DEF BB 02 28         [24] 1778 	cjne	r3,#0x02,00125$
      005DF2 BC 00 25         [24] 1779 	cjne	r4,#0x00,00125$
      005DF5 8D 01            [24] 1780 	mov	ar1,r5
      005DF7 8E 02            [24] 1781 	mov	ar2,r6
      005DF9 B9 06 1E         [24] 1782 	cjne	r1,#0x06,00125$
      005DFC BA 02 1B         [24] 1783 	cjne	r2,#0x02,00125$
      005DFF 90 07 5D         [24] 1784 	mov	dptr,#_D0SetupLen
      005E02 E0               [24] 1785 	movx	a,@dptr
      005E03 F9               [12] 1786 	mov	r1,a
      005E04 A3               [24] 1787 	inc	dptr
      005E05 E0               [24] 1788 	movx	a,@dptr
      005E06 FA               [12] 1789 	mov	r2,a
      005E07 B9 02 10         [24] 1790 	cjne	r1,#0x02,00125$
      005E0A BA 00 0D         [24] 1791 	cjne	r2,#0x00,00125$
                                   1792 ;	tmk_core/protocol/ch555/usb_ak820.c:257: output_kind = OUTPUT_SHARED_LED;
      005E0D 90 07 BC         [24] 1793 	mov	dptr,#_output_kind
      005E10 74 03            [12] 1794 	mov	a,#0x03
      005E12 F0               [24] 1795 	movx	@dptr,a
                                   1796 ;	tmk_core/protocol/ch555/usb_ak820.c:258: output_report_id = REPORT_ID_NKRO;
      005E13 90 07 BD         [24] 1797 	mov	dptr,#_output_report_id
      005E16 23               [12] 1798 	rl	a
      005E17 F0               [24] 1799 	movx	@dptr,a
      005E18 80 03            [24] 1800 	sjmp	00136$
      005E1A                       1801 00125$:
                                   1802 ;	tmk_core/protocol/ch555/usb_ak820.c:260: } else { control_stall(); return; }
      005E1A 02 59 79         [24] 1803 	ljmp	_control_stall
      005E1D                       1804 00136$:
                                   1805 ;	tmk_core/protocol/ch555/usb_ak820.c:261: control_phase = CTRL_DATA_OUT;
      005E1D 90 07 BB         [24] 1806 	mov	dptr,#_control_phase
      005E20 74 04            [12] 1807 	mov	a,#0x04
      005E22 F0               [24] 1808 	movx	@dptr,a
                                   1809 ;	tmk_core/protocol/ch555/usb_ak820.c:262: return; /* OUT data must arrive before status-IN becomes ACK */
      005E23 22               [24] 1810 	ret
                                   1811 ;	tmk_core/protocol/ch555/usb_ak820.c:263: } else { control_stall(); return; }
      005E24 02 59 79         [24] 1812 	ljmp	_control_stall
                                   1813 ;	tmk_core/protocol/ch555/usb_ak820.c:265: case USB_GET_CONFIGURATION:
      005E27                       1814 00150$:
                                   1815 ;	tmk_core/protocol/ch555/usb_ak820.c:266: if (type == 0x80 && zero_index && zero_value && D0SetupLen == 1) {
      005E27 BF 80 2A         [24] 1816 	cjne	r7,#0x80,00152$
      005E2A 30 17 27         [24] 1817 	jnb	_control_setup_zero_index_10000_286,00152$
      005E2D 30 18 24         [24] 1818 	jnb	_control_setup_zero_value_10000_286,00152$
      005E30 90 07 5D         [24] 1819 	mov	dptr,#_D0SetupLen
      005E33 E0               [24] 1820 	movx	a,@dptr
      005E34 F9               [12] 1821 	mov	r1,a
      005E35 A3               [24] 1822 	inc	dptr
      005E36 E0               [24] 1823 	movx	a,@dptr
      005E37 FA               [12] 1824 	mov	r2,a
      005E38 B9 01 19         [24] 1825 	cjne	r1,#0x01,00152$
      005E3B BA 00 16         [24] 1826 	cjne	r2,#0x00,00152$
                                   1827 ;	tmk_core/protocol/ch555/usb_ak820.c:267: pD0_EP0_BUF[0] = D0UsbConfig;
      005E3E 90 07 62         [24] 1828 	mov	dptr,#_D0UsbConfig
      005E41 E0               [24] 1829 	movx	a,@dptr
      005E42 90 10 00         [24] 1830 	mov	dptr,#0x1000
      005E45 F0               [24] 1831 	movx	@dptr,a
                                   1832 ;	tmk_core/protocol/ch555/usb_ak820.c:268: D0_EP0T_L = 1;
      005E46 90 22 08         [24] 1833 	mov	dptr,#0x2208
      005E49 74 01            [12] 1834 	mov	a,#0x01
      005E4B F0               [24] 1835 	movx	@dptr,a
                                   1836 ;	tmk_core/protocol/ch555/usb_ak820.c:269: control_phase = CTRL_STATUS_OUT;
      005E4C 90 07 BB         [24] 1837 	mov	dptr,#_control_phase
      005E4F 04               [12] 1838 	inc	a
      005E50 F0               [24] 1839 	movx	@dptr,a
      005E51 02 63 28         [24] 1840 	ljmp	00291$
      005E54                       1841 00152$:
                                   1842 ;	tmk_core/protocol/ch555/usb_ak820.c:270: } else { control_stall(); return; }
      005E54 02 59 79         [24] 1843 	ljmp	_control_stall
                                   1844 ;	tmk_core/protocol/ch555/usb_ak820.c:272: case USB_GET_INTERFACE: /* DEF_USB_SET_IDLE has the same request byte. */
      005E57                       1845 00157$:
                                   1846 ;	tmk_core/protocol/ch555/usb_ak820.c:273: if (type == 0x81 && valid_interface && zero_value && D0SetupLen == 1 && D0UsbConfig) {
      005E57 BF 81 2C         [24] 1847 	cjne	r7,#0x81,00167$
      005E5A 30 16 29         [24] 1848 	jnb	_control_setup_valid_interface_10000_286,00167$
      005E5D 30 18 26         [24] 1849 	jnb	_control_setup_zero_value_10000_286,00167$
      005E60 90 07 5D         [24] 1850 	mov	dptr,#_D0SetupLen
      005E63 E0               [24] 1851 	movx	a,@dptr
      005E64 F9               [12] 1852 	mov	r1,a
      005E65 A3               [24] 1853 	inc	dptr
      005E66 E0               [24] 1854 	movx	a,@dptr
      005E67 FA               [12] 1855 	mov	r2,a
      005E68 B9 01 1B         [24] 1856 	cjne	r1,#0x01,00167$
      005E6B BA 00 18         [24] 1857 	cjne	r2,#0x00,00167$
      005E6E 90 07 62         [24] 1858 	mov	dptr,#_D0UsbConfig
      005E71 E0               [24] 1859 	movx	a,@dptr
      005E72 60 12            [24] 1860 	jz	00167$
                                   1861 ;	tmk_core/protocol/ch555/usb_ak820.c:274: pD0_EP0_BUF[0] = 0;
      005E74 90 10 00         [24] 1862 	mov	dptr,#0x1000
      005E77 E4               [12] 1863 	clr	a
      005E78 F0               [24] 1864 	movx	@dptr,a
                                   1865 ;	tmk_core/protocol/ch555/usb_ak820.c:275: D0_EP0T_L = 1;
      005E79 90 22 08         [24] 1866 	mov	dptr,#0x2208
      005E7C 04               [12] 1867 	inc	a
      005E7D F0               [24] 1868 	movx	@dptr,a
                                   1869 ;	tmk_core/protocol/ch555/usb_ak820.c:276: control_phase = CTRL_STATUS_OUT;
      005E7E 90 07 BB         [24] 1870 	mov	dptr,#_control_phase
      005E81 04               [12] 1871 	inc	a
      005E82 F0               [24] 1872 	movx	@dptr,a
      005E83 02 63 28         [24] 1873 	ljmp	00291$
      005E86                       1874 00167$:
                                   1875 ;	tmk_core/protocol/ch555/usb_ak820.c:277: } else if (valid_interface && D0UsbConfig && type == 0x21 && zero_length) {
      005E86 30 16 1E         [24] 1876 	jnb	_control_setup_valid_interface_10000_286,00161$
      005E89 90 07 62         [24] 1877 	mov	dptr,#_D0UsbConfig
      005E8C E0               [24] 1878 	movx	a,@dptr
      005E8D 60 18            [24] 1879 	jz	00161$
      005E8F BF 21 15         [24] 1880 	cjne	r7,#0x21,00161$
      005E92 30 19 12         [24] 1881 	jnb	_control_setup_zero_length_10000_286,00161$
                                   1882 ;	tmk_core/protocol/ch555/usb_ak820.c:278: if (index == KEYBOARD_INTERFACE) keyboard_idle = value >> 8;
      005E95 EB               [12] 1883 	mov	a,r3
      005E96 4C               [12] 1884 	orl	a,r4
      005E97 70 05            [24] 1885 	jnz	00159$
      005E99 90 06 3A         [24] 1886 	mov	dptr,#_keyboard_idle
      005E9C EE               [12] 1887 	mov	a,r6
      005E9D F0               [24] 1888 	movx	@dptr,a
      005E9E                       1889 00159$:
                                   1890 ;	tmk_core/protocol/ch555/usb_ak820.c:279: control_phase = CTRL_STATUS_IN;
      005E9E 90 07 BB         [24] 1891 	mov	dptr,#_control_phase
      005EA1 74 03            [12] 1892 	mov	a,#0x03
      005EA3 F0               [24] 1893 	movx	@dptr,a
      005EA4 02 63 28         [24] 1894 	ljmp	00291$
      005EA7                       1895 00161$:
                                   1896 ;	tmk_core/protocol/ch555/usb_ak820.c:280: } else { control_stall(); return; }
      005EA7 02 59 79         [24] 1897 	ljmp	_control_stall
                                   1898 ;	tmk_core/protocol/ch555/usb_ak820.c:282: case USB_SET_INTERFACE: /* DEF_USB_SET_PROTOCOL has the same request byte. */
      005EAA                       1899 00173$:
                                   1900 ;	tmk_core/protocol/ch555/usb_ak820.c:283: if (type == 0x01 && valid_interface && zero_value && zero_length && D0UsbConfig) {
      005EAA BF 01 18         [24] 1901 	cjne	r7,#0x01,00182$
      005EAD 30 16 15         [24] 1902 	jnb	_control_setup_valid_interface_10000_286,00182$
      005EB0 30 18 12         [24] 1903 	jnb	_control_setup_zero_value_10000_286,00182$
      005EB3 30 19 0F         [24] 1904 	jnb	_control_setup_zero_length_10000_286,00182$
      005EB6 90 07 62         [24] 1905 	mov	dptr,#_D0UsbConfig
      005EB9 E0               [24] 1906 	movx	a,@dptr
      005EBA 60 09            [24] 1907 	jz	00182$
                                   1908 ;	tmk_core/protocol/ch555/usb_ak820.c:284: control_phase = CTRL_STATUS_IN;
      005EBC 90 07 BB         [24] 1909 	mov	dptr,#_control_phase
      005EBF 74 03            [12] 1910 	mov	a,#0x03
      005EC1 F0               [24] 1911 	movx	@dptr,a
      005EC2 02 63 28         [24] 1912 	ljmp	00291$
      005EC5                       1913 00182$:
                                   1914 ;	tmk_core/protocol/ch555/usb_ak820.c:285: } else if (index == KEYBOARD_INTERFACE && D0UsbConfig && type == 0x21 && zero_length && value <= 1) {
      005EC5 EB               [12] 1915 	mov	a,r3
      005EC6 4C               [12] 1916 	orl	a,r4
      005EC7 70 2C            [24] 1917 	jnz	00175$
      005EC9 90 07 62         [24] 1918 	mov	dptr,#_D0UsbConfig
      005ECC E0               [24] 1919 	movx	a,@dptr
      005ECD 60 26            [24] 1920 	jz	00175$
      005ECF BF 21 23         [24] 1921 	cjne	r7,#0x21,00175$
      005ED2 30 19 20         [24] 1922 	jnb	_control_setup_zero_length_10000_286,00175$
      005ED5 8D 01            [24] 1923 	mov	ar1,r5
      005ED7 8E 02            [24] 1924 	mov	ar2,r6
      005ED9 C3               [12] 1925 	clr	c
      005EDA 74 01            [12] 1926 	mov	a,#0x01
      005EDC 99               [12] 1927 	subb	a,r1
      005EDD E4               [12] 1928 	clr	a
      005EDE 9A               [12] 1929 	subb	a,r2
      005EDF 40 14            [24] 1930 	jc	00175$
                                   1931 ;	free result
                                   1932 ;	tmk_core/protocol/ch555/usb_ak820.c:286: keyboard_protocol = value;
      005EE1 90 0D AC         [24] 1933 	mov	dptr,#_keyboard_protocol
      005EE4 ED               [12] 1934 	mov	a,r5
      005EE5 F0               [24] 1935 	movx	@dptr,a
                                   1936 ;	tmk_core/protocol/ch555/usb_ak820.c:287: keyboard_reset = 1;
      005EE6 90 07 8C         [24] 1937 	mov	dptr,#_keyboard_reset
      005EE9 74 01            [12] 1938 	mov	a,#0x01
      005EEB F0               [24] 1939 	movx	@dptr,a
                                   1940 ;	tmk_core/protocol/ch555/usb_ak820.c:288: control_phase = CTRL_STATUS_IN;
      005EEC 90 07 BB         [24] 1941 	mov	dptr,#_control_phase
      005EEF 74 03            [12] 1942 	mov	a,#0x03
      005EF1 F0               [24] 1943 	movx	@dptr,a
      005EF2 02 63 28         [24] 1944 	ljmp	00291$
      005EF5                       1945 00175$:
                                   1946 ;	tmk_core/protocol/ch555/usb_ak820.c:289: } else { control_stall(); return; }
      005EF5 02 59 79         [24] 1947 	ljmp	_control_stall
                                   1948 ;	tmk_core/protocol/ch555/usb_ak820.c:291: case USB_GET_STATUS:
      005EF8                       1949 00188$:
                                   1950 ;	tmk_core/protocol/ch555/usb_ak820.c:292: if (zero_value && D0SetupLen == 2 &&
      005EF8 20 18 03         [24] 1951 	jb	_control_setup_zero_value_10000_286,01283$
      005EFB 02 59 79         [24] 1952 	ljmp	_control_stall
      005EFE                       1953 01283$:
      005EFE 90 07 5D         [24] 1954 	mov	dptr,#_D0SetupLen
      005F01 E0               [24] 1955 	movx	a,@dptr
      005F02 F9               [12] 1956 	mov	r1,a
      005F03 A3               [24] 1957 	inc	dptr
      005F04 E0               [24] 1958 	movx	a,@dptr
      005F05 FA               [12] 1959 	mov	r2,a
      005F06 B9 02 05         [24] 1960 	cjne	r1,#0x02,01284$
      005F09 BA 00 02         [24] 1961 	cjne	r2,#0x00,01284$
      005F0C 80 03            [24] 1962 	sjmp	01285$
      005F0E                       1963 01284$:
      005F0E 02 59 79         [24] 1964 	ljmp	_control_stall
      005F11                       1965 01285$:
                                   1966 ;	tmk_core/protocol/ch555/usb_ak820.c:293: ((type == 0x80 && zero_index) || (type == 0x81 && valid_interface && D0UsbConfig) ||
      005F11 E4               [12] 1967 	clr	a
      005F12 BF 80 01         [24] 1968 	cjne	r7,#0x80,01286$
      005F15 04               [12] 1969 	inc	a
      005F16                       1970 01286$:
      005F16 FA               [12] 1971 	mov	r2,a
      005F17 60 03            [24] 1972 	jz	00196$
      005F19 20 17 35         [24] 1973 	jb	_control_setup_zero_index_10000_286,00189$
      005F1C                       1974 00196$:
      005F1C BF 81 09         [24] 1975 	cjne	r7,#0x81,00202$
      005F1F 30 16 06         [24] 1976 	jnb	_control_setup_valid_interface_10000_286,00202$
      005F22 90 07 62         [24] 1977 	mov	dptr,#_D0UsbConfig
      005F25 E0               [24] 1978 	movx	a,@dptr
      005F26 70 29            [24] 1979 	jnz	00189$
      005F28                       1980 00202$:
                                   1981 ;	tmk_core/protocol/ch555/usb_ak820.c:294: (type == 0x82 && D0UsbConfig && (index == 0 || index == 0x80 || (index >= 0x81 && index <= 0x83))))) {
      005F28 BF 82 70         [24] 1982 	cjne	r7,#0x82,00190$
      005F2B 90 07 62         [24] 1983 	mov	dptr,#_D0UsbConfig
      005F2E E0               [24] 1984 	movx	a,@dptr
      005F2F 60 6A            [24] 1985 	jz	00190$
      005F31 EB               [12] 1986 	mov	a,r3
      005F32 4C               [12] 1987 	orl	a,r4
      005F33 60 1C            [24] 1988 	jz	00189$
      005F35 8B 00            [24] 1989 	mov	ar0,r3
      005F37 8C 01            [24] 1990 	mov	ar1,r4
      005F39 B8 80 05         [24] 1991 	cjne	r0,#0x80,01298$
      005F3C B9 00 02         [24] 1992 	cjne	r1,#0x00,01298$
      005F3F 80 10            [24] 1993 	sjmp	00189$
      005F41                       1994 01298$:
      005F41 C3               [12] 1995 	clr	c
      005F42 E8               [12] 1996 	mov	a,r0
      005F43 94 81            [12] 1997 	subb	a,#0x81
      005F45 E9               [12] 1998 	mov	a,r1
      005F46 94 00            [12] 1999 	subb	a,#0x00
      005F48 40 51            [24] 2000 	jc	00190$
      005F4A 74 83            [12] 2001 	mov	a,#0x83
      005F4C 98               [12] 2002 	subb	a,r0
      005F4D E4               [12] 2003 	clr	a
      005F4E 99               [12] 2004 	subb	a,r1
      005F4F 40 4A            [24] 2005 	jc	00190$
                                   2006 ;	free result
      005F51                       2007 00189$:
                                   2008 ;	tmk_core/protocol/ch555/usb_ak820.c:295: endpoint = index & 7;
      005F51 8B 01            [24] 2009 	mov	ar1,r3
      005F53 53 01 07         [24] 2010 	anl	ar1,#0x07
                                   2011 ;	tmk_core/protocol/ch555/usb_ak820.c:296: pD0_EP0_BUF[0] = type == 0x80 ? ((USB_SleepStatus & 1) << 1) :
      005F56 EA               [12] 2012 	mov	a,r2
      005F57 60 0B            [24] 2013 	jz	00308$
      005F59 90 07 64         [24] 2014 	mov	dptr,#_USB_SleepStatus
      005F5C E0               [24] 2015 	movx	a,@dptr
      005F5D 54 01            [12] 2016 	anl	a,#0x01
      005F5F 25 E0            [12] 2017 	add	a,acc
      005F61 FA               [12] 2018 	mov	r2,a
      005F62 80 22            [24] 2019 	sjmp	00309$
      005F64                       2020 00308$:
                                   2021 ;	tmk_core/protocol/ch555/usb_ak820.c:297: ((type == 0x82 && endpoint && (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_STALL) ? 1 : 0);
      005F64 BF 82 1B         [24] 2022 	cjne	r7,#0x82,00310$
      005F67 E9               [12] 2023 	mov	a,r1
      005F68 60 18            [24] 2024 	jz	00310$
      005F6A 89 00            [24] 2025 	mov	ar0,r1
      005F6C 79 00            [12] 2026 	mov	r1,#0x00
      005F6E 74 22            [12] 2027 	mov	a,#0x22
      005F70 29               [12] 2028 	add	a, r1
      005F71 F9               [12] 2029 	mov	r1,a
      005F72 88 82            [24] 2030 	mov	dpl,r0
      005F74 89 83            [24] 2031 	mov	dph,r1
      005F76 E0               [24] 2032 	movx	a,@dptr
      005F77 F9               [12] 2033 	mov	r1,a
      005F78 53 01 03         [24] 2034 	anl	ar1,#0x03
      005F7B B9 03 04         [24] 2035 	cjne	r1,#0x03,00310$
      005F7E 79 01            [12] 2036 	mov	r1,#0x01
      005F80 80 02            [24] 2037 	sjmp	00311$
      005F82                       2038 00310$:
      005F82 79 00            [12] 2039 	mov	r1,#0x00
      005F84                       2040 00311$:
      005F84 89 02            [24] 2041 	mov	ar2,r1
      005F86                       2042 00309$:
      005F86 90 10 00         [24] 2043 	mov	dptr,#0x1000
      005F89 EA               [12] 2044 	mov	a,r2
      005F8A F0               [24] 2045 	movx	@dptr,a
                                   2046 ;	tmk_core/protocol/ch555/usb_ak820.c:298: pD0_EP0_BUF[1] = 0;
      005F8B A3               [24] 2047 	inc	dptr
      005F8C E4               [12] 2048 	clr	a
      005F8D F0               [24] 2049 	movx	@dptr,a
                                   2050 ;	tmk_core/protocol/ch555/usb_ak820.c:299: D0_EP0T_L = 2;
      005F8E 90 22 08         [24] 2051 	mov	dptr,#0x2208
      005F91 74 02            [12] 2052 	mov	a,#0x02
      005F93 F0               [24] 2053 	movx	@dptr,a
                                   2054 ;	tmk_core/protocol/ch555/usb_ak820.c:300: control_phase = CTRL_STATUS_OUT;
      005F94 90 07 BB         [24] 2055 	mov	dptr,#_control_phase
      005F97 F0               [24] 2056 	movx	@dptr,a
      005F98 02 63 28         [24] 2057 	ljmp	00291$
      005F9B                       2058 00190$:
                                   2059 ;	tmk_core/protocol/ch555/usb_ak820.c:301: } else { control_stall(); return; }
      005F9B 02 59 79         [24] 2060 	ljmp	_control_stall
                                   2061 ;	tmk_core/protocol/ch555/usb_ak820.c:304: case USB_SET_FEATURE: /* DEF_USB_GET_PROTOCOL has the same request byte. */
      005F9E                       2062 00205$:
                                   2063 ;	tmk_core/protocol/ch555/usb_ak820.c:305: if (zero_length && D0UsbConfig) {
      005F9E 20 19 03         [24] 2064 	jb	_control_setup_zero_length_10000_286,01307$
      005FA1 02 60 31         [24] 2065 	ljmp	00279$
      005FA4                       2066 01307$:
      005FA4 90 07 62         [24] 2067 	mov	dptr,#_D0UsbConfig
      005FA7 E0               [24] 2068 	movx	a,@dptr
      005FA8 70 03            [24] 2069 	jnz	01308$
      005FAA 02 60 31         [24] 2070 	ljmp	00279$
      005FAD                       2071 01308$:
                                   2072 ;	tmk_core/protocol/ch555/usb_ak820.c:306: if (type == 0x00 && value == 1 && zero_index) {
      005FAD EF               [12] 2073 	mov	a,r7
      005FAE 70 29            [24] 2074 	jnz	00218$
      005FB0 8D 01            [24] 2075 	mov	ar1,r5
      005FB2 8E 02            [24] 2076 	mov	ar2,r6
      005FB4 B9 01 22         [24] 2077 	cjne	r1,#0x01,00218$
      005FB7 BA 00 1F         [24] 2078 	cjne	r2,#0x00,00218$
      005FBA 30 17 1C         [24] 2079 	jnb	_control_setup_zero_index_10000_286,00218$
                                   2080 ;	tmk_core/protocol/ch555/usb_ak820.c:307: if (D0SetupReqCode == USB_SET_FEATURE) USB_SleepStatus |= 1;
      005FBD 90 07 5C         [24] 2081 	mov	dptr,#_D0SetupReqCode
      005FC0 E0               [24] 2082 	movx	a,@dptr
      005FC1 FA               [12] 2083 	mov	r2,a
      005FC2 BA 03 0A         [24] 2084 	cjne	r2,#0x03,00207$
      005FC5 90 07 64         [24] 2085 	mov	dptr,#_USB_SleepStatus
      005FC8 E0               [24] 2086 	movx	a,@dptr
      005FC9 43 E0 01         [24] 2087 	orl	acc,#0x01
      005FCC F0               [24] 2088 	movx	@dptr,a
      005FCD 80 59            [24] 2089 	sjmp	00219$
      005FCF                       2090 00207$:
                                   2091 ;	tmk_core/protocol/ch555/usb_ak820.c:308: else USB_SleepStatus &= ~1;
      005FCF 90 07 64         [24] 2092 	mov	dptr,#_USB_SleepStatus
      005FD2 E0               [24] 2093 	movx	a,@dptr
      005FD3 53 E0 FE         [24] 2094 	anl	acc,#0xfe
      005FD6 F0               [24] 2095 	movx	@dptr,a
      005FD7 80 4F            [24] 2096 	sjmp	00219$
      005FD9                       2097 00218$:
                                   2098 ;	tmk_core/protocol/ch555/usb_ak820.c:309: } else if (type == 0x02 && zero_value && index >= 0x81 && index <= 0x83) {
      005FD9 BF 02 49         [24] 2099 	cjne	r7,#0x02,00212$
      005FDC 30 18 46         [24] 2100 	jnb	_control_setup_zero_value_10000_286,00212$
      005FDF 8B 01            [24] 2101 	mov	ar1,r3
      005FE1 8C 02            [24] 2102 	mov	ar2,r4
      005FE3 C3               [12] 2103 	clr	c
      005FE4 E9               [12] 2104 	mov	a,r1
      005FE5 94 81            [12] 2105 	subb	a,#0x81
      005FE7 EA               [12] 2106 	mov	a,r2
      005FE8 94 00            [12] 2107 	subb	a,#0x00
      005FEA 40 39            [24] 2108 	jc	00212$
      005FEC 74 83            [12] 2109 	mov	a,#0x83
      005FEE 99               [12] 2110 	subb	a,r1
      005FEF E4               [12] 2111 	clr	a
      005FF0 9A               [12] 2112 	subb	a,r2
      005FF1 40 32            [24] 2113 	jc	00212$
                                   2114 ;	free result
                                   2115 ;	tmk_core/protocol/ch555/usb_ak820.c:310: endpoint = index & 7;
      005FF3 8B 02            [24] 2116 	mov	ar2,r3
      005FF5 53 02 07         [24] 2117 	anl	ar2,#0x07
                                   2118 ;	tmk_core/protocol/ch555/usb_ak820.c:312: EP_RESPONSE(endpoint) = bUEP_X_AUTO_TOG | (D0SetupReqCode == USB_SET_FEATURE ? UEP_X_RES_STALL : UEP_X_RES_NAK);
      005FF8 8A 00            [24] 2119 	mov	ar0,r2
      005FFA 79 00            [12] 2120 	mov	r1,#0x00
      005FFC 74 22            [12] 2121 	mov	a,#0x22
      005FFE 29               [12] 2122 	add	a, r1
      005FFF F9               [12] 2123 	mov	r1,a
      006000 88 17            [24] 2124 	mov	_control_setup_sloc3_1_0,r0
      006002 89 18            [24] 2125 	mov	(_control_setup_sloc3_1_0 + 1),r1
      006004 90 07 5C         [24] 2126 	mov	dptr,#_D0SetupReqCode
      006007 E0               [24] 2127 	movx	a,@dptr
      006008 F9               [12] 2128 	mov	r1,a
      006009 B9 03 04         [24] 2129 	cjne	r1,#0x03,00318$
      00600C 79 03            [12] 2130 	mov	r1,#0x03
      00600E 80 02            [24] 2131 	sjmp	00319$
      006010                       2132 00318$:
      006010 79 02            [12] 2133 	mov	r1,#0x02
      006012                       2134 00319$:
      006012 43 01 10         [24] 2135 	orl	ar1,#0x10
      006015 85 17 82         [24] 2136 	mov	dpl,_control_setup_sloc3_1_0
      006018 85 18 83         [24] 2137 	mov	dph,(_control_setup_sloc3_1_0 + 1)
      00601B E9               [12] 2138 	mov	a,r1
      00601C F0               [24] 2139 	movx	@dptr,a
                                   2140 ;	tmk_core/protocol/ch555/usb_ak820.c:313: if (endpoint == RAW_IN_EPNUM) raw_complete();
      00601D BA 03 08         [24] 2141 	cjne	r2,#0x03,00219$
      006020 12 59 05         [24] 2142 	lcall	_raw_complete
      006023 80 03            [24] 2143 	sjmp	00219$
      006025                       2144 00212$:
                                   2145 ;	tmk_core/protocol/ch555/usb_ak820.c:314: } else { control_stall(); return; }
      006025 02 59 79         [24] 2146 	ljmp	_control_stall
      006028                       2147 00219$:
                                   2148 ;	tmk_core/protocol/ch555/usb_ak820.c:315: control_phase = CTRL_STATUS_IN;
      006028 90 07 BB         [24] 2149 	mov	dptr,#_control_phase
      00602B 74 03            [12] 2150 	mov	a,#0x03
      00602D F0               [24] 2151 	movx	@dptr,a
      00602E 02 63 28         [24] 2152 	ljmp	00291$
      006031                       2153 00279$:
                                   2154 ;	tmk_core/protocol/ch555/usb_ak820.c:316: } else if (type == 0xa1 && D0SetupReqCode == HID_GET_REPORT && D0UsbConfig && D0SetupLen) {
      006031 E4               [12] 2155 	clr	a
      006032 BF A1 01         [24] 2156 	cjne	r7,#0xa1,01324$
      006035 04               [12] 2157 	inc	a
      006036                       2158 01324$:
      006036 FA               [12] 2159 	mov	r2,a
      006037 70 03            [24] 2160 	jnz	01326$
      006039 02 62 A3         [24] 2161 	ljmp	00273$
      00603C                       2162 01326$:
      00603C 90 07 5C         [24] 2163 	mov	dptr,#_D0SetupReqCode
      00603F E0               [24] 2164 	movx	a,@dptr
      006040 F9               [12] 2165 	mov	r1,a
      006041 B9 01 02         [24] 2166 	cjne	r1,#0x01,01327$
      006044 80 03            [24] 2167 	sjmp	01328$
      006046                       2168 01327$:
      006046 02 62 A3         [24] 2169 	ljmp	00273$
      006049                       2170 01328$:
      006049 90 07 62         [24] 2171 	mov	dptr,#_D0UsbConfig
      00604C E0               [24] 2172 	movx	a,@dptr
      00604D 70 03            [24] 2173 	jnz	01329$
      00604F 02 62 A3         [24] 2174 	ljmp	00273$
      006052                       2175 01329$:
      006052 90 07 5D         [24] 2176 	mov	dptr,#_D0SetupLen
      006055 E0               [24] 2177 	movx	a,@dptr
      006056 F8               [12] 2178 	mov	r0,a
      006057 A3               [24] 2179 	inc	dptr
      006058 E0               [24] 2180 	movx	a,@dptr
      006059 48               [12] 2181 	orl	a,r0
      00605A 70 03            [24] 2182 	jnz	01330$
      00605C 02 62 A3         [24] 2183 	ljmp	00273$
      00605F                       2184 01330$:
                                   2185 ;	tmk_core/protocol/ch555/usb_ak820.c:317: report_id = value;
      00605F C0 03            [24] 2186 	push	ar3
      006061 C0 04            [24] 2187 	push	ar4
      006063 8D 01            [24] 2188 	mov	ar1,r5
                                   2189 ;	tmk_core/protocol/ch555/usb_ak820.c:318: if ((value >> 8) == 1 && index == KEYBOARD_INTERFACE && !report_id) {
      006065 8E 00            [24] 2190 	mov	ar0,r6
      006067 B8 01 03         [24] 2191 	cjne	r0,#0x01,01331$
      00606A E8               [12] 2192 	mov	a,r0
      00606B 80 01            [24] 2193 	sjmp	01332$
      00606D                       2194 01331$:
      00606D E4               [12] 2195 	clr	a
      00606E                       2196 01332$:
      00606E F5 17            [12] 2197 	mov	_control_setup_sloc3_1_0,a
      006070 D0 04            [24] 2198 	pop	ar4
      006072 D0 03            [24] 2199 	pop	ar3
      006074 E5 17            [12] 2200 	mov	a,_control_setup_sloc3_1_0
      006076 60 17            [24] 2201 	jz	00251$
      006078 EB               [12] 2202 	mov	a,r3
      006079 4C               [12] 2203 	orl	a,r4
      00607A 70 13            [24] 2204 	jnz	00251$
      00607C E9               [12] 2205 	mov	a,r1
      00607D 70 10            [24] 2206 	jnz	00251$
                                   2207 ;	tmk_core/protocol/ch555/usb_ak820.c:319: length = KEYBOARD_EPSIZE;
      00607F 90 07 C5         [24] 2208 	mov	dptr,#_control_setup_length_10000_286
      006082 74 08            [12] 2209 	mov	a,#0x08
      006084 F0               [24] 2210 	movx	@dptr,a
      006085 E4               [12] 2211 	clr	a
      006086 A3               [24] 2212 	inc	dptr
      006087 F0               [24] 2213 	movx	@dptr,a
                                   2214 ;	tmk_core/protocol/ch555/usb_ak820.c:320: offset = SNAPSHOT_KEYBOARD;
      006088 90 07 C7         [24] 2215 	mov	dptr,#_control_setup_offset_10000_286
      00608B F0               [24] 2216 	movx	@dptr,a
      00608C 02 62 13         [24] 2217 	ljmp	00252$
      00608F                       2218 00251$:
                                   2219 ;	tmk_core/protocol/ch555/usb_ak820.c:321: } else if ((value >> 8) == 1 && index == SHARED_INTERFACE &&
      00608F E5 17            [12] 2220 	mov	a,_control_setup_sloc3_1_0
      006091 60 27            [24] 2221 	jz	00245$
      006093 BB 02 24         [24] 2222 	cjne	r3,#0x02,00245$
      006096 BC 00 21         [24] 2223 	cjne	r4,#0x00,00245$
                                   2224 ;	tmk_core/protocol/ch555/usb_ak820.c:322: report_id < sizeof(shared_lengths) && shared_lengths[report_id]) {
      006099 B9 07 00         [24] 2225 	cjne	r1,#0x07,01339$
      00609C                       2226 01339$:
      00609C 50 1C            [24] 2227 	jnc	00245$
      00609E E9               [12] 2228 	mov	a,r1
      00609F 90 B7 14         [24] 2229 	mov	dptr,#_shared_lengths
      0060A2 93               [24] 2230 	movc	a,@a+dptr
      0060A3 F8               [12] 2231 	mov	r0,a
      0060A4 60 14            [24] 2232 	jz	00245$
                                   2233 ;	tmk_core/protocol/ch555/usb_ak820.c:323: length = shared_lengths[report_id];
      0060A6 90 07 C5         [24] 2234 	mov	dptr,#_control_setup_length_10000_286
      0060A9 E8               [12] 2235 	mov	a,r0
      0060AA F0               [24] 2236 	movx	@dptr,a
      0060AB E4               [12] 2237 	clr	a
      0060AC A3               [24] 2238 	inc	dptr
      0060AD F0               [24] 2239 	movx	@dptr,a
                                   2240 ;	tmk_core/protocol/ch555/usb_ak820.c:324: offset = shared_offsets[report_id];
      0060AE E9               [12] 2241 	mov	a,r1
      0060AF 90 B7 0D         [24] 2242 	mov	dptr,#_shared_offsets
      0060B2 93               [24] 2243 	movc	a,@a+dptr
      0060B3 90 07 C7         [24] 2244 	mov	dptr,#_control_setup_offset_10000_286
      0060B6 F0               [24] 2245 	movx	@dptr,a
      0060B7 02 62 13         [24] 2246 	ljmp	00252$
      0060BA                       2247 00245$:
                                   2248 ;	tmk_core/protocol/ch555/usb_ak820.c:325: } else if ((value >> 8) == 1 && index == RAW_INTERFACE && !report_id) {
      0060BA E5 17            [12] 2249 	mov	a,_control_setup_sloc3_1_0
      0060BC 60 7A            [24] 2250 	jz	00240$
      0060BE BB 01 77         [24] 2251 	cjne	r3,#0x01,00240$
      0060C1 BC 00 74         [24] 2252 	cjne	r4,#0x00,00240$
      0060C4 E9               [12] 2253 	mov	a,r1
      0060C5 70 71            [24] 2254 	jnz	00240$
                                   2255 ;	tmk_core/protocol/ch555/usb_ak820.c:326: length = D0SetupLen < RAW_EPSIZE ? D0SetupLen : RAW_EPSIZE;
      0060C7 90 07 5D         [24] 2256 	mov	dptr,#_D0SetupLen
      0060CA E0               [24] 2257 	movx	a,@dptr
      0060CB F8               [12] 2258 	mov	r0,a
      0060CC A3               [24] 2259 	inc	dptr
      0060CD E0               [24] 2260 	movx	a,@dptr
      0060CE F9               [12] 2261 	mov	r1,a
      0060CF C3               [12] 2262 	clr	c
      0060D0 E8               [12] 2263 	mov	a,r0
      0060D1 94 20            [12] 2264 	subb	a,#0x20
      0060D3 E9               [12] 2265 	mov	a,r1
      0060D4 94 00            [12] 2266 	subb	a,#0x00
      0060D6 50 0A            [24] 2267 	jnc	00320$
      0060D8 90 07 5D         [24] 2268 	mov	dptr,#_D0SetupLen
      0060DB E0               [24] 2269 	movx	a,@dptr
      0060DC F8               [12] 2270 	mov	r0,a
      0060DD A3               [24] 2271 	inc	dptr
      0060DE E0               [24] 2272 	movx	a,@dptr
      0060DF F9               [12] 2273 	mov	r1,a
      0060E0 80 04            [24] 2274 	sjmp	00321$
      0060E2                       2275 00320$:
      0060E2 78 20            [12] 2276 	mov	r0,#0x20
      0060E4 79 00            [12] 2277 	mov	r1,#0x00
      0060E6                       2278 00321$:
                                   2279 ;	tmk_core/protocol/ch555/usb_ak820.c:327: for (i = 0; i < length; ++i) pD0_EP0_BUF[i] = pUSB_BUF_DEV0[UX_EP3_ADDR + i];
      0060E6 75 17 00         [24] 2280 	mov	_control_setup_sloc3_1_0,#0x00
      0060E9                       2281 00293$:
      0060E9 C0 03            [24] 2282 	push	ar3
      0060EB C0 04            [24] 2283 	push	ar4
      0060ED AB 17            [24] 2284 	mov	r3,_control_setup_sloc3_1_0
      0060EF 7C 00            [12] 2285 	mov	r4,#0x00
      0060F1 C3               [12] 2286 	clr	c
      0060F2 EB               [12] 2287 	mov	a,r3
      0060F3 98               [12] 2288 	subb	a,r0
      0060F4 EC               [12] 2289 	mov	a,r4
      0060F5 99               [12] 2290 	subb	a,r1
      0060F6 D0 04            [24] 2291 	pop	ar4
      0060F8 D0 03            [24] 2292 	pop	ar3
      0060FA 50 32            [24] 2293 	jnc	00222$
      0060FC C0 00            [24] 2294 	push	ar0
      0060FE C0 01            [24] 2295 	push	ar1
      006100 85 17 19         [24] 2296 	mov	_control_setup_sloc4_1_0,_control_setup_sloc3_1_0
      006103 74 10            [12] 2297 	mov	a,#0x10
      006105 24 00            [12] 2298 	add	a, #0x00
      006107 F5 1A            [12] 2299 	mov	(_control_setup_sloc4_1_0 + 1),a
      006109 A8 17            [24] 2300 	mov	r0,_control_setup_sloc3_1_0
      00610B 79 00            [12] 2301 	mov	r1,#0x00
      00610D 74 C0            [12] 2302 	mov	a,#0xc0
      00610F 28               [12] 2303 	add	a, r0
      006110 F8               [12] 2304 	mov	r0,a
      006111 E4               [12] 2305 	clr	a
      006112 39               [12] 2306 	addc	a, r1
      006113 F9               [12] 2307 	mov	r1,a
      006114 88 82            [24] 2308 	mov	dpl,r0
      006116 74 10            [12] 2309 	mov	a,#0x10
      006118 29               [12] 2310 	add	a, r1
      006119 F5 83            [12] 2311 	mov	dph,a
      00611B E0               [24] 2312 	movx	a,@dptr
      00611C 85 19 82         [24] 2313 	mov	dpl,_control_setup_sloc4_1_0
      00611F 85 1A 83         [24] 2314 	mov	dph,(_control_setup_sloc4_1_0 + 1)
      006122 F0               [24] 2315 	movx	@dptr,a
      006123 E5 17            [12] 2316 	mov	a,_control_setup_sloc3_1_0
      006125 04               [12] 2317 	inc	a
      006126 F5 17            [12] 2318 	mov	_control_setup_sloc3_1_0,a
      006128 D0 01            [24] 2319 	pop	ar1
      00612A D0 00            [24] 2320 	pop	ar0
      00612C 80 BB            [24] 2321 	sjmp	00293$
      00612E                       2322 00222$:
                                   2323 ;	tmk_core/protocol/ch555/usb_ak820.c:328: length = 0; /* data already copied */
      00612E 90 07 C5         [24] 2324 	mov	dptr,#_control_setup_length_10000_286
      006131 E4               [12] 2325 	clr	a
      006132 F0               [24] 2326 	movx	@dptr,a
      006133 A3               [24] 2327 	inc	dptr
      006134 F0               [24] 2328 	movx	@dptr,a
      006135 02 62 13         [24] 2329 	ljmp	00252$
      006138                       2330 00240$:
                                   2331 ;	tmk_core/protocol/ch555/usb_ak820.c:329: } else if (value == 0x0200 && index == KEYBOARD_INTERFACE) {
      006138 8D 00            [24] 2332 	mov	ar0,r5
      00613A 8E 01            [24] 2333 	mov	ar1,r6
      00613C B8 00 21         [24] 2334 	cjne	r0,#0x00,00236$
      00613F B9 02 1E         [24] 2335 	cjne	r1,#0x02,00236$
      006142 EB               [12] 2336 	mov	a,r3
      006143 4C               [12] 2337 	orl	a,r4
      006144 70 1A            [24] 2338 	jnz	00236$
                                   2339 ;	tmk_core/protocol/ch555/usb_ak820.c:330: pD0_EP0_BUF[0] = KB_USB_SetReport;
      006146 90 07 67         [24] 2340 	mov	dptr,#_KB_USB_SetReport
      006149 E0               [24] 2341 	movx	a,@dptr
      00614A 90 10 00         [24] 2342 	mov	dptr,#0x1000
      00614D F0               [24] 2343 	movx	@dptr,a
                                   2344 ;	tmk_core/protocol/ch555/usb_ak820.c:331: length = 0;
      00614E 90 07 C5         [24] 2345 	mov	dptr,#_control_setup_length_10000_286
      006151 E4               [12] 2346 	clr	a
      006152 F0               [24] 2347 	movx	@dptr,a
      006153 A3               [24] 2348 	inc	dptr
      006154 F0               [24] 2349 	movx	@dptr,a
                                   2350 ;	tmk_core/protocol/ch555/usb_ak820.c:332: D0SetupLen = 1;
      006155 90 07 5D         [24] 2351 	mov	dptr,#_D0SetupLen
      006158 04               [12] 2352 	inc	a
      006159 F0               [24] 2353 	movx	@dptr,a
      00615A E4               [12] 2354 	clr	a
      00615B A3               [24] 2355 	inc	dptr
      00615C F0               [24] 2356 	movx	@dptr,a
      00615D 02 62 13         [24] 2357 	ljmp	00252$
      006160                       2358 00236$:
                                   2359 ;	tmk_core/protocol/ch555/usb_ak820.c:333: } else if (value == (0x0200 | REPORT_ID_NKRO) && index == SHARED_INTERFACE) {
      006160 B8 06 41         [24] 2360 	cjne	r0,#0x06,00232$
      006163 B9 02 3E         [24] 2361 	cjne	r1,#0x02,00232$
      006166 BB 02 3B         [24] 2362 	cjne	r3,#0x02,00232$
      006169 BC 00 38         [24] 2363 	cjne	r4,#0x00,00232$
                                   2364 ;	tmk_core/protocol/ch555/usb_ak820.c:334: pD0_EP0_BUF[0] = REPORT_ID_NKRO;
      00616C C0 03            [24] 2365 	push	ar3
      00616E C0 04            [24] 2366 	push	ar4
      006170 90 10 00         [24] 2367 	mov	dptr,#0x1000
      006173 74 06            [12] 2368 	mov	a,#0x06
      006175 F0               [24] 2369 	movx	@dptr,a
                                   2370 ;	tmk_core/protocol/ch555/usb_ak820.c:335: pD0_EP0_BUF[1] = KB_USB_SetReport;
      006176 90 07 67         [24] 2371 	mov	dptr,#_KB_USB_SetReport
      006179 E0               [24] 2372 	movx	a,@dptr
      00617A 90 10 01         [24] 2373 	mov	dptr,#0x1001
      00617D F0               [24] 2374 	movx	@dptr,a
                                   2375 ;	tmk_core/protocol/ch555/usb_ak820.c:336: length = 0;
      00617E 90 07 C5         [24] 2376 	mov	dptr,#_control_setup_length_10000_286
      006181 E4               [12] 2377 	clr	a
      006182 F0               [24] 2378 	movx	@dptr,a
      006183 A3               [24] 2379 	inc	dptr
      006184 F0               [24] 2380 	movx	@dptr,a
                                   2381 ;	tmk_core/protocol/ch555/usb_ak820.c:337: if (D0SetupLen > 2) D0SetupLen = 2;
      006185 90 07 5D         [24] 2382 	mov	dptr,#_D0SetupLen
      006188 E0               [24] 2383 	movx	a,@dptr
      006189 FB               [12] 2384 	mov	r3,a
      00618A A3               [24] 2385 	inc	dptr
      00618B E0               [24] 2386 	movx	a,@dptr
      00618C FC               [12] 2387 	mov	r4,a
      00618D C3               [12] 2388 	clr	c
      00618E 74 02            [12] 2389 	mov	a,#0x02
      006190 9B               [12] 2390 	subb	a,r3
      006191 E4               [12] 2391 	clr	a
      006192 9C               [12] 2392 	subb	a,r4
      006193 D0 04            [24] 2393 	pop	ar4
      006195 D0 03            [24] 2394 	pop	ar3
      006197 50 7A            [24] 2395 	jnc	00252$
                                   2396 ;	free result
      006199 90 07 5D         [24] 2397 	mov	dptr,#_D0SetupLen
      00619C 74 02            [12] 2398 	mov	a,#0x02
      00619E F0               [24] 2399 	movx	@dptr,a
      00619F E4               [12] 2400 	clr	a
      0061A0 A3               [24] 2401 	inc	dptr
      0061A1 F0               [24] 2402 	movx	@dptr,a
      0061A2 80 6F            [24] 2403 	sjmp	00252$
      0061A4                       2404 00232$:
                                   2405 ;	tmk_core/protocol/ch555/usb_ak820.c:338: } else if (value == 0x0300 && index == RAW_INTERFACE) {
      0061A4 B8 00 69         [24] 2406 	cjne	r0,#0x00,00228$
      0061A7 B9 03 66         [24] 2407 	cjne	r1,#0x03,00228$
      0061AA BB 01 63         [24] 2408 	cjne	r3,#0x01,00228$
      0061AD BC 00 60         [24] 2409 	cjne	r4,#0x00,00228$
                                   2410 ;	tmk_core/protocol/ch555/usb_ak820.c:341: pD0_EP0_BUF[0] = 'A';
      0061B0 90 10 00         [24] 2411 	mov	dptr,#0x1000
      0061B3 74 41            [12] 2412 	mov	a,#0x41
      0061B5 F0               [24] 2413 	movx	@dptr,a
                                   2414 ;	tmk_core/protocol/ch555/usb_ak820.c:342: pD0_EP0_BUF[1] = 'K';
      0061B6 A3               [24] 2415 	inc	dptr
      0061B7 74 4B            [12] 2416 	mov	a,#0x4b
      0061B9 F0               [24] 2417 	movx	@dptr,a
                                   2418 ;	tmk_core/protocol/ch555/usb_ak820.c:343: pD0_EP0_BUF[2] = 'B';
      0061BA A3               [24] 2419 	inc	dptr
      0061BB 74 42            [12] 2420 	mov	a,#0x42
      0061BD F0               [24] 2421 	movx	@dptr,a
                                   2422 ;	tmk_core/protocol/ch555/usb_ak820.c:344: pD0_EP0_BUF[3] = 'T';
      0061BE A3               [24] 2423 	inc	dptr
      0061BF 74 54            [12] 2424 	mov	a,#0x54
      0061C1 F0               [24] 2425 	movx	@dptr,a
                                   2426 ;	tmk_core/protocol/ch555/usb_ak820.c:345: pD0_EP0_BUF[4] = 1;
      0061C2 A3               [24] 2427 	inc	dptr
      0061C3 74 01            [12] 2428 	mov	a,#0x01
      0061C5 F0               [24] 2429 	movx	@dptr,a
                                   2430 ;	tmk_core/protocol/ch555/usb_ak820.c:346: pD0_EP0_BUF[5] = ak820_boot_stage;
      0061C6 90 07 68         [24] 2431 	mov	dptr,#_ak820_boot_stage
      0061C9 E0               [24] 2432 	movx	a,@dptr
      0061CA 90 10 05         [24] 2433 	mov	dptr,#0x1005
      0061CD F0               [24] 2434 	movx	@dptr,a
                                   2435 ;	tmk_core/protocol/ch555/usb_ak820.c:347: pD0_EP0_BUF[6] = ak820_main_heartbeat;
      0061CE 90 07 69         [24] 2436 	mov	dptr,#_ak820_main_heartbeat
      0061D1 E0               [24] 2437 	movx	a,@dptr
      0061D2 90 10 06         [24] 2438 	mov	dptr,#0x1006
      0061D5 F0               [24] 2439 	movx	@dptr,a
                                   2440 ;	tmk_core/protocol/ch555/usb_ak820.c:348: pD0_EP0_BUF[7] = (USB_EnumStatus ? 1 : 0) | (USB_SleepStatus & 2);
      0061D6 90 07 63         [24] 2441 	mov	dptr,#_USB_EnumStatus
      0061D9 E0               [24] 2442 	movx	a,@dptr
      0061DA 60 02            [24] 2443 	jz	00322$
      0061DC 74 01            [12] 2444 	mov	a,#0x01
      0061DE                       2445 00322$:
      0061DE F9               [12] 2446 	mov	r1,a
      0061DF 90 07 64         [24] 2447 	mov	dptr,#_USB_SleepStatus
      0061E2 E0               [24] 2448 	movx	a,@dptr
      0061E3 54 02            [12] 2449 	anl	a,#0x02
      0061E5 F8               [12] 2450 	mov	r0,a
      0061E6 E9               [12] 2451 	mov	a,r1
      0061E7 42 00            [12] 2452 	orl	ar0,a
      0061E9 90 10 07         [24] 2453 	mov	dptr,#0x1007
      0061EC E8               [12] 2454 	mov	a,r0
      0061ED F0               [24] 2455 	movx	@dptr,a
                                   2456 ;	tmk_core/protocol/ch555/usb_ak820.c:349: length = 0;
      0061EE 90 07 C5         [24] 2457 	mov	dptr,#_control_setup_length_10000_286
      0061F1 E4               [12] 2458 	clr	a
      0061F2 F0               [24] 2459 	movx	@dptr,a
      0061F3 A3               [24] 2460 	inc	dptr
      0061F4 F0               [24] 2461 	movx	@dptr,a
                                   2462 ;	tmk_core/protocol/ch555/usb_ak820.c:350: if (D0SetupLen > 8) D0SetupLen = 8;
      0061F5 90 07 5D         [24] 2463 	mov	dptr,#_D0SetupLen
      0061F8 E0               [24] 2464 	movx	a,@dptr
      0061F9 F8               [12] 2465 	mov	r0,a
      0061FA A3               [24] 2466 	inc	dptr
      0061FB E0               [24] 2467 	movx	a,@dptr
      0061FC F9               [12] 2468 	mov	r1,a
      0061FD C3               [12] 2469 	clr	c
      0061FE 74 08            [12] 2470 	mov	a,#0x08
      006200 98               [12] 2471 	subb	a,r0
      006201 E4               [12] 2472 	clr	a
      006202 99               [12] 2473 	subb	a,r1
      006203 50 0E            [24] 2474 	jnc	00252$
                                   2475 ;	free result
      006205 90 07 5D         [24] 2476 	mov	dptr,#_D0SetupLen
      006208 74 08            [12] 2477 	mov	a,#0x08
      00620A F0               [24] 2478 	movx	@dptr,a
      00620B E4               [12] 2479 	clr	a
      00620C A3               [24] 2480 	inc	dptr
      00620D F0               [24] 2481 	movx	@dptr,a
      00620E 80 03            [24] 2482 	sjmp	00252$
      006210                       2483 00228$:
                                   2484 ;	tmk_core/protocol/ch555/usb_ak820.c:351: } else { control_stall(); return; }
      006210 02 59 79         [24] 2485 	ljmp	_control_stall
      006213                       2486 00252$:
                                   2487 ;	tmk_core/protocol/ch555/usb_ak820.c:352: if (length) {
      006213 90 07 C5         [24] 2488 	mov	dptr,#_control_setup_length_10000_286
      006216 E0               [24] 2489 	movx	a,@dptr
      006217 F5 19            [12] 2490 	mov	_control_setup_sloc4_1_0,a
      006219 A3               [24] 2491 	inc	dptr
      00621A E0               [24] 2492 	movx	a,@dptr
      00621B F5 1A            [12] 2493 	mov	(_control_setup_sloc4_1_0 + 1),a
      00621D E5 19            [12] 2494 	mov	a,_control_setup_sloc4_1_0
      00621F 45 1A            [12] 2495 	orl	a,(_control_setup_sloc4_1_0 + 1)
      006221 60 50            [24] 2496 	jz	00262$
                                   2497 ;	tmk_core/protocol/ch555/usb_ak820.c:353: if (D0SetupLen > length) D0SetupLen = length;
      006223 90 07 5D         [24] 2498 	mov	dptr,#_D0SetupLen
      006226 E0               [24] 2499 	movx	a,@dptr
      006227 F8               [12] 2500 	mov	r0,a
      006228 A3               [24] 2501 	inc	dptr
      006229 E0               [24] 2502 	movx	a,@dptr
      00622A F9               [12] 2503 	mov	r1,a
      00622B C3               [12] 2504 	clr	c
      00622C E5 19            [12] 2505 	mov	a,_control_setup_sloc4_1_0
      00622E 98               [12] 2506 	subb	a,r0
      00622F E5 1A            [12] 2507 	mov	a,(_control_setup_sloc4_1_0 + 1)
      006231 99               [12] 2508 	subb	a,r1
      006232 50 0A            [24] 2509 	jnc	00559$
                                   2510 ;	free result
      006234 90 07 5D         [24] 2511 	mov	dptr,#_D0SetupLen
      006237 E5 19            [12] 2512 	mov	a,_control_setup_sloc4_1_0
      006239 F0               [24] 2513 	movx	@dptr,a
      00623A E5 1A            [12] 2514 	mov	a,(_control_setup_sloc4_1_0 + 1)
      00623C A3               [24] 2515 	inc	dptr
      00623D F0               [24] 2516 	movx	@dptr,a
                                   2517 ;	tmk_core/protocol/ch555/usb_ak820.c:356: for (i = 0; i < (uint8_t)D0SetupLen; ++i) pD0_EP0_BUF[i] = input_snapshot[offset + i];
      00623E                       2518 00559$:
      00623E 75 19 00         [24] 2519 	mov	_control_setup_sloc4_1_0,#0x00
      006241                       2520 00296$:
      006241 90 07 5D         [24] 2521 	mov	dptr,#_D0SetupLen
      006244 E0               [24] 2522 	movx	a,@dptr
      006245 F8               [12] 2523 	mov	r0,a
      006246 C3               [12] 2524 	clr	c
      006247 E5 19            [12] 2525 	mov	a,_control_setup_sloc4_1_0
      006249 98               [12] 2526 	subb	a,r0
      00624A 50 46            [24] 2527 	jnc	00263$
      00624C 85 19 17         [24] 2528 	mov	_control_setup_sloc3_1_0,_control_setup_sloc4_1_0
      00624F 74 10            [12] 2529 	mov	a,#0x10
      006251 24 00            [12] 2530 	add	a, #0x00
      006253 F5 18            [12] 2531 	mov	(_control_setup_sloc3_1_0 + 1),a
      006255 90 07 C7         [24] 2532 	mov	dptr,#_control_setup_offset_10000_286
      006258 E0               [24] 2533 	movx	a,@dptr
      006259 25 19            [12] 2534 	add	a, _control_setup_sloc4_1_0
      00625B 24 8D            [12] 2535 	add	a, #_input_snapshot
      00625D F5 82            [12] 2536 	mov	dpl,a
      00625F E4               [12] 2537 	clr	a
      006260 34 07            [12] 2538 	addc	a,#(_input_snapshot >> 8)
      006262 F5 83            [12] 2539 	mov	dph,a
      006264 E0               [24] 2540 	movx	a,@dptr
      006265 85 17 82         [24] 2541 	mov	dpl,_control_setup_sloc3_1_0
      006268 85 18 83         [24] 2542 	mov	dph,(_control_setup_sloc3_1_0 + 1)
      00626B F0               [24] 2543 	movx	@dptr,a
      00626C E5 19            [12] 2544 	mov	a,_control_setup_sloc4_1_0
      00626E 04               [12] 2545 	inc	a
      00626F F5 19            [12] 2546 	mov	_control_setup_sloc4_1_0,a
      006271 80 CE            [24] 2547 	sjmp	00296$
      006273                       2548 00262$:
                                   2549 ;	tmk_core/protocol/ch555/usb_ak820.c:357: } else if (index == RAW_INTERFACE && D0SetupLen > RAW_EPSIZE) D0SetupLen = RAW_EPSIZE;
      006273 BB 01 1C         [24] 2550 	cjne	r3,#0x01,00263$
      006276 BC 00 19         [24] 2551 	cjne	r4,#0x00,00263$
      006279 90 07 5D         [24] 2552 	mov	dptr,#_D0SetupLen
      00627C E0               [24] 2553 	movx	a,@dptr
      00627D F8               [12] 2554 	mov	r0,a
      00627E A3               [24] 2555 	inc	dptr
      00627F E0               [24] 2556 	movx	a,@dptr
      006280 F9               [12] 2557 	mov	r1,a
      006281 C3               [12] 2558 	clr	c
      006282 74 20            [12] 2559 	mov	a,#0x20
      006284 98               [12] 2560 	subb	a,r0
      006285 E4               [12] 2561 	clr	a
      006286 99               [12] 2562 	subb	a,r1
      006287 50 09            [24] 2563 	jnc	00263$
                                   2564 ;	free result
      006289 90 07 5D         [24] 2565 	mov	dptr,#_D0SetupLen
      00628C 74 20            [12] 2566 	mov	a,#0x20
      00628E F0               [24] 2567 	movx	@dptr,a
      00628F E4               [12] 2568 	clr	a
      006290 A3               [24] 2569 	inc	dptr
      006291 F0               [24] 2570 	movx	@dptr,a
      006292                       2571 00263$:
                                   2572 ;	tmk_core/protocol/ch555/usb_ak820.c:358: D0_EP0T_L = D0SetupLen;
      006292 90 07 5D         [24] 2573 	mov	dptr,#_D0SetupLen
      006295 E0               [24] 2574 	movx	a,@dptr
      006296 90 22 08         [24] 2575 	mov	dptr,#0x2208
      006299 F0               [24] 2576 	movx	@dptr,a
                                   2577 ;	tmk_core/protocol/ch555/usb_ak820.c:359: control_phase = CTRL_STATUS_OUT;
      00629A 90 07 BB         [24] 2578 	mov	dptr,#_control_phase
      00629D 74 02            [12] 2579 	mov	a,#0x02
      00629F F0               [24] 2580 	movx	@dptr,a
      0062A0 02 63 28         [24] 2581 	ljmp	00291$
      0062A3                       2582 00273$:
                                   2583 ;	tmk_core/protocol/ch555/usb_ak820.c:360: } else if (index == KEYBOARD_INTERFACE && D0UsbConfig && type == 0xa1 && D0SetupReqCode == DEF_USB_GET_PROTOCOL && zero_value && D0SetupLen == 1) {
      0062A3 EB               [12] 2584 	mov	a,r3
      0062A4 4C               [12] 2585 	orl	a,r4
      0062A5 70 37            [24] 2586 	jnz	00265$
      0062A7 90 07 62         [24] 2587 	mov	dptr,#_D0UsbConfig
      0062AA E0               [24] 2588 	movx	a,@dptr
      0062AB 60 31            [24] 2589 	jz	00265$
      0062AD EA               [12] 2590 	mov	a,r2
      0062AE 60 2E            [24] 2591 	jz	00265$
      0062B0 90 07 5C         [24] 2592 	mov	dptr,#_D0SetupReqCode
      0062B3 E0               [24] 2593 	movx	a,@dptr
      0062B4 FA               [12] 2594 	mov	r2,a
      0062B5 BA 03 26         [24] 2595 	cjne	r2,#0x03,00265$
      0062B8 30 18 23         [24] 2596 	jnb	_control_setup_zero_value_10000_286,00265$
      0062BB 90 07 5D         [24] 2597 	mov	dptr,#_D0SetupLen
      0062BE E0               [24] 2598 	movx	a,@dptr
      0062BF F9               [12] 2599 	mov	r1,a
      0062C0 A3               [24] 2600 	inc	dptr
      0062C1 E0               [24] 2601 	movx	a,@dptr
      0062C2 FA               [12] 2602 	mov	r2,a
      0062C3 B9 01 18         [24] 2603 	cjne	r1,#0x01,00265$
      0062C6 BA 00 15         [24] 2604 	cjne	r2,#0x00,00265$
                                   2605 ;	tmk_core/protocol/ch555/usb_ak820.c:361: pD0_EP0_BUF[0] = keyboard_protocol;
      0062C9 90 0D AC         [24] 2606 	mov	dptr,#_keyboard_protocol
      0062CC E0               [24] 2607 	movx	a,@dptr
      0062CD 90 10 00         [24] 2608 	mov	dptr,#0x1000
      0062D0 F0               [24] 2609 	movx	@dptr,a
                                   2610 ;	tmk_core/protocol/ch555/usb_ak820.c:362: D0_EP0T_L = 1;
      0062D1 90 22 08         [24] 2611 	mov	dptr,#0x2208
      0062D4 74 01            [12] 2612 	mov	a,#0x01
      0062D6 F0               [24] 2613 	movx	@dptr,a
                                   2614 ;	tmk_core/protocol/ch555/usb_ak820.c:363: control_phase = CTRL_STATUS_OUT;
      0062D7 90 07 BB         [24] 2615 	mov	dptr,#_control_phase
      0062DA 04               [12] 2616 	inc	a
      0062DB F0               [24] 2617 	movx	@dptr,a
      0062DC 80 4A            [24] 2618 	sjmp	00291$
      0062DE                       2619 00265$:
                                   2620 ;	tmk_core/protocol/ch555/usb_ak820.c:364: } else { control_stall(); return; }
                                   2621 ;	tmk_core/protocol/ch555/usb_ak820.c:366: case DEF_USB_GET_IDLE:
      0062DE 02 59 79         [24] 2622 	ljmp	_control_stall
      0062E1                       2623 00282$:
                                   2624 ;	tmk_core/protocol/ch555/usb_ak820.c:367: if (valid_interface && D0UsbConfig && type == 0xa1 && !(value >> 8) && D0SetupLen == 1) {
      0062E1 30 16 3E         [24] 2625 	jnb	_control_setup_valid_interface_10000_286,00284$
      0062E4 90 07 62         [24] 2626 	mov	dptr,#_D0UsbConfig
      0062E7 E0               [24] 2627 	movx	a,@dptr
      0062E8 60 38            [24] 2628 	jz	00284$
      0062EA BF A1 35         [24] 2629 	cjne	r7,#0xa1,00284$
      0062ED 8E 05            [24] 2630 	mov	ar5,r6
      0062EF 7E 00            [12] 2631 	mov	r6,#0x00
      0062F1 ED               [12] 2632 	mov	a,r5
      0062F2 4E               [12] 2633 	orl	a,r6
      0062F3 70 2D            [24] 2634 	jnz	00284$
      0062F5 90 07 5D         [24] 2635 	mov	dptr,#_D0SetupLen
      0062F8 E0               [24] 2636 	movx	a,@dptr
      0062F9 FE               [12] 2637 	mov	r6,a
      0062FA A3               [24] 2638 	inc	dptr
      0062FB E0               [24] 2639 	movx	a,@dptr
      0062FC FF               [12] 2640 	mov	r7,a
      0062FD BE 01 22         [24] 2641 	cjne	r6,#0x01,00284$
      006300 BF 00 1F         [24] 2642 	cjne	r7,#0x00,00284$
                                   2643 ;	tmk_core/protocol/ch555/usb_ak820.c:368: pD0_EP0_BUF[0] = index == KEYBOARD_INTERFACE ? keyboard_idle : 0;
      006303 EB               [12] 2644 	mov	a,r3
      006304 4C               [12] 2645 	orl	a,r4
      006305 70 07            [24] 2646 	jnz	00324$
      006307 90 06 3A         [24] 2647 	mov	dptr,#_keyboard_idle
      00630A E0               [24] 2648 	movx	a,@dptr
      00630B FF               [12] 2649 	mov	r7,a
      00630C 80 02            [24] 2650 	sjmp	00325$
      00630E                       2651 00324$:
      00630E 7F 00            [12] 2652 	mov	r7,#0x00
      006310                       2653 00325$:
      006310 90 10 00         [24] 2654 	mov	dptr,#0x1000
      006313 EF               [12] 2655 	mov	a,r7
      006314 F0               [24] 2656 	movx	@dptr,a
                                   2657 ;	tmk_core/protocol/ch555/usb_ak820.c:369: D0_EP0T_L = 1;
      006315 90 22 08         [24] 2658 	mov	dptr,#0x2208
      006318 74 01            [12] 2659 	mov	a,#0x01
      00631A F0               [24] 2660 	movx	@dptr,a
                                   2661 ;	tmk_core/protocol/ch555/usb_ak820.c:370: control_phase = CTRL_STATUS_OUT;
      00631B 90 07 BB         [24] 2662 	mov	dptr,#_control_phase
      00631E 04               [12] 2663 	inc	a
      00631F F0               [24] 2664 	movx	@dptr,a
      006320 80 06            [24] 2665 	sjmp	00291$
      006322                       2666 00284$:
                                   2667 ;	tmk_core/protocol/ch555/usb_ak820.c:371: } else { control_stall(); return; }
                                   2668 ;	tmk_core/protocol/ch555/usb_ak820.c:373: default: control_stall(); return;
      006322 02 59 79         [24] 2669 	ljmp	_control_stall
      006325                       2670 00290$:
                                   2671 ;	tmk_core/protocol/ch555/usb_ak820.c:374: }
      006325 02 59 79         [24] 2672 	ljmp	_control_stall
      006328                       2673 00291$:
                                   2674 ;	tmk_core/protocol/ch555/usb_ak820.c:375: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_ACK | UEP_T_RES_ACK;
      006328 90 22 00         [24] 2675 	mov	dptr,#0x2200
      00632B 74 C0            [12] 2676 	mov	a,#0xc0
      00632D F0               [24] 2677 	movx	@dptr,a
                                   2678 ;	tmk_core/protocol/ch555/usb_ak820.c:376: }
      00632E 22               [24] 2679 	ret
                                   2680 ;------------------------------------------------------------
                                   2681 ;Allocation info for local variables in function 'control_out'
                                   2682 ;------------------------------------------------------------
                                   2683 ;i             Allocated with name '_control_out_i_10000_370'
                                   2684 ;------------------------------------------------------------
                                   2685 ;	tmk_core/protocol/ch555/usb_ak820.c:378: static void control_out(void) {
                                   2686 ;	-----------------------------------------
                                   2687 ;	 function control_out
                                   2688 ;	-----------------------------------------
      00632F                       2689 _control_out:
                                   2690 ;	tmk_core/protocol/ch555/usb_ak820.c:380: if (!(D0_STATUS & bUXS_TOG_OK)) return; /* duplicate OUT is not a new request */
      00632F 90 22 0F         [24] 2691 	mov	dptr,#0x220f
      006332 E0               [24] 2692 	movx	a,@dptr
      006333 20 E6 01         [24] 2693 	jb	acc.6,00102$
      006336 22               [24] 2694 	ret
      006337                       2695 00102$:
                                   2696 ;	tmk_core/protocol/ch555/usb_ak820.c:381: if (control_phase == CTRL_STATUS_OUT && D0_RX_LEN == 0) {
      006337 90 07 BB         [24] 2697 	mov	dptr,#_control_phase
      00633A E0               [24] 2698 	movx	a,@dptr
      00633B FF               [12] 2699 	mov	r7,a
      00633C BF 02 12         [24] 2700 	cjne	r7,#0x02,00104$
      00633F 90 22 0E         [24] 2701 	mov	dptr,#0x220e
      006342 E0               [24] 2702 	movx	a,@dptr
      006343 70 0C            [24] 2703 	jnz	00104$
                                   2704 ;	tmk_core/protocol/ch555/usb_ak820.c:382: control_phase = CTRL_IDLE;
      006345 90 07 BB         [24] 2705 	mov	dptr,#_control_phase
      006348 E4               [12] 2706 	clr	a
      006349 F0               [24] 2707 	movx	@dptr,a
                                   2708 ;	tmk_core/protocol/ch555/usb_ak820.c:383: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      00634A 90 22 00         [24] 2709 	mov	dptr,#0x2200
      00634D 74 02            [12] 2710 	mov	a,#0x02
      00634F F0               [24] 2711 	movx	@dptr,a
                                   2712 ;	tmk_core/protocol/ch555/usb_ak820.c:384: return;
      006350 22               [24] 2713 	ret
      006351                       2714 00104$:
                                   2715 ;	tmk_core/protocol/ch555/usb_ak820.c:386: if (control_phase != CTRL_DATA_OUT || D0_RX_LEN != D0SetupLen) { control_stall(); return; }
      006351 BF 04 19         [24] 2716 	cjne	r7,#0x04,00106$
      006354 90 22 0E         [24] 2717 	mov	dptr,#0x220e
      006357 E0               [24] 2718 	movx	a,@dptr
      006358 FF               [12] 2719 	mov	r7,a
      006359 90 07 5D         [24] 2720 	mov	dptr,#_D0SetupLen
      00635C E0               [24] 2721 	movx	a,@dptr
      00635D FD               [12] 2722 	mov	r5,a
      00635E A3               [24] 2723 	inc	dptr
      00635F E0               [24] 2724 	movx	a,@dptr
      006360 FE               [12] 2725 	mov	r6,a
      006361 7C 00            [12] 2726 	mov	r4,#0x00
      006363 EF               [12] 2727 	mov	a,r7
      006364 B5 05 06         [24] 2728 	cjne	a,ar5,00209$
      006367 EC               [12] 2729 	mov	a,r4
      006368 B5 06 02         [24] 2730 	cjne	a,ar6,00209$
      00636B 80 03            [24] 2731 	sjmp	00107$
      00636D                       2732 00209$:
      00636D                       2733 00106$:
      00636D 02 59 79         [24] 2734 	ljmp	_control_stall
      006370                       2735 00107$:
                                   2736 ;	tmk_core/protocol/ch555/usb_ak820.c:387: if (output_kind == OUTPUT_RAW && raw_state == RAW_RX) {
      006370 90 07 BC         [24] 2737 	mov	dptr,#_output_kind
      006373 E0               [24] 2738 	movx	a,@dptr
      006374 FF               [12] 2739 	mov	r7,a
      006375 BF 01 2E         [24] 2740 	cjne	r7,#0x01,00118$
      006378 90 07 6A         [24] 2741 	mov	dptr,#_raw_state
      00637B E0               [24] 2742 	movx	a,@dptr
      00637C FE               [12] 2743 	mov	r6,a
      00637D BE 01 26         [24] 2744 	cjne	r6,#0x01,00118$
                                   2745 ;	tmk_core/protocol/ch555/usb_ak820.c:388: for (i = 0; i < RAW_EPSIZE; ++i) raw_buffer[i] = pD0_EP0_BUF[i];
      006380 7E 00            [12] 2746 	mov	r6,#0x00
      006382                       2747 00121$:
      006382 EE               [12] 2748 	mov	a,r6
      006383 24 6B            [12] 2749 	add	a, #_raw_buffer
      006385 FC               [12] 2750 	mov	r4,a
      006386 E4               [12] 2751 	clr	a
      006387 34 07            [12] 2752 	addc	a, #(_raw_buffer >> 8)
      006389 FD               [12] 2753 	mov	r5,a
      00638A 8E 82            [24] 2754 	mov	dpl,r6
      00638C 74 10            [12] 2755 	mov	a,#0x10
      00638E 24 00            [12] 2756 	add	a, #0x00
      006390 F5 83            [12] 2757 	mov	dph,a
      006392 E0               [24] 2758 	movx	a,@dptr
      006393 8C 82            [24] 2759 	mov	dpl,r4
      006395 8D 83            [24] 2760 	mov	dph,r5
      006397 F0               [24] 2761 	movx	@dptr,a
      006398 0E               [12] 2762 	inc	r6
      006399 BE 20 00         [24] 2763 	cjne	r6,#0x20,00214$
      00639C                       2764 00214$:
      00639C 40 E4            [24] 2765 	jc	00121$
                                   2766 ;	tmk_core/protocol/ch555/usb_ak820.c:389: raw_state = RAW_READY; /* publish only after the entire packet is copied */
      00639E 90 07 6A         [24] 2767 	mov	dptr,#_raw_state
      0063A1 74 02            [12] 2768 	mov	a,#0x02
      0063A3 F0               [24] 2769 	movx	@dptr,a
      0063A4 80 2B            [24] 2770 	sjmp	00119$
      0063A6                       2771 00118$:
                                   2772 ;	tmk_core/protocol/ch555/usb_ak820.c:390: } else if (output_kind == OUTPUT_LED) {
      0063A6 BF 02 0A         [24] 2773 	cjne	r7,#0x02,00115$
                                   2774 ;	tmk_core/protocol/ch555/usb_ak820.c:391: KB_USB_SetReport = pD0_EP0_BUF[0];
      0063A9 90 10 00         [24] 2775 	mov	dptr,#0x1000
      0063AC E0               [24] 2776 	movx	a,@dptr
      0063AD 90 07 67         [24] 2777 	mov	dptr,#_KB_USB_SetReport
      0063B0 F0               [24] 2778 	movx	@dptr,a
      0063B1 80 1E            [24] 2779 	sjmp	00119$
      0063B3                       2780 00115$:
                                   2781 ;	tmk_core/protocol/ch555/usb_ak820.c:392: } else if (output_kind == OUTPUT_SHARED_LED && pD0_EP0_BUF[0] == output_report_id) {
      0063B3 BF 03 18         [24] 2782 	cjne	r7,#0x03,00111$
      0063B6 90 10 00         [24] 2783 	mov	dptr,#0x1000
      0063B9 E0               [24] 2784 	movx	a,@dptr
      0063BA FF               [12] 2785 	mov	r7,a
      0063BB 90 07 BD         [24] 2786 	mov	dptr,#_output_report_id
      0063BE E0               [24] 2787 	movx	a,@dptr
      0063BF FE               [12] 2788 	mov	r6,a
      0063C0 EF               [12] 2789 	mov	a,r7
      0063C1 B5 06 0A         [24] 2790 	cjne	a,ar6,00111$
                                   2791 ;	tmk_core/protocol/ch555/usb_ak820.c:393: KB_USB_SetReport = pD0_EP0_BUF[1];
      0063C4 90 10 01         [24] 2792 	mov	dptr,#0x1001
      0063C7 E0               [24] 2793 	movx	a,@dptr
      0063C8 90 07 67         [24] 2794 	mov	dptr,#_KB_USB_SetReport
      0063CB F0               [24] 2795 	movx	@dptr,a
      0063CC 80 03            [24] 2796 	sjmp	00119$
      0063CE                       2797 00111$:
                                   2798 ;	tmk_core/protocol/ch555/usb_ak820.c:394: } else { control_stall(); return; }
      0063CE 02 59 79         [24] 2799 	ljmp	_control_stall
      0063D1                       2800 00119$:
                                   2801 ;	tmk_core/protocol/ch555/usb_ak820.c:395: output_kind = OUTPUT_NONE;
      0063D1 90 07 BC         [24] 2802 	mov	dptr,#_output_kind
      0063D4 E4               [12] 2803 	clr	a
      0063D5 F0               [24] 2804 	movx	@dptr,a
                                   2805 ;	tmk_core/protocol/ch555/usb_ak820.c:396: D0SetupLen = 0;
      0063D6 90 07 5D         [24] 2806 	mov	dptr,#_D0SetupLen
      0063D9 F0               [24] 2807 	movx	@dptr,a
      0063DA A3               [24] 2808 	inc	dptr
      0063DB F0               [24] 2809 	movx	@dptr,a
                                   2810 ;	tmk_core/protocol/ch555/usb_ak820.c:397: control_phase = CTRL_STATUS_IN;
      0063DC 90 07 BB         [24] 2811 	mov	dptr,#_control_phase
      0063DF 74 03            [12] 2812 	mov	a,#0x03
      0063E1 F0               [24] 2813 	movx	@dptr,a
                                   2814 ;	tmk_core/protocol/ch555/usb_ak820.c:398: D0_EP0T_L = 0;
      0063E2 90 22 08         [24] 2815 	mov	dptr,#0x2208
      0063E5 E4               [12] 2816 	clr	a
      0063E6 F0               [24] 2817 	movx	@dptr,a
                                   2818 ;	tmk_core/protocol/ch555/usb_ak820.c:399: D0_EP0RES = bUEP_T_TOG | UEP_R_RES_NAK | UEP_T_RES_ACK;
      0063E7 F5 82            [12] 2819 	mov	dpl,a
      0063E9 74 48            [12] 2820 	mov	a,#0x48
      0063EB F0               [24] 2821 	movx	@dptr,a
                                   2822 ;	tmk_core/protocol/ch555/usb_ak820.c:400: }
      0063EC 22               [24] 2823 	ret
                                   2824 ;------------------------------------------------------------
                                   2825 ;Allocation info for local variables in function 'control_in'
                                   2826 ;------------------------------------------------------------
                                   2827 ;	tmk_core/protocol/ch555/usb_ak820.c:402: static void control_in(void) {
                                   2828 ;	-----------------------------------------
                                   2829 ;	 function control_in
                                   2830 ;	-----------------------------------------
      0063ED                       2831 _control_in:
                                   2832 ;	tmk_core/protocol/ch555/usb_ak820.c:403: if (control_phase == CTRL_DATA_IN) {
      0063ED 90 07 BB         [24] 2833 	mov	dptr,#_control_phase
      0063F0 E0               [24] 2834 	movx	a,@dptr
      0063F1 FF               [12] 2835 	mov	r7,a
      0063F2 BF 01 22         [24] 2836 	cjne	r7,#0x01,00109$
                                   2837 ;	tmk_core/protocol/ch555/usb_ak820.c:404: if (D0SetupLen || control_zlp) {
      0063F5 90 07 5D         [24] 2838 	mov	dptr,#_D0SetupLen
      0063F8 E0               [24] 2839 	movx	a,@dptr
      0063F9 FD               [12] 2840 	mov	r5,a
      0063FA A3               [24] 2841 	inc	dptr
      0063FB E0               [24] 2842 	movx	a,@dptr
      0063FC 4D               [12] 2843 	orl	a,r5
      0063FD 70 06            [24] 2844 	jnz	00101$
      0063FF 90 07 BE         [24] 2845 	mov	dptr,#_control_zlp
      006402 E0               [24] 2846 	movx	a,@dptr
      006403 60 0A            [24] 2847 	jz	00102$
      006405                       2848 00101$:
                                   2849 ;	tmk_core/protocol/ch555/usb_ak820.c:405: D0_EP0RES ^= bUEP_T_TOG;
      006405 90 22 00         [24] 2850 	mov	dptr,#0x2200
      006408 E0               [24] 2851 	movx	a,@dptr
      006409 64 40            [12] 2852 	xrl	a,#0x40
      00640B F0               [24] 2853 	movx	@dptr,a
                                   2854 ;	tmk_core/protocol/ch555/usb_ak820.c:406: control_next();
                                   2855 ;	tmk_core/protocol/ch555/usb_ak820.c:407: return;
      00640C 02 59 9B         [24] 2856 	ljmp	_control_next
      00640F                       2857 00102$:
                                   2858 ;	tmk_core/protocol/ch555/usb_ak820.c:409: control_phase = CTRL_STATUS_OUT;
      00640F 90 07 BB         [24] 2859 	mov	dptr,#_control_phase
      006412 74 02            [12] 2860 	mov	a,#0x02
      006414 F0               [24] 2861 	movx	@dptr,a
      006415 80 18            [24] 2862 	sjmp	00110$
      006417                       2863 00109$:
                                   2864 ;	tmk_core/protocol/ch555/usb_ak820.c:410: } else if (control_phase == CTRL_STATUS_IN) {
      006417 BF 03 15         [24] 2865 	cjne	r7,#0x03,00110$
                                   2866 ;	tmk_core/protocol/ch555/usb_ak820.c:411: if (D0SetupReqCode == USB_SET_ADDRESS) D0_ADDR = D0SetupLen;
      00641A 90 07 5C         [24] 2867 	mov	dptr,#_D0SetupReqCode
      00641D E0               [24] 2868 	movx	a,@dptr
      00641E FF               [12] 2869 	mov	r7,a
      00641F BF 05 08         [24] 2870 	cjne	r7,#0x05,00105$
      006422 90 07 5D         [24] 2871 	mov	dptr,#_D0SetupLen
      006425 E0               [24] 2872 	movx	a,@dptr
      006426 90 22 07         [24] 2873 	mov	dptr,#0x2207
      006429 F0               [24] 2874 	movx	@dptr,a
      00642A                       2875 00105$:
                                   2876 ;	tmk_core/protocol/ch555/usb_ak820.c:412: control_phase = CTRL_IDLE;
      00642A 90 07 BB         [24] 2877 	mov	dptr,#_control_phase
      00642D E4               [12] 2878 	clr	a
      00642E F0               [24] 2879 	movx	@dptr,a
      00642F                       2880 00110$:
                                   2881 ;	tmk_core/protocol/ch555/usb_ak820.c:414: D0_EP0RES = bUEP_R_TOG | UEP_R_RES_ACK | UEP_T_RES_NAK;
      00642F 90 22 00         [24] 2882 	mov	dptr,#0x2200
      006432 74 82            [12] 2883 	mov	a,#0x82
      006434 F0               [24] 2884 	movx	@dptr,a
                                   2885 ;	tmk_core/protocol/ch555/usb_ak820.c:415: }
      006435 22               [24] 2886 	ret
                                   2887 ;------------------------------------------------------------
                                   2888 ;Allocation info for local variables in function 'USB_DeviceInterrupt'
                                   2889 ;------------------------------------------------------------
                                   2890 ;status        Allocated with name '_USB_DeviceInterrupt_status_10000_394'
                                   2891 ;endpoint      Allocated with name '_USB_DeviceInterrupt_endpoint_10000_394'
                                   2892 ;------------------------------------------------------------
                                   2893 ;	tmk_core/protocol/ch555/usb_ak820.c:417: void USB_DeviceInterrupt(void) {
                                   2894 ;	-----------------------------------------
                                   2895 ;	 function USB_DeviceInterrupt
                                   2896 ;	-----------------------------------------
      006436                       2897 _USB_DeviceInterrupt:
                                   2898 ;	tmk_core/protocol/ch555/usb_ak820.c:420: do {
      006436                       2899 00129$:
                                   2900 ;	tmk_core/protocol/ch555/usb_ak820.c:422: if (USB_IF & bUX_IF_BUS_RST) {
      006436 90 22 3D         [24] 2901 	mov	dptr,#0x223d
      006439 E0               [24] 2902 	movx	a,@dptr
      00643A 30 E0 4B         [24] 2903 	jnb	acc.0,00127$
                                   2904 ;	tmk_core/protocol/ch555/usb_ak820.c:423: endpoints_reset();
      00643D 12 59 22         [24] 2905 	lcall	_endpoints_reset
                                   2906 ;	tmk_core/protocol/ch555/usb_ak820.c:424: D0_ADDR = 0;
      006440 90 22 07         [24] 2907 	mov	dptr,#0x2207
      006443 E4               [12] 2908 	clr	a
      006444 F0               [24] 2909 	movx	@dptr,a
                                   2910 ;	tmk_core/protocol/ch555/usb_ak820.c:425: D0UsbConfig = USB_EnumStatus = USB_SleepStatus = 0;
      006445 90 07 64         [24] 2911 	mov	dptr,#_USB_SleepStatus
      006448 F0               [24] 2912 	movx	@dptr,a
      006449 90 07 63         [24] 2913 	mov	dptr,#_USB_EnumStatus
      00644C F0               [24] 2914 	movx	@dptr,a
      00644D 90 07 62         [24] 2915 	mov	dptr,#_D0UsbConfig
      006450 F0               [24] 2916 	movx	@dptr,a
                                   2917 ;	tmk_core/protocol/ch555/usb_ak820.c:426: KB_USB_SetReport = 0;
      006451 90 07 67         [24] 2918 	mov	dptr,#_KB_USB_SetReport
      006454 F0               [24] 2919 	movx	@dptr,a
                                   2920 ;	tmk_core/protocol/ch555/usb_ak820.c:427: keyboard_protocol = 1;
      006455 90 0D AC         [24] 2921 	mov	dptr,#_keyboard_protocol
      006458 04               [12] 2922 	inc	a
      006459 F0               [24] 2923 	movx	@dptr,a
                                   2924 ;	tmk_core/protocol/ch555/usb_ak820.c:428: keyboard_idle = 0;
      00645A 90 06 3A         [24] 2925 	mov	dptr,#_keyboard_idle
      00645D E4               [12] 2926 	clr	a
      00645E F0               [24] 2927 	movx	@dptr,a
                                   2928 ;	tmk_core/protocol/ch555/usb_ak820.c:429: keyboard_reset = 1;
      00645F 90 07 8C         [24] 2929 	mov	dptr,#_keyboard_reset
      006462 04               [12] 2930 	inc	a
      006463 F0               [24] 2931 	movx	@dptr,a
                                   2932 ;	tmk_core/protocol/ch555/usb_ak820.c:430: D0SetupReqCode = 0xff;
      006464 90 07 5C         [24] 2933 	mov	dptr,#_D0SetupReqCode
      006467 74 FF            [12] 2934 	mov	a,#0xff
      006469 F0               [24] 2935 	movx	@dptr,a
                                   2936 ;	tmk_core/protocol/ch555/usb_ak820.c:431: D0SetupLen = 0;
      00646A 90 07 5D         [24] 2937 	mov	dptr,#_D0SetupLen
      00646D E4               [12] 2938 	clr	a
      00646E F0               [24] 2939 	movx	@dptr,a
      00646F A3               [24] 2940 	inc	dptr
      006470 F0               [24] 2941 	movx	@dptr,a
                                   2942 ;	tmk_core/protocol/ch555/usb_ak820.c:432: control_phase = CTRL_IDLE;
      006471 90 07 BB         [24] 2943 	mov	dptr,#_control_phase
      006474 F0               [24] 2944 	movx	@dptr,a
                                   2945 ;	tmk_core/protocol/ch555/usb_ak820.c:433: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      006475 90 22 00         [24] 2946 	mov	dptr,#0x2200
      006478 74 02            [12] 2947 	mov	a,#0x02
      00647A F0               [24] 2948 	movx	@dptr,a
                                   2949 ;	tmk_core/protocol/ch555/usb_ak820.c:434: ACK_TRANSFER();
      00647B 90 22 0F         [24] 2950 	mov	dptr,#0x220f
      00647E E4               [12] 2951 	clr	a
      00647F F0               [24] 2952 	movx	@dptr,a
                                   2953 ;	tmk_core/protocol/ch555/usb_ak820.c:435: ACK_RESET();
      006480 90 22 3D         [24] 2954 	mov	dptr,#0x223d
      006483 04               [12] 2955 	inc	a
      006484 F0               [24] 2956 	movx	@dptr,a
      006485 02 65 1B         [24] 2957 	ljmp	00130$
      006488                       2958 00127$:
                                   2959 ;	tmk_core/protocol/ch555/usb_ak820.c:436: } else if (USB_IF & bUX_IF_D0_TRANS) {
      006488 90 22 3D         [24] 2960 	mov	dptr,#0x223d
      00648B E0               [24] 2961 	movx	a,@dptr
      00648C 30 E5 60         [24] 2962 	jnb	acc.5,00124$
                                   2963 ;	tmk_core/protocol/ch555/usb_ak820.c:437: status = D0_STATUS;
      00648F 90 22 0F         [24] 2964 	mov	dptr,#0x220f
      006492 E0               [24] 2965 	movx	a,@dptr
      006493 FF               [12] 2966 	mov	r7,a
                                   2967 ;	tmk_core/protocol/ch555/usb_ak820.c:438: endpoint = status & MASK_UXS_ENDP;
      006494 74 07            [12] 2968 	mov	a,#0x07
      006496 5F               [12] 2969 	anl	a,r7
      006497 FE               [12] 2970 	mov	r6,a
                                   2971 ;	tmk_core/protocol/ch555/usb_ak820.c:442: if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_OUT && !endpoint) {
      006498 EF               [12] 2972 	mov	a,r7
      006499 54 18            [12] 2973 	anl	a,#0x18
      00649B 70 08            [24] 2974 	jnz	00115$
      00649D EE               [12] 2975 	mov	a,r6
      00649E 70 05            [24] 2976 	jnz	00115$
                                   2977 ;	tmk_core/protocol/ch555/usb_ak820.c:443: control_out();
      0064A0 12 63 2F         [24] 2978 	lcall	_control_out
      0064A3 80 43            [24] 2979 	sjmp	00116$
      0064A5                       2980 00115$:
                                   2981 ;	tmk_core/protocol/ch555/usb_ak820.c:444: } else if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_IN) {
      0064A5 8F 05            [24] 2982 	mov	ar5,r7
      0064A7 74 18            [12] 2983 	mov	a,#0x18
      0064A9 5D               [12] 2984 	anl	a,r5
      0064AA FC               [12] 2985 	mov	r4,a
      0064AB BC 10 2D         [24] 2986 	cjne	r4,#0x10,00112$
                                   2987 ;	tmk_core/protocol/ch555/usb_ak820.c:445: if (!endpoint) control_in();
      0064AE EE               [12] 2988 	mov	a,r6
      0064AF 70 05            [24] 2989 	jnz	00106$
      0064B1 12 63 ED         [24] 2990 	lcall	_control_in
      0064B4 80 32            [24] 2991 	sjmp	00116$
      0064B6                       2992 00106$:
                                   2993 ;	tmk_core/protocol/ch555/usb_ak820.c:446: else if (endpoint <= 3) {
      0064B6 EE               [12] 2994 	mov	a,r6
      0064B7 24 FC            [12] 2995 	add	a,#0xff - 0x03
      0064B9 40 2D            [24] 2996 	jc	00116$
                                   2997 ;	free result
                                   2998 ;	tmk_core/protocol/ch555/usb_ak820.c:447: EP_RESPONSE(endpoint) = (EP_RESPONSE(endpoint) & ~MASK_UEP_X_RES) | UEP_X_RES_NAK;
      0064BB 8E 04            [24] 2999 	mov	ar4,r6
      0064BD 7B 00            [12] 3000 	mov	r3,#0x00
      0064BF 74 22            [12] 3001 	mov	a,#0x22
      0064C1 2B               [12] 3002 	add	a, r3
      0064C2 FB               [12] 3003 	mov	r3,a
      0064C3 8C 82            [24] 3004 	mov	dpl,r4
      0064C5 8B 83            [24] 3005 	mov	dph,r3
      0064C7 E0               [24] 3006 	movx	a,@dptr
      0064C8 FA               [12] 3007 	mov	r2,a
      0064C9 74 FC            [12] 3008 	mov	a,#0xfc
      0064CB 5A               [12] 3009 	anl	a,r2
      0064CC 44 02            [12] 3010 	orl	a,#0x02
      0064CE 8C 82            [24] 3011 	mov	dpl,r4
      0064D0 8B 83            [24] 3012 	mov	dph,r3
      0064D2 F0               [24] 3013 	movx	@dptr,a
                                   3014 ;	tmk_core/protocol/ch555/usb_ak820.c:448: if (endpoint == RAW_IN_EPNUM) raw_complete();
      0064D3 BE 03 12         [24] 3015 	cjne	r6,#0x03,00116$
      0064D6 12 59 05         [24] 3016 	lcall	_raw_complete
      0064D9 80 0D            [24] 3017 	sjmp	00116$
      0064DB                       3018 00112$:
                                   3019 ;	tmk_core/protocol/ch555/usb_ak820.c:450: } else if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_FREE && (status & bUXS_SETUP_ACT)) {
      0064DB 53 05 18         [24] 3020 	anl	ar5,#0x18
      0064DE BD 18 07         [24] 3021 	cjne	r5,#0x18,00116$
      0064E1 EF               [12] 3022 	mov	a,r7
      0064E2 30 E5 03         [24] 3023 	jnb	acc.5,00116$
                                   3024 ;	tmk_core/protocol/ch555/usb_ak820.c:451: control_setup();
      0064E5 12 5B 92         [24] 3025 	lcall	_control_setup
      0064E8                       3026 00116$:
                                   3027 ;	tmk_core/protocol/ch555/usb_ak820.c:453: ACK_TRANSFER();
      0064E8 90 22 0F         [24] 3028 	mov	dptr,#0x220f
      0064EB E4               [12] 3029 	clr	a
      0064EC F0               [24] 3030 	movx	@dptr,a
      0064ED 80 2C            [24] 3031 	sjmp	00130$
      0064EF                       3032 00124$:
                                   3033 ;	tmk_core/protocol/ch555/usb_ak820.c:454: } else if (USB_IF & bUX_IF_SUSPEND) {
      0064EF 90 22 3D         [24] 3034 	mov	dptr,#0x223d
      0064F2 E0               [24] 3035 	movx	a,@dptr
      0064F3 30 E2 25         [24] 3036 	jnb	acc.2,00130$
                                   3037 ;	tmk_core/protocol/ch555/usb_ak820.c:455: if (USB_IF & bUX_SUSPEND) USB_SleepStatus |= 2;
      0064F6 90 22 3D         [24] 3038 	mov	dptr,#0x223d
      0064F9 E0               [24] 3039 	movx	a,@dptr
      0064FA 30 E3 0A         [24] 3040 	jnb	acc.3,00119$
      0064FD 90 07 64         [24] 3041 	mov	dptr,#_USB_SleepStatus
      006500 E0               [24] 3042 	movx	a,@dptr
      006501 43 E0 02         [24] 3043 	orl	acc,#0x02
      006504 F0               [24] 3044 	movx	@dptr,a
      006505 80 0E            [24] 3045 	sjmp	00120$
      006507                       3046 00119$:
                                   3047 ;	tmk_core/protocol/ch555/usb_ak820.c:457: USB_SleepStatus &= ~2;
      006507 90 07 64         [24] 3048 	mov	dptr,#_USB_SleepStatus
      00650A E0               [24] 3049 	movx	a,@dptr
      00650B 53 E0 FD         [24] 3050 	anl	acc,#0xfd
      00650E F0               [24] 3051 	movx	@dptr,a
                                   3052 ;	tmk_core/protocol/ch555/usb_ak820.c:458: keyboard_reset = 1;
      00650F 90 07 8C         [24] 3053 	mov	dptr,#_keyboard_reset
      006512 74 01            [12] 3054 	mov	a,#0x01
      006514 F0               [24] 3055 	movx	@dptr,a
      006515                       3056 00120$:
                                   3057 ;	tmk_core/protocol/ch555/usb_ak820.c:460: ACK_SUSPEND();
      006515 90 22 3D         [24] 3058 	mov	dptr,#0x223d
      006518 74 04            [12] 3059 	mov	a,#0x04
      00651A F0               [24] 3060 	movx	@dptr,a
      00651B                       3061 00130$:
                                   3062 ;	tmk_core/protocol/ch555/usb_ak820.c:462: } while (USB_IF & (bUX_IF_BUS_RST | bUX_IF_D0_TRANS | bUX_IF_SUSPEND));
      00651B 90 22 3D         [24] 3063 	mov	dptr,#0x223d
      00651E E0               [24] 3064 	movx	a,@dptr
      00651F 54 25            [12] 3065 	anl	a,#0x25
      006521 60 03            [24] 3066 	jz	00242$
      006523 02 64 36         [24] 3067 	ljmp	00129$
      006526                       3068 00242$:
                                   3069 ;	tmk_core/protocol/ch555/usb_ak820.c:463: }
      006526 22               [24] 3070 	ret
                                   3071 ;------------------------------------------------------------
                                   3072 ;Allocation info for local variables in function 'USB_Device_Init'
                                   3073 ;------------------------------------------------------------
                                   3074 ;	tmk_core/protocol/ch555/usb_ak820.c:466: void USB_Device_Init(void) {
                                   3075 ;	-----------------------------------------
                                   3076 ;	 function USB_Device_Init
                                   3077 ;	-----------------------------------------
      006527                       3078 _USB_Device_Init:
                                   3079 ;	tmk_core/protocol/ch555/usb_ak820.c:467: IE_USB = 0;
                                   3080 ;	assignBit
      006527 C2 E9            [12] 3081 	clr	_IE_USB
                                   3082 ;	tmk_core/protocol/ch555/usb_ak820.c:468: USB_CTRL = 0;
      006529 90 22 3C         [24] 3083 	mov	dptr,#0x223c
      00652C E4               [12] 3084 	clr	a
      00652D F0               [24] 3085 	movx	@dptr,a
                                   3086 ;	tmk_core/protocol/ch555/usb_ak820.c:469: raw_state = RAW_IDLE;
      00652E 90 07 6A         [24] 3087 	mov	dptr,#_raw_state
      006531 F0               [24] 3088 	movx	@dptr,a
                                   3089 ;	tmk_core/protocol/ch555/usb_ak820.c:470: endpoints_reset();
      006532 12 59 22         [24] 3090 	lcall	_endpoints_reset
                                   3091 ;	tmk_core/protocol/ch555/usb_ak820.c:471: D0_ADDR = D0UsbConfig = USB_EnumStatus = USB_SleepStatus = 0;
      006535 90 07 64         [24] 3092 	mov	dptr,#_USB_SleepStatus
      006538 E4               [12] 3093 	clr	a
      006539 F0               [24] 3094 	movx	@dptr,a
      00653A 90 07 63         [24] 3095 	mov	dptr,#_USB_EnumStatus
      00653D F0               [24] 3096 	movx	@dptr,a
      00653E 90 07 62         [24] 3097 	mov	dptr,#_D0UsbConfig
      006541 F0               [24] 3098 	movx	@dptr,a
      006542 90 22 07         [24] 3099 	mov	dptr,#0x2207
      006545 F0               [24] 3100 	movx	@dptr,a
                                   3101 ;	tmk_core/protocol/ch555/usb_ak820.c:472: KB_USB_SetReport = KB_USB_UpStatus = MCU_Sleep_Operate = 0;
      006546 90 07 65         [24] 3102 	mov	dptr,#_MCU_Sleep_Operate
      006549 F0               [24] 3103 	movx	@dptr,a
      00654A 90 07 66         [24] 3104 	mov	dptr,#_KB_USB_UpStatus
      00654D F0               [24] 3105 	movx	@dptr,a
      00654E 90 07 67         [24] 3106 	mov	dptr,#_KB_USB_SetReport
      006551 F0               [24] 3107 	movx	@dptr,a
                                   3108 ;	tmk_core/protocol/ch555/usb_ak820.c:473: keyboard_protocol = 1;
      006552 90 0D AC         [24] 3109 	mov	dptr,#_keyboard_protocol
      006555 04               [12] 3110 	inc	a
      006556 F0               [24] 3111 	movx	@dptr,a
                                   3112 ;	tmk_core/protocol/ch555/usb_ak820.c:474: keyboard_idle = 0;
      006557 90 06 3A         [24] 3113 	mov	dptr,#_keyboard_idle
      00655A E4               [12] 3114 	clr	a
      00655B F0               [24] 3115 	movx	@dptr,a
                                   3116 ;	tmk_core/protocol/ch555/usb_ak820.c:475: keyboard_reset = 0;
      00655C 90 07 8C         [24] 3117 	mov	dptr,#_keyboard_reset
      00655F F0               [24] 3118 	movx	@dptr,a
                                   3119 ;	tmk_core/protocol/ch555/usb_ak820.c:476: control_phase = CTRL_IDLE;
      006560 90 07 BB         [24] 3120 	mov	dptr,#_control_phase
      006563 F0               [24] 3121 	movx	@dptr,a
                                   3122 ;	tmk_core/protocol/ch555/usb_ak820.c:477: D0SetupReqCode = 0xff;
      006564 90 07 5C         [24] 3123 	mov	dptr,#_D0SetupReqCode
      006567 14               [12] 3124 	dec	a
      006568 F0               [24] 3125 	movx	@dptr,a
                                   3126 ;	tmk_core/protocol/ch555/usb_ak820.c:478: D0SetupLen = 0;
      006569 90 07 5D         [24] 3127 	mov	dptr,#_D0SetupLen
      00656C E4               [12] 3128 	clr	a
      00656D F0               [24] 3129 	movx	@dptr,a
      00656E A3               [24] 3130 	inc	dptr
      00656F F0               [24] 3131 	movx	@dptr,a
                                   3132 ;	tmk_core/protocol/ch555/usb_ak820.c:479: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      006570 90 22 00         [24] 3133 	mov	dptr,#0x2200
      006573 74 02            [12] 3134 	mov	a,#0x02
      006575 F0               [24] 3135 	movx	@dptr,a
                                   3136 ;	tmk_core/protocol/ch555/usb_ak820.c:480: HB_ADDR = 0x7f;
      006576 90 22 37         [24] 3137 	mov	dptr,#0x2237
      006579 74 7F            [12] 3138 	mov	a,#0x7f
      00657B F0               [24] 3139 	movx	@dptr,a
                                   3140 ;	tmk_core/protocol/ch555/usb_ak820.c:481: ACK_ALL();
      00657C 90 22 3D         [24] 3141 	mov	dptr,#0x223d
      00657F 74 FF            [12] 3142 	mov	a,#0xff
      006581 F0               [24] 3143 	movx	@dptr,a
                                   3144 ;	tmk_core/protocol/ch555/usb_ak820.c:482: USB_IE = bUX_IE_SUSPEND | bUX_IE_TRANSFER | bUX_IE_BUS_RST;
      006582 90 22 3B         [24] 3145 	mov	dptr,#0x223b
      006585 74 07            [12] 3146 	mov	a,#0x07
      006587 F0               [24] 3147 	movx	@dptr,a
                                   3148 ;	tmk_core/protocol/ch555/usb_ak820.c:483: USB_CTRL = bUX_DP_PU_EN;
      006588 A3               [24] 3149 	inc	dptr
      006589 74 80            [12] 3150 	mov	a,#0x80
      00658B F0               [24] 3151 	movx	@dptr,a
                                   3152 ;	tmk_core/protocol/ch555/usb_ak820.c:484: IE_USB = 1;
                                   3153 ;	assignBit
      00658C D2 E9            [12] 3154 	setb	_IE_USB
                                   3155 ;	tmk_core/protocol/ch555/usb_ak820.c:485: }
      00658E 22               [24] 3156 	ret
                                   3157 ;------------------------------------------------------------
                                   3158 ;Allocation info for local variables in function 'USB_WakeUp_PC'
                                   3159 ;------------------------------------------------------------
                                   3160 ;saved         Allocated with name '_USB_WakeUp_PC_saved_10000_417'
                                   3161 ;i             Allocated with name '_USB_WakeUp_PC_i_30000_420'
                                   3162 ;------------------------------------------------------------
                                   3163 ;	tmk_core/protocol/ch555/usb_ak820.c:487: void USB_WakeUp_PC(void) {
                                   3164 ;	-----------------------------------------
                                   3165 ;	 function USB_WakeUp_PC
                                   3166 ;	-----------------------------------------
      00658F                       3167 _USB_WakeUp_PC:
                                   3168 ;	tmk_core/protocol/ch555/usb_ak820.c:489: if (USB_SleepStatus != 3) return;
      00658F 90 07 64         [24] 3169 	mov	dptr,#_USB_SleepStatus
      006592 E0               [24] 3170 	movx	a,@dptr
      006593 FF               [12] 3171 	mov	r7,a
      006594 BF 03 22         [24] 3172 	cjne	r7,#0x03,00110$
                                   3173 ;	tmk_core/protocol/ch555/usb_ak820.c:490: saved = USB_CTRL;
      006597 90 22 3C         [24] 3174 	mov	dptr,#0x223c
      00659A E0               [24] 3175 	movx	a,@dptr
      00659B FF               [12] 3176 	mov	r7,a
                                   3177 ;	tmk_core/protocol/ch555/usb_ak820.c:491: USB_CTRL ^= bUX_DP_PU_EN | bUX_DM_PU_EN;
      00659C E0               [24] 3178 	movx	a,@dptr
      00659D FE               [12] 3179 	mov	r6,a
      00659E 63 06 C0         [24] 3180 	xrl	ar6,#0xc0
      0065A1 90 22 3C         [24] 3181 	mov	dptr,#0x223c
      0065A4 EE               [12] 3182 	mov	a,r6
      0065A5 F0               [24] 3183 	movx	@dptr,a
                                   3184 ;	tmk_core/protocol/ch555/usb_ak820.c:492: wait_ms(10);
      0065A6 7E 0A            [12] 3185 	mov	r6,#0x0a
      0065A8                       3186 00108$:
      0065A8 EE               [12] 3187 	mov	a,r6
      0065A9 60 09            [24] 3188 	jz	00105$
      0065AB 90 00 01         [24] 3189 	mov	dptr,#0x0001
      0065AE 12 57 69         [24] 3190 	lcall	_mDelaymS
      0065B1 1E               [12] 3191 	dec	r6
      0065B2 80 F4            [24] 3192 	sjmp	00108$
      0065B4                       3193 00105$:
                                   3194 ;	tmk_core/protocol/ch555/usb_ak820.c:493: USB_CTRL = saved;
      0065B4 90 22 3C         [24] 3195 	mov	dptr,#0x223c
      0065B7 EF               [12] 3196 	mov	a,r7
      0065B8 F0               [24] 3197 	movx	@dptr,a
      0065B9                       3198 00110$:
                                   3199 ;	tmk_core/protocol/ch555/usb_ak820.c:494: }
      0065B9 22               [24] 3200 	ret
                                   3201 ;------------------------------------------------------------
                                   3202 ;Allocation info for local variables in function 'ak820_usb_send'
                                   3203 ;------------------------------------------------------------
                                   3204 ;sloc0         Allocated with name '_ak820_usb_send_sloc0_1_0'
                                   3205 ;sloc1         Allocated with name '_ak820_usb_send_sloc1_1_0'
                                   3206 ;report        Allocated with name '_ak820_usb_send_PARM_2'
                                   3207 ;length        Allocated with name '_ak820_usb_send_PARM_3'
                                   3208 ;endpoint      Allocated with name '_ak820_usb_send_endpoint_10000_422'
                                   3209 ;saved_ea      Allocated with name '_ak820_usb_send_saved_ea_10000_423'
                                   3210 ;i             Allocated with name '_ak820_usb_send_i_10000_423'
                                   3211 ;timeout       Allocated with name '_ak820_usb_send_timeout_10000_423'
                                   3212 ;offset        Allocated with name '_ak820_usb_send_offset_10000_423'
                                   3213 ;report_id     Allocated with name '_ak820_usb_send_report_id_10000_423'
                                   3214 ;i             Allocated with name '_ak820_usb_send_i_30000_435'
                                   3215 ;------------------------------------------------------------
                                   3216 ;	tmk_core/protocol/ch555/usb_ak820.c:496: bool ak820_usb_send(uint8_t endpoint, const uint8_t __xdata *report, uint8_t length) {
                                   3217 ;	-----------------------------------------
                                   3218 ;	 function ak820_usb_send
                                   3219 ;	-----------------------------------------
      0065BA                       3220 _ak820_usb_send:
      0065BA E5 82            [12] 3221 	mov	a,dpl
      0065BC 90 07 CB         [24] 3222 	mov	dptr,#_ak820_usb_send_endpoint_10000_422
      0065BF F0               [24] 3223 	movx	@dptr,a
                                   3224 ;	tmk_core/protocol/ch555/usb_ak820.c:500: uint8_t offset = SNAPSHOT_SIZE;
      0065C0 90 07 CC         [24] 3225 	mov	dptr,#_ak820_usb_send_offset_10000_423
      0065C3 74 2E            [12] 3226 	mov	a,#0x2e
      0065C5 F0               [24] 3227 	movx	@dptr,a
                                   3228 ;	tmk_core/protocol/ch555/usb_ak820.c:502: if (endpoint < 1 || endpoint > 3 || length > 64 || !USB_EnumStatus) return false;
      0065C6 90 07 CB         [24] 3229 	mov	dptr,#_ak820_usb_send_endpoint_10000_422
      0065C9 E0               [24] 3230 	movx	a,@dptr
      0065CA FF               [12] 3231 	mov	r7,a
      0065CB BF 01 00         [24] 3232 	cjne	r7,#0x01,00306$
      0065CE                       3233 00306$:
      0065CE 40 14            [24] 3234 	jc	00101$
      0065D0 EF               [12] 3235 	mov	a,r7
      0065D1 24 FC            [12] 3236 	add	a,#0xff - 0x03
      0065D3 40 0F            [24] 3237 	jc	00101$
                                   3238 ;	free result
      0065D5 90 07 CA         [24] 3239 	mov	dptr,#_ak820_usb_send_PARM_3
      0065D8 E0               [24] 3240 	movx	a,@dptr
      0065D9 FE               [12] 3241 	mov  r6,a
      0065DA 24 BF            [12] 3242 	add	a,#0xff - 0x40
      0065DC 40 06            [24] 3243 	jc	00101$
                                   3244 ;	free result
      0065DE 90 07 63         [24] 3245 	mov	dptr,#_USB_EnumStatus
      0065E1 E0               [24] 3246 	movx	a,@dptr
      0065E2 70 04            [24] 3247 	jnz	00102$
      0065E4                       3248 00101$:
      0065E4 75 82 00         [24] 3249 	mov	dpl, #0x00
      0065E7 22               [24] 3250 	ret
      0065E8                       3251 00102$:
                                   3252 ;	tmk_core/protocol/ch555/usb_ak820.c:503: if (endpoint == KEYBOARD_IN_EPNUM) {
      0065E8 BF 01 10         [24] 3253 	cjne	r7,#0x01,00118$
                                   3254 ;	tmk_core/protocol/ch555/usb_ak820.c:504: if (length != KEYBOARD_EPSIZE) return false;
      0065EB BE 08 02         [24] 3255 	cjne	r6,#0x08,00313$
      0065EE 80 04            [24] 3256 	sjmp	00107$
      0065F0                       3257 00313$:
      0065F0 75 82 00         [24] 3258 	mov	dpl, #0x00
      0065F3 22               [24] 3259 	ret
      0065F4                       3260 00107$:
                                   3261 ;	tmk_core/protocol/ch555/usb_ak820.c:505: offset = SNAPSHOT_KEYBOARD;
      0065F4 90 07 CC         [24] 3262 	mov	dptr,#_ak820_usb_send_offset_10000_423
      0065F7 E4               [12] 3263 	clr	a
      0065F8 F0               [24] 3264 	movx	@dptr,a
      0065F9 80 3C            [24] 3265 	sjmp	00119$
      0065FB                       3266 00118$:
                                   3267 ;	tmk_core/protocol/ch555/usb_ak820.c:506: } else if (endpoint == SHARED_IN_EPNUM) {
      0065FB BF 02 30         [24] 3268 	cjne	r7,#0x02,00115$
                                   3269 ;	tmk_core/protocol/ch555/usb_ak820.c:507: report_id = report[0];
      0065FE 90 07 C8         [24] 3270 	mov	dptr,#_ak820_usb_send_PARM_2
      006601 E0               [24] 3271 	movx	a,@dptr
      006602 FD               [12] 3272 	mov	r5,a
      006603 A3               [24] 3273 	inc	dptr
      006604 E0               [24] 3274 	movx	a,@dptr
      006605 FF               [12] 3275 	mov	r7,a
      006606 8D 82            [24] 3276 	mov	dpl,r5
      006608 8F 83            [24] 3277 	mov	dph,r7
      00660A E0               [24] 3278 	movx	a,@dptr
      00660B FF               [12] 3279 	mov	r7,a
                                   3280 ;	tmk_core/protocol/ch555/usb_ak820.c:508: if (report_id >= sizeof(shared_lengths) || !shared_lengths[report_id] || length != shared_lengths[report_id]) return false;
      00660C BF 07 00         [24] 3281 	cjne	r7,#0x07,00316$
      00660F                       3282 00316$:
      00660F 50 0E            [24] 3283 	jnc	00108$
      006611 EF               [12] 3284 	mov	a,r7
      006612 90 B7 14         [24] 3285 	mov	dptr,#_shared_lengths
      006615 93               [24] 3286 	movc	a,@a+dptr
      006616 FD               [12] 3287 	mov	r5,a
      006617 60 06            [24] 3288 	jz	00108$
      006619 EE               [12] 3289 	mov	a,r6
      00661A B5 05 02         [24] 3290 	cjne	a,ar5,00319$
      00661D 80 04            [24] 3291 	sjmp	00109$
      00661F                       3292 00319$:
      00661F                       3293 00108$:
      00661F 75 82 00         [24] 3294 	mov	dpl, #0x00
      006622 22               [24] 3295 	ret
      006623                       3296 00109$:
                                   3297 ;	tmk_core/protocol/ch555/usb_ak820.c:509: offset = shared_offsets[report_id];
      006623 EF               [12] 3298 	mov	a,r7
      006624 90 B7 0D         [24] 3299 	mov	dptr,#_shared_offsets
      006627 93               [24] 3300 	movc	a,@a+dptr
      006628 90 07 CC         [24] 3301 	mov	dptr,#_ak820_usb_send_offset_10000_423
      00662B F0               [24] 3302 	movx	@dptr,a
      00662C 80 09            [24] 3303 	sjmp	00119$
      00662E                       3304 00115$:
                                   3305 ;	tmk_core/protocol/ch555/usb_ak820.c:510: } else if (length != RAW_EPSIZE) return false;
      00662E BE 20 02         [24] 3306 	cjne	r6,#0x20,00320$
      006631 80 04            [24] 3307 	sjmp	00119$
      006633                       3308 00320$:
      006633 75 82 00         [24] 3309 	mov	dpl, #0x00
      006636 22               [24] 3310 	ret
      006637                       3311 00119$:
                                   3312 ;	tmk_core/protocol/ch555/usb_ak820.c:511: if (USB_SleepStatus & 2) { USB_WakeUp_PC(); return false; }
      006637 90 07 64         [24] 3313 	mov	dptr,#_USB_SleepStatus
      00663A E0               [24] 3314 	movx	a,@dptr
      00663B 30 E1 07         [24] 3315 	jnb	acc.1,00184$
      00663E 12 65 8F         [24] 3316 	lcall	_USB_WakeUp_PC
      006641 75 82 00         [24] 3317 	mov	dpl, #0x00
      006644 22               [24] 3318 	ret
                                   3319 ;	tmk_core/protocol/ch555/usb_ak820.c:512: while ((EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_ACK && timeout--) wait_us(40);
      006645                       3320 00184$:
      006645 7F FA            [12] 3321 	mov	r7,#0xfa
      006647                       3322 00127$:
      006647 90 07 CB         [24] 3323 	mov	dptr,#_ak820_usb_send_endpoint_10000_422
      00664A E0               [24] 3324 	movx	a,@dptr
      00664B FC               [12] 3325 	mov	r4,a
      00664C 7D 00            [12] 3326 	mov	r5,#0x00
      00664E 8C 02            [24] 3327 	mov	ar2,r4
      006650 74 22            [12] 3328 	mov	a,#0x22
      006652 2D               [12] 3329 	add	a, r5
      006653 FB               [12] 3330 	mov	r3,a
      006654 8A 82            [24] 3331 	mov	dpl,r2
      006656 8B 83            [24] 3332 	mov	dph,r3
      006658 E0               [24] 3333 	movx	a,@dptr
      006659 54 03            [12] 3334 	anl	a,#0x03
      00665B 70 14            [24] 3335 	jnz	00129$
      00665D 8F 03            [24] 3336 	mov	ar3,r7
      00665F 1F               [12] 3337 	dec	r7
      006660 EB               [12] 3338 	mov	a,r3
      006661 60 0E            [24] 3339 	jz	00129$
      006663 7B 28            [12] 3340 	mov	r3,#0x28
      006665                       3341 00141$:
      006665 EB               [12] 3342 	mov	a,r3
      006666 60 DF            [24] 3343 	jz	00127$
      006668 90 00 01         [24] 3344 	mov	dptr,#0x0001
      00666B 12 57 25         [24] 3345 	lcall	_mDelayuS
      00666E 1B               [12] 3346 	dec	r3
      00666F 80 F4            [24] 3347 	sjmp	00141$
      006671                       3348 00129$:
                                   3349 ;	tmk_core/protocol/ch555/usb_ak820.c:513: saved_ea = EA;
      006671 A2 AF            [12] 3350 	mov	c,_EA
      006673 E4               [12] 3351 	clr	a
      006674 33               [12] 3352 	rlc	a
      006675 FF               [12] 3353 	mov	r7,a
                                   3354 ;	tmk_core/protocol/ch555/usb_ak820.c:514: EA = 0;
                                   3355 ;	assignBit
      006676 C2 AF            [12] 3356 	clr	_EA
                                   3357 ;	tmk_core/protocol/ch555/usb_ak820.c:515: if (!USB_EnumStatus || (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) != UEP_X_RES_NAK ||
      006678 90 07 63         [24] 3358 	mov	dptr,#_USB_EnumStatus
      00667B E0               [24] 3359 	movx	a,@dptr
      00667C 60 25            [24] 3360 	jz	00130$
      00667E 90 07 CB         [24] 3361 	mov	dptr,#_ak820_usb_send_endpoint_10000_422
      006681 E0               [24] 3362 	movx	a,@dptr
      006682 FB               [12] 3363 	mov	r3,a
      006683 F9               [12] 3364 	mov	r1,a
      006684 7A 00            [12] 3365 	mov	r2,#0x00
      006686 74 22            [12] 3366 	mov	a,#0x22
      006688 2A               [12] 3367 	add	a, r2
      006689 FA               [12] 3368 	mov	r2,a
      00668A 89 82            [24] 3369 	mov	dpl,r1
      00668C 8A 83            [24] 3370 	mov	dph,r2
      00668E E0               [24] 3371 	movx	a,@dptr
      00668F FA               [12] 3372 	mov	r2,a
      006690 53 02 03         [24] 3373 	anl	ar2,#0x03
      006693 BA 02 0D         [24] 3374 	cjne	r2,#0x02,00130$
                                   3375 ;	tmk_core/protocol/ch555/usb_ak820.c:516: (endpoint == RAW_IN_EPNUM && raw_state != RAW_WORK)) { EA = saved_ea; return false; }
      006696 BB 03 13         [24] 3376 	cjne	r3,#0x03,00192$
      006699 90 07 6A         [24] 3377 	mov	dptr,#_raw_state
      00669C E0               [24] 3378 	movx	a,@dptr
      00669D FB               [12] 3379 	mov	r3,a
      00669E BB 03 02         [24] 3380 	cjne	r3,#0x03,00331$
      0066A1 80 09            [24] 3381 	sjmp	00192$
      0066A3                       3382 00331$:
      0066A3                       3383 00130$:
                                   3384 ;	assignBit
      0066A3 EF               [12] 3385 	mov	a,r7
      0066A4 24 FF            [12] 3386 	add	a,#0xff
      0066A6 92 AF            [24] 3387 	mov	_EA,c
      0066A8 75 82 00         [24] 3388 	mov	dpl, #0x00
      0066AB 22               [24] 3389 	ret
                                   3390 ;	tmk_core/protocol/ch555/usb_ak820.c:517: for (i = 0; i < length; ++i) {
      0066AC                       3391 00192$:
      0066AC 7B 00            [12] 3392 	mov	r3,#0x00
      0066AE                       3393 00144$:
      0066AE C3               [12] 3394 	clr	c
      0066AF EB               [12] 3395 	mov	a,r3
      0066B0 9E               [12] 3396 	subb	a,r6
      0066B1 50 67            [24] 3397 	jnc	00137$
                                   3398 ;	tmk_core/protocol/ch555/usb_ak820.c:518: pUSB_BUF_DEV0[((uint16_t)endpoint << 6) + i] = report[i];
      0066B3 C0 07            [24] 3399 	push	ar7
      0066B5 90 07 CB         [24] 3400 	mov	dptr,#_ak820_usb_send_endpoint_10000_422
      0066B8 E0               [24] 3401 	movx	a,@dptr
      0066B9 F9               [12] 3402 	mov	r1,a
      0066BA E4               [12] 3403 	clr	a
      0066BB C3               [12] 3404 	clr	c
      0066BC C9               [12] 3405 	xch	a,r1
      0066BD 13               [12] 3406 	rrc	a
      0066BE C9               [12] 3407 	xch	a,r1
      0066BF 13               [12] 3408 	rrc	a
      0066C0 A2 E0            [12] 3409 	mov	c,acc.0
      0066C2 C9               [12] 3410 	xch	a,r1
      0066C3 13               [12] 3411 	rrc	a
      0066C4 C9               [12] 3412 	xch	a,r1
      0066C5 13               [12] 3413 	rrc	a
      0066C6 C9               [12] 3414 	xch	a,r1
      0066C7 FA               [12] 3415 	mov	r2,a
      0066C8 8B 00            [24] 3416 	mov	ar0,r3
      0066CA 7F 00            [12] 3417 	mov	r7,#0x00
      0066CC E8               [12] 3418 	mov	a,r0
      0066CD 29               [12] 3419 	add	a, r1
      0066CE F9               [12] 3420 	mov	r1,a
      0066CF EF               [12] 3421 	mov	a,r7
      0066D0 3A               [12] 3422 	addc	a, r2
      0066D1 24 10            [12] 3423 	add	a,#0x10
      0066D3 FA               [12] 3424 	mov	r2,a
      0066D4 90 07 C8         [24] 3425 	mov	dptr,#_ak820_usb_send_PARM_2
      0066D7 E0               [24] 3426 	movx	a,@dptr
      0066D8 F8               [12] 3427 	mov	r0,a
      0066D9 A3               [24] 3428 	inc	dptr
      0066DA E0               [24] 3429 	movx	a,@dptr
      0066DB FF               [12] 3430 	mov	r7,a
      0066DC EB               [12] 3431 	mov	a,r3
      0066DD 28               [12] 3432 	add	a, r0
      0066DE F5 1B            [12] 3433 	mov	_ak820_usb_send_sloc0_1_0,a
      0066E0 E4               [12] 3434 	clr	a
      0066E1 3F               [12] 3435 	addc	a, r7
      0066E2 F5 1C            [12] 3436 	mov	(_ak820_usb_send_sloc0_1_0 + 1),a
      0066E4 85 1B 82         [24] 3437 	mov	dpl,_ak820_usb_send_sloc0_1_0
      0066E7 85 1C 83         [24] 3438 	mov	dph,(_ak820_usb_send_sloc0_1_0 + 1)
      0066EA E0               [24] 3439 	movx	a,@dptr
      0066EB 89 82            [24] 3440 	mov	dpl,r1
      0066ED 8A 83            [24] 3441 	mov	dph,r2
      0066EF F0               [24] 3442 	movx	@dptr,a
                                   3443 ;	tmk_core/protocol/ch555/usb_ak820.c:519: if (offset != SNAPSHOT_SIZE) input_snapshot[offset + i] = report[i];
      0066F0 90 07 CC         [24] 3444 	mov	dptr,#_ak820_usb_send_offset_10000_423
      0066F3 E0               [24] 3445 	movx	a,@dptr
      0066F4 F5 1D            [12] 3446 	mov	_ak820_usb_send_sloc1_1_0,a
      0066F6 74 2E            [12] 3447 	mov	a,#0x2e
      0066F8 B5 1D 04         [24] 3448 	cjne	a,_ak820_usb_send_sloc1_1_0,00333$
      0066FB D0 07            [24] 3449 	pop	ar7
      0066FD 80 18            [24] 3450 	sjmp	00145$
      0066FF                       3451 00333$:
      0066FF D0 07            [24] 3452 	pop	ar7
      006701 EB               [12] 3453 	mov	a,r3
      006702 25 1D            [12] 3454 	add	a, _ak820_usb_send_sloc1_1_0
      006704 24 8D            [12] 3455 	add	a, #_input_snapshot
      006706 F9               [12] 3456 	mov	r1,a
      006707 E4               [12] 3457 	clr	a
      006708 34 07            [12] 3458 	addc	a,#(_input_snapshot >> 8)
      00670A FA               [12] 3459 	mov	r2,a
      00670B 85 1B 82         [24] 3460 	mov	dpl,_ak820_usb_send_sloc0_1_0
      00670E 85 1C 83         [24] 3461 	mov	dph,(_ak820_usb_send_sloc0_1_0 + 1)
      006711 E0               [24] 3462 	movx	a,@dptr
      006712 89 82            [24] 3463 	mov	dpl,r1
      006714 8A 83            [24] 3464 	mov	dph,r2
      006716 F0               [24] 3465 	movx	@dptr,a
      006717                       3466 00145$:
                                   3467 ;	tmk_core/protocol/ch555/usb_ak820.c:517: for (i = 0; i < length; ++i) {
      006717 0B               [12] 3468 	inc	r3
      006718 80 94            [24] 3469 	sjmp	00144$
      00671A                       3470 00137$:
                                   3471 ;	tmk_core/protocol/ch555/usb_ak820.c:521: EP_LENGTH(endpoint) = length;
      00671A 90 07 CB         [24] 3472 	mov	dptr,#_ak820_usb_send_endpoint_10000_422
      00671D E0               [24] 3473 	movx	a,@dptr
      00671E FB               [12] 3474 	mov	r3,a
      00671F F9               [12] 3475 	mov	r1,a
      006720 7A 00            [12] 3476 	mov	r2,#0x00
      006722 74 08            [12] 3477 	mov	a,#0x08
      006724 29               [12] 3478 	add	a, r1
      006725 F9               [12] 3479 	mov	r1,a
      006726 74 22            [12] 3480 	mov	a,#0x22
      006728 3A               [12] 3481 	addc	a, r2
      006729 FA               [12] 3482 	mov	r2,a
      00672A 89 82            [24] 3483 	mov	dpl,r1
      00672C 8A 83            [24] 3484 	mov	dph,r2
      00672E EE               [12] 3485 	mov	a,r6
      00672F F0               [24] 3486 	movx	@dptr,a
                                   3487 ;	tmk_core/protocol/ch555/usb_ak820.c:522: if (endpoint == RAW_IN_EPNUM) raw_state = RAW_TX_ACTIVE;
      006730 BB 03 06         [24] 3488 	cjne	r3,#0x03,00139$
      006733 90 07 6A         [24] 3489 	mov	dptr,#_raw_state
      006736 74 04            [12] 3490 	mov	a,#0x04
      006738 F0               [24] 3491 	movx	@dptr,a
      006739                       3492 00139$:
                                   3493 ;	tmk_core/protocol/ch555/usb_ak820.c:523: EP_RESPONSE(endpoint) = (EP_RESPONSE(endpoint) & ~MASK_UEP_X_RES) | UEP_X_RES_ACK;
      006739 74 22            [12] 3494 	mov	a,#0x22
      00673B 2D               [12] 3495 	add	a, r5
      00673C FD               [12] 3496 	mov	r5,a
      00673D 8C 82            [24] 3497 	mov	dpl,r4
      00673F 8D 83            [24] 3498 	mov	dph,r5
      006741 E0               [24] 3499 	movx	a,@dptr
      006742 FE               [12] 3500 	mov	r6,a
      006743 53 06 FC         [24] 3501 	anl	ar6,#0xfc
      006746 8C 82            [24] 3502 	mov	dpl,r4
      006748 8D 83            [24] 3503 	mov	dph,r5
      00674A EE               [12] 3504 	mov	a,r6
      00674B F0               [24] 3505 	movx	@dptr,a
                                   3506 ;	tmk_core/protocol/ch555/usb_ak820.c:524: EA = saved_ea;
                                   3507 ;	assignBit
      00674C EF               [12] 3508 	mov	a,r7
      00674D 24 FF            [12] 3509 	add	a,#0xff
      00674F 92 AF            [24] 3510 	mov	_EA,c
                                   3511 ;	tmk_core/protocol/ch555/usb_ak820.c:525: return true;
      006751 75 82 01         [24] 3512 	mov	dpl, #0x01
                                   3513 ;	tmk_core/protocol/ch555/usb_ak820.c:526: }
      006754 22               [24] 3514 	ret
                                   3515 ;------------------------------------------------------------
                                   3516 ;Allocation info for local variables in function 'ak820_usb_try_send'
                                   3517 ;------------------------------------------------------------
                                   3518 ;report        Allocated with name '_ak820_usb_try_send_PARM_2'
                                   3519 ;length        Allocated with name '_ak820_usb_try_send_PARM_3'
                                   3520 ;endpoint      Allocated with name '_ak820_usb_try_send_endpoint_10000_443'
                                   3521 ;saved_ea      Allocated with name '_ak820_usb_try_send_saved_ea_10000_444'
                                   3522 ;sent          Allocated with name '_ak820_usb_try_send_sent_10000_444'
                                   3523 ;------------------------------------------------------------
                                   3524 ;	tmk_core/protocol/ch555/usb_ak820.c:528: bool ak820_usb_try_send(uint8_t endpoint, const uint8_t __xdata *report, uint8_t length) {
                                   3525 ;	-----------------------------------------
                                   3526 ;	 function ak820_usb_try_send
                                   3527 ;	-----------------------------------------
      006755                       3528 _ak820_usb_try_send:
      006755 E5 82            [12] 3529 	mov	a,dpl
      006757 90 07 D0         [24] 3530 	mov	dptr,#_ak820_usb_try_send_endpoint_10000_443
      00675A F0               [24] 3531 	movx	@dptr,a
                                   3532 ;	tmk_core/protocol/ch555/usb_ak820.c:529: uint8_t saved_ea = EA;
                                   3533 ;	assignBit
      00675B A2 AF            [12] 3534 	mov	c,_EA
      00675D 92 1C            [24] 3535 	mov	_ak820_usb_try_send_sloc0_1_0,c
                                   3536 ;	tmk_core/protocol/ch555/usb_ak820.c:530: bool sent = false;
      00675F 90 07 D1         [24] 3537 	mov	dptr,#_ak820_usb_try_send_sent_10000_444
      006762 E4               [12] 3538 	clr	a
      006763 F0               [24] 3539 	movx	@dptr,a
                                   3540 ;	tmk_core/protocol/ch555/usb_ak820.c:531: EA = 0;
                                   3541 ;	assignBit
      006764 C2 AF            [12] 3542 	clr	_EA
                                   3543 ;	tmk_core/protocol/ch555/usb_ak820.c:535: if (endpoint >= 1 && endpoint <= 2 && USB_EnumStatus &&
      006766 90 07 D0         [24] 3544 	mov	dptr,#_ak820_usb_try_send_endpoint_10000_443
      006769 E0               [24] 3545 	movx	a,@dptr
      00676A FF               [12] 3546 	mov	r7,a
      00676B BF 01 00         [24] 3547 	cjne	r7,#0x01,00152$
      00676E                       3548 00152$:
      00676E 40 4E            [24] 3549 	jc	00102$
      006770 EF               [12] 3550 	mov	a,r7
      006771 24 FD            [12] 3551 	add	a,#0xff - 0x02
      006773 40 49            [24] 3552 	jc	00102$
                                   3553 ;	free result
      006775 90 07 63         [24] 3554 	mov	dptr,#_USB_EnumStatus
      006778 E0               [24] 3555 	movx	a,@dptr
      006779 60 43            [24] 3556 	jz	00102$
                                   3557 ;	tmk_core/protocol/ch555/usb_ak820.c:536: !(USB_SleepStatus & 2) && !keyboard_reset &&
      00677B 90 07 64         [24] 3558 	mov	dptr,#_USB_SleepStatus
      00677E E0               [24] 3559 	movx	a,@dptr
      00677F 20 E1 3C         [24] 3560 	jb	acc.1,00102$
      006782 90 07 8C         [24] 3561 	mov	dptr,#_keyboard_reset
      006785 E0               [24] 3562 	movx	a,@dptr
                                   3563 ;	tmk_core/protocol/ch555/usb_ak820.c:537: (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_NAK) {
      006786 70 36            [24] 3564 	jnz	00102$
      006788 8F 06            [24] 3565 	mov	ar6,r7
      00678A 24 22            [12] 3566 	add	a,#0x22
      00678C FD               [12] 3567 	mov	r5,a
      00678D 8E 82            [24] 3568 	mov	dpl,r6
      00678F 8D 83            [24] 3569 	mov	dph,r5
      006791 E0               [24] 3570 	movx	a,@dptr
      006792 FE               [12] 3571 	mov	r6,a
      006793 53 06 03         [24] 3572 	anl	ar6,#0x03
      006796 BE 02 25         [24] 3573 	cjne	r6,#0x02,00102$
                                   3574 ;	tmk_core/protocol/ch555/usb_ak820.c:538: sent = ak820_usb_send(endpoint, report, length);
      006799 90 07 CD         [24] 3575 	mov	dptr,#_ak820_usb_try_send_PARM_2
      00679C E0               [24] 3576 	movx	a,@dptr
      00679D FD               [12] 3577 	mov	r5,a
      00679E A3               [24] 3578 	inc	dptr
      00679F E0               [24] 3579 	movx	a,@dptr
      0067A0 FE               [12] 3580 	mov	r6,a
      0067A1 90 07 CF         [24] 3581 	mov	dptr,#_ak820_usb_try_send_PARM_3
      0067A4 E0               [24] 3582 	movx	a,@dptr
      0067A5 FC               [12] 3583 	mov	r4,a
      0067A6 90 07 C8         [24] 3584 	mov	dptr,#_ak820_usb_send_PARM_2
      0067A9 ED               [12] 3585 	mov	a,r5
      0067AA F0               [24] 3586 	movx	@dptr,a
      0067AB EE               [12] 3587 	mov	a,r6
      0067AC A3               [24] 3588 	inc	dptr
      0067AD F0               [24] 3589 	movx	@dptr,a
      0067AE 90 07 CA         [24] 3590 	mov	dptr,#_ak820_usb_send_PARM_3
      0067B1 EC               [12] 3591 	mov	a,r4
      0067B2 F0               [24] 3592 	movx	@dptr,a
      0067B3 8F 82            [24] 3593 	mov	dpl, r7
      0067B5 12 65 BA         [24] 3594 	lcall	_ak820_usb_send
      0067B8 E5 82            [12] 3595 	mov	a, dpl
      0067BA 90 07 D1         [24] 3596 	mov	dptr,#_ak820_usb_try_send_sent_10000_444
      0067BD F0               [24] 3597 	movx	@dptr,a
      0067BE                       3598 00102$:
                                   3599 ;	tmk_core/protocol/ch555/usb_ak820.c:540: EA = saved_ea;
                                   3600 ;	assignBit
      0067BE A2 1C            [12] 3601 	mov	c,_ak820_usb_try_send_sloc0_1_0
      0067C0 92 AF            [24] 3602 	mov	_EA,c
                                   3603 ;	tmk_core/protocol/ch555/usb_ak820.c:541: return sent;
      0067C2 90 07 D1         [24] 3604 	mov	dptr,#_ak820_usb_try_send_sent_10000_444
      0067C5 E0               [24] 3605 	movx	a,@dptr
                                   3606 ;	tmk_core/protocol/ch555/usb_ak820.c:542: }
      0067C6 F5 82            [12] 3607 	mov	dpl,a
      0067C8 22               [24] 3608 	ret
                                   3609 ;------------------------------------------------------------
                                   3610 ;Allocation info for local variables in function 'raw_request_is_nonpersistent'
                                   3611 ;------------------------------------------------------------
                                   3612 ;	tmk_core/protocol/ch555/usb_ak820.c:547: static bool raw_request_is_nonpersistent(void) {
                                   3613 ;	-----------------------------------------
                                   3614 ;	 function raw_request_is_nonpersistent
                                   3615 ;	-----------------------------------------
      0067C9                       3616 _raw_request_is_nonpersistent:
                                   3617 ;	tmk_core/protocol/ch555/usb_ak820.c:548: switch (raw_buffer[0]) {
      0067C9 90 07 6B         [24] 3618 	mov	dptr,#_raw_buffer
      0067CC E0               [24] 3619 	movx	a,@dptr
      0067CD FF               [12] 3620 	mov	r7,a
      0067CE BF 01 02         [24] 3621 	cjne	r7,#0x01,00302$
      0067D1 80 35            [24] 3622 	sjmp	00108$
      0067D3                       3623 00302$:
      0067D3 BF 02 02         [24] 3624 	cjne	r7,#0x02,00303$
      0067D6 80 34            [24] 3625 	sjmp	00109$
      0067D8                       3626 00303$:
      0067D8 BF 04 02         [24] 3627 	cjne	r7,#0x04,00304$
      0067DB 80 2B            [24] 3628 	sjmp	00108$
      0067DD                       3629 00304$:
      0067DD BF 08 02         [24] 3630 	cjne	r7,#0x08,00305$
      0067E0 80 47            [24] 3631 	sjmp	00116$
      0067E2                       3632 00305$:
      0067E2 BF 0B 02         [24] 3633 	cjne	r7,#0x0b,00306$
      0067E5 80 21            [24] 3634 	sjmp	00108$
      0067E7                       3635 00306$:
      0067E7 BF 0C 02         [24] 3636 	cjne	r7,#0x0c,00307$
      0067EA 80 1C            [24] 3637 	sjmp	00108$
      0067EC                       3638 00307$:
      0067EC BF 0D 02         [24] 3639 	cjne	r7,#0x0d,00308$
      0067EF 80 17            [24] 3640 	sjmp	00108$
      0067F1                       3641 00308$:
      0067F1 BF 0E 02         [24] 3642 	cjne	r7,#0x0e,00309$
      0067F4 80 12            [24] 3643 	sjmp	00108$
      0067F6                       3644 00309$:
      0067F6 BF 11 02         [24] 3645 	cjne	r7,#0x11,00310$
      0067F9 80 0D            [24] 3646 	sjmp	00108$
      0067FB                       3647 00310$:
      0067FB BF 12 02         [24] 3648 	cjne	r7,#0x12,00311$
      0067FE 80 08            [24] 3649 	sjmp	00108$
      006800                       3650 00311$:
      006800 BF FE 02         [24] 3651 	cjne	r7,#0xfe,00312$
      006803 80 46            [24] 3652 	sjmp	00124$
      006805                       3653 00312$:
      006805 02 68 A0         [24] 3654 	ljmp	00144$
                                   3655 ;	tmk_core/protocol/ch555/usb_ak820.c:556: case id_bootloader_jump:
      006808                       3656 00108$:
                                   3657 ;	tmk_core/protocol/ch555/usb_ak820.c:557: return true;
      006808 75 82 01         [24] 3658 	mov	dpl, #0x01
      00680B 22               [24] 3659 	ret
                                   3660 ;	tmk_core/protocol/ch555/usb_ak820.c:558: case id_get_keyboard_value:
      00680C                       3661 00109$:
                                   3662 ;	tmk_core/protocol/ch555/usb_ak820.c:559: switch (raw_buffer[1]) {
      00680C 12 6A D2         [24] 3663 	lcall	_ak820_outline_0160
      00680F BF 01 02         [24] 3664 	cjne	r7,#0x01,00313$
      006812 80 0D            [24] 3665 	sjmp	00113$
      006814                       3666 00313$:
      006814 BF 02 02         [24] 3667 	cjne	r7,#0x02,00314$
      006817 80 08            [24] 3668 	sjmp	00113$
      006819                       3669 00314$:
      006819 BF 03 02         [24] 3670 	cjne	r7,#0x03,00315$
      00681C 80 03            [24] 3671 	sjmp	00113$
      00681E                       3672 00315$:
      00681E BF 04 04         [24] 3673 	cjne	r7,#0x04,00114$
                                   3674 ;	tmk_core/protocol/ch555/usb_ak820.c:563: case id_firmware_version:
      006821                       3675 00113$:
                                   3676 ;	tmk_core/protocol/ch555/usb_ak820.c:564: return true;
      006821 75 82 01         [24] 3677 	mov	dpl, #0x01
      006824 22               [24] 3678 	ret
                                   3679 ;	tmk_core/protocol/ch555/usb_ak820.c:565: default: return false;
      006825                       3680 00114$:
      006825 75 82 00         [24] 3681 	mov	dpl, #0x00
      006828 22               [24] 3682 	ret
                                   3683 ;	tmk_core/protocol/ch555/usb_ak820.c:567: case id_lighting_get_value:
      006829                       3684 00116$:
                                   3685 ;	tmk_core/protocol/ch555/usb_ak820.c:568: switch (raw_buffer[1]) {
      006829 12 6A D2         [24] 3686 	lcall	_ak820_outline_0160
      00682C BF 40 02         [24] 3687 	cjne	r7,#0x40,00318$
      00682F 80 12            [24] 3688 	sjmp	00121$
      006831                       3689 00318$:
      006831 BF 41 02         [24] 3690 	cjne	r7,#0x41,00319$
      006834 80 0D            [24] 3691 	sjmp	00121$
      006836                       3692 00319$:
      006836 BF 42 02         [24] 3693 	cjne	r7,#0x42,00320$
      006839 80 08            [24] 3694 	sjmp	00121$
      00683B                       3695 00320$:
      00683B BF 43 02         [24] 3696 	cjne	r7,#0x43,00321$
      00683E 80 03            [24] 3697 	sjmp	00121$
      006840                       3698 00321$:
      006840 BF 44 04         [24] 3699 	cjne	r7,#0x44,00122$
                                   3700 ;	tmk_core/protocol/ch555/usb_ak820.c:573: case vialrgb_get_led_info:
      006843                       3701 00121$:
                                   3702 ;	tmk_core/protocol/ch555/usb_ak820.c:574: return true;
      006843 75 82 01         [24] 3703 	mov	dpl, #0x01
                                   3704 ;	tmk_core/protocol/ch555/usb_ak820.c:575: default: return false;
      006846 22               [24] 3705 	ret
      006847                       3706 00122$:
      006847 75 82 00         [24] 3707 	mov	dpl, #0x00
                                   3708 ;	tmk_core/protocol/ch555/usb_ak820.c:577: case id_vial_prefix:
      00684A 22               [24] 3709 	ret
      00684B                       3710 00124$:
                                   3711 ;	tmk_core/protocol/ch555/usb_ak820.c:578: switch (raw_buffer[1]) {
      00684B 12 6A D2         [24] 3712 	lcall	_ak820_outline_0160
      00684E 24 F2            [12] 3713 	add	a,#0xff - 0x0d
      006850 40 4A            [24] 3714 	jc	00142$
                                   3715 ;	free result
      006852 EF               [12] 3716 	mov	a,r7
      006853 24 0A            [12] 3717 	add	a,#(00325$-3-.)
      006855 83               [24] 3718 	movc	a,@a+pc
      006856 F5 82            [12] 3719 	mov	dpl,a
      006858 EF               [12] 3720 	mov	a,r7
      006859 24 12            [12] 3721 	add	a,#(00326$-3-.)
      00685B 83               [24] 3722 	movc	a,@a+pc
      00685C F5 83            [12] 3723 	mov	dph,a
      00685E E4               [12] 3724 	clr	a
      00685F 73               [24] 3725 	jmp	@a+dptr
      006860                       3726 00325$:
      006860 7C                    3727 	.db	00134$
      006861 7C                    3728 	.db	00134$
      006862 7C                    3729 	.db	00134$
      006863 7C                    3730 	.db	00134$
      006864 9C                    3731 	.db	00142$
      006865 7C                    3732 	.db	00134$
      006866 7C                    3733 	.db	00134$
      006867 7C                    3734 	.db	00134$
      006868 7C                    3735 	.db	00134$
      006869 7C                    3736 	.db	00134$
      00686A 7C                    3737 	.db	00134$
      00686B 9C                    3738 	.db	00142$
      00686C 9C                    3739 	.db	00142$
      00686D 80                    3740 	.db	00135$
      00686E                       3741 00326$:
      00686E 68                    3742 	.db	00134$>>8
      00686F 68                    3743 	.db	00134$>>8
      006870 68                    3744 	.db	00134$>>8
      006871 68                    3745 	.db	00134$>>8
      006872 68                    3746 	.db	00142$>>8
      006873 68                    3747 	.db	00134$>>8
      006874 68                    3748 	.db	00134$>>8
      006875 68                    3749 	.db	00134$>>8
      006876 68                    3750 	.db	00134$>>8
      006877 68                    3751 	.db	00134$>>8
      006878 68                    3752 	.db	00134$>>8
      006879 68                    3753 	.db	00142$>>8
      00687A 68                    3754 	.db	00142$>>8
      00687B 68                    3755 	.db	00135$>>8
                                   3756 ;	tmk_core/protocol/ch555/usb_ak820.c:588: case vial_qmk_settings_get:
      00687C                       3757 00134$:
                                   3758 ;	tmk_core/protocol/ch555/usb_ak820.c:589: return true;
      00687C 75 82 01         [24] 3759 	mov	dpl, #0x01
                                   3760 ;	tmk_core/protocol/ch555/usb_ak820.c:590: case vial_dynamic_entry_op:
      00687F 22               [24] 3761 	ret
      006880                       3762 00135$:
                                   3763 ;	tmk_core/protocol/ch555/usb_ak820.c:591: switch (raw_buffer[2]) {
      006880 90 07 6D         [24] 3764 	mov	dptr,#(_raw_buffer + 0x0002)
      006883 E0               [24] 3765 	movx	a,@dptr
      006884 FF               [12] 3766 	mov	r7,a
      006885 60 0D            [24] 3767 	jz	00139$
      006887 BF 01 02         [24] 3768 	cjne	r7,#0x01,00328$
      00688A 80 08            [24] 3769 	sjmp	00139$
      00688C                       3770 00328$:
      00688C BF 03 02         [24] 3771 	cjne	r7,#0x03,00329$
      00688F 80 03            [24] 3772 	sjmp	00139$
      006891                       3773 00329$:
      006891 BF 05 04         [24] 3774 	cjne	r7,#0x05,00140$
                                   3775 ;	tmk_core/protocol/ch555/usb_ak820.c:595: case dynamic_vial_key_override_get:
      006894                       3776 00139$:
                                   3777 ;	tmk_core/protocol/ch555/usb_ak820.c:596: return true;
      006894 75 82 01         [24] 3778 	mov	dpl, #0x01
                                   3779 ;	tmk_core/protocol/ch555/usb_ak820.c:597: default: return false;
      006897 22               [24] 3780 	ret
      006898                       3781 00140$:
      006898 75 82 00         [24] 3782 	mov	dpl, #0x00
                                   3783 ;	tmk_core/protocol/ch555/usb_ak820.c:599: default: return false;
      00689B 22               [24] 3784 	ret
      00689C                       3785 00142$:
      00689C 75 82 00         [24] 3786 	mov	dpl, #0x00
                                   3787 ;	tmk_core/protocol/ch555/usb_ak820.c:601: default: return false;
      00689F 22               [24] 3788 	ret
      0068A0                       3789 00144$:
      0068A0 75 82 00         [24] 3790 	mov	dpl, #0x00
                                   3791 ;	tmk_core/protocol/ch555/usb_ak820.c:602: }
                                   3792 ;	tmk_core/protocol/ch555/usb_ak820.c:603: }
      0068A3 22               [24] 3793 	ret
                                   3794 ;------------------------------------------------------------
                                   3795 ;Allocation info for local variables in function 'ak820_usb_raw_send'
                                   3796 ;------------------------------------------------------------
                                   3797 ;length        Allocated with name '_ak820_usb_raw_send_PARM_2'
                                   3798 ;report        Allocated with name '_ak820_usb_raw_send_report_10000_459'
                                   3799 ;------------------------------------------------------------
                                   3800 ;	tmk_core/protocol/ch555/usb_ak820.c:605: void ak820_usb_raw_send(const uint8_t *report, uint8_t length) {
                                   3801 ;	-----------------------------------------
                                   3802 ;	 function ak820_usb_raw_send
                                   3803 ;	-----------------------------------------
      0068A4                       3804 _ak820_usb_raw_send:
      0068A4 12 43 0E         [24] 3805 	lcall	_ak820_outline_0035
      0068A7 90 07 D3         [24] 3806 	mov	dptr,#_ak820_usb_raw_send_report_10000_459
      0068AA 12 38 20         [24] 3807 	lcall	_ak820_outline_0015
                                   3808 ;	tmk_core/protocol/ch555/usb_ak820.c:606: if (length != RAW_EPSIZE) return;
      0068AD 90 07 D2         [24] 3809 	mov	dptr,#_ak820_usb_raw_send_PARM_2
      0068B0 E0               [24] 3810 	movx	a,@dptr
      0068B1 FF               [12] 3811 	mov	r7,a
      0068B2 BF 20 2B         [24] 3812 	cjne	r7,#0x20,00106$
                                   3813 ;	tmk_core/protocol/ch555/usb_ak820.c:607: ak820_nvm_flush();
      0068B5 C0 07            [24] 3814 	push	ar7
      0068B7 12 3E 24         [24] 3815 	lcall	_ak820_nvm_flush
      0068BA D0 07            [24] 3816 	pop	ar7
                                   3817 ;	tmk_core/protocol/ch555/usb_ak820.c:608: if (raw_reply_without_nvm || ak820_nvm_ok()) ak820_usb_send(RAW_IN_EPNUM, (const uint8_t __xdata *)report, length);
      0068BC 90 07 8B         [24] 3818 	mov	dptr,#_raw_reply_without_nvm
      0068BF E0               [24] 3819 	movx	a,@dptr
      0068C0 70 07            [24] 3820 	jnz	00103$
      0068C2 12 3E 15         [24] 3821 	lcall	_ak820_nvm_ok
      0068C5 E5 82            [12] 3822 	mov	a, dpl
      0068C7 60 17            [24] 3823 	jz	00106$
      0068C9                       3824 00103$:
      0068C9 90 07 D3         [24] 3825 	mov	dptr,#_ak820_usb_raw_send_report_10000_459
      0068CC 12 38 71         [24] 3826 	lcall	_ak820_outline_0093
      0068CF 90 07 C8         [24] 3827 	mov	dptr,#_ak820_usb_send_PARM_2
      0068D2 12 43 77         [24] 3828 	lcall	_ak820_outline_0158
      0068D5 90 07 CA         [24] 3829 	mov	dptr,#_ak820_usb_send_PARM_3
      0068D8 EF               [12] 3830 	mov	a,r7
      0068D9 F0               [24] 3831 	movx	@dptr,a
      0068DA 75 82 03         [24] 3832 	mov	dpl, #0x03
                                   3833 ;	tmk_core/protocol/ch555/usb_ak820.c:609: }
      0068DD 02 65 BA         [24] 3834 	ljmp	_ak820_usb_send
      0068E0                       3835 00106$:
      0068E0 22               [24] 3836 	ret
                                   3837 ;------------------------------------------------------------
                                   3838 ;Allocation info for local variables in function 'ak820_usb_raw_task'
                                   3839 ;------------------------------------------------------------
                                   3840 ;sloc0         Allocated with name '_ak820_usb_raw_task_sloc0_1_0'
                                   3841 ;i             Allocated with name '_ak820_usb_raw_task_i_10000_464'
                                   3842 ;length        Allocated with name '_ak820_usb_raw_task_length_10000_464'
                                   3843 ;address       Allocated with name '_ak820_usb_raw_task_address_10000_464'
                                   3844 ;saved_ea      Allocated with name '_ak820_usb_raw_task_saved_ea_10000_464'
                                   3845 ;------------------------------------------------------------
                                   3846 ;	tmk_core/protocol/ch555/usb_ak820.c:611: void ak820_usb_raw_task(void) {
                                   3847 ;	-----------------------------------------
                                   3848 ;	 function ak820_usb_raw_task
                                   3849 ;	-----------------------------------------
      0068E1                       3850 _ak820_usb_raw_task:
                                   3851 ;	tmk_core/protocol/ch555/usb_ak820.c:615: uint8_t saved_ea = EA;
      0068E1 A2 AF            [12] 3852 	mov	c,_EA
      0068E3 E4               [12] 3853 	clr	a
      0068E4 33               [12] 3854 	rlc	a
      0068E5 FF               [12] 3855 	mov	r7,a
                                   3856 ;	tmk_core/protocol/ch555/usb_ak820.c:616: EA = 0;
                                   3857 ;	assignBit
      0068E6 C2 AF            [12] 3858 	clr	_EA
                                   3859 ;	tmk_core/protocol/ch555/usb_ak820.c:617: if (!USB_EnumStatus || raw_state != RAW_READY) { EA = saved_ea; return; }
      0068E8 90 07 63         [24] 3860 	mov	dptr,#_USB_EnumStatus
      0068EB E0               [24] 3861 	movx	a,@dptr
      0068EC 60 0A            [24] 3862 	jz	00101$
      0068EE 90 07 6A         [24] 3863 	mov	dptr,#_raw_state
      0068F1 E0               [24] 3864 	movx	a,@dptr
      0068F2 FE               [12] 3865 	mov	r6,a
      0068F3 BE 02 02         [24] 3866 	cjne	r6,#0x02,00270$
      0068F6 80 06            [24] 3867 	sjmp	00102$
      0068F8                       3868 00270$:
      0068F8                       3869 00101$:
                                   3870 ;	assignBit
      0068F8 EF               [12] 3871 	mov	a,r7
      0068F9 24 FF            [12] 3872 	add	a,#0xff
      0068FB 92 AF            [24] 3873 	mov	_EA,c
      0068FD 22               [24] 3874 	ret
      0068FE                       3875 00102$:
                                   3876 ;	tmk_core/protocol/ch555/usb_ak820.c:618: raw_state = RAW_WORK;
      0068FE 90 07 6A         [24] 3877 	mov	dptr,#_raw_state
      006901 74 03            [12] 3878 	mov	a,#0x03
      006903 F0               [24] 3879 	movx	@dptr,a
                                   3880 ;	tmk_core/protocol/ch555/usb_ak820.c:619: EA = saved_ea;
                                   3881 ;	assignBit
      006904 EF               [12] 3882 	mov	a,r7
      006905 24 FF            [12] 3883 	add	a,#0xff
      006907 92 AF            [24] 3884 	mov	_EA,c
                                   3885 ;	tmk_core/protocol/ch555/usb_ak820.c:620: if (raw_buffer[0] == 0xfd && raw_buffer[1] == 0) {
      006909 90 07 6B         [24] 3886 	mov	dptr,#_raw_buffer
      00690C E0               [24] 3887 	movx	a,@dptr
      00690D FF               [12] 3888 	mov	r7,a
      00690E E4               [12] 3889 	clr	a
      00690F BF FD 01         [24] 3890 	cjne	r7,#0xfd,00271$
      006912 04               [12] 3891 	inc	a
      006913                       3892 00271$:
      006913 FF               [12] 3893 	mov	r7,a
      006914 70 03            [24] 3894 	jnz	00273$
      006916 02 69 B6         [24] 3895 	ljmp	00118$
      006919                       3896 00273$:
      006919 90 07 6C         [24] 3897 	mov	dptr,#(_raw_buffer + 0x0001)
      00691C E0               [24] 3898 	movx	a,@dptr
      00691D 60 03            [24] 3899 	jz	00274$
      00691F 02 69 B6         [24] 3900 	ljmp	00118$
      006922                       3901 00274$:
                                   3902 ;	tmk_core/protocol/ch555/usb_ak820.c:623: address = ((uint16_t)raw_buffer[2] << 8) | raw_buffer[3];
      006922 90 07 6D         [24] 3903 	mov	dptr,#(_raw_buffer + 0x0002)
      006925 E0               [24] 3904 	movx	a,@dptr
      006926 FD               [12] 3905 	mov	r5,a
      006927 7E 00            [12] 3906 	mov	r6,#0x00
      006929 90 07 6E         [24] 3907 	mov	dptr,#(_raw_buffer + 0x0003)
      00692C E0               [24] 3908 	movx	a,@dptr
      00692D 7B 00            [12] 3909 	mov	r3,#0x00
      00692F 42 06            [12] 3910 	orl	ar6,a
      006931 EB               [12] 3911 	mov	a,r3
      006932 42 05            [12] 3912 	orl	ar5,a
                                   3913 ;	tmk_core/protocol/ch555/usb_ak820.c:624: length = raw_buffer[4];
      006934 90 07 6F         [24] 3914 	mov	dptr,#(_raw_buffer + 0x0004)
      006937 E0               [24] 3915 	movx	a,@dptr
      006938 FC               [12] 3916 	mov	r4,a
                                   3917 ;	tmk_core/protocol/ch555/usb_ak820.c:625: for (i = 5; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
      006939 7B 05            [12] 3918 	mov	r3,#0x05
      00693B                       3919 00128$:
      00693B EB               [12] 3920 	mov	a,r3
      00693C 12 6A C0         [24] 3921 	lcall	_ak820_outline_0102
      00693F 0B               [12] 3922 	inc	r3
      006940 BB 20 00         [24] 3923 	cjne	r3,#0x20,00275$
      006943                       3924 00275$:
      006943 40 F6            [24] 3925 	jc	00128$
                                   3926 ;	tmk_core/protocol/ch555/usb_ak820.c:626: if (length > RAW_EPSIZE - 5 || (length && address > 0xffffu - (length - 1))) {
      006945 EC               [12] 3927 	mov	a,r4
      006946 24 E4            [12] 3928 	add	a,#0xff - 0x1b
      006948 40 1C            [24] 3929 	jc	00106$
                                   3930 ;	free result
      00694A EC               [12] 3931 	mov	a,r4
      00694B 60 26            [24] 3932 	jz	00165$
      00694D 8C 03            [24] 3933 	mov	ar3,r4
      00694F 1B               [12] 3934 	dec	r3
      006950 7A 00            [12] 3935 	mov	r2,#0x00
      006952 74 FF            [12] 3936 	mov	a,#0xff
      006954 C3               [12] 3937 	clr	c
      006955 9B               [12] 3938 	subb	a,r3
      006956 FB               [12] 3939 	mov	r3,a
      006957 74 FF            [12] 3940 	mov	a,#0xff
      006959 9A               [12] 3941 	subb	a,r2
      00695A FA               [12] 3942 	mov	r2,a
      00695B 8E 00            [24] 3943 	mov	ar0,r6
      00695D 8D 01            [24] 3944 	mov	ar1,r5
      00695F C3               [12] 3945 	clr	c
      006960 EB               [12] 3946 	mov	a,r3
      006961 98               [12] 3947 	subb	a,r0
      006962 EA               [12] 3948 	mov	a,r2
      006963 99               [12] 3949 	subb	a,r1
      006964 50 0D            [24] 3950 	jnc	00165$
                                   3951 ;	free result
      006966                       3952 00106$:
                                   3953 ;	tmk_core/protocol/ch555/usb_ak820.c:627: raw_buffer[1] = 0xff;
      006966 90 07 6C         [24] 3954 	mov	dptr,#(_raw_buffer + 0x0001)
      006969 74 FF            [12] 3955 	mov	a,#0xff
      00696B F0               [24] 3956 	movx	@dptr,a
                                   3957 ;	tmk_core/protocol/ch555/usb_ak820.c:628: raw_buffer[4] = 0;
      00696C 90 07 6F         [24] 3958 	mov	dptr,#(_raw_buffer + 0x0004)
      00696F E4               [12] 3959 	clr	a
      006970 F0               [24] 3960 	movx	@dptr,a
                                   3961 ;	tmk_core/protocol/ch555/usb_ak820.c:630: for (i = 0; i < length; ++i) raw_buffer[5 + i] = READ_CODE(address + i);
      006971 80 3A            [24] 3962 	sjmp	00108$
      006973                       3963 00165$:
      006973 7B 00            [12] 3964 	mov	r3,#0x00
      006975                       3965 00131$:
      006975 C3               [12] 3966 	clr	c
      006976 EB               [12] 3967 	mov	a,r3
      006977 9C               [12] 3968 	subb	a,r4
      006978 50 33            [24] 3969 	jnc	00108$
      00697A C0 04            [24] 3970 	push	ar4
      00697C 8B 02            [24] 3971 	mov	ar2,r3
      00697E 74 05            [12] 3972 	mov	a,#0x05
      006980 2A               [12] 3973 	add	a, r2
      006981 F9               [12] 3974 	mov	r1,a
      006982 33               [12] 3975 	rlc	a
      006983 95 E0            [12] 3976 	subb	a,acc
      006985 FA               [12] 3977 	mov	r2,a
      006986 E9               [12] 3978 	mov	a,r1
      006987 24 6B            [12] 3979 	add	a, #_raw_buffer
      006989 F9               [12] 3980 	mov	r1,a
      00698A EA               [12] 3981 	mov	a,r2
      00698B 34 07            [12] 3982 	addc	a, #(_raw_buffer >> 8)
      00698D FA               [12] 3983 	mov	r2,a
      00698E 8B 1E            [24] 3984 	mov	_ak820_usb_raw_task_sloc0_1_0,r3
      006990 75 1F 00         [24] 3985 	mov	(_ak820_usb_raw_task_sloc0_1_0 + 1),#0x00
      006993 8E 00            [24] 3986 	mov	ar0,r6
      006995 8D 04            [24] 3987 	mov	ar4,r5
      006997 E5 1E            [12] 3988 	mov	a,_ak820_usb_raw_task_sloc0_1_0
      006999 28               [12] 3989 	add	a, r0
      00699A F8               [12] 3990 	mov	r0,a
      00699B E5 1F            [12] 3991 	mov	a,(_ak820_usb_raw_task_sloc0_1_0 + 1)
      00699D 3C               [12] 3992 	addc	a, r4
      00699E FC               [12] 3993 	mov	r4,a
      00699F 88 82            [24] 3994 	mov	dpl,r0
      0069A1 8C 83            [24] 3995 	mov	dph,r4
      0069A3 E4               [12] 3996 	clr	a
      0069A4 93               [24] 3997 	movc	a,@a+dptr
      0069A5 12 6A CC         [24] 3998 	lcall	_ak820_outline_0135
      0069A8 0B               [12] 3999 	inc	r3
      0069A9 D0 04            [24] 4000 	pop	ar4
      0069AB 80 C8            [24] 4001 	sjmp	00131$
      0069AD                       4002 00108$:
                                   4003 ;	tmk_core/protocol/ch555/usb_ak820.c:634: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
      0069AD 12 6A AC         [24] 4004 	lcall	_ak820_outline_0044
      0069B0 12 65 BA         [24] 4005 	lcall	_ak820_usb_send
      0069B3 02 6A 5C         [24] 4006 	ljmp	00119$
      0069B6                       4007 00118$:
                                   4008 ;	tmk_core/protocol/ch555/usb_ak820.c:635: } else if (raw_buffer[0] == 0xfd && raw_buffer[1] == 1) {
      0069B6 EF               [12] 4009 	mov	a,r7
      0069B7 70 03            [24] 4010 	jnz	00281$
      0069B9 02 6A 39         [24] 4011 	ljmp	00114$
      0069BC                       4012 00281$:
      0069BC 12 6A D2         [24] 4013 	lcall	_ak820_outline_0160
      0069BF BF 01 02         [24] 4014 	cjne	r7,#0x01,00282$
      0069C2 80 03            [24] 4015 	sjmp	00283$
      0069C4                       4016 00282$:
      0069C4 02 6A 39         [24] 4017 	ljmp	00114$
      0069C7                       4018 00283$:
                                   4019 ;	tmk_core/protocol/ch555/usb_ak820.c:638: for (i = 2; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
      0069C7 7F 02            [12] 4020 	mov	r7,#0x02
      0069C9                       4021 00133$:
      0069C9 EF               [12] 4022 	mov	a,r7
      0069CA 12 6A C0         [24] 4023 	lcall	_ak820_outline_0102
      0069CD 0F               [12] 4024 	inc	r7
      0069CE BF 20 00         [24] 4025 	cjne	r7,#0x20,00284$
      0069D1                       4026 00284$:
      0069D1 40 F6            [24] 4027 	jc	00133$
                                   4028 ;	tmk_core/protocol/ch555/usb_ak820.c:639: raw_buffer[2] = 1;
      0069D3 90 07 6D         [24] 4029 	mov	dptr,#(_raw_buffer + 0x0002)
      0069D6 74 01            [12] 4030 	mov	a,#0x01
      0069D8 F0               [24] 4031 	movx	@dptr,a
                                   4032 ;	tmk_core/protocol/ch555/usb_ak820.c:640: raw_buffer[3] = 0xa8;
      0069D9 90 07 6E         [24] 4033 	mov	dptr,#(_raw_buffer + 0x0003)
      0069DC 74 A8            [12] 4034 	mov	a,#0xa8
      0069DE F0               [24] 4035 	movx	@dptr,a
                                   4036 ;	tmk_core/protocol/ch555/usb_ak820.c:641: ak820_nvm_diagnostic(&raw_buffer[4]);
      0069DF 90 07 6F         [24] 4037 	mov	dptr,#(_raw_buffer + 0x0004)
      0069E2 12 3B 92         [24] 4038 	lcall	_ak820_nvm_diagnostic
                                   4039 ;	tmk_core/protocol/ch555/usb_ak820.c:642: for (i = 0; i < 6; ++i) raw_buffer[11 + i] = ak820_flash_diagnostic[i];
      0069E5 7F 00            [12] 4040 	mov	r7,#0x00
      0069E7                       4041 00135$:
      0069E7 8F 06            [24] 4042 	mov	ar6,r7
      0069E9 74 0B            [12] 4043 	mov	a,#0x0b
      0069EB 2E               [12] 4044 	add	a, r6
      0069EC 24 6B            [12] 4045 	add	a,#_raw_buffer
      0069EE FE               [12] 4046 	mov	r6,a
      0069EF E4               [12] 4047 	clr	a
      0069F0 34 07            [12] 4048 	addc	a, #(_raw_buffer >> 8)
      0069F2 FD               [12] 4049 	mov	r5,a
      0069F3 EF               [12] 4050 	mov	a,r7
      0069F4 24 64            [12] 4051 	add	a, #_ak820_flash_diagnostic
      0069F6 F5 82            [12] 4052 	mov	dpl,a
      0069F8 E4               [12] 4053 	clr	a
      0069F9 34 04            [12] 4054 	addc	a, #(_ak820_flash_diagnostic >> 8)
      0069FB F5 83            [12] 4055 	mov	dph,a
      0069FD E0               [24] 4056 	movx	a,@dptr
      0069FE 8E 82            [24] 4057 	mov	dpl,r6
      006A00 8D 83            [24] 4058 	mov	dph,r5
      006A02 F0               [24] 4059 	movx	@dptr,a
      006A03 0F               [12] 4060 	inc	r7
      006A04 BF 06 00         [24] 4061 	cjne	r7,#0x06,00286$
      006A07                       4062 00286$:
      006A07 40 DE            [24] 4063 	jc	00135$
                                   4064 ;	tmk_core/protocol/ch555/usb_ak820.c:643: raw_buffer[17] = vial_unlocked;
      006A09 90 0E 1A         [24] 4065 	mov	dptr,#_vial_unlocked
      006A0C E0               [24] 4066 	movx	a,@dptr
      006A0D 90 07 7C         [24] 4067 	mov	dptr,#(_raw_buffer + 0x0011)
      006A10 F0               [24] 4068 	movx	@dptr,a
                                   4069 ;	tmk_core/protocol/ch555/usb_ak820.c:644: raw_buffer[18] = vial_unlock_in_progress;
      006A11 90 0E 1B         [24] 4070 	mov	dptr,#_vial_unlock_in_progress
      006A14 E0               [24] 4071 	movx	a,@dptr
      006A15 90 07 7D         [24] 4072 	mov	dptr,#(_raw_buffer + 0x0012)
      006A18 F0               [24] 4073 	movx	@dptr,a
                                   4074 ;	tmk_core/protocol/ch555/usb_ak820.c:645: raw_buffer[19] = USB_EnumStatus;
      006A19 90 07 63         [24] 4075 	mov	dptr,#_USB_EnumStatus
      006A1C E0               [24] 4076 	movx	a,@dptr
      006A1D 90 07 7E         [24] 4077 	mov	dptr,#(_raw_buffer + 0x0013)
      006A20 F0               [24] 4078 	movx	@dptr,a
                                   4079 ;	tmk_core/protocol/ch555/usb_ak820.c:646: raw_buffer[20] = USB_SleepStatus;
      006A21 90 07 64         [24] 4080 	mov	dptr,#_USB_SleepStatus
      006A24 E0               [24] 4081 	movx	a,@dptr
      006A25 90 07 7F         [24] 4082 	mov	dptr,#(_raw_buffer + 0x0014)
      006A28 F0               [24] 4083 	movx	@dptr,a
                                   4084 ;	tmk_core/protocol/ch555/usb_ak820.c:647: raw_buffer[21] = raw_state;
      006A29 90 07 6A         [24] 4085 	mov	dptr,#_raw_state
      006A2C E0               [24] 4086 	movx	a,@dptr
      006A2D 90 07 80         [24] 4087 	mov	dptr,#(_raw_buffer + 0x0015)
      006A30 F0               [24] 4088 	movx	@dptr,a
                                   4089 ;	tmk_core/protocol/ch555/usb_ak820.c:648: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
      006A31 12 6A AC         [24] 4090 	lcall	_ak820_outline_0044
      006A34 12 65 BA         [24] 4091 	lcall	_ak820_usb_send
      006A37 80 23            [24] 4092 	sjmp	00119$
      006A39                       4093 00114$:
                                   4094 ;	tmk_core/protocol/ch555/usb_ak820.c:650: raw_reply_without_nvm = raw_request_is_nonpersistent();
      006A39 12 67 C9         [24] 4095 	lcall	_raw_request_is_nonpersistent
      006A3C E5 82            [12] 4096 	mov	a, dpl
      006A3E 90 07 8B         [24] 4097 	mov	dptr,#_raw_reply_without_nvm
      006A41 F0               [24] 4098 	movx	@dptr,a
                                   4099 ;	tmk_core/protocol/ch555/usb_ak820.c:651: ak820_nvm_begin();
      006A42 12 3F 77         [24] 4100 	lcall	_ak820_nvm_begin
                                   4101 ;	tmk_core/protocol/ch555/usb_ak820.c:652: raw_hid_receive(raw_buffer, RAW_EPSIZE);
      006A45 90 0C 4D         [24] 4102 	mov	dptr,#_raw_hid_receive_PARM_2
      006A48 74 20            [12] 4103 	mov	a,#0x20
      006A4A F0               [24] 4104 	movx	@dptr,a
      006A4B 90 07 6B         [24] 4105 	mov	dptr,#_raw_buffer
      006A4E 75 F0 00         [24] 4106 	mov	b, #0x00
      006A51 12 A4 3B         [24] 4107 	lcall	_raw_hid_receive
                                   4108 ;	tmk_core/protocol/ch555/usb_ak820.c:653: ak820_nvm_end();
      006A54 12 3F 8C         [24] 4109 	lcall	_ak820_nvm_end
                                   4110 ;	tmk_core/protocol/ch555/usb_ak820.c:654: raw_reply_without_nvm = false;
      006A57 90 07 8B         [24] 4111 	mov	dptr,#_raw_reply_without_nvm
      006A5A E4               [12] 4112 	clr	a
      006A5B F0               [24] 4113 	movx	@dptr,a
      006A5C                       4114 00119$:
                                   4115 ;	tmk_core/protocol/ch555/usb_ak820.c:656: saved_ea = EA;
                                   4116 ;	assignBit
      006A5C A2 AF            [12] 4117 	mov	c,_EA
      006A5E 92 1D            [24] 4118 	mov	_ak820_usb_raw_task_sloc1_1_0,c
                                   4119 ;	tmk_core/protocol/ch555/usb_ak820.c:657: EA = 0;
                                   4120 ;	assignBit
      006A60 C2 AF            [12] 4121 	clr	_EA
                                   4122 ;	tmk_core/protocol/ch555/usb_ak820.c:659: if (raw_state == RAW_TX_ACTIVE) raw_state = RAW_TX_WAIT;
      006A62 12 6A D8         [24] 4123 	lcall	_ak820_outline_0162
      006A65 BF 04 08         [24] 4124 	cjne	r7,#0x04,00126$
      006A68 90 07 6A         [24] 4125 	mov	dptr,#_raw_state
      006A6B 74 05            [12] 4126 	mov	a,#0x05
      006A6D F0               [24] 4127 	movx	@dptr,a
      006A6E 80 1B            [24] 4128 	sjmp	00127$
      006A70                       4129 00126$:
                                   4130 ;	tmk_core/protocol/ch555/usb_ak820.c:660: else if (raw_state == RAW_WORK || raw_state == RAW_DRAINED || raw_state == RAW_CANCELLED) raw_state = RAW_IDLE;
      006A70 12 6A D8         [24] 4131 	lcall	_ak820_outline_0162
      006A73 BF 03 02         [24] 4132 	cjne	r7,#0x03,00290$
      006A76 80 0E            [24] 4133 	sjmp	00121$
      006A78                       4134 00290$:
      006A78 12 6A D8         [24] 4135 	lcall	_ak820_outline_0162
      006A7B BF 06 02         [24] 4136 	cjne	r7,#0x06,00291$
      006A7E 80 06            [24] 4137 	sjmp	00121$
      006A80                       4138 00291$:
      006A80 12 6A D8         [24] 4139 	lcall	_ak820_outline_0162
      006A83 BF 07 05         [24] 4140 	cjne	r7,#0x07,00127$
      006A86                       4141 00121$:
      006A86 90 07 6A         [24] 4142 	mov	dptr,#_raw_state
      006A89 E4               [12] 4143 	clr	a
      006A8A F0               [24] 4144 	movx	@dptr,a
      006A8B                       4145 00127$:
                                   4146 ;	tmk_core/protocol/ch555/usb_ak820.c:661: EA = saved_ea;
                                   4147 ;	assignBit
      006A8B A2 1D            [12] 4148 	mov	c,_ak820_usb_raw_task_sloc1_1_0
      006A8D 92 AF            [24] 4149 	mov	_EA,c
                                   4150 ;	tmk_core/protocol/ch555/usb_ak820.c:662: }
      006A8F 22               [24] 4151 	ret
                                   4152 ;------------------------------------------------------------
                                   4153 ;Allocation info for local variables in function 'ak820_usb_take_keyboard_reset'
                                   4154 ;------------------------------------------------------------
                                   4155 ;result        Allocated with name '_ak820_usb_take_keyboard_reset_result_10000_482'
                                   4156 ;saved_ea      Allocated with name '_ak820_usb_take_keyboard_reset_saved_ea_10000_482'
                                   4157 ;------------------------------------------------------------
                                   4158 ;	tmk_core/protocol/ch555/usb_ak820.c:670: bool ak820_usb_take_keyboard_reset(void) {
                                   4159 ;	-----------------------------------------
                                   4160 ;	 function ak820_usb_take_keyboard_reset
                                   4161 ;	-----------------------------------------
      006A90                       4162 _ak820_usb_take_keyboard_reset:
                                   4163 ;	tmk_core/protocol/ch555/usb_ak820.c:672: uint8_t saved_ea = EA;
                                   4164 ;	assignBit
      006A90 A2 AF            [12] 4165 	mov	c,_EA
      006A92 92 1E            [24] 4166 	mov	_ak820_usb_take_keyboard_reset_sloc0_1_0,c
                                   4167 ;	tmk_core/protocol/ch555/usb_ak820.c:673: EA = 0;
                                   4168 ;	assignBit
      006A94 C2 AF            [12] 4169 	clr	_EA
                                   4170 ;	tmk_core/protocol/ch555/usb_ak820.c:674: result = keyboard_reset;
      006A96 90 07 8C         [24] 4171 	mov	dptr,#_keyboard_reset
      006A99 E0               [24] 4172 	movx	a,@dptr
      006A9A FF               [12] 4173 	mov	r7,a
                                   4174 ;	tmk_core/protocol/ch555/usb_ak820.c:675: keyboard_reset = 0;
      006A9B E4               [12] 4175 	clr	a
      006A9C F0               [24] 4176 	movx	@dptr,a
                                   4177 ;	tmk_core/protocol/ch555/usb_ak820.c:676: EA = saved_ea;
                                   4178 ;	assignBit
      006A9D A2 1E            [12] 4179 	mov	c,_ak820_usb_take_keyboard_reset_sloc0_1_0
      006A9F 92 AF            [24] 4180 	mov	_EA,c
                                   4181 ;	tmk_core/protocol/ch555/usb_ak820.c:677: return result != 0;
      006AA1 EF               [12] 4182 	mov	a,r7
      006AA2 B4 01 00         [24] 4183 	cjne	a,#0x01,00103$
      006AA5                       4184 00103$:
      006AA5 B3               [12] 4185 	cpl	c
      006AA6 92 1E            [24] 4186 	mov	_ak820_usb_take_keyboard_reset_sloc0_1_0,c
      006AA8 12 38 B1         [24] 4187 	lcall	_ak820_outline_0153
                                   4188 ;	tmk_core/protocol/ch555/usb_ak820.c:678: }
      006AAB 22               [24] 4189 	ret
                                   4190 	.area CSEG    (CODE)
                                   4191 	.area CONST   (CODE)
                                   4192 	.area CONST   (CODE)
      00B70D                       4193 _shared_offsets:
      00B70D 00                    4194 	.db #0x00	; 0
      00B70E 00                    4195 	.db #0x00	; 0
      00B70F 28                    4196 	.db #0x28	; 40
      00B710 28                    4197 	.db #0x28	; 40
      00B711 2B                    4198 	.db #0x2b	; 43
      00B712 00                    4199 	.db #0x00	; 0
      00B713 08                    4200 	.db #0x08	; 8
                                   4201 	.area CSEG    (CODE)
                                   4202 	.area CONST   (CODE)
      00B714                       4203 _shared_lengths:
      00B714 00                    4204 	.db #0x00	; 0
      00B715 00                    4205 	.db #0x00	; 0
      00B716 00                    4206 	.db #0x00	; 0
      00B717 03                    4207 	.db #0x03	; 3
      00B718 03                    4208 	.db #0x03	; 3
      00B719 00                    4209 	.db #0x00	; 0
      00B71A 20                    4210 	.db #0x20	; 32
                                   4211 	.area CSEG    (CODE)
                                   4212 	.area CONST   (CODE)
      00B71B                       4213 _interface_descriptors:
      00B71B B6 BC                 4214 	.byte _KeyboardReport, (_KeyboardReport >> 8)
      00B71D B6 BD                 4215 	.byte (_ConfigurationDescriptor + 18), ((_ConfigurationDescriptor + 18) >> 8)
      00B71F 69 BD                 4216 	.byte _RawReport, (_RawReport >> 8)
      00B721 CF BD                 4217 	.byte (_ConfigurationDescriptor + 43), ((_ConfigurationDescriptor + 43) >> 8)
      00B723 FB BC                 4218 	.byte _SharedReport, (_SharedReport >> 8)
      00B725 E8 BD                 4219 	.byte (_ConfigurationDescriptor + 68), ((_ConfigurationDescriptor + 68) >> 8)
                                   4220 	.area CSEG    (CODE)
                                   4221 	.area XINIT   (CODE)
                                   4222 	.area CABS    (ABS,CODE)
                                   4223 
                                   4224 ; Experimental exact instruction outlining.
                                   4225 	.globl _ak820_outline_0015
                                   4226 	.globl _ak820_outline_0035
                                   4227 	.globl _ak820_outline_0044
                                   4228 	.globl _ak820_outline_0093
                                   4229 	.globl _ak820_outline_0102
                                   4230 	.globl _ak820_outline_0135
                                   4231 	.globl _ak820_outline_0153
                                   4232 	.globl _ak820_outline_0158
                                   4233 	.globl _ak820_outline_0160
                                   4234 	.globl _ak820_outline_0162
                                   4235 
                                   4236 	.area CSEG (CODE)
                                   4237 ; function ak820_outline_0044
      006AAC                       4238 _ak820_outline_0044:
      006AAC 90 07 C8         [24] 4239 	mov	dptr,#_ak820_usb_send_PARM_2
      006AAF 74 6B            [12] 4240 	mov	a,#_raw_buffer
      006AB1 F0               [24] 4241 	movx	@dptr,a
      006AB2 74 07            [12] 4242 	mov	a,#(_raw_buffer>>8)
      006AB4 A3               [24] 4243 	inc	dptr
      006AB5 F0               [24] 4244 	movx	@dptr,a
      006AB6 90 07 CA         [24] 4245 	mov	dptr,#_ak820_usb_send_PARM_3
      006AB9 74 20            [12] 4246 	mov	a,#0x20
      006ABB F0               [24] 4247 	movx	@dptr,a
      006ABC 75 82 03         [24] 4248 	mov	dpl,#0x03
      006ABF 22               [24] 4249 	ret
                                   4250 
                                   4251 	.area CSEG (CODE)
                                   4252 ; function ak820_outline_0102
      006AC0                       4253 _ak820_outline_0102:
      006AC0 24 6B            [12] 4254 	add	a,#_raw_buffer
      006AC2 F5 82            [12] 4255 	mov	dpl,a
      006AC4 E4               [12] 4256 	clr	a
      006AC5 34 07            [12] 4257 	addc	a,#(_raw_buffer>>8)
      006AC7 F5 83            [12] 4258 	mov	dph,a
      006AC9 E4               [12] 4259 	clr	a
      006ACA F0               [24] 4260 	movx	@dptr,a
      006ACB 22               [24] 4261 	ret
                                   4262 
                                   4263 	.area CSEG (CODE)
                                   4264 ; function ak820_outline_0135
      006ACC                       4265 _ak820_outline_0135:
      006ACC 89 82            [24] 4266 	mov	dpl,r1
      006ACE 8A 83            [24] 4267 	mov	dph,r2
      006AD0 F0               [24] 4268 	movx	@dptr,a
      006AD1 22               [24] 4269 	ret
                                   4270 
                                   4271 	.area CSEG (CODE)
                                   4272 ; function ak820_outline_0160
      006AD2                       4273 _ak820_outline_0160:
      006AD2 90 07 6C         [24] 4274 	mov	dptr,#(_raw_buffer+0x0001)
      006AD5 E0               [24] 4275 	movx	a,@dptr
      006AD6 FF               [12] 4276 	mov	r7,a
      006AD7 22               [24] 4277 	ret
                                   4278 
                                   4279 	.area CSEG (CODE)
                                   4280 ; function ak820_outline_0162
      006AD8                       4281 _ak820_outline_0162:
      006AD8 90 07 6A         [24] 4282 	mov	dptr,#_raw_state
      006ADB E0               [24] 4283 	movx	a,@dptr
      006ADC FF               [12] 4284 	mov	r7,a
      006ADD 22               [24] 4285 	ret
