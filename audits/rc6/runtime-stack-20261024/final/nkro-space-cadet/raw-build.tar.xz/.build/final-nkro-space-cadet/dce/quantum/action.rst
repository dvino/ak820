                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_combo_cancel
                                     12 	.globl _ak820_combo_tick
                                     13 	.globl _ak820_tapping_cancel
                                     14 	.globl _ak820_tapping_process
                                     15 	.globl _ak820_tapping_before
                                     16 	.globl _pre_process_record_quantum
                                     17 	.globl _repeat_key_cancel
                                     18 	.globl _clear_owned_usages
                                     19 	.globl _owned_usage_key
                                     20 	.globl _clear_owned_keys
                                     21 	.globl _del_owned_key
                                     22 	.globl _add_owned_key
                                     23 	.globl _clear_owned_mods
                                     24 	.globl _del_owned_weak_mods
                                     25 	.globl _add_owned_weak_mods
                                     26 	.globl _del_owned_mods
                                     27 	.globl _add_owned_mods
                                     28 	.globl _clear_weak_mods
                                     29 	.globl _clear_mods
                                     30 	.globl _send_keyboard_report
                                     31 	.globl _layer_hold_clear
                                     32 	.globl _layer_hold_off
                                     33 	.globl _layer_hold_on
                                     34 	.globl _ak820_resolve_key
                                     35 	.globl _layer_xor
                                     36 	.globl _layer_and
                                     37 	.globl _layer_or
                                     38 	.globl _layer_off
                                     39 	.globl _layer_on
                                     40 	.globl _layer_move
                                     41 	.globl _layer_clear
                                     42 	.globl _layer_state_set
                                     43 	.globl _default_layer_xor
                                     44 	.globl _default_layer_and
                                     45 	.globl _default_layer_or
                                     46 	.globl _default_layer_set
                                     47 	.globl _post_process_record_quantum
                                     48 	.globl _process_record_quantum
                                     49 	.globl _action_for_keycode
                                     50 	.globl _mDelaymS
                                     51 	.globl _host_consumer_send
                                     52 	.globl _host_system_send
                                     53 	.globl _host_keyboard_leds
                                     54 	.globl _led_set
                                     55 	.globl _clear_keys_from_report
                                     56 	.globl ___memcpy
                                     57 	.globl _ADC_START
                                     58 	.globl _S0_R_FIFO
                                     59 	.globl _S0_T_FIFO
                                     60 	.globl _S0_FREE
                                     61 	.globl _S0_IF_BYTE
                                     62 	.globl _S0_IF_FIRST
                                     63 	.globl _S0_IF_OV
                                     64 	.globl _S0_FST_ACT
                                     65 	.globl _CP_RL2
                                     66 	.globl _C_T2
                                     67 	.globl _TR2
                                     68 	.globl _EXEN2
                                     69 	.globl _TCLK
                                     70 	.globl _RCLK
                                     71 	.globl _EXF2
                                     72 	.globl _CAP1F
                                     73 	.globl _TF2
                                     74 	.globl _RI
                                     75 	.globl _TI
                                     76 	.globl _RB8
                                     77 	.globl _TB8
                                     78 	.globl _REN
                                     79 	.globl _SM2
                                     80 	.globl _SM1
                                     81 	.globl _SM0
                                     82 	.globl _IT0
                                     83 	.globl _IE0
                                     84 	.globl _IT1
                                     85 	.globl _IE1
                                     86 	.globl _TR0
                                     87 	.globl _TF0
                                     88 	.globl _TR1
                                     89 	.globl _TF1
                                     90 	.globl _P4_0
                                     91 	.globl _P4_1
                                     92 	.globl _P4_2
                                     93 	.globl _P4_3
                                     94 	.globl _P4_4
                                     95 	.globl _P4_5
                                     96 	.globl _P4_6
                                     97 	.globl _RXD
                                     98 	.globl _TXD
                                     99 	.globl _INT0
                                    100 	.globl _INT1
                                    101 	.globl _T0
                                    102 	.globl _T1
                                    103 	.globl _MOSI1
                                    104 	.globl _MISO1
                                    105 	.globl _SCK1
                                    106 	.globl _P3_0
                                    107 	.globl _P3_1
                                    108 	.globl _P3_2
                                    109 	.globl _P3_3
                                    110 	.globl _P3_4
                                    111 	.globl _P3_5
                                    112 	.globl _P3_6
                                    113 	.globl _P3_7
                                    114 	.globl _CAP1_
                                    115 	.globl _T2_
                                    116 	.globl _CAP2_
                                    117 	.globl _T2EX_
                                    118 	.globl _RXD1
                                    119 	.globl _TXD1
                                    120 	.globl _P2_0
                                    121 	.globl _P2_1
                                    122 	.globl _P2_2
                                    123 	.globl _P2_3
                                    124 	.globl _P2_4
                                    125 	.globl _P2_5
                                    126 	.globl _P2_6
                                    127 	.globl _P2_7
                                    128 	.globl _AIN0
                                    129 	.globl _AIN1
                                    130 	.globl _AIN2
                                    131 	.globl _AIN3
                                    132 	.globl _AIN4
                                    133 	.globl _AIN5
                                    134 	.globl _AIN6
                                    135 	.globl _AIN7
                                    136 	.globl _CAP1
                                    137 	.globl _T2
                                    138 	.globl _CAP2
                                    139 	.globl _T2EX
                                    140 	.globl _INT0_
                                    141 	.globl _SCS
                                    142 	.globl _MOSI
                                    143 	.globl _MISO
                                    144 	.globl _SCK
                                    145 	.globl _RXD1_
                                    146 	.globl _TXD1_
                                    147 	.globl _P1_0
                                    148 	.globl _P1_1
                                    149 	.globl _P1_2
                                    150 	.globl _P1_3
                                    151 	.globl _P1_4
                                    152 	.globl _P1_5
                                    153 	.globl _P1_6
                                    154 	.globl _P1_7
                                    155 	.globl _AIN8
                                    156 	.globl _AIN9
                                    157 	.globl _AIN10
                                    158 	.globl _AIN11
                                    159 	.globl _AIN12
                                    160 	.globl _AIN13
                                    161 	.globl _RXD_
                                    162 	.globl _TXD_
                                    163 	.globl _SCL0
                                    164 	.globl _SDA0
                                    165 	.globl _P0_0
                                    166 	.globl _P0_1
                                    167 	.globl _P0_2
                                    168 	.globl _P0_3
                                    169 	.globl _P0_4
                                    170 	.globl _P0_5
                                    171 	.globl _P0_6
                                    172 	.globl _P0_7
                                    173 	.globl _IE_SPI0
                                    174 	.globl _IE_USB
                                    175 	.globl _IE_ADC
                                    176 	.globl _IE_UART1
                                    177 	.globl _IE_PWM_I2C
                                    178 	.globl _IE_GPIO
                                    179 	.globl _IE_WDOG
                                    180 	.globl _PX0
                                    181 	.globl _PT0
                                    182 	.globl _PX1
                                    183 	.globl _PT1
                                    184 	.globl _PS
                                    185 	.globl _PT2
                                    186 	.globl _PL_FLAG
                                    187 	.globl _PH_FLAG
                                    188 	.globl _EX0
                                    189 	.globl _ET0
                                    190 	.globl _EX1
                                    191 	.globl _ET1
                                    192 	.globl _ES
                                    193 	.globl _ET2
                                    194 	.globl _E_DIS
                                    195 	.globl _EA
                                    196 	.globl _P
                                    197 	.globl _F1
                                    198 	.globl _OV
                                    199 	.globl _RS0
                                    200 	.globl _RS1
                                    201 	.globl _F0
                                    202 	.globl _AC
                                    203 	.globl _CY
                                    204 	.globl _I2CS_INT_ST
                                    205 	.globl _I2CX_INT
                                    206 	.globl _LED_STATUS
                                    207 	.globl _LED_DMA_H
                                    208 	.globl _LED_DMA_L
                                    209 	.globl _LED_DMA
                                    210 	.globl _LED_PWM_OE
                                    211 	.globl _LED_COMMON
                                    212 	.globl _ADC_CHAN
                                    213 	.globl _ADC_DAT_H
                                    214 	.globl _ADC_DAT_L
                                    215 	.globl _ADC_DAT
                                    216 	.globl _ADC_CTRL
                                    217 	.globl _SPI1_CK_SE
                                    218 	.globl _SPI1_CTRL
                                    219 	.globl _SPI1_DATA
                                    220 	.globl _SPI1_STAT
                                    221 	.globl _SIF1
                                    222 	.globl _SBAUD1
                                    223 	.globl _SBUF1
                                    224 	.globl _SCON1
                                    225 	.globl _SPI0_SETUP
                                    226 	.globl _SPI0_CK_SE
                                    227 	.globl _SPI0_CTRL
                                    228 	.globl _SPI0_DATA
                                    229 	.globl _SPI0_STAT
                                    230 	.globl _T2CAP1H
                                    231 	.globl _T2CAP1L
                                    232 	.globl _T2CAP1
                                    233 	.globl _TH2
                                    234 	.globl _TL2
                                    235 	.globl _T2COUNT
                                    236 	.globl _RCAP2H
                                    237 	.globl _RCAP2L
                                    238 	.globl _RCAP2
                                    239 	.globl _T2MOD
                                    240 	.globl _T2CON
                                    241 	.globl _SBUF
                                    242 	.globl _SCON
                                    243 	.globl _TH1
                                    244 	.globl _TH0
                                    245 	.globl _TL1
                                    246 	.globl _TL0
                                    247 	.globl _TMOD
                                    248 	.globl _TCON
                                    249 	.globl _XBUS_AUX
                                    250 	.globl _P7
                                    251 	.globl _P6_DIR
                                    252 	.globl _P6_OUT_PU
                                    253 	.globl _P6_IN
                                    254 	.globl _P5_DIR
                                    255 	.globl _P5_OUT_PU
                                    256 	.globl _P5_IN
                                    257 	.globl _P4_LED_KEY
                                    258 	.globl _P4_DIR_PU
                                    259 	.globl _P4_MOD_OC
                                    260 	.globl _P4
                                    261 	.globl _P3_DIR_PU
                                    262 	.globl _P3_MOD_OC
                                    263 	.globl _P3
                                    264 	.globl _P2_DIR_PU
                                    265 	.globl _P2_MOD_OC
                                    266 	.globl _P2
                                    267 	.globl _P1_DIR_PU
                                    268 	.globl _P1_MOD_OC
                                    269 	.globl _P1
                                    270 	.globl _P0_DIR_PU
                                    271 	.globl _P0_MOD_OC
                                    272 	.globl _P0
                                    273 	.globl _ROM_CTRL
                                    274 	.globl _ROM_DATA_HH
                                    275 	.globl _ROM_DATA_HL
                                    276 	.globl _ROM_DATA_HI
                                    277 	.globl _ROM_ADDR_H
                                    278 	.globl _ROM_ADDR_L
                                    279 	.globl _ROM_ADDR
                                    280 	.globl _GPIO_IE
                                    281 	.globl _IP_EX
                                    282 	.globl _IE_EX
                                    283 	.globl _IP
                                    284 	.globl _IE
                                    285 	.globl _WDOG_COUNT
                                    286 	.globl _RESET_KEEP
                                    287 	.globl _WAKE_CTRL
                                    288 	.globl _CLOCK_CFG
                                    289 	.globl _POWER_CFG
                                    290 	.globl _PCON
                                    291 	.globl _GLOBAL_CFG
                                    292 	.globl _SAFE_MOD
                                    293 	.globl _DPH
                                    294 	.globl _DPL
                                    295 	.globl _SP
                                    296 	.globl _A_INV
                                    297 	.globl _B
                                    298 	.globl _ACC
                                    299 	.globl _PSW
                                    300 	.globl _disable_action_cache
                                    301 	.globl _tap_code_delay_PARM_2
                                    302 	.globl _process_action_PARM_2
                                    303 	.globl _action_exec_PARM_1
                                    304 	.globl _tp_buttons
                                    305 	.globl _action_exec
                                    306 	.globl _ak820_action_exec
                                    307 	.globl _process_record
                                    308 	.globl _process_record_handler
                                    309 	.globl _process_action
                                    310 	.globl _register_code
                                    311 	.globl _unregister_code
                                    312 	.globl _tap_code_delay
                                    313 	.globl _tap_code
                                    314 	.globl _register_mods
                                    315 	.globl _unregister_mods
                                    316 	.globl _register_weak_mods
                                    317 	.globl _unregister_weak_mods
                                    318 	.globl _clear_keyboard
                                    319 	.globl _clear_keyboard_but_mods
                                    320 	.globl _clear_keyboard_but_mods_and_keys
                                    321 ;--------------------------------------------------------
                                    322 ; special function registers
                                    323 ;--------------------------------------------------------
                                    324 	.area RSEG    (ABS,DATA)
      000000                        325 	.org 0x0000
                           0000D0   326 _PSW	=	0x00d0
                           0000E0   327 _ACC	=	0x00e0
                           0000F0   328 _B	=	0x00f0
                           0000FD   329 _A_INV	=	0x00fd
                           000081   330 _SP	=	0x0081
                           000082   331 _DPL	=	0x0082
                           000083   332 _DPH	=	0x0083
                           0000A1   333 _SAFE_MOD	=	0x00a1
                           0000B1   334 _GLOBAL_CFG	=	0x00b1
                           000087   335 _PCON	=	0x0087
                           0000BA   336 _POWER_CFG	=	0x00ba
                           0000B9   337 _CLOCK_CFG	=	0x00b9
                           0000A9   338 _WAKE_CTRL	=	0x00a9
                           0000FE   339 _RESET_KEEP	=	0x00fe
                           0000FF   340 _WDOG_COUNT	=	0x00ff
                           0000A8   341 _IE	=	0x00a8
                           0000B8   342 _IP	=	0x00b8
                           0000E8   343 _IE_EX	=	0x00e8
                           0000E9   344 _IP_EX	=	0x00e9
                           0000B2   345 _GPIO_IE	=	0x00b2
                           008584   346 _ROM_ADDR	=	0x8584
                           000084   347 _ROM_ADDR_L	=	0x0084
                           000085   348 _ROM_ADDR_H	=	0x0085
                           008F8E   349 _ROM_DATA_HI	=	0x8f8e
                           00008E   350 _ROM_DATA_HL	=	0x008e
                           00008F   351 _ROM_DATA_HH	=	0x008f
                           000086   352 _ROM_CTRL	=	0x0086
                           000080   353 _P0	=	0x0080
                           0000C4   354 _P0_MOD_OC	=	0x00c4
                           0000C5   355 _P0_DIR_PU	=	0x00c5
                           000090   356 _P1	=	0x0090
                           000092   357 _P1_MOD_OC	=	0x0092
                           000093   358 _P1_DIR_PU	=	0x0093
                           0000A0   359 _P2	=	0x00a0
                           000094   360 _P2_MOD_OC	=	0x0094
                           000095   361 _P2_DIR_PU	=	0x0095
                           0000B0   362 _P3	=	0x00b0
                           000096   363 _P3_MOD_OC	=	0x0096
                           000097   364 _P3_DIR_PU	=	0x0097
                           0000C0   365 _P4	=	0x00c0
                           0000C2   366 _P4_MOD_OC	=	0x00c2
                           0000C3   367 _P4_DIR_PU	=	0x00c3
                           0000C1   368 _P4_LED_KEY	=	0x00c1
                           0000AA   369 _P5_IN	=	0x00aa
                           0000AB   370 _P5_OUT_PU	=	0x00ab
                           0000AC   371 _P5_DIR	=	0x00ac
                           0000AD   372 _P6_IN	=	0x00ad
                           0000AE   373 _P6_OUT_PU	=	0x00ae
                           0000AF   374 _P6_DIR	=	0x00af
                           0000F1   375 _P7	=	0x00f1
                           0000A2   376 _XBUS_AUX	=	0x00a2
                           000088   377 _TCON	=	0x0088
                           000089   378 _TMOD	=	0x0089
                           00008A   379 _TL0	=	0x008a
                           00008B   380 _TL1	=	0x008b
                           00008C   381 _TH0	=	0x008c
                           00008D   382 _TH1	=	0x008d
                           000098   383 _SCON	=	0x0098
                           000099   384 _SBUF	=	0x0099
                           0000C8   385 _T2CON	=	0x00c8
                           0000C9   386 _T2MOD	=	0x00c9
                           00CBCA   387 _RCAP2	=	0xcbca
                           0000CA   388 _RCAP2L	=	0x00ca
                           0000CB   389 _RCAP2H	=	0x00cb
                           00CDCC   390 _T2COUNT	=	0xcdcc
                           0000CC   391 _TL2	=	0x00cc
                           0000CD   392 _TH2	=	0x00cd
                           00CFCE   393 _T2CAP1	=	0xcfce
                           0000CE   394 _T2CAP1L	=	0x00ce
                           0000CF   395 _T2CAP1H	=	0x00cf
                           0000F8   396 _SPI0_STAT	=	0x00f8
                           0000F9   397 _SPI0_DATA	=	0x00f9
                           0000FA   398 _SPI0_CTRL	=	0x00fa
                           0000FB   399 _SPI0_CK_SE	=	0x00fb
                           0000FC   400 _SPI0_SETUP	=	0x00fc
                           0000BC   401 _SCON1	=	0x00bc
                           0000BD   402 _SBUF1	=	0x00bd
                           0000BE   403 _SBAUD1	=	0x00be
                           0000BF   404 _SIF1	=	0x00bf
                           0000B4   405 _SPI1_STAT	=	0x00b4
                           0000B5   406 _SPI1_DATA	=	0x00b5
                           0000B6   407 _SPI1_CTRL	=	0x00b6
                           0000B7   408 _SPI1_CK_SE	=	0x00b7
                           0000F3   409 _ADC_CTRL	=	0x00f3
                           00F5F4   410 _ADC_DAT	=	0xf5f4
                           0000F4   411 _ADC_DAT_L	=	0x00f4
                           0000F5   412 _ADC_DAT_H	=	0x00f5
                           0000F6   413 _ADC_CHAN	=	0x00f6
                           0000A6   414 _LED_COMMON	=	0x00a6
                           0000A7   415 _LED_PWM_OE	=	0x00a7
                           00C7C6   416 _LED_DMA	=	0xc7c6
                           0000C6   417 _LED_DMA_L	=	0x00c6
                           0000C7   418 _LED_DMA_H	=	0x00c7
                           0000F7   419 _LED_STATUS	=	0x00f7
                           0000B3   420 _I2CX_INT	=	0x00b3
                           0000BB   421 _I2CS_INT_ST	=	0x00bb
                                    422 ;--------------------------------------------------------
                                    423 ; special function bits
                                    424 ;--------------------------------------------------------
                                    425 	.area RSEG    (ABS,DATA)
      000000                        426 	.org 0x0000
                           0000D7   427 _CY	=	0x00d7
                           0000D6   428 _AC	=	0x00d6
                           0000D5   429 _F0	=	0x00d5
                           0000D4   430 _RS1	=	0x00d4
                           0000D3   431 _RS0	=	0x00d3
                           0000D2   432 _OV	=	0x00d2
                           0000D1   433 _F1	=	0x00d1
                           0000D0   434 _P	=	0x00d0
                           0000AF   435 _EA	=	0x00af
                           0000AE   436 _E_DIS	=	0x00ae
                           0000AD   437 _ET2	=	0x00ad
                           0000AC   438 _ES	=	0x00ac
                           0000AB   439 _ET1	=	0x00ab
                           0000AA   440 _EX1	=	0x00aa
                           0000A9   441 _ET0	=	0x00a9
                           0000A8   442 _EX0	=	0x00a8
                           0000BF   443 _PH_FLAG	=	0x00bf
                           0000BE   444 _PL_FLAG	=	0x00be
                           0000BD   445 _PT2	=	0x00bd
                           0000BC   446 _PS	=	0x00bc
                           0000BB   447 _PT1	=	0x00bb
                           0000BA   448 _PX1	=	0x00ba
                           0000B9   449 _PT0	=	0x00b9
                           0000B8   450 _PX0	=	0x00b8
                           0000EF   451 _IE_WDOG	=	0x00ef
                           0000EE   452 _IE_GPIO	=	0x00ee
                           0000ED   453 _IE_PWM_I2C	=	0x00ed
                           0000EC   454 _IE_UART1	=	0x00ec
                           0000EB   455 _IE_ADC	=	0x00eb
                           0000E9   456 _IE_USB	=	0x00e9
                           0000E8   457 _IE_SPI0	=	0x00e8
                           000087   458 _P0_7	=	0x0087
                           000086   459 _P0_6	=	0x0086
                           000085   460 _P0_5	=	0x0085
                           000084   461 _P0_4	=	0x0084
                           000083   462 _P0_3	=	0x0083
                           000082   463 _P0_2	=	0x0082
                           000081   464 _P0_1	=	0x0081
                           000080   465 _P0_0	=	0x0080
                           000081   466 _SDA0	=	0x0081
                           000080   467 _SCL0	=	0x0080
                           000083   468 _TXD_	=	0x0083
                           000082   469 _RXD_	=	0x0082
                           000085   470 _AIN13	=	0x0085
                           000084   471 _AIN12	=	0x0084
                           000083   472 _AIN11	=	0x0083
                           000082   473 _AIN10	=	0x0082
                           000081   474 _AIN9	=	0x0081
                           000080   475 _AIN8	=	0x0080
                           000097   476 _P1_7	=	0x0097
                           000096   477 _P1_6	=	0x0096
                           000095   478 _P1_5	=	0x0095
                           000094   479 _P1_4	=	0x0094
                           000093   480 _P1_3	=	0x0093
                           000092   481 _P1_2	=	0x0092
                           000091   482 _P1_1	=	0x0091
                           000090   483 _P1_0	=	0x0090
                           000097   484 _TXD1_	=	0x0097
                           000096   485 _RXD1_	=	0x0096
                           000097   486 _SCK	=	0x0097
                           000096   487 _MISO	=	0x0096
                           000095   488 _MOSI	=	0x0095
                           000094   489 _SCS	=	0x0094
                           000092   490 _INT0_	=	0x0092
                           000091   491 _T2EX	=	0x0091
                           000091   492 _CAP2	=	0x0091
                           000090   493 _T2	=	0x0090
                           000090   494 _CAP1	=	0x0090
                           000097   495 _AIN7	=	0x0097
                           000096   496 _AIN6	=	0x0096
                           000095   497 _AIN5	=	0x0095
                           000094   498 _AIN4	=	0x0094
                           000093   499 _AIN3	=	0x0093
                           000092   500 _AIN2	=	0x0092
                           000091   501 _AIN1	=	0x0091
                           000090   502 _AIN0	=	0x0090
                           0000A7   503 _P2_7	=	0x00a7
                           0000A6   504 _P2_6	=	0x00a6
                           0000A5   505 _P2_5	=	0x00a5
                           0000A4   506 _P2_4	=	0x00a4
                           0000A3   507 _P2_3	=	0x00a3
                           0000A2   508 _P2_2	=	0x00a2
                           0000A1   509 _P2_1	=	0x00a1
                           0000A0   510 _P2_0	=	0x00a0
                           0000A7   511 _TXD1	=	0x00a7
                           0000A6   512 _RXD1	=	0x00a6
                           0000A5   513 _T2EX_	=	0x00a5
                           0000A5   514 _CAP2_	=	0x00a5
                           0000A4   515 _T2_	=	0x00a4
                           0000A4   516 _CAP1_	=	0x00a4
                           0000B7   517 _P3_7	=	0x00b7
                           0000B6   518 _P3_6	=	0x00b6
                           0000B5   519 _P3_5	=	0x00b5
                           0000B4   520 _P3_4	=	0x00b4
                           0000B3   521 _P3_3	=	0x00b3
                           0000B2   522 _P3_2	=	0x00b2
                           0000B1   523 _P3_1	=	0x00b1
                           0000B0   524 _P3_0	=	0x00b0
                           0000B7   525 _SCK1	=	0x00b7
                           0000B6   526 _MISO1	=	0x00b6
                           0000B5   527 _MOSI1	=	0x00b5
                           0000B5   528 _T1	=	0x00b5
                           0000B4   529 _T0	=	0x00b4
                           0000B3   530 _INT1	=	0x00b3
                           0000B2   531 _INT0	=	0x00b2
                           0000B1   532 _TXD	=	0x00b1
                           0000B0   533 _RXD	=	0x00b0
                           0000C6   534 _P4_6	=	0x00c6
                           0000C5   535 _P4_5	=	0x00c5
                           0000C4   536 _P4_4	=	0x00c4
                           0000C3   537 _P4_3	=	0x00c3
                           0000C2   538 _P4_2	=	0x00c2
                           0000C1   539 _P4_1	=	0x00c1
                           0000C0   540 _P4_0	=	0x00c0
                           00008F   541 _TF1	=	0x008f
                           00008E   542 _TR1	=	0x008e
                           00008D   543 _TF0	=	0x008d
                           00008C   544 _TR0	=	0x008c
                           00008B   545 _IE1	=	0x008b
                           00008A   546 _IT1	=	0x008a
                           000089   547 _IE0	=	0x0089
                           000088   548 _IT0	=	0x0088
                           00009F   549 _SM0	=	0x009f
                           00009E   550 _SM1	=	0x009e
                           00009D   551 _SM2	=	0x009d
                           00009C   552 _REN	=	0x009c
                           00009B   553 _TB8	=	0x009b
                           00009A   554 _RB8	=	0x009a
                           000099   555 _TI	=	0x0099
                           000098   556 _RI	=	0x0098
                           0000CF   557 _TF2	=	0x00cf
                           0000CF   558 _CAP1F	=	0x00cf
                           0000CE   559 _EXF2	=	0x00ce
                           0000CD   560 _RCLK	=	0x00cd
                           0000CC   561 _TCLK	=	0x00cc
                           0000CB   562 _EXEN2	=	0x00cb
                           0000CA   563 _TR2	=	0x00ca
                           0000C9   564 _C_T2	=	0x00c9
                           0000C8   565 _CP_RL2	=	0x00c8
                           0000FF   566 _S0_FST_ACT	=	0x00ff
                           0000FE   567 _S0_IF_OV	=	0x00fe
                           0000FD   568 _S0_IF_FIRST	=	0x00fd
                           0000FC   569 _S0_IF_BYTE	=	0x00fc
                           0000FB   570 _S0_FREE	=	0x00fb
                           0000FA   571 _S0_T_FIFO	=	0x00fa
                           0000F8   572 _S0_R_FIFO	=	0x00f8
                           0000F7   573 _ADC_START	=	0x00f7
                                    574 ;--------------------------------------------------------
                                    575 ; overlayable register banks
                                    576 ;--------------------------------------------------------
                                    577 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        578 	.ds 8
                                    579 ;--------------------------------------------------------
                                    580 ; internal ram data
                                    581 ;--------------------------------------------------------
                                    582 	.area DSEG    (DATA)
      000027                        583 _process_action_sloc0_1_0:
      000027                        584 	.ds 1
                                    585 ;--------------------------------------------------------
                                    586 ; overlayable items in internal ram
                                    587 ;--------------------------------------------------------
                                    588 ;--------------------------------------------------------
                                    589 ; indirectly addressable internal ram data
                                    590 ;--------------------------------------------------------
                                    591 	.area ISEG    (DATA)
                                    592 ;--------------------------------------------------------
                                    593 ; absolute internal ram data
                                    594 ;--------------------------------------------------------
                                    595 	.area IABS    (ABS,DATA)
                                    596 	.area IABS    (ABS,DATA)
                                    597 ;--------------------------------------------------------
                                    598 ; bit data
                                    599 ;--------------------------------------------------------
                                    600 	.area BSEG    (BIT)
      00001F                        601 _process_action_sloc1_1_0:
      00001F                        602 	.ds 1
                                    603 ;--------------------------------------------------------
                                    604 ; paged external ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area PSEG    (PAG,XDATA)
                                    607 ;--------------------------------------------------------
                                    608 ; uninitialized external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area XSEG    (XDATA)
      00080C                        611 _tp_buttons::
      00080C                        612 	.ds 2
      00080E                        613 _action_exec_PARM_1:
      00080E                        614 	.ds 6
      000814                        615 _action_exec_record_10001_620:
      000814                        616 	.ds 9
      00081D                        617 _ak820_action_exec_event_10000_624:
      00081D                        618 	.ds 2
      00081F                        619 _ak820_action_exec_snapshot_10000_625:
      00081F                        620 	.ds 6
      000825                        621 _process_record_record_10000_628:
      000825                        622 	.ds 3
      000828                        623 _process_record_handler_record_argument_10000_634:
      000828                        624 	.ds 3
      00082B                        625 _process_record_handler_action_10000_635:
      00082B                        626 	.ds 2
      00082D                        627 _process_action_PARM_2:
      00082D                        628 	.ds 2
      00082F                        629 _process_action_record_argument_10000_646:
      00082F                        630 	.ds 3
      000832                        631 _process_action_on_40000_669:
      000832                        632 	.ds 1
      000833                        633 _register_code_code_10000_703:
      000833                        634 	.ds 1
      000834                        635 _unregister_code_code_10000_717:
      000834                        636 	.ds 1
      000835                        637 _tap_code_delay_PARM_2:
      000835                        638 	.ds 2
      000837                        639 _tap_code_delay_code_10000_730:
      000837                        640 	.ds 1
      000838                        641 _tap_code_code_10000_737:
      000838                        642 	.ds 1
      000839                        643 _register_mods_mods_10000_739:
      000839                        644 	.ds 1
      00083A                        645 _unregister_mods_mods_10000_743:
      00083A                        646 	.ds 1
      00083B                        647 _register_weak_mods_mods_10000_747:
      00083B                        648 	.ds 1
      00083C                        649 _unregister_weak_mods_mods_10000_751:
      00083C                        650 	.ds 1
                                    651 ;--------------------------------------------------------
                                    652 ; absolute external ram data
                                    653 ;--------------------------------------------------------
                                    654 	.area XABS    (ABS,XDATA)
                                    655 ;--------------------------------------------------------
                                    656 ; initialized external ram data
                                    657 ;--------------------------------------------------------
                                    658 	.area XISEG   (XDATA)
      000DBA                        659 _disable_action_cache::
      000DBA                        660 	.ds 1
                                    661 	.area HOME    (CODE)
                                    662 	.area GSINIT0 (CODE)
                                    663 	.area GSINIT1 (CODE)
                                    664 	.area GSINIT2 (CODE)
                                    665 	.area GSINIT3 (CODE)
                                    666 	.area GSINIT4 (CODE)
                                    667 	.area GSINIT5 (CODE)
                                    668 	.area GSINIT  (CODE)
                                    669 	.area GSFINAL (CODE)
                                    670 	.area CSEG    (CODE)
                                    671 ;--------------------------------------------------------
                                    672 ; global & static initialisations
                                    673 ;--------------------------------------------------------
                                    674 	.area HOME    (CODE)
                                    675 	.area GSINIT  (CODE)
                                    676 	.area GSFINAL (CODE)
                                    677 	.area GSINIT  (CODE)
                                    678 ;--------------------------------------------------------
                                    679 ; Home
                                    680 ;--------------------------------------------------------
                                    681 	.area HOME    (CODE)
                                    682 	.area HOME    (CODE)
                                    683 ;--------------------------------------------------------
                                    684 ; code
                                    685 ;--------------------------------------------------------
                                    686 	.area CSEG    (CODE)
                                    687 ;------------------------------------------------------------
                                    688 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    689 ;------------------------------------------------------------
                                    690 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    691 ;------------------------------------------------------------
                                    692 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    693 ;	-----------------------------------------
                           000007   694 	ar7 = 0x07
                           000006   695 	ar6 = 0x06
                           000005   696 	ar5 = 0x05
                           000004   697 	ar4 = 0x04
                           000003   698 	ar3 = 0x03
                           000002   699 	ar2 = 0x02
                           000001   700 	ar1 = 0x01
                           000000   701 	ar0 = 0x00
                                    702 ;	 function action_exec
                                    703 ;	-----------------------------------------
      006EBF                        704 _action_exec:
                                    705 ;	quantum/action.c:92: ak820_combo_tick(event.time);
      006EBF 90 08 10         [24]  706 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      006EC2 12 37 F5         [24]  707 	lcall	_ak820_outline_0005
      006EC5 12 36 04         [24]  708 	lcall	_ak820_combo_tick
                                    709 ;	quantum/action.c:95: if (!ak820_tapping_before(&event)) return;
      006EC8 90 08 0E         [24]  710 	mov	dptr,#_action_exec_PARM_1
      006ECB 12 44 4D         [24]  711 	lcall	_ak820_tapping_before
      006ECE E5 82            [12]  712 	mov	a, dpl
      006ED0 70 01            [24]  713 	jnz	00102$
      006ED2 22               [24]  714 	ret
      006ED3                        715 00102$:
                                    716 ;	quantum/action.c:113: if (event.pressed) {
      006ED3 90 08 13         [24]  717 	mov	dptr,#(_action_exec_PARM_1 + 0x0005)
      006ED6 E0               [24]  718 	movx	a,@dptr
      006ED7 60 03            [24]  719 	jz	00104$
                                    720 ;	quantum/action.c:115: clear_weak_mods();
      006ED9 12 7E 4B         [24]  721 	lcall	_clear_weak_mods
      006EDC                        722 00104$:
                                    723 ;	quantum/action.c:127: record.event = event;
      006EDC 90 0D 9B         [24]  724 	mov	dptr,#___memcpy_PARM_2
      006EDF 74 0E            [12]  725 	mov	a,#_action_exec_PARM_1
      006EE1 F0               [24]  726 	movx	@dptr,a
      006EE2 74 08            [12]  727 	mov	a,#(_action_exec_PARM_1 >> 8)
      006EE4 12 38 6B         [24]  728 	lcall	_ak820_outline_0090
      006EE7 12 74 C5         [24]  729 	lcall	_ak820_outline_0070
      006EEA 90 08 14         [24]  730 	mov	dptr,#_action_exec_record_10001_620
      006EED F5 F0            [12]  731 	mov	b,a
      006EEF 12 B5 A2         [24]  732 	lcall	___memcpy
                                    733 ;	quantum/action.c:129: record.tap.count = 0;
      006EF2 90 08 1A         [24]  734 	mov	dptr,#(_action_exec_record_10001_620 + 0x0006)
      006EF5 E0               [24]  735 	movx	a,@dptr
      006EF6 54 0F            [12]  736 	anl	a,#0x0f
      006EF8 F0               [24]  737 	movx	@dptr,a
                                    738 ;	quantum/action.c:134: record.keycode = 0;
      006EF9 90 08 1B         [24]  739 	mov	dptr,#(_action_exec_record_10001_620 + 0x0007)
      006EFC 12 4D E7         [24]  740 	lcall	_ak820_outline_0166
                                    741 ;	quantum/action.c:165: if (IS_NOEVENT(record.event) || pre_process_record_quantum(&record)) {
      006EFF 90 08 18         [24]  742 	mov	dptr,#(_action_exec_record_10001_620 + 0x0004)
      006F02 E0               [24]  743 	movx	a,@dptr
      006F03 60 0D            [24]  744 	jz	00107$
      006F05 90 08 14         [24]  745 	mov	dptr,#_action_exec_record_10001_620
      006F08 75 F0 00         [24]  746 	mov	b, #0x00
      006F0B 12 9C 4D         [24]  747 	lcall	_pre_process_record_quantum
      006F0E E5 82            [12]  748 	mov	a, dpl
      006F10 60 14            [24]  749 	jz	00110$
      006F12                        750 00107$:
                                    751 ;	quantum/action.c:167: if (!ak820_tapping_process(&record)) return;
      006F12 90 08 14         [24]  752 	mov	dptr,#_action_exec_record_10001_620
      006F15 12 45 3B         [24]  753 	lcall	_ak820_tapping_process
      006F18 E5 82            [12]  754 	mov	a, dpl
      006F1A 70 01            [24]  755 	jnz	00106$
      006F1C 22               [24]  756 	ret
      006F1D                        757 00106$:
                                    758 ;	quantum/action.c:172: process_record(&record);
      006F1D 90 08 14         [24]  759 	mov	dptr,#_action_exec_record_10001_620
      006F20 75 F0 00         [24]  760 	mov	b, #0x00
                                    761 ;	quantum/action.c:182: }
      006F23 02 6F 63         [24]  762 	ljmp	_process_record
      006F26                        763 00110$:
      006F26 22               [24]  764 	ret
                                    765 ;------------------------------------------------------------
                                    766 ;Allocation info for local variables in function 'ak820_action_exec'
                                    767 ;------------------------------------------------------------
                                    768 ;event         Allocated with name '_ak820_action_exec_event_10000_624'
                                    769 ;snapshot      Allocated with name '_ak820_action_exec_snapshot_10000_625'
                                    770 ;------------------------------------------------------------
                                    771 ;	quantum/action.c:185: void ak820_action_exec(const keyevent_t __xdata *event) {
                                    772 ;	-----------------------------------------
                                    773 ;	 function ak820_action_exec
                                    774 ;	-----------------------------------------
      006F27                        775 _ak820_action_exec:
      006F27 12 38 7D         [24]  776 	lcall	_ak820_outline_0112
      006F2A 90 08 1D         [24]  777 	mov	dptr,#_ak820_action_exec_event_10000_624
      006F2D 12 38 82         [24]  778 	lcall	_ak820_outline_0113
                                    779 ;	quantum/action.c:188: keyevent_t snapshot = *event;
      006F30 90 08 1D         [24]  780 	mov	dptr,#_ak820_action_exec_event_10000_624
      006F33 12 38 71         [24]  781 	lcall	_ak820_outline_0093
      006F36 7F 00            [12]  782 	mov	r7,#0x00
      006F38 90 0D 9B         [24]  783 	mov	dptr,#___memcpy_PARM_2
      006F3B ED               [12]  784 	mov	a,r5
      006F3C 12 38 20         [24]  785 	lcall	_ak820_outline_0015
      006F3F 12 74 C5         [24]  786 	lcall	_ak820_outline_0070
      006F42 90 08 1F         [24]  787 	mov	dptr,#_ak820_action_exec_snapshot_10000_625
      006F45 F5 F0            [12]  788 	mov	b,a
      006F47 12 B5 A2         [24]  789 	lcall	___memcpy
                                    790 ;	quantum/action.c:189: action_exec(snapshot);
      006F4A 90 0D 9B         [24]  791 	mov	dptr,#___memcpy_PARM_2
      006F4D 74 1F            [12]  792 	mov	a,#_ak820_action_exec_snapshot_10000_625
      006F4F F0               [24]  793 	movx	@dptr,a
      006F50 74 08            [12]  794 	mov	a,#(_ak820_action_exec_snapshot_10000_625 >> 8)
      006F52 12 38 6B         [24]  795 	lcall	_ak820_outline_0090
      006F55 12 74 C5         [24]  796 	lcall	_ak820_outline_0070
      006F58 90 08 0E         [24]  797 	mov	dptr,#_action_exec_PARM_1
      006F5B F5 F0            [12]  798 	mov	b,a
      006F5D 12 B5 A2         [24]  799 	lcall	___memcpy
                                    800 ;	quantum/action.c:190: }
      006F60 02 6E BF         [24]  801 	ljmp	_action_exec
                                    802 ;------------------------------------------------------------
                                    803 ;Allocation info for local variables in function 'process_record_nocache'
                                    804 ;------------------------------------------------------------
                                    805 ;record        Allocated with name '_process_record_nocache_record_10000_626'
                                    806 ;------------------------------------------------------------
                                    807 ;	quantum/action.c:275: void process_record_nocache(keyrecord_t *record) {
                                    808 ;	-----------------------------------------
                                    809 ;	 function process_record
                                    810 ;	-----------------------------------------
      006F63                        811 _process_record:
      006F63 12 43 0E         [24]  812 	lcall	_ak820_outline_0035
      006F66 90 08 25         [24]  813 	mov	dptr,#_process_record_record_10000_628
      006F69 12 38 20         [24]  814 	lcall	_ak820_outline_0015
                                    815 ;	quantum/action.c:329: if (IS_NOEVENT(record->event)) {
      006F6C 90 08 25         [24]  816 	mov	dptr,#_process_record_record_10000_628
      006F6F 12 4D 9B         [24]  817 	lcall	_ak820_outline_0013
      006F72 74 04            [12]  818 	mov	a,#0x04
      006F74 12 74 98         [24]  819 	lcall	_ak820_outline_0012
      006F77 12 B6 7B         [24]  820 	lcall	__gptrget
      006F7A 70 01            [24]  821 	jnz	00102$
                                    822 ;	quantum/action.c:330: return;
      006F7C 22               [24]  823 	ret
      006F7D                        824 00102$:
                                    825 ;	quantum/action.c:343: if (!process_record_quantum(record)) {
      006F7D 12 6C 05         [24]  826 	lcall	_ak820_outline_0046
      006F80 C0 07            [24]  827 	push	ar7
      006F82 C0 06            [24]  828 	push	ar6
      006F84 C0 05            [24]  829 	push	ar5
      006F86 12 9C D5         [24]  830 	lcall	_process_record_quantum
      006F89 E5 82            [12]  831 	mov	a, dpl
      006F8B D0 05            [24]  832 	pop	ar5
      006F8D D0 06            [24]  833 	pop	ar6
      006F8F D0 07            [24]  834 	pop	ar7
      006F91 70 01            [24]  835 	jnz	00104$
                                    836 ;	quantum/action.c:352: return;
      006F93 22               [24]  837 	ret
      006F94                        838 00104$:
                                    839 ;	quantum/action.c:358: process_record_handler(record);
      006F94 12 6C 05         [24]  840 	lcall	_ak820_outline_0046
      006F97 12 6F A3         [24]  841 	lcall	_process_record_handler
                                    842 ;	quantum/action.c:362: post_process_record_quantum(record);
      006F9A 90 08 25         [24]  843 	mov	dptr,#_process_record_record_10000_628
      006F9D 12 4D 75         [24]  844 	lcall	_ak820_outline_0001
                                    845 ;	quantum/action.c:366: }
      006FA0 02 9C AA         [24]  846 	ljmp	_post_process_record_quantum
                                    847 ;------------------------------------------------------------
                                    848 ;Allocation info for local variables in function 'process_record_handler'
                                    849 ;------------------------------------------------------------
                                    850 ;record_argument Allocated with name '_process_record_handler_record_argument_10000_634'
                                    851 ;record        Allocated with name '_process_record_handler_record_10000_635'
                                    852 ;action        Allocated with name '_process_record_handler_action_10000_635'
                                    853 ;------------------------------------------------------------
                                    854 ;	quantum/action.c:368: void process_record_handler(keyrecord_t *record_argument) {
                                    855 ;	-----------------------------------------
                                    856 ;	 function process_record_handler
                                    857 ;	-----------------------------------------
      006FA3                        858 _process_record_handler:
      006FA3 12 43 0E         [24]  859 	lcall	_ak820_outline_0035
      006FA6 90 08 28         [24]  860 	mov	dptr,#_process_record_handler_record_argument_10000_634
      006FA9 12 38 20         [24]  861 	lcall	_ak820_outline_0015
                                    862 ;	quantum/action.c:372: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      006FAC 90 08 28         [24]  863 	mov	dptr,#_process_record_handler_record_argument_10000_634
      006FAF 12 37 FF         [24]  864 	lcall	_ak820_outline_0007
                                    865 ;	quantum/action.c:379: if (record->keycode) {
      006FB2 4C               [12]  866 	orl	a,r4
      006FB3 60 19            [24]  867 	jz	00102$
                                    868 ;	quantum/action.c:380: action.code = action_for_keycode(record->keycode);
      006FB5 12 38 92         [24]  869 	lcall	_ak820_outline_0121
      006FB8 C0 07            [24]  870 	push	ar7
      006FBA C0 06            [24]  871 	push	ar6
      006FBC 12 92 3B         [24]  872 	lcall	_action_for_keycode
      006FBF 12 43 67         [24]  873 	lcall	_ak820_outline_0145
      006FC2 D0 06            [24]  874 	pop	ar6
      006FC4 D0 07            [24]  875 	pop	ar7
      006FC6 90 08 2B         [24]  876 	mov	dptr,#_process_record_handler_action_10000_635
      006FC9 12 38 5F         [24]  877 	lcall	_ak820_outline_0071
      006FCC 80 2B            [24]  878 	sjmp	00104$
      006FCE                        879 00102$:
                                    880 ;	quantum/action.c:383: action.code = action_for_keycode(ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed));
      006FCE 12 74 A6         [24]  881 	lcall	_ak820_outline_0019
      006FD1 7A 00            [12]  882 	mov	r2,#0x00
      006FD3 12 43 61         [24]  883 	lcall	_ak820_outline_0138
      006FD6 12 42 FC         [24]  884 	lcall	_ak820_outline_0011
      006FD9 E0               [24]  885 	movx	a,@dptr
      006FDA 90 09 67         [24]  886 	mov	dptr,#_ak820_resolve_key_PARM_2
      006FDD F0               [24]  887 	movx	@dptr,a
      006FDE 8D 82            [24]  888 	mov	dpl, r5
      006FE0 8C 83            [24]  889 	mov	dph, r4
      006FE2 C0 07            [24]  890 	push	ar7
      006FE4 C0 06            [24]  891 	push	ar6
      006FE6 12 78 3E         [24]  892 	lcall	_ak820_resolve_key
      006FE9 12 92 3B         [24]  893 	lcall	_action_for_keycode
      006FEC 12 43 67         [24]  894 	lcall	_ak820_outline_0145
      006FEF D0 06            [24]  895 	pop	ar6
      006FF1 D0 07            [24]  896 	pop	ar7
      006FF3 90 08 2B         [24]  897 	mov	dptr,#_process_record_handler_action_10000_635
      006FF6 12 38 5F         [24]  898 	lcall	_ak820_outline_0071
                                    899 ;	quantum/action.c:392: ac_dprintf("ACTION: ");
      006FF9                        900 00104$:
                                    901 ;	quantum/action.c:403: process_action(record, action);
      006FF9 7D 00            [12]  902 	mov	r5,#0x00
      006FFB 90 0D 9B         [24]  903 	mov	dptr,#___memcpy_PARM_2
      006FFE 74 2B            [12]  904 	mov	a,#_process_record_handler_action_10000_635
      007000 F0               [24]  905 	movx	@dptr,a
      007001 74 08            [12]  906 	mov	a,#(_process_record_handler_action_10000_635 >> 8)
      007003 12 38 6B         [24]  907 	lcall	_ak820_outline_0090
      007006 90 0D 9E         [24]  908 	mov	dptr,#___memcpy_PARM_3
      007009 74 02            [12]  909 	mov	a,#0x02
      00700B 12 38 97         [24]  910 	lcall	_ak820_outline_0122
      00700E 90 08 2D         [24]  911 	mov	dptr,#_process_action_PARM_2
      007011 F5 F0            [12]  912 	mov	b,a
      007013 C0 07            [24]  913 	push	ar7
      007015 C0 06            [24]  914 	push	ar6
      007017 C0 05            [24]  915 	push	ar5
      007019 12 B5 A2         [24]  916 	lcall	___memcpy
      00701C D0 05            [24]  917 	pop	ar5
      00701E D0 06            [24]  918 	pop	ar6
      007020 D0 07            [24]  919 	pop	ar7
      007022 12 6E 2A         [24]  920 	lcall	_ak820_outline_0050
                                    921 ;	quantum/action.c:404: }
      007025 02 70 28         [24]  922 	ljmp	_process_action
                                    923 ;------------------------------------------------------------
                                    924 ;Allocation info for local variables in function 'register_mouse'
                                    925 ;------------------------------------------------------------
                                    926 ;pressed       Allocated with name '_register_mouse_PARM_2'
                                    927 ;mouse_keycode Allocated with name '_register_mouse_mouse_keycode_10000_643'
                                    928 ;------------------------------------------------------------
                                    929 ;	quantum/action.c:416: void register_mouse(uint8_t mouse_keycode, bool pressed) {
                                    930 ;	-----------------------------------------
                                    931 ;	 function process_action
                                    932 ;	-----------------------------------------
      007028                        933 _process_action:
      007028 12 43 0E         [24]  934 	lcall	_ak820_outline_0035
      00702B 90 08 2F         [24]  935 	mov	dptr,#_process_action_record_argument_10000_646
      00702E 12 38 20         [24]  936 	lcall	_ak820_outline_0015
                                    937 ;	quantum/action.c:469: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      007031 90 08 2F         [24]  938 	mov	dptr,#_process_action_record_argument_10000_646
      007034 12 37 F5         [24]  939 	lcall	_ak820_outline_0005
                                    940 ;	quantum/action.c:475: pressed = record->event.pressed;
      007037 A3               [24]  941 	inc	dptr
      007038 A3               [24]  942 	inc	dptr
      007039 A3               [24]  943 	inc	dptr
      00703A A3               [24]  944 	inc	dptr
      00703B A3               [24]  945 	inc	dptr
      00703C E0               [24]  946 	movx	a,@dptr
      00703D F5 27            [12]  947 	mov	_process_action_sloc0_1_0,a
                                    948 ;	quantum/action.c:499: switch (action.kind.id) {
      00703F 90 08 2E         [24]  949 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007042 E0               [24]  950 	movx	a,@dptr
      007043 C4               [12]  951 	swap	a
      007044 54 0F            [12]  952 	anl	a,#0x0f
      007046 FD               [12]  953 	mov  r5,a
      007047 24 F4            [12]  954 	add	a,#0xff - 0x0b
      007049 50 03            [24]  955 	jnc	00434$
      00704B 02 72 C9         [24]  956 	ljmp	00181$
      00704E                        957 00434$:
                                    958 ;	free result
      00704E ED               [12]  959 	mov	a,r5
      00704F 24 0A            [12]  960 	add	a,#(00435$-3-.)
      007051 83               [24]  961 	movc	a,@a+pc
      007052 F5 82            [12]  962 	mov	dpl,a
      007054 ED               [12]  963 	mov	a,r5
      007055 24 10            [12]  964 	add	a,#(00436$-3-.)
      007057 83               [24]  965 	movc	a,@a+pc
      007058 F5 83            [12]  966 	mov	dph,a
      00705A E4               [12]  967 	clr	a
      00705B 73               [24]  968 	jmp	@a+dptr
      00705C                        969 00435$:
      00705C 74                     970 	.db	00102$
      00705D 74                     971 	.db	00102$
      00705E C9                     972 	.db	00181$
      00705F C9                     973 	.db	00181$
      007060 FE                     974 	.db	00123$
      007061 C9                     975 	.db	00181$
      007062 C9                     976 	.db	00181$
      007063 C9                     977 	.db	00181$
      007064 5E                     978 	.db	00131$
      007065 30                     979 	.db	00147$
      007066 56                     980 	.db	00152$
      007067 56                     981 	.db	00152$
      007068                        982 00436$:
      007068 70                     983 	.db	00102$>>8
      007069 70                     984 	.db	00102$>>8
      00706A 72                     985 	.db	00181$>>8
      00706B 72                     986 	.db	00181$>>8
      00706C 70                     987 	.db	00123$>>8
      00706D 72                     988 	.db	00181$>>8
      00706E 72                     989 	.db	00181$>>8
      00706F 72                     990 	.db	00181$>>8
      007070 71                     991 	.db	00131$>>8
      007071 72                     992 	.db	00147$>>8
      007072 72                     993 	.db	00152$>>8
      007073 72                     994 	.db	00152$>>8
                                    995 ;	quantum/action.c:502: case ACT_RMODS: {
      007074                        996 00102$:
                                    997 ;	quantum/action.c:503: mods = (action.kind.id == ACT_LMODS) ? action.key.mods : action.key.mods << 4;
      007074 90 08 2E         [24]  998 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007077 E0               [24]  999 	movx	a,@dptr
      007078 54 F0            [12] 1000 	anl	a,#0xf0
      00707A 70 06            [24] 1001 	jnz	00194$
      00707C 12 74 DF         [24] 1002 	lcall	_ak820_outline_0107
      00707F FD               [12] 1003 	mov	r5,a
      007080 80 07            [24] 1004 	sjmp	00195$
      007082                       1005 00194$:
      007082 12 74 DF         [24] 1006 	lcall	_ak820_outline_0107
      007085 C4               [12] 1007 	swap	a
      007086 54 F0            [12] 1008 	anl	a,#0xf0
      007088 FD               [12] 1009 	mov	r5,a
      007089                       1010 00195$:
                                   1011 ;	quantum/action.c:505: if (pressed) {
      007089 E5 27            [12] 1012 	mov	a,_process_action_sloc0_1_0
      00708B 60 35            [24] 1013 	jz	00119$
                                   1014 ;	quantum/action.c:506: if (mods) {
      00708D ED               [12] 1015 	mov	a,r5
      00708E 60 29            [24] 1016 	jz	00110$
                                   1017 ;	quantum/action.c:507: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      007090 12 74 F1         [24] 1018 	lcall	_ak820_outline_0155
      007093 FC               [12] 1019 	mov	r4,a
      007094 BC E0 00         [24] 1020 	cjne	r4,#0xe0,00440$
      007097                       1021 00440$:
      007097 40 07            [24] 1022 	jc	00108$
      007099 12 74 F1         [24] 1023 	lcall	_ak820_outline_0155
      00709C 24 18            [12] 1024 	add	a,#0xff - 0xe7
      00709E 50 0A            [24] 1025 	jnc	00104$
                                   1026 ;	free result
      0070A0                       1027 00108$:
      0070A0 7B 2D            [12] 1028 	mov	r3,#_process_action_PARM_2
      0070A2 7C 08            [12] 1029 	mov	r4,#(_process_action_PARM_2 >> 8)
      0070A4 12 33 FC         [24] 1030 	lcall	_ak820_outline_0120
      0070A7 E0               [24] 1031 	movx	a,@dptr
      0070A8 70 07            [24] 1032 	jnz	00105$
      0070AA                       1033 00104$:
                                   1034 ;	quantum/action.c:511: add_owned_mods(mods);
      0070AA 8D 82            [24] 1035 	mov	dpl, r5
      0070AC 12 7A 58         [24] 1036 	lcall	_add_owned_mods
      0070AF 80 05            [24] 1037 	sjmp	00106$
      0070B1                       1038 00105$:
                                   1039 ;	quantum/action.c:513: add_owned_weak_mods(mods);
      0070B1 8D 82            [24] 1040 	mov	dpl, r5
      0070B3 12 7A 77         [24] 1041 	lcall	_add_owned_weak_mods
      0070B6                       1042 00106$:
                                   1043 ;	quantum/action.c:515: send_keyboard_report();
      0070B6 12 7D 9C         [24] 1044 	lcall	_send_keyboard_report
      0070B9                       1045 00110$:
                                   1046 ;	quantum/action.c:517: register_code(action.key.code);
      0070B9 12 74 CF         [24] 1047 	lcall	_ak820_outline_0076
      0070BC 12 72 E0         [24] 1048 	lcall	_register_code
      0070BF 02 72 C9         [24] 1049 	ljmp	00181$
      0070C2                       1050 00119$:
                                   1051 ;	quantum/action.c:519: unregister_code(action.key.code);
      0070C2 12 74 CF         [24] 1052 	lcall	_ak820_outline_0076
      0070C5 C0 05            [24] 1053 	push	ar5
      0070C7 12 73 4D         [24] 1054 	lcall	_unregister_code
      0070CA D0 05            [24] 1055 	pop	ar5
                                   1056 ;	quantum/action.c:520: if (mods) {
      0070CC ED               [12] 1057 	mov	a,r5
      0070CD 70 03            [24] 1058 	jnz	00444$
      0070CF 02 72 C9         [24] 1059 	ljmp	00181$
      0070D2                       1060 00444$:
                                   1061 ;	quantum/action.c:521: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      0070D2 12 74 F1         [24] 1062 	lcall	_ak820_outline_0155
      0070D5 FC               [12] 1063 	mov	r4,a
      0070D6 BC E0 00         [24] 1064 	cjne	r4,#0xe0,00445$
      0070D9                       1065 00445$:
      0070D9 40 07            [24] 1066 	jc	00115$
      0070DB 12 74 F1         [24] 1067 	lcall	_ak820_outline_0155
      0070DE 24 18            [12] 1068 	add	a,#0xff - 0xe7
      0070E0 50 0A            [24] 1069 	jnc	00111$
                                   1070 ;	free result
      0070E2                       1071 00115$:
      0070E2 7B 2D            [12] 1072 	mov	r3,#_process_action_PARM_2
      0070E4 7C 08            [12] 1073 	mov	r4,#(_process_action_PARM_2 >> 8)
      0070E6 12 33 FC         [24] 1074 	lcall	_ak820_outline_0120
      0070E9 E0               [24] 1075 	movx	a,@dptr
      0070EA 70 07            [24] 1076 	jnz	00112$
      0070EC                       1077 00111$:
                                   1078 ;	quantum/action.c:522: del_owned_mods(mods);
      0070EC 8D 82            [24] 1079 	mov	dpl, r5
      0070EE 12 7A 68         [24] 1080 	lcall	_del_owned_mods
      0070F1 80 05            [24] 1081 	sjmp	00113$
      0070F3                       1082 00112$:
                                   1083 ;	quantum/action.c:524: del_owned_weak_mods(mods);
      0070F3 8D 82            [24] 1084 	mov	dpl, r5
      0070F5 12 7A 87         [24] 1085 	lcall	_del_owned_weak_mods
      0070F8                       1086 00113$:
                                   1087 ;	quantum/action.c:526: send_keyboard_report();
      0070F8 12 7D 9C         [24] 1088 	lcall	_send_keyboard_report
                                   1089 ;	quantum/action.c:529: } break;
      0070FB 02 72 C9         [24] 1090 	ljmp	00181$
                                   1091 ;	quantum/action.c:606: case ACT_USAGE:
      0070FE                       1092 00123$:
                                   1093 ;	quantum/action.c:612: if (record->keycode >= KC_SYSTEM_POWER && record->keycode <= KC_LAUNCHPAD) {
      0070FE 74 07            [12] 1094 	mov	a,#0x07
      007100 12 38 32         [24] 1095 	lcall	_ak820_outline_0020
      007103 12 46 F6         [24] 1096 	lcall	_ak820_outline_0008
      007106 C3               [12] 1097 	clr	c
      007107 EC               [12] 1098 	mov	a,r4
      007108 94 A5            [12] 1099 	subb	a,#0xa5
      00710A ED               [12] 1100 	mov	a,r5
      00710B 94 00            [12] 1101 	subb	a,#0x00
      00710D 40 15            [24] 1102 	jc	00125$
      00710F 74 C2            [12] 1103 	mov	a,#0xc2
      007111 9C               [12] 1104 	subb	a,r4
      007112 E4               [12] 1105 	clr	a
      007113 9D               [12] 1106 	subb	a,r5
      007114 40 0E            [24] 1107 	jc	00125$
                                   1108 ;	free result
                                   1109 ;	quantum/action.c:613: owned_usage_key((uint8_t)record->keycode, pressed);
      007116 90 0A 8E         [24] 1110 	mov	dptr,#_owned_usage_key_PARM_2
      007119 E5 27            [12] 1111 	mov	a,_process_action_sloc0_1_0
      00711B F0               [24] 1112 	movx	@dptr,a
      00711C 8E 82            [24] 1113 	mov	dpl, r6
      00711E 12 7C 47         [24] 1114 	lcall	_owned_usage_key
                                   1115 ;	quantum/action.c:614: break;
      007121 02 72 C9         [24] 1116 	ljmp	00181$
      007124                       1117 00125$:
                                   1118 ;	quantum/action.c:617: switch (action.usage.page) {
      007124 12 74 D6         [24] 1119 	lcall	_ak820_outline_0086
      007127 FF               [12] 1120 	mov	r7,a
      007128 60 08            [24] 1121 	jz	00127$
      00712A BF 01 02         [24] 1122 	cjne	r7,#0x01,00452$
      00712D 80 19            [24] 1123 	sjmp	00128$
      00712F                       1124 00452$:
      00712F 02 72 C9         [24] 1125 	ljmp	00181$
                                   1126 ;	quantum/action.c:618: case PAGE_SYSTEM:
      007132                       1127 00127$:
                                   1128 ;	quantum/action.c:619: host_system_send(pressed ? action.usage.code : 0);
      007132 E5 27            [12] 1129 	mov	a,_process_action_sloc0_1_0
      007134 60 05            [24] 1130 	jz	00196$
      007136 12 74 E6         [24] 1131 	lcall	_ak820_outline_0128
      007139 80 04            [24] 1132 	sjmp	00197$
      00713B                       1133 00196$:
      00713B 7E 00            [12] 1134 	mov	r6,#0x00
      00713D 7F 00            [12] 1135 	mov	r7,#0x00
      00713F                       1136 00197$:
      00713F 12 38 87         [24] 1137 	lcall	_ak820_outline_0114
      007142 12 6B 8F         [24] 1138 	lcall	_host_system_send
                                   1139 ;	quantum/action.c:620: break;
      007145 02 72 C9         [24] 1140 	ljmp	00181$
                                   1141 ;	quantum/action.c:621: case PAGE_CONSUMER:
      007148                       1142 00128$:
                                   1143 ;	quantum/action.c:622: host_consumer_send(pressed ? action.usage.code : 0);
      007148 E5 27            [12] 1144 	mov	a,_process_action_sloc0_1_0
      00714A 60 05            [24] 1145 	jz	00198$
      00714C 12 74 E6         [24] 1146 	lcall	_ak820_outline_0128
      00714F 80 04            [24] 1147 	sjmp	00199$
      007151                       1148 00198$:
      007151 7E 00            [12] 1149 	mov	r6,#0x00
      007153 7F 00            [12] 1150 	mov	r7,#0x00
      007155                       1151 00199$:
      007155 12 38 87         [24] 1152 	lcall	_ak820_outline_0114
      007158 12 6B BF         [24] 1153 	lcall	_host_consumer_send
                                   1154 ;	quantum/action.c:625: break;
      00715B 02 72 C9         [24] 1155 	ljmp	00181$
                                   1156 ;	quantum/action.c:632: case ACT_LAYER: {
      00715E                       1157 00131$:
                                   1158 ;	quantum/action.c:633: uint8_t on = action.layer_bitop.on;
      00715E 90 08 2E         [24] 1159 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007161 E0               [24] 1160 	movx	a,@dptr
      007162 54 03            [12] 1161 	anl	a,#0x03
      007164 90 08 32         [24] 1162 	mov	dptr,#_process_action_on_40000_669
      007167 F0               [24] 1163 	movx	@dptr,a
                                   1164 ;	quantum/action.c:636: if (on ? (pressed ? (on & ON_PRESS) : (on & ON_RELEASE)) : !pressed) {
      007168 E0               [24] 1165 	movx	a,@dptr
      007169 FF               [12] 1166 	mov	r7,a
      00716A 60 11            [24] 1167 	jz	00200$
      00716C E5 27            [12] 1168 	mov	a,_process_action_sloc0_1_0
      00716E 60 07            [24] 1169 	jz	00202$
      007170 8F 06            [24] 1170 	mov	ar6,r7
      007172 53 06 01         [24] 1171 	anl	ar6,#0x01
      007175 80 10            [24] 1172 	sjmp	00201$
      007177                       1173 00202$:
      007177 74 02            [12] 1174 	mov	a,#0x02
      007179 5F               [12] 1175 	anl	a,r7
      00717A FE               [12] 1176 	mov	r6,a
      00717B 80 0A            [24] 1177 	sjmp	00201$
      00717D                       1178 00200$:
      00717D E5 27            [12] 1179 	mov	a,_process_action_sloc0_1_0
      00717F B4 01 00         [24] 1180 	cjne	a,#0x01,00457$
      007182                       1181 00457$:
      007182 92 1F            [24] 1182 	mov  _process_action_sloc1_1_0,c
      007184 E4               [12] 1183 	clr	a
      007185 33               [12] 1184 	rlc	a
      007186 FE               [12] 1185 	mov	r6,a
      007187                       1186 00201$:
      007187 EE               [12] 1187 	mov	a,r6
      007188 70 03            [24] 1188 	jnz	00458$
      00718A 02 72 C9         [24] 1189 	ljmp	00181$
      00718D                       1190 00458$:
                                   1191 ;	quantum/action.c:637: uint8_t shift = action.layer_bitop.part * 4;
      00718D 12 74 F1         [24] 1192 	lcall	_ak820_outline_0155
      007190 C4               [12] 1193 	swap	a
      007191 03               [12] 1194 	rr	a
      007192 54 07            [12] 1195 	anl	a,#0x07
      007194 25 E0            [12] 1196 	add	a,acc
      007196 25 E0            [12] 1197 	add	a,acc
      007198 FF               [12] 1198 	mov	r7,a
                                   1199 ;	quantum/action.c:638: layer_state_t bits = ((layer_state_t)action.layer_bitop.bits) << shift;
      007199 12 74 F1         [24] 1200 	lcall	_ak820_outline_0155
      00719C 54 0F            [12] 1201 	anl	a,#0x0f
      00719E FE               [12] 1202 	mov	r6,a
      00719F 8F F0            [24] 1203 	mov	b,r7
      0071A1 05 F0            [12] 1204 	inc	b
      0071A3 EE               [12] 1205 	mov	a,r6
      0071A4 80 02            [24] 1206 	sjmp	00460$
      0071A6                       1207 00459$:
      0071A6 25 E0            [12] 1208 	add	a,acc
      0071A8                       1209 00460$:
      0071A8 D5 F0 FB         [24] 1210 	djnz	b,00459$
      0071AB FE               [12] 1211 	mov	r6,a
                                   1212 ;	quantum/action.c:639: layer_state_t mask = action.layer_bitop.xbit ? ~(((layer_state_t)0xf) << shift) : 0;
      0071AC 12 74 F1         [24] 1213 	lcall	_ak820_outline_0155
      0071AF 30 E4 11         [24] 1214 	jnb	acc.4,00204$
      0071B2 8F F0            [24] 1215 	mov	b,r7
      0071B4 05 F0            [12] 1216 	inc	b
      0071B6 74 0F            [12] 1217 	mov	a,#0x0f
      0071B8 80 02            [24] 1218 	sjmp	00463$
      0071BA                       1219 00462$:
      0071BA 25 E0            [12] 1220 	add	a,acc
      0071BC                       1221 00463$:
      0071BC D5 F0 FB         [24] 1222 	djnz	b,00462$
      0071BF F4               [12] 1223 	cpl	a
      0071C0 FF               [12] 1224 	mov	r7,a
      0071C1 80 02            [24] 1225 	sjmp	00205$
      0071C3                       1226 00204$:
      0071C3 7F 00            [12] 1227 	mov	r7,#0x00
      0071C5                       1228 00205$:
                                   1229 ;	quantum/action.c:640: bits |= mask;
      0071C5 EE               [12] 1230 	mov	a,r6
      0071C6 42 07            [12] 1231 	orl	ar7,a
                                   1232 ;	quantum/action.c:641: if (!on) {
      0071C8 90 08 32         [24] 1233 	mov	dptr,#_process_action_on_40000_669
      0071CB E0               [24] 1234 	movx	a,@dptr
      0071CC 70 31            [24] 1235 	jnz	00143$
                                   1236 ;	quantum/action.c:642: switch (action.layer_bitop.op) {
      0071CE 12 74 D6         [24] 1237 	lcall	_ak820_outline_0086
      0071D1 FE               [12] 1238 	mov	r6,a
      0071D2 2E               [12] 1239 	add	a,r6
                                   1240 ;	quantum/action.c:643: case OP_BIT_AND: default_layer_and(bits); break;
      0071D3 90 71 D7         [24] 1241 	mov	dptr,#00465$
      0071D6 73               [24] 1242 	jmp	@a+dptr
      0071D7                       1243 00465$:
      0071D7 80 06            [24] 1244 	sjmp	00132$
      0071D9 80 0C            [24] 1245 	sjmp	00133$
      0071DB 80 12            [24] 1246 	sjmp	00134$
      0071DD 80 18            [24] 1247 	sjmp	00135$
      0071DF                       1248 00132$:
      0071DF 8F 82            [24] 1249 	mov	dpl, r7
      0071E1 12 75 4C         [24] 1250 	lcall	_default_layer_and
      0071E4 02 72 C9         [24] 1251 	ljmp	00181$
                                   1252 ;	quantum/action.c:644: case OP_BIT_OR: default_layer_or(bits); break;
      0071E7                       1253 00133$:
      0071E7 8F 82            [24] 1254 	mov	dpl, r7
      0071E9 12 75 3B         [24] 1255 	lcall	_default_layer_or
      0071EC 02 72 C9         [24] 1256 	ljmp	00181$
                                   1257 ;	quantum/action.c:645: case OP_BIT_XOR: default_layer_xor(bits); break;
      0071EF                       1258 00134$:
      0071EF 8F 82            [24] 1259 	mov	dpl, r7
      0071F1 12 75 62         [24] 1260 	lcall	_default_layer_xor
      0071F4 02 72 C9         [24] 1261 	ljmp	00181$
                                   1262 ;	quantum/action.c:646: case OP_BIT_SET: default_layer_set(bits); break;
      0071F7                       1263 00135$:
      0071F7 8F 82            [24] 1264 	mov	dpl, r7
      0071F9 12 75 30         [24] 1265 	lcall	_default_layer_set
                                   1266 ;	quantum/action.c:647: }
      0071FC 02 72 C9         [24] 1267 	ljmp	00181$
      0071FF                       1268 00143$:
                                   1269 ;	quantum/action.c:649: switch (action.layer_bitop.op) {
      0071FF 12 74 D6         [24] 1270 	lcall	_ak820_outline_0086
      007202 FE               [12] 1271 	mov	r6,a
      007203 2E               [12] 1272 	add	a,r6
                                   1273 ;	quantum/action.c:650: case OP_BIT_AND: layer_and(bits); break;
      007204 90 72 08         [24] 1274 	mov	dptr,#00466$
      007207 73               [24] 1275 	jmp	@a+dptr
      007208                       1276 00466$:
      007208 80 06            [24] 1277 	sjmp	00137$
      00720A 80 0C            [24] 1278 	sjmp	00138$
      00720C 80 12            [24] 1279 	sjmp	00139$
      00720E 80 18            [24] 1280 	sjmp	00140$
      007210                       1281 00137$:
      007210 8F 82            [24] 1282 	mov	dpl, r7
      007212 12 76 E6         [24] 1283 	lcall	_layer_and
      007215 02 72 C9         [24] 1284 	ljmp	00181$
                                   1285 ;	quantum/action.c:651: case OP_BIT_OR: layer_or(bits); break;
      007218                       1286 00138$:
      007218 8F 82            [24] 1287 	mov	dpl, r7
      00721A 12 76 D5         [24] 1288 	lcall	_layer_or
      00721D 02 72 C9         [24] 1289 	ljmp	00181$
                                   1290 ;	quantum/action.c:652: case OP_BIT_XOR: layer_xor(bits); break;
      007220                       1291 00139$:
      007220 8F 82            [24] 1292 	mov	dpl, r7
      007222 12 76 FC         [24] 1293 	lcall	_layer_xor
      007225 02 72 C9         [24] 1294 	ljmp	00181$
                                   1295 ;	quantum/action.c:653: case OP_BIT_SET: layer_state_set(bits); break;
      007228                       1296 00140$:
      007228 8F 82            [24] 1297 	mov	dpl, r7
      00722A 12 76 72         [24] 1298 	lcall	_layer_state_set
                                   1299 ;	quantum/action.c:657: break;
      00722D 02 72 C9         [24] 1300 	ljmp	00181$
                                   1301 ;	quantum/action.c:659: case ACT_LAYER_MODS:
      007230                       1302 00147$:
                                   1303 ;	quantum/action.c:660: if (pressed) {
      007230 E5 27            [12] 1304 	mov	a,_process_action_sloc0_1_0
      007232 60 11            [24] 1305 	jz	00149$
                                   1306 ;	quantum/action.c:661: layer_hold_on(action.layer_mods.layer);
      007234 12 74 DF         [24] 1307 	lcall	_ak820_outline_0107
      007237 F5 82            [12] 1308 	mov	dpl,a
      007239 12 75 D2         [24] 1309 	lcall	_layer_hold_on
                                   1310 ;	quantum/action.c:662: register_mods(action.layer_mods.mods);
      00723C 12 74 CF         [24] 1311 	lcall	_ak820_outline_0076
      00723F 12 74 03         [24] 1312 	lcall	_register_mods
      007242 02 72 C9         [24] 1313 	ljmp	00181$
      007245                       1314 00149$:
                                   1315 ;	quantum/action.c:664: unregister_mods(action.layer_mods.mods);
      007245 12 74 CF         [24] 1316 	lcall	_ak820_outline_0076
      007248 12 74 17         [24] 1317 	lcall	_unregister_mods
                                   1318 ;	quantum/action.c:665: layer_hold_off(action.layer_mods.layer);
      00724B 12 74 DF         [24] 1319 	lcall	_ak820_outline_0107
      00724E F5 82            [12] 1320 	mov	dpl,a
      007250 12 76 0A         [24] 1321 	lcall	_layer_hold_off
                                   1322 ;	quantum/action.c:667: break;
      007253 02 72 C9         [24] 1323 	ljmp	00181$
                                   1324 ;	quantum/action.c:669: case ACT_LAYER_TAP_EXT:
      007256                       1325 00152$:
                                   1326 ;	quantum/action.c:670: switch (action.layer_tap.code) {
      007256 12 74 F1         [24] 1327 	lcall	_ak820_outline_0155
      007259 FF               [12] 1328 	mov	r7,a
      00725A BF F1 02         [24] 1329 	cjne	r7,#0xf1,00468$
      00725D 80 0A            [24] 1330 	sjmp	00154$
      00725F                       1331 00468$:
      00725F BF F2 02         [24] 1332 	cjne	r7,#0xf2,00469$
      007262 80 19            [24] 1333 	sjmp	00155$
      007264                       1334 00469$:
                                   1335 ;	quantum/action.c:686: momentary_layer_action:
      007264 BF F3 3B         [24] 1336 	cjne	r7,#0xf3,00160$
      007267 80 28            [24] 1337 	sjmp	00156$
      007269                       1338 00154$:
                                   1339 ;	quantum/action.c:687: pressed ? layer_hold_on(action.layer_tap.val) : layer_hold_off(action.layer_tap.val);
      007269 E5 27            [12] 1340 	mov	a,_process_action_sloc0_1_0
      00726B 60 08            [24] 1341 	jz	00206$
      00726D 12 74 B5         [24] 1342 	lcall	_ak820_outline_0041
      007270 12 75 D2         [24] 1343 	lcall	_layer_hold_on
      007273 80 54            [24] 1344 	sjmp	00181$
      007275                       1345 00206$:
      007275 12 74 B5         [24] 1346 	lcall	_ak820_outline_0041
      007278 12 76 0A         [24] 1347 	lcall	_layer_hold_off
                                   1348 ;	quantum/action.c:688: break;
                                   1349 ;	quantum/action.c:689: case OP_OFF_ON:
      00727B 80 4C            [24] 1350 	sjmp	00181$
      00727D                       1351 00155$:
                                   1352 ;	quantum/action.c:690: pressed ? layer_off(action.layer_tap.val) : layer_on(action.layer_tap.val);
      00727D E5 27            [12] 1353 	mov	a,_process_action_sloc0_1_0
      00727F 60 08            [24] 1354 	jz	00208$
      007281 12 74 B5         [24] 1355 	lcall	_ak820_outline_0041
      007284 12 76 B7         [24] 1356 	lcall	_layer_off
      007287 80 40            [24] 1357 	sjmp	00181$
      007289                       1358 00208$:
      007289 12 74 B5         [24] 1359 	lcall	_ak820_outline_0041
      00728C 12 76 9C         [24] 1360 	lcall	_layer_on
                                   1361 ;	quantum/action.c:691: break;
                                   1362 ;	quantum/action.c:692: case OP_SET_CLEAR:
      00728F 80 38            [24] 1363 	sjmp	00181$
      007291                       1364 00156$:
                                   1365 ;	quantum/action.c:693: pressed ? layer_move(action.layer_tap.val) : layer_clear();
      007291 E5 27            [12] 1366 	mov	a,_process_action_sloc0_1_0
      007293 60 08            [24] 1367 	jz	00210$
      007295 12 74 B5         [24] 1368 	lcall	_ak820_outline_0041
      007298 12 76 86         [24] 1369 	lcall	_layer_move
      00729B 80 2C            [24] 1370 	sjmp	00181$
      00729D                       1371 00210$:
      00729D 12 76 80         [24] 1372 	lcall	_layer_clear
                                   1373 ;	quantum/action.c:694: break;
                                   1374 ;	quantum/action.c:740: default:
      0072A0 80 27            [24] 1375 	sjmp	00181$
      0072A2                       1376 00160$:
                                   1377 ;	quantum/action.c:747: if (pressed) {
      0072A2 E5 27            [12] 1378 	mov	a,_process_action_sloc0_1_0
      0072A4 60 08            [24] 1379 	jz	00163$
                                   1380 ;	quantum/action.c:749: register_code(action.layer_tap.code);
      0072A6 12 74 CF         [24] 1381 	lcall	_ak820_outline_0076
      0072A9 12 72 E0         [24] 1382 	lcall	_register_code
                                   1383 ;	quantum/action.c:751: ac_dprintf("KEYMAP_TAP_KEY: Tap: unregister_code\n");
      0072AC 80 1B            [24] 1384 	sjmp	00181$
      0072AE                       1385 00163$:
                                   1386 ;	quantum/action.c:752: if (action.layer_tap.code == KC_CAPS) {
      0072AE 12 74 F1         [24] 1387 	lcall	_ak820_outline_0155
      0072B1 FF               [12] 1388 	mov	r7,a
      0072B2 BF 39 0E         [24] 1389 	cjne	r7,#0x39,00175$
                                   1390 ;	quantum/action.c:753: wait_ms(TAP_HOLD_CAPS_DELAY);
      0072B5 7F 50            [12] 1391 	mov	r7,#0x50
      0072B7                       1392 00187$:
      0072B7 EF               [12] 1393 	mov	a,r7
      0072B8 60 09            [24] 1394 	jz	00175$
      0072BA 90 00 01         [24] 1395 	mov	dptr,#0x0001
      0072BD 12 57 69         [24] 1396 	lcall	_mDelaymS
      0072C0 1F               [12] 1397 	dec	r7
                                   1398 ;	quantum/action.c:755: wait_ms(TAP_CODE_DELAY);
      0072C1 80 F4            [24] 1399 	sjmp	00187$
      0072C3                       1400 00175$:
                                   1401 ;	quantum/action.c:757: unregister_code(action.layer_tap.code);
      0072C3 12 74 CF         [24] 1402 	lcall	_ak820_outline_0076
      0072C6 12 73 4D         [24] 1403 	lcall	_unregister_code
                                   1404 ;	quantum/action.c:840: }
      0072C9                       1405 00181$:
                                   1406 ;	quantum/action.c:861: switch (action.kind.id) {
      0072C9 90 08 2E         [24] 1407 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0072CC E0               [24] 1408 	movx	a,@dptr
      0072CD C4               [12] 1409 	swap	a
      0072CE 54 0F            [12] 1410 	anl	a,#0x0f
      0072D0 FF               [12] 1411 	mov	r7,a
      0072D1 BF 08 02         [24] 1412 	cjne	r7,#0x08,00478$
      0072D4 80 03            [24] 1413 	sjmp	00183$
      0072D6                       1414 00478$:
      0072D6 BF 09 06         [24] 1415 	cjne	r7,#0x09,00192$
                                   1416 ;	quantum/action.c:863: case ACT_LAYER_MODS:
      0072D9                       1417 00183$:
                                   1418 ;	quantum/action.c:868: led_set(host_keyboard_leds());
      0072D9 12 6A F4         [24] 1419 	lcall	_host_keyboard_leds
                                   1420 ;	quantum/action.c:872: }
                                   1421 ;	quantum/action.c:925: }
      0072DC 02 94 F0         [24] 1422 	ljmp	_led_set
      0072DF                       1423 00192$:
      0072DF 22               [24] 1424 	ret
                                   1425 ;------------------------------------------------------------
                                   1426 ;Allocation info for local variables in function 'register_code'
                                   1427 ;------------------------------------------------------------
                                   1428 ;code          Allocated with name '_register_code_code_10000_703'
                                   1429 ;------------------------------------------------------------
                                   1430 ;	quantum/action.c:931: __attribute__((weak)) void register_code(uint8_t code) {
                                   1431 ;	-----------------------------------------
                                   1432 ;	 function register_code
                                   1433 ;	-----------------------------------------
      0072E0                       1434 _register_code:
      0072E0 E5 82            [12] 1435 	mov	a,dpl
      0072E2 90 08 33         [24] 1436 	mov	dptr,#_register_code_code_10000_703
      0072E5 F0               [24] 1437 	movx	@dptr,a
                                   1438 ;	quantum/action.c:932: if (code == KC_NO) {
      0072E6 E0               [24] 1439 	movx	a,@dptr
      0072E7 FF               [12] 1440 	mov	r7,a
      0072E8 70 01            [24] 1441 	jnz	00123$
                                   1442 ;	quantum/action.c:933: return;
      0072EA 22               [24] 1443 	ret
      0072EB                       1444 00123$:
                                   1445 ;	quantum/action.c:968: } else if (IS_BASIC_KEYCODE(code)) {
      0072EB BF 04 00         [24] 1446 	cjne	r7,#0x04,00186$
      0072EE                       1447 00186$:
      0072EE 40 12            [24] 1448 	jc	00119$
      0072F0 EF               [12] 1449 	mov	a,r7
      0072F1 24 5B            [12] 1450 	add	a,#0xff - 0xa4
      0072F3 40 0D            [24] 1451 	jc	00119$
                                   1452 ;	free result
                                   1453 ;	quantum/action.c:973: if (!add_owned_key(code)) return;
      0072F5 8F 82            [24] 1454 	mov	dpl, r7
      0072F7 12 7A FC         [24] 1455 	lcall	_add_owned_key
      0072FA E5 82            [12] 1456 	mov	a, dpl
      0072FC 70 01            [24] 1457 	jnz	00104$
      0072FE 22               [24] 1458 	ret
      0072FF                       1459 00104$:
                                   1460 ;	quantum/action.c:987: send_keyboard_report();
      0072FF 02 7D 9C         [24] 1461 	ljmp	_send_keyboard_report
      007302                       1462 00119$:
                                   1463 ;	quantum/action.c:988: } else if (IS_MODIFIER_KEYCODE(code)) {
      007302 12 74 F6         [24] 1464 	lcall	_ak820_outline_0163
      007305 BF E0 00         [24] 1465 	cjne	r7,#0xe0,00190$
      007308                       1466 00190$:
      007308 40 1A            [24] 1467 	jc	00115$
      00730A EF               [12] 1468 	mov	a,r7
      00730B 24 18            [12] 1469 	add	a,#0xff - 0xe7
      00730D 40 15            [24] 1470 	jc	00115$
                                   1471 ;	free result
                                   1472 ;	quantum/action.c:989: add_owned_mods(MOD_BIT(code));
      00730F 74 07            [12] 1473 	mov	a,#0x07
      007311 5F               [12] 1474 	anl	a,r7
      007312 12 74 BE         [24] 1475 	lcall	_ak820_outline_0063
      007315 80 02            [24] 1476 	sjmp	00194$
      007317                       1477 00193$:
      007317 25 E0            [12] 1478 	add	a,acc
      007319                       1479 00194$:
      007319 D5 F0 FB         [24] 1480 	djnz	b,00193$
      00731C F5 82            [12] 1481 	mov	dpl,a
      00731E 12 7A 58         [24] 1482 	lcall	_add_owned_mods
                                   1483 ;	quantum/action.c:990: send_keyboard_report();
      007321 02 7D 9C         [24] 1484 	ljmp	_send_keyboard_report
      007324                       1485 00115$:
                                   1486 ;	quantum/action.c:993: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      007324 12 74 F6         [24] 1487 	lcall	_ak820_outline_0163
      007327 BF A5 00         [24] 1488 	cjne	r7,#0xa5,00195$
      00732A                       1489 00195$:
      00732A 40 05            [24] 1490 	jc	00113$
      00732C EF               [12] 1491 	mov	a,r7
      00732D 24 58            [12] 1492 	add	a,#0xff - 0xa7
      00732F 50 0D            [24] 1493 	jnc	00108$
                                   1494 ;	free result
      007331                       1495 00113$:
      007331 12 74 F6         [24] 1496 	lcall	_ak820_outline_0163
      007334 BF A8 00         [24] 1497 	cjne	r7,#0xa8,00198$
      007337                       1498 00198$:
      007337 40 13            [24] 1499 	jc	00125$
      007339 EF               [12] 1500 	mov	a,r7
      00733A 24 3D            [12] 1501 	add	a,#0xff - 0xc2
      00733C 40 0E            [24] 1502 	jc	00125$
                                   1503 ;	free result
      00733E                       1504 00108$:
                                   1505 ;	quantum/action.c:995: owned_usage_key(code, true);
      00733E 12 74 F6         [24] 1506 	lcall	_ak820_outline_0163
      007341 90 0A 8E         [24] 1507 	mov	dptr,#_owned_usage_key_PARM_2
      007344 74 01            [12] 1508 	mov	a,#0x01
      007346 F0               [24] 1509 	movx	@dptr,a
      007347 8F 82            [24] 1510 	mov	dpl, r7
                                   1511 ;	quantum/action.c:1003: register_mouse(code, true);
                                   1512 ;	quantum/action.c:1005: }
      007349 02 7C 47         [24] 1513 	ljmp	_owned_usage_key
      00734C                       1514 00125$:
      00734C 22               [24] 1515 	ret
                                   1516 ;------------------------------------------------------------
                                   1517 ;Allocation info for local variables in function 'unregister_code'
                                   1518 ;------------------------------------------------------------
                                   1519 ;code          Allocated with name '_unregister_code_code_10000_717'
                                   1520 ;------------------------------------------------------------
                                   1521 ;	quantum/action.c:1011: __attribute__((weak)) void unregister_code(uint8_t code) {
                                   1522 ;	-----------------------------------------
                                   1523 ;	 function unregister_code
                                   1524 ;	-----------------------------------------
      00734D                       1525 _unregister_code:
      00734D E5 82            [12] 1526 	mov	a,dpl
      00734F 90 08 34         [24] 1527 	mov	dptr,#_unregister_code_code_10000_717
      007352 F0               [24] 1528 	movx	@dptr,a
                                   1529 ;	quantum/action.c:1012: if (code == KC_NO) {
      007353 E0               [24] 1530 	movx	a,@dptr
      007354 FF               [12] 1531 	mov	r7,a
      007355 70 01            [24] 1532 	jnz	00121$
                                   1533 ;	quantum/action.c:1013: return;
      007357 22               [24] 1534 	ret
      007358                       1535 00121$:
                                   1536 ;	quantum/action.c:1045: } else if (IS_BASIC_KEYCODE(code)) {
      007358 BF 04 00         [24] 1537 	cjne	r7,#0x04,00184$
      00735B                       1538 00184$:
      00735B 40 12            [24] 1539 	jc	00117$
      00735D EF               [12] 1540 	mov	a,r7
      00735E 24 5B            [12] 1541 	add	a,#0xff - 0xa4
      007360 40 0D            [24] 1542 	jc	00117$
                                   1543 ;	free result
                                   1544 ;	quantum/action.c:1047: if (!del_owned_key(code)) return;
      007362 8F 82            [24] 1545 	mov	dpl, r7
      007364 12 7B 79         [24] 1546 	lcall	_del_owned_key
      007367 E5 82            [12] 1547 	mov	a, dpl
      007369 70 01            [24] 1548 	jnz	00102$
      00736B 22               [24] 1549 	ret
      00736C                       1550 00102$:
                                   1551 ;	quantum/action.c:1054: send_keyboard_report();
      00736C 02 7D 9C         [24] 1552 	ljmp	_send_keyboard_report
      00736F                       1553 00117$:
                                   1554 ;	quantum/action.c:1055: } else if (IS_MODIFIER_KEYCODE(code)) {
      00736F 12 74 FC         [24] 1555 	lcall	_ak820_outline_0164
      007372 BF E0 00         [24] 1556 	cjne	r7,#0xe0,00188$
      007375                       1557 00188$:
      007375 40 1A            [24] 1558 	jc	00113$
      007377 EF               [12] 1559 	mov	a,r7
      007378 24 18            [12] 1560 	add	a,#0xff - 0xe7
      00737A 40 15            [24] 1561 	jc	00113$
                                   1562 ;	free result
                                   1563 ;	quantum/action.c:1056: del_owned_mods(MOD_BIT(code));
      00737C 74 07            [12] 1564 	mov	a,#0x07
      00737E 5F               [12] 1565 	anl	a,r7
      00737F 12 74 BE         [24] 1566 	lcall	_ak820_outline_0063
      007382 80 02            [24] 1567 	sjmp	00192$
      007384                       1568 00191$:
      007384 25 E0            [12] 1569 	add	a,acc
      007386                       1570 00192$:
      007386 D5 F0 FB         [24] 1571 	djnz	b,00191$
      007389 F5 82            [12] 1572 	mov	dpl,a
      00738B 12 7A 68         [24] 1573 	lcall	_del_owned_mods
                                   1574 ;	quantum/action.c:1057: send_keyboard_report();
      00738E 02 7D 9C         [24] 1575 	ljmp	_send_keyboard_report
      007391                       1576 00113$:
                                   1577 ;	quantum/action.c:1060: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      007391 12 74 FC         [24] 1578 	lcall	_ak820_outline_0164
      007394 BF A5 00         [24] 1579 	cjne	r7,#0xa5,00193$
      007397                       1580 00193$:
      007397 40 05            [24] 1581 	jc	00111$
      007399 EF               [12] 1582 	mov	a,r7
      00739A 24 58            [12] 1583 	add	a,#0xff - 0xa7
      00739C 50 0D            [24] 1584 	jnc	00106$
                                   1585 ;	free result
      00739E                       1586 00111$:
      00739E 12 74 FC         [24] 1587 	lcall	_ak820_outline_0164
      0073A1 BF A8 00         [24] 1588 	cjne	r7,#0xa8,00196$
      0073A4                       1589 00196$:
      0073A4 40 12            [24] 1590 	jc	00123$
      0073A6 EF               [12] 1591 	mov	a,r7
      0073A7 24 3D            [12] 1592 	add	a,#0xff - 0xc2
      0073A9 40 0D            [24] 1593 	jc	00123$
                                   1594 ;	free result
      0073AB                       1595 00106$:
                                   1596 ;	quantum/action.c:1062: owned_usage_key(code, false);
      0073AB 12 74 FC         [24] 1597 	lcall	_ak820_outline_0164
      0073AE 90 0A 8E         [24] 1598 	mov	dptr,#_owned_usage_key_PARM_2
      0073B1 E4               [12] 1599 	clr	a
      0073B2 F0               [24] 1600 	movx	@dptr,a
      0073B3 8F 82            [24] 1601 	mov	dpl, r7
                                   1602 ;	quantum/action.c:1070: register_mouse(code, false);
                                   1603 ;	quantum/action.c:1072: }
      0073B5 02 7C 47         [24] 1604 	ljmp	_owned_usage_key
      0073B8                       1605 00123$:
      0073B8 22               [24] 1606 	ret
                                   1607 ;------------------------------------------------------------
                                   1608 ;Allocation info for local variables in function 'tap_code_delay'
                                   1609 ;------------------------------------------------------------
                                   1610 ;delay         Allocated with name '_tap_code_delay_PARM_2'
                                   1611 ;code          Allocated with name '_tap_code_delay_code_10000_730'
                                   1612 ;i             Allocated with name '_tap_code_delay_i_20000_732'
                                   1613 ;i             Allocated with name '_tap_code_delay_i_50000_735'
                                   1614 ;------------------------------------------------------------
                                   1615 ;	quantum/action.c:1079: __attribute__((weak)) void tap_code_delay(uint8_t code, uint16_t delay) {
                                   1616 ;	-----------------------------------------
                                   1617 ;	 function tap_code_delay
                                   1618 ;	-----------------------------------------
      0073B9                       1619 _tap_code_delay:
      0073B9 E5 82            [12] 1620 	mov	a,dpl
      0073BB 90 08 37         [24] 1621 	mov	dptr,#_tap_code_delay_code_10000_730
      0073BE F0               [24] 1622 	movx	@dptr,a
                                   1623 ;	quantum/action.c:1080: register_code(code);
      0073BF E0               [24] 1624 	movx	a,@dptr
      0073C0 FF               [12] 1625 	mov	r7,a
      0073C1 F5 82            [12] 1626 	mov	dpl,a
      0073C3 C0 07            [24] 1627 	push	ar7
      0073C5 12 72 E0         [24] 1628 	lcall	_register_code
      0073C8 D0 07            [24] 1629 	pop	ar7
                                   1630 ;	quantum/action.c:1081: for (uint16_t i = delay; i > 0; i--) {
      0073CA 90 08 35         [24] 1631 	mov	dptr,#_tap_code_delay_PARM_2
      0073CD 12 38 71         [24] 1632 	lcall	_ak820_outline_0093
      0073D0                       1633 00110$:
      0073D0 ED               [12] 1634 	mov	a,r5
      0073D1 4E               [12] 1635 	orl	a,r6
      0073D2 60 0D            [24] 1636 	jz	00105$
                                   1637 ;	quantum/action.c:1082: wait_ms(1);
      0073D4 90 00 01         [24] 1638 	mov	dptr,#0x0001
      0073D7 12 57 69         [24] 1639 	lcall	_mDelaymS
                                   1640 ;	quantum/action.c:1081: for (uint16_t i = delay; i > 0; i--) {
      0073DA 1D               [12] 1641 	dec	r5
      0073DB BD FF 01         [24] 1642 	cjne	r5,#0xff,00141$
      0073DE 1E               [12] 1643 	dec	r6
      0073DF                       1644 00141$:
      0073DF 80 EF            [24] 1645 	sjmp	00110$
      0073E1                       1646 00105$:
                                   1647 ;	quantum/action.c:1084: unregister_code(code);
      0073E1 8F 82            [24] 1648 	mov	dpl, r7
                                   1649 ;	quantum/action.c:1085: }
      0073E3 02 73 4D         [24] 1650 	ljmp	_unregister_code
                                   1651 ;------------------------------------------------------------
                                   1652 ;Allocation info for local variables in function 'tap_code'
                                   1653 ;------------------------------------------------------------
                                   1654 ;code          Allocated with name '_tap_code_code_10000_737'
                                   1655 ;------------------------------------------------------------
                                   1656 ;	quantum/action.c:1091: __attribute__((weak)) void tap_code(uint8_t code) {
                                   1657 ;	-----------------------------------------
                                   1658 ;	 function tap_code
                                   1659 ;	-----------------------------------------
      0073E6                       1660 _tap_code:
      0073E6 E5 82            [12] 1661 	mov	a,dpl
      0073E8 90 08 38         [24] 1662 	mov	dptr,#_tap_code_code_10000_737
      0073EB F0               [24] 1663 	movx	@dptr,a
                                   1664 ;	quantum/action.c:1092: tap_code_delay(code, code == KC_CAPS ? QS_tap_hold_caps_delay : QS_tap_code_delay);
      0073EC E0               [24] 1665 	movx	a,@dptr
      0073ED FF               [12] 1666 	mov	r7,a
      0073EE BF 39 04         [24] 1667 	cjne	r7,#0x39,00103$
      0073F1 7E 50            [12] 1668 	mov	r6,#0x50
      0073F3 80 02            [24] 1669 	sjmp	00104$
      0073F5                       1670 00103$:
      0073F5 7E 00            [12] 1671 	mov	r6,#0x00
      0073F7                       1672 00104$:
      0073F7 90 08 35         [24] 1673 	mov	dptr,#_tap_code_delay_PARM_2
      0073FA EE               [12] 1674 	mov	a,r6
      0073FB 12 38 97         [24] 1675 	lcall	_ak820_outline_0122
      0073FE 8F 82            [24] 1676 	mov	dpl, r7
                                   1677 ;	quantum/action.c:1093: }
      007400 02 73 B9         [24] 1678 	ljmp	_tap_code_delay
                                   1679 ;------------------------------------------------------------
                                   1680 ;Allocation info for local variables in function 'register_mods'
                                   1681 ;------------------------------------------------------------
                                   1682 ;mods          Allocated with name '_register_mods_mods_10000_739'
                                   1683 ;------------------------------------------------------------
                                   1684 ;	quantum/action.c:1099: __attribute__((weak)) void register_mods(uint8_t mods) {
                                   1685 ;	-----------------------------------------
                                   1686 ;	 function register_mods
                                   1687 ;	-----------------------------------------
      007403                       1688 _register_mods:
      007403 E5 82            [12] 1689 	mov	a,dpl
      007405 90 08 39         [24] 1690 	mov	dptr,#_register_mods_mods_10000_739
      007408 F0               [24] 1691 	movx	@dptr,a
                                   1692 ;	quantum/action.c:1100: if (mods) {
      007409 E0               [24] 1693 	movx	a,@dptr
      00740A FF               [12] 1694 	mov	r7,a
      00740B E0               [24] 1695 	movx	a,@dptr
      00740C 60 08            [24] 1696 	jz	00103$
                                   1697 ;	quantum/action.c:1101: add_owned_mods(mods);
      00740E 8F 82            [24] 1698 	mov	dpl, r7
      007410 12 7A 58         [24] 1699 	lcall	_add_owned_mods
                                   1700 ;	quantum/action.c:1102: send_keyboard_report();
                                   1701 ;	quantum/action.c:1104: }
      007413 02 7D 9C         [24] 1702 	ljmp	_send_keyboard_report
      007416                       1703 00103$:
      007416 22               [24] 1704 	ret
                                   1705 ;------------------------------------------------------------
                                   1706 ;Allocation info for local variables in function 'unregister_mods'
                                   1707 ;------------------------------------------------------------
                                   1708 ;mods          Allocated with name '_unregister_mods_mods_10000_743'
                                   1709 ;------------------------------------------------------------
                                   1710 ;	quantum/action.c:1110: __attribute__((weak)) void unregister_mods(uint8_t mods) {
                                   1711 ;	-----------------------------------------
                                   1712 ;	 function unregister_mods
                                   1713 ;	-----------------------------------------
      007417                       1714 _unregister_mods:
      007417 E5 82            [12] 1715 	mov	a,dpl
      007419 90 08 3A         [24] 1716 	mov	dptr,#_unregister_mods_mods_10000_743
      00741C F0               [24] 1717 	movx	@dptr,a
                                   1718 ;	quantum/action.c:1111: if (mods) {
      00741D E0               [24] 1719 	movx	a,@dptr
      00741E FF               [12] 1720 	mov	r7,a
      00741F E0               [24] 1721 	movx	a,@dptr
      007420 60 08            [24] 1722 	jz	00103$
                                   1723 ;	quantum/action.c:1112: del_owned_mods(mods);
      007422 8F 82            [24] 1724 	mov	dpl, r7
      007424 12 7A 68         [24] 1725 	lcall	_del_owned_mods
                                   1726 ;	quantum/action.c:1113: send_keyboard_report();
                                   1727 ;	quantum/action.c:1115: }
      007427 02 7D 9C         [24] 1728 	ljmp	_send_keyboard_report
      00742A                       1729 00103$:
      00742A 22               [24] 1730 	ret
                                   1731 ;------------------------------------------------------------
                                   1732 ;Allocation info for local variables in function 'register_weak_mods'
                                   1733 ;------------------------------------------------------------
                                   1734 ;mods          Allocated with name '_register_weak_mods_mods_10000_747'
                                   1735 ;------------------------------------------------------------
                                   1736 ;	quantum/action.c:1121: __attribute__((weak)) void register_weak_mods(uint8_t mods) {
                                   1737 ;	-----------------------------------------
                                   1738 ;	 function register_weak_mods
                                   1739 ;	-----------------------------------------
      00742B                       1740 _register_weak_mods:
      00742B E5 82            [12] 1741 	mov	a,dpl
      00742D 90 08 3B         [24] 1742 	mov	dptr,#_register_weak_mods_mods_10000_747
      007430 F0               [24] 1743 	movx	@dptr,a
                                   1744 ;	quantum/action.c:1122: if (mods) {
      007431 E0               [24] 1745 	movx	a,@dptr
      007432 FF               [12] 1746 	mov	r7,a
      007433 E0               [24] 1747 	movx	a,@dptr
      007434 60 08            [24] 1748 	jz	00103$
                                   1749 ;	quantum/action.c:1123: add_owned_weak_mods(mods);
      007436 8F 82            [24] 1750 	mov	dpl, r7
      007438 12 7A 77         [24] 1751 	lcall	_add_owned_weak_mods
                                   1752 ;	quantum/action.c:1124: send_keyboard_report();
                                   1753 ;	quantum/action.c:1126: }
      00743B 02 7D 9C         [24] 1754 	ljmp	_send_keyboard_report
      00743E                       1755 00103$:
      00743E 22               [24] 1756 	ret
                                   1757 ;------------------------------------------------------------
                                   1758 ;Allocation info for local variables in function 'unregister_weak_mods'
                                   1759 ;------------------------------------------------------------
                                   1760 ;mods          Allocated with name '_unregister_weak_mods_mods_10000_751'
                                   1761 ;------------------------------------------------------------
                                   1762 ;	quantum/action.c:1132: __attribute__((weak)) void unregister_weak_mods(uint8_t mods) {
                                   1763 ;	-----------------------------------------
                                   1764 ;	 function unregister_weak_mods
                                   1765 ;	-----------------------------------------
      00743F                       1766 _unregister_weak_mods:
      00743F E5 82            [12] 1767 	mov	a,dpl
      007441 90 08 3C         [24] 1768 	mov	dptr,#_unregister_weak_mods_mods_10000_751
      007444 F0               [24] 1769 	movx	@dptr,a
                                   1770 ;	quantum/action.c:1133: if (mods) {
      007445 E0               [24] 1771 	movx	a,@dptr
      007446 FF               [12] 1772 	mov	r7,a
      007447 E0               [24] 1773 	movx	a,@dptr
      007448 60 08            [24] 1774 	jz	00103$
                                   1775 ;	quantum/action.c:1134: del_owned_weak_mods(mods);
      00744A 8F 82            [24] 1776 	mov	dpl, r7
      00744C 12 7A 87         [24] 1777 	lcall	_del_owned_weak_mods
                                   1778 ;	quantum/action.c:1135: send_keyboard_report();
                                   1779 ;	quantum/action.c:1137: }
      00744F 02 7D 9C         [24] 1780 	ljmp	_send_keyboard_report
      007452                       1781 00103$:
      007452 22               [24] 1782 	ret
                                   1783 ;------------------------------------------------------------
                                   1784 ;Allocation info for local variables in function 'clear_keyboard'
                                   1785 ;------------------------------------------------------------
                                   1786 ;	quantum/action.c:1143: void clear_keyboard(void) {
                                   1787 ;	-----------------------------------------
                                   1788 ;	 function clear_keyboard
                                   1789 ;	-----------------------------------------
      007453                       1790 _clear_keyboard:
                                   1791 ;	quantum/action.c:1144: clear_mods();
      007453 12 7E 16         [24] 1792 	lcall	_clear_mods
                                   1793 ;	quantum/action.c:1145: clear_keyboard_but_mods();
                                   1794 ;	quantum/action.c:1146: }
      007456 02 74 59         [24] 1795 	ljmp	_clear_keyboard_but_mods
                                   1796 ;------------------------------------------------------------
                                   1797 ;Allocation info for local variables in function 'clear_keyboard_but_mods'
                                   1798 ;------------------------------------------------------------
                                   1799 ;	quantum/action.c:1152: void clear_keyboard_but_mods(void) {
                                   1800 ;	-----------------------------------------
                                   1801 ;	 function clear_keyboard_but_mods
                                   1802 ;	-----------------------------------------
      007459                       1803 _clear_keyboard_but_mods:
                                   1804 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007459 90 0D BF         [24] 1805 	mov	dptr,#_actual_keyboard_report
      00745C 75 F0 00         [24] 1806 	mov	b, #0x00
      00745F 12 6D CB         [24] 1807 	lcall	_clear_keys_from_report
                                   1808 ;	quantum/action.c:1154: clear_keyboard_but_mods_and_keys();
                                   1809 ;	quantum/action.c:1155: }
      007462 02 74 65         [24] 1810 	ljmp	_clear_keyboard_but_mods_and_keys
                                   1811 ;------------------------------------------------------------
                                   1812 ;Allocation info for local variables in function 'clear_keyboard_but_mods_and_keys'
                                   1813 ;------------------------------------------------------------
                                   1814 ;	quantum/action.c:1161: void clear_keyboard_but_mods_and_keys(void) {
                                   1815 ;	-----------------------------------------
                                   1816 ;	 function clear_keyboard_but_mods_and_keys
                                   1817 ;	-----------------------------------------
      007465                       1818 _clear_keyboard_but_mods_and_keys:
                                   1819 ;	quantum/action.c:1163: ak820_tapping_cancel();
      007465 12 46 CE         [24] 1820 	lcall	_ak820_tapping_cancel
                                   1821 ;	quantum/action.c:1174: ak820_combo_cancel();
      007468 12 35 70         [24] 1822 	lcall	_ak820_combo_cancel
                                   1823 ;	quantum/action.c:1177: repeat_key_cancel();
      00746B 12 9E F2         [24] 1824 	lcall	_repeat_key_cancel
                                   1825 ;	quantum/action.c:1179: clear_owned_mods();
      00746E 12 7A 97         [24] 1826 	lcall	_clear_owned_mods
                                   1827 ;	quantum/action.c:1180: clear_owned_keys();
      007471 12 7A CF         [24] 1828 	lcall	_clear_owned_keys
                                   1829 ;	quantum/action.c:1181: clear_owned_usages();
      007474 12 7C 0F         [24] 1830 	lcall	_clear_owned_usages
                                   1831 ;	quantum/action.c:1182: layer_hold_clear();
      007477 12 76 43         [24] 1832 	lcall	_layer_hold_clear
                                   1833 ;	quantum/action.c:1184: clear_macro_tri_layer();
      00747A 12 99 B6         [24] 1834 	lcall	_clear_macro_tri_layer
                                   1835 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      00747D 90 0D BF         [24] 1836 	mov	dptr,#_actual_keyboard_report
      007480 75 F0 00         [24] 1837 	mov	b, #0x00
      007483 12 6D CB         [24] 1838 	lcall	_clear_keys_from_report
                                   1839 ;	quantum/action.c:1189: host_system_send(0);
      007486 90 00 00         [24] 1840 	mov	dptr,#0x0000
      007489 12 6B 8F         [24] 1841 	lcall	_host_system_send
                                   1842 ;	quantum/action.c:1190: host_consumer_send(0);
      00748C 90 00 00         [24] 1843 	mov	dptr,#0x0000
      00748F 12 6B BF         [24] 1844 	lcall	_host_consumer_send
                                   1845 ;	quantum/action.c:1192: clear_weak_mods();
      007492 12 7E 4B         [24] 1846 	lcall	_clear_weak_mods
                                   1847 ;	quantum/action.c:1193: send_keyboard_report();
                                   1848 ;	quantum/action.c:1201: }
      007495 02 7D 9C         [24] 1849 	ljmp	_send_keyboard_report
                                   1850 ;------------------------------------------------------------
                                   1851 ;Allocation info for local variables in function 'is_tap_record'
                                   1852 ;------------------------------------------------------------
                                   1853 ;record        Allocated with name '_is_tap_record_record_10000_767'
                                   1854 ;action        Allocated with name '_is_tap_record_action_10001_771'
                                   1855 ;------------------------------------------------------------
                                   1856 ;	quantum/action.c:1207: bool is_tap_record(keyrecord_t *record) {
                                   1857 ;	-----------------------------------------
                                   1858 	.area CSEG    (CODE)
                                   1859 	.area CONST   (CODE)
                                   1860 	.area XINIT   (CODE)
      00BE71                       1861 __xinit__disable_action_cache:
      00BE71 00                    1862 	.db #0x00	;  0
                                   1863 	.area CABS    (ABS,CODE)
                                   1864 
                                   1865 ; Experimental exact instruction outlining.
                                   1866 	.globl _ak820_outline_0001
                                   1867 	.globl _ak820_outline_0005
                                   1868 	.globl _ak820_outline_0007
                                   1869 	.globl _ak820_outline_0008
                                   1870 	.globl _ak820_outline_0011
                                   1871 	.globl _ak820_outline_0012
                                   1872 	.globl _ak820_outline_0013
                                   1873 	.globl _ak820_outline_0015
                                   1874 	.globl _ak820_outline_0019
                                   1875 	.globl _ak820_outline_0020
                                   1876 	.globl _ak820_outline_0035
                                   1877 	.globl _ak820_outline_0041
                                   1878 	.globl _ak820_outline_0046
                                   1879 	.globl _ak820_outline_0050
                                   1880 	.globl _ak820_outline_0063
                                   1881 	.globl _ak820_outline_0070
                                   1882 	.globl _ak820_outline_0071
                                   1883 	.globl _ak820_outline_0076
                                   1884 	.globl _ak820_outline_0086
                                   1885 	.globl _ak820_outline_0090
                                   1886 	.globl _ak820_outline_0093
                                   1887 	.globl _ak820_outline_0107
                                   1888 	.globl _ak820_outline_0112
                                   1889 	.globl _ak820_outline_0113
                                   1890 	.globl _ak820_outline_0114
                                   1891 	.globl _ak820_outline_0120
                                   1892 	.globl _ak820_outline_0121
                                   1893 	.globl _ak820_outline_0122
                                   1894 	.globl _ak820_outline_0128
                                   1895 	.globl _ak820_outline_0138
                                   1896 	.globl _ak820_outline_0145
                                   1897 	.globl _ak820_outline_0155
                                   1898 	.globl _ak820_outline_0163
                                   1899 	.globl _ak820_outline_0164
                                   1900 	.globl _ak820_outline_0166
                                   1901 
                                   1902 	.area CSEG (CODE)
                                   1903 ; function ak820_outline_0012
      007498                       1904 _ak820_outline_0012:
      007498 2D               [12] 1905 	add	a,r5
      007499 FA               [12] 1906 	mov	r2,a
      00749A E4               [12] 1907 	clr	a
      00749B 3E               [12] 1908 	addc	a,r6
      00749C FB               [12] 1909 	mov	r3,a
      00749D 8F 04            [24] 1910 	mov	ar4,r7
      00749F 8A 82            [24] 1911 	mov	dpl,r2
      0074A1 8B 83            [24] 1912 	mov	dph,r3
      0074A3 8C F0            [24] 1913 	mov	b,r4
      0074A5 22               [24] 1914 	ret
                                   1915 
                                   1916 	.area CSEG (CODE)
                                   1917 ; function ak820_outline_0019
      0074A6                       1918 _ak820_outline_0019:
      0074A6 8E 82            [24] 1919 	mov	dpl,r6
      0074A8 8F 83            [24] 1920 	mov	dph,r7
      0074AA A3               [24] 1921 	inc	dptr
      0074AB E0               [24] 1922 	movx	a,@dptr
      0074AC FC               [12] 1923 	mov	r4,a
      0074AD 7D 00            [12] 1924 	mov	r5,#0x00
      0074AF 8E 82            [24] 1925 	mov	dpl,r6
      0074B1 8F 83            [24] 1926 	mov	dph,r7
      0074B3 E0               [24] 1927 	movx	a,@dptr
      0074B4 22               [24] 1928 	ret
                                   1929 
                                   1930 	.area CSEG (CODE)
                                   1931 ; function ak820_outline_0041
      0074B5                       1932 _ak820_outline_0041:
      0074B5 90 08 2E         [24] 1933 	mov	dptr,#(_process_action_PARM_2+0x0001)
      0074B8 E0               [24] 1934 	movx	a,@dptr
      0074B9 54 1F            [12] 1935 	anl	a,#0x1f
      0074BB F5 82            [12] 1936 	mov	dpl,a
      0074BD 22               [24] 1937 	ret
                                   1938 
                                   1939 	.area CSEG (CODE)
                                   1940 ; function ak820_outline_0063
      0074BE                       1941 _ak820_outline_0063:
      0074BE F5 F0            [12] 1942 	mov	b,a
      0074C0 05 F0            [12] 1943 	inc	b
      0074C2 74 01            [12] 1944 	mov	a,#0x01
      0074C4 22               [24] 1945 	ret
                                   1946 
                                   1947 	.area CSEG (CODE)
                                   1948 ; function ak820_outline_0070
      0074C5                       1949 _ak820_outline_0070:
      0074C5 90 0D 9E         [24] 1950 	mov	dptr,#___memcpy_PARM_3
      0074C8 74 06            [12] 1951 	mov	a,#0x06
      0074CA F0               [24] 1952 	movx	@dptr,a
      0074CB E4               [12] 1953 	clr	a
      0074CC A3               [24] 1954 	inc	dptr
      0074CD F0               [24] 1955 	movx	@dptr,a
      0074CE 22               [24] 1956 	ret
                                   1957 
                                   1958 	.area CSEG (CODE)
                                   1959 ; function ak820_outline_0076
      0074CF                       1960 _ak820_outline_0076:
      0074CF 90 08 2D         [24] 1961 	mov	dptr,#_process_action_PARM_2
      0074D2 E0               [24] 1962 	movx	a,@dptr
      0074D3 F5 82            [12] 1963 	mov	dpl,a
      0074D5 22               [24] 1964 	ret
                                   1965 
                                   1966 	.area CSEG (CODE)
                                   1967 ; function ak820_outline_0086
      0074D6                       1968 _ak820_outline_0086:
      0074D6 90 08 2E         [24] 1969 	mov	dptr,#(_process_action_PARM_2+0x0001)
      0074D9 E0               [24] 1970 	movx	a,@dptr
      0074DA 03               [12] 1971 	rr	a
      0074DB 03               [12] 1972 	rr	a
      0074DC 54 03            [12] 1973 	anl	a,#0x03
      0074DE 22               [24] 1974 	ret
                                   1975 
                                   1976 	.area CSEG (CODE)
                                   1977 ; function ak820_outline_0107
      0074DF                       1978 _ak820_outline_0107:
      0074DF 90 08 2E         [24] 1979 	mov	dptr,#(_process_action_PARM_2+0x0001)
      0074E2 E0               [24] 1980 	movx	a,@dptr
      0074E3 54 0F            [12] 1981 	anl	a,#0x0f
      0074E5 22               [24] 1982 	ret
                                   1983 
                                   1984 	.area CSEG (CODE)
                                   1985 ; function ak820_outline_0128
      0074E6                       1986 _ak820_outline_0128:
      0074E6 90 08 2D         [24] 1987 	mov	dptr,#_process_action_PARM_2
      0074E9 E0               [24] 1988 	movx	a,@dptr
      0074EA FE               [12] 1989 	mov	r6,a
      0074EB A3               [24] 1990 	inc	dptr
      0074EC E0               [24] 1991 	movx	a,@dptr
      0074ED 54 03            [12] 1992 	anl	a,#0x03
      0074EF FF               [12] 1993 	mov	r7,a
      0074F0 22               [24] 1994 	ret
                                   1995 
                                   1996 	.area CSEG (CODE)
                                   1997 ; function ak820_outline_0155
      0074F1                       1998 _ak820_outline_0155:
      0074F1 90 08 2D         [24] 1999 	mov	dptr,#_process_action_PARM_2
      0074F4 E0               [24] 2000 	movx	a,@dptr
      0074F5 22               [24] 2001 	ret
                                   2002 
                                   2003 	.area CSEG (CODE)
                                   2004 ; function ak820_outline_0163
      0074F6                       2005 _ak820_outline_0163:
      0074F6 90 08 33         [24] 2006 	mov	dptr,#_register_code_code_10000_703
      0074F9 E0               [24] 2007 	movx	a,@dptr
      0074FA FF               [12] 2008 	mov	r7,a
      0074FB 22               [24] 2009 	ret
                                   2010 
                                   2011 	.area CSEG (CODE)
                                   2012 ; function ak820_outline_0164
      0074FC                       2013 _ak820_outline_0164:
      0074FC 90 08 34         [24] 2014 	mov	dptr,#_unregister_code_code_10000_717
      0074FF E0               [24] 2015 	movx	a,@dptr
      007500 FF               [12] 2016 	mov	r7,a
      007501 22               [24] 2017 	ret
