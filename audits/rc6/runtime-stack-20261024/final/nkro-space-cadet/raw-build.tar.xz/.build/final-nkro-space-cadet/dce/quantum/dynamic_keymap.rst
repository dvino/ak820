                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module dynamic_keymap
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _dynamic_keymap_encoder_to_eeprom_address
                                     12 	.globl _ak820_combo_valid
                                     13 	.globl _ak820_eeprom_write_block_xdata
                                     14 	.globl _ak820_eeprom_read_block_xdata
                                     15 	.globl _ak820_nvm_flush
                                     16 	.globl _ak820_nvm_ok
                                     17 	.globl _ak820_macro_reset
                                     18 	.globl _ak820_macro_write
                                     19 	.globl _ak820_macro_length
                                     20 	.globl _ak820_macro_ready
                                     21 	.globl _send_char
                                     22 	.globl _keycode_at_encodermap_location_raw
                                     23 	.globl _keycode_at_keymap_location_raw
                                     24 	.globl _vial_keycode_tap
                                     25 	.globl _vial_keycode_up
                                     26 	.globl _vial_keycode_down
                                     27 	.globl _clear_keyboard
                                     28 	.globl _tap_code
                                     29 	.globl _unregister_code
                                     30 	.globl _register_code
                                     31 	.globl _mDelaymS
                                     32 	.globl ___memcpy
                                     33 	.globl _memset
                                     34 	.globl _eeprom_update_byte
                                     35 	.globl _eeprom_read_byte
                                     36 	.globl _ADC_START
                                     37 	.globl _S0_R_FIFO
                                     38 	.globl _S0_T_FIFO
                                     39 	.globl _S0_FREE
                                     40 	.globl _S0_IF_BYTE
                                     41 	.globl _S0_IF_FIRST
                                     42 	.globl _S0_IF_OV
                                     43 	.globl _S0_FST_ACT
                                     44 	.globl _CP_RL2
                                     45 	.globl _C_T2
                                     46 	.globl _TR2
                                     47 	.globl _EXEN2
                                     48 	.globl _TCLK
                                     49 	.globl _RCLK
                                     50 	.globl _EXF2
                                     51 	.globl _CAP1F
                                     52 	.globl _TF2
                                     53 	.globl _RI
                                     54 	.globl _TI
                                     55 	.globl _RB8
                                     56 	.globl _TB8
                                     57 	.globl _REN
                                     58 	.globl _SM2
                                     59 	.globl _SM1
                                     60 	.globl _SM0
                                     61 	.globl _IT0
                                     62 	.globl _IE0
                                     63 	.globl _IT1
                                     64 	.globl _IE1
                                     65 	.globl _TR0
                                     66 	.globl _TF0
                                     67 	.globl _TR1
                                     68 	.globl _TF1
                                     69 	.globl _P4_0
                                     70 	.globl _P4_1
                                     71 	.globl _P4_2
                                     72 	.globl _P4_3
                                     73 	.globl _P4_4
                                     74 	.globl _P4_5
                                     75 	.globl _P4_6
                                     76 	.globl _RXD
                                     77 	.globl _TXD
                                     78 	.globl _INT0
                                     79 	.globl _INT1
                                     80 	.globl _T0
                                     81 	.globl _T1
                                     82 	.globl _MOSI1
                                     83 	.globl _MISO1
                                     84 	.globl _SCK1
                                     85 	.globl _P3_0
                                     86 	.globl _P3_1
                                     87 	.globl _P3_2
                                     88 	.globl _P3_3
                                     89 	.globl _P3_4
                                     90 	.globl _P3_5
                                     91 	.globl _P3_6
                                     92 	.globl _P3_7
                                     93 	.globl _CAP1_
                                     94 	.globl _T2_
                                     95 	.globl _CAP2_
                                     96 	.globl _T2EX_
                                     97 	.globl _RXD1
                                     98 	.globl _TXD1
                                     99 	.globl _P2_0
                                    100 	.globl _P2_1
                                    101 	.globl _P2_2
                                    102 	.globl _P2_3
                                    103 	.globl _P2_4
                                    104 	.globl _P2_5
                                    105 	.globl _P2_6
                                    106 	.globl _P2_7
                                    107 	.globl _AIN0
                                    108 	.globl _AIN1
                                    109 	.globl _AIN2
                                    110 	.globl _AIN3
                                    111 	.globl _AIN4
                                    112 	.globl _AIN5
                                    113 	.globl _AIN6
                                    114 	.globl _AIN7
                                    115 	.globl _CAP1
                                    116 	.globl _T2
                                    117 	.globl _CAP2
                                    118 	.globl _T2EX
                                    119 	.globl _INT0_
                                    120 	.globl _SCS
                                    121 	.globl _MOSI
                                    122 	.globl _MISO
                                    123 	.globl _SCK
                                    124 	.globl _RXD1_
                                    125 	.globl _TXD1_
                                    126 	.globl _P1_0
                                    127 	.globl _P1_1
                                    128 	.globl _P1_2
                                    129 	.globl _P1_3
                                    130 	.globl _P1_4
                                    131 	.globl _P1_5
                                    132 	.globl _P1_6
                                    133 	.globl _P1_7
                                    134 	.globl _AIN8
                                    135 	.globl _AIN9
                                    136 	.globl _AIN10
                                    137 	.globl _AIN11
                                    138 	.globl _AIN12
                                    139 	.globl _AIN13
                                    140 	.globl _RXD_
                                    141 	.globl _TXD_
                                    142 	.globl _SCL0
                                    143 	.globl _SDA0
                                    144 	.globl _P0_0
                                    145 	.globl _P0_1
                                    146 	.globl _P0_2
                                    147 	.globl _P0_3
                                    148 	.globl _P0_4
                                    149 	.globl _P0_5
                                    150 	.globl _P0_6
                                    151 	.globl _P0_7
                                    152 	.globl _IE_SPI0
                                    153 	.globl _IE_USB
                                    154 	.globl _IE_ADC
                                    155 	.globl _IE_UART1
                                    156 	.globl _IE_PWM_I2C
                                    157 	.globl _IE_GPIO
                                    158 	.globl _IE_WDOG
                                    159 	.globl _PX0
                                    160 	.globl _PT0
                                    161 	.globl _PX1
                                    162 	.globl _PT1
                                    163 	.globl _PS
                                    164 	.globl _PT2
                                    165 	.globl _PL_FLAG
                                    166 	.globl _PH_FLAG
                                    167 	.globl _EX0
                                    168 	.globl _ET0
                                    169 	.globl _EX1
                                    170 	.globl _ET1
                                    171 	.globl _ES
                                    172 	.globl _ET2
                                    173 	.globl _E_DIS
                                    174 	.globl _EA
                                    175 	.globl _P
                                    176 	.globl _F1
                                    177 	.globl _OV
                                    178 	.globl _RS0
                                    179 	.globl _RS1
                                    180 	.globl _F0
                                    181 	.globl _AC
                                    182 	.globl _CY
                                    183 	.globl _I2CS_INT_ST
                                    184 	.globl _I2CX_INT
                                    185 	.globl _LED_STATUS
                                    186 	.globl _LED_DMA_H
                                    187 	.globl _LED_DMA_L
                                    188 	.globl _LED_DMA
                                    189 	.globl _LED_PWM_OE
                                    190 	.globl _LED_COMMON
                                    191 	.globl _ADC_CHAN
                                    192 	.globl _ADC_DAT_H
                                    193 	.globl _ADC_DAT_L
                                    194 	.globl _ADC_DAT
                                    195 	.globl _ADC_CTRL
                                    196 	.globl _SPI1_CK_SE
                                    197 	.globl _SPI1_CTRL
                                    198 	.globl _SPI1_DATA
                                    199 	.globl _SPI1_STAT
                                    200 	.globl _SIF1
                                    201 	.globl _SBAUD1
                                    202 	.globl _SBUF1
                                    203 	.globl _SCON1
                                    204 	.globl _SPI0_SETUP
                                    205 	.globl _SPI0_CK_SE
                                    206 	.globl _SPI0_CTRL
                                    207 	.globl _SPI0_DATA
                                    208 	.globl _SPI0_STAT
                                    209 	.globl _T2CAP1H
                                    210 	.globl _T2CAP1L
                                    211 	.globl _T2CAP1
                                    212 	.globl _TH2
                                    213 	.globl _TL2
                                    214 	.globl _T2COUNT
                                    215 	.globl _RCAP2H
                                    216 	.globl _RCAP2L
                                    217 	.globl _RCAP2
                                    218 	.globl _T2MOD
                                    219 	.globl _T2CON
                                    220 	.globl _SBUF
                                    221 	.globl _SCON
                                    222 	.globl _TH1
                                    223 	.globl _TH0
                                    224 	.globl _TL1
                                    225 	.globl _TL0
                                    226 	.globl _TMOD
                                    227 	.globl _TCON
                                    228 	.globl _XBUS_AUX
                                    229 	.globl _P7
                                    230 	.globl _P6_DIR
                                    231 	.globl _P6_OUT_PU
                                    232 	.globl _P6_IN
                                    233 	.globl _P5_DIR
                                    234 	.globl _P5_OUT_PU
                                    235 	.globl _P5_IN
                                    236 	.globl _P4_LED_KEY
                                    237 	.globl _P4_DIR_PU
                                    238 	.globl _P4_MOD_OC
                                    239 	.globl _P4
                                    240 	.globl _P3_DIR_PU
                                    241 	.globl _P3_MOD_OC
                                    242 	.globl _P3
                                    243 	.globl _P2_DIR_PU
                                    244 	.globl _P2_MOD_OC
                                    245 	.globl _P2
                                    246 	.globl _P1_DIR_PU
                                    247 	.globl _P1_MOD_OC
                                    248 	.globl _P1
                                    249 	.globl _P0_DIR_PU
                                    250 	.globl _P0_MOD_OC
                                    251 	.globl _P0
                                    252 	.globl _ROM_CTRL
                                    253 	.globl _ROM_DATA_HH
                                    254 	.globl _ROM_DATA_HL
                                    255 	.globl _ROM_DATA_HI
                                    256 	.globl _ROM_ADDR_H
                                    257 	.globl _ROM_ADDR_L
                                    258 	.globl _ROM_ADDR
                                    259 	.globl _GPIO_IE
                                    260 	.globl _IP_EX
                                    261 	.globl _IE_EX
                                    262 	.globl _IP
                                    263 	.globl _IE
                                    264 	.globl _WDOG_COUNT
                                    265 	.globl _RESET_KEEP
                                    266 	.globl _WAKE_CTRL
                                    267 	.globl _CLOCK_CFG
                                    268 	.globl _POWER_CFG
                                    269 	.globl _PCON
                                    270 	.globl _GLOBAL_CFG
                                    271 	.globl _SAFE_MOD
                                    272 	.globl _DPH
                                    273 	.globl _DPL
                                    274 	.globl _SP
                                    275 	.globl _A_INV
                                    276 	.globl _B
                                    277 	.globl _ACC
                                    278 	.globl _PSW
                                    279 	.globl _dynamic_keymap_macro_set_buffer_PARM_3
                                    280 	.globl _dynamic_keymap_macro_set_buffer_PARM_2
                                    281 	.globl _dynamic_keymap_macro_get_buffer_PARM_3
                                    282 	.globl _dynamic_keymap_macro_get_buffer_PARM_2
                                    283 	.globl _keycode_at_encodermap_location_PARM_3
                                    284 	.globl _keycode_at_encodermap_location_PARM_2
                                    285 	.globl _keycode_at_keymap_location_PARM_3
                                    286 	.globl _keycode_at_keymap_location_PARM_2
                                    287 	.globl _dynamic_keymap_set_buffer_PARM_3
                                    288 	.globl _dynamic_keymap_set_buffer_PARM_2
                                    289 	.globl _dynamic_keymap_get_buffer_PARM_3
                                    290 	.globl _dynamic_keymap_get_buffer_PARM_2
                                    291 	.globl _dynamic_keymap_set_combo_PARM_2
                                    292 	.globl _dynamic_keymap_get_combo_PARM_2
                                    293 	.globl _dynamic_keymap_set_encoder_PARM_4
                                    294 	.globl _dynamic_keymap_set_encoder_PARM_3
                                    295 	.globl _dynamic_keymap_set_encoder_PARM_2
                                    296 	.globl _dynamic_keymap_get_encoder_PARM_3
                                    297 	.globl _dynamic_keymap_get_encoder_PARM_2
                                    298 	.globl _dynamic_keymap_encoder_to_eeprom_address_PARM_2
                                    299 	.globl _dynamic_keymap_set_keycode_PARM_4
                                    300 	.globl _dynamic_keymap_set_keycode_PARM_3
                                    301 	.globl _dynamic_keymap_set_keycode_PARM_2
                                    302 	.globl _dynamic_keymap_get_keycode_PARM_3
                                    303 	.globl _dynamic_keymap_get_keycode_PARM_2
                                    304 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_3
                                    305 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_2
                                    306 	.globl _dynamic_keymap_get_layer_count
                                    307 	.globl _dynamic_keymap_key_to_eeprom_address
                                    308 	.globl _dynamic_keymap_get_keycode
                                    309 	.globl _dynamic_keymap_set_keycode
                                    310 	.globl _dynamic_keymap_get_encoder
                                    311 	.globl _dynamic_keymap_set_encoder
                                    312 	.globl _dynamic_keymap_get_combo
                                    313 	.globl _dynamic_keymap_set_combo
                                    314 	.globl _dynamic_keymap_reset
                                    315 	.globl _dynamic_keymap_get_buffer
                                    316 	.globl _dynamic_keymap_set_buffer
                                    317 	.globl _keycode_at_keymap_location
                                    318 	.globl _keycode_at_encodermap_location
                                    319 	.globl _dynamic_keymap_macro_get_count
                                    320 	.globl _dynamic_keymap_macro_get_buffer_size
                                    321 	.globl _dynamic_keymap_macro_get_buffer
                                    322 	.globl _dynamic_keymap_macro_set_buffer
                                    323 	.globl _dynamic_keymap_macro_reset
                                    324 	.globl _dynamic_keymap_macro_send
                                    325 ;--------------------------------------------------------
                                    326 ; special function registers
                                    327 ;--------------------------------------------------------
                                    328 	.area RSEG    (ABS,DATA)
      000000                        329 	.org 0x0000
                           0000D0   330 _PSW	=	0x00d0
                           0000E0   331 _ACC	=	0x00e0
                           0000F0   332 _B	=	0x00f0
                           0000FD   333 _A_INV	=	0x00fd
                           000081   334 _SP	=	0x0081
                           000082   335 _DPL	=	0x0082
                           000083   336 _DPH	=	0x0083
                           0000A1   337 _SAFE_MOD	=	0x00a1
                           0000B1   338 _GLOBAL_CFG	=	0x00b1
                           000087   339 _PCON	=	0x0087
                           0000BA   340 _POWER_CFG	=	0x00ba
                           0000B9   341 _CLOCK_CFG	=	0x00b9
                           0000A9   342 _WAKE_CTRL	=	0x00a9
                           0000FE   343 _RESET_KEEP	=	0x00fe
                           0000FF   344 _WDOG_COUNT	=	0x00ff
                           0000A8   345 _IE	=	0x00a8
                           0000B8   346 _IP	=	0x00b8
                           0000E8   347 _IE_EX	=	0x00e8
                           0000E9   348 _IP_EX	=	0x00e9
                           0000B2   349 _GPIO_IE	=	0x00b2
                           008584   350 _ROM_ADDR	=	0x8584
                           000084   351 _ROM_ADDR_L	=	0x0084
                           000085   352 _ROM_ADDR_H	=	0x0085
                           008F8E   353 _ROM_DATA_HI	=	0x8f8e
                           00008E   354 _ROM_DATA_HL	=	0x008e
                           00008F   355 _ROM_DATA_HH	=	0x008f
                           000086   356 _ROM_CTRL	=	0x0086
                           000080   357 _P0	=	0x0080
                           0000C4   358 _P0_MOD_OC	=	0x00c4
                           0000C5   359 _P0_DIR_PU	=	0x00c5
                           000090   360 _P1	=	0x0090
                           000092   361 _P1_MOD_OC	=	0x0092
                           000093   362 _P1_DIR_PU	=	0x0093
                           0000A0   363 _P2	=	0x00a0
                           000094   364 _P2_MOD_OC	=	0x0094
                           000095   365 _P2_DIR_PU	=	0x0095
                           0000B0   366 _P3	=	0x00b0
                           000096   367 _P3_MOD_OC	=	0x0096
                           000097   368 _P3_DIR_PU	=	0x0097
                           0000C0   369 _P4	=	0x00c0
                           0000C2   370 _P4_MOD_OC	=	0x00c2
                           0000C3   371 _P4_DIR_PU	=	0x00c3
                           0000C1   372 _P4_LED_KEY	=	0x00c1
                           0000AA   373 _P5_IN	=	0x00aa
                           0000AB   374 _P5_OUT_PU	=	0x00ab
                           0000AC   375 _P5_DIR	=	0x00ac
                           0000AD   376 _P6_IN	=	0x00ad
                           0000AE   377 _P6_OUT_PU	=	0x00ae
                           0000AF   378 _P6_DIR	=	0x00af
                           0000F1   379 _P7	=	0x00f1
                           0000A2   380 _XBUS_AUX	=	0x00a2
                           000088   381 _TCON	=	0x0088
                           000089   382 _TMOD	=	0x0089
                           00008A   383 _TL0	=	0x008a
                           00008B   384 _TL1	=	0x008b
                           00008C   385 _TH0	=	0x008c
                           00008D   386 _TH1	=	0x008d
                           000098   387 _SCON	=	0x0098
                           000099   388 _SBUF	=	0x0099
                           0000C8   389 _T2CON	=	0x00c8
                           0000C9   390 _T2MOD	=	0x00c9
                           00CBCA   391 _RCAP2	=	0xcbca
                           0000CA   392 _RCAP2L	=	0x00ca
                           0000CB   393 _RCAP2H	=	0x00cb
                           00CDCC   394 _T2COUNT	=	0xcdcc
                           0000CC   395 _TL2	=	0x00cc
                           0000CD   396 _TH2	=	0x00cd
                           00CFCE   397 _T2CAP1	=	0xcfce
                           0000CE   398 _T2CAP1L	=	0x00ce
                           0000CF   399 _T2CAP1H	=	0x00cf
                           0000F8   400 _SPI0_STAT	=	0x00f8
                           0000F9   401 _SPI0_DATA	=	0x00f9
                           0000FA   402 _SPI0_CTRL	=	0x00fa
                           0000FB   403 _SPI0_CK_SE	=	0x00fb
                           0000FC   404 _SPI0_SETUP	=	0x00fc
                           0000BC   405 _SCON1	=	0x00bc
                           0000BD   406 _SBUF1	=	0x00bd
                           0000BE   407 _SBAUD1	=	0x00be
                           0000BF   408 _SIF1	=	0x00bf
                           0000B4   409 _SPI1_STAT	=	0x00b4
                           0000B5   410 _SPI1_DATA	=	0x00b5
                           0000B6   411 _SPI1_CTRL	=	0x00b6
                           0000B7   412 _SPI1_CK_SE	=	0x00b7
                           0000F3   413 _ADC_CTRL	=	0x00f3
                           00F5F4   414 _ADC_DAT	=	0xf5f4
                           0000F4   415 _ADC_DAT_L	=	0x00f4
                           0000F5   416 _ADC_DAT_H	=	0x00f5
                           0000F6   417 _ADC_CHAN	=	0x00f6
                           0000A6   418 _LED_COMMON	=	0x00a6
                           0000A7   419 _LED_PWM_OE	=	0x00a7
                           00C7C6   420 _LED_DMA	=	0xc7c6
                           0000C6   421 _LED_DMA_L	=	0x00c6
                           0000C7   422 _LED_DMA_H	=	0x00c7
                           0000F7   423 _LED_STATUS	=	0x00f7
                           0000B3   424 _I2CX_INT	=	0x00b3
                           0000BB   425 _I2CS_INT_ST	=	0x00bb
                                    426 ;--------------------------------------------------------
                                    427 ; special function bits
                                    428 ;--------------------------------------------------------
                                    429 	.area RSEG    (ABS,DATA)
      000000                        430 	.org 0x0000
                           0000D7   431 _CY	=	0x00d7
                           0000D6   432 _AC	=	0x00d6
                           0000D5   433 _F0	=	0x00d5
                           0000D4   434 _RS1	=	0x00d4
                           0000D3   435 _RS0	=	0x00d3
                           0000D2   436 _OV	=	0x00d2
                           0000D1   437 _F1	=	0x00d1
                           0000D0   438 _P	=	0x00d0
                           0000AF   439 _EA	=	0x00af
                           0000AE   440 _E_DIS	=	0x00ae
                           0000AD   441 _ET2	=	0x00ad
                           0000AC   442 _ES	=	0x00ac
                           0000AB   443 _ET1	=	0x00ab
                           0000AA   444 _EX1	=	0x00aa
                           0000A9   445 _ET0	=	0x00a9
                           0000A8   446 _EX0	=	0x00a8
                           0000BF   447 _PH_FLAG	=	0x00bf
                           0000BE   448 _PL_FLAG	=	0x00be
                           0000BD   449 _PT2	=	0x00bd
                           0000BC   450 _PS	=	0x00bc
                           0000BB   451 _PT1	=	0x00bb
                           0000BA   452 _PX1	=	0x00ba
                           0000B9   453 _PT0	=	0x00b9
                           0000B8   454 _PX0	=	0x00b8
                           0000EF   455 _IE_WDOG	=	0x00ef
                           0000EE   456 _IE_GPIO	=	0x00ee
                           0000ED   457 _IE_PWM_I2C	=	0x00ed
                           0000EC   458 _IE_UART1	=	0x00ec
                           0000EB   459 _IE_ADC	=	0x00eb
                           0000E9   460 _IE_USB	=	0x00e9
                           0000E8   461 _IE_SPI0	=	0x00e8
                           000087   462 _P0_7	=	0x0087
                           000086   463 _P0_6	=	0x0086
                           000085   464 _P0_5	=	0x0085
                           000084   465 _P0_4	=	0x0084
                           000083   466 _P0_3	=	0x0083
                           000082   467 _P0_2	=	0x0082
                           000081   468 _P0_1	=	0x0081
                           000080   469 _P0_0	=	0x0080
                           000081   470 _SDA0	=	0x0081
                           000080   471 _SCL0	=	0x0080
                           000083   472 _TXD_	=	0x0083
                           000082   473 _RXD_	=	0x0082
                           000085   474 _AIN13	=	0x0085
                           000084   475 _AIN12	=	0x0084
                           000083   476 _AIN11	=	0x0083
                           000082   477 _AIN10	=	0x0082
                           000081   478 _AIN9	=	0x0081
                           000080   479 _AIN8	=	0x0080
                           000097   480 _P1_7	=	0x0097
                           000096   481 _P1_6	=	0x0096
                           000095   482 _P1_5	=	0x0095
                           000094   483 _P1_4	=	0x0094
                           000093   484 _P1_3	=	0x0093
                           000092   485 _P1_2	=	0x0092
                           000091   486 _P1_1	=	0x0091
                           000090   487 _P1_0	=	0x0090
                           000097   488 _TXD1_	=	0x0097
                           000096   489 _RXD1_	=	0x0096
                           000097   490 _SCK	=	0x0097
                           000096   491 _MISO	=	0x0096
                           000095   492 _MOSI	=	0x0095
                           000094   493 _SCS	=	0x0094
                           000092   494 _INT0_	=	0x0092
                           000091   495 _T2EX	=	0x0091
                           000091   496 _CAP2	=	0x0091
                           000090   497 _T2	=	0x0090
                           000090   498 _CAP1	=	0x0090
                           000097   499 _AIN7	=	0x0097
                           000096   500 _AIN6	=	0x0096
                           000095   501 _AIN5	=	0x0095
                           000094   502 _AIN4	=	0x0094
                           000093   503 _AIN3	=	0x0093
                           000092   504 _AIN2	=	0x0092
                           000091   505 _AIN1	=	0x0091
                           000090   506 _AIN0	=	0x0090
                           0000A7   507 _P2_7	=	0x00a7
                           0000A6   508 _P2_6	=	0x00a6
                           0000A5   509 _P2_5	=	0x00a5
                           0000A4   510 _P2_4	=	0x00a4
                           0000A3   511 _P2_3	=	0x00a3
                           0000A2   512 _P2_2	=	0x00a2
                           0000A1   513 _P2_1	=	0x00a1
                           0000A0   514 _P2_0	=	0x00a0
                           0000A7   515 _TXD1	=	0x00a7
                           0000A6   516 _RXD1	=	0x00a6
                           0000A5   517 _T2EX_	=	0x00a5
                           0000A5   518 _CAP2_	=	0x00a5
                           0000A4   519 _T2_	=	0x00a4
                           0000A4   520 _CAP1_	=	0x00a4
                           0000B7   521 _P3_7	=	0x00b7
                           0000B6   522 _P3_6	=	0x00b6
                           0000B5   523 _P3_5	=	0x00b5
                           0000B4   524 _P3_4	=	0x00b4
                           0000B3   525 _P3_3	=	0x00b3
                           0000B2   526 _P3_2	=	0x00b2
                           0000B1   527 _P3_1	=	0x00b1
                           0000B0   528 _P3_0	=	0x00b0
                           0000B7   529 _SCK1	=	0x00b7
                           0000B6   530 _MISO1	=	0x00b6
                           0000B5   531 _MOSI1	=	0x00b5
                           0000B5   532 _T1	=	0x00b5
                           0000B4   533 _T0	=	0x00b4
                           0000B3   534 _INT1	=	0x00b3
                           0000B2   535 _INT0	=	0x00b2
                           0000B1   536 _TXD	=	0x00b1
                           0000B0   537 _RXD	=	0x00b0
                           0000C6   538 _P4_6	=	0x00c6
                           0000C5   539 _P4_5	=	0x00c5
                           0000C4   540 _P4_4	=	0x00c4
                           0000C3   541 _P4_3	=	0x00c3
                           0000C2   542 _P4_2	=	0x00c2
                           0000C1   543 _P4_1	=	0x00c1
                           0000C0   544 _P4_0	=	0x00c0
                           00008F   545 _TF1	=	0x008f
                           00008E   546 _TR1	=	0x008e
                           00008D   547 _TF0	=	0x008d
                           00008C   548 _TR0	=	0x008c
                           00008B   549 _IE1	=	0x008b
                           00008A   550 _IT1	=	0x008a
                           000089   551 _IE0	=	0x0089
                           000088   552 _IT0	=	0x0088
                           00009F   553 _SM0	=	0x009f
                           00009E   554 _SM1	=	0x009e
                           00009D   555 _SM2	=	0x009d
                           00009C   556 _REN	=	0x009c
                           00009B   557 _TB8	=	0x009b
                           00009A   558 _RB8	=	0x009a
                           000099   559 _TI	=	0x0099
                           000098   560 _RI	=	0x0098
                           0000CF   561 _TF2	=	0x00cf
                           0000CF   562 _CAP1F	=	0x00cf
                           0000CE   563 _EXF2	=	0x00ce
                           0000CD   564 _RCLK	=	0x00cd
                           0000CC   565 _TCLK	=	0x00cc
                           0000CB   566 _EXEN2	=	0x00cb
                           0000CA   567 _TR2	=	0x00ca
                           0000C9   568 _C_T2	=	0x00c9
                           0000C8   569 _CP_RL2	=	0x00c8
                           0000FF   570 _S0_FST_ACT	=	0x00ff
                           0000FE   571 _S0_IF_OV	=	0x00fe
                           0000FD   572 _S0_IF_FIRST	=	0x00fd
                           0000FC   573 _S0_IF_BYTE	=	0x00fc
                           0000FB   574 _S0_FREE	=	0x00fb
                           0000FA   575 _S0_T_FIFO	=	0x00fa
                           0000F8   576 _S0_R_FIFO	=	0x00f8
                           0000F7   577 _ADC_START	=	0x00f7
                                    578 ;--------------------------------------------------------
                                    579 ; overlayable register banks
                                    580 ;--------------------------------------------------------
                                    581 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        582 	.ds 8
                                    583 ;--------------------------------------------------------
                                    584 ; internal ram data
                                    585 ;--------------------------------------------------------
                                    586 	.area DSEG    (DATA)
      000029                        587 _dynamic_keymap_set_encoder_sloc0_1_0:
      000029                        588 	.ds 2
      00002B                        589 _dynamic_keymap_get_combo_sloc0_1_0:
      00002B                        590 	.ds 1
      00002C                        591 _ak820_dynamic_read_buffer_sloc0_1_0:
      00002C                        592 	.ds 1
      00002D                        593 _dynamic_keymap_set_buffer_sloc0_1_0:
      00002D                        594 	.ds 2
      00002F                        595 _dynamic_keymap_set_buffer_sloc1_1_0:
      00002F                        596 	.ds 2
      000031                        597 _dynamic_keymap_set_buffer_sloc2_1_0:
      000031                        598 	.ds 1
      000032                        599 _dynamic_keymap_macro_get_buffer_sloc0_1_0:
      000032                        600 	.ds 2
                                    601 ;--------------------------------------------------------
                                    602 ; overlayable items in internal ram
                                    603 ;--------------------------------------------------------
                                    604 ;--------------------------------------------------------
                                    605 ; indirectly addressable internal ram data
                                    606 ;--------------------------------------------------------
                                    607 	.area ISEG    (DATA)
                                    608 ;--------------------------------------------------------
                                    609 ; absolute internal ram data
                                    610 ;--------------------------------------------------------
                                    611 	.area IABS    (ABS,DATA)
                                    612 	.area IABS    (ABS,DATA)
                                    613 ;--------------------------------------------------------
                                    614 ; bit data
                                    615 ;--------------------------------------------------------
                                    616 	.area BSEG    (BIT)
      000024                        617 _dynamic_keymap_macro_send_sloc0_1_0:
      000024                        618 	.ds 1
                                    619 ;--------------------------------------------------------
                                    620 ; paged external ram data
                                    621 ;--------------------------------------------------------
                                    622 	.area PSEG    (PAG,XDATA)
                                    623 ;--------------------------------------------------------
                                    624 ; uninitialized external ram data
                                    625 ;--------------------------------------------------------
                                    626 	.area XSEG    (XDATA)
      000AD3                        627 _dynamic_keymap_key_to_eeprom_address_PARM_2:
      000AD3                        628 	.ds 1
      000AD4                        629 _dynamic_keymap_key_to_eeprom_address_PARM_3:
      000AD4                        630 	.ds 1
      000AD5                        631 _dynamic_keymap_key_to_eeprom_address_layer_10000_364:
      000AD5                        632 	.ds 1
      000AD6                        633 _dynamic_keymap_get_keycode_PARM_2:
      000AD6                        634 	.ds 1
      000AD7                        635 _dynamic_keymap_get_keycode_PARM_3:
      000AD7                        636 	.ds 1
      000AD8                        637 _dynamic_keymap_get_keycode_layer_10000_366:
      000AD8                        638 	.ds 1
      000AD9                        639 _dynamic_keymap_set_keycode_PARM_2:
      000AD9                        640 	.ds 1
      000ADA                        641 _dynamic_keymap_set_keycode_PARM_3:
      000ADA                        642 	.ds 1
      000ADB                        643 _dynamic_keymap_set_keycode_PARM_4:
      000ADB                        644 	.ds 2
      000ADD                        645 _dynamic_keymap_set_keycode_layer_10000_370:
      000ADD                        646 	.ds 1
      000ADE                        647 _dynamic_keymap_encoder_to_eeprom_address_PARM_2:
      000ADE                        648 	.ds 1
      000ADF                        649 _dynamic_keymap_encoder_to_eeprom_address_layer_10000_374:
      000ADF                        650 	.ds 1
      000AE0                        651 _dynamic_keymap_get_encoder_PARM_2:
      000AE0                        652 	.ds 1
      000AE1                        653 _dynamic_keymap_get_encoder_PARM_3:
      000AE1                        654 	.ds 1
      000AE2                        655 _dynamic_keymap_get_encoder_layer_10000_376:
      000AE2                        656 	.ds 1
      000AE3                        657 _dynamic_keymap_set_encoder_PARM_2:
      000AE3                        658 	.ds 1
      000AE4                        659 _dynamic_keymap_set_encoder_PARM_3:
      000AE4                        660 	.ds 1
      000AE5                        661 _dynamic_keymap_set_encoder_PARM_4:
      000AE5                        662 	.ds 2
      000AE7                        663 _dynamic_keymap_set_encoder_layer_10000_380:
      000AE7                        664 	.ds 1
      000AE8                        665 _dynamic_keymap_get_combo_PARM_2:
      000AE8                        666 	.ds 3
      000AEB                        667 _dynamic_keymap_get_combo_index_10000_384:
      000AEB                        668 	.ds 1
      000AEC                        669 _dynamic_keymap_set_combo_PARM_2:
      000AEC                        670 	.ds 3
      000AEF                        671 _dynamic_keymap_set_combo_index_10000_390:
      000AEF                        672 	.ds 1
      000AF0                        673 _dynamic_keymap_set_combo_stored_10002_395:
      000AF0                        674 	.ds 10
      000AFA                        675 _dynamic_keymap_reset_vial_unlocked_prev_10000_398:
      000AFA                        676 	.ds 1
      000AFB                        677 _dynamic_keymap_reset_combo_10001_407:
      000AFB                        678 	.ds 10
      000B05                        679 _ak820_dynamic_read_buffer_PARM_2:
      000B05                        680 	.ds 2
      000B07                        681 _ak820_dynamic_read_buffer_PARM_3:
      000B07                        682 	.ds 2
      000B09                        683 _ak820_dynamic_read_buffer_PARM_4:
      000B09                        684 	.ds 2
      000B0B                        685 _ak820_dynamic_read_buffer_PARM_5:
      000B0B                        686 	.ds 3
      000B0E                        687 _ak820_dynamic_read_buffer_base_10000_409:
      000B0E                        688 	.ds 2
      000B10                        689 _ak820_dynamic_read_buffer_available_10000_410:
      000B10                        690 	.ds 1
      000B11                        691 _dynamic_keymap_get_buffer_PARM_2:
      000B11                        692 	.ds 2
      000B13                        693 _dynamic_keymap_get_buffer_PARM_3:
      000B13                        694 	.ds 3
      000B16                        695 _dynamic_keymap_get_buffer_offset_10000_416:
      000B16                        696 	.ds 2
      000B18                        697 _dynamic_keymap_set_buffer_PARM_2:
      000B18                        698 	.ds 2
      000B1A                        699 _dynamic_keymap_set_buffer_PARM_3:
      000B1A                        700 	.ds 3
      000B1D                        701 _dynamic_keymap_set_buffer_offset_10000_418:
      000B1D                        702 	.ds 2
      000B1F                        703 _dynamic_keymap_set_buffer_chk_offset_30001_425:
      000B1F                        704 	.ds 1
      000B20                        705 _dynamic_keymap_set_buffer_chk_sz_30001_425:
      000B20                        706 	.ds 1
      000B21                        707 _dynamic_keymap_set_buffer_i_40001_432:
      000B21                        708 	.ds 1
      000B22                        709 _keycode_at_keymap_location_PARM_2:
      000B22                        710 	.ds 1
      000B23                        711 _keycode_at_keymap_location_PARM_3:
      000B23                        712 	.ds 1
      000B24                        713 _keycode_at_keymap_location_layer_num_10000_436:
      000B24                        714 	.ds 1
      000B25                        715 _keycode_at_encodermap_location_PARM_2:
      000B25                        716 	.ds 1
      000B26                        717 _keycode_at_encodermap_location_PARM_3:
      000B26                        718 	.ds 1
      000B27                        719 _keycode_at_encodermap_location_layer_num_10000_440:
      000B27                        720 	.ds 1
      000B28                        721 _dynamic_keymap_macro_get_buffer_PARM_2:
      000B28                        722 	.ds 2
      000B2A                        723 _dynamic_keymap_macro_get_buffer_PARM_3:
      000B2A                        724 	.ds 3
      000B2D                        725 _dynamic_keymap_macro_get_buffer_offset_10000_448:
      000B2D                        726 	.ds 2
      000B2F                        727 _dynamic_keymap_macro_set_buffer_PARM_2:
      000B2F                        728 	.ds 2
      000B31                        729 _dynamic_keymap_macro_set_buffer_PARM_3:
      000B31                        730 	.ds 3
      000B34                        731 _dynamic_keymap_macro_set_buffer_offset_10000_450:
      000B34                        732 	.ds 2
      000B36                        733 _decode_keycode_kc_10000_454:
      000B36                        734 	.ds 2
      000B38                        735 _dynamic_keymap_macro_send_id_10000_457:
      000B38                        736 	.ds 1
      000B39                        737 _dynamic_keymap_macro_send_sending_10000_458:
      000B39                        738 	.ds 1
      000B3A                        739 _dynamic_keymap_macro_send_p_10001_463:
      000B3A                        740 	.ds 2
      000B3C                        741 _dynamic_keymap_macro_send_data_10003_470:
      000B3C                        742 	.ds 4
                                    743 ;--------------------------------------------------------
                                    744 ; absolute external ram data
                                    745 ;--------------------------------------------------------
                                    746 	.area XABS    (ABS,XDATA)
                                    747 ;--------------------------------------------------------
                                    748 ; initialized external ram data
                                    749 ;--------------------------------------------------------
                                    750 	.area XISEG   (XDATA)
                                    751 	.area HOME    (CODE)
                                    752 	.area GSINIT0 (CODE)
                                    753 	.area GSINIT1 (CODE)
                                    754 	.area GSINIT2 (CODE)
                                    755 	.area GSINIT3 (CODE)
                                    756 	.area GSINIT4 (CODE)
                                    757 	.area GSINIT5 (CODE)
                                    758 	.area GSINIT  (CODE)
                                    759 	.area GSFINAL (CODE)
                                    760 	.area CSEG    (CODE)
                                    761 ;--------------------------------------------------------
                                    762 ; global & static initialisations
                                    763 ;--------------------------------------------------------
                                    764 	.area HOME    (CODE)
                                    765 	.area GSINIT  (CODE)
                                    766 	.area GSFINAL (CODE)
                                    767 	.area GSINIT  (CODE)
                                    768 ;--------------------------------------------------------
                                    769 ; Home
                                    770 ;--------------------------------------------------------
                                    771 	.area HOME    (CODE)
                                    772 	.area HOME    (CODE)
                                    773 ;--------------------------------------------------------
                                    774 ; code
                                    775 ;--------------------------------------------------------
                                    776 	.area CSEG    (CODE)
                                    777 ;------------------------------------------------------------
                                    778 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    779 ;------------------------------------------------------------
                                    780 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_230'
                                    781 ;------------------------------------------------------------
                                    782 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    783 ;	-----------------------------------------
                           000007   784 	ar7 = 0x07
                           000006   785 	ar6 = 0x06
                           000005   786 	ar5 = 0x05
                           000004   787 	ar4 = 0x04
                           000003   788 	ar3 = 0x03
                           000002   789 	ar2 = 0x02
                           000001   790 	ar1 = 0x01
                           000000   791 	ar0 = 0x00
                                    792 ;	 function dynamic_keymap_get_layer_count
                                    793 ;	-----------------------------------------
      008141                        794 _dynamic_keymap_get_layer_count:
                                    795 ;	quantum/dynamic_keymap.c:178: return DYNAMIC_KEYMAP_LAYER_COUNT;
      008141 75 82 06         [24]  796 	mov	dpl, #0x06
                                    797 ;	quantum/dynamic_keymap.c:179: }
      008144 22               [24]  798 	ret
                                    799 ;------------------------------------------------------------
                                    800 ;Allocation info for local variables in function 'dynamic_keymap_key_to_eeprom_address'
                                    801 ;------------------------------------------------------------
                                    802 ;row           Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_2'
                                    803 ;column        Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_3'
                                    804 ;layer         Allocated with name '_dynamic_keymap_key_to_eeprom_address_layer_10000_364'
                                    805 ;------------------------------------------------------------
                                    806 ;	quantum/dynamic_keymap.c:181: void *dynamic_keymap_key_to_eeprom_address(uint8_t layer, uint8_t row, uint8_t column) {
                                    807 ;	-----------------------------------------
                                    808 ;	 function dynamic_keymap_key_to_eeprom_address
                                    809 ;	-----------------------------------------
      008145                        810 _dynamic_keymap_key_to_eeprom_address:
      008145 E5 82            [12]  811 	mov	a,dpl
      008147 90 0A D5         [24]  812 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_layer_10000_364
      00814A F0               [24]  813 	movx	@dptr,a
                                    814 ;	quantum/dynamic_keymap.c:183: return ((uint8_t *)DYNAMIC_KEYMAP_EEPROM_ADDR) + (layer * MATRIX_ROWS * MATRIX_COLS * 2) + (row * MATRIX_COLS * 2) + (column * 2);
      00814B E0               [24]  815 	movx	a,@dptr
      00814C FF               [12]  816 	mov	r7,a
      00814D 7E 00            [12]  817 	mov	r6,#0x00
      00814F 74 40            [12]  818 	mov	a,#0x40
      008151 12 43 5B         [24]  819 	lcall	_ak820_outline_0133
      008154 7D 00            [12]  820 	mov	r5,#0x00
      008156 90 0A D3         [24]  821 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      008159 E0               [24]  822 	movx	a,@dptr
      00815A 75 F0 10         [24]  823 	mov	b,#0x10
      00815D A4               [48]  824 	mul	ab
      00815E 2E               [12]  825 	add	a, r6
      00815F FE               [12]  826 	mov	r6,a
      008160 EF               [12]  827 	mov	a,r7
      008161 35 F0            [12]  828 	addc	a, b
      008163 FF               [12]  829 	mov	r7,a
      008164 90 0A D4         [24]  830 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      008167 E0               [24]  831 	movx	a,@dptr
      008168 7C 00            [12]  832 	mov	r4,#0x00
      00816A 25 E0            [12]  833 	add	a,acc
      00816C FB               [12]  834 	mov	r3,a
      00816D EC               [12]  835 	mov	a,r4
      00816E 33               [12]  836 	rlc	a
      00816F FC               [12]  837 	mov	r4,a
      008170 EB               [12]  838 	mov	a,r3
      008171 2E               [12]  839 	add	a, r6
      008172 FE               [12]  840 	mov	r6,a
      008173 EC               [12]  841 	mov	a,r4
      008174 3F               [12]  842 	addc	a, r7
      008175 FF               [12]  843 	mov	r7,a
      008176 12 6E 2A         [24]  844 	lcall	_ak820_outline_0050
                                    845 ;	quantum/dynamic_keymap.c:184: }
      008179 22               [24]  846 	ret
                                    847 ;------------------------------------------------------------
                                    848 ;Allocation info for local variables in function 'dynamic_keymap_get_keycode'
                                    849 ;------------------------------------------------------------
                                    850 ;row           Allocated with name '_dynamic_keymap_get_keycode_PARM_2'
                                    851 ;column        Allocated with name '_dynamic_keymap_get_keycode_PARM_3'
                                    852 ;layer         Allocated with name '_dynamic_keymap_get_keycode_layer_10000_366'
                                    853 ;address       Allocated with name '_dynamic_keymap_get_keycode_address_10001_369'
                                    854 ;keycode       Allocated with name '_dynamic_keymap_get_keycode_keycode_10001_369'
                                    855 ;------------------------------------------------------------
                                    856 ;	quantum/dynamic_keymap.c:186: uint16_t dynamic_keymap_get_keycode(uint8_t layer, uint8_t row, uint8_t column) {
                                    857 ;	-----------------------------------------
                                    858 ;	 function dynamic_keymap_get_keycode
                                    859 ;	-----------------------------------------
      00817A                        860 _dynamic_keymap_get_keycode:
      00817A E5 82            [12]  861 	mov	a,dpl
      00817C 90 0A D8         [24]  862 	mov	dptr,#_dynamic_keymap_get_keycode_layer_10000_366
      00817F F0               [24]  863 	movx	@dptr,a
                                    864 ;	quantum/dynamic_keymap.c:187: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return KC_NO;
      008180 E0               [24]  865 	movx	a,@dptr
      008181 FF               [12]  866 	mov	r7,a
      008182 BF 06 00         [24]  867 	cjne	r7,#0x06,00121$
      008185                        868 00121$:
      008185 50 14            [24]  869 	jnc	00101$
      008187 90 0A D6         [24]  870 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      00818A E0               [24]  871 	movx	a,@dptr
      00818B FE               [12]  872 	mov	r6,a
      00818C BE 10 00         [24]  873 	cjne	r6,#0x10,00123$
      00818F                        874 00123$:
      00818F 50 0A            [24]  875 	jnc	00101$
      008191 90 0A D7         [24]  876 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      008194 E0               [24]  877 	movx	a,@dptr
      008195 FD               [12]  878 	mov	r5,a
      008196 BD 08 00         [24]  879 	cjne	r5,#0x08,00125$
      008199                        880 00125$:
      008199 40 04            [24]  881 	jc	00102$
      00819B                        882 00101$:
      00819B 90 00 00         [24]  883 	mov	dptr,#0x0000
      00819E 22               [24]  884 	ret
      00819F                        885 00102$:
                                    886 ;	quantum/dynamic_keymap.c:188: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      00819F 12 8B E1         [24]  887 	lcall	_ak820_outline_0097
      0081A2 12 81 45         [24]  888 	lcall	_dynamic_keymap_key_to_eeprom_address
                                    889 ;	quantum/dynamic_keymap.c:190: uint16_t keycode = eeprom_read_byte(address) << 8;
      0081A5 12 8B F5         [24]  890 	lcall	_ak820_outline_0110
      0081A8 12 40 6F         [24]  891 	lcall	_eeprom_read_byte
      0081AB AB 82            [24]  892 	mov	r3,dpl
      0081AD 7C 00            [12]  893 	mov	r4,#0x00
                                    894 ;	quantum/dynamic_keymap.c:191: keycode |= eeprom_read_byte(address + 1);
      0081AF 0D               [12]  895 	inc	r5
      0081B0 BD 00 01         [24]  896 	cjne	r5,#0x00,00127$
      0081B3 0E               [12]  897 	inc	r6
      0081B4                        898 00127$:
      0081B4 12 6C 05         [24]  899 	lcall	_ak820_outline_0046
      0081B7 12 40 6F         [24]  900 	lcall	_eeprom_read_byte
      0081BA AF 82            [24]  901 	mov	r7, dpl
      0081BC 7E 00            [12]  902 	mov	r6,#0x00
      0081BE EF               [12]  903 	mov	a,r7
      0081BF 42 04            [12]  904 	orl	ar4,a
      0081C1 EE               [12]  905 	mov	a,r6
      0081C2 42 03            [12]  906 	orl	ar3,a
                                    907 ;	quantum/dynamic_keymap.c:192: return keycode;
      0081C4 12 43 82         [24]  908 	lcall	_ak820_outline_0179
                                    909 ;	quantum/dynamic_keymap.c:193: }
      0081C7 22               [24]  910 	ret
                                    911 ;------------------------------------------------------------
                                    912 ;Allocation info for local variables in function 'dynamic_keymap_set_keycode'
                                    913 ;------------------------------------------------------------
                                    914 ;row           Allocated with name '_dynamic_keymap_set_keycode_PARM_2'
                                    915 ;column        Allocated with name '_dynamic_keymap_set_keycode_PARM_3'
                                    916 ;keycode       Allocated with name '_dynamic_keymap_set_keycode_PARM_4'
                                    917 ;layer         Allocated with name '_dynamic_keymap_set_keycode_layer_10000_370'
                                    918 ;address       Allocated with name '_dynamic_keymap_set_keycode_address_10001_373'
                                    919 ;------------------------------------------------------------
                                    920 ;	quantum/dynamic_keymap.c:195: void dynamic_keymap_set_keycode(uint8_t layer, uint8_t row, uint8_t column, uint16_t keycode) {
                                    921 ;	-----------------------------------------
                                    922 ;	 function dynamic_keymap_set_keycode
                                    923 ;	-----------------------------------------
      0081C8                        924 _dynamic_keymap_set_keycode:
      0081C8 E5 82            [12]  925 	mov	a,dpl
      0081CA 90 0A DD         [24]  926 	mov	dptr,#_dynamic_keymap_set_keycode_layer_10000_370
      0081CD F0               [24]  927 	movx	@dptr,a
                                    928 ;	quantum/dynamic_keymap.c:196: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return;
      0081CE E0               [24]  929 	movx	a,@dptr
      0081CF FF               [12]  930 	mov	r7,a
      0081D0 BF 06 00         [24]  931 	cjne	r7,#0x06,00121$
      0081D3                        932 00121$:
      0081D3 50 14            [24]  933 	jnc	00101$
      0081D5 90 0A D9         [24]  934 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      0081D8 E0               [24]  935 	movx	a,@dptr
      0081D9 FE               [12]  936 	mov	r6,a
      0081DA BE 10 00         [24]  937 	cjne	r6,#0x10,00123$
      0081DD                        938 00123$:
      0081DD 50 0A            [24]  939 	jnc	00101$
      0081DF 90 0A DA         [24]  940 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      0081E2 E0               [24]  941 	movx	a,@dptr
      0081E3 FD               [12]  942 	mov	r5,a
      0081E4 BD 08 00         [24]  943 	cjne	r5,#0x08,00125$
      0081E7                        944 00125$:
      0081E7 40 01            [24]  945 	jc	00102$
      0081E9                        946 00101$:
      0081E9 22               [24]  947 	ret
      0081EA                        948 00102$:
                                    949 ;	quantum/dynamic_keymap.c:197: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      0081EA 12 8B E1         [24]  950 	lcall	_ak820_outline_0097
      0081ED 12 81 45         [24]  951 	lcall	_dynamic_keymap_key_to_eeprom_address
      0081F0 12 8B F5         [24]  952 	lcall	_ak820_outline_0110
                                    953 ;	quantum/dynamic_keymap.c:199: eeprom_update_byte(address, (uint8_t)(keycode >> 8));
      0081F3 90 0A DB         [24]  954 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      0081F6 E0               [24]  955 	movx	a,@dptr
      0081F7 FB               [12]  956 	mov	r3,a
      0081F8 A3               [24]  957 	inc	dptr
      0081F9 E0               [24]  958 	movx	a,@dptr
      0081FA 90 06 92         [24]  959 	mov	dptr,#_eeprom_update_byte_PARM_2
      0081FD 12 4D A4         [24]  960 	lcall	_ak820_outline_0038
      008200 12 4C 8E         [24]  961 	lcall	_eeprom_update_byte
                                    962 ;	quantum/dynamic_keymap.c:200: eeprom_update_byte(address + 1, (uint8_t)(keycode & 0xFF));
      008203 0D               [12]  963 	inc	r5
      008204 BD 00 01         [24]  964 	cjne	r5,#0x00,00127$
      008207 0E               [12]  965 	inc	r6
      008208                        966 00127$:
      008208 90 06 92         [24]  967 	mov	dptr,#_eeprom_update_byte_PARM_2
      00820B EB               [12]  968 	mov	a,r3
      00820C 12 4D A4         [24]  969 	lcall	_ak820_outline_0038
                                    970 ;	quantum/dynamic_keymap.c:201: }
      00820F 02 4C 8E         [24]  971 	ljmp	_eeprom_update_byte
                                    972 ;------------------------------------------------------------
                                    973 ;Allocation info for local variables in function 'dynamic_keymap_encoder_to_eeprom_address'
                                    974 ;------------------------------------------------------------
                                    975 ;encoder_id    Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_PARM_2'
                                    976 ;layer         Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_layer_10000_374'
                                    977 ;------------------------------------------------------------
                                    978 ;	quantum/dynamic_keymap.c:204: void *dynamic_keymap_encoder_to_eeprom_address(uint8_t layer, uint8_t encoder_id) {
                                    979 ;	-----------------------------------------
                                    980 ;	 function dynamic_keymap_encoder_to_eeprom_address
                                    981 ;	-----------------------------------------
      008212                        982 _dynamic_keymap_encoder_to_eeprom_address:
      008212 E5 82            [12]  983 	mov	a,dpl
      008214 90 0A DF         [24]  984 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_layer_10000_374
      008217 F0               [24]  985 	movx	@dptr,a
                                    986 ;	quantum/dynamic_keymap.c:205: return ((uint8_t *)DYNAMIC_KEYMAP_ENCODER_EEPROM_ADDR) + (layer * NUM_ENCODERS * 2 * 2) + (encoder_id * 2 * 2);
      008218 E0               [24]  987 	movx	a,@dptr
      008219 75 F0 04         [24]  988 	mov	b,#0x04
      00821C A4               [48]  989 	mul	ab
      00821D 24 40            [12]  990 	add	a, #0x40
      00821F FD               [12]  991 	mov	r5,a
      008220 74 06            [12]  992 	mov	a,#0x06
      008222 35 F0            [12]  993 	addc	a, b
      008224 FE               [12]  994 	mov	r6,a
      008225 7F 00            [12]  995 	mov	r7,#0x00
      008227 90 0A DE         [24]  996 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      00822A E0               [24]  997 	movx	a,@dptr
      00822B 75 F0 04         [24]  998 	mov	b,#0x04
      00822E A4               [48]  999 	mul	ab
      00822F 2D               [12] 1000 	add	a, r5
      008230 FD               [12] 1001 	mov	r5,a
      008231 EE               [12] 1002 	mov	a,r6
      008232 35 F0            [12] 1003 	addc	a, b
      008234 FE               [12] 1004 	mov	r6,a
      008235 12 6C 05         [24] 1005 	lcall	_ak820_outline_0046
                                   1006 ;	quantum/dynamic_keymap.c:206: }
      008238 22               [24] 1007 	ret
                                   1008 ;------------------------------------------------------------
                                   1009 ;Allocation info for local variables in function 'dynamic_keymap_get_encoder'
                                   1010 ;------------------------------------------------------------
                                   1011 ;encoder_id    Allocated with name '_dynamic_keymap_get_encoder_PARM_2'
                                   1012 ;clockwise     Allocated with name '_dynamic_keymap_get_encoder_PARM_3'
                                   1013 ;layer         Allocated with name '_dynamic_keymap_get_encoder_layer_10000_376'
                                   1014 ;address       Allocated with name '_dynamic_keymap_get_encoder_address_10001_379'
                                   1015 ;keycode       Allocated with name '_dynamic_keymap_get_encoder_keycode_10001_379'
                                   1016 ;------------------------------------------------------------
                                   1017 ;	quantum/dynamic_keymap.c:208: uint16_t dynamic_keymap_get_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise) {
                                   1018 ;	-----------------------------------------
                                   1019 ;	 function dynamic_keymap_get_encoder
                                   1020 ;	-----------------------------------------
      008239                       1021 _dynamic_keymap_get_encoder:
      008239 E5 82            [12] 1022 	mov	a,dpl
      00823B 90 0A E2         [24] 1023 	mov	dptr,#_dynamic_keymap_get_encoder_layer_10000_376
      00823E F0               [24] 1024 	movx	@dptr,a
                                   1025 ;	quantum/dynamic_keymap.c:209: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return KC_NO;
      00823F E0               [24] 1026 	movx	a,@dptr
      008240 FF               [12] 1027 	mov	r7,a
      008241 BF 06 00         [24] 1028 	cjne	r7,#0x06,00131$
      008244                       1029 00131$:
      008244 50 0A            [24] 1030 	jnc	00101$
      008246 90 0A E0         [24] 1031 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      008249 E0               [24] 1032 	movx	a,@dptr
      00824A FE               [12] 1033 	mov	r6,a
      00824B BE 01 00         [24] 1034 	cjne	r6,#0x01,00133$
      00824E                       1035 00133$:
      00824E 40 04            [24] 1036 	jc	00102$
      008250                       1037 00101$:
      008250 90 00 00         [24] 1038 	mov	dptr,#0x0000
      008253 22               [24] 1039 	ret
      008254                       1040 00102$:
                                   1041 ;	quantum/dynamic_keymap.c:210: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      008254 90 0A DE         [24] 1042 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      008257 E4               [12] 1043 	clr	a
      008258 F0               [24] 1044 	movx	@dptr,a
      008259 8F 82            [24] 1045 	mov	dpl, r7
      00825B 12 82 12         [24] 1046 	lcall	_dynamic_keymap_encoder_to_eeprom_address
      00825E 12 8B F5         [24] 1047 	lcall	_ak820_outline_0110
                                   1048 ;	quantum/dynamic_keymap.c:212: uint16_t keycode = ((uint16_t)eeprom_read_byte(address + (clockwise ? 0 : 2))) << 8;
      008261 90 0A E1         [24] 1049 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      008264 E0               [24] 1050 	movx	a,@dptr
      008265 FC               [12] 1051 	mov	r4,a
      008266 E0               [24] 1052 	movx	a,@dptr
      008267 60 04            [24] 1053 	jz	00106$
      008269 7B 00            [12] 1054 	mov	r3,#0x00
      00826B 80 02            [24] 1055 	sjmp	00107$
      00826D                       1056 00106$:
      00826D 7B 02            [12] 1057 	mov	r3,#0x02
      00826F                       1058 00107$:
      00826F EB               [12] 1059 	mov	a,r3
      008270 12 8B BF         [24] 1060 	lcall	_ak820_outline_0025
      008273 12 40 6F         [24] 1061 	lcall	_eeprom_read_byte
      008276 AA 82            [24] 1062 	mov	r2,dpl
      008278 7B 00            [12] 1063 	mov	r3,#0x00
                                   1064 ;	quantum/dynamic_keymap.c:213: keycode |= eeprom_read_byte(address + (clockwise ? 0 : 2) + 1);
      00827A EC               [12] 1065 	mov	a,r4
      00827B 60 04            [24] 1066 	jz	00108$
      00827D 7C 00            [12] 1067 	mov	r4,#0x00
      00827F 80 02            [24] 1068 	sjmp	00109$
      008281                       1069 00108$:
      008281 7C 02            [12] 1070 	mov	r4,#0x02
      008283                       1071 00109$:
      008283 EC               [12] 1072 	mov	a,r4
      008284 12 38 B6         [24] 1073 	lcall	_ak820_outline_0156
      008287 0D               [12] 1074 	inc	r5
      008288 BD 00 01         [24] 1075 	cjne	r5,#0x00,00137$
      00828B 0E               [12] 1076 	inc	r6
      00828C                       1077 00137$:
      00828C 12 6C 05         [24] 1078 	lcall	_ak820_outline_0046
      00828F 12 40 6F         [24] 1079 	lcall	_eeprom_read_byte
      008292 AF 82            [24] 1080 	mov	r7, dpl
      008294 7E 00            [12] 1081 	mov	r6,#0x00
      008296 EF               [12] 1082 	mov	a,r7
      008297 42 03            [12] 1083 	orl	ar3,a
      008299 EE               [12] 1084 	mov	a,r6
      00829A 42 02            [12] 1085 	orl	ar2,a
                                   1086 ;	quantum/dynamic_keymap.c:214: return keycode;
      00829C 8B 82            [24] 1087 	mov	dpl, r3
      00829E 8A 83            [24] 1088 	mov	dph, r2
                                   1089 ;	quantum/dynamic_keymap.c:215: }
      0082A0 22               [24] 1090 	ret
                                   1091 ;------------------------------------------------------------
                                   1092 ;Allocation info for local variables in function 'dynamic_keymap_set_encoder'
                                   1093 ;------------------------------------------------------------
                                   1094 ;sloc0         Allocated with name '_dynamic_keymap_set_encoder_sloc0_1_0'
                                   1095 ;encoder_id    Allocated with name '_dynamic_keymap_set_encoder_PARM_2'
                                   1096 ;clockwise     Allocated with name '_dynamic_keymap_set_encoder_PARM_3'
                                   1097 ;keycode       Allocated with name '_dynamic_keymap_set_encoder_PARM_4'
                                   1098 ;layer         Allocated with name '_dynamic_keymap_set_encoder_layer_10000_380'
                                   1099 ;address       Allocated with name '_dynamic_keymap_set_encoder_address_10001_383'
                                   1100 ;------------------------------------------------------------
                                   1101 ;	quantum/dynamic_keymap.c:217: void dynamic_keymap_set_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise, uint16_t keycode) {
                                   1102 ;	-----------------------------------------
                                   1103 ;	 function dynamic_keymap_set_encoder
                                   1104 ;	-----------------------------------------
      0082A1                       1105 _dynamic_keymap_set_encoder:
      0082A1 E5 82            [12] 1106 	mov	a,dpl
      0082A3 90 0A E7         [24] 1107 	mov	dptr,#_dynamic_keymap_set_encoder_layer_10000_380
      0082A6 F0               [24] 1108 	movx	@dptr,a
                                   1109 ;	quantum/dynamic_keymap.c:218: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return;
      0082A7 E0               [24] 1110 	movx	a,@dptr
      0082A8 FF               [12] 1111 	mov	r7,a
      0082A9 BF 06 00         [24] 1112 	cjne	r7,#0x06,00131$
      0082AC                       1113 00131$:
      0082AC 50 0A            [24] 1114 	jnc	00101$
      0082AE 90 0A E3         [24] 1115 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      0082B1 E0               [24] 1116 	movx	a,@dptr
      0082B2 FE               [12] 1117 	mov	r6,a
      0082B3 BE 01 00         [24] 1118 	cjne	r6,#0x01,00133$
      0082B6                       1119 00133$:
      0082B6 40 01            [24] 1120 	jc	00102$
      0082B8                       1121 00101$:
      0082B8 22               [24] 1122 	ret
      0082B9                       1123 00102$:
                                   1124 ;	quantum/dynamic_keymap.c:219: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      0082B9 90 0A DE         [24] 1125 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      0082BC E4               [12] 1126 	clr	a
      0082BD F0               [24] 1127 	movx	@dptr,a
      0082BE 8F 82            [24] 1128 	mov	dpl, r7
      0082C0 12 82 12         [24] 1129 	lcall	_dynamic_keymap_encoder_to_eeprom_address
      0082C3 12 8B F5         [24] 1130 	lcall	_ak820_outline_0110
                                   1131 ;	quantum/dynamic_keymap.c:221: eeprom_update_byte(address + (clockwise ? 0 : 2), (uint8_t)(keycode >> 8));
      0082C6 90 0A E4         [24] 1132 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      0082C9 E0               [24] 1133 	movx	a,@dptr
      0082CA FC               [12] 1134 	mov	r4,a
      0082CB E0               [24] 1135 	movx	a,@dptr
      0082CC 60 04            [24] 1136 	jz	00106$
      0082CE 7B 00            [12] 1137 	mov	r3,#0x00
      0082D0 80 02            [24] 1138 	sjmp	00107$
      0082D2                       1139 00106$:
      0082D2 7B 02            [12] 1140 	mov	r3,#0x02
      0082D4                       1141 00107$:
      0082D4 EB               [12] 1142 	mov	a,r3
      0082D5 12 8C 07         [24] 1143 	lcall	_ak820_outline_0132
      0082D8 8F 03            [24] 1144 	mov	ar3,r7
      0082DA 90 0A E5         [24] 1145 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      0082DD E0               [24] 1146 	movx	a,@dptr
      0082DE F5 29            [12] 1147 	mov	_dynamic_keymap_set_encoder_sloc0_1_0,a
      0082E0 A3               [24] 1148 	inc	dptr
      0082E1 E0               [24] 1149 	movx	a,@dptr
      0082E2 F5 2A            [12] 1150 	mov	(_dynamic_keymap_set_encoder_sloc0_1_0 + 1),a
      0082E4 90 06 92         [24] 1151 	mov	dptr,#_eeprom_update_byte_PARM_2
      0082E7 F0               [24] 1152 	movx	@dptr,a
      0082E8 12 43 7D         [24] 1153 	lcall	_ak820_outline_0178
      0082EB 8B F0            [24] 1154 	mov	b, r3
      0082ED 12 4C 8E         [24] 1155 	lcall	_eeprom_update_byte
                                   1156 ;	quantum/dynamic_keymap.c:222: eeprom_update_byte(address + (clockwise ? 0 : 2) + 1, (uint8_t)(keycode & 0xFF));
      0082F0 EC               [12] 1157 	mov	a,r4
      0082F1 60 04            [24] 1158 	jz	00108$
      0082F3 7C 00            [12] 1159 	mov	r4,#0x00
      0082F5 80 02            [24] 1160 	sjmp	00109$
      0082F7                       1161 00108$:
      0082F7 7C 02            [12] 1162 	mov	r4,#0x02
      0082F9                       1163 00109$:
      0082F9 EC               [12] 1164 	mov	a,r4
      0082FA 12 38 B6         [24] 1165 	lcall	_ak820_outline_0156
      0082FD 0D               [12] 1166 	inc	r5
      0082FE BD 00 01         [24] 1167 	cjne	r5,#0x00,00137$
      008301 0E               [12] 1168 	inc	r6
      008302                       1169 00137$:
      008302 90 06 92         [24] 1170 	mov	dptr,#_eeprom_update_byte_PARM_2
      008305 E5 29            [12] 1171 	mov	a,_dynamic_keymap_set_encoder_sloc0_1_0
      008307 12 4D A4         [24] 1172 	lcall	_ak820_outline_0038
                                   1173 ;	quantum/dynamic_keymap.c:223: }
      00830A 02 4C 8E         [24] 1174 	ljmp	_eeprom_update_byte
                                   1175 ;------------------------------------------------------------
                                   1176 ;Allocation info for local variables in function 'dynamic_keymap_get_combo'
                                   1177 ;------------------------------------------------------------
                                   1178 ;sloc0         Allocated with name '_dynamic_keymap_get_combo_sloc0_1_0'
                                   1179 ;buffer        Allocated with name '_dynamic_keymap_get_combo_PARM_2'
                                   1180 ;index         Allocated with name '_dynamic_keymap_get_combo_index_10000_384'
                                   1181 ;entry         Allocated with name '_dynamic_keymap_get_combo_entry_10000_385'
                                   1182 ;address       Allocated with name '_dynamic_keymap_get_combo_address_10001_387'
                                   1183 ;marked        Allocated with name '_dynamic_keymap_get_combo_marked_10002_388'
                                   1184 ;------------------------------------------------------------
                                   1185 ;	quantum/dynamic_keymap.c:267: int dynamic_keymap_get_combo(uint8_t index, vial_combo_entry_t *buffer) {
                                   1186 ;	-----------------------------------------
                                   1187 ;	 function dynamic_keymap_get_combo
                                   1188 ;	-----------------------------------------
      00830D                       1189 _dynamic_keymap_get_combo:
      00830D E5 82            [12] 1190 	mov	a,dpl
      00830F 90 0A EB         [24] 1191 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_384
      008312 F0               [24] 1192 	movx	@dptr,a
                                   1193 ;	quantum/dynamic_keymap.c:270: vial_combo_entry_t AK820_STATE_MEM *entry = (vial_combo_entry_t AK820_STATE_MEM *)buffer;
      008313 90 0A E8         [24] 1194 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      008316 12 38 42         [24] 1195 	lcall	_ak820_outline_0052
                                   1196 ;	quantum/dynamic_keymap.c:274: if (index >= VIAL_COMBO_ENTRIES)
      008319 90 0A EB         [24] 1197 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_384
      00831C E0               [24] 1198 	movx	a,@dptr
      00831D FD               [12] 1199 	mov	r5,a
      00831E BD 08 00         [24] 1200 	cjne	r5,#0x08,00132$
      008321                       1201 00132$:
      008321 40 04            [24] 1202 	jc	00102$
                                   1203 ;	quantum/dynamic_keymap.c:275: return -1;
      008323 90 FF FF         [24] 1204 	mov	dptr,#0xffff
      008326 22               [24] 1205 	ret
      008327                       1206 00102$:
                                   1207 ;	quantum/dynamic_keymap.c:277: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      008327 12 8B CD         [24] 1208 	lcall	_ak820_outline_0078
                                   1209 ;	quantum/dynamic_keymap.c:279: ak820_eeprom_read_block_xdata(entry, address, sizeof(vial_combo_entry_t));
      00832A 8E 02            [24] 1210 	mov	ar2,r6
      00832C 8F 03            [24] 1211 	mov	ar3,r7
      00832E 90 05 85         [24] 1212 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      008331 12 38 5F         [24] 1213 	lcall	_ak820_outline_0071
      008334 E4               [12] 1214 	clr	a
      008335 A3               [24] 1215 	inc	dptr
      008336 F0               [24] 1216 	movx	@dptr,a
      008337 90 05 88         [24] 1217 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      00833A 12 8B EE         [24] 1218 	lcall	_ak820_outline_0106
      00833D 12 38 A7         [24] 1219 	lcall	_ak820_outline_0139
      008340 C0 07            [24] 1220 	push	ar7
      008342 C0 06            [24] 1221 	push	ar6
      008344 12 40 AA         [24] 1222 	lcall	_ak820_eeprom_read_block_xdata
      008347 D0 06            [24] 1223 	pop	ar6
      008349 D0 07            [24] 1224 	pop	ar7
                                   1225 ;	quantum/dynamic_keymap.c:284: bool marked = entry->input[2] == AK820_COMBO_MARKER && entry->input[3] == AK820_COMBO_VERSION;
      00834B 74 04            [12] 1226 	mov	a,#0x04
      00834D 12 47 31         [24] 1227 	lcall	_ak820_outline_0032
      008350 FA               [12] 1228 	mov	r2,a
      008351 A3               [24] 1229 	inc	dptr
      008352 E0               [24] 1230 	movx	a,@dptr
      008353 FB               [12] 1231 	mov	r3,a
      008354 BA 20 13         [24] 1232 	cjne	r2,#0x20,00108$
      008357 BB 08 10         [24] 1233 	cjne	r3,#0x08,00108$
      00835A 74 06            [12] 1234 	mov	a,#0x06
      00835C 12 38 32         [24] 1235 	lcall	_ak820_outline_0020
      00835F 12 43 3E         [24] 1236 	lcall	_ak820_outline_0101
      008362 BA 01 05         [24] 1237 	cjne	r2,#0x01,00136$
      008365 BB 00 02         [24] 1238 	cjne	r3,#0x00,00136$
      008368 80 05            [24] 1239 	sjmp	00109$
      00836A                       1240 00136$:
      00836A                       1241 00108$:
      00836A 75 2B 00         [24] 1242 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x00
      00836D 80 03            [24] 1243 	sjmp	00110$
      00836F                       1244 00109$:
      00836F 75 2B 01         [24] 1245 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x01
      008372                       1246 00110$:
                                   1247 ;	quantum/dynamic_keymap.c:285: entry->input[2] = entry->input[3] = 0;
      008372 74 06            [12] 1248 	mov	a,#0x06
      008374 12 38 32         [24] 1249 	lcall	_ak820_outline_0020
      008377 12 4D E7         [24] 1250 	lcall	_ak820_outline_0166
      00837A 12 43 50         [24] 1251 	lcall	_ak820_outline_0117
      00837D A3               [24] 1252 	inc	dptr
      00837E F0               [24] 1253 	movx	@dptr,a
                                   1254 ;	quantum/dynamic_keymap.c:286: if (!marked || !ak820_combo_valid(entry)) memset(entry, 0, sizeof(*entry));
      00837F E5 2B            [12] 1255 	mov	a,_dynamic_keymap_get_combo_sloc0_1_0
      008381 60 12            [24] 1256 	jz	00103$
      008383 12 38 87         [24] 1257 	lcall	_ak820_outline_0114
      008386 C0 07            [24] 1258 	push	ar7
      008388 C0 06            [24] 1259 	push	ar6
      00838A 12 34 D1         [24] 1260 	lcall	_ak820_combo_valid
      00838D E5 82            [12] 1261 	mov	a, dpl
      00838F D0 06            [24] 1262 	pop	ar6
      008391 D0 07            [24] 1263 	pop	ar7
      008393 70 13            [24] 1264 	jnz	00104$
      008395                       1265 00103$:
      008395 7D 00            [12] 1266 	mov	r5,#0x00
      008397 90 0D A3         [24] 1267 	mov	dptr,#_memset_PARM_2
      00839A E4               [12] 1268 	clr	a
      00839B F0               [24] 1269 	movx	@dptr,a
      00839C 90 0D A4         [24] 1270 	mov	dptr,#_memset_PARM_3
      00839F 12 8B EE         [24] 1271 	lcall	_ak820_outline_0106
      0083A2 12 6E 2A         [24] 1272 	lcall	_ak820_outline_0050
      0083A5 12 B6 18         [24] 1273 	lcall	_memset
      0083A8                       1274 00104$:
                                   1275 ;	quantum/dynamic_keymap.c:289: return 0;
      0083A8 90 00 00         [24] 1276 	mov	dptr,#0x0000
                                   1277 ;	quantum/dynamic_keymap.c:290: }
      0083AB 22               [24] 1278 	ret
                                   1279 ;------------------------------------------------------------
                                   1280 ;Allocation info for local variables in function 'dynamic_keymap_set_combo'
                                   1281 ;------------------------------------------------------------
                                   1282 ;buffer        Allocated with name '_dynamic_keymap_set_combo_PARM_2'
                                   1283 ;index         Allocated with name '_dynamic_keymap_set_combo_index_10000_390'
                                   1284 ;entry         Allocated with name '_dynamic_keymap_set_combo_entry_10000_391'
                                   1285 ;address       Allocated with name '_dynamic_keymap_set_combo_address_10001_394'
                                   1286 ;stored        Allocated with name '_dynamic_keymap_set_combo_stored_10002_395'
                                   1287 ;------------------------------------------------------------
                                   1288 ;	quantum/dynamic_keymap.c:292: int dynamic_keymap_set_combo(uint8_t index, const vial_combo_entry_t *buffer) {
                                   1289 ;	-----------------------------------------
                                   1290 ;	 function dynamic_keymap_set_combo
                                   1291 ;	-----------------------------------------
      0083AC                       1292 _dynamic_keymap_set_combo:
      0083AC E5 82            [12] 1293 	mov	a,dpl
      0083AE 90 0A EF         [24] 1294 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_390
      0083B1 F0               [24] 1295 	movx	@dptr,a
                                   1296 ;	quantum/dynamic_keymap.c:294: const vial_combo_entry_t AK820_STATE_MEM *entry = (const vial_combo_entry_t AK820_STATE_MEM *)buffer;
      0083B2 90 0A EC         [24] 1297 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      0083B5 12 37 F5         [24] 1298 	lcall	_ak820_outline_0005
                                   1299 ;	quantum/dynamic_keymap.c:299: if (!ak820_combo_valid(entry) || !ak820_nvm_ok()) return -1;
      0083B8 C0 07            [24] 1300 	push	ar7
      0083BA C0 06            [24] 1301 	push	ar6
      0083BC 12 34 D1         [24] 1302 	lcall	_ak820_combo_valid
      0083BF E5 82            [12] 1303 	mov	a, dpl
      0083C1 D0 06            [24] 1304 	pop	ar6
      0083C3 D0 07            [24] 1305 	pop	ar7
      0083C5 60 07            [24] 1306 	jz	00101$
      0083C7 12 3E 15         [24] 1307 	lcall	_ak820_nvm_ok
      0083CA E5 82            [12] 1308 	mov	a, dpl
      0083CC 70 04            [24] 1309 	jnz	00102$
      0083CE                       1310 00101$:
      0083CE 90 FF FF         [24] 1311 	mov	dptr,#0xffff
      0083D1 22               [24] 1312 	ret
      0083D2                       1313 00102$:
                                   1314 ;	quantum/dynamic_keymap.c:301: if (index >= VIAL_COMBO_ENTRIES)
      0083D2 90 0A EF         [24] 1315 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_390
      0083D5 E0               [24] 1316 	movx	a,@dptr
      0083D6 FD               [12] 1317 	mov	r5,a
      0083D7 BD 08 00         [24] 1318 	cjne	r5,#0x08,00133$
      0083DA                       1319 00133$:
      0083DA 40 04            [24] 1320 	jc	00105$
                                   1321 ;	quantum/dynamic_keymap.c:302: return -1;
      0083DC 90 FF FF         [24] 1322 	mov	dptr,#0xffff
      0083DF 22               [24] 1323 	ret
      0083E0                       1324 00105$:
                                   1325 ;	quantum/dynamic_keymap.c:304: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      0083E0 12 8B CD         [24] 1326 	lcall	_ak820_outline_0078
                                   1327 ;	quantum/dynamic_keymap.c:306: clear_keyboard();
      0083E3 C0 07            [24] 1328 	push	ar7
      0083E5 C0 06            [24] 1329 	push	ar6
      0083E7 C0 05            [24] 1330 	push	ar5
      0083E9 C0 04            [24] 1331 	push	ar4
      0083EB 12 74 53         [24] 1332 	lcall	_clear_keyboard
      0083EE D0 04            [24] 1333 	pop	ar4
      0083F0 D0 05            [24] 1334 	pop	ar5
      0083F2 D0 06            [24] 1335 	pop	ar6
      0083F4 D0 07            [24] 1336 	pop	ar7
                                   1337 ;	quantum/dynamic_keymap.c:307: vial_combo_entry_t stored = *entry;
      0083F6 90 0D 9B         [24] 1338 	mov	dptr,#___memcpy_PARM_2
      0083F9 12 47 4C         [24] 1339 	lcall	_ak820_outline_0060
      0083FC E4               [12] 1340 	clr	a
      0083FD A3               [24] 1341 	inc	dptr
      0083FE F0               [24] 1342 	movx	@dptr,a
      0083FF 90 0D 9E         [24] 1343 	mov	dptr,#___memcpy_PARM_3
      008402 12 8B EE         [24] 1344 	lcall	_ak820_outline_0106
      008405 90 0A F0         [24] 1345 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_395
      008408 F5 F0            [12] 1346 	mov	b,a
      00840A C0 05            [24] 1347 	push	ar5
      00840C C0 04            [24] 1348 	push	ar4
      00840E 12 B5 A2         [24] 1349 	lcall	___memcpy
      008411 D0 04            [24] 1350 	pop	ar4
      008413 D0 05            [24] 1351 	pop	ar5
                                   1352 ;	quantum/dynamic_keymap.c:308: stored.input[2] = AK820_COMBO_MARKER;
      008415 90 0A F4         [24] 1353 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_395 + 0x0004)
      008418 74 20            [12] 1354 	mov	a,#0x20
      00841A F0               [24] 1355 	movx	@dptr,a
      00841B 74 08            [12] 1356 	mov	a,#0x08
      00841D A3               [24] 1357 	inc	dptr
      00841E F0               [24] 1358 	movx	@dptr,a
                                   1359 ;	quantum/dynamic_keymap.c:309: stored.input[3] = AK820_COMBO_VERSION;
      00841F 90 0A F6         [24] 1360 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_395 + 0x0006)
      008422 74 01            [12] 1361 	mov	a,#0x01
      008424 12 38 97         [24] 1362 	lcall	_ak820_outline_0122
                                   1363 ;	quantum/dynamic_keymap.c:310: ak820_eeprom_write_block_xdata(&stored, address, sizeof(stored));
      008427 90 05 8E         [24] 1364 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      00842A 12 38 5F         [24] 1365 	lcall	_ak820_outline_0071
      00842D E4               [12] 1366 	clr	a
      00842E A3               [24] 1367 	inc	dptr
      00842F F0               [24] 1368 	movx	@dptr,a
      008430 90 05 91         [24] 1369 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      008433 12 8B EE         [24] 1370 	lcall	_ak820_outline_0106
      008436 90 0A F0         [24] 1371 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_395
      008439 12 41 36         [24] 1372 	lcall	_ak820_eeprom_write_block_xdata
                                   1373 ;	quantum/dynamic_keymap.c:315: ak820_nvm_flush();
      00843C 12 3E 24         [24] 1374 	lcall	_ak820_nvm_flush
                                   1375 ;	quantum/dynamic_keymap.c:316: if (!ak820_nvm_ok()) return -1;
      00843F 12 3E 15         [24] 1376 	lcall	_ak820_nvm_ok
      008442 E5 82            [12] 1377 	mov	a, dpl
      008444 70 04            [24] 1378 	jnz	00107$
      008446 90 FF FF         [24] 1379 	mov	dptr,#0xffff
      008449 22               [24] 1380 	ret
      00844A                       1381 00107$:
                                   1382 ;	quantum/dynamic_keymap.c:320: return 0;
      00844A 90 00 00         [24] 1383 	mov	dptr,#0x0000
                                   1384 ;	quantum/dynamic_keymap.c:321: }
      00844D 22               [24] 1385 	ret
                                   1386 ;------------------------------------------------------------
                                   1387 ;Allocation info for local variables in function 'dynamic_keymap_reset'
                                   1388 ;------------------------------------------------------------
                                   1389 ;vial_unlocked_prev Allocated with name '_dynamic_keymap_reset_vial_unlocked_prev_10000_398'
                                   1390 ;layer         Allocated with name '_dynamic_keymap_reset_layer_20000_399'
                                   1391 ;row           Allocated with name '_dynamic_keymap_reset_row_40000_401'
                                   1392 ;column        Allocated with name '_dynamic_keymap_reset_column_60000_403'
                                   1393 ;encoder       Allocated with name '_dynamic_keymap_reset_encoder_40000_405'
                                   1394 ;combo         Allocated with name '_dynamic_keymap_reset_combo_10001_407'
                                   1395 ;i             Allocated with name '_dynamic_keymap_reset_i_20001_408'
                                   1396 ;------------------------------------------------------------
                                   1397 ;	quantum/dynamic_keymap.c:346: void dynamic_keymap_reset(void) {
                                   1398 ;	-----------------------------------------
                                   1399 ;	 function dynamic_keymap_reset
                                   1400 ;	-----------------------------------------
      00844E                       1401 _dynamic_keymap_reset:
                                   1402 ;	quantum/dynamic_keymap.c:357: bool vial_unlocked_prev = vial_unlocked;
      00844E 90 0E 1A         [24] 1403 	mov	dptr,#_vial_unlocked
      008451 E0               [24] 1404 	movx	a,@dptr
      008452 90 0A FA         [24] 1405 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_398
      008455 F0               [24] 1406 	movx	@dptr,a
                                   1407 ;	quantum/dynamic_keymap.c:358: vial_unlocked = 1;
      008456 90 0E 1A         [24] 1408 	mov	dptr,#_vial_unlocked
      008459 74 01            [12] 1409 	mov	a,#0x01
      00845B F0               [24] 1410 	movx	@dptr,a
                                   1411 ;	quantum/dynamic_keymap.c:362: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      00845C 7F 00            [12] 1412 	mov	r7,#0x00
      00845E                       1413 00116$:
      00845E BF 06 00         [24] 1414 	cjne	r7,#0x06,00198$
      008461                       1415 00198$:
      008461 40 03            [24] 1416 	jc	00199$
      008463 02 85 11         [24] 1417 	ljmp	00104$
      008466                       1418 00199$:
                                   1419 ;	quantum/dynamic_keymap.c:363: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      008466 7E 00            [12] 1420 	mov	r6,#0x00
      008468                       1421 00110$:
      008468 BE 10 00         [24] 1422 	cjne	r6,#0x10,00200$
      00846B                       1423 00200$:
      00846B 50 4D            [24] 1424 	jnc	00102$
                                   1425 ;	quantum/dynamic_keymap.c:364: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      00846D 7D 00            [12] 1426 	mov	r5,#0x00
      00846F                       1427 00107$:
      00846F BD 08 00         [24] 1428 	cjne	r5,#0x08,00202$
      008472                       1429 00202$:
      008472 50 43            [24] 1430 	jnc	00111$
                                   1431 ;	quantum/dynamic_keymap.c:365: dynamic_keymap_set_keycode(layer, row, column, keycode_at_keymap_location_raw(layer, row, column));
      008474 90 0B 96         [24] 1432 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_2
      008477 EE               [12] 1433 	mov	a,r6
      008478 F0               [24] 1434 	movx	@dptr,a
      008479 90 0B 97         [24] 1435 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_3
      00847C ED               [12] 1436 	mov	a,r5
      00847D F0               [24] 1437 	movx	@dptr,a
      00847E 8F 82            [24] 1438 	mov	dpl, r7
      008480 C0 07            [24] 1439 	push	ar7
      008482 C0 06            [24] 1440 	push	ar6
      008484 C0 05            [24] 1441 	push	ar5
      008486 12 94 1E         [24] 1442 	lcall	_keycode_at_keymap_location_raw
      008489 AB 82            [24] 1443 	mov	r3, dpl
      00848B AC 83            [24] 1444 	mov	r4, dph
      00848D D0 05            [24] 1445 	pop	ar5
      00848F D0 06            [24] 1446 	pop	ar6
      008491 D0 07            [24] 1447 	pop	ar7
      008493 90 0A D9         [24] 1448 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      008496 EE               [12] 1449 	mov	a,r6
      008497 F0               [24] 1450 	movx	@dptr,a
      008498 90 0A DA         [24] 1451 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      00849B ED               [12] 1452 	mov	a,r5
      00849C F0               [24] 1453 	movx	@dptr,a
      00849D 90 0A DB         [24] 1454 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      0084A0 12 38 65         [24] 1455 	lcall	_ak820_outline_0082
      0084A3 8F 82            [24] 1456 	mov	dpl, r7
      0084A5 C0 07            [24] 1457 	push	ar7
      0084A7 C0 06            [24] 1458 	push	ar6
      0084A9 C0 05            [24] 1459 	push	ar5
      0084AB 12 81 C8         [24] 1460 	lcall	_dynamic_keymap_set_keycode
      0084AE D0 05            [24] 1461 	pop	ar5
      0084B0 D0 06            [24] 1462 	pop	ar6
      0084B2 D0 07            [24] 1463 	pop	ar7
                                   1464 ;	quantum/dynamic_keymap.c:364: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      0084B4 0D               [12] 1465 	inc	r5
      0084B5 80 B8            [24] 1466 	sjmp	00107$
      0084B7                       1467 00111$:
                                   1468 ;	quantum/dynamic_keymap.c:363: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      0084B7 0E               [12] 1469 	inc	r6
      0084B8 80 AE            [24] 1470 	sjmp	00110$
      0084BA                       1471 00102$:
                                   1472 ;	quantum/dynamic_keymap.c:369: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      0084BA 7E 00            [12] 1473 	mov	r6,#0x00
      0084BC                       1474 00113$:
      0084BC BE 01 00         [24] 1475 	cjne	r6,#0x01,00204$
      0084BF                       1476 00204$:
      0084BF 50 4C            [24] 1477 	jnc	00117$
                                   1478 ;	quantum/dynamic_keymap.c:370: dynamic_keymap_set_encoder(layer, encoder, true, keycode_at_encodermap_location_raw(layer, encoder, true));
      0084C1 12 8C 23         [24] 1479 	lcall	_ak820_outline_0174
      0084C4 04               [12] 1480 	inc	a
      0084C5 F0               [24] 1481 	movx	@dptr,a
      0084C6 8F 82            [24] 1482 	mov	dpl, r7
      0084C8 C0 07            [24] 1483 	push	ar7
      0084CA 12 94 63         [24] 1484 	lcall	_keycode_at_encodermap_location_raw
      0084CD 12 43 67         [24] 1485 	lcall	_ak820_outline_0145
      0084D0 D0 07            [24] 1486 	pop	ar7
      0084D2 12 8C 1A         [24] 1487 	lcall	_ak820_outline_0173
      0084D5 04               [12] 1488 	inc	a
      0084D6 F0               [24] 1489 	movx	@dptr,a
      0084D7 90 0A E5         [24] 1490 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      0084DA 12 38 5F         [24] 1491 	lcall	_ak820_outline_0071
      0084DD 8F 82            [24] 1492 	mov	dpl, r7
      0084DF C0 07            [24] 1493 	push	ar7
      0084E1 12 82 A1         [24] 1494 	lcall	_dynamic_keymap_set_encoder
      0084E4 D0 07            [24] 1495 	pop	ar7
                                   1496 ;	quantum/dynamic_keymap.c:371: dynamic_keymap_set_encoder(layer, encoder, false, keycode_at_encodermap_location_raw(layer, encoder, false));
      0084E6 12 8C 23         [24] 1497 	lcall	_ak820_outline_0174
      0084E9 F0               [24] 1498 	movx	@dptr,a
      0084EA 8F 82            [24] 1499 	mov	dpl, r7
      0084EC C0 07            [24] 1500 	push	ar7
      0084EE 12 94 63         [24] 1501 	lcall	_keycode_at_encodermap_location_raw
      0084F1 12 43 67         [24] 1502 	lcall	_ak820_outline_0145
      0084F4 D0 07            [24] 1503 	pop	ar7
      0084F6 12 8C 1A         [24] 1504 	lcall	_ak820_outline_0173
      0084F9 F0               [24] 1505 	movx	@dptr,a
      0084FA 90 0A E5         [24] 1506 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      0084FD 12 38 5F         [24] 1507 	lcall	_ak820_outline_0071
      008500 8F 82            [24] 1508 	mov	dpl, r7
      008502 C0 07            [24] 1509 	push	ar7
      008504 12 82 A1         [24] 1510 	lcall	_dynamic_keymap_set_encoder
      008507 D0 07            [24] 1511 	pop	ar7
                                   1512 ;	quantum/dynamic_keymap.c:369: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      008509 7E 01            [12] 1513 	mov	r6,#0x01
      00850B 80 AF            [24] 1514 	sjmp	00113$
      00850D                       1515 00117$:
                                   1516 ;	quantum/dynamic_keymap.c:362: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      00850D 0F               [12] 1517 	inc	r7
      00850E 02 84 5E         [24] 1518 	ljmp	00116$
      008511                       1519 00104$:
                                   1520 ;	quantum/dynamic_keymap.c:388: vial_combo_entry_t combo = { { 0 }, 0 };
      008511 90 0A FB         [24] 1521 	mov	dptr,#_dynamic_keymap_reset_combo_10001_407
      008514 12 4D E7         [24] 1522 	lcall	_ak820_outline_0166
      008517 90 0A FD         [24] 1523 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_407 + 0x0002)
      00851A F0               [24] 1524 	movx	@dptr,a
      00851B A3               [24] 1525 	inc	dptr
      00851C F0               [24] 1526 	movx	@dptr,a
      00851D 90 0A FF         [24] 1527 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_407 + 0x0004)
      008520 F0               [24] 1528 	movx	@dptr,a
      008521 A3               [24] 1529 	inc	dptr
      008522 F0               [24] 1530 	movx	@dptr,a
      008523 90 0B 01         [24] 1531 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_407 + 0x0006)
      008526 F0               [24] 1532 	movx	@dptr,a
      008527 A3               [24] 1533 	inc	dptr
      008528 F0               [24] 1534 	movx	@dptr,a
      008529 90 0B 03         [24] 1535 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_407 + 0x0008)
      00852C F0               [24] 1536 	movx	@dptr,a
      00852D A3               [24] 1537 	inc	dptr
      00852E F0               [24] 1538 	movx	@dptr,a
                                   1539 ;	quantum/dynamic_keymap.c:389: for (size_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      00852F FF               [12] 1540 	mov	r7,a
      008530                       1541 00119$:
      008530 BF 08 00         [24] 1542 	cjne	r7,#0x08,00206$
      008533                       1543 00206$:
      008533 50 19            [24] 1544 	jnc	00105$
                                   1545 ;	quantum/dynamic_keymap.c:390: dynamic_keymap_set_combo(i, &combo);
      008535 8F 06            [24] 1546 	mov	ar6,r7
      008537 90 0A EC         [24] 1547 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      00853A 74 FB            [12] 1548 	mov	a,#_dynamic_keymap_reset_combo_10001_407
      00853C F0               [24] 1549 	movx	@dptr,a
      00853D 74 0A            [12] 1550 	mov	a,#(_dynamic_keymap_reset_combo_10001_407 >> 8)
      00853F 12 38 6B         [24] 1551 	lcall	_ak820_outline_0090
      008542 8E 82            [24] 1552 	mov	dpl, r6
      008544 C0 07            [24] 1553 	push	ar7
      008546 12 83 AC         [24] 1554 	lcall	_dynamic_keymap_set_combo
      008549 D0 07            [24] 1555 	pop	ar7
                                   1556 ;	quantum/dynamic_keymap.c:389: for (size_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      00854B 0F               [12] 1557 	inc	r7
      00854C 80 E2            [24] 1558 	sjmp	00119$
      00854E                       1559 00105$:
                                   1560 ;	quantum/dynamic_keymap.c:403: vial_unlocked = vial_unlocked_prev;
      00854E 90 0A FA         [24] 1561 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_398
      008551 E0               [24] 1562 	movx	a,@dptr
      008552 90 0E 1A         [24] 1563 	mov	dptr,#_vial_unlocked
      008555 F0               [24] 1564 	movx	@dptr,a
                                   1565 ;	quantum/dynamic_keymap.c:405: }
      008556 22               [24] 1566 	ret
                                   1567 ;------------------------------------------------------------
                                   1568 ;Allocation info for local variables in function 'ak820_dynamic_read_buffer'
                                   1569 ;------------------------------------------------------------
                                   1570 ;sloc0         Allocated with name '_ak820_dynamic_read_buffer_sloc0_1_0'
                                   1571 ;limit         Allocated with name '_ak820_dynamic_read_buffer_PARM_2'
                                   1572 ;offset        Allocated with name '_ak820_dynamic_read_buffer_PARM_3'
                                   1573 ;size          Allocated with name '_ak820_dynamic_read_buffer_PARM_4'
                                   1574 ;data          Allocated with name '_ak820_dynamic_read_buffer_PARM_5'
                                   1575 ;base          Allocated with name '_ak820_dynamic_read_buffer_base_10000_409'
                                   1576 ;target        Allocated with name '_ak820_dynamic_read_buffer_target_10000_410'
                                   1577 ;available     Allocated with name '_ak820_dynamic_read_buffer_available_10000_410'
                                   1578 ;remaining     Allocated with name '_ak820_dynamic_read_buffer_remaining_30000_413'
                                   1579 ;i             Allocated with name '_ak820_dynamic_read_buffer_i_20000_415'
                                   1580 ;------------------------------------------------------------
                                   1581 ;	quantum/dynamic_keymap.c:410: static void ak820_dynamic_read_buffer(uint16_t base, uint16_t limit, uint16_t offset, uint16_t size, uint8_t *data) {
                                   1582 ;	-----------------------------------------
                                   1583 ;	 function ak820_dynamic_read_buffer
                                   1584 ;	-----------------------------------------
      008557                       1585 _ak820_dynamic_read_buffer:
      008557 12 38 7D         [24] 1586 	lcall	_ak820_outline_0112
      00855A 90 0B 0E         [24] 1587 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_409
      00855D 12 38 82         [24] 1588 	lcall	_ak820_outline_0113
                                   1589 ;	quantum/dynamic_keymap.c:411: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      008560 90 0B 0B         [24] 1590 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008563 12 38 42         [24] 1591 	lcall	_ak820_outline_0052
                                   1592 ;	quantum/dynamic_keymap.c:412: uint8_t available = 0;
      008566 90 0B 10         [24] 1593 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_410
      008569 E4               [12] 1594 	clr	a
      00856A F0               [24] 1595 	movx	@dptr,a
                                   1596 ;	quantum/dynamic_keymap.c:413: if (size > 28) return;
      00856B 90 0B 09         [24] 1597 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      00856E 12 38 59         [24] 1598 	lcall	_ak820_outline_0061
      008571 8C 02            [24] 1599 	mov	ar2,r4
      008573 8D 03            [24] 1600 	mov	ar3,r5
      008575 C3               [12] 1601 	clr	c
      008576 74 1C            [12] 1602 	mov	a,#0x1c
      008578 9A               [12] 1603 	subb	a,r2
      008579 E4               [12] 1604 	clr	a
      00857A 9B               [12] 1605 	subb	a,r3
      00857B 50 01            [24] 1606 	jnc	00102$
                                   1607 ;	free result
      00857D 22               [24] 1608 	ret
      00857E                       1609 00102$:
                                   1610 ;	quantum/dynamic_keymap.c:414: if (offset < limit) {
      00857E 90 0B 07         [24] 1611 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008581 12 43 3E         [24] 1612 	lcall	_ak820_outline_0101
      008584 90 0B 05         [24] 1613 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008587 12 38 77         [24] 1614 	lcall	_ak820_outline_0100
      00858A C3               [12] 1615 	clr	c
      00858B EA               [12] 1616 	mov	a,r2
      00858C 98               [12] 1617 	subb	a,r0
      00858D EB               [12] 1618 	mov	a,r3
      00858E 99               [12] 1619 	subb	a,r1
      00858F 50 17            [24] 1620 	jnc	00104$
                                   1621 ;	quantum/dynamic_keymap.c:415: uint16_t remaining = limit - offset;
      008591 E8               [12] 1622 	mov	a,r0
      008592 C3               [12] 1623 	clr	c
      008593 9A               [12] 1624 	subb	a,r2
      008594 F8               [12] 1625 	mov	r0,a
      008595 E9               [12] 1626 	mov	a,r1
      008596 9B               [12] 1627 	subb	a,r3
      008597 F9               [12] 1628 	mov	r1,a
                                   1629 ;	quantum/dynamic_keymap.c:416: available = remaining < size ? remaining : size;
      008598 C3               [12] 1630 	clr	c
      008599 E8               [12] 1631 	mov	a,r0
      00859A 9C               [12] 1632 	subb	a,r4
      00859B E9               [12] 1633 	mov	a,r1
      00859C 9D               [12] 1634 	subb	a,r5
      00859D 40 04            [24] 1635 	jc	00114$
      00859F 8C 00            [24] 1636 	mov	ar0,r4
      0085A1 8D 01            [24] 1637 	mov	ar1,r5
      0085A3                       1638 00114$:
      0085A3 90 0B 10         [24] 1639 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_410
      0085A6 E8               [12] 1640 	mov	a,r0
      0085A7 F0               [24] 1641 	movx	@dptr,a
      0085A8                       1642 00104$:
                                   1643 ;	quantum/dynamic_keymap.c:418: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      0085A8 90 0B 10         [24] 1644 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_410
      0085AB E0               [24] 1645 	movx	a,@dptr
      0085AC F5 2C            [12] 1646 	mov	_ak820_dynamic_read_buffer_sloc0_1_0,a
      0085AE E0               [24] 1647 	movx	a,@dptr
      0085AF 60 42            [24] 1648 	jz	00106$
      0085B1 C0 04            [24] 1649 	push	ar4
      0085B3 C0 05            [24] 1650 	push	ar5
      0085B5 8E 00            [24] 1651 	mov	ar0,r6
      0085B7 8F 05            [24] 1652 	mov	ar5,r7
      0085B9 90 0B 0E         [24] 1653 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_409
      0085BC E0               [24] 1654 	movx	a,@dptr
      0085BD F9               [12] 1655 	mov	r1,a
      0085BE A3               [24] 1656 	inc	dptr
      0085BF E0               [24] 1657 	movx	a,@dptr
      0085C0 FC               [12] 1658 	mov	r4,a
      0085C1 EA               [12] 1659 	mov	a,r2
      0085C2 29               [12] 1660 	add	a, r1
      0085C3 FA               [12] 1661 	mov	r2,a
      0085C4 EB               [12] 1662 	mov	a,r3
      0085C5 3C               [12] 1663 	addc	a, r4
      0085C6 FB               [12] 1664 	mov	r3,a
      0085C7 90 05 85         [24] 1665 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      0085CA EA               [12] 1666 	mov	a,r2
      0085CB F0               [24] 1667 	movx	@dptr,a
      0085CC EB               [12] 1668 	mov	a,r3
      0085CD 12 38 6B         [24] 1669 	lcall	_ak820_outline_0090
      0085D0 90 05 88         [24] 1670 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      0085D3 E5 2C            [12] 1671 	mov	a,_ak820_dynamic_read_buffer_sloc0_1_0
      0085D5 12 38 97         [24] 1672 	lcall	_ak820_outline_0122
      0085D8 88 82            [24] 1673 	mov	dpl, r0
      0085DA 8D 83            [24] 1674 	mov	dph, r5
      0085DC C0 07            [24] 1675 	push	ar7
      0085DE C0 06            [24] 1676 	push	ar6
      0085E0 C0 05            [24] 1677 	push	ar5
      0085E2 C0 04            [24] 1678 	push	ar4
      0085E4 12 40 AA         [24] 1679 	lcall	_ak820_eeprom_read_block_xdata
      0085E7 D0 04            [24] 1680 	pop	ar4
      0085E9 D0 05            [24] 1681 	pop	ar5
      0085EB D0 06            [24] 1682 	pop	ar6
      0085ED D0 07            [24] 1683 	pop	ar7
                                   1684 ;	quantum/dynamic_keymap.c:419: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      0085EF D0 05            [24] 1685 	pop	ar5
      0085F1 D0 04            [24] 1686 	pop	ar4
                                   1687 ;	quantum/dynamic_keymap.c:418: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      0085F3                       1688 00106$:
                                   1689 ;	quantum/dynamic_keymap.c:419: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      0085F3 90 0B 10         [24] 1690 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_410
      0085F6 E0               [24] 1691 	movx	a,@dptr
      0085F7 FB               [12] 1692 	mov	r3,a
      0085F8                       1693 00109$:
      0085F8 8B 01            [24] 1694 	mov	ar1,r3
      0085FA 7A 00            [12] 1695 	mov	r2,#0x00
      0085FC C3               [12] 1696 	clr	c
      0085FD E9               [12] 1697 	mov	a,r1
      0085FE 9C               [12] 1698 	subb	a,r4
      0085FF EA               [12] 1699 	mov	a,r2
      008600 9D               [12] 1700 	subb	a,r5
      008601 50 09            [24] 1701 	jnc	00111$
      008603 EB               [12] 1702 	mov	a,r3
      008604 12 38 32         [24] 1703 	lcall	_ak820_outline_0020
      008607 E4               [12] 1704 	clr	a
      008608 F0               [24] 1705 	movx	@dptr,a
      008609 0B               [12] 1706 	inc	r3
      00860A 80 EC            [24] 1707 	sjmp	00109$
      00860C                       1708 00111$:
                                   1709 ;	quantum/dynamic_keymap.c:420: }
      00860C 22               [24] 1710 	ret
                                   1711 ;------------------------------------------------------------
                                   1712 ;Allocation info for local variables in function 'dynamic_keymap_get_buffer'
                                   1713 ;------------------------------------------------------------
                                   1714 ;size          Allocated with name '_dynamic_keymap_get_buffer_PARM_2'
                                   1715 ;data          Allocated with name '_dynamic_keymap_get_buffer_PARM_3'
                                   1716 ;offset        Allocated with name '_dynamic_keymap_get_buffer_offset_10000_416'
                                   1717 ;------------------------------------------------------------
                                   1718 ;	quantum/dynamic_keymap.c:423: void dynamic_keymap_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   1719 ;	-----------------------------------------
                                   1720 ;	 function dynamic_keymap_get_buffer
                                   1721 ;	-----------------------------------------
      00860D                       1722 _dynamic_keymap_get_buffer:
      00860D 12 38 7D         [24] 1723 	lcall	_ak820_outline_0112
      008610 90 0B 16         [24] 1724 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_416
      008613 12 38 82         [24] 1725 	lcall	_ak820_outline_0113
                                   1726 ;	quantum/dynamic_keymap.c:426: DYNAMIC_KEYMAP_LAYER_COUNT * MATRIX_ROWS * MATRIX_COLS * 2, offset, size, data);
      008616 90 0B 16         [24] 1727 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_416
      008619 12 38 42         [24] 1728 	lcall	_ak820_outline_0052
      00861C 90 0B 11         [24] 1729 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_2
      00861F 12 38 59         [24] 1730 	lcall	_ak820_outline_0061
      008622 90 0B 13         [24] 1731 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_3
      008625 12 4D CE         [24] 1732 	lcall	_ak820_outline_0088
      008628 90 0B 05         [24] 1733 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      00862B E4               [12] 1734 	clr	a
      00862C F0               [24] 1735 	movx	@dptr,a
      00862D 74 06            [12] 1736 	mov	a,#0x06
      00862F A3               [24] 1737 	inc	dptr
      008630 F0               [24] 1738 	movx	@dptr,a
      008631 90 0B 07         [24] 1739 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008634 12 47 4C         [24] 1740 	lcall	_ak820_outline_0060
      008637 90 0B 09         [24] 1741 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      00863A 12 38 5F         [24] 1742 	lcall	_ak820_outline_0071
      00863D 90 0B 0B         [24] 1743 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008640 E9               [12] 1744 	mov	a,r1
      008641 12 4D E0         [24] 1745 	lcall	_ak820_outline_0152
      008644 F0               [24] 1746 	movx	@dptr,a
      008645 90 00 40         [24] 1747 	mov	dptr,#0x0040
                                   1748 ;	quantum/dynamic_keymap.c:448: }
      008648 02 85 57         [24] 1749 	ljmp	_ak820_dynamic_read_buffer
                                   1750 ;------------------------------------------------------------
                                   1751 ;Allocation info for local variables in function 'dynamic_keymap_set_buffer'
                                   1752 ;------------------------------------------------------------
                                   1753 ;sloc0         Allocated with name '_dynamic_keymap_set_buffer_sloc0_1_0'
                                   1754 ;sloc1         Allocated with name '_dynamic_keymap_set_buffer_sloc1_1_0'
                                   1755 ;sloc2         Allocated with name '_dynamic_keymap_set_buffer_sloc2_1_0'
                                   1756 ;size          Allocated with name '_dynamic_keymap_set_buffer_PARM_2'
                                   1757 ;data          Allocated with name '_dynamic_keymap_set_buffer_PARM_3'
                                   1758 ;offset        Allocated with name '_dynamic_keymap_set_buffer_offset_10000_418'
                                   1759 ;dynamic_keymap_eeprom_size Allocated with name '_dynamic_keymap_set_buffer_dynamic_keymap_eeprom_size_10000_419'
                                   1760 ;target        Allocated with name '_dynamic_keymap_set_buffer_target_10000_419'
                                   1761 ;buffer        Allocated with name '_dynamic_keymap_set_buffer_buffer_10000_419'
                                   1762 ;count         Allocated with name '_dynamic_keymap_set_buffer_count_10001_422'
                                   1763 ;chk_offset    Allocated with name '_dynamic_keymap_set_buffer_chk_offset_30001_425'
                                   1764 ;chk_sz        Allocated with name '_dynamic_keymap_set_buffer_chk_sz_30001_425'
                                   1765 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_427'
                                   1766 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_430'
                                   1767 ;i             Allocated with name '_dynamic_keymap_set_buffer_i_40001_432'
                                   1768 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_433'
                                   1769 ;------------------------------------------------------------
                                   1770 ;	quantum/dynamic_keymap.c:450: void dynamic_keymap_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   1771 ;	-----------------------------------------
                                   1772 ;	 function dynamic_keymap_set_buffer
                                   1773 ;	-----------------------------------------
      00864B                       1774 _dynamic_keymap_set_buffer:
      00864B 12 38 7D         [24] 1775 	lcall	_ak820_outline_0112
      00864E 90 0B 1D         [24] 1776 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_418
      008651 12 38 82         [24] 1777 	lcall	_ak820_outline_0113
                                   1778 ;	quantum/dynamic_keymap.c:452: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset);
      008654 90 0B 1D         [24] 1779 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_418
      008657 12 46 F6         [24] 1780 	lcall	_ak820_outline_0008
      00865A 74 40            [12] 1781 	mov	a,#0x40
      00865C 2C               [12] 1782 	add	a, r4
      00865D FA               [12] 1783 	mov	r2,a
      00865E E4               [12] 1784 	clr	a
      00865F 3D               [12] 1785 	addc	a, r5
      008660 FB               [12] 1786 	mov	r3,a
                                   1787 ;	quantum/dynamic_keymap.c:453: uint8_t DYNAMIC_BUFFER_MEM *buffer = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      008661 90 0B 1A         [24] 1788 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_3
      008664 12 38 77         [24] 1789 	lcall	_ak820_outline_0100
                                   1790 ;	quantum/dynamic_keymap.c:457: if (!size) return;
      008667 90 0B 18         [24] 1791 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_2
      00866A E0               [24] 1792 	movx	a,@dptr
      00866B F5 2D            [12] 1793 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,a
      00866D A3               [24] 1794 	inc	dptr
      00866E E0               [24] 1795 	movx	a,@dptr
      00866F F5 2E            [12] 1796 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),a
      008671 E5 2D            [12] 1797 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008673 45 2E            [12] 1798 	orl	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008675 70 01            [24] 1799 	jnz	00102$
      008677 22               [24] 1800 	ret
      008678                       1801 00102$:
                                   1802 ;	quantum/dynamic_keymap.c:459: if (size > 28) return;
      008678 85 2D 2F         [24] 1803 	mov	_dynamic_keymap_set_buffer_sloc1_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
      00867B 85 2E 30         [24] 1804 	mov	(_dynamic_keymap_set_buffer_sloc1_1_0 + 1),(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      00867E C3               [12] 1805 	clr	c
      00867F 74 1C            [12] 1806 	mov	a,#0x1c
      008681 95 2F            [12] 1807 	subb	a,_dynamic_keymap_set_buffer_sloc1_1_0
      008683 E4               [12] 1808 	clr	a
      008684 95 30            [12] 1809 	subb	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      008686 50 01            [24] 1810 	jnc	00104$
                                   1811 ;	free result
      008688 22               [24] 1812 	ret
      008689                       1813 00104$:
                                   1814 ;	quantum/dynamic_keymap.c:461: dynamic_buffer_size_t count = size;
      008689 85 2D 31         [24] 1815 	mov	_dynamic_keymap_set_buffer_sloc2_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
                                   1816 ;	quantum/dynamic_keymap.c:465: if (offset >= dynamic_keymap_eeprom_size || dynamic_keymap_eeprom_size - offset < size)
      00868C 74 FA            [12] 1817 	mov	a,#0x100 - 0x06
      00868E 2F               [12] 1818 	add	a,r7
      00868F 40 11            [24] 1819 	jc	00105$
      008691 E4               [12] 1820 	clr	a
      008692 C3               [12] 1821 	clr	c
      008693 9E               [12] 1822 	subb	a,r6
      008694 FE               [12] 1823 	mov	r6,a
      008695 74 06            [12] 1824 	mov	a,#0x06
      008697 9F               [12] 1825 	subb	a,r7
      008698 FF               [12] 1826 	mov	r7,a
      008699 C3               [12] 1827 	clr	c
      00869A EE               [12] 1828 	mov	a,r6
      00869B 95 2D            [12] 1829 	subb	a,_dynamic_keymap_set_buffer_sloc0_1_0
      00869D EF               [12] 1830 	mov	a,r7
      00869E 95 2E            [12] 1831 	subb	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      0086A0 50 01            [24] 1832 	jnc	00106$
      0086A2                       1833 00105$:
                                   1834 ;	quantum/dynamic_keymap.c:466: return;
      0086A2 22               [24] 1835 	ret
      0086A3                       1836 00106$:
                                   1837 ;	quantum/dynamic_keymap.c:470: if (!vial_unlocked) {
      0086A3 90 0E 1A         [24] 1838 	mov	dptr,#_vial_unlocked
      0086A6 E0               [24] 1839 	movx	a,@dptr
      0086A7 60 03            [24] 1840 	jz	00207$
      0086A9 02 87 B5         [24] 1841 	ljmp	00120$
      0086AC                       1842 00207$:
                                   1843 ;	quantum/dynamic_keymap.c:472: dynamic_buffer_size_t chk_offset = 0;
      0086AC 90 0B 1F         [24] 1844 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_425
      0086AF E4               [12] 1845 	clr	a
      0086B0 F0               [24] 1846 	movx	@dptr,a
                                   1847 ;	quantum/dynamic_keymap.c:473: dynamic_buffer_size_t chk_sz = count;
      0086B1 90 0B 20         [24] 1848 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_425
      0086B4 E5 31            [12] 1849 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      0086B6 F0               [24] 1850 	movx	@dptr,a
                                   1851 ;	quantum/dynamic_keymap.c:476: if (offset % 2 != 0) {
      0086B7 EC               [12] 1852 	mov	a,r4
      0086B8 30 E0 31         [24] 1853 	jnb	acc.0,00111$
                                   1854 ;	quantum/dynamic_keymap.c:477: uint16_t kc = (eeprom_read_byte(target - 1) << 8) | buffer[0];
      0086BB EA               [12] 1855 	mov	a,r2
      0086BC 24 FF            [12] 1856 	add	a,#0xff
      0086BE FE               [12] 1857 	mov	r6,a
      0086BF EB               [12] 1858 	mov	a,r3
      0086C0 34 FF            [12] 1859 	addc	a,#0xff
      0086C2 FF               [12] 1860 	mov	r7,a
      0086C3 7D 00            [12] 1861 	mov	r5,#0x00
      0086C5 12 6E 2A         [24] 1862 	lcall	_ak820_outline_0050
      0086C8 12 40 6F         [24] 1863 	lcall	_eeprom_read_byte
      0086CB AE 82            [24] 1864 	mov	r6,dpl
      0086CD 7F 00            [12] 1865 	mov	r7,#0x00
      0086CF 12 38 AC         [24] 1866 	lcall	_ak820_outline_0144
      0086D2 E0               [24] 1867 	movx	a,@dptr
      0086D3 7C 00            [12] 1868 	mov	r4,#0x00
      0086D5 42 07            [12] 1869 	orl	ar7,a
      0086D7 EC               [12] 1870 	mov	a,r4
      0086D8 42 06            [12] 1871 	orl	ar6,a
                                   1872 ;	quantum/dynamic_keymap.c:478: if (kc == QK_BOOT)
      0086DA BF 00 09         [24] 1873 	cjne	r7,#0x00,00109$
      0086DD BE 7C 06         [24] 1874 	cjne	r6,#0x7c,00109$
                                   1875 ;	quantum/dynamic_keymap.c:479: buffer[0] = 0xFF;
      0086E0 12 38 AC         [24] 1876 	lcall	_ak820_outline_0144
      0086E3 74 FF            [12] 1877 	mov	a,#0xff
      0086E5 F0               [24] 1878 	movx	@dptr,a
      0086E6                       1879 00109$:
                                   1880 ;	quantum/dynamic_keymap.c:482: chk_offset += 1;
      0086E6 90 0B 1F         [24] 1881 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_425
      0086E9 74 01            [12] 1882 	mov	a,#0x01
      0086EB F0               [24] 1883 	movx	@dptr,a
      0086EC                       1884 00111$:
                                   1885 ;	quantum/dynamic_keymap.c:486: if ((offset + size) % 2 != 0) {
      0086EC 90 0B 1D         [24] 1886 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_418
      0086EF 12 38 42         [24] 1887 	lcall	_ak820_outline_0052
      0086F2 E5 2D            [12] 1888 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      0086F4 2E               [12] 1889 	add	a, r6
      0086F5 FE               [12] 1890 	mov	r6,a
      0086F6 E5 2E            [12] 1891 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      0086F8 3F               [12] 1892 	addc	a, r7
      0086F9 EE               [12] 1893 	mov	a,r6
      0086FA 30 E0 5A         [24] 1894 	jnb	acc.0,00115$
                                   1895 ;	quantum/dynamic_keymap.c:487: uint16_t kc = (buffer[count - 1] << 8) | eeprom_read_byte(target + count);
      0086FD AE 31            [24] 1896 	mov	r6,_dynamic_keymap_set_buffer_sloc2_1_0
      0086FF 7F 00            [12] 1897 	mov	r7,#0x00
      008701 EE               [12] 1898 	mov	a,r6
      008702 24 FF            [12] 1899 	add	a,#0xff
      008704 FC               [12] 1900 	mov	r4,a
      008705 EF               [12] 1901 	mov	a,r7
      008706 34 FF            [12] 1902 	addc	a,#0xff
      008708 FD               [12] 1903 	mov	r5,a
      008709 EC               [12] 1904 	mov	a,r4
      00870A 28               [12] 1905 	add	a, r0
      00870B F5 82            [12] 1906 	mov	dpl,a
      00870D ED               [12] 1907 	mov	a,r5
      00870E 39               [12] 1908 	addc	a, r1
      00870F F5 83            [12] 1909 	mov	dph,a
      008711 E0               [24] 1910 	movx	a,@dptr
      008712 FC               [12] 1911 	mov	r4,a
      008713 7D 00            [12] 1912 	mov	r5,#0x00
      008715 E5 31            [12] 1913 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008717 2A               [12] 1914 	add	a, r2
      008718 FA               [12] 1915 	mov	r2,a
      008719 E4               [12] 1916 	clr	a
      00871A 3B               [12] 1917 	addc	a, r3
      00871B FB               [12] 1918 	mov	r3,a
      00871C C0 00            [24] 1919 	push	ar0
      00871E C0 01            [24] 1920 	push	ar1
      008720 8B 01            [24] 1921 	mov	ar1,r3
      008722 7B 00            [12] 1922 	mov	r3,#0x00
      008724 8A 82            [24] 1923 	mov	dpl, r2
      008726 89 83            [24] 1924 	mov	dph, r1
      008728 8B F0            [24] 1925 	mov	b, r3
      00872A 12 40 6F         [24] 1926 	lcall	_eeprom_read_byte
      00872D AB 82            [24] 1927 	mov	r3, dpl
      00872F 7A 00            [12] 1928 	mov	r2,#0x00
      008731 EB               [12] 1929 	mov	a,r3
      008732 12 43 61         [24] 1930 	lcall	_ak820_outline_0138
                                   1931 ;	quantum/dynamic_keymap.c:488: if (kc == QK_BOOT)
      008735 BD 00 05         [24] 1932 	cjne	r5,#0x00,00212$
      008738 BC 7C 02         [24] 1933 	cjne	r4,#0x7c,00212$
      00873B 80 06            [24] 1934 	sjmp	00213$
      00873D                       1935 00212$:
      00873D D0 01            [24] 1936 	pop	ar1
      00873F D0 00            [24] 1937 	pop	ar0
      008741 80 0D            [24] 1938 	sjmp	00113$
      008743                       1939 00213$:
      008743 D0 01            [24] 1940 	pop	ar1
      008745 D0 00            [24] 1941 	pop	ar0
                                   1942 ;	quantum/dynamic_keymap.c:489: buffer[count - 1] = 0xFF;
      008747 1E               [12] 1943 	dec	r6
      008748 BE FF 01         [24] 1944 	cjne	r6,#0xff,00214$
      00874B 1F               [12] 1945 	dec	r7
      00874C                       1946 00214$:
      00874C EE               [12] 1947 	mov	a,r6
      00874D 12 8B FC         [24] 1948 	lcall	_ak820_outline_0126
      008750                       1949 00113$:
                                   1950 ;	quantum/dynamic_keymap.c:492: chk_sz -= 1;
      008750 E5 31            [12] 1951 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008752 14               [12] 1952 	dec	a
      008753 90 0B 20         [24] 1953 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_425
      008756 F0               [24] 1954 	movx	@dptr,a
      008757                       1955 00115$:
                                   1956 ;	quantum/dynamic_keymap.c:496: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      008757 90 0B 1F         [24] 1957 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_425
      00875A E0               [24] 1958 	movx	a,@dptr
      00875B 90 0B 21         [24] 1959 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_432
      00875E F0               [24] 1960 	movx	@dptr,a
      00875F                       1961 00122$:
      00875F 90 0B 21         [24] 1962 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_432
      008762 E0               [24] 1963 	movx	a,@dptr
      008763 FF               [12] 1964 	mov	r7,a
      008764 90 0B 20         [24] 1965 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_425
      008767 E0               [24] 1966 	movx	a,@dptr
      008768 FE               [12] 1967 	mov	r6,a
      008769 C3               [12] 1968 	clr	c
      00876A EF               [12] 1969 	mov	a,r7
      00876B 9E               [12] 1970 	subb	a,r6
      00876C 50 47            [24] 1971 	jnc	00120$
                                   1972 ;	quantum/dynamic_keymap.c:497: uint16_t kc = (buffer[i] << 8) | buffer[i + 1];
      00876E EF               [12] 1973 	mov	a,r7
      00876F 28               [12] 1974 	add	a, r0
      008770 FD               [12] 1975 	mov	r5,a
      008771 E4               [12] 1976 	clr	a
      008772 39               [12] 1977 	addc	a, r1
      008773 12 47 44         [24] 1978 	lcall	_ak820_outline_0058
      008776 7B 00            [12] 1979 	mov	r3,#0x00
      008778 8C 2E            [24] 1980 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),r4
      00877A 8B 2D            [24] 1981 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,r3
      00877C 8F 02            [24] 1982 	mov	ar2,r7
      00877E 7F 00            [12] 1983 	mov	r7,#0x00
      008780 74 01            [12] 1984 	mov	a,#0x01
      008782 2A               [12] 1985 	add	a, r2
      008783 FB               [12] 1986 	mov	r3,a
      008784 E4               [12] 1987 	clr	a
      008785 3F               [12] 1988 	addc	a, r7
      008786 FC               [12] 1989 	mov	r4,a
      008787 EB               [12] 1990 	mov	a,r3
      008788 28               [12] 1991 	add	a, r0
      008789 F5 82            [12] 1992 	mov	dpl,a
      00878B EC               [12] 1993 	mov	a,r4
      00878C 39               [12] 1994 	addc	a, r1
      00878D F5 83            [12] 1995 	mov	dph,a
      00878F E0               [24] 1996 	movx	a,@dptr
      008790 FC               [12] 1997 	mov	r4,a
      008791 7B 00            [12] 1998 	mov	r3,#0x00
      008793 E5 2E            [12] 1999 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008795 42 03            [12] 2000 	orl	ar3,a
                                   2001 ;	quantum/dynamic_keymap.c:498: if (kc == QK_BOOT) {
      008797 BC 00 12         [24] 2002 	cjne	r4,#0x00,00123$
      00879A BB 7C 0F         [24] 2003 	cjne	r3,#0x7c,00123$
                                   2004 ;	quantum/dynamic_keymap.c:499: buffer[i] = 0xFF;
      00879D 12 38 9C         [24] 2005 	lcall	_ak820_outline_0130
      0087A0 74 FF            [12] 2006 	mov	a,#0xff
      0087A2 F0               [24] 2007 	movx	@dptr,a
                                   2008 ;	quantum/dynamic_keymap.c:500: buffer[i + 1] = 0xFF;
      0087A3 0A               [12] 2009 	inc	r2
      0087A4 BA 00 01         [24] 2010 	cjne	r2,#0x00,00218$
      0087A7 0F               [12] 2011 	inc	r7
      0087A8                       2012 00218$:
      0087A8 EA               [12] 2013 	mov	a,r2
      0087A9 12 8B FC         [24] 2014 	lcall	_ak820_outline_0126
      0087AC                       2015 00123$:
                                   2016 ;	quantum/dynamic_keymap.c:496: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      0087AC 90 0B 21         [24] 2017 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_432
      0087AF E0               [24] 2018 	movx	a,@dptr
      0087B0 24 02            [12] 2019 	add	a,#0x02
      0087B2 F0               [24] 2020 	movx	@dptr,a
      0087B3 80 AA            [24] 2021 	sjmp	00122$
      0087B5                       2022 00120$:
                                   2023 ;	quantum/dynamic_keymap.c:511: ak820_eeprom_write_block_xdata(buffer, (void *)(uintptr_t)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset), size);
      0087B5 90 0B 1D         [24] 2024 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_418
      0087B8 12 38 42         [24] 2025 	lcall	_ak820_outline_0052
      0087BB 74 40            [12] 2026 	mov	a,#0x40
      0087BD 12 43 5B         [24] 2027 	lcall	_ak820_outline_0133
      0087C0 90 05 8E         [24] 2028 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      0087C3 12 47 4C         [24] 2029 	lcall	_ak820_outline_0060
      0087C6 E4               [12] 2030 	clr	a
      0087C7 A3               [24] 2031 	inc	dptr
      0087C8 F0               [24] 2032 	movx	@dptr,a
      0087C9 90 05 91         [24] 2033 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0087CC E5 2F            [12] 2034 	mov	a,_dynamic_keymap_set_buffer_sloc1_1_0
      0087CE F0               [24] 2035 	movx	@dptr,a
      0087CF E5 30            [12] 2036 	mov	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      0087D1 A3               [24] 2037 	inc	dptr
      0087D2 F0               [24] 2038 	movx	@dptr,a
      0087D3 12 38 AC         [24] 2039 	lcall	_ak820_outline_0144
                                   2040 ;	quantum/dynamic_keymap.c:521: }
      0087D6 02 41 36         [24] 2041 	ljmp	_ak820_eeprom_write_block_xdata
                                   2042 ;------------------------------------------------------------
                                   2043 ;Allocation info for local variables in function 'keycode_at_keymap_location'
                                   2044 ;------------------------------------------------------------
                                   2045 ;row           Allocated with name '_keycode_at_keymap_location_PARM_2'
                                   2046 ;column        Allocated with name '_keycode_at_keymap_location_PARM_3'
                                   2047 ;layer_num     Allocated with name '_keycode_at_keymap_location_layer_num_10000_436'
                                   2048 ;------------------------------------------------------------
                                   2049 ;	quantum/dynamic_keymap.c:523: uint16_t keycode_at_keymap_location(uint8_t layer_num, uint8_t row, uint8_t column) {
                                   2050 ;	-----------------------------------------
                                   2051 ;	 function keycode_at_keymap_location
                                   2052 ;	-----------------------------------------
      0087D9                       2053 _keycode_at_keymap_location:
      0087D9 E5 82            [12] 2054 	mov	a,dpl
      0087DB 90 0B 24         [24] 2055 	mov	dptr,#_keycode_at_keymap_location_layer_num_10000_436
      0087DE F0               [24] 2056 	movx	@dptr,a
                                   2057 ;	quantum/dynamic_keymap.c:524: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && row < MATRIX_ROWS && column < MATRIX_COLS) {
      0087DF E0               [24] 2058 	movx	a,@dptr
      0087E0 FF               [12] 2059 	mov	r7,a
      0087E1 BF 06 00         [24] 2060 	cjne	r7,#0x06,00128$
      0087E4                       2061 00128$:
      0087E4 50 23            [24] 2062 	jnc	00102$
      0087E6 90 0B 22         [24] 2063 	mov	dptr,#_keycode_at_keymap_location_PARM_2
      0087E9 E0               [24] 2064 	movx	a,@dptr
      0087EA FE               [12] 2065 	mov	r6,a
      0087EB BE 10 00         [24] 2066 	cjne	r6,#0x10,00130$
      0087EE                       2067 00130$:
      0087EE 50 19            [24] 2068 	jnc	00102$
      0087F0 90 0B 23         [24] 2069 	mov	dptr,#_keycode_at_keymap_location_PARM_3
      0087F3 E0               [24] 2070 	movx	a,@dptr
      0087F4 FD               [12] 2071 	mov	r5,a
      0087F5 BD 08 00         [24] 2072 	cjne	r5,#0x08,00132$
      0087F8                       2073 00132$:
      0087F8 50 0F            [24] 2074 	jnc	00102$
                                   2075 ;	quantum/dynamic_keymap.c:525: return dynamic_keymap_get_keycode(layer_num, row, column);
      0087FA 90 0A D6         [24] 2076 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      0087FD EE               [12] 2077 	mov	a,r6
      0087FE F0               [24] 2078 	movx	@dptr,a
      0087FF 90 0A D7         [24] 2079 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      008802 ED               [12] 2080 	mov	a,r5
      008803 F0               [24] 2081 	movx	@dptr,a
      008804 8F 82            [24] 2082 	mov	dpl, r7
      008806 02 81 7A         [24] 2083 	ljmp	_dynamic_keymap_get_keycode
      008809                       2084 00102$:
                                   2085 ;	quantum/dynamic_keymap.c:527: return KC_NO;
      008809 90 00 00         [24] 2086 	mov	dptr,#0x0000
                                   2087 ;	quantum/dynamic_keymap.c:528: }
      00880C 22               [24] 2088 	ret
                                   2089 ;------------------------------------------------------------
                                   2090 ;Allocation info for local variables in function 'keycode_at_encodermap_location'
                                   2091 ;------------------------------------------------------------
                                   2092 ;encoder_idx   Allocated with name '_keycode_at_encodermap_location_PARM_2'
                                   2093 ;clockwise     Allocated with name '_keycode_at_encodermap_location_PARM_3'
                                   2094 ;layer_num     Allocated with name '_keycode_at_encodermap_location_layer_num_10000_440'
                                   2095 ;------------------------------------------------------------
                                   2096 ;	quantum/dynamic_keymap.c:531: uint16_t keycode_at_encodermap_location(uint8_t layer_num, uint8_t encoder_idx, bool clockwise) {
                                   2097 ;	-----------------------------------------
                                   2098 ;	 function keycode_at_encodermap_location
                                   2099 ;	-----------------------------------------
      00880D                       2100 _keycode_at_encodermap_location:
      00880D E5 82            [12] 2101 	mov	a,dpl
      00880F 90 0B 27         [24] 2102 	mov	dptr,#_keycode_at_encodermap_location_layer_num_10000_440
      008812 F0               [24] 2103 	movx	@dptr,a
                                   2104 ;	quantum/dynamic_keymap.c:532: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && encoder_idx < NUM_ENCODERS) {
      008813 E0               [24] 2105 	movx	a,@dptr
      008814 FF               [12] 2106 	mov	r7,a
      008815 BF 06 00         [24] 2107 	cjne	r7,#0x06,00120$
      008818                       2108 00120$:
      008818 50 1E            [24] 2109 	jnc	00102$
      00881A 90 0B 25         [24] 2110 	mov	dptr,#_keycode_at_encodermap_location_PARM_2
      00881D E0               [24] 2111 	movx	a,@dptr
      00881E FE               [12] 2112 	mov	r6,a
      00881F BE 01 00         [24] 2113 	cjne	r6,#0x01,00122$
      008822                       2114 00122$:
      008822 50 14            [24] 2115 	jnc	00102$
                                   2116 ;	quantum/dynamic_keymap.c:533: return dynamic_keymap_get_encoder(layer_num, encoder_idx, clockwise);
      008824 90 0B 26         [24] 2117 	mov	dptr,#_keycode_at_encodermap_location_PARM_3
      008827 E0               [24] 2118 	movx	a,@dptr
      008828 FE               [12] 2119 	mov	r6,a
      008829 90 0A E0         [24] 2120 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      00882C E4               [12] 2121 	clr	a
      00882D F0               [24] 2122 	movx	@dptr,a
      00882E 90 0A E1         [24] 2123 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      008831 EE               [12] 2124 	mov	a,r6
      008832 F0               [24] 2125 	movx	@dptr,a
      008833 8F 82            [24] 2126 	mov	dpl, r7
      008835 02 82 39         [24] 2127 	ljmp	_dynamic_keymap_get_encoder
      008838                       2128 00102$:
                                   2129 ;	quantum/dynamic_keymap.c:535: return KC_NO;
      008838 90 00 00         [24] 2130 	mov	dptr,#0x0000
                                   2131 ;	quantum/dynamic_keymap.c:536: }
      00883B 22               [24] 2132 	ret
                                   2133 ;------------------------------------------------------------
                                   2134 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_count'
                                   2135 ;------------------------------------------------------------
                                   2136 ;	quantum/dynamic_keymap.c:539: uint8_t dynamic_keymap_macro_get_count(void) {
                                   2137 ;	-----------------------------------------
                                   2138 ;	 function dynamic_keymap_macro_get_count
                                   2139 ;	-----------------------------------------
      00883C                       2140 _dynamic_keymap_macro_get_count:
                                   2141 ;	quantum/dynamic_keymap.c:540: return DYNAMIC_KEYMAP_MACRO_COUNT;
      00883C 75 82 10         [24] 2142 	mov	dpl, #0x10
                                   2143 ;	quantum/dynamic_keymap.c:541: }
      00883F 22               [24] 2144 	ret
                                   2145 ;------------------------------------------------------------
                                   2146 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer_size'
                                   2147 ;------------------------------------------------------------
                                   2148 ;	quantum/dynamic_keymap.c:543: uint16_t dynamic_keymap_macro_get_buffer_size(void) {
                                   2149 ;	-----------------------------------------
                                   2150 ;	 function dynamic_keymap_macro_get_buffer_size
                                   2151 ;	-----------------------------------------
      008840                       2152 _dynamic_keymap_macro_get_buffer_size:
                                   2153 ;	quantum/dynamic_keymap.c:544: return DYNAMIC_KEYMAP_MACRO_EEPROM_SIZE;
      008840 90 20 00         [24] 2154 	mov	dptr,#0x2000
                                   2155 ;	quantum/dynamic_keymap.c:545: }
      008843 22               [24] 2156 	ret
                                   2157 ;------------------------------------------------------------
                                   2158 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer'
                                   2159 ;------------------------------------------------------------
                                   2160 ;sloc0         Allocated with name '_dynamic_keymap_macro_get_buffer_sloc0_1_0'
                                   2161 ;size          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_2'
                                   2162 ;data          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_3'
                                   2163 ;offset        Allocated with name '_dynamic_keymap_macro_get_buffer_offset_10000_448'
                                   2164 ;------------------------------------------------------------
                                   2165 ;	quantum/dynamic_keymap.c:547: void dynamic_keymap_macro_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2166 ;	-----------------------------------------
                                   2167 ;	 function dynamic_keymap_macro_get_buffer
                                   2168 ;	-----------------------------------------
      008844                       2169 _dynamic_keymap_macro_get_buffer:
      008844 12 38 7D         [24] 2170 	lcall	_ak820_outline_0112
      008847 90 0B 2D         [24] 2171 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_448
      00884A 12 38 82         [24] 2172 	lcall	_ak820_outline_0113
                                   2173 ;	quantum/dynamic_keymap.c:550: ak820_macro_length(), offset, size, data);
      00884D 12 2B 2B         [24] 2174 	lcall	_ak820_macro_length
      008850 12 43 56         [24] 2175 	lcall	_ak820_outline_0131
      008853 90 0B 2D         [24] 2176 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_448
      008856 12 38 59         [24] 2177 	lcall	_ak820_outline_0061
      008859 90 0B 28         [24] 2178 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_2
      00885C E0               [24] 2179 	movx	a,@dptr
      00885D F5 32            [12] 2180 	mov	_dynamic_keymap_macro_get_buffer_sloc0_1_0,a
      00885F A3               [24] 2181 	inc	dptr
      008860 E0               [24] 2182 	movx	a,@dptr
      008861 F5 33            [12] 2183 	mov	(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1),a
      008863 90 0B 2A         [24] 2184 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_3
      008866 12 38 77         [24] 2185 	lcall	_ak820_outline_0100
      008869 A3               [24] 2186 	inc	dptr
      00886A E0               [24] 2187 	movx	a,@dptr
      00886B FB               [12] 2188 	mov	r3,a
      00886C 90 0B 05         [24] 2189 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      00886F 12 47 4C         [24] 2190 	lcall	_ak820_outline_0060
      008872 90 0B 07         [24] 2191 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008875 12 38 5F         [24] 2192 	lcall	_ak820_outline_0071
      008878 90 0B 09         [24] 2193 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      00887B E5 32            [12] 2194 	mov	a,_dynamic_keymap_macro_get_buffer_sloc0_1_0
      00887D F0               [24] 2195 	movx	@dptr,a
      00887E E5 33            [12] 2196 	mov	a,(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1)
      008880 A3               [24] 2197 	inc	dptr
      008881 F0               [24] 2198 	movx	@dptr,a
      008882 90 0B 0B         [24] 2199 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008885 E8               [12] 2200 	mov	a,r0
      008886 F0               [24] 2201 	movx	@dptr,a
      008887 E9               [12] 2202 	mov	a,r1
      008888 A3               [24] 2203 	inc	dptr
      008889 12 8C 35         [24] 2204 	lcall	_ak820_outline_0184
      00888C 90 08 00         [24] 2205 	mov	dptr,#0x0800
                                   2206 ;	quantum/dynamic_keymap.c:572: }
      00888F 02 85 57         [24] 2207 	ljmp	_ak820_dynamic_read_buffer
                                   2208 ;------------------------------------------------------------
                                   2209 ;Allocation info for local variables in function 'dynamic_keymap_macro_set_buffer'
                                   2210 ;------------------------------------------------------------
                                   2211 ;size          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_2'
                                   2212 ;data          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_3'
                                   2213 ;offset        Allocated with name '_dynamic_keymap_macro_set_buffer_offset_10000_450'
                                   2214 ;------------------------------------------------------------
                                   2215 ;	quantum/dynamic_keymap.c:575: bool dynamic_keymap_macro_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2216 ;	-----------------------------------------
                                   2217 ;	 function dynamic_keymap_macro_set_buffer
                                   2218 ;	-----------------------------------------
      008892                       2219 _dynamic_keymap_macro_set_buffer:
      008892 12 38 7D         [24] 2220 	lcall	_ak820_outline_0112
      008895 90 0B 34         [24] 2221 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_450
      008898 12 38 82         [24] 2222 	lcall	_ak820_outline_0113
                                   2223 ;	quantum/dynamic_keymap.c:576: return ak820_macro_write(offset, size, data);
      00889B 90 0B 34         [24] 2224 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_450
      00889E 12 38 42         [24] 2225 	lcall	_ak820_outline_0052
      0088A1 90 0B 2F         [24] 2226 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_2
      0088A4 12 38 59         [24] 2227 	lcall	_ak820_outline_0061
      0088A7 90 0B 31         [24] 2228 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_3
      0088AA 12 4D CE         [24] 2229 	lcall	_ak820_outline_0088
      0088AD 90 05 14         [24] 2230 	mov	dptr,#_ak820_macro_write_PARM_2
      0088B0 12 38 5F         [24] 2231 	lcall	_ak820_outline_0071
      0088B3 90 05 16         [24] 2232 	mov	dptr,#_ak820_macro_write_PARM_3
      0088B6 E9               [12] 2233 	mov	a,r1
      0088B7 12 4D E0         [24] 2234 	lcall	_ak820_outline_0152
      0088BA 12 43 32         [24] 2235 	lcall	_ak820_outline_0077
                                   2236 ;	quantum/dynamic_keymap.c:577: }
      0088BD 02 2B 45         [24] 2237 	ljmp	_ak820_macro_write
                                   2238 ;------------------------------------------------------------
                                   2239 ;Allocation info for local variables in function 'dynamic_keymap_macro_reset'
                                   2240 ;------------------------------------------------------------
                                   2241 ;	quantum/dynamic_keymap.c:592: void dynamic_keymap_macro_reset(void) {
                                   2242 ;	-----------------------------------------
                                   2243 ;	 function dynamic_keymap_macro_reset
                                   2244 ;	-----------------------------------------
      0088C0                       2245 _dynamic_keymap_macro_reset:
                                   2246 ;	quantum/dynamic_keymap.c:594: ak820_macro_reset();
                                   2247 ;	quantum/dynamic_keymap.c:603: }
      0088C0 02 2E 64         [24] 2248 	ljmp	_ak820_macro_reset
                                   2249 ;------------------------------------------------------------
                                   2250 ;Allocation info for local variables in function 'decode_keycode'
                                   2251 ;------------------------------------------------------------
                                   2252 ;kc            Allocated with name '_decode_keycode_kc_10000_454'
                                   2253 ;------------------------------------------------------------
                                   2254 ;	quantum/dynamic_keymap.c:605: static uint16_t decode_keycode(uint16_t kc) {
                                   2255 ;	-----------------------------------------
                                   2256 ;	 function decode_keycode
                                   2257 ;	-----------------------------------------
      0088C3                       2258 _decode_keycode:
      0088C3 12 38 7D         [24] 2259 	lcall	_ak820_outline_0112
      0088C6 90 0B 36         [24] 2260 	mov	dptr,#_decode_keycode_kc_10000_454
      0088C9 12 38 82         [24] 2261 	lcall	_ak820_outline_0113
                                   2262 ;	quantum/dynamic_keymap.c:607: if (kc > 0xFF00)
      0088CC 90 0B 36         [24] 2263 	mov	dptr,#_decode_keycode_kc_10000_454
      0088CF 12 46 F6         [24] 2264 	lcall	_ak820_outline_0008
      0088D2 C3               [12] 2265 	clr	c
      0088D3 E4               [12] 2266 	clr	a
      0088D4 9C               [12] 2267 	subb	a,r4
      0088D5 74 FF            [12] 2268 	mov	a,#0xff
      0088D7 9D               [12] 2269 	subb	a,r5
      0088D8 50 08            [24] 2270 	jnc	00102$
                                   2271 ;	free result
                                   2272 ;	quantum/dynamic_keymap.c:608: return (kc & 0xFF) << 8;
      0088DA 8C 05            [24] 2273 	mov	ar5,r4
      0088DC 7C 00            [12] 2274 	mov	r4,#0x00
      0088DE 12 38 92         [24] 2275 	lcall	_ak820_outline_0121
      0088E1 22               [24] 2276 	ret
      0088E2                       2277 00102$:
                                   2278 ;	quantum/dynamic_keymap.c:609: return kc;
      0088E2 12 38 87         [24] 2279 	lcall	_ak820_outline_0114
                                   2280 ;	quantum/dynamic_keymap.c:610: }
      0088E5 22               [24] 2281 	ret
                                   2282 ;------------------------------------------------------------
                                   2283 ;Allocation info for local variables in function 'dynamic_keymap_macro_send'
                                   2284 ;------------------------------------------------------------
                                   2285 ;id            Allocated with name '_dynamic_keymap_macro_send_id_10000_457'
                                   2286 ;sending       Allocated with name '_dynamic_keymap_macro_send_sending_10000_458'
                                   2287 ;p             Allocated with name '_dynamic_keymap_macro_send_p_10001_463'
                                   2288 ;end           Allocated with name '_dynamic_keymap_macro_send_end_10002_464'
                                   2289 ;data          Allocated with name '_dynamic_keymap_macro_send_data_10003_470'
                                   2290 ;kc            Allocated with name '_dynamic_keymap_macro_send_kc_110003_488'
                                   2291 ;d0            Allocated with name '_dynamic_keymap_macro_send_d0_80003_492'
                                   2292 ;d1            Allocated with name '_dynamic_keymap_macro_send_d1_80003_492'
                                   2293 ;ms            Allocated with name '_dynamic_keymap_macro_send_ms_80004_494'
                                   2294 ;i             Allocated with name '_dynamic_keymap_macro_send_i_100004_496'
                                   2295 ;delay         Allocated with name '_dynamic_keymap_macro_send_delay_50003_500'
                                   2296 ;i             Allocated with name '_dynamic_keymap_macro_send_i_70003_502'
                                   2297 ;------------------------------------------------------------
                                   2298 ;	quantum/dynamic_keymap.c:612: void dynamic_keymap_macro_send(uint8_t id) {
                                   2299 ;	-----------------------------------------
                                   2300 ;	 function dynamic_keymap_macro_send
                                   2301 ;	-----------------------------------------
      0088E6                       2302 _dynamic_keymap_macro_send:
      0088E6 E5 82            [12] 2303 	mov	a,dpl
      0088E8 90 0B 38         [24] 2304 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_457
      0088EB F0               [24] 2305 	movx	@dptr,a
                                   2306 ;	quantum/dynamic_keymap.c:617: if (sending) return;
      0088EC 90 0B 39         [24] 2307 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_458
      0088EF E0               [24] 2308 	movx	a,@dptr
      0088F0 60 01            [24] 2309 	jz	00102$
      0088F2 22               [24] 2310 	ret
      0088F3                       2311 00102$:
                                   2312 ;	quantum/dynamic_keymap.c:619: if (id >= DYNAMIC_KEYMAP_MACRO_COUNT) {
      0088F3 90 0B 38         [24] 2313 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_457
      0088F6 E0               [24] 2314 	movx	a,@dptr
      0088F7 FF               [12] 2315 	mov	r7,a
      0088F8 BF 10 00         [24] 2316 	cjne	r7,#0x10,00422$
      0088FB                       2317 00422$:
      0088FB 40 01            [24] 2318 	jc	00104$
                                   2319 ;	quantum/dynamic_keymap.c:620: return;
      0088FD 22               [24] 2320 	ret
      0088FE                       2321 00104$:
                                   2322 ;	quantum/dynamic_keymap.c:626: if (!ak820_macro_ready()) return;
      0088FE C0 07            [24] 2323 	push	ar7
      008900 12 2A F2         [24] 2324 	lcall	_ak820_macro_ready
      008903 E5 82            [12] 2325 	mov	a, dpl
      008905 D0 07            [24] 2326 	pop	ar7
      008907 70 01            [24] 2327 	jnz	00106$
      008909 22               [24] 2328 	ret
      00890A                       2329 00106$:
                                   2330 ;	quantum/dynamic_keymap.c:643: p = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR;
      00890A 90 0B 3A         [24] 2331 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      00890D E4               [12] 2332 	clr	a
      00890E F0               [24] 2333 	movx	@dptr,a
      00890F 74 08            [12] 2334 	mov	a,#0x08
      008911 A3               [24] 2335 	inc	dptr
      008912 F0               [24] 2336 	movx	@dptr,a
                                   2337 ;	quantum/dynamic_keymap.c:644: uint16_t end = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR + ak820_macro_length();
      008913 C0 07            [24] 2338 	push	ar7
      008915 12 2B 2B         [24] 2339 	lcall	_ak820_macro_length
      008918 AD 82            [24] 2340 	mov	r5, dpl
      00891A AE 83            [24] 2341 	mov	r6, dph
      00891C D0 07            [24] 2342 	pop	ar7
      00891E 74 08            [12] 2343 	mov	a,#0x08
      008920 2E               [12] 2344 	add	a, r6
      008921 FE               [12] 2345 	mov	r6,a
                                   2346 ;	quantum/dynamic_keymap.c:649: while (id > 0) {
      008922 7B 00            [12] 2347 	mov	r3,#0x00
      008924 7C 08            [12] 2348 	mov	r4,#0x08
      008926                       2349 00111$:
      008926 EF               [12] 2350 	mov	a,r7
      008927 60 31            [24] 2351 	jz	00113$
                                   2352 ;	quantum/dynamic_keymap.c:653: if (p == end) {
      008929 EB               [12] 2353 	mov	a,r3
      00892A B5 05 05         [24] 2354 	cjne	a,ar5,00108$
      00892D EC               [12] 2355 	mov	a,r4
      00892E B5 06 01         [24] 2356 	cjne	a,ar6,00108$
                                   2357 ;	quantum/dynamic_keymap.c:654: return;
      008931 22               [24] 2358 	ret
      008932                       2359 00108$:
                                   2360 ;	quantum/dynamic_keymap.c:656: if (eeprom_read_byte((const uint8_t *)(uintptr_t)p) == 0) {
      008932 8B 01            [24] 2361 	mov	ar1,r3
      008934 8C 02            [24] 2362 	mov	ar2,r4
      008936 8A 00            [24] 2363 	mov	ar0,r2
      008938 7A 00            [12] 2364 	mov	r2,#0x00
      00893A 89 82            [24] 2365 	mov	dpl, r1
      00893C 88 83            [24] 2366 	mov	dph, r0
      00893E 8A F0            [24] 2367 	mov	b, r2
      008940 12 40 6F         [24] 2368 	lcall	_eeprom_read_byte
      008943 E5 82            [12] 2369 	mov	a, dpl
      008945 70 06            [24] 2370 	jnz	00110$
                                   2371 ;	quantum/dynamic_keymap.c:657: --id;
      008947 1F               [12] 2372 	dec	r7
      008948 90 0B 38         [24] 2373 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_457
      00894B EF               [12] 2374 	mov	a,r7
      00894C F0               [24] 2375 	movx	@dptr,a
      00894D                       2376 00110$:
                                   2377 ;	quantum/dynamic_keymap.c:659: ++p;
      00894D 0B               [12] 2378 	inc	r3
      00894E BB 00 01         [24] 2379 	cjne	r3,#0x00,00429$
      008951 0C               [12] 2380 	inc	r4
      008952                       2381 00429$:
      008952 90 0B 3A         [24] 2382 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      008955 12 38 65         [24] 2383 	lcall	_ak820_outline_0082
      008958 80 CC            [24] 2384 	sjmp	00111$
      00895A                       2385 00113$:
                                   2386 ;	quantum/dynamic_keymap.c:665: sending = true;
      00895A 90 0B 39         [24] 2387 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_458
      00895D 74 01            [12] 2388 	mov	a,#0x01
      00895F F0               [24] 2389 	movx	@dptr,a
                                   2390 ;	quantum/dynamic_keymap.c:667: ak820_macro_cancelled = ak820_macro_primitive = false;
      008960 12 8C 14         [24] 2391 	lcall	_ak820_outline_0161
      008963 90 09 82         [24] 2392 	mov	dptr,#_ak820_macro_cancelled
      008966 F0               [24] 2393 	movx	@dptr,a
                                   2394 ;	quantum/dynamic_keymap.c:672: char data[4] = {0, 0, 0, 0};
      008967 90 0B 3C         [24] 2395 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_470
      00896A F0               [24] 2396 	movx	@dptr,a
      00896B 90 0B 3D         [24] 2397 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0001)
      00896E F0               [24] 2398 	movx	@dptr,a
      00896F 90 0B 3E         [24] 2399 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0002)
      008972 F0               [24] 2400 	movx	@dptr,a
      008973 90 0B 3F         [24] 2401 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0003)
      008976 F0               [24] 2402 	movx	@dptr,a
                                   2403 ;	quantum/dynamic_keymap.c:675: while (p < end
      008977                       2404 00167$:
                                   2405 ;	quantum/dynamic_keymap.c:677: && !ak820_macro_cancelled
      008977 90 0B 3A         [24] 2406 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      00897A E0               [24] 2407 	movx	a,@dptr
      00897B FC               [12] 2408 	mov	r4,a
      00897C A3               [24] 2409 	inc	dptr
      00897D E0               [24] 2410 	movx	a,@dptr
      00897E FF               [12] 2411 	mov	r7,a
      00897F C3               [12] 2412 	clr	c
      008980 EC               [12] 2413 	mov	a,r4
      008981 9D               [12] 2414 	subb	a,r5
      008982 EF               [12] 2415 	mov	a,r7
      008983 9E               [12] 2416 	subb	a,r6
      008984 40 03            [24] 2417 	jc	00430$
      008986 02 8B 9B         [24] 2418 	ljmp	00169$
      008989                       2419 00430$:
      008989 90 09 82         [24] 2420 	mov	dptr,#_ak820_macro_cancelled
      00898C E0               [24] 2421 	movx	a,@dptr
      00898D 60 03            [24] 2422 	jz	00431$
      00898F 02 8B 9B         [24] 2423 	ljmp	00169$
      008992                       2424 00431$:
                                   2425 ;	quantum/dynamic_keymap.c:680: data[0] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008992 8C 02            [24] 2426 	mov	ar2,r4
      008994 8F 03            [24] 2427 	mov	ar3,r7
      008996 90 0B 3A         [24] 2428 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      008999 74 01            [12] 2429 	mov	a,#0x01
      00899B 2C               [12] 2430 	add	a, r4
      00899C F0               [24] 2431 	movx	@dptr,a
      00899D E4               [12] 2432 	clr	a
      00899E 3F               [12] 2433 	addc	a, r7
      00899F A3               [24] 2434 	inc	dptr
      0089A0 F0               [24] 2435 	movx	@dptr,a
      0089A1 7F 00            [12] 2436 	mov	r7,#0x00
      0089A3 12 38 A7         [24] 2437 	lcall	_ak820_outline_0139
      0089A6 8F F0            [24] 2438 	mov	b, r7
      0089A8 12 40 6F         [24] 2439 	lcall	_eeprom_read_byte
      0089AB AF 82            [24] 2440 	mov	r7, dpl
      0089AD 90 0B 3C         [24] 2441 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_470
      0089B0 EF               [12] 2442 	mov	a,r7
      0089B1 F0               [24] 2443 	movx	@dptr,a
                                   2444 ;	quantum/dynamic_keymap.c:681: data[1] = 0;
      0089B2 90 0B 3D         [24] 2445 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0001)
      0089B5 E4               [12] 2446 	clr	a
      0089B6 F0               [24] 2447 	movx	@dptr,a
                                   2448 ;	quantum/dynamic_keymap.c:683: if (data[0] == 0) {
      0089B7 90 0B 3C         [24] 2449 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_470
      0089BA E0               [24] 2450 	movx	a,@dptr
      0089BB 70 03            [24] 2451 	jnz	00432$
      0089BD 02 8B 9B         [24] 2452 	ljmp	00169$
      0089C0                       2453 00432$:
                                   2454 ;	quantum/dynamic_keymap.c:686: if (data[0] == SS_QMK_PREFIX) {
      0089C0 90 0B 3C         [24] 2455 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_470
      0089C3 E0               [24] 2456 	movx	a,@dptr
      0089C4 FF               [12] 2457 	mov	r7,a
      0089C5 BF 01 02         [24] 2458 	cjne	r7,#0x01,00433$
      0089C8 80 03            [24] 2459 	sjmp	00434$
      0089CA                       2460 00433$:
      0089CA 02 8B 7D         [24] 2461 	ljmp	00164$
      0089CD                       2462 00434$:
                                   2463 ;	quantum/dynamic_keymap.c:689: data[1] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      0089CD 12 8B A3         [24] 2464 	lcall	_ak820_outline_0000
      0089D0 12 40 6F         [24] 2465 	lcall	_eeprom_read_byte
      0089D3 AF 82            [24] 2466 	mov	r7, dpl
      0089D5 90 0B 3D         [24] 2467 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0001)
      0089D8 EF               [12] 2468 	mov	a,r7
      0089D9 F0               [24] 2469 	movx	@dptr,a
                                   2470 ;	quantum/dynamic_keymap.c:690: if (data[1] == 0)
      0089DA EF               [12] 2471 	mov	a,r7
      0089DB 70 03            [24] 2472 	jnz	00435$
      0089DD 02 8B 9B         [24] 2473 	ljmp	00169$
      0089E0                       2474 00435$:
                                   2475 ;	quantum/dynamic_keymap.c:692: if (data[1] == SS_TAP_CODE || data[1] == SS_DOWN_CODE || data[1] == SS_UP_CODE) {
      0089E0 12 8B DB         [24] 2476 	lcall	_ak820_outline_0092
      0089E3 BF 01 02         [24] 2477 	cjne	r7,#0x01,00436$
      0089E6 80 13            [24] 2478 	sjmp	00151$
      0089E8                       2479 00436$:
      0089E8 12 8B DB         [24] 2480 	lcall	_ak820_outline_0092
      0089EB BF 02 02         [24] 2481 	cjne	r7,#0x02,00437$
      0089EE 80 0B            [24] 2482 	sjmp	00151$
      0089F0                       2483 00437$:
      0089F0 12 8B DB         [24] 2484 	lcall	_ak820_outline_0092
      0089F3 BF 03 02         [24] 2485 	cjne	r7,#0x03,00438$
      0089F6 80 03            [24] 2486 	sjmp	00439$
      0089F8                       2487 00438$:
      0089F8 02 8A 5C         [24] 2488 	ljmp	00152$
      0089FB                       2489 00439$:
      0089FB                       2490 00151$:
                                   2491 ;	quantum/dynamic_keymap.c:694: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      0089FB 12 8B A3         [24] 2492 	lcall	_ak820_outline_0000
      0089FE 12 40 6F         [24] 2493 	lcall	_eeprom_read_byte
      008A01 12 8C 2C         [24] 2494 	lcall	_ak820_outline_0177
                                   2495 ;	quantum/dynamic_keymap.c:698: if (data[2] != 0) {
      008A04 70 03            [24] 2496 	jnz	00440$
      008A06 02 89 77         [24] 2497 	ljmp	00167$
      008A09                       2498 00440$:
                                   2499 ;	quantum/dynamic_keymap.c:700: ak820_macro_primitive = data[1] != SS_TAP_CODE;
      008A09 12 8B DB         [24] 2500 	lcall	_ak820_outline_0092
      008A0C BF 01 03         [24] 2501 	cjne	r7,#0x01,00441$
      008A0F D3               [12] 2502 	setb	c
      008A10 80 01            [24] 2503 	sjmp	00442$
      008A12                       2504 00441$:
      008A12 C3               [12] 2505 	clr	c
      008A13                       2506 00442$:
      008A13 92 24            [24] 2507 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      008A15 90 09 81         [24] 2508 	mov	dptr,#_ak820_macro_primitive
      008A18 B3               [12] 2509 	cpl	c
      008A19 E4               [12] 2510 	clr	a
      008A1A 33               [12] 2511 	rlc	a
      008A1B F0               [24] 2512 	movx	@dptr,a
                                   2513 ;	quantum/dynamic_keymap.c:702: if (data[1] == SS_TAP_CODE) tap_code((uint8_t)data[2]);
      008A1C 12 8B DB         [24] 2514 	lcall	_ak820_outline_0092
      008A1F BF 01 10         [24] 2515 	cjne	r7,#0x01,00122$
      008A22 12 8C 0D         [24] 2516 	lcall	_ak820_outline_0148
      008A25 C0 06            [24] 2517 	push	ar6
      008A27 C0 05            [24] 2518 	push	ar5
      008A29 12 73 E6         [24] 2519 	lcall	_tap_code
      008A2C D0 05            [24] 2520 	pop	ar5
      008A2E D0 06            [24] 2521 	pop	ar6
      008A30 80 24            [24] 2522 	sjmp	00123$
      008A32                       2523 00122$:
                                   2524 ;	quantum/dynamic_keymap.c:703: else if (data[1] == SS_DOWN_CODE) register_code((uint8_t)data[2]);
      008A32 12 8B DB         [24] 2525 	lcall	_ak820_outline_0092
      008A35 BF 02 10         [24] 2526 	cjne	r7,#0x02,00119$
      008A38 12 8C 0D         [24] 2527 	lcall	_ak820_outline_0148
      008A3B C0 06            [24] 2528 	push	ar6
      008A3D C0 05            [24] 2529 	push	ar5
      008A3F 12 72 E0         [24] 2530 	lcall	_register_code
      008A42 D0 05            [24] 2531 	pop	ar5
      008A44 D0 06            [24] 2532 	pop	ar6
      008A46 80 0E            [24] 2533 	sjmp	00123$
      008A48                       2534 00119$:
                                   2535 ;	quantum/dynamic_keymap.c:704: else unregister_code((uint8_t)data[2]);
      008A48 12 8C 0D         [24] 2536 	lcall	_ak820_outline_0148
      008A4B C0 06            [24] 2537 	push	ar6
      008A4D C0 05            [24] 2538 	push	ar5
      008A4F 12 73 4D         [24] 2539 	lcall	_unregister_code
      008A52 D0 05            [24] 2540 	pop	ar5
      008A54 D0 06            [24] 2541 	pop	ar6
      008A56                       2542 00123$:
                                   2543 ;	quantum/dynamic_keymap.c:706: ak820_macro_primitive = false;
      008A56 12 8C 14         [24] 2544 	lcall	_ak820_outline_0161
      008A59 02 89 77         [24] 2545 	ljmp	00167$
      008A5C                       2546 00152$:
                                   2547 ;	quantum/dynamic_keymap.c:714: } else if (data[1] == VIAL_MACRO_EXT_TAP || data[1] == VIAL_MACRO_EXT_DOWN || data[1] == VIAL_MACRO_EXT_UP) {
      008A5C 12 8B DB         [24] 2548 	lcall	_ak820_outline_0092
      008A5F BF 05 02         [24] 2549 	cjne	r7,#0x05,00447$
      008A62 80 13            [24] 2550 	sjmp	00146$
      008A64                       2551 00447$:
      008A64 12 8B DB         [24] 2552 	lcall	_ak820_outline_0092
      008A67 BF 06 02         [24] 2553 	cjne	r7,#0x06,00448$
      008A6A 80 0B            [24] 2554 	sjmp	00146$
      008A6C                       2555 00448$:
      008A6C 12 8B DB         [24] 2556 	lcall	_ak820_outline_0092
      008A6F BF 07 02         [24] 2557 	cjne	r7,#0x07,00449$
      008A72 80 03            [24] 2558 	sjmp	00450$
      008A74                       2559 00449$:
      008A74 02 8B 1D         [24] 2560 	ljmp	00147$
      008A77                       2561 00450$:
      008A77                       2562 00146$:
                                   2563 ;	quantum/dynamic_keymap.c:715: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008A77 12 8B A3         [24] 2564 	lcall	_ak820_outline_0000
      008A7A 12 40 6F         [24] 2565 	lcall	_eeprom_read_byte
      008A7D 12 8C 2C         [24] 2566 	lcall	_ak820_outline_0177
                                   2567 ;	quantum/dynamic_keymap.c:716: if (data[2] != 0) {
      008A80 70 03            [24] 2568 	jnz	00451$
      008A82 02 89 77         [24] 2569 	ljmp	00167$
      008A85                       2570 00451$:
                                   2571 ;	quantum/dynamic_keymap.c:717: data[3] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008A85 12 8B A3         [24] 2572 	lcall	_ak820_outline_0000
      008A88 12 40 6F         [24] 2573 	lcall	_eeprom_read_byte
      008A8B AF 82            [24] 2574 	mov	r7, dpl
      008A8D 90 0B 3F         [24] 2575 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0003)
      008A90 EF               [12] 2576 	mov	a,r7
      008A91 F0               [24] 2577 	movx	@dptr,a
                                   2578 ;	quantum/dynamic_keymap.c:718: if (data[3] != 0) {
      008A92 EF               [12] 2579 	mov	a,r7
      008A93 70 03            [24] 2580 	jnz	00452$
      008A95 02 89 77         [24] 2581 	ljmp	00167$
      008A98                       2582 00452$:
                                   2583 ;	quantum/dynamic_keymap.c:721: kc = (uint8_t)data[2] | ((uint16_t)(uint8_t)data[3] << 8);
      008A98 90 0B 3E         [24] 2584 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0002)
      008A9B E0               [24] 2585 	movx	a,@dptr
      008A9C FF               [12] 2586 	mov	r7,a
      008A9D 90 0B 3F         [24] 2587 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0003)
      008AA0 E0               [24] 2588 	movx	a,@dptr
      008AA1 FB               [12] 2589 	mov	r3,a
      008AA2 E4               [12] 2590 	clr	a
      008AA3 FC               [12] 2591 	mov	r4,a
      008AA4 FA               [12] 2592 	mov	r2,a
      008AA5 EF               [12] 2593 	mov	a,r7
      008AA6 42 04            [12] 2594 	orl	ar4,a
      008AA8 EA               [12] 2595 	mov	a,r2
      008AA9 42 03            [12] 2596 	orl	ar3,a
                                   2597 ;	quantum/dynamic_keymap.c:725: kc = decode_keycode(kc);
      008AAB 12 43 82         [24] 2598 	lcall	_ak820_outline_0179
      008AAE C0 06            [24] 2599 	push	ar6
      008AB0 C0 05            [24] 2600 	push	ar5
      008AB2 12 88 C3         [24] 2601 	lcall	_decode_keycode
      008AB5 AC 82            [24] 2602 	mov	r4, dpl
      008AB7 AF 83            [24] 2603 	mov	r7, dph
      008AB9 D0 05            [24] 2604 	pop	ar5
      008ABB D0 06            [24] 2605 	pop	ar6
                                   2606 ;	quantum/dynamic_keymap.c:727: ak820_macro_primitive = data[1] != VIAL_MACRO_EXT_TAP;
      008ABD 90 0B 3D         [24] 2607 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0001)
      008AC0 E0               [24] 2608 	movx	a,@dptr
      008AC1 FB               [12] 2609 	mov	r3,a
      008AC2 BB 05 03         [24] 2610 	cjne	r3,#0x05,00453$
      008AC5 D3               [12] 2611 	setb	c
      008AC6 80 01            [24] 2612 	sjmp	00454$
      008AC8                       2613 00453$:
      008AC8 C3               [12] 2614 	clr	c
      008AC9                       2615 00454$:
      008AC9 92 24            [24] 2616 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      008ACB 90 09 81         [24] 2617 	mov	dptr,#_ak820_macro_primitive
      008ACE B3               [12] 2618 	cpl	c
      008ACF E4               [12] 2619 	clr	a
      008AD0 33               [12] 2620 	rlc	a
      008AD1 F0               [24] 2621 	movx	@dptr,a
                                   2622 ;	quantum/dynamic_keymap.c:729: switch (data[1]) {
      008AD2 90 0B 3D         [24] 2623 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0001)
      008AD5 E0               [24] 2624 	movx	a,@dptr
      008AD6 FB               [12] 2625 	mov	r3,a
      008AD7 BB 05 02         [24] 2626 	cjne	r3,#0x05,00455$
      008ADA 80 0A            [24] 2627 	sjmp	00126$
      008ADC                       2628 00455$:
      008ADC BB 06 02         [24] 2629 	cjne	r3,#0x06,00456$
      008ADF 80 16            [24] 2630 	sjmp	00127$
      008AE1                       2631 00456$:
                                   2632 ;	quantum/dynamic_keymap.c:730: case VIAL_MACRO_EXT_TAP:
      008AE1 BB 07 33         [24] 2633 	cjne	r3,#0x07,00129$
      008AE4 80 22            [24] 2634 	sjmp	00128$
      008AE6                       2635 00126$:
                                   2636 ;	quantum/dynamic_keymap.c:731: vial_keycode_tap(kc);
      008AE6 8C 82            [24] 2637 	mov	dpl, r4
      008AE8 8F 83            [24] 2638 	mov	dph, r7
      008AEA C0 06            [24] 2639 	push	ar6
      008AEC C0 05            [24] 2640 	push	ar5
      008AEE 12 AF 9D         [24] 2641 	lcall	_vial_keycode_tap
      008AF1 D0 05            [24] 2642 	pop	ar5
      008AF3 D0 06            [24] 2643 	pop	ar6
                                   2644 ;	quantum/dynamic_keymap.c:732: break;
                                   2645 ;	quantum/dynamic_keymap.c:733: case VIAL_MACRO_EXT_DOWN:
      008AF5 80 20            [24] 2646 	sjmp	00129$
      008AF7                       2647 00127$:
                                   2648 ;	quantum/dynamic_keymap.c:734: vial_keycode_down(kc);
      008AF7 8C 82            [24] 2649 	mov	dpl, r4
      008AF9 8F 83            [24] 2650 	mov	dph, r7
      008AFB C0 06            [24] 2651 	push	ar6
      008AFD C0 05            [24] 2652 	push	ar5
      008AFF 12 AE D2         [24] 2653 	lcall	_vial_keycode_down
      008B02 D0 05            [24] 2654 	pop	ar5
      008B04 D0 06            [24] 2655 	pop	ar6
                                   2656 ;	quantum/dynamic_keymap.c:735: break;
                                   2657 ;	quantum/dynamic_keymap.c:736: case VIAL_MACRO_EXT_UP:
      008B06 80 0F            [24] 2658 	sjmp	00129$
      008B08                       2659 00128$:
                                   2660 ;	quantum/dynamic_keymap.c:737: vial_keycode_up(kc);
      008B08 8C 82            [24] 2661 	mov	dpl, r4
      008B0A 8F 83            [24] 2662 	mov	dph, r7
      008B0C C0 06            [24] 2663 	push	ar6
      008B0E C0 05            [24] 2664 	push	ar5
      008B10 12 AF 38         [24] 2665 	lcall	_vial_keycode_up
      008B13 D0 05            [24] 2666 	pop	ar5
      008B15 D0 06            [24] 2667 	pop	ar6
                                   2668 ;	quantum/dynamic_keymap.c:739: }
      008B17                       2669 00129$:
                                   2670 ;	quantum/dynamic_keymap.c:741: ak820_macro_primitive = false;
      008B17 12 8C 14         [24] 2671 	lcall	_ak820_outline_0161
      008B1A 02 89 77         [24] 2672 	ljmp	00167$
      008B1D                       2673 00147$:
                                   2674 ;	quantum/dynamic_keymap.c:745: } else if (data[1] == SS_DELAY_CODE) {
      008B1D 12 8B DB         [24] 2675 	lcall	_ak820_outline_0092
      008B20 BF 04 02         [24] 2676 	cjne	r7,#0x04,00458$
      008B23 80 03            [24] 2677 	sjmp	00459$
      008B25                       2678 00458$:
      008B25 02 89 77         [24] 2679 	ljmp	00167$
      008B28                       2680 00459$:
                                   2681 ;	quantum/dynamic_keymap.c:747: uint8_t d0 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008B28 12 8B A3         [24] 2682 	lcall	_ak820_outline_0000
      008B2B 12 40 6F         [24] 2683 	lcall	_eeprom_read_byte
      008B2E AF 82            [24] 2684 	mov	r7, dpl
                                   2685 ;	quantum/dynamic_keymap.c:748: uint8_t d1 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008B30 90 0B 3A         [24] 2686 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      008B33 12 38 8C         [24] 2687 	lcall	_ak820_outline_0119
      008B36 90 0B 3A         [24] 2688 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      008B39 74 01            [12] 2689 	mov	a,#0x01
      008B3B 2B               [12] 2690 	add	a, r3
      008B3C F0               [24] 2691 	movx	@dptr,a
      008B3D E4               [12] 2692 	clr	a
      008B3E 3C               [12] 2693 	addc	a, r4
      008B3F A3               [24] 2694 	inc	dptr
      008B40 F0               [24] 2695 	movx	@dptr,a
      008B41 7A 00            [12] 2696 	mov	r2,#0x00
      008B43 12 33 FC         [24] 2697 	lcall	_ak820_outline_0120
      008B46 8A F0            [24] 2698 	mov	b, r2
      008B48 12 40 6F         [24] 2699 	lcall	_eeprom_read_byte
      008B4B AC 82            [24] 2700 	mov	r4, dpl
                                   2701 ;	quantum/dynamic_keymap.c:749: if (d0 == 0 || d1 == 0)
      008B4D EF               [12] 2702 	mov	a,r7
      008B4E 60 4B            [24] 2703 	jz	00169$
      008B50 EC               [12] 2704 	mov	a,r4
      008B51 60 48            [24] 2705 	jz	00169$
                                   2706 ;	quantum/dynamic_keymap.c:752: uint16_t ms = (uint16_t)(d0 - 1) + (uint16_t)(d1 - 1) * 255u;
      008B53 1F               [12] 2707 	dec	r7
      008B54 1C               [12] 2708 	dec	r4
      008B55 EC               [12] 2709 	mov	a,r4
      008B56 75 F0 FF         [24] 2710 	mov	b,#0xff
      008B59 A4               [48] 2711 	mul	ab
      008B5A FC               [12] 2712 	mov	r4,a
      008B5B AB F0            [24] 2713 	mov	r3,b
      008B5D 7A 00            [12] 2714 	mov	r2,#0x00
      008B5F EC               [12] 2715 	mov	a,r4
      008B60 2F               [12] 2716 	add	a, r7
      008B61 FC               [12] 2717 	mov	r4,a
      008B62 EB               [12] 2718 	mov	a,r3
      008B63 3A               [12] 2719 	addc	a, r2
      008B64 FB               [12] 2720 	mov	r3,a
                                   2721 ;	quantum/dynamic_keymap.c:753: while (ms--) wait_ms(1);
      008B65                       2722 00141$:
      008B65 8C 02            [24] 2723 	mov	ar2,r4
      008B67 8B 07            [24] 2724 	mov	ar7,r3
      008B69 1C               [12] 2725 	dec	r4
      008B6A BC FF 01         [24] 2726 	cjne	r4,#0xff,00462$
      008B6D 1B               [12] 2727 	dec	r3
      008B6E                       2728 00462$:
      008B6E EA               [12] 2729 	mov	a,r2
      008B6F 4F               [12] 2730 	orl	a,r7
      008B70 70 03            [24] 2731 	jnz	00463$
      008B72 02 89 77         [24] 2732 	ljmp	00167$
      008B75                       2733 00463$:
      008B75 90 00 01         [24] 2734 	mov	dptr,#0x0001
      008B78 12 57 69         [24] 2735 	lcall	_mDelaymS
      008B7B 80 E8            [24] 2736 	sjmp	00141$
      008B7D                       2737 00164$:
                                   2738 ;	quantum/dynamic_keymap.c:759: if ((uint8_t)data[0] >= 128) break;
      008B7D 90 0B 3C         [24] 2739 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_470
      008B80 E0               [24] 2740 	movx	a,@dptr
      008B81 FF               [12] 2741 	mov	r7,a
      008B82 BF 80 00         [24] 2742 	cjne	r7,#0x80,00464$
      008B85                       2743 00464$:
      008B85 50 14            [24] 2744 	jnc	00169$
                                   2745 ;	quantum/dynamic_keymap.c:763: send_char(data[0]);
      008B87 90 0B 3C         [24] 2746 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_470
      008B8A E0               [24] 2747 	movx	a,@dptr
      008B8B F5 82            [12] 2748 	mov	dpl,a
      008B8D C0 06            [24] 2749 	push	ar6
      008B8F C0 05            [24] 2750 	push	ar5
      008B91 12 A2 42         [24] 2751 	lcall	_send_char
      008B94 D0 05            [24] 2752 	pop	ar5
      008B96 D0 06            [24] 2753 	pop	ar6
                                   2754 ;	quantum/dynamic_keymap.c:764: for (uint8_t delay = DYNAMIC_KEYMAP_MACRO_DELAY; delay; --delay) wait_ms(1);
      008B98 02 89 77         [24] 2755 	ljmp	00167$
      008B9B                       2756 00169$:
                                   2757 ;	quantum/dynamic_keymap.c:772: ak820_macro_primitive = false;
      008B9B 12 8C 14         [24] 2758 	lcall	_ak820_outline_0161
                                   2759 ;	quantum/dynamic_keymap.c:774: sending = false;
      008B9E 90 0B 39         [24] 2760 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_458
      008BA1 F0               [24] 2761 	movx	@dptr,a
                                   2762 ;	quantum/dynamic_keymap.c:776: }
      008BA2 22               [24] 2763 	ret
                                   2764 	.area CSEG    (CODE)
                                   2765 	.area CONST   (CODE)
                                   2766 	.area XINIT   (CODE)
                                   2767 	.area CABS    (ABS,CODE)
                                   2768 
                                   2769 ; Experimental exact instruction outlining.
                                   2770 	.globl _ak820_outline_0000
                                   2771 	.globl _ak820_outline_0005
                                   2772 	.globl _ak820_outline_0008
                                   2773 	.globl _ak820_outline_0020
                                   2774 	.globl _ak820_outline_0025
                                   2775 	.globl _ak820_outline_0032
                                   2776 	.globl _ak820_outline_0038
                                   2777 	.globl _ak820_outline_0046
                                   2778 	.globl _ak820_outline_0050
                                   2779 	.globl _ak820_outline_0052
                                   2780 	.globl _ak820_outline_0058
                                   2781 	.globl _ak820_outline_0060
                                   2782 	.globl _ak820_outline_0061
                                   2783 	.globl _ak820_outline_0071
                                   2784 	.globl _ak820_outline_0077
                                   2785 	.globl _ak820_outline_0078
                                   2786 	.globl _ak820_outline_0082
                                   2787 	.globl _ak820_outline_0088
                                   2788 	.globl _ak820_outline_0090
                                   2789 	.globl _ak820_outline_0092
                                   2790 	.globl _ak820_outline_0097
                                   2791 	.globl _ak820_outline_0100
                                   2792 	.globl _ak820_outline_0101
                                   2793 	.globl _ak820_outline_0106
                                   2794 	.globl _ak820_outline_0110
                                   2795 	.globl _ak820_outline_0112
                                   2796 	.globl _ak820_outline_0113
                                   2797 	.globl _ak820_outline_0114
                                   2798 	.globl _ak820_outline_0117
                                   2799 	.globl _ak820_outline_0119
                                   2800 	.globl _ak820_outline_0120
                                   2801 	.globl _ak820_outline_0121
                                   2802 	.globl _ak820_outline_0122
                                   2803 	.globl _ak820_outline_0126
                                   2804 	.globl _ak820_outline_0130
                                   2805 	.globl _ak820_outline_0131
                                   2806 	.globl _ak820_outline_0132
                                   2807 	.globl _ak820_outline_0133
                                   2808 	.globl _ak820_outline_0138
                                   2809 	.globl _ak820_outline_0139
                                   2810 	.globl _ak820_outline_0144
                                   2811 	.globl _ak820_outline_0145
                                   2812 	.globl _ak820_outline_0148
                                   2813 	.globl _ak820_outline_0152
                                   2814 	.globl _ak820_outline_0156
                                   2815 	.globl _ak820_outline_0161
                                   2816 	.globl _ak820_outline_0166
                                   2817 	.globl _ak820_outline_0173
                                   2818 	.globl _ak820_outline_0174
                                   2819 	.globl _ak820_outline_0177
                                   2820 	.globl _ak820_outline_0178
                                   2821 	.globl _ak820_outline_0179
                                   2822 	.globl _ak820_outline_0184
                                   2823 
                                   2824 	.area CSEG (CODE)
                                   2825 ; function ak820_outline_0000
      008BA3                       2826 _ak820_outline_0000:
      008BA3 90 0B 3A         [24] 2827 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      008BA6 E0               [24] 2828 	movx	a,@dptr
      008BA7 FC               [12] 2829 	mov	r4,a
      008BA8 A3               [24] 2830 	inc	dptr
      008BA9 E0               [24] 2831 	movx	a,@dptr
      008BAA FF               [12] 2832 	mov	r7,a
      008BAB 90 0B 3A         [24] 2833 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      008BAE 74 01            [12] 2834 	mov	a,#0x01
      008BB0 2C               [12] 2835 	add	a,r4
      008BB1 F0               [24] 2836 	movx	@dptr,a
      008BB2 E4               [12] 2837 	clr	a
      008BB3 3F               [12] 2838 	addc	a,r7
      008BB4 A3               [24] 2839 	inc	dptr
      008BB5 F0               [24] 2840 	movx	@dptr,a
      008BB6 7B 00            [12] 2841 	mov	r3,#0x00
      008BB8 8C 82            [24] 2842 	mov	dpl,r4
      008BBA 8F 83            [24] 2843 	mov	dph,r7
      008BBC 8B F0            [24] 2844 	mov	b,r3
      008BBE 22               [24] 2845 	ret
                                   2846 
                                   2847 	.area CSEG (CODE)
                                   2848 ; function ak820_outline_0025
      008BBF                       2849 _ak820_outline_0025:
      008BBF 2D               [12] 2850 	add	a,r5
      008BC0 F9               [12] 2851 	mov	r1,a
      008BC1 E4               [12] 2852 	clr	a
      008BC2 3E               [12] 2853 	addc	a,r6
      008BC3 FA               [12] 2854 	mov	r2,a
      008BC4 8F 03            [24] 2855 	mov	ar3,r7
      008BC6 89 82            [24] 2856 	mov	dpl,r1
      008BC8 8A 83            [24] 2857 	mov	dph,r2
      008BCA 8B F0            [24] 2858 	mov	b,r3
      008BCC 22               [24] 2859 	ret
                                   2860 
                                   2861 	.area CSEG (CODE)
                                   2862 ; function ak820_outline_0078
      008BCD                       2863 _ak820_outline_0078:
      008BCD ED               [12] 2864 	mov	a,r5
      008BCE 75 F0 0A         [24] 2865 	mov	b,#0x0a
      008BD1 A4               [48] 2866 	mul	ab
      008BD2 24 58            [12] 2867 	add	a,#0x58
      008BD4 FC               [12] 2868 	mov	r4,a
      008BD5 74 06            [12] 2869 	mov	a,#0x06
      008BD7 35 F0            [12] 2870 	addc	a,b
      008BD9 FD               [12] 2871 	mov	r5,a
      008BDA 22               [24] 2872 	ret
                                   2873 
                                   2874 	.area CSEG (CODE)
                                   2875 ; function ak820_outline_0092
      008BDB                       2876 _ak820_outline_0092:
      008BDB 90 0B 3D         [24] 2877 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470+0x0001)
      008BDE E0               [24] 2878 	movx	a,@dptr
      008BDF FF               [12] 2879 	mov	r7,a
      008BE0 22               [24] 2880 	ret
                                   2881 
                                   2882 	.area CSEG (CODE)
                                   2883 ; function ak820_outline_0097
      008BE1                       2884 _ak820_outline_0097:
      008BE1 90 0A D3         [24] 2885 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      008BE4 EE               [12] 2886 	mov	a,r6
      008BE5 F0               [24] 2887 	movx	@dptr,a
      008BE6 90 0A D4         [24] 2888 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      008BE9 ED               [12] 2889 	mov	a,r5
      008BEA F0               [24] 2890 	movx	@dptr,a
      008BEB 8F 82            [24] 2891 	mov	dpl,r7
      008BED 22               [24] 2892 	ret
                                   2893 
                                   2894 	.area CSEG (CODE)
                                   2895 ; function ak820_outline_0106
      008BEE                       2896 _ak820_outline_0106:
      008BEE 74 0A            [12] 2897 	mov	a,#0x0a
      008BF0 F0               [24] 2898 	movx	@dptr,a
      008BF1 E4               [12] 2899 	clr	a
      008BF2 A3               [24] 2900 	inc	dptr
      008BF3 F0               [24] 2901 	movx	@dptr,a
      008BF4 22               [24] 2902 	ret
                                   2903 
                                   2904 	.area CSEG (CODE)
                                   2905 ; function ak820_outline_0110
      008BF5                       2906 _ak820_outline_0110:
      008BF5 AD 82            [24] 2907 	mov	r5,dpl
      008BF7 AE 83            [24] 2908 	mov	r6,dph
      008BF9 AF F0            [24] 2909 	mov	r7,b
      008BFB 22               [24] 2910 	ret
                                   2911 
                                   2912 	.area CSEG (CODE)
                                   2913 ; function ak820_outline_0126
      008BFC                       2914 _ak820_outline_0126:
      008BFC 28               [12] 2915 	add	a,r0
      008BFD F5 82            [12] 2916 	mov	dpl,a
      008BFF EF               [12] 2917 	mov	a,r7
      008C00 39               [12] 2918 	addc	a,r1
      008C01 F5 83            [12] 2919 	mov	dph,a
      008C03 74 FF            [12] 2920 	mov	a,#0xff
      008C05 F0               [24] 2921 	movx	@dptr,a
      008C06 22               [24] 2922 	ret
                                   2923 
                                   2924 	.area CSEG (CODE)
                                   2925 ; function ak820_outline_0132
      008C07                       2926 _ak820_outline_0132:
      008C07 2D               [12] 2927 	add	a,r5
      008C08 F9               [12] 2928 	mov	r1,a
      008C09 E4               [12] 2929 	clr	a
      008C0A 3E               [12] 2930 	addc	a,r6
      008C0B FA               [12] 2931 	mov	r2,a
      008C0C 22               [24] 2932 	ret
                                   2933 
                                   2934 	.area CSEG (CODE)
                                   2935 ; function ak820_outline_0148
      008C0D                       2936 _ak820_outline_0148:
      008C0D 90 0B 3E         [24] 2937 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470+0x0002)
      008C10 E0               [24] 2938 	movx	a,@dptr
      008C11 F5 82            [12] 2939 	mov	dpl,a
      008C13 22               [24] 2940 	ret
                                   2941 
                                   2942 	.area CSEG (CODE)
                                   2943 ; function ak820_outline_0161
      008C14                       2944 _ak820_outline_0161:
      008C14 90 09 81         [24] 2945 	mov	dptr,#_ak820_macro_primitive
      008C17 E4               [12] 2946 	clr	a
      008C18 F0               [24] 2947 	movx	@dptr,a
      008C19 22               [24] 2948 	ret
                                   2949 
                                   2950 	.area CSEG (CODE)
                                   2951 ; function ak820_outline_0173
      008C1A                       2952 _ak820_outline_0173:
      008C1A 90 0A E3         [24] 2953 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      008C1D E4               [12] 2954 	clr	a
      008C1E F0               [24] 2955 	movx	@dptr,a
      008C1F 90 0A E4         [24] 2956 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      008C22 22               [24] 2957 	ret
                                   2958 
                                   2959 	.area CSEG (CODE)
                                   2960 ; function ak820_outline_0174
      008C23                       2961 _ak820_outline_0174:
      008C23 90 0B 99         [24] 2962 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_2
      008C26 E4               [12] 2963 	clr	a
      008C27 F0               [24] 2964 	movx	@dptr,a
      008C28 90 0B 9A         [24] 2965 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_3
      008C2B 22               [24] 2966 	ret
                                   2967 
                                   2968 	.area CSEG (CODE)
                                   2969 ; function ak820_outline_0177
      008C2C                       2970 _ak820_outline_0177:
      008C2C AF 82            [24] 2971 	mov	r7,dpl
      008C2E 90 0B 3E         [24] 2972 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470+0x0002)
      008C31 EF               [12] 2973 	mov	a,r7
      008C32 F0               [24] 2974 	movx	@dptr,a
      008C33 EF               [12] 2975 	mov	a,r7
      008C34 22               [24] 2976 	ret
                                   2977 
                                   2978 	.area CSEG (CODE)
                                   2979 ; function ak820_outline_0184
      008C35                       2980 _ak820_outline_0184:
      008C35 F0               [24] 2981 	movx	@dptr,a
      008C36 EB               [12] 2982 	mov	a,r3
      008C37 A3               [24] 2983 	inc	dptr
      008C38 F0               [24] 2984 	movx	@dptr,a
      008C39 22               [24] 2985 	ret
