                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_combo_cancel
                                     12 	.globl _ak820_combo_tick
                                     13 	.globl _ak820_autoshift_cancel
                                     14 	.globl _ak820_autoshift_process
                                     15 	.globl _ak820_autoshift_before
                                     16 	.globl _ak820_oneshot_cancel
                                     17 	.globl _ak820_oneshot_post
                                     18 	.globl _ak820_oneshot_process
                                     19 	.globl _ak820_tapping_source
                                     20 	.globl _ak820_tapping_cancel
                                     21 	.globl _ak820_tapping_process
                                     22 	.globl _ak820_tapping_before
                                     23 	.globl _pre_process_record_quantum
                                     24 	.globl _get_record_keycode
                                     25 	.globl _repeat_key_cancel
                                     26 	.globl _clear_owned_usages
                                     27 	.globl _owned_usage_key
                                     28 	.globl _clear_owned_keys
                                     29 	.globl _del_owned_key
                                     30 	.globl _add_owned_key
                                     31 	.globl _clear_owned_mods
                                     32 	.globl _del_owned_weak_mods
                                     33 	.globl _add_owned_weak_mods
                                     34 	.globl _del_owned_mods
                                     35 	.globl _add_owned_mods
                                     36 	.globl _clear_weak_mods
                                     37 	.globl _clear_mods
                                     38 	.globl _send_keyboard_report
                                     39 	.globl _layer_hold_clear
                                     40 	.globl _layer_hold_off
                                     41 	.globl _layer_hold_on
                                     42 	.globl _ak820_resolve_key
                                     43 	.globl _layer_xor
                                     44 	.globl _layer_and
                                     45 	.globl _layer_or
                                     46 	.globl _layer_off
                                     47 	.globl _layer_on
                                     48 	.globl _layer_move
                                     49 	.globl _layer_clear
                                     50 	.globl _layer_state_set
                                     51 	.globl _default_layer_xor
                                     52 	.globl _default_layer_and
                                     53 	.globl _default_layer_or
                                     54 	.globl _default_layer_set
                                     55 	.globl _post_process_record_quantum
                                     56 	.globl _process_record_quantum
                                     57 	.globl _action_for_keycode
                                     58 	.globl _mDelaymS
                                     59 	.globl _host_consumer_send
                                     60 	.globl _host_system_send
                                     61 	.globl _host_keyboard_leds
                                     62 	.globl _led_set
                                     63 	.globl _clear_keys_from_report
                                     64 	.globl ___memcpy
                                     65 	.globl _ADC_START
                                     66 	.globl _S0_R_FIFO
                                     67 	.globl _S0_T_FIFO
                                     68 	.globl _S0_FREE
                                     69 	.globl _S0_IF_BYTE
                                     70 	.globl _S0_IF_FIRST
                                     71 	.globl _S0_IF_OV
                                     72 	.globl _S0_FST_ACT
                                     73 	.globl _CP_RL2
                                     74 	.globl _C_T2
                                     75 	.globl _TR2
                                     76 	.globl _EXEN2
                                     77 	.globl _TCLK
                                     78 	.globl _RCLK
                                     79 	.globl _EXF2
                                     80 	.globl _CAP1F
                                     81 	.globl _TF2
                                     82 	.globl _RI
                                     83 	.globl _TI
                                     84 	.globl _RB8
                                     85 	.globl _TB8
                                     86 	.globl _REN
                                     87 	.globl _SM2
                                     88 	.globl _SM1
                                     89 	.globl _SM0
                                     90 	.globl _IT0
                                     91 	.globl _IE0
                                     92 	.globl _IT1
                                     93 	.globl _IE1
                                     94 	.globl _TR0
                                     95 	.globl _TF0
                                     96 	.globl _TR1
                                     97 	.globl _TF1
                                     98 	.globl _P4_0
                                     99 	.globl _P4_1
                                    100 	.globl _P4_2
                                    101 	.globl _P4_3
                                    102 	.globl _P4_4
                                    103 	.globl _P4_5
                                    104 	.globl _P4_6
                                    105 	.globl _RXD
                                    106 	.globl _TXD
                                    107 	.globl _INT0
                                    108 	.globl _INT1
                                    109 	.globl _T0
                                    110 	.globl _T1
                                    111 	.globl _MOSI1
                                    112 	.globl _MISO1
                                    113 	.globl _SCK1
                                    114 	.globl _P3_0
                                    115 	.globl _P3_1
                                    116 	.globl _P3_2
                                    117 	.globl _P3_3
                                    118 	.globl _P3_4
                                    119 	.globl _P3_5
                                    120 	.globl _P3_6
                                    121 	.globl _P3_7
                                    122 	.globl _CAP1_
                                    123 	.globl _T2_
                                    124 	.globl _CAP2_
                                    125 	.globl _T2EX_
                                    126 	.globl _RXD1
                                    127 	.globl _TXD1
                                    128 	.globl _P2_0
                                    129 	.globl _P2_1
                                    130 	.globl _P2_2
                                    131 	.globl _P2_3
                                    132 	.globl _P2_4
                                    133 	.globl _P2_5
                                    134 	.globl _P2_6
                                    135 	.globl _P2_7
                                    136 	.globl _AIN0
                                    137 	.globl _AIN1
                                    138 	.globl _AIN2
                                    139 	.globl _AIN3
                                    140 	.globl _AIN4
                                    141 	.globl _AIN5
                                    142 	.globl _AIN6
                                    143 	.globl _AIN7
                                    144 	.globl _CAP1
                                    145 	.globl _T2
                                    146 	.globl _CAP2
                                    147 	.globl _T2EX
                                    148 	.globl _INT0_
                                    149 	.globl _SCS
                                    150 	.globl _MOSI
                                    151 	.globl _MISO
                                    152 	.globl _SCK
                                    153 	.globl _RXD1_
                                    154 	.globl _TXD1_
                                    155 	.globl _P1_0
                                    156 	.globl _P1_1
                                    157 	.globl _P1_2
                                    158 	.globl _P1_3
                                    159 	.globl _P1_4
                                    160 	.globl _P1_5
                                    161 	.globl _P1_6
                                    162 	.globl _P1_7
                                    163 	.globl _AIN8
                                    164 	.globl _AIN9
                                    165 	.globl _AIN10
                                    166 	.globl _AIN11
                                    167 	.globl _AIN12
                                    168 	.globl _AIN13
                                    169 	.globl _RXD_
                                    170 	.globl _TXD_
                                    171 	.globl _SCL0
                                    172 	.globl _SDA0
                                    173 	.globl _P0_0
                                    174 	.globl _P0_1
                                    175 	.globl _P0_2
                                    176 	.globl _P0_3
                                    177 	.globl _P0_4
                                    178 	.globl _P0_5
                                    179 	.globl _P0_6
                                    180 	.globl _P0_7
                                    181 	.globl _IE_SPI0
                                    182 	.globl _IE_USB
                                    183 	.globl _IE_ADC
                                    184 	.globl _IE_UART1
                                    185 	.globl _IE_PWM_I2C
                                    186 	.globl _IE_GPIO
                                    187 	.globl _IE_WDOG
                                    188 	.globl _PX0
                                    189 	.globl _PT0
                                    190 	.globl _PX1
                                    191 	.globl _PT1
                                    192 	.globl _PS
                                    193 	.globl _PT2
                                    194 	.globl _PL_FLAG
                                    195 	.globl _PH_FLAG
                                    196 	.globl _EX0
                                    197 	.globl _ET0
                                    198 	.globl _EX1
                                    199 	.globl _ET1
                                    200 	.globl _ES
                                    201 	.globl _ET2
                                    202 	.globl _E_DIS
                                    203 	.globl _EA
                                    204 	.globl _P
                                    205 	.globl _F1
                                    206 	.globl _OV
                                    207 	.globl _RS0
                                    208 	.globl _RS1
                                    209 	.globl _F0
                                    210 	.globl _AC
                                    211 	.globl _CY
                                    212 	.globl _I2CS_INT_ST
                                    213 	.globl _I2CX_INT
                                    214 	.globl _LED_STATUS
                                    215 	.globl _LED_DMA_H
                                    216 	.globl _LED_DMA_L
                                    217 	.globl _LED_DMA
                                    218 	.globl _LED_PWM_OE
                                    219 	.globl _LED_COMMON
                                    220 	.globl _ADC_CHAN
                                    221 	.globl _ADC_DAT_H
                                    222 	.globl _ADC_DAT_L
                                    223 	.globl _ADC_DAT
                                    224 	.globl _ADC_CTRL
                                    225 	.globl _SPI1_CK_SE
                                    226 	.globl _SPI1_CTRL
                                    227 	.globl _SPI1_DATA
                                    228 	.globl _SPI1_STAT
                                    229 	.globl _SIF1
                                    230 	.globl _SBAUD1
                                    231 	.globl _SBUF1
                                    232 	.globl _SCON1
                                    233 	.globl _SPI0_SETUP
                                    234 	.globl _SPI0_CK_SE
                                    235 	.globl _SPI0_CTRL
                                    236 	.globl _SPI0_DATA
                                    237 	.globl _SPI0_STAT
                                    238 	.globl _T2CAP1H
                                    239 	.globl _T2CAP1L
                                    240 	.globl _T2CAP1
                                    241 	.globl _TH2
                                    242 	.globl _TL2
                                    243 	.globl _T2COUNT
                                    244 	.globl _RCAP2H
                                    245 	.globl _RCAP2L
                                    246 	.globl _RCAP2
                                    247 	.globl _T2MOD
                                    248 	.globl _T2CON
                                    249 	.globl _SBUF
                                    250 	.globl _SCON
                                    251 	.globl _TH1
                                    252 	.globl _TH0
                                    253 	.globl _TL1
                                    254 	.globl _TL0
                                    255 	.globl _TMOD
                                    256 	.globl _TCON
                                    257 	.globl _XBUS_AUX
                                    258 	.globl _P7
                                    259 	.globl _P6_DIR
                                    260 	.globl _P6_OUT_PU
                                    261 	.globl _P6_IN
                                    262 	.globl _P5_DIR
                                    263 	.globl _P5_OUT_PU
                                    264 	.globl _P5_IN
                                    265 	.globl _P4_LED_KEY
                                    266 	.globl _P4_DIR_PU
                                    267 	.globl _P4_MOD_OC
                                    268 	.globl _P4
                                    269 	.globl _P3_DIR_PU
                                    270 	.globl _P3_MOD_OC
                                    271 	.globl _P3
                                    272 	.globl _P2_DIR_PU
                                    273 	.globl _P2_MOD_OC
                                    274 	.globl _P2
                                    275 	.globl _P1_DIR_PU
                                    276 	.globl _P1_MOD_OC
                                    277 	.globl _P1
                                    278 	.globl _P0_DIR_PU
                                    279 	.globl _P0_MOD_OC
                                    280 	.globl _P0
                                    281 	.globl _ROM_CTRL
                                    282 	.globl _ROM_DATA_HH
                                    283 	.globl _ROM_DATA_HL
                                    284 	.globl _ROM_DATA_HI
                                    285 	.globl _ROM_ADDR_H
                                    286 	.globl _ROM_ADDR_L
                                    287 	.globl _ROM_ADDR
                                    288 	.globl _GPIO_IE
                                    289 	.globl _IP_EX
                                    290 	.globl _IE_EX
                                    291 	.globl _IP
                                    292 	.globl _IE
                                    293 	.globl _WDOG_COUNT
                                    294 	.globl _RESET_KEEP
                                    295 	.globl _WAKE_CTRL
                                    296 	.globl _CLOCK_CFG
                                    297 	.globl _POWER_CFG
                                    298 	.globl _PCON
                                    299 	.globl _GLOBAL_CFG
                                    300 	.globl _SAFE_MOD
                                    301 	.globl _DPH
                                    302 	.globl _DPL
                                    303 	.globl _SP
                                    304 	.globl _A_INV
                                    305 	.globl _B
                                    306 	.globl _ACC
                                    307 	.globl _PSW
                                    308 	.globl _disable_action_cache
                                    309 	.globl _tap_code_delay_PARM_2
                                    310 	.globl _process_action_PARM_2
                                    311 	.globl _action_exec_PARM_1
                                    312 	.globl _tp_buttons
                                    313 	.globl _action_exec
                                    314 	.globl _ak820_action_exec
                                    315 	.globl _process_record
                                    316 	.globl _process_record_handler
                                    317 	.globl _process_action
                                    318 	.globl _register_code
                                    319 	.globl _unregister_code
                                    320 	.globl _tap_code_delay
                                    321 	.globl _tap_code
                                    322 	.globl _register_mods
                                    323 	.globl _unregister_mods
                                    324 	.globl _register_weak_mods
                                    325 	.globl _unregister_weak_mods
                                    326 	.globl _clear_keyboard
                                    327 	.globl _clear_keyboard_but_mods
                                    328 	.globl _clear_keyboard_but_mods_and_keys
                                    329 ;--------------------------------------------------------
                                    330 ; special function registers
                                    331 ;--------------------------------------------------------
                                    332 	.area RSEG    (ABS,DATA)
      000000                        333 	.org 0x0000
                           0000D0   334 _PSW	=	0x00d0
                           0000E0   335 _ACC	=	0x00e0
                           0000F0   336 _B	=	0x00f0
                           0000FD   337 _A_INV	=	0x00fd
                           000081   338 _SP	=	0x0081
                           000082   339 _DPL	=	0x0082
                           000083   340 _DPH	=	0x0083
                           0000A1   341 _SAFE_MOD	=	0x00a1
                           0000B1   342 _GLOBAL_CFG	=	0x00b1
                           000087   343 _PCON	=	0x0087
                           0000BA   344 _POWER_CFG	=	0x00ba
                           0000B9   345 _CLOCK_CFG	=	0x00b9
                           0000A9   346 _WAKE_CTRL	=	0x00a9
                           0000FE   347 _RESET_KEEP	=	0x00fe
                           0000FF   348 _WDOG_COUNT	=	0x00ff
                           0000A8   349 _IE	=	0x00a8
                           0000B8   350 _IP	=	0x00b8
                           0000E8   351 _IE_EX	=	0x00e8
                           0000E9   352 _IP_EX	=	0x00e9
                           0000B2   353 _GPIO_IE	=	0x00b2
                           008584   354 _ROM_ADDR	=	0x8584
                           000084   355 _ROM_ADDR_L	=	0x0084
                           000085   356 _ROM_ADDR_H	=	0x0085
                           008F8E   357 _ROM_DATA_HI	=	0x8f8e
                           00008E   358 _ROM_DATA_HL	=	0x008e
                           00008F   359 _ROM_DATA_HH	=	0x008f
                           000086   360 _ROM_CTRL	=	0x0086
                           000080   361 _P0	=	0x0080
                           0000C4   362 _P0_MOD_OC	=	0x00c4
                           0000C5   363 _P0_DIR_PU	=	0x00c5
                           000090   364 _P1	=	0x0090
                           000092   365 _P1_MOD_OC	=	0x0092
                           000093   366 _P1_DIR_PU	=	0x0093
                           0000A0   367 _P2	=	0x00a0
                           000094   368 _P2_MOD_OC	=	0x0094
                           000095   369 _P2_DIR_PU	=	0x0095
                           0000B0   370 _P3	=	0x00b0
                           000096   371 _P3_MOD_OC	=	0x0096
                           000097   372 _P3_DIR_PU	=	0x0097
                           0000C0   373 _P4	=	0x00c0
                           0000C2   374 _P4_MOD_OC	=	0x00c2
                           0000C3   375 _P4_DIR_PU	=	0x00c3
                           0000C1   376 _P4_LED_KEY	=	0x00c1
                           0000AA   377 _P5_IN	=	0x00aa
                           0000AB   378 _P5_OUT_PU	=	0x00ab
                           0000AC   379 _P5_DIR	=	0x00ac
                           0000AD   380 _P6_IN	=	0x00ad
                           0000AE   381 _P6_OUT_PU	=	0x00ae
                           0000AF   382 _P6_DIR	=	0x00af
                           0000F1   383 _P7	=	0x00f1
                           0000A2   384 _XBUS_AUX	=	0x00a2
                           000088   385 _TCON	=	0x0088
                           000089   386 _TMOD	=	0x0089
                           00008A   387 _TL0	=	0x008a
                           00008B   388 _TL1	=	0x008b
                           00008C   389 _TH0	=	0x008c
                           00008D   390 _TH1	=	0x008d
                           000098   391 _SCON	=	0x0098
                           000099   392 _SBUF	=	0x0099
                           0000C8   393 _T2CON	=	0x00c8
                           0000C9   394 _T2MOD	=	0x00c9
                           00CBCA   395 _RCAP2	=	0xcbca
                           0000CA   396 _RCAP2L	=	0x00ca
                           0000CB   397 _RCAP2H	=	0x00cb
                           00CDCC   398 _T2COUNT	=	0xcdcc
                           0000CC   399 _TL2	=	0x00cc
                           0000CD   400 _TH2	=	0x00cd
                           00CFCE   401 _T2CAP1	=	0xcfce
                           0000CE   402 _T2CAP1L	=	0x00ce
                           0000CF   403 _T2CAP1H	=	0x00cf
                           0000F8   404 _SPI0_STAT	=	0x00f8
                           0000F9   405 _SPI0_DATA	=	0x00f9
                           0000FA   406 _SPI0_CTRL	=	0x00fa
                           0000FB   407 _SPI0_CK_SE	=	0x00fb
                           0000FC   408 _SPI0_SETUP	=	0x00fc
                           0000BC   409 _SCON1	=	0x00bc
                           0000BD   410 _SBUF1	=	0x00bd
                           0000BE   411 _SBAUD1	=	0x00be
                           0000BF   412 _SIF1	=	0x00bf
                           0000B4   413 _SPI1_STAT	=	0x00b4
                           0000B5   414 _SPI1_DATA	=	0x00b5
                           0000B6   415 _SPI1_CTRL	=	0x00b6
                           0000B7   416 _SPI1_CK_SE	=	0x00b7
                           0000F3   417 _ADC_CTRL	=	0x00f3
                           00F5F4   418 _ADC_DAT	=	0xf5f4
                           0000F4   419 _ADC_DAT_L	=	0x00f4
                           0000F5   420 _ADC_DAT_H	=	0x00f5
                           0000F6   421 _ADC_CHAN	=	0x00f6
                           0000A6   422 _LED_COMMON	=	0x00a6
                           0000A7   423 _LED_PWM_OE	=	0x00a7
                           00C7C6   424 _LED_DMA	=	0xc7c6
                           0000C6   425 _LED_DMA_L	=	0x00c6
                           0000C7   426 _LED_DMA_H	=	0x00c7
                           0000F7   427 _LED_STATUS	=	0x00f7
                           0000B3   428 _I2CX_INT	=	0x00b3
                           0000BB   429 _I2CS_INT_ST	=	0x00bb
                                    430 ;--------------------------------------------------------
                                    431 ; special function bits
                                    432 ;--------------------------------------------------------
                                    433 	.area RSEG    (ABS,DATA)
      000000                        434 	.org 0x0000
                           0000D7   435 _CY	=	0x00d7
                           0000D6   436 _AC	=	0x00d6
                           0000D5   437 _F0	=	0x00d5
                           0000D4   438 _RS1	=	0x00d4
                           0000D3   439 _RS0	=	0x00d3
                           0000D2   440 _OV	=	0x00d2
                           0000D1   441 _F1	=	0x00d1
                           0000D0   442 _P	=	0x00d0
                           0000AF   443 _EA	=	0x00af
                           0000AE   444 _E_DIS	=	0x00ae
                           0000AD   445 _ET2	=	0x00ad
                           0000AC   446 _ES	=	0x00ac
                           0000AB   447 _ET1	=	0x00ab
                           0000AA   448 _EX1	=	0x00aa
                           0000A9   449 _ET0	=	0x00a9
                           0000A8   450 _EX0	=	0x00a8
                           0000BF   451 _PH_FLAG	=	0x00bf
                           0000BE   452 _PL_FLAG	=	0x00be
                           0000BD   453 _PT2	=	0x00bd
                           0000BC   454 _PS	=	0x00bc
                           0000BB   455 _PT1	=	0x00bb
                           0000BA   456 _PX1	=	0x00ba
                           0000B9   457 _PT0	=	0x00b9
                           0000B8   458 _PX0	=	0x00b8
                           0000EF   459 _IE_WDOG	=	0x00ef
                           0000EE   460 _IE_GPIO	=	0x00ee
                           0000ED   461 _IE_PWM_I2C	=	0x00ed
                           0000EC   462 _IE_UART1	=	0x00ec
                           0000EB   463 _IE_ADC	=	0x00eb
                           0000E9   464 _IE_USB	=	0x00e9
                           0000E8   465 _IE_SPI0	=	0x00e8
                           000087   466 _P0_7	=	0x0087
                           000086   467 _P0_6	=	0x0086
                           000085   468 _P0_5	=	0x0085
                           000084   469 _P0_4	=	0x0084
                           000083   470 _P0_3	=	0x0083
                           000082   471 _P0_2	=	0x0082
                           000081   472 _P0_1	=	0x0081
                           000080   473 _P0_0	=	0x0080
                           000081   474 _SDA0	=	0x0081
                           000080   475 _SCL0	=	0x0080
                           000083   476 _TXD_	=	0x0083
                           000082   477 _RXD_	=	0x0082
                           000085   478 _AIN13	=	0x0085
                           000084   479 _AIN12	=	0x0084
                           000083   480 _AIN11	=	0x0083
                           000082   481 _AIN10	=	0x0082
                           000081   482 _AIN9	=	0x0081
                           000080   483 _AIN8	=	0x0080
                           000097   484 _P1_7	=	0x0097
                           000096   485 _P1_6	=	0x0096
                           000095   486 _P1_5	=	0x0095
                           000094   487 _P1_4	=	0x0094
                           000093   488 _P1_3	=	0x0093
                           000092   489 _P1_2	=	0x0092
                           000091   490 _P1_1	=	0x0091
                           000090   491 _P1_0	=	0x0090
                           000097   492 _TXD1_	=	0x0097
                           000096   493 _RXD1_	=	0x0096
                           000097   494 _SCK	=	0x0097
                           000096   495 _MISO	=	0x0096
                           000095   496 _MOSI	=	0x0095
                           000094   497 _SCS	=	0x0094
                           000092   498 _INT0_	=	0x0092
                           000091   499 _T2EX	=	0x0091
                           000091   500 _CAP2	=	0x0091
                           000090   501 _T2	=	0x0090
                           000090   502 _CAP1	=	0x0090
                           000097   503 _AIN7	=	0x0097
                           000096   504 _AIN6	=	0x0096
                           000095   505 _AIN5	=	0x0095
                           000094   506 _AIN4	=	0x0094
                           000093   507 _AIN3	=	0x0093
                           000092   508 _AIN2	=	0x0092
                           000091   509 _AIN1	=	0x0091
                           000090   510 _AIN0	=	0x0090
                           0000A7   511 _P2_7	=	0x00a7
                           0000A6   512 _P2_6	=	0x00a6
                           0000A5   513 _P2_5	=	0x00a5
                           0000A4   514 _P2_4	=	0x00a4
                           0000A3   515 _P2_3	=	0x00a3
                           0000A2   516 _P2_2	=	0x00a2
                           0000A1   517 _P2_1	=	0x00a1
                           0000A0   518 _P2_0	=	0x00a0
                           0000A7   519 _TXD1	=	0x00a7
                           0000A6   520 _RXD1	=	0x00a6
                           0000A5   521 _T2EX_	=	0x00a5
                           0000A5   522 _CAP2_	=	0x00a5
                           0000A4   523 _T2_	=	0x00a4
                           0000A4   524 _CAP1_	=	0x00a4
                           0000B7   525 _P3_7	=	0x00b7
                           0000B6   526 _P3_6	=	0x00b6
                           0000B5   527 _P3_5	=	0x00b5
                           0000B4   528 _P3_4	=	0x00b4
                           0000B3   529 _P3_3	=	0x00b3
                           0000B2   530 _P3_2	=	0x00b2
                           0000B1   531 _P3_1	=	0x00b1
                           0000B0   532 _P3_0	=	0x00b0
                           0000B7   533 _SCK1	=	0x00b7
                           0000B6   534 _MISO1	=	0x00b6
                           0000B5   535 _MOSI1	=	0x00b5
                           0000B5   536 _T1	=	0x00b5
                           0000B4   537 _T0	=	0x00b4
                           0000B3   538 _INT1	=	0x00b3
                           0000B2   539 _INT0	=	0x00b2
                           0000B1   540 _TXD	=	0x00b1
                           0000B0   541 _RXD	=	0x00b0
                           0000C6   542 _P4_6	=	0x00c6
                           0000C5   543 _P4_5	=	0x00c5
                           0000C4   544 _P4_4	=	0x00c4
                           0000C3   545 _P4_3	=	0x00c3
                           0000C2   546 _P4_2	=	0x00c2
                           0000C1   547 _P4_1	=	0x00c1
                           0000C0   548 _P4_0	=	0x00c0
                           00008F   549 _TF1	=	0x008f
                           00008E   550 _TR1	=	0x008e
                           00008D   551 _TF0	=	0x008d
                           00008C   552 _TR0	=	0x008c
                           00008B   553 _IE1	=	0x008b
                           00008A   554 _IT1	=	0x008a
                           000089   555 _IE0	=	0x0089
                           000088   556 _IT0	=	0x0088
                           00009F   557 _SM0	=	0x009f
                           00009E   558 _SM1	=	0x009e
                           00009D   559 _SM2	=	0x009d
                           00009C   560 _REN	=	0x009c
                           00009B   561 _TB8	=	0x009b
                           00009A   562 _RB8	=	0x009a
                           000099   563 _TI	=	0x0099
                           000098   564 _RI	=	0x0098
                           0000CF   565 _TF2	=	0x00cf
                           0000CF   566 _CAP1F	=	0x00cf
                           0000CE   567 _EXF2	=	0x00ce
                           0000CD   568 _RCLK	=	0x00cd
                           0000CC   569 _TCLK	=	0x00cc
                           0000CB   570 _EXEN2	=	0x00cb
                           0000CA   571 _TR2	=	0x00ca
                           0000C9   572 _C_T2	=	0x00c9
                           0000C8   573 _CP_RL2	=	0x00c8
                           0000FF   574 _S0_FST_ACT	=	0x00ff
                           0000FE   575 _S0_IF_OV	=	0x00fe
                           0000FD   576 _S0_IF_FIRST	=	0x00fd
                           0000FC   577 _S0_IF_BYTE	=	0x00fc
                           0000FB   578 _S0_FREE	=	0x00fb
                           0000FA   579 _S0_T_FIFO	=	0x00fa
                           0000F8   580 _S0_R_FIFO	=	0x00f8
                           0000F7   581 _ADC_START	=	0x00f7
                                    582 ;--------------------------------------------------------
                                    583 ; overlayable register banks
                                    584 ;--------------------------------------------------------
                                    585 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        586 	.ds 8
                                    587 ;--------------------------------------------------------
                                    588 ; internal ram data
                                    589 ;--------------------------------------------------------
                                    590 	.area DSEG    (DATA)
      000027                        591 _process_action_sloc0_1_0:
      000027                        592 	.ds 1
                                    593 ;--------------------------------------------------------
                                    594 ; overlayable items in internal ram
                                    595 ;--------------------------------------------------------
                                    596 ;--------------------------------------------------------
                                    597 ; indirectly addressable internal ram data
                                    598 ;--------------------------------------------------------
                                    599 	.area ISEG    (DATA)
                                    600 ;--------------------------------------------------------
                                    601 ; absolute internal ram data
                                    602 ;--------------------------------------------------------
                                    603 	.area IABS    (ABS,DATA)
                                    604 	.area IABS    (ABS,DATA)
                                    605 ;--------------------------------------------------------
                                    606 ; bit data
                                    607 ;--------------------------------------------------------
                                    608 	.area BSEG    (BIT)
      000020                        609 _process_action_sloc1_1_0:
      000020                        610 	.ds 1
                                    611 ;--------------------------------------------------------
                                    612 ; paged external ram data
                                    613 ;--------------------------------------------------------
                                    614 	.area PSEG    (PAG,XDATA)
                                    615 ;--------------------------------------------------------
                                    616 ; uninitialized external ram data
                                    617 ;--------------------------------------------------------
                                    618 	.area XSEG    (XDATA)
      000825                        619 _tp_buttons::
      000825                        620 	.ds 2
      000827                        621 _action_exec_PARM_1:
      000827                        622 	.ds 6
      00082D                        623 _action_exec_record_10001_628:
      00082D                        624 	.ds 9
      000836                        625 _ak820_action_exec_event_10000_633:
      000836                        626 	.ds 2
      000838                        627 _ak820_action_exec_snapshot_10000_634:
      000838                        628 	.ds 6
      00083E                        629 _process_record_record_10000_637:
      00083E                        630 	.ds 3
      000841                        631 _process_record_handler_record_argument_10000_645:
      000841                        632 	.ds 3
      000844                        633 _process_record_handler_action_10000_646:
      000844                        634 	.ds 2
      000846                        635 _process_action_PARM_2:
      000846                        636 	.ds 2
      000848                        637 _process_action_record_argument_10000_657:
      000848                        638 	.ds 3
      00084B                        639 _process_action_on_40000_680:
      00084B                        640 	.ds 1
      00084C                        641 _register_code_code_10000_714:
      00084C                        642 	.ds 1
      00084D                        643 _unregister_code_code_10000_728:
      00084D                        644 	.ds 1
      00084E                        645 _tap_code_delay_PARM_2:
      00084E                        646 	.ds 2
      000850                        647 _tap_code_delay_code_10000_741:
      000850                        648 	.ds 1
      000851                        649 _tap_code_code_10000_748:
      000851                        650 	.ds 1
      000852                        651 _register_mods_mods_10000_750:
      000852                        652 	.ds 1
      000853                        653 _unregister_mods_mods_10000_754:
      000853                        654 	.ds 1
      000854                        655 _register_weak_mods_mods_10000_758:
      000854                        656 	.ds 1
      000855                        657 _unregister_weak_mods_mods_10000_762:
      000855                        658 	.ds 1
                                    659 ;--------------------------------------------------------
                                    660 ; absolute external ram data
                                    661 ;--------------------------------------------------------
                                    662 	.area XABS    (ABS,XDATA)
                                    663 ;--------------------------------------------------------
                                    664 ; initialized external ram data
                                    665 ;--------------------------------------------------------
                                    666 	.area XISEG   (XDATA)
      000DD5                        667 _disable_action_cache::
      000DD5                        668 	.ds 1
                                    669 	.area HOME    (CODE)
                                    670 	.area GSINIT0 (CODE)
                                    671 	.area GSINIT1 (CODE)
                                    672 	.area GSINIT2 (CODE)
                                    673 	.area GSINIT3 (CODE)
                                    674 	.area GSINIT4 (CODE)
                                    675 	.area GSINIT5 (CODE)
                                    676 	.area GSINIT  (CODE)
                                    677 	.area GSFINAL (CODE)
                                    678 	.area CSEG    (CODE)
                                    679 ;--------------------------------------------------------
                                    680 ; global & static initialisations
                                    681 ;--------------------------------------------------------
                                    682 	.area HOME    (CODE)
                                    683 	.area GSINIT  (CODE)
                                    684 	.area GSFINAL (CODE)
                                    685 	.area GSINIT  (CODE)
                                    686 ;--------------------------------------------------------
                                    687 ; Home
                                    688 ;--------------------------------------------------------
                                    689 	.area HOME    (CODE)
                                    690 	.area HOME    (CODE)
                                    691 ;--------------------------------------------------------
                                    692 ; code
                                    693 ;--------------------------------------------------------
                                    694 	.area CSEG    (CODE)
                                    695 ;------------------------------------------------------------
                                    696 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    697 ;------------------------------------------------------------
                                    698 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    699 ;------------------------------------------------------------
                                    700 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    701 ;	-----------------------------------------
                           000007   702 	ar7 = 0x07
                           000006   703 	ar6 = 0x06
                           000005   704 	ar5 = 0x05
                           000004   705 	ar4 = 0x04
                           000003   706 	ar3 = 0x03
                           000002   707 	ar2 = 0x02
                           000001   708 	ar1 = 0x01
                           000000   709 	ar0 = 0x00
                                    710 ;	 function action_exec
                                    711 ;	-----------------------------------------
      00725E                        712 _action_exec:
                                    713 ;	quantum/action.c:92: ak820_combo_tick(event.time);
      00725E 90 08 29         [24]  714 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      007261 12 3A 3F         [24]  715 	lcall	_ak820_outline_0005
      007264 12 38 4F         [24]  716 	lcall	_ak820_combo_tick
                                    717 ;	quantum/action.c:95: if (!ak820_tapping_before(&event)) return;
      007267 90 08 27         [24]  718 	mov	dptr,#_action_exec_PARM_1
      00726A 12 46 9E         [24]  719 	lcall	_ak820_tapping_before
      00726D E5 82            [12]  720 	mov	a, dpl
      00726F 70 01            [24]  721 	jnz	00102$
      007271 22               [24]  722 	ret
      007272                        723 00102$:
                                    724 ;	quantum/action.c:97: if (!ak820_autoshift_before(&event)) return;
      007272 90 08 27         [24]  725 	mov	dptr,#_action_exec_PARM_1
      007275 12 31 2D         [24]  726 	lcall	_ak820_autoshift_before
      007278 E5 82            [12]  727 	mov	a, dpl
      00727A 70 01            [24]  728 	jnz	00104$
      00727C 22               [24]  729 	ret
      00727D                        730 00104$:
                                    731 ;	quantum/action.c:113: if (event.pressed) {
      00727D 90 08 2C         [24]  732 	mov	dptr,#(_action_exec_PARM_1 + 0x0005)
      007280 E0               [24]  733 	movx	a,@dptr
      007281 60 03            [24]  734 	jz	00106$
                                    735 ;	quantum/action.c:115: clear_weak_mods();
      007283 12 82 E1         [24]  736 	lcall	_clear_weak_mods
      007286                        737 00106$:
                                    738 ;	quantum/action.c:127: record.event = event;
      007286 90 0D B4         [24]  739 	mov	dptr,#___memcpy_PARM_2
      007289 74 27            [12]  740 	mov	a,#_action_exec_PARM_1
      00728B F0               [24]  741 	movx	@dptr,a
      00728C 74 08            [12]  742 	mov	a,#(_action_exec_PARM_1 >> 8)
      00728E 12 3A BB         [24]  743 	lcall	_ak820_outline_0094
      007291 12 79 4D         [24]  744 	lcall	_ak820_outline_0071
      007294 90 08 2D         [24]  745 	mov	dptr,#_action_exec_record_10001_628
      007297 F5 F0            [12]  746 	mov	b,a
      007299 12 BA 11         [24]  747 	lcall	___memcpy
                                    748 ;	quantum/action.c:129: record.tap.count = 0;
      00729C 90 08 33         [24]  749 	mov	dptr,#(_action_exec_record_10001_628 + 0x0006)
      00729F E0               [24]  750 	movx	a,@dptr
      0072A0 54 0F            [12]  751 	anl	a,#0x0f
      0072A2 F0               [24]  752 	movx	@dptr,a
                                    753 ;	quantum/action.c:134: record.keycode = 0;
      0072A3 90 08 34         [24]  754 	mov	dptr,#(_action_exec_record_10001_628 + 0x0007)
      0072A6 12 51 87         [24]  755 	lcall	_ak820_outline_0184
                                    756 ;	quantum/action.c:165: if (IS_NOEVENT(record.event) || pre_process_record_quantum(&record)) {
      0072A9 90 08 31         [24]  757 	mov	dptr,#(_action_exec_record_10001_628 + 0x0004)
      0072AC E0               [24]  758 	movx	a,@dptr
      0072AD 60 0D            [24]  759 	jz	00111$
      0072AF 90 08 2D         [24]  760 	mov	dptr,#_action_exec_record_10001_628
      0072B2 75 F0 00         [24]  761 	mov	b, #0x00
      0072B5 12 A0 C0         [24]  762 	lcall	_pre_process_record_quantum
      0072B8 E5 82            [12]  763 	mov	a, dpl
      0072BA 60 1F            [24]  764 	jz	00114$
      0072BC                        765 00111$:
                                    766 ;	quantum/action.c:167: if (!ak820_tapping_process(&record)) return;
      0072BC 90 08 2D         [24]  767 	mov	dptr,#_action_exec_record_10001_628
      0072BF 12 47 85         [24]  768 	lcall	_ak820_tapping_process
      0072C2 E5 82            [12]  769 	mov	a, dpl
      0072C4 70 01            [24]  770 	jnz	00108$
      0072C6 22               [24]  771 	ret
      0072C7                        772 00108$:
                                    773 ;	quantum/action.c:169: if (!ak820_autoshift_process(&record)) return;
      0072C7 90 08 2D         [24]  774 	mov	dptr,#_action_exec_record_10001_628
      0072CA 12 32 35         [24]  775 	lcall	_ak820_autoshift_process
      0072CD E5 82            [12]  776 	mov	a, dpl
      0072CF 70 01            [24]  777 	jnz	00110$
      0072D1 22               [24]  778 	ret
      0072D2                        779 00110$:
                                    780 ;	quantum/action.c:172: process_record(&record);
      0072D2 90 08 2D         [24]  781 	mov	dptr,#_action_exec_record_10001_628
      0072D5 75 F0 00         [24]  782 	mov	b, #0x00
                                    783 ;	quantum/action.c:182: }
      0072D8 02 73 18         [24]  784 	ljmp	_process_record
      0072DB                        785 00114$:
      0072DB 22               [24]  786 	ret
                                    787 ;------------------------------------------------------------
                                    788 ;Allocation info for local variables in function 'ak820_action_exec'
                                    789 ;------------------------------------------------------------
                                    790 ;event         Allocated with name '_ak820_action_exec_event_10000_633'
                                    791 ;snapshot      Allocated with name '_ak820_action_exec_snapshot_10000_634'
                                    792 ;------------------------------------------------------------
                                    793 ;	quantum/action.c:185: void ak820_action_exec(const keyevent_t __xdata *event) {
                                    794 ;	-----------------------------------------
                                    795 ;	 function ak820_action_exec
                                    796 ;	-----------------------------------------
      0072DC                        797 _ak820_action_exec:
      0072DC 12 3A CD         [24]  798 	lcall	_ak820_outline_0109
      0072DF 90 08 36         [24]  799 	mov	dptr,#_ak820_action_exec_event_10000_633
      0072E2 12 3A D2         [24]  800 	lcall	_ak820_outline_0110
                                    801 ;	quantum/action.c:188: keyevent_t snapshot = *event;
      0072E5 90 08 36         [24]  802 	mov	dptr,#_ak820_action_exec_event_10000_633
      0072E8 12 3A AF         [24]  803 	lcall	_ak820_outline_0080
      0072EB 7F 00            [12]  804 	mov	r7,#0x00
      0072ED 90 0D B4         [24]  805 	mov	dptr,#___memcpy_PARM_2
      0072F0 ED               [12]  806 	mov	a,r5
      0072F1 12 3A 6A         [24]  807 	lcall	_ak820_outline_0016
      0072F4 12 79 4D         [24]  808 	lcall	_ak820_outline_0071
      0072F7 90 08 38         [24]  809 	mov	dptr,#_ak820_action_exec_snapshot_10000_634
      0072FA F5 F0            [12]  810 	mov	b,a
      0072FC 12 BA 11         [24]  811 	lcall	___memcpy
                                    812 ;	quantum/action.c:189: action_exec(snapshot);
      0072FF 90 0D B4         [24]  813 	mov	dptr,#___memcpy_PARM_2
      007302 74 38            [12]  814 	mov	a,#_ak820_action_exec_snapshot_10000_634
      007304 F0               [24]  815 	movx	@dptr,a
      007305 74 08            [12]  816 	mov	a,#(_ak820_action_exec_snapshot_10000_634 >> 8)
      007307 12 3A BB         [24]  817 	lcall	_ak820_outline_0094
      00730A 12 79 4D         [24]  818 	lcall	_ak820_outline_0071
      00730D 90 08 27         [24]  819 	mov	dptr,#_action_exec_PARM_1
      007310 F5 F0            [12]  820 	mov	b,a
      007312 12 BA 11         [24]  821 	lcall	___memcpy
                                    822 ;	quantum/action.c:190: }
      007315 02 72 5E         [24]  823 	ljmp	_action_exec
                                    824 ;------------------------------------------------------------
                                    825 ;Allocation info for local variables in function 'process_record_nocache'
                                    826 ;------------------------------------------------------------
                                    827 ;record        Allocated with name '_process_record_nocache_record_10000_635'
                                    828 ;------------------------------------------------------------
                                    829 ;	quantum/action.c:275: void process_record_nocache(keyrecord_t *record) {
                                    830 ;	-----------------------------------------
                                    831 ;	 function process_record
                                    832 ;	-----------------------------------------
      007318                        833 _process_record:
      007318 12 45 5E         [24]  834 	lcall	_ak820_outline_0036
      00731B 90 08 3E         [24]  835 	mov	dptr,#_process_record_record_10000_637
      00731E 12 3A 6A         [24]  836 	lcall	_ak820_outline_0016
                                    837 ;	quantum/action.c:329: if (IS_NOEVENT(record->event)) {
      007321 90 08 3E         [24]  838 	mov	dptr,#_process_record_record_10000_637
      007324 12 51 34         [24]  839 	lcall	_ak820_outline_0012
      007327 74 04            [12]  840 	mov	a,#0x04
      007329 12 79 20         [24]  841 	lcall	_ak820_outline_0014
      00732C 12 BA EA         [24]  842 	lcall	__gptrget
      00732F 70 01            [24]  843 	jnz	00102$
                                    844 ;	quantum/action.c:330: return;
      007331 22               [24]  845 	ret
      007332                        846 00102$:
                                    847 ;	quantum/action.c:338: uint8_t oneshot_source = ak820_tapping_source(record->event.key);
      007332 8D 02            [24]  848 	mov	ar2,r5
      007334 8E 03            [24]  849 	mov	ar3,r6
      007336 8F 04            [24]  850 	mov	ar4,r7
      007338 90 0D B4         [24]  851 	mov	dptr,#___memcpy_PARM_2
      00733B EA               [12]  852 	mov	a,r2
      00733C 12 79 94         [24]  853 	lcall	_ak820_outline_0189
      00733F EC               [12]  854 	mov	a,r4
      007340 A3               [24]  855 	inc	dptr
      007341 F0               [24]  856 	movx	@dptr,a
      007342 90 0D B7         [24]  857 	mov	dptr,#___memcpy_PARM_3
      007345 12 51 79         [24]  858 	lcall	_ak820_outline_0112
      007348 90 06 34         [24]  859 	mov	dptr,#_ak820_tapping_source_PARM_1
      00734B F5 F0            [12]  860 	mov	b,a
      00734D C0 07            [24]  861 	push	ar7
      00734F C0 06            [24]  862 	push	ar6
      007351 C0 05            [24]  863 	push	ar5
      007353 12 BA 11         [24]  864 	lcall	___memcpy
      007356 12 45 D8         [24]  865 	lcall	_ak820_tapping_source
      007359 AC 82            [24]  866 	mov	r4, dpl
      00735B D0 05            [24]  867 	pop	ar5
      00735D D0 06            [24]  868 	pop	ar6
      00735F D0 07            [24]  869 	pop	ar7
                                    870 ;	quantum/action.c:339: bool oneshot_pressed = record->event.pressed;
      007361 74 05            [12]  871 	mov	a,#0x05
      007363 12 79 12         [24]  872 	lcall	_ak820_outline_0013
      007366 12 BA EA         [24]  873 	lcall	__gptrget
      007369 FB               [12]  874 	mov	r3,a
                                    875 ;	quantum/action.c:340: record->keycode = get_record_keycode(record, true);
      00736A 12 79 79         [24]  876 	lcall	_ak820_outline_0148
      00736D 90 0C 0B         [24]  877 	mov	dptr,#_get_record_keycode_PARM_2
      007370 74 01            [12]  878 	mov	a,#0x01
      007372 12 51 3D         [24]  879 	lcall	_ak820_outline_0034
      007375 C0 04            [24]  880 	push	ar4
      007377 C0 03            [24]  881 	push	ar3
      007379 C0 02            [24]  882 	push	ar2
      00737B C0 01            [24]  883 	push	ar1
      00737D C0 00            [24]  884 	push	ar0
      00737F 12 A0 82         [24]  885 	lcall	_get_record_keycode
      007382 12 45 A7         [24]  886 	lcall	_ak820_outline_0135
      007385 D0 00            [24]  887 	pop	ar0
      007387 D0 01            [24]  888 	pop	ar1
      007389 D0 02            [24]  889 	pop	ar2
      00738B D0 03            [24]  890 	pop	ar3
      00738D D0 04            [24]  891 	pop	ar4
      00738F 12 4A FD         [24]  892 	lcall	_ak820_outline_0114
      007392 EE               [12]  893 	mov	a,r6
      007393 12 BA AF         [24]  894 	lcall	__gptrput
      007396 A3               [24]  895 	inc	dptr
      007397 EF               [12]  896 	mov	a,r7
      007398 12 BA AF         [24]  897 	lcall	__gptrput
                                    898 ;	quantum/action.c:341: if (!ak820_oneshot_process(record->keycode, oneshot_source, oneshot_pressed)) return;
      00739B 90 08 3E         [24]  899 	mov	dptr,#_process_record_record_10000_637
      00739E 12 51 34         [24]  900 	lcall	_ak820_outline_0012
      0073A1 12 79 79         [24]  901 	lcall	_ak820_outline_0148
      0073A4 12 4A FD         [24]  902 	lcall	_ak820_outline_0114
      0073A7 12 BA EA         [24]  903 	lcall	__gptrget
      0073AA F8               [12]  904 	mov	r0,a
      0073AB A3               [24]  905 	inc	dptr
      0073AC 12 BA EA         [24]  906 	lcall	__gptrget
      0073AF F9               [12]  907 	mov	r1,a
      0073B0 90 06 44         [24]  908 	mov	dptr,#_ak820_oneshot_process_PARM_2
      0073B3 EC               [12]  909 	mov	a,r4
      0073B4 F0               [24]  910 	movx	@dptr,a
      0073B5 90 06 45         [24]  911 	mov	dptr,#_ak820_oneshot_process_PARM_3
      0073B8 EB               [12]  912 	mov	a,r3
      0073B9 F0               [24]  913 	movx	@dptr,a
      0073BA 12 3B 01         [24]  914 	lcall	_ak820_outline_0160
      0073BD C0 07            [24]  915 	push	ar7
      0073BF C0 06            [24]  916 	push	ar6
      0073C1 C0 05            [24]  917 	push	ar5
      0073C3 C0 04            [24]  918 	push	ar4
      0073C5 C0 03            [24]  919 	push	ar3
      0073C7 12 49 37         [24]  920 	lcall	_ak820_oneshot_process
      0073CA E5 82            [12]  921 	mov	a, dpl
      0073CC D0 03            [24]  922 	pop	ar3
      0073CE D0 04            [24]  923 	pop	ar4
      0073D0 D0 05            [24]  924 	pop	ar5
      0073D2 D0 06            [24]  925 	pop	ar6
      0073D4 D0 07            [24]  926 	pop	ar7
      0073D6 70 01            [24]  927 	jnz	00104$
      0073D8 22               [24]  928 	ret
      0073D9                        929 00104$:
                                    930 ;	quantum/action.c:343: if (!process_record_quantum(record)) {
      0073D9 12 6F A4         [24]  931 	lcall	_ak820_outline_0059
      0073DC C0 04            [24]  932 	push	ar4
      0073DE C0 03            [24]  933 	push	ar3
      0073E0 12 A1 48         [24]  934 	lcall	_process_record_quantum
      0073E3 E5 82            [12]  935 	mov	a, dpl
      0073E5 D0 03            [24]  936 	pop	ar3
      0073E7 D0 04            [24]  937 	pop	ar4
      0073E9 70 0A            [24]  938 	jnz	00106$
                                    939 ;	quantum/action.c:345: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      0073EB 90 05 AC         [24]  940 	mov	dptr,#_ak820_oneshot_post_PARM_2
      0073EE EB               [12]  941 	mov	a,r3
      0073EF F0               [24]  942 	movx	@dptr,a
      0073F0 8C 82            [24]  943 	mov	dpl, r4
                                    944 ;	quantum/action.c:352: return;
      0073F2 02 2E BB         [24]  945 	ljmp	_ak820_oneshot_post
      0073F5                        946 00106$:
                                    947 ;	quantum/action.c:358: process_record_handler(record);
      0073F5 90 08 3E         [24]  948 	mov	dptr,#_process_record_record_10000_637
      0073F8 12 51 0E         [24]  949 	lcall	_ak820_outline_0001
      0073FB C0 04            [24]  950 	push	ar4
      0073FD C0 03            [24]  951 	push	ar3
      0073FF 12 74 19         [24]  952 	lcall	_process_record_handler
                                    953 ;	quantum/action.c:362: post_process_record_quantum(record);
      007402 90 08 3E         [24]  954 	mov	dptr,#_process_record_record_10000_637
      007405 12 51 0E         [24]  955 	lcall	_ak820_outline_0001
      007408 12 A1 1D         [24]  956 	lcall	_post_process_record_quantum
      00740B D0 03            [24]  957 	pop	ar3
      00740D D0 04            [24]  958 	pop	ar4
                                    959 ;	quantum/action.c:364: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      00740F 90 05 AC         [24]  960 	mov	dptr,#_ak820_oneshot_post_PARM_2
      007412 EB               [12]  961 	mov	a,r3
      007413 F0               [24]  962 	movx	@dptr,a
      007414 8C 82            [24]  963 	mov	dpl, r4
                                    964 ;	quantum/action.c:366: }
      007416 02 2E BB         [24]  965 	ljmp	_ak820_oneshot_post
                                    966 ;------------------------------------------------------------
                                    967 ;Allocation info for local variables in function 'process_record_handler'
                                    968 ;------------------------------------------------------------
                                    969 ;record_argument Allocated with name '_process_record_handler_record_argument_10000_645'
                                    970 ;record        Allocated with name '_process_record_handler_record_10000_646'
                                    971 ;action        Allocated with name '_process_record_handler_action_10000_646'
                                    972 ;------------------------------------------------------------
                                    973 ;	quantum/action.c:368: void process_record_handler(keyrecord_t *record_argument) {
                                    974 ;	-----------------------------------------
                                    975 ;	 function process_record_handler
                                    976 ;	-----------------------------------------
      007419                        977 _process_record_handler:
      007419 12 45 5E         [24]  978 	lcall	_ak820_outline_0036
      00741C 90 08 41         [24]  979 	mov	dptr,#_process_record_handler_record_argument_10000_645
      00741F 12 3A 6A         [24]  980 	lcall	_ak820_outline_0016
                                    981 ;	quantum/action.c:372: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      007422 90 08 41         [24]  982 	mov	dptr,#_process_record_handler_record_argument_10000_645
      007425 12 3A 49         [24]  983 	lcall	_ak820_outline_0007
                                    984 ;	quantum/action.c:379: if (record->keycode) {
      007428 4C               [12]  985 	orl	a,r4
      007429 60 19            [24]  986 	jz	00102$
                                    987 ;	quantum/action.c:380: action.code = action_for_keycode(record->keycode);
      00742B 12 3A E2         [24]  988 	lcall	_ak820_outline_0126
      00742E C0 07            [24]  989 	push	ar7
      007430 C0 06            [24]  990 	push	ar6
      007432 12 96 BF         [24]  991 	lcall	_action_for_keycode
      007435 12 45 B8         [24]  992 	lcall	_ak820_outline_0151
      007438 D0 06            [24]  993 	pop	ar6
      00743A D0 07            [24]  994 	pop	ar7
      00743C 90 08 44         [24]  995 	mov	dptr,#_process_record_handler_action_10000_646
      00743F 12 3A A9         [24]  996 	lcall	_ak820_outline_0072
      007442 80 2B            [24]  997 	sjmp	00104$
      007444                        998 00102$:
                                    999 ;	quantum/action.c:383: action.code = action_for_keycode(ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed));
      007444 12 79 2E         [24] 1000 	lcall	_ak820_outline_0021
      007447 7A 00            [12] 1001 	mov	r2,#0x00
      007449 12 45 B2         [24] 1002 	lcall	_ak820_outline_0144
      00744C 12 45 4C         [24] 1003 	lcall	_ak820_outline_0011
      00744F E0               [24] 1004 	movx	a,@dptr
      007450 90 09 80         [24] 1005 	mov	dptr,#_ak820_resolve_key_PARM_2
      007453 F0               [24] 1006 	movx	@dptr,a
      007454 8D 82            [24] 1007 	mov	dpl, r5
      007456 8C 83            [24] 1008 	mov	dph, r4
      007458 C0 07            [24] 1009 	push	ar7
      00745A C0 06            [24] 1010 	push	ar6
      00745C 12 7C D5         [24] 1011 	lcall	_ak820_resolve_key
      00745F 12 96 BF         [24] 1012 	lcall	_action_for_keycode
      007462 12 45 B8         [24] 1013 	lcall	_ak820_outline_0151
      007465 D0 06            [24] 1014 	pop	ar6
      007467 D0 07            [24] 1015 	pop	ar7
      007469 90 08 44         [24] 1016 	mov	dptr,#_process_record_handler_action_10000_646
      00746C 12 3A A9         [24] 1017 	lcall	_ak820_outline_0072
                                   1018 ;	quantum/action.c:392: ac_dprintf("ACTION: ");
      00746F                       1019 00104$:
                                   1020 ;	quantum/action.c:403: process_action(record, action);
      00746F 7D 00            [12] 1021 	mov	r5,#0x00
      007471 90 0D B4         [24] 1022 	mov	dptr,#___memcpy_PARM_2
      007474 74 44            [12] 1023 	mov	a,#_process_record_handler_action_10000_646
      007476 F0               [24] 1024 	movx	@dptr,a
      007477 74 08            [12] 1025 	mov	a,#(_process_record_handler_action_10000_646 >> 8)
      007479 12 3A BB         [24] 1026 	lcall	_ak820_outline_0094
      00747C 90 0D B7         [24] 1027 	mov	dptr,#___memcpy_PARM_3
      00747F 12 51 79         [24] 1028 	lcall	_ak820_outline_0112
      007482 90 08 46         [24] 1029 	mov	dptr,#_process_action_PARM_2
      007485 F5 F0            [12] 1030 	mov	b,a
      007487 C0 07            [24] 1031 	push	ar7
      007489 C0 06            [24] 1032 	push	ar6
      00748B C0 05            [24] 1033 	push	ar5
      00748D 12 BA 11         [24] 1034 	lcall	___memcpy
      007490 D0 05            [24] 1035 	pop	ar5
      007492 D0 06            [24] 1036 	pop	ar6
      007494 D0 07            [24] 1037 	pop	ar7
      007496 12 71 C9         [24] 1038 	lcall	_ak820_outline_0050
                                   1039 ;	quantum/action.c:404: }
      007499 02 74 9C         [24] 1040 	ljmp	_process_action
                                   1041 ;------------------------------------------------------------
                                   1042 ;Allocation info for local variables in function 'register_mouse'
                                   1043 ;------------------------------------------------------------
                                   1044 ;pressed       Allocated with name '_register_mouse_PARM_2'
                                   1045 ;mouse_keycode Allocated with name '_register_mouse_mouse_keycode_10000_654'
                                   1046 ;------------------------------------------------------------
                                   1047 ;	quantum/action.c:416: void register_mouse(uint8_t mouse_keycode, bool pressed) {
                                   1048 ;	-----------------------------------------
                                   1049 ;	 function process_action
                                   1050 ;	-----------------------------------------
      00749C                       1051 _process_action:
      00749C 12 45 5E         [24] 1052 	lcall	_ak820_outline_0036
      00749F 90 08 48         [24] 1053 	mov	dptr,#_process_action_record_argument_10000_657
      0074A2 12 3A 6A         [24] 1054 	lcall	_ak820_outline_0016
                                   1055 ;	quantum/action.c:469: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      0074A5 90 08 48         [24] 1056 	mov	dptr,#_process_action_record_argument_10000_657
      0074A8 12 3A 3F         [24] 1057 	lcall	_ak820_outline_0005
                                   1058 ;	quantum/action.c:475: pressed = record->event.pressed;
      0074AB A3               [24] 1059 	inc	dptr
      0074AC A3               [24] 1060 	inc	dptr
      0074AD A3               [24] 1061 	inc	dptr
      0074AE A3               [24] 1062 	inc	dptr
      0074AF A3               [24] 1063 	inc	dptr
      0074B0 E0               [24] 1064 	movx	a,@dptr
      0074B1 F5 27            [12] 1065 	mov	_process_action_sloc0_1_0,a
                                   1066 ;	quantum/action.c:499: switch (action.kind.id) {
      0074B3 90 08 47         [24] 1067 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0074B6 E0               [24] 1068 	movx	a,@dptr
      0074B7 C4               [12] 1069 	swap	a
      0074B8 54 0F            [12] 1070 	anl	a,#0x0f
      0074BA FD               [12] 1071 	mov  r5,a
      0074BB 24 F4            [12] 1072 	add	a,#0xff - 0x0b
      0074BD 50 03            [24] 1073 	jnc	00434$
      0074BF 02 77 3D         [24] 1074 	ljmp	00181$
      0074C2                       1075 00434$:
                                   1076 ;	free result
      0074C2 ED               [12] 1077 	mov	a,r5
      0074C3 24 0A            [12] 1078 	add	a,#(00435$-3-.)
      0074C5 83               [24] 1079 	movc	a,@a+pc
      0074C6 F5 82            [12] 1080 	mov	dpl,a
      0074C8 ED               [12] 1081 	mov	a,r5
      0074C9 24 10            [12] 1082 	add	a,#(00436$-3-.)
      0074CB 83               [24] 1083 	movc	a,@a+pc
      0074CC F5 83            [12] 1084 	mov	dph,a
      0074CE E4               [12] 1085 	clr	a
      0074CF 73               [24] 1086 	jmp	@a+dptr
      0074D0                       1087 00435$:
      0074D0 E8                    1088 	.db	00102$
      0074D1 E8                    1089 	.db	00102$
      0074D2 3D                    1090 	.db	00181$
      0074D3 3D                    1091 	.db	00181$
      0074D4 72                    1092 	.db	00123$
      0074D5 3D                    1093 	.db	00181$
      0074D6 3D                    1094 	.db	00181$
      0074D7 3D                    1095 	.db	00181$
      0074D8 D2                    1096 	.db	00131$
      0074D9 A4                    1097 	.db	00147$
      0074DA CA                    1098 	.db	00152$
      0074DB CA                    1099 	.db	00152$
      0074DC                       1100 00436$:
      0074DC 74                    1101 	.db	00102$>>8
      0074DD 74                    1102 	.db	00102$>>8
      0074DE 77                    1103 	.db	00181$>>8
      0074DF 77                    1104 	.db	00181$>>8
      0074E0 75                    1105 	.db	00123$>>8
      0074E1 77                    1106 	.db	00181$>>8
      0074E2 77                    1107 	.db	00181$>>8
      0074E3 77                    1108 	.db	00181$>>8
      0074E4 75                    1109 	.db	00131$>>8
      0074E5 76                    1110 	.db	00147$>>8
      0074E6 76                    1111 	.db	00152$>>8
      0074E7 76                    1112 	.db	00152$>>8
                                   1113 ;	quantum/action.c:502: case ACT_RMODS: {
      0074E8                       1114 00102$:
                                   1115 ;	quantum/action.c:503: mods = (action.kind.id == ACT_LMODS) ? action.key.mods : action.key.mods << 4;
      0074E8 90 08 47         [24] 1116 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0074EB E0               [24] 1117 	movx	a,@dptr
      0074EC 54 F0            [12] 1118 	anl	a,#0xf0
      0074EE 70 06            [24] 1119 	jnz	00194$
      0074F0 12 79 67         [24] 1120 	lcall	_ak820_outline_0115
      0074F3 FD               [12] 1121 	mov	r5,a
      0074F4 80 07            [24] 1122 	sjmp	00195$
      0074F6                       1123 00194$:
      0074F6 12 79 67         [24] 1124 	lcall	_ak820_outline_0115
      0074F9 C4               [12] 1125 	swap	a
      0074FA 54 F0            [12] 1126 	anl	a,#0xf0
      0074FC FD               [12] 1127 	mov	r5,a
      0074FD                       1128 00195$:
                                   1129 ;	quantum/action.c:505: if (pressed) {
      0074FD E5 27            [12] 1130 	mov	a,_process_action_sloc0_1_0
      0074FF 60 35            [24] 1131 	jz	00119$
                                   1132 ;	quantum/action.c:506: if (mods) {
      007501 ED               [12] 1133 	mov	a,r5
      007502 60 29            [24] 1134 	jz	00110$
                                   1135 ;	quantum/action.c:507: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      007504 12 79 83         [24] 1136 	lcall	_ak820_outline_0162
      007507 FC               [12] 1137 	mov	r4,a
      007508 BC E0 00         [24] 1138 	cjne	r4,#0xe0,00440$
      00750B                       1139 00440$:
      00750B 40 07            [24] 1140 	jc	00108$
      00750D 12 79 83         [24] 1141 	lcall	_ak820_outline_0162
      007510 24 18            [12] 1142 	add	a,#0xff - 0xe7
      007512 50 0A            [24] 1143 	jnc	00104$
                                   1144 ;	free result
      007514                       1145 00108$:
      007514 7B 46            [12] 1146 	mov	r3,#_process_action_PARM_2
      007516 7C 08            [12] 1147 	mov	r4,#(_process_action_PARM_2 >> 8)
      007518 12 36 47         [24] 1148 	lcall	_ak820_outline_0125
      00751B E0               [24] 1149 	movx	a,@dptr
      00751C 70 07            [24] 1150 	jnz	00105$
      00751E                       1151 00104$:
                                   1152 ;	quantum/action.c:511: add_owned_mods(mods);
      00751E 8D 82            [24] 1153 	mov	dpl, r5
      007520 12 7E EF         [24] 1154 	lcall	_add_owned_mods
      007523 80 05            [24] 1155 	sjmp	00106$
      007525                       1156 00105$:
                                   1157 ;	quantum/action.c:513: add_owned_weak_mods(mods);
      007525 8D 82            [24] 1158 	mov	dpl, r5
      007527 12 7F 0E         [24] 1159 	lcall	_add_owned_weak_mods
      00752A                       1160 00106$:
                                   1161 ;	quantum/action.c:515: send_keyboard_report();
      00752A 12 82 31         [24] 1162 	lcall	_send_keyboard_report
      00752D                       1163 00110$:
                                   1164 ;	quantum/action.c:517: register_code(action.key.code);
      00752D 12 79 57         [24] 1165 	lcall	_ak820_outline_0078
      007530 12 77 54         [24] 1166 	lcall	_register_code
      007533 02 77 3D         [24] 1167 	ljmp	00181$
      007536                       1168 00119$:
                                   1169 ;	quantum/action.c:519: unregister_code(action.key.code);
      007536 12 79 57         [24] 1170 	lcall	_ak820_outline_0078
      007539 C0 05            [24] 1171 	push	ar5
      00753B 12 77 C1         [24] 1172 	lcall	_unregister_code
      00753E D0 05            [24] 1173 	pop	ar5
                                   1174 ;	quantum/action.c:520: if (mods) {
      007540 ED               [12] 1175 	mov	a,r5
      007541 70 03            [24] 1176 	jnz	00444$
      007543 02 77 3D         [24] 1177 	ljmp	00181$
      007546                       1178 00444$:
                                   1179 ;	quantum/action.c:521: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      007546 12 79 83         [24] 1180 	lcall	_ak820_outline_0162
      007549 FC               [12] 1181 	mov	r4,a
      00754A BC E0 00         [24] 1182 	cjne	r4,#0xe0,00445$
      00754D                       1183 00445$:
      00754D 40 07            [24] 1184 	jc	00115$
      00754F 12 79 83         [24] 1185 	lcall	_ak820_outline_0162
      007552 24 18            [12] 1186 	add	a,#0xff - 0xe7
      007554 50 0A            [24] 1187 	jnc	00111$
                                   1188 ;	free result
      007556                       1189 00115$:
      007556 7B 46            [12] 1190 	mov	r3,#_process_action_PARM_2
      007558 7C 08            [12] 1191 	mov	r4,#(_process_action_PARM_2 >> 8)
      00755A 12 36 47         [24] 1192 	lcall	_ak820_outline_0125
      00755D E0               [24] 1193 	movx	a,@dptr
      00755E 70 07            [24] 1194 	jnz	00112$
      007560                       1195 00111$:
                                   1196 ;	quantum/action.c:522: del_owned_mods(mods);
      007560 8D 82            [24] 1197 	mov	dpl, r5
      007562 12 7E FF         [24] 1198 	lcall	_del_owned_mods
      007565 80 05            [24] 1199 	sjmp	00113$
      007567                       1200 00112$:
                                   1201 ;	quantum/action.c:524: del_owned_weak_mods(mods);
      007567 8D 82            [24] 1202 	mov	dpl, r5
      007569 12 7F 1E         [24] 1203 	lcall	_del_owned_weak_mods
      00756C                       1204 00113$:
                                   1205 ;	quantum/action.c:526: send_keyboard_report();
      00756C 12 82 31         [24] 1206 	lcall	_send_keyboard_report
                                   1207 ;	quantum/action.c:529: } break;
      00756F 02 77 3D         [24] 1208 	ljmp	00181$
                                   1209 ;	quantum/action.c:606: case ACT_USAGE:
      007572                       1210 00123$:
                                   1211 ;	quantum/action.c:612: if (record->keycode >= KC_SYSTEM_POWER && record->keycode <= KC_LAUNCHPAD) {
      007572 74 07            [12] 1212 	mov	a,#0x07
      007574 12 3A 7C         [24] 1213 	lcall	_ak820_outline_0022
      007577 12 4A 71         [24] 1214 	lcall	_ak820_outline_0008
      00757A C3               [12] 1215 	clr	c
      00757B EC               [12] 1216 	mov	a,r4
      00757C 94 A5            [12] 1217 	subb	a,#0xa5
      00757E ED               [12] 1218 	mov	a,r5
      00757F 94 00            [12] 1219 	subb	a,#0x00
      007581 40 15            [24] 1220 	jc	00125$
      007583 74 C2            [12] 1221 	mov	a,#0xc2
      007585 9C               [12] 1222 	subb	a,r4
      007586 E4               [12] 1223 	clr	a
      007587 9D               [12] 1224 	subb	a,r5
      007588 40 0E            [24] 1225 	jc	00125$
                                   1226 ;	free result
                                   1227 ;	quantum/action.c:613: owned_usage_key((uint8_t)record->keycode, pressed);
      00758A 90 0A A7         [24] 1228 	mov	dptr,#_owned_usage_key_PARM_2
      00758D E5 27            [12] 1229 	mov	a,_process_action_sloc0_1_0
      00758F F0               [24] 1230 	movx	@dptr,a
      007590 8E 82            [24] 1231 	mov	dpl, r6
      007592 12 80 DC         [24] 1232 	lcall	_owned_usage_key
                                   1233 ;	quantum/action.c:614: break;
      007595 02 77 3D         [24] 1234 	ljmp	00181$
      007598                       1235 00125$:
                                   1236 ;	quantum/action.c:617: switch (action.usage.page) {
      007598 12 79 5E         [24] 1237 	lcall	_ak820_outline_0090
      00759B FF               [12] 1238 	mov	r7,a
      00759C 60 08            [24] 1239 	jz	00127$
      00759E BF 01 02         [24] 1240 	cjne	r7,#0x01,00452$
      0075A1 80 19            [24] 1241 	sjmp	00128$
      0075A3                       1242 00452$:
      0075A3 02 77 3D         [24] 1243 	ljmp	00181$
                                   1244 ;	quantum/action.c:618: case PAGE_SYSTEM:
      0075A6                       1245 00127$:
                                   1246 ;	quantum/action.c:619: host_system_send(pressed ? action.usage.code : 0);
      0075A6 E5 27            [12] 1247 	mov	a,_process_action_sloc0_1_0
      0075A8 60 05            [24] 1248 	jz	00196$
      0075AA 12 79 6E         [24] 1249 	lcall	_ak820_outline_0132
      0075AD 80 04            [24] 1250 	sjmp	00197$
      0075AF                       1251 00196$:
      0075AF 7E 00            [12] 1252 	mov	r6,#0x00
      0075B1 7F 00            [12] 1253 	mov	r7,#0x00
      0075B3                       1254 00197$:
      0075B3 12 3A D7         [24] 1255 	lcall	_ak820_outline_0120
      0075B6 12 6F 2E         [24] 1256 	lcall	_host_system_send
                                   1257 ;	quantum/action.c:620: break;
      0075B9 02 77 3D         [24] 1258 	ljmp	00181$
                                   1259 ;	quantum/action.c:621: case PAGE_CONSUMER:
      0075BC                       1260 00128$:
                                   1261 ;	quantum/action.c:622: host_consumer_send(pressed ? action.usage.code : 0);
      0075BC E5 27            [12] 1262 	mov	a,_process_action_sloc0_1_0
      0075BE 60 05            [24] 1263 	jz	00198$
      0075C0 12 79 6E         [24] 1264 	lcall	_ak820_outline_0132
      0075C3 80 04            [24] 1265 	sjmp	00199$
      0075C5                       1266 00198$:
      0075C5 7E 00            [12] 1267 	mov	r6,#0x00
      0075C7 7F 00            [12] 1268 	mov	r7,#0x00
      0075C9                       1269 00199$:
      0075C9 12 3A D7         [24] 1270 	lcall	_ak820_outline_0120
      0075CC 12 6F 5E         [24] 1271 	lcall	_host_consumer_send
                                   1272 ;	quantum/action.c:625: break;
      0075CF 02 77 3D         [24] 1273 	ljmp	00181$
                                   1274 ;	quantum/action.c:632: case ACT_LAYER: {
      0075D2                       1275 00131$:
                                   1276 ;	quantum/action.c:633: uint8_t on = action.layer_bitop.on;
      0075D2 90 08 47         [24] 1277 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0075D5 E0               [24] 1278 	movx	a,@dptr
      0075D6 54 03            [12] 1279 	anl	a,#0x03
      0075D8 90 08 4B         [24] 1280 	mov	dptr,#_process_action_on_40000_680
      0075DB F0               [24] 1281 	movx	@dptr,a
                                   1282 ;	quantum/action.c:636: if (on ? (pressed ? (on & ON_PRESS) : (on & ON_RELEASE)) : !pressed) {
      0075DC E0               [24] 1283 	movx	a,@dptr
      0075DD FF               [12] 1284 	mov	r7,a
      0075DE 60 11            [24] 1285 	jz	00200$
      0075E0 E5 27            [12] 1286 	mov	a,_process_action_sloc0_1_0
      0075E2 60 07            [24] 1287 	jz	00202$
      0075E4 8F 06            [24] 1288 	mov	ar6,r7
      0075E6 53 06 01         [24] 1289 	anl	ar6,#0x01
      0075E9 80 10            [24] 1290 	sjmp	00201$
      0075EB                       1291 00202$:
      0075EB 74 02            [12] 1292 	mov	a,#0x02
      0075ED 5F               [12] 1293 	anl	a,r7
      0075EE FE               [12] 1294 	mov	r6,a
      0075EF 80 0A            [24] 1295 	sjmp	00201$
      0075F1                       1296 00200$:
      0075F1 E5 27            [12] 1297 	mov	a,_process_action_sloc0_1_0
      0075F3 B4 01 00         [24] 1298 	cjne	a,#0x01,00457$
      0075F6                       1299 00457$:
      0075F6 92 20            [24] 1300 	mov  _process_action_sloc1_1_0,c
      0075F8 E4               [12] 1301 	clr	a
      0075F9 33               [12] 1302 	rlc	a
      0075FA FE               [12] 1303 	mov	r6,a
      0075FB                       1304 00201$:
      0075FB EE               [12] 1305 	mov	a,r6
      0075FC 70 03            [24] 1306 	jnz	00458$
      0075FE 02 77 3D         [24] 1307 	ljmp	00181$
      007601                       1308 00458$:
                                   1309 ;	quantum/action.c:637: uint8_t shift = action.layer_bitop.part * 4;
      007601 12 79 83         [24] 1310 	lcall	_ak820_outline_0162
      007604 C4               [12] 1311 	swap	a
      007605 03               [12] 1312 	rr	a
      007606 54 07            [12] 1313 	anl	a,#0x07
      007608 25 E0            [12] 1314 	add	a,acc
      00760A 25 E0            [12] 1315 	add	a,acc
      00760C FF               [12] 1316 	mov	r7,a
                                   1317 ;	quantum/action.c:638: layer_state_t bits = ((layer_state_t)action.layer_bitop.bits) << shift;
      00760D 12 79 83         [24] 1318 	lcall	_ak820_outline_0162
      007610 54 0F            [12] 1319 	anl	a,#0x0f
      007612 FE               [12] 1320 	mov	r6,a
      007613 8F F0            [24] 1321 	mov	b,r7
      007615 05 F0            [12] 1322 	inc	b
      007617 EE               [12] 1323 	mov	a,r6
      007618 80 02            [24] 1324 	sjmp	00460$
      00761A                       1325 00459$:
      00761A 25 E0            [12] 1326 	add	a,acc
      00761C                       1327 00460$:
      00761C D5 F0 FB         [24] 1328 	djnz	b,00459$
      00761F FE               [12] 1329 	mov	r6,a
                                   1330 ;	quantum/action.c:639: layer_state_t mask = action.layer_bitop.xbit ? ~(((layer_state_t)0xf) << shift) : 0;
      007620 12 79 83         [24] 1331 	lcall	_ak820_outline_0162
      007623 30 E4 11         [24] 1332 	jnb	acc.4,00204$
      007626 8F F0            [24] 1333 	mov	b,r7
      007628 05 F0            [12] 1334 	inc	b
      00762A 74 0F            [12] 1335 	mov	a,#0x0f
      00762C 80 02            [24] 1336 	sjmp	00463$
      00762E                       1337 00462$:
      00762E 25 E0            [12] 1338 	add	a,acc
      007630                       1339 00463$:
      007630 D5 F0 FB         [24] 1340 	djnz	b,00462$
      007633 F4               [12] 1341 	cpl	a
      007634 FF               [12] 1342 	mov	r7,a
      007635 80 02            [24] 1343 	sjmp	00205$
      007637                       1344 00204$:
      007637 7F 00            [12] 1345 	mov	r7,#0x00
      007639                       1346 00205$:
                                   1347 ;	quantum/action.c:640: bits |= mask;
      007639 EE               [12] 1348 	mov	a,r6
      00763A 42 07            [12] 1349 	orl	ar7,a
                                   1350 ;	quantum/action.c:641: if (!on) {
      00763C 90 08 4B         [24] 1351 	mov	dptr,#_process_action_on_40000_680
      00763F E0               [24] 1352 	movx	a,@dptr
      007640 70 31            [24] 1353 	jnz	00143$
                                   1354 ;	quantum/action.c:642: switch (action.layer_bitop.op) {
      007642 12 79 5E         [24] 1355 	lcall	_ak820_outline_0090
      007645 FE               [12] 1356 	mov	r6,a
      007646 2E               [12] 1357 	add	a,r6
                                   1358 ;	quantum/action.c:643: case OP_BIT_AND: default_layer_and(bits); break;
      007647 90 76 4B         [24] 1359 	mov	dptr,#00465$
      00764A 73               [24] 1360 	jmp	@a+dptr
      00764B                       1361 00465$:
      00764B 80 06            [24] 1362 	sjmp	00132$
      00764D 80 0C            [24] 1363 	sjmp	00133$
      00764F 80 12            [24] 1364 	sjmp	00134$
      007651 80 18            [24] 1365 	sjmp	00135$
      007653                       1366 00132$:
      007653 8F 82            [24] 1367 	mov	dpl, r7
      007655 12 79 E3         [24] 1368 	lcall	_default_layer_and
      007658 02 77 3D         [24] 1369 	ljmp	00181$
                                   1370 ;	quantum/action.c:644: case OP_BIT_OR: default_layer_or(bits); break;
      00765B                       1371 00133$:
      00765B 8F 82            [24] 1372 	mov	dpl, r7
      00765D 12 79 D2         [24] 1373 	lcall	_default_layer_or
      007660 02 77 3D         [24] 1374 	ljmp	00181$
                                   1375 ;	quantum/action.c:645: case OP_BIT_XOR: default_layer_xor(bits); break;
      007663                       1376 00134$:
      007663 8F 82            [24] 1377 	mov	dpl, r7
      007665 12 79 F9         [24] 1378 	lcall	_default_layer_xor
      007668 02 77 3D         [24] 1379 	ljmp	00181$
                                   1380 ;	quantum/action.c:646: case OP_BIT_SET: default_layer_set(bits); break;
      00766B                       1381 00135$:
      00766B 8F 82            [24] 1382 	mov	dpl, r7
      00766D 12 79 C7         [24] 1383 	lcall	_default_layer_set
                                   1384 ;	quantum/action.c:647: }
      007670 02 77 3D         [24] 1385 	ljmp	00181$
      007673                       1386 00143$:
                                   1387 ;	quantum/action.c:649: switch (action.layer_bitop.op) {
      007673 12 79 5E         [24] 1388 	lcall	_ak820_outline_0090
      007676 FE               [12] 1389 	mov	r6,a
      007677 2E               [12] 1390 	add	a,r6
                                   1391 ;	quantum/action.c:650: case OP_BIT_AND: layer_and(bits); break;
      007678 90 76 7C         [24] 1392 	mov	dptr,#00466$
      00767B 73               [24] 1393 	jmp	@a+dptr
      00767C                       1394 00466$:
      00767C 80 06            [24] 1395 	sjmp	00137$
      00767E 80 0C            [24] 1396 	sjmp	00138$
      007680 80 12            [24] 1397 	sjmp	00139$
      007682 80 18            [24] 1398 	sjmp	00140$
      007684                       1399 00137$:
      007684 8F 82            [24] 1400 	mov	dpl, r7
      007686 12 7B 7D         [24] 1401 	lcall	_layer_and
      007689 02 77 3D         [24] 1402 	ljmp	00181$
                                   1403 ;	quantum/action.c:651: case OP_BIT_OR: layer_or(bits); break;
      00768C                       1404 00138$:
      00768C 8F 82            [24] 1405 	mov	dpl, r7
      00768E 12 7B 6C         [24] 1406 	lcall	_layer_or
      007691 02 77 3D         [24] 1407 	ljmp	00181$
                                   1408 ;	quantum/action.c:652: case OP_BIT_XOR: layer_xor(bits); break;
      007694                       1409 00139$:
      007694 8F 82            [24] 1410 	mov	dpl, r7
      007696 12 7B 93         [24] 1411 	lcall	_layer_xor
      007699 02 77 3D         [24] 1412 	ljmp	00181$
                                   1413 ;	quantum/action.c:653: case OP_BIT_SET: layer_state_set(bits); break;
      00769C                       1414 00140$:
      00769C 8F 82            [24] 1415 	mov	dpl, r7
      00769E 12 7B 09         [24] 1416 	lcall	_layer_state_set
                                   1417 ;	quantum/action.c:657: break;
      0076A1 02 77 3D         [24] 1418 	ljmp	00181$
                                   1419 ;	quantum/action.c:659: case ACT_LAYER_MODS:
      0076A4                       1420 00147$:
                                   1421 ;	quantum/action.c:660: if (pressed) {
      0076A4 E5 27            [12] 1422 	mov	a,_process_action_sloc0_1_0
      0076A6 60 11            [24] 1423 	jz	00149$
                                   1424 ;	quantum/action.c:661: layer_hold_on(action.layer_mods.layer);
      0076A8 12 79 67         [24] 1425 	lcall	_ak820_outline_0115
      0076AB F5 82            [12] 1426 	mov	dpl,a
      0076AD 12 7A 69         [24] 1427 	lcall	_layer_hold_on
                                   1428 ;	quantum/action.c:662: register_mods(action.layer_mods.mods);
      0076B0 12 79 57         [24] 1429 	lcall	_ak820_outline_0078
      0076B3 12 78 77         [24] 1430 	lcall	_register_mods
      0076B6 02 77 3D         [24] 1431 	ljmp	00181$
      0076B9                       1432 00149$:
                                   1433 ;	quantum/action.c:664: unregister_mods(action.layer_mods.mods);
      0076B9 12 79 57         [24] 1434 	lcall	_ak820_outline_0078
      0076BC 12 78 8B         [24] 1435 	lcall	_unregister_mods
                                   1436 ;	quantum/action.c:665: layer_hold_off(action.layer_mods.layer);
      0076BF 12 79 67         [24] 1437 	lcall	_ak820_outline_0115
      0076C2 F5 82            [12] 1438 	mov	dpl,a
      0076C4 12 7A A1         [24] 1439 	lcall	_layer_hold_off
                                   1440 ;	quantum/action.c:667: break;
      0076C7 02 77 3D         [24] 1441 	ljmp	00181$
                                   1442 ;	quantum/action.c:669: case ACT_LAYER_TAP_EXT:
      0076CA                       1443 00152$:
                                   1444 ;	quantum/action.c:670: switch (action.layer_tap.code) {
      0076CA 12 79 83         [24] 1445 	lcall	_ak820_outline_0162
      0076CD FF               [12] 1446 	mov	r7,a
      0076CE BF F1 02         [24] 1447 	cjne	r7,#0xf1,00468$
      0076D1 80 0A            [24] 1448 	sjmp	00154$
      0076D3                       1449 00468$:
      0076D3 BF F2 02         [24] 1450 	cjne	r7,#0xf2,00469$
      0076D6 80 19            [24] 1451 	sjmp	00155$
      0076D8                       1452 00469$:
                                   1453 ;	quantum/action.c:686: momentary_layer_action:
      0076D8 BF F3 3B         [24] 1454 	cjne	r7,#0xf3,00160$
      0076DB 80 28            [24] 1455 	sjmp	00156$
      0076DD                       1456 00154$:
                                   1457 ;	quantum/action.c:687: pressed ? layer_hold_on(action.layer_tap.val) : layer_hold_off(action.layer_tap.val);
      0076DD E5 27            [12] 1458 	mov	a,_process_action_sloc0_1_0
      0076DF 60 08            [24] 1459 	jz	00206$
      0076E1 12 79 3D         [24] 1460 	lcall	_ak820_outline_0042
      0076E4 12 7A 69         [24] 1461 	lcall	_layer_hold_on
      0076E7 80 54            [24] 1462 	sjmp	00181$
      0076E9                       1463 00206$:
      0076E9 12 79 3D         [24] 1464 	lcall	_ak820_outline_0042
      0076EC 12 7A A1         [24] 1465 	lcall	_layer_hold_off
                                   1466 ;	quantum/action.c:688: break;
                                   1467 ;	quantum/action.c:689: case OP_OFF_ON:
      0076EF 80 4C            [24] 1468 	sjmp	00181$
      0076F1                       1469 00155$:
                                   1470 ;	quantum/action.c:690: pressed ? layer_off(action.layer_tap.val) : layer_on(action.layer_tap.val);
      0076F1 E5 27            [12] 1471 	mov	a,_process_action_sloc0_1_0
      0076F3 60 08            [24] 1472 	jz	00208$
      0076F5 12 79 3D         [24] 1473 	lcall	_ak820_outline_0042
      0076F8 12 7B 4E         [24] 1474 	lcall	_layer_off
      0076FB 80 40            [24] 1475 	sjmp	00181$
      0076FD                       1476 00208$:
      0076FD 12 79 3D         [24] 1477 	lcall	_ak820_outline_0042
      007700 12 7B 33         [24] 1478 	lcall	_layer_on
                                   1479 ;	quantum/action.c:691: break;
                                   1480 ;	quantum/action.c:692: case OP_SET_CLEAR:
      007703 80 38            [24] 1481 	sjmp	00181$
      007705                       1482 00156$:
                                   1483 ;	quantum/action.c:693: pressed ? layer_move(action.layer_tap.val) : layer_clear();
      007705 E5 27            [12] 1484 	mov	a,_process_action_sloc0_1_0
      007707 60 08            [24] 1485 	jz	00210$
      007709 12 79 3D         [24] 1486 	lcall	_ak820_outline_0042
      00770C 12 7B 1D         [24] 1487 	lcall	_layer_move
      00770F 80 2C            [24] 1488 	sjmp	00181$
      007711                       1489 00210$:
      007711 12 7B 17         [24] 1490 	lcall	_layer_clear
                                   1491 ;	quantum/action.c:694: break;
                                   1492 ;	quantum/action.c:740: default:
      007714 80 27            [24] 1493 	sjmp	00181$
      007716                       1494 00160$:
                                   1495 ;	quantum/action.c:747: if (pressed) {
      007716 E5 27            [12] 1496 	mov	a,_process_action_sloc0_1_0
      007718 60 08            [24] 1497 	jz	00163$
                                   1498 ;	quantum/action.c:749: register_code(action.layer_tap.code);
      00771A 12 79 57         [24] 1499 	lcall	_ak820_outline_0078
      00771D 12 77 54         [24] 1500 	lcall	_register_code
                                   1501 ;	quantum/action.c:751: ac_dprintf("KEYMAP_TAP_KEY: Tap: unregister_code\n");
      007720 80 1B            [24] 1502 	sjmp	00181$
      007722                       1503 00163$:
                                   1504 ;	quantum/action.c:752: if (action.layer_tap.code == KC_CAPS) {
      007722 12 79 83         [24] 1505 	lcall	_ak820_outline_0162
      007725 FF               [12] 1506 	mov	r7,a
      007726 BF 39 0E         [24] 1507 	cjne	r7,#0x39,00175$
                                   1508 ;	quantum/action.c:753: wait_ms(TAP_HOLD_CAPS_DELAY);
      007729 7F 50            [12] 1509 	mov	r7,#0x50
      00772B                       1510 00187$:
      00772B EF               [12] 1511 	mov	a,r7
      00772C 60 09            [24] 1512 	jz	00175$
      00772E 90 00 01         [24] 1513 	mov	dptr,#0x0001
      007731 12 5B 08         [24] 1514 	lcall	_mDelaymS
      007734 1F               [12] 1515 	dec	r7
                                   1516 ;	quantum/action.c:755: wait_ms(TAP_CODE_DELAY);
      007735 80 F4            [24] 1517 	sjmp	00187$
      007737                       1518 00175$:
                                   1519 ;	quantum/action.c:757: unregister_code(action.layer_tap.code);
      007737 12 79 57         [24] 1520 	lcall	_ak820_outline_0078
      00773A 12 77 C1         [24] 1521 	lcall	_unregister_code
                                   1522 ;	quantum/action.c:840: }
      00773D                       1523 00181$:
                                   1524 ;	quantum/action.c:861: switch (action.kind.id) {
      00773D 90 08 47         [24] 1525 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007740 E0               [24] 1526 	movx	a,@dptr
      007741 C4               [12] 1527 	swap	a
      007742 54 0F            [12] 1528 	anl	a,#0x0f
      007744 FF               [12] 1529 	mov	r7,a
      007745 BF 08 02         [24] 1530 	cjne	r7,#0x08,00478$
      007748 80 03            [24] 1531 	sjmp	00183$
      00774A                       1532 00478$:
      00774A BF 09 06         [24] 1533 	cjne	r7,#0x09,00192$
                                   1534 ;	quantum/action.c:863: case ACT_LAYER_MODS:
      00774D                       1535 00183$:
                                   1536 ;	quantum/action.c:868: led_set(host_keyboard_leds());
      00774D 12 6E 93         [24] 1537 	lcall	_host_keyboard_leds
                                   1538 ;	quantum/action.c:872: }
                                   1539 ;	quantum/action.c:925: }
      007750 02 99 74         [24] 1540 	ljmp	_led_set
      007753                       1541 00192$:
      007753 22               [24] 1542 	ret
                                   1543 ;------------------------------------------------------------
                                   1544 ;Allocation info for local variables in function 'register_code'
                                   1545 ;------------------------------------------------------------
                                   1546 ;code          Allocated with name '_register_code_code_10000_714'
                                   1547 ;------------------------------------------------------------
                                   1548 ;	quantum/action.c:931: __attribute__((weak)) void register_code(uint8_t code) {
                                   1549 ;	-----------------------------------------
                                   1550 ;	 function register_code
                                   1551 ;	-----------------------------------------
      007754                       1552 _register_code:
      007754 E5 82            [12] 1553 	mov	a,dpl
      007756 90 08 4C         [24] 1554 	mov	dptr,#_register_code_code_10000_714
      007759 F0               [24] 1555 	movx	@dptr,a
                                   1556 ;	quantum/action.c:932: if (code == KC_NO) {
      00775A E0               [24] 1557 	movx	a,@dptr
      00775B FF               [12] 1558 	mov	r7,a
      00775C 70 01            [24] 1559 	jnz	00123$
                                   1560 ;	quantum/action.c:933: return;
      00775E 22               [24] 1561 	ret
      00775F                       1562 00123$:
                                   1563 ;	quantum/action.c:968: } else if (IS_BASIC_KEYCODE(code)) {
      00775F BF 04 00         [24] 1564 	cjne	r7,#0x04,00186$
      007762                       1565 00186$:
      007762 40 12            [24] 1566 	jc	00119$
      007764 EF               [12] 1567 	mov	a,r7
      007765 24 5B            [12] 1568 	add	a,#0xff - 0xa4
      007767 40 0D            [24] 1569 	jc	00119$
                                   1570 ;	free result
                                   1571 ;	quantum/action.c:973: if (!add_owned_key(code)) return;
      007769 8F 82            [24] 1572 	mov	dpl, r7
      00776B 12 7F 93         [24] 1573 	lcall	_add_owned_key
      00776E E5 82            [12] 1574 	mov	a, dpl
      007770 70 01            [24] 1575 	jnz	00104$
      007772 22               [24] 1576 	ret
      007773                       1577 00104$:
                                   1578 ;	quantum/action.c:987: send_keyboard_report();
      007773 02 82 31         [24] 1579 	ljmp	_send_keyboard_report
      007776                       1580 00119$:
                                   1581 ;	quantum/action.c:988: } else if (IS_MODIFIER_KEYCODE(code)) {
      007776 12 79 88         [24] 1582 	lcall	_ak820_outline_0170
      007779 BF E0 00         [24] 1583 	cjne	r7,#0xe0,00190$
      00777C                       1584 00190$:
      00777C 40 1A            [24] 1585 	jc	00115$
      00777E EF               [12] 1586 	mov	a,r7
      00777F 24 18            [12] 1587 	add	a,#0xff - 0xe7
      007781 40 15            [24] 1588 	jc	00115$
                                   1589 ;	free result
                                   1590 ;	quantum/action.c:989: add_owned_mods(MOD_BIT(code));
      007783 74 07            [12] 1591 	mov	a,#0x07
      007785 5F               [12] 1592 	anl	a,r7
      007786 12 79 46         [24] 1593 	lcall	_ak820_outline_0063
      007789 80 02            [24] 1594 	sjmp	00194$
      00778B                       1595 00193$:
      00778B 25 E0            [12] 1596 	add	a,acc
      00778D                       1597 00194$:
      00778D D5 F0 FB         [24] 1598 	djnz	b,00193$
      007790 F5 82            [12] 1599 	mov	dpl,a
      007792 12 7E EF         [24] 1600 	lcall	_add_owned_mods
                                   1601 ;	quantum/action.c:990: send_keyboard_report();
      007795 02 82 31         [24] 1602 	ljmp	_send_keyboard_report
      007798                       1603 00115$:
                                   1604 ;	quantum/action.c:993: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      007798 12 79 88         [24] 1605 	lcall	_ak820_outline_0170
      00779B BF A5 00         [24] 1606 	cjne	r7,#0xa5,00195$
      00779E                       1607 00195$:
      00779E 40 05            [24] 1608 	jc	00113$
      0077A0 EF               [12] 1609 	mov	a,r7
      0077A1 24 58            [12] 1610 	add	a,#0xff - 0xa7
      0077A3 50 0D            [24] 1611 	jnc	00108$
                                   1612 ;	free result
      0077A5                       1613 00113$:
      0077A5 12 79 88         [24] 1614 	lcall	_ak820_outline_0170
      0077A8 BF A8 00         [24] 1615 	cjne	r7,#0xa8,00198$
      0077AB                       1616 00198$:
      0077AB 40 13            [24] 1617 	jc	00125$
      0077AD EF               [12] 1618 	mov	a,r7
      0077AE 24 3D            [12] 1619 	add	a,#0xff - 0xc2
      0077B0 40 0E            [24] 1620 	jc	00125$
                                   1621 ;	free result
      0077B2                       1622 00108$:
                                   1623 ;	quantum/action.c:995: owned_usage_key(code, true);
      0077B2 12 79 88         [24] 1624 	lcall	_ak820_outline_0170
      0077B5 90 0A A7         [24] 1625 	mov	dptr,#_owned_usage_key_PARM_2
      0077B8 74 01            [12] 1626 	mov	a,#0x01
      0077BA F0               [24] 1627 	movx	@dptr,a
      0077BB 8F 82            [24] 1628 	mov	dpl, r7
                                   1629 ;	quantum/action.c:1003: register_mouse(code, true);
                                   1630 ;	quantum/action.c:1005: }
      0077BD 02 80 DC         [24] 1631 	ljmp	_owned_usage_key
      0077C0                       1632 00125$:
      0077C0 22               [24] 1633 	ret
                                   1634 ;------------------------------------------------------------
                                   1635 ;Allocation info for local variables in function 'unregister_code'
                                   1636 ;------------------------------------------------------------
                                   1637 ;code          Allocated with name '_unregister_code_code_10000_728'
                                   1638 ;------------------------------------------------------------
                                   1639 ;	quantum/action.c:1011: __attribute__((weak)) void unregister_code(uint8_t code) {
                                   1640 ;	-----------------------------------------
                                   1641 ;	 function unregister_code
                                   1642 ;	-----------------------------------------
      0077C1                       1643 _unregister_code:
      0077C1 E5 82            [12] 1644 	mov	a,dpl
      0077C3 90 08 4D         [24] 1645 	mov	dptr,#_unregister_code_code_10000_728
      0077C6 F0               [24] 1646 	movx	@dptr,a
                                   1647 ;	quantum/action.c:1012: if (code == KC_NO) {
      0077C7 E0               [24] 1648 	movx	a,@dptr
      0077C8 FF               [12] 1649 	mov	r7,a
      0077C9 70 01            [24] 1650 	jnz	00121$
                                   1651 ;	quantum/action.c:1013: return;
      0077CB 22               [24] 1652 	ret
      0077CC                       1653 00121$:
                                   1654 ;	quantum/action.c:1045: } else if (IS_BASIC_KEYCODE(code)) {
      0077CC BF 04 00         [24] 1655 	cjne	r7,#0x04,00184$
      0077CF                       1656 00184$:
      0077CF 40 12            [24] 1657 	jc	00117$
      0077D1 EF               [12] 1658 	mov	a,r7
      0077D2 24 5B            [12] 1659 	add	a,#0xff - 0xa4
      0077D4 40 0D            [24] 1660 	jc	00117$
                                   1661 ;	free result
                                   1662 ;	quantum/action.c:1047: if (!del_owned_key(code)) return;
      0077D6 8F 82            [24] 1663 	mov	dpl, r7
      0077D8 12 80 10         [24] 1664 	lcall	_del_owned_key
      0077DB E5 82            [12] 1665 	mov	a, dpl
      0077DD 70 01            [24] 1666 	jnz	00102$
      0077DF 22               [24] 1667 	ret
      0077E0                       1668 00102$:
                                   1669 ;	quantum/action.c:1054: send_keyboard_report();
      0077E0 02 82 31         [24] 1670 	ljmp	_send_keyboard_report
      0077E3                       1671 00117$:
                                   1672 ;	quantum/action.c:1055: } else if (IS_MODIFIER_KEYCODE(code)) {
      0077E3 12 79 8E         [24] 1673 	lcall	_ak820_outline_0171
      0077E6 BF E0 00         [24] 1674 	cjne	r7,#0xe0,00188$
      0077E9                       1675 00188$:
      0077E9 40 1A            [24] 1676 	jc	00113$
      0077EB EF               [12] 1677 	mov	a,r7
      0077EC 24 18            [12] 1678 	add	a,#0xff - 0xe7
      0077EE 40 15            [24] 1679 	jc	00113$
                                   1680 ;	free result
                                   1681 ;	quantum/action.c:1056: del_owned_mods(MOD_BIT(code));
      0077F0 74 07            [12] 1682 	mov	a,#0x07
      0077F2 5F               [12] 1683 	anl	a,r7
      0077F3 12 79 46         [24] 1684 	lcall	_ak820_outline_0063
      0077F6 80 02            [24] 1685 	sjmp	00192$
      0077F8                       1686 00191$:
      0077F8 25 E0            [12] 1687 	add	a,acc
      0077FA                       1688 00192$:
      0077FA D5 F0 FB         [24] 1689 	djnz	b,00191$
      0077FD F5 82            [12] 1690 	mov	dpl,a
      0077FF 12 7E FF         [24] 1691 	lcall	_del_owned_mods
                                   1692 ;	quantum/action.c:1057: send_keyboard_report();
      007802 02 82 31         [24] 1693 	ljmp	_send_keyboard_report
      007805                       1694 00113$:
                                   1695 ;	quantum/action.c:1060: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      007805 12 79 8E         [24] 1696 	lcall	_ak820_outline_0171
      007808 BF A5 00         [24] 1697 	cjne	r7,#0xa5,00193$
      00780B                       1698 00193$:
      00780B 40 05            [24] 1699 	jc	00111$
      00780D EF               [12] 1700 	mov	a,r7
      00780E 24 58            [12] 1701 	add	a,#0xff - 0xa7
      007810 50 0D            [24] 1702 	jnc	00106$
                                   1703 ;	free result
      007812                       1704 00111$:
      007812 12 79 8E         [24] 1705 	lcall	_ak820_outline_0171
      007815 BF A8 00         [24] 1706 	cjne	r7,#0xa8,00196$
      007818                       1707 00196$:
      007818 40 12            [24] 1708 	jc	00123$
      00781A EF               [12] 1709 	mov	a,r7
      00781B 24 3D            [12] 1710 	add	a,#0xff - 0xc2
      00781D 40 0D            [24] 1711 	jc	00123$
                                   1712 ;	free result
      00781F                       1713 00106$:
                                   1714 ;	quantum/action.c:1062: owned_usage_key(code, false);
      00781F 12 79 8E         [24] 1715 	lcall	_ak820_outline_0171
      007822 90 0A A7         [24] 1716 	mov	dptr,#_owned_usage_key_PARM_2
      007825 E4               [12] 1717 	clr	a
      007826 F0               [24] 1718 	movx	@dptr,a
      007827 8F 82            [24] 1719 	mov	dpl, r7
                                   1720 ;	quantum/action.c:1070: register_mouse(code, false);
                                   1721 ;	quantum/action.c:1072: }
      007829 02 80 DC         [24] 1722 	ljmp	_owned_usage_key
      00782C                       1723 00123$:
      00782C 22               [24] 1724 	ret
                                   1725 ;------------------------------------------------------------
                                   1726 ;Allocation info for local variables in function 'tap_code_delay'
                                   1727 ;------------------------------------------------------------
                                   1728 ;delay         Allocated with name '_tap_code_delay_PARM_2'
                                   1729 ;code          Allocated with name '_tap_code_delay_code_10000_741'
                                   1730 ;i             Allocated with name '_tap_code_delay_i_20000_743'
                                   1731 ;i             Allocated with name '_tap_code_delay_i_50000_746'
                                   1732 ;------------------------------------------------------------
                                   1733 ;	quantum/action.c:1079: __attribute__((weak)) void tap_code_delay(uint8_t code, uint16_t delay) {
                                   1734 ;	-----------------------------------------
                                   1735 ;	 function tap_code_delay
                                   1736 ;	-----------------------------------------
      00782D                       1737 _tap_code_delay:
      00782D E5 82            [12] 1738 	mov	a,dpl
      00782F 90 08 50         [24] 1739 	mov	dptr,#_tap_code_delay_code_10000_741
      007832 F0               [24] 1740 	movx	@dptr,a
                                   1741 ;	quantum/action.c:1080: register_code(code);
      007833 E0               [24] 1742 	movx	a,@dptr
      007834 FF               [12] 1743 	mov	r7,a
      007835 F5 82            [12] 1744 	mov	dpl,a
      007837 C0 07            [24] 1745 	push	ar7
      007839 12 77 54         [24] 1746 	lcall	_register_code
      00783C D0 07            [24] 1747 	pop	ar7
                                   1748 ;	quantum/action.c:1081: for (uint16_t i = delay; i > 0; i--) {
      00783E 90 08 4E         [24] 1749 	mov	dptr,#_tap_code_delay_PARM_2
      007841 12 3A AF         [24] 1750 	lcall	_ak820_outline_0080
      007844                       1751 00110$:
      007844 ED               [12] 1752 	mov	a,r5
      007845 4E               [12] 1753 	orl	a,r6
      007846 60 0D            [24] 1754 	jz	00105$
                                   1755 ;	quantum/action.c:1082: wait_ms(1);
      007848 90 00 01         [24] 1756 	mov	dptr,#0x0001
      00784B 12 5B 08         [24] 1757 	lcall	_mDelaymS
                                   1758 ;	quantum/action.c:1081: for (uint16_t i = delay; i > 0; i--) {
      00784E 1D               [12] 1759 	dec	r5
      00784F BD FF 01         [24] 1760 	cjne	r5,#0xff,00141$
      007852 1E               [12] 1761 	dec	r6
      007853                       1762 00141$:
      007853 80 EF            [24] 1763 	sjmp	00110$
      007855                       1764 00105$:
                                   1765 ;	quantum/action.c:1084: unregister_code(code);
      007855 8F 82            [24] 1766 	mov	dpl, r7
                                   1767 ;	quantum/action.c:1085: }
      007857 02 77 C1         [24] 1768 	ljmp	_unregister_code
                                   1769 ;------------------------------------------------------------
                                   1770 ;Allocation info for local variables in function 'tap_code'
                                   1771 ;------------------------------------------------------------
                                   1772 ;code          Allocated with name '_tap_code_code_10000_748'
                                   1773 ;------------------------------------------------------------
                                   1774 ;	quantum/action.c:1091: __attribute__((weak)) void tap_code(uint8_t code) {
                                   1775 ;	-----------------------------------------
                                   1776 ;	 function tap_code
                                   1777 ;	-----------------------------------------
      00785A                       1778 _tap_code:
      00785A E5 82            [12] 1779 	mov	a,dpl
      00785C 90 08 51         [24] 1780 	mov	dptr,#_tap_code_code_10000_748
      00785F F0               [24] 1781 	movx	@dptr,a
                                   1782 ;	quantum/action.c:1092: tap_code_delay(code, code == KC_CAPS ? QS_tap_hold_caps_delay : QS_tap_code_delay);
      007860 E0               [24] 1783 	movx	a,@dptr
      007861 FF               [12] 1784 	mov	r7,a
      007862 BF 39 04         [24] 1785 	cjne	r7,#0x39,00103$
      007865 7E 50            [12] 1786 	mov	r6,#0x50
      007867 80 02            [24] 1787 	sjmp	00104$
      007869                       1788 00103$:
      007869 7E 00            [12] 1789 	mov	r6,#0x00
      00786B                       1790 00104$:
      00786B 90 08 4E         [24] 1791 	mov	dptr,#_tap_code_delay_PARM_2
      00786E EE               [12] 1792 	mov	a,r6
      00786F 12 3A E7         [24] 1793 	lcall	_ak820_outline_0136
      007872 8F 82            [24] 1794 	mov	dpl, r7
                                   1795 ;	quantum/action.c:1093: }
      007874 02 78 2D         [24] 1796 	ljmp	_tap_code_delay
                                   1797 ;------------------------------------------------------------
                                   1798 ;Allocation info for local variables in function 'register_mods'
                                   1799 ;------------------------------------------------------------
                                   1800 ;mods          Allocated with name '_register_mods_mods_10000_750'
                                   1801 ;------------------------------------------------------------
                                   1802 ;	quantum/action.c:1099: __attribute__((weak)) void register_mods(uint8_t mods) {
                                   1803 ;	-----------------------------------------
                                   1804 ;	 function register_mods
                                   1805 ;	-----------------------------------------
      007877                       1806 _register_mods:
      007877 E5 82            [12] 1807 	mov	a,dpl
      007879 90 08 52         [24] 1808 	mov	dptr,#_register_mods_mods_10000_750
      00787C F0               [24] 1809 	movx	@dptr,a
                                   1810 ;	quantum/action.c:1100: if (mods) {
      00787D E0               [24] 1811 	movx	a,@dptr
      00787E FF               [12] 1812 	mov	r7,a
      00787F E0               [24] 1813 	movx	a,@dptr
      007880 60 08            [24] 1814 	jz	00103$
                                   1815 ;	quantum/action.c:1101: add_owned_mods(mods);
      007882 8F 82            [24] 1816 	mov	dpl, r7
      007884 12 7E EF         [24] 1817 	lcall	_add_owned_mods
                                   1818 ;	quantum/action.c:1102: send_keyboard_report();
                                   1819 ;	quantum/action.c:1104: }
      007887 02 82 31         [24] 1820 	ljmp	_send_keyboard_report
      00788A                       1821 00103$:
      00788A 22               [24] 1822 	ret
                                   1823 ;------------------------------------------------------------
                                   1824 ;Allocation info for local variables in function 'unregister_mods'
                                   1825 ;------------------------------------------------------------
                                   1826 ;mods          Allocated with name '_unregister_mods_mods_10000_754'
                                   1827 ;------------------------------------------------------------
                                   1828 ;	quantum/action.c:1110: __attribute__((weak)) void unregister_mods(uint8_t mods) {
                                   1829 ;	-----------------------------------------
                                   1830 ;	 function unregister_mods
                                   1831 ;	-----------------------------------------
      00788B                       1832 _unregister_mods:
      00788B E5 82            [12] 1833 	mov	a,dpl
      00788D 90 08 53         [24] 1834 	mov	dptr,#_unregister_mods_mods_10000_754
      007890 F0               [24] 1835 	movx	@dptr,a
                                   1836 ;	quantum/action.c:1111: if (mods) {
      007891 E0               [24] 1837 	movx	a,@dptr
      007892 FF               [12] 1838 	mov	r7,a
      007893 E0               [24] 1839 	movx	a,@dptr
      007894 60 08            [24] 1840 	jz	00103$
                                   1841 ;	quantum/action.c:1112: del_owned_mods(mods);
      007896 8F 82            [24] 1842 	mov	dpl, r7
      007898 12 7E FF         [24] 1843 	lcall	_del_owned_mods
                                   1844 ;	quantum/action.c:1113: send_keyboard_report();
                                   1845 ;	quantum/action.c:1115: }
      00789B 02 82 31         [24] 1846 	ljmp	_send_keyboard_report
      00789E                       1847 00103$:
      00789E 22               [24] 1848 	ret
                                   1849 ;------------------------------------------------------------
                                   1850 ;Allocation info for local variables in function 'register_weak_mods'
                                   1851 ;------------------------------------------------------------
                                   1852 ;mods          Allocated with name '_register_weak_mods_mods_10000_758'
                                   1853 ;------------------------------------------------------------
                                   1854 ;	quantum/action.c:1121: __attribute__((weak)) void register_weak_mods(uint8_t mods) {
                                   1855 ;	-----------------------------------------
                                   1856 ;	 function register_weak_mods
                                   1857 ;	-----------------------------------------
      00789F                       1858 _register_weak_mods:
      00789F E5 82            [12] 1859 	mov	a,dpl
      0078A1 90 08 54         [24] 1860 	mov	dptr,#_register_weak_mods_mods_10000_758
      0078A4 F0               [24] 1861 	movx	@dptr,a
                                   1862 ;	quantum/action.c:1122: if (mods) {
      0078A5 E0               [24] 1863 	movx	a,@dptr
      0078A6 FF               [12] 1864 	mov	r7,a
      0078A7 E0               [24] 1865 	movx	a,@dptr
      0078A8 60 08            [24] 1866 	jz	00103$
                                   1867 ;	quantum/action.c:1123: add_owned_weak_mods(mods);
      0078AA 8F 82            [24] 1868 	mov	dpl, r7
      0078AC 12 7F 0E         [24] 1869 	lcall	_add_owned_weak_mods
                                   1870 ;	quantum/action.c:1124: send_keyboard_report();
                                   1871 ;	quantum/action.c:1126: }
      0078AF 02 82 31         [24] 1872 	ljmp	_send_keyboard_report
      0078B2                       1873 00103$:
      0078B2 22               [24] 1874 	ret
                                   1875 ;------------------------------------------------------------
                                   1876 ;Allocation info for local variables in function 'unregister_weak_mods'
                                   1877 ;------------------------------------------------------------
                                   1878 ;mods          Allocated with name '_unregister_weak_mods_mods_10000_762'
                                   1879 ;------------------------------------------------------------
                                   1880 ;	quantum/action.c:1132: __attribute__((weak)) void unregister_weak_mods(uint8_t mods) {
                                   1881 ;	-----------------------------------------
                                   1882 ;	 function unregister_weak_mods
                                   1883 ;	-----------------------------------------
      0078B3                       1884 _unregister_weak_mods:
      0078B3 E5 82            [12] 1885 	mov	a,dpl
      0078B5 90 08 55         [24] 1886 	mov	dptr,#_unregister_weak_mods_mods_10000_762
      0078B8 F0               [24] 1887 	movx	@dptr,a
                                   1888 ;	quantum/action.c:1133: if (mods) {
      0078B9 E0               [24] 1889 	movx	a,@dptr
      0078BA FF               [12] 1890 	mov	r7,a
      0078BB E0               [24] 1891 	movx	a,@dptr
      0078BC 60 08            [24] 1892 	jz	00103$
                                   1893 ;	quantum/action.c:1134: del_owned_weak_mods(mods);
      0078BE 8F 82            [24] 1894 	mov	dpl, r7
      0078C0 12 7F 1E         [24] 1895 	lcall	_del_owned_weak_mods
                                   1896 ;	quantum/action.c:1135: send_keyboard_report();
                                   1897 ;	quantum/action.c:1137: }
      0078C3 02 82 31         [24] 1898 	ljmp	_send_keyboard_report
      0078C6                       1899 00103$:
      0078C6 22               [24] 1900 	ret
                                   1901 ;------------------------------------------------------------
                                   1902 ;Allocation info for local variables in function 'clear_keyboard'
                                   1903 ;------------------------------------------------------------
                                   1904 ;	quantum/action.c:1143: void clear_keyboard(void) {
                                   1905 ;	-----------------------------------------
                                   1906 ;	 function clear_keyboard
                                   1907 ;	-----------------------------------------
      0078C7                       1908 _clear_keyboard:
                                   1909 ;	quantum/action.c:1144: clear_mods();
      0078C7 12 82 AC         [24] 1910 	lcall	_clear_mods
                                   1911 ;	quantum/action.c:1145: clear_keyboard_but_mods();
                                   1912 ;	quantum/action.c:1146: }
      0078CA 02 78 CD         [24] 1913 	ljmp	_clear_keyboard_but_mods
                                   1914 ;------------------------------------------------------------
                                   1915 ;Allocation info for local variables in function 'clear_keyboard_but_mods'
                                   1916 ;------------------------------------------------------------
                                   1917 ;	quantum/action.c:1152: void clear_keyboard_but_mods(void) {
                                   1918 ;	-----------------------------------------
                                   1919 ;	 function clear_keyboard_but_mods
                                   1920 ;	-----------------------------------------
      0078CD                       1921 _clear_keyboard_but_mods:
                                   1922 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      0078CD 90 0D DA         [24] 1923 	mov	dptr,#_actual_keyboard_report
      0078D0 75 F0 00         [24] 1924 	mov	b, #0x00
      0078D3 12 71 6A         [24] 1925 	lcall	_clear_keys_from_report
                                   1926 ;	quantum/action.c:1154: clear_keyboard_but_mods_and_keys();
                                   1927 ;	quantum/action.c:1155: }
      0078D6 02 78 D9         [24] 1928 	ljmp	_clear_keyboard_but_mods_and_keys
                                   1929 ;------------------------------------------------------------
                                   1930 ;Allocation info for local variables in function 'clear_keyboard_but_mods_and_keys'
                                   1931 ;------------------------------------------------------------
                                   1932 ;	quantum/action.c:1161: void clear_keyboard_but_mods_and_keys(void) {
                                   1933 ;	-----------------------------------------
                                   1934 ;	 function clear_keyboard_but_mods_and_keys
                                   1935 ;	-----------------------------------------
      0078D9                       1936 _clear_keyboard_but_mods_and_keys:
                                   1937 ;	quantum/action.c:1163: ak820_tapping_cancel();
      0078D9 12 49 16         [24] 1938 	lcall	_ak820_tapping_cancel
                                   1939 ;	quantum/action.c:1168: ak820_autoshift_cancel();
      0078DC 12 33 4A         [24] 1940 	lcall	_ak820_autoshift_cancel
                                   1941 ;	quantum/action.c:1171: ak820_oneshot_cancel();
      0078DF 12 2E F0         [24] 1942 	lcall	_ak820_oneshot_cancel
                                   1943 ;	quantum/action.c:1174: ak820_combo_cancel();
      0078E2 12 37 BB         [24] 1944 	lcall	_ak820_combo_cancel
                                   1945 ;	quantum/action.c:1177: repeat_key_cancel();
      0078E5 12 A3 65         [24] 1946 	lcall	_repeat_key_cancel
                                   1947 ;	quantum/action.c:1179: clear_owned_mods();
      0078E8 12 7F 2E         [24] 1948 	lcall	_clear_owned_mods
                                   1949 ;	quantum/action.c:1180: clear_owned_keys();
      0078EB 12 7F 66         [24] 1950 	lcall	_clear_owned_keys
                                   1951 ;	quantum/action.c:1181: clear_owned_usages();
      0078EE 12 80 A4         [24] 1952 	lcall	_clear_owned_usages
                                   1953 ;	quantum/action.c:1182: layer_hold_clear();
      0078F1 12 7A DA         [24] 1954 	lcall	_layer_hold_clear
                                   1955 ;	quantum/action.c:1184: clear_macro_tri_layer();
      0078F4 12 9E 29         [24] 1956 	lcall	_clear_macro_tri_layer
                                   1957 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      0078F7 90 0D DA         [24] 1958 	mov	dptr,#_actual_keyboard_report
      0078FA 75 F0 00         [24] 1959 	mov	b, #0x00
      0078FD 12 71 6A         [24] 1960 	lcall	_clear_keys_from_report
                                   1961 ;	quantum/action.c:1189: host_system_send(0);
      007900 90 00 00         [24] 1962 	mov	dptr,#0x0000
      007903 12 6F 2E         [24] 1963 	lcall	_host_system_send
                                   1964 ;	quantum/action.c:1190: host_consumer_send(0);
      007906 90 00 00         [24] 1965 	mov	dptr,#0x0000
      007909 12 6F 5E         [24] 1966 	lcall	_host_consumer_send
                                   1967 ;	quantum/action.c:1192: clear_weak_mods();
      00790C 12 82 E1         [24] 1968 	lcall	_clear_weak_mods
                                   1969 ;	quantum/action.c:1193: send_keyboard_report();
                                   1970 ;	quantum/action.c:1201: }
      00790F 02 82 31         [24] 1971 	ljmp	_send_keyboard_report
                                   1972 ;------------------------------------------------------------
                                   1973 ;Allocation info for local variables in function 'is_tap_record'
                                   1974 ;------------------------------------------------------------
                                   1975 ;record        Allocated with name '_is_tap_record_record_10000_778'
                                   1976 ;action        Allocated with name '_is_tap_record_action_10001_782'
                                   1977 ;------------------------------------------------------------
                                   1978 ;	quantum/action.c:1207: bool is_tap_record(keyrecord_t *record) {
                                   1979 ;	-----------------------------------------
                                   1980 	.area CSEG    (CODE)
                                   1981 	.area CONST   (CODE)
                                   1982 	.area XINIT   (CODE)
      00C2E2                       1983 __xinit__disable_action_cache:
      00C2E2 00                    1984 	.db #0x00	;  0
                                   1985 	.area CABS    (ABS,CODE)
                                   1986 
                                   1987 ; Experimental exact instruction outlining.
                                   1988 	.globl _ak820_outline_0001
                                   1989 	.globl _ak820_outline_0005
                                   1990 	.globl _ak820_outline_0007
                                   1991 	.globl _ak820_outline_0008
                                   1992 	.globl _ak820_outline_0011
                                   1993 	.globl _ak820_outline_0012
                                   1994 	.globl _ak820_outline_0013
                                   1995 	.globl _ak820_outline_0014
                                   1996 	.globl _ak820_outline_0016
                                   1997 	.globl _ak820_outline_0021
                                   1998 	.globl _ak820_outline_0022
                                   1999 	.globl _ak820_outline_0034
                                   2000 	.globl _ak820_outline_0036
                                   2001 	.globl _ak820_outline_0042
                                   2002 	.globl _ak820_outline_0050
                                   2003 	.globl _ak820_outline_0059
                                   2004 	.globl _ak820_outline_0063
                                   2005 	.globl _ak820_outline_0071
                                   2006 	.globl _ak820_outline_0072
                                   2007 	.globl _ak820_outline_0078
                                   2008 	.globl _ak820_outline_0080
                                   2009 	.globl _ak820_outline_0090
                                   2010 	.globl _ak820_outline_0094
                                   2011 	.globl _ak820_outline_0109
                                   2012 	.globl _ak820_outline_0110
                                   2013 	.globl _ak820_outline_0112
                                   2014 	.globl _ak820_outline_0114
                                   2015 	.globl _ak820_outline_0115
                                   2016 	.globl _ak820_outline_0120
                                   2017 	.globl _ak820_outline_0125
                                   2018 	.globl _ak820_outline_0126
                                   2019 	.globl _ak820_outline_0132
                                   2020 	.globl _ak820_outline_0135
                                   2021 	.globl _ak820_outline_0136
                                   2022 	.globl _ak820_outline_0144
                                   2023 	.globl _ak820_outline_0148
                                   2024 	.globl _ak820_outline_0151
                                   2025 	.globl _ak820_outline_0160
                                   2026 	.globl _ak820_outline_0162
                                   2027 	.globl _ak820_outline_0170
                                   2028 	.globl _ak820_outline_0171
                                   2029 	.globl _ak820_outline_0184
                                   2030 	.globl _ak820_outline_0189
                                   2031 
                                   2032 	.area CSEG (CODE)
                                   2033 ; function ak820_outline_0013
      007912                       2034 _ak820_outline_0013:
      007912 2D               [12] 2035 	add	a,r5
      007913 F9               [12] 2036 	mov	r1,a
      007914 E4               [12] 2037 	clr	a
      007915 3E               [12] 2038 	addc	a,r6
      007916 FA               [12] 2039 	mov	r2,a
      007917 8F 03            [24] 2040 	mov	ar3,r7
      007919 89 82            [24] 2041 	mov	dpl,r1
      00791B 8A 83            [24] 2042 	mov	dph,r2
      00791D 8B F0            [24] 2043 	mov	b,r3
      00791F 22               [24] 2044 	ret
                                   2045 
                                   2046 	.area CSEG (CODE)
                                   2047 ; function ak820_outline_0014
      007920                       2048 _ak820_outline_0014:
      007920 2D               [12] 2049 	add	a,r5
      007921 FA               [12] 2050 	mov	r2,a
      007922 E4               [12] 2051 	clr	a
      007923 3E               [12] 2052 	addc	a,r6
      007924 FB               [12] 2053 	mov	r3,a
      007925 8F 04            [24] 2054 	mov	ar4,r7
      007927 8A 82            [24] 2055 	mov	dpl,r2
      007929 8B 83            [24] 2056 	mov	dph,r3
      00792B 8C F0            [24] 2057 	mov	b,r4
      00792D 22               [24] 2058 	ret
                                   2059 
                                   2060 	.area CSEG (CODE)
                                   2061 ; function ak820_outline_0021
      00792E                       2062 _ak820_outline_0021:
      00792E 8E 82            [24] 2063 	mov	dpl,r6
      007930 8F 83            [24] 2064 	mov	dph,r7
      007932 A3               [24] 2065 	inc	dptr
      007933 E0               [24] 2066 	movx	a,@dptr
      007934 FC               [12] 2067 	mov	r4,a
      007935 7D 00            [12] 2068 	mov	r5,#0x00
      007937 8E 82            [24] 2069 	mov	dpl,r6
      007939 8F 83            [24] 2070 	mov	dph,r7
      00793B E0               [24] 2071 	movx	a,@dptr
      00793C 22               [24] 2072 	ret
                                   2073 
                                   2074 	.area CSEG (CODE)
                                   2075 ; function ak820_outline_0042
      00793D                       2076 _ak820_outline_0042:
      00793D 90 08 47         [24] 2077 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007940 E0               [24] 2078 	movx	a,@dptr
      007941 54 1F            [12] 2079 	anl	a,#0x1f
      007943 F5 82            [12] 2080 	mov	dpl,a
      007945 22               [24] 2081 	ret
                                   2082 
                                   2083 	.area CSEG (CODE)
                                   2084 ; function ak820_outline_0063
      007946                       2085 _ak820_outline_0063:
      007946 F5 F0            [12] 2086 	mov	b,a
      007948 05 F0            [12] 2087 	inc	b
      00794A 74 01            [12] 2088 	mov	a,#0x01
      00794C 22               [24] 2089 	ret
                                   2090 
                                   2091 	.area CSEG (CODE)
                                   2092 ; function ak820_outline_0071
      00794D                       2093 _ak820_outline_0071:
      00794D 90 0D B7         [24] 2094 	mov	dptr,#___memcpy_PARM_3
      007950 74 06            [12] 2095 	mov	a,#0x06
      007952 F0               [24] 2096 	movx	@dptr,a
      007953 E4               [12] 2097 	clr	a
      007954 A3               [24] 2098 	inc	dptr
      007955 F0               [24] 2099 	movx	@dptr,a
      007956 22               [24] 2100 	ret
                                   2101 
                                   2102 	.area CSEG (CODE)
                                   2103 ; function ak820_outline_0078
      007957                       2104 _ak820_outline_0078:
      007957 90 08 46         [24] 2105 	mov	dptr,#_process_action_PARM_2
      00795A E0               [24] 2106 	movx	a,@dptr
      00795B F5 82            [12] 2107 	mov	dpl,a
      00795D 22               [24] 2108 	ret
                                   2109 
                                   2110 	.area CSEG (CODE)
                                   2111 ; function ak820_outline_0090
      00795E                       2112 _ak820_outline_0090:
      00795E 90 08 47         [24] 2113 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007961 E0               [24] 2114 	movx	a,@dptr
      007962 03               [12] 2115 	rr	a
      007963 03               [12] 2116 	rr	a
      007964 54 03            [12] 2117 	anl	a,#0x03
      007966 22               [24] 2118 	ret
                                   2119 
                                   2120 	.area CSEG (CODE)
                                   2121 ; function ak820_outline_0115
      007967                       2122 _ak820_outline_0115:
      007967 90 08 47         [24] 2123 	mov	dptr,#(_process_action_PARM_2+0x0001)
      00796A E0               [24] 2124 	movx	a,@dptr
      00796B 54 0F            [12] 2125 	anl	a,#0x0f
      00796D 22               [24] 2126 	ret
                                   2127 
                                   2128 	.area CSEG (CODE)
                                   2129 ; function ak820_outline_0132
      00796E                       2130 _ak820_outline_0132:
      00796E 90 08 46         [24] 2131 	mov	dptr,#_process_action_PARM_2
      007971 E0               [24] 2132 	movx	a,@dptr
      007972 FE               [12] 2133 	mov	r6,a
      007973 A3               [24] 2134 	inc	dptr
      007974 E0               [24] 2135 	movx	a,@dptr
      007975 54 03            [12] 2136 	anl	a,#0x03
      007977 FF               [12] 2137 	mov	r7,a
      007978 22               [24] 2138 	ret
                                   2139 
                                   2140 	.area CSEG (CODE)
                                   2141 ; function ak820_outline_0148
      007979                       2142 _ak820_outline_0148:
      007979 74 07            [12] 2143 	mov	a,#0x07
      00797B 2D               [12] 2144 	add	a,r5
      00797C F8               [12] 2145 	mov	r0,a
      00797D E4               [12] 2146 	clr	a
      00797E 3E               [12] 2147 	addc	a,r6
      00797F F9               [12] 2148 	mov	r1,a
      007980 8F 02            [24] 2149 	mov	ar2,r7
      007982 22               [24] 2150 	ret
                                   2151 
                                   2152 	.area CSEG (CODE)
                                   2153 ; function ak820_outline_0162
      007983                       2154 _ak820_outline_0162:
      007983 90 08 46         [24] 2155 	mov	dptr,#_process_action_PARM_2
      007986 E0               [24] 2156 	movx	a,@dptr
      007987 22               [24] 2157 	ret
                                   2158 
                                   2159 	.area CSEG (CODE)
                                   2160 ; function ak820_outline_0170
      007988                       2161 _ak820_outline_0170:
      007988 90 08 4C         [24] 2162 	mov	dptr,#_register_code_code_10000_714
      00798B E0               [24] 2163 	movx	a,@dptr
      00798C FF               [12] 2164 	mov	r7,a
      00798D 22               [24] 2165 	ret
                                   2166 
                                   2167 	.area CSEG (CODE)
                                   2168 ; function ak820_outline_0171
      00798E                       2169 _ak820_outline_0171:
      00798E 90 08 4D         [24] 2170 	mov	dptr,#_unregister_code_code_10000_728
      007991 E0               [24] 2171 	movx	a,@dptr
      007992 FF               [12] 2172 	mov	r7,a
      007993 22               [24] 2173 	ret
                                   2174 
                                   2175 	.area CSEG (CODE)
                                   2176 ; function ak820_outline_0189
      007994                       2177 _ak820_outline_0189:
      007994 F0               [24] 2178 	movx	@dptr,a
      007995 EB               [12] 2179 	mov	a,r3
      007996 A3               [24] 2180 	inc	dptr
      007997 F0               [24] 2181 	movx	@dptr,a
      007998 22               [24] 2182 	ret
