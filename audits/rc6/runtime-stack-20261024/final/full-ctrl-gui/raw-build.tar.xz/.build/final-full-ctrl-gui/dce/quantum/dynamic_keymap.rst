                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module dynamic_keymap
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _dynamic_keymap_encoder_to_eeprom_address
                                     12 	.globl _ak820_combo_valid
                                     13 	.globl _ak820_eeprom_write_block_xdata
                                     14 	.globl _ak820_eeprom_read_block_xdata
                                     15 	.globl _ak820_nvm_flush
                                     16 	.globl _ak820_nvm_ok
                                     17 	.globl _ak820_macro_reset
                                     18 	.globl _ak820_macro_write
                                     19 	.globl _ak820_macro_length
                                     20 	.globl _ak820_macro_ready
                                     21 	.globl _send_char
                                     22 	.globl _keycode_at_encodermap_location_raw
                                     23 	.globl _keycode_at_keymap_location_raw
                                     24 	.globl _vial_keycode_tap
                                     25 	.globl _vial_keycode_up
                                     26 	.globl _vial_keycode_down
                                     27 	.globl _clear_keyboard
                                     28 	.globl _tap_code
                                     29 	.globl _unregister_code
                                     30 	.globl _register_code
                                     31 	.globl _mDelaymS
                                     32 	.globl ___memcpy
                                     33 	.globl _memset
                                     34 	.globl _eeprom_update_byte
                                     35 	.globl _eeprom_read_byte
                                     36 	.globl _ADC_START
                                     37 	.globl _S0_R_FIFO
                                     38 	.globl _S0_T_FIFO
                                     39 	.globl _S0_FREE
                                     40 	.globl _S0_IF_BYTE
                                     41 	.globl _S0_IF_FIRST
                                     42 	.globl _S0_IF_OV
                                     43 	.globl _S0_FST_ACT
                                     44 	.globl _CP_RL2
                                     45 	.globl _C_T2
                                     46 	.globl _TR2
                                     47 	.globl _EXEN2
                                     48 	.globl _TCLK
                                     49 	.globl _RCLK
                                     50 	.globl _EXF2
                                     51 	.globl _CAP1F
                                     52 	.globl _TF2
                                     53 	.globl _RI
                                     54 	.globl _TI
                                     55 	.globl _RB8
                                     56 	.globl _TB8
                                     57 	.globl _REN
                                     58 	.globl _SM2
                                     59 	.globl _SM1
                                     60 	.globl _SM0
                                     61 	.globl _IT0
                                     62 	.globl _IE0
                                     63 	.globl _IT1
                                     64 	.globl _IE1
                                     65 	.globl _TR0
                                     66 	.globl _TF0
                                     67 	.globl _TR1
                                     68 	.globl _TF1
                                     69 	.globl _P4_0
                                     70 	.globl _P4_1
                                     71 	.globl _P4_2
                                     72 	.globl _P4_3
                                     73 	.globl _P4_4
                                     74 	.globl _P4_5
                                     75 	.globl _P4_6
                                     76 	.globl _RXD
                                     77 	.globl _TXD
                                     78 	.globl _INT0
                                     79 	.globl _INT1
                                     80 	.globl _T0
                                     81 	.globl _T1
                                     82 	.globl _MOSI1
                                     83 	.globl _MISO1
                                     84 	.globl _SCK1
                                     85 	.globl _P3_0
                                     86 	.globl _P3_1
                                     87 	.globl _P3_2
                                     88 	.globl _P3_3
                                     89 	.globl _P3_4
                                     90 	.globl _P3_5
                                     91 	.globl _P3_6
                                     92 	.globl _P3_7
                                     93 	.globl _CAP1_
                                     94 	.globl _T2_
                                     95 	.globl _CAP2_
                                     96 	.globl _T2EX_
                                     97 	.globl _RXD1
                                     98 	.globl _TXD1
                                     99 	.globl _P2_0
                                    100 	.globl _P2_1
                                    101 	.globl _P2_2
                                    102 	.globl _P2_3
                                    103 	.globl _P2_4
                                    104 	.globl _P2_5
                                    105 	.globl _P2_6
                                    106 	.globl _P2_7
                                    107 	.globl _AIN0
                                    108 	.globl _AIN1
                                    109 	.globl _AIN2
                                    110 	.globl _AIN3
                                    111 	.globl _AIN4
                                    112 	.globl _AIN5
                                    113 	.globl _AIN6
                                    114 	.globl _AIN7
                                    115 	.globl _CAP1
                                    116 	.globl _T2
                                    117 	.globl _CAP2
                                    118 	.globl _T2EX
                                    119 	.globl _INT0_
                                    120 	.globl _SCS
                                    121 	.globl _MOSI
                                    122 	.globl _MISO
                                    123 	.globl _SCK
                                    124 	.globl _RXD1_
                                    125 	.globl _TXD1_
                                    126 	.globl _P1_0
                                    127 	.globl _P1_1
                                    128 	.globl _P1_2
                                    129 	.globl _P1_3
                                    130 	.globl _P1_4
                                    131 	.globl _P1_5
                                    132 	.globl _P1_6
                                    133 	.globl _P1_7
                                    134 	.globl _AIN8
                                    135 	.globl _AIN9
                                    136 	.globl _AIN10
                                    137 	.globl _AIN11
                                    138 	.globl _AIN12
                                    139 	.globl _AIN13
                                    140 	.globl _RXD_
                                    141 	.globl _TXD_
                                    142 	.globl _SCL0
                                    143 	.globl _SDA0
                                    144 	.globl _P0_0
                                    145 	.globl _P0_1
                                    146 	.globl _P0_2
                                    147 	.globl _P0_3
                                    148 	.globl _P0_4
                                    149 	.globl _P0_5
                                    150 	.globl _P0_6
                                    151 	.globl _P0_7
                                    152 	.globl _IE_SPI0
                                    153 	.globl _IE_USB
                                    154 	.globl _IE_ADC
                                    155 	.globl _IE_UART1
                                    156 	.globl _IE_PWM_I2C
                                    157 	.globl _IE_GPIO
                                    158 	.globl _IE_WDOG
                                    159 	.globl _PX0
                                    160 	.globl _PT0
                                    161 	.globl _PX1
                                    162 	.globl _PT1
                                    163 	.globl _PS
                                    164 	.globl _PT2
                                    165 	.globl _PL_FLAG
                                    166 	.globl _PH_FLAG
                                    167 	.globl _EX0
                                    168 	.globl _ET0
                                    169 	.globl _EX1
                                    170 	.globl _ET1
                                    171 	.globl _ES
                                    172 	.globl _ET2
                                    173 	.globl _E_DIS
                                    174 	.globl _EA
                                    175 	.globl _P
                                    176 	.globl _F1
                                    177 	.globl _OV
                                    178 	.globl _RS0
                                    179 	.globl _RS1
                                    180 	.globl _F0
                                    181 	.globl _AC
                                    182 	.globl _CY
                                    183 	.globl _I2CS_INT_ST
                                    184 	.globl _I2CX_INT
                                    185 	.globl _LED_STATUS
                                    186 	.globl _LED_DMA_H
                                    187 	.globl _LED_DMA_L
                                    188 	.globl _LED_DMA
                                    189 	.globl _LED_PWM_OE
                                    190 	.globl _LED_COMMON
                                    191 	.globl _ADC_CHAN
                                    192 	.globl _ADC_DAT_H
                                    193 	.globl _ADC_DAT_L
                                    194 	.globl _ADC_DAT
                                    195 	.globl _ADC_CTRL
                                    196 	.globl _SPI1_CK_SE
                                    197 	.globl _SPI1_CTRL
                                    198 	.globl _SPI1_DATA
                                    199 	.globl _SPI1_STAT
                                    200 	.globl _SIF1
                                    201 	.globl _SBAUD1
                                    202 	.globl _SBUF1
                                    203 	.globl _SCON1
                                    204 	.globl _SPI0_SETUP
                                    205 	.globl _SPI0_CK_SE
                                    206 	.globl _SPI0_CTRL
                                    207 	.globl _SPI0_DATA
                                    208 	.globl _SPI0_STAT
                                    209 	.globl _T2CAP1H
                                    210 	.globl _T2CAP1L
                                    211 	.globl _T2CAP1
                                    212 	.globl _TH2
                                    213 	.globl _TL2
                                    214 	.globl _T2COUNT
                                    215 	.globl _RCAP2H
                                    216 	.globl _RCAP2L
                                    217 	.globl _RCAP2
                                    218 	.globl _T2MOD
                                    219 	.globl _T2CON
                                    220 	.globl _SBUF
                                    221 	.globl _SCON
                                    222 	.globl _TH1
                                    223 	.globl _TH0
                                    224 	.globl _TL1
                                    225 	.globl _TL0
                                    226 	.globl _TMOD
                                    227 	.globl _TCON
                                    228 	.globl _XBUS_AUX
                                    229 	.globl _P7
                                    230 	.globl _P6_DIR
                                    231 	.globl _P6_OUT_PU
                                    232 	.globl _P6_IN
                                    233 	.globl _P5_DIR
                                    234 	.globl _P5_OUT_PU
                                    235 	.globl _P5_IN
                                    236 	.globl _P4_LED_KEY
                                    237 	.globl _P4_DIR_PU
                                    238 	.globl _P4_MOD_OC
                                    239 	.globl _P4
                                    240 	.globl _P3_DIR_PU
                                    241 	.globl _P3_MOD_OC
                                    242 	.globl _P3
                                    243 	.globl _P2_DIR_PU
                                    244 	.globl _P2_MOD_OC
                                    245 	.globl _P2
                                    246 	.globl _P1_DIR_PU
                                    247 	.globl _P1_MOD_OC
                                    248 	.globl _P1
                                    249 	.globl _P0_DIR_PU
                                    250 	.globl _P0_MOD_OC
                                    251 	.globl _P0
                                    252 	.globl _ROM_CTRL
                                    253 	.globl _ROM_DATA_HH
                                    254 	.globl _ROM_DATA_HL
                                    255 	.globl _ROM_DATA_HI
                                    256 	.globl _ROM_ADDR_H
                                    257 	.globl _ROM_ADDR_L
                                    258 	.globl _ROM_ADDR
                                    259 	.globl _GPIO_IE
                                    260 	.globl _IP_EX
                                    261 	.globl _IE_EX
                                    262 	.globl _IP
                                    263 	.globl _IE
                                    264 	.globl _WDOG_COUNT
                                    265 	.globl _RESET_KEEP
                                    266 	.globl _WAKE_CTRL
                                    267 	.globl _CLOCK_CFG
                                    268 	.globl _POWER_CFG
                                    269 	.globl _PCON
                                    270 	.globl _GLOBAL_CFG
                                    271 	.globl _SAFE_MOD
                                    272 	.globl _DPH
                                    273 	.globl _DPL
                                    274 	.globl _SP
                                    275 	.globl _A_INV
                                    276 	.globl _B
                                    277 	.globl _ACC
                                    278 	.globl _PSW
                                    279 	.globl _dynamic_keymap_macro_set_buffer_PARM_3
                                    280 	.globl _dynamic_keymap_macro_set_buffer_PARM_2
                                    281 	.globl _dynamic_keymap_macro_get_buffer_PARM_3
                                    282 	.globl _dynamic_keymap_macro_get_buffer_PARM_2
                                    283 	.globl _keycode_at_encodermap_location_PARM_3
                                    284 	.globl _keycode_at_encodermap_location_PARM_2
                                    285 	.globl _keycode_at_keymap_location_PARM_3
                                    286 	.globl _keycode_at_keymap_location_PARM_2
                                    287 	.globl _dynamic_keymap_set_buffer_PARM_3
                                    288 	.globl _dynamic_keymap_set_buffer_PARM_2
                                    289 	.globl _dynamic_keymap_get_buffer_PARM_3
                                    290 	.globl _dynamic_keymap_get_buffer_PARM_2
                                    291 	.globl _dynamic_keymap_set_combo_PARM_2
                                    292 	.globl _dynamic_keymap_get_combo_PARM_2
                                    293 	.globl _dynamic_keymap_set_encoder_PARM_4
                                    294 	.globl _dynamic_keymap_set_encoder_PARM_3
                                    295 	.globl _dynamic_keymap_set_encoder_PARM_2
                                    296 	.globl _dynamic_keymap_get_encoder_PARM_3
                                    297 	.globl _dynamic_keymap_get_encoder_PARM_2
                                    298 	.globl _dynamic_keymap_encoder_to_eeprom_address_PARM_2
                                    299 	.globl _dynamic_keymap_set_keycode_PARM_4
                                    300 	.globl _dynamic_keymap_set_keycode_PARM_3
                                    301 	.globl _dynamic_keymap_set_keycode_PARM_2
                                    302 	.globl _dynamic_keymap_get_keycode_PARM_3
                                    303 	.globl _dynamic_keymap_get_keycode_PARM_2
                                    304 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_3
                                    305 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_2
                                    306 	.globl _dynamic_keymap_get_layer_count
                                    307 	.globl _dynamic_keymap_key_to_eeprom_address
                                    308 	.globl _dynamic_keymap_get_keycode
                                    309 	.globl _dynamic_keymap_set_keycode
                                    310 	.globl _dynamic_keymap_get_encoder
                                    311 	.globl _dynamic_keymap_set_encoder
                                    312 	.globl _dynamic_keymap_get_combo
                                    313 	.globl _dynamic_keymap_set_combo
                                    314 	.globl _dynamic_keymap_reset
                                    315 	.globl _dynamic_keymap_get_buffer
                                    316 	.globl _dynamic_keymap_set_buffer
                                    317 	.globl _keycode_at_keymap_location
                                    318 	.globl _keycode_at_encodermap_location
                                    319 	.globl _dynamic_keymap_macro_get_count
                                    320 	.globl _dynamic_keymap_macro_get_buffer_size
                                    321 	.globl _dynamic_keymap_macro_get_buffer
                                    322 	.globl _dynamic_keymap_macro_set_buffer
                                    323 	.globl _dynamic_keymap_macro_reset
                                    324 	.globl _dynamic_keymap_macro_send
                                    325 ;--------------------------------------------------------
                                    326 ; special function registers
                                    327 ;--------------------------------------------------------
                                    328 	.area RSEG    (ABS,DATA)
      000000                        329 	.org 0x0000
                           0000D0   330 _PSW	=	0x00d0
                           0000E0   331 _ACC	=	0x00e0
                           0000F0   332 _B	=	0x00f0
                           0000FD   333 _A_INV	=	0x00fd
                           000081   334 _SP	=	0x0081
                           000082   335 _DPL	=	0x0082
                           000083   336 _DPH	=	0x0083
                           0000A1   337 _SAFE_MOD	=	0x00a1
                           0000B1   338 _GLOBAL_CFG	=	0x00b1
                           000087   339 _PCON	=	0x0087
                           0000BA   340 _POWER_CFG	=	0x00ba
                           0000B9   341 _CLOCK_CFG	=	0x00b9
                           0000A9   342 _WAKE_CTRL	=	0x00a9
                           0000FE   343 _RESET_KEEP	=	0x00fe
                           0000FF   344 _WDOG_COUNT	=	0x00ff
                           0000A8   345 _IE	=	0x00a8
                           0000B8   346 _IP	=	0x00b8
                           0000E8   347 _IE_EX	=	0x00e8
                           0000E9   348 _IP_EX	=	0x00e9
                           0000B2   349 _GPIO_IE	=	0x00b2
                           008584   350 _ROM_ADDR	=	0x8584
                           000084   351 _ROM_ADDR_L	=	0x0084
                           000085   352 _ROM_ADDR_H	=	0x0085
                           008F8E   353 _ROM_DATA_HI	=	0x8f8e
                           00008E   354 _ROM_DATA_HL	=	0x008e
                           00008F   355 _ROM_DATA_HH	=	0x008f
                           000086   356 _ROM_CTRL	=	0x0086
                           000080   357 _P0	=	0x0080
                           0000C4   358 _P0_MOD_OC	=	0x00c4
                           0000C5   359 _P0_DIR_PU	=	0x00c5
                           000090   360 _P1	=	0x0090
                           000092   361 _P1_MOD_OC	=	0x0092
                           000093   362 _P1_DIR_PU	=	0x0093
                           0000A0   363 _P2	=	0x00a0
                           000094   364 _P2_MOD_OC	=	0x0094
                           000095   365 _P2_DIR_PU	=	0x0095
                           0000B0   366 _P3	=	0x00b0
                           000096   367 _P3_MOD_OC	=	0x0096
                           000097   368 _P3_DIR_PU	=	0x0097
                           0000C0   369 _P4	=	0x00c0
                           0000C2   370 _P4_MOD_OC	=	0x00c2
                           0000C3   371 _P4_DIR_PU	=	0x00c3
                           0000C1   372 _P4_LED_KEY	=	0x00c1
                           0000AA   373 _P5_IN	=	0x00aa
                           0000AB   374 _P5_OUT_PU	=	0x00ab
                           0000AC   375 _P5_DIR	=	0x00ac
                           0000AD   376 _P6_IN	=	0x00ad
                           0000AE   377 _P6_OUT_PU	=	0x00ae
                           0000AF   378 _P6_DIR	=	0x00af
                           0000F1   379 _P7	=	0x00f1
                           0000A2   380 _XBUS_AUX	=	0x00a2
                           000088   381 _TCON	=	0x0088
                           000089   382 _TMOD	=	0x0089
                           00008A   383 _TL0	=	0x008a
                           00008B   384 _TL1	=	0x008b
                           00008C   385 _TH0	=	0x008c
                           00008D   386 _TH1	=	0x008d
                           000098   387 _SCON	=	0x0098
                           000099   388 _SBUF	=	0x0099
                           0000C8   389 _T2CON	=	0x00c8
                           0000C9   390 _T2MOD	=	0x00c9
                           00CBCA   391 _RCAP2	=	0xcbca
                           0000CA   392 _RCAP2L	=	0x00ca
                           0000CB   393 _RCAP2H	=	0x00cb
                           00CDCC   394 _T2COUNT	=	0xcdcc
                           0000CC   395 _TL2	=	0x00cc
                           0000CD   396 _TH2	=	0x00cd
                           00CFCE   397 _T2CAP1	=	0xcfce
                           0000CE   398 _T2CAP1L	=	0x00ce
                           0000CF   399 _T2CAP1H	=	0x00cf
                           0000F8   400 _SPI0_STAT	=	0x00f8
                           0000F9   401 _SPI0_DATA	=	0x00f9
                           0000FA   402 _SPI0_CTRL	=	0x00fa
                           0000FB   403 _SPI0_CK_SE	=	0x00fb
                           0000FC   404 _SPI0_SETUP	=	0x00fc
                           0000BC   405 _SCON1	=	0x00bc
                           0000BD   406 _SBUF1	=	0x00bd
                           0000BE   407 _SBAUD1	=	0x00be
                           0000BF   408 _SIF1	=	0x00bf
                           0000B4   409 _SPI1_STAT	=	0x00b4
                           0000B5   410 _SPI1_DATA	=	0x00b5
                           0000B6   411 _SPI1_CTRL	=	0x00b6
                           0000B7   412 _SPI1_CK_SE	=	0x00b7
                           0000F3   413 _ADC_CTRL	=	0x00f3
                           00F5F4   414 _ADC_DAT	=	0xf5f4
                           0000F4   415 _ADC_DAT_L	=	0x00f4
                           0000F5   416 _ADC_DAT_H	=	0x00f5
                           0000F6   417 _ADC_CHAN	=	0x00f6
                           0000A6   418 _LED_COMMON	=	0x00a6
                           0000A7   419 _LED_PWM_OE	=	0x00a7
                           00C7C6   420 _LED_DMA	=	0xc7c6
                           0000C6   421 _LED_DMA_L	=	0x00c6
                           0000C7   422 _LED_DMA_H	=	0x00c7
                           0000F7   423 _LED_STATUS	=	0x00f7
                           0000B3   424 _I2CX_INT	=	0x00b3
                           0000BB   425 _I2CS_INT_ST	=	0x00bb
                                    426 ;--------------------------------------------------------
                                    427 ; special function bits
                                    428 ;--------------------------------------------------------
                                    429 	.area RSEG    (ABS,DATA)
      000000                        430 	.org 0x0000
                           0000D7   431 _CY	=	0x00d7
                           0000D6   432 _AC	=	0x00d6
                           0000D5   433 _F0	=	0x00d5
                           0000D4   434 _RS1	=	0x00d4
                           0000D3   435 _RS0	=	0x00d3
                           0000D2   436 _OV	=	0x00d2
                           0000D1   437 _F1	=	0x00d1
                           0000D0   438 _P	=	0x00d0
                           0000AF   439 _EA	=	0x00af
                           0000AE   440 _E_DIS	=	0x00ae
                           0000AD   441 _ET2	=	0x00ad
                           0000AC   442 _ES	=	0x00ac
                           0000AB   443 _ET1	=	0x00ab
                           0000AA   444 _EX1	=	0x00aa
                           0000A9   445 _ET0	=	0x00a9
                           0000A8   446 _EX0	=	0x00a8
                           0000BF   447 _PH_FLAG	=	0x00bf
                           0000BE   448 _PL_FLAG	=	0x00be
                           0000BD   449 _PT2	=	0x00bd
                           0000BC   450 _PS	=	0x00bc
                           0000BB   451 _PT1	=	0x00bb
                           0000BA   452 _PX1	=	0x00ba
                           0000B9   453 _PT0	=	0x00b9
                           0000B8   454 _PX0	=	0x00b8
                           0000EF   455 _IE_WDOG	=	0x00ef
                           0000EE   456 _IE_GPIO	=	0x00ee
                           0000ED   457 _IE_PWM_I2C	=	0x00ed
                           0000EC   458 _IE_UART1	=	0x00ec
                           0000EB   459 _IE_ADC	=	0x00eb
                           0000E9   460 _IE_USB	=	0x00e9
                           0000E8   461 _IE_SPI0	=	0x00e8
                           000087   462 _P0_7	=	0x0087
                           000086   463 _P0_6	=	0x0086
                           000085   464 _P0_5	=	0x0085
                           000084   465 _P0_4	=	0x0084
                           000083   466 _P0_3	=	0x0083
                           000082   467 _P0_2	=	0x0082
                           000081   468 _P0_1	=	0x0081
                           000080   469 _P0_0	=	0x0080
                           000081   470 _SDA0	=	0x0081
                           000080   471 _SCL0	=	0x0080
                           000083   472 _TXD_	=	0x0083
                           000082   473 _RXD_	=	0x0082
                           000085   474 _AIN13	=	0x0085
                           000084   475 _AIN12	=	0x0084
                           000083   476 _AIN11	=	0x0083
                           000082   477 _AIN10	=	0x0082
                           000081   478 _AIN9	=	0x0081
                           000080   479 _AIN8	=	0x0080
                           000097   480 _P1_7	=	0x0097
                           000096   481 _P1_6	=	0x0096
                           000095   482 _P1_5	=	0x0095
                           000094   483 _P1_4	=	0x0094
                           000093   484 _P1_3	=	0x0093
                           000092   485 _P1_2	=	0x0092
                           000091   486 _P1_1	=	0x0091
                           000090   487 _P1_0	=	0x0090
                           000097   488 _TXD1_	=	0x0097
                           000096   489 _RXD1_	=	0x0096
                           000097   490 _SCK	=	0x0097
                           000096   491 _MISO	=	0x0096
                           000095   492 _MOSI	=	0x0095
                           000094   493 _SCS	=	0x0094
                           000092   494 _INT0_	=	0x0092
                           000091   495 _T2EX	=	0x0091
                           000091   496 _CAP2	=	0x0091
                           000090   497 _T2	=	0x0090
                           000090   498 _CAP1	=	0x0090
                           000097   499 _AIN7	=	0x0097
                           000096   500 _AIN6	=	0x0096
                           000095   501 _AIN5	=	0x0095
                           000094   502 _AIN4	=	0x0094
                           000093   503 _AIN3	=	0x0093
                           000092   504 _AIN2	=	0x0092
                           000091   505 _AIN1	=	0x0091
                           000090   506 _AIN0	=	0x0090
                           0000A7   507 _P2_7	=	0x00a7
                           0000A6   508 _P2_6	=	0x00a6
                           0000A5   509 _P2_5	=	0x00a5
                           0000A4   510 _P2_4	=	0x00a4
                           0000A3   511 _P2_3	=	0x00a3
                           0000A2   512 _P2_2	=	0x00a2
                           0000A1   513 _P2_1	=	0x00a1
                           0000A0   514 _P2_0	=	0x00a0
                           0000A7   515 _TXD1	=	0x00a7
                           0000A6   516 _RXD1	=	0x00a6
                           0000A5   517 _T2EX_	=	0x00a5
                           0000A5   518 _CAP2_	=	0x00a5
                           0000A4   519 _T2_	=	0x00a4
                           0000A4   520 _CAP1_	=	0x00a4
                           0000B7   521 _P3_7	=	0x00b7
                           0000B6   522 _P3_6	=	0x00b6
                           0000B5   523 _P3_5	=	0x00b5
                           0000B4   524 _P3_4	=	0x00b4
                           0000B3   525 _P3_3	=	0x00b3
                           0000B2   526 _P3_2	=	0x00b2
                           0000B1   527 _P3_1	=	0x00b1
                           0000B0   528 _P3_0	=	0x00b0
                           0000B7   529 _SCK1	=	0x00b7
                           0000B6   530 _MISO1	=	0x00b6
                           0000B5   531 _MOSI1	=	0x00b5
                           0000B5   532 _T1	=	0x00b5
                           0000B4   533 _T0	=	0x00b4
                           0000B3   534 _INT1	=	0x00b3
                           0000B2   535 _INT0	=	0x00b2
                           0000B1   536 _TXD	=	0x00b1
                           0000B0   537 _RXD	=	0x00b0
                           0000C6   538 _P4_6	=	0x00c6
                           0000C5   539 _P4_5	=	0x00c5
                           0000C4   540 _P4_4	=	0x00c4
                           0000C3   541 _P4_3	=	0x00c3
                           0000C2   542 _P4_2	=	0x00c2
                           0000C1   543 _P4_1	=	0x00c1
                           0000C0   544 _P4_0	=	0x00c0
                           00008F   545 _TF1	=	0x008f
                           00008E   546 _TR1	=	0x008e
                           00008D   547 _TF0	=	0x008d
                           00008C   548 _TR0	=	0x008c
                           00008B   549 _IE1	=	0x008b
                           00008A   550 _IT1	=	0x008a
                           000089   551 _IE0	=	0x0089
                           000088   552 _IT0	=	0x0088
                           00009F   553 _SM0	=	0x009f
                           00009E   554 _SM1	=	0x009e
                           00009D   555 _SM2	=	0x009d
                           00009C   556 _REN	=	0x009c
                           00009B   557 _TB8	=	0x009b
                           00009A   558 _RB8	=	0x009a
                           000099   559 _TI	=	0x0099
                           000098   560 _RI	=	0x0098
                           0000CF   561 _TF2	=	0x00cf
                           0000CF   562 _CAP1F	=	0x00cf
                           0000CE   563 _EXF2	=	0x00ce
                           0000CD   564 _RCLK	=	0x00cd
                           0000CC   565 _TCLK	=	0x00cc
                           0000CB   566 _EXEN2	=	0x00cb
                           0000CA   567 _TR2	=	0x00ca
                           0000C9   568 _C_T2	=	0x00c9
                           0000C8   569 _CP_RL2	=	0x00c8
                           0000FF   570 _S0_FST_ACT	=	0x00ff
                           0000FE   571 _S0_IF_OV	=	0x00fe
                           0000FD   572 _S0_IF_FIRST	=	0x00fd
                           0000FC   573 _S0_IF_BYTE	=	0x00fc
                           0000FB   574 _S0_FREE	=	0x00fb
                           0000FA   575 _S0_T_FIFO	=	0x00fa
                           0000F8   576 _S0_R_FIFO	=	0x00f8
                           0000F7   577 _ADC_START	=	0x00f7
                                    578 ;--------------------------------------------------------
                                    579 ; overlayable register banks
                                    580 ;--------------------------------------------------------
                                    581 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        582 	.ds 8
                                    583 ;--------------------------------------------------------
                                    584 ; internal ram data
                                    585 ;--------------------------------------------------------
                                    586 	.area DSEG    (DATA)
      000029                        587 _dynamic_keymap_set_encoder_sloc0_1_0:
      000029                        588 	.ds 2
      00002B                        589 _dynamic_keymap_get_combo_sloc0_1_0:
      00002B                        590 	.ds 1
      00002C                        591 _ak820_dynamic_read_buffer_sloc0_1_0:
      00002C                        592 	.ds 1
      00002D                        593 _dynamic_keymap_set_buffer_sloc0_1_0:
      00002D                        594 	.ds 2
      00002F                        595 _dynamic_keymap_set_buffer_sloc1_1_0:
      00002F                        596 	.ds 2
      000031                        597 _dynamic_keymap_set_buffer_sloc2_1_0:
      000031                        598 	.ds 1
      000032                        599 _dynamic_keymap_macro_get_buffer_sloc0_1_0:
      000032                        600 	.ds 2
                                    601 ;--------------------------------------------------------
                                    602 ; overlayable items in internal ram
                                    603 ;--------------------------------------------------------
                                    604 ;--------------------------------------------------------
                                    605 ; indirectly addressable internal ram data
                                    606 ;--------------------------------------------------------
                                    607 	.area ISEG    (DATA)
                                    608 ;--------------------------------------------------------
                                    609 ; absolute internal ram data
                                    610 ;--------------------------------------------------------
                                    611 	.area IABS    (ABS,DATA)
                                    612 	.area IABS    (ABS,DATA)
                                    613 ;--------------------------------------------------------
                                    614 ; bit data
                                    615 ;--------------------------------------------------------
                                    616 	.area BSEG    (BIT)
      000027                        617 _dynamic_keymap_macro_send_sloc0_1_0:
      000027                        618 	.ds 1
                                    619 ;--------------------------------------------------------
                                    620 ; paged external ram data
                                    621 ;--------------------------------------------------------
                                    622 	.area PSEG    (PAG,XDATA)
                                    623 ;--------------------------------------------------------
                                    624 ; uninitialized external ram data
                                    625 ;--------------------------------------------------------
                                    626 	.area XSEG    (XDATA)
      000ADF                        627 _dynamic_keymap_key_to_eeprom_address_PARM_2:
      000ADF                        628 	.ds 1
      000AE0                        629 _dynamic_keymap_key_to_eeprom_address_PARM_3:
      000AE0                        630 	.ds 1
      000AE1                        631 _dynamic_keymap_key_to_eeprom_address_layer_10000_365:
      000AE1                        632 	.ds 1
      000AE2                        633 _dynamic_keymap_get_keycode_PARM_2:
      000AE2                        634 	.ds 1
      000AE3                        635 _dynamic_keymap_get_keycode_PARM_3:
      000AE3                        636 	.ds 1
      000AE4                        637 _dynamic_keymap_get_keycode_layer_10000_367:
      000AE4                        638 	.ds 1
      000AE5                        639 _dynamic_keymap_set_keycode_PARM_2:
      000AE5                        640 	.ds 1
      000AE6                        641 _dynamic_keymap_set_keycode_PARM_3:
      000AE6                        642 	.ds 1
      000AE7                        643 _dynamic_keymap_set_keycode_PARM_4:
      000AE7                        644 	.ds 2
      000AE9                        645 _dynamic_keymap_set_keycode_layer_10000_371:
      000AE9                        646 	.ds 1
      000AEA                        647 _dynamic_keymap_encoder_to_eeprom_address_PARM_2:
      000AEA                        648 	.ds 1
      000AEB                        649 _dynamic_keymap_encoder_to_eeprom_address_layer_10000_375:
      000AEB                        650 	.ds 1
      000AEC                        651 _dynamic_keymap_get_encoder_PARM_2:
      000AEC                        652 	.ds 1
      000AED                        653 _dynamic_keymap_get_encoder_PARM_3:
      000AED                        654 	.ds 1
      000AEE                        655 _dynamic_keymap_get_encoder_layer_10000_377:
      000AEE                        656 	.ds 1
      000AEF                        657 _dynamic_keymap_set_encoder_PARM_2:
      000AEF                        658 	.ds 1
      000AF0                        659 _dynamic_keymap_set_encoder_PARM_3:
      000AF0                        660 	.ds 1
      000AF1                        661 _dynamic_keymap_set_encoder_PARM_4:
      000AF1                        662 	.ds 2
      000AF3                        663 _dynamic_keymap_set_encoder_layer_10000_381:
      000AF3                        664 	.ds 1
      000AF4                        665 _dynamic_keymap_get_combo_PARM_2:
      000AF4                        666 	.ds 3
      000AF7                        667 _dynamic_keymap_get_combo_index_10000_385:
      000AF7                        668 	.ds 1
      000AF8                        669 _dynamic_keymap_set_combo_PARM_2:
      000AF8                        670 	.ds 3
      000AFB                        671 _dynamic_keymap_set_combo_index_10000_391:
      000AFB                        672 	.ds 1
      000AFC                        673 _dynamic_keymap_set_combo_stored_10002_396:
      000AFC                        674 	.ds 10
      000B06                        675 _dynamic_keymap_reset_vial_unlocked_prev_10000_399:
      000B06                        676 	.ds 1
      000B07                        677 _dynamic_keymap_reset_combo_10001_408:
      000B07                        678 	.ds 10
      000B11                        679 _ak820_dynamic_read_buffer_PARM_2:
      000B11                        680 	.ds 2
      000B13                        681 _ak820_dynamic_read_buffer_PARM_3:
      000B13                        682 	.ds 2
      000B15                        683 _ak820_dynamic_read_buffer_PARM_4:
      000B15                        684 	.ds 2
      000B17                        685 _ak820_dynamic_read_buffer_PARM_5:
      000B17                        686 	.ds 3
      000B1A                        687 _ak820_dynamic_read_buffer_base_10000_410:
      000B1A                        688 	.ds 2
      000B1C                        689 _ak820_dynamic_read_buffer_available_10000_411:
      000B1C                        690 	.ds 1
      000B1D                        691 _dynamic_keymap_get_buffer_PARM_2:
      000B1D                        692 	.ds 2
      000B1F                        693 _dynamic_keymap_get_buffer_PARM_3:
      000B1F                        694 	.ds 3
      000B22                        695 _dynamic_keymap_get_buffer_offset_10000_417:
      000B22                        696 	.ds 2
      000B24                        697 _dynamic_keymap_set_buffer_PARM_2:
      000B24                        698 	.ds 2
      000B26                        699 _dynamic_keymap_set_buffer_PARM_3:
      000B26                        700 	.ds 3
      000B29                        701 _dynamic_keymap_set_buffer_offset_10000_419:
      000B29                        702 	.ds 2
      000B2B                        703 _dynamic_keymap_set_buffer_chk_offset_30001_426:
      000B2B                        704 	.ds 1
      000B2C                        705 _dynamic_keymap_set_buffer_chk_sz_30001_426:
      000B2C                        706 	.ds 1
      000B2D                        707 _dynamic_keymap_set_buffer_i_40001_433:
      000B2D                        708 	.ds 1
      000B2E                        709 _keycode_at_keymap_location_PARM_2:
      000B2E                        710 	.ds 1
      000B2F                        711 _keycode_at_keymap_location_PARM_3:
      000B2F                        712 	.ds 1
      000B30                        713 _keycode_at_keymap_location_layer_num_10000_437:
      000B30                        714 	.ds 1
      000B31                        715 _keycode_at_encodermap_location_PARM_2:
      000B31                        716 	.ds 1
      000B32                        717 _keycode_at_encodermap_location_PARM_3:
      000B32                        718 	.ds 1
      000B33                        719 _keycode_at_encodermap_location_layer_num_10000_441:
      000B33                        720 	.ds 1
      000B34                        721 _dynamic_keymap_macro_get_buffer_PARM_2:
      000B34                        722 	.ds 2
      000B36                        723 _dynamic_keymap_macro_get_buffer_PARM_3:
      000B36                        724 	.ds 3
      000B39                        725 _dynamic_keymap_macro_get_buffer_offset_10000_449:
      000B39                        726 	.ds 2
      000B3B                        727 _dynamic_keymap_macro_set_buffer_PARM_2:
      000B3B                        728 	.ds 2
      000B3D                        729 _dynamic_keymap_macro_set_buffer_PARM_3:
      000B3D                        730 	.ds 3
      000B40                        731 _dynamic_keymap_macro_set_buffer_offset_10000_451:
      000B40                        732 	.ds 2
      000B42                        733 _decode_keycode_kc_10000_455:
      000B42                        734 	.ds 2
      000B44                        735 _dynamic_keymap_macro_send_id_10000_458:
      000B44                        736 	.ds 1
      000B45                        737 _dynamic_keymap_macro_send_sending_10000_459:
      000B45                        738 	.ds 1
      000B46                        739 _dynamic_keymap_macro_send_p_10001_464:
      000B46                        740 	.ds 2
      000B48                        741 _dynamic_keymap_macro_send_data_10003_471:
      000B48                        742 	.ds 4
                                    743 ;--------------------------------------------------------
                                    744 ; absolute external ram data
                                    745 ;--------------------------------------------------------
                                    746 	.area XABS    (ABS,XDATA)
                                    747 ;--------------------------------------------------------
                                    748 ; initialized external ram data
                                    749 ;--------------------------------------------------------
                                    750 	.area XISEG   (XDATA)
                                    751 	.area HOME    (CODE)
                                    752 	.area GSINIT0 (CODE)
                                    753 	.area GSINIT1 (CODE)
                                    754 	.area GSINIT2 (CODE)
                                    755 	.area GSINIT3 (CODE)
                                    756 	.area GSINIT4 (CODE)
                                    757 	.area GSINIT5 (CODE)
                                    758 	.area GSINIT  (CODE)
                                    759 	.area GSFINAL (CODE)
                                    760 	.area CSEG    (CODE)
                                    761 ;--------------------------------------------------------
                                    762 ; global & static initialisations
                                    763 ;--------------------------------------------------------
                                    764 	.area HOME    (CODE)
                                    765 	.area GSINIT  (CODE)
                                    766 	.area GSFINAL (CODE)
                                    767 	.area GSINIT  (CODE)
                                    768 ;--------------------------------------------------------
                                    769 ; Home
                                    770 ;--------------------------------------------------------
                                    771 	.area HOME    (CODE)
                                    772 	.area HOME    (CODE)
                                    773 ;--------------------------------------------------------
                                    774 ; code
                                    775 ;--------------------------------------------------------
                                    776 	.area CSEG    (CODE)
                                    777 ;------------------------------------------------------------
                                    778 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    779 ;------------------------------------------------------------
                                    780 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_230'
                                    781 ;------------------------------------------------------------
                                    782 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    783 ;	-----------------------------------------
                           000007   784 	ar7 = 0x07
                           000006   785 	ar6 = 0x06
                           000005   786 	ar5 = 0x05
                           000004   787 	ar4 = 0x04
                           000003   788 	ar3 = 0x03
                           000002   789 	ar2 = 0x02
                           000001   790 	ar1 = 0x01
                           000000   791 	ar0 = 0x00
                                    792 ;	 function dynamic_keymap_get_layer_count
                                    793 ;	-----------------------------------------
      008474                        794 _dynamic_keymap_get_layer_count:
                                    795 ;	quantum/dynamic_keymap.c:178: return DYNAMIC_KEYMAP_LAYER_COUNT;
      008474 75 82 06         [24]  796 	mov	dpl, #0x06
                                    797 ;	quantum/dynamic_keymap.c:179: }
      008477 22               [24]  798 	ret
                                    799 ;------------------------------------------------------------
                                    800 ;Allocation info for local variables in function 'dynamic_keymap_key_to_eeprom_address'
                                    801 ;------------------------------------------------------------
                                    802 ;row           Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_2'
                                    803 ;column        Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_3'
                                    804 ;layer         Allocated with name '_dynamic_keymap_key_to_eeprom_address_layer_10000_365'
                                    805 ;------------------------------------------------------------
                                    806 ;	quantum/dynamic_keymap.c:181: void *dynamic_keymap_key_to_eeprom_address(uint8_t layer, uint8_t row, uint8_t column) {
                                    807 ;	-----------------------------------------
                                    808 ;	 function dynamic_keymap_key_to_eeprom_address
                                    809 ;	-----------------------------------------
      008478                        810 _dynamic_keymap_key_to_eeprom_address:
      008478 E5 82            [12]  811 	mov	a,dpl
      00847A 90 0A E1         [24]  812 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_layer_10000_365
      00847D F0               [24]  813 	movx	@dptr,a
                                    814 ;	quantum/dynamic_keymap.c:183: return ((uint8_t *)DYNAMIC_KEYMAP_EEPROM_ADDR) + (layer * MATRIX_ROWS * MATRIX_COLS * 2) + (row * MATRIX_COLS * 2) + (column * 2);
      00847E E0               [24]  815 	movx	a,@dptr
      00847F FF               [12]  816 	mov	r7,a
      008480 7E 00            [12]  817 	mov	r6,#0x00
      008482 74 40            [12]  818 	mov	a,#0x40
      008484 12 43 5C         [24]  819 	lcall	_ak820_outline_0139
      008487 7D 00            [12]  820 	mov	r5,#0x00
      008489 90 0A DF         [24]  821 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      00848C E0               [24]  822 	movx	a,@dptr
      00848D 75 F0 10         [24]  823 	mov	b,#0x10
      008490 A4               [48]  824 	mul	ab
      008491 2E               [12]  825 	add	a, r6
      008492 FE               [12]  826 	mov	r6,a
      008493 EF               [12]  827 	mov	a,r7
      008494 35 F0            [12]  828 	addc	a, b
      008496 FF               [12]  829 	mov	r7,a
      008497 90 0A E0         [24]  830 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      00849A E0               [24]  831 	movx	a,@dptr
      00849B 7C 00            [12]  832 	mov	r4,#0x00
      00849D 25 E0            [12]  833 	add	a,acc
      00849F FB               [12]  834 	mov	r3,a
      0084A0 EC               [12]  835 	mov	a,r4
      0084A1 33               [12]  836 	rlc	a
      0084A2 FC               [12]  837 	mov	r4,a
      0084A3 EB               [12]  838 	mov	a,r3
      0084A4 2E               [12]  839 	add	a, r6
      0084A5 FE               [12]  840 	mov	r6,a
      0084A6 EC               [12]  841 	mov	a,r4
      0084A7 3F               [12]  842 	addc	a, r7
      0084A8 FF               [12]  843 	mov	r7,a
      0084A9 12 6F B4         [24]  844 	lcall	_ak820_outline_0050
                                    845 ;	quantum/dynamic_keymap.c:184: }
      0084AC 22               [24]  846 	ret
                                    847 ;------------------------------------------------------------
                                    848 ;Allocation info for local variables in function 'dynamic_keymap_get_keycode'
                                    849 ;------------------------------------------------------------
                                    850 ;row           Allocated with name '_dynamic_keymap_get_keycode_PARM_2'
                                    851 ;column        Allocated with name '_dynamic_keymap_get_keycode_PARM_3'
                                    852 ;layer         Allocated with name '_dynamic_keymap_get_keycode_layer_10000_367'
                                    853 ;address       Allocated with name '_dynamic_keymap_get_keycode_address_10001_370'
                                    854 ;keycode       Allocated with name '_dynamic_keymap_get_keycode_keycode_10001_370'
                                    855 ;------------------------------------------------------------
                                    856 ;	quantum/dynamic_keymap.c:186: uint16_t dynamic_keymap_get_keycode(uint8_t layer, uint8_t row, uint8_t column) {
                                    857 ;	-----------------------------------------
                                    858 ;	 function dynamic_keymap_get_keycode
                                    859 ;	-----------------------------------------
      0084AD                        860 _dynamic_keymap_get_keycode:
      0084AD E5 82            [12]  861 	mov	a,dpl
      0084AF 90 0A E4         [24]  862 	mov	dptr,#_dynamic_keymap_get_keycode_layer_10000_367
      0084B2 F0               [24]  863 	movx	@dptr,a
                                    864 ;	quantum/dynamic_keymap.c:187: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return KC_NO;
      0084B3 E0               [24]  865 	movx	a,@dptr
      0084B4 FF               [12]  866 	mov	r7,a
      0084B5 BF 06 00         [24]  867 	cjne	r7,#0x06,00121$
      0084B8                        868 00121$:
      0084B8 50 14            [24]  869 	jnc	00101$
      0084BA 90 0A E2         [24]  870 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      0084BD E0               [24]  871 	movx	a,@dptr
      0084BE FE               [12]  872 	mov	r6,a
      0084BF BE 10 00         [24]  873 	cjne	r6,#0x10,00123$
      0084C2                        874 00123$:
      0084C2 50 0A            [24]  875 	jnc	00101$
      0084C4 90 0A E3         [24]  876 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      0084C7 E0               [24]  877 	movx	a,@dptr
      0084C8 FD               [12]  878 	mov	r5,a
      0084C9 BD 08 00         [24]  879 	cjne	r5,#0x08,00125$
      0084CC                        880 00125$:
      0084CC 40 04            [24]  881 	jc	00102$
      0084CE                        882 00101$:
      0084CE 90 00 00         [24]  883 	mov	dptr,#0x0000
      0084D1 22               [24]  884 	ret
      0084D2                        885 00102$:
                                    886 ;	quantum/dynamic_keymap.c:188: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      0084D2 12 8F 07         [24]  887 	lcall	_ak820_outline_0100
      0084D5 12 84 78         [24]  888 	lcall	_dynamic_keymap_key_to_eeprom_address
                                    889 ;	quantum/dynamic_keymap.c:190: uint16_t keycode = eeprom_read_byte(address) << 8;
      0084D8 12 8F 1B         [24]  890 	lcall	_ak820_outline_0119
      0084DB 12 40 76         [24]  891 	lcall	_eeprom_read_byte
      0084DE AB 82            [24]  892 	mov	r3,dpl
      0084E0 7C 00            [12]  893 	mov	r4,#0x00
                                    894 ;	quantum/dynamic_keymap.c:191: keycode |= eeprom_read_byte(address + 1);
      0084E2 0D               [12]  895 	inc	r5
      0084E3 BD 00 01         [24]  896 	cjne	r5,#0x00,00127$
      0084E6 0E               [12]  897 	inc	r6
      0084E7                        898 00127$:
      0084E7 12 6D 8E         [24]  899 	lcall	_ak820_outline_0059
      0084EA 12 40 76         [24]  900 	lcall	_eeprom_read_byte
      0084ED AF 82            [24]  901 	mov	r7, dpl
      0084EF 7E 00            [12]  902 	mov	r6,#0x00
      0084F1 EF               [12]  903 	mov	a,r7
      0084F2 42 04            [12]  904 	orl	ar4,a
      0084F4 EE               [12]  905 	mov	a,r6
      0084F5 42 03            [12]  906 	orl	ar3,a
                                    907 ;	quantum/dynamic_keymap.c:192: return keycode;
      0084F7 12 43 83         [24]  908 	lcall	_ak820_outline_0187
                                    909 ;	quantum/dynamic_keymap.c:193: }
      0084FA 22               [24]  910 	ret
                                    911 ;------------------------------------------------------------
                                    912 ;Allocation info for local variables in function 'dynamic_keymap_set_keycode'
                                    913 ;------------------------------------------------------------
                                    914 ;row           Allocated with name '_dynamic_keymap_set_keycode_PARM_2'
                                    915 ;column        Allocated with name '_dynamic_keymap_set_keycode_PARM_3'
                                    916 ;keycode       Allocated with name '_dynamic_keymap_set_keycode_PARM_4'
                                    917 ;layer         Allocated with name '_dynamic_keymap_set_keycode_layer_10000_371'
                                    918 ;address       Allocated with name '_dynamic_keymap_set_keycode_address_10001_374'
                                    919 ;------------------------------------------------------------
                                    920 ;	quantum/dynamic_keymap.c:195: void dynamic_keymap_set_keycode(uint8_t layer, uint8_t row, uint8_t column, uint16_t keycode) {
                                    921 ;	-----------------------------------------
                                    922 ;	 function dynamic_keymap_set_keycode
                                    923 ;	-----------------------------------------
      0084FB                        924 _dynamic_keymap_set_keycode:
      0084FB E5 82            [12]  925 	mov	a,dpl
      0084FD 90 0A E9         [24]  926 	mov	dptr,#_dynamic_keymap_set_keycode_layer_10000_371
      008500 F0               [24]  927 	movx	@dptr,a
                                    928 ;	quantum/dynamic_keymap.c:196: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return;
      008501 E0               [24]  929 	movx	a,@dptr
      008502 FF               [12]  930 	mov	r7,a
      008503 BF 06 00         [24]  931 	cjne	r7,#0x06,00121$
      008506                        932 00121$:
      008506 50 14            [24]  933 	jnc	00101$
      008508 90 0A E5         [24]  934 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      00850B E0               [24]  935 	movx	a,@dptr
      00850C FE               [12]  936 	mov	r6,a
      00850D BE 10 00         [24]  937 	cjne	r6,#0x10,00123$
      008510                        938 00123$:
      008510 50 0A            [24]  939 	jnc	00101$
      008512 90 0A E6         [24]  940 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      008515 E0               [24]  941 	movx	a,@dptr
      008516 FD               [12]  942 	mov	r5,a
      008517 BD 08 00         [24]  943 	cjne	r5,#0x08,00125$
      00851A                        944 00125$:
      00851A 40 01            [24]  945 	jc	00102$
      00851C                        946 00101$:
      00851C 22               [24]  947 	ret
      00851D                        948 00102$:
                                    949 ;	quantum/dynamic_keymap.c:197: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      00851D 12 8F 07         [24]  950 	lcall	_ak820_outline_0100
      008520 12 84 78         [24]  951 	lcall	_dynamic_keymap_key_to_eeprom_address
      008523 12 8F 1B         [24]  952 	lcall	_ak820_outline_0119
                                    953 ;	quantum/dynamic_keymap.c:199: eeprom_update_byte(address, (uint8_t)(keycode >> 8));
      008526 90 0A E7         [24]  954 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      008529 E0               [24]  955 	movx	a,@dptr
      00852A FB               [12]  956 	mov	r3,a
      00852B A3               [24]  957 	inc	dptr
      00852C E0               [24]  958 	movx	a,@dptr
      00852D 90 06 9B         [24]  959 	mov	dptr,#_eeprom_update_byte_PARM_2
      008530 12 4F 27         [24]  960 	lcall	_ak820_outline_0034
      008533 12 4E 12         [24]  961 	lcall	_eeprom_update_byte
                                    962 ;	quantum/dynamic_keymap.c:200: eeprom_update_byte(address + 1, (uint8_t)(keycode & 0xFF));
      008536 0D               [12]  963 	inc	r5
      008537 BD 00 01         [24]  964 	cjne	r5,#0x00,00127$
      00853A 0E               [12]  965 	inc	r6
      00853B                        966 00127$:
      00853B 90 06 9B         [24]  967 	mov	dptr,#_eeprom_update_byte_PARM_2
      00853E EB               [12]  968 	mov	a,r3
      00853F 12 4F 27         [24]  969 	lcall	_ak820_outline_0034
                                    970 ;	quantum/dynamic_keymap.c:201: }
      008542 02 4E 12         [24]  971 	ljmp	_eeprom_update_byte
                                    972 ;------------------------------------------------------------
                                    973 ;Allocation info for local variables in function 'dynamic_keymap_encoder_to_eeprom_address'
                                    974 ;------------------------------------------------------------
                                    975 ;encoder_id    Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_PARM_2'
                                    976 ;layer         Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_layer_10000_375'
                                    977 ;------------------------------------------------------------
                                    978 ;	quantum/dynamic_keymap.c:204: void *dynamic_keymap_encoder_to_eeprom_address(uint8_t layer, uint8_t encoder_id) {
                                    979 ;	-----------------------------------------
                                    980 ;	 function dynamic_keymap_encoder_to_eeprom_address
                                    981 ;	-----------------------------------------
      008545                        982 _dynamic_keymap_encoder_to_eeprom_address:
      008545 E5 82            [12]  983 	mov	a,dpl
      008547 90 0A EB         [24]  984 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_layer_10000_375
      00854A F0               [24]  985 	movx	@dptr,a
                                    986 ;	quantum/dynamic_keymap.c:205: return ((uint8_t *)DYNAMIC_KEYMAP_ENCODER_EEPROM_ADDR) + (layer * NUM_ENCODERS * 2 * 2) + (encoder_id * 2 * 2);
      00854B E0               [24]  987 	movx	a,@dptr
      00854C 75 F0 04         [24]  988 	mov	b,#0x04
      00854F A4               [48]  989 	mul	ab
      008550 24 40            [12]  990 	add	a, #0x40
      008552 FD               [12]  991 	mov	r5,a
      008553 74 06            [12]  992 	mov	a,#0x06
      008555 35 F0            [12]  993 	addc	a, b
      008557 FE               [12]  994 	mov	r6,a
      008558 7F 00            [12]  995 	mov	r7,#0x00
      00855A 90 0A EA         [24]  996 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      00855D E0               [24]  997 	movx	a,@dptr
      00855E 75 F0 04         [24]  998 	mov	b,#0x04
      008561 A4               [48]  999 	mul	ab
      008562 2D               [12] 1000 	add	a, r5
      008563 FD               [12] 1001 	mov	r5,a
      008564 EE               [12] 1002 	mov	a,r6
      008565 35 F0            [12] 1003 	addc	a, b
      008567 FE               [12] 1004 	mov	r6,a
      008568 12 6D 8E         [24] 1005 	lcall	_ak820_outline_0059
                                   1006 ;	quantum/dynamic_keymap.c:206: }
      00856B 22               [24] 1007 	ret
                                   1008 ;------------------------------------------------------------
                                   1009 ;Allocation info for local variables in function 'dynamic_keymap_get_encoder'
                                   1010 ;------------------------------------------------------------
                                   1011 ;encoder_id    Allocated with name '_dynamic_keymap_get_encoder_PARM_2'
                                   1012 ;clockwise     Allocated with name '_dynamic_keymap_get_encoder_PARM_3'
                                   1013 ;layer         Allocated with name '_dynamic_keymap_get_encoder_layer_10000_377'
                                   1014 ;address       Allocated with name '_dynamic_keymap_get_encoder_address_10001_380'
                                   1015 ;keycode       Allocated with name '_dynamic_keymap_get_encoder_keycode_10001_380'
                                   1016 ;------------------------------------------------------------
                                   1017 ;	quantum/dynamic_keymap.c:208: uint16_t dynamic_keymap_get_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise) {
                                   1018 ;	-----------------------------------------
                                   1019 ;	 function dynamic_keymap_get_encoder
                                   1020 ;	-----------------------------------------
      00856C                       1021 _dynamic_keymap_get_encoder:
      00856C E5 82            [12] 1022 	mov	a,dpl
      00856E 90 0A EE         [24] 1023 	mov	dptr,#_dynamic_keymap_get_encoder_layer_10000_377
      008571 F0               [24] 1024 	movx	@dptr,a
                                   1025 ;	quantum/dynamic_keymap.c:209: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return KC_NO;
      008572 E0               [24] 1026 	movx	a,@dptr
      008573 FF               [12] 1027 	mov	r7,a
      008574 BF 06 00         [24] 1028 	cjne	r7,#0x06,00131$
      008577                       1029 00131$:
      008577 50 0A            [24] 1030 	jnc	00101$
      008579 90 0A EC         [24] 1031 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      00857C E0               [24] 1032 	movx	a,@dptr
      00857D FE               [12] 1033 	mov	r6,a
      00857E BE 01 00         [24] 1034 	cjne	r6,#0x01,00133$
      008581                       1035 00133$:
      008581 40 04            [24] 1036 	jc	00102$
      008583                       1037 00101$:
      008583 90 00 00         [24] 1038 	mov	dptr,#0x0000
      008586 22               [24] 1039 	ret
      008587                       1040 00102$:
                                   1041 ;	quantum/dynamic_keymap.c:210: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      008587 90 0A EA         [24] 1042 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      00858A E4               [12] 1043 	clr	a
      00858B F0               [24] 1044 	movx	@dptr,a
      00858C 8F 82            [24] 1045 	mov	dpl, r7
      00858E 12 85 45         [24] 1046 	lcall	_dynamic_keymap_encoder_to_eeprom_address
      008591 12 8F 1B         [24] 1047 	lcall	_ak820_outline_0119
                                   1048 ;	quantum/dynamic_keymap.c:212: uint16_t keycode = ((uint16_t)eeprom_read_byte(address + (clockwise ? 0 : 2))) << 8;
      008594 90 0A ED         [24] 1049 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      008597 E0               [24] 1050 	movx	a,@dptr
      008598 FC               [12] 1051 	mov	r4,a
      008599 E0               [24] 1052 	movx	a,@dptr
      00859A 60 04            [24] 1053 	jz	00106$
      00859C 7B 00            [12] 1054 	mov	r3,#0x00
      00859E 80 02            [24] 1055 	sjmp	00107$
      0085A0                       1056 00106$:
      0085A0 7B 02            [12] 1057 	mov	r3,#0x02
      0085A2                       1058 00107$:
      0085A2 EB               [12] 1059 	mov	a,r3
      0085A3 12 76 E4         [24] 1060 	lcall	_ak820_outline_0013
      0085A6 12 40 76         [24] 1061 	lcall	_eeprom_read_byte
      0085A9 AA 82            [24] 1062 	mov	r2,dpl
      0085AB 7B 00            [12] 1063 	mov	r3,#0x00
                                   1064 ;	quantum/dynamic_keymap.c:213: keycode |= eeprom_read_byte(address + (clockwise ? 0 : 2) + 1);
      0085AD EC               [12] 1065 	mov	a,r4
      0085AE 60 04            [24] 1066 	jz	00108$
      0085B0 7C 00            [12] 1067 	mov	r4,#0x00
      0085B2 80 02            [24] 1068 	sjmp	00109$
      0085B4                       1069 00108$:
      0085B4 7C 02            [12] 1070 	mov	r4,#0x02
      0085B6                       1071 00109$:
      0085B6 EC               [12] 1072 	mov	a,r4
      0085B7 12 38 BB         [24] 1073 	lcall	_ak820_outline_0163
      0085BA 0D               [12] 1074 	inc	r5
      0085BB BD 00 01         [24] 1075 	cjne	r5,#0x00,00137$
      0085BE 0E               [12] 1076 	inc	r6
      0085BF                       1077 00137$:
      0085BF 12 6D 8E         [24] 1078 	lcall	_ak820_outline_0059
      0085C2 12 40 76         [24] 1079 	lcall	_eeprom_read_byte
      0085C5 AF 82            [24] 1080 	mov	r7, dpl
      0085C7 7E 00            [12] 1081 	mov	r6,#0x00
      0085C9 EF               [12] 1082 	mov	a,r7
      0085CA 42 03            [12] 1083 	orl	ar3,a
      0085CC EE               [12] 1084 	mov	a,r6
      0085CD 42 02            [12] 1085 	orl	ar2,a
                                   1086 ;	quantum/dynamic_keymap.c:214: return keycode;
      0085CF 8B 82            [24] 1087 	mov	dpl, r3
      0085D1 8A 83            [24] 1088 	mov	dph, r2
                                   1089 ;	quantum/dynamic_keymap.c:215: }
      0085D3 22               [24] 1090 	ret
                                   1091 ;------------------------------------------------------------
                                   1092 ;Allocation info for local variables in function 'dynamic_keymap_set_encoder'
                                   1093 ;------------------------------------------------------------
                                   1094 ;sloc0         Allocated with name '_dynamic_keymap_set_encoder_sloc0_1_0'
                                   1095 ;encoder_id    Allocated with name '_dynamic_keymap_set_encoder_PARM_2'
                                   1096 ;clockwise     Allocated with name '_dynamic_keymap_set_encoder_PARM_3'
                                   1097 ;keycode       Allocated with name '_dynamic_keymap_set_encoder_PARM_4'
                                   1098 ;layer         Allocated with name '_dynamic_keymap_set_encoder_layer_10000_381'
                                   1099 ;address       Allocated with name '_dynamic_keymap_set_encoder_address_10001_384'
                                   1100 ;------------------------------------------------------------
                                   1101 ;	quantum/dynamic_keymap.c:217: void dynamic_keymap_set_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise, uint16_t keycode) {
                                   1102 ;	-----------------------------------------
                                   1103 ;	 function dynamic_keymap_set_encoder
                                   1104 ;	-----------------------------------------
      0085D4                       1105 _dynamic_keymap_set_encoder:
      0085D4 E5 82            [12] 1106 	mov	a,dpl
      0085D6 90 0A F3         [24] 1107 	mov	dptr,#_dynamic_keymap_set_encoder_layer_10000_381
      0085D9 F0               [24] 1108 	movx	@dptr,a
                                   1109 ;	quantum/dynamic_keymap.c:218: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return;
      0085DA E0               [24] 1110 	movx	a,@dptr
      0085DB FF               [12] 1111 	mov	r7,a
      0085DC BF 06 00         [24] 1112 	cjne	r7,#0x06,00131$
      0085DF                       1113 00131$:
      0085DF 50 0A            [24] 1114 	jnc	00101$
      0085E1 90 0A EF         [24] 1115 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      0085E4 E0               [24] 1116 	movx	a,@dptr
      0085E5 FE               [12] 1117 	mov	r6,a
      0085E6 BE 01 00         [24] 1118 	cjne	r6,#0x01,00133$
      0085E9                       1119 00133$:
      0085E9 40 01            [24] 1120 	jc	00102$
      0085EB                       1121 00101$:
      0085EB 22               [24] 1122 	ret
      0085EC                       1123 00102$:
                                   1124 ;	quantum/dynamic_keymap.c:219: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      0085EC 90 0A EA         [24] 1125 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      0085EF E4               [12] 1126 	clr	a
      0085F0 F0               [24] 1127 	movx	@dptr,a
      0085F1 8F 82            [24] 1128 	mov	dpl, r7
      0085F3 12 85 45         [24] 1129 	lcall	_dynamic_keymap_encoder_to_eeprom_address
      0085F6 12 8F 1B         [24] 1130 	lcall	_ak820_outline_0119
                                   1131 ;	quantum/dynamic_keymap.c:221: eeprom_update_byte(address + (clockwise ? 0 : 2), (uint8_t)(keycode >> 8));
      0085F9 90 0A F0         [24] 1132 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      0085FC E0               [24] 1133 	movx	a,@dptr
      0085FD FC               [12] 1134 	mov	r4,a
      0085FE E0               [24] 1135 	movx	a,@dptr
      0085FF 60 04            [24] 1136 	jz	00106$
      008601 7B 00            [12] 1137 	mov	r3,#0x00
      008603 80 02            [24] 1138 	sjmp	00107$
      008605                       1139 00106$:
      008605 7B 02            [12] 1140 	mov	r3,#0x02
      008607                       1141 00107$:
      008607 EB               [12] 1142 	mov	a,r3
      008608 12 8F 2D         [24] 1143 	lcall	_ak820_outline_0138
      00860B 8F 03            [24] 1144 	mov	ar3,r7
      00860D 90 0A F1         [24] 1145 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008610 E0               [24] 1146 	movx	a,@dptr
      008611 F5 29            [12] 1147 	mov	_dynamic_keymap_set_encoder_sloc0_1_0,a
      008613 A3               [24] 1148 	inc	dptr
      008614 E0               [24] 1149 	movx	a,@dptr
      008615 F5 2A            [12] 1150 	mov	(_dynamic_keymap_set_encoder_sloc0_1_0 + 1),a
      008617 90 06 9B         [24] 1151 	mov	dptr,#_eeprom_update_byte_PARM_2
      00861A F0               [24] 1152 	movx	@dptr,a
      00861B 12 43 7E         [24] 1153 	lcall	_ak820_outline_0186
      00861E 8B F0            [24] 1154 	mov	b, r3
      008620 12 4E 12         [24] 1155 	lcall	_eeprom_update_byte
                                   1156 ;	quantum/dynamic_keymap.c:222: eeprom_update_byte(address + (clockwise ? 0 : 2) + 1, (uint8_t)(keycode & 0xFF));
      008623 EC               [12] 1157 	mov	a,r4
      008624 60 04            [24] 1158 	jz	00108$
      008626 7C 00            [12] 1159 	mov	r4,#0x00
      008628 80 02            [24] 1160 	sjmp	00109$
      00862A                       1161 00108$:
      00862A 7C 02            [12] 1162 	mov	r4,#0x02
      00862C                       1163 00109$:
      00862C EC               [12] 1164 	mov	a,r4
      00862D 12 38 BB         [24] 1165 	lcall	_ak820_outline_0163
      008630 0D               [12] 1166 	inc	r5
      008631 BD 00 01         [24] 1167 	cjne	r5,#0x00,00137$
      008634 0E               [12] 1168 	inc	r6
      008635                       1169 00137$:
      008635 90 06 9B         [24] 1170 	mov	dptr,#_eeprom_update_byte_PARM_2
      008638 E5 29            [12] 1171 	mov	a,_dynamic_keymap_set_encoder_sloc0_1_0
      00863A 12 4F 27         [24] 1172 	lcall	_ak820_outline_0034
                                   1173 ;	quantum/dynamic_keymap.c:223: }
      00863D 02 4E 12         [24] 1174 	ljmp	_eeprom_update_byte
                                   1175 ;------------------------------------------------------------
                                   1176 ;Allocation info for local variables in function 'dynamic_keymap_get_combo'
                                   1177 ;------------------------------------------------------------
                                   1178 ;sloc0         Allocated with name '_dynamic_keymap_get_combo_sloc0_1_0'
                                   1179 ;buffer        Allocated with name '_dynamic_keymap_get_combo_PARM_2'
                                   1180 ;index         Allocated with name '_dynamic_keymap_get_combo_index_10000_385'
                                   1181 ;entry         Allocated with name '_dynamic_keymap_get_combo_entry_10000_386'
                                   1182 ;address       Allocated with name '_dynamic_keymap_get_combo_address_10001_388'
                                   1183 ;marked        Allocated with name '_dynamic_keymap_get_combo_marked_10002_389'
                                   1184 ;------------------------------------------------------------
                                   1185 ;	quantum/dynamic_keymap.c:267: int dynamic_keymap_get_combo(uint8_t index, vial_combo_entry_t *buffer) {
                                   1186 ;	-----------------------------------------
                                   1187 ;	 function dynamic_keymap_get_combo
                                   1188 ;	-----------------------------------------
      008640                       1189 _dynamic_keymap_get_combo:
      008640 E5 82            [12] 1190 	mov	a,dpl
      008642 90 0A F7         [24] 1191 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_385
      008645 F0               [24] 1192 	movx	@dptr,a
                                   1193 ;	quantum/dynamic_keymap.c:270: vial_combo_entry_t AK820_STATE_MEM *entry = (vial_combo_entry_t AK820_STATE_MEM *)buffer;
      008646 90 0A F4         [24] 1194 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      008649 12 38 41         [24] 1195 	lcall	_ak820_outline_0052
                                   1196 ;	quantum/dynamic_keymap.c:274: if (index >= VIAL_COMBO_ENTRIES)
      00864C 90 0A F7         [24] 1197 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_385
      00864F E0               [24] 1198 	movx	a,@dptr
      008650 FD               [12] 1199 	mov	r5,a
      008651 BD 08 00         [24] 1200 	cjne	r5,#0x08,00132$
      008654                       1201 00132$:
      008654 40 04            [24] 1202 	jc	00102$
                                   1203 ;	quantum/dynamic_keymap.c:275: return -1;
      008656 90 FF FF         [24] 1204 	mov	dptr,#0xffff
      008659 22               [24] 1205 	ret
      00865A                       1206 00102$:
                                   1207 ;	quantum/dynamic_keymap.c:277: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      00865A 12 8E F3         [24] 1208 	lcall	_ak820_outline_0080
                                   1209 ;	quantum/dynamic_keymap.c:279: ak820_eeprom_read_block_xdata(entry, address, sizeof(vial_combo_entry_t));
      00865D 8E 02            [24] 1210 	mov	ar2,r6
      00865F 8F 03            [24] 1211 	mov	ar3,r7
      008661 90 05 85         [24] 1212 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      008664 12 38 5E         [24] 1213 	lcall	_ak820_outline_0072
      008667 E4               [12] 1214 	clr	a
      008668 A3               [24] 1215 	inc	dptr
      008669 F0               [24] 1216 	movx	@dptr,a
      00866A 90 05 88         [24] 1217 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      00866D 12 8F 14         [24] 1218 	lcall	_ak820_outline_0114
      008670 12 38 AC         [24] 1219 	lcall	_ak820_outline_0145
      008673 C0 07            [24] 1220 	push	ar7
      008675 C0 06            [24] 1221 	push	ar6
      008677 12 40 B1         [24] 1222 	lcall	_ak820_eeprom_read_block_xdata
      00867A D0 06            [24] 1223 	pop	ar6
      00867C D0 07            [24] 1224 	pop	ar7
                                   1225 ;	quantum/dynamic_keymap.c:284: bool marked = entry->input[2] == AK820_COMBO_MARKER && entry->input[3] == AK820_COMBO_VERSION;
      00867E 74 04            [12] 1226 	mov	a,#0x04
      008680 12 48 9E         [24] 1227 	lcall	_ak820_outline_0033
      008683 FA               [12] 1228 	mov	r2,a
      008684 A3               [24] 1229 	inc	dptr
      008685 E0               [24] 1230 	movx	a,@dptr
      008686 FB               [12] 1231 	mov	r3,a
      008687 BA 20 13         [24] 1232 	cjne	r2,#0x20,00108$
      00868A BB 08 10         [24] 1233 	cjne	r3,#0x08,00108$
      00868D 74 06            [12] 1234 	mov	a,#0x06
      00868F 12 38 31         [24] 1235 	lcall	_ak820_outline_0021
      008692 12 43 45         [24] 1236 	lcall	_ak820_outline_0105
      008695 BA 01 05         [24] 1237 	cjne	r2,#0x01,00136$
      008698 BB 00 02         [24] 1238 	cjne	r3,#0x00,00136$
      00869B 80 05            [24] 1239 	sjmp	00109$
      00869D                       1240 00136$:
      00869D                       1241 00108$:
      00869D 75 2B 00         [24] 1242 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x00
      0086A0 80 03            [24] 1243 	sjmp	00110$
      0086A2                       1244 00109$:
      0086A2 75 2B 01         [24] 1245 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x01
      0086A5                       1246 00110$:
                                   1247 ;	quantum/dynamic_keymap.c:285: entry->input[2] = entry->input[3] = 0;
      0086A5 74 06            [12] 1248 	mov	a,#0x06
      0086A7 12 38 31         [24] 1249 	lcall	_ak820_outline_0021
      0086AA E4               [12] 1250 	clr	a
      0086AB F0               [24] 1251 	movx	@dptr,a
      0086AC A3               [24] 1252 	inc	dptr
      0086AD 12 38 76         [24] 1253 	lcall	_ak820_outline_0101
      0086B0 F0               [24] 1254 	movx	@dptr,a
      0086B1 A3               [24] 1255 	inc	dptr
      0086B2 F0               [24] 1256 	movx	@dptr,a
                                   1257 ;	quantum/dynamic_keymap.c:286: if (!marked || !ak820_combo_valid(entry)) memset(entry, 0, sizeof(*entry));
      0086B3 E5 2B            [12] 1258 	mov	a,_dynamic_keymap_get_combo_sloc0_1_0
      0086B5 60 12            [24] 1259 	jz	00103$
      0086B7 12 38 92         [24] 1260 	lcall	_ak820_outline_0121
      0086BA C0 07            [24] 1261 	push	ar7
      0086BC C0 06            [24] 1262 	push	ar6
      0086BE 12 34 D1         [24] 1263 	lcall	_ak820_combo_valid
      0086C1 E5 82            [12] 1264 	mov	a, dpl
      0086C3 D0 06            [24] 1265 	pop	ar6
      0086C5 D0 07            [24] 1266 	pop	ar7
      0086C7 70 13            [24] 1267 	jnz	00104$
      0086C9                       1268 00103$:
      0086C9 7D 00            [12] 1269 	mov	r5,#0x00
      0086CB 90 0D AF         [24] 1270 	mov	dptr,#_memset_PARM_2
      0086CE E4               [12] 1271 	clr	a
      0086CF F0               [24] 1272 	movx	@dptr,a
      0086D0 90 0D B0         [24] 1273 	mov	dptr,#_memset_PARM_3
      0086D3 12 8F 14         [24] 1274 	lcall	_ak820_outline_0114
      0086D6 12 6F B4         [24] 1275 	lcall	_ak820_outline_0050
      0086D9 12 B9 9D         [24] 1276 	lcall	_memset
      0086DC                       1277 00104$:
                                   1278 ;	quantum/dynamic_keymap.c:289: return 0;
      0086DC 90 00 00         [24] 1279 	mov	dptr,#0x0000
                                   1280 ;	quantum/dynamic_keymap.c:290: }
      0086DF 22               [24] 1281 	ret
                                   1282 ;------------------------------------------------------------
                                   1283 ;Allocation info for local variables in function 'dynamic_keymap_set_combo'
                                   1284 ;------------------------------------------------------------
                                   1285 ;buffer        Allocated with name '_dynamic_keymap_set_combo_PARM_2'
                                   1286 ;index         Allocated with name '_dynamic_keymap_set_combo_index_10000_391'
                                   1287 ;entry         Allocated with name '_dynamic_keymap_set_combo_entry_10000_392'
                                   1288 ;address       Allocated with name '_dynamic_keymap_set_combo_address_10001_395'
                                   1289 ;stored        Allocated with name '_dynamic_keymap_set_combo_stored_10002_396'
                                   1290 ;------------------------------------------------------------
                                   1291 ;	quantum/dynamic_keymap.c:292: int dynamic_keymap_set_combo(uint8_t index, const vial_combo_entry_t *buffer) {
                                   1292 ;	-----------------------------------------
                                   1293 ;	 function dynamic_keymap_set_combo
                                   1294 ;	-----------------------------------------
      0086E0                       1295 _dynamic_keymap_set_combo:
      0086E0 E5 82            [12] 1296 	mov	a,dpl
      0086E2 90 0A FB         [24] 1297 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_391
      0086E5 F0               [24] 1298 	movx	@dptr,a
                                   1299 ;	quantum/dynamic_keymap.c:294: const vial_combo_entry_t AK820_STATE_MEM *entry = (const vial_combo_entry_t AK820_STATE_MEM *)buffer;
      0086E6 90 0A F8         [24] 1300 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      0086E9 12 37 F4         [24] 1301 	lcall	_ak820_outline_0005
                                   1302 ;	quantum/dynamic_keymap.c:299: if (!ak820_combo_valid(entry) || !ak820_nvm_ok()) return -1;
      0086EC C0 07            [24] 1303 	push	ar7
      0086EE C0 06            [24] 1304 	push	ar6
      0086F0 12 34 D1         [24] 1305 	lcall	_ak820_combo_valid
      0086F3 E5 82            [12] 1306 	mov	a, dpl
      0086F5 D0 06            [24] 1307 	pop	ar6
      0086F7 D0 07            [24] 1308 	pop	ar7
      0086F9 60 07            [24] 1309 	jz	00101$
      0086FB 12 3E 1C         [24] 1310 	lcall	_ak820_nvm_ok
      0086FE E5 82            [12] 1311 	mov	a, dpl
      008700 70 04            [24] 1312 	jnz	00102$
      008702                       1313 00101$:
      008702 90 FF FF         [24] 1314 	mov	dptr,#0xffff
      008705 22               [24] 1315 	ret
      008706                       1316 00102$:
                                   1317 ;	quantum/dynamic_keymap.c:301: if (index >= VIAL_COMBO_ENTRIES)
      008706 90 0A FB         [24] 1318 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_391
      008709 E0               [24] 1319 	movx	a,@dptr
      00870A FD               [12] 1320 	mov	r5,a
      00870B BD 08 00         [24] 1321 	cjne	r5,#0x08,00133$
      00870E                       1322 00133$:
      00870E 40 04            [24] 1323 	jc	00105$
                                   1324 ;	quantum/dynamic_keymap.c:302: return -1;
      008710 90 FF FF         [24] 1325 	mov	dptr,#0xffff
      008713 22               [24] 1326 	ret
      008714                       1327 00105$:
                                   1328 ;	quantum/dynamic_keymap.c:304: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      008714 12 8E F3         [24] 1329 	lcall	_ak820_outline_0080
                                   1330 ;	quantum/dynamic_keymap.c:306: clear_keyboard();
      008717 C0 07            [24] 1331 	push	ar7
      008719 C0 06            [24] 1332 	push	ar6
      00871B C0 05            [24] 1333 	push	ar5
      00871D C0 04            [24] 1334 	push	ar4
      00871F 12 76 9C         [24] 1335 	lcall	_clear_keyboard
      008722 D0 04            [24] 1336 	pop	ar4
      008724 D0 05            [24] 1337 	pop	ar5
      008726 D0 06            [24] 1338 	pop	ar6
      008728 D0 07            [24] 1339 	pop	ar7
                                   1340 ;	quantum/dynamic_keymap.c:307: vial_combo_entry_t stored = *entry;
      00872A 90 0D A7         [24] 1341 	mov	dptr,#___memcpy_PARM_2
      00872D 12 48 B1         [24] 1342 	lcall	_ak820_outline_0060
      008730 E4               [12] 1343 	clr	a
      008731 A3               [24] 1344 	inc	dptr
      008732 F0               [24] 1345 	movx	@dptr,a
      008733 90 0D AA         [24] 1346 	mov	dptr,#___memcpy_PARM_3
      008736 12 8F 14         [24] 1347 	lcall	_ak820_outline_0114
      008739 90 0A FC         [24] 1348 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_396
      00873C F5 F0            [12] 1349 	mov	b,a
      00873E C0 05            [24] 1350 	push	ar5
      008740 C0 04            [24] 1351 	push	ar4
      008742 12 B9 27         [24] 1352 	lcall	___memcpy
      008745 D0 04            [24] 1353 	pop	ar4
      008747 D0 05            [24] 1354 	pop	ar5
                                   1355 ;	quantum/dynamic_keymap.c:308: stored.input[2] = AK820_COMBO_MARKER;
      008749 90 0B 00         [24] 1356 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_396 + 0x0004)
      00874C 74 20            [12] 1357 	mov	a,#0x20
      00874E F0               [24] 1358 	movx	@dptr,a
      00874F 74 08            [12] 1359 	mov	a,#0x08
      008751 A3               [24] 1360 	inc	dptr
      008752 F0               [24] 1361 	movx	@dptr,a
                                   1362 ;	quantum/dynamic_keymap.c:309: stored.input[3] = AK820_COMBO_VERSION;
      008753 90 0B 02         [24] 1363 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_396 + 0x0006)
      008756 74 01            [12] 1364 	mov	a,#0x01
      008758 12 38 A1         [24] 1365 	lcall	_ak820_outline_0137
                                   1366 ;	quantum/dynamic_keymap.c:310: ak820_eeprom_write_block_xdata(&stored, address, sizeof(stored));
      00875B 90 05 8E         [24] 1367 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      00875E 12 38 5E         [24] 1368 	lcall	_ak820_outline_0072
      008761 E4               [12] 1369 	clr	a
      008762 A3               [24] 1370 	inc	dptr
      008763 F0               [24] 1371 	movx	@dptr,a
      008764 90 05 91         [24] 1372 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      008767 12 8F 14         [24] 1373 	lcall	_ak820_outline_0114
      00876A 90 0A FC         [24] 1374 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_396
      00876D 12 41 3D         [24] 1375 	lcall	_ak820_eeprom_write_block_xdata
                                   1376 ;	quantum/dynamic_keymap.c:315: ak820_nvm_flush();
      008770 12 3E 2B         [24] 1377 	lcall	_ak820_nvm_flush
                                   1378 ;	quantum/dynamic_keymap.c:316: if (!ak820_nvm_ok()) return -1;
      008773 12 3E 1C         [24] 1379 	lcall	_ak820_nvm_ok
      008776 E5 82            [12] 1380 	mov	a, dpl
      008778 70 04            [24] 1381 	jnz	00107$
      00877A 90 FF FF         [24] 1382 	mov	dptr,#0xffff
      00877D 22               [24] 1383 	ret
      00877E                       1384 00107$:
                                   1385 ;	quantum/dynamic_keymap.c:320: return 0;
      00877E 90 00 00         [24] 1386 	mov	dptr,#0x0000
                                   1387 ;	quantum/dynamic_keymap.c:321: }
      008781 22               [24] 1388 	ret
                                   1389 ;------------------------------------------------------------
                                   1390 ;Allocation info for local variables in function 'dynamic_keymap_reset'
                                   1391 ;------------------------------------------------------------
                                   1392 ;vial_unlocked_prev Allocated with name '_dynamic_keymap_reset_vial_unlocked_prev_10000_399'
                                   1393 ;layer         Allocated with name '_dynamic_keymap_reset_layer_20000_400'
                                   1394 ;row           Allocated with name '_dynamic_keymap_reset_row_40000_402'
                                   1395 ;column        Allocated with name '_dynamic_keymap_reset_column_60000_404'
                                   1396 ;encoder       Allocated with name '_dynamic_keymap_reset_encoder_40000_406'
                                   1397 ;combo         Allocated with name '_dynamic_keymap_reset_combo_10001_408'
                                   1398 ;i             Allocated with name '_dynamic_keymap_reset_i_20001_409'
                                   1399 ;------------------------------------------------------------
                                   1400 ;	quantum/dynamic_keymap.c:346: void dynamic_keymap_reset(void) {
                                   1401 ;	-----------------------------------------
                                   1402 ;	 function dynamic_keymap_reset
                                   1403 ;	-----------------------------------------
      008782                       1404 _dynamic_keymap_reset:
                                   1405 ;	quantum/dynamic_keymap.c:357: bool vial_unlocked_prev = vial_unlocked;
      008782 90 0E 27         [24] 1406 	mov	dptr,#_vial_unlocked
      008785 E0               [24] 1407 	movx	a,@dptr
      008786 90 0B 06         [24] 1408 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_399
      008789 F0               [24] 1409 	movx	@dptr,a
                                   1410 ;	quantum/dynamic_keymap.c:358: vial_unlocked = 1;
      00878A 90 0E 27         [24] 1411 	mov	dptr,#_vial_unlocked
      00878D 74 01            [12] 1412 	mov	a,#0x01
      00878F F0               [24] 1413 	movx	@dptr,a
                                   1414 ;	quantum/dynamic_keymap.c:362: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      008790 7F 00            [12] 1415 	mov	r7,#0x00
      008792                       1416 00116$:
      008792 BF 06 00         [24] 1417 	cjne	r7,#0x06,00198$
      008795                       1418 00198$:
      008795 40 03            [24] 1419 	jc	00199$
      008797 02 88 45         [24] 1420 	ljmp	00104$
      00879A                       1421 00199$:
                                   1422 ;	quantum/dynamic_keymap.c:363: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      00879A 7E 00            [12] 1423 	mov	r6,#0x00
      00879C                       1424 00110$:
      00879C BE 10 00         [24] 1425 	cjne	r6,#0x10,00200$
      00879F                       1426 00200$:
      00879F 50 4D            [24] 1427 	jnc	00102$
                                   1428 ;	quantum/dynamic_keymap.c:364: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      0087A1 7D 00            [12] 1429 	mov	r5,#0x00
      0087A3                       1430 00107$:
      0087A3 BD 08 00         [24] 1431 	cjne	r5,#0x08,00202$
      0087A6                       1432 00202$:
      0087A6 50 43            [24] 1433 	jnc	00111$
                                   1434 ;	quantum/dynamic_keymap.c:365: dynamic_keymap_set_keycode(layer, row, column, keycode_at_keymap_location_raw(layer, row, column));
      0087A8 90 0B A2         [24] 1435 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_2
      0087AB EE               [12] 1436 	mov	a,r6
      0087AC F0               [24] 1437 	movx	@dptr,a
      0087AD 90 0B A3         [24] 1438 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_3
      0087B0 ED               [12] 1439 	mov	a,r5
      0087B1 F0               [24] 1440 	movx	@dptr,a
      0087B2 8F 82            [24] 1441 	mov	dpl, r7
      0087B4 C0 07            [24] 1442 	push	ar7
      0087B6 C0 06            [24] 1443 	push	ar6
      0087B8 C0 05            [24] 1444 	push	ar5
      0087BA 12 97 42         [24] 1445 	lcall	_keycode_at_keymap_location_raw
      0087BD AB 82            [24] 1446 	mov	r3, dpl
      0087BF AC 83            [24] 1447 	mov	r4, dph
      0087C1 D0 05            [24] 1448 	pop	ar5
      0087C3 D0 06            [24] 1449 	pop	ar6
      0087C5 D0 07            [24] 1450 	pop	ar7
      0087C7 90 0A E5         [24] 1451 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      0087CA EE               [12] 1452 	mov	a,r6
      0087CB F0               [24] 1453 	movx	@dptr,a
      0087CC 90 0A E6         [24] 1454 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      0087CF ED               [12] 1455 	mov	a,r5
      0087D0 F0               [24] 1456 	movx	@dptr,a
      0087D1 90 0A E7         [24] 1457 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      0087D4 12 38 64         [24] 1458 	lcall	_ak820_outline_0084
      0087D7 8F 82            [24] 1459 	mov	dpl, r7
      0087D9 C0 07            [24] 1460 	push	ar7
      0087DB C0 06            [24] 1461 	push	ar6
      0087DD C0 05            [24] 1462 	push	ar5
      0087DF 12 84 FB         [24] 1463 	lcall	_dynamic_keymap_set_keycode
      0087E2 D0 05            [24] 1464 	pop	ar5
      0087E4 D0 06            [24] 1465 	pop	ar6
      0087E6 D0 07            [24] 1466 	pop	ar7
                                   1467 ;	quantum/dynamic_keymap.c:364: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      0087E8 0D               [12] 1468 	inc	r5
      0087E9 80 B8            [24] 1469 	sjmp	00107$
      0087EB                       1470 00111$:
                                   1471 ;	quantum/dynamic_keymap.c:363: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      0087EB 0E               [12] 1472 	inc	r6
      0087EC 80 AE            [24] 1473 	sjmp	00110$
      0087EE                       1474 00102$:
                                   1475 ;	quantum/dynamic_keymap.c:369: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      0087EE 7E 00            [12] 1476 	mov	r6,#0x00
      0087F0                       1477 00113$:
      0087F0 BE 01 00         [24] 1478 	cjne	r6,#0x01,00204$
      0087F3                       1479 00204$:
      0087F3 50 4C            [24] 1480 	jnc	00117$
                                   1481 ;	quantum/dynamic_keymap.c:370: dynamic_keymap_set_encoder(layer, encoder, true, keycode_at_encodermap_location_raw(layer, encoder, true));
      0087F5 12 8F 49         [24] 1482 	lcall	_ak820_outline_0181
      0087F8 04               [12] 1483 	inc	a
      0087F9 F0               [24] 1484 	movx	@dptr,a
      0087FA 8F 82            [24] 1485 	mov	dpl, r7
      0087FC C0 07            [24] 1486 	push	ar7
      0087FE 12 97 87         [24] 1487 	lcall	_keycode_at_encodermap_location_raw
      008801 12 43 68         [24] 1488 	lcall	_ak820_outline_0151
      008804 D0 07            [24] 1489 	pop	ar7
      008806 12 8F 40         [24] 1490 	lcall	_ak820_outline_0180
      008809 04               [12] 1491 	inc	a
      00880A F0               [24] 1492 	movx	@dptr,a
      00880B 90 0A F1         [24] 1493 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      00880E 12 38 5E         [24] 1494 	lcall	_ak820_outline_0072
      008811 8F 82            [24] 1495 	mov	dpl, r7
      008813 C0 07            [24] 1496 	push	ar7
      008815 12 85 D4         [24] 1497 	lcall	_dynamic_keymap_set_encoder
      008818 D0 07            [24] 1498 	pop	ar7
                                   1499 ;	quantum/dynamic_keymap.c:371: dynamic_keymap_set_encoder(layer, encoder, false, keycode_at_encodermap_location_raw(layer, encoder, false));
      00881A 12 8F 49         [24] 1500 	lcall	_ak820_outline_0181
      00881D F0               [24] 1501 	movx	@dptr,a
      00881E 8F 82            [24] 1502 	mov	dpl, r7
      008820 C0 07            [24] 1503 	push	ar7
      008822 12 97 87         [24] 1504 	lcall	_keycode_at_encodermap_location_raw
      008825 12 43 68         [24] 1505 	lcall	_ak820_outline_0151
      008828 D0 07            [24] 1506 	pop	ar7
      00882A 12 8F 40         [24] 1507 	lcall	_ak820_outline_0180
      00882D F0               [24] 1508 	movx	@dptr,a
      00882E 90 0A F1         [24] 1509 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008831 12 38 5E         [24] 1510 	lcall	_ak820_outline_0072
      008834 8F 82            [24] 1511 	mov	dpl, r7
      008836 C0 07            [24] 1512 	push	ar7
      008838 12 85 D4         [24] 1513 	lcall	_dynamic_keymap_set_encoder
      00883B D0 07            [24] 1514 	pop	ar7
                                   1515 ;	quantum/dynamic_keymap.c:369: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      00883D 7E 01            [12] 1516 	mov	r6,#0x01
      00883F 80 AF            [24] 1517 	sjmp	00113$
      008841                       1518 00117$:
                                   1519 ;	quantum/dynamic_keymap.c:362: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      008841 0F               [12] 1520 	inc	r7
      008842 02 87 92         [24] 1521 	ljmp	00116$
      008845                       1522 00104$:
                                   1523 ;	quantum/dynamic_keymap.c:388: vial_combo_entry_t combo = { { 0 }, 0 };
      008845 90 0B 07         [24] 1524 	mov	dptr,#_dynamic_keymap_reset_combo_10001_408
      008848 12 4F 71         [24] 1525 	lcall	_ak820_outline_0185
      00884B 90 0B 09         [24] 1526 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_408 + 0x0002)
      00884E F0               [24] 1527 	movx	@dptr,a
      00884F A3               [24] 1528 	inc	dptr
      008850 F0               [24] 1529 	movx	@dptr,a
      008851 90 0B 0B         [24] 1530 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_408 + 0x0004)
      008854 F0               [24] 1531 	movx	@dptr,a
      008855 A3               [24] 1532 	inc	dptr
      008856 F0               [24] 1533 	movx	@dptr,a
      008857 90 0B 0D         [24] 1534 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_408 + 0x0006)
      00885A F0               [24] 1535 	movx	@dptr,a
      00885B A3               [24] 1536 	inc	dptr
      00885C F0               [24] 1537 	movx	@dptr,a
      00885D 90 0B 0F         [24] 1538 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_408 + 0x0008)
      008860 F0               [24] 1539 	movx	@dptr,a
      008861 A3               [24] 1540 	inc	dptr
      008862 F0               [24] 1541 	movx	@dptr,a
                                   1542 ;	quantum/dynamic_keymap.c:389: for (size_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      008863 FF               [12] 1543 	mov	r7,a
      008864                       1544 00119$:
      008864 BF 08 00         [24] 1545 	cjne	r7,#0x08,00206$
      008867                       1546 00206$:
      008867 50 19            [24] 1547 	jnc	00105$
                                   1548 ;	quantum/dynamic_keymap.c:390: dynamic_keymap_set_combo(i, &combo);
      008869 8F 06            [24] 1549 	mov	ar6,r7
      00886B 90 0A F8         [24] 1550 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      00886E 74 07            [12] 1551 	mov	a,#_dynamic_keymap_reset_combo_10001_408
      008870 F0               [24] 1552 	movx	@dptr,a
      008871 74 0B            [12] 1553 	mov	a,#(_dynamic_keymap_reset_combo_10001_408 >> 8)
      008873 12 38 70         [24] 1554 	lcall	_ak820_outline_0093
      008876 8E 82            [24] 1555 	mov	dpl, r6
      008878 C0 07            [24] 1556 	push	ar7
      00887A 12 86 E0         [24] 1557 	lcall	_dynamic_keymap_set_combo
      00887D D0 07            [24] 1558 	pop	ar7
                                   1559 ;	quantum/dynamic_keymap.c:389: for (size_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      00887F 0F               [12] 1560 	inc	r7
      008880 80 E2            [24] 1561 	sjmp	00119$
      008882                       1562 00105$:
                                   1563 ;	quantum/dynamic_keymap.c:403: vial_unlocked = vial_unlocked_prev;
      008882 90 0B 06         [24] 1564 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_399
      008885 E0               [24] 1565 	movx	a,@dptr
      008886 90 0E 27         [24] 1566 	mov	dptr,#_vial_unlocked
      008889 F0               [24] 1567 	movx	@dptr,a
                                   1568 ;	quantum/dynamic_keymap.c:405: }
      00888A 22               [24] 1569 	ret
                                   1570 ;------------------------------------------------------------
                                   1571 ;Allocation info for local variables in function 'ak820_dynamic_read_buffer'
                                   1572 ;------------------------------------------------------------
                                   1573 ;sloc0         Allocated with name '_ak820_dynamic_read_buffer_sloc0_1_0'
                                   1574 ;limit         Allocated with name '_ak820_dynamic_read_buffer_PARM_2'
                                   1575 ;offset        Allocated with name '_ak820_dynamic_read_buffer_PARM_3'
                                   1576 ;size          Allocated with name '_ak820_dynamic_read_buffer_PARM_4'
                                   1577 ;data          Allocated with name '_ak820_dynamic_read_buffer_PARM_5'
                                   1578 ;base          Allocated with name '_ak820_dynamic_read_buffer_base_10000_410'
                                   1579 ;target        Allocated with name '_ak820_dynamic_read_buffer_target_10000_411'
                                   1580 ;available     Allocated with name '_ak820_dynamic_read_buffer_available_10000_411'
                                   1581 ;remaining     Allocated with name '_ak820_dynamic_read_buffer_remaining_30000_414'
                                   1582 ;i             Allocated with name '_ak820_dynamic_read_buffer_i_20000_416'
                                   1583 ;------------------------------------------------------------
                                   1584 ;	quantum/dynamic_keymap.c:410: static void ak820_dynamic_read_buffer(uint16_t base, uint16_t limit, uint16_t offset, uint16_t size, uint8_t *data) {
                                   1585 ;	-----------------------------------------
                                   1586 ;	 function ak820_dynamic_read_buffer
                                   1587 ;	-----------------------------------------
      00888B                       1588 _ak820_dynamic_read_buffer:
      00888B 12 38 88         [24] 1589 	lcall	_ak820_outline_0110
      00888E 90 0B 1A         [24] 1590 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_410
      008891 12 38 8D         [24] 1591 	lcall	_ak820_outline_0111
                                   1592 ;	quantum/dynamic_keymap.c:411: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      008894 90 0B 17         [24] 1593 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008897 12 38 41         [24] 1594 	lcall	_ak820_outline_0052
                                   1595 ;	quantum/dynamic_keymap.c:412: uint8_t available = 0;
      00889A 90 0B 1C         [24] 1596 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_411
      00889D E4               [12] 1597 	clr	a
      00889E F0               [24] 1598 	movx	@dptr,a
                                   1599 ;	quantum/dynamic_keymap.c:413: if (size > 28) return;
      00889F 90 0B 15         [24] 1600 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      0088A2 12 38 58         [24] 1601 	lcall	_ak820_outline_0061
      0088A5 8C 02            [24] 1602 	mov	ar2,r4
      0088A7 8D 03            [24] 1603 	mov	ar3,r5
      0088A9 C3               [12] 1604 	clr	c
      0088AA 74 1C            [12] 1605 	mov	a,#0x1c
      0088AC 9A               [12] 1606 	subb	a,r2
      0088AD E4               [12] 1607 	clr	a
      0088AE 9B               [12] 1608 	subb	a,r3
      0088AF 50 01            [24] 1609 	jnc	00102$
                                   1610 ;	free result
      0088B1 22               [24] 1611 	ret
      0088B2                       1612 00102$:
                                   1613 ;	quantum/dynamic_keymap.c:414: if (offset < limit) {
      0088B2 90 0B 13         [24] 1614 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      0088B5 12 43 45         [24] 1615 	lcall	_ak820_outline_0105
      0088B8 90 0B 11         [24] 1616 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      0088BB 12 38 7C         [24] 1617 	lcall	_ak820_outline_0104
      0088BE C3               [12] 1618 	clr	c
      0088BF EA               [12] 1619 	mov	a,r2
      0088C0 98               [12] 1620 	subb	a,r0
      0088C1 EB               [12] 1621 	mov	a,r3
      0088C2 99               [12] 1622 	subb	a,r1
      0088C3 50 17            [24] 1623 	jnc	00104$
                                   1624 ;	quantum/dynamic_keymap.c:415: uint16_t remaining = limit - offset;
      0088C5 E8               [12] 1625 	mov	a,r0
      0088C6 C3               [12] 1626 	clr	c
      0088C7 9A               [12] 1627 	subb	a,r2
      0088C8 F8               [12] 1628 	mov	r0,a
      0088C9 E9               [12] 1629 	mov	a,r1
      0088CA 9B               [12] 1630 	subb	a,r3
      0088CB F9               [12] 1631 	mov	r1,a
                                   1632 ;	quantum/dynamic_keymap.c:416: available = remaining < size ? remaining : size;
      0088CC C3               [12] 1633 	clr	c
      0088CD E8               [12] 1634 	mov	a,r0
      0088CE 9C               [12] 1635 	subb	a,r4
      0088CF E9               [12] 1636 	mov	a,r1
      0088D0 9D               [12] 1637 	subb	a,r5
      0088D1 40 04            [24] 1638 	jc	00114$
      0088D3 8C 00            [24] 1639 	mov	ar0,r4
      0088D5 8D 01            [24] 1640 	mov	ar1,r5
      0088D7                       1641 00114$:
      0088D7 90 0B 1C         [24] 1642 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_411
      0088DA E8               [12] 1643 	mov	a,r0
      0088DB F0               [24] 1644 	movx	@dptr,a
      0088DC                       1645 00104$:
                                   1646 ;	quantum/dynamic_keymap.c:418: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      0088DC 90 0B 1C         [24] 1647 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_411
      0088DF E0               [24] 1648 	movx	a,@dptr
      0088E0 F5 2C            [12] 1649 	mov	_ak820_dynamic_read_buffer_sloc0_1_0,a
      0088E2 E0               [24] 1650 	movx	a,@dptr
      0088E3 60 42            [24] 1651 	jz	00106$
      0088E5 C0 04            [24] 1652 	push	ar4
      0088E7 C0 05            [24] 1653 	push	ar5
      0088E9 8E 00            [24] 1654 	mov	ar0,r6
      0088EB 8F 05            [24] 1655 	mov	ar5,r7
      0088ED 90 0B 1A         [24] 1656 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_410
      0088F0 E0               [24] 1657 	movx	a,@dptr
      0088F1 F9               [12] 1658 	mov	r1,a
      0088F2 A3               [24] 1659 	inc	dptr
      0088F3 E0               [24] 1660 	movx	a,@dptr
      0088F4 FC               [12] 1661 	mov	r4,a
      0088F5 EA               [12] 1662 	mov	a,r2
      0088F6 29               [12] 1663 	add	a, r1
      0088F7 FA               [12] 1664 	mov	r2,a
      0088F8 EB               [12] 1665 	mov	a,r3
      0088F9 3C               [12] 1666 	addc	a, r4
      0088FA FB               [12] 1667 	mov	r3,a
      0088FB 90 05 85         [24] 1668 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      0088FE EA               [12] 1669 	mov	a,r2
      0088FF F0               [24] 1670 	movx	@dptr,a
      008900 EB               [12] 1671 	mov	a,r3
      008901 12 38 70         [24] 1672 	lcall	_ak820_outline_0093
      008904 90 05 88         [24] 1673 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      008907 E5 2C            [12] 1674 	mov	a,_ak820_dynamic_read_buffer_sloc0_1_0
      008909 12 38 A1         [24] 1675 	lcall	_ak820_outline_0137
      00890C 88 82            [24] 1676 	mov	dpl, r0
      00890E 8D 83            [24] 1677 	mov	dph, r5
      008910 C0 07            [24] 1678 	push	ar7
      008912 C0 06            [24] 1679 	push	ar6
      008914 C0 05            [24] 1680 	push	ar5
      008916 C0 04            [24] 1681 	push	ar4
      008918 12 40 B1         [24] 1682 	lcall	_ak820_eeprom_read_block_xdata
      00891B D0 04            [24] 1683 	pop	ar4
      00891D D0 05            [24] 1684 	pop	ar5
      00891F D0 06            [24] 1685 	pop	ar6
      008921 D0 07            [24] 1686 	pop	ar7
                                   1687 ;	quantum/dynamic_keymap.c:419: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      008923 D0 05            [24] 1688 	pop	ar5
      008925 D0 04            [24] 1689 	pop	ar4
                                   1690 ;	quantum/dynamic_keymap.c:418: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      008927                       1691 00106$:
                                   1692 ;	quantum/dynamic_keymap.c:419: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      008927 90 0B 1C         [24] 1693 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_411
      00892A E0               [24] 1694 	movx	a,@dptr
      00892B FB               [12] 1695 	mov	r3,a
      00892C                       1696 00109$:
      00892C 8B 01            [24] 1697 	mov	ar1,r3
      00892E 7A 00            [12] 1698 	mov	r2,#0x00
      008930 C3               [12] 1699 	clr	c
      008931 E9               [12] 1700 	mov	a,r1
      008932 9C               [12] 1701 	subb	a,r4
      008933 EA               [12] 1702 	mov	a,r2
      008934 9D               [12] 1703 	subb	a,r5
      008935 50 09            [24] 1704 	jnc	00111$
      008937 EB               [12] 1705 	mov	a,r3
      008938 12 38 31         [24] 1706 	lcall	_ak820_outline_0021
      00893B E4               [12] 1707 	clr	a
      00893C F0               [24] 1708 	movx	@dptr,a
      00893D 0B               [12] 1709 	inc	r3
      00893E 80 EC            [24] 1710 	sjmp	00109$
      008940                       1711 00111$:
                                   1712 ;	quantum/dynamic_keymap.c:420: }
      008940 22               [24] 1713 	ret
                                   1714 ;------------------------------------------------------------
                                   1715 ;Allocation info for local variables in function 'dynamic_keymap_get_buffer'
                                   1716 ;------------------------------------------------------------
                                   1717 ;size          Allocated with name '_dynamic_keymap_get_buffer_PARM_2'
                                   1718 ;data          Allocated with name '_dynamic_keymap_get_buffer_PARM_3'
                                   1719 ;offset        Allocated with name '_dynamic_keymap_get_buffer_offset_10000_417'
                                   1720 ;------------------------------------------------------------
                                   1721 ;	quantum/dynamic_keymap.c:423: void dynamic_keymap_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   1722 ;	-----------------------------------------
                                   1723 ;	 function dynamic_keymap_get_buffer
                                   1724 ;	-----------------------------------------
      008941                       1725 _dynamic_keymap_get_buffer:
      008941 12 38 88         [24] 1726 	lcall	_ak820_outline_0110
      008944 90 0B 22         [24] 1727 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_417
      008947 12 38 8D         [24] 1728 	lcall	_ak820_outline_0111
                                   1729 ;	quantum/dynamic_keymap.c:426: DYNAMIC_KEYMAP_LAYER_COUNT * MATRIX_ROWS * MATRIX_COLS * 2, offset, size, data);
      00894A 90 0B 22         [24] 1730 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_417
      00894D 12 38 41         [24] 1731 	lcall	_ak820_outline_0052
      008950 90 0B 1D         [24] 1732 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_2
      008953 12 38 58         [24] 1733 	lcall	_ak820_outline_0061
      008956 90 0B 1F         [24] 1734 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_3
      008959 12 4F 51         [24] 1735 	lcall	_ak820_outline_0091
      00895C 90 0B 11         [24] 1736 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      00895F E4               [12] 1737 	clr	a
      008960 F0               [24] 1738 	movx	@dptr,a
      008961 74 06            [12] 1739 	mov	a,#0x06
      008963 A3               [24] 1740 	inc	dptr
      008964 F0               [24] 1741 	movx	@dptr,a
      008965 90 0B 13         [24] 1742 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008968 12 48 B1         [24] 1743 	lcall	_ak820_outline_0060
      00896B 90 0B 15         [24] 1744 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      00896E 12 38 5E         [24] 1745 	lcall	_ak820_outline_0072
      008971 90 0B 17         [24] 1746 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008974 E9               [12] 1747 	mov	a,r1
      008975 12 4F 6A         [24] 1748 	lcall	_ak820_outline_0158
      008978 F0               [24] 1749 	movx	@dptr,a
      008979 90 00 40         [24] 1750 	mov	dptr,#0x0040
                                   1751 ;	quantum/dynamic_keymap.c:448: }
      00897C 02 88 8B         [24] 1752 	ljmp	_ak820_dynamic_read_buffer
                                   1753 ;------------------------------------------------------------
                                   1754 ;Allocation info for local variables in function 'dynamic_keymap_set_buffer'
                                   1755 ;------------------------------------------------------------
                                   1756 ;sloc0         Allocated with name '_dynamic_keymap_set_buffer_sloc0_1_0'
                                   1757 ;sloc1         Allocated with name '_dynamic_keymap_set_buffer_sloc1_1_0'
                                   1758 ;sloc2         Allocated with name '_dynamic_keymap_set_buffer_sloc2_1_0'
                                   1759 ;size          Allocated with name '_dynamic_keymap_set_buffer_PARM_2'
                                   1760 ;data          Allocated with name '_dynamic_keymap_set_buffer_PARM_3'
                                   1761 ;offset        Allocated with name '_dynamic_keymap_set_buffer_offset_10000_419'
                                   1762 ;dynamic_keymap_eeprom_size Allocated with name '_dynamic_keymap_set_buffer_dynamic_keymap_eeprom_size_10000_420'
                                   1763 ;target        Allocated with name '_dynamic_keymap_set_buffer_target_10000_420'
                                   1764 ;buffer        Allocated with name '_dynamic_keymap_set_buffer_buffer_10000_420'
                                   1765 ;count         Allocated with name '_dynamic_keymap_set_buffer_count_10001_423'
                                   1766 ;chk_offset    Allocated with name '_dynamic_keymap_set_buffer_chk_offset_30001_426'
                                   1767 ;chk_sz        Allocated with name '_dynamic_keymap_set_buffer_chk_sz_30001_426'
                                   1768 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_428'
                                   1769 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_431'
                                   1770 ;i             Allocated with name '_dynamic_keymap_set_buffer_i_40001_433'
                                   1771 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_434'
                                   1772 ;------------------------------------------------------------
                                   1773 ;	quantum/dynamic_keymap.c:450: void dynamic_keymap_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   1774 ;	-----------------------------------------
                                   1775 ;	 function dynamic_keymap_set_buffer
                                   1776 ;	-----------------------------------------
      00897F                       1777 _dynamic_keymap_set_buffer:
      00897F 12 38 88         [24] 1778 	lcall	_ak820_outline_0110
      008982 90 0B 29         [24] 1779 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_419
      008985 12 38 8D         [24] 1780 	lcall	_ak820_outline_0111
                                   1781 ;	quantum/dynamic_keymap.c:452: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset);
      008988 90 0B 29         [24] 1782 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_419
      00898B 12 48 55         [24] 1783 	lcall	_ak820_outline_0008
      00898E 74 40            [12] 1784 	mov	a,#0x40
      008990 2C               [12] 1785 	add	a, r4
      008991 FA               [12] 1786 	mov	r2,a
      008992 E4               [12] 1787 	clr	a
      008993 3D               [12] 1788 	addc	a, r5
      008994 FB               [12] 1789 	mov	r3,a
                                   1790 ;	quantum/dynamic_keymap.c:453: uint8_t DYNAMIC_BUFFER_MEM *buffer = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      008995 90 0B 26         [24] 1791 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_3
      008998 12 38 7C         [24] 1792 	lcall	_ak820_outline_0104
                                   1793 ;	quantum/dynamic_keymap.c:457: if (!size) return;
      00899B 90 0B 24         [24] 1794 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_2
      00899E E0               [24] 1795 	movx	a,@dptr
      00899F F5 2D            [12] 1796 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,a
      0089A1 A3               [24] 1797 	inc	dptr
      0089A2 E0               [24] 1798 	movx	a,@dptr
      0089A3 F5 2E            [12] 1799 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),a
      0089A5 E5 2D            [12] 1800 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      0089A7 45 2E            [12] 1801 	orl	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      0089A9 70 01            [24] 1802 	jnz	00102$
      0089AB 22               [24] 1803 	ret
      0089AC                       1804 00102$:
                                   1805 ;	quantum/dynamic_keymap.c:459: if (size > 28) return;
      0089AC 85 2D 2F         [24] 1806 	mov	_dynamic_keymap_set_buffer_sloc1_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
      0089AF 85 2E 30         [24] 1807 	mov	(_dynamic_keymap_set_buffer_sloc1_1_0 + 1),(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      0089B2 C3               [12] 1808 	clr	c
      0089B3 74 1C            [12] 1809 	mov	a,#0x1c
      0089B5 95 2F            [12] 1810 	subb	a,_dynamic_keymap_set_buffer_sloc1_1_0
      0089B7 E4               [12] 1811 	clr	a
      0089B8 95 30            [12] 1812 	subb	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      0089BA 50 01            [24] 1813 	jnc	00104$
                                   1814 ;	free result
      0089BC 22               [24] 1815 	ret
      0089BD                       1816 00104$:
                                   1817 ;	quantum/dynamic_keymap.c:461: dynamic_buffer_size_t count = size;
      0089BD 85 2D 31         [24] 1818 	mov	_dynamic_keymap_set_buffer_sloc2_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
                                   1819 ;	quantum/dynamic_keymap.c:465: if (offset >= dynamic_keymap_eeprom_size || dynamic_keymap_eeprom_size - offset < size)
      0089C0 74 FA            [12] 1820 	mov	a,#0x100 - 0x06
      0089C2 2F               [12] 1821 	add	a,r7
      0089C3 40 11            [24] 1822 	jc	00105$
      0089C5 E4               [12] 1823 	clr	a
      0089C6 C3               [12] 1824 	clr	c
      0089C7 9E               [12] 1825 	subb	a,r6
      0089C8 FE               [12] 1826 	mov	r6,a
      0089C9 74 06            [12] 1827 	mov	a,#0x06
      0089CB 9F               [12] 1828 	subb	a,r7
      0089CC FF               [12] 1829 	mov	r7,a
      0089CD C3               [12] 1830 	clr	c
      0089CE EE               [12] 1831 	mov	a,r6
      0089CF 95 2D            [12] 1832 	subb	a,_dynamic_keymap_set_buffer_sloc0_1_0
      0089D1 EF               [12] 1833 	mov	a,r7
      0089D2 95 2E            [12] 1834 	subb	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      0089D4 50 01            [24] 1835 	jnc	00106$
      0089D6                       1836 00105$:
                                   1837 ;	quantum/dynamic_keymap.c:466: return;
      0089D6 22               [24] 1838 	ret
      0089D7                       1839 00106$:
                                   1840 ;	quantum/dynamic_keymap.c:470: if (!vial_unlocked) {
      0089D7 90 0E 27         [24] 1841 	mov	dptr,#_vial_unlocked
      0089DA E0               [24] 1842 	movx	a,@dptr
      0089DB 60 03            [24] 1843 	jz	00207$
      0089DD 02 8A E9         [24] 1844 	ljmp	00120$
      0089E0                       1845 00207$:
                                   1846 ;	quantum/dynamic_keymap.c:472: dynamic_buffer_size_t chk_offset = 0;
      0089E0 90 0B 2B         [24] 1847 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_426
      0089E3 E4               [12] 1848 	clr	a
      0089E4 F0               [24] 1849 	movx	@dptr,a
                                   1850 ;	quantum/dynamic_keymap.c:473: dynamic_buffer_size_t chk_sz = count;
      0089E5 90 0B 2C         [24] 1851 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_426
      0089E8 E5 31            [12] 1852 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      0089EA F0               [24] 1853 	movx	@dptr,a
                                   1854 ;	quantum/dynamic_keymap.c:476: if (offset % 2 != 0) {
      0089EB EC               [12] 1855 	mov	a,r4
      0089EC 30 E0 31         [24] 1856 	jnb	acc.0,00111$
                                   1857 ;	quantum/dynamic_keymap.c:477: uint16_t kc = (eeprom_read_byte(target - 1) << 8) | buffer[0];
      0089EF EA               [12] 1858 	mov	a,r2
      0089F0 24 FF            [12] 1859 	add	a,#0xff
      0089F2 FE               [12] 1860 	mov	r6,a
      0089F3 EB               [12] 1861 	mov	a,r3
      0089F4 34 FF            [12] 1862 	addc	a,#0xff
      0089F6 FF               [12] 1863 	mov	r7,a
      0089F7 7D 00            [12] 1864 	mov	r5,#0x00
      0089F9 12 6F B4         [24] 1865 	lcall	_ak820_outline_0050
      0089FC 12 40 76         [24] 1866 	lcall	_eeprom_read_byte
      0089FF AE 82            [24] 1867 	mov	r6,dpl
      008A01 7F 00            [12] 1868 	mov	r7,#0x00
      008A03 12 38 B6         [24] 1869 	lcall	_ak820_outline_0160
      008A06 E0               [24] 1870 	movx	a,@dptr
      008A07 7C 00            [12] 1871 	mov	r4,#0x00
      008A09 42 07            [12] 1872 	orl	ar7,a
      008A0B EC               [12] 1873 	mov	a,r4
      008A0C 42 06            [12] 1874 	orl	ar6,a
                                   1875 ;	quantum/dynamic_keymap.c:478: if (kc == QK_BOOT)
      008A0E BF 00 09         [24] 1876 	cjne	r7,#0x00,00109$
      008A11 BE 7C 06         [24] 1877 	cjne	r6,#0x7c,00109$
                                   1878 ;	quantum/dynamic_keymap.c:479: buffer[0] = 0xFF;
      008A14 12 38 B6         [24] 1879 	lcall	_ak820_outline_0160
      008A17 74 FF            [12] 1880 	mov	a,#0xff
      008A19 F0               [24] 1881 	movx	@dptr,a
      008A1A                       1882 00109$:
                                   1883 ;	quantum/dynamic_keymap.c:482: chk_offset += 1;
      008A1A 90 0B 2B         [24] 1884 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_426
      008A1D 74 01            [12] 1885 	mov	a,#0x01
      008A1F F0               [24] 1886 	movx	@dptr,a
      008A20                       1887 00111$:
                                   1888 ;	quantum/dynamic_keymap.c:486: if ((offset + size) % 2 != 0) {
      008A20 90 0B 29         [24] 1889 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_419
      008A23 12 38 41         [24] 1890 	lcall	_ak820_outline_0052
      008A26 E5 2D            [12] 1891 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008A28 2E               [12] 1892 	add	a, r6
      008A29 FE               [12] 1893 	mov	r6,a
      008A2A E5 2E            [12] 1894 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008A2C 3F               [12] 1895 	addc	a, r7
      008A2D EE               [12] 1896 	mov	a,r6
      008A2E 30 E0 5A         [24] 1897 	jnb	acc.0,00115$
                                   1898 ;	quantum/dynamic_keymap.c:487: uint16_t kc = (buffer[count - 1] << 8) | eeprom_read_byte(target + count);
      008A31 AE 31            [24] 1899 	mov	r6,_dynamic_keymap_set_buffer_sloc2_1_0
      008A33 7F 00            [12] 1900 	mov	r7,#0x00
      008A35 EE               [12] 1901 	mov	a,r6
      008A36 24 FF            [12] 1902 	add	a,#0xff
      008A38 FC               [12] 1903 	mov	r4,a
      008A39 EF               [12] 1904 	mov	a,r7
      008A3A 34 FF            [12] 1905 	addc	a,#0xff
      008A3C FD               [12] 1906 	mov	r5,a
      008A3D EC               [12] 1907 	mov	a,r4
      008A3E 28               [12] 1908 	add	a, r0
      008A3F F5 82            [12] 1909 	mov	dpl,a
      008A41 ED               [12] 1910 	mov	a,r5
      008A42 39               [12] 1911 	addc	a, r1
      008A43 F5 83            [12] 1912 	mov	dph,a
      008A45 E0               [24] 1913 	movx	a,@dptr
      008A46 FC               [12] 1914 	mov	r4,a
      008A47 7D 00            [12] 1915 	mov	r5,#0x00
      008A49 E5 31            [12] 1916 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008A4B 2A               [12] 1917 	add	a, r2
      008A4C FA               [12] 1918 	mov	r2,a
      008A4D E4               [12] 1919 	clr	a
      008A4E 3B               [12] 1920 	addc	a, r3
      008A4F FB               [12] 1921 	mov	r3,a
      008A50 C0 00            [24] 1922 	push	ar0
      008A52 C0 01            [24] 1923 	push	ar1
      008A54 8B 01            [24] 1924 	mov	ar1,r3
      008A56 7B 00            [12] 1925 	mov	r3,#0x00
      008A58 8A 82            [24] 1926 	mov	dpl, r2
      008A5A 89 83            [24] 1927 	mov	dph, r1
      008A5C 8B F0            [24] 1928 	mov	b, r3
      008A5E 12 40 76         [24] 1929 	lcall	_eeprom_read_byte
      008A61 AB 82            [24] 1930 	mov	r3, dpl
      008A63 7A 00            [12] 1931 	mov	r2,#0x00
      008A65 EB               [12] 1932 	mov	a,r3
      008A66 12 43 62         [24] 1933 	lcall	_ak820_outline_0144
                                   1934 ;	quantum/dynamic_keymap.c:488: if (kc == QK_BOOT)
      008A69 BD 00 05         [24] 1935 	cjne	r5,#0x00,00212$
      008A6C BC 7C 02         [24] 1936 	cjne	r4,#0x7c,00212$
      008A6F 80 06            [24] 1937 	sjmp	00213$
      008A71                       1938 00212$:
      008A71 D0 01            [24] 1939 	pop	ar1
      008A73 D0 00            [24] 1940 	pop	ar0
      008A75 80 0D            [24] 1941 	sjmp	00113$
      008A77                       1942 00213$:
      008A77 D0 01            [24] 1943 	pop	ar1
      008A79 D0 00            [24] 1944 	pop	ar0
                                   1945 ;	quantum/dynamic_keymap.c:489: buffer[count - 1] = 0xFF;
      008A7B 1E               [12] 1946 	dec	r6
      008A7C BE FF 01         [24] 1947 	cjne	r6,#0xff,00214$
      008A7F 1F               [12] 1948 	dec	r7
      008A80                       1949 00214$:
      008A80 EE               [12] 1950 	mov	a,r6
      008A81 12 8F 22         [24] 1951 	lcall	_ak820_outline_0130
      008A84                       1952 00113$:
                                   1953 ;	quantum/dynamic_keymap.c:492: chk_sz -= 1;
      008A84 E5 31            [12] 1954 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008A86 14               [12] 1955 	dec	a
      008A87 90 0B 2C         [24] 1956 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_426
      008A8A F0               [24] 1957 	movx	@dptr,a
      008A8B                       1958 00115$:
                                   1959 ;	quantum/dynamic_keymap.c:496: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      008A8B 90 0B 2B         [24] 1960 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_426
      008A8E E0               [24] 1961 	movx	a,@dptr
      008A8F 90 0B 2D         [24] 1962 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_433
      008A92 F0               [24] 1963 	movx	@dptr,a
      008A93                       1964 00122$:
      008A93 90 0B 2D         [24] 1965 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_433
      008A96 E0               [24] 1966 	movx	a,@dptr
      008A97 FF               [12] 1967 	mov	r7,a
      008A98 90 0B 2C         [24] 1968 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_426
      008A9B E0               [24] 1969 	movx	a,@dptr
      008A9C FE               [12] 1970 	mov	r6,a
      008A9D C3               [12] 1971 	clr	c
      008A9E EF               [12] 1972 	mov	a,r7
      008A9F 9E               [12] 1973 	subb	a,r6
      008AA0 50 47            [24] 1974 	jnc	00120$
                                   1975 ;	quantum/dynamic_keymap.c:497: uint16_t kc = (buffer[i] << 8) | buffer[i + 1];
      008AA2 EF               [12] 1976 	mov	a,r7
      008AA3 28               [12] 1977 	add	a, r0
      008AA4 FD               [12] 1978 	mov	r5,a
      008AA5 E4               [12] 1979 	clr	a
      008AA6 39               [12] 1980 	addc	a, r1
      008AA7 12 48 A9         [24] 1981 	lcall	_ak820_outline_0057
      008AAA 7B 00            [12] 1982 	mov	r3,#0x00
      008AAC 8C 2E            [24] 1983 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),r4
      008AAE 8B 2D            [24] 1984 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,r3
      008AB0 8F 02            [24] 1985 	mov	ar2,r7
      008AB2 7F 00            [12] 1986 	mov	r7,#0x00
      008AB4 74 01            [12] 1987 	mov	a,#0x01
      008AB6 2A               [12] 1988 	add	a, r2
      008AB7 FB               [12] 1989 	mov	r3,a
      008AB8 E4               [12] 1990 	clr	a
      008AB9 3F               [12] 1991 	addc	a, r7
      008ABA FC               [12] 1992 	mov	r4,a
      008ABB EB               [12] 1993 	mov	a,r3
      008ABC 28               [12] 1994 	add	a, r0
      008ABD F5 82            [12] 1995 	mov	dpl,a
      008ABF EC               [12] 1996 	mov	a,r4
      008AC0 39               [12] 1997 	addc	a, r1
      008AC1 F5 83            [12] 1998 	mov	dph,a
      008AC3 E0               [24] 1999 	movx	a,@dptr
      008AC4 FC               [12] 2000 	mov	r4,a
      008AC5 7B 00            [12] 2001 	mov	r3,#0x00
      008AC7 E5 2E            [12] 2002 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008AC9 42 03            [12] 2003 	orl	ar3,a
                                   2004 ;	quantum/dynamic_keymap.c:498: if (kc == QK_BOOT) {
      008ACB BC 00 12         [24] 2005 	cjne	r4,#0x00,00123$
      008ACE BB 7C 0F         [24] 2006 	cjne	r3,#0x7c,00123$
                                   2007 ;	quantum/dynamic_keymap.c:499: buffer[i] = 0xFF;
      008AD1 12 38 9C         [24] 2008 	lcall	_ak820_outline_0135
      008AD4 74 FF            [12] 2009 	mov	a,#0xff
      008AD6 F0               [24] 2010 	movx	@dptr,a
                                   2011 ;	quantum/dynamic_keymap.c:500: buffer[i + 1] = 0xFF;
      008AD7 0A               [12] 2012 	inc	r2
      008AD8 BA 00 01         [24] 2013 	cjne	r2,#0x00,00218$
      008ADB 0F               [12] 2014 	inc	r7
      008ADC                       2015 00218$:
      008ADC EA               [12] 2016 	mov	a,r2
      008ADD 12 8F 22         [24] 2017 	lcall	_ak820_outline_0130
      008AE0                       2018 00123$:
                                   2019 ;	quantum/dynamic_keymap.c:496: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      008AE0 90 0B 2D         [24] 2020 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_433
      008AE3 E0               [24] 2021 	movx	a,@dptr
      008AE4 24 02            [12] 2022 	add	a,#0x02
      008AE6 F0               [24] 2023 	movx	@dptr,a
      008AE7 80 AA            [24] 2024 	sjmp	00122$
      008AE9                       2025 00120$:
                                   2026 ;	quantum/dynamic_keymap.c:511: ak820_eeprom_write_block_xdata(buffer, (void *)(uintptr_t)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset), size);
      008AE9 90 0B 29         [24] 2027 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_419
      008AEC 12 38 41         [24] 2028 	lcall	_ak820_outline_0052
      008AEF 74 40            [12] 2029 	mov	a,#0x40
      008AF1 12 43 5C         [24] 2030 	lcall	_ak820_outline_0139
      008AF4 90 05 8E         [24] 2031 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      008AF7 12 48 B1         [24] 2032 	lcall	_ak820_outline_0060
      008AFA E4               [12] 2033 	clr	a
      008AFB A3               [24] 2034 	inc	dptr
      008AFC F0               [24] 2035 	movx	@dptr,a
      008AFD 90 05 91         [24] 2036 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      008B00 E5 2F            [12] 2037 	mov	a,_dynamic_keymap_set_buffer_sloc1_1_0
      008B02 F0               [24] 2038 	movx	@dptr,a
      008B03 E5 30            [12] 2039 	mov	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      008B05 A3               [24] 2040 	inc	dptr
      008B06 F0               [24] 2041 	movx	@dptr,a
      008B07 12 38 B6         [24] 2042 	lcall	_ak820_outline_0160
                                   2043 ;	quantum/dynamic_keymap.c:521: }
      008B0A 02 41 3D         [24] 2044 	ljmp	_ak820_eeprom_write_block_xdata
                                   2045 ;------------------------------------------------------------
                                   2046 ;Allocation info for local variables in function 'keycode_at_keymap_location'
                                   2047 ;------------------------------------------------------------
                                   2048 ;row           Allocated with name '_keycode_at_keymap_location_PARM_2'
                                   2049 ;column        Allocated with name '_keycode_at_keymap_location_PARM_3'
                                   2050 ;layer_num     Allocated with name '_keycode_at_keymap_location_layer_num_10000_437'
                                   2051 ;------------------------------------------------------------
                                   2052 ;	quantum/dynamic_keymap.c:523: uint16_t keycode_at_keymap_location(uint8_t layer_num, uint8_t row, uint8_t column) {
                                   2053 ;	-----------------------------------------
                                   2054 ;	 function keycode_at_keymap_location
                                   2055 ;	-----------------------------------------
      008B0D                       2056 _keycode_at_keymap_location:
      008B0D E5 82            [12] 2057 	mov	a,dpl
      008B0F 90 0B 30         [24] 2058 	mov	dptr,#_keycode_at_keymap_location_layer_num_10000_437
      008B12 F0               [24] 2059 	movx	@dptr,a
                                   2060 ;	quantum/dynamic_keymap.c:524: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && row < MATRIX_ROWS && column < MATRIX_COLS) {
      008B13 E0               [24] 2061 	movx	a,@dptr
      008B14 FF               [12] 2062 	mov	r7,a
      008B15 BF 06 00         [24] 2063 	cjne	r7,#0x06,00128$
      008B18                       2064 00128$:
      008B18 50 23            [24] 2065 	jnc	00102$
      008B1A 90 0B 2E         [24] 2066 	mov	dptr,#_keycode_at_keymap_location_PARM_2
      008B1D E0               [24] 2067 	movx	a,@dptr
      008B1E FE               [12] 2068 	mov	r6,a
      008B1F BE 10 00         [24] 2069 	cjne	r6,#0x10,00130$
      008B22                       2070 00130$:
      008B22 50 19            [24] 2071 	jnc	00102$
      008B24 90 0B 2F         [24] 2072 	mov	dptr,#_keycode_at_keymap_location_PARM_3
      008B27 E0               [24] 2073 	movx	a,@dptr
      008B28 FD               [12] 2074 	mov	r5,a
      008B29 BD 08 00         [24] 2075 	cjne	r5,#0x08,00132$
      008B2C                       2076 00132$:
      008B2C 50 0F            [24] 2077 	jnc	00102$
                                   2078 ;	quantum/dynamic_keymap.c:525: return dynamic_keymap_get_keycode(layer_num, row, column);
      008B2E 90 0A E2         [24] 2079 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      008B31 EE               [12] 2080 	mov	a,r6
      008B32 F0               [24] 2081 	movx	@dptr,a
      008B33 90 0A E3         [24] 2082 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      008B36 ED               [12] 2083 	mov	a,r5
      008B37 F0               [24] 2084 	movx	@dptr,a
      008B38 8F 82            [24] 2085 	mov	dpl, r7
      008B3A 02 84 AD         [24] 2086 	ljmp	_dynamic_keymap_get_keycode
      008B3D                       2087 00102$:
                                   2088 ;	quantum/dynamic_keymap.c:527: return KC_NO;
      008B3D 90 00 00         [24] 2089 	mov	dptr,#0x0000
                                   2090 ;	quantum/dynamic_keymap.c:528: }
      008B40 22               [24] 2091 	ret
                                   2092 ;------------------------------------------------------------
                                   2093 ;Allocation info for local variables in function 'keycode_at_encodermap_location'
                                   2094 ;------------------------------------------------------------
                                   2095 ;encoder_idx   Allocated with name '_keycode_at_encodermap_location_PARM_2'
                                   2096 ;clockwise     Allocated with name '_keycode_at_encodermap_location_PARM_3'
                                   2097 ;layer_num     Allocated with name '_keycode_at_encodermap_location_layer_num_10000_441'
                                   2098 ;------------------------------------------------------------
                                   2099 ;	quantum/dynamic_keymap.c:531: uint16_t keycode_at_encodermap_location(uint8_t layer_num, uint8_t encoder_idx, bool clockwise) {
                                   2100 ;	-----------------------------------------
                                   2101 ;	 function keycode_at_encodermap_location
                                   2102 ;	-----------------------------------------
      008B41                       2103 _keycode_at_encodermap_location:
      008B41 E5 82            [12] 2104 	mov	a,dpl
      008B43 90 0B 33         [24] 2105 	mov	dptr,#_keycode_at_encodermap_location_layer_num_10000_441
      008B46 F0               [24] 2106 	movx	@dptr,a
                                   2107 ;	quantum/dynamic_keymap.c:532: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && encoder_idx < NUM_ENCODERS) {
      008B47 E0               [24] 2108 	movx	a,@dptr
      008B48 FF               [12] 2109 	mov	r7,a
      008B49 BF 06 00         [24] 2110 	cjne	r7,#0x06,00120$
      008B4C                       2111 00120$:
      008B4C 50 1E            [24] 2112 	jnc	00102$
      008B4E 90 0B 31         [24] 2113 	mov	dptr,#_keycode_at_encodermap_location_PARM_2
      008B51 E0               [24] 2114 	movx	a,@dptr
      008B52 FE               [12] 2115 	mov	r6,a
      008B53 BE 01 00         [24] 2116 	cjne	r6,#0x01,00122$
      008B56                       2117 00122$:
      008B56 50 14            [24] 2118 	jnc	00102$
                                   2119 ;	quantum/dynamic_keymap.c:533: return dynamic_keymap_get_encoder(layer_num, encoder_idx, clockwise);
      008B58 90 0B 32         [24] 2120 	mov	dptr,#_keycode_at_encodermap_location_PARM_3
      008B5B E0               [24] 2121 	movx	a,@dptr
      008B5C FE               [12] 2122 	mov	r6,a
      008B5D 90 0A EC         [24] 2123 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      008B60 E4               [12] 2124 	clr	a
      008B61 F0               [24] 2125 	movx	@dptr,a
      008B62 90 0A ED         [24] 2126 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      008B65 EE               [12] 2127 	mov	a,r6
      008B66 F0               [24] 2128 	movx	@dptr,a
      008B67 8F 82            [24] 2129 	mov	dpl, r7
      008B69 02 85 6C         [24] 2130 	ljmp	_dynamic_keymap_get_encoder
      008B6C                       2131 00102$:
                                   2132 ;	quantum/dynamic_keymap.c:535: return KC_NO;
      008B6C 90 00 00         [24] 2133 	mov	dptr,#0x0000
                                   2134 ;	quantum/dynamic_keymap.c:536: }
      008B6F 22               [24] 2135 	ret
                                   2136 ;------------------------------------------------------------
                                   2137 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_count'
                                   2138 ;------------------------------------------------------------
                                   2139 ;	quantum/dynamic_keymap.c:539: uint8_t dynamic_keymap_macro_get_count(void) {
                                   2140 ;	-----------------------------------------
                                   2141 ;	 function dynamic_keymap_macro_get_count
                                   2142 ;	-----------------------------------------
      008B70                       2143 _dynamic_keymap_macro_get_count:
                                   2144 ;	quantum/dynamic_keymap.c:540: return DYNAMIC_KEYMAP_MACRO_COUNT;
      008B70 75 82 10         [24] 2145 	mov	dpl, #0x10
                                   2146 ;	quantum/dynamic_keymap.c:541: }
      008B73 22               [24] 2147 	ret
                                   2148 ;------------------------------------------------------------
                                   2149 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer_size'
                                   2150 ;------------------------------------------------------------
                                   2151 ;	quantum/dynamic_keymap.c:543: uint16_t dynamic_keymap_macro_get_buffer_size(void) {
                                   2152 ;	-----------------------------------------
                                   2153 ;	 function dynamic_keymap_macro_get_buffer_size
                                   2154 ;	-----------------------------------------
      008B74                       2155 _dynamic_keymap_macro_get_buffer_size:
                                   2156 ;	quantum/dynamic_keymap.c:544: return DYNAMIC_KEYMAP_MACRO_EEPROM_SIZE;
      008B74 90 20 00         [24] 2157 	mov	dptr,#0x2000
                                   2158 ;	quantum/dynamic_keymap.c:545: }
      008B77 22               [24] 2159 	ret
                                   2160 ;------------------------------------------------------------
                                   2161 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer'
                                   2162 ;------------------------------------------------------------
                                   2163 ;sloc0         Allocated with name '_dynamic_keymap_macro_get_buffer_sloc0_1_0'
                                   2164 ;size          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_2'
                                   2165 ;data          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_3'
                                   2166 ;offset        Allocated with name '_dynamic_keymap_macro_get_buffer_offset_10000_449'
                                   2167 ;------------------------------------------------------------
                                   2168 ;	quantum/dynamic_keymap.c:547: void dynamic_keymap_macro_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2169 ;	-----------------------------------------
                                   2170 ;	 function dynamic_keymap_macro_get_buffer
                                   2171 ;	-----------------------------------------
      008B78                       2172 _dynamic_keymap_macro_get_buffer:
      008B78 12 38 88         [24] 2173 	lcall	_ak820_outline_0110
      008B7B 90 0B 39         [24] 2174 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_449
      008B7E 12 38 8D         [24] 2175 	lcall	_ak820_outline_0111
                                   2176 ;	quantum/dynamic_keymap.c:550: ak820_macro_length(), offset, size, data);
      008B81 12 2B 2B         [24] 2177 	lcall	_ak820_macro_length
      008B84 12 43 57         [24] 2178 	lcall	_ak820_outline_0136
      008B87 90 0B 39         [24] 2179 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_449
      008B8A 12 38 58         [24] 2180 	lcall	_ak820_outline_0061
      008B8D 90 0B 34         [24] 2181 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_2
      008B90 E0               [24] 2182 	movx	a,@dptr
      008B91 F5 32            [12] 2183 	mov	_dynamic_keymap_macro_get_buffer_sloc0_1_0,a
      008B93 A3               [24] 2184 	inc	dptr
      008B94 E0               [24] 2185 	movx	a,@dptr
      008B95 F5 33            [12] 2186 	mov	(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1),a
      008B97 90 0B 36         [24] 2187 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_3
      008B9A 12 38 7C         [24] 2188 	lcall	_ak820_outline_0104
      008B9D A3               [24] 2189 	inc	dptr
      008B9E E0               [24] 2190 	movx	a,@dptr
      008B9F FB               [12] 2191 	mov	r3,a
      008BA0 90 0B 11         [24] 2192 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008BA3 12 48 B1         [24] 2193 	lcall	_ak820_outline_0060
      008BA6 90 0B 13         [24] 2194 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008BA9 12 38 5E         [24] 2195 	lcall	_ak820_outline_0072
      008BAC 90 0B 15         [24] 2196 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008BAF E5 32            [12] 2197 	mov	a,_dynamic_keymap_macro_get_buffer_sloc0_1_0
      008BB1 F0               [24] 2198 	movx	@dptr,a
      008BB2 E5 33            [12] 2199 	mov	a,(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1)
      008BB4 A3               [24] 2200 	inc	dptr
      008BB5 F0               [24] 2201 	movx	@dptr,a
      008BB6 90 0B 17         [24] 2202 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008BB9 E8               [12] 2203 	mov	a,r0
      008BBA F0               [24] 2204 	movx	@dptr,a
      008BBB E9               [12] 2205 	mov	a,r1
      008BBC A3               [24] 2206 	inc	dptr
      008BBD 12 77 66         [24] 2207 	lcall	_ak820_outline_0190
      008BC0 90 08 00         [24] 2208 	mov	dptr,#0x0800
                                   2209 ;	quantum/dynamic_keymap.c:572: }
      008BC3 02 88 8B         [24] 2210 	ljmp	_ak820_dynamic_read_buffer
                                   2211 ;------------------------------------------------------------
                                   2212 ;Allocation info for local variables in function 'dynamic_keymap_macro_set_buffer'
                                   2213 ;------------------------------------------------------------
                                   2214 ;size          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_2'
                                   2215 ;data          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_3'
                                   2216 ;offset        Allocated with name '_dynamic_keymap_macro_set_buffer_offset_10000_451'
                                   2217 ;------------------------------------------------------------
                                   2218 ;	quantum/dynamic_keymap.c:575: bool dynamic_keymap_macro_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2219 ;	-----------------------------------------
                                   2220 ;	 function dynamic_keymap_macro_set_buffer
                                   2221 ;	-----------------------------------------
      008BC6                       2222 _dynamic_keymap_macro_set_buffer:
      008BC6 12 38 88         [24] 2223 	lcall	_ak820_outline_0110
      008BC9 90 0B 40         [24] 2224 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_451
      008BCC 12 38 8D         [24] 2225 	lcall	_ak820_outline_0111
                                   2226 ;	quantum/dynamic_keymap.c:576: return ak820_macro_write(offset, size, data);
      008BCF 90 0B 40         [24] 2227 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_451
      008BD2 12 38 41         [24] 2228 	lcall	_ak820_outline_0052
      008BD5 90 0B 3B         [24] 2229 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_2
      008BD8 12 38 58         [24] 2230 	lcall	_ak820_outline_0061
      008BDB 90 0B 3D         [24] 2231 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_3
      008BDE 12 4F 51         [24] 2232 	lcall	_ak820_outline_0091
      008BE1 90 05 14         [24] 2233 	mov	dptr,#_ak820_macro_write_PARM_2
      008BE4 12 38 5E         [24] 2234 	lcall	_ak820_outline_0072
      008BE7 90 05 16         [24] 2235 	mov	dptr,#_ak820_macro_write_PARM_3
      008BEA E9               [12] 2236 	mov	a,r1
      008BEB 12 4F 6A         [24] 2237 	lcall	_ak820_outline_0158
      008BEE 12 43 39         [24] 2238 	lcall	_ak820_outline_0078
                                   2239 ;	quantum/dynamic_keymap.c:577: }
      008BF1 02 2B 45         [24] 2240 	ljmp	_ak820_macro_write
                                   2241 ;------------------------------------------------------------
                                   2242 ;Allocation info for local variables in function 'dynamic_keymap_macro_reset'
                                   2243 ;------------------------------------------------------------
                                   2244 ;	quantum/dynamic_keymap.c:592: void dynamic_keymap_macro_reset(void) {
                                   2245 ;	-----------------------------------------
                                   2246 ;	 function dynamic_keymap_macro_reset
                                   2247 ;	-----------------------------------------
      008BF4                       2248 _dynamic_keymap_macro_reset:
                                   2249 ;	quantum/dynamic_keymap.c:594: ak820_macro_reset();
                                   2250 ;	quantum/dynamic_keymap.c:603: }
      008BF4 02 2E 64         [24] 2251 	ljmp	_ak820_macro_reset
                                   2252 ;------------------------------------------------------------
                                   2253 ;Allocation info for local variables in function 'decode_keycode'
                                   2254 ;------------------------------------------------------------
                                   2255 ;kc            Allocated with name '_decode_keycode_kc_10000_455'
                                   2256 ;------------------------------------------------------------
                                   2257 ;	quantum/dynamic_keymap.c:605: static uint16_t decode_keycode(uint16_t kc) {
                                   2258 ;	-----------------------------------------
                                   2259 ;	 function decode_keycode
                                   2260 ;	-----------------------------------------
      008BF7                       2261 _decode_keycode:
      008BF7 12 38 88         [24] 2262 	lcall	_ak820_outline_0110
      008BFA 90 0B 42         [24] 2263 	mov	dptr,#_decode_keycode_kc_10000_455
      008BFD 12 38 8D         [24] 2264 	lcall	_ak820_outline_0111
                                   2265 ;	quantum/dynamic_keymap.c:607: if (kc > 0xFF00)
      008C00 90 0B 42         [24] 2266 	mov	dptr,#_decode_keycode_kc_10000_455
      008C03 12 48 55         [24] 2267 	lcall	_ak820_outline_0008
      008C06 C3               [12] 2268 	clr	c
      008C07 E4               [12] 2269 	clr	a
      008C08 9C               [12] 2270 	subb	a,r4
      008C09 74 FF            [12] 2271 	mov	a,#0xff
      008C0B 9D               [12] 2272 	subb	a,r5
      008C0C 50 08            [24] 2273 	jnc	00102$
                                   2274 ;	free result
                                   2275 ;	quantum/dynamic_keymap.c:608: return (kc & 0xFF) << 8;
      008C0E 8C 05            [24] 2276 	mov	ar5,r4
      008C10 7C 00            [12] 2277 	mov	r4,#0x00
      008C12 12 38 97         [24] 2278 	lcall	_ak820_outline_0126
      008C15 22               [24] 2279 	ret
      008C16                       2280 00102$:
                                   2281 ;	quantum/dynamic_keymap.c:609: return kc;
      008C16 12 38 92         [24] 2282 	lcall	_ak820_outline_0121
                                   2283 ;	quantum/dynamic_keymap.c:610: }
      008C19 22               [24] 2284 	ret
                                   2285 ;------------------------------------------------------------
                                   2286 ;Allocation info for local variables in function 'dynamic_keymap_macro_send'
                                   2287 ;------------------------------------------------------------
                                   2288 ;id            Allocated with name '_dynamic_keymap_macro_send_id_10000_458'
                                   2289 ;sending       Allocated with name '_dynamic_keymap_macro_send_sending_10000_459'
                                   2290 ;p             Allocated with name '_dynamic_keymap_macro_send_p_10001_464'
                                   2291 ;end           Allocated with name '_dynamic_keymap_macro_send_end_10002_465'
                                   2292 ;data          Allocated with name '_dynamic_keymap_macro_send_data_10003_471'
                                   2293 ;kc            Allocated with name '_dynamic_keymap_macro_send_kc_110003_489'
                                   2294 ;d0            Allocated with name '_dynamic_keymap_macro_send_d0_80003_493'
                                   2295 ;d1            Allocated with name '_dynamic_keymap_macro_send_d1_80003_493'
                                   2296 ;ms            Allocated with name '_dynamic_keymap_macro_send_ms_80004_495'
                                   2297 ;i             Allocated with name '_dynamic_keymap_macro_send_i_100004_497'
                                   2298 ;delay         Allocated with name '_dynamic_keymap_macro_send_delay_50003_501'
                                   2299 ;i             Allocated with name '_dynamic_keymap_macro_send_i_70003_503'
                                   2300 ;------------------------------------------------------------
                                   2301 ;	quantum/dynamic_keymap.c:612: void dynamic_keymap_macro_send(uint8_t id) {
                                   2302 ;	-----------------------------------------
                                   2303 ;	 function dynamic_keymap_macro_send
                                   2304 ;	-----------------------------------------
      008C1A                       2305 _dynamic_keymap_macro_send:
      008C1A E5 82            [12] 2306 	mov	a,dpl
      008C1C 90 0B 44         [24] 2307 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_458
      008C1F F0               [24] 2308 	movx	@dptr,a
                                   2309 ;	quantum/dynamic_keymap.c:617: if (sending) return;
      008C20 90 0B 45         [24] 2310 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_459
      008C23 E0               [24] 2311 	movx	a,@dptr
      008C24 60 01            [24] 2312 	jz	00102$
      008C26 22               [24] 2313 	ret
      008C27                       2314 00102$:
                                   2315 ;	quantum/dynamic_keymap.c:619: if (id >= DYNAMIC_KEYMAP_MACRO_COUNT) {
      008C27 90 0B 44         [24] 2316 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_458
      008C2A E0               [24] 2317 	movx	a,@dptr
      008C2B FF               [12] 2318 	mov	r7,a
      008C2C BF 10 00         [24] 2319 	cjne	r7,#0x10,00422$
      008C2F                       2320 00422$:
      008C2F 40 01            [24] 2321 	jc	00104$
                                   2322 ;	quantum/dynamic_keymap.c:620: return;
      008C31 22               [24] 2323 	ret
      008C32                       2324 00104$:
                                   2325 ;	quantum/dynamic_keymap.c:626: if (!ak820_macro_ready()) return;
      008C32 C0 07            [24] 2326 	push	ar7
      008C34 12 2A F2         [24] 2327 	lcall	_ak820_macro_ready
      008C37 E5 82            [12] 2328 	mov	a, dpl
      008C39 D0 07            [24] 2329 	pop	ar7
      008C3B 70 01            [24] 2330 	jnz	00106$
      008C3D 22               [24] 2331 	ret
      008C3E                       2332 00106$:
                                   2333 ;	quantum/dynamic_keymap.c:643: p = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR;
      008C3E 90 0B 46         [24] 2334 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      008C41 E4               [12] 2335 	clr	a
      008C42 F0               [24] 2336 	movx	@dptr,a
      008C43 74 08            [12] 2337 	mov	a,#0x08
      008C45 A3               [24] 2338 	inc	dptr
      008C46 F0               [24] 2339 	movx	@dptr,a
                                   2340 ;	quantum/dynamic_keymap.c:644: uint16_t end = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR + ak820_macro_length();
      008C47 C0 07            [24] 2341 	push	ar7
      008C49 12 2B 2B         [24] 2342 	lcall	_ak820_macro_length
      008C4C AD 82            [24] 2343 	mov	r5, dpl
      008C4E AE 83            [24] 2344 	mov	r6, dph
      008C50 D0 07            [24] 2345 	pop	ar7
      008C52 74 08            [12] 2346 	mov	a,#0x08
      008C54 2E               [12] 2347 	add	a, r6
      008C55 FE               [12] 2348 	mov	r6,a
                                   2349 ;	quantum/dynamic_keymap.c:649: while (id > 0) {
      008C56 7B 00            [12] 2350 	mov	r3,#0x00
      008C58 7C 08            [12] 2351 	mov	r4,#0x08
      008C5A                       2352 00111$:
      008C5A EF               [12] 2353 	mov	a,r7
      008C5B 60 31            [24] 2354 	jz	00113$
                                   2355 ;	quantum/dynamic_keymap.c:653: if (p == end) {
      008C5D EB               [12] 2356 	mov	a,r3
      008C5E B5 05 05         [24] 2357 	cjne	a,ar5,00108$
      008C61 EC               [12] 2358 	mov	a,r4
      008C62 B5 06 01         [24] 2359 	cjne	a,ar6,00108$
                                   2360 ;	quantum/dynamic_keymap.c:654: return;
      008C65 22               [24] 2361 	ret
      008C66                       2362 00108$:
                                   2363 ;	quantum/dynamic_keymap.c:656: if (eeprom_read_byte((const uint8_t *)(uintptr_t)p) == 0) {
      008C66 8B 01            [24] 2364 	mov	ar1,r3
      008C68 8C 02            [24] 2365 	mov	ar2,r4
      008C6A 8A 00            [24] 2366 	mov	ar0,r2
      008C6C 7A 00            [12] 2367 	mov	r2,#0x00
      008C6E 89 82            [24] 2368 	mov	dpl, r1
      008C70 88 83            [24] 2369 	mov	dph, r0
      008C72 8A F0            [24] 2370 	mov	b, r2
      008C74 12 40 76         [24] 2371 	lcall	_eeprom_read_byte
      008C77 E5 82            [12] 2372 	mov	a, dpl
      008C79 70 06            [24] 2373 	jnz	00110$
                                   2374 ;	quantum/dynamic_keymap.c:657: --id;
      008C7B 1F               [12] 2375 	dec	r7
      008C7C 90 0B 44         [24] 2376 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_458
      008C7F EF               [12] 2377 	mov	a,r7
      008C80 F0               [24] 2378 	movx	@dptr,a
      008C81                       2379 00110$:
                                   2380 ;	quantum/dynamic_keymap.c:659: ++p;
      008C81 0B               [12] 2381 	inc	r3
      008C82 BB 00 01         [24] 2382 	cjne	r3,#0x00,00429$
      008C85 0C               [12] 2383 	inc	r4
      008C86                       2384 00429$:
      008C86 90 0B 46         [24] 2385 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      008C89 12 38 64         [24] 2386 	lcall	_ak820_outline_0084
      008C8C 80 CC            [24] 2387 	sjmp	00111$
      008C8E                       2388 00113$:
                                   2389 ;	quantum/dynamic_keymap.c:665: sending = true;
      008C8E 90 0B 45         [24] 2390 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_459
      008C91 74 01            [12] 2391 	mov	a,#0x01
      008C93 F0               [24] 2392 	movx	@dptr,a
                                   2393 ;	quantum/dynamic_keymap.c:667: ak820_macro_cancelled = ak820_macro_primitive = false;
      008C94 12 8F 3A         [24] 2394 	lcall	_ak820_outline_0168
      008C97 90 09 8E         [24] 2395 	mov	dptr,#_ak820_macro_cancelled
      008C9A F0               [24] 2396 	movx	@dptr,a
                                   2397 ;	quantum/dynamic_keymap.c:672: char data[4] = {0, 0, 0, 0};
      008C9B 90 0B 48         [24] 2398 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      008C9E F0               [24] 2399 	movx	@dptr,a
      008C9F 90 0B 49         [24] 2400 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0001)
      008CA2 F0               [24] 2401 	movx	@dptr,a
      008CA3 90 0B 4A         [24] 2402 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0002)
      008CA6 F0               [24] 2403 	movx	@dptr,a
      008CA7 90 0B 4B         [24] 2404 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0003)
      008CAA F0               [24] 2405 	movx	@dptr,a
                                   2406 ;	quantum/dynamic_keymap.c:675: while (p < end
      008CAB                       2407 00167$:
                                   2408 ;	quantum/dynamic_keymap.c:677: && !ak820_macro_cancelled
      008CAB 90 0B 46         [24] 2409 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      008CAE E0               [24] 2410 	movx	a,@dptr
      008CAF FC               [12] 2411 	mov	r4,a
      008CB0 A3               [24] 2412 	inc	dptr
      008CB1 E0               [24] 2413 	movx	a,@dptr
      008CB2 FF               [12] 2414 	mov	r7,a
      008CB3 C3               [12] 2415 	clr	c
      008CB4 EC               [12] 2416 	mov	a,r4
      008CB5 9D               [12] 2417 	subb	a,r5
      008CB6 EF               [12] 2418 	mov	a,r7
      008CB7 9E               [12] 2419 	subb	a,r6
      008CB8 40 03            [24] 2420 	jc	00430$
      008CBA 02 8E CF         [24] 2421 	ljmp	00169$
      008CBD                       2422 00430$:
      008CBD 90 09 8E         [24] 2423 	mov	dptr,#_ak820_macro_cancelled
      008CC0 E0               [24] 2424 	movx	a,@dptr
      008CC1 60 03            [24] 2425 	jz	00431$
      008CC3 02 8E CF         [24] 2426 	ljmp	00169$
      008CC6                       2427 00431$:
                                   2428 ;	quantum/dynamic_keymap.c:680: data[0] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008CC6 8C 02            [24] 2429 	mov	ar2,r4
      008CC8 8F 03            [24] 2430 	mov	ar3,r7
      008CCA 90 0B 46         [24] 2431 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      008CCD 74 01            [12] 2432 	mov	a,#0x01
      008CCF 2C               [12] 2433 	add	a, r4
      008CD0 F0               [24] 2434 	movx	@dptr,a
      008CD1 E4               [12] 2435 	clr	a
      008CD2 3F               [12] 2436 	addc	a, r7
      008CD3 A3               [24] 2437 	inc	dptr
      008CD4 F0               [24] 2438 	movx	@dptr,a
      008CD5 7F 00            [12] 2439 	mov	r7,#0x00
      008CD7 12 38 AC         [24] 2440 	lcall	_ak820_outline_0145
      008CDA 8F F0            [24] 2441 	mov	b, r7
      008CDC 12 40 76         [24] 2442 	lcall	_eeprom_read_byte
      008CDF AF 82            [24] 2443 	mov	r7, dpl
      008CE1 90 0B 48         [24] 2444 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      008CE4 EF               [12] 2445 	mov	a,r7
      008CE5 F0               [24] 2446 	movx	@dptr,a
                                   2447 ;	quantum/dynamic_keymap.c:681: data[1] = 0;
      008CE6 90 0B 49         [24] 2448 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0001)
      008CE9 E4               [12] 2449 	clr	a
      008CEA F0               [24] 2450 	movx	@dptr,a
                                   2451 ;	quantum/dynamic_keymap.c:683: if (data[0] == 0) {
      008CEB 90 0B 48         [24] 2452 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      008CEE E0               [24] 2453 	movx	a,@dptr
      008CEF 70 03            [24] 2454 	jnz	00432$
      008CF1 02 8E CF         [24] 2455 	ljmp	00169$
      008CF4                       2456 00432$:
                                   2457 ;	quantum/dynamic_keymap.c:686: if (data[0] == SS_QMK_PREFIX) {
      008CF4 90 0B 48         [24] 2458 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      008CF7 E0               [24] 2459 	movx	a,@dptr
      008CF8 FF               [12] 2460 	mov	r7,a
      008CF9 BF 01 02         [24] 2461 	cjne	r7,#0x01,00433$
      008CFC 80 03            [24] 2462 	sjmp	00434$
      008CFE                       2463 00433$:
      008CFE 02 8E B1         [24] 2464 	ljmp	00164$
      008D01                       2465 00434$:
                                   2466 ;	quantum/dynamic_keymap.c:689: data[1] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008D01 12 8E D7         [24] 2467 	lcall	_ak820_outline_0000
      008D04 12 40 76         [24] 2468 	lcall	_eeprom_read_byte
      008D07 AF 82            [24] 2469 	mov	r7, dpl
      008D09 90 0B 49         [24] 2470 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0001)
      008D0C EF               [12] 2471 	mov	a,r7
      008D0D F0               [24] 2472 	movx	@dptr,a
                                   2473 ;	quantum/dynamic_keymap.c:690: if (data[1] == 0)
      008D0E EF               [12] 2474 	mov	a,r7
      008D0F 70 03            [24] 2475 	jnz	00435$
      008D11 02 8E CF         [24] 2476 	ljmp	00169$
      008D14                       2477 00435$:
                                   2478 ;	quantum/dynamic_keymap.c:692: if (data[1] == SS_TAP_CODE || data[1] == SS_DOWN_CODE || data[1] == SS_UP_CODE) {
      008D14 12 8F 01         [24] 2479 	lcall	_ak820_outline_0094
      008D17 BF 01 02         [24] 2480 	cjne	r7,#0x01,00436$
      008D1A 80 13            [24] 2481 	sjmp	00151$
      008D1C                       2482 00436$:
      008D1C 12 8F 01         [24] 2483 	lcall	_ak820_outline_0094
      008D1F BF 02 02         [24] 2484 	cjne	r7,#0x02,00437$
      008D22 80 0B            [24] 2485 	sjmp	00151$
      008D24                       2486 00437$:
      008D24 12 8F 01         [24] 2487 	lcall	_ak820_outline_0094
      008D27 BF 03 02         [24] 2488 	cjne	r7,#0x03,00438$
      008D2A 80 03            [24] 2489 	sjmp	00439$
      008D2C                       2490 00438$:
      008D2C 02 8D 90         [24] 2491 	ljmp	00152$
      008D2F                       2492 00439$:
      008D2F                       2493 00151$:
                                   2494 ;	quantum/dynamic_keymap.c:694: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008D2F 12 8E D7         [24] 2495 	lcall	_ak820_outline_0000
      008D32 12 40 76         [24] 2496 	lcall	_eeprom_read_byte
      008D35 12 8F 52         [24] 2497 	lcall	_ak820_outline_0184
                                   2498 ;	quantum/dynamic_keymap.c:698: if (data[2] != 0) {
      008D38 70 03            [24] 2499 	jnz	00440$
      008D3A 02 8C AB         [24] 2500 	ljmp	00167$
      008D3D                       2501 00440$:
                                   2502 ;	quantum/dynamic_keymap.c:700: ak820_macro_primitive = data[1] != SS_TAP_CODE;
      008D3D 12 8F 01         [24] 2503 	lcall	_ak820_outline_0094
      008D40 BF 01 03         [24] 2504 	cjne	r7,#0x01,00441$
      008D43 D3               [12] 2505 	setb	c
      008D44 80 01            [24] 2506 	sjmp	00442$
      008D46                       2507 00441$:
      008D46 C3               [12] 2508 	clr	c
      008D47                       2509 00442$:
      008D47 92 27            [24] 2510 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      008D49 90 09 8D         [24] 2511 	mov	dptr,#_ak820_macro_primitive
      008D4C B3               [12] 2512 	cpl	c
      008D4D E4               [12] 2513 	clr	a
      008D4E 33               [12] 2514 	rlc	a
      008D4F F0               [24] 2515 	movx	@dptr,a
                                   2516 ;	quantum/dynamic_keymap.c:702: if (data[1] == SS_TAP_CODE) tap_code((uint8_t)data[2]);
      008D50 12 8F 01         [24] 2517 	lcall	_ak820_outline_0094
      008D53 BF 01 10         [24] 2518 	cjne	r7,#0x01,00122$
      008D56 12 8F 33         [24] 2519 	lcall	_ak820_outline_0154
      008D59 C0 06            [24] 2520 	push	ar6
      008D5B C0 05            [24] 2521 	push	ar5
      008D5D 12 76 2F         [24] 2522 	lcall	_tap_code
      008D60 D0 05            [24] 2523 	pop	ar5
      008D62 D0 06            [24] 2524 	pop	ar6
      008D64 80 24            [24] 2525 	sjmp	00123$
      008D66                       2526 00122$:
                                   2527 ;	quantum/dynamic_keymap.c:703: else if (data[1] == SS_DOWN_CODE) register_code((uint8_t)data[2]);
      008D66 12 8F 01         [24] 2528 	lcall	_ak820_outline_0094
      008D69 BF 02 10         [24] 2529 	cjne	r7,#0x02,00119$
      008D6C 12 8F 33         [24] 2530 	lcall	_ak820_outline_0154
      008D6F C0 06            [24] 2531 	push	ar6
      008D71 C0 05            [24] 2532 	push	ar5
      008D73 12 75 29         [24] 2533 	lcall	_register_code
      008D76 D0 05            [24] 2534 	pop	ar5
      008D78 D0 06            [24] 2535 	pop	ar6
      008D7A 80 0E            [24] 2536 	sjmp	00123$
      008D7C                       2537 00119$:
                                   2538 ;	quantum/dynamic_keymap.c:704: else unregister_code((uint8_t)data[2]);
      008D7C 12 8F 33         [24] 2539 	lcall	_ak820_outline_0154
      008D7F C0 06            [24] 2540 	push	ar6
      008D81 C0 05            [24] 2541 	push	ar5
      008D83 12 75 96         [24] 2542 	lcall	_unregister_code
      008D86 D0 05            [24] 2543 	pop	ar5
      008D88 D0 06            [24] 2544 	pop	ar6
      008D8A                       2545 00123$:
                                   2546 ;	quantum/dynamic_keymap.c:706: ak820_macro_primitive = false;
      008D8A 12 8F 3A         [24] 2547 	lcall	_ak820_outline_0168
      008D8D 02 8C AB         [24] 2548 	ljmp	00167$
      008D90                       2549 00152$:
                                   2550 ;	quantum/dynamic_keymap.c:714: } else if (data[1] == VIAL_MACRO_EXT_TAP || data[1] == VIAL_MACRO_EXT_DOWN || data[1] == VIAL_MACRO_EXT_UP) {
      008D90 12 8F 01         [24] 2551 	lcall	_ak820_outline_0094
      008D93 BF 05 02         [24] 2552 	cjne	r7,#0x05,00447$
      008D96 80 13            [24] 2553 	sjmp	00146$
      008D98                       2554 00447$:
      008D98 12 8F 01         [24] 2555 	lcall	_ak820_outline_0094
      008D9B BF 06 02         [24] 2556 	cjne	r7,#0x06,00448$
      008D9E 80 0B            [24] 2557 	sjmp	00146$
      008DA0                       2558 00448$:
      008DA0 12 8F 01         [24] 2559 	lcall	_ak820_outline_0094
      008DA3 BF 07 02         [24] 2560 	cjne	r7,#0x07,00449$
      008DA6 80 03            [24] 2561 	sjmp	00450$
      008DA8                       2562 00449$:
      008DA8 02 8E 51         [24] 2563 	ljmp	00147$
      008DAB                       2564 00450$:
      008DAB                       2565 00146$:
                                   2566 ;	quantum/dynamic_keymap.c:715: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008DAB 12 8E D7         [24] 2567 	lcall	_ak820_outline_0000
      008DAE 12 40 76         [24] 2568 	lcall	_eeprom_read_byte
      008DB1 12 8F 52         [24] 2569 	lcall	_ak820_outline_0184
                                   2570 ;	quantum/dynamic_keymap.c:716: if (data[2] != 0) {
      008DB4 70 03            [24] 2571 	jnz	00451$
      008DB6 02 8C AB         [24] 2572 	ljmp	00167$
      008DB9                       2573 00451$:
                                   2574 ;	quantum/dynamic_keymap.c:717: data[3] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008DB9 12 8E D7         [24] 2575 	lcall	_ak820_outline_0000
      008DBC 12 40 76         [24] 2576 	lcall	_eeprom_read_byte
      008DBF AF 82            [24] 2577 	mov	r7, dpl
      008DC1 90 0B 4B         [24] 2578 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0003)
      008DC4 EF               [12] 2579 	mov	a,r7
      008DC5 F0               [24] 2580 	movx	@dptr,a
                                   2581 ;	quantum/dynamic_keymap.c:718: if (data[3] != 0) {
      008DC6 EF               [12] 2582 	mov	a,r7
      008DC7 70 03            [24] 2583 	jnz	00452$
      008DC9 02 8C AB         [24] 2584 	ljmp	00167$
      008DCC                       2585 00452$:
                                   2586 ;	quantum/dynamic_keymap.c:721: kc = (uint8_t)data[2] | ((uint16_t)(uint8_t)data[3] << 8);
      008DCC 90 0B 4A         [24] 2587 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0002)
      008DCF E0               [24] 2588 	movx	a,@dptr
      008DD0 FF               [12] 2589 	mov	r7,a
      008DD1 90 0B 4B         [24] 2590 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0003)
      008DD4 E0               [24] 2591 	movx	a,@dptr
      008DD5 FB               [12] 2592 	mov	r3,a
      008DD6 E4               [12] 2593 	clr	a
      008DD7 FC               [12] 2594 	mov	r4,a
      008DD8 FA               [12] 2595 	mov	r2,a
      008DD9 EF               [12] 2596 	mov	a,r7
      008DDA 42 04            [12] 2597 	orl	ar4,a
      008DDC EA               [12] 2598 	mov	a,r2
      008DDD 42 03            [12] 2599 	orl	ar3,a
                                   2600 ;	quantum/dynamic_keymap.c:725: kc = decode_keycode(kc);
      008DDF 12 43 83         [24] 2601 	lcall	_ak820_outline_0187
      008DE2 C0 06            [24] 2602 	push	ar6
      008DE4 C0 05            [24] 2603 	push	ar5
      008DE6 12 8B F7         [24] 2604 	lcall	_decode_keycode
      008DE9 AC 82            [24] 2605 	mov	r4, dpl
      008DEB AF 83            [24] 2606 	mov	r7, dph
      008DED D0 05            [24] 2607 	pop	ar5
      008DEF D0 06            [24] 2608 	pop	ar6
                                   2609 ;	quantum/dynamic_keymap.c:727: ak820_macro_primitive = data[1] != VIAL_MACRO_EXT_TAP;
      008DF1 90 0B 49         [24] 2610 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0001)
      008DF4 E0               [24] 2611 	movx	a,@dptr
      008DF5 FB               [12] 2612 	mov	r3,a
      008DF6 BB 05 03         [24] 2613 	cjne	r3,#0x05,00453$
      008DF9 D3               [12] 2614 	setb	c
      008DFA 80 01            [24] 2615 	sjmp	00454$
      008DFC                       2616 00453$:
      008DFC C3               [12] 2617 	clr	c
      008DFD                       2618 00454$:
      008DFD 92 27            [24] 2619 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      008DFF 90 09 8D         [24] 2620 	mov	dptr,#_ak820_macro_primitive
      008E02 B3               [12] 2621 	cpl	c
      008E03 E4               [12] 2622 	clr	a
      008E04 33               [12] 2623 	rlc	a
      008E05 F0               [24] 2624 	movx	@dptr,a
                                   2625 ;	quantum/dynamic_keymap.c:729: switch (data[1]) {
      008E06 90 0B 49         [24] 2626 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471 + 0x0001)
      008E09 E0               [24] 2627 	movx	a,@dptr
      008E0A FB               [12] 2628 	mov	r3,a
      008E0B BB 05 02         [24] 2629 	cjne	r3,#0x05,00455$
      008E0E 80 0A            [24] 2630 	sjmp	00126$
      008E10                       2631 00455$:
      008E10 BB 06 02         [24] 2632 	cjne	r3,#0x06,00456$
      008E13 80 16            [24] 2633 	sjmp	00127$
      008E15                       2634 00456$:
                                   2635 ;	quantum/dynamic_keymap.c:730: case VIAL_MACRO_EXT_TAP:
      008E15 BB 07 33         [24] 2636 	cjne	r3,#0x07,00129$
      008E18 80 22            [24] 2637 	sjmp	00128$
      008E1A                       2638 00126$:
                                   2639 ;	quantum/dynamic_keymap.c:731: vial_keycode_tap(kc);
      008E1A 8C 82            [24] 2640 	mov	dpl, r4
      008E1C 8F 83            [24] 2641 	mov	dph, r7
      008E1E C0 06            [24] 2642 	push	ar6
      008E20 C0 05            [24] 2643 	push	ar5
      008E22 12 B3 24         [24] 2644 	lcall	_vial_keycode_tap
      008E25 D0 05            [24] 2645 	pop	ar5
      008E27 D0 06            [24] 2646 	pop	ar6
                                   2647 ;	quantum/dynamic_keymap.c:732: break;
                                   2648 ;	quantum/dynamic_keymap.c:733: case VIAL_MACRO_EXT_DOWN:
      008E29 80 20            [24] 2649 	sjmp	00129$
      008E2B                       2650 00127$:
                                   2651 ;	quantum/dynamic_keymap.c:734: vial_keycode_down(kc);
      008E2B 8C 82            [24] 2652 	mov	dpl, r4
      008E2D 8F 83            [24] 2653 	mov	dph, r7
      008E2F C0 06            [24] 2654 	push	ar6
      008E31 C0 05            [24] 2655 	push	ar5
      008E33 12 B2 59         [24] 2656 	lcall	_vial_keycode_down
      008E36 D0 05            [24] 2657 	pop	ar5
      008E38 D0 06            [24] 2658 	pop	ar6
                                   2659 ;	quantum/dynamic_keymap.c:735: break;
                                   2660 ;	quantum/dynamic_keymap.c:736: case VIAL_MACRO_EXT_UP:
      008E3A 80 0F            [24] 2661 	sjmp	00129$
      008E3C                       2662 00128$:
                                   2663 ;	quantum/dynamic_keymap.c:737: vial_keycode_up(kc);
      008E3C 8C 82            [24] 2664 	mov	dpl, r4
      008E3E 8F 83            [24] 2665 	mov	dph, r7
      008E40 C0 06            [24] 2666 	push	ar6
      008E42 C0 05            [24] 2667 	push	ar5
      008E44 12 B2 BF         [24] 2668 	lcall	_vial_keycode_up
      008E47 D0 05            [24] 2669 	pop	ar5
      008E49 D0 06            [24] 2670 	pop	ar6
                                   2671 ;	quantum/dynamic_keymap.c:739: }
      008E4B                       2672 00129$:
                                   2673 ;	quantum/dynamic_keymap.c:741: ak820_macro_primitive = false;
      008E4B 12 8F 3A         [24] 2674 	lcall	_ak820_outline_0168
      008E4E 02 8C AB         [24] 2675 	ljmp	00167$
      008E51                       2676 00147$:
                                   2677 ;	quantum/dynamic_keymap.c:745: } else if (data[1] == SS_DELAY_CODE) {
      008E51 12 8F 01         [24] 2678 	lcall	_ak820_outline_0094
      008E54 BF 04 02         [24] 2679 	cjne	r7,#0x04,00458$
      008E57 80 03            [24] 2680 	sjmp	00459$
      008E59                       2681 00458$:
      008E59 02 8C AB         [24] 2682 	ljmp	00167$
      008E5C                       2683 00459$:
                                   2684 ;	quantum/dynamic_keymap.c:747: uint8_t d0 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008E5C 12 8E D7         [24] 2685 	lcall	_ak820_outline_0000
      008E5F 12 40 76         [24] 2686 	lcall	_eeprom_read_byte
      008E62 AF 82            [24] 2687 	mov	r7, dpl
                                   2688 ;	quantum/dynamic_keymap.c:748: uint8_t d1 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008E64 90 0B 46         [24] 2689 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      008E67 12 38 82         [24] 2690 	lcall	_ak820_outline_0106
      008E6A 90 0B 46         [24] 2691 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      008E6D 74 01            [12] 2692 	mov	a,#0x01
      008E6F 2B               [12] 2693 	add	a, r3
      008E70 F0               [24] 2694 	movx	@dptr,a
      008E71 E4               [12] 2695 	clr	a
      008E72 3C               [12] 2696 	addc	a, r4
      008E73 A3               [24] 2697 	inc	dptr
      008E74 F0               [24] 2698 	movx	@dptr,a
      008E75 7A 00            [12] 2699 	mov	r2,#0x00
      008E77 12 33 FC         [24] 2700 	lcall	_ak820_outline_0125
      008E7A 8A F0            [24] 2701 	mov	b, r2
      008E7C 12 40 76         [24] 2702 	lcall	_eeprom_read_byte
      008E7F AC 82            [24] 2703 	mov	r4, dpl
                                   2704 ;	quantum/dynamic_keymap.c:749: if (d0 == 0 || d1 == 0)
      008E81 EF               [12] 2705 	mov	a,r7
      008E82 60 4B            [24] 2706 	jz	00169$
      008E84 EC               [12] 2707 	mov	a,r4
      008E85 60 48            [24] 2708 	jz	00169$
                                   2709 ;	quantum/dynamic_keymap.c:752: uint16_t ms = (uint16_t)(d0 - 1) + (uint16_t)(d1 - 1) * 255u;
      008E87 1F               [12] 2710 	dec	r7
      008E88 1C               [12] 2711 	dec	r4
      008E89 EC               [12] 2712 	mov	a,r4
      008E8A 75 F0 FF         [24] 2713 	mov	b,#0xff
      008E8D A4               [48] 2714 	mul	ab
      008E8E FC               [12] 2715 	mov	r4,a
      008E8F AB F0            [24] 2716 	mov	r3,b
      008E91 7A 00            [12] 2717 	mov	r2,#0x00
      008E93 EC               [12] 2718 	mov	a,r4
      008E94 2F               [12] 2719 	add	a, r7
      008E95 FC               [12] 2720 	mov	r4,a
      008E96 EB               [12] 2721 	mov	a,r3
      008E97 3A               [12] 2722 	addc	a, r2
      008E98 FB               [12] 2723 	mov	r3,a
                                   2724 ;	quantum/dynamic_keymap.c:753: while (ms--) wait_ms(1);
      008E99                       2725 00141$:
      008E99 8C 02            [24] 2726 	mov	ar2,r4
      008E9B 8B 07            [24] 2727 	mov	ar7,r3
      008E9D 1C               [12] 2728 	dec	r4
      008E9E BC FF 01         [24] 2729 	cjne	r4,#0xff,00462$
      008EA1 1B               [12] 2730 	dec	r3
      008EA2                       2731 00462$:
      008EA2 EA               [12] 2732 	mov	a,r2
      008EA3 4F               [12] 2733 	orl	a,r7
      008EA4 70 03            [24] 2734 	jnz	00463$
      008EA6 02 8C AB         [24] 2735 	ljmp	00167$
      008EA9                       2736 00463$:
      008EA9 90 00 01         [24] 2737 	mov	dptr,#0x0001
      008EAC 12 58 F2         [24] 2738 	lcall	_mDelaymS
      008EAF 80 E8            [24] 2739 	sjmp	00141$
      008EB1                       2740 00164$:
                                   2741 ;	quantum/dynamic_keymap.c:759: if ((uint8_t)data[0] >= 128) break;
      008EB1 90 0B 48         [24] 2742 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      008EB4 E0               [24] 2743 	movx	a,@dptr
      008EB5 FF               [12] 2744 	mov	r7,a
      008EB6 BF 80 00         [24] 2745 	cjne	r7,#0x80,00464$
      008EB9                       2746 00464$:
      008EB9 50 14            [24] 2747 	jnc	00169$
                                   2748 ;	quantum/dynamic_keymap.c:763: send_char(data[0]);
      008EBB 90 0B 48         [24] 2749 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_471
      008EBE E0               [24] 2750 	movx	a,@dptr
      008EBF F5 82            [12] 2751 	mov	dpl,a
      008EC1 C0 06            [24] 2752 	push	ar6
      008EC3 C0 05            [24] 2753 	push	ar5
      008EC5 12 A5 CB         [24] 2754 	lcall	_send_char
      008EC8 D0 05            [24] 2755 	pop	ar5
      008ECA D0 06            [24] 2756 	pop	ar6
                                   2757 ;	quantum/dynamic_keymap.c:764: for (uint8_t delay = DYNAMIC_KEYMAP_MACRO_DELAY; delay; --delay) wait_ms(1);
      008ECC 02 8C AB         [24] 2758 	ljmp	00167$
      008ECF                       2759 00169$:
                                   2760 ;	quantum/dynamic_keymap.c:772: ak820_macro_primitive = false;
      008ECF 12 8F 3A         [24] 2761 	lcall	_ak820_outline_0168
                                   2762 ;	quantum/dynamic_keymap.c:774: sending = false;
      008ED2 90 0B 45         [24] 2763 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_459
      008ED5 F0               [24] 2764 	movx	@dptr,a
                                   2765 ;	quantum/dynamic_keymap.c:776: }
      008ED6 22               [24] 2766 	ret
                                   2767 	.area CSEG    (CODE)
                                   2768 	.area CONST   (CODE)
                                   2769 	.area XINIT   (CODE)
                                   2770 	.area CABS    (ABS,CODE)
                                   2771 
                                   2772 ; Experimental exact instruction outlining.
                                   2773 	.globl _ak820_outline_0000
                                   2774 	.globl _ak820_outline_0005
                                   2775 	.globl _ak820_outline_0008
                                   2776 	.globl _ak820_outline_0013
                                   2777 	.globl _ak820_outline_0021
                                   2778 	.globl _ak820_outline_0033
                                   2779 	.globl _ak820_outline_0034
                                   2780 	.globl _ak820_outline_0050
                                   2781 	.globl _ak820_outline_0052
                                   2782 	.globl _ak820_outline_0057
                                   2783 	.globl _ak820_outline_0059
                                   2784 	.globl _ak820_outline_0060
                                   2785 	.globl _ak820_outline_0061
                                   2786 	.globl _ak820_outline_0072
                                   2787 	.globl _ak820_outline_0078
                                   2788 	.globl _ak820_outline_0080
                                   2789 	.globl _ak820_outline_0084
                                   2790 	.globl _ak820_outline_0091
                                   2791 	.globl _ak820_outline_0093
                                   2792 	.globl _ak820_outline_0094
                                   2793 	.globl _ak820_outline_0100
                                   2794 	.globl _ak820_outline_0101
                                   2795 	.globl _ak820_outline_0104
                                   2796 	.globl _ak820_outline_0105
                                   2797 	.globl _ak820_outline_0106
                                   2798 	.globl _ak820_outline_0110
                                   2799 	.globl _ak820_outline_0111
                                   2800 	.globl _ak820_outline_0114
                                   2801 	.globl _ak820_outline_0119
                                   2802 	.globl _ak820_outline_0121
                                   2803 	.globl _ak820_outline_0125
                                   2804 	.globl _ak820_outline_0126
                                   2805 	.globl _ak820_outline_0130
                                   2806 	.globl _ak820_outline_0135
                                   2807 	.globl _ak820_outline_0136
                                   2808 	.globl _ak820_outline_0137
                                   2809 	.globl _ak820_outline_0138
                                   2810 	.globl _ak820_outline_0139
                                   2811 	.globl _ak820_outline_0144
                                   2812 	.globl _ak820_outline_0145
                                   2813 	.globl _ak820_outline_0151
                                   2814 	.globl _ak820_outline_0154
                                   2815 	.globl _ak820_outline_0158
                                   2816 	.globl _ak820_outline_0160
                                   2817 	.globl _ak820_outline_0163
                                   2818 	.globl _ak820_outline_0168
                                   2819 	.globl _ak820_outline_0180
                                   2820 	.globl _ak820_outline_0181
                                   2821 	.globl _ak820_outline_0184
                                   2822 	.globl _ak820_outline_0185
                                   2823 	.globl _ak820_outline_0186
                                   2824 	.globl _ak820_outline_0187
                                   2825 	.globl _ak820_outline_0190
                                   2826 
                                   2827 	.area CSEG (CODE)
                                   2828 ; function ak820_outline_0000
      008ED7                       2829 _ak820_outline_0000:
      008ED7 90 0B 46         [24] 2830 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      008EDA E0               [24] 2831 	movx	a,@dptr
      008EDB FC               [12] 2832 	mov	r4,a
      008EDC A3               [24] 2833 	inc	dptr
      008EDD E0               [24] 2834 	movx	a,@dptr
      008EDE FF               [12] 2835 	mov	r7,a
      008EDF 90 0B 46         [24] 2836 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_464
      008EE2 74 01            [12] 2837 	mov	a,#0x01
      008EE4 2C               [12] 2838 	add	a,r4
      008EE5 F0               [24] 2839 	movx	@dptr,a
      008EE6 E4               [12] 2840 	clr	a
      008EE7 3F               [12] 2841 	addc	a,r7
      008EE8 A3               [24] 2842 	inc	dptr
      008EE9 F0               [24] 2843 	movx	@dptr,a
      008EEA 7B 00            [12] 2844 	mov	r3,#0x00
      008EEC 8C 82            [24] 2845 	mov	dpl,r4
      008EEE 8F 83            [24] 2846 	mov	dph,r7
      008EF0 8B F0            [24] 2847 	mov	b,r3
      008EF2 22               [24] 2848 	ret
                                   2849 
                                   2850 	.area CSEG (CODE)
                                   2851 ; function ak820_outline_0080
      008EF3                       2852 _ak820_outline_0080:
      008EF3 ED               [12] 2853 	mov	a,r5
      008EF4 75 F0 0A         [24] 2854 	mov	b,#0x0a
      008EF7 A4               [48] 2855 	mul	ab
      008EF8 24 58            [12] 2856 	add	a,#0x58
      008EFA FC               [12] 2857 	mov	r4,a
      008EFB 74 06            [12] 2858 	mov	a,#0x06
      008EFD 35 F0            [12] 2859 	addc	a,b
      008EFF FD               [12] 2860 	mov	r5,a
      008F00 22               [24] 2861 	ret
                                   2862 
                                   2863 	.area CSEG (CODE)
                                   2864 ; function ak820_outline_0094
      008F01                       2865 _ak820_outline_0094:
      008F01 90 0B 49         [24] 2866 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471+0x0001)
      008F04 E0               [24] 2867 	movx	a,@dptr
      008F05 FF               [12] 2868 	mov	r7,a
      008F06 22               [24] 2869 	ret
                                   2870 
                                   2871 	.area CSEG (CODE)
                                   2872 ; function ak820_outline_0100
      008F07                       2873 _ak820_outline_0100:
      008F07 90 0A DF         [24] 2874 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      008F0A EE               [12] 2875 	mov	a,r6
      008F0B F0               [24] 2876 	movx	@dptr,a
      008F0C 90 0A E0         [24] 2877 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      008F0F ED               [12] 2878 	mov	a,r5
      008F10 F0               [24] 2879 	movx	@dptr,a
      008F11 8F 82            [24] 2880 	mov	dpl,r7
      008F13 22               [24] 2881 	ret
                                   2882 
                                   2883 	.area CSEG (CODE)
                                   2884 ; function ak820_outline_0114
      008F14                       2885 _ak820_outline_0114:
      008F14 74 0A            [12] 2886 	mov	a,#0x0a
      008F16 F0               [24] 2887 	movx	@dptr,a
      008F17 E4               [12] 2888 	clr	a
      008F18 A3               [24] 2889 	inc	dptr
      008F19 F0               [24] 2890 	movx	@dptr,a
      008F1A 22               [24] 2891 	ret
                                   2892 
                                   2893 	.area CSEG (CODE)
                                   2894 ; function ak820_outline_0119
      008F1B                       2895 _ak820_outline_0119:
      008F1B AD 82            [24] 2896 	mov	r5,dpl
      008F1D AE 83            [24] 2897 	mov	r6,dph
      008F1F AF F0            [24] 2898 	mov	r7,b
      008F21 22               [24] 2899 	ret
                                   2900 
                                   2901 	.area CSEG (CODE)
                                   2902 ; function ak820_outline_0130
      008F22                       2903 _ak820_outline_0130:
      008F22 28               [12] 2904 	add	a,r0
      008F23 F5 82            [12] 2905 	mov	dpl,a
      008F25 EF               [12] 2906 	mov	a,r7
      008F26 39               [12] 2907 	addc	a,r1
      008F27 F5 83            [12] 2908 	mov	dph,a
      008F29 74 FF            [12] 2909 	mov	a,#0xff
      008F2B F0               [24] 2910 	movx	@dptr,a
      008F2C 22               [24] 2911 	ret
                                   2912 
                                   2913 	.area CSEG (CODE)
                                   2914 ; function ak820_outline_0138
      008F2D                       2915 _ak820_outline_0138:
      008F2D 2D               [12] 2916 	add	a,r5
      008F2E F9               [12] 2917 	mov	r1,a
      008F2F E4               [12] 2918 	clr	a
      008F30 3E               [12] 2919 	addc	a,r6
      008F31 FA               [12] 2920 	mov	r2,a
      008F32 22               [24] 2921 	ret
                                   2922 
                                   2923 	.area CSEG (CODE)
                                   2924 ; function ak820_outline_0154
      008F33                       2925 _ak820_outline_0154:
      008F33 90 0B 4A         [24] 2926 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471+0x0002)
      008F36 E0               [24] 2927 	movx	a,@dptr
      008F37 F5 82            [12] 2928 	mov	dpl,a
      008F39 22               [24] 2929 	ret
                                   2930 
                                   2931 	.area CSEG (CODE)
                                   2932 ; function ak820_outline_0168
      008F3A                       2933 _ak820_outline_0168:
      008F3A 90 09 8D         [24] 2934 	mov	dptr,#_ak820_macro_primitive
      008F3D E4               [12] 2935 	clr	a
      008F3E F0               [24] 2936 	movx	@dptr,a
      008F3F 22               [24] 2937 	ret
                                   2938 
                                   2939 	.area CSEG (CODE)
                                   2940 ; function ak820_outline_0180
      008F40                       2941 _ak820_outline_0180:
      008F40 90 0A EF         [24] 2942 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      008F43 E4               [12] 2943 	clr	a
      008F44 F0               [24] 2944 	movx	@dptr,a
      008F45 90 0A F0         [24] 2945 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      008F48 22               [24] 2946 	ret
                                   2947 
                                   2948 	.area CSEG (CODE)
                                   2949 ; function ak820_outline_0181
      008F49                       2950 _ak820_outline_0181:
      008F49 90 0B A5         [24] 2951 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_2
      008F4C E4               [12] 2952 	clr	a
      008F4D F0               [24] 2953 	movx	@dptr,a
      008F4E 90 0B A6         [24] 2954 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_3
      008F51 22               [24] 2955 	ret
                                   2956 
                                   2957 	.area CSEG (CODE)
                                   2958 ; function ak820_outline_0184
      008F52                       2959 _ak820_outline_0184:
      008F52 AF 82            [24] 2960 	mov	r7,dpl
      008F54 90 0B 4A         [24] 2961 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_471+0x0002)
      008F57 EF               [12] 2962 	mov	a,r7
      008F58 F0               [24] 2963 	movx	@dptr,a
      008F59 EF               [12] 2964 	mov	a,r7
      008F5A 22               [24] 2965 	ret
