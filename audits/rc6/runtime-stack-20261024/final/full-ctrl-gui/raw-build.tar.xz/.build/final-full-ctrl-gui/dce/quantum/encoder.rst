                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module encoder
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _encoder_wait_pullup_charge
                                     12 	.globl _tap_code_delay
                                     13 	.globl _ak820_action_exec
                                     14 	.globl _is_keyboard_master
                                     15 	.globl _timer_read
                                     16 	.globl _mDelayuS
                                     17 	.globl _readPin
                                     18 	.globl _pinModeInputHighQMK
                                     19 	.globl _ADC_START
                                     20 	.globl _S0_R_FIFO
                                     21 	.globl _S0_T_FIFO
                                     22 	.globl _S0_FREE
                                     23 	.globl _S0_IF_BYTE
                                     24 	.globl _S0_IF_FIRST
                                     25 	.globl _S0_IF_OV
                                     26 	.globl _S0_FST_ACT
                                     27 	.globl _CP_RL2
                                     28 	.globl _C_T2
                                     29 	.globl _TR2
                                     30 	.globl _EXEN2
                                     31 	.globl _TCLK
                                     32 	.globl _RCLK
                                     33 	.globl _EXF2
                                     34 	.globl _CAP1F
                                     35 	.globl _TF2
                                     36 	.globl _RI
                                     37 	.globl _TI
                                     38 	.globl _RB8
                                     39 	.globl _TB8
                                     40 	.globl _REN
                                     41 	.globl _SM2
                                     42 	.globl _SM1
                                     43 	.globl _SM0
                                     44 	.globl _IT0
                                     45 	.globl _IE0
                                     46 	.globl _IT1
                                     47 	.globl _IE1
                                     48 	.globl _TR0
                                     49 	.globl _TF0
                                     50 	.globl _TR1
                                     51 	.globl _TF1
                                     52 	.globl _P4_0
                                     53 	.globl _P4_1
                                     54 	.globl _P4_2
                                     55 	.globl _P4_3
                                     56 	.globl _P4_4
                                     57 	.globl _P4_5
                                     58 	.globl _P4_6
                                     59 	.globl _RXD
                                     60 	.globl _TXD
                                     61 	.globl _INT0
                                     62 	.globl _INT1
                                     63 	.globl _T0
                                     64 	.globl _T1
                                     65 	.globl _MOSI1
                                     66 	.globl _MISO1
                                     67 	.globl _SCK1
                                     68 	.globl _P3_0
                                     69 	.globl _P3_1
                                     70 	.globl _P3_2
                                     71 	.globl _P3_3
                                     72 	.globl _P3_4
                                     73 	.globl _P3_5
                                     74 	.globl _P3_6
                                     75 	.globl _P3_7
                                     76 	.globl _CAP1_
                                     77 	.globl _T2_
                                     78 	.globl _CAP2_
                                     79 	.globl _T2EX_
                                     80 	.globl _RXD1
                                     81 	.globl _TXD1
                                     82 	.globl _P2_0
                                     83 	.globl _P2_1
                                     84 	.globl _P2_2
                                     85 	.globl _P2_3
                                     86 	.globl _P2_4
                                     87 	.globl _P2_5
                                     88 	.globl _P2_6
                                     89 	.globl _P2_7
                                     90 	.globl _AIN0
                                     91 	.globl _AIN1
                                     92 	.globl _AIN2
                                     93 	.globl _AIN3
                                     94 	.globl _AIN4
                                     95 	.globl _AIN5
                                     96 	.globl _AIN6
                                     97 	.globl _AIN7
                                     98 	.globl _CAP1
                                     99 	.globl _T2
                                    100 	.globl _CAP2
                                    101 	.globl _T2EX
                                    102 	.globl _INT0_
                                    103 	.globl _SCS
                                    104 	.globl _MOSI
                                    105 	.globl _MISO
                                    106 	.globl _SCK
                                    107 	.globl _RXD1_
                                    108 	.globl _TXD1_
                                    109 	.globl _P1_0
                                    110 	.globl _P1_1
                                    111 	.globl _P1_2
                                    112 	.globl _P1_3
                                    113 	.globl _P1_4
                                    114 	.globl _P1_5
                                    115 	.globl _P1_6
                                    116 	.globl _P1_7
                                    117 	.globl _AIN8
                                    118 	.globl _AIN9
                                    119 	.globl _AIN10
                                    120 	.globl _AIN11
                                    121 	.globl _AIN12
                                    122 	.globl _AIN13
                                    123 	.globl _RXD_
                                    124 	.globl _TXD_
                                    125 	.globl _SCL0
                                    126 	.globl _SDA0
                                    127 	.globl _P0_0
                                    128 	.globl _P0_1
                                    129 	.globl _P0_2
                                    130 	.globl _P0_3
                                    131 	.globl _P0_4
                                    132 	.globl _P0_5
                                    133 	.globl _P0_6
                                    134 	.globl _P0_7
                                    135 	.globl _IE_SPI0
                                    136 	.globl _IE_USB
                                    137 	.globl _IE_ADC
                                    138 	.globl _IE_UART1
                                    139 	.globl _IE_PWM_I2C
                                    140 	.globl _IE_GPIO
                                    141 	.globl _IE_WDOG
                                    142 	.globl _PX0
                                    143 	.globl _PT0
                                    144 	.globl _PX1
                                    145 	.globl _PT1
                                    146 	.globl _PS
                                    147 	.globl _PT2
                                    148 	.globl _PL_FLAG
                                    149 	.globl _PH_FLAG
                                    150 	.globl _EX0
                                    151 	.globl _ET0
                                    152 	.globl _EX1
                                    153 	.globl _ET1
                                    154 	.globl _ES
                                    155 	.globl _ET2
                                    156 	.globl _E_DIS
                                    157 	.globl _EA
                                    158 	.globl _P
                                    159 	.globl _F1
                                    160 	.globl _OV
                                    161 	.globl _RS0
                                    162 	.globl _RS1
                                    163 	.globl _F0
                                    164 	.globl _AC
                                    165 	.globl _CY
                                    166 	.globl _I2CS_INT_ST
                                    167 	.globl _I2CX_INT
                                    168 	.globl _LED_STATUS
                                    169 	.globl _LED_DMA_H
                                    170 	.globl _LED_DMA_L
                                    171 	.globl _LED_DMA
                                    172 	.globl _LED_PWM_OE
                                    173 	.globl _LED_COMMON
                                    174 	.globl _ADC_CHAN
                                    175 	.globl _ADC_DAT_H
                                    176 	.globl _ADC_DAT_L
                                    177 	.globl _ADC_DAT
                                    178 	.globl _ADC_CTRL
                                    179 	.globl _SPI1_CK_SE
                                    180 	.globl _SPI1_CTRL
                                    181 	.globl _SPI1_DATA
                                    182 	.globl _SPI1_STAT
                                    183 	.globl _SIF1
                                    184 	.globl _SBAUD1
                                    185 	.globl _SBUF1
                                    186 	.globl _SCON1
                                    187 	.globl _SPI0_SETUP
                                    188 	.globl _SPI0_CK_SE
                                    189 	.globl _SPI0_CTRL
                                    190 	.globl _SPI0_DATA
                                    191 	.globl _SPI0_STAT
                                    192 	.globl _T2CAP1H
                                    193 	.globl _T2CAP1L
                                    194 	.globl _T2CAP1
                                    195 	.globl _TH2
                                    196 	.globl _TL2
                                    197 	.globl _T2COUNT
                                    198 	.globl _RCAP2H
                                    199 	.globl _RCAP2L
                                    200 	.globl _RCAP2
                                    201 	.globl _T2MOD
                                    202 	.globl _T2CON
                                    203 	.globl _SBUF
                                    204 	.globl _SCON
                                    205 	.globl _TH1
                                    206 	.globl _TH0
                                    207 	.globl _TL1
                                    208 	.globl _TL0
                                    209 	.globl _TMOD
                                    210 	.globl _TCON
                                    211 	.globl _XBUS_AUX
                                    212 	.globl _P7
                                    213 	.globl _P6_DIR
                                    214 	.globl _P6_OUT_PU
                                    215 	.globl _P6_IN
                                    216 	.globl _P5_DIR
                                    217 	.globl _P5_OUT_PU
                                    218 	.globl _P5_IN
                                    219 	.globl _P4_LED_KEY
                                    220 	.globl _P4_DIR_PU
                                    221 	.globl _P4_MOD_OC
                                    222 	.globl _P4
                                    223 	.globl _P3_DIR_PU
                                    224 	.globl _P3_MOD_OC
                                    225 	.globl _P3
                                    226 	.globl _P2_DIR_PU
                                    227 	.globl _P2_MOD_OC
                                    228 	.globl _P2
                                    229 	.globl _P1_DIR_PU
                                    230 	.globl _P1_MOD_OC
                                    231 	.globl _P1
                                    232 	.globl _P0_DIR_PU
                                    233 	.globl _P0_MOD_OC
                                    234 	.globl _P0
                                    235 	.globl _ROM_CTRL
                                    236 	.globl _ROM_DATA_HH
                                    237 	.globl _ROM_DATA_HL
                                    238 	.globl _ROM_DATA_HI
                                    239 	.globl _ROM_ADDR_H
                                    240 	.globl _ROM_ADDR_L
                                    241 	.globl _ROM_ADDR
                                    242 	.globl _GPIO_IE
                                    243 	.globl _IP_EX
                                    244 	.globl _IE_EX
                                    245 	.globl _IP
                                    246 	.globl _IE
                                    247 	.globl _WDOG_COUNT
                                    248 	.globl _RESET_KEEP
                                    249 	.globl _WAKE_CTRL
                                    250 	.globl _CLOCK_CFG
                                    251 	.globl _POWER_CFG
                                    252 	.globl _PCON
                                    253 	.globl _GLOBAL_CFG
                                    254 	.globl _SAFE_MOD
                                    255 	.globl _DPH
                                    256 	.globl _DPL
                                    257 	.globl _SP
                                    258 	.globl _A_INV
                                    259 	.globl _B
                                    260 	.globl _ACC
                                    261 	.globl _PSW
                                    262 	.globl _encoder_init
                                    263 	.globl _encoder_read
                                    264 ;--------------------------------------------------------
                                    265 ; special function registers
                                    266 ;--------------------------------------------------------
                                    267 	.area RSEG    (ABS,DATA)
      000000                        268 	.org 0x0000
                           0000D0   269 _PSW	=	0x00d0
                           0000E0   270 _ACC	=	0x00e0
                           0000F0   271 _B	=	0x00f0
                           0000FD   272 _A_INV	=	0x00fd
                           000081   273 _SP	=	0x0081
                           000082   274 _DPL	=	0x0082
                           000083   275 _DPH	=	0x0083
                           0000A1   276 _SAFE_MOD	=	0x00a1
                           0000B1   277 _GLOBAL_CFG	=	0x00b1
                           000087   278 _PCON	=	0x0087
                           0000BA   279 _POWER_CFG	=	0x00ba
                           0000B9   280 _CLOCK_CFG	=	0x00b9
                           0000A9   281 _WAKE_CTRL	=	0x00a9
                           0000FE   282 _RESET_KEEP	=	0x00fe
                           0000FF   283 _WDOG_COUNT	=	0x00ff
                           0000A8   284 _IE	=	0x00a8
                           0000B8   285 _IP	=	0x00b8
                           0000E8   286 _IE_EX	=	0x00e8
                           0000E9   287 _IP_EX	=	0x00e9
                           0000B2   288 _GPIO_IE	=	0x00b2
                           008584   289 _ROM_ADDR	=	0x8584
                           000084   290 _ROM_ADDR_L	=	0x0084
                           000085   291 _ROM_ADDR_H	=	0x0085
                           008F8E   292 _ROM_DATA_HI	=	0x8f8e
                           00008E   293 _ROM_DATA_HL	=	0x008e
                           00008F   294 _ROM_DATA_HH	=	0x008f
                           000086   295 _ROM_CTRL	=	0x0086
                           000080   296 _P0	=	0x0080
                           0000C4   297 _P0_MOD_OC	=	0x00c4
                           0000C5   298 _P0_DIR_PU	=	0x00c5
                           000090   299 _P1	=	0x0090
                           000092   300 _P1_MOD_OC	=	0x0092
                           000093   301 _P1_DIR_PU	=	0x0093
                           0000A0   302 _P2	=	0x00a0
                           000094   303 _P2_MOD_OC	=	0x0094
                           000095   304 _P2_DIR_PU	=	0x0095
                           0000B0   305 _P3	=	0x00b0
                           000096   306 _P3_MOD_OC	=	0x0096
                           000097   307 _P3_DIR_PU	=	0x0097
                           0000C0   308 _P4	=	0x00c0
                           0000C2   309 _P4_MOD_OC	=	0x00c2
                           0000C3   310 _P4_DIR_PU	=	0x00c3
                           0000C1   311 _P4_LED_KEY	=	0x00c1
                           0000AA   312 _P5_IN	=	0x00aa
                           0000AB   313 _P5_OUT_PU	=	0x00ab
                           0000AC   314 _P5_DIR	=	0x00ac
                           0000AD   315 _P6_IN	=	0x00ad
                           0000AE   316 _P6_OUT_PU	=	0x00ae
                           0000AF   317 _P6_DIR	=	0x00af
                           0000F1   318 _P7	=	0x00f1
                           0000A2   319 _XBUS_AUX	=	0x00a2
                           000088   320 _TCON	=	0x0088
                           000089   321 _TMOD	=	0x0089
                           00008A   322 _TL0	=	0x008a
                           00008B   323 _TL1	=	0x008b
                           00008C   324 _TH0	=	0x008c
                           00008D   325 _TH1	=	0x008d
                           000098   326 _SCON	=	0x0098
                           000099   327 _SBUF	=	0x0099
                           0000C8   328 _T2CON	=	0x00c8
                           0000C9   329 _T2MOD	=	0x00c9
                           00CBCA   330 _RCAP2	=	0xcbca
                           0000CA   331 _RCAP2L	=	0x00ca
                           0000CB   332 _RCAP2H	=	0x00cb
                           00CDCC   333 _T2COUNT	=	0xcdcc
                           0000CC   334 _TL2	=	0x00cc
                           0000CD   335 _TH2	=	0x00cd
                           00CFCE   336 _T2CAP1	=	0xcfce
                           0000CE   337 _T2CAP1L	=	0x00ce
                           0000CF   338 _T2CAP1H	=	0x00cf
                           0000F8   339 _SPI0_STAT	=	0x00f8
                           0000F9   340 _SPI0_DATA	=	0x00f9
                           0000FA   341 _SPI0_CTRL	=	0x00fa
                           0000FB   342 _SPI0_CK_SE	=	0x00fb
                           0000FC   343 _SPI0_SETUP	=	0x00fc
                           0000BC   344 _SCON1	=	0x00bc
                           0000BD   345 _SBUF1	=	0x00bd
                           0000BE   346 _SBAUD1	=	0x00be
                           0000BF   347 _SIF1	=	0x00bf
                           0000B4   348 _SPI1_STAT	=	0x00b4
                           0000B5   349 _SPI1_DATA	=	0x00b5
                           0000B6   350 _SPI1_CTRL	=	0x00b6
                           0000B7   351 _SPI1_CK_SE	=	0x00b7
                           0000F3   352 _ADC_CTRL	=	0x00f3
                           00F5F4   353 _ADC_DAT	=	0xf5f4
                           0000F4   354 _ADC_DAT_L	=	0x00f4
                           0000F5   355 _ADC_DAT_H	=	0x00f5
                           0000F6   356 _ADC_CHAN	=	0x00f6
                           0000A6   357 _LED_COMMON	=	0x00a6
                           0000A7   358 _LED_PWM_OE	=	0x00a7
                           00C7C6   359 _LED_DMA	=	0xc7c6
                           0000C6   360 _LED_DMA_L	=	0x00c6
                           0000C7   361 _LED_DMA_H	=	0x00c7
                           0000F7   362 _LED_STATUS	=	0x00f7
                           0000B3   363 _I2CX_INT	=	0x00b3
                           0000BB   364 _I2CS_INT_ST	=	0x00bb
                                    365 ;--------------------------------------------------------
                                    366 ; special function bits
                                    367 ;--------------------------------------------------------
                                    368 	.area RSEG    (ABS,DATA)
      000000                        369 	.org 0x0000
                           0000D7   370 _CY	=	0x00d7
                           0000D6   371 _AC	=	0x00d6
                           0000D5   372 _F0	=	0x00d5
                           0000D4   373 _RS1	=	0x00d4
                           0000D3   374 _RS0	=	0x00d3
                           0000D2   375 _OV	=	0x00d2
                           0000D1   376 _F1	=	0x00d1
                           0000D0   377 _P	=	0x00d0
                           0000AF   378 _EA	=	0x00af
                           0000AE   379 _E_DIS	=	0x00ae
                           0000AD   380 _ET2	=	0x00ad
                           0000AC   381 _ES	=	0x00ac
                           0000AB   382 _ET1	=	0x00ab
                           0000AA   383 _EX1	=	0x00aa
                           0000A9   384 _ET0	=	0x00a9
                           0000A8   385 _EX0	=	0x00a8
                           0000BF   386 _PH_FLAG	=	0x00bf
                           0000BE   387 _PL_FLAG	=	0x00be
                           0000BD   388 _PT2	=	0x00bd
                           0000BC   389 _PS	=	0x00bc
                           0000BB   390 _PT1	=	0x00bb
                           0000BA   391 _PX1	=	0x00ba
                           0000B9   392 _PT0	=	0x00b9
                           0000B8   393 _PX0	=	0x00b8
                           0000EF   394 _IE_WDOG	=	0x00ef
                           0000EE   395 _IE_GPIO	=	0x00ee
                           0000ED   396 _IE_PWM_I2C	=	0x00ed
                           0000EC   397 _IE_UART1	=	0x00ec
                           0000EB   398 _IE_ADC	=	0x00eb
                           0000E9   399 _IE_USB	=	0x00e9
                           0000E8   400 _IE_SPI0	=	0x00e8
                           000087   401 _P0_7	=	0x0087
                           000086   402 _P0_6	=	0x0086
                           000085   403 _P0_5	=	0x0085
                           000084   404 _P0_4	=	0x0084
                           000083   405 _P0_3	=	0x0083
                           000082   406 _P0_2	=	0x0082
                           000081   407 _P0_1	=	0x0081
                           000080   408 _P0_0	=	0x0080
                           000081   409 _SDA0	=	0x0081
                           000080   410 _SCL0	=	0x0080
                           000083   411 _TXD_	=	0x0083
                           000082   412 _RXD_	=	0x0082
                           000085   413 _AIN13	=	0x0085
                           000084   414 _AIN12	=	0x0084
                           000083   415 _AIN11	=	0x0083
                           000082   416 _AIN10	=	0x0082
                           000081   417 _AIN9	=	0x0081
                           000080   418 _AIN8	=	0x0080
                           000097   419 _P1_7	=	0x0097
                           000096   420 _P1_6	=	0x0096
                           000095   421 _P1_5	=	0x0095
                           000094   422 _P1_4	=	0x0094
                           000093   423 _P1_3	=	0x0093
                           000092   424 _P1_2	=	0x0092
                           000091   425 _P1_1	=	0x0091
                           000090   426 _P1_0	=	0x0090
                           000097   427 _TXD1_	=	0x0097
                           000096   428 _RXD1_	=	0x0096
                           000097   429 _SCK	=	0x0097
                           000096   430 _MISO	=	0x0096
                           000095   431 _MOSI	=	0x0095
                           000094   432 _SCS	=	0x0094
                           000092   433 _INT0_	=	0x0092
                           000091   434 _T2EX	=	0x0091
                           000091   435 _CAP2	=	0x0091
                           000090   436 _T2	=	0x0090
                           000090   437 _CAP1	=	0x0090
                           000097   438 _AIN7	=	0x0097
                           000096   439 _AIN6	=	0x0096
                           000095   440 _AIN5	=	0x0095
                           000094   441 _AIN4	=	0x0094
                           000093   442 _AIN3	=	0x0093
                           000092   443 _AIN2	=	0x0092
                           000091   444 _AIN1	=	0x0091
                           000090   445 _AIN0	=	0x0090
                           0000A7   446 _P2_7	=	0x00a7
                           0000A6   447 _P2_6	=	0x00a6
                           0000A5   448 _P2_5	=	0x00a5
                           0000A4   449 _P2_4	=	0x00a4
                           0000A3   450 _P2_3	=	0x00a3
                           0000A2   451 _P2_2	=	0x00a2
                           0000A1   452 _P2_1	=	0x00a1
                           0000A0   453 _P2_0	=	0x00a0
                           0000A7   454 _TXD1	=	0x00a7
                           0000A6   455 _RXD1	=	0x00a6
                           0000A5   456 _T2EX_	=	0x00a5
                           0000A5   457 _CAP2_	=	0x00a5
                           0000A4   458 _T2_	=	0x00a4
                           0000A4   459 _CAP1_	=	0x00a4
                           0000B7   460 _P3_7	=	0x00b7
                           0000B6   461 _P3_6	=	0x00b6
                           0000B5   462 _P3_5	=	0x00b5
                           0000B4   463 _P3_4	=	0x00b4
                           0000B3   464 _P3_3	=	0x00b3
                           0000B2   465 _P3_2	=	0x00b2
                           0000B1   466 _P3_1	=	0x00b1
                           0000B0   467 _P3_0	=	0x00b0
                           0000B7   468 _SCK1	=	0x00b7
                           0000B6   469 _MISO1	=	0x00b6
                           0000B5   470 _MOSI1	=	0x00b5
                           0000B5   471 _T1	=	0x00b5
                           0000B4   472 _T0	=	0x00b4
                           0000B3   473 _INT1	=	0x00b3
                           0000B2   474 _INT0	=	0x00b2
                           0000B1   475 _TXD	=	0x00b1
                           0000B0   476 _RXD	=	0x00b0
                           0000C6   477 _P4_6	=	0x00c6
                           0000C5   478 _P4_5	=	0x00c5
                           0000C4   479 _P4_4	=	0x00c4
                           0000C3   480 _P4_3	=	0x00c3
                           0000C2   481 _P4_2	=	0x00c2
                           0000C1   482 _P4_1	=	0x00c1
                           0000C0   483 _P4_0	=	0x00c0
                           00008F   484 _TF1	=	0x008f
                           00008E   485 _TR1	=	0x008e
                           00008D   486 _TF0	=	0x008d
                           00008C   487 _TR0	=	0x008c
                           00008B   488 _IE1	=	0x008b
                           00008A   489 _IT1	=	0x008a
                           000089   490 _IE0	=	0x0089
                           000088   491 _IT0	=	0x0088
                           00009F   492 _SM0	=	0x009f
                           00009E   493 _SM1	=	0x009e
                           00009D   494 _SM2	=	0x009d
                           00009C   495 _REN	=	0x009c
                           00009B   496 _TB8	=	0x009b
                           00009A   497 _RB8	=	0x009a
                           000099   498 _TI	=	0x0099
                           000098   499 _RI	=	0x0098
                           0000CF   500 _TF2	=	0x00cf
                           0000CF   501 _CAP1F	=	0x00cf
                           0000CE   502 _EXF2	=	0x00ce
                           0000CD   503 _RCLK	=	0x00cd
                           0000CC   504 _TCLK	=	0x00cc
                           0000CB   505 _EXEN2	=	0x00cb
                           0000CA   506 _TR2	=	0x00ca
                           0000C9   507 _C_T2	=	0x00c9
                           0000C8   508 _CP_RL2	=	0x00c8
                           0000FF   509 _S0_FST_ACT	=	0x00ff
                           0000FE   510 _S0_IF_OV	=	0x00fe
                           0000FD   511 _S0_IF_FIRST	=	0x00fd
                           0000FC   512 _S0_IF_BYTE	=	0x00fc
                           0000FB   513 _S0_FREE	=	0x00fb
                           0000FA   514 _S0_T_FIFO	=	0x00fa
                           0000F8   515 _S0_R_FIFO	=	0x00f8
                           0000F7   516 _ADC_START	=	0x00f7
                                    517 ;--------------------------------------------------------
                                    518 ; overlayable register banks
                                    519 ;--------------------------------------------------------
                                    520 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        521 	.ds 8
                                    522 ;--------------------------------------------------------
                                    523 ; internal ram data
                                    524 ;--------------------------------------------------------
                                    525 	.area DSEG    (DATA)
                                    526 ;--------------------------------------------------------
                                    527 ; overlayable items in internal ram
                                    528 ;--------------------------------------------------------
                                    529 ;--------------------------------------------------------
                                    530 ; indirectly addressable internal ram data
                                    531 ;--------------------------------------------------------
                                    532 	.area ISEG    (DATA)
                                    533 ;--------------------------------------------------------
                                    534 ; absolute internal ram data
                                    535 ;--------------------------------------------------------
                                    536 	.area IABS    (ABS,DATA)
                                    537 	.area IABS    (ABS,DATA)
                                    538 ;--------------------------------------------------------
                                    539 ; bit data
                                    540 ;--------------------------------------------------------
                                    541 	.area BSEG    (BIT)
                                    542 ;--------------------------------------------------------
                                    543 ; paged external ram data
                                    544 ;--------------------------------------------------------
                                    545 	.area PSEG    (PAG,XDATA)
                                    546 ;--------------------------------------------------------
                                    547 ; uninitialized external ram data
                                    548 ;--------------------------------------------------------
                                    549 	.area XSEG    (XDATA)
      000B5D                        550 _thisCount:
      000B5D                        551 	.ds 1
      000B5E                        552 _encoder_exec_mapping_PARM_2:
      000B5E                        553 	.ds 1
      000B5F                        554 _encoder_exec_mapping_index_10000_166:
      000B5F                        555 	.ds 1
      000B60                        556 _encoder_exec_mapping_dummy_event_10000_167:
      000B60                        557 	.ds 6
      000B66                        558 _encoder_update_PARM_2:
      000B66                        559 	.ds 1
      000B67                        560 _encoder_update_index_10000_168:
      000B67                        561 	.ds 1
      000B68                        562 _encoder_update_changed_10000_169:
      000B68                        563 	.ds 1
      000B69                        564 _encoder_read_changed_10000_175:
      000B69                        565 	.ds 1
                                    566 ;--------------------------------------------------------
                                    567 ; absolute external ram data
                                    568 ;--------------------------------------------------------
                                    569 	.area XABS    (ABS,XDATA)
                                    570 ;--------------------------------------------------------
                                    571 ; initialized external ram data
                                    572 ;--------------------------------------------------------
                                    573 	.area XISEG   (XDATA)
      000DF0                        574 _encoders_pad_a:
      000DF0                        575 	.ds 1
      000DF1                        576 _encoders_pad_b:
      000DF1                        577 	.ds 1
      000DF2                        578 _encoder_LUT:
      000DF2                        579 	.ds 16
      000E02                        580 _encoder_state:
      000E02                        581 	.ds 1
      000E03                        582 _encoder_pulses:
      000E03                        583 	.ds 1
      000E04                        584 _encoder_value:
      000E04                        585 	.ds 1
                                    586 	.area HOME    (CODE)
                                    587 	.area GSINIT0 (CODE)
                                    588 	.area GSINIT1 (CODE)
                                    589 	.area GSINIT2 (CODE)
                                    590 	.area GSINIT3 (CODE)
                                    591 	.area GSINIT4 (CODE)
                                    592 	.area GSINIT5 (CODE)
                                    593 	.area GSINIT  (CODE)
                                    594 	.area GSFINAL (CODE)
                                    595 	.area CSEG    (CODE)
                                    596 ;--------------------------------------------------------
                                    597 ; global & static initialisations
                                    598 ;--------------------------------------------------------
                                    599 	.area HOME    (CODE)
                                    600 	.area GSINIT  (CODE)
                                    601 	.area GSFINAL (CODE)
                                    602 	.area GSINIT  (CODE)
                                    603 ;--------------------------------------------------------
                                    604 ; Home
                                    605 ;--------------------------------------------------------
                                    606 	.area HOME    (CODE)
                                    607 	.area HOME    (CODE)
                                    608 ;--------------------------------------------------------
                                    609 ; code
                                    610 ;--------------------------------------------------------
                                    611 	.area CSEG    (CODE)
                                    612 ;------------------------------------------------------------
                                    613 ;Allocation info for local variables in function 'encoder_wait_pullup_charge'
                                    614 ;------------------------------------------------------------
                                    615 ;i             Allocated with name '_encoder_wait_pullup_charge_i_30000_147'
                                    616 ;------------------------------------------------------------
                                    617 ;	quantum/encoder.c:77: __attribute__((weak)) void encoder_wait_pullup_charge(void) {
                                    618 ;	-----------------------------------------
                                    619 ;	 function encoder_wait_pullup_charge
                                    620 ;	-----------------------------------------
      009109                        621 _encoder_wait_pullup_charge:
                           000007   622 	ar7 = 0x07
                           000006   623 	ar6 = 0x06
                           000005   624 	ar5 = 0x05
                           000004   625 	ar4 = 0x04
                           000003   626 	ar3 = 0x03
                           000002   627 	ar2 = 0x02
                           000001   628 	ar1 = 0x01
                           000000   629 	ar0 = 0x00
                                    630 ;	quantum/encoder.c:78: wait_us(100);
      009109 7F 64            [12]  631 	mov	r7,#0x64
      00910B                        632 00106$:
      00910B EF               [12]  633 	mov	a,r7
      00910C 60 09            [24]  634 	jz	00108$
      00910E 90 00 01         [24]  635 	mov	dptr,#0x0001
      009111 12 58 AE         [24]  636 	lcall	_mDelayuS
      009114 1F               [12]  637 	dec	r7
      009115 80 F4            [24]  638 	sjmp	00106$
      009117                        639 00108$:
                                    640 ;	quantum/encoder.c:79: }
      009117 22               [24]  641 	ret
                                    642 ;------------------------------------------------------------
                                    643 ;Allocation info for local variables in function 'encoder_update_user'
                                    644 ;------------------------------------------------------------
                                    645 ;clockwise     Allocated with name '_encoder_update_user_PARM_2'
                                    646 ;index         Allocated with name '_encoder_update_user_index_10000_149'
                                    647 ;------------------------------------------------------------
                                    648 ;	quantum/encoder.c:81: __attribute__((weak)) bool encoder_update_user(uint8_t index, bool clockwise) {
                                    649 ;	-----------------------------------------
                                    650 ;	 function encoder_init
                                    651 ;	-----------------------------------------
      009118                        652 _encoder_init:
                                    653 ;	quantum/encoder.c:122: thisCount                = NUM_ENCODERS;
      009118 90 0B 5D         [24]  654 	mov	dptr,#_thisCount
      00911B 74 01            [12]  655 	mov	a,#0x01
      00911D F0               [24]  656 	movx	@dptr,a
                                    657 ;	quantum/encoder.c:165: for (uint8_t i = 0; i < thisCount; i++) {
      00911E 7F 00            [12]  658 	mov	r7,#0x00
      009120                        659 00104$:
      009120 12 93 0A         [24]  660 	lcall	_ak820_outline_0090
      009123 50 17            [24]  661 	jnc	00101$
                                    662 ;	quantum/encoder.c:166: setPinInputHigh(encoders_pad_a[i]);
      009125 12 92 DE         [24]  663 	lcall	_ak820_outline_0028
      009128 C0 07            [24]  664 	push	ar7
      00912A 12 57 70         [24]  665 	lcall	_pinModeInputHighQMK
      00912D D0 07            [24]  666 	pop	ar7
                                    667 ;	quantum/encoder.c:167: setPinInputHigh(encoders_pad_b[i]);
      00912F 12 92 EC         [24]  668 	lcall	_ak820_outline_0029
      009132 C0 07            [24]  669 	push	ar7
      009134 12 57 70         [24]  670 	lcall	_pinModeInputHighQMK
      009137 D0 07            [24]  671 	pop	ar7
                                    672 ;	quantum/encoder.c:165: for (uint8_t i = 0; i < thisCount; i++) {
      009139 0F               [12]  673 	inc	r7
      00913A 80 E4            [24]  674 	sjmp	00104$
      00913C                        675 00101$:
                                    676 ;	quantum/encoder.c:169: encoder_wait_pullup_charge();
      00913C 12 91 09         [24]  677 	lcall	_encoder_wait_pullup_charge
                                    678 ;	quantum/encoder.c:170: for (uint8_t i = 0; i < thisCount; i++) {
      00913F 7F 00            [12]  679 	mov	r7,#0x00
      009141                        680 00107$:
      009141 12 93 0A         [24]  681 	lcall	_ak820_outline_0090
      009144 50 24            [24]  682 	jnc	00109$
                                    683 ;	quantum/encoder.c:171: encoder_state[i] = (readPin(encoders_pad_a[i]) << 0) | (readPin(encoders_pad_b[i]) << 1);
      009146 EF               [12]  684 	mov	a,r7
      009147 24 02            [12]  685 	add	a, #_encoder_state
      009149 FD               [12]  686 	mov	r5,a
      00914A E4               [12]  687 	clr	a
      00914B 34 0E            [12]  688 	addc	a, #(_encoder_state >> 8)
      00914D FE               [12]  689 	mov	r6,a
      00914E 12 92 DE         [24]  690 	lcall	_ak820_outline_0028
      009151 12 57 BC         [24]  691 	lcall	_readPin
      009154 AC 82            [24]  692 	mov	r4, dpl
      009156 12 92 EC         [24]  693 	lcall	_ak820_outline_0029
      009159 12 57 BC         [24]  694 	lcall	_readPin
      00915C E5 82            [12]  695 	mov	a,dpl
      00915E 25 82            [12]  696 	add	a,dpl
      009160 42 04            [12]  697 	orl	ar4,a
      009162 12 38 9C         [24]  698 	lcall	_ak820_outline_0135
      009165 EC               [12]  699 	mov	a,r4
      009166 F0               [24]  700 	movx	@dptr,a
                                    701 ;	quantum/encoder.c:170: for (uint8_t i = 0; i < thisCount; i++) {
      009167 0F               [12]  702 	inc	r7
      009168 80 D7            [24]  703 	sjmp	00107$
      00916A                        704 00109$:
                                    705 ;	quantum/encoder.c:173: }
      00916A 22               [24]  706 	ret
                                    707 ;------------------------------------------------------------
                                    708 ;Allocation info for local variables in function 'encoder_exec_mapping'
                                    709 ;------------------------------------------------------------
                                    710 ;clockwise     Allocated with name '_encoder_exec_mapping_PARM_2'
                                    711 ;index         Allocated with name '_encoder_exec_mapping_index_10000_166'
                                    712 ;dummy_event   Allocated with name '_encoder_exec_mapping_dummy_event_10000_167'
                                    713 ;------------------------------------------------------------
                                    714 ;	quantum/encoder.c:176: static void encoder_exec_mapping(uint8_t index, bool clockwise) {
                                    715 ;	-----------------------------------------
                                    716 ;	 function encoder_exec_mapping
                                    717 ;	-----------------------------------------
      00916B                        718 _encoder_exec_mapping:
      00916B E5 82            [12]  719 	mov	a,dpl
      00916D 90 0B 5F         [24]  720 	mov	dptr,#_encoder_exec_mapping_index_10000_166
      009170 F0               [24]  721 	movx	@dptr,a
                                    722 ;	quantum/encoder.c:179: MAKE_EVENT(clockwise ? KEYLOC_ENCODER_CW : KEYLOC_ENCODER_CCW, index, true,
      009171 E0               [24]  723 	movx	a,@dptr
      009172 90 0B 60         [24]  724 	mov	dptr,#_encoder_exec_mapping_dummy_event_10000_167
      009175 F0               [24]  725 	movx	@dptr,a
      009176 90 0B 5E         [24]  726 	mov	dptr,#_encoder_exec_mapping_PARM_2
      009179 E0               [24]  727 	movx	a,@dptr
      00917A FF               [12]  728 	mov	r7,a
      00917B E0               [24]  729 	movx	a,@dptr
      00917C 60 04            [24]  730 	jz	00103$
      00917E 7E FD            [12]  731 	mov	r6,#0xfd
      009180 80 02            [24]  732 	sjmp	00104$
      009182                        733 00103$:
      009182 7E FC            [12]  734 	mov	r6,#0xfc
      009184                        735 00104$:
      009184 90 0B 61         [24]  736 	mov	dptr,#(_encoder_exec_mapping_dummy_event_10000_167 + 0x0001)
      009187 EE               [12]  737 	mov	a,r6
      009188 F0               [24]  738 	movx	@dptr,a
      009189 12 49 6B         [24]  739 	lcall	_timer_read
      00918C AD 82            [24]  740 	mov	r5, dpl
      00918E AE 83            [24]  741 	mov	r6, dph
      009190 90 0B 62         [24]  742 	mov	dptr,#(_encoder_exec_mapping_dummy_event_10000_167 + 0x0002)
      009193 12 43 78         [24]  743 	lcall	_ak820_outline_0165
      009196 EF               [12]  744 	mov	a,r7
      009197 60 04            [24]  745 	jz	00105$
      009199 7F 02            [12]  746 	mov	r7,#0x02
      00919B 80 02            [24]  747 	sjmp	00106$
      00919D                        748 00105$:
      00919D 7F 03            [12]  749 	mov	r7,#0x03
      00919F                        750 00106$:
      00919F 90 0B 64         [24]  751 	mov	dptr,#(_encoder_exec_mapping_dummy_event_10000_167 + 0x0004)
      0091A2 EF               [12]  752 	mov	a,r7
      0091A3 F0               [24]  753 	movx	@dptr,a
      0091A4 90 0B 65         [24]  754 	mov	dptr,#(_encoder_exec_mapping_dummy_event_10000_167 + 0x0005)
      0091A7 74 01            [12]  755 	mov	a,#0x01
      0091A9 F0               [24]  756 	movx	@dptr,a
                                    757 ;	quantum/encoder.c:181: AK820_ACTION_EXEC(dummy_event);
      0091AA 90 0B 60         [24]  758 	mov	dptr,#_encoder_exec_mapping_dummy_event_10000_167
      0091AD 12 70 B1         [24]  759 	lcall	_ak820_action_exec
                                    760 ;	quantum/encoder.c:185: dummy_event.time = timer_read();
      0091B0 12 49 6B         [24]  761 	lcall	_timer_read
      0091B3 12 43 57         [24]  762 	lcall	_ak820_outline_0136
      0091B6 90 0B 62         [24]  763 	mov	dptr,#(_encoder_exec_mapping_dummy_event_10000_167 + 0x0002)
      0091B9 12 48 B1         [24]  764 	lcall	_ak820_outline_0060
                                    765 ;	quantum/encoder.c:186: dummy_event.pressed = false;
      0091BC 90 0B 65         [24]  766 	mov	dptr,#(_encoder_exec_mapping_dummy_event_10000_167 + 0x0005)
      0091BF E4               [12]  767 	clr	a
      0091C0 F0               [24]  768 	movx	@dptr,a
                                    769 ;	quantum/encoder.c:187: AK820_ACTION_EXEC(dummy_event);
      0091C1 90 0B 60         [24]  770 	mov	dptr,#_encoder_exec_mapping_dummy_event_10000_167
                                    771 ;	quantum/encoder.c:217: }
      0091C4 02 70 B1         [24]  772 	ljmp	_ak820_action_exec
                                    773 ;------------------------------------------------------------
                                    774 ;Allocation info for local variables in function 'encoder_update'
                                    775 ;------------------------------------------------------------
                                    776 ;state         Allocated with name '_encoder_update_PARM_2'
                                    777 ;index         Allocated with name '_encoder_update_index_10000_168'
                                    778 ;changed       Allocated with name '_encoder_update_changed_10000_169'
                                    779 ;i             Allocated with name '_encoder_update_i_10000_169'
                                    780 ;resolution    Allocated with name '_encoder_update_resolution_10000_169'
                                    781 ;------------------------------------------------------------
                                    782 ;	quantum/encoder.c:220: static bool encoder_update(uint8_t index, uint8_t state) {
                                    783 ;	-----------------------------------------
                                    784 ;	 function encoder_update
                                    785 ;	-----------------------------------------
      0091C7                        786 _encoder_update:
      0091C7 E5 82            [12]  787 	mov	a,dpl
      0091C9 90 0B 67         [24]  788 	mov	dptr,#_encoder_update_index_10000_168
      0091CC F0               [24]  789 	movx	@dptr,a
                                    790 ;	quantum/encoder.c:221: bool    changed = false;
      0091CD 90 0B 68         [24]  791 	mov	dptr,#_encoder_update_changed_10000_169
      0091D0 E4               [12]  792 	clr	a
      0091D1 F0               [24]  793 	movx	@dptr,a
                                    794 ;	quantum/encoder.c:222: uint8_t i       = index;
      0091D2 90 0B 67         [24]  795 	mov	dptr,#_encoder_update_index_10000_168
      0091D5 E0               [24]  796 	movx	a,@dptr
                                    797 ;	quantum/encoder.c:233: encoder_pulses[i] += encoder_LUT[state & 0xF];
      0091D6 FF               [12]  798 	mov	r7,a
      0091D7 24 03            [12]  799 	add	a, #_encoder_pulses
      0091D9 FD               [12]  800 	mov	r5,a
      0091DA E4               [12]  801 	clr	a
      0091DB 34 0E            [12]  802 	addc	a, #(_encoder_pulses >> 8)
      0091DD 12 48 A9         [24]  803 	lcall	_ak820_outline_0057
      0091E0 90 0B 66         [24]  804 	mov	dptr,#_encoder_update_PARM_2
      0091E3 E0               [24]  805 	movx	a,@dptr
      0091E4 FB               [12]  806 	mov	r3,a
      0091E5 74 0F            [12]  807 	mov	a,#0x0f
      0091E7 5B               [12]  808 	anl	a,r3
      0091E8 24 F2            [12]  809 	add	a, #_encoder_LUT
      0091EA F5 82            [12]  810 	mov	dpl,a
      0091EC E4               [12]  811 	clr	a
      0091ED 34 0D            [12]  812 	addc	a,#(_encoder_LUT >> 8)
      0091EF F5 83            [12]  813 	mov	dph,a
      0091F1 E0               [24]  814 	movx	a,@dptr
      0091F2 2C               [12]  815 	add	a, r4
      0091F3 FC               [12]  816 	mov	r4,a
      0091F4 12 81 C2         [24]  817 	lcall	_ak820_outline_0124
                                    818 ;	quantum/encoder.c:239: if (encoder_pulses[i] >= resolution) {
      0091F7 EC               [12]  819 	mov	a,r4
      0091F8 33               [12]  820 	rlc	a
      0091F9 95 E0            [12]  821 	subb	a,acc
      0091FB FB               [12]  822 	mov	r3,a
      0091FC C3               [12]  823 	clr	c
      0091FD EC               [12]  824 	mov	a,r4
      0091FE 94 02            [12]  825 	subb	a,#0x02
      009200 EB               [12]  826 	mov	a,r3
      009201 64 80            [12]  827 	xrl	a,#0x80
      009203 94 80            [12]  828 	subb	a,#0x80
      009205 40 1E            [24]  829 	jc	00102$
                                    830 ;	quantum/encoder.c:242: encoder_value[index]++;
      009207 EF               [12]  831 	mov	a,r7
      009208 24 04            [12]  832 	add	a, #_encoder_value
      00920A FB               [12]  833 	mov	r3,a
      00920B E4               [12]  834 	clr	a
      00920C 34 0E            [12]  835 	addc	a, #(_encoder_value >> 8)
      00920E FC               [12]  836 	mov	r4,a
      00920F 12 48 B7         [24]  837 	lcall	_ak820_outline_0065
      009212 0A               [12]  838 	inc	r2
      009213 12 92 FA         [24]  839 	lcall	_ak820_outline_0062
                                    840 ;	quantum/encoder.c:243: changed = true;
                                    841 ;	quantum/encoder.c:248: encoder_exec_mapping(index, ENCODER_COUNTER_CLOCKWISE);
      009216 E4               [12]  842 	clr	a
      009217 F0               [24]  843 	movx	@dptr,a
      009218 8F 82            [24]  844 	mov	dpl, r7
      00921A C0 06            [24]  845 	push	ar6
      00921C C0 05            [24]  846 	push	ar5
      00921E 12 91 6B         [24]  847 	lcall	_encoder_exec_mapping
      009221 D0 05            [24]  848 	pop	ar5
      009223 D0 06            [24]  849 	pop	ar6
      009225                        850 00102$:
                                    851 ;	quantum/encoder.c:257: if (encoder_pulses[i] <= -resolution) { // direction is arbitrary here, but this clockwise
      009225 12 38 9C         [24]  852 	lcall	_ak820_outline_0135
      009228 E0               [24]  853 	movx	a,@dptr
      009229 FF               [12]  854 	mov	r7,a
      00922A 33               [12]  855 	rlc	a
      00922B 95 E0            [12]  856 	subb	a,acc
      00922D FC               [12]  857 	mov	r4,a
      00922E C3               [12]  858 	clr	c
      00922F 74 FE            [12]  859 	mov	a,#0xfe
      009231 9F               [12]  860 	subb	a,r7
      009232 74 7F            [12]  861 	mov	a,#(0xff ^ 0x80)
      009234 8C F0            [24]  862 	mov	b,r4
      009236 63 F0 80         [24]  863 	xrl	b,#0x80
      009239 95 F0            [12]  864 	subb	a,b
      00923B 40 21            [24]  865 	jc	00104$
                                    866 ;	free result
                                    867 ;	quantum/encoder.c:259: encoder_value[index]--;
      00923D 90 0B 67         [24]  868 	mov	dptr,#_encoder_update_index_10000_168
      009240 E0               [24]  869 	movx	a,@dptr
      009241 FF               [12]  870 	mov	r7,a
      009242 24 04            [12]  871 	add	a, #_encoder_value
      009244 FB               [12]  872 	mov	r3,a
      009245 E4               [12]  873 	clr	a
      009246 34 0E            [12]  874 	addc	a, #(_encoder_value >> 8)
      009248 FC               [12]  875 	mov	r4,a
      009249 12 48 B7         [24]  876 	lcall	_ak820_outline_0065
      00924C 1A               [12]  877 	dec	r2
      00924D 12 92 FA         [24]  878 	lcall	_ak820_outline_0062
                                    879 ;	quantum/encoder.c:260: changed = true;
                                    880 ;	quantum/encoder.c:265: encoder_exec_mapping(index, ENCODER_CLOCKWISE);
      009250 F0               [24]  881 	movx	@dptr,a
      009251 8F 82            [24]  882 	mov	dpl, r7
      009253 C0 06            [24]  883 	push	ar6
      009255 C0 05            [24]  884 	push	ar5
      009257 12 91 6B         [24]  885 	lcall	_encoder_exec_mapping
      00925A D0 05            [24]  886 	pop	ar5
      00925C D0 06            [24]  887 	pop	ar6
      00925E                        888 00104$:
                                    889 ;	quantum/encoder.c:270: encoder_pulses[i] %= resolution;
      00925E 12 38 9C         [24]  890 	lcall	_ak820_outline_0135
      009261 E0               [24]  891 	movx	a,@dptr
      009262 A2 E7            [12]  892 	mov	c,acc.7
      009264 54 01            [12]  893 	anl	a,#0x01
      009266 60 04            [24]  894 	jz	00123$
      009268 50 02            [24]  895 	jnc	00123$
      00926A 44 FE            [12]  896 	orl	a,#0xfe
      00926C                        897 00123$:
      00926C 12 81 C2         [24]  898 	lcall	_ak820_outline_0124
                                    899 ;	quantum/encoder.c:275: return changed;
      00926F 90 0B 68         [24]  900 	mov	dptr,#_encoder_update_changed_10000_169
      009272 E0               [24]  901 	movx	a,@dptr
                                    902 ;	quantum/encoder.c:276: }
      009273 F5 82            [12]  903 	mov	dpl,a
      009275 22               [24]  904 	ret
                                    905 ;------------------------------------------------------------
                                    906 ;Allocation info for local variables in function 'encoder_read'
                                    907 ;------------------------------------------------------------
                                    908 ;changed       Allocated with name '_encoder_read_changed_10000_175'
                                    909 ;i             Allocated with name '_encoder_read_i_20000_176'
                                    910 ;new_status    Allocated with name '_encoder_read_new_status_30000_177'
                                    911 ;------------------------------------------------------------
                                    912 ;	quantum/encoder.c:278: bool encoder_read(void) {
                                    913 ;	-----------------------------------------
                                    914 ;	 function encoder_read
                                    915 ;	-----------------------------------------
      009276                        916 _encoder_read:
                                    917 ;	quantum/encoder.c:279: bool changed = false;
      009276 90 0B 69         [24]  918 	mov	dptr,#_encoder_read_changed_10000_175
      009279 E4               [12]  919 	clr	a
      00927A F0               [24]  920 	movx	@dptr,a
                                    921 ;	quantum/encoder.c:280: for (uint8_t i = 0; i < thisCount; i++) {
      00927B FF               [12]  922 	mov	r7,a
      00927C                        923 00105$:
      00927C 12 93 0A         [24]  924 	lcall	_ak820_outline_0090
      00927F 50 56            [24]  925 	jnc	00103$
                                    926 ;	quantum/encoder.c:281: uint8_t new_status = (readPin(encoders_pad_a[i]) << 0) | (readPin(encoders_pad_b[i]) << 1);
      009281 12 92 DE         [24]  927 	lcall	_ak820_outline_0028
      009284 12 57 BC         [24]  928 	lcall	_readPin
      009287 AE 82            [24]  929 	mov	r6, dpl
      009289 12 92 EC         [24]  930 	lcall	_ak820_outline_0029
      00928C 12 57 BC         [24]  931 	lcall	_readPin
      00928F E5 82            [12]  932 	mov	a,dpl
      009291 25 82            [12]  933 	add	a,dpl
      009293 42 06            [12]  934 	orl	ar6,a
                                    935 ;	quantum/encoder.c:282: if ((encoder_state[i] & 0x3) != new_status) {
      009295 EF               [12]  936 	mov	a,r7
      009296 24 02            [12]  937 	add	a, #_encoder_state
      009298 FC               [12]  938 	mov	r4,a
      009299 E4               [12]  939 	clr	a
      00929A 34 0E            [12]  940 	addc	a, #(_encoder_state >> 8)
      00929C FD               [12]  941 	mov	r5,a
      00929D 12 43 3F         [24]  942 	lcall	_ak820_outline_0096
      0092A0 FB               [12]  943 	mov	r3,a
      0092A1 FA               [12]  944 	mov	r2,a
      0092A2 53 02 03         [24]  945 	anl	ar2,#0x03
      0092A5 8E 01            [24]  946 	mov	ar1,r6
      0092A7 EA               [12]  947 	mov	a,r2
      0092A8 B5 01 02         [24]  948 	cjne	a,ar1,00132$
      0092AB 80 27            [24]  949 	sjmp	00106$
      0092AD                        950 00132$:
                                    951 ;	quantum/encoder.c:283: encoder_state[i] <<= 2;
      0092AD EB               [12]  952 	mov	a,r3
      0092AE 2B               [12]  953 	add	a,r3
      0092AF 25 E0            [12]  954 	add	a,acc
      0092B1 FB               [12]  955 	mov	r3,a
      0092B2 12 38 97         [24]  956 	lcall	_ak820_outline_0126
      0092B5 F0               [24]  957 	movx	@dptr,a
                                    958 ;	quantum/encoder.c:284: encoder_state[i] |= new_status;
      0092B6 EB               [12]  959 	mov	a,r3
      0092B7 42 06            [12]  960 	orl	ar6,a
      0092B9 12 38 97         [24]  961 	lcall	_ak820_outline_0126
      0092BC EE               [12]  962 	mov	a,r6
      0092BD F0               [24]  963 	movx	@dptr,a
                                    964 ;	quantum/encoder.c:285: changed |= encoder_update(i, encoder_state[i]);
      0092BE 90 0B 66         [24]  965 	mov	dptr,#_encoder_update_PARM_2
      0092C1 EE               [12]  966 	mov	a,r6
      0092C2 F0               [24]  967 	movx	@dptr,a
      0092C3 8F 82            [24]  968 	mov	dpl, r7
      0092C5 C0 07            [24]  969 	push	ar7
      0092C7 12 91 C7         [24]  970 	lcall	_encoder_update
      0092CA AE 82            [24]  971 	mov	r6, dpl
      0092CC D0 07            [24]  972 	pop	ar7
      0092CE 90 0B 69         [24]  973 	mov	dptr,#_encoder_read_changed_10000_175
      0092D1 E0               [24]  974 	movx	a,@dptr
      0092D2 4E               [12]  975 	orl	a,r6
      0092D3 F0               [24]  976 	movx	@dptr,a
      0092D4                        977 00106$:
                                    978 ;	quantum/encoder.c:280: for (uint8_t i = 0; i < thisCount; i++) {
      0092D4 0F               [12]  979 	inc	r7
      0092D5 80 A5            [24]  980 	sjmp	00105$
      0092D7                        981 00103$:
                                    982 ;	quantum/encoder.c:288: return changed;
      0092D7 90 0B 69         [24]  983 	mov	dptr,#_encoder_read_changed_10000_175
      0092DA E0               [24]  984 	movx	a,@dptr
                                    985 ;	quantum/encoder.c:289: }
      0092DB F5 82            [12]  986 	mov	dpl,a
      0092DD 22               [24]  987 	ret
                                    988 	.area CSEG    (CODE)
                                    989 	.area CONST   (CODE)
                                    990 	.area XINIT   (CODE)
      00C220                        991 __xinit__encoders_pad_a:
      00C220 39                     992 	.db #0x39	; 57	'9'
      00C221                        993 __xinit__encoders_pad_b:
      00C221 38                     994 	.db #0x38	; 56	'8'
      00C222                        995 __xinit__encoder_LUT:
      00C222 00                     996 	.db #0x00	;  0
      00C223 FF                     997 	.db #0xff	; -1
      00C224 01                     998 	.db #0x01	;  1
      00C225 00                     999 	.db #0x00	;  0
      00C226 01                    1000 	.db #0x01	;  1
      00C227 00                    1001 	.db #0x00	;  0
      00C228 00                    1002 	.db #0x00	;  0
      00C229 FF                    1003 	.db #0xff	; -1
      00C22A FF                    1004 	.db #0xff	; -1
      00C22B 00                    1005 	.db #0x00	;  0
      00C22C 00                    1006 	.db #0x00	;  0
      00C22D 01                    1007 	.db #0x01	;  1
      00C22E 00                    1008 	.db #0x00	;  0
      00C22F 01                    1009 	.db #0x01	;  1
      00C230 FF                    1010 	.db #0xff	; -1
      00C231 00                    1011 	.db #0x00	;  0
      00C232                       1012 __xinit__encoder_state:
      00C232 00                    1013 	.db #0x00	; 0
      00C233                       1014 __xinit__encoder_pulses:
      00C233 00                    1015 	.db #0x00	;  0
      00C234                       1016 __xinit__encoder_value:
      00C234 00                    1017 	.db #0x00	; 0
                                   1018 	.area CABS    (ABS,CODE)
                                   1019 
                                   1020 ; Experimental exact instruction outlining.
                                   1021 	.globl _ak820_outline_0028
                                   1022 	.globl _ak820_outline_0029
                                   1023 	.globl _ak820_outline_0057
                                   1024 	.globl _ak820_outline_0060
                                   1025 	.globl _ak820_outline_0062
                                   1026 	.globl _ak820_outline_0065
                                   1027 	.globl _ak820_outline_0090
                                   1028 	.globl _ak820_outline_0096
                                   1029 	.globl _ak820_outline_0124
                                   1030 	.globl _ak820_outline_0126
                                   1031 	.globl _ak820_outline_0135
                                   1032 	.globl _ak820_outline_0136
                                   1033 	.globl _ak820_outline_0165
                                   1034 
                                   1035 	.area CSEG (CODE)
                                   1036 ; function ak820_outline_0028
      0092DE                       1037 _ak820_outline_0028:
      0092DE EF               [12] 1038 	mov	a,r7
      0092DF 24 F0            [12] 1039 	add	a,#_encoders_pad_a
      0092E1 F5 82            [12] 1040 	mov	dpl,a
      0092E3 E4               [12] 1041 	clr	a
      0092E4 34 0D            [12] 1042 	addc	a,#(_encoders_pad_a>>8)
      0092E6 F5 83            [12] 1043 	mov	dph,a
      0092E8 E0               [24] 1044 	movx	a,@dptr
      0092E9 F5 82            [12] 1045 	mov	dpl,a
      0092EB 22               [24] 1046 	ret
                                   1047 
                                   1048 	.area CSEG (CODE)
                                   1049 ; function ak820_outline_0029
      0092EC                       1050 _ak820_outline_0029:
      0092EC EF               [12] 1051 	mov	a,r7
      0092ED 24 F1            [12] 1052 	add	a,#_encoders_pad_b
      0092EF F5 82            [12] 1053 	mov	dpl,a
      0092F1 E4               [12] 1054 	clr	a
      0092F2 34 0D            [12] 1055 	addc	a,#(_encoders_pad_b>>8)
      0092F4 F5 83            [12] 1056 	mov	dph,a
      0092F6 E0               [24] 1057 	movx	a,@dptr
      0092F7 F5 82            [12] 1058 	mov	dpl,a
      0092F9 22               [24] 1059 	ret
                                   1060 
                                   1061 	.area CSEG (CODE)
                                   1062 ; function ak820_outline_0062
      0092FA                       1063 _ak820_outline_0062:
      0092FA 8B 82            [24] 1064 	mov	dpl,r3
      0092FC 8C 83            [24] 1065 	mov	dph,r4
      0092FE EA               [12] 1066 	mov	a,r2
      0092FF F0               [24] 1067 	movx	@dptr,a
      009300 90 0B 68         [24] 1068 	mov	dptr,#_encoder_update_changed_10000_169
      009303 74 01            [12] 1069 	mov	a,#0x01
      009305 F0               [24] 1070 	movx	@dptr,a
      009306 90 0B 5E         [24] 1071 	mov	dptr,#_encoder_exec_mapping_PARM_2
      009309 22               [24] 1072 	ret
                                   1073 
                                   1074 	.area CSEG (CODE)
                                   1075 ; function ak820_outline_0090
      00930A                       1076 _ak820_outline_0090:
      00930A 90 0B 5D         [24] 1077 	mov	dptr,#_thisCount
      00930D E0               [24] 1078 	movx	a,@dptr
      00930E FE               [12] 1079 	mov	r6,a
      00930F C3               [12] 1080 	clr	c
      009310 EF               [12] 1081 	mov	a,r7
      009311 9E               [12] 1082 	subb	a,r6
      009312 22               [24] 1083 	ret
