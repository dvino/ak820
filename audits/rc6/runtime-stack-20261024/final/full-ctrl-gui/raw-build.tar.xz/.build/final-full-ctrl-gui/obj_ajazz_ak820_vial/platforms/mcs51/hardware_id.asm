;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (Linux)
;--------------------------------------------------------
	.module hardware_id
	
	.optsdcc -mmcs51 --model-large
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _memset
	.globl _get_hardware_id
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram
;--------------------------------------------------------
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; absolute internal ram data
;--------------------------------------------------------
	.area IABS    (ABS,DATA)
	.area IABS    (ABS,DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; uninitialized external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
_get_hardware_id_id_10000_30:
	.ds 16
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area XABS    (ABS,XDATA)
;--------------------------------------------------------
; initialized external ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area HOME    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'get_hardware_id'
;------------------------------------------------------------
;id            Allocated with name '_get_hardware_id_id_10000_30'
;------------------------------------------------------------
;	platforms/mcs51/hardware_id.c:7: hardware_id_t get_hardware_id(void) {
;	-----------------------------------------
;	 function get_hardware_id
;	-----------------------------------------
_get_hardware_id:
	ar7 = 0x07
	ar6 = 0x06
	ar5 = 0x05
	ar4 = 0x04
	ar3 = 0x03
	ar2 = 0x02
	ar1 = 0x01
	ar0 = 0x00
;	platforms/mcs51/hardware_id.c:9: memset(&id,0,sizeof(hardware_id_t));
	mov	dptr,#_memset_PARM_2
	clr	a
	movx	@dptr,a
	mov	dptr,#_memset_PARM_3
	mov	a,#0x10
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	mov	dptr,#_get_hardware_id_id_10000_30
	mov	b,a
	lcall	_memset
;	platforms/mcs51/hardware_id.c:10: return id;
	mov	dptr,#_get_hardware_id_id_10000_30
	mov	a,sp
	add	a,#0xfc
	mov	r0,a
	mov	ar7,@r0
	inc	r0
	mov	ar6,@r0
	inc	r0
	mov	b,@r0
	movx	a,@dptr
	xch	a,r7
	xch	a,dpl
	xch	a,r7
	xch	a,r6
	xch	a,dph
	xch	a,r6
	lcall	__gptrput
	inc	dptr
	xch	a,r7
	xch	a,dpl
	xch	a,r7
	xch	a,r6
	xch	a,dph
	xch	a,r6
	inc	dptr
	movx	a,@dptr
	xch	a,r7
	xch	a,dpl
	xch	a,r7
	xch	a,r6
	xch	a,dph
	xch	a,r6
	lcall	__gptrput
	inc	dptr
	xch	a,r7
	xch	a,dpl
	xch	a,r7
	xch	a,r6
	xch	a,dph
	xch	a,r6
	inc	dptr
	movx	a,@dptr
	xch	a,r7
	xch	a,dpl
	xch	a,r7
	xch	a,r6
	xch	a,dph
	xch	a,r6
	lcall	__gptrput
	inc	dptr
	xch	a,r7
	xch	a,dpl
	xch	a,r7
	xch	a,r6
	xch	a,dph
	xch	a,r6
	inc	dptr
	movx	a,@dptr
	xch	a,r7
	xch	a,dpl
	xch	a,r7
	xch	a,r6
	xch	a,dph
	xch	a,r6
	lcall	__gptrput
	inc	dptr
	xch	a,r7
	xch	a,dpl
	xch	a,r7
	xch	a,r6
	xch	a,dph
	xch	a,r6
	inc	dptr
	movx	a,@dptr
	xch	a,r7
	xch	a,dpl
	xch	a,r7
	xch	a,r6
	xch	a,dph
	xch	a,r6
	lcall	__gptrput
	inc	dptr
	xch	a,r7
	xch	a,dpl
	xch	a,r7
	xch	a,r6
	xch	a,dph
	xch	a,r6
	inc	dptr
	movx	a,@dptr
	xch	a,r7
	xch	a,dpl
	xch	a,r7
	xch	a,r6
	xch	a,dph
	xch	a,r6
	lcall	__gptrput
	inc	dptr
	xch	a,r7
	xch	a,dpl
	xch	a,r7
	xch	a,r6
	xch	a,dph
	xch	a,r6
	inc	dptr
	movx	a,@dptr
	xch	a,r7
	xch	a,dpl
	xch	a,r7
	xch	a,r6
	xch	a,dph
	xch	a,r6
	lcall	__gptrput
	inc	dptr
	xch	a,r7
	xch	a,dpl
	xch	a,r7
	xch	a,r6
	xch	a,dph
	xch	a,r6
	inc	dptr
	movx	a,@dptr
	xch	a,r7
	xch	a,dpl
	xch	a,r7
	xch	a,r6
	xch	a,dph
	xch	a,r6
	lcall	__gptrput
	inc	dptr
	xch	a,r7
	xch	a,dpl
	xch	a,r7
	xch	a,r6
	xch	a,dph
	xch	a,r6
	inc	dptr
	movx	a,@dptr
	xch	a,r7
	xch	a,dpl
	xch	a,r7
	xch	a,r6
	xch	a,dph
	xch	a,r6
	lcall	__gptrput
	inc	dptr
	xch	a,r7
	xch	a,dpl
	xch	a,r7
	xch	a,r6
	xch	a,dph
	xch	a,r6
	inc	dptr
	movx	a,@dptr
	xch	a,r7
	xch	a,dpl
	xch	a,r7
	xch	a,r6
	xch	a,dph
	xch	a,r6
	lcall	__gptrput
	inc	dptr
	xch	a,r7
	xch	a,dpl
	xch	a,r7
	xch	a,r6
	xch	a,dph
	xch	a,r6
	inc	dptr
	movx	a,@dptr
	xch	a,r7
	xch	a,dpl
	xch	a,r7
	xch	a,r6
	xch	a,dph
	xch	a,r6
	lcall	__gptrput
	inc	dptr
	xch	a,r7
	xch	a,dpl
	xch	a,r7
	xch	a,r6
	xch	a,dph
	xch	a,r6
	inc	dptr
	movx	a,@dptr
	xch	a,r7
	xch	a,dpl
	xch	a,r7
	xch	a,r6
	xch	a,dph
	xch	a,r6
	lcall	__gptrput
	inc	dptr
	xch	a,r7
	xch	a,dpl
	xch	a,r7
	xch	a,r6
	xch	a,dph
	xch	a,r6
	inc	dptr
	movx	a,@dptr
	xch	a,r7
	xch	a,dpl
	xch	a,r7
	xch	a,r6
	xch	a,dph
	xch	a,r6
	lcall	__gptrput
	inc	dptr
	xch	a,r7
	xch	a,dpl
	xch	a,r7
	xch	a,r6
	xch	a,dph
	xch	a,r6
	inc	dptr
	movx	a,@dptr
	xch	a,r7
	xch	a,dpl
	xch	a,r7
	xch	a,r6
	xch	a,dph
	xch	a,r6
	lcall	__gptrput
	inc	dptr
	xch	a,r7
	xch	a,dpl
	xch	a,r7
	xch	a,r6
	xch	a,dph
	xch	a,r6
	inc	dptr
	movx	a,@dptr
	xch	a,r7
	xch	a,dpl
	xch	a,r7
	xch	a,r6
	xch	a,dph
	xch	a,r6
	lcall	__gptrput
	inc	dptr
	xch	a,r7
	xch	a,dpl
	xch	a,r7
	xch	a,r6
	xch	a,dph
	xch	a,r6
	inc	dptr
	movx	a,@dptr
	xch	a,r7
	xch	a,dpl
	xch	a,r7
	xch	a,r6
	xch	a,dph
	xch	a,r6
;	platforms/mcs51/hardware_id.c:11: }
	ljmp	__gptrput
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
	.area CABS    (ABS,CODE)
