# Copyright 2026 QMK
# SPDX-License-Identifier: GPL-2.0-or-later

################################################################################
#
# 88888888888 888      d8b                .d888 d8b 888               d8b
#     888     888      Y8P               d88P"  Y8P 888               Y8P
#     888     888                        888        888
#     888     88888b.  888 .d8888b       888888 888 888  .d88b.       888 .d8888b
#     888     888 "88b 888 88K           888    888 888 d8P  Y8b      888 88K
#     888     888  888 888 "Y8888b.      888    888 888 88888888      888 "Y8888b.
#     888     888  888 888      X88      888    888 888 Y8b.          888      X88
#     888     888  888 888  88888P'      888    888 888  "Y8888       888  88888P'
#
#                                                       888                 888
#                                                       888                 888
#                                                       888                 888
#    .d88b.   .d88b.  88888b.   .d88b.  888d888 8888b.  888888 .d88b.   .d88888
#   d88P"88b d8P  Y8b 888 "88b d8P  Y8b 888P"      "88b 888   d8P  Y8b d88" 888
#   888  888 88888888 888  888 88888888 888    .d888888 888   88888888 888  888
#   Y88b 888 Y8b.     888  888 Y8b.     888    888  888 Y88b. Y8b.     Y88b 888
#    "Y88888  "Y8888  888  888  "Y8888  888    "Y888888  "Y888 "Y8888   "Y88888
#        888
#   Y8b d88P
#    "Y88P"
#
################################################################################

BOOTLOADER ?= ch55xbl
CAPS_WORD_ENABLE ?= yes
EEPROM_DRIVER ?= custom
ENCODER_ENABLE ?= yes
MCU ?= ch555
MOUSEKEY_ENABLE ?= yes
PLATFORM_KEY ?= mcs51
RGB_MATRIX_DRIVER ?= custom
ENCODER_ENABLE ?= yes
ENCODER_MAP_ENABLE ?= yes
EXTRAKEY_ENABLE ?= yes
MOUSEKEY_ENABLE ?= yes
NKRO_ENABLE ?= yes
CONSOLE_ENABLE ?= no
COMMAND_ENABLE ?= no
MAGIC_ENABLE ?= no
CAPS_WORD_ENABLE ?= yes
REPEAT_KEY_ENABLE ?= yes
GRAVE_ESC_ENABLE ?= yes
TRI_LAYER_ENABLE ?= yes
SPACE_CADET_ENABLE ?= no
LEADER_ENABLE ?= no
DYNAMIC_MACRO_ENABLE ?= no
TAP_DANCE_ENABLE ?= no
COMBO_ENABLE ?= no
KEY_OVERRIDE_ENABLE ?= no
AUTO_SHIFT_ENABLE ?= no
RGB_MATRIX_ENABLE ?= yes
VIALRGB_ENABLE ?= yes
