                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_nvm
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _eeprom_driver_erase
                                     12 	.globl _eeprom_read_byte
                                     13 	.globl _eeprom_driver_init
                                     14 	.globl _ak820_macro_init
                                     15 	.globl _ak820_flash_program_page
                                     16 	.globl _ak820_flash_program
                                     17 	.globl _ak820_flash_erase
                                     18 	.globl _ak820_flash_read
                                     19 	.globl _ak820_eeprom_update_block_xdata_PARM_3
                                     20 	.globl _ak820_eeprom_update_block_xdata_PARM_2
                                     21 	.globl _ak820_eeprom_write_block_xdata_PARM_3
                                     22 	.globl _ak820_eeprom_write_block_xdata_PARM_2
                                     23 	.globl _ak820_eeprom_read_block_xdata_PARM_3
                                     24 	.globl _ak820_eeprom_read_block_xdata_PARM_2
                                     25 	.globl _ak820_nvm_diagnostic
                                     26 	.globl _ak820_nvm_ok
                                     27 	.globl _ak820_nvm_schema_fault
                                     28 	.globl _ak820_nvm_flush
                                     29 	.globl _ak820_nvm_begin
                                     30 	.globl _ak820_nvm_end
                                     31 	.globl _ak820_eeprom_read_block_xdata
                                     32 	.globl _ak820_eeprom_write_block_xdata
                                     33 	.globl _ak820_eeprom_update_block_xdata
                                     34 ;--------------------------------------------------------
                                     35 ; special function registers
                                     36 ;--------------------------------------------------------
                                     37 	.area RSEG    (ABS,DATA)
      000000                         38 	.org 0x0000
                                     39 ;--------------------------------------------------------
                                     40 ; special function bits
                                     41 ;--------------------------------------------------------
                                     42 	.area RSEG    (ABS,DATA)
      000000                         43 	.org 0x0000
                                     44 ;--------------------------------------------------------
                                     45 ; overlayable register banks
                                     46 ;--------------------------------------------------------
                                     47 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         48 	.ds 8
                                     49 ;--------------------------------------------------------
                                     50 ; overlayable bit register bank
                                     51 ;--------------------------------------------------------
                                     52 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         53 bits:
      000026                         54 	.ds 1
                           008000    55 	b0 = bits[0]
                           008100    56 	b1 = bits[1]
                           008200    57 	b2 = bits[2]
                           008300    58 	b3 = bits[3]
                           008400    59 	b4 = bits[4]
                           008500    60 	b5 = bits[5]
                           008600    61 	b6 = bits[6]
                           008700    62 	b7 = bits[7]
                                     63 ;--------------------------------------------------------
                                     64 ; internal ram data
                                     65 ;--------------------------------------------------------
                                     66 	.area DSEG    (DATA)
      00000C                         67 _ak820_eeprom_write_block_xdata_sloc0_1_0:
      00000C                         68 	.ds 2
      00000E                         69 _ak820_eeprom_update_block_xdata_sloc0_1_0:
      00000E                         70 	.ds 2
      000010                         71 _ak820_eeprom_update_block_xdata_sloc1_1_0:
      000010                         72 	.ds 2
      000012                         73 _ak820_eeprom_update_block_xdata_sloc2_1_0:
      000012                         74 	.ds 3
                                     75 ;--------------------------------------------------------
                                     76 ; overlayable items in internal ram
                                     77 ;--------------------------------------------------------
                                     78 ;--------------------------------------------------------
                                     79 ; indirectly addressable internal ram data
                                     80 ;--------------------------------------------------------
                                     81 	.area ISEG    (DATA)
                                     82 ;--------------------------------------------------------
                                     83 ; absolute internal ram data
                                     84 ;--------------------------------------------------------
                                     85 	.area IABS    (ABS,DATA)
                                     86 	.area IABS    (ABS,DATA)
                                     87 ;--------------------------------------------------------
                                     88 ; bit data
                                     89 ;--------------------------------------------------------
                                     90 	.area BSEG    (BIT)
      000009                         91 _page_valid:
      000009                         92 	.ds 1
      00000A                         93 _page_dirty:
      00000A                         94 	.ds 1
      00000B                         95 _storage_failed:
      00000B                         96 	.ds 1
      00000C                         97 _ak820_nvm_ok_sloc0_1_0:
      00000C                         98 	.ds 1
      00000D                         99 _load_page_sloc0_1_0:
      00000D                        100 	.ds 1
                                    101 ;--------------------------------------------------------
                                    102 ; paged external ram data
                                    103 ;--------------------------------------------------------
                                    104 	.area PSEG    (PAG,XDATA)
                                    105 ;--------------------------------------------------------
                                    106 ; uninitialized external ram data
                                    107 ;--------------------------------------------------------
                                    108 	.area XSEG    (XDATA)
      00051D                        109 _page_data:
      00051D                        110 	.ds 64
      00055D                        111 _cached_page:
      00055D                        112 	.ds 1
      00055E                        113 _batch_depth:
      00055E                        114 	.ds 1
      00055F                        115 _first_failure_stage:
      00055F                        116 	.ds 1
      000560                        117 _nvm_fail_stage_10000_20:
      000560                        118 	.ds 1
      000561                        119 _ak820_nvm_diagnostic_out_10000_23:
      000561                        120 	.ds 2
      000563                        121 _crc_byte_PARM_2:
      000563                        122 	.ds 1
      000564                        123 _crc_byte_crc_10000_25:
      000564                        124 	.ds 2
      000566                        125 _page_crc_crc_10000_30:
      000566                        126 	.ds 2
      000568                        127 _write_page_address_10000_32:
      000568                        128 	.ds 2
      00056A                        129 _journal_header_valid_header_10000_39:
      00056A                        130 	.ds 2
      00056C                        131 _recover_journal_header_10000_46:
      00056C                        132 	.ds 9
      000575                        133 _ak820_nvm_flush_header_10000_62:
      000575                        134 	.ds 9
      00057E                        135 _ak820_nvm_flush_stage_10000_62:
      00057E                        136 	.ds 1
      00057F                        137 _load_page_page_10000_87:
      00057F                        138 	.ds 1
      000580                        139 _read_offset_offset_10000_93:
      000580                        140 	.ds 2
      000582                        141 _eeprom_read_byte_addr_10000_97:
      000582                        142 	.ds 3
      000585                        143 _ak820_eeprom_read_block_xdata_PARM_2:
      000585                        144 	.ds 3
      000588                        145 _ak820_eeprom_read_block_xdata_PARM_3:
      000588                        146 	.ds 2
      00058A                        147 _ak820_eeprom_read_block_xdata_buf_10000_113:
      00058A                        148 	.ds 2
      00058C                        149 _ak820_eeprom_read_block_xdata_out_10000_114:
      00058C                        150 	.ds 2
      00058E                        151 _ak820_eeprom_write_block_xdata_PARM_2:
      00058E                        152 	.ds 3
      000591                        153 _ak820_eeprom_write_block_xdata_PARM_3:
      000591                        154 	.ds 2
      000593                        155 _ak820_eeprom_write_block_xdata_buf_10000_118:
      000593                        156 	.ds 2
      000595                        157 _ak820_eeprom_update_block_xdata_PARM_2:
      000595                        158 	.ds 3
      000598                        159 _ak820_eeprom_update_block_xdata_PARM_3:
      000598                        160 	.ds 2
      00059A                        161 _ak820_eeprom_update_block_xdata_buf_10000_127:
      00059A                        162 	.ds 2
                                    163 ;--------------------------------------------------------
                                    164 ; absolute external ram data
                                    165 ;--------------------------------------------------------
                                    166 	.area XABS    (ABS,XDATA)
                                    167 ;--------------------------------------------------------
                                    168 ; initialized external ram data
                                    169 ;--------------------------------------------------------
                                    170 	.area XISEG   (XDATA)
                                    171 	.area HOME    (CODE)
                                    172 	.area GSINIT0 (CODE)
                                    173 	.area GSINIT1 (CODE)
                                    174 	.area GSINIT2 (CODE)
                                    175 	.area GSINIT3 (CODE)
                                    176 	.area GSINIT4 (CODE)
                                    177 	.area GSINIT5 (CODE)
                                    178 	.area GSINIT  (CODE)
                                    179 	.area GSFINAL (CODE)
                                    180 	.area CSEG    (CODE)
                                    181 ;--------------------------------------------------------
                                    182 ; global & static initialisations
                                    183 ;--------------------------------------------------------
                                    184 	.area HOME    (CODE)
                                    185 	.area GSINIT  (CODE)
                                    186 	.area GSFINAL (CODE)
                                    187 	.area GSINIT  (CODE)
                                    188 ;--------------------------------------------------------
                                    189 ; Home
                                    190 ;--------------------------------------------------------
                                    191 	.area HOME    (CODE)
                                    192 	.area HOME    (CODE)
                                    193 ;--------------------------------------------------------
                                    194 ; code
                                    195 ;--------------------------------------------------------
                                    196 	.area CSEG    (CODE)
                                    197 ;------------------------------------------------------------
                                    198 ;Allocation info for local variables in function 'nvm_fail'
                                    199 ;------------------------------------------------------------
                                    200 ;stage         Allocated with name '_nvm_fail_stage_10000_20'
                                    201 ;------------------------------------------------------------
                                    202 ;	keyboards/ajazz/ak820/ak820_nvm.c:31: static void nvm_fail(uint8_t stage) {
                                    203 ;	-----------------------------------------
                                    204 ;	 function nvm_fail
                                    205 ;	-----------------------------------------
      003B83                        206 _nvm_fail:
                           000007   207 	ar7 = 0x07
                           000006   208 	ar6 = 0x06
                           000005   209 	ar5 = 0x05
                           000004   210 	ar4 = 0x04
                           000003   211 	ar3 = 0x03
                           000002   212 	ar2 = 0x02
                           000001   213 	ar1 = 0x01
                           000000   214 	ar0 = 0x00
      003B83 E5 82            [12]  215 	mov	a,dpl
      003B85 90 05 60         [24]  216 	mov	dptr,#_nvm_fail_stage_10000_20
      003B88 F0               [24]  217 	movx	@dptr,a
                                    218 ;	keyboards/ajazz/ak820/ak820_nvm.c:32: if (!storage_failed) first_failure_stage = stage;
      003B89 20 0B 08         [24]  219 	jb	_storage_failed,00102$
      003B8C 90 05 60         [24]  220 	mov	dptr,#_nvm_fail_stage_10000_20
      003B8F E0               [24]  221 	movx	a,@dptr
      003B90 90 05 5F         [24]  222 	mov	dptr,#_first_failure_stage
      003B93 F0               [24]  223 	movx	@dptr,a
      003B94                        224 00102$:
                                    225 ;	keyboards/ajazz/ak820/ak820_nvm.c:33: storage_failed = true;
                                    226 ;	assignBit
      003B94 D2 0B            [12]  227 	setb	_storage_failed
                                    228 ;	keyboards/ajazz/ak820/ak820_nvm.c:34: }
      003B96 22               [24]  229 	ret
                                    230 ;------------------------------------------------------------
                                    231 ;Allocation info for local variables in function 'ak820_nvm_diagnostic'
                                    232 ;------------------------------------------------------------
                                    233 ;out           Allocated with name '_ak820_nvm_diagnostic_out_10000_23'
                                    234 ;------------------------------------------------------------
                                    235 ;	keyboards/ajazz/ak820/ak820_nvm.c:36: void ak820_nvm_diagnostic(uint8_t AK820_XDATA *out) {
                                    236 ;	-----------------------------------------
                                    237 ;	 function ak820_nvm_diagnostic
                                    238 ;	-----------------------------------------
      003B97                        239 _ak820_nvm_diagnostic:
      003B97 12 38 88         [24]  240 	lcall	_ak820_outline_0110
      003B9A 90 05 61         [24]  241 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003B9D 12 38 8D         [24]  242 	lcall	_ak820_outline_0111
                                    243 ;	keyboards/ajazz/ak820/ak820_nvm.c:37: out[0] = storage_failed;
      003BA0 90 05 61         [24]  244 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003BA3 12 38 41         [24]  245 	lcall	_ak820_outline_0052
      003BA6 A2 0B            [12]  246 	mov	c,_storage_failed
      003BA8 E4               [12]  247 	clr	a
      003BA9 33               [12]  248 	rlc	a
      003BAA 12 38 92         [24]  249 	lcall	_ak820_outline_0121
      003BAD 12 43 39         [24]  250 	lcall	_ak820_outline_0078
                                    251 ;	keyboards/ajazz/ak820/ak820_nvm.c:38: out[1] = page_valid;
      003BB0 A3               [24]  252 	inc	dptr
      003BB1 A2 09            [12]  253 	mov	c,_page_valid
      003BB3 E4               [12]  254 	clr	a
      003BB4 33               [12]  255 	rlc	a
      003BB5 12 43 0D         [24]  256 	lcall	_ak820_outline_0031
                                    257 ;	keyboards/ajazz/ak820/ak820_nvm.c:39: out[2] = page_dirty;
      003BB8 A2 0A            [12]  258 	mov	c,_page_dirty
      003BBA E4               [12]  259 	clr	a
      003BBB 33               [12]  260 	rlc	a
      003BBC F0               [24]  261 	movx	@dptr,a
                                    262 ;	keyboards/ajazz/ak820/ak820_nvm.c:40: out[3] = batch_depth;
      003BBD 74 03            [12]  263 	mov	a,#0x03
      003BBF 12 43 72         [24]  264 	lcall	_ak820_outline_0164
      003BC2 90 05 5E         [24]  265 	mov	dptr,#_batch_depth
      003BC5 E0               [24]  266 	movx	a,@dptr
      003BC6 12 38 97         [24]  267 	lcall	_ak820_outline_0126
      003BC9 F0               [24]  268 	movx	@dptr,a
                                    269 ;	keyboards/ajazz/ak820/ak820_nvm.c:41: out[4] = (uint8_t)cached_page;
      003BCA 74 04            [12]  270 	mov	a,#0x04
      003BCC 12 43 72         [24]  271 	lcall	_ak820_outline_0164
      003BCF 90 05 5D         [24]  272 	mov	dptr,#_cached_page
      003BD2 E0               [24]  273 	movx	a,@dptr
      003BD3 12 38 97         [24]  274 	lcall	_ak820_outline_0126
      003BD6 F0               [24]  275 	movx	@dptr,a
                                    276 ;	keyboards/ajazz/ak820/ak820_nvm.c:42: out[5] = (uint8_t)(cached_page >> 8);
      003BD7 12 43 03         [24]  277 	lcall	_ak820_outline_0011
      003BDA E4               [12]  278 	clr	a
      003BDB F0               [24]  279 	movx	@dptr,a
                                    280 ;	keyboards/ajazz/ak820/ak820_nvm.c:43: out[6] = first_failure_stage;
      003BDC 74 06            [12]  281 	mov	a,#0x06
      003BDE 12 43 5C         [24]  282 	lcall	_ak820_outline_0139
      003BE1 90 05 5F         [24]  283 	mov	dptr,#_first_failure_stage
      003BE4 E0               [24]  284 	movx	a,@dptr
      003BE5 12 38 92         [24]  285 	lcall	_ak820_outline_0121
      003BE8 F0               [24]  286 	movx	@dptr,a
                                    287 ;	keyboards/ajazz/ak820/ak820_nvm.c:44: }
      003BE9 22               [24]  288 	ret
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'crc_byte'
                                    291 ;------------------------------------------------------------
                                    292 ;value         Allocated with name '_crc_byte_PARM_2'
                                    293 ;crc           Allocated with name '_crc_byte_crc_10000_25'
                                    294 ;bit           Allocated with name '_crc_byte_bit_10000_26'
                                    295 ;------------------------------------------------------------
                                    296 ;	keyboards/ajazz/ak820/ak820_nvm.c:46: static uint16_t crc_byte(uint16_t crc, uint8_t value) {
                                    297 ;	-----------------------------------------
                                    298 ;	 function crc_byte
                                    299 ;	-----------------------------------------
      003BEA                        300 _crc_byte:
      003BEA 12 38 88         [24]  301 	lcall	_ak820_outline_0110
      003BED 90 05 64         [24]  302 	mov	dptr,#_crc_byte_crc_10000_25
      003BF0 12 38 8D         [24]  303 	lcall	_ak820_outline_0111
                                    304 ;	keyboards/ajazz/ak820/ak820_nvm.c:48: crc ^= (uint16_t)value << 8;
      003BF3 90 05 63         [24]  305 	mov	dptr,#_crc_byte_PARM_2
      003BF6 E0               [24]  306 	movx	a,@dptr
      003BF7 FF               [12]  307 	mov	r7,a
      003BF8 7E 00            [12]  308 	mov	r6,#0x00
      003BFA 90 05 64         [24]  309 	mov	dptr,#_crc_byte_crc_10000_25
      003BFD E0               [24]  310 	movx	a,@dptr
      003BFE 6E               [12]  311 	xrl	a,r6
      003BFF F0               [24]  312 	movx	@dptr,a
      003C00 A3               [24]  313 	inc	dptr
      003C01 E0               [24]  314 	movx	a,@dptr
      003C02 6F               [12]  315 	xrl	a,r7
      003C03 F0               [24]  316 	movx	@dptr,a
                                    317 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003C04 7F 00            [12]  318 	mov	r7,#0x00
      003C06                        319 00102$:
                                    320 ;	keyboards/ajazz/ak820/ak820_nvm.c:50: crc = (crc & 0x8000u) ? (uint16_t)((crc << 1) ^ 0x1021u) : (uint16_t)(crc << 1);
      003C06 90 05 64         [24]  321 	mov	dptr,#_crc_byte_crc_10000_25
      003C09 12 38 6A         [24]  322 	lcall	_ak820_outline_0085
      003C0C 30 E7 0E         [24]  323 	jnb	acc.7,00106$
      003C0F ED               [12]  324 	mov	a,r5
      003C10 2D               [12]  325 	add	a,r5
      003C11 FB               [12]  326 	mov	r3,a
      003C12 EE               [12]  327 	mov	a,r6
      003C13 33               [12]  328 	rlc	a
      003C14 FC               [12]  329 	mov	r4,a
      003C15 63 03 21         [24]  330 	xrl	ar3,#0x21
      003C18 63 04 10         [24]  331 	xrl	ar4,#0x10
      003C1B 80 06            [24]  332 	sjmp	00107$
      003C1D                        333 00106$:
      003C1D ED               [12]  334 	mov	a,r5
      003C1E 2D               [12]  335 	add	a,r5
      003C1F FB               [12]  336 	mov	r3,a
      003C20 EE               [12]  337 	mov	a,r6
      003C21 33               [12]  338 	rlc	a
      003C22 FC               [12]  339 	mov	r4,a
      003C23                        340 00107$:
      003C23 90 05 64         [24]  341 	mov	dptr,#_crc_byte_crc_10000_25
      003C26 12 38 64         [24]  342 	lcall	_ak820_outline_0084
                                    343 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003C29 0F               [12]  344 	inc	r7
      003C2A BF 08 D9         [24]  345 	cjne	r7,#0x08,00102$
                                    346 ;	keyboards/ajazz/ak820/ak820_nvm.c:52: return crc;
      003C2D 12 33 FC         [24]  347 	lcall	_ak820_outline_0125
                                    348 ;	keyboards/ajazz/ak820/ak820_nvm.c:53: }
      003C30 22               [24]  349 	ret
                                    350 ;------------------------------------------------------------
                                    351 ;Allocation info for local variables in function 'page_crc'
                                    352 ;------------------------------------------------------------
                                    353 ;crc           Allocated with name '_page_crc_crc_10000_30'
                                    354 ;i             Allocated with name '_page_crc_i_10000_30'
                                    355 ;------------------------------------------------------------
                                    356 ;	keyboards/ajazz/ak820/ak820_nvm.c:55: static uint16_t page_crc(void) {
                                    357 ;	-----------------------------------------
                                    358 ;	 function page_crc
                                    359 ;	-----------------------------------------
      003C31                        360 _page_crc:
                                    361 ;	keyboards/ajazz/ak820/ak820_nvm.c:56: uint16_t crc = 0xFFFFu;
      003C31 90 05 66         [24]  362 	mov	dptr,#_page_crc_crc_10000_30
      003C34 74 FF            [12]  363 	mov	a,#0xff
      003C36 F0               [24]  364 	movx	@dptr,a
      003C37 A3               [24]  365 	inc	dptr
      003C38 F0               [24]  366 	movx	@dptr,a
                                    367 ;	keyboards/ajazz/ak820/ak820_nvm.c:58: for (i = 0; i != AK820_FLASH_PAGE; ++i) crc = crc_byte(crc, page_data[i]);
      003C39 7F 00            [12]  368 	mov	r7,#0x00
      003C3B                        369 00102$:
      003C3B 90 05 66         [24]  370 	mov	dptr,#_page_crc_crc_10000_30
      003C3E 12 38 6A         [24]  371 	lcall	_ak820_outline_0085
      003C41 12 43 4B         [24]  372 	lcall	_ak820_outline_0108
      003C44 90 05 63         [24]  373 	mov	dptr,#_crc_byte_PARM_2
      003C47 F0               [24]  374 	movx	@dptr,a
      003C48 12 38 9C         [24]  375 	lcall	_ak820_outline_0135
      003C4B C0 07            [24]  376 	push	ar7
      003C4D 12 3B EA         [24]  377 	lcall	_crc_byte
      003C50 AD 82            [24]  378 	mov	r5, dpl
      003C52 AE 83            [24]  379 	mov	r6, dph
      003C54 D0 07            [24]  380 	pop	ar7
      003C56 90 05 66         [24]  381 	mov	dptr,#_page_crc_crc_10000_30
      003C59 12 43 78         [24]  382 	lcall	_ak820_outline_0165
      003C5C 0F               [12]  383 	inc	r7
      003C5D BF 40 DB         [24]  384 	cjne	r7,#0x40,00102$
                                    385 ;	keyboards/ajazz/ak820/ak820_nvm.c:59: return crc;
      003C60 12 38 9C         [24]  386 	lcall	_ak820_outline_0135
                                    387 ;	keyboards/ajazz/ak820/ak820_nvm.c:60: }
      003C63 22               [24]  388 	ret
                                    389 ;------------------------------------------------------------
                                    390 ;Allocation info for local variables in function 'write_page'
                                    391 ;------------------------------------------------------------
                                    392 ;address       Allocated with name '_write_page_address_10000_32'
                                    393 ;i             Allocated with name '_write_page_i_10000_33'
                                    394 ;------------------------------------------------------------
                                    395 ;	keyboards/ajazz/ak820/ak820_nvm.c:62: static bool write_page(uint16_t address) {
                                    396 ;	-----------------------------------------
                                    397 ;	 function write_page
                                    398 ;	-----------------------------------------
      003C64                        399 _write_page:
      003C64 12 38 88         [24]  400 	lcall	_ak820_outline_0110
      003C67 90 05 68         [24]  401 	mov	dptr,#_write_page_address_10000_32
      003C6A 12 38 8D         [24]  402 	lcall	_ak820_outline_0111
                                    403 ;	keyboards/ajazz/ak820/ak820_nvm.c:64: if (!ak820_flash_erase(address)) return false;
      003C6D 90 05 68         [24]  404 	mov	dptr,#_write_page_address_10000_32
      003C70 12 37 F4         [24]  405 	lcall	_ak820_outline_0005
      003C73 C0 07            [24]  406 	push	ar7
      003C75 C0 06            [24]  407 	push	ar6
      003C77 12 39 FC         [24]  408 	lcall	_ak820_flash_erase
      003C7A E5 82            [12]  409 	mov	a, dpl
      003C7C D0 06            [24]  410 	pop	ar6
      003C7E D0 07            [24]  411 	pop	ar7
      003C80 70 03            [24]  412 	jnz	00102$
      003C82 F5 82            [12]  413 	mov	dpl,a
      003C84 22               [24]  414 	ret
      003C85                        415 00102$:
                                    416 ;	keyboards/ajazz/ak820/ak820_nvm.c:65: if (!ak820_flash_program_page(address, page_data)) return false;
      003C85 90 04 F9         [24]  417 	mov	dptr,#_ak820_flash_program_page_PARM_2
      003C88 74 1D            [12]  418 	mov	a,#_page_data
      003C8A F0               [24]  419 	movx	@dptr,a
      003C8B 74 05            [12]  420 	mov	a,#(_page_data >> 8)
      003C8D A3               [24]  421 	inc	dptr
      003C8E 12 43 39         [24]  422 	lcall	_ak820_outline_0078
      003C91 12 3B 10         [24]  423 	lcall	_ak820_flash_program_page
      003C94 E5 82            [12]  424 	mov	a, dpl
      003C96 70 03            [24]  425 	jnz	00120$
      003C98 F5 82            [12]  426 	mov	dpl,a
                                    427 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003C9A 22               [24]  428 	ret
      003C9B                        429 00120$:
      003C9B 7F 00            [12]  430 	mov	r7,#0x00
      003C9D                        431 00108$:
                                    432 ;	keyboards/ajazz/ak820/ak820_nvm.c:67: if (ak820_flash_read(address + i) != page_data[i]) return false;
      003C9D 8F 05            [24]  433 	mov	ar5,r7
      003C9F 7E 00            [12]  434 	mov	r6,#0x00
      003CA1 90 05 68         [24]  435 	mov	dptr,#_write_page_address_10000_32
      003CA4 12 38 82         [24]  436 	lcall	_ak820_outline_0106
      003CA7 ED               [12]  437 	mov	a,r5
      003CA8 2B               [12]  438 	add	a, r3
      003CA9 FB               [12]  439 	mov	r3,a
      003CAA EE               [12]  440 	mov	a,r6
      003CAB 3C               [12]  441 	addc	a, r4
      003CAC FC               [12]  442 	mov	r4,a
      003CAD 12 33 FC         [24]  443 	lcall	_ak820_outline_0125
      003CB0 12 38 EF         [24]  444 	lcall	_ak820_flash_read
      003CB3 AE 82            [24]  445 	mov	r6, dpl
      003CB5 12 43 4B         [24]  446 	lcall	_ak820_outline_0108
      003CB8 FD               [12]  447 	mov	r5,a
      003CB9 EE               [12]  448 	mov	a,r6
      003CBA B5 05 02         [24]  449 	cjne	a,ar5,00149$
      003CBD 80 04            [24]  450 	sjmp	00109$
      003CBF                        451 00149$:
      003CBF 75 82 00         [24]  452 	mov	dpl, #0x00
      003CC2 22               [24]  453 	ret
      003CC3                        454 00109$:
                                    455 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003CC3 0F               [12]  456 	inc	r7
      003CC4 BF 40 D6         [24]  457 	cjne	r7,#0x40,00108$
                                    458 ;	keyboards/ajazz/ak820/ak820_nvm.c:69: return true;
      003CC7 75 82 01         [24]  459 	mov	dpl, #0x01
                                    460 ;	keyboards/ajazz/ak820/ak820_nvm.c:70: }
      003CCA 22               [24]  461 	ret
                                    462 ;------------------------------------------------------------
                                    463 ;Allocation info for local variables in function 'journal_header_valid'
                                    464 ;------------------------------------------------------------
                                    465 ;header        Allocated with name '_journal_header_valid_header_10000_39'
                                    466 ;i             Allocated with name '_journal_header_valid_i_10000_40'
                                    467 ;------------------------------------------------------------
                                    468 ;	keyboards/ajazz/ak820/ak820_nvm.c:72: static bool journal_header_valid(uint8_t AK820_XDATA *header) {
                                    469 ;	-----------------------------------------
                                    470 ;	 function journal_header_valid
                                    471 ;	-----------------------------------------
      003CCB                        472 _journal_header_valid:
      003CCB 12 38 88         [24]  473 	lcall	_ak820_outline_0110
      003CCE 90 05 6A         [24]  474 	mov	dptr,#_journal_header_valid_header_10000_39
      003CD1 12 38 8D         [24]  475 	lcall	_ak820_outline_0111
                                    476 ;	keyboards/ajazz/ak820/ak820_nvm.c:74: if (header[0] != 0xA5u) return false;
      003CD4 90 05 6A         [24]  477 	mov	dptr,#_journal_header_valid_header_10000_39
      003CD7 12 37 F4         [24]  478 	lcall	_ak820_outline_0005
      003CDA E0               [24]  479 	movx	a,@dptr
      003CDB FD               [12]  480 	mov	r5,a
      003CDC BD A5 02         [24]  481 	cjne	r5,#0xa5,00138$
      003CDF 80 04            [24]  482 	sjmp	00116$
      003CE1                        483 00138$:
      003CE1 75 82 00         [24]  484 	mov	dpl, #0x00
                                    485 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      003CE4 22               [24]  486 	ret
      003CE5                        487 00116$:
      003CE5 7D 01            [12]  488 	mov	r5,#0x01
      003CE7                        489 00106$:
                                    490 ;	keyboards/ajazz/ak820/ak820_nvm.c:76: if ((uint8_t)(header[i] ^ header[i + 4]) != 0xFFu) return false;
      003CE7 ED               [12]  491 	mov	a,r5
      003CE8 12 38 31         [24]  492 	lcall	_ak820_outline_0021
      003CEB E0               [24]  493 	movx	a,@dptr
      003CEC FC               [12]  494 	mov	r4,a
      003CED 8D 02            [24]  495 	mov	ar2,r5
      003CEF 7B 00            [12]  496 	mov	r3,#0x00
      003CF1 74 04            [12]  497 	mov	a,#0x04
      003CF3 2A               [12]  498 	add	a, r2
      003CF4 FA               [12]  499 	mov	r2,a
      003CF5 E4               [12]  500 	clr	a
      003CF6 3B               [12]  501 	addc	a, r3
      003CF7 FB               [12]  502 	mov	r3,a
      003CF8 EA               [12]  503 	mov	a,r2
      003CF9 2E               [12]  504 	add	a, r6
      003CFA F5 82            [12]  505 	mov	dpl,a
      003CFC EB               [12]  506 	mov	a,r3
      003CFD 3F               [12]  507 	addc	a, r7
      003CFE F5 83            [12]  508 	mov	dph,a
      003D00 E0               [24]  509 	movx	a,@dptr
      003D01 62 04            [12]  510 	xrl	ar4,a
      003D03 BC FF 02         [24]  511 	cjne	r4,#0xff,00139$
      003D06 80 04            [24]  512 	sjmp	00107$
      003D08                        513 00139$:
      003D08 75 82 00         [24]  514 	mov	dpl, #0x00
      003D0B 22               [24]  515 	ret
      003D0C                        516 00107$:
                                    517 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      003D0C 0D               [12]  518 	inc	r5
      003D0D BD 05 D7         [24]  519 	cjne	r5,#0x05,00106$
                                    520 ;	keyboards/ajazz/ak820/ak820_nvm.c:78: return true;
      003D10 75 82 01         [24]  521 	mov	dpl, #0x01
                                    522 ;	keyboards/ajazz/ak820/ak820_nvm.c:79: }
      003D13 22               [24]  523 	ret
                                    524 ;------------------------------------------------------------
                                    525 ;Allocation info for local variables in function 'recover_journal'
                                    526 ;------------------------------------------------------------
                                    527 ;header        Allocated with name '_recover_journal_header_10000_46'
                                    528 ;i             Allocated with name '_recover_journal_i_10000_46'
                                    529 ;page          Allocated with name '_recover_journal_page_10000_46'
                                    530 ;crc           Allocated with name '_recover_journal_crc_10000_46'
                                    531 ;------------------------------------------------------------
                                    532 ;	keyboards/ajazz/ak820/ak820_nvm.c:81: static void recover_journal(void) {
                                    533 ;	-----------------------------------------
                                    534 ;	 function recover_journal
                                    535 ;	-----------------------------------------
      003D14                        536 _recover_journal:
                                    537 ;	keyboards/ajazz/ak820/ak820_nvm.c:85: for (i = 0; i != sizeof(header); ++i) header[i] = ak820_flash_read(AK820_JOURNAL_HEADER + i);
      003D14 7F 00            [12]  538 	mov	r7,#0x00
      003D16                        539 00115$:
      003D16 EF               [12]  540 	mov	a,r7
      003D17 24 6C            [12]  541 	add	a, #_recover_journal_header_10000_46
      003D19 FD               [12]  542 	mov	r5,a
      003D1A E4               [12]  543 	clr	a
      003D1B 34 05            [12]  544 	addc	a, #(_recover_journal_header_10000_46 >> 8)
      003D1D FE               [12]  545 	mov	r6,a
      003D1E 8F 04            [24]  546 	mov	ar4,r7
      003D20 7B 00            [12]  547 	mov	r3,#0x00
      003D22 74 40            [12]  548 	mov	a,#0x40
      003D24 2C               [12]  549 	add	a, r4
      003D25 FC               [12]  550 	mov	r4,a
      003D26 74 EF            [12]  551 	mov	a,#0xef
      003D28 3B               [12]  552 	addc	a, r3
      003D29 FB               [12]  553 	mov	r3,a
      003D2A 12 43 83         [24]  554 	lcall	_ak820_outline_0187
      003D2D 12 38 EF         [24]  555 	lcall	_ak820_flash_read
      003D30 AC 82            [24]  556 	mov	r4, dpl
      003D32 12 38 9C         [24]  557 	lcall	_ak820_outline_0135
      003D35 EC               [12]  558 	mov	a,r4
      003D36 F0               [24]  559 	movx	@dptr,a
      003D37 0F               [12]  560 	inc	r7
      003D38 BF 09 DB         [24]  561 	cjne	r7,#0x09,00115$
                                    562 ;	keyboards/ajazz/ak820/ak820_nvm.c:88: if (!journal_header_valid(header)) return;
      003D3B 90 05 6C         [24]  563 	mov	dptr,#_recover_journal_header_10000_46
      003D3E 12 3C CB         [24]  564 	lcall	_journal_header_valid
      003D41 E5 82            [12]  565 	mov	a, dpl
      003D43 70 01            [24]  566 	jnz	00103$
      003D45 22               [24]  567 	ret
      003D46                        568 00103$:
                                    569 ;	keyboards/ajazz/ak820/ak820_nvm.c:89: page = (uint16_t)header[1] | ((uint16_t)header[2] << 8);
      003D46 90 05 6D         [24]  570 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0001)
      003D49 E0               [24]  571 	movx	a,@dptr
      003D4A FF               [12]  572 	mov	r7,a
      003D4B 7E 00            [12]  573 	mov	r6,#0x00
      003D4D 90 05 6E         [24]  574 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0002)
      003D50 E0               [24]  575 	movx	a,@dptr
      003D51 FC               [12]  576 	mov	r4,a
      003D52 E4               [12]  577 	clr	a
      003D53 42 07            [12]  578 	orl	ar7,a
      003D55 EC               [12]  579 	mov	a,r4
      003D56 42 06            [12]  580 	orl	ar6,a
                                    581 ;	keyboards/ajazz/ak820/ak820_nvm.c:90: crc = (uint16_t)header[3] | ((uint16_t)header[4] << 8);
      003D58 90 05 6F         [24]  582 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0003)
      003D5B E0               [24]  583 	movx	a,@dptr
      003D5C FD               [12]  584 	mov	r5,a
      003D5D 7C 00            [12]  585 	mov	r4,#0x00
      003D5F 90 05 70         [24]  586 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0004)
      003D62 E0               [24]  587 	movx	a,@dptr
      003D63 FA               [12]  588 	mov	r2,a
      003D64 E4               [12]  589 	clr	a
      003D65 12 43 62         [24]  590 	lcall	_ak820_outline_0144
                                    591 ;	keyboards/ajazz/ak820/ak820_nvm.c:91: if (page >= AK820_NVM_SIZE / AK820_FLASH_PAGE) {
      003D68 C3               [12]  592 	clr	c
      003D69 EF               [12]  593 	mov	a,r7
      003D6A 94 A0            [12]  594 	subb	a,#0xa0
      003D6C EE               [12]  595 	mov	a,r6
      003D6D 94 00            [12]  596 	subb	a,#0x00
      003D6F 40 06            [24]  597 	jc	00134$
                                    598 ;	keyboards/ajazz/ak820/ak820_nvm.c:92: nvm_fail(AK820_NVM_FAULT_RECOVERY_PAGE);
      003D71 75 82 01         [24]  599 	mov	dpl, #0x01
                                    600 ;	keyboards/ajazz/ak820/ak820_nvm.c:93: return;
      003D74 02 3B 83         [24]  601 	ljmp	_nvm_fail
                                    602 ;	keyboards/ajazz/ak820/ak820_nvm.c:95: for (i = 0; i != AK820_FLASH_PAGE; ++i) page_data[i] = ak820_flash_read(AK820_JOURNAL_DATA + i);
      003D77                        603 00134$:
      003D77 7B 00            [12]  604 	mov	r3,#0x00
      003D79                        605 00117$:
      003D79 C0 05            [24]  606 	push	ar5
      003D7B C0 04            [24]  607 	push	ar4
      003D7D EB               [12]  608 	mov	a,r3
      003D7E 24 1D            [12]  609 	add	a, #_page_data
      003D80 F9               [12]  610 	mov	r1,a
      003D81 E4               [12]  611 	clr	a
      003D82 34 05            [12]  612 	addc	a, #(_page_data >> 8)
      003D84 FA               [12]  613 	mov	r2,a
      003D85 8B 00            [24]  614 	mov	ar0,r3
      003D87 7D 00            [12]  615 	mov	r5,#0x00
      003D89 74 EF            [12]  616 	mov	a,#0xef
      003D8B 2D               [12]  617 	add	a, r5
      003D8C FD               [12]  618 	mov	r5,a
      003D8D 88 82            [24]  619 	mov	dpl, r0
      003D8F 8D 83            [24]  620 	mov	dph, r5
      003D91 12 38 EF         [24]  621 	lcall	_ak820_flash_read
      003D94 AD 82            [24]  622 	mov	r5, dpl
      003D96 12 43 7E         [24]  623 	lcall	_ak820_outline_0186
      003D99 ED               [12]  624 	mov	a,r5
      003D9A F0               [24]  625 	movx	@dptr,a
      003D9B 0B               [12]  626 	inc	r3
      003D9C BB 40 02         [24]  627 	cjne	r3,#0x40,00190$
      003D9F 80 06            [24]  628 	sjmp	00191$
      003DA1                        629 00190$:
      003DA1 D0 04            [24]  630 	pop	ar4
      003DA3 D0 05            [24]  631 	pop	ar5
      003DA5 80 D2            [24]  632 	sjmp	00117$
      003DA7                        633 00191$:
      003DA7 D0 04            [24]  634 	pop	ar4
      003DA9 D0 05            [24]  635 	pop	ar5
                                    636 ;	keyboards/ajazz/ak820/ak820_nvm.c:96: if (page_crc() != crc) nvm_fail(AK820_NVM_FAULT_RECOVERY_CRC);
      003DAB C0 07            [24]  637 	push	ar7
      003DAD C0 06            [24]  638 	push	ar6
      003DAF C0 05            [24]  639 	push	ar5
      003DB1 C0 04            [24]  640 	push	ar4
      003DB3 12 3C 31         [24]  641 	lcall	_page_crc
      003DB6 AA 82            [24]  642 	mov	r2, dpl
      003DB8 AB 83            [24]  643 	mov	r3, dph
      003DBA D0 04            [24]  644 	pop	ar4
      003DBC D0 05            [24]  645 	pop	ar5
      003DBE D0 06            [24]  646 	pop	ar6
      003DC0 D0 07            [24]  647 	pop	ar7
      003DC2 EA               [12]  648 	mov	a,r2
      003DC3 B5 05 06         [24]  649 	cjne	a,ar5,00192$
      003DC6 EB               [12]  650 	mov	a,r3
      003DC7 B5 04 02         [24]  651 	cjne	a,ar4,00192$
      003DCA 80 06            [24]  652 	sjmp	00113$
      003DCC                        653 00192$:
      003DCC 75 82 02         [24]  654 	mov	dpl, #0x02
      003DCF 02 3B 83         [24]  655 	ljmp	_nvm_fail
      003DD2                        656 00113$:
                                    657 ;	keyboards/ajazz/ak820/ak820_nvm.c:97: else if (!write_page(AK820_NVM_BASE + page * AK820_FLASH_PAGE)) nvm_fail(AK820_NVM_FAULT_RECOVERY_WRITE);
      003DD2 EE               [12]  658 	mov	a,r6
      003DD3 54 03            [12]  659 	anl	a,#0x03
      003DD5 A2 E0            [12]  660 	mov	c,acc.0
      003DD7 CF               [12]  661 	xch	a,r7
      003DD8 13               [12]  662 	rrc	a
      003DD9 CF               [12]  663 	xch	a,r7
      003DDA 13               [12]  664 	rrc	a
      003DDB A2 E0            [12]  665 	mov	c,acc.0
      003DDD CF               [12]  666 	xch	a,r7
      003DDE 13               [12]  667 	rrc	a
      003DDF CF               [12]  668 	xch	a,r7
      003DE0 13               [12]  669 	rrc	a
      003DE1 CF               [12]  670 	xch	a,r7
      003DE2 24 C7            [12]  671 	add	a,#0xc7
      003DE4 FE               [12]  672 	mov	r6,a
      003DE5 12 43 6D         [24]  673 	lcall	_ak820_outline_0161
      003DE8 12 3C 64         [24]  674 	lcall	_write_page
      003DEB E5 82            [12]  675 	mov	a, dpl
      003DED 70 06            [24]  676 	jnz	00110$
      003DEF 75 82 03         [24]  677 	mov	dpl, #0x03
      003DF2 02 3B 83         [24]  678 	ljmp	_nvm_fail
      003DF5                        679 00110$:
                                    680 ;	keyboards/ajazz/ak820/ak820_nvm.c:98: else if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) nvm_fail(AK820_NVM_FAULT_RECOVERY_CLEANUP);
      003DF5 90 EF 40         [24]  681 	mov	dptr,#0xef40
      003DF8 12 39 FC         [24]  682 	lcall	_ak820_flash_erase
      003DFB E5 82            [12]  683 	mov	a, dpl
      003DFD 70 06            [24]  684 	jnz	00119$
      003DFF 75 82 04         [24]  685 	mov	dpl, #0x04
                                    686 ;	keyboards/ajazz/ak820/ak820_nvm.c:99: }
      003E02 02 3B 83         [24]  687 	ljmp	_nvm_fail
      003E05                        688 00119$:
      003E05 22               [24]  689 	ret
                                    690 ;------------------------------------------------------------
                                    691 ;Allocation info for local variables in function 'eeprom_driver_init'
                                    692 ;------------------------------------------------------------
                                    693 ;	keyboards/ajazz/ak820/ak820_nvm.c:101: void eeprom_driver_init(void) {
                                    694 ;	-----------------------------------------
                                    695 ;	 function eeprom_driver_init
                                    696 ;	-----------------------------------------
      003E06                        697 _eeprom_driver_init:
                                    698 ;	keyboards/ajazz/ak820/ak820_nvm.c:102: storage_failed = false;
                                    699 ;	assignBit
      003E06 C2 0B            [12]  700 	clr	_storage_failed
                                    701 ;	keyboards/ajazz/ak820/ak820_nvm.c:103: first_failure_stage = AK820_NVM_FAULT_NONE;
      003E08 90 05 5F         [24]  702 	mov	dptr,#_first_failure_stage
      003E0B E4               [12]  703 	clr	a
      003E0C F0               [24]  704 	movx	@dptr,a
                                    705 ;	keyboards/ajazz/ak820/ak820_nvm.c:104: page_valid = page_dirty = false;
                                    706 ;	assignBit
      003E0D C2 0A            [12]  707 	clr	_page_dirty
                                    708 ;	assignBit
      003E0F C2 09            [12]  709 	clr	_page_valid
                                    710 ;	keyboards/ajazz/ak820/ak820_nvm.c:105: batch_depth = 0;
      003E11 90 05 5E         [24]  711 	mov	dptr,#_batch_depth
      003E14 E4               [12]  712 	clr	a
      003E15 F0               [24]  713 	movx	@dptr,a
                                    714 ;	keyboards/ajazz/ak820/ak820_nvm.c:106: recover_journal();
      003E16 12 3D 14         [24]  715 	lcall	_recover_journal
                                    716 ;	keyboards/ajazz/ak820/ak820_nvm.c:108: ak820_macro_init();
                                    717 ;	keyboards/ajazz/ak820/ak820_nvm.c:110: }
      003E19 02 2A B7         [24]  718 	ljmp	_ak820_macro_init
                                    719 ;------------------------------------------------------------
                                    720 ;Allocation info for local variables in function 'ak820_nvm_ok'
                                    721 ;------------------------------------------------------------
                                    722 ;	keyboards/ajazz/ak820/ak820_nvm.c:112: bool ak820_nvm_ok(void) { return !storage_failed; }
                                    723 ;	-----------------------------------------
                                    724 ;	 function ak820_nvm_ok
                                    725 ;	-----------------------------------------
      003E1C                        726 _ak820_nvm_ok:
      003E1C A2 0B            [12]  727 	mov	c,_storage_failed
      003E1E B3               [12]  728 	cpl	c
      003E1F 92 0C            [24]  729 	mov  _ak820_nvm_ok_sloc0_1_0,c
      003E21 12 38 B1         [24]  730 	lcall	_ak820_outline_0159
      003E24 22               [24]  731 	ret
                                    732 ;------------------------------------------------------------
                                    733 ;Allocation info for local variables in function 'ak820_nvm_schema_fault'
                                    734 ;------------------------------------------------------------
                                    735 ;	keyboards/ajazz/ak820/ak820_nvm.c:114: void ak820_nvm_schema_fault(void) { nvm_fail(AK820_NVM_FAULT_SCHEMA); }
                                    736 ;	-----------------------------------------
                                    737 ;	 function ak820_nvm_schema_fault
                                    738 ;	-----------------------------------------
      003E25                        739 _ak820_nvm_schema_fault:
      003E25 75 82 10         [24]  740 	mov	dpl, #0x10
      003E28 02 3B 83         [24]  741 	ljmp	_nvm_fail
                                    742 ;------------------------------------------------------------
                                    743 ;Allocation info for local variables in function 'ak820_nvm_flush'
                                    744 ;------------------------------------------------------------
                                    745 ;header        Allocated with name '_ak820_nvm_flush_header_10000_62'
                                    746 ;crc           Allocated with name '_ak820_nvm_flush_crc_10000_62'
                                    747 ;i             Allocated with name '_ak820_nvm_flush_i_10000_62'
                                    748 ;stage         Allocated with name '_ak820_nvm_flush_stage_10000_62'
                                    749 ;------------------------------------------------------------
                                    750 ;	keyboards/ajazz/ak820/ak820_nvm.c:116: void ak820_nvm_flush(void) {
                                    751 ;	-----------------------------------------
                                    752 ;	 function ak820_nvm_flush
                                    753 ;	-----------------------------------------
      003E2B                        754 _ak820_nvm_flush:
                                    755 ;	keyboards/ajazz/ak820/ak820_nvm.c:121: if (!page_dirty || storage_failed) return;
      003E2B 30 0A 03         [24]  756 	jnb	_page_dirty,00101$
      003E2E 30 0B 01         [24]  757 	jnb	_storage_failed,00102$
      003E31                        758 00101$:
      003E31 22               [24]  759 	ret
      003E32                        760 00102$:
                                    761 ;	keyboards/ajazz/ak820/ak820_nvm.c:122: crc = page_crc();
      003E32 12 3C 31         [24]  762 	lcall	_page_crc
      003E35 12 43 57         [24]  763 	lcall	_ak820_outline_0136
                                    764 ;	keyboards/ajazz/ak820/ak820_nvm.c:123: header[0] = 0xA5u;
      003E38 90 05 75         [24]  765 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003E3B 74 A5            [12]  766 	mov	a,#0xa5
      003E3D F0               [24]  767 	movx	@dptr,a
                                    768 ;	keyboards/ajazz/ak820/ak820_nvm.c:124: header[1] = (uint8_t)cached_page;
      003E3E 90 05 5D         [24]  769 	mov	dptr,#_cached_page
      003E41 E0               [24]  770 	movx	a,@dptr
      003E42 90 05 76         [24]  771 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0001)
      003E45 F0               [24]  772 	movx	@dptr,a
                                    773 ;	keyboards/ajazz/ak820/ak820_nvm.c:125: header[2] = (uint8_t)(cached_page >> 8);
      003E46 90 05 77         [24]  774 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0002)
      003E49 E4               [12]  775 	clr	a
      003E4A F0               [24]  776 	movx	@dptr,a
                                    777 ;	keyboards/ajazz/ak820/ak820_nvm.c:126: header[3] = (uint8_t)crc;
      003E4B 8E 05            [24]  778 	mov	ar5,r6
      003E4D 90 05 78         [24]  779 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0003)
      003E50 ED               [12]  780 	mov	a,r5
      003E51 F0               [24]  781 	movx	@dptr,a
                                    782 ;	keyboards/ajazz/ak820/ak820_nvm.c:127: header[4] = (uint8_t)(crc >> 8);
      003E52 8F 06            [24]  783 	mov	ar6,r7
      003E54 90 05 79         [24]  784 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0004)
      003E57 EE               [12]  785 	mov	a,r6
      003E58 F0               [24]  786 	movx	@dptr,a
                                    787 ;	keyboards/ajazz/ak820/ak820_nvm.c:128: for (i = 1; i != 5; ++i) header[i + 4] = (uint8_t)~header[i];
      003E59 7F 01            [12]  788 	mov	r7,#0x01
      003E5B                        789 00128$:
      003E5B 8F 06            [24]  790 	mov	ar6,r7
      003E5D EE               [12]  791 	mov	a,r6
      003E5E 24 04            [12]  792 	add	a,#0x04
      003E60 FE               [12]  793 	mov	r6,a
      003E61 33               [12]  794 	rlc	a
      003E62 95 E0            [12]  795 	subb	a,acc
      003E64 FD               [12]  796 	mov	r5,a
      003E65 EE               [12]  797 	mov	a,r6
      003E66 24 75            [12]  798 	add	a, #_ak820_nvm_flush_header_10000_62
      003E68 FE               [12]  799 	mov	r6,a
      003E69 ED               [12]  800 	mov	a,r5
      003E6A 34 05            [12]  801 	addc	a, #(_ak820_nvm_flush_header_10000_62 >> 8)
      003E6C FD               [12]  802 	mov	r5,a
      003E6D 12 43 1C         [24]  803 	lcall	_ak820_outline_0043
      003E70 FC               [12]  804 	mov	r4,a
      003E71 63 04 FF         [24]  805 	xrl	ar4,#0xff
      003E74 8E 82            [24]  806 	mov	dpl,r6
      003E76 8D 83            [24]  807 	mov	dph,r5
      003E78 EC               [12]  808 	mov	a,r4
      003E79 F0               [24]  809 	movx	@dptr,a
      003E7A 0F               [12]  810 	inc	r7
      003E7B BF 05 DD         [24]  811 	cjne	r7,#0x05,00128$
                                    812 ;	keyboards/ajazz/ak820/ak820_nvm.c:131: stage = AK820_NVM_FAULT_HEADER_ERASE;
      003E7E 90 05 7E         [24]  813 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003E81 74 05            [12]  814 	mov	a,#0x05
      003E83 F0               [24]  815 	movx	@dptr,a
                                    816 ;	keyboards/ajazz/ak820/ak820_nvm.c:132: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      003E84 90 EF 40         [24]  817 	mov	dptr,#0xef40
      003E87 12 39 FC         [24]  818 	lcall	_ak820_flash_erase
      003E8A E5 82            [12]  819 	mov	a, dpl
      003E8C 70 03            [24]  820 	jnz	00269$
      003E8E 02 3F 75         [24]  821 	ljmp	00127$
      003E91                        822 00269$:
                                    823 ;	keyboards/ajazz/ak820/ak820_nvm.c:133: stage = AK820_NVM_FAULT_HEADER_ZERO;
      003E91 90 05 7E         [24]  824 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003E94 74 06            [12]  825 	mov	a,#0x06
      003E96 F0               [24]  826 	movx	@dptr,a
                                    827 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003E97 7F 00            [12]  828 	mov	r7,#0x00
      003E99                        829 00130$:
                                    830 ;	keyboards/ajazz/ak820/ak820_nvm.c:135: if (ak820_flash_read(AK820_JOURNAL_HEADER + i)) goto failed;
      003E99 12 43 28         [24]  831 	lcall	_ak820_outline_0053
      003E9C 12 38 EF         [24]  832 	lcall	_ak820_flash_read
      003E9F E5 82            [12]  833 	mov	a, dpl
      003EA1 60 03            [24]  834 	jz	00270$
      003EA3 02 3F 75         [24]  835 	ljmp	00127$
      003EA6                        836 00270$:
                                    837 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003EA6 0F               [12]  838 	inc	r7
      003EA7 BF 40 EF         [24]  839 	cjne	r7,#0x40,00130$
                                    840 ;	keyboards/ajazz/ak820/ak820_nvm.c:137: stage = AK820_NVM_FAULT_JOURNAL_WRITE;
      003EAA 90 05 7E         [24]  841 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003EAD 74 07            [12]  842 	mov	a,#0x07
      003EAF F0               [24]  843 	movx	@dptr,a
                                    844 ;	keyboards/ajazz/ak820/ak820_nvm.c:138: if (!write_page(AK820_JOURNAL_DATA)) goto failed;
      003EB0 90 EF 00         [24]  845 	mov	dptr,#0xef00
      003EB3 12 3C 64         [24]  846 	lcall	_write_page
      003EB6 E5 82            [12]  847 	mov	a, dpl
      003EB8 70 03            [24]  848 	jnz	00273$
      003EBA 02 3F 75         [24]  849 	ljmp	00127$
      003EBD                        850 00273$:
                                    851 ;	keyboards/ajazz/ak820/ak820_nvm.c:139: stage = AK820_NVM_FAULT_METADATA_PROGRAM;
      003EBD 90 05 7E         [24]  852 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003EC0 74 08            [12]  853 	mov	a,#0x08
      003EC2 F0               [24]  854 	movx	@dptr,a
                                    855 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      003EC3 7F 01            [12]  856 	mov	r7,#0x01
      003EC5                        857 00132$:
                                    858 ;	keyboards/ajazz/ak820/ak820_nvm.c:141: if (header[i] && !ak820_flash_program(AK820_JOURNAL_HEADER + i, header[i])) goto failed;
      003EC5 12 43 1C         [24]  859 	lcall	_ak820_outline_0043
      003EC8 FE               [12]  860 	mov	r6,a
      003EC9 60 23            [24]  861 	jz	00133$
      003ECB 8F 05            [24]  862 	mov	ar5,r7
      003ECD 7C 00            [12]  863 	mov	r4,#0x00
      003ECF 74 40            [12]  864 	mov	a,#0x40
      003ED1 2D               [12]  865 	add	a, r5
      003ED2 FD               [12]  866 	mov	r5,a
      003ED3 74 EF            [12]  867 	mov	a,#0xef
      003ED5 3C               [12]  868 	addc	a, r4
      003ED6 FC               [12]  869 	mov	r4,a
      003ED7 90 04 F6         [24]  870 	mov	dptr,#_ak820_flash_program_PARM_2
      003EDA EE               [12]  871 	mov	a,r6
      003EDB F0               [24]  872 	movx	@dptr,a
      003EDC 8D 82            [24]  873 	mov	dpl, r5
      003EDE 8C 83            [24]  874 	mov	dph, r4
      003EE0 C0 07            [24]  875 	push	ar7
      003EE2 12 3A 5C         [24]  876 	lcall	_ak820_flash_program
      003EE5 E5 82            [12]  877 	mov	a, dpl
      003EE7 D0 07            [24]  878 	pop	ar7
      003EE9 70 03            [24]  879 	jnz	00275$
      003EEB 02 3F 75         [24]  880 	ljmp	00127$
      003EEE                        881 00275$:
      003EEE                        882 00133$:
                                    883 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      003EEE 0F               [12]  884 	inc	r7
      003EEF BF 09 D3         [24]  885 	cjne	r7,#0x09,00132$
                                    886 ;	keyboards/ajazz/ak820/ak820_nvm.c:143: stage = AK820_NVM_FAULT_METADATA_READBACK;
      003EF2 90 05 7E         [24]  887 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003EF5 74 09            [12]  888 	mov	a,#0x09
      003EF7 F0               [24]  889 	movx	@dptr,a
                                    890 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      003EF8 7F 01            [12]  891 	mov	r7,#0x01
      003EFA                        892 00134$:
                                    893 ;	keyboards/ajazz/ak820/ak820_nvm.c:145: if (ak820_flash_read(AK820_JOURNAL_HEADER + i) != header[i]) goto failed;
      003EFA 12 43 28         [24]  894 	lcall	_ak820_outline_0053
      003EFD 12 38 EF         [24]  895 	lcall	_ak820_flash_read
      003F00 AE 82            [24]  896 	mov	r6, dpl
      003F02 12 43 1C         [24]  897 	lcall	_ak820_outline_0043
      003F05 FD               [12]  898 	mov	r5,a
      003F06 EE               [12]  899 	mov	a,r6
      003F07 B5 05 6B         [24]  900 	cjne	a,ar5,00127$
                                    901 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      003F0A 0F               [12]  902 	inc	r7
      003F0B BF 09 EC         [24]  903 	cjne	r7,#0x09,00134$
                                    904 ;	keyboards/ajazz/ak820/ak820_nvm.c:148: stage = AK820_NVM_FAULT_COMMIT_PROGRAM;
      003F0E 90 05 7E         [24]  905 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F11 74 0A            [12]  906 	mov	a,#0x0a
      003F13 F0               [24]  907 	movx	@dptr,a
                                    908 ;	keyboards/ajazz/ak820/ak820_nvm.c:149: if (!ak820_flash_program(AK820_JOURNAL_HEADER, header[0])) goto failed;
      003F14 90 05 75         [24]  909 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003F17 E0               [24]  910 	movx	a,@dptr
      003F18 90 04 F6         [24]  911 	mov	dptr,#_ak820_flash_program_PARM_2
      003F1B F0               [24]  912 	movx	@dptr,a
      003F1C 90 EF 40         [24]  913 	mov	dptr,#0xef40
      003F1F 12 3A 5C         [24]  914 	lcall	_ak820_flash_program
      003F22 E5 82            [12]  915 	mov	a, dpl
      003F24 60 4F            [24]  916 	jz	00127$
                                    917 ;	keyboards/ajazz/ak820/ak820_nvm.c:150: stage = AK820_NVM_FAULT_COMMIT_READBACK;
      003F26 90 05 7E         [24]  918 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F29 74 0B            [12]  919 	mov	a,#0x0b
      003F2B F0               [24]  920 	movx	@dptr,a
                                    921 ;	keyboards/ajazz/ak820/ak820_nvm.c:151: if (ak820_flash_read(AK820_JOURNAL_HEADER) != header[0]) goto failed;
      003F2C 90 EF 40         [24]  922 	mov	dptr,#0xef40
      003F2F 12 38 EF         [24]  923 	lcall	_ak820_flash_read
      003F32 AF 82            [24]  924 	mov	r7, dpl
      003F34 90 05 75         [24]  925 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003F37 E0               [24]  926 	movx	a,@dptr
      003F38 FE               [12]  927 	mov	r6,a
      003F39 EF               [12]  928 	mov	a,r7
      003F3A B5 06 38         [24]  929 	cjne	a,ar6,00127$
                                    930 ;	keyboards/ajazz/ak820/ak820_nvm.c:152: stage = AK820_NVM_FAULT_TARGET_WRITE;
      003F3D 90 05 7E         [24]  931 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F40 74 0C            [12]  932 	mov	a,#0x0c
      003F42 F0               [24]  933 	movx	@dptr,a
                                    934 ;	keyboards/ajazz/ak820/ak820_nvm.c:153: if (!write_page(AK820_NVM_BASE + cached_page * AK820_FLASH_PAGE)) goto failed;
      003F43 90 05 5D         [24]  935 	mov	dptr,#_cached_page
      003F46 E0               [24]  936 	movx	a,@dptr
      003F47 FE               [12]  937 	mov	r6,a
      003F48 E4               [12]  938 	clr	a
      003F49 C3               [12]  939 	clr	c
      003F4A CE               [12]  940 	xch	a,r6
      003F4B 13               [12]  941 	rrc	a
      003F4C CE               [12]  942 	xch	a,r6
      003F4D 13               [12]  943 	rrc	a
      003F4E A2 E0            [12]  944 	mov	c,acc.0
      003F50 CE               [12]  945 	xch	a,r6
      003F51 13               [12]  946 	rrc	a
      003F52 CE               [12]  947 	xch	a,r6
      003F53 13               [12]  948 	rrc	a
      003F54 CE               [12]  949 	xch	a,r6
      003F55 24 C7            [12]  950 	add	a,#0xc7
      003F57 FF               [12]  951 	mov	r7,a
      003F58 12 38 92         [24]  952 	lcall	_ak820_outline_0121
      003F5B 12 3C 64         [24]  953 	lcall	_write_page
      003F5E E5 82            [12]  954 	mov	a, dpl
      003F60 60 13            [24]  955 	jz	00127$
                                    956 ;	keyboards/ajazz/ak820/ak820_nvm.c:154: stage = AK820_NVM_FAULT_CLEANUP;
      003F62 90 05 7E         [24]  957 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F65 74 0D            [12]  958 	mov	a,#0x0d
      003F67 F0               [24]  959 	movx	@dptr,a
                                    960 ;	keyboards/ajazz/ak820/ak820_nvm.c:155: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      003F68 90 EF 40         [24]  961 	mov	dptr,#0xef40
      003F6B 12 39 FC         [24]  962 	lcall	_ak820_flash_erase
      003F6E E5 82            [12]  963 	mov	a, dpl
      003F70 60 03            [24]  964 	jz	00127$
                                    965 ;	keyboards/ajazz/ak820/ak820_nvm.c:156: page_dirty = false;
                                    966 ;	assignBit
      003F72 C2 0A            [12]  967 	clr	_page_dirty
                                    968 ;	keyboards/ajazz/ak820/ak820_nvm.c:157: return;
                                    969 ;	keyboards/ajazz/ak820/ak820_nvm.c:158: failed:
      003F74 22               [24]  970 	ret
      003F75                        971 00127$:
                                    972 ;	keyboards/ajazz/ak820/ak820_nvm.c:159: nvm_fail(stage);
      003F75 90 05 7E         [24]  973 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F78 E0               [24]  974 	movx	a,@dptr
      003F79 F5 82            [12]  975 	mov	dpl,a
                                    976 ;	keyboards/ajazz/ak820/ak820_nvm.c:160: }
      003F7B 02 3B 83         [24]  977 	ljmp	_nvm_fail
                                    978 ;------------------------------------------------------------
                                    979 ;Allocation info for local variables in function 'ak820_nvm_begin'
                                    980 ;------------------------------------------------------------
                                    981 ;	keyboards/ajazz/ak820/ak820_nvm.c:162: void ak820_nvm_begin(void) {
                                    982 ;	-----------------------------------------
                                    983 ;	 function ak820_nvm_begin
                                    984 ;	-----------------------------------------
      003F7E                        985 _ak820_nvm_begin:
                                    986 ;	keyboards/ajazz/ak820/ak820_nvm.c:163: if (batch_depth == 255u) nvm_fail(AK820_NVM_FAULT_BATCH_OVERFLOW);
      003F7E 90 05 5E         [24]  987 	mov	dptr,#_batch_depth
      003F81 E0               [24]  988 	movx	a,@dptr
      003F82 FF               [12]  989 	mov	r7,a
      003F83 BF FF 06         [24]  990 	cjne	r7,#0xff,00102$
      003F86 75 82 0F         [24]  991 	mov	dpl, #0x0f
      003F89 02 3B 83         [24]  992 	ljmp	_nvm_fail
      003F8C                        993 00102$:
                                    994 ;	keyboards/ajazz/ak820/ak820_nvm.c:164: else ++batch_depth;
      003F8C 90 05 5E         [24]  995 	mov	dptr,#_batch_depth
      003F8F EF               [12]  996 	mov	a,r7
      003F90 04               [12]  997 	inc	a
      003F91 F0               [24]  998 	movx	@dptr,a
                                    999 ;	keyboards/ajazz/ak820/ak820_nvm.c:165: }
      003F92 22               [24] 1000 	ret
                                   1001 ;------------------------------------------------------------
                                   1002 ;Allocation info for local variables in function 'ak820_nvm_end'
                                   1003 ;------------------------------------------------------------
                                   1004 ;	keyboards/ajazz/ak820/ak820_nvm.c:167: void ak820_nvm_end(void) {
                                   1005 ;	-----------------------------------------
                                   1006 ;	 function ak820_nvm_end
                                   1007 ;	-----------------------------------------
      003F93                       1008 _ak820_nvm_end:
                                   1009 ;	keyboards/ajazz/ak820/ak820_nvm.c:168: if (batch_depth) --batch_depth;
      003F93 90 05 5E         [24] 1010 	mov	dptr,#_batch_depth
      003F96 E0               [24] 1011 	movx	a,@dptr
      003F97 FF               [12] 1012 	mov	r7,a
      003F98 E0               [24] 1013 	movx	a,@dptr
      003F99 60 06            [24] 1014 	jz	00102$
      003F9B EF               [12] 1015 	mov	a,r7
      003F9C 14               [12] 1016 	dec	a
      003F9D 90 05 5E         [24] 1017 	mov	dptr,#_batch_depth
      003FA0 F0               [24] 1018 	movx	@dptr,a
      003FA1                       1019 00102$:
                                   1020 ;	keyboards/ajazz/ak820/ak820_nvm.c:169: if (!batch_depth) ak820_nvm_flush();
      003FA1 90 05 5E         [24] 1021 	mov	dptr,#_batch_depth
      003FA4 E0               [24] 1022 	movx	a,@dptr
      003FA5 70 03            [24] 1023 	jnz	00105$
                                   1024 ;	keyboards/ajazz/ak820/ak820_nvm.c:170: }
      003FA7 02 3E 2B         [24] 1025 	ljmp	_ak820_nvm_flush
      003FAA                       1026 00105$:
      003FAA 22               [24] 1027 	ret
                                   1028 ;------------------------------------------------------------
                                   1029 ;Allocation info for local variables in function 'load_page'
                                   1030 ;------------------------------------------------------------
                                   1031 ;page          Allocated with name '_load_page_page_10000_87'
                                   1032 ;i             Allocated with name '_load_page_i_10000_88'
                                   1033 ;------------------------------------------------------------
                                   1034 ;	keyboards/ajazz/ak820/ak820_nvm.c:172: static bool load_page(uint8_t page) {
                                   1035 ;	-----------------------------------------
                                   1036 ;	 function load_page
                                   1037 ;	-----------------------------------------
      003FAB                       1038 _load_page:
      003FAB E5 82            [12] 1039 	mov	a,dpl
      003FAD 90 05 7F         [24] 1040 	mov	dptr,#_load_page_page_10000_87
      003FB0 F0               [24] 1041 	movx	@dptr,a
                                   1042 ;	keyboards/ajazz/ak820/ak820_nvm.c:174: if (page_valid && cached_page == page) return !storage_failed;
      003FB1 30 09 17         [24] 1043 	jnb	_page_valid,00102$
      003FB4 90 05 5D         [24] 1044 	mov	dptr,#_cached_page
      003FB7 E0               [24] 1045 	movx	a,@dptr
      003FB8 FF               [12] 1046 	mov	r7,a
      003FB9 90 05 7F         [24] 1047 	mov	dptr,#_load_page_page_10000_87
      003FBC E0               [24] 1048 	movx	a,@dptr
      003FBD FE               [12] 1049 	mov	r6,a
      003FBE EF               [12] 1050 	mov	a,r7
      003FBF B5 06 09         [24] 1051 	cjne	a,ar6,00102$
      003FC2 A2 0B            [12] 1052 	mov	c,_storage_failed
      003FC4 B3               [12] 1053 	cpl	c
      003FC5 92 0D            [24] 1054 	mov  _load_page_sloc0_1_0,c
      003FC7 12 38 B1         [24] 1055 	lcall	_ak820_outline_0159
      003FCA 22               [24] 1056 	ret
      003FCB                       1057 00102$:
                                   1058 ;	keyboards/ajazz/ak820/ak820_nvm.c:175: ak820_nvm_flush();
      003FCB 12 3E 2B         [24] 1059 	lcall	_ak820_nvm_flush
                                   1060 ;	keyboards/ajazz/ak820/ak820_nvm.c:176: if (storage_failed) return false;
      003FCE 30 0B 04         [24] 1061 	jnb	_storage_failed,00119$
      003FD1 75 82 00         [24] 1062 	mov	dpl, #0x00
                                   1063 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003FD4 22               [24] 1064 	ret
      003FD5                       1065 00119$:
      003FD5 7F 00            [12] 1066 	mov	r7,#0x00
      003FD7                       1067 00107$:
                                   1068 ;	keyboards/ajazz/ak820/ak820_nvm.c:178: page_data[i] = ak820_flash_read(AK820_NVM_BASE + page * AK820_FLASH_PAGE + i);
      003FD7 EF               [12] 1069 	mov	a,r7
      003FD8 24 1D            [12] 1070 	add	a, #_page_data
      003FDA FD               [12] 1071 	mov	r5,a
      003FDB E4               [12] 1072 	clr	a
      003FDC 34 05            [12] 1073 	addc	a, #(_page_data >> 8)
      003FDE FE               [12] 1074 	mov	r6,a
      003FDF 90 05 7F         [24] 1075 	mov	dptr,#_load_page_page_10000_87
      003FE2 E0               [24] 1076 	movx	a,@dptr
      003FE3 FC               [12] 1077 	mov	r4,a
      003FE4 FA               [12] 1078 	mov	r2,a
      003FE5 E4               [12] 1079 	clr	a
      003FE6 C3               [12] 1080 	clr	c
      003FE7 CA               [12] 1081 	xch	a,r2
      003FE8 13               [12] 1082 	rrc	a
      003FE9 CA               [12] 1083 	xch	a,r2
      003FEA 13               [12] 1084 	rrc	a
      003FEB A2 E0            [12] 1085 	mov	c,acc.0
      003FED CA               [12] 1086 	xch	a,r2
      003FEE 13               [12] 1087 	rrc	a
      003FEF CA               [12] 1088 	xch	a,r2
      003FF0 13               [12] 1089 	rrc	a
      003FF1 CA               [12] 1090 	xch	a,r2
      003FF2 24 C7            [12] 1091 	add	a,#0xc7
      003FF4 FB               [12] 1092 	mov	r3,a
      003FF5 8F 01            [24] 1093 	mov	ar1,r7
      003FF7 89 00            [24] 1094 	mov	ar0,r1
      003FF9 79 00            [12] 1095 	mov	r1,#0x00
      003FFB E8               [12] 1096 	mov	a,r0
      003FFC 2A               [12] 1097 	add	a, r2
      003FFD FA               [12] 1098 	mov	r2,a
      003FFE E9               [12] 1099 	mov	a,r1
      003FFF 3B               [12] 1100 	addc	a, r3
      004000 FB               [12] 1101 	mov	r3,a
      004001 12 38 AC         [24] 1102 	lcall	_ak820_outline_0145
      004004 12 38 EF         [24] 1103 	lcall	_ak820_flash_read
      004007 AB 82            [24] 1104 	mov	r3, dpl
      004009 12 38 9C         [24] 1105 	lcall	_ak820_outline_0135
      00400C EB               [12] 1106 	mov	a,r3
      00400D F0               [24] 1107 	movx	@dptr,a
                                   1108 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      00400E 0F               [12] 1109 	inc	r7
      00400F BF 40 C5         [24] 1110 	cjne	r7,#0x40,00107$
                                   1111 ;	keyboards/ajazz/ak820/ak820_nvm.c:180: cached_page = page;
      004012 90 05 5D         [24] 1112 	mov	dptr,#_cached_page
      004015 EC               [12] 1113 	mov	a,r4
      004016 F0               [24] 1114 	movx	@dptr,a
                                   1115 ;	keyboards/ajazz/ak820/ak820_nvm.c:181: page_valid = true;
                                   1116 ;	assignBit
      004017 D2 09            [12] 1117 	setb	_page_valid
                                   1118 ;	keyboards/ajazz/ak820/ak820_nvm.c:182: return true;
      004019 75 82 01         [24] 1119 	mov	dpl, #0x01
                                   1120 ;	keyboards/ajazz/ak820/ak820_nvm.c:183: }
      00401C 22               [24] 1121 	ret
                                   1122 ;------------------------------------------------------------
                                   1123 ;Allocation info for local variables in function 'read_offset'
                                   1124 ;------------------------------------------------------------
                                   1125 ;offset        Allocated with name '_read_offset_offset_10000_93'
                                   1126 ;------------------------------------------------------------
                                   1127 ;	keyboards/ajazz/ak820/ak820_nvm.c:185: static uint8_t read_offset(uint16_t offset) {
                                   1128 ;	-----------------------------------------
                                   1129 ;	 function read_offset
                                   1130 ;	-----------------------------------------
      00401D                       1131 _read_offset:
      00401D 12 38 88         [24] 1132 	lcall	_ak820_outline_0110
      004020 90 05 80         [24] 1133 	mov	dptr,#_read_offset_offset_10000_93
      004023 12 38 8D         [24] 1134 	lcall	_ak820_outline_0111
                                   1135 ;	keyboards/ajazz/ak820/ak820_nvm.c:186: if (offset >= AK820_NVM_SIZE) return 0;
      004026 90 05 80         [24] 1136 	mov	dptr,#_read_offset_offset_10000_93
      004029 12 38 41         [24] 1137 	lcall	_ak820_outline_0052
      00402C C3               [12] 1138 	clr	c
      00402D 94 28            [12] 1139 	subb	a,#0x28
      00402F 40 04            [24] 1140 	jc	00102$
      004031 75 82 00         [24] 1141 	mov	dpl, #0x00
      004034 22               [24] 1142 	ret
      004035                       1143 00102$:
                                   1144 ;	keyboards/ajazz/ak820/ak820_nvm.c:187: if (page_valid && (offset / AK820_FLASH_PAGE) == cached_page)
      004035 30 09 34         [24] 1145 	jnb	_page_valid,00104$
      004038 8E 04            [24] 1146 	mov	ar4,r6
      00403A EF               [12] 1147 	mov	a,r7
      00403B A2 E7            [12] 1148 	mov	c,acc.7
      00403D CC               [12] 1149 	xch	a,r4
      00403E 33               [12] 1150 	rlc	a
      00403F CC               [12] 1151 	xch	a,r4
      004040 33               [12] 1152 	rlc	a
      004041 A2 E7            [12] 1153 	mov	c,acc.7
      004043 CC               [12] 1154 	xch	a,r4
      004044 33               [12] 1155 	rlc	a
      004045 CC               [12] 1156 	xch	a,r4
      004046 33               [12] 1157 	rlc	a
      004047 CC               [12] 1158 	xch	a,r4
      004048 54 03            [12] 1159 	anl	a,#0x03
      00404A FD               [12] 1160 	mov	r5,a
      00404B 90 05 5D         [24] 1161 	mov	dptr,#_cached_page
      00404E E0               [24] 1162 	movx	a,@dptr
      00404F FA               [12] 1163 	mov	r2,a
      004050 7B 00            [12] 1164 	mov	r3,#0x00
      004052 EC               [12] 1165 	mov	a,r4
      004053 B5 02 16         [24] 1166 	cjne	a,ar2,00104$
      004056 ED               [12] 1167 	mov	a,r5
      004057 B5 03 12         [24] 1168 	cjne	a,ar3,00104$
                                   1169 ;	keyboards/ajazz/ak820/ak820_nvm.c:188: return page_data[offset % AK820_FLASH_PAGE];
      00405A 74 3F            [12] 1170 	mov	a,#0x3f
      00405C 5E               [12] 1171 	anl	a,r6
      00405D 7D 00            [12] 1172 	mov	r5,#0x00
      00405F 24 1D            [12] 1173 	add	a, #_page_data
      004061 F5 82            [12] 1174 	mov	dpl,a
      004063 ED               [12] 1175 	mov	a,r5
      004064 34 05            [12] 1176 	addc	a, #(_page_data >> 8)
      004066 F5 83            [12] 1177 	mov	dph,a
      004068 E0               [24] 1178 	movx	a,@dptr
      004069 F5 82            [12] 1179 	mov	dpl,a
      00406B 22               [24] 1180 	ret
      00406C                       1181 00104$:
                                   1182 ;	keyboards/ajazz/ak820/ak820_nvm.c:189: return ak820_flash_read(AK820_NVM_BASE + offset);
      00406C 74 C7            [12] 1183 	mov	a,#0xc7
      00406E 2F               [12] 1184 	add	a, r7
      00406F FF               [12] 1185 	mov	r7,a
      004070 12 38 92         [24] 1186 	lcall	_ak820_outline_0121
                                   1187 ;	keyboards/ajazz/ak820/ak820_nvm.c:190: }
      004073 02 38 EF         [24] 1188 	ljmp	_ak820_flash_read
                                   1189 ;------------------------------------------------------------
                                   1190 ;Allocation info for local variables in function 'eeprom_read_byte'
                                   1191 ;------------------------------------------------------------
                                   1192 ;addr          Allocated with name '_eeprom_read_byte_addr_10000_97'
                                   1193 ;------------------------------------------------------------
                                   1194 ;	keyboards/ajazz/ak820/ak820_nvm.c:193: uint8_t eeprom_read_byte(const uint8_t *addr) {
                                   1195 ;	-----------------------------------------
                                   1196 ;	 function eeprom_read_byte
                                   1197 ;	-----------------------------------------
      004076                       1198 _eeprom_read_byte:
      004076 C0 07            [24] 1199 	push	ar7
      004078 C0 06            [24] 1200 	push	ar6
      00407A 12 43 15         [24] 1201 	lcall	_ak820_outline_0036
      00407D 90 05 82         [24] 1202 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      004080 12 38 1F         [24] 1203 	lcall	_ak820_outline_0016
                                   1204 ;	keyboards/ajazz/ak820/ak820_nvm.c:194: return read_offset((uint16_t)(uintptr_t)addr);
      004083 90 05 82         [24] 1205 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      004086 12 37 F4         [24] 1206 	lcall	_ak820_outline_0005
      004089 C0 06            [24] 1207 	push	ar6
      00408B C0 05            [24] 1208 	push	ar5
      00408D C0 04            [24] 1209 	push	ar4
      00408F C0 03            [24] 1210 	push	ar3
      004091 C0 02            [24] 1211 	push	ar2
      004093 C0 01            [24] 1212 	push	ar1
      004095 C0 00            [24] 1213 	push	ar0
      004097 12 40 1D         [24] 1214 	lcall	_read_offset
      00409A AF 82            [24] 1215 	mov	r7, dpl
      00409C D0 00            [24] 1216 	pop	ar0
      00409E D0 01            [24] 1217 	pop	ar1
      0040A0 D0 02            [24] 1218 	pop	ar2
      0040A2 D0 03            [24] 1219 	pop	ar3
      0040A4 D0 04            [24] 1220 	pop	ar4
      0040A6 D0 05            [24] 1221 	pop	ar5
      0040A8 D0 06            [24] 1222 	pop	ar6
      0040AA 8F 82            [24] 1223 	mov	dpl, r7
                                   1224 ;	keyboards/ajazz/ak820/ak820_nvm.c:195: }
      0040AC D0 06            [24] 1225 	pop	ar6
      0040AE D0 07            [24] 1226 	pop	ar7
      0040B0 22               [24] 1227 	ret
                                   1228 ;------------------------------------------------------------
                                   1229 ;Allocation info for local variables in function 'eeprom_read_block'
                                   1230 ;------------------------------------------------------------
                                   1231 ;addr          Allocated with name '_eeprom_read_block_PARM_2'
                                   1232 ;len           Allocated with name '_eeprom_read_block_PARM_3'
                                   1233 ;buf           Allocated with name '_eeprom_read_block_buf_10000_99'
                                   1234 ;offset        Allocated with name '_eeprom_read_block_offset_10000_100'
                                   1235 ;out           Allocated with name '_eeprom_read_block_out_10000_100'
                                   1236 ;------------------------------------------------------------
                                   1237 ;	keyboards/ajazz/ak820/ak820_nvm.c:199: void eeprom_read_block(void *buf, const void *addr, size_t len) {
                                   1238 ;	-----------------------------------------
                                   1239 ;	 function ak820_eeprom_read_block_xdata
                                   1240 ;	-----------------------------------------
      0040B1                       1241 _ak820_eeprom_read_block_xdata:
      0040B1 12 38 88         [24] 1242 	lcall	_ak820_outline_0110
      0040B4 90 05 8A         [24] 1243 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      0040B7 12 38 8D         [24] 1244 	lcall	_ak820_outline_0111
                                   1245 ;	keyboards/ajazz/ak820/ak820_nvm.c:230: uint16_t offset = (uint16_t)(uintptr_t)addr;
      0040BA 90 05 85         [24] 1246 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      0040BD 12 38 41         [24] 1247 	lcall	_ak820_outline_0052
                                   1248 ;	keyboards/ajazz/ak820/ak820_nvm.c:231: uint8_t AK820_XDATA *out = (uint8_t AK820_XDATA *)buf;
      0040C0 90 05 8A         [24] 1249 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      0040C3 12 38 58         [24] 1250 	lcall	_ak820_outline_0061
      0040C6 90 05 8C         [24] 1251 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0040C9 12 38 5E         [24] 1252 	lcall	_ak820_outline_0072
                                   1253 ;	keyboards/ajazz/ak820/ak820_nvm.c:232: while (len--) {
      0040CC 90 05 88         [24] 1254 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      0040CF 12 38 58         [24] 1255 	lcall	_ak820_outline_0061
      0040D2                       1256 00103$:
      0040D2 8C 02            [24] 1257 	mov	ar2,r4
      0040D4 8D 03            [24] 1258 	mov	ar3,r5
      0040D6 1C               [12] 1259 	dec	r4
      0040D7 BC FF 01         [24] 1260 	cjne	r4,#0xff,00130$
      0040DA 1D               [12] 1261 	dec	r5
      0040DB                       1262 00130$:
      0040DB EA               [12] 1263 	mov	a,r2
      0040DC 4B               [12] 1264 	orl	a,r3
      0040DD 60 5D            [24] 1265 	jz	00106$
                                   1266 ;	keyboards/ajazz/ak820/ak820_nvm.c:233: if (offset >= AK820_NVM_SIZE) { *out++ = 0; continue; }
      0040DF 8E 02            [24] 1267 	mov	ar2,r6
      0040E1 8F 03            [24] 1268 	mov	ar3,r7
      0040E3 74 D8            [12] 1269 	mov	a,#0x100 - 0x28
      0040E5 2B               [12] 1270 	add	a,r3
      0040E6 50 17            [24] 1271 	jnc	00102$
      0040E8 90 05 8C         [24] 1272 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0040EB 12 43 45         [24] 1273 	lcall	_ak820_outline_0105
      0040EE 12 38 AC         [24] 1274 	lcall	_ak820_outline_0145
      0040F1 E4               [12] 1275 	clr	a
      0040F2 F0               [24] 1276 	movx	@dptr,a
      0040F3 90 05 8C         [24] 1277 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0040F6 04               [12] 1278 	inc	a
      0040F7 2A               [12] 1279 	add	a, r2
      0040F8 F0               [24] 1280 	movx	@dptr,a
      0040F9 E4               [12] 1281 	clr	a
      0040FA 3B               [12] 1282 	addc	a, r3
      0040FB A3               [24] 1283 	inc	dptr
      0040FC F0               [24] 1284 	movx	@dptr,a
      0040FD 80 D3            [24] 1285 	sjmp	00103$
      0040FF                       1286 00102$:
                                   1287 ;	keyboards/ajazz/ak820/ak820_nvm.c:234: *out++ = read_offset(offset);
      0040FF 90 05 8C         [24] 1288 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004102 12 43 45         [24] 1289 	lcall	_ak820_outline_0105
      004105 12 38 92         [24] 1290 	lcall	_ak820_outline_0121
      004108 C0 07            [24] 1291 	push	ar7
      00410A C0 06            [24] 1292 	push	ar6
      00410C C0 05            [24] 1293 	push	ar5
      00410E C0 04            [24] 1294 	push	ar4
      004110 C0 03            [24] 1295 	push	ar3
      004112 C0 02            [24] 1296 	push	ar2
      004114 12 40 1D         [24] 1297 	lcall	_read_offset
      004117 A9 82            [24] 1298 	mov	r1, dpl
      004119 D0 02            [24] 1299 	pop	ar2
      00411B D0 03            [24] 1300 	pop	ar3
      00411D D0 04            [24] 1301 	pop	ar4
      00411F D0 05            [24] 1302 	pop	ar5
      004121 D0 06            [24] 1303 	pop	ar6
      004123 D0 07            [24] 1304 	pop	ar7
      004125 12 38 AC         [24] 1305 	lcall	_ak820_outline_0145
      004128 E9               [12] 1306 	mov	a,r1
      004129 F0               [24] 1307 	movx	@dptr,a
      00412A 90 05 8C         [24] 1308 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      00412D 74 01            [12] 1309 	mov	a,#0x01
      00412F 2A               [12] 1310 	add	a, r2
      004130 F0               [24] 1311 	movx	@dptr,a
      004131 E4               [12] 1312 	clr	a
      004132 3B               [12] 1313 	addc	a, r3
      004133 A3               [24] 1314 	inc	dptr
      004134 F0               [24] 1315 	movx	@dptr,a
                                   1316 ;	keyboards/ajazz/ak820/ak820_nvm.c:235: ++offset;
      004135 0E               [12] 1317 	inc	r6
      004136 BE 00 99         [24] 1318 	cjne	r6,#0x00,00103$
      004139 0F               [12] 1319 	inc	r7
      00413A 80 96            [24] 1320 	sjmp	00103$
      00413C                       1321 00106$:
                                   1322 ;	keyboards/ajazz/ak820/ak820_nvm.c:237: }
      00413C 22               [24] 1323 	ret
                                   1324 ;------------------------------------------------------------
                                   1325 ;Allocation info for local variables in function 'ak820_eeprom_write_block_xdata'
                                   1326 ;------------------------------------------------------------
                                   1327 ;sloc0         Allocated with name '_ak820_eeprom_write_block_xdata_sloc0_1_0'
                                   1328 ;addr          Allocated with name '_ak820_eeprom_write_block_xdata_PARM_2'
                                   1329 ;len           Allocated with name '_ak820_eeprom_write_block_xdata_PARM_3'
                                   1330 ;buf           Allocated with name '_ak820_eeprom_write_block_xdata_buf_10000_118'
                                   1331 ;offset        Allocated with name '_ak820_eeprom_write_block_xdata_offset_10000_119'
                                   1332 ;in            Allocated with name '_ak820_eeprom_write_block_xdata_in_10000_119'
                                   1333 ;value         Allocated with name '_ak820_eeprom_write_block_xdata_value_20000_122'
                                   1334 ;------------------------------------------------------------
                                   1335 ;	keyboards/ajazz/ak820/ak820_nvm.c:239: void ak820_eeprom_write_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1336 ;	-----------------------------------------
                                   1337 ;	 function ak820_eeprom_write_block_xdata
                                   1338 ;	-----------------------------------------
      00413D                       1339 _ak820_eeprom_write_block_xdata:
      00413D 12 38 88         [24] 1340 	lcall	_ak820_outline_0110
      004140 90 05 93         [24] 1341 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      004143 12 38 8D         [24] 1342 	lcall	_ak820_outline_0111
                                   1343 ;	keyboards/ajazz/ak820/ak820_nvm.c:240: uint16_t offset = (uint16_t)(uintptr_t)addr;
      004146 90 05 8E         [24] 1344 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      004149 12 38 41         [24] 1345 	lcall	_ak820_outline_0052
                                   1346 ;	keyboards/ajazz/ak820/ak820_nvm.c:241: const uint8_t AK820_XDATA *in = (const uint8_t AK820_XDATA *)buf;
      00414C 90 05 93         [24] 1347 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      00414F 12 38 58         [24] 1348 	lcall	_ak820_outline_0061
                                   1349 ;	keyboards/ajazz/ak820/ak820_nvm.c:243: if (offset > AK820_NVM_SIZE || len > AK820_NVM_SIZE - offset) {
      004152 8E 02            [24] 1350 	mov	ar2,r6
      004154 8F 03            [24] 1351 	mov	ar3,r7
      004156 C3               [12] 1352 	clr	c
      004157 E4               [12] 1353 	clr	a
      004158 9A               [12] 1354 	subb	a,r2
      004159 74 28            [12] 1355 	mov	a,#0x28
      00415B 9B               [12] 1356 	subb	a,r3
      00415C 40 15            [24] 1357 	jc	00101$
                                   1358 ;	free result
      00415E E4               [12] 1359 	clr	a
      00415F C3               [12] 1360 	clr	c
      004160 9E               [12] 1361 	subb	a,r6
      004161 FA               [12] 1362 	mov	r2,a
      004162 74 28            [12] 1363 	mov	a,#0x28
      004164 9F               [12] 1364 	subb	a,r7
      004165 FB               [12] 1365 	mov	r3,a
      004166 90 05 91         [24] 1366 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004169 12 38 7C         [24] 1367 	lcall	_ak820_outline_0104
      00416C C3               [12] 1368 	clr	c
      00416D EA               [12] 1369 	mov	a,r2
      00416E 98               [12] 1370 	subb	a,r0
      00416F EB               [12] 1371 	mov	a,r3
      004170 99               [12] 1372 	subb	a,r1
      004171 50 06            [24] 1373 	jnc	00125$
                                   1374 ;	free result
      004173                       1375 00101$:
                                   1376 ;	keyboards/ajazz/ak820/ak820_nvm.c:244: nvm_fail(AK820_NVM_FAULT_WRITE_RANGE);
      004173 75 82 0E         [24] 1377 	mov	dpl, #0x0e
                                   1378 ;	keyboards/ajazz/ak820/ak820_nvm.c:245: return;
      004176 02 3B 83         [24] 1379 	ljmp	_nvm_fail
                                   1380 ;	keyboards/ajazz/ak820/ak820_nvm.c:247: while (len--) {
      004179                       1381 00125$:
      004179 90 05 91         [24] 1382 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      00417C 12 43 45         [24] 1383 	lcall	_ak820_outline_0105
      00417F                       1384 00108$:
      00417F 8A 00            [24] 1385 	mov	ar0,r2
      004181 8B 01            [24] 1386 	mov	ar1,r3
      004183 1A               [12] 1387 	dec	r2
      004184 BA FF 01         [24] 1388 	cjne	r2,#0xff,00159$
      004187 1B               [12] 1389 	dec	r3
      004188                       1390 00159$:
      004188 E8               [12] 1391 	mov	a,r0
      004189 49               [12] 1392 	orl	a,r1
      00418A 70 03            [24] 1393 	jnz	00160$
      00418C 02 42 16         [24] 1394 	ljmp	00110$
      00418F                       1395 00160$:
                                   1396 ;	keyboards/ajazz/ak820/ak820_nvm.c:248: uint8_t value = *in++;
      00418F C0 02            [24] 1397 	push	ar2
      004191 C0 03            [24] 1398 	push	ar3
      004193 12 43 3F         [24] 1399 	lcall	_ak820_outline_0096
      004196 F9               [12] 1400 	mov	r1,a
      004197 A3               [24] 1401 	inc	dptr
      004198 12 43 68         [24] 1402 	lcall	_ak820_outline_0151
                                   1403 ;	keyboards/ajazz/ak820/ak820_nvm.c:249: if (!load_page(offset / AK820_FLASH_PAGE)) return;
      00419B 8E 0C            [24] 1404 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,r6
      00419D 8F 0D            [24] 1405 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),r7
      00419F A8 0C            [24] 1406 	mov	r0,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0041A1 E5 0D            [12] 1407 	mov	a,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      0041A3 A2 E7            [12] 1408 	mov	c,acc.7
      0041A5 C8               [12] 1409 	xch	a,r0
      0041A6 33               [12] 1410 	rlc	a
      0041A7 C8               [12] 1411 	xch	a,r0
      0041A8 33               [12] 1412 	rlc	a
      0041A9 A2 E7            [12] 1413 	mov	c,acc.7
      0041AB C8               [12] 1414 	xch	a,r0
      0041AC 33               [12] 1415 	rlc	a
      0041AD C8               [12] 1416 	xch	a,r0
      0041AE 33               [12] 1417 	rlc	a
      0041AF C8               [12] 1418 	xch	a,r0
      0041B0 54 03            [12] 1419 	anl	a,#0x03
      0041B2 FB               [12] 1420 	mov	r3,a
      0041B3 88 82            [24] 1421 	mov	dpl, r0
      0041B5 C0 07            [24] 1422 	push	ar7
      0041B7 C0 06            [24] 1423 	push	ar6
      0041B9 C0 05            [24] 1424 	push	ar5
      0041BB C0 04            [24] 1425 	push	ar4
      0041BD C0 03            [24] 1426 	push	ar3
      0041BF C0 02            [24] 1427 	push	ar2
      0041C1 C0 01            [24] 1428 	push	ar1
      0041C3 12 3F AB         [24] 1429 	lcall	_load_page
      0041C6 E5 82            [12] 1430 	mov	a, dpl
      0041C8 D0 01            [24] 1431 	pop	ar1
      0041CA D0 02            [24] 1432 	pop	ar2
      0041CC D0 03            [24] 1433 	pop	ar3
      0041CE D0 04            [24] 1434 	pop	ar4
      0041D0 D0 05            [24] 1435 	pop	ar5
      0041D2 D0 06            [24] 1436 	pop	ar6
      0041D4 D0 07            [24] 1437 	pop	ar7
      0041D6 D0 03            [24] 1438 	pop	ar3
      0041D8 D0 02            [24] 1439 	pop	ar2
      0041DA 70 01            [24] 1440 	jnz	00105$
      0041DC 22               [24] 1441 	ret
      0041DD                       1442 00105$:
                                   1443 ;	keyboards/ajazz/ak820/ak820_nvm.c:250: if (page_data[offset % AK820_FLASH_PAGE] != value) {
      0041DD C0 06            [24] 1444 	push	ar6
      0041DF C0 07            [24] 1445 	push	ar7
      0041E1 74 3F            [12] 1446 	mov	a,#0x3f
      0041E3 55 0C            [12] 1447 	anl	a,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0041E5 7F 00            [12] 1448 	mov	r7,#0x00
      0041E7 24 1D            [12] 1449 	add	a, #_page_data
      0041E9 F5 0C            [12] 1450 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,a
      0041EB EF               [12] 1451 	mov	a,r7
      0041EC 34 05            [12] 1452 	addc	a, #(_page_data >> 8)
      0041EE F5 0D            [12] 1453 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),a
      0041F0 85 0C 82         [24] 1454 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0041F3 85 0D 83         [24] 1455 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      0041F6 E0               [24] 1456 	movx	a,@dptr
      0041F7 B5 01 06         [24] 1457 	cjne	a,ar1,00162$
      0041FA D0 07            [24] 1458 	pop	ar7
      0041FC D0 06            [24] 1459 	pop	ar6
      0041FE 80 0E            [24] 1460 	sjmp	00107$
      004200                       1461 00162$:
      004200 D0 07            [24] 1462 	pop	ar7
      004202 D0 06            [24] 1463 	pop	ar6
                                   1464 ;	keyboards/ajazz/ak820/ak820_nvm.c:251: page_data[offset % AK820_FLASH_PAGE] = value;
      004204 85 0C 82         [24] 1465 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      004207 85 0D 83         [24] 1466 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      00420A E9               [12] 1467 	mov	a,r1
      00420B F0               [24] 1468 	movx	@dptr,a
                                   1469 ;	keyboards/ajazz/ak820/ak820_nvm.c:252: page_dirty = true;
                                   1470 ;	assignBit
      00420C D2 0A            [12] 1471 	setb	_page_dirty
      00420E                       1472 00107$:
                                   1473 ;	keyboards/ajazz/ak820/ak820_nvm.c:254: ++offset;
      00420E 0E               [12] 1474 	inc	r6
      00420F BE 00 01         [24] 1475 	cjne	r6,#0x00,00163$
      004212 0F               [12] 1476 	inc	r7
      004213                       1477 00163$:
      004213 02 41 7F         [24] 1478 	ljmp	00108$
      004216                       1479 00110$:
                                   1480 ;	keyboards/ajazz/ak820/ak820_nvm.c:256: if (!batch_depth) ak820_nvm_flush();
      004216 90 05 5E         [24] 1481 	mov	dptr,#_batch_depth
      004219 E0               [24] 1482 	movx	a,@dptr
      00421A 70 03            [24] 1483 	jnz	00113$
                                   1484 ;	keyboards/ajazz/ak820/ak820_nvm.c:257: }
      00421C 02 3E 2B         [24] 1485 	ljmp	_ak820_nvm_flush
      00421F                       1486 00113$:
      00421F 22               [24] 1487 	ret
                                   1488 ;------------------------------------------------------------
                                   1489 ;Allocation info for local variables in function 'ak820_eeprom_update_block_xdata'
                                   1490 ;------------------------------------------------------------
                                   1491 ;sloc0         Allocated with name '_ak820_eeprom_update_block_xdata_sloc0_1_0'
                                   1492 ;sloc1         Allocated with name '_ak820_eeprom_update_block_xdata_sloc1_1_0'
                                   1493 ;sloc2         Allocated with name '_ak820_eeprom_update_block_xdata_sloc2_1_0'
                                   1494 ;addr          Allocated with name '_ak820_eeprom_update_block_xdata_PARM_2'
                                   1495 ;len           Allocated with name '_ak820_eeprom_update_block_xdata_PARM_3'
                                   1496 ;buf           Allocated with name '_ak820_eeprom_update_block_xdata_buf_10000_127'
                                   1497 ;source        Allocated with name '_ak820_eeprom_update_block_xdata_source_10000_128'
                                   1498 ;offset        Allocated with name '_ak820_eeprom_update_block_xdata_offset_10000_128'
                                   1499 ;i             Allocated with name '_ak820_eeprom_update_block_xdata_i_10000_128'
                                   1500 ;------------------------------------------------------------
                                   1501 ;	keyboards/ajazz/ak820/ak820_nvm.c:259: void ak820_eeprom_update_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1502 ;	-----------------------------------------
                                   1503 ;	 function ak820_eeprom_update_block_xdata
                                   1504 ;	-----------------------------------------
      004220                       1505 _ak820_eeprom_update_block_xdata:
      004220 12 38 88         [24] 1506 	lcall	_ak820_outline_0110
      004223 90 05 9A         [24] 1507 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      004226 12 38 8D         [24] 1508 	lcall	_ak820_outline_0111
                                   1509 ;	keyboards/ajazz/ak820/ak820_nvm.c:260: const uint8_t AK820_XDATA *source = (const uint8_t AK820_XDATA *)buf;
      004229 90 05 9A         [24] 1510 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      00422C 12 38 41         [24] 1511 	lcall	_ak820_outline_0052
                                   1512 ;	keyboards/ajazz/ak820/ak820_nvm.c:261: uint16_t offset = (uint16_t)(uintptr_t)addr;
      00422F 90 05 95         [24] 1513 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      004232 E0               [24] 1514 	movx	a,@dptr
      004233 F5 12            [12] 1515 	mov	_ak820_eeprom_update_block_xdata_sloc2_1_0,a
      004235 A3               [24] 1516 	inc	dptr
      004236 E0               [24] 1517 	movx	a,@dptr
      004237 F5 13            [12] 1518 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1),a
      004239 A3               [24] 1519 	inc	dptr
      00423A E0               [24] 1520 	movx	a,@dptr
      00423B F5 14            [12] 1521 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2),a
      00423D A9 12            [24] 1522 	mov	r1,_ak820_eeprom_update_block_xdata_sloc2_1_0
      00423F AA 13            [24] 1523 	mov	r2,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
                                   1524 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      004241 E4               [12] 1525 	clr	a
      004242 F5 0E            [12] 1526 	mov	_ak820_eeprom_update_block_xdata_sloc0_1_0,a
      004244 F5 0F            [12] 1527 	mov	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1),a
      004246                       1528 00105$:
      004246 90 05 98         [24] 1529 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      004249 E0               [24] 1530 	movx	a,@dptr
      00424A F5 10            [12] 1531 	mov	_ak820_eeprom_update_block_xdata_sloc1_1_0,a
      00424C A3               [24] 1532 	inc	dptr
      00424D E0               [24] 1533 	movx	a,@dptr
      00424E F5 11            [12] 1534 	mov	(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1),a
      004250 C3               [12] 1535 	clr	c
      004251 E5 0E            [12] 1536 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      004253 95 10            [12] 1537 	subb	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      004255 E5 0F            [12] 1538 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      004257 95 11            [12] 1539 	subb	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      004259 50 68            [24] 1540 	jnc	00107$
                                   1541 ;	keyboards/ajazz/ak820/ak820_nvm.c:264: if (read_offset(offset + i) != source[i]) {
      00425B 89 00            [24] 1542 	mov	ar0,r1
      00425D 8A 05            [24] 1543 	mov	ar5,r2
      00425F E5 0E            [12] 1544 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      004261 28               [12] 1545 	add	a, r0
      004262 F8               [12] 1546 	mov	r0,a
      004263 E5 0F            [12] 1547 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      004265 3D               [12] 1548 	addc	a, r5
      004266 FD               [12] 1549 	mov	r5,a
      004267 88 82            [24] 1550 	mov	dpl, r0
      004269 8D 83            [24] 1551 	mov	dph, r5
      00426B C0 07            [24] 1552 	push	ar7
      00426D C0 06            [24] 1553 	push	ar6
      00426F C0 02            [24] 1554 	push	ar2
      004271 C0 01            [24] 1555 	push	ar1
      004273 12 40 1D         [24] 1556 	lcall	_read_offset
      004276 AD 82            [24] 1557 	mov	r5, dpl
      004278 D0 01            [24] 1558 	pop	ar1
      00427A D0 02            [24] 1559 	pop	ar2
      00427C D0 06            [24] 1560 	pop	ar6
      00427E D0 07            [24] 1561 	pop	ar7
      004280 E5 0E            [12] 1562 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      004282 2E               [12] 1563 	add	a, r6
      004283 F5 82            [12] 1564 	mov	dpl,a
      004285 E5 0F            [12] 1565 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      004287 3F               [12] 1566 	addc	a, r7
      004288 F5 83            [12] 1567 	mov	dph,a
      00428A E0               [24] 1568 	movx	a,@dptr
      00428B FC               [12] 1569 	mov	r4,a
      00428C ED               [12] 1570 	mov	a,r5
      00428D B5 04 02         [24] 1571 	cjne	a,ar4,00131$
      004290 80 27            [24] 1572 	sjmp	00106$
      004292                       1573 00131$:
                                   1574 ;	keyboards/ajazz/ak820/ak820_nvm.c:265: ak820_eeprom_write_block_xdata(buf, addr, len);
      004292 90 05 9A         [24] 1575 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      004295 E0               [24] 1576 	movx	a,@dptr
      004296 F8               [12] 1577 	mov	r0,a
      004297 A3               [24] 1578 	inc	dptr
      004298 E0               [24] 1579 	movx	a,@dptr
      004299 FD               [12] 1580 	mov	r5,a
      00429A 90 05 8E         [24] 1581 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      00429D E5 12            [12] 1582 	mov	a,_ak820_eeprom_update_block_xdata_sloc2_1_0
      00429F F0               [24] 1583 	movx	@dptr,a
      0042A0 E5 13            [12] 1584 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
      0042A2 A3               [24] 1585 	inc	dptr
      0042A3 F0               [24] 1586 	movx	@dptr,a
      0042A4 E5 14            [12] 1587 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2)
      0042A6 A3               [24] 1588 	inc	dptr
      0042A7 F0               [24] 1589 	movx	@dptr,a
      0042A8 90 05 91         [24] 1590 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0042AB E5 10            [12] 1591 	mov	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      0042AD F0               [24] 1592 	movx	@dptr,a
      0042AE E5 11            [12] 1593 	mov	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      0042B0 A3               [24] 1594 	inc	dptr
      0042B1 F0               [24] 1595 	movx	@dptr,a
      0042B2 88 82            [24] 1596 	mov	dpl, r0
      0042B4 8D 83            [24] 1597 	mov	dph, r5
                                   1598 ;	keyboards/ajazz/ak820/ak820_nvm.c:266: return;
      0042B6 02 41 3D         [24] 1599 	ljmp	_ak820_eeprom_write_block_xdata
      0042B9                       1600 00106$:
                                   1601 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      0042B9 05 0E            [12] 1602 	inc	_ak820_eeprom_update_block_xdata_sloc0_1_0
      0042BB E4               [12] 1603 	clr	a
      0042BC B5 0E 87         [24] 1604 	cjne	a,_ak820_eeprom_update_block_xdata_sloc0_1_0,00105$
      0042BF 05 0F            [12] 1605 	inc	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      0042C1 80 83            [24] 1606 	sjmp	00105$
      0042C3                       1607 00107$:
                                   1608 ;	keyboards/ajazz/ak820/ak820_nvm.c:269: }
      0042C3 22               [24] 1609 	ret
                                   1610 ;------------------------------------------------------------
                                   1611 ;Allocation info for local variables in function 'eeprom_driver_erase'
                                   1612 ;------------------------------------------------------------
                                   1613 ;page          Allocated with name '_eeprom_driver_erase_page_10000_134'
                                   1614 ;i             Allocated with name '_eeprom_driver_erase_i_10000_134'
                                   1615 ;------------------------------------------------------------
                                   1616 ;	keyboards/ajazz/ak820/ak820_nvm.c:271: void eeprom_driver_erase(void) {
                                   1617 ;	-----------------------------------------
                                   1618 ;	 function eeprom_driver_erase
                                   1619 ;	-----------------------------------------
      0042C4                       1620 _eeprom_driver_erase:
                                   1621 ;	keyboards/ajazz/ak820/ak820_nvm.c:274: ak820_nvm_flush();
      0042C4 12 3E 2B         [24] 1622 	lcall	_ak820_nvm_flush
                                   1623 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      0042C7 7F 00            [12] 1624 	mov	r7,#0x00
      0042C9                       1625 00111$:
      0042C9 BF A0 01         [24] 1626 	cjne	r7,#0xa0,00165$
      0042CC 22               [24] 1627 	ret
      0042CD                       1628 00165$:
      0042CD 20 0B 32         [24] 1629 	jb	_storage_failed,00113$
                                   1630 ;	keyboards/ajazz/ak820/ak820_nvm.c:276: if (!load_page(page)) return;
      0042D0 8F 82            [24] 1631 	mov	dpl, r7
      0042D2 C0 07            [24] 1632 	push	ar7
      0042D4 12 3F AB         [24] 1633 	lcall	_load_page
      0042D7 E5 82            [12] 1634 	mov	a, dpl
      0042D9 D0 07            [24] 1635 	pop	ar7
      0042DB 70 01            [24] 1636 	jnz	00126$
                                   1637 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      0042DD 22               [24] 1638 	ret
      0042DE                       1639 00126$:
      0042DE 7E 00            [12] 1640 	mov	r6,#0x00
      0042E0                       1641 00107$:
                                   1642 ;	keyboards/ajazz/ak820/ak820_nvm.c:278: if (page_data[i]) { page_data[i] = 0; page_dirty = true; }
      0042E0 EE               [12] 1643 	mov	a,r6
      0042E1 24 1D            [12] 1644 	add	a, #_page_data
      0042E3 FC               [12] 1645 	mov	r4,a
      0042E4 E4               [12] 1646 	clr	a
      0042E5 34 05            [12] 1647 	addc	a, #(_page_data >> 8)
      0042E7 FD               [12] 1648 	mov	r5,a
      0042E8 12 43 3F         [24] 1649 	lcall	_ak820_outline_0096
      0042EB 60 07            [24] 1650 	jz	00108$
      0042ED 12 38 97         [24] 1651 	lcall	_ak820_outline_0126
      0042F0 E4               [12] 1652 	clr	a
      0042F1 F0               [24] 1653 	movx	@dptr,a
                                   1654 ;	assignBit
      0042F2 D2 0A            [12] 1655 	setb	_page_dirty
      0042F4                       1656 00108$:
                                   1657 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      0042F4 0E               [12] 1658 	inc	r6
      0042F5 BE 40 E8         [24] 1659 	cjne	r6,#0x40,00107$
                                   1660 ;	keyboards/ajazz/ak820/ak820_nvm.c:280: ak820_nvm_flush();
      0042F8 C0 07            [24] 1661 	push	ar7
      0042FA 12 3E 2B         [24] 1662 	lcall	_ak820_nvm_flush
      0042FD D0 07            [24] 1663 	pop	ar7
                                   1664 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      0042FF 0F               [12] 1665 	inc	r7
      004300 80 C7            [24] 1666 	sjmp	00111$
      004302                       1667 00113$:
                                   1668 ;	keyboards/ajazz/ak820/ak820_nvm.c:282: }
      004302 22               [24] 1669 	ret
                                   1670 	.area CSEG    (CODE)
                                   1671 	.area CONST   (CODE)
                                   1672 	.area XINIT   (CODE)
                                   1673 	.area CABS    (ABS,CODE)
                                   1674 
                                   1675 ; Experimental exact instruction outlining.
                                   1676 	.globl _ak820_outline_0005
                                   1677 	.globl _ak820_outline_0011
                                   1678 	.globl _ak820_outline_0016
                                   1679 	.globl _ak820_outline_0021
                                   1680 	.globl _ak820_outline_0031
                                   1681 	.globl _ak820_outline_0036
                                   1682 	.globl _ak820_outline_0043
                                   1683 	.globl _ak820_outline_0052
                                   1684 	.globl _ak820_outline_0053
                                   1685 	.globl _ak820_outline_0061
                                   1686 	.globl _ak820_outline_0072
                                   1687 	.globl _ak820_outline_0078
                                   1688 	.globl _ak820_outline_0084
                                   1689 	.globl _ak820_outline_0085
                                   1690 	.globl _ak820_outline_0096
                                   1691 	.globl _ak820_outline_0104
                                   1692 	.globl _ak820_outline_0105
                                   1693 	.globl _ak820_outline_0106
                                   1694 	.globl _ak820_outline_0108
                                   1695 	.globl _ak820_outline_0110
                                   1696 	.globl _ak820_outline_0111
                                   1697 	.globl _ak820_outline_0121
                                   1698 	.globl _ak820_outline_0125
                                   1699 	.globl _ak820_outline_0126
                                   1700 	.globl _ak820_outline_0135
                                   1701 	.globl _ak820_outline_0136
                                   1702 	.globl _ak820_outline_0139
                                   1703 	.globl _ak820_outline_0144
                                   1704 	.globl _ak820_outline_0145
                                   1705 	.globl _ak820_outline_0151
                                   1706 	.globl _ak820_outline_0159
                                   1707 	.globl _ak820_outline_0161
                                   1708 	.globl _ak820_outline_0164
                                   1709 	.globl _ak820_outline_0165
                                   1710 	.globl _ak820_outline_0186
                                   1711 	.globl _ak820_outline_0187
                                   1712 
                                   1713 	.area CSEG (CODE)
                                   1714 ; function ak820_outline_0011
      004303                       1715 _ak820_outline_0011:
      004303 8E 82            [24] 1716 	mov	dpl,r6
      004305 8F 83            [24] 1717 	mov	dph,r7
      004307 A3               [24] 1718 	inc	dptr
      004308 A3               [24] 1719 	inc	dptr
      004309 A3               [24] 1720 	inc	dptr
      00430A A3               [24] 1721 	inc	dptr
      00430B A3               [24] 1722 	inc	dptr
      00430C 22               [24] 1723 	ret
                                   1724 
                                   1725 	.area CSEG (CODE)
                                   1726 ; function ak820_outline_0031
      00430D                       1727 _ak820_outline_0031:
      00430D F0               [24] 1728 	movx	@dptr,a
      00430E 8E 82            [24] 1729 	mov	dpl,r6
      004310 8F 83            [24] 1730 	mov	dph,r7
      004312 A3               [24] 1731 	inc	dptr
      004313 A3               [24] 1732 	inc	dptr
      004314 22               [24] 1733 	ret
                                   1734 
                                   1735 	.area CSEG (CODE)
                                   1736 ; function ak820_outline_0036
      004315                       1737 _ak820_outline_0036:
      004315 AF F0            [24] 1738 	mov	r7,b
      004317 AE 83            [24] 1739 	mov	r6,dph
      004319 E5 82            [12] 1740 	mov	a,dpl
      00431B 22               [24] 1741 	ret
                                   1742 
                                   1743 	.area CSEG (CODE)
                                   1744 ; function ak820_outline_0043
      00431C                       1745 _ak820_outline_0043:
      00431C EF               [12] 1746 	mov	a,r7
      00431D 24 75            [12] 1747 	add	a,#_ak820_nvm_flush_header_10000_62
      00431F F5 82            [12] 1748 	mov	dpl,a
      004321 E4               [12] 1749 	clr	a
      004322 34 05            [12] 1750 	addc	a,#(_ak820_nvm_flush_header_10000_62>>8)
      004324 F5 83            [12] 1751 	mov	dph,a
      004326 E0               [24] 1752 	movx	a,@dptr
      004327 22               [24] 1753 	ret
                                   1754 
                                   1755 	.area CSEG (CODE)
                                   1756 ; function ak820_outline_0053
      004328                       1757 _ak820_outline_0053:
      004328 8F 06            [24] 1758 	mov	ar6,r7
      00432A 7D 00            [12] 1759 	mov	r5,#0x00
      00432C 74 40            [12] 1760 	mov	a,#0x40
      00432E 2E               [12] 1761 	add	a,r6
      00432F FE               [12] 1762 	mov	r6,a
      004330 74 EF            [12] 1763 	mov	a,#0xef
      004332 3D               [12] 1764 	addc	a,r5
      004333 FD               [12] 1765 	mov	r5,a
      004334 8E 82            [24] 1766 	mov	dpl,r6
      004336 8D 83            [24] 1767 	mov	dph,r5
      004338 22               [24] 1768 	ret
                                   1769 
                                   1770 	.area CSEG (CODE)
                                   1771 ; function ak820_outline_0078
      004339                       1772 _ak820_outline_0078:
      004339 F0               [24] 1773 	movx	@dptr,a
      00433A 8E 82            [24] 1774 	mov	dpl,r6
      00433C 8F 83            [24] 1775 	mov	dph,r7
      00433E 22               [24] 1776 	ret
                                   1777 
                                   1778 	.area CSEG (CODE)
                                   1779 ; function ak820_outline_0096
      00433F                       1780 _ak820_outline_0096:
      00433F 8C 82            [24] 1781 	mov	dpl,r4
      004341 8D 83            [24] 1782 	mov	dph,r5
      004343 E0               [24] 1783 	movx	a,@dptr
      004344 22               [24] 1784 	ret
                                   1785 
                                   1786 	.area CSEG (CODE)
                                   1787 ; function ak820_outline_0105
      004345                       1788 _ak820_outline_0105:
      004345 E0               [24] 1789 	movx	a,@dptr
      004346 FA               [12] 1790 	mov	r2,a
      004347 A3               [24] 1791 	inc	dptr
      004348 E0               [24] 1792 	movx	a,@dptr
      004349 FB               [12] 1793 	mov	r3,a
      00434A 22               [24] 1794 	ret
                                   1795 
                                   1796 	.area CSEG (CODE)
                                   1797 ; function ak820_outline_0108
      00434B                       1798 _ak820_outline_0108:
      00434B EF               [12] 1799 	mov	a,r7
      00434C 24 1D            [12] 1800 	add	a,#_page_data
      00434E F5 82            [12] 1801 	mov	dpl,a
      004350 E4               [12] 1802 	clr	a
      004351 34 05            [12] 1803 	addc	a,#(_page_data>>8)
      004353 F5 83            [12] 1804 	mov	dph,a
      004355 E0               [24] 1805 	movx	a,@dptr
      004356 22               [24] 1806 	ret
                                   1807 
                                   1808 	.area CSEG (CODE)
                                   1809 ; function ak820_outline_0136
      004357                       1810 _ak820_outline_0136:
      004357 AE 82            [24] 1811 	mov	r6,dpl
      004359 AF 83            [24] 1812 	mov	r7,dph
      00435B 22               [24] 1813 	ret
                                   1814 
                                   1815 	.area CSEG (CODE)
                                   1816 ; function ak820_outline_0139
      00435C                       1817 _ak820_outline_0139:
      00435C 2E               [12] 1818 	add	a,r6
      00435D FE               [12] 1819 	mov	r6,a
      00435E E4               [12] 1820 	clr	a
      00435F 3F               [12] 1821 	addc	a,r7
      004360 FF               [12] 1822 	mov	r7,a
      004361 22               [24] 1823 	ret
                                   1824 
                                   1825 	.area CSEG (CODE)
                                   1826 ; function ak820_outline_0144
      004362                       1827 _ak820_outline_0144:
      004362 42 05            [12] 1828 	orl	ar5,a
      004364 EA               [12] 1829 	mov	a,r2
      004365 42 04            [12] 1830 	orl	ar4,a
      004367 22               [24] 1831 	ret
                                   1832 
                                   1833 	.area CSEG (CODE)
                                   1834 ; function ak820_outline_0151
      004368                       1835 _ak820_outline_0151:
      004368 AC 82            [24] 1836 	mov	r4,dpl
      00436A AD 83            [24] 1837 	mov	r5,dph
      00436C 22               [24] 1838 	ret
                                   1839 
                                   1840 	.area CSEG (CODE)
                                   1841 ; function ak820_outline_0161
      00436D                       1842 _ak820_outline_0161:
      00436D 8F 82            [24] 1843 	mov	dpl,r7
      00436F 8E 83            [24] 1844 	mov	dph,r6
      004371 22               [24] 1845 	ret
                                   1846 
                                   1847 	.area CSEG (CODE)
                                   1848 ; function ak820_outline_0164
      004372                       1849 _ak820_outline_0164:
      004372 2E               [12] 1850 	add	a,r6
      004373 FC               [12] 1851 	mov	r4,a
      004374 E4               [12] 1852 	clr	a
      004375 3F               [12] 1853 	addc	a,r7
      004376 FD               [12] 1854 	mov	r5,a
      004377 22               [24] 1855 	ret
                                   1856 
                                   1857 	.area CSEG (CODE)
                                   1858 ; function ak820_outline_0165
      004378                       1859 _ak820_outline_0165:
      004378 ED               [12] 1860 	mov	a,r5
      004379 F0               [24] 1861 	movx	@dptr,a
      00437A EE               [12] 1862 	mov	a,r6
      00437B A3               [24] 1863 	inc	dptr
      00437C F0               [24] 1864 	movx	@dptr,a
      00437D 22               [24] 1865 	ret
                                   1866 
                                   1867 	.area CSEG (CODE)
                                   1868 ; function ak820_outline_0186
      00437E                       1869 _ak820_outline_0186:
      00437E 89 82            [24] 1870 	mov	dpl,r1
      004380 8A 83            [24] 1871 	mov	dph,r2
      004382 22               [24] 1872 	ret
                                   1873 
                                   1874 	.area CSEG (CODE)
                                   1875 ; function ak820_outline_0187
      004383                       1876 _ak820_outline_0187:
      004383 8C 82            [24] 1877 	mov	dpl,r4
      004385 8B 83            [24] 1878 	mov	dph,r3
      004387 22               [24] 1879 	ret
