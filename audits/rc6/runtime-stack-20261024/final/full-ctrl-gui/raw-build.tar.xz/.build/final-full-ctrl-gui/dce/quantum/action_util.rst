                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action_util
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _host_consumer_send
                                     12 	.globl _host_system_send
                                     13 	.globl _host_keyboard_send
                                     14 	.globl _clear_keys_from_report
                                     15 	.globl _del_key_from_report
                                     16 	.globl _add_key_to_report
                                     17 	.globl _KEYCODE2CONSUMER
                                     18 	.globl _ADC_START
                                     19 	.globl _S0_R_FIFO
                                     20 	.globl _S0_T_FIFO
                                     21 	.globl _S0_FREE
                                     22 	.globl _S0_IF_BYTE
                                     23 	.globl _S0_IF_FIRST
                                     24 	.globl _S0_IF_OV
                                     25 	.globl _S0_FST_ACT
                                     26 	.globl _CP_RL2
                                     27 	.globl _C_T2
                                     28 	.globl _TR2
                                     29 	.globl _EXEN2
                                     30 	.globl _TCLK
                                     31 	.globl _RCLK
                                     32 	.globl _EXF2
                                     33 	.globl _CAP1F
                                     34 	.globl _TF2
                                     35 	.globl _RI
                                     36 	.globl _TI
                                     37 	.globl _RB8
                                     38 	.globl _TB8
                                     39 	.globl _REN
                                     40 	.globl _SM2
                                     41 	.globl _SM1
                                     42 	.globl _SM0
                                     43 	.globl _IT0
                                     44 	.globl _IE0
                                     45 	.globl _IT1
                                     46 	.globl _IE1
                                     47 	.globl _TR0
                                     48 	.globl _TF0
                                     49 	.globl _TR1
                                     50 	.globl _TF1
                                     51 	.globl _P4_0
                                     52 	.globl _P4_1
                                     53 	.globl _P4_2
                                     54 	.globl _P4_3
                                     55 	.globl _P4_4
                                     56 	.globl _P4_5
                                     57 	.globl _P4_6
                                     58 	.globl _RXD
                                     59 	.globl _TXD
                                     60 	.globl _INT0
                                     61 	.globl _INT1
                                     62 	.globl _T0
                                     63 	.globl _T1
                                     64 	.globl _MOSI1
                                     65 	.globl _MISO1
                                     66 	.globl _SCK1
                                     67 	.globl _P3_0
                                     68 	.globl _P3_1
                                     69 	.globl _P3_2
                                     70 	.globl _P3_3
                                     71 	.globl _P3_4
                                     72 	.globl _P3_5
                                     73 	.globl _P3_6
                                     74 	.globl _P3_7
                                     75 	.globl _CAP1_
                                     76 	.globl _T2_
                                     77 	.globl _CAP2_
                                     78 	.globl _T2EX_
                                     79 	.globl _RXD1
                                     80 	.globl _TXD1
                                     81 	.globl _P2_0
                                     82 	.globl _P2_1
                                     83 	.globl _P2_2
                                     84 	.globl _P2_3
                                     85 	.globl _P2_4
                                     86 	.globl _P2_5
                                     87 	.globl _P2_6
                                     88 	.globl _P2_7
                                     89 	.globl _AIN0
                                     90 	.globl _AIN1
                                     91 	.globl _AIN2
                                     92 	.globl _AIN3
                                     93 	.globl _AIN4
                                     94 	.globl _AIN5
                                     95 	.globl _AIN6
                                     96 	.globl _AIN7
                                     97 	.globl _CAP1
                                     98 	.globl _T2
                                     99 	.globl _CAP2
                                    100 	.globl _T2EX
                                    101 	.globl _INT0_
                                    102 	.globl _SCS
                                    103 	.globl _MOSI
                                    104 	.globl _MISO
                                    105 	.globl _SCK
                                    106 	.globl _RXD1_
                                    107 	.globl _TXD1_
                                    108 	.globl _P1_0
                                    109 	.globl _P1_1
                                    110 	.globl _P1_2
                                    111 	.globl _P1_3
                                    112 	.globl _P1_4
                                    113 	.globl _P1_5
                                    114 	.globl _P1_6
                                    115 	.globl _P1_7
                                    116 	.globl _AIN8
                                    117 	.globl _AIN9
                                    118 	.globl _AIN10
                                    119 	.globl _AIN11
                                    120 	.globl _AIN12
                                    121 	.globl _AIN13
                                    122 	.globl _RXD_
                                    123 	.globl _TXD_
                                    124 	.globl _SCL0
                                    125 	.globl _SDA0
                                    126 	.globl _P0_0
                                    127 	.globl _P0_1
                                    128 	.globl _P0_2
                                    129 	.globl _P0_3
                                    130 	.globl _P0_4
                                    131 	.globl _P0_5
                                    132 	.globl _P0_6
                                    133 	.globl _P0_7
                                    134 	.globl _IE_SPI0
                                    135 	.globl _IE_USB
                                    136 	.globl _IE_ADC
                                    137 	.globl _IE_UART1
                                    138 	.globl _IE_PWM_I2C
                                    139 	.globl _IE_GPIO
                                    140 	.globl _IE_WDOG
                                    141 	.globl _PX0
                                    142 	.globl _PT0
                                    143 	.globl _PX1
                                    144 	.globl _PT1
                                    145 	.globl _PS
                                    146 	.globl _PT2
                                    147 	.globl _PL_FLAG
                                    148 	.globl _PH_FLAG
                                    149 	.globl _EX0
                                    150 	.globl _ET0
                                    151 	.globl _EX1
                                    152 	.globl _ET1
                                    153 	.globl _ES
                                    154 	.globl _ET2
                                    155 	.globl _E_DIS
                                    156 	.globl _EA
                                    157 	.globl _P
                                    158 	.globl _F1
                                    159 	.globl _OV
                                    160 	.globl _RS0
                                    161 	.globl _RS1
                                    162 	.globl _F0
                                    163 	.globl _AC
                                    164 	.globl _CY
                                    165 	.globl _I2CS_INT_ST
                                    166 	.globl _I2CX_INT
                                    167 	.globl _LED_STATUS
                                    168 	.globl _LED_DMA_H
                                    169 	.globl _LED_DMA_L
                                    170 	.globl _LED_DMA
                                    171 	.globl _LED_PWM_OE
                                    172 	.globl _LED_COMMON
                                    173 	.globl _ADC_CHAN
                                    174 	.globl _ADC_DAT_H
                                    175 	.globl _ADC_DAT_L
                                    176 	.globl _ADC_DAT
                                    177 	.globl _ADC_CTRL
                                    178 	.globl _SPI1_CK_SE
                                    179 	.globl _SPI1_CTRL
                                    180 	.globl _SPI1_DATA
                                    181 	.globl _SPI1_STAT
                                    182 	.globl _SIF1
                                    183 	.globl _SBAUD1
                                    184 	.globl _SBUF1
                                    185 	.globl _SCON1
                                    186 	.globl _SPI0_SETUP
                                    187 	.globl _SPI0_CK_SE
                                    188 	.globl _SPI0_CTRL
                                    189 	.globl _SPI0_DATA
                                    190 	.globl _SPI0_STAT
                                    191 	.globl _T2CAP1H
                                    192 	.globl _T2CAP1L
                                    193 	.globl _T2CAP1
                                    194 	.globl _TH2
                                    195 	.globl _TL2
                                    196 	.globl _T2COUNT
                                    197 	.globl _RCAP2H
                                    198 	.globl _RCAP2L
                                    199 	.globl _RCAP2
                                    200 	.globl _T2MOD
                                    201 	.globl _T2CON
                                    202 	.globl _SBUF
                                    203 	.globl _SCON
                                    204 	.globl _TH1
                                    205 	.globl _TH0
                                    206 	.globl _TL1
                                    207 	.globl _TL0
                                    208 	.globl _TMOD
                                    209 	.globl _TCON
                                    210 	.globl _XBUS_AUX
                                    211 	.globl _P7
                                    212 	.globl _P6_DIR
                                    213 	.globl _P6_OUT_PU
                                    214 	.globl _P6_IN
                                    215 	.globl _P5_DIR
                                    216 	.globl _P5_OUT_PU
                                    217 	.globl _P5_IN
                                    218 	.globl _P4_LED_KEY
                                    219 	.globl _P4_DIR_PU
                                    220 	.globl _P4_MOD_OC
                                    221 	.globl _P4
                                    222 	.globl _P3_DIR_PU
                                    223 	.globl _P3_MOD_OC
                                    224 	.globl _P3
                                    225 	.globl _P2_DIR_PU
                                    226 	.globl _P2_MOD_OC
                                    227 	.globl _P2
                                    228 	.globl _P1_DIR_PU
                                    229 	.globl _P1_MOD_OC
                                    230 	.globl _P1
                                    231 	.globl _P0_DIR_PU
                                    232 	.globl _P0_MOD_OC
                                    233 	.globl _P0
                                    234 	.globl _ROM_CTRL
                                    235 	.globl _ROM_DATA_HH
                                    236 	.globl _ROM_DATA_HL
                                    237 	.globl _ROM_DATA_HI
                                    238 	.globl _ROM_ADDR_H
                                    239 	.globl _ROM_ADDR_L
                                    240 	.globl _ROM_ADDR
                                    241 	.globl _GPIO_IE
                                    242 	.globl _IP_EX
                                    243 	.globl _IE_EX
                                    244 	.globl _IP
                                    245 	.globl _IE
                                    246 	.globl _WDOG_COUNT
                                    247 	.globl _RESET_KEEP
                                    248 	.globl _WAKE_CTRL
                                    249 	.globl _CLOCK_CFG
                                    250 	.globl _POWER_CFG
                                    251 	.globl _PCON
                                    252 	.globl _GLOBAL_CFG
                                    253 	.globl _SAFE_MOD
                                    254 	.globl _DPH
                                    255 	.globl _DPL
                                    256 	.globl _SP
                                    257 	.globl _A_INV
                                    258 	.globl _B
                                    259 	.globl _ACC
                                    260 	.globl _PSW
                                    261 	.globl _actual_keyboard_report
                                    262 	.globl _owned_usage_key_PARM_2
                                    263 	.globl _ak820_macro_change_PARM_3
                                    264 	.globl _ak820_macro_change_PARM_2
                                    265 	.globl _ak820_macro_cancelled
                                    266 	.globl _ak820_macro_primitive
                                    267 	.globl _ak820_gui_process_PARM_2
                                    268 	.globl _ak820_gui_process
                                    269 	.globl _ak820_macro_change
                                    270 	.globl _add_owned_mods
                                    271 	.globl _del_owned_mods
                                    272 	.globl _add_owned_weak_mods
                                    273 	.globl _del_owned_weak_mods
                                    274 	.globl _clear_owned_mods
                                    275 	.globl _clear_owned_keys
                                    276 	.globl _add_owned_key
                                    277 	.globl _del_owned_key
                                    278 	.globl _clear_owned_usages
                                    279 	.globl _owned_usage_key
                                    280 	.globl _send_keyboard_report
                                    281 	.globl _get_mods
                                    282 	.globl _clear_mods
                                    283 	.globl _get_weak_mods
                                    284 	.globl _add_weak_mods
                                    285 	.globl _del_weak_mods
                                    286 	.globl _clear_weak_mods
                                    287 ;--------------------------------------------------------
                                    288 ; special function registers
                                    289 ;--------------------------------------------------------
                                    290 	.area RSEG    (ABS,DATA)
      000000                        291 	.org 0x0000
                           0000D0   292 _PSW	=	0x00d0
                           0000E0   293 _ACC	=	0x00e0
                           0000F0   294 _B	=	0x00f0
                           0000FD   295 _A_INV	=	0x00fd
                           000081   296 _SP	=	0x0081
                           000082   297 _DPL	=	0x0082
                           000083   298 _DPH	=	0x0083
                           0000A1   299 _SAFE_MOD	=	0x00a1
                           0000B1   300 _GLOBAL_CFG	=	0x00b1
                           000087   301 _PCON	=	0x0087
                           0000BA   302 _POWER_CFG	=	0x00ba
                           0000B9   303 _CLOCK_CFG	=	0x00b9
                           0000A9   304 _WAKE_CTRL	=	0x00a9
                           0000FE   305 _RESET_KEEP	=	0x00fe
                           0000FF   306 _WDOG_COUNT	=	0x00ff
                           0000A8   307 _IE	=	0x00a8
                           0000B8   308 _IP	=	0x00b8
                           0000E8   309 _IE_EX	=	0x00e8
                           0000E9   310 _IP_EX	=	0x00e9
                           0000B2   311 _GPIO_IE	=	0x00b2
                           008584   312 _ROM_ADDR	=	0x8584
                           000084   313 _ROM_ADDR_L	=	0x0084
                           000085   314 _ROM_ADDR_H	=	0x0085
                           008F8E   315 _ROM_DATA_HI	=	0x8f8e
                           00008E   316 _ROM_DATA_HL	=	0x008e
                           00008F   317 _ROM_DATA_HH	=	0x008f
                           000086   318 _ROM_CTRL	=	0x0086
                           000080   319 _P0	=	0x0080
                           0000C4   320 _P0_MOD_OC	=	0x00c4
                           0000C5   321 _P0_DIR_PU	=	0x00c5
                           000090   322 _P1	=	0x0090
                           000092   323 _P1_MOD_OC	=	0x0092
                           000093   324 _P1_DIR_PU	=	0x0093
                           0000A0   325 _P2	=	0x00a0
                           000094   326 _P2_MOD_OC	=	0x0094
                           000095   327 _P2_DIR_PU	=	0x0095
                           0000B0   328 _P3	=	0x00b0
                           000096   329 _P3_MOD_OC	=	0x0096
                           000097   330 _P3_DIR_PU	=	0x0097
                           0000C0   331 _P4	=	0x00c0
                           0000C2   332 _P4_MOD_OC	=	0x00c2
                           0000C3   333 _P4_DIR_PU	=	0x00c3
                           0000C1   334 _P4_LED_KEY	=	0x00c1
                           0000AA   335 _P5_IN	=	0x00aa
                           0000AB   336 _P5_OUT_PU	=	0x00ab
                           0000AC   337 _P5_DIR	=	0x00ac
                           0000AD   338 _P6_IN	=	0x00ad
                           0000AE   339 _P6_OUT_PU	=	0x00ae
                           0000AF   340 _P6_DIR	=	0x00af
                           0000F1   341 _P7	=	0x00f1
                           0000A2   342 _XBUS_AUX	=	0x00a2
                           000088   343 _TCON	=	0x0088
                           000089   344 _TMOD	=	0x0089
                           00008A   345 _TL0	=	0x008a
                           00008B   346 _TL1	=	0x008b
                           00008C   347 _TH0	=	0x008c
                           00008D   348 _TH1	=	0x008d
                           000098   349 _SCON	=	0x0098
                           000099   350 _SBUF	=	0x0099
                           0000C8   351 _T2CON	=	0x00c8
                           0000C9   352 _T2MOD	=	0x00c9
                           00CBCA   353 _RCAP2	=	0xcbca
                           0000CA   354 _RCAP2L	=	0x00ca
                           0000CB   355 _RCAP2H	=	0x00cb
                           00CDCC   356 _T2COUNT	=	0xcdcc
                           0000CC   357 _TL2	=	0x00cc
                           0000CD   358 _TH2	=	0x00cd
                           00CFCE   359 _T2CAP1	=	0xcfce
                           0000CE   360 _T2CAP1L	=	0x00ce
                           0000CF   361 _T2CAP1H	=	0x00cf
                           0000F8   362 _SPI0_STAT	=	0x00f8
                           0000F9   363 _SPI0_DATA	=	0x00f9
                           0000FA   364 _SPI0_CTRL	=	0x00fa
                           0000FB   365 _SPI0_CK_SE	=	0x00fb
                           0000FC   366 _SPI0_SETUP	=	0x00fc
                           0000BC   367 _SCON1	=	0x00bc
                           0000BD   368 _SBUF1	=	0x00bd
                           0000BE   369 _SBAUD1	=	0x00be
                           0000BF   370 _SIF1	=	0x00bf
                           0000B4   371 _SPI1_STAT	=	0x00b4
                           0000B5   372 _SPI1_DATA	=	0x00b5
                           0000B6   373 _SPI1_CTRL	=	0x00b6
                           0000B7   374 _SPI1_CK_SE	=	0x00b7
                           0000F3   375 _ADC_CTRL	=	0x00f3
                           00F5F4   376 _ADC_DAT	=	0xf5f4
                           0000F4   377 _ADC_DAT_L	=	0x00f4
                           0000F5   378 _ADC_DAT_H	=	0x00f5
                           0000F6   379 _ADC_CHAN	=	0x00f6
                           0000A6   380 _LED_COMMON	=	0x00a6
                           0000A7   381 _LED_PWM_OE	=	0x00a7
                           00C7C6   382 _LED_DMA	=	0xc7c6
                           0000C6   383 _LED_DMA_L	=	0x00c6
                           0000C7   384 _LED_DMA_H	=	0x00c7
                           0000F7   385 _LED_STATUS	=	0x00f7
                           0000B3   386 _I2CX_INT	=	0x00b3
                           0000BB   387 _I2CS_INT_ST	=	0x00bb
                                    388 ;--------------------------------------------------------
                                    389 ; special function bits
                                    390 ;--------------------------------------------------------
                                    391 	.area RSEG    (ABS,DATA)
      000000                        392 	.org 0x0000
                           0000D7   393 _CY	=	0x00d7
                           0000D6   394 _AC	=	0x00d6
                           0000D5   395 _F0	=	0x00d5
                           0000D4   396 _RS1	=	0x00d4
                           0000D3   397 _RS0	=	0x00d3
                           0000D2   398 _OV	=	0x00d2
                           0000D1   399 _F1	=	0x00d1
                           0000D0   400 _P	=	0x00d0
                           0000AF   401 _EA	=	0x00af
                           0000AE   402 _E_DIS	=	0x00ae
                           0000AD   403 _ET2	=	0x00ad
                           0000AC   404 _ES	=	0x00ac
                           0000AB   405 _ET1	=	0x00ab
                           0000AA   406 _EX1	=	0x00aa
                           0000A9   407 _ET0	=	0x00a9
                           0000A8   408 _EX0	=	0x00a8
                           0000BF   409 _PH_FLAG	=	0x00bf
                           0000BE   410 _PL_FLAG	=	0x00be
                           0000BD   411 _PT2	=	0x00bd
                           0000BC   412 _PS	=	0x00bc
                           0000BB   413 _PT1	=	0x00bb
                           0000BA   414 _PX1	=	0x00ba
                           0000B9   415 _PT0	=	0x00b9
                           0000B8   416 _PX0	=	0x00b8
                           0000EF   417 _IE_WDOG	=	0x00ef
                           0000EE   418 _IE_GPIO	=	0x00ee
                           0000ED   419 _IE_PWM_I2C	=	0x00ed
                           0000EC   420 _IE_UART1	=	0x00ec
                           0000EB   421 _IE_ADC	=	0x00eb
                           0000E9   422 _IE_USB	=	0x00e9
                           0000E8   423 _IE_SPI0	=	0x00e8
                           000087   424 _P0_7	=	0x0087
                           000086   425 _P0_6	=	0x0086
                           000085   426 _P0_5	=	0x0085
                           000084   427 _P0_4	=	0x0084
                           000083   428 _P0_3	=	0x0083
                           000082   429 _P0_2	=	0x0082
                           000081   430 _P0_1	=	0x0081
                           000080   431 _P0_0	=	0x0080
                           000081   432 _SDA0	=	0x0081
                           000080   433 _SCL0	=	0x0080
                           000083   434 _TXD_	=	0x0083
                           000082   435 _RXD_	=	0x0082
                           000085   436 _AIN13	=	0x0085
                           000084   437 _AIN12	=	0x0084
                           000083   438 _AIN11	=	0x0083
                           000082   439 _AIN10	=	0x0082
                           000081   440 _AIN9	=	0x0081
                           000080   441 _AIN8	=	0x0080
                           000097   442 _P1_7	=	0x0097
                           000096   443 _P1_6	=	0x0096
                           000095   444 _P1_5	=	0x0095
                           000094   445 _P1_4	=	0x0094
                           000093   446 _P1_3	=	0x0093
                           000092   447 _P1_2	=	0x0092
                           000091   448 _P1_1	=	0x0091
                           000090   449 _P1_0	=	0x0090
                           000097   450 _TXD1_	=	0x0097
                           000096   451 _RXD1_	=	0x0096
                           000097   452 _SCK	=	0x0097
                           000096   453 _MISO	=	0x0096
                           000095   454 _MOSI	=	0x0095
                           000094   455 _SCS	=	0x0094
                           000092   456 _INT0_	=	0x0092
                           000091   457 _T2EX	=	0x0091
                           000091   458 _CAP2	=	0x0091
                           000090   459 _T2	=	0x0090
                           000090   460 _CAP1	=	0x0090
                           000097   461 _AIN7	=	0x0097
                           000096   462 _AIN6	=	0x0096
                           000095   463 _AIN5	=	0x0095
                           000094   464 _AIN4	=	0x0094
                           000093   465 _AIN3	=	0x0093
                           000092   466 _AIN2	=	0x0092
                           000091   467 _AIN1	=	0x0091
                           000090   468 _AIN0	=	0x0090
                           0000A7   469 _P2_7	=	0x00a7
                           0000A6   470 _P2_6	=	0x00a6
                           0000A5   471 _P2_5	=	0x00a5
                           0000A4   472 _P2_4	=	0x00a4
                           0000A3   473 _P2_3	=	0x00a3
                           0000A2   474 _P2_2	=	0x00a2
                           0000A1   475 _P2_1	=	0x00a1
                           0000A0   476 _P2_0	=	0x00a0
                           0000A7   477 _TXD1	=	0x00a7
                           0000A6   478 _RXD1	=	0x00a6
                           0000A5   479 _T2EX_	=	0x00a5
                           0000A5   480 _CAP2_	=	0x00a5
                           0000A4   481 _T2_	=	0x00a4
                           0000A4   482 _CAP1_	=	0x00a4
                           0000B7   483 _P3_7	=	0x00b7
                           0000B6   484 _P3_6	=	0x00b6
                           0000B5   485 _P3_5	=	0x00b5
                           0000B4   486 _P3_4	=	0x00b4
                           0000B3   487 _P3_3	=	0x00b3
                           0000B2   488 _P3_2	=	0x00b2
                           0000B1   489 _P3_1	=	0x00b1
                           0000B0   490 _P3_0	=	0x00b0
                           0000B7   491 _SCK1	=	0x00b7
                           0000B6   492 _MISO1	=	0x00b6
                           0000B5   493 _MOSI1	=	0x00b5
                           0000B5   494 _T1	=	0x00b5
                           0000B4   495 _T0	=	0x00b4
                           0000B3   496 _INT1	=	0x00b3
                           0000B2   497 _INT0	=	0x00b2
                           0000B1   498 _TXD	=	0x00b1
                           0000B0   499 _RXD	=	0x00b0
                           0000C6   500 _P4_6	=	0x00c6
                           0000C5   501 _P4_5	=	0x00c5
                           0000C4   502 _P4_4	=	0x00c4
                           0000C3   503 _P4_3	=	0x00c3
                           0000C2   504 _P4_2	=	0x00c2
                           0000C1   505 _P4_1	=	0x00c1
                           0000C0   506 _P4_0	=	0x00c0
                           00008F   507 _TF1	=	0x008f
                           00008E   508 _TR1	=	0x008e
                           00008D   509 _TF0	=	0x008d
                           00008C   510 _TR0	=	0x008c
                           00008B   511 _IE1	=	0x008b
                           00008A   512 _IT1	=	0x008a
                           000089   513 _IE0	=	0x0089
                           000088   514 _IT0	=	0x0088
                           00009F   515 _SM0	=	0x009f
                           00009E   516 _SM1	=	0x009e
                           00009D   517 _SM2	=	0x009d
                           00009C   518 _REN	=	0x009c
                           00009B   519 _TB8	=	0x009b
                           00009A   520 _RB8	=	0x009a
                           000099   521 _TI	=	0x0099
                           000098   522 _RI	=	0x0098
                           0000CF   523 _TF2	=	0x00cf
                           0000CF   524 _CAP1F	=	0x00cf
                           0000CE   525 _EXF2	=	0x00ce
                           0000CD   526 _RCLK	=	0x00cd
                           0000CC   527 _TCLK	=	0x00cc
                           0000CB   528 _EXEN2	=	0x00cb
                           0000CA   529 _TR2	=	0x00ca
                           0000C9   530 _C_T2	=	0x00c9
                           0000C8   531 _CP_RL2	=	0x00c8
                           0000FF   532 _S0_FST_ACT	=	0x00ff
                           0000FE   533 _S0_IF_OV	=	0x00fe
                           0000FD   534 _S0_IF_FIRST	=	0x00fd
                           0000FC   535 _S0_IF_BYTE	=	0x00fc
                           0000FB   536 _S0_FREE	=	0x00fb
                           0000FA   537 _S0_T_FIFO	=	0x00fa
                           0000F8   538 _S0_R_FIFO	=	0x00f8
                           0000F7   539 _ADC_START	=	0x00f7
                                    540 ;--------------------------------------------------------
                                    541 ; overlayable register banks
                                    542 ;--------------------------------------------------------
                                    543 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        544 	.ds 8
                                    545 ;--------------------------------------------------------
                                    546 ; internal ram data
                                    547 ;--------------------------------------------------------
                                    548 	.area DSEG    (DATA)
                                    549 ;--------------------------------------------------------
                                    550 ; overlayable items in internal ram
                                    551 ;--------------------------------------------------------
                                    552 	.area	OSEG    (OVR,DATA)
      000054                        553 _change_owned_sloc1_1_0:
      000054                        554 	.ds 1
                                    555 ;--------------------------------------------------------
                                    556 ; indirectly addressable internal ram data
                                    557 ;--------------------------------------------------------
                                    558 	.area ISEG    (DATA)
                                    559 ;--------------------------------------------------------
                                    560 ; absolute internal ram data
                                    561 ;--------------------------------------------------------
                                    562 	.area IABS    (ABS,DATA)
                                    563 	.area IABS    (ABS,DATA)
                                    564 ;--------------------------------------------------------
                                    565 ; bit data
                                    566 ;--------------------------------------------------------
                                    567 	.area BSEG    (BIT)
      000020                        568 _gui_disabled:
      000020                        569 	.ds 1
      000021                        570 _ctrl_gui_swapped:
      000021                        571 	.ds 1
      000022                        572 _ak820_gui_process_sloc0_1_0:
      000022                        573 	.ds 1
      000023                        574 _ak820_macro_change_sloc0_1_0:
      000023                        575 	.ds 1
      000024                        576 _change_owned_sloc0_1_0:
      000024                        577 	.ds 1
      000025                        578 _owned_usage_key_sloc0_1_0:
      000025                        579 	.ds 1
                                    580 ;--------------------------------------------------------
                                    581 ; paged external ram data
                                    582 ;--------------------------------------------------------
                                    583 	.area PSEG    (PAG,XDATA)
                                    584 ;--------------------------------------------------------
                                    585 ; uninitialized external ram data
                                    586 ;--------------------------------------------------------
                                    587 	.area XSEG    (XDATA)
      000976                        588 _ak820_gui_process_PARM_2:
      000976                        589 	.ds 1
      000977                        590 _ak820_gui_process_code_10000_294:
      000977                        591 	.ds 2
      000979                        592 _owned_mod_refs:
      000979                        593 	.ds 8
      000981                        594 _owned_weak_refs:
      000981                        595 	.ds 8
      000989                        596 _owned_mods:
      000989                        597 	.ds 1
      00098A                        598 _owned_weak_mods:
      00098A                        599 	.ds 1
      00098B                        600 _macro_mods:
      00098B                        601 	.ds 2
      00098D                        602 _ak820_macro_primitive::
      00098D                        603 	.ds 1
      00098E                        604 _ak820_macro_cancelled::
      00098E                        605 	.ds 1
      00098F                        606 _ak820_macro_change_PARM_2:
      00098F                        607 	.ds 1
      000990                        608 _ak820_macro_change_PARM_3:
      000990                        609 	.ds 1
      000991                        610 _ak820_macro_change_bits_10000_303:
      000991                        611 	.ds 2
      000993                        612 _change_owned_PARM_2:
      000993                        613 	.ds 1
      000994                        614 _change_owned_mods_10000_308:
      000994                        615 	.ds 1
      000995                        616 _change_owned_result_10001_312:
      000995                        617 	.ds 1
      000996                        618 _change_owned_bit_20001_313:
      000996                        619 	.ds 1
      000997                        620 _add_owned_mods_mods_10000_321:
      000997                        621 	.ds 1
      000998                        622 _del_owned_mods_mods_10000_323:
      000998                        623 	.ds 1
      000999                        624 _add_owned_weak_mods_mods_10000_325:
      000999                        625 	.ds 1
      00099A                        626 _del_owned_weak_mods_mods_10000_327:
      00099A                        627 	.ds 1
      00099B                        628 _key_refs:
      00099B                        629 	.ds 165
      000A40                        630 _distinct_keys:
      000A40                        631 	.ds 1
      000A41                        632 _macro_keys:
      000A41                        633 	.ds 21
      000A56                        634 _add_owned_key_code_10000_336:
      000A56                        635 	.ds 1
      000A57                        636 _del_owned_key_code_10000_351:
      000A57                        637 	.ds 1
      000A58                        638 _usage_refs:
      000A58                        639 	.ds 30
      000A76                        640 _usage_order:
      000A76                        641 	.ds 30
      000A94                        642 _usage_lengths:
      000A94                        643 	.ds 2
      000A96                        644 _macro_usages:
      000A96                        645 	.ds 4
      000A9A                        646 _owned_usage_key_PARM_2:
      000A9A                        647 	.ds 1
      000A9B                        648 _owned_usage_key_code_10000_378:
      000A9B                        649 	.ds 1
      000A9C                        650 _owned_usage_key___200000085_20000_379:
      000A9C                        651 	.ds 2
      000A9E                        652 _owned_usage_key_which_10000_379:
      000A9E                        653 	.ds 1
      000A9F                        654 _owned_usage_key_count_10000_379:
      000A9F                        655 	.ds 1
      000AA0                        656 _owned_usage_key_pos_30001_386:
      000AA0                        657 	.ds 1
      000AA1                        658 _owned_usage_key_key_40000_391:
      000AA1                        659 	.ds 1
      000AA2                        660 _send_keyboard_report_last_report_10001_401:
      000AA2                        661 	.ds 32
      000AC2                        662 _send_keyboard_report_changed_10001_401:
      000AC2                        663 	.ds 1
      000AC3                        664 _add_weak_mods_mods_10000_419:
      000AC3                        665 	.ds 1
      000AC4                        666 _del_weak_mods_mods_10000_421:
      000AC4                        667 	.ds 1
                                    668 ;--------------------------------------------------------
                                    669 ; absolute external ram data
                                    670 ;--------------------------------------------------------
                                    671 	.area XABS    (ABS,XDATA)
                                    672 ;--------------------------------------------------------
                                    673 ; initialized external ram data
                                    674 ;--------------------------------------------------------
                                    675 	.area XISEG   (XDATA)
      000DCA                        676 _real_mods:
      000DCA                        677 	.ds 1
      000DCB                        678 _weak_mods:
      000DCB                        679 	.ds 1
      000DCC                        680 _actual_keyboard_report::
      000DCC                        681 	.ds 32
                                    682 	.area HOME    (CODE)
                                    683 	.area GSINIT0 (CODE)
                                    684 	.area GSINIT1 (CODE)
                                    685 	.area GSINIT2 (CODE)
                                    686 	.area GSINIT3 (CODE)
                                    687 	.area GSINIT4 (CODE)
                                    688 	.area GSINIT5 (CODE)
                                    689 	.area GSINIT  (CODE)
                                    690 	.area GSFINAL (CODE)
                                    691 	.area CSEG    (CODE)
                                    692 ;--------------------------------------------------------
                                    693 ; global & static initialisations
                                    694 ;--------------------------------------------------------
                                    695 	.area HOME    (CODE)
                                    696 	.area GSINIT  (CODE)
                                    697 	.area GSFINAL (CODE)
                                    698 	.area GSINIT  (CODE)
                                    699 ;--------------------------------------------------------
                                    700 ; Home
                                    701 ;--------------------------------------------------------
                                    702 	.area HOME    (CODE)
                                    703 	.area HOME    (CODE)
                                    704 ;--------------------------------------------------------
                                    705 ; code
                                    706 ;--------------------------------------------------------
                                    707 	.area CSEG    (CODE)
                                    708 ;------------------------------------------------------------
                                    709 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    710 ;------------------------------------------------------------
                                    711 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    712 ;------------------------------------------------------------
                                    713 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    714 ;	-----------------------------------------
                           000007   715 	ar7 = 0x07
                           000006   716 	ar6 = 0x06
                           000005   717 	ar5 = 0x05
                           000004   718 	ar4 = 0x04
                           000003   719 	ar3 = 0x03
                           000002   720 	ar2 = 0x02
                           000001   721 	ar1 = 0x01
                           000000   722 	ar0 = 0x00
                                    723 ;	 function ak820_gui_process
                                    724 ;	-----------------------------------------
      007B86                        725 _ak820_gui_process:
      007B86 12 38 88         [24]  726 	lcall	_ak820_outline_0110
      007B89 90 09 77         [24]  727 	mov	dptr,#_ak820_gui_process_code_10000_294
      007B8C 12 38 8D         [24]  728 	lcall	_ak820_outline_0111
                                    729 ;	quantum/action_util.c:51: if (code == QK_MAGIC_SWAP_CTL_GUI || code == QK_MAGIC_UNSWAP_CTL_GUI || code == QK_MAGIC_TOGGLE_CTL_GUI) {
      007B8F 90 09 77         [24]  730 	mov	dptr,#_ak820_gui_process_code_10000_294
      007B92 12 38 41         [24]  731 	lcall	_ak820_outline_0052
      007B95 E4               [12]  732 	clr	a
      007B96 BE 1B 04         [24]  733 	cjne	r6,#0x1b,00167$
      007B99 BF 70 01         [24]  734 	cjne	r7,#0x70,00167$
      007B9C 04               [12]  735 	inc	a
      007B9D                        736 00167$:
      007B9D FD               [12]  737 	mov	r5,a
      007B9E 70 0E            [24]  738 	jnz	00103$
      007BA0 BE 1C 05         [24]  739 	cjne	r6,#0x1c,00170$
      007BA3 BF 70 02         [24]  740 	cjne	r7,#0x70,00170$
      007BA6 80 06            [24]  741 	sjmp	00103$
      007BA8                        742 00170$:
      007BA8 BE 1D 27         [24]  743 	cjne	r6,#0x1d,00104$
      007BAB BF 70 24         [24]  744 	cjne	r7,#0x70,00104$
      007BAE                        745 00103$:
                                    746 ;	quantum/action_util.c:52: if (pressed) {
      007BAE 90 09 76         [24]  747 	mov	dptr,#_ak820_gui_process_PARM_2
      007BB1 E0               [24]  748 	movx	a,@dptr
      007BB2 60 1A            [24]  749 	jz	00102$
                                    750 ;	quantum/action_util.c:53: ctrl_gui_swapped = code == QK_MAGIC_TOGGLE_CTL_GUI ? !ctrl_gui_swapped : code == QK_MAGIC_SWAP_CTL_GUI;
      007BB4 BE 1D 0D         [24]  751 	cjne	r6,#0x1d,00114$
      007BB7 BF 70 0A         [24]  752 	cjne	r7,#0x70,00114$
      007BBA A2 21            [12]  753 	mov	c,_ctrl_gui_swapped
      007BBC B3               [12]  754 	cpl	c
      007BBD 92 22            [24]  755 	mov  _ak820_gui_process_sloc0_1_0,c
      007BBF E4               [12]  756 	clr	a
      007BC0 33               [12]  757 	rlc	a
      007BC1 FC               [12]  758 	mov	r4,a
      007BC2 80 02            [24]  759 	sjmp	00115$
      007BC4                        760 00114$:
      007BC4 8D 04            [24]  761 	mov	ar4,r5
      007BC6                        762 00115$:
                                    763 ;	assignBit
      007BC6 EC               [12]  764 	mov	a,r4
      007BC7 24 FF            [12]  765 	add	a,#0xff
      007BC9 92 21            [24]  766 	mov	_ctrl_gui_swapped,c
                                    767 ;	quantum/action_util.c:54: send_keyboard_report();
      007BCB 12 80 92         [24]  768 	lcall	_send_keyboard_report
      007BCE                        769 00102$:
                                    770 ;	quantum/action_util.c:56: return false;
      007BCE 75 82 00         [24]  771 	mov	dpl, #0x00
      007BD1 22               [24]  772 	ret
      007BD2                        773 00104$:
                                    774 ;	quantum/action_util.c:60: if (code < QK_MAGIC_GUI_ON || code > QK_MAGIC_TOGGLE_GUI) return true;
      007BD2 C3               [12]  775 	clr	c
      007BD3 EE               [12]  776 	mov	a,r6
      007BD4 94 09            [12]  777 	subb	a,#0x09
      007BD6 EF               [12]  778 	mov	a,r7
      007BD7 94 70            [12]  779 	subb	a,#0x70
      007BD9 40 08            [24]  780 	jc	00107$
      007BDB 74 0B            [12]  781 	mov	a,#0x0b
      007BDD 9E               [12]  782 	subb	a,r6
      007BDE 74 70            [12]  783 	mov	a,#0x70
      007BE0 9F               [12]  784 	subb	a,r7
      007BE1 50 04            [24]  785 	jnc	00108$
                                    786 ;	free result
      007BE3                        787 00107$:
      007BE3 75 82 01         [24]  788 	mov	dpl, #0x01
      007BE6 22               [24]  789 	ret
      007BE7                        790 00108$:
                                    791 ;	quantum/action_util.c:61: if (pressed) {
      007BE7 90 09 76         [24]  792 	mov	dptr,#_ak820_gui_process_PARM_2
      007BEA E0               [24]  793 	movx	a,@dptr
      007BEB 60 21            [24]  794 	jz	00111$
                                    795 ;	quantum/action_util.c:62: gui_disabled = code == QK_MAGIC_TOGGLE_GUI ? !gui_disabled : code == QK_MAGIC_GUI_OFF;
      007BED BE 0B 0D         [24]  796 	cjne	r6,#0x0b,00116$
      007BF0 BF 70 0A         [24]  797 	cjne	r7,#0x70,00116$
      007BF3 A2 20            [12]  798 	mov	c,_gui_disabled
      007BF5 B3               [12]  799 	cpl	c
      007BF6 92 22            [24]  800 	mov  _ak820_gui_process_sloc0_1_0,c
      007BF8 E4               [12]  801 	clr	a
      007BF9 33               [12]  802 	rlc	a
      007BFA FD               [12]  803 	mov	r5,a
      007BFB 80 09            [24]  804 	sjmp	00117$
      007BFD                        805 00116$:
      007BFD E4               [12]  806 	clr	a
      007BFE BE 0A 04         [24]  807 	cjne	r6,#0x0a,00181$
      007C01 BF 70 01         [24]  808 	cjne	r7,#0x70,00181$
      007C04 04               [12]  809 	inc	a
      007C05                        810 00181$:
      007C05 FD               [12]  811 	mov	r5,a
      007C06                        812 00117$:
                                    813 ;	assignBit
      007C06 ED               [12]  814 	mov	a,r5
      007C07 24 FF            [12]  815 	add	a,#0xff
      007C09 92 20            [24]  816 	mov	_gui_disabled,c
                                    817 ;	quantum/action_util.c:63: send_keyboard_report();
      007C0B 12 80 92         [24]  818 	lcall	_send_keyboard_report
      007C0E                        819 00111$:
                                    820 ;	quantum/action_util.c:65: return false;
      007C0E 75 82 00         [24]  821 	mov	dpl, #0x00
                                    822 ;	quantum/action_util.c:69: }
      007C11 22               [24]  823 	ret
                                    824 ;------------------------------------------------------------
                                    825 ;Allocation info for local variables in function 'ak820_macro_change'
                                    826 ;------------------------------------------------------------
                                    827 ;index         Allocated with name '_ak820_macro_change_PARM_2'
                                    828 ;pressed       Allocated with name '_ak820_macro_change_PARM_3'
                                    829 ;bits          Allocated with name '_ak820_macro_change_bits_10000_303'
                                    830 ;mask          Allocated with name '_ak820_macro_change_mask_10001_306'
                                    831 ;------------------------------------------------------------
                                    832 ;	quantum/action_util.c:78: bool ak820_macro_change(uint8_t AK820_STATE_MEM *bits, uint8_t index, bool pressed) {
                                    833 ;	-----------------------------------------
                                    834 ;	 function ak820_macro_change
                                    835 ;	-----------------------------------------
      007C12                        836 _ak820_macro_change:
      007C12 12 38 88         [24]  837 	lcall	_ak820_outline_0110
      007C15 90 09 91         [24]  838 	mov	dptr,#_ak820_macro_change_bits_10000_303
      007C18 12 38 8D         [24]  839 	lcall	_ak820_outline_0111
                                    840 ;	quantum/action_util.c:79: if (!ak820_macro_primitive) return true;
      007C1B 90 09 8D         [24]  841 	mov	dptr,#_ak820_macro_primitive
      007C1E E0               [24]  842 	movx	a,@dptr
      007C1F 70 04            [24]  843 	jnz	00102$
      007C21 75 82 01         [24]  844 	mov	dpl, #0x01
      007C24 22               [24]  845 	ret
      007C25                        846 00102$:
                                    847 ;	quantum/action_util.c:80: uint8_t mask = 1u << (index & 7);
      007C25 90 09 8F         [24]  848 	mov	dptr,#_ak820_macro_change_PARM_2
      007C28 E0               [24]  849 	movx	a,@dptr
      007C29 FF               [12]  850 	mov	r7,a
      007C2A 74 07            [12]  851 	mov	a,#0x07
      007C2C 5F               [12]  852 	anl	a,r7
      007C2D 12 77 18         [24]  853 	lcall	_ak820_outline_0063
      007C30 80 02            [24]  854 	sjmp	00123$
      007C32                        855 00122$:
      007C32 25 E0            [12]  856 	add	a,acc
      007C34                        857 00123$:
      007C34 D5 F0 FB         [24]  858 	djnz	b,00122$
      007C37 FE               [12]  859 	mov	r6,a
                                    860 ;	quantum/action_util.c:81: bits += index >> 3;
      007C38 EF               [12]  861 	mov	a,r7
      007C39 12 57 54         [24]  862 	lcall	_ak820_outline_0174
      007C3C FF               [12]  863 	mov	r7,a
      007C3D 90 09 91         [24]  864 	mov	dptr,#_ak820_macro_change_bits_10000_303
      007C40 12 38 58         [24]  865 	lcall	_ak820_outline_0061
      007C43 90 09 91         [24]  866 	mov	dptr,#_ak820_macro_change_bits_10000_303
      007C46 EF               [12]  867 	mov	a,r7
      007C47 2C               [12]  868 	add	a, r4
      007C48 F0               [24]  869 	movx	@dptr,a
      007C49 E4               [12]  870 	clr	a
      007C4A 3D               [12]  871 	addc	a, r5
      007C4B A3               [24]  872 	inc	dptr
      007C4C F0               [24]  873 	movx	@dptr,a
                                    874 ;	quantum/action_util.c:82: if (((*bits & mask) != 0) == pressed) return false;
      007C4D 90 09 91         [24]  875 	mov	dptr,#_ak820_macro_change_bits_10000_303
      007C50 E0               [24]  876 	movx	a,@dptr
      007C51 FD               [12]  877 	mov	r5,a
      007C52 A3               [24]  878 	inc	dptr
      007C53 E0               [24]  879 	movx	a,@dptr
      007C54 FF               [12]  880 	mov	r7,a
      007C55 12 81 DE         [24]  881 	lcall	_ak820_outline_0192
      007C58 E0               [24]  882 	movx	a,@dptr
      007C59 FC               [12]  883 	mov	r4,a
      007C5A EE               [12]  884 	mov	a,r6
      007C5B 5C               [12]  885 	anl	a,r4
      007C5C B4 01 00         [24]  886 	cjne	a,#0x01,00124$
      007C5F                        887 00124$:
      007C5F B3               [12]  888 	cpl	c
      007C60 92 23            [24]  889 	mov	_ak820_macro_change_sloc0_1_0,c
      007C62 90 09 90         [24]  890 	mov	dptr,#_ak820_macro_change_PARM_3
      007C65 E0               [24]  891 	movx	a,@dptr
      007C66 FB               [12]  892 	mov	r3,a
      007C67 A2 23            [12]  893 	mov	c,_ak820_macro_change_sloc0_1_0
      007C69 E4               [12]  894 	clr	a
      007C6A 33               [12]  895 	rlc	a
      007C6B B5 03 04         [24]  896 	cjne	a,ar3,00104$
      007C6E 75 82 00         [24]  897 	mov	dpl, #0x00
      007C71 22               [24]  898 	ret
      007C72                        899 00104$:
                                    900 ;	quantum/action_util.c:83: *bits ^= mask;
      007C72 EC               [12]  901 	mov	a,r4
      007C73 62 06            [12]  902 	xrl	ar6,a
      007C75 12 81 DE         [24]  903 	lcall	_ak820_outline_0192
      007C78 EE               [12]  904 	mov	a,r6
      007C79 F0               [24]  905 	movx	@dptr,a
                                    906 ;	quantum/action_util.c:84: return true;
      007C7A 75 82 01         [24]  907 	mov	dpl, #0x01
                                    908 ;	quantum/action_util.c:85: }
      007C7D 22               [24]  909 	ret
                                    910 ;------------------------------------------------------------
                                    911 ;Allocation info for local variables in function 'change_owned'
                                    912 ;------------------------------------------------------------
                                    913 ;mode          Allocated with name '_change_owned_PARM_2'
                                    914 ;mods          Allocated with name '_change_owned_mods_10000_308'
                                    915 ;kind          Allocated with name '_change_owned_kind_10000_309'
                                    916 ;pressed       Allocated with name '_change_owned_pressed_10000_309'
                                    917 ;refs          Allocated with name '_change_owned_refs_10000_309'
                                    918 ;old           Allocated with name '_change_owned_old_30000_311'
                                    919 ;result        Allocated with name '_change_owned_result_10001_312'
                                    920 ;i             Allocated with name '_change_owned_i_20001_313'
                                    921 ;bit           Allocated with name '_change_owned_bit_20001_313'
                                    922 ;sloc1         Allocated with name '_change_owned_sloc1_1_0'
                                    923 ;------------------------------------------------------------
                                    924 ;	quantum/action_util.c:86: static void change_owned(uint8_t mods, uint8_t mode) {
                                    925 ;	-----------------------------------------
                                    926 ;	 function change_owned
                                    927 ;	-----------------------------------------
      007C7E                        928 _change_owned:
      007C7E E5 82            [12]  929 	mov	a,dpl
      007C80 90 09 94         [24]  930 	mov	dptr,#_change_owned_mods_10000_308
      007C83 F0               [24]  931 	movx	@dptr,a
                                    932 ;	quantum/action_util.c:87: uint8_t kind = mode >> 1;
      007C84 90 09 93         [24]  933 	mov	dptr,#_change_owned_PARM_2
      007C87 E0               [24]  934 	movx	a,@dptr
      007C88 FF               [12]  935 	mov	r7,a
      007C89 C3               [12]  936 	clr	c
      007C8A 13               [12]  937 	rrc	a
      007C8B FE               [12]  938 	mov	r6,a
                                    939 ;	quantum/action_util.c:88: bool pressed = (mode & 1) != 0;
      007C8C 53 07 01         [24]  940 	anl	ar7,#0x01
      007C8F EF               [12]  941 	mov	a,r7
      007C90 B4 01 00         [24]  942 	cjne	a,#0x01,00205$
      007C93                        943 00205$:
      007C93 92 24            [24]  944 	mov  _change_owned_sloc0_1_0,c
      007C95 B3               [12]  945 	cpl	c
      007C96 E4               [12]  946 	clr	a
      007C97 33               [12]  947 	rlc	a
      007C98 F5 54            [12]  948 	mov	_change_owned_sloc1_1_0,a
                                    949 ;	quantum/action_util.c:89: uint8_t AK820_STATE_MEM *refs = kind ? owned_weak_refs : owned_mod_refs;
      007C9A EE               [12]  950 	mov	a,r6
      007C9B 60 06            [24]  951 	jz	00121$
      007C9D 7D 81            [12]  952 	mov	r5,#_owned_weak_refs
      007C9F 7F 09            [12]  953 	mov	r7,#(_owned_weak_refs >> 8)
      007CA1 80 04            [24]  954 	sjmp	00122$
      007CA3                        955 00121$:
      007CA3 7D 79            [12]  956 	mov	r5,#_owned_mod_refs
      007CA5 7F 09            [12]  957 	mov	r7,#(_owned_mod_refs >> 8)
      007CA7                        958 00122$:
                                    959 ;	quantum/action_util.c:90: if (ak820_macro_primitive) {
      007CA7 90 09 8D         [24]  960 	mov	dptr,#_ak820_macro_primitive
      007CAA E0               [24]  961 	movx	a,@dptr
      007CAB 60 37            [24]  962 	jz	00102$
                                    963 ;	quantum/action_util.c:91: uint8_t old = macro_mods[kind];
      007CAD EE               [12]  964 	mov	a,r6
      007CAE 24 8B            [12]  965 	add	a, #_macro_mods
      007CB0 FB               [12]  966 	mov	r3,a
      007CB1 E4               [12]  967 	clr	a
      007CB2 34 09            [12]  968 	addc	a, #(_macro_mods >> 8)
      007CB4 FC               [12]  969 	mov	r4,a
      007CB5 12 48 B7         [24]  970 	lcall	_ak820_outline_0065
                                    971 ;	quantum/action_util.c:92: macro_mods[kind] = pressed ? old | mods : old & ~mods;
      007CB8 E5 54            [12]  972 	mov	a,_change_owned_sloc1_1_0
      007CBA 60 0A            [24]  973 	jz	00123$
      007CBC 90 09 94         [24]  974 	mov	dptr,#_change_owned_mods_10000_308
      007CBF E0               [24]  975 	movx	a,@dptr
      007CC0 F9               [12]  976 	mov	r1,a
      007CC1 EA               [12]  977 	mov	a,r2
      007CC2 42 01            [12]  978 	orl	ar1,a
      007CC4 80 07            [24]  979 	sjmp	00124$
      007CC6                        980 00123$:
      007CC6 90 09 94         [24]  981 	mov	dptr,#_change_owned_mods_10000_308
      007CC9 E0               [24]  982 	movx	a,@dptr
      007CCA F4               [12]  983 	cpl	a
      007CCB 5A               [12]  984 	anl	a,r2
      007CCC F9               [12]  985 	mov	r1,a
      007CCD                        986 00124$:
      007CCD 12 33 FC         [24]  987 	lcall	_ak820_outline_0125
      007CD0 E9               [12]  988 	mov	a,r1
      007CD1 F0               [24]  989 	movx	@dptr,a
                                    990 ;	quantum/action_util.c:93: mods &= pressed ? ~old : old;
      007CD2 E5 54            [12]  991 	mov	a,_change_owned_sloc1_1_0
      007CD4 60 06            [24]  992 	jz	00125$
      007CD6 74 FF            [12]  993 	mov	a,#0xff
      007CD8 6A               [12]  994 	xrl	a,r2
      007CD9 FC               [12]  995 	mov	r4,a
      007CDA 80 02            [24]  996 	sjmp	00126$
      007CDC                        997 00125$:
      007CDC 8A 04            [24]  998 	mov	ar4,r2
      007CDE                        999 00126$:
      007CDE 90 09 94         [24] 1000 	mov	dptr,#_change_owned_mods_10000_308
      007CE1 E0               [24] 1001 	movx	a,@dptr
      007CE2 5C               [12] 1002 	anl	a,r4
      007CE3 F0               [24] 1003 	movx	@dptr,a
      007CE4                       1004 00102$:
                                   1005 ;	quantum/action_util.c:95: uint8_t result = 0;
      007CE4 90 09 95         [24] 1006 	mov	dptr,#_change_owned_result_10001_312
      007CE7 E4               [12] 1007 	clr	a
      007CE8 F0               [24] 1008 	movx	@dptr,a
                                   1009 ;	quantum/action_util.c:96: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      007CE9 90 09 96         [24] 1010 	mov	dptr,#_change_owned_bit_20001_313
      007CEC 04               [12] 1011 	inc	a
      007CED F0               [24] 1012 	movx	@dptr,a
      007CEE 90 09 94         [24] 1013 	mov	dptr,#_change_owned_mods_10000_308
      007CF1 E0               [24] 1014 	movx	a,@dptr
      007CF2 FC               [12] 1015 	mov	r4,a
      007CF3 7B 00            [12] 1016 	mov	r3,#0x00
      007CF5                       1017 00117$:
      007CF5 BB 08 00         [24] 1018 	cjne	r3,#0x08,00210$
      007CF8                       1019 00210$:
      007CF8 50 3F            [24] 1020 	jnc	00112$
                                   1021 ;	quantum/action_util.c:97: if (mods & bit) {
      007CFA 90 09 96         [24] 1022 	mov	dptr,#_change_owned_bit_20001_313
      007CFD E0               [24] 1023 	movx	a,@dptr
      007CFE 5C               [12] 1024 	anl	a,r4
      007CFF 60 1C            [24] 1025 	jz	00109$
                                   1026 ;	quantum/action_util.c:98: if (pressed) ++refs[i];
      007D01 E5 54            [12] 1027 	mov	a,_change_owned_sloc1_1_0
      007D03 60 0C            [24] 1028 	jz	00106$
      007D05 EB               [12] 1029 	mov	a,r3
      007D06 2D               [12] 1030 	add	a, r5
      007D07 12 38 27         [24] 1031 	lcall	_ak820_outline_0017
      007D0A F8               [12] 1032 	mov	r0,a
      007D0B 08               [12] 1033 	inc	r0
      007D0C 12 81 9B         [24] 1034 	lcall	_ak820_outline_0064
      007D0F 80 0C            [24] 1035 	sjmp	00109$
      007D11                       1036 00106$:
                                   1037 ;	quantum/action_util.c:99: else if (refs[i]) --refs[i];
      007D11 EB               [12] 1038 	mov	a,r3
      007D12 2D               [12] 1039 	add	a, r5
      007D13 12 38 27         [24] 1040 	lcall	_ak820_outline_0017
      007D16 F8               [12] 1041 	mov	r0,a
      007D17 60 04            [24] 1042 	jz	00109$
      007D19 18               [12] 1043 	dec	r0
      007D1A 12 81 9B         [24] 1044 	lcall	_ak820_outline_0064
      007D1D                       1045 00109$:
                                   1046 ;	quantum/action_util.c:101: if (refs[i]) result |= bit;
      007D1D EB               [12] 1047 	mov	a,r3
      007D1E 2D               [12] 1048 	add	a, r5
      007D1F 12 38 27         [24] 1049 	lcall	_ak820_outline_0017
      007D22 60 0B            [24] 1050 	jz	00118$
      007D24 90 09 96         [24] 1051 	mov	dptr,#_change_owned_bit_20001_313
      007D27 E0               [24] 1052 	movx	a,@dptr
      007D28 FA               [12] 1053 	mov	r2,a
      007D29 90 09 95         [24] 1054 	mov	dptr,#_change_owned_result_10001_312
      007D2C E0               [24] 1055 	movx	a,@dptr
      007D2D 4A               [12] 1056 	orl	a,r2
      007D2E F0               [24] 1057 	movx	@dptr,a
      007D2F                       1058 00118$:
                                   1059 ;	quantum/action_util.c:96: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      007D2F 0B               [12] 1060 	inc	r3
      007D30 90 09 96         [24] 1061 	mov	dptr,#_change_owned_bit_20001_313
      007D33 E0               [24] 1062 	movx	a,@dptr
      007D34 25 E0            [12] 1063 	add	a,acc
      007D36 F0               [24] 1064 	movx	@dptr,a
      007D37 80 BC            [24] 1065 	sjmp	00117$
      007D39                       1066 00112$:
                                   1067 ;	quantum/action_util.c:103: if (kind) owned_weak_mods = result;
      007D39 EE               [12] 1068 	mov	a,r6
      007D3A 60 09            [24] 1069 	jz	00114$
      007D3C 90 09 95         [24] 1070 	mov	dptr,#_change_owned_result_10001_312
      007D3F E0               [24] 1071 	movx	a,@dptr
      007D40 90 09 8A         [24] 1072 	mov	dptr,#_owned_weak_mods
      007D43 F0               [24] 1073 	movx	@dptr,a
      007D44 22               [24] 1074 	ret
      007D45                       1075 00114$:
                                   1076 ;	quantum/action_util.c:104: else owned_mods = result;
      007D45 90 09 95         [24] 1077 	mov	dptr,#_change_owned_result_10001_312
      007D48 E0               [24] 1078 	movx	a,@dptr
      007D49 90 09 89         [24] 1079 	mov	dptr,#_owned_mods
      007D4C F0               [24] 1080 	movx	@dptr,a
                                   1081 ;	quantum/action_util.c:105: }
      007D4D 22               [24] 1082 	ret
                                   1083 ;------------------------------------------------------------
                                   1084 ;Allocation info for local variables in function 'add_owned_mods'
                                   1085 ;------------------------------------------------------------
                                   1086 ;mods          Allocated with name '_add_owned_mods_mods_10000_321'
                                   1087 ;------------------------------------------------------------
                                   1088 ;	quantum/action_util.c:106: void add_owned_mods(uint8_t mods) { change_owned(mods, 1); }
                                   1089 ;	-----------------------------------------
                                   1090 ;	 function add_owned_mods
                                   1091 ;	-----------------------------------------
      007D4E                       1092 _add_owned_mods:
      007D4E E5 82            [12] 1093 	mov	a,dpl
      007D50 90 09 97         [24] 1094 	mov	dptr,#_add_owned_mods_mods_10000_321
      007D53 12 81 BB         [24] 1095 	lcall	_ak820_outline_0120
      007D56 74 01            [12] 1096 	mov	a,#0x01
      007D58 F0               [24] 1097 	movx	@dptr,a
      007D59 8F 82            [24] 1098 	mov	dpl, r7
      007D5B 02 7C 7E         [24] 1099 	ljmp	_change_owned
                                   1100 ;------------------------------------------------------------
                                   1101 ;Allocation info for local variables in function 'del_owned_mods'
                                   1102 ;------------------------------------------------------------
                                   1103 ;mods          Allocated with name '_del_owned_mods_mods_10000_323'
                                   1104 ;------------------------------------------------------------
                                   1105 ;	quantum/action_util.c:107: void del_owned_mods(uint8_t mods) { change_owned(mods, 0); }
                                   1106 ;	-----------------------------------------
                                   1107 ;	 function del_owned_mods
                                   1108 ;	-----------------------------------------
      007D5E                       1109 _del_owned_mods:
      007D5E E5 82            [12] 1110 	mov	a,dpl
      007D60 90 09 98         [24] 1111 	mov	dptr,#_del_owned_mods_mods_10000_323
      007D63 12 81 BB         [24] 1112 	lcall	_ak820_outline_0120
      007D66 E4               [12] 1113 	clr	a
      007D67 F0               [24] 1114 	movx	@dptr,a
      007D68 8F 82            [24] 1115 	mov	dpl, r7
      007D6A 02 7C 7E         [24] 1116 	ljmp	_change_owned
                                   1117 ;------------------------------------------------------------
                                   1118 ;Allocation info for local variables in function 'add_owned_weak_mods'
                                   1119 ;------------------------------------------------------------
                                   1120 ;mods          Allocated with name '_add_owned_weak_mods_mods_10000_325'
                                   1121 ;------------------------------------------------------------
                                   1122 ;	quantum/action_util.c:108: void add_owned_weak_mods(uint8_t mods) { change_owned(mods, 3); }
                                   1123 ;	-----------------------------------------
                                   1124 ;	 function add_owned_weak_mods
                                   1125 ;	-----------------------------------------
      007D6D                       1126 _add_owned_weak_mods:
      007D6D E5 82            [12] 1127 	mov	a,dpl
      007D6F 90 09 99         [24] 1128 	mov	dptr,#_add_owned_weak_mods_mods_10000_325
      007D72 12 81 BB         [24] 1129 	lcall	_ak820_outline_0120
      007D75 74 03            [12] 1130 	mov	a,#0x03
      007D77 F0               [24] 1131 	movx	@dptr,a
      007D78 8F 82            [24] 1132 	mov	dpl, r7
      007D7A 02 7C 7E         [24] 1133 	ljmp	_change_owned
                                   1134 ;------------------------------------------------------------
                                   1135 ;Allocation info for local variables in function 'del_owned_weak_mods'
                                   1136 ;------------------------------------------------------------
                                   1137 ;mods          Allocated with name '_del_owned_weak_mods_mods_10000_327'
                                   1138 ;------------------------------------------------------------
                                   1139 ;	quantum/action_util.c:109: void del_owned_weak_mods(uint8_t mods) { change_owned(mods, 2); }
                                   1140 ;	-----------------------------------------
                                   1141 ;	 function del_owned_weak_mods
                                   1142 ;	-----------------------------------------
      007D7D                       1143 _del_owned_weak_mods:
      007D7D E5 82            [12] 1144 	mov	a,dpl
      007D7F 90 09 9A         [24] 1145 	mov	dptr,#_del_owned_weak_mods_mods_10000_327
      007D82 12 81 BB         [24] 1146 	lcall	_ak820_outline_0120
      007D85 74 02            [12] 1147 	mov	a,#0x02
      007D87 F0               [24] 1148 	movx	@dptr,a
      007D88 8F 82            [24] 1149 	mov	dpl, r7
      007D8A 02 7C 7E         [24] 1150 	ljmp	_change_owned
                                   1151 ;------------------------------------------------------------
                                   1152 ;Allocation info for local variables in function 'clear_owned_mods'
                                   1153 ;------------------------------------------------------------
                                   1154 ;i             Allocated with name '_clear_owned_mods_i_20000_331'
                                   1155 ;------------------------------------------------------------
                                   1156 ;	quantum/action_util.c:110: void clear_owned_mods(void) {
                                   1157 ;	-----------------------------------------
                                   1158 ;	 function clear_owned_mods
                                   1159 ;	-----------------------------------------
      007D8D                       1160 _clear_owned_mods:
                                   1161 ;	quantum/action_util.c:111: for (uint8_t i = 0; i < 8; ++i) owned_mod_refs[i] = owned_weak_refs[i] = 0;
      007D8D 7F 00            [12] 1162 	mov	r7,#0x00
      007D8F                       1163 00103$:
      007D8F BF 08 00         [24] 1164 	cjne	r7,#0x08,00122$
      007D92                       1165 00122$:
      007D92 50 1A            [24] 1166 	jnc	00101$
      007D94 EF               [12] 1167 	mov	a,r7
      007D95 24 79            [12] 1168 	add	a, #_owned_mod_refs
      007D97 FD               [12] 1169 	mov	r5,a
      007D98 E4               [12] 1170 	clr	a
      007D99 34 09            [12] 1171 	addc	a, #(_owned_mod_refs >> 8)
      007D9B FE               [12] 1172 	mov	r6,a
      007D9C EF               [12] 1173 	mov	a,r7
      007D9D 24 81            [12] 1174 	add	a, #_owned_weak_refs
      007D9F F5 82            [12] 1175 	mov	dpl,a
      007DA1 E4               [12] 1176 	clr	a
      007DA2 34 09            [12] 1177 	addc	a, #(_owned_weak_refs >> 8)
      007DA4 F5 83            [12] 1178 	mov	dph,a
      007DA6 E4               [12] 1179 	clr	a
      007DA7 F0               [24] 1180 	movx	@dptr,a
      007DA8 12 81 C2         [24] 1181 	lcall	_ak820_outline_0124
      007DAB 0F               [12] 1182 	inc	r7
      007DAC 80 E1            [24] 1183 	sjmp	00103$
      007DAE                       1184 00101$:
                                   1185 ;	quantum/action_util.c:112: owned_mods = owned_weak_mods = macro_mods[0] = macro_mods[1] = 0;
      007DAE 90 09 8C         [24] 1186 	mov	dptr,#(_macro_mods + 0x0001)
      007DB1 E4               [12] 1187 	clr	a
      007DB2 F0               [24] 1188 	movx	@dptr,a
      007DB3 90 09 8B         [24] 1189 	mov	dptr,#_macro_mods
      007DB6 F0               [24] 1190 	movx	@dptr,a
      007DB7 90 09 8A         [24] 1191 	mov	dptr,#_owned_weak_mods
      007DBA F0               [24] 1192 	movx	@dptr,a
      007DBB 90 09 89         [24] 1193 	mov	dptr,#_owned_mods
      007DBE F0               [24] 1194 	movx	@dptr,a
                                   1195 ;	quantum/action_util.c:113: ak820_macro_cancelled = true;
      007DBF 90 09 8E         [24] 1196 	mov	dptr,#_ak820_macro_cancelled
      007DC2 04               [12] 1197 	inc	a
      007DC3 F0               [24] 1198 	movx	@dptr,a
                                   1199 ;	quantum/action_util.c:114: }
      007DC4 22               [24] 1200 	ret
                                   1201 ;------------------------------------------------------------
                                   1202 ;Allocation info for local variables in function 'clear_owned_keys'
                                   1203 ;------------------------------------------------------------
                                   1204 ;i             Allocated with name '_clear_owned_keys_i_20000_334'
                                   1205 ;i             Allocated with name '_clear_owned_keys_i_20000_335'
                                   1206 ;------------------------------------------------------------
                                   1207 ;	quantum/action_util.c:120: void clear_owned_keys(void) {
                                   1208 ;	-----------------------------------------
                                   1209 ;	 function clear_owned_keys
                                   1210 ;	-----------------------------------------
      007DC5                       1211 _clear_owned_keys:
                                   1212 ;	quantum/action_util.c:121: for (uint8_t i = 0; i <= KC_EXSEL; ++i) key_refs[i] = 0;
      007DC5 7F 00            [12] 1213 	mov	r7,#0x00
      007DC7                       1214 00104$:
      007DC7 EF               [12] 1215 	mov	a,r7
      007DC8 24 5B            [12] 1216 	add	a,#0xff - 0xa4
      007DCA 40 0D            [24] 1217 	jc	00101$
                                   1218 ;	free result
      007DCC EF               [12] 1219 	mov	a,r7
      007DCD 24 9B            [12] 1220 	add	a, #_key_refs
      007DCF F5 82            [12] 1221 	mov	dpl,a
      007DD1 E4               [12] 1222 	clr	a
      007DD2 34 09            [12] 1223 	addc	a, #(_key_refs >> 8)
      007DD4 12 7B 77         [24] 1224 	lcall	_ak820_outline_0166
      007DD7 80 EE            [24] 1225 	sjmp	00104$
      007DD9                       1226 00101$:
                                   1227 ;	quantum/action_util.c:122: distinct_keys = 0;
      007DD9 90 0A 40         [24] 1228 	mov	dptr,#_distinct_keys
      007DDC E4               [12] 1229 	clr	a
      007DDD F0               [24] 1230 	movx	@dptr,a
                                   1231 ;	quantum/action_util.c:123: for (uint8_t i = 0; i < sizeof(macro_keys); ++i) macro_keys[i] = 0;
      007DDE FF               [12] 1232 	mov	r7,a
      007DDF                       1233 00107$:
      007DDF BF 15 00         [24] 1234 	cjne	r7,#0x15,00142$
      007DE2                       1235 00142$:
      007DE2 50 0D            [24] 1236 	jnc	00109$
      007DE4 EF               [12] 1237 	mov	a,r7
      007DE5 24 41            [12] 1238 	add	a, #_macro_keys
      007DE7 F5 82            [12] 1239 	mov	dpl,a
      007DE9 E4               [12] 1240 	clr	a
      007DEA 34 0A            [12] 1241 	addc	a, #(_macro_keys >> 8)
      007DEC 12 7B 77         [24] 1242 	lcall	_ak820_outline_0166
      007DEF 80 EE            [24] 1243 	sjmp	00107$
      007DF1                       1244 00109$:
                                   1245 ;	quantum/action_util.c:124: }
      007DF1 22               [24] 1246 	ret
                                   1247 ;------------------------------------------------------------
                                   1248 ;Allocation info for local variables in function 'add_owned_key'
                                   1249 ;------------------------------------------------------------
                                   1250 ;code          Allocated with name '_add_owned_key_code_10000_336'
                                   1251 ;__400000074   Allocated with name '_add_owned_key___400000074_40000_345'
                                   1252 ;key           Allocated with name '_add_owned_key_key_50000_346'
                                   1253 ;i             Allocated with name '_add_owned_key_i_40000_344'
                                   1254 ;__300000076   Allocated with name '_add_owned_key___300000076_30000_348'
                                   1255 ;key           Allocated with name '_add_owned_key_key_40000_349'
                                   1256 ;------------------------------------------------------------
                                   1257 ;	quantum/action_util.c:125: bool add_owned_key(uint8_t code) {
                                   1258 ;	-----------------------------------------
                                   1259 ;	 function add_owned_key
                                   1260 ;	-----------------------------------------
      007DF2                       1261 _add_owned_key:
      007DF2 E5 82            [12] 1262 	mov	a,dpl
      007DF4 90 0A 56         [24] 1263 	mov	dptr,#_add_owned_key_code_10000_336
      007DF7 12 81 D3         [24] 1264 	lcall	_ak820_outline_0134
                                   1265 ;	quantum/action_util.c:126: if (!ak820_macro_change(macro_keys, code, true)) return false;
      007DFA 74 01            [12] 1266 	mov	a,#0x01
      007DFC F0               [24] 1267 	movx	@dptr,a
      007DFD 90 0A 41         [24] 1268 	mov	dptr,#_macro_keys
      007E00 C0 07            [24] 1269 	push	ar7
      007E02 12 7C 12         [24] 1270 	lcall	_ak820_macro_change
      007E05 E5 82            [12] 1271 	mov	a, dpl
      007E07 D0 07            [24] 1272 	pop	ar7
      007E09 70 03            [24] 1273 	jnz	00102$
      007E0B F5 82            [12] 1274 	mov	dpl,a
      007E0D 22               [24] 1275 	ret
      007E0E                       1276 00102$:
                                   1277 ;	quantum/action_util.c:127: if (key_refs[code]++) return false;
      007E0E 12 81 85         [24] 1278 	lcall	_ak820_outline_0030
      007E11 FC               [12] 1279 	mov	r4,a
      007E12 04               [12] 1280 	inc	a
      007E13 12 81 C2         [24] 1281 	lcall	_ak820_outline_0124
      007E16 EC               [12] 1282 	mov	a,r4
      007E17 60 04            [24] 1283 	jz	00104$
      007E19 75 82 00         [24] 1284 	mov	dpl, #0x00
      007E1C 22               [24] 1285 	ret
      007E1D                       1286 00104$:
                                   1287 ;	quantum/action_util.c:128: ++distinct_keys;
      007E1D 90 0A 40         [24] 1288 	mov	dptr,#_distinct_keys
      007E20 E0               [24] 1289 	movx	a,@dptr
      007E21 24 01            [12] 1290 	add	a, #0x01
      007E23 F0               [24] 1291 	movx	@dptr,a
                                   1292 ;	quantum/action_util.c:130: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      007E24 90 0D B9         [24] 1293 	mov	dptr,#_keyboard_protocol
      007E27 E0               [24] 1294 	movx	a,@dptr
      007E28 60 15            [24] 1295 	jz	00106$
      007E2A 90 0A C5         [24] 1296 	mov	dptr,#_keymap_config
      007E2D E0               [24] 1297 	movx	a,@dptr
      007E2E 30 E7 0E         [24] 1298 	jnb	acc.7,00106$
                                   1299 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      007E31 90 08 03         [24] 1300 	mov	dptr,#_add_key_to_report_PARM_2
      007E34 EF               [12] 1301 	mov	a,r7
      007E35 12 81 93         [24] 1302 	lcall	_ak820_outline_0058
      007E38 12 6E D9         [24] 1303 	lcall	_add_key_to_report
                                   1304 ;	quantum/action_util.c:130: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      007E3B 75 82 01         [24] 1305 	mov	dpl, #0x01
      007E3E 22               [24] 1306 	ret
      007E3F                       1307 00106$:
                                   1308 ;	quantum/action_util.c:132: if (distinct_keys > KEYBOARD_REPORT_KEYS) {
      007E3F 90 0A 40         [24] 1309 	mov	dptr,#_distinct_keys
      007E42 E0               [24] 1310 	movx	a,@dptr
      007E43 24 F9            [12] 1311 	add	a,#0xff - 0x06
      007E45 50 17            [24] 1312 	jnc	00110$
                                   1313 ;	free result
                                   1314 ;	quantum/action_util.c:133: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; ++i) keyboard_report->keys[i] = 1; /* HID ErrorRollOver */
      007E47 7F 00            [12] 1315 	mov	r7,#0x00
      007E49                       1316 00115$:
      007E49 BF 06 00         [24] 1317 	cjne	r7,#0x06,00174$
      007E4C                       1318 00174$:
      007E4C 50 1D            [24] 1319 	jnc	00111$
      007E4E EF               [12] 1320 	mov	a,r7
      007E4F 24 CE            [12] 1321 	add	a, #(_actual_keyboard_report + 0x0002)
      007E51 F5 82            [12] 1322 	mov	dpl,a
      007E53 E4               [12] 1323 	clr	a
      007E54 34 0D            [12] 1324 	addc	a, #((_actual_keyboard_report + 0x0002) >> 8)
      007E56 F5 83            [12] 1325 	mov	dph,a
      007E58 74 01            [12] 1326 	mov	a,#0x01
      007E5A F0               [24] 1327 	movx	@dptr,a
      007E5B 0F               [12] 1328 	inc	r7
      007E5C 80 EB            [24] 1329 	sjmp	00115$
      007E5E                       1330 00110$:
                                   1331 ;	quantum/action_util.c:134: } else add_key(code);
      007E5E 90 0A 56         [24] 1332 	mov	dptr,#_add_owned_key_code_10000_336
      007E61 E0               [24] 1333 	movx	a,@dptr
                                   1334 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      007E62 90 08 03         [24] 1335 	mov	dptr,#_add_key_to_report_PARM_2
      007E65 12 81 93         [24] 1336 	lcall	_ak820_outline_0058
      007E68 12 6E D9         [24] 1337 	lcall	_add_key_to_report
                                   1338 ;	quantum/action_util.c:134: } else add_key(code);
      007E6B                       1339 00111$:
                                   1340 ;	quantum/action_util.c:135: return true;
      007E6B 75 82 01         [24] 1341 	mov	dpl, #0x01
                                   1342 ;	quantum/action_util.c:136: }
      007E6E 22               [24] 1343 	ret
                                   1344 ;------------------------------------------------------------
                                   1345 ;Allocation info for local variables in function 'del_owned_key'
                                   1346 ;------------------------------------------------------------
                                   1347 ;code          Allocated with name '_del_owned_key_code_10000_351'
                                   1348 ;__400000078   Allocated with name '_del_owned_key___400000078_40000_362'
                                   1349 ;key           Allocated with name '_del_owned_key_key_50000_363'
                                   1350 ;key           Allocated with name '_del_owned_key_key_40000_360'
                                   1351 ;__600000081   Allocated with name '_del_owned_key___600000081_60000_368'
                                   1352 ;key           Allocated with name '_del_owned_key_key_70000_369'
                                   1353 ;__300000083   Allocated with name '_del_owned_key___300000083_30000_371'
                                   1354 ;key           Allocated with name '_del_owned_key_key_40000_372'
                                   1355 ;------------------------------------------------------------
                                   1356 ;	quantum/action_util.c:137: bool del_owned_key(uint8_t code) {
                                   1357 ;	-----------------------------------------
                                   1358 ;	 function del_owned_key
                                   1359 ;	-----------------------------------------
      007E6F                       1360 _del_owned_key:
      007E6F E5 82            [12] 1361 	mov	a,dpl
      007E71 90 0A 57         [24] 1362 	mov	dptr,#_del_owned_key_code_10000_351
      007E74 12 81 D3         [24] 1363 	lcall	_ak820_outline_0134
                                   1364 ;	quantum/action_util.c:138: if (!ak820_macro_change(macro_keys, code, false)) return false;
      007E77 E4               [12] 1365 	clr	a
      007E78 F0               [24] 1366 	movx	@dptr,a
      007E79 90 0A 41         [24] 1367 	mov	dptr,#_macro_keys
      007E7C C0 07            [24] 1368 	push	ar7
      007E7E 12 7C 12         [24] 1369 	lcall	_ak820_macro_change
      007E81 E5 82            [12] 1370 	mov	a, dpl
      007E83 D0 07            [24] 1371 	pop	ar7
      007E85 70 03            [24] 1372 	jnz	00102$
      007E87 F5 82            [12] 1373 	mov	dpl,a
      007E89 22               [24] 1374 	ret
      007E8A                       1375 00102$:
                                   1376 ;	quantum/action_util.c:139: if (!key_refs[code] || --key_refs[code]) return false;
      007E8A 12 81 85         [24] 1377 	lcall	_ak820_outline_0030
      007E8D FC               [12] 1378 	mov	r4,a
      007E8E 60 09            [24] 1379 	jz	00103$
      007E90 1C               [12] 1380 	dec	r4
      007E91 12 38 9C         [24] 1381 	lcall	_ak820_outline_0135
      007E94 EC               [12] 1382 	mov	a,r4
      007E95 F0               [24] 1383 	movx	@dptr,a
      007E96 EC               [12] 1384 	mov	a,r4
      007E97 60 04            [24] 1385 	jz	00104$
      007E99                       1386 00103$:
      007E99 75 82 00         [24] 1387 	mov	dpl, #0x00
      007E9C 22               [24] 1388 	ret
      007E9D                       1389 00104$:
                                   1390 ;	quantum/action_util.c:140: --distinct_keys;
      007E9D 90 0A 40         [24] 1391 	mov	dptr,#_distinct_keys
      007EA0 E0               [24] 1392 	movx	a,@dptr
      007EA1 14               [12] 1393 	dec	a
      007EA2 F0               [24] 1394 	movx	@dptr,a
                                   1395 ;	quantum/action_util.c:142: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      007EA3 90 0D B9         [24] 1396 	mov	dptr,#_keyboard_protocol
      007EA6 E0               [24] 1397 	movx	a,@dptr
      007EA7 60 15            [24] 1398 	jz	00107$
      007EA9 90 0A C5         [24] 1399 	mov	dptr,#_keymap_config
      007EAC E0               [24] 1400 	movx	a,@dptr
      007EAD 30 E7 0E         [24] 1401 	jnb	acc.7,00107$
                                   1402 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      007EB0 90 08 07         [24] 1403 	mov	dptr,#_del_key_from_report_PARM_2
      007EB3 EF               [12] 1404 	mov	a,r7
      007EB4 12 81 93         [24] 1405 	lcall	_ak820_outline_0058
      007EB7 12 6F 17         [24] 1406 	lcall	_del_key_from_report
                                   1407 ;	quantum/action_util.c:142: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      007EBA 75 82 01         [24] 1408 	mov	dpl, #0x01
      007EBD 22               [24] 1409 	ret
      007EBE                       1410 00107$:
                                   1411 ;	quantum/action_util.c:144: if (distinct_keys > KEYBOARD_REPORT_KEYS) return true;
      007EBE 90 0A 40         [24] 1412 	mov	dptr,#_distinct_keys
      007EC1 E0               [24] 1413 	movx	a,@dptr
      007EC2 FF               [12] 1414 	mov  r7,a
      007EC3 24 F9            [12] 1415 	add	a,#0xff - 0x06
      007EC5 50 04            [24] 1416 	jnc	00110$
                                   1417 ;	free result
      007EC7 75 82 01         [24] 1418 	mov	dpl, #0x01
      007ECA 22               [24] 1419 	ret
      007ECB                       1420 00110$:
                                   1421 ;	quantum/action_util.c:145: if (distinct_keys == KEYBOARD_REPORT_KEYS) {
      007ECB BF 06 26         [24] 1422 	cjne	r7,#0x06,00115$
                                   1423 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007ECE 90 0D CC         [24] 1424 	mov	dptr,#_actual_keyboard_report
      007ED1 75 F0 00         [24] 1425 	mov	b, #0x00
      007ED4 12 6F 55         [24] 1426 	lcall	_clear_keys_from_report
                                   1427 ;	quantum/action_util.c:148: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      007ED7 7F 04            [12] 1428 	mov	r7,#0x04
      007ED9                       1429 00122$:
      007ED9 EF               [12] 1430 	mov	a,r7
      007EDA 24 5B            [12] 1431 	add	a,#0xff - 0xa4
      007EDC 40 23            [24] 1432 	jc	00116$
                                   1433 ;	free result
      007EDE 12 81 85         [24] 1434 	lcall	_ak820_outline_0030
      007EE1 60 0E            [24] 1435 	jz	00123$
                                   1436 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      007EE3 90 08 03         [24] 1437 	mov	dptr,#_add_key_to_report_PARM_2
      007EE6 EF               [12] 1438 	mov	a,r7
      007EE7 12 81 93         [24] 1439 	lcall	_ak820_outline_0058
      007EEA C0 07            [24] 1440 	push	ar7
      007EEC 12 6E D9         [24] 1441 	lcall	_add_key_to_report
      007EEF D0 07            [24] 1442 	pop	ar7
                                   1443 ;	quantum/action_util.c:148: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      007EF1                       1444 00123$:
      007EF1 0F               [12] 1445 	inc	r7
      007EF2 80 E5            [24] 1446 	sjmp	00122$
      007EF4                       1447 00115$:
                                   1448 ;	quantum/action_util.c:149: } else del_key(code);
      007EF4 90 0A 57         [24] 1449 	mov	dptr,#_del_owned_key_code_10000_351
      007EF7 E0               [24] 1450 	movx	a,@dptr
                                   1451 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      007EF8 90 08 07         [24] 1452 	mov	dptr,#_del_key_from_report_PARM_2
      007EFB 12 81 93         [24] 1453 	lcall	_ak820_outline_0058
      007EFE 12 6F 17         [24] 1454 	lcall	_del_key_from_report
                                   1455 ;	quantum/action_util.c:149: } else del_key(code);
      007F01                       1456 00116$:
                                   1457 ;	quantum/action_util.c:150: return true;
      007F01 75 82 01         [24] 1458 	mov	dpl, #0x01
                                   1459 ;	quantum/action_util.c:151: }
      007F04 22               [24] 1460 	ret
                                   1461 ;------------------------------------------------------------
                                   1462 ;Allocation info for local variables in function 'clear_owned_usages'
                                   1463 ;------------------------------------------------------------
                                   1464 ;i             Allocated with name '_clear_owned_usages_i_20000_376'
                                   1465 ;i             Allocated with name '_clear_owned_usages_i_20000_377'
                                   1466 ;------------------------------------------------------------
                                   1467 ;	quantum/action_util.c:161: void clear_owned_usages(void) {
                                   1468 ;	-----------------------------------------
                                   1469 ;	 function clear_owned_usages
                                   1470 ;	-----------------------------------------
      007F05                       1471 _clear_owned_usages:
                                   1472 ;	quantum/action_util.c:162: for (uint8_t i = 0; i < USAGE_COUNT; ++i) usage_refs[i] = usage_order[i] = 0;
      007F05 7F 00            [12] 1473 	mov	r7,#0x00
      007F07                       1474 00104$:
      007F07 BF 1E 00         [24] 1475 	cjne	r7,#0x1e,00141$
      007F0A                       1476 00141$:
      007F0A 50 14            [24] 1477 	jnc	00101$
      007F0C EF               [12] 1478 	mov	a,r7
      007F0D 24 58            [12] 1479 	add	a, #_usage_refs
      007F0F FD               [12] 1480 	mov	r5,a
      007F10 E4               [12] 1481 	clr	a
      007F11 34 0A            [12] 1482 	addc	a, #(_usage_refs >> 8)
      007F13 FE               [12] 1483 	mov	r6,a
      007F14 EF               [12] 1484 	mov	a,r7
      007F15 12 81 A2         [24] 1485 	lcall	_ak820_outline_0068
      007F18 E4               [12] 1486 	clr	a
      007F19 F0               [24] 1487 	movx	@dptr,a
      007F1A 12 81 C2         [24] 1488 	lcall	_ak820_outline_0124
      007F1D 0F               [12] 1489 	inc	r7
      007F1E 80 E7            [24] 1490 	sjmp	00104$
      007F20                       1491 00101$:
                                   1492 ;	quantum/action_util.c:163: usage_lengths[0] = usage_lengths[1] = 0;
      007F20 90 0A 95         [24] 1493 	mov	dptr,#(_usage_lengths + 0x0001)
      007F23 E4               [12] 1494 	clr	a
      007F24 F0               [24] 1495 	movx	@dptr,a
      007F25 90 0A 94         [24] 1496 	mov	dptr,#_usage_lengths
      007F28 F0               [24] 1497 	movx	@dptr,a
                                   1498 ;	quantum/action_util.c:164: for (uint8_t i = 0; i < sizeof(macro_usages); ++i) macro_usages[i] = 0;
      007F29 FF               [12] 1499 	mov	r7,a
      007F2A                       1500 00107$:
      007F2A BF 04 00         [24] 1501 	cjne	r7,#0x04,00143$
      007F2D                       1502 00143$:
      007F2D 50 0D            [24] 1503 	jnc	00109$
      007F2F EF               [12] 1504 	mov	a,r7
      007F30 24 96            [12] 1505 	add	a, #_macro_usages
      007F32 F5 82            [12] 1506 	mov	dpl,a
      007F34 E4               [12] 1507 	clr	a
      007F35 34 0A            [12] 1508 	addc	a, #(_macro_usages >> 8)
      007F37 12 7B 77         [24] 1509 	lcall	_ak820_outline_0166
      007F3A 80 EE            [24] 1510 	sjmp	00107$
      007F3C                       1511 00109$:
                                   1512 ;	quantum/action_util.c:165: }
      007F3C 22               [24] 1513 	ret
                                   1514 ;------------------------------------------------------------
                                   1515 ;Allocation info for local variables in function 'owned_usage_key'
                                   1516 ;------------------------------------------------------------
                                   1517 ;pressed       Allocated with name '_owned_usage_key_PARM_2'
                                   1518 ;code          Allocated with name '_owned_usage_key_code_10000_378'
                                   1519 ;__200000085   Allocated with name '_owned_usage_key___200000085_20000_379'
                                   1520 ;which         Allocated with name '_owned_usage_key_which_10000_379'
                                   1521 ;base          Allocated with name '_owned_usage_key_base_10000_379'
                                   1522 ;count         Allocated with name '_owned_usage_key_count_10000_379'
                                   1523 ;index         Allocated with name '_owned_usage_key_index_10000_379'
                                   1524 ;pos           Allocated with name '_owned_usage_key_pos_30001_386'
                                   1525 ;i             Allocated with name '_owned_usage_key_i_40001_387'
                                   1526 ;__300000086   Allocated with name '_owned_usage_key___300000086_30000_390'
                                   1527 ;key           Allocated with name '_owned_usage_key_key_40000_391'
                                   1528 ;------------------------------------------------------------
                                   1529 ;	quantum/action_util.c:166: void owned_usage_key(uint8_t code, bool pressed) {
                                   1530 ;	-----------------------------------------
                                   1531 ;	 function owned_usage_key
                                   1532 ;	-----------------------------------------
      007F3D                       1533 _owned_usage_key:
      007F3D E5 82            [12] 1534 	mov	a,dpl
      007F3F 90 0A 9B         [24] 1535 	mov	dptr,#_owned_usage_key_code_10000_378
      007F42 F0               [24] 1536 	movx	@dptr,a
                                   1537 ;	quantum/action_util.c:167: uint8_t which = code >= KC_AUDIO_MUTE;
      007F43 E0               [24] 1538 	movx	a,@dptr
      007F44 FF               [12] 1539 	mov	r7,a
      007F45 BF A8 00         [24] 1540 	cjne	r7,#0xa8,00244$
      007F48                       1541 00244$:
      007F48 B3               [12] 1542 	cpl	c
      007F49 92 25            [24] 1543 	mov	_owned_usage_key_sloc0_1_0,c
      007F4B E4               [12] 1544 	clr	a
      007F4C 33               [12] 1545 	rlc	a
      007F4D FF               [12] 1546 	mov	r7,a
      007F4E 90 0A 9E         [24] 1547 	mov	dptr,#_owned_usage_key_which_10000_379
      007F51 F0               [24] 1548 	movx	@dptr,a
                                   1549 ;	quantum/action_util.c:168: uint8_t base = which ? SYSTEM_COUNT : 0;
      007F52 EF               [12] 1550 	mov	a,r7
      007F53 60 02            [24] 1551 	jz	00129$
      007F55 74 03            [12] 1552 	mov	a,#0x03
      007F57                       1553 00129$:
      007F57 FE               [12] 1554 	mov	r6,a
                                   1555 ;	quantum/action_util.c:169: uint8_t count = usage_lengths[which];
      007F58 EF               [12] 1556 	mov	a,r7
      007F59 24 94            [12] 1557 	add	a, #_usage_lengths
      007F5B FD               [12] 1558 	mov	r5,a
      007F5C E4               [12] 1559 	clr	a
      007F5D 34 0A            [12] 1560 	addc	a, #(_usage_lengths >> 8)
      007F5F FF               [12] 1561 	mov	r7,a
      007F60 12 81 DE         [24] 1562 	lcall	_ak820_outline_0192
      007F63 E0               [24] 1563 	movx	a,@dptr
      007F64 FC               [12] 1564 	mov	r4,a
                                   1565 ;	quantum/action_util.c:170: uint8_t index = code - KC_SYSTEM_POWER;
      007F65 90 0A 9B         [24] 1566 	mov	dptr,#_owned_usage_key_code_10000_378
      007F68 E0               [24] 1567 	movx	a,@dptr
      007F69 24 5B            [12] 1568 	add	a,#0x5b
      007F6B FB               [12] 1569 	mov	r3,a
                                   1570 ;	quantum/action_util.c:171: if (!ak820_macro_change(macro_usages, index, pressed)) return;
      007F6C 90 0A 9A         [24] 1571 	mov	dptr,#_owned_usage_key_PARM_2
      007F6F E0               [24] 1572 	movx	a,@dptr
      007F70 FA               [12] 1573 	mov	r2,a
      007F71 90 09 8F         [24] 1574 	mov	dptr,#_ak820_macro_change_PARM_2
      007F74 EB               [12] 1575 	mov	a,r3
      007F75 F0               [24] 1576 	movx	@dptr,a
      007F76 90 09 90         [24] 1577 	mov	dptr,#_ak820_macro_change_PARM_3
      007F79 EA               [12] 1578 	mov	a,r2
      007F7A F0               [24] 1579 	movx	@dptr,a
      007F7B 90 0A 96         [24] 1580 	mov	dptr,#_macro_usages
      007F7E C0 07            [24] 1581 	push	ar7
      007F80 C0 06            [24] 1582 	push	ar6
      007F82 C0 05            [24] 1583 	push	ar5
      007F84 C0 04            [24] 1584 	push	ar4
      007F86 C0 03            [24] 1585 	push	ar3
      007F88 C0 02            [24] 1586 	push	ar2
      007F8A 12 7C 12         [24] 1587 	lcall	_ak820_macro_change
      007F8D E5 82            [12] 1588 	mov	a, dpl
      007F8F D0 02            [24] 1589 	pop	ar2
      007F91 D0 03            [24] 1590 	pop	ar3
      007F93 D0 04            [24] 1591 	pop	ar4
      007F95 D0 05            [24] 1592 	pop	ar5
      007F97 D0 06            [24] 1593 	pop	ar6
      007F99 D0 07            [24] 1594 	pop	ar7
      007F9B 70 01            [24] 1595 	jnz	00102$
      007F9D 22               [24] 1596 	ret
      007F9E                       1597 00102$:
                                   1598 ;	quantum/action_util.c:172: if (pressed) {
      007F9E EA               [12] 1599 	mov	a,r2
      007F9F 60 1B            [24] 1600 	jz	00115$
                                   1601 ;	quantum/action_util.c:173: if (usage_refs[index]++) return;
      007FA1 12 81 AC         [24] 1602 	lcall	_ak820_outline_0075
      007FA4 04               [12] 1603 	inc	a
      007FA5 12 6C 55         [24] 1604 	lcall	_ak820_outline_0141
      007FA8 E8               [12] 1605 	mov	a,r0
      007FA9 60 01            [24] 1606 	jz	00104$
      007FAB 22               [24] 1607 	ret
      007FAC                       1608 00104$:
                                   1609 ;	quantum/action_util.c:174: usage_order[base + count++] = index;
      007FAC 90 0A 9F         [24] 1610 	mov	dptr,#_owned_usage_key_count_10000_379
      007FAF EC               [12] 1611 	mov	a,r4
      007FB0 04               [12] 1612 	inc	a
      007FB1 F0               [24] 1613 	movx	@dptr,a
      007FB2 EC               [12] 1614 	mov	a,r4
      007FB3 2E               [12] 1615 	add	a, r6
      007FB4 12 81 A2         [24] 1616 	lcall	_ak820_outline_0068
      007FB7 EB               [12] 1617 	mov	a,r3
      007FB8 F0               [24] 1618 	movx	@dptr,a
      007FB9 02 80 1D         [24] 1619 	ljmp	00116$
      007FBC                       1620 00115$:
                                   1621 ;	quantum/action_util.c:176: if (!usage_refs[index] || --usage_refs[index]) return;
      007FBC 12 81 AC         [24] 1622 	lcall	_ak820_outline_0075
      007FBF 60 07            [24] 1623 	jz	00105$
      007FC1 18               [12] 1624 	dec	r0
      007FC2 12 81 9B         [24] 1625 	lcall	_ak820_outline_0064
      007FC5 E8               [12] 1626 	mov	a,r0
      007FC6 60 01            [24] 1627 	jz	00106$
      007FC8                       1628 00105$:
      007FC8 22               [24] 1629 	ret
      007FC9                       1630 00106$:
                                   1631 ;	quantum/action_util.c:178: while (usage_order[base + pos] != index) ++pos;
      007FC9 7A 00            [12] 1632 	mov	r2,#0x00
      007FCB                       1633 00108$:
      007FCB EA               [12] 1634 	mov	a,r2
      007FCC 2E               [12] 1635 	add	a, r6
      007FCD 12 81 A2         [24] 1636 	lcall	_ak820_outline_0068
      007FD0 E0               [24] 1637 	movx	a,@dptr
      007FD1 B5 03 02         [24] 1638 	cjne	a,ar3,00251$
      007FD4 80 03            [24] 1639 	sjmp	00167$
      007FD6                       1640 00251$:
      007FD6 0A               [12] 1641 	inc	r2
      007FD7 80 F2            [24] 1642 	sjmp	00108$
      007FD9                       1643 00167$:
      007FD9 90 0A A0         [24] 1644 	mov	dptr,#_owned_usage_key_pos_30001_386
      007FDC EA               [12] 1645 	mov	a,r2
      007FDD F0               [24] 1646 	movx	@dptr,a
                                   1647 ;	quantum/action_util.c:179: --count;
      007FDE 1C               [12] 1648 	dec	r4
      007FDF 90 0A 9F         [24] 1649 	mov	dptr,#_owned_usage_key_count_10000_379
      007FE2 EC               [12] 1650 	mov	a,r4
      007FE3 F0               [24] 1651 	movx	@dptr,a
                                   1652 ;	quantum/action_util.c:180: for (uint8_t i = pos; i < count; ++i) usage_order[base + i] = usage_order[base + i + 1];
      007FE4 8A 03            [24] 1653 	mov	ar3,r2
      007FE6                       1654 00125$:
      007FE6 C3               [12] 1655 	clr	c
      007FE7 EB               [12] 1656 	mov	a,r3
      007FE8 9C               [12] 1657 	subb	a,r4
      007FE9 50 23            [24] 1658 	jnc	00111$
      007FEB C0 05            [24] 1659 	push	ar5
      007FED C0 07            [24] 1660 	push	ar7
      007FEF EB               [12] 1661 	mov	a,r3
      007FF0 2E               [12] 1662 	add	a, r6
      007FF1 FA               [12] 1663 	mov	r2,a
      007FF2 24 76            [12] 1664 	add	a, #_usage_order
      007FF4 F8               [12] 1665 	mov	r0,a
      007FF5 E4               [12] 1666 	clr	a
      007FF6 34 0A            [12] 1667 	addc	a, #(_usage_order >> 8)
      007FF8 F9               [12] 1668 	mov	r1,a
      007FF9 0A               [12] 1669 	inc	r2
      007FFA EA               [12] 1670 	mov	a,r2
      007FFB 33               [12] 1671 	rlc	a
      007FFC 95 E0            [12] 1672 	subb	a,acc
      007FFE FF               [12] 1673 	mov	r7,a
      007FFF EA               [12] 1674 	mov	a,r2
      008000 12 81 C8         [24] 1675 	lcall	_ak820_outline_0127
      008003 12 38 B6         [24] 1676 	lcall	_ak820_outline_0160
      008006 F0               [24] 1677 	movx	@dptr,a
      008007 0B               [12] 1678 	inc	r3
      008008 D0 07            [24] 1679 	pop	ar7
      00800A D0 05            [24] 1680 	pop	ar5
      00800C 80 D8            [24] 1681 	sjmp	00125$
      00800E                       1682 00111$:
                                   1683 ;	quantum/action_util.c:181: usage_lengths[which] = count;
      00800E 12 81 DE         [24] 1684 	lcall	_ak820_outline_0192
      008011 EC               [12] 1685 	mov	a,r4
      008012 F0               [24] 1686 	movx	@dptr,a
                                   1687 ;	quantum/action_util.c:182: if (pos != count) return; /* A non-winning owner changed only storage. */
      008013 90 0A A0         [24] 1688 	mov	dptr,#_owned_usage_key_pos_30001_386
      008016 E0               [24] 1689 	movx	a,@dptr
      008017 B5 04 02         [24] 1690 	cjne	a,ar4,00253$
      00801A 80 01            [24] 1691 	sjmp	00116$
      00801C                       1692 00253$:
      00801C 22               [24] 1693 	ret
      00801D                       1694 00116$:
                                   1695 ;	quantum/action_util.c:184: usage_lengths[which] = count;
      00801D 90 0A 9F         [24] 1696 	mov	dptr,#_owned_usage_key_count_10000_379
      008020 E0               [24] 1697 	movx	a,@dptr
      008021 FC               [12] 1698 	mov	r4,a
      008022 12 81 DE         [24] 1699 	lcall	_ak820_outline_0192
      008025 F0               [24] 1700 	movx	@dptr,a
                                   1701 ;	quantum/action_util.c:185: code = count ? usage_order[base + count - 1] + KC_SYSTEM_POWER : 0;
      008026 EC               [12] 1702 	mov	a,r4
      008027 60 15            [24] 1703 	jz	00131$
      008029 EC               [12] 1704 	mov	a,r4
      00802A 2E               [12] 1705 	add	a, r6
      00802B FE               [12] 1706 	mov	r6,a
      00802C 1E               [12] 1707 	dec	r6
      00802D EE               [12] 1708 	mov	a,r6
      00802E 33               [12] 1709 	rlc	a
      00802F 95 E0            [12] 1710 	subb	a,acc
      008031 FF               [12] 1711 	mov	r7,a
      008032 EE               [12] 1712 	mov	a,r6
      008033 12 81 C8         [24] 1713 	lcall	_ak820_outline_0127
      008036 24 A5            [12] 1714 	add	a,#0xa5
      008038 FE               [12] 1715 	mov	r6,a
      008039 33               [12] 1716 	rlc	a
      00803A 95 E0            [12] 1717 	subb	a,acc
      00803C 80 02            [24] 1718 	sjmp	00132$
      00803E                       1719 00131$:
      00803E 7E 00            [12] 1720 	mov	r6,#0x00
      008040                       1721 00132$:
      008040 90 0A 9B         [24] 1722 	mov	dptr,#_owned_usage_key_code_10000_378
      008043 EE               [12] 1723 	mov	a,r6
      008044 F0               [24] 1724 	movx	@dptr,a
                                   1725 ;	quantum/action_util.c:186: if (which) host_consumer_send(code ? KEYCODE2CONSUMER(code) : 0);
      008045 90 0A 9E         [24] 1726 	mov	dptr,#_owned_usage_key_which_10000_379
      008048 E0               [24] 1727 	movx	a,@dptr
      008049 60 18            [24] 1728 	jz	00118$
      00804B EE               [12] 1729 	mov	a,r6
      00804C 60 0B            [24] 1730 	jz	00133$
      00804E 8E 82            [24] 1731 	mov	dpl, r6
      008050 12 6D 95         [24] 1732 	lcall	_KEYCODE2CONSUMER
      008053 AD 82            [24] 1733 	mov	r5, dpl
      008055 AF 83            [24] 1734 	mov	r7, dph
      008057 80 04            [24] 1735 	sjmp	00134$
      008059                       1736 00133$:
      008059 7D 00            [12] 1737 	mov	r5,#0x00
      00805B 7F 00            [12] 1738 	mov	r7,#0x00
      00805D                       1739 00134$:
      00805D 12 81 DE         [24] 1740 	lcall	_ak820_outline_0192
      008060 02 6D 48         [24] 1741 	ljmp	_host_consumer_send
      008063                       1742 00118$:
                                   1743 ;	quantum/action_util.c:187: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      008063 EE               [12] 1744 	mov	a,r6
      008064 60 22            [24] 1745 	jz	00135$
                                   1746 ;	tmk_core/protocol/report.h:264: if (key < KC_SYSTEM_POWER || key > KC_SYSTEM_WAKE) return 0;
      008066 BE A5 00         [24] 1747 	cjne	r6,#0xa5,00258$
      008069                       1748 00258$:
      008069 40 05            [24] 1749 	jc	00121$
      00806B EE               [12] 1750 	mov	a,r6
      00806C 24 58            [12] 1751 	add	a,#0xff - 0xa7
      00806E 50 08            [24] 1752 	jnc	00122$
                                   1753 ;	free result
      008070                       1754 00121$:
      008070 90 0A 9C         [24] 1755 	mov	dptr,#_owned_usage_key___200000085_20000_379
      008073 12 4F 71         [24] 1756 	lcall	_ak820_outline_0185
      008076 80 09            [24] 1757 	sjmp	00123$
      008078                       1758 00122$:
                                   1759 ;	tmk_core/protocol/report.h:265: return SYSTEM_POWER_DOWN + (key - KC_SYSTEM_POWER);
      008078 74 DC            [12] 1760 	mov	a,#0xdc
      00807A 2E               [12] 1761 	add	a, r6
      00807B 90 0A 9C         [24] 1762 	mov	dptr,#_owned_usage_key___200000085_20000_379
      00807E 12 38 A1         [24] 1763 	lcall	_ak820_outline_0137
                                   1764 ;	quantum/action_util.c:187: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      008081                       1765 00123$:
      008081 90 0A 9C         [24] 1766 	mov	dptr,#_owned_usage_key___200000085_20000_379
      008084 E0               [24] 1767 	movx	a,@dptr
      008085 FF               [12] 1768 	mov	r7,a
      008086 80 02            [24] 1769 	sjmp	00136$
      008088                       1770 00135$:
      008088 7F 00            [12] 1771 	mov	r7,#0x00
      00808A                       1772 00136$:
      00808A 7E 00            [12] 1773 	mov	r6,#0x00
      00808C 12 43 6D         [24] 1774 	lcall	_ak820_outline_0161
                                   1775 ;	quantum/action_util.c:188: }
      00808F 02 6D 18         [24] 1776 	ljmp	_host_system_send
                                   1777 ;------------------------------------------------------------
                                   1778 ;Allocation info for local variables in function 'send_keyboard_report'
                                   1779 ;------------------------------------------------------------
                                   1780 ;mods          Allocated with name '_send_keyboard_report_mods_30000_399'
                                   1781 ;last_report   Allocated with name '_send_keyboard_report_last_report_10001_401'
                                   1782 ;changed       Allocated with name '_send_keyboard_report_changed_10001_401'
                                   1783 ;dest          Allocated with name '_send_keyboard_report_dest_10001_401'
                                   1784 ;src           Allocated with name '_send_keyboard_report_src_10001_401'
                                   1785 ;i             Allocated with name '_send_keyboard_report_i_20001_402'
                                   1786 ;------------------------------------------------------------
                                   1787 ;	quantum/action_util.c:410: void send_keyboard_report(void) {
                                   1788 ;	-----------------------------------------
                                   1789 ;	 function send_keyboard_report
                                   1790 ;	-----------------------------------------
      008092                       1791 _send_keyboard_report:
                                   1792 ;	quantum/action_util.c:411: keyboard_report->mods = real_mods;
      008092 90 0D CA         [24] 1793 	mov	dptr,#_real_mods
      008095 E0               [24] 1794 	movx	a,@dptr
      008096 FF               [12] 1795 	mov	r7,a
      008097 90 0D CC         [24] 1796 	mov	dptr,#_actual_keyboard_report
      00809A F0               [24] 1797 	movx	@dptr,a
                                   1798 ;	quantum/action_util.c:412: keyboard_report->mods |= weak_mods;
      00809B 90 0D CB         [24] 1799 	mov	dptr,#_weak_mods
      00809E E0               [24] 1800 	movx	a,@dptr
      00809F 42 07            [12] 1801 	orl	ar7,a
      0080A1 90 0D CC         [24] 1802 	mov	dptr,#_actual_keyboard_report
      0080A4 EF               [12] 1803 	mov	a,r7
      0080A5 F0               [24] 1804 	movx	@dptr,a
                                   1805 ;	quantum/action_util.c:414: keyboard_report->mods |= owned_mods | owned_weak_mods;
      0080A6 90 09 8A         [24] 1806 	mov	dptr,#_owned_weak_mods
      0080A9 E0               [24] 1807 	movx	a,@dptr
      0080AA FE               [12] 1808 	mov	r6,a
      0080AB 90 09 89         [24] 1809 	mov	dptr,#_owned_mods
      0080AE E0               [24] 1810 	movx	a,@dptr
      0080AF 4E               [12] 1811 	orl	a,r6
      0080B0 42 07            [12] 1812 	orl	ar7,a
      0080B2 90 0D CC         [24] 1813 	mov	dptr,#_actual_keyboard_report
      0080B5 EF               [12] 1814 	mov	a,r7
      0080B6 F0               [24] 1815 	movx	@dptr,a
                                   1816 ;	quantum/action_util.c:438: if (ctrl_gui_swapped) {
      0080B7 30 21 31         [24] 1817 	jnb	_ctrl_gui_swapped,00102$
                                   1818 ;	quantum/action_util.c:439: uint8_t mods = keyboard_report->mods;
      0080BA 90 0D CC         [24] 1819 	mov	dptr,#_actual_keyboard_report
      0080BD E0               [24] 1820 	movx	a,@dptr
      0080BE FF               [12] 1821 	mov	r7,a
                                   1822 ;	quantum/action_util.c:440: keyboard_report->mods = (mods & 0x66) | ((mods & 0x11) << 3) | ((mods & 0x88) >> 3);
      0080BF 74 66            [12] 1823 	mov	a,#0x66
      0080C1 5F               [12] 1824 	anl	a,r7
      0080C2 FE               [12] 1825 	mov	r6,a
      0080C3 8F 05            [24] 1826 	mov	ar5,r7
      0080C5 53 05 11         [24] 1827 	anl	ar5,#0x11
      0080C8 ED               [12] 1828 	mov	a,r5
      0080C9 12 38 C6         [24] 1829 	lcall	_ak820_outline_0191
      0080CC 42 06            [12] 1830 	orl	ar6,a
      0080CE 53 07 88         [24] 1831 	anl	ar7,#0x88
      0080D1 E4               [12] 1832 	clr	a
      0080D2 23               [12] 1833 	rl	a
      0080D3 CF               [12] 1834 	xch	a,r7
      0080D4 12 57 54         [24] 1835 	lcall	_ak820_outline_0174
      0080D7 6F               [12] 1836 	xrl	a,r7
      0080D8 CF               [12] 1837 	xch	a,r7
      0080D9 54 1F            [12] 1838 	anl	a,#0x1f
      0080DB CF               [12] 1839 	xch	a,r7
      0080DC 6F               [12] 1840 	xrl	a,r7
      0080DD CF               [12] 1841 	xch	a,r7
      0080DE 30 E4 02         [24] 1842 	jnb	acc.4,00159$
      0080E1 44 E0            [12] 1843 	orl	a,#0xffffffe0
      0080E3                       1844 00159$:
      0080E3 EF               [12] 1845 	mov	a,r7
      0080E4 42 06            [12] 1846 	orl	ar6,a
      0080E6 90 0D CC         [24] 1847 	mov	dptr,#_actual_keyboard_report
      0080E9 EE               [12] 1848 	mov	a,r6
      0080EA F0               [24] 1849 	movx	@dptr,a
      0080EB                       1850 00102$:
                                   1851 ;	quantum/action_util.c:444: if (gui_disabled) keyboard_report->mods &= ~(MOD_BIT(KC_LGUI) | MOD_BIT(KC_RGUI));
      0080EB 30 20 07         [24] 1852 	jnb	_gui_disabled,00104$
      0080EE 90 0D CC         [24] 1853 	mov	dptr,#_actual_keyboard_report
      0080F1 E0               [24] 1854 	movx	a,@dptr
      0080F2 54 77            [12] 1855 	anl	a,#0x77
      0080F4 F0               [24] 1856 	movx	@dptr,a
      0080F5                       1857 00104$:
                                   1858 ;	quantum/action_util.c:455: bool changed = false;
      0080F5 90 0A C2         [24] 1859 	mov	dptr,#_send_keyboard_report_changed_10001_401
      0080F8 E4               [12] 1860 	clr	a
      0080F9 F0               [24] 1861 	movx	@dptr,a
                                   1862 ;	quantum/action_util.c:457: uint8_t __xdata *dest = (uint8_t __xdata *)&last_report;
                                   1863 ;	quantum/action_util.c:458: const uint8_t __xdata *src = (const uint8_t __xdata *)keyboard_report;
                                   1864 ;	quantum/action_util.c:463: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      0080FA FF               [12] 1865 	mov	r7,a
      0080FB                       1866 00111$:
      0080FB BF 20 00         [24] 1867 	cjne	r7,#0x20,00161$
      0080FE                       1868 00161$:
      0080FE 50 2A            [24] 1869 	jnc	00107$
                                   1870 ;	quantum/action_util.c:464: if (dest[i] != src[i]) {
      008100 EF               [12] 1871 	mov	a,r7
      008101 24 A2            [12] 1872 	add	a, #_send_keyboard_report_last_report_10001_401
      008103 FD               [12] 1873 	mov	r5,a
      008104 E4               [12] 1874 	clr	a
      008105 34 0A            [12] 1875 	addc	a, #(_send_keyboard_report_last_report_10001_401 >> 8)
      008107 12 48 A9         [24] 1876 	lcall	_ak820_outline_0057
      00810A EF               [12] 1877 	mov	a,r7
      00810B 24 CC            [12] 1878 	add	a, #_actual_keyboard_report
      00810D F5 82            [12] 1879 	mov	dpl,a
      00810F E4               [12] 1880 	clr	a
      008110 34 0D            [12] 1881 	addc	a, #(_actual_keyboard_report >> 8)
      008112 F5 83            [12] 1882 	mov	dph,a
      008114 E0               [24] 1883 	movx	a,@dptr
      008115 FB               [12] 1884 	mov	r3,a
      008116 EC               [12] 1885 	mov	a,r4
      008117 B5 03 02         [24] 1886 	cjne	a,ar3,00163$
      00811A 80 0B            [24] 1887 	sjmp	00112$
      00811C                       1888 00163$:
                                   1889 ;	quantum/action_util.c:465: dest[i] = src[i];
      00811C 12 38 9C         [24] 1890 	lcall	_ak820_outline_0135
      00811F EB               [12] 1891 	mov	a,r3
      008120 F0               [24] 1892 	movx	@dptr,a
                                   1893 ;	quantum/action_util.c:466: changed = true;
      008121 90 0A C2         [24] 1894 	mov	dptr,#_send_keyboard_report_changed_10001_401
      008124 74 01            [12] 1895 	mov	a,#0x01
      008126 F0               [24] 1896 	movx	@dptr,a
      008127                       1897 00112$:
                                   1898 ;	quantum/action_util.c:463: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      008127 0F               [12] 1899 	inc	r7
      008128 80 D1            [24] 1900 	sjmp	00111$
      00812A                       1901 00107$:
                                   1902 ;	quantum/action_util.c:469: if (changed) host_keyboard_send(keyboard_report);
      00812A 90 0A C2         [24] 1903 	mov	dptr,#_send_keyboard_report_changed_10001_401
      00812D E0               [24] 1904 	movx	a,@dptr
      00812E 60 09            [24] 1905 	jz	00113$
      008130 90 0D CC         [24] 1906 	mov	dptr,#_actual_keyboard_report
      008133 75 F0 00         [24] 1907 	mov	b, #0x00
                                   1908 ;	quantum/action_util.c:477: }
      008136 02 6C 8D         [24] 1909 	ljmp	_host_keyboard_send
      008139                       1910 00113$:
      008139 22               [24] 1911 	ret
                                   1912 ;------------------------------------------------------------
                                   1913 ;Allocation info for local variables in function 'get_mods'
                                   1914 ;------------------------------------------------------------
                                   1915 ;	quantum/action_util.c:483: uint8_t get_mods(void) {
                                   1916 ;	-----------------------------------------
                                   1917 ;	 function get_mods
                                   1918 ;	-----------------------------------------
      00813A                       1919 _get_mods:
      00813A C0 07            [24] 1920 	push	ar7
                                   1921 ;	quantum/action_util.c:488: ;
      00813C 90 09 89         [24] 1922 	mov	dptr,#_owned_mods
      00813F E0               [24] 1923 	movx	a,@dptr
      008140 FF               [12] 1924 	mov	r7,a
      008141 90 0D CA         [24] 1925 	mov	dptr,#_real_mods
      008144 12 7B 71         [24] 1926 	lcall	_ak820_outline_0143
                                   1927 ;	quantum/action_util.c:489: }
      008147 D0 07            [24] 1928 	pop	ar7
      008149 22               [24] 1929 	ret
                                   1930 ;------------------------------------------------------------
                                   1931 ;Allocation info for local variables in function 'add_mods'
                                   1932 ;------------------------------------------------------------
                                   1933 ;mods          Allocated with name '_add_mods_mods_10000_409'
                                   1934 ;------------------------------------------------------------
                                   1935 ;	quantum/action_util.c:494: void add_mods(uint8_t mods) {
                                   1936 ;	-----------------------------------------
                                   1937 ;	 function clear_mods
                                   1938 ;	-----------------------------------------
      00814A                       1939 _clear_mods:
                                   1940 ;	quantum/action_util.c:516: real_mods = 0;
      00814A 90 0D CA         [24] 1941 	mov	dptr,#_real_mods
      00814D E4               [12] 1942 	clr	a
      00814E F0               [24] 1943 	movx	@dptr,a
                                   1944 ;	quantum/action_util.c:517: }
      00814F 22               [24] 1945 	ret
                                   1946 ;------------------------------------------------------------
                                   1947 ;Allocation info for local variables in function 'get_weak_mods'
                                   1948 ;------------------------------------------------------------
                                   1949 ;	quantum/action_util.c:523: uint8_t get_weak_mods(void) {
                                   1950 ;	-----------------------------------------
                                   1951 ;	 function get_weak_mods
                                   1952 ;	-----------------------------------------
      008150                       1953 _get_weak_mods:
      008150 C0 07            [24] 1954 	push	ar7
                                   1955 ;	quantum/action_util.c:528: ;
      008152 90 09 8A         [24] 1956 	mov	dptr,#_owned_weak_mods
      008155 E0               [24] 1957 	movx	a,@dptr
      008156 FF               [12] 1958 	mov	r7,a
      008157 90 0D CB         [24] 1959 	mov	dptr,#_weak_mods
      00815A 12 7B 71         [24] 1960 	lcall	_ak820_outline_0143
                                   1961 ;	quantum/action_util.c:529: }
      00815D D0 07            [24] 1962 	pop	ar7
      00815F 22               [24] 1963 	ret
                                   1964 ;------------------------------------------------------------
                                   1965 ;Allocation info for local variables in function 'add_weak_mods'
                                   1966 ;------------------------------------------------------------
                                   1967 ;mods          Allocated with name '_add_weak_mods_mods_10000_419'
                                   1968 ;------------------------------------------------------------
                                   1969 ;	quantum/action_util.c:534: void add_weak_mods(uint8_t mods) {
                                   1970 ;	-----------------------------------------
                                   1971 ;	 function add_weak_mods
                                   1972 ;	-----------------------------------------
      008160                       1973 _add_weak_mods:
      008160 E5 82            [12] 1974 	mov	a,dpl
      008162 90 0A C3         [24] 1975 	mov	dptr,#_add_weak_mods_mods_10000_419
      008165 F0               [24] 1976 	movx	@dptr,a
                                   1977 ;	quantum/action_util.c:535: weak_mods |= mods;
      008166 E0               [24] 1978 	movx	a,@dptr
      008167 FF               [12] 1979 	mov	r7,a
      008168 90 0D CB         [24] 1980 	mov	dptr,#_weak_mods
      00816B E0               [24] 1981 	movx	a,@dptr
      00816C 4F               [12] 1982 	orl	a,r7
      00816D F0               [24] 1983 	movx	@dptr,a
                                   1984 ;	quantum/action_util.c:536: }
      00816E 22               [24] 1985 	ret
                                   1986 ;------------------------------------------------------------
                                   1987 ;Allocation info for local variables in function 'del_weak_mods'
                                   1988 ;------------------------------------------------------------
                                   1989 ;mods          Allocated with name '_del_weak_mods_mods_10000_421'
                                   1990 ;------------------------------------------------------------
                                   1991 ;	quantum/action_util.c:541: void del_weak_mods(uint8_t mods) {
                                   1992 ;	-----------------------------------------
                                   1993 ;	 function del_weak_mods
                                   1994 ;	-----------------------------------------
      00816F                       1995 _del_weak_mods:
      00816F E5 82            [12] 1996 	mov	a,dpl
      008171 90 0A C4         [24] 1997 	mov	dptr,#_del_weak_mods_mods_10000_421
      008174 F0               [24] 1998 	movx	@dptr,a
                                   1999 ;	quantum/action_util.c:542: weak_mods &= ~mods;
      008175 E0               [24] 2000 	movx	a,@dptr
      008176 F4               [12] 2001 	cpl	a
      008177 FF               [12] 2002 	mov	r7,a
      008178 90 0D CB         [24] 2003 	mov	dptr,#_weak_mods
      00817B E0               [24] 2004 	movx	a,@dptr
      00817C 5F               [12] 2005 	anl	a,r7
      00817D F0               [24] 2006 	movx	@dptr,a
                                   2007 ;	quantum/action_util.c:543: }
      00817E 22               [24] 2008 	ret
                                   2009 ;------------------------------------------------------------
                                   2010 ;Allocation info for local variables in function 'set_weak_mods'
                                   2011 ;------------------------------------------------------------
                                   2012 ;mods          Allocated with name '_set_weak_mods_mods_10000_423'
                                   2013 ;------------------------------------------------------------
                                   2014 ;	quantum/action_util.c:548: void set_weak_mods(uint8_t mods) {
                                   2015 ;	-----------------------------------------
                                   2016 ;	 function clear_weak_mods
                                   2017 ;	-----------------------------------------
      00817F                       2018 _clear_weak_mods:
                                   2019 ;	quantum/action_util.c:556: weak_mods = 0;
      00817F 90 0D CB         [24] 2020 	mov	dptr,#_weak_mods
      008182 E4               [12] 2021 	clr	a
      008183 F0               [24] 2022 	movx	@dptr,a
                                   2023 ;	quantum/action_util.c:557: }
      008184 22               [24] 2024 	ret
                                   2025 ;------------------------------------------------------------
                                   2026 ;Allocation info for local variables in function 'oneshot_locked_mods_changed_user'
                                   2027 ;------------------------------------------------------------
                                   2028 ;mods          Allocated with name '_oneshot_locked_mods_changed_user_mods_10000_427'
                                   2029 ;------------------------------------------------------------
                                   2030 ;	quantum/action_util.c:639: __attribute__((weak)) void oneshot_locked_mods_changed_user(uint8_t mods) {}
                                   2031 ;	-----------------------------------------
                                   2032 	.area CSEG    (CODE)
                                   2033 	.area CONST   (CODE)
                                   2034 	.area XINIT   (CODE)
      00C1FA                       2035 __xinit__real_mods:
      00C1FA 00                    2036 	.db #0x00	; 0
      00C1FB                       2037 __xinit__weak_mods:
      00C1FB 00                    2038 	.db #0x00	; 0
      00C1FC                       2039 __xinit__actual_keyboard_report:
      00C1FC 00                    2040 	.db #0x00	; 0
      00C1FD 00                    2041 	.db #0x00	; 0
      00C1FE 00                    2042 	.db #0x00	; 0
      00C1FF 00                    2043 	.db #0x00	; 0
      00C200 00                    2044 	.db #0x00	; 0
      00C201 00                    2045 	.db #0x00	; 0
      00C202 00                    2046 	.db #0x00	; 0
      00C203 00                    2047 	.db #0x00	; 0
      00C204 00                    2048 	.db 0x00
      00C205 00                    2049 	.db 0x00
      00C206 00                    2050 	.db 0x00
      00C207 00                    2051 	.db 0x00
      00C208 00                    2052 	.db 0x00
      00C209 00                    2053 	.db 0x00
      00C20A 00                    2054 	.db 0x00
      00C20B 00                    2055 	.db 0x00
      00C20C 00                    2056 	.db 0x00
      00C20D 00                    2057 	.db 0x00
      00C20E 00                    2058 	.db 0x00
      00C20F 00                    2059 	.db 0x00
      00C210 00                    2060 	.db 0x00
      00C211 00                    2061 	.db 0x00
      00C212 00                    2062 	.db 0x00
      00C213 00                    2063 	.db 0x00
      00C214 00                    2064 	.db 0x00
      00C215 00                    2065 	.db 0x00
      00C216 00                    2066 	.db 0x00
      00C217 00                    2067 	.db 0x00
      00C218 00                    2068 	.db 0x00
      00C219 00                    2069 	.db 0x00
      00C21A 00                    2070 	.db 0x00
      00C21B 00                    2071 	.db 0x00
                                   2072 	.area CABS    (ABS,CODE)
                                   2073 
                                   2074 ; Experimental exact instruction outlining.
                                   2075 	.globl _ak820_outline_0017
                                   2076 	.globl _ak820_outline_0030
                                   2077 	.globl _ak820_outline_0052
                                   2078 	.globl _ak820_outline_0057
                                   2079 	.globl _ak820_outline_0058
                                   2080 	.globl _ak820_outline_0061
                                   2081 	.globl _ak820_outline_0063
                                   2082 	.globl _ak820_outline_0064
                                   2083 	.globl _ak820_outline_0065
                                   2084 	.globl _ak820_outline_0068
                                   2085 	.globl _ak820_outline_0075
                                   2086 	.globl _ak820_outline_0110
                                   2087 	.globl _ak820_outline_0111
                                   2088 	.globl _ak820_outline_0120
                                   2089 	.globl _ak820_outline_0124
                                   2090 	.globl _ak820_outline_0125
                                   2091 	.globl _ak820_outline_0127
                                   2092 	.globl _ak820_outline_0134
                                   2093 	.globl _ak820_outline_0135
                                   2094 	.globl _ak820_outline_0137
                                   2095 	.globl _ak820_outline_0141
                                   2096 	.globl _ak820_outline_0143
                                   2097 	.globl _ak820_outline_0160
                                   2098 	.globl _ak820_outline_0161
                                   2099 	.globl _ak820_outline_0166
                                   2100 	.globl _ak820_outline_0174
                                   2101 	.globl _ak820_outline_0185
                                   2102 	.globl _ak820_outline_0191
                                   2103 	.globl _ak820_outline_0192
                                   2104 
                                   2105 	.area CSEG (CODE)
                                   2106 ; function ak820_outline_0030
      008185                       2107 _ak820_outline_0030:
      008185 EF               [12] 2108 	mov	a,r7
      008186 24 9B            [12] 2109 	add	a,#_key_refs
      008188 FD               [12] 2110 	mov	r5,a
      008189 E4               [12] 2111 	clr	a
      00818A 34 09            [12] 2112 	addc	a,#(_key_refs>>8)
      00818C FE               [12] 2113 	mov	r6,a
      00818D 8D 82            [24] 2114 	mov	dpl,r5
      00818F 8E 83            [24] 2115 	mov	dph,r6
      008191 E0               [24] 2116 	movx	a,@dptr
      008192 22               [24] 2117 	ret
                                   2118 
                                   2119 	.area CSEG (CODE)
                                   2120 ; function ak820_outline_0058
      008193                       2121 _ak820_outline_0058:
      008193 F0               [24] 2122 	movx	@dptr,a
      008194 90 0D CC         [24] 2123 	mov	dptr,#_actual_keyboard_report
      008197 75 F0 00         [24] 2124 	mov	b,#0x00
      00819A 22               [24] 2125 	ret
                                   2126 
                                   2127 	.area CSEG (CODE)
                                   2128 ; function ak820_outline_0064
      00819B                       2129 _ak820_outline_0064:
      00819B 89 82            [24] 2130 	mov	dpl,r1
      00819D 8A 83            [24] 2131 	mov	dph,r2
      00819F E8               [12] 2132 	mov	a,r0
      0081A0 F0               [24] 2133 	movx	@dptr,a
      0081A1 22               [24] 2134 	ret
                                   2135 
                                   2136 	.area CSEG (CODE)
                                   2137 ; function ak820_outline_0068
      0081A2                       2138 _ak820_outline_0068:
      0081A2 24 76            [12] 2139 	add	a,#_usage_order
      0081A4 F5 82            [12] 2140 	mov	dpl,a
      0081A6 E4               [12] 2141 	clr	a
      0081A7 34 0A            [12] 2142 	addc	a,#(_usage_order>>8)
      0081A9 F5 83            [12] 2143 	mov	dph,a
      0081AB 22               [24] 2144 	ret
                                   2145 
                                   2146 	.area CSEG (CODE)
                                   2147 ; function ak820_outline_0075
      0081AC                       2148 _ak820_outline_0075:
      0081AC EB               [12] 2149 	mov	a,r3
      0081AD 24 58            [12] 2150 	add	a,#_usage_refs
      0081AF F9               [12] 2151 	mov	r1,a
      0081B0 E4               [12] 2152 	clr	a
      0081B1 34 0A            [12] 2153 	addc	a,#(_usage_refs>>8)
      0081B3 FA               [12] 2154 	mov	r2,a
      0081B4 89 82            [24] 2155 	mov	dpl,r1
      0081B6 8A 83            [24] 2156 	mov	dph,r2
      0081B8 E0               [24] 2157 	movx	a,@dptr
      0081B9 F8               [12] 2158 	mov	r0,a
      0081BA 22               [24] 2159 	ret
                                   2160 
                                   2161 	.area CSEG (CODE)
                                   2162 ; function ak820_outline_0120
      0081BB                       2163 _ak820_outline_0120:
      0081BB F0               [24] 2164 	movx	@dptr,a
      0081BC E0               [24] 2165 	movx	a,@dptr
      0081BD FF               [12] 2166 	mov	r7,a
      0081BE 90 09 93         [24] 2167 	mov	dptr,#_change_owned_PARM_2
      0081C1 22               [24] 2168 	ret
                                   2169 
                                   2170 	.area CSEG (CODE)
                                   2171 ; function ak820_outline_0124
      0081C2                       2172 _ak820_outline_0124:
      0081C2 8D 82            [24] 2173 	mov	dpl,r5
      0081C4 8E 83            [24] 2174 	mov	dph,r6
      0081C6 F0               [24] 2175 	movx	@dptr,a
      0081C7 22               [24] 2176 	ret
                                   2177 
                                   2178 	.area CSEG (CODE)
                                   2179 ; function ak820_outline_0127
      0081C8                       2180 _ak820_outline_0127:
      0081C8 24 76            [12] 2181 	add	a,#_usage_order
      0081CA F5 82            [12] 2182 	mov	dpl,a
      0081CC EF               [12] 2183 	mov	a,r7
      0081CD 34 0A            [12] 2184 	addc	a,#(_usage_order>>8)
      0081CF F5 83            [12] 2185 	mov	dph,a
      0081D1 E0               [24] 2186 	movx	a,@dptr
      0081D2 22               [24] 2187 	ret
                                   2188 
                                   2189 	.area CSEG (CODE)
                                   2190 ; function ak820_outline_0134
      0081D3                       2191 _ak820_outline_0134:
      0081D3 F0               [24] 2192 	movx	@dptr,a
      0081D4 E0               [24] 2193 	movx	a,@dptr
      0081D5 FF               [12] 2194 	mov	r7,a
      0081D6 90 09 8F         [24] 2195 	mov	dptr,#_ak820_macro_change_PARM_2
      0081D9 F0               [24] 2196 	movx	@dptr,a
      0081DA 90 09 90         [24] 2197 	mov	dptr,#_ak820_macro_change_PARM_3
      0081DD 22               [24] 2198 	ret
                                   2199 
                                   2200 	.area CSEG (CODE)
                                   2201 ; function ak820_outline_0192
      0081DE                       2202 _ak820_outline_0192:
      0081DE 8D 82            [24] 2203 	mov	dpl,r5
      0081E0 8F 83            [24] 2204 	mov	dph,r7
      0081E2 22               [24] 2205 	ret
