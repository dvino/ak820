;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (Linux)
;--------------------------------------------------------
	.module gpio
	
	.optsdcc -mmcs51 --model-large
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _pin_to_pinmask
	.globl _ADC_START
	.globl _S0_R_FIFO
	.globl _S0_T_FIFO
	.globl _S0_FREE
	.globl _S0_IF_BYTE
	.globl _S0_IF_FIRST
	.globl _S0_IF_OV
	.globl _S0_FST_ACT
	.globl _CP_RL2
	.globl _C_T2
	.globl _TR2
	.globl _EXEN2
	.globl _TCLK
	.globl _RCLK
	.globl _EXF2
	.globl _CAP1F
	.globl _TF2
	.globl _RI
	.globl _TI
	.globl _RB8
	.globl _TB8
	.globl _REN
	.globl _SM2
	.globl _SM1
	.globl _SM0
	.globl _IT0
	.globl _IE0
	.globl _IT1
	.globl _IE1
	.globl _TR0
	.globl _TF0
	.globl _TR1
	.globl _TF1
	.globl _P4_0
	.globl _P4_1
	.globl _P4_2
	.globl _P4_3
	.globl _P4_4
	.globl _P4_5
	.globl _P4_6
	.globl _RXD
	.globl _TXD
	.globl _INT0
	.globl _INT1
	.globl _T0
	.globl _T1
	.globl _MOSI1
	.globl _MISO1
	.globl _SCK1
	.globl _P3_0
	.globl _P3_1
	.globl _P3_2
	.globl _P3_3
	.globl _P3_4
	.globl _P3_5
	.globl _P3_6
	.globl _P3_7
	.globl _CAP1_
	.globl _T2_
	.globl _CAP2_
	.globl _T2EX_
	.globl _RXD1
	.globl _TXD1
	.globl _P2_0
	.globl _P2_1
	.globl _P2_2
	.globl _P2_3
	.globl _P2_4
	.globl _P2_5
	.globl _P2_6
	.globl _P2_7
	.globl _AIN0
	.globl _AIN1
	.globl _AIN2
	.globl _AIN3
	.globl _AIN4
	.globl _AIN5
	.globl _AIN6
	.globl _AIN7
	.globl _CAP1
	.globl _T2
	.globl _CAP2
	.globl _T2EX
	.globl _INT0_
	.globl _SCS
	.globl _MOSI
	.globl _MISO
	.globl _SCK
	.globl _RXD1_
	.globl _TXD1_
	.globl _P1_0
	.globl _P1_1
	.globl _P1_2
	.globl _P1_3
	.globl _P1_4
	.globl _P1_5
	.globl _P1_6
	.globl _P1_7
	.globl _AIN8
	.globl _AIN9
	.globl _AIN10
	.globl _AIN11
	.globl _AIN12
	.globl _AIN13
	.globl _RXD_
	.globl _TXD_
	.globl _SCL0
	.globl _SDA0
	.globl _P0_0
	.globl _P0_1
	.globl _P0_2
	.globl _P0_3
	.globl _P0_4
	.globl _P0_5
	.globl _P0_6
	.globl _P0_7
	.globl _IE_SPI0
	.globl _IE_USB
	.globl _IE_ADC
	.globl _IE_UART1
	.globl _IE_PWM_I2C
	.globl _IE_GPIO
	.globl _IE_WDOG
	.globl _PX0
	.globl _PT0
	.globl _PX1
	.globl _PT1
	.globl _PS
	.globl _PT2
	.globl _PL_FLAG
	.globl _PH_FLAG
	.globl _EX0
	.globl _ET0
	.globl _EX1
	.globl _ET1
	.globl _ES
	.globl _ET2
	.globl _E_DIS
	.globl _EA
	.globl _P
	.globl _F1
	.globl _OV
	.globl _RS0
	.globl _RS1
	.globl _F0
	.globl _AC
	.globl _CY
	.globl _I2CS_INT_ST
	.globl _I2CX_INT
	.globl _LED_STATUS
	.globl _LED_DMA_H
	.globl _LED_DMA_L
	.globl _LED_DMA
	.globl _LED_PWM_OE
	.globl _LED_COMMON
	.globl _ADC_CHAN
	.globl _ADC_DAT_H
	.globl _ADC_DAT_L
	.globl _ADC_DAT
	.globl _ADC_CTRL
	.globl _SPI1_CK_SE
	.globl _SPI1_CTRL
	.globl _SPI1_DATA
	.globl _SPI1_STAT
	.globl _SIF1
	.globl _SBAUD1
	.globl _SBUF1
	.globl _SCON1
	.globl _SPI0_SETUP
	.globl _SPI0_CK_SE
	.globl _SPI0_CTRL
	.globl _SPI0_DATA
	.globl _SPI0_STAT
	.globl _T2CAP1H
	.globl _T2CAP1L
	.globl _T2CAP1
	.globl _TH2
	.globl _TL2
	.globl _T2COUNT
	.globl _RCAP2H
	.globl _RCAP2L
	.globl _RCAP2
	.globl _T2MOD
	.globl _T2CON
	.globl _SBUF
	.globl _SCON
	.globl _TH1
	.globl _TH0
	.globl _TL1
	.globl _TL0
	.globl _TMOD
	.globl _TCON
	.globl _XBUS_AUX
	.globl _P7
	.globl _P6_DIR
	.globl _P6_OUT_PU
	.globl _P6_IN
	.globl _P5_DIR
	.globl _P5_OUT_PU
	.globl _P5_IN
	.globl _P4_LED_KEY
	.globl _P4_DIR_PU
	.globl _P4_MOD_OC
	.globl _P4
	.globl _P3_DIR_PU
	.globl _P3_MOD_OC
	.globl _P3
	.globl _P2_DIR_PU
	.globl _P2_MOD_OC
	.globl _P2
	.globl _P1_DIR_PU
	.globl _P1_MOD_OC
	.globl _P1
	.globl _P0_DIR_PU
	.globl _P0_MOD_OC
	.globl _P0
	.globl _ROM_CTRL
	.globl _ROM_DATA_HH
	.globl _ROM_DATA_HL
	.globl _ROM_DATA_HI
	.globl _ROM_ADDR_H
	.globl _ROM_ADDR_L
	.globl _ROM_ADDR
	.globl _GPIO_IE
	.globl _IP_EX
	.globl _IE_EX
	.globl _IP
	.globl _IE
	.globl _WDOG_COUNT
	.globl _RESET_KEEP
	.globl _WAKE_CTRL
	.globl _CLOCK_CFG
	.globl _POWER_CFG
	.globl _PCON
	.globl _GLOBAL_CFG
	.globl _SAFE_MOD
	.globl _DPH
	.globl _DPL
	.globl _SP
	.globl _A_INV
	.globl _B
	.globl _ACC
	.globl _PSW
	.globl _pinModeInputHighQMK
	.globl _pinModeOutputQMK
	.globl _pinModeInputZ
	.globl _pinModeOutputPushPull
	.globl _pinModeOutputOpen
	.globl _pinModeBiDi
	.globl _readPin
	.globl _writePinHigh
	.globl _writePinLow
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
_PSW	=	0x00d0
_ACC	=	0x00e0
_B	=	0x00f0
_A_INV	=	0x00fd
_SP	=	0x0081
_DPL	=	0x0082
_DPH	=	0x0083
_SAFE_MOD	=	0x00a1
_GLOBAL_CFG	=	0x00b1
_PCON	=	0x0087
_POWER_CFG	=	0x00ba
_CLOCK_CFG	=	0x00b9
_WAKE_CTRL	=	0x00a9
_RESET_KEEP	=	0x00fe
_WDOG_COUNT	=	0x00ff
_IE	=	0x00a8
_IP	=	0x00b8
_IE_EX	=	0x00e8
_IP_EX	=	0x00e9
_GPIO_IE	=	0x00b2
_ROM_ADDR	=	0x8584
_ROM_ADDR_L	=	0x0084
_ROM_ADDR_H	=	0x0085
_ROM_DATA_HI	=	0x8f8e
_ROM_DATA_HL	=	0x008e
_ROM_DATA_HH	=	0x008f
_ROM_CTRL	=	0x0086
_P0	=	0x0080
_P0_MOD_OC	=	0x00c4
_P0_DIR_PU	=	0x00c5
_P1	=	0x0090
_P1_MOD_OC	=	0x0092
_P1_DIR_PU	=	0x0093
_P2	=	0x00a0
_P2_MOD_OC	=	0x0094
_P2_DIR_PU	=	0x0095
_P3	=	0x00b0
_P3_MOD_OC	=	0x0096
_P3_DIR_PU	=	0x0097
_P4	=	0x00c0
_P4_MOD_OC	=	0x00c2
_P4_DIR_PU	=	0x00c3
_P4_LED_KEY	=	0x00c1
_P5_IN	=	0x00aa
_P5_OUT_PU	=	0x00ab
_P5_DIR	=	0x00ac
_P6_IN	=	0x00ad
_P6_OUT_PU	=	0x00ae
_P6_DIR	=	0x00af
_P7	=	0x00f1
_XBUS_AUX	=	0x00a2
_TCON	=	0x0088
_TMOD	=	0x0089
_TL0	=	0x008a
_TL1	=	0x008b
_TH0	=	0x008c
_TH1	=	0x008d
_SCON	=	0x0098
_SBUF	=	0x0099
_T2CON	=	0x00c8
_T2MOD	=	0x00c9
_RCAP2	=	0xcbca
_RCAP2L	=	0x00ca
_RCAP2H	=	0x00cb
_T2COUNT	=	0xcdcc
_TL2	=	0x00cc
_TH2	=	0x00cd
_T2CAP1	=	0xcfce
_T2CAP1L	=	0x00ce
_T2CAP1H	=	0x00cf
_SPI0_STAT	=	0x00f8
_SPI0_DATA	=	0x00f9
_SPI0_CTRL	=	0x00fa
_SPI0_CK_SE	=	0x00fb
_SPI0_SETUP	=	0x00fc
_SCON1	=	0x00bc
_SBUF1	=	0x00bd
_SBAUD1	=	0x00be
_SIF1	=	0x00bf
_SPI1_STAT	=	0x00b4
_SPI1_DATA	=	0x00b5
_SPI1_CTRL	=	0x00b6
_SPI1_CK_SE	=	0x00b7
_ADC_CTRL	=	0x00f3
_ADC_DAT	=	0xf5f4
_ADC_DAT_L	=	0x00f4
_ADC_DAT_H	=	0x00f5
_ADC_CHAN	=	0x00f6
_LED_COMMON	=	0x00a6
_LED_PWM_OE	=	0x00a7
_LED_DMA	=	0xc7c6
_LED_DMA_L	=	0x00c6
_LED_DMA_H	=	0x00c7
_LED_STATUS	=	0x00f7
_I2CX_INT	=	0x00b3
_I2CS_INT_ST	=	0x00bb
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
_CY	=	0x00d7
_AC	=	0x00d6
_F0	=	0x00d5
_RS1	=	0x00d4
_RS0	=	0x00d3
_OV	=	0x00d2
_F1	=	0x00d1
_P	=	0x00d0
_EA	=	0x00af
_E_DIS	=	0x00ae
_ET2	=	0x00ad
_ES	=	0x00ac
_ET1	=	0x00ab
_EX1	=	0x00aa
_ET0	=	0x00a9
_EX0	=	0x00a8
_PH_FLAG	=	0x00bf
_PL_FLAG	=	0x00be
_PT2	=	0x00bd
_PS	=	0x00bc
_PT1	=	0x00bb
_PX1	=	0x00ba
_PT0	=	0x00b9
_PX0	=	0x00b8
_IE_WDOG	=	0x00ef
_IE_GPIO	=	0x00ee
_IE_PWM_I2C	=	0x00ed
_IE_UART1	=	0x00ec
_IE_ADC	=	0x00eb
_IE_USB	=	0x00e9
_IE_SPI0	=	0x00e8
_P0_7	=	0x0087
_P0_6	=	0x0086
_P0_5	=	0x0085
_P0_4	=	0x0084
_P0_3	=	0x0083
_P0_2	=	0x0082
_P0_1	=	0x0081
_P0_0	=	0x0080
_SDA0	=	0x0081
_SCL0	=	0x0080
_TXD_	=	0x0083
_RXD_	=	0x0082
_AIN13	=	0x0085
_AIN12	=	0x0084
_AIN11	=	0x0083
_AIN10	=	0x0082
_AIN9	=	0x0081
_AIN8	=	0x0080
_P1_7	=	0x0097
_P1_6	=	0x0096
_P1_5	=	0x0095
_P1_4	=	0x0094
_P1_3	=	0x0093
_P1_2	=	0x0092
_P1_1	=	0x0091
_P1_0	=	0x0090
_TXD1_	=	0x0097
_RXD1_	=	0x0096
_SCK	=	0x0097
_MISO	=	0x0096
_MOSI	=	0x0095
_SCS	=	0x0094
_INT0_	=	0x0092
_T2EX	=	0x0091
_CAP2	=	0x0091
_T2	=	0x0090
_CAP1	=	0x0090
_AIN7	=	0x0097
_AIN6	=	0x0096
_AIN5	=	0x0095
_AIN4	=	0x0094
_AIN3	=	0x0093
_AIN2	=	0x0092
_AIN1	=	0x0091
_AIN0	=	0x0090
_P2_7	=	0x00a7
_P2_6	=	0x00a6
_P2_5	=	0x00a5
_P2_4	=	0x00a4
_P2_3	=	0x00a3
_P2_2	=	0x00a2
_P2_1	=	0x00a1
_P2_0	=	0x00a0
_TXD1	=	0x00a7
_RXD1	=	0x00a6
_T2EX_	=	0x00a5
_CAP2_	=	0x00a5
_T2_	=	0x00a4
_CAP1_	=	0x00a4
_P3_7	=	0x00b7
_P3_6	=	0x00b6
_P3_5	=	0x00b5
_P3_4	=	0x00b4
_P3_3	=	0x00b3
_P3_2	=	0x00b2
_P3_1	=	0x00b1
_P3_0	=	0x00b0
_SCK1	=	0x00b7
_MISO1	=	0x00b6
_MOSI1	=	0x00b5
_T1	=	0x00b5
_T0	=	0x00b4
_INT1	=	0x00b3
_INT0	=	0x00b2
_TXD	=	0x00b1
_RXD	=	0x00b0
_P4_6	=	0x00c6
_P4_5	=	0x00c5
_P4_4	=	0x00c4
_P4_3	=	0x00c3
_P4_2	=	0x00c2
_P4_1	=	0x00c1
_P4_0	=	0x00c0
_TF1	=	0x008f
_TR1	=	0x008e
_TF0	=	0x008d
_TR0	=	0x008c
_IE1	=	0x008b
_IT1	=	0x008a
_IE0	=	0x0089
_IT0	=	0x0088
_SM0	=	0x009f
_SM1	=	0x009e
_SM2	=	0x009d
_REN	=	0x009c
_TB8	=	0x009b
_RB8	=	0x009a
_TI	=	0x0099
_RI	=	0x0098
_TF2	=	0x00cf
_CAP1F	=	0x00cf
_EXF2	=	0x00ce
_RCLK	=	0x00cd
_TCLK	=	0x00cc
_EXEN2	=	0x00cb
_TR2	=	0x00ca
_C_T2	=	0x00c9
_CP_RL2	=	0x00c8
_S0_FST_ACT	=	0x00ff
_S0_IF_OV	=	0x00fe
_S0_IF_FIRST	=	0x00fd
_S0_IF_BYTE	=	0x00fc
_S0_FREE	=	0x00fb
_S0_T_FIFO	=	0x00fa
_S0_R_FIFO	=	0x00f8
_ADC_START	=	0x00f7
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram
;--------------------------------------------------------
	.area	OSEG    (OVR,DATA)
	.area	OSEG    (OVR,DATA)
	.area	OSEG    (OVR,DATA)
	.area	OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; absolute internal ram data
;--------------------------------------------------------
	.area IABS    (ABS,DATA)
	.area IABS    (ABS,DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; uninitialized external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
_pinModeInputHighQMK_pin_10000_10:
	.ds 1
_pinModeOutputQMK_pin_10000_14:
	.ds 1
_pinModeInputZ_pin_10000_18:
	.ds 1
_pinModeOutputPushPull_pin_10000_22:
	.ds 1
_pinModeOutputOpen_pin_10000_26:
	.ds 1
_pinModeBiDi_pin_10000_30:
	.ds 1
_readPin_pin_10000_34:
	.ds 1
_writePinHigh_pin_10000_38:
	.ds 1
_writePinLow_pin_10000_42:
	.ds 1
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area XABS    (ABS,XDATA)
;--------------------------------------------------------
; initialized external ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area HOME    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'pinModeInputHighQMK'
;------------------------------------------------------------
;port          Allocated to registers r6 
;pinmask       Allocated to registers r5 
;pin           Allocated with name '_pinModeInputHighQMK_pin_10000_10'
;------------------------------------------------------------
;	lib/ch555/gpio.c:10: void pinModeInputHighQMK(uint8_t pin) {
;	-----------------------------------------
;	 function pinModeInputHighQMK
;	-----------------------------------------
_pinModeInputHighQMK:
	ar7 = 0x07
	ar6 = 0x06
	ar5 = 0x05
	ar4 = 0x04
	ar3 = 0x03
	ar2 = 0x02
	ar1 = 0x01
	ar0 = 0x00
	mov	a,dpl
	mov	dptr,#_pinModeInputHighQMK_pin_10000_10
	movx	@dptr,a
;	lib/ch555/gpio.c:11: __data uint8_t port = PORTx(pin);
	movx	a,@dptr
	mov	r7,a
	swap	a
	rl	a
	anl	a,#0x1f
	mov	r6,a
;	lib/ch555/gpio.c:12: __data uint8_t pinmask  = PIN_MASK(pin);
	mov	a,#0x07
	anl	a,r7
	mov	dptr,#_pin_to_pinmask
	movc	a,@a+dptr
	mov	r5,a
;	lib/ch555/gpio.c:15: switch (port) {
	mov	a,r6
	add	a,#0xff - 0x07
	jc	00108$
;	free result
	mov	a,r6
	add	a,#(00118$-3-.)
	movc	a,@a+pc
	mov	dpl,a
	mov	a,r6
	add	a,#(00119$-3-.)
	movc	a,@a+pc
	mov	dph,a
	clr	a
	jmp	@a+dptr
00118$:
	.db	00106$
	.db	00106$
	.db	00106$
	.db	00106$
	.db	00106$
	.db	00108$
	.db	00108$
	.db	00101$
00119$:
	.db	00106$>>8
	.db	00106$>>8
	.db	00106$>>8
	.db	00106$>>8
	.db	00106$>>8
	.db	00108$>>8
	.db	00108$>>8
	.db	00101$>>8
;	lib/ch555/gpio.c:17: case PORT7:
00101$:
;	lib/ch555/gpio.c:18: P7 &= ~(pinmask<<2); // _DIR
	mov	a,r5
	add	a,r5
	add	a,acc
	mov	r6,a
	mov	a,#0xff
	xrl	a,r6
	anl	_P7,a
;	lib/ch555/gpio.c:19: P7 |=  pinmask; // _OUT_PU
	mov	a,r5
	orl	_P7,a
;	lib/ch555/gpio.c:20: break;
;	lib/ch555/gpio.c:37: case PORT4:
	ret
00106$:
;	lib/ch555/gpio.c:39: writePinHigh(pin);
	mov	dpl, r7
;	lib/ch555/gpio.c:42: }
;	lib/ch555/gpio.c:44: }
	ljmp	_writePinHigh
00108$:
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'pinModeOutputQMK'
;------------------------------------------------------------
;pin           Allocated with name '_pinModeOutputQMK_pin_10000_14'
;port          Allocated to registers r6 
;pinmask       Allocated to registers r7 
;------------------------------------------------------------
;	lib/ch555/gpio.c:45: void pinModeOutputQMK(uint8_t pin) {
;	-----------------------------------------
;	 function pinModeOutputQMK
;	-----------------------------------------
_pinModeOutputQMK:
	mov	a,dpl
	mov	dptr,#_pinModeOutputQMK_pin_10000_14
	movx	@dptr,a
;	lib/ch555/gpio.c:47: __data uint8_t port = PORTx(pin);
	movx	a,@dptr
	mov	r7,a
	swap	a
	rl	a
	anl	a,#0x1f
	mov	r6,a
;	lib/ch555/gpio.c:48: __data uint8_t pinmask  = PIN_MASK(pin);
	mov	a,#0x07
	anl	a,r7
	mov	dptr,#_pin_to_pinmask
	movc	a,@a+dptr
	mov	r7,a
;	lib/ch555/gpio.c:49: if (port == PORT7) {
	cjne	r6,#0x07,00103$
;	lib/ch555/gpio.c:50: P7 |=  (pinmask<<2); // _DIR
	mov	a,r7
	add	a,r7
	add	a,acc
	orl	_P7,a
00103$:
;	lib/ch555/gpio.c:54: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'pinModeInputZ'
;------------------------------------------------------------
;pin           Allocated with name '_pinModeInputZ_pin_10000_18'
;port          Allocated with name '_pinModeInputZ_port_10000_19'
;pinmask       Allocated with name '_pinModeInputZ_pinmask_10000_19'
;------------------------------------------------------------
;	lib/ch555/gpio.c:56: void pinModeInputZ(uint8_t pin) {
;	-----------------------------------------
;	 function pinModeInputZ
;	-----------------------------------------
_pinModeInputZ:
	mov	a,dpl
	mov	dptr,#_pinModeInputZ_pin_10000_18
	movx	@dptr,a
;	lib/ch555/gpio.c:57: uint8_t port = PORTx(pin);
	movx	a,@dptr
	mov	r7,a
	swap	a
	rl	a
	anl	a,#0x1f
	mov	r6,a
;	lib/ch555/gpio.c:58: uint8_t pinmask  = PIN_MASK(pin);
	mov	a,#0x07
	anl	a,r7
	mov	dptr,#_pin_to_pinmask
	movc	a,@a+dptr
	mov	r7,a
;	lib/ch555/gpio.c:59: switch (port) {
	mov	a,r6
	add	a,#0xff - 0x07
	jc	00108$
;	free result
	mov	a,r6
	add	a,#(00118$-3-.)
	movc	a,@a+pc
	mov	dpl,a
	mov	a,r6
	add	a,#(00119$-3-.)
	movc	a,@a+pc
	mov	dph,a
	clr	a
	jmp	@a+dptr
00118$:
	.db	00101$
	.db	00102$
	.db	00103$
	.db	00104$
	.db	00105$
	.db	00108$
	.db	00108$
	.db	00106$
00119$:
	.db	00101$>>8
	.db	00102$>>8
	.db	00103$>>8
	.db	00104$>>8
	.db	00105$>>8
	.db	00108$>>8
	.db	00108$>>8
	.db	00106$>>8
;	lib/ch555/gpio.c:61: case PORT0:
00101$:
;	lib/ch555/gpio.c:62: P0_MOD_OC &= ~pinmask;
	mov	a,#0xff
	xrl	a,r7
	mov	r6,a
	anl	_P0_MOD_OC,a
;	lib/ch555/gpio.c:63: P0_DIR_PU &= ~pinmask;
	mov	a,r6
	anl	_P0_DIR_PU,a
;	lib/ch555/gpio.c:64: break;
;	lib/ch555/gpio.c:67: case PORT1:
	ret
00102$:
;	lib/ch555/gpio.c:68: P1_MOD_OC &= ~pinmask;
	mov	a,#0xff
	xrl	a,r7
	mov	r6,a
	anl	_P1_MOD_OC,a
;	lib/ch555/gpio.c:69: P1_DIR_PU &= ~pinmask;
	mov	a,r6
	anl	_P1_DIR_PU,a
;	lib/ch555/gpio.c:70: break;
;	lib/ch555/gpio.c:73: case PORT2:
	ret
00103$:
;	lib/ch555/gpio.c:74: P2_MOD_OC &= ~pinmask;
	mov	a,#0xff
	xrl	a,r7
	mov	r6,a
	anl	_P2_MOD_OC,a
;	lib/ch555/gpio.c:75: P2_DIR_PU &= ~pinmask;
	mov	a,r6
	anl	_P2_DIR_PU,a
;	lib/ch555/gpio.c:76: break;
;	lib/ch555/gpio.c:79: case PORT3:
	ret
00104$:
;	lib/ch555/gpio.c:80: P3_MOD_OC &= ~pinmask;
	mov	a,#0xff
	xrl	a,r7
	mov	r6,a
	anl	_P3_MOD_OC,a
;	lib/ch555/gpio.c:81: P3_DIR_PU &= ~pinmask;
	mov	a,r6
	anl	_P3_DIR_PU,a
;	lib/ch555/gpio.c:82: break;
;	lib/ch555/gpio.c:85: case PORT4:
	ret
00105$:
;	lib/ch555/gpio.c:86: P4_MOD_OC &= ~pinmask;
	mov	a,#0xff
	xrl	a,r7
	mov	r6,a
	anl	_P4_MOD_OC,a
;	lib/ch555/gpio.c:87: P4_DIR_PU &= ~pinmask;
	mov	a,r6
	anl	_P4_DIR_PU,a
;	lib/ch555/gpio.c:88: break;
;	lib/ch555/gpio.c:91: case PORT7:
	ret
00106$:
;	lib/ch555/gpio.c:92: P7 &= ~(pinmask<<2); // _DIR
	mov	a,r7
	add	a,r7
	add	a,acc
	mov	r6,a
	mov	a,#0xff
	xrl	a,r6
	anl	_P7,a
;	lib/ch555/gpio.c:93: P7 &= ~pinmask; // _OUT_PU
	mov	a,#0xff
	xrl	a,r7
	anl	_P7,a
;	lib/ch555/gpio.c:96: }
00108$:
;	lib/ch555/gpio.c:97: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'pinModeOutputPushPull'
;------------------------------------------------------------
;pin           Allocated with name '_pinModeOutputPushPull_pin_10000_22'
;port          Allocated with name '_pinModeOutputPushPull_port_10000_23'
;pinmask       Allocated with name '_pinModeOutputPushPull_pinmask_10000_23'
;------------------------------------------------------------
;	lib/ch555/gpio.c:98: void pinModeOutputPushPull(uint8_t pin) {
;	-----------------------------------------
;	 function pinModeOutputPushPull
;	-----------------------------------------
_pinModeOutputPushPull:
	mov	a,dpl
	mov	dptr,#_pinModeOutputPushPull_pin_10000_22
	movx	@dptr,a
;	lib/ch555/gpio.c:99: uint8_t port = PORTx(pin);
	movx	a,@dptr
	mov	r7,a
	swap	a
	rl	a
	anl	a,#0x1f
	mov	r6,a
;	lib/ch555/gpio.c:100: uint8_t pinmask  = PIN_MASK(pin);
	mov	a,#0x07
	anl	a,r7
	mov	dptr,#_pin_to_pinmask
	movc	a,@a+dptr
	mov	r7,a
;	lib/ch555/gpio.c:101: switch (port) {
	mov	a,r6
	add	a,#0xff - 0x07
	jc	00108$
;	free result
	mov	a,r6
	add	a,#(00118$-3-.)
	movc	a,@a+pc
	mov	dpl,a
	mov	a,r6
	add	a,#(00119$-3-.)
	movc	a,@a+pc
	mov	dph,a
	clr	a
	jmp	@a+dptr
00118$:
	.db	00101$
	.db	00102$
	.db	00103$
	.db	00104$
	.db	00105$
	.db	00108$
	.db	00108$
	.db	00106$
00119$:
	.db	00101$>>8
	.db	00102$>>8
	.db	00103$>>8
	.db	00104$>>8
	.db	00105$>>8
	.db	00108$>>8
	.db	00108$>>8
	.db	00106$>>8
;	lib/ch555/gpio.c:103: case PORT0:
00101$:
;	lib/ch555/gpio.c:104: P0_MOD_OC &= ~pinmask;
	mov	a,#0xff
	xrl	a,r7
	anl	_P0_MOD_OC,a
;	lib/ch555/gpio.c:105: P0_DIR_PU |=  pinmask;
	mov	a,r7
	orl	_P0_DIR_PU,a
;	lib/ch555/gpio.c:106: break;
;	lib/ch555/gpio.c:109: case PORT1:
	ret
00102$:
;	lib/ch555/gpio.c:110: P1_MOD_OC &= ~pinmask;
	mov	a,#0xff
	xrl	a,r7
	anl	_P1_MOD_OC,a
;	lib/ch555/gpio.c:111: P1_DIR_PU |=  pinmask;
	mov	a,r7
	orl	_P1_DIR_PU,a
;	lib/ch555/gpio.c:112: break;
;	lib/ch555/gpio.c:115: case PORT2:
	ret
00103$:
;	lib/ch555/gpio.c:116: P2_MOD_OC &= ~pinmask;
	mov	a,#0xff
	xrl	a,r7
	anl	_P2_MOD_OC,a
;	lib/ch555/gpio.c:117: P2_DIR_PU |=  pinmask;
	mov	a,r7
	orl	_P2_DIR_PU,a
;	lib/ch555/gpio.c:118: break;
;	lib/ch555/gpio.c:121: case PORT3:
	ret
00104$:
;	lib/ch555/gpio.c:122: P3_MOD_OC &= ~pinmask;
	mov	a,#0xff
	xrl	a,r7
	anl	_P3_MOD_OC,a
;	lib/ch555/gpio.c:123: P3_DIR_PU |=  pinmask;
	mov	a,r7
	orl	_P3_DIR_PU,a
;	lib/ch555/gpio.c:124: break;
;	lib/ch555/gpio.c:127: case PORT4:
	ret
00105$:
;	lib/ch555/gpio.c:128: P4_MOD_OC &= ~pinmask;
	mov	a,#0xff
	xrl	a,r7
	anl	_P4_MOD_OC,a
;	lib/ch555/gpio.c:129: P4_DIR_PU |=  pinmask;
	mov	a,r7
	orl	_P4_DIR_PU,a
;	lib/ch555/gpio.c:130: break;
;	lib/ch555/gpio.c:133: case PORT7:
	ret
00106$:
;	lib/ch555/gpio.c:134: P7 |=  (pinmask<<2); // _DIR
	mov	a,r7
	add	a,r7
	add	a,acc
	orl	_P7,a
;	lib/ch555/gpio.c:137: }
00108$:
;	lib/ch555/gpio.c:138: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'pinModeOutputOpen'
;------------------------------------------------------------
;pin           Allocated with name '_pinModeOutputOpen_pin_10000_26'
;port          Allocated with name '_pinModeOutputOpen_port_10000_27'
;pinmask       Allocated with name '_pinModeOutputOpen_pinmask_10000_27'
;------------------------------------------------------------
;	lib/ch555/gpio.c:139: void pinModeOutputOpen(uint8_t pin) {
;	-----------------------------------------
;	 function pinModeOutputOpen
;	-----------------------------------------
_pinModeOutputOpen:
	mov	a,dpl
	mov	dptr,#_pinModeOutputOpen_pin_10000_26
	movx	@dptr,a
;	lib/ch555/gpio.c:140: uint8_t port = PORTx(pin);
	movx	a,@dptr
	mov	r7,a
	swap	a
	rl	a
	anl	a,#0x1f
	mov	r6,a
;	lib/ch555/gpio.c:141: uint8_t pinmask  = PIN_MASK(pin);
	mov	a,#0x07
	anl	a,r7
	mov	dptr,#_pin_to_pinmask
	movc	a,@a+dptr
	mov	r7,a
;	lib/ch555/gpio.c:142: switch (port) {
	mov	a,r6
	add	a,#0xff - 0x04
	jc	00107$
;	free result
	mov	a,r6
	add	a,r6
;	lib/ch555/gpio.c:144: case PORT0:
	mov	dptr,#00117$
	jmp	@a+dptr
00117$:
	sjmp	00101$
	sjmp	00102$
	sjmp	00103$
	sjmp	00104$
	sjmp	00105$
00101$:
;	lib/ch555/gpio.c:145: P0_MOD_OC |=  pinmask;
	mov	a,r7
	orl	_P0_MOD_OC,a
;	lib/ch555/gpio.c:146: P0_DIR_PU &= ~pinmask;
	mov	a,#0xff
	xrl	a,r7
	anl	_P0_DIR_PU,a
;	lib/ch555/gpio.c:147: break;
;	lib/ch555/gpio.c:150: case PORT1:
	ret
00102$:
;	lib/ch555/gpio.c:151: P1_MOD_OC |= ~pinmask;
	mov	a,#0xff
	xrl	a,r7
	mov	r6,a
	orl	_P1_MOD_OC,a
;	lib/ch555/gpio.c:152: P1_DIR_PU &= ~pinmask;
	mov	a,r6
	anl	_P1_DIR_PU,a
;	lib/ch555/gpio.c:153: break;
;	lib/ch555/gpio.c:156: case PORT2:
	ret
00103$:
;	lib/ch555/gpio.c:157: P2_MOD_OC |= ~pinmask;
	mov	a,#0xff
	xrl	a,r7
	mov	r6,a
	orl	_P2_MOD_OC,a
;	lib/ch555/gpio.c:158: P2_DIR_PU &= ~pinmask;
	mov	a,r6
	anl	_P2_DIR_PU,a
;	lib/ch555/gpio.c:159: break;
;	lib/ch555/gpio.c:162: case PORT3:
	ret
00104$:
;	lib/ch555/gpio.c:163: P3_MOD_OC |= ~pinmask;
	mov	a,#0xff
	xrl	a,r7
	mov	r6,a
	orl	_P3_MOD_OC,a
;	lib/ch555/gpio.c:164: P3_DIR_PU &= ~pinmask;
	mov	a,r6
	anl	_P3_DIR_PU,a
;	lib/ch555/gpio.c:165: break;
;	lib/ch555/gpio.c:168: case PORT4:
	ret
00105$:
;	lib/ch555/gpio.c:169: P4_MOD_OC |= ~pinmask;
	xrl	ar7,#0xff
	mov	a,r7
	orl	_P4_MOD_OC,a
;	lib/ch555/gpio.c:170: P4_DIR_PU &= ~pinmask;
	mov	a,r7
	anl	_P4_DIR_PU,a
;	lib/ch555/gpio.c:180: }
00107$:
;	lib/ch555/gpio.c:181: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'pinModeBiDi'
;------------------------------------------------------------
;pin           Allocated with name '_pinModeBiDi_pin_10000_30'
;port          Allocated with name '_pinModeBiDi_port_10000_31'
;pinmask       Allocated with name '_pinModeBiDi_pinmask_10000_31'
;------------------------------------------------------------
;	lib/ch555/gpio.c:182: void pinModeBiDi(uint8_t pin) {
;	-----------------------------------------
;	 function pinModeBiDi
;	-----------------------------------------
_pinModeBiDi:
	mov	a,dpl
	mov	dptr,#_pinModeBiDi_pin_10000_30
	movx	@dptr,a
;	lib/ch555/gpio.c:183: uint8_t port = PORTx(pin);
	movx	a,@dptr
	mov	r7,a
	swap	a
	rl	a
	anl	a,#0x1f
	mov	r6,a
;	lib/ch555/gpio.c:184: uint8_t pinmask  = PIN_MASK(pin);
	mov	a,#0x07
	anl	a,r7
	mov	dptr,#_pin_to_pinmask
	movc	a,@a+dptr
	mov	r7,a
;	lib/ch555/gpio.c:185: switch (port) {
	mov	a,r6
	add	a,#0xff - 0x04
	jc	00107$
;	free result
	mov	a,r6
	add	a,r6
;	lib/ch555/gpio.c:187: case PORT0:
	mov	dptr,#00117$
	jmp	@a+dptr
00117$:
	sjmp	00101$
	sjmp	00102$
	sjmp	00103$
	sjmp	00104$
	sjmp	00105$
00101$:
;	lib/ch555/gpio.c:188: P0_MOD_OC |=  pinmask;
	mov	a,r7
	orl	_P0_MOD_OC,a
;	lib/ch555/gpio.c:189: P0_DIR_PU |=  pinmask;
	mov	a,r7
	orl	_P0_DIR_PU,a
;	lib/ch555/gpio.c:190: break;
;	lib/ch555/gpio.c:193: case PORT1:
	ret
00102$:
;	lib/ch555/gpio.c:194: P1_MOD_OC |=  pinmask;
	mov	a,r7
	orl	_P1_MOD_OC,a
;	lib/ch555/gpio.c:195: P1_DIR_PU |=  pinmask;
	mov	a,r7
	orl	_P1_DIR_PU,a
;	lib/ch555/gpio.c:196: break;
;	lib/ch555/gpio.c:199: case PORT2:
	ret
00103$:
;	lib/ch555/gpio.c:200: P2_MOD_OC |=  pinmask;
	mov	a,r7
	orl	_P2_MOD_OC,a
;	lib/ch555/gpio.c:201: P2_DIR_PU |=  pinmask;
	mov	a,r7
	orl	_P2_DIR_PU,a
;	lib/ch555/gpio.c:202: break;
;	lib/ch555/gpio.c:205: case PORT3:
	ret
00104$:
;	lib/ch555/gpio.c:206: P3_MOD_OC |=  pinmask;
	mov	a,r7
	orl	_P3_MOD_OC,a
;	lib/ch555/gpio.c:207: P3_DIR_PU |=  pinmask;
	mov	a,r7
	orl	_P3_DIR_PU,a
;	lib/ch555/gpio.c:208: break;
;	lib/ch555/gpio.c:211: case PORT4:
	ret
00105$:
;	lib/ch555/gpio.c:212: P4_MOD_OC |= ~pinmask;
	mov	a,#0xff
	xrl	a,r7
	orl	_P4_MOD_OC,a
;	lib/ch555/gpio.c:213: P4_DIR_PU |=  pinmask;
	mov	a,r7
	orl	_P4_DIR_PU,a
;	lib/ch555/gpio.c:224: }
00107$:
;	lib/ch555/gpio.c:225: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'readPin'
;------------------------------------------------------------
;pin           Allocated with name '_readPin_pin_10000_34'
;port          Allocated to registers r6 
;pinmask       Allocated to registers r7 
;------------------------------------------------------------
;	lib/ch555/gpio.c:226: uint8_t readPin(uint8_t pin) {
;	-----------------------------------------
;	 function readPin
;	-----------------------------------------
_readPin:
	push	ar7
	push	ar6
	push	ar5
	push	ar4
	mov	a,dpl
	mov	dptr,#_readPin_pin_10000_34
	movx	@dptr,a
;	lib/ch555/gpio.c:227: __data uint8_t port = PORTx(pin);
	movx	a,@dptr
	mov	r7,a
	swap	a
	rl	a
	anl	a,#0x1f
	mov	r6,a
;	lib/ch555/gpio.c:228: __data uint8_t pinmask  = PIN_MASK(pin);
	mov	a,#0x07
	anl	a,r7
	mov	dptr,#_pin_to_pinmask
	movc	a,@a+dptr
	mov	r7,a
;	lib/ch555/gpio.c:229: switch (port) {
	mov	a,r6
	add	a,#0xff - 0x07
	jc	00107$
;	free result
	mov	a,r6
	add	a,#(00119$-3-.)
	movc	a,@a+pc
	mov	dpl,a
	mov	a,r6
	add	a,#(00120$-3-.)
	movc	a,@a+pc
	mov	dph,a
	clr	a
	jmp	@a+dptr
00119$:
	.db	00101$
	.db	00102$
	.db	00103$
	.db	00104$
	.db	00105$
	.db	00107$
	.db	00107$
	.db	00106$
00120$:
	.db	00101$>>8
	.db	00102$>>8
	.db	00103$>>8
	.db	00104$>>8
	.db	00105$>>8
	.db	00107$>>8
	.db	00107$>>8
	.db	00106$>>8
;	lib/ch555/gpio.c:231: case PORT0:
00101$:
;	lib/ch555/gpio.c:232: return ((bool)(P0 & pinmask));
	mov	a,r7
	anl	a,_P0
;	assignBit
	add	a,#0xff
	clr	a
	rlc	a
	mov	dpl,a
;	lib/ch555/gpio.c:236: case PORT1:
	sjmp	00109$
00102$:
;	lib/ch555/gpio.c:237: return ((bool)(P1 & pinmask));
	mov	a,r7
	anl	a,_P1
;	assignBit
	add	a,#0xff
	clr	a
	rlc	a
	mov	dpl,a
;	lib/ch555/gpio.c:241: case PORT2:
	sjmp	00109$
00103$:
;	lib/ch555/gpio.c:242: return ((bool)(P2 & pinmask));
	mov	a,r7
	anl	a,_P2
;	assignBit
	add	a,#0xff
	clr	a
	rlc	a
	mov	dpl,a
;	lib/ch555/gpio.c:246: case PORT3:
	sjmp	00109$
00104$:
;	lib/ch555/gpio.c:247: return ((bool)(P3 & pinmask));
	mov	a,r7
	anl	a,_P3
;	assignBit
	add	a,#0xff
	clr	a
	rlc	a
	mov	dpl,a
;	lib/ch555/gpio.c:251: case PORT4:
	sjmp	00109$
00105$:
;	lib/ch555/gpio.c:252: return ((bool)(P4 & pinmask));
	mov	a,r7
	anl	a,_P4
;	assignBit
	add	a,#0xff
	clr	a
	rlc	a
	mov	dpl,a
;	lib/ch555/gpio.c:256: case PORT7:
	sjmp	00109$
00106$:
;	lib/ch555/gpio.c:257: return ((bool)(P7 & (pinmask<<4))); // bP7_{0,1}_IN
	clr	a
	xch	a,r7
	swap	a
	xch	a,r7
	xrl	a,r7
	xch	a,r7
	anl	a,#0xf0
	xch	a,r7
	xrl	a,r7
	mov	r6,a
	mov	r4,_P7
	mov	r5,#0x00
	mov	a,r4
	anl	ar7,a
	mov	a,r5
	anl	ar6,a
;	assignBit
	mov	a,r7
	orl	a,r6
	add	a,#0xff
	clr	a
	rlc	a
	mov	dpl,a
;	lib/ch555/gpio.c:260: default:
	sjmp	00109$
00107$:
;	lib/ch555/gpio.c:261: return -1;
	mov	dpl, #0xff
;	lib/ch555/gpio.c:263: }
00109$:
;	lib/ch555/gpio.c:264: }
	pop	ar4
	pop	ar5
	pop	ar6
	pop	ar7
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'writePinHigh'
;------------------------------------------------------------
;pin           Allocated with name '_writePinHigh_pin_10000_38'
;port          Allocated to registers r6 
;pinmask       Allocated to registers r7 
;------------------------------------------------------------
;	lib/ch555/gpio.c:265: void writePinHigh(uint8_t pin) {
;	-----------------------------------------
;	 function writePinHigh
;	-----------------------------------------
_writePinHigh:
	mov	a,dpl
	mov	dptr,#_writePinHigh_pin_10000_38
	movx	@dptr,a
;	lib/ch555/gpio.c:266: __data uint8_t port = PORTx(pin);
	movx	a,@dptr
	mov	r7,a
	swap	a
	rl	a
	anl	a,#0x1f
	mov	r6,a
;	lib/ch555/gpio.c:267: __data uint8_t pinmask  = PIN_MASK(pin);
	mov	a,#0x07
	anl	a,r7
	mov	dptr,#_pin_to_pinmask
	movc	a,@a+dptr
	mov	r7,a
;	lib/ch555/gpio.c:268: switch (port) {
	mov	a,r6
	add	a,#0xff - 0x07
	jc	00108$
;	free result
	mov	a,r6
	add	a,#(00118$-3-.)
	movc	a,@a+pc
	mov	dpl,a
	mov	a,r6
	add	a,#(00119$-3-.)
	movc	a,@a+pc
	mov	dph,a
	clr	a
	jmp	@a+dptr
00118$:
	.db	00101$
	.db	00102$
	.db	00103$
	.db	00104$
	.db	00105$
	.db	00108$
	.db	00108$
	.db	00106$
00119$:
	.db	00101$>>8
	.db	00102$>>8
	.db	00103$>>8
	.db	00104$>>8
	.db	00105$>>8
	.db	00108$>>8
	.db	00108$>>8
	.db	00106$>>8
;	lib/ch555/gpio.c:270: case PORT0:
00101$:
;	lib/ch555/gpio.c:271: P0 |=  pinmask;
	mov	a,r7
	orl	_P0,a
;	lib/ch555/gpio.c:272: break;
;	lib/ch555/gpio.c:275: case PORT1:
	ret
00102$:
;	lib/ch555/gpio.c:276: P1 |=  pinmask;
	mov	a,r7
	orl	_P1,a
;	lib/ch555/gpio.c:277: break;
;	lib/ch555/gpio.c:280: case PORT2:
	ret
00103$:
;	lib/ch555/gpio.c:281: P2 |=  pinmask;
	mov	a,r7
	orl	_P2,a
;	lib/ch555/gpio.c:282: break;
;	lib/ch555/gpio.c:285: case PORT3:
	ret
00104$:
;	lib/ch555/gpio.c:286: P3 |=  pinmask;
	mov	a,r7
	orl	_P3,a
;	lib/ch555/gpio.c:287: break;
;	lib/ch555/gpio.c:290: case PORT4:
	ret
00105$:
;	lib/ch555/gpio.c:291: P4 |=  pinmask;
	mov	a,r7
	orl	_P4,a
;	lib/ch555/gpio.c:292: break;
;	lib/ch555/gpio.c:295: case PORT7:
	ret
00106$:
;	lib/ch555/gpio.c:296: P7 |=  pinmask; // _OUT_PU
	mov	a,r7
	orl	_P7,a
;	lib/ch555/gpio.c:299: }
00108$:
;	lib/ch555/gpio.c:300: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'writePinLow'
;------------------------------------------------------------
;pin           Allocated with name '_writePinLow_pin_10000_42'
;port          Allocated to registers r6 
;pinmask       Allocated to registers r7 
;------------------------------------------------------------
;	lib/ch555/gpio.c:301: void writePinLow(uint8_t pin) {
;	-----------------------------------------
;	 function writePinLow
;	-----------------------------------------
_writePinLow:
	mov	a,dpl
	mov	dptr,#_writePinLow_pin_10000_42
	movx	@dptr,a
;	lib/ch555/gpio.c:302: __data uint8_t port = PORTx(pin);
	movx	a,@dptr
	mov	r7,a
	swap	a
	rl	a
	anl	a,#0x1f
	mov	r6,a
;	lib/ch555/gpio.c:303: __data uint8_t pinmask  = PIN_MASK(pin);
	mov	a,#0x07
	anl	a,r7
	mov	dptr,#_pin_to_pinmask
	movc	a,@a+dptr
	mov	r7,a
;	lib/ch555/gpio.c:304: switch (port) {
	mov	a,r6
	add	a,#0xff - 0x07
	jc	00108$
;	free result
	mov	a,r6
	add	a,#(00118$-3-.)
	movc	a,@a+pc
	mov	dpl,a
	mov	a,r6
	add	a,#(00119$-3-.)
	movc	a,@a+pc
	mov	dph,a
	clr	a
	jmp	@a+dptr
00118$:
	.db	00101$
	.db	00102$
	.db	00103$
	.db	00104$
	.db	00105$
	.db	00108$
	.db	00108$
	.db	00106$
00119$:
	.db	00101$>>8
	.db	00102$>>8
	.db	00103$>>8
	.db	00104$>>8
	.db	00105$>>8
	.db	00108$>>8
	.db	00108$>>8
	.db	00106$>>8
;	lib/ch555/gpio.c:306: case PORT0:
00101$:
;	lib/ch555/gpio.c:307: P0 &= ~pinmask;
	mov	a,#0xff
	xrl	a,r7
	anl	_P0,a
;	lib/ch555/gpio.c:308: break;
;	lib/ch555/gpio.c:311: case PORT1:
	ret
00102$:
;	lib/ch555/gpio.c:312: P1 &= ~pinmask;
	mov	a,#0xff
	xrl	a,r7
	anl	_P1,a
;	lib/ch555/gpio.c:313: break;
;	lib/ch555/gpio.c:316: case PORT2:
	ret
00103$:
;	lib/ch555/gpio.c:317: P2 &= ~pinmask;
	mov	a,#0xff
	xrl	a,r7
	anl	_P2,a
;	lib/ch555/gpio.c:318: break;
;	lib/ch555/gpio.c:321: case PORT3:
	ret
00104$:
;	lib/ch555/gpio.c:322: P3 &= ~pinmask;
	mov	a,#0xff
	xrl	a,r7
	anl	_P3,a
;	lib/ch555/gpio.c:323: break;
;	lib/ch555/gpio.c:326: case PORT4:
	ret
00105$:
;	lib/ch555/gpio.c:327: P4 &= ~pinmask;
	mov	a,#0xff
	xrl	a,r7
	anl	_P4,a
;	lib/ch555/gpio.c:328: break;
;	lib/ch555/gpio.c:331: case PORT7:
	ret
00106$:
;	lib/ch555/gpio.c:332: P7 &= ~pinmask; // _OUT_PU
	mov	a,#0xff
	xrl	a,r7
	anl	_P7,a
;	lib/ch555/gpio.c:335: }
00108$:
;	lib/ch555/gpio.c:336: }
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area CONST   (CODE)
_pin_to_pinmask:
	.db #0x01	; 1
	.db #0x02	; 2
	.db #0x04	; 4
	.db #0x08	; 8
	.db #0x10	; 16
	.db #0x20	; 32
	.db #0x40	; 64
	.db #0x80	; 128
	.area CSEG    (CODE)
	.area XINIT   (CODE)
	.area CABS    (ABS,CODE)
