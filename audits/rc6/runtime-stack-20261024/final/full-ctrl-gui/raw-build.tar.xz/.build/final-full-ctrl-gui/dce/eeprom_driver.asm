;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (Linux)
;--------------------------------------------------------
	.module eeprom_driver
	
	.optsdcc -mmcs51 --model-large
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _ak820_eeprom_write_block_xdata
	.globl _ak820_eeprom_read_block_xdata
	.globl _eeprom_read_byte
	.globl _eeprom_update_dword_PARM_2
	.globl _eeprom_update_word_PARM_2
	.globl _eeprom_update_byte_PARM_2
	.globl _eeprom_write_dword_PARM_2
	.globl _eeprom_write_word_PARM_2
	.globl _eeprom_write_byte_PARM_2
	.globl _eeprom_read_word
	.globl _eeprom_read_dword
	.globl _eeprom_write_byte
	.globl _eeprom_write_word
	.globl _eeprom_write_dword
	.globl _eeprom_update_byte
	.globl _eeprom_update_word
	.globl _eeprom_update_dword
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; overlayable bit register bank
;--------------------------------------------------------
	.area BIT_BANK	(REL,OVR,DATA)
bits:
	.ds 1
	b0 = bits[0]
	b1 = bits[1]
	b2 = bits[2]
	b3 = bits[3]
	b4 = bits[4]
	b5 = bits[5]
	b6 = bits[6]
	b7 = bits[7]
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram
;--------------------------------------------------------
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; absolute internal ram data
;--------------------------------------------------------
	.area IABS    (ABS,DATA)
	.area IABS    (ABS,DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; uninitialized external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
_eeprom_read_word_addr_10000_91:
	.ds 3
_eeprom_read_word_ret_10000_92:
	.ds 2
_eeprom_read_dword_addr_10000_93:
	.ds 3
_eeprom_read_dword_ret_10000_94:
	.ds 4
_eeprom_write_byte_PARM_2:
	.ds 1
_eeprom_write_byte_addr_10000_95:
	.ds 3
_eeprom_write_word_PARM_2:
	.ds 2
_eeprom_write_word_addr_10000_97:
	.ds 3
_eeprom_write_dword_PARM_2:
	.ds 4
_eeprom_write_dword_addr_10000_99:
	.ds 3
_eeprom_update_byte_PARM_2:
	.ds 1
_eeprom_update_byte_addr_10000_107:
	.ds 3
_eeprom_update_word_PARM_2:
	.ds 2
_eeprom_update_word_addr_10000_111:
	.ds 3
_eeprom_update_dword_PARM_2:
	.ds 4
_eeprom_update_dword_addr_10000_115:
	.ds 3
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area XABS    (ABS,XDATA)
;--------------------------------------------------------
; initialized external ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area HOME    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'eeprom_read_word'
;------------------------------------------------------------
;addr          Allocated with name '_eeprom_read_word_addr_10000_91'
;ret           Allocated with name '_eeprom_read_word_ret_10000_92'
;------------------------------------------------------------
;	drivers/eeprom/eeprom_driver.c:44: uint16_t eeprom_read_word(const uint16_t *addr) {
;	-----------------------------------------
;	 function eeprom_read_word
;	-----------------------------------------
_eeprom_read_word:
	ar7 = 0x07
	ar6 = 0x06
	ar5 = 0x05
	ar4 = 0x04
	ar3 = 0x03
	ar2 = 0x02
	ar1 = 0x01
	ar0 = 0x00
	lcall	_ak820_outline_0036
	mov	dptr,#_eeprom_read_word_addr_10000_91
	lcall	_ak820_outline_0016
;	drivers/eeprom/eeprom_driver.c:45: uint16_t ret = 0;
	mov	dptr,#_eeprom_read_word_ret_10000_92
	lcall	_ak820_outline_0185
;	drivers/eeprom/eeprom_driver.c:46: EEPROM_LOCAL_READ(&ret, addr, 2);
	mov	dptr,#_eeprom_read_word_addr_10000_91
	lcall	_ak820_outline_0012
	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
	mov	a,r5
	lcall	_ak820_outline_0016
	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
	lcall	_ak820_outline_0113
	mov	dptr,#_eeprom_read_word_ret_10000_92
	lcall	_ak820_eeprom_read_block_xdata
;	drivers/eeprom/eeprom_driver.c:47: return ret;
	mov	dptr,#_eeprom_read_word_ret_10000_92
	lcall	_ak820_outline_0092
;	drivers/eeprom/eeprom_driver.c:48: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'eeprom_read_dword'
;------------------------------------------------------------
;addr          Allocated with name '_eeprom_read_dword_addr_10000_93'
;ret           Allocated with name '_eeprom_read_dword_ret_10000_94'
;------------------------------------------------------------
;	drivers/eeprom/eeprom_driver.c:50: uint32_t eeprom_read_dword(const uint32_t *addr) {
;	-----------------------------------------
;	 function eeprom_read_dword
;	-----------------------------------------
_eeprom_read_dword:
	lcall	_ak820_outline_0036
	mov	dptr,#_eeprom_read_dword_addr_10000_93
	lcall	_ak820_outline_0016
;	drivers/eeprom/eeprom_driver.c:51: uint32_t ret = 0;
	mov	dptr,#_eeprom_read_dword_ret_10000_94
	lcall	_ak820_outline_0051
;	drivers/eeprom/eeprom_driver.c:52: EEPROM_LOCAL_READ(&ret, addr, 4);
	mov	dptr,#_eeprom_read_dword_addr_10000_93
	lcall	_ak820_outline_0012
	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
	mov	a,r5
	lcall	_ak820_outline_0016
	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
	mov	a,#0x04
	lcall	_ak820_outline_0137
	mov	dptr,#_eeprom_read_dword_ret_10000_94
	lcall	_ak820_eeprom_read_block_xdata
;	drivers/eeprom/eeprom_driver.c:53: return ret;
	mov	dptr,#_eeprom_read_dword_ret_10000_94
	lcall	_ak820_outline_0055
;	drivers/eeprom/eeprom_driver.c:54: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'eeprom_write_byte'
;------------------------------------------------------------
;value         Allocated with name '_eeprom_write_byte_PARM_2'
;addr          Allocated with name '_eeprom_write_byte_addr_10000_95'
;------------------------------------------------------------
;	drivers/eeprom/eeprom_driver.c:56: void eeprom_write_byte(uint8_t *addr, uint8_t value) {
;	-----------------------------------------
;	 function eeprom_write_byte
;	-----------------------------------------
_eeprom_write_byte:
	lcall	_ak820_outline_0036
	mov	dptr,#_eeprom_write_byte_addr_10000_95
	lcall	_ak820_outline_0016
;	drivers/eeprom/eeprom_driver.c:57: EEPROM_LOCAL_WRITE(&value, addr, 1);
	mov	dptr,#_eeprom_write_byte_addr_10000_95
	lcall	_ak820_outline_0004
	mov	a,#0x01
	lcall	_ak820_outline_0137
	mov	dptr,#_eeprom_write_byte_PARM_2
;	drivers/eeprom/eeprom_driver.c:58: }
	ljmp	_ak820_eeprom_write_block_xdata
;------------------------------------------------------------
;Allocation info for local variables in function 'eeprom_write_word'
;------------------------------------------------------------
;value         Allocated with name '_eeprom_write_word_PARM_2'
;addr          Allocated with name '_eeprom_write_word_addr_10000_97'
;------------------------------------------------------------
;	drivers/eeprom/eeprom_driver.c:60: void eeprom_write_word(uint16_t *addr, uint16_t value) {
;	-----------------------------------------
;	 function eeprom_write_word
;	-----------------------------------------
_eeprom_write_word:
	lcall	_ak820_outline_0036
	mov	dptr,#_eeprom_write_word_addr_10000_97
	lcall	_ak820_outline_0016
;	drivers/eeprom/eeprom_driver.c:61: EEPROM_LOCAL_WRITE(&value, addr, 2);
	mov	dptr,#_eeprom_write_word_addr_10000_97
	lcall	_ak820_outline_0004
	lcall	_ak820_outline_0113
	mov	dptr,#_eeprom_write_word_PARM_2
;	drivers/eeprom/eeprom_driver.c:62: }
	ljmp	_ak820_eeprom_write_block_xdata
;------------------------------------------------------------
;Allocation info for local variables in function 'eeprom_write_dword'
;------------------------------------------------------------
;value         Allocated with name '_eeprom_write_dword_PARM_2'
;addr          Allocated with name '_eeprom_write_dword_addr_10000_99'
;------------------------------------------------------------
;	drivers/eeprom/eeprom_driver.c:64: void eeprom_write_dword(uint32_t *addr, uint32_t value) {
;	-----------------------------------------
;	 function eeprom_write_dword
;	-----------------------------------------
_eeprom_write_dword:
	lcall	_ak820_outline_0036
	mov	dptr,#_eeprom_write_dword_addr_10000_99
	lcall	_ak820_outline_0016
;	drivers/eeprom/eeprom_driver.c:65: EEPROM_LOCAL_WRITE(&value, addr, 4);
	mov	dptr,#_eeprom_write_dword_addr_10000_99
	lcall	_ak820_outline_0004
	mov	a,#0x04
	lcall	_ak820_outline_0137
	mov	dptr,#_eeprom_write_dword_PARM_2
;	drivers/eeprom/eeprom_driver.c:66: }
	ljmp	_ak820_eeprom_write_block_xdata
;------------------------------------------------------------
;Allocation info for local variables in function 'eeprom_update_block'
;------------------------------------------------------------
;sloc0         Allocated with name '_eeprom_update_block_sloc0_1_0'
;sloc1         Allocated with name '_eeprom_update_block_sloc1_1_0'
;sloc2         Allocated with name '_eeprom_update_block_sloc2_1_0'
;sloc3         Allocated with name '_eeprom_update_block_sloc3_1_0'
;addr          Allocated with name '_eeprom_update_block_PARM_2'
;len           Allocated with name '_eeprom_update_block_PARM_3'
;buf           Allocated with name '_eeprom_update_block_buf_10000_101'
;source        Allocated with name '_eeprom_update_block_source_10000_102'
;target        Allocated with name '_eeprom_update_block_target_10000_102'
;i             Allocated with name '_eeprom_update_block_i_10000_102'
;------------------------------------------------------------
;	drivers/eeprom/eeprom_driver.c:68: void eeprom_update_block(const void *buf, void *addr, size_t len) {
;	-----------------------------------------
;	 function eeprom_update_byte
;	-----------------------------------------
_eeprom_update_byte:
	push	ar7
	push	ar6
	push	ar5
	push	ar4
	lcall	_ak820_outline_0036
	mov	dptr,#_eeprom_update_byte_addr_10000_107
	lcall	_ak820_outline_0016
;	drivers/eeprom/eeprom_driver.c:83: uint8_t orig = eeprom_read_byte(addr);
	mov	dptr,#_eeprom_update_byte_addr_10000_107
	lcall	_ak820_outline_0001
	lcall	_eeprom_read_byte
	mov	r7, dpl
;	drivers/eeprom/eeprom_driver.c:84: if (orig != value) {
	mov	dptr,#_eeprom_update_byte_PARM_2
	movx	a,@dptr
	mov	r6,a
	mov	a,r7
	cjne	a,ar6,00112$
	sjmp	00103$
00112$:
;	drivers/eeprom/eeprom_driver.c:85: eeprom_write_byte(addr, value);
	mov	dptr,#_eeprom_update_byte_addr_10000_107
	lcall	_ak820_outline_0061
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_eeprom_write_byte_PARM_2
	mov	a,r6
	lcall	_ak820_outline_0101
	mov	b, r7
	push	ar7
	push	ar6
	push	ar5
	push	ar4
	push	ar3
	push	ar2
	push	ar1
	push	ar0
	lcall	_eeprom_write_byte
	pop	ar0
	pop	ar1
	pop	ar2
	pop	ar3
	pop	ar4
	pop	ar5
	pop	ar6
	pop	ar7
00103$:
;	drivers/eeprom/eeprom_driver.c:87: }
	pop	ar4
	pop	ar5
	pop	ar6
	pop	ar7
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'eeprom_update_word'
;------------------------------------------------------------
;value         Allocated with name '_eeprom_update_word_PARM_2'
;addr          Allocated with name '_eeprom_update_word_addr_10000_111'
;orig          Allocated with name '_eeprom_update_word_orig_10000_112'
;------------------------------------------------------------
;	drivers/eeprom/eeprom_driver.c:89: void eeprom_update_word(uint16_t *addr, uint16_t value) {
;	-----------------------------------------
;	 function eeprom_update_word
;	-----------------------------------------
_eeprom_update_word:
	lcall	_ak820_outline_0036
	mov	dptr,#_eeprom_update_word_addr_10000_111
	lcall	_ak820_outline_0016
;	drivers/eeprom/eeprom_driver.c:90: uint16_t orig = eeprom_read_word(addr);
	mov	dptr,#_eeprom_update_word_addr_10000_111
	lcall	_ak820_outline_0001
	lcall	_eeprom_read_word
	lcall	_ak820_outline_0136
;	drivers/eeprom/eeprom_driver.c:91: if (orig != value) {
	mov	dptr,#_eeprom_update_word_PARM_2
	lcall	_ak820_outline_0061
	mov	a,r6
	cjne	a,ar4,00112$
	mov	a,r7
	cjne	a,ar5,00112$
	ret
00112$:
;	drivers/eeprom/eeprom_driver.c:92: eeprom_write_word(addr, value);
	mov	dptr,#_eeprom_update_word_addr_10000_111
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	lcall	_ak820_outline_0052
	mov	dptr,#_eeprom_write_word_PARM_2
	lcall	_ak820_outline_0072
	mov	dpl, r3
	mov	dph, r6
	mov	b, r7
;	drivers/eeprom/eeprom_driver.c:94: }
	ljmp	_eeprom_write_word
;------------------------------------------------------------
;Allocation info for local variables in function 'eeprom_update_dword'
;------------------------------------------------------------
;value         Allocated with name '_eeprom_update_dword_PARM_2'
;addr          Allocated with name '_eeprom_update_dword_addr_10000_115'
;orig          Allocated with name '_eeprom_update_dword_orig_10000_116'
;------------------------------------------------------------
;	drivers/eeprom/eeprom_driver.c:96: void eeprom_update_dword(uint32_t *addr, uint32_t value) {
;	-----------------------------------------
;	 function eeprom_update_dword
;	-----------------------------------------
_eeprom_update_dword:
	lcall	_ak820_outline_0036
	mov	dptr,#_eeprom_update_dword_addr_10000_115
	lcall	_ak820_outline_0016
;	drivers/eeprom/eeprom_driver.c:97: uint32_t orig = eeprom_read_dword(addr);
	mov	dptr,#_eeprom_update_dword_addr_10000_115
	lcall	_ak820_outline_0001
	lcall	_eeprom_read_dword
	lcall	_ak820_outline_0056
;	drivers/eeprom/eeprom_driver.c:98: if (orig != value) {
	mov	dptr,#_eeprom_update_dword_PARM_2
	movx	a,@dptr
	mov	r0,a
	inc	dptr
	lcall	_ak820_outline_0091
	mov	a,r4
	cjne	a,ar0,00112$
	mov	a,r5
	cjne	a,ar1,00112$
	mov	a,r6
	cjne	a,ar2,00112$
	mov	a,r7
	cjne	a,ar3,00112$
	ret
00112$:
;	drivers/eeprom/eeprom_driver.c:99: eeprom_write_dword(addr, value);
	mov	dptr,#_eeprom_update_dword_addr_10000_115
	lcall	_ak820_outline_0012
	mov	dptr,#_eeprom_write_dword_PARM_2
	mov	a,r0
	movx	@dptr,a
	mov	a,r1
	inc	dptr
	lcall	_ak820_outline_0158
	lcall	_ak820_outline_0034
;	drivers/eeprom/eeprom_driver.c:101: }
	ljmp	_eeprom_write_dword
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
	.area CABS    (ABS,CODE)

; Experimental exact instruction outlining.
	.globl _ak820_outline_0001
	.globl _ak820_outline_0004
	.globl _ak820_outline_0012
	.globl _ak820_outline_0016
	.globl _ak820_outline_0034
	.globl _ak820_outline_0036
	.globl _ak820_outline_0051
	.globl _ak820_outline_0052
	.globl _ak820_outline_0055
	.globl _ak820_outline_0056
	.globl _ak820_outline_0061
	.globl _ak820_outline_0072
	.globl _ak820_outline_0091
	.globl _ak820_outline_0092
	.globl _ak820_outline_0101
	.globl _ak820_outline_0113
	.globl _ak820_outline_0136
	.globl _ak820_outline_0137
	.globl _ak820_outline_0158
	.globl _ak820_outline_0185

	.area CSEG (CODE)
; function ak820_outline_0001
_ak820_outline_0001:
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dpl,r5
	mov	dph,r6
	mov	b,r7
	ret

	.area CSEG (CODE)
; function ak820_outline_0004
_ak820_outline_0004:
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
	mov	a,r5
	movx	@dptr,a
	mov	a,r6
	inc	dptr
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
	ret

	.area CSEG (CODE)
; function ak820_outline_0012
_ak820_outline_0012:
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0034
_ak820_outline_0034:
	movx	@dptr,a
	mov	dpl,r5
	mov	dph,r6
	mov	b,r7
	ret

	.area CSEG (CODE)
; function ak820_outline_0051
_ak820_outline_0051:
	clr	a
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0055
_ak820_outline_0055:
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	dpl,r4
	mov	dph,r5
	mov	b,r6
	ret

	.area CSEG (CODE)
; function ak820_outline_0056
_ak820_outline_0056:
	mov	r4,dpl
	mov	r5,dph
	mov	r6,b
	mov	r7,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0091
_ak820_outline_0091:
	movx	a,@dptr
	mov	r1,a
	inc	dptr
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0092
_ak820_outline_0092:
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	dpl,r6
	mov	dph,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0113
_ak820_outline_0113:
	mov	a,#0x02
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0158
_ak820_outline_0158:
	movx	@dptr,a
	mov	a,r2
	inc	dptr
	movx	@dptr,a
	mov	a,r3
	inc	dptr
	ret

	.area CSEG (CODE)
; function ak820_outline_0185
_ak820_outline_0185:
	clr	a
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
	ret
