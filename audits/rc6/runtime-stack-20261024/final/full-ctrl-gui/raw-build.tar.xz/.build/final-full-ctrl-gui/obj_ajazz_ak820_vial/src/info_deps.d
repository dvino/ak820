generated-files: $(wildcard keyboards/ajazz/ak820/info.json)

generated-files: $(wildcard keyboards/ajazz/ak820/rules.mk)

generated-files: $(wildcard keyboards/ajazz/ak820/post_rules.mk)

generated-files: $(wildcard keyboards/ajazz/ak820/config.h)

generated-files: $(wildcard keyboards/ajazz/ak820/post_config.h)

generated-files: $(wildcard keyboards/ajazz/info.json)

generated-files: $(wildcard keyboards/ajazz/rules.mk)

generated-files: $(wildcard keyboards/ajazz/post_rules.mk)

generated-files: $(wildcard keyboards/ajazz/config.h)

generated-files: $(wildcard keyboards/ajazz/post_config.h)

generated-files: $(wildcard keyboards/ajazz/ak820/keymaps/vial/keymap.json)

generated-files: $(wildcard keyboards/ajazz/ak820/keymaps/vial/info.json)

generated-files: $(wildcard keyboards/ajazz/ak820/keymaps/vial/rules.mk)

generated-files: $(wildcard keyboards/ajazz/ak820/keymaps/vial/post_rules.mk)

generated-files: $(wildcard keyboards/ajazz/ak820/keymaps/vial/config.h)

generated-files: $(wildcard keyboards/ajazz/ak820/keymaps/vial/post_config.h)

generated-files: $(wildcard users/vial/info.json)

generated-files: $(wildcard users/vial/rules.mk)

generated-files: $(wildcard users/vial/post_rules.mk)

generated-files: $(wildcard users/vial/config.h)

generated-files: $(wildcard users/vial/post_config.h)

