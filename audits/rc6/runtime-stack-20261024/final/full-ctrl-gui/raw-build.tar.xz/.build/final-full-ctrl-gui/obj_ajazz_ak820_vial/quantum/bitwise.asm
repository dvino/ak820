;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (Linux)
;--------------------------------------------------------
	.module bitwise
	
	.optsdcc -mmcs51 --model-large
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _ADC_START
	.globl _S0_R_FIFO
	.globl _S0_T_FIFO
	.globl _S0_FREE
	.globl _S0_IF_BYTE
	.globl _S0_IF_FIRST
	.globl _S0_IF_OV
	.globl _S0_FST_ACT
	.globl _CP_RL2
	.globl _C_T2
	.globl _TR2
	.globl _EXEN2
	.globl _TCLK
	.globl _RCLK
	.globl _EXF2
	.globl _CAP1F
	.globl _TF2
	.globl _RI
	.globl _TI
	.globl _RB8
	.globl _TB8
	.globl _REN
	.globl _SM2
	.globl _SM1
	.globl _SM0
	.globl _IT0
	.globl _IE0
	.globl _IT1
	.globl _IE1
	.globl _TR0
	.globl _TF0
	.globl _TR1
	.globl _TF1
	.globl _P4_0
	.globl _P4_1
	.globl _P4_2
	.globl _P4_3
	.globl _P4_4
	.globl _P4_5
	.globl _P4_6
	.globl _RXD
	.globl _TXD
	.globl _INT0
	.globl _INT1
	.globl _T0
	.globl _T1
	.globl _MOSI1
	.globl _MISO1
	.globl _SCK1
	.globl _P3_0
	.globl _P3_1
	.globl _P3_2
	.globl _P3_3
	.globl _P3_4
	.globl _P3_5
	.globl _P3_6
	.globl _P3_7
	.globl _CAP1_
	.globl _T2_
	.globl _CAP2_
	.globl _T2EX_
	.globl _RXD1
	.globl _TXD1
	.globl _P2_0
	.globl _P2_1
	.globl _P2_2
	.globl _P2_3
	.globl _P2_4
	.globl _P2_5
	.globl _P2_6
	.globl _P2_7
	.globl _AIN0
	.globl _AIN1
	.globl _AIN2
	.globl _AIN3
	.globl _AIN4
	.globl _AIN5
	.globl _AIN6
	.globl _AIN7
	.globl _CAP1
	.globl _T2
	.globl _CAP2
	.globl _T2EX
	.globl _INT0_
	.globl _SCS
	.globl _MOSI
	.globl _MISO
	.globl _SCK
	.globl _RXD1_
	.globl _TXD1_
	.globl _P1_0
	.globl _P1_1
	.globl _P1_2
	.globl _P1_3
	.globl _P1_4
	.globl _P1_5
	.globl _P1_6
	.globl _P1_7
	.globl _AIN8
	.globl _AIN9
	.globl _AIN10
	.globl _AIN11
	.globl _AIN12
	.globl _AIN13
	.globl _RXD_
	.globl _TXD_
	.globl _SCL0
	.globl _SDA0
	.globl _P0_0
	.globl _P0_1
	.globl _P0_2
	.globl _P0_3
	.globl _P0_4
	.globl _P0_5
	.globl _P0_6
	.globl _P0_7
	.globl _IE_SPI0
	.globl _IE_USB
	.globl _IE_ADC
	.globl _IE_UART1
	.globl _IE_PWM_I2C
	.globl _IE_GPIO
	.globl _IE_WDOG
	.globl _PX0
	.globl _PT0
	.globl _PX1
	.globl _PT1
	.globl _PS
	.globl _PT2
	.globl _PL_FLAG
	.globl _PH_FLAG
	.globl _EX0
	.globl _ET0
	.globl _EX1
	.globl _ET1
	.globl _ES
	.globl _ET2
	.globl _E_DIS
	.globl _EA
	.globl _P
	.globl _F1
	.globl _OV
	.globl _RS0
	.globl _RS1
	.globl _F0
	.globl _AC
	.globl _CY
	.globl _I2CS_INT_ST
	.globl _I2CX_INT
	.globl _LED_STATUS
	.globl _LED_DMA_H
	.globl _LED_DMA_L
	.globl _LED_DMA
	.globl _LED_PWM_OE
	.globl _LED_COMMON
	.globl _ADC_CHAN
	.globl _ADC_DAT_H
	.globl _ADC_DAT_L
	.globl _ADC_DAT
	.globl _ADC_CTRL
	.globl _SPI1_CK_SE
	.globl _SPI1_CTRL
	.globl _SPI1_DATA
	.globl _SPI1_STAT
	.globl _SIF1
	.globl _SBAUD1
	.globl _SBUF1
	.globl _SCON1
	.globl _SPI0_SETUP
	.globl _SPI0_CK_SE
	.globl _SPI0_CTRL
	.globl _SPI0_DATA
	.globl _SPI0_STAT
	.globl _T2CAP1H
	.globl _T2CAP1L
	.globl _T2CAP1
	.globl _TH2
	.globl _TL2
	.globl _T2COUNT
	.globl _RCAP2H
	.globl _RCAP2L
	.globl _RCAP2
	.globl _T2MOD
	.globl _T2CON
	.globl _SBUF
	.globl _SCON
	.globl _TH1
	.globl _TH0
	.globl _TL1
	.globl _TL0
	.globl _TMOD
	.globl _TCON
	.globl _XBUS_AUX
	.globl _P7
	.globl _P6_DIR
	.globl _P6_OUT_PU
	.globl _P6_IN
	.globl _P5_DIR
	.globl _P5_OUT_PU
	.globl _P5_IN
	.globl _P4_LED_KEY
	.globl _P4_DIR_PU
	.globl _P4_MOD_OC
	.globl _P4
	.globl _P3_DIR_PU
	.globl _P3_MOD_OC
	.globl _P3
	.globl _P2_DIR_PU
	.globl _P2_MOD_OC
	.globl _P2
	.globl _P1_DIR_PU
	.globl _P1_MOD_OC
	.globl _P1
	.globl _P0_DIR_PU
	.globl _P0_MOD_OC
	.globl _P0
	.globl _ROM_CTRL
	.globl _ROM_DATA_HH
	.globl _ROM_DATA_HL
	.globl _ROM_DATA_HI
	.globl _ROM_ADDR_H
	.globl _ROM_ADDR_L
	.globl _ROM_ADDR
	.globl _GPIO_IE
	.globl _IP_EX
	.globl _IE_EX
	.globl _IP
	.globl _IE
	.globl _WDOG_COUNT
	.globl _RESET_KEEP
	.globl _WAKE_CTRL
	.globl _CLOCK_CFG
	.globl _POWER_CFG
	.globl _PCON
	.globl _GLOBAL_CFG
	.globl _SAFE_MOD
	.globl _DPH
	.globl _DPL
	.globl _SP
	.globl _A_INV
	.globl _B
	.globl _ACC
	.globl _PSW
	.globl _bitpop
	.globl _bitpop16
	.globl _bitpop32
	.globl _biton
	.globl _biton16
	.globl _biton32
	.globl _bitrev
	.globl _bitrev16
	.globl _bitrev32
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
_PSW	=	0x00d0
_ACC	=	0x00e0
_B	=	0x00f0
_A_INV	=	0x00fd
_SP	=	0x0081
_DPL	=	0x0082
_DPH	=	0x0083
_SAFE_MOD	=	0x00a1
_GLOBAL_CFG	=	0x00b1
_PCON	=	0x0087
_POWER_CFG	=	0x00ba
_CLOCK_CFG	=	0x00b9
_WAKE_CTRL	=	0x00a9
_RESET_KEEP	=	0x00fe
_WDOG_COUNT	=	0x00ff
_IE	=	0x00a8
_IP	=	0x00b8
_IE_EX	=	0x00e8
_IP_EX	=	0x00e9
_GPIO_IE	=	0x00b2
_ROM_ADDR	=	0x8584
_ROM_ADDR_L	=	0x0084
_ROM_ADDR_H	=	0x0085
_ROM_DATA_HI	=	0x8f8e
_ROM_DATA_HL	=	0x008e
_ROM_DATA_HH	=	0x008f
_ROM_CTRL	=	0x0086
_P0	=	0x0080
_P0_MOD_OC	=	0x00c4
_P0_DIR_PU	=	0x00c5
_P1	=	0x0090
_P1_MOD_OC	=	0x0092
_P1_DIR_PU	=	0x0093
_P2	=	0x00a0
_P2_MOD_OC	=	0x0094
_P2_DIR_PU	=	0x0095
_P3	=	0x00b0
_P3_MOD_OC	=	0x0096
_P3_DIR_PU	=	0x0097
_P4	=	0x00c0
_P4_MOD_OC	=	0x00c2
_P4_DIR_PU	=	0x00c3
_P4_LED_KEY	=	0x00c1
_P5_IN	=	0x00aa
_P5_OUT_PU	=	0x00ab
_P5_DIR	=	0x00ac
_P6_IN	=	0x00ad
_P6_OUT_PU	=	0x00ae
_P6_DIR	=	0x00af
_P7	=	0x00f1
_XBUS_AUX	=	0x00a2
_TCON	=	0x0088
_TMOD	=	0x0089
_TL0	=	0x008a
_TL1	=	0x008b
_TH0	=	0x008c
_TH1	=	0x008d
_SCON	=	0x0098
_SBUF	=	0x0099
_T2CON	=	0x00c8
_T2MOD	=	0x00c9
_RCAP2	=	0xcbca
_RCAP2L	=	0x00ca
_RCAP2H	=	0x00cb
_T2COUNT	=	0xcdcc
_TL2	=	0x00cc
_TH2	=	0x00cd
_T2CAP1	=	0xcfce
_T2CAP1L	=	0x00ce
_T2CAP1H	=	0x00cf
_SPI0_STAT	=	0x00f8
_SPI0_DATA	=	0x00f9
_SPI0_CTRL	=	0x00fa
_SPI0_CK_SE	=	0x00fb
_SPI0_SETUP	=	0x00fc
_SCON1	=	0x00bc
_SBUF1	=	0x00bd
_SBAUD1	=	0x00be
_SIF1	=	0x00bf
_SPI1_STAT	=	0x00b4
_SPI1_DATA	=	0x00b5
_SPI1_CTRL	=	0x00b6
_SPI1_CK_SE	=	0x00b7
_ADC_CTRL	=	0x00f3
_ADC_DAT	=	0xf5f4
_ADC_DAT_L	=	0x00f4
_ADC_DAT_H	=	0x00f5
_ADC_CHAN	=	0x00f6
_LED_COMMON	=	0x00a6
_LED_PWM_OE	=	0x00a7
_LED_DMA	=	0xc7c6
_LED_DMA_L	=	0x00c6
_LED_DMA_H	=	0x00c7
_LED_STATUS	=	0x00f7
_I2CX_INT	=	0x00b3
_I2CS_INT_ST	=	0x00bb
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
_CY	=	0x00d7
_AC	=	0x00d6
_F0	=	0x00d5
_RS1	=	0x00d4
_RS0	=	0x00d3
_OV	=	0x00d2
_F1	=	0x00d1
_P	=	0x00d0
_EA	=	0x00af
_E_DIS	=	0x00ae
_ET2	=	0x00ad
_ES	=	0x00ac
_ET1	=	0x00ab
_EX1	=	0x00aa
_ET0	=	0x00a9
_EX0	=	0x00a8
_PH_FLAG	=	0x00bf
_PL_FLAG	=	0x00be
_PT2	=	0x00bd
_PS	=	0x00bc
_PT1	=	0x00bb
_PX1	=	0x00ba
_PT0	=	0x00b9
_PX0	=	0x00b8
_IE_WDOG	=	0x00ef
_IE_GPIO	=	0x00ee
_IE_PWM_I2C	=	0x00ed
_IE_UART1	=	0x00ec
_IE_ADC	=	0x00eb
_IE_USB	=	0x00e9
_IE_SPI0	=	0x00e8
_P0_7	=	0x0087
_P0_6	=	0x0086
_P0_5	=	0x0085
_P0_4	=	0x0084
_P0_3	=	0x0083
_P0_2	=	0x0082
_P0_1	=	0x0081
_P0_0	=	0x0080
_SDA0	=	0x0081
_SCL0	=	0x0080
_TXD_	=	0x0083
_RXD_	=	0x0082
_AIN13	=	0x0085
_AIN12	=	0x0084
_AIN11	=	0x0083
_AIN10	=	0x0082
_AIN9	=	0x0081
_AIN8	=	0x0080
_P1_7	=	0x0097
_P1_6	=	0x0096
_P1_5	=	0x0095
_P1_4	=	0x0094
_P1_3	=	0x0093
_P1_2	=	0x0092
_P1_1	=	0x0091
_P1_0	=	0x0090
_TXD1_	=	0x0097
_RXD1_	=	0x0096
_SCK	=	0x0097
_MISO	=	0x0096
_MOSI	=	0x0095
_SCS	=	0x0094
_INT0_	=	0x0092
_T2EX	=	0x0091
_CAP2	=	0x0091
_T2	=	0x0090
_CAP1	=	0x0090
_AIN7	=	0x0097
_AIN6	=	0x0096
_AIN5	=	0x0095
_AIN4	=	0x0094
_AIN3	=	0x0093
_AIN2	=	0x0092
_AIN1	=	0x0091
_AIN0	=	0x0090
_P2_7	=	0x00a7
_P2_6	=	0x00a6
_P2_5	=	0x00a5
_P2_4	=	0x00a4
_P2_3	=	0x00a3
_P2_2	=	0x00a2
_P2_1	=	0x00a1
_P2_0	=	0x00a0
_TXD1	=	0x00a7
_RXD1	=	0x00a6
_T2EX_	=	0x00a5
_CAP2_	=	0x00a5
_T2_	=	0x00a4
_CAP1_	=	0x00a4
_P3_7	=	0x00b7
_P3_6	=	0x00b6
_P3_5	=	0x00b5
_P3_4	=	0x00b4
_P3_3	=	0x00b3
_P3_2	=	0x00b2
_P3_1	=	0x00b1
_P3_0	=	0x00b0
_SCK1	=	0x00b7
_MISO1	=	0x00b6
_MOSI1	=	0x00b5
_T1	=	0x00b5
_T0	=	0x00b4
_INT1	=	0x00b3
_INT0	=	0x00b2
_TXD	=	0x00b1
_RXD	=	0x00b0
_P4_6	=	0x00c6
_P4_5	=	0x00c5
_P4_4	=	0x00c4
_P4_3	=	0x00c3
_P4_2	=	0x00c2
_P4_1	=	0x00c1
_P4_0	=	0x00c0
_TF1	=	0x008f
_TR1	=	0x008e
_TF0	=	0x008d
_TR0	=	0x008c
_IE1	=	0x008b
_IT1	=	0x008a
_IE0	=	0x0089
_IT0	=	0x0088
_SM0	=	0x009f
_SM1	=	0x009e
_SM2	=	0x009d
_REN	=	0x009c
_TB8	=	0x009b
_RB8	=	0x009a
_TI	=	0x0099
_RI	=	0x0098
_TF2	=	0x00cf
_CAP1F	=	0x00cf
_EXF2	=	0x00ce
_RCLK	=	0x00cd
_TCLK	=	0x00cc
_EXEN2	=	0x00cb
_TR2	=	0x00ca
_C_T2	=	0x00c9
_CP_RL2	=	0x00c8
_S0_FST_ACT	=	0x00ff
_S0_IF_OV	=	0x00fe
_S0_IF_FIRST	=	0x00fd
_S0_IF_BYTE	=	0x00fc
_S0_FREE	=	0x00fb
_S0_T_FIFO	=	0x00fa
_S0_R_FIFO	=	0x00f8
_ADC_START	=	0x00f7
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram
;--------------------------------------------------------
	.area	OSEG    (OVR,DATA)
_bitpop32_sloc0_1_0:
	.ds 1
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; absolute internal ram data
;--------------------------------------------------------
	.area IABS    (ABS,DATA)
	.area IABS    (ABS,DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; uninitialized external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
_bitpop_bits_10000_49:
	.ds 1
_bitpop16_bits_10000_52:
	.ds 2
_bitpop32_bits_10000_55:
	.ds 4
_biton_bits_10000_58:
	.ds 1
_biton_n_10000_59:
	.ds 1
_biton16_bits_10000_66:
	.ds 2
_biton16_n_10000_67:
	.ds 1
_biton32_bits_10000_76:
	.ds 4
_biton32_n_10000_77:
	.ds 1
_bitrev_bits_10000_88:
	.ds 1
_bitrev16_bits_10000_90:
	.ds 2
_bitrev32_bits_10000_92:
	.ds 4
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area XABS    (ABS,XDATA)
;--------------------------------------------------------
; initialized external ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area HOME    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'bitpop'
;------------------------------------------------------------
;bits          Allocated with name '_bitpop_bits_10000_49'
;c             Allocated with name '_bitpop_c_10000_50'
;------------------------------------------------------------
;	quantum/bitwise.c:22: __attribute__((noinline)) uint8_t bitpop(uint8_t bits) {
;	-----------------------------------------
;	 function bitpop
;	-----------------------------------------
_bitpop:
	ar7 = 0x07
	ar6 = 0x06
	ar5 = 0x05
	ar4 = 0x04
	ar3 = 0x03
	ar2 = 0x02
	ar1 = 0x01
	ar0 = 0x00
	mov	a,dpl
	mov	dptr,#_bitpop_bits_10000_49
	movx	@dptr,a
;	quantum/bitwise.c:24: for (c = 0; bits; c++)
	mov	r7,#0x00
00103$:
	mov	dptr,#_bitpop_bits_10000_49
	movx	a,@dptr
	mov	r6,a
	jz	00101$
;	quantum/bitwise.c:25: bits &= bits - 1;
	mov	ar5,r6
	mov	a,r5
	dec	a
	mov	dptr,#_bitpop_bits_10000_49
	anl	a,r6
	movx	@dptr,a
;	quantum/bitwise.c:24: for (c = 0; bits; c++)
	inc	r7
	sjmp	00103$
00101$:
;	quantum/bitwise.c:26: return c;
	mov	dpl, r7
;	quantum/bitwise.c:31: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'bitpop16'
;------------------------------------------------------------
;bits          Allocated with name '_bitpop16_bits_10000_52'
;c             Allocated with name '_bitpop16_c_10000_53'
;------------------------------------------------------------
;	quantum/bitwise.c:33: uint8_t bitpop16(uint16_t bits) {
;	-----------------------------------------
;	 function bitpop16
;	-----------------------------------------
_bitpop16:
	mov	r7,dph
	mov	a,dpl
	mov	dptr,#_bitpop16_bits_10000_52
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	quantum/bitwise.c:35: for (c = 0; bits; c++)
	mov	r7,#0x00
00103$:
	mov	dptr,#_bitpop16_bits_10000_52
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	mov	dptr,#_bitpop16_bits_10000_52
	movx	a,@dptr
	mov	b,a
	inc	dptr
	movx	a,@dptr
	orl	a,b
	jz	00101$
;	quantum/bitwise.c:36: bits &= bits - 1;
	mov	a,r5
	add	a,#0xff
	mov	r3,a
	mov	a,r6
	addc	a,#0xff
	mov	r4,a
	mov	a,r3
	anl	ar5,a
	mov	a,r4
	anl	ar6,a
	mov	dptr,#_bitpop16_bits_10000_52
	mov	a,r5
	movx	@dptr,a
	mov	a,r6
	inc	dptr
	movx	@dptr,a
;	quantum/bitwise.c:35: for (c = 0; bits; c++)
	inc	r7
	sjmp	00103$
00101$:
;	quantum/bitwise.c:37: return c;
	mov	dpl, r7
;	quantum/bitwise.c:38: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'bitpop32'
;------------------------------------------------------------
;bits          Allocated with name '_bitpop32_bits_10000_55'
;c             Allocated with name '_bitpop32_c_10000_56'
;sloc0         Allocated with name '_bitpop32_sloc0_1_0'
;------------------------------------------------------------
;	quantum/bitwise.c:40: uint8_t bitpop32(uint32_t bits) {
;	-----------------------------------------
;	 function bitpop32
;	-----------------------------------------
_bitpop32:
	mov	r7,dpl
	mov	r6,dph
	mov	r5,b
	mov	r4,a
	mov	dptr,#_bitpop32_bits_10000_55
	mov	a,r7
	movx	@dptr,a
	mov	a,r6
	inc	dptr
	movx	@dptr,a
	mov	a,r5
	inc	dptr
	movx	@dptr,a
	mov	a,r4
	inc	dptr
	movx	@dptr,a
;	quantum/bitwise.c:42: for (c = 0; bits; c++)
	mov	_bitpop32_sloc0_1_0,#0x00
00103$:
	mov	dptr,#_bitpop32_bits_10000_55
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	mov	a,r3
	orl	a,r4
	orl	a,r5
	orl	a,r6
	jz	00101$
;	quantum/bitwise.c:43: bits &= bits - 1;
	mov	a,r3
	add	a,#0xff
	mov	r0,a
	mov	a,r4
	addc	a,#0xff
	mov	r1,a
	mov	a,r5
	addc	a,#0xff
	mov	r2,a
	mov	a,r6
	addc	a,#0xff
	mov	r7,a
	mov	dptr,#_bitpop32_bits_10000_55
	mov	a,r0
	anl	a,r3
	movx	@dptr,a
	mov	a,r1
	anl	a,r4
	inc	dptr
	movx	@dptr,a
	mov	a,r2
	anl	a,r5
	inc	dptr
	movx	@dptr,a
	mov	a,r7
	anl	a,r6
	inc	dptr
	movx	@dptr,a
;	quantum/bitwise.c:42: for (c = 0; bits; c++)
	inc	_bitpop32_sloc0_1_0
	sjmp	00103$
00101$:
;	quantum/bitwise.c:44: return c;
	mov	dpl, _bitpop32_sloc0_1_0
;	quantum/bitwise.c:45: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'biton'
;------------------------------------------------------------
;bits          Allocated with name '_biton_bits_10000_58'
;n             Allocated with name '_biton_n_10000_59'
;------------------------------------------------------------
;	quantum/bitwise.c:49: __attribute__((noinline)) uint8_t biton(uint8_t bits) {
;	-----------------------------------------
;	 function biton
;	-----------------------------------------
_biton:
	mov	a,dpl
	mov	dptr,#_biton_bits_10000_58
	movx	@dptr,a
;	quantum/bitwise.c:50: uint8_t n = 0;
	mov	dptr,#_biton_n_10000_59
	clr	a
	movx	@dptr,a
;	quantum/bitwise.c:51: if (bits >> 4) {
	mov	dptr,#_biton_bits_10000_58
	movx	a,@dptr
	swap	a
	anl	a,#0x0f
	mov	r7,a
	jz	00102$
;	quantum/bitwise.c:52: bits >>= 4;
	mov	dptr,#_biton_bits_10000_58
	mov	a,r7
	movx	@dptr,a
;	quantum/bitwise.c:53: n += 4;
	mov	dptr,#_biton_n_10000_59
	mov	a,#0x04
	movx	@dptr,a
00102$:
;	quantum/bitwise.c:55: if (bits >> 2) {
	mov	dptr,#_biton_bits_10000_58
	movx	a,@dptr
	rr	a
	rr	a
	anl	a,#0x3f
	mov	r7,a
	jz	00104$
;	quantum/bitwise.c:56: bits >>= 2;
	mov	dptr,#_biton_bits_10000_58
	mov	a,r7
	movx	@dptr,a
;	quantum/bitwise.c:57: n += 2;
	mov	dptr,#_biton_n_10000_59
	movx	a,@dptr
	add	a,#0x02
	movx	@dptr,a
00104$:
;	quantum/bitwise.c:59: if (bits >> 1) {
	mov	dptr,#_biton_bits_10000_58
	movx	a,@dptr
	clr	c
	rrc	a
	mov	r7,a
	jz	00106$
;	quantum/bitwise.c:60: bits >>= 1;
	mov	dptr,#_biton_bits_10000_58
	mov	a,r7
	movx	@dptr,a
;	quantum/bitwise.c:61: n += 1;
	mov	dptr,#_biton_n_10000_59
	movx	a,@dptr
	inc	a
	movx	@dptr,a
00106$:
;	quantum/bitwise.c:63: return n;
	mov	dptr,#_biton_n_10000_59
	movx	a,@dptr
;	quantum/bitwise.c:64: }
	mov	dpl,a
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'biton16'
;------------------------------------------------------------
;bits          Allocated with name '_biton16_bits_10000_66'
;n             Allocated with name '_biton16_n_10000_67'
;------------------------------------------------------------
;	quantum/bitwise.c:66: uint8_t biton16(uint16_t bits) {
;	-----------------------------------------
;	 function biton16
;	-----------------------------------------
_biton16:
	mov	r7,dph
	mov	a,dpl
	mov	dptr,#_biton16_bits_10000_66
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	quantum/bitwise.c:67: uint8_t n = 0;
	mov	dptr,#_biton16_n_10000_67
	clr	a
	movx	@dptr,a
;	quantum/bitwise.c:68: if (bits >> 8) {
	mov	dptr,#_biton16_bits_10000_66
	movx	a,@dptr
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	mov	r7,#0x00
	orl	a,r7
	jz	00102$
;	quantum/bitwise.c:69: bits >>= 8;
	mov	dptr,#_biton16_bits_10000_66
	mov	a,r6
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	quantum/bitwise.c:70: n += 8;
	mov	dptr,#_biton16_n_10000_67
	mov	a,#0x08
	movx	@dptr,a
00102$:
;	quantum/bitwise.c:72: if (bits >> 4) {
	mov	dptr,#_biton16_bits_10000_66
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	swap	a
	xch	a,r6
	swap	a
	anl	a,#0x0f
	xrl	a,r6
	xch	a,r6
	anl	a,#0x0f
	xch	a,r6
	xrl	a,r6
	xch	a,r6
	mov	r7,a
	orl	a,r6
	jz	00104$
;	quantum/bitwise.c:73: bits >>= 4;
	mov	dptr,#_biton16_bits_10000_66
	mov	a,r6
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	quantum/bitwise.c:74: n += 4;
	mov	dptr,#_biton16_n_10000_67
	movx	a,@dptr
	add	a,#0x04
	movx	@dptr,a
00104$:
;	quantum/bitwise.c:76: if (bits >> 2) {
	mov	dptr,#_biton16_bits_10000_66
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	clr	c
	rrc	a
	xch	a,r6
	rrc	a
	xch	a,r6
	clr	c
	rrc	a
	xch	a,r6
	rrc	a
	xch	a,r6
	mov	r7,a
	orl	a,r6
	jz	00106$
;	quantum/bitwise.c:77: bits >>= 2;
	mov	dptr,#_biton16_bits_10000_66
	mov	a,r6
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	quantum/bitwise.c:78: n += 2;
	mov	dptr,#_biton16_n_10000_67
	movx	a,@dptr
	add	a,#0x02
	movx	@dptr,a
00106$:
;	quantum/bitwise.c:80: if (bits >> 1) {
	mov	dptr,#_biton16_bits_10000_66
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	clr	c
	rrc	a
	xch	a,r6
	rrc	a
	xch	a,r6
	mov	r7,a
	orl	a,r6
	jz	00108$
;	quantum/bitwise.c:81: bits >>= 1;
	mov	dptr,#_biton16_bits_10000_66
	mov	a,r6
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	quantum/bitwise.c:82: n += 1;
	mov	dptr,#_biton16_n_10000_67
	movx	a,@dptr
	inc	a
	movx	@dptr,a
00108$:
;	quantum/bitwise.c:84: return n;
	mov	dptr,#_biton16_n_10000_67
	movx	a,@dptr
;	quantum/bitwise.c:85: }
	mov	dpl,a
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'biton32'
;------------------------------------------------------------
;bits          Allocated with name '_biton32_bits_10000_76'
;n             Allocated with name '_biton32_n_10000_77'
;------------------------------------------------------------
;	quantum/bitwise.c:87: uint8_t biton32(uint32_t bits) {
;	-----------------------------------------
;	 function biton32
;	-----------------------------------------
_biton32:
	mov	r7,dpl
	mov	r6,dph
	mov	r5,b
	mov	r4,a
	mov	dptr,#_biton32_bits_10000_76
	mov	a,r7
	movx	@dptr,a
	mov	a,r6
	inc	dptr
	movx	@dptr,a
	mov	a,r5
	inc	dptr
	movx	@dptr,a
	mov	a,r4
	inc	dptr
	movx	@dptr,a
;	quantum/bitwise.c:88: uint8_t n = 0;
	mov	dptr,#_biton32_n_10000_77
	clr	a
	movx	@dptr,a
;	quantum/bitwise.c:89: if (bits >> 16) {
	mov	dptr,#_biton32_bits_10000_76
	movx	a,@dptr
	inc	dptr
	movx	a,@dptr
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	ar4,r6
	mov	ar5,r7
	clr	a
	mov	r6,a
	mov	r7,a
	mov	a,r4
	orl	a,r5
	orl	a,r6
	orl	a,r7
	jz	00102$
;	quantum/bitwise.c:90: bits >>= 16;
	mov	dptr,#_biton32_bits_10000_76
	mov	a,r4
	movx	@dptr,a
	mov	a,r5
	inc	dptr
	movx	@dptr,a
	mov	a,r6
	inc	dptr
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	quantum/bitwise.c:91: n += 16;
	mov	dptr,#_biton32_n_10000_77
	mov	a,#0x10
	movx	@dptr,a
00102$:
;	quantum/bitwise.c:93: if (bits >> 8) {
	mov	dptr,#_biton32_bits_10000_76
	movx	a,@dptr
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	ar4,r5
	mov	ar5,r6
	mov	ar6,r7
	mov	r7,#0x00
	mov	a,r4
	orl	a,r5
	orl	a,r6
	orl	a,r7
	jz	00104$
;	quantum/bitwise.c:94: bits >>= 8;
	mov	dptr,#_biton32_bits_10000_76
	mov	a,r4
	movx	@dptr,a
	mov	a,r5
	inc	dptr
	movx	@dptr,a
	mov	a,r6
	inc	dptr
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	quantum/bitwise.c:95: n += 8;
	mov	dptr,#_biton32_n_10000_77
	movx	a,@dptr
	add	a,#0x08
	movx	@dptr,a
00104$:
;	quantum/bitwise.c:97: if (bits >> 4) {
	mov	dptr,#_biton32_bits_10000_76
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	a,r5
	swap	a
	xch	a,r4
	swap	a
	anl	a,#0x0f
	xrl	a,r4
	xch	a,r4
	anl	a,#0x0f
	xch	a,r4
	xrl	a,r4
	xch	a,r4
	mov	r5,a
	mov	a,r6
	swap	a
	anl	a,#0xf0
	orl	a,r5
	mov	r5,a
	mov	a,r7
	swap	a
	xch	a,r6
	swap	a
	anl	a,#0x0f
	xrl	a,r6
	xch	a,r6
	anl	a,#0x0f
	xch	a,r6
	xrl	a,r6
	xch	a,r6
	mov	r7,a
	mov	a,r4
	orl	a,r5
	orl	a,r6
	orl	a,r7
	jz	00106$
;	quantum/bitwise.c:98: bits >>= 4;
	mov	dptr,#_biton32_bits_10000_76
	mov	a,r4
	movx	@dptr,a
	mov	a,r5
	inc	dptr
	movx	@dptr,a
	mov	a,r6
	inc	dptr
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	quantum/bitwise.c:99: n += 4;
	mov	dptr,#_biton32_n_10000_77
	movx	a,@dptr
	add	a,#0x04
	movx	@dptr,a
00106$:
;	quantum/bitwise.c:101: if (bits >> 2) {
	mov	dptr,#_biton32_bits_10000_76
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	clr	c
	rrc	a
	mov	r7,a
	mov	a,r6
	rrc	a
	mov	r6,a
	mov	a,r5
	rrc	a
	mov	r5,a
	mov	a,r4
	rrc	a
	mov	r4,a
	mov	a,r7
	clr	c
	rrc	a
	mov	r7,a
	mov	a,r6
	rrc	a
	mov	r6,a
	mov	a,r5
	rrc	a
	mov	r5,a
	mov	a,r4
	rrc	a
	mov	r4,a
	orl	a,r5
	orl	a,r6
	orl	a,r7
	jz	00108$
;	quantum/bitwise.c:102: bits >>= 2;
	mov	dptr,#_biton32_bits_10000_76
	mov	a,r4
	movx	@dptr,a
	mov	a,r5
	inc	dptr
	movx	@dptr,a
	mov	a,r6
	inc	dptr
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	quantum/bitwise.c:103: n += 2;
	mov	dptr,#_biton32_n_10000_77
	movx	a,@dptr
	add	a,#0x02
	movx	@dptr,a
00108$:
;	quantum/bitwise.c:105: if (bits >> 1) {
	mov	dptr,#_biton32_bits_10000_76
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	clr	c
	rrc	a
	mov	r7,a
	mov	a,r6
	rrc	a
	mov	r6,a
	mov	a,r5
	rrc	a
	mov	r5,a
	mov	a,r4
	rrc	a
	mov	r4,a
	orl	a,r5
	orl	a,r6
	orl	a,r7
	jz	00110$
;	quantum/bitwise.c:106: bits >>= 1;
	mov	dptr,#_biton32_bits_10000_76
	mov	a,r4
	movx	@dptr,a
	mov	a,r5
	inc	dptr
	movx	@dptr,a
	mov	a,r6
	inc	dptr
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	quantum/bitwise.c:107: n += 1;
	mov	dptr,#_biton32_n_10000_77
	movx	a,@dptr
	inc	a
	movx	@dptr,a
00110$:
;	quantum/bitwise.c:109: return n;
	mov	dptr,#_biton32_n_10000_77
	movx	a,@dptr
;	quantum/bitwise.c:110: }
	mov	dpl,a
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'bitrev'
;------------------------------------------------------------
;bits          Allocated with name '_bitrev_bits_10000_88'
;------------------------------------------------------------
;	quantum/bitwise.c:112: __attribute__((noinline)) uint8_t bitrev(uint8_t bits) {
;	-----------------------------------------
;	 function bitrev
;	-----------------------------------------
_bitrev:
	mov	a,dpl
	mov	dptr,#_bitrev_bits_10000_88
	movx	@dptr,a
;	quantum/bitwise.c:113: bits = (bits & 0x0f) << 4 | (bits & 0xf0) >> 4;
	movx	a,@dptr
	mov	r7,a
	anl	a,#0x0f
	swap	a
	anl	a,#0xf0
	mov	r6,a
	anl	ar7,#0xf0
	clr	a
	xch	a,r7
	swap	a
	anl	a,#0x0f
	xrl	a,r7
	xch	a,r7
	anl	a,#0x0f
	xch	a,r7
	xrl	a,r7
	xch	a,r7
	jnb	acc.3,00103$
	orl	a,#0xfffffff0
00103$:
	mov	dptr,#_bitrev_bits_10000_88
	mov	a,r7
	orl	a,r6
	movx	@dptr,a
;	quantum/bitwise.c:114: bits = (bits & 0b00110011) << 2 | (bits & 0b11001100) >> 2;
	movx	a,@dptr
	mov	r7,a
	anl	a,#0x33
	add	a,acc
	add	a,acc
	mov	r6,a
	anl	ar7,#0xcc
	clr	a
	mov	c,acc.7
	rrc	a
	xch	a,r7
	rrc	a
	xch	a,r7
	mov	c,acc.7
	rrc	a
	xch	a,r7
	rrc	a
	xch	a,r7
	mov	dptr,#_bitrev_bits_10000_88
	mov	a,r7
	orl	a,r6
	movx	@dptr,a
;	quantum/bitwise.c:115: bits = (bits & 0b01010101) << 1 | (bits & 0b10101010) >> 1;
	movx	a,@dptr
	mov	r7,a
	anl	a,#0x55
	add	a,acc
	mov	r6,a
	anl	ar7,#0xaa
	clr	a
	mov	c,acc.7
	rrc	a
	xch	a,r7
	rrc	a
	xch	a,r7
	mov	dptr,#_bitrev_bits_10000_88
	mov	a,r7
	orl	a,r6
	movx	@dptr,a
;	quantum/bitwise.c:116: return bits;
	movx	a,@dptr
;	quantum/bitwise.c:117: }
	mov	dpl,a
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'bitrev16'
;------------------------------------------------------------
;bits          Allocated with name '_bitrev16_bits_10000_90'
;------------------------------------------------------------
;	quantum/bitwise.c:119: uint16_t bitrev16(uint16_t bits) {
;	-----------------------------------------
;	 function bitrev16
;	-----------------------------------------
_bitrev16:
	mov	r7,dph
	mov	a,dpl
	mov	dptr,#_bitrev16_bits_10000_90
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	quantum/bitwise.c:120: bits = bitrev(bits & 0x00ff) << 8 | bitrev((bits & 0xff00) >> 8);
	mov	dptr,#_bitrev16_bits_10000_90
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	ar5,r6
	mov	dpl, r5
	push	ar7
	push	ar6
	lcall	_bitrev
	mov	r5, dpl
	pop	ar6
	pop	ar7
	mov	ar4,r5
	mov	r5,#0x00
	mov	ar6,r7
	mov	dpl, r6
	push	ar5
	push	ar4
	lcall	_bitrev
	mov	r7, dpl
	pop	ar4
	pop	ar5
	mov	r6,#0x00
	mov	a,r7
	orl	ar5,a
	mov	a,r6
	orl	ar4,a
	mov	dptr,#_bitrev16_bits_10000_90
	mov	a,r5
	movx	@dptr,a
	mov	a,r4
	inc	dptr
	movx	@dptr,a
;	quantum/bitwise.c:121: return bits;
	mov	dpl, r5
	mov	dph, r4
;	quantum/bitwise.c:122: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'bitrev32'
;------------------------------------------------------------
;bits          Allocated with name '_bitrev32_bits_10000_92'
;------------------------------------------------------------
;	quantum/bitwise.c:124: uint32_t bitrev32(uint32_t bits) {
;	-----------------------------------------
;	 function bitrev32
;	-----------------------------------------
_bitrev32:
	mov	r7,dpl
	mov	r6,dph
	mov	r5,b
	mov	r4,a
	mov	dptr,#_bitrev32_bits_10000_92
	mov	a,r7
	movx	@dptr,a
	mov	a,r6
	inc	dptr
	movx	@dptr,a
	mov	a,r5
	inc	dptr
	movx	@dptr,a
	mov	a,r4
	inc	dptr
	movx	@dptr,a
;	quantum/bitwise.c:125: bits = (uint32_t)bitrev16(bits & 0x0000ffff) << 16 | bitrev16((bits & 0xffff0000) >> 16);
	mov	dptr,#_bitrev32_bits_10000_92
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	ar2,r4
	mov	ar3,r5
	mov	dpl, r2
	mov	dph, r3
	push	ar7
	push	ar6
	push	ar5
	push	ar4
	lcall	_bitrev16
	mov	r2, dpl
	mov	r3, dph
	pop	ar4
	pop	ar5
	pop	ar6
	pop	ar7
	mov	ar0,r2
	mov	ar1,r3
	mov	ar3,r1
	mov	ar2,r0
	mov	r0,#0x00
	mov	r1,#0x00
	mov	ar4,r6
	mov	ar5,r7
	mov	dpl, r4
	mov	dph, r5
	push	ar3
	push	ar2
	push	ar1
	push	ar0
	lcall	_bitrev16
	mov	r6, dpl
	mov	r7, dph
	pop	ar0
	pop	ar1
	pop	ar2
	pop	ar3
	clr	a
	mov	r5,a
	mov	r4,a
	mov	a,r6
	orl	ar0,a
	mov	a,r7
	orl	ar1,a
	mov	a,r5
	orl	ar2,a
	mov	a,r4
	orl	ar3,a
	mov	dptr,#_bitrev32_bits_10000_92
	mov	a,r0
	movx	@dptr,a
	mov	a,r1
	inc	dptr
	movx	@dptr,a
	mov	a,r2
	inc	dptr
	movx	@dptr,a
	mov	a,r3
	inc	dptr
	movx	@dptr,a
;	quantum/bitwise.c:126: return bits;
	mov	dpl, r0
	mov	dph, r1
	mov	b, r2
	mov	a, r3
;	quantum/bitwise.c:127: }
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
	.area CABS    (ABS,CODE)
