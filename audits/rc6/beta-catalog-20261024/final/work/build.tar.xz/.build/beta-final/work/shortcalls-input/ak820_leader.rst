                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_leader
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _get_repeat_key_count
                                     12 	.globl _dynamic_keymap_macro_send
                                     13 	.globl _ADC_START
                                     14 	.globl _S0_R_FIFO
                                     15 	.globl _S0_T_FIFO
                                     16 	.globl _S0_FREE
                                     17 	.globl _S0_IF_BYTE
                                     18 	.globl _S0_IF_FIRST
                                     19 	.globl _S0_IF_OV
                                     20 	.globl _S0_FST_ACT
                                     21 	.globl _CP_RL2
                                     22 	.globl _C_T2
                                     23 	.globl _TR2
                                     24 	.globl _EXEN2
                                     25 	.globl _TCLK
                                     26 	.globl _RCLK
                                     27 	.globl _EXF2
                                     28 	.globl _CAP1F
                                     29 	.globl _TF2
                                     30 	.globl _RI
                                     31 	.globl _TI
                                     32 	.globl _RB8
                                     33 	.globl _TB8
                                     34 	.globl _REN
                                     35 	.globl _SM2
                                     36 	.globl _SM1
                                     37 	.globl _SM0
                                     38 	.globl _IT0
                                     39 	.globl _IE0
                                     40 	.globl _IT1
                                     41 	.globl _IE1
                                     42 	.globl _TR0
                                     43 	.globl _TF0
                                     44 	.globl _TR1
                                     45 	.globl _TF1
                                     46 	.globl _P4_0
                                     47 	.globl _P4_1
                                     48 	.globl _P4_2
                                     49 	.globl _P4_3
                                     50 	.globl _P4_4
                                     51 	.globl _P4_5
                                     52 	.globl _P4_6
                                     53 	.globl _RXD
                                     54 	.globl _TXD
                                     55 	.globl _INT0
                                     56 	.globl _INT1
                                     57 	.globl _T0
                                     58 	.globl _T1
                                     59 	.globl _MOSI1
                                     60 	.globl _MISO1
                                     61 	.globl _SCK1
                                     62 	.globl _P3_0
                                     63 	.globl _P3_1
                                     64 	.globl _P3_2
                                     65 	.globl _P3_3
                                     66 	.globl _P3_4
                                     67 	.globl _P3_5
                                     68 	.globl _P3_6
                                     69 	.globl _P3_7
                                     70 	.globl _CAP1_
                                     71 	.globl _T2_
                                     72 	.globl _CAP2_
                                     73 	.globl _T2EX_
                                     74 	.globl _RXD1
                                     75 	.globl _TXD1
                                     76 	.globl _P2_0
                                     77 	.globl _P2_1
                                     78 	.globl _P2_2
                                     79 	.globl _P2_3
                                     80 	.globl _P2_4
                                     81 	.globl _P2_5
                                     82 	.globl _P2_6
                                     83 	.globl _P2_7
                                     84 	.globl _AIN0
                                     85 	.globl _AIN1
                                     86 	.globl _AIN2
                                     87 	.globl _AIN3
                                     88 	.globl _AIN4
                                     89 	.globl _AIN5
                                     90 	.globl _AIN6
                                     91 	.globl _AIN7
                                     92 	.globl _CAP1
                                     93 	.globl _T2
                                     94 	.globl _CAP2
                                     95 	.globl _T2EX
                                     96 	.globl _INT0_
                                     97 	.globl _SCS
                                     98 	.globl _MOSI
                                     99 	.globl _MISO
                                    100 	.globl _SCK
                                    101 	.globl _RXD1_
                                    102 	.globl _TXD1_
                                    103 	.globl _P1_0
                                    104 	.globl _P1_1
                                    105 	.globl _P1_2
                                    106 	.globl _P1_3
                                    107 	.globl _P1_4
                                    108 	.globl _P1_5
                                    109 	.globl _P1_6
                                    110 	.globl _P1_7
                                    111 	.globl _AIN8
                                    112 	.globl _AIN9
                                    113 	.globl _AIN10
                                    114 	.globl _AIN11
                                    115 	.globl _AIN12
                                    116 	.globl _AIN13
                                    117 	.globl _RXD_
                                    118 	.globl _TXD_
                                    119 	.globl _SCL0
                                    120 	.globl _SDA0
                                    121 	.globl _P0_0
                                    122 	.globl _P0_1
                                    123 	.globl _P0_2
                                    124 	.globl _P0_3
                                    125 	.globl _P0_4
                                    126 	.globl _P0_5
                                    127 	.globl _P0_6
                                    128 	.globl _P0_7
                                    129 	.globl _IE_SPI0
                                    130 	.globl _IE_USB
                                    131 	.globl _IE_ADC
                                    132 	.globl _IE_UART1
                                    133 	.globl _IE_PWM_I2C
                                    134 	.globl _IE_GPIO
                                    135 	.globl _IE_WDOG
                                    136 	.globl _PX0
                                    137 	.globl _PT0
                                    138 	.globl _PX1
                                    139 	.globl _PT1
                                    140 	.globl _PS
                                    141 	.globl _PT2
                                    142 	.globl _PL_FLAG
                                    143 	.globl _PH_FLAG
                                    144 	.globl _EX0
                                    145 	.globl _ET0
                                    146 	.globl _EX1
                                    147 	.globl _ET1
                                    148 	.globl _ES
                                    149 	.globl _ET2
                                    150 	.globl _E_DIS
                                    151 	.globl _EA
                                    152 	.globl _P
                                    153 	.globl _F1
                                    154 	.globl _OV
                                    155 	.globl _RS0
                                    156 	.globl _RS1
                                    157 	.globl _F0
                                    158 	.globl _AC
                                    159 	.globl _CY
                                    160 	.globl _I2CS_INT_ST
                                    161 	.globl _I2CX_INT
                                    162 	.globl _LED_STATUS
                                    163 	.globl _LED_DMA_H
                                    164 	.globl _LED_DMA_L
                                    165 	.globl _LED_DMA
                                    166 	.globl _LED_PWM_OE
                                    167 	.globl _LED_COMMON
                                    168 	.globl _ADC_CHAN
                                    169 	.globl _ADC_DAT_H
                                    170 	.globl _ADC_DAT_L
                                    171 	.globl _ADC_DAT
                                    172 	.globl _ADC_CTRL
                                    173 	.globl _SPI1_CK_SE
                                    174 	.globl _SPI1_CTRL
                                    175 	.globl _SPI1_DATA
                                    176 	.globl _SPI1_STAT
                                    177 	.globl _SIF1
                                    178 	.globl _SBAUD1
                                    179 	.globl _SBUF1
                                    180 	.globl _SCON1
                                    181 	.globl _SPI0_SETUP
                                    182 	.globl _SPI0_CK_SE
                                    183 	.globl _SPI0_CTRL
                                    184 	.globl _SPI0_DATA
                                    185 	.globl _SPI0_STAT
                                    186 	.globl _T2CAP1H
                                    187 	.globl _T2CAP1L
                                    188 	.globl _T2CAP1
                                    189 	.globl _TH2
                                    190 	.globl _TL2
                                    191 	.globl _T2COUNT
                                    192 	.globl _RCAP2H
                                    193 	.globl _RCAP2L
                                    194 	.globl _RCAP2
                                    195 	.globl _T2MOD
                                    196 	.globl _T2CON
                                    197 	.globl _SBUF
                                    198 	.globl _SCON
                                    199 	.globl _TH1
                                    200 	.globl _TH0
                                    201 	.globl _TL1
                                    202 	.globl _TL0
                                    203 	.globl _TMOD
                                    204 	.globl _TCON
                                    205 	.globl _XBUS_AUX
                                    206 	.globl _P7
                                    207 	.globl _P6_DIR
                                    208 	.globl _P6_OUT_PU
                                    209 	.globl _P6_IN
                                    210 	.globl _P5_DIR
                                    211 	.globl _P5_OUT_PU
                                    212 	.globl _P5_IN
                                    213 	.globl _P4_LED_KEY
                                    214 	.globl _P4_DIR_PU
                                    215 	.globl _P4_MOD_OC
                                    216 	.globl _P4
                                    217 	.globl _P3_DIR_PU
                                    218 	.globl _P3_MOD_OC
                                    219 	.globl _P3
                                    220 	.globl _P2_DIR_PU
                                    221 	.globl _P2_MOD_OC
                                    222 	.globl _P2
                                    223 	.globl _P1_DIR_PU
                                    224 	.globl _P1_MOD_OC
                                    225 	.globl _P1
                                    226 	.globl _P0_DIR_PU
                                    227 	.globl _P0_MOD_OC
                                    228 	.globl _P0
                                    229 	.globl _ROM_CTRL
                                    230 	.globl _ROM_DATA_HH
                                    231 	.globl _ROM_DATA_HL
                                    232 	.globl _ROM_DATA_HI
                                    233 	.globl _ROM_ADDR_H
                                    234 	.globl _ROM_ADDR_L
                                    235 	.globl _ROM_ADDR
                                    236 	.globl _GPIO_IE
                                    237 	.globl _IP_EX
                                    238 	.globl _IE_EX
                                    239 	.globl _IP
                                    240 	.globl _IE
                                    241 	.globl _WDOG_COUNT
                                    242 	.globl _RESET_KEEP
                                    243 	.globl _WAKE_CTRL
                                    244 	.globl _CLOCK_CFG
                                    245 	.globl _POWER_CFG
                                    246 	.globl _PCON
                                    247 	.globl _GLOBAL_CFG
                                    248 	.globl _SAFE_MOD
                                    249 	.globl _DPH
                                    250 	.globl _DPL
                                    251 	.globl _SP
                                    252 	.globl _A_INV
                                    253 	.globl _B
                                    254 	.globl _ACC
                                    255 	.globl _PSW
                                    256 	.globl _ak820_leader_cancel
                                    257 	.globl _ak820_leader_task
                                    258 	.globl _ak820_leader_process
                                    259 ;--------------------------------------------------------
                                    260 ; special function registers
                                    261 ;--------------------------------------------------------
                                    262 	.area RSEG    (ABS,DATA)
      000000                        263 	.org 0x0000
                           0000D0   264 _PSW	=	0x00d0
                           0000E0   265 _ACC	=	0x00e0
                           0000F0   266 _B	=	0x00f0
                           0000FD   267 _A_INV	=	0x00fd
                           000081   268 _SP	=	0x0081
                           000082   269 _DPL	=	0x0082
                           000083   270 _DPH	=	0x0083
                           0000A1   271 _SAFE_MOD	=	0x00a1
                           0000B1   272 _GLOBAL_CFG	=	0x00b1
                           000087   273 _PCON	=	0x0087
                           0000BA   274 _POWER_CFG	=	0x00ba
                           0000B9   275 _CLOCK_CFG	=	0x00b9
                           0000A9   276 _WAKE_CTRL	=	0x00a9
                           0000FE   277 _RESET_KEEP	=	0x00fe
                           0000FF   278 _WDOG_COUNT	=	0x00ff
                           0000A8   279 _IE	=	0x00a8
                           0000B8   280 _IP	=	0x00b8
                           0000E8   281 _IE_EX	=	0x00e8
                           0000E9   282 _IP_EX	=	0x00e9
                           0000B2   283 _GPIO_IE	=	0x00b2
                           008584   284 _ROM_ADDR	=	0x8584
                           000084   285 _ROM_ADDR_L	=	0x0084
                           000085   286 _ROM_ADDR_H	=	0x0085
                           008F8E   287 _ROM_DATA_HI	=	0x8f8e
                           00008E   288 _ROM_DATA_HL	=	0x008e
                           00008F   289 _ROM_DATA_HH	=	0x008f
                           000086   290 _ROM_CTRL	=	0x0086
                           000080   291 _P0	=	0x0080
                           0000C4   292 _P0_MOD_OC	=	0x00c4
                           0000C5   293 _P0_DIR_PU	=	0x00c5
                           000090   294 _P1	=	0x0090
                           000092   295 _P1_MOD_OC	=	0x0092
                           000093   296 _P1_DIR_PU	=	0x0093
                           0000A0   297 _P2	=	0x00a0
                           000094   298 _P2_MOD_OC	=	0x0094
                           000095   299 _P2_DIR_PU	=	0x0095
                           0000B0   300 _P3	=	0x00b0
                           000096   301 _P3_MOD_OC	=	0x0096
                           000097   302 _P3_DIR_PU	=	0x0097
                           0000C0   303 _P4	=	0x00c0
                           0000C2   304 _P4_MOD_OC	=	0x00c2
                           0000C3   305 _P4_DIR_PU	=	0x00c3
                           0000C1   306 _P4_LED_KEY	=	0x00c1
                           0000AA   307 _P5_IN	=	0x00aa
                           0000AB   308 _P5_OUT_PU	=	0x00ab
                           0000AC   309 _P5_DIR	=	0x00ac
                           0000AD   310 _P6_IN	=	0x00ad
                           0000AE   311 _P6_OUT_PU	=	0x00ae
                           0000AF   312 _P6_DIR	=	0x00af
                           0000F1   313 _P7	=	0x00f1
                           0000A2   314 _XBUS_AUX	=	0x00a2
                           000088   315 _TCON	=	0x0088
                           000089   316 _TMOD	=	0x0089
                           00008A   317 _TL0	=	0x008a
                           00008B   318 _TL1	=	0x008b
                           00008C   319 _TH0	=	0x008c
                           00008D   320 _TH1	=	0x008d
                           000098   321 _SCON	=	0x0098
                           000099   322 _SBUF	=	0x0099
                           0000C8   323 _T2CON	=	0x00c8
                           0000C9   324 _T2MOD	=	0x00c9
                           00CBCA   325 _RCAP2	=	0xcbca
                           0000CA   326 _RCAP2L	=	0x00ca
                           0000CB   327 _RCAP2H	=	0x00cb
                           00CDCC   328 _T2COUNT	=	0xcdcc
                           0000CC   329 _TL2	=	0x00cc
                           0000CD   330 _TH2	=	0x00cd
                           00CFCE   331 _T2CAP1	=	0xcfce
                           0000CE   332 _T2CAP1L	=	0x00ce
                           0000CF   333 _T2CAP1H	=	0x00cf
                           0000F8   334 _SPI0_STAT	=	0x00f8
                           0000F9   335 _SPI0_DATA	=	0x00f9
                           0000FA   336 _SPI0_CTRL	=	0x00fa
                           0000FB   337 _SPI0_CK_SE	=	0x00fb
                           0000FC   338 _SPI0_SETUP	=	0x00fc
                           0000BC   339 _SCON1	=	0x00bc
                           0000BD   340 _SBUF1	=	0x00bd
                           0000BE   341 _SBAUD1	=	0x00be
                           0000BF   342 _SIF1	=	0x00bf
                           0000B4   343 _SPI1_STAT	=	0x00b4
                           0000B5   344 _SPI1_DATA	=	0x00b5
                           0000B6   345 _SPI1_CTRL	=	0x00b6
                           0000B7   346 _SPI1_CK_SE	=	0x00b7
                           0000F3   347 _ADC_CTRL	=	0x00f3
                           00F5F4   348 _ADC_DAT	=	0xf5f4
                           0000F4   349 _ADC_DAT_L	=	0x00f4
                           0000F5   350 _ADC_DAT_H	=	0x00f5
                           0000F6   351 _ADC_CHAN	=	0x00f6
                           0000A6   352 _LED_COMMON	=	0x00a6
                           0000A7   353 _LED_PWM_OE	=	0x00a7
                           00C7C6   354 _LED_DMA	=	0xc7c6
                           0000C6   355 _LED_DMA_L	=	0x00c6
                           0000C7   356 _LED_DMA_H	=	0x00c7
                           0000F7   357 _LED_STATUS	=	0x00f7
                           0000B3   358 _I2CX_INT	=	0x00b3
                           0000BB   359 _I2CS_INT_ST	=	0x00bb
                                    360 ;--------------------------------------------------------
                                    361 ; special function bits
                                    362 ;--------------------------------------------------------
                                    363 	.area RSEG    (ABS,DATA)
      000000                        364 	.org 0x0000
                           0000D7   365 _CY	=	0x00d7
                           0000D6   366 _AC	=	0x00d6
                           0000D5   367 _F0	=	0x00d5
                           0000D4   368 _RS1	=	0x00d4
                           0000D3   369 _RS0	=	0x00d3
                           0000D2   370 _OV	=	0x00d2
                           0000D1   371 _F1	=	0x00d1
                           0000D0   372 _P	=	0x00d0
                           0000AF   373 _EA	=	0x00af
                           0000AE   374 _E_DIS	=	0x00ae
                           0000AD   375 _ET2	=	0x00ad
                           0000AC   376 _ES	=	0x00ac
                           0000AB   377 _ET1	=	0x00ab
                           0000AA   378 _EX1	=	0x00aa
                           0000A9   379 _ET0	=	0x00a9
                           0000A8   380 _EX0	=	0x00a8
                           0000BF   381 _PH_FLAG	=	0x00bf
                           0000BE   382 _PL_FLAG	=	0x00be
                           0000BD   383 _PT2	=	0x00bd
                           0000BC   384 _PS	=	0x00bc
                           0000BB   385 _PT1	=	0x00bb
                           0000BA   386 _PX1	=	0x00ba
                           0000B9   387 _PT0	=	0x00b9
                           0000B8   388 _PX0	=	0x00b8
                           0000EF   389 _IE_WDOG	=	0x00ef
                           0000EE   390 _IE_GPIO	=	0x00ee
                           0000ED   391 _IE_PWM_I2C	=	0x00ed
                           0000EC   392 _IE_UART1	=	0x00ec
                           0000EB   393 _IE_ADC	=	0x00eb
                           0000E9   394 _IE_USB	=	0x00e9
                           0000E8   395 _IE_SPI0	=	0x00e8
                           000087   396 _P0_7	=	0x0087
                           000086   397 _P0_6	=	0x0086
                           000085   398 _P0_5	=	0x0085
                           000084   399 _P0_4	=	0x0084
                           000083   400 _P0_3	=	0x0083
                           000082   401 _P0_2	=	0x0082
                           000081   402 _P0_1	=	0x0081
                           000080   403 _P0_0	=	0x0080
                           000081   404 _SDA0	=	0x0081
                           000080   405 _SCL0	=	0x0080
                           000083   406 _TXD_	=	0x0083
                           000082   407 _RXD_	=	0x0082
                           000085   408 _AIN13	=	0x0085
                           000084   409 _AIN12	=	0x0084
                           000083   410 _AIN11	=	0x0083
                           000082   411 _AIN10	=	0x0082
                           000081   412 _AIN9	=	0x0081
                           000080   413 _AIN8	=	0x0080
                           000097   414 _P1_7	=	0x0097
                           000096   415 _P1_6	=	0x0096
                           000095   416 _P1_5	=	0x0095
                           000094   417 _P1_4	=	0x0094
                           000093   418 _P1_3	=	0x0093
                           000092   419 _P1_2	=	0x0092
                           000091   420 _P1_1	=	0x0091
                           000090   421 _P1_0	=	0x0090
                           000097   422 _TXD1_	=	0x0097
                           000096   423 _RXD1_	=	0x0096
                           000097   424 _SCK	=	0x0097
                           000096   425 _MISO	=	0x0096
                           000095   426 _MOSI	=	0x0095
                           000094   427 _SCS	=	0x0094
                           000092   428 _INT0_	=	0x0092
                           000091   429 _T2EX	=	0x0091
                           000091   430 _CAP2	=	0x0091
                           000090   431 _T2	=	0x0090
                           000090   432 _CAP1	=	0x0090
                           000097   433 _AIN7	=	0x0097
                           000096   434 _AIN6	=	0x0096
                           000095   435 _AIN5	=	0x0095
                           000094   436 _AIN4	=	0x0094
                           000093   437 _AIN3	=	0x0093
                           000092   438 _AIN2	=	0x0092
                           000091   439 _AIN1	=	0x0091
                           000090   440 _AIN0	=	0x0090
                           0000A7   441 _P2_7	=	0x00a7
                           0000A6   442 _P2_6	=	0x00a6
                           0000A5   443 _P2_5	=	0x00a5
                           0000A4   444 _P2_4	=	0x00a4
                           0000A3   445 _P2_3	=	0x00a3
                           0000A2   446 _P2_2	=	0x00a2
                           0000A1   447 _P2_1	=	0x00a1
                           0000A0   448 _P2_0	=	0x00a0
                           0000A7   449 _TXD1	=	0x00a7
                           0000A6   450 _RXD1	=	0x00a6
                           0000A5   451 _T2EX_	=	0x00a5
                           0000A5   452 _CAP2_	=	0x00a5
                           0000A4   453 _T2_	=	0x00a4
                           0000A4   454 _CAP1_	=	0x00a4
                           0000B7   455 _P3_7	=	0x00b7
                           0000B6   456 _P3_6	=	0x00b6
                           0000B5   457 _P3_5	=	0x00b5
                           0000B4   458 _P3_4	=	0x00b4
                           0000B3   459 _P3_3	=	0x00b3
                           0000B2   460 _P3_2	=	0x00b2
                           0000B1   461 _P3_1	=	0x00b1
                           0000B0   462 _P3_0	=	0x00b0
                           0000B7   463 _SCK1	=	0x00b7
                           0000B6   464 _MISO1	=	0x00b6
                           0000B5   465 _MOSI1	=	0x00b5
                           0000B5   466 _T1	=	0x00b5
                           0000B4   467 _T0	=	0x00b4
                           0000B3   468 _INT1	=	0x00b3
                           0000B2   469 _INT0	=	0x00b2
                           0000B1   470 _TXD	=	0x00b1
                           0000B0   471 _RXD	=	0x00b0
                           0000C6   472 _P4_6	=	0x00c6
                           0000C5   473 _P4_5	=	0x00c5
                           0000C4   474 _P4_4	=	0x00c4
                           0000C3   475 _P4_3	=	0x00c3
                           0000C2   476 _P4_2	=	0x00c2
                           0000C1   477 _P4_1	=	0x00c1
                           0000C0   478 _P4_0	=	0x00c0
                           00008F   479 _TF1	=	0x008f
                           00008E   480 _TR1	=	0x008e
                           00008D   481 _TF0	=	0x008d
                           00008C   482 _TR0	=	0x008c
                           00008B   483 _IE1	=	0x008b
                           00008A   484 _IT1	=	0x008a
                           000089   485 _IE0	=	0x0089
                           000088   486 _IT0	=	0x0088
                           00009F   487 _SM0	=	0x009f
                           00009E   488 _SM1	=	0x009e
                           00009D   489 _SM2	=	0x009d
                           00009C   490 _REN	=	0x009c
                           00009B   491 _TB8	=	0x009b
                           00009A   492 _RB8	=	0x009a
                           000099   493 _TI	=	0x0099
                           000098   494 _RI	=	0x0098
                           0000CF   495 _TF2	=	0x00cf
                           0000CF   496 _CAP1F	=	0x00cf
                           0000CE   497 _EXF2	=	0x00ce
                           0000CD   498 _RCLK	=	0x00cd
                           0000CC   499 _TCLK	=	0x00cc
                           0000CB   500 _EXEN2	=	0x00cb
                           0000CA   501 _TR2	=	0x00ca
                           0000C9   502 _C_T2	=	0x00c9
                           0000C8   503 _CP_RL2	=	0x00c8
                           0000FF   504 _S0_FST_ACT	=	0x00ff
                           0000FE   505 _S0_IF_OV	=	0x00fe
                           0000FD   506 _S0_IF_FIRST	=	0x00fd
                           0000FC   507 _S0_IF_BYTE	=	0x00fc
                           0000FB   508 _S0_FREE	=	0x00fb
                           0000FA   509 _S0_T_FIFO	=	0x00fa
                           0000F8   510 _S0_R_FIFO	=	0x00f8
                           0000F7   511 _ADC_START	=	0x00f7
                                    512 ;--------------------------------------------------------
                                    513 ; overlayable register banks
                                    514 ;--------------------------------------------------------
                                    515 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        516 	.ds 8
                                    517 ;--------------------------------------------------------
                                    518 ; internal ram data
                                    519 ;--------------------------------------------------------
                                    520 	.area DSEG    (DATA)
                                    521 ;--------------------------------------------------------
                                    522 ; overlayable items in internal ram
                                    523 ;--------------------------------------------------------
                                    524 ;--------------------------------------------------------
                                    525 ; indirectly addressable internal ram data
                                    526 ;--------------------------------------------------------
                                    527 	.area ISEG    (DATA)
                                    528 ;--------------------------------------------------------
                                    529 ; absolute internal ram data
                                    530 ;--------------------------------------------------------
                                    531 	.area IABS    (ABS,DATA)
                                    532 	.area IABS    (ABS,DATA)
                                    533 ;--------------------------------------------------------
                                    534 ; bit data
                                    535 ;--------------------------------------------------------
                                    536 	.area BSEG    (BIT)
                                    537 ;--------------------------------------------------------
                                    538 ; paged external ram data
                                    539 ;--------------------------------------------------------
                                    540 	.area PSEG    (PAG,XDATA)
                                    541 ;--------------------------------------------------------
                                    542 ; uninitialized external ram data
                                    543 ;--------------------------------------------------------
                                    544 	.area XSEG    (XDATA)
      00054F                        545 _leader_suppressed:
      00054F                        546 	.ds 16
      00055F                        547 _leader_waiting:
      00055F                        548 	.ds 1
      000560                        549 _leader_running:
      000560                        550 	.ds 1
      000561                        551 _leader_started:
      000561                        552 	.ds 2
      000563                        553 _ak820_leader_task_now_10000_593:
      000563                        554 	.ds 2
      000565                        555 _ak820_leader_task_slot_30000_600:
      000565                        556 	.ds 1
      000566                        557 _ak820_leader_process_record_10000_601:
      000566                        558 	.ds 2
                                    559 ;--------------------------------------------------------
                                    560 ; absolute external ram data
                                    561 ;--------------------------------------------------------
                                    562 	.area XABS    (ABS,XDATA)
                                    563 ;--------------------------------------------------------
                                    564 ; initialized external ram data
                                    565 ;--------------------------------------------------------
                                    566 	.area XISEG   (XDATA)
      000DF8                        567 _leader_pending:
      000DF8                        568 	.ds 1
                                    569 	.area HOME    (CODE)
                                    570 	.area GSINIT0 (CODE)
                                    571 	.area GSINIT1 (CODE)
                                    572 	.area GSINIT2 (CODE)
                                    573 	.area GSINIT3 (CODE)
                                    574 	.area GSINIT4 (CODE)
                                    575 	.area GSINIT5 (CODE)
                                    576 	.area GSINIT  (CODE)
                                    577 	.area GSFINAL (CODE)
                                    578 	.area CSEG    (CODE)
                                    579 ;--------------------------------------------------------
                                    580 ; global & static initialisations
                                    581 ;--------------------------------------------------------
                                    582 	.area HOME    (CODE)
                                    583 	.area GSINIT  (CODE)
                                    584 	.area GSFINAL (CODE)
                                    585 	.area GSINIT  (CODE)
                                    586 ;--------------------------------------------------------
                                    587 ; Home
                                    588 ;--------------------------------------------------------
                                    589 	.area HOME    (CODE)
                                    590 	.area HOME    (CODE)
                                    591 ;--------------------------------------------------------
                                    592 ; code
                                    593 ;--------------------------------------------------------
                                    594 	.area CSEG    (CODE)
                                    595 ;------------------------------------------------------------
                                    596 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    597 ;------------------------------------------------------------
                                    598 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    599 ;------------------------------------------------------------
                                    600 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    601 ;	-----------------------------------------
                           000007   602 	ar7 = 0x07
                           000006   603 	ar6 = 0x06
                           000005   604 	ar5 = 0x05
                           000004   605 	ar4 = 0x04
                           000003   606 	ar3 = 0x03
                           000002   607 	ar2 = 0x02
                           000001   608 	ar1 = 0x01
                           000000   609 	ar0 = 0x00
                                    610 ;	 function ak820_leader_cancel
                                    611 ;	-----------------------------------------
      003EE1                        612 _ak820_leader_cancel:
                                    613 ;	keyboards/ajazz/ak820/ak820_leader.c:18: leader_waiting = false;
      003EE1 90 05 5F         [24]  614 	mov	dptr,#_leader_waiting
      003EE4 E4               [12]  615 	clr	a
      003EE5 F0               [24]  616 	movx	@dptr,a
                                    617 ;	keyboards/ajazz/ak820/ak820_leader.c:19: leader_pending = NONE;
      003EE6 90 0D F8         [24]  618 	mov	dptr,#_leader_pending
      003EE9 14               [12]  619 	dec	a
      003EEA F0               [24]  620 	movx	@dptr,a
                                    621 ;	keyboards/ajazz/ak820/ak820_leader.c:20: for (uint8_t i = 0; i < sizeof(leader_suppressed); ++i) leader_suppressed[i] = 0;
      003EEB 7F 00            [12]  622 	mov	r7,#0x00
      003EED                        623 00103$:
      003EED BF 10 00         [24]  624 	cjne	r7,#0x10,00122$
      003EF0                        625 00122$:
      003EF0 50 0F            [24]  626 	jnc	00105$
      003EF2 EF               [12]  627 	mov	a,r7
      003EF3 24 4F            [12]  628 	add	a, #_leader_suppressed
      003EF5 F5 82            [12]  629 	mov	dpl,a
      003EF7 E4               [12]  630 	clr	a
      003EF8 34 05            [12]  631 	addc	a, #(_leader_suppressed >> 8)
      003EFA F5 83            [12]  632 	mov	dph,a
      003EFC E4               [12]  633 	clr	a
      003EFD F0               [24]  634 	movx	@dptr,a
      003EFE 0F               [12]  635 	inc	r7
      003EFF 80 EC            [24]  636 	sjmp	00103$
      003F01                        637 00105$:
                                    638 ;	keyboards/ajazz/ak820/ak820_leader.c:21: }
      003F01 22               [24]  639 	ret
                                    640 ;------------------------------------------------------------
                                    641 ;Allocation info for local variables in function 'ak820_leader_task'
                                    642 ;------------------------------------------------------------
                                    643 ;now           Allocated with name '_ak820_leader_task_now_10000_593'
                                    644 ;slot          Allocated with name '_ak820_leader_task_slot_30000_600'
                                    645 ;------------------------------------------------------------
                                    646 ;	keyboards/ajazz/ak820/ak820_leader.c:22: void ak820_leader_task(uint16_t now) {
                                    647 ;	-----------------------------------------
                                    648 ;	 function ak820_leader_task
                                    649 ;	-----------------------------------------
      003F02                        650 _ak820_leader_task:
      003F02 AF 83            [24]  651 	mov	r7,dph
      003F04 E5 82            [12]  652 	mov	a,dpl
      003F06 90 05 63         [24]  653 	mov	dptr,#_ak820_leader_task_now_10000_593
      003F09 F0               [24]  654 	movx	@dptr,a
      003F0A EF               [12]  655 	mov	a,r7
      003F0B A3               [24]  656 	inc	dptr
      003F0C F0               [24]  657 	movx	@dptr,a
                                    658 ;	keyboards/ajazz/ak820/ak820_leader.c:23: if (vial_unlock_in_progress) { ak820_leader_cancel(); return; }
      003F0D 90 0E 6A         [24]  659 	mov	dptr,#_vial_unlock_in_progress
      003F10 E0               [24]  660 	movx	a,@dptr
      003F11 60 03            [24]  661 	jz	00102$
      003F13 02 3E E1         [24]  662 	ljmp	_ak820_leader_cancel
      003F16                        663 00102$:
                                    664 ;	keyboards/ajazz/ak820/ak820_leader.c:24: if (leader_running) return;
      003F16 90 05 60         [24]  665 	mov	dptr,#_leader_running
      003F19 E0               [24]  666 	movx	a,@dptr
      003F1A 60 01            [24]  667 	jz	00104$
      003F1C 22               [24]  668 	ret
      003F1D                        669 00104$:
                                    670 ;	keyboards/ajazz/ak820/ak820_leader.c:25: if (leader_waiting && (uint16_t)(now - leader_started) >= 300) leader_waiting = false;
      003F1D 90 05 5F         [24]  671 	mov	dptr,#_leader_waiting
      003F20 E0               [24]  672 	movx	a,@dptr
      003F21 60 25            [24]  673 	jz	00106$
      003F23 90 05 61         [24]  674 	mov	dptr,#_leader_started
      003F26 E0               [24]  675 	movx	a,@dptr
      003F27 FE               [12]  676 	mov	r6,a
      003F28 A3               [24]  677 	inc	dptr
      003F29 E0               [24]  678 	movx	a,@dptr
      003F2A FF               [12]  679 	mov	r7,a
      003F2B 90 05 63         [24]  680 	mov	dptr,#_ak820_leader_task_now_10000_593
      003F2E E0               [24]  681 	movx	a,@dptr
      003F2F FC               [12]  682 	mov	r4,a
      003F30 A3               [24]  683 	inc	dptr
      003F31 E0               [24]  684 	movx	a,@dptr
      003F32 FD               [12]  685 	mov	r5,a
      003F33 EC               [12]  686 	mov	a,r4
      003F34 C3               [12]  687 	clr	c
      003F35 9E               [12]  688 	subb	a,r6
      003F36 FE               [12]  689 	mov	r6,a
      003F37 ED               [12]  690 	mov	a,r5
      003F38 9F               [12]  691 	subb	a,r7
      003F39 FF               [12]  692 	mov	r7,a
      003F3A C3               [12]  693 	clr	c
      003F3B EE               [12]  694 	mov	a,r6
      003F3C 94 2C            [12]  695 	subb	a,#0x2c
      003F3E EF               [12]  696 	mov	a,r7
      003F3F 94 01            [12]  697 	subb	a,#0x01
      003F41 40 05            [24]  698 	jc	00106$
      003F43 90 05 5F         [24]  699 	mov	dptr,#_leader_waiting
      003F46 E4               [12]  700 	clr	a
      003F47 F0               [24]  701 	movx	@dptr,a
      003F48                        702 00106$:
                                    703 ;	keyboards/ajazz/ak820/ak820_leader.c:26: if (leader_pending != NONE) {
      003F48 90 0D F8         [24]  704 	mov	dptr,#_leader_pending
      003F4B E0               [24]  705 	movx	a,@dptr
      003F4C FF               [12]  706 	mov	r7,a
      003F4D BF FF 01         [24]  707 	cjne	r7,#0xff,00151$
      003F50 22               [24]  708 	ret
      003F51                        709 00151$:
                                    710 ;	keyboards/ajazz/ak820/ak820_leader.c:27: uint8_t slot = leader_pending;
      003F51 90 05 65         [24]  711 	mov	dptr,#_ak820_leader_task_slot_30000_600
      003F54 EF               [12]  712 	mov	a,r7
      003F55 F0               [24]  713 	movx	@dptr,a
                                    714 ;	keyboards/ajazz/ak820/ak820_leader.c:28: leader_pending = NONE; /* Interpreter-generated events cannot recurse. */
      003F56 90 0D F8         [24]  715 	mov	dptr,#_leader_pending
      003F59 74 FF            [12]  716 	mov	a,#0xff
      003F5B F0               [24]  717 	movx	@dptr,a
                                    718 ;	keyboards/ajazz/ak820/ak820_leader.c:29: leader_running = true;
      003F5C 90 05 60         [24]  719 	mov	dptr,#_leader_running
      003F5F 74 01            [12]  720 	mov	a,#0x01
      003F61 F0               [24]  721 	movx	@dptr,a
                                    722 ;	keyboards/ajazz/ak820/ak820_leader.c:30: dynamic_keymap_macro_send(slot);
      003F62 90 05 65         [24]  723 	mov	dptr,#_ak820_leader_task_slot_30000_600
      003F65 E0               [24]  724 	movx	a,@dptr
      003F66 F5 82            [12]  725 	mov	dpl,a
      003F68 12 92 AC         [24]  726 	lcall	_dynamic_keymap_macro_send
                                    727 ;	keyboards/ajazz/ak820/ak820_leader.c:31: leader_running = false;
      003F6B 90 05 60         [24]  728 	mov	dptr,#_leader_running
      003F6E E4               [12]  729 	clr	a
      003F6F F0               [24]  730 	movx	@dptr,a
                                    731 ;	keyboards/ajazz/ak820/ak820_leader.c:33: }
      003F70 22               [24]  732 	ret
                                    733 ;------------------------------------------------------------
                                    734 ;Allocation info for local variables in function 'ak820_leader_process'
                                    735 ;------------------------------------------------------------
                                    736 ;record        Allocated with name '_ak820_leader_process_record_10000_601'
                                    737 ;id            Allocated with name '_ak820_leader_process_id_10000_602'
                                    738 ;mask          Allocated with name '_ak820_leader_process_mask_10000_602'
                                    739 ;index         Allocated with name '_ak820_leader_process_index_10000_602'
                                    740 ;code          Allocated with name '_ak820_leader_process_code_10000_602'
                                    741 ;------------------------------------------------------------
                                    742 ;	keyboards/ajazz/ak820/ak820_leader.c:34: bool ak820_leader_process(keyrecord_t AK820_STATE_MEM *record) {
                                    743 ;	-----------------------------------------
                                    744 ;	 function ak820_leader_process
                                    745 ;	-----------------------------------------
      003F71                        746 _ak820_leader_process:
      003F71 AF 83            [24]  747 	mov	r7,dph
      003F73 E5 82            [12]  748 	mov	a,dpl
      003F75 90 05 66         [24]  749 	mov	dptr,#_ak820_leader_process_record_10000_601
      003F78 F0               [24]  750 	movx	@dptr,a
      003F79 EF               [12]  751 	mov	a,r7
      003F7A A3               [24]  752 	inc	dptr
      003F7B F0               [24]  753 	movx	@dptr,a
                                    754 ;	keyboards/ajazz/ak820/ak820_leader.c:37: if (record->event.type != KEY_EVENT || record->event.key.row >= MATRIX_ROWS ||
      003F7C 90 05 66         [24]  755 	mov	dptr,#_ak820_leader_process_record_10000_601
      003F7F E0               [24]  756 	movx	a,@dptr
      003F80 FE               [12]  757 	mov	r6,a
      003F81 A3               [24]  758 	inc	dptr
      003F82 E0               [24]  759 	movx	a,@dptr
      003F83 FF               [12]  760 	mov	r7,a
      003F84 8E 82            [24]  761 	mov	dpl,r6
      003F86 8F 83            [24]  762 	mov	dph,r7
      003F88 A3               [24]  763 	inc	dptr
      003F89 A3               [24]  764 	inc	dptr
      003F8A A3               [24]  765 	inc	dptr
      003F8B A3               [24]  766 	inc	dptr
      003F8C E0               [24]  767 	movx	a,@dptr
      003F8D FD               [12]  768 	mov	r5,a
      003F8E BD 01 34         [24]  769 	cjne	r5,#0x01,00101$
      003F91 74 01            [12]  770 	mov	a,#0x01
      003F93 2E               [12]  771 	add	a, r6
      003F94 FC               [12]  772 	mov	r4,a
      003F95 E4               [12]  773 	clr	a
      003F96 3F               [12]  774 	addc	a, r7
      003F97 FD               [12]  775 	mov	r5,a
      003F98 8C 82            [24]  776 	mov	dpl,r4
      003F9A 8D 83            [24]  777 	mov	dph,r5
      003F9C E0               [24]  778 	movx	a,@dptr
      003F9D FB               [12]  779 	mov	r3,a
      003F9E BB 10 00         [24]  780 	cjne	r3,#0x10,00249$
      003FA1                        781 00249$:
      003FA1 50 22            [24]  782 	jnc	00101$
                                    783 ;	keyboards/ajazz/ak820/ak820_leader.c:38: record->event.key.col >= MATRIX_COLS || leader_running || ak820_macro_primitive || get_repeat_key_count()) return true;
      003FA3 8E 02            [24]  784 	mov	ar2,r6
      003FA5 8F 03            [24]  785 	mov	ar3,r7
      003FA7 8A 82            [24]  786 	mov	dpl,r2
      003FA9 8B 83            [24]  787 	mov	dph,r3
      003FAB E0               [24]  788 	movx	a,@dptr
      003FAC F9               [12]  789 	mov	r1,a
      003FAD B9 08 00         [24]  790 	cjne	r1,#0x08,00251$
      003FB0                        791 00251$:
      003FB0 50 13            [24]  792 	jnc	00101$
      003FB2 90 05 60         [24]  793 	mov	dptr,#_leader_running
      003FB5 E0               [24]  794 	movx	a,@dptr
      003FB6 70 0D            [24]  795 	jnz	00101$
      003FB8 90 09 F4         [24]  796 	mov	dptr,#_ak820_macro_primitive
      003FBB E0               [24]  797 	movx	a,@dptr
      003FBC 70 07            [24]  798 	jnz	00101$
      003FBE 12 A8 79         [24]  799 	lcall	_get_repeat_key_count
      003FC1 E5 82            [12]  800 	mov	a, dpl
      003FC3 60 04            [24]  801 	jz	00102$
      003FC5                        802 00101$:
      003FC5 75 82 01         [24]  803 	mov	dpl, #0x01
      003FC8 22               [24]  804 	ret
      003FC9                        805 00102$:
                                    806 ;	keyboards/ajazz/ak820/ak820_leader.c:39: id = record->event.key.row * MATRIX_COLS + record->event.key.col;
      003FC9 8C 82            [24]  807 	mov	dpl,r4
      003FCB 8D 83            [24]  808 	mov	dph,r5
      003FCD E0               [24]  809 	movx	a,@dptr
      003FCE C4               [12]  810 	swap	a
      003FCF 03               [12]  811 	rr	a
      003FD0 54 F8            [12]  812 	anl	a,#0xf8
      003FD2 FC               [12]  813 	mov	r4,a
      003FD3 8A 82            [24]  814 	mov	dpl,r2
      003FD5 8B 83            [24]  815 	mov	dph,r3
      003FD7 E0               [24]  816 	movx	a,@dptr
      003FD8 2C               [12]  817 	add	a, r4
                                    818 ;	keyboards/ajazz/ak820/ak820_leader.c:40: index = id >> 3;
      003FD9 FC               [12]  819 	mov	r4,a
      003FDA C4               [12]  820 	swap	a
      003FDB 23               [12]  821 	rl	a
      003FDC 54 1F            [12]  822 	anl	a,#0x1f
      003FDE FD               [12]  823 	mov	r5,a
                                    824 ;	keyboards/ajazz/ak820/ak820_leader.c:41: mask = 1u << (id & 7);
      003FDF 74 07            [12]  825 	mov	a,#0x07
      003FE1 5C               [12]  826 	anl	a,r4
      003FE2 F5 F0            [12]  827 	mov	b,a
      003FE4 05 F0            [12]  828 	inc	b
      003FE6 74 01            [12]  829 	mov	a,#0x01
      003FE8 80 02            [24]  830 	sjmp	00257$
      003FEA                        831 00256$:
      003FEA 25 E0            [12]  832 	add	a,acc
      003FEC                        833 00257$:
      003FEC D5 F0 FB         [24]  834 	djnz	b,00256$
      003FEF FC               [12]  835 	mov	r4,a
                                    836 ;	keyboards/ajazz/ak820/ak820_leader.c:42: if (leader_suppressed[index] & mask) {
      003FF0 ED               [12]  837 	mov	a,r5
      003FF1 24 4F            [12]  838 	add	a, #_leader_suppressed
      003FF3 FB               [12]  839 	mov	r3,a
      003FF4 E4               [12]  840 	clr	a
      003FF5 34 05            [12]  841 	addc	a, #(_leader_suppressed >> 8)
      003FF7 FD               [12]  842 	mov	r5,a
      003FF8 8B 82            [24]  843 	mov	dpl,r3
      003FFA 8D 83            [24]  844 	mov	dph,r5
      003FFC E0               [24]  845 	movx	a,@dptr
      003FFD FA               [12]  846 	mov	r2,a
      003FFE EC               [12]  847 	mov	a,r4
      003FFF 5A               [12]  848 	anl	a,r2
      004000 60 1D            [24]  849 	jz	00111$
                                    850 ;	keyboards/ajazz/ak820/ak820_leader.c:43: if (!record->event.pressed) leader_suppressed[index] &= ~mask;
      004002 74 05            [12]  851 	mov	a,#0x05
      004004 2E               [12]  852 	add	a, r6
      004005 F8               [12]  853 	mov	r0,a
      004006 E4               [12]  854 	clr	a
      004007 3F               [12]  855 	addc	a, r7
      004008 F9               [12]  856 	mov	r1,a
      004009 88 82            [24]  857 	mov	dpl,r0
      00400B 89 83            [24]  858 	mov	dph,r1
      00400D E0               [24]  859 	movx	a,@dptr
      00400E 70 0B            [24]  860 	jnz	00109$
      004010 74 FF            [12]  861 	mov	a,#0xff
      004012 6C               [12]  862 	xrl	a,r4
      004013 52 02            [12]  863 	anl	ar2,a
      004015 8B 82            [24]  864 	mov	dpl,r3
      004017 8D 83            [24]  865 	mov	dph,r5
      004019 EA               [12]  866 	mov	a,r2
      00401A F0               [24]  867 	movx	@dptr,a
      00401B                        868 00109$:
                                    869 ;	keyboards/ajazz/ak820/ak820_leader.c:44: return false;
      00401B 75 82 00         [24]  870 	mov	dpl, #0x00
      00401E 22               [24]  871 	ret
      00401F                        872 00111$:
                                    873 ;	keyboards/ajazz/ak820/ak820_leader.c:46: if (!record->event.pressed) return true; /* Preheld release keeps its owner. */
      00401F 74 05            [12]  874 	mov	a,#0x05
      004021 2E               [12]  875 	add	a, r6
      004022 F9               [12]  876 	mov	r1,a
      004023 E4               [12]  877 	clr	a
      004024 3F               [12]  878 	addc	a, r7
      004025 FA               [12]  879 	mov	r2,a
      004026 89 82            [24]  880 	mov	dpl,r1
      004028 8A 83            [24]  881 	mov	dph,r2
      00402A E0               [24]  882 	movx	a,@dptr
      00402B 70 04            [24]  883 	jnz	00113$
      00402D 75 82 01         [24]  884 	mov	dpl, #0x01
      004030 22               [24]  885 	ret
      004031                        886 00113$:
                                    887 ;	keyboards/ajazz/ak820/ak820_leader.c:47: if (record->keycode == QK_LEAD) {
      004031 C0 04            [24]  888 	push	ar4
      004033 74 07            [12]  889 	mov	a,#0x07
      004035 2E               [12]  890 	add	a, r6
      004036 F9               [12]  891 	mov	r1,a
      004037 E4               [12]  892 	clr	a
      004038 3F               [12]  893 	addc	a, r7
      004039 FA               [12]  894 	mov	r2,a
      00403A 89 82            [24]  895 	mov	dpl,r1
      00403C 8A 83            [24]  896 	mov	dph,r2
      00403E E0               [24]  897 	movx	a,@dptr
      00403F F8               [12]  898 	mov	r0,a
      004040 A3               [24]  899 	inc	dptr
      004041 E0               [24]  900 	movx	a,@dptr
      004042 FC               [12]  901 	mov	r4,a
      004043 B8 58 05         [24]  902 	cjne	r0,#0x58,00261$
      004046 BC 7C 02         [24]  903 	cjne	r4,#0x7c,00261$
      004049 80 04            [24]  904 	sjmp	00262$
      00404B                        905 00261$:
      00404B D0 04            [24]  906 	pop	ar4
      00404D 80 2F            [24]  907 	sjmp	00131$
      00404F                        908 00262$:
      00404F D0 04            [24]  909 	pop	ar4
                                    910 ;	keyboards/ajazz/ak820/ak820_leader.c:48: if (leader_pending == NONE) {
      004051 90 0D F8         [24]  911 	mov	dptr,#_leader_pending
      004054 E0               [24]  912 	movx	a,@dptr
      004055 F8               [12]  913 	mov	r0,a
      004056 B8 FF 02         [24]  914 	cjne	r0,#0xff,00263$
      004059 80 03            [24]  915 	sjmp	00264$
      00405B                        916 00263$:
      00405B 02 41 06         [24]  917 	ljmp	00132$
      00405E                        918 00264$:
                                    919 ;	keyboards/ajazz/ak820/ak820_leader.c:49: leader_waiting = true;
      00405E C0 04            [24]  920 	push	ar4
      004060 90 05 5F         [24]  921 	mov	dptr,#_leader_waiting
      004063 74 01            [12]  922 	mov	a,#0x01
      004065 F0               [24]  923 	movx	@dptr,a
                                    924 ;	keyboards/ajazz/ak820/ak820_leader.c:50: leader_started = record->event.time;
      004066 8E 82            [24]  925 	mov	dpl,r6
      004068 8F 83            [24]  926 	mov	dph,r7
      00406A A3               [24]  927 	inc	dptr
      00406B A3               [24]  928 	inc	dptr
      00406C E0               [24]  929 	movx	a,@dptr
      00406D F8               [12]  930 	mov	r0,a
      00406E A3               [24]  931 	inc	dptr
      00406F E0               [24]  932 	movx	a,@dptr
      004070 FC               [12]  933 	mov	r4,a
      004071 90 05 61         [24]  934 	mov	dptr,#_leader_started
      004074 E8               [12]  935 	mov	a,r0
      004075 F0               [24]  936 	movx	@dptr,a
      004076 EC               [12]  937 	mov	a,r4
      004077 A3               [24]  938 	inc	dptr
      004078 F0               [24]  939 	movx	@dptr,a
      004079 D0 04            [24]  940 	pop	ar4
      00407B 02 41 06         [24]  941 	ljmp	00132$
      00407E                        942 00131$:
                                    943 ;	keyboards/ajazz/ak820/ak820_leader.c:53: if (!leader_waiting) return true;
      00407E 90 05 5F         [24]  944 	mov	dptr,#_leader_waiting
      004081 E0               [24]  945 	movx	a,@dptr
      004082 70 04            [24]  946 	jnz	00117$
      004084 75 82 01         [24]  947 	mov	dpl, #0x01
      004087 22               [24]  948 	ret
      004088                        949 00117$:
                                    950 ;	keyboards/ajazz/ak820/ak820_leader.c:54: leader_waiting = false;
      004088 C0 01            [24]  951 	push	ar1
      00408A C0 02            [24]  952 	push	ar2
      00408C 90 05 5F         [24]  953 	mov	dptr,#_leader_waiting
      00408F E4               [12]  954 	clr	a
      004090 F0               [24]  955 	movx	@dptr,a
                                    956 ;	keyboards/ajazz/ak820/ak820_leader.c:55: if ((uint16_t)(record->event.time - leader_started) >= 300) return true;
      004091 8E 82            [24]  957 	mov	dpl,r6
      004093 8F 83            [24]  958 	mov	dph,r7
      004095 A3               [24]  959 	inc	dptr
      004096 A3               [24]  960 	inc	dptr
      004097 E0               [24]  961 	movx	a,@dptr
      004098 FE               [12]  962 	mov	r6,a
      004099 A3               [24]  963 	inc	dptr
      00409A E0               [24]  964 	movx	a,@dptr
      00409B FF               [12]  965 	mov	r7,a
      00409C 90 05 61         [24]  966 	mov	dptr,#_leader_started
      00409F E0               [24]  967 	movx	a,@dptr
      0040A0 F8               [12]  968 	mov	r0,a
      0040A1 A3               [24]  969 	inc	dptr
      0040A2 E0               [24]  970 	movx	a,@dptr
      0040A3 FA               [12]  971 	mov	r2,a
      0040A4 EE               [12]  972 	mov	a,r6
      0040A5 C3               [12]  973 	clr	c
      0040A6 98               [12]  974 	subb	a,r0
      0040A7 FE               [12]  975 	mov	r6,a
      0040A8 EF               [12]  976 	mov	a,r7
      0040A9 9A               [12]  977 	subb	a,r2
      0040AA FF               [12]  978 	mov	r7,a
      0040AB C3               [12]  979 	clr	c
      0040AC EE               [12]  980 	mov	a,r6
      0040AD 94 2C            [12]  981 	subb	a,#0x2c
      0040AF EF               [12]  982 	mov	a,r7
      0040B0 94 01            [12]  983 	subb	a,#0x01
      0040B2 D0 02            [24]  984 	pop	ar2
      0040B4 D0 01            [24]  985 	pop	ar1
      0040B6 40 04            [24]  986 	jc	00119$
      0040B8 75 82 01         [24]  987 	mov	dpl, #0x01
      0040BB 22               [24]  988 	ret
      0040BC                        989 00119$:
                                    990 ;	keyboards/ajazz/ak820/ak820_leader.c:56: code = record->keycode;
      0040BC 89 82            [24]  991 	mov	dpl,r1
      0040BE 8A 83            [24]  992 	mov	dph,r2
      0040C0 E0               [24]  993 	movx	a,@dptr
      0040C1 FE               [12]  994 	mov	r6,a
      0040C2 A3               [24]  995 	inc	dptr
      0040C3 E0               [24]  996 	movx	a,@dptr
      0040C4 FF               [12]  997 	mov	r7,a
                                    998 ;	keyboards/ajazz/ak820/ak820_leader.c:58: if (code < KC_A || code > KC_EXSEL) return true;
      0040C5 8E 01            [24]  999 	mov	ar1,r6
      0040C7 8F 02            [24] 1000 	mov	ar2,r7
      0040C9 C3               [12] 1001 	clr	c
      0040CA E9               [12] 1002 	mov	a,r1
      0040CB 94 04            [12] 1003 	subb	a,#0x04
      0040CD EA               [12] 1004 	mov	a,r2
      0040CE 94 00            [12] 1005 	subb	a,#0x00
      0040D0 40 07            [24] 1006 	jc	00120$
      0040D2 74 A4            [12] 1007 	mov	a,#0xa4
      0040D4 99               [12] 1008 	subb	a,r1
      0040D5 E4               [12] 1009 	clr	a
      0040D6 9A               [12] 1010 	subb	a,r2
      0040D7 50 04            [24] 1011 	jnc	00121$
                                   1012 ;	free result
      0040D9                       1013 00120$:
      0040D9 75 82 01         [24] 1014 	mov	dpl, #0x01
      0040DC 22               [24] 1015 	ret
      0040DD                       1016 00121$:
                                   1017 ;	keyboards/ajazz/ak820/ak820_leader.c:59: if ((uint8_t)code >= KC_1 && (uint8_t)code <= KC_0) leader_pending = (uint8_t)code - KC_1;
      0040DD BE 1E 00         [24] 1018 	cjne	r6,#0x1e,00269$
      0040E0                       1019 00269$:
      0040E0 40 10            [24] 1020 	jc	00127$
      0040E2 EE               [12] 1021 	mov	a,r6
      0040E3 24 D8            [12] 1022 	add	a,#0xff - 0x27
      0040E5 40 0B            [24] 1023 	jc	00127$
                                   1024 ;	free result
      0040E7 8E 07            [24] 1025 	mov	ar7,r6
      0040E9 EF               [12] 1026 	mov	a,r7
      0040EA 24 E2            [12] 1027 	add	a,#0xe2
      0040EC 90 0D F8         [24] 1028 	mov	dptr,#_leader_pending
      0040EF F0               [24] 1029 	movx	@dptr,a
      0040F0 80 14            [24] 1030 	sjmp	00132$
      0040F2                       1031 00127$:
                                   1032 ;	keyboards/ajazz/ak820/ak820_leader.c:60: else if ((uint8_t)code <= KC_F) leader_pending = (uint8_t)code - KC_A + 10;
      0040F2 EE               [12] 1033 	mov	a,r6
      0040F3 24 F6            [12] 1034 	add	a,#0xff - 0x09
      0040F5 40 09            [24] 1035 	jc	00124$
                                   1036 ;	free result
      0040F7 90 0D F8         [24] 1037 	mov	dptr,#_leader_pending
      0040FA 74 06            [12] 1038 	mov	a,#0x06
      0040FC 2E               [12] 1039 	add	a, r6
      0040FD F0               [24] 1040 	movx	@dptr,a
      0040FE 80 06            [24] 1041 	sjmp	00132$
      004100                       1042 00124$:
                                   1043 ;	keyboards/ajazz/ak820/ak820_leader.c:61: else leader_pending = NONE; /* Other basic keys are consumed without output. */
      004100 90 0D F8         [24] 1044 	mov	dptr,#_leader_pending
      004103 74 FF            [12] 1045 	mov	a,#0xff
      004105 F0               [24] 1046 	movx	@dptr,a
      004106                       1047 00132$:
                                   1048 ;	keyboards/ajazz/ak820/ak820_leader.c:63: leader_suppressed[index] |= mask;
      004106 8B 82            [24] 1049 	mov	dpl,r3
      004108 8D 83            [24] 1050 	mov	dph,r5
      00410A E0               [24] 1051 	movx	a,@dptr
      00410B 42 04            [12] 1052 	orl	ar4,a
      00410D 8B 82            [24] 1053 	mov	dpl,r3
      00410F 8D 83            [24] 1054 	mov	dph,r5
      004111 EC               [12] 1055 	mov	a,r4
      004112 F0               [24] 1056 	movx	@dptr,a
                                   1057 ;	keyboards/ajazz/ak820/ak820_leader.c:64: return false;
      004113 75 82 00         [24] 1058 	mov	dpl, #0x00
                                   1059 ;	keyboards/ajazz/ak820/ak820_leader.c:65: }
      004116 22               [24] 1060 	ret
                                   1061 	.area CSEG    (CODE)
                                   1062 	.area CONST   (CODE)
                                   1063 	.area XINIT   (CODE)
      00C743                       1064 __xinit__leader_pending:
      00C743 FF                    1065 	.db #0xff	; 255
                                   1066 	.area CABS    (ABS,CODE)
