                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module usb_ak820
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_nvm_end
                                     12 	.globl _ak820_nvm_flush
                                     13 	.globl _ak820_nvm_begin
                                     14 	.globl _ak820_nvm_ok
                                     15 	.globl _ak820_os_indicator_get
                                     16 	.globl _ak820_os_indicator_set
                                     17 	.globl _ak820_nvm_diagnostic
                                     18 	.globl _mDelaymS
                                     19 	.globl _mDelayuS
                                     20 	.globl _raw_hid_receive
                                     21 	.globl _ADC_START
                                     22 	.globl _S0_R_FIFO
                                     23 	.globl _S0_T_FIFO
                                     24 	.globl _S0_FREE
                                     25 	.globl _S0_IF_BYTE
                                     26 	.globl _S0_IF_FIRST
                                     27 	.globl _S0_IF_OV
                                     28 	.globl _S0_FST_ACT
                                     29 	.globl _CP_RL2
                                     30 	.globl _C_T2
                                     31 	.globl _TR2
                                     32 	.globl _EXEN2
                                     33 	.globl _TCLK
                                     34 	.globl _RCLK
                                     35 	.globl _EXF2
                                     36 	.globl _CAP1F
                                     37 	.globl _TF2
                                     38 	.globl _RI
                                     39 	.globl _TI
                                     40 	.globl _RB8
                                     41 	.globl _TB8
                                     42 	.globl _REN
                                     43 	.globl _SM2
                                     44 	.globl _SM1
                                     45 	.globl _SM0
                                     46 	.globl _IT0
                                     47 	.globl _IE0
                                     48 	.globl _IT1
                                     49 	.globl _IE1
                                     50 	.globl _TR0
                                     51 	.globl _TF0
                                     52 	.globl _TR1
                                     53 	.globl _TF1
                                     54 	.globl _P4_0
                                     55 	.globl _P4_1
                                     56 	.globl _P4_2
                                     57 	.globl _P4_3
                                     58 	.globl _P4_4
                                     59 	.globl _P4_5
                                     60 	.globl _P4_6
                                     61 	.globl _RXD
                                     62 	.globl _TXD
                                     63 	.globl _INT0
                                     64 	.globl _INT1
                                     65 	.globl _T0
                                     66 	.globl _T1
                                     67 	.globl _MOSI1
                                     68 	.globl _MISO1
                                     69 	.globl _SCK1
                                     70 	.globl _P3_0
                                     71 	.globl _P3_1
                                     72 	.globl _P3_2
                                     73 	.globl _P3_3
                                     74 	.globl _P3_4
                                     75 	.globl _P3_5
                                     76 	.globl _P3_6
                                     77 	.globl _P3_7
                                     78 	.globl _CAP1_
                                     79 	.globl _T2_
                                     80 	.globl _CAP2_
                                     81 	.globl _T2EX_
                                     82 	.globl _RXD1
                                     83 	.globl _TXD1
                                     84 	.globl _P2_0
                                     85 	.globl _P2_1
                                     86 	.globl _P2_2
                                     87 	.globl _P2_3
                                     88 	.globl _P2_4
                                     89 	.globl _P2_5
                                     90 	.globl _P2_6
                                     91 	.globl _P2_7
                                     92 	.globl _AIN0
                                     93 	.globl _AIN1
                                     94 	.globl _AIN2
                                     95 	.globl _AIN3
                                     96 	.globl _AIN4
                                     97 	.globl _AIN5
                                     98 	.globl _AIN6
                                     99 	.globl _AIN7
                                    100 	.globl _CAP1
                                    101 	.globl _T2
                                    102 	.globl _CAP2
                                    103 	.globl _T2EX
                                    104 	.globl _INT0_
                                    105 	.globl _SCS
                                    106 	.globl _MOSI
                                    107 	.globl _MISO
                                    108 	.globl _SCK
                                    109 	.globl _RXD1_
                                    110 	.globl _TXD1_
                                    111 	.globl _P1_0
                                    112 	.globl _P1_1
                                    113 	.globl _P1_2
                                    114 	.globl _P1_3
                                    115 	.globl _P1_4
                                    116 	.globl _P1_5
                                    117 	.globl _P1_6
                                    118 	.globl _P1_7
                                    119 	.globl _AIN8
                                    120 	.globl _AIN9
                                    121 	.globl _AIN10
                                    122 	.globl _AIN11
                                    123 	.globl _AIN12
                                    124 	.globl _AIN13
                                    125 	.globl _RXD_
                                    126 	.globl _TXD_
                                    127 	.globl _SCL0
                                    128 	.globl _SDA0
                                    129 	.globl _P0_0
                                    130 	.globl _P0_1
                                    131 	.globl _P0_2
                                    132 	.globl _P0_3
                                    133 	.globl _P0_4
                                    134 	.globl _P0_5
                                    135 	.globl _P0_6
                                    136 	.globl _P0_7
                                    137 	.globl _IE_SPI0
                                    138 	.globl _IE_USB
                                    139 	.globl _IE_ADC
                                    140 	.globl _IE_UART1
                                    141 	.globl _IE_PWM_I2C
                                    142 	.globl _IE_GPIO
                                    143 	.globl _IE_WDOG
                                    144 	.globl _PX0
                                    145 	.globl _PT0
                                    146 	.globl _PX1
                                    147 	.globl _PT1
                                    148 	.globl _PS
                                    149 	.globl _PT2
                                    150 	.globl _PL_FLAG
                                    151 	.globl _PH_FLAG
                                    152 	.globl _EX0
                                    153 	.globl _ET0
                                    154 	.globl _EX1
                                    155 	.globl _ET1
                                    156 	.globl _ES
                                    157 	.globl _ET2
                                    158 	.globl _E_DIS
                                    159 	.globl _EA
                                    160 	.globl _P
                                    161 	.globl _F1
                                    162 	.globl _OV
                                    163 	.globl _RS0
                                    164 	.globl _RS1
                                    165 	.globl _F0
                                    166 	.globl _AC
                                    167 	.globl _CY
                                    168 	.globl _I2CS_INT_ST
                                    169 	.globl _I2CX_INT
                                    170 	.globl _LED_STATUS
                                    171 	.globl _LED_DMA_H
                                    172 	.globl _LED_DMA_L
                                    173 	.globl _LED_DMA
                                    174 	.globl _LED_PWM_OE
                                    175 	.globl _LED_COMMON
                                    176 	.globl _ADC_CHAN
                                    177 	.globl _ADC_DAT_H
                                    178 	.globl _ADC_DAT_L
                                    179 	.globl _ADC_DAT
                                    180 	.globl _ADC_CTRL
                                    181 	.globl _SPI1_CK_SE
                                    182 	.globl _SPI1_CTRL
                                    183 	.globl _SPI1_DATA
                                    184 	.globl _SPI1_STAT
                                    185 	.globl _SIF1
                                    186 	.globl _SBAUD1
                                    187 	.globl _SBUF1
                                    188 	.globl _SCON1
                                    189 	.globl _SPI0_SETUP
                                    190 	.globl _SPI0_CK_SE
                                    191 	.globl _SPI0_CTRL
                                    192 	.globl _SPI0_DATA
                                    193 	.globl _SPI0_STAT
                                    194 	.globl _T2CAP1H
                                    195 	.globl _T2CAP1L
                                    196 	.globl _T2CAP1
                                    197 	.globl _TH2
                                    198 	.globl _TL2
                                    199 	.globl _T2COUNT
                                    200 	.globl _RCAP2H
                                    201 	.globl _RCAP2L
                                    202 	.globl _RCAP2
                                    203 	.globl _T2MOD
                                    204 	.globl _T2CON
                                    205 	.globl _SBUF
                                    206 	.globl _SCON
                                    207 	.globl _TH1
                                    208 	.globl _TH0
                                    209 	.globl _TL1
                                    210 	.globl _TL0
                                    211 	.globl _TMOD
                                    212 	.globl _TCON
                                    213 	.globl _XBUS_AUX
                                    214 	.globl _P7
                                    215 	.globl _P6_DIR
                                    216 	.globl _P6_OUT_PU
                                    217 	.globl _P6_IN
                                    218 	.globl _P5_DIR
                                    219 	.globl _P5_OUT_PU
                                    220 	.globl _P5_IN
                                    221 	.globl _P4_LED_KEY
                                    222 	.globl _P4_DIR_PU
                                    223 	.globl _P4_MOD_OC
                                    224 	.globl _P4
                                    225 	.globl _P3_DIR_PU
                                    226 	.globl _P3_MOD_OC
                                    227 	.globl _P3
                                    228 	.globl _P2_DIR_PU
                                    229 	.globl _P2_MOD_OC
                                    230 	.globl _P2
                                    231 	.globl _P1_DIR_PU
                                    232 	.globl _P1_MOD_OC
                                    233 	.globl _P1
                                    234 	.globl _P0_DIR_PU
                                    235 	.globl _P0_MOD_OC
                                    236 	.globl _P0
                                    237 	.globl _ROM_CTRL
                                    238 	.globl _ROM_DATA_HH
                                    239 	.globl _ROM_DATA_HL
                                    240 	.globl _ROM_DATA_HI
                                    241 	.globl _ROM_ADDR_H
                                    242 	.globl _ROM_ADDR_L
                                    243 	.globl _ROM_ADDR
                                    244 	.globl _GPIO_IE
                                    245 	.globl _IP_EX
                                    246 	.globl _IE_EX
                                    247 	.globl _IP
                                    248 	.globl _IE
                                    249 	.globl _WDOG_COUNT
                                    250 	.globl _RESET_KEEP
                                    251 	.globl _WAKE_CTRL
                                    252 	.globl _CLOCK_CFG
                                    253 	.globl _POWER_CFG
                                    254 	.globl _PCON
                                    255 	.globl _GLOBAL_CFG
                                    256 	.globl _SAFE_MOD
                                    257 	.globl _DPH
                                    258 	.globl _DPL
                                    259 	.globl _SP
                                    260 	.globl _A_INV
                                    261 	.globl _B
                                    262 	.globl _ACC
                                    263 	.globl _PSW
                                    264 	.globl _ak820_usb_raw_send_PARM_2
                                    265 	.globl _ak820_usb_try_send_PARM_3
                                    266 	.globl _ak820_usb_try_send_PARM_2
                                    267 	.globl _ak820_usb_send_PARM_3
                                    268 	.globl _ak820_usb_send_PARM_2
                                    269 	.globl _ak820_main_heartbeat
                                    270 	.globl _ak820_boot_stage
                                    271 	.globl _KB_USB_SetReport
                                    272 	.globl _KB_USB_UpStatus
                                    273 	.globl _MCU_Sleep_Operate
                                    274 	.globl _USB_SleepStatus
                                    275 	.globl _USB_EnumStatus
                                    276 	.globl _D0UsbConfig
                                    277 	.globl _pD0Descr
                                    278 	.globl _D0SetupLen
                                    279 	.globl _D0SetupReqCode
                                    280 	.globl _USB_DeviceInterrupt
                                    281 	.globl _USB_Device_Init
                                    282 	.globl _USB_WakeUp_PC
                                    283 	.globl _ak820_usb_send
                                    284 	.globl _ak820_usb_try_send
                                    285 	.globl _ak820_usb_raw_send
                                    286 	.globl _ak820_usb_raw_task
                                    287 	.globl _ak820_usb_keyboard_blocked
                                    288 	.globl _ak820_usb_take_keyboard_reset
                                    289 ;--------------------------------------------------------
                                    290 ; special function registers
                                    291 ;--------------------------------------------------------
                                    292 	.area RSEG    (ABS,DATA)
      000000                        293 	.org 0x0000
                           0000D0   294 _PSW	=	0x00d0
                           0000E0   295 _ACC	=	0x00e0
                           0000F0   296 _B	=	0x00f0
                           0000FD   297 _A_INV	=	0x00fd
                           000081   298 _SP	=	0x0081
                           000082   299 _DPL	=	0x0082
                           000083   300 _DPH	=	0x0083
                           0000A1   301 _SAFE_MOD	=	0x00a1
                           0000B1   302 _GLOBAL_CFG	=	0x00b1
                           000087   303 _PCON	=	0x0087
                           0000BA   304 _POWER_CFG	=	0x00ba
                           0000B9   305 _CLOCK_CFG	=	0x00b9
                           0000A9   306 _WAKE_CTRL	=	0x00a9
                           0000FE   307 _RESET_KEEP	=	0x00fe
                           0000FF   308 _WDOG_COUNT	=	0x00ff
                           0000A8   309 _IE	=	0x00a8
                           0000B8   310 _IP	=	0x00b8
                           0000E8   311 _IE_EX	=	0x00e8
                           0000E9   312 _IP_EX	=	0x00e9
                           0000B2   313 _GPIO_IE	=	0x00b2
                           008584   314 _ROM_ADDR	=	0x8584
                           000084   315 _ROM_ADDR_L	=	0x0084
                           000085   316 _ROM_ADDR_H	=	0x0085
                           008F8E   317 _ROM_DATA_HI	=	0x8f8e
                           00008E   318 _ROM_DATA_HL	=	0x008e
                           00008F   319 _ROM_DATA_HH	=	0x008f
                           000086   320 _ROM_CTRL	=	0x0086
                           000080   321 _P0	=	0x0080
                           0000C4   322 _P0_MOD_OC	=	0x00c4
                           0000C5   323 _P0_DIR_PU	=	0x00c5
                           000090   324 _P1	=	0x0090
                           000092   325 _P1_MOD_OC	=	0x0092
                           000093   326 _P1_DIR_PU	=	0x0093
                           0000A0   327 _P2	=	0x00a0
                           000094   328 _P2_MOD_OC	=	0x0094
                           000095   329 _P2_DIR_PU	=	0x0095
                           0000B0   330 _P3	=	0x00b0
                           000096   331 _P3_MOD_OC	=	0x0096
                           000097   332 _P3_DIR_PU	=	0x0097
                           0000C0   333 _P4	=	0x00c0
                           0000C2   334 _P4_MOD_OC	=	0x00c2
                           0000C3   335 _P4_DIR_PU	=	0x00c3
                           0000C1   336 _P4_LED_KEY	=	0x00c1
                           0000AA   337 _P5_IN	=	0x00aa
                           0000AB   338 _P5_OUT_PU	=	0x00ab
                           0000AC   339 _P5_DIR	=	0x00ac
                           0000AD   340 _P6_IN	=	0x00ad
                           0000AE   341 _P6_OUT_PU	=	0x00ae
                           0000AF   342 _P6_DIR	=	0x00af
                           0000F1   343 _P7	=	0x00f1
                           0000A2   344 _XBUS_AUX	=	0x00a2
                           000088   345 _TCON	=	0x0088
                           000089   346 _TMOD	=	0x0089
                           00008A   347 _TL0	=	0x008a
                           00008B   348 _TL1	=	0x008b
                           00008C   349 _TH0	=	0x008c
                           00008D   350 _TH1	=	0x008d
                           000098   351 _SCON	=	0x0098
                           000099   352 _SBUF	=	0x0099
                           0000C8   353 _T2CON	=	0x00c8
                           0000C9   354 _T2MOD	=	0x00c9
                           00CBCA   355 _RCAP2	=	0xcbca
                           0000CA   356 _RCAP2L	=	0x00ca
                           0000CB   357 _RCAP2H	=	0x00cb
                           00CDCC   358 _T2COUNT	=	0xcdcc
                           0000CC   359 _TL2	=	0x00cc
                           0000CD   360 _TH2	=	0x00cd
                           00CFCE   361 _T2CAP1	=	0xcfce
                           0000CE   362 _T2CAP1L	=	0x00ce
                           0000CF   363 _T2CAP1H	=	0x00cf
                           0000F8   364 _SPI0_STAT	=	0x00f8
                           0000F9   365 _SPI0_DATA	=	0x00f9
                           0000FA   366 _SPI0_CTRL	=	0x00fa
                           0000FB   367 _SPI0_CK_SE	=	0x00fb
                           0000FC   368 _SPI0_SETUP	=	0x00fc
                           0000BC   369 _SCON1	=	0x00bc
                           0000BD   370 _SBUF1	=	0x00bd
                           0000BE   371 _SBAUD1	=	0x00be
                           0000BF   372 _SIF1	=	0x00bf
                           0000B4   373 _SPI1_STAT	=	0x00b4
                           0000B5   374 _SPI1_DATA	=	0x00b5
                           0000B6   375 _SPI1_CTRL	=	0x00b6
                           0000B7   376 _SPI1_CK_SE	=	0x00b7
                           0000F3   377 _ADC_CTRL	=	0x00f3
                           00F5F4   378 _ADC_DAT	=	0xf5f4
                           0000F4   379 _ADC_DAT_L	=	0x00f4
                           0000F5   380 _ADC_DAT_H	=	0x00f5
                           0000F6   381 _ADC_CHAN	=	0x00f6
                           0000A6   382 _LED_COMMON	=	0x00a6
                           0000A7   383 _LED_PWM_OE	=	0x00a7
                           00C7C6   384 _LED_DMA	=	0xc7c6
                           0000C6   385 _LED_DMA_L	=	0x00c6
                           0000C7   386 _LED_DMA_H	=	0x00c7
                           0000F7   387 _LED_STATUS	=	0x00f7
                           0000B3   388 _I2CX_INT	=	0x00b3
                           0000BB   389 _I2CS_INT_ST	=	0x00bb
                                    390 ;--------------------------------------------------------
                                    391 ; special function bits
                                    392 ;--------------------------------------------------------
                                    393 	.area RSEG    (ABS,DATA)
      000000                        394 	.org 0x0000
                           0000D7   395 _CY	=	0x00d7
                           0000D6   396 _AC	=	0x00d6
                           0000D5   397 _F0	=	0x00d5
                           0000D4   398 _RS1	=	0x00d4
                           0000D3   399 _RS0	=	0x00d3
                           0000D2   400 _OV	=	0x00d2
                           0000D1   401 _F1	=	0x00d1
                           0000D0   402 _P	=	0x00d0
                           0000AF   403 _EA	=	0x00af
                           0000AE   404 _E_DIS	=	0x00ae
                           0000AD   405 _ET2	=	0x00ad
                           0000AC   406 _ES	=	0x00ac
                           0000AB   407 _ET1	=	0x00ab
                           0000AA   408 _EX1	=	0x00aa
                           0000A9   409 _ET0	=	0x00a9
                           0000A8   410 _EX0	=	0x00a8
                           0000BF   411 _PH_FLAG	=	0x00bf
                           0000BE   412 _PL_FLAG	=	0x00be
                           0000BD   413 _PT2	=	0x00bd
                           0000BC   414 _PS	=	0x00bc
                           0000BB   415 _PT1	=	0x00bb
                           0000BA   416 _PX1	=	0x00ba
                           0000B9   417 _PT0	=	0x00b9
                           0000B8   418 _PX0	=	0x00b8
                           0000EF   419 _IE_WDOG	=	0x00ef
                           0000EE   420 _IE_GPIO	=	0x00ee
                           0000ED   421 _IE_PWM_I2C	=	0x00ed
                           0000EC   422 _IE_UART1	=	0x00ec
                           0000EB   423 _IE_ADC	=	0x00eb
                           0000E9   424 _IE_USB	=	0x00e9
                           0000E8   425 _IE_SPI0	=	0x00e8
                           000087   426 _P0_7	=	0x0087
                           000086   427 _P0_6	=	0x0086
                           000085   428 _P0_5	=	0x0085
                           000084   429 _P0_4	=	0x0084
                           000083   430 _P0_3	=	0x0083
                           000082   431 _P0_2	=	0x0082
                           000081   432 _P0_1	=	0x0081
                           000080   433 _P0_0	=	0x0080
                           000081   434 _SDA0	=	0x0081
                           000080   435 _SCL0	=	0x0080
                           000083   436 _TXD_	=	0x0083
                           000082   437 _RXD_	=	0x0082
                           000085   438 _AIN13	=	0x0085
                           000084   439 _AIN12	=	0x0084
                           000083   440 _AIN11	=	0x0083
                           000082   441 _AIN10	=	0x0082
                           000081   442 _AIN9	=	0x0081
                           000080   443 _AIN8	=	0x0080
                           000097   444 _P1_7	=	0x0097
                           000096   445 _P1_6	=	0x0096
                           000095   446 _P1_5	=	0x0095
                           000094   447 _P1_4	=	0x0094
                           000093   448 _P1_3	=	0x0093
                           000092   449 _P1_2	=	0x0092
                           000091   450 _P1_1	=	0x0091
                           000090   451 _P1_0	=	0x0090
                           000097   452 _TXD1_	=	0x0097
                           000096   453 _RXD1_	=	0x0096
                           000097   454 _SCK	=	0x0097
                           000096   455 _MISO	=	0x0096
                           000095   456 _MOSI	=	0x0095
                           000094   457 _SCS	=	0x0094
                           000092   458 _INT0_	=	0x0092
                           000091   459 _T2EX	=	0x0091
                           000091   460 _CAP2	=	0x0091
                           000090   461 _T2	=	0x0090
                           000090   462 _CAP1	=	0x0090
                           000097   463 _AIN7	=	0x0097
                           000096   464 _AIN6	=	0x0096
                           000095   465 _AIN5	=	0x0095
                           000094   466 _AIN4	=	0x0094
                           000093   467 _AIN3	=	0x0093
                           000092   468 _AIN2	=	0x0092
                           000091   469 _AIN1	=	0x0091
                           000090   470 _AIN0	=	0x0090
                           0000A7   471 _P2_7	=	0x00a7
                           0000A6   472 _P2_6	=	0x00a6
                           0000A5   473 _P2_5	=	0x00a5
                           0000A4   474 _P2_4	=	0x00a4
                           0000A3   475 _P2_3	=	0x00a3
                           0000A2   476 _P2_2	=	0x00a2
                           0000A1   477 _P2_1	=	0x00a1
                           0000A0   478 _P2_0	=	0x00a0
                           0000A7   479 _TXD1	=	0x00a7
                           0000A6   480 _RXD1	=	0x00a6
                           0000A5   481 _T2EX_	=	0x00a5
                           0000A5   482 _CAP2_	=	0x00a5
                           0000A4   483 _T2_	=	0x00a4
                           0000A4   484 _CAP1_	=	0x00a4
                           0000B7   485 _P3_7	=	0x00b7
                           0000B6   486 _P3_6	=	0x00b6
                           0000B5   487 _P3_5	=	0x00b5
                           0000B4   488 _P3_4	=	0x00b4
                           0000B3   489 _P3_3	=	0x00b3
                           0000B2   490 _P3_2	=	0x00b2
                           0000B1   491 _P3_1	=	0x00b1
                           0000B0   492 _P3_0	=	0x00b0
                           0000B7   493 _SCK1	=	0x00b7
                           0000B6   494 _MISO1	=	0x00b6
                           0000B5   495 _MOSI1	=	0x00b5
                           0000B5   496 _T1	=	0x00b5
                           0000B4   497 _T0	=	0x00b4
                           0000B3   498 _INT1	=	0x00b3
                           0000B2   499 _INT0	=	0x00b2
                           0000B1   500 _TXD	=	0x00b1
                           0000B0   501 _RXD	=	0x00b0
                           0000C6   502 _P4_6	=	0x00c6
                           0000C5   503 _P4_5	=	0x00c5
                           0000C4   504 _P4_4	=	0x00c4
                           0000C3   505 _P4_3	=	0x00c3
                           0000C2   506 _P4_2	=	0x00c2
                           0000C1   507 _P4_1	=	0x00c1
                           0000C0   508 _P4_0	=	0x00c0
                           00008F   509 _TF1	=	0x008f
                           00008E   510 _TR1	=	0x008e
                           00008D   511 _TF0	=	0x008d
                           00008C   512 _TR0	=	0x008c
                           00008B   513 _IE1	=	0x008b
                           00008A   514 _IT1	=	0x008a
                           000089   515 _IE0	=	0x0089
                           000088   516 _IT0	=	0x0088
                           00009F   517 _SM0	=	0x009f
                           00009E   518 _SM1	=	0x009e
                           00009D   519 _SM2	=	0x009d
                           00009C   520 _REN	=	0x009c
                           00009B   521 _TB8	=	0x009b
                           00009A   522 _RB8	=	0x009a
                           000099   523 _TI	=	0x0099
                           000098   524 _RI	=	0x0098
                           0000CF   525 _TF2	=	0x00cf
                           0000CF   526 _CAP1F	=	0x00cf
                           0000CE   527 _EXF2	=	0x00ce
                           0000CD   528 _RCLK	=	0x00cd
                           0000CC   529 _TCLK	=	0x00cc
                           0000CB   530 _EXEN2	=	0x00cb
                           0000CA   531 _TR2	=	0x00ca
                           0000C9   532 _C_T2	=	0x00c9
                           0000C8   533 _CP_RL2	=	0x00c8
                           0000FF   534 _S0_FST_ACT	=	0x00ff
                           0000FE   535 _S0_IF_OV	=	0x00fe
                           0000FD   536 _S0_IF_FIRST	=	0x00fd
                           0000FC   537 _S0_IF_BYTE	=	0x00fc
                           0000FB   538 _S0_FREE	=	0x00fb
                           0000FA   539 _S0_T_FIFO	=	0x00fa
                           0000F8   540 _S0_R_FIFO	=	0x00f8
                           0000F7   541 _ADC_START	=	0x00f7
                                    542 ;--------------------------------------------------------
                                    543 ; overlayable register banks
                                    544 ;--------------------------------------------------------
                                    545 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        546 	.ds 8
                                    547 ;--------------------------------------------------------
                                    548 ; internal ram data
                                    549 ;--------------------------------------------------------
                                    550 	.area DSEG    (DATA)
      000016                        551 _control_setup_sloc1_1_0:
      000016                        552 	.ds 1
      000017                        553 _control_setup_sloc3_1_0:
      000017                        554 	.ds 2
      000019                        555 _control_setup_sloc4_1_0:
      000019                        556 	.ds 2
      00001B                        557 _ak820_usb_send_sloc0_1_0:
      00001B                        558 	.ds 2
      00001D                        559 _ak820_usb_send_sloc1_1_0:
      00001D                        560 	.ds 1
      00001E                        561 _ak820_usb_raw_task_sloc0_1_0:
      00001E                        562 	.ds 2
                                    563 ;--------------------------------------------------------
                                    564 ; overlayable items in internal ram
                                    565 ;--------------------------------------------------------
                                    566 ;--------------------------------------------------------
                                    567 ; indirectly addressable internal ram data
                                    568 ;--------------------------------------------------------
                                    569 	.area ISEG    (DATA)
                                    570 ;--------------------------------------------------------
                                    571 ; absolute internal ram data
                                    572 ;--------------------------------------------------------
                                    573 	.area IABS    (ABS,DATA)
                                    574 	.area IABS    (ABS,DATA)
                                    575 ;--------------------------------------------------------
                                    576 ; bit data
                                    577 ;--------------------------------------------------------
                                    578 	.area BSEG    (BIT)
      000015                        579 _control_setup_valid_interface_10000_290:
      000015                        580 	.ds 1
      000016                        581 _control_setup_zero_index_10000_290:
      000016                        582 	.ds 1
      000017                        583 _control_setup_zero_value_10000_290:
      000017                        584 	.ds 1
      000018                        585 _control_setup_zero_length_10000_290:
      000018                        586 	.ds 1
      000019                        587 _control_setup_sloc0_1_0:
      000019                        588 	.ds 1
      00001A                        589 _control_setup_sloc2_1_0:
      00001A                        590 	.ds 1
      00001B                        591 _ak820_usb_try_send_sloc0_1_0:
      00001B                        592 	.ds 1
      00001C                        593 _ak820_usb_raw_task_sloc1_1_0:
      00001C                        594 	.ds 1
      00001D                        595 _ak820_usb_keyboard_blocked_sloc0_1_0:
      00001D                        596 	.ds 1
      00001E                        597 _ak820_usb_take_keyboard_reset_sloc0_1_0:
      00001E                        598 	.ds 1
                                    599 ;--------------------------------------------------------
                                    600 ; paged external ram data
                                    601 ;--------------------------------------------------------
                                    602 	.area PSEG    (PAG,XDATA)
                                    603 ;--------------------------------------------------------
                                    604 ; uninitialized external ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area XSEG    (XDATA)
      0007D8                        607 _D0SetupReqCode::
      0007D8                        608 	.ds 1
      0007D9                        609 _D0SetupLen::
      0007D9                        610 	.ds 2
      0007DB                        611 _pD0Descr::
      0007DB                        612 	.ds 3
      0007DE                        613 _D0UsbConfig::
      0007DE                        614 	.ds 1
      0007DF                        615 _USB_EnumStatus::
      0007DF                        616 	.ds 1
      0007E0                        617 _USB_SleepStatus::
      0007E0                        618 	.ds 1
      0007E1                        619 _MCU_Sleep_Operate::
      0007E1                        620 	.ds 1
      0007E2                        621 _KB_USB_UpStatus::
      0007E2                        622 	.ds 1
      0007E3                        623 _KB_USB_SetReport::
      0007E3                        624 	.ds 1
      0007E4                        625 _ak820_boot_stage::
      0007E4                        626 	.ds 1
      0007E5                        627 _ak820_main_heartbeat::
      0007E5                        628 	.ds 1
      0007E6                        629 _raw_state:
      0007E6                        630 	.ds 1
      0007E7                        631 _raw_buffer:
      0007E7                        632 	.ds 32
      000807                        633 _raw_reply_without_nvm:
      000807                        634 	.ds 1
      000808                        635 _keyboard_reset:
      000808                        636 	.ds 1
      000809                        637 _input_snapshot:
      000809                        638 	.ds 46
      000837                        639 _control_phase:
      000837                        640 	.ds 1
      000838                        641 _output_kind:
      000838                        642 	.ds 1
      000839                        643 _output_report_id:
      000839                        644 	.ds 1
      00083A                        645 _control_zlp:
      00083A                        646 	.ds 1
      00083B                        647 _control_pointer:
      00083B                        648 	.ds 2
      00083D                        649 _descriptor_select_PARM_2:
      00083D                        650 	.ds 1
      00083E                        651 _descriptor_select_PARM_3:
      00083E                        652 	.ds 2
      000840                        653 _descriptor_select_type_10000_272:
      000840                        654 	.ds 1
      000841                        655 _control_setup_length_10000_290:
      000841                        656 	.ds 2
      000843                        657 _control_setup_offset_10000_290:
      000843                        658 	.ds 1
      000844                        659 _ak820_usb_send_PARM_2:
      000844                        660 	.ds 2
      000846                        661 _ak820_usb_send_PARM_3:
      000846                        662 	.ds 1
      000847                        663 _ak820_usb_send_endpoint_10000_426:
      000847                        664 	.ds 1
      000848                        665 _ak820_usb_send_offset_10000_427:
      000848                        666 	.ds 1
      000849                        667 _ak820_usb_try_send_PARM_2:
      000849                        668 	.ds 2
      00084B                        669 _ak820_usb_try_send_PARM_3:
      00084B                        670 	.ds 1
      00084C                        671 _ak820_usb_try_send_endpoint_10000_447:
      00084C                        672 	.ds 1
      00084D                        673 _ak820_usb_try_send_sent_10000_448:
      00084D                        674 	.ds 1
      00084E                        675 _ak820_usb_raw_send_PARM_2:
      00084E                        676 	.ds 1
      00084F                        677 _ak820_usb_raw_send_report_10000_463:
      00084F                        678 	.ds 3
      000852                        679 _ak820_usb_raw_task_length_10000_468:
      000852                        680 	.ds 1
                                    681 ;--------------------------------------------------------
                                    682 ; absolute external ram data
                                    683 ;--------------------------------------------------------
                                    684 	.area XABS    (ABS,XDATA)
                                    685 ;--------------------------------------------------------
                                    686 ; initialized external ram data
                                    687 ;--------------------------------------------------------
                                    688 	.area XISEG   (XDATA)
                                    689 	.area HOME    (CODE)
                                    690 	.area GSINIT0 (CODE)
                                    691 	.area GSINIT1 (CODE)
                                    692 	.area GSINIT2 (CODE)
                                    693 	.area GSINIT3 (CODE)
                                    694 	.area GSINIT4 (CODE)
                                    695 	.area GSINIT5 (CODE)
                                    696 	.area GSINIT  (CODE)
                                    697 	.area GSFINAL (CODE)
                                    698 	.area CSEG    (CODE)
                                    699 ;--------------------------------------------------------
                                    700 ; global & static initialisations
                                    701 ;--------------------------------------------------------
                                    702 	.area HOME    (CODE)
                                    703 	.area GSINIT  (CODE)
                                    704 	.area GSFINAL (CODE)
                                    705 	.area GSINIT  (CODE)
                                    706 ;--------------------------------------------------------
                                    707 ; Home
                                    708 ;--------------------------------------------------------
                                    709 	.area HOME    (CODE)
                                    710 	.area HOME    (CODE)
                                    711 ;--------------------------------------------------------
                                    712 ; code
                                    713 ;--------------------------------------------------------
                                    714 	.area CSEG    (CODE)
                                    715 ;------------------------------------------------------------
                                    716 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    717 ;------------------------------------------------------------
                                    718 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_46'
                                    719 ;------------------------------------------------------------
                                    720 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    721 ;	-----------------------------------------
                           000007   722 	ar7 = 0x07
                           000006   723 	ar6 = 0x06
                           000005   724 	ar5 = 0x05
                           000004   725 	ar4 = 0x04
                           000003   726 	ar3 = 0x03
                           000002   727 	ar2 = 0x02
                           000001   728 	ar1 = 0x01
                           000000   729 	ar0 = 0x00
                                    730 ;	 function raw_abort
                                    731 ;	-----------------------------------------
      006074                        732 _raw_abort:
                                    733 ;	tmk_core/protocol/ch555/usb_ak820.c:97: if (raw_state == RAW_WORK || raw_state == RAW_TX_ACTIVE ||
      006074 90 07 E6         [24]  734 	mov	dptr,#_raw_state
      006077 E0               [24]  735 	movx	a,@dptr
      006078 FF               [12]  736 	mov	r7,a
      006079 BF 03 02         [24]  737 	cjne	r7,#0x03,00130$
      00607C 80 1C            [24]  738 	sjmp	00101$
      00607E                        739 00130$:
      00607E 90 07 E6         [24]  740 	mov	dptr,#_raw_state
      006081 E0               [24]  741 	movx	a,@dptr
      006082 FF               [12]  742 	mov	r7,a
      006083 BF 04 02         [24]  743 	cjne	r7,#0x04,00131$
      006086 80 12            [24]  744 	sjmp	00101$
      006088                        745 00131$:
                                    746 ;	tmk_core/protocol/ch555/usb_ak820.c:98: raw_state == RAW_DRAINED || raw_state == RAW_CANCELLED)
      006088 90 07 E6         [24]  747 	mov	dptr,#_raw_state
      00608B E0               [24]  748 	movx	a,@dptr
      00608C FF               [12]  749 	mov	r7,a
      00608D BF 06 02         [24]  750 	cjne	r7,#0x06,00132$
      006090 80 08            [24]  751 	sjmp	00101$
      006092                        752 00132$:
      006092 90 07 E6         [24]  753 	mov	dptr,#_raw_state
      006095 E0               [24]  754 	movx	a,@dptr
      006096 FF               [12]  755 	mov	r7,a
      006097 BF 07 08         [24]  756 	cjne	r7,#0x07,00102$
      00609A                        757 00101$:
                                    758 ;	tmk_core/protocol/ch555/usb_ak820.c:99: raw_state = RAW_CANCELLED;
      00609A 90 07 E6         [24]  759 	mov	dptr,#_raw_state
      00609D 74 07            [12]  760 	mov	a,#0x07
      00609F F0               [24]  761 	movx	@dptr,a
      0060A0 80 05            [24]  762 	sjmp	00103$
      0060A2                        763 00102$:
                                    764 ;	tmk_core/protocol/ch555/usb_ak820.c:101: raw_state = RAW_IDLE;
      0060A2 90 07 E6         [24]  765 	mov	dptr,#_raw_state
      0060A5 E4               [12]  766 	clr	a
      0060A6 F0               [24]  767 	movx	@dptr,a
      0060A7                        768 00103$:
                                    769 ;	tmk_core/protocol/ch555/usb_ak820.c:102: output_kind = OUTPUT_NONE;
      0060A7 90 08 38         [24]  770 	mov	dptr,#_output_kind
      0060AA E4               [12]  771 	clr	a
      0060AB F0               [24]  772 	movx	@dptr,a
                                    773 ;	tmk_core/protocol/ch555/usb_ak820.c:103: }
      0060AC 22               [24]  774 	ret
                                    775 ;------------------------------------------------------------
                                    776 ;Allocation info for local variables in function 'raw_complete'
                                    777 ;------------------------------------------------------------
                                    778 ;	tmk_core/protocol/ch555/usb_ak820.c:105: static void raw_complete(void) {
                                    779 ;	-----------------------------------------
                                    780 ;	 function raw_complete
                                    781 ;	-----------------------------------------
      0060AD                        782 _raw_complete:
                                    783 ;	tmk_core/protocol/ch555/usb_ak820.c:106: if (raw_state == RAW_TX_ACTIVE) raw_state = RAW_DRAINED;
      0060AD 90 07 E6         [24]  784 	mov	dptr,#_raw_state
      0060B0 E0               [24]  785 	movx	a,@dptr
      0060B1 FF               [12]  786 	mov	r7,a
      0060B2 BF 04 07         [24]  787 	cjne	r7,#0x04,00104$
      0060B5 90 07 E6         [24]  788 	mov	dptr,#_raw_state
      0060B8 74 06            [12]  789 	mov	a,#0x06
      0060BA F0               [24]  790 	movx	@dptr,a
      0060BB 22               [24]  791 	ret
      0060BC                        792 00104$:
                                    793 ;	tmk_core/protocol/ch555/usb_ak820.c:107: else if (raw_state == RAW_TX_WAIT) raw_state = RAW_IDLE;
      0060BC 90 07 E6         [24]  794 	mov	dptr,#_raw_state
      0060BF E0               [24]  795 	movx	a,@dptr
      0060C0 FF               [12]  796 	mov	r7,a
      0060C1 BF 05 05         [24]  797 	cjne	r7,#0x05,00106$
      0060C4 90 07 E6         [24]  798 	mov	dptr,#_raw_state
      0060C7 E4               [12]  799 	clr	a
      0060C8 F0               [24]  800 	movx	@dptr,a
      0060C9                        801 00106$:
                                    802 ;	tmk_core/protocol/ch555/usb_ak820.c:108: }
      0060C9 22               [24]  803 	ret
                                    804 ;------------------------------------------------------------
                                    805 ;Allocation info for local variables in function 'endpoints_reset'
                                    806 ;------------------------------------------------------------
                                    807 ;i             Allocated with name '_endpoints_reset_i_10000_262'
                                    808 ;------------------------------------------------------------
                                    809 ;	tmk_core/protocol/ch555/usb_ak820.c:110: static void endpoints_reset(void) {
                                    810 ;	-----------------------------------------
                                    811 ;	 function endpoints_reset
                                    812 ;	-----------------------------------------
      0060CA                        813 _endpoints_reset:
                                    814 ;	tmk_core/protocol/ch555/usb_ak820.c:113: ak820_os_indicator_mode = AK820_OS_NORMAL;
      0060CA 90 06 09         [24]  815 	mov	dptr,#_ak820_os_indicator_mode
      0060CD E4               [12]  816 	clr	a
      0060CE F0               [24]  817 	movx	@dptr,a
                                    818 ;	tmk_core/protocol/ch555/usb_ak820.c:116: D0_EP_MOD = bUX_DEV_EN;
      0060CF 90 22 0C         [24]  819 	mov	dptr,#0x220c
      0060D2 04               [12]  820 	inc	a
      0060D3 F0               [24]  821 	movx	@dptr,a
                                    822 ;	tmk_core/protocol/ch555/usb_ak820.c:117: D0_EP1RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      0060D4 F5 82            [12]  823 	mov	dpl,a
      0060D6 74 12            [12]  824 	mov	a,#0x12
      0060D8 F0               [24]  825 	movx	@dptr,a
                                    826 ;	tmk_core/protocol/ch555/usb_ak820.c:118: D0_EP2RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      0060D9 A3               [24]  827 	inc	dptr
      0060DA F0               [24]  828 	movx	@dptr,a
                                    829 ;	tmk_core/protocol/ch555/usb_ak820.c:119: D0_EP3RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      0060DB A3               [24]  830 	inc	dptr
      0060DC F0               [24]  831 	movx	@dptr,a
                                    832 ;	tmk_core/protocol/ch555/usb_ak820.c:120: D0_EP1T_L = D0_EP2T_L = D0_EP3T_L = 0;
      0060DD 90 22 0B         [24]  833 	mov	dptr,#0x220b
      0060E0 E4               [12]  834 	clr	a
      0060E1 F0               [24]  835 	movx	@dptr,a
      0060E2 15 82            [12]  836 	dec	dpl
      0060E4 F0               [24]  837 	movx	@dptr,a
      0060E5 15 82            [12]  838 	dec	dpl
      0060E7 F0               [24]  839 	movx	@dptr,a
                                    840 ;	tmk_core/protocol/ch555/usb_ak820.c:121: for (i = 0; i < SNAPSHOT_SIZE; ++i) input_snapshot[i] = 0;
      0060E8 FF               [12]  841 	mov	r7,a
      0060E9                        842 00103$:
      0060E9 EF               [12]  843 	mov	a,r7
      0060EA 24 09            [12]  844 	add	a, #_input_snapshot
      0060EC F5 82            [12]  845 	mov	dpl,a
      0060EE E4               [12]  846 	clr	a
      0060EF 34 08            [12]  847 	addc	a, #(_input_snapshot >> 8)
      0060F1 F5 83            [12]  848 	mov	dph,a
      0060F3 E4               [12]  849 	clr	a
      0060F4 F0               [24]  850 	movx	@dptr,a
      0060F5 0F               [12]  851 	inc	r7
      0060F6 BF 2E 00         [24]  852 	cjne	r7,#0x2e,00139$
      0060F9                        853 00139$:
      0060F9 40 EE            [24]  854 	jc	00103$
                                    855 ;	tmk_core/protocol/ch555/usb_ak820.c:122: input_snapshot[SNAPSHOT_NKRO] = REPORT_ID_NKRO;
      0060FB 90 08 11         [24]  856 	mov	dptr,#(_input_snapshot + 0x0008)
      0060FE 74 06            [12]  857 	mov	a,#0x06
      006100 F0               [24]  858 	movx	@dptr,a
                                    859 ;	tmk_core/protocol/ch555/usb_ak820.c:126: input_snapshot[SNAPSHOT_SYSTEM] = REPORT_ID_SYSTEM;
      006101 90 08 31         [24]  860 	mov	dptr,#(_input_snapshot + 0x0028)
      006104 03               [12]  861 	rr	a
      006105 F0               [24]  862 	movx	@dptr,a
                                    863 ;	tmk_core/protocol/ch555/usb_ak820.c:127: input_snapshot[SNAPSHOT_CONSUMER] = REPORT_ID_CONSUMER;
      006106 90 08 34         [24]  864 	mov	dptr,#(_input_snapshot + 0x002b)
      006109 04               [12]  865 	inc	a
      00610A F0               [24]  866 	movx	@dptr,a
                                    867 ;	tmk_core/protocol/ch555/usb_ak820.c:128: for (i = 0; i < RAW_EPSIZE; ++i) pUSB_BUF_DEV0[UX_EP3_ADDR + i] = 0;
      00610B 7F 00            [12]  868 	mov	r7,#0x00
      00610D                        869 00105$:
      00610D 8F 06            [24]  870 	mov	ar6,r7
      00610F 74 C0            [12]  871 	mov	a,#0xc0
      006111 2E               [12]  872 	add	a, r6
      006112 F5 82            [12]  873 	mov	dpl,a
      006114 74 10            [12]  874 	mov	a,#0x10
      006116 24 00            [12]  875 	add	a, #0x00
      006118 F5 83            [12]  876 	mov	dph,a
      00611A E4               [12]  877 	clr	a
      00611B F0               [24]  878 	movx	@dptr,a
      00611C 0F               [12]  879 	inc	r7
      00611D BF 20 00         [24]  880 	cjne	r7,#0x20,00141$
      006120                        881 00141$:
      006120 40 EB            [24]  882 	jc	00105$
                                    883 ;	tmk_core/protocol/ch555/usb_ak820.c:129: raw_abort();
                                    884 ;	tmk_core/protocol/ch555/usb_ak820.c:130: }
      006122 02 60 74         [24]  885 	ljmp	_raw_abort
                                    886 ;------------------------------------------------------------
                                    887 ;Allocation info for local variables in function 'control_stall'
                                    888 ;------------------------------------------------------------
                                    889 ;	tmk_core/protocol/ch555/usb_ak820.c:132: static void control_stall(void) {
                                    890 ;	-----------------------------------------
                                    891 ;	 function control_stall
                                    892 ;	-----------------------------------------
      006125                        893 _control_stall:
                                    894 ;	tmk_core/protocol/ch555/usb_ak820.c:133: if (raw_state == RAW_RX) raw_state = RAW_IDLE;
      006125 90 07 E6         [24]  895 	mov	dptr,#_raw_state
      006128 E0               [24]  896 	movx	a,@dptr
      006129 FF               [12]  897 	mov	r7,a
      00612A BF 01 05         [24]  898 	cjne	r7,#0x01,00102$
      00612D 90 07 E6         [24]  899 	mov	dptr,#_raw_state
      006130 E4               [12]  900 	clr	a
      006131 F0               [24]  901 	movx	@dptr,a
      006132                        902 00102$:
                                    903 ;	tmk_core/protocol/ch555/usb_ak820.c:134: output_kind = OUTPUT_NONE;
      006132 90 08 38         [24]  904 	mov	dptr,#_output_kind
      006135 E4               [12]  905 	clr	a
      006136 F0               [24]  906 	movx	@dptr,a
                                    907 ;	tmk_core/protocol/ch555/usb_ak820.c:135: control_phase = CTRL_IDLE;
      006137 90 08 37         [24]  908 	mov	dptr,#_control_phase
      00613A F0               [24]  909 	movx	@dptr,a
                                    910 ;	tmk_core/protocol/ch555/usb_ak820.c:136: D0SetupReqCode = 0xff;
      00613B 90 07 D8         [24]  911 	mov	dptr,#_D0SetupReqCode
      00613E 14               [12]  912 	dec	a
      00613F F0               [24]  913 	movx	@dptr,a
                                    914 ;	tmk_core/protocol/ch555/usb_ak820.c:138: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_STALL | UEP_T_RES_STALL;
      006140 90 22 00         [24]  915 	mov	dptr,#0x2200
      006143 74 CF            [12]  916 	mov	a,#0xcf
      006145 F0               [24]  917 	movx	@dptr,a
                                    918 ;	tmk_core/protocol/ch555/usb_ak820.c:139: }
      006146 22               [24]  919 	ret
                                    920 ;------------------------------------------------------------
                                    921 ;Allocation info for local variables in function 'control_next'
                                    922 ;------------------------------------------------------------
                                    923 ;i             Allocated with name '_control_next_i_10000_269'
                                    924 ;length        Allocated with name '_control_next_length_10000_269'
                                    925 ;------------------------------------------------------------
                                    926 ;	tmk_core/protocol/ch555/usb_ak820.c:141: static void control_next(void) {
                                    927 ;	-----------------------------------------
                                    928 ;	 function control_next
                                    929 ;	-----------------------------------------
      006147                        930 _control_next:
                                    931 ;	tmk_core/protocol/ch555/usb_ak820.c:143: uint8_t length = D0SetupLen > DEF_ENDP0_SIZE ? DEF_ENDP0_SIZE : D0SetupLen;
      006147 90 07 D9         [24]  932 	mov	dptr,#_D0SetupLen
      00614A E0               [24]  933 	movx	a,@dptr
      00614B FE               [12]  934 	mov	r6,a
      00614C A3               [24]  935 	inc	dptr
      00614D E0               [24]  936 	movx	a,@dptr
      00614E FF               [12]  937 	mov	r7,a
      00614F C3               [12]  938 	clr	c
      006150 74 40            [12]  939 	mov	a,#0x40
      006152 9E               [12]  940 	subb	a,r6
      006153 E4               [12]  941 	clr	a
      006154 9F               [12]  942 	subb	a,r7
      006155 50 04            [24]  943 	jnc	00109$
                                    944 ;	free result
      006157 7E 40            [12]  945 	mov	r6,#0x40
      006159 80 07            [24]  946 	sjmp	00110$
      00615B                        947 00109$:
      00615B 90 07 D9         [24]  948 	mov	dptr,#_D0SetupLen
      00615E E0               [24]  949 	movx	a,@dptr
      00615F FE               [12]  950 	mov	r6,a
      006160 A3               [24]  951 	inc	dptr
      006161 E0               [24]  952 	movx	a,@dptr
      006162                        953 00110$:
                                    954 ;	tmk_core/protocol/ch555/usb_ak820.c:144: for (i = 0; i < length; ++i) pD0_EP0_BUF[i] = *control_pointer++;
      006162 7F 00            [12]  955 	mov	r7,#0x00
      006164                        956 00105$:
      006164 C3               [12]  957 	clr	c
      006165 EF               [12]  958 	mov	a,r7
      006166 9E               [12]  959 	subb	a,r6
      006167 50 2A            [24]  960 	jnc	00101$
      006169 8F 04            [24]  961 	mov	ar4,r7
      00616B 74 10            [12]  962 	mov	a,#0x10
      00616D 24 00            [12]  963 	add	a, #0x00
      00616F FD               [12]  964 	mov	r5,a
      006170 90 08 3B         [24]  965 	mov	dptr,#_control_pointer
      006173 E0               [24]  966 	movx	a,@dptr
      006174 FA               [12]  967 	mov	r2,a
      006175 A3               [24]  968 	inc	dptr
      006176 E0               [24]  969 	movx	a,@dptr
      006177 FB               [12]  970 	mov	r3,a
      006178 8A 82            [24]  971 	mov	dpl,r2
      00617A 8B 83            [24]  972 	mov	dph,r3
      00617C E4               [12]  973 	clr	a
      00617D 93               [24]  974 	movc	a,@a+dptr
      00617E F9               [12]  975 	mov	r1,a
      00617F 90 08 3B         [24]  976 	mov	dptr,#_control_pointer
      006182 74 01            [12]  977 	mov	a,#0x01
      006184 2A               [12]  978 	add	a, r2
      006185 F0               [24]  979 	movx	@dptr,a
      006186 E4               [12]  980 	clr	a
      006187 3B               [12]  981 	addc	a, r3
      006188 A3               [24]  982 	inc	dptr
      006189 F0               [24]  983 	movx	@dptr,a
      00618A 8C 82            [24]  984 	mov	dpl,r4
      00618C 8D 83            [24]  985 	mov	dph,r5
      00618E E9               [12]  986 	mov	a,r1
      00618F F0               [24]  987 	movx	@dptr,a
      006190 0F               [12]  988 	inc	r7
      006191 80 D1            [24]  989 	sjmp	00105$
      006193                        990 00101$:
                                    991 ;	tmk_core/protocol/ch555/usb_ak820.c:145: D0SetupLen -= length;
      006193 8E 05            [24]  992 	mov	ar5,r6
      006195 7F 00            [12]  993 	mov	r7,#0x00
      006197 90 07 D9         [24]  994 	mov	dptr,#_D0SetupLen
      00619A E0               [24]  995 	movx	a,@dptr
      00619B FB               [12]  996 	mov	r3,a
      00619C A3               [24]  997 	inc	dptr
      00619D E0               [24]  998 	movx	a,@dptr
      00619E FC               [12]  999 	mov	r4,a
      00619F EB               [12] 1000 	mov	a,r3
      0061A0 C3               [12] 1001 	clr	c
      0061A1 9D               [12] 1002 	subb	a,r5
      0061A2 FB               [12] 1003 	mov	r3,a
      0061A3 EC               [12] 1004 	mov	a,r4
      0061A4 9F               [12] 1005 	subb	a,r7
      0061A5 FC               [12] 1006 	mov	r4,a
      0061A6 90 07 D9         [24] 1007 	mov	dptr,#_D0SetupLen
      0061A9 EB               [12] 1008 	mov	a,r3
      0061AA F0               [24] 1009 	movx	@dptr,a
      0061AB EC               [12] 1010 	mov	a,r4
      0061AC A3               [24] 1011 	inc	dptr
      0061AD F0               [24] 1012 	movx	@dptr,a
                                   1013 ;	tmk_core/protocol/ch555/usb_ak820.c:146: if (!length) control_zlp = 0;
      0061AE EE               [12] 1014 	mov	a,r6
      0061AF 70 05            [24] 1015 	jnz	00103$
      0061B1 90 08 3A         [24] 1016 	mov	dptr,#_control_zlp
      0061B4 E4               [12] 1017 	clr	a
      0061B5 F0               [24] 1018 	movx	@dptr,a
      0061B6                       1019 00103$:
                                   1020 ;	tmk_core/protocol/ch555/usb_ak820.c:147: D0_EP0T_L = length;
      0061B6 90 22 08         [24] 1021 	mov	dptr,#0x2208
      0061B9 EE               [12] 1022 	mov	a,r6
      0061BA F0               [24] 1023 	movx	@dptr,a
                                   1024 ;	tmk_core/protocol/ch555/usb_ak820.c:148: D0_EP0RES = (D0_EP0RES & (bUEP_T_TOG | bUEP_R_TOG)) | UEP_T_RES_ACK | UEP_R_RES_ACK;
      0061BB 90 22 00         [24] 1025 	mov	dptr,#0x2200
      0061BE E0               [24] 1026 	movx	a,@dptr
      0061BF 54 C0            [12] 1027 	anl	a,#0xc0
      0061C1 F0               [24] 1028 	movx	@dptr,a
                                   1029 ;	tmk_core/protocol/ch555/usb_ak820.c:149: }
      0061C2 22               [24] 1030 	ret
                                   1031 ;------------------------------------------------------------
                                   1032 ;Allocation info for local variables in function 'descriptor_select'
                                   1033 ;------------------------------------------------------------
                                   1034 ;index         Allocated with name '_descriptor_select_PARM_2'
                                   1035 ;interface     Allocated with name '_descriptor_select_PARM_3'
                                   1036 ;type          Allocated with name '_descriptor_select_type_10000_272'
                                   1037 ;hid           Allocated with name '_descriptor_select_hid_30000_285'
                                   1038 ;------------------------------------------------------------
                                   1039 ;	tmk_core/protocol/ch555/usb_ak820.c:166: static uint16_t descriptor_select(uint8_t type, uint8_t index, uint16_t interface) {
                                   1040 ;	-----------------------------------------
                                   1041 ;	 function descriptor_select
                                   1042 ;	-----------------------------------------
      0061C3                       1043 _descriptor_select:
      0061C3 E5 82            [12] 1044 	mov	a,dpl
      0061C5 90 08 40         [24] 1045 	mov	dptr,#_descriptor_select_type_10000_272
      0061C8 F0               [24] 1046 	movx	@dptr,a
                                   1047 ;	tmk_core/protocol/ch555/usb_ak820.c:167: if (type == USB_DESCR_TYP_DEVICE && !index && !interface) {
      0061C9 E0               [24] 1048 	movx	a,@dptr
      0061CA FF               [12] 1049 	mov	r7,a
      0061CB BF 01 20         [24] 1050 	cjne	r7,#0x01,00102$
      0061CE 90 08 3D         [24] 1051 	mov	dptr,#_descriptor_select_PARM_2
      0061D1 E0               [24] 1052 	movx	a,@dptr
      0061D2 70 1A            [24] 1053 	jnz	00102$
      0061D4 90 08 3E         [24] 1054 	mov	dptr,#_descriptor_select_PARM_3
      0061D7 E0               [24] 1055 	movx	a,@dptr
      0061D8 F5 F0            [12] 1056 	mov	b,a
      0061DA A3               [24] 1057 	inc	dptr
      0061DB E0               [24] 1058 	movx	a,@dptr
      0061DC 45 F0            [12] 1059 	orl	a,b
      0061DE 70 0E            [24] 1060 	jnz	00102$
                                   1061 ;	tmk_core/protocol/ch555/usb_ak820.c:168: control_pointer = (const uint8_t __code *)&DeviceDescriptor;
      0061E0 90 08 3B         [24] 1062 	mov	dptr,#_control_pointer
      0061E3 74 73            [12] 1063 	mov	a,#_DeviceDescriptor
      0061E5 F0               [24] 1064 	movx	@dptr,a
      0061E6 74 C6            [12] 1065 	mov	a,#(_DeviceDescriptor >> 8)
      0061E8 A3               [24] 1066 	inc	dptr
      0061E9 F0               [24] 1067 	movx	@dptr,a
                                   1068 ;	tmk_core/protocol/ch555/usb_ak820.c:169: return sizeof(DeviceDescriptor);
      0061EA 90 00 12         [24] 1069 	mov	dptr,#0x0012
      0061ED 22               [24] 1070 	ret
      0061EE                       1071 00102$:
                                   1072 ;	tmk_core/protocol/ch555/usb_ak820.c:171: if (type == USB_DESCR_TYP_CONFIG && !index && !interface) {
      0061EE 90 08 40         [24] 1073 	mov	dptr,#_descriptor_select_type_10000_272
      0061F1 E0               [24] 1074 	movx	a,@dptr
      0061F2 FF               [12] 1075 	mov	r7,a
      0061F3 BF 02 20         [24] 1076 	cjne	r7,#0x02,00106$
      0061F6 90 08 3D         [24] 1077 	mov	dptr,#_descriptor_select_PARM_2
      0061F9 E0               [24] 1078 	movx	a,@dptr
      0061FA 70 1A            [24] 1079 	jnz	00106$
      0061FC 90 08 3E         [24] 1080 	mov	dptr,#_descriptor_select_PARM_3
      0061FF E0               [24] 1081 	movx	a,@dptr
      006200 F5 F0            [12] 1082 	mov	b,a
      006202 A3               [24] 1083 	inc	dptr
      006203 E0               [24] 1084 	movx	a,@dptr
      006204 45 F0            [12] 1085 	orl	a,b
      006206 70 0E            [24] 1086 	jnz	00106$
                                   1087 ;	tmk_core/protocol/ch555/usb_ak820.c:172: control_pointer = (const uint8_t __code *)&ConfigurationDescriptor;
      006208 90 08 3B         [24] 1088 	mov	dptr,#_control_pointer
      00620B 74 85            [12] 1089 	mov	a,#_ConfigurationDescriptor
      00620D F0               [24] 1090 	movx	@dptr,a
      00620E 74 C6            [12] 1091 	mov	a,#(_ConfigurationDescriptor >> 8)
      006210 A3               [24] 1092 	inc	dptr
      006211 F0               [24] 1093 	movx	@dptr,a
                                   1094 ;	tmk_core/protocol/ch555/usb_ak820.c:173: return sizeof(ConfigurationDescriptor);
      006212 90 00 54         [24] 1095 	mov	dptr,#0x0054
      006215 22               [24] 1096 	ret
      006216                       1097 00106$:
                                   1098 ;	tmk_core/protocol/ch555/usb_ak820.c:175: if (type == USB_DESCR_TYP_STRING) {
      006216 90 08 40         [24] 1099 	mov	dptr,#_descriptor_select_type_10000_272
      006219 E0               [24] 1100 	movx	a,@dptr
      00621A FF               [12] 1101 	mov	r7,a
      00621B BF 03 02         [24] 1102 	cjne	r7,#0x03,00238$
      00621E 80 03            [24] 1103 	sjmp	00239$
      006220                       1104 00238$:
      006220 02 62 BA         [24] 1105 	ljmp	00119$
      006223                       1106 00239$:
                                   1107 ;	tmk_core/protocol/ch555/usb_ak820.c:176: if (interface != 0 && interface != 0x0409) return 0;
      006223 90 08 3E         [24] 1108 	mov	dptr,#_descriptor_select_PARM_3
      006226 E0               [24] 1109 	movx	a,@dptr
      006227 FD               [12] 1110 	mov	r5,a
      006228 A3               [24] 1111 	inc	dptr
      006229 E0               [24] 1112 	movx	a,@dptr
      00622A FE               [12] 1113 	mov	r6,a
      00622B 90 08 3E         [24] 1114 	mov	dptr,#_descriptor_select_PARM_3
      00622E E0               [24] 1115 	movx	a,@dptr
      00622F F5 F0            [12] 1116 	mov	b,a
      006231 A3               [24] 1117 	inc	dptr
      006232 E0               [24] 1118 	movx	a,@dptr
      006233 45 F0            [12] 1119 	orl	a,b
      006235 60 0C            [24] 1120 	jz	00110$
      006237 BD 09 05         [24] 1121 	cjne	r5,#0x09,00241$
      00623A BE 04 02         [24] 1122 	cjne	r6,#0x04,00241$
      00623D 80 04            [24] 1123 	sjmp	00110$
      00623F                       1124 00241$:
      00623F 90 00 00         [24] 1125 	mov	dptr,#0x0000
      006242 22               [24] 1126 	ret
      006243                       1127 00110$:
                                   1128 ;	tmk_core/protocol/ch555/usb_ak820.c:177: switch (index) {
      006243 90 08 3D         [24] 1129 	mov	dptr,#_descriptor_select_PARM_2
      006246 E0               [24] 1130 	movx	a,@dptr
      006247 FE               [12] 1131 	mov  r6,a
      006248 24 FC            [12] 1132 	add	a,#0xff - 0x03
      00624A 40 6A            [24] 1133 	jc	00116$
                                   1134 ;	free result
      00624C EE               [12] 1135 	mov	a,r6
      00624D 2E               [12] 1136 	add	a,r6
                                   1137 ;	tmk_core/protocol/ch555/usb_ak820.c:178: case 0: control_pointer = (const uint8_t __code *)&LanguageString; return LanguageString.Header.Size;
      00624E 90 62 52         [24] 1138 	mov	dptr,#00243$
      006251 73               [24] 1139 	jmp	@a+dptr
      006252                       1140 00243$:
      006252 80 06            [24] 1141 	sjmp	00112$
      006254 80 1B            [24] 1142 	sjmp	00113$
      006256 80 30            [24] 1143 	sjmp	00114$
      006258 80 45            [24] 1144 	sjmp	00115$
      00625A                       1145 00112$:
      00625A 90 08 3B         [24] 1146 	mov	dptr,#_control_pointer
      00625D 74 D9            [12] 1147 	mov	a,#_LanguageString
      00625F F0               [24] 1148 	movx	@dptr,a
      006260 74 C6            [12] 1149 	mov	a,#(_LanguageString >> 8)
      006262 A3               [24] 1150 	inc	dptr
      006263 F0               [24] 1151 	movx	@dptr,a
      006264 90 C6 D9         [24] 1152 	mov	dptr,#_LanguageString
      006267 E4               [12] 1153 	clr	a
      006268 93               [24] 1154 	movc	a,@a+dptr
      006269 FE               [12] 1155 	mov	r6,a
      00626A 7D 00            [12] 1156 	mov	r5,#0x00
      00626C 8E 82            [24] 1157 	mov	dpl, r6
      00626E 8D 83            [24] 1158 	mov	dph, r5
      006270 22               [24] 1159 	ret
                                   1160 ;	tmk_core/protocol/ch555/usb_ak820.c:179: case 1: control_pointer = (const uint8_t __code *)&ManufacturerString; return ManufacturerString.Header.Size;
      006271                       1161 00113$:
      006271 90 08 3B         [24] 1162 	mov	dptr,#_control_pointer
      006274 74 DD            [12] 1163 	mov	a,#_ManufacturerString
      006276 F0               [24] 1164 	movx	@dptr,a
      006277 74 C6            [12] 1165 	mov	a,#(_ManufacturerString >> 8)
      006279 A3               [24] 1166 	inc	dptr
      00627A F0               [24] 1167 	movx	@dptr,a
      00627B 90 C6 DD         [24] 1168 	mov	dptr,#_ManufacturerString
      00627E E4               [12] 1169 	clr	a
      00627F 93               [24] 1170 	movc	a,@a+dptr
      006280 FE               [12] 1171 	mov	r6,a
      006281 7D 00            [12] 1172 	mov	r5,#0x00
      006283 8E 82            [24] 1173 	mov	dpl, r6
      006285 8D 83            [24] 1174 	mov	dph, r5
      006287 22               [24] 1175 	ret
                                   1176 ;	tmk_core/protocol/ch555/usb_ak820.c:180: case 2: control_pointer = (const uint8_t __code *)&ProductString; return ProductString.Header.Size;
      006288                       1177 00114$:
      006288 90 08 3B         [24] 1178 	mov	dptr,#_control_pointer
      00628B 74 EB            [12] 1179 	mov	a,#_ProductString
      00628D F0               [24] 1180 	movx	@dptr,a
      00628E 74 C6            [12] 1181 	mov	a,#(_ProductString >> 8)
      006290 A3               [24] 1182 	inc	dptr
      006291 F0               [24] 1183 	movx	@dptr,a
      006292 90 C6 EB         [24] 1184 	mov	dptr,#_ProductString
      006295 E4               [12] 1185 	clr	a
      006296 93               [24] 1186 	movc	a,@a+dptr
      006297 FE               [12] 1187 	mov	r6,a
      006298 7D 00            [12] 1188 	mov	r5,#0x00
      00629A 8E 82            [24] 1189 	mov	dpl, r6
      00629C 8D 83            [24] 1190 	mov	dph, r5
      00629E 22               [24] 1191 	ret
                                   1192 ;	tmk_core/protocol/ch555/usb_ak820.c:182: case 3: control_pointer = (const uint8_t __code *)&SerialNumberString; return SerialNumberString.Header.Size;
      00629F                       1193 00115$:
      00629F 90 08 3B         [24] 1194 	mov	dptr,#_control_pointer
      0062A2 74 23            [12] 1195 	mov	a,#_SerialNumberString
      0062A4 F0               [24] 1196 	movx	@dptr,a
      0062A5 74 C7            [12] 1197 	mov	a,#(_SerialNumberString >> 8)
      0062A7 A3               [24] 1198 	inc	dptr
      0062A8 F0               [24] 1199 	movx	@dptr,a
      0062A9 90 C7 23         [24] 1200 	mov	dptr,#_SerialNumberString
      0062AC E4               [12] 1201 	clr	a
      0062AD 93               [24] 1202 	movc	a,@a+dptr
      0062AE FE               [12] 1203 	mov	r6,a
      0062AF 7D 00            [12] 1204 	mov	r5,#0x00
      0062B1 8E 82            [24] 1205 	mov	dpl, r6
      0062B3 8D 83            [24] 1206 	mov	dph, r5
      0062B5 22               [24] 1207 	ret
                                   1208 ;	tmk_core/protocol/ch555/usb_ak820.c:184: default: return 0;
      0062B6                       1209 00116$:
      0062B6 90 00 00         [24] 1210 	mov	dptr,#0x0000
      0062B9 22               [24] 1211 	ret
                                   1212 ;	tmk_core/protocol/ch555/usb_ak820.c:185: }
      0062BA                       1213 00119$:
                                   1214 ;	tmk_core/protocol/ch555/usb_ak820.c:187: if (index || interface >= TOTAL_INTERFACES) return 0;
      0062BA 90 08 3D         [24] 1215 	mov	dptr,#_descriptor_select_PARM_2
      0062BD E0               [24] 1216 	movx	a,@dptr
      0062BE 70 11            [24] 1217 	jnz	00120$
      0062C0 90 08 3E         [24] 1218 	mov	dptr,#_descriptor_select_PARM_3
      0062C3 E0               [24] 1219 	movx	a,@dptr
      0062C4 FD               [12] 1220 	mov	r5,a
      0062C5 A3               [24] 1221 	inc	dptr
      0062C6 E0               [24] 1222 	movx	a,@dptr
      0062C7 FE               [12] 1223 	mov	r6,a
      0062C8 C3               [12] 1224 	clr	c
      0062C9 ED               [12] 1225 	mov	a,r5
      0062CA 94 03            [12] 1226 	subb	a,#0x03
      0062CC EE               [12] 1227 	mov	a,r6
      0062CD 94 00            [12] 1228 	subb	a,#0x00
      0062CF 40 04            [24] 1229 	jc	00121$
      0062D1                       1230 00120$:
      0062D1 90 00 00         [24] 1231 	mov	dptr,#0x0000
      0062D4 22               [24] 1232 	ret
      0062D5                       1233 00121$:
                                   1234 ;	tmk_core/protocol/ch555/usb_ak820.c:188: if (type == USB_DESCR_TYP_REPORT || type == USB_DESCR_TYP_HID) {
      0062D5 BF 22 02         [24] 1235 	cjne	r7,#0x22,00246$
      0062D8 80 03            [24] 1236 	sjmp	00127$
      0062DA                       1237 00246$:
      0062DA BF 21 5D         [24] 1238 	cjne	r7,#0x21,00128$
      0062DD                       1239 00127$:
                                   1240 ;	tmk_core/protocol/ch555/usb_ak820.c:189: const USB_HID_Descriptor_HID_t __code *hid = interface_descriptors[(uint8_t)interface].hid;
      0062DD ED               [12] 1241 	mov	a,r5
      0062DE 75 F0 04         [24] 1242 	mov	b,#0x04
      0062E1 A4               [48] 1243 	mul	ab
      0062E2 24 FC            [12] 1244 	add	a, #_interface_descriptors
      0062E4 FE               [12] 1245 	mov	r6,a
      0062E5 74 BF            [12] 1246 	mov	a,#(_interface_descriptors >> 8)
      0062E7 35 F0            [12] 1247 	addc	a, b
      0062E9 FF               [12] 1248 	mov	r7,a
      0062EA 8E 82            [24] 1249 	mov	dpl,r6
      0062EC 8F 83            [24] 1250 	mov	dph,r7
      0062EE A3               [24] 1251 	inc	dptr
      0062EF A3               [24] 1252 	inc	dptr
      0062F0 E4               [12] 1253 	clr	a
      0062F1 93               [24] 1254 	movc	a,@a+dptr
      0062F2 FC               [12] 1255 	mov	r4,a
      0062F3 A3               [24] 1256 	inc	dptr
      0062F4 E4               [12] 1257 	clr	a
      0062F5 93               [24] 1258 	movc	a,@a+dptr
                                   1259 ;	tmk_core/protocol/ch555/usb_ak820.c:190: if (!hid) return 0;
      0062F6 FD               [12] 1260 	mov	r5,a
      0062F7 4C               [12] 1261 	orl	a,r4
      0062F8 70 04            [24] 1262 	jnz	00124$
      0062FA 90 00 00         [24] 1263 	mov	dptr,#0x0000
      0062FD 22               [24] 1264 	ret
      0062FE                       1265 00124$:
                                   1266 ;	tmk_core/protocol/ch555/usb_ak820.c:191: if (type == USB_DESCR_TYP_REPORT) {
      0062FE 90 08 40         [24] 1267 	mov	dptr,#_descriptor_select_type_10000_272
      006301 E0               [24] 1268 	movx	a,@dptr
      006302 FB               [12] 1269 	mov	r3,a
      006303 BB 22 28         [24] 1270 	cjne	r3,#0x22,00126$
                                   1271 ;	tmk_core/protocol/ch555/usb_ak820.c:192: control_pointer = interface_descriptors[(uint8_t)interface].report;
      006306 8E 82            [24] 1272 	mov	dpl,r6
      006308 8F 83            [24] 1273 	mov	dph,r7
      00630A E4               [12] 1274 	clr	a
      00630B 93               [24] 1275 	movc	a,@a+dptr
      00630C FE               [12] 1276 	mov	r6,a
      00630D A3               [24] 1277 	inc	dptr
      00630E E4               [12] 1278 	clr	a
      00630F 93               [24] 1279 	movc	a,@a+dptr
      006310 FF               [12] 1280 	mov	r7,a
      006311 90 08 3B         [24] 1281 	mov	dptr,#_control_pointer
      006314 EE               [12] 1282 	mov	a,r6
      006315 F0               [24] 1283 	movx	@dptr,a
      006316 EF               [12] 1284 	mov	a,r7
      006317 A3               [24] 1285 	inc	dptr
      006318 F0               [24] 1286 	movx	@dptr,a
                                   1287 ;	tmk_core/protocol/ch555/usb_ak820.c:193: return hid->HIDReportLength;
      006319 74 07            [12] 1288 	mov	a,#0x07
      00631B 2C               [12] 1289 	add	a, r4
      00631C F5 82            [12] 1290 	mov	dpl,a
      00631E E4               [12] 1291 	clr	a
      00631F 3D               [12] 1292 	addc	a, r5
      006320 F5 83            [12] 1293 	mov	dph,a
      006322 E4               [12] 1294 	clr	a
      006323 93               [24] 1295 	movc	a,@a+dptr
      006324 FE               [12] 1296 	mov	r6,a
      006325 A3               [24] 1297 	inc	dptr
      006326 E4               [12] 1298 	clr	a
      006327 93               [24] 1299 	movc	a,@a+dptr
      006328 FF               [12] 1300 	mov	r7,a
      006329 8E 82            [24] 1301 	mov	dpl, r6
      00632B 8F 83            [24] 1302 	mov	dph, r7
      00632D 22               [24] 1303 	ret
      00632E                       1304 00126$:
                                   1305 ;	tmk_core/protocol/ch555/usb_ak820.c:195: control_pointer = (const uint8_t __code *)hid;
      00632E 90 08 3B         [24] 1306 	mov	dptr,#_control_pointer
      006331 EC               [12] 1307 	mov	a,r4
      006332 F0               [24] 1308 	movx	@dptr,a
      006333 ED               [12] 1309 	mov	a,r5
      006334 A3               [24] 1310 	inc	dptr
      006335 F0               [24] 1311 	movx	@dptr,a
                                   1312 ;	tmk_core/protocol/ch555/usb_ak820.c:196: return 9;
      006336 90 00 09         [24] 1313 	mov	dptr,#0x0009
      006339 22               [24] 1314 	ret
      00633A                       1315 00128$:
                                   1316 ;	tmk_core/protocol/ch555/usb_ak820.c:198: return 0;
      00633A 90 00 00         [24] 1317 	mov	dptr,#0x0000
                                   1318 ;	tmk_core/protocol/ch555/usb_ak820.c:199: }
      00633D 22               [24] 1319 	ret
                                   1320 ;------------------------------------------------------------
                                   1321 ;Allocation info for local variables in function 'control_setup'
                                   1322 ;------------------------------------------------------------
                                   1323 ;sloc1         Allocated with name '_control_setup_sloc1_1_0'
                                   1324 ;sloc3         Allocated with name '_control_setup_sloc3_1_0'
                                   1325 ;sloc4         Allocated with name '_control_setup_sloc4_1_0'
                                   1326 ;type          Allocated with name '_control_setup_type_10000_290'
                                   1327 ;value         Allocated with name '_control_setup_value_10000_290'
                                   1328 ;index         Allocated with name '_control_setup_index_10000_290'
                                   1329 ;length        Allocated with name '_control_setup_length_10000_290'
                                   1330 ;endpoint      Allocated with name '_control_setup_endpoint_10000_290'
                                   1331 ;i             Allocated with name '_control_setup_i_10000_290'
                                   1332 ;offset        Allocated with name '_control_setup_offset_10000_290'
                                   1333 ;report_id     Allocated with name '_control_setup_report_id_10000_290'
                                   1334 ;------------------------------------------------------------
                                   1335 ;	tmk_core/protocol/ch555/usb_ak820.c:201: static void control_setup(void) {
                                   1336 ;	-----------------------------------------
                                   1337 ;	 function control_setup
                                   1338 ;	-----------------------------------------
      00633E                       1339 _control_setup:
                                   1340 ;	tmk_core/protocol/ch555/usb_ak820.c:202: uint8_t type = pD0_SETUP_REQ->bRequestType;
      00633E 90 10 00         [24] 1341 	mov	dptr,#0x1000
      006341 E0               [24] 1342 	movx	a,@dptr
      006342 FF               [12] 1343 	mov	r7,a
                                   1344 ;	tmk_core/protocol/ch555/usb_ak820.c:203: uint16_t value = pD0_SETUP_REQ->wValueL | ((uint16_t)pD0_SETUP_REQ->wValueH << 8);
      006343 A3               [24] 1345 	inc	dptr
      006344 A3               [24] 1346 	inc	dptr
      006345 E0               [24] 1347 	movx	a,@dptr
      006346 FE               [12] 1348 	mov	r6,a
      006347 A3               [24] 1349 	inc	dptr
      006348 E0               [24] 1350 	movx	a,@dptr
      006349 FC               [12] 1351 	mov	r4,a
      00634A 7D 00            [12] 1352 	mov	r5,#0x00
      00634C 8E 03            [24] 1353 	mov	ar3,r6
      00634E 7E 00            [12] 1354 	mov	r6,#0x00
      006350 ED               [12] 1355 	mov	a,r5
      006351 4B               [12] 1356 	orl	a,r3
      006352 FD               [12] 1357 	mov	r5,a
      006353 EC               [12] 1358 	mov	a,r4
      006354 4E               [12] 1359 	orl	a,r6
      006355 FE               [12] 1360 	mov	r6,a
                                   1361 ;	tmk_core/protocol/ch555/usb_ak820.c:204: uint16_t index = pD0_SETUP_REQ->wIndexL | ((uint16_t)pD0_SETUP_REQ->wIndexH << 8);
      006356 A3               [24] 1362 	inc	dptr
      006357 E0               [24] 1363 	movx	a,@dptr
      006358 FC               [12] 1364 	mov	r4,a
      006359 A3               [24] 1365 	inc	dptr
      00635A E0               [24] 1366 	movx	a,@dptr
      00635B FA               [12] 1367 	mov	r2,a
      00635C 7B 00            [12] 1368 	mov	r3,#0x00
      00635E 8C 01            [24] 1369 	mov	ar1,r4
      006360 7C 00            [12] 1370 	mov	r4,#0x00
      006362 EB               [12] 1371 	mov	a,r3
      006363 49               [12] 1372 	orl	a,r1
      006364 FB               [12] 1373 	mov	r3,a
      006365 EA               [12] 1374 	mov	a,r2
      006366 4C               [12] 1375 	orl	a,r4
      006367 FC               [12] 1376 	mov	r4,a
                                   1377 ;	tmk_core/protocol/ch555/usb_ak820.c:208: __bit valid_interface = index < TOTAL_INTERFACES;
      006368 C3               [12] 1378 	clr	c
      006369 EB               [12] 1379 	mov	a,r3
      00636A 94 03            [12] 1380 	subb	a,#0x03
      00636C EC               [12] 1381 	mov	a,r4
      00636D 94 00            [12] 1382 	subb	a,#0x00
      00636F 92 15            [24] 1383 	mov	_control_setup_valid_interface_10000_290,c
                                   1384 ;	tmk_core/protocol/ch555/usb_ak820.c:209: __bit zero_index = !index;
      006371 EB               [12] 1385 	mov	a,r3
      006372 4C               [12] 1386 	orl	a,r4
      006373 B4 01 00         [24] 1387 	cjne	a,#0x01,01201$
      006376                       1388 01201$:
      006376 92 16            [24] 1389 	mov	_control_setup_zero_index_10000_290,c
                                   1390 ;	tmk_core/protocol/ch555/usb_ak820.c:210: __bit zero_value = !value;
      006378 ED               [12] 1391 	mov	a,r5
      006379 4E               [12] 1392 	orl	a,r6
      00637A B4 01 00         [24] 1393 	cjne	a,#0x01,01202$
      00637D                       1394 01202$:
                                   1395 ;	assignBit
      00637D 92 19            [24] 1396 	mov  _control_setup_sloc0_1_0,c
      00637F 92 17            [24] 1397 	mov	_control_setup_zero_value_10000_290,c
                                   1398 ;	tmk_core/protocol/ch555/usb_ak820.c:214: uint8_t offset = 0;
      006381 90 08 43         [24] 1399 	mov	dptr,#_control_setup_offset_10000_290
      006384 E4               [12] 1400 	clr	a
      006385 F0               [24] 1401 	movx	@dptr,a
                                   1402 ;	tmk_core/protocol/ch555/usb_ak820.c:216: if (raw_state == RAW_RX) raw_state = RAW_IDLE; /* abort only unfinished OUT */
      006386 90 07 E6         [24] 1403 	mov	dptr,#_raw_state
      006389 E0               [24] 1404 	movx	a,@dptr
      00638A FA               [12] 1405 	mov	r2,a
      00638B BA 01 05         [24] 1406 	cjne	r2,#0x01,00102$
      00638E 90 07 E6         [24] 1407 	mov	dptr,#_raw_state
      006391 E4               [12] 1408 	clr	a
      006392 F0               [24] 1409 	movx	@dptr,a
      006393                       1410 00102$:
                                   1411 ;	tmk_core/protocol/ch555/usb_ak820.c:217: output_kind = OUTPUT_NONE;
      006393 C0 07            [24] 1412 	push	ar7
      006395 90 08 38         [24] 1413 	mov	dptr,#_output_kind
      006398 E4               [12] 1414 	clr	a
      006399 F0               [24] 1415 	movx	@dptr,a
                                   1416 ;	tmk_core/protocol/ch555/usb_ak820.c:218: control_phase = CTRL_IDLE;
      00639A 90 08 37         [24] 1417 	mov	dptr,#_control_phase
      00639D F0               [24] 1418 	movx	@dptr,a
                                   1419 ;	tmk_core/protocol/ch555/usb_ak820.c:219: control_zlp = 0;
      00639E 90 08 3A         [24] 1420 	mov	dptr,#_control_zlp
      0063A1 F0               [24] 1421 	movx	@dptr,a
                                   1422 ;	tmk_core/protocol/ch555/usb_ak820.c:220: D0SetupReqCode = pD0_SETUP_REQ->bRequest;
      0063A2 90 10 01         [24] 1423 	mov	dptr,#0x1001
      0063A5 E0               [24] 1424 	movx	a,@dptr
      0063A6 90 07 D8         [24] 1425 	mov	dptr,#_D0SetupReqCode
      0063A9 F0               [24] 1426 	movx	@dptr,a
                                   1427 ;	tmk_core/protocol/ch555/usb_ak820.c:221: D0SetupLen = pD0_SETUP_REQ->wLengthL | ((uint16_t)pD0_SETUP_REQ->wLengthH << 8);
      0063AA 90 10 06         [24] 1428 	mov	dptr,#0x1006
      0063AD E0               [24] 1429 	movx	a,@dptr
      0063AE FA               [12] 1430 	mov	r2,a
      0063AF A3               [24] 1431 	inc	dptr
      0063B0 E0               [24] 1432 	movx	a,@dptr
      0063B1 F9               [12] 1433 	mov	r1,a
      0063B2 78 00            [12] 1434 	mov	r0,#0x00
      0063B4 7F 00            [12] 1435 	mov	r7,#0x00
      0063B6 90 07 D9         [24] 1436 	mov	dptr,#_D0SetupLen
      0063B9 E8               [12] 1437 	mov	a,r0
      0063BA 4A               [12] 1438 	orl	a,r2
      0063BB F0               [24] 1439 	movx	@dptr,a
      0063BC E9               [12] 1440 	mov	a,r1
      0063BD 4F               [12] 1441 	orl	a,r7
      0063BE A3               [24] 1442 	inc	dptr
      0063BF F0               [24] 1443 	movx	@dptr,a
                                   1444 ;	tmk_core/protocol/ch555/usb_ak820.c:222: zero_length = !D0SetupLen;
      0063C0 90 07 D9         [24] 1445 	mov	dptr,#_D0SetupLen
      0063C3 E0               [24] 1446 	movx	a,@dptr
      0063C4 FA               [12] 1447 	mov	r2,a
      0063C5 A3               [24] 1448 	inc	dptr
      0063C6 E0               [24] 1449 	movx	a,@dptr
      0063C7 4A               [12] 1450 	orl	a,r2
      0063C8 B4 01 00         [24] 1451 	cjne	a,#0x01,01205$
      0063CB                       1452 01205$:
      0063CB 92 18            [24] 1453 	mov	_control_setup_zero_length_10000_290,c
                                   1454 ;	tmk_core/protocol/ch555/usb_ak820.c:223: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_ACK | UEP_T_RES_NAK;
      0063CD 90 22 00         [24] 1455 	mov	dptr,#0x2200
      0063D0 74 C2            [12] 1456 	mov	a,#0xc2
      0063D2 F0               [24] 1457 	movx	@dptr,a
                                   1458 ;	tmk_core/protocol/ch555/usb_ak820.c:224: D0_EP0T_L = 0;
      0063D3 90 22 08         [24] 1459 	mov	dptr,#0x2208
      0063D6 E4               [12] 1460 	clr	a
      0063D7 F0               [24] 1461 	movx	@dptr,a
                                   1462 ;	tmk_core/protocol/ch555/usb_ak820.c:228: switch (D0SetupReqCode) {
      0063D8 90 07 D8         [24] 1463 	mov	dptr,#_D0SetupReqCode
      0063DB E0               [24] 1464 	movx	a,@dptr
      0063DC F5 16            [12] 1465 	mov	_control_setup_sloc1_1_0,a
      0063DE C3               [12] 1466 	clr	c
      0063DF 74 0B            [12] 1467 	mov	a,#0x0b
      0063E1 95 16            [12] 1468 	subb	a,_control_setup_sloc1_1_0
      0063E3 D0 07            [24] 1469 	pop	ar7
      0063E5 50 03            [24] 1470 	jnc	01206$
      0063E7 02 61 25         [24] 1471 	ljmp	_control_stall
      0063EA                       1472 01206$:
                                   1473 ;	free result
      0063EA E5 16            [12] 1474 	mov	a,_control_setup_sloc1_1_0
      0063EC F5 F0            [12] 1475 	mov	b,a
      0063EE 24 0B            [12] 1476 	add	a,#(01207$-3-.)
      0063F0 83               [24] 1477 	movc	a,@a+pc
      0063F1 F5 82            [12] 1478 	mov	dpl,a
      0063F3 E5 F0            [12] 1479 	mov	a,b
      0063F5 24 10            [12] 1480 	add	a,#(01208$-3-.)
      0063F7 83               [24] 1481 	movc	a,@a+pc
      0063F8 F5 83            [12] 1482 	mov	dph,a
      0063FA E4               [12] 1483 	clr	a
      0063FB 73               [24] 1484 	jmp	@a+dptr
      0063FC                       1485 01207$:
      0063FC A4                    1486 	.db	00188$
      0063FD 4A                    1487 	.db	00205$
      0063FE 8D                    1488 	.db	00282$
      0063FF 4A                    1489 	.db	00205$
      006400 D1                    1490 	.db	00290$
      006401 CE                    1491 	.db	00116$
      006402 14                    1492 	.db	00103$
      006403 D1                    1493 	.db	00290$
      006404 D3                    1494 	.db	00150$
      006405 F7                    1495 	.db	00123$
      006406 03                    1496 	.db	00157$
      006407 56                    1497 	.db	00173$
      006408                       1498 01208$:
      006408 66                    1499 	.db	00188$>>8
      006409 67                    1500 	.db	00205$>>8
      00640A 6A                    1501 	.db	00282$>>8
      00640B 67                    1502 	.db	00205$>>8
      00640C 6A                    1503 	.db	00290$>>8
      00640D 64                    1504 	.db	00116$>>8
      00640E 64                    1505 	.db	00103$>>8
      00640F 6A                    1506 	.db	00290$>>8
      006410 65                    1507 	.db	00150$>>8
      006411 64                    1508 	.db	00123$>>8
      006412 66                    1509 	.db	00157$>>8
      006413 66                    1510 	.db	00173$>>8
                                   1511 ;	tmk_core/protocol/ch555/usb_ak820.c:229: case USB_GET_DESCRIPTOR:
      006414                       1512 00103$:
                                   1513 ;	tmk_core/protocol/ch555/usb_ak820.c:230: if (type == 0x80 || type == 0x81) {
      006414 BF 80 02         [24] 1514 	cjne	r7,#0x80,01209$
      006417 80 08            [24] 1515 	sjmp	00112$
      006419                       1516 01209$:
      006419 BF 81 02         [24] 1517 	cjne	r7,#0x81,01210$
      00641C 80 03            [24] 1518 	sjmp	01211$
      00641E                       1519 01210$:
      00641E 02 61 25         [24] 1520 	ljmp	_control_stall
      006421                       1521 01211$:
      006421                       1522 00112$:
                                   1523 ;	tmk_core/protocol/ch555/usb_ak820.c:231: if (((value >> 8) == USB_DESCR_TYP_HID || (value >> 8) == USB_DESCR_TYP_REPORT) != (type == 0x81)) {
      006421 8E 01            [24] 1524 	mov	ar1,r6
      006423 B9 21 02         [24] 1525 	cjne	r1,#0x21,01212$
      006426 80 09            [24] 1526 	sjmp	00301$
      006428                       1527 01212$:
      006428 B9 22 02         [24] 1528 	cjne	r1,#0x22,01213$
      00642B 80 04            [24] 1529 	sjmp	00301$
      00642D                       1530 01213$:
                                   1531 ;	assignBit
      00642D C2 1A            [12] 1532 	clr	_control_setup_sloc2_1_0
      00642F 80 02            [24] 1533 	sjmp	00302$
      006431                       1534 00301$:
                                   1535 ;	assignBit
      006431 D2 1A            [12] 1536 	setb	_control_setup_sloc2_1_0
      006433                       1537 00302$:
      006433 E4               [12] 1538 	clr	a
      006434 BF 81 01         [24] 1539 	cjne	r7,#0x81,01214$
      006437 04               [12] 1540 	inc	a
      006438                       1541 01214$:
      006438 FA               [12] 1542 	mov	r2,a
      006439 A2 1A            [12] 1543 	mov	c,_control_setup_sloc2_1_0
      00643B E4               [12] 1544 	clr	a
      00643C 33               [12] 1545 	rlc	a
      00643D B5 02 02         [24] 1546 	cjne	a,ar2,01216$
      006440 80 03            [24] 1547 	sjmp	00105$
      006442                       1548 01216$:
                                   1549 ;	tmk_core/protocol/ch555/usb_ak820.c:232: control_stall(); return;
      006442 02 61 25         [24] 1550 	ljmp	_control_stall
      006445                       1551 00105$:
                                   1552 ;	tmk_core/protocol/ch555/usb_ak820.c:234: length = descriptor_select(value >> 8, value, index);
      006445 8E 02            [24] 1553 	mov	ar2,r6
      006447 90 08 3D         [24] 1554 	mov	dptr,#_descriptor_select_PARM_2
      00644A ED               [12] 1555 	mov	a,r5
      00644B F0               [24] 1556 	movx	@dptr,a
      00644C 90 08 3E         [24] 1557 	mov	dptr,#_descriptor_select_PARM_3
      00644F EB               [12] 1558 	mov	a,r3
      006450 F0               [24] 1559 	movx	@dptr,a
      006451 EC               [12] 1560 	mov	a,r4
      006452 A3               [24] 1561 	inc	dptr
      006453 F0               [24] 1562 	movx	@dptr,a
      006454 8A 82            [24] 1563 	mov	dpl, r2
      006456 12 61 C3         [24] 1564 	lcall	_descriptor_select
      006459 85 82 17         [24] 1565 	mov	_control_setup_sloc3_1_0,dpl
      00645C 85 83 18         [24] 1566 	mov	(_control_setup_sloc3_1_0 + 1),dph
                                   1567 ;	tmk_core/protocol/ch555/usb_ak820.c:235: if (!length) { control_stall(); return; }
      00645F E5 17            [12] 1568 	mov	a,_control_setup_sloc3_1_0
      006461 45 18            [12] 1569 	orl	a,(_control_setup_sloc3_1_0 + 1)
      006463 70 03            [24] 1570 	jnz	00107$
      006465 02 61 25         [24] 1571 	ljmp	_control_stall
      006468                       1572 00107$:
                                   1573 ;	tmk_core/protocol/ch555/usb_ak820.c:236: control_zlp = length < D0SetupLen && !(length & (DEF_ENDP0_SIZE - 1));
      006468 90 07 D9         [24] 1574 	mov	dptr,#_D0SetupLen
      00646B E0               [24] 1575 	movx	a,@dptr
      00646C F8               [12] 1576 	mov	r0,a
      00646D A3               [24] 1577 	inc	dptr
      00646E E0               [24] 1578 	movx	a,@dptr
      00646F FA               [12] 1579 	mov	r2,a
      006470 C3               [12] 1580 	clr	c
      006471 E5 17            [12] 1581 	mov	a,_control_setup_sloc3_1_0
      006473 98               [12] 1582 	subb	a,r0
      006474 E5 18            [12] 1583 	mov	a,(_control_setup_sloc3_1_0 + 1)
      006476 9A               [12] 1584 	subb	a,r2
      006477 50 06            [24] 1585 	jnc	00303$
      006479 E5 17            [12] 1586 	mov	a,_control_setup_sloc3_1_0
      00647B 54 3F            [12] 1587 	anl	a,#0x3f
      00647D 60 04            [24] 1588 	jz	00304$
      00647F                       1589 00303$:
                                   1590 ;	assignBit
      00647F C2 1A            [12] 1591 	clr	_control_setup_sloc2_1_0
      006481 80 02            [24] 1592 	sjmp	00305$
      006483                       1593 00304$:
                                   1594 ;	assignBit
      006483 D2 1A            [12] 1595 	setb	_control_setup_sloc2_1_0
      006485                       1596 00305$:
      006485 90 08 3A         [24] 1597 	mov	dptr,#_control_zlp
      006488 A2 1A            [12] 1598 	mov	c,_control_setup_sloc2_1_0
      00648A E4               [12] 1599 	clr	a
      00648B 33               [12] 1600 	rlc	a
      00648C F0               [24] 1601 	movx	@dptr,a
                                   1602 ;	tmk_core/protocol/ch555/usb_ak820.c:237: if (D0SetupLen > length) D0SetupLen = length;
      00648D 90 07 D9         [24] 1603 	mov	dptr,#_D0SetupLen
      006490 E0               [24] 1604 	movx	a,@dptr
      006491 F9               [12] 1605 	mov	r1,a
      006492 A3               [24] 1606 	inc	dptr
      006493 E0               [24] 1607 	movx	a,@dptr
      006494 FA               [12] 1608 	mov	r2,a
      006495 C3               [12] 1609 	clr	c
      006496 E5 17            [12] 1610 	mov	a,_control_setup_sloc3_1_0
      006498 99               [12] 1611 	subb	a,r1
      006499 E5 18            [12] 1612 	mov	a,(_control_setup_sloc3_1_0 + 1)
      00649B 9A               [12] 1613 	subb	a,r2
      00649C 50 0A            [24] 1614 	jnc	00109$
                                   1615 ;	free result
      00649E 90 07 D9         [24] 1616 	mov	dptr,#_D0SetupLen
      0064A1 E5 17            [12] 1617 	mov	a,_control_setup_sloc3_1_0
      0064A3 F0               [24] 1618 	movx	@dptr,a
      0064A4 E5 18            [12] 1619 	mov	a,(_control_setup_sloc3_1_0 + 1)
      0064A6 A3               [24] 1620 	inc	dptr
      0064A7 F0               [24] 1621 	movx	@dptr,a
      0064A8                       1622 00109$:
                                   1623 ;	tmk_core/protocol/ch555/usb_ak820.c:238: control_phase = D0SetupLen ? CTRL_DATA_IN : CTRL_STATUS_OUT;
      0064A8 90 07 D9         [24] 1624 	mov	dptr,#_D0SetupLen
      0064AB E0               [24] 1625 	movx	a,@dptr
      0064AC F9               [12] 1626 	mov	r1,a
      0064AD A3               [24] 1627 	inc	dptr
      0064AE E0               [24] 1628 	movx	a,@dptr
      0064AF 49               [12] 1629 	orl	a,r1
      0064B0 60 04            [24] 1630 	jz	00306$
      0064B2 7A 01            [12] 1631 	mov	r2,#0x01
      0064B4 80 02            [24] 1632 	sjmp	00307$
      0064B6                       1633 00306$:
      0064B6 7A 02            [12] 1634 	mov	r2,#0x02
      0064B8                       1635 00307$:
      0064B8 90 08 37         [24] 1636 	mov	dptr,#_control_phase
      0064BB EA               [12] 1637 	mov	a,r2
      0064BC F0               [24] 1638 	movx	@dptr,a
                                   1639 ;	tmk_core/protocol/ch555/usb_ak820.c:239: if (D0SetupLen) control_next();
      0064BD 90 07 D9         [24] 1640 	mov	dptr,#_D0SetupLen
      0064C0 E0               [24] 1641 	movx	a,@dptr
      0064C1 F9               [12] 1642 	mov	r1,a
      0064C2 A3               [24] 1643 	inc	dptr
      0064C3 E0               [24] 1644 	movx	a,@dptr
      0064C4 49               [12] 1645 	orl	a,r1
      0064C5 60 03            [24] 1646 	jz	00111$
                                   1647 ;	tmk_core/protocol/ch555/usb_ak820.c:240: return;
      0064C7 02 61 47         [24] 1648 	ljmp	_control_next
      0064CA                       1649 00111$:
      0064CA 22               [24] 1650 	ret
                                   1651 ;	tmk_core/protocol/ch555/usb_ak820.c:241: } else { control_stall(); return; }
      0064CB 02 61 25         [24] 1652 	ljmp	_control_stall
                                   1653 ;	tmk_core/protocol/ch555/usb_ak820.c:242: case USB_SET_ADDRESS:
      0064CE                       1654 00116$:
                                   1655 ;	tmk_core/protocol/ch555/usb_ak820.c:243: if (type == 0x00 && zero_index && zero_length && value <= 127) {
      0064CE EF               [12] 1656 	mov	a,r7
      0064CF 70 23            [24] 1657 	jnz	00118$
      0064D1 30 16 20         [24] 1658 	jnb	_control_setup_zero_index_10000_290,00118$
      0064D4 30 18 1D         [24] 1659 	jnb	_control_setup_zero_length_10000_290,00118$
      0064D7 8D 01            [24] 1660 	mov	ar1,r5
      0064D9 8E 02            [24] 1661 	mov	ar2,r6
      0064DB C3               [12] 1662 	clr	c
      0064DC 74 7F            [12] 1663 	mov	a,#0x7f
      0064DE 99               [12] 1664 	subb	a,r1
      0064DF E4               [12] 1665 	clr	a
      0064E0 9A               [12] 1666 	subb	a,r2
      0064E1 40 11            [24] 1667 	jc	00118$
                                   1668 ;	free result
                                   1669 ;	tmk_core/protocol/ch555/usb_ak820.c:244: D0SetupLen = value; /* applied after status-IN ACK */
      0064E3 90 07 D9         [24] 1670 	mov	dptr,#_D0SetupLen
      0064E6 ED               [12] 1671 	mov	a,r5
      0064E7 F0               [24] 1672 	movx	@dptr,a
      0064E8 EE               [12] 1673 	mov	a,r6
      0064E9 A3               [24] 1674 	inc	dptr
      0064EA F0               [24] 1675 	movx	@dptr,a
                                   1676 ;	tmk_core/protocol/ch555/usb_ak820.c:245: control_phase = CTRL_STATUS_IN;
      0064EB 90 08 37         [24] 1677 	mov	dptr,#_control_phase
      0064EE 74 03            [12] 1678 	mov	a,#0x03
      0064F0 F0               [24] 1679 	movx	@dptr,a
      0064F1 02 6A D4         [24] 1680 	ljmp	00291$
      0064F4                       1681 00118$:
                                   1682 ;	tmk_core/protocol/ch555/usb_ak820.c:246: } else { control_stall(); return; }
      0064F4 02 61 25         [24] 1683 	ljmp	_control_stall
                                   1684 ;	tmk_core/protocol/ch555/usb_ak820.c:248: case USB_SET_CONFIGURATION: /* HID_SET_REPORT has the same request byte. */
      0064F7                       1685 00123$:
                                   1686 ;	tmk_core/protocol/ch555/usb_ak820.c:249: if (type == 0x00 && zero_index && zero_length && value <= 1) {
      0064F7 EF               [12] 1687 	mov	a,r7
      0064F8 70 3C            [24] 1688 	jnz	00145$
      0064FA 30 16 39         [24] 1689 	jnb	_control_setup_zero_index_10000_290,00145$
      0064FD 30 18 36         [24] 1690 	jnb	_control_setup_zero_length_10000_290,00145$
      006500 8D 01            [24] 1691 	mov	ar1,r5
      006502 8E 02            [24] 1692 	mov	ar2,r6
      006504 C3               [12] 1693 	clr	c
      006505 74 01            [12] 1694 	mov	a,#0x01
      006507 99               [12] 1695 	subb	a,r1
      006508 E4               [12] 1696 	clr	a
      006509 9A               [12] 1697 	subb	a,r2
      00650A 40 2A            [24] 1698 	jc	00145$
                                   1699 ;	free result
                                   1700 ;	tmk_core/protocol/ch555/usb_ak820.c:250: endpoints_reset();
      00650C C0 06            [24] 1701 	push	ar6
      00650E C0 05            [24] 1702 	push	ar5
      006510 12 60 CA         [24] 1703 	lcall	_endpoints_reset
      006513 D0 05            [24] 1704 	pop	ar5
      006515 D0 06            [24] 1705 	pop	ar6
                                   1706 ;	tmk_core/protocol/ch555/usb_ak820.c:251: D0UsbConfig = value;
      006517 90 07 DE         [24] 1707 	mov	dptr,#_D0UsbConfig
      00651A ED               [12] 1708 	mov	a,r5
      00651B F0               [24] 1709 	movx	@dptr,a
                                   1710 ;	tmk_core/protocol/ch555/usb_ak820.c:252: USB_EnumStatus = value != 0;
      00651C A2 19            [12] 1711 	mov	c,_control_setup_sloc0_1_0
      00651E B3               [12] 1712 	cpl	c
      00651F 92 1A            [24] 1713 	mov	_control_setup_sloc2_1_0,c
      006521 90 07 DF         [24] 1714 	mov	dptr,#_USB_EnumStatus
      006524 E4               [12] 1715 	clr	a
      006525 33               [12] 1716 	rlc	a
      006526 F0               [24] 1717 	movx	@dptr,a
                                   1718 ;	tmk_core/protocol/ch555/usb_ak820.c:253: keyboard_reset = 1;
      006527 90 08 08         [24] 1719 	mov	dptr,#_keyboard_reset
      00652A 74 01            [12] 1720 	mov	a,#0x01
      00652C F0               [24] 1721 	movx	@dptr,a
                                   1722 ;	tmk_core/protocol/ch555/usb_ak820.c:254: control_phase = CTRL_STATUS_IN;
      00652D 90 08 37         [24] 1723 	mov	dptr,#_control_phase
      006530 74 03            [12] 1724 	mov	a,#0x03
      006532 F0               [24] 1725 	movx	@dptr,a
      006533 02 6A D4         [24] 1726 	ljmp	00291$
      006536                       1727 00145$:
                                   1728 ;	tmk_core/protocol/ch555/usb_ak820.c:255: } else if (type == 0x21 && D0UsbConfig) {
      006536 BF 21 02         [24] 1729 	cjne	r7,#0x21,01231$
      006539 80 03            [24] 1730 	sjmp	01232$
      00653B                       1731 01231$:
      00653B 02 61 25         [24] 1732 	ljmp	_control_stall
      00653E                       1733 01232$:
      00653E 90 07 DE         [24] 1734 	mov	dptr,#_D0UsbConfig
      006541 E0               [24] 1735 	movx	a,@dptr
      006542 70 03            [24] 1736 	jnz	01233$
      006544 02 61 25         [24] 1737 	ljmp	_control_stall
      006547                       1738 01233$:
                                   1739 ;	tmk_core/protocol/ch555/usb_ak820.c:256: if (index == RAW_INTERFACE && value == 0x0200 && D0SetupLen == RAW_EPSIZE && raw_state == RAW_IDLE) {
      006547 BB 01 2D         [24] 1740 	cjne	r3,#0x01,00135$
      00654A BC 00 2A         [24] 1741 	cjne	r4,#0x00,00135$
      00654D 8D 01            [24] 1742 	mov	ar1,r5
      00654F 8E 02            [24] 1743 	mov	ar2,r6
      006551 B9 00 23         [24] 1744 	cjne	r1,#0x00,00135$
      006554 BA 02 20         [24] 1745 	cjne	r2,#0x02,00135$
      006557 90 07 D9         [24] 1746 	mov	dptr,#_D0SetupLen
      00655A E0               [24] 1747 	movx	a,@dptr
      00655B F9               [12] 1748 	mov	r1,a
      00655C A3               [24] 1749 	inc	dptr
      00655D E0               [24] 1750 	movx	a,@dptr
      00655E FA               [12] 1751 	mov	r2,a
      00655F B9 20 15         [24] 1752 	cjne	r1,#0x20,00135$
      006562 BA 00 12         [24] 1753 	cjne	r2,#0x00,00135$
      006565 90 07 E6         [24] 1754 	mov	dptr,#_raw_state
      006568 E0               [24] 1755 	movx	a,@dptr
      006569 70 0C            [24] 1756 	jnz	00135$
                                   1757 ;	tmk_core/protocol/ch555/usb_ak820.c:257: raw_state = RAW_RX;
      00656B 90 07 E6         [24] 1758 	mov	dptr,#_raw_state
      00656E 74 01            [12] 1759 	mov	a,#0x01
      006570 F0               [24] 1760 	movx	@dptr,a
                                   1761 ;	tmk_core/protocol/ch555/usb_ak820.c:258: output_kind = OUTPUT_RAW;
      006571 90 08 38         [24] 1762 	mov	dptr,#_output_kind
      006574 F0               [24] 1763 	movx	@dptr,a
      006575 80 52            [24] 1764 	sjmp	00136$
      006577                       1765 00135$:
                                   1766 ;	tmk_core/protocol/ch555/usb_ak820.c:259: } else if (index == KEYBOARD_INTERFACE && value == 0x0200 && D0SetupLen == 1) {
      006577 EB               [12] 1767 	mov	a,r3
      006578 4C               [12] 1768 	orl	a,r4
      006579 70 20            [24] 1769 	jnz	00130$
      00657B 8D 01            [24] 1770 	mov	ar1,r5
      00657D 8E 02            [24] 1771 	mov	ar2,r6
      00657F B9 00 19         [24] 1772 	cjne	r1,#0x00,00130$
      006582 BA 02 16         [24] 1773 	cjne	r2,#0x02,00130$
      006585 90 07 D9         [24] 1774 	mov	dptr,#_D0SetupLen
      006588 E0               [24] 1775 	movx	a,@dptr
      006589 F9               [12] 1776 	mov	r1,a
      00658A A3               [24] 1777 	inc	dptr
      00658B E0               [24] 1778 	movx	a,@dptr
      00658C FA               [12] 1779 	mov	r2,a
      00658D B9 01 0B         [24] 1780 	cjne	r1,#0x01,00130$
      006590 BA 00 08         [24] 1781 	cjne	r2,#0x00,00130$
                                   1782 ;	tmk_core/protocol/ch555/usb_ak820.c:260: output_kind = OUTPUT_LED;
      006593 90 08 38         [24] 1783 	mov	dptr,#_output_kind
      006596 74 02            [12] 1784 	mov	a,#0x02
      006598 F0               [24] 1785 	movx	@dptr,a
      006599 80 2E            [24] 1786 	sjmp	00136$
      00659B                       1787 00130$:
                                   1788 ;	tmk_core/protocol/ch555/usb_ak820.c:262: } else if (index == SHARED_INTERFACE && value == (0x0200 | REPORT_ID_NKRO) && D0SetupLen == 2) {
      00659B BB 02 28         [24] 1789 	cjne	r3,#0x02,00125$
      00659E BC 00 25         [24] 1790 	cjne	r4,#0x00,00125$
      0065A1 8D 01            [24] 1791 	mov	ar1,r5
      0065A3 8E 02            [24] 1792 	mov	ar2,r6
      0065A5 B9 06 1E         [24] 1793 	cjne	r1,#0x06,00125$
      0065A8 BA 02 1B         [24] 1794 	cjne	r2,#0x02,00125$
      0065AB 90 07 D9         [24] 1795 	mov	dptr,#_D0SetupLen
      0065AE E0               [24] 1796 	movx	a,@dptr
      0065AF F9               [12] 1797 	mov	r1,a
      0065B0 A3               [24] 1798 	inc	dptr
      0065B1 E0               [24] 1799 	movx	a,@dptr
      0065B2 FA               [12] 1800 	mov	r2,a
      0065B3 B9 02 10         [24] 1801 	cjne	r1,#0x02,00125$
      0065B6 BA 00 0D         [24] 1802 	cjne	r2,#0x00,00125$
                                   1803 ;	tmk_core/protocol/ch555/usb_ak820.c:263: output_kind = OUTPUT_SHARED_LED;
      0065B9 90 08 38         [24] 1804 	mov	dptr,#_output_kind
      0065BC 74 03            [12] 1805 	mov	a,#0x03
      0065BE F0               [24] 1806 	movx	@dptr,a
                                   1807 ;	tmk_core/protocol/ch555/usb_ak820.c:264: output_report_id = REPORT_ID_NKRO;
      0065BF 90 08 39         [24] 1808 	mov	dptr,#_output_report_id
      0065C2 23               [12] 1809 	rl	a
      0065C3 F0               [24] 1810 	movx	@dptr,a
      0065C4 80 03            [24] 1811 	sjmp	00136$
      0065C6                       1812 00125$:
                                   1813 ;	tmk_core/protocol/ch555/usb_ak820.c:266: } else { control_stall(); return; }
      0065C6 02 61 25         [24] 1814 	ljmp	_control_stall
      0065C9                       1815 00136$:
                                   1816 ;	tmk_core/protocol/ch555/usb_ak820.c:267: control_phase = CTRL_DATA_OUT;
      0065C9 90 08 37         [24] 1817 	mov	dptr,#_control_phase
      0065CC 74 04            [12] 1818 	mov	a,#0x04
      0065CE F0               [24] 1819 	movx	@dptr,a
                                   1820 ;	tmk_core/protocol/ch555/usb_ak820.c:268: return; /* OUT data must arrive before status-IN becomes ACK */
      0065CF 22               [24] 1821 	ret
                                   1822 ;	tmk_core/protocol/ch555/usb_ak820.c:269: } else { control_stall(); return; }
      0065D0 02 61 25         [24] 1823 	ljmp	_control_stall
                                   1824 ;	tmk_core/protocol/ch555/usb_ak820.c:271: case USB_GET_CONFIGURATION:
      0065D3                       1825 00150$:
                                   1826 ;	tmk_core/protocol/ch555/usb_ak820.c:272: if (type == 0x80 && zero_index && zero_value && D0SetupLen == 1) {
      0065D3 BF 80 2A         [24] 1827 	cjne	r7,#0x80,00152$
      0065D6 30 16 27         [24] 1828 	jnb	_control_setup_zero_index_10000_290,00152$
      0065D9 30 17 24         [24] 1829 	jnb	_control_setup_zero_value_10000_290,00152$
      0065DC 90 07 D9         [24] 1830 	mov	dptr,#_D0SetupLen
      0065DF E0               [24] 1831 	movx	a,@dptr
      0065E0 F9               [12] 1832 	mov	r1,a
      0065E1 A3               [24] 1833 	inc	dptr
      0065E2 E0               [24] 1834 	movx	a,@dptr
      0065E3 FA               [12] 1835 	mov	r2,a
      0065E4 B9 01 19         [24] 1836 	cjne	r1,#0x01,00152$
      0065E7 BA 00 16         [24] 1837 	cjne	r2,#0x00,00152$
                                   1838 ;	tmk_core/protocol/ch555/usb_ak820.c:273: pD0_EP0_BUF[0] = D0UsbConfig;
      0065EA 90 07 DE         [24] 1839 	mov	dptr,#_D0UsbConfig
      0065ED E0               [24] 1840 	movx	a,@dptr
      0065EE 90 10 00         [24] 1841 	mov	dptr,#0x1000
      0065F1 F0               [24] 1842 	movx	@dptr,a
                                   1843 ;	tmk_core/protocol/ch555/usb_ak820.c:274: D0_EP0T_L = 1;
      0065F2 90 22 08         [24] 1844 	mov	dptr,#0x2208
      0065F5 74 01            [12] 1845 	mov	a,#0x01
      0065F7 F0               [24] 1846 	movx	@dptr,a
                                   1847 ;	tmk_core/protocol/ch555/usb_ak820.c:275: control_phase = CTRL_STATUS_OUT;
      0065F8 90 08 37         [24] 1848 	mov	dptr,#_control_phase
      0065FB 04               [12] 1849 	inc	a
      0065FC F0               [24] 1850 	movx	@dptr,a
      0065FD 02 6A D4         [24] 1851 	ljmp	00291$
      006600                       1852 00152$:
                                   1853 ;	tmk_core/protocol/ch555/usb_ak820.c:276: } else { control_stall(); return; }
      006600 02 61 25         [24] 1854 	ljmp	_control_stall
                                   1855 ;	tmk_core/protocol/ch555/usb_ak820.c:278: case USB_GET_INTERFACE: /* DEF_USB_SET_IDLE has the same request byte. */
      006603                       1856 00157$:
                                   1857 ;	tmk_core/protocol/ch555/usb_ak820.c:279: if (type == 0x81 && valid_interface && zero_value && D0SetupLen == 1 && D0UsbConfig) {
      006603 BF 81 2C         [24] 1858 	cjne	r7,#0x81,00167$
      006606 30 15 29         [24] 1859 	jnb	_control_setup_valid_interface_10000_290,00167$
      006609 30 17 26         [24] 1860 	jnb	_control_setup_zero_value_10000_290,00167$
      00660C 90 07 D9         [24] 1861 	mov	dptr,#_D0SetupLen
      00660F E0               [24] 1862 	movx	a,@dptr
      006610 F9               [12] 1863 	mov	r1,a
      006611 A3               [24] 1864 	inc	dptr
      006612 E0               [24] 1865 	movx	a,@dptr
      006613 FA               [12] 1866 	mov	r2,a
      006614 B9 01 1B         [24] 1867 	cjne	r1,#0x01,00167$
      006617 BA 00 18         [24] 1868 	cjne	r2,#0x00,00167$
      00661A 90 07 DE         [24] 1869 	mov	dptr,#_D0UsbConfig
      00661D E0               [24] 1870 	movx	a,@dptr
      00661E 60 12            [24] 1871 	jz	00167$
                                   1872 ;	tmk_core/protocol/ch555/usb_ak820.c:280: pD0_EP0_BUF[0] = 0;
      006620 90 10 00         [24] 1873 	mov	dptr,#0x1000
      006623 E4               [12] 1874 	clr	a
      006624 F0               [24] 1875 	movx	@dptr,a
                                   1876 ;	tmk_core/protocol/ch555/usb_ak820.c:281: D0_EP0T_L = 1;
      006625 90 22 08         [24] 1877 	mov	dptr,#0x2208
      006628 04               [12] 1878 	inc	a
      006629 F0               [24] 1879 	movx	@dptr,a
                                   1880 ;	tmk_core/protocol/ch555/usb_ak820.c:282: control_phase = CTRL_STATUS_OUT;
      00662A 90 08 37         [24] 1881 	mov	dptr,#_control_phase
      00662D 04               [12] 1882 	inc	a
      00662E F0               [24] 1883 	movx	@dptr,a
      00662F 02 6A D4         [24] 1884 	ljmp	00291$
      006632                       1885 00167$:
                                   1886 ;	tmk_core/protocol/ch555/usb_ak820.c:283: } else if (valid_interface && D0UsbConfig && type == 0x21 && zero_length) {
      006632 30 15 1E         [24] 1887 	jnb	_control_setup_valid_interface_10000_290,00161$
      006635 90 07 DE         [24] 1888 	mov	dptr,#_D0UsbConfig
      006638 E0               [24] 1889 	movx	a,@dptr
      006639 60 18            [24] 1890 	jz	00161$
      00663B BF 21 15         [24] 1891 	cjne	r7,#0x21,00161$
      00663E 30 18 12         [24] 1892 	jnb	_control_setup_zero_length_10000_290,00161$
                                   1893 ;	tmk_core/protocol/ch555/usb_ak820.c:284: if (index == KEYBOARD_INTERFACE) keyboard_idle = value >> 8;
      006641 EB               [12] 1894 	mov	a,r3
      006642 4C               [12] 1895 	orl	a,r4
      006643 70 05            [24] 1896 	jnz	00159$
      006645 90 06 B6         [24] 1897 	mov	dptr,#_keyboard_idle
      006648 EE               [12] 1898 	mov	a,r6
      006649 F0               [24] 1899 	movx	@dptr,a
      00664A                       1900 00159$:
                                   1901 ;	tmk_core/protocol/ch555/usb_ak820.c:285: control_phase = CTRL_STATUS_IN;
      00664A 90 08 37         [24] 1902 	mov	dptr,#_control_phase
      00664D 74 03            [12] 1903 	mov	a,#0x03
      00664F F0               [24] 1904 	movx	@dptr,a
      006650 02 6A D4         [24] 1905 	ljmp	00291$
      006653                       1906 00161$:
                                   1907 ;	tmk_core/protocol/ch555/usb_ak820.c:286: } else { control_stall(); return; }
      006653 02 61 25         [24] 1908 	ljmp	_control_stall
                                   1909 ;	tmk_core/protocol/ch555/usb_ak820.c:288: case USB_SET_INTERFACE: /* DEF_USB_SET_PROTOCOL has the same request byte. */
      006656                       1910 00173$:
                                   1911 ;	tmk_core/protocol/ch555/usb_ak820.c:289: if (type == 0x01 && valid_interface && zero_value && zero_length && D0UsbConfig) {
      006656 BF 01 18         [24] 1912 	cjne	r7,#0x01,00182$
      006659 30 15 15         [24] 1913 	jnb	_control_setup_valid_interface_10000_290,00182$
      00665C 30 17 12         [24] 1914 	jnb	_control_setup_zero_value_10000_290,00182$
      00665F 30 18 0F         [24] 1915 	jnb	_control_setup_zero_length_10000_290,00182$
      006662 90 07 DE         [24] 1916 	mov	dptr,#_D0UsbConfig
      006665 E0               [24] 1917 	movx	a,@dptr
      006666 60 09            [24] 1918 	jz	00182$
                                   1919 ;	tmk_core/protocol/ch555/usb_ak820.c:290: control_phase = CTRL_STATUS_IN;
      006668 90 08 37         [24] 1920 	mov	dptr,#_control_phase
      00666B 74 03            [12] 1921 	mov	a,#0x03
      00666D F0               [24] 1922 	movx	@dptr,a
      00666E 02 6A D4         [24] 1923 	ljmp	00291$
      006671                       1924 00182$:
                                   1925 ;	tmk_core/protocol/ch555/usb_ak820.c:291: } else if (index == KEYBOARD_INTERFACE && D0UsbConfig && type == 0x21 && zero_length && value <= 1) {
      006671 EB               [12] 1926 	mov	a,r3
      006672 4C               [12] 1927 	orl	a,r4
      006673 70 2C            [24] 1928 	jnz	00175$
      006675 90 07 DE         [24] 1929 	mov	dptr,#_D0UsbConfig
      006678 E0               [24] 1930 	movx	a,@dptr
      006679 60 26            [24] 1931 	jz	00175$
      00667B BF 21 23         [24] 1932 	cjne	r7,#0x21,00175$
      00667E 30 18 20         [24] 1933 	jnb	_control_setup_zero_length_10000_290,00175$
      006681 8D 01            [24] 1934 	mov	ar1,r5
      006683 8E 02            [24] 1935 	mov	ar2,r6
      006685 C3               [12] 1936 	clr	c
      006686 74 01            [12] 1937 	mov	a,#0x01
      006688 99               [12] 1938 	subb	a,r1
      006689 E4               [12] 1939 	clr	a
      00668A 9A               [12] 1940 	subb	a,r2
      00668B 40 14            [24] 1941 	jc	00175$
                                   1942 ;	free result
                                   1943 ;	tmk_core/protocol/ch555/usb_ak820.c:292: keyboard_protocol = value;
      00668D 90 0D FB         [24] 1944 	mov	dptr,#_keyboard_protocol
      006690 ED               [12] 1945 	mov	a,r5
      006691 F0               [24] 1946 	movx	@dptr,a
                                   1947 ;	tmk_core/protocol/ch555/usb_ak820.c:293: keyboard_reset = 1;
      006692 90 08 08         [24] 1948 	mov	dptr,#_keyboard_reset
      006695 74 01            [12] 1949 	mov	a,#0x01
      006697 F0               [24] 1950 	movx	@dptr,a
                                   1951 ;	tmk_core/protocol/ch555/usb_ak820.c:294: control_phase = CTRL_STATUS_IN;
      006698 90 08 37         [24] 1952 	mov	dptr,#_control_phase
      00669B 74 03            [12] 1953 	mov	a,#0x03
      00669D F0               [24] 1954 	movx	@dptr,a
      00669E 02 6A D4         [24] 1955 	ljmp	00291$
      0066A1                       1956 00175$:
                                   1957 ;	tmk_core/protocol/ch555/usb_ak820.c:295: } else { control_stall(); return; }
      0066A1 02 61 25         [24] 1958 	ljmp	_control_stall
                                   1959 ;	tmk_core/protocol/ch555/usb_ak820.c:297: case USB_GET_STATUS:
      0066A4                       1960 00188$:
                                   1961 ;	tmk_core/protocol/ch555/usb_ak820.c:298: if (zero_value && D0SetupLen == 2 &&
      0066A4 20 17 03         [24] 1962 	jb	_control_setup_zero_value_10000_290,01283$
      0066A7 02 61 25         [24] 1963 	ljmp	_control_stall
      0066AA                       1964 01283$:
      0066AA 90 07 D9         [24] 1965 	mov	dptr,#_D0SetupLen
      0066AD E0               [24] 1966 	movx	a,@dptr
      0066AE F9               [12] 1967 	mov	r1,a
      0066AF A3               [24] 1968 	inc	dptr
      0066B0 E0               [24] 1969 	movx	a,@dptr
      0066B1 FA               [12] 1970 	mov	r2,a
      0066B2 B9 02 05         [24] 1971 	cjne	r1,#0x02,01284$
      0066B5 BA 00 02         [24] 1972 	cjne	r2,#0x00,01284$
      0066B8 80 03            [24] 1973 	sjmp	01285$
      0066BA                       1974 01284$:
      0066BA 02 61 25         [24] 1975 	ljmp	_control_stall
      0066BD                       1976 01285$:
                                   1977 ;	tmk_core/protocol/ch555/usb_ak820.c:299: ((type == 0x80 && zero_index) || (type == 0x81 && valid_interface && D0UsbConfig) ||
      0066BD E4               [12] 1978 	clr	a
      0066BE BF 80 01         [24] 1979 	cjne	r7,#0x80,01286$
      0066C1 04               [12] 1980 	inc	a
      0066C2                       1981 01286$:
      0066C2 FA               [12] 1982 	mov	r2,a
      0066C3 60 03            [24] 1983 	jz	00196$
      0066C5 20 16 35         [24] 1984 	jb	_control_setup_zero_index_10000_290,00189$
      0066C8                       1985 00196$:
      0066C8 BF 81 09         [24] 1986 	cjne	r7,#0x81,00202$
      0066CB 30 15 06         [24] 1987 	jnb	_control_setup_valid_interface_10000_290,00202$
      0066CE 90 07 DE         [24] 1988 	mov	dptr,#_D0UsbConfig
      0066D1 E0               [24] 1989 	movx	a,@dptr
      0066D2 70 29            [24] 1990 	jnz	00189$
      0066D4                       1991 00202$:
                                   1992 ;	tmk_core/protocol/ch555/usb_ak820.c:300: (type == 0x82 && D0UsbConfig && (index == 0 || index == 0x80 || (index >= 0x81 && index <= 0x83))))) {
      0066D4 BF 82 70         [24] 1993 	cjne	r7,#0x82,00190$
      0066D7 90 07 DE         [24] 1994 	mov	dptr,#_D0UsbConfig
      0066DA E0               [24] 1995 	movx	a,@dptr
      0066DB 60 6A            [24] 1996 	jz	00190$
      0066DD EB               [12] 1997 	mov	a,r3
      0066DE 4C               [12] 1998 	orl	a,r4
      0066DF 60 1C            [24] 1999 	jz	00189$
      0066E1 8B 00            [24] 2000 	mov	ar0,r3
      0066E3 8C 01            [24] 2001 	mov	ar1,r4
      0066E5 B8 80 05         [24] 2002 	cjne	r0,#0x80,01298$
      0066E8 B9 00 02         [24] 2003 	cjne	r1,#0x00,01298$
      0066EB 80 10            [24] 2004 	sjmp	00189$
      0066ED                       2005 01298$:
      0066ED C3               [12] 2006 	clr	c
      0066EE E8               [12] 2007 	mov	a,r0
      0066EF 94 81            [12] 2008 	subb	a,#0x81
      0066F1 E9               [12] 2009 	mov	a,r1
      0066F2 94 00            [12] 2010 	subb	a,#0x00
      0066F4 40 51            [24] 2011 	jc	00190$
      0066F6 74 83            [12] 2012 	mov	a,#0x83
      0066F8 98               [12] 2013 	subb	a,r0
      0066F9 E4               [12] 2014 	clr	a
      0066FA 99               [12] 2015 	subb	a,r1
      0066FB 40 4A            [24] 2016 	jc	00190$
                                   2017 ;	free result
      0066FD                       2018 00189$:
                                   2019 ;	tmk_core/protocol/ch555/usb_ak820.c:301: endpoint = index & 7;
      0066FD 8B 01            [24] 2020 	mov	ar1,r3
      0066FF 53 01 07         [24] 2021 	anl	ar1,#0x07
                                   2022 ;	tmk_core/protocol/ch555/usb_ak820.c:302: pD0_EP0_BUF[0] = type == 0x80 ? ((USB_SleepStatus & 1) << 1) :
      006702 EA               [12] 2023 	mov	a,r2
      006703 60 0B            [24] 2024 	jz	00308$
      006705 90 07 E0         [24] 2025 	mov	dptr,#_USB_SleepStatus
      006708 E0               [24] 2026 	movx	a,@dptr
      006709 54 01            [12] 2027 	anl	a,#0x01
      00670B 25 E0            [12] 2028 	add	a,acc
      00670D FA               [12] 2029 	mov	r2,a
      00670E 80 22            [24] 2030 	sjmp	00309$
      006710                       2031 00308$:
                                   2032 ;	tmk_core/protocol/ch555/usb_ak820.c:303: ((type == 0x82 && endpoint && (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_STALL) ? 1 : 0);
      006710 BF 82 1B         [24] 2033 	cjne	r7,#0x82,00310$
      006713 E9               [12] 2034 	mov	a,r1
      006714 60 18            [24] 2035 	jz	00310$
      006716 89 00            [24] 2036 	mov	ar0,r1
      006718 79 00            [12] 2037 	mov	r1,#0x00
      00671A 74 22            [12] 2038 	mov	a,#0x22
      00671C 29               [12] 2039 	add	a, r1
      00671D F9               [12] 2040 	mov	r1,a
      00671E 88 82            [24] 2041 	mov	dpl,r0
      006720 89 83            [24] 2042 	mov	dph,r1
      006722 E0               [24] 2043 	movx	a,@dptr
      006723 F9               [12] 2044 	mov	r1,a
      006724 53 01 03         [24] 2045 	anl	ar1,#0x03
      006727 B9 03 04         [24] 2046 	cjne	r1,#0x03,00310$
      00672A 79 01            [12] 2047 	mov	r1,#0x01
      00672C 80 02            [24] 2048 	sjmp	00311$
      00672E                       2049 00310$:
      00672E 79 00            [12] 2050 	mov	r1,#0x00
      006730                       2051 00311$:
      006730 89 02            [24] 2052 	mov	ar2,r1
      006732                       2053 00309$:
      006732 90 10 00         [24] 2054 	mov	dptr,#0x1000
      006735 EA               [12] 2055 	mov	a,r2
      006736 F0               [24] 2056 	movx	@dptr,a
                                   2057 ;	tmk_core/protocol/ch555/usb_ak820.c:304: pD0_EP0_BUF[1] = 0;
      006737 A3               [24] 2058 	inc	dptr
      006738 E4               [12] 2059 	clr	a
      006739 F0               [24] 2060 	movx	@dptr,a
                                   2061 ;	tmk_core/protocol/ch555/usb_ak820.c:305: D0_EP0T_L = 2;
      00673A 90 22 08         [24] 2062 	mov	dptr,#0x2208
      00673D 74 02            [12] 2063 	mov	a,#0x02
      00673F F0               [24] 2064 	movx	@dptr,a
                                   2065 ;	tmk_core/protocol/ch555/usb_ak820.c:306: control_phase = CTRL_STATUS_OUT;
      006740 90 08 37         [24] 2066 	mov	dptr,#_control_phase
      006743 F0               [24] 2067 	movx	@dptr,a
      006744 02 6A D4         [24] 2068 	ljmp	00291$
      006747                       2069 00190$:
                                   2070 ;	tmk_core/protocol/ch555/usb_ak820.c:307: } else { control_stall(); return; }
      006747 02 61 25         [24] 2071 	ljmp	_control_stall
                                   2072 ;	tmk_core/protocol/ch555/usb_ak820.c:310: case USB_SET_FEATURE: /* DEF_USB_GET_PROTOCOL has the same request byte. */
      00674A                       2073 00205$:
                                   2074 ;	tmk_core/protocol/ch555/usb_ak820.c:311: if (zero_length && D0UsbConfig) {
      00674A 20 18 03         [24] 2075 	jb	_control_setup_zero_length_10000_290,01307$
      00674D 02 67 DD         [24] 2076 	ljmp	00279$
      006750                       2077 01307$:
      006750 90 07 DE         [24] 2078 	mov	dptr,#_D0UsbConfig
      006753 E0               [24] 2079 	movx	a,@dptr
      006754 70 03            [24] 2080 	jnz	01308$
      006756 02 67 DD         [24] 2081 	ljmp	00279$
      006759                       2082 01308$:
                                   2083 ;	tmk_core/protocol/ch555/usb_ak820.c:312: if (type == 0x00 && value == 1 && zero_index) {
      006759 EF               [12] 2084 	mov	a,r7
      00675A 70 29            [24] 2085 	jnz	00218$
      00675C 8D 01            [24] 2086 	mov	ar1,r5
      00675E 8E 02            [24] 2087 	mov	ar2,r6
      006760 B9 01 22         [24] 2088 	cjne	r1,#0x01,00218$
      006763 BA 00 1F         [24] 2089 	cjne	r2,#0x00,00218$
      006766 30 16 1C         [24] 2090 	jnb	_control_setup_zero_index_10000_290,00218$
                                   2091 ;	tmk_core/protocol/ch555/usb_ak820.c:313: if (D0SetupReqCode == USB_SET_FEATURE) USB_SleepStatus |= 1;
      006769 90 07 D8         [24] 2092 	mov	dptr,#_D0SetupReqCode
      00676C E0               [24] 2093 	movx	a,@dptr
      00676D FA               [12] 2094 	mov	r2,a
      00676E BA 03 0A         [24] 2095 	cjne	r2,#0x03,00207$
      006771 90 07 E0         [24] 2096 	mov	dptr,#_USB_SleepStatus
      006774 E0               [24] 2097 	movx	a,@dptr
      006775 43 E0 01         [24] 2098 	orl	acc,#0x01
      006778 F0               [24] 2099 	movx	@dptr,a
      006779 80 59            [24] 2100 	sjmp	00219$
      00677B                       2101 00207$:
                                   2102 ;	tmk_core/protocol/ch555/usb_ak820.c:314: else USB_SleepStatus &= ~1;
      00677B 90 07 E0         [24] 2103 	mov	dptr,#_USB_SleepStatus
      00677E E0               [24] 2104 	movx	a,@dptr
      00677F 53 E0 FE         [24] 2105 	anl	acc,#0xfe
      006782 F0               [24] 2106 	movx	@dptr,a
      006783 80 4F            [24] 2107 	sjmp	00219$
      006785                       2108 00218$:
                                   2109 ;	tmk_core/protocol/ch555/usb_ak820.c:315: } else if (type == 0x02 && zero_value && index >= 0x81 && index <= 0x83) {
      006785 BF 02 49         [24] 2110 	cjne	r7,#0x02,00212$
      006788 30 17 46         [24] 2111 	jnb	_control_setup_zero_value_10000_290,00212$
      00678B 8B 01            [24] 2112 	mov	ar1,r3
      00678D 8C 02            [24] 2113 	mov	ar2,r4
      00678F C3               [12] 2114 	clr	c
      006790 E9               [12] 2115 	mov	a,r1
      006791 94 81            [12] 2116 	subb	a,#0x81
      006793 EA               [12] 2117 	mov	a,r2
      006794 94 00            [12] 2118 	subb	a,#0x00
      006796 40 39            [24] 2119 	jc	00212$
      006798 74 83            [12] 2120 	mov	a,#0x83
      00679A 99               [12] 2121 	subb	a,r1
      00679B E4               [12] 2122 	clr	a
      00679C 9A               [12] 2123 	subb	a,r2
      00679D 40 32            [24] 2124 	jc	00212$
                                   2125 ;	free result
                                   2126 ;	tmk_core/protocol/ch555/usb_ak820.c:316: endpoint = index & 7;
      00679F 8B 02            [24] 2127 	mov	ar2,r3
      0067A1 53 02 07         [24] 2128 	anl	ar2,#0x07
                                   2129 ;	tmk_core/protocol/ch555/usb_ak820.c:318: EP_RESPONSE(endpoint) = bUEP_X_AUTO_TOG | (D0SetupReqCode == USB_SET_FEATURE ? UEP_X_RES_STALL : UEP_X_RES_NAK);
      0067A4 8A 00            [24] 2130 	mov	ar0,r2
      0067A6 79 00            [12] 2131 	mov	r1,#0x00
      0067A8 74 22            [12] 2132 	mov	a,#0x22
      0067AA 29               [12] 2133 	add	a, r1
      0067AB F9               [12] 2134 	mov	r1,a
      0067AC 88 17            [24] 2135 	mov	_control_setup_sloc3_1_0,r0
      0067AE 89 18            [24] 2136 	mov	(_control_setup_sloc3_1_0 + 1),r1
      0067B0 90 07 D8         [24] 2137 	mov	dptr,#_D0SetupReqCode
      0067B3 E0               [24] 2138 	movx	a,@dptr
      0067B4 F9               [12] 2139 	mov	r1,a
      0067B5 B9 03 04         [24] 2140 	cjne	r1,#0x03,00318$
      0067B8 79 03            [12] 2141 	mov	r1,#0x03
      0067BA 80 02            [24] 2142 	sjmp	00319$
      0067BC                       2143 00318$:
      0067BC 79 02            [12] 2144 	mov	r1,#0x02
      0067BE                       2145 00319$:
      0067BE 43 01 10         [24] 2146 	orl	ar1,#0x10
      0067C1 85 17 82         [24] 2147 	mov	dpl,_control_setup_sloc3_1_0
      0067C4 85 18 83         [24] 2148 	mov	dph,(_control_setup_sloc3_1_0 + 1)
      0067C7 E9               [12] 2149 	mov	a,r1
      0067C8 F0               [24] 2150 	movx	@dptr,a
                                   2151 ;	tmk_core/protocol/ch555/usb_ak820.c:319: if (endpoint == RAW_IN_EPNUM) raw_complete();
      0067C9 BA 03 08         [24] 2152 	cjne	r2,#0x03,00219$
      0067CC 12 60 AD         [24] 2153 	lcall	_raw_complete
      0067CF 80 03            [24] 2154 	sjmp	00219$
      0067D1                       2155 00212$:
                                   2156 ;	tmk_core/protocol/ch555/usb_ak820.c:320: } else { control_stall(); return; }
      0067D1 02 61 25         [24] 2157 	ljmp	_control_stall
      0067D4                       2158 00219$:
                                   2159 ;	tmk_core/protocol/ch555/usb_ak820.c:321: control_phase = CTRL_STATUS_IN;
      0067D4 90 08 37         [24] 2160 	mov	dptr,#_control_phase
      0067D7 74 03            [12] 2161 	mov	a,#0x03
      0067D9 F0               [24] 2162 	movx	@dptr,a
      0067DA 02 6A D4         [24] 2163 	ljmp	00291$
      0067DD                       2164 00279$:
                                   2165 ;	tmk_core/protocol/ch555/usb_ak820.c:322: } else if (type == 0xa1 && D0SetupReqCode == HID_GET_REPORT && D0UsbConfig && D0SetupLen) {
      0067DD E4               [12] 2166 	clr	a
      0067DE BF A1 01         [24] 2167 	cjne	r7,#0xa1,01324$
      0067E1 04               [12] 2168 	inc	a
      0067E2                       2169 01324$:
      0067E2 FA               [12] 2170 	mov	r2,a
      0067E3 70 03            [24] 2171 	jnz	01326$
      0067E5 02 6A 4F         [24] 2172 	ljmp	00273$
      0067E8                       2173 01326$:
      0067E8 90 07 D8         [24] 2174 	mov	dptr,#_D0SetupReqCode
      0067EB E0               [24] 2175 	movx	a,@dptr
      0067EC F9               [12] 2176 	mov	r1,a
      0067ED B9 01 02         [24] 2177 	cjne	r1,#0x01,01327$
      0067F0 80 03            [24] 2178 	sjmp	01328$
      0067F2                       2179 01327$:
      0067F2 02 6A 4F         [24] 2180 	ljmp	00273$
      0067F5                       2181 01328$:
      0067F5 90 07 DE         [24] 2182 	mov	dptr,#_D0UsbConfig
      0067F8 E0               [24] 2183 	movx	a,@dptr
      0067F9 70 03            [24] 2184 	jnz	01329$
      0067FB 02 6A 4F         [24] 2185 	ljmp	00273$
      0067FE                       2186 01329$:
      0067FE 90 07 D9         [24] 2187 	mov	dptr,#_D0SetupLen
      006801 E0               [24] 2188 	movx	a,@dptr
      006802 F8               [12] 2189 	mov	r0,a
      006803 A3               [24] 2190 	inc	dptr
      006804 E0               [24] 2191 	movx	a,@dptr
      006805 48               [12] 2192 	orl	a,r0
      006806 70 03            [24] 2193 	jnz	01330$
      006808 02 6A 4F         [24] 2194 	ljmp	00273$
      00680B                       2195 01330$:
                                   2196 ;	tmk_core/protocol/ch555/usb_ak820.c:323: report_id = value;
      00680B C0 03            [24] 2197 	push	ar3
      00680D C0 04            [24] 2198 	push	ar4
      00680F 8D 01            [24] 2199 	mov	ar1,r5
                                   2200 ;	tmk_core/protocol/ch555/usb_ak820.c:324: if ((value >> 8) == 1 && index == KEYBOARD_INTERFACE && !report_id) {
      006811 8E 00            [24] 2201 	mov	ar0,r6
      006813 B8 01 03         [24] 2202 	cjne	r0,#0x01,01331$
      006816 E8               [12] 2203 	mov	a,r0
      006817 80 01            [24] 2204 	sjmp	01332$
      006819                       2205 01331$:
      006819 E4               [12] 2206 	clr	a
      00681A                       2207 01332$:
      00681A F5 17            [12] 2208 	mov	_control_setup_sloc3_1_0,a
      00681C D0 04            [24] 2209 	pop	ar4
      00681E D0 03            [24] 2210 	pop	ar3
      006820 E5 17            [12] 2211 	mov	a,_control_setup_sloc3_1_0
      006822 60 17            [24] 2212 	jz	00251$
      006824 EB               [12] 2213 	mov	a,r3
      006825 4C               [12] 2214 	orl	a,r4
      006826 70 13            [24] 2215 	jnz	00251$
      006828 E9               [12] 2216 	mov	a,r1
      006829 70 10            [24] 2217 	jnz	00251$
                                   2218 ;	tmk_core/protocol/ch555/usb_ak820.c:325: length = KEYBOARD_EPSIZE;
      00682B 90 08 41         [24] 2219 	mov	dptr,#_control_setup_length_10000_290
      00682E 74 08            [12] 2220 	mov	a,#0x08
      006830 F0               [24] 2221 	movx	@dptr,a
      006831 E4               [12] 2222 	clr	a
      006832 A3               [24] 2223 	inc	dptr
      006833 F0               [24] 2224 	movx	@dptr,a
                                   2225 ;	tmk_core/protocol/ch555/usb_ak820.c:326: offset = SNAPSHOT_KEYBOARD;
      006834 90 08 43         [24] 2226 	mov	dptr,#_control_setup_offset_10000_290
      006837 F0               [24] 2227 	movx	@dptr,a
      006838 02 69 BF         [24] 2228 	ljmp	00252$
      00683B                       2229 00251$:
                                   2230 ;	tmk_core/protocol/ch555/usb_ak820.c:327: } else if ((value >> 8) == 1 && index == SHARED_INTERFACE &&
      00683B E5 17            [12] 2231 	mov	a,_control_setup_sloc3_1_0
      00683D 60 27            [24] 2232 	jz	00245$
      00683F BB 02 24         [24] 2233 	cjne	r3,#0x02,00245$
      006842 BC 00 21         [24] 2234 	cjne	r4,#0x00,00245$
                                   2235 ;	tmk_core/protocol/ch555/usb_ak820.c:328: report_id < sizeof(shared_lengths) && shared_lengths[report_id]) {
      006845 B9 07 00         [24] 2236 	cjne	r1,#0x07,01339$
      006848                       2237 01339$:
      006848 50 1C            [24] 2238 	jnc	00245$
      00684A E9               [12] 2239 	mov	a,r1
      00684B 90 BF F5         [24] 2240 	mov	dptr,#_shared_lengths
      00684E 93               [24] 2241 	movc	a,@a+dptr
      00684F F8               [12] 2242 	mov	r0,a
      006850 60 14            [24] 2243 	jz	00245$
                                   2244 ;	tmk_core/protocol/ch555/usb_ak820.c:329: length = shared_lengths[report_id];
      006852 90 08 41         [24] 2245 	mov	dptr,#_control_setup_length_10000_290
      006855 E8               [12] 2246 	mov	a,r0
      006856 F0               [24] 2247 	movx	@dptr,a
      006857 E4               [12] 2248 	clr	a
      006858 A3               [24] 2249 	inc	dptr
      006859 F0               [24] 2250 	movx	@dptr,a
                                   2251 ;	tmk_core/protocol/ch555/usb_ak820.c:330: offset = shared_offsets[report_id];
      00685A E9               [12] 2252 	mov	a,r1
      00685B 90 BF EE         [24] 2253 	mov	dptr,#_shared_offsets
      00685E 93               [24] 2254 	movc	a,@a+dptr
      00685F 90 08 43         [24] 2255 	mov	dptr,#_control_setup_offset_10000_290
      006862 F0               [24] 2256 	movx	@dptr,a
      006863 02 69 BF         [24] 2257 	ljmp	00252$
      006866                       2258 00245$:
                                   2259 ;	tmk_core/protocol/ch555/usb_ak820.c:331: } else if ((value >> 8) == 1 && index == RAW_INTERFACE && !report_id) {
      006866 E5 17            [12] 2260 	mov	a,_control_setup_sloc3_1_0
      006868 60 7A            [24] 2261 	jz	00240$
      00686A BB 01 77         [24] 2262 	cjne	r3,#0x01,00240$
      00686D BC 00 74         [24] 2263 	cjne	r4,#0x00,00240$
      006870 E9               [12] 2264 	mov	a,r1
      006871 70 71            [24] 2265 	jnz	00240$
                                   2266 ;	tmk_core/protocol/ch555/usb_ak820.c:332: length = D0SetupLen < RAW_EPSIZE ? D0SetupLen : RAW_EPSIZE;
      006873 90 07 D9         [24] 2267 	mov	dptr,#_D0SetupLen
      006876 E0               [24] 2268 	movx	a,@dptr
      006877 F8               [12] 2269 	mov	r0,a
      006878 A3               [24] 2270 	inc	dptr
      006879 E0               [24] 2271 	movx	a,@dptr
      00687A F9               [12] 2272 	mov	r1,a
      00687B C3               [12] 2273 	clr	c
      00687C E8               [12] 2274 	mov	a,r0
      00687D 94 20            [12] 2275 	subb	a,#0x20
      00687F E9               [12] 2276 	mov	a,r1
      006880 94 00            [12] 2277 	subb	a,#0x00
      006882 50 0A            [24] 2278 	jnc	00320$
      006884 90 07 D9         [24] 2279 	mov	dptr,#_D0SetupLen
      006887 E0               [24] 2280 	movx	a,@dptr
      006888 F8               [12] 2281 	mov	r0,a
      006889 A3               [24] 2282 	inc	dptr
      00688A E0               [24] 2283 	movx	a,@dptr
      00688B F9               [12] 2284 	mov	r1,a
      00688C 80 04            [24] 2285 	sjmp	00321$
      00688E                       2286 00320$:
      00688E 78 20            [12] 2287 	mov	r0,#0x20
      006890 79 00            [12] 2288 	mov	r1,#0x00
      006892                       2289 00321$:
                                   2290 ;	tmk_core/protocol/ch555/usb_ak820.c:333: for (i = 0; i < length; ++i) pD0_EP0_BUF[i] = pUSB_BUF_DEV0[UX_EP3_ADDR + i];
      006892 75 17 00         [24] 2291 	mov	_control_setup_sloc3_1_0,#0x00
      006895                       2292 00293$:
      006895 C0 03            [24] 2293 	push	ar3
      006897 C0 04            [24] 2294 	push	ar4
      006899 AB 17            [24] 2295 	mov	r3,_control_setup_sloc3_1_0
      00689B 7C 00            [12] 2296 	mov	r4,#0x00
      00689D C3               [12] 2297 	clr	c
      00689E EB               [12] 2298 	mov	a,r3
      00689F 98               [12] 2299 	subb	a,r0
      0068A0 EC               [12] 2300 	mov	a,r4
      0068A1 99               [12] 2301 	subb	a,r1
      0068A2 D0 04            [24] 2302 	pop	ar4
      0068A4 D0 03            [24] 2303 	pop	ar3
      0068A6 50 32            [24] 2304 	jnc	00222$
      0068A8 C0 00            [24] 2305 	push	ar0
      0068AA C0 01            [24] 2306 	push	ar1
      0068AC 85 17 19         [24] 2307 	mov	_control_setup_sloc4_1_0,_control_setup_sloc3_1_0
      0068AF 74 10            [12] 2308 	mov	a,#0x10
      0068B1 24 00            [12] 2309 	add	a, #0x00
      0068B3 F5 1A            [12] 2310 	mov	(_control_setup_sloc4_1_0 + 1),a
      0068B5 A8 17            [24] 2311 	mov	r0,_control_setup_sloc3_1_0
      0068B7 79 00            [12] 2312 	mov	r1,#0x00
      0068B9 74 C0            [12] 2313 	mov	a,#0xc0
      0068BB 28               [12] 2314 	add	a, r0
      0068BC F8               [12] 2315 	mov	r0,a
      0068BD E4               [12] 2316 	clr	a
      0068BE 39               [12] 2317 	addc	a, r1
      0068BF F9               [12] 2318 	mov	r1,a
      0068C0 88 82            [24] 2319 	mov	dpl,r0
      0068C2 74 10            [12] 2320 	mov	a,#0x10
      0068C4 29               [12] 2321 	add	a, r1
      0068C5 F5 83            [12] 2322 	mov	dph,a
      0068C7 E0               [24] 2323 	movx	a,@dptr
      0068C8 85 19 82         [24] 2324 	mov	dpl,_control_setup_sloc4_1_0
      0068CB 85 1A 83         [24] 2325 	mov	dph,(_control_setup_sloc4_1_0 + 1)
      0068CE F0               [24] 2326 	movx	@dptr,a
      0068CF E5 17            [12] 2327 	mov	a,_control_setup_sloc3_1_0
      0068D1 04               [12] 2328 	inc	a
      0068D2 F5 17            [12] 2329 	mov	_control_setup_sloc3_1_0,a
      0068D4 D0 01            [24] 2330 	pop	ar1
      0068D6 D0 00            [24] 2331 	pop	ar0
      0068D8 80 BB            [24] 2332 	sjmp	00293$
      0068DA                       2333 00222$:
                                   2334 ;	tmk_core/protocol/ch555/usb_ak820.c:334: length = 0; /* data already copied */
      0068DA 90 08 41         [24] 2335 	mov	dptr,#_control_setup_length_10000_290
      0068DD E4               [12] 2336 	clr	a
      0068DE F0               [24] 2337 	movx	@dptr,a
      0068DF A3               [24] 2338 	inc	dptr
      0068E0 F0               [24] 2339 	movx	@dptr,a
      0068E1 02 69 BF         [24] 2340 	ljmp	00252$
      0068E4                       2341 00240$:
                                   2342 ;	tmk_core/protocol/ch555/usb_ak820.c:335: } else if (value == 0x0200 && index == KEYBOARD_INTERFACE) {
      0068E4 8D 00            [24] 2343 	mov	ar0,r5
      0068E6 8E 01            [24] 2344 	mov	ar1,r6
      0068E8 B8 00 21         [24] 2345 	cjne	r0,#0x00,00236$
      0068EB B9 02 1E         [24] 2346 	cjne	r1,#0x02,00236$
      0068EE EB               [12] 2347 	mov	a,r3
      0068EF 4C               [12] 2348 	orl	a,r4
      0068F0 70 1A            [24] 2349 	jnz	00236$
                                   2350 ;	tmk_core/protocol/ch555/usb_ak820.c:336: pD0_EP0_BUF[0] = KB_USB_SetReport;
      0068F2 90 07 E3         [24] 2351 	mov	dptr,#_KB_USB_SetReport
      0068F5 E0               [24] 2352 	movx	a,@dptr
      0068F6 90 10 00         [24] 2353 	mov	dptr,#0x1000
      0068F9 F0               [24] 2354 	movx	@dptr,a
                                   2355 ;	tmk_core/protocol/ch555/usb_ak820.c:337: length = 0;
      0068FA 90 08 41         [24] 2356 	mov	dptr,#_control_setup_length_10000_290
      0068FD E4               [12] 2357 	clr	a
      0068FE F0               [24] 2358 	movx	@dptr,a
      0068FF A3               [24] 2359 	inc	dptr
      006900 F0               [24] 2360 	movx	@dptr,a
                                   2361 ;	tmk_core/protocol/ch555/usb_ak820.c:338: D0SetupLen = 1;
      006901 90 07 D9         [24] 2362 	mov	dptr,#_D0SetupLen
      006904 04               [12] 2363 	inc	a
      006905 F0               [24] 2364 	movx	@dptr,a
      006906 E4               [12] 2365 	clr	a
      006907 A3               [24] 2366 	inc	dptr
      006908 F0               [24] 2367 	movx	@dptr,a
      006909 02 69 BF         [24] 2368 	ljmp	00252$
      00690C                       2369 00236$:
                                   2370 ;	tmk_core/protocol/ch555/usb_ak820.c:339: } else if (value == (0x0200 | REPORT_ID_NKRO) && index == SHARED_INTERFACE) {
      00690C B8 06 41         [24] 2371 	cjne	r0,#0x06,00232$
      00690F B9 02 3E         [24] 2372 	cjne	r1,#0x02,00232$
      006912 BB 02 3B         [24] 2373 	cjne	r3,#0x02,00232$
      006915 BC 00 38         [24] 2374 	cjne	r4,#0x00,00232$
                                   2375 ;	tmk_core/protocol/ch555/usb_ak820.c:340: pD0_EP0_BUF[0] = REPORT_ID_NKRO;
      006918 C0 03            [24] 2376 	push	ar3
      00691A C0 04            [24] 2377 	push	ar4
      00691C 90 10 00         [24] 2378 	mov	dptr,#0x1000
      00691F 74 06            [12] 2379 	mov	a,#0x06
      006921 F0               [24] 2380 	movx	@dptr,a
                                   2381 ;	tmk_core/protocol/ch555/usb_ak820.c:341: pD0_EP0_BUF[1] = KB_USB_SetReport;
      006922 90 07 E3         [24] 2382 	mov	dptr,#_KB_USB_SetReport
      006925 E0               [24] 2383 	movx	a,@dptr
      006926 90 10 01         [24] 2384 	mov	dptr,#0x1001
      006929 F0               [24] 2385 	movx	@dptr,a
                                   2386 ;	tmk_core/protocol/ch555/usb_ak820.c:342: length = 0;
      00692A 90 08 41         [24] 2387 	mov	dptr,#_control_setup_length_10000_290
      00692D E4               [12] 2388 	clr	a
      00692E F0               [24] 2389 	movx	@dptr,a
      00692F A3               [24] 2390 	inc	dptr
      006930 F0               [24] 2391 	movx	@dptr,a
                                   2392 ;	tmk_core/protocol/ch555/usb_ak820.c:343: if (D0SetupLen > 2) D0SetupLen = 2;
      006931 90 07 D9         [24] 2393 	mov	dptr,#_D0SetupLen
      006934 E0               [24] 2394 	movx	a,@dptr
      006935 FB               [12] 2395 	mov	r3,a
      006936 A3               [24] 2396 	inc	dptr
      006937 E0               [24] 2397 	movx	a,@dptr
      006938 FC               [12] 2398 	mov	r4,a
      006939 C3               [12] 2399 	clr	c
      00693A 74 02            [12] 2400 	mov	a,#0x02
      00693C 9B               [12] 2401 	subb	a,r3
      00693D E4               [12] 2402 	clr	a
      00693E 9C               [12] 2403 	subb	a,r4
      00693F D0 04            [24] 2404 	pop	ar4
      006941 D0 03            [24] 2405 	pop	ar3
      006943 50 7A            [24] 2406 	jnc	00252$
                                   2407 ;	free result
      006945 90 07 D9         [24] 2408 	mov	dptr,#_D0SetupLen
      006948 74 02            [12] 2409 	mov	a,#0x02
      00694A F0               [24] 2410 	movx	@dptr,a
      00694B E4               [12] 2411 	clr	a
      00694C A3               [24] 2412 	inc	dptr
      00694D F0               [24] 2413 	movx	@dptr,a
      00694E 80 6F            [24] 2414 	sjmp	00252$
      006950                       2415 00232$:
                                   2416 ;	tmk_core/protocol/ch555/usb_ak820.c:344: } else if (value == 0x0300 && index == RAW_INTERFACE) {
      006950 B8 00 69         [24] 2417 	cjne	r0,#0x00,00228$
      006953 B9 03 66         [24] 2418 	cjne	r1,#0x03,00228$
      006956 BB 01 63         [24] 2419 	cjne	r3,#0x01,00228$
      006959 BC 00 60         [24] 2420 	cjne	r4,#0x00,00228$
                                   2421 ;	tmk_core/protocol/ch555/usb_ak820.c:347: pD0_EP0_BUF[0] = 'A';
      00695C 90 10 00         [24] 2422 	mov	dptr,#0x1000
      00695F 74 41            [12] 2423 	mov	a,#0x41
      006961 F0               [24] 2424 	movx	@dptr,a
                                   2425 ;	tmk_core/protocol/ch555/usb_ak820.c:348: pD0_EP0_BUF[1] = 'K';
      006962 A3               [24] 2426 	inc	dptr
      006963 74 4B            [12] 2427 	mov	a,#0x4b
      006965 F0               [24] 2428 	movx	@dptr,a
                                   2429 ;	tmk_core/protocol/ch555/usb_ak820.c:349: pD0_EP0_BUF[2] = 'B';
      006966 A3               [24] 2430 	inc	dptr
      006967 74 42            [12] 2431 	mov	a,#0x42
      006969 F0               [24] 2432 	movx	@dptr,a
                                   2433 ;	tmk_core/protocol/ch555/usb_ak820.c:350: pD0_EP0_BUF[3] = 'T';
      00696A A3               [24] 2434 	inc	dptr
      00696B 74 54            [12] 2435 	mov	a,#0x54
      00696D F0               [24] 2436 	movx	@dptr,a
                                   2437 ;	tmk_core/protocol/ch555/usb_ak820.c:351: pD0_EP0_BUF[4] = 1;
      00696E A3               [24] 2438 	inc	dptr
      00696F 74 01            [12] 2439 	mov	a,#0x01
      006971 F0               [24] 2440 	movx	@dptr,a
                                   2441 ;	tmk_core/protocol/ch555/usb_ak820.c:352: pD0_EP0_BUF[5] = ak820_boot_stage;
      006972 90 07 E4         [24] 2442 	mov	dptr,#_ak820_boot_stage
      006975 E0               [24] 2443 	movx	a,@dptr
      006976 90 10 05         [24] 2444 	mov	dptr,#0x1005
      006979 F0               [24] 2445 	movx	@dptr,a
                                   2446 ;	tmk_core/protocol/ch555/usb_ak820.c:353: pD0_EP0_BUF[6] = ak820_main_heartbeat;
      00697A 90 07 E5         [24] 2447 	mov	dptr,#_ak820_main_heartbeat
      00697D E0               [24] 2448 	movx	a,@dptr
      00697E 90 10 06         [24] 2449 	mov	dptr,#0x1006
      006981 F0               [24] 2450 	movx	@dptr,a
                                   2451 ;	tmk_core/protocol/ch555/usb_ak820.c:354: pD0_EP0_BUF[7] = (USB_EnumStatus ? 1 : 0) | (USB_SleepStatus & 2);
      006982 90 07 DF         [24] 2452 	mov	dptr,#_USB_EnumStatus
      006985 E0               [24] 2453 	movx	a,@dptr
      006986 60 02            [24] 2454 	jz	00322$
      006988 74 01            [12] 2455 	mov	a,#0x01
      00698A                       2456 00322$:
      00698A F9               [12] 2457 	mov	r1,a
      00698B 90 07 E0         [24] 2458 	mov	dptr,#_USB_SleepStatus
      00698E E0               [24] 2459 	movx	a,@dptr
      00698F 54 02            [12] 2460 	anl	a,#0x02
      006991 F8               [12] 2461 	mov	r0,a
      006992 E9               [12] 2462 	mov	a,r1
      006993 42 00            [12] 2463 	orl	ar0,a
      006995 90 10 07         [24] 2464 	mov	dptr,#0x1007
      006998 E8               [12] 2465 	mov	a,r0
      006999 F0               [24] 2466 	movx	@dptr,a
                                   2467 ;	tmk_core/protocol/ch555/usb_ak820.c:355: length = 0;
      00699A 90 08 41         [24] 2468 	mov	dptr,#_control_setup_length_10000_290
      00699D E4               [12] 2469 	clr	a
      00699E F0               [24] 2470 	movx	@dptr,a
      00699F A3               [24] 2471 	inc	dptr
      0069A0 F0               [24] 2472 	movx	@dptr,a
                                   2473 ;	tmk_core/protocol/ch555/usb_ak820.c:356: if (D0SetupLen > 8) D0SetupLen = 8;
      0069A1 90 07 D9         [24] 2474 	mov	dptr,#_D0SetupLen
      0069A4 E0               [24] 2475 	movx	a,@dptr
      0069A5 F8               [12] 2476 	mov	r0,a
      0069A6 A3               [24] 2477 	inc	dptr
      0069A7 E0               [24] 2478 	movx	a,@dptr
      0069A8 F9               [12] 2479 	mov	r1,a
      0069A9 C3               [12] 2480 	clr	c
      0069AA 74 08            [12] 2481 	mov	a,#0x08
      0069AC 98               [12] 2482 	subb	a,r0
      0069AD E4               [12] 2483 	clr	a
      0069AE 99               [12] 2484 	subb	a,r1
      0069AF 50 0E            [24] 2485 	jnc	00252$
                                   2486 ;	free result
      0069B1 90 07 D9         [24] 2487 	mov	dptr,#_D0SetupLen
      0069B4 74 08            [12] 2488 	mov	a,#0x08
      0069B6 F0               [24] 2489 	movx	@dptr,a
      0069B7 E4               [12] 2490 	clr	a
      0069B8 A3               [24] 2491 	inc	dptr
      0069B9 F0               [24] 2492 	movx	@dptr,a
      0069BA 80 03            [24] 2493 	sjmp	00252$
      0069BC                       2494 00228$:
                                   2495 ;	tmk_core/protocol/ch555/usb_ak820.c:357: } else { control_stall(); return; }
      0069BC 02 61 25         [24] 2496 	ljmp	_control_stall
      0069BF                       2497 00252$:
                                   2498 ;	tmk_core/protocol/ch555/usb_ak820.c:358: if (length) {
      0069BF 90 08 41         [24] 2499 	mov	dptr,#_control_setup_length_10000_290
      0069C2 E0               [24] 2500 	movx	a,@dptr
      0069C3 F5 19            [12] 2501 	mov	_control_setup_sloc4_1_0,a
      0069C5 A3               [24] 2502 	inc	dptr
      0069C6 E0               [24] 2503 	movx	a,@dptr
      0069C7 F5 1A            [12] 2504 	mov	(_control_setup_sloc4_1_0 + 1),a
      0069C9 E5 19            [12] 2505 	mov	a,_control_setup_sloc4_1_0
      0069CB 45 1A            [12] 2506 	orl	a,(_control_setup_sloc4_1_0 + 1)
      0069CD 60 50            [24] 2507 	jz	00262$
                                   2508 ;	tmk_core/protocol/ch555/usb_ak820.c:359: if (D0SetupLen > length) D0SetupLen = length;
      0069CF 90 07 D9         [24] 2509 	mov	dptr,#_D0SetupLen
      0069D2 E0               [24] 2510 	movx	a,@dptr
      0069D3 F8               [12] 2511 	mov	r0,a
      0069D4 A3               [24] 2512 	inc	dptr
      0069D5 E0               [24] 2513 	movx	a,@dptr
      0069D6 F9               [12] 2514 	mov	r1,a
      0069D7 C3               [12] 2515 	clr	c
      0069D8 E5 19            [12] 2516 	mov	a,_control_setup_sloc4_1_0
      0069DA 98               [12] 2517 	subb	a,r0
      0069DB E5 1A            [12] 2518 	mov	a,(_control_setup_sloc4_1_0 + 1)
      0069DD 99               [12] 2519 	subb	a,r1
      0069DE 50 0A            [24] 2520 	jnc	00559$
                                   2521 ;	free result
      0069E0 90 07 D9         [24] 2522 	mov	dptr,#_D0SetupLen
      0069E3 E5 19            [12] 2523 	mov	a,_control_setup_sloc4_1_0
      0069E5 F0               [24] 2524 	movx	@dptr,a
      0069E6 E5 1A            [12] 2525 	mov	a,(_control_setup_sloc4_1_0 + 1)
      0069E8 A3               [24] 2526 	inc	dptr
      0069E9 F0               [24] 2527 	movx	@dptr,a
                                   2528 ;	tmk_core/protocol/ch555/usb_ak820.c:362: for (i = 0; i < (uint8_t)D0SetupLen; ++i) pD0_EP0_BUF[i] = input_snapshot[offset + i];
      0069EA                       2529 00559$:
      0069EA 75 19 00         [24] 2530 	mov	_control_setup_sloc4_1_0,#0x00
      0069ED                       2531 00296$:
      0069ED 90 07 D9         [24] 2532 	mov	dptr,#_D0SetupLen
      0069F0 E0               [24] 2533 	movx	a,@dptr
      0069F1 F8               [12] 2534 	mov	r0,a
      0069F2 C3               [12] 2535 	clr	c
      0069F3 E5 19            [12] 2536 	mov	a,_control_setup_sloc4_1_0
      0069F5 98               [12] 2537 	subb	a,r0
      0069F6 50 46            [24] 2538 	jnc	00263$
      0069F8 85 19 17         [24] 2539 	mov	_control_setup_sloc3_1_0,_control_setup_sloc4_1_0
      0069FB 74 10            [12] 2540 	mov	a,#0x10
      0069FD 24 00            [12] 2541 	add	a, #0x00
      0069FF F5 18            [12] 2542 	mov	(_control_setup_sloc3_1_0 + 1),a
      006A01 90 08 43         [24] 2543 	mov	dptr,#_control_setup_offset_10000_290
      006A04 E0               [24] 2544 	movx	a,@dptr
      006A05 25 19            [12] 2545 	add	a, _control_setup_sloc4_1_0
      006A07 24 09            [12] 2546 	add	a, #_input_snapshot
      006A09 F5 82            [12] 2547 	mov	dpl,a
      006A0B E4               [12] 2548 	clr	a
      006A0C 34 08            [12] 2549 	addc	a,#(_input_snapshot >> 8)
      006A0E F5 83            [12] 2550 	mov	dph,a
      006A10 E0               [24] 2551 	movx	a,@dptr
      006A11 85 17 82         [24] 2552 	mov	dpl,_control_setup_sloc3_1_0
      006A14 85 18 83         [24] 2553 	mov	dph,(_control_setup_sloc3_1_0 + 1)
      006A17 F0               [24] 2554 	movx	@dptr,a
      006A18 E5 19            [12] 2555 	mov	a,_control_setup_sloc4_1_0
      006A1A 04               [12] 2556 	inc	a
      006A1B F5 19            [12] 2557 	mov	_control_setup_sloc4_1_0,a
      006A1D 80 CE            [24] 2558 	sjmp	00296$
      006A1F                       2559 00262$:
                                   2560 ;	tmk_core/protocol/ch555/usb_ak820.c:363: } else if (index == RAW_INTERFACE && D0SetupLen > RAW_EPSIZE) D0SetupLen = RAW_EPSIZE;
      006A1F BB 01 1C         [24] 2561 	cjne	r3,#0x01,00263$
      006A22 BC 00 19         [24] 2562 	cjne	r4,#0x00,00263$
      006A25 90 07 D9         [24] 2563 	mov	dptr,#_D0SetupLen
      006A28 E0               [24] 2564 	movx	a,@dptr
      006A29 F8               [12] 2565 	mov	r0,a
      006A2A A3               [24] 2566 	inc	dptr
      006A2B E0               [24] 2567 	movx	a,@dptr
      006A2C F9               [12] 2568 	mov	r1,a
      006A2D C3               [12] 2569 	clr	c
      006A2E 74 20            [12] 2570 	mov	a,#0x20
      006A30 98               [12] 2571 	subb	a,r0
      006A31 E4               [12] 2572 	clr	a
      006A32 99               [12] 2573 	subb	a,r1
      006A33 50 09            [24] 2574 	jnc	00263$
                                   2575 ;	free result
      006A35 90 07 D9         [24] 2576 	mov	dptr,#_D0SetupLen
      006A38 74 20            [12] 2577 	mov	a,#0x20
      006A3A F0               [24] 2578 	movx	@dptr,a
      006A3B E4               [12] 2579 	clr	a
      006A3C A3               [24] 2580 	inc	dptr
      006A3D F0               [24] 2581 	movx	@dptr,a
      006A3E                       2582 00263$:
                                   2583 ;	tmk_core/protocol/ch555/usb_ak820.c:364: D0_EP0T_L = D0SetupLen;
      006A3E 90 07 D9         [24] 2584 	mov	dptr,#_D0SetupLen
      006A41 E0               [24] 2585 	movx	a,@dptr
      006A42 90 22 08         [24] 2586 	mov	dptr,#0x2208
      006A45 F0               [24] 2587 	movx	@dptr,a
                                   2588 ;	tmk_core/protocol/ch555/usb_ak820.c:365: control_phase = CTRL_STATUS_OUT;
      006A46 90 08 37         [24] 2589 	mov	dptr,#_control_phase
      006A49 74 02            [12] 2590 	mov	a,#0x02
      006A4B F0               [24] 2591 	movx	@dptr,a
      006A4C 02 6A D4         [24] 2592 	ljmp	00291$
      006A4F                       2593 00273$:
                                   2594 ;	tmk_core/protocol/ch555/usb_ak820.c:366: } else if (index == KEYBOARD_INTERFACE && D0UsbConfig && type == 0xa1 && D0SetupReqCode == DEF_USB_GET_PROTOCOL && zero_value && D0SetupLen == 1) {
      006A4F EB               [12] 2595 	mov	a,r3
      006A50 4C               [12] 2596 	orl	a,r4
      006A51 70 37            [24] 2597 	jnz	00265$
      006A53 90 07 DE         [24] 2598 	mov	dptr,#_D0UsbConfig
      006A56 E0               [24] 2599 	movx	a,@dptr
      006A57 60 31            [24] 2600 	jz	00265$
      006A59 EA               [12] 2601 	mov	a,r2
      006A5A 60 2E            [24] 2602 	jz	00265$
      006A5C 90 07 D8         [24] 2603 	mov	dptr,#_D0SetupReqCode
      006A5F E0               [24] 2604 	movx	a,@dptr
      006A60 FA               [12] 2605 	mov	r2,a
      006A61 BA 03 26         [24] 2606 	cjne	r2,#0x03,00265$
      006A64 30 17 23         [24] 2607 	jnb	_control_setup_zero_value_10000_290,00265$
      006A67 90 07 D9         [24] 2608 	mov	dptr,#_D0SetupLen
      006A6A E0               [24] 2609 	movx	a,@dptr
      006A6B F9               [12] 2610 	mov	r1,a
      006A6C A3               [24] 2611 	inc	dptr
      006A6D E0               [24] 2612 	movx	a,@dptr
      006A6E FA               [12] 2613 	mov	r2,a
      006A6F B9 01 18         [24] 2614 	cjne	r1,#0x01,00265$
      006A72 BA 00 15         [24] 2615 	cjne	r2,#0x00,00265$
                                   2616 ;	tmk_core/protocol/ch555/usb_ak820.c:367: pD0_EP0_BUF[0] = keyboard_protocol;
      006A75 90 0D FB         [24] 2617 	mov	dptr,#_keyboard_protocol
      006A78 E0               [24] 2618 	movx	a,@dptr
      006A79 90 10 00         [24] 2619 	mov	dptr,#0x1000
      006A7C F0               [24] 2620 	movx	@dptr,a
                                   2621 ;	tmk_core/protocol/ch555/usb_ak820.c:368: D0_EP0T_L = 1;
      006A7D 90 22 08         [24] 2622 	mov	dptr,#0x2208
      006A80 74 01            [12] 2623 	mov	a,#0x01
      006A82 F0               [24] 2624 	movx	@dptr,a
                                   2625 ;	tmk_core/protocol/ch555/usb_ak820.c:369: control_phase = CTRL_STATUS_OUT;
      006A83 90 08 37         [24] 2626 	mov	dptr,#_control_phase
      006A86 04               [12] 2627 	inc	a
      006A87 F0               [24] 2628 	movx	@dptr,a
      006A88 80 4A            [24] 2629 	sjmp	00291$
      006A8A                       2630 00265$:
                                   2631 ;	tmk_core/protocol/ch555/usb_ak820.c:370: } else { control_stall(); return; }
                                   2632 ;	tmk_core/protocol/ch555/usb_ak820.c:372: case DEF_USB_GET_IDLE:
      006A8A 02 61 25         [24] 2633 	ljmp	_control_stall
      006A8D                       2634 00282$:
                                   2635 ;	tmk_core/protocol/ch555/usb_ak820.c:373: if (valid_interface && D0UsbConfig && type == 0xa1 && !(value >> 8) && D0SetupLen == 1) {
      006A8D 30 15 3E         [24] 2636 	jnb	_control_setup_valid_interface_10000_290,00284$
      006A90 90 07 DE         [24] 2637 	mov	dptr,#_D0UsbConfig
      006A93 E0               [24] 2638 	movx	a,@dptr
      006A94 60 38            [24] 2639 	jz	00284$
      006A96 BF A1 35         [24] 2640 	cjne	r7,#0xa1,00284$
      006A99 8E 05            [24] 2641 	mov	ar5,r6
      006A9B 7E 00            [12] 2642 	mov	r6,#0x00
      006A9D ED               [12] 2643 	mov	a,r5
      006A9E 4E               [12] 2644 	orl	a,r6
      006A9F 70 2D            [24] 2645 	jnz	00284$
      006AA1 90 07 D9         [24] 2646 	mov	dptr,#_D0SetupLen
      006AA4 E0               [24] 2647 	movx	a,@dptr
      006AA5 FE               [12] 2648 	mov	r6,a
      006AA6 A3               [24] 2649 	inc	dptr
      006AA7 E0               [24] 2650 	movx	a,@dptr
      006AA8 FF               [12] 2651 	mov	r7,a
      006AA9 BE 01 22         [24] 2652 	cjne	r6,#0x01,00284$
      006AAC BF 00 1F         [24] 2653 	cjne	r7,#0x00,00284$
                                   2654 ;	tmk_core/protocol/ch555/usb_ak820.c:374: pD0_EP0_BUF[0] = index == KEYBOARD_INTERFACE ? keyboard_idle : 0;
      006AAF EB               [12] 2655 	mov	a,r3
      006AB0 4C               [12] 2656 	orl	a,r4
      006AB1 70 07            [24] 2657 	jnz	00324$
      006AB3 90 06 B6         [24] 2658 	mov	dptr,#_keyboard_idle
      006AB6 E0               [24] 2659 	movx	a,@dptr
      006AB7 FF               [12] 2660 	mov	r7,a
      006AB8 80 02            [24] 2661 	sjmp	00325$
      006ABA                       2662 00324$:
      006ABA 7F 00            [12] 2663 	mov	r7,#0x00
      006ABC                       2664 00325$:
      006ABC 90 10 00         [24] 2665 	mov	dptr,#0x1000
      006ABF EF               [12] 2666 	mov	a,r7
      006AC0 F0               [24] 2667 	movx	@dptr,a
                                   2668 ;	tmk_core/protocol/ch555/usb_ak820.c:375: D0_EP0T_L = 1;
      006AC1 90 22 08         [24] 2669 	mov	dptr,#0x2208
      006AC4 74 01            [12] 2670 	mov	a,#0x01
      006AC6 F0               [24] 2671 	movx	@dptr,a
                                   2672 ;	tmk_core/protocol/ch555/usb_ak820.c:376: control_phase = CTRL_STATUS_OUT;
      006AC7 90 08 37         [24] 2673 	mov	dptr,#_control_phase
      006ACA 04               [12] 2674 	inc	a
      006ACB F0               [24] 2675 	movx	@dptr,a
      006ACC 80 06            [24] 2676 	sjmp	00291$
      006ACE                       2677 00284$:
                                   2678 ;	tmk_core/protocol/ch555/usb_ak820.c:377: } else { control_stall(); return; }
                                   2679 ;	tmk_core/protocol/ch555/usb_ak820.c:379: default: control_stall(); return;
      006ACE 02 61 25         [24] 2680 	ljmp	_control_stall
      006AD1                       2681 00290$:
                                   2682 ;	tmk_core/protocol/ch555/usb_ak820.c:380: }
      006AD1 02 61 25         [24] 2683 	ljmp	_control_stall
      006AD4                       2684 00291$:
                                   2685 ;	tmk_core/protocol/ch555/usb_ak820.c:381: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_ACK | UEP_T_RES_ACK;
      006AD4 90 22 00         [24] 2686 	mov	dptr,#0x2200
      006AD7 74 C0            [12] 2687 	mov	a,#0xc0
      006AD9 F0               [24] 2688 	movx	@dptr,a
                                   2689 ;	tmk_core/protocol/ch555/usb_ak820.c:382: }
      006ADA 22               [24] 2690 	ret
                                   2691 ;------------------------------------------------------------
                                   2692 ;Allocation info for local variables in function 'control_out'
                                   2693 ;------------------------------------------------------------
                                   2694 ;i             Allocated with name '_control_out_i_10000_374'
                                   2695 ;------------------------------------------------------------
                                   2696 ;	tmk_core/protocol/ch555/usb_ak820.c:384: static void control_out(void) {
                                   2697 ;	-----------------------------------------
                                   2698 ;	 function control_out
                                   2699 ;	-----------------------------------------
      006ADB                       2700 _control_out:
                                   2701 ;	tmk_core/protocol/ch555/usb_ak820.c:386: if (!(D0_STATUS & bUXS_TOG_OK)) return; /* duplicate OUT is not a new request */
      006ADB 90 22 0F         [24] 2702 	mov	dptr,#0x220f
      006ADE E0               [24] 2703 	movx	a,@dptr
      006ADF 20 E6 01         [24] 2704 	jb	acc.6,00102$
      006AE2 22               [24] 2705 	ret
      006AE3                       2706 00102$:
                                   2707 ;	tmk_core/protocol/ch555/usb_ak820.c:387: if (control_phase == CTRL_STATUS_OUT && D0_RX_LEN == 0) {
      006AE3 90 08 37         [24] 2708 	mov	dptr,#_control_phase
      006AE6 E0               [24] 2709 	movx	a,@dptr
      006AE7 FF               [12] 2710 	mov	r7,a
      006AE8 BF 02 12         [24] 2711 	cjne	r7,#0x02,00104$
      006AEB 90 22 0E         [24] 2712 	mov	dptr,#0x220e
      006AEE E0               [24] 2713 	movx	a,@dptr
      006AEF 70 0C            [24] 2714 	jnz	00104$
                                   2715 ;	tmk_core/protocol/ch555/usb_ak820.c:388: control_phase = CTRL_IDLE;
      006AF1 90 08 37         [24] 2716 	mov	dptr,#_control_phase
      006AF4 E4               [12] 2717 	clr	a
      006AF5 F0               [24] 2718 	movx	@dptr,a
                                   2719 ;	tmk_core/protocol/ch555/usb_ak820.c:389: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      006AF6 90 22 00         [24] 2720 	mov	dptr,#0x2200
      006AF9 74 02            [12] 2721 	mov	a,#0x02
      006AFB F0               [24] 2722 	movx	@dptr,a
                                   2723 ;	tmk_core/protocol/ch555/usb_ak820.c:390: return;
      006AFC 22               [24] 2724 	ret
      006AFD                       2725 00104$:
                                   2726 ;	tmk_core/protocol/ch555/usb_ak820.c:392: if (control_phase != CTRL_DATA_OUT || D0_RX_LEN != D0SetupLen) { control_stall(); return; }
      006AFD BF 04 19         [24] 2727 	cjne	r7,#0x04,00106$
      006B00 90 22 0E         [24] 2728 	mov	dptr,#0x220e
      006B03 E0               [24] 2729 	movx	a,@dptr
      006B04 FF               [12] 2730 	mov	r7,a
      006B05 90 07 D9         [24] 2731 	mov	dptr,#_D0SetupLen
      006B08 E0               [24] 2732 	movx	a,@dptr
      006B09 FD               [12] 2733 	mov	r5,a
      006B0A A3               [24] 2734 	inc	dptr
      006B0B E0               [24] 2735 	movx	a,@dptr
      006B0C FE               [12] 2736 	mov	r6,a
      006B0D 7C 00            [12] 2737 	mov	r4,#0x00
      006B0F EF               [12] 2738 	mov	a,r7
      006B10 B5 05 06         [24] 2739 	cjne	a,ar5,00209$
      006B13 EC               [12] 2740 	mov	a,r4
      006B14 B5 06 02         [24] 2741 	cjne	a,ar6,00209$
      006B17 80 03            [24] 2742 	sjmp	00107$
      006B19                       2743 00209$:
      006B19                       2744 00106$:
      006B19 02 61 25         [24] 2745 	ljmp	_control_stall
      006B1C                       2746 00107$:
                                   2747 ;	tmk_core/protocol/ch555/usb_ak820.c:393: if (output_kind == OUTPUT_RAW && raw_state == RAW_RX) {
      006B1C 90 08 38         [24] 2748 	mov	dptr,#_output_kind
      006B1F E0               [24] 2749 	movx	a,@dptr
      006B20 FF               [12] 2750 	mov	r7,a
      006B21 BF 01 2E         [24] 2751 	cjne	r7,#0x01,00118$
      006B24 90 07 E6         [24] 2752 	mov	dptr,#_raw_state
      006B27 E0               [24] 2753 	movx	a,@dptr
      006B28 FE               [12] 2754 	mov	r6,a
      006B29 BE 01 26         [24] 2755 	cjne	r6,#0x01,00118$
                                   2756 ;	tmk_core/protocol/ch555/usb_ak820.c:394: for (i = 0; i < RAW_EPSIZE; ++i) raw_buffer[i] = pD0_EP0_BUF[i];
      006B2C 7E 00            [12] 2757 	mov	r6,#0x00
      006B2E                       2758 00121$:
      006B2E EE               [12] 2759 	mov	a,r6
      006B2F 24 E7            [12] 2760 	add	a, #_raw_buffer
      006B31 FC               [12] 2761 	mov	r4,a
      006B32 E4               [12] 2762 	clr	a
      006B33 34 07            [12] 2763 	addc	a, #(_raw_buffer >> 8)
      006B35 FD               [12] 2764 	mov	r5,a
      006B36 8E 82            [24] 2765 	mov	dpl,r6
      006B38 74 10            [12] 2766 	mov	a,#0x10
      006B3A 24 00            [12] 2767 	add	a, #0x00
      006B3C F5 83            [12] 2768 	mov	dph,a
      006B3E E0               [24] 2769 	movx	a,@dptr
      006B3F 8C 82            [24] 2770 	mov	dpl,r4
      006B41 8D 83            [24] 2771 	mov	dph,r5
      006B43 F0               [24] 2772 	movx	@dptr,a
      006B44 0E               [12] 2773 	inc	r6
      006B45 BE 20 00         [24] 2774 	cjne	r6,#0x20,00214$
      006B48                       2775 00214$:
      006B48 40 E4            [24] 2776 	jc	00121$
                                   2777 ;	tmk_core/protocol/ch555/usb_ak820.c:395: raw_state = RAW_READY; /* publish only after the entire packet is copied */
      006B4A 90 07 E6         [24] 2778 	mov	dptr,#_raw_state
      006B4D 74 02            [12] 2779 	mov	a,#0x02
      006B4F F0               [24] 2780 	movx	@dptr,a
      006B50 80 2B            [24] 2781 	sjmp	00119$
      006B52                       2782 00118$:
                                   2783 ;	tmk_core/protocol/ch555/usb_ak820.c:396: } else if (output_kind == OUTPUT_LED) {
      006B52 BF 02 0A         [24] 2784 	cjne	r7,#0x02,00115$
                                   2785 ;	tmk_core/protocol/ch555/usb_ak820.c:397: KB_USB_SetReport = pD0_EP0_BUF[0];
      006B55 90 10 00         [24] 2786 	mov	dptr,#0x1000
      006B58 E0               [24] 2787 	movx	a,@dptr
      006B59 90 07 E3         [24] 2788 	mov	dptr,#_KB_USB_SetReport
      006B5C F0               [24] 2789 	movx	@dptr,a
      006B5D 80 1E            [24] 2790 	sjmp	00119$
      006B5F                       2791 00115$:
                                   2792 ;	tmk_core/protocol/ch555/usb_ak820.c:398: } else if (output_kind == OUTPUT_SHARED_LED && pD0_EP0_BUF[0] == output_report_id) {
      006B5F BF 03 18         [24] 2793 	cjne	r7,#0x03,00111$
      006B62 90 10 00         [24] 2794 	mov	dptr,#0x1000
      006B65 E0               [24] 2795 	movx	a,@dptr
      006B66 FF               [12] 2796 	mov	r7,a
      006B67 90 08 39         [24] 2797 	mov	dptr,#_output_report_id
      006B6A E0               [24] 2798 	movx	a,@dptr
      006B6B FE               [12] 2799 	mov	r6,a
      006B6C EF               [12] 2800 	mov	a,r7
      006B6D B5 06 0A         [24] 2801 	cjne	a,ar6,00111$
                                   2802 ;	tmk_core/protocol/ch555/usb_ak820.c:399: KB_USB_SetReport = pD0_EP0_BUF[1];
      006B70 90 10 01         [24] 2803 	mov	dptr,#0x1001
      006B73 E0               [24] 2804 	movx	a,@dptr
      006B74 90 07 E3         [24] 2805 	mov	dptr,#_KB_USB_SetReport
      006B77 F0               [24] 2806 	movx	@dptr,a
      006B78 80 03            [24] 2807 	sjmp	00119$
      006B7A                       2808 00111$:
                                   2809 ;	tmk_core/protocol/ch555/usb_ak820.c:400: } else { control_stall(); return; }
      006B7A 02 61 25         [24] 2810 	ljmp	_control_stall
      006B7D                       2811 00119$:
                                   2812 ;	tmk_core/protocol/ch555/usb_ak820.c:401: output_kind = OUTPUT_NONE;
      006B7D 90 08 38         [24] 2813 	mov	dptr,#_output_kind
      006B80 E4               [12] 2814 	clr	a
      006B81 F0               [24] 2815 	movx	@dptr,a
                                   2816 ;	tmk_core/protocol/ch555/usb_ak820.c:402: D0SetupLen = 0;
      006B82 90 07 D9         [24] 2817 	mov	dptr,#_D0SetupLen
      006B85 F0               [24] 2818 	movx	@dptr,a
      006B86 A3               [24] 2819 	inc	dptr
      006B87 F0               [24] 2820 	movx	@dptr,a
                                   2821 ;	tmk_core/protocol/ch555/usb_ak820.c:403: control_phase = CTRL_STATUS_IN;
      006B88 90 08 37         [24] 2822 	mov	dptr,#_control_phase
      006B8B 74 03            [12] 2823 	mov	a,#0x03
      006B8D F0               [24] 2824 	movx	@dptr,a
                                   2825 ;	tmk_core/protocol/ch555/usb_ak820.c:404: D0_EP0T_L = 0;
      006B8E 90 22 08         [24] 2826 	mov	dptr,#0x2208
      006B91 E4               [12] 2827 	clr	a
      006B92 F0               [24] 2828 	movx	@dptr,a
                                   2829 ;	tmk_core/protocol/ch555/usb_ak820.c:405: D0_EP0RES = bUEP_T_TOG | UEP_R_RES_NAK | UEP_T_RES_ACK;
      006B93 F5 82            [12] 2830 	mov	dpl,a
      006B95 74 48            [12] 2831 	mov	a,#0x48
      006B97 F0               [24] 2832 	movx	@dptr,a
                                   2833 ;	tmk_core/protocol/ch555/usb_ak820.c:406: }
      006B98 22               [24] 2834 	ret
                                   2835 ;------------------------------------------------------------
                                   2836 ;Allocation info for local variables in function 'control_in'
                                   2837 ;------------------------------------------------------------
                                   2838 ;	tmk_core/protocol/ch555/usb_ak820.c:408: static void control_in(void) {
                                   2839 ;	-----------------------------------------
                                   2840 ;	 function control_in
                                   2841 ;	-----------------------------------------
      006B99                       2842 _control_in:
                                   2843 ;	tmk_core/protocol/ch555/usb_ak820.c:409: if (control_phase == CTRL_DATA_IN) {
      006B99 90 08 37         [24] 2844 	mov	dptr,#_control_phase
      006B9C E0               [24] 2845 	movx	a,@dptr
      006B9D FF               [12] 2846 	mov	r7,a
      006B9E BF 01 22         [24] 2847 	cjne	r7,#0x01,00109$
                                   2848 ;	tmk_core/protocol/ch555/usb_ak820.c:410: if (D0SetupLen || control_zlp) {
      006BA1 90 07 D9         [24] 2849 	mov	dptr,#_D0SetupLen
      006BA4 E0               [24] 2850 	movx	a,@dptr
      006BA5 FD               [12] 2851 	mov	r5,a
      006BA6 A3               [24] 2852 	inc	dptr
      006BA7 E0               [24] 2853 	movx	a,@dptr
      006BA8 4D               [12] 2854 	orl	a,r5
      006BA9 70 06            [24] 2855 	jnz	00101$
      006BAB 90 08 3A         [24] 2856 	mov	dptr,#_control_zlp
      006BAE E0               [24] 2857 	movx	a,@dptr
      006BAF 60 0A            [24] 2858 	jz	00102$
      006BB1                       2859 00101$:
                                   2860 ;	tmk_core/protocol/ch555/usb_ak820.c:411: D0_EP0RES ^= bUEP_T_TOG;
      006BB1 90 22 00         [24] 2861 	mov	dptr,#0x2200
      006BB4 E0               [24] 2862 	movx	a,@dptr
      006BB5 64 40            [12] 2863 	xrl	a,#0x40
      006BB7 F0               [24] 2864 	movx	@dptr,a
                                   2865 ;	tmk_core/protocol/ch555/usb_ak820.c:412: control_next();
                                   2866 ;	tmk_core/protocol/ch555/usb_ak820.c:413: return;
      006BB8 02 61 47         [24] 2867 	ljmp	_control_next
      006BBB                       2868 00102$:
                                   2869 ;	tmk_core/protocol/ch555/usb_ak820.c:415: control_phase = CTRL_STATUS_OUT;
      006BBB 90 08 37         [24] 2870 	mov	dptr,#_control_phase
      006BBE 74 02            [12] 2871 	mov	a,#0x02
      006BC0 F0               [24] 2872 	movx	@dptr,a
      006BC1 80 18            [24] 2873 	sjmp	00110$
      006BC3                       2874 00109$:
                                   2875 ;	tmk_core/protocol/ch555/usb_ak820.c:416: } else if (control_phase == CTRL_STATUS_IN) {
      006BC3 BF 03 15         [24] 2876 	cjne	r7,#0x03,00110$
                                   2877 ;	tmk_core/protocol/ch555/usb_ak820.c:417: if (D0SetupReqCode == USB_SET_ADDRESS) D0_ADDR = D0SetupLen;
      006BC6 90 07 D8         [24] 2878 	mov	dptr,#_D0SetupReqCode
      006BC9 E0               [24] 2879 	movx	a,@dptr
      006BCA FF               [12] 2880 	mov	r7,a
      006BCB BF 05 08         [24] 2881 	cjne	r7,#0x05,00105$
      006BCE 90 07 D9         [24] 2882 	mov	dptr,#_D0SetupLen
      006BD1 E0               [24] 2883 	movx	a,@dptr
      006BD2 90 22 07         [24] 2884 	mov	dptr,#0x2207
      006BD5 F0               [24] 2885 	movx	@dptr,a
      006BD6                       2886 00105$:
                                   2887 ;	tmk_core/protocol/ch555/usb_ak820.c:418: control_phase = CTRL_IDLE;
      006BD6 90 08 37         [24] 2888 	mov	dptr,#_control_phase
      006BD9 E4               [12] 2889 	clr	a
      006BDA F0               [24] 2890 	movx	@dptr,a
      006BDB                       2891 00110$:
                                   2892 ;	tmk_core/protocol/ch555/usb_ak820.c:420: D0_EP0RES = bUEP_R_TOG | UEP_R_RES_ACK | UEP_T_RES_NAK;
      006BDB 90 22 00         [24] 2893 	mov	dptr,#0x2200
      006BDE 74 82            [12] 2894 	mov	a,#0x82
      006BE0 F0               [24] 2895 	movx	@dptr,a
                                   2896 ;	tmk_core/protocol/ch555/usb_ak820.c:421: }
      006BE1 22               [24] 2897 	ret
                                   2898 ;------------------------------------------------------------
                                   2899 ;Allocation info for local variables in function 'USB_DeviceInterrupt'
                                   2900 ;------------------------------------------------------------
                                   2901 ;status        Allocated with name '_USB_DeviceInterrupt_status_10000_398'
                                   2902 ;endpoint      Allocated with name '_USB_DeviceInterrupt_endpoint_10000_398'
                                   2903 ;------------------------------------------------------------
                                   2904 ;	tmk_core/protocol/ch555/usb_ak820.c:423: void USB_DeviceInterrupt(void) {
                                   2905 ;	-----------------------------------------
                                   2906 ;	 function USB_DeviceInterrupt
                                   2907 ;	-----------------------------------------
      006BE2                       2908 _USB_DeviceInterrupt:
                                   2909 ;	tmk_core/protocol/ch555/usb_ak820.c:426: do {
      006BE2                       2910 00129$:
                                   2911 ;	tmk_core/protocol/ch555/usb_ak820.c:428: if (USB_IF & bUX_IF_BUS_RST) {
      006BE2 90 22 3D         [24] 2912 	mov	dptr,#0x223d
      006BE5 E0               [24] 2913 	movx	a,@dptr
      006BE6 30 E0 4B         [24] 2914 	jnb	acc.0,00127$
                                   2915 ;	tmk_core/protocol/ch555/usb_ak820.c:429: endpoints_reset();
      006BE9 12 60 CA         [24] 2916 	lcall	_endpoints_reset
                                   2917 ;	tmk_core/protocol/ch555/usb_ak820.c:430: D0_ADDR = 0;
      006BEC 90 22 07         [24] 2918 	mov	dptr,#0x2207
      006BEF E4               [12] 2919 	clr	a
      006BF0 F0               [24] 2920 	movx	@dptr,a
                                   2921 ;	tmk_core/protocol/ch555/usb_ak820.c:431: D0UsbConfig = USB_EnumStatus = USB_SleepStatus = 0;
      006BF1 90 07 E0         [24] 2922 	mov	dptr,#_USB_SleepStatus
      006BF4 F0               [24] 2923 	movx	@dptr,a
      006BF5 90 07 DF         [24] 2924 	mov	dptr,#_USB_EnumStatus
      006BF8 F0               [24] 2925 	movx	@dptr,a
      006BF9 90 07 DE         [24] 2926 	mov	dptr,#_D0UsbConfig
      006BFC F0               [24] 2927 	movx	@dptr,a
                                   2928 ;	tmk_core/protocol/ch555/usb_ak820.c:432: KB_USB_SetReport = 0;
      006BFD 90 07 E3         [24] 2929 	mov	dptr,#_KB_USB_SetReport
      006C00 F0               [24] 2930 	movx	@dptr,a
                                   2931 ;	tmk_core/protocol/ch555/usb_ak820.c:433: keyboard_protocol = 1;
      006C01 90 0D FB         [24] 2932 	mov	dptr,#_keyboard_protocol
      006C04 04               [12] 2933 	inc	a
      006C05 F0               [24] 2934 	movx	@dptr,a
                                   2935 ;	tmk_core/protocol/ch555/usb_ak820.c:434: keyboard_idle = 0;
      006C06 90 06 B6         [24] 2936 	mov	dptr,#_keyboard_idle
      006C09 E4               [12] 2937 	clr	a
      006C0A F0               [24] 2938 	movx	@dptr,a
                                   2939 ;	tmk_core/protocol/ch555/usb_ak820.c:435: keyboard_reset = 1;
      006C0B 90 08 08         [24] 2940 	mov	dptr,#_keyboard_reset
      006C0E 04               [12] 2941 	inc	a
      006C0F F0               [24] 2942 	movx	@dptr,a
                                   2943 ;	tmk_core/protocol/ch555/usb_ak820.c:436: D0SetupReqCode = 0xff;
      006C10 90 07 D8         [24] 2944 	mov	dptr,#_D0SetupReqCode
      006C13 74 FF            [12] 2945 	mov	a,#0xff
      006C15 F0               [24] 2946 	movx	@dptr,a
                                   2947 ;	tmk_core/protocol/ch555/usb_ak820.c:437: D0SetupLen = 0;
      006C16 90 07 D9         [24] 2948 	mov	dptr,#_D0SetupLen
      006C19 E4               [12] 2949 	clr	a
      006C1A F0               [24] 2950 	movx	@dptr,a
      006C1B A3               [24] 2951 	inc	dptr
      006C1C F0               [24] 2952 	movx	@dptr,a
                                   2953 ;	tmk_core/protocol/ch555/usb_ak820.c:438: control_phase = CTRL_IDLE;
      006C1D 90 08 37         [24] 2954 	mov	dptr,#_control_phase
      006C20 F0               [24] 2955 	movx	@dptr,a
                                   2956 ;	tmk_core/protocol/ch555/usb_ak820.c:439: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      006C21 90 22 00         [24] 2957 	mov	dptr,#0x2200
      006C24 74 02            [12] 2958 	mov	a,#0x02
      006C26 F0               [24] 2959 	movx	@dptr,a
                                   2960 ;	tmk_core/protocol/ch555/usb_ak820.c:440: ACK_TRANSFER();
      006C27 90 22 0F         [24] 2961 	mov	dptr,#0x220f
      006C2A E4               [12] 2962 	clr	a
      006C2B F0               [24] 2963 	movx	@dptr,a
                                   2964 ;	tmk_core/protocol/ch555/usb_ak820.c:441: ACK_RESET();
      006C2C 90 22 3D         [24] 2965 	mov	dptr,#0x223d
      006C2F 04               [12] 2966 	inc	a
      006C30 F0               [24] 2967 	movx	@dptr,a
      006C31 02 6C CC         [24] 2968 	ljmp	00130$
      006C34                       2969 00127$:
                                   2970 ;	tmk_core/protocol/ch555/usb_ak820.c:442: } else if (USB_IF & bUX_IF_D0_TRANS) {
      006C34 90 22 3D         [24] 2971 	mov	dptr,#0x223d
      006C37 E0               [24] 2972 	movx	a,@dptr
      006C38 30 E5 60         [24] 2973 	jnb	acc.5,00124$
                                   2974 ;	tmk_core/protocol/ch555/usb_ak820.c:443: status = D0_STATUS;
      006C3B 90 22 0F         [24] 2975 	mov	dptr,#0x220f
      006C3E E0               [24] 2976 	movx	a,@dptr
      006C3F FF               [12] 2977 	mov	r7,a
                                   2978 ;	tmk_core/protocol/ch555/usb_ak820.c:444: endpoint = status & MASK_UXS_ENDP;
      006C40 74 07            [12] 2979 	mov	a,#0x07
      006C42 5F               [12] 2980 	anl	a,r7
      006C43 FE               [12] 2981 	mov	r6,a
                                   2982 ;	tmk_core/protocol/ch555/usb_ak820.c:448: if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_OUT && !endpoint) {
      006C44 EF               [12] 2983 	mov	a,r7
      006C45 54 18            [12] 2984 	anl	a,#0x18
      006C47 70 08            [24] 2985 	jnz	00115$
      006C49 EE               [12] 2986 	mov	a,r6
      006C4A 70 05            [24] 2987 	jnz	00115$
                                   2988 ;	tmk_core/protocol/ch555/usb_ak820.c:449: control_out();
      006C4C 12 6A DB         [24] 2989 	lcall	_control_out
      006C4F 80 43            [24] 2990 	sjmp	00116$
      006C51                       2991 00115$:
                                   2992 ;	tmk_core/protocol/ch555/usb_ak820.c:450: } else if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_IN) {
      006C51 8F 05            [24] 2993 	mov	ar5,r7
      006C53 74 18            [12] 2994 	mov	a,#0x18
      006C55 5D               [12] 2995 	anl	a,r5
      006C56 FC               [12] 2996 	mov	r4,a
      006C57 BC 10 2D         [24] 2997 	cjne	r4,#0x10,00112$
                                   2998 ;	tmk_core/protocol/ch555/usb_ak820.c:451: if (!endpoint) control_in();
      006C5A EE               [12] 2999 	mov	a,r6
      006C5B 70 05            [24] 3000 	jnz	00106$
      006C5D 12 6B 99         [24] 3001 	lcall	_control_in
      006C60 80 32            [24] 3002 	sjmp	00116$
      006C62                       3003 00106$:
                                   3004 ;	tmk_core/protocol/ch555/usb_ak820.c:452: else if (endpoint <= 3) {
      006C62 EE               [12] 3005 	mov	a,r6
      006C63 24 FC            [12] 3006 	add	a,#0xff - 0x03
      006C65 40 2D            [24] 3007 	jc	00116$
                                   3008 ;	free result
                                   3009 ;	tmk_core/protocol/ch555/usb_ak820.c:453: EP_RESPONSE(endpoint) = (EP_RESPONSE(endpoint) & ~MASK_UEP_X_RES) | UEP_X_RES_NAK;
      006C67 8E 04            [24] 3010 	mov	ar4,r6
      006C69 7B 00            [12] 3011 	mov	r3,#0x00
      006C6B 74 22            [12] 3012 	mov	a,#0x22
      006C6D 2B               [12] 3013 	add	a, r3
      006C6E FB               [12] 3014 	mov	r3,a
      006C6F 8C 82            [24] 3015 	mov	dpl,r4
      006C71 8B 83            [24] 3016 	mov	dph,r3
      006C73 E0               [24] 3017 	movx	a,@dptr
      006C74 FA               [12] 3018 	mov	r2,a
      006C75 74 FC            [12] 3019 	mov	a,#0xfc
      006C77 5A               [12] 3020 	anl	a,r2
      006C78 44 02            [12] 3021 	orl	a,#0x02
      006C7A 8C 82            [24] 3022 	mov	dpl,r4
      006C7C 8B 83            [24] 3023 	mov	dph,r3
      006C7E F0               [24] 3024 	movx	@dptr,a
                                   3025 ;	tmk_core/protocol/ch555/usb_ak820.c:454: if (endpoint == RAW_IN_EPNUM) raw_complete();
      006C7F BE 03 12         [24] 3026 	cjne	r6,#0x03,00116$
      006C82 12 60 AD         [24] 3027 	lcall	_raw_complete
      006C85 80 0D            [24] 3028 	sjmp	00116$
      006C87                       3029 00112$:
                                   3030 ;	tmk_core/protocol/ch555/usb_ak820.c:456: } else if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_FREE && (status & bUXS_SETUP_ACT)) {
      006C87 53 05 18         [24] 3031 	anl	ar5,#0x18
      006C8A BD 18 07         [24] 3032 	cjne	r5,#0x18,00116$
      006C8D EF               [12] 3033 	mov	a,r7
      006C8E 30 E5 03         [24] 3034 	jnb	acc.5,00116$
                                   3035 ;	tmk_core/protocol/ch555/usb_ak820.c:457: control_setup();
      006C91 12 63 3E         [24] 3036 	lcall	_control_setup
      006C94                       3037 00116$:
                                   3038 ;	tmk_core/protocol/ch555/usb_ak820.c:459: ACK_TRANSFER();
      006C94 90 22 0F         [24] 3039 	mov	dptr,#0x220f
      006C97 E4               [12] 3040 	clr	a
      006C98 F0               [24] 3041 	movx	@dptr,a
      006C99 80 31            [24] 3042 	sjmp	00130$
      006C9B                       3043 00124$:
                                   3044 ;	tmk_core/protocol/ch555/usb_ak820.c:460: } else if (USB_IF & bUX_IF_SUSPEND) {
      006C9B 90 22 3D         [24] 3045 	mov	dptr,#0x223d
      006C9E E0               [24] 3046 	movx	a,@dptr
      006C9F 30 E2 2A         [24] 3047 	jnb	acc.2,00130$
                                   3048 ;	tmk_core/protocol/ch555/usb_ak820.c:462: ak820_os_indicator_mode = AK820_OS_NORMAL;
      006CA2 90 06 09         [24] 3049 	mov	dptr,#_ak820_os_indicator_mode
      006CA5 E4               [12] 3050 	clr	a
      006CA6 F0               [24] 3051 	movx	@dptr,a
                                   3052 ;	tmk_core/protocol/ch555/usb_ak820.c:464: if (USB_IF & bUX_SUSPEND) USB_SleepStatus |= 2;
      006CA7 90 22 3D         [24] 3053 	mov	dptr,#0x223d
      006CAA E0               [24] 3054 	movx	a,@dptr
      006CAB 30 E3 0A         [24] 3055 	jnb	acc.3,00119$
      006CAE 90 07 E0         [24] 3056 	mov	dptr,#_USB_SleepStatus
      006CB1 E0               [24] 3057 	movx	a,@dptr
      006CB2 43 E0 02         [24] 3058 	orl	acc,#0x02
      006CB5 F0               [24] 3059 	movx	@dptr,a
      006CB6 80 0E            [24] 3060 	sjmp	00120$
      006CB8                       3061 00119$:
                                   3062 ;	tmk_core/protocol/ch555/usb_ak820.c:466: USB_SleepStatus &= ~2;
      006CB8 90 07 E0         [24] 3063 	mov	dptr,#_USB_SleepStatus
      006CBB E0               [24] 3064 	movx	a,@dptr
      006CBC 53 E0 FD         [24] 3065 	anl	acc,#0xfd
      006CBF F0               [24] 3066 	movx	@dptr,a
                                   3067 ;	tmk_core/protocol/ch555/usb_ak820.c:467: keyboard_reset = 1;
      006CC0 90 08 08         [24] 3068 	mov	dptr,#_keyboard_reset
      006CC3 74 01            [12] 3069 	mov	a,#0x01
      006CC5 F0               [24] 3070 	movx	@dptr,a
      006CC6                       3071 00120$:
                                   3072 ;	tmk_core/protocol/ch555/usb_ak820.c:469: ACK_SUSPEND();
      006CC6 90 22 3D         [24] 3073 	mov	dptr,#0x223d
      006CC9 74 04            [12] 3074 	mov	a,#0x04
      006CCB F0               [24] 3075 	movx	@dptr,a
      006CCC                       3076 00130$:
                                   3077 ;	tmk_core/protocol/ch555/usb_ak820.c:471: } while (USB_IF & (bUX_IF_BUS_RST | bUX_IF_D0_TRANS | bUX_IF_SUSPEND));
      006CCC 90 22 3D         [24] 3078 	mov	dptr,#0x223d
      006CCF E0               [24] 3079 	movx	a,@dptr
      006CD0 54 25            [12] 3080 	anl	a,#0x25
      006CD2 60 03            [24] 3081 	jz	00242$
      006CD4 02 6B E2         [24] 3082 	ljmp	00129$
      006CD7                       3083 00242$:
                                   3084 ;	tmk_core/protocol/ch555/usb_ak820.c:472: }
      006CD7 22               [24] 3085 	ret
                                   3086 ;------------------------------------------------------------
                                   3087 ;Allocation info for local variables in function 'USB_Device_Init'
                                   3088 ;------------------------------------------------------------
                                   3089 ;	tmk_core/protocol/ch555/usb_ak820.c:475: void USB_Device_Init(void) {
                                   3090 ;	-----------------------------------------
                                   3091 ;	 function USB_Device_Init
                                   3092 ;	-----------------------------------------
      006CD8                       3093 _USB_Device_Init:
                                   3094 ;	tmk_core/protocol/ch555/usb_ak820.c:476: IE_USB = 0;
                                   3095 ;	assignBit
      006CD8 C2 E9            [12] 3096 	clr	_IE_USB
                                   3097 ;	tmk_core/protocol/ch555/usb_ak820.c:477: USB_CTRL = 0;
      006CDA 90 22 3C         [24] 3098 	mov	dptr,#0x223c
      006CDD E4               [12] 3099 	clr	a
      006CDE F0               [24] 3100 	movx	@dptr,a
                                   3101 ;	tmk_core/protocol/ch555/usb_ak820.c:478: raw_state = RAW_IDLE;
      006CDF 90 07 E6         [24] 3102 	mov	dptr,#_raw_state
      006CE2 F0               [24] 3103 	movx	@dptr,a
                                   3104 ;	tmk_core/protocol/ch555/usb_ak820.c:479: endpoints_reset();
      006CE3 12 60 CA         [24] 3105 	lcall	_endpoints_reset
                                   3106 ;	tmk_core/protocol/ch555/usb_ak820.c:480: D0_ADDR = D0UsbConfig = USB_EnumStatus = USB_SleepStatus = 0;
      006CE6 90 07 E0         [24] 3107 	mov	dptr,#_USB_SleepStatus
      006CE9 E4               [12] 3108 	clr	a
      006CEA F0               [24] 3109 	movx	@dptr,a
      006CEB 90 07 DF         [24] 3110 	mov	dptr,#_USB_EnumStatus
      006CEE F0               [24] 3111 	movx	@dptr,a
      006CEF 90 07 DE         [24] 3112 	mov	dptr,#_D0UsbConfig
      006CF2 F0               [24] 3113 	movx	@dptr,a
      006CF3 90 22 07         [24] 3114 	mov	dptr,#0x2207
      006CF6 F0               [24] 3115 	movx	@dptr,a
                                   3116 ;	tmk_core/protocol/ch555/usb_ak820.c:481: KB_USB_SetReport = KB_USB_UpStatus = MCU_Sleep_Operate = 0;
      006CF7 90 07 E1         [24] 3117 	mov	dptr,#_MCU_Sleep_Operate
      006CFA F0               [24] 3118 	movx	@dptr,a
      006CFB 90 07 E2         [24] 3119 	mov	dptr,#_KB_USB_UpStatus
      006CFE F0               [24] 3120 	movx	@dptr,a
      006CFF 90 07 E3         [24] 3121 	mov	dptr,#_KB_USB_SetReport
      006D02 F0               [24] 3122 	movx	@dptr,a
                                   3123 ;	tmk_core/protocol/ch555/usb_ak820.c:482: keyboard_protocol = 1;
      006D03 90 0D FB         [24] 3124 	mov	dptr,#_keyboard_protocol
      006D06 04               [12] 3125 	inc	a
      006D07 F0               [24] 3126 	movx	@dptr,a
                                   3127 ;	tmk_core/protocol/ch555/usb_ak820.c:483: keyboard_idle = 0;
      006D08 90 06 B6         [24] 3128 	mov	dptr,#_keyboard_idle
      006D0B E4               [12] 3129 	clr	a
      006D0C F0               [24] 3130 	movx	@dptr,a
                                   3131 ;	tmk_core/protocol/ch555/usb_ak820.c:484: keyboard_reset = 0;
      006D0D 90 08 08         [24] 3132 	mov	dptr,#_keyboard_reset
      006D10 F0               [24] 3133 	movx	@dptr,a
                                   3134 ;	tmk_core/protocol/ch555/usb_ak820.c:485: control_phase = CTRL_IDLE;
      006D11 90 08 37         [24] 3135 	mov	dptr,#_control_phase
      006D14 F0               [24] 3136 	movx	@dptr,a
                                   3137 ;	tmk_core/protocol/ch555/usb_ak820.c:486: D0SetupReqCode = 0xff;
      006D15 90 07 D8         [24] 3138 	mov	dptr,#_D0SetupReqCode
      006D18 14               [12] 3139 	dec	a
      006D19 F0               [24] 3140 	movx	@dptr,a
                                   3141 ;	tmk_core/protocol/ch555/usb_ak820.c:487: D0SetupLen = 0;
      006D1A 90 07 D9         [24] 3142 	mov	dptr,#_D0SetupLen
      006D1D E4               [12] 3143 	clr	a
      006D1E F0               [24] 3144 	movx	@dptr,a
      006D1F A3               [24] 3145 	inc	dptr
      006D20 F0               [24] 3146 	movx	@dptr,a
                                   3147 ;	tmk_core/protocol/ch555/usb_ak820.c:488: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      006D21 90 22 00         [24] 3148 	mov	dptr,#0x2200
      006D24 74 02            [12] 3149 	mov	a,#0x02
      006D26 F0               [24] 3150 	movx	@dptr,a
                                   3151 ;	tmk_core/protocol/ch555/usb_ak820.c:489: HB_ADDR = 0x7f;
      006D27 90 22 37         [24] 3152 	mov	dptr,#0x2237
      006D2A 74 7F            [12] 3153 	mov	a,#0x7f
      006D2C F0               [24] 3154 	movx	@dptr,a
                                   3155 ;	tmk_core/protocol/ch555/usb_ak820.c:490: ACK_ALL();
      006D2D 90 22 3D         [24] 3156 	mov	dptr,#0x223d
      006D30 74 FF            [12] 3157 	mov	a,#0xff
      006D32 F0               [24] 3158 	movx	@dptr,a
                                   3159 ;	tmk_core/protocol/ch555/usb_ak820.c:491: USB_IE = bUX_IE_SUSPEND | bUX_IE_TRANSFER | bUX_IE_BUS_RST;
      006D33 90 22 3B         [24] 3160 	mov	dptr,#0x223b
      006D36 74 07            [12] 3161 	mov	a,#0x07
      006D38 F0               [24] 3162 	movx	@dptr,a
                                   3163 ;	tmk_core/protocol/ch555/usb_ak820.c:492: USB_CTRL = bUX_DP_PU_EN;
      006D39 A3               [24] 3164 	inc	dptr
      006D3A 74 80            [12] 3165 	mov	a,#0x80
      006D3C F0               [24] 3166 	movx	@dptr,a
                                   3167 ;	tmk_core/protocol/ch555/usb_ak820.c:493: IE_USB = 1;
                                   3168 ;	assignBit
      006D3D D2 E9            [12] 3169 	setb	_IE_USB
                                   3170 ;	tmk_core/protocol/ch555/usb_ak820.c:494: }
      006D3F 22               [24] 3171 	ret
                                   3172 ;------------------------------------------------------------
                                   3173 ;Allocation info for local variables in function 'USB_WakeUp_PC'
                                   3174 ;------------------------------------------------------------
                                   3175 ;saved         Allocated with name '_USB_WakeUp_PC_saved_10000_421'
                                   3176 ;i             Allocated with name '_USB_WakeUp_PC_i_30000_424'
                                   3177 ;------------------------------------------------------------
                                   3178 ;	tmk_core/protocol/ch555/usb_ak820.c:496: void USB_WakeUp_PC(void) {
                                   3179 ;	-----------------------------------------
                                   3180 ;	 function USB_WakeUp_PC
                                   3181 ;	-----------------------------------------
      006D40                       3182 _USB_WakeUp_PC:
                                   3183 ;	tmk_core/protocol/ch555/usb_ak820.c:498: if (USB_SleepStatus != 3) return;
      006D40 90 07 E0         [24] 3184 	mov	dptr,#_USB_SleepStatus
      006D43 E0               [24] 3185 	movx	a,@dptr
      006D44 FF               [12] 3186 	mov	r7,a
      006D45 BF 03 22         [24] 3187 	cjne	r7,#0x03,00110$
                                   3188 ;	tmk_core/protocol/ch555/usb_ak820.c:499: saved = USB_CTRL;
      006D48 90 22 3C         [24] 3189 	mov	dptr,#0x223c
      006D4B E0               [24] 3190 	movx	a,@dptr
      006D4C FF               [12] 3191 	mov	r7,a
                                   3192 ;	tmk_core/protocol/ch555/usb_ak820.c:500: USB_CTRL ^= bUX_DP_PU_EN | bUX_DM_PU_EN;
      006D4D E0               [24] 3193 	movx	a,@dptr
      006D4E FE               [12] 3194 	mov	r6,a
      006D4F 63 06 C0         [24] 3195 	xrl	ar6,#0xc0
      006D52 90 22 3C         [24] 3196 	mov	dptr,#0x223c
      006D55 EE               [12] 3197 	mov	a,r6
      006D56 F0               [24] 3198 	movx	@dptr,a
                                   3199 ;	tmk_core/protocol/ch555/usb_ak820.c:501: wait_ms(10);
      006D57 7E 0A            [12] 3200 	mov	r6,#0x0a
      006D59                       3201 00108$:
      006D59 EE               [12] 3202 	mov	a,r6
      006D5A 60 09            [24] 3203 	jz	00105$
      006D5C 90 00 01         [24] 3204 	mov	dptr,#0x0001
      006D5F 12 5F 11         [24] 3205 	lcall	_mDelaymS
      006D62 1E               [12] 3206 	dec	r6
      006D63 80 F4            [24] 3207 	sjmp	00108$
      006D65                       3208 00105$:
                                   3209 ;	tmk_core/protocol/ch555/usb_ak820.c:502: USB_CTRL = saved;
      006D65 90 22 3C         [24] 3210 	mov	dptr,#0x223c
      006D68 EF               [12] 3211 	mov	a,r7
      006D69 F0               [24] 3212 	movx	@dptr,a
      006D6A                       3213 00110$:
                                   3214 ;	tmk_core/protocol/ch555/usb_ak820.c:503: }
      006D6A 22               [24] 3215 	ret
                                   3216 ;------------------------------------------------------------
                                   3217 ;Allocation info for local variables in function 'ak820_usb_send'
                                   3218 ;------------------------------------------------------------
                                   3219 ;sloc0         Allocated with name '_ak820_usb_send_sloc0_1_0'
                                   3220 ;sloc1         Allocated with name '_ak820_usb_send_sloc1_1_0'
                                   3221 ;report        Allocated with name '_ak820_usb_send_PARM_2'
                                   3222 ;length        Allocated with name '_ak820_usb_send_PARM_3'
                                   3223 ;endpoint      Allocated with name '_ak820_usb_send_endpoint_10000_426'
                                   3224 ;saved_ea      Allocated with name '_ak820_usb_send_saved_ea_10000_427'
                                   3225 ;i             Allocated with name '_ak820_usb_send_i_10000_427'
                                   3226 ;timeout       Allocated with name '_ak820_usb_send_timeout_10000_427'
                                   3227 ;offset        Allocated with name '_ak820_usb_send_offset_10000_427'
                                   3228 ;report_id     Allocated with name '_ak820_usb_send_report_id_10000_427'
                                   3229 ;i             Allocated with name '_ak820_usb_send_i_30000_439'
                                   3230 ;------------------------------------------------------------
                                   3231 ;	tmk_core/protocol/ch555/usb_ak820.c:505: bool ak820_usb_send(uint8_t endpoint, const uint8_t __xdata *report, uint8_t length) {
                                   3232 ;	-----------------------------------------
                                   3233 ;	 function ak820_usb_send
                                   3234 ;	-----------------------------------------
      006D6B                       3235 _ak820_usb_send:
      006D6B E5 82            [12] 3236 	mov	a,dpl
      006D6D 90 08 47         [24] 3237 	mov	dptr,#_ak820_usb_send_endpoint_10000_426
      006D70 F0               [24] 3238 	movx	@dptr,a
                                   3239 ;	tmk_core/protocol/ch555/usb_ak820.c:509: uint8_t offset = SNAPSHOT_SIZE;
      006D71 90 08 48         [24] 3240 	mov	dptr,#_ak820_usb_send_offset_10000_427
      006D74 74 2E            [12] 3241 	mov	a,#0x2e
      006D76 F0               [24] 3242 	movx	@dptr,a
                                   3243 ;	tmk_core/protocol/ch555/usb_ak820.c:511: if (endpoint < 1 || endpoint > 3 || length > 64 || !USB_EnumStatus) return false;
      006D77 90 08 47         [24] 3244 	mov	dptr,#_ak820_usb_send_endpoint_10000_426
      006D7A E0               [24] 3245 	movx	a,@dptr
      006D7B FF               [12] 3246 	mov	r7,a
      006D7C BF 01 00         [24] 3247 	cjne	r7,#0x01,00306$
      006D7F                       3248 00306$:
      006D7F 40 14            [24] 3249 	jc	00101$
      006D81 EF               [12] 3250 	mov	a,r7
      006D82 24 FC            [12] 3251 	add	a,#0xff - 0x03
      006D84 40 0F            [24] 3252 	jc	00101$
                                   3253 ;	free result
      006D86 90 08 46         [24] 3254 	mov	dptr,#_ak820_usb_send_PARM_3
      006D89 E0               [24] 3255 	movx	a,@dptr
      006D8A FE               [12] 3256 	mov  r6,a
      006D8B 24 BF            [12] 3257 	add	a,#0xff - 0x40
      006D8D 40 06            [24] 3258 	jc	00101$
                                   3259 ;	free result
      006D8F 90 07 DF         [24] 3260 	mov	dptr,#_USB_EnumStatus
      006D92 E0               [24] 3261 	movx	a,@dptr
      006D93 70 04            [24] 3262 	jnz	00102$
      006D95                       3263 00101$:
      006D95 75 82 00         [24] 3264 	mov	dpl, #0x00
      006D98 22               [24] 3265 	ret
      006D99                       3266 00102$:
                                   3267 ;	tmk_core/protocol/ch555/usb_ak820.c:512: if (endpoint == KEYBOARD_IN_EPNUM) {
      006D99 BF 01 10         [24] 3268 	cjne	r7,#0x01,00118$
                                   3269 ;	tmk_core/protocol/ch555/usb_ak820.c:513: if (length != KEYBOARD_EPSIZE) return false;
      006D9C BE 08 02         [24] 3270 	cjne	r6,#0x08,00313$
      006D9F 80 04            [24] 3271 	sjmp	00107$
      006DA1                       3272 00313$:
      006DA1 75 82 00         [24] 3273 	mov	dpl, #0x00
      006DA4 22               [24] 3274 	ret
      006DA5                       3275 00107$:
                                   3276 ;	tmk_core/protocol/ch555/usb_ak820.c:514: offset = SNAPSHOT_KEYBOARD;
      006DA5 90 08 48         [24] 3277 	mov	dptr,#_ak820_usb_send_offset_10000_427
      006DA8 E4               [12] 3278 	clr	a
      006DA9 F0               [24] 3279 	movx	@dptr,a
      006DAA 80 3C            [24] 3280 	sjmp	00119$
      006DAC                       3281 00118$:
                                   3282 ;	tmk_core/protocol/ch555/usb_ak820.c:515: } else if (endpoint == SHARED_IN_EPNUM) {
      006DAC BF 02 30         [24] 3283 	cjne	r7,#0x02,00115$
                                   3284 ;	tmk_core/protocol/ch555/usb_ak820.c:516: report_id = report[0];
      006DAF 90 08 44         [24] 3285 	mov	dptr,#_ak820_usb_send_PARM_2
      006DB2 E0               [24] 3286 	movx	a,@dptr
      006DB3 FD               [12] 3287 	mov	r5,a
      006DB4 A3               [24] 3288 	inc	dptr
      006DB5 E0               [24] 3289 	movx	a,@dptr
      006DB6 FF               [12] 3290 	mov	r7,a
      006DB7 8D 82            [24] 3291 	mov	dpl,r5
      006DB9 8F 83            [24] 3292 	mov	dph,r7
      006DBB E0               [24] 3293 	movx	a,@dptr
      006DBC FF               [12] 3294 	mov	r7,a
                                   3295 ;	tmk_core/protocol/ch555/usb_ak820.c:517: if (report_id >= sizeof(shared_lengths) || !shared_lengths[report_id] || length != shared_lengths[report_id]) return false;
      006DBD BF 07 00         [24] 3296 	cjne	r7,#0x07,00316$
      006DC0                       3297 00316$:
      006DC0 50 0E            [24] 3298 	jnc	00108$
      006DC2 EF               [12] 3299 	mov	a,r7
      006DC3 90 BF F5         [24] 3300 	mov	dptr,#_shared_lengths
      006DC6 93               [24] 3301 	movc	a,@a+dptr
      006DC7 FD               [12] 3302 	mov	r5,a
      006DC8 60 06            [24] 3303 	jz	00108$
      006DCA EE               [12] 3304 	mov	a,r6
      006DCB B5 05 02         [24] 3305 	cjne	a,ar5,00319$
      006DCE 80 04            [24] 3306 	sjmp	00109$
      006DD0                       3307 00319$:
      006DD0                       3308 00108$:
      006DD0 75 82 00         [24] 3309 	mov	dpl, #0x00
      006DD3 22               [24] 3310 	ret
      006DD4                       3311 00109$:
                                   3312 ;	tmk_core/protocol/ch555/usb_ak820.c:518: offset = shared_offsets[report_id];
      006DD4 EF               [12] 3313 	mov	a,r7
      006DD5 90 BF EE         [24] 3314 	mov	dptr,#_shared_offsets
      006DD8 93               [24] 3315 	movc	a,@a+dptr
      006DD9 90 08 48         [24] 3316 	mov	dptr,#_ak820_usb_send_offset_10000_427
      006DDC F0               [24] 3317 	movx	@dptr,a
      006DDD 80 09            [24] 3318 	sjmp	00119$
      006DDF                       3319 00115$:
                                   3320 ;	tmk_core/protocol/ch555/usb_ak820.c:519: } else if (length != RAW_EPSIZE) return false;
      006DDF BE 20 02         [24] 3321 	cjne	r6,#0x20,00320$
      006DE2 80 04            [24] 3322 	sjmp	00119$
      006DE4                       3323 00320$:
      006DE4 75 82 00         [24] 3324 	mov	dpl, #0x00
      006DE7 22               [24] 3325 	ret
      006DE8                       3326 00119$:
                                   3327 ;	tmk_core/protocol/ch555/usb_ak820.c:520: if (USB_SleepStatus & 2) { USB_WakeUp_PC(); return false; }
      006DE8 90 07 E0         [24] 3328 	mov	dptr,#_USB_SleepStatus
      006DEB E0               [24] 3329 	movx	a,@dptr
      006DEC 30 E1 07         [24] 3330 	jnb	acc.1,00184$
      006DEF 12 6D 40         [24] 3331 	lcall	_USB_WakeUp_PC
      006DF2 75 82 00         [24] 3332 	mov	dpl, #0x00
      006DF5 22               [24] 3333 	ret
                                   3334 ;	tmk_core/protocol/ch555/usb_ak820.c:521: while ((EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_ACK && timeout--) wait_us(40);
      006DF6                       3335 00184$:
      006DF6 7F FA            [12] 3336 	mov	r7,#0xfa
      006DF8                       3337 00127$:
      006DF8 90 08 47         [24] 3338 	mov	dptr,#_ak820_usb_send_endpoint_10000_426
      006DFB E0               [24] 3339 	movx	a,@dptr
      006DFC FC               [12] 3340 	mov	r4,a
      006DFD 7D 00            [12] 3341 	mov	r5,#0x00
      006DFF 8C 02            [24] 3342 	mov	ar2,r4
      006E01 74 22            [12] 3343 	mov	a,#0x22
      006E03 2D               [12] 3344 	add	a, r5
      006E04 FB               [12] 3345 	mov	r3,a
      006E05 8A 82            [24] 3346 	mov	dpl,r2
      006E07 8B 83            [24] 3347 	mov	dph,r3
      006E09 E0               [24] 3348 	movx	a,@dptr
      006E0A 54 03            [12] 3349 	anl	a,#0x03
      006E0C 70 14            [24] 3350 	jnz	00129$
      006E0E 8F 03            [24] 3351 	mov	ar3,r7
      006E10 1F               [12] 3352 	dec	r7
      006E11 EB               [12] 3353 	mov	a,r3
      006E12 60 0E            [24] 3354 	jz	00129$
      006E14 7B 28            [12] 3355 	mov	r3,#0x28
      006E16                       3356 00141$:
      006E16 EB               [12] 3357 	mov	a,r3
      006E17 60 DF            [24] 3358 	jz	00127$
      006E19 90 00 01         [24] 3359 	mov	dptr,#0x0001
      006E1C 12 5E CD         [24] 3360 	lcall	_mDelayuS
      006E1F 1B               [12] 3361 	dec	r3
      006E20 80 F4            [24] 3362 	sjmp	00141$
      006E22                       3363 00129$:
                                   3364 ;	tmk_core/protocol/ch555/usb_ak820.c:522: saved_ea = EA;
      006E22 A2 AF            [12] 3365 	mov	c,_EA
      006E24 E4               [12] 3366 	clr	a
      006E25 33               [12] 3367 	rlc	a
      006E26 FF               [12] 3368 	mov	r7,a
                                   3369 ;	tmk_core/protocol/ch555/usb_ak820.c:523: EA = 0;
                                   3370 ;	assignBit
      006E27 C2 AF            [12] 3371 	clr	_EA
                                   3372 ;	tmk_core/protocol/ch555/usb_ak820.c:524: if (!USB_EnumStatus || (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) != UEP_X_RES_NAK ||
      006E29 90 07 DF         [24] 3373 	mov	dptr,#_USB_EnumStatus
      006E2C E0               [24] 3374 	movx	a,@dptr
      006E2D 60 25            [24] 3375 	jz	00130$
      006E2F 90 08 47         [24] 3376 	mov	dptr,#_ak820_usb_send_endpoint_10000_426
      006E32 E0               [24] 3377 	movx	a,@dptr
      006E33 FB               [12] 3378 	mov	r3,a
      006E34 F9               [12] 3379 	mov	r1,a
      006E35 7A 00            [12] 3380 	mov	r2,#0x00
      006E37 74 22            [12] 3381 	mov	a,#0x22
      006E39 2A               [12] 3382 	add	a, r2
      006E3A FA               [12] 3383 	mov	r2,a
      006E3B 89 82            [24] 3384 	mov	dpl,r1
      006E3D 8A 83            [24] 3385 	mov	dph,r2
      006E3F E0               [24] 3386 	movx	a,@dptr
      006E40 FA               [12] 3387 	mov	r2,a
      006E41 53 02 03         [24] 3388 	anl	ar2,#0x03
      006E44 BA 02 0D         [24] 3389 	cjne	r2,#0x02,00130$
                                   3390 ;	tmk_core/protocol/ch555/usb_ak820.c:525: (endpoint == RAW_IN_EPNUM && raw_state != RAW_WORK)) { EA = saved_ea; return false; }
      006E47 BB 03 13         [24] 3391 	cjne	r3,#0x03,00192$
      006E4A 90 07 E6         [24] 3392 	mov	dptr,#_raw_state
      006E4D E0               [24] 3393 	movx	a,@dptr
      006E4E FB               [12] 3394 	mov	r3,a
      006E4F BB 03 02         [24] 3395 	cjne	r3,#0x03,00331$
      006E52 80 09            [24] 3396 	sjmp	00192$
      006E54                       3397 00331$:
      006E54                       3398 00130$:
                                   3399 ;	assignBit
      006E54 EF               [12] 3400 	mov	a,r7
      006E55 24 FF            [12] 3401 	add	a,#0xff
      006E57 92 AF            [24] 3402 	mov	_EA,c
      006E59 75 82 00         [24] 3403 	mov	dpl, #0x00
      006E5C 22               [24] 3404 	ret
                                   3405 ;	tmk_core/protocol/ch555/usb_ak820.c:526: for (i = 0; i < length; ++i) {
      006E5D                       3406 00192$:
      006E5D 7B 00            [12] 3407 	mov	r3,#0x00
      006E5F                       3408 00144$:
      006E5F C3               [12] 3409 	clr	c
      006E60 EB               [12] 3410 	mov	a,r3
      006E61 9E               [12] 3411 	subb	a,r6
      006E62 50 67            [24] 3412 	jnc	00137$
                                   3413 ;	tmk_core/protocol/ch555/usb_ak820.c:527: pUSB_BUF_DEV0[((uint16_t)endpoint << 6) + i] = report[i];
      006E64 C0 07            [24] 3414 	push	ar7
      006E66 90 08 47         [24] 3415 	mov	dptr,#_ak820_usb_send_endpoint_10000_426
      006E69 E0               [24] 3416 	movx	a,@dptr
      006E6A F9               [12] 3417 	mov	r1,a
      006E6B E4               [12] 3418 	clr	a
      006E6C C3               [12] 3419 	clr	c
      006E6D C9               [12] 3420 	xch	a,r1
      006E6E 13               [12] 3421 	rrc	a
      006E6F C9               [12] 3422 	xch	a,r1
      006E70 13               [12] 3423 	rrc	a
      006E71 A2 E0            [12] 3424 	mov	c,acc.0
      006E73 C9               [12] 3425 	xch	a,r1
      006E74 13               [12] 3426 	rrc	a
      006E75 C9               [12] 3427 	xch	a,r1
      006E76 13               [12] 3428 	rrc	a
      006E77 C9               [12] 3429 	xch	a,r1
      006E78 FA               [12] 3430 	mov	r2,a
      006E79 8B 00            [24] 3431 	mov	ar0,r3
      006E7B 7F 00            [12] 3432 	mov	r7,#0x00
      006E7D E8               [12] 3433 	mov	a,r0
      006E7E 29               [12] 3434 	add	a, r1
      006E7F F9               [12] 3435 	mov	r1,a
      006E80 EF               [12] 3436 	mov	a,r7
      006E81 3A               [12] 3437 	addc	a, r2
      006E82 24 10            [12] 3438 	add	a,#0x10
      006E84 FA               [12] 3439 	mov	r2,a
      006E85 90 08 44         [24] 3440 	mov	dptr,#_ak820_usb_send_PARM_2
      006E88 E0               [24] 3441 	movx	a,@dptr
      006E89 F8               [12] 3442 	mov	r0,a
      006E8A A3               [24] 3443 	inc	dptr
      006E8B E0               [24] 3444 	movx	a,@dptr
      006E8C FF               [12] 3445 	mov	r7,a
      006E8D EB               [12] 3446 	mov	a,r3
      006E8E 28               [12] 3447 	add	a, r0
      006E8F F5 1B            [12] 3448 	mov	_ak820_usb_send_sloc0_1_0,a
      006E91 E4               [12] 3449 	clr	a
      006E92 3F               [12] 3450 	addc	a, r7
      006E93 F5 1C            [12] 3451 	mov	(_ak820_usb_send_sloc0_1_0 + 1),a
      006E95 85 1B 82         [24] 3452 	mov	dpl,_ak820_usb_send_sloc0_1_0
      006E98 85 1C 83         [24] 3453 	mov	dph,(_ak820_usb_send_sloc0_1_0 + 1)
      006E9B E0               [24] 3454 	movx	a,@dptr
      006E9C 89 82            [24] 3455 	mov	dpl,r1
      006E9E 8A 83            [24] 3456 	mov	dph,r2
      006EA0 F0               [24] 3457 	movx	@dptr,a
                                   3458 ;	tmk_core/protocol/ch555/usb_ak820.c:528: if (offset != SNAPSHOT_SIZE) input_snapshot[offset + i] = report[i];
      006EA1 90 08 48         [24] 3459 	mov	dptr,#_ak820_usb_send_offset_10000_427
      006EA4 E0               [24] 3460 	movx	a,@dptr
      006EA5 F5 1D            [12] 3461 	mov	_ak820_usb_send_sloc1_1_0,a
      006EA7 74 2E            [12] 3462 	mov	a,#0x2e
      006EA9 B5 1D 04         [24] 3463 	cjne	a,_ak820_usb_send_sloc1_1_0,00333$
      006EAC D0 07            [24] 3464 	pop	ar7
      006EAE 80 18            [24] 3465 	sjmp	00145$
      006EB0                       3466 00333$:
      006EB0 D0 07            [24] 3467 	pop	ar7
      006EB2 EB               [12] 3468 	mov	a,r3
      006EB3 25 1D            [12] 3469 	add	a, _ak820_usb_send_sloc1_1_0
      006EB5 24 09            [12] 3470 	add	a, #_input_snapshot
      006EB7 F9               [12] 3471 	mov	r1,a
      006EB8 E4               [12] 3472 	clr	a
      006EB9 34 08            [12] 3473 	addc	a,#(_input_snapshot >> 8)
      006EBB FA               [12] 3474 	mov	r2,a
      006EBC 85 1B 82         [24] 3475 	mov	dpl,_ak820_usb_send_sloc0_1_0
      006EBF 85 1C 83         [24] 3476 	mov	dph,(_ak820_usb_send_sloc0_1_0 + 1)
      006EC2 E0               [24] 3477 	movx	a,@dptr
      006EC3 89 82            [24] 3478 	mov	dpl,r1
      006EC5 8A 83            [24] 3479 	mov	dph,r2
      006EC7 F0               [24] 3480 	movx	@dptr,a
      006EC8                       3481 00145$:
                                   3482 ;	tmk_core/protocol/ch555/usb_ak820.c:526: for (i = 0; i < length; ++i) {
      006EC8 0B               [12] 3483 	inc	r3
      006EC9 80 94            [24] 3484 	sjmp	00144$
      006ECB                       3485 00137$:
                                   3486 ;	tmk_core/protocol/ch555/usb_ak820.c:530: EP_LENGTH(endpoint) = length;
      006ECB 90 08 47         [24] 3487 	mov	dptr,#_ak820_usb_send_endpoint_10000_426
      006ECE E0               [24] 3488 	movx	a,@dptr
      006ECF FB               [12] 3489 	mov	r3,a
      006ED0 F9               [12] 3490 	mov	r1,a
      006ED1 7A 00            [12] 3491 	mov	r2,#0x00
      006ED3 74 08            [12] 3492 	mov	a,#0x08
      006ED5 29               [12] 3493 	add	a, r1
      006ED6 F9               [12] 3494 	mov	r1,a
      006ED7 74 22            [12] 3495 	mov	a,#0x22
      006ED9 3A               [12] 3496 	addc	a, r2
      006EDA FA               [12] 3497 	mov	r2,a
      006EDB 89 82            [24] 3498 	mov	dpl,r1
      006EDD 8A 83            [24] 3499 	mov	dph,r2
      006EDF EE               [12] 3500 	mov	a,r6
      006EE0 F0               [24] 3501 	movx	@dptr,a
                                   3502 ;	tmk_core/protocol/ch555/usb_ak820.c:531: if (endpoint == RAW_IN_EPNUM) raw_state = RAW_TX_ACTIVE;
      006EE1 BB 03 06         [24] 3503 	cjne	r3,#0x03,00139$
      006EE4 90 07 E6         [24] 3504 	mov	dptr,#_raw_state
      006EE7 74 04            [12] 3505 	mov	a,#0x04
      006EE9 F0               [24] 3506 	movx	@dptr,a
      006EEA                       3507 00139$:
                                   3508 ;	tmk_core/protocol/ch555/usb_ak820.c:532: EP_RESPONSE(endpoint) = (EP_RESPONSE(endpoint) & ~MASK_UEP_X_RES) | UEP_X_RES_ACK;
      006EEA 74 22            [12] 3509 	mov	a,#0x22
      006EEC 2D               [12] 3510 	add	a, r5
      006EED FD               [12] 3511 	mov	r5,a
      006EEE 8C 82            [24] 3512 	mov	dpl,r4
      006EF0 8D 83            [24] 3513 	mov	dph,r5
      006EF2 E0               [24] 3514 	movx	a,@dptr
      006EF3 FE               [12] 3515 	mov	r6,a
      006EF4 53 06 FC         [24] 3516 	anl	ar6,#0xfc
      006EF7 8C 82            [24] 3517 	mov	dpl,r4
      006EF9 8D 83            [24] 3518 	mov	dph,r5
      006EFB EE               [12] 3519 	mov	a,r6
      006EFC F0               [24] 3520 	movx	@dptr,a
                                   3521 ;	tmk_core/protocol/ch555/usb_ak820.c:533: EA = saved_ea;
                                   3522 ;	assignBit
      006EFD EF               [12] 3523 	mov	a,r7
      006EFE 24 FF            [12] 3524 	add	a,#0xff
      006F00 92 AF            [24] 3525 	mov	_EA,c
                                   3526 ;	tmk_core/protocol/ch555/usb_ak820.c:534: return true;
      006F02 75 82 01         [24] 3527 	mov	dpl, #0x01
                                   3528 ;	tmk_core/protocol/ch555/usb_ak820.c:535: }
      006F05 22               [24] 3529 	ret
                                   3530 ;------------------------------------------------------------
                                   3531 ;Allocation info for local variables in function 'ak820_usb_try_send'
                                   3532 ;------------------------------------------------------------
                                   3533 ;report        Allocated with name '_ak820_usb_try_send_PARM_2'
                                   3534 ;length        Allocated with name '_ak820_usb_try_send_PARM_3'
                                   3535 ;endpoint      Allocated with name '_ak820_usb_try_send_endpoint_10000_447'
                                   3536 ;saved_ea      Allocated with name '_ak820_usb_try_send_saved_ea_10000_448'
                                   3537 ;sent          Allocated with name '_ak820_usb_try_send_sent_10000_448'
                                   3538 ;------------------------------------------------------------
                                   3539 ;	tmk_core/protocol/ch555/usb_ak820.c:537: bool ak820_usb_try_send(uint8_t endpoint, const uint8_t __xdata *report, uint8_t length) {
                                   3540 ;	-----------------------------------------
                                   3541 ;	 function ak820_usb_try_send
                                   3542 ;	-----------------------------------------
      006F06                       3543 _ak820_usb_try_send:
      006F06 E5 82            [12] 3544 	mov	a,dpl
      006F08 90 08 4C         [24] 3545 	mov	dptr,#_ak820_usb_try_send_endpoint_10000_447
      006F0B F0               [24] 3546 	movx	@dptr,a
                                   3547 ;	tmk_core/protocol/ch555/usb_ak820.c:538: uint8_t saved_ea = EA;
                                   3548 ;	assignBit
      006F0C A2 AF            [12] 3549 	mov	c,_EA
      006F0E 92 1B            [24] 3550 	mov	_ak820_usb_try_send_sloc0_1_0,c
                                   3551 ;	tmk_core/protocol/ch555/usb_ak820.c:539: bool sent = false;
      006F10 90 08 4D         [24] 3552 	mov	dptr,#_ak820_usb_try_send_sent_10000_448
      006F13 E4               [12] 3553 	clr	a
      006F14 F0               [24] 3554 	movx	@dptr,a
                                   3555 ;	tmk_core/protocol/ch555/usb_ak820.c:540: EA = 0;
                                   3556 ;	assignBit
      006F15 C2 AF            [12] 3557 	clr	_EA
                                   3558 ;	tmk_core/protocol/ch555/usb_ak820.c:544: if (endpoint >= 1 && endpoint <= 2 && USB_EnumStatus &&
      006F17 90 08 4C         [24] 3559 	mov	dptr,#_ak820_usb_try_send_endpoint_10000_447
      006F1A E0               [24] 3560 	movx	a,@dptr
      006F1B FF               [12] 3561 	mov	r7,a
      006F1C BF 01 00         [24] 3562 	cjne	r7,#0x01,00152$
      006F1F                       3563 00152$:
      006F1F 40 4E            [24] 3564 	jc	00102$
      006F21 EF               [12] 3565 	mov	a,r7
      006F22 24 FD            [12] 3566 	add	a,#0xff - 0x02
      006F24 40 49            [24] 3567 	jc	00102$
                                   3568 ;	free result
      006F26 90 07 DF         [24] 3569 	mov	dptr,#_USB_EnumStatus
      006F29 E0               [24] 3570 	movx	a,@dptr
      006F2A 60 43            [24] 3571 	jz	00102$
                                   3572 ;	tmk_core/protocol/ch555/usb_ak820.c:545: !(USB_SleepStatus & 2) && !keyboard_reset &&
      006F2C 90 07 E0         [24] 3573 	mov	dptr,#_USB_SleepStatus
      006F2F E0               [24] 3574 	movx	a,@dptr
      006F30 20 E1 3C         [24] 3575 	jb	acc.1,00102$
      006F33 90 08 08         [24] 3576 	mov	dptr,#_keyboard_reset
      006F36 E0               [24] 3577 	movx	a,@dptr
                                   3578 ;	tmk_core/protocol/ch555/usb_ak820.c:546: (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_NAK) {
      006F37 70 36            [24] 3579 	jnz	00102$
      006F39 8F 06            [24] 3580 	mov	ar6,r7
      006F3B 24 22            [12] 3581 	add	a,#0x22
      006F3D FD               [12] 3582 	mov	r5,a
      006F3E 8E 82            [24] 3583 	mov	dpl,r6
      006F40 8D 83            [24] 3584 	mov	dph,r5
      006F42 E0               [24] 3585 	movx	a,@dptr
      006F43 FE               [12] 3586 	mov	r6,a
      006F44 53 06 03         [24] 3587 	anl	ar6,#0x03
      006F47 BE 02 25         [24] 3588 	cjne	r6,#0x02,00102$
                                   3589 ;	tmk_core/protocol/ch555/usb_ak820.c:547: sent = ak820_usb_send(endpoint, report, length);
      006F4A 90 08 49         [24] 3590 	mov	dptr,#_ak820_usb_try_send_PARM_2
      006F4D E0               [24] 3591 	movx	a,@dptr
      006F4E FD               [12] 3592 	mov	r5,a
      006F4F A3               [24] 3593 	inc	dptr
      006F50 E0               [24] 3594 	movx	a,@dptr
      006F51 FE               [12] 3595 	mov	r6,a
      006F52 90 08 4B         [24] 3596 	mov	dptr,#_ak820_usb_try_send_PARM_3
      006F55 E0               [24] 3597 	movx	a,@dptr
      006F56 FC               [12] 3598 	mov	r4,a
      006F57 90 08 44         [24] 3599 	mov	dptr,#_ak820_usb_send_PARM_2
      006F5A ED               [12] 3600 	mov	a,r5
      006F5B F0               [24] 3601 	movx	@dptr,a
      006F5C EE               [12] 3602 	mov	a,r6
      006F5D A3               [24] 3603 	inc	dptr
      006F5E F0               [24] 3604 	movx	@dptr,a
      006F5F 90 08 46         [24] 3605 	mov	dptr,#_ak820_usb_send_PARM_3
      006F62 EC               [12] 3606 	mov	a,r4
      006F63 F0               [24] 3607 	movx	@dptr,a
      006F64 8F 82            [24] 3608 	mov	dpl, r7
      006F66 12 6D 6B         [24] 3609 	lcall	_ak820_usb_send
      006F69 E5 82            [12] 3610 	mov	a, dpl
      006F6B 90 08 4D         [24] 3611 	mov	dptr,#_ak820_usb_try_send_sent_10000_448
      006F6E F0               [24] 3612 	movx	@dptr,a
      006F6F                       3613 00102$:
                                   3614 ;	tmk_core/protocol/ch555/usb_ak820.c:549: EA = saved_ea;
                                   3615 ;	assignBit
      006F6F A2 1B            [12] 3616 	mov	c,_ak820_usb_try_send_sloc0_1_0
      006F71 92 AF            [24] 3617 	mov	_EA,c
                                   3618 ;	tmk_core/protocol/ch555/usb_ak820.c:550: return sent;
      006F73 90 08 4D         [24] 3619 	mov	dptr,#_ak820_usb_try_send_sent_10000_448
      006F76 E0               [24] 3620 	movx	a,@dptr
                                   3621 ;	tmk_core/protocol/ch555/usb_ak820.c:551: }
      006F77 F5 82            [12] 3622 	mov	dpl,a
      006F79 22               [24] 3623 	ret
                                   3624 ;------------------------------------------------------------
                                   3625 ;Allocation info for local variables in function 'raw_request_is_nonpersistent'
                                   3626 ;------------------------------------------------------------
                                   3627 ;	tmk_core/protocol/ch555/usb_ak820.c:556: static bool raw_request_is_nonpersistent(void) {
                                   3628 ;	-----------------------------------------
                                   3629 ;	 function raw_request_is_nonpersistent
                                   3630 ;	-----------------------------------------
      006F7A                       3631 _raw_request_is_nonpersistent:
                                   3632 ;	tmk_core/protocol/ch555/usb_ak820.c:557: switch (raw_buffer[0]) {
      006F7A 90 07 E7         [24] 3633 	mov	dptr,#_raw_buffer
      006F7D E0               [24] 3634 	movx	a,@dptr
      006F7E FF               [12] 3635 	mov	r7,a
      006F7F BF 01 02         [24] 3636 	cjne	r7,#0x01,00302$
      006F82 80 35            [24] 3637 	sjmp	00108$
      006F84                       3638 00302$:
      006F84 BF 02 02         [24] 3639 	cjne	r7,#0x02,00303$
      006F87 80 34            [24] 3640 	sjmp	00109$
      006F89                       3641 00303$:
      006F89 BF 04 02         [24] 3642 	cjne	r7,#0x04,00304$
      006F8C 80 2B            [24] 3643 	sjmp	00108$
      006F8E                       3644 00304$:
      006F8E BF 08 02         [24] 3645 	cjne	r7,#0x08,00305$
      006F91 80 47            [24] 3646 	sjmp	00116$
      006F93                       3647 00305$:
      006F93 BF 0B 02         [24] 3648 	cjne	r7,#0x0b,00306$
      006F96 80 21            [24] 3649 	sjmp	00108$
      006F98                       3650 00306$:
      006F98 BF 0C 02         [24] 3651 	cjne	r7,#0x0c,00307$
      006F9B 80 1C            [24] 3652 	sjmp	00108$
      006F9D                       3653 00307$:
      006F9D BF 0D 02         [24] 3654 	cjne	r7,#0x0d,00308$
      006FA0 80 17            [24] 3655 	sjmp	00108$
      006FA2                       3656 00308$:
      006FA2 BF 0E 02         [24] 3657 	cjne	r7,#0x0e,00309$
      006FA5 80 12            [24] 3658 	sjmp	00108$
      006FA7                       3659 00309$:
      006FA7 BF 11 02         [24] 3660 	cjne	r7,#0x11,00310$
      006FAA 80 0D            [24] 3661 	sjmp	00108$
      006FAC                       3662 00310$:
      006FAC BF 12 02         [24] 3663 	cjne	r7,#0x12,00311$
      006FAF 80 08            [24] 3664 	sjmp	00108$
      006FB1                       3665 00311$:
      006FB1 BF FE 02         [24] 3666 	cjne	r7,#0xfe,00312$
      006FB4 80 46            [24] 3667 	sjmp	00124$
      006FB6                       3668 00312$:
      006FB6 02 70 51         [24] 3669 	ljmp	00144$
                                   3670 ;	tmk_core/protocol/ch555/usb_ak820.c:565: case id_bootloader_jump:
      006FB9                       3671 00108$:
                                   3672 ;	tmk_core/protocol/ch555/usb_ak820.c:566: return true;
      006FB9 75 82 01         [24] 3673 	mov	dpl, #0x01
      006FBC 22               [24] 3674 	ret
                                   3675 ;	tmk_core/protocol/ch555/usb_ak820.c:567: case id_get_keyboard_value:
      006FBD                       3676 00109$:
                                   3677 ;	tmk_core/protocol/ch555/usb_ak820.c:568: switch (raw_buffer[1]) {
      006FBD 12 73 87         [24] 3678 	lcall	_ak820_outline_0160
      006FC0 BF 01 02         [24] 3679 	cjne	r7,#0x01,00313$
      006FC3 80 0D            [24] 3680 	sjmp	00113$
      006FC5                       3681 00313$:
      006FC5 BF 02 02         [24] 3682 	cjne	r7,#0x02,00314$
      006FC8 80 08            [24] 3683 	sjmp	00113$
      006FCA                       3684 00314$:
      006FCA BF 03 02         [24] 3685 	cjne	r7,#0x03,00315$
      006FCD 80 03            [24] 3686 	sjmp	00113$
      006FCF                       3687 00315$:
      006FCF BF 04 04         [24] 3688 	cjne	r7,#0x04,00114$
                                   3689 ;	tmk_core/protocol/ch555/usb_ak820.c:572: case id_firmware_version:
      006FD2                       3690 00113$:
                                   3691 ;	tmk_core/protocol/ch555/usb_ak820.c:573: return true;
      006FD2 75 82 01         [24] 3692 	mov	dpl, #0x01
      006FD5 22               [24] 3693 	ret
                                   3694 ;	tmk_core/protocol/ch555/usb_ak820.c:574: default: return false;
      006FD6                       3695 00114$:
      006FD6 75 82 00         [24] 3696 	mov	dpl, #0x00
      006FD9 22               [24] 3697 	ret
                                   3698 ;	tmk_core/protocol/ch555/usb_ak820.c:576: case id_lighting_get_value:
      006FDA                       3699 00116$:
                                   3700 ;	tmk_core/protocol/ch555/usb_ak820.c:577: switch (raw_buffer[1]) {
      006FDA 12 73 87         [24] 3701 	lcall	_ak820_outline_0160
      006FDD BF 40 02         [24] 3702 	cjne	r7,#0x40,00318$
      006FE0 80 12            [24] 3703 	sjmp	00121$
      006FE2                       3704 00318$:
      006FE2 BF 41 02         [24] 3705 	cjne	r7,#0x41,00319$
      006FE5 80 0D            [24] 3706 	sjmp	00121$
      006FE7                       3707 00319$:
      006FE7 BF 42 02         [24] 3708 	cjne	r7,#0x42,00320$
      006FEA 80 08            [24] 3709 	sjmp	00121$
      006FEC                       3710 00320$:
      006FEC BF 43 02         [24] 3711 	cjne	r7,#0x43,00321$
      006FEF 80 03            [24] 3712 	sjmp	00121$
      006FF1                       3713 00321$:
      006FF1 BF 44 04         [24] 3714 	cjne	r7,#0x44,00122$
                                   3715 ;	tmk_core/protocol/ch555/usb_ak820.c:582: case vialrgb_get_led_info:
      006FF4                       3716 00121$:
                                   3717 ;	tmk_core/protocol/ch555/usb_ak820.c:583: return true;
      006FF4 75 82 01         [24] 3718 	mov	dpl, #0x01
                                   3719 ;	tmk_core/protocol/ch555/usb_ak820.c:584: default: return false;
      006FF7 22               [24] 3720 	ret
      006FF8                       3721 00122$:
      006FF8 75 82 00         [24] 3722 	mov	dpl, #0x00
                                   3723 ;	tmk_core/protocol/ch555/usb_ak820.c:586: case id_vial_prefix:
      006FFB 22               [24] 3724 	ret
      006FFC                       3725 00124$:
                                   3726 ;	tmk_core/protocol/ch555/usb_ak820.c:587: switch (raw_buffer[1]) {
      006FFC 12 73 87         [24] 3727 	lcall	_ak820_outline_0160
      006FFF 24 F2            [12] 3728 	add	a,#0xff - 0x0d
      007001 40 4A            [24] 3729 	jc	00142$
                                   3730 ;	free result
      007003 EF               [12] 3731 	mov	a,r7
      007004 24 0A            [12] 3732 	add	a,#(00325$-3-.)
      007006 83               [24] 3733 	movc	a,@a+pc
      007007 F5 82            [12] 3734 	mov	dpl,a
      007009 EF               [12] 3735 	mov	a,r7
      00700A 24 12            [12] 3736 	add	a,#(00326$-3-.)
      00700C 83               [24] 3737 	movc	a,@a+pc
      00700D F5 83            [12] 3738 	mov	dph,a
      00700F E4               [12] 3739 	clr	a
      007010 73               [24] 3740 	jmp	@a+dptr
      007011                       3741 00325$:
      007011 2D                    3742 	.db	00134$
      007012 2D                    3743 	.db	00134$
      007013 2D                    3744 	.db	00134$
      007014 2D                    3745 	.db	00134$
      007015 4D                    3746 	.db	00142$
      007016 2D                    3747 	.db	00134$
      007017 2D                    3748 	.db	00134$
      007018 2D                    3749 	.db	00134$
      007019 2D                    3750 	.db	00134$
      00701A 2D                    3751 	.db	00134$
      00701B 2D                    3752 	.db	00134$
      00701C 4D                    3753 	.db	00142$
      00701D 4D                    3754 	.db	00142$
      00701E 31                    3755 	.db	00135$
      00701F                       3756 00326$:
      00701F 70                    3757 	.db	00134$>>8
      007020 70                    3758 	.db	00134$>>8
      007021 70                    3759 	.db	00134$>>8
      007022 70                    3760 	.db	00134$>>8
      007023 70                    3761 	.db	00142$>>8
      007024 70                    3762 	.db	00134$>>8
      007025 70                    3763 	.db	00134$>>8
      007026 70                    3764 	.db	00134$>>8
      007027 70                    3765 	.db	00134$>>8
      007028 70                    3766 	.db	00134$>>8
      007029 70                    3767 	.db	00134$>>8
      00702A 70                    3768 	.db	00142$>>8
      00702B 70                    3769 	.db	00142$>>8
      00702C 70                    3770 	.db	00135$>>8
                                   3771 ;	tmk_core/protocol/ch555/usb_ak820.c:597: case vial_qmk_settings_get:
      00702D                       3772 00134$:
                                   3773 ;	tmk_core/protocol/ch555/usb_ak820.c:598: return true;
      00702D 75 82 01         [24] 3774 	mov	dpl, #0x01
                                   3775 ;	tmk_core/protocol/ch555/usb_ak820.c:599: case vial_dynamic_entry_op:
      007030 22               [24] 3776 	ret
      007031                       3777 00135$:
                                   3778 ;	tmk_core/protocol/ch555/usb_ak820.c:600: switch (raw_buffer[2]) {
      007031 90 07 E9         [24] 3779 	mov	dptr,#(_raw_buffer + 0x0002)
      007034 E0               [24] 3780 	movx	a,@dptr
      007035 FF               [12] 3781 	mov	r7,a
      007036 60 0D            [24] 3782 	jz	00139$
      007038 BF 01 02         [24] 3783 	cjne	r7,#0x01,00328$
      00703B 80 08            [24] 3784 	sjmp	00139$
      00703D                       3785 00328$:
      00703D BF 03 02         [24] 3786 	cjne	r7,#0x03,00329$
      007040 80 03            [24] 3787 	sjmp	00139$
      007042                       3788 00329$:
      007042 BF 05 04         [24] 3789 	cjne	r7,#0x05,00140$
                                   3790 ;	tmk_core/protocol/ch555/usb_ak820.c:604: case dynamic_vial_key_override_get:
      007045                       3791 00139$:
                                   3792 ;	tmk_core/protocol/ch555/usb_ak820.c:605: return true;
      007045 75 82 01         [24] 3793 	mov	dpl, #0x01
                                   3794 ;	tmk_core/protocol/ch555/usb_ak820.c:606: default: return false;
      007048 22               [24] 3795 	ret
      007049                       3796 00140$:
      007049 75 82 00         [24] 3797 	mov	dpl, #0x00
                                   3798 ;	tmk_core/protocol/ch555/usb_ak820.c:608: default: return false;
      00704C 22               [24] 3799 	ret
      00704D                       3800 00142$:
      00704D 75 82 00         [24] 3801 	mov	dpl, #0x00
                                   3802 ;	tmk_core/protocol/ch555/usb_ak820.c:610: default: return false;
      007050 22               [24] 3803 	ret
      007051                       3804 00144$:
      007051 75 82 00         [24] 3805 	mov	dpl, #0x00
                                   3806 ;	tmk_core/protocol/ch555/usb_ak820.c:611: }
                                   3807 ;	tmk_core/protocol/ch555/usb_ak820.c:612: }
      007054 22               [24] 3808 	ret
                                   3809 ;------------------------------------------------------------
                                   3810 ;Allocation info for local variables in function 'ak820_usb_raw_send'
                                   3811 ;------------------------------------------------------------
                                   3812 ;length        Allocated with name '_ak820_usb_raw_send_PARM_2'
                                   3813 ;report        Allocated with name '_ak820_usb_raw_send_report_10000_463'
                                   3814 ;------------------------------------------------------------
                                   3815 ;	tmk_core/protocol/ch555/usb_ak820.c:614: void ak820_usb_raw_send(const uint8_t *report, uint8_t length) {
                                   3816 ;	-----------------------------------------
                                   3817 ;	 function ak820_usb_raw_send
                                   3818 ;	-----------------------------------------
      007055                       3819 _ak820_usb_raw_send:
      007055 12 48 A5         [24] 3820 	lcall	_ak820_outline_0037
      007058 90 08 4F         [24] 3821 	mov	dptr,#_ak820_usb_raw_send_report_10000_463
      00705B 12 37 DF         [24] 3822 	lcall	_ak820_outline_0016
                                   3823 ;	tmk_core/protocol/ch555/usb_ak820.c:615: if (length != RAW_EPSIZE) return;
      00705E 90 08 4E         [24] 3824 	mov	dptr,#_ak820_usb_raw_send_PARM_2
      007061 E0               [24] 3825 	movx	a,@dptr
      007062 FF               [12] 3826 	mov	r7,a
      007063 BF 20 2B         [24] 3827 	cjne	r7,#0x20,00106$
                                   3828 ;	tmk_core/protocol/ch555/usb_ak820.c:616: ak820_nvm_flush();
      007066 C0 07            [24] 3829 	push	ar7
      007068 12 43 BC         [24] 3830 	lcall	_ak820_nvm_flush
      00706B D0 07            [24] 3831 	pop	ar7
                                   3832 ;	tmk_core/protocol/ch555/usb_ak820.c:617: if (raw_reply_without_nvm || ak820_nvm_ok()) ak820_usb_send(RAW_IN_EPNUM, (const uint8_t __xdata *)report, length);
      00706D 90 08 07         [24] 3833 	mov	dptr,#_raw_reply_without_nvm
      007070 E0               [24] 3834 	movx	a,@dptr
      007071 70 07            [24] 3835 	jnz	00103$
      007073 12 43 AD         [24] 3836 	lcall	_ak820_nvm_ok
      007076 E5 82            [12] 3837 	mov	a, dpl
      007078 60 17            [24] 3838 	jz	00106$
      00707A                       3839 00103$:
      00707A 90 08 4F         [24] 3840 	mov	dptr,#_ak820_usb_raw_send_report_10000_463
      00707D 12 48 DC         [24] 3841 	lcall	_ak820_outline_0095
      007080 90 08 44         [24] 3842 	mov	dptr,#_ak820_usb_send_PARM_2
      007083 12 49 1F         [24] 3843 	lcall	_ak820_outline_0158
      007086 90 08 46         [24] 3844 	mov	dptr,#_ak820_usb_send_PARM_3
      007089 EF               [12] 3845 	mov	a,r7
      00708A F0               [24] 3846 	movx	@dptr,a
      00708B 75 82 03         [24] 3847 	mov	dpl, #0x03
                                   3848 ;	tmk_core/protocol/ch555/usb_ak820.c:618: }
      00708E 02 6D 6B         [24] 3849 	ljmp	_ak820_usb_send
      007091                       3850 00106$:
      007091 22               [24] 3851 	ret
                                   3852 ;------------------------------------------------------------
                                   3853 ;Allocation info for local variables in function 'ak820_usb_raw_task'
                                   3854 ;------------------------------------------------------------
                                   3855 ;sloc0         Allocated with name '_ak820_usb_raw_task_sloc0_1_0'
                                   3856 ;i             Allocated with name '_ak820_usb_raw_task_i_10000_468'
                                   3857 ;length        Allocated with name '_ak820_usb_raw_task_length_10000_468'
                                   3858 ;address       Allocated with name '_ak820_usb_raw_task_address_10000_468'
                                   3859 ;saved_ea      Allocated with name '_ak820_usb_raw_task_saved_ea_10000_468'
                                   3860 ;------------------------------------------------------------
                                   3861 ;	tmk_core/protocol/ch555/usb_ak820.c:620: void ak820_usb_raw_task(void) {
                                   3862 ;	-----------------------------------------
                                   3863 ;	 function ak820_usb_raw_task
                                   3864 ;	-----------------------------------------
      007092                       3865 _ak820_usb_raw_task:
                                   3866 ;	tmk_core/protocol/ch555/usb_ak820.c:624: uint8_t saved_ea = EA;
      007092 A2 AF            [12] 3867 	mov	c,_EA
      007094 E4               [12] 3868 	clr	a
      007095 33               [12] 3869 	rlc	a
      007096 FF               [12] 3870 	mov	r7,a
                                   3871 ;	tmk_core/protocol/ch555/usb_ak820.c:625: EA = 0;
                                   3872 ;	assignBit
      007097 C2 AF            [12] 3873 	clr	_EA
                                   3874 ;	tmk_core/protocol/ch555/usb_ak820.c:626: if (!USB_EnumStatus || raw_state != RAW_READY) { EA = saved_ea; return; }
      007099 90 07 DF         [24] 3875 	mov	dptr,#_USB_EnumStatus
      00709C E0               [24] 3876 	movx	a,@dptr
      00709D 60 0A            [24] 3877 	jz	00101$
      00709F 90 07 E6         [24] 3878 	mov	dptr,#_raw_state
      0070A2 E0               [24] 3879 	movx	a,@dptr
      0070A3 FE               [12] 3880 	mov	r6,a
      0070A4 BE 02 02         [24] 3881 	cjne	r6,#0x02,00427$
      0070A7 80 06            [24] 3882 	sjmp	00102$
      0070A9                       3883 00427$:
      0070A9                       3884 00101$:
                                   3885 ;	assignBit
      0070A9 EF               [12] 3886 	mov	a,r7
      0070AA 24 FF            [12] 3887 	add	a,#0xff
      0070AC 92 AF            [24] 3888 	mov	_EA,c
      0070AE 22               [24] 3889 	ret
      0070AF                       3890 00102$:
                                   3891 ;	tmk_core/protocol/ch555/usb_ak820.c:627: raw_state = RAW_WORK;
      0070AF 90 07 E6         [24] 3892 	mov	dptr,#_raw_state
      0070B2 74 03            [12] 3893 	mov	a,#0x03
      0070B4 F0               [24] 3894 	movx	@dptr,a
                                   3895 ;	tmk_core/protocol/ch555/usb_ak820.c:628: EA = saved_ea;
                                   3896 ;	assignBit
      0070B5 EF               [12] 3897 	mov	a,r7
      0070B6 24 FF            [12] 3898 	add	a,#0xff
      0070B8 92 AF            [24] 3899 	mov	_EA,c
                                   3900 ;	tmk_core/protocol/ch555/usb_ak820.c:629: if (raw_buffer[0] == 0xfd && raw_buffer[1] == 0) {
      0070BA 90 07 E7         [24] 3901 	mov	dptr,#_raw_buffer
      0070BD E0               [24] 3902 	movx	a,@dptr
      0070BE FF               [12] 3903 	mov	r7,a
      0070BF E4               [12] 3904 	clr	a
      0070C0 BF FD 01         [24] 3905 	cjne	r7,#0xfd,00428$
      0070C3 04               [12] 3906 	inc	a
      0070C4                       3907 00428$:
      0070C4 FF               [12] 3908 	mov	r7,a
      0070C5 70 03            [24] 3909 	jnz	00430$
      0070C7 02 71 67         [24] 3910 	ljmp	00141$
      0070CA                       3911 00430$:
      0070CA 90 07 E8         [24] 3912 	mov	dptr,#(_raw_buffer + 0x0001)
      0070CD E0               [24] 3913 	movx	a,@dptr
      0070CE 60 03            [24] 3914 	jz	00431$
      0070D0 02 71 67         [24] 3915 	ljmp	00141$
      0070D3                       3916 00431$:
                                   3917 ;	tmk_core/protocol/ch555/usb_ak820.c:632: address = ((uint16_t)raw_buffer[2] << 8) | raw_buffer[3];
      0070D3 90 07 E9         [24] 3918 	mov	dptr,#(_raw_buffer + 0x0002)
      0070D6 E0               [24] 3919 	movx	a,@dptr
      0070D7 FD               [12] 3920 	mov	r5,a
      0070D8 7E 00            [12] 3921 	mov	r6,#0x00
      0070DA 90 07 EA         [24] 3922 	mov	dptr,#(_raw_buffer + 0x0003)
      0070DD E0               [24] 3923 	movx	a,@dptr
      0070DE 7B 00            [12] 3924 	mov	r3,#0x00
      0070E0 42 06            [12] 3925 	orl	ar6,a
      0070E2 EB               [12] 3926 	mov	a,r3
      0070E3 42 05            [12] 3927 	orl	ar5,a
                                   3928 ;	tmk_core/protocol/ch555/usb_ak820.c:633: length = raw_buffer[4];
      0070E5 90 07 EB         [24] 3929 	mov	dptr,#(_raw_buffer + 0x0004)
      0070E8 E0               [24] 3930 	movx	a,@dptr
      0070E9 FC               [12] 3931 	mov	r4,a
                                   3932 ;	tmk_core/protocol/ch555/usb_ak820.c:634: for (i = 5; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
      0070EA 7B 05            [12] 3933 	mov	r3,#0x05
      0070EC                       3934 00151$:
      0070EC EB               [12] 3935 	mov	a,r3
      0070ED 12 73 6F         [24] 3936 	lcall	_ak820_outline_0040
      0070F0 0B               [12] 3937 	inc	r3
      0070F1 BB 20 00         [24] 3938 	cjne	r3,#0x20,00432$
      0070F4                       3939 00432$:
      0070F4 40 F6            [24] 3940 	jc	00151$
                                   3941 ;	tmk_core/protocol/ch555/usb_ak820.c:635: if (length > RAW_EPSIZE - 5 || (length && address > 0xffffu - (length - 1))) {
      0070F6 EC               [12] 3942 	mov	a,r4
      0070F7 24 E4            [12] 3943 	add	a,#0xff - 0x1b
      0070F9 40 1C            [24] 3944 	jc	00106$
                                   3945 ;	free result
      0070FB EC               [12] 3946 	mov	a,r4
      0070FC 60 26            [24] 3947 	jz	00212$
      0070FE 8C 03            [24] 3948 	mov	ar3,r4
      007100 1B               [12] 3949 	dec	r3
      007101 7A 00            [12] 3950 	mov	r2,#0x00
      007103 74 FF            [12] 3951 	mov	a,#0xff
      007105 C3               [12] 3952 	clr	c
      007106 9B               [12] 3953 	subb	a,r3
      007107 FB               [12] 3954 	mov	r3,a
      007108 74 FF            [12] 3955 	mov	a,#0xff
      00710A 9A               [12] 3956 	subb	a,r2
      00710B FA               [12] 3957 	mov	r2,a
      00710C 8E 00            [24] 3958 	mov	ar0,r6
      00710E 8D 01            [24] 3959 	mov	ar1,r5
      007110 C3               [12] 3960 	clr	c
      007111 EB               [12] 3961 	mov	a,r3
      007112 98               [12] 3962 	subb	a,r0
      007113 EA               [12] 3963 	mov	a,r2
      007114 99               [12] 3964 	subb	a,r1
      007115 50 0D            [24] 3965 	jnc	00212$
                                   3966 ;	free result
      007117                       3967 00106$:
                                   3968 ;	tmk_core/protocol/ch555/usb_ak820.c:636: raw_buffer[1] = 0xff;
      007117 90 07 E8         [24] 3969 	mov	dptr,#(_raw_buffer + 0x0001)
      00711A 74 FF            [12] 3970 	mov	a,#0xff
      00711C F0               [24] 3971 	movx	@dptr,a
                                   3972 ;	tmk_core/protocol/ch555/usb_ak820.c:637: raw_buffer[4] = 0;
      00711D 90 07 EB         [24] 3973 	mov	dptr,#(_raw_buffer + 0x0004)
      007120 E4               [12] 3974 	clr	a
      007121 F0               [24] 3975 	movx	@dptr,a
                                   3976 ;	tmk_core/protocol/ch555/usb_ak820.c:639: for (i = 0; i < length; ++i) raw_buffer[5 + i] = READ_CODE(address + i);
      007122 80 3A            [24] 3977 	sjmp	00108$
      007124                       3978 00212$:
      007124 7B 00            [12] 3979 	mov	r3,#0x00
      007126                       3980 00154$:
      007126 C3               [12] 3981 	clr	c
      007127 EB               [12] 3982 	mov	a,r3
      007128 9C               [12] 3983 	subb	a,r4
      007129 50 33            [24] 3984 	jnc	00108$
      00712B C0 04            [24] 3985 	push	ar4
      00712D 8B 02            [24] 3986 	mov	ar2,r3
      00712F 74 05            [12] 3987 	mov	a,#0x05
      007131 2A               [12] 3988 	add	a, r2
      007132 F9               [12] 3989 	mov	r1,a
      007133 33               [12] 3990 	rlc	a
      007134 95 E0            [12] 3991 	subb	a,acc
      007136 FA               [12] 3992 	mov	r2,a
      007137 E9               [12] 3993 	mov	a,r1
      007138 24 E7            [12] 3994 	add	a, #_raw_buffer
      00713A F9               [12] 3995 	mov	r1,a
      00713B EA               [12] 3996 	mov	a,r2
      00713C 34 07            [12] 3997 	addc	a, #(_raw_buffer >> 8)
      00713E FA               [12] 3998 	mov	r2,a
      00713F 8B 1E            [24] 3999 	mov	_ak820_usb_raw_task_sloc0_1_0,r3
      007141 75 1F 00         [24] 4000 	mov	(_ak820_usb_raw_task_sloc0_1_0 + 1),#0x00
      007144 8E 00            [24] 4001 	mov	ar0,r6
      007146 8D 04            [24] 4002 	mov	ar4,r5
      007148 E5 1E            [12] 4003 	mov	a,_ak820_usb_raw_task_sloc0_1_0
      00714A 28               [12] 4004 	add	a, r0
      00714B F8               [12] 4005 	mov	r0,a
      00714C E5 1F            [12] 4006 	mov	a,(_ak820_usb_raw_task_sloc0_1_0 + 1)
      00714E 3C               [12] 4007 	addc	a, r4
      00714F FC               [12] 4008 	mov	r4,a
      007150 88 82            [24] 4009 	mov	dpl,r0
      007152 8C 83            [24] 4010 	mov	dph,r4
      007154 E4               [12] 4011 	clr	a
      007155 93               [24] 4012 	movc	a,@a+dptr
      007156 12 73 81         [24] 4013 	lcall	_ak820_outline_0137
      007159 0B               [12] 4014 	inc	r3
      00715A D0 04            [24] 4015 	pop	ar4
      00715C 80 C8            [24] 4016 	sjmp	00154$
      00715E                       4017 00108$:
                                   4018 ;	tmk_core/protocol/ch555/usb_ak820.c:643: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
      00715E 12 73 5B         [24] 4019 	lcall	_ak820_outline_0008
      007161 12 6D 6B         [24] 4020 	lcall	_ak820_usb_send
      007164 02 72 E9         [24] 4021 	ljmp	00142$
      007167                       4022 00141$:
                                   4023 ;	tmk_core/protocol/ch555/usb_ak820.c:644: } else if (raw_buffer[0] == 0xfd && raw_buffer[1] == 1) {
      007167 EF               [12] 4024 	mov	a,r7
      007168 70 03            [24] 4025 	jnz	00438$
      00716A 02 71 EC         [24] 4026 	ljmp	00137$
      00716D                       4027 00438$:
      00716D 90 07 E8         [24] 4028 	mov	dptr,#(_raw_buffer + 0x0001)
      007170 E0               [24] 4029 	movx	a,@dptr
      007171 FE               [12] 4030 	mov	r6,a
      007172 BE 01 02         [24] 4031 	cjne	r6,#0x01,00439$
      007175 80 03            [24] 4032 	sjmp	00440$
      007177                       4033 00439$:
      007177 02 71 EC         [24] 4034 	ljmp	00137$
      00717A                       4035 00440$:
                                   4036 ;	tmk_core/protocol/ch555/usb_ak820.c:647: for (i = 2; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
      00717A 7E 02            [12] 4037 	mov	r6,#0x02
      00717C                       4038 00156$:
      00717C EE               [12] 4039 	mov	a,r6
      00717D 12 73 6F         [24] 4040 	lcall	_ak820_outline_0040
      007180 0E               [12] 4041 	inc	r6
      007181 BE 20 00         [24] 4042 	cjne	r6,#0x20,00441$
      007184                       4043 00441$:
      007184 40 F6            [24] 4044 	jc	00156$
                                   4045 ;	tmk_core/protocol/ch555/usb_ak820.c:648: raw_buffer[2] = 1;
      007186 90 07 E9         [24] 4046 	mov	dptr,#(_raw_buffer + 0x0002)
      007189 74 01            [12] 4047 	mov	a,#0x01
      00718B F0               [24] 4048 	movx	@dptr,a
                                   4049 ;	tmk_core/protocol/ch555/usb_ak820.c:649: raw_buffer[3] = 0xa8;
      00718C 90 07 EA         [24] 4050 	mov	dptr,#(_raw_buffer + 0x0003)
      00718F 74 A8            [12] 4051 	mov	a,#0xa8
      007191 F0               [24] 4052 	movx	@dptr,a
                                   4053 ;	tmk_core/protocol/ch555/usb_ak820.c:650: ak820_nvm_diagnostic(&raw_buffer[4]);
      007192 90 07 EB         [24] 4054 	mov	dptr,#(_raw_buffer + 0x0004)
      007195 12 41 2B         [24] 4055 	lcall	_ak820_nvm_diagnostic
                                   4056 ;	tmk_core/protocol/ch555/usb_ak820.c:651: for (i = 0; i < 6; ++i) raw_buffer[11 + i] = ak820_flash_diagnostic[i];
      007198 7E 00            [12] 4057 	mov	r6,#0x00
      00719A                       4058 00158$:
      00719A 8E 05            [24] 4059 	mov	ar5,r6
      00719C 74 0B            [12] 4060 	mov	a,#0x0b
      00719E 2D               [12] 4061 	add	a, r5
      00719F 24 E7            [12] 4062 	add	a,#_raw_buffer
      0071A1 FD               [12] 4063 	mov	r5,a
      0071A2 E4               [12] 4064 	clr	a
      0071A3 34 07            [12] 4065 	addc	a, #(_raw_buffer >> 8)
      0071A5 FC               [12] 4066 	mov	r4,a
      0071A6 EE               [12] 4067 	mov	a,r6
      0071A7 24 B6            [12] 4068 	add	a, #_ak820_flash_diagnostic
      0071A9 F5 82            [12] 4069 	mov	dpl,a
      0071AB E4               [12] 4070 	clr	a
      0071AC 34 04            [12] 4071 	addc	a, #(_ak820_flash_diagnostic >> 8)
      0071AE F5 83            [12] 4072 	mov	dph,a
      0071B0 E0               [24] 4073 	movx	a,@dptr
      0071B1 12 49 2F         [24] 4074 	lcall	_ak820_outline_0186
      0071B4 F0               [24] 4075 	movx	@dptr,a
      0071B5 0E               [12] 4076 	inc	r6
      0071B6 BE 06 00         [24] 4077 	cjne	r6,#0x06,00443$
      0071B9                       4078 00443$:
      0071B9 40 DF            [24] 4079 	jc	00158$
                                   4080 ;	tmk_core/protocol/ch555/usb_ak820.c:652: raw_buffer[17] = vial_unlocked;
      0071BB 90 0E 69         [24] 4081 	mov	dptr,#_vial_unlocked
      0071BE E0               [24] 4082 	movx	a,@dptr
      0071BF 90 07 F8         [24] 4083 	mov	dptr,#(_raw_buffer + 0x0011)
      0071C2 F0               [24] 4084 	movx	@dptr,a
                                   4085 ;	tmk_core/protocol/ch555/usb_ak820.c:653: raw_buffer[18] = vial_unlock_in_progress;
      0071C3 90 0E 6A         [24] 4086 	mov	dptr,#_vial_unlock_in_progress
      0071C6 E0               [24] 4087 	movx	a,@dptr
      0071C7 90 07 F9         [24] 4088 	mov	dptr,#(_raw_buffer + 0x0012)
      0071CA F0               [24] 4089 	movx	@dptr,a
                                   4090 ;	tmk_core/protocol/ch555/usb_ak820.c:654: raw_buffer[19] = USB_EnumStatus;
      0071CB 90 07 DF         [24] 4091 	mov	dptr,#_USB_EnumStatus
      0071CE E0               [24] 4092 	movx	a,@dptr
      0071CF 90 07 FA         [24] 4093 	mov	dptr,#(_raw_buffer + 0x0013)
      0071D2 F0               [24] 4094 	movx	@dptr,a
                                   4095 ;	tmk_core/protocol/ch555/usb_ak820.c:655: raw_buffer[20] = USB_SleepStatus;
      0071D3 90 07 E0         [24] 4096 	mov	dptr,#_USB_SleepStatus
      0071D6 E0               [24] 4097 	movx	a,@dptr
      0071D7 90 07 FB         [24] 4098 	mov	dptr,#(_raw_buffer + 0x0014)
      0071DA F0               [24] 4099 	movx	@dptr,a
                                   4100 ;	tmk_core/protocol/ch555/usb_ak820.c:656: raw_buffer[21] = raw_state;
      0071DB 90 07 E6         [24] 4101 	mov	dptr,#_raw_state
      0071DE E0               [24] 4102 	movx	a,@dptr
      0071DF 90 07 FC         [24] 4103 	mov	dptr,#(_raw_buffer + 0x0015)
      0071E2 F0               [24] 4104 	movx	@dptr,a
                                   4105 ;	tmk_core/protocol/ch555/usb_ak820.c:657: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
      0071E3 12 73 5B         [24] 4106 	lcall	_ak820_outline_0008
      0071E6 12 6D 6B         [24] 4107 	lcall	_ak820_usb_send
      0071E9 02 72 E9         [24] 4108 	ljmp	00142$
      0071EC                       4109 00137$:
                                   4110 ;	tmk_core/protocol/ch555/usb_ak820.c:659: } else if (raw_buffer[0] == 0xfd && raw_buffer[1] == 2) {
      0071EC EF               [12] 4111 	mov	a,r7
      0071ED 70 03            [24] 4112 	jnz	00445$
      0071EF 02 72 C6         [24] 4113 	ljmp	00133$
      0071F2                       4114 00445$:
      0071F2 12 73 87         [24] 4115 	lcall	_ak820_outline_0160
      0071F5 BF 02 02         [24] 4116 	cjne	r7,#0x02,00446$
      0071F8 80 03            [24] 4117 	sjmp	00447$
      0071FA                       4118 00446$:
      0071FA 02 72 C6         [24] 4119 	ljmp	00133$
      0071FD                       4120 00447$:
                                   4121 ;	tmk_core/protocol/ch555/usb_ak820.c:663: length = 1;
      0071FD 90 08 52         [24] 4122 	mov	dptr,#_ak820_usb_raw_task_length_10000_468
      007200 74 01            [12] 4123 	mov	a,#0x01
      007202 F0               [24] 4124 	movx	@dptr,a
                                   4125 ;	tmk_core/protocol/ch555/usb_ak820.c:664: if (raw_buffer[2] == 1 && raw_buffer[3] <= 1 && raw_buffer[4] <= AK820_OS_BREATHE &&
      007203 90 07 E9         [24] 4126 	mov	dptr,#(_raw_buffer + 0x0002)
      007206 E0               [24] 4127 	movx	a,@dptr
      007207 FF               [12] 4128 	mov	r7,a
      007208 BF 01 72         [24] 4129 	cjne	r7,#0x01,00235$
      00720B 90 07 EA         [24] 4130 	mov	dptr,#(_raw_buffer + 0x0003)
      00720E E0               [24] 4131 	movx	a,@dptr
      00720F FF               [12] 4132 	mov  r7,a
      007210 24 FE            [12] 4133 	add	a,#0xff - 0x01
      007212 40 69            [24] 4134 	jc	00235$
                                   4135 ;	free result
      007214 90 07 EB         [24] 4136 	mov	dptr,#(_raw_buffer + 0x0004)
      007217 E0               [24] 4137 	movx	a,@dptr
      007218 FE               [12] 4138 	mov  r6,a
      007219 24 FC            [12] 4139 	add	a,#0xff - 0x03
      00721B 40 60            [24] 4140 	jc	00235$
                                   4141 ;	free result
                                   4142 ;	tmk_core/protocol/ch555/usb_ak820.c:665: (raw_buffer[3] || !raw_buffer[4])) {
      00721D EF               [12] 4143 	mov	a,r7
      00721E 70 03            [24] 4144 	jnz	00227$
      007220 EE               [12] 4145 	mov	a,r6
      007221 70 5A            [24] 4146 	jnz	00235$
                                   4147 ;	tmk_core/protocol/ch555/usb_ak820.c:666: for (i = 5; i < RAW_EPSIZE && !raw_buffer[i]; ++i) {}
      007223                       4148 00227$:
      007223 7D 05            [12] 4149 	mov	r5,#0x05
      007225                       4150 00162$:
      007225 BD 20 00         [24] 4151 	cjne	r5,#0x20,00454$
      007228                       4152 00454$:
      007228 50 10            [24] 4153 	jnc	00113$
      00722A ED               [12] 4154 	mov	a,r5
      00722B 24 E7            [12] 4155 	add	a, #_raw_buffer
      00722D FB               [12] 4156 	mov	r3,a
      00722E E4               [12] 4157 	clr	a
      00722F 34 07            [12] 4158 	addc	a, #(_raw_buffer >> 8)
      007231 FC               [12] 4159 	mov	r4,a
      007232 12 73 7B         [24] 4160 	lcall	_ak820_outline_0118
      007235 70 03            [24] 4161 	jnz	00113$
      007237 0D               [12] 4162 	inc	r5
      007238 80 EB            [24] 4163 	sjmp	00162$
      00723A                       4164 00113$:
                                   4165 ;	tmk_core/protocol/ch555/usb_ak820.c:667: if (i == RAW_EPSIZE) {
      00723A BD 20 40         [24] 4166 	cjne	r5,#0x20,00235$
                                   4167 ;	tmk_core/protocol/ch555/usb_ak820.c:668: saved_ea = EA;
                                   4168 ;	assignBit
      00723D A2 AF            [12] 4169 	mov	c,_EA
      00723F 92 1C            [24] 4170 	mov	_ak820_usb_raw_task_sloc1_1_0,c
                                   4171 ;	tmk_core/protocol/ch555/usb_ak820.c:669: EA = 0;
                                   4172 ;	assignBit
      007241 C2 AF            [12] 4173 	clr	_EA
                                   4174 ;	tmk_core/protocol/ch555/usb_ak820.c:672: if (raw_state == RAW_WORK && USB_EnumStatus && D0UsbConfig &&
      007243 90 07 E6         [24] 4175 	mov	dptr,#_raw_state
      007246 E0               [24] 4176 	movx	a,@dptr
      007247 FD               [12] 4177 	mov	r5,a
      007248 BD 03 28         [24] 4178 	cjne	r5,#0x03,00117$
      00724B 90 07 DF         [24] 4179 	mov	dptr,#_USB_EnumStatus
      00724E E0               [24] 4180 	movx	a,@dptr
      00724F 60 22            [24] 4181 	jz	00117$
      007251 90 07 DE         [24] 4182 	mov	dptr,#_D0UsbConfig
      007254 E0               [24] 4183 	movx	a,@dptr
      007255 60 1C            [24] 4184 	jz	00117$
                                   4185 ;	tmk_core/protocol/ch555/usb_ak820.c:673: !(USB_SleepStatus & 2) && !vial_unlock_in_progress) {
      007257 90 07 E0         [24] 4186 	mov	dptr,#_USB_SleepStatus
      00725A E0               [24] 4187 	movx	a,@dptr
      00725B 20 E1 15         [24] 4188 	jb	acc.1,00117$
      00725E 90 0E 6A         [24] 4189 	mov	dptr,#_vial_unlock_in_progress
      007261 E0               [24] 4190 	movx	a,@dptr
      007262 70 0F            [24] 4191 	jnz	00117$
                                   4192 ;	tmk_core/protocol/ch555/usb_ak820.c:674: if (raw_buffer[3]) ak820_os_indicator_set(raw_buffer[4]);
      007264 EF               [12] 4193 	mov	a,r7
      007265 60 05            [24] 4194 	jz	00115$
      007267 8E 82            [24] 4195 	mov	dpl, r6
      007269 12 49 34         [24] 4196 	lcall	_ak820_os_indicator_set
      00726C                       4197 00115$:
                                   4198 ;	tmk_core/protocol/ch555/usb_ak820.c:675: length = 0;
      00726C 90 08 52         [24] 4199 	mov	dptr,#_ak820_usb_raw_task_length_10000_468
      00726F E4               [12] 4200 	clr	a
      007270 F0               [24] 4201 	movx	@dptr,a
      007271 80 06            [24] 4202 	sjmp	00118$
      007273                       4203 00117$:
                                   4204 ;	tmk_core/protocol/ch555/usb_ak820.c:676: } else length = 2;
      007273 90 08 52         [24] 4205 	mov	dptr,#_ak820_usb_raw_task_length_10000_468
      007276 74 02            [12] 4206 	mov	a,#0x02
      007278 F0               [24] 4207 	movx	@dptr,a
      007279                       4208 00118$:
                                   4209 ;	tmk_core/protocol/ch555/usb_ak820.c:677: EA = saved_ea;
                                   4210 ;	assignBit
      007279 A2 1C            [12] 4211 	mov	c,_ak820_usb_raw_task_sloc1_1_0
      00727B 92 AF            [24] 4212 	mov	_EA,c
                                   4213 ;	tmk_core/protocol/ch555/usb_ak820.c:680: for (i = 2; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
      00727D                       4214 00235$:
      00727D 7F 02            [12] 4215 	mov	r7,#0x02
      00727F                       4216 00164$:
      00727F EF               [12] 4217 	mov	a,r7
      007280 12 73 6F         [24] 4218 	lcall	_ak820_outline_0040
      007283 0F               [12] 4219 	inc	r7
      007284 BF 20 00         [24] 4220 	cjne	r7,#0x20,00466$
      007287                       4221 00466$:
      007287 40 F6            [24] 4222 	jc	00164$
                                   4223 ;	tmk_core/protocol/ch555/usb_ak820.c:681: raw_buffer[2] = 1;
      007289 90 07 E9         [24] 4224 	mov	dptr,#(_raw_buffer + 0x0002)
      00728C 74 01            [12] 4225 	mov	a,#0x01
      00728E F0               [24] 4226 	movx	@dptr,a
                                   4227 ;	tmk_core/protocol/ch555/usb_ak820.c:682: raw_buffer[3] = length;
      00728F 90 08 52         [24] 4228 	mov	dptr,#_ak820_usb_raw_task_length_10000_468
      007292 E0               [24] 4229 	movx	a,@dptr
      007293 90 07 EA         [24] 4230 	mov	dptr,#(_raw_buffer + 0x0003)
      007296 F0               [24] 4231 	movx	@dptr,a
                                   4232 ;	tmk_core/protocol/ch555/usb_ak820.c:683: raw_buffer[4] = ak820_os_indicator_get();
      007297 12 49 5B         [24] 4233 	lcall	_ak820_os_indicator_get
      00729A AF 82            [24] 4234 	mov	r7, dpl
      00729C 90 07 EB         [24] 4235 	mov	dptr,#(_raw_buffer + 0x0004)
      00729F EF               [12] 4236 	mov	a,r7
      0072A0 F0               [24] 4237 	movx	@dptr,a
                                   4238 ;	tmk_core/protocol/ch555/usb_ak820.c:684: raw_buffer[5] = 0xa8;
      0072A1 90 07 EC         [24] 4239 	mov	dptr,#(_raw_buffer + 0x0005)
      0072A4 74 A8            [12] 4240 	mov	a,#0xa8
      0072A6 F0               [24] 4241 	movx	@dptr,a
                                   4242 ;	tmk_core/protocol/ch555/usb_ak820.c:685: raw_buffer[6] = (uint8_t)AK820_OS_INDICATOR_LEASE_MS;
      0072A7 90 07 ED         [24] 4243 	mov	dptr,#(_raw_buffer + 0x0006)
      0072AA 74 B8            [12] 4244 	mov	a,#0xb8
      0072AC F0               [24] 4245 	movx	@dptr,a
                                   4246 ;	tmk_core/protocol/ch555/usb_ak820.c:686: raw_buffer[7] = (uint8_t)(AK820_OS_INDICATOR_LEASE_MS >> 8);
      0072AD 90 07 EE         [24] 4247 	mov	dptr,#(_raw_buffer + 0x0007)
      0072B0 74 0B            [12] 4248 	mov	a,#0x0b
      0072B2 F0               [24] 4249 	movx	@dptr,a
                                   4250 ;	tmk_core/protocol/ch555/usb_ak820.c:687: raw_buffer[8] = (uint8_t)AK820_OS_INDICATOR_PERIOD_MS;
      0072B3 90 07 EF         [24] 4251 	mov	dptr,#(_raw_buffer + 0x0008)
      0072B6 E4               [12] 4252 	clr	a
      0072B7 F0               [24] 4253 	movx	@dptr,a
                                   4254 ;	tmk_core/protocol/ch555/usb_ak820.c:688: raw_buffer[9] = (uint8_t)(AK820_OS_INDICATOR_PERIOD_MS >> 8);
      0072B8 90 07 F0         [24] 4255 	mov	dptr,#(_raw_buffer + 0x0009)
      0072BB 74 10            [12] 4256 	mov	a,#0x10
      0072BD F0               [24] 4257 	movx	@dptr,a
                                   4258 ;	tmk_core/protocol/ch555/usb_ak820.c:689: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
      0072BE 12 73 5B         [24] 4259 	lcall	_ak820_outline_0008
      0072C1 12 6D 6B         [24] 4260 	lcall	_ak820_usb_send
      0072C4 80 23            [24] 4261 	sjmp	00142$
      0072C6                       4262 00133$:
                                   4263 ;	tmk_core/protocol/ch555/usb_ak820.c:692: raw_reply_without_nvm = raw_request_is_nonpersistent();
      0072C6 12 6F 7A         [24] 4264 	lcall	_raw_request_is_nonpersistent
      0072C9 E5 82            [12] 4265 	mov	a, dpl
      0072CB 90 08 07         [24] 4266 	mov	dptr,#_raw_reply_without_nvm
      0072CE F0               [24] 4267 	movx	@dptr,a
                                   4268 ;	tmk_core/protocol/ch555/usb_ak820.c:693: ak820_nvm_begin();
      0072CF 12 45 0E         [24] 4269 	lcall	_ak820_nvm_begin
                                   4270 ;	tmk_core/protocol/ch555/usb_ak820.c:694: raw_hid_receive(raw_buffer, RAW_EPSIZE);
      0072D2 90 0C 9A         [24] 4271 	mov	dptr,#_raw_hid_receive_PARM_2
      0072D5 74 20            [12] 4272 	mov	a,#0x20
      0072D7 F0               [24] 4273 	movx	@dptr,a
      0072D8 90 07 E7         [24] 4274 	mov	dptr,#_raw_buffer
      0072DB 75 F0 00         [24] 4275 	mov	b, #0x00
      0072DE 12 AD 16         [24] 4276 	lcall	_raw_hid_receive
                                   4277 ;	tmk_core/protocol/ch555/usb_ak820.c:695: ak820_nvm_end();
      0072E1 12 45 23         [24] 4278 	lcall	_ak820_nvm_end
                                   4279 ;	tmk_core/protocol/ch555/usb_ak820.c:696: raw_reply_without_nvm = false;
      0072E4 90 08 07         [24] 4280 	mov	dptr,#_raw_reply_without_nvm
      0072E7 E4               [12] 4281 	clr	a
      0072E8 F0               [24] 4282 	movx	@dptr,a
      0072E9                       4283 00142$:
                                   4284 ;	tmk_core/protocol/ch555/usb_ak820.c:698: saved_ea = EA;
                                   4285 ;	assignBit
      0072E9 A2 AF            [12] 4286 	mov	c,_EA
      0072EB 92 1C            [24] 4287 	mov	_ak820_usb_raw_task_sloc1_1_0,c
                                   4288 ;	tmk_core/protocol/ch555/usb_ak820.c:699: EA = 0;
                                   4289 ;	assignBit
      0072ED C2 AF            [12] 4290 	clr	_EA
                                   4291 ;	tmk_core/protocol/ch555/usb_ak820.c:701: if (raw_state == RAW_TX_ACTIVE) raw_state = RAW_TX_WAIT;
      0072EF 12 73 8D         [24] 4292 	lcall	_ak820_outline_0162
      0072F2 BF 04 08         [24] 4293 	cjne	r7,#0x04,00149$
      0072F5 90 07 E6         [24] 4294 	mov	dptr,#_raw_state
      0072F8 74 05            [12] 4295 	mov	a,#0x05
      0072FA F0               [24] 4296 	movx	@dptr,a
      0072FB 80 1B            [24] 4297 	sjmp	00150$
      0072FD                       4298 00149$:
                                   4299 ;	tmk_core/protocol/ch555/usb_ak820.c:702: else if (raw_state == RAW_WORK || raw_state == RAW_DRAINED || raw_state == RAW_CANCELLED) raw_state = RAW_IDLE;
      0072FD 12 73 8D         [24] 4300 	lcall	_ak820_outline_0162
      007300 BF 03 02         [24] 4301 	cjne	r7,#0x03,00470$
      007303 80 0E            [24] 4302 	sjmp	00144$
      007305                       4303 00470$:
      007305 12 73 8D         [24] 4304 	lcall	_ak820_outline_0162
      007308 BF 06 02         [24] 4305 	cjne	r7,#0x06,00471$
      00730B 80 06            [24] 4306 	sjmp	00144$
      00730D                       4307 00471$:
      00730D 12 73 8D         [24] 4308 	lcall	_ak820_outline_0162
      007310 BF 07 05         [24] 4309 	cjne	r7,#0x07,00150$
      007313                       4310 00144$:
      007313 90 07 E6         [24] 4311 	mov	dptr,#_raw_state
      007316 E4               [12] 4312 	clr	a
      007317 F0               [24] 4313 	movx	@dptr,a
      007318                       4314 00150$:
                                   4315 ;	tmk_core/protocol/ch555/usb_ak820.c:703: EA = saved_ea;
                                   4316 ;	assignBit
      007318 A2 1C            [12] 4317 	mov	c,_ak820_usb_raw_task_sloc1_1_0
      00731A 92 AF            [24] 4318 	mov	_EA,c
                                   4319 ;	tmk_core/protocol/ch555/usb_ak820.c:704: }
      00731C 22               [24] 4320 	ret
                                   4321 ;------------------------------------------------------------
                                   4322 ;Allocation info for local variables in function 'ak820_usb_keyboard_blocked'
                                   4323 ;------------------------------------------------------------
                                   4324 ;	tmk_core/protocol/ch555/usb_ak820.c:707: bool ak820_usb_keyboard_blocked(void) {
                                   4325 ;	-----------------------------------------
                                   4326 ;	 function ak820_usb_keyboard_blocked
                                   4327 ;	-----------------------------------------
      00731D                       4328 _ak820_usb_keyboard_blocked:
                                   4329 ;	tmk_core/protocol/ch555/usb_ak820.c:708: return !USB_EnumStatus || (USB_SleepStatus & 2) || keyboard_reset;
      00731D 90 07 DF         [24] 4330 	mov	dptr,#_USB_EnumStatus
      007320 E0               [24] 4331 	movx	a,@dptr
      007321 60 13            [24] 4332 	jz	00104$
      007323 90 07 E0         [24] 4333 	mov	dptr,#_USB_SleepStatus
      007326 E0               [24] 4334 	movx	a,@dptr
      007327 03               [12] 4335 	rr	a
      007328 54 01            [12] 4336 	anl	a,#0x01
      00732A 70 0A            [24] 4337 	jnz	00104$
      00732C 90 08 08         [24] 4338 	mov	dptr,#_keyboard_reset
      00732F E0               [24] 4339 	movx	a,@dptr
      007330 70 04            [24] 4340 	jnz	00104$
                                   4341 ;	assignBit
      007332 C2 1D            [12] 4342 	clr	_ak820_usb_keyboard_blocked_sloc0_1_0
      007334 80 02            [24] 4343 	sjmp	00105$
      007336                       4344 00104$:
                                   4345 ;	assignBit
      007336 D2 1D            [12] 4346 	setb	_ak820_usb_keyboard_blocked_sloc0_1_0
      007338                       4347 00105$:
      007338 A2 1D            [12] 4348 	mov	c,_ak820_usb_keyboard_blocked_sloc0_1_0
      00733A E4               [12] 4349 	clr	a
      00733B 33               [12] 4350 	rlc	a
      00733C F5 82            [12] 4351 	mov	dpl, a
                                   4352 ;	tmk_core/protocol/ch555/usb_ak820.c:709: }
      00733E 22               [24] 4353 	ret
                                   4354 ;------------------------------------------------------------
                                   4355 ;Allocation info for local variables in function 'ak820_usb_take_keyboard_reset'
                                   4356 ;------------------------------------------------------------
                                   4357 ;result        Allocated with name '_ak820_usb_take_keyboard_reset_result_10000_500'
                                   4358 ;saved_ea      Allocated with name '_ak820_usb_take_keyboard_reset_saved_ea_10000_500'
                                   4359 ;------------------------------------------------------------
                                   4360 ;	tmk_core/protocol/ch555/usb_ak820.c:712: bool ak820_usb_take_keyboard_reset(void) {
                                   4361 ;	-----------------------------------------
                                   4362 ;	 function ak820_usb_take_keyboard_reset
                                   4363 ;	-----------------------------------------
      00733F                       4364 _ak820_usb_take_keyboard_reset:
                                   4365 ;	tmk_core/protocol/ch555/usb_ak820.c:714: uint8_t saved_ea = EA;
                                   4366 ;	assignBit
      00733F A2 AF            [12] 4367 	mov	c,_EA
      007341 92 1E            [24] 4368 	mov	_ak820_usb_take_keyboard_reset_sloc0_1_0,c
                                   4369 ;	tmk_core/protocol/ch555/usb_ak820.c:715: EA = 0;
                                   4370 ;	assignBit
      007343 C2 AF            [12] 4371 	clr	_EA
                                   4372 ;	tmk_core/protocol/ch555/usb_ak820.c:716: result = keyboard_reset;
      007345 90 08 08         [24] 4373 	mov	dptr,#_keyboard_reset
      007348 E0               [24] 4374 	movx	a,@dptr
      007349 FF               [12] 4375 	mov	r7,a
                                   4376 ;	tmk_core/protocol/ch555/usb_ak820.c:717: keyboard_reset = 0;
      00734A E4               [12] 4377 	clr	a
      00734B F0               [24] 4378 	movx	@dptr,a
                                   4379 ;	tmk_core/protocol/ch555/usb_ak820.c:718: EA = saved_ea;
                                   4380 ;	assignBit
      00734C A2 1E            [12] 4381 	mov	c,_ak820_usb_take_keyboard_reset_sloc0_1_0
      00734E 92 AF            [24] 4382 	mov	_EA,c
                                   4383 ;	tmk_core/protocol/ch555/usb_ak820.c:719: return result != 0;
      007350 EF               [12] 4384 	mov	a,r7
      007351 B4 01 00         [24] 4385 	cjne	a,#0x01,00103$
      007354                       4386 00103$:
      007354 B3               [12] 4387 	cpl	c
      007355 92 1E            [24] 4388 	mov	_ak820_usb_take_keyboard_reset_sloc0_1_0,c
      007357 12 38 86         [24] 4389 	lcall	_ak820_outline_0167
                                   4390 ;	tmk_core/protocol/ch555/usb_ak820.c:720: }
      00735A 22               [24] 4391 	ret
                                   4392 	.area CSEG    (CODE)
                                   4393 	.area CONST   (CODE)
                                   4394 	.area CONST   (CODE)
      00BFEE                       4395 _shared_offsets:
      00BFEE 00                    4396 	.db #0x00	; 0
      00BFEF 00                    4397 	.db #0x00	; 0
      00BFF0 28                    4398 	.db #0x28	; 40
      00BFF1 28                    4399 	.db #0x28	; 40
      00BFF2 2B                    4400 	.db #0x2b	; 43
      00BFF3 00                    4401 	.db #0x00	; 0
      00BFF4 08                    4402 	.db #0x08	; 8
                                   4403 	.area CSEG    (CODE)
                                   4404 	.area CONST   (CODE)
      00BFF5                       4405 _shared_lengths:
      00BFF5 00                    4406 	.db #0x00	; 0
      00BFF6 00                    4407 	.db #0x00	; 0
      00BFF7 00                    4408 	.db #0x00	; 0
      00BFF8 03                    4409 	.db #0x03	; 3
      00BFF9 03                    4410 	.db #0x03	; 3
      00BFFA 00                    4411 	.db #0x00	; 0
      00BFFB 20                    4412 	.db #0x20	; 32
                                   4413 	.area CSEG    (CODE)
                                   4414 	.area CONST   (CODE)
      00BFFC                       4415 _interface_descriptors:
      00BFFC 97 C5                 4416 	.byte _KeyboardReport, (_KeyboardReport >> 8)
      00BFFE 97 C6                 4417 	.byte (_ConfigurationDescriptor + 18), ((_ConfigurationDescriptor + 18) >> 8)
      00C000 4A C6                 4418 	.byte _RawReport, (_RawReport >> 8)
      00C002 B0 C6                 4419 	.byte (_ConfigurationDescriptor + 43), ((_ConfigurationDescriptor + 43) >> 8)
      00C004 DC C5                 4420 	.byte _SharedReport, (_SharedReport >> 8)
      00C006 C9 C6                 4421 	.byte (_ConfigurationDescriptor + 68), ((_ConfigurationDescriptor + 68) >> 8)
                                   4422 	.area CSEG    (CODE)
                                   4423 	.area XINIT   (CODE)
                                   4424 	.area CABS    (ABS,CODE)
                                   4425 
                                   4426 ; Experimental exact instruction outlining.
                                   4427 	.globl _ak820_outline_0008
                                   4428 	.globl _ak820_outline_0016
                                   4429 	.globl _ak820_outline_0037
                                   4430 	.globl _ak820_outline_0040
                                   4431 	.globl _ak820_outline_0095
                                   4432 	.globl _ak820_outline_0118
                                   4433 	.globl _ak820_outline_0137
                                   4434 	.globl _ak820_outline_0158
                                   4435 	.globl _ak820_outline_0160
                                   4436 	.globl _ak820_outline_0162
                                   4437 	.globl _ak820_outline_0167
                                   4438 	.globl _ak820_outline_0186
                                   4439 
                                   4440 	.area CSEG (CODE)
                                   4441 ; function ak820_outline_0008
      00735B                       4442 _ak820_outline_0008:
      00735B 90 08 44         [24] 4443 	mov	dptr,#_ak820_usb_send_PARM_2
      00735E 74 E7            [12] 4444 	mov	a,#_raw_buffer
      007360 F0               [24] 4445 	movx	@dptr,a
      007361 74 07            [12] 4446 	mov	a,#(_raw_buffer>>8)
      007363 A3               [24] 4447 	inc	dptr
      007364 F0               [24] 4448 	movx	@dptr,a
      007365 90 08 46         [24] 4449 	mov	dptr,#_ak820_usb_send_PARM_3
      007368 74 20            [12] 4450 	mov	a,#0x20
      00736A F0               [24] 4451 	movx	@dptr,a
      00736B 75 82 03         [24] 4452 	mov	dpl,#0x03
      00736E 22               [24] 4453 	ret
                                   4454 
                                   4455 	.area CSEG (CODE)
                                   4456 ; function ak820_outline_0040
      00736F                       4457 _ak820_outline_0040:
      00736F 24 E7            [12] 4458 	add	a,#_raw_buffer
      007371 F5 82            [12] 4459 	mov	dpl,a
      007373 E4               [12] 4460 	clr	a
      007374 34 07            [12] 4461 	addc	a,#(_raw_buffer>>8)
      007376 F5 83            [12] 4462 	mov	dph,a
      007378 E4               [12] 4463 	clr	a
      007379 F0               [24] 4464 	movx	@dptr,a
      00737A 22               [24] 4465 	ret
                                   4466 
                                   4467 	.area CSEG (CODE)
                                   4468 ; function ak820_outline_0118
      00737B                       4469 _ak820_outline_0118:
      00737B 8B 82            [24] 4470 	mov	dpl,r3
      00737D 8C 83            [24] 4471 	mov	dph,r4
      00737F E0               [24] 4472 	movx	a,@dptr
      007380 22               [24] 4473 	ret
                                   4474 
                                   4475 	.area CSEG (CODE)
                                   4476 ; function ak820_outline_0137
      007381                       4477 _ak820_outline_0137:
      007381 89 82            [24] 4478 	mov	dpl,r1
      007383 8A 83            [24] 4479 	mov	dph,r2
      007385 F0               [24] 4480 	movx	@dptr,a
      007386 22               [24] 4481 	ret
                                   4482 
                                   4483 	.area CSEG (CODE)
                                   4484 ; function ak820_outline_0160
      007387                       4485 _ak820_outline_0160:
      007387 90 07 E8         [24] 4486 	mov	dptr,#(_raw_buffer+0x0001)
      00738A E0               [24] 4487 	movx	a,@dptr
      00738B FF               [12] 4488 	mov	r7,a
      00738C 22               [24] 4489 	ret
                                   4490 
                                   4491 	.area CSEG (CODE)
                                   4492 ; function ak820_outline_0162
      00738D                       4493 _ak820_outline_0162:
      00738D 90 07 E6         [24] 4494 	mov	dptr,#_raw_state
      007390 E0               [24] 4495 	movx	a,@dptr
      007391 FF               [12] 4496 	mov	r7,a
      007392 22               [24] 4497 	ret
