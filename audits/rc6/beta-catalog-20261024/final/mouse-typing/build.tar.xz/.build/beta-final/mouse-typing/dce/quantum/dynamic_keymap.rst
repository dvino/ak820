                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module dynamic_keymap
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _dynamic_keymap_encoder_to_eeprom_address
                                     12 	.globl _ak820_combo_valid
                                     13 	.globl _ak820_eeprom_write_block_xdata
                                     14 	.globl _ak820_eeprom_read_block_xdata
                                     15 	.globl _ak820_nvm_flush
                                     16 	.globl _ak820_nvm_ok
                                     17 	.globl _ak820_macro_reset
                                     18 	.globl _ak820_macro_write
                                     19 	.globl _ak820_macro_length
                                     20 	.globl _ak820_macro_ready
                                     21 	.globl _send_char
                                     22 	.globl _keycode_at_encodermap_location_raw
                                     23 	.globl _keycode_at_keymap_location_raw
                                     24 	.globl _vial_keycode_tap
                                     25 	.globl _vial_keycode_up
                                     26 	.globl _vial_keycode_down
                                     27 	.globl _clear_keyboard
                                     28 	.globl _tap_code
                                     29 	.globl _unregister_code
                                     30 	.globl _register_code
                                     31 	.globl _mDelaymS
                                     32 	.globl ___memcpy
                                     33 	.globl _memset
                                     34 	.globl _eeprom_update_byte
                                     35 	.globl _eeprom_read_byte
                                     36 	.globl _ADC_START
                                     37 	.globl _S0_R_FIFO
                                     38 	.globl _S0_T_FIFO
                                     39 	.globl _S0_FREE
                                     40 	.globl _S0_IF_BYTE
                                     41 	.globl _S0_IF_FIRST
                                     42 	.globl _S0_IF_OV
                                     43 	.globl _S0_FST_ACT
                                     44 	.globl _CP_RL2
                                     45 	.globl _C_T2
                                     46 	.globl _TR2
                                     47 	.globl _EXEN2
                                     48 	.globl _TCLK
                                     49 	.globl _RCLK
                                     50 	.globl _EXF2
                                     51 	.globl _CAP1F
                                     52 	.globl _TF2
                                     53 	.globl _RI
                                     54 	.globl _TI
                                     55 	.globl _RB8
                                     56 	.globl _TB8
                                     57 	.globl _REN
                                     58 	.globl _SM2
                                     59 	.globl _SM1
                                     60 	.globl _SM0
                                     61 	.globl _IT0
                                     62 	.globl _IE0
                                     63 	.globl _IT1
                                     64 	.globl _IE1
                                     65 	.globl _TR0
                                     66 	.globl _TF0
                                     67 	.globl _TR1
                                     68 	.globl _TF1
                                     69 	.globl _P4_0
                                     70 	.globl _P4_1
                                     71 	.globl _P4_2
                                     72 	.globl _P4_3
                                     73 	.globl _P4_4
                                     74 	.globl _P4_5
                                     75 	.globl _P4_6
                                     76 	.globl _RXD
                                     77 	.globl _TXD
                                     78 	.globl _INT0
                                     79 	.globl _INT1
                                     80 	.globl _T0
                                     81 	.globl _T1
                                     82 	.globl _MOSI1
                                     83 	.globl _MISO1
                                     84 	.globl _SCK1
                                     85 	.globl _P3_0
                                     86 	.globl _P3_1
                                     87 	.globl _P3_2
                                     88 	.globl _P3_3
                                     89 	.globl _P3_4
                                     90 	.globl _P3_5
                                     91 	.globl _P3_6
                                     92 	.globl _P3_7
                                     93 	.globl _CAP1_
                                     94 	.globl _T2_
                                     95 	.globl _CAP2_
                                     96 	.globl _T2EX_
                                     97 	.globl _RXD1
                                     98 	.globl _TXD1
                                     99 	.globl _P2_0
                                    100 	.globl _P2_1
                                    101 	.globl _P2_2
                                    102 	.globl _P2_3
                                    103 	.globl _P2_4
                                    104 	.globl _P2_5
                                    105 	.globl _P2_6
                                    106 	.globl _P2_7
                                    107 	.globl _AIN0
                                    108 	.globl _AIN1
                                    109 	.globl _AIN2
                                    110 	.globl _AIN3
                                    111 	.globl _AIN4
                                    112 	.globl _AIN5
                                    113 	.globl _AIN6
                                    114 	.globl _AIN7
                                    115 	.globl _CAP1
                                    116 	.globl _T2
                                    117 	.globl _CAP2
                                    118 	.globl _T2EX
                                    119 	.globl _INT0_
                                    120 	.globl _SCS
                                    121 	.globl _MOSI
                                    122 	.globl _MISO
                                    123 	.globl _SCK
                                    124 	.globl _RXD1_
                                    125 	.globl _TXD1_
                                    126 	.globl _P1_0
                                    127 	.globl _P1_1
                                    128 	.globl _P1_2
                                    129 	.globl _P1_3
                                    130 	.globl _P1_4
                                    131 	.globl _P1_5
                                    132 	.globl _P1_6
                                    133 	.globl _P1_7
                                    134 	.globl _AIN8
                                    135 	.globl _AIN9
                                    136 	.globl _AIN10
                                    137 	.globl _AIN11
                                    138 	.globl _AIN12
                                    139 	.globl _AIN13
                                    140 	.globl _RXD_
                                    141 	.globl _TXD_
                                    142 	.globl _SCL0
                                    143 	.globl _SDA0
                                    144 	.globl _P0_0
                                    145 	.globl _P0_1
                                    146 	.globl _P0_2
                                    147 	.globl _P0_3
                                    148 	.globl _P0_4
                                    149 	.globl _P0_5
                                    150 	.globl _P0_6
                                    151 	.globl _P0_7
                                    152 	.globl _IE_SPI0
                                    153 	.globl _IE_USB
                                    154 	.globl _IE_ADC
                                    155 	.globl _IE_UART1
                                    156 	.globl _IE_PWM_I2C
                                    157 	.globl _IE_GPIO
                                    158 	.globl _IE_WDOG
                                    159 	.globl _PX0
                                    160 	.globl _PT0
                                    161 	.globl _PX1
                                    162 	.globl _PT1
                                    163 	.globl _PS
                                    164 	.globl _PT2
                                    165 	.globl _PL_FLAG
                                    166 	.globl _PH_FLAG
                                    167 	.globl _EX0
                                    168 	.globl _ET0
                                    169 	.globl _EX1
                                    170 	.globl _ET1
                                    171 	.globl _ES
                                    172 	.globl _ET2
                                    173 	.globl _E_DIS
                                    174 	.globl _EA
                                    175 	.globl _P
                                    176 	.globl _F1
                                    177 	.globl _OV
                                    178 	.globl _RS0
                                    179 	.globl _RS1
                                    180 	.globl _F0
                                    181 	.globl _AC
                                    182 	.globl _CY
                                    183 	.globl _I2CS_INT_ST
                                    184 	.globl _I2CX_INT
                                    185 	.globl _LED_STATUS
                                    186 	.globl _LED_DMA_H
                                    187 	.globl _LED_DMA_L
                                    188 	.globl _LED_DMA
                                    189 	.globl _LED_PWM_OE
                                    190 	.globl _LED_COMMON
                                    191 	.globl _ADC_CHAN
                                    192 	.globl _ADC_DAT_H
                                    193 	.globl _ADC_DAT_L
                                    194 	.globl _ADC_DAT
                                    195 	.globl _ADC_CTRL
                                    196 	.globl _SPI1_CK_SE
                                    197 	.globl _SPI1_CTRL
                                    198 	.globl _SPI1_DATA
                                    199 	.globl _SPI1_STAT
                                    200 	.globl _SIF1
                                    201 	.globl _SBAUD1
                                    202 	.globl _SBUF1
                                    203 	.globl _SCON1
                                    204 	.globl _SPI0_SETUP
                                    205 	.globl _SPI0_CK_SE
                                    206 	.globl _SPI0_CTRL
                                    207 	.globl _SPI0_DATA
                                    208 	.globl _SPI0_STAT
                                    209 	.globl _T2CAP1H
                                    210 	.globl _T2CAP1L
                                    211 	.globl _T2CAP1
                                    212 	.globl _TH2
                                    213 	.globl _TL2
                                    214 	.globl _T2COUNT
                                    215 	.globl _RCAP2H
                                    216 	.globl _RCAP2L
                                    217 	.globl _RCAP2
                                    218 	.globl _T2MOD
                                    219 	.globl _T2CON
                                    220 	.globl _SBUF
                                    221 	.globl _SCON
                                    222 	.globl _TH1
                                    223 	.globl _TH0
                                    224 	.globl _TL1
                                    225 	.globl _TL0
                                    226 	.globl _TMOD
                                    227 	.globl _TCON
                                    228 	.globl _XBUS_AUX
                                    229 	.globl _P7
                                    230 	.globl _P6_DIR
                                    231 	.globl _P6_OUT_PU
                                    232 	.globl _P6_IN
                                    233 	.globl _P5_DIR
                                    234 	.globl _P5_OUT_PU
                                    235 	.globl _P5_IN
                                    236 	.globl _P4_LED_KEY
                                    237 	.globl _P4_DIR_PU
                                    238 	.globl _P4_MOD_OC
                                    239 	.globl _P4
                                    240 	.globl _P3_DIR_PU
                                    241 	.globl _P3_MOD_OC
                                    242 	.globl _P3
                                    243 	.globl _P2_DIR_PU
                                    244 	.globl _P2_MOD_OC
                                    245 	.globl _P2
                                    246 	.globl _P1_DIR_PU
                                    247 	.globl _P1_MOD_OC
                                    248 	.globl _P1
                                    249 	.globl _P0_DIR_PU
                                    250 	.globl _P0_MOD_OC
                                    251 	.globl _P0
                                    252 	.globl _ROM_CTRL
                                    253 	.globl _ROM_DATA_HH
                                    254 	.globl _ROM_DATA_HL
                                    255 	.globl _ROM_DATA_HI
                                    256 	.globl _ROM_ADDR_H
                                    257 	.globl _ROM_ADDR_L
                                    258 	.globl _ROM_ADDR
                                    259 	.globl _GPIO_IE
                                    260 	.globl _IP_EX
                                    261 	.globl _IE_EX
                                    262 	.globl _IP
                                    263 	.globl _IE
                                    264 	.globl _WDOG_COUNT
                                    265 	.globl _RESET_KEEP
                                    266 	.globl _WAKE_CTRL
                                    267 	.globl _CLOCK_CFG
                                    268 	.globl _POWER_CFG
                                    269 	.globl _PCON
                                    270 	.globl _GLOBAL_CFG
                                    271 	.globl _SAFE_MOD
                                    272 	.globl _DPH
                                    273 	.globl _DPL
                                    274 	.globl _SP
                                    275 	.globl _A_INV
                                    276 	.globl _B
                                    277 	.globl _ACC
                                    278 	.globl _PSW
                                    279 	.globl _dynamic_keymap_macro_set_buffer_PARM_3
                                    280 	.globl _dynamic_keymap_macro_set_buffer_PARM_2
                                    281 	.globl _dynamic_keymap_macro_get_buffer_PARM_3
                                    282 	.globl _dynamic_keymap_macro_get_buffer_PARM_2
                                    283 	.globl _keycode_at_encodermap_location_PARM_3
                                    284 	.globl _keycode_at_encodermap_location_PARM_2
                                    285 	.globl _keycode_at_keymap_location_PARM_3
                                    286 	.globl _keycode_at_keymap_location_PARM_2
                                    287 	.globl _dynamic_keymap_set_buffer_PARM_3
                                    288 	.globl _dynamic_keymap_set_buffer_PARM_2
                                    289 	.globl _dynamic_keymap_get_buffer_PARM_3
                                    290 	.globl _dynamic_keymap_get_buffer_PARM_2
                                    291 	.globl _dynamic_keymap_set_combo_PARM_2
                                    292 	.globl _dynamic_keymap_get_combo_PARM_2
                                    293 	.globl _dynamic_keymap_set_encoder_PARM_4
                                    294 	.globl _dynamic_keymap_set_encoder_PARM_3
                                    295 	.globl _dynamic_keymap_set_encoder_PARM_2
                                    296 	.globl _dynamic_keymap_get_encoder_PARM_3
                                    297 	.globl _dynamic_keymap_get_encoder_PARM_2
                                    298 	.globl _dynamic_keymap_encoder_to_eeprom_address_PARM_2
                                    299 	.globl _dynamic_keymap_set_keycode_PARM_4
                                    300 	.globl _dynamic_keymap_set_keycode_PARM_3
                                    301 	.globl _dynamic_keymap_set_keycode_PARM_2
                                    302 	.globl _dynamic_keymap_get_keycode_PARM_3
                                    303 	.globl _dynamic_keymap_get_keycode_PARM_2
                                    304 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_3
                                    305 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_2
                                    306 	.globl _dynamic_keymap_get_layer_count
                                    307 	.globl _dynamic_keymap_key_to_eeprom_address
                                    308 	.globl _dynamic_keymap_get_keycode
                                    309 	.globl _dynamic_keymap_set_keycode
                                    310 	.globl _dynamic_keymap_get_encoder
                                    311 	.globl _dynamic_keymap_set_encoder
                                    312 	.globl _dynamic_keymap_get_combo
                                    313 	.globl _dynamic_keymap_set_combo
                                    314 	.globl _dynamic_keymap_reset
                                    315 	.globl _dynamic_keymap_get_buffer
                                    316 	.globl _dynamic_keymap_set_buffer
                                    317 	.globl _keycode_at_keymap_location
                                    318 	.globl _keycode_at_encodermap_location
                                    319 	.globl _dynamic_keymap_macro_get_count
                                    320 	.globl _dynamic_keymap_macro_get_buffer_size
                                    321 	.globl _dynamic_keymap_macro_get_buffer
                                    322 	.globl _dynamic_keymap_macro_set_buffer
                                    323 	.globl _dynamic_keymap_macro_reset
                                    324 	.globl _dynamic_keymap_macro_send
                                    325 ;--------------------------------------------------------
                                    326 ; special function registers
                                    327 ;--------------------------------------------------------
                                    328 	.area RSEG    (ABS,DATA)
      000000                        329 	.org 0x0000
                           0000D0   330 _PSW	=	0x00d0
                           0000E0   331 _ACC	=	0x00e0
                           0000F0   332 _B	=	0x00f0
                           0000FD   333 _A_INV	=	0x00fd
                           000081   334 _SP	=	0x0081
                           000082   335 _DPL	=	0x0082
                           000083   336 _DPH	=	0x0083
                           0000A1   337 _SAFE_MOD	=	0x00a1
                           0000B1   338 _GLOBAL_CFG	=	0x00b1
                           000087   339 _PCON	=	0x0087
                           0000BA   340 _POWER_CFG	=	0x00ba
                           0000B9   341 _CLOCK_CFG	=	0x00b9
                           0000A9   342 _WAKE_CTRL	=	0x00a9
                           0000FE   343 _RESET_KEEP	=	0x00fe
                           0000FF   344 _WDOG_COUNT	=	0x00ff
                           0000A8   345 _IE	=	0x00a8
                           0000B8   346 _IP	=	0x00b8
                           0000E8   347 _IE_EX	=	0x00e8
                           0000E9   348 _IP_EX	=	0x00e9
                           0000B2   349 _GPIO_IE	=	0x00b2
                           008584   350 _ROM_ADDR	=	0x8584
                           000084   351 _ROM_ADDR_L	=	0x0084
                           000085   352 _ROM_ADDR_H	=	0x0085
                           008F8E   353 _ROM_DATA_HI	=	0x8f8e
                           00008E   354 _ROM_DATA_HL	=	0x008e
                           00008F   355 _ROM_DATA_HH	=	0x008f
                           000086   356 _ROM_CTRL	=	0x0086
                           000080   357 _P0	=	0x0080
                           0000C4   358 _P0_MOD_OC	=	0x00c4
                           0000C5   359 _P0_DIR_PU	=	0x00c5
                           000090   360 _P1	=	0x0090
                           000092   361 _P1_MOD_OC	=	0x0092
                           000093   362 _P1_DIR_PU	=	0x0093
                           0000A0   363 _P2	=	0x00a0
                           000094   364 _P2_MOD_OC	=	0x0094
                           000095   365 _P2_DIR_PU	=	0x0095
                           0000B0   366 _P3	=	0x00b0
                           000096   367 _P3_MOD_OC	=	0x0096
                           000097   368 _P3_DIR_PU	=	0x0097
                           0000C0   369 _P4	=	0x00c0
                           0000C2   370 _P4_MOD_OC	=	0x00c2
                           0000C3   371 _P4_DIR_PU	=	0x00c3
                           0000C1   372 _P4_LED_KEY	=	0x00c1
                           0000AA   373 _P5_IN	=	0x00aa
                           0000AB   374 _P5_OUT_PU	=	0x00ab
                           0000AC   375 _P5_DIR	=	0x00ac
                           0000AD   376 _P6_IN	=	0x00ad
                           0000AE   377 _P6_OUT_PU	=	0x00ae
                           0000AF   378 _P6_DIR	=	0x00af
                           0000F1   379 _P7	=	0x00f1
                           0000A2   380 _XBUS_AUX	=	0x00a2
                           000088   381 _TCON	=	0x0088
                           000089   382 _TMOD	=	0x0089
                           00008A   383 _TL0	=	0x008a
                           00008B   384 _TL1	=	0x008b
                           00008C   385 _TH0	=	0x008c
                           00008D   386 _TH1	=	0x008d
                           000098   387 _SCON	=	0x0098
                           000099   388 _SBUF	=	0x0099
                           0000C8   389 _T2CON	=	0x00c8
                           0000C9   390 _T2MOD	=	0x00c9
                           00CBCA   391 _RCAP2	=	0xcbca
                           0000CA   392 _RCAP2L	=	0x00ca
                           0000CB   393 _RCAP2H	=	0x00cb
                           00CDCC   394 _T2COUNT	=	0xcdcc
                           0000CC   395 _TL2	=	0x00cc
                           0000CD   396 _TH2	=	0x00cd
                           00CFCE   397 _T2CAP1	=	0xcfce
                           0000CE   398 _T2CAP1L	=	0x00ce
                           0000CF   399 _T2CAP1H	=	0x00cf
                           0000F8   400 _SPI0_STAT	=	0x00f8
                           0000F9   401 _SPI0_DATA	=	0x00f9
                           0000FA   402 _SPI0_CTRL	=	0x00fa
                           0000FB   403 _SPI0_CK_SE	=	0x00fb
                           0000FC   404 _SPI0_SETUP	=	0x00fc
                           0000BC   405 _SCON1	=	0x00bc
                           0000BD   406 _SBUF1	=	0x00bd
                           0000BE   407 _SBAUD1	=	0x00be
                           0000BF   408 _SIF1	=	0x00bf
                           0000B4   409 _SPI1_STAT	=	0x00b4
                           0000B5   410 _SPI1_DATA	=	0x00b5
                           0000B6   411 _SPI1_CTRL	=	0x00b6
                           0000B7   412 _SPI1_CK_SE	=	0x00b7
                           0000F3   413 _ADC_CTRL	=	0x00f3
                           00F5F4   414 _ADC_DAT	=	0xf5f4
                           0000F4   415 _ADC_DAT_L	=	0x00f4
                           0000F5   416 _ADC_DAT_H	=	0x00f5
                           0000F6   417 _ADC_CHAN	=	0x00f6
                           0000A6   418 _LED_COMMON	=	0x00a6
                           0000A7   419 _LED_PWM_OE	=	0x00a7
                           00C7C6   420 _LED_DMA	=	0xc7c6
                           0000C6   421 _LED_DMA_L	=	0x00c6
                           0000C7   422 _LED_DMA_H	=	0x00c7
                           0000F7   423 _LED_STATUS	=	0x00f7
                           0000B3   424 _I2CX_INT	=	0x00b3
                           0000BB   425 _I2CS_INT_ST	=	0x00bb
                                    426 ;--------------------------------------------------------
                                    427 ; special function bits
                                    428 ;--------------------------------------------------------
                                    429 	.area RSEG    (ABS,DATA)
      000000                        430 	.org 0x0000
                           0000D7   431 _CY	=	0x00d7
                           0000D6   432 _AC	=	0x00d6
                           0000D5   433 _F0	=	0x00d5
                           0000D4   434 _RS1	=	0x00d4
                           0000D3   435 _RS0	=	0x00d3
                           0000D2   436 _OV	=	0x00d2
                           0000D1   437 _F1	=	0x00d1
                           0000D0   438 _P	=	0x00d0
                           0000AF   439 _EA	=	0x00af
                           0000AE   440 _E_DIS	=	0x00ae
                           0000AD   441 _ET2	=	0x00ad
                           0000AC   442 _ES	=	0x00ac
                           0000AB   443 _ET1	=	0x00ab
                           0000AA   444 _EX1	=	0x00aa
                           0000A9   445 _ET0	=	0x00a9
                           0000A8   446 _EX0	=	0x00a8
                           0000BF   447 _PH_FLAG	=	0x00bf
                           0000BE   448 _PL_FLAG	=	0x00be
                           0000BD   449 _PT2	=	0x00bd
                           0000BC   450 _PS	=	0x00bc
                           0000BB   451 _PT1	=	0x00bb
                           0000BA   452 _PX1	=	0x00ba
                           0000B9   453 _PT0	=	0x00b9
                           0000B8   454 _PX0	=	0x00b8
                           0000EF   455 _IE_WDOG	=	0x00ef
                           0000EE   456 _IE_GPIO	=	0x00ee
                           0000ED   457 _IE_PWM_I2C	=	0x00ed
                           0000EC   458 _IE_UART1	=	0x00ec
                           0000EB   459 _IE_ADC	=	0x00eb
                           0000E9   460 _IE_USB	=	0x00e9
                           0000E8   461 _IE_SPI0	=	0x00e8
                           000087   462 _P0_7	=	0x0087
                           000086   463 _P0_6	=	0x0086
                           000085   464 _P0_5	=	0x0085
                           000084   465 _P0_4	=	0x0084
                           000083   466 _P0_3	=	0x0083
                           000082   467 _P0_2	=	0x0082
                           000081   468 _P0_1	=	0x0081
                           000080   469 _P0_0	=	0x0080
                           000081   470 _SDA0	=	0x0081
                           000080   471 _SCL0	=	0x0080
                           000083   472 _TXD_	=	0x0083
                           000082   473 _RXD_	=	0x0082
                           000085   474 _AIN13	=	0x0085
                           000084   475 _AIN12	=	0x0084
                           000083   476 _AIN11	=	0x0083
                           000082   477 _AIN10	=	0x0082
                           000081   478 _AIN9	=	0x0081
                           000080   479 _AIN8	=	0x0080
                           000097   480 _P1_7	=	0x0097
                           000096   481 _P1_6	=	0x0096
                           000095   482 _P1_5	=	0x0095
                           000094   483 _P1_4	=	0x0094
                           000093   484 _P1_3	=	0x0093
                           000092   485 _P1_2	=	0x0092
                           000091   486 _P1_1	=	0x0091
                           000090   487 _P1_0	=	0x0090
                           000097   488 _TXD1_	=	0x0097
                           000096   489 _RXD1_	=	0x0096
                           000097   490 _SCK	=	0x0097
                           000096   491 _MISO	=	0x0096
                           000095   492 _MOSI	=	0x0095
                           000094   493 _SCS	=	0x0094
                           000092   494 _INT0_	=	0x0092
                           000091   495 _T2EX	=	0x0091
                           000091   496 _CAP2	=	0x0091
                           000090   497 _T2	=	0x0090
                           000090   498 _CAP1	=	0x0090
                           000097   499 _AIN7	=	0x0097
                           000096   500 _AIN6	=	0x0096
                           000095   501 _AIN5	=	0x0095
                           000094   502 _AIN4	=	0x0094
                           000093   503 _AIN3	=	0x0093
                           000092   504 _AIN2	=	0x0092
                           000091   505 _AIN1	=	0x0091
                           000090   506 _AIN0	=	0x0090
                           0000A7   507 _P2_7	=	0x00a7
                           0000A6   508 _P2_6	=	0x00a6
                           0000A5   509 _P2_5	=	0x00a5
                           0000A4   510 _P2_4	=	0x00a4
                           0000A3   511 _P2_3	=	0x00a3
                           0000A2   512 _P2_2	=	0x00a2
                           0000A1   513 _P2_1	=	0x00a1
                           0000A0   514 _P2_0	=	0x00a0
                           0000A7   515 _TXD1	=	0x00a7
                           0000A6   516 _RXD1	=	0x00a6
                           0000A5   517 _T2EX_	=	0x00a5
                           0000A5   518 _CAP2_	=	0x00a5
                           0000A4   519 _T2_	=	0x00a4
                           0000A4   520 _CAP1_	=	0x00a4
                           0000B7   521 _P3_7	=	0x00b7
                           0000B6   522 _P3_6	=	0x00b6
                           0000B5   523 _P3_5	=	0x00b5
                           0000B4   524 _P3_4	=	0x00b4
                           0000B3   525 _P3_3	=	0x00b3
                           0000B2   526 _P3_2	=	0x00b2
                           0000B1   527 _P3_1	=	0x00b1
                           0000B0   528 _P3_0	=	0x00b0
                           0000B7   529 _SCK1	=	0x00b7
                           0000B6   530 _MISO1	=	0x00b6
                           0000B5   531 _MOSI1	=	0x00b5
                           0000B5   532 _T1	=	0x00b5
                           0000B4   533 _T0	=	0x00b4
                           0000B3   534 _INT1	=	0x00b3
                           0000B2   535 _INT0	=	0x00b2
                           0000B1   536 _TXD	=	0x00b1
                           0000B0   537 _RXD	=	0x00b0
                           0000C6   538 _P4_6	=	0x00c6
                           0000C5   539 _P4_5	=	0x00c5
                           0000C4   540 _P4_4	=	0x00c4
                           0000C3   541 _P4_3	=	0x00c3
                           0000C2   542 _P4_2	=	0x00c2
                           0000C1   543 _P4_1	=	0x00c1
                           0000C0   544 _P4_0	=	0x00c0
                           00008F   545 _TF1	=	0x008f
                           00008E   546 _TR1	=	0x008e
                           00008D   547 _TF0	=	0x008d
                           00008C   548 _TR0	=	0x008c
                           00008B   549 _IE1	=	0x008b
                           00008A   550 _IT1	=	0x008a
                           000089   551 _IE0	=	0x0089
                           000088   552 _IT0	=	0x0088
                           00009F   553 _SM0	=	0x009f
                           00009E   554 _SM1	=	0x009e
                           00009D   555 _SM2	=	0x009d
                           00009C   556 _REN	=	0x009c
                           00009B   557 _TB8	=	0x009b
                           00009A   558 _RB8	=	0x009a
                           000099   559 _TI	=	0x0099
                           000098   560 _RI	=	0x0098
                           0000CF   561 _TF2	=	0x00cf
                           0000CF   562 _CAP1F	=	0x00cf
                           0000CE   563 _EXF2	=	0x00ce
                           0000CD   564 _RCLK	=	0x00cd
                           0000CC   565 _TCLK	=	0x00cc
                           0000CB   566 _EXEN2	=	0x00cb
                           0000CA   567 _TR2	=	0x00ca
                           0000C9   568 _C_T2	=	0x00c9
                           0000C8   569 _CP_RL2	=	0x00c8
                           0000FF   570 _S0_FST_ACT	=	0x00ff
                           0000FE   571 _S0_IF_OV	=	0x00fe
                           0000FD   572 _S0_IF_FIRST	=	0x00fd
                           0000FC   573 _S0_IF_BYTE	=	0x00fc
                           0000FB   574 _S0_FREE	=	0x00fb
                           0000FA   575 _S0_T_FIFO	=	0x00fa
                           0000F8   576 _S0_R_FIFO	=	0x00f8
                           0000F7   577 _ADC_START	=	0x00f7
                                    578 ;--------------------------------------------------------
                                    579 ; overlayable register banks
                                    580 ;--------------------------------------------------------
                                    581 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        582 	.ds 8
                                    583 ;--------------------------------------------------------
                                    584 ; internal ram data
                                    585 ;--------------------------------------------------------
                                    586 	.area DSEG    (DATA)
      000029                        587 _dynamic_keymap_set_encoder_sloc0_1_0:
      000029                        588 	.ds 2
      00002B                        589 _dynamic_keymap_get_combo_sloc0_1_0:
      00002B                        590 	.ds 1
      00002C                        591 _ak820_dynamic_read_buffer_sloc0_1_0:
      00002C                        592 	.ds 1
      00002D                        593 _dynamic_keymap_set_buffer_sloc0_1_0:
      00002D                        594 	.ds 2
      00002F                        595 _dynamic_keymap_set_buffer_sloc1_1_0:
      00002F                        596 	.ds 2
      000031                        597 _dynamic_keymap_set_buffer_sloc2_1_0:
      000031                        598 	.ds 1
      000032                        599 _dynamic_keymap_macro_get_buffer_sloc0_1_0:
      000032                        600 	.ds 2
                                    601 ;--------------------------------------------------------
                                    602 ; overlayable items in internal ram
                                    603 ;--------------------------------------------------------
                                    604 ;--------------------------------------------------------
                                    605 ; indirectly addressable internal ram data
                                    606 ;--------------------------------------------------------
                                    607 	.area ISEG    (DATA)
                                    608 ;--------------------------------------------------------
                                    609 ; absolute internal ram data
                                    610 ;--------------------------------------------------------
                                    611 	.area IABS    (ABS,DATA)
                                    612 	.area IABS    (ABS,DATA)
                                    613 ;--------------------------------------------------------
                                    614 ; bit data
                                    615 ;--------------------------------------------------------
                                    616 	.area BSEG    (BIT)
      000025                        617 _dynamic_keymap_macro_send_sloc0_1_0:
      000025                        618 	.ds 1
                                    619 ;--------------------------------------------------------
                                    620 ; paged external ram data
                                    621 ;--------------------------------------------------------
                                    622 	.area PSEG    (PAG,XDATA)
                                    623 ;--------------------------------------------------------
                                    624 ; uninitialized external ram data
                                    625 ;--------------------------------------------------------
                                    626 	.area XSEG    (XDATA)
      000B08                        627 _dynamic_keymap_key_to_eeprom_address_PARM_2:
      000B08                        628 	.ds 1
      000B09                        629 _dynamic_keymap_key_to_eeprom_address_PARM_3:
      000B09                        630 	.ds 1
      000B0A                        631 _dynamic_keymap_key_to_eeprom_address_layer_10000_366:
      000B0A                        632 	.ds 1
      000B0B                        633 _dynamic_keymap_get_keycode_PARM_2:
      000B0B                        634 	.ds 1
      000B0C                        635 _dynamic_keymap_get_keycode_PARM_3:
      000B0C                        636 	.ds 1
      000B0D                        637 _dynamic_keymap_get_keycode_layer_10000_368:
      000B0D                        638 	.ds 1
      000B0E                        639 _dynamic_keymap_set_keycode_PARM_2:
      000B0E                        640 	.ds 1
      000B0F                        641 _dynamic_keymap_set_keycode_PARM_3:
      000B0F                        642 	.ds 1
      000B10                        643 _dynamic_keymap_set_keycode_PARM_4:
      000B10                        644 	.ds 2
      000B12                        645 _dynamic_keymap_set_keycode_layer_10000_372:
      000B12                        646 	.ds 1
      000B13                        647 _dynamic_keymap_encoder_to_eeprom_address_PARM_2:
      000B13                        648 	.ds 1
      000B14                        649 _dynamic_keymap_encoder_to_eeprom_address_layer_10000_376:
      000B14                        650 	.ds 1
      000B15                        651 _dynamic_keymap_get_encoder_PARM_2:
      000B15                        652 	.ds 1
      000B16                        653 _dynamic_keymap_get_encoder_PARM_3:
      000B16                        654 	.ds 1
      000B17                        655 _dynamic_keymap_get_encoder_layer_10000_378:
      000B17                        656 	.ds 1
      000B18                        657 _dynamic_keymap_set_encoder_PARM_2:
      000B18                        658 	.ds 1
      000B19                        659 _dynamic_keymap_set_encoder_PARM_3:
      000B19                        660 	.ds 1
      000B1A                        661 _dynamic_keymap_set_encoder_PARM_4:
      000B1A                        662 	.ds 2
      000B1C                        663 _dynamic_keymap_set_encoder_layer_10000_382:
      000B1C                        664 	.ds 1
      000B1D                        665 _dynamic_keymap_get_combo_PARM_2:
      000B1D                        666 	.ds 3
      000B20                        667 _dynamic_keymap_get_combo_index_10000_386:
      000B20                        668 	.ds 1
      000B21                        669 _dynamic_keymap_set_combo_PARM_2:
      000B21                        670 	.ds 3
      000B24                        671 _dynamic_keymap_set_combo_index_10000_392:
      000B24                        672 	.ds 1
      000B25                        673 _dynamic_keymap_set_combo_stored_10002_397:
      000B25                        674 	.ds 10
      000B2F                        675 _dynamic_keymap_reset_vial_unlocked_prev_10000_400:
      000B2F                        676 	.ds 1
      000B30                        677 _dynamic_keymap_reset_combo_10001_409:
      000B30                        678 	.ds 10
      000B3A                        679 _ak820_dynamic_read_buffer_PARM_2:
      000B3A                        680 	.ds 2
      000B3C                        681 _ak820_dynamic_read_buffer_PARM_3:
      000B3C                        682 	.ds 2
      000B3E                        683 _ak820_dynamic_read_buffer_PARM_4:
      000B3E                        684 	.ds 2
      000B40                        685 _ak820_dynamic_read_buffer_PARM_5:
      000B40                        686 	.ds 3
      000B43                        687 _ak820_dynamic_read_buffer_base_10000_411:
      000B43                        688 	.ds 2
      000B45                        689 _ak820_dynamic_read_buffer_available_10000_412:
      000B45                        690 	.ds 1
      000B46                        691 _dynamic_keymap_get_buffer_PARM_2:
      000B46                        692 	.ds 2
      000B48                        693 _dynamic_keymap_get_buffer_PARM_3:
      000B48                        694 	.ds 3
      000B4B                        695 _dynamic_keymap_get_buffer_offset_10000_418:
      000B4B                        696 	.ds 2
      000B4D                        697 _dynamic_keymap_set_buffer_PARM_2:
      000B4D                        698 	.ds 2
      000B4F                        699 _dynamic_keymap_set_buffer_PARM_3:
      000B4F                        700 	.ds 3
      000B52                        701 _dynamic_keymap_set_buffer_offset_10000_420:
      000B52                        702 	.ds 2
      000B54                        703 _dynamic_keymap_set_buffer_chk_offset_30001_427:
      000B54                        704 	.ds 1
      000B55                        705 _dynamic_keymap_set_buffer_chk_sz_30001_427:
      000B55                        706 	.ds 1
      000B56                        707 _dynamic_keymap_set_buffer_i_40001_434:
      000B56                        708 	.ds 1
      000B57                        709 _keycode_at_keymap_location_PARM_2:
      000B57                        710 	.ds 1
      000B58                        711 _keycode_at_keymap_location_PARM_3:
      000B58                        712 	.ds 1
      000B59                        713 _keycode_at_keymap_location_layer_num_10000_438:
      000B59                        714 	.ds 1
      000B5A                        715 _keycode_at_encodermap_location_PARM_2:
      000B5A                        716 	.ds 1
      000B5B                        717 _keycode_at_encodermap_location_PARM_3:
      000B5B                        718 	.ds 1
      000B5C                        719 _keycode_at_encodermap_location_layer_num_10000_442:
      000B5C                        720 	.ds 1
      000B5D                        721 _dynamic_keymap_macro_get_buffer_PARM_2:
      000B5D                        722 	.ds 2
      000B5F                        723 _dynamic_keymap_macro_get_buffer_PARM_3:
      000B5F                        724 	.ds 3
      000B62                        725 _dynamic_keymap_macro_get_buffer_offset_10000_450:
      000B62                        726 	.ds 2
      000B64                        727 _dynamic_keymap_macro_set_buffer_PARM_2:
      000B64                        728 	.ds 2
      000B66                        729 _dynamic_keymap_macro_set_buffer_PARM_3:
      000B66                        730 	.ds 3
      000B69                        731 _dynamic_keymap_macro_set_buffer_offset_10000_452:
      000B69                        732 	.ds 2
      000B6B                        733 _decode_keycode_kc_10000_456:
      000B6B                        734 	.ds 2
      000B6D                        735 _dynamic_keymap_macro_send_id_10000_459:
      000B6D                        736 	.ds 1
      000B6E                        737 _dynamic_keymap_macro_send_sending_10000_460:
      000B6E                        738 	.ds 1
      000B6F                        739 _dynamic_keymap_macro_send_p_10001_465:
      000B6F                        740 	.ds 2
      000B71                        741 _dynamic_keymap_macro_send_data_10003_472:
      000B71                        742 	.ds 4
                                    743 ;--------------------------------------------------------
                                    744 ; absolute external ram data
                                    745 ;--------------------------------------------------------
                                    746 	.area XABS    (ABS,XDATA)
                                    747 ;--------------------------------------------------------
                                    748 ; initialized external ram data
                                    749 ;--------------------------------------------------------
                                    750 	.area XISEG   (XDATA)
                                    751 	.area HOME    (CODE)
                                    752 	.area GSINIT0 (CODE)
                                    753 	.area GSINIT1 (CODE)
                                    754 	.area GSINIT2 (CODE)
                                    755 	.area GSINIT3 (CODE)
                                    756 	.area GSINIT4 (CODE)
                                    757 	.area GSINIT5 (CODE)
                                    758 	.area GSINIT  (CODE)
                                    759 	.area GSFINAL (CODE)
                                    760 	.area CSEG    (CODE)
                                    761 ;--------------------------------------------------------
                                    762 ; global & static initialisations
                                    763 ;--------------------------------------------------------
                                    764 	.area HOME    (CODE)
                                    765 	.area GSINIT  (CODE)
                                    766 	.area GSFINAL (CODE)
                                    767 	.area GSINIT  (CODE)
                                    768 ;--------------------------------------------------------
                                    769 ; Home
                                    770 ;--------------------------------------------------------
                                    771 	.area HOME    (CODE)
                                    772 	.area HOME    (CODE)
                                    773 ;--------------------------------------------------------
                                    774 ; code
                                    775 ;--------------------------------------------------------
                                    776 	.area CSEG    (CODE)
                                    777 ;------------------------------------------------------------
                                    778 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    779 ;------------------------------------------------------------
                                    780 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_230'
                                    781 ;------------------------------------------------------------
                                    782 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    783 ;	-----------------------------------------
                           000007   784 	ar7 = 0x07
                           000006   785 	ar6 = 0x06
                           000005   786 	ar5 = 0x05
                           000004   787 	ar4 = 0x04
                           000003   788 	ar3 = 0x03
                           000002   789 	ar2 = 0x02
                           000001   790 	ar1 = 0x01
                           000000   791 	ar0 = 0x00
                                    792 ;	 function dynamic_keymap_get_layer_count
                                    793 ;	-----------------------------------------
      008A1A                        794 _dynamic_keymap_get_layer_count:
                                    795 ;	quantum/dynamic_keymap.c:200: return DYNAMIC_KEYMAP_LAYER_COUNT;
      008A1A 75 82 06         [24]  796 	mov	dpl, #0x06
                                    797 ;	quantum/dynamic_keymap.c:201: }
      008A1D 22               [24]  798 	ret
                                    799 ;------------------------------------------------------------
                                    800 ;Allocation info for local variables in function 'dynamic_keymap_key_to_eeprom_address'
                                    801 ;------------------------------------------------------------
                                    802 ;row           Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_2'
                                    803 ;column        Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_3'
                                    804 ;layer         Allocated with name '_dynamic_keymap_key_to_eeprom_address_layer_10000_366'
                                    805 ;------------------------------------------------------------
                                    806 ;	quantum/dynamic_keymap.c:203: void *dynamic_keymap_key_to_eeprom_address(uint8_t layer, uint8_t row, uint8_t column) {
                                    807 ;	-----------------------------------------
                                    808 ;	 function dynamic_keymap_key_to_eeprom_address
                                    809 ;	-----------------------------------------
      008A1E                        810 _dynamic_keymap_key_to_eeprom_address:
      008A1E E5 82            [12]  811 	mov	a,dpl
      008A20 90 0B 0A         [24]  812 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_layer_10000_366
      008A23 F0               [24]  813 	movx	@dptr,a
                                    814 ;	quantum/dynamic_keymap.c:205: return ((uint8_t *)DYNAMIC_KEYMAP_EEPROM_ADDR) + (layer * MATRIX_ROWS * MATRIX_COLS * 2) + (row * MATRIX_COLS * 2) + (column * 2);
      008A24 E0               [24]  815 	movx	a,@dptr
      008A25 FF               [12]  816 	mov	r7,a
      008A26 7E 00            [12]  817 	mov	r6,#0x00
      008A28 74 40            [12]  818 	mov	a,#0x40
      008A2A 12 45 D9         [24]  819 	lcall	_ak820_outline_0134
      008A2D 7D 00            [12]  820 	mov	r5,#0x00
      008A2F 90 0B 08         [24]  821 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      008A32 E0               [24]  822 	movx	a,@dptr
      008A33 75 F0 10         [24]  823 	mov	b,#0x10
      008A36 A4               [48]  824 	mul	ab
      008A37 2E               [12]  825 	add	a, r6
      008A38 FE               [12]  826 	mov	r6,a
      008A39 EF               [12]  827 	mov	a,r7
      008A3A 35 F0            [12]  828 	addc	a, b
      008A3C FF               [12]  829 	mov	r7,a
      008A3D 90 0B 09         [24]  830 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      008A40 E0               [24]  831 	movx	a,@dptr
      008A41 7C 00            [12]  832 	mov	r4,#0x00
      008A43 25 E0            [12]  833 	add	a,acc
      008A45 FB               [12]  834 	mov	r3,a
      008A46 EC               [12]  835 	mov	a,r4
      008A47 33               [12]  836 	rlc	a
      008A48 FC               [12]  837 	mov	r4,a
      008A49 EB               [12]  838 	mov	a,r3
      008A4A 2E               [12]  839 	add	a, r6
      008A4B FE               [12]  840 	mov	r6,a
      008A4C EC               [12]  841 	mov	a,r4
      008A4D 3F               [12]  842 	addc	a, r7
      008A4E FF               [12]  843 	mov	r7,a
      008A4F 12 45 C9         [24]  844 	lcall	_ak820_outline_0116
      008A52 8D F0            [24]  845 	mov	b, r5
                                    846 ;	quantum/dynamic_keymap.c:206: }
      008A54 22               [24]  847 	ret
                                    848 ;------------------------------------------------------------
                                    849 ;Allocation info for local variables in function 'dynamic_keymap_get_keycode'
                                    850 ;------------------------------------------------------------
                                    851 ;row           Allocated with name '_dynamic_keymap_get_keycode_PARM_2'
                                    852 ;column        Allocated with name '_dynamic_keymap_get_keycode_PARM_3'
                                    853 ;layer         Allocated with name '_dynamic_keymap_get_keycode_layer_10000_368'
                                    854 ;address       Allocated with name '_dynamic_keymap_get_keycode_address_10001_371'
                                    855 ;keycode       Allocated with name '_dynamic_keymap_get_keycode_keycode_10001_371'
                                    856 ;------------------------------------------------------------
                                    857 ;	quantum/dynamic_keymap.c:208: uint16_t dynamic_keymap_get_keycode(uint8_t layer, uint8_t row, uint8_t column) {
                                    858 ;	-----------------------------------------
                                    859 ;	 function dynamic_keymap_get_keycode
                                    860 ;	-----------------------------------------
      008A55                        861 _dynamic_keymap_get_keycode:
      008A55 E5 82            [12]  862 	mov	a,dpl
      008A57 90 0B 0D         [24]  863 	mov	dptr,#_dynamic_keymap_get_keycode_layer_10000_368
      008A5A F0               [24]  864 	movx	@dptr,a
                                    865 ;	quantum/dynamic_keymap.c:209: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return KC_NO;
      008A5B E0               [24]  866 	movx	a,@dptr
      008A5C FF               [12]  867 	mov	r7,a
      008A5D BF 06 00         [24]  868 	cjne	r7,#0x06,00121$
      008A60                        869 00121$:
      008A60 50 14            [24]  870 	jnc	00101$
      008A62 90 0B 0B         [24]  871 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      008A65 E0               [24]  872 	movx	a,@dptr
      008A66 FE               [12]  873 	mov	r6,a
      008A67 BE 10 00         [24]  874 	cjne	r6,#0x10,00123$
      008A6A                        875 00123$:
      008A6A 50 0A            [24]  876 	jnc	00101$
      008A6C 90 0B 0C         [24]  877 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      008A6F E0               [24]  878 	movx	a,@dptr
      008A70 FD               [12]  879 	mov	r5,a
      008A71 BD 08 00         [24]  880 	cjne	r5,#0x08,00125$
      008A74                        881 00125$:
      008A74 40 04            [24]  882 	jc	00102$
      008A76                        883 00101$:
      008A76 90 00 00         [24]  884 	mov	dptr,#0x0000
      008A79 22               [24]  885 	ret
      008A7A                        886 00102$:
                                    887 ;	quantum/dynamic_keymap.c:210: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      008A7A 12 94 AF         [24]  888 	lcall	_ak820_outline_0095
      008A7D 51 1E            [12]  889 	acall	_dynamic_keymap_key_to_eeprom_address
                                    890 ;	quantum/dynamic_keymap.c:212: uint16_t keycode = eeprom_read_byte(address) << 8;
      008A7F 12 94 BC         [24]  891 	lcall	_ak820_outline_0112
      008A82 12 42 E8         [24]  892 	lcall	_eeprom_read_byte
      008A85 AB 82            [24]  893 	mov	r3,dpl
      008A87 7C 00            [12]  894 	mov	r4,#0x00
                                    895 ;	quantum/dynamic_keymap.c:213: keycode |= eeprom_read_byte(address + 1);
      008A89 0D               [12]  896 	inc	r5
      008A8A BD 00 01         [24]  897 	cjne	r5,#0x00,00127$
      008A8D 0E               [12]  898 	inc	r6
      008A8E                        899 00127$:
      008A8E 12 52 45         [24]  900 	lcall	_ak820_outline_0044
      008A91 12 42 E8         [24]  901 	lcall	_eeprom_read_byte
      008A94 AF 82            [24]  902 	mov	r7, dpl
      008A96 7E 00            [12]  903 	mov	r6,#0x00
      008A98 EF               [12]  904 	mov	a,r7
      008A99 42 04            [12]  905 	orl	ar4,a
      008A9B EE               [12]  906 	mov	a,r6
      008A9C 42 03            [12]  907 	orl	ar3,a
                                    908 ;	quantum/dynamic_keymap.c:214: return keycode;
      008A9E 12 46 05         [24]  909 	lcall	_ak820_outline_0180
                                    910 ;	quantum/dynamic_keymap.c:215: }
      008AA1 22               [24]  911 	ret
                                    912 ;------------------------------------------------------------
                                    913 ;Allocation info for local variables in function 'dynamic_keymap_set_keycode'
                                    914 ;------------------------------------------------------------
                                    915 ;row           Allocated with name '_dynamic_keymap_set_keycode_PARM_2'
                                    916 ;column        Allocated with name '_dynamic_keymap_set_keycode_PARM_3'
                                    917 ;keycode       Allocated with name '_dynamic_keymap_set_keycode_PARM_4'
                                    918 ;layer         Allocated with name '_dynamic_keymap_set_keycode_layer_10000_372'
                                    919 ;address       Allocated with name '_dynamic_keymap_set_keycode_address_10001_375'
                                    920 ;------------------------------------------------------------
                                    921 ;	quantum/dynamic_keymap.c:217: void dynamic_keymap_set_keycode(uint8_t layer, uint8_t row, uint8_t column, uint16_t keycode) {
                                    922 ;	-----------------------------------------
                                    923 ;	 function dynamic_keymap_set_keycode
                                    924 ;	-----------------------------------------
      008AA2                        925 _dynamic_keymap_set_keycode:
      008AA2 E5 82            [12]  926 	mov	a,dpl
      008AA4 90 0B 12         [24]  927 	mov	dptr,#_dynamic_keymap_set_keycode_layer_10000_372
      008AA7 F0               [24]  928 	movx	@dptr,a
                                    929 ;	quantum/dynamic_keymap.c:218: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return;
      008AA8 E0               [24]  930 	movx	a,@dptr
      008AA9 FF               [12]  931 	mov	r7,a
      008AAA BF 06 00         [24]  932 	cjne	r7,#0x06,00121$
      008AAD                        933 00121$:
      008AAD 50 14            [24]  934 	jnc	00101$
      008AAF 90 0B 0E         [24]  935 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      008AB2 E0               [24]  936 	movx	a,@dptr
      008AB3 FE               [12]  937 	mov	r6,a
      008AB4 BE 10 00         [24]  938 	cjne	r6,#0x10,00123$
      008AB7                        939 00123$:
      008AB7 50 0A            [24]  940 	jnc	00101$
      008AB9 90 0B 0F         [24]  941 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      008ABC E0               [24]  942 	movx	a,@dptr
      008ABD FD               [12]  943 	mov	r5,a
      008ABE BD 08 00         [24]  944 	cjne	r5,#0x08,00125$
      008AC1                        945 00125$:
      008AC1 40 01            [24]  946 	jc	00102$
      008AC3                        947 00101$:
      008AC3 22               [24]  948 	ret
      008AC4                        949 00102$:
                                    950 ;	quantum/dynamic_keymap.c:219: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      008AC4 12 94 AF         [24]  951 	lcall	_ak820_outline_0095
      008AC7 51 1E            [12]  952 	acall	_dynamic_keymap_key_to_eeprom_address
      008AC9 12 94 BC         [24]  953 	lcall	_ak820_outline_0112
                                    954 ;	quantum/dynamic_keymap.c:221: eeprom_update_byte(address, (uint8_t)(keycode >> 8));
      008ACC 90 0B 10         [24]  955 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      008ACF E0               [24]  956 	movx	a,@dptr
      008AD0 FB               [12]  957 	mov	r3,a
      008AD1 A3               [24]  958 	inc	dptr
      008AD2 E0               [24]  959 	movx	a,@dptr
      008AD3 90 06 B2         [24]  960 	mov	dptr,#_eeprom_update_byte_PARM_2
      008AD6 F0               [24]  961 	movx	@dptr,a
      008AD7 12 52 45         [24]  962 	lcall	_ak820_outline_0044
      008ADA 12 51 2F         [24]  963 	lcall	_eeprom_update_byte
                                    964 ;	quantum/dynamic_keymap.c:222: eeprom_update_byte(address + 1, (uint8_t)(keycode & 0xFF));
      008ADD 0D               [12]  965 	inc	r5
      008ADE BD 00 01         [24]  966 	cjne	r5,#0x00,00127$
      008AE1 0E               [12]  967 	inc	r6
      008AE2                        968 00127$:
      008AE2 90 06 B2         [24]  969 	mov	dptr,#_eeprom_update_byte_PARM_2
      008AE5 EB               [12]  970 	mov	a,r3
      008AE6 F0               [24]  971 	movx	@dptr,a
      008AE7 12 52 45         [24]  972 	lcall	_ak820_outline_0044
                                    973 ;	quantum/dynamic_keymap.c:223: }
      008AEA 02 51 2F         [24]  974 	ljmp	_eeprom_update_byte
                                    975 ;------------------------------------------------------------
                                    976 ;Allocation info for local variables in function 'dynamic_keymap_encoder_to_eeprom_address'
                                    977 ;------------------------------------------------------------
                                    978 ;encoder_id    Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_PARM_2'
                                    979 ;layer         Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_layer_10000_376'
                                    980 ;------------------------------------------------------------
                                    981 ;	quantum/dynamic_keymap.c:226: void *dynamic_keymap_encoder_to_eeprom_address(uint8_t layer, uint8_t encoder_id) {
                                    982 ;	-----------------------------------------
                                    983 ;	 function dynamic_keymap_encoder_to_eeprom_address
                                    984 ;	-----------------------------------------
      008AED                        985 _dynamic_keymap_encoder_to_eeprom_address:
      008AED E5 82            [12]  986 	mov	a,dpl
      008AEF 90 0B 14         [24]  987 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_layer_10000_376
      008AF2 F0               [24]  988 	movx	@dptr,a
                                    989 ;	quantum/dynamic_keymap.c:227: return ((uint8_t *)DYNAMIC_KEYMAP_ENCODER_EEPROM_ADDR) + (layer * NUM_ENCODERS * 2 * 2) + (encoder_id * 2 * 2);
      008AF3 E0               [24]  990 	movx	a,@dptr
      008AF4 75 F0 04         [24]  991 	mov	b,#0x04
      008AF7 A4               [48]  992 	mul	ab
      008AF8 24 40            [12]  993 	add	a, #0x40
      008AFA FD               [12]  994 	mov	r5,a
      008AFB 74 06            [12]  995 	mov	a,#0x06
      008AFD 35 F0            [12]  996 	addc	a, b
      008AFF FE               [12]  997 	mov	r6,a
      008B00 7F 00            [12]  998 	mov	r7,#0x00
      008B02 90 0B 13         [24]  999 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      008B05 E0               [24] 1000 	movx	a,@dptr
      008B06 75 F0 04         [24] 1001 	mov	b,#0x04
      008B09 A4               [48] 1002 	mul	ab
      008B0A 2D               [12] 1003 	add	a, r5
      008B0B FD               [12] 1004 	mov	r5,a
      008B0C EE               [12] 1005 	mov	a,r6
      008B0D 35 F0            [12] 1006 	addc	a, b
      008B0F FE               [12] 1007 	mov	r6,a
      008B10 12 52 45         [24] 1008 	lcall	_ak820_outline_0044
                                   1009 ;	quantum/dynamic_keymap.c:228: }
      008B13 22               [24] 1010 	ret
                                   1011 ;------------------------------------------------------------
                                   1012 ;Allocation info for local variables in function 'dynamic_keymap_get_encoder'
                                   1013 ;------------------------------------------------------------
                                   1014 ;encoder_id    Allocated with name '_dynamic_keymap_get_encoder_PARM_2'
                                   1015 ;clockwise     Allocated with name '_dynamic_keymap_get_encoder_PARM_3'
                                   1016 ;layer         Allocated with name '_dynamic_keymap_get_encoder_layer_10000_378'
                                   1017 ;address       Allocated with name '_dynamic_keymap_get_encoder_address_10001_381'
                                   1018 ;keycode       Allocated with name '_dynamic_keymap_get_encoder_keycode_10001_381'
                                   1019 ;------------------------------------------------------------
                                   1020 ;	quantum/dynamic_keymap.c:230: uint16_t dynamic_keymap_get_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise) {
                                   1021 ;	-----------------------------------------
                                   1022 ;	 function dynamic_keymap_get_encoder
                                   1023 ;	-----------------------------------------
      008B14                       1024 _dynamic_keymap_get_encoder:
      008B14 E5 82            [12] 1025 	mov	a,dpl
      008B16 90 0B 17         [24] 1026 	mov	dptr,#_dynamic_keymap_get_encoder_layer_10000_378
      008B19 F0               [24] 1027 	movx	@dptr,a
                                   1028 ;	quantum/dynamic_keymap.c:231: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return KC_NO;
      008B1A E0               [24] 1029 	movx	a,@dptr
      008B1B FF               [12] 1030 	mov	r7,a
      008B1C BF 06 00         [24] 1031 	cjne	r7,#0x06,00131$
      008B1F                       1032 00131$:
      008B1F 50 0A            [24] 1033 	jnc	00101$
      008B21 90 0B 15         [24] 1034 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      008B24 E0               [24] 1035 	movx	a,@dptr
      008B25 FE               [12] 1036 	mov	r6,a
      008B26 BE 01 00         [24] 1037 	cjne	r6,#0x01,00133$
      008B29                       1038 00133$:
      008B29 40 04            [24] 1039 	jc	00102$
      008B2B                       1040 00101$:
      008B2B 90 00 00         [24] 1041 	mov	dptr,#0x0000
      008B2E 22               [24] 1042 	ret
      008B2F                       1043 00102$:
                                   1044 ;	quantum/dynamic_keymap.c:232: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      008B2F 90 0B 13         [24] 1045 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      008B32 12 7D A9         [24] 1046 	lcall	_ak820_outline_0184
      008B35 51 ED            [12] 1047 	acall	_dynamic_keymap_encoder_to_eeprom_address
      008B37 12 94 BC         [24] 1048 	lcall	_ak820_outline_0112
                                   1049 ;	quantum/dynamic_keymap.c:234: uint16_t keycode = ((uint16_t)eeprom_read_byte(address + (clockwise ? 0 : 2))) << 8;
      008B3A 90 0B 16         [24] 1050 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      008B3D E0               [24] 1051 	movx	a,@dptr
      008B3E FC               [12] 1052 	mov	r4,a
      008B3F E0               [24] 1053 	movx	a,@dptr
      008B40 60 04            [24] 1054 	jz	00106$
      008B42 7B 00            [12] 1055 	mov	r3,#0x00
      008B44 80 02            [24] 1056 	sjmp	00107$
      008B46                       1057 00106$:
      008B46 7B 02            [12] 1058 	mov	r3,#0x02
      008B48                       1059 00107$:
      008B48 EB               [12] 1060 	mov	a,r3
      008B49 12 94 8D         [24] 1061 	lcall	_ak820_outline_0025
      008B4C 12 42 E8         [24] 1062 	lcall	_eeprom_read_byte
      008B4F AA 82            [24] 1063 	mov	r2,dpl
      008B51 7B 00            [12] 1064 	mov	r3,#0x00
                                   1065 ;	quantum/dynamic_keymap.c:235: keycode |= eeprom_read_byte(address + (clockwise ? 0 : 2) + 1);
      008B53 EC               [12] 1066 	mov	a,r4
      008B54 60 04            [24] 1067 	jz	00108$
      008B56 7C 00            [12] 1068 	mov	r4,#0x00
      008B58 80 02            [24] 1069 	sjmp	00109$
      008B5A                       1070 00108$:
      008B5A 7C 02            [12] 1071 	mov	r4,#0x02
      008B5C                       1072 00109$:
      008B5C EC               [12] 1073 	mov	a,r4
      008B5D 12 3A BA         [24] 1074 	lcall	_ak820_outline_0157
      008B60 0D               [12] 1075 	inc	r5
      008B61 BD 00 01         [24] 1076 	cjne	r5,#0x00,00137$
      008B64 0E               [12] 1077 	inc	r6
      008B65                       1078 00137$:
      008B65 12 52 45         [24] 1079 	lcall	_ak820_outline_0044
      008B68 12 42 E8         [24] 1080 	lcall	_eeprom_read_byte
      008B6B AF 82            [24] 1081 	mov	r7, dpl
      008B6D 7E 00            [12] 1082 	mov	r6,#0x00
      008B6F EF               [12] 1083 	mov	a,r7
      008B70 42 03            [12] 1084 	orl	ar3,a
      008B72 EE               [12] 1085 	mov	a,r6
      008B73 42 02            [12] 1086 	orl	ar2,a
                                   1087 ;	quantum/dynamic_keymap.c:236: return keycode;
      008B75 8B 82            [24] 1088 	mov	dpl, r3
      008B77 8A 83            [24] 1089 	mov	dph, r2
                                   1090 ;	quantum/dynamic_keymap.c:237: }
      008B79 22               [24] 1091 	ret
                                   1092 ;------------------------------------------------------------
                                   1093 ;Allocation info for local variables in function 'dynamic_keymap_set_encoder'
                                   1094 ;------------------------------------------------------------
                                   1095 ;sloc0         Allocated with name '_dynamic_keymap_set_encoder_sloc0_1_0'
                                   1096 ;encoder_id    Allocated with name '_dynamic_keymap_set_encoder_PARM_2'
                                   1097 ;clockwise     Allocated with name '_dynamic_keymap_set_encoder_PARM_3'
                                   1098 ;keycode       Allocated with name '_dynamic_keymap_set_encoder_PARM_4'
                                   1099 ;layer         Allocated with name '_dynamic_keymap_set_encoder_layer_10000_382'
                                   1100 ;address       Allocated with name '_dynamic_keymap_set_encoder_address_10001_385'
                                   1101 ;------------------------------------------------------------
                                   1102 ;	quantum/dynamic_keymap.c:239: void dynamic_keymap_set_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise, uint16_t keycode) {
                                   1103 ;	-----------------------------------------
                                   1104 ;	 function dynamic_keymap_set_encoder
                                   1105 ;	-----------------------------------------
      008B7A                       1106 _dynamic_keymap_set_encoder:
      008B7A E5 82            [12] 1107 	mov	a,dpl
      008B7C 90 0B 1C         [24] 1108 	mov	dptr,#_dynamic_keymap_set_encoder_layer_10000_382
      008B7F F0               [24] 1109 	movx	@dptr,a
                                   1110 ;	quantum/dynamic_keymap.c:240: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return;
      008B80 E0               [24] 1111 	movx	a,@dptr
      008B81 FF               [12] 1112 	mov	r7,a
      008B82 BF 06 00         [24] 1113 	cjne	r7,#0x06,00131$
      008B85                       1114 00131$:
      008B85 50 0A            [24] 1115 	jnc	00101$
      008B87 90 0B 18         [24] 1116 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      008B8A E0               [24] 1117 	movx	a,@dptr
      008B8B FE               [12] 1118 	mov	r6,a
      008B8C BE 01 00         [24] 1119 	cjne	r6,#0x01,00133$
      008B8F                       1120 00133$:
      008B8F 40 01            [24] 1121 	jc	00102$
      008B91                       1122 00101$:
      008B91 22               [24] 1123 	ret
      008B92                       1124 00102$:
                                   1125 ;	quantum/dynamic_keymap.c:241: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      008B92 90 0B 13         [24] 1126 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      008B95 12 7D A9         [24] 1127 	lcall	_ak820_outline_0184
      008B98 51 ED            [12] 1128 	acall	_dynamic_keymap_encoder_to_eeprom_address
      008B9A 12 94 BC         [24] 1129 	lcall	_ak820_outline_0112
                                   1130 ;	quantum/dynamic_keymap.c:243: eeprom_update_byte(address + (clockwise ? 0 : 2), (uint8_t)(keycode >> 8));
      008B9D 90 0B 19         [24] 1131 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      008BA0 E0               [24] 1132 	movx	a,@dptr
      008BA1 FC               [12] 1133 	mov	r4,a
      008BA2 E0               [24] 1134 	movx	a,@dptr
      008BA3 60 04            [24] 1135 	jz	00106$
      008BA5 7B 00            [12] 1136 	mov	r3,#0x00
      008BA7 80 02            [24] 1137 	sjmp	00107$
      008BA9                       1138 00106$:
      008BA9 7B 02            [12] 1139 	mov	r3,#0x02
      008BAB                       1140 00107$:
      008BAB EB               [12] 1141 	mov	a,r3
      008BAC 12 94 CE         [24] 1142 	lcall	_ak820_outline_0133
      008BAF 8F 03            [24] 1143 	mov	ar3,r7
      008BB1 90 0B 1A         [24] 1144 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008BB4 E0               [24] 1145 	movx	a,@dptr
      008BB5 F5 29            [12] 1146 	mov	_dynamic_keymap_set_encoder_sloc0_1_0,a
      008BB7 A3               [24] 1147 	inc	dptr
      008BB8 E0               [24] 1148 	movx	a,@dptr
      008BB9 F5 2A            [12] 1149 	mov	(_dynamic_keymap_set_encoder_sloc0_1_0 + 1),a
      008BBB 90 06 B2         [24] 1150 	mov	dptr,#_eeprom_update_byte_PARM_2
      008BBE F0               [24] 1151 	movx	@dptr,a
      008BBF 12 46 00         [24] 1152 	lcall	_ak820_outline_0179
      008BC2 8B F0            [24] 1153 	mov	b, r3
      008BC4 12 51 2F         [24] 1154 	lcall	_eeprom_update_byte
                                   1155 ;	quantum/dynamic_keymap.c:244: eeprom_update_byte(address + (clockwise ? 0 : 2) + 1, (uint8_t)(keycode & 0xFF));
      008BC7 EC               [12] 1156 	mov	a,r4
      008BC8 60 04            [24] 1157 	jz	00108$
      008BCA 7C 00            [12] 1158 	mov	r4,#0x00
      008BCC 80 02            [24] 1159 	sjmp	00109$
      008BCE                       1160 00108$:
      008BCE 7C 02            [12] 1161 	mov	r4,#0x02
      008BD0                       1162 00109$:
      008BD0 EC               [12] 1163 	mov	a,r4
      008BD1 12 3A BA         [24] 1164 	lcall	_ak820_outline_0157
      008BD4 0D               [12] 1165 	inc	r5
      008BD5 BD 00 01         [24] 1166 	cjne	r5,#0x00,00137$
      008BD8 0E               [12] 1167 	inc	r6
      008BD9                       1168 00137$:
      008BD9 90 06 B2         [24] 1169 	mov	dptr,#_eeprom_update_byte_PARM_2
      008BDC E5 29            [12] 1170 	mov	a,_dynamic_keymap_set_encoder_sloc0_1_0
      008BDE F0               [24] 1171 	movx	@dptr,a
      008BDF 12 52 45         [24] 1172 	lcall	_ak820_outline_0044
                                   1173 ;	quantum/dynamic_keymap.c:245: }
      008BE2 02 51 2F         [24] 1174 	ljmp	_eeprom_update_byte
                                   1175 ;------------------------------------------------------------
                                   1176 ;Allocation info for local variables in function 'dynamic_keymap_get_combo'
                                   1177 ;------------------------------------------------------------
                                   1178 ;sloc0         Allocated with name '_dynamic_keymap_get_combo_sloc0_1_0'
                                   1179 ;buffer        Allocated with name '_dynamic_keymap_get_combo_PARM_2'
                                   1180 ;index         Allocated with name '_dynamic_keymap_get_combo_index_10000_386'
                                   1181 ;entry         Allocated with name '_dynamic_keymap_get_combo_entry_10000_387'
                                   1182 ;address       Allocated with name '_dynamic_keymap_get_combo_address_10001_389'
                                   1183 ;marked        Allocated with name '_dynamic_keymap_get_combo_marked_10002_390'
                                   1184 ;------------------------------------------------------------
                                   1185 ;	quantum/dynamic_keymap.c:307: int dynamic_keymap_get_combo(uint8_t index, vial_combo_entry_t *buffer) {
                                   1186 ;	-----------------------------------------
                                   1187 ;	 function dynamic_keymap_get_combo
                                   1188 ;	-----------------------------------------
      008BE5                       1189 _dynamic_keymap_get_combo:
      008BE5 E5 82            [12] 1190 	mov	a,dpl
      008BE7 90 0B 20         [24] 1191 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_386
      008BEA F0               [24] 1192 	movx	@dptr,a
                                   1193 ;	quantum/dynamic_keymap.c:310: vial_combo_entry_t AK820_STATE_MEM *entry = (vial_combo_entry_t AK820_STATE_MEM *)buffer;
      008BEB 90 0B 1D         [24] 1194 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      008BEE 12 3A 40         [24] 1195 	lcall	_ak820_outline_0051
                                   1196 ;	quantum/dynamic_keymap.c:314: if (index >= VIAL_COMBO_ENTRIES)
      008BF1 90 0B 20         [24] 1197 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_386
      008BF4 E0               [24] 1198 	movx	a,@dptr
      008BF5 FD               [12] 1199 	mov	r5,a
      008BF6 BD 08 00         [24] 1200 	cjne	r5,#0x08,00132$
      008BF9                       1201 00132$:
      008BF9 40 04            [24] 1202 	jc	00102$
                                   1203 ;	quantum/dynamic_keymap.c:315: return -1;
      008BFB 90 FF FF         [24] 1204 	mov	dptr,#0xffff
      008BFE 22               [24] 1205 	ret
      008BFF                       1206 00102$:
                                   1207 ;	quantum/dynamic_keymap.c:317: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      008BFF 12 94 9B         [24] 1208 	lcall	_ak820_outline_0078
                                   1209 ;	quantum/dynamic_keymap.c:319: ak820_eeprom_read_block_xdata(entry, address, sizeof(vial_combo_entry_t));
      008C02 8E 02            [24] 1210 	mov	ar2,r6
      008C04 8F 03            [24] 1211 	mov	ar3,r7
      008C06 90 05 91         [24] 1212 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      008C09 12 3A 65         [24] 1213 	lcall	_ak820_outline_0071
      008C0C E4               [12] 1214 	clr	a
      008C0D A3               [24] 1215 	inc	dptr
      008C0E F0               [24] 1216 	movx	@dptr,a
      008C0F 90 05 94         [24] 1217 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      008C12 74 0A            [12] 1218 	mov	a,#0x0a
      008C14 12 3A A5         [24] 1219 	lcall	_ak820_outline_0123
      008C17 12 45 E5         [24] 1220 	lcall	_ak820_outline_0142
      008C1A C0 07            [24] 1221 	push	ar7
      008C1C C0 06            [24] 1222 	push	ar6
      008C1E 12 43 23         [24] 1223 	lcall	_ak820_eeprom_read_block_xdata
      008C21 D0 06            [24] 1224 	pop	ar6
      008C23 D0 07            [24] 1225 	pop	ar7
                                   1226 ;	quantum/dynamic_keymap.c:324: bool marked = entry->input[2] == AK820_COMBO_MARKER && entry->input[3] == AK820_COMBO_VERSION;
      008C25 74 04            [12] 1227 	mov	a,#0x04
      008C27 12 4B 65         [24] 1228 	lcall	_ak820_outline_0012
      008C2A FA               [12] 1229 	mov	r2,a
      008C2B A3               [24] 1230 	inc	dptr
      008C2C E0               [24] 1231 	movx	a,@dptr
      008C2D FB               [12] 1232 	mov	r3,a
      008C2E BA 20 14         [24] 1233 	cjne	r2,#0x20,00108$
      008C31 BB 08 11         [24] 1234 	cjne	r3,#0x08,00108$
      008C34 74 06            [12] 1235 	mov	a,#0x06
      008C36 12 3A 27         [24] 1236 	lcall	_ak820_outline_0017
      008C39 FA               [12] 1237 	mov	r2,a
      008C3A A3               [24] 1238 	inc	dptr
      008C3B E0               [24] 1239 	movx	a,@dptr
      008C3C FB               [12] 1240 	mov	r3,a
      008C3D BA 01 05         [24] 1241 	cjne	r2,#0x01,00136$
      008C40 BB 00 02         [24] 1242 	cjne	r3,#0x00,00136$
      008C43 80 05            [24] 1243 	sjmp	00109$
      008C45                       1244 00136$:
      008C45                       1245 00108$:
      008C45 75 2B 00         [24] 1246 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x00
      008C48 80 03            [24] 1247 	sjmp	00110$
      008C4A                       1248 00109$:
      008C4A 75 2B 01         [24] 1249 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x01
      008C4D                       1250 00110$:
                                   1251 ;	quantum/dynamic_keymap.c:325: entry->input[2] = entry->input[3] = 0;
      008C4D 74 06            [12] 1252 	mov	a,#0x06
      008C4F 12 3A 30         [24] 1253 	lcall	_ak820_outline_0031
      008C52 E4               [12] 1254 	clr	a
      008C53 F0               [24] 1255 	movx	@dptr,a
      008C54 A3               [24] 1256 	inc	dptr
      008C55 12 3A 71         [24] 1257 	lcall	_ak820_outline_0096
      008C58 F0               [24] 1258 	movx	@dptr,a
      008C59 A3               [24] 1259 	inc	dptr
      008C5A F0               [24] 1260 	movx	@dptr,a
                                   1261 ;	quantum/dynamic_keymap.c:326: if (!marked || !ak820_combo_valid(entry)) memset(entry, 0, sizeof(*entry));
      008C5B E5 2B            [12] 1262 	mov	a,_dynamic_keymap_get_combo_sloc0_1_0
      008C5D 60 12            [24] 1263 	jz	00103$
      008C5F 12 45 C9         [24] 1264 	lcall	_ak820_outline_0116
      008C62 C0 07            [24] 1265 	push	ar7
      008C64 C0 06            [24] 1266 	push	ar6
      008C66 12 36 AE         [24] 1267 	lcall	_ak820_combo_valid
      008C69 E5 82            [12] 1268 	mov	a, dpl
      008C6B D0 06            [24] 1269 	pop	ar6
      008C6D D0 07            [24] 1270 	pop	ar7
      008C6F 70 17            [24] 1271 	jnz	00104$
      008C71                       1272 00103$:
      008C71 7D 00            [12] 1273 	mov	r5,#0x00
      008C73 90 0D B2         [24] 1274 	mov	dptr,#_memset_PARM_2
      008C76 E4               [12] 1275 	clr	a
      008C77 F0               [24] 1276 	movx	@dptr,a
      008C78 90 0D B3         [24] 1277 	mov	dptr,#_memset_PARM_3
      008C7B 74 0A            [12] 1278 	mov	a,#0x0a
      008C7D F0               [24] 1279 	movx	@dptr,a
      008C7E E4               [12] 1280 	clr	a
      008C7F A3               [24] 1281 	inc	dptr
      008C80 12 45 AB         [24] 1282 	lcall	_ak820_outline_0061
      008C83 8D F0            [24] 1283 	mov	b, r5
      008C85 12 BD 6E         [24] 1284 	lcall	_memset
      008C88                       1285 00104$:
                                   1286 ;	quantum/dynamic_keymap.c:329: return 0;
      008C88 90 00 00         [24] 1287 	mov	dptr,#0x0000
                                   1288 ;	quantum/dynamic_keymap.c:330: }
      008C8B 22               [24] 1289 	ret
                                   1290 ;------------------------------------------------------------
                                   1291 ;Allocation info for local variables in function 'dynamic_keymap_set_combo'
                                   1292 ;------------------------------------------------------------
                                   1293 ;buffer        Allocated with name '_dynamic_keymap_set_combo_PARM_2'
                                   1294 ;index         Allocated with name '_dynamic_keymap_set_combo_index_10000_392'
                                   1295 ;entry         Allocated with name '_dynamic_keymap_set_combo_entry_10000_393'
                                   1296 ;address       Allocated with name '_dynamic_keymap_set_combo_address_10001_396'
                                   1297 ;stored        Allocated with name '_dynamic_keymap_set_combo_stored_10002_397'
                                   1298 ;------------------------------------------------------------
                                   1299 ;	quantum/dynamic_keymap.c:332: int dynamic_keymap_set_combo(uint8_t index, const vial_combo_entry_t *buffer) {
                                   1300 ;	-----------------------------------------
                                   1301 ;	 function dynamic_keymap_set_combo
                                   1302 ;	-----------------------------------------
      008C8C                       1303 _dynamic_keymap_set_combo:
      008C8C E5 82            [12] 1304 	mov	a,dpl
      008C8E 90 0B 24         [24] 1305 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_392
      008C91 F0               [24] 1306 	movx	@dptr,a
                                   1307 ;	quantum/dynamic_keymap.c:334: const vial_combo_entry_t AK820_STATE_MEM *entry = (const vial_combo_entry_t AK820_STATE_MEM *)buffer;
      008C92 90 0B 21         [24] 1308 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      008C95 12 39 E0         [24] 1309 	lcall	_ak820_outline_0004
                                   1310 ;	quantum/dynamic_keymap.c:339: if (!ak820_combo_valid(entry) || !ak820_nvm_ok()) return -1;
      008C98 C0 07            [24] 1311 	push	ar7
      008C9A C0 06            [24] 1312 	push	ar6
      008C9C 12 36 AE         [24] 1313 	lcall	_ak820_combo_valid
      008C9F E5 82            [12] 1314 	mov	a, dpl
      008CA1 D0 06            [24] 1315 	pop	ar6
      008CA3 D0 07            [24] 1316 	pop	ar7
      008CA5 60 07            [24] 1317 	jz	00101$
      008CA7 12 40 8F         [24] 1318 	lcall	_ak820_nvm_ok
      008CAA E5 82            [12] 1319 	mov	a, dpl
      008CAC 70 04            [24] 1320 	jnz	00102$
      008CAE                       1321 00101$:
      008CAE 90 FF FF         [24] 1322 	mov	dptr,#0xffff
      008CB1 22               [24] 1323 	ret
      008CB2                       1324 00102$:
                                   1325 ;	quantum/dynamic_keymap.c:341: if (index >= VIAL_COMBO_ENTRIES)
      008CB2 90 0B 24         [24] 1326 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_392
      008CB5 E0               [24] 1327 	movx	a,@dptr
      008CB6 FD               [12] 1328 	mov	r5,a
      008CB7 BD 08 00         [24] 1329 	cjne	r5,#0x08,00133$
      008CBA                       1330 00133$:
      008CBA 40 04            [24] 1331 	jc	00105$
                                   1332 ;	quantum/dynamic_keymap.c:342: return -1;
      008CBC 90 FF FF         [24] 1333 	mov	dptr,#0xffff
      008CBF 22               [24] 1334 	ret
      008CC0                       1335 00105$:
                                   1336 ;	quantum/dynamic_keymap.c:344: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      008CC0 12 94 9B         [24] 1337 	lcall	_ak820_outline_0078
                                   1338 ;	quantum/dynamic_keymap.c:346: clear_keyboard();
      008CC3 C0 07            [24] 1339 	push	ar7
      008CC5 C0 06            [24] 1340 	push	ar6
      008CC7 C0 05            [24] 1341 	push	ar5
      008CC9 C0 04            [24] 1342 	push	ar4
      008CCB 12 7C FF         [24] 1343 	lcall	_clear_keyboard
      008CCE D0 04            [24] 1344 	pop	ar4
      008CD0 D0 05            [24] 1345 	pop	ar5
      008CD2 D0 06            [24] 1346 	pop	ar6
      008CD4 D0 07            [24] 1347 	pop	ar7
                                   1348 ;	quantum/dynamic_keymap.c:347: vial_combo_entry_t stored = *entry;
      008CD6 90 0D AA         [24] 1349 	mov	dptr,#___memcpy_PARM_2
      008CD9 12 4B BE         [24] 1350 	lcall	_ak820_outline_0059
      008CDC E4               [12] 1351 	clr	a
      008CDD A3               [24] 1352 	inc	dptr
      008CDE F0               [24] 1353 	movx	@dptr,a
      008CDF 90 0D AD         [24] 1354 	mov	dptr,#___memcpy_PARM_3
      008CE2 74 0A            [12] 1355 	mov	a,#0x0a
      008CE4 12 3A A5         [24] 1356 	lcall	_ak820_outline_0123
      008CE7 90 0B 25         [24] 1357 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_397
      008CEA F5 F0            [12] 1358 	mov	b,a
      008CEC C0 05            [24] 1359 	push	ar5
      008CEE C0 04            [24] 1360 	push	ar4
      008CF0 12 BC F8         [24] 1361 	lcall	___memcpy
      008CF3 D0 04            [24] 1362 	pop	ar4
      008CF5 D0 05            [24] 1363 	pop	ar5
                                   1364 ;	quantum/dynamic_keymap.c:348: stored.input[2] = AK820_COMBO_MARKER;
      008CF7 90 0B 29         [24] 1365 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_397 + 0x0004)
      008CFA 74 20            [12] 1366 	mov	a,#0x20
      008CFC F0               [24] 1367 	movx	@dptr,a
      008CFD 74 08            [12] 1368 	mov	a,#0x08
      008CFF A3               [24] 1369 	inc	dptr
      008D00 F0               [24] 1370 	movx	@dptr,a
                                   1371 ;	quantum/dynamic_keymap.c:349: stored.input[3] = AK820_COMBO_VERSION;
      008D01 90 0B 2B         [24] 1372 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_397 + 0x0006)
      008D04 74 01            [12] 1373 	mov	a,#0x01
      008D06 12 3A A5         [24] 1374 	lcall	_ak820_outline_0123
                                   1375 ;	quantum/dynamic_keymap.c:350: ak820_eeprom_write_block_xdata(&stored, address, sizeof(stored));
      008D09 90 05 9A         [24] 1376 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      008D0C 12 3A 65         [24] 1377 	lcall	_ak820_outline_0071
      008D0F E4               [12] 1378 	clr	a
      008D10 A3               [24] 1379 	inc	dptr
      008D11 F0               [24] 1380 	movx	@dptr,a
      008D12 90 05 9D         [24] 1381 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      008D15 74 0A            [12] 1382 	mov	a,#0x0a
      008D17 12 3A A5         [24] 1383 	lcall	_ak820_outline_0123
      008D1A 90 0B 25         [24] 1384 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_397
      008D1D 12 43 AF         [24] 1385 	lcall	_ak820_eeprom_write_block_xdata
                                   1386 ;	quantum/dynamic_keymap.c:355: ak820_nvm_flush();
      008D20 12 40 9E         [24] 1387 	lcall	_ak820_nvm_flush
                                   1388 ;	quantum/dynamic_keymap.c:356: if (!ak820_nvm_ok()) return -1;
      008D23 12 40 8F         [24] 1389 	lcall	_ak820_nvm_ok
      008D26 E5 82            [12] 1390 	mov	a, dpl
      008D28 70 04            [24] 1391 	jnz	00107$
      008D2A 90 FF FF         [24] 1392 	mov	dptr,#0xffff
      008D2D 22               [24] 1393 	ret
      008D2E                       1394 00107$:
                                   1395 ;	quantum/dynamic_keymap.c:360: return 0;
      008D2E 90 00 00         [24] 1396 	mov	dptr,#0x0000
                                   1397 ;	quantum/dynamic_keymap.c:361: }
      008D31 22               [24] 1398 	ret
                                   1399 ;------------------------------------------------------------
                                   1400 ;Allocation info for local variables in function 'dynamic_keymap_reset'
                                   1401 ;------------------------------------------------------------
                                   1402 ;vial_unlocked_prev Allocated with name '_dynamic_keymap_reset_vial_unlocked_prev_10000_400'
                                   1403 ;layer         Allocated with name '_dynamic_keymap_reset_layer_20000_401'
                                   1404 ;row           Allocated with name '_dynamic_keymap_reset_row_40000_403'
                                   1405 ;column        Allocated with name '_dynamic_keymap_reset_column_60000_405'
                                   1406 ;encoder       Allocated with name '_dynamic_keymap_reset_encoder_40000_407'
                                   1407 ;combo         Allocated with name '_dynamic_keymap_reset_combo_10001_409'
                                   1408 ;i             Allocated with name '_dynamic_keymap_reset_i_20001_410'
                                   1409 ;------------------------------------------------------------
                                   1410 ;	quantum/dynamic_keymap.c:404: void dynamic_keymap_reset(void) {
                                   1411 ;	-----------------------------------------
                                   1412 ;	 function dynamic_keymap_reset
                                   1413 ;	-----------------------------------------
      008D32                       1414 _dynamic_keymap_reset:
                                   1415 ;	quantum/dynamic_keymap.c:415: bool vial_unlocked_prev = vial_unlocked;
      008D32 90 0E 2B         [24] 1416 	mov	dptr,#_vial_unlocked
      008D35 E0               [24] 1417 	movx	a,@dptr
      008D36 90 0B 2F         [24] 1418 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_400
      008D39 F0               [24] 1419 	movx	@dptr,a
                                   1420 ;	quantum/dynamic_keymap.c:416: vial_unlocked = 1;
      008D3A 90 0E 2B         [24] 1421 	mov	dptr,#_vial_unlocked
      008D3D 74 01            [12] 1422 	mov	a,#0x01
      008D3F F0               [24] 1423 	movx	@dptr,a
                                   1424 ;	quantum/dynamic_keymap.c:420: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      008D40 7F 00            [12] 1425 	mov	r7,#0x00
      008D42                       1426 00116$:
      008D42 BF 06 00         [24] 1427 	cjne	r7,#0x06,00198$
      008D45                       1428 00198$:
      008D45 40 02            [24] 1429 	jc	00199$
      008D47 A1 F0            [12] 1430 	ajmp	00104$
      008D49                       1431 00199$:
                                   1432 ;	quantum/dynamic_keymap.c:421: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      008D49 7E 00            [12] 1433 	mov	r6,#0x00
      008D4B                       1434 00110$:
      008D4B BE 10 00         [24] 1435 	cjne	r6,#0x10,00200$
      008D4E                       1436 00200$:
      008D4E 50 4C            [24] 1437 	jnc	00102$
                                   1438 ;	quantum/dynamic_keymap.c:422: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      008D50 7D 00            [12] 1439 	mov	r5,#0x00
      008D52                       1440 00107$:
      008D52 BD 08 00         [24] 1441 	cjne	r5,#0x08,00202$
      008D55                       1442 00202$:
      008D55 50 42            [24] 1443 	jnc	00111$
                                   1444 ;	quantum/dynamic_keymap.c:423: dynamic_keymap_set_keycode(layer, row, column, keycode_at_keymap_location_raw(layer, row, column));
      008D57 90 0B CB         [24] 1445 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_2
      008D5A EE               [12] 1446 	mov	a,r6
      008D5B F0               [24] 1447 	movx	@dptr,a
      008D5C 90 0B CC         [24] 1448 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_3
      008D5F ED               [12] 1449 	mov	a,r5
      008D60 F0               [24] 1450 	movx	@dptr,a
      008D61 8F 82            [24] 1451 	mov	dpl, r7
      008D63 C0 07            [24] 1452 	push	ar7
      008D65 C0 06            [24] 1453 	push	ar6
      008D67 C0 05            [24] 1454 	push	ar5
      008D69 12 9C CC         [24] 1455 	lcall	_keycode_at_keymap_location_raw
      008D6C AB 82            [24] 1456 	mov	r3, dpl
      008D6E AC 83            [24] 1457 	mov	r4, dph
      008D70 D0 05            [24] 1458 	pop	ar5
      008D72 D0 06            [24] 1459 	pop	ar6
      008D74 D0 07            [24] 1460 	pop	ar7
      008D76 90 0B 0E         [24] 1461 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      008D79 EE               [12] 1462 	mov	a,r6
      008D7A F0               [24] 1463 	movx	@dptr,a
      008D7B 90 0B 0F         [24] 1464 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      008D7E ED               [12] 1465 	mov	a,r5
      008D7F F0               [24] 1466 	movx	@dptr,a
      008D80 90 0B 10         [24] 1467 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      008D83 12 3A 6B         [24] 1468 	lcall	_ak820_outline_0076
      008D86 8F 82            [24] 1469 	mov	dpl, r7
      008D88 C0 07            [24] 1470 	push	ar7
      008D8A C0 06            [24] 1471 	push	ar6
      008D8C C0 05            [24] 1472 	push	ar5
      008D8E 51 A2            [12] 1473 	acall	_dynamic_keymap_set_keycode
      008D90 D0 05            [24] 1474 	pop	ar5
      008D92 D0 06            [24] 1475 	pop	ar6
      008D94 D0 07            [24] 1476 	pop	ar7
                                   1477 ;	quantum/dynamic_keymap.c:422: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      008D96 0D               [12] 1478 	inc	r5
      008D97 80 B9            [24] 1479 	sjmp	00107$
      008D99                       1480 00111$:
                                   1481 ;	quantum/dynamic_keymap.c:421: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      008D99 0E               [12] 1482 	inc	r6
      008D9A 80 AF            [24] 1483 	sjmp	00110$
      008D9C                       1484 00102$:
                                   1485 ;	quantum/dynamic_keymap.c:427: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      008D9C 7E 00            [12] 1486 	mov	r6,#0x00
      008D9E                       1487 00113$:
      008D9E BE 01 00         [24] 1488 	cjne	r6,#0x01,00204$
      008DA1                       1489 00204$:
      008DA1 50 4A            [24] 1490 	jnc	00117$
                                   1491 ;	quantum/dynamic_keymap.c:428: dynamic_keymap_set_encoder(layer, encoder, true, keycode_at_encodermap_location_raw(layer, encoder, true));
      008DA3 12 94 EA         [24] 1492 	lcall	_ak820_outline_0174
      008DA6 04               [12] 1493 	inc	a
      008DA7 F0               [24] 1494 	movx	@dptr,a
      008DA8 8F 82            [24] 1495 	mov	dpl, r7
      008DAA C0 07            [24] 1496 	push	ar7
      008DAC 12 9D 11         [24] 1497 	lcall	_keycode_at_encodermap_location_raw
      008DAF 12 45 EA         [24] 1498 	lcall	_ak820_outline_0148
      008DB2 D0 07            [24] 1499 	pop	ar7
      008DB4 12 94 E1         [24] 1500 	lcall	_ak820_outline_0173
      008DB7 04               [12] 1501 	inc	a
      008DB8 F0               [24] 1502 	movx	@dptr,a
      008DB9 90 0B 1A         [24] 1503 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008DBC 12 3A 65         [24] 1504 	lcall	_ak820_outline_0071
      008DBF 8F 82            [24] 1505 	mov	dpl, r7
      008DC1 C0 07            [24] 1506 	push	ar7
      008DC3 71 7A            [24] 1507 	acall	_dynamic_keymap_set_encoder
      008DC5 D0 07            [24] 1508 	pop	ar7
                                   1509 ;	quantum/dynamic_keymap.c:429: dynamic_keymap_set_encoder(layer, encoder, false, keycode_at_encodermap_location_raw(layer, encoder, false));
      008DC7 12 94 EA         [24] 1510 	lcall	_ak820_outline_0174
      008DCA F0               [24] 1511 	movx	@dptr,a
      008DCB 8F 82            [24] 1512 	mov	dpl, r7
      008DCD C0 07            [24] 1513 	push	ar7
      008DCF 12 9D 11         [24] 1514 	lcall	_keycode_at_encodermap_location_raw
      008DD2 12 45 EA         [24] 1515 	lcall	_ak820_outline_0148
      008DD5 D0 07            [24] 1516 	pop	ar7
      008DD7 12 94 E1         [24] 1517 	lcall	_ak820_outline_0173
      008DDA F0               [24] 1518 	movx	@dptr,a
      008DDB 90 0B 1A         [24] 1519 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008DDE 12 3A 65         [24] 1520 	lcall	_ak820_outline_0071
      008DE1 8F 82            [24] 1521 	mov	dpl, r7
      008DE3 C0 07            [24] 1522 	push	ar7
      008DE5 71 7A            [24] 1523 	acall	_dynamic_keymap_set_encoder
      008DE7 D0 07            [24] 1524 	pop	ar7
                                   1525 ;	quantum/dynamic_keymap.c:427: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      008DE9 7E 01            [12] 1526 	mov	r6,#0x01
      008DEB 80 B1            [24] 1527 	sjmp	00113$
      008DED                       1528 00117$:
                                   1529 ;	quantum/dynamic_keymap.c:420: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      008DED 0F               [12] 1530 	inc	r7
      008DEE A1 42            [12] 1531 	ajmp	00116$
      008DF0                       1532 00104$:
                                   1533 ;	quantum/dynamic_keymap.c:449: vial_combo_entry_t combo = { { 0 }, 0 };
      008DF0 90 0B 30         [24] 1534 	mov	dptr,#_dynamic_keymap_reset_combo_10001_409
      008DF3 12 52 8E         [24] 1535 	lcall	_ak820_outline_0178
      008DF6 90 0B 32         [24] 1536 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_409 + 0x0002)
      008DF9 F0               [24] 1537 	movx	@dptr,a
      008DFA A3               [24] 1538 	inc	dptr
      008DFB F0               [24] 1539 	movx	@dptr,a
      008DFC 90 0B 34         [24] 1540 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_409 + 0x0004)
      008DFF F0               [24] 1541 	movx	@dptr,a
      008E00 A3               [24] 1542 	inc	dptr
      008E01 F0               [24] 1543 	movx	@dptr,a
      008E02 90 0B 36         [24] 1544 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_409 + 0x0006)
      008E05 F0               [24] 1545 	movx	@dptr,a
      008E06 A3               [24] 1546 	inc	dptr
      008E07 F0               [24] 1547 	movx	@dptr,a
      008E08 90 0B 38         [24] 1548 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_409 + 0x0008)
      008E0B F0               [24] 1549 	movx	@dptr,a
      008E0C A3               [24] 1550 	inc	dptr
      008E0D F0               [24] 1551 	movx	@dptr,a
                                   1552 ;	quantum/dynamic_keymap.c:450: for (reset_index_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      008E0E FF               [12] 1553 	mov	r7,a
      008E0F                       1554 00119$:
      008E0F BF 08 00         [24] 1555 	cjne	r7,#0x08,00206$
      008E12                       1556 00206$:
      008E12 50 16            [24] 1557 	jnc	00105$
                                   1558 ;	quantum/dynamic_keymap.c:451: dynamic_keymap_set_combo(i, &combo);
      008E14 90 0B 21         [24] 1559 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      008E17 74 30            [12] 1560 	mov	a,#_dynamic_keymap_reset_combo_10001_409
      008E19 F0               [24] 1561 	movx	@dptr,a
      008E1A 74 0B            [12] 1562 	mov	a,#(_dynamic_keymap_reset_combo_10001_409 >> 8)
      008E1C 12 3A 94         [24] 1563 	lcall	_ak820_outline_0117
      008E1F 8F 82            [24] 1564 	mov	dpl, r7
      008E21 C0 07            [24] 1565 	push	ar7
      008E23 91 8C            [24] 1566 	acall	_dynamic_keymap_set_combo
      008E25 D0 07            [24] 1567 	pop	ar7
                                   1568 ;	quantum/dynamic_keymap.c:450: for (reset_index_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      008E27 0F               [12] 1569 	inc	r7
      008E28 80 E5            [24] 1570 	sjmp	00119$
      008E2A                       1571 00105$:
                                   1572 ;	quantum/dynamic_keymap.c:466: vial_unlocked = vial_unlocked_prev;
      008E2A 90 0B 2F         [24] 1573 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_400
      008E2D E0               [24] 1574 	movx	a,@dptr
      008E2E 90 0E 2B         [24] 1575 	mov	dptr,#_vial_unlocked
      008E31 F0               [24] 1576 	movx	@dptr,a
                                   1577 ;	quantum/dynamic_keymap.c:468: }
      008E32 22               [24] 1578 	ret
                                   1579 ;------------------------------------------------------------
                                   1580 ;Allocation info for local variables in function 'ak820_dynamic_read_buffer'
                                   1581 ;------------------------------------------------------------
                                   1582 ;sloc0         Allocated with name '_ak820_dynamic_read_buffer_sloc0_1_0'
                                   1583 ;limit         Allocated with name '_ak820_dynamic_read_buffer_PARM_2'
                                   1584 ;offset        Allocated with name '_ak820_dynamic_read_buffer_PARM_3'
                                   1585 ;size          Allocated with name '_ak820_dynamic_read_buffer_PARM_4'
                                   1586 ;data          Allocated with name '_ak820_dynamic_read_buffer_PARM_5'
                                   1587 ;base          Allocated with name '_ak820_dynamic_read_buffer_base_10000_411'
                                   1588 ;target        Allocated with name '_ak820_dynamic_read_buffer_target_10000_412'
                                   1589 ;available     Allocated with name '_ak820_dynamic_read_buffer_available_10000_412'
                                   1590 ;remaining     Allocated with name '_ak820_dynamic_read_buffer_remaining_30000_415'
                                   1591 ;i             Allocated with name '_ak820_dynamic_read_buffer_i_20000_417'
                                   1592 ;------------------------------------------------------------
                                   1593 ;	quantum/dynamic_keymap.c:473: static void ak820_dynamic_read_buffer(uint16_t base, uint16_t limit, uint16_t offset, uint16_t size, uint8_t *data) {
                                   1594 ;	-----------------------------------------
                                   1595 ;	 function ak820_dynamic_read_buffer
                                   1596 ;	-----------------------------------------
      008E33                       1597 _ak820_dynamic_read_buffer:
      008E33 12 3A 83         [24] 1598 	lcall	_ak820_outline_0103
      008E36 90 0B 43         [24] 1599 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_411
      008E39 12 3A 88         [24] 1600 	lcall	_ak820_outline_0104
                                   1601 ;	quantum/dynamic_keymap.c:474: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      008E3C 90 0B 40         [24] 1602 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008E3F 12 3A 40         [24] 1603 	lcall	_ak820_outline_0051
                                   1604 ;	quantum/dynamic_keymap.c:475: uint8_t available = 0;
      008E42 90 0B 45         [24] 1605 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_412
      008E45 E4               [12] 1606 	clr	a
      008E46 F0               [24] 1607 	movx	@dptr,a
                                   1608 ;	quantum/dynamic_keymap.c:476: if (size > 28) return;
      008E47 90 0B 3E         [24] 1609 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008E4A 12 3A 5F         [24] 1610 	lcall	_ak820_outline_0060
      008E4D 8C 02            [24] 1611 	mov	ar2,r4
      008E4F 8D 03            [24] 1612 	mov	ar3,r5
      008E51 C3               [12] 1613 	clr	c
      008E52 74 1C            [12] 1614 	mov	a,#0x1c
      008E54 9A               [12] 1615 	subb	a,r2
      008E55 E4               [12] 1616 	clr	a
      008E56 9B               [12] 1617 	subb	a,r3
      008E57 50 01            [24] 1618 	jnc	00102$
                                   1619 ;	free result
      008E59 22               [24] 1620 	ret
      008E5A                       1621 00102$:
                                   1622 ;	quantum/dynamic_keymap.c:477: if (offset < limit) {
      008E5A 90 0B 3C         [24] 1623 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008E5D 12 45 CE         [24] 1624 	lcall	_ak820_outline_0119
      008E60 90 0B 3A         [24] 1625 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008E63 12 3A 7D         [24] 1626 	lcall	_ak820_outline_0100
      008E66 C3               [12] 1627 	clr	c
      008E67 EA               [12] 1628 	mov	a,r2
      008E68 98               [12] 1629 	subb	a,r0
      008E69 EB               [12] 1630 	mov	a,r3
      008E6A 99               [12] 1631 	subb	a,r1
      008E6B 50 17            [24] 1632 	jnc	00104$
                                   1633 ;	quantum/dynamic_keymap.c:478: uint16_t remaining = limit - offset;
      008E6D E8               [12] 1634 	mov	a,r0
      008E6E C3               [12] 1635 	clr	c
      008E6F 9A               [12] 1636 	subb	a,r2
      008E70 F8               [12] 1637 	mov	r0,a
      008E71 E9               [12] 1638 	mov	a,r1
      008E72 9B               [12] 1639 	subb	a,r3
      008E73 F9               [12] 1640 	mov	r1,a
                                   1641 ;	quantum/dynamic_keymap.c:479: available = remaining < size ? remaining : size;
      008E74 C3               [12] 1642 	clr	c
      008E75 E8               [12] 1643 	mov	a,r0
      008E76 9C               [12] 1644 	subb	a,r4
      008E77 E9               [12] 1645 	mov	a,r1
      008E78 9D               [12] 1646 	subb	a,r5
      008E79 40 04            [24] 1647 	jc	00114$
      008E7B 8C 00            [24] 1648 	mov	ar0,r4
      008E7D 8D 01            [24] 1649 	mov	ar1,r5
      008E7F                       1650 00114$:
      008E7F 90 0B 45         [24] 1651 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_412
      008E82 E8               [12] 1652 	mov	a,r0
      008E83 F0               [24] 1653 	movx	@dptr,a
      008E84                       1654 00104$:
                                   1655 ;	quantum/dynamic_keymap.c:481: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      008E84 90 0B 45         [24] 1656 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_412
      008E87 E0               [24] 1657 	movx	a,@dptr
      008E88 F5 2C            [12] 1658 	mov	_ak820_dynamic_read_buffer_sloc0_1_0,a
      008E8A E0               [24] 1659 	movx	a,@dptr
      008E8B 60 42            [24] 1660 	jz	00106$
      008E8D C0 04            [24] 1661 	push	ar4
      008E8F C0 05            [24] 1662 	push	ar5
      008E91 8E 00            [24] 1663 	mov	ar0,r6
      008E93 8F 05            [24] 1664 	mov	ar5,r7
      008E95 90 0B 43         [24] 1665 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_411
      008E98 E0               [24] 1666 	movx	a,@dptr
      008E99 F9               [12] 1667 	mov	r1,a
      008E9A A3               [24] 1668 	inc	dptr
      008E9B E0               [24] 1669 	movx	a,@dptr
      008E9C FC               [12] 1670 	mov	r4,a
      008E9D EA               [12] 1671 	mov	a,r2
      008E9E 29               [12] 1672 	add	a, r1
      008E9F FA               [12] 1673 	mov	r2,a
      008EA0 EB               [12] 1674 	mov	a,r3
      008EA1 3C               [12] 1675 	addc	a, r4
      008EA2 FB               [12] 1676 	mov	r3,a
      008EA3 90 05 91         [24] 1677 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      008EA6 EA               [12] 1678 	mov	a,r2
      008EA7 F0               [24] 1679 	movx	@dptr,a
      008EA8 EB               [12] 1680 	mov	a,r3
      008EA9 12 3A 94         [24] 1681 	lcall	_ak820_outline_0117
      008EAC 90 05 94         [24] 1682 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      008EAF E5 2C            [12] 1683 	mov	a,_ak820_dynamic_read_buffer_sloc0_1_0
      008EB1 12 3A A5         [24] 1684 	lcall	_ak820_outline_0123
      008EB4 88 82            [24] 1685 	mov	dpl, r0
      008EB6 8D 83            [24] 1686 	mov	dph, r5
      008EB8 C0 07            [24] 1687 	push	ar7
      008EBA C0 06            [24] 1688 	push	ar6
      008EBC C0 05            [24] 1689 	push	ar5
      008EBE C0 04            [24] 1690 	push	ar4
      008EC0 12 43 23         [24] 1691 	lcall	_ak820_eeprom_read_block_xdata
      008EC3 D0 04            [24] 1692 	pop	ar4
      008EC5 D0 05            [24] 1693 	pop	ar5
      008EC7 D0 06            [24] 1694 	pop	ar6
      008EC9 D0 07            [24] 1695 	pop	ar7
                                   1696 ;	quantum/dynamic_keymap.c:482: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      008ECB D0 05            [24] 1697 	pop	ar5
      008ECD D0 04            [24] 1698 	pop	ar4
                                   1699 ;	quantum/dynamic_keymap.c:481: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      008ECF                       1700 00106$:
                                   1701 ;	quantum/dynamic_keymap.c:482: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      008ECF 90 0B 45         [24] 1702 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_412
      008ED2 E0               [24] 1703 	movx	a,@dptr
      008ED3 FB               [12] 1704 	mov	r3,a
      008ED4                       1705 00109$:
      008ED4 8B 01            [24] 1706 	mov	ar1,r3
      008ED6 7A 00            [12] 1707 	mov	r2,#0x00
      008ED8 C3               [12] 1708 	clr	c
      008ED9 E9               [12] 1709 	mov	a,r1
      008EDA 9C               [12] 1710 	subb	a,r4
      008EDB EA               [12] 1711 	mov	a,r2
      008EDC 9D               [12] 1712 	subb	a,r5
      008EDD 50 09            [24] 1713 	jnc	00111$
      008EDF EB               [12] 1714 	mov	a,r3
      008EE0 12 3A 30         [24] 1715 	lcall	_ak820_outline_0031
      008EE3 E4               [12] 1716 	clr	a
      008EE4 F0               [24] 1717 	movx	@dptr,a
      008EE5 0B               [12] 1718 	inc	r3
      008EE6 80 EC            [24] 1719 	sjmp	00109$
      008EE8                       1720 00111$:
                                   1721 ;	quantum/dynamic_keymap.c:483: }
      008EE8 22               [24] 1722 	ret
                                   1723 ;------------------------------------------------------------
                                   1724 ;Allocation info for local variables in function 'dynamic_keymap_get_buffer'
                                   1725 ;------------------------------------------------------------
                                   1726 ;size          Allocated with name '_dynamic_keymap_get_buffer_PARM_2'
                                   1727 ;data          Allocated with name '_dynamic_keymap_get_buffer_PARM_3'
                                   1728 ;offset        Allocated with name '_dynamic_keymap_get_buffer_offset_10000_418'
                                   1729 ;------------------------------------------------------------
                                   1730 ;	quantum/dynamic_keymap.c:486: void dynamic_keymap_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   1731 ;	-----------------------------------------
                                   1732 ;	 function dynamic_keymap_get_buffer
                                   1733 ;	-----------------------------------------
      008EE9                       1734 _dynamic_keymap_get_buffer:
      008EE9 12 3A 83         [24] 1735 	lcall	_ak820_outline_0103
      008EEC 90 0B 4B         [24] 1736 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_418
      008EEF 12 3A 88         [24] 1737 	lcall	_ak820_outline_0104
                                   1738 ;	quantum/dynamic_keymap.c:489: DYNAMIC_KEYMAP_LAYER_COUNT * MATRIX_ROWS * MATRIX_COLS * 2, offset, size, data);
      008EF2 90 0B 4B         [24] 1739 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_418
      008EF5 12 3A 40         [24] 1740 	lcall	_ak820_outline_0051
      008EF8 90 0B 46         [24] 1741 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_2
      008EFB 12 3A 5F         [24] 1742 	lcall	_ak820_outline_0060
      008EFE 90 0B 48         [24] 1743 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_3
      008F01 12 52 6E         [24] 1744 	lcall	_ak820_outline_0087
      008F04 90 0B 3A         [24] 1745 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008F07 E4               [12] 1746 	clr	a
      008F08 F0               [24] 1747 	movx	@dptr,a
      008F09 74 06            [12] 1748 	mov	a,#0x06
      008F0B A3               [24] 1749 	inc	dptr
      008F0C F0               [24] 1750 	movx	@dptr,a
      008F0D 90 0B 3C         [24] 1751 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008F10 12 4B BE         [24] 1752 	lcall	_ak820_outline_0059
      008F13 90 0B 3E         [24] 1753 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008F16 12 3A 65         [24] 1754 	lcall	_ak820_outline_0071
      008F19 90 0B 40         [24] 1755 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008F1C E9               [12] 1756 	mov	a,r1
      008F1D 12 52 87         [24] 1757 	lcall	_ak820_outline_0154
      008F20 F0               [24] 1758 	movx	@dptr,a
      008F21 90 00 40         [24] 1759 	mov	dptr,#0x0040
                                   1760 ;	quantum/dynamic_keymap.c:511: }
      008F24 C1 33            [12] 1761 	ajmp	_ak820_dynamic_read_buffer
                                   1762 ;------------------------------------------------------------
                                   1763 ;Allocation info for local variables in function 'dynamic_keymap_set_buffer'
                                   1764 ;------------------------------------------------------------
                                   1765 ;sloc0         Allocated with name '_dynamic_keymap_set_buffer_sloc0_1_0'
                                   1766 ;sloc1         Allocated with name '_dynamic_keymap_set_buffer_sloc1_1_0'
                                   1767 ;sloc2         Allocated with name '_dynamic_keymap_set_buffer_sloc2_1_0'
                                   1768 ;size          Allocated with name '_dynamic_keymap_set_buffer_PARM_2'
                                   1769 ;data          Allocated with name '_dynamic_keymap_set_buffer_PARM_3'
                                   1770 ;offset        Allocated with name '_dynamic_keymap_set_buffer_offset_10000_420'
                                   1771 ;dynamic_keymap_eeprom_size Allocated with name '_dynamic_keymap_set_buffer_dynamic_keymap_eeprom_size_10000_421'
                                   1772 ;target        Allocated with name '_dynamic_keymap_set_buffer_target_10000_421'
                                   1773 ;buffer        Allocated with name '_dynamic_keymap_set_buffer_buffer_10000_421'
                                   1774 ;count         Allocated with name '_dynamic_keymap_set_buffer_count_10001_424'
                                   1775 ;chk_offset    Allocated with name '_dynamic_keymap_set_buffer_chk_offset_30001_427'
                                   1776 ;chk_sz        Allocated with name '_dynamic_keymap_set_buffer_chk_sz_30001_427'
                                   1777 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_429'
                                   1778 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_432'
                                   1779 ;i             Allocated with name '_dynamic_keymap_set_buffer_i_40001_434'
                                   1780 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_435'
                                   1781 ;------------------------------------------------------------
                                   1782 ;	quantum/dynamic_keymap.c:513: void dynamic_keymap_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   1783 ;	-----------------------------------------
                                   1784 ;	 function dynamic_keymap_set_buffer
                                   1785 ;	-----------------------------------------
      008F26                       1786 _dynamic_keymap_set_buffer:
      008F26 12 3A 83         [24] 1787 	lcall	_ak820_outline_0103
      008F29 90 0B 52         [24] 1788 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_420
      008F2C 12 3A 88         [24] 1789 	lcall	_ak820_outline_0104
                                   1790 ;	quantum/dynamic_keymap.c:515: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset);
      008F2F 90 0B 52         [24] 1791 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_420
      008F32 12 3A 0B         [24] 1792 	lcall	_ak820_outline_0011
      008F35 74 40            [12] 1793 	mov	a,#0x40
      008F37 2C               [12] 1794 	add	a, r4
      008F38 FA               [12] 1795 	mov	r2,a
      008F39 E4               [12] 1796 	clr	a
      008F3A 3D               [12] 1797 	addc	a, r5
      008F3B FB               [12] 1798 	mov	r3,a
                                   1799 ;	quantum/dynamic_keymap.c:516: uint8_t DYNAMIC_BUFFER_MEM *buffer = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      008F3C 90 0B 4F         [24] 1800 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_3
      008F3F 12 3A 7D         [24] 1801 	lcall	_ak820_outline_0100
                                   1802 ;	quantum/dynamic_keymap.c:520: if (!size) return;
      008F42 90 0B 4D         [24] 1803 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_2
      008F45 E0               [24] 1804 	movx	a,@dptr
      008F46 F5 2D            [12] 1805 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,a
      008F48 A3               [24] 1806 	inc	dptr
      008F49 E0               [24] 1807 	movx	a,@dptr
      008F4A F5 2E            [12] 1808 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),a
      008F4C E5 2D            [12] 1809 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008F4E 45 2E            [12] 1810 	orl	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008F50 70 01            [24] 1811 	jnz	00102$
      008F52 22               [24] 1812 	ret
      008F53                       1813 00102$:
                                   1814 ;	quantum/dynamic_keymap.c:522: if (size > 28) return;
      008F53 85 2D 2F         [24] 1815 	mov	_dynamic_keymap_set_buffer_sloc1_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
      008F56 85 2E 30         [24] 1816 	mov	(_dynamic_keymap_set_buffer_sloc1_1_0 + 1),(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008F59 C3               [12] 1817 	clr	c
      008F5A 74 1C            [12] 1818 	mov	a,#0x1c
      008F5C 95 2F            [12] 1819 	subb	a,_dynamic_keymap_set_buffer_sloc1_1_0
      008F5E E4               [12] 1820 	clr	a
      008F5F 95 30            [12] 1821 	subb	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      008F61 50 01            [24] 1822 	jnc	00104$
                                   1823 ;	free result
      008F63 22               [24] 1824 	ret
      008F64                       1825 00104$:
                                   1826 ;	quantum/dynamic_keymap.c:524: dynamic_buffer_size_t count = size;
      008F64 85 2D 31         [24] 1827 	mov	_dynamic_keymap_set_buffer_sloc2_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
                                   1828 ;	quantum/dynamic_keymap.c:528: if (offset >= dynamic_keymap_eeprom_size || dynamic_keymap_eeprom_size - offset < size)
      008F67 74 FA            [12] 1829 	mov	a,#0x100 - 0x06
      008F69 2F               [12] 1830 	add	a,r7
      008F6A 40 11            [24] 1831 	jc	00105$
      008F6C E4               [12] 1832 	clr	a
      008F6D C3               [12] 1833 	clr	c
      008F6E 9E               [12] 1834 	subb	a,r6
      008F6F FE               [12] 1835 	mov	r6,a
      008F70 74 06            [12] 1836 	mov	a,#0x06
      008F72 9F               [12] 1837 	subb	a,r7
      008F73 FF               [12] 1838 	mov	r7,a
      008F74 C3               [12] 1839 	clr	c
      008F75 EE               [12] 1840 	mov	a,r6
      008F76 95 2D            [12] 1841 	subb	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008F78 EF               [12] 1842 	mov	a,r7
      008F79 95 2E            [12] 1843 	subb	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008F7B 50 01            [24] 1844 	jnc	00106$
      008F7D                       1845 00105$:
                                   1846 ;	quantum/dynamic_keymap.c:529: return;
      008F7D 22               [24] 1847 	ret
      008F7E                       1848 00106$:
                                   1849 ;	quantum/dynamic_keymap.c:533: if (!vial_unlocked) {
      008F7E 90 0E 2B         [24] 1850 	mov	dptr,#_vial_unlocked
      008F81 E0               [24] 1851 	movx	a,@dptr
      008F82 60 03            [24] 1852 	jz	00207$
      008F84 02 90 92         [24] 1853 	ljmp	00120$
      008F87                       1854 00207$:
                                   1855 ;	quantum/dynamic_keymap.c:535: dynamic_buffer_size_t chk_offset = 0;
      008F87 90 0B 54         [24] 1856 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_427
      008F8A E4               [12] 1857 	clr	a
      008F8B F0               [24] 1858 	movx	@dptr,a
                                   1859 ;	quantum/dynamic_keymap.c:536: dynamic_buffer_size_t chk_sz = count;
      008F8C 90 0B 55         [24] 1860 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_427
      008F8F E5 31            [12] 1861 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008F91 F0               [24] 1862 	movx	@dptr,a
                                   1863 ;	quantum/dynamic_keymap.c:539: if (offset % 2 != 0) {
      008F92 EC               [12] 1864 	mov	a,r4
      008F93 30 E0 33         [24] 1865 	jnb	acc.0,00111$
                                   1866 ;	quantum/dynamic_keymap.c:540: uint16_t kc = (eeprom_read_byte(target - 1) << 8) | buffer[0];
      008F96 EA               [12] 1867 	mov	a,r2
      008F97 24 FF            [12] 1868 	add	a,#0xff
      008F99 FE               [12] 1869 	mov	r6,a
      008F9A EB               [12] 1870 	mov	a,r3
      008F9B 34 FF            [12] 1871 	addc	a,#0xff
      008F9D FF               [12] 1872 	mov	r7,a
      008F9E 7D 00            [12] 1873 	mov	r5,#0x00
      008FA0 12 45 C9         [24] 1874 	lcall	_ak820_outline_0116
      008FA3 8D F0            [24] 1875 	mov	b, r5
      008FA5 12 42 E8         [24] 1876 	lcall	_eeprom_read_byte
      008FA8 AE 82            [24] 1877 	mov	r6,dpl
      008FAA 7F 00            [12] 1878 	mov	r7,#0x00
      008FAC 12 3A B5         [24] 1879 	lcall	_ak820_outline_0155
      008FAF E0               [24] 1880 	movx	a,@dptr
      008FB0 7C 00            [12] 1881 	mov	r4,#0x00
      008FB2 42 07            [12] 1882 	orl	ar7,a
      008FB4 EC               [12] 1883 	mov	a,r4
      008FB5 42 06            [12] 1884 	orl	ar6,a
                                   1885 ;	quantum/dynamic_keymap.c:541: if (kc == QK_BOOT)
      008FB7 BF 00 09         [24] 1886 	cjne	r7,#0x00,00109$
      008FBA BE 7C 06         [24] 1887 	cjne	r6,#0x7c,00109$
                                   1888 ;	quantum/dynamic_keymap.c:542: buffer[0] = 0xFF;
      008FBD 12 3A B5         [24] 1889 	lcall	_ak820_outline_0155
      008FC0 74 FF            [12] 1890 	mov	a,#0xff
      008FC2 F0               [24] 1891 	movx	@dptr,a
      008FC3                       1892 00109$:
                                   1893 ;	quantum/dynamic_keymap.c:545: chk_offset += 1;
      008FC3 90 0B 54         [24] 1894 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_427
      008FC6 74 01            [12] 1895 	mov	a,#0x01
      008FC8 F0               [24] 1896 	movx	@dptr,a
      008FC9                       1897 00111$:
                                   1898 ;	quantum/dynamic_keymap.c:549: if ((offset + size) % 2 != 0) {
      008FC9 90 0B 52         [24] 1899 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_420
      008FCC 12 3A 40         [24] 1900 	lcall	_ak820_outline_0051
      008FCF E5 2D            [12] 1901 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008FD1 2E               [12] 1902 	add	a, r6
      008FD2 FE               [12] 1903 	mov	r6,a
      008FD3 E5 2E            [12] 1904 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008FD5 3F               [12] 1905 	addc	a, r7
      008FD6 EE               [12] 1906 	mov	a,r6
      008FD7 30 E0 5A         [24] 1907 	jnb	acc.0,00115$
                                   1908 ;	quantum/dynamic_keymap.c:550: uint16_t kc = (buffer[count - 1] << 8) | eeprom_read_byte(target + count);
      008FDA AE 31            [24] 1909 	mov	r6,_dynamic_keymap_set_buffer_sloc2_1_0
      008FDC 7F 00            [12] 1910 	mov	r7,#0x00
      008FDE EE               [12] 1911 	mov	a,r6
      008FDF 24 FF            [12] 1912 	add	a,#0xff
      008FE1 FC               [12] 1913 	mov	r4,a
      008FE2 EF               [12] 1914 	mov	a,r7
      008FE3 34 FF            [12] 1915 	addc	a,#0xff
      008FE5 FD               [12] 1916 	mov	r5,a
      008FE6 EC               [12] 1917 	mov	a,r4
      008FE7 28               [12] 1918 	add	a, r0
      008FE8 F5 82            [12] 1919 	mov	dpl,a
      008FEA ED               [12] 1920 	mov	a,r5
      008FEB 39               [12] 1921 	addc	a, r1
      008FEC F5 83            [12] 1922 	mov	dph,a
      008FEE E0               [24] 1923 	movx	a,@dptr
      008FEF FC               [12] 1924 	mov	r4,a
      008FF0 7D 00            [12] 1925 	mov	r5,#0x00
      008FF2 E5 31            [12] 1926 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008FF4 2A               [12] 1927 	add	a, r2
      008FF5 FA               [12] 1928 	mov	r2,a
      008FF6 E4               [12] 1929 	clr	a
      008FF7 3B               [12] 1930 	addc	a, r3
      008FF8 FB               [12] 1931 	mov	r3,a
      008FF9 C0 00            [24] 1932 	push	ar0
      008FFB C0 01            [24] 1933 	push	ar1
      008FFD 8B 01            [24] 1934 	mov	ar1,r3
      008FFF 7B 00            [12] 1935 	mov	r3,#0x00
      009001 8A 82            [24] 1936 	mov	dpl, r2
      009003 89 83            [24] 1937 	mov	dph, r1
      009005 8B F0            [24] 1938 	mov	b, r3
      009007 12 42 E8         [24] 1939 	lcall	_eeprom_read_byte
      00900A AB 82            [24] 1940 	mov	r3, dpl
      00900C 7A 00            [12] 1941 	mov	r2,#0x00
      00900E EB               [12] 1942 	mov	a,r3
      00900F 12 45 DF         [24] 1943 	lcall	_ak820_outline_0141
                                   1944 ;	quantum/dynamic_keymap.c:551: if (kc == QK_BOOT)
      009012 BD 00 05         [24] 1945 	cjne	r5,#0x00,00212$
      009015 BC 7C 02         [24] 1946 	cjne	r4,#0x7c,00212$
      009018 80 06            [24] 1947 	sjmp	00213$
      00901A                       1948 00212$:
      00901A D0 01            [24] 1949 	pop	ar1
      00901C D0 00            [24] 1950 	pop	ar0
      00901E 80 0D            [24] 1951 	sjmp	00113$
      009020                       1952 00213$:
      009020 D0 01            [24] 1953 	pop	ar1
      009022 D0 00            [24] 1954 	pop	ar0
                                   1955 ;	quantum/dynamic_keymap.c:552: buffer[count - 1] = 0xFF;
      009024 1E               [12] 1956 	dec	r6
      009025 BE FF 01         [24] 1957 	cjne	r6,#0xff,00214$
      009028 1F               [12] 1958 	dec	r7
      009029                       1959 00214$:
      009029 EE               [12] 1960 	mov	a,r6
      00902A 12 94 C3         [24] 1961 	lcall	_ak820_outline_0127
      00902D                       1962 00113$:
                                   1963 ;	quantum/dynamic_keymap.c:555: chk_sz -= 1;
      00902D E5 31            [12] 1964 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      00902F 14               [12] 1965 	dec	a
      009030 90 0B 55         [24] 1966 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_427
      009033 F0               [24] 1967 	movx	@dptr,a
      009034                       1968 00115$:
                                   1969 ;	quantum/dynamic_keymap.c:559: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      009034 90 0B 54         [24] 1970 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_427
      009037 E0               [24] 1971 	movx	a,@dptr
      009038 90 0B 56         [24] 1972 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_434
      00903B F0               [24] 1973 	movx	@dptr,a
      00903C                       1974 00122$:
      00903C 90 0B 56         [24] 1975 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_434
      00903F E0               [24] 1976 	movx	a,@dptr
      009040 FF               [12] 1977 	mov	r7,a
      009041 90 0B 55         [24] 1978 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_427
      009044 E0               [24] 1979 	movx	a,@dptr
      009045 FE               [12] 1980 	mov	r6,a
      009046 C3               [12] 1981 	clr	c
      009047 EF               [12] 1982 	mov	a,r7
      009048 9E               [12] 1983 	subb	a,r6
      009049 50 47            [24] 1984 	jnc	00120$
                                   1985 ;	quantum/dynamic_keymap.c:560: uint16_t kc = (buffer[i] << 8) | buffer[i + 1];
      00904B EF               [12] 1986 	mov	a,r7
      00904C 28               [12] 1987 	add	a, r0
      00904D FD               [12] 1988 	mov	r5,a
      00904E E4               [12] 1989 	clr	a
      00904F 39               [12] 1990 	addc	a, r1
      009050 12 4B B6         [24] 1991 	lcall	_ak820_outline_0057
      009053 7B 00            [12] 1992 	mov	r3,#0x00
      009055 8C 2E            [24] 1993 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),r4
      009057 8B 2D            [24] 1994 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,r3
      009059 8F 02            [24] 1995 	mov	ar2,r7
      00905B 7F 00            [12] 1996 	mov	r7,#0x00
      00905D 74 01            [12] 1997 	mov	a,#0x01
      00905F 2A               [12] 1998 	add	a, r2
      009060 FB               [12] 1999 	mov	r3,a
      009061 E4               [12] 2000 	clr	a
      009062 3F               [12] 2001 	addc	a, r7
      009063 FC               [12] 2002 	mov	r4,a
      009064 EB               [12] 2003 	mov	a,r3
      009065 28               [12] 2004 	add	a, r0
      009066 F5 82            [12] 2005 	mov	dpl,a
      009068 EC               [12] 2006 	mov	a,r4
      009069 39               [12] 2007 	addc	a, r1
      00906A F5 83            [12] 2008 	mov	dph,a
      00906C E0               [24] 2009 	movx	a,@dptr
      00906D FC               [12] 2010 	mov	r4,a
      00906E 7B 00            [12] 2011 	mov	r3,#0x00
      009070 E5 2E            [12] 2012 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      009072 42 03            [12] 2013 	orl	ar3,a
                                   2014 ;	quantum/dynamic_keymap.c:561: if (kc == QK_BOOT) {
      009074 BC 00 12         [24] 2015 	cjne	r4,#0x00,00123$
      009077 BB 7C 0F         [24] 2016 	cjne	r3,#0x7c,00123$
                                   2017 ;	quantum/dynamic_keymap.c:562: buffer[i] = 0xFF;
      00907A 12 3A AA         [24] 2018 	lcall	_ak820_outline_0131
      00907D 74 FF            [12] 2019 	mov	a,#0xff
      00907F F0               [24] 2020 	movx	@dptr,a
                                   2021 ;	quantum/dynamic_keymap.c:563: buffer[i + 1] = 0xFF;
      009080 0A               [12] 2022 	inc	r2
      009081 BA 00 01         [24] 2023 	cjne	r2,#0x00,00218$
      009084 0F               [12] 2024 	inc	r7
      009085                       2025 00218$:
      009085 EA               [12] 2026 	mov	a,r2
      009086 12 94 C3         [24] 2027 	lcall	_ak820_outline_0127
      009089                       2028 00123$:
                                   2029 ;	quantum/dynamic_keymap.c:559: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      009089 90 0B 56         [24] 2030 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_434
      00908C E0               [24] 2031 	movx	a,@dptr
      00908D 24 02            [12] 2032 	add	a,#0x02
      00908F F0               [24] 2033 	movx	@dptr,a
      009090 80 AA            [24] 2034 	sjmp	00122$
      009092                       2035 00120$:
                                   2036 ;	quantum/dynamic_keymap.c:574: ak820_eeprom_write_block_xdata(buffer, (void *)(uintptr_t)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset), size);
      009092 90 0B 52         [24] 2037 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_420
      009095 12 3A 40         [24] 2038 	lcall	_ak820_outline_0051
      009098 74 40            [12] 2039 	mov	a,#0x40
      00909A 12 45 D9         [24] 2040 	lcall	_ak820_outline_0134
      00909D 90 05 9A         [24] 2041 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      0090A0 12 4B BE         [24] 2042 	lcall	_ak820_outline_0059
      0090A3 E4               [12] 2043 	clr	a
      0090A4 A3               [24] 2044 	inc	dptr
      0090A5 F0               [24] 2045 	movx	@dptr,a
      0090A6 90 05 9D         [24] 2046 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0090A9 E5 2F            [12] 2047 	mov	a,_dynamic_keymap_set_buffer_sloc1_1_0
      0090AB F0               [24] 2048 	movx	@dptr,a
      0090AC E5 30            [12] 2049 	mov	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      0090AE A3               [24] 2050 	inc	dptr
      0090AF F0               [24] 2051 	movx	@dptr,a
      0090B0 12 3A B5         [24] 2052 	lcall	_ak820_outline_0155
                                   2053 ;	quantum/dynamic_keymap.c:584: }
      0090B3 02 43 AF         [24] 2054 	ljmp	_ak820_eeprom_write_block_xdata
                                   2055 ;------------------------------------------------------------
                                   2056 ;Allocation info for local variables in function 'keycode_at_keymap_location'
                                   2057 ;------------------------------------------------------------
                                   2058 ;row           Allocated with name '_keycode_at_keymap_location_PARM_2'
                                   2059 ;column        Allocated with name '_keycode_at_keymap_location_PARM_3'
                                   2060 ;layer_num     Allocated with name '_keycode_at_keymap_location_layer_num_10000_438'
                                   2061 ;------------------------------------------------------------
                                   2062 ;	quantum/dynamic_keymap.c:586: uint16_t keycode_at_keymap_location(uint8_t layer_num, uint8_t row, uint8_t column) {
                                   2063 ;	-----------------------------------------
                                   2064 ;	 function keycode_at_keymap_location
                                   2065 ;	-----------------------------------------
      0090B6                       2066 _keycode_at_keymap_location:
      0090B6 E5 82            [12] 2067 	mov	a,dpl
      0090B8 90 0B 59         [24] 2068 	mov	dptr,#_keycode_at_keymap_location_layer_num_10000_438
      0090BB F0               [24] 2069 	movx	@dptr,a
                                   2070 ;	quantum/dynamic_keymap.c:587: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && row < MATRIX_ROWS && column < MATRIX_COLS) {
      0090BC E0               [24] 2071 	movx	a,@dptr
      0090BD FF               [12] 2072 	mov	r7,a
      0090BE BF 06 00         [24] 2073 	cjne	r7,#0x06,00128$
      0090C1                       2074 00128$:
      0090C1 50 23            [24] 2075 	jnc	00102$
      0090C3 90 0B 57         [24] 2076 	mov	dptr,#_keycode_at_keymap_location_PARM_2
      0090C6 E0               [24] 2077 	movx	a,@dptr
      0090C7 FE               [12] 2078 	mov	r6,a
      0090C8 BE 10 00         [24] 2079 	cjne	r6,#0x10,00130$
      0090CB                       2080 00130$:
      0090CB 50 19            [24] 2081 	jnc	00102$
      0090CD 90 0B 58         [24] 2082 	mov	dptr,#_keycode_at_keymap_location_PARM_3
      0090D0 E0               [24] 2083 	movx	a,@dptr
      0090D1 FD               [12] 2084 	mov	r5,a
      0090D2 BD 08 00         [24] 2085 	cjne	r5,#0x08,00132$
      0090D5                       2086 00132$:
      0090D5 50 0F            [24] 2087 	jnc	00102$
                                   2088 ;	quantum/dynamic_keymap.c:588: return dynamic_keymap_get_keycode(layer_num, row, column);
      0090D7 90 0B 0B         [24] 2089 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      0090DA EE               [12] 2090 	mov	a,r6
      0090DB F0               [24] 2091 	movx	@dptr,a
      0090DC 90 0B 0C         [24] 2092 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      0090DF ED               [12] 2093 	mov	a,r5
      0090E0 F0               [24] 2094 	movx	@dptr,a
      0090E1 8F 82            [24] 2095 	mov	dpl, r7
      0090E3 02 8A 55         [24] 2096 	ljmp	_dynamic_keymap_get_keycode
      0090E6                       2097 00102$:
                                   2098 ;	quantum/dynamic_keymap.c:590: return KC_NO;
      0090E6 90 00 00         [24] 2099 	mov	dptr,#0x0000
                                   2100 ;	quantum/dynamic_keymap.c:591: }
      0090E9 22               [24] 2101 	ret
                                   2102 ;------------------------------------------------------------
                                   2103 ;Allocation info for local variables in function 'keycode_at_encodermap_location'
                                   2104 ;------------------------------------------------------------
                                   2105 ;encoder_idx   Allocated with name '_keycode_at_encodermap_location_PARM_2'
                                   2106 ;clockwise     Allocated with name '_keycode_at_encodermap_location_PARM_3'
                                   2107 ;layer_num     Allocated with name '_keycode_at_encodermap_location_layer_num_10000_442'
                                   2108 ;------------------------------------------------------------
                                   2109 ;	quantum/dynamic_keymap.c:594: uint16_t keycode_at_encodermap_location(uint8_t layer_num, uint8_t encoder_idx, bool clockwise) {
                                   2110 ;	-----------------------------------------
                                   2111 ;	 function keycode_at_encodermap_location
                                   2112 ;	-----------------------------------------
      0090EA                       2113 _keycode_at_encodermap_location:
      0090EA E5 82            [12] 2114 	mov	a,dpl
      0090EC 90 0B 5C         [24] 2115 	mov	dptr,#_keycode_at_encodermap_location_layer_num_10000_442
      0090EF F0               [24] 2116 	movx	@dptr,a
                                   2117 ;	quantum/dynamic_keymap.c:595: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && encoder_idx < NUM_ENCODERS) {
      0090F0 E0               [24] 2118 	movx	a,@dptr
      0090F1 FF               [12] 2119 	mov	r7,a
      0090F2 BF 06 00         [24] 2120 	cjne	r7,#0x06,00120$
      0090F5                       2121 00120$:
      0090F5 50 1E            [24] 2122 	jnc	00102$
      0090F7 90 0B 5A         [24] 2123 	mov	dptr,#_keycode_at_encodermap_location_PARM_2
      0090FA E0               [24] 2124 	movx	a,@dptr
      0090FB FE               [12] 2125 	mov	r6,a
      0090FC BE 01 00         [24] 2126 	cjne	r6,#0x01,00122$
      0090FF                       2127 00122$:
      0090FF 50 14            [24] 2128 	jnc	00102$
                                   2129 ;	quantum/dynamic_keymap.c:596: return dynamic_keymap_get_encoder(layer_num, encoder_idx, clockwise);
      009101 90 0B 5B         [24] 2130 	mov	dptr,#_keycode_at_encodermap_location_PARM_3
      009104 E0               [24] 2131 	movx	a,@dptr
      009105 FE               [12] 2132 	mov	r6,a
      009106 90 0B 15         [24] 2133 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      009109 E4               [12] 2134 	clr	a
      00910A F0               [24] 2135 	movx	@dptr,a
      00910B 90 0B 16         [24] 2136 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      00910E EE               [12] 2137 	mov	a,r6
      00910F F0               [24] 2138 	movx	@dptr,a
      009110 8F 82            [24] 2139 	mov	dpl, r7
      009112 02 8B 14         [24] 2140 	ljmp	_dynamic_keymap_get_encoder
      009115                       2141 00102$:
                                   2142 ;	quantum/dynamic_keymap.c:598: return KC_NO;
      009115 90 00 00         [24] 2143 	mov	dptr,#0x0000
                                   2144 ;	quantum/dynamic_keymap.c:599: }
      009118 22               [24] 2145 	ret
                                   2146 ;------------------------------------------------------------
                                   2147 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_count'
                                   2148 ;------------------------------------------------------------
                                   2149 ;	quantum/dynamic_keymap.c:602: uint8_t dynamic_keymap_macro_get_count(void) {
                                   2150 ;	-----------------------------------------
                                   2151 ;	 function dynamic_keymap_macro_get_count
                                   2152 ;	-----------------------------------------
      009119                       2153 _dynamic_keymap_macro_get_count:
                                   2154 ;	quantum/dynamic_keymap.c:603: return DYNAMIC_KEYMAP_MACRO_COUNT;
      009119 75 82 10         [24] 2155 	mov	dpl, #0x10
                                   2156 ;	quantum/dynamic_keymap.c:604: }
      00911C 22               [24] 2157 	ret
                                   2158 ;------------------------------------------------------------
                                   2159 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer_size'
                                   2160 ;------------------------------------------------------------
                                   2161 ;	quantum/dynamic_keymap.c:606: uint16_t dynamic_keymap_macro_get_buffer_size(void) {
                                   2162 ;	-----------------------------------------
                                   2163 ;	 function dynamic_keymap_macro_get_buffer_size
                                   2164 ;	-----------------------------------------
      00911D                       2165 _dynamic_keymap_macro_get_buffer_size:
                                   2166 ;	quantum/dynamic_keymap.c:607: return DYNAMIC_KEYMAP_MACRO_EEPROM_SIZE;
      00911D 90 20 00         [24] 2167 	mov	dptr,#0x2000
                                   2168 ;	quantum/dynamic_keymap.c:608: }
      009120 22               [24] 2169 	ret
                                   2170 ;------------------------------------------------------------
                                   2171 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer'
                                   2172 ;------------------------------------------------------------
                                   2173 ;sloc0         Allocated with name '_dynamic_keymap_macro_get_buffer_sloc0_1_0'
                                   2174 ;size          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_2'
                                   2175 ;data          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_3'
                                   2176 ;offset        Allocated with name '_dynamic_keymap_macro_get_buffer_offset_10000_450'
                                   2177 ;------------------------------------------------------------
                                   2178 ;	quantum/dynamic_keymap.c:610: void dynamic_keymap_macro_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2179 ;	-----------------------------------------
                                   2180 ;	 function dynamic_keymap_macro_get_buffer
                                   2181 ;	-----------------------------------------
      009121                       2182 _dynamic_keymap_macro_get_buffer:
      009121 12 3A 83         [24] 2183 	lcall	_ak820_outline_0103
      009124 90 0B 62         [24] 2184 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_450
      009127 12 3A 88         [24] 2185 	lcall	_ak820_outline_0104
                                   2186 ;	quantum/dynamic_keymap.c:613: ak820_macro_length(), offset, size, data);
      00912A 12 2A DF         [24] 2187 	lcall	_ak820_macro_length
      00912D 12 45 D4         [24] 2188 	lcall	_ak820_outline_0132
      009130 90 0B 62         [24] 2189 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_450
      009133 12 3A 5F         [24] 2190 	lcall	_ak820_outline_0060
      009136 90 0B 5D         [24] 2191 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_2
      009139 E0               [24] 2192 	movx	a,@dptr
      00913A F5 32            [12] 2193 	mov	_dynamic_keymap_macro_get_buffer_sloc0_1_0,a
      00913C A3               [24] 2194 	inc	dptr
      00913D E0               [24] 2195 	movx	a,@dptr
      00913E F5 33            [12] 2196 	mov	(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1),a
      009140 90 0B 5F         [24] 2197 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_3
      009143 12 3A 7D         [24] 2198 	lcall	_ak820_outline_0100
      009146 A3               [24] 2199 	inc	dptr
      009147 E0               [24] 2200 	movx	a,@dptr
      009148 FB               [12] 2201 	mov	r3,a
      009149 90 0B 3A         [24] 2202 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      00914C 12 4B BE         [24] 2203 	lcall	_ak820_outline_0059
      00914F 90 0B 3C         [24] 2204 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      009152 12 3A 65         [24] 2205 	lcall	_ak820_outline_0071
      009155 90 0B 3E         [24] 2206 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      009158 E5 32            [12] 2207 	mov	a,_dynamic_keymap_macro_get_buffer_sloc0_1_0
      00915A F0               [24] 2208 	movx	@dptr,a
      00915B E5 33            [12] 2209 	mov	a,(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1)
      00915D A3               [24] 2210 	inc	dptr
      00915E F0               [24] 2211 	movx	@dptr,a
      00915F 90 0B 40         [24] 2212 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      009162 E8               [12] 2213 	mov	a,r0
      009163 F0               [24] 2214 	movx	@dptr,a
      009164 E9               [12] 2215 	mov	a,r1
      009165 A3               [24] 2216 	inc	dptr
      009166 F0               [24] 2217 	movx	@dptr,a
      009167 EB               [12] 2218 	mov	a,r3
      009168 A3               [24] 2219 	inc	dptr
      009169 F0               [24] 2220 	movx	@dptr,a
      00916A 90 08 00         [24] 2221 	mov	dptr,#0x0800
                                   2222 ;	quantum/dynamic_keymap.c:635: }
      00916D 02 8E 33         [24] 2223 	ljmp	_ak820_dynamic_read_buffer
                                   2224 ;------------------------------------------------------------
                                   2225 ;Allocation info for local variables in function 'dynamic_keymap_macro_set_buffer'
                                   2226 ;------------------------------------------------------------
                                   2227 ;size          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_2'
                                   2228 ;data          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_3'
                                   2229 ;offset        Allocated with name '_dynamic_keymap_macro_set_buffer_offset_10000_452'
                                   2230 ;------------------------------------------------------------
                                   2231 ;	quantum/dynamic_keymap.c:638: bool dynamic_keymap_macro_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2232 ;	-----------------------------------------
                                   2233 ;	 function dynamic_keymap_macro_set_buffer
                                   2234 ;	-----------------------------------------
      009170                       2235 _dynamic_keymap_macro_set_buffer:
      009170 12 3A 83         [24] 2236 	lcall	_ak820_outline_0103
      009173 90 0B 69         [24] 2237 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_452
      009176 12 3A 88         [24] 2238 	lcall	_ak820_outline_0104
                                   2239 ;	quantum/dynamic_keymap.c:639: return ak820_macro_write(offset, size, data);
      009179 90 0B 69         [24] 2240 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_452
      00917C 12 3A 40         [24] 2241 	lcall	_ak820_outline_0051
      00917F 90 0B 64         [24] 2242 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_2
      009182 12 3A 5F         [24] 2243 	lcall	_ak820_outline_0060
      009185 90 0B 66         [24] 2244 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_3
      009188 12 52 6E         [24] 2245 	lcall	_ak820_outline_0087
      00918B 90 05 20         [24] 2246 	mov	dptr,#_ak820_macro_write_PARM_2
      00918E 12 3A 65         [24] 2247 	lcall	_ak820_outline_0071
      009191 90 05 22         [24] 2248 	mov	dptr,#_ak820_macro_write_PARM_3
      009194 E9               [12] 2249 	mov	a,r1
      009195 12 52 87         [24] 2250 	lcall	_ak820_outline_0154
      009198 12 45 AB         [24] 2251 	lcall	_ak820_outline_0061
                                   2252 ;	quantum/dynamic_keymap.c:640: }
      00919B 02 2A F9         [24] 2253 	ljmp	_ak820_macro_write
                                   2254 ;------------------------------------------------------------
                                   2255 ;Allocation info for local variables in function 'dynamic_keymap_macro_reset'
                                   2256 ;------------------------------------------------------------
                                   2257 ;	quantum/dynamic_keymap.c:655: void dynamic_keymap_macro_reset(void) {
                                   2258 ;	-----------------------------------------
                                   2259 ;	 function dynamic_keymap_macro_reset
                                   2260 ;	-----------------------------------------
      00919E                       2261 _dynamic_keymap_macro_reset:
                                   2262 ;	quantum/dynamic_keymap.c:657: ak820_macro_reset();
                                   2263 ;	quantum/dynamic_keymap.c:666: }
      00919E 02 2E 18         [24] 2264 	ljmp	_ak820_macro_reset
                                   2265 ;------------------------------------------------------------
                                   2266 ;Allocation info for local variables in function 'decode_keycode'
                                   2267 ;------------------------------------------------------------
                                   2268 ;kc            Allocated with name '_decode_keycode_kc_10000_456'
                                   2269 ;------------------------------------------------------------
                                   2270 ;	quantum/dynamic_keymap.c:668: static uint16_t decode_keycode(uint16_t kc) {
                                   2271 ;	-----------------------------------------
                                   2272 ;	 function decode_keycode
                                   2273 ;	-----------------------------------------
      0091A1                       2274 _decode_keycode:
      0091A1 12 3A 83         [24] 2275 	lcall	_ak820_outline_0103
      0091A4 90 0B 6B         [24] 2276 	mov	dptr,#_decode_keycode_kc_10000_456
      0091A7 12 3A 88         [24] 2277 	lcall	_ak820_outline_0104
                                   2278 ;	quantum/dynamic_keymap.c:670: if (kc > 0xFF00)
      0091AA 90 0B 6B         [24] 2279 	mov	dptr,#_decode_keycode_kc_10000_456
      0091AD 12 3A 0B         [24] 2280 	lcall	_ak820_outline_0011
      0091B0 C3               [12] 2281 	clr	c
      0091B1 E4               [12] 2282 	clr	a
      0091B2 9C               [12] 2283 	subb	a,r4
      0091B3 74 FF            [12] 2284 	mov	a,#0xff
      0091B5 9D               [12] 2285 	subb	a,r5
      0091B6 50 08            [24] 2286 	jnc	00102$
                                   2287 ;	free result
                                   2288 ;	quantum/dynamic_keymap.c:671: return (kc & 0xFF) << 8;
      0091B8 8C 05            [24] 2289 	mov	ar5,r4
      0091BA 7C 00            [12] 2290 	mov	r4,#0x00
      0091BC 12 3A A0         [24] 2291 	lcall	_ak820_outline_0121
      0091BF 22               [24] 2292 	ret
      0091C0                       2293 00102$:
                                   2294 ;	quantum/dynamic_keymap.c:672: return kc;
      0091C0 12 45 C9         [24] 2295 	lcall	_ak820_outline_0116
                                   2296 ;	quantum/dynamic_keymap.c:673: }
      0091C3 22               [24] 2297 	ret
                                   2298 ;------------------------------------------------------------
                                   2299 ;Allocation info for local variables in function 'dynamic_keymap_macro_send'
                                   2300 ;------------------------------------------------------------
                                   2301 ;id            Allocated with name '_dynamic_keymap_macro_send_id_10000_459'
                                   2302 ;sending       Allocated with name '_dynamic_keymap_macro_send_sending_10000_460'
                                   2303 ;p             Allocated with name '_dynamic_keymap_macro_send_p_10001_465'
                                   2304 ;end           Allocated with name '_dynamic_keymap_macro_send_end_10002_466'
                                   2305 ;data          Allocated with name '_dynamic_keymap_macro_send_data_10003_472'
                                   2306 ;kc            Allocated with name '_dynamic_keymap_macro_send_kc_110003_490'
                                   2307 ;d0            Allocated with name '_dynamic_keymap_macro_send_d0_80003_494'
                                   2308 ;d1            Allocated with name '_dynamic_keymap_macro_send_d1_80003_494'
                                   2309 ;ms            Allocated with name '_dynamic_keymap_macro_send_ms_80004_496'
                                   2310 ;i             Allocated with name '_dynamic_keymap_macro_send_i_100004_498'
                                   2311 ;delay         Allocated with name '_dynamic_keymap_macro_send_delay_50003_502'
                                   2312 ;i             Allocated with name '_dynamic_keymap_macro_send_i_70003_504'
                                   2313 ;------------------------------------------------------------
                                   2314 ;	quantum/dynamic_keymap.c:675: void dynamic_keymap_macro_send(uint8_t id) {
                                   2315 ;	-----------------------------------------
                                   2316 ;	 function dynamic_keymap_macro_send
                                   2317 ;	-----------------------------------------
      0091C4                       2318 _dynamic_keymap_macro_send:
      0091C4 E5 82            [12] 2319 	mov	a,dpl
      0091C6 90 0B 6D         [24] 2320 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_459
      0091C9 F0               [24] 2321 	movx	@dptr,a
                                   2322 ;	quantum/dynamic_keymap.c:680: if (sending) return;
      0091CA 90 0B 6E         [24] 2323 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_460
      0091CD E0               [24] 2324 	movx	a,@dptr
      0091CE 60 01            [24] 2325 	jz	00102$
      0091D0 22               [24] 2326 	ret
      0091D1                       2327 00102$:
                                   2328 ;	quantum/dynamic_keymap.c:682: if (id >= DYNAMIC_KEYMAP_MACRO_COUNT) {
      0091D1 90 0B 6D         [24] 2329 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_459
      0091D4 E0               [24] 2330 	movx	a,@dptr
      0091D5 FF               [12] 2331 	mov	r7,a
      0091D6 BF 10 00         [24] 2332 	cjne	r7,#0x10,00422$
      0091D9                       2333 00422$:
      0091D9 40 01            [24] 2334 	jc	00104$
                                   2335 ;	quantum/dynamic_keymap.c:683: return;
      0091DB 22               [24] 2336 	ret
      0091DC                       2337 00104$:
                                   2338 ;	quantum/dynamic_keymap.c:689: if (!ak820_macro_ready()) return;
      0091DC C0 07            [24] 2339 	push	ar7
      0091DE 12 2A A6         [24] 2340 	lcall	_ak820_macro_ready
      0091E1 E5 82            [12] 2341 	mov	a, dpl
      0091E3 D0 07            [24] 2342 	pop	ar7
      0091E5 70 01            [24] 2343 	jnz	00106$
      0091E7 22               [24] 2344 	ret
      0091E8                       2345 00106$:
                                   2346 ;	quantum/dynamic_keymap.c:706: p = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR;
      0091E8 90 0B 6F         [24] 2347 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_465
      0091EB E4               [12] 2348 	clr	a
      0091EC F0               [24] 2349 	movx	@dptr,a
      0091ED 74 08            [12] 2350 	mov	a,#0x08
      0091EF A3               [24] 2351 	inc	dptr
      0091F0 F0               [24] 2352 	movx	@dptr,a
                                   2353 ;	quantum/dynamic_keymap.c:707: uint16_t end = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR + ak820_macro_length();
      0091F1 C0 07            [24] 2354 	push	ar7
      0091F3 12 2A DF         [24] 2355 	lcall	_ak820_macro_length
      0091F6 AD 82            [24] 2356 	mov	r5, dpl
      0091F8 AE 83            [24] 2357 	mov	r6, dph
      0091FA D0 07            [24] 2358 	pop	ar7
      0091FC 74 08            [12] 2359 	mov	a,#0x08
      0091FE 2E               [12] 2360 	add	a, r6
      0091FF FE               [12] 2361 	mov	r6,a
                                   2362 ;	quantum/dynamic_keymap.c:712: while (id > 0) {
      009200 7B 00            [12] 2363 	mov	r3,#0x00
      009202 7C 08            [12] 2364 	mov	r4,#0x08
      009204                       2365 00111$:
      009204 EF               [12] 2366 	mov	a,r7
      009205 60 31            [24] 2367 	jz	00113$
                                   2368 ;	quantum/dynamic_keymap.c:716: if (p == end) {
      009207 EB               [12] 2369 	mov	a,r3
      009208 B5 05 05         [24] 2370 	cjne	a,ar5,00108$
      00920B EC               [12] 2371 	mov	a,r4
      00920C B5 06 01         [24] 2372 	cjne	a,ar6,00108$
                                   2373 ;	quantum/dynamic_keymap.c:717: return;
      00920F 22               [24] 2374 	ret
      009210                       2375 00108$:
                                   2376 ;	quantum/dynamic_keymap.c:719: if (eeprom_read_byte((const uint8_t *)(uintptr_t)p) == 0) {
      009210 8B 01            [24] 2377 	mov	ar1,r3
      009212 8C 02            [24] 2378 	mov	ar2,r4
      009214 8A 00            [24] 2379 	mov	ar0,r2
      009216 7A 00            [12] 2380 	mov	r2,#0x00
      009218 89 82            [24] 2381 	mov	dpl, r1
      00921A 88 83            [24] 2382 	mov	dph, r0
      00921C 8A F0            [24] 2383 	mov	b, r2
      00921E 12 42 E8         [24] 2384 	lcall	_eeprom_read_byte
      009221 E5 82            [12] 2385 	mov	a, dpl
      009223 70 06            [24] 2386 	jnz	00110$
                                   2387 ;	quantum/dynamic_keymap.c:720: --id;
      009225 1F               [12] 2388 	dec	r7
      009226 90 0B 6D         [24] 2389 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_459
      009229 EF               [12] 2390 	mov	a,r7
      00922A F0               [24] 2391 	movx	@dptr,a
      00922B                       2392 00110$:
                                   2393 ;	quantum/dynamic_keymap.c:722: ++p;
      00922B 0B               [12] 2394 	inc	r3
      00922C BB 00 01         [24] 2395 	cjne	r3,#0x00,00429$
      00922F 0C               [12] 2396 	inc	r4
      009230                       2397 00429$:
      009230 90 0B 6F         [24] 2398 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_465
      009233 12 3A 6B         [24] 2399 	lcall	_ak820_outline_0076
      009236 80 CC            [24] 2400 	sjmp	00111$
      009238                       2401 00113$:
                                   2402 ;	quantum/dynamic_keymap.c:728: sending = true;
      009238 90 0B 6E         [24] 2403 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_460
      00923B 74 01            [12] 2404 	mov	a,#0x01
      00923D F0               [24] 2405 	movx	@dptr,a
                                   2406 ;	quantum/dynamic_keymap.c:730: ak820_macro_cancelled = ak820_macro_primitive = false;
      00923E 12 94 DB         [24] 2407 	lcall	_ak820_outline_0162
      009241 90 09 B7         [24] 2408 	mov	dptr,#_ak820_macro_cancelled
      009244 F0               [24] 2409 	movx	@dptr,a
                                   2410 ;	quantum/dynamic_keymap.c:735: char data[4] = {0, 0, 0, 0};
      009245 90 0B 71         [24] 2411 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_472
      009248 F0               [24] 2412 	movx	@dptr,a
      009249 90 0B 72         [24] 2413 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_472 + 0x0001)
      00924C F0               [24] 2414 	movx	@dptr,a
      00924D 90 0B 73         [24] 2415 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_472 + 0x0002)
      009250 F0               [24] 2416 	movx	@dptr,a
      009251 90 0B 74         [24] 2417 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_472 + 0x0003)
      009254 F0               [24] 2418 	movx	@dptr,a
                                   2419 ;	quantum/dynamic_keymap.c:738: while (p < end
      009255                       2420 00167$:
                                   2421 ;	quantum/dynamic_keymap.c:740: && !ak820_macro_cancelled
      009255 90 0B 6F         [24] 2422 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_465
      009258 E0               [24] 2423 	movx	a,@dptr
      009259 FC               [12] 2424 	mov	r4,a
      00925A A3               [24] 2425 	inc	dptr
      00925B E0               [24] 2426 	movx	a,@dptr
      00925C FF               [12] 2427 	mov	r7,a
      00925D C3               [12] 2428 	clr	c
      00925E EC               [12] 2429 	mov	a,r4
      00925F 9D               [12] 2430 	subb	a,r5
      009260 EF               [12] 2431 	mov	a,r7
      009261 9E               [12] 2432 	subb	a,r6
      009262 40 02            [24] 2433 	jc	00430$
      009264 81 69            [12] 2434 	ajmp	00169$
      009266                       2435 00430$:
      009266 90 09 B7         [24] 2436 	mov	dptr,#_ak820_macro_cancelled
      009269 E0               [24] 2437 	movx	a,@dptr
      00926A 60 02            [24] 2438 	jz	00431$
      00926C 81 69            [12] 2439 	ajmp	00169$
      00926E                       2440 00431$:
                                   2441 ;	quantum/dynamic_keymap.c:743: data[0] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      00926E 8C 02            [24] 2442 	mov	ar2,r4
      009270 8F 03            [24] 2443 	mov	ar3,r7
      009272 90 0B 6F         [24] 2444 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_465
      009275 74 01            [12] 2445 	mov	a,#0x01
      009277 2C               [12] 2446 	add	a, r4
      009278 F0               [24] 2447 	movx	@dptr,a
      009279 E4               [12] 2448 	clr	a
      00927A 3F               [12] 2449 	addc	a, r7
      00927B A3               [24] 2450 	inc	dptr
      00927C F0               [24] 2451 	movx	@dptr,a
      00927D 7F 00            [12] 2452 	mov	r7,#0x00
      00927F 12 45 E5         [24] 2453 	lcall	_ak820_outline_0142
      009282 8F F0            [24] 2454 	mov	b, r7
      009284 12 42 E8         [24] 2455 	lcall	_eeprom_read_byte
      009287 AF 82            [24] 2456 	mov	r7, dpl
      009289 90 0B 71         [24] 2457 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_472
      00928C EF               [12] 2458 	mov	a,r7
      00928D F0               [24] 2459 	movx	@dptr,a
                                   2460 ;	quantum/dynamic_keymap.c:744: data[1] = 0;
      00928E 90 0B 72         [24] 2461 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_472 + 0x0001)
      009291 E4               [12] 2462 	clr	a
      009292 F0               [24] 2463 	movx	@dptr,a
                                   2464 ;	quantum/dynamic_keymap.c:746: if (data[0] == 0) {
      009293 90 0B 71         [24] 2465 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_472
      009296 E0               [24] 2466 	movx	a,@dptr
      009297 70 02            [24] 2467 	jnz	00432$
      009299 81 69            [12] 2468 	ajmp	00169$
      00929B                       2469 00432$:
                                   2470 ;	quantum/dynamic_keymap.c:749: if (data[0] == SS_QMK_PREFIX) {
      00929B 90 0B 71         [24] 2471 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_472
      00929E E0               [24] 2472 	movx	a,@dptr
      00929F FF               [12] 2473 	mov	r7,a
      0092A0 BF 01 02         [24] 2474 	cjne	r7,#0x01,00433$
      0092A3 80 02            [24] 2475 	sjmp	00434$
      0092A5                       2476 00433$:
      0092A5 81 4C            [12] 2477 	ajmp	00164$
      0092A7                       2478 00434$:
                                   2479 ;	quantum/dynamic_keymap.c:752: data[1] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      0092A7 12 94 71         [24] 2480 	lcall	_ak820_outline_0000
      0092AA 12 42 E8         [24] 2481 	lcall	_eeprom_read_byte
      0092AD AF 82            [24] 2482 	mov	r7, dpl
      0092AF 90 0B 72         [24] 2483 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_472 + 0x0001)
      0092B2 EF               [12] 2484 	mov	a,r7
      0092B3 F0               [24] 2485 	movx	@dptr,a
                                   2486 ;	quantum/dynamic_keymap.c:753: if (data[1] == 0)
      0092B4 EF               [12] 2487 	mov	a,r7
      0092B5 70 02            [24] 2488 	jnz	00435$
      0092B7 81 69            [12] 2489 	ajmp	00169$
      0092B9                       2490 00435$:
                                   2491 ;	quantum/dynamic_keymap.c:755: if (data[1] == SS_TAP_CODE || data[1] == SS_DOWN_CODE || data[1] == SS_UP_CODE) {
      0092B9 12 94 A9         [24] 2492 	lcall	_ak820_outline_0089
      0092BC BF 01 02         [24] 2493 	cjne	r7,#0x01,00436$
      0092BF 80 12            [24] 2494 	sjmp	00151$
      0092C1                       2495 00436$:
      0092C1 12 94 A9         [24] 2496 	lcall	_ak820_outline_0089
      0092C4 BF 02 02         [24] 2497 	cjne	r7,#0x02,00437$
      0092C7 80 0A            [24] 2498 	sjmp	00151$
      0092C9                       2499 00437$:
      0092C9 12 94 A9         [24] 2500 	lcall	_ak820_outline_0089
      0092CC BF 03 02         [24] 2501 	cjne	r7,#0x03,00438$
      0092CF 80 02            [24] 2502 	sjmp	00439$
      0092D1                       2503 00438$:
      0092D1 61 32            [12] 2504 	ajmp	00152$
      0092D3                       2505 00439$:
      0092D3                       2506 00151$:
                                   2507 ;	quantum/dynamic_keymap.c:757: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      0092D3 12 94 71         [24] 2508 	lcall	_ak820_outline_0000
      0092D6 12 42 E8         [24] 2509 	lcall	_eeprom_read_byte
      0092D9 12 94 F3         [24] 2510 	lcall	_ak820_outline_0177
                                   2511 ;	quantum/dynamic_keymap.c:761: if (data[2] != 0) {
      0092DC 70 02            [24] 2512 	jnz	00440$
      0092DE 41 55            [12] 2513 	ajmp	00167$
      0092E0                       2514 00440$:
                                   2515 ;	quantum/dynamic_keymap.c:763: ak820_macro_primitive = data[1] != SS_TAP_CODE;
      0092E0 12 94 A9         [24] 2516 	lcall	_ak820_outline_0089
      0092E3 BF 01 03         [24] 2517 	cjne	r7,#0x01,00441$
      0092E6 D3               [12] 2518 	setb	c
      0092E7 80 01            [24] 2519 	sjmp	00442$
      0092E9                       2520 00441$:
      0092E9 C3               [12] 2521 	clr	c
      0092EA                       2522 00442$:
      0092EA 92 25            [24] 2523 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      0092EC 90 09 B6         [24] 2524 	mov	dptr,#_ak820_macro_primitive
      0092EF B3               [12] 2525 	cpl	c
      0092F0 E4               [12] 2526 	clr	a
      0092F1 33               [12] 2527 	rlc	a
      0092F2 F0               [24] 2528 	movx	@dptr,a
                                   2529 ;	quantum/dynamic_keymap.c:765: if (data[1] == SS_TAP_CODE) tap_code((uint8_t)data[2]);
      0092F3 12 94 A9         [24] 2530 	lcall	_ak820_outline_0089
      0092F6 BF 01 10         [24] 2531 	cjne	r7,#0x01,00122$
      0092F9 12 94 D4         [24] 2532 	lcall	_ak820_outline_0150
      0092FC C0 06            [24] 2533 	push	ar6
      0092FE C0 05            [24] 2534 	push	ar5
      009300 12 7C 93         [24] 2535 	lcall	_tap_code
      009303 D0 05            [24] 2536 	pop	ar5
      009305 D0 06            [24] 2537 	pop	ar6
      009307 80 24            [24] 2538 	sjmp	00123$
      009309                       2539 00122$:
                                   2540 ;	quantum/dynamic_keymap.c:766: else if (data[1] == SS_DOWN_CODE) register_code((uint8_t)data[2]);
      009309 12 94 A9         [24] 2541 	lcall	_ak820_outline_0089
      00930C BF 02 10         [24] 2542 	cjne	r7,#0x02,00119$
      00930F 12 94 D4         [24] 2543 	lcall	_ak820_outline_0150
      009312 C0 06            [24] 2544 	push	ar6
      009314 C0 05            [24] 2545 	push	ar5
      009316 12 7B 64         [24] 2546 	lcall	_register_code
      009319 D0 05            [24] 2547 	pop	ar5
      00931B D0 06            [24] 2548 	pop	ar6
      00931D 80 0E            [24] 2549 	sjmp	00123$
      00931F                       2550 00119$:
                                   2551 ;	quantum/dynamic_keymap.c:767: else unregister_code((uint8_t)data[2]);
      00931F 12 94 D4         [24] 2552 	lcall	_ak820_outline_0150
      009322 C0 06            [24] 2553 	push	ar6
      009324 C0 05            [24] 2554 	push	ar5
      009326 12 7B E8         [24] 2555 	lcall	_unregister_code
      009329 D0 05            [24] 2556 	pop	ar5
      00932B D0 06            [24] 2557 	pop	ar6
      00932D                       2558 00123$:
                                   2559 ;	quantum/dynamic_keymap.c:769: ak820_macro_primitive = false;
      00932D 12 94 DB         [24] 2560 	lcall	_ak820_outline_0162
      009330 41 55            [12] 2561 	ajmp	00167$
      009332                       2562 00152$:
                                   2563 ;	quantum/dynamic_keymap.c:777: } else if (data[1] == VIAL_MACRO_EXT_TAP || data[1] == VIAL_MACRO_EXT_DOWN || data[1] == VIAL_MACRO_EXT_UP) {
      009332 12 94 A9         [24] 2564 	lcall	_ak820_outline_0089
      009335 BF 05 02         [24] 2565 	cjne	r7,#0x05,00447$
      009338 80 12            [24] 2566 	sjmp	00146$
      00933A                       2567 00447$:
      00933A 12 94 A9         [24] 2568 	lcall	_ak820_outline_0089
      00933D BF 06 02         [24] 2569 	cjne	r7,#0x06,00448$
      009340 80 0A            [24] 2570 	sjmp	00146$
      009342                       2571 00448$:
      009342 12 94 A9         [24] 2572 	lcall	_ak820_outline_0089
      009345 BF 07 02         [24] 2573 	cjne	r7,#0x07,00449$
      009348 80 02            [24] 2574 	sjmp	00450$
      00934A                       2575 00449$:
      00934A 61 EE            [12] 2576 	ajmp	00147$
      00934C                       2577 00450$:
      00934C                       2578 00146$:
                                   2579 ;	quantum/dynamic_keymap.c:778: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      00934C 12 94 71         [24] 2580 	lcall	_ak820_outline_0000
      00934F 12 42 E8         [24] 2581 	lcall	_eeprom_read_byte
      009352 12 94 F3         [24] 2582 	lcall	_ak820_outline_0177
                                   2583 ;	quantum/dynamic_keymap.c:779: if (data[2] != 0) {
      009355 70 02            [24] 2584 	jnz	00451$
      009357 41 55            [12] 2585 	ajmp	00167$
      009359                       2586 00451$:
                                   2587 ;	quantum/dynamic_keymap.c:780: data[3] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      009359 12 94 71         [24] 2588 	lcall	_ak820_outline_0000
      00935C 12 42 E8         [24] 2589 	lcall	_eeprom_read_byte
      00935F AF 82            [24] 2590 	mov	r7, dpl
      009361 90 0B 74         [24] 2591 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_472 + 0x0003)
      009364 EF               [12] 2592 	mov	a,r7
      009365 F0               [24] 2593 	movx	@dptr,a
                                   2594 ;	quantum/dynamic_keymap.c:781: if (data[3] != 0) {
      009366 EF               [12] 2595 	mov	a,r7
      009367 70 02            [24] 2596 	jnz	00452$
      009369 41 55            [12] 2597 	ajmp	00167$
      00936B                       2598 00452$:
                                   2599 ;	quantum/dynamic_keymap.c:784: kc = (uint8_t)data[2] | ((uint16_t)(uint8_t)data[3] << 8);
      00936B 90 0B 73         [24] 2600 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_472 + 0x0002)
      00936E E0               [24] 2601 	movx	a,@dptr
      00936F FF               [12] 2602 	mov	r7,a
      009370 90 0B 74         [24] 2603 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_472 + 0x0003)
      009373 E0               [24] 2604 	movx	a,@dptr
      009374 FB               [12] 2605 	mov	r3,a
      009375 E4               [12] 2606 	clr	a
      009376 FC               [12] 2607 	mov	r4,a
      009377 FA               [12] 2608 	mov	r2,a
      009378 EF               [12] 2609 	mov	a,r7
      009379 42 04            [12] 2610 	orl	ar4,a
      00937B EA               [12] 2611 	mov	a,r2
      00937C 42 03            [12] 2612 	orl	ar3,a
                                   2613 ;	quantum/dynamic_keymap.c:788: kc = decode_keycode(kc);
      00937E 12 46 05         [24] 2614 	lcall	_ak820_outline_0180
      009381 C0 06            [24] 2615 	push	ar6
      009383 C0 05            [24] 2616 	push	ar5
      009385 31 A1            [12] 2617 	acall	_decode_keycode
      009387 AC 82            [24] 2618 	mov	r4, dpl
      009389 AF 83            [24] 2619 	mov	r7, dph
      00938B D0 05            [24] 2620 	pop	ar5
      00938D D0 06            [24] 2621 	pop	ar6
                                   2622 ;	quantum/dynamic_keymap.c:790: ak820_macro_primitive = data[1] != VIAL_MACRO_EXT_TAP;
      00938F 90 0B 72         [24] 2623 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_472 + 0x0001)
      009392 E0               [24] 2624 	movx	a,@dptr
      009393 FB               [12] 2625 	mov	r3,a
      009394 BB 05 03         [24] 2626 	cjne	r3,#0x05,00453$
      009397 D3               [12] 2627 	setb	c
      009398 80 01            [24] 2628 	sjmp	00454$
      00939A                       2629 00453$:
      00939A C3               [12] 2630 	clr	c
      00939B                       2631 00454$:
      00939B 92 25            [24] 2632 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      00939D 90 09 B6         [24] 2633 	mov	dptr,#_ak820_macro_primitive
      0093A0 B3               [12] 2634 	cpl	c
      0093A1 E4               [12] 2635 	clr	a
      0093A2 33               [12] 2636 	rlc	a
      0093A3 F0               [24] 2637 	movx	@dptr,a
                                   2638 ;	quantum/dynamic_keymap.c:792: switch (data[1]) {
      0093A4 90 0B 72         [24] 2639 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_472 + 0x0001)
      0093A7 E0               [24] 2640 	movx	a,@dptr
      0093A8 FB               [12] 2641 	mov	r3,a
      0093A9 BB 05 02         [24] 2642 	cjne	r3,#0x05,00455$
      0093AC 80 0A            [24] 2643 	sjmp	00126$
      0093AE                       2644 00455$:
      0093AE BB 06 02         [24] 2645 	cjne	r3,#0x06,00456$
      0093B1 80 16            [24] 2646 	sjmp	00127$
      0093B3                       2647 00456$:
                                   2648 ;	quantum/dynamic_keymap.c:793: case VIAL_MACRO_EXT_TAP:
      0093B3 BB 07 33         [24] 2649 	cjne	r3,#0x07,00129$
      0093B6 80 22            [24] 2650 	sjmp	00128$
      0093B8                       2651 00126$:
                                   2652 ;	quantum/dynamic_keymap.c:794: vial_keycode_tap(kc);
      0093B8 8C 82            [24] 2653 	mov	dpl, r4
      0093BA 8F 83            [24] 2654 	mov	dph, r7
      0093BC C0 06            [24] 2655 	push	ar6
      0093BE C0 05            [24] 2656 	push	ar5
      0093C0 12 B7 00         [24] 2657 	lcall	_vial_keycode_tap
      0093C3 D0 05            [24] 2658 	pop	ar5
      0093C5 D0 06            [24] 2659 	pop	ar6
                                   2660 ;	quantum/dynamic_keymap.c:795: break;
                                   2661 ;	quantum/dynamic_keymap.c:796: case VIAL_MACRO_EXT_DOWN:
      0093C7 80 20            [24] 2662 	sjmp	00129$
      0093C9                       2663 00127$:
                                   2664 ;	quantum/dynamic_keymap.c:797: vial_keycode_down(kc);
      0093C9 8C 82            [24] 2665 	mov	dpl, r4
      0093CB 8F 83            [24] 2666 	mov	dph, r7
      0093CD C0 06            [24] 2667 	push	ar6
      0093CF C0 05            [24] 2668 	push	ar5
      0093D1 12 B6 35         [24] 2669 	lcall	_vial_keycode_down
      0093D4 D0 05            [24] 2670 	pop	ar5
      0093D6 D0 06            [24] 2671 	pop	ar6
                                   2672 ;	quantum/dynamic_keymap.c:798: break;
                                   2673 ;	quantum/dynamic_keymap.c:799: case VIAL_MACRO_EXT_UP:
      0093D8 80 0F            [24] 2674 	sjmp	00129$
      0093DA                       2675 00128$:
                                   2676 ;	quantum/dynamic_keymap.c:800: vial_keycode_up(kc);
      0093DA 8C 82            [24] 2677 	mov	dpl, r4
      0093DC 8F 83            [24] 2678 	mov	dph, r7
      0093DE C0 06            [24] 2679 	push	ar6
      0093E0 C0 05            [24] 2680 	push	ar5
      0093E2 12 B6 9B         [24] 2681 	lcall	_vial_keycode_up
      0093E5 D0 05            [24] 2682 	pop	ar5
      0093E7 D0 06            [24] 2683 	pop	ar6
                                   2684 ;	quantum/dynamic_keymap.c:802: }
      0093E9                       2685 00129$:
                                   2686 ;	quantum/dynamic_keymap.c:804: ak820_macro_primitive = false;
      0093E9 12 94 DB         [24] 2687 	lcall	_ak820_outline_0162
      0093EC 41 55            [12] 2688 	ajmp	00167$
      0093EE                       2689 00147$:
                                   2690 ;	quantum/dynamic_keymap.c:808: } else if (data[1] == SS_DELAY_CODE) {
      0093EE 12 94 A9         [24] 2691 	lcall	_ak820_outline_0089
      0093F1 BF 04 02         [24] 2692 	cjne	r7,#0x04,00458$
      0093F4 80 02            [24] 2693 	sjmp	00459$
      0093F6                       2694 00458$:
      0093F6 41 55            [12] 2695 	ajmp	00167$
      0093F8                       2696 00459$:
                                   2697 ;	quantum/dynamic_keymap.c:810: uint8_t d0 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      0093F8 12 94 71         [24] 2698 	lcall	_ak820_outline_0000
      0093FB 12 42 E8         [24] 2699 	lcall	_eeprom_read_byte
      0093FE AF 82            [24] 2700 	mov	r7, dpl
                                   2701 ;	quantum/dynamic_keymap.c:811: uint8_t d1 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      009400 90 0B 6F         [24] 2702 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_465
      009403 12 3A 9A         [24] 2703 	lcall	_ak820_outline_0120
      009406 90 0B 6F         [24] 2704 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_465
      009409 74 01            [12] 2705 	mov	a,#0x01
      00940B 2B               [12] 2706 	add	a, r3
      00940C F0               [24] 2707 	movx	@dptr,a
      00940D E4               [12] 2708 	clr	a
      00940E 3C               [12] 2709 	addc	a, r4
      00940F A3               [24] 2710 	inc	dptr
      009410 F0               [24] 2711 	movx	@dptr,a
      009411 7A 00            [12] 2712 	mov	r2,#0x00
      009413 12 36 42         [24] 2713 	lcall	_ak820_outline_0122
      009416 8A F0            [24] 2714 	mov	b, r2
      009418 12 42 E8         [24] 2715 	lcall	_eeprom_read_byte
      00941B AC 82            [24] 2716 	mov	r4, dpl
                                   2717 ;	quantum/dynamic_keymap.c:812: if (d0 == 0 || d1 == 0)
      00941D EF               [12] 2718 	mov	a,r7
      00941E 60 49            [24] 2719 	jz	00169$
      009420 EC               [12] 2720 	mov	a,r4
      009421 60 46            [24] 2721 	jz	00169$
                                   2722 ;	quantum/dynamic_keymap.c:815: uint16_t ms = (uint16_t)(d0 - 1) + (uint16_t)(d1 - 1) * 255u;
      009423 1F               [12] 2723 	dec	r7
      009424 1C               [12] 2724 	dec	r4
      009425 EC               [12] 2725 	mov	a,r4
      009426 75 F0 FF         [24] 2726 	mov	b,#0xff
      009429 A4               [48] 2727 	mul	ab
      00942A FC               [12] 2728 	mov	r4,a
      00942B AB F0            [24] 2729 	mov	r3,b
      00942D 7A 00            [12] 2730 	mov	r2,#0x00
      00942F EC               [12] 2731 	mov	a,r4
      009430 2F               [12] 2732 	add	a, r7
      009431 FC               [12] 2733 	mov	r4,a
      009432 EB               [12] 2734 	mov	a,r3
      009433 3A               [12] 2735 	addc	a, r2
      009434 FB               [12] 2736 	mov	r3,a
                                   2737 ;	quantum/dynamic_keymap.c:816: while (ms--) wait_ms(1);
      009435                       2738 00141$:
      009435 8C 02            [24] 2739 	mov	ar2,r4
      009437 8B 07            [24] 2740 	mov	ar7,r3
      009439 1C               [12] 2741 	dec	r4
      00943A BC FF 01         [24] 2742 	cjne	r4,#0xff,00462$
      00943D 1B               [12] 2743 	dec	r3
      00943E                       2744 00462$:
      00943E EA               [12] 2745 	mov	a,r2
      00943F 4F               [12] 2746 	orl	a,r7
      009440 70 02            [24] 2747 	jnz	00463$
      009442 41 55            [12] 2748 	ajmp	00167$
      009444                       2749 00463$:
      009444 90 00 01         [24] 2750 	mov	dptr,#0x0001
      009447 12 5E 5B         [24] 2751 	lcall	_mDelaymS
      00944A 80 E9            [24] 2752 	sjmp	00141$
      00944C                       2753 00164$:
                                   2754 ;	quantum/dynamic_keymap.c:822: if ((uint8_t)data[0] >= 128) break;
      00944C 90 0B 71         [24] 2755 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_472
      00944F E0               [24] 2756 	movx	a,@dptr
      009450 FF               [12] 2757 	mov	r7,a
      009451 BF 80 00         [24] 2758 	cjne	r7,#0x80,00464$
      009454                       2759 00464$:
      009454 50 13            [24] 2760 	jnc	00169$
                                   2761 ;	quantum/dynamic_keymap.c:826: send_char(data[0]);
      009456 90 0B 71         [24] 2762 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_472
      009459 E0               [24] 2763 	movx	a,@dptr
      00945A F5 82            [12] 2764 	mov	dpl,a
      00945C C0 06            [24] 2765 	push	ar6
      00945E C0 05            [24] 2766 	push	ar5
      009460 12 A9 BB         [24] 2767 	lcall	_send_char
      009463 D0 05            [24] 2768 	pop	ar5
      009465 D0 06            [24] 2769 	pop	ar6
                                   2770 ;	quantum/dynamic_keymap.c:827: for (uint8_t delay = DYNAMIC_KEYMAP_MACRO_DELAY; delay; --delay) wait_ms(1);
      009467 41 55            [12] 2771 	ajmp	00167$
      009469                       2772 00169$:
                                   2773 ;	quantum/dynamic_keymap.c:835: ak820_macro_primitive = false;
      009469 12 94 DB         [24] 2774 	lcall	_ak820_outline_0162
                                   2775 ;	quantum/dynamic_keymap.c:837: sending = false;
      00946C 90 0B 6E         [24] 2776 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_460
      00946F F0               [24] 2777 	movx	@dptr,a
                                   2778 ;	quantum/dynamic_keymap.c:839: }
      009470 22               [24] 2779 	ret
                                   2780 	.area CSEG    (CODE)
                                   2781 	.area CONST   (CODE)
                                   2782 	.area XINIT   (CODE)
                                   2783 	.area CABS    (ABS,CODE)
                                   2784 
                                   2785 ; Experimental exact instruction outlining.
                                   2786 	.globl _ak820_outline_0000
                                   2787 	.globl _ak820_outline_0004
                                   2788 	.globl _ak820_outline_0011
                                   2789 	.globl _ak820_outline_0012
                                   2790 	.globl _ak820_outline_0017
                                   2791 	.globl _ak820_outline_0025
                                   2792 	.globl _ak820_outline_0031
                                   2793 	.globl _ak820_outline_0044
                                   2794 	.globl _ak820_outline_0051
                                   2795 	.globl _ak820_outline_0057
                                   2796 	.globl _ak820_outline_0059
                                   2797 	.globl _ak820_outline_0060
                                   2798 	.globl _ak820_outline_0061
                                   2799 	.globl _ak820_outline_0071
                                   2800 	.globl _ak820_outline_0076
                                   2801 	.globl _ak820_outline_0078
                                   2802 	.globl _ak820_outline_0087
                                   2803 	.globl _ak820_outline_0089
                                   2804 	.globl _ak820_outline_0095
                                   2805 	.globl _ak820_outline_0096
                                   2806 	.globl _ak820_outline_0100
                                   2807 	.globl _ak820_outline_0103
                                   2808 	.globl _ak820_outline_0104
                                   2809 	.globl _ak820_outline_0112
                                   2810 	.globl _ak820_outline_0116
                                   2811 	.globl _ak820_outline_0117
                                   2812 	.globl _ak820_outline_0119
                                   2813 	.globl _ak820_outline_0120
                                   2814 	.globl _ak820_outline_0121
                                   2815 	.globl _ak820_outline_0122
                                   2816 	.globl _ak820_outline_0123
                                   2817 	.globl _ak820_outline_0127
                                   2818 	.globl _ak820_outline_0131
                                   2819 	.globl _ak820_outline_0132
                                   2820 	.globl _ak820_outline_0133
                                   2821 	.globl _ak820_outline_0134
                                   2822 	.globl _ak820_outline_0141
                                   2823 	.globl _ak820_outline_0142
                                   2824 	.globl _ak820_outline_0148
                                   2825 	.globl _ak820_outline_0150
                                   2826 	.globl _ak820_outline_0154
                                   2827 	.globl _ak820_outline_0155
                                   2828 	.globl _ak820_outline_0157
                                   2829 	.globl _ak820_outline_0162
                                   2830 	.globl _ak820_outline_0173
                                   2831 	.globl _ak820_outline_0174
                                   2832 	.globl _ak820_outline_0177
                                   2833 	.globl _ak820_outline_0178
                                   2834 	.globl _ak820_outline_0179
                                   2835 	.globl _ak820_outline_0180
                                   2836 	.globl _ak820_outline_0184
                                   2837 
                                   2838 	.area CSEG (CODE)
                                   2839 ; function ak820_outline_0000
      009471                       2840 _ak820_outline_0000:
      009471 90 0B 6F         [24] 2841 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_465
      009474 E0               [24] 2842 	movx	a,@dptr
      009475 FC               [12] 2843 	mov	r4,a
      009476 A3               [24] 2844 	inc	dptr
      009477 E0               [24] 2845 	movx	a,@dptr
      009478 FF               [12] 2846 	mov	r7,a
      009479 90 0B 6F         [24] 2847 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_465
      00947C 74 01            [12] 2848 	mov	a,#0x01
      00947E 2C               [12] 2849 	add	a,r4
      00947F F0               [24] 2850 	movx	@dptr,a
      009480 E4               [12] 2851 	clr	a
      009481 3F               [12] 2852 	addc	a,r7
      009482 A3               [24] 2853 	inc	dptr
      009483 F0               [24] 2854 	movx	@dptr,a
      009484 7B 00            [12] 2855 	mov	r3,#0x00
      009486 8C 82            [24] 2856 	mov	dpl,r4
      009488 8F 83            [24] 2857 	mov	dph,r7
      00948A 8B F0            [24] 2858 	mov	b,r3
      00948C 22               [24] 2859 	ret
                                   2860 
                                   2861 	.area CSEG (CODE)
                                   2862 ; function ak820_outline_0025
      00948D                       2863 _ak820_outline_0025:
      00948D 2D               [12] 2864 	add	a,r5
      00948E F9               [12] 2865 	mov	r1,a
      00948F E4               [12] 2866 	clr	a
      009490 3E               [12] 2867 	addc	a,r6
      009491 FA               [12] 2868 	mov	r2,a
      009492 8F 03            [24] 2869 	mov	ar3,r7
      009494 89 82            [24] 2870 	mov	dpl,r1
      009496 8A 83            [24] 2871 	mov	dph,r2
      009498 8B F0            [24] 2872 	mov	b,r3
      00949A 22               [24] 2873 	ret
                                   2874 
                                   2875 	.area CSEG (CODE)
                                   2876 ; function ak820_outline_0078
      00949B                       2877 _ak820_outline_0078:
      00949B ED               [12] 2878 	mov	a,r5
      00949C 75 F0 0A         [24] 2879 	mov	b,#0x0a
      00949F A4               [48] 2880 	mul	ab
      0094A0 24 58            [12] 2881 	add	a,#0x58
      0094A2 FC               [12] 2882 	mov	r4,a
      0094A3 74 06            [12] 2883 	mov	a,#0x06
      0094A5 35 F0            [12] 2884 	addc	a,b
      0094A7 FD               [12] 2885 	mov	r5,a
      0094A8 22               [24] 2886 	ret
                                   2887 
                                   2888 	.area CSEG (CODE)
                                   2889 ; function ak820_outline_0089
      0094A9                       2890 _ak820_outline_0089:
      0094A9 90 0B 72         [24] 2891 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_472+0x0001)
      0094AC E0               [24] 2892 	movx	a,@dptr
      0094AD FF               [12] 2893 	mov	r7,a
      0094AE 22               [24] 2894 	ret
                                   2895 
                                   2896 	.area CSEG (CODE)
                                   2897 ; function ak820_outline_0095
      0094AF                       2898 _ak820_outline_0095:
      0094AF 90 0B 08         [24] 2899 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      0094B2 EE               [12] 2900 	mov	a,r6
      0094B3 F0               [24] 2901 	movx	@dptr,a
      0094B4 90 0B 09         [24] 2902 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      0094B7 ED               [12] 2903 	mov	a,r5
      0094B8 F0               [24] 2904 	movx	@dptr,a
      0094B9 8F 82            [24] 2905 	mov	dpl,r7
      0094BB 22               [24] 2906 	ret
                                   2907 
                                   2908 	.area CSEG (CODE)
                                   2909 ; function ak820_outline_0112
      0094BC                       2910 _ak820_outline_0112:
      0094BC AD 82            [24] 2911 	mov	r5,dpl
      0094BE AE 83            [24] 2912 	mov	r6,dph
      0094C0 AF F0            [24] 2913 	mov	r7,b
      0094C2 22               [24] 2914 	ret
                                   2915 
                                   2916 	.area CSEG (CODE)
                                   2917 ; function ak820_outline_0127
      0094C3                       2918 _ak820_outline_0127:
      0094C3 28               [12] 2919 	add	a,r0
      0094C4 F5 82            [12] 2920 	mov	dpl,a
      0094C6 EF               [12] 2921 	mov	a,r7
      0094C7 39               [12] 2922 	addc	a,r1
      0094C8 F5 83            [12] 2923 	mov	dph,a
      0094CA 74 FF            [12] 2924 	mov	a,#0xff
      0094CC F0               [24] 2925 	movx	@dptr,a
      0094CD 22               [24] 2926 	ret
                                   2927 
                                   2928 	.area CSEG (CODE)
                                   2929 ; function ak820_outline_0133
      0094CE                       2930 _ak820_outline_0133:
      0094CE 2D               [12] 2931 	add	a,r5
      0094CF F9               [12] 2932 	mov	r1,a
      0094D0 E4               [12] 2933 	clr	a
      0094D1 3E               [12] 2934 	addc	a,r6
      0094D2 FA               [12] 2935 	mov	r2,a
      0094D3 22               [24] 2936 	ret
                                   2937 
                                   2938 	.area CSEG (CODE)
                                   2939 ; function ak820_outline_0150
      0094D4                       2940 _ak820_outline_0150:
      0094D4 90 0B 73         [24] 2941 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_472+0x0002)
      0094D7 E0               [24] 2942 	movx	a,@dptr
      0094D8 F5 82            [12] 2943 	mov	dpl,a
      0094DA 22               [24] 2944 	ret
                                   2945 
                                   2946 	.area CSEG (CODE)
                                   2947 ; function ak820_outline_0162
      0094DB                       2948 _ak820_outline_0162:
      0094DB 90 09 B6         [24] 2949 	mov	dptr,#_ak820_macro_primitive
      0094DE E4               [12] 2950 	clr	a
      0094DF F0               [24] 2951 	movx	@dptr,a
      0094E0 22               [24] 2952 	ret
                                   2953 
                                   2954 	.area CSEG (CODE)
                                   2955 ; function ak820_outline_0173
      0094E1                       2956 _ak820_outline_0173:
      0094E1 90 0B 18         [24] 2957 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      0094E4 E4               [12] 2958 	clr	a
      0094E5 F0               [24] 2959 	movx	@dptr,a
      0094E6 90 0B 19         [24] 2960 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      0094E9 22               [24] 2961 	ret
                                   2962 
                                   2963 	.area CSEG (CODE)
                                   2964 ; function ak820_outline_0174
      0094EA                       2965 _ak820_outline_0174:
      0094EA 90 0B CE         [24] 2966 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_2
      0094ED E4               [12] 2967 	clr	a
      0094EE F0               [24] 2968 	movx	@dptr,a
      0094EF 90 0B CF         [24] 2969 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_3
      0094F2 22               [24] 2970 	ret
                                   2971 
                                   2972 	.area CSEG (CODE)
                                   2973 ; function ak820_outline_0177
      0094F3                       2974 _ak820_outline_0177:
      0094F3 AF 82            [24] 2975 	mov	r7,dpl
      0094F5 90 0B 73         [24] 2976 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_472+0x0002)
      0094F8 EF               [12] 2977 	mov	a,r7
      0094F9 F0               [24] 2978 	movx	@dptr,a
      0094FA EF               [12] 2979 	mov	a,r7
      0094FB 22               [24] 2980 	ret
