                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module vial
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _unregister_code16
                                     12 	.globl _register_code16
                                     13 	.globl _matrix_is_on
                                     14 	.globl _dynamic_keymap_set_combo
                                     15 	.globl _dynamic_keymap_get_combo
                                     16 	.globl _dynamic_keymap_set_encoder
                                     17 	.globl _dynamic_keymap_get_encoder
                                     18 	.globl _repeat_key_cancel
                                     19 	.globl _ak820_combo_reload
                                     20 	.globl _clear_keyboard
                                     21 	.globl _ak820_action_exec
                                     22 	.globl _timer_elapsed32
                                     23 	.globl _timer_read32
                                     24 	.globl _timer_read
                                     25 	.globl ___memcpy
                                     26 	.globl _ADC_START
                                     27 	.globl _S0_R_FIFO
                                     28 	.globl _S0_T_FIFO
                                     29 	.globl _S0_FREE
                                     30 	.globl _S0_IF_BYTE
                                     31 	.globl _S0_IF_FIRST
                                     32 	.globl _S0_IF_OV
                                     33 	.globl _S0_FST_ACT
                                     34 	.globl _CP_RL2
                                     35 	.globl _C_T2
                                     36 	.globl _TR2
                                     37 	.globl _EXEN2
                                     38 	.globl _TCLK
                                     39 	.globl _RCLK
                                     40 	.globl _EXF2
                                     41 	.globl _CAP1F
                                     42 	.globl _TF2
                                     43 	.globl _RI
                                     44 	.globl _TI
                                     45 	.globl _RB8
                                     46 	.globl _TB8
                                     47 	.globl _REN
                                     48 	.globl _SM2
                                     49 	.globl _SM1
                                     50 	.globl _SM0
                                     51 	.globl _IT0
                                     52 	.globl _IE0
                                     53 	.globl _IT1
                                     54 	.globl _IE1
                                     55 	.globl _TR0
                                     56 	.globl _TF0
                                     57 	.globl _TR1
                                     58 	.globl _TF1
                                     59 	.globl _P4_0
                                     60 	.globl _P4_1
                                     61 	.globl _P4_2
                                     62 	.globl _P4_3
                                     63 	.globl _P4_4
                                     64 	.globl _P4_5
                                     65 	.globl _P4_6
                                     66 	.globl _RXD
                                     67 	.globl _TXD
                                     68 	.globl _INT0
                                     69 	.globl _INT1
                                     70 	.globl _T0
                                     71 	.globl _T1
                                     72 	.globl _MOSI1
                                     73 	.globl _MISO1
                                     74 	.globl _SCK1
                                     75 	.globl _P3_0
                                     76 	.globl _P3_1
                                     77 	.globl _P3_2
                                     78 	.globl _P3_3
                                     79 	.globl _P3_4
                                     80 	.globl _P3_5
                                     81 	.globl _P3_6
                                     82 	.globl _P3_7
                                     83 	.globl _CAP1_
                                     84 	.globl _T2_
                                     85 	.globl _CAP2_
                                     86 	.globl _T2EX_
                                     87 	.globl _RXD1
                                     88 	.globl _TXD1
                                     89 	.globl _P2_0
                                     90 	.globl _P2_1
                                     91 	.globl _P2_2
                                     92 	.globl _P2_3
                                     93 	.globl _P2_4
                                     94 	.globl _P2_5
                                     95 	.globl _P2_6
                                     96 	.globl _P2_7
                                     97 	.globl _AIN0
                                     98 	.globl _AIN1
                                     99 	.globl _AIN2
                                    100 	.globl _AIN3
                                    101 	.globl _AIN4
                                    102 	.globl _AIN5
                                    103 	.globl _AIN6
                                    104 	.globl _AIN7
                                    105 	.globl _CAP1
                                    106 	.globl _T2
                                    107 	.globl _CAP2
                                    108 	.globl _T2EX
                                    109 	.globl _INT0_
                                    110 	.globl _SCS
                                    111 	.globl _MOSI
                                    112 	.globl _MISO
                                    113 	.globl _SCK
                                    114 	.globl _RXD1_
                                    115 	.globl _TXD1_
                                    116 	.globl _P1_0
                                    117 	.globl _P1_1
                                    118 	.globl _P1_2
                                    119 	.globl _P1_3
                                    120 	.globl _P1_4
                                    121 	.globl _P1_5
                                    122 	.globl _P1_6
                                    123 	.globl _P1_7
                                    124 	.globl _AIN8
                                    125 	.globl _AIN9
                                    126 	.globl _AIN10
                                    127 	.globl _AIN11
                                    128 	.globl _AIN12
                                    129 	.globl _AIN13
                                    130 	.globl _RXD_
                                    131 	.globl _TXD_
                                    132 	.globl _SCL0
                                    133 	.globl _SDA0
                                    134 	.globl _P0_0
                                    135 	.globl _P0_1
                                    136 	.globl _P0_2
                                    137 	.globl _P0_3
                                    138 	.globl _P0_4
                                    139 	.globl _P0_5
                                    140 	.globl _P0_6
                                    141 	.globl _P0_7
                                    142 	.globl _IE_SPI0
                                    143 	.globl _IE_USB
                                    144 	.globl _IE_ADC
                                    145 	.globl _IE_UART1
                                    146 	.globl _IE_PWM_I2C
                                    147 	.globl _IE_GPIO
                                    148 	.globl _IE_WDOG
                                    149 	.globl _PX0
                                    150 	.globl _PT0
                                    151 	.globl _PX1
                                    152 	.globl _PT1
                                    153 	.globl _PS
                                    154 	.globl _PT2
                                    155 	.globl _PL_FLAG
                                    156 	.globl _PH_FLAG
                                    157 	.globl _EX0
                                    158 	.globl _ET0
                                    159 	.globl _EX1
                                    160 	.globl _ET1
                                    161 	.globl _ES
                                    162 	.globl _ET2
                                    163 	.globl _E_DIS
                                    164 	.globl _EA
                                    165 	.globl _P
                                    166 	.globl _F1
                                    167 	.globl _OV
                                    168 	.globl _RS0
                                    169 	.globl _RS1
                                    170 	.globl _F0
                                    171 	.globl _AC
                                    172 	.globl _CY
                                    173 	.globl _I2CS_INT_ST
                                    174 	.globl _I2CX_INT
                                    175 	.globl _LED_STATUS
                                    176 	.globl _LED_DMA_H
                                    177 	.globl _LED_DMA_L
                                    178 	.globl _LED_DMA
                                    179 	.globl _LED_PWM_OE
                                    180 	.globl _LED_COMMON
                                    181 	.globl _ADC_CHAN
                                    182 	.globl _ADC_DAT_H
                                    183 	.globl _ADC_DAT_L
                                    184 	.globl _ADC_DAT
                                    185 	.globl _ADC_CTRL
                                    186 	.globl _SPI1_CK_SE
                                    187 	.globl _SPI1_CTRL
                                    188 	.globl _SPI1_DATA
                                    189 	.globl _SPI1_STAT
                                    190 	.globl _SIF1
                                    191 	.globl _SBAUD1
                                    192 	.globl _SBUF1
                                    193 	.globl _SCON1
                                    194 	.globl _SPI0_SETUP
                                    195 	.globl _SPI0_CK_SE
                                    196 	.globl _SPI0_CTRL
                                    197 	.globl _SPI0_DATA
                                    198 	.globl _SPI0_STAT
                                    199 	.globl _T2CAP1H
                                    200 	.globl _T2CAP1L
                                    201 	.globl _T2CAP1
                                    202 	.globl _TH2
                                    203 	.globl _TL2
                                    204 	.globl _T2COUNT
                                    205 	.globl _RCAP2H
                                    206 	.globl _RCAP2L
                                    207 	.globl _RCAP2
                                    208 	.globl _T2MOD
                                    209 	.globl _T2CON
                                    210 	.globl _SBUF
                                    211 	.globl _SCON
                                    212 	.globl _TH1
                                    213 	.globl _TH0
                                    214 	.globl _TL1
                                    215 	.globl _TL0
                                    216 	.globl _TMOD
                                    217 	.globl _TCON
                                    218 	.globl _XBUS_AUX
                                    219 	.globl _P7
                                    220 	.globl _P6_DIR
                                    221 	.globl _P6_OUT_PU
                                    222 	.globl _P6_IN
                                    223 	.globl _P5_DIR
                                    224 	.globl _P5_OUT_PU
                                    225 	.globl _P5_IN
                                    226 	.globl _P4_LED_KEY
                                    227 	.globl _P4_DIR_PU
                                    228 	.globl _P4_MOD_OC
                                    229 	.globl _P4
                                    230 	.globl _P3_DIR_PU
                                    231 	.globl _P3_MOD_OC
                                    232 	.globl _P3
                                    233 	.globl _P2_DIR_PU
                                    234 	.globl _P2_MOD_OC
                                    235 	.globl _P2
                                    236 	.globl _P1_DIR_PU
                                    237 	.globl _P1_MOD_OC
                                    238 	.globl _P1
                                    239 	.globl _P0_DIR_PU
                                    240 	.globl _P0_MOD_OC
                                    241 	.globl _P0
                                    242 	.globl _ROM_CTRL
                                    243 	.globl _ROM_DATA_HH
                                    244 	.globl _ROM_DATA_HL
                                    245 	.globl _ROM_DATA_HI
                                    246 	.globl _ROM_ADDR_H
                                    247 	.globl _ROM_ADDR_L
                                    248 	.globl _ROM_ADDR
                                    249 	.globl _GPIO_IE
                                    250 	.globl _IP_EX
                                    251 	.globl _IE_EX
                                    252 	.globl _IP
                                    253 	.globl _IE
                                    254 	.globl _WDOG_COUNT
                                    255 	.globl _RESET_KEEP
                                    256 	.globl _WAKE_CTRL
                                    257 	.globl _CLOCK_CFG
                                    258 	.globl _POWER_CFG
                                    259 	.globl _PCON
                                    260 	.globl _GLOBAL_CFG
                                    261 	.globl _SAFE_MOD
                                    262 	.globl _DPH
                                    263 	.globl _DPL
                                    264 	.globl _SP
                                    265 	.globl _A_INV
                                    266 	.globl _B
                                    267 	.globl _ACC
                                    268 	.globl _PSW
                                    269 	.globl _vial_unlock_in_progress
                                    270 	.globl _vial_unlocked
                                    271 	.globl _g_vial_magic_keycode_override
                                    272 	.globl _vial_handle_cmd_PARM_2
                                    273 	.globl _vial_unlock_task
                                    274 	.globl _vial_init
                                    275 	.globl _vial_handle_cmd
                                    276 	.globl _vial_keycode_down
                                    277 	.globl _vial_keycode_up
                                    278 	.globl _vial_keycode_tap
                                    279 ;--------------------------------------------------------
                                    280 ; special function registers
                                    281 ;--------------------------------------------------------
                                    282 	.area RSEG    (ABS,DATA)
      000000                        283 	.org 0x0000
                           0000D0   284 _PSW	=	0x00d0
                           0000E0   285 _ACC	=	0x00e0
                           0000F0   286 _B	=	0x00f0
                           0000FD   287 _A_INV	=	0x00fd
                           000081   288 _SP	=	0x0081
                           000082   289 _DPL	=	0x0082
                           000083   290 _DPH	=	0x0083
                           0000A1   291 _SAFE_MOD	=	0x00a1
                           0000B1   292 _GLOBAL_CFG	=	0x00b1
                           000087   293 _PCON	=	0x0087
                           0000BA   294 _POWER_CFG	=	0x00ba
                           0000B9   295 _CLOCK_CFG	=	0x00b9
                           0000A9   296 _WAKE_CTRL	=	0x00a9
                           0000FE   297 _RESET_KEEP	=	0x00fe
                           0000FF   298 _WDOG_COUNT	=	0x00ff
                           0000A8   299 _IE	=	0x00a8
                           0000B8   300 _IP	=	0x00b8
                           0000E8   301 _IE_EX	=	0x00e8
                           0000E9   302 _IP_EX	=	0x00e9
                           0000B2   303 _GPIO_IE	=	0x00b2
                           008584   304 _ROM_ADDR	=	0x8584
                           000084   305 _ROM_ADDR_L	=	0x0084
                           000085   306 _ROM_ADDR_H	=	0x0085
                           008F8E   307 _ROM_DATA_HI	=	0x8f8e
                           00008E   308 _ROM_DATA_HL	=	0x008e
                           00008F   309 _ROM_DATA_HH	=	0x008f
                           000086   310 _ROM_CTRL	=	0x0086
                           000080   311 _P0	=	0x0080
                           0000C4   312 _P0_MOD_OC	=	0x00c4
                           0000C5   313 _P0_DIR_PU	=	0x00c5
                           000090   314 _P1	=	0x0090
                           000092   315 _P1_MOD_OC	=	0x0092
                           000093   316 _P1_DIR_PU	=	0x0093
                           0000A0   317 _P2	=	0x00a0
                           000094   318 _P2_MOD_OC	=	0x0094
                           000095   319 _P2_DIR_PU	=	0x0095
                           0000B0   320 _P3	=	0x00b0
                           000096   321 _P3_MOD_OC	=	0x0096
                           000097   322 _P3_DIR_PU	=	0x0097
                           0000C0   323 _P4	=	0x00c0
                           0000C2   324 _P4_MOD_OC	=	0x00c2
                           0000C3   325 _P4_DIR_PU	=	0x00c3
                           0000C1   326 _P4_LED_KEY	=	0x00c1
                           0000AA   327 _P5_IN	=	0x00aa
                           0000AB   328 _P5_OUT_PU	=	0x00ab
                           0000AC   329 _P5_DIR	=	0x00ac
                           0000AD   330 _P6_IN	=	0x00ad
                           0000AE   331 _P6_OUT_PU	=	0x00ae
                           0000AF   332 _P6_DIR	=	0x00af
                           0000F1   333 _P7	=	0x00f1
                           0000A2   334 _XBUS_AUX	=	0x00a2
                           000088   335 _TCON	=	0x0088
                           000089   336 _TMOD	=	0x0089
                           00008A   337 _TL0	=	0x008a
                           00008B   338 _TL1	=	0x008b
                           00008C   339 _TH0	=	0x008c
                           00008D   340 _TH1	=	0x008d
                           000098   341 _SCON	=	0x0098
                           000099   342 _SBUF	=	0x0099
                           0000C8   343 _T2CON	=	0x00c8
                           0000C9   344 _T2MOD	=	0x00c9
                           00CBCA   345 _RCAP2	=	0xcbca
                           0000CA   346 _RCAP2L	=	0x00ca
                           0000CB   347 _RCAP2H	=	0x00cb
                           00CDCC   348 _T2COUNT	=	0xcdcc
                           0000CC   349 _TL2	=	0x00cc
                           0000CD   350 _TH2	=	0x00cd
                           00CFCE   351 _T2CAP1	=	0xcfce
                           0000CE   352 _T2CAP1L	=	0x00ce
                           0000CF   353 _T2CAP1H	=	0x00cf
                           0000F8   354 _SPI0_STAT	=	0x00f8
                           0000F9   355 _SPI0_DATA	=	0x00f9
                           0000FA   356 _SPI0_CTRL	=	0x00fa
                           0000FB   357 _SPI0_CK_SE	=	0x00fb
                           0000FC   358 _SPI0_SETUP	=	0x00fc
                           0000BC   359 _SCON1	=	0x00bc
                           0000BD   360 _SBUF1	=	0x00bd
                           0000BE   361 _SBAUD1	=	0x00be
                           0000BF   362 _SIF1	=	0x00bf
                           0000B4   363 _SPI1_STAT	=	0x00b4
                           0000B5   364 _SPI1_DATA	=	0x00b5
                           0000B6   365 _SPI1_CTRL	=	0x00b6
                           0000B7   366 _SPI1_CK_SE	=	0x00b7
                           0000F3   367 _ADC_CTRL	=	0x00f3
                           00F5F4   368 _ADC_DAT	=	0xf5f4
                           0000F4   369 _ADC_DAT_L	=	0x00f4
                           0000F5   370 _ADC_DAT_H	=	0x00f5
                           0000F6   371 _ADC_CHAN	=	0x00f6
                           0000A6   372 _LED_COMMON	=	0x00a6
                           0000A7   373 _LED_PWM_OE	=	0x00a7
                           00C7C6   374 _LED_DMA	=	0xc7c6
                           0000C6   375 _LED_DMA_L	=	0x00c6
                           0000C7   376 _LED_DMA_H	=	0x00c7
                           0000F7   377 _LED_STATUS	=	0x00f7
                           0000B3   378 _I2CX_INT	=	0x00b3
                           0000BB   379 _I2CS_INT_ST	=	0x00bb
                                    380 ;--------------------------------------------------------
                                    381 ; special function bits
                                    382 ;--------------------------------------------------------
                                    383 	.area RSEG    (ABS,DATA)
      000000                        384 	.org 0x0000
                           0000D7   385 _CY	=	0x00d7
                           0000D6   386 _AC	=	0x00d6
                           0000D5   387 _F0	=	0x00d5
                           0000D4   388 _RS1	=	0x00d4
                           0000D3   389 _RS0	=	0x00d3
                           0000D2   390 _OV	=	0x00d2
                           0000D1   391 _F1	=	0x00d1
                           0000D0   392 _P	=	0x00d0
                           0000AF   393 _EA	=	0x00af
                           0000AE   394 _E_DIS	=	0x00ae
                           0000AD   395 _ET2	=	0x00ad
                           0000AC   396 _ES	=	0x00ac
                           0000AB   397 _ET1	=	0x00ab
                           0000AA   398 _EX1	=	0x00aa
                           0000A9   399 _ET0	=	0x00a9
                           0000A8   400 _EX0	=	0x00a8
                           0000BF   401 _PH_FLAG	=	0x00bf
                           0000BE   402 _PL_FLAG	=	0x00be
                           0000BD   403 _PT2	=	0x00bd
                           0000BC   404 _PS	=	0x00bc
                           0000BB   405 _PT1	=	0x00bb
                           0000BA   406 _PX1	=	0x00ba
                           0000B9   407 _PT0	=	0x00b9
                           0000B8   408 _PX0	=	0x00b8
                           0000EF   409 _IE_WDOG	=	0x00ef
                           0000EE   410 _IE_GPIO	=	0x00ee
                           0000ED   411 _IE_PWM_I2C	=	0x00ed
                           0000EC   412 _IE_UART1	=	0x00ec
                           0000EB   413 _IE_ADC	=	0x00eb
                           0000E9   414 _IE_USB	=	0x00e9
                           0000E8   415 _IE_SPI0	=	0x00e8
                           000087   416 _P0_7	=	0x0087
                           000086   417 _P0_6	=	0x0086
                           000085   418 _P0_5	=	0x0085
                           000084   419 _P0_4	=	0x0084
                           000083   420 _P0_3	=	0x0083
                           000082   421 _P0_2	=	0x0082
                           000081   422 _P0_1	=	0x0081
                           000080   423 _P0_0	=	0x0080
                           000081   424 _SDA0	=	0x0081
                           000080   425 _SCL0	=	0x0080
                           000083   426 _TXD_	=	0x0083
                           000082   427 _RXD_	=	0x0082
                           000085   428 _AIN13	=	0x0085
                           000084   429 _AIN12	=	0x0084
                           000083   430 _AIN11	=	0x0083
                           000082   431 _AIN10	=	0x0082
                           000081   432 _AIN9	=	0x0081
                           000080   433 _AIN8	=	0x0080
                           000097   434 _P1_7	=	0x0097
                           000096   435 _P1_6	=	0x0096
                           000095   436 _P1_5	=	0x0095
                           000094   437 _P1_4	=	0x0094
                           000093   438 _P1_3	=	0x0093
                           000092   439 _P1_2	=	0x0092
                           000091   440 _P1_1	=	0x0091
                           000090   441 _P1_0	=	0x0090
                           000097   442 _TXD1_	=	0x0097
                           000096   443 _RXD1_	=	0x0096
                           000097   444 _SCK	=	0x0097
                           000096   445 _MISO	=	0x0096
                           000095   446 _MOSI	=	0x0095
                           000094   447 _SCS	=	0x0094
                           000092   448 _INT0_	=	0x0092
                           000091   449 _T2EX	=	0x0091
                           000091   450 _CAP2	=	0x0091
                           000090   451 _T2	=	0x0090
                           000090   452 _CAP1	=	0x0090
                           000097   453 _AIN7	=	0x0097
                           000096   454 _AIN6	=	0x0096
                           000095   455 _AIN5	=	0x0095
                           000094   456 _AIN4	=	0x0094
                           000093   457 _AIN3	=	0x0093
                           000092   458 _AIN2	=	0x0092
                           000091   459 _AIN1	=	0x0091
                           000090   460 _AIN0	=	0x0090
                           0000A7   461 _P2_7	=	0x00a7
                           0000A6   462 _P2_6	=	0x00a6
                           0000A5   463 _P2_5	=	0x00a5
                           0000A4   464 _P2_4	=	0x00a4
                           0000A3   465 _P2_3	=	0x00a3
                           0000A2   466 _P2_2	=	0x00a2
                           0000A1   467 _P2_1	=	0x00a1
                           0000A0   468 _P2_0	=	0x00a0
                           0000A7   469 _TXD1	=	0x00a7
                           0000A6   470 _RXD1	=	0x00a6
                           0000A5   471 _T2EX_	=	0x00a5
                           0000A5   472 _CAP2_	=	0x00a5
                           0000A4   473 _T2_	=	0x00a4
                           0000A4   474 _CAP1_	=	0x00a4
                           0000B7   475 _P3_7	=	0x00b7
                           0000B6   476 _P3_6	=	0x00b6
                           0000B5   477 _P3_5	=	0x00b5
                           0000B4   478 _P3_4	=	0x00b4
                           0000B3   479 _P3_3	=	0x00b3
                           0000B2   480 _P3_2	=	0x00b2
                           0000B1   481 _P3_1	=	0x00b1
                           0000B0   482 _P3_0	=	0x00b0
                           0000B7   483 _SCK1	=	0x00b7
                           0000B6   484 _MISO1	=	0x00b6
                           0000B5   485 _MOSI1	=	0x00b5
                           0000B5   486 _T1	=	0x00b5
                           0000B4   487 _T0	=	0x00b4
                           0000B3   488 _INT1	=	0x00b3
                           0000B2   489 _INT0	=	0x00b2
                           0000B1   490 _TXD	=	0x00b1
                           0000B0   491 _RXD	=	0x00b0
                           0000C6   492 _P4_6	=	0x00c6
                           0000C5   493 _P4_5	=	0x00c5
                           0000C4   494 _P4_4	=	0x00c4
                           0000C3   495 _P4_3	=	0x00c3
                           0000C2   496 _P4_2	=	0x00c2
                           0000C1   497 _P4_1	=	0x00c1
                           0000C0   498 _P4_0	=	0x00c0
                           00008F   499 _TF1	=	0x008f
                           00008E   500 _TR1	=	0x008e
                           00008D   501 _TF0	=	0x008d
                           00008C   502 _TR0	=	0x008c
                           00008B   503 _IE1	=	0x008b
                           00008A   504 _IT1	=	0x008a
                           000089   505 _IE0	=	0x0089
                           000088   506 _IT0	=	0x0088
                           00009F   507 _SM0	=	0x009f
                           00009E   508 _SM1	=	0x009e
                           00009D   509 _SM2	=	0x009d
                           00009C   510 _REN	=	0x009c
                           00009B   511 _TB8	=	0x009b
                           00009A   512 _RB8	=	0x009a
                           000099   513 _TI	=	0x0099
                           000098   514 _RI	=	0x0098
                           0000CF   515 _TF2	=	0x00cf
                           0000CF   516 _CAP1F	=	0x00cf
                           0000CE   517 _EXF2	=	0x00ce
                           0000CD   518 _RCLK	=	0x00cd
                           0000CC   519 _TCLK	=	0x00cc
                           0000CB   520 _EXEN2	=	0x00cb
                           0000CA   521 _TR2	=	0x00ca
                           0000C9   522 _C_T2	=	0x00c9
                           0000C8   523 _CP_RL2	=	0x00c8
                           0000FF   524 _S0_FST_ACT	=	0x00ff
                           0000FE   525 _S0_IF_OV	=	0x00fe
                           0000FD   526 _S0_IF_FIRST	=	0x00fd
                           0000FC   527 _S0_IF_BYTE	=	0x00fc
                           0000FB   528 _S0_FREE	=	0x00fb
                           0000FA   529 _S0_T_FIFO	=	0x00fa
                           0000F8   530 _S0_R_FIFO	=	0x00f8
                           0000F7   531 _ADC_START	=	0x00f7
                                    532 ;--------------------------------------------------------
                                    533 ; overlayable register banks
                                    534 ;--------------------------------------------------------
                                    535 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        536 	.ds 8
                                    537 ;--------------------------------------------------------
                                    538 ; internal ram data
                                    539 ;--------------------------------------------------------
                                    540 	.area DSEG    (DATA)
      000042                        541 _vial_handle_cmd_sloc0_1_0:
      000042                        542 	.ds 2
      000044                        543 _vial_handle_cmd_sloc1_1_0:
      000044                        544 	.ds 2
      000046                        545 _vial_handle_cmd_sloc2_1_0:
      000046                        546 	.ds 2
      000048                        547 _vial_handle_cmd_sloc3_1_0:
      000048                        548 	.ds 2
                                    549 ;--------------------------------------------------------
                                    550 ; overlayable items in internal ram
                                    551 ;--------------------------------------------------------
                                    552 ;--------------------------------------------------------
                                    553 ; indirectly addressable internal ram data
                                    554 ;--------------------------------------------------------
                                    555 	.area ISEG    (DATA)
                                    556 ;--------------------------------------------------------
                                    557 ; absolute internal ram data
                                    558 ;--------------------------------------------------------
                                    559 	.area IABS    (ABS,DATA)
                                    560 	.area IABS    (ABS,DATA)
                                    561 ;--------------------------------------------------------
                                    562 ; bit data
                                    563 ;--------------------------------------------------------
                                    564 	.area BSEG    (BIT)
                                    565 ;--------------------------------------------------------
                                    566 ; paged external ram data
                                    567 ;--------------------------------------------------------
                                    568 	.area PSEG    (PAG,XDATA)
                                    569 ;--------------------------------------------------------
                                    570 ; uninitialized external ram data
                                    571 ;--------------------------------------------------------
                                    572 	.area XSEG    (XDATA)
      000C60                        573 _vial_unlock_timer:
      000C60                        574 	.ds 4
      000C64                        575 _vial_unlock_holding:
      000C64                        576 	.ds 1
      000C65                        577 _vial_keycode_firewall_in_10000_611:
      000C65                        578 	.ds 2
      000C67                        579 _vial_fill_packet_PARM_2:
      000C67                        580 	.ds 1
      000C68                        581 _vial_fill_packet_msg_10000_614:
      000C68                        582 	.ds 2
      000C6A                        583 _vial_handle_cmd_PARM_2:
      000C6A                        584 	.ds 1
      000C6B                        585 _vial_handle_cmd_data_10000_619:
      000C6B                        586 	.ds 3
      000C6E                        587 _vial_handle_cmd_entry_70000_647:
      000C6E                        588 	.ds 10
      000C78                        589 _vial_handle_cmd_entry_70000_648:
      000C78                        590 	.ds 10
      000C82                        591 _g_vial_magic_keycode_override::
      000C82                        592 	.ds 2
      000C84                        593 _vial_keycode_down_keycode_10000_650:
      000C84                        594 	.ds 2
      000C86                        595 _vial_keycode_down_dummy_event_30000_657:
      000C86                        596 	.ds 6
      000C8C                        597 _vial_keycode_up_keycode_10000_658:
      000C8C                        598 	.ds 2
      000C8E                        599 _vial_keycode_up_dummy_event_30000_665:
      000C8E                        600 	.ds 6
      000C94                        601 _vial_keycode_tap_keycode_10000_666:
      000C94                        602 	.ds 2
                                    603 ;--------------------------------------------------------
                                    604 ; absolute external ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area XABS    (ABS,XDATA)
                                    607 ;--------------------------------------------------------
                                    608 ; initialized external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area XISEG   (XDATA)
      000E2B                        611 _vial_unlocked::
      000E2B                        612 	.ds 1
      000E2C                        613 _vial_unlock_in_progress::
      000E2C                        614 	.ds 1
      000E2D                        615 _vial_unlock_counter:
      000E2D                        616 	.ds 1
      000E2E                        617 _vial_unlock_combo_rows:
      000E2E                        618 	.ds 2
      000E30                        619 _vial_unlock_combo_cols:
      000E30                        620 	.ds 2
                                    621 	.area HOME    (CODE)
                                    622 	.area GSINIT0 (CODE)
                                    623 	.area GSINIT1 (CODE)
                                    624 	.area GSINIT2 (CODE)
                                    625 	.area GSINIT3 (CODE)
                                    626 	.area GSINIT4 (CODE)
                                    627 	.area GSINIT5 (CODE)
                                    628 	.area GSINIT  (CODE)
                                    629 	.area GSFINAL (CODE)
                                    630 	.area CSEG    (CODE)
                                    631 ;--------------------------------------------------------
                                    632 ; global & static initialisations
                                    633 ;--------------------------------------------------------
                                    634 	.area HOME    (CODE)
                                    635 	.area GSINIT  (CODE)
                                    636 	.area GSFINAL (CODE)
                                    637 	.area GSINIT  (CODE)
                                    638 ;--------------------------------------------------------
                                    639 ; Home
                                    640 ;--------------------------------------------------------
                                    641 	.area HOME    (CODE)
                                    642 	.area HOME    (CODE)
                                    643 ;--------------------------------------------------------
                                    644 ; code
                                    645 ;--------------------------------------------------------
                                    646 	.area CSEG    (CODE)
                                    647 ;------------------------------------------------------------
                                    648 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    649 ;------------------------------------------------------------
                                    650 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_176'
                                    651 ;------------------------------------------------------------
                                    652 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    653 ;	-----------------------------------------
                           000007   654 	ar7 = 0x07
                           000006   655 	ar6 = 0x06
                           000005   656 	ar5 = 0x05
                           000004   657 	ar4 = 0x04
                           000003   658 	ar3 = 0x03
                           000002   659 	ar2 = 0x02
                           000001   660 	ar1 = 0x01
                           000000   661 	ar0 = 0x00
                                    662 ;	 function vial_unlock_task
                                    663 ;	-----------------------------------------
      00B18E                        664 _vial_unlock_task:
                                    665 ;	quantum/vial.c:64: if (!vial_unlock_in_progress) return;
      00B18E 90 0E 2C         [24]  666 	mov	dptr,#_vial_unlock_in_progress
      00B191 E0               [24]  667 	movx	a,@dptr
      00B192 70 01            [24]  668 	jnz	00131$
      00B194 22               [24]  669 	ret
                                    670 ;	quantum/vial.c:65: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B195                        671 00131$:
      00B195 7F 00            [12]  672 	mov	r7,#0x00
      00B197                        673 00115$:
      00B197 BF 02 00         [24]  674 	cjne	r7,#0x02,00184$
      00B19A                        675 00184$:
      00B19A 50 29            [24]  676 	jnc	00105$
                                    677 ;	quantum/vial.c:66: if (!matrix_is_on(vial_unlock_combo_rows[i], vial_unlock_combo_cols[i])) {
      00B19C EF               [12]  678 	mov	a,r7
      00B19D 12 B7 51         [24]  679 	lcall	_ak820_outline_0126
      00B1A0 FE               [12]  680 	mov	r6,a
      00B1A1 EF               [12]  681 	mov	a,r7
      00B1A2 12 B7 46         [24]  682 	lcall	_ak820_outline_0125
      00B1A5 90 07 89         [24]  683 	mov	dptr,#_matrix_is_on_PARM_2
      00B1A8 F0               [24]  684 	movx	@dptr,a
      00B1A9 8E 82            [24]  685 	mov	dpl, r6
      00B1AB C0 07            [24]  686 	push	ar7
      00B1AD 12 5E CD         [24]  687 	lcall	_matrix_is_on
      00B1B0 E5 82            [12]  688 	mov	a, dpl
      00B1B2 D0 07            [24]  689 	pop	ar7
      00B1B4 70 0C            [24]  690 	jnz	00116$
                                    691 ;	quantum/vial.c:67: vial_unlock_holding = false;
      00B1B6 90 0C 64         [24]  692 	mov	dptr,#_vial_unlock_holding
      00B1B9 E4               [12]  693 	clr	a
      00B1BA F0               [24]  694 	movx	@dptr,a
                                    695 ;	quantum/vial.c:68: vial_unlock_counter = VIAL_UNLOCK_COUNTER_MAX;
      00B1BB 90 0E 2D         [24]  696 	mov	dptr,#_vial_unlock_counter
      00B1BE 74 1E            [12]  697 	mov	a,#0x1e
      00B1C0 F0               [24]  698 	movx	@dptr,a
                                    699 ;	quantum/vial.c:69: return;
      00B1C1 22               [24]  700 	ret
      00B1C2                        701 00116$:
                                    702 ;	quantum/vial.c:65: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B1C2 0F               [12]  703 	inc	r7
      00B1C3 80 D2            [24]  704 	sjmp	00115$
      00B1C5                        705 00105$:
                                    706 ;	quantum/vial.c:72: if (!vial_unlock_holding) {
      00B1C5 90 0C 64         [24]  707 	mov	dptr,#_vial_unlock_holding
      00B1C8 E0               [24]  708 	movx	a,@dptr
      00B1C9 70 12            [24]  709 	jnz	00107$
                                    710 ;	quantum/vial.c:73: vial_unlock_holding = true;
      00B1CB 90 0C 64         [24]  711 	mov	dptr,#_vial_unlock_holding
      00B1CE 74 01            [12]  712 	mov	a,#0x01
      00B1D0 F0               [24]  713 	movx	@dptr,a
                                    714 ;	quantum/vial.c:74: vial_unlock_timer = timer_read32();
      00B1D1 12 4C 2C         [24]  715 	lcall	_timer_read32
      00B1D4 12 52 66         [24]  716 	lcall	_ak820_outline_0056
      00B1D7 90 0C 60         [24]  717 	mov	dptr,#_vial_unlock_timer
      00B1DA 12 96 71         [24]  718 	lcall	_ak820_outline_0007
      00B1DD                        719 00107$:
                                    720 ;	quantum/vial.c:76: uint32_t elapsed = timer_elapsed32(vial_unlock_timer);
      00B1DD 90 0C 60         [24]  721 	mov	dptr,#_vial_unlock_timer
      00B1E0 12 52 55         [24]  722 	lcall	_ak820_outline_0054
      00B1E3 12 4C 85         [24]  723 	lcall	_timer_elapsed32
      00B1E6 12 52 66         [24]  724 	lcall	_ak820_outline_0056
                                    725 ;	quantum/vial.c:80: while (counter && elapsed >= VIAL_UNLOCK_COUNTER_TICK_MS) {
      00B1E9 7B 1E            [12]  726 	mov	r3,#0x1e
      00B1EB                        727 00109$:
      00B1EB EB               [12]  728 	mov	a,r3
      00B1EC 60 22            [24]  729 	jz	00111$
      00B1EE C3               [12]  730 	clr	c
      00B1EF EC               [12]  731 	mov	a,r4
      00B1F0 94 64            [12]  732 	subb	a,#0x64
      00B1F2 ED               [12]  733 	mov	a,r5
      00B1F3 94 00            [12]  734 	subb	a,#0x00
      00B1F5 EE               [12]  735 	mov	a,r6
      00B1F6 94 00            [12]  736 	subb	a,#0x00
      00B1F8 EF               [12]  737 	mov	a,r7
      00B1F9 94 00            [12]  738 	subb	a,#0x00
      00B1FB 40 13            [24]  739 	jc	00111$
                                    740 ;	quantum/vial.c:81: elapsed -= VIAL_UNLOCK_COUNTER_TICK_MS;
      00B1FD EC               [12]  741 	mov	a,r4
      00B1FE 24 9C            [12]  742 	add	a,#0x9c
      00B200 FC               [12]  743 	mov	r4,a
      00B201 ED               [12]  744 	mov	a,r5
      00B202 34 FF            [12]  745 	addc	a,#0xff
      00B204 FD               [12]  746 	mov	r5,a
      00B205 EE               [12]  747 	mov	a,r6
      00B206 34 FF            [12]  748 	addc	a,#0xff
      00B208 FE               [12]  749 	mov	r6,a
      00B209 EF               [12]  750 	mov	a,r7
      00B20A 34 FF            [12]  751 	addc	a,#0xff
      00B20C FF               [12]  752 	mov	r7,a
                                    753 ;	quantum/vial.c:82: --counter;
      00B20D 1B               [12]  754 	dec	r3
      00B20E 80 DB            [24]  755 	sjmp	00109$
      00B210                        756 00111$:
                                    757 ;	quantum/vial.c:84: vial_unlock_counter = counter;
      00B210 90 0E 2D         [24]  758 	mov	dptr,#_vial_unlock_counter
      00B213 EB               [12]  759 	mov	a,r3
      00B214 F0               [24]  760 	movx	@dptr,a
                                    761 ;	quantum/vial.c:85: if (!counter) {
      00B215 EB               [12]  762 	mov	a,r3
      00B216 70 0A            [24]  763 	jnz	00117$
                                    764 ;	quantum/vial.c:86: vial_unlock_in_progress = 0;
      00B218 90 0E 2C         [24]  765 	mov	dptr,#_vial_unlock_in_progress
      00B21B E4               [12]  766 	clr	a
      00B21C F0               [24]  767 	movx	@dptr,a
                                    768 ;	quantum/vial.c:87: vial_unlocked = 1;
      00B21D 90 0E 2B         [24]  769 	mov	dptr,#_vial_unlocked
      00B220 04               [12]  770 	inc	a
      00B221 F0               [24]  771 	movx	@dptr,a
      00B222                        772 00117$:
                                    773 ;	quantum/vial.c:90: }
      00B222 22               [24]  774 	ret
                                    775 ;------------------------------------------------------------
                                    776 ;Allocation info for local variables in function 'vial_init'
                                    777 ;------------------------------------------------------------
                                    778 ;	quantum/vial.c:117: void vial_init(void) {
                                    779 ;	-----------------------------------------
                                    780 ;	 function vial_init
                                    781 ;	-----------------------------------------
      00B223                        782 _vial_init:
                                    783 ;	quantum/vial.c:125: reload_combo();
                                    784 ;	quantum/vial.c:130: }
      00B223 02 37 7D         [24]  785 	ljmp	_ak820_combo_reload
                                    786 ;------------------------------------------------------------
                                    787 ;Allocation info for local variables in function 'vial_keycode_firewall'
                                    788 ;------------------------------------------------------------
                                    789 ;in            Allocated with name '_vial_keycode_firewall_in_10000_611'
                                    790 ;------------------------------------------------------------
                                    791 ;	quantum/vial.c:132: __attribute__((unused)) static uint16_t vial_keycode_firewall(uint16_t in) {
                                    792 ;	-----------------------------------------
                                    793 ;	 function vial_keycode_firewall
                                    794 ;	-----------------------------------------
      00B226                        795 _vial_keycode_firewall:
      00B226 12 3A 83         [24]  796 	lcall	_ak820_outline_0103
      00B229 90 0C 65         [24]  797 	mov	dptr,#_vial_keycode_firewall_in_10000_611
      00B22C 12 3A 88         [24]  798 	lcall	_ak820_outline_0104
                                    799 ;	quantum/vial.c:133: if (in == QK_BOOT && !vial_unlocked)
      00B22F 90 0C 65         [24]  800 	mov	dptr,#_vial_keycode_firewall_in_10000_611
      00B232 12 3A 0B         [24]  801 	lcall	_ak820_outline_0011
      00B235 BC 00 0D         [24]  802 	cjne	r4,#0x00,00102$
      00B238 BD 7C 0A         [24]  803 	cjne	r5,#0x7c,00102$
      00B23B 90 0E 2B         [24]  804 	mov	dptr,#_vial_unlocked
      00B23E E0               [24]  805 	movx	a,@dptr
      00B23F 70 04            [24]  806 	jnz	00102$
                                    807 ;	quantum/vial.c:134: return 0;
      00B241 90 00 00         [24]  808 	mov	dptr,#0x0000
      00B244 22               [24]  809 	ret
      00B245                        810 00102$:
                                    811 ;	quantum/vial.c:135: return in;
      00B245 12 45 C9         [24]  812 	lcall	_ak820_outline_0116
                                    813 ;	quantum/vial.c:136: }
      00B248 22               [24]  814 	ret
                                    815 ;------------------------------------------------------------
                                    816 ;Allocation info for local variables in function 'vial_fill_packet'
                                    817 ;------------------------------------------------------------
                                    818 ;value         Allocated with name '_vial_fill_packet_PARM_2'
                                    819 ;msg           Allocated with name '_vial_fill_packet_msg_10000_614'
                                    820 ;i             Allocated with name '_vial_fill_packet_i_20000_616'
                                    821 ;------------------------------------------------------------
                                    822 ;	quantum/vial.c:139: static void vial_fill_packet(uint8_t __xdata *msg, uint8_t value) {
                                    823 ;	-----------------------------------------
                                    824 ;	 function vial_fill_packet
                                    825 ;	-----------------------------------------
      00B249                        826 _vial_fill_packet:
      00B249 12 3A 83         [24]  827 	lcall	_ak820_outline_0103
      00B24C 90 0C 68         [24]  828 	mov	dptr,#_vial_fill_packet_msg_10000_614
      00B24F 12 3A 88         [24]  829 	lcall	_ak820_outline_0104
                                    830 ;	quantum/vial.c:140: for (uint8_t i = 0; i < VIAL_RAW_EPSIZE; ++i) msg[i] = value;
      00B252 90 0C 68         [24]  831 	mov	dptr,#_vial_fill_packet_msg_10000_614
      00B255 12 3A 40         [24]  832 	lcall	_ak820_outline_0051
      00B258 90 0C 67         [24]  833 	mov	dptr,#_vial_fill_packet_PARM_2
      00B25B E0               [24]  834 	movx	a,@dptr
      00B25C FD               [12]  835 	mov	r5,a
      00B25D 7C 00            [12]  836 	mov	r4,#0x00
      00B25F                        837 00103$:
      00B25F BC 20 00         [24]  838 	cjne	r4,#0x20,00122$
      00B262                        839 00122$:
      00B262 50 09            [24]  840 	jnc	00105$
      00B264 EC               [12]  841 	mov	a,r4
      00B265 12 3A 30         [24]  842 	lcall	_ak820_outline_0031
      00B268 ED               [12]  843 	mov	a,r5
      00B269 F0               [24]  844 	movx	@dptr,a
      00B26A 0C               [12]  845 	inc	r4
      00B26B 80 F2            [24]  846 	sjmp	00103$
      00B26D                        847 00105$:
                                    848 ;	quantum/vial.c:141: }
      00B26D 22               [24]  849 	ret
                                    850 ;------------------------------------------------------------
                                    851 ;Allocation info for local variables in function 'vial_release_held_state'
                                    852 ;------------------------------------------------------------
                                    853 ;	quantum/vial.c:152: static void vial_release_held_state(void) {
                                    854 ;	-----------------------------------------
                                    855 ;	 function vial_release_held_state
                                    856 ;	-----------------------------------------
      00B26E                        857 _vial_release_held_state:
                                    858 ;	quantum/vial.c:174: repeat_key_cancel();
      00B26E 12 A6 88         [24]  859 	lcall	_repeat_key_cancel
                                    860 ;	quantum/vial.c:176: clear_keyboard();
                                    861 ;	quantum/vial.c:177: }
      00B271 02 7C FF         [24]  862 	ljmp	_clear_keyboard
                                    863 ;------------------------------------------------------------
                                    864 ;Allocation info for local variables in function 'vial_handle_cmd'
                                    865 ;------------------------------------------------------------
                                    866 ;sloc0         Allocated with name '_vial_handle_cmd_sloc0_1_0'
                                    867 ;sloc1         Allocated with name '_vial_handle_cmd_sloc1_1_0'
                                    868 ;sloc2         Allocated with name '_vial_handle_cmd_sloc2_1_0'
                                    869 ;sloc3         Allocated with name '_vial_handle_cmd_sloc3_1_0'
                                    870 ;length        Allocated with name '_vial_handle_cmd_PARM_2'
                                    871 ;data          Allocated with name '_vial_handle_cmd_data_10000_619'
                                    872 ;msg           Allocated with name '_vial_handle_cmd_msg_10000_620'
                                    873 ;i             Allocated with name '_vial_handle_cmd_i_50000_625'
                                    874 ;sz            Allocated with name '_vial_handle_cmd_sz_40000_626'
                                    875 ;page          Allocated with name '_vial_handle_cmd_page_40001_629'
                                    876 ;start         Allocated with name '_vial_handle_cmd_start_40002_631'
                                    877 ;remaining     Allocated with name '_vial_handle_cmd_remaining_40002_631'
                                    878 ;count         Allocated with name '_vial_handle_cmd_count_40002_631'
                                    879 ;i             Allocated with name '_vial_handle_cmd_i_50002_632'
                                    880 ;layer         Allocated with name '_vial_handle_cmd_layer_40000_633'
                                    881 ;idx           Allocated with name '_vial_handle_cmd_idx_40000_633'
                                    882 ;keycode       Allocated with name '_vial_handle_cmd_keycode_40000_633'
                                    883 ;i             Allocated with name '_vial_handle_cmd_i_50000_636'
                                    884 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_647'
                                    885 ;entry         Allocated with name '_vial_handle_cmd_entry_70000_647'
                                    886 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_648'
                                    887 ;entry         Allocated with name '_vial_handle_cmd_entry_70000_648'
                                    888 ;------------------------------------------------------------
                                    889 ;	quantum/vial.c:180: void vial_handle_cmd(uint8_t *data, uint8_t length) {
                                    890 ;	-----------------------------------------
                                    891 ;	 function vial_handle_cmd
                                    892 ;	-----------------------------------------
      00B274                        893 _vial_handle_cmd:
      00B274 12 45 87         [24]  894 	lcall	_ak820_outline_0037
      00B277 90 0C 6B         [24]  895 	mov	dptr,#_vial_handle_cmd_data_10000_619
      00B27A 12 3A 1F         [24]  896 	lcall	_ak820_outline_0016
                                    897 ;	quantum/vial.c:184: uint8_t __xdata *msg = (uint8_t __xdata *)data;
      00B27D 90 0C 6B         [24]  898 	mov	dptr,#_vial_handle_cmd_data_10000_619
      00B280 12 3A 40         [24]  899 	lcall	_ak820_outline_0051
                                    900 ;	quantum/vial.c:189: if (length != VIAL_RAW_EPSIZE)
      00B283 90 0C 6A         [24]  901 	mov	dptr,#_vial_handle_cmd_PARM_2
      00B286 E0               [24]  902 	movx	a,@dptr
      00B287 FD               [12]  903 	mov	r5,a
      00B288 BD 20 02         [24]  904 	cjne	r5,#0x20,00258$
      00B28B 80 01            [24]  905 	sjmp	00102$
      00B28D                        906 00258$:
                                    907 ;	quantum/vial.c:190: return;
      00B28D 22               [24]  908 	ret
      00B28E                        909 00102$:
                                    910 ;	quantum/vial.c:193: switch (msg[1]) {
      00B28E 74 01            [12]  911 	mov	a,#0x01
      00B290 12 4B 65         [24]  912 	lcall	_ak820_outline_0012
      00B293 FB               [12]  913 	mov  r3,a
      00B294 24 F2            [12]  914 	add	a,#0xff - 0x0d
      00B296 50 01            [24]  915 	jnc	00259$
      00B298 22               [24]  916 	ret
      00B299                        917 00259$:
                                    918 ;	free result
      00B299 EB               [12]  919 	mov	a,r3
      00B29A 24 0A            [12]  920 	add	a,#(00260$-3-.)
      00B29C 83               [24]  921 	movc	a,@a+pc
      00B29D F5 82            [12]  922 	mov	dpl,a
      00B29F EB               [12]  923 	mov	a,r3
      00B2A0 24 12            [12]  924 	add	a,#(00261$-3-.)
      00B2A2 83               [24]  925 	movc	a,@a+pc
      00B2A3 F5 83            [12]  926 	mov	dph,a
      00B2A5 E4               [12]  927 	clr	a
      00B2A6 73               [24]  928 	jmp	@a+dptr
      00B2A7                        929 00260$:
      00B2A7 C3                     930 	.db	00103$
      00B2A8 0B                     931 	.db	00105$
      00B2A9 1F                     932 	.db	00106$
      00B2AA AB                     933 	.db	00112$
      00B2AB 31                     934 	.db	00113$
      00B2AC 7C                     935 	.db	00114$
      00B2AD EB                     936 	.db	00116$
      00B2AE 06                     937 	.db	00119$
      00B2AF 26                     938 	.db	00120$
      00B2B0 34                     939 	.db	00121$
      00B2B1 34                     940 	.db	00139$
      00B2B2 34                     941 	.db	00139$
      00B2B3 34                     942 	.db	00139$
      00B2B4 3F                     943 	.db	00122$
      00B2B5                        944 00261$:
      00B2B5 B2                     945 	.db	00103$>>8
      00B2B6 B3                     946 	.db	00105$>>8
      00B2B7 B3                     947 	.db	00106$>>8
      00B2B8 B3                     948 	.db	00112$>>8
      00B2B9 B4                     949 	.db	00113$>>8
      00B2BA B4                     950 	.db	00114$>>8
      00B2BB B4                     951 	.db	00116$>>8
      00B2BC B5                     952 	.db	00119$>>8
      00B2BD B5                     953 	.db	00120$>>8
      00B2BE B5                     954 	.db	00121$>>8
      00B2BF B6                     955 	.db	00139$>>8
      00B2C0 B6                     956 	.db	00139$>>8
      00B2C1 B6                     957 	.db	00139$>>8
      00B2C2 B5                     958 	.db	00122$>>8
                                    959 ;	quantum/vial.c:195: case vial_get_keyboard_id: {
      00B2C3                        960 00103$:
                                    961 ;	quantum/vial.c:198: VIAL_FILL_PACKET(msg, 0, length);
      00B2C3 90 0C 67         [24]  962 	mov	dptr,#_vial_fill_packet_PARM_2
      00B2C6 E4               [12]  963 	clr	a
      00B2C7 12 45 AB         [24]  964 	lcall	_ak820_outline_0061
      00B2CA C0 07            [24]  965 	push	ar7
      00B2CC C0 06            [24]  966 	push	ar6
      00B2CE 12 B2 49         [24]  967 	lcall	_vial_fill_packet
      00B2D1 D0 06            [24]  968 	pop	ar6
      00B2D3 D0 07            [24]  969 	pop	ar7
                                    970 ;	quantum/vial.c:199: msg[0] = VIAL_PROTOCOL_VERSION & 0xFF;
      00B2D5 12 45 C9         [24]  971 	lcall	_ak820_outline_0116
      00B2D8 74 06            [12]  972 	mov	a,#0x06
      00B2DA 12 45 AB         [24]  973 	lcall	_ak820_outline_0061
                                    974 ;	quantum/vial.c:200: msg[1] = (VIAL_PROTOCOL_VERSION >> 8) & 0xFF;
      00B2DD A3               [24]  975 	inc	dptr
      00B2DE E4               [12]  976 	clr	a
      00B2DF 12 45 7F         [24]  977 	lcall	_ak820_outline_0030
                                    978 ;	quantum/vial.c:201: msg[2] = (VIAL_PROTOCOL_VERSION >> 16) & 0xFF;
      00B2E2 12 45 7F         [24]  979 	lcall	_ak820_outline_0030
                                    980 ;	quantum/vial.c:202: msg[3] = (VIAL_PROTOCOL_VERSION >> 24) & 0xFF;
      00B2E5 A3               [24]  981 	inc	dptr
      00B2E6 F0               [24]  982 	movx	@dptr,a
                                    983 ;	quantum/vial.c:203: for (uint8_t i = 0; i < 8; ++i) msg[4 + i] = pgm_read_byte(&keyboard_uid[i]);
      00B2E7 FB               [12]  984 	mov	r3,a
      00B2E8                        985 00131$:
      00B2E8 BB 08 00         [24]  986 	cjne	r3,#0x08,00262$
      00B2EB                        987 00262$:
      00B2EB 50 15            [24]  988 	jnc	00104$
      00B2ED 8B 02            [24]  989 	mov	ar2,r3
      00B2EF 74 04            [12]  990 	mov	a,#0x04
      00B2F1 2A               [12]  991 	add	a, r2
      00B2F2 2E               [12]  992 	add	a, r6
      00B2F3 F9               [12]  993 	mov	r1,a
      00B2F4 E4               [12]  994 	clr	a
      00B2F5 3F               [12]  995 	addc	a,r7
      00B2F6 FA               [12]  996 	mov	r2,a
      00B2F7 EB               [12]  997 	mov	a,r3
      00B2F8 90 C3 FA         [24]  998 	mov	dptr,#_vial_handle_cmd_keyboard_uid_40000_624
      00B2FB 93               [24]  999 	movc	a,@a+dptr
      00B2FC 12 72 AA         [24] 1000 	lcall	_ak820_outline_0136
      00B2FF 0B               [12] 1001 	inc	r3
      00B300 80 E6            [24] 1002 	sjmp	00131$
      00B302                       1003 00104$:
                                   1004 ;	quantum/vial.c:205: msg[12] = 1; /* bit flag to indicate vialrgb is supported - so third-party apps don't have to query json */
      00B302 74 0C            [12] 1005 	mov	a,#0x0c
      00B304 12 3A 30         [24] 1006 	lcall	_ak820_outline_0031
      00B307 74 01            [12] 1007 	mov	a,#0x01
      00B309 F0               [24] 1008 	movx	@dptr,a
                                   1009 ;	quantum/vial.c:207: break;
      00B30A 22               [24] 1010 	ret
                                   1011 ;	quantum/vial.c:210: case vial_get_size: {
      00B30B                       1012 00105$:
                                   1013 ;	quantum/vial.c:212: msg[0] = sz & 0xFF;
      00B30B 12 45 C9         [24] 1014 	lcall	_ak820_outline_0116
      00B30E 74 7C            [12] 1015 	mov	a,#0x7c
      00B310 12 3A 71         [24] 1016 	lcall	_ak820_outline_0096
                                   1017 ;	quantum/vial.c:213: msg[1] = (sz >> 8) & 0xFF;
      00B313 74 01            [12] 1018 	mov	a,#0x01
      00B315 12 45 7F         [24] 1019 	lcall	_ak820_outline_0030
                                   1020 ;	quantum/vial.c:214: msg[2] = (sz >> 16) & 0xFF;
      00B318 E4               [12] 1021 	clr	a
      00B319 12 45 7F         [24] 1022 	lcall	_ak820_outline_0030
                                   1023 ;	quantum/vial.c:215: msg[3] = (sz >> 24) & 0xFF;
      00B31C A3               [24] 1024 	inc	dptr
      00B31D F0               [24] 1025 	movx	@dptr,a
                                   1026 ;	quantum/vial.c:216: break;
      00B31E 22               [24] 1027 	ret
                                   1028 ;	quantum/vial.c:219: case vial_get_def: {
      00B31F                       1029 00106$:
                                   1030 ;	quantum/vial.c:226: if (msg[4] | msg[5]) return;
      00B31F 12 B1 52         [24] 1031 	lcall	_ak820_outline_0020
      00B322 E0               [24] 1032 	movx	a,@dptr
      00B323 FB               [12] 1033 	mov	r3,a
      00B324 12 45 75         [24] 1034 	lcall	_ak820_outline_0010
      00B327 E0               [24] 1035 	movx	a,@dptr
      00B328 4B               [12] 1036 	orl	a,r3
      00B329 60 01            [24] 1037 	jz	00108$
      00B32B 22               [24] 1038 	ret
      00B32C                       1039 00108$:
                                   1040 ;	quantum/vial.c:227: uint16_t page = (uint16_t)msg[2] | ((uint16_t)msg[3] << 8);
      00B32C 12 3A 38         [24] 1041 	lcall	_ak820_outline_0034
      00B32F FB               [12] 1042 	mov	r3,a
      00B330 7A 00            [12] 1043 	mov	r2,#0x00
      00B332 12 B1 49         [24] 1044 	lcall	_ak820_outline_0015
      00B335 F9               [12] 1045 	mov	r1,a
      00B336 E4               [12] 1046 	clr	a
      00B337 42 03            [12] 1047 	orl	ar3,a
      00B339 E9               [12] 1048 	mov	a,r1
      00B33A 42 02            [12] 1049 	orl	ar2,a
                                   1050 ;	quantum/vial.c:228: if (page >= (sizeof(keyboard_definition) + VIAL_RAW_EPSIZE - 1) / VIAL_RAW_EPSIZE) return;
      00B33C C3               [12] 1051 	clr	c
      00B33D EB               [12] 1052 	mov	a,r3
      00B33E 94 0C            [12] 1053 	subb	a,#0x0c
      00B340 EA               [12] 1054 	mov	a,r2
      00B341 94 00            [12] 1055 	subb	a,#0x00
      00B343 40 01            [24] 1056 	jc	00110$
      00B345 22               [24] 1057 	ret
      00B346                       1058 00110$:
                                   1059 ;	quantum/vial.c:229: uint16_t start = page * VIAL_RAW_EPSIZE;
      00B346 EA               [12] 1060 	mov	a,r2
      00B347 C4               [12] 1061 	swap	a
      00B348 23               [12] 1062 	rl	a
      00B349 54 E0            [12] 1063 	anl	a,#0xe0
      00B34B CB               [12] 1064 	xch	a,r3
      00B34C C4               [12] 1065 	swap	a
      00B34D 23               [12] 1066 	rl	a
      00B34E CB               [12] 1067 	xch	a,r3
      00B34F 6B               [12] 1068 	xrl	a,r3
      00B350 CB               [12] 1069 	xch	a,r3
      00B351 54 E0            [12] 1070 	anl	a,#0xe0
      00B353 CB               [12] 1071 	xch	a,r3
      00B354 6B               [12] 1072 	xrl	a,r3
      00B355 FA               [12] 1073 	mov	r2,a
      00B356 8B 42            [24] 1074 	mov	_vial_handle_cmd_sloc0_1_0,r3
      00B358 8A 43            [24] 1075 	mov	(_vial_handle_cmd_sloc0_1_0 + 1),r2
                                   1076 ;	quantum/vial.c:230: uint16_t remaining = sizeof(keyboard_definition) - start;
      00B35A 74 7C            [12] 1077 	mov	a,#0x7c
      00B35C C3               [12] 1078 	clr	c
      00B35D 95 42            [12] 1079 	subb	a,_vial_handle_cmd_sloc0_1_0
      00B35F F8               [12] 1080 	mov	r0,a
      00B360 74 01            [12] 1081 	mov	a,#0x01
      00B362 95 43            [12] 1082 	subb	a,(_vial_handle_cmd_sloc0_1_0 + 1)
      00B364 F9               [12] 1083 	mov	r1,a
                                   1084 ;	quantum/vial.c:231: uint8_t count = remaining < VIAL_RAW_EPSIZE ? remaining : VIAL_RAW_EPSIZE;
      00B365 C3               [12] 1085 	clr	c
      00B366 E8               [12] 1086 	mov	a,r0
      00B367 94 20            [12] 1087 	subb	a,#0x20
      00B369 E9               [12] 1088 	mov	a,r1
      00B36A 94 00            [12] 1089 	subb	a,#0x00
      00B36C 40 02            [24] 1090 	jc	00142$
      00B36E 78 20            [12] 1091 	mov	r0,#0x20
      00B370                       1092 00142$:
                                   1093 ;	quantum/vial.c:232: for (uint8_t i = 0; i < count; ++i) msg[i] = pgm_read_byte(&keyboard_definition[start + i]);
      00B370 79 00            [12] 1094 	mov	r1,#0x00
      00B372                       1095 00134$:
      00B372 C3               [12] 1096 	clr	c
      00B373 E9               [12] 1097 	mov	a,r1
      00B374 98               [12] 1098 	subb	a,r0
      00B375 40 01            [24] 1099 	jc	00267$
      00B377 22               [24] 1100 	ret
      00B378                       1101 00267$:
      00B378 C0 00            [24] 1102 	push	ar0
      00B37A E9               [12] 1103 	mov	a,r1
      00B37B 2E               [12] 1104 	add	a, r6
      00B37C F5 44            [12] 1105 	mov	_vial_handle_cmd_sloc1_1_0,a
      00B37E E4               [12] 1106 	clr	a
      00B37F 3F               [12] 1107 	addc	a, r7
      00B380 F5 45            [12] 1108 	mov	(_vial_handle_cmd_sloc1_1_0 + 1),a
      00B382 89 46            [24] 1109 	mov	_vial_handle_cmd_sloc2_1_0,r1
      00B384 75 47 00         [24] 1110 	mov	(_vial_handle_cmd_sloc2_1_0 + 1),#0x00
      00B387 A8 42            [24] 1111 	mov	r0,_vial_handle_cmd_sloc0_1_0
      00B389 AB 43            [24] 1112 	mov	r3,(_vial_handle_cmd_sloc0_1_0 + 1)
      00B38B E5 46            [12] 1113 	mov	a,_vial_handle_cmd_sloc2_1_0
      00B38D 28               [12] 1114 	add	a, r0
      00B38E F8               [12] 1115 	mov	r0,a
      00B38F E5 47            [12] 1116 	mov	a,(_vial_handle_cmd_sloc2_1_0 + 1)
      00B391 3B               [12] 1117 	addc	a, r3
      00B392 FB               [12] 1118 	mov	r3,a
      00B393 E8               [12] 1119 	mov	a,r0
      00B394 24 7E            [12] 1120 	add	a, #_keyboard_definition
      00B396 F5 82            [12] 1121 	mov	dpl,a
      00B398 EB               [12] 1122 	mov	a,r3
      00B399 34 C2            [12] 1123 	addc	a, #(_keyboard_definition >> 8)
      00B39B F5 83            [12] 1124 	mov	dph,a
      00B39D E4               [12] 1125 	clr	a
      00B39E 93               [24] 1126 	movc	a,@a+dptr
      00B39F 85 44 82         [24] 1127 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00B3A2 85 45 83         [24] 1128 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00B3A5 F0               [24] 1129 	movx	@dptr,a
      00B3A6 09               [12] 1130 	inc	r1
      00B3A7 D0 00            [24] 1131 	pop	ar0
                                   1132 ;	quantum/vial.c:246: case vial_get_encoder: {
      00B3A9 80 C7            [24] 1133 	sjmp	00134$
      00B3AB                       1134 00112$:
                                   1135 ;	quantum/vial.c:247: uint8_t layer = msg[2];
      00B3AB 74 02            [12] 1136 	mov	a,#0x02
      00B3AD 12 4B A3         [24] 1137 	lcall	_ak820_outline_0046
      00B3B0 F5 46            [12] 1138 	mov	_vial_handle_cmd_sloc2_1_0,a
                                   1139 ;	quantum/vial.c:248: uint8_t idx = msg[3];
      00B3B2 74 03            [12] 1140 	mov	a,#0x03
      00B3B4 2E               [12] 1141 	add	a, r6
      00B3B5 F5 44            [12] 1142 	mov	_vial_handle_cmd_sloc1_1_0,a
      00B3B7 E4               [12] 1143 	clr	a
      00B3B8 3F               [12] 1144 	addc	a, r7
      00B3B9 F5 45            [12] 1145 	mov	(_vial_handle_cmd_sloc1_1_0 + 1),a
      00B3BB 85 44 82         [24] 1146 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00B3BE 85 45 83         [24] 1147 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00B3C1 E0               [24] 1148 	movx	a,@dptr
                                   1149 ;	quantum/vial.c:249: uint16_t keycode = dynamic_keymap_get_encoder(layer, idx, 0);
      00B3C2 F5 42            [12] 1150 	mov	_vial_handle_cmd_sloc0_1_0,a
      00B3C4 90 0B 15         [24] 1151 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      00B3C7 F0               [24] 1152 	movx	@dptr,a
      00B3C8 90 0B 16         [24] 1153 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      00B3CB E4               [12] 1154 	clr	a
      00B3CC F0               [24] 1155 	movx	@dptr,a
      00B3CD 85 46 82         [24] 1156 	mov	dpl, _vial_handle_cmd_sloc2_1_0
      00B3D0 C0 07            [24] 1157 	push	ar7
      00B3D2 C0 06            [24] 1158 	push	ar6
      00B3D4 C0 05            [24] 1159 	push	ar5
      00B3D6 C0 04            [24] 1160 	push	ar4
      00B3D8 C0 03            [24] 1161 	push	ar3
      00B3DA C0 02            [24] 1162 	push	ar2
      00B3DC 12 8B 14         [24] 1163 	lcall	_dynamic_keymap_get_encoder
      00B3DF 85 82 48         [24] 1164 	mov	_vial_handle_cmd_sloc3_1_0,dpl
      00B3E2 85 83 49         [24] 1165 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),dph
      00B3E5 D0 02            [24] 1166 	pop	ar2
      00B3E7 D0 03            [24] 1167 	pop	ar3
      00B3E9 D0 04            [24] 1168 	pop	ar4
      00B3EB D0 05            [24] 1169 	pop	ar5
      00B3ED D0 06            [24] 1170 	pop	ar6
      00B3EF D0 07            [24] 1171 	pop	ar7
                                   1172 ;	quantum/vial.c:250: msg[0]  = keycode >> 8;
      00B3F1 A9 49            [24] 1173 	mov	r1,(_vial_handle_cmd_sloc3_1_0 + 1)
      00B3F3 12 45 C9         [24] 1174 	lcall	_ak820_outline_0116
      00B3F6 E9               [12] 1175 	mov	a,r1
      00B3F7 F0               [24] 1176 	movx	@dptr,a
                                   1177 ;	quantum/vial.c:251: msg[1]  = keycode & 0xFF;
      00B3F8 A8 48            [24] 1178 	mov	r0,_vial_handle_cmd_sloc3_1_0
      00B3FA 12 3A A0         [24] 1179 	lcall	_ak820_outline_0121
      00B3FD E8               [12] 1180 	mov	a,r0
      00B3FE F0               [24] 1181 	movx	@dptr,a
                                   1182 ;	quantum/vial.c:252: keycode = dynamic_keymap_get_encoder(layer, idx, 1);
      00B3FF 90 0B 15         [24] 1183 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      00B402 E5 42            [12] 1184 	mov	a,_vial_handle_cmd_sloc0_1_0
      00B404 F0               [24] 1185 	movx	@dptr,a
      00B405 90 0B 16         [24] 1186 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      00B408 74 01            [12] 1187 	mov	a,#0x01
      00B40A F0               [24] 1188 	movx	@dptr,a
      00B40B 85 46 82         [24] 1189 	mov	dpl, _vial_handle_cmd_sloc2_1_0
      00B40E C0 03            [24] 1190 	push	ar3
      00B410 C0 02            [24] 1191 	push	ar2
      00B412 12 8B 14         [24] 1192 	lcall	_dynamic_keymap_get_encoder
      00B415 85 82 48         [24] 1193 	mov	_vial_handle_cmd_sloc3_1_0,dpl
      00B418 85 83 49         [24] 1194 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),dph
      00B41B D0 02            [24] 1195 	pop	ar2
      00B41D D0 03            [24] 1196 	pop	ar3
                                   1197 ;	quantum/vial.c:253: msg[2] = keycode >> 8;
      00B41F A9 49            [24] 1198 	mov	r1,(_vial_handle_cmd_sloc3_1_0 + 1)
      00B421 12 45 E5         [24] 1199 	lcall	_ak820_outline_0142
      00B424 E9               [12] 1200 	mov	a,r1
      00B425 F0               [24] 1201 	movx	@dptr,a
                                   1202 ;	quantum/vial.c:254: msg[3] = keycode & 0xFF;
      00B426 A8 48            [24] 1203 	mov	r0,_vial_handle_cmd_sloc3_1_0
      00B428 85 44 82         [24] 1204 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00B42B 85 45 83         [24] 1205 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00B42E E8               [12] 1206 	mov	a,r0
      00B42F F0               [24] 1207 	movx	@dptr,a
                                   1208 ;	quantum/vial.c:255: break;
      00B430 22               [24] 1209 	ret
                                   1210 ;	quantum/vial.c:257: case vial_set_encoder: {
      00B431                       1211 00113$:
                                   1212 ;	quantum/vial.c:258: dynamic_keymap_set_encoder(msg[2], msg[3], msg[4], vial_keycode_firewall((msg[5] << 8) | msg[6]));
      00B431 12 3A 38         [24] 1213 	lcall	_ak820_outline_0034
      00B434 F5 44            [12] 1214 	mov	_vial_handle_cmd_sloc1_1_0,a
      00B436 12 B1 49         [24] 1215 	lcall	_ak820_outline_0015
      00B439 F5 46            [12] 1216 	mov	_vial_handle_cmd_sloc2_1_0,a
      00B43B 12 B1 52         [24] 1217 	lcall	_ak820_outline_0020
      00B43E E0               [24] 1218 	movx	a,@dptr
                                   1219 ;	assignBit
      00B43F 24 FF            [12] 1220 	add	a,#0xff
      00B441 E4               [12] 1221 	clr	a
      00B442 33               [12] 1222 	rlc	a
      00B443 F5 48            [12] 1223 	mov	_vial_handle_cmd_sloc3_1_0,a
      00B445 12 45 75         [24] 1224 	lcall	_ak820_outline_0010
      00B448 E0               [24] 1225 	movx	a,@dptr
      00B449 F9               [12] 1226 	mov	r1,a
      00B44A 78 00            [12] 1227 	mov	r0,#0x00
      00B44C 74 06            [12] 1228 	mov	a,#0x06
      00B44E 12 3A 27         [24] 1229 	lcall	_ak820_outline_0017
      00B451 7B 00            [12] 1230 	mov	r3,#0x00
      00B453 42 00            [12] 1231 	orl	ar0,a
      00B455 EB               [12] 1232 	mov	a,r3
      00B456 42 01            [12] 1233 	orl	ar1,a
      00B458 12 3A B5         [24] 1234 	lcall	_ak820_outline_0155
      00B45B 12 B2 26         [24] 1235 	lcall	_vial_keycode_firewall
      00B45E AA 82            [24] 1236 	mov	r2, dpl
      00B460 AB 83            [24] 1237 	mov	r3, dph
      00B462 90 0B 18         [24] 1238 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      00B465 E5 46            [12] 1239 	mov	a,_vial_handle_cmd_sloc2_1_0
      00B467 F0               [24] 1240 	movx	@dptr,a
      00B468 90 0B 19         [24] 1241 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      00B46B E5 48            [12] 1242 	mov	a,_vial_handle_cmd_sloc3_1_0
      00B46D F0               [24] 1243 	movx	@dptr,a
      00B46E 90 0B 1A         [24] 1244 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      00B471 EA               [12] 1245 	mov	a,r2
      00B472 F0               [24] 1246 	movx	@dptr,a
      00B473 EB               [12] 1247 	mov	a,r3
      00B474 A3               [24] 1248 	inc	dptr
      00B475 F0               [24] 1249 	movx	@dptr,a
      00B476 85 44 82         [24] 1250 	mov	dpl, _vial_handle_cmd_sloc1_1_0
                                   1251 ;	quantum/vial.c:259: break;
      00B479 02 8B 7A         [24] 1252 	ljmp	_dynamic_keymap_set_encoder
                                   1253 ;	quantum/vial.c:262: case vial_get_unlock_status: {
      00B47C                       1254 00114$:
                                   1255 ;	quantum/vial.c:264: VIAL_FILL_PACKET(msg, 0xFF, length);
      00B47C 90 0C 67         [24] 1256 	mov	dptr,#_vial_fill_packet_PARM_2
      00B47F 74 FF            [12] 1257 	mov	a,#0xff
      00B481 12 45 AB         [24] 1258 	lcall	_ak820_outline_0061
      00B484 C0 07            [24] 1259 	push	ar7
      00B486 C0 06            [24] 1260 	push	ar6
      00B488 12 B2 49         [24] 1261 	lcall	_vial_fill_packet
      00B48B D0 06            [24] 1262 	pop	ar6
      00B48D D0 07            [24] 1263 	pop	ar7
                                   1264 ;	quantum/vial.c:266: msg[0] = vial_unlocked;
      00B48F 90 0E 2B         [24] 1265 	mov	dptr,#_vial_unlocked
      00B492 E0               [24] 1266 	movx	a,@dptr
      00B493 12 45 C9         [24] 1267 	lcall	_ak820_outline_0116
      00B496 F0               [24] 1268 	movx	@dptr,a
                                   1269 ;	quantum/vial.c:268: msg[1] = vial_unlock_in_progress;
      00B497 74 01            [12] 1270 	mov	a,#0x01
      00B499 2E               [12] 1271 	add	a, r6
      00B49A FA               [12] 1272 	mov	r2,a
      00B49B E4               [12] 1273 	clr	a
      00B49C 3F               [12] 1274 	addc	a, r7
      00B49D FB               [12] 1275 	mov	r3,a
      00B49E 90 0E 2C         [24] 1276 	mov	dptr,#_vial_unlock_in_progress
      00B4A1 E0               [24] 1277 	movx	a,@dptr
      00B4A2 12 45 E5         [24] 1278 	lcall	_ak820_outline_0142
      00B4A5 F0               [24] 1279 	movx	@dptr,a
                                   1280 ;	quantum/vial.c:271: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B4A6 7B 00            [12] 1281 	mov	r3,#0x00
      00B4A8                       1282 00137$:
      00B4A8 BB 02 00         [24] 1283 	cjne	r3,#0x02,00268$
      00B4AB                       1284 00268$:
      00B4AB 40 01            [24] 1285 	jc	00269$
      00B4AD 22               [24] 1286 	ret
      00B4AE                       1287 00269$:
                                   1288 ;	quantum/vial.c:272: msg[2 + i * 2] = vial_unlock_combo_rows[i];
      00B4AE 8B 01            [24] 1289 	mov	ar1,r3
      00B4B0 7A 00            [12] 1290 	mov	r2,#0x00
      00B4B2 E9               [12] 1291 	mov	a,r1
      00B4B3 29               [12] 1292 	add	a,r1
      00B4B4 F5 48            [12] 1293 	mov	_vial_handle_cmd_sloc3_1_0,a
      00B4B6 EA               [12] 1294 	mov	a,r2
      00B4B7 33               [12] 1295 	rlc	a
      00B4B8 F5 49            [12] 1296 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),a
      00B4BA 74 02            [12] 1297 	mov	a,#0x02
      00B4BC 25 48            [12] 1298 	add	a, _vial_handle_cmd_sloc3_1_0
      00B4BE F8               [12] 1299 	mov	r0,a
      00B4BF E4               [12] 1300 	clr	a
      00B4C0 35 49            [12] 1301 	addc	a, (_vial_handle_cmd_sloc3_1_0 + 1)
      00B4C2 FA               [12] 1302 	mov	r2,a
      00B4C3 E8               [12] 1303 	mov	a,r0
      00B4C4 2E               [12] 1304 	add	a, r6
      00B4C5 F8               [12] 1305 	mov	r0,a
      00B4C6 EA               [12] 1306 	mov	a,r2
      00B4C7 3F               [12] 1307 	addc	a, r7
      00B4C8 FA               [12] 1308 	mov	r2,a
      00B4C9 EB               [12] 1309 	mov	a,r3
      00B4CA 12 B7 51         [24] 1310 	lcall	_ak820_outline_0126
      00B4CD 88 82            [24] 1311 	mov	dpl,r0
      00B4CF 8A 83            [24] 1312 	mov	dph,r2
      00B4D1 F0               [24] 1313 	movx	@dptr,a
                                   1314 ;	quantum/vial.c:273: msg[2 + i * 2 + 1] = vial_unlock_combo_cols[i];
      00B4D2 74 03            [12] 1315 	mov	a,#0x03
      00B4D4 25 48            [12] 1316 	add	a, _vial_handle_cmd_sloc3_1_0
      00B4D6 F9               [12] 1317 	mov	r1,a
      00B4D7 E4               [12] 1318 	clr	a
      00B4D8 35 49            [12] 1319 	addc	a, (_vial_handle_cmd_sloc3_1_0 + 1)
      00B4DA FA               [12] 1320 	mov	r2,a
      00B4DB E9               [12] 1321 	mov	a,r1
      00B4DC 2E               [12] 1322 	add	a, r6
      00B4DD F9               [12] 1323 	mov	r1,a
      00B4DE EA               [12] 1324 	mov	a,r2
      00B4DF 3F               [12] 1325 	addc	a, r7
      00B4E0 FA               [12] 1326 	mov	r2,a
      00B4E1 EB               [12] 1327 	mov	a,r3
      00B4E2 12 B7 46         [24] 1328 	lcall	_ak820_outline_0125
      00B4E5 12 72 AA         [24] 1329 	lcall	_ak820_outline_0136
                                   1330 ;	quantum/vial.c:271: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B4E8 0B               [12] 1331 	inc	r3
                                   1332 ;	quantum/vial.c:278: case vial_unlock_start: {
      00B4E9 80 BD            [24] 1333 	sjmp	00137$
      00B4EB                       1334 00116$:
                                   1335 ;	quantum/vial.c:280: if (!vial_unlock_in_progress) vial_release_held_state();
      00B4EB 90 0E 2C         [24] 1336 	mov	dptr,#_vial_unlock_in_progress
      00B4EE E0               [24] 1337 	movx	a,@dptr
      00B4EF 70 03            [24] 1338 	jnz	00118$
      00B4F1 12 B2 6E         [24] 1339 	lcall	_vial_release_held_state
      00B4F4                       1340 00118$:
                                   1341 ;	quantum/vial.c:282: vial_unlock_in_progress = 1;
      00B4F4 90 0E 2C         [24] 1342 	mov	dptr,#_vial_unlock_in_progress
      00B4F7 74 01            [12] 1343 	mov	a,#0x01
      00B4F9 F0               [24] 1344 	movx	@dptr,a
                                   1345 ;	quantum/vial.c:283: vial_unlock_counter = VIAL_UNLOCK_COUNTER_MAX;
      00B4FA 90 0E 2D         [24] 1346 	mov	dptr,#_vial_unlock_counter
      00B4FD 74 1E            [12] 1347 	mov	a,#0x1e
      00B4FF F0               [24] 1348 	movx	@dptr,a
                                   1349 ;	quantum/vial.c:285: vial_unlock_holding = false;
      00B500 90 0C 64         [24] 1350 	mov	dptr,#_vial_unlock_holding
      00B503 E4               [12] 1351 	clr	a
      00B504 F0               [24] 1352 	movx	@dptr,a
                                   1353 ;	quantum/vial.c:287: break;
      00B505 22               [24] 1354 	ret
                                   1355 ;	quantum/vial.c:289: case vial_unlock_poll: {
      00B506                       1356 00119$:
                                   1357 ;	quantum/vial.c:290: msg[0] = vial_unlocked;
      00B506 90 0E 2B         [24] 1358 	mov	dptr,#_vial_unlocked
      00B509 E0               [24] 1359 	movx	a,@dptr
      00B50A 12 45 C9         [24] 1360 	lcall	_ak820_outline_0116
      00B50D F0               [24] 1361 	movx	@dptr,a
                                   1362 ;	quantum/vial.c:291: msg[1] = vial_unlock_in_progress;
      00B50E 90 0E 2C         [24] 1363 	mov	dptr,#_vial_unlock_in_progress
      00B511 E0               [24] 1364 	movx	a,@dptr
      00B512 12 3A A0         [24] 1365 	lcall	_ak820_outline_0121
      00B515 F0               [24] 1366 	movx	@dptr,a
                                   1367 ;	quantum/vial.c:292: msg[2] = vial_unlock_counter;
      00B516 74 02            [12] 1368 	mov	a,#0x02
      00B518 2E               [12] 1369 	add	a, r6
      00B519 FA               [12] 1370 	mov	r2,a
      00B51A E4               [12] 1371 	clr	a
      00B51B 3F               [12] 1372 	addc	a, r7
      00B51C FB               [12] 1373 	mov	r3,a
      00B51D 90 0E 2D         [24] 1374 	mov	dptr,#_vial_unlock_counter
      00B520 E0               [24] 1375 	movx	a,@dptr
      00B521 12 45 E5         [24] 1376 	lcall	_ak820_outline_0142
      00B524 F0               [24] 1377 	movx	@dptr,a
                                   1378 ;	quantum/vial.c:293: break;
      00B525 22               [24] 1379 	ret
                                   1380 ;	quantum/vial.c:295: case vial_lock: {
      00B526                       1381 00120$:
                                   1382 ;	quantum/vial.c:297: vial_unlocked = 0;
      00B526 90 0E 2B         [24] 1383 	mov	dptr,#_vial_unlocked
      00B529 E4               [12] 1384 	clr	a
      00B52A F0               [24] 1385 	movx	@dptr,a
                                   1386 ;	quantum/vial.c:298: vial_unlock_in_progress = 0;
      00B52B 90 0E 2C         [24] 1387 	mov	dptr,#_vial_unlock_in_progress
      00B52E F0               [24] 1388 	movx	@dptr,a
                                   1389 ;	quantum/vial.c:299: vial_unlock_holding = false;
      00B52F 90 0C 64         [24] 1390 	mov	dptr,#_vial_unlock_holding
      00B532 F0               [24] 1391 	movx	@dptr,a
                                   1392 ;	quantum/vial.c:301: break;
      00B533 22               [24] 1393 	ret
                                   1394 ;	quantum/vial.c:303: case vial_qmk_settings_query: {
      00B534                       1395 00121$:
                                   1396 ;	quantum/vial.c:312: VIAL_FILL_PACKET(msg, 0xFF, length); /* indicate that we don't support any qsid */
      00B534 90 0C 67         [24] 1397 	mov	dptr,#_vial_fill_packet_PARM_2
      00B537 74 FF            [12] 1398 	mov	a,#0xff
      00B539 12 45 AB         [24] 1399 	lcall	_ak820_outline_0061
                                   1400 ;	quantum/vial.c:314: break;
      00B53C 02 B2 49         [24] 1401 	ljmp	_vial_fill_packet
                                   1402 ;	quantum/vial.c:346: case vial_dynamic_entry_op: {
      00B53F                       1403 00122$:
                                   1404 ;	quantum/vial.c:347: switch (msg[2]) {
      00B53F 12 3A 38         [24] 1405 	lcall	_ak820_outline_0034
      00B542 FB               [12] 1406 	mov	r3,a
      00B543 60 0C            [24] 1407 	jz	00123$
      00B545 BB 03 02         [24] 1408 	cjne	r3,#0x03,00272$
      00B548 80 31            [24] 1409 	sjmp	00124$
      00B54A                       1410 00272$:
      00B54A BB 04 03         [24] 1411 	cjne	r3,#0x04,00273$
      00B54D 02 B5 D9         [24] 1412 	ljmp	00125$
      00B550                       1413 00273$:
      00B550 22               [24] 1414 	ret
                                   1415 ;	quantum/vial.c:348: case dynamic_vial_get_number_of_entries: {
      00B551                       1416 00123$:
                                   1417 ;	quantum/vial.c:349: VIAL_FILL_PACKET(msg, 0, length);
      00B551 90 0C 67         [24] 1418 	mov	dptr,#_vial_fill_packet_PARM_2
      00B554 E4               [12] 1419 	clr	a
      00B555 12 45 AB         [24] 1420 	lcall	_ak820_outline_0061
      00B558 C0 07            [24] 1421 	push	ar7
      00B55A C0 06            [24] 1422 	push	ar6
      00B55C 12 B2 49         [24] 1423 	lcall	_vial_fill_packet
      00B55F D0 06            [24] 1424 	pop	ar6
      00B561 D0 07            [24] 1425 	pop	ar7
                                   1426 ;	quantum/vial.c:350: msg[0] = VIAL_TAP_DANCE_ENTRIES;
      00B563 12 45 C9         [24] 1427 	lcall	_ak820_outline_0116
      00B566 E4               [12] 1428 	clr	a
      00B567 12 45 AB         [24] 1429 	lcall	_ak820_outline_0061
                                   1430 ;	quantum/vial.c:351: msg[1] = VIAL_COMBO_ENTRIES;
      00B56A A3               [24] 1431 	inc	dptr
      00B56B 74 08            [12] 1432 	mov	a,#0x08
      00B56D 12 45 7F         [24] 1433 	lcall	_ak820_outline_0030
                                   1434 ;	quantum/vial.c:352: msg[2] = VIAL_KEY_OVERRIDE_ENTRIES;
      00B570 E4               [12] 1435 	clr	a
      00B571 F0               [24] 1436 	movx	@dptr,a
                                   1437 ;	quantum/vial.c:354: msg[VIAL_RAW_EPSIZE - 1] = 1; /* Standard Vial feature bit 0. */
      00B572 74 1F            [12] 1438 	mov	a,#0x1f
      00B574 12 3A 30         [24] 1439 	lcall	_ak820_outline_0031
      00B577 74 01            [12] 1440 	mov	a,#0x01
      00B579 F0               [24] 1441 	movx	@dptr,a
                                   1442 ;	quantum/vial.c:356: break;
      00B57A 22               [24] 1443 	ret
                                   1444 ;	quantum/vial.c:382: case dynamic_vial_combo_get: {
      00B57B                       1445 00124$:
                                   1446 ;	quantum/vial.c:383: uint8_t idx = msg[3];
      00B57B 12 B1 49         [24] 1447 	lcall	_ak820_outline_0015
      00B57E FB               [12] 1448 	mov	r3,a
                                   1449 ;	quantum/vial.c:384: vial_combo_entry_t entry = { { 0 }, 0 };
      00B57F 90 0C 6E         [24] 1450 	mov	dptr,#_vial_handle_cmd_entry_70000_647
      00B582 12 52 8E         [24] 1451 	lcall	_ak820_outline_0178
      00B585 90 0C 70         [24] 1452 	mov	dptr,#(_vial_handle_cmd_entry_70000_647 + 0x0002)
      00B588 F0               [24] 1453 	movx	@dptr,a
      00B589 A3               [24] 1454 	inc	dptr
      00B58A F0               [24] 1455 	movx	@dptr,a
      00B58B 90 0C 72         [24] 1456 	mov	dptr,#(_vial_handle_cmd_entry_70000_647 + 0x0004)
      00B58E F0               [24] 1457 	movx	@dptr,a
      00B58F A3               [24] 1458 	inc	dptr
      00B590 F0               [24] 1459 	movx	@dptr,a
      00B591 90 0C 74         [24] 1460 	mov	dptr,#(_vial_handle_cmd_entry_70000_647 + 0x0006)
      00B594 F0               [24] 1461 	movx	@dptr,a
      00B595 A3               [24] 1462 	inc	dptr
      00B596 F0               [24] 1463 	movx	@dptr,a
      00B597 90 0C 76         [24] 1464 	mov	dptr,#(_vial_handle_cmd_entry_70000_647 + 0x0008)
      00B59A F0               [24] 1465 	movx	@dptr,a
      00B59B A3               [24] 1466 	inc	dptr
      00B59C F0               [24] 1467 	movx	@dptr,a
                                   1468 ;	quantum/vial.c:385: msg[0] = dynamic_keymap_get_combo(idx, &entry);
      00B59D 90 0B 1D         [24] 1469 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      00B5A0 74 6E            [12] 1470 	mov	a,#_vial_handle_cmd_entry_70000_647
      00B5A2 F0               [24] 1471 	movx	@dptr,a
      00B5A3 74 0C            [12] 1472 	mov	a,#(_vial_handle_cmd_entry_70000_647 >> 8)
      00B5A5 12 3A 94         [24] 1473 	lcall	_ak820_outline_0117
      00B5A8 8B 82            [24] 1474 	mov	dpl, r3
      00B5AA C0 07            [24] 1475 	push	ar7
      00B5AC C0 06            [24] 1476 	push	ar6
      00B5AE C0 05            [24] 1477 	push	ar5
      00B5B0 C0 04            [24] 1478 	push	ar4
      00B5B2 12 8B E5         [24] 1479 	lcall	_dynamic_keymap_get_combo
      00B5B5 AA 82            [24] 1480 	mov	r2, dpl
      00B5B7 D0 04            [24] 1481 	pop	ar4
      00B5B9 D0 05            [24] 1482 	pop	ar5
      00B5BB D0 06            [24] 1483 	pop	ar6
      00B5BD D0 07            [24] 1484 	pop	ar7
      00B5BF 12 45 C9         [24] 1485 	lcall	_ak820_outline_0116
      00B5C2 EA               [12] 1486 	mov	a,r2
      00B5C3 F0               [24] 1487 	movx	@dptr,a
                                   1488 ;	quantum/vial.c:386: memcpy(&msg[1], &entry, sizeof(entry));
      00B5C4 7B 00            [12] 1489 	mov	r3,#0x00
      00B5C6 90 0D AA         [24] 1490 	mov	dptr,#___memcpy_PARM_2
      00B5C9 74 6E            [12] 1491 	mov	a,#_vial_handle_cmd_entry_70000_647
      00B5CB F0               [24] 1492 	movx	@dptr,a
      00B5CC 74 0C            [12] 1493 	mov	a,#(_vial_handle_cmd_entry_70000_647 >> 8)
      00B5CE 12 B7 37         [24] 1494 	lcall	_ak820_outline_0073
      00B5D1 12 3A A0         [24] 1495 	lcall	_ak820_outline_0121
      00B5D4 8B F0            [24] 1496 	mov	b, r3
                                   1497 ;	quantum/vial.c:387: break;
      00B5D6 02 BC F8         [24] 1498 	ljmp	___memcpy
                                   1499 ;	quantum/vial.c:389: case dynamic_vial_combo_set: {
      00B5D9                       1500 00125$:
                                   1501 ;	quantum/vial.c:390: uint8_t idx = msg[3];
      00B5D9 12 B1 49         [24] 1502 	lcall	_ak820_outline_0015
      00B5DC FD               [12] 1503 	mov	r5,a
                                   1504 ;	quantum/vial.c:392: memcpy(&entry, &msg[4], sizeof(entry));
      00B5DD 74 04            [12] 1505 	mov	a,#0x04
      00B5DF 2E               [12] 1506 	add	a, r6
      00B5E0 FB               [12] 1507 	mov	r3,a
      00B5E1 E4               [12] 1508 	clr	a
      00B5E2 3F               [12] 1509 	addc	a, r7
      00B5E3 FC               [12] 1510 	mov	r4,a
      00B5E4 90 0D AA         [24] 1511 	mov	dptr,#___memcpy_PARM_2
      00B5E7 EB               [12] 1512 	mov	a,r3
      00B5E8 F0               [24] 1513 	movx	@dptr,a
      00B5E9 EC               [12] 1514 	mov	a,r4
      00B5EA 12 B7 37         [24] 1515 	lcall	_ak820_outline_0073
      00B5ED 90 0C 78         [24] 1516 	mov	dptr,#_vial_handle_cmd_entry_70000_648
      00B5F0 F5 F0            [12] 1517 	mov	b,a
      00B5F2 C0 07            [24] 1518 	push	ar7
      00B5F4 C0 06            [24] 1519 	push	ar6
      00B5F6 C0 05            [24] 1520 	push	ar5
      00B5F8 12 BC F8         [24] 1521 	lcall	___memcpy
                                   1522 ;	quantum/vial.c:393: entry.output = vial_keycode_firewall(entry.output);
      00B5FB 90 0C 80         [24] 1523 	mov	dptr,#(_vial_handle_cmd_entry_70000_648 + 0x0008)
      00B5FE 12 3A 9A         [24] 1524 	lcall	_ak820_outline_0120
      00B601 12 36 42         [24] 1525 	lcall	_ak820_outline_0122
      00B604 12 B2 26         [24] 1526 	lcall	_vial_keycode_firewall
      00B607 AB 82            [24] 1527 	mov	r3, dpl
      00B609 AC 83            [24] 1528 	mov	r4, dph
      00B60B D0 05            [24] 1529 	pop	ar5
      00B60D 90 0C 80         [24] 1530 	mov	dptr,#(_vial_handle_cmd_entry_70000_648 + 0x0008)
      00B610 12 3A 6B         [24] 1531 	lcall	_ak820_outline_0076
                                   1532 ;	quantum/vial.c:394: msg[0] = dynamic_keymap_set_combo(idx, &entry);
      00B613 90 0B 21         [24] 1533 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      00B616 74 78            [12] 1534 	mov	a,#_vial_handle_cmd_entry_70000_648
      00B618 F0               [24] 1535 	movx	@dptr,a
      00B619 74 0C            [12] 1536 	mov	a,#(_vial_handle_cmd_entry_70000_648 >> 8)
      00B61B 12 3A 94         [24] 1537 	lcall	_ak820_outline_0117
      00B61E 8D 82            [24] 1538 	mov	dpl, r5
      00B620 12 8C 8C         [24] 1539 	lcall	_dynamic_keymap_set_combo
      00B623 AC 82            [24] 1540 	mov	r4, dpl
      00B625 D0 06            [24] 1541 	pop	ar6
      00B627 D0 07            [24] 1542 	pop	ar7
      00B629 12 45 C9         [24] 1543 	lcall	_ak820_outline_0116
      00B62C EC               [12] 1544 	mov	a,r4
      00B62D F0               [24] 1545 	movx	@dptr,a
                                   1546 ;	quantum/vial.c:395: if (!msg[0]) reload_combo();
      00B62E EC               [12] 1547 	mov	a,r4
      00B62F 70 03            [24] 1548 	jnz	00139$
                                   1549 ;	quantum/vial.c:423: }
                                   1550 ;	quantum/vial.c:424: }
      00B631 02 37 7D         [24] 1551 	ljmp	_ak820_combo_reload
      00B634                       1552 00139$:
      00B634 22               [24] 1553 	ret
                                   1554 ;------------------------------------------------------------
                                   1555 ;Allocation info for local variables in function 'vial_keycode_down'
                                   1556 ;------------------------------------------------------------
                                   1557 ;keycode       Allocated with name '_vial_keycode_down_keycode_10000_650'
                                   1558 ;dummy_event   Allocated with name '_vial_keycode_down_dummy_event_30000_657'
                                   1559 ;------------------------------------------------------------
                                   1560 ;	quantum/vial.c:428: void vial_keycode_down(uint16_t keycode) {
                                   1561 ;	-----------------------------------------
                                   1562 ;	 function vial_keycode_down
                                   1563 ;	-----------------------------------------
      00B635                       1564 _vial_keycode_down:
      00B635 12 3A 83         [24] 1565 	lcall	_ak820_outline_0103
      00B638 90 0C 84         [24] 1566 	mov	dptr,#_vial_keycode_down_keycode_10000_650
      00B63B 12 3A 88         [24] 1567 	lcall	_ak820_outline_0104
                                   1568 ;	quantum/vial.c:432: if (keycode >= QK_MOD_TAP && keycode <= QK_LAYER_TAP_MAX) {
      00B63E 90 0C 84         [24] 1569 	mov	dptr,#_vial_keycode_down_keycode_10000_650
      00B641 12 3A 0B         [24] 1570 	lcall	_ak820_outline_0011
      00B644 74 E0            [12] 1571 	mov	a,#0x100 - 0x20
      00B646 2D               [12] 1572 	add	a,r5
      00B647 50 19            [24] 1573 	jnc	00104$
      00B649 C3               [12] 1574 	clr	c
      00B64A 74 FF            [12] 1575 	mov	a,#0xff
      00B64C 9C               [12] 1576 	subb	a,r4
      00B64D 74 4F            [12] 1577 	mov	a,#0x4f
      00B64F 9D               [12] 1578 	subb	a,r5
      00B650 40 10            [24] 1579 	jc	00104$
                                   1580 ;	free result
                                   1581 ;	quantum/vial.c:433: keycode = (uint8_t)keycode;
      00B652 90 0C 84         [24] 1582 	mov	dptr,#_vial_keycode_down_keycode_10000_650
      00B655 EE               [12] 1583 	mov	a,r6
      00B656 12 3A A5         [24] 1584 	lcall	_ak820_outline_0123
                                   1585 ;	quantum/vial.c:434: if (keycode <= KC_TRANSPARENT) return;
      00B659 90 0C 84         [24] 1586 	mov	dptr,#_vial_keycode_down_keycode_10000_650
      00B65C E0               [24] 1587 	movx	a,@dptr
      00B65D 24 FE            [12] 1588 	add	a,#0xff - 0x01
      00B65F 40 01            [24] 1589 	jc	00104$
                                   1590 ;	free result
      00B661 22               [24] 1591 	ret
      00B662                       1592 00104$:
                                   1593 ;	quantum/vial.c:437: g_vial_magic_keycode_override = keycode;
      00B662 90 0C 84         [24] 1594 	mov	dptr,#_vial_keycode_down_keycode_10000_650
      00B665 12 B7 1E         [24] 1595 	lcall	_ak820_outline_0023
                                   1596 ;	quantum/vial.c:439: if (keycode <= QK_MODS_MAX) {
      00B668 40 06            [24] 1597 	jc	00107$
                                   1598 ;	free result
                                   1599 ;	quantum/vial.c:440: register_code16(keycode);
      00B66A 12 45 C9         [24] 1600 	lcall	_ak820_outline_0116
      00B66D 02 A3 57         [24] 1601 	ljmp	_register_code16
      00B670                       1602 00107$:
                                   1603 ;	quantum/vial.c:442: keyevent_t dummy_event = {
      00B670 90 0C 8A         [24] 1604 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_657 + 0x0004)
      00B673 74 01            [12] 1605 	mov	a,#0x01
      00B675 F0               [24] 1606 	movx	@dptr,a
      00B676 90 0C 87         [24] 1607 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_657 + 0x0001)
      00B679 74 F0            [12] 1608 	mov	a,#0xf0
      00B67B F0               [24] 1609 	movx	@dptr,a
      00B67C 90 0C 86         [24] 1610 	mov	dptr,#_vial_keycode_down_dummy_event_30000_657
      00B67F F0               [24] 1611 	movx	@dptr,a
      00B680 90 0C 8B         [24] 1612 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_657 + 0x0005)
      00B683 74 01            [12] 1613 	mov	a,#0x01
      00B685 F0               [24] 1614 	movx	@dptr,a
      00B686 12 4C 5D         [24] 1615 	lcall	_timer_read
      00B689 12 45 D4         [24] 1616 	lcall	_ak820_outline_0132
      00B68C 43 06 01         [24] 1617 	orl	ar6,#0x01
      00B68F 90 0C 88         [24] 1618 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_657 + 0x0002)
      00B692 12 4B BE         [24] 1619 	lcall	_ak820_outline_0059
                                   1620 ;	quantum/vial.c:446: AK820_ACTION_EXEC(dummy_event);
      00B695 90 0C 86         [24] 1621 	mov	dptr,#_vial_keycode_down_dummy_event_30000_657
                                   1622 ;	quantum/vial.c:448: }
      00B698 02 76 E5         [24] 1623 	ljmp	_ak820_action_exec
                                   1624 ;------------------------------------------------------------
                                   1625 ;Allocation info for local variables in function 'vial_keycode_up'
                                   1626 ;------------------------------------------------------------
                                   1627 ;keycode       Allocated with name '_vial_keycode_up_keycode_10000_658'
                                   1628 ;dummy_event   Allocated with name '_vial_keycode_up_dummy_event_30000_665'
                                   1629 ;------------------------------------------------------------
                                   1630 ;	quantum/vial.c:450: void vial_keycode_up(uint16_t keycode) {
                                   1631 ;	-----------------------------------------
                                   1632 ;	 function vial_keycode_up
                                   1633 ;	-----------------------------------------
      00B69B                       1634 _vial_keycode_up:
      00B69B 12 3A 83         [24] 1635 	lcall	_ak820_outline_0103
      00B69E 90 0C 8C         [24] 1636 	mov	dptr,#_vial_keycode_up_keycode_10000_658
      00B6A1 12 3A 88         [24] 1637 	lcall	_ak820_outline_0104
                                   1638 ;	quantum/vial.c:454: if (keycode >= QK_MOD_TAP && keycode <= QK_LAYER_TAP_MAX) {
      00B6A4 90 0C 8C         [24] 1639 	mov	dptr,#_vial_keycode_up_keycode_10000_658
      00B6A7 12 3A 0B         [24] 1640 	lcall	_ak820_outline_0011
      00B6AA 74 E0            [12] 1641 	mov	a,#0x100 - 0x20
      00B6AC 2D               [12] 1642 	add	a,r5
      00B6AD 50 19            [24] 1643 	jnc	00104$
      00B6AF C3               [12] 1644 	clr	c
      00B6B0 74 FF            [12] 1645 	mov	a,#0xff
      00B6B2 9C               [12] 1646 	subb	a,r4
      00B6B3 74 4F            [12] 1647 	mov	a,#0x4f
      00B6B5 9D               [12] 1648 	subb	a,r5
      00B6B6 40 10            [24] 1649 	jc	00104$
                                   1650 ;	free result
                                   1651 ;	quantum/vial.c:455: keycode = (uint8_t)keycode;
      00B6B8 90 0C 8C         [24] 1652 	mov	dptr,#_vial_keycode_up_keycode_10000_658
      00B6BB EE               [12] 1653 	mov	a,r6
      00B6BC 12 3A A5         [24] 1654 	lcall	_ak820_outline_0123
                                   1655 ;	quantum/vial.c:456: if (keycode <= KC_TRANSPARENT) return;
      00B6BF 90 0C 8C         [24] 1656 	mov	dptr,#_vial_keycode_up_keycode_10000_658
      00B6C2 E0               [24] 1657 	movx	a,@dptr
      00B6C3 24 FE            [12] 1658 	add	a,#0xff - 0x01
      00B6C5 40 01            [24] 1659 	jc	00104$
                                   1660 ;	free result
      00B6C7 22               [24] 1661 	ret
      00B6C8                       1662 00104$:
                                   1663 ;	quantum/vial.c:459: g_vial_magic_keycode_override = keycode;
      00B6C8 90 0C 8C         [24] 1664 	mov	dptr,#_vial_keycode_up_keycode_10000_658
      00B6CB 12 B7 1E         [24] 1665 	lcall	_ak820_outline_0023
                                   1666 ;	quantum/vial.c:461: if (keycode <= QK_MODS_MAX) {
      00B6CE 40 06            [24] 1667 	jc	00107$
                                   1668 ;	free result
                                   1669 ;	quantum/vial.c:462: unregister_code16(keycode);
      00B6D0 12 45 C9         [24] 1670 	lcall	_ak820_outline_0116
      00B6D3 02 A3 9B         [24] 1671 	ljmp	_unregister_code16
      00B6D6                       1672 00107$:
                                   1673 ;	quantum/vial.c:464: keyevent_t dummy_event = {
      00B6D6 90 0C 92         [24] 1674 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_665 + 0x0004)
      00B6D9 74 01            [12] 1675 	mov	a,#0x01
      00B6DB F0               [24] 1676 	movx	@dptr,a
      00B6DC 90 0C 8F         [24] 1677 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_665 + 0x0001)
      00B6DF 74 F0            [12] 1678 	mov	a,#0xf0
      00B6E1 F0               [24] 1679 	movx	@dptr,a
      00B6E2 90 0C 8E         [24] 1680 	mov	dptr,#_vial_keycode_up_dummy_event_30000_665
      00B6E5 F0               [24] 1681 	movx	@dptr,a
      00B6E6 90 0C 93         [24] 1682 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_665 + 0x0005)
      00B6E9 E4               [12] 1683 	clr	a
      00B6EA F0               [24] 1684 	movx	@dptr,a
      00B6EB 12 4C 5D         [24] 1685 	lcall	_timer_read
      00B6EE 12 45 D4         [24] 1686 	lcall	_ak820_outline_0132
      00B6F1 43 06 01         [24] 1687 	orl	ar6,#0x01
      00B6F4 90 0C 90         [24] 1688 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_665 + 0x0002)
      00B6F7 12 4B BE         [24] 1689 	lcall	_ak820_outline_0059
                                   1690 ;	quantum/vial.c:468: AK820_ACTION_EXEC(dummy_event);
      00B6FA 90 0C 8E         [24] 1691 	mov	dptr,#_vial_keycode_up_dummy_event_30000_665
                                   1692 ;	quantum/vial.c:470: }
      00B6FD 02 76 E5         [24] 1693 	ljmp	_ak820_action_exec
                                   1694 ;------------------------------------------------------------
                                   1695 ;Allocation info for local variables in function 'vial_keycode_tap'
                                   1696 ;------------------------------------------------------------
                                   1697 ;keycode       Allocated with name '_vial_keycode_tap_keycode_10000_666'
                                   1698 ;i             Allocated with name '_vial_keycode_tap_i_30000_669'
                                   1699 ;------------------------------------------------------------
                                   1700 ;	quantum/vial.c:472: void vial_keycode_tap(uint16_t keycode) {
                                   1701 ;	-----------------------------------------
                                   1702 ;	 function vial_keycode_tap
                                   1703 ;	-----------------------------------------
      00B700                       1704 _vial_keycode_tap:
      00B700 12 3A 83         [24] 1705 	lcall	_ak820_outline_0103
      00B703 90 0C 94         [24] 1706 	mov	dptr,#_vial_keycode_tap_keycode_10000_666
      00B706 12 3A 88         [24] 1707 	lcall	_ak820_outline_0104
                                   1708 ;	quantum/vial.c:473: vial_keycode_down(keycode);
      00B709 90 0C 94         [24] 1709 	mov	dptr,#_vial_keycode_tap_keycode_10000_666
      00B70C 12 39 E0         [24] 1710 	lcall	_ak820_outline_0004
      00B70F C0 07            [24] 1711 	push	ar7
      00B711 C0 06            [24] 1712 	push	ar6
      00B713 D1 35            [12] 1713 	acall	_vial_keycode_down
      00B715 D0 06            [24] 1714 	pop	ar6
      00B717 D0 07            [24] 1715 	pop	ar7
                                   1716 ;	quantum/vial.c:475: vial_keycode_up(keycode);
      00B719 12 45 C9         [24] 1717 	lcall	_ak820_outline_0116
                                   1718 ;	quantum/vial.c:476: }
      00B71C C1 9B            [12] 1719 	ajmp	_vial_keycode_up
                                   1720 ;------------------------------------------------------------
                                   1721 ;Allocation info for local variables in function 'process_record_vial'
                                   1722 ;------------------------------------------------------------
                                   1723 ;record        Allocated with name '_process_record_vial_PARM_2'
                                   1724 ;keycode       Allocated with name '_process_record_vial_keycode_10000_671'
                                   1725 ;------------------------------------------------------------
                                   1726 ;	quantum/vial.c:686: bool process_record_vial(uint16_t keycode, keyrecord_t *record) {
                                   1727 ;	-----------------------------------------
                                   1728 	.area CSEG    (CODE)
                                   1729 	.area CONST   (CODE)
                                   1730 	.area CONST   (CODE)
      00C27E                       1731 _keyboard_definition:
      00C27E FD                    1732 	.db #0xfd	; 253
      00C27F 37                    1733 	.db #0x37	; 55	'7'
      00C280 7A                    1734 	.db #0x7a	; 122	'z'
      00C281 58                    1735 	.db #0x58	; 88	'X'
      00C282 5A                    1736 	.db #0x5a	; 90	'Z'
      00C283 00                    1737 	.db #0x00	; 0
      00C284 00                    1738 	.db #0x00	; 0
      00C285 04                    1739 	.db #0x04	; 4
      00C286 E6                    1740 	.db #0xe6	; 230
      00C287 D6                    1741 	.db #0xd6	; 214
      00C288 B4                    1742 	.db #0xb4	; 180
      00C289 46                    1743 	.db #0x46	; 70	'F'
      00C28A 02                    1744 	.db #0x02	; 2
      00C28B 00                    1745 	.db #0x00	; 0
      00C28C 21                    1746 	.db #0x21	; 33
      00C28D 01                    1747 	.db #0x01	; 1
      00C28E 00                    1748 	.db #0x00	; 0
      00C28F 00                    1749 	.db #0x00	; 0
      00C290 00                    1750 	.db #0x00	; 0
      00C291 00                    1751 	.db #0x00	; 0
      00C292 37                    1752 	.db #0x37	; 55	'7'
      00C293 27                    1753 	.db #0x27	; 39
      00C294 97                    1754 	.db #0x97	; 151
      00C295 D6                    1755 	.db #0xd6	; 214
      00C296 E0                    1756 	.db #0xe0	; 224
      00C297 03                    1757 	.db #0x03	; 3
      00C298 CB                    1758 	.db #0xcb	; 203
      00C299 01                    1759 	.db #0x01	; 1
      00C29A 3C                    1760 	.db #0x3c	; 60
      00C29B 00                    1761 	.db #0x00	; 0
      00C29C 00                    1762 	.db #0x00	; 0
      00C29D 3D                    1763 	.db #0x3d	; 61
      00C29E 88                    1764 	.db #0x88	; 136
      00C29F CD                    1765 	.db #0xcd	; 205
      00C2A0 A5                    1766 	.db #0xa5	; 165
      00C2A1 AA                    1767 	.db #0xaa	; 170
      00C2A2 E5                    1768 	.db #0xe5	; 229
      00C2A3 A8                    1769 	.db #0xa8	; 168
      00C2A4 76                    1770 	.db #0x76	; 118	'v'
      00C2A5 F6                    1771 	.db #0xf6	; 246
      00C2A6 43                    1772 	.db #0x43	; 67	'C'
      00C2A7 0E                    1773 	.db #0x0e	; 14
      00C2A8 D2                    1774 	.db #0xd2	; 210
      00C2A9 90                    1775 	.db #0x90	; 144
      00C2AA 7D                    1776 	.db #0x7d	; 125
      00C2AB 94                    1777 	.db #0x94	; 148
      00C2AC 79                    1778 	.db #0x79	; 121	'y'
      00C2AD 78                    1779 	.db #0x78	; 120	'x'
      00C2AE EF                    1780 	.db #0xef	; 239
      00C2AF 49                    1781 	.db #0x49	; 73	'I'
      00C2B0 3E                    1782 	.db #0x3e	; 62
      00C2B1 EF                    1783 	.db #0xef	; 239
      00C2B2 FD                    1784 	.db #0xfd	; 253
      00C2B3 8F                    1785 	.db #0x8f	; 143
      00C2B4 EF                    1786 	.db #0xef	; 239
      00C2B5 00                    1787 	.db #0x00	; 0
      00C2B6 C6                    1788 	.db #0xc6	; 198
      00C2B7 D1                    1789 	.db #0xd1	; 209
      00C2B8 DB                    1790 	.db #0xdb	; 219
      00C2B9 FB                    1791 	.db #0xfb	; 251
      00C2BA EB                    1792 	.db #0xeb	; 235
      00C2BB DE                    1793 	.db #0xde	; 222
      00C2BC 66                    1794 	.db #0x66	; 102	'f'
      00C2BD 63                    1795 	.db #0x63	; 99	'c'
      00C2BE 0C                    1796 	.db #0x0c	; 12
      00C2BF 92                    1797 	.db #0x92	; 146
      00C2C0 7B                    1798 	.db #0x7b	; 123
      00C2C1 F9                    1799 	.db #0xf9	; 249
      00C2C2 D4                    1800 	.db #0xd4	; 212
      00C2C3 7A                    1801 	.db #0x7a	; 122	'z'
      00C2C4 4F                    1802 	.db #0x4f	; 79	'O'
      00C2C5 83                    1803 	.db #0x83	; 131
      00C2C6 4B                    1804 	.db #0x4b	; 75	'K'
      00C2C7 86                    1805 	.db #0x86	; 134
      00C2C8 0E                    1806 	.db #0x0e	; 14
      00C2C9 6A                    1807 	.db #0x6a	; 106	'j'
      00C2CA F2                    1808 	.db #0xf2	; 242
      00C2CB 22                    1809 	.db #0x22	; 34
      00C2CC 22                    1810 	.db #0x22	; 34
      00C2CD 0B                    1811 	.db #0x0b	; 11
      00C2CE 03                    1812 	.db #0x03	; 3
      00C2CF BA                    1813 	.db #0xba	; 186
      00C2D0 67                    1814 	.db #0x67	; 103	'g'
      00C2D1 9B                    1815 	.db #0x9b	; 155
      00C2D2 7A                    1816 	.db #0x7a	; 122	'z'
      00C2D3 E1                    1817 	.db #0xe1	; 225
      00C2D4 BC                    1818 	.db #0xbc	; 188
      00C2D5 37                    1819 	.db #0x37	; 55	'7'
      00C2D6 26                    1820 	.db #0x26	; 38
      00C2D7 46                    1821 	.db #0x46	; 70	'F'
      00C2D8 78                    1822 	.db #0x78	; 120	'x'
      00C2D9 05                    1823 	.db #0x05	; 5
      00C2DA 0D                    1824 	.db #0x0d	; 13
      00C2DB 95                    1825 	.db #0x95	; 149
      00C2DC 02                    1826 	.db #0x02	; 2
      00C2DD E4                    1827 	.db #0xe4	; 228
      00C2DE 18                    1828 	.db #0x18	; 24
      00C2DF CA                    1829 	.db #0xca	; 202
      00C2E0 33                    1830 	.db #0x33	; 51	'3'
      00C2E1 EA                    1831 	.db #0xea	; 234
      00C2E2 24                    1832 	.db #0x24	; 36
      00C2E3 C8                    1833 	.db #0xc8	; 200
      00C2E4 81                    1834 	.db #0x81	; 129
      00C2E5 4E                    1835 	.db #0x4e	; 78	'N'
      00C2E6 47                    1836 	.db #0x47	; 71	'G'
      00C2E7 A8                    1837 	.db #0xa8	; 168
      00C2E8 44                    1838 	.db #0x44	; 68	'D'
      00C2E9 DD                    1839 	.db #0xdd	; 221
      00C2EA 91                    1840 	.db #0x91	; 145
      00C2EB 6D                    1841 	.db #0x6d	; 109	'm'
      00C2EC 69                    1842 	.db #0x69	; 105	'i'
      00C2ED DB                    1843 	.db #0xdb	; 219
      00C2EE 4F                    1844 	.db #0x4f	; 79	'O'
      00C2EF 3A                    1845 	.db #0x3a	; 58
      00C2F0 43                    1846 	.db #0x43	; 67	'C'
      00C2F1 9D                    1847 	.db #0x9d	; 157
      00C2F2 26                    1848 	.db #0x26	; 38
      00C2F3 49                    1849 	.db #0x49	; 73	'I'
      00C2F4 4C                    1850 	.db #0x4c	; 76	'L'
      00C2F5 EF                    1851 	.db #0xef	; 239
      00C2F6 2B                    1852 	.db #0x2b	; 43
      00C2F7 D8                    1853 	.db #0xd8	; 216
      00C2F8 55                    1854 	.db #0x55	; 85	'U'
      00C2F9 95                    1855 	.db #0x95	; 149
      00C2FA 70                    1856 	.db #0x70	; 112	'p'
      00C2FB B1                    1857 	.db #0xb1	; 177
      00C2FC CC                    1858 	.db #0xcc	; 204
      00C2FD CF                    1859 	.db #0xcf	; 207
      00C2FE 13                    1860 	.db #0x13	; 19
      00C2FF 32                    1861 	.db #0x32	; 50	'2'
      00C300 6A                    1862 	.db #0x6a	; 106	'j'
      00C301 A1                    1863 	.db #0xa1	; 161
      00C302 FF                    1864 	.db #0xff	; 255
      00C303 99                    1865 	.db #0x99	; 153
      00C304 61                    1866 	.db #0x61	; 97	'a'
      00C305 95                    1867 	.db #0x95	; 149
      00C306 B1                    1868 	.db #0xb1	; 177
      00C307 89                    1869 	.db #0x89	; 137
      00C308 9B                    1870 	.db #0x9b	; 155
      00C309 11                    1871 	.db #0x11	; 17
      00C30A D9                    1872 	.db #0xd9	; 217
      00C30B 35                    1873 	.db #0x35	; 53	'5'
      00C30C 78                    1874 	.db #0x78	; 120	'x'
      00C30D ED                    1875 	.db #0xed	; 237
      00C30E CD                    1876 	.db #0xcd	; 205
      00C30F 94                    1877 	.db #0x94	; 148
      00C310 6E                    1878 	.db #0x6e	; 110	'n'
      00C311 60                    1879 	.db #0x60	; 96
      00C312 8E                    1880 	.db #0x8e	; 142
      00C313 63                    1881 	.db #0x63	; 99	'c'
      00C314 8B                    1882 	.db #0x8b	; 139
      00C315 FF                    1883 	.db #0xff	; 255
      00C316 4E                    1884 	.db #0x4e	; 78	'N'
      00C317 20                    1885 	.db #0x20	; 32
      00C318 7A                    1886 	.db #0x7a	; 122	'z'
      00C319 B5                    1887 	.db #0xb5	; 181
      00C31A 87                    1888 	.db #0x87	; 135
      00C31B C2                    1889 	.db #0xc2	; 194
      00C31C 35                    1890 	.db #0x35	; 53	'5'
      00C31D A4                    1891 	.db #0xa4	; 164
      00C31E 6D                    1892 	.db #0x6d	; 109	'm'
      00C31F 18                    1893 	.db #0x18	; 24
      00C320 C1                    1894 	.db #0xc1	; 193
      00C321 A3                    1895 	.db #0xa3	; 163
      00C322 DB                    1896 	.db #0xdb	; 219
      00C323 53                    1897 	.db #0x53	; 83	'S'
      00C324 1D                    1898 	.db #0x1d	; 29
      00C325 EC                    1899 	.db #0xec	; 236
      00C326 F0                    1900 	.db #0xf0	; 240
      00C327 BF                    1901 	.db #0xbf	; 191
      00C328 4A                    1902 	.db #0x4a	; 74	'J'
      00C329 4C                    1903 	.db #0x4c	; 76	'L'
      00C32A 4A                    1904 	.db #0x4a	; 74	'J'
      00C32B C4                    1905 	.db #0xc4	; 196
      00C32C AA                    1906 	.db #0xaa	; 170
      00C32D 37                    1907 	.db #0x37	; 55	'7'
      00C32E 19                    1908 	.db #0x19	; 25
      00C32F 34                    1909 	.db #0x34	; 52	'4'
      00C330 3F                    1910 	.db #0x3f	; 63
      00C331 A1                    1911 	.db #0xa1	; 161
      00C332 D3                    1912 	.db #0xd3	; 211
      00C333 1A                    1913 	.db #0x1a	; 26
      00C334 5C                    1914 	.db #0x5c	; 92
      00C335 03                    1915 	.db #0x03	; 3
      00C336 4D                    1916 	.db #0x4d	; 77	'M'
      00C337 BC                    1917 	.db #0xbc	; 188
      00C338 10                    1918 	.db #0x10	; 16
      00C339 2E                    1919 	.db #0x2e	; 46
      00C33A 80                    1920 	.db #0x80	; 128
      00C33B F7                    1921 	.db #0xf7	; 247
      00C33C D6                    1922 	.db #0xd6	; 214
      00C33D 82                    1923 	.db #0x82	; 130
      00C33E 24                    1924 	.db #0x24	; 36
      00C33F 4C                    1925 	.db #0x4c	; 76	'L'
      00C340 87                    1926 	.db #0x87	; 135
      00C341 B9                    1927 	.db #0xb9	; 185
      00C342 F8                    1928 	.db #0xf8	; 248
      00C343 BE                    1929 	.db #0xbe	; 190
      00C344 67                    1930 	.db #0x67	; 103	'g'
      00C345 96                    1931 	.db #0x96	; 150
      00C346 89                    1932 	.db #0x89	; 137
      00C347 30                    1933 	.db #0x30	; 48	'0'
      00C348 C8                    1934 	.db #0xc8	; 200
      00C349 8D                    1935 	.db #0x8d	; 141
      00C34A 2C                    1936 	.db #0x2c	; 44
      00C34B F5                    1937 	.db #0xf5	; 245
      00C34C 06                    1938 	.db #0x06	; 6
      00C34D 05                    1939 	.db #0x05	; 5
      00C34E 7C                    1940 	.db #0x7c	; 124
      00C34F 48                    1941 	.db #0x48	; 72	'H'
      00C350 1B                    1942 	.db #0x1b	; 27
      00C351 76                    1943 	.db #0x76	; 118	'v'
      00C352 AA                    1944 	.db #0xaa	; 170
      00C353 3D                    1945 	.db #0x3d	; 61
      00C354 28                    1946 	.db #0x28	; 40
      00C355 FC                    1947 	.db #0xfc	; 252
      00C356 80                    1948 	.db #0x80	; 128
      00C357 75                    1949 	.db #0x75	; 117	'u'
      00C358 EB                    1950 	.db #0xeb	; 235
      00C359 78                    1951 	.db #0x78	; 120	'x'
      00C35A D0                    1952 	.db #0xd0	; 208
      00C35B 8A                    1953 	.db #0x8a	; 138
      00C35C 8F                    1954 	.db #0x8f	; 143
      00C35D 27                    1955 	.db #0x27	; 39
      00C35E F7                    1956 	.db #0xf7	; 247
      00C35F F2                    1957 	.db #0xf2	; 242
      00C360 EB                    1958 	.db #0xeb	; 235
      00C361 58                    1959 	.db #0x58	; 88	'X'
      00C362 37                    1960 	.db #0x37	; 55	'7'
      00C363 3C                    1961 	.db #0x3c	; 60
      00C364 2B                    1962 	.db #0x2b	; 43
      00C365 6F                    1963 	.db #0x6f	; 111	'o'
      00C366 0E                    1964 	.db #0x0e	; 14
      00C367 C7                    1965 	.db #0xc7	; 199
      00C368 E2                    1966 	.db #0xe2	; 226
      00C369 A0                    1967 	.db #0xa0	; 160
      00C36A 97                    1968 	.db #0x97	; 151
      00C36B EE                    1969 	.db #0xee	; 238
      00C36C FD                    1970 	.db #0xfd	; 253
      00C36D 9F                    1971 	.db #0x9f	; 159
      00C36E 45                    1972 	.db #0x45	; 69	'E'
      00C36F 17                    1973 	.db #0x17	; 23
      00C370 94                    1974 	.db #0x94	; 148
      00C371 E6                    1975 	.db #0xe6	; 230
      00C372 E7                    1976 	.db #0xe7	; 231
      00C373 FA                    1977 	.db #0xfa	; 250
      00C374 4C                    1978 	.db #0x4c	; 76	'L'
      00C375 7A                    1979 	.db #0x7a	; 122	'z'
      00C376 D6                    1980 	.db #0xd6	; 214
      00C377 7A                    1981 	.db #0x7a	; 122	'z'
      00C378 7B                    1982 	.db #0x7b	; 123
      00C379 ED                    1983 	.db #0xed	; 237
      00C37A 10                    1984 	.db #0x10	; 16
      00C37B C5                    1985 	.db #0xc5	; 197
      00C37C BC                    1986 	.db #0xbc	; 188
      00C37D E3                    1987 	.db #0xe3	; 227
      00C37E A9                    1988 	.db #0xa9	; 169
      00C37F 1F                    1989 	.db #0x1f	; 31
      00C380 CF                    1990 	.db #0xcf	; 207
      00C381 C4                    1991 	.db #0xc4	; 196
      00C382 9D                    1992 	.db #0x9d	; 157
      00C383 DC                    1993 	.db #0xdc	; 220
      00C384 45                    1994 	.db #0x45	; 69	'E'
      00C385 2A                    1995 	.db #0x2a	; 42
      00C386 69                    1996 	.db #0x69	; 105	'i'
      00C387 57                    1997 	.db #0x57	; 87	'W'
      00C388 8F                    1998 	.db #0x8f	; 143
      00C389 EC                    1999 	.db #0xec	; 236
      00C38A 85                    2000 	.db #0x85	; 133
      00C38B 6C                    2001 	.db #0x6c	; 108	'l'
      00C38C 43                    2002 	.db #0x43	; 67	'C'
      00C38D 1C                    2003 	.db #0x1c	; 28
      00C38E BA                    2004 	.db #0xba	; 186
      00C38F 89                    2005 	.db #0x89	; 137
      00C390 68                    2006 	.db #0x68	; 104	'h'
      00C391 4A                    2007 	.db #0x4a	; 74	'J'
      00C392 1C                    2008 	.db #0x1c	; 28
      00C393 91                    2009 	.db #0x91	; 145
      00C394 3F                    2010 	.db #0x3f	; 63
      00C395 D1                    2011 	.db #0xd1	; 209
      00C396 B3                    2012 	.db #0xb3	; 179
      00C397 96                    2013 	.db #0x96	; 150
      00C398 1D                    2014 	.db #0x1d	; 29
      00C399 7C                    2015 	.db #0x7c	; 124
      00C39A 14                    2016 	.db #0x14	; 20
      00C39B 77                    2017 	.db #0x77	; 119	'w'
      00C39C 9C                    2018 	.db #0x9c	; 156
      00C39D 74                    2019 	.db #0x74	; 116	't'
      00C39E 36                    2020 	.db #0x36	; 54	'6'
      00C39F FF                    2021 	.db #0xff	; 255
      00C3A0 2C                    2022 	.db #0x2c	; 44
      00C3A1 66                    2023 	.db #0x66	; 102	'f'
      00C3A2 AF                    2024 	.db #0xaf	; 175
      00C3A3 0F                    2025 	.db #0x0f	; 15
      00C3A4 3C                    2026 	.db #0x3c	; 60
      00C3A5 A2                    2027 	.db #0xa2	; 162
      00C3A6 23                    2028 	.db #0x23	; 35
      00C3A7 85                    2029 	.db #0x85	; 133
      00C3A8 05                    2030 	.db #0x05	; 5
      00C3A9 87                    2031 	.db #0x87	; 135
      00C3AA DA                    2032 	.db #0xda	; 218
      00C3AB 61                    2033 	.db #0x61	; 97	'a'
      00C3AC 5E                    2034 	.db #0x5e	; 94
      00C3AD 42                    2035 	.db #0x42	; 66	'B'
      00C3AE 54                    2036 	.db #0x54	; 84	'T'
      00C3AF 60                    2037 	.db #0x60	; 96
      00C3B0 23                    2038 	.db #0x23	; 35
      00C3B1 CA                    2039 	.db #0xca	; 202
      00C3B2 BC                    2040 	.db #0xbc	; 188
      00C3B3 B3                    2041 	.db #0xb3	; 179
      00C3B4 18                    2042 	.db #0x18	; 24
      00C3B5 1D                    2043 	.db #0x1d	; 29
      00C3B6 F8                    2044 	.db #0xf8	; 248
      00C3B7 0A                    2045 	.db #0x0a	; 10
      00C3B8 55                    2046 	.db #0x55	; 85	'U'
      00C3B9 CD                    2047 	.db #0xcd	; 205
      00C3BA A3                    2048 	.db #0xa3	; 163
      00C3BB DE                    2049 	.db #0xde	; 222
      00C3BC FF                    2050 	.db #0xff	; 255
      00C3BD B2                    2051 	.db #0xb2	; 178
      00C3BE 2A                    2052 	.db #0x2a	; 42
      00C3BF 35                    2053 	.db #0x35	; 53	'5'
      00C3C0 00                    2054 	.db #0x00	; 0
      00C3C1 D6                    2055 	.db #0xd6	; 214
      00C3C2 7B                    2056 	.db #0x7b	; 123
      00C3C3 E8                    2057 	.db #0xe8	; 232
      00C3C4 F2                    2058 	.db #0xf2	; 242
      00C3C5 1A                    2059 	.db #0x1a	; 26
      00C3C6 BC                    2060 	.db #0xbc	; 188
      00C3C7 F5                    2061 	.db #0xf5	; 245
      00C3C8 7E                    2062 	.db #0x7e	; 126
      00C3C9 48                    2063 	.db #0x48	; 72	'H'
      00C3CA 72                    2064 	.db #0x72	; 114	'r'
      00C3CB E0                    2065 	.db #0xe0	; 224
      00C3CC E4                    2066 	.db #0xe4	; 228
      00C3CD E0                    2067 	.db #0xe0	; 224
      00C3CE 27                    2068 	.db #0x27	; 39
      00C3CF 87                    2069 	.db #0x87	; 135
      00C3D0 9A                    2070 	.db #0x9a	; 154
      00C3D1 51                    2071 	.db #0x51	; 81	'Q'
      00C3D2 D4                    2072 	.db #0xd4	; 212
      00C3D3 DD                    2073 	.db #0xdd	; 221
      00C3D4 C3                    2074 	.db #0xc3	; 195
      00C3D5 AA                    2075 	.db #0xaa	; 170
      00C3D6 49                    2076 	.db #0x49	; 73	'I'
      00C3D7 5A                    2077 	.db #0x5a	; 90	'Z'
      00C3D8 2A                    2078 	.db #0x2a	; 42
      00C3D9 00                    2079 	.db #0x00	; 0
      00C3DA A0                    2080 	.db #0xa0	; 160
      00C3DB 8C                    2081 	.db #0x8c	; 140
      00C3DC FF                    2082 	.db #0xff	; 255
      00C3DD 74                    2083 	.db #0x74	; 116	't'
      00C3DE BF                    2084 	.db #0xbf	; 191
      00C3DF EC                    2085 	.db #0xec	; 236
      00C3E0 1D                    2086 	.db #0x1d	; 29
      00C3E1 F1                    2087 	.db #0xf1	; 241
      00C3E2 00                    2088 	.db #0x00	; 0
      00C3E3 01                    2089 	.db #0x01	; 1
      00C3E4 D8                    2090 	.db #0xd8	; 216
      00C3E5 02                    2091 	.db #0x02	; 2
      00C3E6 CC                    2092 	.db #0xcc	; 204
      00C3E7 07                    2093 	.db #0x07	; 7
      00C3E8 00                    2094 	.db #0x00	; 0
      00C3E9 00                    2095 	.db #0x00	; 0
      00C3EA C4                    2096 	.db #0xc4	; 196
      00C3EB 5E                    2097 	.db #0x5e	; 94
      00C3EC 2C                    2098 	.db #0x2c	; 44
      00C3ED 7E                    2099 	.db #0x7e	; 126
      00C3EE B1                    2100 	.db #0xb1	; 177
      00C3EF C4                    2101 	.db #0xc4	; 196
      00C3F0 67                    2102 	.db #0x67	; 103	'g'
      00C3F1 FB                    2103 	.db #0xfb	; 251
      00C3F2 02                    2104 	.db #0x02	; 2
      00C3F3 00                    2105 	.db #0x00	; 0
      00C3F4 00                    2106 	.db #0x00	; 0
      00C3F5 00                    2107 	.db #0x00	; 0
      00C3F6 00                    2108 	.db #0x00	; 0
      00C3F7 04                    2109 	.db #0x04	; 4
      00C3F8 59                    2110 	.db #0x59	; 89	'Y'
      00C3F9 5A                    2111 	.db #0x5a	; 90	'Z'
                                   2112 	.area CSEG    (CODE)
                                   2113 	.area CONST   (CODE)
      00C3FA                       2114 _vial_handle_cmd_keyboard_uid_40000_624:
      00C3FA 04                    2115 	.db #0x04	; 4
      00C3FB 70                    2116 	.db #0x70	; 112	'p'
      00C3FC FF                    2117 	.db #0xff	; 255
      00C3FD 90                    2118 	.db #0x90	; 144
      00C3FE 01                    2119 	.db #0x01	; 1
      00C3FF B9                    2120 	.db #0xb9	; 185
      00C400 15                    2121 	.db #0x15	; 21
      00C401 D3                    2122 	.db #0xd3	; 211
                                   2123 	.area CSEG    (CODE)
                                   2124 	.area XINIT   (CODE)
      00C67A                       2125 __xinit__vial_unlocked:
      00C67A 00                    2126 	.db #0x00	;  0
      00C67B                       2127 __xinit__vial_unlock_in_progress:
      00C67B 00                    2128 	.db #0x00	;  0
      00C67C                       2129 __xinit__vial_unlock_counter:
      00C67C 00                    2130 	.db #0x00	; 0
      00C67D                       2131 __xinit__vial_unlock_combo_rows:
      00C67D 00                    2132 	.db #0x00	; 0
      00C67E 00                    2133 	.db #0x00	; 0
      00C67F                       2134 __xinit__vial_unlock_combo_cols:
      00C67F 00                    2135 	.db #0x00	; 0
      00C680 05                    2136 	.db #0x05	; 5
                                   2137 	.area CABS    (ABS,CODE)
                                   2138 
                                   2139 ; Experimental exact instruction outlining.
                                   2140 	.globl _ak820_outline_0004
                                   2141 	.globl _ak820_outline_0007
                                   2142 	.globl _ak820_outline_0010
                                   2143 	.globl _ak820_outline_0011
                                   2144 	.globl _ak820_outline_0012
                                   2145 	.globl _ak820_outline_0015
                                   2146 	.globl _ak820_outline_0016
                                   2147 	.globl _ak820_outline_0017
                                   2148 	.globl _ak820_outline_0020
                                   2149 	.globl _ak820_outline_0023
                                   2150 	.globl _ak820_outline_0030
                                   2151 	.globl _ak820_outline_0031
                                   2152 	.globl _ak820_outline_0034
                                   2153 	.globl _ak820_outline_0037
                                   2154 	.globl _ak820_outline_0046
                                   2155 	.globl _ak820_outline_0051
                                   2156 	.globl _ak820_outline_0054
                                   2157 	.globl _ak820_outline_0056
                                   2158 	.globl _ak820_outline_0059
                                   2159 	.globl _ak820_outline_0061
                                   2160 	.globl _ak820_outline_0073
                                   2161 	.globl _ak820_outline_0076
                                   2162 	.globl _ak820_outline_0096
                                   2163 	.globl _ak820_outline_0103
                                   2164 	.globl _ak820_outline_0104
                                   2165 	.globl _ak820_outline_0116
                                   2166 	.globl _ak820_outline_0117
                                   2167 	.globl _ak820_outline_0120
                                   2168 	.globl _ak820_outline_0121
                                   2169 	.globl _ak820_outline_0122
                                   2170 	.globl _ak820_outline_0123
                                   2171 	.globl _ak820_outline_0125
                                   2172 	.globl _ak820_outline_0126
                                   2173 	.globl _ak820_outline_0132
                                   2174 	.globl _ak820_outline_0136
                                   2175 	.globl _ak820_outline_0142
                                   2176 	.globl _ak820_outline_0155
                                   2177 	.globl _ak820_outline_0178
                                   2178 
                                   2179 	.area CSEG (CODE)
                                   2180 ; function ak820_outline_0023
      00B71E                       2181 _ak820_outline_0023:
      00B71E E0               [24] 2182 	movx	a,@dptr
      00B71F FE               [12] 2183 	mov	r6,a
      00B720 A3               [24] 2184 	inc	dptr
      00B721 E0               [24] 2185 	movx	a,@dptr
      00B722 FF               [12] 2186 	mov	r7,a
      00B723 90 0C 82         [24] 2187 	mov	dptr,#_g_vial_magic_keycode_override
      00B726 EE               [12] 2188 	mov	a,r6
      00B727 F0               [24] 2189 	movx	@dptr,a
      00B728 EF               [12] 2190 	mov	a,r7
      00B729 A3               [24] 2191 	inc	dptr
      00B72A F0               [24] 2192 	movx	@dptr,a
      00B72B 8E 04            [24] 2193 	mov	ar4,r6
      00B72D 8F 05            [24] 2194 	mov	ar5,r7
      00B72F C3               [12] 2195 	clr	c
      00B730 74 FF            [12] 2196 	mov	a,#0xff
      00B732 9C               [12] 2197 	subb	a,r4
      00B733 74 1F            [12] 2198 	mov	a,#0x1f
      00B735 9D               [12] 2199 	subb	a,r5
      00B736 22               [24] 2200 	ret
                                   2201 
                                   2202 	.area CSEG (CODE)
                                   2203 ; function ak820_outline_0073
      00B737                       2204 _ak820_outline_0073:
      00B737 A3               [24] 2205 	inc	dptr
      00B738 F0               [24] 2206 	movx	@dptr,a
      00B739 E4               [12] 2207 	clr	a
      00B73A A3               [24] 2208 	inc	dptr
      00B73B F0               [24] 2209 	movx	@dptr,a
      00B73C 90 0D AD         [24] 2210 	mov	dptr,#___memcpy_PARM_3
      00B73F 74 0A            [12] 2211 	mov	a,#0x0a
      00B741 F0               [24] 2212 	movx	@dptr,a
      00B742 E4               [12] 2213 	clr	a
      00B743 A3               [24] 2214 	inc	dptr
      00B744 F0               [24] 2215 	movx	@dptr,a
      00B745 22               [24] 2216 	ret
                                   2217 
                                   2218 	.area CSEG (CODE)
                                   2219 ; function ak820_outline_0125
      00B746                       2220 _ak820_outline_0125:
      00B746 24 30            [12] 2221 	add	a,#_vial_unlock_combo_cols
      00B748 F5 82            [12] 2222 	mov	dpl,a
      00B74A E4               [12] 2223 	clr	a
      00B74B 34 0E            [12] 2224 	addc	a,#(_vial_unlock_combo_cols>>8)
      00B74D F5 83            [12] 2225 	mov	dph,a
      00B74F E0               [24] 2226 	movx	a,@dptr
      00B750 22               [24] 2227 	ret
                                   2228 
                                   2229 	.area CSEG (CODE)
                                   2230 ; function ak820_outline_0126
      00B751                       2231 _ak820_outline_0126:
      00B751 24 2E            [12] 2232 	add	a,#_vial_unlock_combo_rows
      00B753 F5 82            [12] 2233 	mov	dpl,a
      00B755 E4               [12] 2234 	clr	a
      00B756 34 0E            [12] 2235 	addc	a,#(_vial_unlock_combo_rows>>8)
      00B758 F5 83            [12] 2236 	mov	dph,a
      00B75A E0               [24] 2237 	movx	a,@dptr
      00B75B 22               [24] 2238 	ret
