                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module vialrgb
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _rgb_matrix_get_speed
                                     12 	.globl _rgb_matrix_set_speed_noeeprom
                                     13 	.globl _rgb_matrix_get_val
                                     14 	.globl _rgb_matrix_get_sat
                                     15 	.globl _rgb_matrix_get_hue
                                     16 	.globl _rgb_matrix_sethsv_noeeprom
                                     17 	.globl _rgb_matrix_get_mode
                                     18 	.globl _rgb_matrix_mode_noeeprom
                                     19 	.globl _rgb_matrix_is_enabled
                                     20 	.globl _rgb_matrix_disable_noeeprom
                                     21 	.globl _rgb_matrix_enable_noeeprom
                                     22 	.globl _eeconfig_update_rgb_matrix
                                     23 	.globl _ADC_START
                                     24 	.globl _S0_R_FIFO
                                     25 	.globl _S0_T_FIFO
                                     26 	.globl _S0_FREE
                                     27 	.globl _S0_IF_BYTE
                                     28 	.globl _S0_IF_FIRST
                                     29 	.globl _S0_IF_OV
                                     30 	.globl _S0_FST_ACT
                                     31 	.globl _CP_RL2
                                     32 	.globl _C_T2
                                     33 	.globl _TR2
                                     34 	.globl _EXEN2
                                     35 	.globl _TCLK
                                     36 	.globl _RCLK
                                     37 	.globl _EXF2
                                     38 	.globl _CAP1F
                                     39 	.globl _TF2
                                     40 	.globl _RI
                                     41 	.globl _TI
                                     42 	.globl _RB8
                                     43 	.globl _TB8
                                     44 	.globl _REN
                                     45 	.globl _SM2
                                     46 	.globl _SM1
                                     47 	.globl _SM0
                                     48 	.globl _IT0
                                     49 	.globl _IE0
                                     50 	.globl _IT1
                                     51 	.globl _IE1
                                     52 	.globl _TR0
                                     53 	.globl _TF0
                                     54 	.globl _TR1
                                     55 	.globl _TF1
                                     56 	.globl _P4_0
                                     57 	.globl _P4_1
                                     58 	.globl _P4_2
                                     59 	.globl _P4_3
                                     60 	.globl _P4_4
                                     61 	.globl _P4_5
                                     62 	.globl _P4_6
                                     63 	.globl _RXD
                                     64 	.globl _TXD
                                     65 	.globl _INT0
                                     66 	.globl _INT1
                                     67 	.globl _T0
                                     68 	.globl _T1
                                     69 	.globl _MOSI1
                                     70 	.globl _MISO1
                                     71 	.globl _SCK1
                                     72 	.globl _P3_0
                                     73 	.globl _P3_1
                                     74 	.globl _P3_2
                                     75 	.globl _P3_3
                                     76 	.globl _P3_4
                                     77 	.globl _P3_5
                                     78 	.globl _P3_6
                                     79 	.globl _P3_7
                                     80 	.globl _CAP1_
                                     81 	.globl _T2_
                                     82 	.globl _CAP2_
                                     83 	.globl _T2EX_
                                     84 	.globl _RXD1
                                     85 	.globl _TXD1
                                     86 	.globl _P2_0
                                     87 	.globl _P2_1
                                     88 	.globl _P2_2
                                     89 	.globl _P2_3
                                     90 	.globl _P2_4
                                     91 	.globl _P2_5
                                     92 	.globl _P2_6
                                     93 	.globl _P2_7
                                     94 	.globl _AIN0
                                     95 	.globl _AIN1
                                     96 	.globl _AIN2
                                     97 	.globl _AIN3
                                     98 	.globl _AIN4
                                     99 	.globl _AIN5
                                    100 	.globl _AIN6
                                    101 	.globl _AIN7
                                    102 	.globl _CAP1
                                    103 	.globl _T2
                                    104 	.globl _CAP2
                                    105 	.globl _T2EX
                                    106 	.globl _INT0_
                                    107 	.globl _SCS
                                    108 	.globl _MOSI
                                    109 	.globl _MISO
                                    110 	.globl _SCK
                                    111 	.globl _RXD1_
                                    112 	.globl _TXD1_
                                    113 	.globl _P1_0
                                    114 	.globl _P1_1
                                    115 	.globl _P1_2
                                    116 	.globl _P1_3
                                    117 	.globl _P1_4
                                    118 	.globl _P1_5
                                    119 	.globl _P1_6
                                    120 	.globl _P1_7
                                    121 	.globl _AIN8
                                    122 	.globl _AIN9
                                    123 	.globl _AIN10
                                    124 	.globl _AIN11
                                    125 	.globl _AIN12
                                    126 	.globl _AIN13
                                    127 	.globl _RXD_
                                    128 	.globl _TXD_
                                    129 	.globl _SCL0
                                    130 	.globl _SDA0
                                    131 	.globl _P0_0
                                    132 	.globl _P0_1
                                    133 	.globl _P0_2
                                    134 	.globl _P0_3
                                    135 	.globl _P0_4
                                    136 	.globl _P0_5
                                    137 	.globl _P0_6
                                    138 	.globl _P0_7
                                    139 	.globl _IE_SPI0
                                    140 	.globl _IE_USB
                                    141 	.globl _IE_ADC
                                    142 	.globl _IE_UART1
                                    143 	.globl _IE_PWM_I2C
                                    144 	.globl _IE_GPIO
                                    145 	.globl _IE_WDOG
                                    146 	.globl _PX0
                                    147 	.globl _PT0
                                    148 	.globl _PX1
                                    149 	.globl _PT1
                                    150 	.globl _PS
                                    151 	.globl _PT2
                                    152 	.globl _PL_FLAG
                                    153 	.globl _PH_FLAG
                                    154 	.globl _EX0
                                    155 	.globl _ET0
                                    156 	.globl _EX1
                                    157 	.globl _ET1
                                    158 	.globl _ES
                                    159 	.globl _ET2
                                    160 	.globl _E_DIS
                                    161 	.globl _EA
                                    162 	.globl _P
                                    163 	.globl _F1
                                    164 	.globl _OV
                                    165 	.globl _RS0
                                    166 	.globl _RS1
                                    167 	.globl _F0
                                    168 	.globl _AC
                                    169 	.globl _CY
                                    170 	.globl _I2CS_INT_ST
                                    171 	.globl _I2CX_INT
                                    172 	.globl _LED_STATUS
                                    173 	.globl _LED_DMA_H
                                    174 	.globl _LED_DMA_L
                                    175 	.globl _LED_DMA
                                    176 	.globl _LED_PWM_OE
                                    177 	.globl _LED_COMMON
                                    178 	.globl _ADC_CHAN
                                    179 	.globl _ADC_DAT_H
                                    180 	.globl _ADC_DAT_L
                                    181 	.globl _ADC_DAT
                                    182 	.globl _ADC_CTRL
                                    183 	.globl _SPI1_CK_SE
                                    184 	.globl _SPI1_CTRL
                                    185 	.globl _SPI1_DATA
                                    186 	.globl _SPI1_STAT
                                    187 	.globl _SIF1
                                    188 	.globl _SBAUD1
                                    189 	.globl _SBUF1
                                    190 	.globl _SCON1
                                    191 	.globl _SPI0_SETUP
                                    192 	.globl _SPI0_CK_SE
                                    193 	.globl _SPI0_CTRL
                                    194 	.globl _SPI0_DATA
                                    195 	.globl _SPI0_STAT
                                    196 	.globl _T2CAP1H
                                    197 	.globl _T2CAP1L
                                    198 	.globl _T2CAP1
                                    199 	.globl _TH2
                                    200 	.globl _TL2
                                    201 	.globl _T2COUNT
                                    202 	.globl _RCAP2H
                                    203 	.globl _RCAP2L
                                    204 	.globl _RCAP2
                                    205 	.globl _T2MOD
                                    206 	.globl _T2CON
                                    207 	.globl _SBUF
                                    208 	.globl _SCON
                                    209 	.globl _TH1
                                    210 	.globl _TH0
                                    211 	.globl _TL1
                                    212 	.globl _TL0
                                    213 	.globl _TMOD
                                    214 	.globl _TCON
                                    215 	.globl _XBUS_AUX
                                    216 	.globl _P7
                                    217 	.globl _P6_DIR
                                    218 	.globl _P6_OUT_PU
                                    219 	.globl _P6_IN
                                    220 	.globl _P5_DIR
                                    221 	.globl _P5_OUT_PU
                                    222 	.globl _P5_IN
                                    223 	.globl _P4_LED_KEY
                                    224 	.globl _P4_DIR_PU
                                    225 	.globl _P4_MOD_OC
                                    226 	.globl _P4
                                    227 	.globl _P3_DIR_PU
                                    228 	.globl _P3_MOD_OC
                                    229 	.globl _P3
                                    230 	.globl _P2_DIR_PU
                                    231 	.globl _P2_MOD_OC
                                    232 	.globl _P2
                                    233 	.globl _P1_DIR_PU
                                    234 	.globl _P1_MOD_OC
                                    235 	.globl _P1
                                    236 	.globl _P0_DIR_PU
                                    237 	.globl _P0_MOD_OC
                                    238 	.globl _P0
                                    239 	.globl _ROM_CTRL
                                    240 	.globl _ROM_DATA_HH
                                    241 	.globl _ROM_DATA_HL
                                    242 	.globl _ROM_DATA_HI
                                    243 	.globl _ROM_ADDR_H
                                    244 	.globl _ROM_ADDR_L
                                    245 	.globl _ROM_ADDR
                                    246 	.globl _GPIO_IE
                                    247 	.globl _IP_EX
                                    248 	.globl _IE_EX
                                    249 	.globl _IP
                                    250 	.globl _IE
                                    251 	.globl _WDOG_COUNT
                                    252 	.globl _RESET_KEEP
                                    253 	.globl _WAKE_CTRL
                                    254 	.globl _CLOCK_CFG
                                    255 	.globl _POWER_CFG
                                    256 	.globl _PCON
                                    257 	.globl _GLOBAL_CFG
                                    258 	.globl _SAFE_MOD
                                    259 	.globl _DPH
                                    260 	.globl _DPL
                                    261 	.globl _SP
                                    262 	.globl _A_INV
                                    263 	.globl _B
                                    264 	.globl _ACC
                                    265 	.globl _PSW
                                    266 	.globl _vialrgb_save_PARM_2
                                    267 	.globl _vialrgb_set_value_PARM_2
                                    268 	.globl _vialrgb_get_value_PARM_2
                                    269 	.globl _g_direct_mode_colors
                                    270 	.globl _vialrgb_get_value
                                    271 	.globl _vialrgb_set_value
                                    272 	.globl _vialrgb_save
                                    273 ;--------------------------------------------------------
                                    274 ; special function registers
                                    275 ;--------------------------------------------------------
                                    276 	.area RSEG    (ABS,DATA)
      000000                        277 	.org 0x0000
                           0000D0   278 _PSW	=	0x00d0
                           0000E0   279 _ACC	=	0x00e0
                           0000F0   280 _B	=	0x00f0
                           0000FD   281 _A_INV	=	0x00fd
                           000081   282 _SP	=	0x0081
                           000082   283 _DPL	=	0x0082
                           000083   284 _DPH	=	0x0083
                           0000A1   285 _SAFE_MOD	=	0x00a1
                           0000B1   286 _GLOBAL_CFG	=	0x00b1
                           000087   287 _PCON	=	0x0087
                           0000BA   288 _POWER_CFG	=	0x00ba
                           0000B9   289 _CLOCK_CFG	=	0x00b9
                           0000A9   290 _WAKE_CTRL	=	0x00a9
                           0000FE   291 _RESET_KEEP	=	0x00fe
                           0000FF   292 _WDOG_COUNT	=	0x00ff
                           0000A8   293 _IE	=	0x00a8
                           0000B8   294 _IP	=	0x00b8
                           0000E8   295 _IE_EX	=	0x00e8
                           0000E9   296 _IP_EX	=	0x00e9
                           0000B2   297 _GPIO_IE	=	0x00b2
                           008584   298 _ROM_ADDR	=	0x8584
                           000084   299 _ROM_ADDR_L	=	0x0084
                           000085   300 _ROM_ADDR_H	=	0x0085
                           008F8E   301 _ROM_DATA_HI	=	0x8f8e
                           00008E   302 _ROM_DATA_HL	=	0x008e
                           00008F   303 _ROM_DATA_HH	=	0x008f
                           000086   304 _ROM_CTRL	=	0x0086
                           000080   305 _P0	=	0x0080
                           0000C4   306 _P0_MOD_OC	=	0x00c4
                           0000C5   307 _P0_DIR_PU	=	0x00c5
                           000090   308 _P1	=	0x0090
                           000092   309 _P1_MOD_OC	=	0x0092
                           000093   310 _P1_DIR_PU	=	0x0093
                           0000A0   311 _P2	=	0x00a0
                           000094   312 _P2_MOD_OC	=	0x0094
                           000095   313 _P2_DIR_PU	=	0x0095
                           0000B0   314 _P3	=	0x00b0
                           000096   315 _P3_MOD_OC	=	0x0096
                           000097   316 _P3_DIR_PU	=	0x0097
                           0000C0   317 _P4	=	0x00c0
                           0000C2   318 _P4_MOD_OC	=	0x00c2
                           0000C3   319 _P4_DIR_PU	=	0x00c3
                           0000C1   320 _P4_LED_KEY	=	0x00c1
                           0000AA   321 _P5_IN	=	0x00aa
                           0000AB   322 _P5_OUT_PU	=	0x00ab
                           0000AC   323 _P5_DIR	=	0x00ac
                           0000AD   324 _P6_IN	=	0x00ad
                           0000AE   325 _P6_OUT_PU	=	0x00ae
                           0000AF   326 _P6_DIR	=	0x00af
                           0000F1   327 _P7	=	0x00f1
                           0000A2   328 _XBUS_AUX	=	0x00a2
                           000088   329 _TCON	=	0x0088
                           000089   330 _TMOD	=	0x0089
                           00008A   331 _TL0	=	0x008a
                           00008B   332 _TL1	=	0x008b
                           00008C   333 _TH0	=	0x008c
                           00008D   334 _TH1	=	0x008d
                           000098   335 _SCON	=	0x0098
                           000099   336 _SBUF	=	0x0099
                           0000C8   337 _T2CON	=	0x00c8
                           0000C9   338 _T2MOD	=	0x00c9
                           00CBCA   339 _RCAP2	=	0xcbca
                           0000CA   340 _RCAP2L	=	0x00ca
                           0000CB   341 _RCAP2H	=	0x00cb
                           00CDCC   342 _T2COUNT	=	0xcdcc
                           0000CC   343 _TL2	=	0x00cc
                           0000CD   344 _TH2	=	0x00cd
                           00CFCE   345 _T2CAP1	=	0xcfce
                           0000CE   346 _T2CAP1L	=	0x00ce
                           0000CF   347 _T2CAP1H	=	0x00cf
                           0000F8   348 _SPI0_STAT	=	0x00f8
                           0000F9   349 _SPI0_DATA	=	0x00f9
                           0000FA   350 _SPI0_CTRL	=	0x00fa
                           0000FB   351 _SPI0_CK_SE	=	0x00fb
                           0000FC   352 _SPI0_SETUP	=	0x00fc
                           0000BC   353 _SCON1	=	0x00bc
                           0000BD   354 _SBUF1	=	0x00bd
                           0000BE   355 _SBAUD1	=	0x00be
                           0000BF   356 _SIF1	=	0x00bf
                           0000B4   357 _SPI1_STAT	=	0x00b4
                           0000B5   358 _SPI1_DATA	=	0x00b5
                           0000B6   359 _SPI1_CTRL	=	0x00b6
                           0000B7   360 _SPI1_CK_SE	=	0x00b7
                           0000F3   361 _ADC_CTRL	=	0x00f3
                           00F5F4   362 _ADC_DAT	=	0xf5f4
                           0000F4   363 _ADC_DAT_L	=	0x00f4
                           0000F5   364 _ADC_DAT_H	=	0x00f5
                           0000F6   365 _ADC_CHAN	=	0x00f6
                           0000A6   366 _LED_COMMON	=	0x00a6
                           0000A7   367 _LED_PWM_OE	=	0x00a7
                           00C7C6   368 _LED_DMA	=	0xc7c6
                           0000C6   369 _LED_DMA_L	=	0x00c6
                           0000C7   370 _LED_DMA_H	=	0x00c7
                           0000F7   371 _LED_STATUS	=	0x00f7
                           0000B3   372 _I2CX_INT	=	0x00b3
                           0000BB   373 _I2CS_INT_ST	=	0x00bb
                                    374 ;--------------------------------------------------------
                                    375 ; special function bits
                                    376 ;--------------------------------------------------------
                                    377 	.area RSEG    (ABS,DATA)
      000000                        378 	.org 0x0000
                           0000D7   379 _CY	=	0x00d7
                           0000D6   380 _AC	=	0x00d6
                           0000D5   381 _F0	=	0x00d5
                           0000D4   382 _RS1	=	0x00d4
                           0000D3   383 _RS0	=	0x00d3
                           0000D2   384 _OV	=	0x00d2
                           0000D1   385 _F1	=	0x00d1
                           0000D0   386 _P	=	0x00d0
                           0000AF   387 _EA	=	0x00af
                           0000AE   388 _E_DIS	=	0x00ae
                           0000AD   389 _ET2	=	0x00ad
                           0000AC   390 _ES	=	0x00ac
                           0000AB   391 _ET1	=	0x00ab
                           0000AA   392 _EX1	=	0x00aa
                           0000A9   393 _ET0	=	0x00a9
                           0000A8   394 _EX0	=	0x00a8
                           0000BF   395 _PH_FLAG	=	0x00bf
                           0000BE   396 _PL_FLAG	=	0x00be
                           0000BD   397 _PT2	=	0x00bd
                           0000BC   398 _PS	=	0x00bc
                           0000BB   399 _PT1	=	0x00bb
                           0000BA   400 _PX1	=	0x00ba
                           0000B9   401 _PT0	=	0x00b9
                           0000B8   402 _PX0	=	0x00b8
                           0000EF   403 _IE_WDOG	=	0x00ef
                           0000EE   404 _IE_GPIO	=	0x00ee
                           0000ED   405 _IE_PWM_I2C	=	0x00ed
                           0000EC   406 _IE_UART1	=	0x00ec
                           0000EB   407 _IE_ADC	=	0x00eb
                           0000E9   408 _IE_USB	=	0x00e9
                           0000E8   409 _IE_SPI0	=	0x00e8
                           000087   410 _P0_7	=	0x0087
                           000086   411 _P0_6	=	0x0086
                           000085   412 _P0_5	=	0x0085
                           000084   413 _P0_4	=	0x0084
                           000083   414 _P0_3	=	0x0083
                           000082   415 _P0_2	=	0x0082
                           000081   416 _P0_1	=	0x0081
                           000080   417 _P0_0	=	0x0080
                           000081   418 _SDA0	=	0x0081
                           000080   419 _SCL0	=	0x0080
                           000083   420 _TXD_	=	0x0083
                           000082   421 _RXD_	=	0x0082
                           000085   422 _AIN13	=	0x0085
                           000084   423 _AIN12	=	0x0084
                           000083   424 _AIN11	=	0x0083
                           000082   425 _AIN10	=	0x0082
                           000081   426 _AIN9	=	0x0081
                           000080   427 _AIN8	=	0x0080
                           000097   428 _P1_7	=	0x0097
                           000096   429 _P1_6	=	0x0096
                           000095   430 _P1_5	=	0x0095
                           000094   431 _P1_4	=	0x0094
                           000093   432 _P1_3	=	0x0093
                           000092   433 _P1_2	=	0x0092
                           000091   434 _P1_1	=	0x0091
                           000090   435 _P1_0	=	0x0090
                           000097   436 _TXD1_	=	0x0097
                           000096   437 _RXD1_	=	0x0096
                           000097   438 _SCK	=	0x0097
                           000096   439 _MISO	=	0x0096
                           000095   440 _MOSI	=	0x0095
                           000094   441 _SCS	=	0x0094
                           000092   442 _INT0_	=	0x0092
                           000091   443 _T2EX	=	0x0091
                           000091   444 _CAP2	=	0x0091
                           000090   445 _T2	=	0x0090
                           000090   446 _CAP1	=	0x0090
                           000097   447 _AIN7	=	0x0097
                           000096   448 _AIN6	=	0x0096
                           000095   449 _AIN5	=	0x0095
                           000094   450 _AIN4	=	0x0094
                           000093   451 _AIN3	=	0x0093
                           000092   452 _AIN2	=	0x0092
                           000091   453 _AIN1	=	0x0091
                           000090   454 _AIN0	=	0x0090
                           0000A7   455 _P2_7	=	0x00a7
                           0000A6   456 _P2_6	=	0x00a6
                           0000A5   457 _P2_5	=	0x00a5
                           0000A4   458 _P2_4	=	0x00a4
                           0000A3   459 _P2_3	=	0x00a3
                           0000A2   460 _P2_2	=	0x00a2
                           0000A1   461 _P2_1	=	0x00a1
                           0000A0   462 _P2_0	=	0x00a0
                           0000A7   463 _TXD1	=	0x00a7
                           0000A6   464 _RXD1	=	0x00a6
                           0000A5   465 _T2EX_	=	0x00a5
                           0000A5   466 _CAP2_	=	0x00a5
                           0000A4   467 _T2_	=	0x00a4
                           0000A4   468 _CAP1_	=	0x00a4
                           0000B7   469 _P3_7	=	0x00b7
                           0000B6   470 _P3_6	=	0x00b6
                           0000B5   471 _P3_5	=	0x00b5
                           0000B4   472 _P3_4	=	0x00b4
                           0000B3   473 _P3_3	=	0x00b3
                           0000B2   474 _P3_2	=	0x00b2
                           0000B1   475 _P3_1	=	0x00b1
                           0000B0   476 _P3_0	=	0x00b0
                           0000B7   477 _SCK1	=	0x00b7
                           0000B6   478 _MISO1	=	0x00b6
                           0000B5   479 _MOSI1	=	0x00b5
                           0000B5   480 _T1	=	0x00b5
                           0000B4   481 _T0	=	0x00b4
                           0000B3   482 _INT1	=	0x00b3
                           0000B2   483 _INT0	=	0x00b2
                           0000B1   484 _TXD	=	0x00b1
                           0000B0   485 _RXD	=	0x00b0
                           0000C6   486 _P4_6	=	0x00c6
                           0000C5   487 _P4_5	=	0x00c5
                           0000C4   488 _P4_4	=	0x00c4
                           0000C3   489 _P4_3	=	0x00c3
                           0000C2   490 _P4_2	=	0x00c2
                           0000C1   491 _P4_1	=	0x00c1
                           0000C0   492 _P4_0	=	0x00c0
                           00008F   493 _TF1	=	0x008f
                           00008E   494 _TR1	=	0x008e
                           00008D   495 _TF0	=	0x008d
                           00008C   496 _TR0	=	0x008c
                           00008B   497 _IE1	=	0x008b
                           00008A   498 _IT1	=	0x008a
                           000089   499 _IE0	=	0x0089
                           000088   500 _IT0	=	0x0088
                           00009F   501 _SM0	=	0x009f
                           00009E   502 _SM1	=	0x009e
                           00009D   503 _SM2	=	0x009d
                           00009C   504 _REN	=	0x009c
                           00009B   505 _TB8	=	0x009b
                           00009A   506 _RB8	=	0x009a
                           000099   507 _TI	=	0x0099
                           000098   508 _RI	=	0x0098
                           0000CF   509 _TF2	=	0x00cf
                           0000CF   510 _CAP1F	=	0x00cf
                           0000CE   511 _EXF2	=	0x00ce
                           0000CD   512 _RCLK	=	0x00cd
                           0000CC   513 _TCLK	=	0x00cc
                           0000CB   514 _EXEN2	=	0x00cb
                           0000CA   515 _TR2	=	0x00ca
                           0000C9   516 _C_T2	=	0x00c9
                           0000C8   517 _CP_RL2	=	0x00c8
                           0000FF   518 _S0_FST_ACT	=	0x00ff
                           0000FE   519 _S0_IF_OV	=	0x00fe
                           0000FD   520 _S0_IF_FIRST	=	0x00fd
                           0000FC   521 _S0_IF_BYTE	=	0x00fc
                           0000FB   522 _S0_FREE	=	0x00fb
                           0000FA   523 _S0_T_FIFO	=	0x00fa
                           0000F8   524 _S0_R_FIFO	=	0x00f8
                           0000F7   525 _ADC_START	=	0x00f7
                                    526 ;--------------------------------------------------------
                                    527 ; overlayable register banks
                                    528 ;--------------------------------------------------------
                                    529 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        530 	.ds 8
                                    531 ;--------------------------------------------------------
                                    532 ; internal ram data
                                    533 ;--------------------------------------------------------
                                    534 	.area DSEG    (DATA)
      00004A                        535 _fast_set_leds_sloc0_1_0:
      00004A                        536 	.ds 2
      00004C                        537 _fast_set_leds_sloc1_1_0:
      00004C                        538 	.ds 2
      00004E                        539 _vialrgb_get_value_sloc0_1_0:
      00004E                        540 	.ds 2
      000050                        541 _vialrgb_get_value_sloc1_1_0:
      000050                        542 	.ds 2
      000052                        543 _vialrgb_set_value_sloc0_1_0:
      000052                        544 	.ds 2
                                    545 ;--------------------------------------------------------
                                    546 ; overlayable items in internal ram
                                    547 ;--------------------------------------------------------
                                    548 ;--------------------------------------------------------
                                    549 ; indirectly addressable internal ram data
                                    550 ;--------------------------------------------------------
                                    551 	.area ISEG    (DATA)
                                    552 ;--------------------------------------------------------
                                    553 ; absolute internal ram data
                                    554 ;--------------------------------------------------------
                                    555 	.area IABS    (ABS,DATA)
                                    556 	.area IABS    (ABS,DATA)
                                    557 ;--------------------------------------------------------
                                    558 ; bit data
                                    559 ;--------------------------------------------------------
                                    560 	.area BSEG    (BIT)
                                    561 ;--------------------------------------------------------
                                    562 ; paged external ram data
                                    563 ;--------------------------------------------------------
                                    564 	.area PSEG    (PAG,XDATA)
                                    565 ;--------------------------------------------------------
                                    566 ; uninitialized external ram data
                                    567 ;--------------------------------------------------------
                                    568 	.area XSEG    (XDATA)
      000C96                        569 _g_direct_mode_colors::
      000C96                        570 	.ds 246
      000D8C                        571 _get_supported_PARM_2:
      000D8C                        572 	.ds 1
      000D8D                        573 _get_supported_args_10000_255:
      000D8D                        574 	.ds 2
      000D8F                        575 _qmk_id_to_vialrgb_id_id_10000_262:
      000D8F                        576 	.ds 2
      000D91                        577 _vialrgb_id_to_qmk_id_id_10000_267:
      000D91                        578 	.ds 2
      000D93                        579 _set_mode_mode_10000_275:
      000D93                        580 	.ds 2
      000D95                        581 _get_matrix_pos_for_led_PARM_2:
      000D95                        582 	.ds 2
      000D97                        583 _get_matrix_pos_for_led_led_10000_280:
      000D97                        584 	.ds 2
      000D99                        585 _fast_set_leds_PARM_2:
      000D99                        586 	.ds 1
      000D9A                        587 _fast_set_leds_args_10000_282:
      000D9A                        588 	.ds 2
      000D9C                        589 _fast_set_leds_first_index_10001_285:
      000D9C                        590 	.ds 2
      000D9E                        591 _fast_set_leds_num_leds_10001_285:
      000D9E                        592 	.ds 1
      000D9F                        593 _vialrgb_get_value_PARM_2:
      000D9F                        594 	.ds 1
      000DA0                        595 _vialrgb_get_value_data_10000_291:
      000DA0                        596 	.ds 3
      000DA3                        597 _vialrgb_set_value_PARM_2:
      000DA3                        598 	.ds 1
      000DA4                        599 _vialrgb_set_value_data_10000_302:
      000DA4                        600 	.ds 3
      000DA7                        601 _vialrgb_save_PARM_2:
      000DA7                        602 	.ds 1
                                    603 ;--------------------------------------------------------
                                    604 ; absolute external ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area XABS    (ABS,XDATA)
                                    607 ;--------------------------------------------------------
                                    608 ; initialized external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area XISEG   (XDATA)
                                    611 	.area HOME    (CODE)
                                    612 	.area GSINIT0 (CODE)
                                    613 	.area GSINIT1 (CODE)
                                    614 	.area GSINIT2 (CODE)
                                    615 	.area GSINIT3 (CODE)
                                    616 	.area GSINIT4 (CODE)
                                    617 	.area GSINIT5 (CODE)
                                    618 	.area GSINIT  (CODE)
                                    619 	.area GSFINAL (CODE)
                                    620 	.area CSEG    (CODE)
                                    621 ;--------------------------------------------------------
                                    622 ; global & static initialisations
                                    623 ;--------------------------------------------------------
                                    624 	.area HOME    (CODE)
                                    625 	.area GSINIT  (CODE)
                                    626 	.area GSFINAL (CODE)
                                    627 	.area GSINIT  (CODE)
                                    628 ;--------------------------------------------------------
                                    629 ; Home
                                    630 ;--------------------------------------------------------
                                    631 	.area HOME    (CODE)
                                    632 	.area HOME    (CODE)
                                    633 ;--------------------------------------------------------
                                    634 ; code
                                    635 ;--------------------------------------------------------
                                    636 	.area CSEG    (CODE)
                                    637 ;------------------------------------------------------------
                                    638 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    639 ;------------------------------------------------------------
                                    640 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_167'
                                    641 ;------------------------------------------------------------
                                    642 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    643 ;	-----------------------------------------
                           000007   644 	ar7 = 0x07
                           000006   645 	ar6 = 0x06
                           000005   646 	ar5 = 0x05
                           000004   647 	ar4 = 0x04
                           000003   648 	ar3 = 0x03
                           000002   649 	ar2 = 0x02
                           000001   650 	ar1 = 0x01
                           000000   651 	ar0 = 0x00
                                    652 ;	 function get_supported
                                    653 ;	-----------------------------------------
      00B75C                        654 _get_supported:
      00B75C 12 3A 83         [24]  655 	lcall	_ak820_outline_0103
      00B75F 90 0D 8D         [24]  656 	mov	dptr,#_get_supported_args_10000_255
      00B762 12 3A 88         [24]  657 	lcall	_ak820_outline_0104
                                    658 ;	quantum/vialrgb.c:44: uint16_t gt = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00B765 90 0D 8D         [24]  659 	mov	dptr,#_get_supported_args_10000_255
      00B768 12 39 E0         [24]  660 	lcall	_ak820_outline_0004
      00B76B E0               [24]  661 	movx	a,@dptr
      00B76C FD               [12]  662 	mov	r5,a
      00B76D 7C 00            [12]  663 	mov	r4,#0x00
      00B76F 12 3A 8D         [24]  664 	lcall	_ak820_outline_0108
      00B772 FA               [12]  665 	mov	r2,a
      00B773 E4               [12]  666 	clr	a
      00B774 12 45 DF         [24]  667 	lcall	_ak820_outline_0141
                                    668 ;	quantum/vialrgb.c:45: for (uint8_t i = 0; i < length; ++i) args[i] = 0xff;
      00B777 90 0D 8C         [24]  669 	mov	dptr,#_get_supported_PARM_2
      00B77A E0               [24]  670 	movx	a,@dptr
      00B77B FB               [12]  671 	mov	r3,a
      00B77C 7A 00            [12]  672 	mov	r2,#0x00
      00B77E                        673 00107$:
      00B77E C3               [12]  674 	clr	c
      00B77F EA               [12]  675 	mov	a,r2
      00B780 9B               [12]  676 	subb	a,r3
      00B781 50 0A            [24]  677 	jnc	00101$
      00B783 EA               [12]  678 	mov	a,r2
      00B784 12 3A 30         [24]  679 	lcall	_ak820_outline_0031
      00B787 74 FF            [12]  680 	mov	a,#0xff
      00B789 F0               [24]  681 	movx	@dptr,a
      00B78A 0A               [12]  682 	inc	r2
      00B78B 80 F1            [24]  683 	sjmp	00107$
      00B78D                        684 00101$:
                                    685 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B78D 8D 06            [24]  686 	mov	ar6,r5
      00B78F 8C 07            [24]  687 	mov	ar7,r4
      00B791 8B 05            [24]  688 	mov	ar5,r3
      00B793 90 0D 8D         [24]  689 	mov	dptr,#_get_supported_args_10000_255
      00B796 12 3A 9A         [24]  690 	lcall	_ak820_outline_0120
      00B799 7A 00            [12]  691 	mov	r2,#0x00
      00B79B                        692 00110$:
      00B79B BA 07 00         [24]  693 	cjne	r2,#0x07,00159$
      00B79E                        694 00159$:
      00B79E 50 46            [24]  695 	jnc	00127$
                                    696 ;	quantum/vialrgb.c:47: uint16_t id = READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00B7A0 EA               [12]  697 	mov	a,r2
      00B7A1 75 F0 02         [24]  698 	mov	b,#0x02
      00B7A4 A4               [48]  699 	mul	ab
      00B7A5 24 02            [12]  700 	add	a, #_supported_modes
      00B7A7 F5 82            [12]  701 	mov	dpl,a
      00B7A9 74 C4            [12]  702 	mov	a,#(_supported_modes >> 8)
      00B7AB 12 5C 9E         [24]  703 	lcall	_ak820_outline_0105
      00B7AE F8               [12]  704 	mov	r0,a
      00B7AF 79 00            [12]  705 	mov	r1,#0x00
                                    706 ;	quantum/vialrgb.c:48: if (id > gt && length >= sizeof(id)) {
      00B7B1 C3               [12]  707 	clr	c
      00B7B2 EE               [12]  708 	mov	a,r6
      00B7B3 98               [12]  709 	subb	a,r0
      00B7B4 EF               [12]  710 	mov	a,r7
      00B7B5 99               [12]  711 	subb	a,r1
      00B7B6 50 2B            [24]  712 	jnc	00111$
                                    713 ;	free result
      00B7B8 BD 02 00         [24]  714 	cjne	r5,#0x02,00162$
      00B7BB                        715 00162$:
      00B7BB 40 26            [24]  716 	jc	00111$
                                    717 ;	quantum/vialrgb.c:49: args[0] = id;
      00B7BD C0 06            [24]  718 	push	ar6
      00B7BF C0 07            [24]  719 	push	ar7
      00B7C1 88 07            [24]  720 	mov	ar7,r0
      00B7C3 12 36 42         [24]  721 	lcall	_ak820_outline_0122
      00B7C6 EF               [12]  722 	mov	a,r7
      00B7C7 F0               [24]  723 	movx	@dptr,a
                                    724 ;	quantum/vialrgb.c:50: args[1] = id >> 8;
      00B7C8 12 36 42         [24]  725 	lcall	_ak820_outline_0122
      00B7CB A3               [24]  726 	inc	dptr
      00B7CC 89 00            [24]  727 	mov	ar0,r1
      00B7CE E8               [12]  728 	mov	a,r0
      00B7CF F0               [24]  729 	movx	@dptr,a
                                    730 ;	quantum/vialrgb.c:51: length -= sizeof(id);
      00B7D0 1D               [12]  731 	dec	r5
      00B7D1 1D               [12]  732 	dec	r5
                                    733 ;	quantum/vialrgb.c:52: args += sizeof(id);
      00B7D2 74 02            [12]  734 	mov	a,#0x02
      00B7D4 2B               [12]  735 	add	a, r3
      00B7D5 FB               [12]  736 	mov	r3,a
      00B7D6 E4               [12]  737 	clr	a
      00B7D7 3C               [12]  738 	addc	a, r4
      00B7D8 FC               [12]  739 	mov	r4,a
      00B7D9 90 0D 8D         [24]  740 	mov	dptr,#_get_supported_args_10000_255
      00B7DC 12 3A 6B         [24]  741 	lcall	_ak820_outline_0076
                                    742 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B7DF D0 07            [24]  743 	pop	ar7
      00B7E1 D0 06            [24]  744 	pop	ar6
                                    745 ;	quantum/vialrgb.c:52: args += sizeof(id);
      00B7E3                        746 00111$:
                                    747 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B7E3 0A               [12]  748 	inc	r2
      00B7E4 80 B5            [24]  749 	sjmp	00110$
      00B7E6                        750 00127$:
      00B7E6 90 0D 8D         [24]  751 	mov	dptr,#_get_supported_args_10000_255
      00B7E9 12 3A 6B         [24]  752 	lcall	_ak820_outline_0076
                                    753 ;	quantum/vialrgb.c:55: }
      00B7EC 22               [24]  754 	ret
                                    755 ;------------------------------------------------------------
                                    756 ;Allocation info for local variables in function 'qmk_id_to_vialrgb_id'
                                    757 ;------------------------------------------------------------
                                    758 ;id            Allocated with name '_qmk_id_to_vialrgb_id_id_10000_262'
                                    759 ;i             Allocated with name '_qmk_id_to_vialrgb_id_i_20000_264'
                                    760 ;qmk_id        Allocated with name '_qmk_id_to_vialrgb_id_qmk_id_30000_265'
                                    761 ;------------------------------------------------------------
                                    762 ;	quantum/vialrgb.c:57: static uint16_t qmk_id_to_vialrgb_id(uint16_t id) {
                                    763 ;	-----------------------------------------
                                    764 ;	 function qmk_id_to_vialrgb_id
                                    765 ;	-----------------------------------------
      00B7ED                        766 _qmk_id_to_vialrgb_id:
      00B7ED 12 3A 83         [24]  767 	lcall	_ak820_outline_0103
      00B7F0 90 0D 8F         [24]  768 	mov	dptr,#_qmk_id_to_vialrgb_id_id_10000_262
      00B7F3 12 3A 88         [24]  769 	lcall	_ak820_outline_0104
                                    770 ;	quantum/vialrgb.c:58: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B7F6 90 0D 8F         [24]  771 	mov	dptr,#_qmk_id_to_vialrgb_id_id_10000_262
      00B7F9 12 3A 40         [24]  772 	lcall	_ak820_outline_0051
      00B7FC 7D 00            [12]  773 	mov	r5,#0x00
      00B7FE                        774 00105$:
      00B7FE BD 07 00         [24]  775 	cjne	r5,#0x07,00130$
      00B801                        776 00130$:
      00B801 50 19            [24]  777 	jnc	00103$
                                    778 ;	quantum/vialrgb.c:59: uint16_t qmk_id = READ_MODE_ID(&supported_modes[i].qmk_id);
      00B803 12 BC 19         [24]  779 	lcall	_ak820_outline_0045
      00B806 A3               [24]  780 	inc	dptr
      00B807 E4               [12]  781 	clr	a
      00B808 93               [24]  782 	movc	a,@a+dptr
                                    783 ;	quantum/vialrgb.c:60: if (qmk_id == id)
      00B809 7A 00            [12]  784 	mov	r2,#0x00
      00B80B B5 06 0B         [24]  785 	cjne	a,ar6,00106$
      00B80E EA               [12]  786 	mov	a,r2
      00B80F B5 07 07         [24]  787 	cjne	a,ar7,00106$
                                    788 ;	quantum/vialrgb.c:61: return READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00B812 12 36 42         [24]  789 	lcall	_ak820_outline_0122
      00B815 12 BC 45         [24]  790 	lcall	_ak820_outline_0143
      00B818 22               [24]  791 	ret
      00B819                        792 00106$:
                                    793 ;	quantum/vialrgb.c:58: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B819 0D               [12]  794 	inc	r5
      00B81A 80 E2            [24]  795 	sjmp	00105$
      00B81C                        796 00103$:
                                    797 ;	quantum/vialrgb.c:63: return 0;
      00B81C 90 00 00         [24]  798 	mov	dptr,#0x0000
                                    799 ;	quantum/vialrgb.c:64: }
      00B81F 22               [24]  800 	ret
                                    801 ;------------------------------------------------------------
                                    802 ;Allocation info for local variables in function 'vialrgb_id_to_qmk_id'
                                    803 ;------------------------------------------------------------
                                    804 ;id            Allocated with name '_vialrgb_id_to_qmk_id_id_10000_267'
                                    805 ;i             Allocated with name '_vialrgb_id_to_qmk_id_i_20000_269'
                                    806 ;vialrgb_id    Allocated with name '_vialrgb_id_to_qmk_id_vialrgb_id_30000_270'
                                    807 ;------------------------------------------------------------
                                    808 ;	quantum/vialrgb.c:66: static uint16_t vialrgb_id_to_qmk_id(uint16_t id) {
                                    809 ;	-----------------------------------------
                                    810 ;	 function vialrgb_id_to_qmk_id
                                    811 ;	-----------------------------------------
      00B820                        812 _vialrgb_id_to_qmk_id:
      00B820 12 3A 83         [24]  813 	lcall	_ak820_outline_0103
      00B823 90 0D 91         [24]  814 	mov	dptr,#_vialrgb_id_to_qmk_id_id_10000_267
      00B826 12 3A 88         [24]  815 	lcall	_ak820_outline_0104
                                    816 ;	quantum/vialrgb.c:67: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B829 90 0D 91         [24]  817 	mov	dptr,#_vialrgb_id_to_qmk_id_id_10000_267
      00B82C 12 3A 40         [24]  818 	lcall	_ak820_outline_0051
      00B82F 7D 00            [12]  819 	mov	r5,#0x00
      00B831                        820 00105$:
      00B831 BD 07 00         [24]  821 	cjne	r5,#0x07,00130$
      00B834                        822 00130$:
      00B834 50 19            [24]  823 	jnc	00103$
                                    824 ;	quantum/vialrgb.c:68: uint16_t vialrgb_id = READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00B836 12 BC 19         [24]  825 	lcall	_ak820_outline_0045
      00B839 E4               [12]  826 	clr	a
      00B83A 93               [24]  827 	movc	a,@a+dptr
                                    828 ;	quantum/vialrgb.c:69: if (vialrgb_id == id)
      00B83B 7A 00            [12]  829 	mov	r2,#0x00
      00B83D B5 06 0C         [24]  830 	cjne	a,ar6,00106$
      00B840 EA               [12]  831 	mov	a,r2
      00B841 B5 07 08         [24]  832 	cjne	a,ar7,00106$
                                    833 ;	quantum/vialrgb.c:70: return READ_MODE_ID(&supported_modes[i].qmk_id);
      00B844 12 36 42         [24]  834 	lcall	_ak820_outline_0122
      00B847 A3               [24]  835 	inc	dptr
      00B848 12 BC 45         [24]  836 	lcall	_ak820_outline_0143
      00B84B 22               [24]  837 	ret
      00B84C                        838 00106$:
                                    839 ;	quantum/vialrgb.c:67: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B84C 0D               [12]  840 	inc	r5
      00B84D 80 E2            [24]  841 	sjmp	00105$
      00B84F                        842 00103$:
                                    843 ;	quantum/vialrgb.c:72: return 0;
      00B84F 90 00 00         [24]  844 	mov	dptr,#0x0000
                                    845 ;	quantum/vialrgb.c:73: }
      00B852 22               [24]  846 	ret
                                    847 ;------------------------------------------------------------
                                    848 ;Allocation info for local variables in function 'get_mode'
                                    849 ;------------------------------------------------------------
                                    850 ;	quantum/vialrgb.c:75: static uint16_t get_mode(void) {
                                    851 ;	-----------------------------------------
                                    852 ;	 function get_mode
                                    853 ;	-----------------------------------------
      00B853                        854 _get_mode:
                                    855 ;	quantum/vialrgb.c:77: if (!rgb_matrix_is_enabled())
      00B853 12 5A 92         [24]  856 	lcall	_rgb_matrix_is_enabled
      00B856 E5 82            [12]  857 	mov	a, dpl
      00B858 70 04            [24]  858 	jnz	00102$
                                    859 ;	quantum/vialrgb.c:78: return VIALRGB_EFFECT_OFF;
      00B85A 90 00 00         [24]  860 	mov	dptr,#0x0000
      00B85D 22               [24]  861 	ret
      00B85E                        862 00102$:
                                    863 ;	quantum/vialrgb.c:79: return qmk_id_to_vialrgb_id(rgb_matrix_get_mode());
      00B85E 12 5A 98         [24]  864 	lcall	_rgb_matrix_get_mode
      00B861 7E 00            [12]  865 	mov	r6,#0x00
      00B863 8E 83            [24]  866 	mov	dph, r6
                                    867 ;	quantum/vialrgb.c:80: }
      00B865 02 B7 ED         [24]  868 	ljmp	_qmk_id_to_vialrgb_id
                                    869 ;------------------------------------------------------------
                                    870 ;Allocation info for local variables in function 'set_mode'
                                    871 ;------------------------------------------------------------
                                    872 ;mode          Allocated with name '_set_mode_mode_10000_275'
                                    873 ;------------------------------------------------------------
                                    874 ;	quantum/vialrgb.c:82: static void set_mode(uint16_t mode) {
                                    875 ;	-----------------------------------------
                                    876 ;	 function set_mode
                                    877 ;	-----------------------------------------
      00B868                        878 _set_mode:
      00B868 12 3A 83         [24]  879 	lcall	_ak820_outline_0103
      00B86B 90 0D 93         [24]  880 	mov	dptr,#_set_mode_mode_10000_275
      00B86E 12 3A 88         [24]  881 	lcall	_ak820_outline_0104
                                    882 ;	quantum/vialrgb.c:84: if (mode == VIALRGB_EFFECT_OFF) {
      00B871 90 0D 93         [24]  883 	mov	dptr,#_set_mode_mode_10000_275
      00B874 12 3A 40         [24]  884 	lcall	_ak820_outline_0051
      00B877 90 0D 93         [24]  885 	mov	dptr,#_set_mode_mode_10000_275
      00B87A 12 73 D9         [24]  886 	lcall	_ak820_outline_0036
      00B87D 70 03            [24]  887 	jnz	00102$
                                    888 ;	quantum/vialrgb.c:85: rgb_matrix_disable_noeeprom();
      00B87F 02 5A E5         [24]  889 	ljmp	_rgb_matrix_disable_noeeprom
      00B882                        890 00102$:
                                    891 ;	quantum/vialrgb.c:87: rgb_matrix_enable_noeeprom();
      00B882 C0 07            [24]  892 	push	ar7
      00B884 C0 06            [24]  893 	push	ar6
      00B886 12 5A D4         [24]  894 	lcall	_rgb_matrix_enable_noeeprom
      00B889 D0 06            [24]  895 	pop	ar6
      00B88B D0 07            [24]  896 	pop	ar7
                                    897 ;	quantum/vialrgb.c:88: rgb_matrix_mode_noeeprom(vialrgb_id_to_qmk_id(mode));
      00B88D 12 45 C9         [24]  898 	lcall	_ak820_outline_0116
      00B890 11 20            [12]  899 	acall	_vialrgb_id_to_qmk_id
                                    900 ;	quantum/vialrgb.c:90: }
      00B892 02 5A EE         [24]  901 	ljmp	_rgb_matrix_mode_noeeprom
                                    902 ;------------------------------------------------------------
                                    903 ;Allocation info for local variables in function 'get_matrix_pos_for_led'
                                    904 ;------------------------------------------------------------
                                    905 ;output        Allocated with name '_get_matrix_pos_for_led_PARM_2'
                                    906 ;led           Allocated with name '_get_matrix_pos_for_led_led_10000_280'
                                    907 ;slot          Allocated with name '_get_matrix_pos_for_led_slot_10000_281'
                                    908 ;------------------------------------------------------------
                                    909 ;	quantum/vialrgb.c:93: static void get_matrix_pos_for_led(uint16_t led, uint8_t VIALRGB_BUFFER *output) {
                                    910 ;	-----------------------------------------
                                    911 ;	 function get_matrix_pos_for_led
                                    912 ;	-----------------------------------------
      00B895                        913 _get_matrix_pos_for_led:
      00B895 12 3A 83         [24]  914 	lcall	_ak820_outline_0103
      00B898 90 0D 97         [24]  915 	mov	dptr,#_get_matrix_pos_for_led_led_10000_280
      00B89B 12 3A 88         [24]  916 	lcall	_ak820_outline_0104
                                    917 ;	quantum/vialrgb.c:95: uint8_t slot = ak820_rgb_slots[led];
      00B89E 90 0D 97         [24]  918 	mov	dptr,#_get_matrix_pos_for_led_led_10000_280
      00B8A1 12 3A 40         [24]  919 	lcall	_ak820_outline_0051
      00B8A4 EE               [12]  920 	mov	a,r6
      00B8A5 24 01            [12]  921 	add	a, #_ak820_rgb_slots
      00B8A7 F5 82            [12]  922 	mov	dpl,a
      00B8A9 EF               [12]  923 	mov	a,r7
      00B8AA 34 BE            [12]  924 	addc	a, #(_ak820_rgb_slots >> 8)
      00B8AC F5 83            [12]  925 	mov	dph,a
      00B8AE E4               [12]  926 	clr	a
      00B8AF 93               [24]  927 	movc	a,@a+dptr
      00B8B0 FF               [12]  928 	mov	r7,a
                                    929 ;	quantum/vialrgb.c:96: output[0] = slot >> 3;
      00B8B1 90 0D 95         [24]  930 	mov	dptr,#_get_matrix_pos_for_led_PARM_2
      00B8B4 12 45 B7         [24]  931 	lcall	_ak820_outline_0097
      00B8B7 EF               [12]  932 	mov	a,r7
      00B8B8 12 5C D4         [24]  933 	lcall	_ak820_outline_0183
      00B8BB 12 87 61         [24]  934 	lcall	_ak820_outline_0118
                                    935 ;	quantum/vialrgb.c:97: output[1] = slot & 7;
      00B8BE 12 3A AA         [24]  936 	lcall	_ak820_outline_0131
      00B8C1 A3               [24]  937 	inc	dptr
      00B8C2 53 07 07         [24]  938 	anl	ar7,#0x07
      00B8C5 EF               [12]  939 	mov	a,r7
      00B8C6 F0               [24]  940 	movx	@dptr,a
                                    941 ;	quantum/vialrgb.c:110: }
      00B8C7 22               [24]  942 	ret
                                    943 ;------------------------------------------------------------
                                    944 ;Allocation info for local variables in function 'fast_set_leds'
                                    945 ;------------------------------------------------------------
                                    946 ;sloc0         Allocated with name '_fast_set_leds_sloc0_1_0'
                                    947 ;sloc1         Allocated with name '_fast_set_leds_sloc1_1_0'
                                    948 ;length        Allocated with name '_fast_set_leds_PARM_2'
                                    949 ;args          Allocated with name '_fast_set_leds_args_10000_282'
                                    950 ;first_index   Allocated with name '_fast_set_leds_first_index_10001_285'
                                    951 ;num_leds      Allocated with name '_fast_set_leds_num_leds_10001_285'
                                    952 ;i             Allocated with name '_fast_set_leds_i_20001_288'
                                    953 ;color         Allocated with name '_fast_set_leds_color_30001_289'
                                    954 ;val           Allocated with name '_fast_set_leds_val_30002_290'
                                    955 ;------------------------------------------------------------
                                    956 ;	quantum/vialrgb.c:112: static void fast_set_leds(uint8_t VIALRGB_BUFFER *args, uint8_t length) {
                                    957 ;	-----------------------------------------
                                    958 ;	 function fast_set_leds
                                    959 ;	-----------------------------------------
      00B8C8                        960 _fast_set_leds:
      00B8C8 12 3A 83         [24]  961 	lcall	_ak820_outline_0103
      00B8CB 90 0D 9A         [24]  962 	mov	dptr,#_fast_set_leds_args_10000_282
      00B8CE 12 3A 88         [24]  963 	lcall	_ak820_outline_0104
                                    964 ;	quantum/vialrgb.c:115: if (length < 3) return;
      00B8D1 90 0D 99         [24]  965 	mov	dptr,#_fast_set_leds_PARM_2
      00B8D4 E0               [24]  966 	movx	a,@dptr
      00B8D5 FF               [12]  967 	mov	r7,a
      00B8D6 BF 03 00         [24]  968 	cjne	r7,#0x03,00159$
      00B8D9                        969 00159$:
      00B8D9 50 01            [24]  970 	jnc	00102$
      00B8DB 22               [24]  971 	ret
      00B8DC                        972 00102$:
                                    973 ;	quantum/vialrgb.c:117: uint16_t first_index = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00B8DC 90 0D 9A         [24]  974 	mov	dptr,#_fast_set_leds_args_10000_282
      00B8DF E0               [24]  975 	movx	a,@dptr
      00B8E0 FD               [12]  976 	mov	r5,a
      00B8E1 A3               [24]  977 	inc	dptr
      00B8E2 E0               [24]  978 	movx	a,@dptr
      00B8E3 12 4B B6         [24]  979 	lcall	_ak820_outline_0057
      00B8E6 7B 00            [12]  980 	mov	r3,#0x00
      00B8E8 12 3A AA         [24]  981 	lcall	_ak820_outline_0131
      00B8EB A3               [24]  982 	inc	dptr
      00B8EC E0               [24]  983 	movx	a,@dptr
      00B8ED FA               [12]  984 	mov	r2,a
      00B8EE 79 00            [12]  985 	mov	r1,#0x00
      00B8F0 90 0D 9C         [24]  986 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00B8F3 E9               [12]  987 	mov	a,r1
      00B8F4 4C               [12]  988 	orl	a,r4
      00B8F5 F0               [24]  989 	movx	@dptr,a
      00B8F6 EA               [12]  990 	mov	a,r2
      00B8F7 4B               [12]  991 	orl	a,r3
      00B8F8 A3               [24]  992 	inc	dptr
      00B8F9 F0               [24]  993 	movx	@dptr,a
                                    994 ;	quantum/vialrgb.c:118: uint8_t num_leds = args[2];
      00B8FA 12 3A AA         [24]  995 	lcall	_ak820_outline_0131
      00B8FD A3               [24]  996 	inc	dptr
      00B8FE A3               [24]  997 	inc	dptr
      00B8FF E0               [24]  998 	movx	a,@dptr
      00B900 90 0D 9E         [24]  999 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B903 F0               [24] 1000 	movx	@dptr,a
                                   1001 ;	quantum/vialrgb.c:119: length -= 3;
      00B904 EF               [12] 1002 	mov	a,r7
      00B905 24 FD            [12] 1003 	add	a,#0xfd
      00B907 90 0D 99         [24] 1004 	mov	dptr,#_fast_set_leds_PARM_2
      00B90A F0               [24] 1005 	movx	@dptr,a
                                   1006 ;	quantum/vialrgb.c:120: args += 3;
      00B90B 90 0D 9A         [24] 1007 	mov	dptr,#_fast_set_leds_args_10000_282
      00B90E 74 03            [12] 1008 	mov	a,#0x03
      00B910 2D               [12] 1009 	add	a, r5
      00B911 F0               [24] 1010 	movx	@dptr,a
      00B912 E4               [12] 1011 	clr	a
      00B913 3E               [12] 1012 	addc	a, r6
      00B914 A3               [24] 1013 	inc	dptr
      00B915 F0               [24] 1014 	movx	@dptr,a
                                   1015 ;	quantum/vialrgb.c:123: if ((uint16_t)num_leds * 3u > length || first_index >= RGB_MATRIX_LED_COUNT) return;
      00B916 90 0D 9E         [24] 1016 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B919 E0               [24] 1017 	movx	a,@dptr
      00B91A FF               [12] 1018 	mov	r7,a
      00B91B 75 F0 03         [24] 1019 	mov	b,#0x03
      00B91E A4               [48] 1020 	mul	ab
      00B91F FE               [12] 1021 	mov	r6,a
      00B920 AD F0            [24] 1022 	mov	r5,b
      00B922 90 0D 99         [24] 1023 	mov	dptr,#_fast_set_leds_PARM_2
      00B925 E0               [24] 1024 	movx	a,@dptr
      00B926 FB               [12] 1025 	mov	r3,a
      00B927 7C 00            [12] 1026 	mov	r4,#0x00
      00B929 C3               [12] 1027 	clr	c
      00B92A EB               [12] 1028 	mov	a,r3
      00B92B 9E               [12] 1029 	subb	a,r6
      00B92C EC               [12] 1030 	mov	a,r4
      00B92D 9D               [12] 1031 	subb	a,r5
      00B92E 40 13            [24] 1032 	jc	00103$
                                   1033 ;	free result
      00B930 90 0D 9C         [24] 1034 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00B933 12 45 B7         [24] 1035 	lcall	_ak820_outline_0097
      00B936 8D 03            [24] 1036 	mov	ar3,r5
      00B938 8E 04            [24] 1037 	mov	ar4,r6
      00B93A C3               [12] 1038 	clr	c
      00B93B EB               [12] 1039 	mov	a,r3
      00B93C 94 52            [12] 1040 	subb	a,#0x52
      00B93E EC               [12] 1041 	mov	a,r4
      00B93F 94 00            [12] 1042 	subb	a,#0x00
      00B941 40 01            [24] 1043 	jc	00104$
      00B943                       1044 00103$:
      00B943 22               [24] 1045 	ret
      00B944                       1046 00104$:
                                   1047 ;	quantum/vialrgb.c:124: if (num_leds > RGB_MATRIX_LED_COUNT - first_index) num_leds = RGB_MATRIX_LED_COUNT - first_index;
      00B944 74 52            [12] 1048 	mov	a,#0x52
      00B946 C3               [12] 1049 	clr	c
      00B947 9D               [12] 1050 	subb	a,r5
      00B948 FB               [12] 1051 	mov	r3,a
      00B949 E4               [12] 1052 	clr	a
      00B94A 9E               [12] 1053 	subb	a,r6
      00B94B FC               [12] 1054 	mov	r4,a
      00B94C 7A 00            [12] 1055 	mov	r2,#0x00
      00B94E C3               [12] 1056 	clr	c
      00B94F EB               [12] 1057 	mov	a,r3
      00B950 9F               [12] 1058 	subb	a,r7
      00B951 EC               [12] 1059 	mov	a,r4
      00B952 9A               [12] 1060 	subb	a,r2
      00B953 50 08            [24] 1061 	jnc	00127$
                                   1062 ;	free result
      00B955 90 0D 9E         [24] 1063 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B958 74 52            [12] 1064 	mov	a,#0x52
      00B95A C3               [12] 1065 	clr	c
      00B95B 9D               [12] 1066 	subb	a,r5
      00B95C F0               [24] 1067 	movx	@dptr,a
                                   1068 ;	quantum/vialrgb.c:126: for (uint8_t i = 0; i < num_leds; ++i) {
      00B95D                       1069 00127$:
      00B95D 90 0D 9E         [24] 1070 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B960 E0               [24] 1071 	movx	a,@dptr
      00B961 FF               [12] 1072 	mov	r7,a
      00B962 90 0D 9C         [24] 1073 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00B965 12 45 B7         [24] 1074 	lcall	_ak820_outline_0097
      00B968 7C 00            [12] 1075 	mov	r4,#0x00
      00B96A                       1076 00110$:
      00B96A C3               [12] 1077 	clr	c
      00B96B EC               [12] 1078 	mov	a,r4
      00B96C 9F               [12] 1079 	subb	a,r7
      00B96D 40 01            [24] 1080 	jc	00164$
      00B96F 22               [24] 1081 	ret
      00B970                       1082 00164$:
                                   1083 ;	quantum/vialrgb.c:127: HSV VIALRGB_BUFFER *color = &g_direct_mode_colors[first_index++];
      00B970 C0 07            [24] 1084 	push	ar7
      00B972 90 0D B6         [24] 1085 	mov	dptr,#__mulint_PARM_2
      00B975 12 45 FA         [24] 1086 	lcall	_ak820_outline_0159
      00B978 90 00 03         [24] 1087 	mov	dptr,#0x0003
      00B97B C0 07            [24] 1088 	push	ar7
      00B97D C0 06            [24] 1089 	push	ar6
      00B97F C0 05            [24] 1090 	push	ar5
      00B981 C0 04            [24] 1091 	push	ar4
      00B983 B1 B1            [12] 1092 	acall	__mulint
      00B985 AA 82            [24] 1093 	mov	r2, dpl
      00B987 AB 83            [24] 1094 	mov	r3, dph
      00B989 D0 04            [24] 1095 	pop	ar4
      00B98B D0 05            [24] 1096 	pop	ar5
      00B98D D0 06            [24] 1097 	pop	ar6
      00B98F D0 07            [24] 1098 	pop	ar7
      00B991 0D               [12] 1099 	inc	r5
      00B992 BD 00 01         [24] 1100 	cjne	r5,#0x00,00165$
      00B995 0E               [12] 1101 	inc	r6
      00B996                       1102 00165$:
      00B996 EA               [12] 1103 	mov	a,r2
      00B997 24 96            [12] 1104 	add	a, #_g_direct_mode_colors
      00B999 FA               [12] 1105 	mov	r2,a
      00B99A EB               [12] 1106 	mov	a,r3
      00B99B 34 0C            [12] 1107 	addc	a, #(_g_direct_mode_colors >> 8)
      00B99D FB               [12] 1108 	mov	r3,a
                                   1109 ;	quantum/vialrgb.c:128: color->h = *args++;
      00B99E 8A 4A            [24] 1110 	mov	_fast_set_leds_sloc0_1_0,r2
      00B9A0 8B 4B            [24] 1111 	mov	(_fast_set_leds_sloc0_1_0 + 1),r3
      00B9A2 12 BC 2B         [24] 1112 	lcall	_ak820_outline_0081
      00B9A5 F8               [12] 1113 	mov	r0,a
      00B9A6 12 BC 39         [24] 1114 	lcall	_ak820_outline_0102
      00B9A9 85 4A 82         [24] 1115 	mov	dpl,_fast_set_leds_sloc0_1_0
      00B9AC 85 4B 83         [24] 1116 	mov	dph,(_fast_set_leds_sloc0_1_0 + 1)
      00B9AF E8               [12] 1117 	mov	a,r0
      00B9B0 F0               [24] 1118 	movx	@dptr,a
                                   1119 ;	quantum/vialrgb.c:129: color->s = *args++;
      00B9B1 74 01            [12] 1120 	mov	a,#0x01
      00B9B3 2A               [12] 1121 	add	a, r2
      00B9B4 F5 4A            [12] 1122 	mov	_fast_set_leds_sloc0_1_0,a
      00B9B6 E4               [12] 1123 	clr	a
      00B9B7 3B               [12] 1124 	addc	a, r3
      00B9B8 F5 4B            [12] 1125 	mov	(_fast_set_leds_sloc0_1_0 + 1),a
      00B9BA 90 0D 9A         [24] 1126 	mov	dptr,#_fast_set_leds_args_10000_282
      00B9BD E0               [24] 1127 	movx	a,@dptr
      00B9BE F8               [12] 1128 	mov	r0,a
      00B9BF A3               [24] 1129 	inc	dptr
      00B9C0 E0               [24] 1130 	movx	a,@dptr
      00B9C1 FF               [12] 1131 	mov	r7,a
      00B9C2 88 82            [24] 1132 	mov	dpl,r0
      00B9C4 8F 83            [24] 1133 	mov	dph,r7
      00B9C6 E0               [24] 1134 	movx	a,@dptr
      00B9C7 F9               [12] 1135 	mov	r1,a
      00B9C8 90 0D 9A         [24] 1136 	mov	dptr,#_fast_set_leds_args_10000_282
      00B9CB 74 01            [12] 1137 	mov	a,#0x01
      00B9CD 28               [12] 1138 	add	a, r0
      00B9CE F0               [24] 1139 	movx	@dptr,a
      00B9CF E4               [12] 1140 	clr	a
      00B9D0 3F               [12] 1141 	addc	a, r7
      00B9D1 A3               [24] 1142 	inc	dptr
      00B9D2 F0               [24] 1143 	movx	@dptr,a
      00B9D3 85 4A 82         [24] 1144 	mov	dpl,_fast_set_leds_sloc0_1_0
      00B9D6 85 4B 83         [24] 1145 	mov	dph,(_fast_set_leds_sloc0_1_0 + 1)
      00B9D9 E9               [12] 1146 	mov	a,r1
      00B9DA F0               [24] 1147 	movx	@dptr,a
                                   1148 ;	quantum/vialrgb.c:130: uint8_t val = *args++;
      00B9DB 12 BC 2B         [24] 1149 	lcall	_ak820_outline_0081
      00B9DE F5 4A            [12] 1150 	mov	_fast_set_leds_sloc0_1_0,a
      00B9E0 12 BC 39         [24] 1151 	lcall	_ak820_outline_0102
                                   1152 ;	quantum/vialrgb.c:131: color->v = (val > RGB_MATRIX_MAXIMUM_BRIGHTNESS) ? RGB_MATRIX_MAXIMUM_BRIGHTNESS : val;
      00B9E3 74 02            [12] 1153 	mov	a,#0x02
      00B9E5 2A               [12] 1154 	add	a, r2
      00B9E6 F5 4C            [12] 1155 	mov	_fast_set_leds_sloc1_1_0,a
      00B9E8 E4               [12] 1156 	clr	a
      00B9E9 3B               [12] 1157 	addc	a, r3
      00B9EA F5 4D            [12] 1158 	mov	(_fast_set_leds_sloc1_1_0 + 1),a
      00B9EC C3               [12] 1159 	clr	c
      00B9ED 74 A0            [12] 1160 	mov	a,#0xa0
      00B9EF 95 4A            [12] 1161 	subb	a,_fast_set_leds_sloc0_1_0
      00B9F1 D0 07            [24] 1162 	pop	ar7
      00B9F3 50 04            [24] 1163 	jnc	00114$
                                   1164 ;	free result
      00B9F5 7B A0            [12] 1165 	mov	r3,#0xa0
      00B9F7 80 04            [24] 1166 	sjmp	00115$
      00B9F9                       1167 00114$:
      00B9F9 AA 4A            [24] 1168 	mov	r2,_fast_set_leds_sloc0_1_0
      00B9FB 8A 03            [24] 1169 	mov	ar3,r2
      00B9FD                       1170 00115$:
      00B9FD 85 4C 82         [24] 1171 	mov	dpl,_fast_set_leds_sloc1_1_0
      00BA00 85 4D 83         [24] 1172 	mov	dph,(_fast_set_leds_sloc1_1_0 + 1)
      00BA03 EB               [12] 1173 	mov	a,r3
      00BA04 F0               [24] 1174 	movx	@dptr,a
                                   1175 ;	quantum/vialrgb.c:126: for (uint8_t i = 0; i < num_leds; ++i) {
      00BA05 0C               [12] 1176 	inc	r4
                                   1177 ;	quantum/vialrgb.c:133: }
      00BA06 21 6A            [24] 1178 	ajmp	00110$
                                   1179 ;------------------------------------------------------------
                                   1180 ;Allocation info for local variables in function 'vialrgb_get_value'
                                   1181 ;------------------------------------------------------------
                                   1182 ;sloc0         Allocated with name '_vialrgb_get_value_sloc0_1_0'
                                   1183 ;sloc1         Allocated with name '_vialrgb_get_value_sloc1_1_0'
                                   1184 ;length        Allocated with name '_vialrgb_get_value_PARM_2'
                                   1185 ;data          Allocated with name '_vialrgb_get_value_data_10000_291'
                                   1186 ;args          Allocated with name '_vialrgb_get_value_args_10001_294'
                                   1187 ;cmd           Allocated with name '_vialrgb_get_value_cmd_10001_294'
                                   1188 ;vialrgb_id    Allocated with name '_vialrgb_get_value_vialrgb_id_40001_297'
                                   1189 ;led           Allocated with name '_vialrgb_get_value_led_40001_300'
                                   1190 ;------------------------------------------------------------
                                   1191 ;	quantum/vialrgb.c:136: void vialrgb_get_value(uint8_t *data, uint8_t length) {
                                   1192 ;	-----------------------------------------
                                   1193 ;	 function vialrgb_get_value
                                   1194 ;	-----------------------------------------
      00BA08                       1195 _vialrgb_get_value:
      00BA08 12 45 87         [24] 1196 	lcall	_ak820_outline_0037
      00BA0B 90 0D A0         [24] 1197 	mov	dptr,#_vialrgb_get_value_data_10000_291
      00BA0E 12 3A 1F         [24] 1198 	lcall	_ak820_outline_0016
                                   1199 ;	quantum/vialrgb.c:137: if (length != VIAL_RAW_EPSIZE) return;
      00BA11 90 0D 9F         [24] 1200 	mov	dptr,#_vialrgb_get_value_PARM_2
      00BA14 E0               [24] 1201 	movx	a,@dptr
      00BA15 FF               [12] 1202 	mov	r7,a
      00BA16 BF 20 02         [24] 1203 	cjne	r7,#0x20,00162$
      00BA19 80 01            [24] 1204 	sjmp	00102$
      00BA1B                       1205 00162$:
      00BA1B 22               [24] 1206 	ret
      00BA1C                       1207 00102$:
                                   1208 ;	quantum/vialrgb.c:140: uint8_t VIALRGB_BUFFER *args = (uint8_t VIALRGB_BUFFER *)data + 2;
      00BA1C 90 0D A0         [24] 1209 	mov	dptr,#_vialrgb_get_value_data_10000_291
      00BA1F 12 BC 05         [24] 1210 	lcall	_ak820_outline_0043
                                   1211 ;	quantum/vialrgb.c:141: uint8_t cmd = args[-1];
                                   1212 ;	quantum/vialrgb.c:142: switch (cmd) {
      00BA22 BA 40 02         [24] 1213 	cjne	r2,#0x40,00163$
      00BA25 80 15            [24] 1214 	sjmp	00103$
      00BA27                       1215 00163$:
      00BA27 BA 41 02         [24] 1216 	cjne	r2,#0x41,00164$
      00BA2A 80 23            [24] 1217 	sjmp	00104$
      00BA2C                       1218 00164$:
      00BA2C BA 42 02         [24] 1219 	cjne	r2,#0x42,00165$
      00BA2F 41 E0            [12] 1220 	ajmp	00105$
      00BA31                       1221 00165$:
      00BA31 BA 43 02         [24] 1222 	cjne	r2,#0x43,00166$
      00BA34 41 ED            [12] 1223 	ajmp	00106$
      00BA36                       1224 00166$:
      00BA36 BA 44 02         [24] 1225 	cjne	r2,#0x44,00167$
      00BA39 41 F9            [12] 1226 	ajmp	00107$
      00BA3B                       1227 00167$:
      00BA3B 22               [24] 1228 	ret
                                   1229 ;	quantum/vialrgb.c:143: case vialrgb_get_info:
      00BA3C                       1230 00103$:
                                   1231 ;	quantum/vialrgb.c:144: args[0] = VIALRGB_PROTOCOL_VERSION & 0xFF;
      00BA3C 12 36 42         [24] 1232 	lcall	_ak820_outline_0122
      00BA3F 74 01            [12] 1233 	mov	a,#0x01
      00BA41 F0               [24] 1234 	movx	@dptr,a
                                   1235 ;	quantum/vialrgb.c:145: args[1] = VIALRGB_PROTOCOL_VERSION >> 8;
      00BA42 12 BB FD         [24] 1236 	lcall	_ak820_outline_0035
      00BA45 E4               [12] 1237 	clr	a
      00BA46 F0               [24] 1238 	movx	@dptr,a
                                   1239 ;	quantum/vialrgb.c:146: args[2] = RGB_MATRIX_MAXIMUM_BRIGHTNESS;
      00BA47 12 BB FD         [24] 1240 	lcall	_ak820_outline_0035
      00BA4A A3               [24] 1241 	inc	dptr
      00BA4B 74 A0            [12] 1242 	mov	a,#0xa0
      00BA4D F0               [24] 1243 	movx	@dptr,a
                                   1244 ;	quantum/vialrgb.c:147: break;
      00BA4E 22               [24] 1245 	ret
                                   1246 ;	quantum/vialrgb.c:148: case vialrgb_get_mode: {
      00BA4F                       1247 00104$:
                                   1248 ;	quantum/vialrgb.c:149: uint16_t vialrgb_id = get_mode();
      00BA4F C0 06            [24] 1249 	push	ar6
      00BA51 C0 05            [24] 1250 	push	ar5
      00BA53 C0 04            [24] 1251 	push	ar4
      00BA55 C0 03            [24] 1252 	push	ar3
      00BA57 11 53            [12] 1253 	acall	_get_mode
      00BA59 A9 82            [24] 1254 	mov	r1, dpl
      00BA5B AA 83            [24] 1255 	mov	r2, dph
      00BA5D D0 03            [24] 1256 	pop	ar3
      00BA5F D0 04            [24] 1257 	pop	ar4
      00BA61 D0 05            [24] 1258 	pop	ar5
      00BA63 D0 06            [24] 1259 	pop	ar6
                                   1260 ;	quantum/vialrgb.c:150: args[0] = vialrgb_id & 0xFF;
      00BA65 89 00            [24] 1261 	mov	ar0,r1
      00BA67 12 36 42         [24] 1262 	lcall	_ak820_outline_0122
      00BA6A E8               [12] 1263 	mov	a,r0
      00BA6B F0               [24] 1264 	movx	@dptr,a
                                   1265 ;	quantum/vialrgb.c:151: args[1] = vialrgb_id >> 8;
      00BA6C 12 BB FD         [24] 1266 	lcall	_ak820_outline_0035
      00BA6F 8A 01            [24] 1267 	mov	ar1,r2
      00BA71 E9               [12] 1268 	mov	a,r1
      00BA72 F0               [24] 1269 	movx	@dptr,a
                                   1270 ;	quantum/vialrgb.c:152: args[2] = rgb_matrix_get_speed();
      00BA73 74 04            [12] 1271 	mov	a,#0x04
      00BA75 12 94 CE         [24] 1272 	lcall	_ak820_outline_0133
      00BA78 C0 06            [24] 1273 	push	ar6
      00BA7A C0 05            [24] 1274 	push	ar5
      00BA7C C0 02            [24] 1275 	push	ar2
      00BA7E C0 01            [24] 1276 	push	ar1
      00BA80 12 5A B3         [24] 1277 	lcall	_rgb_matrix_get_speed
      00BA83 A8 82            [24] 1278 	mov	r0, dpl
      00BA85 D0 01            [24] 1279 	pop	ar1
      00BA87 D0 02            [24] 1280 	pop	ar2
      00BA89 D0 05            [24] 1281 	pop	ar5
      00BA8B D0 06            [24] 1282 	pop	ar6
      00BA8D 12 87 3A         [24] 1283 	lcall	_ak820_outline_0064
                                   1284 ;	quantum/vialrgb.c:153: args[3] = rgb_matrix_get_hue();
      00BA90 74 05            [12] 1285 	mov	a,#0x05
      00BA92 12 94 CE         [24] 1286 	lcall	_ak820_outline_0133
      00BA95 C0 06            [24] 1287 	push	ar6
      00BA97 C0 05            [24] 1288 	push	ar5
      00BA99 C0 02            [24] 1289 	push	ar2
      00BA9B C0 01            [24] 1290 	push	ar1
      00BA9D 12 5A 9E         [24] 1291 	lcall	_rgb_matrix_get_hue
      00BAA0 A8 82            [24] 1292 	mov	r0, dpl
      00BAA2 D0 01            [24] 1293 	pop	ar1
      00BAA4 D0 02            [24] 1294 	pop	ar2
      00BAA6 D0 05            [24] 1295 	pop	ar5
      00BAA8 D0 06            [24] 1296 	pop	ar6
      00BAAA 12 87 3A         [24] 1297 	lcall	_ak820_outline_0064
                                   1298 ;	quantum/vialrgb.c:154: args[4] = rgb_matrix_get_sat();
      00BAAD 74 06            [12] 1299 	mov	a,#0x06
      00BAAF 12 94 CE         [24] 1300 	lcall	_ak820_outline_0133
      00BAB2 C0 06            [24] 1301 	push	ar6
      00BAB4 C0 05            [24] 1302 	push	ar5
      00BAB6 C0 02            [24] 1303 	push	ar2
      00BAB8 C0 01            [24] 1304 	push	ar1
      00BABA 12 5A A5         [24] 1305 	lcall	_rgb_matrix_get_sat
      00BABD A8 82            [24] 1306 	mov	r0, dpl
      00BABF D0 01            [24] 1307 	pop	ar1
      00BAC1 D0 02            [24] 1308 	pop	ar2
      00BAC3 D0 05            [24] 1309 	pop	ar5
      00BAC5 D0 06            [24] 1310 	pop	ar6
      00BAC7 12 87 3A         [24] 1311 	lcall	_ak820_outline_0064
                                   1312 ;	quantum/vialrgb.c:155: args[5] = rgb_matrix_get_val();
      00BACA 74 07            [12] 1313 	mov	a,#0x07
      00BACC 12 94 CE         [24] 1314 	lcall	_ak820_outline_0133
      00BACF C0 02            [24] 1315 	push	ar2
      00BAD1 C0 01            [24] 1316 	push	ar1
      00BAD3 12 5A AC         [24] 1317 	lcall	_rgb_matrix_get_val
      00BAD6 A8 82            [24] 1318 	mov	r0, dpl
      00BAD8 D0 01            [24] 1319 	pop	ar1
      00BADA D0 02            [24] 1320 	pop	ar2
      00BADC 12 87 3A         [24] 1321 	lcall	_ak820_outline_0064
                                   1322 ;	quantum/vialrgb.c:156: break;
      00BADF 22               [24] 1323 	ret
                                   1324 ;	quantum/vialrgb.c:158: case vialrgb_get_supported: {
      00BAE0                       1325 00105$:
                                   1326 ;	quantum/vialrgb.c:159: get_supported(args, length - 2);
      00BAE0 EF               [12] 1327 	mov	a,r7
      00BAE1 24 FE            [12] 1328 	add	a,#0xfe
      00BAE3 90 0D 8C         [24] 1329 	mov	dptr,#_get_supported_PARM_2
      00BAE6 F0               [24] 1330 	movx	@dptr,a
      00BAE7 12 36 42         [24] 1331 	lcall	_ak820_outline_0122
                                   1332 ;	quantum/vialrgb.c:160: break;
      00BAEA 02 B7 5C         [24] 1333 	ljmp	_get_supported
                                   1334 ;	quantum/vialrgb.c:163: case vialrgb_get_number_leds: {
      00BAED                       1335 00106$:
                                   1336 ;	quantum/vialrgb.c:164: args[0] = RGB_MATRIX_LED_COUNT & 0xFF;
      00BAED 12 36 42         [24] 1337 	lcall	_ak820_outline_0122
      00BAF0 74 52            [12] 1338 	mov	a,#0x52
      00BAF2 F0               [24] 1339 	movx	@dptr,a
                                   1340 ;	quantum/vialrgb.c:165: args[1] = RGB_MATRIX_LED_COUNT >> 8;
      00BAF3 12 BB FD         [24] 1341 	lcall	_ak820_outline_0035
      00BAF6 E4               [12] 1342 	clr	a
      00BAF7 F0               [24] 1343 	movx	@dptr,a
                                   1344 ;	quantum/vialrgb.c:166: break;
      00BAF8 22               [24] 1345 	ret
                                   1346 ;	quantum/vialrgb.c:168: case vialrgb_get_led_info: {
      00BAF9                       1347 00107$:
                                   1348 ;	quantum/vialrgb.c:169: uint16_t led = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00BAF9 12 36 42         [24] 1349 	lcall	_ak820_outline_0122
      00BAFC E0               [24] 1350 	movx	a,@dptr
      00BAFD FF               [12] 1351 	mov	r7,a
      00BAFE 7A 00            [12] 1352 	mov	r2,#0x00
      00BB00 74 03            [12] 1353 	mov	a,#0x03
      00BB02 2D               [12] 1354 	add	a, r5
      00BB03 F8               [12] 1355 	mov	r0,a
      00BB04 E4               [12] 1356 	clr	a
      00BB05 3E               [12] 1357 	addc	a, r6
      00BB06 F9               [12] 1358 	mov	r1,a
      00BB07 C0 03            [24] 1359 	push	ar3
      00BB09 C0 04            [24] 1360 	push	ar4
      00BB0B 12 3A B5         [24] 1361 	lcall	_ak820_outline_0155
      00BB0E E0               [24] 1362 	movx	a,@dptr
      00BB0F FB               [12] 1363 	mov	r3,a
      00BB10 E4               [12] 1364 	clr	a
      00BB11 4F               [12] 1365 	orl	a,r7
      00BB12 F5 4E            [12] 1366 	mov	_vialrgb_get_value_sloc0_1_0,a
      00BB14 EB               [12] 1367 	mov	a,r3
      00BB15 4A               [12] 1368 	orl	a,r2
      00BB16 F5 4F            [12] 1369 	mov	(_vialrgb_get_value_sloc0_1_0 + 1),a
                                   1370 ;	quantum/vialrgb.c:170: if (led >= RGB_MATRIX_LED_COUNT) return;
      00BB18 AC 4E            [24] 1371 	mov	r4,_vialrgb_get_value_sloc0_1_0
      00BB1A AF 4F            [24] 1372 	mov	r7,(_vialrgb_get_value_sloc0_1_0 + 1)
      00BB1C C3               [12] 1373 	clr	c
      00BB1D EC               [12] 1374 	mov	a,r4
      00BB1E 94 52            [12] 1375 	subb	a,#0x52
      00BB20 EF               [12] 1376 	mov	a,r7
      00BB21 94 00            [12] 1377 	subb	a,#0x00
      00BB23 D0 04            [24] 1378 	pop	ar4
      00BB25 D0 03            [24] 1379 	pop	ar3
      00BB27 40 01            [24] 1380 	jc	00109$
      00BB29 22               [24] 1381 	ret
      00BB2A                       1382 00109$:
                                   1383 ;	quantum/vialrgb.c:172: args[0] = ak820_led_points[led].x;
      00BB2A E5 4E            [12] 1384 	mov	a,_vialrgb_get_value_sloc0_1_0
      00BB2C 25 4E            [12] 1385 	add	a,_vialrgb_get_value_sloc0_1_0
      00BB2E FA               [12] 1386 	mov	r2,a
      00BB2F E5 4F            [12] 1387 	mov	a,(_vialrgb_get_value_sloc0_1_0 + 1)
      00BB31 33               [12] 1388 	rlc	a
      00BB32 FF               [12] 1389 	mov	r7,a
      00BB33 EA               [12] 1390 	mov	a,r2
      00BB34 24 BB            [12] 1391 	add	a, #_ak820_led_points
      00BB36 F5 50            [12] 1392 	mov	_vialrgb_get_value_sloc1_1_0,a
      00BB38 EF               [12] 1393 	mov	a,r7
      00BB39 34 C0            [12] 1394 	addc	a, #(_ak820_led_points >> 8)
      00BB3B F5 51            [12] 1395 	mov	(_vialrgb_get_value_sloc1_1_0 + 1),a
      00BB3D 85 50 82         [24] 1396 	mov	dpl,_vialrgb_get_value_sloc1_1_0
      00BB40 85 51 83         [24] 1397 	mov	dph,(_vialrgb_get_value_sloc1_1_0 + 1)
      00BB43 E4               [12] 1398 	clr	a
      00BB44 93               [24] 1399 	movc	a,@a+dptr
      00BB45 12 36 42         [24] 1400 	lcall	_ak820_outline_0122
      00BB48 F0               [24] 1401 	movx	@dptr,a
                                   1402 ;	quantum/vialrgb.c:173: args[1] = ak820_led_points[led].y;
      00BB49 85 50 82         [24] 1403 	mov	dpl,_vialrgb_get_value_sloc1_1_0
      00BB4C 85 51 83         [24] 1404 	mov	dph,(_vialrgb_get_value_sloc1_1_0 + 1)
      00BB4F A3               [24] 1405 	inc	dptr
      00BB50 E4               [12] 1406 	clr	a
      00BB51 93               [24] 1407 	movc	a,@a+dptr
      00BB52 12 3A B5         [24] 1408 	lcall	_ak820_outline_0155
      00BB55 F0               [24] 1409 	movx	@dptr,a
                                   1410 ;	quantum/vialrgb.c:174: args[2] = LED_FLAG_KEYLIGHT;
      00BB56 12 BB FD         [24] 1411 	lcall	_ak820_outline_0035
      00BB59 A3               [24] 1412 	inc	dptr
      00BB5A 74 04            [12] 1413 	mov	a,#0x04
      00BB5C F0               [24] 1414 	movx	@dptr,a
                                   1415 ;	quantum/vialrgb.c:183: get_matrix_pos_for_led(led, &args[3]);
      00BB5D 90 0D 95         [24] 1416 	mov	dptr,#_get_matrix_pos_for_led_PARM_2
      00BB60 04               [12] 1417 	inc	a
      00BB61 2D               [12] 1418 	add	a, r5
      00BB62 F0               [24] 1419 	movx	@dptr,a
      00BB63 E4               [12] 1420 	clr	a
      00BB64 3E               [12] 1421 	addc	a, r6
      00BB65 A3               [24] 1422 	inc	dptr
      00BB66 F0               [24] 1423 	movx	@dptr,a
      00BB67 85 4E 82         [24] 1424 	mov	dpl, _vialrgb_get_value_sloc0_1_0
      00BB6A 85 4F 83         [24] 1425 	mov	dph, (_vialrgb_get_value_sloc0_1_0 + 1)
                                   1426 ;	quantum/vialrgb.c:187: }
                                   1427 ;	quantum/vialrgb.c:188: }
      00BB6D 01 95            [24] 1428 	ajmp	_get_matrix_pos_for_led
                                   1429 ;------------------------------------------------------------
                                   1430 ;Allocation info for local variables in function 'vialrgb_set_value'
                                   1431 ;------------------------------------------------------------
                                   1432 ;sloc0         Allocated with name '_vialrgb_set_value_sloc0_1_0'
                                   1433 ;length        Allocated with name '_vialrgb_set_value_PARM_2'
                                   1434 ;data          Allocated with name '_vialrgb_set_value_data_10000_302'
                                   1435 ;args          Allocated with name '_vialrgb_set_value_args_10001_305'
                                   1436 ;cmd           Allocated with name '_vialrgb_set_value_cmd_10001_305'
                                   1437 ;vialrgb_id    Allocated with name '_vialrgb_set_value_vialrgb_id_40001_308'
                                   1438 ;------------------------------------------------------------
                                   1439 ;	quantum/vialrgb.c:190: void vialrgb_set_value(uint8_t *data, uint8_t length) {
                                   1440 ;	-----------------------------------------
                                   1441 ;	 function vialrgb_set_value
                                   1442 ;	-----------------------------------------
      00BB6F                       1443 _vialrgb_set_value:
      00BB6F 12 45 87         [24] 1444 	lcall	_ak820_outline_0037
      00BB72 90 0D A4         [24] 1445 	mov	dptr,#_vialrgb_set_value_data_10000_302
      00BB75 12 3A 1F         [24] 1446 	lcall	_ak820_outline_0016
                                   1447 ;	quantum/vialrgb.c:191: if (length != VIAL_RAW_EPSIZE) return;
      00BB78 90 0D A3         [24] 1448 	mov	dptr,#_vialrgb_set_value_PARM_2
      00BB7B E0               [24] 1449 	movx	a,@dptr
      00BB7C FF               [12] 1450 	mov	r7,a
      00BB7D BF 20 02         [24] 1451 	cjne	r7,#0x20,00129$
      00BB80 80 01            [24] 1452 	sjmp	00102$
      00BB82                       1453 00129$:
      00BB82 22               [24] 1454 	ret
      00BB83                       1455 00102$:
                                   1456 ;	quantum/vialrgb.c:194: uint8_t VIALRGB_BUFFER *args = (uint8_t VIALRGB_BUFFER *)data + 2;
      00BB83 90 0D A4         [24] 1457 	mov	dptr,#_vialrgb_set_value_data_10000_302
      00BB86 12 BC 05         [24] 1458 	lcall	_ak820_outline_0043
                                   1459 ;	quantum/vialrgb.c:195: uint8_t cmd = args[-1];
                                   1460 ;	quantum/vialrgb.c:196: switch (cmd) {
      00BB89 BA 41 02         [24] 1461 	cjne	r2,#0x41,00130$
      00BB8C 80 06            [24] 1462 	sjmp	00103$
      00BB8E                       1463 00130$:
      00BB8E BA 42 02         [24] 1464 	cjne	r2,#0x42,00131$
      00BB91 80 5B            [24] 1465 	sjmp	00104$
      00BB93                       1466 00131$:
      00BB93 22               [24] 1467 	ret
                                   1468 ;	quantum/vialrgb.c:197: case vialrgb_set_mode: {
      00BB94                       1469 00103$:
                                   1470 ;	quantum/vialrgb.c:198: uint16_t vialrgb_id = args[0] | (args[1] << 8);
      00BB94 12 4B C4         [24] 1471 	lcall	_ak820_outline_0065
      00BB97 12 BB FD         [24] 1472 	lcall	_ak820_outline_0035
      00BB9A E0               [24] 1473 	movx	a,@dptr
      00BB9B F8               [12] 1474 	mov	r0,a
      00BB9C 79 00            [12] 1475 	mov	r1,#0x00
      00BB9E 88 53            [24] 1476 	mov	(_vialrgb_set_value_sloc0_1_0 + 1),r0
      00BBA0 89 52            [24] 1477 	mov	_vialrgb_set_value_sloc0_1_0,r1
      00BBA2 8A 01            [24] 1478 	mov	ar1,r2
      00BBA4 7A 00            [12] 1479 	mov	r2,#0x00
      00BBA6 E5 53            [12] 1480 	mov	a,(_vialrgb_set_value_sloc0_1_0 + 1)
      00BBA8 42 02            [12] 1481 	orl	ar2,a
                                   1482 ;	quantum/vialrgb.c:199: set_mode(vialrgb_id);
      00BBAA 12 46 00         [24] 1483 	lcall	_ak820_outline_0179
      00BBAD C0 06            [24] 1484 	push	ar6
      00BBAF C0 05            [24] 1485 	push	ar5
      00BBB1 11 68            [24] 1486 	acall	_set_mode
      00BBB3 D0 05            [24] 1487 	pop	ar5
      00BBB5 D0 06            [24] 1488 	pop	ar6
                                   1489 ;	quantum/vialrgb.c:200: rgb_matrix_set_speed_noeeprom(args[2]);
      00BBB7 12 BB FD         [24] 1490 	lcall	_ak820_outline_0035
      00BBBA A3               [24] 1491 	inc	dptr
      00BBBB E0               [24] 1492 	movx	a,@dptr
      00BBBC F5 82            [12] 1493 	mov	dpl,a
      00BBBE C0 06            [24] 1494 	push	ar6
      00BBC0 C0 05            [24] 1495 	push	ar5
      00BBC2 12 5B 7F         [24] 1496 	lcall	_rgb_matrix_set_speed_noeeprom
      00BBC5 D0 05            [24] 1497 	pop	ar5
      00BBC7 D0 06            [24] 1498 	pop	ar6
                                   1499 ;	quantum/vialrgb.c:201: rgb_matrix_sethsv_noeeprom(args[3], args[4], args[5]);
      00BBC9 12 BB FD         [24] 1500 	lcall	_ak820_outline_0035
      00BBCC A3               [24] 1501 	inc	dptr
      00BBCD A3               [24] 1502 	inc	dptr
      00BBCE E0               [24] 1503 	movx	a,@dptr
      00BBCF F9               [12] 1504 	mov	r1,a
      00BBD0 7A 00            [12] 1505 	mov	r2,#0x00
      00BBD2 74 06            [12] 1506 	mov	a,#0x06
      00BBD4 12 BC 4F         [24] 1507 	lcall	_ak820_outline_0168
      00BBD7 F8               [12] 1508 	mov	r0,a
      00BBD8 74 07            [12] 1509 	mov	a,#0x07
      00BBDA 12 BC 4F         [24] 1510 	lcall	_ak820_outline_0168
      00BBDD FE               [12] 1511 	mov	r6,a
      00BBDE 90 07 5A         [24] 1512 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_2
      00BBE1 E8               [12] 1513 	mov	a,r0
      00BBE2 F0               [24] 1514 	movx	@dptr,a
      00BBE3 90 07 5B         [24] 1515 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_3
      00BBE6 EE               [12] 1516 	mov	a,r6
      00BBE7 F0               [24] 1517 	movx	@dptr,a
      00BBE8 12 46 00         [24] 1518 	lcall	_ak820_outline_0179
                                   1519 ;	quantum/vialrgb.c:202: break;
                                   1520 ;	quantum/vialrgb.c:205: case vialrgb_direct_fastset: {
      00BBEB 02 5B 50         [24] 1521 	ljmp	_rgb_matrix_sethsv_noeeprom
      00BBEE                       1522 00104$:
                                   1523 ;	quantum/vialrgb.c:206: fast_set_leds(args, length - 2);
      00BBEE EF               [12] 1524 	mov	a,r7
      00BBEF 24 FE            [12] 1525 	add	a,#0xfe
      00BBF1 90 0D 99         [24] 1526 	mov	dptr,#_fast_set_leds_PARM_2
      00BBF4 F0               [24] 1527 	movx	@dptr,a
      00BBF5 12 36 42         [24] 1528 	lcall	_ak820_outline_0122
                                   1529 ;	quantum/vialrgb.c:210: }
                                   1530 ;	quantum/vialrgb.c:211: }
      00BBF8 01 C8            [24] 1531 	ajmp	_fast_set_leds
                                   1532 ;------------------------------------------------------------
                                   1533 ;Allocation info for local variables in function 'vialrgb_save'
                                   1534 ;------------------------------------------------------------
                                   1535 ;length        Allocated with name '_vialrgb_save_PARM_2'
                                   1536 ;data          Allocated with name '_vialrgb_save_data_10000_310'
                                   1537 ;------------------------------------------------------------
                                   1538 ;	quantum/vialrgb.c:213: void vialrgb_save(uint8_t *data, uint8_t length) {
                                   1539 ;	-----------------------------------------
                                   1540 ;	 function vialrgb_save
                                   1541 ;	-----------------------------------------
      00BBFA                       1542 _vialrgb_save:
                                   1543 ;	quantum/vialrgb.c:217: eeconfig_update_rgb_matrix();
                                   1544 ;	quantum/vialrgb.c:218: }
      00BBFA 02 55 E3         [24] 1545 	ljmp	_eeconfig_update_rgb_matrix
                                   1546 	.area CSEG    (CODE)
                                   1547 	.area CONST   (CODE)
                                   1548 	.area CONST   (CODE)
      00C402                       1549 _supported_modes:
      00C402 00                    1550 	.db #0x00	; 0
      00C403 00                    1551 	.db #0x00	; 0
      00C404 01                    1552 	.db #0x01	; 1
      00C405 05                    1553 	.db #0x05	; 5
      00C406 02                    1554 	.db #0x02	; 2
      00C407 01                    1555 	.db #0x01	; 1
      00C408 06                    1556 	.db #0x06	; 6
      00C409 02                    1557 	.db #0x02	; 2
      00C40A 0D                    1558 	.db #0x0d	; 13
      00C40B 03                    1559 	.db #0x03	; 3
      00C40C 0E                    1560 	.db #0x0e	; 14
      00C40D 04                    1561 	.db #0x04	; 4
      00C40E 1F                    1562 	.db #0x1f	; 31
      00C40F 06                    1563 	.db #0x06	; 6
                                   1564 	.area CSEG    (CODE)
                                   1565 	.area XINIT   (CODE)
                                   1566 	.area CABS    (ABS,CODE)
                                   1567 
                                   1568 ; Experimental exact instruction outlining.
                                   1569 	.globl _ak820_outline_0004
                                   1570 	.globl _ak820_outline_0016
                                   1571 	.globl _ak820_outline_0031
                                   1572 	.globl _ak820_outline_0035
                                   1573 	.globl _ak820_outline_0036
                                   1574 	.globl _ak820_outline_0037
                                   1575 	.globl _ak820_outline_0043
                                   1576 	.globl _ak820_outline_0045
                                   1577 	.globl _ak820_outline_0051
                                   1578 	.globl _ak820_outline_0057
                                   1579 	.globl _ak820_outline_0064
                                   1580 	.globl _ak820_outline_0065
                                   1581 	.globl _ak820_outline_0076
                                   1582 	.globl _ak820_outline_0081
                                   1583 	.globl _ak820_outline_0097
                                   1584 	.globl _ak820_outline_0102
                                   1585 	.globl _ak820_outline_0103
                                   1586 	.globl _ak820_outline_0104
                                   1587 	.globl _ak820_outline_0105
                                   1588 	.globl _ak820_outline_0108
                                   1589 	.globl _ak820_outline_0116
                                   1590 	.globl _ak820_outline_0118
                                   1591 	.globl _ak820_outline_0120
                                   1592 	.globl _ak820_outline_0122
                                   1593 	.globl _ak820_outline_0131
                                   1594 	.globl _ak820_outline_0133
                                   1595 	.globl _ak820_outline_0141
                                   1596 	.globl _ak820_outline_0143
                                   1597 	.globl _ak820_outline_0155
                                   1598 	.globl _ak820_outline_0159
                                   1599 	.globl _ak820_outline_0168
                                   1600 	.globl _ak820_outline_0179
                                   1601 	.globl _ak820_outline_0183
                                   1602 
                                   1603 	.area CSEG (CODE)
                                   1604 ; function ak820_outline_0035
      00BBFD                       1605 _ak820_outline_0035:
      00BBFD 8D 82            [24] 1606 	mov	dpl,r5
      00BBFF 8E 83            [24] 1607 	mov	dph,r6
      00BC01 A3               [24] 1608 	inc	dptr
      00BC02 A3               [24] 1609 	inc	dptr
      00BC03 A3               [24] 1610 	inc	dptr
      00BC04 22               [24] 1611 	ret
                                   1612 
                                   1613 	.area CSEG (CODE)
                                   1614 ; function ak820_outline_0043
      00BC05                       1615 _ak820_outline_0043:
      00BC05 E0               [24] 1616 	movx	a,@dptr
      00BC06 FD               [12] 1617 	mov	r5,a
      00BC07 A3               [24] 1618 	inc	dptr
      00BC08 E0               [24] 1619 	movx	a,@dptr
      00BC09 FE               [12] 1620 	mov	r6,a
      00BC0A 74 02            [12] 1621 	mov	a,#0x02
      00BC0C 2D               [12] 1622 	add	a,r5
      00BC0D FB               [12] 1623 	mov	r3,a
      00BC0E E4               [12] 1624 	clr	a
      00BC0F 3E               [12] 1625 	addc	a,r6
      00BC10 FC               [12] 1626 	mov	r4,a
      00BC11 8D 82            [24] 1627 	mov	dpl,r5
      00BC13 8E 83            [24] 1628 	mov	dph,r6
      00BC15 A3               [24] 1629 	inc	dptr
      00BC16 E0               [24] 1630 	movx	a,@dptr
      00BC17 FA               [12] 1631 	mov	r2,a
      00BC18 22               [24] 1632 	ret
                                   1633 
                                   1634 	.area CSEG (CODE)
                                   1635 ; function ak820_outline_0045
      00BC19                       1636 _ak820_outline_0045:
      00BC19 ED               [12] 1637 	mov	a,r5
      00BC1A 75 F0 02         [24] 1638 	mov	b,#0x02
      00BC1D A4               [48] 1639 	mul	ab
      00BC1E 24 02            [12] 1640 	add	a,#_supported_modes
      00BC20 FB               [12] 1641 	mov	r3,a
      00BC21 74 C4            [12] 1642 	mov	a,#(_supported_modes>>8)
      00BC23 35 F0            [12] 1643 	addc	a,b
      00BC25 FC               [12] 1644 	mov	r4,a
      00BC26 8B 82            [24] 1645 	mov	dpl,r3
      00BC28 8C 83            [24] 1646 	mov	dph,r4
      00BC2A 22               [24] 1647 	ret
                                   1648 
                                   1649 	.area CSEG (CODE)
                                   1650 ; function ak820_outline_0081
      00BC2B                       1651 _ak820_outline_0081:
      00BC2B 90 0D 9A         [24] 1652 	mov	dptr,#_fast_set_leds_args_10000_282
      00BC2E E0               [24] 1653 	movx	a,@dptr
      00BC2F F9               [12] 1654 	mov	r1,a
      00BC30 A3               [24] 1655 	inc	dptr
      00BC31 E0               [24] 1656 	movx	a,@dptr
      00BC32 FF               [12] 1657 	mov	r7,a
      00BC33 89 82            [24] 1658 	mov	dpl,r1
      00BC35 8F 83            [24] 1659 	mov	dph,r7
      00BC37 E0               [24] 1660 	movx	a,@dptr
      00BC38 22               [24] 1661 	ret
                                   1662 
                                   1663 	.area CSEG (CODE)
                                   1664 ; function ak820_outline_0102
      00BC39                       1665 _ak820_outline_0102:
      00BC39 90 0D 9A         [24] 1666 	mov	dptr,#_fast_set_leds_args_10000_282
      00BC3C 74 01            [12] 1667 	mov	a,#0x01
      00BC3E 29               [12] 1668 	add	a,r1
      00BC3F F0               [24] 1669 	movx	@dptr,a
      00BC40 E4               [12] 1670 	clr	a
      00BC41 3F               [12] 1671 	addc	a,r7
      00BC42 A3               [24] 1672 	inc	dptr
      00BC43 F0               [24] 1673 	movx	@dptr,a
      00BC44 22               [24] 1674 	ret
                                   1675 
                                   1676 	.area CSEG (CODE)
                                   1677 ; function ak820_outline_0143
      00BC45                       1678 _ak820_outline_0143:
      00BC45 E4               [12] 1679 	clr	a
      00BC46 93               [24] 1680 	movc	a,@a+dptr
      00BC47 FC               [12] 1681 	mov	r4,a
      00BC48 7B 00            [12] 1682 	mov	r3,#0x00
      00BC4A 8C 82            [24] 1683 	mov	dpl,r4
      00BC4C 8B 83            [24] 1684 	mov	dph,r3
      00BC4E 22               [24] 1685 	ret
                                   1686 
                                   1687 	.area CSEG (CODE)
                                   1688 ; function ak820_outline_0168
      00BC4F                       1689 _ak820_outline_0168:
      00BC4F 2D               [12] 1690 	add	a,r5
      00BC50 F5 82            [12] 1691 	mov	dpl,a
      00BC52 E4               [12] 1692 	clr	a
      00BC53 3E               [12] 1693 	addc	a,r6
      00BC54 F5 83            [12] 1694 	mov	dph,a
      00BC56 E0               [24] 1695 	movx	a,@dptr
      00BC57 22               [24] 1696 	ret
