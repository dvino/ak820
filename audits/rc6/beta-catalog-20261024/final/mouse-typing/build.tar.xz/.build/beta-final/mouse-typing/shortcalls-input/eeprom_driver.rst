                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module eeprom_driver
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_eeprom_write_block_xdata
                                     12 	.globl _ak820_eeprom_read_block_xdata
                                     13 	.globl _eeprom_read_byte
                                     14 	.globl _eeprom_update_dword_PARM_2
                                     15 	.globl _eeprom_update_word_PARM_2
                                     16 	.globl _eeprom_update_byte_PARM_2
                                     17 	.globl _eeprom_write_dword_PARM_2
                                     18 	.globl _eeprom_write_word_PARM_2
                                     19 	.globl _eeprom_write_byte_PARM_2
                                     20 	.globl _eeprom_read_word
                                     21 	.globl _eeprom_read_dword
                                     22 	.globl _eeprom_write_byte
                                     23 	.globl _eeprom_write_word
                                     24 	.globl _eeprom_write_dword
                                     25 	.globl _eeprom_update_byte
                                     26 	.globl _eeprom_update_word
                                     27 	.globl _eeprom_update_dword
                                     28 ;--------------------------------------------------------
                                     29 ; special function registers
                                     30 ;--------------------------------------------------------
                                     31 	.area RSEG    (ABS,DATA)
      000000                         32 	.org 0x0000
                                     33 ;--------------------------------------------------------
                                     34 ; special function bits
                                     35 ;--------------------------------------------------------
                                     36 	.area RSEG    (ABS,DATA)
      000000                         37 	.org 0x0000
                                     38 ;--------------------------------------------------------
                                     39 ; overlayable register banks
                                     40 ;--------------------------------------------------------
                                     41 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         42 	.ds 8
                                     43 ;--------------------------------------------------------
                                     44 ; overlayable bit register bank
                                     45 ;--------------------------------------------------------
                                     46 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         47 bits:
      000026                         48 	.ds 1
                           008000    49 	b0 = bits[0]
                           008100    50 	b1 = bits[1]
                           008200    51 	b2 = bits[2]
                           008300    52 	b3 = bits[3]
                           008400    53 	b4 = bits[4]
                           008500    54 	b5 = bits[5]
                           008600    55 	b6 = bits[6]
                           008700    56 	b7 = bits[7]
                                     57 ;--------------------------------------------------------
                                     58 ; internal ram data
                                     59 ;--------------------------------------------------------
                                     60 	.area DSEG    (DATA)
                                     61 ;--------------------------------------------------------
                                     62 ; overlayable items in internal ram
                                     63 ;--------------------------------------------------------
                                     64 ;--------------------------------------------------------
                                     65 ; indirectly addressable internal ram data
                                     66 ;--------------------------------------------------------
                                     67 	.area ISEG    (DATA)
                                     68 ;--------------------------------------------------------
                                     69 ; absolute internal ram data
                                     70 ;--------------------------------------------------------
                                     71 	.area IABS    (ABS,DATA)
                                     72 	.area IABS    (ABS,DATA)
                                     73 ;--------------------------------------------------------
                                     74 ; bit data
                                     75 ;--------------------------------------------------------
                                     76 	.area BSEG    (BIT)
                                     77 ;--------------------------------------------------------
                                     78 ; paged external ram data
                                     79 ;--------------------------------------------------------
                                     80 	.area PSEG    (PAG,XDATA)
                                     81 ;--------------------------------------------------------
                                     82 ; uninitialized external ram data
                                     83 ;--------------------------------------------------------
                                     84 	.area XSEG    (XDATA)
      000696                         85 _eeprom_read_word_addr_10000_91:
      000696                         86 	.ds 3
      000699                         87 _eeprom_read_word_ret_10000_92:
      000699                         88 	.ds 2
      00069B                         89 _eeprom_read_dword_addr_10000_93:
      00069B                         90 	.ds 3
      00069E                         91 _eeprom_read_dword_ret_10000_94:
      00069E                         92 	.ds 4
      0006A2                         93 _eeprom_write_byte_PARM_2:
      0006A2                         94 	.ds 1
      0006A3                         95 _eeprom_write_byte_addr_10000_95:
      0006A3                         96 	.ds 3
      0006A6                         97 _eeprom_write_word_PARM_2:
      0006A6                         98 	.ds 2
      0006A8                         99 _eeprom_write_word_addr_10000_97:
      0006A8                        100 	.ds 3
      0006AB                        101 _eeprom_write_dword_PARM_2:
      0006AB                        102 	.ds 4
      0006AF                        103 _eeprom_write_dword_addr_10000_99:
      0006AF                        104 	.ds 3
      0006B2                        105 _eeprom_update_byte_PARM_2:
      0006B2                        106 	.ds 1
      0006B3                        107 _eeprom_update_byte_addr_10000_107:
      0006B3                        108 	.ds 3
      0006B6                        109 _eeprom_update_word_PARM_2:
      0006B6                        110 	.ds 2
      0006B8                        111 _eeprom_update_word_addr_10000_111:
      0006B8                        112 	.ds 3
      0006BB                        113 _eeprom_update_dword_PARM_2:
      0006BB                        114 	.ds 4
      0006BF                        115 _eeprom_update_dword_addr_10000_115:
      0006BF                        116 	.ds 3
                                    117 ;--------------------------------------------------------
                                    118 ; absolute external ram data
                                    119 ;--------------------------------------------------------
                                    120 	.area XABS    (ABS,XDATA)
                                    121 ;--------------------------------------------------------
                                    122 ; initialized external ram data
                                    123 ;--------------------------------------------------------
                                    124 	.area XISEG   (XDATA)
                                    125 	.area HOME    (CODE)
                                    126 	.area GSINIT0 (CODE)
                                    127 	.area GSINIT1 (CODE)
                                    128 	.area GSINIT2 (CODE)
                                    129 	.area GSINIT3 (CODE)
                                    130 	.area GSINIT4 (CODE)
                                    131 	.area GSINIT5 (CODE)
                                    132 	.area GSINIT  (CODE)
                                    133 	.area GSFINAL (CODE)
                                    134 	.area CSEG    (CODE)
                                    135 ;--------------------------------------------------------
                                    136 ; global & static initialisations
                                    137 ;--------------------------------------------------------
                                    138 	.area HOME    (CODE)
                                    139 	.area GSINIT  (CODE)
                                    140 	.area GSFINAL (CODE)
                                    141 	.area GSINIT  (CODE)
                                    142 ;--------------------------------------------------------
                                    143 ; Home
                                    144 ;--------------------------------------------------------
                                    145 	.area HOME    (CODE)
                                    146 	.area HOME    (CODE)
                                    147 ;--------------------------------------------------------
                                    148 ; code
                                    149 ;--------------------------------------------------------
                                    150 	.area CSEG    (CODE)
                                    151 ;------------------------------------------------------------
                                    152 ;Allocation info for local variables in function 'eeprom_read_word'
                                    153 ;------------------------------------------------------------
                                    154 ;addr          Allocated with name '_eeprom_read_word_addr_10000_91'
                                    155 ;ret           Allocated with name '_eeprom_read_word_ret_10000_92'
                                    156 ;------------------------------------------------------------
                                    157 ;	drivers/eeprom/eeprom_driver.c:44: uint16_t eeprom_read_word(const uint16_t *addr) {
                                    158 ;	-----------------------------------------
                                    159 ;	 function eeprom_read_word
                                    160 ;	-----------------------------------------
      00508F                        161 _eeprom_read_word:
                           000007   162 	ar7 = 0x07
                           000006   163 	ar6 = 0x06
                           000005   164 	ar5 = 0x05
                           000004   165 	ar4 = 0x04
                           000003   166 	ar3 = 0x03
                           000002   167 	ar2 = 0x02
                           000001   168 	ar1 = 0x01
                           000000   169 	ar0 = 0x00
      00508F 12 45 8D         [24]  170 	lcall	_ak820_outline_0037
      005092 90 06 96         [24]  171 	mov	dptr,#_eeprom_read_word_addr_10000_91
      005095 12 3A 25         [24]  172 	lcall	_ak820_outline_0016
                                    173 ;	drivers/eeprom/eeprom_driver.c:45: uint16_t ret = 0;
      005098 90 06 99         [24]  174 	mov	dptr,#_eeprom_read_word_ret_10000_92
      00509B 12 52 9A         [24]  175 	lcall	_ak820_outline_0178
                                    176 ;	drivers/eeprom/eeprom_driver.c:46: EEPROM_LOCAL_READ(&ret, addr, 2);
      00509E 90 06 96         [24]  177 	mov	dptr,#_eeprom_read_word_addr_10000_91
      0050A1 12 52 48         [24]  178 	lcall	_ak820_outline_0021
      0050A4 90 05 91         [24]  179 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      0050A7 ED               [12]  180 	mov	a,r5
      0050A8 12 3A 25         [24]  181 	lcall	_ak820_outline_0016
      0050AB 90 05 94         [24]  182 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      0050AE 12 52 8C         [24]  183 	lcall	_ak820_outline_0106
      0050B1 90 06 99         [24]  184 	mov	dptr,#_eeprom_read_word_ret_10000_92
      0050B4 12 43 29         [24]  185 	lcall	_ak820_eeprom_read_block_xdata
                                    186 ;	drivers/eeprom/eeprom_driver.c:47: return ret;
      0050B7 90 06 99         [24]  187 	mov	dptr,#_eeprom_read_word_ret_10000_92
      0050BA 12 52 83         [24]  188 	lcall	_ak820_outline_0088
                                    189 ;	drivers/eeprom/eeprom_driver.c:48: }
      0050BD 22               [24]  190 	ret
                                    191 ;------------------------------------------------------------
                                    192 ;Allocation info for local variables in function 'eeprom_read_dword'
                                    193 ;------------------------------------------------------------
                                    194 ;addr          Allocated with name '_eeprom_read_dword_addr_10000_93'
                                    195 ;ret           Allocated with name '_eeprom_read_dword_ret_10000_94'
                                    196 ;------------------------------------------------------------
                                    197 ;	drivers/eeprom/eeprom_driver.c:50: uint32_t eeprom_read_dword(const uint32_t *addr) {
                                    198 ;	-----------------------------------------
                                    199 ;	 function eeprom_read_dword
                                    200 ;	-----------------------------------------
      0050BE                        201 _eeprom_read_dword:
      0050BE 12 45 8D         [24]  202 	lcall	_ak820_outline_0037
      0050C1 90 06 9B         [24]  203 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      0050C4 12 3A 25         [24]  204 	lcall	_ak820_outline_0016
                                    205 ;	drivers/eeprom/eeprom_driver.c:51: uint32_t ret = 0;
      0050C7 90 06 9E         [24]  206 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      0050CA 12 52 58         [24]  207 	lcall	_ak820_outline_0049
                                    208 ;	drivers/eeprom/eeprom_driver.c:52: EEPROM_LOCAL_READ(&ret, addr, 4);
      0050CD 90 06 9B         [24]  209 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      0050D0 12 52 48         [24]  210 	lcall	_ak820_outline_0021
      0050D3 90 05 91         [24]  211 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      0050D6 ED               [12]  212 	mov	a,r5
      0050D7 12 3A 25         [24]  213 	lcall	_ak820_outline_0016
      0050DA 90 05 94         [24]  214 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      0050DD 74 04            [12]  215 	mov	a,#0x04
      0050DF 12 3A AB         [24]  216 	lcall	_ak820_outline_0123
      0050E2 90 06 9E         [24]  217 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      0050E5 12 43 29         [24]  218 	lcall	_ak820_eeprom_read_block_xdata
                                    219 ;	drivers/eeprom/eeprom_driver.c:53: return ret;
      0050E8 90 06 9E         [24]  220 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      0050EB 12 52 61         [24]  221 	lcall	_ak820_outline_0054
                                    222 ;	drivers/eeprom/eeprom_driver.c:54: }
      0050EE 22               [24]  223 	ret
                                    224 ;------------------------------------------------------------
                                    225 ;Allocation info for local variables in function 'eeprom_write_byte'
                                    226 ;------------------------------------------------------------
                                    227 ;value         Allocated with name '_eeprom_write_byte_PARM_2'
                                    228 ;addr          Allocated with name '_eeprom_write_byte_addr_10000_95'
                                    229 ;------------------------------------------------------------
                                    230 ;	drivers/eeprom/eeprom_driver.c:56: void eeprom_write_byte(uint8_t *addr, uint8_t value) {
                                    231 ;	-----------------------------------------
                                    232 ;	 function eeprom_write_byte
                                    233 ;	-----------------------------------------
      0050EF                        234 _eeprom_write_byte:
      0050EF 12 45 8D         [24]  235 	lcall	_ak820_outline_0037
      0050F2 90 06 A3         [24]  236 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      0050F5 12 3A 25         [24]  237 	lcall	_ak820_outline_0016
                                    238 ;	drivers/eeprom/eeprom_driver.c:57: EEPROM_LOCAL_WRITE(&value, addr, 1);
      0050F8 90 06 A3         [24]  239 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      0050FB 12 52 22         [24]  240 	lcall	_ak820_outline_0002
      0050FE 74 01            [12]  241 	mov	a,#0x01
      005100 12 3A AB         [24]  242 	lcall	_ak820_outline_0123
      005103 90 06 A2         [24]  243 	mov	dptr,#_eeprom_write_byte_PARM_2
                                    244 ;	drivers/eeprom/eeprom_driver.c:58: }
      005106 02 43 B5         [24]  245 	ljmp	_ak820_eeprom_write_block_xdata
                                    246 ;------------------------------------------------------------
                                    247 ;Allocation info for local variables in function 'eeprom_write_word'
                                    248 ;------------------------------------------------------------
                                    249 ;value         Allocated with name '_eeprom_write_word_PARM_2'
                                    250 ;addr          Allocated with name '_eeprom_write_word_addr_10000_97'
                                    251 ;------------------------------------------------------------
                                    252 ;	drivers/eeprom/eeprom_driver.c:60: void eeprom_write_word(uint16_t *addr, uint16_t value) {
                                    253 ;	-----------------------------------------
                                    254 ;	 function eeprom_write_word
                                    255 ;	-----------------------------------------
      005109                        256 _eeprom_write_word:
      005109 12 45 8D         [24]  257 	lcall	_ak820_outline_0037
      00510C 90 06 A8         [24]  258 	mov	dptr,#_eeprom_write_word_addr_10000_97
      00510F 12 3A 25         [24]  259 	lcall	_ak820_outline_0016
                                    260 ;	drivers/eeprom/eeprom_driver.c:61: EEPROM_LOCAL_WRITE(&value, addr, 2);
      005112 90 06 A8         [24]  261 	mov	dptr,#_eeprom_write_word_addr_10000_97
      005115 12 52 22         [24]  262 	lcall	_ak820_outline_0002
      005118 12 52 8C         [24]  263 	lcall	_ak820_outline_0106
      00511B 90 06 A6         [24]  264 	mov	dptr,#_eeprom_write_word_PARM_2
                                    265 ;	drivers/eeprom/eeprom_driver.c:62: }
      00511E 02 43 B5         [24]  266 	ljmp	_ak820_eeprom_write_block_xdata
                                    267 ;------------------------------------------------------------
                                    268 ;Allocation info for local variables in function 'eeprom_write_dword'
                                    269 ;------------------------------------------------------------
                                    270 ;value         Allocated with name '_eeprom_write_dword_PARM_2'
                                    271 ;addr          Allocated with name '_eeprom_write_dword_addr_10000_99'
                                    272 ;------------------------------------------------------------
                                    273 ;	drivers/eeprom/eeprom_driver.c:64: void eeprom_write_dword(uint32_t *addr, uint32_t value) {
                                    274 ;	-----------------------------------------
                                    275 ;	 function eeprom_write_dword
                                    276 ;	-----------------------------------------
      005121                        277 _eeprom_write_dword:
      005121 12 45 8D         [24]  278 	lcall	_ak820_outline_0037
      005124 90 06 AF         [24]  279 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      005127 12 3A 25         [24]  280 	lcall	_ak820_outline_0016
                                    281 ;	drivers/eeprom/eeprom_driver.c:65: EEPROM_LOCAL_WRITE(&value, addr, 4);
      00512A 90 06 AF         [24]  282 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      00512D 12 52 22         [24]  283 	lcall	_ak820_outline_0002
      005130 74 04            [12]  284 	mov	a,#0x04
      005132 12 3A AB         [24]  285 	lcall	_ak820_outline_0123
      005135 90 06 AB         [24]  286 	mov	dptr,#_eeprom_write_dword_PARM_2
                                    287 ;	drivers/eeprom/eeprom_driver.c:66: }
      005138 02 43 B5         [24]  288 	ljmp	_ak820_eeprom_write_block_xdata
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'eeprom_update_block'
                                    291 ;------------------------------------------------------------
                                    292 ;sloc0         Allocated with name '_eeprom_update_block_sloc0_1_0'
                                    293 ;sloc1         Allocated with name '_eeprom_update_block_sloc1_1_0'
                                    294 ;sloc2         Allocated with name '_eeprom_update_block_sloc2_1_0'
                                    295 ;sloc3         Allocated with name '_eeprom_update_block_sloc3_1_0'
                                    296 ;addr          Allocated with name '_eeprom_update_block_PARM_2'
                                    297 ;len           Allocated with name '_eeprom_update_block_PARM_3'
                                    298 ;buf           Allocated with name '_eeprom_update_block_buf_10000_101'
                                    299 ;source        Allocated with name '_eeprom_update_block_source_10000_102'
                                    300 ;target        Allocated with name '_eeprom_update_block_target_10000_102'
                                    301 ;i             Allocated with name '_eeprom_update_block_i_10000_102'
                                    302 ;------------------------------------------------------------
                                    303 ;	drivers/eeprom/eeprom_driver.c:68: void eeprom_update_block(const void *buf, void *addr, size_t len) {
                                    304 ;	-----------------------------------------
                                    305 ;	 function eeprom_update_byte
                                    306 ;	-----------------------------------------
      00513B                        307 _eeprom_update_byte:
      00513B C0 07            [24]  308 	push	ar7
      00513D C0 06            [24]  309 	push	ar6
      00513F C0 05            [24]  310 	push	ar5
      005141 C0 04            [24]  311 	push	ar4
      005143 12 45 8D         [24]  312 	lcall	_ak820_outline_0037
      005146 90 06 B3         [24]  313 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      005149 12 3A 25         [24]  314 	lcall	_ak820_outline_0016
                                    315 ;	drivers/eeprom/eeprom_driver.c:83: uint8_t orig = eeprom_read_byte(addr);
      00514C 90 06 B3         [24]  316 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      00514F 12 52 39         [24]  317 	lcall	_ak820_outline_0003
      005152 12 42 EE         [24]  318 	lcall	_eeprom_read_byte
      005155 AF 82            [24]  319 	mov	r7, dpl
                                    320 ;	drivers/eeprom/eeprom_driver.c:84: if (orig != value) {
      005157 90 06 B2         [24]  321 	mov	dptr,#_eeprom_update_byte_PARM_2
      00515A E0               [24]  322 	movx	a,@dptr
      00515B FE               [12]  323 	mov	r6,a
      00515C EF               [12]  324 	mov	a,r7
      00515D B5 06 02         [24]  325 	cjne	a,ar6,00112$
      005160 80 35            [24]  326 	sjmp	00103$
      005162                        327 00112$:
                                    328 ;	drivers/eeprom/eeprom_driver.c:85: eeprom_write_byte(addr, value);
      005162 90 06 B3         [24]  329 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      005165 12 3A 65         [24]  330 	lcall	_ak820_outline_0060
      005168 A3               [24]  331 	inc	dptr
      005169 E0               [24]  332 	movx	a,@dptr
      00516A FF               [12]  333 	mov	r7,a
      00516B 90 06 A2         [24]  334 	mov	dptr,#_eeprom_write_byte_PARM_2
      00516E EE               [12]  335 	mov	a,r6
      00516F 12 3A 77         [24]  336 	lcall	_ak820_outline_0096
      005172 8F F0            [24]  337 	mov	b, r7
      005174 C0 07            [24]  338 	push	ar7
      005176 C0 06            [24]  339 	push	ar6
      005178 C0 05            [24]  340 	push	ar5
      00517A C0 04            [24]  341 	push	ar4
      00517C C0 03            [24]  342 	push	ar3
      00517E C0 02            [24]  343 	push	ar2
      005180 C0 01            [24]  344 	push	ar1
      005182 C0 00            [24]  345 	push	ar0
      005184 12 50 EF         [24]  346 	lcall	_eeprom_write_byte
      005187 D0 00            [24]  347 	pop	ar0
      005189 D0 01            [24]  348 	pop	ar1
      00518B D0 02            [24]  349 	pop	ar2
      00518D D0 03            [24]  350 	pop	ar3
      00518F D0 04            [24]  351 	pop	ar4
      005191 D0 05            [24]  352 	pop	ar5
      005193 D0 06            [24]  353 	pop	ar6
      005195 D0 07            [24]  354 	pop	ar7
      005197                        355 00103$:
                                    356 ;	drivers/eeprom/eeprom_driver.c:87: }
      005197 D0 04            [24]  357 	pop	ar4
      005199 D0 05            [24]  358 	pop	ar5
      00519B D0 06            [24]  359 	pop	ar6
      00519D D0 07            [24]  360 	pop	ar7
      00519F 22               [24]  361 	ret
                                    362 ;------------------------------------------------------------
                                    363 ;Allocation info for local variables in function 'eeprom_update_word'
                                    364 ;------------------------------------------------------------
                                    365 ;value         Allocated with name '_eeprom_update_word_PARM_2'
                                    366 ;addr          Allocated with name '_eeprom_update_word_addr_10000_111'
                                    367 ;orig          Allocated with name '_eeprom_update_word_orig_10000_112'
                                    368 ;------------------------------------------------------------
                                    369 ;	drivers/eeprom/eeprom_driver.c:89: void eeprom_update_word(uint16_t *addr, uint16_t value) {
                                    370 ;	-----------------------------------------
                                    371 ;	 function eeprom_update_word
                                    372 ;	-----------------------------------------
      0051A0                        373 _eeprom_update_word:
      0051A0 12 45 8D         [24]  374 	lcall	_ak820_outline_0037
      0051A3 90 06 B8         [24]  375 	mov	dptr,#_eeprom_update_word_addr_10000_111
      0051A6 12 3A 25         [24]  376 	lcall	_ak820_outline_0016
                                    377 ;	drivers/eeprom/eeprom_driver.c:90: uint16_t orig = eeprom_read_word(addr);
      0051A9 90 06 B8         [24]  378 	mov	dptr,#_eeprom_update_word_addr_10000_111
      0051AC 12 52 39         [24]  379 	lcall	_ak820_outline_0003
      0051AF 12 50 8F         [24]  380 	lcall	_eeprom_read_word
      0051B2 12 45 DA         [24]  381 	lcall	_ak820_outline_0132
                                    382 ;	drivers/eeprom/eeprom_driver.c:91: if (orig != value) {
      0051B5 90 06 B6         [24]  383 	mov	dptr,#_eeprom_update_word_PARM_2
      0051B8 12 3A 65         [24]  384 	lcall	_ak820_outline_0060
      0051BB EE               [12]  385 	mov	a,r6
      0051BC B5 04 05         [24]  386 	cjne	a,ar4,00112$
      0051BF EF               [12]  387 	mov	a,r7
      0051C0 B5 05 01         [24]  388 	cjne	a,ar5,00112$
      0051C3 22               [24]  389 	ret
      0051C4                        390 00112$:
                                    391 ;	drivers/eeprom/eeprom_driver.c:92: eeprom_write_word(addr, value);
      0051C4 90 06 B8         [24]  392 	mov	dptr,#_eeprom_update_word_addr_10000_111
      0051C7 E0               [24]  393 	movx	a,@dptr
      0051C8 FB               [12]  394 	mov	r3,a
      0051C9 A3               [24]  395 	inc	dptr
      0051CA 12 3A 46         [24]  396 	lcall	_ak820_outline_0051
      0051CD 90 06 A6         [24]  397 	mov	dptr,#_eeprom_write_word_PARM_2
      0051D0 12 3A 6B         [24]  398 	lcall	_ak820_outline_0071
      0051D3 8B 82            [24]  399 	mov	dpl, r3
      0051D5 8E 83            [24]  400 	mov	dph, r6
      0051D7 8F F0            [24]  401 	mov	b, r7
                                    402 ;	drivers/eeprom/eeprom_driver.c:94: }
      0051D9 02 51 09         [24]  403 	ljmp	_eeprom_write_word
                                    404 ;------------------------------------------------------------
                                    405 ;Allocation info for local variables in function 'eeprom_update_dword'
                                    406 ;------------------------------------------------------------
                                    407 ;value         Allocated with name '_eeprom_update_dword_PARM_2'
                                    408 ;addr          Allocated with name '_eeprom_update_dword_addr_10000_115'
                                    409 ;orig          Allocated with name '_eeprom_update_dword_orig_10000_116'
                                    410 ;------------------------------------------------------------
                                    411 ;	drivers/eeprom/eeprom_driver.c:96: void eeprom_update_dword(uint32_t *addr, uint32_t value) {
                                    412 ;	-----------------------------------------
                                    413 ;	 function eeprom_update_dword
                                    414 ;	-----------------------------------------
      0051DC                        415 _eeprom_update_dword:
      0051DC 12 45 8D         [24]  416 	lcall	_ak820_outline_0037
      0051DF 90 06 BF         [24]  417 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      0051E2 12 3A 25         [24]  418 	lcall	_ak820_outline_0016
                                    419 ;	drivers/eeprom/eeprom_driver.c:97: uint32_t orig = eeprom_read_dword(addr);
      0051E5 90 06 BF         [24]  420 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      0051E8 12 52 39         [24]  421 	lcall	_ak820_outline_0003
      0051EB 12 50 BE         [24]  422 	lcall	_eeprom_read_dword
      0051EE 12 52 72         [24]  423 	lcall	_ak820_outline_0056
                                    424 ;	drivers/eeprom/eeprom_driver.c:98: if (orig != value) {
      0051F1 90 06 BB         [24]  425 	mov	dptr,#_eeprom_update_dword_PARM_2
      0051F4 E0               [24]  426 	movx	a,@dptr
      0051F5 F8               [12]  427 	mov	r0,a
      0051F6 A3               [24]  428 	inc	dptr
      0051F7 12 52 7A         [24]  429 	lcall	_ak820_outline_0087
      0051FA EC               [12]  430 	mov	a,r4
      0051FB B5 00 0D         [24]  431 	cjne	a,ar0,00112$
      0051FE ED               [12]  432 	mov	a,r5
      0051FF B5 01 09         [24]  433 	cjne	a,ar1,00112$
      005202 EE               [12]  434 	mov	a,r6
      005203 B5 02 05         [24]  435 	cjne	a,ar2,00112$
      005206 EF               [12]  436 	mov	a,r7
      005207 B5 03 01         [24]  437 	cjne	a,ar3,00112$
      00520A 22               [24]  438 	ret
      00520B                        439 00112$:
                                    440 ;	drivers/eeprom/eeprom_driver.c:99: eeprom_write_dword(addr, value);
      00520B 90 06 BF         [24]  441 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      00520E 12 52 48         [24]  442 	lcall	_ak820_outline_0021
      005211 90 06 AB         [24]  443 	mov	dptr,#_eeprom_write_dword_PARM_2
      005214 E8               [12]  444 	mov	a,r0
      005215 F0               [24]  445 	movx	@dptr,a
      005216 E9               [12]  446 	mov	a,r1
      005217 A3               [24]  447 	inc	dptr
      005218 12 52 93         [24]  448 	lcall	_ak820_outline_0154
      00521B F0               [24]  449 	movx	@dptr,a
      00521C 12 52 51         [24]  450 	lcall	_ak820_outline_0044
                                    451 ;	drivers/eeprom/eeprom_driver.c:101: }
      00521F 02 51 21         [24]  452 	ljmp	_eeprom_write_dword
                                    453 	.area CSEG    (CODE)
                                    454 	.area CONST   (CODE)
                                    455 	.area XINIT   (CODE)
                                    456 	.area CABS    (ABS,CODE)
                                    457 
                                    458 ; Experimental exact instruction outlining.
                                    459 	.globl _ak820_outline_0002
                                    460 	.globl _ak820_outline_0003
                                    461 	.globl _ak820_outline_0016
                                    462 	.globl _ak820_outline_0021
                                    463 	.globl _ak820_outline_0037
                                    464 	.globl _ak820_outline_0044
                                    465 	.globl _ak820_outline_0049
                                    466 	.globl _ak820_outline_0051
                                    467 	.globl _ak820_outline_0054
                                    468 	.globl _ak820_outline_0056
                                    469 	.globl _ak820_outline_0060
                                    470 	.globl _ak820_outline_0071
                                    471 	.globl _ak820_outline_0087
                                    472 	.globl _ak820_outline_0088
                                    473 	.globl _ak820_outline_0096
                                    474 	.globl _ak820_outline_0106
                                    475 	.globl _ak820_outline_0123
                                    476 	.globl _ak820_outline_0132
                                    477 	.globl _ak820_outline_0154
                                    478 	.globl _ak820_outline_0178
                                    479 
                                    480 	.area CSEG (CODE)
                                    481 ; function ak820_outline_0002
      005222                        482 _ak820_outline_0002:
      005222 E0               [24]  483 	movx	a,@dptr
      005223 FD               [12]  484 	mov	r5,a
      005224 A3               [24]  485 	inc	dptr
      005225 E0               [24]  486 	movx	a,@dptr
      005226 FE               [12]  487 	mov	r6,a
      005227 A3               [24]  488 	inc	dptr
      005228 E0               [24]  489 	movx	a,@dptr
      005229 FF               [12]  490 	mov	r7,a
      00522A 90 05 9A         [24]  491 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      00522D ED               [12]  492 	mov	a,r5
      00522E F0               [24]  493 	movx	@dptr,a
      00522F EE               [12]  494 	mov	a,r6
      005230 A3               [24]  495 	inc	dptr
      005231 F0               [24]  496 	movx	@dptr,a
      005232 EF               [12]  497 	mov	a,r7
      005233 A3               [24]  498 	inc	dptr
      005234 F0               [24]  499 	movx	@dptr,a
      005235 90 05 9D         [24]  500 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      005238 22               [24]  501 	ret
                                    502 
                                    503 	.area CSEG (CODE)
                                    504 ; function ak820_outline_0003
      005239                        505 _ak820_outline_0003:
      005239 E0               [24]  506 	movx	a,@dptr
      00523A FD               [12]  507 	mov	r5,a
      00523B A3               [24]  508 	inc	dptr
      00523C E0               [24]  509 	movx	a,@dptr
      00523D FE               [12]  510 	mov	r6,a
      00523E A3               [24]  511 	inc	dptr
      00523F E0               [24]  512 	movx	a,@dptr
      005240 FF               [12]  513 	mov	r7,a
      005241 8D 82            [24]  514 	mov	dpl,r5
      005243 8E 83            [24]  515 	mov	dph,r6
      005245 8F F0            [24]  516 	mov	b,r7
      005247 22               [24]  517 	ret
                                    518 
                                    519 	.area CSEG (CODE)
                                    520 ; function ak820_outline_0021
      005248                        521 _ak820_outline_0021:
      005248 E0               [24]  522 	movx	a,@dptr
      005249 FD               [12]  523 	mov	r5,a
      00524A A3               [24]  524 	inc	dptr
      00524B E0               [24]  525 	movx	a,@dptr
      00524C FE               [12]  526 	mov	r6,a
      00524D A3               [24]  527 	inc	dptr
      00524E E0               [24]  528 	movx	a,@dptr
      00524F FF               [12]  529 	mov	r7,a
      005250 22               [24]  530 	ret
                                    531 
                                    532 	.area CSEG (CODE)
                                    533 ; function ak820_outline_0044
      005251                        534 _ak820_outline_0044:
      005251 8D 82            [24]  535 	mov	dpl,r5
      005253 8E 83            [24]  536 	mov	dph,r6
      005255 8F F0            [24]  537 	mov	b,r7
      005257 22               [24]  538 	ret
                                    539 
                                    540 	.area CSEG (CODE)
                                    541 ; function ak820_outline_0049
      005258                        542 _ak820_outline_0049:
      005258 E4               [12]  543 	clr	a
      005259 F0               [24]  544 	movx	@dptr,a
      00525A A3               [24]  545 	inc	dptr
      00525B F0               [24]  546 	movx	@dptr,a
      00525C A3               [24]  547 	inc	dptr
      00525D F0               [24]  548 	movx	@dptr,a
      00525E A3               [24]  549 	inc	dptr
      00525F F0               [24]  550 	movx	@dptr,a
      005260 22               [24]  551 	ret
                                    552 
                                    553 	.area CSEG (CODE)
                                    554 ; function ak820_outline_0054
      005261                        555 _ak820_outline_0054:
      005261 E0               [24]  556 	movx	a,@dptr
      005262 FC               [12]  557 	mov	r4,a
      005263 A3               [24]  558 	inc	dptr
      005264 E0               [24]  559 	movx	a,@dptr
      005265 FD               [12]  560 	mov	r5,a
      005266 A3               [24]  561 	inc	dptr
      005267 E0               [24]  562 	movx	a,@dptr
      005268 FE               [12]  563 	mov	r6,a
      005269 A3               [24]  564 	inc	dptr
      00526A E0               [24]  565 	movx	a,@dptr
      00526B 8C 82            [24]  566 	mov	dpl,r4
      00526D 8D 83            [24]  567 	mov	dph,r5
      00526F 8E F0            [24]  568 	mov	b,r6
      005271 22               [24]  569 	ret
                                    570 
                                    571 	.area CSEG (CODE)
                                    572 ; function ak820_outline_0056
      005272                        573 _ak820_outline_0056:
      005272 AC 82            [24]  574 	mov	r4,dpl
      005274 AD 83            [24]  575 	mov	r5,dph
      005276 AE F0            [24]  576 	mov	r6,b
      005278 FF               [12]  577 	mov	r7,a
      005279 22               [24]  578 	ret
                                    579 
                                    580 	.area CSEG (CODE)
                                    581 ; function ak820_outline_0087
      00527A                        582 _ak820_outline_0087:
      00527A E0               [24]  583 	movx	a,@dptr
      00527B F9               [12]  584 	mov	r1,a
      00527C A3               [24]  585 	inc	dptr
      00527D E0               [24]  586 	movx	a,@dptr
      00527E FA               [12]  587 	mov	r2,a
      00527F A3               [24]  588 	inc	dptr
      005280 E0               [24]  589 	movx	a,@dptr
      005281 FB               [12]  590 	mov	r3,a
      005282 22               [24]  591 	ret
                                    592 
                                    593 	.area CSEG (CODE)
                                    594 ; function ak820_outline_0088
      005283                        595 _ak820_outline_0088:
      005283 E0               [24]  596 	movx	a,@dptr
      005284 FE               [12]  597 	mov	r6,a
      005285 A3               [24]  598 	inc	dptr
      005286 E0               [24]  599 	movx	a,@dptr
      005287 8E 82            [24]  600 	mov	dpl,r6
      005289 F5 83            [12]  601 	mov	dph,a
      00528B 22               [24]  602 	ret
                                    603 
                                    604 	.area CSEG (CODE)
                                    605 ; function ak820_outline_0106
      00528C                        606 _ak820_outline_0106:
      00528C 74 02            [12]  607 	mov	a,#0x02
      00528E F0               [24]  608 	movx	@dptr,a
      00528F E4               [12]  609 	clr	a
      005290 A3               [24]  610 	inc	dptr
      005291 F0               [24]  611 	movx	@dptr,a
      005292 22               [24]  612 	ret
                                    613 
                                    614 	.area CSEG (CODE)
                                    615 ; function ak820_outline_0154
      005293                        616 _ak820_outline_0154:
      005293 F0               [24]  617 	movx	@dptr,a
      005294 EA               [12]  618 	mov	a,r2
      005295 A3               [24]  619 	inc	dptr
      005296 F0               [24]  620 	movx	@dptr,a
      005297 EB               [12]  621 	mov	a,r3
      005298 A3               [24]  622 	inc	dptr
      005299 22               [24]  623 	ret
                                    624 
                                    625 	.area CSEG (CODE)
                                    626 ; function ak820_outline_0178
      00529A                        627 _ak820_outline_0178:
      00529A E4               [12]  628 	clr	a
      00529B F0               [24]  629 	movx	@dptr,a
      00529C A3               [24]  630 	inc	dptr
      00529D F0               [24]  631 	movx	@dptr,a
      00529E 22               [24]  632 	ret
