                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module usb_ak820
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_nvm_end
                                     12 	.globl _ak820_nvm_flush
                                     13 	.globl _ak820_nvm_begin
                                     14 	.globl _ak820_nvm_ok
                                     15 	.globl _ak820_os_indicator_get
                                     16 	.globl _ak820_os_indicator_set
                                     17 	.globl _ak820_nvm_diagnostic
                                     18 	.globl _mDelaymS
                                     19 	.globl _mDelayuS
                                     20 	.globl _raw_hid_receive
                                     21 	.globl _ADC_START
                                     22 	.globl _S0_R_FIFO
                                     23 	.globl _S0_T_FIFO
                                     24 	.globl _S0_FREE
                                     25 	.globl _S0_IF_BYTE
                                     26 	.globl _S0_IF_FIRST
                                     27 	.globl _S0_IF_OV
                                     28 	.globl _S0_FST_ACT
                                     29 	.globl _CP_RL2
                                     30 	.globl _C_T2
                                     31 	.globl _TR2
                                     32 	.globl _EXEN2
                                     33 	.globl _TCLK
                                     34 	.globl _RCLK
                                     35 	.globl _EXF2
                                     36 	.globl _CAP1F
                                     37 	.globl _TF2
                                     38 	.globl _RI
                                     39 	.globl _TI
                                     40 	.globl _RB8
                                     41 	.globl _TB8
                                     42 	.globl _REN
                                     43 	.globl _SM2
                                     44 	.globl _SM1
                                     45 	.globl _SM0
                                     46 	.globl _IT0
                                     47 	.globl _IE0
                                     48 	.globl _IT1
                                     49 	.globl _IE1
                                     50 	.globl _TR0
                                     51 	.globl _TF0
                                     52 	.globl _TR1
                                     53 	.globl _TF1
                                     54 	.globl _P4_0
                                     55 	.globl _P4_1
                                     56 	.globl _P4_2
                                     57 	.globl _P4_3
                                     58 	.globl _P4_4
                                     59 	.globl _P4_5
                                     60 	.globl _P4_6
                                     61 	.globl _RXD
                                     62 	.globl _TXD
                                     63 	.globl _INT0
                                     64 	.globl _INT1
                                     65 	.globl _T0
                                     66 	.globl _T1
                                     67 	.globl _MOSI1
                                     68 	.globl _MISO1
                                     69 	.globl _SCK1
                                     70 	.globl _P3_0
                                     71 	.globl _P3_1
                                     72 	.globl _P3_2
                                     73 	.globl _P3_3
                                     74 	.globl _P3_4
                                     75 	.globl _P3_5
                                     76 	.globl _P3_6
                                     77 	.globl _P3_7
                                     78 	.globl _CAP1_
                                     79 	.globl _T2_
                                     80 	.globl _CAP2_
                                     81 	.globl _T2EX_
                                     82 	.globl _RXD1
                                     83 	.globl _TXD1
                                     84 	.globl _P2_0
                                     85 	.globl _P2_1
                                     86 	.globl _P2_2
                                     87 	.globl _P2_3
                                     88 	.globl _P2_4
                                     89 	.globl _P2_5
                                     90 	.globl _P2_6
                                     91 	.globl _P2_7
                                     92 	.globl _AIN0
                                     93 	.globl _AIN1
                                     94 	.globl _AIN2
                                     95 	.globl _AIN3
                                     96 	.globl _AIN4
                                     97 	.globl _AIN5
                                     98 	.globl _AIN6
                                     99 	.globl _AIN7
                                    100 	.globl _CAP1
                                    101 	.globl _T2
                                    102 	.globl _CAP2
                                    103 	.globl _T2EX
                                    104 	.globl _INT0_
                                    105 	.globl _SCS
                                    106 	.globl _MOSI
                                    107 	.globl _MISO
                                    108 	.globl _SCK
                                    109 	.globl _RXD1_
                                    110 	.globl _TXD1_
                                    111 	.globl _P1_0
                                    112 	.globl _P1_1
                                    113 	.globl _P1_2
                                    114 	.globl _P1_3
                                    115 	.globl _P1_4
                                    116 	.globl _P1_5
                                    117 	.globl _P1_6
                                    118 	.globl _P1_7
                                    119 	.globl _AIN8
                                    120 	.globl _AIN9
                                    121 	.globl _AIN10
                                    122 	.globl _AIN11
                                    123 	.globl _AIN12
                                    124 	.globl _AIN13
                                    125 	.globl _RXD_
                                    126 	.globl _TXD_
                                    127 	.globl _SCL0
                                    128 	.globl _SDA0
                                    129 	.globl _P0_0
                                    130 	.globl _P0_1
                                    131 	.globl _P0_2
                                    132 	.globl _P0_3
                                    133 	.globl _P0_4
                                    134 	.globl _P0_5
                                    135 	.globl _P0_6
                                    136 	.globl _P0_7
                                    137 	.globl _IE_SPI0
                                    138 	.globl _IE_USB
                                    139 	.globl _IE_ADC
                                    140 	.globl _IE_UART1
                                    141 	.globl _IE_PWM_I2C
                                    142 	.globl _IE_GPIO
                                    143 	.globl _IE_WDOG
                                    144 	.globl _PX0
                                    145 	.globl _PT0
                                    146 	.globl _PX1
                                    147 	.globl _PT1
                                    148 	.globl _PS
                                    149 	.globl _PT2
                                    150 	.globl _PL_FLAG
                                    151 	.globl _PH_FLAG
                                    152 	.globl _EX0
                                    153 	.globl _ET0
                                    154 	.globl _EX1
                                    155 	.globl _ET1
                                    156 	.globl _ES
                                    157 	.globl _ET2
                                    158 	.globl _E_DIS
                                    159 	.globl _EA
                                    160 	.globl _P
                                    161 	.globl _F1
                                    162 	.globl _OV
                                    163 	.globl _RS0
                                    164 	.globl _RS1
                                    165 	.globl _F0
                                    166 	.globl _AC
                                    167 	.globl _CY
                                    168 	.globl _I2CS_INT_ST
                                    169 	.globl _I2CX_INT
                                    170 	.globl _LED_STATUS
                                    171 	.globl _LED_DMA_H
                                    172 	.globl _LED_DMA_L
                                    173 	.globl _LED_DMA
                                    174 	.globl _LED_PWM_OE
                                    175 	.globl _LED_COMMON
                                    176 	.globl _ADC_CHAN
                                    177 	.globl _ADC_DAT_H
                                    178 	.globl _ADC_DAT_L
                                    179 	.globl _ADC_DAT
                                    180 	.globl _ADC_CTRL
                                    181 	.globl _SPI1_CK_SE
                                    182 	.globl _SPI1_CTRL
                                    183 	.globl _SPI1_DATA
                                    184 	.globl _SPI1_STAT
                                    185 	.globl _SIF1
                                    186 	.globl _SBAUD1
                                    187 	.globl _SBUF1
                                    188 	.globl _SCON1
                                    189 	.globl _SPI0_SETUP
                                    190 	.globl _SPI0_CK_SE
                                    191 	.globl _SPI0_CTRL
                                    192 	.globl _SPI0_DATA
                                    193 	.globl _SPI0_STAT
                                    194 	.globl _T2CAP1H
                                    195 	.globl _T2CAP1L
                                    196 	.globl _T2CAP1
                                    197 	.globl _TH2
                                    198 	.globl _TL2
                                    199 	.globl _T2COUNT
                                    200 	.globl _RCAP2H
                                    201 	.globl _RCAP2L
                                    202 	.globl _RCAP2
                                    203 	.globl _T2MOD
                                    204 	.globl _T2CON
                                    205 	.globl _SBUF
                                    206 	.globl _SCON
                                    207 	.globl _TH1
                                    208 	.globl _TH0
                                    209 	.globl _TL1
                                    210 	.globl _TL0
                                    211 	.globl _TMOD
                                    212 	.globl _TCON
                                    213 	.globl _XBUS_AUX
                                    214 	.globl _P7
                                    215 	.globl _P6_DIR
                                    216 	.globl _P6_OUT_PU
                                    217 	.globl _P6_IN
                                    218 	.globl _P5_DIR
                                    219 	.globl _P5_OUT_PU
                                    220 	.globl _P5_IN
                                    221 	.globl _P4_LED_KEY
                                    222 	.globl _P4_DIR_PU
                                    223 	.globl _P4_MOD_OC
                                    224 	.globl _P4
                                    225 	.globl _P3_DIR_PU
                                    226 	.globl _P3_MOD_OC
                                    227 	.globl _P3
                                    228 	.globl _P2_DIR_PU
                                    229 	.globl _P2_MOD_OC
                                    230 	.globl _P2
                                    231 	.globl _P1_DIR_PU
                                    232 	.globl _P1_MOD_OC
                                    233 	.globl _P1
                                    234 	.globl _P0_DIR_PU
                                    235 	.globl _P0_MOD_OC
                                    236 	.globl _P0
                                    237 	.globl _ROM_CTRL
                                    238 	.globl _ROM_DATA_HH
                                    239 	.globl _ROM_DATA_HL
                                    240 	.globl _ROM_DATA_HI
                                    241 	.globl _ROM_ADDR_H
                                    242 	.globl _ROM_ADDR_L
                                    243 	.globl _ROM_ADDR
                                    244 	.globl _GPIO_IE
                                    245 	.globl _IP_EX
                                    246 	.globl _IE_EX
                                    247 	.globl _IP
                                    248 	.globl _IE
                                    249 	.globl _WDOG_COUNT
                                    250 	.globl _RESET_KEEP
                                    251 	.globl _WAKE_CTRL
                                    252 	.globl _CLOCK_CFG
                                    253 	.globl _POWER_CFG
                                    254 	.globl _PCON
                                    255 	.globl _GLOBAL_CFG
                                    256 	.globl _SAFE_MOD
                                    257 	.globl _DPH
                                    258 	.globl _DPL
                                    259 	.globl _SP
                                    260 	.globl _A_INV
                                    261 	.globl _B
                                    262 	.globl _ACC
                                    263 	.globl _PSW
                                    264 	.globl _ak820_usb_raw_send_PARM_2
                                    265 	.globl _ak820_usb_try_send_PARM_3
                                    266 	.globl _ak820_usb_try_send_PARM_2
                                    267 	.globl _ak820_usb_send_PARM_3
                                    268 	.globl _ak820_usb_send_PARM_2
                                    269 	.globl _ak820_main_heartbeat
                                    270 	.globl _ak820_boot_stage
                                    271 	.globl _KB_USB_SetReport
                                    272 	.globl _KB_USB_UpStatus
                                    273 	.globl _MCU_Sleep_Operate
                                    274 	.globl _USB_SleepStatus
                                    275 	.globl _USB_EnumStatus
                                    276 	.globl _D0UsbConfig
                                    277 	.globl _pD0Descr
                                    278 	.globl _D0SetupLen
                                    279 	.globl _D0SetupReqCode
                                    280 	.globl _USB_DeviceInterrupt
                                    281 	.globl _USB_Device_Init
                                    282 	.globl _USB_WakeUp_PC
                                    283 	.globl _ak820_usb_send
                                    284 	.globl _ak820_usb_try_send
                                    285 	.globl _ak820_usb_raw_send
                                    286 	.globl _ak820_usb_raw_task
                                    287 	.globl _ak820_usb_take_keyboard_reset
                                    288 ;--------------------------------------------------------
                                    289 ; special function registers
                                    290 ;--------------------------------------------------------
                                    291 	.area RSEG    (ABS,DATA)
      000000                        292 	.org 0x0000
                           0000D0   293 _PSW	=	0x00d0
                           0000E0   294 _ACC	=	0x00e0
                           0000F0   295 _B	=	0x00f0
                           0000FD   296 _A_INV	=	0x00fd
                           000081   297 _SP	=	0x0081
                           000082   298 _DPL	=	0x0082
                           000083   299 _DPH	=	0x0083
                           0000A1   300 _SAFE_MOD	=	0x00a1
                           0000B1   301 _GLOBAL_CFG	=	0x00b1
                           000087   302 _PCON	=	0x0087
                           0000BA   303 _POWER_CFG	=	0x00ba
                           0000B9   304 _CLOCK_CFG	=	0x00b9
                           0000A9   305 _WAKE_CTRL	=	0x00a9
                           0000FE   306 _RESET_KEEP	=	0x00fe
                           0000FF   307 _WDOG_COUNT	=	0x00ff
                           0000A8   308 _IE	=	0x00a8
                           0000B8   309 _IP	=	0x00b8
                           0000E8   310 _IE_EX	=	0x00e8
                           0000E9   311 _IP_EX	=	0x00e9
                           0000B2   312 _GPIO_IE	=	0x00b2
                           008584   313 _ROM_ADDR	=	0x8584
                           000084   314 _ROM_ADDR_L	=	0x0084
                           000085   315 _ROM_ADDR_H	=	0x0085
                           008F8E   316 _ROM_DATA_HI	=	0x8f8e
                           00008E   317 _ROM_DATA_HL	=	0x008e
                           00008F   318 _ROM_DATA_HH	=	0x008f
                           000086   319 _ROM_CTRL	=	0x0086
                           000080   320 _P0	=	0x0080
                           0000C4   321 _P0_MOD_OC	=	0x00c4
                           0000C5   322 _P0_DIR_PU	=	0x00c5
                           000090   323 _P1	=	0x0090
                           000092   324 _P1_MOD_OC	=	0x0092
                           000093   325 _P1_DIR_PU	=	0x0093
                           0000A0   326 _P2	=	0x00a0
                           000094   327 _P2_MOD_OC	=	0x0094
                           000095   328 _P2_DIR_PU	=	0x0095
                           0000B0   329 _P3	=	0x00b0
                           000096   330 _P3_MOD_OC	=	0x0096
                           000097   331 _P3_DIR_PU	=	0x0097
                           0000C0   332 _P4	=	0x00c0
                           0000C2   333 _P4_MOD_OC	=	0x00c2
                           0000C3   334 _P4_DIR_PU	=	0x00c3
                           0000C1   335 _P4_LED_KEY	=	0x00c1
                           0000AA   336 _P5_IN	=	0x00aa
                           0000AB   337 _P5_OUT_PU	=	0x00ab
                           0000AC   338 _P5_DIR	=	0x00ac
                           0000AD   339 _P6_IN	=	0x00ad
                           0000AE   340 _P6_OUT_PU	=	0x00ae
                           0000AF   341 _P6_DIR	=	0x00af
                           0000F1   342 _P7	=	0x00f1
                           0000A2   343 _XBUS_AUX	=	0x00a2
                           000088   344 _TCON	=	0x0088
                           000089   345 _TMOD	=	0x0089
                           00008A   346 _TL0	=	0x008a
                           00008B   347 _TL1	=	0x008b
                           00008C   348 _TH0	=	0x008c
                           00008D   349 _TH1	=	0x008d
                           000098   350 _SCON	=	0x0098
                           000099   351 _SBUF	=	0x0099
                           0000C8   352 _T2CON	=	0x00c8
                           0000C9   353 _T2MOD	=	0x00c9
                           00CBCA   354 _RCAP2	=	0xcbca
                           0000CA   355 _RCAP2L	=	0x00ca
                           0000CB   356 _RCAP2H	=	0x00cb
                           00CDCC   357 _T2COUNT	=	0xcdcc
                           0000CC   358 _TL2	=	0x00cc
                           0000CD   359 _TH2	=	0x00cd
                           00CFCE   360 _T2CAP1	=	0xcfce
                           0000CE   361 _T2CAP1L	=	0x00ce
                           0000CF   362 _T2CAP1H	=	0x00cf
                           0000F8   363 _SPI0_STAT	=	0x00f8
                           0000F9   364 _SPI0_DATA	=	0x00f9
                           0000FA   365 _SPI0_CTRL	=	0x00fa
                           0000FB   366 _SPI0_CK_SE	=	0x00fb
                           0000FC   367 _SPI0_SETUP	=	0x00fc
                           0000BC   368 _SCON1	=	0x00bc
                           0000BD   369 _SBUF1	=	0x00bd
                           0000BE   370 _SBAUD1	=	0x00be
                           0000BF   371 _SIF1	=	0x00bf
                           0000B4   372 _SPI1_STAT	=	0x00b4
                           0000B5   373 _SPI1_DATA	=	0x00b5
                           0000B6   374 _SPI1_CTRL	=	0x00b6
                           0000B7   375 _SPI1_CK_SE	=	0x00b7
                           0000F3   376 _ADC_CTRL	=	0x00f3
                           00F5F4   377 _ADC_DAT	=	0xf5f4
                           0000F4   378 _ADC_DAT_L	=	0x00f4
                           0000F5   379 _ADC_DAT_H	=	0x00f5
                           0000F6   380 _ADC_CHAN	=	0x00f6
                           0000A6   381 _LED_COMMON	=	0x00a6
                           0000A7   382 _LED_PWM_OE	=	0x00a7
                           00C7C6   383 _LED_DMA	=	0xc7c6
                           0000C6   384 _LED_DMA_L	=	0x00c6
                           0000C7   385 _LED_DMA_H	=	0x00c7
                           0000F7   386 _LED_STATUS	=	0x00f7
                           0000B3   387 _I2CX_INT	=	0x00b3
                           0000BB   388 _I2CS_INT_ST	=	0x00bb
                                    389 ;--------------------------------------------------------
                                    390 ; special function bits
                                    391 ;--------------------------------------------------------
                                    392 	.area RSEG    (ABS,DATA)
      000000                        393 	.org 0x0000
                           0000D7   394 _CY	=	0x00d7
                           0000D6   395 _AC	=	0x00d6
                           0000D5   396 _F0	=	0x00d5
                           0000D4   397 _RS1	=	0x00d4
                           0000D3   398 _RS0	=	0x00d3
                           0000D2   399 _OV	=	0x00d2
                           0000D1   400 _F1	=	0x00d1
                           0000D0   401 _P	=	0x00d0
                           0000AF   402 _EA	=	0x00af
                           0000AE   403 _E_DIS	=	0x00ae
                           0000AD   404 _ET2	=	0x00ad
                           0000AC   405 _ES	=	0x00ac
                           0000AB   406 _ET1	=	0x00ab
                           0000AA   407 _EX1	=	0x00aa
                           0000A9   408 _ET0	=	0x00a9
                           0000A8   409 _EX0	=	0x00a8
                           0000BF   410 _PH_FLAG	=	0x00bf
                           0000BE   411 _PL_FLAG	=	0x00be
                           0000BD   412 _PT2	=	0x00bd
                           0000BC   413 _PS	=	0x00bc
                           0000BB   414 _PT1	=	0x00bb
                           0000BA   415 _PX1	=	0x00ba
                           0000B9   416 _PT0	=	0x00b9
                           0000B8   417 _PX0	=	0x00b8
                           0000EF   418 _IE_WDOG	=	0x00ef
                           0000EE   419 _IE_GPIO	=	0x00ee
                           0000ED   420 _IE_PWM_I2C	=	0x00ed
                           0000EC   421 _IE_UART1	=	0x00ec
                           0000EB   422 _IE_ADC	=	0x00eb
                           0000E9   423 _IE_USB	=	0x00e9
                           0000E8   424 _IE_SPI0	=	0x00e8
                           000087   425 _P0_7	=	0x0087
                           000086   426 _P0_6	=	0x0086
                           000085   427 _P0_5	=	0x0085
                           000084   428 _P0_4	=	0x0084
                           000083   429 _P0_3	=	0x0083
                           000082   430 _P0_2	=	0x0082
                           000081   431 _P0_1	=	0x0081
                           000080   432 _P0_0	=	0x0080
                           000081   433 _SDA0	=	0x0081
                           000080   434 _SCL0	=	0x0080
                           000083   435 _TXD_	=	0x0083
                           000082   436 _RXD_	=	0x0082
                           000085   437 _AIN13	=	0x0085
                           000084   438 _AIN12	=	0x0084
                           000083   439 _AIN11	=	0x0083
                           000082   440 _AIN10	=	0x0082
                           000081   441 _AIN9	=	0x0081
                           000080   442 _AIN8	=	0x0080
                           000097   443 _P1_7	=	0x0097
                           000096   444 _P1_6	=	0x0096
                           000095   445 _P1_5	=	0x0095
                           000094   446 _P1_4	=	0x0094
                           000093   447 _P1_3	=	0x0093
                           000092   448 _P1_2	=	0x0092
                           000091   449 _P1_1	=	0x0091
                           000090   450 _P1_0	=	0x0090
                           000097   451 _TXD1_	=	0x0097
                           000096   452 _RXD1_	=	0x0096
                           000097   453 _SCK	=	0x0097
                           000096   454 _MISO	=	0x0096
                           000095   455 _MOSI	=	0x0095
                           000094   456 _SCS	=	0x0094
                           000092   457 _INT0_	=	0x0092
                           000091   458 _T2EX	=	0x0091
                           000091   459 _CAP2	=	0x0091
                           000090   460 _T2	=	0x0090
                           000090   461 _CAP1	=	0x0090
                           000097   462 _AIN7	=	0x0097
                           000096   463 _AIN6	=	0x0096
                           000095   464 _AIN5	=	0x0095
                           000094   465 _AIN4	=	0x0094
                           000093   466 _AIN3	=	0x0093
                           000092   467 _AIN2	=	0x0092
                           000091   468 _AIN1	=	0x0091
                           000090   469 _AIN0	=	0x0090
                           0000A7   470 _P2_7	=	0x00a7
                           0000A6   471 _P2_6	=	0x00a6
                           0000A5   472 _P2_5	=	0x00a5
                           0000A4   473 _P2_4	=	0x00a4
                           0000A3   474 _P2_3	=	0x00a3
                           0000A2   475 _P2_2	=	0x00a2
                           0000A1   476 _P2_1	=	0x00a1
                           0000A0   477 _P2_0	=	0x00a0
                           0000A7   478 _TXD1	=	0x00a7
                           0000A6   479 _RXD1	=	0x00a6
                           0000A5   480 _T2EX_	=	0x00a5
                           0000A5   481 _CAP2_	=	0x00a5
                           0000A4   482 _T2_	=	0x00a4
                           0000A4   483 _CAP1_	=	0x00a4
                           0000B7   484 _P3_7	=	0x00b7
                           0000B6   485 _P3_6	=	0x00b6
                           0000B5   486 _P3_5	=	0x00b5
                           0000B4   487 _P3_4	=	0x00b4
                           0000B3   488 _P3_3	=	0x00b3
                           0000B2   489 _P3_2	=	0x00b2
                           0000B1   490 _P3_1	=	0x00b1
                           0000B0   491 _P3_0	=	0x00b0
                           0000B7   492 _SCK1	=	0x00b7
                           0000B6   493 _MISO1	=	0x00b6
                           0000B5   494 _MOSI1	=	0x00b5
                           0000B5   495 _T1	=	0x00b5
                           0000B4   496 _T0	=	0x00b4
                           0000B3   497 _INT1	=	0x00b3
                           0000B2   498 _INT0	=	0x00b2
                           0000B1   499 _TXD	=	0x00b1
                           0000B0   500 _RXD	=	0x00b0
                           0000C6   501 _P4_6	=	0x00c6
                           0000C5   502 _P4_5	=	0x00c5
                           0000C4   503 _P4_4	=	0x00c4
                           0000C3   504 _P4_3	=	0x00c3
                           0000C2   505 _P4_2	=	0x00c2
                           0000C1   506 _P4_1	=	0x00c1
                           0000C0   507 _P4_0	=	0x00c0
                           00008F   508 _TF1	=	0x008f
                           00008E   509 _TR1	=	0x008e
                           00008D   510 _TF0	=	0x008d
                           00008C   511 _TR0	=	0x008c
                           00008B   512 _IE1	=	0x008b
                           00008A   513 _IT1	=	0x008a
                           000089   514 _IE0	=	0x0089
                           000088   515 _IT0	=	0x0088
                           00009F   516 _SM0	=	0x009f
                           00009E   517 _SM1	=	0x009e
                           00009D   518 _SM2	=	0x009d
                           00009C   519 _REN	=	0x009c
                           00009B   520 _TB8	=	0x009b
                           00009A   521 _RB8	=	0x009a
                           000099   522 _TI	=	0x0099
                           000098   523 _RI	=	0x0098
                           0000CF   524 _TF2	=	0x00cf
                           0000CF   525 _CAP1F	=	0x00cf
                           0000CE   526 _EXF2	=	0x00ce
                           0000CD   527 _RCLK	=	0x00cd
                           0000CC   528 _TCLK	=	0x00cc
                           0000CB   529 _EXEN2	=	0x00cb
                           0000CA   530 _TR2	=	0x00ca
                           0000C9   531 _C_T2	=	0x00c9
                           0000C8   532 _CP_RL2	=	0x00c8
                           0000FF   533 _S0_FST_ACT	=	0x00ff
                           0000FE   534 _S0_IF_OV	=	0x00fe
                           0000FD   535 _S0_IF_FIRST	=	0x00fd
                           0000FC   536 _S0_IF_BYTE	=	0x00fc
                           0000FB   537 _S0_FREE	=	0x00fb
                           0000FA   538 _S0_T_FIFO	=	0x00fa
                           0000F8   539 _S0_R_FIFO	=	0x00f8
                           0000F7   540 _ADC_START	=	0x00f7
                                    541 ;--------------------------------------------------------
                                    542 ; overlayable register banks
                                    543 ;--------------------------------------------------------
                                    544 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        545 	.ds 8
                                    546 ;--------------------------------------------------------
                                    547 ; internal ram data
                                    548 ;--------------------------------------------------------
                                    549 	.area DSEG    (DATA)
      000016                        550 _control_setup_sloc1_1_0:
      000016                        551 	.ds 1
      000017                        552 _control_setup_sloc3_1_0:
      000017                        553 	.ds 2
      000019                        554 _control_setup_sloc4_1_0:
      000019                        555 	.ds 2
      00001B                        556 _ak820_usb_send_sloc0_1_0:
      00001B                        557 	.ds 2
      00001D                        558 _ak820_usb_send_sloc1_1_0:
      00001D                        559 	.ds 1
      00001E                        560 _ak820_usb_raw_task_sloc0_1_0:
      00001E                        561 	.ds 2
                                    562 ;--------------------------------------------------------
                                    563 ; overlayable items in internal ram
                                    564 ;--------------------------------------------------------
                                    565 ;--------------------------------------------------------
                                    566 ; indirectly addressable internal ram data
                                    567 ;--------------------------------------------------------
                                    568 	.area ISEG    (DATA)
                                    569 ;--------------------------------------------------------
                                    570 ; absolute internal ram data
                                    571 ;--------------------------------------------------------
                                    572 	.area IABS    (ABS,DATA)
                                    573 	.area IABS    (ABS,DATA)
                                    574 ;--------------------------------------------------------
                                    575 ; bit data
                                    576 ;--------------------------------------------------------
                                    577 	.area BSEG    (BIT)
      000015                        578 _control_setup_valid_interface_10000_290:
      000015                        579 	.ds 1
      000016                        580 _control_setup_zero_index_10000_290:
      000016                        581 	.ds 1
      000017                        582 _control_setup_zero_value_10000_290:
      000017                        583 	.ds 1
      000018                        584 _control_setup_zero_length_10000_290:
      000018                        585 	.ds 1
      000019                        586 _control_setup_sloc0_1_0:
      000019                        587 	.ds 1
      00001A                        588 _control_setup_sloc2_1_0:
      00001A                        589 	.ds 1
      00001B                        590 _ak820_usb_try_send_sloc0_1_0:
      00001B                        591 	.ds 1
      00001C                        592 _ak820_usb_raw_task_sloc1_1_0:
      00001C                        593 	.ds 1
      00001D                        594 _ak820_usb_take_keyboard_reset_sloc0_1_0:
      00001D                        595 	.ds 1
                                    596 ;--------------------------------------------------------
                                    597 ; paged external ram data
                                    598 ;--------------------------------------------------------
                                    599 	.area PSEG    (PAG,XDATA)
                                    600 ;--------------------------------------------------------
                                    601 ; uninitialized external ram data
                                    602 ;--------------------------------------------------------
                                    603 	.area XSEG    (XDATA)
      00078F                        604 _D0SetupReqCode::
      00078F                        605 	.ds 1
      000790                        606 _D0SetupLen::
      000790                        607 	.ds 2
      000792                        608 _pD0Descr::
      000792                        609 	.ds 3
      000795                        610 _D0UsbConfig::
      000795                        611 	.ds 1
      000796                        612 _USB_EnumStatus::
      000796                        613 	.ds 1
      000797                        614 _USB_SleepStatus::
      000797                        615 	.ds 1
      000798                        616 _MCU_Sleep_Operate::
      000798                        617 	.ds 1
      000799                        618 _KB_USB_UpStatus::
      000799                        619 	.ds 1
      00079A                        620 _KB_USB_SetReport::
      00079A                        621 	.ds 1
      00079B                        622 _ak820_boot_stage::
      00079B                        623 	.ds 1
      00079C                        624 _ak820_main_heartbeat::
      00079C                        625 	.ds 1
      00079D                        626 _raw_state:
      00079D                        627 	.ds 1
      00079E                        628 _raw_buffer:
      00079E                        629 	.ds 32
      0007BE                        630 _raw_reply_without_nvm:
      0007BE                        631 	.ds 1
      0007BF                        632 _keyboard_reset:
      0007BF                        633 	.ds 1
      0007C0                        634 _input_snapshot:
      0007C0                        635 	.ds 52
      0007F4                        636 _control_phase:
      0007F4                        637 	.ds 1
      0007F5                        638 _output_kind:
      0007F5                        639 	.ds 1
      0007F6                        640 _output_report_id:
      0007F6                        641 	.ds 1
      0007F7                        642 _control_zlp:
      0007F7                        643 	.ds 1
      0007F8                        644 _control_pointer:
      0007F8                        645 	.ds 2
      0007FA                        646 _descriptor_select_PARM_2:
      0007FA                        647 	.ds 1
      0007FB                        648 _descriptor_select_PARM_3:
      0007FB                        649 	.ds 2
      0007FD                        650 _descriptor_select_type_10000_272:
      0007FD                        651 	.ds 1
      0007FE                        652 _control_setup_length_10000_290:
      0007FE                        653 	.ds 2
      000800                        654 _control_setup_offset_10000_290:
      000800                        655 	.ds 1
      000801                        656 _ak820_usb_send_PARM_2:
      000801                        657 	.ds 2
      000803                        658 _ak820_usb_send_PARM_3:
      000803                        659 	.ds 1
      000804                        660 _ak820_usb_send_endpoint_10000_426:
      000804                        661 	.ds 1
      000805                        662 _ak820_usb_send_offset_10000_427:
      000805                        663 	.ds 1
      000806                        664 _ak820_usb_try_send_PARM_2:
      000806                        665 	.ds 2
      000808                        666 _ak820_usb_try_send_PARM_3:
      000808                        667 	.ds 1
      000809                        668 _ak820_usb_try_send_endpoint_10000_447:
      000809                        669 	.ds 1
      00080A                        670 _ak820_usb_try_send_sent_10000_448:
      00080A                        671 	.ds 1
      00080B                        672 _ak820_usb_raw_send_PARM_2:
      00080B                        673 	.ds 1
      00080C                        674 _ak820_usb_raw_send_report_10000_463:
      00080C                        675 	.ds 3
      00080F                        676 _ak820_usb_raw_task_length_10000_468:
      00080F                        677 	.ds 1
                                    678 ;--------------------------------------------------------
                                    679 ; absolute external ram data
                                    680 ;--------------------------------------------------------
                                    681 	.area XABS    (ABS,XDATA)
                                    682 ;--------------------------------------------------------
                                    683 ; initialized external ram data
                                    684 ;--------------------------------------------------------
                                    685 	.area XISEG   (XDATA)
                                    686 	.area HOME    (CODE)
                                    687 	.area GSINIT0 (CODE)
                                    688 	.area GSINIT1 (CODE)
                                    689 	.area GSINIT2 (CODE)
                                    690 	.area GSINIT3 (CODE)
                                    691 	.area GSINIT4 (CODE)
                                    692 	.area GSINIT5 (CODE)
                                    693 	.area GSINIT  (CODE)
                                    694 	.area GSFINAL (CODE)
                                    695 	.area CSEG    (CODE)
                                    696 ;--------------------------------------------------------
                                    697 ; global & static initialisations
                                    698 ;--------------------------------------------------------
                                    699 	.area HOME    (CODE)
                                    700 	.area GSINIT  (CODE)
                                    701 	.area GSFINAL (CODE)
                                    702 	.area GSINIT  (CODE)
                                    703 ;--------------------------------------------------------
                                    704 ; Home
                                    705 ;--------------------------------------------------------
                                    706 	.area HOME    (CODE)
                                    707 	.area HOME    (CODE)
                                    708 ;--------------------------------------------------------
                                    709 ; code
                                    710 ;--------------------------------------------------------
                                    711 	.area CSEG    (CODE)
                                    712 ;------------------------------------------------------------
                                    713 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    714 ;------------------------------------------------------------
                                    715 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_45'
                                    716 ;------------------------------------------------------------
                                    717 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    718 ;	-----------------------------------------
                           000007   719 	ar7 = 0x07
                           000006   720 	ar6 = 0x06
                           000005   721 	ar5 = 0x05
                           000004   722 	ar4 = 0x04
                           000003   723 	ar3 = 0x03
                           000002   724 	ar2 = 0x02
                           000001   725 	ar1 = 0x01
                           000000   726 	ar0 = 0x00
                                    727 ;	 function raw_abort
                                    728 ;	-----------------------------------------
      005FE2                        729 _raw_abort:
                                    730 ;	tmk_core/protocol/ch555/usb_ak820.c:97: if (raw_state == RAW_WORK || raw_state == RAW_TX_ACTIVE ||
      005FE2 90 07 9D         [24]  731 	mov	dptr,#_raw_state
      005FE5 E0               [24]  732 	movx	a,@dptr
      005FE6 FF               [12]  733 	mov	r7,a
      005FE7 BF 03 02         [24]  734 	cjne	r7,#0x03,00130$
      005FEA 80 1C            [24]  735 	sjmp	00101$
      005FEC                        736 00130$:
      005FEC 90 07 9D         [24]  737 	mov	dptr,#_raw_state
      005FEF E0               [24]  738 	movx	a,@dptr
      005FF0 FF               [12]  739 	mov	r7,a
      005FF1 BF 04 02         [24]  740 	cjne	r7,#0x04,00131$
      005FF4 80 12            [24]  741 	sjmp	00101$
      005FF6                        742 00131$:
                                    743 ;	tmk_core/protocol/ch555/usb_ak820.c:98: raw_state == RAW_DRAINED || raw_state == RAW_CANCELLED)
      005FF6 90 07 9D         [24]  744 	mov	dptr,#_raw_state
      005FF9 E0               [24]  745 	movx	a,@dptr
      005FFA FF               [12]  746 	mov	r7,a
      005FFB BF 06 02         [24]  747 	cjne	r7,#0x06,00132$
      005FFE 80 08            [24]  748 	sjmp	00101$
      006000                        749 00132$:
      006000 90 07 9D         [24]  750 	mov	dptr,#_raw_state
      006003 E0               [24]  751 	movx	a,@dptr
      006004 FF               [12]  752 	mov	r7,a
      006005 BF 07 08         [24]  753 	cjne	r7,#0x07,00102$
      006008                        754 00101$:
                                    755 ;	tmk_core/protocol/ch555/usb_ak820.c:99: raw_state = RAW_CANCELLED;
      006008 90 07 9D         [24]  756 	mov	dptr,#_raw_state
      00600B 74 07            [12]  757 	mov	a,#0x07
      00600D F0               [24]  758 	movx	@dptr,a
      00600E 80 05            [24]  759 	sjmp	00103$
      006010                        760 00102$:
                                    761 ;	tmk_core/protocol/ch555/usb_ak820.c:101: raw_state = RAW_IDLE;
      006010 90 07 9D         [24]  762 	mov	dptr,#_raw_state
      006013 E4               [12]  763 	clr	a
      006014 F0               [24]  764 	movx	@dptr,a
      006015                        765 00103$:
                                    766 ;	tmk_core/protocol/ch555/usb_ak820.c:102: output_kind = OUTPUT_NONE;
      006015 90 07 F5         [24]  767 	mov	dptr,#_output_kind
      006018 E4               [12]  768 	clr	a
      006019 F0               [24]  769 	movx	@dptr,a
                                    770 ;	tmk_core/protocol/ch555/usb_ak820.c:103: }
      00601A 22               [24]  771 	ret
                                    772 ;------------------------------------------------------------
                                    773 ;Allocation info for local variables in function 'raw_complete'
                                    774 ;------------------------------------------------------------
                                    775 ;	tmk_core/protocol/ch555/usb_ak820.c:105: static void raw_complete(void) {
                                    776 ;	-----------------------------------------
                                    777 ;	 function raw_complete
                                    778 ;	-----------------------------------------
      00601B                        779 _raw_complete:
                                    780 ;	tmk_core/protocol/ch555/usb_ak820.c:106: if (raw_state == RAW_TX_ACTIVE) raw_state = RAW_DRAINED;
      00601B 90 07 9D         [24]  781 	mov	dptr,#_raw_state
      00601E E0               [24]  782 	movx	a,@dptr
      00601F FF               [12]  783 	mov	r7,a
      006020 BF 04 07         [24]  784 	cjne	r7,#0x04,00104$
      006023 90 07 9D         [24]  785 	mov	dptr,#_raw_state
      006026 74 06            [12]  786 	mov	a,#0x06
      006028 F0               [24]  787 	movx	@dptr,a
      006029 22               [24]  788 	ret
      00602A                        789 00104$:
                                    790 ;	tmk_core/protocol/ch555/usb_ak820.c:107: else if (raw_state == RAW_TX_WAIT) raw_state = RAW_IDLE;
      00602A 90 07 9D         [24]  791 	mov	dptr,#_raw_state
      00602D E0               [24]  792 	movx	a,@dptr
      00602E FF               [12]  793 	mov	r7,a
      00602F BF 05 05         [24]  794 	cjne	r7,#0x05,00106$
      006032 90 07 9D         [24]  795 	mov	dptr,#_raw_state
      006035 E4               [12]  796 	clr	a
      006036 F0               [24]  797 	movx	@dptr,a
      006037                        798 00106$:
                                    799 ;	tmk_core/protocol/ch555/usb_ak820.c:108: }
      006037 22               [24]  800 	ret
                                    801 ;------------------------------------------------------------
                                    802 ;Allocation info for local variables in function 'endpoints_reset'
                                    803 ;------------------------------------------------------------
                                    804 ;i             Allocated with name '_endpoints_reset_i_10000_262'
                                    805 ;------------------------------------------------------------
                                    806 ;	tmk_core/protocol/ch555/usb_ak820.c:110: static void endpoints_reset(void) {
                                    807 ;	-----------------------------------------
                                    808 ;	 function endpoints_reset
                                    809 ;	-----------------------------------------
      006038                        810 _endpoints_reset:
                                    811 ;	tmk_core/protocol/ch555/usb_ak820.c:113: ak820_os_indicator_mode = AK820_OS_NORMAL;
      006038 90 05 AA         [24]  812 	mov	dptr,#_ak820_os_indicator_mode
      00603B E4               [12]  813 	clr	a
      00603C F0               [24]  814 	movx	@dptr,a
                                    815 ;	tmk_core/protocol/ch555/usb_ak820.c:116: D0_EP_MOD = bUX_DEV_EN;
      00603D 90 22 0C         [24]  816 	mov	dptr,#0x220c
      006040 04               [12]  817 	inc	a
      006041 F0               [24]  818 	movx	@dptr,a
                                    819 ;	tmk_core/protocol/ch555/usb_ak820.c:117: D0_EP1RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      006042 F5 82            [12]  820 	mov	dpl,a
      006044 74 12            [12]  821 	mov	a,#0x12
      006046 F0               [24]  822 	movx	@dptr,a
                                    823 ;	tmk_core/protocol/ch555/usb_ak820.c:118: D0_EP2RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      006047 A3               [24]  824 	inc	dptr
      006048 F0               [24]  825 	movx	@dptr,a
                                    826 ;	tmk_core/protocol/ch555/usb_ak820.c:119: D0_EP3RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      006049 A3               [24]  827 	inc	dptr
      00604A F0               [24]  828 	movx	@dptr,a
                                    829 ;	tmk_core/protocol/ch555/usb_ak820.c:120: D0_EP1T_L = D0_EP2T_L = D0_EP3T_L = 0;
      00604B 90 22 0B         [24]  830 	mov	dptr,#0x220b
      00604E E4               [12]  831 	clr	a
      00604F F0               [24]  832 	movx	@dptr,a
      006050 15 82            [12]  833 	dec	dpl
      006052 F0               [24]  834 	movx	@dptr,a
      006053 15 82            [12]  835 	dec	dpl
      006055 F0               [24]  836 	movx	@dptr,a
                                    837 ;	tmk_core/protocol/ch555/usb_ak820.c:121: for (i = 0; i < SNAPSHOT_SIZE; ++i) input_snapshot[i] = 0;
      006056 FF               [12]  838 	mov	r7,a
      006057                        839 00103$:
      006057 EF               [12]  840 	mov	a,r7
      006058 24 C0            [12]  841 	add	a, #_input_snapshot
      00605A F5 82            [12]  842 	mov	dpl,a
      00605C E4               [12]  843 	clr	a
      00605D 34 07            [12]  844 	addc	a, #(_input_snapshot >> 8)
      00605F F5 83            [12]  845 	mov	dph,a
      006061 E4               [12]  846 	clr	a
      006062 F0               [24]  847 	movx	@dptr,a
      006063 0F               [12]  848 	inc	r7
      006064 BF 34 00         [24]  849 	cjne	r7,#0x34,00139$
      006067                        850 00139$:
      006067 40 EE            [24]  851 	jc	00103$
                                    852 ;	tmk_core/protocol/ch555/usb_ak820.c:122: input_snapshot[SNAPSHOT_NKRO] = REPORT_ID_NKRO;
      006069 90 07 C8         [24]  853 	mov	dptr,#(_input_snapshot + 0x0008)
      00606C 74 06            [12]  854 	mov	a,#0x06
      00606E F0               [24]  855 	movx	@dptr,a
                                    856 ;	tmk_core/protocol/ch555/usb_ak820.c:124: input_snapshot[SNAPSHOT_MOUSE] = REPORT_ID_MOUSE;
      00606F 90 07 E8         [24]  857 	mov	dptr,#(_input_snapshot + 0x0028)
      006072 74 02            [12]  858 	mov	a,#0x02
      006074 F0               [24]  859 	movx	@dptr,a
                                    860 ;	tmk_core/protocol/ch555/usb_ak820.c:126: input_snapshot[SNAPSHOT_SYSTEM] = REPORT_ID_SYSTEM;
      006075 90 07 EE         [24]  861 	mov	dptr,#(_input_snapshot + 0x002e)
      006078 04               [12]  862 	inc	a
      006079 F0               [24]  863 	movx	@dptr,a
                                    864 ;	tmk_core/protocol/ch555/usb_ak820.c:127: input_snapshot[SNAPSHOT_CONSUMER] = REPORT_ID_CONSUMER;
      00607A 90 07 F1         [24]  865 	mov	dptr,#(_input_snapshot + 0x0031)
      00607D 04               [12]  866 	inc	a
      00607E F0               [24]  867 	movx	@dptr,a
                                    868 ;	tmk_core/protocol/ch555/usb_ak820.c:128: for (i = 0; i < RAW_EPSIZE; ++i) pUSB_BUF_DEV0[UX_EP3_ADDR + i] = 0;
      00607F 7F 00            [12]  869 	mov	r7,#0x00
      006081                        870 00105$:
      006081 8F 06            [24]  871 	mov	ar6,r7
      006083 74 C0            [12]  872 	mov	a,#0xc0
      006085 2E               [12]  873 	add	a, r6
      006086 F5 82            [12]  874 	mov	dpl,a
      006088 74 10            [12]  875 	mov	a,#0x10
      00608A 24 00            [12]  876 	add	a, #0x00
      00608C F5 83            [12]  877 	mov	dph,a
      00608E E4               [12]  878 	clr	a
      00608F F0               [24]  879 	movx	@dptr,a
      006090 0F               [12]  880 	inc	r7
      006091 BF 20 00         [24]  881 	cjne	r7,#0x20,00141$
      006094                        882 00141$:
      006094 40 EB            [24]  883 	jc	00105$
                                    884 ;	tmk_core/protocol/ch555/usb_ak820.c:129: raw_abort();
                                    885 ;	tmk_core/protocol/ch555/usb_ak820.c:130: }
      006096 02 5F E2         [24]  886 	ljmp	_raw_abort
                                    887 ;------------------------------------------------------------
                                    888 ;Allocation info for local variables in function 'control_stall'
                                    889 ;------------------------------------------------------------
                                    890 ;	tmk_core/protocol/ch555/usb_ak820.c:132: static void control_stall(void) {
                                    891 ;	-----------------------------------------
                                    892 ;	 function control_stall
                                    893 ;	-----------------------------------------
      006099                        894 _control_stall:
                                    895 ;	tmk_core/protocol/ch555/usb_ak820.c:133: if (raw_state == RAW_RX) raw_state = RAW_IDLE;
      006099 90 07 9D         [24]  896 	mov	dptr,#_raw_state
      00609C E0               [24]  897 	movx	a,@dptr
      00609D FF               [12]  898 	mov	r7,a
      00609E BF 01 05         [24]  899 	cjne	r7,#0x01,00102$
      0060A1 90 07 9D         [24]  900 	mov	dptr,#_raw_state
      0060A4 E4               [12]  901 	clr	a
      0060A5 F0               [24]  902 	movx	@dptr,a
      0060A6                        903 00102$:
                                    904 ;	tmk_core/protocol/ch555/usb_ak820.c:134: output_kind = OUTPUT_NONE;
      0060A6 90 07 F5         [24]  905 	mov	dptr,#_output_kind
      0060A9 E4               [12]  906 	clr	a
      0060AA F0               [24]  907 	movx	@dptr,a
                                    908 ;	tmk_core/protocol/ch555/usb_ak820.c:135: control_phase = CTRL_IDLE;
      0060AB 90 07 F4         [24]  909 	mov	dptr,#_control_phase
      0060AE F0               [24]  910 	movx	@dptr,a
                                    911 ;	tmk_core/protocol/ch555/usb_ak820.c:136: D0SetupReqCode = 0xff;
      0060AF 90 07 8F         [24]  912 	mov	dptr,#_D0SetupReqCode
      0060B2 14               [12]  913 	dec	a
      0060B3 F0               [24]  914 	movx	@dptr,a
                                    915 ;	tmk_core/protocol/ch555/usb_ak820.c:138: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_STALL | UEP_T_RES_STALL;
      0060B4 90 22 00         [24]  916 	mov	dptr,#0x2200
      0060B7 74 CF            [12]  917 	mov	a,#0xcf
      0060B9 F0               [24]  918 	movx	@dptr,a
                                    919 ;	tmk_core/protocol/ch555/usb_ak820.c:139: }
      0060BA 22               [24]  920 	ret
                                    921 ;------------------------------------------------------------
                                    922 ;Allocation info for local variables in function 'control_next'
                                    923 ;------------------------------------------------------------
                                    924 ;i             Allocated with name '_control_next_i_10000_269'
                                    925 ;length        Allocated with name '_control_next_length_10000_269'
                                    926 ;------------------------------------------------------------
                                    927 ;	tmk_core/protocol/ch555/usb_ak820.c:141: static void control_next(void) {
                                    928 ;	-----------------------------------------
                                    929 ;	 function control_next
                                    930 ;	-----------------------------------------
      0060BB                        931 _control_next:
                                    932 ;	tmk_core/protocol/ch555/usb_ak820.c:143: uint8_t length = D0SetupLen > DEF_ENDP0_SIZE ? DEF_ENDP0_SIZE : D0SetupLen;
      0060BB 90 07 90         [24]  933 	mov	dptr,#_D0SetupLen
      0060BE E0               [24]  934 	movx	a,@dptr
      0060BF FE               [12]  935 	mov	r6,a
      0060C0 A3               [24]  936 	inc	dptr
      0060C1 E0               [24]  937 	movx	a,@dptr
      0060C2 FF               [12]  938 	mov	r7,a
      0060C3 C3               [12]  939 	clr	c
      0060C4 74 40            [12]  940 	mov	a,#0x40
      0060C6 9E               [12]  941 	subb	a,r6
      0060C7 E4               [12]  942 	clr	a
      0060C8 9F               [12]  943 	subb	a,r7
      0060C9 50 04            [24]  944 	jnc	00109$
                                    945 ;	free result
      0060CB 7E 40            [12]  946 	mov	r6,#0x40
      0060CD 80 07            [24]  947 	sjmp	00110$
      0060CF                        948 00109$:
      0060CF 90 07 90         [24]  949 	mov	dptr,#_D0SetupLen
      0060D2 E0               [24]  950 	movx	a,@dptr
      0060D3 FE               [12]  951 	mov	r6,a
      0060D4 A3               [24]  952 	inc	dptr
      0060D5 E0               [24]  953 	movx	a,@dptr
      0060D6                        954 00110$:
                                    955 ;	tmk_core/protocol/ch555/usb_ak820.c:144: for (i = 0; i < length; ++i) pD0_EP0_BUF[i] = *control_pointer++;
      0060D6 7F 00            [12]  956 	mov	r7,#0x00
      0060D8                        957 00105$:
      0060D8 C3               [12]  958 	clr	c
      0060D9 EF               [12]  959 	mov	a,r7
      0060DA 9E               [12]  960 	subb	a,r6
      0060DB 50 2A            [24]  961 	jnc	00101$
      0060DD 8F 04            [24]  962 	mov	ar4,r7
      0060DF 74 10            [12]  963 	mov	a,#0x10
      0060E1 24 00            [12]  964 	add	a, #0x00
      0060E3 FD               [12]  965 	mov	r5,a
      0060E4 90 07 F8         [24]  966 	mov	dptr,#_control_pointer
      0060E7 E0               [24]  967 	movx	a,@dptr
      0060E8 FA               [12]  968 	mov	r2,a
      0060E9 A3               [24]  969 	inc	dptr
      0060EA E0               [24]  970 	movx	a,@dptr
      0060EB FB               [12]  971 	mov	r3,a
      0060EC 8A 82            [24]  972 	mov	dpl,r2
      0060EE 8B 83            [24]  973 	mov	dph,r3
      0060F0 E4               [12]  974 	clr	a
      0060F1 93               [24]  975 	movc	a,@a+dptr
      0060F2 F9               [12]  976 	mov	r1,a
      0060F3 90 07 F8         [24]  977 	mov	dptr,#_control_pointer
      0060F6 74 01            [12]  978 	mov	a,#0x01
      0060F8 2A               [12]  979 	add	a, r2
      0060F9 F0               [24]  980 	movx	@dptr,a
      0060FA E4               [12]  981 	clr	a
      0060FB 3B               [12]  982 	addc	a, r3
      0060FC A3               [24]  983 	inc	dptr
      0060FD F0               [24]  984 	movx	@dptr,a
      0060FE 8C 82            [24]  985 	mov	dpl,r4
      006100 8D 83            [24]  986 	mov	dph,r5
      006102 E9               [12]  987 	mov	a,r1
      006103 F0               [24]  988 	movx	@dptr,a
      006104 0F               [12]  989 	inc	r7
      006105 80 D1            [24]  990 	sjmp	00105$
      006107                        991 00101$:
                                    992 ;	tmk_core/protocol/ch555/usb_ak820.c:145: D0SetupLen -= length;
      006107 8E 05            [24]  993 	mov	ar5,r6
      006109 7F 00            [12]  994 	mov	r7,#0x00
      00610B 90 07 90         [24]  995 	mov	dptr,#_D0SetupLen
      00610E E0               [24]  996 	movx	a,@dptr
      00610F FB               [12]  997 	mov	r3,a
      006110 A3               [24]  998 	inc	dptr
      006111 E0               [24]  999 	movx	a,@dptr
      006112 FC               [12] 1000 	mov	r4,a
      006113 EB               [12] 1001 	mov	a,r3
      006114 C3               [12] 1002 	clr	c
      006115 9D               [12] 1003 	subb	a,r5
      006116 FB               [12] 1004 	mov	r3,a
      006117 EC               [12] 1005 	mov	a,r4
      006118 9F               [12] 1006 	subb	a,r7
      006119 FC               [12] 1007 	mov	r4,a
      00611A 90 07 90         [24] 1008 	mov	dptr,#_D0SetupLen
      00611D EB               [12] 1009 	mov	a,r3
      00611E F0               [24] 1010 	movx	@dptr,a
      00611F EC               [12] 1011 	mov	a,r4
      006120 A3               [24] 1012 	inc	dptr
      006121 F0               [24] 1013 	movx	@dptr,a
                                   1014 ;	tmk_core/protocol/ch555/usb_ak820.c:146: if (!length) control_zlp = 0;
      006122 EE               [12] 1015 	mov	a,r6
      006123 70 05            [24] 1016 	jnz	00103$
      006125 90 07 F7         [24] 1017 	mov	dptr,#_control_zlp
      006128 E4               [12] 1018 	clr	a
      006129 F0               [24] 1019 	movx	@dptr,a
      00612A                       1020 00103$:
                                   1021 ;	tmk_core/protocol/ch555/usb_ak820.c:147: D0_EP0T_L = length;
      00612A 90 22 08         [24] 1022 	mov	dptr,#0x2208
      00612D EE               [12] 1023 	mov	a,r6
      00612E F0               [24] 1024 	movx	@dptr,a
                                   1025 ;	tmk_core/protocol/ch555/usb_ak820.c:148: D0_EP0RES = (D0_EP0RES & (bUEP_T_TOG | bUEP_R_TOG)) | UEP_T_RES_ACK | UEP_R_RES_ACK;
      00612F 90 22 00         [24] 1026 	mov	dptr,#0x2200
      006132 E0               [24] 1027 	movx	a,@dptr
      006133 54 C0            [12] 1028 	anl	a,#0xc0
      006135 F0               [24] 1029 	movx	@dptr,a
                                   1030 ;	tmk_core/protocol/ch555/usb_ak820.c:149: }
      006136 22               [24] 1031 	ret
                                   1032 ;------------------------------------------------------------
                                   1033 ;Allocation info for local variables in function 'descriptor_select'
                                   1034 ;------------------------------------------------------------
                                   1035 ;index         Allocated with name '_descriptor_select_PARM_2'
                                   1036 ;interface     Allocated with name '_descriptor_select_PARM_3'
                                   1037 ;type          Allocated with name '_descriptor_select_type_10000_272'
                                   1038 ;hid           Allocated with name '_descriptor_select_hid_30000_285'
                                   1039 ;------------------------------------------------------------
                                   1040 ;	tmk_core/protocol/ch555/usb_ak820.c:166: static uint16_t descriptor_select(uint8_t type, uint8_t index, uint16_t interface) {
                                   1041 ;	-----------------------------------------
                                   1042 ;	 function descriptor_select
                                   1043 ;	-----------------------------------------
      006137                       1044 _descriptor_select:
      006137 E5 82            [12] 1045 	mov	a,dpl
      006139 90 07 FD         [24] 1046 	mov	dptr,#_descriptor_select_type_10000_272
      00613C F0               [24] 1047 	movx	@dptr,a
                                   1048 ;	tmk_core/protocol/ch555/usb_ak820.c:167: if (type == USB_DESCR_TYP_DEVICE && !index && !interface) {
      00613D E0               [24] 1049 	movx	a,@dptr
      00613E FF               [12] 1050 	mov	r7,a
      00613F BF 01 20         [24] 1051 	cjne	r7,#0x01,00102$
      006142 90 07 FA         [24] 1052 	mov	dptr,#_descriptor_select_PARM_2
      006145 E0               [24] 1053 	movx	a,@dptr
      006146 70 1A            [24] 1054 	jnz	00102$
      006148 90 07 FB         [24] 1055 	mov	dptr,#_descriptor_select_PARM_3
      00614B E0               [24] 1056 	movx	a,@dptr
      00614C F5 F0            [12] 1057 	mov	b,a
      00614E A3               [24] 1058 	inc	dptr
      00614F E0               [24] 1059 	movx	a,@dptr
      006150 45 F0            [12] 1060 	orl	a,b
      006152 70 0E            [24] 1061 	jnz	00102$
                                   1062 ;	tmk_core/protocol/ch555/usb_ak820.c:168: control_pointer = (const uint8_t __code *)&DeviceDescriptor;
      006154 90 07 F8         [24] 1063 	mov	dptr,#_control_pointer
      006157 74 1C            [12] 1064 	mov	a,#_DeviceDescriptor
      006159 F0               [24] 1065 	movx	@dptr,a
      00615A 74 C6            [12] 1066 	mov	a,#(_DeviceDescriptor >> 8)
      00615C A3               [24] 1067 	inc	dptr
      00615D F0               [24] 1068 	movx	@dptr,a
                                   1069 ;	tmk_core/protocol/ch555/usb_ak820.c:169: return sizeof(DeviceDescriptor);
      00615E 90 00 12         [24] 1070 	mov	dptr,#0x0012
      006161 22               [24] 1071 	ret
      006162                       1072 00102$:
                                   1073 ;	tmk_core/protocol/ch555/usb_ak820.c:171: if (type == USB_DESCR_TYP_CONFIG && !index && !interface) {
      006162 90 07 FD         [24] 1074 	mov	dptr,#_descriptor_select_type_10000_272
      006165 E0               [24] 1075 	movx	a,@dptr
      006166 FF               [12] 1076 	mov	r7,a
      006167 BF 02 20         [24] 1077 	cjne	r7,#0x02,00106$
      00616A 90 07 FA         [24] 1078 	mov	dptr,#_descriptor_select_PARM_2
      00616D E0               [24] 1079 	movx	a,@dptr
      00616E 70 1A            [24] 1080 	jnz	00106$
      006170 90 07 FB         [24] 1081 	mov	dptr,#_descriptor_select_PARM_3
      006173 E0               [24] 1082 	movx	a,@dptr
      006174 F5 F0            [12] 1083 	mov	b,a
      006176 A3               [24] 1084 	inc	dptr
      006177 E0               [24] 1085 	movx	a,@dptr
      006178 45 F0            [12] 1086 	orl	a,b
      00617A 70 0E            [24] 1087 	jnz	00106$
                                   1088 ;	tmk_core/protocol/ch555/usb_ak820.c:172: control_pointer = (const uint8_t __code *)&ConfigurationDescriptor;
      00617C 90 07 F8         [24] 1089 	mov	dptr,#_control_pointer
      00617F 74 2E            [12] 1090 	mov	a,#_ConfigurationDescriptor
      006181 F0               [24] 1091 	movx	@dptr,a
      006182 74 C6            [12] 1092 	mov	a,#(_ConfigurationDescriptor >> 8)
      006184 A3               [24] 1093 	inc	dptr
      006185 F0               [24] 1094 	movx	@dptr,a
                                   1095 ;	tmk_core/protocol/ch555/usb_ak820.c:173: return sizeof(ConfigurationDescriptor);
      006186 90 00 54         [24] 1096 	mov	dptr,#0x0054
      006189 22               [24] 1097 	ret
      00618A                       1098 00106$:
                                   1099 ;	tmk_core/protocol/ch555/usb_ak820.c:175: if (type == USB_DESCR_TYP_STRING) {
      00618A 90 07 FD         [24] 1100 	mov	dptr,#_descriptor_select_type_10000_272
      00618D E0               [24] 1101 	movx	a,@dptr
      00618E FF               [12] 1102 	mov	r7,a
      00618F BF 03 02         [24] 1103 	cjne	r7,#0x03,00238$
      006192 80 03            [24] 1104 	sjmp	00239$
      006194                       1105 00238$:
      006194 02 62 2E         [24] 1106 	ljmp	00119$
      006197                       1107 00239$:
                                   1108 ;	tmk_core/protocol/ch555/usb_ak820.c:176: if (interface != 0 && interface != 0x0409) return 0;
      006197 90 07 FB         [24] 1109 	mov	dptr,#_descriptor_select_PARM_3
      00619A E0               [24] 1110 	movx	a,@dptr
      00619B FD               [12] 1111 	mov	r5,a
      00619C A3               [24] 1112 	inc	dptr
      00619D E0               [24] 1113 	movx	a,@dptr
      00619E FE               [12] 1114 	mov	r6,a
      00619F 90 07 FB         [24] 1115 	mov	dptr,#_descriptor_select_PARM_3
      0061A2 E0               [24] 1116 	movx	a,@dptr
      0061A3 F5 F0            [12] 1117 	mov	b,a
      0061A5 A3               [24] 1118 	inc	dptr
      0061A6 E0               [24] 1119 	movx	a,@dptr
      0061A7 45 F0            [12] 1120 	orl	a,b
      0061A9 60 0C            [24] 1121 	jz	00110$
      0061AB BD 09 05         [24] 1122 	cjne	r5,#0x09,00241$
      0061AE BE 04 02         [24] 1123 	cjne	r6,#0x04,00241$
      0061B1 80 04            [24] 1124 	sjmp	00110$
      0061B3                       1125 00241$:
      0061B3 90 00 00         [24] 1126 	mov	dptr,#0x0000
      0061B6 22               [24] 1127 	ret
      0061B7                       1128 00110$:
                                   1129 ;	tmk_core/protocol/ch555/usb_ak820.c:177: switch (index) {
      0061B7 90 07 FA         [24] 1130 	mov	dptr,#_descriptor_select_PARM_2
      0061BA E0               [24] 1131 	movx	a,@dptr
      0061BB FE               [12] 1132 	mov  r6,a
      0061BC 24 FC            [12] 1133 	add	a,#0xff - 0x03
      0061BE 40 6A            [24] 1134 	jc	00116$
                                   1135 ;	free result
      0061C0 EE               [12] 1136 	mov	a,r6
      0061C1 2E               [12] 1137 	add	a,r6
                                   1138 ;	tmk_core/protocol/ch555/usb_ak820.c:178: case 0: control_pointer = (const uint8_t __code *)&LanguageString; return LanguageString.Header.Size;
      0061C2 90 61 C6         [24] 1139 	mov	dptr,#00243$
      0061C5 73               [24] 1140 	jmp	@a+dptr
      0061C6                       1141 00243$:
      0061C6 80 06            [24] 1142 	sjmp	00112$
      0061C8 80 1B            [24] 1143 	sjmp	00113$
      0061CA 80 30            [24] 1144 	sjmp	00114$
      0061CC 80 45            [24] 1145 	sjmp	00115$
      0061CE                       1146 00112$:
      0061CE 90 07 F8         [24] 1147 	mov	dptr,#_control_pointer
      0061D1 74 82            [12] 1148 	mov	a,#_LanguageString
      0061D3 F0               [24] 1149 	movx	@dptr,a
      0061D4 74 C6            [12] 1150 	mov	a,#(_LanguageString >> 8)
      0061D6 A3               [24] 1151 	inc	dptr
      0061D7 F0               [24] 1152 	movx	@dptr,a
      0061D8 90 C6 82         [24] 1153 	mov	dptr,#_LanguageString
      0061DB E4               [12] 1154 	clr	a
      0061DC 93               [24] 1155 	movc	a,@a+dptr
      0061DD FE               [12] 1156 	mov	r6,a
      0061DE 7D 00            [12] 1157 	mov	r5,#0x00
      0061E0 8E 82            [24] 1158 	mov	dpl, r6
      0061E2 8D 83            [24] 1159 	mov	dph, r5
      0061E4 22               [24] 1160 	ret
                                   1161 ;	tmk_core/protocol/ch555/usb_ak820.c:179: case 1: control_pointer = (const uint8_t __code *)&ManufacturerString; return ManufacturerString.Header.Size;
      0061E5                       1162 00113$:
      0061E5 90 07 F8         [24] 1163 	mov	dptr,#_control_pointer
      0061E8 74 86            [12] 1164 	mov	a,#_ManufacturerString
      0061EA F0               [24] 1165 	movx	@dptr,a
      0061EB 74 C6            [12] 1166 	mov	a,#(_ManufacturerString >> 8)
      0061ED A3               [24] 1167 	inc	dptr
      0061EE F0               [24] 1168 	movx	@dptr,a
      0061EF 90 C6 86         [24] 1169 	mov	dptr,#_ManufacturerString
      0061F2 E4               [12] 1170 	clr	a
      0061F3 93               [24] 1171 	movc	a,@a+dptr
      0061F4 FE               [12] 1172 	mov	r6,a
      0061F5 7D 00            [12] 1173 	mov	r5,#0x00
      0061F7 8E 82            [24] 1174 	mov	dpl, r6
      0061F9 8D 83            [24] 1175 	mov	dph, r5
      0061FB 22               [24] 1176 	ret
                                   1177 ;	tmk_core/protocol/ch555/usb_ak820.c:180: case 2: control_pointer = (const uint8_t __code *)&ProductString; return ProductString.Header.Size;
      0061FC                       1178 00114$:
      0061FC 90 07 F8         [24] 1179 	mov	dptr,#_control_pointer
      0061FF 74 94            [12] 1180 	mov	a,#_ProductString
      006201 F0               [24] 1181 	movx	@dptr,a
      006202 74 C6            [12] 1182 	mov	a,#(_ProductString >> 8)
      006204 A3               [24] 1183 	inc	dptr
      006205 F0               [24] 1184 	movx	@dptr,a
      006206 90 C6 94         [24] 1185 	mov	dptr,#_ProductString
      006209 E4               [12] 1186 	clr	a
      00620A 93               [24] 1187 	movc	a,@a+dptr
      00620B FE               [12] 1188 	mov	r6,a
      00620C 7D 00            [12] 1189 	mov	r5,#0x00
      00620E 8E 82            [24] 1190 	mov	dpl, r6
      006210 8D 83            [24] 1191 	mov	dph, r5
      006212 22               [24] 1192 	ret
                                   1193 ;	tmk_core/protocol/ch555/usb_ak820.c:182: case 3: control_pointer = (const uint8_t __code *)&SerialNumberString; return SerialNumberString.Header.Size;
      006213                       1194 00115$:
      006213 90 07 F8         [24] 1195 	mov	dptr,#_control_pointer
      006216 74 CC            [12] 1196 	mov	a,#_SerialNumberString
      006218 F0               [24] 1197 	movx	@dptr,a
      006219 74 C6            [12] 1198 	mov	a,#(_SerialNumberString >> 8)
      00621B A3               [24] 1199 	inc	dptr
      00621C F0               [24] 1200 	movx	@dptr,a
      00621D 90 C6 CC         [24] 1201 	mov	dptr,#_SerialNumberString
      006220 E4               [12] 1202 	clr	a
      006221 93               [24] 1203 	movc	a,@a+dptr
      006222 FE               [12] 1204 	mov	r6,a
      006223 7D 00            [12] 1205 	mov	r5,#0x00
      006225 8E 82            [24] 1206 	mov	dpl, r6
      006227 8D 83            [24] 1207 	mov	dph, r5
      006229 22               [24] 1208 	ret
                                   1209 ;	tmk_core/protocol/ch555/usb_ak820.c:184: default: return 0;
      00622A                       1210 00116$:
      00622A 90 00 00         [24] 1211 	mov	dptr,#0x0000
      00622D 22               [24] 1212 	ret
                                   1213 ;	tmk_core/protocol/ch555/usb_ak820.c:185: }
      00622E                       1214 00119$:
                                   1215 ;	tmk_core/protocol/ch555/usb_ak820.c:187: if (index || interface >= TOTAL_INTERFACES) return 0;
      00622E 90 07 FA         [24] 1216 	mov	dptr,#_descriptor_select_PARM_2
      006231 E0               [24] 1217 	movx	a,@dptr
      006232 70 11            [24] 1218 	jnz	00120$
      006234 90 07 FB         [24] 1219 	mov	dptr,#_descriptor_select_PARM_3
      006237 E0               [24] 1220 	movx	a,@dptr
      006238 FD               [12] 1221 	mov	r5,a
      006239 A3               [24] 1222 	inc	dptr
      00623A E0               [24] 1223 	movx	a,@dptr
      00623B FE               [12] 1224 	mov	r6,a
      00623C C3               [12] 1225 	clr	c
      00623D ED               [12] 1226 	mov	a,r5
      00623E 94 03            [12] 1227 	subb	a,#0x03
      006240 EE               [12] 1228 	mov	a,r6
      006241 94 00            [12] 1229 	subb	a,#0x00
      006243 40 04            [24] 1230 	jc	00121$
      006245                       1231 00120$:
      006245 90 00 00         [24] 1232 	mov	dptr,#0x0000
      006248 22               [24] 1233 	ret
      006249                       1234 00121$:
                                   1235 ;	tmk_core/protocol/ch555/usb_ak820.c:188: if (type == USB_DESCR_TYP_REPORT || type == USB_DESCR_TYP_HID) {
      006249 BF 22 02         [24] 1236 	cjne	r7,#0x22,00246$
      00624C 80 03            [24] 1237 	sjmp	00127$
      00624E                       1238 00246$:
      00624E BF 21 5D         [24] 1239 	cjne	r7,#0x21,00128$
      006251                       1240 00127$:
                                   1241 ;	tmk_core/protocol/ch555/usb_ak820.c:189: const USB_HID_Descriptor_HID_t __code *hid = interface_descriptors[(uint8_t)interface].hid;
      006251 ED               [12] 1242 	mov	a,r5
      006252 75 F0 04         [24] 1243 	mov	b,#0x04
      006255 A4               [48] 1244 	mul	ab
      006256 24 54            [12] 1245 	add	a, #_interface_descriptors
      006258 FE               [12] 1246 	mov	r6,a
      006259 74 BF            [12] 1247 	mov	a,#(_interface_descriptors >> 8)
      00625B 35 F0            [12] 1248 	addc	a, b
      00625D FF               [12] 1249 	mov	r7,a
      00625E 8E 82            [24] 1250 	mov	dpl,r6
      006260 8F 83            [24] 1251 	mov	dph,r7
      006262 A3               [24] 1252 	inc	dptr
      006263 A3               [24] 1253 	inc	dptr
      006264 E4               [12] 1254 	clr	a
      006265 93               [24] 1255 	movc	a,@a+dptr
      006266 FC               [12] 1256 	mov	r4,a
      006267 A3               [24] 1257 	inc	dptr
      006268 E4               [12] 1258 	clr	a
      006269 93               [24] 1259 	movc	a,@a+dptr
                                   1260 ;	tmk_core/protocol/ch555/usb_ak820.c:190: if (!hid) return 0;
      00626A FD               [12] 1261 	mov	r5,a
      00626B 4C               [12] 1262 	orl	a,r4
      00626C 70 04            [24] 1263 	jnz	00124$
      00626E 90 00 00         [24] 1264 	mov	dptr,#0x0000
      006271 22               [24] 1265 	ret
      006272                       1266 00124$:
                                   1267 ;	tmk_core/protocol/ch555/usb_ak820.c:191: if (type == USB_DESCR_TYP_REPORT) {
      006272 90 07 FD         [24] 1268 	mov	dptr,#_descriptor_select_type_10000_272
      006275 E0               [24] 1269 	movx	a,@dptr
      006276 FB               [12] 1270 	mov	r3,a
      006277 BB 22 28         [24] 1271 	cjne	r3,#0x22,00126$
                                   1272 ;	tmk_core/protocol/ch555/usb_ak820.c:192: control_pointer = interface_descriptors[(uint8_t)interface].report;
      00627A 8E 82            [24] 1273 	mov	dpl,r6
      00627C 8F 83            [24] 1274 	mov	dph,r7
      00627E E4               [12] 1275 	clr	a
      00627F 93               [24] 1276 	movc	a,@a+dptr
      006280 FE               [12] 1277 	mov	r6,a
      006281 A3               [24] 1278 	inc	dptr
      006282 E4               [12] 1279 	clr	a
      006283 93               [24] 1280 	movc	a,@a+dptr
      006284 FF               [12] 1281 	mov	r7,a
      006285 90 07 F8         [24] 1282 	mov	dptr,#_control_pointer
      006288 EE               [12] 1283 	mov	a,r6
      006289 F0               [24] 1284 	movx	@dptr,a
      00628A EF               [12] 1285 	mov	a,r7
      00628B A3               [24] 1286 	inc	dptr
      00628C F0               [24] 1287 	movx	@dptr,a
                                   1288 ;	tmk_core/protocol/ch555/usb_ak820.c:193: return hid->HIDReportLength;
      00628D 74 07            [12] 1289 	mov	a,#0x07
      00628F 2C               [12] 1290 	add	a, r4
      006290 F5 82            [12] 1291 	mov	dpl,a
      006292 E4               [12] 1292 	clr	a
      006293 3D               [12] 1293 	addc	a, r5
      006294 F5 83            [12] 1294 	mov	dph,a
      006296 E4               [12] 1295 	clr	a
      006297 93               [24] 1296 	movc	a,@a+dptr
      006298 FE               [12] 1297 	mov	r6,a
      006299 A3               [24] 1298 	inc	dptr
      00629A E4               [12] 1299 	clr	a
      00629B 93               [24] 1300 	movc	a,@a+dptr
      00629C FF               [12] 1301 	mov	r7,a
      00629D 8E 82            [24] 1302 	mov	dpl, r6
      00629F 8F 83            [24] 1303 	mov	dph, r7
      0062A1 22               [24] 1304 	ret
      0062A2                       1305 00126$:
                                   1306 ;	tmk_core/protocol/ch555/usb_ak820.c:195: control_pointer = (const uint8_t __code *)hid;
      0062A2 90 07 F8         [24] 1307 	mov	dptr,#_control_pointer
      0062A5 EC               [12] 1308 	mov	a,r4
      0062A6 F0               [24] 1309 	movx	@dptr,a
      0062A7 ED               [12] 1310 	mov	a,r5
      0062A8 A3               [24] 1311 	inc	dptr
      0062A9 F0               [24] 1312 	movx	@dptr,a
                                   1313 ;	tmk_core/protocol/ch555/usb_ak820.c:196: return 9;
      0062AA 90 00 09         [24] 1314 	mov	dptr,#0x0009
      0062AD 22               [24] 1315 	ret
      0062AE                       1316 00128$:
                                   1317 ;	tmk_core/protocol/ch555/usb_ak820.c:198: return 0;
      0062AE 90 00 00         [24] 1318 	mov	dptr,#0x0000
                                   1319 ;	tmk_core/protocol/ch555/usb_ak820.c:199: }
      0062B1 22               [24] 1320 	ret
                                   1321 ;------------------------------------------------------------
                                   1322 ;Allocation info for local variables in function 'control_setup'
                                   1323 ;------------------------------------------------------------
                                   1324 ;sloc1         Allocated with name '_control_setup_sloc1_1_0'
                                   1325 ;sloc3         Allocated with name '_control_setup_sloc3_1_0'
                                   1326 ;sloc4         Allocated with name '_control_setup_sloc4_1_0'
                                   1327 ;type          Allocated with name '_control_setup_type_10000_290'
                                   1328 ;value         Allocated with name '_control_setup_value_10000_290'
                                   1329 ;index         Allocated with name '_control_setup_index_10000_290'
                                   1330 ;length        Allocated with name '_control_setup_length_10000_290'
                                   1331 ;endpoint      Allocated with name '_control_setup_endpoint_10000_290'
                                   1332 ;i             Allocated with name '_control_setup_i_10000_290'
                                   1333 ;offset        Allocated with name '_control_setup_offset_10000_290'
                                   1334 ;report_id     Allocated with name '_control_setup_report_id_10000_290'
                                   1335 ;------------------------------------------------------------
                                   1336 ;	tmk_core/protocol/ch555/usb_ak820.c:201: static void control_setup(void) {
                                   1337 ;	-----------------------------------------
                                   1338 ;	 function control_setup
                                   1339 ;	-----------------------------------------
      0062B2                       1340 _control_setup:
                                   1341 ;	tmk_core/protocol/ch555/usb_ak820.c:202: uint8_t type = pD0_SETUP_REQ->bRequestType;
      0062B2 90 10 00         [24] 1342 	mov	dptr,#0x1000
      0062B5 E0               [24] 1343 	movx	a,@dptr
      0062B6 FF               [12] 1344 	mov	r7,a
                                   1345 ;	tmk_core/protocol/ch555/usb_ak820.c:203: uint16_t value = pD0_SETUP_REQ->wValueL | ((uint16_t)pD0_SETUP_REQ->wValueH << 8);
      0062B7 A3               [24] 1346 	inc	dptr
      0062B8 A3               [24] 1347 	inc	dptr
      0062B9 E0               [24] 1348 	movx	a,@dptr
      0062BA FE               [12] 1349 	mov	r6,a
      0062BB A3               [24] 1350 	inc	dptr
      0062BC E0               [24] 1351 	movx	a,@dptr
      0062BD FC               [12] 1352 	mov	r4,a
      0062BE 7D 00            [12] 1353 	mov	r5,#0x00
      0062C0 8E 03            [24] 1354 	mov	ar3,r6
      0062C2 7E 00            [12] 1355 	mov	r6,#0x00
      0062C4 ED               [12] 1356 	mov	a,r5
      0062C5 4B               [12] 1357 	orl	a,r3
      0062C6 FD               [12] 1358 	mov	r5,a
      0062C7 EC               [12] 1359 	mov	a,r4
      0062C8 4E               [12] 1360 	orl	a,r6
      0062C9 FE               [12] 1361 	mov	r6,a
                                   1362 ;	tmk_core/protocol/ch555/usb_ak820.c:204: uint16_t index = pD0_SETUP_REQ->wIndexL | ((uint16_t)pD0_SETUP_REQ->wIndexH << 8);
      0062CA A3               [24] 1363 	inc	dptr
      0062CB E0               [24] 1364 	movx	a,@dptr
      0062CC FC               [12] 1365 	mov	r4,a
      0062CD A3               [24] 1366 	inc	dptr
      0062CE E0               [24] 1367 	movx	a,@dptr
      0062CF FA               [12] 1368 	mov	r2,a
      0062D0 7B 00            [12] 1369 	mov	r3,#0x00
      0062D2 8C 01            [24] 1370 	mov	ar1,r4
      0062D4 7C 00            [12] 1371 	mov	r4,#0x00
      0062D6 EB               [12] 1372 	mov	a,r3
      0062D7 49               [12] 1373 	orl	a,r1
      0062D8 FB               [12] 1374 	mov	r3,a
      0062D9 EA               [12] 1375 	mov	a,r2
      0062DA 4C               [12] 1376 	orl	a,r4
      0062DB FC               [12] 1377 	mov	r4,a
                                   1378 ;	tmk_core/protocol/ch555/usb_ak820.c:208: __bit valid_interface = index < TOTAL_INTERFACES;
      0062DC C3               [12] 1379 	clr	c
      0062DD EB               [12] 1380 	mov	a,r3
      0062DE 94 03            [12] 1381 	subb	a,#0x03
      0062E0 EC               [12] 1382 	mov	a,r4
      0062E1 94 00            [12] 1383 	subb	a,#0x00
      0062E3 92 15            [24] 1384 	mov	_control_setup_valid_interface_10000_290,c
                                   1385 ;	tmk_core/protocol/ch555/usb_ak820.c:209: __bit zero_index = !index;
      0062E5 EB               [12] 1386 	mov	a,r3
      0062E6 4C               [12] 1387 	orl	a,r4
      0062E7 B4 01 00         [24] 1388 	cjne	a,#0x01,01201$
      0062EA                       1389 01201$:
      0062EA 92 16            [24] 1390 	mov	_control_setup_zero_index_10000_290,c
                                   1391 ;	tmk_core/protocol/ch555/usb_ak820.c:210: __bit zero_value = !value;
      0062EC ED               [12] 1392 	mov	a,r5
      0062ED 4E               [12] 1393 	orl	a,r6
      0062EE B4 01 00         [24] 1394 	cjne	a,#0x01,01202$
      0062F1                       1395 01202$:
                                   1396 ;	assignBit
      0062F1 92 19            [24] 1397 	mov  _control_setup_sloc0_1_0,c
      0062F3 92 17            [24] 1398 	mov	_control_setup_zero_value_10000_290,c
                                   1399 ;	tmk_core/protocol/ch555/usb_ak820.c:214: uint8_t offset = 0;
      0062F5 90 08 00         [24] 1400 	mov	dptr,#_control_setup_offset_10000_290
      0062F8 E4               [12] 1401 	clr	a
      0062F9 F0               [24] 1402 	movx	@dptr,a
                                   1403 ;	tmk_core/protocol/ch555/usb_ak820.c:216: if (raw_state == RAW_RX) raw_state = RAW_IDLE; /* abort only unfinished OUT */
      0062FA 90 07 9D         [24] 1404 	mov	dptr,#_raw_state
      0062FD E0               [24] 1405 	movx	a,@dptr
      0062FE FA               [12] 1406 	mov	r2,a
      0062FF BA 01 05         [24] 1407 	cjne	r2,#0x01,00102$
      006302 90 07 9D         [24] 1408 	mov	dptr,#_raw_state
      006305 E4               [12] 1409 	clr	a
      006306 F0               [24] 1410 	movx	@dptr,a
      006307                       1411 00102$:
                                   1412 ;	tmk_core/protocol/ch555/usb_ak820.c:217: output_kind = OUTPUT_NONE;
      006307 C0 07            [24] 1413 	push	ar7
      006309 90 07 F5         [24] 1414 	mov	dptr,#_output_kind
      00630C E4               [12] 1415 	clr	a
      00630D F0               [24] 1416 	movx	@dptr,a
                                   1417 ;	tmk_core/protocol/ch555/usb_ak820.c:218: control_phase = CTRL_IDLE;
      00630E 90 07 F4         [24] 1418 	mov	dptr,#_control_phase
      006311 F0               [24] 1419 	movx	@dptr,a
                                   1420 ;	tmk_core/protocol/ch555/usb_ak820.c:219: control_zlp = 0;
      006312 90 07 F7         [24] 1421 	mov	dptr,#_control_zlp
      006315 F0               [24] 1422 	movx	@dptr,a
                                   1423 ;	tmk_core/protocol/ch555/usb_ak820.c:220: D0SetupReqCode = pD0_SETUP_REQ->bRequest;
      006316 90 10 01         [24] 1424 	mov	dptr,#0x1001
      006319 E0               [24] 1425 	movx	a,@dptr
      00631A 90 07 8F         [24] 1426 	mov	dptr,#_D0SetupReqCode
      00631D F0               [24] 1427 	movx	@dptr,a
                                   1428 ;	tmk_core/protocol/ch555/usb_ak820.c:221: D0SetupLen = pD0_SETUP_REQ->wLengthL | ((uint16_t)pD0_SETUP_REQ->wLengthH << 8);
      00631E 90 10 06         [24] 1429 	mov	dptr,#0x1006
      006321 E0               [24] 1430 	movx	a,@dptr
      006322 FA               [12] 1431 	mov	r2,a
      006323 A3               [24] 1432 	inc	dptr
      006324 E0               [24] 1433 	movx	a,@dptr
      006325 F9               [12] 1434 	mov	r1,a
      006326 78 00            [12] 1435 	mov	r0,#0x00
      006328 7F 00            [12] 1436 	mov	r7,#0x00
      00632A 90 07 90         [24] 1437 	mov	dptr,#_D0SetupLen
      00632D E8               [12] 1438 	mov	a,r0
      00632E 4A               [12] 1439 	orl	a,r2
      00632F F0               [24] 1440 	movx	@dptr,a
      006330 E9               [12] 1441 	mov	a,r1
      006331 4F               [12] 1442 	orl	a,r7
      006332 A3               [24] 1443 	inc	dptr
      006333 F0               [24] 1444 	movx	@dptr,a
                                   1445 ;	tmk_core/protocol/ch555/usb_ak820.c:222: zero_length = !D0SetupLen;
      006334 90 07 90         [24] 1446 	mov	dptr,#_D0SetupLen
      006337 E0               [24] 1447 	movx	a,@dptr
      006338 FA               [12] 1448 	mov	r2,a
      006339 A3               [24] 1449 	inc	dptr
      00633A E0               [24] 1450 	movx	a,@dptr
      00633B 4A               [12] 1451 	orl	a,r2
      00633C B4 01 00         [24] 1452 	cjne	a,#0x01,01205$
      00633F                       1453 01205$:
      00633F 92 18            [24] 1454 	mov	_control_setup_zero_length_10000_290,c
                                   1455 ;	tmk_core/protocol/ch555/usb_ak820.c:223: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_ACK | UEP_T_RES_NAK;
      006341 90 22 00         [24] 1456 	mov	dptr,#0x2200
      006344 74 C2            [12] 1457 	mov	a,#0xc2
      006346 F0               [24] 1458 	movx	@dptr,a
                                   1459 ;	tmk_core/protocol/ch555/usb_ak820.c:224: D0_EP0T_L = 0;
      006347 90 22 08         [24] 1460 	mov	dptr,#0x2208
      00634A E4               [12] 1461 	clr	a
      00634B F0               [24] 1462 	movx	@dptr,a
                                   1463 ;	tmk_core/protocol/ch555/usb_ak820.c:228: switch (D0SetupReqCode) {
      00634C 90 07 8F         [24] 1464 	mov	dptr,#_D0SetupReqCode
      00634F E0               [24] 1465 	movx	a,@dptr
      006350 F5 16            [12] 1466 	mov	_control_setup_sloc1_1_0,a
      006352 C3               [12] 1467 	clr	c
      006353 74 0B            [12] 1468 	mov	a,#0x0b
      006355 95 16            [12] 1469 	subb	a,_control_setup_sloc1_1_0
      006357 D0 07            [24] 1470 	pop	ar7
      006359 50 03            [24] 1471 	jnc	01206$
      00635B 02 60 99         [24] 1472 	ljmp	_control_stall
      00635E                       1473 01206$:
                                   1474 ;	free result
      00635E E5 16            [12] 1475 	mov	a,_control_setup_sloc1_1_0
      006360 F5 F0            [12] 1476 	mov	b,a
      006362 24 0B            [12] 1477 	add	a,#(01207$-3-.)
      006364 83               [24] 1478 	movc	a,@a+pc
      006365 F5 82            [12] 1479 	mov	dpl,a
      006367 E5 F0            [12] 1480 	mov	a,b
      006369 24 10            [12] 1481 	add	a,#(01208$-3-.)
      00636B 83               [24] 1482 	movc	a,@a+pc
      00636C F5 83            [12] 1483 	mov	dph,a
      00636E E4               [12] 1484 	clr	a
      00636F 73               [24] 1485 	jmp	@a+dptr
      006370                       1486 01207$:
      006370 18                    1487 	.db	00188$
      006371 BE                    1488 	.db	00205$
      006372 01                    1489 	.db	00282$
      006373 BE                    1490 	.db	00205$
      006374 45                    1491 	.db	00290$
      006375 42                    1492 	.db	00116$
      006376 88                    1493 	.db	00103$
      006377 45                    1494 	.db	00290$
      006378 47                    1495 	.db	00150$
      006379 6B                    1496 	.db	00123$
      00637A 77                    1497 	.db	00157$
      00637B CA                    1498 	.db	00173$
      00637C                       1499 01208$:
      00637C 66                    1500 	.db	00188$>>8
      00637D 66                    1501 	.db	00205$>>8
      00637E 6A                    1502 	.db	00282$>>8
      00637F 66                    1503 	.db	00205$>>8
      006380 6A                    1504 	.db	00290$>>8
      006381 64                    1505 	.db	00116$>>8
      006382 63                    1506 	.db	00103$>>8
      006383 6A                    1507 	.db	00290$>>8
      006384 65                    1508 	.db	00150$>>8
      006385 64                    1509 	.db	00123$>>8
      006386 65                    1510 	.db	00157$>>8
      006387 65                    1511 	.db	00173$>>8
                                   1512 ;	tmk_core/protocol/ch555/usb_ak820.c:229: case USB_GET_DESCRIPTOR:
      006388                       1513 00103$:
                                   1514 ;	tmk_core/protocol/ch555/usb_ak820.c:230: if (type == 0x80 || type == 0x81) {
      006388 BF 80 02         [24] 1515 	cjne	r7,#0x80,01209$
      00638B 80 08            [24] 1516 	sjmp	00112$
      00638D                       1517 01209$:
      00638D BF 81 02         [24] 1518 	cjne	r7,#0x81,01210$
      006390 80 03            [24] 1519 	sjmp	01211$
      006392                       1520 01210$:
      006392 02 60 99         [24] 1521 	ljmp	_control_stall
      006395                       1522 01211$:
      006395                       1523 00112$:
                                   1524 ;	tmk_core/protocol/ch555/usb_ak820.c:231: if (((value >> 8) == USB_DESCR_TYP_HID || (value >> 8) == USB_DESCR_TYP_REPORT) != (type == 0x81)) {
      006395 8E 01            [24] 1525 	mov	ar1,r6
      006397 B9 21 02         [24] 1526 	cjne	r1,#0x21,01212$
      00639A 80 09            [24] 1527 	sjmp	00301$
      00639C                       1528 01212$:
      00639C B9 22 02         [24] 1529 	cjne	r1,#0x22,01213$
      00639F 80 04            [24] 1530 	sjmp	00301$
      0063A1                       1531 01213$:
                                   1532 ;	assignBit
      0063A1 C2 1A            [12] 1533 	clr	_control_setup_sloc2_1_0
      0063A3 80 02            [24] 1534 	sjmp	00302$
      0063A5                       1535 00301$:
                                   1536 ;	assignBit
      0063A5 D2 1A            [12] 1537 	setb	_control_setup_sloc2_1_0
      0063A7                       1538 00302$:
      0063A7 E4               [12] 1539 	clr	a
      0063A8 BF 81 01         [24] 1540 	cjne	r7,#0x81,01214$
      0063AB 04               [12] 1541 	inc	a
      0063AC                       1542 01214$:
      0063AC FA               [12] 1543 	mov	r2,a
      0063AD A2 1A            [12] 1544 	mov	c,_control_setup_sloc2_1_0
      0063AF E4               [12] 1545 	clr	a
      0063B0 33               [12] 1546 	rlc	a
      0063B1 B5 02 02         [24] 1547 	cjne	a,ar2,01216$
      0063B4 80 03            [24] 1548 	sjmp	00105$
      0063B6                       1549 01216$:
                                   1550 ;	tmk_core/protocol/ch555/usb_ak820.c:232: control_stall(); return;
      0063B6 02 60 99         [24] 1551 	ljmp	_control_stall
      0063B9                       1552 00105$:
                                   1553 ;	tmk_core/protocol/ch555/usb_ak820.c:234: length = descriptor_select(value >> 8, value, index);
      0063B9 8E 02            [24] 1554 	mov	ar2,r6
      0063BB 90 07 FA         [24] 1555 	mov	dptr,#_descriptor_select_PARM_2
      0063BE ED               [12] 1556 	mov	a,r5
      0063BF F0               [24] 1557 	movx	@dptr,a
      0063C0 90 07 FB         [24] 1558 	mov	dptr,#_descriptor_select_PARM_3
      0063C3 EB               [12] 1559 	mov	a,r3
      0063C4 F0               [24] 1560 	movx	@dptr,a
      0063C5 EC               [12] 1561 	mov	a,r4
      0063C6 A3               [24] 1562 	inc	dptr
      0063C7 F0               [24] 1563 	movx	@dptr,a
      0063C8 8A 82            [24] 1564 	mov	dpl, r2
      0063CA 12 61 37         [24] 1565 	lcall	_descriptor_select
      0063CD 85 82 17         [24] 1566 	mov	_control_setup_sloc3_1_0,dpl
      0063D0 85 83 18         [24] 1567 	mov	(_control_setup_sloc3_1_0 + 1),dph
                                   1568 ;	tmk_core/protocol/ch555/usb_ak820.c:235: if (!length) { control_stall(); return; }
      0063D3 E5 17            [12] 1569 	mov	a,_control_setup_sloc3_1_0
      0063D5 45 18            [12] 1570 	orl	a,(_control_setup_sloc3_1_0 + 1)
      0063D7 70 03            [24] 1571 	jnz	00107$
      0063D9 02 60 99         [24] 1572 	ljmp	_control_stall
      0063DC                       1573 00107$:
                                   1574 ;	tmk_core/protocol/ch555/usb_ak820.c:236: control_zlp = length < D0SetupLen && !(length & (DEF_ENDP0_SIZE - 1));
      0063DC 90 07 90         [24] 1575 	mov	dptr,#_D0SetupLen
      0063DF E0               [24] 1576 	movx	a,@dptr
      0063E0 F8               [12] 1577 	mov	r0,a
      0063E1 A3               [24] 1578 	inc	dptr
      0063E2 E0               [24] 1579 	movx	a,@dptr
      0063E3 FA               [12] 1580 	mov	r2,a
      0063E4 C3               [12] 1581 	clr	c
      0063E5 E5 17            [12] 1582 	mov	a,_control_setup_sloc3_1_0
      0063E7 98               [12] 1583 	subb	a,r0
      0063E8 E5 18            [12] 1584 	mov	a,(_control_setup_sloc3_1_0 + 1)
      0063EA 9A               [12] 1585 	subb	a,r2
      0063EB 50 06            [24] 1586 	jnc	00303$
      0063ED E5 17            [12] 1587 	mov	a,_control_setup_sloc3_1_0
      0063EF 54 3F            [12] 1588 	anl	a,#0x3f
      0063F1 60 04            [24] 1589 	jz	00304$
      0063F3                       1590 00303$:
                                   1591 ;	assignBit
      0063F3 C2 1A            [12] 1592 	clr	_control_setup_sloc2_1_0
      0063F5 80 02            [24] 1593 	sjmp	00305$
      0063F7                       1594 00304$:
                                   1595 ;	assignBit
      0063F7 D2 1A            [12] 1596 	setb	_control_setup_sloc2_1_0
      0063F9                       1597 00305$:
      0063F9 90 07 F7         [24] 1598 	mov	dptr,#_control_zlp
      0063FC A2 1A            [12] 1599 	mov	c,_control_setup_sloc2_1_0
      0063FE E4               [12] 1600 	clr	a
      0063FF 33               [12] 1601 	rlc	a
      006400 F0               [24] 1602 	movx	@dptr,a
                                   1603 ;	tmk_core/protocol/ch555/usb_ak820.c:237: if (D0SetupLen > length) D0SetupLen = length;
      006401 90 07 90         [24] 1604 	mov	dptr,#_D0SetupLen
      006404 E0               [24] 1605 	movx	a,@dptr
      006405 F9               [12] 1606 	mov	r1,a
      006406 A3               [24] 1607 	inc	dptr
      006407 E0               [24] 1608 	movx	a,@dptr
      006408 FA               [12] 1609 	mov	r2,a
      006409 C3               [12] 1610 	clr	c
      00640A E5 17            [12] 1611 	mov	a,_control_setup_sloc3_1_0
      00640C 99               [12] 1612 	subb	a,r1
      00640D E5 18            [12] 1613 	mov	a,(_control_setup_sloc3_1_0 + 1)
      00640F 9A               [12] 1614 	subb	a,r2
      006410 50 0A            [24] 1615 	jnc	00109$
                                   1616 ;	free result
      006412 90 07 90         [24] 1617 	mov	dptr,#_D0SetupLen
      006415 E5 17            [12] 1618 	mov	a,_control_setup_sloc3_1_0
      006417 F0               [24] 1619 	movx	@dptr,a
      006418 E5 18            [12] 1620 	mov	a,(_control_setup_sloc3_1_0 + 1)
      00641A A3               [24] 1621 	inc	dptr
      00641B F0               [24] 1622 	movx	@dptr,a
      00641C                       1623 00109$:
                                   1624 ;	tmk_core/protocol/ch555/usb_ak820.c:238: control_phase = D0SetupLen ? CTRL_DATA_IN : CTRL_STATUS_OUT;
      00641C 90 07 90         [24] 1625 	mov	dptr,#_D0SetupLen
      00641F E0               [24] 1626 	movx	a,@dptr
      006420 F9               [12] 1627 	mov	r1,a
      006421 A3               [24] 1628 	inc	dptr
      006422 E0               [24] 1629 	movx	a,@dptr
      006423 49               [12] 1630 	orl	a,r1
      006424 60 04            [24] 1631 	jz	00306$
      006426 7A 01            [12] 1632 	mov	r2,#0x01
      006428 80 02            [24] 1633 	sjmp	00307$
      00642A                       1634 00306$:
      00642A 7A 02            [12] 1635 	mov	r2,#0x02
      00642C                       1636 00307$:
      00642C 90 07 F4         [24] 1637 	mov	dptr,#_control_phase
      00642F EA               [12] 1638 	mov	a,r2
      006430 F0               [24] 1639 	movx	@dptr,a
                                   1640 ;	tmk_core/protocol/ch555/usb_ak820.c:239: if (D0SetupLen) control_next();
      006431 90 07 90         [24] 1641 	mov	dptr,#_D0SetupLen
      006434 E0               [24] 1642 	movx	a,@dptr
      006435 F9               [12] 1643 	mov	r1,a
      006436 A3               [24] 1644 	inc	dptr
      006437 E0               [24] 1645 	movx	a,@dptr
      006438 49               [12] 1646 	orl	a,r1
      006439 60 03            [24] 1647 	jz	00111$
                                   1648 ;	tmk_core/protocol/ch555/usb_ak820.c:240: return;
      00643B 02 60 BB         [24] 1649 	ljmp	_control_next
      00643E                       1650 00111$:
      00643E 22               [24] 1651 	ret
                                   1652 ;	tmk_core/protocol/ch555/usb_ak820.c:241: } else { control_stall(); return; }
      00643F 02 60 99         [24] 1653 	ljmp	_control_stall
                                   1654 ;	tmk_core/protocol/ch555/usb_ak820.c:242: case USB_SET_ADDRESS:
      006442                       1655 00116$:
                                   1656 ;	tmk_core/protocol/ch555/usb_ak820.c:243: if (type == 0x00 && zero_index && zero_length && value <= 127) {
      006442 EF               [12] 1657 	mov	a,r7
      006443 70 23            [24] 1658 	jnz	00118$
      006445 30 16 20         [24] 1659 	jnb	_control_setup_zero_index_10000_290,00118$
      006448 30 18 1D         [24] 1660 	jnb	_control_setup_zero_length_10000_290,00118$
      00644B 8D 01            [24] 1661 	mov	ar1,r5
      00644D 8E 02            [24] 1662 	mov	ar2,r6
      00644F C3               [12] 1663 	clr	c
      006450 74 7F            [12] 1664 	mov	a,#0x7f
      006452 99               [12] 1665 	subb	a,r1
      006453 E4               [12] 1666 	clr	a
      006454 9A               [12] 1667 	subb	a,r2
      006455 40 11            [24] 1668 	jc	00118$
                                   1669 ;	free result
                                   1670 ;	tmk_core/protocol/ch555/usb_ak820.c:244: D0SetupLen = value; /* applied after status-IN ACK */
      006457 90 07 90         [24] 1671 	mov	dptr,#_D0SetupLen
      00645A ED               [12] 1672 	mov	a,r5
      00645B F0               [24] 1673 	movx	@dptr,a
      00645C EE               [12] 1674 	mov	a,r6
      00645D A3               [24] 1675 	inc	dptr
      00645E F0               [24] 1676 	movx	@dptr,a
                                   1677 ;	tmk_core/protocol/ch555/usb_ak820.c:245: control_phase = CTRL_STATUS_IN;
      00645F 90 07 F4         [24] 1678 	mov	dptr,#_control_phase
      006462 74 03            [12] 1679 	mov	a,#0x03
      006464 F0               [24] 1680 	movx	@dptr,a
      006465 02 6A 48         [24] 1681 	ljmp	00291$
      006468                       1682 00118$:
                                   1683 ;	tmk_core/protocol/ch555/usb_ak820.c:246: } else { control_stall(); return; }
      006468 02 60 99         [24] 1684 	ljmp	_control_stall
                                   1685 ;	tmk_core/protocol/ch555/usb_ak820.c:248: case USB_SET_CONFIGURATION: /* HID_SET_REPORT has the same request byte. */
      00646B                       1686 00123$:
                                   1687 ;	tmk_core/protocol/ch555/usb_ak820.c:249: if (type == 0x00 && zero_index && zero_length && value <= 1) {
      00646B EF               [12] 1688 	mov	a,r7
      00646C 70 3C            [24] 1689 	jnz	00145$
      00646E 30 16 39         [24] 1690 	jnb	_control_setup_zero_index_10000_290,00145$
      006471 30 18 36         [24] 1691 	jnb	_control_setup_zero_length_10000_290,00145$
      006474 8D 01            [24] 1692 	mov	ar1,r5
      006476 8E 02            [24] 1693 	mov	ar2,r6
      006478 C3               [12] 1694 	clr	c
      006479 74 01            [12] 1695 	mov	a,#0x01
      00647B 99               [12] 1696 	subb	a,r1
      00647C E4               [12] 1697 	clr	a
      00647D 9A               [12] 1698 	subb	a,r2
      00647E 40 2A            [24] 1699 	jc	00145$
                                   1700 ;	free result
                                   1701 ;	tmk_core/protocol/ch555/usb_ak820.c:250: endpoints_reset();
      006480 C0 06            [24] 1702 	push	ar6
      006482 C0 05            [24] 1703 	push	ar5
      006484 12 60 38         [24] 1704 	lcall	_endpoints_reset
      006487 D0 05            [24] 1705 	pop	ar5
      006489 D0 06            [24] 1706 	pop	ar6
                                   1707 ;	tmk_core/protocol/ch555/usb_ak820.c:251: D0UsbConfig = value;
      00648B 90 07 95         [24] 1708 	mov	dptr,#_D0UsbConfig
      00648E ED               [12] 1709 	mov	a,r5
      00648F F0               [24] 1710 	movx	@dptr,a
                                   1711 ;	tmk_core/protocol/ch555/usb_ak820.c:252: USB_EnumStatus = value != 0;
      006490 A2 19            [12] 1712 	mov	c,_control_setup_sloc0_1_0
      006492 B3               [12] 1713 	cpl	c
      006493 92 1A            [24] 1714 	mov	_control_setup_sloc2_1_0,c
      006495 90 07 96         [24] 1715 	mov	dptr,#_USB_EnumStatus
      006498 E4               [12] 1716 	clr	a
      006499 33               [12] 1717 	rlc	a
      00649A F0               [24] 1718 	movx	@dptr,a
                                   1719 ;	tmk_core/protocol/ch555/usb_ak820.c:253: keyboard_reset = 1;
      00649B 90 07 BF         [24] 1720 	mov	dptr,#_keyboard_reset
      00649E 74 01            [12] 1721 	mov	a,#0x01
      0064A0 F0               [24] 1722 	movx	@dptr,a
                                   1723 ;	tmk_core/protocol/ch555/usb_ak820.c:254: control_phase = CTRL_STATUS_IN;
      0064A1 90 07 F4         [24] 1724 	mov	dptr,#_control_phase
      0064A4 74 03            [12] 1725 	mov	a,#0x03
      0064A6 F0               [24] 1726 	movx	@dptr,a
      0064A7 02 6A 48         [24] 1727 	ljmp	00291$
      0064AA                       1728 00145$:
                                   1729 ;	tmk_core/protocol/ch555/usb_ak820.c:255: } else if (type == 0x21 && D0UsbConfig) {
      0064AA BF 21 02         [24] 1730 	cjne	r7,#0x21,01231$
      0064AD 80 03            [24] 1731 	sjmp	01232$
      0064AF                       1732 01231$:
      0064AF 02 60 99         [24] 1733 	ljmp	_control_stall
      0064B2                       1734 01232$:
      0064B2 90 07 95         [24] 1735 	mov	dptr,#_D0UsbConfig
      0064B5 E0               [24] 1736 	movx	a,@dptr
      0064B6 70 03            [24] 1737 	jnz	01233$
      0064B8 02 60 99         [24] 1738 	ljmp	_control_stall
      0064BB                       1739 01233$:
                                   1740 ;	tmk_core/protocol/ch555/usb_ak820.c:256: if (index == RAW_INTERFACE && value == 0x0200 && D0SetupLen == RAW_EPSIZE && raw_state == RAW_IDLE) {
      0064BB BB 01 2D         [24] 1741 	cjne	r3,#0x01,00135$
      0064BE BC 00 2A         [24] 1742 	cjne	r4,#0x00,00135$
      0064C1 8D 01            [24] 1743 	mov	ar1,r5
      0064C3 8E 02            [24] 1744 	mov	ar2,r6
      0064C5 B9 00 23         [24] 1745 	cjne	r1,#0x00,00135$
      0064C8 BA 02 20         [24] 1746 	cjne	r2,#0x02,00135$
      0064CB 90 07 90         [24] 1747 	mov	dptr,#_D0SetupLen
      0064CE E0               [24] 1748 	movx	a,@dptr
      0064CF F9               [12] 1749 	mov	r1,a
      0064D0 A3               [24] 1750 	inc	dptr
      0064D1 E0               [24] 1751 	movx	a,@dptr
      0064D2 FA               [12] 1752 	mov	r2,a
      0064D3 B9 20 15         [24] 1753 	cjne	r1,#0x20,00135$
      0064D6 BA 00 12         [24] 1754 	cjne	r2,#0x00,00135$
      0064D9 90 07 9D         [24] 1755 	mov	dptr,#_raw_state
      0064DC E0               [24] 1756 	movx	a,@dptr
      0064DD 70 0C            [24] 1757 	jnz	00135$
                                   1758 ;	tmk_core/protocol/ch555/usb_ak820.c:257: raw_state = RAW_RX;
      0064DF 90 07 9D         [24] 1759 	mov	dptr,#_raw_state
      0064E2 74 01            [12] 1760 	mov	a,#0x01
      0064E4 F0               [24] 1761 	movx	@dptr,a
                                   1762 ;	tmk_core/protocol/ch555/usb_ak820.c:258: output_kind = OUTPUT_RAW;
      0064E5 90 07 F5         [24] 1763 	mov	dptr,#_output_kind
      0064E8 F0               [24] 1764 	movx	@dptr,a
      0064E9 80 52            [24] 1765 	sjmp	00136$
      0064EB                       1766 00135$:
                                   1767 ;	tmk_core/protocol/ch555/usb_ak820.c:259: } else if (index == KEYBOARD_INTERFACE && value == 0x0200 && D0SetupLen == 1) {
      0064EB EB               [12] 1768 	mov	a,r3
      0064EC 4C               [12] 1769 	orl	a,r4
      0064ED 70 20            [24] 1770 	jnz	00130$
      0064EF 8D 01            [24] 1771 	mov	ar1,r5
      0064F1 8E 02            [24] 1772 	mov	ar2,r6
      0064F3 B9 00 19         [24] 1773 	cjne	r1,#0x00,00130$
      0064F6 BA 02 16         [24] 1774 	cjne	r2,#0x02,00130$
      0064F9 90 07 90         [24] 1775 	mov	dptr,#_D0SetupLen
      0064FC E0               [24] 1776 	movx	a,@dptr
      0064FD F9               [12] 1777 	mov	r1,a
      0064FE A3               [24] 1778 	inc	dptr
      0064FF E0               [24] 1779 	movx	a,@dptr
      006500 FA               [12] 1780 	mov	r2,a
      006501 B9 01 0B         [24] 1781 	cjne	r1,#0x01,00130$
      006504 BA 00 08         [24] 1782 	cjne	r2,#0x00,00130$
                                   1783 ;	tmk_core/protocol/ch555/usb_ak820.c:260: output_kind = OUTPUT_LED;
      006507 90 07 F5         [24] 1784 	mov	dptr,#_output_kind
      00650A 74 02            [12] 1785 	mov	a,#0x02
      00650C F0               [24] 1786 	movx	@dptr,a
      00650D 80 2E            [24] 1787 	sjmp	00136$
      00650F                       1788 00130$:
                                   1789 ;	tmk_core/protocol/ch555/usb_ak820.c:262: } else if (index == SHARED_INTERFACE && value == (0x0200 | REPORT_ID_NKRO) && D0SetupLen == 2) {
      00650F BB 02 28         [24] 1790 	cjne	r3,#0x02,00125$
      006512 BC 00 25         [24] 1791 	cjne	r4,#0x00,00125$
      006515 8D 01            [24] 1792 	mov	ar1,r5
      006517 8E 02            [24] 1793 	mov	ar2,r6
      006519 B9 06 1E         [24] 1794 	cjne	r1,#0x06,00125$
      00651C BA 02 1B         [24] 1795 	cjne	r2,#0x02,00125$
      00651F 90 07 90         [24] 1796 	mov	dptr,#_D0SetupLen
      006522 E0               [24] 1797 	movx	a,@dptr
      006523 F9               [12] 1798 	mov	r1,a
      006524 A3               [24] 1799 	inc	dptr
      006525 E0               [24] 1800 	movx	a,@dptr
      006526 FA               [12] 1801 	mov	r2,a
      006527 B9 02 10         [24] 1802 	cjne	r1,#0x02,00125$
      00652A BA 00 0D         [24] 1803 	cjne	r2,#0x00,00125$
                                   1804 ;	tmk_core/protocol/ch555/usb_ak820.c:263: output_kind = OUTPUT_SHARED_LED;
      00652D 90 07 F5         [24] 1805 	mov	dptr,#_output_kind
      006530 74 03            [12] 1806 	mov	a,#0x03
      006532 F0               [24] 1807 	movx	@dptr,a
                                   1808 ;	tmk_core/protocol/ch555/usb_ak820.c:264: output_report_id = REPORT_ID_NKRO;
      006533 90 07 F6         [24] 1809 	mov	dptr,#_output_report_id
      006536 23               [12] 1810 	rl	a
      006537 F0               [24] 1811 	movx	@dptr,a
      006538 80 03            [24] 1812 	sjmp	00136$
      00653A                       1813 00125$:
                                   1814 ;	tmk_core/protocol/ch555/usb_ak820.c:266: } else { control_stall(); return; }
      00653A 02 60 99         [24] 1815 	ljmp	_control_stall
      00653D                       1816 00136$:
                                   1817 ;	tmk_core/protocol/ch555/usb_ak820.c:267: control_phase = CTRL_DATA_OUT;
      00653D 90 07 F4         [24] 1818 	mov	dptr,#_control_phase
      006540 74 04            [12] 1819 	mov	a,#0x04
      006542 F0               [24] 1820 	movx	@dptr,a
                                   1821 ;	tmk_core/protocol/ch555/usb_ak820.c:268: return; /* OUT data must arrive before status-IN becomes ACK */
      006543 22               [24] 1822 	ret
                                   1823 ;	tmk_core/protocol/ch555/usb_ak820.c:269: } else { control_stall(); return; }
      006544 02 60 99         [24] 1824 	ljmp	_control_stall
                                   1825 ;	tmk_core/protocol/ch555/usb_ak820.c:271: case USB_GET_CONFIGURATION:
      006547                       1826 00150$:
                                   1827 ;	tmk_core/protocol/ch555/usb_ak820.c:272: if (type == 0x80 && zero_index && zero_value && D0SetupLen == 1) {
      006547 BF 80 2A         [24] 1828 	cjne	r7,#0x80,00152$
      00654A 30 16 27         [24] 1829 	jnb	_control_setup_zero_index_10000_290,00152$
      00654D 30 17 24         [24] 1830 	jnb	_control_setup_zero_value_10000_290,00152$
      006550 90 07 90         [24] 1831 	mov	dptr,#_D0SetupLen
      006553 E0               [24] 1832 	movx	a,@dptr
      006554 F9               [12] 1833 	mov	r1,a
      006555 A3               [24] 1834 	inc	dptr
      006556 E0               [24] 1835 	movx	a,@dptr
      006557 FA               [12] 1836 	mov	r2,a
      006558 B9 01 19         [24] 1837 	cjne	r1,#0x01,00152$
      00655B BA 00 16         [24] 1838 	cjne	r2,#0x00,00152$
                                   1839 ;	tmk_core/protocol/ch555/usb_ak820.c:273: pD0_EP0_BUF[0] = D0UsbConfig;
      00655E 90 07 95         [24] 1840 	mov	dptr,#_D0UsbConfig
      006561 E0               [24] 1841 	movx	a,@dptr
      006562 90 10 00         [24] 1842 	mov	dptr,#0x1000
      006565 F0               [24] 1843 	movx	@dptr,a
                                   1844 ;	tmk_core/protocol/ch555/usb_ak820.c:274: D0_EP0T_L = 1;
      006566 90 22 08         [24] 1845 	mov	dptr,#0x2208
      006569 74 01            [12] 1846 	mov	a,#0x01
      00656B F0               [24] 1847 	movx	@dptr,a
                                   1848 ;	tmk_core/protocol/ch555/usb_ak820.c:275: control_phase = CTRL_STATUS_OUT;
      00656C 90 07 F4         [24] 1849 	mov	dptr,#_control_phase
      00656F 04               [12] 1850 	inc	a
      006570 F0               [24] 1851 	movx	@dptr,a
      006571 02 6A 48         [24] 1852 	ljmp	00291$
      006574                       1853 00152$:
                                   1854 ;	tmk_core/protocol/ch555/usb_ak820.c:276: } else { control_stall(); return; }
      006574 02 60 99         [24] 1855 	ljmp	_control_stall
                                   1856 ;	tmk_core/protocol/ch555/usb_ak820.c:278: case USB_GET_INTERFACE: /* DEF_USB_SET_IDLE has the same request byte. */
      006577                       1857 00157$:
                                   1858 ;	tmk_core/protocol/ch555/usb_ak820.c:279: if (type == 0x81 && valid_interface && zero_value && D0SetupLen == 1 && D0UsbConfig) {
      006577 BF 81 2C         [24] 1859 	cjne	r7,#0x81,00167$
      00657A 30 15 29         [24] 1860 	jnb	_control_setup_valid_interface_10000_290,00167$
      00657D 30 17 26         [24] 1861 	jnb	_control_setup_zero_value_10000_290,00167$
      006580 90 07 90         [24] 1862 	mov	dptr,#_D0SetupLen
      006583 E0               [24] 1863 	movx	a,@dptr
      006584 F9               [12] 1864 	mov	r1,a
      006585 A3               [24] 1865 	inc	dptr
      006586 E0               [24] 1866 	movx	a,@dptr
      006587 FA               [12] 1867 	mov	r2,a
      006588 B9 01 1B         [24] 1868 	cjne	r1,#0x01,00167$
      00658B BA 00 18         [24] 1869 	cjne	r2,#0x00,00167$
      00658E 90 07 95         [24] 1870 	mov	dptr,#_D0UsbConfig
      006591 E0               [24] 1871 	movx	a,@dptr
      006592 60 12            [24] 1872 	jz	00167$
                                   1873 ;	tmk_core/protocol/ch555/usb_ak820.c:280: pD0_EP0_BUF[0] = 0;
      006594 90 10 00         [24] 1874 	mov	dptr,#0x1000
      006597 E4               [12] 1875 	clr	a
      006598 F0               [24] 1876 	movx	@dptr,a
                                   1877 ;	tmk_core/protocol/ch555/usb_ak820.c:281: D0_EP0T_L = 1;
      006599 90 22 08         [24] 1878 	mov	dptr,#0x2208
      00659C 04               [12] 1879 	inc	a
      00659D F0               [24] 1880 	movx	@dptr,a
                                   1881 ;	tmk_core/protocol/ch555/usb_ak820.c:282: control_phase = CTRL_STATUS_OUT;
      00659E 90 07 F4         [24] 1882 	mov	dptr,#_control_phase
      0065A1 04               [12] 1883 	inc	a
      0065A2 F0               [24] 1884 	movx	@dptr,a
      0065A3 02 6A 48         [24] 1885 	ljmp	00291$
      0065A6                       1886 00167$:
                                   1887 ;	tmk_core/protocol/ch555/usb_ak820.c:283: } else if (valid_interface && D0UsbConfig && type == 0x21 && zero_length) {
      0065A6 30 15 1E         [24] 1888 	jnb	_control_setup_valid_interface_10000_290,00161$
      0065A9 90 07 95         [24] 1889 	mov	dptr,#_D0UsbConfig
      0065AC E0               [24] 1890 	movx	a,@dptr
      0065AD 60 18            [24] 1891 	jz	00161$
      0065AF BF 21 15         [24] 1892 	cjne	r7,#0x21,00161$
      0065B2 30 18 12         [24] 1893 	jnb	_control_setup_zero_length_10000_290,00161$
                                   1894 ;	tmk_core/protocol/ch555/usb_ak820.c:284: if (index == KEYBOARD_INTERFACE) keyboard_idle = value >> 8;
      0065B5 EB               [12] 1895 	mov	a,r3
      0065B6 4C               [12] 1896 	orl	a,r4
      0065B7 70 05            [24] 1897 	jnz	00159$
      0065B9 90 06 57         [24] 1898 	mov	dptr,#_keyboard_idle
      0065BC EE               [12] 1899 	mov	a,r6
      0065BD F0               [24] 1900 	movx	@dptr,a
      0065BE                       1901 00159$:
                                   1902 ;	tmk_core/protocol/ch555/usb_ak820.c:285: control_phase = CTRL_STATUS_IN;
      0065BE 90 07 F4         [24] 1903 	mov	dptr,#_control_phase
      0065C1 74 03            [12] 1904 	mov	a,#0x03
      0065C3 F0               [24] 1905 	movx	@dptr,a
      0065C4 02 6A 48         [24] 1906 	ljmp	00291$
      0065C7                       1907 00161$:
                                   1908 ;	tmk_core/protocol/ch555/usb_ak820.c:286: } else { control_stall(); return; }
      0065C7 02 60 99         [24] 1909 	ljmp	_control_stall
                                   1910 ;	tmk_core/protocol/ch555/usb_ak820.c:288: case USB_SET_INTERFACE: /* DEF_USB_SET_PROTOCOL has the same request byte. */
      0065CA                       1911 00173$:
                                   1912 ;	tmk_core/protocol/ch555/usb_ak820.c:289: if (type == 0x01 && valid_interface && zero_value && zero_length && D0UsbConfig) {
      0065CA BF 01 18         [24] 1913 	cjne	r7,#0x01,00182$
      0065CD 30 15 15         [24] 1914 	jnb	_control_setup_valid_interface_10000_290,00182$
      0065D0 30 17 12         [24] 1915 	jnb	_control_setup_zero_value_10000_290,00182$
      0065D3 30 18 0F         [24] 1916 	jnb	_control_setup_zero_length_10000_290,00182$
      0065D6 90 07 95         [24] 1917 	mov	dptr,#_D0UsbConfig
      0065D9 E0               [24] 1918 	movx	a,@dptr
      0065DA 60 09            [24] 1919 	jz	00182$
                                   1920 ;	tmk_core/protocol/ch555/usb_ak820.c:290: control_phase = CTRL_STATUS_IN;
      0065DC 90 07 F4         [24] 1921 	mov	dptr,#_control_phase
      0065DF 74 03            [12] 1922 	mov	a,#0x03
      0065E1 F0               [24] 1923 	movx	@dptr,a
      0065E2 02 6A 48         [24] 1924 	ljmp	00291$
      0065E5                       1925 00182$:
                                   1926 ;	tmk_core/protocol/ch555/usb_ak820.c:291: } else if (index == KEYBOARD_INTERFACE && D0UsbConfig && type == 0x21 && zero_length && value <= 1) {
      0065E5 EB               [12] 1927 	mov	a,r3
      0065E6 4C               [12] 1928 	orl	a,r4
      0065E7 70 2C            [24] 1929 	jnz	00175$
      0065E9 90 07 95         [24] 1930 	mov	dptr,#_D0UsbConfig
      0065EC E0               [24] 1931 	movx	a,@dptr
      0065ED 60 26            [24] 1932 	jz	00175$
      0065EF BF 21 23         [24] 1933 	cjne	r7,#0x21,00175$
      0065F2 30 18 20         [24] 1934 	jnb	_control_setup_zero_length_10000_290,00175$
      0065F5 8D 01            [24] 1935 	mov	ar1,r5
      0065F7 8E 02            [24] 1936 	mov	ar2,r6
      0065F9 C3               [12] 1937 	clr	c
      0065FA 74 01            [12] 1938 	mov	a,#0x01
      0065FC 99               [12] 1939 	subb	a,r1
      0065FD E4               [12] 1940 	clr	a
      0065FE 9A               [12] 1941 	subb	a,r2
      0065FF 40 14            [24] 1942 	jc	00175$
                                   1943 ;	free result
                                   1944 ;	tmk_core/protocol/ch555/usb_ak820.c:292: keyboard_protocol = value;
      006601 90 0D BD         [24] 1945 	mov	dptr,#_keyboard_protocol
      006604 ED               [12] 1946 	mov	a,r5
      006605 F0               [24] 1947 	movx	@dptr,a
                                   1948 ;	tmk_core/protocol/ch555/usb_ak820.c:293: keyboard_reset = 1;
      006606 90 07 BF         [24] 1949 	mov	dptr,#_keyboard_reset
      006609 74 01            [12] 1950 	mov	a,#0x01
      00660B F0               [24] 1951 	movx	@dptr,a
                                   1952 ;	tmk_core/protocol/ch555/usb_ak820.c:294: control_phase = CTRL_STATUS_IN;
      00660C 90 07 F4         [24] 1953 	mov	dptr,#_control_phase
      00660F 74 03            [12] 1954 	mov	a,#0x03
      006611 F0               [24] 1955 	movx	@dptr,a
      006612 02 6A 48         [24] 1956 	ljmp	00291$
      006615                       1957 00175$:
                                   1958 ;	tmk_core/protocol/ch555/usb_ak820.c:295: } else { control_stall(); return; }
      006615 02 60 99         [24] 1959 	ljmp	_control_stall
                                   1960 ;	tmk_core/protocol/ch555/usb_ak820.c:297: case USB_GET_STATUS:
      006618                       1961 00188$:
                                   1962 ;	tmk_core/protocol/ch555/usb_ak820.c:298: if (zero_value && D0SetupLen == 2 &&
      006618 20 17 03         [24] 1963 	jb	_control_setup_zero_value_10000_290,01283$
      00661B 02 60 99         [24] 1964 	ljmp	_control_stall
      00661E                       1965 01283$:
      00661E 90 07 90         [24] 1966 	mov	dptr,#_D0SetupLen
      006621 E0               [24] 1967 	movx	a,@dptr
      006622 F9               [12] 1968 	mov	r1,a
      006623 A3               [24] 1969 	inc	dptr
      006624 E0               [24] 1970 	movx	a,@dptr
      006625 FA               [12] 1971 	mov	r2,a
      006626 B9 02 05         [24] 1972 	cjne	r1,#0x02,01284$
      006629 BA 00 02         [24] 1973 	cjne	r2,#0x00,01284$
      00662C 80 03            [24] 1974 	sjmp	01285$
      00662E                       1975 01284$:
      00662E 02 60 99         [24] 1976 	ljmp	_control_stall
      006631                       1977 01285$:
                                   1978 ;	tmk_core/protocol/ch555/usb_ak820.c:299: ((type == 0x80 && zero_index) || (type == 0x81 && valid_interface && D0UsbConfig) ||
      006631 E4               [12] 1979 	clr	a
      006632 BF 80 01         [24] 1980 	cjne	r7,#0x80,01286$
      006635 04               [12] 1981 	inc	a
      006636                       1982 01286$:
      006636 FA               [12] 1983 	mov	r2,a
      006637 60 03            [24] 1984 	jz	00196$
      006639 20 16 35         [24] 1985 	jb	_control_setup_zero_index_10000_290,00189$
      00663C                       1986 00196$:
      00663C BF 81 09         [24] 1987 	cjne	r7,#0x81,00202$
      00663F 30 15 06         [24] 1988 	jnb	_control_setup_valid_interface_10000_290,00202$
      006642 90 07 95         [24] 1989 	mov	dptr,#_D0UsbConfig
      006645 E0               [24] 1990 	movx	a,@dptr
      006646 70 29            [24] 1991 	jnz	00189$
      006648                       1992 00202$:
                                   1993 ;	tmk_core/protocol/ch555/usb_ak820.c:300: (type == 0x82 && D0UsbConfig && (index == 0 || index == 0x80 || (index >= 0x81 && index <= 0x83))))) {
      006648 BF 82 70         [24] 1994 	cjne	r7,#0x82,00190$
      00664B 90 07 95         [24] 1995 	mov	dptr,#_D0UsbConfig
      00664E E0               [24] 1996 	movx	a,@dptr
      00664F 60 6A            [24] 1997 	jz	00190$
      006651 EB               [12] 1998 	mov	a,r3
      006652 4C               [12] 1999 	orl	a,r4
      006653 60 1C            [24] 2000 	jz	00189$
      006655 8B 00            [24] 2001 	mov	ar0,r3
      006657 8C 01            [24] 2002 	mov	ar1,r4
      006659 B8 80 05         [24] 2003 	cjne	r0,#0x80,01298$
      00665C B9 00 02         [24] 2004 	cjne	r1,#0x00,01298$
      00665F 80 10            [24] 2005 	sjmp	00189$
      006661                       2006 01298$:
      006661 C3               [12] 2007 	clr	c
      006662 E8               [12] 2008 	mov	a,r0
      006663 94 81            [12] 2009 	subb	a,#0x81
      006665 E9               [12] 2010 	mov	a,r1
      006666 94 00            [12] 2011 	subb	a,#0x00
      006668 40 51            [24] 2012 	jc	00190$
      00666A 74 83            [12] 2013 	mov	a,#0x83
      00666C 98               [12] 2014 	subb	a,r0
      00666D E4               [12] 2015 	clr	a
      00666E 99               [12] 2016 	subb	a,r1
      00666F 40 4A            [24] 2017 	jc	00190$
                                   2018 ;	free result
      006671                       2019 00189$:
                                   2020 ;	tmk_core/protocol/ch555/usb_ak820.c:301: endpoint = index & 7;
      006671 8B 01            [24] 2021 	mov	ar1,r3
      006673 53 01 07         [24] 2022 	anl	ar1,#0x07
                                   2023 ;	tmk_core/protocol/ch555/usb_ak820.c:302: pD0_EP0_BUF[0] = type == 0x80 ? ((USB_SleepStatus & 1) << 1) :
      006676 EA               [12] 2024 	mov	a,r2
      006677 60 0B            [24] 2025 	jz	00308$
      006679 90 07 97         [24] 2026 	mov	dptr,#_USB_SleepStatus
      00667C E0               [24] 2027 	movx	a,@dptr
      00667D 54 01            [12] 2028 	anl	a,#0x01
      00667F 25 E0            [12] 2029 	add	a,acc
      006681 FA               [12] 2030 	mov	r2,a
      006682 80 22            [24] 2031 	sjmp	00309$
      006684                       2032 00308$:
                                   2033 ;	tmk_core/protocol/ch555/usb_ak820.c:303: ((type == 0x82 && endpoint && (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_STALL) ? 1 : 0);
      006684 BF 82 1B         [24] 2034 	cjne	r7,#0x82,00310$
      006687 E9               [12] 2035 	mov	a,r1
      006688 60 18            [24] 2036 	jz	00310$
      00668A 89 00            [24] 2037 	mov	ar0,r1
      00668C 79 00            [12] 2038 	mov	r1,#0x00
      00668E 74 22            [12] 2039 	mov	a,#0x22
      006690 29               [12] 2040 	add	a, r1
      006691 F9               [12] 2041 	mov	r1,a
      006692 88 82            [24] 2042 	mov	dpl,r0
      006694 89 83            [24] 2043 	mov	dph,r1
      006696 E0               [24] 2044 	movx	a,@dptr
      006697 F9               [12] 2045 	mov	r1,a
      006698 53 01 03         [24] 2046 	anl	ar1,#0x03
      00669B B9 03 04         [24] 2047 	cjne	r1,#0x03,00310$
      00669E 79 01            [12] 2048 	mov	r1,#0x01
      0066A0 80 02            [24] 2049 	sjmp	00311$
      0066A2                       2050 00310$:
      0066A2 79 00            [12] 2051 	mov	r1,#0x00
      0066A4                       2052 00311$:
      0066A4 89 02            [24] 2053 	mov	ar2,r1
      0066A6                       2054 00309$:
      0066A6 90 10 00         [24] 2055 	mov	dptr,#0x1000
      0066A9 EA               [12] 2056 	mov	a,r2
      0066AA F0               [24] 2057 	movx	@dptr,a
                                   2058 ;	tmk_core/protocol/ch555/usb_ak820.c:304: pD0_EP0_BUF[1] = 0;
      0066AB A3               [24] 2059 	inc	dptr
      0066AC E4               [12] 2060 	clr	a
      0066AD F0               [24] 2061 	movx	@dptr,a
                                   2062 ;	tmk_core/protocol/ch555/usb_ak820.c:305: D0_EP0T_L = 2;
      0066AE 90 22 08         [24] 2063 	mov	dptr,#0x2208
      0066B1 74 02            [12] 2064 	mov	a,#0x02
      0066B3 F0               [24] 2065 	movx	@dptr,a
                                   2066 ;	tmk_core/protocol/ch555/usb_ak820.c:306: control_phase = CTRL_STATUS_OUT;
      0066B4 90 07 F4         [24] 2067 	mov	dptr,#_control_phase
      0066B7 F0               [24] 2068 	movx	@dptr,a
      0066B8 02 6A 48         [24] 2069 	ljmp	00291$
      0066BB                       2070 00190$:
                                   2071 ;	tmk_core/protocol/ch555/usb_ak820.c:307: } else { control_stall(); return; }
      0066BB 02 60 99         [24] 2072 	ljmp	_control_stall
                                   2073 ;	tmk_core/protocol/ch555/usb_ak820.c:310: case USB_SET_FEATURE: /* DEF_USB_GET_PROTOCOL has the same request byte. */
      0066BE                       2074 00205$:
                                   2075 ;	tmk_core/protocol/ch555/usb_ak820.c:311: if (zero_length && D0UsbConfig) {
      0066BE 20 18 03         [24] 2076 	jb	_control_setup_zero_length_10000_290,01307$
      0066C1 02 67 51         [24] 2077 	ljmp	00279$
      0066C4                       2078 01307$:
      0066C4 90 07 95         [24] 2079 	mov	dptr,#_D0UsbConfig
      0066C7 E0               [24] 2080 	movx	a,@dptr
      0066C8 70 03            [24] 2081 	jnz	01308$
      0066CA 02 67 51         [24] 2082 	ljmp	00279$
      0066CD                       2083 01308$:
                                   2084 ;	tmk_core/protocol/ch555/usb_ak820.c:312: if (type == 0x00 && value == 1 && zero_index) {
      0066CD EF               [12] 2085 	mov	a,r7
      0066CE 70 29            [24] 2086 	jnz	00218$
      0066D0 8D 01            [24] 2087 	mov	ar1,r5
      0066D2 8E 02            [24] 2088 	mov	ar2,r6
      0066D4 B9 01 22         [24] 2089 	cjne	r1,#0x01,00218$
      0066D7 BA 00 1F         [24] 2090 	cjne	r2,#0x00,00218$
      0066DA 30 16 1C         [24] 2091 	jnb	_control_setup_zero_index_10000_290,00218$
                                   2092 ;	tmk_core/protocol/ch555/usb_ak820.c:313: if (D0SetupReqCode == USB_SET_FEATURE) USB_SleepStatus |= 1;
      0066DD 90 07 8F         [24] 2093 	mov	dptr,#_D0SetupReqCode
      0066E0 E0               [24] 2094 	movx	a,@dptr
      0066E1 FA               [12] 2095 	mov	r2,a
      0066E2 BA 03 0A         [24] 2096 	cjne	r2,#0x03,00207$
      0066E5 90 07 97         [24] 2097 	mov	dptr,#_USB_SleepStatus
      0066E8 E0               [24] 2098 	movx	a,@dptr
      0066E9 43 E0 01         [24] 2099 	orl	acc,#0x01
      0066EC F0               [24] 2100 	movx	@dptr,a
      0066ED 80 59            [24] 2101 	sjmp	00219$
      0066EF                       2102 00207$:
                                   2103 ;	tmk_core/protocol/ch555/usb_ak820.c:314: else USB_SleepStatus &= ~1;
      0066EF 90 07 97         [24] 2104 	mov	dptr,#_USB_SleepStatus
      0066F2 E0               [24] 2105 	movx	a,@dptr
      0066F3 53 E0 FE         [24] 2106 	anl	acc,#0xfe
      0066F6 F0               [24] 2107 	movx	@dptr,a
      0066F7 80 4F            [24] 2108 	sjmp	00219$
      0066F9                       2109 00218$:
                                   2110 ;	tmk_core/protocol/ch555/usb_ak820.c:315: } else if (type == 0x02 && zero_value && index >= 0x81 && index <= 0x83) {
      0066F9 BF 02 49         [24] 2111 	cjne	r7,#0x02,00212$
      0066FC 30 17 46         [24] 2112 	jnb	_control_setup_zero_value_10000_290,00212$
      0066FF 8B 01            [24] 2113 	mov	ar1,r3
      006701 8C 02            [24] 2114 	mov	ar2,r4
      006703 C3               [12] 2115 	clr	c
      006704 E9               [12] 2116 	mov	a,r1
      006705 94 81            [12] 2117 	subb	a,#0x81
      006707 EA               [12] 2118 	mov	a,r2
      006708 94 00            [12] 2119 	subb	a,#0x00
      00670A 40 39            [24] 2120 	jc	00212$
      00670C 74 83            [12] 2121 	mov	a,#0x83
      00670E 99               [12] 2122 	subb	a,r1
      00670F E4               [12] 2123 	clr	a
      006710 9A               [12] 2124 	subb	a,r2
      006711 40 32            [24] 2125 	jc	00212$
                                   2126 ;	free result
                                   2127 ;	tmk_core/protocol/ch555/usb_ak820.c:316: endpoint = index & 7;
      006713 8B 02            [24] 2128 	mov	ar2,r3
      006715 53 02 07         [24] 2129 	anl	ar2,#0x07
                                   2130 ;	tmk_core/protocol/ch555/usb_ak820.c:318: EP_RESPONSE(endpoint) = bUEP_X_AUTO_TOG | (D0SetupReqCode == USB_SET_FEATURE ? UEP_X_RES_STALL : UEP_X_RES_NAK);
      006718 8A 00            [24] 2131 	mov	ar0,r2
      00671A 79 00            [12] 2132 	mov	r1,#0x00
      00671C 74 22            [12] 2133 	mov	a,#0x22
      00671E 29               [12] 2134 	add	a, r1
      00671F F9               [12] 2135 	mov	r1,a
      006720 88 17            [24] 2136 	mov	_control_setup_sloc3_1_0,r0
      006722 89 18            [24] 2137 	mov	(_control_setup_sloc3_1_0 + 1),r1
      006724 90 07 8F         [24] 2138 	mov	dptr,#_D0SetupReqCode
      006727 E0               [24] 2139 	movx	a,@dptr
      006728 F9               [12] 2140 	mov	r1,a
      006729 B9 03 04         [24] 2141 	cjne	r1,#0x03,00318$
      00672C 79 03            [12] 2142 	mov	r1,#0x03
      00672E 80 02            [24] 2143 	sjmp	00319$
      006730                       2144 00318$:
      006730 79 02            [12] 2145 	mov	r1,#0x02
      006732                       2146 00319$:
      006732 43 01 10         [24] 2147 	orl	ar1,#0x10
      006735 85 17 82         [24] 2148 	mov	dpl,_control_setup_sloc3_1_0
      006738 85 18 83         [24] 2149 	mov	dph,(_control_setup_sloc3_1_0 + 1)
      00673B E9               [12] 2150 	mov	a,r1
      00673C F0               [24] 2151 	movx	@dptr,a
                                   2152 ;	tmk_core/protocol/ch555/usb_ak820.c:319: if (endpoint == RAW_IN_EPNUM) raw_complete();
      00673D BA 03 08         [24] 2153 	cjne	r2,#0x03,00219$
      006740 12 60 1B         [24] 2154 	lcall	_raw_complete
      006743 80 03            [24] 2155 	sjmp	00219$
      006745                       2156 00212$:
                                   2157 ;	tmk_core/protocol/ch555/usb_ak820.c:320: } else { control_stall(); return; }
      006745 02 60 99         [24] 2158 	ljmp	_control_stall
      006748                       2159 00219$:
                                   2160 ;	tmk_core/protocol/ch555/usb_ak820.c:321: control_phase = CTRL_STATUS_IN;
      006748 90 07 F4         [24] 2161 	mov	dptr,#_control_phase
      00674B 74 03            [12] 2162 	mov	a,#0x03
      00674D F0               [24] 2163 	movx	@dptr,a
      00674E 02 6A 48         [24] 2164 	ljmp	00291$
      006751                       2165 00279$:
                                   2166 ;	tmk_core/protocol/ch555/usb_ak820.c:322: } else if (type == 0xa1 && D0SetupReqCode == HID_GET_REPORT && D0UsbConfig && D0SetupLen) {
      006751 E4               [12] 2167 	clr	a
      006752 BF A1 01         [24] 2168 	cjne	r7,#0xa1,01324$
      006755 04               [12] 2169 	inc	a
      006756                       2170 01324$:
      006756 FA               [12] 2171 	mov	r2,a
      006757 70 03            [24] 2172 	jnz	01326$
      006759 02 69 C3         [24] 2173 	ljmp	00273$
      00675C                       2174 01326$:
      00675C 90 07 8F         [24] 2175 	mov	dptr,#_D0SetupReqCode
      00675F E0               [24] 2176 	movx	a,@dptr
      006760 F9               [12] 2177 	mov	r1,a
      006761 B9 01 02         [24] 2178 	cjne	r1,#0x01,01327$
      006764 80 03            [24] 2179 	sjmp	01328$
      006766                       2180 01327$:
      006766 02 69 C3         [24] 2181 	ljmp	00273$
      006769                       2182 01328$:
      006769 90 07 95         [24] 2183 	mov	dptr,#_D0UsbConfig
      00676C E0               [24] 2184 	movx	a,@dptr
      00676D 70 03            [24] 2185 	jnz	01329$
      00676F 02 69 C3         [24] 2186 	ljmp	00273$
      006772                       2187 01329$:
      006772 90 07 90         [24] 2188 	mov	dptr,#_D0SetupLen
      006775 E0               [24] 2189 	movx	a,@dptr
      006776 F8               [12] 2190 	mov	r0,a
      006777 A3               [24] 2191 	inc	dptr
      006778 E0               [24] 2192 	movx	a,@dptr
      006779 48               [12] 2193 	orl	a,r0
      00677A 70 03            [24] 2194 	jnz	01330$
      00677C 02 69 C3         [24] 2195 	ljmp	00273$
      00677F                       2196 01330$:
                                   2197 ;	tmk_core/protocol/ch555/usb_ak820.c:323: report_id = value;
      00677F C0 03            [24] 2198 	push	ar3
      006781 C0 04            [24] 2199 	push	ar4
      006783 8D 01            [24] 2200 	mov	ar1,r5
                                   2201 ;	tmk_core/protocol/ch555/usb_ak820.c:324: if ((value >> 8) == 1 && index == KEYBOARD_INTERFACE && !report_id) {
      006785 8E 00            [24] 2202 	mov	ar0,r6
      006787 B8 01 03         [24] 2203 	cjne	r0,#0x01,01331$
      00678A E8               [12] 2204 	mov	a,r0
      00678B 80 01            [24] 2205 	sjmp	01332$
      00678D                       2206 01331$:
      00678D E4               [12] 2207 	clr	a
      00678E                       2208 01332$:
      00678E F5 17            [12] 2209 	mov	_control_setup_sloc3_1_0,a
      006790 D0 04            [24] 2210 	pop	ar4
      006792 D0 03            [24] 2211 	pop	ar3
      006794 E5 17            [12] 2212 	mov	a,_control_setup_sloc3_1_0
      006796 60 17            [24] 2213 	jz	00251$
      006798 EB               [12] 2214 	mov	a,r3
      006799 4C               [12] 2215 	orl	a,r4
      00679A 70 13            [24] 2216 	jnz	00251$
      00679C E9               [12] 2217 	mov	a,r1
      00679D 70 10            [24] 2218 	jnz	00251$
                                   2219 ;	tmk_core/protocol/ch555/usb_ak820.c:325: length = KEYBOARD_EPSIZE;
      00679F 90 07 FE         [24] 2220 	mov	dptr,#_control_setup_length_10000_290
      0067A2 74 08            [12] 2221 	mov	a,#0x08
      0067A4 F0               [24] 2222 	movx	@dptr,a
      0067A5 E4               [12] 2223 	clr	a
      0067A6 A3               [24] 2224 	inc	dptr
      0067A7 F0               [24] 2225 	movx	@dptr,a
                                   2226 ;	tmk_core/protocol/ch555/usb_ak820.c:326: offset = SNAPSHOT_KEYBOARD;
      0067A8 90 08 00         [24] 2227 	mov	dptr,#_control_setup_offset_10000_290
      0067AB F0               [24] 2228 	movx	@dptr,a
      0067AC 02 69 33         [24] 2229 	ljmp	00252$
      0067AF                       2230 00251$:
                                   2231 ;	tmk_core/protocol/ch555/usb_ak820.c:327: } else if ((value >> 8) == 1 && index == SHARED_INTERFACE &&
      0067AF E5 17            [12] 2232 	mov	a,_control_setup_sloc3_1_0
      0067B1 60 27            [24] 2233 	jz	00245$
      0067B3 BB 02 24         [24] 2234 	cjne	r3,#0x02,00245$
      0067B6 BC 00 21         [24] 2235 	cjne	r4,#0x00,00245$
                                   2236 ;	tmk_core/protocol/ch555/usb_ak820.c:328: report_id < sizeof(shared_lengths) && shared_lengths[report_id]) {
      0067B9 B9 07 00         [24] 2237 	cjne	r1,#0x07,01339$
      0067BC                       2238 01339$:
      0067BC 50 1C            [24] 2239 	jnc	00245$
      0067BE E9               [12] 2240 	mov	a,r1
      0067BF 90 BF 4D         [24] 2241 	mov	dptr,#_shared_lengths
      0067C2 93               [24] 2242 	movc	a,@a+dptr
      0067C3 F8               [12] 2243 	mov	r0,a
      0067C4 60 14            [24] 2244 	jz	00245$
                                   2245 ;	tmk_core/protocol/ch555/usb_ak820.c:329: length = shared_lengths[report_id];
      0067C6 90 07 FE         [24] 2246 	mov	dptr,#_control_setup_length_10000_290
      0067C9 E8               [12] 2247 	mov	a,r0
      0067CA F0               [24] 2248 	movx	@dptr,a
      0067CB E4               [12] 2249 	clr	a
      0067CC A3               [24] 2250 	inc	dptr
      0067CD F0               [24] 2251 	movx	@dptr,a
                                   2252 ;	tmk_core/protocol/ch555/usb_ak820.c:330: offset = shared_offsets[report_id];
      0067CE E9               [12] 2253 	mov	a,r1
      0067CF 90 BF 46         [24] 2254 	mov	dptr,#_shared_offsets
      0067D2 93               [24] 2255 	movc	a,@a+dptr
      0067D3 90 08 00         [24] 2256 	mov	dptr,#_control_setup_offset_10000_290
      0067D6 F0               [24] 2257 	movx	@dptr,a
      0067D7 02 69 33         [24] 2258 	ljmp	00252$
      0067DA                       2259 00245$:
                                   2260 ;	tmk_core/protocol/ch555/usb_ak820.c:331: } else if ((value >> 8) == 1 && index == RAW_INTERFACE && !report_id) {
      0067DA E5 17            [12] 2261 	mov	a,_control_setup_sloc3_1_0
      0067DC 60 7A            [24] 2262 	jz	00240$
      0067DE BB 01 77         [24] 2263 	cjne	r3,#0x01,00240$
      0067E1 BC 00 74         [24] 2264 	cjne	r4,#0x00,00240$
      0067E4 E9               [12] 2265 	mov	a,r1
      0067E5 70 71            [24] 2266 	jnz	00240$
                                   2267 ;	tmk_core/protocol/ch555/usb_ak820.c:332: length = D0SetupLen < RAW_EPSIZE ? D0SetupLen : RAW_EPSIZE;
      0067E7 90 07 90         [24] 2268 	mov	dptr,#_D0SetupLen
      0067EA E0               [24] 2269 	movx	a,@dptr
      0067EB F8               [12] 2270 	mov	r0,a
      0067EC A3               [24] 2271 	inc	dptr
      0067ED E0               [24] 2272 	movx	a,@dptr
      0067EE F9               [12] 2273 	mov	r1,a
      0067EF C3               [12] 2274 	clr	c
      0067F0 E8               [12] 2275 	mov	a,r0
      0067F1 94 20            [12] 2276 	subb	a,#0x20
      0067F3 E9               [12] 2277 	mov	a,r1
      0067F4 94 00            [12] 2278 	subb	a,#0x00
      0067F6 50 0A            [24] 2279 	jnc	00320$
      0067F8 90 07 90         [24] 2280 	mov	dptr,#_D0SetupLen
      0067FB E0               [24] 2281 	movx	a,@dptr
      0067FC F8               [12] 2282 	mov	r0,a
      0067FD A3               [24] 2283 	inc	dptr
      0067FE E0               [24] 2284 	movx	a,@dptr
      0067FF F9               [12] 2285 	mov	r1,a
      006800 80 04            [24] 2286 	sjmp	00321$
      006802                       2287 00320$:
      006802 78 20            [12] 2288 	mov	r0,#0x20
      006804 79 00            [12] 2289 	mov	r1,#0x00
      006806                       2290 00321$:
                                   2291 ;	tmk_core/protocol/ch555/usb_ak820.c:333: for (i = 0; i < length; ++i) pD0_EP0_BUF[i] = pUSB_BUF_DEV0[UX_EP3_ADDR + i];
      006806 75 17 00         [24] 2292 	mov	_control_setup_sloc3_1_0,#0x00
      006809                       2293 00293$:
      006809 C0 03            [24] 2294 	push	ar3
      00680B C0 04            [24] 2295 	push	ar4
      00680D AB 17            [24] 2296 	mov	r3,_control_setup_sloc3_1_0
      00680F 7C 00            [12] 2297 	mov	r4,#0x00
      006811 C3               [12] 2298 	clr	c
      006812 EB               [12] 2299 	mov	a,r3
      006813 98               [12] 2300 	subb	a,r0
      006814 EC               [12] 2301 	mov	a,r4
      006815 99               [12] 2302 	subb	a,r1
      006816 D0 04            [24] 2303 	pop	ar4
      006818 D0 03            [24] 2304 	pop	ar3
      00681A 50 32            [24] 2305 	jnc	00222$
      00681C C0 00            [24] 2306 	push	ar0
      00681E C0 01            [24] 2307 	push	ar1
      006820 85 17 19         [24] 2308 	mov	_control_setup_sloc4_1_0,_control_setup_sloc3_1_0
      006823 74 10            [12] 2309 	mov	a,#0x10
      006825 24 00            [12] 2310 	add	a, #0x00
      006827 F5 1A            [12] 2311 	mov	(_control_setup_sloc4_1_0 + 1),a
      006829 A8 17            [24] 2312 	mov	r0,_control_setup_sloc3_1_0
      00682B 79 00            [12] 2313 	mov	r1,#0x00
      00682D 74 C0            [12] 2314 	mov	a,#0xc0
      00682F 28               [12] 2315 	add	a, r0
      006830 F8               [12] 2316 	mov	r0,a
      006831 E4               [12] 2317 	clr	a
      006832 39               [12] 2318 	addc	a, r1
      006833 F9               [12] 2319 	mov	r1,a
      006834 88 82            [24] 2320 	mov	dpl,r0
      006836 74 10            [12] 2321 	mov	a,#0x10
      006838 29               [12] 2322 	add	a, r1
      006839 F5 83            [12] 2323 	mov	dph,a
      00683B E0               [24] 2324 	movx	a,@dptr
      00683C 85 19 82         [24] 2325 	mov	dpl,_control_setup_sloc4_1_0
      00683F 85 1A 83         [24] 2326 	mov	dph,(_control_setup_sloc4_1_0 + 1)
      006842 F0               [24] 2327 	movx	@dptr,a
      006843 E5 17            [12] 2328 	mov	a,_control_setup_sloc3_1_0
      006845 04               [12] 2329 	inc	a
      006846 F5 17            [12] 2330 	mov	_control_setup_sloc3_1_0,a
      006848 D0 01            [24] 2331 	pop	ar1
      00684A D0 00            [24] 2332 	pop	ar0
      00684C 80 BB            [24] 2333 	sjmp	00293$
      00684E                       2334 00222$:
                                   2335 ;	tmk_core/protocol/ch555/usb_ak820.c:334: length = 0; /* data already copied */
      00684E 90 07 FE         [24] 2336 	mov	dptr,#_control_setup_length_10000_290
      006851 E4               [12] 2337 	clr	a
      006852 F0               [24] 2338 	movx	@dptr,a
      006853 A3               [24] 2339 	inc	dptr
      006854 F0               [24] 2340 	movx	@dptr,a
      006855 02 69 33         [24] 2341 	ljmp	00252$
      006858                       2342 00240$:
                                   2343 ;	tmk_core/protocol/ch555/usb_ak820.c:335: } else if (value == 0x0200 && index == KEYBOARD_INTERFACE) {
      006858 8D 00            [24] 2344 	mov	ar0,r5
      00685A 8E 01            [24] 2345 	mov	ar1,r6
      00685C B8 00 21         [24] 2346 	cjne	r0,#0x00,00236$
      00685F B9 02 1E         [24] 2347 	cjne	r1,#0x02,00236$
      006862 EB               [12] 2348 	mov	a,r3
      006863 4C               [12] 2349 	orl	a,r4
      006864 70 1A            [24] 2350 	jnz	00236$
                                   2351 ;	tmk_core/protocol/ch555/usb_ak820.c:336: pD0_EP0_BUF[0] = KB_USB_SetReport;
      006866 90 07 9A         [24] 2352 	mov	dptr,#_KB_USB_SetReport
      006869 E0               [24] 2353 	movx	a,@dptr
      00686A 90 10 00         [24] 2354 	mov	dptr,#0x1000
      00686D F0               [24] 2355 	movx	@dptr,a
                                   2356 ;	tmk_core/protocol/ch555/usb_ak820.c:337: length = 0;
      00686E 90 07 FE         [24] 2357 	mov	dptr,#_control_setup_length_10000_290
      006871 E4               [12] 2358 	clr	a
      006872 F0               [24] 2359 	movx	@dptr,a
      006873 A3               [24] 2360 	inc	dptr
      006874 F0               [24] 2361 	movx	@dptr,a
                                   2362 ;	tmk_core/protocol/ch555/usb_ak820.c:338: D0SetupLen = 1;
      006875 90 07 90         [24] 2363 	mov	dptr,#_D0SetupLen
      006878 04               [12] 2364 	inc	a
      006879 F0               [24] 2365 	movx	@dptr,a
      00687A E4               [12] 2366 	clr	a
      00687B A3               [24] 2367 	inc	dptr
      00687C F0               [24] 2368 	movx	@dptr,a
      00687D 02 69 33         [24] 2369 	ljmp	00252$
      006880                       2370 00236$:
                                   2371 ;	tmk_core/protocol/ch555/usb_ak820.c:339: } else if (value == (0x0200 | REPORT_ID_NKRO) && index == SHARED_INTERFACE) {
      006880 B8 06 41         [24] 2372 	cjne	r0,#0x06,00232$
      006883 B9 02 3E         [24] 2373 	cjne	r1,#0x02,00232$
      006886 BB 02 3B         [24] 2374 	cjne	r3,#0x02,00232$
      006889 BC 00 38         [24] 2375 	cjne	r4,#0x00,00232$
                                   2376 ;	tmk_core/protocol/ch555/usb_ak820.c:340: pD0_EP0_BUF[0] = REPORT_ID_NKRO;
      00688C C0 03            [24] 2377 	push	ar3
      00688E C0 04            [24] 2378 	push	ar4
      006890 90 10 00         [24] 2379 	mov	dptr,#0x1000
      006893 74 06            [12] 2380 	mov	a,#0x06
      006895 F0               [24] 2381 	movx	@dptr,a
                                   2382 ;	tmk_core/protocol/ch555/usb_ak820.c:341: pD0_EP0_BUF[1] = KB_USB_SetReport;
      006896 90 07 9A         [24] 2383 	mov	dptr,#_KB_USB_SetReport
      006899 E0               [24] 2384 	movx	a,@dptr
      00689A 90 10 01         [24] 2385 	mov	dptr,#0x1001
      00689D F0               [24] 2386 	movx	@dptr,a
                                   2387 ;	tmk_core/protocol/ch555/usb_ak820.c:342: length = 0;
      00689E 90 07 FE         [24] 2388 	mov	dptr,#_control_setup_length_10000_290
      0068A1 E4               [12] 2389 	clr	a
      0068A2 F0               [24] 2390 	movx	@dptr,a
      0068A3 A3               [24] 2391 	inc	dptr
      0068A4 F0               [24] 2392 	movx	@dptr,a
                                   2393 ;	tmk_core/protocol/ch555/usb_ak820.c:343: if (D0SetupLen > 2) D0SetupLen = 2;
      0068A5 90 07 90         [24] 2394 	mov	dptr,#_D0SetupLen
      0068A8 E0               [24] 2395 	movx	a,@dptr
      0068A9 FB               [12] 2396 	mov	r3,a
      0068AA A3               [24] 2397 	inc	dptr
      0068AB E0               [24] 2398 	movx	a,@dptr
      0068AC FC               [12] 2399 	mov	r4,a
      0068AD C3               [12] 2400 	clr	c
      0068AE 74 02            [12] 2401 	mov	a,#0x02
      0068B0 9B               [12] 2402 	subb	a,r3
      0068B1 E4               [12] 2403 	clr	a
      0068B2 9C               [12] 2404 	subb	a,r4
      0068B3 D0 04            [24] 2405 	pop	ar4
      0068B5 D0 03            [24] 2406 	pop	ar3
      0068B7 50 7A            [24] 2407 	jnc	00252$
                                   2408 ;	free result
      0068B9 90 07 90         [24] 2409 	mov	dptr,#_D0SetupLen
      0068BC 74 02            [12] 2410 	mov	a,#0x02
      0068BE F0               [24] 2411 	movx	@dptr,a
      0068BF E4               [12] 2412 	clr	a
      0068C0 A3               [24] 2413 	inc	dptr
      0068C1 F0               [24] 2414 	movx	@dptr,a
      0068C2 80 6F            [24] 2415 	sjmp	00252$
      0068C4                       2416 00232$:
                                   2417 ;	tmk_core/protocol/ch555/usb_ak820.c:344: } else if (value == 0x0300 && index == RAW_INTERFACE) {
      0068C4 B8 00 69         [24] 2418 	cjne	r0,#0x00,00228$
      0068C7 B9 03 66         [24] 2419 	cjne	r1,#0x03,00228$
      0068CA BB 01 63         [24] 2420 	cjne	r3,#0x01,00228$
      0068CD BC 00 60         [24] 2421 	cjne	r4,#0x00,00228$
                                   2422 ;	tmk_core/protocol/ch555/usb_ak820.c:347: pD0_EP0_BUF[0] = 'A';
      0068D0 90 10 00         [24] 2423 	mov	dptr,#0x1000
      0068D3 74 41            [12] 2424 	mov	a,#0x41
      0068D5 F0               [24] 2425 	movx	@dptr,a
                                   2426 ;	tmk_core/protocol/ch555/usb_ak820.c:348: pD0_EP0_BUF[1] = 'K';
      0068D6 A3               [24] 2427 	inc	dptr
      0068D7 74 4B            [12] 2428 	mov	a,#0x4b
      0068D9 F0               [24] 2429 	movx	@dptr,a
                                   2430 ;	tmk_core/protocol/ch555/usb_ak820.c:349: pD0_EP0_BUF[2] = 'B';
      0068DA A3               [24] 2431 	inc	dptr
      0068DB 74 42            [12] 2432 	mov	a,#0x42
      0068DD F0               [24] 2433 	movx	@dptr,a
                                   2434 ;	tmk_core/protocol/ch555/usb_ak820.c:350: pD0_EP0_BUF[3] = 'T';
      0068DE A3               [24] 2435 	inc	dptr
      0068DF 74 54            [12] 2436 	mov	a,#0x54
      0068E1 F0               [24] 2437 	movx	@dptr,a
                                   2438 ;	tmk_core/protocol/ch555/usb_ak820.c:351: pD0_EP0_BUF[4] = 1;
      0068E2 A3               [24] 2439 	inc	dptr
      0068E3 74 01            [12] 2440 	mov	a,#0x01
      0068E5 F0               [24] 2441 	movx	@dptr,a
                                   2442 ;	tmk_core/protocol/ch555/usb_ak820.c:352: pD0_EP0_BUF[5] = ak820_boot_stage;
      0068E6 90 07 9B         [24] 2443 	mov	dptr,#_ak820_boot_stage
      0068E9 E0               [24] 2444 	movx	a,@dptr
      0068EA 90 10 05         [24] 2445 	mov	dptr,#0x1005
      0068ED F0               [24] 2446 	movx	@dptr,a
                                   2447 ;	tmk_core/protocol/ch555/usb_ak820.c:353: pD0_EP0_BUF[6] = ak820_main_heartbeat;
      0068EE 90 07 9C         [24] 2448 	mov	dptr,#_ak820_main_heartbeat
      0068F1 E0               [24] 2449 	movx	a,@dptr
      0068F2 90 10 06         [24] 2450 	mov	dptr,#0x1006
      0068F5 F0               [24] 2451 	movx	@dptr,a
                                   2452 ;	tmk_core/protocol/ch555/usb_ak820.c:354: pD0_EP0_BUF[7] = (USB_EnumStatus ? 1 : 0) | (USB_SleepStatus & 2);
      0068F6 90 07 96         [24] 2453 	mov	dptr,#_USB_EnumStatus
      0068F9 E0               [24] 2454 	movx	a,@dptr
      0068FA 60 02            [24] 2455 	jz	00322$
      0068FC 74 01            [12] 2456 	mov	a,#0x01
      0068FE                       2457 00322$:
      0068FE F9               [12] 2458 	mov	r1,a
      0068FF 90 07 97         [24] 2459 	mov	dptr,#_USB_SleepStatus
      006902 E0               [24] 2460 	movx	a,@dptr
      006903 54 02            [12] 2461 	anl	a,#0x02
      006905 F8               [12] 2462 	mov	r0,a
      006906 E9               [12] 2463 	mov	a,r1
      006907 42 00            [12] 2464 	orl	ar0,a
      006909 90 10 07         [24] 2465 	mov	dptr,#0x1007
      00690C E8               [12] 2466 	mov	a,r0
      00690D F0               [24] 2467 	movx	@dptr,a
                                   2468 ;	tmk_core/protocol/ch555/usb_ak820.c:355: length = 0;
      00690E 90 07 FE         [24] 2469 	mov	dptr,#_control_setup_length_10000_290
      006911 E4               [12] 2470 	clr	a
      006912 F0               [24] 2471 	movx	@dptr,a
      006913 A3               [24] 2472 	inc	dptr
      006914 F0               [24] 2473 	movx	@dptr,a
                                   2474 ;	tmk_core/protocol/ch555/usb_ak820.c:356: if (D0SetupLen > 8) D0SetupLen = 8;
      006915 90 07 90         [24] 2475 	mov	dptr,#_D0SetupLen
      006918 E0               [24] 2476 	movx	a,@dptr
      006919 F8               [12] 2477 	mov	r0,a
      00691A A3               [24] 2478 	inc	dptr
      00691B E0               [24] 2479 	movx	a,@dptr
      00691C F9               [12] 2480 	mov	r1,a
      00691D C3               [12] 2481 	clr	c
      00691E 74 08            [12] 2482 	mov	a,#0x08
      006920 98               [12] 2483 	subb	a,r0
      006921 E4               [12] 2484 	clr	a
      006922 99               [12] 2485 	subb	a,r1
      006923 50 0E            [24] 2486 	jnc	00252$
                                   2487 ;	free result
      006925 90 07 90         [24] 2488 	mov	dptr,#_D0SetupLen
      006928 74 08            [12] 2489 	mov	a,#0x08
      00692A F0               [24] 2490 	movx	@dptr,a
      00692B E4               [12] 2491 	clr	a
      00692C A3               [24] 2492 	inc	dptr
      00692D F0               [24] 2493 	movx	@dptr,a
      00692E 80 03            [24] 2494 	sjmp	00252$
      006930                       2495 00228$:
                                   2496 ;	tmk_core/protocol/ch555/usb_ak820.c:357: } else { control_stall(); return; }
      006930 02 60 99         [24] 2497 	ljmp	_control_stall
      006933                       2498 00252$:
                                   2499 ;	tmk_core/protocol/ch555/usb_ak820.c:358: if (length) {
      006933 90 07 FE         [24] 2500 	mov	dptr,#_control_setup_length_10000_290
      006936 E0               [24] 2501 	movx	a,@dptr
      006937 F5 19            [12] 2502 	mov	_control_setup_sloc4_1_0,a
      006939 A3               [24] 2503 	inc	dptr
      00693A E0               [24] 2504 	movx	a,@dptr
      00693B F5 1A            [12] 2505 	mov	(_control_setup_sloc4_1_0 + 1),a
      00693D E5 19            [12] 2506 	mov	a,_control_setup_sloc4_1_0
      00693F 45 1A            [12] 2507 	orl	a,(_control_setup_sloc4_1_0 + 1)
      006941 60 50            [24] 2508 	jz	00262$
                                   2509 ;	tmk_core/protocol/ch555/usb_ak820.c:359: if (D0SetupLen > length) D0SetupLen = length;
      006943 90 07 90         [24] 2510 	mov	dptr,#_D0SetupLen
      006946 E0               [24] 2511 	movx	a,@dptr
      006947 F8               [12] 2512 	mov	r0,a
      006948 A3               [24] 2513 	inc	dptr
      006949 E0               [24] 2514 	movx	a,@dptr
      00694A F9               [12] 2515 	mov	r1,a
      00694B C3               [12] 2516 	clr	c
      00694C E5 19            [12] 2517 	mov	a,_control_setup_sloc4_1_0
      00694E 98               [12] 2518 	subb	a,r0
      00694F E5 1A            [12] 2519 	mov	a,(_control_setup_sloc4_1_0 + 1)
      006951 99               [12] 2520 	subb	a,r1
      006952 50 0A            [24] 2521 	jnc	00559$
                                   2522 ;	free result
      006954 90 07 90         [24] 2523 	mov	dptr,#_D0SetupLen
      006957 E5 19            [12] 2524 	mov	a,_control_setup_sloc4_1_0
      006959 F0               [24] 2525 	movx	@dptr,a
      00695A E5 1A            [12] 2526 	mov	a,(_control_setup_sloc4_1_0 + 1)
      00695C A3               [24] 2527 	inc	dptr
      00695D F0               [24] 2528 	movx	@dptr,a
                                   2529 ;	tmk_core/protocol/ch555/usb_ak820.c:362: for (i = 0; i < (uint8_t)D0SetupLen; ++i) pD0_EP0_BUF[i] = input_snapshot[offset + i];
      00695E                       2530 00559$:
      00695E 75 19 00         [24] 2531 	mov	_control_setup_sloc4_1_0,#0x00
      006961                       2532 00296$:
      006961 90 07 90         [24] 2533 	mov	dptr,#_D0SetupLen
      006964 E0               [24] 2534 	movx	a,@dptr
      006965 F8               [12] 2535 	mov	r0,a
      006966 C3               [12] 2536 	clr	c
      006967 E5 19            [12] 2537 	mov	a,_control_setup_sloc4_1_0
      006969 98               [12] 2538 	subb	a,r0
      00696A 50 46            [24] 2539 	jnc	00263$
      00696C 85 19 17         [24] 2540 	mov	_control_setup_sloc3_1_0,_control_setup_sloc4_1_0
      00696F 74 10            [12] 2541 	mov	a,#0x10
      006971 24 00            [12] 2542 	add	a, #0x00
      006973 F5 18            [12] 2543 	mov	(_control_setup_sloc3_1_0 + 1),a
      006975 90 08 00         [24] 2544 	mov	dptr,#_control_setup_offset_10000_290
      006978 E0               [24] 2545 	movx	a,@dptr
      006979 25 19            [12] 2546 	add	a, _control_setup_sloc4_1_0
      00697B 24 C0            [12] 2547 	add	a, #_input_snapshot
      00697D F5 82            [12] 2548 	mov	dpl,a
      00697F E4               [12] 2549 	clr	a
      006980 34 07            [12] 2550 	addc	a,#(_input_snapshot >> 8)
      006982 F5 83            [12] 2551 	mov	dph,a
      006984 E0               [24] 2552 	movx	a,@dptr
      006985 85 17 82         [24] 2553 	mov	dpl,_control_setup_sloc3_1_0
      006988 85 18 83         [24] 2554 	mov	dph,(_control_setup_sloc3_1_0 + 1)
      00698B F0               [24] 2555 	movx	@dptr,a
      00698C E5 19            [12] 2556 	mov	a,_control_setup_sloc4_1_0
      00698E 04               [12] 2557 	inc	a
      00698F F5 19            [12] 2558 	mov	_control_setup_sloc4_1_0,a
      006991 80 CE            [24] 2559 	sjmp	00296$
      006993                       2560 00262$:
                                   2561 ;	tmk_core/protocol/ch555/usb_ak820.c:363: } else if (index == RAW_INTERFACE && D0SetupLen > RAW_EPSIZE) D0SetupLen = RAW_EPSIZE;
      006993 BB 01 1C         [24] 2562 	cjne	r3,#0x01,00263$
      006996 BC 00 19         [24] 2563 	cjne	r4,#0x00,00263$
      006999 90 07 90         [24] 2564 	mov	dptr,#_D0SetupLen
      00699C E0               [24] 2565 	movx	a,@dptr
      00699D F8               [12] 2566 	mov	r0,a
      00699E A3               [24] 2567 	inc	dptr
      00699F E0               [24] 2568 	movx	a,@dptr
      0069A0 F9               [12] 2569 	mov	r1,a
      0069A1 C3               [12] 2570 	clr	c
      0069A2 74 20            [12] 2571 	mov	a,#0x20
      0069A4 98               [12] 2572 	subb	a,r0
      0069A5 E4               [12] 2573 	clr	a
      0069A6 99               [12] 2574 	subb	a,r1
      0069A7 50 09            [24] 2575 	jnc	00263$
                                   2576 ;	free result
      0069A9 90 07 90         [24] 2577 	mov	dptr,#_D0SetupLen
      0069AC 74 20            [12] 2578 	mov	a,#0x20
      0069AE F0               [24] 2579 	movx	@dptr,a
      0069AF E4               [12] 2580 	clr	a
      0069B0 A3               [24] 2581 	inc	dptr
      0069B1 F0               [24] 2582 	movx	@dptr,a
      0069B2                       2583 00263$:
                                   2584 ;	tmk_core/protocol/ch555/usb_ak820.c:364: D0_EP0T_L = D0SetupLen;
      0069B2 90 07 90         [24] 2585 	mov	dptr,#_D0SetupLen
      0069B5 E0               [24] 2586 	movx	a,@dptr
      0069B6 90 22 08         [24] 2587 	mov	dptr,#0x2208
      0069B9 F0               [24] 2588 	movx	@dptr,a
                                   2589 ;	tmk_core/protocol/ch555/usb_ak820.c:365: control_phase = CTRL_STATUS_OUT;
      0069BA 90 07 F4         [24] 2590 	mov	dptr,#_control_phase
      0069BD 74 02            [12] 2591 	mov	a,#0x02
      0069BF F0               [24] 2592 	movx	@dptr,a
      0069C0 02 6A 48         [24] 2593 	ljmp	00291$
      0069C3                       2594 00273$:
                                   2595 ;	tmk_core/protocol/ch555/usb_ak820.c:366: } else if (index == KEYBOARD_INTERFACE && D0UsbConfig && type == 0xa1 && D0SetupReqCode == DEF_USB_GET_PROTOCOL && zero_value && D0SetupLen == 1) {
      0069C3 EB               [12] 2596 	mov	a,r3
      0069C4 4C               [12] 2597 	orl	a,r4
      0069C5 70 37            [24] 2598 	jnz	00265$
      0069C7 90 07 95         [24] 2599 	mov	dptr,#_D0UsbConfig
      0069CA E0               [24] 2600 	movx	a,@dptr
      0069CB 60 31            [24] 2601 	jz	00265$
      0069CD EA               [12] 2602 	mov	a,r2
      0069CE 60 2E            [24] 2603 	jz	00265$
      0069D0 90 07 8F         [24] 2604 	mov	dptr,#_D0SetupReqCode
      0069D3 E0               [24] 2605 	movx	a,@dptr
      0069D4 FA               [12] 2606 	mov	r2,a
      0069D5 BA 03 26         [24] 2607 	cjne	r2,#0x03,00265$
      0069D8 30 17 23         [24] 2608 	jnb	_control_setup_zero_value_10000_290,00265$
      0069DB 90 07 90         [24] 2609 	mov	dptr,#_D0SetupLen
      0069DE E0               [24] 2610 	movx	a,@dptr
      0069DF F9               [12] 2611 	mov	r1,a
      0069E0 A3               [24] 2612 	inc	dptr
      0069E1 E0               [24] 2613 	movx	a,@dptr
      0069E2 FA               [12] 2614 	mov	r2,a
      0069E3 B9 01 18         [24] 2615 	cjne	r1,#0x01,00265$
      0069E6 BA 00 15         [24] 2616 	cjne	r2,#0x00,00265$
                                   2617 ;	tmk_core/protocol/ch555/usb_ak820.c:367: pD0_EP0_BUF[0] = keyboard_protocol;
      0069E9 90 0D BD         [24] 2618 	mov	dptr,#_keyboard_protocol
      0069EC E0               [24] 2619 	movx	a,@dptr
      0069ED 90 10 00         [24] 2620 	mov	dptr,#0x1000
      0069F0 F0               [24] 2621 	movx	@dptr,a
                                   2622 ;	tmk_core/protocol/ch555/usb_ak820.c:368: D0_EP0T_L = 1;
      0069F1 90 22 08         [24] 2623 	mov	dptr,#0x2208
      0069F4 74 01            [12] 2624 	mov	a,#0x01
      0069F6 F0               [24] 2625 	movx	@dptr,a
                                   2626 ;	tmk_core/protocol/ch555/usb_ak820.c:369: control_phase = CTRL_STATUS_OUT;
      0069F7 90 07 F4         [24] 2627 	mov	dptr,#_control_phase
      0069FA 04               [12] 2628 	inc	a
      0069FB F0               [24] 2629 	movx	@dptr,a
      0069FC 80 4A            [24] 2630 	sjmp	00291$
      0069FE                       2631 00265$:
                                   2632 ;	tmk_core/protocol/ch555/usb_ak820.c:370: } else { control_stall(); return; }
                                   2633 ;	tmk_core/protocol/ch555/usb_ak820.c:372: case DEF_USB_GET_IDLE:
      0069FE 02 60 99         [24] 2634 	ljmp	_control_stall
      006A01                       2635 00282$:
                                   2636 ;	tmk_core/protocol/ch555/usb_ak820.c:373: if (valid_interface && D0UsbConfig && type == 0xa1 && !(value >> 8) && D0SetupLen == 1) {
      006A01 30 15 3E         [24] 2637 	jnb	_control_setup_valid_interface_10000_290,00284$
      006A04 90 07 95         [24] 2638 	mov	dptr,#_D0UsbConfig
      006A07 E0               [24] 2639 	movx	a,@dptr
      006A08 60 38            [24] 2640 	jz	00284$
      006A0A BF A1 35         [24] 2641 	cjne	r7,#0xa1,00284$
      006A0D 8E 05            [24] 2642 	mov	ar5,r6
      006A0F 7E 00            [12] 2643 	mov	r6,#0x00
      006A11 ED               [12] 2644 	mov	a,r5
      006A12 4E               [12] 2645 	orl	a,r6
      006A13 70 2D            [24] 2646 	jnz	00284$
      006A15 90 07 90         [24] 2647 	mov	dptr,#_D0SetupLen
      006A18 E0               [24] 2648 	movx	a,@dptr
      006A19 FE               [12] 2649 	mov	r6,a
      006A1A A3               [24] 2650 	inc	dptr
      006A1B E0               [24] 2651 	movx	a,@dptr
      006A1C FF               [12] 2652 	mov	r7,a
      006A1D BE 01 22         [24] 2653 	cjne	r6,#0x01,00284$
      006A20 BF 00 1F         [24] 2654 	cjne	r7,#0x00,00284$
                                   2655 ;	tmk_core/protocol/ch555/usb_ak820.c:374: pD0_EP0_BUF[0] = index == KEYBOARD_INTERFACE ? keyboard_idle : 0;
      006A23 EB               [12] 2656 	mov	a,r3
      006A24 4C               [12] 2657 	orl	a,r4
      006A25 70 07            [24] 2658 	jnz	00324$
      006A27 90 06 57         [24] 2659 	mov	dptr,#_keyboard_idle
      006A2A E0               [24] 2660 	movx	a,@dptr
      006A2B FF               [12] 2661 	mov	r7,a
      006A2C 80 02            [24] 2662 	sjmp	00325$
      006A2E                       2663 00324$:
      006A2E 7F 00            [12] 2664 	mov	r7,#0x00
      006A30                       2665 00325$:
      006A30 90 10 00         [24] 2666 	mov	dptr,#0x1000
      006A33 EF               [12] 2667 	mov	a,r7
      006A34 F0               [24] 2668 	movx	@dptr,a
                                   2669 ;	tmk_core/protocol/ch555/usb_ak820.c:375: D0_EP0T_L = 1;
      006A35 90 22 08         [24] 2670 	mov	dptr,#0x2208
      006A38 74 01            [12] 2671 	mov	a,#0x01
      006A3A F0               [24] 2672 	movx	@dptr,a
                                   2673 ;	tmk_core/protocol/ch555/usb_ak820.c:376: control_phase = CTRL_STATUS_OUT;
      006A3B 90 07 F4         [24] 2674 	mov	dptr,#_control_phase
      006A3E 04               [12] 2675 	inc	a
      006A3F F0               [24] 2676 	movx	@dptr,a
      006A40 80 06            [24] 2677 	sjmp	00291$
      006A42                       2678 00284$:
                                   2679 ;	tmk_core/protocol/ch555/usb_ak820.c:377: } else { control_stall(); return; }
                                   2680 ;	tmk_core/protocol/ch555/usb_ak820.c:379: default: control_stall(); return;
      006A42 02 60 99         [24] 2681 	ljmp	_control_stall
      006A45                       2682 00290$:
                                   2683 ;	tmk_core/protocol/ch555/usb_ak820.c:380: }
      006A45 02 60 99         [24] 2684 	ljmp	_control_stall
      006A48                       2685 00291$:
                                   2686 ;	tmk_core/protocol/ch555/usb_ak820.c:381: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_ACK | UEP_T_RES_ACK;
      006A48 90 22 00         [24] 2687 	mov	dptr,#0x2200
      006A4B 74 C0            [12] 2688 	mov	a,#0xc0
      006A4D F0               [24] 2689 	movx	@dptr,a
                                   2690 ;	tmk_core/protocol/ch555/usb_ak820.c:382: }
      006A4E 22               [24] 2691 	ret
                                   2692 ;------------------------------------------------------------
                                   2693 ;Allocation info for local variables in function 'control_out'
                                   2694 ;------------------------------------------------------------
                                   2695 ;i             Allocated with name '_control_out_i_10000_374'
                                   2696 ;------------------------------------------------------------
                                   2697 ;	tmk_core/protocol/ch555/usb_ak820.c:384: static void control_out(void) {
                                   2698 ;	-----------------------------------------
                                   2699 ;	 function control_out
                                   2700 ;	-----------------------------------------
      006A4F                       2701 _control_out:
                                   2702 ;	tmk_core/protocol/ch555/usb_ak820.c:386: if (!(D0_STATUS & bUXS_TOG_OK)) return; /* duplicate OUT is not a new request */
      006A4F 90 22 0F         [24] 2703 	mov	dptr,#0x220f
      006A52 E0               [24] 2704 	movx	a,@dptr
      006A53 20 E6 01         [24] 2705 	jb	acc.6,00102$
      006A56 22               [24] 2706 	ret
      006A57                       2707 00102$:
                                   2708 ;	tmk_core/protocol/ch555/usb_ak820.c:387: if (control_phase == CTRL_STATUS_OUT && D0_RX_LEN == 0) {
      006A57 90 07 F4         [24] 2709 	mov	dptr,#_control_phase
      006A5A E0               [24] 2710 	movx	a,@dptr
      006A5B FF               [12] 2711 	mov	r7,a
      006A5C BF 02 12         [24] 2712 	cjne	r7,#0x02,00104$
      006A5F 90 22 0E         [24] 2713 	mov	dptr,#0x220e
      006A62 E0               [24] 2714 	movx	a,@dptr
      006A63 70 0C            [24] 2715 	jnz	00104$
                                   2716 ;	tmk_core/protocol/ch555/usb_ak820.c:388: control_phase = CTRL_IDLE;
      006A65 90 07 F4         [24] 2717 	mov	dptr,#_control_phase
      006A68 E4               [12] 2718 	clr	a
      006A69 F0               [24] 2719 	movx	@dptr,a
                                   2720 ;	tmk_core/protocol/ch555/usb_ak820.c:389: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      006A6A 90 22 00         [24] 2721 	mov	dptr,#0x2200
      006A6D 74 02            [12] 2722 	mov	a,#0x02
      006A6F F0               [24] 2723 	movx	@dptr,a
                                   2724 ;	tmk_core/protocol/ch555/usb_ak820.c:390: return;
      006A70 22               [24] 2725 	ret
      006A71                       2726 00104$:
                                   2727 ;	tmk_core/protocol/ch555/usb_ak820.c:392: if (control_phase != CTRL_DATA_OUT || D0_RX_LEN != D0SetupLen) { control_stall(); return; }
      006A71 BF 04 19         [24] 2728 	cjne	r7,#0x04,00106$
      006A74 90 22 0E         [24] 2729 	mov	dptr,#0x220e
      006A77 E0               [24] 2730 	movx	a,@dptr
      006A78 FF               [12] 2731 	mov	r7,a
      006A79 90 07 90         [24] 2732 	mov	dptr,#_D0SetupLen
      006A7C E0               [24] 2733 	movx	a,@dptr
      006A7D FD               [12] 2734 	mov	r5,a
      006A7E A3               [24] 2735 	inc	dptr
      006A7F E0               [24] 2736 	movx	a,@dptr
      006A80 FE               [12] 2737 	mov	r6,a
      006A81 7C 00            [12] 2738 	mov	r4,#0x00
      006A83 EF               [12] 2739 	mov	a,r7
      006A84 B5 05 06         [24] 2740 	cjne	a,ar5,00209$
      006A87 EC               [12] 2741 	mov	a,r4
      006A88 B5 06 02         [24] 2742 	cjne	a,ar6,00209$
      006A8B 80 03            [24] 2743 	sjmp	00107$
      006A8D                       2744 00209$:
      006A8D                       2745 00106$:
      006A8D 02 60 99         [24] 2746 	ljmp	_control_stall
      006A90                       2747 00107$:
                                   2748 ;	tmk_core/protocol/ch555/usb_ak820.c:393: if (output_kind == OUTPUT_RAW && raw_state == RAW_RX) {
      006A90 90 07 F5         [24] 2749 	mov	dptr,#_output_kind
      006A93 E0               [24] 2750 	movx	a,@dptr
      006A94 FF               [12] 2751 	mov	r7,a
      006A95 BF 01 2E         [24] 2752 	cjne	r7,#0x01,00118$
      006A98 90 07 9D         [24] 2753 	mov	dptr,#_raw_state
      006A9B E0               [24] 2754 	movx	a,@dptr
      006A9C FE               [12] 2755 	mov	r6,a
      006A9D BE 01 26         [24] 2756 	cjne	r6,#0x01,00118$
                                   2757 ;	tmk_core/protocol/ch555/usb_ak820.c:394: for (i = 0; i < RAW_EPSIZE; ++i) raw_buffer[i] = pD0_EP0_BUF[i];
      006AA0 7E 00            [12] 2758 	mov	r6,#0x00
      006AA2                       2759 00121$:
      006AA2 EE               [12] 2760 	mov	a,r6
      006AA3 24 9E            [12] 2761 	add	a, #_raw_buffer
      006AA5 FC               [12] 2762 	mov	r4,a
      006AA6 E4               [12] 2763 	clr	a
      006AA7 34 07            [12] 2764 	addc	a, #(_raw_buffer >> 8)
      006AA9 FD               [12] 2765 	mov	r5,a
      006AAA 8E 82            [24] 2766 	mov	dpl,r6
      006AAC 74 10            [12] 2767 	mov	a,#0x10
      006AAE 24 00            [12] 2768 	add	a, #0x00
      006AB0 F5 83            [12] 2769 	mov	dph,a
      006AB2 E0               [24] 2770 	movx	a,@dptr
      006AB3 8C 82            [24] 2771 	mov	dpl,r4
      006AB5 8D 83            [24] 2772 	mov	dph,r5
      006AB7 F0               [24] 2773 	movx	@dptr,a
      006AB8 0E               [12] 2774 	inc	r6
      006AB9 BE 20 00         [24] 2775 	cjne	r6,#0x20,00214$
      006ABC                       2776 00214$:
      006ABC 40 E4            [24] 2777 	jc	00121$
                                   2778 ;	tmk_core/protocol/ch555/usb_ak820.c:395: raw_state = RAW_READY; /* publish only after the entire packet is copied */
      006ABE 90 07 9D         [24] 2779 	mov	dptr,#_raw_state
      006AC1 74 02            [12] 2780 	mov	a,#0x02
      006AC3 F0               [24] 2781 	movx	@dptr,a
      006AC4 80 2B            [24] 2782 	sjmp	00119$
      006AC6                       2783 00118$:
                                   2784 ;	tmk_core/protocol/ch555/usb_ak820.c:396: } else if (output_kind == OUTPUT_LED) {
      006AC6 BF 02 0A         [24] 2785 	cjne	r7,#0x02,00115$
                                   2786 ;	tmk_core/protocol/ch555/usb_ak820.c:397: KB_USB_SetReport = pD0_EP0_BUF[0];
      006AC9 90 10 00         [24] 2787 	mov	dptr,#0x1000
      006ACC E0               [24] 2788 	movx	a,@dptr
      006ACD 90 07 9A         [24] 2789 	mov	dptr,#_KB_USB_SetReport
      006AD0 F0               [24] 2790 	movx	@dptr,a
      006AD1 80 1E            [24] 2791 	sjmp	00119$
      006AD3                       2792 00115$:
                                   2793 ;	tmk_core/protocol/ch555/usb_ak820.c:398: } else if (output_kind == OUTPUT_SHARED_LED && pD0_EP0_BUF[0] == output_report_id) {
      006AD3 BF 03 18         [24] 2794 	cjne	r7,#0x03,00111$
      006AD6 90 10 00         [24] 2795 	mov	dptr,#0x1000
      006AD9 E0               [24] 2796 	movx	a,@dptr
      006ADA FF               [12] 2797 	mov	r7,a
      006ADB 90 07 F6         [24] 2798 	mov	dptr,#_output_report_id
      006ADE E0               [24] 2799 	movx	a,@dptr
      006ADF FE               [12] 2800 	mov	r6,a
      006AE0 EF               [12] 2801 	mov	a,r7
      006AE1 B5 06 0A         [24] 2802 	cjne	a,ar6,00111$
                                   2803 ;	tmk_core/protocol/ch555/usb_ak820.c:399: KB_USB_SetReport = pD0_EP0_BUF[1];
      006AE4 90 10 01         [24] 2804 	mov	dptr,#0x1001
      006AE7 E0               [24] 2805 	movx	a,@dptr
      006AE8 90 07 9A         [24] 2806 	mov	dptr,#_KB_USB_SetReport
      006AEB F0               [24] 2807 	movx	@dptr,a
      006AEC 80 03            [24] 2808 	sjmp	00119$
      006AEE                       2809 00111$:
                                   2810 ;	tmk_core/protocol/ch555/usb_ak820.c:400: } else { control_stall(); return; }
      006AEE 02 60 99         [24] 2811 	ljmp	_control_stall
      006AF1                       2812 00119$:
                                   2813 ;	tmk_core/protocol/ch555/usb_ak820.c:401: output_kind = OUTPUT_NONE;
      006AF1 90 07 F5         [24] 2814 	mov	dptr,#_output_kind
      006AF4 E4               [12] 2815 	clr	a
      006AF5 F0               [24] 2816 	movx	@dptr,a
                                   2817 ;	tmk_core/protocol/ch555/usb_ak820.c:402: D0SetupLen = 0;
      006AF6 90 07 90         [24] 2818 	mov	dptr,#_D0SetupLen
      006AF9 F0               [24] 2819 	movx	@dptr,a
      006AFA A3               [24] 2820 	inc	dptr
      006AFB F0               [24] 2821 	movx	@dptr,a
                                   2822 ;	tmk_core/protocol/ch555/usb_ak820.c:403: control_phase = CTRL_STATUS_IN;
      006AFC 90 07 F4         [24] 2823 	mov	dptr,#_control_phase
      006AFF 74 03            [12] 2824 	mov	a,#0x03
      006B01 F0               [24] 2825 	movx	@dptr,a
                                   2826 ;	tmk_core/protocol/ch555/usb_ak820.c:404: D0_EP0T_L = 0;
      006B02 90 22 08         [24] 2827 	mov	dptr,#0x2208
      006B05 E4               [12] 2828 	clr	a
      006B06 F0               [24] 2829 	movx	@dptr,a
                                   2830 ;	tmk_core/protocol/ch555/usb_ak820.c:405: D0_EP0RES = bUEP_T_TOG | UEP_R_RES_NAK | UEP_T_RES_ACK;
      006B07 F5 82            [12] 2831 	mov	dpl,a
      006B09 74 48            [12] 2832 	mov	a,#0x48
      006B0B F0               [24] 2833 	movx	@dptr,a
                                   2834 ;	tmk_core/protocol/ch555/usb_ak820.c:406: }
      006B0C 22               [24] 2835 	ret
                                   2836 ;------------------------------------------------------------
                                   2837 ;Allocation info for local variables in function 'control_in'
                                   2838 ;------------------------------------------------------------
                                   2839 ;	tmk_core/protocol/ch555/usb_ak820.c:408: static void control_in(void) {
                                   2840 ;	-----------------------------------------
                                   2841 ;	 function control_in
                                   2842 ;	-----------------------------------------
      006B0D                       2843 _control_in:
                                   2844 ;	tmk_core/protocol/ch555/usb_ak820.c:409: if (control_phase == CTRL_DATA_IN) {
      006B0D 90 07 F4         [24] 2845 	mov	dptr,#_control_phase
      006B10 E0               [24] 2846 	movx	a,@dptr
      006B11 FF               [12] 2847 	mov	r7,a
      006B12 BF 01 22         [24] 2848 	cjne	r7,#0x01,00109$
                                   2849 ;	tmk_core/protocol/ch555/usb_ak820.c:410: if (D0SetupLen || control_zlp) {
      006B15 90 07 90         [24] 2850 	mov	dptr,#_D0SetupLen
      006B18 E0               [24] 2851 	movx	a,@dptr
      006B19 FD               [12] 2852 	mov	r5,a
      006B1A A3               [24] 2853 	inc	dptr
      006B1B E0               [24] 2854 	movx	a,@dptr
      006B1C 4D               [12] 2855 	orl	a,r5
      006B1D 70 06            [24] 2856 	jnz	00101$
      006B1F 90 07 F7         [24] 2857 	mov	dptr,#_control_zlp
      006B22 E0               [24] 2858 	movx	a,@dptr
      006B23 60 0A            [24] 2859 	jz	00102$
      006B25                       2860 00101$:
                                   2861 ;	tmk_core/protocol/ch555/usb_ak820.c:411: D0_EP0RES ^= bUEP_T_TOG;
      006B25 90 22 00         [24] 2862 	mov	dptr,#0x2200
      006B28 E0               [24] 2863 	movx	a,@dptr
      006B29 64 40            [12] 2864 	xrl	a,#0x40
      006B2B F0               [24] 2865 	movx	@dptr,a
                                   2866 ;	tmk_core/protocol/ch555/usb_ak820.c:412: control_next();
                                   2867 ;	tmk_core/protocol/ch555/usb_ak820.c:413: return;
      006B2C 02 60 BB         [24] 2868 	ljmp	_control_next
      006B2F                       2869 00102$:
                                   2870 ;	tmk_core/protocol/ch555/usb_ak820.c:415: control_phase = CTRL_STATUS_OUT;
      006B2F 90 07 F4         [24] 2871 	mov	dptr,#_control_phase
      006B32 74 02            [12] 2872 	mov	a,#0x02
      006B34 F0               [24] 2873 	movx	@dptr,a
      006B35 80 18            [24] 2874 	sjmp	00110$
      006B37                       2875 00109$:
                                   2876 ;	tmk_core/protocol/ch555/usb_ak820.c:416: } else if (control_phase == CTRL_STATUS_IN) {
      006B37 BF 03 15         [24] 2877 	cjne	r7,#0x03,00110$
                                   2878 ;	tmk_core/protocol/ch555/usb_ak820.c:417: if (D0SetupReqCode == USB_SET_ADDRESS) D0_ADDR = D0SetupLen;
      006B3A 90 07 8F         [24] 2879 	mov	dptr,#_D0SetupReqCode
      006B3D E0               [24] 2880 	movx	a,@dptr
      006B3E FF               [12] 2881 	mov	r7,a
      006B3F BF 05 08         [24] 2882 	cjne	r7,#0x05,00105$
      006B42 90 07 90         [24] 2883 	mov	dptr,#_D0SetupLen
      006B45 E0               [24] 2884 	movx	a,@dptr
      006B46 90 22 07         [24] 2885 	mov	dptr,#0x2207
      006B49 F0               [24] 2886 	movx	@dptr,a
      006B4A                       2887 00105$:
                                   2888 ;	tmk_core/protocol/ch555/usb_ak820.c:418: control_phase = CTRL_IDLE;
      006B4A 90 07 F4         [24] 2889 	mov	dptr,#_control_phase
      006B4D E4               [12] 2890 	clr	a
      006B4E F0               [24] 2891 	movx	@dptr,a
      006B4F                       2892 00110$:
                                   2893 ;	tmk_core/protocol/ch555/usb_ak820.c:420: D0_EP0RES = bUEP_R_TOG | UEP_R_RES_ACK | UEP_T_RES_NAK;
      006B4F 90 22 00         [24] 2894 	mov	dptr,#0x2200
      006B52 74 82            [12] 2895 	mov	a,#0x82
      006B54 F0               [24] 2896 	movx	@dptr,a
                                   2897 ;	tmk_core/protocol/ch555/usb_ak820.c:421: }
      006B55 22               [24] 2898 	ret
                                   2899 ;------------------------------------------------------------
                                   2900 ;Allocation info for local variables in function 'USB_DeviceInterrupt'
                                   2901 ;------------------------------------------------------------
                                   2902 ;status        Allocated with name '_USB_DeviceInterrupt_status_10000_398'
                                   2903 ;endpoint      Allocated with name '_USB_DeviceInterrupt_endpoint_10000_398'
                                   2904 ;------------------------------------------------------------
                                   2905 ;	tmk_core/protocol/ch555/usb_ak820.c:423: void USB_DeviceInterrupt(void) {
                                   2906 ;	-----------------------------------------
                                   2907 ;	 function USB_DeviceInterrupt
                                   2908 ;	-----------------------------------------
      006B56                       2909 _USB_DeviceInterrupt:
                                   2910 ;	tmk_core/protocol/ch555/usb_ak820.c:426: do {
      006B56                       2911 00129$:
                                   2912 ;	tmk_core/protocol/ch555/usb_ak820.c:428: if (USB_IF & bUX_IF_BUS_RST) {
      006B56 90 22 3D         [24] 2913 	mov	dptr,#0x223d
      006B59 E0               [24] 2914 	movx	a,@dptr
      006B5A 30 E0 4B         [24] 2915 	jnb	acc.0,00127$
                                   2916 ;	tmk_core/protocol/ch555/usb_ak820.c:429: endpoints_reset();
      006B5D 12 60 38         [24] 2917 	lcall	_endpoints_reset
                                   2918 ;	tmk_core/protocol/ch555/usb_ak820.c:430: D0_ADDR = 0;
      006B60 90 22 07         [24] 2919 	mov	dptr,#0x2207
      006B63 E4               [12] 2920 	clr	a
      006B64 F0               [24] 2921 	movx	@dptr,a
                                   2922 ;	tmk_core/protocol/ch555/usb_ak820.c:431: D0UsbConfig = USB_EnumStatus = USB_SleepStatus = 0;
      006B65 90 07 97         [24] 2923 	mov	dptr,#_USB_SleepStatus
      006B68 F0               [24] 2924 	movx	@dptr,a
      006B69 90 07 96         [24] 2925 	mov	dptr,#_USB_EnumStatus
      006B6C F0               [24] 2926 	movx	@dptr,a
      006B6D 90 07 95         [24] 2927 	mov	dptr,#_D0UsbConfig
      006B70 F0               [24] 2928 	movx	@dptr,a
                                   2929 ;	tmk_core/protocol/ch555/usb_ak820.c:432: KB_USB_SetReport = 0;
      006B71 90 07 9A         [24] 2930 	mov	dptr,#_KB_USB_SetReport
      006B74 F0               [24] 2931 	movx	@dptr,a
                                   2932 ;	tmk_core/protocol/ch555/usb_ak820.c:433: keyboard_protocol = 1;
      006B75 90 0D BD         [24] 2933 	mov	dptr,#_keyboard_protocol
      006B78 04               [12] 2934 	inc	a
      006B79 F0               [24] 2935 	movx	@dptr,a
                                   2936 ;	tmk_core/protocol/ch555/usb_ak820.c:434: keyboard_idle = 0;
      006B7A 90 06 57         [24] 2937 	mov	dptr,#_keyboard_idle
      006B7D E4               [12] 2938 	clr	a
      006B7E F0               [24] 2939 	movx	@dptr,a
                                   2940 ;	tmk_core/protocol/ch555/usb_ak820.c:435: keyboard_reset = 1;
      006B7F 90 07 BF         [24] 2941 	mov	dptr,#_keyboard_reset
      006B82 04               [12] 2942 	inc	a
      006B83 F0               [24] 2943 	movx	@dptr,a
                                   2944 ;	tmk_core/protocol/ch555/usb_ak820.c:436: D0SetupReqCode = 0xff;
      006B84 90 07 8F         [24] 2945 	mov	dptr,#_D0SetupReqCode
      006B87 74 FF            [12] 2946 	mov	a,#0xff
      006B89 F0               [24] 2947 	movx	@dptr,a
                                   2948 ;	tmk_core/protocol/ch555/usb_ak820.c:437: D0SetupLen = 0;
      006B8A 90 07 90         [24] 2949 	mov	dptr,#_D0SetupLen
      006B8D E4               [12] 2950 	clr	a
      006B8E F0               [24] 2951 	movx	@dptr,a
      006B8F A3               [24] 2952 	inc	dptr
      006B90 F0               [24] 2953 	movx	@dptr,a
                                   2954 ;	tmk_core/protocol/ch555/usb_ak820.c:438: control_phase = CTRL_IDLE;
      006B91 90 07 F4         [24] 2955 	mov	dptr,#_control_phase
      006B94 F0               [24] 2956 	movx	@dptr,a
                                   2957 ;	tmk_core/protocol/ch555/usb_ak820.c:439: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      006B95 90 22 00         [24] 2958 	mov	dptr,#0x2200
      006B98 74 02            [12] 2959 	mov	a,#0x02
      006B9A F0               [24] 2960 	movx	@dptr,a
                                   2961 ;	tmk_core/protocol/ch555/usb_ak820.c:440: ACK_TRANSFER();
      006B9B 90 22 0F         [24] 2962 	mov	dptr,#0x220f
      006B9E E4               [12] 2963 	clr	a
      006B9F F0               [24] 2964 	movx	@dptr,a
                                   2965 ;	tmk_core/protocol/ch555/usb_ak820.c:441: ACK_RESET();
      006BA0 90 22 3D         [24] 2966 	mov	dptr,#0x223d
      006BA3 04               [12] 2967 	inc	a
      006BA4 F0               [24] 2968 	movx	@dptr,a
      006BA5 02 6C 40         [24] 2969 	ljmp	00130$
      006BA8                       2970 00127$:
                                   2971 ;	tmk_core/protocol/ch555/usb_ak820.c:442: } else if (USB_IF & bUX_IF_D0_TRANS) {
      006BA8 90 22 3D         [24] 2972 	mov	dptr,#0x223d
      006BAB E0               [24] 2973 	movx	a,@dptr
      006BAC 30 E5 60         [24] 2974 	jnb	acc.5,00124$
                                   2975 ;	tmk_core/protocol/ch555/usb_ak820.c:443: status = D0_STATUS;
      006BAF 90 22 0F         [24] 2976 	mov	dptr,#0x220f
      006BB2 E0               [24] 2977 	movx	a,@dptr
      006BB3 FF               [12] 2978 	mov	r7,a
                                   2979 ;	tmk_core/protocol/ch555/usb_ak820.c:444: endpoint = status & MASK_UXS_ENDP;
      006BB4 74 07            [12] 2980 	mov	a,#0x07
      006BB6 5F               [12] 2981 	anl	a,r7
      006BB7 FE               [12] 2982 	mov	r6,a
                                   2983 ;	tmk_core/protocol/ch555/usb_ak820.c:448: if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_OUT && !endpoint) {
      006BB8 EF               [12] 2984 	mov	a,r7
      006BB9 54 18            [12] 2985 	anl	a,#0x18
      006BBB 70 08            [24] 2986 	jnz	00115$
      006BBD EE               [12] 2987 	mov	a,r6
      006BBE 70 05            [24] 2988 	jnz	00115$
                                   2989 ;	tmk_core/protocol/ch555/usb_ak820.c:449: control_out();
      006BC0 12 6A 4F         [24] 2990 	lcall	_control_out
      006BC3 80 43            [24] 2991 	sjmp	00116$
      006BC5                       2992 00115$:
                                   2993 ;	tmk_core/protocol/ch555/usb_ak820.c:450: } else if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_IN) {
      006BC5 8F 05            [24] 2994 	mov	ar5,r7
      006BC7 74 18            [12] 2995 	mov	a,#0x18
      006BC9 5D               [12] 2996 	anl	a,r5
      006BCA FC               [12] 2997 	mov	r4,a
      006BCB BC 10 2D         [24] 2998 	cjne	r4,#0x10,00112$
                                   2999 ;	tmk_core/protocol/ch555/usb_ak820.c:451: if (!endpoint) control_in();
      006BCE EE               [12] 3000 	mov	a,r6
      006BCF 70 05            [24] 3001 	jnz	00106$
      006BD1 12 6B 0D         [24] 3002 	lcall	_control_in
      006BD4 80 32            [24] 3003 	sjmp	00116$
      006BD6                       3004 00106$:
                                   3005 ;	tmk_core/protocol/ch555/usb_ak820.c:452: else if (endpoint <= 3) {
      006BD6 EE               [12] 3006 	mov	a,r6
      006BD7 24 FC            [12] 3007 	add	a,#0xff - 0x03
      006BD9 40 2D            [24] 3008 	jc	00116$
                                   3009 ;	free result
                                   3010 ;	tmk_core/protocol/ch555/usb_ak820.c:453: EP_RESPONSE(endpoint) = (EP_RESPONSE(endpoint) & ~MASK_UEP_X_RES) | UEP_X_RES_NAK;
      006BDB 8E 04            [24] 3011 	mov	ar4,r6
      006BDD 7B 00            [12] 3012 	mov	r3,#0x00
      006BDF 74 22            [12] 3013 	mov	a,#0x22
      006BE1 2B               [12] 3014 	add	a, r3
      006BE2 FB               [12] 3015 	mov	r3,a
      006BE3 8C 82            [24] 3016 	mov	dpl,r4
      006BE5 8B 83            [24] 3017 	mov	dph,r3
      006BE7 E0               [24] 3018 	movx	a,@dptr
      006BE8 FA               [12] 3019 	mov	r2,a
      006BE9 74 FC            [12] 3020 	mov	a,#0xfc
      006BEB 5A               [12] 3021 	anl	a,r2
      006BEC 44 02            [12] 3022 	orl	a,#0x02
      006BEE 8C 82            [24] 3023 	mov	dpl,r4
      006BF0 8B 83            [24] 3024 	mov	dph,r3
      006BF2 F0               [24] 3025 	movx	@dptr,a
                                   3026 ;	tmk_core/protocol/ch555/usb_ak820.c:454: if (endpoint == RAW_IN_EPNUM) raw_complete();
      006BF3 BE 03 12         [24] 3027 	cjne	r6,#0x03,00116$
      006BF6 12 60 1B         [24] 3028 	lcall	_raw_complete
      006BF9 80 0D            [24] 3029 	sjmp	00116$
      006BFB                       3030 00112$:
                                   3031 ;	tmk_core/protocol/ch555/usb_ak820.c:456: } else if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_FREE && (status & bUXS_SETUP_ACT)) {
      006BFB 53 05 18         [24] 3032 	anl	ar5,#0x18
      006BFE BD 18 07         [24] 3033 	cjne	r5,#0x18,00116$
      006C01 EF               [12] 3034 	mov	a,r7
      006C02 30 E5 03         [24] 3035 	jnb	acc.5,00116$
                                   3036 ;	tmk_core/protocol/ch555/usb_ak820.c:457: control_setup();
      006C05 12 62 B2         [24] 3037 	lcall	_control_setup
      006C08                       3038 00116$:
                                   3039 ;	tmk_core/protocol/ch555/usb_ak820.c:459: ACK_TRANSFER();
      006C08 90 22 0F         [24] 3040 	mov	dptr,#0x220f
      006C0B E4               [12] 3041 	clr	a
      006C0C F0               [24] 3042 	movx	@dptr,a
      006C0D 80 31            [24] 3043 	sjmp	00130$
      006C0F                       3044 00124$:
                                   3045 ;	tmk_core/protocol/ch555/usb_ak820.c:460: } else if (USB_IF & bUX_IF_SUSPEND) {
      006C0F 90 22 3D         [24] 3046 	mov	dptr,#0x223d
      006C12 E0               [24] 3047 	movx	a,@dptr
      006C13 30 E2 2A         [24] 3048 	jnb	acc.2,00130$
                                   3049 ;	tmk_core/protocol/ch555/usb_ak820.c:462: ak820_os_indicator_mode = AK820_OS_NORMAL;
      006C16 90 05 AA         [24] 3050 	mov	dptr,#_ak820_os_indicator_mode
      006C19 E4               [12] 3051 	clr	a
      006C1A F0               [24] 3052 	movx	@dptr,a
                                   3053 ;	tmk_core/protocol/ch555/usb_ak820.c:464: if (USB_IF & bUX_SUSPEND) USB_SleepStatus |= 2;
      006C1B 90 22 3D         [24] 3054 	mov	dptr,#0x223d
      006C1E E0               [24] 3055 	movx	a,@dptr
      006C1F 30 E3 0A         [24] 3056 	jnb	acc.3,00119$
      006C22 90 07 97         [24] 3057 	mov	dptr,#_USB_SleepStatus
      006C25 E0               [24] 3058 	movx	a,@dptr
      006C26 43 E0 02         [24] 3059 	orl	acc,#0x02
      006C29 F0               [24] 3060 	movx	@dptr,a
      006C2A 80 0E            [24] 3061 	sjmp	00120$
      006C2C                       3062 00119$:
                                   3063 ;	tmk_core/protocol/ch555/usb_ak820.c:466: USB_SleepStatus &= ~2;
      006C2C 90 07 97         [24] 3064 	mov	dptr,#_USB_SleepStatus
      006C2F E0               [24] 3065 	movx	a,@dptr
      006C30 53 E0 FD         [24] 3066 	anl	acc,#0xfd
      006C33 F0               [24] 3067 	movx	@dptr,a
                                   3068 ;	tmk_core/protocol/ch555/usb_ak820.c:467: keyboard_reset = 1;
      006C34 90 07 BF         [24] 3069 	mov	dptr,#_keyboard_reset
      006C37 74 01            [12] 3070 	mov	a,#0x01
      006C39 F0               [24] 3071 	movx	@dptr,a
      006C3A                       3072 00120$:
                                   3073 ;	tmk_core/protocol/ch555/usb_ak820.c:469: ACK_SUSPEND();
      006C3A 90 22 3D         [24] 3074 	mov	dptr,#0x223d
      006C3D 74 04            [12] 3075 	mov	a,#0x04
      006C3F F0               [24] 3076 	movx	@dptr,a
      006C40                       3077 00130$:
                                   3078 ;	tmk_core/protocol/ch555/usb_ak820.c:471: } while (USB_IF & (bUX_IF_BUS_RST | bUX_IF_D0_TRANS | bUX_IF_SUSPEND));
      006C40 90 22 3D         [24] 3079 	mov	dptr,#0x223d
      006C43 E0               [24] 3080 	movx	a,@dptr
      006C44 54 25            [12] 3081 	anl	a,#0x25
      006C46 60 03            [24] 3082 	jz	00242$
      006C48 02 6B 56         [24] 3083 	ljmp	00129$
      006C4B                       3084 00242$:
                                   3085 ;	tmk_core/protocol/ch555/usb_ak820.c:472: }
      006C4B 22               [24] 3086 	ret
                                   3087 ;------------------------------------------------------------
                                   3088 ;Allocation info for local variables in function 'USB_Device_Init'
                                   3089 ;------------------------------------------------------------
                                   3090 ;	tmk_core/protocol/ch555/usb_ak820.c:475: void USB_Device_Init(void) {
                                   3091 ;	-----------------------------------------
                                   3092 ;	 function USB_Device_Init
                                   3093 ;	-----------------------------------------
      006C4C                       3094 _USB_Device_Init:
                                   3095 ;	tmk_core/protocol/ch555/usb_ak820.c:476: IE_USB = 0;
                                   3096 ;	assignBit
      006C4C C2 E9            [12] 3097 	clr	_IE_USB
                                   3098 ;	tmk_core/protocol/ch555/usb_ak820.c:477: USB_CTRL = 0;
      006C4E 90 22 3C         [24] 3099 	mov	dptr,#0x223c
      006C51 E4               [12] 3100 	clr	a
      006C52 F0               [24] 3101 	movx	@dptr,a
                                   3102 ;	tmk_core/protocol/ch555/usb_ak820.c:478: raw_state = RAW_IDLE;
      006C53 90 07 9D         [24] 3103 	mov	dptr,#_raw_state
      006C56 F0               [24] 3104 	movx	@dptr,a
                                   3105 ;	tmk_core/protocol/ch555/usb_ak820.c:479: endpoints_reset();
      006C57 12 60 38         [24] 3106 	lcall	_endpoints_reset
                                   3107 ;	tmk_core/protocol/ch555/usb_ak820.c:480: D0_ADDR = D0UsbConfig = USB_EnumStatus = USB_SleepStatus = 0;
      006C5A 90 07 97         [24] 3108 	mov	dptr,#_USB_SleepStatus
      006C5D E4               [12] 3109 	clr	a
      006C5E F0               [24] 3110 	movx	@dptr,a
      006C5F 90 07 96         [24] 3111 	mov	dptr,#_USB_EnumStatus
      006C62 F0               [24] 3112 	movx	@dptr,a
      006C63 90 07 95         [24] 3113 	mov	dptr,#_D0UsbConfig
      006C66 F0               [24] 3114 	movx	@dptr,a
      006C67 90 22 07         [24] 3115 	mov	dptr,#0x2207
      006C6A F0               [24] 3116 	movx	@dptr,a
                                   3117 ;	tmk_core/protocol/ch555/usb_ak820.c:481: KB_USB_SetReport = KB_USB_UpStatus = MCU_Sleep_Operate = 0;
      006C6B 90 07 98         [24] 3118 	mov	dptr,#_MCU_Sleep_Operate
      006C6E F0               [24] 3119 	movx	@dptr,a
      006C6F 90 07 99         [24] 3120 	mov	dptr,#_KB_USB_UpStatus
      006C72 F0               [24] 3121 	movx	@dptr,a
      006C73 90 07 9A         [24] 3122 	mov	dptr,#_KB_USB_SetReport
      006C76 F0               [24] 3123 	movx	@dptr,a
                                   3124 ;	tmk_core/protocol/ch555/usb_ak820.c:482: keyboard_protocol = 1;
      006C77 90 0D BD         [24] 3125 	mov	dptr,#_keyboard_protocol
      006C7A 04               [12] 3126 	inc	a
      006C7B F0               [24] 3127 	movx	@dptr,a
                                   3128 ;	tmk_core/protocol/ch555/usb_ak820.c:483: keyboard_idle = 0;
      006C7C 90 06 57         [24] 3129 	mov	dptr,#_keyboard_idle
      006C7F E4               [12] 3130 	clr	a
      006C80 F0               [24] 3131 	movx	@dptr,a
                                   3132 ;	tmk_core/protocol/ch555/usb_ak820.c:484: keyboard_reset = 0;
      006C81 90 07 BF         [24] 3133 	mov	dptr,#_keyboard_reset
      006C84 F0               [24] 3134 	movx	@dptr,a
                                   3135 ;	tmk_core/protocol/ch555/usb_ak820.c:485: control_phase = CTRL_IDLE;
      006C85 90 07 F4         [24] 3136 	mov	dptr,#_control_phase
      006C88 F0               [24] 3137 	movx	@dptr,a
                                   3138 ;	tmk_core/protocol/ch555/usb_ak820.c:486: D0SetupReqCode = 0xff;
      006C89 90 07 8F         [24] 3139 	mov	dptr,#_D0SetupReqCode
      006C8C 14               [12] 3140 	dec	a
      006C8D F0               [24] 3141 	movx	@dptr,a
                                   3142 ;	tmk_core/protocol/ch555/usb_ak820.c:487: D0SetupLen = 0;
      006C8E 90 07 90         [24] 3143 	mov	dptr,#_D0SetupLen
      006C91 E4               [12] 3144 	clr	a
      006C92 F0               [24] 3145 	movx	@dptr,a
      006C93 A3               [24] 3146 	inc	dptr
      006C94 F0               [24] 3147 	movx	@dptr,a
                                   3148 ;	tmk_core/protocol/ch555/usb_ak820.c:488: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      006C95 90 22 00         [24] 3149 	mov	dptr,#0x2200
      006C98 74 02            [12] 3150 	mov	a,#0x02
      006C9A F0               [24] 3151 	movx	@dptr,a
                                   3152 ;	tmk_core/protocol/ch555/usb_ak820.c:489: HB_ADDR = 0x7f;
      006C9B 90 22 37         [24] 3153 	mov	dptr,#0x2237
      006C9E 74 7F            [12] 3154 	mov	a,#0x7f
      006CA0 F0               [24] 3155 	movx	@dptr,a
                                   3156 ;	tmk_core/protocol/ch555/usb_ak820.c:490: ACK_ALL();
      006CA1 90 22 3D         [24] 3157 	mov	dptr,#0x223d
      006CA4 74 FF            [12] 3158 	mov	a,#0xff
      006CA6 F0               [24] 3159 	movx	@dptr,a
                                   3160 ;	tmk_core/protocol/ch555/usb_ak820.c:491: USB_IE = bUX_IE_SUSPEND | bUX_IE_TRANSFER | bUX_IE_BUS_RST;
      006CA7 90 22 3B         [24] 3161 	mov	dptr,#0x223b
      006CAA 74 07            [12] 3162 	mov	a,#0x07
      006CAC F0               [24] 3163 	movx	@dptr,a
                                   3164 ;	tmk_core/protocol/ch555/usb_ak820.c:492: USB_CTRL = bUX_DP_PU_EN;
      006CAD A3               [24] 3165 	inc	dptr
      006CAE 74 80            [12] 3166 	mov	a,#0x80
      006CB0 F0               [24] 3167 	movx	@dptr,a
                                   3168 ;	tmk_core/protocol/ch555/usb_ak820.c:493: IE_USB = 1;
                                   3169 ;	assignBit
      006CB1 D2 E9            [12] 3170 	setb	_IE_USB
                                   3171 ;	tmk_core/protocol/ch555/usb_ak820.c:494: }
      006CB3 22               [24] 3172 	ret
                                   3173 ;------------------------------------------------------------
                                   3174 ;Allocation info for local variables in function 'USB_WakeUp_PC'
                                   3175 ;------------------------------------------------------------
                                   3176 ;saved         Allocated with name '_USB_WakeUp_PC_saved_10000_421'
                                   3177 ;i             Allocated with name '_USB_WakeUp_PC_i_30000_424'
                                   3178 ;------------------------------------------------------------
                                   3179 ;	tmk_core/protocol/ch555/usb_ak820.c:496: void USB_WakeUp_PC(void) {
                                   3180 ;	-----------------------------------------
                                   3181 ;	 function USB_WakeUp_PC
                                   3182 ;	-----------------------------------------
      006CB4                       3183 _USB_WakeUp_PC:
                                   3184 ;	tmk_core/protocol/ch555/usb_ak820.c:498: if (USB_SleepStatus != 3) return;
      006CB4 90 07 97         [24] 3185 	mov	dptr,#_USB_SleepStatus
      006CB7 E0               [24] 3186 	movx	a,@dptr
      006CB8 FF               [12] 3187 	mov	r7,a
      006CB9 BF 03 22         [24] 3188 	cjne	r7,#0x03,00110$
                                   3189 ;	tmk_core/protocol/ch555/usb_ak820.c:499: saved = USB_CTRL;
      006CBC 90 22 3C         [24] 3190 	mov	dptr,#0x223c
      006CBF E0               [24] 3191 	movx	a,@dptr
      006CC0 FF               [12] 3192 	mov	r7,a
                                   3193 ;	tmk_core/protocol/ch555/usb_ak820.c:500: USB_CTRL ^= bUX_DP_PU_EN | bUX_DM_PU_EN;
      006CC1 E0               [24] 3194 	movx	a,@dptr
      006CC2 FE               [12] 3195 	mov	r6,a
      006CC3 63 06 C0         [24] 3196 	xrl	ar6,#0xc0
      006CC6 90 22 3C         [24] 3197 	mov	dptr,#0x223c
      006CC9 EE               [12] 3198 	mov	a,r6
      006CCA F0               [24] 3199 	movx	@dptr,a
                                   3200 ;	tmk_core/protocol/ch555/usb_ak820.c:501: wait_ms(10);
      006CCB 7E 0A            [12] 3201 	mov	r6,#0x0a
      006CCD                       3202 00108$:
      006CCD EE               [12] 3203 	mov	a,r6
      006CCE 60 09            [24] 3204 	jz	00105$
      006CD0 90 00 01         [24] 3205 	mov	dptr,#0x0001
      006CD3 12 5E 7F         [24] 3206 	lcall	_mDelaymS
      006CD6 1E               [12] 3207 	dec	r6
      006CD7 80 F4            [24] 3208 	sjmp	00108$
      006CD9                       3209 00105$:
                                   3210 ;	tmk_core/protocol/ch555/usb_ak820.c:502: USB_CTRL = saved;
      006CD9 90 22 3C         [24] 3211 	mov	dptr,#0x223c
      006CDC EF               [12] 3212 	mov	a,r7
      006CDD F0               [24] 3213 	movx	@dptr,a
      006CDE                       3214 00110$:
                                   3215 ;	tmk_core/protocol/ch555/usb_ak820.c:503: }
      006CDE 22               [24] 3216 	ret
                                   3217 ;------------------------------------------------------------
                                   3218 ;Allocation info for local variables in function 'ak820_usb_send'
                                   3219 ;------------------------------------------------------------
                                   3220 ;sloc0         Allocated with name '_ak820_usb_send_sloc0_1_0'
                                   3221 ;sloc1         Allocated with name '_ak820_usb_send_sloc1_1_0'
                                   3222 ;report        Allocated with name '_ak820_usb_send_PARM_2'
                                   3223 ;length        Allocated with name '_ak820_usb_send_PARM_3'
                                   3224 ;endpoint      Allocated with name '_ak820_usb_send_endpoint_10000_426'
                                   3225 ;saved_ea      Allocated with name '_ak820_usb_send_saved_ea_10000_427'
                                   3226 ;i             Allocated with name '_ak820_usb_send_i_10000_427'
                                   3227 ;timeout       Allocated with name '_ak820_usb_send_timeout_10000_427'
                                   3228 ;offset        Allocated with name '_ak820_usb_send_offset_10000_427'
                                   3229 ;report_id     Allocated with name '_ak820_usb_send_report_id_10000_427'
                                   3230 ;i             Allocated with name '_ak820_usb_send_i_30000_439'
                                   3231 ;------------------------------------------------------------
                                   3232 ;	tmk_core/protocol/ch555/usb_ak820.c:505: bool ak820_usb_send(uint8_t endpoint, const uint8_t __xdata *report, uint8_t length) {
                                   3233 ;	-----------------------------------------
                                   3234 ;	 function ak820_usb_send
                                   3235 ;	-----------------------------------------
      006CDF                       3236 _ak820_usb_send:
      006CDF E5 82            [12] 3237 	mov	a,dpl
      006CE1 90 08 04         [24] 3238 	mov	dptr,#_ak820_usb_send_endpoint_10000_426
      006CE4 F0               [24] 3239 	movx	@dptr,a
                                   3240 ;	tmk_core/protocol/ch555/usb_ak820.c:509: uint8_t offset = SNAPSHOT_SIZE;
      006CE5 90 08 05         [24] 3241 	mov	dptr,#_ak820_usb_send_offset_10000_427
      006CE8 74 34            [12] 3242 	mov	a,#0x34
      006CEA F0               [24] 3243 	movx	@dptr,a
                                   3244 ;	tmk_core/protocol/ch555/usb_ak820.c:511: if (endpoint < 1 || endpoint > 3 || length > 64 || !USB_EnumStatus) return false;
      006CEB 90 08 04         [24] 3245 	mov	dptr,#_ak820_usb_send_endpoint_10000_426
      006CEE E0               [24] 3246 	movx	a,@dptr
      006CEF FF               [12] 3247 	mov	r7,a
      006CF0 BF 01 00         [24] 3248 	cjne	r7,#0x01,00306$
      006CF3                       3249 00306$:
      006CF3 40 14            [24] 3250 	jc	00101$
      006CF5 EF               [12] 3251 	mov	a,r7
      006CF6 24 FC            [12] 3252 	add	a,#0xff - 0x03
      006CF8 40 0F            [24] 3253 	jc	00101$
                                   3254 ;	free result
      006CFA 90 08 03         [24] 3255 	mov	dptr,#_ak820_usb_send_PARM_3
      006CFD E0               [24] 3256 	movx	a,@dptr
      006CFE FE               [12] 3257 	mov  r6,a
      006CFF 24 BF            [12] 3258 	add	a,#0xff - 0x40
      006D01 40 06            [24] 3259 	jc	00101$
                                   3260 ;	free result
      006D03 90 07 96         [24] 3261 	mov	dptr,#_USB_EnumStatus
      006D06 E0               [24] 3262 	movx	a,@dptr
      006D07 70 04            [24] 3263 	jnz	00102$
      006D09                       3264 00101$:
      006D09 75 82 00         [24] 3265 	mov	dpl, #0x00
      006D0C 22               [24] 3266 	ret
      006D0D                       3267 00102$:
                                   3268 ;	tmk_core/protocol/ch555/usb_ak820.c:512: if (endpoint == KEYBOARD_IN_EPNUM) {
      006D0D BF 01 10         [24] 3269 	cjne	r7,#0x01,00118$
                                   3270 ;	tmk_core/protocol/ch555/usb_ak820.c:513: if (length != KEYBOARD_EPSIZE) return false;
      006D10 BE 08 02         [24] 3271 	cjne	r6,#0x08,00313$
      006D13 80 04            [24] 3272 	sjmp	00107$
      006D15                       3273 00313$:
      006D15 75 82 00         [24] 3274 	mov	dpl, #0x00
      006D18 22               [24] 3275 	ret
      006D19                       3276 00107$:
                                   3277 ;	tmk_core/protocol/ch555/usb_ak820.c:514: offset = SNAPSHOT_KEYBOARD;
      006D19 90 08 05         [24] 3278 	mov	dptr,#_ak820_usb_send_offset_10000_427
      006D1C E4               [12] 3279 	clr	a
      006D1D F0               [24] 3280 	movx	@dptr,a
      006D1E 80 3C            [24] 3281 	sjmp	00119$
      006D20                       3282 00118$:
                                   3283 ;	tmk_core/protocol/ch555/usb_ak820.c:515: } else if (endpoint == SHARED_IN_EPNUM) {
      006D20 BF 02 30         [24] 3284 	cjne	r7,#0x02,00115$
                                   3285 ;	tmk_core/protocol/ch555/usb_ak820.c:516: report_id = report[0];
      006D23 90 08 01         [24] 3286 	mov	dptr,#_ak820_usb_send_PARM_2
      006D26 E0               [24] 3287 	movx	a,@dptr
      006D27 FD               [12] 3288 	mov	r5,a
      006D28 A3               [24] 3289 	inc	dptr
      006D29 E0               [24] 3290 	movx	a,@dptr
      006D2A FF               [12] 3291 	mov	r7,a
      006D2B 8D 82            [24] 3292 	mov	dpl,r5
      006D2D 8F 83            [24] 3293 	mov	dph,r7
      006D2F E0               [24] 3294 	movx	a,@dptr
      006D30 FF               [12] 3295 	mov	r7,a
                                   3296 ;	tmk_core/protocol/ch555/usb_ak820.c:517: if (report_id >= sizeof(shared_lengths) || !shared_lengths[report_id] || length != shared_lengths[report_id]) return false;
      006D31 BF 07 00         [24] 3297 	cjne	r7,#0x07,00316$
      006D34                       3298 00316$:
      006D34 50 0E            [24] 3299 	jnc	00108$
      006D36 EF               [12] 3300 	mov	a,r7
      006D37 90 BF 4D         [24] 3301 	mov	dptr,#_shared_lengths
      006D3A 93               [24] 3302 	movc	a,@a+dptr
      006D3B FD               [12] 3303 	mov	r5,a
      006D3C 60 06            [24] 3304 	jz	00108$
      006D3E EE               [12] 3305 	mov	a,r6
      006D3F B5 05 02         [24] 3306 	cjne	a,ar5,00319$
      006D42 80 04            [24] 3307 	sjmp	00109$
      006D44                       3308 00319$:
      006D44                       3309 00108$:
      006D44 75 82 00         [24] 3310 	mov	dpl, #0x00
      006D47 22               [24] 3311 	ret
      006D48                       3312 00109$:
                                   3313 ;	tmk_core/protocol/ch555/usb_ak820.c:518: offset = shared_offsets[report_id];
      006D48 EF               [12] 3314 	mov	a,r7
      006D49 90 BF 46         [24] 3315 	mov	dptr,#_shared_offsets
      006D4C 93               [24] 3316 	movc	a,@a+dptr
      006D4D 90 08 05         [24] 3317 	mov	dptr,#_ak820_usb_send_offset_10000_427
      006D50 F0               [24] 3318 	movx	@dptr,a
      006D51 80 09            [24] 3319 	sjmp	00119$
      006D53                       3320 00115$:
                                   3321 ;	tmk_core/protocol/ch555/usb_ak820.c:519: } else if (length != RAW_EPSIZE) return false;
      006D53 BE 20 02         [24] 3322 	cjne	r6,#0x20,00320$
      006D56 80 04            [24] 3323 	sjmp	00119$
      006D58                       3324 00320$:
      006D58 75 82 00         [24] 3325 	mov	dpl, #0x00
      006D5B 22               [24] 3326 	ret
      006D5C                       3327 00119$:
                                   3328 ;	tmk_core/protocol/ch555/usb_ak820.c:520: if (USB_SleepStatus & 2) { USB_WakeUp_PC(); return false; }
      006D5C 90 07 97         [24] 3329 	mov	dptr,#_USB_SleepStatus
      006D5F E0               [24] 3330 	movx	a,@dptr
      006D60 30 E1 07         [24] 3331 	jnb	acc.1,00184$
      006D63 12 6C B4         [24] 3332 	lcall	_USB_WakeUp_PC
      006D66 75 82 00         [24] 3333 	mov	dpl, #0x00
      006D69 22               [24] 3334 	ret
                                   3335 ;	tmk_core/protocol/ch555/usb_ak820.c:521: while ((EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_ACK && timeout--) wait_us(40);
      006D6A                       3336 00184$:
      006D6A 7F FA            [12] 3337 	mov	r7,#0xfa
      006D6C                       3338 00127$:
      006D6C 90 08 04         [24] 3339 	mov	dptr,#_ak820_usb_send_endpoint_10000_426
      006D6F E0               [24] 3340 	movx	a,@dptr
      006D70 FC               [12] 3341 	mov	r4,a
      006D71 7D 00            [12] 3342 	mov	r5,#0x00
      006D73 8C 02            [24] 3343 	mov	ar2,r4
      006D75 74 22            [12] 3344 	mov	a,#0x22
      006D77 2D               [12] 3345 	add	a, r5
      006D78 FB               [12] 3346 	mov	r3,a
      006D79 8A 82            [24] 3347 	mov	dpl,r2
      006D7B 8B 83            [24] 3348 	mov	dph,r3
      006D7D E0               [24] 3349 	movx	a,@dptr
      006D7E 54 03            [12] 3350 	anl	a,#0x03
      006D80 70 14            [24] 3351 	jnz	00129$
      006D82 8F 03            [24] 3352 	mov	ar3,r7
      006D84 1F               [12] 3353 	dec	r7
      006D85 EB               [12] 3354 	mov	a,r3
      006D86 60 0E            [24] 3355 	jz	00129$
      006D88 7B 28            [12] 3356 	mov	r3,#0x28
      006D8A                       3357 00141$:
      006D8A EB               [12] 3358 	mov	a,r3
      006D8B 60 DF            [24] 3359 	jz	00127$
      006D8D 90 00 01         [24] 3360 	mov	dptr,#0x0001
      006D90 12 5E 3B         [24] 3361 	lcall	_mDelayuS
      006D93 1B               [12] 3362 	dec	r3
      006D94 80 F4            [24] 3363 	sjmp	00141$
      006D96                       3364 00129$:
                                   3365 ;	tmk_core/protocol/ch555/usb_ak820.c:522: saved_ea = EA;
      006D96 A2 AF            [12] 3366 	mov	c,_EA
      006D98 E4               [12] 3367 	clr	a
      006D99 33               [12] 3368 	rlc	a
      006D9A FF               [12] 3369 	mov	r7,a
                                   3370 ;	tmk_core/protocol/ch555/usb_ak820.c:523: EA = 0;
                                   3371 ;	assignBit
      006D9B C2 AF            [12] 3372 	clr	_EA
                                   3373 ;	tmk_core/protocol/ch555/usb_ak820.c:524: if (!USB_EnumStatus || (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) != UEP_X_RES_NAK ||
      006D9D 90 07 96         [24] 3374 	mov	dptr,#_USB_EnumStatus
      006DA0 E0               [24] 3375 	movx	a,@dptr
      006DA1 60 25            [24] 3376 	jz	00130$
      006DA3 90 08 04         [24] 3377 	mov	dptr,#_ak820_usb_send_endpoint_10000_426
      006DA6 E0               [24] 3378 	movx	a,@dptr
      006DA7 FB               [12] 3379 	mov	r3,a
      006DA8 F9               [12] 3380 	mov	r1,a
      006DA9 7A 00            [12] 3381 	mov	r2,#0x00
      006DAB 74 22            [12] 3382 	mov	a,#0x22
      006DAD 2A               [12] 3383 	add	a, r2
      006DAE FA               [12] 3384 	mov	r2,a
      006DAF 89 82            [24] 3385 	mov	dpl,r1
      006DB1 8A 83            [24] 3386 	mov	dph,r2
      006DB3 E0               [24] 3387 	movx	a,@dptr
      006DB4 FA               [12] 3388 	mov	r2,a
      006DB5 53 02 03         [24] 3389 	anl	ar2,#0x03
      006DB8 BA 02 0D         [24] 3390 	cjne	r2,#0x02,00130$
                                   3391 ;	tmk_core/protocol/ch555/usb_ak820.c:525: (endpoint == RAW_IN_EPNUM && raw_state != RAW_WORK)) { EA = saved_ea; return false; }
      006DBB BB 03 13         [24] 3392 	cjne	r3,#0x03,00192$
      006DBE 90 07 9D         [24] 3393 	mov	dptr,#_raw_state
      006DC1 E0               [24] 3394 	movx	a,@dptr
      006DC2 FB               [12] 3395 	mov	r3,a
      006DC3 BB 03 02         [24] 3396 	cjne	r3,#0x03,00331$
      006DC6 80 09            [24] 3397 	sjmp	00192$
      006DC8                       3398 00331$:
      006DC8                       3399 00130$:
                                   3400 ;	assignBit
      006DC8 EF               [12] 3401 	mov	a,r7
      006DC9 24 FF            [12] 3402 	add	a,#0xff
      006DCB 92 AF            [24] 3403 	mov	_EA,c
      006DCD 75 82 00         [24] 3404 	mov	dpl, #0x00
      006DD0 22               [24] 3405 	ret
                                   3406 ;	tmk_core/protocol/ch555/usb_ak820.c:526: for (i = 0; i < length; ++i) {
      006DD1                       3407 00192$:
      006DD1 7B 00            [12] 3408 	mov	r3,#0x00
      006DD3                       3409 00144$:
      006DD3 C3               [12] 3410 	clr	c
      006DD4 EB               [12] 3411 	mov	a,r3
      006DD5 9E               [12] 3412 	subb	a,r6
      006DD6 50 67            [24] 3413 	jnc	00137$
                                   3414 ;	tmk_core/protocol/ch555/usb_ak820.c:527: pUSB_BUF_DEV0[((uint16_t)endpoint << 6) + i] = report[i];
      006DD8 C0 07            [24] 3415 	push	ar7
      006DDA 90 08 04         [24] 3416 	mov	dptr,#_ak820_usb_send_endpoint_10000_426
      006DDD E0               [24] 3417 	movx	a,@dptr
      006DDE F9               [12] 3418 	mov	r1,a
      006DDF E4               [12] 3419 	clr	a
      006DE0 C3               [12] 3420 	clr	c
      006DE1 C9               [12] 3421 	xch	a,r1
      006DE2 13               [12] 3422 	rrc	a
      006DE3 C9               [12] 3423 	xch	a,r1
      006DE4 13               [12] 3424 	rrc	a
      006DE5 A2 E0            [12] 3425 	mov	c,acc.0
      006DE7 C9               [12] 3426 	xch	a,r1
      006DE8 13               [12] 3427 	rrc	a
      006DE9 C9               [12] 3428 	xch	a,r1
      006DEA 13               [12] 3429 	rrc	a
      006DEB C9               [12] 3430 	xch	a,r1
      006DEC FA               [12] 3431 	mov	r2,a
      006DED 8B 00            [24] 3432 	mov	ar0,r3
      006DEF 7F 00            [12] 3433 	mov	r7,#0x00
      006DF1 E8               [12] 3434 	mov	a,r0
      006DF2 29               [12] 3435 	add	a, r1
      006DF3 F9               [12] 3436 	mov	r1,a
      006DF4 EF               [12] 3437 	mov	a,r7
      006DF5 3A               [12] 3438 	addc	a, r2
      006DF6 24 10            [12] 3439 	add	a,#0x10
      006DF8 FA               [12] 3440 	mov	r2,a
      006DF9 90 08 01         [24] 3441 	mov	dptr,#_ak820_usb_send_PARM_2
      006DFC E0               [24] 3442 	movx	a,@dptr
      006DFD F8               [12] 3443 	mov	r0,a
      006DFE A3               [24] 3444 	inc	dptr
      006DFF E0               [24] 3445 	movx	a,@dptr
      006E00 FF               [12] 3446 	mov	r7,a
      006E01 EB               [12] 3447 	mov	a,r3
      006E02 28               [12] 3448 	add	a, r0
      006E03 F5 1B            [12] 3449 	mov	_ak820_usb_send_sloc0_1_0,a
      006E05 E4               [12] 3450 	clr	a
      006E06 3F               [12] 3451 	addc	a, r7
      006E07 F5 1C            [12] 3452 	mov	(_ak820_usb_send_sloc0_1_0 + 1),a
      006E09 85 1B 82         [24] 3453 	mov	dpl,_ak820_usb_send_sloc0_1_0
      006E0C 85 1C 83         [24] 3454 	mov	dph,(_ak820_usb_send_sloc0_1_0 + 1)
      006E0F E0               [24] 3455 	movx	a,@dptr
      006E10 89 82            [24] 3456 	mov	dpl,r1
      006E12 8A 83            [24] 3457 	mov	dph,r2
      006E14 F0               [24] 3458 	movx	@dptr,a
                                   3459 ;	tmk_core/protocol/ch555/usb_ak820.c:528: if (offset != SNAPSHOT_SIZE) input_snapshot[offset + i] = report[i];
      006E15 90 08 05         [24] 3460 	mov	dptr,#_ak820_usb_send_offset_10000_427
      006E18 E0               [24] 3461 	movx	a,@dptr
      006E19 F5 1D            [12] 3462 	mov	_ak820_usb_send_sloc1_1_0,a
      006E1B 74 34            [12] 3463 	mov	a,#0x34
      006E1D B5 1D 04         [24] 3464 	cjne	a,_ak820_usb_send_sloc1_1_0,00333$
      006E20 D0 07            [24] 3465 	pop	ar7
      006E22 80 18            [24] 3466 	sjmp	00145$
      006E24                       3467 00333$:
      006E24 D0 07            [24] 3468 	pop	ar7
      006E26 EB               [12] 3469 	mov	a,r3
      006E27 25 1D            [12] 3470 	add	a, _ak820_usb_send_sloc1_1_0
      006E29 24 C0            [12] 3471 	add	a, #_input_snapshot
      006E2B F9               [12] 3472 	mov	r1,a
      006E2C E4               [12] 3473 	clr	a
      006E2D 34 07            [12] 3474 	addc	a,#(_input_snapshot >> 8)
      006E2F FA               [12] 3475 	mov	r2,a
      006E30 85 1B 82         [24] 3476 	mov	dpl,_ak820_usb_send_sloc0_1_0
      006E33 85 1C 83         [24] 3477 	mov	dph,(_ak820_usb_send_sloc0_1_0 + 1)
      006E36 E0               [24] 3478 	movx	a,@dptr
      006E37 89 82            [24] 3479 	mov	dpl,r1
      006E39 8A 83            [24] 3480 	mov	dph,r2
      006E3B F0               [24] 3481 	movx	@dptr,a
      006E3C                       3482 00145$:
                                   3483 ;	tmk_core/protocol/ch555/usb_ak820.c:526: for (i = 0; i < length; ++i) {
      006E3C 0B               [12] 3484 	inc	r3
      006E3D 80 94            [24] 3485 	sjmp	00144$
      006E3F                       3486 00137$:
                                   3487 ;	tmk_core/protocol/ch555/usb_ak820.c:530: EP_LENGTH(endpoint) = length;
      006E3F 90 08 04         [24] 3488 	mov	dptr,#_ak820_usb_send_endpoint_10000_426
      006E42 E0               [24] 3489 	movx	a,@dptr
      006E43 FB               [12] 3490 	mov	r3,a
      006E44 F9               [12] 3491 	mov	r1,a
      006E45 7A 00            [12] 3492 	mov	r2,#0x00
      006E47 74 08            [12] 3493 	mov	a,#0x08
      006E49 29               [12] 3494 	add	a, r1
      006E4A F9               [12] 3495 	mov	r1,a
      006E4B 74 22            [12] 3496 	mov	a,#0x22
      006E4D 3A               [12] 3497 	addc	a, r2
      006E4E FA               [12] 3498 	mov	r2,a
      006E4F 89 82            [24] 3499 	mov	dpl,r1
      006E51 8A 83            [24] 3500 	mov	dph,r2
      006E53 EE               [12] 3501 	mov	a,r6
      006E54 F0               [24] 3502 	movx	@dptr,a
                                   3503 ;	tmk_core/protocol/ch555/usb_ak820.c:531: if (endpoint == RAW_IN_EPNUM) raw_state = RAW_TX_ACTIVE;
      006E55 BB 03 06         [24] 3504 	cjne	r3,#0x03,00139$
      006E58 90 07 9D         [24] 3505 	mov	dptr,#_raw_state
      006E5B 74 04            [12] 3506 	mov	a,#0x04
      006E5D F0               [24] 3507 	movx	@dptr,a
      006E5E                       3508 00139$:
                                   3509 ;	tmk_core/protocol/ch555/usb_ak820.c:532: EP_RESPONSE(endpoint) = (EP_RESPONSE(endpoint) & ~MASK_UEP_X_RES) | UEP_X_RES_ACK;
      006E5E 74 22            [12] 3510 	mov	a,#0x22
      006E60 2D               [12] 3511 	add	a, r5
      006E61 FD               [12] 3512 	mov	r5,a
      006E62 8C 82            [24] 3513 	mov	dpl,r4
      006E64 8D 83            [24] 3514 	mov	dph,r5
      006E66 E0               [24] 3515 	movx	a,@dptr
      006E67 FE               [12] 3516 	mov	r6,a
      006E68 53 06 FC         [24] 3517 	anl	ar6,#0xfc
      006E6B 8C 82            [24] 3518 	mov	dpl,r4
      006E6D 8D 83            [24] 3519 	mov	dph,r5
      006E6F EE               [12] 3520 	mov	a,r6
      006E70 F0               [24] 3521 	movx	@dptr,a
                                   3522 ;	tmk_core/protocol/ch555/usb_ak820.c:533: EA = saved_ea;
                                   3523 ;	assignBit
      006E71 EF               [12] 3524 	mov	a,r7
      006E72 24 FF            [12] 3525 	add	a,#0xff
      006E74 92 AF            [24] 3526 	mov	_EA,c
                                   3527 ;	tmk_core/protocol/ch555/usb_ak820.c:534: return true;
      006E76 75 82 01         [24] 3528 	mov	dpl, #0x01
                                   3529 ;	tmk_core/protocol/ch555/usb_ak820.c:535: }
      006E79 22               [24] 3530 	ret
                                   3531 ;------------------------------------------------------------
                                   3532 ;Allocation info for local variables in function 'ak820_usb_try_send'
                                   3533 ;------------------------------------------------------------
                                   3534 ;report        Allocated with name '_ak820_usb_try_send_PARM_2'
                                   3535 ;length        Allocated with name '_ak820_usb_try_send_PARM_3'
                                   3536 ;endpoint      Allocated with name '_ak820_usb_try_send_endpoint_10000_447'
                                   3537 ;saved_ea      Allocated with name '_ak820_usb_try_send_saved_ea_10000_448'
                                   3538 ;sent          Allocated with name '_ak820_usb_try_send_sent_10000_448'
                                   3539 ;------------------------------------------------------------
                                   3540 ;	tmk_core/protocol/ch555/usb_ak820.c:537: bool ak820_usb_try_send(uint8_t endpoint, const uint8_t __xdata *report, uint8_t length) {
                                   3541 ;	-----------------------------------------
                                   3542 ;	 function ak820_usb_try_send
                                   3543 ;	-----------------------------------------
      006E7A                       3544 _ak820_usb_try_send:
      006E7A E5 82            [12] 3545 	mov	a,dpl
      006E7C 90 08 09         [24] 3546 	mov	dptr,#_ak820_usb_try_send_endpoint_10000_447
      006E7F F0               [24] 3547 	movx	@dptr,a
                                   3548 ;	tmk_core/protocol/ch555/usb_ak820.c:538: uint8_t saved_ea = EA;
                                   3549 ;	assignBit
      006E80 A2 AF            [12] 3550 	mov	c,_EA
      006E82 92 1B            [24] 3551 	mov	_ak820_usb_try_send_sloc0_1_0,c
                                   3552 ;	tmk_core/protocol/ch555/usb_ak820.c:539: bool sent = false;
      006E84 90 08 0A         [24] 3553 	mov	dptr,#_ak820_usb_try_send_sent_10000_448
      006E87 E4               [12] 3554 	clr	a
      006E88 F0               [24] 3555 	movx	@dptr,a
                                   3556 ;	tmk_core/protocol/ch555/usb_ak820.c:540: EA = 0;
                                   3557 ;	assignBit
      006E89 C2 AF            [12] 3558 	clr	_EA
                                   3559 ;	tmk_core/protocol/ch555/usb_ak820.c:544: if (endpoint >= 1 && endpoint <= 2 && USB_EnumStatus &&
      006E8B 90 08 09         [24] 3560 	mov	dptr,#_ak820_usb_try_send_endpoint_10000_447
      006E8E E0               [24] 3561 	movx	a,@dptr
      006E8F FF               [12] 3562 	mov	r7,a
      006E90 BF 01 00         [24] 3563 	cjne	r7,#0x01,00152$
      006E93                       3564 00152$:
      006E93 40 4E            [24] 3565 	jc	00102$
      006E95 EF               [12] 3566 	mov	a,r7
      006E96 24 FD            [12] 3567 	add	a,#0xff - 0x02
      006E98 40 49            [24] 3568 	jc	00102$
                                   3569 ;	free result
      006E9A 90 07 96         [24] 3570 	mov	dptr,#_USB_EnumStatus
      006E9D E0               [24] 3571 	movx	a,@dptr
      006E9E 60 43            [24] 3572 	jz	00102$
                                   3573 ;	tmk_core/protocol/ch555/usb_ak820.c:545: !(USB_SleepStatus & 2) && !keyboard_reset &&
      006EA0 90 07 97         [24] 3574 	mov	dptr,#_USB_SleepStatus
      006EA3 E0               [24] 3575 	movx	a,@dptr
      006EA4 20 E1 3C         [24] 3576 	jb	acc.1,00102$
      006EA7 90 07 BF         [24] 3577 	mov	dptr,#_keyboard_reset
      006EAA E0               [24] 3578 	movx	a,@dptr
                                   3579 ;	tmk_core/protocol/ch555/usb_ak820.c:546: (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_NAK) {
      006EAB 70 36            [24] 3580 	jnz	00102$
      006EAD 8F 06            [24] 3581 	mov	ar6,r7
      006EAF 24 22            [12] 3582 	add	a,#0x22
      006EB1 FD               [12] 3583 	mov	r5,a
      006EB2 8E 82            [24] 3584 	mov	dpl,r6
      006EB4 8D 83            [24] 3585 	mov	dph,r5
      006EB6 E0               [24] 3586 	movx	a,@dptr
      006EB7 FE               [12] 3587 	mov	r6,a
      006EB8 53 06 03         [24] 3588 	anl	ar6,#0x03
      006EBB BE 02 25         [24] 3589 	cjne	r6,#0x02,00102$
                                   3590 ;	tmk_core/protocol/ch555/usb_ak820.c:547: sent = ak820_usb_send(endpoint, report, length);
      006EBE 90 08 06         [24] 3591 	mov	dptr,#_ak820_usb_try_send_PARM_2
      006EC1 E0               [24] 3592 	movx	a,@dptr
      006EC2 FD               [12] 3593 	mov	r5,a
      006EC3 A3               [24] 3594 	inc	dptr
      006EC4 E0               [24] 3595 	movx	a,@dptr
      006EC5 FE               [12] 3596 	mov	r6,a
      006EC6 90 08 08         [24] 3597 	mov	dptr,#_ak820_usb_try_send_PARM_3
      006EC9 E0               [24] 3598 	movx	a,@dptr
      006ECA FC               [12] 3599 	mov	r4,a
      006ECB 90 08 01         [24] 3600 	mov	dptr,#_ak820_usb_send_PARM_2
      006ECE ED               [12] 3601 	mov	a,r5
      006ECF F0               [24] 3602 	movx	@dptr,a
      006ED0 EE               [12] 3603 	mov	a,r6
      006ED1 A3               [24] 3604 	inc	dptr
      006ED2 F0               [24] 3605 	movx	@dptr,a
      006ED3 90 08 03         [24] 3606 	mov	dptr,#_ak820_usb_send_PARM_3
      006ED6 EC               [12] 3607 	mov	a,r4
      006ED7 F0               [24] 3608 	movx	@dptr,a
      006ED8 8F 82            [24] 3609 	mov	dpl, r7
      006EDA 12 6C DF         [24] 3610 	lcall	_ak820_usb_send
      006EDD E5 82            [12] 3611 	mov	a, dpl
      006EDF 90 08 0A         [24] 3612 	mov	dptr,#_ak820_usb_try_send_sent_10000_448
      006EE2 F0               [24] 3613 	movx	@dptr,a
      006EE3                       3614 00102$:
                                   3615 ;	tmk_core/protocol/ch555/usb_ak820.c:549: EA = saved_ea;
                                   3616 ;	assignBit
      006EE3 A2 1B            [12] 3617 	mov	c,_ak820_usb_try_send_sloc0_1_0
      006EE5 92 AF            [24] 3618 	mov	_EA,c
                                   3619 ;	tmk_core/protocol/ch555/usb_ak820.c:550: return sent;
      006EE7 90 08 0A         [24] 3620 	mov	dptr,#_ak820_usb_try_send_sent_10000_448
      006EEA E0               [24] 3621 	movx	a,@dptr
                                   3622 ;	tmk_core/protocol/ch555/usb_ak820.c:551: }
      006EEB F5 82            [12] 3623 	mov	dpl,a
      006EED 22               [24] 3624 	ret
                                   3625 ;------------------------------------------------------------
                                   3626 ;Allocation info for local variables in function 'raw_request_is_nonpersistent'
                                   3627 ;------------------------------------------------------------
                                   3628 ;	tmk_core/protocol/ch555/usb_ak820.c:556: static bool raw_request_is_nonpersistent(void) {
                                   3629 ;	-----------------------------------------
                                   3630 ;	 function raw_request_is_nonpersistent
                                   3631 ;	-----------------------------------------
      006EEE                       3632 _raw_request_is_nonpersistent:
                                   3633 ;	tmk_core/protocol/ch555/usb_ak820.c:557: switch (raw_buffer[0]) {
      006EEE 90 07 9E         [24] 3634 	mov	dptr,#_raw_buffer
      006EF1 E0               [24] 3635 	movx	a,@dptr
      006EF2 FF               [12] 3636 	mov	r7,a
      006EF3 BF 01 02         [24] 3637 	cjne	r7,#0x01,00302$
      006EF6 80 35            [24] 3638 	sjmp	00108$
      006EF8                       3639 00302$:
      006EF8 BF 02 02         [24] 3640 	cjne	r7,#0x02,00303$
      006EFB 80 34            [24] 3641 	sjmp	00109$
      006EFD                       3642 00303$:
      006EFD BF 04 02         [24] 3643 	cjne	r7,#0x04,00304$
      006F00 80 2B            [24] 3644 	sjmp	00108$
      006F02                       3645 00304$:
      006F02 BF 08 02         [24] 3646 	cjne	r7,#0x08,00305$
      006F05 80 47            [24] 3647 	sjmp	00116$
      006F07                       3648 00305$:
      006F07 BF 0B 02         [24] 3649 	cjne	r7,#0x0b,00306$
      006F0A 80 21            [24] 3650 	sjmp	00108$
      006F0C                       3651 00306$:
      006F0C BF 0C 02         [24] 3652 	cjne	r7,#0x0c,00307$
      006F0F 80 1C            [24] 3653 	sjmp	00108$
      006F11                       3654 00307$:
      006F11 BF 0D 02         [24] 3655 	cjne	r7,#0x0d,00308$
      006F14 80 17            [24] 3656 	sjmp	00108$
      006F16                       3657 00308$:
      006F16 BF 0E 02         [24] 3658 	cjne	r7,#0x0e,00309$
      006F19 80 12            [24] 3659 	sjmp	00108$
      006F1B                       3660 00309$:
      006F1B BF 11 02         [24] 3661 	cjne	r7,#0x11,00310$
      006F1E 80 0D            [24] 3662 	sjmp	00108$
      006F20                       3663 00310$:
      006F20 BF 12 02         [24] 3664 	cjne	r7,#0x12,00311$
      006F23 80 08            [24] 3665 	sjmp	00108$
      006F25                       3666 00311$:
      006F25 BF FE 02         [24] 3667 	cjne	r7,#0xfe,00312$
      006F28 80 46            [24] 3668 	sjmp	00124$
      006F2A                       3669 00312$:
      006F2A 02 6F C5         [24] 3670 	ljmp	00144$
                                   3671 ;	tmk_core/protocol/ch555/usb_ak820.c:565: case id_bootloader_jump:
      006F2D                       3672 00108$:
                                   3673 ;	tmk_core/protocol/ch555/usb_ak820.c:566: return true;
      006F2D 75 82 01         [24] 3674 	mov	dpl, #0x01
      006F30 22               [24] 3675 	ret
                                   3676 ;	tmk_core/protocol/ch555/usb_ak820.c:567: case id_get_keyboard_value:
      006F31                       3677 00109$:
                                   3678 ;	tmk_core/protocol/ch555/usb_ak820.c:568: switch (raw_buffer[1]) {
      006F31 12 72 D4         [24] 3679 	lcall	_ak820_outline_0161
      006F34 BF 01 02         [24] 3680 	cjne	r7,#0x01,00313$
      006F37 80 0D            [24] 3681 	sjmp	00113$
      006F39                       3682 00313$:
      006F39 BF 02 02         [24] 3683 	cjne	r7,#0x02,00314$
      006F3C 80 08            [24] 3684 	sjmp	00113$
      006F3E                       3685 00314$:
      006F3E BF 03 02         [24] 3686 	cjne	r7,#0x03,00315$
      006F41 80 03            [24] 3687 	sjmp	00113$
      006F43                       3688 00315$:
      006F43 BF 04 04         [24] 3689 	cjne	r7,#0x04,00114$
                                   3690 ;	tmk_core/protocol/ch555/usb_ak820.c:572: case id_firmware_version:
      006F46                       3691 00113$:
                                   3692 ;	tmk_core/protocol/ch555/usb_ak820.c:573: return true;
      006F46 75 82 01         [24] 3693 	mov	dpl, #0x01
      006F49 22               [24] 3694 	ret
                                   3695 ;	tmk_core/protocol/ch555/usb_ak820.c:574: default: return false;
      006F4A                       3696 00114$:
      006F4A 75 82 00         [24] 3697 	mov	dpl, #0x00
      006F4D 22               [24] 3698 	ret
                                   3699 ;	tmk_core/protocol/ch555/usb_ak820.c:576: case id_lighting_get_value:
      006F4E                       3700 00116$:
                                   3701 ;	tmk_core/protocol/ch555/usb_ak820.c:577: switch (raw_buffer[1]) {
      006F4E 12 72 D4         [24] 3702 	lcall	_ak820_outline_0161
      006F51 BF 40 02         [24] 3703 	cjne	r7,#0x40,00318$
      006F54 80 12            [24] 3704 	sjmp	00121$
      006F56                       3705 00318$:
      006F56 BF 41 02         [24] 3706 	cjne	r7,#0x41,00319$
      006F59 80 0D            [24] 3707 	sjmp	00121$
      006F5B                       3708 00319$:
      006F5B BF 42 02         [24] 3709 	cjne	r7,#0x42,00320$
      006F5E 80 08            [24] 3710 	sjmp	00121$
      006F60                       3711 00320$:
      006F60 BF 43 02         [24] 3712 	cjne	r7,#0x43,00321$
      006F63 80 03            [24] 3713 	sjmp	00121$
      006F65                       3714 00321$:
      006F65 BF 44 04         [24] 3715 	cjne	r7,#0x44,00122$
                                   3716 ;	tmk_core/protocol/ch555/usb_ak820.c:582: case vialrgb_get_led_info:
      006F68                       3717 00121$:
                                   3718 ;	tmk_core/protocol/ch555/usb_ak820.c:583: return true;
      006F68 75 82 01         [24] 3719 	mov	dpl, #0x01
                                   3720 ;	tmk_core/protocol/ch555/usb_ak820.c:584: default: return false;
      006F6B 22               [24] 3721 	ret
      006F6C                       3722 00122$:
      006F6C 75 82 00         [24] 3723 	mov	dpl, #0x00
                                   3724 ;	tmk_core/protocol/ch555/usb_ak820.c:586: case id_vial_prefix:
      006F6F 22               [24] 3725 	ret
      006F70                       3726 00124$:
                                   3727 ;	tmk_core/protocol/ch555/usb_ak820.c:587: switch (raw_buffer[1]) {
      006F70 12 72 D4         [24] 3728 	lcall	_ak820_outline_0161
      006F73 24 F2            [12] 3729 	add	a,#0xff - 0x0d
      006F75 40 4A            [24] 3730 	jc	00142$
                                   3731 ;	free result
      006F77 EF               [12] 3732 	mov	a,r7
      006F78 24 0A            [12] 3733 	add	a,#(00325$-3-.)
      006F7A 83               [24] 3734 	movc	a,@a+pc
      006F7B F5 82            [12] 3735 	mov	dpl,a
      006F7D EF               [12] 3736 	mov	a,r7
      006F7E 24 12            [12] 3737 	add	a,#(00326$-3-.)
      006F80 83               [24] 3738 	movc	a,@a+pc
      006F81 F5 83            [12] 3739 	mov	dph,a
      006F83 E4               [12] 3740 	clr	a
      006F84 73               [24] 3741 	jmp	@a+dptr
      006F85                       3742 00325$:
      006F85 A1                    3743 	.db	00134$
      006F86 A1                    3744 	.db	00134$
      006F87 A1                    3745 	.db	00134$
      006F88 A1                    3746 	.db	00134$
      006F89 C1                    3747 	.db	00142$
      006F8A A1                    3748 	.db	00134$
      006F8B A1                    3749 	.db	00134$
      006F8C A1                    3750 	.db	00134$
      006F8D A1                    3751 	.db	00134$
      006F8E A1                    3752 	.db	00134$
      006F8F A1                    3753 	.db	00134$
      006F90 C1                    3754 	.db	00142$
      006F91 C1                    3755 	.db	00142$
      006F92 A5                    3756 	.db	00135$
      006F93                       3757 00326$:
      006F93 6F                    3758 	.db	00134$>>8
      006F94 6F                    3759 	.db	00134$>>8
      006F95 6F                    3760 	.db	00134$>>8
      006F96 6F                    3761 	.db	00134$>>8
      006F97 6F                    3762 	.db	00142$>>8
      006F98 6F                    3763 	.db	00134$>>8
      006F99 6F                    3764 	.db	00134$>>8
      006F9A 6F                    3765 	.db	00134$>>8
      006F9B 6F                    3766 	.db	00134$>>8
      006F9C 6F                    3767 	.db	00134$>>8
      006F9D 6F                    3768 	.db	00134$>>8
      006F9E 6F                    3769 	.db	00142$>>8
      006F9F 6F                    3770 	.db	00142$>>8
      006FA0 6F                    3771 	.db	00135$>>8
                                   3772 ;	tmk_core/protocol/ch555/usb_ak820.c:597: case vial_qmk_settings_get:
      006FA1                       3773 00134$:
                                   3774 ;	tmk_core/protocol/ch555/usb_ak820.c:598: return true;
      006FA1 75 82 01         [24] 3775 	mov	dpl, #0x01
                                   3776 ;	tmk_core/protocol/ch555/usb_ak820.c:599: case vial_dynamic_entry_op:
      006FA4 22               [24] 3777 	ret
      006FA5                       3778 00135$:
                                   3779 ;	tmk_core/protocol/ch555/usb_ak820.c:600: switch (raw_buffer[2]) {
      006FA5 90 07 A0         [24] 3780 	mov	dptr,#(_raw_buffer + 0x0002)
      006FA8 E0               [24] 3781 	movx	a,@dptr
      006FA9 FF               [12] 3782 	mov	r7,a
      006FAA 60 0D            [24] 3783 	jz	00139$
      006FAC BF 01 02         [24] 3784 	cjne	r7,#0x01,00328$
      006FAF 80 08            [24] 3785 	sjmp	00139$
      006FB1                       3786 00328$:
      006FB1 BF 03 02         [24] 3787 	cjne	r7,#0x03,00329$
      006FB4 80 03            [24] 3788 	sjmp	00139$
      006FB6                       3789 00329$:
      006FB6 BF 05 04         [24] 3790 	cjne	r7,#0x05,00140$
                                   3791 ;	tmk_core/protocol/ch555/usb_ak820.c:604: case dynamic_vial_key_override_get:
      006FB9                       3792 00139$:
                                   3793 ;	tmk_core/protocol/ch555/usb_ak820.c:605: return true;
      006FB9 75 82 01         [24] 3794 	mov	dpl, #0x01
                                   3795 ;	tmk_core/protocol/ch555/usb_ak820.c:606: default: return false;
      006FBC 22               [24] 3796 	ret
      006FBD                       3797 00140$:
      006FBD 75 82 00         [24] 3798 	mov	dpl, #0x00
                                   3799 ;	tmk_core/protocol/ch555/usb_ak820.c:608: default: return false;
      006FC0 22               [24] 3800 	ret
      006FC1                       3801 00142$:
      006FC1 75 82 00         [24] 3802 	mov	dpl, #0x00
                                   3803 ;	tmk_core/protocol/ch555/usb_ak820.c:610: default: return false;
      006FC4 22               [24] 3804 	ret
      006FC5                       3805 00144$:
      006FC5 75 82 00         [24] 3806 	mov	dpl, #0x00
                                   3807 ;	tmk_core/protocol/ch555/usb_ak820.c:611: }
                                   3808 ;	tmk_core/protocol/ch555/usb_ak820.c:612: }
      006FC8 22               [24] 3809 	ret
                                   3810 ;------------------------------------------------------------
                                   3811 ;Allocation info for local variables in function 'ak820_usb_raw_send'
                                   3812 ;------------------------------------------------------------
                                   3813 ;length        Allocated with name '_ak820_usb_raw_send_PARM_2'
                                   3814 ;report        Allocated with name '_ak820_usb_raw_send_report_10000_463'
                                   3815 ;------------------------------------------------------------
                                   3816 ;	tmk_core/protocol/ch555/usb_ak820.c:614: void ak820_usb_raw_send(const uint8_t *report, uint8_t length) {
                                   3817 ;	-----------------------------------------
                                   3818 ;	 function ak820_usb_raw_send
                                   3819 ;	-----------------------------------------
      006FC9                       3820 _ak820_usb_raw_send:
      006FC9 12 45 8D         [24] 3821 	lcall	_ak820_outline_0037
      006FCC 90 08 0C         [24] 3822 	mov	dptr,#_ak820_usb_raw_send_report_10000_463
      006FCF 12 3A 25         [24] 3823 	lcall	_ak820_outline_0016
                                   3824 ;	tmk_core/protocol/ch555/usb_ak820.c:615: if (length != RAW_EPSIZE) return;
      006FD2 90 08 0B         [24] 3825 	mov	dptr,#_ak820_usb_raw_send_PARM_2
      006FD5 E0               [24] 3826 	movx	a,@dptr
      006FD6 FF               [12] 3827 	mov	r7,a
      006FD7 BF 20 2B         [24] 3828 	cjne	r7,#0x20,00106$
                                   3829 ;	tmk_core/protocol/ch555/usb_ak820.c:616: ak820_nvm_flush();
      006FDA C0 07            [24] 3830 	push	ar7
      006FDC 12 40 A4         [24] 3831 	lcall	_ak820_nvm_flush
      006FDF D0 07            [24] 3832 	pop	ar7
                                   3833 ;	tmk_core/protocol/ch555/usb_ak820.c:617: if (raw_reply_without_nvm || ak820_nvm_ok()) ak820_usb_send(RAW_IN_EPNUM, (const uint8_t __xdata *)report, length);
      006FE1 90 07 BE         [24] 3834 	mov	dptr,#_raw_reply_without_nvm
      006FE4 E0               [24] 3835 	movx	a,@dptr
      006FE5 70 07            [24] 3836 	jnz	00103$
      006FE7 12 40 95         [24] 3837 	lcall	_ak820_nvm_ok
      006FEA E5 82            [12] 3838 	mov	a, dpl
      006FEC 60 17            [24] 3839 	jz	00106$
      006FEE                       3840 00103$:
      006FEE 90 08 0C         [24] 3841 	mov	dptr,#_ak820_usb_raw_send_report_10000_463
      006FF1 12 45 BD         [24] 3842 	lcall	_ak820_outline_0097
      006FF4 90 08 01         [24] 3843 	mov	dptr,#_ak820_usb_send_PARM_2
      006FF7 12 46 00         [24] 3844 	lcall	_ak820_outline_0159
      006FFA 90 08 03         [24] 3845 	mov	dptr,#_ak820_usb_send_PARM_3
      006FFD EF               [12] 3846 	mov	a,r7
      006FFE F0               [24] 3847 	movx	@dptr,a
      006FFF 75 82 03         [24] 3848 	mov	dpl, #0x03
                                   3849 ;	tmk_core/protocol/ch555/usb_ak820.c:618: }
      007002 02 6C DF         [24] 3850 	ljmp	_ak820_usb_send
      007005                       3851 00106$:
      007005 22               [24] 3852 	ret
                                   3853 ;------------------------------------------------------------
                                   3854 ;Allocation info for local variables in function 'ak820_usb_raw_task'
                                   3855 ;------------------------------------------------------------
                                   3856 ;sloc0         Allocated with name '_ak820_usb_raw_task_sloc0_1_0'
                                   3857 ;i             Allocated with name '_ak820_usb_raw_task_i_10000_468'
                                   3858 ;length        Allocated with name '_ak820_usb_raw_task_length_10000_468'
                                   3859 ;address       Allocated with name '_ak820_usb_raw_task_address_10000_468'
                                   3860 ;saved_ea      Allocated with name '_ak820_usb_raw_task_saved_ea_10000_468'
                                   3861 ;------------------------------------------------------------
                                   3862 ;	tmk_core/protocol/ch555/usb_ak820.c:620: void ak820_usb_raw_task(void) {
                                   3863 ;	-----------------------------------------
                                   3864 ;	 function ak820_usb_raw_task
                                   3865 ;	-----------------------------------------
      007006                       3866 _ak820_usb_raw_task:
                                   3867 ;	tmk_core/protocol/ch555/usb_ak820.c:624: uint8_t saved_ea = EA;
      007006 A2 AF            [12] 3868 	mov	c,_EA
      007008 E4               [12] 3869 	clr	a
      007009 33               [12] 3870 	rlc	a
      00700A FF               [12] 3871 	mov	r7,a
                                   3872 ;	tmk_core/protocol/ch555/usb_ak820.c:625: EA = 0;
                                   3873 ;	assignBit
      00700B C2 AF            [12] 3874 	clr	_EA
                                   3875 ;	tmk_core/protocol/ch555/usb_ak820.c:626: if (!USB_EnumStatus || raw_state != RAW_READY) { EA = saved_ea; return; }
      00700D 90 07 96         [24] 3876 	mov	dptr,#_USB_EnumStatus
      007010 E0               [24] 3877 	movx	a,@dptr
      007011 60 0A            [24] 3878 	jz	00101$
      007013 90 07 9D         [24] 3879 	mov	dptr,#_raw_state
      007016 E0               [24] 3880 	movx	a,@dptr
      007017 FE               [12] 3881 	mov	r6,a
      007018 BE 02 02         [24] 3882 	cjne	r6,#0x02,00427$
      00701B 80 06            [24] 3883 	sjmp	00102$
      00701D                       3884 00427$:
      00701D                       3885 00101$:
                                   3886 ;	assignBit
      00701D EF               [12] 3887 	mov	a,r7
      00701E 24 FF            [12] 3888 	add	a,#0xff
      007020 92 AF            [24] 3889 	mov	_EA,c
      007022 22               [24] 3890 	ret
      007023                       3891 00102$:
                                   3892 ;	tmk_core/protocol/ch555/usb_ak820.c:627: raw_state = RAW_WORK;
      007023 90 07 9D         [24] 3893 	mov	dptr,#_raw_state
      007026 74 03            [12] 3894 	mov	a,#0x03
      007028 F0               [24] 3895 	movx	@dptr,a
                                   3896 ;	tmk_core/protocol/ch555/usb_ak820.c:628: EA = saved_ea;
                                   3897 ;	assignBit
      007029 EF               [12] 3898 	mov	a,r7
      00702A 24 FF            [12] 3899 	add	a,#0xff
      00702C 92 AF            [24] 3900 	mov	_EA,c
                                   3901 ;	tmk_core/protocol/ch555/usb_ak820.c:629: if (raw_buffer[0] == 0xfd && raw_buffer[1] == 0) {
      00702E 90 07 9E         [24] 3902 	mov	dptr,#_raw_buffer
      007031 E0               [24] 3903 	movx	a,@dptr
      007032 FF               [12] 3904 	mov	r7,a
      007033 E4               [12] 3905 	clr	a
      007034 BF FD 01         [24] 3906 	cjne	r7,#0xfd,00428$
      007037 04               [12] 3907 	inc	a
      007038                       3908 00428$:
      007038 FF               [12] 3909 	mov	r7,a
      007039 70 03            [24] 3910 	jnz	00430$
      00703B 02 70 DB         [24] 3911 	ljmp	00141$
      00703E                       3912 00430$:
      00703E 90 07 9F         [24] 3913 	mov	dptr,#(_raw_buffer + 0x0001)
      007041 E0               [24] 3914 	movx	a,@dptr
      007042 60 03            [24] 3915 	jz	00431$
      007044 02 70 DB         [24] 3916 	ljmp	00141$
      007047                       3917 00431$:
                                   3918 ;	tmk_core/protocol/ch555/usb_ak820.c:632: address = ((uint16_t)raw_buffer[2] << 8) | raw_buffer[3];
      007047 90 07 A0         [24] 3919 	mov	dptr,#(_raw_buffer + 0x0002)
      00704A E0               [24] 3920 	movx	a,@dptr
      00704B FD               [12] 3921 	mov	r5,a
      00704C 7E 00            [12] 3922 	mov	r6,#0x00
      00704E 90 07 A1         [24] 3923 	mov	dptr,#(_raw_buffer + 0x0003)
      007051 E0               [24] 3924 	movx	a,@dptr
      007052 7B 00            [12] 3925 	mov	r3,#0x00
      007054 42 06            [12] 3926 	orl	ar6,a
      007056 EB               [12] 3927 	mov	a,r3
      007057 42 05            [12] 3928 	orl	ar5,a
                                   3929 ;	tmk_core/protocol/ch555/usb_ak820.c:633: length = raw_buffer[4];
      007059 90 07 A2         [24] 3930 	mov	dptr,#(_raw_buffer + 0x0004)
      00705C E0               [24] 3931 	movx	a,@dptr
      00705D FC               [12] 3932 	mov	r4,a
                                   3933 ;	tmk_core/protocol/ch555/usb_ak820.c:634: for (i = 5; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
      00705E 7B 05            [12] 3934 	mov	r3,#0x05
      007060                       3935 00151$:
      007060 EB               [12] 3936 	mov	a,r3
      007061 12 72 C2         [24] 3937 	lcall	_ak820_outline_0040
      007064 0B               [12] 3938 	inc	r3
      007065 BB 20 00         [24] 3939 	cjne	r3,#0x20,00432$
      007068                       3940 00432$:
      007068 40 F6            [24] 3941 	jc	00151$
                                   3942 ;	tmk_core/protocol/ch555/usb_ak820.c:635: if (length > RAW_EPSIZE - 5 || (length && address > 0xffffu - (length - 1))) {
      00706A EC               [12] 3943 	mov	a,r4
      00706B 24 E4            [12] 3944 	add	a,#0xff - 0x1b
      00706D 40 1C            [24] 3945 	jc	00106$
                                   3946 ;	free result
      00706F EC               [12] 3947 	mov	a,r4
      007070 60 26            [24] 3948 	jz	00212$
      007072 8C 03            [24] 3949 	mov	ar3,r4
      007074 1B               [12] 3950 	dec	r3
      007075 7A 00            [12] 3951 	mov	r2,#0x00
      007077 74 FF            [12] 3952 	mov	a,#0xff
      007079 C3               [12] 3953 	clr	c
      00707A 9B               [12] 3954 	subb	a,r3
      00707B FB               [12] 3955 	mov	r3,a
      00707C 74 FF            [12] 3956 	mov	a,#0xff
      00707E 9A               [12] 3957 	subb	a,r2
      00707F FA               [12] 3958 	mov	r2,a
      007080 8E 00            [24] 3959 	mov	ar0,r6
      007082 8D 01            [24] 3960 	mov	ar1,r5
      007084 C3               [12] 3961 	clr	c
      007085 EB               [12] 3962 	mov	a,r3
      007086 98               [12] 3963 	subb	a,r0
      007087 EA               [12] 3964 	mov	a,r2
      007088 99               [12] 3965 	subb	a,r1
      007089 50 0D            [24] 3966 	jnc	00212$
                                   3967 ;	free result
      00708B                       3968 00106$:
                                   3969 ;	tmk_core/protocol/ch555/usb_ak820.c:636: raw_buffer[1] = 0xff;
      00708B 90 07 9F         [24] 3970 	mov	dptr,#(_raw_buffer + 0x0001)
      00708E 74 FF            [12] 3971 	mov	a,#0xff
      007090 F0               [24] 3972 	movx	@dptr,a
                                   3973 ;	tmk_core/protocol/ch555/usb_ak820.c:637: raw_buffer[4] = 0;
      007091 90 07 A2         [24] 3974 	mov	dptr,#(_raw_buffer + 0x0004)
      007094 E4               [12] 3975 	clr	a
      007095 F0               [24] 3976 	movx	@dptr,a
                                   3977 ;	tmk_core/protocol/ch555/usb_ak820.c:639: for (i = 0; i < length; ++i) raw_buffer[5 + i] = READ_CODE(address + i);
      007096 80 3A            [24] 3978 	sjmp	00108$
      007098                       3979 00212$:
      007098 7B 00            [12] 3980 	mov	r3,#0x00
      00709A                       3981 00154$:
      00709A C3               [12] 3982 	clr	c
      00709B EB               [12] 3983 	mov	a,r3
      00709C 9C               [12] 3984 	subb	a,r4
      00709D 50 33            [24] 3985 	jnc	00108$
      00709F C0 04            [24] 3986 	push	ar4
      0070A1 8B 02            [24] 3987 	mov	ar2,r3
      0070A3 74 05            [12] 3988 	mov	a,#0x05
      0070A5 2A               [12] 3989 	add	a, r2
      0070A6 F9               [12] 3990 	mov	r1,a
      0070A7 33               [12] 3991 	rlc	a
      0070A8 95 E0            [12] 3992 	subb	a,acc
      0070AA FA               [12] 3993 	mov	r2,a
      0070AB E9               [12] 3994 	mov	a,r1
      0070AC 24 9E            [12] 3995 	add	a, #_raw_buffer
      0070AE F9               [12] 3996 	mov	r1,a
      0070AF EA               [12] 3997 	mov	a,r2
      0070B0 34 07            [12] 3998 	addc	a, #(_raw_buffer >> 8)
      0070B2 FA               [12] 3999 	mov	r2,a
      0070B3 8B 1E            [24] 4000 	mov	_ak820_usb_raw_task_sloc0_1_0,r3
      0070B5 75 1F 00         [24] 4001 	mov	(_ak820_usb_raw_task_sloc0_1_0 + 1),#0x00
      0070B8 8E 00            [24] 4002 	mov	ar0,r6
      0070BA 8D 04            [24] 4003 	mov	ar4,r5
      0070BC E5 1E            [12] 4004 	mov	a,_ak820_usb_raw_task_sloc0_1_0
      0070BE 28               [12] 4005 	add	a, r0
      0070BF F8               [12] 4006 	mov	r0,a
      0070C0 E5 1F            [12] 4007 	mov	a,(_ak820_usb_raw_task_sloc0_1_0 + 1)
      0070C2 3C               [12] 4008 	addc	a, r4
      0070C3 FC               [12] 4009 	mov	r4,a
      0070C4 88 82            [24] 4010 	mov	dpl,r0
      0070C6 8C 83            [24] 4011 	mov	dph,r4
      0070C8 E4               [12] 4012 	clr	a
      0070C9 93               [24] 4013 	movc	a,@a+dptr
      0070CA 12 72 CE         [24] 4014 	lcall	_ak820_outline_0136
      0070CD 0B               [12] 4015 	inc	r3
      0070CE D0 04            [24] 4016 	pop	ar4
      0070D0 80 C8            [24] 4017 	sjmp	00154$
      0070D2                       4018 00108$:
                                   4019 ;	tmk_core/protocol/ch555/usb_ak820.c:643: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
      0070D2 12 72 AE         [24] 4020 	lcall	_ak820_outline_0008
      0070D5 12 6C DF         [24] 4021 	lcall	_ak820_usb_send
      0070D8 02 72 5E         [24] 4022 	ljmp	00142$
      0070DB                       4023 00141$:
                                   4024 ;	tmk_core/protocol/ch555/usb_ak820.c:644: } else if (raw_buffer[0] == 0xfd && raw_buffer[1] == 1) {
      0070DB EF               [12] 4025 	mov	a,r7
      0070DC 70 03            [24] 4026 	jnz	00438$
      0070DE 02 71 60         [24] 4027 	ljmp	00137$
      0070E1                       4028 00438$:
      0070E1 90 07 9F         [24] 4029 	mov	dptr,#(_raw_buffer + 0x0001)
      0070E4 E0               [24] 4030 	movx	a,@dptr
      0070E5 FE               [12] 4031 	mov	r6,a
      0070E6 BE 01 02         [24] 4032 	cjne	r6,#0x01,00439$
      0070E9 80 03            [24] 4033 	sjmp	00440$
      0070EB                       4034 00439$:
      0070EB 02 71 60         [24] 4035 	ljmp	00137$
      0070EE                       4036 00440$:
                                   4037 ;	tmk_core/protocol/ch555/usb_ak820.c:647: for (i = 2; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
      0070EE 7E 02            [12] 4038 	mov	r6,#0x02
      0070F0                       4039 00156$:
      0070F0 EE               [12] 4040 	mov	a,r6
      0070F1 12 72 C2         [24] 4041 	lcall	_ak820_outline_0040
      0070F4 0E               [12] 4042 	inc	r6
      0070F5 BE 20 00         [24] 4043 	cjne	r6,#0x20,00441$
      0070F8                       4044 00441$:
      0070F8 40 F6            [24] 4045 	jc	00156$
                                   4046 ;	tmk_core/protocol/ch555/usb_ak820.c:648: raw_buffer[2] = 1;
      0070FA 90 07 A0         [24] 4047 	mov	dptr,#(_raw_buffer + 0x0002)
      0070FD 74 01            [12] 4048 	mov	a,#0x01
      0070FF F0               [24] 4049 	movx	@dptr,a
                                   4050 ;	tmk_core/protocol/ch555/usb_ak820.c:649: raw_buffer[3] = 0xa8;
      007100 90 07 A1         [24] 4051 	mov	dptr,#(_raw_buffer + 0x0003)
      007103 74 A8            [12] 4052 	mov	a,#0xa8
      007105 F0               [24] 4053 	movx	@dptr,a
                                   4054 ;	tmk_core/protocol/ch555/usb_ak820.c:650: ak820_nvm_diagnostic(&raw_buffer[4]);
      007106 90 07 A2         [24] 4055 	mov	dptr,#(_raw_buffer + 0x0004)
      007109 12 3E 11         [24] 4056 	lcall	_ak820_nvm_diagnostic
                                   4057 ;	tmk_core/protocol/ch555/usb_ak820.c:651: for (i = 0; i < 6; ++i) raw_buffer[11 + i] = ak820_flash_diagnostic[i];
      00710C 7E 00            [12] 4058 	mov	r6,#0x00
      00710E                       4059 00158$:
      00710E 8E 05            [24] 4060 	mov	ar5,r6
      007110 74 0B            [12] 4061 	mov	a,#0x0b
      007112 2D               [12] 4062 	add	a, r5
      007113 24 9E            [12] 4063 	add	a,#_raw_buffer
      007115 FD               [12] 4064 	mov	r5,a
      007116 E4               [12] 4065 	clr	a
      007117 34 07            [12] 4066 	addc	a, #(_raw_buffer >> 8)
      007119 FC               [12] 4067 	mov	r4,a
      00711A EE               [12] 4068 	mov	a,r6
      00711B 24 70            [12] 4069 	add	a, #_ak820_flash_diagnostic
      00711D F5 82            [12] 4070 	mov	dpl,a
      00711F E4               [12] 4071 	clr	a
      007120 34 04            [12] 4072 	addc	a, #(_ak820_flash_diagnostic >> 8)
      007122 F5 83            [12] 4073 	mov	dph,a
      007124 E0               [24] 4074 	movx	a,@dptr
      007125 12 46 10         [24] 4075 	lcall	_ak820_outline_0185
      007128 F0               [24] 4076 	movx	@dptr,a
      007129 0E               [12] 4077 	inc	r6
      00712A BE 06 00         [24] 4078 	cjne	r6,#0x06,00443$
      00712D                       4079 00443$:
      00712D 40 DF            [24] 4080 	jc	00158$
                                   4081 ;	tmk_core/protocol/ch555/usb_ak820.c:652: raw_buffer[17] = vial_unlocked;
      00712F 90 0E 2B         [24] 4082 	mov	dptr,#_vial_unlocked
      007132 E0               [24] 4083 	movx	a,@dptr
      007133 90 07 AF         [24] 4084 	mov	dptr,#(_raw_buffer + 0x0011)
      007136 F0               [24] 4085 	movx	@dptr,a
                                   4086 ;	tmk_core/protocol/ch555/usb_ak820.c:653: raw_buffer[18] = vial_unlock_in_progress;
      007137 90 0E 2C         [24] 4087 	mov	dptr,#_vial_unlock_in_progress
      00713A E0               [24] 4088 	movx	a,@dptr
      00713B 90 07 B0         [24] 4089 	mov	dptr,#(_raw_buffer + 0x0012)
      00713E F0               [24] 4090 	movx	@dptr,a
                                   4091 ;	tmk_core/protocol/ch555/usb_ak820.c:654: raw_buffer[19] = USB_EnumStatus;
      00713F 90 07 96         [24] 4092 	mov	dptr,#_USB_EnumStatus
      007142 E0               [24] 4093 	movx	a,@dptr
      007143 90 07 B1         [24] 4094 	mov	dptr,#(_raw_buffer + 0x0013)
      007146 F0               [24] 4095 	movx	@dptr,a
                                   4096 ;	tmk_core/protocol/ch555/usb_ak820.c:655: raw_buffer[20] = USB_SleepStatus;
      007147 90 07 97         [24] 4097 	mov	dptr,#_USB_SleepStatus
      00714A E0               [24] 4098 	movx	a,@dptr
      00714B 90 07 B2         [24] 4099 	mov	dptr,#(_raw_buffer + 0x0014)
      00714E F0               [24] 4100 	movx	@dptr,a
                                   4101 ;	tmk_core/protocol/ch555/usb_ak820.c:656: raw_buffer[21] = raw_state;
      00714F 90 07 9D         [24] 4102 	mov	dptr,#_raw_state
      007152 E0               [24] 4103 	movx	a,@dptr
      007153 90 07 B3         [24] 4104 	mov	dptr,#(_raw_buffer + 0x0015)
      007156 F0               [24] 4105 	movx	@dptr,a
                                   4106 ;	tmk_core/protocol/ch555/usb_ak820.c:657: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
      007157 12 72 AE         [24] 4107 	lcall	_ak820_outline_0008
      00715A 12 6C DF         [24] 4108 	lcall	_ak820_usb_send
      00715D 02 72 5E         [24] 4109 	ljmp	00142$
      007160                       4110 00137$:
                                   4111 ;	tmk_core/protocol/ch555/usb_ak820.c:659: } else if (raw_buffer[0] == 0xfd && raw_buffer[1] == 2) {
      007160 EF               [12] 4112 	mov	a,r7
      007161 70 03            [24] 4113 	jnz	00445$
      007163 02 72 3B         [24] 4114 	ljmp	00133$
      007166                       4115 00445$:
      007166 12 72 D4         [24] 4116 	lcall	_ak820_outline_0161
      007169 BF 02 02         [24] 4117 	cjne	r7,#0x02,00446$
      00716C 80 03            [24] 4118 	sjmp	00447$
      00716E                       4119 00446$:
      00716E 02 72 3B         [24] 4120 	ljmp	00133$
      007171                       4121 00447$:
                                   4122 ;	tmk_core/protocol/ch555/usb_ak820.c:663: length = 1;
      007171 90 08 0F         [24] 4123 	mov	dptr,#_ak820_usb_raw_task_length_10000_468
      007174 74 01            [12] 4124 	mov	a,#0x01
      007176 F0               [24] 4125 	movx	@dptr,a
                                   4126 ;	tmk_core/protocol/ch555/usb_ak820.c:664: if (raw_buffer[2] == 1 && raw_buffer[3] <= 1 && raw_buffer[4] <= AK820_OS_BREATHE &&
      007177 90 07 A0         [24] 4127 	mov	dptr,#(_raw_buffer + 0x0002)
      00717A E0               [24] 4128 	movx	a,@dptr
      00717B FF               [12] 4129 	mov	r7,a
      00717C BF 01 73         [24] 4130 	cjne	r7,#0x01,00235$
      00717F 90 07 A1         [24] 4131 	mov	dptr,#(_raw_buffer + 0x0003)
      007182 E0               [24] 4132 	movx	a,@dptr
      007183 FF               [12] 4133 	mov  r7,a
      007184 24 FE            [12] 4134 	add	a,#0xff - 0x01
      007186 40 6A            [24] 4135 	jc	00235$
                                   4136 ;	free result
      007188 90 07 A2         [24] 4137 	mov	dptr,#(_raw_buffer + 0x0004)
      00718B E0               [24] 4138 	movx	a,@dptr
      00718C FE               [12] 4139 	mov  r6,a
      00718D 24 FC            [12] 4140 	add	a,#0xff - 0x03
      00718F 40 61            [24] 4141 	jc	00235$
                                   4142 ;	free result
                                   4143 ;	tmk_core/protocol/ch555/usb_ak820.c:665: (raw_buffer[3] || !raw_buffer[4])) {
      007191 EF               [12] 4144 	mov	a,r7
      007192 70 03            [24] 4145 	jnz	00227$
      007194 EE               [12] 4146 	mov	a,r6
      007195 70 5B            [24] 4147 	jnz	00235$
                                   4148 ;	tmk_core/protocol/ch555/usb_ak820.c:666: for (i = 5; i < RAW_EPSIZE && !raw_buffer[i]; ++i) {}
      007197                       4149 00227$:
      007197 7D 05            [12] 4150 	mov	r5,#0x05
      007199                       4151 00162$:
      007199 BD 20 00         [24] 4152 	cjne	r5,#0x20,00454$
      00719C                       4153 00454$:
      00719C 50 11            [24] 4154 	jnc	00113$
      00719E ED               [12] 4155 	mov	a,r5
      00719F 24 9E            [12] 4156 	add	a, #_raw_buffer
      0071A1 FB               [12] 4157 	mov	r3,a
      0071A2 E4               [12] 4158 	clr	a
      0071A3 34 07            [12] 4159 	addc	a, #(_raw_buffer >> 8)
      0071A5 FC               [12] 4160 	mov	r4,a
      0071A6 12 36 42         [24] 4161 	lcall	_ak820_outline_0122
      0071A9 E0               [24] 4162 	movx	a,@dptr
      0071AA 70 03            [24] 4163 	jnz	00113$
      0071AC 0D               [12] 4164 	inc	r5
      0071AD 80 EA            [24] 4165 	sjmp	00162$
      0071AF                       4166 00113$:
                                   4167 ;	tmk_core/protocol/ch555/usb_ak820.c:667: if (i == RAW_EPSIZE) {
      0071AF BD 20 40         [24] 4168 	cjne	r5,#0x20,00235$
                                   4169 ;	tmk_core/protocol/ch555/usb_ak820.c:668: saved_ea = EA;
                                   4170 ;	assignBit
      0071B2 A2 AF            [12] 4171 	mov	c,_EA
      0071B4 92 1C            [24] 4172 	mov	_ak820_usb_raw_task_sloc1_1_0,c
                                   4173 ;	tmk_core/protocol/ch555/usb_ak820.c:669: EA = 0;
                                   4174 ;	assignBit
      0071B6 C2 AF            [12] 4175 	clr	_EA
                                   4176 ;	tmk_core/protocol/ch555/usb_ak820.c:672: if (raw_state == RAW_WORK && USB_EnumStatus && D0UsbConfig &&
      0071B8 90 07 9D         [24] 4177 	mov	dptr,#_raw_state
      0071BB E0               [24] 4178 	movx	a,@dptr
      0071BC FD               [12] 4179 	mov	r5,a
      0071BD BD 03 28         [24] 4180 	cjne	r5,#0x03,00117$
      0071C0 90 07 96         [24] 4181 	mov	dptr,#_USB_EnumStatus
      0071C3 E0               [24] 4182 	movx	a,@dptr
      0071C4 60 22            [24] 4183 	jz	00117$
      0071C6 90 07 95         [24] 4184 	mov	dptr,#_D0UsbConfig
      0071C9 E0               [24] 4185 	movx	a,@dptr
      0071CA 60 1C            [24] 4186 	jz	00117$
                                   4187 ;	tmk_core/protocol/ch555/usb_ak820.c:673: !(USB_SleepStatus & 2) && !vial_unlock_in_progress) {
      0071CC 90 07 97         [24] 4188 	mov	dptr,#_USB_SleepStatus
      0071CF E0               [24] 4189 	movx	a,@dptr
      0071D0 20 E1 15         [24] 4190 	jb	acc.1,00117$
      0071D3 90 0E 2C         [24] 4191 	mov	dptr,#_vial_unlock_in_progress
      0071D6 E0               [24] 4192 	movx	a,@dptr
      0071D7 70 0F            [24] 4193 	jnz	00117$
                                   4194 ;	tmk_core/protocol/ch555/usb_ak820.c:674: if (raw_buffer[3]) ak820_os_indicator_set(raw_buffer[4]);
      0071D9 EF               [12] 4195 	mov	a,r7
      0071DA 60 05            [24] 4196 	jz	00115$
      0071DC 8E 82            [24] 4197 	mov	dpl, r6
      0071DE 12 46 15         [24] 4198 	lcall	_ak820_os_indicator_set
      0071E1                       4199 00115$:
                                   4200 ;	tmk_core/protocol/ch555/usb_ak820.c:675: length = 0;
      0071E1 90 08 0F         [24] 4201 	mov	dptr,#_ak820_usb_raw_task_length_10000_468
      0071E4 E4               [12] 4202 	clr	a
      0071E5 F0               [24] 4203 	movx	@dptr,a
      0071E6 80 06            [24] 4204 	sjmp	00118$
      0071E8                       4205 00117$:
                                   4206 ;	tmk_core/protocol/ch555/usb_ak820.c:676: } else length = 2;
      0071E8 90 08 0F         [24] 4207 	mov	dptr,#_ak820_usb_raw_task_length_10000_468
      0071EB 74 02            [12] 4208 	mov	a,#0x02
      0071ED F0               [24] 4209 	movx	@dptr,a
      0071EE                       4210 00118$:
                                   4211 ;	tmk_core/protocol/ch555/usb_ak820.c:677: EA = saved_ea;
                                   4212 ;	assignBit
      0071EE A2 1C            [12] 4213 	mov	c,_ak820_usb_raw_task_sloc1_1_0
      0071F0 92 AF            [24] 4214 	mov	_EA,c
                                   4215 ;	tmk_core/protocol/ch555/usb_ak820.c:680: for (i = 2; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
      0071F2                       4216 00235$:
      0071F2 7F 02            [12] 4217 	mov	r7,#0x02
      0071F4                       4218 00164$:
      0071F4 EF               [12] 4219 	mov	a,r7
      0071F5 12 72 C2         [24] 4220 	lcall	_ak820_outline_0040
      0071F8 0F               [12] 4221 	inc	r7
      0071F9 BF 20 00         [24] 4222 	cjne	r7,#0x20,00466$
      0071FC                       4223 00466$:
      0071FC 40 F6            [24] 4224 	jc	00164$
                                   4225 ;	tmk_core/protocol/ch555/usb_ak820.c:681: raw_buffer[2] = 1;
      0071FE 90 07 A0         [24] 4226 	mov	dptr,#(_raw_buffer + 0x0002)
      007201 74 01            [12] 4227 	mov	a,#0x01
      007203 F0               [24] 4228 	movx	@dptr,a
                                   4229 ;	tmk_core/protocol/ch555/usb_ak820.c:682: raw_buffer[3] = length;
      007204 90 08 0F         [24] 4230 	mov	dptr,#_ak820_usb_raw_task_length_10000_468
      007207 E0               [24] 4231 	movx	a,@dptr
      007208 90 07 A1         [24] 4232 	mov	dptr,#(_raw_buffer + 0x0003)
      00720B F0               [24] 4233 	movx	@dptr,a
                                   4234 ;	tmk_core/protocol/ch555/usb_ak820.c:683: raw_buffer[4] = ak820_os_indicator_get();
      00720C 12 46 3C         [24] 4235 	lcall	_ak820_os_indicator_get
      00720F AF 82            [24] 4236 	mov	r7, dpl
      007211 90 07 A2         [24] 4237 	mov	dptr,#(_raw_buffer + 0x0004)
      007214 EF               [12] 4238 	mov	a,r7
      007215 F0               [24] 4239 	movx	@dptr,a
                                   4240 ;	tmk_core/protocol/ch555/usb_ak820.c:684: raw_buffer[5] = 0xa8;
      007216 90 07 A3         [24] 4241 	mov	dptr,#(_raw_buffer + 0x0005)
      007219 74 A8            [12] 4242 	mov	a,#0xa8
      00721B F0               [24] 4243 	movx	@dptr,a
                                   4244 ;	tmk_core/protocol/ch555/usb_ak820.c:685: raw_buffer[6] = (uint8_t)AK820_OS_INDICATOR_LEASE_MS;
      00721C 90 07 A4         [24] 4245 	mov	dptr,#(_raw_buffer + 0x0006)
      00721F 74 B8            [12] 4246 	mov	a,#0xb8
      007221 F0               [24] 4247 	movx	@dptr,a
                                   4248 ;	tmk_core/protocol/ch555/usb_ak820.c:686: raw_buffer[7] = (uint8_t)(AK820_OS_INDICATOR_LEASE_MS >> 8);
      007222 90 07 A5         [24] 4249 	mov	dptr,#(_raw_buffer + 0x0007)
      007225 74 0B            [12] 4250 	mov	a,#0x0b
      007227 F0               [24] 4251 	movx	@dptr,a
                                   4252 ;	tmk_core/protocol/ch555/usb_ak820.c:687: raw_buffer[8] = (uint8_t)AK820_OS_INDICATOR_PERIOD_MS;
      007228 90 07 A6         [24] 4253 	mov	dptr,#(_raw_buffer + 0x0008)
      00722B E4               [12] 4254 	clr	a
      00722C F0               [24] 4255 	movx	@dptr,a
                                   4256 ;	tmk_core/protocol/ch555/usb_ak820.c:688: raw_buffer[9] = (uint8_t)(AK820_OS_INDICATOR_PERIOD_MS >> 8);
      00722D 90 07 A7         [24] 4257 	mov	dptr,#(_raw_buffer + 0x0009)
      007230 74 10            [12] 4258 	mov	a,#0x10
      007232 F0               [24] 4259 	movx	@dptr,a
                                   4260 ;	tmk_core/protocol/ch555/usb_ak820.c:689: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
      007233 12 72 AE         [24] 4261 	lcall	_ak820_outline_0008
      007236 12 6C DF         [24] 4262 	lcall	_ak820_usb_send
      007239 80 23            [24] 4263 	sjmp	00142$
      00723B                       4264 00133$:
                                   4265 ;	tmk_core/protocol/ch555/usb_ak820.c:692: raw_reply_without_nvm = raw_request_is_nonpersistent();
      00723B 12 6E EE         [24] 4266 	lcall	_raw_request_is_nonpersistent
      00723E E5 82            [12] 4267 	mov	a, dpl
      007240 90 07 BE         [24] 4268 	mov	dptr,#_raw_reply_without_nvm
      007243 F0               [24] 4269 	movx	@dptr,a
                                   4270 ;	tmk_core/protocol/ch555/usb_ak820.c:693: ak820_nvm_begin();
      007244 12 41 F6         [24] 4271 	lcall	_ak820_nvm_begin
                                   4272 ;	tmk_core/protocol/ch555/usb_ak820.c:694: raw_hid_receive(raw_buffer, RAW_EPSIZE);
      007247 90 0C 5C         [24] 4273 	mov	dptr,#_raw_hid_receive_PARM_2
      00724A 74 20            [12] 4274 	mov	a,#0x20
      00724C F0               [24] 4275 	movx	@dptr,a
      00724D 90 07 9E         [24] 4276 	mov	dptr,#_raw_buffer
      007250 75 F0 00         [24] 4277 	mov	b, #0x00
      007253 12 AC 6D         [24] 4278 	lcall	_raw_hid_receive
                                   4279 ;	tmk_core/protocol/ch555/usb_ak820.c:695: ak820_nvm_end();
      007256 12 42 0B         [24] 4280 	lcall	_ak820_nvm_end
                                   4281 ;	tmk_core/protocol/ch555/usb_ak820.c:696: raw_reply_without_nvm = false;
      007259 90 07 BE         [24] 4282 	mov	dptr,#_raw_reply_without_nvm
      00725C E4               [12] 4283 	clr	a
      00725D F0               [24] 4284 	movx	@dptr,a
      00725E                       4285 00142$:
                                   4286 ;	tmk_core/protocol/ch555/usb_ak820.c:698: saved_ea = EA;
                                   4287 ;	assignBit
      00725E A2 AF            [12] 4288 	mov	c,_EA
      007260 92 1C            [24] 4289 	mov	_ak820_usb_raw_task_sloc1_1_0,c
                                   4290 ;	tmk_core/protocol/ch555/usb_ak820.c:699: EA = 0;
                                   4291 ;	assignBit
      007262 C2 AF            [12] 4292 	clr	_EA
                                   4293 ;	tmk_core/protocol/ch555/usb_ak820.c:701: if (raw_state == RAW_TX_ACTIVE) raw_state = RAW_TX_WAIT;
      007264 12 72 DA         [24] 4294 	lcall	_ak820_outline_0163
      007267 BF 04 08         [24] 4295 	cjne	r7,#0x04,00149$
      00726A 90 07 9D         [24] 4296 	mov	dptr,#_raw_state
      00726D 74 05            [12] 4297 	mov	a,#0x05
      00726F F0               [24] 4298 	movx	@dptr,a
      007270 80 1B            [24] 4299 	sjmp	00150$
      007272                       4300 00149$:
                                   4301 ;	tmk_core/protocol/ch555/usb_ak820.c:702: else if (raw_state == RAW_WORK || raw_state == RAW_DRAINED || raw_state == RAW_CANCELLED) raw_state = RAW_IDLE;
      007272 12 72 DA         [24] 4302 	lcall	_ak820_outline_0163
      007275 BF 03 02         [24] 4303 	cjne	r7,#0x03,00470$
      007278 80 0E            [24] 4304 	sjmp	00144$
      00727A                       4305 00470$:
      00727A 12 72 DA         [24] 4306 	lcall	_ak820_outline_0163
      00727D BF 06 02         [24] 4307 	cjne	r7,#0x06,00471$
      007280 80 06            [24] 4308 	sjmp	00144$
      007282                       4309 00471$:
      007282 12 72 DA         [24] 4310 	lcall	_ak820_outline_0163
      007285 BF 07 05         [24] 4311 	cjne	r7,#0x07,00150$
      007288                       4312 00144$:
      007288 90 07 9D         [24] 4313 	mov	dptr,#_raw_state
      00728B E4               [12] 4314 	clr	a
      00728C F0               [24] 4315 	movx	@dptr,a
      00728D                       4316 00150$:
                                   4317 ;	tmk_core/protocol/ch555/usb_ak820.c:703: EA = saved_ea;
                                   4318 ;	assignBit
      00728D A2 1C            [12] 4319 	mov	c,_ak820_usb_raw_task_sloc1_1_0
      00728F 92 AF            [24] 4320 	mov	_EA,c
                                   4321 ;	tmk_core/protocol/ch555/usb_ak820.c:704: }
      007291 22               [24] 4322 	ret
                                   4323 ;------------------------------------------------------------
                                   4324 ;Allocation info for local variables in function 'ak820_usb_take_keyboard_reset'
                                   4325 ;------------------------------------------------------------
                                   4326 ;result        Allocated with name '_ak820_usb_take_keyboard_reset_result_10000_498'
                                   4327 ;saved_ea      Allocated with name '_ak820_usb_take_keyboard_reset_saved_ea_10000_498'
                                   4328 ;------------------------------------------------------------
                                   4329 ;	tmk_core/protocol/ch555/usb_ak820.c:712: bool ak820_usb_take_keyboard_reset(void) {
                                   4330 ;	-----------------------------------------
                                   4331 ;	 function ak820_usb_take_keyboard_reset
                                   4332 ;	-----------------------------------------
      007292                       4333 _ak820_usb_take_keyboard_reset:
                                   4334 ;	tmk_core/protocol/ch555/usb_ak820.c:714: uint8_t saved_ea = EA;
                                   4335 ;	assignBit
      007292 A2 AF            [12] 4336 	mov	c,_EA
      007294 92 1D            [24] 4337 	mov	_ak820_usb_take_keyboard_reset_sloc0_1_0,c
                                   4338 ;	tmk_core/protocol/ch555/usb_ak820.c:715: EA = 0;
                                   4339 ;	assignBit
      007296 C2 AF            [12] 4340 	clr	_EA
                                   4341 ;	tmk_core/protocol/ch555/usb_ak820.c:716: result = keyboard_reset;
      007298 90 07 BF         [24] 4342 	mov	dptr,#_keyboard_reset
      00729B E0               [24] 4343 	movx	a,@dptr
      00729C FF               [12] 4344 	mov	r7,a
                                   4345 ;	tmk_core/protocol/ch555/usb_ak820.c:717: keyboard_reset = 0;
      00729D E4               [12] 4346 	clr	a
      00729E F0               [24] 4347 	movx	@dptr,a
                                   4348 ;	tmk_core/protocol/ch555/usb_ak820.c:718: EA = saved_ea;
                                   4349 ;	assignBit
      00729F A2 1D            [12] 4350 	mov	c,_ak820_usb_take_keyboard_reset_sloc0_1_0
      0072A1 92 AF            [24] 4351 	mov	_EA,c
                                   4352 ;	tmk_core/protocol/ch555/usb_ak820.c:719: return result != 0;
      0072A3 EF               [12] 4353 	mov	a,r7
      0072A4 B4 01 00         [24] 4354 	cjne	a,#0x01,00103$
      0072A7                       4355 00103$:
      0072A7 B3               [12] 4356 	cpl	c
      0072A8 92 1D            [24] 4357 	mov	_ak820_usb_take_keyboard_reset_sloc0_1_0,c
      0072AA 12 3A CC         [24] 4358 	lcall	_ak820_outline_0166
                                   4359 ;	tmk_core/protocol/ch555/usb_ak820.c:720: }
      0072AD 22               [24] 4360 	ret
                                   4361 	.area CSEG    (CODE)
                                   4362 	.area CONST   (CODE)
                                   4363 	.area CONST   (CODE)
      00BF46                       4364 _shared_offsets:
      00BF46 00                    4365 	.db #0x00	; 0
      00BF47 00                    4366 	.db #0x00	; 0
      00BF48 28                    4367 	.db #0x28	; 40
      00BF49 2E                    4368 	.db #0x2e	; 46
      00BF4A 31                    4369 	.db #0x31	; 49	'1'
      00BF4B 00                    4370 	.db #0x00	; 0
      00BF4C 08                    4371 	.db #0x08	; 8
                                   4372 	.area CSEG    (CODE)
                                   4373 	.area CONST   (CODE)
      00BF4D                       4374 _shared_lengths:
      00BF4D 00                    4375 	.db #0x00	; 0
      00BF4E 00                    4376 	.db #0x00	; 0
      00BF4F 06                    4377 	.db #0x06	; 6
      00BF50 03                    4378 	.db #0x03	; 3
      00BF51 03                    4379 	.db #0x03	; 3
      00BF52 00                    4380 	.db #0x00	; 0
      00BF53 20                    4381 	.db #0x20	; 32
                                   4382 	.area CSEG    (CODE)
                                   4383 	.area CONST   (CODE)
      00BF54                       4384 _interface_descriptors:
      00BF54 F7 C4                 4385 	.byte _KeyboardReport, (_KeyboardReport >> 8)
      00BF56 40 C6                 4386 	.byte (_ConfigurationDescriptor + 18), ((_ConfigurationDescriptor + 18) >> 8)
      00BF58 F3 C5                 4387 	.byte _RawReport, (_RawReport >> 8)
      00BF5A 59 C6                 4388 	.byte (_ConfigurationDescriptor + 43), ((_ConfigurationDescriptor + 43) >> 8)
      00BF5C 3C C5                 4389 	.byte _SharedReport, (_SharedReport >> 8)
      00BF5E 72 C6                 4390 	.byte (_ConfigurationDescriptor + 68), ((_ConfigurationDescriptor + 68) >> 8)
                                   4391 	.area CSEG    (CODE)
                                   4392 	.area XINIT   (CODE)
                                   4393 	.area CABS    (ABS,CODE)
                                   4394 
                                   4395 ; Experimental exact instruction outlining.
                                   4396 	.globl _ak820_outline_0008
                                   4397 	.globl _ak820_outline_0016
                                   4398 	.globl _ak820_outline_0037
                                   4399 	.globl _ak820_outline_0040
                                   4400 	.globl _ak820_outline_0097
                                   4401 	.globl _ak820_outline_0122
                                   4402 	.globl _ak820_outline_0136
                                   4403 	.globl _ak820_outline_0159
                                   4404 	.globl _ak820_outline_0161
                                   4405 	.globl _ak820_outline_0163
                                   4406 	.globl _ak820_outline_0166
                                   4407 	.globl _ak820_outline_0185
                                   4408 
                                   4409 	.area CSEG (CODE)
                                   4410 ; function ak820_outline_0008
      0072AE                       4411 _ak820_outline_0008:
      0072AE 90 08 01         [24] 4412 	mov	dptr,#_ak820_usb_send_PARM_2
      0072B1 74 9E            [12] 4413 	mov	a,#_raw_buffer
      0072B3 F0               [24] 4414 	movx	@dptr,a
      0072B4 74 07            [12] 4415 	mov	a,#(_raw_buffer>>8)
      0072B6 A3               [24] 4416 	inc	dptr
      0072B7 F0               [24] 4417 	movx	@dptr,a
      0072B8 90 08 03         [24] 4418 	mov	dptr,#_ak820_usb_send_PARM_3
      0072BB 74 20            [12] 4419 	mov	a,#0x20
      0072BD F0               [24] 4420 	movx	@dptr,a
      0072BE 75 82 03         [24] 4421 	mov	dpl,#0x03
      0072C1 22               [24] 4422 	ret
                                   4423 
                                   4424 	.area CSEG (CODE)
                                   4425 ; function ak820_outline_0040
      0072C2                       4426 _ak820_outline_0040:
      0072C2 24 9E            [12] 4427 	add	a,#_raw_buffer
      0072C4 F5 82            [12] 4428 	mov	dpl,a
      0072C6 E4               [12] 4429 	clr	a
      0072C7 34 07            [12] 4430 	addc	a,#(_raw_buffer>>8)
      0072C9 F5 83            [12] 4431 	mov	dph,a
      0072CB E4               [12] 4432 	clr	a
      0072CC F0               [24] 4433 	movx	@dptr,a
      0072CD 22               [24] 4434 	ret
                                   4435 
                                   4436 	.area CSEG (CODE)
                                   4437 ; function ak820_outline_0136
      0072CE                       4438 _ak820_outline_0136:
      0072CE 89 82            [24] 4439 	mov	dpl,r1
      0072D0 8A 83            [24] 4440 	mov	dph,r2
      0072D2 F0               [24] 4441 	movx	@dptr,a
      0072D3 22               [24] 4442 	ret
                                   4443 
                                   4444 	.area CSEG (CODE)
                                   4445 ; function ak820_outline_0161
      0072D4                       4446 _ak820_outline_0161:
      0072D4 90 07 9F         [24] 4447 	mov	dptr,#(_raw_buffer+0x0001)
      0072D7 E0               [24] 4448 	movx	a,@dptr
      0072D8 FF               [12] 4449 	mov	r7,a
      0072D9 22               [24] 4450 	ret
                                   4451 
                                   4452 	.area CSEG (CODE)
                                   4453 ; function ak820_outline_0163
      0072DA                       4454 _ak820_outline_0163:
      0072DA 90 07 9D         [24] 4455 	mov	dptr,#_raw_state
      0072DD E0               [24] 4456 	movx	a,@dptr
      0072DE FF               [12] 4457 	mov	r7,a
      0072DF 22               [24] 4458 	ret
