                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module usb_ak820
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_nvm_end
                                     12 	.globl _ak820_nvm_flush
                                     13 	.globl _ak820_nvm_begin
                                     14 	.globl _ak820_nvm_ok
                                     15 	.globl _ak820_os_indicator_get
                                     16 	.globl _ak820_os_indicator_set
                                     17 	.globl _ak820_nvm_diagnostic
                                     18 	.globl _mDelaymS
                                     19 	.globl _mDelayuS
                                     20 	.globl _raw_hid_receive
                                     21 	.globl _ADC_START
                                     22 	.globl _S0_R_FIFO
                                     23 	.globl _S0_T_FIFO
                                     24 	.globl _S0_FREE
                                     25 	.globl _S0_IF_BYTE
                                     26 	.globl _S0_IF_FIRST
                                     27 	.globl _S0_IF_OV
                                     28 	.globl _S0_FST_ACT
                                     29 	.globl _CP_RL2
                                     30 	.globl _C_T2
                                     31 	.globl _TR2
                                     32 	.globl _EXEN2
                                     33 	.globl _TCLK
                                     34 	.globl _RCLK
                                     35 	.globl _EXF2
                                     36 	.globl _CAP1F
                                     37 	.globl _TF2
                                     38 	.globl _RI
                                     39 	.globl _TI
                                     40 	.globl _RB8
                                     41 	.globl _TB8
                                     42 	.globl _REN
                                     43 	.globl _SM2
                                     44 	.globl _SM1
                                     45 	.globl _SM0
                                     46 	.globl _IT0
                                     47 	.globl _IE0
                                     48 	.globl _IT1
                                     49 	.globl _IE1
                                     50 	.globl _TR0
                                     51 	.globl _TF0
                                     52 	.globl _TR1
                                     53 	.globl _TF1
                                     54 	.globl _P4_0
                                     55 	.globl _P4_1
                                     56 	.globl _P4_2
                                     57 	.globl _P4_3
                                     58 	.globl _P4_4
                                     59 	.globl _P4_5
                                     60 	.globl _P4_6
                                     61 	.globl _RXD
                                     62 	.globl _TXD
                                     63 	.globl _INT0
                                     64 	.globl _INT1
                                     65 	.globl _T0
                                     66 	.globl _T1
                                     67 	.globl _MOSI1
                                     68 	.globl _MISO1
                                     69 	.globl _SCK1
                                     70 	.globl _P3_0
                                     71 	.globl _P3_1
                                     72 	.globl _P3_2
                                     73 	.globl _P3_3
                                     74 	.globl _P3_4
                                     75 	.globl _P3_5
                                     76 	.globl _P3_6
                                     77 	.globl _P3_7
                                     78 	.globl _CAP1_
                                     79 	.globl _T2_
                                     80 	.globl _CAP2_
                                     81 	.globl _T2EX_
                                     82 	.globl _RXD1
                                     83 	.globl _TXD1
                                     84 	.globl _P2_0
                                     85 	.globl _P2_1
                                     86 	.globl _P2_2
                                     87 	.globl _P2_3
                                     88 	.globl _P2_4
                                     89 	.globl _P2_5
                                     90 	.globl _P2_6
                                     91 	.globl _P2_7
                                     92 	.globl _AIN0
                                     93 	.globl _AIN1
                                     94 	.globl _AIN2
                                     95 	.globl _AIN3
                                     96 	.globl _AIN4
                                     97 	.globl _AIN5
                                     98 	.globl _AIN6
                                     99 	.globl _AIN7
                                    100 	.globl _CAP1
                                    101 	.globl _T2
                                    102 	.globl _CAP2
                                    103 	.globl _T2EX
                                    104 	.globl _INT0_
                                    105 	.globl _SCS
                                    106 	.globl _MOSI
                                    107 	.globl _MISO
                                    108 	.globl _SCK
                                    109 	.globl _RXD1_
                                    110 	.globl _TXD1_
                                    111 	.globl _P1_0
                                    112 	.globl _P1_1
                                    113 	.globl _P1_2
                                    114 	.globl _P1_3
                                    115 	.globl _P1_4
                                    116 	.globl _P1_5
                                    117 	.globl _P1_6
                                    118 	.globl _P1_7
                                    119 	.globl _AIN8
                                    120 	.globl _AIN9
                                    121 	.globl _AIN10
                                    122 	.globl _AIN11
                                    123 	.globl _AIN12
                                    124 	.globl _AIN13
                                    125 	.globl _RXD_
                                    126 	.globl _TXD_
                                    127 	.globl _SCL0
                                    128 	.globl _SDA0
                                    129 	.globl _P0_0
                                    130 	.globl _P0_1
                                    131 	.globl _P0_2
                                    132 	.globl _P0_3
                                    133 	.globl _P0_4
                                    134 	.globl _P0_5
                                    135 	.globl _P0_6
                                    136 	.globl _P0_7
                                    137 	.globl _IE_SPI0
                                    138 	.globl _IE_USB
                                    139 	.globl _IE_ADC
                                    140 	.globl _IE_UART1
                                    141 	.globl _IE_PWM_I2C
                                    142 	.globl _IE_GPIO
                                    143 	.globl _IE_WDOG
                                    144 	.globl _PX0
                                    145 	.globl _PT0
                                    146 	.globl _PX1
                                    147 	.globl _PT1
                                    148 	.globl _PS
                                    149 	.globl _PT2
                                    150 	.globl _PL_FLAG
                                    151 	.globl _PH_FLAG
                                    152 	.globl _EX0
                                    153 	.globl _ET0
                                    154 	.globl _EX1
                                    155 	.globl _ET1
                                    156 	.globl _ES
                                    157 	.globl _ET2
                                    158 	.globl _E_DIS
                                    159 	.globl _EA
                                    160 	.globl _P
                                    161 	.globl _F1
                                    162 	.globl _OV
                                    163 	.globl _RS0
                                    164 	.globl _RS1
                                    165 	.globl _F0
                                    166 	.globl _AC
                                    167 	.globl _CY
                                    168 	.globl _I2CS_INT_ST
                                    169 	.globl _I2CX_INT
                                    170 	.globl _LED_STATUS
                                    171 	.globl _LED_DMA_H
                                    172 	.globl _LED_DMA_L
                                    173 	.globl _LED_DMA
                                    174 	.globl _LED_PWM_OE
                                    175 	.globl _LED_COMMON
                                    176 	.globl _ADC_CHAN
                                    177 	.globl _ADC_DAT_H
                                    178 	.globl _ADC_DAT_L
                                    179 	.globl _ADC_DAT
                                    180 	.globl _ADC_CTRL
                                    181 	.globl _SPI1_CK_SE
                                    182 	.globl _SPI1_CTRL
                                    183 	.globl _SPI1_DATA
                                    184 	.globl _SPI1_STAT
                                    185 	.globl _SIF1
                                    186 	.globl _SBAUD1
                                    187 	.globl _SBUF1
                                    188 	.globl _SCON1
                                    189 	.globl _SPI0_SETUP
                                    190 	.globl _SPI0_CK_SE
                                    191 	.globl _SPI0_CTRL
                                    192 	.globl _SPI0_DATA
                                    193 	.globl _SPI0_STAT
                                    194 	.globl _T2CAP1H
                                    195 	.globl _T2CAP1L
                                    196 	.globl _T2CAP1
                                    197 	.globl _TH2
                                    198 	.globl _TL2
                                    199 	.globl _T2COUNT
                                    200 	.globl _RCAP2H
                                    201 	.globl _RCAP2L
                                    202 	.globl _RCAP2
                                    203 	.globl _T2MOD
                                    204 	.globl _T2CON
                                    205 	.globl _SBUF
                                    206 	.globl _SCON
                                    207 	.globl _TH1
                                    208 	.globl _TH0
                                    209 	.globl _TL1
                                    210 	.globl _TL0
                                    211 	.globl _TMOD
                                    212 	.globl _TCON
                                    213 	.globl _XBUS_AUX
                                    214 	.globl _P7
                                    215 	.globl _P6_DIR
                                    216 	.globl _P6_OUT_PU
                                    217 	.globl _P6_IN
                                    218 	.globl _P5_DIR
                                    219 	.globl _P5_OUT_PU
                                    220 	.globl _P5_IN
                                    221 	.globl _P4_LED_KEY
                                    222 	.globl _P4_DIR_PU
                                    223 	.globl _P4_MOD_OC
                                    224 	.globl _P4
                                    225 	.globl _P3_DIR_PU
                                    226 	.globl _P3_MOD_OC
                                    227 	.globl _P3
                                    228 	.globl _P2_DIR_PU
                                    229 	.globl _P2_MOD_OC
                                    230 	.globl _P2
                                    231 	.globl _P1_DIR_PU
                                    232 	.globl _P1_MOD_OC
                                    233 	.globl _P1
                                    234 	.globl _P0_DIR_PU
                                    235 	.globl _P0_MOD_OC
                                    236 	.globl _P0
                                    237 	.globl _ROM_CTRL
                                    238 	.globl _ROM_DATA_HH
                                    239 	.globl _ROM_DATA_HL
                                    240 	.globl _ROM_DATA_HI
                                    241 	.globl _ROM_ADDR_H
                                    242 	.globl _ROM_ADDR_L
                                    243 	.globl _ROM_ADDR
                                    244 	.globl _GPIO_IE
                                    245 	.globl _IP_EX
                                    246 	.globl _IE_EX
                                    247 	.globl _IP
                                    248 	.globl _IE
                                    249 	.globl _WDOG_COUNT
                                    250 	.globl _RESET_KEEP
                                    251 	.globl _WAKE_CTRL
                                    252 	.globl _CLOCK_CFG
                                    253 	.globl _POWER_CFG
                                    254 	.globl _PCON
                                    255 	.globl _GLOBAL_CFG
                                    256 	.globl _SAFE_MOD
                                    257 	.globl _DPH
                                    258 	.globl _DPL
                                    259 	.globl _SP
                                    260 	.globl _A_INV
                                    261 	.globl _B
                                    262 	.globl _ACC
                                    263 	.globl _PSW
                                    264 	.globl _ak820_usb_raw_send_PARM_2
                                    265 	.globl _ak820_usb_try_send_PARM_3
                                    266 	.globl _ak820_usb_try_send_PARM_2
                                    267 	.globl _ak820_usb_send_PARM_3
                                    268 	.globl _ak820_usb_send_PARM_2
                                    269 	.globl _ak820_main_heartbeat
                                    270 	.globl _ak820_boot_stage
                                    271 	.globl _KB_USB_SetReport
                                    272 	.globl _KB_USB_UpStatus
                                    273 	.globl _MCU_Sleep_Operate
                                    274 	.globl _USB_SleepStatus
                                    275 	.globl _USB_EnumStatus
                                    276 	.globl _D0UsbConfig
                                    277 	.globl _pD0Descr
                                    278 	.globl _D0SetupLen
                                    279 	.globl _D0SetupReqCode
                                    280 	.globl _USB_DeviceInterrupt
                                    281 	.globl _USB_Device_Init
                                    282 	.globl _USB_WakeUp_PC
                                    283 	.globl _ak820_usb_send
                                    284 	.globl _ak820_usb_try_send
                                    285 	.globl _ak820_usb_raw_send
                                    286 	.globl _ak820_usb_raw_task
                                    287 	.globl _ak820_usb_take_keyboard_reset
                                    288 ;--------------------------------------------------------
                                    289 ; special function registers
                                    290 ;--------------------------------------------------------
                                    291 	.area RSEG    (ABS,DATA)
      000000                        292 	.org 0x0000
                           0000D0   293 _PSW	=	0x00d0
                           0000E0   294 _ACC	=	0x00e0
                           0000F0   295 _B	=	0x00f0
                           0000FD   296 _A_INV	=	0x00fd
                           000081   297 _SP	=	0x0081
                           000082   298 _DPL	=	0x0082
                           000083   299 _DPH	=	0x0083
                           0000A1   300 _SAFE_MOD	=	0x00a1
                           0000B1   301 _GLOBAL_CFG	=	0x00b1
                           000087   302 _PCON	=	0x0087
                           0000BA   303 _POWER_CFG	=	0x00ba
                           0000B9   304 _CLOCK_CFG	=	0x00b9
                           0000A9   305 _WAKE_CTRL	=	0x00a9
                           0000FE   306 _RESET_KEEP	=	0x00fe
                           0000FF   307 _WDOG_COUNT	=	0x00ff
                           0000A8   308 _IE	=	0x00a8
                           0000B8   309 _IP	=	0x00b8
                           0000E8   310 _IE_EX	=	0x00e8
                           0000E9   311 _IP_EX	=	0x00e9
                           0000B2   312 _GPIO_IE	=	0x00b2
                           008584   313 _ROM_ADDR	=	0x8584
                           000084   314 _ROM_ADDR_L	=	0x0084
                           000085   315 _ROM_ADDR_H	=	0x0085
                           008F8E   316 _ROM_DATA_HI	=	0x8f8e
                           00008E   317 _ROM_DATA_HL	=	0x008e
                           00008F   318 _ROM_DATA_HH	=	0x008f
                           000086   319 _ROM_CTRL	=	0x0086
                           000080   320 _P0	=	0x0080
                           0000C4   321 _P0_MOD_OC	=	0x00c4
                           0000C5   322 _P0_DIR_PU	=	0x00c5
                           000090   323 _P1	=	0x0090
                           000092   324 _P1_MOD_OC	=	0x0092
                           000093   325 _P1_DIR_PU	=	0x0093
                           0000A0   326 _P2	=	0x00a0
                           000094   327 _P2_MOD_OC	=	0x0094
                           000095   328 _P2_DIR_PU	=	0x0095
                           0000B0   329 _P3	=	0x00b0
                           000096   330 _P3_MOD_OC	=	0x0096
                           000097   331 _P3_DIR_PU	=	0x0097
                           0000C0   332 _P4	=	0x00c0
                           0000C2   333 _P4_MOD_OC	=	0x00c2
                           0000C3   334 _P4_DIR_PU	=	0x00c3
                           0000C1   335 _P4_LED_KEY	=	0x00c1
                           0000AA   336 _P5_IN	=	0x00aa
                           0000AB   337 _P5_OUT_PU	=	0x00ab
                           0000AC   338 _P5_DIR	=	0x00ac
                           0000AD   339 _P6_IN	=	0x00ad
                           0000AE   340 _P6_OUT_PU	=	0x00ae
                           0000AF   341 _P6_DIR	=	0x00af
                           0000F1   342 _P7	=	0x00f1
                           0000A2   343 _XBUS_AUX	=	0x00a2
                           000088   344 _TCON	=	0x0088
                           000089   345 _TMOD	=	0x0089
                           00008A   346 _TL0	=	0x008a
                           00008B   347 _TL1	=	0x008b
                           00008C   348 _TH0	=	0x008c
                           00008D   349 _TH1	=	0x008d
                           000098   350 _SCON	=	0x0098
                           000099   351 _SBUF	=	0x0099
                           0000C8   352 _T2CON	=	0x00c8
                           0000C9   353 _T2MOD	=	0x00c9
                           00CBCA   354 _RCAP2	=	0xcbca
                           0000CA   355 _RCAP2L	=	0x00ca
                           0000CB   356 _RCAP2H	=	0x00cb
                           00CDCC   357 _T2COUNT	=	0xcdcc
                           0000CC   358 _TL2	=	0x00cc
                           0000CD   359 _TH2	=	0x00cd
                           00CFCE   360 _T2CAP1	=	0xcfce
                           0000CE   361 _T2CAP1L	=	0x00ce
                           0000CF   362 _T2CAP1H	=	0x00cf
                           0000F8   363 _SPI0_STAT	=	0x00f8
                           0000F9   364 _SPI0_DATA	=	0x00f9
                           0000FA   365 _SPI0_CTRL	=	0x00fa
                           0000FB   366 _SPI0_CK_SE	=	0x00fb
                           0000FC   367 _SPI0_SETUP	=	0x00fc
                           0000BC   368 _SCON1	=	0x00bc
                           0000BD   369 _SBUF1	=	0x00bd
                           0000BE   370 _SBAUD1	=	0x00be
                           0000BF   371 _SIF1	=	0x00bf
                           0000B4   372 _SPI1_STAT	=	0x00b4
                           0000B5   373 _SPI1_DATA	=	0x00b5
                           0000B6   374 _SPI1_CTRL	=	0x00b6
                           0000B7   375 _SPI1_CK_SE	=	0x00b7
                           0000F3   376 _ADC_CTRL	=	0x00f3
                           00F5F4   377 _ADC_DAT	=	0xf5f4
                           0000F4   378 _ADC_DAT_L	=	0x00f4
                           0000F5   379 _ADC_DAT_H	=	0x00f5
                           0000F6   380 _ADC_CHAN	=	0x00f6
                           0000A6   381 _LED_COMMON	=	0x00a6
                           0000A7   382 _LED_PWM_OE	=	0x00a7
                           00C7C6   383 _LED_DMA	=	0xc7c6
                           0000C6   384 _LED_DMA_L	=	0x00c6
                           0000C7   385 _LED_DMA_H	=	0x00c7
                           0000F7   386 _LED_STATUS	=	0x00f7
                           0000B3   387 _I2CX_INT	=	0x00b3
                           0000BB   388 _I2CS_INT_ST	=	0x00bb
                                    389 ;--------------------------------------------------------
                                    390 ; special function bits
                                    391 ;--------------------------------------------------------
                                    392 	.area RSEG    (ABS,DATA)
      000000                        393 	.org 0x0000
                           0000D7   394 _CY	=	0x00d7
                           0000D6   395 _AC	=	0x00d6
                           0000D5   396 _F0	=	0x00d5
                           0000D4   397 _RS1	=	0x00d4
                           0000D3   398 _RS0	=	0x00d3
                           0000D2   399 _OV	=	0x00d2
                           0000D1   400 _F1	=	0x00d1
                           0000D0   401 _P	=	0x00d0
                           0000AF   402 _EA	=	0x00af
                           0000AE   403 _E_DIS	=	0x00ae
                           0000AD   404 _ET2	=	0x00ad
                           0000AC   405 _ES	=	0x00ac
                           0000AB   406 _ET1	=	0x00ab
                           0000AA   407 _EX1	=	0x00aa
                           0000A9   408 _ET0	=	0x00a9
                           0000A8   409 _EX0	=	0x00a8
                           0000BF   410 _PH_FLAG	=	0x00bf
                           0000BE   411 _PL_FLAG	=	0x00be
                           0000BD   412 _PT2	=	0x00bd
                           0000BC   413 _PS	=	0x00bc
                           0000BB   414 _PT1	=	0x00bb
                           0000BA   415 _PX1	=	0x00ba
                           0000B9   416 _PT0	=	0x00b9
                           0000B8   417 _PX0	=	0x00b8
                           0000EF   418 _IE_WDOG	=	0x00ef
                           0000EE   419 _IE_GPIO	=	0x00ee
                           0000ED   420 _IE_PWM_I2C	=	0x00ed
                           0000EC   421 _IE_UART1	=	0x00ec
                           0000EB   422 _IE_ADC	=	0x00eb
                           0000E9   423 _IE_USB	=	0x00e9
                           0000E8   424 _IE_SPI0	=	0x00e8
                           000087   425 _P0_7	=	0x0087
                           000086   426 _P0_6	=	0x0086
                           000085   427 _P0_5	=	0x0085
                           000084   428 _P0_4	=	0x0084
                           000083   429 _P0_3	=	0x0083
                           000082   430 _P0_2	=	0x0082
                           000081   431 _P0_1	=	0x0081
                           000080   432 _P0_0	=	0x0080
                           000081   433 _SDA0	=	0x0081
                           000080   434 _SCL0	=	0x0080
                           000083   435 _TXD_	=	0x0083
                           000082   436 _RXD_	=	0x0082
                           000085   437 _AIN13	=	0x0085
                           000084   438 _AIN12	=	0x0084
                           000083   439 _AIN11	=	0x0083
                           000082   440 _AIN10	=	0x0082
                           000081   441 _AIN9	=	0x0081
                           000080   442 _AIN8	=	0x0080
                           000097   443 _P1_7	=	0x0097
                           000096   444 _P1_6	=	0x0096
                           000095   445 _P1_5	=	0x0095
                           000094   446 _P1_4	=	0x0094
                           000093   447 _P1_3	=	0x0093
                           000092   448 _P1_2	=	0x0092
                           000091   449 _P1_1	=	0x0091
                           000090   450 _P1_0	=	0x0090
                           000097   451 _TXD1_	=	0x0097
                           000096   452 _RXD1_	=	0x0096
                           000097   453 _SCK	=	0x0097
                           000096   454 _MISO	=	0x0096
                           000095   455 _MOSI	=	0x0095
                           000094   456 _SCS	=	0x0094
                           000092   457 _INT0_	=	0x0092
                           000091   458 _T2EX	=	0x0091
                           000091   459 _CAP2	=	0x0091
                           000090   460 _T2	=	0x0090
                           000090   461 _CAP1	=	0x0090
                           000097   462 _AIN7	=	0x0097
                           000096   463 _AIN6	=	0x0096
                           000095   464 _AIN5	=	0x0095
                           000094   465 _AIN4	=	0x0094
                           000093   466 _AIN3	=	0x0093
                           000092   467 _AIN2	=	0x0092
                           000091   468 _AIN1	=	0x0091
                           000090   469 _AIN0	=	0x0090
                           0000A7   470 _P2_7	=	0x00a7
                           0000A6   471 _P2_6	=	0x00a6
                           0000A5   472 _P2_5	=	0x00a5
                           0000A4   473 _P2_4	=	0x00a4
                           0000A3   474 _P2_3	=	0x00a3
                           0000A2   475 _P2_2	=	0x00a2
                           0000A1   476 _P2_1	=	0x00a1
                           0000A0   477 _P2_0	=	0x00a0
                           0000A7   478 _TXD1	=	0x00a7
                           0000A6   479 _RXD1	=	0x00a6
                           0000A5   480 _T2EX_	=	0x00a5
                           0000A5   481 _CAP2_	=	0x00a5
                           0000A4   482 _T2_	=	0x00a4
                           0000A4   483 _CAP1_	=	0x00a4
                           0000B7   484 _P3_7	=	0x00b7
                           0000B6   485 _P3_6	=	0x00b6
                           0000B5   486 _P3_5	=	0x00b5
                           0000B4   487 _P3_4	=	0x00b4
                           0000B3   488 _P3_3	=	0x00b3
                           0000B2   489 _P3_2	=	0x00b2
                           0000B1   490 _P3_1	=	0x00b1
                           0000B0   491 _P3_0	=	0x00b0
                           0000B7   492 _SCK1	=	0x00b7
                           0000B6   493 _MISO1	=	0x00b6
                           0000B5   494 _MOSI1	=	0x00b5
                           0000B5   495 _T1	=	0x00b5
                           0000B4   496 _T0	=	0x00b4
                           0000B3   497 _INT1	=	0x00b3
                           0000B2   498 _INT0	=	0x00b2
                           0000B1   499 _TXD	=	0x00b1
                           0000B0   500 _RXD	=	0x00b0
                           0000C6   501 _P4_6	=	0x00c6
                           0000C5   502 _P4_5	=	0x00c5
                           0000C4   503 _P4_4	=	0x00c4
                           0000C3   504 _P4_3	=	0x00c3
                           0000C2   505 _P4_2	=	0x00c2
                           0000C1   506 _P4_1	=	0x00c1
                           0000C0   507 _P4_0	=	0x00c0
                           00008F   508 _TF1	=	0x008f
                           00008E   509 _TR1	=	0x008e
                           00008D   510 _TF0	=	0x008d
                           00008C   511 _TR0	=	0x008c
                           00008B   512 _IE1	=	0x008b
                           00008A   513 _IT1	=	0x008a
                           000089   514 _IE0	=	0x0089
                           000088   515 _IT0	=	0x0088
                           00009F   516 _SM0	=	0x009f
                           00009E   517 _SM1	=	0x009e
                           00009D   518 _SM2	=	0x009d
                           00009C   519 _REN	=	0x009c
                           00009B   520 _TB8	=	0x009b
                           00009A   521 _RB8	=	0x009a
                           000099   522 _TI	=	0x0099
                           000098   523 _RI	=	0x0098
                           0000CF   524 _TF2	=	0x00cf
                           0000CF   525 _CAP1F	=	0x00cf
                           0000CE   526 _EXF2	=	0x00ce
                           0000CD   527 _RCLK	=	0x00cd
                           0000CC   528 _TCLK	=	0x00cc
                           0000CB   529 _EXEN2	=	0x00cb
                           0000CA   530 _TR2	=	0x00ca
                           0000C9   531 _C_T2	=	0x00c9
                           0000C8   532 _CP_RL2	=	0x00c8
                           0000FF   533 _S0_FST_ACT	=	0x00ff
                           0000FE   534 _S0_IF_OV	=	0x00fe
                           0000FD   535 _S0_IF_FIRST	=	0x00fd
                           0000FC   536 _S0_IF_BYTE	=	0x00fc
                           0000FB   537 _S0_FREE	=	0x00fb
                           0000FA   538 _S0_T_FIFO	=	0x00fa
                           0000F8   539 _S0_R_FIFO	=	0x00f8
                           0000F7   540 _ADC_START	=	0x00f7
                                    541 ;--------------------------------------------------------
                                    542 ; overlayable register banks
                                    543 ;--------------------------------------------------------
                                    544 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        545 	.ds 8
                                    546 ;--------------------------------------------------------
                                    547 ; internal ram data
                                    548 ;--------------------------------------------------------
                                    549 	.area DSEG    (DATA)
      000016                        550 _control_setup_sloc1_1_0:
      000016                        551 	.ds 1
      000017                        552 _control_setup_sloc3_1_0:
      000017                        553 	.ds 2
      000019                        554 _control_setup_sloc4_1_0:
      000019                        555 	.ds 2
      00001B                        556 _ak820_usb_send_sloc0_1_0:
      00001B                        557 	.ds 2
      00001D                        558 _ak820_usb_send_sloc1_1_0:
      00001D                        559 	.ds 1
      00001E                        560 _ak820_usb_raw_task_sloc0_1_0:
      00001E                        561 	.ds 2
                                    562 ;--------------------------------------------------------
                                    563 ; overlayable items in internal ram
                                    564 ;--------------------------------------------------------
                                    565 ;--------------------------------------------------------
                                    566 ; indirectly addressable internal ram data
                                    567 ;--------------------------------------------------------
                                    568 	.area ISEG    (DATA)
                                    569 ;--------------------------------------------------------
                                    570 ; absolute internal ram data
                                    571 ;--------------------------------------------------------
                                    572 	.area IABS    (ABS,DATA)
                                    573 	.area IABS    (ABS,DATA)
                                    574 ;--------------------------------------------------------
                                    575 ; bit data
                                    576 ;--------------------------------------------------------
                                    577 	.area BSEG    (BIT)
      000015                        578 _control_setup_valid_interface_10000_290:
      000015                        579 	.ds 1
      000016                        580 _control_setup_zero_index_10000_290:
      000016                        581 	.ds 1
      000017                        582 _control_setup_zero_value_10000_290:
      000017                        583 	.ds 1
      000018                        584 _control_setup_zero_length_10000_290:
      000018                        585 	.ds 1
      000019                        586 _control_setup_sloc0_1_0:
      000019                        587 	.ds 1
      00001A                        588 _control_setup_sloc2_1_0:
      00001A                        589 	.ds 1
      00001B                        590 _ak820_usb_try_send_sloc0_1_0:
      00001B                        591 	.ds 1
      00001C                        592 _ak820_usb_raw_task_sloc1_1_0:
      00001C                        593 	.ds 1
      00001D                        594 _ak820_usb_take_keyboard_reset_sloc0_1_0:
      00001D                        595 	.ds 1
                                    596 ;--------------------------------------------------------
                                    597 ; paged external ram data
                                    598 ;--------------------------------------------------------
                                    599 	.area PSEG    (PAG,XDATA)
                                    600 ;--------------------------------------------------------
                                    601 ; uninitialized external ram data
                                    602 ;--------------------------------------------------------
                                    603 	.area XSEG    (XDATA)
      00078F                        604 _D0SetupReqCode::
      00078F                        605 	.ds 1
      000790                        606 _D0SetupLen::
      000790                        607 	.ds 2
      000792                        608 _pD0Descr::
      000792                        609 	.ds 3
      000795                        610 _D0UsbConfig::
      000795                        611 	.ds 1
      000796                        612 _USB_EnumStatus::
      000796                        613 	.ds 1
      000797                        614 _USB_SleepStatus::
      000797                        615 	.ds 1
      000798                        616 _MCU_Sleep_Operate::
      000798                        617 	.ds 1
      000799                        618 _KB_USB_UpStatus::
      000799                        619 	.ds 1
      00079A                        620 _KB_USB_SetReport::
      00079A                        621 	.ds 1
      00079B                        622 _ak820_boot_stage::
      00079B                        623 	.ds 1
      00079C                        624 _ak820_main_heartbeat::
      00079C                        625 	.ds 1
      00079D                        626 _raw_state:
      00079D                        627 	.ds 1
      00079E                        628 _raw_buffer:
      00079E                        629 	.ds 32
      0007BE                        630 _raw_reply_without_nvm:
      0007BE                        631 	.ds 1
      0007BF                        632 _keyboard_reset:
      0007BF                        633 	.ds 1
      0007C0                        634 _input_snapshot:
      0007C0                        635 	.ds 52
      0007F4                        636 _control_phase:
      0007F4                        637 	.ds 1
      0007F5                        638 _output_kind:
      0007F5                        639 	.ds 1
      0007F6                        640 _output_report_id:
      0007F6                        641 	.ds 1
      0007F7                        642 _control_zlp:
      0007F7                        643 	.ds 1
      0007F8                        644 _control_pointer:
      0007F8                        645 	.ds 2
      0007FA                        646 _descriptor_select_PARM_2:
      0007FA                        647 	.ds 1
      0007FB                        648 _descriptor_select_PARM_3:
      0007FB                        649 	.ds 2
      0007FD                        650 _descriptor_select_type_10000_272:
      0007FD                        651 	.ds 1
      0007FE                        652 _control_setup_length_10000_290:
      0007FE                        653 	.ds 2
      000800                        654 _control_setup_offset_10000_290:
      000800                        655 	.ds 1
      000801                        656 _ak820_usb_send_PARM_2:
      000801                        657 	.ds 2
      000803                        658 _ak820_usb_send_PARM_3:
      000803                        659 	.ds 1
      000804                        660 _ak820_usb_send_endpoint_10000_426:
      000804                        661 	.ds 1
      000805                        662 _ak820_usb_send_offset_10000_427:
      000805                        663 	.ds 1
      000806                        664 _ak820_usb_try_send_PARM_2:
      000806                        665 	.ds 2
      000808                        666 _ak820_usb_try_send_PARM_3:
      000808                        667 	.ds 1
      000809                        668 _ak820_usb_try_send_endpoint_10000_447:
      000809                        669 	.ds 1
      00080A                        670 _ak820_usb_try_send_sent_10000_448:
      00080A                        671 	.ds 1
      00080B                        672 _ak820_usb_raw_send_PARM_2:
      00080B                        673 	.ds 1
      00080C                        674 _ak820_usb_raw_send_report_10000_463:
      00080C                        675 	.ds 3
      00080F                        676 _ak820_usb_raw_task_length_10000_468:
      00080F                        677 	.ds 1
                                    678 ;--------------------------------------------------------
                                    679 ; absolute external ram data
                                    680 ;--------------------------------------------------------
                                    681 	.area XABS    (ABS,XDATA)
                                    682 ;--------------------------------------------------------
                                    683 ; initialized external ram data
                                    684 ;--------------------------------------------------------
                                    685 	.area XISEG   (XDATA)
                                    686 	.area HOME    (CODE)
                                    687 	.area GSINIT0 (CODE)
                                    688 	.area GSINIT1 (CODE)
                                    689 	.area GSINIT2 (CODE)
                                    690 	.area GSINIT3 (CODE)
                                    691 	.area GSINIT4 (CODE)
                                    692 	.area GSINIT5 (CODE)
                                    693 	.area GSINIT  (CODE)
                                    694 	.area GSFINAL (CODE)
                                    695 	.area CSEG    (CODE)
                                    696 ;--------------------------------------------------------
                                    697 ; global & static initialisations
                                    698 ;--------------------------------------------------------
                                    699 	.area HOME    (CODE)
                                    700 	.area GSINIT  (CODE)
                                    701 	.area GSFINAL (CODE)
                                    702 	.area GSINIT  (CODE)
                                    703 ;--------------------------------------------------------
                                    704 ; Home
                                    705 ;--------------------------------------------------------
                                    706 	.area HOME    (CODE)
                                    707 	.area HOME    (CODE)
                                    708 ;--------------------------------------------------------
                                    709 ; code
                                    710 ;--------------------------------------------------------
                                    711 	.area CSEG    (CODE)
                                    712 ;------------------------------------------------------------
                                    713 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    714 ;------------------------------------------------------------
                                    715 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_45'
                                    716 ;------------------------------------------------------------
                                    717 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    718 ;	-----------------------------------------
                           000007   719 	ar7 = 0x07
                           000006   720 	ar6 = 0x06
                           000005   721 	ar5 = 0x05
                           000004   722 	ar4 = 0x04
                           000003   723 	ar3 = 0x03
                           000002   724 	ar2 = 0x02
                           000001   725 	ar1 = 0x01
                           000000   726 	ar0 = 0x00
                                    727 ;	 function raw_abort
                                    728 ;	-----------------------------------------
      005FBE                        729 _raw_abort:
                                    730 ;	tmk_core/protocol/ch555/usb_ak820.c:97: if (raw_state == RAW_WORK || raw_state == RAW_TX_ACTIVE ||
      005FBE 90 07 9D         [24]  731 	mov	dptr,#_raw_state
      005FC1 E0               [24]  732 	movx	a,@dptr
      005FC2 FF               [12]  733 	mov	r7,a
      005FC3 BF 03 02         [24]  734 	cjne	r7,#0x03,00130$
      005FC6 80 1C            [24]  735 	sjmp	00101$
      005FC8                        736 00130$:
      005FC8 90 07 9D         [24]  737 	mov	dptr,#_raw_state
      005FCB E0               [24]  738 	movx	a,@dptr
      005FCC FF               [12]  739 	mov	r7,a
      005FCD BF 04 02         [24]  740 	cjne	r7,#0x04,00131$
      005FD0 80 12            [24]  741 	sjmp	00101$
      005FD2                        742 00131$:
                                    743 ;	tmk_core/protocol/ch555/usb_ak820.c:98: raw_state == RAW_DRAINED || raw_state == RAW_CANCELLED)
      005FD2 90 07 9D         [24]  744 	mov	dptr,#_raw_state
      005FD5 E0               [24]  745 	movx	a,@dptr
      005FD6 FF               [12]  746 	mov	r7,a
      005FD7 BF 06 02         [24]  747 	cjne	r7,#0x06,00132$
      005FDA 80 08            [24]  748 	sjmp	00101$
      005FDC                        749 00132$:
      005FDC 90 07 9D         [24]  750 	mov	dptr,#_raw_state
      005FDF E0               [24]  751 	movx	a,@dptr
      005FE0 FF               [12]  752 	mov	r7,a
      005FE1 BF 07 08         [24]  753 	cjne	r7,#0x07,00102$
      005FE4                        754 00101$:
                                    755 ;	tmk_core/protocol/ch555/usb_ak820.c:99: raw_state = RAW_CANCELLED;
      005FE4 90 07 9D         [24]  756 	mov	dptr,#_raw_state
      005FE7 74 07            [12]  757 	mov	a,#0x07
      005FE9 F0               [24]  758 	movx	@dptr,a
      005FEA 80 05            [24]  759 	sjmp	00103$
      005FEC                        760 00102$:
                                    761 ;	tmk_core/protocol/ch555/usb_ak820.c:101: raw_state = RAW_IDLE;
      005FEC 90 07 9D         [24]  762 	mov	dptr,#_raw_state
      005FEF E4               [12]  763 	clr	a
      005FF0 F0               [24]  764 	movx	@dptr,a
      005FF1                        765 00103$:
                                    766 ;	tmk_core/protocol/ch555/usb_ak820.c:102: output_kind = OUTPUT_NONE;
      005FF1 90 07 F5         [24]  767 	mov	dptr,#_output_kind
      005FF4 E4               [12]  768 	clr	a
      005FF5 F0               [24]  769 	movx	@dptr,a
                                    770 ;	tmk_core/protocol/ch555/usb_ak820.c:103: }
      005FF6 22               [24]  771 	ret
                                    772 ;------------------------------------------------------------
                                    773 ;Allocation info for local variables in function 'raw_complete'
                                    774 ;------------------------------------------------------------
                                    775 ;	tmk_core/protocol/ch555/usb_ak820.c:105: static void raw_complete(void) {
                                    776 ;	-----------------------------------------
                                    777 ;	 function raw_complete
                                    778 ;	-----------------------------------------
      005FF7                        779 _raw_complete:
                                    780 ;	tmk_core/protocol/ch555/usb_ak820.c:106: if (raw_state == RAW_TX_ACTIVE) raw_state = RAW_DRAINED;
      005FF7 90 07 9D         [24]  781 	mov	dptr,#_raw_state
      005FFA E0               [24]  782 	movx	a,@dptr
      005FFB FF               [12]  783 	mov	r7,a
      005FFC BF 04 07         [24]  784 	cjne	r7,#0x04,00104$
      005FFF 90 07 9D         [24]  785 	mov	dptr,#_raw_state
      006002 74 06            [12]  786 	mov	a,#0x06
      006004 F0               [24]  787 	movx	@dptr,a
      006005 22               [24]  788 	ret
      006006                        789 00104$:
                                    790 ;	tmk_core/protocol/ch555/usb_ak820.c:107: else if (raw_state == RAW_TX_WAIT) raw_state = RAW_IDLE;
      006006 90 07 9D         [24]  791 	mov	dptr,#_raw_state
      006009 E0               [24]  792 	movx	a,@dptr
      00600A FF               [12]  793 	mov	r7,a
      00600B BF 05 05         [24]  794 	cjne	r7,#0x05,00106$
      00600E 90 07 9D         [24]  795 	mov	dptr,#_raw_state
      006011 E4               [12]  796 	clr	a
      006012 F0               [24]  797 	movx	@dptr,a
      006013                        798 00106$:
                                    799 ;	tmk_core/protocol/ch555/usb_ak820.c:108: }
      006013 22               [24]  800 	ret
                                    801 ;------------------------------------------------------------
                                    802 ;Allocation info for local variables in function 'endpoints_reset'
                                    803 ;------------------------------------------------------------
                                    804 ;i             Allocated with name '_endpoints_reset_i_10000_262'
                                    805 ;------------------------------------------------------------
                                    806 ;	tmk_core/protocol/ch555/usb_ak820.c:110: static void endpoints_reset(void) {
                                    807 ;	-----------------------------------------
                                    808 ;	 function endpoints_reset
                                    809 ;	-----------------------------------------
      006014                        810 _endpoints_reset:
                                    811 ;	tmk_core/protocol/ch555/usb_ak820.c:113: ak820_os_indicator_mode = AK820_OS_NORMAL;
      006014 90 05 AA         [24]  812 	mov	dptr,#_ak820_os_indicator_mode
      006017 E4               [12]  813 	clr	a
      006018 F0               [24]  814 	movx	@dptr,a
                                    815 ;	tmk_core/protocol/ch555/usb_ak820.c:116: D0_EP_MOD = bUX_DEV_EN;
      006019 90 22 0C         [24]  816 	mov	dptr,#0x220c
      00601C 04               [12]  817 	inc	a
      00601D F0               [24]  818 	movx	@dptr,a
                                    819 ;	tmk_core/protocol/ch555/usb_ak820.c:117: D0_EP1RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      00601E F5 82            [12]  820 	mov	dpl,a
      006020 74 12            [12]  821 	mov	a,#0x12
      006022 F0               [24]  822 	movx	@dptr,a
                                    823 ;	tmk_core/protocol/ch555/usb_ak820.c:118: D0_EP2RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      006023 A3               [24]  824 	inc	dptr
      006024 F0               [24]  825 	movx	@dptr,a
                                    826 ;	tmk_core/protocol/ch555/usb_ak820.c:119: D0_EP3RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      006025 A3               [24]  827 	inc	dptr
      006026 F0               [24]  828 	movx	@dptr,a
                                    829 ;	tmk_core/protocol/ch555/usb_ak820.c:120: D0_EP1T_L = D0_EP2T_L = D0_EP3T_L = 0;
      006027 90 22 0B         [24]  830 	mov	dptr,#0x220b
      00602A E4               [12]  831 	clr	a
      00602B F0               [24]  832 	movx	@dptr,a
      00602C 15 82            [12]  833 	dec	dpl
      00602E F0               [24]  834 	movx	@dptr,a
      00602F 15 82            [12]  835 	dec	dpl
      006031 F0               [24]  836 	movx	@dptr,a
                                    837 ;	tmk_core/protocol/ch555/usb_ak820.c:121: for (i = 0; i < SNAPSHOT_SIZE; ++i) input_snapshot[i] = 0;
      006032 FF               [12]  838 	mov	r7,a
      006033                        839 00103$:
      006033 EF               [12]  840 	mov	a,r7
      006034 24 C0            [12]  841 	add	a, #_input_snapshot
      006036 F5 82            [12]  842 	mov	dpl,a
      006038 E4               [12]  843 	clr	a
      006039 34 07            [12]  844 	addc	a, #(_input_snapshot >> 8)
      00603B F5 83            [12]  845 	mov	dph,a
      00603D E4               [12]  846 	clr	a
      00603E F0               [24]  847 	movx	@dptr,a
      00603F 0F               [12]  848 	inc	r7
      006040 BF 34 00         [24]  849 	cjne	r7,#0x34,00139$
      006043                        850 00139$:
      006043 40 EE            [24]  851 	jc	00103$
                                    852 ;	tmk_core/protocol/ch555/usb_ak820.c:122: input_snapshot[SNAPSHOT_NKRO] = REPORT_ID_NKRO;
      006045 90 07 C8         [24]  853 	mov	dptr,#(_input_snapshot + 0x0008)
      006048 74 06            [12]  854 	mov	a,#0x06
      00604A F0               [24]  855 	movx	@dptr,a
                                    856 ;	tmk_core/protocol/ch555/usb_ak820.c:124: input_snapshot[SNAPSHOT_MOUSE] = REPORT_ID_MOUSE;
      00604B 90 07 E8         [24]  857 	mov	dptr,#(_input_snapshot + 0x0028)
      00604E 74 02            [12]  858 	mov	a,#0x02
      006050 F0               [24]  859 	movx	@dptr,a
                                    860 ;	tmk_core/protocol/ch555/usb_ak820.c:126: input_snapshot[SNAPSHOT_SYSTEM] = REPORT_ID_SYSTEM;
      006051 90 07 EE         [24]  861 	mov	dptr,#(_input_snapshot + 0x002e)
      006054 04               [12]  862 	inc	a
      006055 F0               [24]  863 	movx	@dptr,a
                                    864 ;	tmk_core/protocol/ch555/usb_ak820.c:127: input_snapshot[SNAPSHOT_CONSUMER] = REPORT_ID_CONSUMER;
      006056 90 07 F1         [24]  865 	mov	dptr,#(_input_snapshot + 0x0031)
      006059 04               [12]  866 	inc	a
      00605A F0               [24]  867 	movx	@dptr,a
                                    868 ;	tmk_core/protocol/ch555/usb_ak820.c:128: for (i = 0; i < RAW_EPSIZE; ++i) pUSB_BUF_DEV0[UX_EP3_ADDR + i] = 0;
      00605B 7F 00            [12]  869 	mov	r7,#0x00
      00605D                        870 00105$:
      00605D 8F 06            [24]  871 	mov	ar6,r7
      00605F 74 C0            [12]  872 	mov	a,#0xc0
      006061 2E               [12]  873 	add	a, r6
      006062 F5 82            [12]  874 	mov	dpl,a
      006064 74 10            [12]  875 	mov	a,#0x10
      006066 24 00            [12]  876 	add	a, #0x00
      006068 F5 83            [12]  877 	mov	dph,a
      00606A E4               [12]  878 	clr	a
      00606B F0               [24]  879 	movx	@dptr,a
      00606C 0F               [12]  880 	inc	r7
      00606D BF 20 00         [24]  881 	cjne	r7,#0x20,00141$
      006070                        882 00141$:
      006070 40 EB            [24]  883 	jc	00105$
                                    884 ;	tmk_core/protocol/ch555/usb_ak820.c:129: raw_abort();
                                    885 ;	tmk_core/protocol/ch555/usb_ak820.c:130: }
      006072 02 5F BE         [24]  886 	ljmp	_raw_abort
                                    887 ;------------------------------------------------------------
                                    888 ;Allocation info for local variables in function 'control_stall'
                                    889 ;------------------------------------------------------------
                                    890 ;	tmk_core/protocol/ch555/usb_ak820.c:132: static void control_stall(void) {
                                    891 ;	-----------------------------------------
                                    892 ;	 function control_stall
                                    893 ;	-----------------------------------------
      006075                        894 _control_stall:
                                    895 ;	tmk_core/protocol/ch555/usb_ak820.c:133: if (raw_state == RAW_RX) raw_state = RAW_IDLE;
      006075 90 07 9D         [24]  896 	mov	dptr,#_raw_state
      006078 E0               [24]  897 	movx	a,@dptr
      006079 FF               [12]  898 	mov	r7,a
      00607A BF 01 05         [24]  899 	cjne	r7,#0x01,00102$
      00607D 90 07 9D         [24]  900 	mov	dptr,#_raw_state
      006080 E4               [12]  901 	clr	a
      006081 F0               [24]  902 	movx	@dptr,a
      006082                        903 00102$:
                                    904 ;	tmk_core/protocol/ch555/usb_ak820.c:134: output_kind = OUTPUT_NONE;
      006082 90 07 F5         [24]  905 	mov	dptr,#_output_kind
      006085 E4               [12]  906 	clr	a
      006086 F0               [24]  907 	movx	@dptr,a
                                    908 ;	tmk_core/protocol/ch555/usb_ak820.c:135: control_phase = CTRL_IDLE;
      006087 90 07 F4         [24]  909 	mov	dptr,#_control_phase
      00608A F0               [24]  910 	movx	@dptr,a
                                    911 ;	tmk_core/protocol/ch555/usb_ak820.c:136: D0SetupReqCode = 0xff;
      00608B 90 07 8F         [24]  912 	mov	dptr,#_D0SetupReqCode
      00608E 14               [12]  913 	dec	a
      00608F F0               [24]  914 	movx	@dptr,a
                                    915 ;	tmk_core/protocol/ch555/usb_ak820.c:138: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_STALL | UEP_T_RES_STALL;
      006090 90 22 00         [24]  916 	mov	dptr,#0x2200
      006093 74 CF            [12]  917 	mov	a,#0xcf
      006095 F0               [24]  918 	movx	@dptr,a
                                    919 ;	tmk_core/protocol/ch555/usb_ak820.c:139: }
      006096 22               [24]  920 	ret
                                    921 ;------------------------------------------------------------
                                    922 ;Allocation info for local variables in function 'control_next'
                                    923 ;------------------------------------------------------------
                                    924 ;i             Allocated with name '_control_next_i_10000_269'
                                    925 ;length        Allocated with name '_control_next_length_10000_269'
                                    926 ;------------------------------------------------------------
                                    927 ;	tmk_core/protocol/ch555/usb_ak820.c:141: static void control_next(void) {
                                    928 ;	-----------------------------------------
                                    929 ;	 function control_next
                                    930 ;	-----------------------------------------
      006097                        931 _control_next:
                                    932 ;	tmk_core/protocol/ch555/usb_ak820.c:143: uint8_t length = D0SetupLen > DEF_ENDP0_SIZE ? DEF_ENDP0_SIZE : D0SetupLen;
      006097 90 07 90         [24]  933 	mov	dptr,#_D0SetupLen
      00609A E0               [24]  934 	movx	a,@dptr
      00609B FE               [12]  935 	mov	r6,a
      00609C A3               [24]  936 	inc	dptr
      00609D E0               [24]  937 	movx	a,@dptr
      00609E FF               [12]  938 	mov	r7,a
      00609F C3               [12]  939 	clr	c
      0060A0 74 40            [12]  940 	mov	a,#0x40
      0060A2 9E               [12]  941 	subb	a,r6
      0060A3 E4               [12]  942 	clr	a
      0060A4 9F               [12]  943 	subb	a,r7
      0060A5 50 04            [24]  944 	jnc	00109$
                                    945 ;	free result
      0060A7 7E 40            [12]  946 	mov	r6,#0x40
      0060A9 80 07            [24]  947 	sjmp	00110$
      0060AB                        948 00109$:
      0060AB 90 07 90         [24]  949 	mov	dptr,#_D0SetupLen
      0060AE E0               [24]  950 	movx	a,@dptr
      0060AF FE               [12]  951 	mov	r6,a
      0060B0 A3               [24]  952 	inc	dptr
      0060B1 E0               [24]  953 	movx	a,@dptr
      0060B2                        954 00110$:
                                    955 ;	tmk_core/protocol/ch555/usb_ak820.c:144: for (i = 0; i < length; ++i) pD0_EP0_BUF[i] = *control_pointer++;
      0060B2 7F 00            [12]  956 	mov	r7,#0x00
      0060B4                        957 00105$:
      0060B4 C3               [12]  958 	clr	c
      0060B5 EF               [12]  959 	mov	a,r7
      0060B6 9E               [12]  960 	subb	a,r6
      0060B7 50 2A            [24]  961 	jnc	00101$
      0060B9 8F 04            [24]  962 	mov	ar4,r7
      0060BB 74 10            [12]  963 	mov	a,#0x10
      0060BD 24 00            [12]  964 	add	a, #0x00
      0060BF FD               [12]  965 	mov	r5,a
      0060C0 90 07 F8         [24]  966 	mov	dptr,#_control_pointer
      0060C3 E0               [24]  967 	movx	a,@dptr
      0060C4 FA               [12]  968 	mov	r2,a
      0060C5 A3               [24]  969 	inc	dptr
      0060C6 E0               [24]  970 	movx	a,@dptr
      0060C7 FB               [12]  971 	mov	r3,a
      0060C8 8A 82            [24]  972 	mov	dpl,r2
      0060CA 8B 83            [24]  973 	mov	dph,r3
      0060CC E4               [12]  974 	clr	a
      0060CD 93               [24]  975 	movc	a,@a+dptr
      0060CE F9               [12]  976 	mov	r1,a
      0060CF 90 07 F8         [24]  977 	mov	dptr,#_control_pointer
      0060D2 74 01            [12]  978 	mov	a,#0x01
      0060D4 2A               [12]  979 	add	a, r2
      0060D5 F0               [24]  980 	movx	@dptr,a
      0060D6 E4               [12]  981 	clr	a
      0060D7 3B               [12]  982 	addc	a, r3
      0060D8 A3               [24]  983 	inc	dptr
      0060D9 F0               [24]  984 	movx	@dptr,a
      0060DA 8C 82            [24]  985 	mov	dpl,r4
      0060DC 8D 83            [24]  986 	mov	dph,r5
      0060DE E9               [12]  987 	mov	a,r1
      0060DF F0               [24]  988 	movx	@dptr,a
      0060E0 0F               [12]  989 	inc	r7
      0060E1 80 D1            [24]  990 	sjmp	00105$
      0060E3                        991 00101$:
                                    992 ;	tmk_core/protocol/ch555/usb_ak820.c:145: D0SetupLen -= length;
      0060E3 8E 05            [24]  993 	mov	ar5,r6
      0060E5 7F 00            [12]  994 	mov	r7,#0x00
      0060E7 90 07 90         [24]  995 	mov	dptr,#_D0SetupLen
      0060EA E0               [24]  996 	movx	a,@dptr
      0060EB FB               [12]  997 	mov	r3,a
      0060EC A3               [24]  998 	inc	dptr
      0060ED E0               [24]  999 	movx	a,@dptr
      0060EE FC               [12] 1000 	mov	r4,a
      0060EF EB               [12] 1001 	mov	a,r3
      0060F0 C3               [12] 1002 	clr	c
      0060F1 9D               [12] 1003 	subb	a,r5
      0060F2 FB               [12] 1004 	mov	r3,a
      0060F3 EC               [12] 1005 	mov	a,r4
      0060F4 9F               [12] 1006 	subb	a,r7
      0060F5 FC               [12] 1007 	mov	r4,a
      0060F6 90 07 90         [24] 1008 	mov	dptr,#_D0SetupLen
      0060F9 EB               [12] 1009 	mov	a,r3
      0060FA F0               [24] 1010 	movx	@dptr,a
      0060FB EC               [12] 1011 	mov	a,r4
      0060FC A3               [24] 1012 	inc	dptr
      0060FD F0               [24] 1013 	movx	@dptr,a
                                   1014 ;	tmk_core/protocol/ch555/usb_ak820.c:146: if (!length) control_zlp = 0;
      0060FE EE               [12] 1015 	mov	a,r6
      0060FF 70 05            [24] 1016 	jnz	00103$
      006101 90 07 F7         [24] 1017 	mov	dptr,#_control_zlp
      006104 E4               [12] 1018 	clr	a
      006105 F0               [24] 1019 	movx	@dptr,a
      006106                       1020 00103$:
                                   1021 ;	tmk_core/protocol/ch555/usb_ak820.c:147: D0_EP0T_L = length;
      006106 90 22 08         [24] 1022 	mov	dptr,#0x2208
      006109 EE               [12] 1023 	mov	a,r6
      00610A F0               [24] 1024 	movx	@dptr,a
                                   1025 ;	tmk_core/protocol/ch555/usb_ak820.c:148: D0_EP0RES = (D0_EP0RES & (bUEP_T_TOG | bUEP_R_TOG)) | UEP_T_RES_ACK | UEP_R_RES_ACK;
      00610B 90 22 00         [24] 1026 	mov	dptr,#0x2200
      00610E E0               [24] 1027 	movx	a,@dptr
      00610F 54 C0            [12] 1028 	anl	a,#0xc0
      006111 F0               [24] 1029 	movx	@dptr,a
                                   1030 ;	tmk_core/protocol/ch555/usb_ak820.c:149: }
      006112 22               [24] 1031 	ret
                                   1032 ;------------------------------------------------------------
                                   1033 ;Allocation info for local variables in function 'descriptor_select'
                                   1034 ;------------------------------------------------------------
                                   1035 ;index         Allocated with name '_descriptor_select_PARM_2'
                                   1036 ;interface     Allocated with name '_descriptor_select_PARM_3'
                                   1037 ;type          Allocated with name '_descriptor_select_type_10000_272'
                                   1038 ;hid           Allocated with name '_descriptor_select_hid_30000_285'
                                   1039 ;------------------------------------------------------------
                                   1040 ;	tmk_core/protocol/ch555/usb_ak820.c:166: static uint16_t descriptor_select(uint8_t type, uint8_t index, uint16_t interface) {
                                   1041 ;	-----------------------------------------
                                   1042 ;	 function descriptor_select
                                   1043 ;	-----------------------------------------
      006113                       1044 _descriptor_select:
      006113 E5 82            [12] 1045 	mov	a,dpl
      006115 90 07 FD         [24] 1046 	mov	dptr,#_descriptor_select_type_10000_272
      006118 F0               [24] 1047 	movx	@dptr,a
                                   1048 ;	tmk_core/protocol/ch555/usb_ak820.c:167: if (type == USB_DESCR_TYP_DEVICE && !index && !interface) {
      006119 E0               [24] 1049 	movx	a,@dptr
      00611A FF               [12] 1050 	mov	r7,a
      00611B BF 01 20         [24] 1051 	cjne	r7,#0x01,00102$
      00611E 90 07 FA         [24] 1052 	mov	dptr,#_descriptor_select_PARM_2
      006121 E0               [24] 1053 	movx	a,@dptr
      006122 70 1A            [24] 1054 	jnz	00102$
      006124 90 07 FB         [24] 1055 	mov	dptr,#_descriptor_select_PARM_3
      006127 E0               [24] 1056 	movx	a,@dptr
      006128 F5 F0            [12] 1057 	mov	b,a
      00612A A3               [24] 1058 	inc	dptr
      00612B E0               [24] 1059 	movx	a,@dptr
      00612C 45 F0            [12] 1060 	orl	a,b
      00612E 70 0E            [24] 1061 	jnz	00102$
                                   1062 ;	tmk_core/protocol/ch555/usb_ak820.c:168: control_pointer = (const uint8_t __code *)&DeviceDescriptor;
      006130 90 07 F8         [24] 1063 	mov	dptr,#_control_pointer
      006133 74 39            [12] 1064 	mov	a,#_DeviceDescriptor
      006135 F0               [24] 1065 	movx	@dptr,a
      006136 74 C5            [12] 1066 	mov	a,#(_DeviceDescriptor >> 8)
      006138 A3               [24] 1067 	inc	dptr
      006139 F0               [24] 1068 	movx	@dptr,a
                                   1069 ;	tmk_core/protocol/ch555/usb_ak820.c:169: return sizeof(DeviceDescriptor);
      00613A 90 00 12         [24] 1070 	mov	dptr,#0x0012
      00613D 22               [24] 1071 	ret
      00613E                       1072 00102$:
                                   1073 ;	tmk_core/protocol/ch555/usb_ak820.c:171: if (type == USB_DESCR_TYP_CONFIG && !index && !interface) {
      00613E 90 07 FD         [24] 1074 	mov	dptr,#_descriptor_select_type_10000_272
      006141 E0               [24] 1075 	movx	a,@dptr
      006142 FF               [12] 1076 	mov	r7,a
      006143 BF 02 20         [24] 1077 	cjne	r7,#0x02,00106$
      006146 90 07 FA         [24] 1078 	mov	dptr,#_descriptor_select_PARM_2
      006149 E0               [24] 1079 	movx	a,@dptr
      00614A 70 1A            [24] 1080 	jnz	00106$
      00614C 90 07 FB         [24] 1081 	mov	dptr,#_descriptor_select_PARM_3
      00614F E0               [24] 1082 	movx	a,@dptr
      006150 F5 F0            [12] 1083 	mov	b,a
      006152 A3               [24] 1084 	inc	dptr
      006153 E0               [24] 1085 	movx	a,@dptr
      006154 45 F0            [12] 1086 	orl	a,b
      006156 70 0E            [24] 1087 	jnz	00106$
                                   1088 ;	tmk_core/protocol/ch555/usb_ak820.c:172: control_pointer = (const uint8_t __code *)&ConfigurationDescriptor;
      006158 90 07 F8         [24] 1089 	mov	dptr,#_control_pointer
      00615B 74 4B            [12] 1090 	mov	a,#_ConfigurationDescriptor
      00615D F0               [24] 1091 	movx	@dptr,a
      00615E 74 C5            [12] 1092 	mov	a,#(_ConfigurationDescriptor >> 8)
      006160 A3               [24] 1093 	inc	dptr
      006161 F0               [24] 1094 	movx	@dptr,a
                                   1095 ;	tmk_core/protocol/ch555/usb_ak820.c:173: return sizeof(ConfigurationDescriptor);
      006162 90 00 54         [24] 1096 	mov	dptr,#0x0054
      006165 22               [24] 1097 	ret
      006166                       1098 00106$:
                                   1099 ;	tmk_core/protocol/ch555/usb_ak820.c:175: if (type == USB_DESCR_TYP_STRING) {
      006166 90 07 FD         [24] 1100 	mov	dptr,#_descriptor_select_type_10000_272
      006169 E0               [24] 1101 	movx	a,@dptr
      00616A FF               [12] 1102 	mov	r7,a
      00616B BF 03 02         [24] 1103 	cjne	r7,#0x03,00238$
      00616E 80 03            [24] 1104 	sjmp	00239$
      006170                       1105 00238$:
      006170 02 62 0A         [24] 1106 	ljmp	00119$
      006173                       1107 00239$:
                                   1108 ;	tmk_core/protocol/ch555/usb_ak820.c:176: if (interface != 0 && interface != 0x0409) return 0;
      006173 90 07 FB         [24] 1109 	mov	dptr,#_descriptor_select_PARM_3
      006176 E0               [24] 1110 	movx	a,@dptr
      006177 FD               [12] 1111 	mov	r5,a
      006178 A3               [24] 1112 	inc	dptr
      006179 E0               [24] 1113 	movx	a,@dptr
      00617A FE               [12] 1114 	mov	r6,a
      00617B 90 07 FB         [24] 1115 	mov	dptr,#_descriptor_select_PARM_3
      00617E E0               [24] 1116 	movx	a,@dptr
      00617F F5 F0            [12] 1117 	mov	b,a
      006181 A3               [24] 1118 	inc	dptr
      006182 E0               [24] 1119 	movx	a,@dptr
      006183 45 F0            [12] 1120 	orl	a,b
      006185 60 0C            [24] 1121 	jz	00110$
      006187 BD 09 05         [24] 1122 	cjne	r5,#0x09,00241$
      00618A BE 04 02         [24] 1123 	cjne	r6,#0x04,00241$
      00618D 80 04            [24] 1124 	sjmp	00110$
      00618F                       1125 00241$:
      00618F 90 00 00         [24] 1126 	mov	dptr,#0x0000
      006192 22               [24] 1127 	ret
      006193                       1128 00110$:
                                   1129 ;	tmk_core/protocol/ch555/usb_ak820.c:177: switch (index) {
      006193 90 07 FA         [24] 1130 	mov	dptr,#_descriptor_select_PARM_2
      006196 E0               [24] 1131 	movx	a,@dptr
      006197 FE               [12] 1132 	mov  r6,a
      006198 24 FC            [12] 1133 	add	a,#0xff - 0x03
      00619A 40 6A            [24] 1134 	jc	00116$
                                   1135 ;	free result
      00619C EE               [12] 1136 	mov	a,r6
      00619D 2E               [12] 1137 	add	a,r6
                                   1138 ;	tmk_core/protocol/ch555/usb_ak820.c:178: case 0: control_pointer = (const uint8_t __code *)&LanguageString; return LanguageString.Header.Size;
      00619E 90 61 A2         [24] 1139 	mov	dptr,#00243$
      0061A1 73               [24] 1140 	jmp	@a+dptr
      0061A2                       1141 00243$:
      0061A2 80 06            [24] 1142 	sjmp	00112$
      0061A4 80 1B            [24] 1143 	sjmp	00113$
      0061A6 80 30            [24] 1144 	sjmp	00114$
      0061A8 80 45            [24] 1145 	sjmp	00115$
      0061AA                       1146 00112$:
      0061AA 90 07 F8         [24] 1147 	mov	dptr,#_control_pointer
      0061AD 74 9F            [12] 1148 	mov	a,#_LanguageString
      0061AF F0               [24] 1149 	movx	@dptr,a
      0061B0 74 C5            [12] 1150 	mov	a,#(_LanguageString >> 8)
      0061B2 A3               [24] 1151 	inc	dptr
      0061B3 F0               [24] 1152 	movx	@dptr,a
      0061B4 90 C5 9F         [24] 1153 	mov	dptr,#_LanguageString
      0061B7 E4               [12] 1154 	clr	a
      0061B8 93               [24] 1155 	movc	a,@a+dptr
      0061B9 FE               [12] 1156 	mov	r6,a
      0061BA 7D 00            [12] 1157 	mov	r5,#0x00
      0061BC 8E 82            [24] 1158 	mov	dpl, r6
      0061BE 8D 83            [24] 1159 	mov	dph, r5
      0061C0 22               [24] 1160 	ret
                                   1161 ;	tmk_core/protocol/ch555/usb_ak820.c:179: case 1: control_pointer = (const uint8_t __code *)&ManufacturerString; return ManufacturerString.Header.Size;
      0061C1                       1162 00113$:
      0061C1 90 07 F8         [24] 1163 	mov	dptr,#_control_pointer
      0061C4 74 A3            [12] 1164 	mov	a,#_ManufacturerString
      0061C6 F0               [24] 1165 	movx	@dptr,a
      0061C7 74 C5            [12] 1166 	mov	a,#(_ManufacturerString >> 8)
      0061C9 A3               [24] 1167 	inc	dptr
      0061CA F0               [24] 1168 	movx	@dptr,a
      0061CB 90 C5 A3         [24] 1169 	mov	dptr,#_ManufacturerString
      0061CE E4               [12] 1170 	clr	a
      0061CF 93               [24] 1171 	movc	a,@a+dptr
      0061D0 FE               [12] 1172 	mov	r6,a
      0061D1 7D 00            [12] 1173 	mov	r5,#0x00
      0061D3 8E 82            [24] 1174 	mov	dpl, r6
      0061D5 8D 83            [24] 1175 	mov	dph, r5
      0061D7 22               [24] 1176 	ret
                                   1177 ;	tmk_core/protocol/ch555/usb_ak820.c:180: case 2: control_pointer = (const uint8_t __code *)&ProductString; return ProductString.Header.Size;
      0061D8                       1178 00114$:
      0061D8 90 07 F8         [24] 1179 	mov	dptr,#_control_pointer
      0061DB 74 B1            [12] 1180 	mov	a,#_ProductString
      0061DD F0               [24] 1181 	movx	@dptr,a
      0061DE 74 C5            [12] 1182 	mov	a,#(_ProductString >> 8)
      0061E0 A3               [24] 1183 	inc	dptr
      0061E1 F0               [24] 1184 	movx	@dptr,a
      0061E2 90 C5 B1         [24] 1185 	mov	dptr,#_ProductString
      0061E5 E4               [12] 1186 	clr	a
      0061E6 93               [24] 1187 	movc	a,@a+dptr
      0061E7 FE               [12] 1188 	mov	r6,a
      0061E8 7D 00            [12] 1189 	mov	r5,#0x00
      0061EA 8E 82            [24] 1190 	mov	dpl, r6
      0061EC 8D 83            [24] 1191 	mov	dph, r5
      0061EE 22               [24] 1192 	ret
                                   1193 ;	tmk_core/protocol/ch555/usb_ak820.c:182: case 3: control_pointer = (const uint8_t __code *)&SerialNumberString; return SerialNumberString.Header.Size;
      0061EF                       1194 00115$:
      0061EF 90 07 F8         [24] 1195 	mov	dptr,#_control_pointer
      0061F2 74 E9            [12] 1196 	mov	a,#_SerialNumberString
      0061F4 F0               [24] 1197 	movx	@dptr,a
      0061F5 74 C5            [12] 1198 	mov	a,#(_SerialNumberString >> 8)
      0061F7 A3               [24] 1199 	inc	dptr
      0061F8 F0               [24] 1200 	movx	@dptr,a
      0061F9 90 C5 E9         [24] 1201 	mov	dptr,#_SerialNumberString
      0061FC E4               [12] 1202 	clr	a
      0061FD 93               [24] 1203 	movc	a,@a+dptr
      0061FE FE               [12] 1204 	mov	r6,a
      0061FF 7D 00            [12] 1205 	mov	r5,#0x00
      006201 8E 82            [24] 1206 	mov	dpl, r6
      006203 8D 83            [24] 1207 	mov	dph, r5
      006205 22               [24] 1208 	ret
                                   1209 ;	tmk_core/protocol/ch555/usb_ak820.c:184: default: return 0;
      006206                       1210 00116$:
      006206 90 00 00         [24] 1211 	mov	dptr,#0x0000
      006209 22               [24] 1212 	ret
                                   1213 ;	tmk_core/protocol/ch555/usb_ak820.c:185: }
      00620A                       1214 00119$:
                                   1215 ;	tmk_core/protocol/ch555/usb_ak820.c:187: if (index || interface >= TOTAL_INTERFACES) return 0;
      00620A 90 07 FA         [24] 1216 	mov	dptr,#_descriptor_select_PARM_2
      00620D E0               [24] 1217 	movx	a,@dptr
      00620E 70 11            [24] 1218 	jnz	00120$
      006210 90 07 FB         [24] 1219 	mov	dptr,#_descriptor_select_PARM_3
      006213 E0               [24] 1220 	movx	a,@dptr
      006214 FD               [12] 1221 	mov	r5,a
      006215 A3               [24] 1222 	inc	dptr
      006216 E0               [24] 1223 	movx	a,@dptr
      006217 FE               [12] 1224 	mov	r6,a
      006218 C3               [12] 1225 	clr	c
      006219 ED               [12] 1226 	mov	a,r5
      00621A 94 03            [12] 1227 	subb	a,#0x03
      00621C EE               [12] 1228 	mov	a,r6
      00621D 94 00            [12] 1229 	subb	a,#0x00
      00621F 40 04            [24] 1230 	jc	00121$
      006221                       1231 00120$:
      006221 90 00 00         [24] 1232 	mov	dptr,#0x0000
      006224 22               [24] 1233 	ret
      006225                       1234 00121$:
                                   1235 ;	tmk_core/protocol/ch555/usb_ak820.c:188: if (type == USB_DESCR_TYP_REPORT || type == USB_DESCR_TYP_HID) {
      006225 BF 22 02         [24] 1236 	cjne	r7,#0x22,00246$
      006228 80 03            [24] 1237 	sjmp	00127$
      00622A                       1238 00246$:
      00622A BF 21 5D         [24] 1239 	cjne	r7,#0x21,00128$
      00622D                       1240 00127$:
                                   1241 ;	tmk_core/protocol/ch555/usb_ak820.c:189: const USB_HID_Descriptor_HID_t __code *hid = interface_descriptors[(uint8_t)interface].hid;
      00622D ED               [12] 1242 	mov	a,r5
      00622E 75 F0 04         [24] 1243 	mov	b,#0x04
      006231 A4               [48] 1244 	mul	ab
      006232 24 71            [12] 1245 	add	a, #_interface_descriptors
      006234 FE               [12] 1246 	mov	r6,a
      006235 74 BE            [12] 1247 	mov	a,#(_interface_descriptors >> 8)
      006237 35 F0            [12] 1248 	addc	a, b
      006239 FF               [12] 1249 	mov	r7,a
      00623A 8E 82            [24] 1250 	mov	dpl,r6
      00623C 8F 83            [24] 1251 	mov	dph,r7
      00623E A3               [24] 1252 	inc	dptr
      00623F A3               [24] 1253 	inc	dptr
      006240 E4               [12] 1254 	clr	a
      006241 93               [24] 1255 	movc	a,@a+dptr
      006242 FC               [12] 1256 	mov	r4,a
      006243 A3               [24] 1257 	inc	dptr
      006244 E4               [12] 1258 	clr	a
      006245 93               [24] 1259 	movc	a,@a+dptr
                                   1260 ;	tmk_core/protocol/ch555/usb_ak820.c:190: if (!hid) return 0;
      006246 FD               [12] 1261 	mov	r5,a
      006247 4C               [12] 1262 	orl	a,r4
      006248 70 04            [24] 1263 	jnz	00124$
      00624A 90 00 00         [24] 1264 	mov	dptr,#0x0000
      00624D 22               [24] 1265 	ret
      00624E                       1266 00124$:
                                   1267 ;	tmk_core/protocol/ch555/usb_ak820.c:191: if (type == USB_DESCR_TYP_REPORT) {
      00624E 90 07 FD         [24] 1268 	mov	dptr,#_descriptor_select_type_10000_272
      006251 E0               [24] 1269 	movx	a,@dptr
      006252 FB               [12] 1270 	mov	r3,a
      006253 BB 22 28         [24] 1271 	cjne	r3,#0x22,00126$
                                   1272 ;	tmk_core/protocol/ch555/usb_ak820.c:192: control_pointer = interface_descriptors[(uint8_t)interface].report;
      006256 8E 82            [24] 1273 	mov	dpl,r6
      006258 8F 83            [24] 1274 	mov	dph,r7
      00625A E4               [12] 1275 	clr	a
      00625B 93               [24] 1276 	movc	a,@a+dptr
      00625C FE               [12] 1277 	mov	r6,a
      00625D A3               [24] 1278 	inc	dptr
      00625E E4               [12] 1279 	clr	a
      00625F 93               [24] 1280 	movc	a,@a+dptr
      006260 FF               [12] 1281 	mov	r7,a
      006261 90 07 F8         [24] 1282 	mov	dptr,#_control_pointer
      006264 EE               [12] 1283 	mov	a,r6
      006265 F0               [24] 1284 	movx	@dptr,a
      006266 EF               [12] 1285 	mov	a,r7
      006267 A3               [24] 1286 	inc	dptr
      006268 F0               [24] 1287 	movx	@dptr,a
                                   1288 ;	tmk_core/protocol/ch555/usb_ak820.c:193: return hid->HIDReportLength;
      006269 74 07            [12] 1289 	mov	a,#0x07
      00626B 2C               [12] 1290 	add	a, r4
      00626C F5 82            [12] 1291 	mov	dpl,a
      00626E E4               [12] 1292 	clr	a
      00626F 3D               [12] 1293 	addc	a, r5
      006270 F5 83            [12] 1294 	mov	dph,a
      006272 E4               [12] 1295 	clr	a
      006273 93               [24] 1296 	movc	a,@a+dptr
      006274 FE               [12] 1297 	mov	r6,a
      006275 A3               [24] 1298 	inc	dptr
      006276 E4               [12] 1299 	clr	a
      006277 93               [24] 1300 	movc	a,@a+dptr
      006278 FF               [12] 1301 	mov	r7,a
      006279 8E 82            [24] 1302 	mov	dpl, r6
      00627B 8F 83            [24] 1303 	mov	dph, r7
      00627D 22               [24] 1304 	ret
      00627E                       1305 00126$:
                                   1306 ;	tmk_core/protocol/ch555/usb_ak820.c:195: control_pointer = (const uint8_t __code *)hid;
      00627E 90 07 F8         [24] 1307 	mov	dptr,#_control_pointer
      006281 EC               [12] 1308 	mov	a,r4
      006282 F0               [24] 1309 	movx	@dptr,a
      006283 ED               [12] 1310 	mov	a,r5
      006284 A3               [24] 1311 	inc	dptr
      006285 F0               [24] 1312 	movx	@dptr,a
                                   1313 ;	tmk_core/protocol/ch555/usb_ak820.c:196: return 9;
      006286 90 00 09         [24] 1314 	mov	dptr,#0x0009
      006289 22               [24] 1315 	ret
      00628A                       1316 00128$:
                                   1317 ;	tmk_core/protocol/ch555/usb_ak820.c:198: return 0;
      00628A 90 00 00         [24] 1318 	mov	dptr,#0x0000
                                   1319 ;	tmk_core/protocol/ch555/usb_ak820.c:199: }
      00628D 22               [24] 1320 	ret
                                   1321 ;------------------------------------------------------------
                                   1322 ;Allocation info for local variables in function 'control_setup'
                                   1323 ;------------------------------------------------------------
                                   1324 ;sloc1         Allocated with name '_control_setup_sloc1_1_0'
                                   1325 ;sloc3         Allocated with name '_control_setup_sloc3_1_0'
                                   1326 ;sloc4         Allocated with name '_control_setup_sloc4_1_0'
                                   1327 ;type          Allocated with name '_control_setup_type_10000_290'
                                   1328 ;value         Allocated with name '_control_setup_value_10000_290'
                                   1329 ;index         Allocated with name '_control_setup_index_10000_290'
                                   1330 ;length        Allocated with name '_control_setup_length_10000_290'
                                   1331 ;endpoint      Allocated with name '_control_setup_endpoint_10000_290'
                                   1332 ;i             Allocated with name '_control_setup_i_10000_290'
                                   1333 ;offset        Allocated with name '_control_setup_offset_10000_290'
                                   1334 ;report_id     Allocated with name '_control_setup_report_id_10000_290'
                                   1335 ;------------------------------------------------------------
                                   1336 ;	tmk_core/protocol/ch555/usb_ak820.c:201: static void control_setup(void) {
                                   1337 ;	-----------------------------------------
                                   1338 ;	 function control_setup
                                   1339 ;	-----------------------------------------
      00628E                       1340 _control_setup:
                                   1341 ;	tmk_core/protocol/ch555/usb_ak820.c:202: uint8_t type = pD0_SETUP_REQ->bRequestType;
      00628E 90 10 00         [24] 1342 	mov	dptr,#0x1000
      006291 E0               [24] 1343 	movx	a,@dptr
      006292 FF               [12] 1344 	mov	r7,a
                                   1345 ;	tmk_core/protocol/ch555/usb_ak820.c:203: uint16_t value = pD0_SETUP_REQ->wValueL | ((uint16_t)pD0_SETUP_REQ->wValueH << 8);
      006293 A3               [24] 1346 	inc	dptr
      006294 A3               [24] 1347 	inc	dptr
      006295 E0               [24] 1348 	movx	a,@dptr
      006296 FE               [12] 1349 	mov	r6,a
      006297 A3               [24] 1350 	inc	dptr
      006298 E0               [24] 1351 	movx	a,@dptr
      006299 FC               [12] 1352 	mov	r4,a
      00629A 7D 00            [12] 1353 	mov	r5,#0x00
      00629C 8E 03            [24] 1354 	mov	ar3,r6
      00629E 7E 00            [12] 1355 	mov	r6,#0x00
      0062A0 ED               [12] 1356 	mov	a,r5
      0062A1 4B               [12] 1357 	orl	a,r3
      0062A2 FD               [12] 1358 	mov	r5,a
      0062A3 EC               [12] 1359 	mov	a,r4
      0062A4 4E               [12] 1360 	orl	a,r6
      0062A5 FE               [12] 1361 	mov	r6,a
                                   1362 ;	tmk_core/protocol/ch555/usb_ak820.c:204: uint16_t index = pD0_SETUP_REQ->wIndexL | ((uint16_t)pD0_SETUP_REQ->wIndexH << 8);
      0062A6 A3               [24] 1363 	inc	dptr
      0062A7 E0               [24] 1364 	movx	a,@dptr
      0062A8 FC               [12] 1365 	mov	r4,a
      0062A9 A3               [24] 1366 	inc	dptr
      0062AA E0               [24] 1367 	movx	a,@dptr
      0062AB FA               [12] 1368 	mov	r2,a
      0062AC 7B 00            [12] 1369 	mov	r3,#0x00
      0062AE 8C 01            [24] 1370 	mov	ar1,r4
      0062B0 7C 00            [12] 1371 	mov	r4,#0x00
      0062B2 EB               [12] 1372 	mov	a,r3
      0062B3 49               [12] 1373 	orl	a,r1
      0062B4 FB               [12] 1374 	mov	r3,a
      0062B5 EA               [12] 1375 	mov	a,r2
      0062B6 4C               [12] 1376 	orl	a,r4
      0062B7 FC               [12] 1377 	mov	r4,a
                                   1378 ;	tmk_core/protocol/ch555/usb_ak820.c:208: __bit valid_interface = index < TOTAL_INTERFACES;
      0062B8 C3               [12] 1379 	clr	c
      0062B9 EB               [12] 1380 	mov	a,r3
      0062BA 94 03            [12] 1381 	subb	a,#0x03
      0062BC EC               [12] 1382 	mov	a,r4
      0062BD 94 00            [12] 1383 	subb	a,#0x00
      0062BF 92 15            [24] 1384 	mov	_control_setup_valid_interface_10000_290,c
                                   1385 ;	tmk_core/protocol/ch555/usb_ak820.c:209: __bit zero_index = !index;
      0062C1 EB               [12] 1386 	mov	a,r3
      0062C2 4C               [12] 1387 	orl	a,r4
      0062C3 B4 01 00         [24] 1388 	cjne	a,#0x01,01201$
      0062C6                       1389 01201$:
      0062C6 92 16            [24] 1390 	mov	_control_setup_zero_index_10000_290,c
                                   1391 ;	tmk_core/protocol/ch555/usb_ak820.c:210: __bit zero_value = !value;
      0062C8 ED               [12] 1392 	mov	a,r5
      0062C9 4E               [12] 1393 	orl	a,r6
      0062CA B4 01 00         [24] 1394 	cjne	a,#0x01,01202$
      0062CD                       1395 01202$:
                                   1396 ;	assignBit
      0062CD 92 19            [24] 1397 	mov  _control_setup_sloc0_1_0,c
      0062CF 92 17            [24] 1398 	mov	_control_setup_zero_value_10000_290,c
                                   1399 ;	tmk_core/protocol/ch555/usb_ak820.c:214: uint8_t offset = 0;
      0062D1 90 08 00         [24] 1400 	mov	dptr,#_control_setup_offset_10000_290
      0062D4 E4               [12] 1401 	clr	a
      0062D5 F0               [24] 1402 	movx	@dptr,a
                                   1403 ;	tmk_core/protocol/ch555/usb_ak820.c:216: if (raw_state == RAW_RX) raw_state = RAW_IDLE; /* abort only unfinished OUT */
      0062D6 90 07 9D         [24] 1404 	mov	dptr,#_raw_state
      0062D9 E0               [24] 1405 	movx	a,@dptr
      0062DA FA               [12] 1406 	mov	r2,a
      0062DB BA 01 05         [24] 1407 	cjne	r2,#0x01,00102$
      0062DE 90 07 9D         [24] 1408 	mov	dptr,#_raw_state
      0062E1 E4               [12] 1409 	clr	a
      0062E2 F0               [24] 1410 	movx	@dptr,a
      0062E3                       1411 00102$:
                                   1412 ;	tmk_core/protocol/ch555/usb_ak820.c:217: output_kind = OUTPUT_NONE;
      0062E3 C0 07            [24] 1413 	push	ar7
      0062E5 90 07 F5         [24] 1414 	mov	dptr,#_output_kind
      0062E8 E4               [12] 1415 	clr	a
      0062E9 F0               [24] 1416 	movx	@dptr,a
                                   1417 ;	tmk_core/protocol/ch555/usb_ak820.c:218: control_phase = CTRL_IDLE;
      0062EA 90 07 F4         [24] 1418 	mov	dptr,#_control_phase
      0062ED F0               [24] 1419 	movx	@dptr,a
                                   1420 ;	tmk_core/protocol/ch555/usb_ak820.c:219: control_zlp = 0;
      0062EE 90 07 F7         [24] 1421 	mov	dptr,#_control_zlp
      0062F1 F0               [24] 1422 	movx	@dptr,a
                                   1423 ;	tmk_core/protocol/ch555/usb_ak820.c:220: D0SetupReqCode = pD0_SETUP_REQ->bRequest;
      0062F2 90 10 01         [24] 1424 	mov	dptr,#0x1001
      0062F5 E0               [24] 1425 	movx	a,@dptr
      0062F6 90 07 8F         [24] 1426 	mov	dptr,#_D0SetupReqCode
      0062F9 F0               [24] 1427 	movx	@dptr,a
                                   1428 ;	tmk_core/protocol/ch555/usb_ak820.c:221: D0SetupLen = pD0_SETUP_REQ->wLengthL | ((uint16_t)pD0_SETUP_REQ->wLengthH << 8);
      0062FA 90 10 06         [24] 1429 	mov	dptr,#0x1006
      0062FD E0               [24] 1430 	movx	a,@dptr
      0062FE FA               [12] 1431 	mov	r2,a
      0062FF A3               [24] 1432 	inc	dptr
      006300 E0               [24] 1433 	movx	a,@dptr
      006301 F9               [12] 1434 	mov	r1,a
      006302 78 00            [12] 1435 	mov	r0,#0x00
      006304 7F 00            [12] 1436 	mov	r7,#0x00
      006306 90 07 90         [24] 1437 	mov	dptr,#_D0SetupLen
      006309 E8               [12] 1438 	mov	a,r0
      00630A 4A               [12] 1439 	orl	a,r2
      00630B F0               [24] 1440 	movx	@dptr,a
      00630C E9               [12] 1441 	mov	a,r1
      00630D 4F               [12] 1442 	orl	a,r7
      00630E A3               [24] 1443 	inc	dptr
      00630F F0               [24] 1444 	movx	@dptr,a
                                   1445 ;	tmk_core/protocol/ch555/usb_ak820.c:222: zero_length = !D0SetupLen;
      006310 90 07 90         [24] 1446 	mov	dptr,#_D0SetupLen
      006313 E0               [24] 1447 	movx	a,@dptr
      006314 FA               [12] 1448 	mov	r2,a
      006315 A3               [24] 1449 	inc	dptr
      006316 E0               [24] 1450 	movx	a,@dptr
      006317 4A               [12] 1451 	orl	a,r2
      006318 B4 01 00         [24] 1452 	cjne	a,#0x01,01205$
      00631B                       1453 01205$:
      00631B 92 18            [24] 1454 	mov	_control_setup_zero_length_10000_290,c
                                   1455 ;	tmk_core/protocol/ch555/usb_ak820.c:223: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_ACK | UEP_T_RES_NAK;
      00631D 90 22 00         [24] 1456 	mov	dptr,#0x2200
      006320 74 C2            [12] 1457 	mov	a,#0xc2
      006322 F0               [24] 1458 	movx	@dptr,a
                                   1459 ;	tmk_core/protocol/ch555/usb_ak820.c:224: D0_EP0T_L = 0;
      006323 90 22 08         [24] 1460 	mov	dptr,#0x2208
      006326 E4               [12] 1461 	clr	a
      006327 F0               [24] 1462 	movx	@dptr,a
                                   1463 ;	tmk_core/protocol/ch555/usb_ak820.c:228: switch (D0SetupReqCode) {
      006328 90 07 8F         [24] 1464 	mov	dptr,#_D0SetupReqCode
      00632B E0               [24] 1465 	movx	a,@dptr
      00632C F5 16            [12] 1466 	mov	_control_setup_sloc1_1_0,a
      00632E C3               [12] 1467 	clr	c
      00632F 74 0B            [12] 1468 	mov	a,#0x0b
      006331 95 16            [12] 1469 	subb	a,_control_setup_sloc1_1_0
      006333 D0 07            [24] 1470 	pop	ar7
      006335 50 03            [24] 1471 	jnc	01206$
      006337 02 60 75         [24] 1472 	ljmp	_control_stall
      00633A                       1473 01206$:
                                   1474 ;	free result
      00633A E5 16            [12] 1475 	mov	a,_control_setup_sloc1_1_0
      00633C F5 F0            [12] 1476 	mov	b,a
      00633E 24 0B            [12] 1477 	add	a,#(01207$-3-.)
      006340 83               [24] 1478 	movc	a,@a+pc
      006341 F5 82            [12] 1479 	mov	dpl,a
      006343 E5 F0            [12] 1480 	mov	a,b
      006345 24 10            [12] 1481 	add	a,#(01208$-3-.)
      006347 83               [24] 1482 	movc	a,@a+pc
      006348 F5 83            [12] 1483 	mov	dph,a
      00634A E4               [12] 1484 	clr	a
      00634B 73               [24] 1485 	jmp	@a+dptr
      00634C                       1486 01207$:
      00634C F4                    1487 	.db	00188$
      00634D 9A                    1488 	.db	00205$
      00634E DD                    1489 	.db	00282$
      00634F 9A                    1490 	.db	00205$
      006350 21                    1491 	.db	00290$
      006351 1E                    1492 	.db	00116$
      006352 64                    1493 	.db	00103$
      006353 21                    1494 	.db	00290$
      006354 23                    1495 	.db	00150$
      006355 47                    1496 	.db	00123$
      006356 53                    1497 	.db	00157$
      006357 A6                    1498 	.db	00173$
      006358                       1499 01208$:
      006358 65                    1500 	.db	00188$>>8
      006359 66                    1501 	.db	00205$>>8
      00635A 69                    1502 	.db	00282$>>8
      00635B 66                    1503 	.db	00205$>>8
      00635C 6A                    1504 	.db	00290$>>8
      00635D 64                    1505 	.db	00116$>>8
      00635E 63                    1506 	.db	00103$>>8
      00635F 6A                    1507 	.db	00290$>>8
      006360 65                    1508 	.db	00150$>>8
      006361 64                    1509 	.db	00123$>>8
      006362 65                    1510 	.db	00157$>>8
      006363 65                    1511 	.db	00173$>>8
                                   1512 ;	tmk_core/protocol/ch555/usb_ak820.c:229: case USB_GET_DESCRIPTOR:
      006364                       1513 00103$:
                                   1514 ;	tmk_core/protocol/ch555/usb_ak820.c:230: if (type == 0x80 || type == 0x81) {
      006364 BF 80 02         [24] 1515 	cjne	r7,#0x80,01209$
      006367 80 08            [24] 1516 	sjmp	00112$
      006369                       1517 01209$:
      006369 BF 81 02         [24] 1518 	cjne	r7,#0x81,01210$
      00636C 80 03            [24] 1519 	sjmp	01211$
      00636E                       1520 01210$:
      00636E 02 60 75         [24] 1521 	ljmp	_control_stall
      006371                       1522 01211$:
      006371                       1523 00112$:
                                   1524 ;	tmk_core/protocol/ch555/usb_ak820.c:231: if (((value >> 8) == USB_DESCR_TYP_HID || (value >> 8) == USB_DESCR_TYP_REPORT) != (type == 0x81)) {
      006371 8E 01            [24] 1525 	mov	ar1,r6
      006373 B9 21 02         [24] 1526 	cjne	r1,#0x21,01212$
      006376 80 09            [24] 1527 	sjmp	00301$
      006378                       1528 01212$:
      006378 B9 22 02         [24] 1529 	cjne	r1,#0x22,01213$
      00637B 80 04            [24] 1530 	sjmp	00301$
      00637D                       1531 01213$:
                                   1532 ;	assignBit
      00637D C2 1A            [12] 1533 	clr	_control_setup_sloc2_1_0
      00637F 80 02            [24] 1534 	sjmp	00302$
      006381                       1535 00301$:
                                   1536 ;	assignBit
      006381 D2 1A            [12] 1537 	setb	_control_setup_sloc2_1_0
      006383                       1538 00302$:
      006383 E4               [12] 1539 	clr	a
      006384 BF 81 01         [24] 1540 	cjne	r7,#0x81,01214$
      006387 04               [12] 1541 	inc	a
      006388                       1542 01214$:
      006388 FA               [12] 1543 	mov	r2,a
      006389 A2 1A            [12] 1544 	mov	c,_control_setup_sloc2_1_0
      00638B E4               [12] 1545 	clr	a
      00638C 33               [12] 1546 	rlc	a
      00638D B5 02 02         [24] 1547 	cjne	a,ar2,01216$
      006390 80 03            [24] 1548 	sjmp	00105$
      006392                       1549 01216$:
                                   1550 ;	tmk_core/protocol/ch555/usb_ak820.c:232: control_stall(); return;
      006392 02 60 75         [24] 1551 	ljmp	_control_stall
      006395                       1552 00105$:
                                   1553 ;	tmk_core/protocol/ch555/usb_ak820.c:234: length = descriptor_select(value >> 8, value, index);
      006395 8E 02            [24] 1554 	mov	ar2,r6
      006397 90 07 FA         [24] 1555 	mov	dptr,#_descriptor_select_PARM_2
      00639A ED               [12] 1556 	mov	a,r5
      00639B F0               [24] 1557 	movx	@dptr,a
      00639C 90 07 FB         [24] 1558 	mov	dptr,#_descriptor_select_PARM_3
      00639F EB               [12] 1559 	mov	a,r3
      0063A0 F0               [24] 1560 	movx	@dptr,a
      0063A1 EC               [12] 1561 	mov	a,r4
      0063A2 A3               [24] 1562 	inc	dptr
      0063A3 F0               [24] 1563 	movx	@dptr,a
      0063A4 8A 82            [24] 1564 	mov	dpl, r2
      0063A6 12 61 13         [24] 1565 	lcall	_descriptor_select
      0063A9 85 82 17         [24] 1566 	mov	_control_setup_sloc3_1_0,dpl
      0063AC 85 83 18         [24] 1567 	mov	(_control_setup_sloc3_1_0 + 1),dph
                                   1568 ;	tmk_core/protocol/ch555/usb_ak820.c:235: if (!length) { control_stall(); return; }
      0063AF E5 17            [12] 1569 	mov	a,_control_setup_sloc3_1_0
      0063B1 45 18            [12] 1570 	orl	a,(_control_setup_sloc3_1_0 + 1)
      0063B3 70 03            [24] 1571 	jnz	00107$
      0063B5 02 60 75         [24] 1572 	ljmp	_control_stall
      0063B8                       1573 00107$:
                                   1574 ;	tmk_core/protocol/ch555/usb_ak820.c:236: control_zlp = length < D0SetupLen && !(length & (DEF_ENDP0_SIZE - 1));
      0063B8 90 07 90         [24] 1575 	mov	dptr,#_D0SetupLen
      0063BB E0               [24] 1576 	movx	a,@dptr
      0063BC F8               [12] 1577 	mov	r0,a
      0063BD A3               [24] 1578 	inc	dptr
      0063BE E0               [24] 1579 	movx	a,@dptr
      0063BF FA               [12] 1580 	mov	r2,a
      0063C0 C3               [12] 1581 	clr	c
      0063C1 E5 17            [12] 1582 	mov	a,_control_setup_sloc3_1_0
      0063C3 98               [12] 1583 	subb	a,r0
      0063C4 E5 18            [12] 1584 	mov	a,(_control_setup_sloc3_1_0 + 1)
      0063C6 9A               [12] 1585 	subb	a,r2
      0063C7 50 06            [24] 1586 	jnc	00303$
      0063C9 E5 17            [12] 1587 	mov	a,_control_setup_sloc3_1_0
      0063CB 54 3F            [12] 1588 	anl	a,#0x3f
      0063CD 60 04            [24] 1589 	jz	00304$
      0063CF                       1590 00303$:
                                   1591 ;	assignBit
      0063CF C2 1A            [12] 1592 	clr	_control_setup_sloc2_1_0
      0063D1 80 02            [24] 1593 	sjmp	00305$
      0063D3                       1594 00304$:
                                   1595 ;	assignBit
      0063D3 D2 1A            [12] 1596 	setb	_control_setup_sloc2_1_0
      0063D5                       1597 00305$:
      0063D5 90 07 F7         [24] 1598 	mov	dptr,#_control_zlp
      0063D8 A2 1A            [12] 1599 	mov	c,_control_setup_sloc2_1_0
      0063DA E4               [12] 1600 	clr	a
      0063DB 33               [12] 1601 	rlc	a
      0063DC F0               [24] 1602 	movx	@dptr,a
                                   1603 ;	tmk_core/protocol/ch555/usb_ak820.c:237: if (D0SetupLen > length) D0SetupLen = length;
      0063DD 90 07 90         [24] 1604 	mov	dptr,#_D0SetupLen
      0063E0 E0               [24] 1605 	movx	a,@dptr
      0063E1 F9               [12] 1606 	mov	r1,a
      0063E2 A3               [24] 1607 	inc	dptr
      0063E3 E0               [24] 1608 	movx	a,@dptr
      0063E4 FA               [12] 1609 	mov	r2,a
      0063E5 C3               [12] 1610 	clr	c
      0063E6 E5 17            [12] 1611 	mov	a,_control_setup_sloc3_1_0
      0063E8 99               [12] 1612 	subb	a,r1
      0063E9 E5 18            [12] 1613 	mov	a,(_control_setup_sloc3_1_0 + 1)
      0063EB 9A               [12] 1614 	subb	a,r2
      0063EC 50 0A            [24] 1615 	jnc	00109$
                                   1616 ;	free result
      0063EE 90 07 90         [24] 1617 	mov	dptr,#_D0SetupLen
      0063F1 E5 17            [12] 1618 	mov	a,_control_setup_sloc3_1_0
      0063F3 F0               [24] 1619 	movx	@dptr,a
      0063F4 E5 18            [12] 1620 	mov	a,(_control_setup_sloc3_1_0 + 1)
      0063F6 A3               [24] 1621 	inc	dptr
      0063F7 F0               [24] 1622 	movx	@dptr,a
      0063F8                       1623 00109$:
                                   1624 ;	tmk_core/protocol/ch555/usb_ak820.c:238: control_phase = D0SetupLen ? CTRL_DATA_IN : CTRL_STATUS_OUT;
      0063F8 90 07 90         [24] 1625 	mov	dptr,#_D0SetupLen
      0063FB E0               [24] 1626 	movx	a,@dptr
      0063FC F9               [12] 1627 	mov	r1,a
      0063FD A3               [24] 1628 	inc	dptr
      0063FE E0               [24] 1629 	movx	a,@dptr
      0063FF 49               [12] 1630 	orl	a,r1
      006400 60 04            [24] 1631 	jz	00306$
      006402 7A 01            [12] 1632 	mov	r2,#0x01
      006404 80 02            [24] 1633 	sjmp	00307$
      006406                       1634 00306$:
      006406 7A 02            [12] 1635 	mov	r2,#0x02
      006408                       1636 00307$:
      006408 90 07 F4         [24] 1637 	mov	dptr,#_control_phase
      00640B EA               [12] 1638 	mov	a,r2
      00640C F0               [24] 1639 	movx	@dptr,a
                                   1640 ;	tmk_core/protocol/ch555/usb_ak820.c:239: if (D0SetupLen) control_next();
      00640D 90 07 90         [24] 1641 	mov	dptr,#_D0SetupLen
      006410 E0               [24] 1642 	movx	a,@dptr
      006411 F9               [12] 1643 	mov	r1,a
      006412 A3               [24] 1644 	inc	dptr
      006413 E0               [24] 1645 	movx	a,@dptr
      006414 49               [12] 1646 	orl	a,r1
      006415 60 03            [24] 1647 	jz	00111$
                                   1648 ;	tmk_core/protocol/ch555/usb_ak820.c:240: return;
      006417 02 60 97         [24] 1649 	ljmp	_control_next
      00641A                       1650 00111$:
      00641A 22               [24] 1651 	ret
                                   1652 ;	tmk_core/protocol/ch555/usb_ak820.c:241: } else { control_stall(); return; }
      00641B 02 60 75         [24] 1653 	ljmp	_control_stall
                                   1654 ;	tmk_core/protocol/ch555/usb_ak820.c:242: case USB_SET_ADDRESS:
      00641E                       1655 00116$:
                                   1656 ;	tmk_core/protocol/ch555/usb_ak820.c:243: if (type == 0x00 && zero_index && zero_length && value <= 127) {
      00641E EF               [12] 1657 	mov	a,r7
      00641F 70 23            [24] 1658 	jnz	00118$
      006421 30 16 20         [24] 1659 	jnb	_control_setup_zero_index_10000_290,00118$
      006424 30 18 1D         [24] 1660 	jnb	_control_setup_zero_length_10000_290,00118$
      006427 8D 01            [24] 1661 	mov	ar1,r5
      006429 8E 02            [24] 1662 	mov	ar2,r6
      00642B C3               [12] 1663 	clr	c
      00642C 74 7F            [12] 1664 	mov	a,#0x7f
      00642E 99               [12] 1665 	subb	a,r1
      00642F E4               [12] 1666 	clr	a
      006430 9A               [12] 1667 	subb	a,r2
      006431 40 11            [24] 1668 	jc	00118$
                                   1669 ;	free result
                                   1670 ;	tmk_core/protocol/ch555/usb_ak820.c:244: D0SetupLen = value; /* applied after status-IN ACK */
      006433 90 07 90         [24] 1671 	mov	dptr,#_D0SetupLen
      006436 ED               [12] 1672 	mov	a,r5
      006437 F0               [24] 1673 	movx	@dptr,a
      006438 EE               [12] 1674 	mov	a,r6
      006439 A3               [24] 1675 	inc	dptr
      00643A F0               [24] 1676 	movx	@dptr,a
                                   1677 ;	tmk_core/protocol/ch555/usb_ak820.c:245: control_phase = CTRL_STATUS_IN;
      00643B 90 07 F4         [24] 1678 	mov	dptr,#_control_phase
      00643E 74 03            [12] 1679 	mov	a,#0x03
      006440 F0               [24] 1680 	movx	@dptr,a
      006441 02 6A 24         [24] 1681 	ljmp	00291$
      006444                       1682 00118$:
                                   1683 ;	tmk_core/protocol/ch555/usb_ak820.c:246: } else { control_stall(); return; }
      006444 02 60 75         [24] 1684 	ljmp	_control_stall
                                   1685 ;	tmk_core/protocol/ch555/usb_ak820.c:248: case USB_SET_CONFIGURATION: /* HID_SET_REPORT has the same request byte. */
      006447                       1686 00123$:
                                   1687 ;	tmk_core/protocol/ch555/usb_ak820.c:249: if (type == 0x00 && zero_index && zero_length && value <= 1) {
      006447 EF               [12] 1688 	mov	a,r7
      006448 70 3C            [24] 1689 	jnz	00145$
      00644A 30 16 39         [24] 1690 	jnb	_control_setup_zero_index_10000_290,00145$
      00644D 30 18 36         [24] 1691 	jnb	_control_setup_zero_length_10000_290,00145$
      006450 8D 01            [24] 1692 	mov	ar1,r5
      006452 8E 02            [24] 1693 	mov	ar2,r6
      006454 C3               [12] 1694 	clr	c
      006455 74 01            [12] 1695 	mov	a,#0x01
      006457 99               [12] 1696 	subb	a,r1
      006458 E4               [12] 1697 	clr	a
      006459 9A               [12] 1698 	subb	a,r2
      00645A 40 2A            [24] 1699 	jc	00145$
                                   1700 ;	free result
                                   1701 ;	tmk_core/protocol/ch555/usb_ak820.c:250: endpoints_reset();
      00645C C0 06            [24] 1702 	push	ar6
      00645E C0 05            [24] 1703 	push	ar5
      006460 12 60 14         [24] 1704 	lcall	_endpoints_reset
      006463 D0 05            [24] 1705 	pop	ar5
      006465 D0 06            [24] 1706 	pop	ar6
                                   1707 ;	tmk_core/protocol/ch555/usb_ak820.c:251: D0UsbConfig = value;
      006467 90 07 95         [24] 1708 	mov	dptr,#_D0UsbConfig
      00646A ED               [12] 1709 	mov	a,r5
      00646B F0               [24] 1710 	movx	@dptr,a
                                   1711 ;	tmk_core/protocol/ch555/usb_ak820.c:252: USB_EnumStatus = value != 0;
      00646C A2 19            [12] 1712 	mov	c,_control_setup_sloc0_1_0
      00646E B3               [12] 1713 	cpl	c
      00646F 92 1A            [24] 1714 	mov	_control_setup_sloc2_1_0,c
      006471 90 07 96         [24] 1715 	mov	dptr,#_USB_EnumStatus
      006474 E4               [12] 1716 	clr	a
      006475 33               [12] 1717 	rlc	a
      006476 F0               [24] 1718 	movx	@dptr,a
                                   1719 ;	tmk_core/protocol/ch555/usb_ak820.c:253: keyboard_reset = 1;
      006477 90 07 BF         [24] 1720 	mov	dptr,#_keyboard_reset
      00647A 74 01            [12] 1721 	mov	a,#0x01
      00647C F0               [24] 1722 	movx	@dptr,a
                                   1723 ;	tmk_core/protocol/ch555/usb_ak820.c:254: control_phase = CTRL_STATUS_IN;
      00647D 90 07 F4         [24] 1724 	mov	dptr,#_control_phase
      006480 74 03            [12] 1725 	mov	a,#0x03
      006482 F0               [24] 1726 	movx	@dptr,a
      006483 02 6A 24         [24] 1727 	ljmp	00291$
      006486                       1728 00145$:
                                   1729 ;	tmk_core/protocol/ch555/usb_ak820.c:255: } else if (type == 0x21 && D0UsbConfig) {
      006486 BF 21 02         [24] 1730 	cjne	r7,#0x21,01231$
      006489 80 03            [24] 1731 	sjmp	01232$
      00648B                       1732 01231$:
      00648B 02 60 75         [24] 1733 	ljmp	_control_stall
      00648E                       1734 01232$:
      00648E 90 07 95         [24] 1735 	mov	dptr,#_D0UsbConfig
      006491 E0               [24] 1736 	movx	a,@dptr
      006492 70 03            [24] 1737 	jnz	01233$
      006494 02 60 75         [24] 1738 	ljmp	_control_stall
      006497                       1739 01233$:
                                   1740 ;	tmk_core/protocol/ch555/usb_ak820.c:256: if (index == RAW_INTERFACE && value == 0x0200 && D0SetupLen == RAW_EPSIZE && raw_state == RAW_IDLE) {
      006497 BB 01 2D         [24] 1741 	cjne	r3,#0x01,00135$
      00649A BC 00 2A         [24] 1742 	cjne	r4,#0x00,00135$
      00649D 8D 01            [24] 1743 	mov	ar1,r5
      00649F 8E 02            [24] 1744 	mov	ar2,r6
      0064A1 B9 00 23         [24] 1745 	cjne	r1,#0x00,00135$
      0064A4 BA 02 20         [24] 1746 	cjne	r2,#0x02,00135$
      0064A7 90 07 90         [24] 1747 	mov	dptr,#_D0SetupLen
      0064AA E0               [24] 1748 	movx	a,@dptr
      0064AB F9               [12] 1749 	mov	r1,a
      0064AC A3               [24] 1750 	inc	dptr
      0064AD E0               [24] 1751 	movx	a,@dptr
      0064AE FA               [12] 1752 	mov	r2,a
      0064AF B9 20 15         [24] 1753 	cjne	r1,#0x20,00135$
      0064B2 BA 00 12         [24] 1754 	cjne	r2,#0x00,00135$
      0064B5 90 07 9D         [24] 1755 	mov	dptr,#_raw_state
      0064B8 E0               [24] 1756 	movx	a,@dptr
      0064B9 70 0C            [24] 1757 	jnz	00135$
                                   1758 ;	tmk_core/protocol/ch555/usb_ak820.c:257: raw_state = RAW_RX;
      0064BB 90 07 9D         [24] 1759 	mov	dptr,#_raw_state
      0064BE 74 01            [12] 1760 	mov	a,#0x01
      0064C0 F0               [24] 1761 	movx	@dptr,a
                                   1762 ;	tmk_core/protocol/ch555/usb_ak820.c:258: output_kind = OUTPUT_RAW;
      0064C1 90 07 F5         [24] 1763 	mov	dptr,#_output_kind
      0064C4 F0               [24] 1764 	movx	@dptr,a
      0064C5 80 52            [24] 1765 	sjmp	00136$
      0064C7                       1766 00135$:
                                   1767 ;	tmk_core/protocol/ch555/usb_ak820.c:259: } else if (index == KEYBOARD_INTERFACE && value == 0x0200 && D0SetupLen == 1) {
      0064C7 EB               [12] 1768 	mov	a,r3
      0064C8 4C               [12] 1769 	orl	a,r4
      0064C9 70 20            [24] 1770 	jnz	00130$
      0064CB 8D 01            [24] 1771 	mov	ar1,r5
      0064CD 8E 02            [24] 1772 	mov	ar2,r6
      0064CF B9 00 19         [24] 1773 	cjne	r1,#0x00,00130$
      0064D2 BA 02 16         [24] 1774 	cjne	r2,#0x02,00130$
      0064D5 90 07 90         [24] 1775 	mov	dptr,#_D0SetupLen
      0064D8 E0               [24] 1776 	movx	a,@dptr
      0064D9 F9               [12] 1777 	mov	r1,a
      0064DA A3               [24] 1778 	inc	dptr
      0064DB E0               [24] 1779 	movx	a,@dptr
      0064DC FA               [12] 1780 	mov	r2,a
      0064DD B9 01 0B         [24] 1781 	cjne	r1,#0x01,00130$
      0064E0 BA 00 08         [24] 1782 	cjne	r2,#0x00,00130$
                                   1783 ;	tmk_core/protocol/ch555/usb_ak820.c:260: output_kind = OUTPUT_LED;
      0064E3 90 07 F5         [24] 1784 	mov	dptr,#_output_kind
      0064E6 74 02            [12] 1785 	mov	a,#0x02
      0064E8 F0               [24] 1786 	movx	@dptr,a
      0064E9 80 2E            [24] 1787 	sjmp	00136$
      0064EB                       1788 00130$:
                                   1789 ;	tmk_core/protocol/ch555/usb_ak820.c:262: } else if (index == SHARED_INTERFACE && value == (0x0200 | REPORT_ID_NKRO) && D0SetupLen == 2) {
      0064EB BB 02 28         [24] 1790 	cjne	r3,#0x02,00125$
      0064EE BC 00 25         [24] 1791 	cjne	r4,#0x00,00125$
      0064F1 8D 01            [24] 1792 	mov	ar1,r5
      0064F3 8E 02            [24] 1793 	mov	ar2,r6
      0064F5 B9 06 1E         [24] 1794 	cjne	r1,#0x06,00125$
      0064F8 BA 02 1B         [24] 1795 	cjne	r2,#0x02,00125$
      0064FB 90 07 90         [24] 1796 	mov	dptr,#_D0SetupLen
      0064FE E0               [24] 1797 	movx	a,@dptr
      0064FF F9               [12] 1798 	mov	r1,a
      006500 A3               [24] 1799 	inc	dptr
      006501 E0               [24] 1800 	movx	a,@dptr
      006502 FA               [12] 1801 	mov	r2,a
      006503 B9 02 10         [24] 1802 	cjne	r1,#0x02,00125$
      006506 BA 00 0D         [24] 1803 	cjne	r2,#0x00,00125$
                                   1804 ;	tmk_core/protocol/ch555/usb_ak820.c:263: output_kind = OUTPUT_SHARED_LED;
      006509 90 07 F5         [24] 1805 	mov	dptr,#_output_kind
      00650C 74 03            [12] 1806 	mov	a,#0x03
      00650E F0               [24] 1807 	movx	@dptr,a
                                   1808 ;	tmk_core/protocol/ch555/usb_ak820.c:264: output_report_id = REPORT_ID_NKRO;
      00650F 90 07 F6         [24] 1809 	mov	dptr,#_output_report_id
      006512 23               [12] 1810 	rl	a
      006513 F0               [24] 1811 	movx	@dptr,a
      006514 80 03            [24] 1812 	sjmp	00136$
      006516                       1813 00125$:
                                   1814 ;	tmk_core/protocol/ch555/usb_ak820.c:266: } else { control_stall(); return; }
      006516 02 60 75         [24] 1815 	ljmp	_control_stall
      006519                       1816 00136$:
                                   1817 ;	tmk_core/protocol/ch555/usb_ak820.c:267: control_phase = CTRL_DATA_OUT;
      006519 90 07 F4         [24] 1818 	mov	dptr,#_control_phase
      00651C 74 04            [12] 1819 	mov	a,#0x04
      00651E F0               [24] 1820 	movx	@dptr,a
                                   1821 ;	tmk_core/protocol/ch555/usb_ak820.c:268: return; /* OUT data must arrive before status-IN becomes ACK */
      00651F 22               [24] 1822 	ret
                                   1823 ;	tmk_core/protocol/ch555/usb_ak820.c:269: } else { control_stall(); return; }
      006520 02 60 75         [24] 1824 	ljmp	_control_stall
                                   1825 ;	tmk_core/protocol/ch555/usb_ak820.c:271: case USB_GET_CONFIGURATION:
      006523                       1826 00150$:
                                   1827 ;	tmk_core/protocol/ch555/usb_ak820.c:272: if (type == 0x80 && zero_index && zero_value && D0SetupLen == 1) {
      006523 BF 80 2A         [24] 1828 	cjne	r7,#0x80,00152$
      006526 30 16 27         [24] 1829 	jnb	_control_setup_zero_index_10000_290,00152$
      006529 30 17 24         [24] 1830 	jnb	_control_setup_zero_value_10000_290,00152$
      00652C 90 07 90         [24] 1831 	mov	dptr,#_D0SetupLen
      00652F E0               [24] 1832 	movx	a,@dptr
      006530 F9               [12] 1833 	mov	r1,a
      006531 A3               [24] 1834 	inc	dptr
      006532 E0               [24] 1835 	movx	a,@dptr
      006533 FA               [12] 1836 	mov	r2,a
      006534 B9 01 19         [24] 1837 	cjne	r1,#0x01,00152$
      006537 BA 00 16         [24] 1838 	cjne	r2,#0x00,00152$
                                   1839 ;	tmk_core/protocol/ch555/usb_ak820.c:273: pD0_EP0_BUF[0] = D0UsbConfig;
      00653A 90 07 95         [24] 1840 	mov	dptr,#_D0UsbConfig
      00653D E0               [24] 1841 	movx	a,@dptr
      00653E 90 10 00         [24] 1842 	mov	dptr,#0x1000
      006541 F0               [24] 1843 	movx	@dptr,a
                                   1844 ;	tmk_core/protocol/ch555/usb_ak820.c:274: D0_EP0T_L = 1;
      006542 90 22 08         [24] 1845 	mov	dptr,#0x2208
      006545 74 01            [12] 1846 	mov	a,#0x01
      006547 F0               [24] 1847 	movx	@dptr,a
                                   1848 ;	tmk_core/protocol/ch555/usb_ak820.c:275: control_phase = CTRL_STATUS_OUT;
      006548 90 07 F4         [24] 1849 	mov	dptr,#_control_phase
      00654B 04               [12] 1850 	inc	a
      00654C F0               [24] 1851 	movx	@dptr,a
      00654D 02 6A 24         [24] 1852 	ljmp	00291$
      006550                       1853 00152$:
                                   1854 ;	tmk_core/protocol/ch555/usb_ak820.c:276: } else { control_stall(); return; }
      006550 02 60 75         [24] 1855 	ljmp	_control_stall
                                   1856 ;	tmk_core/protocol/ch555/usb_ak820.c:278: case USB_GET_INTERFACE: /* DEF_USB_SET_IDLE has the same request byte. */
      006553                       1857 00157$:
                                   1858 ;	tmk_core/protocol/ch555/usb_ak820.c:279: if (type == 0x81 && valid_interface && zero_value && D0SetupLen == 1 && D0UsbConfig) {
      006553 BF 81 2C         [24] 1859 	cjne	r7,#0x81,00167$
      006556 30 15 29         [24] 1860 	jnb	_control_setup_valid_interface_10000_290,00167$
      006559 30 17 26         [24] 1861 	jnb	_control_setup_zero_value_10000_290,00167$
      00655C 90 07 90         [24] 1862 	mov	dptr,#_D0SetupLen
      00655F E0               [24] 1863 	movx	a,@dptr
      006560 F9               [12] 1864 	mov	r1,a
      006561 A3               [24] 1865 	inc	dptr
      006562 E0               [24] 1866 	movx	a,@dptr
      006563 FA               [12] 1867 	mov	r2,a
      006564 B9 01 1B         [24] 1868 	cjne	r1,#0x01,00167$
      006567 BA 00 18         [24] 1869 	cjne	r2,#0x00,00167$
      00656A 90 07 95         [24] 1870 	mov	dptr,#_D0UsbConfig
      00656D E0               [24] 1871 	movx	a,@dptr
      00656E 60 12            [24] 1872 	jz	00167$
                                   1873 ;	tmk_core/protocol/ch555/usb_ak820.c:280: pD0_EP0_BUF[0] = 0;
      006570 90 10 00         [24] 1874 	mov	dptr,#0x1000
      006573 E4               [12] 1875 	clr	a
      006574 F0               [24] 1876 	movx	@dptr,a
                                   1877 ;	tmk_core/protocol/ch555/usb_ak820.c:281: D0_EP0T_L = 1;
      006575 90 22 08         [24] 1878 	mov	dptr,#0x2208
      006578 04               [12] 1879 	inc	a
      006579 F0               [24] 1880 	movx	@dptr,a
                                   1881 ;	tmk_core/protocol/ch555/usb_ak820.c:282: control_phase = CTRL_STATUS_OUT;
      00657A 90 07 F4         [24] 1882 	mov	dptr,#_control_phase
      00657D 04               [12] 1883 	inc	a
      00657E F0               [24] 1884 	movx	@dptr,a
      00657F 02 6A 24         [24] 1885 	ljmp	00291$
      006582                       1886 00167$:
                                   1887 ;	tmk_core/protocol/ch555/usb_ak820.c:283: } else if (valid_interface && D0UsbConfig && type == 0x21 && zero_length) {
      006582 30 15 1E         [24] 1888 	jnb	_control_setup_valid_interface_10000_290,00161$
      006585 90 07 95         [24] 1889 	mov	dptr,#_D0UsbConfig
      006588 E0               [24] 1890 	movx	a,@dptr
      006589 60 18            [24] 1891 	jz	00161$
      00658B BF 21 15         [24] 1892 	cjne	r7,#0x21,00161$
      00658E 30 18 12         [24] 1893 	jnb	_control_setup_zero_length_10000_290,00161$
                                   1894 ;	tmk_core/protocol/ch555/usb_ak820.c:284: if (index == KEYBOARD_INTERFACE) keyboard_idle = value >> 8;
      006591 EB               [12] 1895 	mov	a,r3
      006592 4C               [12] 1896 	orl	a,r4
      006593 70 05            [24] 1897 	jnz	00159$
      006595 90 06 57         [24] 1898 	mov	dptr,#_keyboard_idle
      006598 EE               [12] 1899 	mov	a,r6
      006599 F0               [24] 1900 	movx	@dptr,a
      00659A                       1901 00159$:
                                   1902 ;	tmk_core/protocol/ch555/usb_ak820.c:285: control_phase = CTRL_STATUS_IN;
      00659A 90 07 F4         [24] 1903 	mov	dptr,#_control_phase
      00659D 74 03            [12] 1904 	mov	a,#0x03
      00659F F0               [24] 1905 	movx	@dptr,a
      0065A0 02 6A 24         [24] 1906 	ljmp	00291$
      0065A3                       1907 00161$:
                                   1908 ;	tmk_core/protocol/ch555/usb_ak820.c:286: } else { control_stall(); return; }
      0065A3 02 60 75         [24] 1909 	ljmp	_control_stall
                                   1910 ;	tmk_core/protocol/ch555/usb_ak820.c:288: case USB_SET_INTERFACE: /* DEF_USB_SET_PROTOCOL has the same request byte. */
      0065A6                       1911 00173$:
                                   1912 ;	tmk_core/protocol/ch555/usb_ak820.c:289: if (type == 0x01 && valid_interface && zero_value && zero_length && D0UsbConfig) {
      0065A6 BF 01 18         [24] 1913 	cjne	r7,#0x01,00182$
      0065A9 30 15 15         [24] 1914 	jnb	_control_setup_valid_interface_10000_290,00182$
      0065AC 30 17 12         [24] 1915 	jnb	_control_setup_zero_value_10000_290,00182$
      0065AF 30 18 0F         [24] 1916 	jnb	_control_setup_zero_length_10000_290,00182$
      0065B2 90 07 95         [24] 1917 	mov	dptr,#_D0UsbConfig
      0065B5 E0               [24] 1918 	movx	a,@dptr
      0065B6 60 09            [24] 1919 	jz	00182$
                                   1920 ;	tmk_core/protocol/ch555/usb_ak820.c:290: control_phase = CTRL_STATUS_IN;
      0065B8 90 07 F4         [24] 1921 	mov	dptr,#_control_phase
      0065BB 74 03            [12] 1922 	mov	a,#0x03
      0065BD F0               [24] 1923 	movx	@dptr,a
      0065BE 02 6A 24         [24] 1924 	ljmp	00291$
      0065C1                       1925 00182$:
                                   1926 ;	tmk_core/protocol/ch555/usb_ak820.c:291: } else if (index == KEYBOARD_INTERFACE && D0UsbConfig && type == 0x21 && zero_length && value <= 1) {
      0065C1 EB               [12] 1927 	mov	a,r3
      0065C2 4C               [12] 1928 	orl	a,r4
      0065C3 70 2C            [24] 1929 	jnz	00175$
      0065C5 90 07 95         [24] 1930 	mov	dptr,#_D0UsbConfig
      0065C8 E0               [24] 1931 	movx	a,@dptr
      0065C9 60 26            [24] 1932 	jz	00175$
      0065CB BF 21 23         [24] 1933 	cjne	r7,#0x21,00175$
      0065CE 30 18 20         [24] 1934 	jnb	_control_setup_zero_length_10000_290,00175$
      0065D1 8D 01            [24] 1935 	mov	ar1,r5
      0065D3 8E 02            [24] 1936 	mov	ar2,r6
      0065D5 C3               [12] 1937 	clr	c
      0065D6 74 01            [12] 1938 	mov	a,#0x01
      0065D8 99               [12] 1939 	subb	a,r1
      0065D9 E4               [12] 1940 	clr	a
      0065DA 9A               [12] 1941 	subb	a,r2
      0065DB 40 14            [24] 1942 	jc	00175$
                                   1943 ;	free result
                                   1944 ;	tmk_core/protocol/ch555/usb_ak820.c:292: keyboard_protocol = value;
      0065DD 90 0D BD         [24] 1945 	mov	dptr,#_keyboard_protocol
      0065E0 ED               [12] 1946 	mov	a,r5
      0065E1 F0               [24] 1947 	movx	@dptr,a
                                   1948 ;	tmk_core/protocol/ch555/usb_ak820.c:293: keyboard_reset = 1;
      0065E2 90 07 BF         [24] 1949 	mov	dptr,#_keyboard_reset
      0065E5 74 01            [12] 1950 	mov	a,#0x01
      0065E7 F0               [24] 1951 	movx	@dptr,a
                                   1952 ;	tmk_core/protocol/ch555/usb_ak820.c:294: control_phase = CTRL_STATUS_IN;
      0065E8 90 07 F4         [24] 1953 	mov	dptr,#_control_phase
      0065EB 74 03            [12] 1954 	mov	a,#0x03
      0065ED F0               [24] 1955 	movx	@dptr,a
      0065EE 02 6A 24         [24] 1956 	ljmp	00291$
      0065F1                       1957 00175$:
                                   1958 ;	tmk_core/protocol/ch555/usb_ak820.c:295: } else { control_stall(); return; }
      0065F1 02 60 75         [24] 1959 	ljmp	_control_stall
                                   1960 ;	tmk_core/protocol/ch555/usb_ak820.c:297: case USB_GET_STATUS:
      0065F4                       1961 00188$:
                                   1962 ;	tmk_core/protocol/ch555/usb_ak820.c:298: if (zero_value && D0SetupLen == 2 &&
      0065F4 20 17 03         [24] 1963 	jb	_control_setup_zero_value_10000_290,01283$
      0065F7 02 60 75         [24] 1964 	ljmp	_control_stall
      0065FA                       1965 01283$:
      0065FA 90 07 90         [24] 1966 	mov	dptr,#_D0SetupLen
      0065FD E0               [24] 1967 	movx	a,@dptr
      0065FE F9               [12] 1968 	mov	r1,a
      0065FF A3               [24] 1969 	inc	dptr
      006600 E0               [24] 1970 	movx	a,@dptr
      006601 FA               [12] 1971 	mov	r2,a
      006602 B9 02 05         [24] 1972 	cjne	r1,#0x02,01284$
      006605 BA 00 02         [24] 1973 	cjne	r2,#0x00,01284$
      006608 80 03            [24] 1974 	sjmp	01285$
      00660A                       1975 01284$:
      00660A 02 60 75         [24] 1976 	ljmp	_control_stall
      00660D                       1977 01285$:
                                   1978 ;	tmk_core/protocol/ch555/usb_ak820.c:299: ((type == 0x80 && zero_index) || (type == 0x81 && valid_interface && D0UsbConfig) ||
      00660D E4               [12] 1979 	clr	a
      00660E BF 80 01         [24] 1980 	cjne	r7,#0x80,01286$
      006611 04               [12] 1981 	inc	a
      006612                       1982 01286$:
      006612 FA               [12] 1983 	mov	r2,a
      006613 60 03            [24] 1984 	jz	00196$
      006615 20 16 35         [24] 1985 	jb	_control_setup_zero_index_10000_290,00189$
      006618                       1986 00196$:
      006618 BF 81 09         [24] 1987 	cjne	r7,#0x81,00202$
      00661B 30 15 06         [24] 1988 	jnb	_control_setup_valid_interface_10000_290,00202$
      00661E 90 07 95         [24] 1989 	mov	dptr,#_D0UsbConfig
      006621 E0               [24] 1990 	movx	a,@dptr
      006622 70 29            [24] 1991 	jnz	00189$
      006624                       1992 00202$:
                                   1993 ;	tmk_core/protocol/ch555/usb_ak820.c:300: (type == 0x82 && D0UsbConfig && (index == 0 || index == 0x80 || (index >= 0x81 && index <= 0x83))))) {
      006624 BF 82 70         [24] 1994 	cjne	r7,#0x82,00190$
      006627 90 07 95         [24] 1995 	mov	dptr,#_D0UsbConfig
      00662A E0               [24] 1996 	movx	a,@dptr
      00662B 60 6A            [24] 1997 	jz	00190$
      00662D EB               [12] 1998 	mov	a,r3
      00662E 4C               [12] 1999 	orl	a,r4
      00662F 60 1C            [24] 2000 	jz	00189$
      006631 8B 00            [24] 2001 	mov	ar0,r3
      006633 8C 01            [24] 2002 	mov	ar1,r4
      006635 B8 80 05         [24] 2003 	cjne	r0,#0x80,01298$
      006638 B9 00 02         [24] 2004 	cjne	r1,#0x00,01298$
      00663B 80 10            [24] 2005 	sjmp	00189$
      00663D                       2006 01298$:
      00663D C3               [12] 2007 	clr	c
      00663E E8               [12] 2008 	mov	a,r0
      00663F 94 81            [12] 2009 	subb	a,#0x81
      006641 E9               [12] 2010 	mov	a,r1
      006642 94 00            [12] 2011 	subb	a,#0x00
      006644 40 51            [24] 2012 	jc	00190$
      006646 74 83            [12] 2013 	mov	a,#0x83
      006648 98               [12] 2014 	subb	a,r0
      006649 E4               [12] 2015 	clr	a
      00664A 99               [12] 2016 	subb	a,r1
      00664B 40 4A            [24] 2017 	jc	00190$
                                   2018 ;	free result
      00664D                       2019 00189$:
                                   2020 ;	tmk_core/protocol/ch555/usb_ak820.c:301: endpoint = index & 7;
      00664D 8B 01            [24] 2021 	mov	ar1,r3
      00664F 53 01 07         [24] 2022 	anl	ar1,#0x07
                                   2023 ;	tmk_core/protocol/ch555/usb_ak820.c:302: pD0_EP0_BUF[0] = type == 0x80 ? ((USB_SleepStatus & 1) << 1) :
      006652 EA               [12] 2024 	mov	a,r2
      006653 60 0B            [24] 2025 	jz	00308$
      006655 90 07 97         [24] 2026 	mov	dptr,#_USB_SleepStatus
      006658 E0               [24] 2027 	movx	a,@dptr
      006659 54 01            [12] 2028 	anl	a,#0x01
      00665B 25 E0            [12] 2029 	add	a,acc
      00665D FA               [12] 2030 	mov	r2,a
      00665E 80 22            [24] 2031 	sjmp	00309$
      006660                       2032 00308$:
                                   2033 ;	tmk_core/protocol/ch555/usb_ak820.c:303: ((type == 0x82 && endpoint && (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_STALL) ? 1 : 0);
      006660 BF 82 1B         [24] 2034 	cjne	r7,#0x82,00310$
      006663 E9               [12] 2035 	mov	a,r1
      006664 60 18            [24] 2036 	jz	00310$
      006666 89 00            [24] 2037 	mov	ar0,r1
      006668 79 00            [12] 2038 	mov	r1,#0x00
      00666A 74 22            [12] 2039 	mov	a,#0x22
      00666C 29               [12] 2040 	add	a, r1
      00666D F9               [12] 2041 	mov	r1,a
      00666E 88 82            [24] 2042 	mov	dpl,r0
      006670 89 83            [24] 2043 	mov	dph,r1
      006672 E0               [24] 2044 	movx	a,@dptr
      006673 F9               [12] 2045 	mov	r1,a
      006674 53 01 03         [24] 2046 	anl	ar1,#0x03
      006677 B9 03 04         [24] 2047 	cjne	r1,#0x03,00310$
      00667A 79 01            [12] 2048 	mov	r1,#0x01
      00667C 80 02            [24] 2049 	sjmp	00311$
      00667E                       2050 00310$:
      00667E 79 00            [12] 2051 	mov	r1,#0x00
      006680                       2052 00311$:
      006680 89 02            [24] 2053 	mov	ar2,r1
      006682                       2054 00309$:
      006682 90 10 00         [24] 2055 	mov	dptr,#0x1000
      006685 EA               [12] 2056 	mov	a,r2
      006686 F0               [24] 2057 	movx	@dptr,a
                                   2058 ;	tmk_core/protocol/ch555/usb_ak820.c:304: pD0_EP0_BUF[1] = 0;
      006687 A3               [24] 2059 	inc	dptr
      006688 E4               [12] 2060 	clr	a
      006689 F0               [24] 2061 	movx	@dptr,a
                                   2062 ;	tmk_core/protocol/ch555/usb_ak820.c:305: D0_EP0T_L = 2;
      00668A 90 22 08         [24] 2063 	mov	dptr,#0x2208
      00668D 74 02            [12] 2064 	mov	a,#0x02
      00668F F0               [24] 2065 	movx	@dptr,a
                                   2066 ;	tmk_core/protocol/ch555/usb_ak820.c:306: control_phase = CTRL_STATUS_OUT;
      006690 90 07 F4         [24] 2067 	mov	dptr,#_control_phase
      006693 F0               [24] 2068 	movx	@dptr,a
      006694 02 6A 24         [24] 2069 	ljmp	00291$
      006697                       2070 00190$:
                                   2071 ;	tmk_core/protocol/ch555/usb_ak820.c:307: } else { control_stall(); return; }
      006697 02 60 75         [24] 2072 	ljmp	_control_stall
                                   2073 ;	tmk_core/protocol/ch555/usb_ak820.c:310: case USB_SET_FEATURE: /* DEF_USB_GET_PROTOCOL has the same request byte. */
      00669A                       2074 00205$:
                                   2075 ;	tmk_core/protocol/ch555/usb_ak820.c:311: if (zero_length && D0UsbConfig) {
      00669A 20 18 03         [24] 2076 	jb	_control_setup_zero_length_10000_290,01307$
      00669D 02 67 2D         [24] 2077 	ljmp	00279$
      0066A0                       2078 01307$:
      0066A0 90 07 95         [24] 2079 	mov	dptr,#_D0UsbConfig
      0066A3 E0               [24] 2080 	movx	a,@dptr
      0066A4 70 03            [24] 2081 	jnz	01308$
      0066A6 02 67 2D         [24] 2082 	ljmp	00279$
      0066A9                       2083 01308$:
                                   2084 ;	tmk_core/protocol/ch555/usb_ak820.c:312: if (type == 0x00 && value == 1 && zero_index) {
      0066A9 EF               [12] 2085 	mov	a,r7
      0066AA 70 29            [24] 2086 	jnz	00218$
      0066AC 8D 01            [24] 2087 	mov	ar1,r5
      0066AE 8E 02            [24] 2088 	mov	ar2,r6
      0066B0 B9 01 22         [24] 2089 	cjne	r1,#0x01,00218$
      0066B3 BA 00 1F         [24] 2090 	cjne	r2,#0x00,00218$
      0066B6 30 16 1C         [24] 2091 	jnb	_control_setup_zero_index_10000_290,00218$
                                   2092 ;	tmk_core/protocol/ch555/usb_ak820.c:313: if (D0SetupReqCode == USB_SET_FEATURE) USB_SleepStatus |= 1;
      0066B9 90 07 8F         [24] 2093 	mov	dptr,#_D0SetupReqCode
      0066BC E0               [24] 2094 	movx	a,@dptr
      0066BD FA               [12] 2095 	mov	r2,a
      0066BE BA 03 0A         [24] 2096 	cjne	r2,#0x03,00207$
      0066C1 90 07 97         [24] 2097 	mov	dptr,#_USB_SleepStatus
      0066C4 E0               [24] 2098 	movx	a,@dptr
      0066C5 43 E0 01         [24] 2099 	orl	acc,#0x01
      0066C8 F0               [24] 2100 	movx	@dptr,a
      0066C9 80 59            [24] 2101 	sjmp	00219$
      0066CB                       2102 00207$:
                                   2103 ;	tmk_core/protocol/ch555/usb_ak820.c:314: else USB_SleepStatus &= ~1;
      0066CB 90 07 97         [24] 2104 	mov	dptr,#_USB_SleepStatus
      0066CE E0               [24] 2105 	movx	a,@dptr
      0066CF 53 E0 FE         [24] 2106 	anl	acc,#0xfe
      0066D2 F0               [24] 2107 	movx	@dptr,a
      0066D3 80 4F            [24] 2108 	sjmp	00219$
      0066D5                       2109 00218$:
                                   2110 ;	tmk_core/protocol/ch555/usb_ak820.c:315: } else if (type == 0x02 && zero_value && index >= 0x81 && index <= 0x83) {
      0066D5 BF 02 49         [24] 2111 	cjne	r7,#0x02,00212$
      0066D8 30 17 46         [24] 2112 	jnb	_control_setup_zero_value_10000_290,00212$
      0066DB 8B 01            [24] 2113 	mov	ar1,r3
      0066DD 8C 02            [24] 2114 	mov	ar2,r4
      0066DF C3               [12] 2115 	clr	c
      0066E0 E9               [12] 2116 	mov	a,r1
      0066E1 94 81            [12] 2117 	subb	a,#0x81
      0066E3 EA               [12] 2118 	mov	a,r2
      0066E4 94 00            [12] 2119 	subb	a,#0x00
      0066E6 40 39            [24] 2120 	jc	00212$
      0066E8 74 83            [12] 2121 	mov	a,#0x83
      0066EA 99               [12] 2122 	subb	a,r1
      0066EB E4               [12] 2123 	clr	a
      0066EC 9A               [12] 2124 	subb	a,r2
      0066ED 40 32            [24] 2125 	jc	00212$
                                   2126 ;	free result
                                   2127 ;	tmk_core/protocol/ch555/usb_ak820.c:316: endpoint = index & 7;
      0066EF 8B 02            [24] 2128 	mov	ar2,r3
      0066F1 53 02 07         [24] 2129 	anl	ar2,#0x07
                                   2130 ;	tmk_core/protocol/ch555/usb_ak820.c:318: EP_RESPONSE(endpoint) = bUEP_X_AUTO_TOG | (D0SetupReqCode == USB_SET_FEATURE ? UEP_X_RES_STALL : UEP_X_RES_NAK);
      0066F4 8A 00            [24] 2131 	mov	ar0,r2
      0066F6 79 00            [12] 2132 	mov	r1,#0x00
      0066F8 74 22            [12] 2133 	mov	a,#0x22
      0066FA 29               [12] 2134 	add	a, r1
      0066FB F9               [12] 2135 	mov	r1,a
      0066FC 88 17            [24] 2136 	mov	_control_setup_sloc3_1_0,r0
      0066FE 89 18            [24] 2137 	mov	(_control_setup_sloc3_1_0 + 1),r1
      006700 90 07 8F         [24] 2138 	mov	dptr,#_D0SetupReqCode
      006703 E0               [24] 2139 	movx	a,@dptr
      006704 F9               [12] 2140 	mov	r1,a
      006705 B9 03 04         [24] 2141 	cjne	r1,#0x03,00318$
      006708 79 03            [12] 2142 	mov	r1,#0x03
      00670A 80 02            [24] 2143 	sjmp	00319$
      00670C                       2144 00318$:
      00670C 79 02            [12] 2145 	mov	r1,#0x02
      00670E                       2146 00319$:
      00670E 43 01 10         [24] 2147 	orl	ar1,#0x10
      006711 85 17 82         [24] 2148 	mov	dpl,_control_setup_sloc3_1_0
      006714 85 18 83         [24] 2149 	mov	dph,(_control_setup_sloc3_1_0 + 1)
      006717 E9               [12] 2150 	mov	a,r1
      006718 F0               [24] 2151 	movx	@dptr,a
                                   2152 ;	tmk_core/protocol/ch555/usb_ak820.c:319: if (endpoint == RAW_IN_EPNUM) raw_complete();
      006719 BA 03 08         [24] 2153 	cjne	r2,#0x03,00219$
      00671C 12 5F F7         [24] 2154 	lcall	_raw_complete
      00671F 80 03            [24] 2155 	sjmp	00219$
      006721                       2156 00212$:
                                   2157 ;	tmk_core/protocol/ch555/usb_ak820.c:320: } else { control_stall(); return; }
      006721 02 60 75         [24] 2158 	ljmp	_control_stall
      006724                       2159 00219$:
                                   2160 ;	tmk_core/protocol/ch555/usb_ak820.c:321: control_phase = CTRL_STATUS_IN;
      006724 90 07 F4         [24] 2161 	mov	dptr,#_control_phase
      006727 74 03            [12] 2162 	mov	a,#0x03
      006729 F0               [24] 2163 	movx	@dptr,a
      00672A 02 6A 24         [24] 2164 	ljmp	00291$
      00672D                       2165 00279$:
                                   2166 ;	tmk_core/protocol/ch555/usb_ak820.c:322: } else if (type == 0xa1 && D0SetupReqCode == HID_GET_REPORT && D0UsbConfig && D0SetupLen) {
      00672D E4               [12] 2167 	clr	a
      00672E BF A1 01         [24] 2168 	cjne	r7,#0xa1,01324$
      006731 04               [12] 2169 	inc	a
      006732                       2170 01324$:
      006732 FA               [12] 2171 	mov	r2,a
      006733 70 03            [24] 2172 	jnz	01326$
      006735 02 69 9F         [24] 2173 	ljmp	00273$
      006738                       2174 01326$:
      006738 90 07 8F         [24] 2175 	mov	dptr,#_D0SetupReqCode
      00673B E0               [24] 2176 	movx	a,@dptr
      00673C F9               [12] 2177 	mov	r1,a
      00673D B9 01 02         [24] 2178 	cjne	r1,#0x01,01327$
      006740 80 03            [24] 2179 	sjmp	01328$
      006742                       2180 01327$:
      006742 02 69 9F         [24] 2181 	ljmp	00273$
      006745                       2182 01328$:
      006745 90 07 95         [24] 2183 	mov	dptr,#_D0UsbConfig
      006748 E0               [24] 2184 	movx	a,@dptr
      006749 70 03            [24] 2185 	jnz	01329$
      00674B 02 69 9F         [24] 2186 	ljmp	00273$
      00674E                       2187 01329$:
      00674E 90 07 90         [24] 2188 	mov	dptr,#_D0SetupLen
      006751 E0               [24] 2189 	movx	a,@dptr
      006752 F8               [12] 2190 	mov	r0,a
      006753 A3               [24] 2191 	inc	dptr
      006754 E0               [24] 2192 	movx	a,@dptr
      006755 48               [12] 2193 	orl	a,r0
      006756 70 03            [24] 2194 	jnz	01330$
      006758 02 69 9F         [24] 2195 	ljmp	00273$
      00675B                       2196 01330$:
                                   2197 ;	tmk_core/protocol/ch555/usb_ak820.c:323: report_id = value;
      00675B C0 03            [24] 2198 	push	ar3
      00675D C0 04            [24] 2199 	push	ar4
      00675F 8D 01            [24] 2200 	mov	ar1,r5
                                   2201 ;	tmk_core/protocol/ch555/usb_ak820.c:324: if ((value >> 8) == 1 && index == KEYBOARD_INTERFACE && !report_id) {
      006761 8E 00            [24] 2202 	mov	ar0,r6
      006763 B8 01 03         [24] 2203 	cjne	r0,#0x01,01331$
      006766 E8               [12] 2204 	mov	a,r0
      006767 80 01            [24] 2205 	sjmp	01332$
      006769                       2206 01331$:
      006769 E4               [12] 2207 	clr	a
      00676A                       2208 01332$:
      00676A F5 17            [12] 2209 	mov	_control_setup_sloc3_1_0,a
      00676C D0 04            [24] 2210 	pop	ar4
      00676E D0 03            [24] 2211 	pop	ar3
      006770 E5 17            [12] 2212 	mov	a,_control_setup_sloc3_1_0
      006772 60 17            [24] 2213 	jz	00251$
      006774 EB               [12] 2214 	mov	a,r3
      006775 4C               [12] 2215 	orl	a,r4
      006776 70 13            [24] 2216 	jnz	00251$
      006778 E9               [12] 2217 	mov	a,r1
      006779 70 10            [24] 2218 	jnz	00251$
                                   2219 ;	tmk_core/protocol/ch555/usb_ak820.c:325: length = KEYBOARD_EPSIZE;
      00677B 90 07 FE         [24] 2220 	mov	dptr,#_control_setup_length_10000_290
      00677E 74 08            [12] 2221 	mov	a,#0x08
      006780 F0               [24] 2222 	movx	@dptr,a
      006781 E4               [12] 2223 	clr	a
      006782 A3               [24] 2224 	inc	dptr
      006783 F0               [24] 2225 	movx	@dptr,a
                                   2226 ;	tmk_core/protocol/ch555/usb_ak820.c:326: offset = SNAPSHOT_KEYBOARD;
      006784 90 08 00         [24] 2227 	mov	dptr,#_control_setup_offset_10000_290
      006787 F0               [24] 2228 	movx	@dptr,a
      006788 02 69 0F         [24] 2229 	ljmp	00252$
      00678B                       2230 00251$:
                                   2231 ;	tmk_core/protocol/ch555/usb_ak820.c:327: } else if ((value >> 8) == 1 && index == SHARED_INTERFACE &&
      00678B E5 17            [12] 2232 	mov	a,_control_setup_sloc3_1_0
      00678D 60 27            [24] 2233 	jz	00245$
      00678F BB 02 24         [24] 2234 	cjne	r3,#0x02,00245$
      006792 BC 00 21         [24] 2235 	cjne	r4,#0x00,00245$
                                   2236 ;	tmk_core/protocol/ch555/usb_ak820.c:328: report_id < sizeof(shared_lengths) && shared_lengths[report_id]) {
      006795 B9 07 00         [24] 2237 	cjne	r1,#0x07,01339$
      006798                       2238 01339$:
      006798 50 1C            [24] 2239 	jnc	00245$
      00679A E9               [12] 2240 	mov	a,r1
      00679B 90 BE 6A         [24] 2241 	mov	dptr,#_shared_lengths
      00679E 93               [24] 2242 	movc	a,@a+dptr
      00679F F8               [12] 2243 	mov	r0,a
      0067A0 60 14            [24] 2244 	jz	00245$
                                   2245 ;	tmk_core/protocol/ch555/usb_ak820.c:329: length = shared_lengths[report_id];
      0067A2 90 07 FE         [24] 2246 	mov	dptr,#_control_setup_length_10000_290
      0067A5 E8               [12] 2247 	mov	a,r0
      0067A6 F0               [24] 2248 	movx	@dptr,a
      0067A7 E4               [12] 2249 	clr	a
      0067A8 A3               [24] 2250 	inc	dptr
      0067A9 F0               [24] 2251 	movx	@dptr,a
                                   2252 ;	tmk_core/protocol/ch555/usb_ak820.c:330: offset = shared_offsets[report_id];
      0067AA E9               [12] 2253 	mov	a,r1
      0067AB 90 BE 63         [24] 2254 	mov	dptr,#_shared_offsets
      0067AE 93               [24] 2255 	movc	a,@a+dptr
      0067AF 90 08 00         [24] 2256 	mov	dptr,#_control_setup_offset_10000_290
      0067B2 F0               [24] 2257 	movx	@dptr,a
      0067B3 02 69 0F         [24] 2258 	ljmp	00252$
      0067B6                       2259 00245$:
                                   2260 ;	tmk_core/protocol/ch555/usb_ak820.c:331: } else if ((value >> 8) == 1 && index == RAW_INTERFACE && !report_id) {
      0067B6 E5 17            [12] 2261 	mov	a,_control_setup_sloc3_1_0
      0067B8 60 7A            [24] 2262 	jz	00240$
      0067BA BB 01 77         [24] 2263 	cjne	r3,#0x01,00240$
      0067BD BC 00 74         [24] 2264 	cjne	r4,#0x00,00240$
      0067C0 E9               [12] 2265 	mov	a,r1
      0067C1 70 71            [24] 2266 	jnz	00240$
                                   2267 ;	tmk_core/protocol/ch555/usb_ak820.c:332: length = D0SetupLen < RAW_EPSIZE ? D0SetupLen : RAW_EPSIZE;
      0067C3 90 07 90         [24] 2268 	mov	dptr,#_D0SetupLen
      0067C6 E0               [24] 2269 	movx	a,@dptr
      0067C7 F8               [12] 2270 	mov	r0,a
      0067C8 A3               [24] 2271 	inc	dptr
      0067C9 E0               [24] 2272 	movx	a,@dptr
      0067CA F9               [12] 2273 	mov	r1,a
      0067CB C3               [12] 2274 	clr	c
      0067CC E8               [12] 2275 	mov	a,r0
      0067CD 94 20            [12] 2276 	subb	a,#0x20
      0067CF E9               [12] 2277 	mov	a,r1
      0067D0 94 00            [12] 2278 	subb	a,#0x00
      0067D2 50 0A            [24] 2279 	jnc	00320$
      0067D4 90 07 90         [24] 2280 	mov	dptr,#_D0SetupLen
      0067D7 E0               [24] 2281 	movx	a,@dptr
      0067D8 F8               [12] 2282 	mov	r0,a
      0067D9 A3               [24] 2283 	inc	dptr
      0067DA E0               [24] 2284 	movx	a,@dptr
      0067DB F9               [12] 2285 	mov	r1,a
      0067DC 80 04            [24] 2286 	sjmp	00321$
      0067DE                       2287 00320$:
      0067DE 78 20            [12] 2288 	mov	r0,#0x20
      0067E0 79 00            [12] 2289 	mov	r1,#0x00
      0067E2                       2290 00321$:
                                   2291 ;	tmk_core/protocol/ch555/usb_ak820.c:333: for (i = 0; i < length; ++i) pD0_EP0_BUF[i] = pUSB_BUF_DEV0[UX_EP3_ADDR + i];
      0067E2 75 17 00         [24] 2292 	mov	_control_setup_sloc3_1_0,#0x00
      0067E5                       2293 00293$:
      0067E5 C0 03            [24] 2294 	push	ar3
      0067E7 C0 04            [24] 2295 	push	ar4
      0067E9 AB 17            [24] 2296 	mov	r3,_control_setup_sloc3_1_0
      0067EB 7C 00            [12] 2297 	mov	r4,#0x00
      0067ED C3               [12] 2298 	clr	c
      0067EE EB               [12] 2299 	mov	a,r3
      0067EF 98               [12] 2300 	subb	a,r0
      0067F0 EC               [12] 2301 	mov	a,r4
      0067F1 99               [12] 2302 	subb	a,r1
      0067F2 D0 04            [24] 2303 	pop	ar4
      0067F4 D0 03            [24] 2304 	pop	ar3
      0067F6 50 32            [24] 2305 	jnc	00222$
      0067F8 C0 00            [24] 2306 	push	ar0
      0067FA C0 01            [24] 2307 	push	ar1
      0067FC 85 17 19         [24] 2308 	mov	_control_setup_sloc4_1_0,_control_setup_sloc3_1_0
      0067FF 74 10            [12] 2309 	mov	a,#0x10
      006801 24 00            [12] 2310 	add	a, #0x00
      006803 F5 1A            [12] 2311 	mov	(_control_setup_sloc4_1_0 + 1),a
      006805 A8 17            [24] 2312 	mov	r0,_control_setup_sloc3_1_0
      006807 79 00            [12] 2313 	mov	r1,#0x00
      006809 74 C0            [12] 2314 	mov	a,#0xc0
      00680B 28               [12] 2315 	add	a, r0
      00680C F8               [12] 2316 	mov	r0,a
      00680D E4               [12] 2317 	clr	a
      00680E 39               [12] 2318 	addc	a, r1
      00680F F9               [12] 2319 	mov	r1,a
      006810 88 82            [24] 2320 	mov	dpl,r0
      006812 74 10            [12] 2321 	mov	a,#0x10
      006814 29               [12] 2322 	add	a, r1
      006815 F5 83            [12] 2323 	mov	dph,a
      006817 E0               [24] 2324 	movx	a,@dptr
      006818 85 19 82         [24] 2325 	mov	dpl,_control_setup_sloc4_1_0
      00681B 85 1A 83         [24] 2326 	mov	dph,(_control_setup_sloc4_1_0 + 1)
      00681E F0               [24] 2327 	movx	@dptr,a
      00681F E5 17            [12] 2328 	mov	a,_control_setup_sloc3_1_0
      006821 04               [12] 2329 	inc	a
      006822 F5 17            [12] 2330 	mov	_control_setup_sloc3_1_0,a
      006824 D0 01            [24] 2331 	pop	ar1
      006826 D0 00            [24] 2332 	pop	ar0
      006828 80 BB            [24] 2333 	sjmp	00293$
      00682A                       2334 00222$:
                                   2335 ;	tmk_core/protocol/ch555/usb_ak820.c:334: length = 0; /* data already copied */
      00682A 90 07 FE         [24] 2336 	mov	dptr,#_control_setup_length_10000_290
      00682D E4               [12] 2337 	clr	a
      00682E F0               [24] 2338 	movx	@dptr,a
      00682F A3               [24] 2339 	inc	dptr
      006830 F0               [24] 2340 	movx	@dptr,a
      006831 02 69 0F         [24] 2341 	ljmp	00252$
      006834                       2342 00240$:
                                   2343 ;	tmk_core/protocol/ch555/usb_ak820.c:335: } else if (value == 0x0200 && index == KEYBOARD_INTERFACE) {
      006834 8D 00            [24] 2344 	mov	ar0,r5
      006836 8E 01            [24] 2345 	mov	ar1,r6
      006838 B8 00 21         [24] 2346 	cjne	r0,#0x00,00236$
      00683B B9 02 1E         [24] 2347 	cjne	r1,#0x02,00236$
      00683E EB               [12] 2348 	mov	a,r3
      00683F 4C               [12] 2349 	orl	a,r4
      006840 70 1A            [24] 2350 	jnz	00236$
                                   2351 ;	tmk_core/protocol/ch555/usb_ak820.c:336: pD0_EP0_BUF[0] = KB_USB_SetReport;
      006842 90 07 9A         [24] 2352 	mov	dptr,#_KB_USB_SetReport
      006845 E0               [24] 2353 	movx	a,@dptr
      006846 90 10 00         [24] 2354 	mov	dptr,#0x1000
      006849 F0               [24] 2355 	movx	@dptr,a
                                   2356 ;	tmk_core/protocol/ch555/usb_ak820.c:337: length = 0;
      00684A 90 07 FE         [24] 2357 	mov	dptr,#_control_setup_length_10000_290
      00684D E4               [12] 2358 	clr	a
      00684E F0               [24] 2359 	movx	@dptr,a
      00684F A3               [24] 2360 	inc	dptr
      006850 F0               [24] 2361 	movx	@dptr,a
                                   2362 ;	tmk_core/protocol/ch555/usb_ak820.c:338: D0SetupLen = 1;
      006851 90 07 90         [24] 2363 	mov	dptr,#_D0SetupLen
      006854 04               [12] 2364 	inc	a
      006855 F0               [24] 2365 	movx	@dptr,a
      006856 E4               [12] 2366 	clr	a
      006857 A3               [24] 2367 	inc	dptr
      006858 F0               [24] 2368 	movx	@dptr,a
      006859 02 69 0F         [24] 2369 	ljmp	00252$
      00685C                       2370 00236$:
                                   2371 ;	tmk_core/protocol/ch555/usb_ak820.c:339: } else if (value == (0x0200 | REPORT_ID_NKRO) && index == SHARED_INTERFACE) {
      00685C B8 06 41         [24] 2372 	cjne	r0,#0x06,00232$
      00685F B9 02 3E         [24] 2373 	cjne	r1,#0x02,00232$
      006862 BB 02 3B         [24] 2374 	cjne	r3,#0x02,00232$
      006865 BC 00 38         [24] 2375 	cjne	r4,#0x00,00232$
                                   2376 ;	tmk_core/protocol/ch555/usb_ak820.c:340: pD0_EP0_BUF[0] = REPORT_ID_NKRO;
      006868 C0 03            [24] 2377 	push	ar3
      00686A C0 04            [24] 2378 	push	ar4
      00686C 90 10 00         [24] 2379 	mov	dptr,#0x1000
      00686F 74 06            [12] 2380 	mov	a,#0x06
      006871 F0               [24] 2381 	movx	@dptr,a
                                   2382 ;	tmk_core/protocol/ch555/usb_ak820.c:341: pD0_EP0_BUF[1] = KB_USB_SetReport;
      006872 90 07 9A         [24] 2383 	mov	dptr,#_KB_USB_SetReport
      006875 E0               [24] 2384 	movx	a,@dptr
      006876 90 10 01         [24] 2385 	mov	dptr,#0x1001
      006879 F0               [24] 2386 	movx	@dptr,a
                                   2387 ;	tmk_core/protocol/ch555/usb_ak820.c:342: length = 0;
      00687A 90 07 FE         [24] 2388 	mov	dptr,#_control_setup_length_10000_290
      00687D E4               [12] 2389 	clr	a
      00687E F0               [24] 2390 	movx	@dptr,a
      00687F A3               [24] 2391 	inc	dptr
      006880 F0               [24] 2392 	movx	@dptr,a
                                   2393 ;	tmk_core/protocol/ch555/usb_ak820.c:343: if (D0SetupLen > 2) D0SetupLen = 2;
      006881 90 07 90         [24] 2394 	mov	dptr,#_D0SetupLen
      006884 E0               [24] 2395 	movx	a,@dptr
      006885 FB               [12] 2396 	mov	r3,a
      006886 A3               [24] 2397 	inc	dptr
      006887 E0               [24] 2398 	movx	a,@dptr
      006888 FC               [12] 2399 	mov	r4,a
      006889 C3               [12] 2400 	clr	c
      00688A 74 02            [12] 2401 	mov	a,#0x02
      00688C 9B               [12] 2402 	subb	a,r3
      00688D E4               [12] 2403 	clr	a
      00688E 9C               [12] 2404 	subb	a,r4
      00688F D0 04            [24] 2405 	pop	ar4
      006891 D0 03            [24] 2406 	pop	ar3
      006893 50 7A            [24] 2407 	jnc	00252$
                                   2408 ;	free result
      006895 90 07 90         [24] 2409 	mov	dptr,#_D0SetupLen
      006898 74 02            [12] 2410 	mov	a,#0x02
      00689A F0               [24] 2411 	movx	@dptr,a
      00689B E4               [12] 2412 	clr	a
      00689C A3               [24] 2413 	inc	dptr
      00689D F0               [24] 2414 	movx	@dptr,a
      00689E 80 6F            [24] 2415 	sjmp	00252$
      0068A0                       2416 00232$:
                                   2417 ;	tmk_core/protocol/ch555/usb_ak820.c:344: } else if (value == 0x0300 && index == RAW_INTERFACE) {
      0068A0 B8 00 69         [24] 2418 	cjne	r0,#0x00,00228$
      0068A3 B9 03 66         [24] 2419 	cjne	r1,#0x03,00228$
      0068A6 BB 01 63         [24] 2420 	cjne	r3,#0x01,00228$
      0068A9 BC 00 60         [24] 2421 	cjne	r4,#0x00,00228$
                                   2422 ;	tmk_core/protocol/ch555/usb_ak820.c:347: pD0_EP0_BUF[0] = 'A';
      0068AC 90 10 00         [24] 2423 	mov	dptr,#0x1000
      0068AF 74 41            [12] 2424 	mov	a,#0x41
      0068B1 F0               [24] 2425 	movx	@dptr,a
                                   2426 ;	tmk_core/protocol/ch555/usb_ak820.c:348: pD0_EP0_BUF[1] = 'K';
      0068B2 A3               [24] 2427 	inc	dptr
      0068B3 74 4B            [12] 2428 	mov	a,#0x4b
      0068B5 F0               [24] 2429 	movx	@dptr,a
                                   2430 ;	tmk_core/protocol/ch555/usb_ak820.c:349: pD0_EP0_BUF[2] = 'B';
      0068B6 A3               [24] 2431 	inc	dptr
      0068B7 74 42            [12] 2432 	mov	a,#0x42
      0068B9 F0               [24] 2433 	movx	@dptr,a
                                   2434 ;	tmk_core/protocol/ch555/usb_ak820.c:350: pD0_EP0_BUF[3] = 'T';
      0068BA A3               [24] 2435 	inc	dptr
      0068BB 74 54            [12] 2436 	mov	a,#0x54
      0068BD F0               [24] 2437 	movx	@dptr,a
                                   2438 ;	tmk_core/protocol/ch555/usb_ak820.c:351: pD0_EP0_BUF[4] = 1;
      0068BE A3               [24] 2439 	inc	dptr
      0068BF 74 01            [12] 2440 	mov	a,#0x01
      0068C1 F0               [24] 2441 	movx	@dptr,a
                                   2442 ;	tmk_core/protocol/ch555/usb_ak820.c:352: pD0_EP0_BUF[5] = ak820_boot_stage;
      0068C2 90 07 9B         [24] 2443 	mov	dptr,#_ak820_boot_stage
      0068C5 E0               [24] 2444 	movx	a,@dptr
      0068C6 90 10 05         [24] 2445 	mov	dptr,#0x1005
      0068C9 F0               [24] 2446 	movx	@dptr,a
                                   2447 ;	tmk_core/protocol/ch555/usb_ak820.c:353: pD0_EP0_BUF[6] = ak820_main_heartbeat;
      0068CA 90 07 9C         [24] 2448 	mov	dptr,#_ak820_main_heartbeat
      0068CD E0               [24] 2449 	movx	a,@dptr
      0068CE 90 10 06         [24] 2450 	mov	dptr,#0x1006
      0068D1 F0               [24] 2451 	movx	@dptr,a
                                   2452 ;	tmk_core/protocol/ch555/usb_ak820.c:354: pD0_EP0_BUF[7] = (USB_EnumStatus ? 1 : 0) | (USB_SleepStatus & 2);
      0068D2 90 07 96         [24] 2453 	mov	dptr,#_USB_EnumStatus
      0068D5 E0               [24] 2454 	movx	a,@dptr
      0068D6 60 02            [24] 2455 	jz	00322$
      0068D8 74 01            [12] 2456 	mov	a,#0x01
      0068DA                       2457 00322$:
      0068DA F9               [12] 2458 	mov	r1,a
      0068DB 90 07 97         [24] 2459 	mov	dptr,#_USB_SleepStatus
      0068DE E0               [24] 2460 	movx	a,@dptr
      0068DF 54 02            [12] 2461 	anl	a,#0x02
      0068E1 F8               [12] 2462 	mov	r0,a
      0068E2 E9               [12] 2463 	mov	a,r1
      0068E3 42 00            [12] 2464 	orl	ar0,a
      0068E5 90 10 07         [24] 2465 	mov	dptr,#0x1007
      0068E8 E8               [12] 2466 	mov	a,r0
      0068E9 F0               [24] 2467 	movx	@dptr,a
                                   2468 ;	tmk_core/protocol/ch555/usb_ak820.c:355: length = 0;
      0068EA 90 07 FE         [24] 2469 	mov	dptr,#_control_setup_length_10000_290
      0068ED E4               [12] 2470 	clr	a
      0068EE F0               [24] 2471 	movx	@dptr,a
      0068EF A3               [24] 2472 	inc	dptr
      0068F0 F0               [24] 2473 	movx	@dptr,a
                                   2474 ;	tmk_core/protocol/ch555/usb_ak820.c:356: if (D0SetupLen > 8) D0SetupLen = 8;
      0068F1 90 07 90         [24] 2475 	mov	dptr,#_D0SetupLen
      0068F4 E0               [24] 2476 	movx	a,@dptr
      0068F5 F8               [12] 2477 	mov	r0,a
      0068F6 A3               [24] 2478 	inc	dptr
      0068F7 E0               [24] 2479 	movx	a,@dptr
      0068F8 F9               [12] 2480 	mov	r1,a
      0068F9 C3               [12] 2481 	clr	c
      0068FA 74 08            [12] 2482 	mov	a,#0x08
      0068FC 98               [12] 2483 	subb	a,r0
      0068FD E4               [12] 2484 	clr	a
      0068FE 99               [12] 2485 	subb	a,r1
      0068FF 50 0E            [24] 2486 	jnc	00252$
                                   2487 ;	free result
      006901 90 07 90         [24] 2488 	mov	dptr,#_D0SetupLen
      006904 74 08            [12] 2489 	mov	a,#0x08
      006906 F0               [24] 2490 	movx	@dptr,a
      006907 E4               [12] 2491 	clr	a
      006908 A3               [24] 2492 	inc	dptr
      006909 F0               [24] 2493 	movx	@dptr,a
      00690A 80 03            [24] 2494 	sjmp	00252$
      00690C                       2495 00228$:
                                   2496 ;	tmk_core/protocol/ch555/usb_ak820.c:357: } else { control_stall(); return; }
      00690C 02 60 75         [24] 2497 	ljmp	_control_stall
      00690F                       2498 00252$:
                                   2499 ;	tmk_core/protocol/ch555/usb_ak820.c:358: if (length) {
      00690F 90 07 FE         [24] 2500 	mov	dptr,#_control_setup_length_10000_290
      006912 E0               [24] 2501 	movx	a,@dptr
      006913 F5 19            [12] 2502 	mov	_control_setup_sloc4_1_0,a
      006915 A3               [24] 2503 	inc	dptr
      006916 E0               [24] 2504 	movx	a,@dptr
      006917 F5 1A            [12] 2505 	mov	(_control_setup_sloc4_1_0 + 1),a
      006919 E5 19            [12] 2506 	mov	a,_control_setup_sloc4_1_0
      00691B 45 1A            [12] 2507 	orl	a,(_control_setup_sloc4_1_0 + 1)
      00691D 60 50            [24] 2508 	jz	00262$
                                   2509 ;	tmk_core/protocol/ch555/usb_ak820.c:359: if (D0SetupLen > length) D0SetupLen = length;
      00691F 90 07 90         [24] 2510 	mov	dptr,#_D0SetupLen
      006922 E0               [24] 2511 	movx	a,@dptr
      006923 F8               [12] 2512 	mov	r0,a
      006924 A3               [24] 2513 	inc	dptr
      006925 E0               [24] 2514 	movx	a,@dptr
      006926 F9               [12] 2515 	mov	r1,a
      006927 C3               [12] 2516 	clr	c
      006928 E5 19            [12] 2517 	mov	a,_control_setup_sloc4_1_0
      00692A 98               [12] 2518 	subb	a,r0
      00692B E5 1A            [12] 2519 	mov	a,(_control_setup_sloc4_1_0 + 1)
      00692D 99               [12] 2520 	subb	a,r1
      00692E 50 0A            [24] 2521 	jnc	00559$
                                   2522 ;	free result
      006930 90 07 90         [24] 2523 	mov	dptr,#_D0SetupLen
      006933 E5 19            [12] 2524 	mov	a,_control_setup_sloc4_1_0
      006935 F0               [24] 2525 	movx	@dptr,a
      006936 E5 1A            [12] 2526 	mov	a,(_control_setup_sloc4_1_0 + 1)
      006938 A3               [24] 2527 	inc	dptr
      006939 F0               [24] 2528 	movx	@dptr,a
                                   2529 ;	tmk_core/protocol/ch555/usb_ak820.c:362: for (i = 0; i < (uint8_t)D0SetupLen; ++i) pD0_EP0_BUF[i] = input_snapshot[offset + i];
      00693A                       2530 00559$:
      00693A 75 19 00         [24] 2531 	mov	_control_setup_sloc4_1_0,#0x00
      00693D                       2532 00296$:
      00693D 90 07 90         [24] 2533 	mov	dptr,#_D0SetupLen
      006940 E0               [24] 2534 	movx	a,@dptr
      006941 F8               [12] 2535 	mov	r0,a
      006942 C3               [12] 2536 	clr	c
      006943 E5 19            [12] 2537 	mov	a,_control_setup_sloc4_1_0
      006945 98               [12] 2538 	subb	a,r0
      006946 50 46            [24] 2539 	jnc	00263$
      006948 85 19 17         [24] 2540 	mov	_control_setup_sloc3_1_0,_control_setup_sloc4_1_0
      00694B 74 10            [12] 2541 	mov	a,#0x10
      00694D 24 00            [12] 2542 	add	a, #0x00
      00694F F5 18            [12] 2543 	mov	(_control_setup_sloc3_1_0 + 1),a
      006951 90 08 00         [24] 2544 	mov	dptr,#_control_setup_offset_10000_290
      006954 E0               [24] 2545 	movx	a,@dptr
      006955 25 19            [12] 2546 	add	a, _control_setup_sloc4_1_0
      006957 24 C0            [12] 2547 	add	a, #_input_snapshot
      006959 F5 82            [12] 2548 	mov	dpl,a
      00695B E4               [12] 2549 	clr	a
      00695C 34 07            [12] 2550 	addc	a,#(_input_snapshot >> 8)
      00695E F5 83            [12] 2551 	mov	dph,a
      006960 E0               [24] 2552 	movx	a,@dptr
      006961 85 17 82         [24] 2553 	mov	dpl,_control_setup_sloc3_1_0
      006964 85 18 83         [24] 2554 	mov	dph,(_control_setup_sloc3_1_0 + 1)
      006967 F0               [24] 2555 	movx	@dptr,a
      006968 E5 19            [12] 2556 	mov	a,_control_setup_sloc4_1_0
      00696A 04               [12] 2557 	inc	a
      00696B F5 19            [12] 2558 	mov	_control_setup_sloc4_1_0,a
      00696D 80 CE            [24] 2559 	sjmp	00296$
      00696F                       2560 00262$:
                                   2561 ;	tmk_core/protocol/ch555/usb_ak820.c:363: } else if (index == RAW_INTERFACE && D0SetupLen > RAW_EPSIZE) D0SetupLen = RAW_EPSIZE;
      00696F BB 01 1C         [24] 2562 	cjne	r3,#0x01,00263$
      006972 BC 00 19         [24] 2563 	cjne	r4,#0x00,00263$
      006975 90 07 90         [24] 2564 	mov	dptr,#_D0SetupLen
      006978 E0               [24] 2565 	movx	a,@dptr
      006979 F8               [12] 2566 	mov	r0,a
      00697A A3               [24] 2567 	inc	dptr
      00697B E0               [24] 2568 	movx	a,@dptr
      00697C F9               [12] 2569 	mov	r1,a
      00697D C3               [12] 2570 	clr	c
      00697E 74 20            [12] 2571 	mov	a,#0x20
      006980 98               [12] 2572 	subb	a,r0
      006981 E4               [12] 2573 	clr	a
      006982 99               [12] 2574 	subb	a,r1
      006983 50 09            [24] 2575 	jnc	00263$
                                   2576 ;	free result
      006985 90 07 90         [24] 2577 	mov	dptr,#_D0SetupLen
      006988 74 20            [12] 2578 	mov	a,#0x20
      00698A F0               [24] 2579 	movx	@dptr,a
      00698B E4               [12] 2580 	clr	a
      00698C A3               [24] 2581 	inc	dptr
      00698D F0               [24] 2582 	movx	@dptr,a
      00698E                       2583 00263$:
                                   2584 ;	tmk_core/protocol/ch555/usb_ak820.c:364: D0_EP0T_L = D0SetupLen;
      00698E 90 07 90         [24] 2585 	mov	dptr,#_D0SetupLen
      006991 E0               [24] 2586 	movx	a,@dptr
      006992 90 22 08         [24] 2587 	mov	dptr,#0x2208
      006995 F0               [24] 2588 	movx	@dptr,a
                                   2589 ;	tmk_core/protocol/ch555/usb_ak820.c:365: control_phase = CTRL_STATUS_OUT;
      006996 90 07 F4         [24] 2590 	mov	dptr,#_control_phase
      006999 74 02            [12] 2591 	mov	a,#0x02
      00699B F0               [24] 2592 	movx	@dptr,a
      00699C 02 6A 24         [24] 2593 	ljmp	00291$
      00699F                       2594 00273$:
                                   2595 ;	tmk_core/protocol/ch555/usb_ak820.c:366: } else if (index == KEYBOARD_INTERFACE && D0UsbConfig && type == 0xa1 && D0SetupReqCode == DEF_USB_GET_PROTOCOL && zero_value && D0SetupLen == 1) {
      00699F EB               [12] 2596 	mov	a,r3
      0069A0 4C               [12] 2597 	orl	a,r4
      0069A1 70 37            [24] 2598 	jnz	00265$
      0069A3 90 07 95         [24] 2599 	mov	dptr,#_D0UsbConfig
      0069A6 E0               [24] 2600 	movx	a,@dptr
      0069A7 60 31            [24] 2601 	jz	00265$
      0069A9 EA               [12] 2602 	mov	a,r2
      0069AA 60 2E            [24] 2603 	jz	00265$
      0069AC 90 07 8F         [24] 2604 	mov	dptr,#_D0SetupReqCode
      0069AF E0               [24] 2605 	movx	a,@dptr
      0069B0 FA               [12] 2606 	mov	r2,a
      0069B1 BA 03 26         [24] 2607 	cjne	r2,#0x03,00265$
      0069B4 30 17 23         [24] 2608 	jnb	_control_setup_zero_value_10000_290,00265$
      0069B7 90 07 90         [24] 2609 	mov	dptr,#_D0SetupLen
      0069BA E0               [24] 2610 	movx	a,@dptr
      0069BB F9               [12] 2611 	mov	r1,a
      0069BC A3               [24] 2612 	inc	dptr
      0069BD E0               [24] 2613 	movx	a,@dptr
      0069BE FA               [12] 2614 	mov	r2,a
      0069BF B9 01 18         [24] 2615 	cjne	r1,#0x01,00265$
      0069C2 BA 00 15         [24] 2616 	cjne	r2,#0x00,00265$
                                   2617 ;	tmk_core/protocol/ch555/usb_ak820.c:367: pD0_EP0_BUF[0] = keyboard_protocol;
      0069C5 90 0D BD         [24] 2618 	mov	dptr,#_keyboard_protocol
      0069C8 E0               [24] 2619 	movx	a,@dptr
      0069C9 90 10 00         [24] 2620 	mov	dptr,#0x1000
      0069CC F0               [24] 2621 	movx	@dptr,a
                                   2622 ;	tmk_core/protocol/ch555/usb_ak820.c:368: D0_EP0T_L = 1;
      0069CD 90 22 08         [24] 2623 	mov	dptr,#0x2208
      0069D0 74 01            [12] 2624 	mov	a,#0x01
      0069D2 F0               [24] 2625 	movx	@dptr,a
                                   2626 ;	tmk_core/protocol/ch555/usb_ak820.c:369: control_phase = CTRL_STATUS_OUT;
      0069D3 90 07 F4         [24] 2627 	mov	dptr,#_control_phase
      0069D6 04               [12] 2628 	inc	a
      0069D7 F0               [24] 2629 	movx	@dptr,a
      0069D8 80 4A            [24] 2630 	sjmp	00291$
      0069DA                       2631 00265$:
                                   2632 ;	tmk_core/protocol/ch555/usb_ak820.c:370: } else { control_stall(); return; }
                                   2633 ;	tmk_core/protocol/ch555/usb_ak820.c:372: case DEF_USB_GET_IDLE:
      0069DA 02 60 75         [24] 2634 	ljmp	_control_stall
      0069DD                       2635 00282$:
                                   2636 ;	tmk_core/protocol/ch555/usb_ak820.c:373: if (valid_interface && D0UsbConfig && type == 0xa1 && !(value >> 8) && D0SetupLen == 1) {
      0069DD 30 15 3E         [24] 2637 	jnb	_control_setup_valid_interface_10000_290,00284$
      0069E0 90 07 95         [24] 2638 	mov	dptr,#_D0UsbConfig
      0069E3 E0               [24] 2639 	movx	a,@dptr
      0069E4 60 38            [24] 2640 	jz	00284$
      0069E6 BF A1 35         [24] 2641 	cjne	r7,#0xa1,00284$
      0069E9 8E 05            [24] 2642 	mov	ar5,r6
      0069EB 7E 00            [12] 2643 	mov	r6,#0x00
      0069ED ED               [12] 2644 	mov	a,r5
      0069EE 4E               [12] 2645 	orl	a,r6
      0069EF 70 2D            [24] 2646 	jnz	00284$
      0069F1 90 07 90         [24] 2647 	mov	dptr,#_D0SetupLen
      0069F4 E0               [24] 2648 	movx	a,@dptr
      0069F5 FE               [12] 2649 	mov	r6,a
      0069F6 A3               [24] 2650 	inc	dptr
      0069F7 E0               [24] 2651 	movx	a,@dptr
      0069F8 FF               [12] 2652 	mov	r7,a
      0069F9 BE 01 22         [24] 2653 	cjne	r6,#0x01,00284$
      0069FC BF 00 1F         [24] 2654 	cjne	r7,#0x00,00284$
                                   2655 ;	tmk_core/protocol/ch555/usb_ak820.c:374: pD0_EP0_BUF[0] = index == KEYBOARD_INTERFACE ? keyboard_idle : 0;
      0069FF EB               [12] 2656 	mov	a,r3
      006A00 4C               [12] 2657 	orl	a,r4
      006A01 70 07            [24] 2658 	jnz	00324$
      006A03 90 06 57         [24] 2659 	mov	dptr,#_keyboard_idle
      006A06 E0               [24] 2660 	movx	a,@dptr
      006A07 FF               [12] 2661 	mov	r7,a
      006A08 80 02            [24] 2662 	sjmp	00325$
      006A0A                       2663 00324$:
      006A0A 7F 00            [12] 2664 	mov	r7,#0x00
      006A0C                       2665 00325$:
      006A0C 90 10 00         [24] 2666 	mov	dptr,#0x1000
      006A0F EF               [12] 2667 	mov	a,r7
      006A10 F0               [24] 2668 	movx	@dptr,a
                                   2669 ;	tmk_core/protocol/ch555/usb_ak820.c:375: D0_EP0T_L = 1;
      006A11 90 22 08         [24] 2670 	mov	dptr,#0x2208
      006A14 74 01            [12] 2671 	mov	a,#0x01
      006A16 F0               [24] 2672 	movx	@dptr,a
                                   2673 ;	tmk_core/protocol/ch555/usb_ak820.c:376: control_phase = CTRL_STATUS_OUT;
      006A17 90 07 F4         [24] 2674 	mov	dptr,#_control_phase
      006A1A 04               [12] 2675 	inc	a
      006A1B F0               [24] 2676 	movx	@dptr,a
      006A1C 80 06            [24] 2677 	sjmp	00291$
      006A1E                       2678 00284$:
                                   2679 ;	tmk_core/protocol/ch555/usb_ak820.c:377: } else { control_stall(); return; }
                                   2680 ;	tmk_core/protocol/ch555/usb_ak820.c:379: default: control_stall(); return;
      006A1E 02 60 75         [24] 2681 	ljmp	_control_stall
      006A21                       2682 00290$:
                                   2683 ;	tmk_core/protocol/ch555/usb_ak820.c:380: }
      006A21 02 60 75         [24] 2684 	ljmp	_control_stall
      006A24                       2685 00291$:
                                   2686 ;	tmk_core/protocol/ch555/usb_ak820.c:381: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_ACK | UEP_T_RES_ACK;
      006A24 90 22 00         [24] 2687 	mov	dptr,#0x2200
      006A27 74 C0            [12] 2688 	mov	a,#0xc0
      006A29 F0               [24] 2689 	movx	@dptr,a
                                   2690 ;	tmk_core/protocol/ch555/usb_ak820.c:382: }
      006A2A 22               [24] 2691 	ret
                                   2692 ;------------------------------------------------------------
                                   2693 ;Allocation info for local variables in function 'control_out'
                                   2694 ;------------------------------------------------------------
                                   2695 ;i             Allocated with name '_control_out_i_10000_374'
                                   2696 ;------------------------------------------------------------
                                   2697 ;	tmk_core/protocol/ch555/usb_ak820.c:384: static void control_out(void) {
                                   2698 ;	-----------------------------------------
                                   2699 ;	 function control_out
                                   2700 ;	-----------------------------------------
      006A2B                       2701 _control_out:
                                   2702 ;	tmk_core/protocol/ch555/usb_ak820.c:386: if (!(D0_STATUS & bUXS_TOG_OK)) return; /* duplicate OUT is not a new request */
      006A2B 90 22 0F         [24] 2703 	mov	dptr,#0x220f
      006A2E E0               [24] 2704 	movx	a,@dptr
      006A2F 20 E6 01         [24] 2705 	jb	acc.6,00102$
      006A32 22               [24] 2706 	ret
      006A33                       2707 00102$:
                                   2708 ;	tmk_core/protocol/ch555/usb_ak820.c:387: if (control_phase == CTRL_STATUS_OUT && D0_RX_LEN == 0) {
      006A33 90 07 F4         [24] 2709 	mov	dptr,#_control_phase
      006A36 E0               [24] 2710 	movx	a,@dptr
      006A37 FF               [12] 2711 	mov	r7,a
      006A38 BF 02 12         [24] 2712 	cjne	r7,#0x02,00104$
      006A3B 90 22 0E         [24] 2713 	mov	dptr,#0x220e
      006A3E E0               [24] 2714 	movx	a,@dptr
      006A3F 70 0C            [24] 2715 	jnz	00104$
                                   2716 ;	tmk_core/protocol/ch555/usb_ak820.c:388: control_phase = CTRL_IDLE;
      006A41 90 07 F4         [24] 2717 	mov	dptr,#_control_phase
      006A44 E4               [12] 2718 	clr	a
      006A45 F0               [24] 2719 	movx	@dptr,a
                                   2720 ;	tmk_core/protocol/ch555/usb_ak820.c:389: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      006A46 90 22 00         [24] 2721 	mov	dptr,#0x2200
      006A49 74 02            [12] 2722 	mov	a,#0x02
      006A4B F0               [24] 2723 	movx	@dptr,a
                                   2724 ;	tmk_core/protocol/ch555/usb_ak820.c:390: return;
      006A4C 22               [24] 2725 	ret
      006A4D                       2726 00104$:
                                   2727 ;	tmk_core/protocol/ch555/usb_ak820.c:392: if (control_phase != CTRL_DATA_OUT || D0_RX_LEN != D0SetupLen) { control_stall(); return; }
      006A4D BF 04 19         [24] 2728 	cjne	r7,#0x04,00106$
      006A50 90 22 0E         [24] 2729 	mov	dptr,#0x220e
      006A53 E0               [24] 2730 	movx	a,@dptr
      006A54 FF               [12] 2731 	mov	r7,a
      006A55 90 07 90         [24] 2732 	mov	dptr,#_D0SetupLen
      006A58 E0               [24] 2733 	movx	a,@dptr
      006A59 FD               [12] 2734 	mov	r5,a
      006A5A A3               [24] 2735 	inc	dptr
      006A5B E0               [24] 2736 	movx	a,@dptr
      006A5C FE               [12] 2737 	mov	r6,a
      006A5D 7C 00            [12] 2738 	mov	r4,#0x00
      006A5F EF               [12] 2739 	mov	a,r7
      006A60 B5 05 06         [24] 2740 	cjne	a,ar5,00209$
      006A63 EC               [12] 2741 	mov	a,r4
      006A64 B5 06 02         [24] 2742 	cjne	a,ar6,00209$
      006A67 80 03            [24] 2743 	sjmp	00107$
      006A69                       2744 00209$:
      006A69                       2745 00106$:
      006A69 02 60 75         [24] 2746 	ljmp	_control_stall
      006A6C                       2747 00107$:
                                   2748 ;	tmk_core/protocol/ch555/usb_ak820.c:393: if (output_kind == OUTPUT_RAW && raw_state == RAW_RX) {
      006A6C 90 07 F5         [24] 2749 	mov	dptr,#_output_kind
      006A6F E0               [24] 2750 	movx	a,@dptr
      006A70 FF               [12] 2751 	mov	r7,a
      006A71 BF 01 2E         [24] 2752 	cjne	r7,#0x01,00118$
      006A74 90 07 9D         [24] 2753 	mov	dptr,#_raw_state
      006A77 E0               [24] 2754 	movx	a,@dptr
      006A78 FE               [12] 2755 	mov	r6,a
      006A79 BE 01 26         [24] 2756 	cjne	r6,#0x01,00118$
                                   2757 ;	tmk_core/protocol/ch555/usb_ak820.c:394: for (i = 0; i < RAW_EPSIZE; ++i) raw_buffer[i] = pD0_EP0_BUF[i];
      006A7C 7E 00            [12] 2758 	mov	r6,#0x00
      006A7E                       2759 00121$:
      006A7E EE               [12] 2760 	mov	a,r6
      006A7F 24 9E            [12] 2761 	add	a, #_raw_buffer
      006A81 FC               [12] 2762 	mov	r4,a
      006A82 E4               [12] 2763 	clr	a
      006A83 34 07            [12] 2764 	addc	a, #(_raw_buffer >> 8)
      006A85 FD               [12] 2765 	mov	r5,a
      006A86 8E 82            [24] 2766 	mov	dpl,r6
      006A88 74 10            [12] 2767 	mov	a,#0x10
      006A8A 24 00            [12] 2768 	add	a, #0x00
      006A8C F5 83            [12] 2769 	mov	dph,a
      006A8E E0               [24] 2770 	movx	a,@dptr
      006A8F 8C 82            [24] 2771 	mov	dpl,r4
      006A91 8D 83            [24] 2772 	mov	dph,r5
      006A93 F0               [24] 2773 	movx	@dptr,a
      006A94 0E               [12] 2774 	inc	r6
      006A95 BE 20 00         [24] 2775 	cjne	r6,#0x20,00214$
      006A98                       2776 00214$:
      006A98 40 E4            [24] 2777 	jc	00121$
                                   2778 ;	tmk_core/protocol/ch555/usb_ak820.c:395: raw_state = RAW_READY; /* publish only after the entire packet is copied */
      006A9A 90 07 9D         [24] 2779 	mov	dptr,#_raw_state
      006A9D 74 02            [12] 2780 	mov	a,#0x02
      006A9F F0               [24] 2781 	movx	@dptr,a
      006AA0 80 2B            [24] 2782 	sjmp	00119$
      006AA2                       2783 00118$:
                                   2784 ;	tmk_core/protocol/ch555/usb_ak820.c:396: } else if (output_kind == OUTPUT_LED) {
      006AA2 BF 02 0A         [24] 2785 	cjne	r7,#0x02,00115$
                                   2786 ;	tmk_core/protocol/ch555/usb_ak820.c:397: KB_USB_SetReport = pD0_EP0_BUF[0];
      006AA5 90 10 00         [24] 2787 	mov	dptr,#0x1000
      006AA8 E0               [24] 2788 	movx	a,@dptr
      006AA9 90 07 9A         [24] 2789 	mov	dptr,#_KB_USB_SetReport
      006AAC F0               [24] 2790 	movx	@dptr,a
      006AAD 80 1E            [24] 2791 	sjmp	00119$
      006AAF                       2792 00115$:
                                   2793 ;	tmk_core/protocol/ch555/usb_ak820.c:398: } else if (output_kind == OUTPUT_SHARED_LED && pD0_EP0_BUF[0] == output_report_id) {
      006AAF BF 03 18         [24] 2794 	cjne	r7,#0x03,00111$
      006AB2 90 10 00         [24] 2795 	mov	dptr,#0x1000
      006AB5 E0               [24] 2796 	movx	a,@dptr
      006AB6 FF               [12] 2797 	mov	r7,a
      006AB7 90 07 F6         [24] 2798 	mov	dptr,#_output_report_id
      006ABA E0               [24] 2799 	movx	a,@dptr
      006ABB FE               [12] 2800 	mov	r6,a
      006ABC EF               [12] 2801 	mov	a,r7
      006ABD B5 06 0A         [24] 2802 	cjne	a,ar6,00111$
                                   2803 ;	tmk_core/protocol/ch555/usb_ak820.c:399: KB_USB_SetReport = pD0_EP0_BUF[1];
      006AC0 90 10 01         [24] 2804 	mov	dptr,#0x1001
      006AC3 E0               [24] 2805 	movx	a,@dptr
      006AC4 90 07 9A         [24] 2806 	mov	dptr,#_KB_USB_SetReport
      006AC7 F0               [24] 2807 	movx	@dptr,a
      006AC8 80 03            [24] 2808 	sjmp	00119$
      006ACA                       2809 00111$:
                                   2810 ;	tmk_core/protocol/ch555/usb_ak820.c:400: } else { control_stall(); return; }
      006ACA 02 60 75         [24] 2811 	ljmp	_control_stall
      006ACD                       2812 00119$:
                                   2813 ;	tmk_core/protocol/ch555/usb_ak820.c:401: output_kind = OUTPUT_NONE;
      006ACD 90 07 F5         [24] 2814 	mov	dptr,#_output_kind
      006AD0 E4               [12] 2815 	clr	a
      006AD1 F0               [24] 2816 	movx	@dptr,a
                                   2817 ;	tmk_core/protocol/ch555/usb_ak820.c:402: D0SetupLen = 0;
      006AD2 90 07 90         [24] 2818 	mov	dptr,#_D0SetupLen
      006AD5 F0               [24] 2819 	movx	@dptr,a
      006AD6 A3               [24] 2820 	inc	dptr
      006AD7 F0               [24] 2821 	movx	@dptr,a
                                   2822 ;	tmk_core/protocol/ch555/usb_ak820.c:403: control_phase = CTRL_STATUS_IN;
      006AD8 90 07 F4         [24] 2823 	mov	dptr,#_control_phase
      006ADB 74 03            [12] 2824 	mov	a,#0x03
      006ADD F0               [24] 2825 	movx	@dptr,a
                                   2826 ;	tmk_core/protocol/ch555/usb_ak820.c:404: D0_EP0T_L = 0;
      006ADE 90 22 08         [24] 2827 	mov	dptr,#0x2208
      006AE1 E4               [12] 2828 	clr	a
      006AE2 F0               [24] 2829 	movx	@dptr,a
                                   2830 ;	tmk_core/protocol/ch555/usb_ak820.c:405: D0_EP0RES = bUEP_T_TOG | UEP_R_RES_NAK | UEP_T_RES_ACK;
      006AE3 F5 82            [12] 2831 	mov	dpl,a
      006AE5 74 48            [12] 2832 	mov	a,#0x48
      006AE7 F0               [24] 2833 	movx	@dptr,a
                                   2834 ;	tmk_core/protocol/ch555/usb_ak820.c:406: }
      006AE8 22               [24] 2835 	ret
                                   2836 ;------------------------------------------------------------
                                   2837 ;Allocation info for local variables in function 'control_in'
                                   2838 ;------------------------------------------------------------
                                   2839 ;	tmk_core/protocol/ch555/usb_ak820.c:408: static void control_in(void) {
                                   2840 ;	-----------------------------------------
                                   2841 ;	 function control_in
                                   2842 ;	-----------------------------------------
      006AE9                       2843 _control_in:
                                   2844 ;	tmk_core/protocol/ch555/usb_ak820.c:409: if (control_phase == CTRL_DATA_IN) {
      006AE9 90 07 F4         [24] 2845 	mov	dptr,#_control_phase
      006AEC E0               [24] 2846 	movx	a,@dptr
      006AED FF               [12] 2847 	mov	r7,a
      006AEE BF 01 22         [24] 2848 	cjne	r7,#0x01,00109$
                                   2849 ;	tmk_core/protocol/ch555/usb_ak820.c:410: if (D0SetupLen || control_zlp) {
      006AF1 90 07 90         [24] 2850 	mov	dptr,#_D0SetupLen
      006AF4 E0               [24] 2851 	movx	a,@dptr
      006AF5 FD               [12] 2852 	mov	r5,a
      006AF6 A3               [24] 2853 	inc	dptr
      006AF7 E0               [24] 2854 	movx	a,@dptr
      006AF8 4D               [12] 2855 	orl	a,r5
      006AF9 70 06            [24] 2856 	jnz	00101$
      006AFB 90 07 F7         [24] 2857 	mov	dptr,#_control_zlp
      006AFE E0               [24] 2858 	movx	a,@dptr
      006AFF 60 0A            [24] 2859 	jz	00102$
      006B01                       2860 00101$:
                                   2861 ;	tmk_core/protocol/ch555/usb_ak820.c:411: D0_EP0RES ^= bUEP_T_TOG;
      006B01 90 22 00         [24] 2862 	mov	dptr,#0x2200
      006B04 E0               [24] 2863 	movx	a,@dptr
      006B05 64 40            [12] 2864 	xrl	a,#0x40
      006B07 F0               [24] 2865 	movx	@dptr,a
                                   2866 ;	tmk_core/protocol/ch555/usb_ak820.c:412: control_next();
                                   2867 ;	tmk_core/protocol/ch555/usb_ak820.c:413: return;
      006B08 02 60 97         [24] 2868 	ljmp	_control_next
      006B0B                       2869 00102$:
                                   2870 ;	tmk_core/protocol/ch555/usb_ak820.c:415: control_phase = CTRL_STATUS_OUT;
      006B0B 90 07 F4         [24] 2871 	mov	dptr,#_control_phase
      006B0E 74 02            [12] 2872 	mov	a,#0x02
      006B10 F0               [24] 2873 	movx	@dptr,a
      006B11 80 18            [24] 2874 	sjmp	00110$
      006B13                       2875 00109$:
                                   2876 ;	tmk_core/protocol/ch555/usb_ak820.c:416: } else if (control_phase == CTRL_STATUS_IN) {
      006B13 BF 03 15         [24] 2877 	cjne	r7,#0x03,00110$
                                   2878 ;	tmk_core/protocol/ch555/usb_ak820.c:417: if (D0SetupReqCode == USB_SET_ADDRESS) D0_ADDR = D0SetupLen;
      006B16 90 07 8F         [24] 2879 	mov	dptr,#_D0SetupReqCode
      006B19 E0               [24] 2880 	movx	a,@dptr
      006B1A FF               [12] 2881 	mov	r7,a
      006B1B BF 05 08         [24] 2882 	cjne	r7,#0x05,00105$
      006B1E 90 07 90         [24] 2883 	mov	dptr,#_D0SetupLen
      006B21 E0               [24] 2884 	movx	a,@dptr
      006B22 90 22 07         [24] 2885 	mov	dptr,#0x2207
      006B25 F0               [24] 2886 	movx	@dptr,a
      006B26                       2887 00105$:
                                   2888 ;	tmk_core/protocol/ch555/usb_ak820.c:418: control_phase = CTRL_IDLE;
      006B26 90 07 F4         [24] 2889 	mov	dptr,#_control_phase
      006B29 E4               [12] 2890 	clr	a
      006B2A F0               [24] 2891 	movx	@dptr,a
      006B2B                       2892 00110$:
                                   2893 ;	tmk_core/protocol/ch555/usb_ak820.c:420: D0_EP0RES = bUEP_R_TOG | UEP_R_RES_ACK | UEP_T_RES_NAK;
      006B2B 90 22 00         [24] 2894 	mov	dptr,#0x2200
      006B2E 74 82            [12] 2895 	mov	a,#0x82
      006B30 F0               [24] 2896 	movx	@dptr,a
                                   2897 ;	tmk_core/protocol/ch555/usb_ak820.c:421: }
      006B31 22               [24] 2898 	ret
                                   2899 ;------------------------------------------------------------
                                   2900 ;Allocation info for local variables in function 'USB_DeviceInterrupt'
                                   2901 ;------------------------------------------------------------
                                   2902 ;status        Allocated with name '_USB_DeviceInterrupt_status_10000_398'
                                   2903 ;endpoint      Allocated with name '_USB_DeviceInterrupt_endpoint_10000_398'
                                   2904 ;------------------------------------------------------------
                                   2905 ;	tmk_core/protocol/ch555/usb_ak820.c:423: void USB_DeviceInterrupt(void) {
                                   2906 ;	-----------------------------------------
                                   2907 ;	 function USB_DeviceInterrupt
                                   2908 ;	-----------------------------------------
      006B32                       2909 _USB_DeviceInterrupt:
                                   2910 ;	tmk_core/protocol/ch555/usb_ak820.c:426: do {
      006B32                       2911 00129$:
                                   2912 ;	tmk_core/protocol/ch555/usb_ak820.c:428: if (USB_IF & bUX_IF_BUS_RST) {
      006B32 90 22 3D         [24] 2913 	mov	dptr,#0x223d
      006B35 E0               [24] 2914 	movx	a,@dptr
      006B36 30 E0 4B         [24] 2915 	jnb	acc.0,00127$
                                   2916 ;	tmk_core/protocol/ch555/usb_ak820.c:429: endpoints_reset();
      006B39 12 60 14         [24] 2917 	lcall	_endpoints_reset
                                   2918 ;	tmk_core/protocol/ch555/usb_ak820.c:430: D0_ADDR = 0;
      006B3C 90 22 07         [24] 2919 	mov	dptr,#0x2207
      006B3F E4               [12] 2920 	clr	a
      006B40 F0               [24] 2921 	movx	@dptr,a
                                   2922 ;	tmk_core/protocol/ch555/usb_ak820.c:431: D0UsbConfig = USB_EnumStatus = USB_SleepStatus = 0;
      006B41 90 07 97         [24] 2923 	mov	dptr,#_USB_SleepStatus
      006B44 F0               [24] 2924 	movx	@dptr,a
      006B45 90 07 96         [24] 2925 	mov	dptr,#_USB_EnumStatus
      006B48 F0               [24] 2926 	movx	@dptr,a
      006B49 90 07 95         [24] 2927 	mov	dptr,#_D0UsbConfig
      006B4C F0               [24] 2928 	movx	@dptr,a
                                   2929 ;	tmk_core/protocol/ch555/usb_ak820.c:432: KB_USB_SetReport = 0;
      006B4D 90 07 9A         [24] 2930 	mov	dptr,#_KB_USB_SetReport
      006B50 F0               [24] 2931 	movx	@dptr,a
                                   2932 ;	tmk_core/protocol/ch555/usb_ak820.c:433: keyboard_protocol = 1;
      006B51 90 0D BD         [24] 2933 	mov	dptr,#_keyboard_protocol
      006B54 04               [12] 2934 	inc	a
      006B55 F0               [24] 2935 	movx	@dptr,a
                                   2936 ;	tmk_core/protocol/ch555/usb_ak820.c:434: keyboard_idle = 0;
      006B56 90 06 57         [24] 2937 	mov	dptr,#_keyboard_idle
      006B59 E4               [12] 2938 	clr	a
      006B5A F0               [24] 2939 	movx	@dptr,a
                                   2940 ;	tmk_core/protocol/ch555/usb_ak820.c:435: keyboard_reset = 1;
      006B5B 90 07 BF         [24] 2941 	mov	dptr,#_keyboard_reset
      006B5E 04               [12] 2942 	inc	a
      006B5F F0               [24] 2943 	movx	@dptr,a
                                   2944 ;	tmk_core/protocol/ch555/usb_ak820.c:436: D0SetupReqCode = 0xff;
      006B60 90 07 8F         [24] 2945 	mov	dptr,#_D0SetupReqCode
      006B63 74 FF            [12] 2946 	mov	a,#0xff
      006B65 F0               [24] 2947 	movx	@dptr,a
                                   2948 ;	tmk_core/protocol/ch555/usb_ak820.c:437: D0SetupLen = 0;
      006B66 90 07 90         [24] 2949 	mov	dptr,#_D0SetupLen
      006B69 E4               [12] 2950 	clr	a
      006B6A F0               [24] 2951 	movx	@dptr,a
      006B6B A3               [24] 2952 	inc	dptr
      006B6C F0               [24] 2953 	movx	@dptr,a
                                   2954 ;	tmk_core/protocol/ch555/usb_ak820.c:438: control_phase = CTRL_IDLE;
      006B6D 90 07 F4         [24] 2955 	mov	dptr,#_control_phase
      006B70 F0               [24] 2956 	movx	@dptr,a
                                   2957 ;	tmk_core/protocol/ch555/usb_ak820.c:439: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      006B71 90 22 00         [24] 2958 	mov	dptr,#0x2200
      006B74 74 02            [12] 2959 	mov	a,#0x02
      006B76 F0               [24] 2960 	movx	@dptr,a
                                   2961 ;	tmk_core/protocol/ch555/usb_ak820.c:440: ACK_TRANSFER();
      006B77 90 22 0F         [24] 2962 	mov	dptr,#0x220f
      006B7A E4               [12] 2963 	clr	a
      006B7B F0               [24] 2964 	movx	@dptr,a
                                   2965 ;	tmk_core/protocol/ch555/usb_ak820.c:441: ACK_RESET();
      006B7C 90 22 3D         [24] 2966 	mov	dptr,#0x223d
      006B7F 04               [12] 2967 	inc	a
      006B80 F0               [24] 2968 	movx	@dptr,a
      006B81 02 6C 1C         [24] 2969 	ljmp	00130$
      006B84                       2970 00127$:
                                   2971 ;	tmk_core/protocol/ch555/usb_ak820.c:442: } else if (USB_IF & bUX_IF_D0_TRANS) {
      006B84 90 22 3D         [24] 2972 	mov	dptr,#0x223d
      006B87 E0               [24] 2973 	movx	a,@dptr
      006B88 30 E5 60         [24] 2974 	jnb	acc.5,00124$
                                   2975 ;	tmk_core/protocol/ch555/usb_ak820.c:443: status = D0_STATUS;
      006B8B 90 22 0F         [24] 2976 	mov	dptr,#0x220f
      006B8E E0               [24] 2977 	movx	a,@dptr
      006B8F FF               [12] 2978 	mov	r7,a
                                   2979 ;	tmk_core/protocol/ch555/usb_ak820.c:444: endpoint = status & MASK_UXS_ENDP;
      006B90 74 07            [12] 2980 	mov	a,#0x07
      006B92 5F               [12] 2981 	anl	a,r7
      006B93 FE               [12] 2982 	mov	r6,a
                                   2983 ;	tmk_core/protocol/ch555/usb_ak820.c:448: if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_OUT && !endpoint) {
      006B94 EF               [12] 2984 	mov	a,r7
      006B95 54 18            [12] 2985 	anl	a,#0x18
      006B97 70 08            [24] 2986 	jnz	00115$
      006B99 EE               [12] 2987 	mov	a,r6
      006B9A 70 05            [24] 2988 	jnz	00115$
                                   2989 ;	tmk_core/protocol/ch555/usb_ak820.c:449: control_out();
      006B9C 12 6A 2B         [24] 2990 	lcall	_control_out
      006B9F 80 43            [24] 2991 	sjmp	00116$
      006BA1                       2992 00115$:
                                   2993 ;	tmk_core/protocol/ch555/usb_ak820.c:450: } else if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_IN) {
      006BA1 8F 05            [24] 2994 	mov	ar5,r7
      006BA3 74 18            [12] 2995 	mov	a,#0x18
      006BA5 5D               [12] 2996 	anl	a,r5
      006BA6 FC               [12] 2997 	mov	r4,a
      006BA7 BC 10 2D         [24] 2998 	cjne	r4,#0x10,00112$
                                   2999 ;	tmk_core/protocol/ch555/usb_ak820.c:451: if (!endpoint) control_in();
      006BAA EE               [12] 3000 	mov	a,r6
      006BAB 70 05            [24] 3001 	jnz	00106$
      006BAD 12 6A E9         [24] 3002 	lcall	_control_in
      006BB0 80 32            [24] 3003 	sjmp	00116$
      006BB2                       3004 00106$:
                                   3005 ;	tmk_core/protocol/ch555/usb_ak820.c:452: else if (endpoint <= 3) {
      006BB2 EE               [12] 3006 	mov	a,r6
      006BB3 24 FC            [12] 3007 	add	a,#0xff - 0x03
      006BB5 40 2D            [24] 3008 	jc	00116$
                                   3009 ;	free result
                                   3010 ;	tmk_core/protocol/ch555/usb_ak820.c:453: EP_RESPONSE(endpoint) = (EP_RESPONSE(endpoint) & ~MASK_UEP_X_RES) | UEP_X_RES_NAK;
      006BB7 8E 04            [24] 3011 	mov	ar4,r6
      006BB9 7B 00            [12] 3012 	mov	r3,#0x00
      006BBB 74 22            [12] 3013 	mov	a,#0x22
      006BBD 2B               [12] 3014 	add	a, r3
      006BBE FB               [12] 3015 	mov	r3,a
      006BBF 8C 82            [24] 3016 	mov	dpl,r4
      006BC1 8B 83            [24] 3017 	mov	dph,r3
      006BC3 E0               [24] 3018 	movx	a,@dptr
      006BC4 FA               [12] 3019 	mov	r2,a
      006BC5 74 FC            [12] 3020 	mov	a,#0xfc
      006BC7 5A               [12] 3021 	anl	a,r2
      006BC8 44 02            [12] 3022 	orl	a,#0x02
      006BCA 8C 82            [24] 3023 	mov	dpl,r4
      006BCC 8B 83            [24] 3024 	mov	dph,r3
      006BCE F0               [24] 3025 	movx	@dptr,a
                                   3026 ;	tmk_core/protocol/ch555/usb_ak820.c:454: if (endpoint == RAW_IN_EPNUM) raw_complete();
      006BCF BE 03 12         [24] 3027 	cjne	r6,#0x03,00116$
      006BD2 12 5F F7         [24] 3028 	lcall	_raw_complete
      006BD5 80 0D            [24] 3029 	sjmp	00116$
      006BD7                       3030 00112$:
                                   3031 ;	tmk_core/protocol/ch555/usb_ak820.c:456: } else if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_FREE && (status & bUXS_SETUP_ACT)) {
      006BD7 53 05 18         [24] 3032 	anl	ar5,#0x18
      006BDA BD 18 07         [24] 3033 	cjne	r5,#0x18,00116$
      006BDD EF               [12] 3034 	mov	a,r7
      006BDE 30 E5 03         [24] 3035 	jnb	acc.5,00116$
                                   3036 ;	tmk_core/protocol/ch555/usb_ak820.c:457: control_setup();
      006BE1 12 62 8E         [24] 3037 	lcall	_control_setup
      006BE4                       3038 00116$:
                                   3039 ;	tmk_core/protocol/ch555/usb_ak820.c:459: ACK_TRANSFER();
      006BE4 90 22 0F         [24] 3040 	mov	dptr,#0x220f
      006BE7 E4               [12] 3041 	clr	a
      006BE8 F0               [24] 3042 	movx	@dptr,a
      006BE9 80 31            [24] 3043 	sjmp	00130$
      006BEB                       3044 00124$:
                                   3045 ;	tmk_core/protocol/ch555/usb_ak820.c:460: } else if (USB_IF & bUX_IF_SUSPEND) {
      006BEB 90 22 3D         [24] 3046 	mov	dptr,#0x223d
      006BEE E0               [24] 3047 	movx	a,@dptr
      006BEF 30 E2 2A         [24] 3048 	jnb	acc.2,00130$
                                   3049 ;	tmk_core/protocol/ch555/usb_ak820.c:462: ak820_os_indicator_mode = AK820_OS_NORMAL;
      006BF2 90 05 AA         [24] 3050 	mov	dptr,#_ak820_os_indicator_mode
      006BF5 E4               [12] 3051 	clr	a
      006BF6 F0               [24] 3052 	movx	@dptr,a
                                   3053 ;	tmk_core/protocol/ch555/usb_ak820.c:464: if (USB_IF & bUX_SUSPEND) USB_SleepStatus |= 2;
      006BF7 90 22 3D         [24] 3054 	mov	dptr,#0x223d
      006BFA E0               [24] 3055 	movx	a,@dptr
      006BFB 30 E3 0A         [24] 3056 	jnb	acc.3,00119$
      006BFE 90 07 97         [24] 3057 	mov	dptr,#_USB_SleepStatus
      006C01 E0               [24] 3058 	movx	a,@dptr
      006C02 43 E0 02         [24] 3059 	orl	acc,#0x02
      006C05 F0               [24] 3060 	movx	@dptr,a
      006C06 80 0E            [24] 3061 	sjmp	00120$
      006C08                       3062 00119$:
                                   3063 ;	tmk_core/protocol/ch555/usb_ak820.c:466: USB_SleepStatus &= ~2;
      006C08 90 07 97         [24] 3064 	mov	dptr,#_USB_SleepStatus
      006C0B E0               [24] 3065 	movx	a,@dptr
      006C0C 53 E0 FD         [24] 3066 	anl	acc,#0xfd
      006C0F F0               [24] 3067 	movx	@dptr,a
                                   3068 ;	tmk_core/protocol/ch555/usb_ak820.c:467: keyboard_reset = 1;
      006C10 90 07 BF         [24] 3069 	mov	dptr,#_keyboard_reset
      006C13 74 01            [12] 3070 	mov	a,#0x01
      006C15 F0               [24] 3071 	movx	@dptr,a
      006C16                       3072 00120$:
                                   3073 ;	tmk_core/protocol/ch555/usb_ak820.c:469: ACK_SUSPEND();
      006C16 90 22 3D         [24] 3074 	mov	dptr,#0x223d
      006C19 74 04            [12] 3075 	mov	a,#0x04
      006C1B F0               [24] 3076 	movx	@dptr,a
      006C1C                       3077 00130$:
                                   3078 ;	tmk_core/protocol/ch555/usb_ak820.c:471: } while (USB_IF & (bUX_IF_BUS_RST | bUX_IF_D0_TRANS | bUX_IF_SUSPEND));
      006C1C 90 22 3D         [24] 3079 	mov	dptr,#0x223d
      006C1F E0               [24] 3080 	movx	a,@dptr
      006C20 54 25            [12] 3081 	anl	a,#0x25
      006C22 60 03            [24] 3082 	jz	00242$
      006C24 02 6B 32         [24] 3083 	ljmp	00129$
      006C27                       3084 00242$:
                                   3085 ;	tmk_core/protocol/ch555/usb_ak820.c:472: }
      006C27 22               [24] 3086 	ret
                                   3087 ;------------------------------------------------------------
                                   3088 ;Allocation info for local variables in function 'USB_Device_Init'
                                   3089 ;------------------------------------------------------------
                                   3090 ;	tmk_core/protocol/ch555/usb_ak820.c:475: void USB_Device_Init(void) {
                                   3091 ;	-----------------------------------------
                                   3092 ;	 function USB_Device_Init
                                   3093 ;	-----------------------------------------
      006C28                       3094 _USB_Device_Init:
                                   3095 ;	tmk_core/protocol/ch555/usb_ak820.c:476: IE_USB = 0;
                                   3096 ;	assignBit
      006C28 C2 E9            [12] 3097 	clr	_IE_USB
                                   3098 ;	tmk_core/protocol/ch555/usb_ak820.c:477: USB_CTRL = 0;
      006C2A 90 22 3C         [24] 3099 	mov	dptr,#0x223c
      006C2D E4               [12] 3100 	clr	a
      006C2E F0               [24] 3101 	movx	@dptr,a
                                   3102 ;	tmk_core/protocol/ch555/usb_ak820.c:478: raw_state = RAW_IDLE;
      006C2F 90 07 9D         [24] 3103 	mov	dptr,#_raw_state
      006C32 F0               [24] 3104 	movx	@dptr,a
                                   3105 ;	tmk_core/protocol/ch555/usb_ak820.c:479: endpoints_reset();
      006C33 12 60 14         [24] 3106 	lcall	_endpoints_reset
                                   3107 ;	tmk_core/protocol/ch555/usb_ak820.c:480: D0_ADDR = D0UsbConfig = USB_EnumStatus = USB_SleepStatus = 0;
      006C36 90 07 97         [24] 3108 	mov	dptr,#_USB_SleepStatus
      006C39 E4               [12] 3109 	clr	a
      006C3A F0               [24] 3110 	movx	@dptr,a
      006C3B 90 07 96         [24] 3111 	mov	dptr,#_USB_EnumStatus
      006C3E F0               [24] 3112 	movx	@dptr,a
      006C3F 90 07 95         [24] 3113 	mov	dptr,#_D0UsbConfig
      006C42 F0               [24] 3114 	movx	@dptr,a
      006C43 90 22 07         [24] 3115 	mov	dptr,#0x2207
      006C46 F0               [24] 3116 	movx	@dptr,a
                                   3117 ;	tmk_core/protocol/ch555/usb_ak820.c:481: KB_USB_SetReport = KB_USB_UpStatus = MCU_Sleep_Operate = 0;
      006C47 90 07 98         [24] 3118 	mov	dptr,#_MCU_Sleep_Operate
      006C4A F0               [24] 3119 	movx	@dptr,a
      006C4B 90 07 99         [24] 3120 	mov	dptr,#_KB_USB_UpStatus
      006C4E F0               [24] 3121 	movx	@dptr,a
      006C4F 90 07 9A         [24] 3122 	mov	dptr,#_KB_USB_SetReport
      006C52 F0               [24] 3123 	movx	@dptr,a
                                   3124 ;	tmk_core/protocol/ch555/usb_ak820.c:482: keyboard_protocol = 1;
      006C53 90 0D BD         [24] 3125 	mov	dptr,#_keyboard_protocol
      006C56 04               [12] 3126 	inc	a
      006C57 F0               [24] 3127 	movx	@dptr,a
                                   3128 ;	tmk_core/protocol/ch555/usb_ak820.c:483: keyboard_idle = 0;
      006C58 90 06 57         [24] 3129 	mov	dptr,#_keyboard_idle
      006C5B E4               [12] 3130 	clr	a
      006C5C F0               [24] 3131 	movx	@dptr,a
                                   3132 ;	tmk_core/protocol/ch555/usb_ak820.c:484: keyboard_reset = 0;
      006C5D 90 07 BF         [24] 3133 	mov	dptr,#_keyboard_reset
      006C60 F0               [24] 3134 	movx	@dptr,a
                                   3135 ;	tmk_core/protocol/ch555/usb_ak820.c:485: control_phase = CTRL_IDLE;
      006C61 90 07 F4         [24] 3136 	mov	dptr,#_control_phase
      006C64 F0               [24] 3137 	movx	@dptr,a
                                   3138 ;	tmk_core/protocol/ch555/usb_ak820.c:486: D0SetupReqCode = 0xff;
      006C65 90 07 8F         [24] 3139 	mov	dptr,#_D0SetupReqCode
      006C68 14               [12] 3140 	dec	a
      006C69 F0               [24] 3141 	movx	@dptr,a
                                   3142 ;	tmk_core/protocol/ch555/usb_ak820.c:487: D0SetupLen = 0;
      006C6A 90 07 90         [24] 3143 	mov	dptr,#_D0SetupLen
      006C6D E4               [12] 3144 	clr	a
      006C6E F0               [24] 3145 	movx	@dptr,a
      006C6F A3               [24] 3146 	inc	dptr
      006C70 F0               [24] 3147 	movx	@dptr,a
                                   3148 ;	tmk_core/protocol/ch555/usb_ak820.c:488: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      006C71 90 22 00         [24] 3149 	mov	dptr,#0x2200
      006C74 74 02            [12] 3150 	mov	a,#0x02
      006C76 F0               [24] 3151 	movx	@dptr,a
                                   3152 ;	tmk_core/protocol/ch555/usb_ak820.c:489: HB_ADDR = 0x7f;
      006C77 90 22 37         [24] 3153 	mov	dptr,#0x2237
      006C7A 74 7F            [12] 3154 	mov	a,#0x7f
      006C7C F0               [24] 3155 	movx	@dptr,a
                                   3156 ;	tmk_core/protocol/ch555/usb_ak820.c:490: ACK_ALL();
      006C7D 90 22 3D         [24] 3157 	mov	dptr,#0x223d
      006C80 74 FF            [12] 3158 	mov	a,#0xff
      006C82 F0               [24] 3159 	movx	@dptr,a
                                   3160 ;	tmk_core/protocol/ch555/usb_ak820.c:491: USB_IE = bUX_IE_SUSPEND | bUX_IE_TRANSFER | bUX_IE_BUS_RST;
      006C83 90 22 3B         [24] 3161 	mov	dptr,#0x223b
      006C86 74 07            [12] 3162 	mov	a,#0x07
      006C88 F0               [24] 3163 	movx	@dptr,a
                                   3164 ;	tmk_core/protocol/ch555/usb_ak820.c:492: USB_CTRL = bUX_DP_PU_EN;
      006C89 A3               [24] 3165 	inc	dptr
      006C8A 74 80            [12] 3166 	mov	a,#0x80
      006C8C F0               [24] 3167 	movx	@dptr,a
                                   3168 ;	tmk_core/protocol/ch555/usb_ak820.c:493: IE_USB = 1;
                                   3169 ;	assignBit
      006C8D D2 E9            [12] 3170 	setb	_IE_USB
                                   3171 ;	tmk_core/protocol/ch555/usb_ak820.c:494: }
      006C8F 22               [24] 3172 	ret
                                   3173 ;------------------------------------------------------------
                                   3174 ;Allocation info for local variables in function 'USB_WakeUp_PC'
                                   3175 ;------------------------------------------------------------
                                   3176 ;saved         Allocated with name '_USB_WakeUp_PC_saved_10000_421'
                                   3177 ;i             Allocated with name '_USB_WakeUp_PC_i_30000_424'
                                   3178 ;------------------------------------------------------------
                                   3179 ;	tmk_core/protocol/ch555/usb_ak820.c:496: void USB_WakeUp_PC(void) {
                                   3180 ;	-----------------------------------------
                                   3181 ;	 function USB_WakeUp_PC
                                   3182 ;	-----------------------------------------
      006C90                       3183 _USB_WakeUp_PC:
                                   3184 ;	tmk_core/protocol/ch555/usb_ak820.c:498: if (USB_SleepStatus != 3) return;
      006C90 90 07 97         [24] 3185 	mov	dptr,#_USB_SleepStatus
      006C93 E0               [24] 3186 	movx	a,@dptr
      006C94 FF               [12] 3187 	mov	r7,a
      006C95 BF 03 22         [24] 3188 	cjne	r7,#0x03,00110$
                                   3189 ;	tmk_core/protocol/ch555/usb_ak820.c:499: saved = USB_CTRL;
      006C98 90 22 3C         [24] 3190 	mov	dptr,#0x223c
      006C9B E0               [24] 3191 	movx	a,@dptr
      006C9C FF               [12] 3192 	mov	r7,a
                                   3193 ;	tmk_core/protocol/ch555/usb_ak820.c:500: USB_CTRL ^= bUX_DP_PU_EN | bUX_DM_PU_EN;
      006C9D E0               [24] 3194 	movx	a,@dptr
      006C9E FE               [12] 3195 	mov	r6,a
      006C9F 63 06 C0         [24] 3196 	xrl	ar6,#0xc0
      006CA2 90 22 3C         [24] 3197 	mov	dptr,#0x223c
      006CA5 EE               [12] 3198 	mov	a,r6
      006CA6 F0               [24] 3199 	movx	@dptr,a
                                   3200 ;	tmk_core/protocol/ch555/usb_ak820.c:501: wait_ms(10);
      006CA7 7E 0A            [12] 3201 	mov	r6,#0x0a
      006CA9                       3202 00108$:
      006CA9 EE               [12] 3203 	mov	a,r6
      006CAA 60 09            [24] 3204 	jz	00105$
      006CAC 90 00 01         [24] 3205 	mov	dptr,#0x0001
      006CAF 12 5E 5B         [24] 3206 	lcall	_mDelaymS
      006CB2 1E               [12] 3207 	dec	r6
      006CB3 80 F4            [24] 3208 	sjmp	00108$
      006CB5                       3209 00105$:
                                   3210 ;	tmk_core/protocol/ch555/usb_ak820.c:502: USB_CTRL = saved;
      006CB5 90 22 3C         [24] 3211 	mov	dptr,#0x223c
      006CB8 EF               [12] 3212 	mov	a,r7
      006CB9 F0               [24] 3213 	movx	@dptr,a
      006CBA                       3214 00110$:
                                   3215 ;	tmk_core/protocol/ch555/usb_ak820.c:503: }
      006CBA 22               [24] 3216 	ret
                                   3217 ;------------------------------------------------------------
                                   3218 ;Allocation info for local variables in function 'ak820_usb_send'
                                   3219 ;------------------------------------------------------------
                                   3220 ;sloc0         Allocated with name '_ak820_usb_send_sloc0_1_0'
                                   3221 ;sloc1         Allocated with name '_ak820_usb_send_sloc1_1_0'
                                   3222 ;report        Allocated with name '_ak820_usb_send_PARM_2'
                                   3223 ;length        Allocated with name '_ak820_usb_send_PARM_3'
                                   3224 ;endpoint      Allocated with name '_ak820_usb_send_endpoint_10000_426'
                                   3225 ;saved_ea      Allocated with name '_ak820_usb_send_saved_ea_10000_427'
                                   3226 ;i             Allocated with name '_ak820_usb_send_i_10000_427'
                                   3227 ;timeout       Allocated with name '_ak820_usb_send_timeout_10000_427'
                                   3228 ;offset        Allocated with name '_ak820_usb_send_offset_10000_427'
                                   3229 ;report_id     Allocated with name '_ak820_usb_send_report_id_10000_427'
                                   3230 ;i             Allocated with name '_ak820_usb_send_i_30000_439'
                                   3231 ;------------------------------------------------------------
                                   3232 ;	tmk_core/protocol/ch555/usb_ak820.c:505: bool ak820_usb_send(uint8_t endpoint, const uint8_t __xdata *report, uint8_t length) {
                                   3233 ;	-----------------------------------------
                                   3234 ;	 function ak820_usb_send
                                   3235 ;	-----------------------------------------
      006CBB                       3236 _ak820_usb_send:
      006CBB E5 82            [12] 3237 	mov	a,dpl
      006CBD 90 08 04         [24] 3238 	mov	dptr,#_ak820_usb_send_endpoint_10000_426
      006CC0 F0               [24] 3239 	movx	@dptr,a
                                   3240 ;	tmk_core/protocol/ch555/usb_ak820.c:509: uint8_t offset = SNAPSHOT_SIZE;
      006CC1 90 08 05         [24] 3241 	mov	dptr,#_ak820_usb_send_offset_10000_427
      006CC4 74 34            [12] 3242 	mov	a,#0x34
      006CC6 F0               [24] 3243 	movx	@dptr,a
                                   3244 ;	tmk_core/protocol/ch555/usb_ak820.c:511: if (endpoint < 1 || endpoint > 3 || length > 64 || !USB_EnumStatus) return false;
      006CC7 90 08 04         [24] 3245 	mov	dptr,#_ak820_usb_send_endpoint_10000_426
      006CCA E0               [24] 3246 	movx	a,@dptr
      006CCB FF               [12] 3247 	mov	r7,a
      006CCC BF 01 00         [24] 3248 	cjne	r7,#0x01,00306$
      006CCF                       3249 00306$:
      006CCF 40 14            [24] 3250 	jc	00101$
      006CD1 EF               [12] 3251 	mov	a,r7
      006CD2 24 FC            [12] 3252 	add	a,#0xff - 0x03
      006CD4 40 0F            [24] 3253 	jc	00101$
                                   3254 ;	free result
      006CD6 90 08 03         [24] 3255 	mov	dptr,#_ak820_usb_send_PARM_3
      006CD9 E0               [24] 3256 	movx	a,@dptr
      006CDA FE               [12] 3257 	mov  r6,a
      006CDB 24 BF            [12] 3258 	add	a,#0xff - 0x40
      006CDD 40 06            [24] 3259 	jc	00101$
                                   3260 ;	free result
      006CDF 90 07 96         [24] 3261 	mov	dptr,#_USB_EnumStatus
      006CE2 E0               [24] 3262 	movx	a,@dptr
      006CE3 70 04            [24] 3263 	jnz	00102$
      006CE5                       3264 00101$:
      006CE5 75 82 00         [24] 3265 	mov	dpl, #0x00
      006CE8 22               [24] 3266 	ret
      006CE9                       3267 00102$:
                                   3268 ;	tmk_core/protocol/ch555/usb_ak820.c:512: if (endpoint == KEYBOARD_IN_EPNUM) {
      006CE9 BF 01 10         [24] 3269 	cjne	r7,#0x01,00118$
                                   3270 ;	tmk_core/protocol/ch555/usb_ak820.c:513: if (length != KEYBOARD_EPSIZE) return false;
      006CEC BE 08 02         [24] 3271 	cjne	r6,#0x08,00313$
      006CEF 80 04            [24] 3272 	sjmp	00107$
      006CF1                       3273 00313$:
      006CF1 75 82 00         [24] 3274 	mov	dpl, #0x00
      006CF4 22               [24] 3275 	ret
      006CF5                       3276 00107$:
                                   3277 ;	tmk_core/protocol/ch555/usb_ak820.c:514: offset = SNAPSHOT_KEYBOARD;
      006CF5 90 08 05         [24] 3278 	mov	dptr,#_ak820_usb_send_offset_10000_427
      006CF8 E4               [12] 3279 	clr	a
      006CF9 F0               [24] 3280 	movx	@dptr,a
      006CFA 80 3C            [24] 3281 	sjmp	00119$
      006CFC                       3282 00118$:
                                   3283 ;	tmk_core/protocol/ch555/usb_ak820.c:515: } else if (endpoint == SHARED_IN_EPNUM) {
      006CFC BF 02 30         [24] 3284 	cjne	r7,#0x02,00115$
                                   3285 ;	tmk_core/protocol/ch555/usb_ak820.c:516: report_id = report[0];
      006CFF 90 08 01         [24] 3286 	mov	dptr,#_ak820_usb_send_PARM_2
      006D02 E0               [24] 3287 	movx	a,@dptr
      006D03 FD               [12] 3288 	mov	r5,a
      006D04 A3               [24] 3289 	inc	dptr
      006D05 E0               [24] 3290 	movx	a,@dptr
      006D06 FF               [12] 3291 	mov	r7,a
      006D07 8D 82            [24] 3292 	mov	dpl,r5
      006D09 8F 83            [24] 3293 	mov	dph,r7
      006D0B E0               [24] 3294 	movx	a,@dptr
      006D0C FF               [12] 3295 	mov	r7,a
                                   3296 ;	tmk_core/protocol/ch555/usb_ak820.c:517: if (report_id >= sizeof(shared_lengths) || !shared_lengths[report_id] || length != shared_lengths[report_id]) return false;
      006D0D BF 07 00         [24] 3297 	cjne	r7,#0x07,00316$
      006D10                       3298 00316$:
      006D10 50 0E            [24] 3299 	jnc	00108$
      006D12 EF               [12] 3300 	mov	a,r7
      006D13 90 BE 6A         [24] 3301 	mov	dptr,#_shared_lengths
      006D16 93               [24] 3302 	movc	a,@a+dptr
      006D17 FD               [12] 3303 	mov	r5,a
      006D18 60 06            [24] 3304 	jz	00108$
      006D1A EE               [12] 3305 	mov	a,r6
      006D1B B5 05 02         [24] 3306 	cjne	a,ar5,00319$
      006D1E 80 04            [24] 3307 	sjmp	00109$
      006D20                       3308 00319$:
      006D20                       3309 00108$:
      006D20 75 82 00         [24] 3310 	mov	dpl, #0x00
      006D23 22               [24] 3311 	ret
      006D24                       3312 00109$:
                                   3313 ;	tmk_core/protocol/ch555/usb_ak820.c:518: offset = shared_offsets[report_id];
      006D24 EF               [12] 3314 	mov	a,r7
      006D25 90 BE 63         [24] 3315 	mov	dptr,#_shared_offsets
      006D28 93               [24] 3316 	movc	a,@a+dptr
      006D29 90 08 05         [24] 3317 	mov	dptr,#_ak820_usb_send_offset_10000_427
      006D2C F0               [24] 3318 	movx	@dptr,a
      006D2D 80 09            [24] 3319 	sjmp	00119$
      006D2F                       3320 00115$:
                                   3321 ;	tmk_core/protocol/ch555/usb_ak820.c:519: } else if (length != RAW_EPSIZE) return false;
      006D2F BE 20 02         [24] 3322 	cjne	r6,#0x20,00320$
      006D32 80 04            [24] 3323 	sjmp	00119$
      006D34                       3324 00320$:
      006D34 75 82 00         [24] 3325 	mov	dpl, #0x00
      006D37 22               [24] 3326 	ret
      006D38                       3327 00119$:
                                   3328 ;	tmk_core/protocol/ch555/usb_ak820.c:520: if (USB_SleepStatus & 2) { USB_WakeUp_PC(); return false; }
      006D38 90 07 97         [24] 3329 	mov	dptr,#_USB_SleepStatus
      006D3B E0               [24] 3330 	movx	a,@dptr
      006D3C 30 E1 07         [24] 3331 	jnb	acc.1,00184$
      006D3F 12 6C 90         [24] 3332 	lcall	_USB_WakeUp_PC
      006D42 75 82 00         [24] 3333 	mov	dpl, #0x00
      006D45 22               [24] 3334 	ret
                                   3335 ;	tmk_core/protocol/ch555/usb_ak820.c:521: while ((EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_ACK && timeout--) wait_us(40);
      006D46                       3336 00184$:
      006D46 7F FA            [12] 3337 	mov	r7,#0xfa
      006D48                       3338 00127$:
      006D48 90 08 04         [24] 3339 	mov	dptr,#_ak820_usb_send_endpoint_10000_426
      006D4B E0               [24] 3340 	movx	a,@dptr
      006D4C FC               [12] 3341 	mov	r4,a
      006D4D 7D 00            [12] 3342 	mov	r5,#0x00
      006D4F 8C 02            [24] 3343 	mov	ar2,r4
      006D51 74 22            [12] 3344 	mov	a,#0x22
      006D53 2D               [12] 3345 	add	a, r5
      006D54 FB               [12] 3346 	mov	r3,a
      006D55 8A 82            [24] 3347 	mov	dpl,r2
      006D57 8B 83            [24] 3348 	mov	dph,r3
      006D59 E0               [24] 3349 	movx	a,@dptr
      006D5A 54 03            [12] 3350 	anl	a,#0x03
      006D5C 70 14            [24] 3351 	jnz	00129$
      006D5E 8F 03            [24] 3352 	mov	ar3,r7
      006D60 1F               [12] 3353 	dec	r7
      006D61 EB               [12] 3354 	mov	a,r3
      006D62 60 0E            [24] 3355 	jz	00129$
      006D64 7B 28            [12] 3356 	mov	r3,#0x28
      006D66                       3357 00141$:
      006D66 EB               [12] 3358 	mov	a,r3
      006D67 60 DF            [24] 3359 	jz	00127$
      006D69 90 00 01         [24] 3360 	mov	dptr,#0x0001
      006D6C 12 5E 17         [24] 3361 	lcall	_mDelayuS
      006D6F 1B               [12] 3362 	dec	r3
      006D70 80 F4            [24] 3363 	sjmp	00141$
      006D72                       3364 00129$:
                                   3365 ;	tmk_core/protocol/ch555/usb_ak820.c:522: saved_ea = EA;
      006D72 A2 AF            [12] 3366 	mov	c,_EA
      006D74 E4               [12] 3367 	clr	a
      006D75 33               [12] 3368 	rlc	a
      006D76 FF               [12] 3369 	mov	r7,a
                                   3370 ;	tmk_core/protocol/ch555/usb_ak820.c:523: EA = 0;
                                   3371 ;	assignBit
      006D77 C2 AF            [12] 3372 	clr	_EA
                                   3373 ;	tmk_core/protocol/ch555/usb_ak820.c:524: if (!USB_EnumStatus || (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) != UEP_X_RES_NAK ||
      006D79 90 07 96         [24] 3374 	mov	dptr,#_USB_EnumStatus
      006D7C E0               [24] 3375 	movx	a,@dptr
      006D7D 60 25            [24] 3376 	jz	00130$
      006D7F 90 08 04         [24] 3377 	mov	dptr,#_ak820_usb_send_endpoint_10000_426
      006D82 E0               [24] 3378 	movx	a,@dptr
      006D83 FB               [12] 3379 	mov	r3,a
      006D84 F9               [12] 3380 	mov	r1,a
      006D85 7A 00            [12] 3381 	mov	r2,#0x00
      006D87 74 22            [12] 3382 	mov	a,#0x22
      006D89 2A               [12] 3383 	add	a, r2
      006D8A FA               [12] 3384 	mov	r2,a
      006D8B 89 82            [24] 3385 	mov	dpl,r1
      006D8D 8A 83            [24] 3386 	mov	dph,r2
      006D8F E0               [24] 3387 	movx	a,@dptr
      006D90 FA               [12] 3388 	mov	r2,a
      006D91 53 02 03         [24] 3389 	anl	ar2,#0x03
      006D94 BA 02 0D         [24] 3390 	cjne	r2,#0x02,00130$
                                   3391 ;	tmk_core/protocol/ch555/usb_ak820.c:525: (endpoint == RAW_IN_EPNUM && raw_state != RAW_WORK)) { EA = saved_ea; return false; }
      006D97 BB 03 13         [24] 3392 	cjne	r3,#0x03,00192$
      006D9A 90 07 9D         [24] 3393 	mov	dptr,#_raw_state
      006D9D E0               [24] 3394 	movx	a,@dptr
      006D9E FB               [12] 3395 	mov	r3,a
      006D9F BB 03 02         [24] 3396 	cjne	r3,#0x03,00331$
      006DA2 80 09            [24] 3397 	sjmp	00192$
      006DA4                       3398 00331$:
      006DA4                       3399 00130$:
                                   3400 ;	assignBit
      006DA4 EF               [12] 3401 	mov	a,r7
      006DA5 24 FF            [12] 3402 	add	a,#0xff
      006DA7 92 AF            [24] 3403 	mov	_EA,c
      006DA9 75 82 00         [24] 3404 	mov	dpl, #0x00
      006DAC 22               [24] 3405 	ret
                                   3406 ;	tmk_core/protocol/ch555/usb_ak820.c:526: for (i = 0; i < length; ++i) {
      006DAD                       3407 00192$:
      006DAD 7B 00            [12] 3408 	mov	r3,#0x00
      006DAF                       3409 00144$:
      006DAF C3               [12] 3410 	clr	c
      006DB0 EB               [12] 3411 	mov	a,r3
      006DB1 9E               [12] 3412 	subb	a,r6
      006DB2 50 67            [24] 3413 	jnc	00137$
                                   3414 ;	tmk_core/protocol/ch555/usb_ak820.c:527: pUSB_BUF_DEV0[((uint16_t)endpoint << 6) + i] = report[i];
      006DB4 C0 07            [24] 3415 	push	ar7
      006DB6 90 08 04         [24] 3416 	mov	dptr,#_ak820_usb_send_endpoint_10000_426
      006DB9 E0               [24] 3417 	movx	a,@dptr
      006DBA F9               [12] 3418 	mov	r1,a
      006DBB E4               [12] 3419 	clr	a
      006DBC C3               [12] 3420 	clr	c
      006DBD C9               [12] 3421 	xch	a,r1
      006DBE 13               [12] 3422 	rrc	a
      006DBF C9               [12] 3423 	xch	a,r1
      006DC0 13               [12] 3424 	rrc	a
      006DC1 A2 E0            [12] 3425 	mov	c,acc.0
      006DC3 C9               [12] 3426 	xch	a,r1
      006DC4 13               [12] 3427 	rrc	a
      006DC5 C9               [12] 3428 	xch	a,r1
      006DC6 13               [12] 3429 	rrc	a
      006DC7 C9               [12] 3430 	xch	a,r1
      006DC8 FA               [12] 3431 	mov	r2,a
      006DC9 8B 00            [24] 3432 	mov	ar0,r3
      006DCB 7F 00            [12] 3433 	mov	r7,#0x00
      006DCD E8               [12] 3434 	mov	a,r0
      006DCE 29               [12] 3435 	add	a, r1
      006DCF F9               [12] 3436 	mov	r1,a
      006DD0 EF               [12] 3437 	mov	a,r7
      006DD1 3A               [12] 3438 	addc	a, r2
      006DD2 24 10            [12] 3439 	add	a,#0x10
      006DD4 FA               [12] 3440 	mov	r2,a
      006DD5 90 08 01         [24] 3441 	mov	dptr,#_ak820_usb_send_PARM_2
      006DD8 E0               [24] 3442 	movx	a,@dptr
      006DD9 F8               [12] 3443 	mov	r0,a
      006DDA A3               [24] 3444 	inc	dptr
      006DDB E0               [24] 3445 	movx	a,@dptr
      006DDC FF               [12] 3446 	mov	r7,a
      006DDD EB               [12] 3447 	mov	a,r3
      006DDE 28               [12] 3448 	add	a, r0
      006DDF F5 1B            [12] 3449 	mov	_ak820_usb_send_sloc0_1_0,a
      006DE1 E4               [12] 3450 	clr	a
      006DE2 3F               [12] 3451 	addc	a, r7
      006DE3 F5 1C            [12] 3452 	mov	(_ak820_usb_send_sloc0_1_0 + 1),a
      006DE5 85 1B 82         [24] 3453 	mov	dpl,_ak820_usb_send_sloc0_1_0
      006DE8 85 1C 83         [24] 3454 	mov	dph,(_ak820_usb_send_sloc0_1_0 + 1)
      006DEB E0               [24] 3455 	movx	a,@dptr
      006DEC 89 82            [24] 3456 	mov	dpl,r1
      006DEE 8A 83            [24] 3457 	mov	dph,r2
      006DF0 F0               [24] 3458 	movx	@dptr,a
                                   3459 ;	tmk_core/protocol/ch555/usb_ak820.c:528: if (offset != SNAPSHOT_SIZE) input_snapshot[offset + i] = report[i];
      006DF1 90 08 05         [24] 3460 	mov	dptr,#_ak820_usb_send_offset_10000_427
      006DF4 E0               [24] 3461 	movx	a,@dptr
      006DF5 F5 1D            [12] 3462 	mov	_ak820_usb_send_sloc1_1_0,a
      006DF7 74 34            [12] 3463 	mov	a,#0x34
      006DF9 B5 1D 04         [24] 3464 	cjne	a,_ak820_usb_send_sloc1_1_0,00333$
      006DFC D0 07            [24] 3465 	pop	ar7
      006DFE 80 18            [24] 3466 	sjmp	00145$
      006E00                       3467 00333$:
      006E00 D0 07            [24] 3468 	pop	ar7
      006E02 EB               [12] 3469 	mov	a,r3
      006E03 25 1D            [12] 3470 	add	a, _ak820_usb_send_sloc1_1_0
      006E05 24 C0            [12] 3471 	add	a, #_input_snapshot
      006E07 F9               [12] 3472 	mov	r1,a
      006E08 E4               [12] 3473 	clr	a
      006E09 34 07            [12] 3474 	addc	a,#(_input_snapshot >> 8)
      006E0B FA               [12] 3475 	mov	r2,a
      006E0C 85 1B 82         [24] 3476 	mov	dpl,_ak820_usb_send_sloc0_1_0
      006E0F 85 1C 83         [24] 3477 	mov	dph,(_ak820_usb_send_sloc0_1_0 + 1)
      006E12 E0               [24] 3478 	movx	a,@dptr
      006E13 89 82            [24] 3479 	mov	dpl,r1
      006E15 8A 83            [24] 3480 	mov	dph,r2
      006E17 F0               [24] 3481 	movx	@dptr,a
      006E18                       3482 00145$:
                                   3483 ;	tmk_core/protocol/ch555/usb_ak820.c:526: for (i = 0; i < length; ++i) {
      006E18 0B               [12] 3484 	inc	r3
      006E19 80 94            [24] 3485 	sjmp	00144$
      006E1B                       3486 00137$:
                                   3487 ;	tmk_core/protocol/ch555/usb_ak820.c:530: EP_LENGTH(endpoint) = length;
      006E1B 90 08 04         [24] 3488 	mov	dptr,#_ak820_usb_send_endpoint_10000_426
      006E1E E0               [24] 3489 	movx	a,@dptr
      006E1F FB               [12] 3490 	mov	r3,a
      006E20 F9               [12] 3491 	mov	r1,a
      006E21 7A 00            [12] 3492 	mov	r2,#0x00
      006E23 74 08            [12] 3493 	mov	a,#0x08
      006E25 29               [12] 3494 	add	a, r1
      006E26 F9               [12] 3495 	mov	r1,a
      006E27 74 22            [12] 3496 	mov	a,#0x22
      006E29 3A               [12] 3497 	addc	a, r2
      006E2A FA               [12] 3498 	mov	r2,a
      006E2B 89 82            [24] 3499 	mov	dpl,r1
      006E2D 8A 83            [24] 3500 	mov	dph,r2
      006E2F EE               [12] 3501 	mov	a,r6
      006E30 F0               [24] 3502 	movx	@dptr,a
                                   3503 ;	tmk_core/protocol/ch555/usb_ak820.c:531: if (endpoint == RAW_IN_EPNUM) raw_state = RAW_TX_ACTIVE;
      006E31 BB 03 06         [24] 3504 	cjne	r3,#0x03,00139$
      006E34 90 07 9D         [24] 3505 	mov	dptr,#_raw_state
      006E37 74 04            [12] 3506 	mov	a,#0x04
      006E39 F0               [24] 3507 	movx	@dptr,a
      006E3A                       3508 00139$:
                                   3509 ;	tmk_core/protocol/ch555/usb_ak820.c:532: EP_RESPONSE(endpoint) = (EP_RESPONSE(endpoint) & ~MASK_UEP_X_RES) | UEP_X_RES_ACK;
      006E3A 74 22            [12] 3510 	mov	a,#0x22
      006E3C 2D               [12] 3511 	add	a, r5
      006E3D FD               [12] 3512 	mov	r5,a
      006E3E 8C 82            [24] 3513 	mov	dpl,r4
      006E40 8D 83            [24] 3514 	mov	dph,r5
      006E42 E0               [24] 3515 	movx	a,@dptr
      006E43 FE               [12] 3516 	mov	r6,a
      006E44 53 06 FC         [24] 3517 	anl	ar6,#0xfc
      006E47 8C 82            [24] 3518 	mov	dpl,r4
      006E49 8D 83            [24] 3519 	mov	dph,r5
      006E4B EE               [12] 3520 	mov	a,r6
      006E4C F0               [24] 3521 	movx	@dptr,a
                                   3522 ;	tmk_core/protocol/ch555/usb_ak820.c:533: EA = saved_ea;
                                   3523 ;	assignBit
      006E4D EF               [12] 3524 	mov	a,r7
      006E4E 24 FF            [12] 3525 	add	a,#0xff
      006E50 92 AF            [24] 3526 	mov	_EA,c
                                   3527 ;	tmk_core/protocol/ch555/usb_ak820.c:534: return true;
      006E52 75 82 01         [24] 3528 	mov	dpl, #0x01
                                   3529 ;	tmk_core/protocol/ch555/usb_ak820.c:535: }
      006E55 22               [24] 3530 	ret
                                   3531 ;------------------------------------------------------------
                                   3532 ;Allocation info for local variables in function 'ak820_usb_try_send'
                                   3533 ;------------------------------------------------------------
                                   3534 ;report        Allocated with name '_ak820_usb_try_send_PARM_2'
                                   3535 ;length        Allocated with name '_ak820_usb_try_send_PARM_3'
                                   3536 ;endpoint      Allocated with name '_ak820_usb_try_send_endpoint_10000_447'
                                   3537 ;saved_ea      Allocated with name '_ak820_usb_try_send_saved_ea_10000_448'
                                   3538 ;sent          Allocated with name '_ak820_usb_try_send_sent_10000_448'
                                   3539 ;------------------------------------------------------------
                                   3540 ;	tmk_core/protocol/ch555/usb_ak820.c:537: bool ak820_usb_try_send(uint8_t endpoint, const uint8_t __xdata *report, uint8_t length) {
                                   3541 ;	-----------------------------------------
                                   3542 ;	 function ak820_usb_try_send
                                   3543 ;	-----------------------------------------
      006E56                       3544 _ak820_usb_try_send:
      006E56 E5 82            [12] 3545 	mov	a,dpl
      006E58 90 08 09         [24] 3546 	mov	dptr,#_ak820_usb_try_send_endpoint_10000_447
      006E5B F0               [24] 3547 	movx	@dptr,a
                                   3548 ;	tmk_core/protocol/ch555/usb_ak820.c:538: uint8_t saved_ea = EA;
                                   3549 ;	assignBit
      006E5C A2 AF            [12] 3550 	mov	c,_EA
      006E5E 92 1B            [24] 3551 	mov	_ak820_usb_try_send_sloc0_1_0,c
                                   3552 ;	tmk_core/protocol/ch555/usb_ak820.c:539: bool sent = false;
      006E60 90 08 0A         [24] 3553 	mov	dptr,#_ak820_usb_try_send_sent_10000_448
      006E63 E4               [12] 3554 	clr	a
      006E64 F0               [24] 3555 	movx	@dptr,a
                                   3556 ;	tmk_core/protocol/ch555/usb_ak820.c:540: EA = 0;
                                   3557 ;	assignBit
      006E65 C2 AF            [12] 3558 	clr	_EA
                                   3559 ;	tmk_core/protocol/ch555/usb_ak820.c:544: if (endpoint >= 1 && endpoint <= 2 && USB_EnumStatus &&
      006E67 90 08 09         [24] 3560 	mov	dptr,#_ak820_usb_try_send_endpoint_10000_447
      006E6A E0               [24] 3561 	movx	a,@dptr
      006E6B FF               [12] 3562 	mov	r7,a
      006E6C BF 01 00         [24] 3563 	cjne	r7,#0x01,00152$
      006E6F                       3564 00152$:
      006E6F 40 4E            [24] 3565 	jc	00102$
      006E71 EF               [12] 3566 	mov	a,r7
      006E72 24 FD            [12] 3567 	add	a,#0xff - 0x02
      006E74 40 49            [24] 3568 	jc	00102$
                                   3569 ;	free result
      006E76 90 07 96         [24] 3570 	mov	dptr,#_USB_EnumStatus
      006E79 E0               [24] 3571 	movx	a,@dptr
      006E7A 60 43            [24] 3572 	jz	00102$
                                   3573 ;	tmk_core/protocol/ch555/usb_ak820.c:545: !(USB_SleepStatus & 2) && !keyboard_reset &&
      006E7C 90 07 97         [24] 3574 	mov	dptr,#_USB_SleepStatus
      006E7F E0               [24] 3575 	movx	a,@dptr
      006E80 20 E1 3C         [24] 3576 	jb	acc.1,00102$
      006E83 90 07 BF         [24] 3577 	mov	dptr,#_keyboard_reset
      006E86 E0               [24] 3578 	movx	a,@dptr
                                   3579 ;	tmk_core/protocol/ch555/usb_ak820.c:546: (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_NAK) {
      006E87 70 36            [24] 3580 	jnz	00102$
      006E89 8F 06            [24] 3581 	mov	ar6,r7
      006E8B 24 22            [12] 3582 	add	a,#0x22
      006E8D FD               [12] 3583 	mov	r5,a
      006E8E 8E 82            [24] 3584 	mov	dpl,r6
      006E90 8D 83            [24] 3585 	mov	dph,r5
      006E92 E0               [24] 3586 	movx	a,@dptr
      006E93 FE               [12] 3587 	mov	r6,a
      006E94 53 06 03         [24] 3588 	anl	ar6,#0x03
      006E97 BE 02 25         [24] 3589 	cjne	r6,#0x02,00102$
                                   3590 ;	tmk_core/protocol/ch555/usb_ak820.c:547: sent = ak820_usb_send(endpoint, report, length);
      006E9A 90 08 06         [24] 3591 	mov	dptr,#_ak820_usb_try_send_PARM_2
      006E9D E0               [24] 3592 	movx	a,@dptr
      006E9E FD               [12] 3593 	mov	r5,a
      006E9F A3               [24] 3594 	inc	dptr
      006EA0 E0               [24] 3595 	movx	a,@dptr
      006EA1 FE               [12] 3596 	mov	r6,a
      006EA2 90 08 08         [24] 3597 	mov	dptr,#_ak820_usb_try_send_PARM_3
      006EA5 E0               [24] 3598 	movx	a,@dptr
      006EA6 FC               [12] 3599 	mov	r4,a
      006EA7 90 08 01         [24] 3600 	mov	dptr,#_ak820_usb_send_PARM_2
      006EAA ED               [12] 3601 	mov	a,r5
      006EAB F0               [24] 3602 	movx	@dptr,a
      006EAC EE               [12] 3603 	mov	a,r6
      006EAD A3               [24] 3604 	inc	dptr
      006EAE F0               [24] 3605 	movx	@dptr,a
      006EAF 90 08 03         [24] 3606 	mov	dptr,#_ak820_usb_send_PARM_3
      006EB2 EC               [12] 3607 	mov	a,r4
      006EB3 F0               [24] 3608 	movx	@dptr,a
      006EB4 8F 82            [24] 3609 	mov	dpl, r7
      006EB6 12 6C BB         [24] 3610 	lcall	_ak820_usb_send
      006EB9 E5 82            [12] 3611 	mov	a, dpl
      006EBB 90 08 0A         [24] 3612 	mov	dptr,#_ak820_usb_try_send_sent_10000_448
      006EBE F0               [24] 3613 	movx	@dptr,a
      006EBF                       3614 00102$:
                                   3615 ;	tmk_core/protocol/ch555/usb_ak820.c:549: EA = saved_ea;
                                   3616 ;	assignBit
      006EBF A2 1B            [12] 3617 	mov	c,_ak820_usb_try_send_sloc0_1_0
      006EC1 92 AF            [24] 3618 	mov	_EA,c
                                   3619 ;	tmk_core/protocol/ch555/usb_ak820.c:550: return sent;
      006EC3 90 08 0A         [24] 3620 	mov	dptr,#_ak820_usb_try_send_sent_10000_448
      006EC6 E0               [24] 3621 	movx	a,@dptr
                                   3622 ;	tmk_core/protocol/ch555/usb_ak820.c:551: }
      006EC7 F5 82            [12] 3623 	mov	dpl,a
      006EC9 22               [24] 3624 	ret
                                   3625 ;------------------------------------------------------------
                                   3626 ;Allocation info for local variables in function 'raw_request_is_nonpersistent'
                                   3627 ;------------------------------------------------------------
                                   3628 ;	tmk_core/protocol/ch555/usb_ak820.c:556: static bool raw_request_is_nonpersistent(void) {
                                   3629 ;	-----------------------------------------
                                   3630 ;	 function raw_request_is_nonpersistent
                                   3631 ;	-----------------------------------------
      006ECA                       3632 _raw_request_is_nonpersistent:
                                   3633 ;	tmk_core/protocol/ch555/usb_ak820.c:557: switch (raw_buffer[0]) {
      006ECA 90 07 9E         [24] 3634 	mov	dptr,#_raw_buffer
      006ECD E0               [24] 3635 	movx	a,@dptr
      006ECE FF               [12] 3636 	mov	r7,a
      006ECF BF 01 02         [24] 3637 	cjne	r7,#0x01,00302$
      006ED2 80 35            [24] 3638 	sjmp	00108$
      006ED4                       3639 00302$:
      006ED4 BF 02 02         [24] 3640 	cjne	r7,#0x02,00303$
      006ED7 80 34            [24] 3641 	sjmp	00109$
      006ED9                       3642 00303$:
      006ED9 BF 04 02         [24] 3643 	cjne	r7,#0x04,00304$
      006EDC 80 2B            [24] 3644 	sjmp	00108$
      006EDE                       3645 00304$:
      006EDE BF 08 02         [24] 3646 	cjne	r7,#0x08,00305$
      006EE1 80 47            [24] 3647 	sjmp	00116$
      006EE3                       3648 00305$:
      006EE3 BF 0B 02         [24] 3649 	cjne	r7,#0x0b,00306$
      006EE6 80 21            [24] 3650 	sjmp	00108$
      006EE8                       3651 00306$:
      006EE8 BF 0C 02         [24] 3652 	cjne	r7,#0x0c,00307$
      006EEB 80 1C            [24] 3653 	sjmp	00108$
      006EED                       3654 00307$:
      006EED BF 0D 02         [24] 3655 	cjne	r7,#0x0d,00308$
      006EF0 80 17            [24] 3656 	sjmp	00108$
      006EF2                       3657 00308$:
      006EF2 BF 0E 02         [24] 3658 	cjne	r7,#0x0e,00309$
      006EF5 80 12            [24] 3659 	sjmp	00108$
      006EF7                       3660 00309$:
      006EF7 BF 11 02         [24] 3661 	cjne	r7,#0x11,00310$
      006EFA 80 0D            [24] 3662 	sjmp	00108$
      006EFC                       3663 00310$:
      006EFC BF 12 02         [24] 3664 	cjne	r7,#0x12,00311$
      006EFF 80 08            [24] 3665 	sjmp	00108$
      006F01                       3666 00311$:
      006F01 BF FE 02         [24] 3667 	cjne	r7,#0xfe,00312$
      006F04 80 46            [24] 3668 	sjmp	00124$
      006F06                       3669 00312$:
      006F06 02 6F A1         [24] 3670 	ljmp	00144$
                                   3671 ;	tmk_core/protocol/ch555/usb_ak820.c:565: case id_bootloader_jump:
      006F09                       3672 00108$:
                                   3673 ;	tmk_core/protocol/ch555/usb_ak820.c:566: return true;
      006F09 75 82 01         [24] 3674 	mov	dpl, #0x01
      006F0C 22               [24] 3675 	ret
                                   3676 ;	tmk_core/protocol/ch555/usb_ak820.c:567: case id_get_keyboard_value:
      006F0D                       3677 00109$:
                                   3678 ;	tmk_core/protocol/ch555/usb_ak820.c:568: switch (raw_buffer[1]) {
      006F0D 12 72 B0         [24] 3679 	lcall	_ak820_outline_0161
      006F10 BF 01 02         [24] 3680 	cjne	r7,#0x01,00313$
      006F13 80 0D            [24] 3681 	sjmp	00113$
      006F15                       3682 00313$:
      006F15 BF 02 02         [24] 3683 	cjne	r7,#0x02,00314$
      006F18 80 08            [24] 3684 	sjmp	00113$
      006F1A                       3685 00314$:
      006F1A BF 03 02         [24] 3686 	cjne	r7,#0x03,00315$
      006F1D 80 03            [24] 3687 	sjmp	00113$
      006F1F                       3688 00315$:
      006F1F BF 04 04         [24] 3689 	cjne	r7,#0x04,00114$
                                   3690 ;	tmk_core/protocol/ch555/usb_ak820.c:572: case id_firmware_version:
      006F22                       3691 00113$:
                                   3692 ;	tmk_core/protocol/ch555/usb_ak820.c:573: return true;
      006F22 75 82 01         [24] 3693 	mov	dpl, #0x01
      006F25 22               [24] 3694 	ret
                                   3695 ;	tmk_core/protocol/ch555/usb_ak820.c:574: default: return false;
      006F26                       3696 00114$:
      006F26 75 82 00         [24] 3697 	mov	dpl, #0x00
      006F29 22               [24] 3698 	ret
                                   3699 ;	tmk_core/protocol/ch555/usb_ak820.c:576: case id_lighting_get_value:
      006F2A                       3700 00116$:
                                   3701 ;	tmk_core/protocol/ch555/usb_ak820.c:577: switch (raw_buffer[1]) {
      006F2A 12 72 B0         [24] 3702 	lcall	_ak820_outline_0161
      006F2D BF 40 02         [24] 3703 	cjne	r7,#0x40,00318$
      006F30 80 12            [24] 3704 	sjmp	00121$
      006F32                       3705 00318$:
      006F32 BF 41 02         [24] 3706 	cjne	r7,#0x41,00319$
      006F35 80 0D            [24] 3707 	sjmp	00121$
      006F37                       3708 00319$:
      006F37 BF 42 02         [24] 3709 	cjne	r7,#0x42,00320$
      006F3A 80 08            [24] 3710 	sjmp	00121$
      006F3C                       3711 00320$:
      006F3C BF 43 02         [24] 3712 	cjne	r7,#0x43,00321$
      006F3F 80 03            [24] 3713 	sjmp	00121$
      006F41                       3714 00321$:
      006F41 BF 44 04         [24] 3715 	cjne	r7,#0x44,00122$
                                   3716 ;	tmk_core/protocol/ch555/usb_ak820.c:582: case vialrgb_get_led_info:
      006F44                       3717 00121$:
                                   3718 ;	tmk_core/protocol/ch555/usb_ak820.c:583: return true;
      006F44 75 82 01         [24] 3719 	mov	dpl, #0x01
                                   3720 ;	tmk_core/protocol/ch555/usb_ak820.c:584: default: return false;
      006F47 22               [24] 3721 	ret
      006F48                       3722 00122$:
      006F48 75 82 00         [24] 3723 	mov	dpl, #0x00
                                   3724 ;	tmk_core/protocol/ch555/usb_ak820.c:586: case id_vial_prefix:
      006F4B 22               [24] 3725 	ret
      006F4C                       3726 00124$:
                                   3727 ;	tmk_core/protocol/ch555/usb_ak820.c:587: switch (raw_buffer[1]) {
      006F4C 12 72 B0         [24] 3728 	lcall	_ak820_outline_0161
      006F4F 24 F2            [12] 3729 	add	a,#0xff - 0x0d
      006F51 40 4A            [24] 3730 	jc	00142$
                                   3731 ;	free result
      006F53 EF               [12] 3732 	mov	a,r7
      006F54 24 0A            [12] 3733 	add	a,#(00325$-3-.)
      006F56 83               [24] 3734 	movc	a,@a+pc
      006F57 F5 82            [12] 3735 	mov	dpl,a
      006F59 EF               [12] 3736 	mov	a,r7
      006F5A 24 12            [12] 3737 	add	a,#(00326$-3-.)
      006F5C 83               [24] 3738 	movc	a,@a+pc
      006F5D F5 83            [12] 3739 	mov	dph,a
      006F5F E4               [12] 3740 	clr	a
      006F60 73               [24] 3741 	jmp	@a+dptr
      006F61                       3742 00325$:
      006F61 7D                    3743 	.db	00134$
      006F62 7D                    3744 	.db	00134$
      006F63 7D                    3745 	.db	00134$
      006F64 7D                    3746 	.db	00134$
      006F65 9D                    3747 	.db	00142$
      006F66 7D                    3748 	.db	00134$
      006F67 7D                    3749 	.db	00134$
      006F68 7D                    3750 	.db	00134$
      006F69 7D                    3751 	.db	00134$
      006F6A 7D                    3752 	.db	00134$
      006F6B 7D                    3753 	.db	00134$
      006F6C 9D                    3754 	.db	00142$
      006F6D 9D                    3755 	.db	00142$
      006F6E 81                    3756 	.db	00135$
      006F6F                       3757 00326$:
      006F6F 6F                    3758 	.db	00134$>>8
      006F70 6F                    3759 	.db	00134$>>8
      006F71 6F                    3760 	.db	00134$>>8
      006F72 6F                    3761 	.db	00134$>>8
      006F73 6F                    3762 	.db	00142$>>8
      006F74 6F                    3763 	.db	00134$>>8
      006F75 6F                    3764 	.db	00134$>>8
      006F76 6F                    3765 	.db	00134$>>8
      006F77 6F                    3766 	.db	00134$>>8
      006F78 6F                    3767 	.db	00134$>>8
      006F79 6F                    3768 	.db	00134$>>8
      006F7A 6F                    3769 	.db	00142$>>8
      006F7B 6F                    3770 	.db	00142$>>8
      006F7C 6F                    3771 	.db	00135$>>8
                                   3772 ;	tmk_core/protocol/ch555/usb_ak820.c:597: case vial_qmk_settings_get:
      006F7D                       3773 00134$:
                                   3774 ;	tmk_core/protocol/ch555/usb_ak820.c:598: return true;
      006F7D 75 82 01         [24] 3775 	mov	dpl, #0x01
                                   3776 ;	tmk_core/protocol/ch555/usb_ak820.c:599: case vial_dynamic_entry_op:
      006F80 22               [24] 3777 	ret
      006F81                       3778 00135$:
                                   3779 ;	tmk_core/protocol/ch555/usb_ak820.c:600: switch (raw_buffer[2]) {
      006F81 90 07 A0         [24] 3780 	mov	dptr,#(_raw_buffer + 0x0002)
      006F84 E0               [24] 3781 	movx	a,@dptr
      006F85 FF               [12] 3782 	mov	r7,a
      006F86 60 0D            [24] 3783 	jz	00139$
      006F88 BF 01 02         [24] 3784 	cjne	r7,#0x01,00328$
      006F8B 80 08            [24] 3785 	sjmp	00139$
      006F8D                       3786 00328$:
      006F8D BF 03 02         [24] 3787 	cjne	r7,#0x03,00329$
      006F90 80 03            [24] 3788 	sjmp	00139$
      006F92                       3789 00329$:
      006F92 BF 05 04         [24] 3790 	cjne	r7,#0x05,00140$
                                   3791 ;	tmk_core/protocol/ch555/usb_ak820.c:604: case dynamic_vial_key_override_get:
      006F95                       3792 00139$:
                                   3793 ;	tmk_core/protocol/ch555/usb_ak820.c:605: return true;
      006F95 75 82 01         [24] 3794 	mov	dpl, #0x01
                                   3795 ;	tmk_core/protocol/ch555/usb_ak820.c:606: default: return false;
      006F98 22               [24] 3796 	ret
      006F99                       3797 00140$:
      006F99 75 82 00         [24] 3798 	mov	dpl, #0x00
                                   3799 ;	tmk_core/protocol/ch555/usb_ak820.c:608: default: return false;
      006F9C 22               [24] 3800 	ret
      006F9D                       3801 00142$:
      006F9D 75 82 00         [24] 3802 	mov	dpl, #0x00
                                   3803 ;	tmk_core/protocol/ch555/usb_ak820.c:610: default: return false;
      006FA0 22               [24] 3804 	ret
      006FA1                       3805 00144$:
      006FA1 75 82 00         [24] 3806 	mov	dpl, #0x00
                                   3807 ;	tmk_core/protocol/ch555/usb_ak820.c:611: }
                                   3808 ;	tmk_core/protocol/ch555/usb_ak820.c:612: }
      006FA4 22               [24] 3809 	ret
                                   3810 ;------------------------------------------------------------
                                   3811 ;Allocation info for local variables in function 'ak820_usb_raw_send'
                                   3812 ;------------------------------------------------------------
                                   3813 ;length        Allocated with name '_ak820_usb_raw_send_PARM_2'
                                   3814 ;report        Allocated with name '_ak820_usb_raw_send_report_10000_463'
                                   3815 ;------------------------------------------------------------
                                   3816 ;	tmk_core/protocol/ch555/usb_ak820.c:614: void ak820_usb_raw_send(const uint8_t *report, uint8_t length) {
                                   3817 ;	-----------------------------------------
                                   3818 ;	 function ak820_usb_raw_send
                                   3819 ;	-----------------------------------------
      006FA5                       3820 _ak820_usb_raw_send:
      006FA5 12 45 87         [24] 3821 	lcall	_ak820_outline_0037
      006FA8 90 08 0C         [24] 3822 	mov	dptr,#_ak820_usb_raw_send_report_10000_463
      006FAB 12 3A 1F         [24] 3823 	lcall	_ak820_outline_0016
                                   3824 ;	tmk_core/protocol/ch555/usb_ak820.c:615: if (length != RAW_EPSIZE) return;
      006FAE 90 08 0B         [24] 3825 	mov	dptr,#_ak820_usb_raw_send_PARM_2
      006FB1 E0               [24] 3826 	movx	a,@dptr
      006FB2 FF               [12] 3827 	mov	r7,a
      006FB3 BF 20 2B         [24] 3828 	cjne	r7,#0x20,00106$
                                   3829 ;	tmk_core/protocol/ch555/usb_ak820.c:616: ak820_nvm_flush();
      006FB6 C0 07            [24] 3830 	push	ar7
      006FB8 12 40 9E         [24] 3831 	lcall	_ak820_nvm_flush
      006FBB D0 07            [24] 3832 	pop	ar7
                                   3833 ;	tmk_core/protocol/ch555/usb_ak820.c:617: if (raw_reply_without_nvm || ak820_nvm_ok()) ak820_usb_send(RAW_IN_EPNUM, (const uint8_t __xdata *)report, length);
      006FBD 90 07 BE         [24] 3834 	mov	dptr,#_raw_reply_without_nvm
      006FC0 E0               [24] 3835 	movx	a,@dptr
      006FC1 70 07            [24] 3836 	jnz	00103$
      006FC3 12 40 8F         [24] 3837 	lcall	_ak820_nvm_ok
      006FC6 E5 82            [12] 3838 	mov	a, dpl
      006FC8 60 17            [24] 3839 	jz	00106$
      006FCA                       3840 00103$:
      006FCA 90 08 0C         [24] 3841 	mov	dptr,#_ak820_usb_raw_send_report_10000_463
      006FCD 12 45 B7         [24] 3842 	lcall	_ak820_outline_0097
      006FD0 90 08 01         [24] 3843 	mov	dptr,#_ak820_usb_send_PARM_2
      006FD3 12 45 FA         [24] 3844 	lcall	_ak820_outline_0159
      006FD6 90 08 03         [24] 3845 	mov	dptr,#_ak820_usb_send_PARM_3
      006FD9 EF               [12] 3846 	mov	a,r7
      006FDA F0               [24] 3847 	movx	@dptr,a
      006FDB 75 82 03         [24] 3848 	mov	dpl, #0x03
                                   3849 ;	tmk_core/protocol/ch555/usb_ak820.c:618: }
      006FDE 02 6C BB         [24] 3850 	ljmp	_ak820_usb_send
      006FE1                       3851 00106$:
      006FE1 22               [24] 3852 	ret
                                   3853 ;------------------------------------------------------------
                                   3854 ;Allocation info for local variables in function 'ak820_usb_raw_task'
                                   3855 ;------------------------------------------------------------
                                   3856 ;sloc0         Allocated with name '_ak820_usb_raw_task_sloc0_1_0'
                                   3857 ;i             Allocated with name '_ak820_usb_raw_task_i_10000_468'
                                   3858 ;length        Allocated with name '_ak820_usb_raw_task_length_10000_468'
                                   3859 ;address       Allocated with name '_ak820_usb_raw_task_address_10000_468'
                                   3860 ;saved_ea      Allocated with name '_ak820_usb_raw_task_saved_ea_10000_468'
                                   3861 ;------------------------------------------------------------
                                   3862 ;	tmk_core/protocol/ch555/usb_ak820.c:620: void ak820_usb_raw_task(void) {
                                   3863 ;	-----------------------------------------
                                   3864 ;	 function ak820_usb_raw_task
                                   3865 ;	-----------------------------------------
      006FE2                       3866 _ak820_usb_raw_task:
                                   3867 ;	tmk_core/protocol/ch555/usb_ak820.c:624: uint8_t saved_ea = EA;
      006FE2 A2 AF            [12] 3868 	mov	c,_EA
      006FE4 E4               [12] 3869 	clr	a
      006FE5 33               [12] 3870 	rlc	a
      006FE6 FF               [12] 3871 	mov	r7,a
                                   3872 ;	tmk_core/protocol/ch555/usb_ak820.c:625: EA = 0;
                                   3873 ;	assignBit
      006FE7 C2 AF            [12] 3874 	clr	_EA
                                   3875 ;	tmk_core/protocol/ch555/usb_ak820.c:626: if (!USB_EnumStatus || raw_state != RAW_READY) { EA = saved_ea; return; }
      006FE9 90 07 96         [24] 3876 	mov	dptr,#_USB_EnumStatus
      006FEC E0               [24] 3877 	movx	a,@dptr
      006FED 60 0A            [24] 3878 	jz	00101$
      006FEF 90 07 9D         [24] 3879 	mov	dptr,#_raw_state
      006FF2 E0               [24] 3880 	movx	a,@dptr
      006FF3 FE               [12] 3881 	mov	r6,a
      006FF4 BE 02 02         [24] 3882 	cjne	r6,#0x02,00427$
      006FF7 80 06            [24] 3883 	sjmp	00102$
      006FF9                       3884 00427$:
      006FF9                       3885 00101$:
                                   3886 ;	assignBit
      006FF9 EF               [12] 3887 	mov	a,r7
      006FFA 24 FF            [12] 3888 	add	a,#0xff
      006FFC 92 AF            [24] 3889 	mov	_EA,c
      006FFE 22               [24] 3890 	ret
      006FFF                       3891 00102$:
                                   3892 ;	tmk_core/protocol/ch555/usb_ak820.c:627: raw_state = RAW_WORK;
      006FFF 90 07 9D         [24] 3893 	mov	dptr,#_raw_state
      007002 74 03            [12] 3894 	mov	a,#0x03
      007004 F0               [24] 3895 	movx	@dptr,a
                                   3896 ;	tmk_core/protocol/ch555/usb_ak820.c:628: EA = saved_ea;
                                   3897 ;	assignBit
      007005 EF               [12] 3898 	mov	a,r7
      007006 24 FF            [12] 3899 	add	a,#0xff
      007008 92 AF            [24] 3900 	mov	_EA,c
                                   3901 ;	tmk_core/protocol/ch555/usb_ak820.c:629: if (raw_buffer[0] == 0xfd && raw_buffer[1] == 0) {
      00700A 90 07 9E         [24] 3902 	mov	dptr,#_raw_buffer
      00700D E0               [24] 3903 	movx	a,@dptr
      00700E FF               [12] 3904 	mov	r7,a
      00700F E4               [12] 3905 	clr	a
      007010 BF FD 01         [24] 3906 	cjne	r7,#0xfd,00428$
      007013 04               [12] 3907 	inc	a
      007014                       3908 00428$:
      007014 FF               [12] 3909 	mov	r7,a
      007015 70 03            [24] 3910 	jnz	00430$
      007017 02 70 B7         [24] 3911 	ljmp	00141$
      00701A                       3912 00430$:
      00701A 90 07 9F         [24] 3913 	mov	dptr,#(_raw_buffer + 0x0001)
      00701D E0               [24] 3914 	movx	a,@dptr
      00701E 60 03            [24] 3915 	jz	00431$
      007020 02 70 B7         [24] 3916 	ljmp	00141$
      007023                       3917 00431$:
                                   3918 ;	tmk_core/protocol/ch555/usb_ak820.c:632: address = ((uint16_t)raw_buffer[2] << 8) | raw_buffer[3];
      007023 90 07 A0         [24] 3919 	mov	dptr,#(_raw_buffer + 0x0002)
      007026 E0               [24] 3920 	movx	a,@dptr
      007027 FD               [12] 3921 	mov	r5,a
      007028 7E 00            [12] 3922 	mov	r6,#0x00
      00702A 90 07 A1         [24] 3923 	mov	dptr,#(_raw_buffer + 0x0003)
      00702D E0               [24] 3924 	movx	a,@dptr
      00702E 7B 00            [12] 3925 	mov	r3,#0x00
      007030 42 06            [12] 3926 	orl	ar6,a
      007032 EB               [12] 3927 	mov	a,r3
      007033 42 05            [12] 3928 	orl	ar5,a
                                   3929 ;	tmk_core/protocol/ch555/usb_ak820.c:633: length = raw_buffer[4];
      007035 90 07 A2         [24] 3930 	mov	dptr,#(_raw_buffer + 0x0004)
      007038 E0               [24] 3931 	movx	a,@dptr
      007039 FC               [12] 3932 	mov	r4,a
                                   3933 ;	tmk_core/protocol/ch555/usb_ak820.c:634: for (i = 5; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
      00703A 7B 05            [12] 3934 	mov	r3,#0x05
      00703C                       3935 00151$:
      00703C EB               [12] 3936 	mov	a,r3
      00703D 12 72 9E         [24] 3937 	lcall	_ak820_outline_0040
      007040 0B               [12] 3938 	inc	r3
      007041 BB 20 00         [24] 3939 	cjne	r3,#0x20,00432$
      007044                       3940 00432$:
      007044 40 F6            [24] 3941 	jc	00151$
                                   3942 ;	tmk_core/protocol/ch555/usb_ak820.c:635: if (length > RAW_EPSIZE - 5 || (length && address > 0xffffu - (length - 1))) {
      007046 EC               [12] 3943 	mov	a,r4
      007047 24 E4            [12] 3944 	add	a,#0xff - 0x1b
      007049 40 1C            [24] 3945 	jc	00106$
                                   3946 ;	free result
      00704B EC               [12] 3947 	mov	a,r4
      00704C 60 26            [24] 3948 	jz	00212$
      00704E 8C 03            [24] 3949 	mov	ar3,r4
      007050 1B               [12] 3950 	dec	r3
      007051 7A 00            [12] 3951 	mov	r2,#0x00
      007053 74 FF            [12] 3952 	mov	a,#0xff
      007055 C3               [12] 3953 	clr	c
      007056 9B               [12] 3954 	subb	a,r3
      007057 FB               [12] 3955 	mov	r3,a
      007058 74 FF            [12] 3956 	mov	a,#0xff
      00705A 9A               [12] 3957 	subb	a,r2
      00705B FA               [12] 3958 	mov	r2,a
      00705C 8E 00            [24] 3959 	mov	ar0,r6
      00705E 8D 01            [24] 3960 	mov	ar1,r5
      007060 C3               [12] 3961 	clr	c
      007061 EB               [12] 3962 	mov	a,r3
      007062 98               [12] 3963 	subb	a,r0
      007063 EA               [12] 3964 	mov	a,r2
      007064 99               [12] 3965 	subb	a,r1
      007065 50 0D            [24] 3966 	jnc	00212$
                                   3967 ;	free result
      007067                       3968 00106$:
                                   3969 ;	tmk_core/protocol/ch555/usb_ak820.c:636: raw_buffer[1] = 0xff;
      007067 90 07 9F         [24] 3970 	mov	dptr,#(_raw_buffer + 0x0001)
      00706A 74 FF            [12] 3971 	mov	a,#0xff
      00706C F0               [24] 3972 	movx	@dptr,a
                                   3973 ;	tmk_core/protocol/ch555/usb_ak820.c:637: raw_buffer[4] = 0;
      00706D 90 07 A2         [24] 3974 	mov	dptr,#(_raw_buffer + 0x0004)
      007070 E4               [12] 3975 	clr	a
      007071 F0               [24] 3976 	movx	@dptr,a
                                   3977 ;	tmk_core/protocol/ch555/usb_ak820.c:639: for (i = 0; i < length; ++i) raw_buffer[5 + i] = READ_CODE(address + i);
      007072 80 3A            [24] 3978 	sjmp	00108$
      007074                       3979 00212$:
      007074 7B 00            [12] 3980 	mov	r3,#0x00
      007076                       3981 00154$:
      007076 C3               [12] 3982 	clr	c
      007077 EB               [12] 3983 	mov	a,r3
      007078 9C               [12] 3984 	subb	a,r4
      007079 50 33            [24] 3985 	jnc	00108$
      00707B C0 04            [24] 3986 	push	ar4
      00707D 8B 02            [24] 3987 	mov	ar2,r3
      00707F 74 05            [12] 3988 	mov	a,#0x05
      007081 2A               [12] 3989 	add	a, r2
      007082 F9               [12] 3990 	mov	r1,a
      007083 33               [12] 3991 	rlc	a
      007084 95 E0            [12] 3992 	subb	a,acc
      007086 FA               [12] 3993 	mov	r2,a
      007087 E9               [12] 3994 	mov	a,r1
      007088 24 9E            [12] 3995 	add	a, #_raw_buffer
      00708A F9               [12] 3996 	mov	r1,a
      00708B EA               [12] 3997 	mov	a,r2
      00708C 34 07            [12] 3998 	addc	a, #(_raw_buffer >> 8)
      00708E FA               [12] 3999 	mov	r2,a
      00708F 8B 1E            [24] 4000 	mov	_ak820_usb_raw_task_sloc0_1_0,r3
      007091 75 1F 00         [24] 4001 	mov	(_ak820_usb_raw_task_sloc0_1_0 + 1),#0x00
      007094 8E 00            [24] 4002 	mov	ar0,r6
      007096 8D 04            [24] 4003 	mov	ar4,r5
      007098 E5 1E            [12] 4004 	mov	a,_ak820_usb_raw_task_sloc0_1_0
      00709A 28               [12] 4005 	add	a, r0
      00709B F8               [12] 4006 	mov	r0,a
      00709C E5 1F            [12] 4007 	mov	a,(_ak820_usb_raw_task_sloc0_1_0 + 1)
      00709E 3C               [12] 4008 	addc	a, r4
      00709F FC               [12] 4009 	mov	r4,a
      0070A0 88 82            [24] 4010 	mov	dpl,r0
      0070A2 8C 83            [24] 4011 	mov	dph,r4
      0070A4 E4               [12] 4012 	clr	a
      0070A5 93               [24] 4013 	movc	a,@a+dptr
      0070A6 12 72 AA         [24] 4014 	lcall	_ak820_outline_0136
      0070A9 0B               [12] 4015 	inc	r3
      0070AA D0 04            [24] 4016 	pop	ar4
      0070AC 80 C8            [24] 4017 	sjmp	00154$
      0070AE                       4018 00108$:
                                   4019 ;	tmk_core/protocol/ch555/usb_ak820.c:643: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
      0070AE 12 72 8A         [24] 4020 	lcall	_ak820_outline_0008
      0070B1 12 6C BB         [24] 4021 	lcall	_ak820_usb_send
      0070B4 02 72 3A         [24] 4022 	ljmp	00142$
      0070B7                       4023 00141$:
                                   4024 ;	tmk_core/protocol/ch555/usb_ak820.c:644: } else if (raw_buffer[0] == 0xfd && raw_buffer[1] == 1) {
      0070B7 EF               [12] 4025 	mov	a,r7
      0070B8 70 03            [24] 4026 	jnz	00438$
      0070BA 02 71 3C         [24] 4027 	ljmp	00137$
      0070BD                       4028 00438$:
      0070BD 90 07 9F         [24] 4029 	mov	dptr,#(_raw_buffer + 0x0001)
      0070C0 E0               [24] 4030 	movx	a,@dptr
      0070C1 FE               [12] 4031 	mov	r6,a
      0070C2 BE 01 02         [24] 4032 	cjne	r6,#0x01,00439$
      0070C5 80 03            [24] 4033 	sjmp	00440$
      0070C7                       4034 00439$:
      0070C7 02 71 3C         [24] 4035 	ljmp	00137$
      0070CA                       4036 00440$:
                                   4037 ;	tmk_core/protocol/ch555/usb_ak820.c:647: for (i = 2; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
      0070CA 7E 02            [12] 4038 	mov	r6,#0x02
      0070CC                       4039 00156$:
      0070CC EE               [12] 4040 	mov	a,r6
      0070CD 12 72 9E         [24] 4041 	lcall	_ak820_outline_0040
      0070D0 0E               [12] 4042 	inc	r6
      0070D1 BE 20 00         [24] 4043 	cjne	r6,#0x20,00441$
      0070D4                       4044 00441$:
      0070D4 40 F6            [24] 4045 	jc	00156$
                                   4046 ;	tmk_core/protocol/ch555/usb_ak820.c:648: raw_buffer[2] = 1;
      0070D6 90 07 A0         [24] 4047 	mov	dptr,#(_raw_buffer + 0x0002)
      0070D9 74 01            [12] 4048 	mov	a,#0x01
      0070DB F0               [24] 4049 	movx	@dptr,a
                                   4050 ;	tmk_core/protocol/ch555/usb_ak820.c:649: raw_buffer[3] = 0xa8;
      0070DC 90 07 A1         [24] 4051 	mov	dptr,#(_raw_buffer + 0x0003)
      0070DF 74 A8            [12] 4052 	mov	a,#0xa8
      0070E1 F0               [24] 4053 	movx	@dptr,a
                                   4054 ;	tmk_core/protocol/ch555/usb_ak820.c:650: ak820_nvm_diagnostic(&raw_buffer[4]);
      0070E2 90 07 A2         [24] 4055 	mov	dptr,#(_raw_buffer + 0x0004)
      0070E5 12 3E 0B         [24] 4056 	lcall	_ak820_nvm_diagnostic
                                   4057 ;	tmk_core/protocol/ch555/usb_ak820.c:651: for (i = 0; i < 6; ++i) raw_buffer[11 + i] = ak820_flash_diagnostic[i];
      0070E8 7E 00            [12] 4058 	mov	r6,#0x00
      0070EA                       4059 00158$:
      0070EA 8E 05            [24] 4060 	mov	ar5,r6
      0070EC 74 0B            [12] 4061 	mov	a,#0x0b
      0070EE 2D               [12] 4062 	add	a, r5
      0070EF 24 9E            [12] 4063 	add	a,#_raw_buffer
      0070F1 FD               [12] 4064 	mov	r5,a
      0070F2 E4               [12] 4065 	clr	a
      0070F3 34 07            [12] 4066 	addc	a, #(_raw_buffer >> 8)
      0070F5 FC               [12] 4067 	mov	r4,a
      0070F6 EE               [12] 4068 	mov	a,r6
      0070F7 24 70            [12] 4069 	add	a, #_ak820_flash_diagnostic
      0070F9 F5 82            [12] 4070 	mov	dpl,a
      0070FB E4               [12] 4071 	clr	a
      0070FC 34 04            [12] 4072 	addc	a, #(_ak820_flash_diagnostic >> 8)
      0070FE F5 83            [12] 4073 	mov	dph,a
      007100 E0               [24] 4074 	movx	a,@dptr
      007101 12 46 0A         [24] 4075 	lcall	_ak820_outline_0185
      007104 F0               [24] 4076 	movx	@dptr,a
      007105 0E               [12] 4077 	inc	r6
      007106 BE 06 00         [24] 4078 	cjne	r6,#0x06,00443$
      007109                       4079 00443$:
      007109 40 DF            [24] 4080 	jc	00158$
                                   4081 ;	tmk_core/protocol/ch555/usb_ak820.c:652: raw_buffer[17] = vial_unlocked;
      00710B 90 0E 2B         [24] 4082 	mov	dptr,#_vial_unlocked
      00710E E0               [24] 4083 	movx	a,@dptr
      00710F 90 07 AF         [24] 4084 	mov	dptr,#(_raw_buffer + 0x0011)
      007112 F0               [24] 4085 	movx	@dptr,a
                                   4086 ;	tmk_core/protocol/ch555/usb_ak820.c:653: raw_buffer[18] = vial_unlock_in_progress;
      007113 90 0E 2C         [24] 4087 	mov	dptr,#_vial_unlock_in_progress
      007116 E0               [24] 4088 	movx	a,@dptr
      007117 90 07 B0         [24] 4089 	mov	dptr,#(_raw_buffer + 0x0012)
      00711A F0               [24] 4090 	movx	@dptr,a
                                   4091 ;	tmk_core/protocol/ch555/usb_ak820.c:654: raw_buffer[19] = USB_EnumStatus;
      00711B 90 07 96         [24] 4092 	mov	dptr,#_USB_EnumStatus
      00711E E0               [24] 4093 	movx	a,@dptr
      00711F 90 07 B1         [24] 4094 	mov	dptr,#(_raw_buffer + 0x0013)
      007122 F0               [24] 4095 	movx	@dptr,a
                                   4096 ;	tmk_core/protocol/ch555/usb_ak820.c:655: raw_buffer[20] = USB_SleepStatus;
      007123 90 07 97         [24] 4097 	mov	dptr,#_USB_SleepStatus
      007126 E0               [24] 4098 	movx	a,@dptr
      007127 90 07 B2         [24] 4099 	mov	dptr,#(_raw_buffer + 0x0014)
      00712A F0               [24] 4100 	movx	@dptr,a
                                   4101 ;	tmk_core/protocol/ch555/usb_ak820.c:656: raw_buffer[21] = raw_state;
      00712B 90 07 9D         [24] 4102 	mov	dptr,#_raw_state
      00712E E0               [24] 4103 	movx	a,@dptr
      00712F 90 07 B3         [24] 4104 	mov	dptr,#(_raw_buffer + 0x0015)
      007132 F0               [24] 4105 	movx	@dptr,a
                                   4106 ;	tmk_core/protocol/ch555/usb_ak820.c:657: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
      007133 12 72 8A         [24] 4107 	lcall	_ak820_outline_0008
      007136 12 6C BB         [24] 4108 	lcall	_ak820_usb_send
      007139 02 72 3A         [24] 4109 	ljmp	00142$
      00713C                       4110 00137$:
                                   4111 ;	tmk_core/protocol/ch555/usb_ak820.c:659: } else if (raw_buffer[0] == 0xfd && raw_buffer[1] == 2) {
      00713C EF               [12] 4112 	mov	a,r7
      00713D 70 03            [24] 4113 	jnz	00445$
      00713F 02 72 17         [24] 4114 	ljmp	00133$
      007142                       4115 00445$:
      007142 12 72 B0         [24] 4116 	lcall	_ak820_outline_0161
      007145 BF 02 02         [24] 4117 	cjne	r7,#0x02,00446$
      007148 80 03            [24] 4118 	sjmp	00447$
      00714A                       4119 00446$:
      00714A 02 72 17         [24] 4120 	ljmp	00133$
      00714D                       4121 00447$:
                                   4122 ;	tmk_core/protocol/ch555/usb_ak820.c:663: length = 1;
      00714D 90 08 0F         [24] 4123 	mov	dptr,#_ak820_usb_raw_task_length_10000_468
      007150 74 01            [12] 4124 	mov	a,#0x01
      007152 F0               [24] 4125 	movx	@dptr,a
                                   4126 ;	tmk_core/protocol/ch555/usb_ak820.c:664: if (raw_buffer[2] == 1 && raw_buffer[3] <= 1 && raw_buffer[4] <= AK820_OS_BREATHE &&
      007153 90 07 A0         [24] 4127 	mov	dptr,#(_raw_buffer + 0x0002)
      007156 E0               [24] 4128 	movx	a,@dptr
      007157 FF               [12] 4129 	mov	r7,a
      007158 BF 01 73         [24] 4130 	cjne	r7,#0x01,00235$
      00715B 90 07 A1         [24] 4131 	mov	dptr,#(_raw_buffer + 0x0003)
      00715E E0               [24] 4132 	movx	a,@dptr
      00715F FF               [12] 4133 	mov  r7,a
      007160 24 FE            [12] 4134 	add	a,#0xff - 0x01
      007162 40 6A            [24] 4135 	jc	00235$
                                   4136 ;	free result
      007164 90 07 A2         [24] 4137 	mov	dptr,#(_raw_buffer + 0x0004)
      007167 E0               [24] 4138 	movx	a,@dptr
      007168 FE               [12] 4139 	mov  r6,a
      007169 24 FC            [12] 4140 	add	a,#0xff - 0x03
      00716B 40 61            [24] 4141 	jc	00235$
                                   4142 ;	free result
                                   4143 ;	tmk_core/protocol/ch555/usb_ak820.c:665: (raw_buffer[3] || !raw_buffer[4])) {
      00716D EF               [12] 4144 	mov	a,r7
      00716E 70 03            [24] 4145 	jnz	00227$
      007170 EE               [12] 4146 	mov	a,r6
      007171 70 5B            [24] 4147 	jnz	00235$
                                   4148 ;	tmk_core/protocol/ch555/usb_ak820.c:666: for (i = 5; i < RAW_EPSIZE && !raw_buffer[i]; ++i) {}
      007173                       4149 00227$:
      007173 7D 05            [12] 4150 	mov	r5,#0x05
      007175                       4151 00162$:
      007175 BD 20 00         [24] 4152 	cjne	r5,#0x20,00454$
      007178                       4153 00454$:
      007178 50 11            [24] 4154 	jnc	00113$
      00717A ED               [12] 4155 	mov	a,r5
      00717B 24 9E            [12] 4156 	add	a, #_raw_buffer
      00717D FB               [12] 4157 	mov	r3,a
      00717E E4               [12] 4158 	clr	a
      00717F 34 07            [12] 4159 	addc	a, #(_raw_buffer >> 8)
      007181 FC               [12] 4160 	mov	r4,a
      007182 12 36 42         [24] 4161 	lcall	_ak820_outline_0122
      007185 E0               [24] 4162 	movx	a,@dptr
      007186 70 03            [24] 4163 	jnz	00113$
      007188 0D               [12] 4164 	inc	r5
      007189 80 EA            [24] 4165 	sjmp	00162$
      00718B                       4166 00113$:
                                   4167 ;	tmk_core/protocol/ch555/usb_ak820.c:667: if (i == RAW_EPSIZE) {
      00718B BD 20 40         [24] 4168 	cjne	r5,#0x20,00235$
                                   4169 ;	tmk_core/protocol/ch555/usb_ak820.c:668: saved_ea = EA;
                                   4170 ;	assignBit
      00718E A2 AF            [12] 4171 	mov	c,_EA
      007190 92 1C            [24] 4172 	mov	_ak820_usb_raw_task_sloc1_1_0,c
                                   4173 ;	tmk_core/protocol/ch555/usb_ak820.c:669: EA = 0;
                                   4174 ;	assignBit
      007192 C2 AF            [12] 4175 	clr	_EA
                                   4176 ;	tmk_core/protocol/ch555/usb_ak820.c:672: if (raw_state == RAW_WORK && USB_EnumStatus && D0UsbConfig &&
      007194 90 07 9D         [24] 4177 	mov	dptr,#_raw_state
      007197 E0               [24] 4178 	movx	a,@dptr
      007198 FD               [12] 4179 	mov	r5,a
      007199 BD 03 28         [24] 4180 	cjne	r5,#0x03,00117$
      00719C 90 07 96         [24] 4181 	mov	dptr,#_USB_EnumStatus
      00719F E0               [24] 4182 	movx	a,@dptr
      0071A0 60 22            [24] 4183 	jz	00117$
      0071A2 90 07 95         [24] 4184 	mov	dptr,#_D0UsbConfig
      0071A5 E0               [24] 4185 	movx	a,@dptr
      0071A6 60 1C            [24] 4186 	jz	00117$
                                   4187 ;	tmk_core/protocol/ch555/usb_ak820.c:673: !(USB_SleepStatus & 2) && !vial_unlock_in_progress) {
      0071A8 90 07 97         [24] 4188 	mov	dptr,#_USB_SleepStatus
      0071AB E0               [24] 4189 	movx	a,@dptr
      0071AC 20 E1 15         [24] 4190 	jb	acc.1,00117$
      0071AF 90 0E 2C         [24] 4191 	mov	dptr,#_vial_unlock_in_progress
      0071B2 E0               [24] 4192 	movx	a,@dptr
      0071B3 70 0F            [24] 4193 	jnz	00117$
                                   4194 ;	tmk_core/protocol/ch555/usb_ak820.c:674: if (raw_buffer[3]) ak820_os_indicator_set(raw_buffer[4]);
      0071B5 EF               [12] 4195 	mov	a,r7
      0071B6 60 05            [24] 4196 	jz	00115$
      0071B8 8E 82            [24] 4197 	mov	dpl, r6
      0071BA 12 46 0F         [24] 4198 	lcall	_ak820_os_indicator_set
      0071BD                       4199 00115$:
                                   4200 ;	tmk_core/protocol/ch555/usb_ak820.c:675: length = 0;
      0071BD 90 08 0F         [24] 4201 	mov	dptr,#_ak820_usb_raw_task_length_10000_468
      0071C0 E4               [12] 4202 	clr	a
      0071C1 F0               [24] 4203 	movx	@dptr,a
      0071C2 80 06            [24] 4204 	sjmp	00118$
      0071C4                       4205 00117$:
                                   4206 ;	tmk_core/protocol/ch555/usb_ak820.c:676: } else length = 2;
      0071C4 90 08 0F         [24] 4207 	mov	dptr,#_ak820_usb_raw_task_length_10000_468
      0071C7 74 02            [12] 4208 	mov	a,#0x02
      0071C9 F0               [24] 4209 	movx	@dptr,a
      0071CA                       4210 00118$:
                                   4211 ;	tmk_core/protocol/ch555/usb_ak820.c:677: EA = saved_ea;
                                   4212 ;	assignBit
      0071CA A2 1C            [12] 4213 	mov	c,_ak820_usb_raw_task_sloc1_1_0
      0071CC 92 AF            [24] 4214 	mov	_EA,c
                                   4215 ;	tmk_core/protocol/ch555/usb_ak820.c:680: for (i = 2; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
      0071CE                       4216 00235$:
      0071CE 7F 02            [12] 4217 	mov	r7,#0x02
      0071D0                       4218 00164$:
      0071D0 EF               [12] 4219 	mov	a,r7
      0071D1 12 72 9E         [24] 4220 	lcall	_ak820_outline_0040
      0071D4 0F               [12] 4221 	inc	r7
      0071D5 BF 20 00         [24] 4222 	cjne	r7,#0x20,00466$
      0071D8                       4223 00466$:
      0071D8 40 F6            [24] 4224 	jc	00164$
                                   4225 ;	tmk_core/protocol/ch555/usb_ak820.c:681: raw_buffer[2] = 1;
      0071DA 90 07 A0         [24] 4226 	mov	dptr,#(_raw_buffer + 0x0002)
      0071DD 74 01            [12] 4227 	mov	a,#0x01
      0071DF F0               [24] 4228 	movx	@dptr,a
                                   4229 ;	tmk_core/protocol/ch555/usb_ak820.c:682: raw_buffer[3] = length;
      0071E0 90 08 0F         [24] 4230 	mov	dptr,#_ak820_usb_raw_task_length_10000_468
      0071E3 E0               [24] 4231 	movx	a,@dptr
      0071E4 90 07 A1         [24] 4232 	mov	dptr,#(_raw_buffer + 0x0003)
      0071E7 F0               [24] 4233 	movx	@dptr,a
                                   4234 ;	tmk_core/protocol/ch555/usb_ak820.c:683: raw_buffer[4] = ak820_os_indicator_get();
      0071E8 12 46 36         [24] 4235 	lcall	_ak820_os_indicator_get
      0071EB AF 82            [24] 4236 	mov	r7, dpl
      0071ED 90 07 A2         [24] 4237 	mov	dptr,#(_raw_buffer + 0x0004)
      0071F0 EF               [12] 4238 	mov	a,r7
      0071F1 F0               [24] 4239 	movx	@dptr,a
                                   4240 ;	tmk_core/protocol/ch555/usb_ak820.c:684: raw_buffer[5] = 0xa8;
      0071F2 90 07 A3         [24] 4241 	mov	dptr,#(_raw_buffer + 0x0005)
      0071F5 74 A8            [12] 4242 	mov	a,#0xa8
      0071F7 F0               [24] 4243 	movx	@dptr,a
                                   4244 ;	tmk_core/protocol/ch555/usb_ak820.c:685: raw_buffer[6] = (uint8_t)AK820_OS_INDICATOR_LEASE_MS;
      0071F8 90 07 A4         [24] 4245 	mov	dptr,#(_raw_buffer + 0x0006)
      0071FB 74 B8            [12] 4246 	mov	a,#0xb8
      0071FD F0               [24] 4247 	movx	@dptr,a
                                   4248 ;	tmk_core/protocol/ch555/usb_ak820.c:686: raw_buffer[7] = (uint8_t)(AK820_OS_INDICATOR_LEASE_MS >> 8);
      0071FE 90 07 A5         [24] 4249 	mov	dptr,#(_raw_buffer + 0x0007)
      007201 74 0B            [12] 4250 	mov	a,#0x0b
      007203 F0               [24] 4251 	movx	@dptr,a
                                   4252 ;	tmk_core/protocol/ch555/usb_ak820.c:687: raw_buffer[8] = (uint8_t)AK820_OS_INDICATOR_PERIOD_MS;
      007204 90 07 A6         [24] 4253 	mov	dptr,#(_raw_buffer + 0x0008)
      007207 E4               [12] 4254 	clr	a
      007208 F0               [24] 4255 	movx	@dptr,a
                                   4256 ;	tmk_core/protocol/ch555/usb_ak820.c:688: raw_buffer[9] = (uint8_t)(AK820_OS_INDICATOR_PERIOD_MS >> 8);
      007209 90 07 A7         [24] 4257 	mov	dptr,#(_raw_buffer + 0x0009)
      00720C 74 10            [12] 4258 	mov	a,#0x10
      00720E F0               [24] 4259 	movx	@dptr,a
                                   4260 ;	tmk_core/protocol/ch555/usb_ak820.c:689: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
      00720F 12 72 8A         [24] 4261 	lcall	_ak820_outline_0008
      007212 12 6C BB         [24] 4262 	lcall	_ak820_usb_send
      007215 80 23            [24] 4263 	sjmp	00142$
      007217                       4264 00133$:
                                   4265 ;	tmk_core/protocol/ch555/usb_ak820.c:692: raw_reply_without_nvm = raw_request_is_nonpersistent();
      007217 12 6E CA         [24] 4266 	lcall	_raw_request_is_nonpersistent
      00721A E5 82            [12] 4267 	mov	a, dpl
      00721C 90 07 BE         [24] 4268 	mov	dptr,#_raw_reply_without_nvm
      00721F F0               [24] 4269 	movx	@dptr,a
                                   4270 ;	tmk_core/protocol/ch555/usb_ak820.c:693: ak820_nvm_begin();
      007220 12 41 F0         [24] 4271 	lcall	_ak820_nvm_begin
                                   4272 ;	tmk_core/protocol/ch555/usb_ak820.c:694: raw_hid_receive(raw_buffer, RAW_EPSIZE);
      007223 90 0C 5C         [24] 4273 	mov	dptr,#_raw_hid_receive_PARM_2
      007226 74 20            [12] 4274 	mov	a,#0x20
      007228 F0               [24] 4275 	movx	@dptr,a
      007229 90 07 9E         [24] 4276 	mov	dptr,#_raw_buffer
      00722C 75 F0 00         [24] 4277 	mov	b, #0x00
      00722F 12 AB AE         [24] 4278 	lcall	_raw_hid_receive
                                   4279 ;	tmk_core/protocol/ch555/usb_ak820.c:695: ak820_nvm_end();
      007232 12 42 05         [24] 4280 	lcall	_ak820_nvm_end
                                   4281 ;	tmk_core/protocol/ch555/usb_ak820.c:696: raw_reply_without_nvm = false;
      007235 90 07 BE         [24] 4282 	mov	dptr,#_raw_reply_without_nvm
      007238 E4               [12] 4283 	clr	a
      007239 F0               [24] 4284 	movx	@dptr,a
      00723A                       4285 00142$:
                                   4286 ;	tmk_core/protocol/ch555/usb_ak820.c:698: saved_ea = EA;
                                   4287 ;	assignBit
      00723A A2 AF            [12] 4288 	mov	c,_EA
      00723C 92 1C            [24] 4289 	mov	_ak820_usb_raw_task_sloc1_1_0,c
                                   4290 ;	tmk_core/protocol/ch555/usb_ak820.c:699: EA = 0;
                                   4291 ;	assignBit
      00723E C2 AF            [12] 4292 	clr	_EA
                                   4293 ;	tmk_core/protocol/ch555/usb_ak820.c:701: if (raw_state == RAW_TX_ACTIVE) raw_state = RAW_TX_WAIT;
      007240 12 72 B6         [24] 4294 	lcall	_ak820_outline_0163
      007243 BF 04 08         [24] 4295 	cjne	r7,#0x04,00149$
      007246 90 07 9D         [24] 4296 	mov	dptr,#_raw_state
      007249 74 05            [12] 4297 	mov	a,#0x05
      00724B F0               [24] 4298 	movx	@dptr,a
      00724C 80 1B            [24] 4299 	sjmp	00150$
      00724E                       4300 00149$:
                                   4301 ;	tmk_core/protocol/ch555/usb_ak820.c:702: else if (raw_state == RAW_WORK || raw_state == RAW_DRAINED || raw_state == RAW_CANCELLED) raw_state = RAW_IDLE;
      00724E 12 72 B6         [24] 4302 	lcall	_ak820_outline_0163
      007251 BF 03 02         [24] 4303 	cjne	r7,#0x03,00470$
      007254 80 0E            [24] 4304 	sjmp	00144$
      007256                       4305 00470$:
      007256 12 72 B6         [24] 4306 	lcall	_ak820_outline_0163
      007259 BF 06 02         [24] 4307 	cjne	r7,#0x06,00471$
      00725C 80 06            [24] 4308 	sjmp	00144$
      00725E                       4309 00471$:
      00725E 12 72 B6         [24] 4310 	lcall	_ak820_outline_0163
      007261 BF 07 05         [24] 4311 	cjne	r7,#0x07,00150$
      007264                       4312 00144$:
      007264 90 07 9D         [24] 4313 	mov	dptr,#_raw_state
      007267 E4               [12] 4314 	clr	a
      007268 F0               [24] 4315 	movx	@dptr,a
      007269                       4316 00150$:
                                   4317 ;	tmk_core/protocol/ch555/usb_ak820.c:703: EA = saved_ea;
                                   4318 ;	assignBit
      007269 A2 1C            [12] 4319 	mov	c,_ak820_usb_raw_task_sloc1_1_0
      00726B 92 AF            [24] 4320 	mov	_EA,c
                                   4321 ;	tmk_core/protocol/ch555/usb_ak820.c:704: }
      00726D 22               [24] 4322 	ret
                                   4323 ;------------------------------------------------------------
                                   4324 ;Allocation info for local variables in function 'ak820_usb_take_keyboard_reset'
                                   4325 ;------------------------------------------------------------
                                   4326 ;result        Allocated with name '_ak820_usb_take_keyboard_reset_result_10000_498'
                                   4327 ;saved_ea      Allocated with name '_ak820_usb_take_keyboard_reset_saved_ea_10000_498'
                                   4328 ;------------------------------------------------------------
                                   4329 ;	tmk_core/protocol/ch555/usb_ak820.c:712: bool ak820_usb_take_keyboard_reset(void) {
                                   4330 ;	-----------------------------------------
                                   4331 ;	 function ak820_usb_take_keyboard_reset
                                   4332 ;	-----------------------------------------
      00726E                       4333 _ak820_usb_take_keyboard_reset:
                                   4334 ;	tmk_core/protocol/ch555/usb_ak820.c:714: uint8_t saved_ea = EA;
                                   4335 ;	assignBit
      00726E A2 AF            [12] 4336 	mov	c,_EA
      007270 92 1D            [24] 4337 	mov	_ak820_usb_take_keyboard_reset_sloc0_1_0,c
                                   4338 ;	tmk_core/protocol/ch555/usb_ak820.c:715: EA = 0;
                                   4339 ;	assignBit
      007272 C2 AF            [12] 4340 	clr	_EA
                                   4341 ;	tmk_core/protocol/ch555/usb_ak820.c:716: result = keyboard_reset;
      007274 90 07 BF         [24] 4342 	mov	dptr,#_keyboard_reset
      007277 E0               [24] 4343 	movx	a,@dptr
      007278 FF               [12] 4344 	mov	r7,a
                                   4345 ;	tmk_core/protocol/ch555/usb_ak820.c:717: keyboard_reset = 0;
      007279 E4               [12] 4346 	clr	a
      00727A F0               [24] 4347 	movx	@dptr,a
                                   4348 ;	tmk_core/protocol/ch555/usb_ak820.c:718: EA = saved_ea;
                                   4349 ;	assignBit
      00727B A2 1D            [12] 4350 	mov	c,_ak820_usb_take_keyboard_reset_sloc0_1_0
      00727D 92 AF            [24] 4351 	mov	_EA,c
                                   4352 ;	tmk_core/protocol/ch555/usb_ak820.c:719: return result != 0;
      00727F EF               [12] 4353 	mov	a,r7
      007280 B4 01 00         [24] 4354 	cjne	a,#0x01,00103$
      007283                       4355 00103$:
      007283 B3               [12] 4356 	cpl	c
      007284 92 1D            [24] 4357 	mov	_ak820_usb_take_keyboard_reset_sloc0_1_0,c
      007286 12 3A C6         [24] 4358 	lcall	_ak820_outline_0166
                                   4359 ;	tmk_core/protocol/ch555/usb_ak820.c:720: }
      007289 22               [24] 4360 	ret
                                   4361 	.area CSEG    (CODE)
                                   4362 	.area CONST   (CODE)
                                   4363 	.area CONST   (CODE)
      00BE63                       4364 _shared_offsets:
      00BE63 00                    4365 	.db #0x00	; 0
      00BE64 00                    4366 	.db #0x00	; 0
      00BE65 28                    4367 	.db #0x28	; 40
      00BE66 2E                    4368 	.db #0x2e	; 46
      00BE67 31                    4369 	.db #0x31	; 49	'1'
      00BE68 00                    4370 	.db #0x00	; 0
      00BE69 08                    4371 	.db #0x08	; 8
                                   4372 	.area CSEG    (CODE)
                                   4373 	.area CONST   (CODE)
      00BE6A                       4374 _shared_lengths:
      00BE6A 00                    4375 	.db #0x00	; 0
      00BE6B 00                    4376 	.db #0x00	; 0
      00BE6C 06                    4377 	.db #0x06	; 6
      00BE6D 03                    4378 	.db #0x03	; 3
      00BE6E 03                    4379 	.db #0x03	; 3
      00BE6F 00                    4380 	.db #0x00	; 0
      00BE70 20                    4381 	.db #0x20	; 32
                                   4382 	.area CSEG    (CODE)
                                   4383 	.area CONST   (CODE)
      00BE71                       4384 _interface_descriptors:
      00BE71 14 C4                 4385 	.byte _KeyboardReport, (_KeyboardReport >> 8)
      00BE73 5D C5                 4386 	.byte (_ConfigurationDescriptor + 18), ((_ConfigurationDescriptor + 18) >> 8)
      00BE75 10 C5                 4387 	.byte _RawReport, (_RawReport >> 8)
      00BE77 76 C5                 4388 	.byte (_ConfigurationDescriptor + 43), ((_ConfigurationDescriptor + 43) >> 8)
      00BE79 59 C4                 4389 	.byte _SharedReport, (_SharedReport >> 8)
      00BE7B 8F C5                 4390 	.byte (_ConfigurationDescriptor + 68), ((_ConfigurationDescriptor + 68) >> 8)
                                   4391 	.area CSEG    (CODE)
                                   4392 	.area XINIT   (CODE)
                                   4393 	.area CABS    (ABS,CODE)
                                   4394 
                                   4395 ; Experimental exact instruction outlining.
                                   4396 	.globl _ak820_outline_0008
                                   4397 	.globl _ak820_outline_0016
                                   4398 	.globl _ak820_outline_0037
                                   4399 	.globl _ak820_outline_0040
                                   4400 	.globl _ak820_outline_0097
                                   4401 	.globl _ak820_outline_0122
                                   4402 	.globl _ak820_outline_0136
                                   4403 	.globl _ak820_outline_0159
                                   4404 	.globl _ak820_outline_0161
                                   4405 	.globl _ak820_outline_0163
                                   4406 	.globl _ak820_outline_0166
                                   4407 	.globl _ak820_outline_0185
                                   4408 
                                   4409 	.area CSEG (CODE)
                                   4410 ; function ak820_outline_0008
      00728A                       4411 _ak820_outline_0008:
      00728A 90 08 01         [24] 4412 	mov	dptr,#_ak820_usb_send_PARM_2
      00728D 74 9E            [12] 4413 	mov	a,#_raw_buffer
      00728F F0               [24] 4414 	movx	@dptr,a
      007290 74 07            [12] 4415 	mov	a,#(_raw_buffer>>8)
      007292 A3               [24] 4416 	inc	dptr
      007293 F0               [24] 4417 	movx	@dptr,a
      007294 90 08 03         [24] 4418 	mov	dptr,#_ak820_usb_send_PARM_3
      007297 74 20            [12] 4419 	mov	a,#0x20
      007299 F0               [24] 4420 	movx	@dptr,a
      00729A 75 82 03         [24] 4421 	mov	dpl,#0x03
      00729D 22               [24] 4422 	ret
                                   4423 
                                   4424 	.area CSEG (CODE)
                                   4425 ; function ak820_outline_0040
      00729E                       4426 _ak820_outline_0040:
      00729E 24 9E            [12] 4427 	add	a,#_raw_buffer
      0072A0 F5 82            [12] 4428 	mov	dpl,a
      0072A2 E4               [12] 4429 	clr	a
      0072A3 34 07            [12] 4430 	addc	a,#(_raw_buffer>>8)
      0072A5 F5 83            [12] 4431 	mov	dph,a
      0072A7 E4               [12] 4432 	clr	a
      0072A8 F0               [24] 4433 	movx	@dptr,a
      0072A9 22               [24] 4434 	ret
                                   4435 
                                   4436 	.area CSEG (CODE)
                                   4437 ; function ak820_outline_0136
      0072AA                       4438 _ak820_outline_0136:
      0072AA 89 82            [24] 4439 	mov	dpl,r1
      0072AC 8A 83            [24] 4440 	mov	dph,r2
      0072AE F0               [24] 4441 	movx	@dptr,a
      0072AF 22               [24] 4442 	ret
                                   4443 
                                   4444 	.area CSEG (CODE)
                                   4445 ; function ak820_outline_0161
      0072B0                       4446 _ak820_outline_0161:
      0072B0 90 07 9F         [24] 4447 	mov	dptr,#(_raw_buffer+0x0001)
      0072B3 E0               [24] 4448 	movx	a,@dptr
      0072B4 FF               [12] 4449 	mov	r7,a
      0072B5 22               [24] 4450 	ret
                                   4451 
                                   4452 	.area CSEG (CODE)
                                   4453 ; function ak820_outline_0163
      0072B6                       4454 _ak820_outline_0163:
      0072B6 90 07 9D         [24] 4455 	mov	dptr,#_raw_state
      0072B9 E0               [24] 4456 	movx	a,@dptr
      0072BA FF               [12] 4457 	mov	r7,a
      0072BB 22               [24] 4458 	ret
