                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_mousekey
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_usb_try_send
                                     12 	.globl _timer_read
                                     13 	.globl _ADC_START
                                     14 	.globl _S0_R_FIFO
                                     15 	.globl _S0_T_FIFO
                                     16 	.globl _S0_FREE
                                     17 	.globl _S0_IF_BYTE
                                     18 	.globl _S0_IF_FIRST
                                     19 	.globl _S0_IF_OV
                                     20 	.globl _S0_FST_ACT
                                     21 	.globl _CP_RL2
                                     22 	.globl _C_T2
                                     23 	.globl _TR2
                                     24 	.globl _EXEN2
                                     25 	.globl _TCLK
                                     26 	.globl _RCLK
                                     27 	.globl _EXF2
                                     28 	.globl _CAP1F
                                     29 	.globl _TF2
                                     30 	.globl _RI
                                     31 	.globl _TI
                                     32 	.globl _RB8
                                     33 	.globl _TB8
                                     34 	.globl _REN
                                     35 	.globl _SM2
                                     36 	.globl _SM1
                                     37 	.globl _SM0
                                     38 	.globl _IT0
                                     39 	.globl _IE0
                                     40 	.globl _IT1
                                     41 	.globl _IE1
                                     42 	.globl _TR0
                                     43 	.globl _TF0
                                     44 	.globl _TR1
                                     45 	.globl _TF1
                                     46 	.globl _P4_0
                                     47 	.globl _P4_1
                                     48 	.globl _P4_2
                                     49 	.globl _P4_3
                                     50 	.globl _P4_4
                                     51 	.globl _P4_5
                                     52 	.globl _P4_6
                                     53 	.globl _RXD
                                     54 	.globl _TXD
                                     55 	.globl _INT0
                                     56 	.globl _INT1
                                     57 	.globl _T0
                                     58 	.globl _T1
                                     59 	.globl _MOSI1
                                     60 	.globl _MISO1
                                     61 	.globl _SCK1
                                     62 	.globl _P3_0
                                     63 	.globl _P3_1
                                     64 	.globl _P3_2
                                     65 	.globl _P3_3
                                     66 	.globl _P3_4
                                     67 	.globl _P3_5
                                     68 	.globl _P3_6
                                     69 	.globl _P3_7
                                     70 	.globl _CAP1_
                                     71 	.globl _T2_
                                     72 	.globl _CAP2_
                                     73 	.globl _T2EX_
                                     74 	.globl _RXD1
                                     75 	.globl _TXD1
                                     76 	.globl _P2_0
                                     77 	.globl _P2_1
                                     78 	.globl _P2_2
                                     79 	.globl _P2_3
                                     80 	.globl _P2_4
                                     81 	.globl _P2_5
                                     82 	.globl _P2_6
                                     83 	.globl _P2_7
                                     84 	.globl _AIN0
                                     85 	.globl _AIN1
                                     86 	.globl _AIN2
                                     87 	.globl _AIN3
                                     88 	.globl _AIN4
                                     89 	.globl _AIN5
                                     90 	.globl _AIN6
                                     91 	.globl _AIN7
                                     92 	.globl _CAP1
                                     93 	.globl _T2
                                     94 	.globl _CAP2
                                     95 	.globl _T2EX
                                     96 	.globl _INT0_
                                     97 	.globl _SCS
                                     98 	.globl _MOSI
                                     99 	.globl _MISO
                                    100 	.globl _SCK
                                    101 	.globl _RXD1_
                                    102 	.globl _TXD1_
                                    103 	.globl _P1_0
                                    104 	.globl _P1_1
                                    105 	.globl _P1_2
                                    106 	.globl _P1_3
                                    107 	.globl _P1_4
                                    108 	.globl _P1_5
                                    109 	.globl _P1_6
                                    110 	.globl _P1_7
                                    111 	.globl _AIN8
                                    112 	.globl _AIN9
                                    113 	.globl _AIN10
                                    114 	.globl _AIN11
                                    115 	.globl _AIN12
                                    116 	.globl _AIN13
                                    117 	.globl _RXD_
                                    118 	.globl _TXD_
                                    119 	.globl _SCL0
                                    120 	.globl _SDA0
                                    121 	.globl _P0_0
                                    122 	.globl _P0_1
                                    123 	.globl _P0_2
                                    124 	.globl _P0_3
                                    125 	.globl _P0_4
                                    126 	.globl _P0_5
                                    127 	.globl _P0_6
                                    128 	.globl _P0_7
                                    129 	.globl _IE_SPI0
                                    130 	.globl _IE_USB
                                    131 	.globl _IE_ADC
                                    132 	.globl _IE_UART1
                                    133 	.globl _IE_PWM_I2C
                                    134 	.globl _IE_GPIO
                                    135 	.globl _IE_WDOG
                                    136 	.globl _PX0
                                    137 	.globl _PT0
                                    138 	.globl _PX1
                                    139 	.globl _PT1
                                    140 	.globl _PS
                                    141 	.globl _PT2
                                    142 	.globl _PL_FLAG
                                    143 	.globl _PH_FLAG
                                    144 	.globl _EX0
                                    145 	.globl _ET0
                                    146 	.globl _EX1
                                    147 	.globl _ET1
                                    148 	.globl _ES
                                    149 	.globl _ET2
                                    150 	.globl _E_DIS
                                    151 	.globl _EA
                                    152 	.globl _P
                                    153 	.globl _F1
                                    154 	.globl _OV
                                    155 	.globl _RS0
                                    156 	.globl _RS1
                                    157 	.globl _F0
                                    158 	.globl _AC
                                    159 	.globl _CY
                                    160 	.globl _I2CS_INT_ST
                                    161 	.globl _I2CX_INT
                                    162 	.globl _LED_STATUS
                                    163 	.globl _LED_DMA_H
                                    164 	.globl _LED_DMA_L
                                    165 	.globl _LED_DMA
                                    166 	.globl _LED_PWM_OE
                                    167 	.globl _LED_COMMON
                                    168 	.globl _ADC_CHAN
                                    169 	.globl _ADC_DAT_H
                                    170 	.globl _ADC_DAT_L
                                    171 	.globl _ADC_DAT
                                    172 	.globl _ADC_CTRL
                                    173 	.globl _SPI1_CK_SE
                                    174 	.globl _SPI1_CTRL
                                    175 	.globl _SPI1_DATA
                                    176 	.globl _SPI1_STAT
                                    177 	.globl _SIF1
                                    178 	.globl _SBAUD1
                                    179 	.globl _SBUF1
                                    180 	.globl _SCON1
                                    181 	.globl _SPI0_SETUP
                                    182 	.globl _SPI0_CK_SE
                                    183 	.globl _SPI0_CTRL
                                    184 	.globl _SPI0_DATA
                                    185 	.globl _SPI0_STAT
                                    186 	.globl _T2CAP1H
                                    187 	.globl _T2CAP1L
                                    188 	.globl _T2CAP1
                                    189 	.globl _TH2
                                    190 	.globl _TL2
                                    191 	.globl _T2COUNT
                                    192 	.globl _RCAP2H
                                    193 	.globl _RCAP2L
                                    194 	.globl _RCAP2
                                    195 	.globl _T2MOD
                                    196 	.globl _T2CON
                                    197 	.globl _SBUF
                                    198 	.globl _SCON
                                    199 	.globl _TH1
                                    200 	.globl _TH0
                                    201 	.globl _TL1
                                    202 	.globl _TL0
                                    203 	.globl _TMOD
                                    204 	.globl _TCON
                                    205 	.globl _XBUS_AUX
                                    206 	.globl _P7
                                    207 	.globl _P6_DIR
                                    208 	.globl _P6_OUT_PU
                                    209 	.globl _P6_IN
                                    210 	.globl _P5_DIR
                                    211 	.globl _P5_OUT_PU
                                    212 	.globl _P5_IN
                                    213 	.globl _P4_LED_KEY
                                    214 	.globl _P4_DIR_PU
                                    215 	.globl _P4_MOD_OC
                                    216 	.globl _P4
                                    217 	.globl _P3_DIR_PU
                                    218 	.globl _P3_MOD_OC
                                    219 	.globl _P3
                                    220 	.globl _P2_DIR_PU
                                    221 	.globl _P2_MOD_OC
                                    222 	.globl _P2
                                    223 	.globl _P1_DIR_PU
                                    224 	.globl _P1_MOD_OC
                                    225 	.globl _P1
                                    226 	.globl _P0_DIR_PU
                                    227 	.globl _P0_MOD_OC
                                    228 	.globl _P0
                                    229 	.globl _ROM_CTRL
                                    230 	.globl _ROM_DATA_HH
                                    231 	.globl _ROM_DATA_HL
                                    232 	.globl _ROM_DATA_HI
                                    233 	.globl _ROM_ADDR_H
                                    234 	.globl _ROM_ADDR_L
                                    235 	.globl _ROM_ADDR
                                    236 	.globl _GPIO_IE
                                    237 	.globl _IP_EX
                                    238 	.globl _IE_EX
                                    239 	.globl _IP
                                    240 	.globl _IE
                                    241 	.globl _WDOG_COUNT
                                    242 	.globl _RESET_KEEP
                                    243 	.globl _WAKE_CTRL
                                    244 	.globl _CLOCK_CFG
                                    245 	.globl _POWER_CFG
                                    246 	.globl _PCON
                                    247 	.globl _GLOBAL_CFG
                                    248 	.globl _SAFE_MOD
                                    249 	.globl _DPH
                                    250 	.globl _DPL
                                    251 	.globl _SP
                                    252 	.globl _A_INV
                                    253 	.globl _B
                                    254 	.globl _ACC
                                    255 	.globl _PSW
                                    256 	.globl _mousekey_on
                                    257 	.globl _mousekey_off
                                    258 	.globl _mousekey_send
                                    259 	.globl _mousekey_task
                                    260 	.globl _mousekey_clear
                                    261 ;--------------------------------------------------------
                                    262 ; special function registers
                                    263 ;--------------------------------------------------------
                                    264 	.area RSEG    (ABS,DATA)
      000000                        265 	.org 0x0000
                           0000D0   266 _PSW	=	0x00d0
                           0000E0   267 _ACC	=	0x00e0
                           0000F0   268 _B	=	0x00f0
                           0000FD   269 _A_INV	=	0x00fd
                           000081   270 _SP	=	0x0081
                           000082   271 _DPL	=	0x0082
                           000083   272 _DPH	=	0x0083
                           0000A1   273 _SAFE_MOD	=	0x00a1
                           0000B1   274 _GLOBAL_CFG	=	0x00b1
                           000087   275 _PCON	=	0x0087
                           0000BA   276 _POWER_CFG	=	0x00ba
                           0000B9   277 _CLOCK_CFG	=	0x00b9
                           0000A9   278 _WAKE_CTRL	=	0x00a9
                           0000FE   279 _RESET_KEEP	=	0x00fe
                           0000FF   280 _WDOG_COUNT	=	0x00ff
                           0000A8   281 _IE	=	0x00a8
                           0000B8   282 _IP	=	0x00b8
                           0000E8   283 _IE_EX	=	0x00e8
                           0000E9   284 _IP_EX	=	0x00e9
                           0000B2   285 _GPIO_IE	=	0x00b2
                           008584   286 _ROM_ADDR	=	0x8584
                           000084   287 _ROM_ADDR_L	=	0x0084
                           000085   288 _ROM_ADDR_H	=	0x0085
                           008F8E   289 _ROM_DATA_HI	=	0x8f8e
                           00008E   290 _ROM_DATA_HL	=	0x008e
                           00008F   291 _ROM_DATA_HH	=	0x008f
                           000086   292 _ROM_CTRL	=	0x0086
                           000080   293 _P0	=	0x0080
                           0000C4   294 _P0_MOD_OC	=	0x00c4
                           0000C5   295 _P0_DIR_PU	=	0x00c5
                           000090   296 _P1	=	0x0090
                           000092   297 _P1_MOD_OC	=	0x0092
                           000093   298 _P1_DIR_PU	=	0x0093
                           0000A0   299 _P2	=	0x00a0
                           000094   300 _P2_MOD_OC	=	0x0094
                           000095   301 _P2_DIR_PU	=	0x0095
                           0000B0   302 _P3	=	0x00b0
                           000096   303 _P3_MOD_OC	=	0x0096
                           000097   304 _P3_DIR_PU	=	0x0097
                           0000C0   305 _P4	=	0x00c0
                           0000C2   306 _P4_MOD_OC	=	0x00c2
                           0000C3   307 _P4_DIR_PU	=	0x00c3
                           0000C1   308 _P4_LED_KEY	=	0x00c1
                           0000AA   309 _P5_IN	=	0x00aa
                           0000AB   310 _P5_OUT_PU	=	0x00ab
                           0000AC   311 _P5_DIR	=	0x00ac
                           0000AD   312 _P6_IN	=	0x00ad
                           0000AE   313 _P6_OUT_PU	=	0x00ae
                           0000AF   314 _P6_DIR	=	0x00af
                           0000F1   315 _P7	=	0x00f1
                           0000A2   316 _XBUS_AUX	=	0x00a2
                           000088   317 _TCON	=	0x0088
                           000089   318 _TMOD	=	0x0089
                           00008A   319 _TL0	=	0x008a
                           00008B   320 _TL1	=	0x008b
                           00008C   321 _TH0	=	0x008c
                           00008D   322 _TH1	=	0x008d
                           000098   323 _SCON	=	0x0098
                           000099   324 _SBUF	=	0x0099
                           0000C8   325 _T2CON	=	0x00c8
                           0000C9   326 _T2MOD	=	0x00c9
                           00CBCA   327 _RCAP2	=	0xcbca
                           0000CA   328 _RCAP2L	=	0x00ca
                           0000CB   329 _RCAP2H	=	0x00cb
                           00CDCC   330 _T2COUNT	=	0xcdcc
                           0000CC   331 _TL2	=	0x00cc
                           0000CD   332 _TH2	=	0x00cd
                           00CFCE   333 _T2CAP1	=	0xcfce
                           0000CE   334 _T2CAP1L	=	0x00ce
                           0000CF   335 _T2CAP1H	=	0x00cf
                           0000F8   336 _SPI0_STAT	=	0x00f8
                           0000F9   337 _SPI0_DATA	=	0x00f9
                           0000FA   338 _SPI0_CTRL	=	0x00fa
                           0000FB   339 _SPI0_CK_SE	=	0x00fb
                           0000FC   340 _SPI0_SETUP	=	0x00fc
                           0000BC   341 _SCON1	=	0x00bc
                           0000BD   342 _SBUF1	=	0x00bd
                           0000BE   343 _SBAUD1	=	0x00be
                           0000BF   344 _SIF1	=	0x00bf
                           0000B4   345 _SPI1_STAT	=	0x00b4
                           0000B5   346 _SPI1_DATA	=	0x00b5
                           0000B6   347 _SPI1_CTRL	=	0x00b6
                           0000B7   348 _SPI1_CK_SE	=	0x00b7
                           0000F3   349 _ADC_CTRL	=	0x00f3
                           00F5F4   350 _ADC_DAT	=	0xf5f4
                           0000F4   351 _ADC_DAT_L	=	0x00f4
                           0000F5   352 _ADC_DAT_H	=	0x00f5
                           0000F6   353 _ADC_CHAN	=	0x00f6
                           0000A6   354 _LED_COMMON	=	0x00a6
                           0000A7   355 _LED_PWM_OE	=	0x00a7
                           00C7C6   356 _LED_DMA	=	0xc7c6
                           0000C6   357 _LED_DMA_L	=	0x00c6
                           0000C7   358 _LED_DMA_H	=	0x00c7
                           0000F7   359 _LED_STATUS	=	0x00f7
                           0000B3   360 _I2CX_INT	=	0x00b3
                           0000BB   361 _I2CS_INT_ST	=	0x00bb
                                    362 ;--------------------------------------------------------
                                    363 ; special function bits
                                    364 ;--------------------------------------------------------
                                    365 	.area RSEG    (ABS,DATA)
      000000                        366 	.org 0x0000
                           0000D7   367 _CY	=	0x00d7
                           0000D6   368 _AC	=	0x00d6
                           0000D5   369 _F0	=	0x00d5
                           0000D4   370 _RS1	=	0x00d4
                           0000D3   371 _RS0	=	0x00d3
                           0000D2   372 _OV	=	0x00d2
                           0000D1   373 _F1	=	0x00d1
                           0000D0   374 _P	=	0x00d0
                           0000AF   375 _EA	=	0x00af
                           0000AE   376 _E_DIS	=	0x00ae
                           0000AD   377 _ET2	=	0x00ad
                           0000AC   378 _ES	=	0x00ac
                           0000AB   379 _ET1	=	0x00ab
                           0000AA   380 _EX1	=	0x00aa
                           0000A9   381 _ET0	=	0x00a9
                           0000A8   382 _EX0	=	0x00a8
                           0000BF   383 _PH_FLAG	=	0x00bf
                           0000BE   384 _PL_FLAG	=	0x00be
                           0000BD   385 _PT2	=	0x00bd
                           0000BC   386 _PS	=	0x00bc
                           0000BB   387 _PT1	=	0x00bb
                           0000BA   388 _PX1	=	0x00ba
                           0000B9   389 _PT0	=	0x00b9
                           0000B8   390 _PX0	=	0x00b8
                           0000EF   391 _IE_WDOG	=	0x00ef
                           0000EE   392 _IE_GPIO	=	0x00ee
                           0000ED   393 _IE_PWM_I2C	=	0x00ed
                           0000EC   394 _IE_UART1	=	0x00ec
                           0000EB   395 _IE_ADC	=	0x00eb
                           0000E9   396 _IE_USB	=	0x00e9
                           0000E8   397 _IE_SPI0	=	0x00e8
                           000087   398 _P0_7	=	0x0087
                           000086   399 _P0_6	=	0x0086
                           000085   400 _P0_5	=	0x0085
                           000084   401 _P0_4	=	0x0084
                           000083   402 _P0_3	=	0x0083
                           000082   403 _P0_2	=	0x0082
                           000081   404 _P0_1	=	0x0081
                           000080   405 _P0_0	=	0x0080
                           000081   406 _SDA0	=	0x0081
                           000080   407 _SCL0	=	0x0080
                           000083   408 _TXD_	=	0x0083
                           000082   409 _RXD_	=	0x0082
                           000085   410 _AIN13	=	0x0085
                           000084   411 _AIN12	=	0x0084
                           000083   412 _AIN11	=	0x0083
                           000082   413 _AIN10	=	0x0082
                           000081   414 _AIN9	=	0x0081
                           000080   415 _AIN8	=	0x0080
                           000097   416 _P1_7	=	0x0097
                           000096   417 _P1_6	=	0x0096
                           000095   418 _P1_5	=	0x0095
                           000094   419 _P1_4	=	0x0094
                           000093   420 _P1_3	=	0x0093
                           000092   421 _P1_2	=	0x0092
                           000091   422 _P1_1	=	0x0091
                           000090   423 _P1_0	=	0x0090
                           000097   424 _TXD1_	=	0x0097
                           000096   425 _RXD1_	=	0x0096
                           000097   426 _SCK	=	0x0097
                           000096   427 _MISO	=	0x0096
                           000095   428 _MOSI	=	0x0095
                           000094   429 _SCS	=	0x0094
                           000092   430 _INT0_	=	0x0092
                           000091   431 _T2EX	=	0x0091
                           000091   432 _CAP2	=	0x0091
                           000090   433 _T2	=	0x0090
                           000090   434 _CAP1	=	0x0090
                           000097   435 _AIN7	=	0x0097
                           000096   436 _AIN6	=	0x0096
                           000095   437 _AIN5	=	0x0095
                           000094   438 _AIN4	=	0x0094
                           000093   439 _AIN3	=	0x0093
                           000092   440 _AIN2	=	0x0092
                           000091   441 _AIN1	=	0x0091
                           000090   442 _AIN0	=	0x0090
                           0000A7   443 _P2_7	=	0x00a7
                           0000A6   444 _P2_6	=	0x00a6
                           0000A5   445 _P2_5	=	0x00a5
                           0000A4   446 _P2_4	=	0x00a4
                           0000A3   447 _P2_3	=	0x00a3
                           0000A2   448 _P2_2	=	0x00a2
                           0000A1   449 _P2_1	=	0x00a1
                           0000A0   450 _P2_0	=	0x00a0
                           0000A7   451 _TXD1	=	0x00a7
                           0000A6   452 _RXD1	=	0x00a6
                           0000A5   453 _T2EX_	=	0x00a5
                           0000A5   454 _CAP2_	=	0x00a5
                           0000A4   455 _T2_	=	0x00a4
                           0000A4   456 _CAP1_	=	0x00a4
                           0000B7   457 _P3_7	=	0x00b7
                           0000B6   458 _P3_6	=	0x00b6
                           0000B5   459 _P3_5	=	0x00b5
                           0000B4   460 _P3_4	=	0x00b4
                           0000B3   461 _P3_3	=	0x00b3
                           0000B2   462 _P3_2	=	0x00b2
                           0000B1   463 _P3_1	=	0x00b1
                           0000B0   464 _P3_0	=	0x00b0
                           0000B7   465 _SCK1	=	0x00b7
                           0000B6   466 _MISO1	=	0x00b6
                           0000B5   467 _MOSI1	=	0x00b5
                           0000B5   468 _T1	=	0x00b5
                           0000B4   469 _T0	=	0x00b4
                           0000B3   470 _INT1	=	0x00b3
                           0000B2   471 _INT0	=	0x00b2
                           0000B1   472 _TXD	=	0x00b1
                           0000B0   473 _RXD	=	0x00b0
                           0000C6   474 _P4_6	=	0x00c6
                           0000C5   475 _P4_5	=	0x00c5
                           0000C4   476 _P4_4	=	0x00c4
                           0000C3   477 _P4_3	=	0x00c3
                           0000C2   478 _P4_2	=	0x00c2
                           0000C1   479 _P4_1	=	0x00c1
                           0000C0   480 _P4_0	=	0x00c0
                           00008F   481 _TF1	=	0x008f
                           00008E   482 _TR1	=	0x008e
                           00008D   483 _TF0	=	0x008d
                           00008C   484 _TR0	=	0x008c
                           00008B   485 _IE1	=	0x008b
                           00008A   486 _IT1	=	0x008a
                           000089   487 _IE0	=	0x0089
                           000088   488 _IT0	=	0x0088
                           00009F   489 _SM0	=	0x009f
                           00009E   490 _SM1	=	0x009e
                           00009D   491 _SM2	=	0x009d
                           00009C   492 _REN	=	0x009c
                           00009B   493 _TB8	=	0x009b
                           00009A   494 _RB8	=	0x009a
                           000099   495 _TI	=	0x0099
                           000098   496 _RI	=	0x0098
                           0000CF   497 _TF2	=	0x00cf
                           0000CF   498 _CAP1F	=	0x00cf
                           0000CE   499 _EXF2	=	0x00ce
                           0000CD   500 _RCLK	=	0x00cd
                           0000CC   501 _TCLK	=	0x00cc
                           0000CB   502 _EXEN2	=	0x00cb
                           0000CA   503 _TR2	=	0x00ca
                           0000C9   504 _C_T2	=	0x00c9
                           0000C8   505 _CP_RL2	=	0x00c8
                           0000FF   506 _S0_FST_ACT	=	0x00ff
                           0000FE   507 _S0_IF_OV	=	0x00fe
                           0000FD   508 _S0_IF_FIRST	=	0x00fd
                           0000FC   509 _S0_IF_BYTE	=	0x00fc
                           0000FB   510 _S0_FREE	=	0x00fb
                           0000FA   511 _S0_T_FIFO	=	0x00fa
                           0000F8   512 _S0_R_FIFO	=	0x00f8
                           0000F7   513 _ADC_START	=	0x00f7
                                    514 ;--------------------------------------------------------
                                    515 ; overlayable register banks
                                    516 ;--------------------------------------------------------
                                    517 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        518 	.ds 8
                                    519 ;--------------------------------------------------------
                                    520 ; internal ram data
                                    521 ;--------------------------------------------------------
                                    522 	.area DSEG    (DATA)
                                    523 ;--------------------------------------------------------
                                    524 ; overlayable items in internal ram
                                    525 ;--------------------------------------------------------
                                    526 ;--------------------------------------------------------
                                    527 ; indirectly addressable internal ram data
                                    528 ;--------------------------------------------------------
                                    529 	.area ISEG    (DATA)
                                    530 ;--------------------------------------------------------
                                    531 ; absolute internal ram data
                                    532 ;--------------------------------------------------------
                                    533 	.area IABS    (ABS,DATA)
                                    534 	.area IABS    (ABS,DATA)
                                    535 ;--------------------------------------------------------
                                    536 ; bit data
                                    537 ;--------------------------------------------------------
                                    538 	.area BSEG    (BIT)
                                    539 ;--------------------------------------------------------
                                    540 ; paged external ram data
                                    541 ;--------------------------------------------------------
                                    542 	.area PSEG    (PAG,XDATA)
                                    543 ;--------------------------------------------------------
                                    544 ; uninitialized external ram data
                                    545 ;--------------------------------------------------------
                                    546 	.area XSEG    (XDATA)
      0006C2                        547 _directions:
      0006C2                        548 	.ds 1
      0006C3                        549 _immediate:
      0006C3                        550 	.ds 1
      0006C4                        551 _buttons:
      0006C4                        552 	.ds 1
      0006C5                        553 _accepted_buttons:
      0006C5                        554 	.ds 1
      0006C6                        555 _cursor_time:
      0006C6                        556 	.ds 2
      0006C8                        557 _wheel_time:
      0006C8                        558 	.ds 2
      0006CA                        559 _mouse_report:
      0006CA                        560 	.ds 6
      0006D0                        561 _direction_bit_code_10000_129:
      0006D0                        562 	.ds 1
      0006D1                        563 _mousekey_on_code_10000_133:
      0006D1                        564 	.ds 1
      0006D2                        565 _mousekey_off_code_10000_140:
      0006D2                        566 	.ds 1
      0006D3                        567 _axis_selected_10000_143:
      0006D3                        568 	.ds 1
      0006D4                        569 _mousekey_send_selected_10000_148:
      0006D4                        570 	.ds 1
                                    571 ;--------------------------------------------------------
                                    572 ; absolute external ram data
                                    573 ;--------------------------------------------------------
                                    574 	.area XABS    (ABS,XDATA)
                                    575 ;--------------------------------------------------------
                                    576 ; initialized external ram data
                                    577 ;--------------------------------------------------------
                                    578 	.area XISEG   (XDATA)
                                    579 	.area HOME    (CODE)
                                    580 	.area GSINIT0 (CODE)
                                    581 	.area GSINIT1 (CODE)
                                    582 	.area GSINIT2 (CODE)
                                    583 	.area GSINIT3 (CODE)
                                    584 	.area GSINIT4 (CODE)
                                    585 	.area GSINIT5 (CODE)
                                    586 	.area GSINIT  (CODE)
                                    587 	.area GSFINAL (CODE)
                                    588 	.area CSEG    (CODE)
                                    589 ;--------------------------------------------------------
                                    590 ; global & static initialisations
                                    591 ;--------------------------------------------------------
                                    592 	.area HOME    (CODE)
                                    593 	.area GSINIT  (CODE)
                                    594 	.area GSFINAL (CODE)
                                    595 	.area GSINIT  (CODE)
                                    596 ;--------------------------------------------------------
                                    597 ; Home
                                    598 ;--------------------------------------------------------
                                    599 	.area HOME    (CODE)
                                    600 	.area HOME    (CODE)
                                    601 ;--------------------------------------------------------
                                    602 ; code
                                    603 ;--------------------------------------------------------
                                    604 	.area CSEG    (CODE)
                                    605 ;------------------------------------------------------------
                                    606 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    607 ;------------------------------------------------------------
                                    608 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    609 ;------------------------------------------------------------
                                    610 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    611 ;	-----------------------------------------
                           000007   612 	ar7 = 0x07
                           000006   613 	ar6 = 0x06
                           000005   614 	ar5 = 0x05
                           000004   615 	ar4 = 0x04
                           000003   616 	ar3 = 0x03
                           000002   617 	ar2 = 0x02
                           000001   618 	ar1 = 0x01
                           000000   619 	ar0 = 0x00
                                    620 ;	 function direction_bit
                                    621 ;	-----------------------------------------
      00529F                        622 _direction_bit:
      00529F E5 82            [12]  623 	mov	a,dpl
      0052A1 90 06 D0         [24]  624 	mov	dptr,#_direction_bit_code_10000_129
      0052A4 F0               [24]  625 	movx	@dptr,a
                                    626 ;	keyboards/ajazz/ak820/ak820_mousekey.c:24: if (code >= KC_MS_UP && code <= KC_MS_RIGHT) return (uint8_t)(1u << (code - KC_MS_UP));
      0052A5 E0               [24]  627 	movx	a,@dptr
      0052A6 FF               [12]  628 	mov	r7,a
      0052A7 BF CD 00         [24]  629 	cjne	r7,#0xcd,00137$
      0052AA                        630 00137$:
      0052AA 40 18            [24]  631 	jc	00102$
      0052AC EF               [12]  632 	mov	a,r7
      0052AD 24 2F            [12]  633 	add	a,#0xff - 0xd0
      0052AF 40 13            [24]  634 	jc	00102$
                                    635 ;	free result
      0052B1 EF               [12]  636 	mov	a,r7
      0052B2 24 33            [12]  637 	add	a,#0x33
      0052B4 F5 F0            [12]  638 	mov	b,a
      0052B6 05 F0            [12]  639 	inc	b
      0052B8 74 01            [12]  640 	mov	a,#0x01
      0052BA 80 02            [24]  641 	sjmp	00141$
      0052BC                        642 00140$:
      0052BC 25 E0            [12]  643 	add	a,acc
      0052BE                        644 00141$:
      0052BE D5 F0 FB         [24]  645 	djnz	b,00140$
      0052C1 F5 82            [12]  646 	mov	dpl,a
      0052C3 22               [24]  647 	ret
      0052C4                        648 00102$:
                                    649 ;	keyboards/ajazz/ak820/ak820_mousekey.c:25: if (code >= KC_MS_WH_UP && code <= KC_MS_WH_RIGHT) return (uint8_t)(0x10u << (code - KC_MS_WH_UP));
      0052C4 90 06 D0         [24]  650 	mov	dptr,#_direction_bit_code_10000_129
      0052C7 E0               [24]  651 	movx	a,@dptr
      0052C8 FF               [12]  652 	mov	r7,a
      0052C9 BF D9 00         [24]  653 	cjne	r7,#0xd9,00142$
      0052CC                        654 00142$:
      0052CC 40 18            [24]  655 	jc	00105$
      0052CE EF               [12]  656 	mov	a,r7
      0052CF 24 23            [12]  657 	add	a,#0xff - 0xdc
      0052D1 40 13            [24]  658 	jc	00105$
                                    659 ;	free result
      0052D3 EF               [12]  660 	mov	a,r7
      0052D4 24 27            [12]  661 	add	a,#0x27
      0052D6 F5 F0            [12]  662 	mov	b,a
      0052D8 05 F0            [12]  663 	inc	b
      0052DA 74 10            [12]  664 	mov	a,#0x10
      0052DC 80 02            [24]  665 	sjmp	00146$
      0052DE                        666 00145$:
      0052DE 25 E0            [12]  667 	add	a,acc
      0052E0                        668 00146$:
      0052E0 D5 F0 FB         [24]  669 	djnz	b,00145$
      0052E3 F5 82            [12]  670 	mov	dpl,a
      0052E5 22               [24]  671 	ret
      0052E6                        672 00105$:
                                    673 ;	keyboards/ajazz/ak820/ak820_mousekey.c:26: return 0;
      0052E6 75 82 00         [24]  674 	mov	dpl, #0x00
                                    675 ;	keyboards/ajazz/ak820/ak820_mousekey.c:27: }
      0052E9 22               [24]  676 	ret
                                    677 ;------------------------------------------------------------
                                    678 ;Allocation info for local variables in function 'mousekey_on'
                                    679 ;------------------------------------------------------------
                                    680 ;code          Allocated with name '_mousekey_on_code_10000_133'
                                    681 ;bit           Allocated with name '_mousekey_on_bit_10000_134'
                                    682 ;------------------------------------------------------------
                                    683 ;	keyboards/ajazz/ak820/ak820_mousekey.c:29: void mousekey_on(uint8_t code) {
                                    684 ;	-----------------------------------------
                                    685 ;	 function mousekey_on
                                    686 ;	-----------------------------------------
      0052EA                        687 _mousekey_on:
      0052EA E5 82            [12]  688 	mov	a,dpl
      0052EC 90 06 D1         [24]  689 	mov	dptr,#_mousekey_on_code_10000_133
      0052EF F0               [24]  690 	movx	@dptr,a
                                    691 ;	keyboards/ajazz/ak820/ak820_mousekey.c:30: uint8_t bit = direction_bit(code);
      0052F0 E0               [24]  692 	movx	a,@dptr
      0052F1 F5 82            [12]  693 	mov	dpl,a
      0052F3 12 52 9F         [24]  694 	lcall	_direction_bit
                                    695 ;	keyboards/ajazz/ak820/ak820_mousekey.c:31: if (bit && !(directions & bit)) {
      0052F6 E5 82            [12]  696 	mov	a,dpl
      0052F8 FF               [12]  697 	mov	r7,a
      0052F9 60 3C            [24]  698 	jz	00108$
      0052FB 90 06 C2         [24]  699 	mov	dptr,#_directions
      0052FE E0               [24]  700 	movx	a,@dptr
      0052FF FE               [12]  701 	mov	r6,a
      005300 EF               [12]  702 	mov	a,r7
      005301 5E               [12]  703 	anl	a,r6
      005302 70 33            [24]  704 	jnz	00108$
                                    705 ;	keyboards/ajazz/ak820/ak820_mousekey.c:32: immediate |= bit;
      005304 90 06 C3         [24]  706 	mov	dptr,#_immediate
      005307 E0               [24]  707 	movx	a,@dptr
      005308 4F               [12]  708 	orl	a,r7
      005309 F0               [24]  709 	movx	@dptr,a
                                    710 ;	keyboards/ajazz/ak820/ak820_mousekey.c:33: directions |= bit;
      00530A 90 06 C2         [24]  711 	mov	dptr,#_directions
      00530D EF               [12]  712 	mov	a,r7
      00530E 4E               [12]  713 	orl	a,r6
      00530F F0               [24]  714 	movx	@dptr,a
                                    715 ;	keyboards/ajazz/ak820/ak820_mousekey.c:34: if (bit & 0x0f) cursor_time = timer_read();
      005310 EF               [12]  716 	mov	a,r7
      005311 54 0F            [12]  717 	anl	a,#0x0f
      005313 60 11            [24]  718 	jz	00102$
      005315 12 4C 69         [24]  719 	lcall	_timer_read
      005318 E5 82            [12]  720 	mov	a, dpl
      00531A 85 83 F0         [24]  721 	mov	b, dph
      00531D 90 06 C6         [24]  722 	mov	dptr,#_cursor_time
      005320 F0               [24]  723 	movx	@dptr,a
      005321 E5 F0            [12]  724 	mov	a,b
      005323 A3               [24]  725 	inc	dptr
      005324 F0               [24]  726 	movx	@dptr,a
      005325 22               [24]  727 	ret
      005326                        728 00102$:
                                    729 ;	keyboards/ajazz/ak820/ak820_mousekey.c:35: else wheel_time = timer_read();
      005326 12 4C 69         [24]  730 	lcall	_timer_read
      005329 E5 82            [12]  731 	mov	a, dpl
      00532B 85 83 F0         [24]  732 	mov	b, dph
      00532E 90 06 C8         [24]  733 	mov	dptr,#_wheel_time
      005331 F0               [24]  734 	movx	@dptr,a
      005332 E5 F0            [12]  735 	mov	a,b
      005334 A3               [24]  736 	inc	dptr
      005335 F0               [24]  737 	movx	@dptr,a
      005336 22               [24]  738 	ret
      005337                        739 00108$:
                                    740 ;	keyboards/ajazz/ak820/ak820_mousekey.c:36: } else if (code >= KC_MS_BTN1 && code <= KC_MS_BTN5) {
      005337 90 06 D1         [24]  741 	mov	dptr,#_mousekey_on_code_10000_133
      00533A E0               [24]  742 	movx	a,@dptr
      00533B FF               [12]  743 	mov	r7,a
      00533C BF D1 00         [24]  744 	cjne	r7,#0xd1,00151$
      00533F                        745 00151$:
      00533F 40 1C            [24]  746 	jc	00111$
      005341 EF               [12]  747 	mov	a,r7
      005342 24 2A            [12]  748 	add	a,#0xff - 0xd5
      005344 40 17            [24]  749 	jc	00111$
                                    750 ;	free result
                                    751 ;	keyboards/ajazz/ak820/ak820_mousekey.c:37: buttons |= (uint8_t)(1u << (code - KC_MS_BTN1));
      005346 EF               [12]  752 	mov	a,r7
      005347 24 2F            [12]  753 	add	a,#0x2f
      005349 F5 F0            [12]  754 	mov	b,a
      00534B 05 F0            [12]  755 	inc	b
      00534D 74 01            [12]  756 	mov	a,#0x01
      00534F 80 02            [24]  757 	sjmp	00155$
      005351                        758 00154$:
      005351 25 E0            [12]  759 	add	a,acc
      005353                        760 00155$:
      005353 D5 F0 FB         [24]  761 	djnz	b,00154$
      005356 FF               [12]  762 	mov	r7,a
      005357 90 06 C4         [24]  763 	mov	dptr,#_buttons
      00535A E0               [24]  764 	movx	a,@dptr
      00535B 4F               [12]  765 	orl	a,r7
      00535C F0               [24]  766 	movx	@dptr,a
      00535D                        767 00111$:
                                    768 ;	keyboards/ajazz/ak820/ak820_mousekey.c:39: }
      00535D 22               [24]  769 	ret
                                    770 ;------------------------------------------------------------
                                    771 ;Allocation info for local variables in function 'mousekey_off'
                                    772 ;------------------------------------------------------------
                                    773 ;code          Allocated with name '_mousekey_off_code_10000_140'
                                    774 ;bit           Allocated with name '_mousekey_off_bit_10000_141'
                                    775 ;------------------------------------------------------------
                                    776 ;	keyboards/ajazz/ak820/ak820_mousekey.c:41: void mousekey_off(uint8_t code) {
                                    777 ;	-----------------------------------------
                                    778 ;	 function mousekey_off
                                    779 ;	-----------------------------------------
      00535E                        780 _mousekey_off:
      00535E E5 82            [12]  781 	mov	a,dpl
      005360 90 06 D2         [24]  782 	mov	dptr,#_mousekey_off_code_10000_140
      005363 F0               [24]  783 	movx	@dptr,a
                                    784 ;	keyboards/ajazz/ak820/ak820_mousekey.c:42: uint8_t bit = direction_bit(code);
      005364 E0               [24]  785 	movx	a,@dptr
      005365 FF               [12]  786 	mov	r7,a
      005366 F5 82            [12]  787 	mov	dpl,a
      005368 C0 07            [24]  788 	push	ar7
      00536A 12 52 9F         [24]  789 	lcall	_direction_bit
      00536D E5 82            [12]  790 	mov	a, dpl
      00536F D0 07            [24]  791 	pop	ar7
                                    792 ;	keyboards/ajazz/ak820/ak820_mousekey.c:43: directions &= (uint8_t)~bit;
      005371 F4               [12]  793 	cpl	a
      005372 FE               [12]  794 	mov	r6,a
      005373 90 06 C2         [24]  795 	mov	dptr,#_directions
      005376 E0               [24]  796 	movx	a,@dptr
      005377 5E               [12]  797 	anl	a,r6
      005378 F0               [24]  798 	movx	@dptr,a
                                    799 ;	keyboards/ajazz/ak820/ak820_mousekey.c:44: immediate &= (uint8_t)~bit;
      005379 90 06 C3         [24]  800 	mov	dptr,#_immediate
      00537C E0               [24]  801 	movx	a,@dptr
      00537D 5E               [12]  802 	anl	a,r6
      00537E F0               [24]  803 	movx	@dptr,a
                                    804 ;	keyboards/ajazz/ak820/ak820_mousekey.c:45: if (code >= KC_MS_BTN1 && code <= KC_MS_BTN5) buttons &= (uint8_t)~(1u << (code - KC_MS_BTN1));
      00537F BF D1 00         [24]  805 	cjne	r7,#0xd1,00120$
      005382                        806 00120$:
      005382 40 1D            [24]  807 	jc	00104$
      005384 EF               [12]  808 	mov	a,r7
      005385 24 2A            [12]  809 	add	a,#0xff - 0xd5
      005387 40 18            [24]  810 	jc	00104$
                                    811 ;	free result
      005389 EF               [12]  812 	mov	a,r7
      00538A 24 2F            [12]  813 	add	a,#0x2f
      00538C F5 F0            [12]  814 	mov	b,a
      00538E 05 F0            [12]  815 	inc	b
      005390 74 01            [12]  816 	mov	a,#0x01
      005392 80 02            [24]  817 	sjmp	00124$
      005394                        818 00123$:
      005394 25 E0            [12]  819 	add	a,acc
      005396                        820 00124$:
      005396 D5 F0 FB         [24]  821 	djnz	b,00123$
      005399 F4               [12]  822 	cpl	a
      00539A FF               [12]  823 	mov	r7,a
      00539B 90 06 C4         [24]  824 	mov	dptr,#_buttons
      00539E E0               [24]  825 	movx	a,@dptr
      00539F 5F               [12]  826 	anl	a,r7
      0053A0 F0               [24]  827 	movx	@dptr,a
      0053A1                        828 00104$:
                                    829 ;	keyboards/ajazz/ak820/ak820_mousekey.c:46: }
      0053A1 22               [24]  830 	ret
                                    831 ;------------------------------------------------------------
                                    832 ;Allocation info for local variables in function 'axis'
                                    833 ;------------------------------------------------------------
                                    834 ;selected      Allocated with name '_axis_selected_10000_143'
                                    835 ;------------------------------------------------------------
                                    836 ;	keyboards/ajazz/ak820/ak820_mousekey.c:49: static int8_t axis(uint8_t selected) {
                                    837 ;	-----------------------------------------
                                    838 ;	 function axis
                                    839 ;	-----------------------------------------
      0053A2                        840 _axis:
      0053A2 E5 82            [12]  841 	mov	a,dpl
      0053A4 90 06 D3         [24]  842 	mov	dptr,#_axis_selected_10000_143
      0053A7 F0               [24]  843 	movx	@dptr,a
                                    844 ;	keyboards/ajazz/ak820/ak820_mousekey.c:50: if (selected & 1) return -1;
      0053A8 E0               [24]  845 	movx	a,@dptr
      0053A9 FF               [12]  846 	mov	r7,a
      0053AA 30 E0 04         [24]  847 	jnb	acc.0,00102$
      0053AD 75 82 FF         [24]  848 	mov	dpl, #0xff
      0053B0 22               [24]  849 	ret
      0053B1                        850 00102$:
                                    851 ;	keyboards/ajazz/ak820/ak820_mousekey.c:51: if (selected & 2) return 1;
      0053B1 EF               [12]  852 	mov	a,r7
      0053B2 30 E1 04         [24]  853 	jnb	acc.1,00104$
      0053B5 75 82 01         [24]  854 	mov	dpl, #0x01
      0053B8 22               [24]  855 	ret
      0053B9                        856 00104$:
                                    857 ;	keyboards/ajazz/ak820/ak820_mousekey.c:52: return 0;
      0053B9 75 82 00         [24]  858 	mov	dpl, #0x00
                                    859 ;	keyboards/ajazz/ak820/ak820_mousekey.c:53: }
      0053BC 22               [24]  860 	ret
                                    861 ;------------------------------------------------------------
                                    862 ;Allocation info for local variables in function 'mousekey_send'
                                    863 ;------------------------------------------------------------
                                    864 ;selected      Allocated with name '_mousekey_send_selected_10000_148'
                                    865 ;opposed       Allocated with name '_mousekey_send_opposed_10000_148'
                                    866 ;------------------------------------------------------------
                                    867 ;	keyboards/ajazz/ak820/ak820_mousekey.c:55: void mousekey_send(void) {
                                    868 ;	-----------------------------------------
                                    869 ;	 function mousekey_send
                                    870 ;	-----------------------------------------
      0053BD                        871 _mousekey_send:
                                    872 ;	keyboards/ajazz/ak820/ak820_mousekey.c:56: uint8_t selected = immediate;
      0053BD 90 06 C3         [24]  873 	mov	dptr,#_immediate
      0053C0 E0               [24]  874 	movx	a,@dptr
      0053C1 FF               [12]  875 	mov	r7,a
                                    876 ;	keyboards/ajazz/ak820/ak820_mousekey.c:57: uint8_t opposed = directions & (directions >> 1) & 0x55;
      0053C2 90 06 C2         [24]  877 	mov	dptr,#_directions
      0053C5 E0               [24]  878 	movx	a,@dptr
      0053C6 FE               [12]  879 	mov	r6,a
      0053C7 C3               [12]  880 	clr	c
      0053C8 13               [12]  881 	rrc	a
      0053C9 5E               [12]  882 	anl	a,r6
      0053CA 54 55            [12]  883 	anl	a,#0x55
                                    884 ;	keyboards/ajazz/ak820/ak820_mousekey.c:58: selected &= (uint8_t)~(opposed | (opposed << 1));
      0053CC FE               [12]  885 	mov	r6,a
      0053CD 25 E0            [12]  886 	add	a,acc
      0053CF 4E               [12]  887 	orl	a,r6
      0053D0 F4               [12]  888 	cpl	a
      0053D1 90 06 D4         [24]  889 	mov	dptr,#_mousekey_send_selected_10000_148
      0053D4 5F               [12]  890 	anl	a,r7
      0053D5 F0               [24]  891 	movx	@dptr,a
                                    892 ;	keyboards/ajazz/ak820/ak820_mousekey.c:59: immediate = 0; /* Relative movement never accumulates behind a busy endpoint. */
      0053D6 90 06 C3         [24]  893 	mov	dptr,#_immediate
      0053D9 E4               [12]  894 	clr	a
      0053DA F0               [24]  895 	movx	@dptr,a
                                    896 ;	keyboards/ajazz/ak820/ak820_mousekey.c:61: mouse_report.report_id = REPORT_ID_MOUSE;
      0053DB 90 06 CA         [24]  897 	mov	dptr,#_mouse_report
      0053DE 74 02            [12]  898 	mov	a,#0x02
      0053E0 F0               [24]  899 	movx	@dptr,a
                                    900 ;	keyboards/ajazz/ak820/ak820_mousekey.c:63: mouse_report.buttons = buttons;
      0053E1 90 06 C4         [24]  901 	mov	dptr,#_buttons
      0053E4 E0               [24]  902 	movx	a,@dptr
      0053E5 90 06 CB         [24]  903 	mov	dptr,#(_mouse_report + 0x0001)
      0053E8 F0               [24]  904 	movx	@dptr,a
                                    905 ;	keyboards/ajazz/ak820/ak820_mousekey.c:64: mouse_report.x = axis(selected >> 2) * 8;
      0053E9 90 06 D4         [24]  906 	mov	dptr,#_mousekey_send_selected_10000_148
      0053EC E0               [24]  907 	movx	a,@dptr
      0053ED FF               [12]  908 	mov	r7,a
      0053EE 03               [12]  909 	rr	a
      0053EF 03               [12]  910 	rr	a
      0053F0 54 3F            [12]  911 	anl	a,#0x3f
      0053F2 F5 82            [12]  912 	mov	dpl,a
      0053F4 C0 07            [24]  913 	push	ar7
      0053F6 12 53 A2         [24]  914 	lcall	_axis
      0053F9 AE 82            [24]  915 	mov	r6, dpl
      0053FB D0 07            [24]  916 	pop	ar7
      0053FD EE               [12]  917 	mov	a,r6
      0053FE C4               [12]  918 	swap	a
      0053FF 03               [12]  919 	rr	a
      005400 54 F8            [12]  920 	anl	a,#0xf8
      005402 90 06 CC         [24]  921 	mov	dptr,#(_mouse_report + 0x0002)
      005405 F0               [24]  922 	movx	@dptr,a
                                    923 ;	keyboards/ajazz/ak820/ak820_mousekey.c:65: mouse_report.y = axis(selected) * 8;
      005406 8F 82            [24]  924 	mov	dpl, r7
      005408 C0 07            [24]  925 	push	ar7
      00540A 12 53 A2         [24]  926 	lcall	_axis
      00540D AE 82            [24]  927 	mov	r6, dpl
      00540F D0 07            [24]  928 	pop	ar7
      005411 EE               [12]  929 	mov	a,r6
      005412 C4               [12]  930 	swap	a
      005413 03               [12]  931 	rr	a
      005414 54 F8            [12]  932 	anl	a,#0xf8
      005416 90 06 CD         [24]  933 	mov	dptr,#(_mouse_report + 0x0003)
      005419 F0               [24]  934 	movx	@dptr,a
                                    935 ;	keyboards/ajazz/ak820/ak820_mousekey.c:66: mouse_report.v = (selected & 0x20) ? -1 : ((selected & 0x10) ? 1 : 0);
      00541A EF               [12]  936 	mov	a,r7
      00541B 30 E5 04         [24]  937 	jnb	acc.5,00111$
      00541E 7E FF            [12]  938 	mov	r6,#0xff
      005420 80 0C            [24]  939 	sjmp	00112$
      005422                        940 00111$:
      005422 EF               [12]  941 	mov	a,r7
      005423 30 E4 04         [24]  942 	jnb	acc.4,00113$
      005426 7F 01            [12]  943 	mov	r7,#0x01
      005428 80 02            [24]  944 	sjmp	00114$
      00542A                        945 00113$:
      00542A 7F 00            [12]  946 	mov	r7,#0x00
      00542C                        947 00114$:
      00542C 8F 06            [24]  948 	mov	ar6,r7
      00542E                        949 00112$:
      00542E 90 06 CE         [24]  950 	mov	dptr,#(_mouse_report + 0x0004)
      005431 EE               [12]  951 	mov	a,r6
      005432 F0               [24]  952 	movx	@dptr,a
                                    953 ;	keyboards/ajazz/ak820/ak820_mousekey.c:67: mouse_report.h = axis(selected >> 6);
      005433 90 06 D4         [24]  954 	mov	dptr,#_mousekey_send_selected_10000_148
      005436 E0               [24]  955 	movx	a,@dptr
      005437 23               [12]  956 	rl	a
      005438 23               [12]  957 	rl	a
      005439 54 03            [12]  958 	anl	a,#0x03
      00543B F5 82            [12]  959 	mov	dpl,a
      00543D 12 53 A2         [24]  960 	lcall	_axis
      005440 AF 82            [24]  961 	mov	r7, dpl
      005442 90 06 CF         [24]  962 	mov	dptr,#(_mouse_report + 0x0005)
      005445 EF               [12]  963 	mov	a,r7
      005446 F0               [24]  964 	movx	@dptr,a
                                    965 ;	keyboards/ajazz/ak820/ak820_mousekey.c:68: if (!(mouse_report.x || mouse_report.y || mouse_report.v || mouse_report.h || buttons != accepted_buttons)) return;
      005447 90 06 CC         [24]  966 	mov	dptr,#(_mouse_report + 0x0002)
      00544A E0               [24]  967 	movx	a,@dptr
      00544B 70 21            [24]  968 	jnz	00102$
      00544D 90 06 CD         [24]  969 	mov	dptr,#(_mouse_report + 0x0003)
      005450 E0               [24]  970 	movx	a,@dptr
      005451 70 1B            [24]  971 	jnz	00102$
      005453 90 06 CE         [24]  972 	mov	dptr,#(_mouse_report + 0x0004)
      005456 E0               [24]  973 	movx	a,@dptr
      005457 70 15            [24]  974 	jnz	00102$
      005459 90 06 CF         [24]  975 	mov	dptr,#(_mouse_report + 0x0005)
      00545C E0               [24]  976 	movx	a,@dptr
      00545D 70 0F            [24]  977 	jnz	00102$
      00545F 90 06 C4         [24]  978 	mov	dptr,#_buttons
      005462 E0               [24]  979 	movx	a,@dptr
      005463 FF               [12]  980 	mov	r7,a
      005464 90 06 C5         [24]  981 	mov	dptr,#_accepted_buttons
      005467 E0               [24]  982 	movx	a,@dptr
      005468 FE               [12]  983 	mov	r6,a
      005469 EF               [12]  984 	mov	a,r7
      00546A B5 06 01         [24]  985 	cjne	a,ar6,00102$
      00546D 22               [24]  986 	ret
      00546E                        987 00102$:
                                    988 ;	keyboards/ajazz/ak820/ak820_mousekey.c:69: if (ak820_usb_try_send(MOUSE_IN_EPNUM, (const uint8_t __xdata *)&mouse_report, sizeof(mouse_report))) accepted_buttons = buttons;
      00546E 90 08 06         [24]  989 	mov	dptr,#_ak820_usb_try_send_PARM_2
      005471 74 CA            [12]  990 	mov	a,#_mouse_report
      005473 F0               [24]  991 	movx	@dptr,a
      005474 74 06            [12]  992 	mov	a,#(_mouse_report >> 8)
      005476 A3               [24]  993 	inc	dptr
      005477 F0               [24]  994 	movx	@dptr,a
      005478 90 08 08         [24]  995 	mov	dptr,#_ak820_usb_try_send_PARM_3
      00547B 74 06            [12]  996 	mov	a,#0x06
      00547D F0               [24]  997 	movx	@dptr,a
      00547E 75 82 02         [24]  998 	mov	dpl, #0x02
      005481 12 6E 7A         [24]  999 	lcall	_ak820_usb_try_send
      005484 E5 82            [12] 1000 	mov	a, dpl
      005486 60 08            [24] 1001 	jz	00109$
      005488 90 06 C4         [24] 1002 	mov	dptr,#_buttons
      00548B E0               [24] 1003 	movx	a,@dptr
      00548C 90 06 C5         [24] 1004 	mov	dptr,#_accepted_buttons
      00548F F0               [24] 1005 	movx	@dptr,a
      005490                       1006 00109$:
                                   1007 ;	keyboards/ajazz/ak820/ak820_mousekey.c:70: }
      005490 22               [24] 1008 	ret
                                   1009 ;------------------------------------------------------------
                                   1010 ;Allocation info for local variables in function 'mousekey_task'
                                   1011 ;------------------------------------------------------------
                                   1012 ;now           Allocated with name '_mousekey_task_now_10000_152'
                                   1013 ;------------------------------------------------------------
                                   1014 ;	keyboards/ajazz/ak820/ak820_mousekey.c:72: void mousekey_task(void) {
                                   1015 ;	-----------------------------------------
                                   1016 ;	 function mousekey_task
                                   1017 ;	-----------------------------------------
      005491                       1018 _mousekey_task:
                                   1019 ;	keyboards/ajazz/ak820/ak820_mousekey.c:73: uint16_t now = timer_read();
      005491 12 4C 69         [24] 1020 	lcall	_timer_read
      005494 AE 82            [24] 1021 	mov	r6, dpl
      005496 AF 83            [24] 1022 	mov	r7, dph
                                   1023 ;	keyboards/ajazz/ak820/ak820_mousekey.c:74: if ((uint16_t)(now - cursor_time) >= 20) {
      005498 90 06 C6         [24] 1024 	mov	dptr,#_cursor_time
      00549B E0               [24] 1025 	movx	a,@dptr
      00549C FC               [12] 1026 	mov	r4,a
      00549D A3               [24] 1027 	inc	dptr
      00549E E0               [24] 1028 	movx	a,@dptr
      00549F FD               [12] 1029 	mov	r5,a
      0054A0 EE               [12] 1030 	mov	a,r6
      0054A1 C3               [12] 1031 	clr	c
      0054A2 9C               [12] 1032 	subb	a,r4
      0054A3 FC               [12] 1033 	mov	r4,a
      0054A4 EF               [12] 1034 	mov	a,r7
      0054A5 9D               [12] 1035 	subb	a,r5
      0054A6 FD               [12] 1036 	mov	r5,a
      0054A7 C3               [12] 1037 	clr	c
      0054A8 EC               [12] 1038 	mov	a,r4
      0054A9 94 14            [12] 1039 	subb	a,#0x14
      0054AB ED               [12] 1040 	mov	a,r5
      0054AC 94 00            [12] 1041 	subb	a,#0x00
      0054AE 40 15            [24] 1042 	jc	00102$
                                   1043 ;	keyboards/ajazz/ak820/ak820_mousekey.c:75: cursor_time = now;
      0054B0 90 06 C6         [24] 1044 	mov	dptr,#_cursor_time
      0054B3 EE               [12] 1045 	mov	a,r6
      0054B4 F0               [24] 1046 	movx	@dptr,a
      0054B5 EF               [12] 1047 	mov	a,r7
      0054B6 A3               [24] 1048 	inc	dptr
      0054B7 F0               [24] 1049 	movx	@dptr,a
                                   1050 ;	keyboards/ajazz/ak820/ak820_mousekey.c:76: immediate |= directions & 0x0f;
      0054B8 90 06 C2         [24] 1051 	mov	dptr,#_directions
      0054BB E0               [24] 1052 	movx	a,@dptr
      0054BC 54 0F            [12] 1053 	anl	a,#0x0f
      0054BE FD               [12] 1054 	mov	r5,a
      0054BF 90 06 C3         [24] 1055 	mov	dptr,#_immediate
      0054C2 E0               [24] 1056 	movx	a,@dptr
      0054C3 4D               [12] 1057 	orl	a,r5
      0054C4 F0               [24] 1058 	movx	@dptr,a
      0054C5                       1059 00102$:
                                   1060 ;	keyboards/ajazz/ak820/ak820_mousekey.c:78: if ((uint16_t)(now - wheel_time) >= 80) {
      0054C5 90 06 C8         [24] 1061 	mov	dptr,#_wheel_time
      0054C8 E0               [24] 1062 	movx	a,@dptr
      0054C9 FC               [12] 1063 	mov	r4,a
      0054CA A3               [24] 1064 	inc	dptr
      0054CB E0               [24] 1065 	movx	a,@dptr
      0054CC FD               [12] 1066 	mov	r5,a
      0054CD EE               [12] 1067 	mov	a,r6
      0054CE C3               [12] 1068 	clr	c
      0054CF 9C               [12] 1069 	subb	a,r4
      0054D0 FC               [12] 1070 	mov	r4,a
      0054D1 EF               [12] 1071 	mov	a,r7
      0054D2 9D               [12] 1072 	subb	a,r5
      0054D3 FD               [12] 1073 	mov	r5,a
      0054D4 C3               [12] 1074 	clr	c
      0054D5 EC               [12] 1075 	mov	a,r4
      0054D6 94 50            [12] 1076 	subb	a,#0x50
      0054D8 ED               [12] 1077 	mov	a,r5
      0054D9 94 00            [12] 1078 	subb	a,#0x00
      0054DB 40 15            [24] 1079 	jc	00104$
                                   1080 ;	keyboards/ajazz/ak820/ak820_mousekey.c:79: wheel_time = now;
      0054DD 90 06 C8         [24] 1081 	mov	dptr,#_wheel_time
      0054E0 EE               [12] 1082 	mov	a,r6
      0054E1 F0               [24] 1083 	movx	@dptr,a
      0054E2 EF               [12] 1084 	mov	a,r7
      0054E3 A3               [24] 1085 	inc	dptr
      0054E4 F0               [24] 1086 	movx	@dptr,a
                                   1087 ;	keyboards/ajazz/ak820/ak820_mousekey.c:80: immediate |= directions & 0xf0;
      0054E5 90 06 C2         [24] 1088 	mov	dptr,#_directions
      0054E8 E0               [24] 1089 	movx	a,@dptr
      0054E9 54 F0            [12] 1090 	anl	a,#0xf0
      0054EB FF               [12] 1091 	mov	r7,a
      0054EC 90 06 C3         [24] 1092 	mov	dptr,#_immediate
      0054EF E0               [24] 1093 	movx	a,@dptr
      0054F0 4F               [12] 1094 	orl	a,r7
      0054F1 F0               [24] 1095 	movx	@dptr,a
      0054F2                       1096 00104$:
                                   1097 ;	keyboards/ajazz/ak820/ak820_mousekey.c:82: mousekey_send();
                                   1098 ;	keyboards/ajazz/ak820/ak820_mousekey.c:83: }
      0054F2 02 53 BD         [24] 1099 	ljmp	_mousekey_send
                                   1100 ;------------------------------------------------------------
                                   1101 ;Allocation info for local variables in function 'mousekey_clear'
                                   1102 ;------------------------------------------------------------
                                   1103 ;	keyboards/ajazz/ak820/ak820_mousekey.c:85: void mousekey_clear(void) {
                                   1104 ;	-----------------------------------------
                                   1105 ;	 function mousekey_clear
                                   1106 ;	-----------------------------------------
      0054F5                       1107 _mousekey_clear:
                                   1108 ;	keyboards/ajazz/ak820/ak820_mousekey.c:86: directions = 0;
      0054F5 90 06 C2         [24] 1109 	mov	dptr,#_directions
      0054F8 E4               [12] 1110 	clr	a
      0054F9 F0               [24] 1111 	movx	@dptr,a
                                   1112 ;	keyboards/ajazz/ak820/ak820_mousekey.c:87: immediate = 0;
      0054FA 90 06 C3         [24] 1113 	mov	dptr,#_immediate
      0054FD F0               [24] 1114 	movx	@dptr,a
                                   1115 ;	keyboards/ajazz/ak820/ak820_mousekey.c:88: buttons = 0;
      0054FE 90 06 C4         [24] 1116 	mov	dptr,#_buttons
      005501 F0               [24] 1117 	movx	@dptr,a
                                   1118 ;	keyboards/ajazz/ak820/ak820_mousekey.c:90: }
      005502 22               [24] 1119 	ret
                                   1120 	.area CSEG    (CODE)
                                   1121 	.area CONST   (CODE)
                                   1122 	.area XINIT   (CODE)
                                   1123 	.area CABS    (ABS,CODE)
