                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_nvm
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _eeprom_driver_erase
                                     12 	.globl _eeprom_read_byte
                                     13 	.globl _eeprom_driver_init
                                     14 	.globl _ak820_macro_init
                                     15 	.globl _ak820_flash_program_page
                                     16 	.globl _ak820_flash_program
                                     17 	.globl _ak820_flash_erase
                                     18 	.globl _ak820_flash_read
                                     19 	.globl _ak820_eeprom_update_block_xdata_PARM_3
                                     20 	.globl _ak820_eeprom_update_block_xdata_PARM_2
                                     21 	.globl _ak820_eeprom_write_block_xdata_PARM_3
                                     22 	.globl _ak820_eeprom_write_block_xdata_PARM_2
                                     23 	.globl _ak820_eeprom_read_block_xdata_PARM_3
                                     24 	.globl _ak820_eeprom_read_block_xdata_PARM_2
                                     25 	.globl _ak820_nvm_diagnostic
                                     26 	.globl _ak820_nvm_ok
                                     27 	.globl _ak820_nvm_schema_fault
                                     28 	.globl _ak820_nvm_flush
                                     29 	.globl _ak820_nvm_begin
                                     30 	.globl _ak820_nvm_end
                                     31 	.globl _ak820_eeprom_read_block_xdata
                                     32 	.globl _ak820_eeprom_write_block_xdata
                                     33 	.globl _ak820_eeprom_update_block_xdata
                                     34 ;--------------------------------------------------------
                                     35 ; special function registers
                                     36 ;--------------------------------------------------------
                                     37 	.area RSEG    (ABS,DATA)
      000000                         38 	.org 0x0000
                                     39 ;--------------------------------------------------------
                                     40 ; special function bits
                                     41 ;--------------------------------------------------------
                                     42 	.area RSEG    (ABS,DATA)
      000000                         43 	.org 0x0000
                                     44 ;--------------------------------------------------------
                                     45 ; overlayable register banks
                                     46 ;--------------------------------------------------------
                                     47 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         48 	.ds 8
                                     49 ;--------------------------------------------------------
                                     50 ; overlayable bit register bank
                                     51 ;--------------------------------------------------------
                                     52 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         53 bits:
      000026                         54 	.ds 1
                           008000    55 	b0 = bits[0]
                           008100    56 	b1 = bits[1]
                           008200    57 	b2 = bits[2]
                           008300    58 	b3 = bits[3]
                           008400    59 	b4 = bits[4]
                           008500    60 	b5 = bits[5]
                           008600    61 	b6 = bits[6]
                           008700    62 	b7 = bits[7]
                                     63 ;--------------------------------------------------------
                                     64 ; internal ram data
                                     65 ;--------------------------------------------------------
                                     66 	.area DSEG    (DATA)
      00000C                         67 _ak820_eeprom_write_block_xdata_sloc0_1_0:
      00000C                         68 	.ds 2
      00000E                         69 _ak820_eeprom_update_block_xdata_sloc0_1_0:
      00000E                         70 	.ds 2
      000010                         71 _ak820_eeprom_update_block_xdata_sloc1_1_0:
      000010                         72 	.ds 2
      000012                         73 _ak820_eeprom_update_block_xdata_sloc2_1_0:
      000012                         74 	.ds 3
                                     75 ;--------------------------------------------------------
                                     76 ; overlayable items in internal ram
                                     77 ;--------------------------------------------------------
                                     78 ;--------------------------------------------------------
                                     79 ; indirectly addressable internal ram data
                                     80 ;--------------------------------------------------------
                                     81 	.area ISEG    (DATA)
                                     82 ;--------------------------------------------------------
                                     83 ; absolute internal ram data
                                     84 ;--------------------------------------------------------
                                     85 	.area IABS    (ABS,DATA)
                                     86 	.area IABS    (ABS,DATA)
                                     87 ;--------------------------------------------------------
                                     88 ; bit data
                                     89 ;--------------------------------------------------------
                                     90 	.area BSEG    (BIT)
      000008                         91 _page_valid:
      000008                         92 	.ds 1
      000009                         93 _page_dirty:
      000009                         94 	.ds 1
      00000A                         95 _storage_failed:
      00000A                         96 	.ds 1
      00000B                         97 _ak820_nvm_ok_sloc0_1_0:
      00000B                         98 	.ds 1
      00000C                         99 _load_page_sloc0_1_0:
      00000C                        100 	.ds 1
                                    101 ;--------------------------------------------------------
                                    102 ; paged external ram data
                                    103 ;--------------------------------------------------------
                                    104 	.area PSEG    (PAG,XDATA)
                                    105 ;--------------------------------------------------------
                                    106 ; uninitialized external ram data
                                    107 ;--------------------------------------------------------
                                    108 	.area XSEG    (XDATA)
      000529                        109 _page_data:
      000529                        110 	.ds 64
      000569                        111 _cached_page:
      000569                        112 	.ds 1
      00056A                        113 _batch_depth:
      00056A                        114 	.ds 1
      00056B                        115 _first_failure_stage:
      00056B                        116 	.ds 1
      00056C                        117 _nvm_fail_stage_10000_20:
      00056C                        118 	.ds 1
      00056D                        119 _ak820_nvm_diagnostic_out_10000_23:
      00056D                        120 	.ds 2
      00056F                        121 _crc_byte_PARM_2:
      00056F                        122 	.ds 1
      000570                        123 _crc_byte_crc_10000_25:
      000570                        124 	.ds 2
      000572                        125 _page_crc_crc_10000_30:
      000572                        126 	.ds 2
      000574                        127 _write_page_address_10000_32:
      000574                        128 	.ds 2
      000576                        129 _journal_header_valid_header_10000_39:
      000576                        130 	.ds 2
      000578                        131 _recover_journal_header_10000_46:
      000578                        132 	.ds 9
      000581                        133 _ak820_nvm_flush_header_10000_62:
      000581                        134 	.ds 9
      00058A                        135 _ak820_nvm_flush_stage_10000_62:
      00058A                        136 	.ds 1
      00058B                        137 _load_page_page_10000_87:
      00058B                        138 	.ds 1
      00058C                        139 _read_offset_offset_10000_93:
      00058C                        140 	.ds 2
      00058E                        141 _eeprom_read_byte_addr_10000_97:
      00058E                        142 	.ds 3
      000591                        143 _ak820_eeprom_read_block_xdata_PARM_2:
      000591                        144 	.ds 3
      000594                        145 _ak820_eeprom_read_block_xdata_PARM_3:
      000594                        146 	.ds 2
      000596                        147 _ak820_eeprom_read_block_xdata_buf_10000_113:
      000596                        148 	.ds 2
      000598                        149 _ak820_eeprom_read_block_xdata_out_10000_114:
      000598                        150 	.ds 2
      00059A                        151 _ak820_eeprom_write_block_xdata_PARM_2:
      00059A                        152 	.ds 3
      00059D                        153 _ak820_eeprom_write_block_xdata_PARM_3:
      00059D                        154 	.ds 2
      00059F                        155 _ak820_eeprom_write_block_xdata_buf_10000_118:
      00059F                        156 	.ds 2
      0005A1                        157 _ak820_eeprom_update_block_xdata_PARM_2:
      0005A1                        158 	.ds 3
      0005A4                        159 _ak820_eeprom_update_block_xdata_PARM_3:
      0005A4                        160 	.ds 2
      0005A6                        161 _ak820_eeprom_update_block_xdata_buf_10000_127:
      0005A6                        162 	.ds 2
                                    163 ;--------------------------------------------------------
                                    164 ; absolute external ram data
                                    165 ;--------------------------------------------------------
                                    166 	.area XABS    (ABS,XDATA)
                                    167 ;--------------------------------------------------------
                                    168 ; initialized external ram data
                                    169 ;--------------------------------------------------------
                                    170 	.area XISEG   (XDATA)
                                    171 	.area HOME    (CODE)
                                    172 	.area GSINIT0 (CODE)
                                    173 	.area GSINIT1 (CODE)
                                    174 	.area GSINIT2 (CODE)
                                    175 	.area GSINIT3 (CODE)
                                    176 	.area GSINIT4 (CODE)
                                    177 	.area GSINIT5 (CODE)
                                    178 	.area GSINIT  (CODE)
                                    179 	.area GSFINAL (CODE)
                                    180 	.area CSEG    (CODE)
                                    181 ;--------------------------------------------------------
                                    182 ; global & static initialisations
                                    183 ;--------------------------------------------------------
                                    184 	.area HOME    (CODE)
                                    185 	.area GSINIT  (CODE)
                                    186 	.area GSFINAL (CODE)
                                    187 	.area GSINIT  (CODE)
                                    188 ;--------------------------------------------------------
                                    189 ; Home
                                    190 ;--------------------------------------------------------
                                    191 	.area HOME    (CODE)
                                    192 	.area HOME    (CODE)
                                    193 ;--------------------------------------------------------
                                    194 ; code
                                    195 ;--------------------------------------------------------
                                    196 	.area CSEG    (CODE)
                                    197 ;------------------------------------------------------------
                                    198 ;Allocation info for local variables in function 'nvm_fail'
                                    199 ;------------------------------------------------------------
                                    200 ;stage         Allocated with name '_nvm_fail_stage_10000_20'
                                    201 ;------------------------------------------------------------
                                    202 ;	keyboards/ajazz/ak820/ak820_nvm.c:31: static void nvm_fail(uint8_t stage) {
                                    203 ;	-----------------------------------------
                                    204 ;	 function nvm_fail
                                    205 ;	-----------------------------------------
      003DF7                        206 _nvm_fail:
                           000007   207 	ar7 = 0x07
                           000006   208 	ar6 = 0x06
                           000005   209 	ar5 = 0x05
                           000004   210 	ar4 = 0x04
                           000003   211 	ar3 = 0x03
                           000002   212 	ar2 = 0x02
                           000001   213 	ar1 = 0x01
                           000000   214 	ar0 = 0x00
      003DF7 E5 82            [12]  215 	mov	a,dpl
      003DF9 90 05 6C         [24]  216 	mov	dptr,#_nvm_fail_stage_10000_20
      003DFC F0               [24]  217 	movx	@dptr,a
                                    218 ;	keyboards/ajazz/ak820/ak820_nvm.c:32: if (!storage_failed) first_failure_stage = stage;
      003DFD 20 0A 08         [24]  219 	jb	_storage_failed,00102$
      003E00 90 05 6C         [24]  220 	mov	dptr,#_nvm_fail_stage_10000_20
      003E03 E0               [24]  221 	movx	a,@dptr
      003E04 90 05 6B         [24]  222 	mov	dptr,#_first_failure_stage
      003E07 F0               [24]  223 	movx	@dptr,a
      003E08                        224 00102$:
                                    225 ;	keyboards/ajazz/ak820/ak820_nvm.c:33: storage_failed = true;
                                    226 ;	assignBit
      003E08 D2 0A            [12]  227 	setb	_storage_failed
                                    228 ;	keyboards/ajazz/ak820/ak820_nvm.c:34: }
      003E0A 22               [24]  229 	ret
                                    230 ;------------------------------------------------------------
                                    231 ;Allocation info for local variables in function 'ak820_nvm_diagnostic'
                                    232 ;------------------------------------------------------------
                                    233 ;out           Allocated with name '_ak820_nvm_diagnostic_out_10000_23'
                                    234 ;------------------------------------------------------------
                                    235 ;	keyboards/ajazz/ak820/ak820_nvm.c:36: void ak820_nvm_diagnostic(uint8_t AK820_XDATA *out) {
                                    236 ;	-----------------------------------------
                                    237 ;	 function ak820_nvm_diagnostic
                                    238 ;	-----------------------------------------
      003E0B                        239 _ak820_nvm_diagnostic:
      003E0B 12 3A 83         [24]  240 	lcall	_ak820_outline_0103
      003E0E 90 05 6D         [24]  241 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003E11 12 3A 88         [24]  242 	lcall	_ak820_outline_0104
                                    243 ;	keyboards/ajazz/ak820/ak820_nvm.c:37: out[0] = storage_failed;
      003E14 90 05 6D         [24]  244 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003E17 12 3A 40         [24]  245 	lcall	_ak820_outline_0051
      003E1A A2 0A            [12]  246 	mov	c,_storage_failed
      003E1C E4               [12]  247 	clr	a
      003E1D 33               [12]  248 	rlc	a
      003E1E 12 45 C9         [24]  249 	lcall	_ak820_outline_0116
      003E21 12 45 AB         [24]  250 	lcall	_ak820_outline_0061
                                    251 ;	keyboards/ajazz/ak820/ak820_nvm.c:38: out[1] = page_valid;
      003E24 A3               [24]  252 	inc	dptr
      003E25 A2 08            [12]  253 	mov	c,_page_valid
      003E27 E4               [12]  254 	clr	a
      003E28 33               [12]  255 	rlc	a
      003E29 12 45 7F         [24]  256 	lcall	_ak820_outline_0030
                                    257 ;	keyboards/ajazz/ak820/ak820_nvm.c:39: out[2] = page_dirty;
      003E2C A2 09            [12]  258 	mov	c,_page_dirty
      003E2E E4               [12]  259 	clr	a
      003E2F 33               [12]  260 	rlc	a
      003E30 F0               [24]  261 	movx	@dptr,a
                                    262 ;	keyboards/ajazz/ak820/ak820_nvm.c:40: out[3] = batch_depth;
      003E31 74 03            [12]  263 	mov	a,#0x03
      003E33 12 45 F4         [24]  264 	lcall	_ak820_outline_0158
      003E36 90 05 6A         [24]  265 	mov	dptr,#_batch_depth
      003E39 E0               [24]  266 	movx	a,@dptr
      003E3A 12 3A A0         [24]  267 	lcall	_ak820_outline_0121
      003E3D F0               [24]  268 	movx	@dptr,a
                                    269 ;	keyboards/ajazz/ak820/ak820_nvm.c:41: out[4] = (uint8_t)cached_page;
      003E3E 74 04            [12]  270 	mov	a,#0x04
      003E40 12 45 F4         [24]  271 	lcall	_ak820_outline_0158
      003E43 90 05 69         [24]  272 	mov	dptr,#_cached_page
      003E46 E0               [24]  273 	movx	a,@dptr
      003E47 12 3A A0         [24]  274 	lcall	_ak820_outline_0121
      003E4A F0               [24]  275 	movx	@dptr,a
                                    276 ;	keyboards/ajazz/ak820/ak820_nvm.c:42: out[5] = (uint8_t)(cached_page >> 8);
      003E4B 12 45 75         [24]  277 	lcall	_ak820_outline_0010
      003E4E E4               [12]  278 	clr	a
      003E4F F0               [24]  279 	movx	@dptr,a
                                    280 ;	keyboards/ajazz/ak820/ak820_nvm.c:43: out[6] = first_failure_stage;
      003E50 74 06            [12]  281 	mov	a,#0x06
      003E52 12 45 D9         [24]  282 	lcall	_ak820_outline_0134
      003E55 90 05 6B         [24]  283 	mov	dptr,#_first_failure_stage
      003E58 E0               [24]  284 	movx	a,@dptr
      003E59 12 45 C9         [24]  285 	lcall	_ak820_outline_0116
      003E5C F0               [24]  286 	movx	@dptr,a
                                    287 ;	keyboards/ajazz/ak820/ak820_nvm.c:44: }
      003E5D 22               [24]  288 	ret
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'crc_byte'
                                    291 ;------------------------------------------------------------
                                    292 ;value         Allocated with name '_crc_byte_PARM_2'
                                    293 ;crc           Allocated with name '_crc_byte_crc_10000_25'
                                    294 ;bit           Allocated with name '_crc_byte_bit_10000_26'
                                    295 ;------------------------------------------------------------
                                    296 ;	keyboards/ajazz/ak820/ak820_nvm.c:46: static uint16_t crc_byte(uint16_t crc, uint8_t value) {
                                    297 ;	-----------------------------------------
                                    298 ;	 function crc_byte
                                    299 ;	-----------------------------------------
      003E5E                        300 _crc_byte:
      003E5E 12 3A 83         [24]  301 	lcall	_ak820_outline_0103
      003E61 90 05 70         [24]  302 	mov	dptr,#_crc_byte_crc_10000_25
      003E64 12 3A 88         [24]  303 	lcall	_ak820_outline_0104
                                    304 ;	keyboards/ajazz/ak820/ak820_nvm.c:48: crc ^= (uint16_t)value << 8;
      003E67 90 05 6F         [24]  305 	mov	dptr,#_crc_byte_PARM_2
      003E6A E0               [24]  306 	movx	a,@dptr
      003E6B FF               [12]  307 	mov	r7,a
      003E6C 7E 00            [12]  308 	mov	r6,#0x00
      003E6E 90 05 70         [24]  309 	mov	dptr,#_crc_byte_crc_10000_25
      003E71 E0               [24]  310 	movx	a,@dptr
      003E72 6E               [12]  311 	xrl	a,r6
      003E73 F0               [24]  312 	movx	@dptr,a
      003E74 A3               [24]  313 	inc	dptr
      003E75 E0               [24]  314 	movx	a,@dptr
      003E76 6F               [12]  315 	xrl	a,r7
      003E77 F0               [24]  316 	movx	@dptr,a
                                    317 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003E78 7F 00            [12]  318 	mov	r7,#0x00
      003E7A                        319 00102$:
                                    320 ;	keyboards/ajazz/ak820/ak820_nvm.c:50: crc = (crc & 0x8000u) ? (uint16_t)((crc << 1) ^ 0x1021u) : (uint16_t)(crc << 1);
      003E7A 90 05 70         [24]  321 	mov	dptr,#_crc_byte_crc_10000_25
      003E7D 12 45 B7         [24]  322 	lcall	_ak820_outline_0097
      003E80 30 E7 0E         [24]  323 	jnb	acc.7,00106$
      003E83 ED               [12]  324 	mov	a,r5
      003E84 2D               [12]  325 	add	a,r5
      003E85 FB               [12]  326 	mov	r3,a
      003E86 EE               [12]  327 	mov	a,r6
      003E87 33               [12]  328 	rlc	a
      003E88 FC               [12]  329 	mov	r4,a
      003E89 63 03 21         [24]  330 	xrl	ar3,#0x21
      003E8C 63 04 10         [24]  331 	xrl	ar4,#0x10
      003E8F 80 06            [24]  332 	sjmp	00107$
      003E91                        333 00106$:
      003E91 ED               [12]  334 	mov	a,r5
      003E92 2D               [12]  335 	add	a,r5
      003E93 FB               [12]  336 	mov	r3,a
      003E94 EE               [12]  337 	mov	a,r6
      003E95 33               [12]  338 	rlc	a
      003E96 FC               [12]  339 	mov	r4,a
      003E97                        340 00107$:
      003E97 90 05 70         [24]  341 	mov	dptr,#_crc_byte_crc_10000_25
      003E9A 12 3A 6B         [24]  342 	lcall	_ak820_outline_0076
                                    343 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003E9D 0F               [12]  344 	inc	r7
      003E9E BF 08 D9         [24]  345 	cjne	r7,#0x08,00102$
                                    346 ;	keyboards/ajazz/ak820/ak820_nvm.c:52: return crc;
      003EA1 12 36 42         [24]  347 	lcall	_ak820_outline_0122
                                    348 ;	keyboards/ajazz/ak820/ak820_nvm.c:53: }
      003EA4 22               [24]  349 	ret
                                    350 ;------------------------------------------------------------
                                    351 ;Allocation info for local variables in function 'page_crc'
                                    352 ;------------------------------------------------------------
                                    353 ;crc           Allocated with name '_page_crc_crc_10000_30'
                                    354 ;i             Allocated with name '_page_crc_i_10000_30'
                                    355 ;------------------------------------------------------------
                                    356 ;	keyboards/ajazz/ak820/ak820_nvm.c:55: static uint16_t page_crc(void) {
                                    357 ;	-----------------------------------------
                                    358 ;	 function page_crc
                                    359 ;	-----------------------------------------
      003EA5                        360 _page_crc:
                                    361 ;	keyboards/ajazz/ak820/ak820_nvm.c:56: uint16_t crc = 0xFFFFu;
      003EA5 90 05 72         [24]  362 	mov	dptr,#_page_crc_crc_10000_30
      003EA8 74 FF            [12]  363 	mov	a,#0xff
      003EAA F0               [24]  364 	movx	@dptr,a
      003EAB A3               [24]  365 	inc	dptr
      003EAC F0               [24]  366 	movx	@dptr,a
                                    367 ;	keyboards/ajazz/ak820/ak820_nvm.c:58: for (i = 0; i != AK820_FLASH_PAGE; ++i) crc = crc_byte(crc, page_data[i]);
      003EAD 7F 00            [12]  368 	mov	r7,#0x00
      003EAF                        369 00102$:
      003EAF 90 05 72         [24]  370 	mov	dptr,#_page_crc_crc_10000_30
      003EB2 12 45 B7         [24]  371 	lcall	_ak820_outline_0097
      003EB5 12 45 BD         [24]  372 	lcall	_ak820_outline_0101
      003EB8 90 05 6F         [24]  373 	mov	dptr,#_crc_byte_PARM_2
      003EBB F0               [24]  374 	movx	@dptr,a
      003EBC 12 3A AA         [24]  375 	lcall	_ak820_outline_0131
      003EBF C0 07            [24]  376 	push	ar7
      003EC1 12 3E 5E         [24]  377 	lcall	_crc_byte
      003EC4 AD 82            [24]  378 	mov	r5, dpl
      003EC6 AE 83            [24]  379 	mov	r6, dph
      003EC8 D0 07            [24]  380 	pop	ar7
      003ECA 90 05 72         [24]  381 	mov	dptr,#_page_crc_crc_10000_30
      003ECD 12 45 FA         [24]  382 	lcall	_ak820_outline_0159
      003ED0 0F               [12]  383 	inc	r7
      003ED1 BF 40 DB         [24]  384 	cjne	r7,#0x40,00102$
                                    385 ;	keyboards/ajazz/ak820/ak820_nvm.c:59: return crc;
      003ED4 12 3A AA         [24]  386 	lcall	_ak820_outline_0131
                                    387 ;	keyboards/ajazz/ak820/ak820_nvm.c:60: }
      003ED7 22               [24]  388 	ret
                                    389 ;------------------------------------------------------------
                                    390 ;Allocation info for local variables in function 'write_page'
                                    391 ;------------------------------------------------------------
                                    392 ;address       Allocated with name '_write_page_address_10000_32'
                                    393 ;i             Allocated with name '_write_page_i_10000_33'
                                    394 ;------------------------------------------------------------
                                    395 ;	keyboards/ajazz/ak820/ak820_nvm.c:62: static bool write_page(uint16_t address) {
                                    396 ;	-----------------------------------------
                                    397 ;	 function write_page
                                    398 ;	-----------------------------------------
      003ED8                        399 _write_page:
      003ED8 12 3A 83         [24]  400 	lcall	_ak820_outline_0103
      003EDB 90 05 74         [24]  401 	mov	dptr,#_write_page_address_10000_32
      003EDE 12 3A 88         [24]  402 	lcall	_ak820_outline_0104
                                    403 ;	keyboards/ajazz/ak820/ak820_nvm.c:64: if (!ak820_flash_erase(address)) return false;
      003EE1 90 05 74         [24]  404 	mov	dptr,#_write_page_address_10000_32
      003EE4 12 39 E0         [24]  405 	lcall	_ak820_outline_0004
      003EE7 C0 07            [24]  406 	push	ar7
      003EE9 C0 06            [24]  407 	push	ar6
      003EEB 12 3C 06         [24]  408 	lcall	_ak820_flash_erase
      003EEE E5 82            [12]  409 	mov	a, dpl
      003EF0 D0 06            [24]  410 	pop	ar6
      003EF2 D0 07            [24]  411 	pop	ar7
      003EF4 70 03            [24]  412 	jnz	00102$
      003EF6 F5 82            [12]  413 	mov	dpl,a
      003EF8 22               [24]  414 	ret
      003EF9                        415 00102$:
                                    416 ;	keyboards/ajazz/ak820/ak820_nvm.c:65: if (!ak820_flash_program_page(address, page_data)) return false;
      003EF9 90 05 05         [24]  417 	mov	dptr,#_ak820_flash_program_page_PARM_2
      003EFC 74 29            [12]  418 	mov	a,#_page_data
      003EFE F0               [24]  419 	movx	@dptr,a
      003EFF 74 05            [12]  420 	mov	a,#(_page_data >> 8)
      003F01 A3               [24]  421 	inc	dptr
      003F02 12 45 AB         [24]  422 	lcall	_ak820_outline_0061
      003F05 12 3D 1A         [24]  423 	lcall	_ak820_flash_program_page
      003F08 E5 82            [12]  424 	mov	a, dpl
      003F0A 70 03            [24]  425 	jnz	00120$
      003F0C F5 82            [12]  426 	mov	dpl,a
                                    427 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003F0E 22               [24]  428 	ret
      003F0F                        429 00120$:
      003F0F 7F 00            [12]  430 	mov	r7,#0x00
      003F11                        431 00108$:
                                    432 ;	keyboards/ajazz/ak820/ak820_nvm.c:67: if (ak820_flash_read(address + i) != page_data[i]) return false;
      003F11 8F 05            [24]  433 	mov	ar5,r7
      003F13 7E 00            [12]  434 	mov	r6,#0x00
      003F15 90 05 74         [24]  435 	mov	dptr,#_write_page_address_10000_32
      003F18 12 3A 9A         [24]  436 	lcall	_ak820_outline_0120
      003F1B ED               [12]  437 	mov	a,r5
      003F1C 2B               [12]  438 	add	a, r3
      003F1D FB               [12]  439 	mov	r3,a
      003F1E EE               [12]  440 	mov	a,r6
      003F1F 3C               [12]  441 	addc	a, r4
      003F20 FC               [12]  442 	mov	r4,a
      003F21 12 36 42         [24]  443 	lcall	_ak820_outline_0122
      003F24 12 3A F9         [24]  444 	lcall	_ak820_flash_read
      003F27 AE 82            [24]  445 	mov	r6, dpl
      003F29 12 45 BD         [24]  446 	lcall	_ak820_outline_0101
      003F2C FD               [12]  447 	mov	r5,a
      003F2D EE               [12]  448 	mov	a,r6
      003F2E B5 05 02         [24]  449 	cjne	a,ar5,00149$
      003F31 80 04            [24]  450 	sjmp	00109$
      003F33                        451 00149$:
      003F33 75 82 00         [24]  452 	mov	dpl, #0x00
      003F36 22               [24]  453 	ret
      003F37                        454 00109$:
                                    455 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003F37 0F               [12]  456 	inc	r7
      003F38 BF 40 D6         [24]  457 	cjne	r7,#0x40,00108$
                                    458 ;	keyboards/ajazz/ak820/ak820_nvm.c:69: return true;
      003F3B 75 82 01         [24]  459 	mov	dpl, #0x01
                                    460 ;	keyboards/ajazz/ak820/ak820_nvm.c:70: }
      003F3E 22               [24]  461 	ret
                                    462 ;------------------------------------------------------------
                                    463 ;Allocation info for local variables in function 'journal_header_valid'
                                    464 ;------------------------------------------------------------
                                    465 ;header        Allocated with name '_journal_header_valid_header_10000_39'
                                    466 ;i             Allocated with name '_journal_header_valid_i_10000_40'
                                    467 ;------------------------------------------------------------
                                    468 ;	keyboards/ajazz/ak820/ak820_nvm.c:72: static bool journal_header_valid(uint8_t AK820_XDATA *header) {
                                    469 ;	-----------------------------------------
                                    470 ;	 function journal_header_valid
                                    471 ;	-----------------------------------------
      003F3F                        472 _journal_header_valid:
      003F3F 12 3A 83         [24]  473 	lcall	_ak820_outline_0103
      003F42 90 05 76         [24]  474 	mov	dptr,#_journal_header_valid_header_10000_39
      003F45 12 3A 88         [24]  475 	lcall	_ak820_outline_0104
                                    476 ;	keyboards/ajazz/ak820/ak820_nvm.c:74: if (header[0] != 0xA5u) return false;
      003F48 90 05 76         [24]  477 	mov	dptr,#_journal_header_valid_header_10000_39
      003F4B 12 39 E0         [24]  478 	lcall	_ak820_outline_0004
      003F4E E0               [24]  479 	movx	a,@dptr
      003F4F FD               [12]  480 	mov	r5,a
      003F50 BD A5 02         [24]  481 	cjne	r5,#0xa5,00138$
      003F53 80 04            [24]  482 	sjmp	00116$
      003F55                        483 00138$:
      003F55 75 82 00         [24]  484 	mov	dpl, #0x00
                                    485 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      003F58 22               [24]  486 	ret
      003F59                        487 00116$:
      003F59 7D 01            [12]  488 	mov	r5,#0x01
      003F5B                        489 00106$:
                                    490 ;	keyboards/ajazz/ak820/ak820_nvm.c:76: if ((uint8_t)(header[i] ^ header[i + 4]) != 0xFFu) return false;
      003F5B ED               [12]  491 	mov	a,r5
      003F5C 12 3A 27         [24]  492 	lcall	_ak820_outline_0017
      003F5F FC               [12]  493 	mov	r4,a
      003F60 8D 02            [24]  494 	mov	ar2,r5
      003F62 7B 00            [12]  495 	mov	r3,#0x00
      003F64 74 04            [12]  496 	mov	a,#0x04
      003F66 2A               [12]  497 	add	a, r2
      003F67 FA               [12]  498 	mov	r2,a
      003F68 E4               [12]  499 	clr	a
      003F69 3B               [12]  500 	addc	a, r3
      003F6A FB               [12]  501 	mov	r3,a
      003F6B EA               [12]  502 	mov	a,r2
      003F6C 2E               [12]  503 	add	a, r6
      003F6D F5 82            [12]  504 	mov	dpl,a
      003F6F EB               [12]  505 	mov	a,r3
      003F70 3F               [12]  506 	addc	a, r7
      003F71 F5 83            [12]  507 	mov	dph,a
      003F73 E0               [24]  508 	movx	a,@dptr
      003F74 62 04            [12]  509 	xrl	ar4,a
      003F76 BC FF 02         [24]  510 	cjne	r4,#0xff,00139$
      003F79 80 04            [24]  511 	sjmp	00107$
      003F7B                        512 00139$:
      003F7B 75 82 00         [24]  513 	mov	dpl, #0x00
      003F7E 22               [24]  514 	ret
      003F7F                        515 00107$:
                                    516 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      003F7F 0D               [12]  517 	inc	r5
      003F80 BD 05 D8         [24]  518 	cjne	r5,#0x05,00106$
                                    519 ;	keyboards/ajazz/ak820/ak820_nvm.c:78: return true;
      003F83 75 82 01         [24]  520 	mov	dpl, #0x01
                                    521 ;	keyboards/ajazz/ak820/ak820_nvm.c:79: }
      003F86 22               [24]  522 	ret
                                    523 ;------------------------------------------------------------
                                    524 ;Allocation info for local variables in function 'recover_journal'
                                    525 ;------------------------------------------------------------
                                    526 ;header        Allocated with name '_recover_journal_header_10000_46'
                                    527 ;i             Allocated with name '_recover_journal_i_10000_46'
                                    528 ;page          Allocated with name '_recover_journal_page_10000_46'
                                    529 ;crc           Allocated with name '_recover_journal_crc_10000_46'
                                    530 ;------------------------------------------------------------
                                    531 ;	keyboards/ajazz/ak820/ak820_nvm.c:81: static void recover_journal(void) {
                                    532 ;	-----------------------------------------
                                    533 ;	 function recover_journal
                                    534 ;	-----------------------------------------
      003F87                        535 _recover_journal:
                                    536 ;	keyboards/ajazz/ak820/ak820_nvm.c:85: for (i = 0; i != sizeof(header); ++i) header[i] = ak820_flash_read(AK820_JOURNAL_HEADER + i);
      003F87 7F 00            [12]  537 	mov	r7,#0x00
      003F89                        538 00115$:
      003F89 EF               [12]  539 	mov	a,r7
      003F8A 24 78            [12]  540 	add	a, #_recover_journal_header_10000_46
      003F8C FD               [12]  541 	mov	r5,a
      003F8D E4               [12]  542 	clr	a
      003F8E 34 05            [12]  543 	addc	a, #(_recover_journal_header_10000_46 >> 8)
      003F90 FE               [12]  544 	mov	r6,a
      003F91 8F 04            [24]  545 	mov	ar4,r7
      003F93 7B 00            [12]  546 	mov	r3,#0x00
      003F95 74 40            [12]  547 	mov	a,#0x40
      003F97 2C               [12]  548 	add	a, r4
      003F98 FC               [12]  549 	mov	r4,a
      003F99 74 EF            [12]  550 	mov	a,#0xef
      003F9B 3B               [12]  551 	addc	a, r3
      003F9C FB               [12]  552 	mov	r3,a
      003F9D 12 46 05         [24]  553 	lcall	_ak820_outline_0180
      003FA0 12 3A F9         [24]  554 	lcall	_ak820_flash_read
      003FA3 AC 82            [24]  555 	mov	r4, dpl
      003FA5 12 3A AA         [24]  556 	lcall	_ak820_outline_0131
      003FA8 EC               [12]  557 	mov	a,r4
      003FA9 F0               [24]  558 	movx	@dptr,a
      003FAA 0F               [12]  559 	inc	r7
      003FAB BF 09 DB         [24]  560 	cjne	r7,#0x09,00115$
                                    561 ;	keyboards/ajazz/ak820/ak820_nvm.c:88: if (!journal_header_valid(header)) return;
      003FAE 90 05 78         [24]  562 	mov	dptr,#_recover_journal_header_10000_46
      003FB1 12 3F 3F         [24]  563 	lcall	_journal_header_valid
      003FB4 E5 82            [12]  564 	mov	a, dpl
      003FB6 70 01            [24]  565 	jnz	00103$
      003FB8 22               [24]  566 	ret
      003FB9                        567 00103$:
                                    568 ;	keyboards/ajazz/ak820/ak820_nvm.c:89: page = (uint16_t)header[1] | ((uint16_t)header[2] << 8);
      003FB9 90 05 79         [24]  569 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0001)
      003FBC E0               [24]  570 	movx	a,@dptr
      003FBD FF               [12]  571 	mov	r7,a
      003FBE 7E 00            [12]  572 	mov	r6,#0x00
      003FC0 90 05 7A         [24]  573 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0002)
      003FC3 E0               [24]  574 	movx	a,@dptr
      003FC4 FC               [12]  575 	mov	r4,a
      003FC5 E4               [12]  576 	clr	a
      003FC6 42 07            [12]  577 	orl	ar7,a
      003FC8 EC               [12]  578 	mov	a,r4
      003FC9 42 06            [12]  579 	orl	ar6,a
                                    580 ;	keyboards/ajazz/ak820/ak820_nvm.c:90: crc = (uint16_t)header[3] | ((uint16_t)header[4] << 8);
      003FCB 90 05 7B         [24]  581 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0003)
      003FCE E0               [24]  582 	movx	a,@dptr
      003FCF FD               [12]  583 	mov	r5,a
      003FD0 7C 00            [12]  584 	mov	r4,#0x00
      003FD2 90 05 7C         [24]  585 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0004)
      003FD5 E0               [24]  586 	movx	a,@dptr
      003FD6 FA               [12]  587 	mov	r2,a
      003FD7 E4               [12]  588 	clr	a
      003FD8 12 45 DF         [24]  589 	lcall	_ak820_outline_0141
                                    590 ;	keyboards/ajazz/ak820/ak820_nvm.c:91: if (page >= AK820_NVM_SIZE / AK820_FLASH_PAGE) {
      003FDB C3               [12]  591 	clr	c
      003FDC EF               [12]  592 	mov	a,r7
      003FDD 94 A0            [12]  593 	subb	a,#0xa0
      003FDF EE               [12]  594 	mov	a,r6
      003FE0 94 00            [12]  595 	subb	a,#0x00
      003FE2 40 06            [24]  596 	jc	00134$
                                    597 ;	keyboards/ajazz/ak820/ak820_nvm.c:92: nvm_fail(AK820_NVM_FAULT_RECOVERY_PAGE);
      003FE4 75 82 01         [24]  598 	mov	dpl, #0x01
                                    599 ;	keyboards/ajazz/ak820/ak820_nvm.c:93: return;
      003FE7 02 3D F7         [24]  600 	ljmp	_nvm_fail
                                    601 ;	keyboards/ajazz/ak820/ak820_nvm.c:95: for (i = 0; i != AK820_FLASH_PAGE; ++i) page_data[i] = ak820_flash_read(AK820_JOURNAL_DATA + i);
      003FEA                        602 00134$:
      003FEA 7B 00            [12]  603 	mov	r3,#0x00
      003FEC                        604 00117$:
      003FEC C0 05            [24]  605 	push	ar5
      003FEE C0 04            [24]  606 	push	ar4
      003FF0 EB               [12]  607 	mov	a,r3
      003FF1 24 29            [12]  608 	add	a, #_page_data
      003FF3 F9               [12]  609 	mov	r1,a
      003FF4 E4               [12]  610 	clr	a
      003FF5 34 05            [12]  611 	addc	a, #(_page_data >> 8)
      003FF7 FA               [12]  612 	mov	r2,a
      003FF8 8B 00            [24]  613 	mov	ar0,r3
      003FFA 7D 00            [12]  614 	mov	r5,#0x00
      003FFC 74 EF            [12]  615 	mov	a,#0xef
      003FFE 2D               [12]  616 	add	a, r5
      003FFF FD               [12]  617 	mov	r5,a
      004000 88 82            [24]  618 	mov	dpl, r0
      004002 8D 83            [24]  619 	mov	dph, r5
      004004 12 3A F9         [24]  620 	lcall	_ak820_flash_read
      004007 AD 82            [24]  621 	mov	r5, dpl
      004009 12 46 00         [24]  622 	lcall	_ak820_outline_0179
      00400C ED               [12]  623 	mov	a,r5
      00400D F0               [24]  624 	movx	@dptr,a
      00400E 0B               [12]  625 	inc	r3
      00400F BB 40 02         [24]  626 	cjne	r3,#0x40,00190$
      004012 80 06            [24]  627 	sjmp	00191$
      004014                        628 00190$:
      004014 D0 04            [24]  629 	pop	ar4
      004016 D0 05            [24]  630 	pop	ar5
      004018 80 D2            [24]  631 	sjmp	00117$
      00401A                        632 00191$:
      00401A D0 04            [24]  633 	pop	ar4
      00401C D0 05            [24]  634 	pop	ar5
                                    635 ;	keyboards/ajazz/ak820/ak820_nvm.c:96: if (page_crc() != crc) nvm_fail(AK820_NVM_FAULT_RECOVERY_CRC);
      00401E C0 07            [24]  636 	push	ar7
      004020 C0 06            [24]  637 	push	ar6
      004022 C0 05            [24]  638 	push	ar5
      004024 C0 04            [24]  639 	push	ar4
      004026 12 3E A5         [24]  640 	lcall	_page_crc
      004029 AA 82            [24]  641 	mov	r2, dpl
      00402B AB 83            [24]  642 	mov	r3, dph
      00402D D0 04            [24]  643 	pop	ar4
      00402F D0 05            [24]  644 	pop	ar5
      004031 D0 06            [24]  645 	pop	ar6
      004033 D0 07            [24]  646 	pop	ar7
      004035 EA               [12]  647 	mov	a,r2
      004036 B5 05 06         [24]  648 	cjne	a,ar5,00192$
      004039 EB               [12]  649 	mov	a,r3
      00403A B5 04 02         [24]  650 	cjne	a,ar4,00192$
      00403D 80 06            [24]  651 	sjmp	00113$
      00403F                        652 00192$:
      00403F 75 82 02         [24]  653 	mov	dpl, #0x02
      004042 02 3D F7         [24]  654 	ljmp	_nvm_fail
      004045                        655 00113$:
                                    656 ;	keyboards/ajazz/ak820/ak820_nvm.c:97: else if (!write_page(AK820_NVM_BASE + page * AK820_FLASH_PAGE)) nvm_fail(AK820_NVM_FAULT_RECOVERY_WRITE);
      004045 EE               [12]  657 	mov	a,r6
      004046 54 03            [12]  658 	anl	a,#0x03
      004048 A2 E0            [12]  659 	mov	c,acc.0
      00404A CF               [12]  660 	xch	a,r7
      00404B 13               [12]  661 	rrc	a
      00404C CF               [12]  662 	xch	a,r7
      00404D 13               [12]  663 	rrc	a
      00404E A2 E0            [12]  664 	mov	c,acc.0
      004050 CF               [12]  665 	xch	a,r7
      004051 13               [12]  666 	rrc	a
      004052 CF               [12]  667 	xch	a,r7
      004053 13               [12]  668 	rrc	a
      004054 CF               [12]  669 	xch	a,r7
      004055 24 C7            [12]  670 	add	a,#0xc7
      004057 FE               [12]  671 	mov	r6,a
      004058 12 45 EF         [24]  672 	lcall	_ak820_outline_0156
      00405B 12 3E D8         [24]  673 	lcall	_write_page
      00405E E5 82            [12]  674 	mov	a, dpl
      004060 70 06            [24]  675 	jnz	00110$
      004062 75 82 03         [24]  676 	mov	dpl, #0x03
      004065 02 3D F7         [24]  677 	ljmp	_nvm_fail
      004068                        678 00110$:
                                    679 ;	keyboards/ajazz/ak820/ak820_nvm.c:98: else if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) nvm_fail(AK820_NVM_FAULT_RECOVERY_CLEANUP);
      004068 90 EF 40         [24]  680 	mov	dptr,#0xef40
      00406B 12 3C 06         [24]  681 	lcall	_ak820_flash_erase
      00406E E5 82            [12]  682 	mov	a, dpl
      004070 70 06            [24]  683 	jnz	00119$
      004072 75 82 04         [24]  684 	mov	dpl, #0x04
                                    685 ;	keyboards/ajazz/ak820/ak820_nvm.c:99: }
      004075 02 3D F7         [24]  686 	ljmp	_nvm_fail
      004078                        687 00119$:
      004078 22               [24]  688 	ret
                                    689 ;------------------------------------------------------------
                                    690 ;Allocation info for local variables in function 'eeprom_driver_init'
                                    691 ;------------------------------------------------------------
                                    692 ;	keyboards/ajazz/ak820/ak820_nvm.c:101: void eeprom_driver_init(void) {
                                    693 ;	-----------------------------------------
                                    694 ;	 function eeprom_driver_init
                                    695 ;	-----------------------------------------
      004079                        696 _eeprom_driver_init:
                                    697 ;	keyboards/ajazz/ak820/ak820_nvm.c:102: storage_failed = false;
                                    698 ;	assignBit
      004079 C2 0A            [12]  699 	clr	_storage_failed
                                    700 ;	keyboards/ajazz/ak820/ak820_nvm.c:103: first_failure_stage = AK820_NVM_FAULT_NONE;
      00407B 90 05 6B         [24]  701 	mov	dptr,#_first_failure_stage
      00407E E4               [12]  702 	clr	a
      00407F F0               [24]  703 	movx	@dptr,a
                                    704 ;	keyboards/ajazz/ak820/ak820_nvm.c:104: page_valid = page_dirty = false;
                                    705 ;	assignBit
      004080 C2 09            [12]  706 	clr	_page_dirty
                                    707 ;	assignBit
      004082 C2 08            [12]  708 	clr	_page_valid
                                    709 ;	keyboards/ajazz/ak820/ak820_nvm.c:105: batch_depth = 0;
      004084 90 05 6A         [24]  710 	mov	dptr,#_batch_depth
      004087 E4               [12]  711 	clr	a
      004088 F0               [24]  712 	movx	@dptr,a
                                    713 ;	keyboards/ajazz/ak820/ak820_nvm.c:106: recover_journal();
      004089 12 3F 87         [24]  714 	lcall	_recover_journal
                                    715 ;	keyboards/ajazz/ak820/ak820_nvm.c:108: ak820_macro_init();
                                    716 ;	keyboards/ajazz/ak820/ak820_nvm.c:110: }
      00408C 02 2A 6B         [24]  717 	ljmp	_ak820_macro_init
                                    718 ;------------------------------------------------------------
                                    719 ;Allocation info for local variables in function 'ak820_nvm_ok'
                                    720 ;------------------------------------------------------------
                                    721 ;	keyboards/ajazz/ak820/ak820_nvm.c:112: bool ak820_nvm_ok(void) { return !storage_failed; }
                                    722 ;	-----------------------------------------
                                    723 ;	 function ak820_nvm_ok
                                    724 ;	-----------------------------------------
      00408F                        725 _ak820_nvm_ok:
      00408F A2 0A            [12]  726 	mov	c,_storage_failed
      004091 B3               [12]  727 	cpl	c
      004092 92 0B            [24]  728 	mov  _ak820_nvm_ok_sloc0_1_0,c
      004094 12 3A C6         [24]  729 	lcall	_ak820_outline_0166
      004097 22               [24]  730 	ret
                                    731 ;------------------------------------------------------------
                                    732 ;Allocation info for local variables in function 'ak820_nvm_schema_fault'
                                    733 ;------------------------------------------------------------
                                    734 ;	keyboards/ajazz/ak820/ak820_nvm.c:114: void ak820_nvm_schema_fault(void) { nvm_fail(AK820_NVM_FAULT_SCHEMA); }
                                    735 ;	-----------------------------------------
                                    736 ;	 function ak820_nvm_schema_fault
                                    737 ;	-----------------------------------------
      004098                        738 _ak820_nvm_schema_fault:
      004098 75 82 10         [24]  739 	mov	dpl, #0x10
      00409B 02 3D F7         [24]  740 	ljmp	_nvm_fail
                                    741 ;------------------------------------------------------------
                                    742 ;Allocation info for local variables in function 'ak820_nvm_flush'
                                    743 ;------------------------------------------------------------
                                    744 ;header        Allocated with name '_ak820_nvm_flush_header_10000_62'
                                    745 ;crc           Allocated with name '_ak820_nvm_flush_crc_10000_62'
                                    746 ;i             Allocated with name '_ak820_nvm_flush_i_10000_62'
                                    747 ;stage         Allocated with name '_ak820_nvm_flush_stage_10000_62'
                                    748 ;------------------------------------------------------------
                                    749 ;	keyboards/ajazz/ak820/ak820_nvm.c:116: void ak820_nvm_flush(void) {
                                    750 ;	-----------------------------------------
                                    751 ;	 function ak820_nvm_flush
                                    752 ;	-----------------------------------------
      00409E                        753 _ak820_nvm_flush:
                                    754 ;	keyboards/ajazz/ak820/ak820_nvm.c:121: if (!page_dirty || storage_failed) return;
      00409E 30 09 03         [24]  755 	jnb	_page_dirty,00101$
      0040A1 30 0A 01         [24]  756 	jnb	_storage_failed,00102$
      0040A4                        757 00101$:
      0040A4 22               [24]  758 	ret
      0040A5                        759 00102$:
                                    760 ;	keyboards/ajazz/ak820/ak820_nvm.c:122: crc = page_crc();
      0040A5 12 3E A5         [24]  761 	lcall	_page_crc
      0040A8 12 45 D4         [24]  762 	lcall	_ak820_outline_0132
                                    763 ;	keyboards/ajazz/ak820/ak820_nvm.c:123: header[0] = 0xA5u;
      0040AB 90 05 81         [24]  764 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      0040AE 74 A5            [12]  765 	mov	a,#0xa5
      0040B0 F0               [24]  766 	movx	@dptr,a
                                    767 ;	keyboards/ajazz/ak820/ak820_nvm.c:124: header[1] = (uint8_t)cached_page;
      0040B1 90 05 69         [24]  768 	mov	dptr,#_cached_page
      0040B4 E0               [24]  769 	movx	a,@dptr
      0040B5 90 05 82         [24]  770 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0001)
      0040B8 F0               [24]  771 	movx	@dptr,a
                                    772 ;	keyboards/ajazz/ak820/ak820_nvm.c:125: header[2] = (uint8_t)(cached_page >> 8);
      0040B9 90 05 83         [24]  773 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0002)
      0040BC E4               [12]  774 	clr	a
      0040BD F0               [24]  775 	movx	@dptr,a
                                    776 ;	keyboards/ajazz/ak820/ak820_nvm.c:126: header[3] = (uint8_t)crc;
      0040BE 8E 05            [24]  777 	mov	ar5,r6
      0040C0 90 05 84         [24]  778 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0003)
      0040C3 ED               [12]  779 	mov	a,r5
      0040C4 F0               [24]  780 	movx	@dptr,a
                                    781 ;	keyboards/ajazz/ak820/ak820_nvm.c:127: header[4] = (uint8_t)(crc >> 8);
      0040C5 8F 06            [24]  782 	mov	ar6,r7
      0040C7 90 05 85         [24]  783 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0004)
      0040CA EE               [12]  784 	mov	a,r6
      0040CB F0               [24]  785 	movx	@dptr,a
                                    786 ;	keyboards/ajazz/ak820/ak820_nvm.c:128: for (i = 1; i != 5; ++i) header[i + 4] = (uint8_t)~header[i];
      0040CC 7F 01            [12]  787 	mov	r7,#0x01
      0040CE                        788 00128$:
      0040CE 8F 06            [24]  789 	mov	ar6,r7
      0040D0 EE               [12]  790 	mov	a,r6
      0040D1 24 04            [12]  791 	add	a,#0x04
      0040D3 FE               [12]  792 	mov	r6,a
      0040D4 33               [12]  793 	rlc	a
      0040D5 95 E0            [12]  794 	subb	a,acc
      0040D7 FD               [12]  795 	mov	r5,a
      0040D8 EE               [12]  796 	mov	a,r6
      0040D9 24 81            [12]  797 	add	a, #_ak820_nvm_flush_header_10000_62
      0040DB FE               [12]  798 	mov	r6,a
      0040DC ED               [12]  799 	mov	a,r5
      0040DD 34 05            [12]  800 	addc	a, #(_ak820_nvm_flush_header_10000_62 >> 8)
      0040DF FD               [12]  801 	mov	r5,a
      0040E0 12 45 8E         [24]  802 	lcall	_ak820_outline_0041
      0040E3 FC               [12]  803 	mov	r4,a
      0040E4 63 04 FF         [24]  804 	xrl	ar4,#0xff
      0040E7 8E 82            [24]  805 	mov	dpl,r6
      0040E9 8D 83            [24]  806 	mov	dph,r5
      0040EB EC               [12]  807 	mov	a,r4
      0040EC F0               [24]  808 	movx	@dptr,a
      0040ED 0F               [12]  809 	inc	r7
      0040EE BF 05 DD         [24]  810 	cjne	r7,#0x05,00128$
                                    811 ;	keyboards/ajazz/ak820/ak820_nvm.c:131: stage = AK820_NVM_FAULT_HEADER_ERASE;
      0040F1 90 05 8A         [24]  812 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0040F4 74 05            [12]  813 	mov	a,#0x05
      0040F6 F0               [24]  814 	movx	@dptr,a
                                    815 ;	keyboards/ajazz/ak820/ak820_nvm.c:132: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      0040F7 90 EF 40         [24]  816 	mov	dptr,#0xef40
      0040FA 12 3C 06         [24]  817 	lcall	_ak820_flash_erase
      0040FD E5 82            [12]  818 	mov	a, dpl
      0040FF 70 03            [24]  819 	jnz	00269$
      004101 02 41 E7         [24]  820 	ljmp	00127$
      004104                        821 00269$:
                                    822 ;	keyboards/ajazz/ak820/ak820_nvm.c:133: stage = AK820_NVM_FAULT_HEADER_ZERO;
      004104 90 05 8A         [24]  823 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004107 74 06            [12]  824 	mov	a,#0x06
      004109 F0               [24]  825 	movx	@dptr,a
                                    826 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      00410A 7F 00            [12]  827 	mov	r7,#0x00
      00410C                        828 00130$:
                                    829 ;	keyboards/ajazz/ak820/ak820_nvm.c:135: if (ak820_flash_read(AK820_JOURNAL_HEADER + i)) goto failed;
      00410C 12 45 9A         [24]  830 	lcall	_ak820_outline_0052
      00410F 12 3A F9         [24]  831 	lcall	_ak820_flash_read
      004112 E5 82            [12]  832 	mov	a, dpl
      004114 60 03            [24]  833 	jz	00270$
      004116 02 41 E7         [24]  834 	ljmp	00127$
      004119                        835 00270$:
                                    836 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004119 0F               [12]  837 	inc	r7
      00411A BF 40 EF         [24]  838 	cjne	r7,#0x40,00130$
                                    839 ;	keyboards/ajazz/ak820/ak820_nvm.c:137: stage = AK820_NVM_FAULT_JOURNAL_WRITE;
      00411D 90 05 8A         [24]  840 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004120 74 07            [12]  841 	mov	a,#0x07
      004122 F0               [24]  842 	movx	@dptr,a
                                    843 ;	keyboards/ajazz/ak820/ak820_nvm.c:138: if (!write_page(AK820_JOURNAL_DATA)) goto failed;
      004123 90 EF 00         [24]  844 	mov	dptr,#0xef00
      004126 12 3E D8         [24]  845 	lcall	_write_page
      004129 E5 82            [12]  846 	mov	a, dpl
      00412B 70 03            [24]  847 	jnz	00273$
      00412D 02 41 E7         [24]  848 	ljmp	00127$
      004130                        849 00273$:
                                    850 ;	keyboards/ajazz/ak820/ak820_nvm.c:139: stage = AK820_NVM_FAULT_METADATA_PROGRAM;
      004130 90 05 8A         [24]  851 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004133 74 08            [12]  852 	mov	a,#0x08
      004135 F0               [24]  853 	movx	@dptr,a
                                    854 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      004136 7F 01            [12]  855 	mov	r7,#0x01
      004138                        856 00132$:
                                    857 ;	keyboards/ajazz/ak820/ak820_nvm.c:141: if (header[i] && !ak820_flash_program(AK820_JOURNAL_HEADER + i, header[i])) goto failed;
      004138 12 45 8E         [24]  858 	lcall	_ak820_outline_0041
      00413B FE               [12]  859 	mov	r6,a
      00413C 60 22            [24]  860 	jz	00133$
      00413E 8F 05            [24]  861 	mov	ar5,r7
      004140 7C 00            [12]  862 	mov	r4,#0x00
      004142 74 40            [12]  863 	mov	a,#0x40
      004144 2D               [12]  864 	add	a, r5
      004145 FD               [12]  865 	mov	r5,a
      004146 74 EF            [12]  866 	mov	a,#0xef
      004148 3C               [12]  867 	addc	a, r4
      004149 FC               [12]  868 	mov	r4,a
      00414A 90 05 02         [24]  869 	mov	dptr,#_ak820_flash_program_PARM_2
      00414D EE               [12]  870 	mov	a,r6
      00414E F0               [24]  871 	movx	@dptr,a
      00414F 12 46 0A         [24]  872 	lcall	_ak820_outline_0185
      004152 C0 07            [24]  873 	push	ar7
      004154 12 3C 66         [24]  874 	lcall	_ak820_flash_program
      004157 E5 82            [12]  875 	mov	a, dpl
      004159 D0 07            [24]  876 	pop	ar7
      00415B 70 03            [24]  877 	jnz	00275$
      00415D 02 41 E7         [24]  878 	ljmp	00127$
      004160                        879 00275$:
      004160                        880 00133$:
                                    881 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      004160 0F               [12]  882 	inc	r7
      004161 BF 09 D4         [24]  883 	cjne	r7,#0x09,00132$
                                    884 ;	keyboards/ajazz/ak820/ak820_nvm.c:143: stage = AK820_NVM_FAULT_METADATA_READBACK;
      004164 90 05 8A         [24]  885 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004167 74 09            [12]  886 	mov	a,#0x09
      004169 F0               [24]  887 	movx	@dptr,a
                                    888 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      00416A 7F 01            [12]  889 	mov	r7,#0x01
      00416C                        890 00134$:
                                    891 ;	keyboards/ajazz/ak820/ak820_nvm.c:145: if (ak820_flash_read(AK820_JOURNAL_HEADER + i) != header[i]) goto failed;
      00416C 12 45 9A         [24]  892 	lcall	_ak820_outline_0052
      00416F 12 3A F9         [24]  893 	lcall	_ak820_flash_read
      004172 AE 82            [24]  894 	mov	r6, dpl
      004174 12 45 8E         [24]  895 	lcall	_ak820_outline_0041
      004177 FD               [12]  896 	mov	r5,a
      004178 EE               [12]  897 	mov	a,r6
      004179 B5 05 6B         [24]  898 	cjne	a,ar5,00127$
                                    899 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      00417C 0F               [12]  900 	inc	r7
      00417D BF 09 EC         [24]  901 	cjne	r7,#0x09,00134$
                                    902 ;	keyboards/ajazz/ak820/ak820_nvm.c:148: stage = AK820_NVM_FAULT_COMMIT_PROGRAM;
      004180 90 05 8A         [24]  903 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004183 74 0A            [12]  904 	mov	a,#0x0a
      004185 F0               [24]  905 	movx	@dptr,a
                                    906 ;	keyboards/ajazz/ak820/ak820_nvm.c:149: if (!ak820_flash_program(AK820_JOURNAL_HEADER, header[0])) goto failed;
      004186 90 05 81         [24]  907 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      004189 E0               [24]  908 	movx	a,@dptr
      00418A 90 05 02         [24]  909 	mov	dptr,#_ak820_flash_program_PARM_2
      00418D F0               [24]  910 	movx	@dptr,a
      00418E 90 EF 40         [24]  911 	mov	dptr,#0xef40
      004191 12 3C 66         [24]  912 	lcall	_ak820_flash_program
      004194 E5 82            [12]  913 	mov	a, dpl
      004196 60 4F            [24]  914 	jz	00127$
                                    915 ;	keyboards/ajazz/ak820/ak820_nvm.c:150: stage = AK820_NVM_FAULT_COMMIT_READBACK;
      004198 90 05 8A         [24]  916 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      00419B 74 0B            [12]  917 	mov	a,#0x0b
      00419D F0               [24]  918 	movx	@dptr,a
                                    919 ;	keyboards/ajazz/ak820/ak820_nvm.c:151: if (ak820_flash_read(AK820_JOURNAL_HEADER) != header[0]) goto failed;
      00419E 90 EF 40         [24]  920 	mov	dptr,#0xef40
      0041A1 12 3A F9         [24]  921 	lcall	_ak820_flash_read
      0041A4 AF 82            [24]  922 	mov	r7, dpl
      0041A6 90 05 81         [24]  923 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      0041A9 E0               [24]  924 	movx	a,@dptr
      0041AA FE               [12]  925 	mov	r6,a
      0041AB EF               [12]  926 	mov	a,r7
      0041AC B5 06 38         [24]  927 	cjne	a,ar6,00127$
                                    928 ;	keyboards/ajazz/ak820/ak820_nvm.c:152: stage = AK820_NVM_FAULT_TARGET_WRITE;
      0041AF 90 05 8A         [24]  929 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0041B2 74 0C            [12]  930 	mov	a,#0x0c
      0041B4 F0               [24]  931 	movx	@dptr,a
                                    932 ;	keyboards/ajazz/ak820/ak820_nvm.c:153: if (!write_page(AK820_NVM_BASE + cached_page * AK820_FLASH_PAGE)) goto failed;
      0041B5 90 05 69         [24]  933 	mov	dptr,#_cached_page
      0041B8 E0               [24]  934 	movx	a,@dptr
      0041B9 FE               [12]  935 	mov	r6,a
      0041BA E4               [12]  936 	clr	a
      0041BB C3               [12]  937 	clr	c
      0041BC CE               [12]  938 	xch	a,r6
      0041BD 13               [12]  939 	rrc	a
      0041BE CE               [12]  940 	xch	a,r6
      0041BF 13               [12]  941 	rrc	a
      0041C0 A2 E0            [12]  942 	mov	c,acc.0
      0041C2 CE               [12]  943 	xch	a,r6
      0041C3 13               [12]  944 	rrc	a
      0041C4 CE               [12]  945 	xch	a,r6
      0041C5 13               [12]  946 	rrc	a
      0041C6 CE               [12]  947 	xch	a,r6
      0041C7 24 C7            [12]  948 	add	a,#0xc7
      0041C9 FF               [12]  949 	mov	r7,a
      0041CA 12 45 C9         [24]  950 	lcall	_ak820_outline_0116
      0041CD 12 3E D8         [24]  951 	lcall	_write_page
      0041D0 E5 82            [12]  952 	mov	a, dpl
      0041D2 60 13            [24]  953 	jz	00127$
                                    954 ;	keyboards/ajazz/ak820/ak820_nvm.c:154: stage = AK820_NVM_FAULT_CLEANUP;
      0041D4 90 05 8A         [24]  955 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0041D7 74 0D            [12]  956 	mov	a,#0x0d
      0041D9 F0               [24]  957 	movx	@dptr,a
                                    958 ;	keyboards/ajazz/ak820/ak820_nvm.c:155: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      0041DA 90 EF 40         [24]  959 	mov	dptr,#0xef40
      0041DD 12 3C 06         [24]  960 	lcall	_ak820_flash_erase
      0041E0 E5 82            [12]  961 	mov	a, dpl
      0041E2 60 03            [24]  962 	jz	00127$
                                    963 ;	keyboards/ajazz/ak820/ak820_nvm.c:156: page_dirty = false;
                                    964 ;	assignBit
      0041E4 C2 09            [12]  965 	clr	_page_dirty
                                    966 ;	keyboards/ajazz/ak820/ak820_nvm.c:157: return;
                                    967 ;	keyboards/ajazz/ak820/ak820_nvm.c:158: failed:
      0041E6 22               [24]  968 	ret
      0041E7                        969 00127$:
                                    970 ;	keyboards/ajazz/ak820/ak820_nvm.c:159: nvm_fail(stage);
      0041E7 90 05 8A         [24]  971 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0041EA E0               [24]  972 	movx	a,@dptr
      0041EB F5 82            [12]  973 	mov	dpl,a
                                    974 ;	keyboards/ajazz/ak820/ak820_nvm.c:160: }
      0041ED 02 3D F7         [24]  975 	ljmp	_nvm_fail
                                    976 ;------------------------------------------------------------
                                    977 ;Allocation info for local variables in function 'ak820_nvm_begin'
                                    978 ;------------------------------------------------------------
                                    979 ;	keyboards/ajazz/ak820/ak820_nvm.c:162: void ak820_nvm_begin(void) {
                                    980 ;	-----------------------------------------
                                    981 ;	 function ak820_nvm_begin
                                    982 ;	-----------------------------------------
      0041F0                        983 _ak820_nvm_begin:
                                    984 ;	keyboards/ajazz/ak820/ak820_nvm.c:163: if (batch_depth == 255u) nvm_fail(AK820_NVM_FAULT_BATCH_OVERFLOW);
      0041F0 90 05 6A         [24]  985 	mov	dptr,#_batch_depth
      0041F3 E0               [24]  986 	movx	a,@dptr
      0041F4 FF               [12]  987 	mov	r7,a
      0041F5 BF FF 06         [24]  988 	cjne	r7,#0xff,00102$
      0041F8 75 82 0F         [24]  989 	mov	dpl, #0x0f
      0041FB 02 3D F7         [24]  990 	ljmp	_nvm_fail
      0041FE                        991 00102$:
                                    992 ;	keyboards/ajazz/ak820/ak820_nvm.c:164: else ++batch_depth;
      0041FE 90 05 6A         [24]  993 	mov	dptr,#_batch_depth
      004201 EF               [12]  994 	mov	a,r7
      004202 04               [12]  995 	inc	a
      004203 F0               [24]  996 	movx	@dptr,a
                                    997 ;	keyboards/ajazz/ak820/ak820_nvm.c:165: }
      004204 22               [24]  998 	ret
                                    999 ;------------------------------------------------------------
                                   1000 ;Allocation info for local variables in function 'ak820_nvm_end'
                                   1001 ;------------------------------------------------------------
                                   1002 ;	keyboards/ajazz/ak820/ak820_nvm.c:167: void ak820_nvm_end(void) {
                                   1003 ;	-----------------------------------------
                                   1004 ;	 function ak820_nvm_end
                                   1005 ;	-----------------------------------------
      004205                       1006 _ak820_nvm_end:
                                   1007 ;	keyboards/ajazz/ak820/ak820_nvm.c:168: if (batch_depth) --batch_depth;
      004205 90 05 6A         [24] 1008 	mov	dptr,#_batch_depth
      004208 E0               [24] 1009 	movx	a,@dptr
      004209 FF               [12] 1010 	mov	r7,a
      00420A E0               [24] 1011 	movx	a,@dptr
      00420B 60 06            [24] 1012 	jz	00102$
      00420D EF               [12] 1013 	mov	a,r7
      00420E 14               [12] 1014 	dec	a
      00420F 90 05 6A         [24] 1015 	mov	dptr,#_batch_depth
      004212 F0               [24] 1016 	movx	@dptr,a
      004213                       1017 00102$:
                                   1018 ;	keyboards/ajazz/ak820/ak820_nvm.c:169: if (!batch_depth) ak820_nvm_flush();
      004213 90 05 6A         [24] 1019 	mov	dptr,#_batch_depth
      004216 E0               [24] 1020 	movx	a,@dptr
      004217 70 03            [24] 1021 	jnz	00105$
                                   1022 ;	keyboards/ajazz/ak820/ak820_nvm.c:170: }
      004219 02 40 9E         [24] 1023 	ljmp	_ak820_nvm_flush
      00421C                       1024 00105$:
      00421C 22               [24] 1025 	ret
                                   1026 ;------------------------------------------------------------
                                   1027 ;Allocation info for local variables in function 'load_page'
                                   1028 ;------------------------------------------------------------
                                   1029 ;page          Allocated with name '_load_page_page_10000_87'
                                   1030 ;i             Allocated with name '_load_page_i_10000_88'
                                   1031 ;------------------------------------------------------------
                                   1032 ;	keyboards/ajazz/ak820/ak820_nvm.c:172: static bool load_page(uint8_t page) {
                                   1033 ;	-----------------------------------------
                                   1034 ;	 function load_page
                                   1035 ;	-----------------------------------------
      00421D                       1036 _load_page:
      00421D E5 82            [12] 1037 	mov	a,dpl
      00421F 90 05 8B         [24] 1038 	mov	dptr,#_load_page_page_10000_87
      004222 F0               [24] 1039 	movx	@dptr,a
                                   1040 ;	keyboards/ajazz/ak820/ak820_nvm.c:174: if (page_valid && cached_page == page) return !storage_failed;
      004223 30 08 17         [24] 1041 	jnb	_page_valid,00102$
      004226 90 05 69         [24] 1042 	mov	dptr,#_cached_page
      004229 E0               [24] 1043 	movx	a,@dptr
      00422A FF               [12] 1044 	mov	r7,a
      00422B 90 05 8B         [24] 1045 	mov	dptr,#_load_page_page_10000_87
      00422E E0               [24] 1046 	movx	a,@dptr
      00422F FE               [12] 1047 	mov	r6,a
      004230 EF               [12] 1048 	mov	a,r7
      004231 B5 06 09         [24] 1049 	cjne	a,ar6,00102$
      004234 A2 0A            [12] 1050 	mov	c,_storage_failed
      004236 B3               [12] 1051 	cpl	c
      004237 92 0C            [24] 1052 	mov  _load_page_sloc0_1_0,c
      004239 12 3A C6         [24] 1053 	lcall	_ak820_outline_0166
      00423C 22               [24] 1054 	ret
      00423D                       1055 00102$:
                                   1056 ;	keyboards/ajazz/ak820/ak820_nvm.c:175: ak820_nvm_flush();
      00423D 12 40 9E         [24] 1057 	lcall	_ak820_nvm_flush
                                   1058 ;	keyboards/ajazz/ak820/ak820_nvm.c:176: if (storage_failed) return false;
      004240 30 0A 04         [24] 1059 	jnb	_storage_failed,00119$
      004243 75 82 00         [24] 1060 	mov	dpl, #0x00
                                   1061 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004246 22               [24] 1062 	ret
      004247                       1063 00119$:
      004247 7F 00            [12] 1064 	mov	r7,#0x00
      004249                       1065 00107$:
                                   1066 ;	keyboards/ajazz/ak820/ak820_nvm.c:178: page_data[i] = ak820_flash_read(AK820_NVM_BASE + page * AK820_FLASH_PAGE + i);
      004249 EF               [12] 1067 	mov	a,r7
      00424A 24 29            [12] 1068 	add	a, #_page_data
      00424C FD               [12] 1069 	mov	r5,a
      00424D E4               [12] 1070 	clr	a
      00424E 34 05            [12] 1071 	addc	a, #(_page_data >> 8)
      004250 FE               [12] 1072 	mov	r6,a
      004251 90 05 8B         [24] 1073 	mov	dptr,#_load_page_page_10000_87
      004254 E0               [24] 1074 	movx	a,@dptr
      004255 FC               [12] 1075 	mov	r4,a
      004256 FA               [12] 1076 	mov	r2,a
      004257 E4               [12] 1077 	clr	a
      004258 C3               [12] 1078 	clr	c
      004259 CA               [12] 1079 	xch	a,r2
      00425A 13               [12] 1080 	rrc	a
      00425B CA               [12] 1081 	xch	a,r2
      00425C 13               [12] 1082 	rrc	a
      00425D A2 E0            [12] 1083 	mov	c,acc.0
      00425F CA               [12] 1084 	xch	a,r2
      004260 13               [12] 1085 	rrc	a
      004261 CA               [12] 1086 	xch	a,r2
      004262 13               [12] 1087 	rrc	a
      004263 CA               [12] 1088 	xch	a,r2
      004264 24 C7            [12] 1089 	add	a,#0xc7
      004266 FB               [12] 1090 	mov	r3,a
      004267 8F 01            [24] 1091 	mov	ar1,r7
      004269 89 00            [24] 1092 	mov	ar0,r1
      00426B 79 00            [12] 1093 	mov	r1,#0x00
      00426D E8               [12] 1094 	mov	a,r0
      00426E 2A               [12] 1095 	add	a, r2
      00426F FA               [12] 1096 	mov	r2,a
      004270 E9               [12] 1097 	mov	a,r1
      004271 3B               [12] 1098 	addc	a, r3
      004272 FB               [12] 1099 	mov	r3,a
      004273 12 45 E5         [24] 1100 	lcall	_ak820_outline_0142
      004276 12 3A F9         [24] 1101 	lcall	_ak820_flash_read
      004279 AB 82            [24] 1102 	mov	r3, dpl
      00427B 12 3A AA         [24] 1103 	lcall	_ak820_outline_0131
      00427E EB               [12] 1104 	mov	a,r3
      00427F F0               [24] 1105 	movx	@dptr,a
                                   1106 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004280 0F               [12] 1107 	inc	r7
      004281 BF 40 C5         [24] 1108 	cjne	r7,#0x40,00107$
                                   1109 ;	keyboards/ajazz/ak820/ak820_nvm.c:180: cached_page = page;
      004284 90 05 69         [24] 1110 	mov	dptr,#_cached_page
      004287 EC               [12] 1111 	mov	a,r4
      004288 F0               [24] 1112 	movx	@dptr,a
                                   1113 ;	keyboards/ajazz/ak820/ak820_nvm.c:181: page_valid = true;
                                   1114 ;	assignBit
      004289 D2 08            [12] 1115 	setb	_page_valid
                                   1116 ;	keyboards/ajazz/ak820/ak820_nvm.c:182: return true;
      00428B 75 82 01         [24] 1117 	mov	dpl, #0x01
                                   1118 ;	keyboards/ajazz/ak820/ak820_nvm.c:183: }
      00428E 22               [24] 1119 	ret
                                   1120 ;------------------------------------------------------------
                                   1121 ;Allocation info for local variables in function 'read_offset'
                                   1122 ;------------------------------------------------------------
                                   1123 ;offset        Allocated with name '_read_offset_offset_10000_93'
                                   1124 ;------------------------------------------------------------
                                   1125 ;	keyboards/ajazz/ak820/ak820_nvm.c:185: static uint8_t read_offset(uint16_t offset) {
                                   1126 ;	-----------------------------------------
                                   1127 ;	 function read_offset
                                   1128 ;	-----------------------------------------
      00428F                       1129 _read_offset:
      00428F 12 3A 83         [24] 1130 	lcall	_ak820_outline_0103
      004292 90 05 8C         [24] 1131 	mov	dptr,#_read_offset_offset_10000_93
      004295 12 3A 88         [24] 1132 	lcall	_ak820_outline_0104
                                   1133 ;	keyboards/ajazz/ak820/ak820_nvm.c:186: if (offset >= AK820_NVM_SIZE) return 0;
      004298 90 05 8C         [24] 1134 	mov	dptr,#_read_offset_offset_10000_93
      00429B 12 3A 40         [24] 1135 	lcall	_ak820_outline_0051
      00429E C3               [12] 1136 	clr	c
      00429F 94 28            [12] 1137 	subb	a,#0x28
      0042A1 40 04            [24] 1138 	jc	00102$
      0042A3 75 82 00         [24] 1139 	mov	dpl, #0x00
      0042A6 22               [24] 1140 	ret
      0042A7                       1141 00102$:
                                   1142 ;	keyboards/ajazz/ak820/ak820_nvm.c:187: if (page_valid && (offset / AK820_FLASH_PAGE) == cached_page)
      0042A7 30 08 34         [24] 1143 	jnb	_page_valid,00104$
      0042AA 8E 04            [24] 1144 	mov	ar4,r6
      0042AC EF               [12] 1145 	mov	a,r7
      0042AD A2 E7            [12] 1146 	mov	c,acc.7
      0042AF CC               [12] 1147 	xch	a,r4
      0042B0 33               [12] 1148 	rlc	a
      0042B1 CC               [12] 1149 	xch	a,r4
      0042B2 33               [12] 1150 	rlc	a
      0042B3 A2 E7            [12] 1151 	mov	c,acc.7
      0042B5 CC               [12] 1152 	xch	a,r4
      0042B6 33               [12] 1153 	rlc	a
      0042B7 CC               [12] 1154 	xch	a,r4
      0042B8 33               [12] 1155 	rlc	a
      0042B9 CC               [12] 1156 	xch	a,r4
      0042BA 54 03            [12] 1157 	anl	a,#0x03
      0042BC FD               [12] 1158 	mov	r5,a
      0042BD 90 05 69         [24] 1159 	mov	dptr,#_cached_page
      0042C0 E0               [24] 1160 	movx	a,@dptr
      0042C1 FA               [12] 1161 	mov	r2,a
      0042C2 7B 00            [12] 1162 	mov	r3,#0x00
      0042C4 EC               [12] 1163 	mov	a,r4
      0042C5 B5 02 16         [24] 1164 	cjne	a,ar2,00104$
      0042C8 ED               [12] 1165 	mov	a,r5
      0042C9 B5 03 12         [24] 1166 	cjne	a,ar3,00104$
                                   1167 ;	keyboards/ajazz/ak820/ak820_nvm.c:188: return page_data[offset % AK820_FLASH_PAGE];
      0042CC 74 3F            [12] 1168 	mov	a,#0x3f
      0042CE 5E               [12] 1169 	anl	a,r6
      0042CF 7D 00            [12] 1170 	mov	r5,#0x00
      0042D1 24 29            [12] 1171 	add	a, #_page_data
      0042D3 F5 82            [12] 1172 	mov	dpl,a
      0042D5 ED               [12] 1173 	mov	a,r5
      0042D6 34 05            [12] 1174 	addc	a, #(_page_data >> 8)
      0042D8 F5 83            [12] 1175 	mov	dph,a
      0042DA E0               [24] 1176 	movx	a,@dptr
      0042DB F5 82            [12] 1177 	mov	dpl,a
      0042DD 22               [24] 1178 	ret
      0042DE                       1179 00104$:
                                   1180 ;	keyboards/ajazz/ak820/ak820_nvm.c:189: return ak820_flash_read(AK820_NVM_BASE + offset);
      0042DE 74 C7            [12] 1181 	mov	a,#0xc7
      0042E0 2F               [12] 1182 	add	a, r7
      0042E1 FF               [12] 1183 	mov	r7,a
      0042E2 12 45 C9         [24] 1184 	lcall	_ak820_outline_0116
                                   1185 ;	keyboards/ajazz/ak820/ak820_nvm.c:190: }
      0042E5 02 3A F9         [24] 1186 	ljmp	_ak820_flash_read
                                   1187 ;------------------------------------------------------------
                                   1188 ;Allocation info for local variables in function 'eeprom_read_byte'
                                   1189 ;------------------------------------------------------------
                                   1190 ;addr          Allocated with name '_eeprom_read_byte_addr_10000_97'
                                   1191 ;------------------------------------------------------------
                                   1192 ;	keyboards/ajazz/ak820/ak820_nvm.c:193: uint8_t eeprom_read_byte(const uint8_t *addr) {
                                   1193 ;	-----------------------------------------
                                   1194 ;	 function eeprom_read_byte
                                   1195 ;	-----------------------------------------
      0042E8                       1196 _eeprom_read_byte:
      0042E8 C0 07            [24] 1197 	push	ar7
      0042EA C0 06            [24] 1198 	push	ar6
      0042EC 12 45 87         [24] 1199 	lcall	_ak820_outline_0037
      0042EF 90 05 8E         [24] 1200 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      0042F2 12 3A 1F         [24] 1201 	lcall	_ak820_outline_0016
                                   1202 ;	keyboards/ajazz/ak820/ak820_nvm.c:194: return read_offset((uint16_t)(uintptr_t)addr);
      0042F5 90 05 8E         [24] 1203 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      0042F8 12 39 E0         [24] 1204 	lcall	_ak820_outline_0004
      0042FB C0 06            [24] 1205 	push	ar6
      0042FD C0 05            [24] 1206 	push	ar5
      0042FF C0 04            [24] 1207 	push	ar4
      004301 C0 03            [24] 1208 	push	ar3
      004303 C0 02            [24] 1209 	push	ar2
      004305 C0 01            [24] 1210 	push	ar1
      004307 C0 00            [24] 1211 	push	ar0
      004309 12 42 8F         [24] 1212 	lcall	_read_offset
      00430C AF 82            [24] 1213 	mov	r7, dpl
      00430E D0 00            [24] 1214 	pop	ar0
      004310 D0 01            [24] 1215 	pop	ar1
      004312 D0 02            [24] 1216 	pop	ar2
      004314 D0 03            [24] 1217 	pop	ar3
      004316 D0 04            [24] 1218 	pop	ar4
      004318 D0 05            [24] 1219 	pop	ar5
      00431A D0 06            [24] 1220 	pop	ar6
      00431C 8F 82            [24] 1221 	mov	dpl, r7
                                   1222 ;	keyboards/ajazz/ak820/ak820_nvm.c:195: }
      00431E D0 06            [24] 1223 	pop	ar6
      004320 D0 07            [24] 1224 	pop	ar7
      004322 22               [24] 1225 	ret
                                   1226 ;------------------------------------------------------------
                                   1227 ;Allocation info for local variables in function 'eeprom_read_block'
                                   1228 ;------------------------------------------------------------
                                   1229 ;addr          Allocated with name '_eeprom_read_block_PARM_2'
                                   1230 ;len           Allocated with name '_eeprom_read_block_PARM_3'
                                   1231 ;buf           Allocated with name '_eeprom_read_block_buf_10000_99'
                                   1232 ;offset        Allocated with name '_eeprom_read_block_offset_10000_100'
                                   1233 ;out           Allocated with name '_eeprom_read_block_out_10000_100'
                                   1234 ;------------------------------------------------------------
                                   1235 ;	keyboards/ajazz/ak820/ak820_nvm.c:199: void eeprom_read_block(void *buf, const void *addr, size_t len) {
                                   1236 ;	-----------------------------------------
                                   1237 ;	 function ak820_eeprom_read_block_xdata
                                   1238 ;	-----------------------------------------
      004323                       1239 _ak820_eeprom_read_block_xdata:
      004323 12 3A 83         [24] 1240 	lcall	_ak820_outline_0103
      004326 90 05 96         [24] 1241 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      004329 12 3A 88         [24] 1242 	lcall	_ak820_outline_0104
                                   1243 ;	keyboards/ajazz/ak820/ak820_nvm.c:230: uint16_t offset = (uint16_t)(uintptr_t)addr;
      00432C 90 05 91         [24] 1244 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      00432F 12 3A 40         [24] 1245 	lcall	_ak820_outline_0051
                                   1246 ;	keyboards/ajazz/ak820/ak820_nvm.c:231: uint8_t AK820_XDATA *out = (uint8_t AK820_XDATA *)buf;
      004332 90 05 96         [24] 1247 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      004335 12 3A 5F         [24] 1248 	lcall	_ak820_outline_0060
      004338 90 05 98         [24] 1249 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      00433B 12 3A 65         [24] 1250 	lcall	_ak820_outline_0071
                                   1251 ;	keyboards/ajazz/ak820/ak820_nvm.c:232: while (len--) {
      00433E 90 05 94         [24] 1252 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      004341 12 3A 5F         [24] 1253 	lcall	_ak820_outline_0060
      004344                       1254 00103$:
      004344 8C 02            [24] 1255 	mov	ar2,r4
      004346 8D 03            [24] 1256 	mov	ar3,r5
      004348 1C               [12] 1257 	dec	r4
      004349 BC FF 01         [24] 1258 	cjne	r4,#0xff,00130$
      00434C 1D               [12] 1259 	dec	r5
      00434D                       1260 00130$:
      00434D EA               [12] 1261 	mov	a,r2
      00434E 4B               [12] 1262 	orl	a,r3
      00434F 60 5D            [24] 1263 	jz	00106$
                                   1264 ;	keyboards/ajazz/ak820/ak820_nvm.c:233: if (offset >= AK820_NVM_SIZE) { *out++ = 0; continue; }
      004351 8E 02            [24] 1265 	mov	ar2,r6
      004353 8F 03            [24] 1266 	mov	ar3,r7
      004355 74 D8            [12] 1267 	mov	a,#0x100 - 0x28
      004357 2B               [12] 1268 	add	a,r3
      004358 50 17            [24] 1269 	jnc	00102$
      00435A 90 05 98         [24] 1270 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      00435D 12 45 CE         [24] 1271 	lcall	_ak820_outline_0119
      004360 12 45 E5         [24] 1272 	lcall	_ak820_outline_0142
      004363 E4               [12] 1273 	clr	a
      004364 F0               [24] 1274 	movx	@dptr,a
      004365 90 05 98         [24] 1275 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004368 04               [12] 1276 	inc	a
      004369 2A               [12] 1277 	add	a, r2
      00436A F0               [24] 1278 	movx	@dptr,a
      00436B E4               [12] 1279 	clr	a
      00436C 3B               [12] 1280 	addc	a, r3
      00436D A3               [24] 1281 	inc	dptr
      00436E F0               [24] 1282 	movx	@dptr,a
      00436F 80 D3            [24] 1283 	sjmp	00103$
      004371                       1284 00102$:
                                   1285 ;	keyboards/ajazz/ak820/ak820_nvm.c:234: *out++ = read_offset(offset);
      004371 90 05 98         [24] 1286 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004374 12 45 CE         [24] 1287 	lcall	_ak820_outline_0119
      004377 12 45 C9         [24] 1288 	lcall	_ak820_outline_0116
      00437A C0 07            [24] 1289 	push	ar7
      00437C C0 06            [24] 1290 	push	ar6
      00437E C0 05            [24] 1291 	push	ar5
      004380 C0 04            [24] 1292 	push	ar4
      004382 C0 03            [24] 1293 	push	ar3
      004384 C0 02            [24] 1294 	push	ar2
      004386 12 42 8F         [24] 1295 	lcall	_read_offset
      004389 A9 82            [24] 1296 	mov	r1, dpl
      00438B D0 02            [24] 1297 	pop	ar2
      00438D D0 03            [24] 1298 	pop	ar3
      00438F D0 04            [24] 1299 	pop	ar4
      004391 D0 05            [24] 1300 	pop	ar5
      004393 D0 06            [24] 1301 	pop	ar6
      004395 D0 07            [24] 1302 	pop	ar7
      004397 12 45 E5         [24] 1303 	lcall	_ak820_outline_0142
      00439A E9               [12] 1304 	mov	a,r1
      00439B F0               [24] 1305 	movx	@dptr,a
      00439C 90 05 98         [24] 1306 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      00439F 74 01            [12] 1307 	mov	a,#0x01
      0043A1 2A               [12] 1308 	add	a, r2
      0043A2 F0               [24] 1309 	movx	@dptr,a
      0043A3 E4               [12] 1310 	clr	a
      0043A4 3B               [12] 1311 	addc	a, r3
      0043A5 A3               [24] 1312 	inc	dptr
      0043A6 F0               [24] 1313 	movx	@dptr,a
                                   1314 ;	keyboards/ajazz/ak820/ak820_nvm.c:235: ++offset;
      0043A7 0E               [12] 1315 	inc	r6
      0043A8 BE 00 99         [24] 1316 	cjne	r6,#0x00,00103$
      0043AB 0F               [12] 1317 	inc	r7
      0043AC 80 96            [24] 1318 	sjmp	00103$
      0043AE                       1319 00106$:
                                   1320 ;	keyboards/ajazz/ak820/ak820_nvm.c:237: }
      0043AE 22               [24] 1321 	ret
                                   1322 ;------------------------------------------------------------
                                   1323 ;Allocation info for local variables in function 'ak820_eeprom_write_block_xdata'
                                   1324 ;------------------------------------------------------------
                                   1325 ;sloc0         Allocated with name '_ak820_eeprom_write_block_xdata_sloc0_1_0'
                                   1326 ;addr          Allocated with name '_ak820_eeprom_write_block_xdata_PARM_2'
                                   1327 ;len           Allocated with name '_ak820_eeprom_write_block_xdata_PARM_3'
                                   1328 ;buf           Allocated with name '_ak820_eeprom_write_block_xdata_buf_10000_118'
                                   1329 ;offset        Allocated with name '_ak820_eeprom_write_block_xdata_offset_10000_119'
                                   1330 ;in            Allocated with name '_ak820_eeprom_write_block_xdata_in_10000_119'
                                   1331 ;value         Allocated with name '_ak820_eeprom_write_block_xdata_value_20000_122'
                                   1332 ;------------------------------------------------------------
                                   1333 ;	keyboards/ajazz/ak820/ak820_nvm.c:239: void ak820_eeprom_write_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1334 ;	-----------------------------------------
                                   1335 ;	 function ak820_eeprom_write_block_xdata
                                   1336 ;	-----------------------------------------
      0043AF                       1337 _ak820_eeprom_write_block_xdata:
      0043AF 12 3A 83         [24] 1338 	lcall	_ak820_outline_0103
      0043B2 90 05 9F         [24] 1339 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      0043B5 12 3A 88         [24] 1340 	lcall	_ak820_outline_0104
                                   1341 ;	keyboards/ajazz/ak820/ak820_nvm.c:240: uint16_t offset = (uint16_t)(uintptr_t)addr;
      0043B8 90 05 9A         [24] 1342 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      0043BB 12 3A 40         [24] 1343 	lcall	_ak820_outline_0051
                                   1344 ;	keyboards/ajazz/ak820/ak820_nvm.c:241: const uint8_t AK820_XDATA *in = (const uint8_t AK820_XDATA *)buf;
      0043BE 90 05 9F         [24] 1345 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      0043C1 12 3A 5F         [24] 1346 	lcall	_ak820_outline_0060
                                   1347 ;	keyboards/ajazz/ak820/ak820_nvm.c:243: if (offset > AK820_NVM_SIZE || len > AK820_NVM_SIZE - offset) {
      0043C4 8E 02            [24] 1348 	mov	ar2,r6
      0043C6 8F 03            [24] 1349 	mov	ar3,r7
      0043C8 C3               [12] 1350 	clr	c
      0043C9 E4               [12] 1351 	clr	a
      0043CA 9A               [12] 1352 	subb	a,r2
      0043CB 74 28            [12] 1353 	mov	a,#0x28
      0043CD 9B               [12] 1354 	subb	a,r3
      0043CE 40 15            [24] 1355 	jc	00101$
                                   1356 ;	free result
      0043D0 E4               [12] 1357 	clr	a
      0043D1 C3               [12] 1358 	clr	c
      0043D2 9E               [12] 1359 	subb	a,r6
      0043D3 FA               [12] 1360 	mov	r2,a
      0043D4 74 28            [12] 1361 	mov	a,#0x28
      0043D6 9F               [12] 1362 	subb	a,r7
      0043D7 FB               [12] 1363 	mov	r3,a
      0043D8 90 05 9D         [24] 1364 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0043DB 12 3A 7D         [24] 1365 	lcall	_ak820_outline_0100
      0043DE C3               [12] 1366 	clr	c
      0043DF EA               [12] 1367 	mov	a,r2
      0043E0 98               [12] 1368 	subb	a,r0
      0043E1 EB               [12] 1369 	mov	a,r3
      0043E2 99               [12] 1370 	subb	a,r1
      0043E3 50 06            [24] 1371 	jnc	00125$
                                   1372 ;	free result
      0043E5                       1373 00101$:
                                   1374 ;	keyboards/ajazz/ak820/ak820_nvm.c:244: nvm_fail(AK820_NVM_FAULT_WRITE_RANGE);
      0043E5 75 82 0E         [24] 1375 	mov	dpl, #0x0e
                                   1376 ;	keyboards/ajazz/ak820/ak820_nvm.c:245: return;
      0043E8 02 3D F7         [24] 1377 	ljmp	_nvm_fail
                                   1378 ;	keyboards/ajazz/ak820/ak820_nvm.c:247: while (len--) {
      0043EB                       1379 00125$:
      0043EB 90 05 9D         [24] 1380 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0043EE 12 45 CE         [24] 1381 	lcall	_ak820_outline_0119
      0043F1                       1382 00108$:
      0043F1 8A 00            [24] 1383 	mov	ar0,r2
      0043F3 8B 01            [24] 1384 	mov	ar1,r3
      0043F5 1A               [12] 1385 	dec	r2
      0043F6 BA FF 01         [24] 1386 	cjne	r2,#0xff,00159$
      0043F9 1B               [12] 1387 	dec	r3
      0043FA                       1388 00159$:
      0043FA E8               [12] 1389 	mov	a,r0
      0043FB 49               [12] 1390 	orl	a,r1
      0043FC 70 03            [24] 1391 	jnz	00160$
      0043FE 02 44 88         [24] 1392 	ljmp	00110$
      004401                       1393 00160$:
                                   1394 ;	keyboards/ajazz/ak820/ak820_nvm.c:248: uint8_t value = *in++;
      004401 C0 02            [24] 1395 	push	ar2
      004403 C0 03            [24] 1396 	push	ar3
      004405 12 45 B1         [24] 1397 	lcall	_ak820_outline_0092
      004408 F9               [12] 1398 	mov	r1,a
      004409 A3               [24] 1399 	inc	dptr
      00440A 12 45 EA         [24] 1400 	lcall	_ak820_outline_0148
                                   1401 ;	keyboards/ajazz/ak820/ak820_nvm.c:249: if (!load_page(offset / AK820_FLASH_PAGE)) return;
      00440D 8E 0C            [24] 1402 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,r6
      00440F 8F 0D            [24] 1403 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),r7
      004411 A8 0C            [24] 1404 	mov	r0,_ak820_eeprom_write_block_xdata_sloc0_1_0
      004413 E5 0D            [12] 1405 	mov	a,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      004415 A2 E7            [12] 1406 	mov	c,acc.7
      004417 C8               [12] 1407 	xch	a,r0
      004418 33               [12] 1408 	rlc	a
      004419 C8               [12] 1409 	xch	a,r0
      00441A 33               [12] 1410 	rlc	a
      00441B A2 E7            [12] 1411 	mov	c,acc.7
      00441D C8               [12] 1412 	xch	a,r0
      00441E 33               [12] 1413 	rlc	a
      00441F C8               [12] 1414 	xch	a,r0
      004420 33               [12] 1415 	rlc	a
      004421 C8               [12] 1416 	xch	a,r0
      004422 54 03            [12] 1417 	anl	a,#0x03
      004424 FB               [12] 1418 	mov	r3,a
      004425 88 82            [24] 1419 	mov	dpl, r0
      004427 C0 07            [24] 1420 	push	ar7
      004429 C0 06            [24] 1421 	push	ar6
      00442B C0 05            [24] 1422 	push	ar5
      00442D C0 04            [24] 1423 	push	ar4
      00442F C0 03            [24] 1424 	push	ar3
      004431 C0 02            [24] 1425 	push	ar2
      004433 C0 01            [24] 1426 	push	ar1
      004435 12 42 1D         [24] 1427 	lcall	_load_page
      004438 E5 82            [12] 1428 	mov	a, dpl
      00443A D0 01            [24] 1429 	pop	ar1
      00443C D0 02            [24] 1430 	pop	ar2
      00443E D0 03            [24] 1431 	pop	ar3
      004440 D0 04            [24] 1432 	pop	ar4
      004442 D0 05            [24] 1433 	pop	ar5
      004444 D0 06            [24] 1434 	pop	ar6
      004446 D0 07            [24] 1435 	pop	ar7
      004448 D0 03            [24] 1436 	pop	ar3
      00444A D0 02            [24] 1437 	pop	ar2
      00444C 70 01            [24] 1438 	jnz	00105$
      00444E 22               [24] 1439 	ret
      00444F                       1440 00105$:
                                   1441 ;	keyboards/ajazz/ak820/ak820_nvm.c:250: if (page_data[offset % AK820_FLASH_PAGE] != value) {
      00444F C0 06            [24] 1442 	push	ar6
      004451 C0 07            [24] 1443 	push	ar7
      004453 74 3F            [12] 1444 	mov	a,#0x3f
      004455 55 0C            [12] 1445 	anl	a,_ak820_eeprom_write_block_xdata_sloc0_1_0
      004457 7F 00            [12] 1446 	mov	r7,#0x00
      004459 24 29            [12] 1447 	add	a, #_page_data
      00445B F5 0C            [12] 1448 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,a
      00445D EF               [12] 1449 	mov	a,r7
      00445E 34 05            [12] 1450 	addc	a, #(_page_data >> 8)
      004460 F5 0D            [12] 1451 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),a
      004462 85 0C 82         [24] 1452 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      004465 85 0D 83         [24] 1453 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      004468 E0               [24] 1454 	movx	a,@dptr
      004469 B5 01 06         [24] 1455 	cjne	a,ar1,00162$
      00446C D0 07            [24] 1456 	pop	ar7
      00446E D0 06            [24] 1457 	pop	ar6
      004470 80 0E            [24] 1458 	sjmp	00107$
      004472                       1459 00162$:
      004472 D0 07            [24] 1460 	pop	ar7
      004474 D0 06            [24] 1461 	pop	ar6
                                   1462 ;	keyboards/ajazz/ak820/ak820_nvm.c:251: page_data[offset % AK820_FLASH_PAGE] = value;
      004476 85 0C 82         [24] 1463 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      004479 85 0D 83         [24] 1464 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      00447C E9               [12] 1465 	mov	a,r1
      00447D F0               [24] 1466 	movx	@dptr,a
                                   1467 ;	keyboards/ajazz/ak820/ak820_nvm.c:252: page_dirty = true;
                                   1468 ;	assignBit
      00447E D2 09            [12] 1469 	setb	_page_dirty
      004480                       1470 00107$:
                                   1471 ;	keyboards/ajazz/ak820/ak820_nvm.c:254: ++offset;
      004480 0E               [12] 1472 	inc	r6
      004481 BE 00 01         [24] 1473 	cjne	r6,#0x00,00163$
      004484 0F               [12] 1474 	inc	r7
      004485                       1475 00163$:
      004485 02 43 F1         [24] 1476 	ljmp	00108$
      004488                       1477 00110$:
                                   1478 ;	keyboards/ajazz/ak820/ak820_nvm.c:256: if (!batch_depth) ak820_nvm_flush();
      004488 90 05 6A         [24] 1479 	mov	dptr,#_batch_depth
      00448B E0               [24] 1480 	movx	a,@dptr
      00448C 70 03            [24] 1481 	jnz	00113$
                                   1482 ;	keyboards/ajazz/ak820/ak820_nvm.c:257: }
      00448E 02 40 9E         [24] 1483 	ljmp	_ak820_nvm_flush
      004491                       1484 00113$:
      004491 22               [24] 1485 	ret
                                   1486 ;------------------------------------------------------------
                                   1487 ;Allocation info for local variables in function 'ak820_eeprom_update_block_xdata'
                                   1488 ;------------------------------------------------------------
                                   1489 ;sloc0         Allocated with name '_ak820_eeprom_update_block_xdata_sloc0_1_0'
                                   1490 ;sloc1         Allocated with name '_ak820_eeprom_update_block_xdata_sloc1_1_0'
                                   1491 ;sloc2         Allocated with name '_ak820_eeprom_update_block_xdata_sloc2_1_0'
                                   1492 ;addr          Allocated with name '_ak820_eeprom_update_block_xdata_PARM_2'
                                   1493 ;len           Allocated with name '_ak820_eeprom_update_block_xdata_PARM_3'
                                   1494 ;buf           Allocated with name '_ak820_eeprom_update_block_xdata_buf_10000_127'
                                   1495 ;source        Allocated with name '_ak820_eeprom_update_block_xdata_source_10000_128'
                                   1496 ;offset        Allocated with name '_ak820_eeprom_update_block_xdata_offset_10000_128'
                                   1497 ;i             Allocated with name '_ak820_eeprom_update_block_xdata_i_10000_128'
                                   1498 ;------------------------------------------------------------
                                   1499 ;	keyboards/ajazz/ak820/ak820_nvm.c:259: void ak820_eeprom_update_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1500 ;	-----------------------------------------
                                   1501 ;	 function ak820_eeprom_update_block_xdata
                                   1502 ;	-----------------------------------------
      004492                       1503 _ak820_eeprom_update_block_xdata:
      004492 12 3A 83         [24] 1504 	lcall	_ak820_outline_0103
      004495 90 05 A6         [24] 1505 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      004498 12 3A 88         [24] 1506 	lcall	_ak820_outline_0104
                                   1507 ;	keyboards/ajazz/ak820/ak820_nvm.c:260: const uint8_t AK820_XDATA *source = (const uint8_t AK820_XDATA *)buf;
      00449B 90 05 A6         [24] 1508 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      00449E 12 3A 40         [24] 1509 	lcall	_ak820_outline_0051
                                   1510 ;	keyboards/ajazz/ak820/ak820_nvm.c:261: uint16_t offset = (uint16_t)(uintptr_t)addr;
      0044A1 90 05 A1         [24] 1511 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      0044A4 E0               [24] 1512 	movx	a,@dptr
      0044A5 F5 12            [12] 1513 	mov	_ak820_eeprom_update_block_xdata_sloc2_1_0,a
      0044A7 A3               [24] 1514 	inc	dptr
      0044A8 E0               [24] 1515 	movx	a,@dptr
      0044A9 F5 13            [12] 1516 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1),a
      0044AB A3               [24] 1517 	inc	dptr
      0044AC E0               [24] 1518 	movx	a,@dptr
      0044AD F5 14            [12] 1519 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2),a
      0044AF A9 12            [24] 1520 	mov	r1,_ak820_eeprom_update_block_xdata_sloc2_1_0
      0044B1 AA 13            [24] 1521 	mov	r2,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
                                   1522 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      0044B3 E4               [12] 1523 	clr	a
      0044B4 F5 0E            [12] 1524 	mov	_ak820_eeprom_update_block_xdata_sloc0_1_0,a
      0044B6 F5 0F            [12] 1525 	mov	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1),a
      0044B8                       1526 00105$:
      0044B8 90 05 A4         [24] 1527 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      0044BB E0               [24] 1528 	movx	a,@dptr
      0044BC F5 10            [12] 1529 	mov	_ak820_eeprom_update_block_xdata_sloc1_1_0,a
      0044BE A3               [24] 1530 	inc	dptr
      0044BF E0               [24] 1531 	movx	a,@dptr
      0044C0 F5 11            [12] 1532 	mov	(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1),a
      0044C2 C3               [12] 1533 	clr	c
      0044C3 E5 0E            [12] 1534 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      0044C5 95 10            [12] 1535 	subb	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      0044C7 E5 0F            [12] 1536 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      0044C9 95 11            [12] 1537 	subb	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      0044CB 50 68            [24] 1538 	jnc	00107$
                                   1539 ;	keyboards/ajazz/ak820/ak820_nvm.c:264: if (read_offset(offset + i) != source[i]) {
      0044CD 89 00            [24] 1540 	mov	ar0,r1
      0044CF 8A 05            [24] 1541 	mov	ar5,r2
      0044D1 E5 0E            [12] 1542 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      0044D3 28               [12] 1543 	add	a, r0
      0044D4 F8               [12] 1544 	mov	r0,a
      0044D5 E5 0F            [12] 1545 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      0044D7 3D               [12] 1546 	addc	a, r5
      0044D8 FD               [12] 1547 	mov	r5,a
      0044D9 88 82            [24] 1548 	mov	dpl, r0
      0044DB 8D 83            [24] 1549 	mov	dph, r5
      0044DD C0 07            [24] 1550 	push	ar7
      0044DF C0 06            [24] 1551 	push	ar6
      0044E1 C0 02            [24] 1552 	push	ar2
      0044E3 C0 01            [24] 1553 	push	ar1
      0044E5 12 42 8F         [24] 1554 	lcall	_read_offset
      0044E8 AD 82            [24] 1555 	mov	r5, dpl
      0044EA D0 01            [24] 1556 	pop	ar1
      0044EC D0 02            [24] 1557 	pop	ar2
      0044EE D0 06            [24] 1558 	pop	ar6
      0044F0 D0 07            [24] 1559 	pop	ar7
      0044F2 E5 0E            [12] 1560 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      0044F4 2E               [12] 1561 	add	a, r6
      0044F5 F5 82            [12] 1562 	mov	dpl,a
      0044F7 E5 0F            [12] 1563 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      0044F9 3F               [12] 1564 	addc	a, r7
      0044FA F5 83            [12] 1565 	mov	dph,a
      0044FC E0               [24] 1566 	movx	a,@dptr
      0044FD FC               [12] 1567 	mov	r4,a
      0044FE ED               [12] 1568 	mov	a,r5
      0044FF B5 04 02         [24] 1569 	cjne	a,ar4,00131$
      004502 80 27            [24] 1570 	sjmp	00106$
      004504                       1571 00131$:
                                   1572 ;	keyboards/ajazz/ak820/ak820_nvm.c:265: ak820_eeprom_write_block_xdata(buf, addr, len);
      004504 90 05 A6         [24] 1573 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      004507 E0               [24] 1574 	movx	a,@dptr
      004508 F8               [12] 1575 	mov	r0,a
      004509 A3               [24] 1576 	inc	dptr
      00450A E0               [24] 1577 	movx	a,@dptr
      00450B FD               [12] 1578 	mov	r5,a
      00450C 90 05 9A         [24] 1579 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      00450F E5 12            [12] 1580 	mov	a,_ak820_eeprom_update_block_xdata_sloc2_1_0
      004511 F0               [24] 1581 	movx	@dptr,a
      004512 E5 13            [12] 1582 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
      004514 A3               [24] 1583 	inc	dptr
      004515 F0               [24] 1584 	movx	@dptr,a
      004516 E5 14            [12] 1585 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2)
      004518 A3               [24] 1586 	inc	dptr
      004519 F0               [24] 1587 	movx	@dptr,a
      00451A 90 05 9D         [24] 1588 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      00451D E5 10            [12] 1589 	mov	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      00451F F0               [24] 1590 	movx	@dptr,a
      004520 E5 11            [12] 1591 	mov	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      004522 A3               [24] 1592 	inc	dptr
      004523 F0               [24] 1593 	movx	@dptr,a
      004524 88 82            [24] 1594 	mov	dpl, r0
      004526 8D 83            [24] 1595 	mov	dph, r5
                                   1596 ;	keyboards/ajazz/ak820/ak820_nvm.c:266: return;
      004528 02 43 AF         [24] 1597 	ljmp	_ak820_eeprom_write_block_xdata
      00452B                       1598 00106$:
                                   1599 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      00452B 05 0E            [12] 1600 	inc	_ak820_eeprom_update_block_xdata_sloc0_1_0
      00452D E4               [12] 1601 	clr	a
      00452E B5 0E 87         [24] 1602 	cjne	a,_ak820_eeprom_update_block_xdata_sloc0_1_0,00105$
      004531 05 0F            [12] 1603 	inc	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      004533 80 83            [24] 1604 	sjmp	00105$
      004535                       1605 00107$:
                                   1606 ;	keyboards/ajazz/ak820/ak820_nvm.c:269: }
      004535 22               [24] 1607 	ret
                                   1608 ;------------------------------------------------------------
                                   1609 ;Allocation info for local variables in function 'eeprom_driver_erase'
                                   1610 ;------------------------------------------------------------
                                   1611 ;page          Allocated with name '_eeprom_driver_erase_page_10000_134'
                                   1612 ;i             Allocated with name '_eeprom_driver_erase_i_10000_134'
                                   1613 ;------------------------------------------------------------
                                   1614 ;	keyboards/ajazz/ak820/ak820_nvm.c:271: void eeprom_driver_erase(void) {
                                   1615 ;	-----------------------------------------
                                   1616 ;	 function eeprom_driver_erase
                                   1617 ;	-----------------------------------------
      004536                       1618 _eeprom_driver_erase:
                                   1619 ;	keyboards/ajazz/ak820/ak820_nvm.c:274: ak820_nvm_flush();
      004536 12 40 9E         [24] 1620 	lcall	_ak820_nvm_flush
                                   1621 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      004539 7F 00            [12] 1622 	mov	r7,#0x00
      00453B                       1623 00111$:
      00453B BF A0 01         [24] 1624 	cjne	r7,#0xa0,00165$
      00453E 22               [24] 1625 	ret
      00453F                       1626 00165$:
      00453F 20 0A 32         [24] 1627 	jb	_storage_failed,00113$
                                   1628 ;	keyboards/ajazz/ak820/ak820_nvm.c:276: if (!load_page(page)) return;
      004542 8F 82            [24] 1629 	mov	dpl, r7
      004544 C0 07            [24] 1630 	push	ar7
      004546 12 42 1D         [24] 1631 	lcall	_load_page
      004549 E5 82            [12] 1632 	mov	a, dpl
      00454B D0 07            [24] 1633 	pop	ar7
      00454D 70 01            [24] 1634 	jnz	00126$
                                   1635 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      00454F 22               [24] 1636 	ret
      004550                       1637 00126$:
      004550 7E 00            [12] 1638 	mov	r6,#0x00
      004552                       1639 00107$:
                                   1640 ;	keyboards/ajazz/ak820/ak820_nvm.c:278: if (page_data[i]) { page_data[i] = 0; page_dirty = true; }
      004552 EE               [12] 1641 	mov	a,r6
      004553 24 29            [12] 1642 	add	a, #_page_data
      004555 FC               [12] 1643 	mov	r4,a
      004556 E4               [12] 1644 	clr	a
      004557 34 05            [12] 1645 	addc	a, #(_page_data >> 8)
      004559 FD               [12] 1646 	mov	r5,a
      00455A 12 45 B1         [24] 1647 	lcall	_ak820_outline_0092
      00455D 60 07            [24] 1648 	jz	00108$
      00455F 12 3A A0         [24] 1649 	lcall	_ak820_outline_0121
      004562 E4               [12] 1650 	clr	a
      004563 F0               [24] 1651 	movx	@dptr,a
                                   1652 ;	assignBit
      004564 D2 09            [12] 1653 	setb	_page_dirty
      004566                       1654 00108$:
                                   1655 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004566 0E               [12] 1656 	inc	r6
      004567 BE 40 E8         [24] 1657 	cjne	r6,#0x40,00107$
                                   1658 ;	keyboards/ajazz/ak820/ak820_nvm.c:280: ak820_nvm_flush();
      00456A C0 07            [24] 1659 	push	ar7
      00456C 12 40 9E         [24] 1660 	lcall	_ak820_nvm_flush
      00456F D0 07            [24] 1661 	pop	ar7
                                   1662 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      004571 0F               [12] 1663 	inc	r7
      004572 80 C7            [24] 1664 	sjmp	00111$
      004574                       1665 00113$:
                                   1666 ;	keyboards/ajazz/ak820/ak820_nvm.c:282: }
      004574 22               [24] 1667 	ret
                                   1668 	.area CSEG    (CODE)
                                   1669 	.area CONST   (CODE)
                                   1670 	.area XINIT   (CODE)
                                   1671 	.area CABS    (ABS,CODE)
                                   1672 
                                   1673 ; Experimental exact instruction outlining.
                                   1674 	.globl _ak820_outline_0004
                                   1675 	.globl _ak820_outline_0010
                                   1676 	.globl _ak820_outline_0016
                                   1677 	.globl _ak820_outline_0017
                                   1678 	.globl _ak820_outline_0030
                                   1679 	.globl _ak820_outline_0037
                                   1680 	.globl _ak820_outline_0041
                                   1681 	.globl _ak820_outline_0051
                                   1682 	.globl _ak820_outline_0052
                                   1683 	.globl _ak820_outline_0060
                                   1684 	.globl _ak820_outline_0061
                                   1685 	.globl _ak820_outline_0071
                                   1686 	.globl _ak820_outline_0076
                                   1687 	.globl _ak820_outline_0092
                                   1688 	.globl _ak820_outline_0097
                                   1689 	.globl _ak820_outline_0100
                                   1690 	.globl _ak820_outline_0101
                                   1691 	.globl _ak820_outline_0103
                                   1692 	.globl _ak820_outline_0104
                                   1693 	.globl _ak820_outline_0116
                                   1694 	.globl _ak820_outline_0119
                                   1695 	.globl _ak820_outline_0120
                                   1696 	.globl _ak820_outline_0121
                                   1697 	.globl _ak820_outline_0122
                                   1698 	.globl _ak820_outline_0131
                                   1699 	.globl _ak820_outline_0132
                                   1700 	.globl _ak820_outline_0134
                                   1701 	.globl _ak820_outline_0141
                                   1702 	.globl _ak820_outline_0142
                                   1703 	.globl _ak820_outline_0148
                                   1704 	.globl _ak820_outline_0156
                                   1705 	.globl _ak820_outline_0158
                                   1706 	.globl _ak820_outline_0159
                                   1707 	.globl _ak820_outline_0166
                                   1708 	.globl _ak820_outline_0179
                                   1709 	.globl _ak820_outline_0180
                                   1710 	.globl _ak820_outline_0185
                                   1711 
                                   1712 	.area CSEG (CODE)
                                   1713 ; function ak820_outline_0010
      004575                       1714 _ak820_outline_0010:
      004575 8E 82            [24] 1715 	mov	dpl,r6
      004577 8F 83            [24] 1716 	mov	dph,r7
      004579 A3               [24] 1717 	inc	dptr
      00457A A3               [24] 1718 	inc	dptr
      00457B A3               [24] 1719 	inc	dptr
      00457C A3               [24] 1720 	inc	dptr
      00457D A3               [24] 1721 	inc	dptr
      00457E 22               [24] 1722 	ret
                                   1723 
                                   1724 	.area CSEG (CODE)
                                   1725 ; function ak820_outline_0030
      00457F                       1726 _ak820_outline_0030:
      00457F F0               [24] 1727 	movx	@dptr,a
      004580 8E 82            [24] 1728 	mov	dpl,r6
      004582 8F 83            [24] 1729 	mov	dph,r7
      004584 A3               [24] 1730 	inc	dptr
      004585 A3               [24] 1731 	inc	dptr
      004586 22               [24] 1732 	ret
                                   1733 
                                   1734 	.area CSEG (CODE)
                                   1735 ; function ak820_outline_0037
      004587                       1736 _ak820_outline_0037:
      004587 AF F0            [24] 1737 	mov	r7,b
      004589 AE 83            [24] 1738 	mov	r6,dph
      00458B E5 82            [12] 1739 	mov	a,dpl
      00458D 22               [24] 1740 	ret
                                   1741 
                                   1742 	.area CSEG (CODE)
                                   1743 ; function ak820_outline_0041
      00458E                       1744 _ak820_outline_0041:
      00458E EF               [12] 1745 	mov	a,r7
      00458F 24 81            [12] 1746 	add	a,#_ak820_nvm_flush_header_10000_62
      004591 F5 82            [12] 1747 	mov	dpl,a
      004593 E4               [12] 1748 	clr	a
      004594 34 05            [12] 1749 	addc	a,#(_ak820_nvm_flush_header_10000_62>>8)
      004596 F5 83            [12] 1750 	mov	dph,a
      004598 E0               [24] 1751 	movx	a,@dptr
      004599 22               [24] 1752 	ret
                                   1753 
                                   1754 	.area CSEG (CODE)
                                   1755 ; function ak820_outline_0052
      00459A                       1756 _ak820_outline_0052:
      00459A 8F 06            [24] 1757 	mov	ar6,r7
      00459C 7D 00            [12] 1758 	mov	r5,#0x00
      00459E 74 40            [12] 1759 	mov	a,#0x40
      0045A0 2E               [12] 1760 	add	a,r6
      0045A1 FE               [12] 1761 	mov	r6,a
      0045A2 74 EF            [12] 1762 	mov	a,#0xef
      0045A4 3D               [12] 1763 	addc	a,r5
      0045A5 FD               [12] 1764 	mov	r5,a
      0045A6 8E 82            [24] 1765 	mov	dpl,r6
      0045A8 8D 83            [24] 1766 	mov	dph,r5
      0045AA 22               [24] 1767 	ret
                                   1768 
                                   1769 	.area CSEG (CODE)
                                   1770 ; function ak820_outline_0061
      0045AB                       1771 _ak820_outline_0061:
      0045AB F0               [24] 1772 	movx	@dptr,a
      0045AC 8E 82            [24] 1773 	mov	dpl,r6
      0045AE 8F 83            [24] 1774 	mov	dph,r7
      0045B0 22               [24] 1775 	ret
                                   1776 
                                   1777 	.area CSEG (CODE)
                                   1778 ; function ak820_outline_0092
      0045B1                       1779 _ak820_outline_0092:
      0045B1 8C 82            [24] 1780 	mov	dpl,r4
      0045B3 8D 83            [24] 1781 	mov	dph,r5
      0045B5 E0               [24] 1782 	movx	a,@dptr
      0045B6 22               [24] 1783 	ret
                                   1784 
                                   1785 	.area CSEG (CODE)
                                   1786 ; function ak820_outline_0097
      0045B7                       1787 _ak820_outline_0097:
      0045B7 E0               [24] 1788 	movx	a,@dptr
      0045B8 FD               [12] 1789 	mov	r5,a
      0045B9 A3               [24] 1790 	inc	dptr
      0045BA E0               [24] 1791 	movx	a,@dptr
      0045BB FE               [12] 1792 	mov	r6,a
      0045BC 22               [24] 1793 	ret
                                   1794 
                                   1795 	.area CSEG (CODE)
                                   1796 ; function ak820_outline_0101
      0045BD                       1797 _ak820_outline_0101:
      0045BD EF               [12] 1798 	mov	a,r7
      0045BE 24 29            [12] 1799 	add	a,#_page_data
      0045C0 F5 82            [12] 1800 	mov	dpl,a
      0045C2 E4               [12] 1801 	clr	a
      0045C3 34 05            [12] 1802 	addc	a,#(_page_data>>8)
      0045C5 F5 83            [12] 1803 	mov	dph,a
      0045C7 E0               [24] 1804 	movx	a,@dptr
      0045C8 22               [24] 1805 	ret
                                   1806 
                                   1807 	.area CSEG (CODE)
                                   1808 ; function ak820_outline_0116
      0045C9                       1809 _ak820_outline_0116:
      0045C9 8E 82            [24] 1810 	mov	dpl,r6
      0045CB 8F 83            [24] 1811 	mov	dph,r7
      0045CD 22               [24] 1812 	ret
                                   1813 
                                   1814 	.area CSEG (CODE)
                                   1815 ; function ak820_outline_0119
      0045CE                       1816 _ak820_outline_0119:
      0045CE E0               [24] 1817 	movx	a,@dptr
      0045CF FA               [12] 1818 	mov	r2,a
      0045D0 A3               [24] 1819 	inc	dptr
      0045D1 E0               [24] 1820 	movx	a,@dptr
      0045D2 FB               [12] 1821 	mov	r3,a
      0045D3 22               [24] 1822 	ret
                                   1823 
                                   1824 	.area CSEG (CODE)
                                   1825 ; function ak820_outline_0132
      0045D4                       1826 _ak820_outline_0132:
      0045D4 AE 82            [24] 1827 	mov	r6,dpl
      0045D6 AF 83            [24] 1828 	mov	r7,dph
      0045D8 22               [24] 1829 	ret
                                   1830 
                                   1831 	.area CSEG (CODE)
                                   1832 ; function ak820_outline_0134
      0045D9                       1833 _ak820_outline_0134:
      0045D9 2E               [12] 1834 	add	a,r6
      0045DA FE               [12] 1835 	mov	r6,a
      0045DB E4               [12] 1836 	clr	a
      0045DC 3F               [12] 1837 	addc	a,r7
      0045DD FF               [12] 1838 	mov	r7,a
      0045DE 22               [24] 1839 	ret
                                   1840 
                                   1841 	.area CSEG (CODE)
                                   1842 ; function ak820_outline_0141
      0045DF                       1843 _ak820_outline_0141:
      0045DF 42 05            [12] 1844 	orl	ar5,a
      0045E1 EA               [12] 1845 	mov	a,r2
      0045E2 42 04            [12] 1846 	orl	ar4,a
      0045E4 22               [24] 1847 	ret
                                   1848 
                                   1849 	.area CSEG (CODE)
                                   1850 ; function ak820_outline_0142
      0045E5                       1851 _ak820_outline_0142:
      0045E5 8A 82            [24] 1852 	mov	dpl,r2
      0045E7 8B 83            [24] 1853 	mov	dph,r3
      0045E9 22               [24] 1854 	ret
                                   1855 
                                   1856 	.area CSEG (CODE)
                                   1857 ; function ak820_outline_0148
      0045EA                       1858 _ak820_outline_0148:
      0045EA AC 82            [24] 1859 	mov	r4,dpl
      0045EC AD 83            [24] 1860 	mov	r5,dph
      0045EE 22               [24] 1861 	ret
                                   1862 
                                   1863 	.area CSEG (CODE)
                                   1864 ; function ak820_outline_0156
      0045EF                       1865 _ak820_outline_0156:
      0045EF 8F 82            [24] 1866 	mov	dpl,r7
      0045F1 8E 83            [24] 1867 	mov	dph,r6
      0045F3 22               [24] 1868 	ret
                                   1869 
                                   1870 	.area CSEG (CODE)
                                   1871 ; function ak820_outline_0158
      0045F4                       1872 _ak820_outline_0158:
      0045F4 2E               [12] 1873 	add	a,r6
      0045F5 FC               [12] 1874 	mov	r4,a
      0045F6 E4               [12] 1875 	clr	a
      0045F7 3F               [12] 1876 	addc	a,r7
      0045F8 FD               [12] 1877 	mov	r5,a
      0045F9 22               [24] 1878 	ret
                                   1879 
                                   1880 	.area CSEG (CODE)
                                   1881 ; function ak820_outline_0159
      0045FA                       1882 _ak820_outline_0159:
      0045FA ED               [12] 1883 	mov	a,r5
      0045FB F0               [24] 1884 	movx	@dptr,a
      0045FC EE               [12] 1885 	mov	a,r6
      0045FD A3               [24] 1886 	inc	dptr
      0045FE F0               [24] 1887 	movx	@dptr,a
      0045FF 22               [24] 1888 	ret
                                   1889 
                                   1890 	.area CSEG (CODE)
                                   1891 ; function ak820_outline_0179
      004600                       1892 _ak820_outline_0179:
      004600 89 82            [24] 1893 	mov	dpl,r1
      004602 8A 83            [24] 1894 	mov	dph,r2
      004604 22               [24] 1895 	ret
                                   1896 
                                   1897 	.area CSEG (CODE)
                                   1898 ; function ak820_outline_0180
      004605                       1899 _ak820_outline_0180:
      004605 8C 82            [24] 1900 	mov	dpl,r4
      004607 8B 83            [24] 1901 	mov	dph,r3
      004609 22               [24] 1902 	ret
                                   1903 
                                   1904 	.area CSEG (CODE)
                                   1905 ; function ak820_outline_0185
      00460A                       1906 _ak820_outline_0185:
      00460A 8D 82            [24] 1907 	mov	dpl,r5
      00460C 8C 83            [24] 1908 	mov	dph,r4
      00460E 22               [24] 1909 	ret
