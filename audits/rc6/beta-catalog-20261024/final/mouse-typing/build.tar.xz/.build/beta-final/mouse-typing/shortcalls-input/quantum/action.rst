                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _register_mouse
                                     12 	.globl _ak820_combo_cancel
                                     13 	.globl _ak820_combo_tick
                                     14 	.globl _ak820_autoshift_cancel
                                     15 	.globl _ak820_autoshift_process
                                     16 	.globl _ak820_autoshift_before
                                     17 	.globl _ak820_oneshot_cancel
                                     18 	.globl _ak820_oneshot_post
                                     19 	.globl _ak820_oneshot_process
                                     20 	.globl _ak820_tapping_source
                                     21 	.globl _ak820_tapping_cancel
                                     22 	.globl _ak820_tapping_process
                                     23 	.globl _ak820_tapping_before
                                     24 	.globl _pre_process_record_quantum
                                     25 	.globl _get_record_keycode
                                     26 	.globl _repeat_key_cancel
                                     27 	.globl _clear_owned_usages
                                     28 	.globl _owned_usage_key
                                     29 	.globl _clear_owned_keys
                                     30 	.globl _del_owned_key
                                     31 	.globl _add_owned_key
                                     32 	.globl _clear_owned_mods
                                     33 	.globl _del_owned_weak_mods
                                     34 	.globl _add_owned_weak_mods
                                     35 	.globl _del_owned_mods
                                     36 	.globl _add_owned_mods
                                     37 	.globl _clear_weak_mods
                                     38 	.globl _clear_mods
                                     39 	.globl _send_keyboard_report
                                     40 	.globl _layer_hold_clear
                                     41 	.globl _layer_hold_off
                                     42 	.globl _layer_hold_on
                                     43 	.globl _ak820_resolve_key
                                     44 	.globl _layer_xor
                                     45 	.globl _layer_and
                                     46 	.globl _layer_or
                                     47 	.globl _layer_off
                                     48 	.globl _layer_on
                                     49 	.globl _layer_move
                                     50 	.globl _layer_clear
                                     51 	.globl _layer_state_set
                                     52 	.globl _default_layer_xor
                                     53 	.globl _default_layer_and
                                     54 	.globl _default_layer_or
                                     55 	.globl _default_layer_set
                                     56 	.globl _process_record_quantum
                                     57 	.globl _action_for_keycode
                                     58 	.globl _mousekey_send
                                     59 	.globl _mousekey_clear
                                     60 	.globl _mousekey_off
                                     61 	.globl _mousekey_on
                                     62 	.globl _mDelaymS
                                     63 	.globl _host_consumer_send
                                     64 	.globl _host_system_send
                                     65 	.globl _host_keyboard_leds
                                     66 	.globl _led_set
                                     67 	.globl _clear_keys_from_report
                                     68 	.globl ___memcpy
                                     69 	.globl _ADC_START
                                     70 	.globl _S0_R_FIFO
                                     71 	.globl _S0_T_FIFO
                                     72 	.globl _S0_FREE
                                     73 	.globl _S0_IF_BYTE
                                     74 	.globl _S0_IF_FIRST
                                     75 	.globl _S0_IF_OV
                                     76 	.globl _S0_FST_ACT
                                     77 	.globl _CP_RL2
                                     78 	.globl _C_T2
                                     79 	.globl _TR2
                                     80 	.globl _EXEN2
                                     81 	.globl _TCLK
                                     82 	.globl _RCLK
                                     83 	.globl _EXF2
                                     84 	.globl _CAP1F
                                     85 	.globl _TF2
                                     86 	.globl _RI
                                     87 	.globl _TI
                                     88 	.globl _RB8
                                     89 	.globl _TB8
                                     90 	.globl _REN
                                     91 	.globl _SM2
                                     92 	.globl _SM1
                                     93 	.globl _SM0
                                     94 	.globl _IT0
                                     95 	.globl _IE0
                                     96 	.globl _IT1
                                     97 	.globl _IE1
                                     98 	.globl _TR0
                                     99 	.globl _TF0
                                    100 	.globl _TR1
                                    101 	.globl _TF1
                                    102 	.globl _P4_0
                                    103 	.globl _P4_1
                                    104 	.globl _P4_2
                                    105 	.globl _P4_3
                                    106 	.globl _P4_4
                                    107 	.globl _P4_5
                                    108 	.globl _P4_6
                                    109 	.globl _RXD
                                    110 	.globl _TXD
                                    111 	.globl _INT0
                                    112 	.globl _INT1
                                    113 	.globl _T0
                                    114 	.globl _T1
                                    115 	.globl _MOSI1
                                    116 	.globl _MISO1
                                    117 	.globl _SCK1
                                    118 	.globl _P3_0
                                    119 	.globl _P3_1
                                    120 	.globl _P3_2
                                    121 	.globl _P3_3
                                    122 	.globl _P3_4
                                    123 	.globl _P3_5
                                    124 	.globl _P3_6
                                    125 	.globl _P3_7
                                    126 	.globl _CAP1_
                                    127 	.globl _T2_
                                    128 	.globl _CAP2_
                                    129 	.globl _T2EX_
                                    130 	.globl _RXD1
                                    131 	.globl _TXD1
                                    132 	.globl _P2_0
                                    133 	.globl _P2_1
                                    134 	.globl _P2_2
                                    135 	.globl _P2_3
                                    136 	.globl _P2_4
                                    137 	.globl _P2_5
                                    138 	.globl _P2_6
                                    139 	.globl _P2_7
                                    140 	.globl _AIN0
                                    141 	.globl _AIN1
                                    142 	.globl _AIN2
                                    143 	.globl _AIN3
                                    144 	.globl _AIN4
                                    145 	.globl _AIN5
                                    146 	.globl _AIN6
                                    147 	.globl _AIN7
                                    148 	.globl _CAP1
                                    149 	.globl _T2
                                    150 	.globl _CAP2
                                    151 	.globl _T2EX
                                    152 	.globl _INT0_
                                    153 	.globl _SCS
                                    154 	.globl _MOSI
                                    155 	.globl _MISO
                                    156 	.globl _SCK
                                    157 	.globl _RXD1_
                                    158 	.globl _TXD1_
                                    159 	.globl _P1_0
                                    160 	.globl _P1_1
                                    161 	.globl _P1_2
                                    162 	.globl _P1_3
                                    163 	.globl _P1_4
                                    164 	.globl _P1_5
                                    165 	.globl _P1_6
                                    166 	.globl _P1_7
                                    167 	.globl _AIN8
                                    168 	.globl _AIN9
                                    169 	.globl _AIN10
                                    170 	.globl _AIN11
                                    171 	.globl _AIN12
                                    172 	.globl _AIN13
                                    173 	.globl _RXD_
                                    174 	.globl _TXD_
                                    175 	.globl _SCL0
                                    176 	.globl _SDA0
                                    177 	.globl _P0_0
                                    178 	.globl _P0_1
                                    179 	.globl _P0_2
                                    180 	.globl _P0_3
                                    181 	.globl _P0_4
                                    182 	.globl _P0_5
                                    183 	.globl _P0_6
                                    184 	.globl _P0_7
                                    185 	.globl _IE_SPI0
                                    186 	.globl _IE_USB
                                    187 	.globl _IE_ADC
                                    188 	.globl _IE_UART1
                                    189 	.globl _IE_PWM_I2C
                                    190 	.globl _IE_GPIO
                                    191 	.globl _IE_WDOG
                                    192 	.globl _PX0
                                    193 	.globl _PT0
                                    194 	.globl _PX1
                                    195 	.globl _PT1
                                    196 	.globl _PS
                                    197 	.globl _PT2
                                    198 	.globl _PL_FLAG
                                    199 	.globl _PH_FLAG
                                    200 	.globl _EX0
                                    201 	.globl _ET0
                                    202 	.globl _EX1
                                    203 	.globl _ET1
                                    204 	.globl _ES
                                    205 	.globl _ET2
                                    206 	.globl _E_DIS
                                    207 	.globl _EA
                                    208 	.globl _P
                                    209 	.globl _F1
                                    210 	.globl _OV
                                    211 	.globl _RS0
                                    212 	.globl _RS1
                                    213 	.globl _F0
                                    214 	.globl _AC
                                    215 	.globl _CY
                                    216 	.globl _I2CS_INT_ST
                                    217 	.globl _I2CX_INT
                                    218 	.globl _LED_STATUS
                                    219 	.globl _LED_DMA_H
                                    220 	.globl _LED_DMA_L
                                    221 	.globl _LED_DMA
                                    222 	.globl _LED_PWM_OE
                                    223 	.globl _LED_COMMON
                                    224 	.globl _ADC_CHAN
                                    225 	.globl _ADC_DAT_H
                                    226 	.globl _ADC_DAT_L
                                    227 	.globl _ADC_DAT
                                    228 	.globl _ADC_CTRL
                                    229 	.globl _SPI1_CK_SE
                                    230 	.globl _SPI1_CTRL
                                    231 	.globl _SPI1_DATA
                                    232 	.globl _SPI1_STAT
                                    233 	.globl _SIF1
                                    234 	.globl _SBAUD1
                                    235 	.globl _SBUF1
                                    236 	.globl _SCON1
                                    237 	.globl _SPI0_SETUP
                                    238 	.globl _SPI0_CK_SE
                                    239 	.globl _SPI0_CTRL
                                    240 	.globl _SPI0_DATA
                                    241 	.globl _SPI0_STAT
                                    242 	.globl _T2CAP1H
                                    243 	.globl _T2CAP1L
                                    244 	.globl _T2CAP1
                                    245 	.globl _TH2
                                    246 	.globl _TL2
                                    247 	.globl _T2COUNT
                                    248 	.globl _RCAP2H
                                    249 	.globl _RCAP2L
                                    250 	.globl _RCAP2
                                    251 	.globl _T2MOD
                                    252 	.globl _T2CON
                                    253 	.globl _SBUF
                                    254 	.globl _SCON
                                    255 	.globl _TH1
                                    256 	.globl _TH0
                                    257 	.globl _TL1
                                    258 	.globl _TL0
                                    259 	.globl _TMOD
                                    260 	.globl _TCON
                                    261 	.globl _XBUS_AUX
                                    262 	.globl _P7
                                    263 	.globl _P6_DIR
                                    264 	.globl _P6_OUT_PU
                                    265 	.globl _P6_IN
                                    266 	.globl _P5_DIR
                                    267 	.globl _P5_OUT_PU
                                    268 	.globl _P5_IN
                                    269 	.globl _P4_LED_KEY
                                    270 	.globl _P4_DIR_PU
                                    271 	.globl _P4_MOD_OC
                                    272 	.globl _P4
                                    273 	.globl _P3_DIR_PU
                                    274 	.globl _P3_MOD_OC
                                    275 	.globl _P3
                                    276 	.globl _P2_DIR_PU
                                    277 	.globl _P2_MOD_OC
                                    278 	.globl _P2
                                    279 	.globl _P1_DIR_PU
                                    280 	.globl _P1_MOD_OC
                                    281 	.globl _P1
                                    282 	.globl _P0_DIR_PU
                                    283 	.globl _P0_MOD_OC
                                    284 	.globl _P0
                                    285 	.globl _ROM_CTRL
                                    286 	.globl _ROM_DATA_HH
                                    287 	.globl _ROM_DATA_HL
                                    288 	.globl _ROM_DATA_HI
                                    289 	.globl _ROM_ADDR_H
                                    290 	.globl _ROM_ADDR_L
                                    291 	.globl _ROM_ADDR
                                    292 	.globl _GPIO_IE
                                    293 	.globl _IP_EX
                                    294 	.globl _IE_EX
                                    295 	.globl _IP
                                    296 	.globl _IE
                                    297 	.globl _WDOG_COUNT
                                    298 	.globl _RESET_KEEP
                                    299 	.globl _WAKE_CTRL
                                    300 	.globl _CLOCK_CFG
                                    301 	.globl _POWER_CFG
                                    302 	.globl _PCON
                                    303 	.globl _GLOBAL_CFG
                                    304 	.globl _SAFE_MOD
                                    305 	.globl _DPH
                                    306 	.globl _DPL
                                    307 	.globl _SP
                                    308 	.globl _A_INV
                                    309 	.globl _B
                                    310 	.globl _ACC
                                    311 	.globl _PSW
                                    312 	.globl _disable_action_cache
                                    313 	.globl _tap_code_delay_PARM_2
                                    314 	.globl _process_action_PARM_2
                                    315 	.globl _register_mouse_PARM_2
                                    316 	.globl _action_exec_PARM_1
                                    317 	.globl _tp_buttons
                                    318 	.globl _action_exec
                                    319 	.globl _ak820_action_exec
                                    320 	.globl _process_record
                                    321 	.globl _process_record_handler
                                    322 	.globl _process_action
                                    323 	.globl _register_code
                                    324 	.globl _unregister_code
                                    325 	.globl _tap_code_delay
                                    326 	.globl _tap_code
                                    327 	.globl _register_mods
                                    328 	.globl _unregister_mods
                                    329 	.globl _register_weak_mods
                                    330 	.globl _unregister_weak_mods
                                    331 	.globl _clear_keyboard
                                    332 	.globl _clear_keyboard_but_mods
                                    333 	.globl _clear_keyboard_but_mods_and_keys
                                    334 ;--------------------------------------------------------
                                    335 ; special function registers
                                    336 ;--------------------------------------------------------
                                    337 	.area RSEG    (ABS,DATA)
      000000                        338 	.org 0x0000
                           0000D0   339 _PSW	=	0x00d0
                           0000E0   340 _ACC	=	0x00e0
                           0000F0   341 _B	=	0x00f0
                           0000FD   342 _A_INV	=	0x00fd
                           000081   343 _SP	=	0x0081
                           000082   344 _DPL	=	0x0082
                           000083   345 _DPH	=	0x0083
                           0000A1   346 _SAFE_MOD	=	0x00a1
                           0000B1   347 _GLOBAL_CFG	=	0x00b1
                           000087   348 _PCON	=	0x0087
                           0000BA   349 _POWER_CFG	=	0x00ba
                           0000B9   350 _CLOCK_CFG	=	0x00b9
                           0000A9   351 _WAKE_CTRL	=	0x00a9
                           0000FE   352 _RESET_KEEP	=	0x00fe
                           0000FF   353 _WDOG_COUNT	=	0x00ff
                           0000A8   354 _IE	=	0x00a8
                           0000B8   355 _IP	=	0x00b8
                           0000E8   356 _IE_EX	=	0x00e8
                           0000E9   357 _IP_EX	=	0x00e9
                           0000B2   358 _GPIO_IE	=	0x00b2
                           008584   359 _ROM_ADDR	=	0x8584
                           000084   360 _ROM_ADDR_L	=	0x0084
                           000085   361 _ROM_ADDR_H	=	0x0085
                           008F8E   362 _ROM_DATA_HI	=	0x8f8e
                           00008E   363 _ROM_DATA_HL	=	0x008e
                           00008F   364 _ROM_DATA_HH	=	0x008f
                           000086   365 _ROM_CTRL	=	0x0086
                           000080   366 _P0	=	0x0080
                           0000C4   367 _P0_MOD_OC	=	0x00c4
                           0000C5   368 _P0_DIR_PU	=	0x00c5
                           000090   369 _P1	=	0x0090
                           000092   370 _P1_MOD_OC	=	0x0092
                           000093   371 _P1_DIR_PU	=	0x0093
                           0000A0   372 _P2	=	0x00a0
                           000094   373 _P2_MOD_OC	=	0x0094
                           000095   374 _P2_DIR_PU	=	0x0095
                           0000B0   375 _P3	=	0x00b0
                           000096   376 _P3_MOD_OC	=	0x0096
                           000097   377 _P3_DIR_PU	=	0x0097
                           0000C0   378 _P4	=	0x00c0
                           0000C2   379 _P4_MOD_OC	=	0x00c2
                           0000C3   380 _P4_DIR_PU	=	0x00c3
                           0000C1   381 _P4_LED_KEY	=	0x00c1
                           0000AA   382 _P5_IN	=	0x00aa
                           0000AB   383 _P5_OUT_PU	=	0x00ab
                           0000AC   384 _P5_DIR	=	0x00ac
                           0000AD   385 _P6_IN	=	0x00ad
                           0000AE   386 _P6_OUT_PU	=	0x00ae
                           0000AF   387 _P6_DIR	=	0x00af
                           0000F1   388 _P7	=	0x00f1
                           0000A2   389 _XBUS_AUX	=	0x00a2
                           000088   390 _TCON	=	0x0088
                           000089   391 _TMOD	=	0x0089
                           00008A   392 _TL0	=	0x008a
                           00008B   393 _TL1	=	0x008b
                           00008C   394 _TH0	=	0x008c
                           00008D   395 _TH1	=	0x008d
                           000098   396 _SCON	=	0x0098
                           000099   397 _SBUF	=	0x0099
                           0000C8   398 _T2CON	=	0x00c8
                           0000C9   399 _T2MOD	=	0x00c9
                           00CBCA   400 _RCAP2	=	0xcbca
                           0000CA   401 _RCAP2L	=	0x00ca
                           0000CB   402 _RCAP2H	=	0x00cb
                           00CDCC   403 _T2COUNT	=	0xcdcc
                           0000CC   404 _TL2	=	0x00cc
                           0000CD   405 _TH2	=	0x00cd
                           00CFCE   406 _T2CAP1	=	0xcfce
                           0000CE   407 _T2CAP1L	=	0x00ce
                           0000CF   408 _T2CAP1H	=	0x00cf
                           0000F8   409 _SPI0_STAT	=	0x00f8
                           0000F9   410 _SPI0_DATA	=	0x00f9
                           0000FA   411 _SPI0_CTRL	=	0x00fa
                           0000FB   412 _SPI0_CK_SE	=	0x00fb
                           0000FC   413 _SPI0_SETUP	=	0x00fc
                           0000BC   414 _SCON1	=	0x00bc
                           0000BD   415 _SBUF1	=	0x00bd
                           0000BE   416 _SBAUD1	=	0x00be
                           0000BF   417 _SIF1	=	0x00bf
                           0000B4   418 _SPI1_STAT	=	0x00b4
                           0000B5   419 _SPI1_DATA	=	0x00b5
                           0000B6   420 _SPI1_CTRL	=	0x00b6
                           0000B7   421 _SPI1_CK_SE	=	0x00b7
                           0000F3   422 _ADC_CTRL	=	0x00f3
                           00F5F4   423 _ADC_DAT	=	0xf5f4
                           0000F4   424 _ADC_DAT_L	=	0x00f4
                           0000F5   425 _ADC_DAT_H	=	0x00f5
                           0000F6   426 _ADC_CHAN	=	0x00f6
                           0000A6   427 _LED_COMMON	=	0x00a6
                           0000A7   428 _LED_PWM_OE	=	0x00a7
                           00C7C6   429 _LED_DMA	=	0xc7c6
                           0000C6   430 _LED_DMA_L	=	0x00c6
                           0000C7   431 _LED_DMA_H	=	0x00c7
                           0000F7   432 _LED_STATUS	=	0x00f7
                           0000B3   433 _I2CX_INT	=	0x00b3
                           0000BB   434 _I2CS_INT_ST	=	0x00bb
                                    435 ;--------------------------------------------------------
                                    436 ; special function bits
                                    437 ;--------------------------------------------------------
                                    438 	.area RSEG    (ABS,DATA)
      000000                        439 	.org 0x0000
                           0000D7   440 _CY	=	0x00d7
                           0000D6   441 _AC	=	0x00d6
                           0000D5   442 _F0	=	0x00d5
                           0000D4   443 _RS1	=	0x00d4
                           0000D3   444 _RS0	=	0x00d3
                           0000D2   445 _OV	=	0x00d2
                           0000D1   446 _F1	=	0x00d1
                           0000D0   447 _P	=	0x00d0
                           0000AF   448 _EA	=	0x00af
                           0000AE   449 _E_DIS	=	0x00ae
                           0000AD   450 _ET2	=	0x00ad
                           0000AC   451 _ES	=	0x00ac
                           0000AB   452 _ET1	=	0x00ab
                           0000AA   453 _EX1	=	0x00aa
                           0000A9   454 _ET0	=	0x00a9
                           0000A8   455 _EX0	=	0x00a8
                           0000BF   456 _PH_FLAG	=	0x00bf
                           0000BE   457 _PL_FLAG	=	0x00be
                           0000BD   458 _PT2	=	0x00bd
                           0000BC   459 _PS	=	0x00bc
                           0000BB   460 _PT1	=	0x00bb
                           0000BA   461 _PX1	=	0x00ba
                           0000B9   462 _PT0	=	0x00b9
                           0000B8   463 _PX0	=	0x00b8
                           0000EF   464 _IE_WDOG	=	0x00ef
                           0000EE   465 _IE_GPIO	=	0x00ee
                           0000ED   466 _IE_PWM_I2C	=	0x00ed
                           0000EC   467 _IE_UART1	=	0x00ec
                           0000EB   468 _IE_ADC	=	0x00eb
                           0000E9   469 _IE_USB	=	0x00e9
                           0000E8   470 _IE_SPI0	=	0x00e8
                           000087   471 _P0_7	=	0x0087
                           000086   472 _P0_6	=	0x0086
                           000085   473 _P0_5	=	0x0085
                           000084   474 _P0_4	=	0x0084
                           000083   475 _P0_3	=	0x0083
                           000082   476 _P0_2	=	0x0082
                           000081   477 _P0_1	=	0x0081
                           000080   478 _P0_0	=	0x0080
                           000081   479 _SDA0	=	0x0081
                           000080   480 _SCL0	=	0x0080
                           000083   481 _TXD_	=	0x0083
                           000082   482 _RXD_	=	0x0082
                           000085   483 _AIN13	=	0x0085
                           000084   484 _AIN12	=	0x0084
                           000083   485 _AIN11	=	0x0083
                           000082   486 _AIN10	=	0x0082
                           000081   487 _AIN9	=	0x0081
                           000080   488 _AIN8	=	0x0080
                           000097   489 _P1_7	=	0x0097
                           000096   490 _P1_6	=	0x0096
                           000095   491 _P1_5	=	0x0095
                           000094   492 _P1_4	=	0x0094
                           000093   493 _P1_3	=	0x0093
                           000092   494 _P1_2	=	0x0092
                           000091   495 _P1_1	=	0x0091
                           000090   496 _P1_0	=	0x0090
                           000097   497 _TXD1_	=	0x0097
                           000096   498 _RXD1_	=	0x0096
                           000097   499 _SCK	=	0x0097
                           000096   500 _MISO	=	0x0096
                           000095   501 _MOSI	=	0x0095
                           000094   502 _SCS	=	0x0094
                           000092   503 _INT0_	=	0x0092
                           000091   504 _T2EX	=	0x0091
                           000091   505 _CAP2	=	0x0091
                           000090   506 _T2	=	0x0090
                           000090   507 _CAP1	=	0x0090
                           000097   508 _AIN7	=	0x0097
                           000096   509 _AIN6	=	0x0096
                           000095   510 _AIN5	=	0x0095
                           000094   511 _AIN4	=	0x0094
                           000093   512 _AIN3	=	0x0093
                           000092   513 _AIN2	=	0x0092
                           000091   514 _AIN1	=	0x0091
                           000090   515 _AIN0	=	0x0090
                           0000A7   516 _P2_7	=	0x00a7
                           0000A6   517 _P2_6	=	0x00a6
                           0000A5   518 _P2_5	=	0x00a5
                           0000A4   519 _P2_4	=	0x00a4
                           0000A3   520 _P2_3	=	0x00a3
                           0000A2   521 _P2_2	=	0x00a2
                           0000A1   522 _P2_1	=	0x00a1
                           0000A0   523 _P2_0	=	0x00a0
                           0000A7   524 _TXD1	=	0x00a7
                           0000A6   525 _RXD1	=	0x00a6
                           0000A5   526 _T2EX_	=	0x00a5
                           0000A5   527 _CAP2_	=	0x00a5
                           0000A4   528 _T2_	=	0x00a4
                           0000A4   529 _CAP1_	=	0x00a4
                           0000B7   530 _P3_7	=	0x00b7
                           0000B6   531 _P3_6	=	0x00b6
                           0000B5   532 _P3_5	=	0x00b5
                           0000B4   533 _P3_4	=	0x00b4
                           0000B3   534 _P3_3	=	0x00b3
                           0000B2   535 _P3_2	=	0x00b2
                           0000B1   536 _P3_1	=	0x00b1
                           0000B0   537 _P3_0	=	0x00b0
                           0000B7   538 _SCK1	=	0x00b7
                           0000B6   539 _MISO1	=	0x00b6
                           0000B5   540 _MOSI1	=	0x00b5
                           0000B5   541 _T1	=	0x00b5
                           0000B4   542 _T0	=	0x00b4
                           0000B3   543 _INT1	=	0x00b3
                           0000B2   544 _INT0	=	0x00b2
                           0000B1   545 _TXD	=	0x00b1
                           0000B0   546 _RXD	=	0x00b0
                           0000C6   547 _P4_6	=	0x00c6
                           0000C5   548 _P4_5	=	0x00c5
                           0000C4   549 _P4_4	=	0x00c4
                           0000C3   550 _P4_3	=	0x00c3
                           0000C2   551 _P4_2	=	0x00c2
                           0000C1   552 _P4_1	=	0x00c1
                           0000C0   553 _P4_0	=	0x00c0
                           00008F   554 _TF1	=	0x008f
                           00008E   555 _TR1	=	0x008e
                           00008D   556 _TF0	=	0x008d
                           00008C   557 _TR0	=	0x008c
                           00008B   558 _IE1	=	0x008b
                           00008A   559 _IT1	=	0x008a
                           000089   560 _IE0	=	0x0089
                           000088   561 _IT0	=	0x0088
                           00009F   562 _SM0	=	0x009f
                           00009E   563 _SM1	=	0x009e
                           00009D   564 _SM2	=	0x009d
                           00009C   565 _REN	=	0x009c
                           00009B   566 _TB8	=	0x009b
                           00009A   567 _RB8	=	0x009a
                           000099   568 _TI	=	0x0099
                           000098   569 _RI	=	0x0098
                           0000CF   570 _TF2	=	0x00cf
                           0000CF   571 _CAP1F	=	0x00cf
                           0000CE   572 _EXF2	=	0x00ce
                           0000CD   573 _RCLK	=	0x00cd
                           0000CC   574 _TCLK	=	0x00cc
                           0000CB   575 _EXEN2	=	0x00cb
                           0000CA   576 _TR2	=	0x00ca
                           0000C9   577 _C_T2	=	0x00c9
                           0000C8   578 _CP_RL2	=	0x00c8
                           0000FF   579 _S0_FST_ACT	=	0x00ff
                           0000FE   580 _S0_IF_OV	=	0x00fe
                           0000FD   581 _S0_IF_FIRST	=	0x00fd
                           0000FC   582 _S0_IF_BYTE	=	0x00fc
                           0000FB   583 _S0_FREE	=	0x00fb
                           0000FA   584 _S0_T_FIFO	=	0x00fa
                           0000F8   585 _S0_R_FIFO	=	0x00f8
                           0000F7   586 _ADC_START	=	0x00f7
                                    587 ;--------------------------------------------------------
                                    588 ; overlayable register banks
                                    589 ;--------------------------------------------------------
                                    590 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        591 	.ds 8
                                    592 ;--------------------------------------------------------
                                    593 ; internal ram data
                                    594 ;--------------------------------------------------------
                                    595 	.area DSEG    (DATA)
      000027                        596 _process_action_sloc0_1_0:
      000027                        597 	.ds 1
                                    598 ;--------------------------------------------------------
                                    599 ; overlayable items in internal ram
                                    600 ;--------------------------------------------------------
                                    601 ;--------------------------------------------------------
                                    602 ; indirectly addressable internal ram data
                                    603 ;--------------------------------------------------------
                                    604 	.area ISEG    (DATA)
                                    605 ;--------------------------------------------------------
                                    606 ; absolute internal ram data
                                    607 ;--------------------------------------------------------
                                    608 	.area IABS    (ABS,DATA)
                                    609 	.area IABS    (ABS,DATA)
                                    610 ;--------------------------------------------------------
                                    611 ; bit data
                                    612 ;--------------------------------------------------------
                                    613 	.area BSEG    (BIT)
      00001E                        614 _process_action_sloc1_1_0:
      00001E                        615 	.ds 1
                                    616 ;--------------------------------------------------------
                                    617 ; paged external ram data
                                    618 ;--------------------------------------------------------
                                    619 	.area PSEG    (PAG,XDATA)
                                    620 ;--------------------------------------------------------
                                    621 ; uninitialized external ram data
                                    622 ;--------------------------------------------------------
                                    623 	.area XSEG    (XDATA)
      00083F                        624 _tp_buttons::
      00083F                        625 	.ds 2
      000841                        626 _action_exec_PARM_1:
      000841                        627 	.ds 6
      000847                        628 _action_exec_record_10001_630:
      000847                        629 	.ds 9
      000850                        630 _ak820_action_exec_event_10000_635:
      000850                        631 	.ds 2
      000852                        632 _ak820_action_exec_snapshot_10000_636:
      000852                        633 	.ds 6
      000858                        634 _process_record_record_argument_10000_639:
      000858                        635 	.ds 2
      00085A                        636 _process_record_handler_record_argument_10000_647:
      00085A                        637 	.ds 2
      00085C                        638 _process_record_handler_action_10000_648:
      00085C                        639 	.ds 2
      00085E                        640 _register_mouse_PARM_2:
      00085E                        641 	.ds 1
      00085F                        642 _register_mouse_mouse_keycode_10000_656:
      00085F                        643 	.ds 1
      000860                        644 _process_action_PARM_2:
      000860                        645 	.ds 2
      000862                        646 _process_action_record_argument_10000_663:
      000862                        647 	.ds 2
      000864                        648 _process_action_on_40000_686:
      000864                        649 	.ds 1
      000865                        650 _register_code_code_10000_720:
      000865                        651 	.ds 1
      000866                        652 _unregister_code_code_10000_734:
      000866                        653 	.ds 1
      000867                        654 _tap_code_delay_PARM_2:
      000867                        655 	.ds 2
      000869                        656 _tap_code_delay_code_10000_747:
      000869                        657 	.ds 1
      00086A                        658 _tap_code_code_10000_754:
      00086A                        659 	.ds 1
      00086B                        660 _register_mods_mods_10000_756:
      00086B                        661 	.ds 1
      00086C                        662 _unregister_mods_mods_10000_760:
      00086C                        663 	.ds 1
      00086D                        664 _register_weak_mods_mods_10000_764:
      00086D                        665 	.ds 1
      00086E                        666 _unregister_weak_mods_mods_10000_768:
      00086E                        667 	.ds 1
                                    668 ;--------------------------------------------------------
                                    669 ; absolute external ram data
                                    670 ;--------------------------------------------------------
                                    671 	.area XABS    (ABS,XDATA)
                                    672 ;--------------------------------------------------------
                                    673 ; initialized external ram data
                                    674 ;--------------------------------------------------------
                                    675 	.area XISEG   (XDATA)
      000DCB                        676 _disable_action_cache::
      000DCB                        677 	.ds 1
                                    678 	.area HOME    (CODE)
                                    679 	.area GSINIT0 (CODE)
                                    680 	.area GSINIT1 (CODE)
                                    681 	.area GSINIT2 (CODE)
                                    682 	.area GSINIT3 (CODE)
                                    683 	.area GSINIT4 (CODE)
                                    684 	.area GSINIT5 (CODE)
                                    685 	.area GSINIT  (CODE)
                                    686 	.area GSFINAL (CODE)
                                    687 	.area CSEG    (CODE)
                                    688 ;--------------------------------------------------------
                                    689 ; global & static initialisations
                                    690 ;--------------------------------------------------------
                                    691 	.area HOME    (CODE)
                                    692 	.area GSINIT  (CODE)
                                    693 	.area GSFINAL (CODE)
                                    694 	.area GSINIT  (CODE)
                                    695 ;--------------------------------------------------------
                                    696 ; Home
                                    697 ;--------------------------------------------------------
                                    698 	.area HOME    (CODE)
                                    699 	.area HOME    (CODE)
                                    700 ;--------------------------------------------------------
                                    701 ; code
                                    702 ;--------------------------------------------------------
                                    703 	.area CSEG    (CODE)
                                    704 ;------------------------------------------------------------
                                    705 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    706 ;------------------------------------------------------------
                                    707 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    708 ;------------------------------------------------------------
                                    709 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    710 ;	-----------------------------------------
                           000007   711 	ar7 = 0x07
                           000006   712 	ar6 = 0x06
                           000005   713 	ar5 = 0x05
                           000004   714 	ar4 = 0x04
                           000003   715 	ar3 = 0x03
                           000002   716 	ar2 = 0x02
                           000001   717 	ar1 = 0x01
                           000000   718 	ar0 = 0x00
                                    719 ;	 function action_exec
                                    720 ;	-----------------------------------------
      007698                        721 _action_exec:
                                    722 ;	quantum/action.c:101: ak820_combo_tick(event.time);
      007698 90 08 43         [24]  723 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      00769B 12 39 E6         [24]  724 	lcall	_ak820_outline_0004
      00769E 12 37 FE         [24]  725 	lcall	_ak820_combo_tick
                                    726 ;	quantum/action.c:104: if (!ak820_tapping_before(&event)) return;
      0076A1 90 08 41         [24]  727 	mov	dptr,#_action_exec_PARM_1
      0076A4 12 47 99         [24]  728 	lcall	_ak820_tapping_before
      0076A7 E5 82            [12]  729 	mov	a, dpl
      0076A9 70 01            [24]  730 	jnz	00102$
      0076AB 22               [24]  731 	ret
      0076AC                        732 00102$:
                                    733 ;	quantum/action.c:110: if (!ak820_autoshift_before(&event)) return;
      0076AC 90 08 41         [24]  734 	mov	dptr,#_action_exec_PARM_1
      0076AF 12 31 2A         [24]  735 	lcall	_ak820_autoshift_before
      0076B2 E5 82            [12]  736 	mov	a, dpl
      0076B4 70 01            [24]  737 	jnz	00104$
      0076B6 22               [24]  738 	ret
      0076B7                        739 00104$:
                                    740 ;	quantum/action.c:126: if (event.pressed) {
      0076B7 90 08 46         [24]  741 	mov	dptr,#(_action_exec_PARM_1 + 0x0005)
      0076BA E0               [24]  742 	movx	a,@dptr
      0076BB 60 03            [24]  743 	jz	00106$
                                    744 ;	quantum/action.c:128: clear_weak_mods();
      0076BD 12 87 7D         [24]  745 	lcall	_clear_weak_mods
      0076C0                        746 00106$:
                                    747 ;	quantum/action.c:140: record.event = event;
      0076C0 90 0D AA         [24]  748 	mov	dptr,#___memcpy_PARM_2
      0076C3 74 41            [12]  749 	mov	a,#_action_exec_PARM_1
      0076C5 F0               [24]  750 	movx	@dptr,a
      0076C6 74 08            [12]  751 	mov	a,#(_action_exec_PARM_1 >> 8)
      0076C8 12 7D 95         [24]  752 	lcall	_ak820_outline_0050
      0076CB 12 7D B5         [24]  753 	lcall	_ak820_outline_0107
      0076CE 90 08 47         [24]  754 	mov	dptr,#_action_exec_record_10001_630
      0076D1 F5 F0            [12]  755 	mov	b,a
      0076D3 12 BD DB         [24]  756 	lcall	___memcpy
                                    757 ;	quantum/action.c:142: record.tap.count = 0;
      0076D6 90 08 4D         [24]  758 	mov	dptr,#(_action_exec_record_10001_630 + 0x0006)
      0076D9 E0               [24]  759 	movx	a,@dptr
      0076DA 54 0F            [12]  760 	anl	a,#0x0f
      0076DC F0               [24]  761 	movx	@dptr,a
                                    762 ;	quantum/action.c:147: record.keycode = 0;
      0076DD 90 08 4E         [24]  763 	mov	dptr,#(_action_exec_record_10001_630 + 0x0007)
      0076E0 12 52 9A         [24]  764 	lcall	_ak820_outline_0178
                                    765 ;	quantum/action.c:178: if (IS_NOEVENT(record.event) || pre_process_record_quantum(&record)) {
      0076E3 90 08 4B         [24]  766 	mov	dptr,#(_action_exec_record_10001_630 + 0x0004)
      0076E6 E0               [24]  767 	movx	a,@dptr
      0076E7 60 0A            [24]  768 	jz	00111$
      0076E9 90 08 47         [24]  769 	mov	dptr,#_action_exec_record_10001_630
      0076EC 12 A4 E2         [24]  770 	lcall	_pre_process_record_quantum
      0076EF E5 82            [12]  771 	mov	a, dpl
      0076F1 60 1C            [24]  772 	jz	00114$
      0076F3                        773 00111$:
                                    774 ;	quantum/action.c:180: if (!ak820_tapping_process(&record)) return;
      0076F3 90 08 47         [24]  775 	mov	dptr,#_action_exec_record_10001_630
      0076F6 12 48 7D         [24]  776 	lcall	_ak820_tapping_process
      0076F9 E5 82            [12]  777 	mov	a, dpl
      0076FB 70 01            [24]  778 	jnz	00108$
      0076FD 22               [24]  779 	ret
      0076FE                        780 00108$:
                                    781 ;	quantum/action.c:182: if (!ak820_autoshift_process(&record)) return;
      0076FE 90 08 47         [24]  782 	mov	dptr,#_action_exec_record_10001_630
      007701 12 32 30         [24]  783 	lcall	_ak820_autoshift_process
      007704 E5 82            [12]  784 	mov	a, dpl
      007706 70 01            [24]  785 	jnz	00110$
      007708 22               [24]  786 	ret
      007709                        787 00110$:
                                    788 ;	quantum/action.c:185: process_record(&record);
      007709 90 08 47         [24]  789 	mov	dptr,#_action_exec_record_10001_630
                                    790 ;	quantum/action.c:200: }
      00770C 02 77 4D         [24]  791 	ljmp	_process_record
      00770F                        792 00114$:
      00770F 22               [24]  793 	ret
                                    794 ;------------------------------------------------------------
                                    795 ;Allocation info for local variables in function 'ak820_action_exec'
                                    796 ;------------------------------------------------------------
                                    797 ;event         Allocated with name '_ak820_action_exec_event_10000_635'
                                    798 ;snapshot      Allocated with name '_ak820_action_exec_snapshot_10000_636'
                                    799 ;------------------------------------------------------------
                                    800 ;	quantum/action.c:203: void ak820_action_exec(const keyevent_t __xdata *event) {
                                    801 ;	-----------------------------------------
                                    802 ;	 function ak820_action_exec
                                    803 ;	-----------------------------------------
      007710                        804 _ak820_action_exec:
      007710 12 3A 89         [24]  805 	lcall	_ak820_outline_0103
      007713 90 08 50         [24]  806 	mov	dptr,#_ak820_action_exec_event_10000_635
      007716 12 3A 8E         [24]  807 	lcall	_ak820_outline_0104
                                    808 ;	quantum/action.c:206: keyevent_t snapshot = *event;
      007719 90 08 50         [24]  809 	mov	dptr,#_ak820_action_exec_event_10000_635
      00771C 12 3A 5D         [24]  810 	lcall	_ak820_outline_0058
      00771F 90 0D AA         [24]  811 	mov	dptr,#___memcpy_PARM_2
      007722 ED               [12]  812 	mov	a,r5
      007723 12 3A 25         [24]  813 	lcall	_ak820_outline_0016
      007726 90 0D AD         [24]  814 	mov	dptr,#___memcpy_PARM_3
      007729 12 7D B5         [24]  815 	lcall	_ak820_outline_0107
      00772C 90 08 52         [24]  816 	mov	dptr,#_ak820_action_exec_snapshot_10000_636
      00772F F5 F0            [12]  817 	mov	b,a
      007731 12 BD DB         [24]  818 	lcall	___memcpy
                                    819 ;	quantum/action.c:207: action_exec(snapshot);
      007734 90 0D AA         [24]  820 	mov	dptr,#___memcpy_PARM_2
      007737 74 52            [12]  821 	mov	a,#_ak820_action_exec_snapshot_10000_636
      007739 F0               [24]  822 	movx	@dptr,a
      00773A 74 08            [12]  823 	mov	a,#(_ak820_action_exec_snapshot_10000_636 >> 8)
      00773C 12 7D 95         [24]  824 	lcall	_ak820_outline_0050
      00773F 12 7D B5         [24]  825 	lcall	_ak820_outline_0107
      007742 90 08 41         [24]  826 	mov	dptr,#_action_exec_PARM_1
      007745 F5 F0            [12]  827 	mov	b,a
      007747 12 BD DB         [24]  828 	lcall	___memcpy
                                    829 ;	quantum/action.c:208: }
      00774A 02 76 98         [24]  830 	ljmp	_action_exec
                                    831 ;------------------------------------------------------------
                                    832 ;Allocation info for local variables in function 'process_record_nocache'
                                    833 ;------------------------------------------------------------
                                    834 ;record        Allocated with name '_process_record_nocache_record_10000_637'
                                    835 ;------------------------------------------------------------
                                    836 ;	quantum/action.c:293: void process_record_nocache(keyrecord_t AK820_RECORD_MEM *record) {
                                    837 ;	-----------------------------------------
                                    838 ;	 function process_record
                                    839 ;	-----------------------------------------
      00774D                        840 _process_record:
      00774D 12 3A 89         [24]  841 	lcall	_ak820_outline_0103
      007750 90 08 58         [24]  842 	mov	dptr,#_process_record_record_argument_10000_639
      007753 12 3A 8E         [24]  843 	lcall	_ak820_outline_0104
                                    844 ;	quantum/action.c:349: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      007756 90 08 58         [24]  845 	mov	dptr,#_process_record_record_argument_10000_639
      007759 12 3A 46         [24]  846 	lcall	_ak820_outline_0051
                                    847 ;	quantum/action.c:353: if (IS_NOEVENT(record->event)) {
      00775C 74 04            [12]  848 	mov	a,#0x04
      00775E 12 4B 71         [24]  849 	lcall	_ak820_outline_0012
      007761 70 01            [24]  850 	jnz	00102$
                                    851 ;	quantum/action.c:354: return;
      007763 22               [24]  852 	ret
      007764                        853 00102$:
                                    854 ;	quantum/action.c:362: uint8_t oneshot_source = ak820_tapping_source(record->event.key);
      007764 8E 04            [24]  855 	mov	ar4,r6
      007766 8F 05            [24]  856 	mov	ar5,r7
      007768 90 0D AA         [24]  857 	mov	dptr,#___memcpy_PARM_2
      00776B EC               [12]  858 	mov	a,r4
      00776C F0               [24]  859 	movx	@dptr,a
      00776D ED               [12]  860 	mov	a,r5
      00776E 12 7D 95         [24]  861 	lcall	_ak820_outline_0050
      007771 12 52 8C         [24]  862 	lcall	_ak820_outline_0106
      007774 90 06 38         [24]  863 	mov	dptr,#_ak820_tapping_source_PARM_1
      007777 F5 F0            [12]  864 	mov	b,a
      007779 C0 07            [24]  865 	push	ar7
      00777B C0 06            [24]  866 	push	ar6
      00777D 12 BD DB         [24]  867 	lcall	___memcpy
      007780 12 46 D5         [24]  868 	lcall	_ak820_tapping_source
      007783 AD 82            [24]  869 	mov	r5, dpl
      007785 D0 06            [24]  870 	pop	ar6
      007787 D0 07            [24]  871 	pop	ar7
                                    872 ;	quantum/action.c:363: bool oneshot_pressed = record->event.pressed;
      007789 12 45 7B         [24]  873 	lcall	_ak820_outline_0010
      00778C E0               [24]  874 	movx	a,@dptr
      00778D FC               [12]  875 	mov	r4,a
                                    876 ;	quantum/action.c:364: record->keycode = get_record_keycode(record, true);
      00778E 74 07            [12]  877 	mov	a,#0x07
      007790 2E               [12]  878 	add	a, r6
      007791 FA               [12]  879 	mov	r2,a
      007792 E4               [12]  880 	clr	a
      007793 3F               [12]  881 	addc	a, r7
      007794 FB               [12]  882 	mov	r3,a
      007795 90 0C 0C         [24]  883 	mov	dptr,#_get_record_keycode_PARM_2
      007798 12 4B BA         [24]  884 	lcall	_ak820_outline_0055
      00779B C0 07            [24]  885 	push	ar7
      00779D C0 06            [24]  886 	push	ar6
      00779F C0 05            [24]  887 	push	ar5
      0077A1 C0 04            [24]  888 	push	ar4
      0077A3 C0 03            [24]  889 	push	ar3
      0077A5 C0 02            [24]  890 	push	ar2
      0077A7 12 A4 A5         [24]  891 	lcall	_get_record_keycode
      0077AA A8 82            [24]  892 	mov	r0, dpl
      0077AC A9 83            [24]  893 	mov	r1, dph
      0077AE D0 02            [24]  894 	pop	ar2
      0077B0 D0 03            [24]  895 	pop	ar3
      0077B2 D0 04            [24]  896 	pop	ar4
      0077B4 D0 05            [24]  897 	pop	ar5
      0077B6 D0 06            [24]  898 	pop	ar6
      0077B8 D0 07            [24]  899 	pop	ar7
      0077BA 12 45 EB         [24]  900 	lcall	_ak820_outline_0142
      0077BD E8               [12]  901 	mov	a,r0
      0077BE F0               [24]  902 	movx	@dptr,a
      0077BF E9               [12]  903 	mov	a,r1
      0077C0 A3               [24]  904 	inc	dptr
      0077C1 F0               [24]  905 	movx	@dptr,a
                                    906 ;	quantum/action.c:365: if (!ak820_oneshot_process(record->keycode, oneshot_source, oneshot_pressed)) return;
      0077C2 74 07            [12]  907 	mov	a,#0x07
      0077C4 12 3A 2D         [24]  908 	lcall	_ak820_outline_0017
      0077C7 FA               [12]  909 	mov	r2,a
      0077C8 A3               [24]  910 	inc	dptr
      0077C9 E0               [24]  911 	movx	a,@dptr
      0077CA FB               [12]  912 	mov	r3,a
      0077CB 90 06 48         [24]  913 	mov	dptr,#_ak820_oneshot_process_PARM_2
      0077CE ED               [12]  914 	mov	a,r5
      0077CF F0               [24]  915 	movx	@dptr,a
      0077D0 90 06 49         [24]  916 	mov	dptr,#_ak820_oneshot_process_PARM_3
      0077D3 EC               [12]  917 	mov	a,r4
      0077D4 F0               [24]  918 	movx	@dptr,a
      0077D5 12 45 EB         [24]  919 	lcall	_ak820_outline_0142
      0077D8 C0 07            [24]  920 	push	ar7
      0077DA C0 06            [24]  921 	push	ar6
      0077DC C0 05            [24]  922 	push	ar5
      0077DE C0 04            [24]  923 	push	ar4
      0077E0 12 4A 24         [24]  924 	lcall	_ak820_oneshot_process
      0077E3 E5 82            [12]  925 	mov	a, dpl
      0077E5 D0 04            [24]  926 	pop	ar4
      0077E7 D0 05            [24]  927 	pop	ar5
      0077E9 D0 06            [24]  928 	pop	ar6
      0077EB D0 07            [24]  929 	pop	ar7
      0077ED 70 01            [24]  930 	jnz	00104$
      0077EF 22               [24]  931 	ret
      0077F0                        932 00104$:
                                    933 ;	quantum/action.c:367: if (!process_record_quantum(record)) {
      0077F0 12 45 CF         [24]  934 	lcall	_ak820_outline_0116
      0077F3 C0 07            [24]  935 	push	ar7
      0077F5 C0 06            [24]  936 	push	ar6
      0077F7 C0 05            [24]  937 	push	ar5
      0077F9 C0 04            [24]  938 	push	ar4
      0077FB 12 A5 24         [24]  939 	lcall	_process_record_quantum
      0077FE E5 82            [12]  940 	mov	a, dpl
      007800 D0 04            [24]  941 	pop	ar4
      007802 D0 05            [24]  942 	pop	ar5
      007804 D0 06            [24]  943 	pop	ar6
      007806 D0 07            [24]  944 	pop	ar7
      007808 70 0A            [24]  945 	jnz	00106$
                                    946 ;	quantum/action.c:369: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      00780A 90 05 A8         [24]  947 	mov	dptr,#_ak820_oneshot_post_PARM_2
      00780D EC               [12]  948 	mov	a,r4
      00780E F0               [24]  949 	movx	@dptr,a
      00780F 8D 82            [24]  950 	mov	dpl, r5
                                    951 ;	quantum/action.c:376: return;
      007811 02 2E 6F         [24]  952 	ljmp	_ak820_oneshot_post
      007814                        953 00106$:
                                    954 ;	quantum/action.c:382: process_record_handler(record);
      007814 12 45 CF         [24]  955 	lcall	_ak820_outline_0116
      007817 C0 05            [24]  956 	push	ar5
      007819 C0 04            [24]  957 	push	ar4
      00781B 12 78 2C         [24]  958 	lcall	_process_record_handler
      00781E D0 04            [24]  959 	pop	ar4
      007820 D0 05            [24]  960 	pop	ar5
                                    961 ;	quantum/action.c:390: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      007822 90 05 A8         [24]  962 	mov	dptr,#_ak820_oneshot_post_PARM_2
      007825 EC               [12]  963 	mov	a,r4
      007826 F0               [24]  964 	movx	@dptr,a
      007827 8D 82            [24]  965 	mov	dpl, r5
                                    966 ;	quantum/action.c:392: }
      007829 02 2E 6F         [24]  967 	ljmp	_ak820_oneshot_post
                                    968 ;------------------------------------------------------------
                                    969 ;Allocation info for local variables in function 'process_record_handler'
                                    970 ;------------------------------------------------------------
                                    971 ;record_argument Allocated with name '_process_record_handler_record_argument_10000_647'
                                    972 ;record        Allocated with name '_process_record_handler_record_10000_648'
                                    973 ;action        Allocated with name '_process_record_handler_action_10000_648'
                                    974 ;------------------------------------------------------------
                                    975 ;	quantum/action.c:394: void process_record_handler(keyrecord_t AK820_RECORD_MEM *record_argument) {
                                    976 ;	-----------------------------------------
                                    977 ;	 function process_record_handler
                                    978 ;	-----------------------------------------
      00782C                        979 _process_record_handler:
      00782C 12 3A 89         [24]  980 	lcall	_ak820_outline_0103
      00782F 90 08 5A         [24]  981 	mov	dptr,#_process_record_handler_record_argument_10000_647
      007832 12 3A 8E         [24]  982 	lcall	_ak820_outline_0104
                                    983 ;	quantum/action.c:398: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      007835 90 08 5A         [24]  984 	mov	dptr,#_process_record_handler_record_argument_10000_647
      007838 12 39 FD         [24]  985 	lcall	_ak820_outline_0009
                                    986 ;	quantum/action.c:405: if (record->keycode) {
      00783B 4C               [12]  987 	orl	a,r4
      00783C 60 19            [24]  988 	jz	00102$
                                    989 ;	quantum/action.c:406: action.code = action_for_keycode(record->keycode);
      00783E 12 3A A6         [24]  990 	lcall	_ak820_outline_0121
      007841 C0 07            [24]  991 	push	ar7
      007843 C0 06            [24]  992 	push	ar6
      007845 12 9B 76         [24]  993 	lcall	_action_for_keycode
      007848 12 45 F0         [24]  994 	lcall	_ak820_outline_0148
      00784B D0 06            [24]  995 	pop	ar6
      00784D D0 07            [24]  996 	pop	ar7
      00784F 90 08 5C         [24]  997 	mov	dptr,#_process_record_handler_action_10000_648
      007852 12 3A 6B         [24]  998 	lcall	_ak820_outline_0071
      007855 80 2A            [24]  999 	sjmp	00104$
      007857                       1000 00102$:
                                   1001 ;	quantum/action.c:409: action.code = action_for_keycode(ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed));
      007857 12 7D 7D         [24] 1002 	lcall	_ak820_outline_0019
      00785A 7A 00            [12] 1003 	mov	r2,#0x00
      00785C 12 45 E5         [24] 1004 	lcall	_ak820_outline_0141
      00785F 12 45 7B         [24] 1005 	lcall	_ak820_outline_0010
      007862 E0               [24] 1006 	movx	a,@dptr
      007863 90 09 99         [24] 1007 	mov	dptr,#_ak820_resolve_key_PARM_2
      007866 F0               [24] 1008 	movx	@dptr,a
      007867 12 46 10         [24] 1009 	lcall	_ak820_outline_0185
      00786A C0 07            [24] 1010 	push	ar7
      00786C C0 06            [24] 1011 	push	ar6
      00786E 12 81 1F         [24] 1012 	lcall	_ak820_resolve_key
      007871 12 9B 76         [24] 1013 	lcall	_action_for_keycode
      007874 12 45 F0         [24] 1014 	lcall	_ak820_outline_0148
      007877 D0 06            [24] 1015 	pop	ar6
      007879 D0 07            [24] 1016 	pop	ar7
      00787B 90 08 5C         [24] 1017 	mov	dptr,#_process_record_handler_action_10000_648
      00787E 12 3A 6B         [24] 1018 	lcall	_ak820_outline_0071
                                   1019 ;	quantum/action.c:418: ac_dprintf("ACTION: ");
      007881                       1020 00104$:
                                   1021 ;	quantum/action.c:429: process_action(record, action);
      007881 90 0D AA         [24] 1022 	mov	dptr,#___memcpy_PARM_2
      007884 74 5C            [12] 1023 	mov	a,#_process_record_handler_action_10000_648
      007886 F0               [24] 1024 	movx	@dptr,a
      007887 74 08            [12] 1025 	mov	a,#(_process_record_handler_action_10000_648 >> 8)
      007889 12 7D 95         [24] 1026 	lcall	_ak820_outline_0050
      00788C 12 52 8C         [24] 1027 	lcall	_ak820_outline_0106
      00788F 90 08 60         [24] 1028 	mov	dptr,#_process_action_PARM_2
      007892 F5 F0            [12] 1029 	mov	b,a
      007894 C0 07            [24] 1030 	push	ar7
      007896 C0 06            [24] 1031 	push	ar6
      007898 12 BD DB         [24] 1032 	lcall	___memcpy
      00789B D0 06            [24] 1033 	pop	ar6
      00789D D0 07            [24] 1034 	pop	ar7
      00789F 12 45 CF         [24] 1035 	lcall	_ak820_outline_0116
                                   1036 ;	quantum/action.c:430: }
      0078A2 02 78 C8         [24] 1037 	ljmp	_process_action
                                   1038 ;------------------------------------------------------------
                                   1039 ;Allocation info for local variables in function 'register_mouse'
                                   1040 ;------------------------------------------------------------
                                   1041 ;pressed       Allocated with name '_register_mouse_PARM_2'
                                   1042 ;mouse_keycode Allocated with name '_register_mouse_mouse_keycode_10000_656'
                                   1043 ;------------------------------------------------------------
                                   1044 ;	quantum/action.c:442: void register_mouse(uint8_t mouse_keycode, bool pressed) {
                                   1045 ;	-----------------------------------------
                                   1046 ;	 function register_mouse
                                   1047 ;	-----------------------------------------
      0078A5                       1048 _register_mouse:
      0078A5 E5 82            [12] 1049 	mov	a,dpl
      0078A7 90 08 5F         [24] 1050 	mov	dptr,#_register_mouse_mouse_keycode_10000_656
      0078AA F0               [24] 1051 	movx	@dptr,a
                                   1052 ;	quantum/action.c:445: if (pressed) {
      0078AB 90 08 5E         [24] 1053 	mov	dptr,#_register_mouse_PARM_2
      0078AE E0               [24] 1054 	movx	a,@dptr
      0078AF 60 0B            [24] 1055 	jz	00102$
                                   1056 ;	quantum/action.c:446: mousekey_on(mouse_keycode);
      0078B1 90 08 5F         [24] 1057 	mov	dptr,#_register_mouse_mouse_keycode_10000_656
      0078B4 E0               [24] 1058 	movx	a,@dptr
      0078B5 F5 82            [12] 1059 	mov	dpl,a
      0078B7 12 52 EA         [24] 1060 	lcall	_mousekey_on
      0078BA 80 09            [24] 1061 	sjmp	00103$
      0078BC                       1062 00102$:
                                   1063 ;	quantum/action.c:448: mousekey_off(mouse_keycode);
      0078BC 90 08 5F         [24] 1064 	mov	dptr,#_register_mouse_mouse_keycode_10000_656
      0078BF E0               [24] 1065 	movx	a,@dptr
      0078C0 F5 82            [12] 1066 	mov	dpl,a
      0078C2 12 53 5E         [24] 1067 	lcall	_mousekey_off
      0078C5                       1068 00103$:
                                   1069 ;	quantum/action.c:469: mousekey_send();
                                   1070 ;	quantum/action.c:471: }
                                   1071 ;	quantum/action.c:487: }
      0078C5 02 53 BD         [24] 1072 	ljmp	_mousekey_send
                                   1073 ;------------------------------------------------------------
                                   1074 ;Allocation info for local variables in function 'process_action'
                                   1075 ;------------------------------------------------------------
                                   1076 ;sloc0         Allocated with name '_process_action_sloc0_1_0'
                                   1077 ;action        Allocated with name '_process_action_PARM_2'
                                   1078 ;record_argument Allocated with name '_process_action_record_argument_10000_663'
                                   1079 ;record        Allocated with name '_process_action_record_10000_664'
                                   1080 ;pressed       Allocated with name '_process_action_pressed_10000_664'
                                   1081 ;mods          Allocated with name '_process_action_mods_10000_664'
                                   1082 ;on            Allocated with name '_process_action_on_40000_686'
                                   1083 ;shift         Allocated with name '_process_action_shift_60000_688'
                                   1084 ;bits          Allocated with name '_process_action_bits_60000_688'
                                   1085 ;mask          Allocated with name '_process_action_mask_60000_688'
                                   1086 ;i             Allocated with name '_process_action_i_110000_712'
                                   1087 ;i             Allocated with name '_process_action_i_110000_716'
                                   1088 ;------------------------------------------------------------
                                   1089 ;	quantum/action.c:493: void process_action(keyrecord_t AK820_RECORD_MEM *record_argument, action_t action) {
                                   1090 ;	-----------------------------------------
                                   1091 ;	 function process_action
                                   1092 ;	-----------------------------------------
      0078C8                       1093 _process_action:
      0078C8 12 3A 89         [24] 1094 	lcall	_ak820_outline_0103
      0078CB 90 08 62         [24] 1095 	mov	dptr,#_process_action_record_argument_10000_663
      0078CE 12 3A 8E         [24] 1096 	lcall	_ak820_outline_0104
                                   1097 ;	quantum/action.c:495: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      0078D1 90 08 62         [24] 1098 	mov	dptr,#_process_action_record_argument_10000_663
      0078D4 12 39 E6         [24] 1099 	lcall	_ak820_outline_0004
                                   1100 ;	quantum/action.c:501: pressed = record->event.pressed;
      0078D7 A3               [24] 1101 	inc	dptr
      0078D8 A3               [24] 1102 	inc	dptr
      0078D9 A3               [24] 1103 	inc	dptr
      0078DA A3               [24] 1104 	inc	dptr
      0078DB A3               [24] 1105 	inc	dptr
      0078DC E0               [24] 1106 	movx	a,@dptr
      0078DD F5 27            [12] 1107 	mov	_process_action_sloc0_1_0,a
                                   1108 ;	quantum/action.c:525: switch (action.kind.id) {
      0078DF 90 08 61         [24] 1109 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0078E2 E0               [24] 1110 	movx	a,@dptr
      0078E3 C4               [12] 1111 	swap	a
      0078E4 54 0F            [12] 1112 	anl	a,#0x0f
      0078E6 FD               [12] 1113 	mov  r5,a
      0078E7 24 F4            [12] 1114 	add	a,#0xff - 0x0b
      0078E9 50 03            [24] 1115 	jnc	00434$
      0078EB 02 7B 7B         [24] 1116 	ljmp	00181$
      0078EE                       1117 00434$:
                                   1118 ;	free result
      0078EE ED               [12] 1119 	mov	a,r5
      0078EF 24 0A            [12] 1120 	add	a,#(00435$-3-.)
      0078F1 83               [24] 1121 	movc	a,@a+pc
      0078F2 F5 82            [12] 1122 	mov	dpl,a
      0078F4 ED               [12] 1123 	mov	a,r5
      0078F5 24 10            [12] 1124 	add	a,#(00436$-3-.)
      0078F7 83               [24] 1125 	movc	a,@a+pc
      0078F8 F5 83            [12] 1126 	mov	dph,a
      0078FA E4               [12] 1127 	clr	a
      0078FB 73               [24] 1128 	jmp	@a+dptr
      0078FC                       1129 00435$:
      0078FC 14                    1130 	.db	00102$
      0078FD 14                    1131 	.db	00102$
      0078FE 7B                    1132 	.db	00181$
      0078FF 7B                    1133 	.db	00181$
      007900 9E                    1134 	.db	00123$
      007901 FE                    1135 	.db	00130$
      007902 7B                    1136 	.db	00181$
      007903 7B                    1137 	.db	00181$
      007904 10                    1138 	.db	00131$
      007905 E2                    1139 	.db	00147$
      007906 08                    1140 	.db	00152$
      007907 08                    1141 	.db	00152$
      007908                       1142 00436$:
      007908 79                    1143 	.db	00102$>>8
      007909 79                    1144 	.db	00102$>>8
      00790A 7B                    1145 	.db	00181$>>8
      00790B 7B                    1146 	.db	00181$>>8
      00790C 79                    1147 	.db	00123$>>8
      00790D 79                    1148 	.db	00130$>>8
      00790E 7B                    1149 	.db	00181$>>8
      00790F 7B                    1150 	.db	00181$>>8
      007910 7A                    1151 	.db	00131$>>8
      007911 7A                    1152 	.db	00147$>>8
      007912 7B                    1153 	.db	00152$>>8
      007913 7B                    1154 	.db	00152$>>8
                                   1155 ;	quantum/action.c:528: case ACT_RMODS: {
      007914                       1156 00102$:
                                   1157 ;	quantum/action.c:529: mods = (action.kind.id == ACT_LMODS) ? action.key.mods : action.key.mods << 4;
      007914 90 08 61         [24] 1158 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007917 E0               [24] 1159 	movx	a,@dptr
      007918 54 F0            [12] 1160 	anl	a,#0xf0
      00791A 70 06            [24] 1161 	jnz	00194$
      00791C 12 7D BC         [24] 1162 	lcall	_ak820_outline_0109
      00791F FD               [12] 1163 	mov	r5,a
      007920 80 07            [24] 1164 	sjmp	00195$
      007922                       1165 00194$:
      007922 12 7D BC         [24] 1166 	lcall	_ak820_outline_0109
      007925 C4               [12] 1167 	swap	a
      007926 54 F0            [12] 1168 	anl	a,#0xf0
      007928 FD               [12] 1169 	mov	r5,a
      007929                       1170 00195$:
                                   1171 ;	quantum/action.c:531: if (pressed) {
      007929 E5 27            [12] 1172 	mov	a,_process_action_sloc0_1_0
      00792B 60 35            [24] 1173 	jz	00119$
                                   1174 ;	quantum/action.c:532: if (mods) {
      00792D ED               [12] 1175 	mov	a,r5
      00792E 60 29            [24] 1176 	jz	00110$
                                   1177 ;	quantum/action.c:533: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      007930 12 7D DA         [24] 1178 	lcall	_ak820_outline_0147
      007933 FC               [12] 1179 	mov	r4,a
      007934 BC E0 00         [24] 1180 	cjne	r4,#0xe0,00440$
      007937                       1181 00440$:
      007937 40 07            [24] 1182 	jc	00108$
      007939 12 7D DA         [24] 1183 	lcall	_ak820_outline_0147
      00793C 24 18            [12] 1184 	add	a,#0xff - 0xe7
      00793E 50 0A            [24] 1185 	jnc	00104$
                                   1186 ;	free result
      007940                       1187 00108$:
      007940 7B 60            [12] 1188 	mov	r3,#_process_action_PARM_2
      007942 7C 08            [12] 1189 	mov	r4,#(_process_action_PARM_2 >> 8)
      007944 12 36 42         [24] 1190 	lcall	_ak820_outline_0122
      007947 E0               [24] 1191 	movx	a,@dptr
      007948 70 07            [24] 1192 	jnz	00105$
      00794A                       1193 00104$:
                                   1194 ;	quantum/action.c:537: add_owned_mods(mods);
      00794A 8D 82            [24] 1195 	mov	dpl, r5
      00794C 12 83 89         [24] 1196 	lcall	_add_owned_mods
      00794F 80 05            [24] 1197 	sjmp	00106$
      007951                       1198 00105$:
                                   1199 ;	quantum/action.c:539: add_owned_weak_mods(mods);
      007951 8D 82            [24] 1200 	mov	dpl, r5
      007953 12 83 A7         [24] 1201 	lcall	_add_owned_weak_mods
      007956                       1202 00106$:
                                   1203 ;	quantum/action.c:541: send_keyboard_report();
      007956 12 86 C4         [24] 1204 	lcall	_send_keyboard_report
      007959                       1205 00110$:
                                   1206 ;	quantum/action.c:543: register_code(action.key.code);
      007959 12 7D A5         [24] 1207 	lcall	_ak820_outline_0075
      00795C 12 7B 92         [24] 1208 	lcall	_register_code
      00795F 02 7B 7B         [24] 1209 	ljmp	00181$
      007962                       1210 00119$:
                                   1211 ;	quantum/action.c:545: unregister_code(action.key.code);
      007962 12 7D A5         [24] 1212 	lcall	_ak820_outline_0075
      007965 C0 05            [24] 1213 	push	ar5
      007967 12 7C 17         [24] 1214 	lcall	_unregister_code
      00796A D0 05            [24] 1215 	pop	ar5
                                   1216 ;	quantum/action.c:546: if (mods) {
      00796C ED               [12] 1217 	mov	a,r5
      00796D 70 03            [24] 1218 	jnz	00444$
      00796F 02 7B 7B         [24] 1219 	ljmp	00181$
      007972                       1220 00444$:
                                   1221 ;	quantum/action.c:547: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      007972 12 7D DA         [24] 1222 	lcall	_ak820_outline_0147
      007975 FC               [12] 1223 	mov	r4,a
      007976 BC E0 00         [24] 1224 	cjne	r4,#0xe0,00445$
      007979                       1225 00445$:
      007979 40 07            [24] 1226 	jc	00115$
      00797B 12 7D DA         [24] 1227 	lcall	_ak820_outline_0147
      00797E 24 18            [12] 1228 	add	a,#0xff - 0xe7
      007980 50 0A            [24] 1229 	jnc	00111$
                                   1230 ;	free result
      007982                       1231 00115$:
      007982 7B 60            [12] 1232 	mov	r3,#_process_action_PARM_2
      007984 7C 08            [12] 1233 	mov	r4,#(_process_action_PARM_2 >> 8)
      007986 12 36 42         [24] 1234 	lcall	_ak820_outline_0122
      007989 E0               [24] 1235 	movx	a,@dptr
      00798A 70 07            [24] 1236 	jnz	00112$
      00798C                       1237 00111$:
                                   1238 ;	quantum/action.c:548: del_owned_mods(mods);
      00798C 8D 82            [24] 1239 	mov	dpl, r5
      00798E 12 83 99         [24] 1240 	lcall	_del_owned_mods
      007991 80 05            [24] 1241 	sjmp	00113$
      007993                       1242 00112$:
                                   1243 ;	quantum/action.c:550: del_owned_weak_mods(mods);
      007993 8D 82            [24] 1244 	mov	dpl, r5
      007995 12 83 B7         [24] 1245 	lcall	_del_owned_weak_mods
      007998                       1246 00113$:
                                   1247 ;	quantum/action.c:552: send_keyboard_report();
      007998 12 86 C4         [24] 1248 	lcall	_send_keyboard_report
                                   1249 ;	quantum/action.c:555: } break;
      00799B 02 7B 7B         [24] 1250 	ljmp	00181$
                                   1251 ;	quantum/action.c:632: case ACT_USAGE:
      00799E                       1252 00123$:
                                   1253 ;	quantum/action.c:638: if (record->keycode >= KC_SYSTEM_POWER && record->keycode <= KC_LAUNCHPAD) {
      00799E 74 07            [12] 1254 	mov	a,#0x07
      0079A0 12 3A 36         [24] 1255 	lcall	_ak820_outline_0031
      0079A3 12 3A 11         [24] 1256 	lcall	_ak820_outline_0011
      0079A6 C3               [12] 1257 	clr	c
      0079A7 EC               [12] 1258 	mov	a,r4
      0079A8 94 A5            [12] 1259 	subb	a,#0xa5
      0079AA ED               [12] 1260 	mov	a,r5
      0079AB 94 00            [12] 1261 	subb	a,#0x00
      0079AD 40 15            [24] 1262 	jc	00125$
      0079AF 74 C2            [12] 1263 	mov	a,#0xc2
      0079B1 9C               [12] 1264 	subb	a,r4
      0079B2 E4               [12] 1265 	clr	a
      0079B3 9D               [12] 1266 	subb	a,r5
      0079B4 40 0E            [24] 1267 	jc	00125$
                                   1268 ;	free result
                                   1269 ;	quantum/action.c:639: owned_usage_key((uint8_t)record->keycode, pressed);
      0079B6 90 0A C3         [24] 1270 	mov	dptr,#_owned_usage_key_PARM_2
      0079B9 E5 27            [12] 1271 	mov	a,_process_action_sloc0_1_0
      0079BB F0               [24] 1272 	movx	@dptr,a
      0079BC 8E 82            [24] 1273 	mov	dpl, r6
      0079BE 12 85 6F         [24] 1274 	lcall	_owned_usage_key
                                   1275 ;	quantum/action.c:640: break;
      0079C1 02 7B 7B         [24] 1276 	ljmp	00181$
      0079C4                       1277 00125$:
                                   1278 ;	quantum/action.c:643: switch (action.usage.page) {
      0079C4 12 7D AC         [24] 1279 	lcall	_ak820_outline_0085
      0079C7 FF               [12] 1280 	mov	r7,a
      0079C8 60 08            [24] 1281 	jz	00127$
      0079CA BF 01 02         [24] 1282 	cjne	r7,#0x01,00452$
      0079CD 80 19            [24] 1283 	sjmp	00128$
      0079CF                       1284 00452$:
      0079CF 02 7B 7B         [24] 1285 	ljmp	00181$
                                   1286 ;	quantum/action.c:644: case PAGE_SYSTEM:
      0079D2                       1287 00127$:
                                   1288 ;	quantum/action.c:645: host_system_send(pressed ? action.usage.code : 0);
      0079D2 E5 27            [12] 1289 	mov	a,_process_action_sloc0_1_0
      0079D4 60 05            [24] 1290 	jz	00196$
      0079D6 12 7D C3         [24] 1291 	lcall	_ak820_outline_0129
      0079D9 80 04            [24] 1292 	sjmp	00197$
      0079DB                       1293 00196$:
      0079DB 7E 00            [12] 1294 	mov	r6,#0x00
      0079DD 7F 00            [12] 1295 	mov	r7,#0x00
      0079DF                       1296 00197$:
      0079DF 12 45 CF         [24] 1297 	lcall	_ak820_outline_0116
      0079E2 12 73 91         [24] 1298 	lcall	_host_system_send
                                   1299 ;	quantum/action.c:646: break;
      0079E5 02 7B 7B         [24] 1300 	ljmp	00181$
                                   1301 ;	quantum/action.c:647: case PAGE_CONSUMER:
      0079E8                       1302 00128$:
                                   1303 ;	quantum/action.c:648: host_consumer_send(pressed ? action.usage.code : 0);
      0079E8 E5 27            [12] 1304 	mov	a,_process_action_sloc0_1_0
      0079EA 60 05            [24] 1305 	jz	00198$
      0079EC 12 7D C3         [24] 1306 	lcall	_ak820_outline_0129
      0079EF 80 04            [24] 1307 	sjmp	00199$
      0079F1                       1308 00198$:
      0079F1 7E 00            [12] 1309 	mov	r6,#0x00
      0079F3 7F 00            [12] 1310 	mov	r7,#0x00
      0079F5                       1311 00199$:
      0079F5 12 45 CF         [24] 1312 	lcall	_ak820_outline_0116
      0079F8 12 73 C1         [24] 1313 	lcall	_host_consumer_send
                                   1314 ;	quantum/action.c:651: break;
      0079FB 02 7B 7B         [24] 1315 	ljmp	00181$
                                   1316 ;	quantum/action.c:654: case ACT_MOUSEKEY:
      0079FE                       1317 00130$:
                                   1318 ;	quantum/action.c:655: register_mouse(action.key.code, pressed);
      0079FE 12 7D DA         [24] 1319 	lcall	_ak820_outline_0147
      007A01 FF               [12] 1320 	mov	r7,a
      007A02 90 08 5E         [24] 1321 	mov	dptr,#_register_mouse_PARM_2
      007A05 E5 27            [12] 1322 	mov	a,_process_action_sloc0_1_0
      007A07 F0               [24] 1323 	movx	@dptr,a
      007A08 8F 82            [24] 1324 	mov	dpl, r7
      007A0A 12 78 A5         [24] 1325 	lcall	_register_mouse
                                   1326 ;	quantum/action.c:656: break;
      007A0D 02 7B 7B         [24] 1327 	ljmp	00181$
                                   1328 ;	quantum/action.c:658: case ACT_LAYER: {
      007A10                       1329 00131$:
                                   1330 ;	quantum/action.c:659: uint8_t on = action.layer_bitop.on;
      007A10 90 08 61         [24] 1331 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007A13 E0               [24] 1332 	movx	a,@dptr
      007A14 54 03            [12] 1333 	anl	a,#0x03
      007A16 90 08 64         [24] 1334 	mov	dptr,#_process_action_on_40000_686
      007A19 F0               [24] 1335 	movx	@dptr,a
                                   1336 ;	quantum/action.c:662: if (on ? (pressed ? (on & ON_PRESS) : (on & ON_RELEASE)) : !pressed) {
      007A1A E0               [24] 1337 	movx	a,@dptr
      007A1B FF               [12] 1338 	mov	r7,a
      007A1C 60 11            [24] 1339 	jz	00200$
      007A1E E5 27            [12] 1340 	mov	a,_process_action_sloc0_1_0
      007A20 60 07            [24] 1341 	jz	00202$
      007A22 8F 06            [24] 1342 	mov	ar6,r7
      007A24 53 06 01         [24] 1343 	anl	ar6,#0x01
      007A27 80 10            [24] 1344 	sjmp	00201$
      007A29                       1345 00202$:
      007A29 74 02            [12] 1346 	mov	a,#0x02
      007A2B 5F               [12] 1347 	anl	a,r7
      007A2C FE               [12] 1348 	mov	r6,a
      007A2D 80 0A            [24] 1349 	sjmp	00201$
      007A2F                       1350 00200$:
      007A2F E5 27            [12] 1351 	mov	a,_process_action_sloc0_1_0
      007A31 B4 01 00         [24] 1352 	cjne	a,#0x01,00457$
      007A34                       1353 00457$:
      007A34 92 1E            [24] 1354 	mov  _process_action_sloc1_1_0,c
      007A36 E4               [12] 1355 	clr	a
      007A37 33               [12] 1356 	rlc	a
      007A38 FE               [12] 1357 	mov	r6,a
      007A39                       1358 00201$:
      007A39 EE               [12] 1359 	mov	a,r6
      007A3A 70 03            [24] 1360 	jnz	00458$
      007A3C 02 7B 7B         [24] 1361 	ljmp	00181$
      007A3F                       1362 00458$:
                                   1363 ;	quantum/action.c:663: uint8_t shift = action.layer_bitop.part * 4;
      007A3F 12 7D DA         [24] 1364 	lcall	_ak820_outline_0147
      007A42 C4               [12] 1365 	swap	a
      007A43 03               [12] 1366 	rr	a
      007A44 54 07            [12] 1367 	anl	a,#0x07
      007A46 25 E0            [12] 1368 	add	a,acc
      007A48 25 E0            [12] 1369 	add	a,acc
      007A4A FF               [12] 1370 	mov	r7,a
                                   1371 ;	quantum/action.c:664: layer_state_t bits = ((layer_state_t)action.layer_bitop.bits) << shift;
      007A4B 12 7D DA         [24] 1372 	lcall	_ak820_outline_0147
      007A4E 54 0F            [12] 1373 	anl	a,#0x0f
      007A50 FE               [12] 1374 	mov	r6,a
      007A51 8F F0            [24] 1375 	mov	b,r7
      007A53 05 F0            [12] 1376 	inc	b
      007A55 EE               [12] 1377 	mov	a,r6
      007A56 80 02            [24] 1378 	sjmp	00460$
      007A58                       1379 00459$:
      007A58 25 E0            [12] 1380 	add	a,acc
      007A5A                       1381 00460$:
      007A5A D5 F0 FB         [24] 1382 	djnz	b,00459$
      007A5D FE               [12] 1383 	mov	r6,a
                                   1384 ;	quantum/action.c:665: layer_state_t mask = action.layer_bitop.xbit ? ~(((layer_state_t)0xf) << shift) : 0;
      007A5E 12 7D DA         [24] 1385 	lcall	_ak820_outline_0147
      007A61 30 E4 11         [24] 1386 	jnb	acc.4,00204$
      007A64 8F F0            [24] 1387 	mov	b,r7
      007A66 05 F0            [12] 1388 	inc	b
      007A68 74 0F            [12] 1389 	mov	a,#0x0f
      007A6A 80 02            [24] 1390 	sjmp	00463$
      007A6C                       1391 00462$:
      007A6C 25 E0            [12] 1392 	add	a,acc
      007A6E                       1393 00463$:
      007A6E D5 F0 FB         [24] 1394 	djnz	b,00462$
      007A71 F4               [12] 1395 	cpl	a
      007A72 FF               [12] 1396 	mov	r7,a
      007A73 80 02            [24] 1397 	sjmp	00205$
      007A75                       1398 00204$:
      007A75 7F 00            [12] 1399 	mov	r7,#0x00
      007A77                       1400 00205$:
                                   1401 ;	quantum/action.c:666: bits |= mask;
      007A77 EE               [12] 1402 	mov	a,r6
      007A78 42 07            [12] 1403 	orl	ar7,a
                                   1404 ;	quantum/action.c:667: if (!on) {
      007A7A 90 08 64         [24] 1405 	mov	dptr,#_process_action_on_40000_686
      007A7D E0               [24] 1406 	movx	a,@dptr
      007A7E 70 31            [24] 1407 	jnz	00143$
                                   1408 ;	quantum/action.c:668: switch (action.layer_bitop.op) {
      007A80 12 7D AC         [24] 1409 	lcall	_ak820_outline_0085
      007A83 FE               [12] 1410 	mov	r6,a
      007A84 2E               [12] 1411 	add	a,r6
                                   1412 ;	quantum/action.c:669: case OP_BIT_AND: default_layer_and(bits); break;
      007A85 90 7A 89         [24] 1413 	mov	dptr,#00465$
      007A88 73               [24] 1414 	jmp	@a+dptr
      007A89                       1415 00465$:
      007A89 80 06            [24] 1416 	sjmp	00132$
      007A8B 80 0C            [24] 1417 	sjmp	00133$
      007A8D 80 12            [24] 1418 	sjmp	00134$
      007A8F 80 18            [24] 1419 	sjmp	00135$
      007A91                       1420 00132$:
      007A91 8F 82            [24] 1421 	mov	dpl, r7
      007A93 12 7E 2E         [24] 1422 	lcall	_default_layer_and
      007A96 02 7B 7B         [24] 1423 	ljmp	00181$
                                   1424 ;	quantum/action.c:670: case OP_BIT_OR: default_layer_or(bits); break;
      007A99                       1425 00133$:
      007A99 8F 82            [24] 1426 	mov	dpl, r7
      007A9B 12 7E 1D         [24] 1427 	lcall	_default_layer_or
      007A9E 02 7B 7B         [24] 1428 	ljmp	00181$
                                   1429 ;	quantum/action.c:671: case OP_BIT_XOR: default_layer_xor(bits); break;
      007AA1                       1430 00134$:
      007AA1 8F 82            [24] 1431 	mov	dpl, r7
      007AA3 12 7E 44         [24] 1432 	lcall	_default_layer_xor
      007AA6 02 7B 7B         [24] 1433 	ljmp	00181$
                                   1434 ;	quantum/action.c:672: case OP_BIT_SET: default_layer_set(bits); break;
      007AA9                       1435 00135$:
      007AA9 8F 82            [24] 1436 	mov	dpl, r7
      007AAB 12 7E 12         [24] 1437 	lcall	_default_layer_set
                                   1438 ;	quantum/action.c:673: }
      007AAE 02 7B 7B         [24] 1439 	ljmp	00181$
      007AB1                       1440 00143$:
                                   1441 ;	quantum/action.c:675: switch (action.layer_bitop.op) {
      007AB1 12 7D AC         [24] 1442 	lcall	_ak820_outline_0085
      007AB4 FE               [12] 1443 	mov	r6,a
      007AB5 2E               [12] 1444 	add	a,r6
                                   1445 ;	quantum/action.c:676: case OP_BIT_AND: layer_and(bits); break;
      007AB6 90 7A BA         [24] 1446 	mov	dptr,#00466$
      007AB9 73               [24] 1447 	jmp	@a+dptr
      007ABA                       1448 00466$:
      007ABA 80 06            [24] 1449 	sjmp	00137$
      007ABC 80 0C            [24] 1450 	sjmp	00138$
      007ABE 80 12            [24] 1451 	sjmp	00139$
      007AC0 80 18            [24] 1452 	sjmp	00140$
      007AC2                       1453 00137$:
      007AC2 8F 82            [24] 1454 	mov	dpl, r7
      007AC4 12 7F C7         [24] 1455 	lcall	_layer_and
      007AC7 02 7B 7B         [24] 1456 	ljmp	00181$
                                   1457 ;	quantum/action.c:677: case OP_BIT_OR: layer_or(bits); break;
      007ACA                       1458 00138$:
      007ACA 8F 82            [24] 1459 	mov	dpl, r7
      007ACC 12 7F B6         [24] 1460 	lcall	_layer_or
      007ACF 02 7B 7B         [24] 1461 	ljmp	00181$
                                   1462 ;	quantum/action.c:678: case OP_BIT_XOR: layer_xor(bits); break;
      007AD2                       1463 00139$:
      007AD2 8F 82            [24] 1464 	mov	dpl, r7
      007AD4 12 7F DD         [24] 1465 	lcall	_layer_xor
      007AD7 02 7B 7B         [24] 1466 	ljmp	00181$
                                   1467 ;	quantum/action.c:679: case OP_BIT_SET: layer_state_set(bits); break;
      007ADA                       1468 00140$:
      007ADA 8F 82            [24] 1469 	mov	dpl, r7
      007ADC 12 7F 53         [24] 1470 	lcall	_layer_state_set
                                   1471 ;	quantum/action.c:683: break;
      007ADF 02 7B 7B         [24] 1472 	ljmp	00181$
                                   1473 ;	quantum/action.c:685: case ACT_LAYER_MODS:
      007AE2                       1474 00147$:
                                   1475 ;	quantum/action.c:686: if (pressed) {
      007AE2 E5 27            [12] 1476 	mov	a,_process_action_sloc0_1_0
      007AE4 60 11            [24] 1477 	jz	00149$
                                   1478 ;	quantum/action.c:687: layer_hold_on(action.layer_mods.layer);
      007AE6 12 7D BC         [24] 1479 	lcall	_ak820_outline_0109
      007AE9 F5 82            [12] 1480 	mov	dpl,a
      007AEB 12 7E B4         [24] 1481 	lcall	_layer_hold_on
                                   1482 ;	quantum/action.c:688: register_mods(action.layer_mods.mods);
      007AEE 12 7D A5         [24] 1483 	lcall	_ak820_outline_0075
      007AF1 12 7C E2         [24] 1484 	lcall	_register_mods
      007AF4 02 7B 7B         [24] 1485 	ljmp	00181$
      007AF7                       1486 00149$:
                                   1487 ;	quantum/action.c:690: unregister_mods(action.layer_mods.mods);
      007AF7 12 7D A5         [24] 1488 	lcall	_ak820_outline_0075
      007AFA 12 7C F6         [24] 1489 	lcall	_unregister_mods
                                   1490 ;	quantum/action.c:691: layer_hold_off(action.layer_mods.layer);
      007AFD 12 7D BC         [24] 1491 	lcall	_ak820_outline_0109
      007B00 F5 82            [12] 1492 	mov	dpl,a
      007B02 12 7E EC         [24] 1493 	lcall	_layer_hold_off
                                   1494 ;	quantum/action.c:693: break;
      007B05 02 7B 7B         [24] 1495 	ljmp	00181$
                                   1496 ;	quantum/action.c:695: case ACT_LAYER_TAP_EXT:
      007B08                       1497 00152$:
                                   1498 ;	quantum/action.c:696: switch (action.layer_tap.code) {
      007B08 12 7D DA         [24] 1499 	lcall	_ak820_outline_0147
      007B0B FF               [12] 1500 	mov	r7,a
      007B0C BF F1 02         [24] 1501 	cjne	r7,#0xf1,00468$
      007B0F 80 0A            [24] 1502 	sjmp	00154$
      007B11                       1503 00468$:
      007B11 BF F2 02         [24] 1504 	cjne	r7,#0xf2,00469$
      007B14 80 19            [24] 1505 	sjmp	00155$
      007B16                       1506 00469$:
                                   1507 ;	quantum/action.c:712: momentary_layer_action:
      007B16 BF F3 3B         [24] 1508 	cjne	r7,#0xf3,00160$
      007B19 80 28            [24] 1509 	sjmp	00156$
      007B1B                       1510 00154$:
                                   1511 ;	quantum/action.c:713: pressed ? layer_hold_on(action.layer_tap.val) : layer_hold_off(action.layer_tap.val);
      007B1B E5 27            [12] 1512 	mov	a,_process_action_sloc0_1_0
      007B1D 60 08            [24] 1513 	jz	00206$
      007B1F 12 7D 8C         [24] 1514 	lcall	_ak820_outline_0039
      007B22 12 7E B4         [24] 1515 	lcall	_layer_hold_on
      007B25 80 54            [24] 1516 	sjmp	00181$
      007B27                       1517 00206$:
      007B27 12 7D 8C         [24] 1518 	lcall	_ak820_outline_0039
      007B2A 12 7E EC         [24] 1519 	lcall	_layer_hold_off
                                   1520 ;	quantum/action.c:714: break;
                                   1521 ;	quantum/action.c:715: case OP_OFF_ON:
      007B2D 80 4C            [24] 1522 	sjmp	00181$
      007B2F                       1523 00155$:
                                   1524 ;	quantum/action.c:716: pressed ? layer_off(action.layer_tap.val) : layer_on(action.layer_tap.val);
      007B2F E5 27            [12] 1525 	mov	a,_process_action_sloc0_1_0
      007B31 60 08            [24] 1526 	jz	00208$
      007B33 12 7D 8C         [24] 1527 	lcall	_ak820_outline_0039
      007B36 12 7F 98         [24] 1528 	lcall	_layer_off
      007B39 80 40            [24] 1529 	sjmp	00181$
      007B3B                       1530 00208$:
      007B3B 12 7D 8C         [24] 1531 	lcall	_ak820_outline_0039
      007B3E 12 7F 7D         [24] 1532 	lcall	_layer_on
                                   1533 ;	quantum/action.c:717: break;
                                   1534 ;	quantum/action.c:718: case OP_SET_CLEAR:
      007B41 80 38            [24] 1535 	sjmp	00181$
      007B43                       1536 00156$:
                                   1537 ;	quantum/action.c:719: pressed ? layer_move(action.layer_tap.val) : layer_clear();
      007B43 E5 27            [12] 1538 	mov	a,_process_action_sloc0_1_0
      007B45 60 08            [24] 1539 	jz	00210$
      007B47 12 7D 8C         [24] 1540 	lcall	_ak820_outline_0039
      007B4A 12 7F 67         [24] 1541 	lcall	_layer_move
      007B4D 80 2C            [24] 1542 	sjmp	00181$
      007B4F                       1543 00210$:
      007B4F 12 7F 61         [24] 1544 	lcall	_layer_clear
                                   1545 ;	quantum/action.c:720: break;
                                   1546 ;	quantum/action.c:766: default:
      007B52 80 27            [24] 1547 	sjmp	00181$
      007B54                       1548 00160$:
                                   1549 ;	quantum/action.c:773: if (pressed) {
      007B54 E5 27            [12] 1550 	mov	a,_process_action_sloc0_1_0
      007B56 60 08            [24] 1551 	jz	00163$
                                   1552 ;	quantum/action.c:775: register_code(action.layer_tap.code);
      007B58 12 7D A5         [24] 1553 	lcall	_ak820_outline_0075
      007B5B 12 7B 92         [24] 1554 	lcall	_register_code
                                   1555 ;	quantum/action.c:777: ac_dprintf("KEYMAP_TAP_KEY: Tap: unregister_code\n");
      007B5E 80 1B            [24] 1556 	sjmp	00181$
      007B60                       1557 00163$:
                                   1558 ;	quantum/action.c:778: if (action.layer_tap.code == KC_CAPS) {
      007B60 12 7D DA         [24] 1559 	lcall	_ak820_outline_0147
      007B63 FF               [12] 1560 	mov	r7,a
      007B64 BF 39 0E         [24] 1561 	cjne	r7,#0x39,00175$
                                   1562 ;	quantum/action.c:779: wait_ms(TAP_HOLD_CAPS_DELAY);
      007B67 7F 50            [12] 1563 	mov	r7,#0x50
      007B69                       1564 00187$:
      007B69 EF               [12] 1565 	mov	a,r7
      007B6A 60 09            [24] 1566 	jz	00175$
      007B6C 90 00 01         [24] 1567 	mov	dptr,#0x0001
      007B6F 12 5E 7F         [24] 1568 	lcall	_mDelaymS
      007B72 1F               [12] 1569 	dec	r7
                                   1570 ;	quantum/action.c:781: wait_ms(TAP_CODE_DELAY);
      007B73 80 F4            [24] 1571 	sjmp	00187$
      007B75                       1572 00175$:
                                   1573 ;	quantum/action.c:783: unregister_code(action.layer_tap.code);
      007B75 12 7D A5         [24] 1574 	lcall	_ak820_outline_0075
      007B78 12 7C 17         [24] 1575 	lcall	_unregister_code
                                   1576 ;	quantum/action.c:866: }
      007B7B                       1577 00181$:
                                   1578 ;	quantum/action.c:887: switch (action.kind.id) {
      007B7B 90 08 61         [24] 1579 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007B7E E0               [24] 1580 	movx	a,@dptr
      007B7F C4               [12] 1581 	swap	a
      007B80 54 0F            [12] 1582 	anl	a,#0x0f
      007B82 FF               [12] 1583 	mov	r7,a
      007B83 BF 08 02         [24] 1584 	cjne	r7,#0x08,00478$
      007B86 80 03            [24] 1585 	sjmp	00183$
      007B88                       1586 00478$:
      007B88 BF 09 06         [24] 1587 	cjne	r7,#0x09,00192$
                                   1588 ;	quantum/action.c:889: case ACT_LAYER_MODS:
      007B8B                       1589 00183$:
                                   1590 ;	quantum/action.c:894: led_set(host_keyboard_leds());
      007B8B 12 72 F6         [24] 1591 	lcall	_host_keyboard_leds
                                   1592 ;	quantum/action.c:898: }
                                   1593 ;	quantum/action.c:951: }
      007B8E 02 9E 2B         [24] 1594 	ljmp	_led_set
      007B91                       1595 00192$:
      007B91 22               [24] 1596 	ret
                                   1597 ;------------------------------------------------------------
                                   1598 ;Allocation info for local variables in function 'register_code'
                                   1599 ;------------------------------------------------------------
                                   1600 ;code          Allocated with name '_register_code_code_10000_720'
                                   1601 ;------------------------------------------------------------
                                   1602 ;	quantum/action.c:957: __attribute__((weak)) void register_code(uint8_t code) {
                                   1603 ;	-----------------------------------------
                                   1604 ;	 function register_code
                                   1605 ;	-----------------------------------------
      007B92                       1606 _register_code:
      007B92 E5 82            [12] 1607 	mov	a,dpl
      007B94 90 08 65         [24] 1608 	mov	dptr,#_register_code_code_10000_720
      007B97 F0               [24] 1609 	movx	@dptr,a
                                   1610 ;	quantum/action.c:958: if (code == KC_NO) {
      007B98 E0               [24] 1611 	movx	a,@dptr
      007B99 FF               [12] 1612 	mov	r7,a
      007B9A 70 01            [24] 1613 	jnz	00123$
                                   1614 ;	quantum/action.c:959: return;
      007B9C 22               [24] 1615 	ret
      007B9D                       1616 00123$:
                                   1617 ;	quantum/action.c:994: } else if (IS_BASIC_KEYCODE(code)) {
      007B9D BF 04 00         [24] 1618 	cjne	r7,#0x04,00198$
      007BA0                       1619 00198$:
      007BA0 40 12            [24] 1620 	jc	00119$
      007BA2 EF               [12] 1621 	mov	a,r7
      007BA3 24 5B            [12] 1622 	add	a,#0xff - 0xa4
      007BA5 40 0D            [24] 1623 	jc	00119$
                                   1624 ;	free result
                                   1625 ;	quantum/action.c:999: if (!add_owned_key(code)) return;
      007BA7 8F 82            [24] 1626 	mov	dpl, r7
      007BA9 12 84 2C         [24] 1627 	lcall	_add_owned_key
      007BAC E5 82            [12] 1628 	mov	a, dpl
      007BAE 70 01            [24] 1629 	jnz	00104$
      007BB0 22               [24] 1630 	ret
      007BB1                       1631 00104$:
                                   1632 ;	quantum/action.c:1013: send_keyboard_report();
      007BB1 02 86 C4         [24] 1633 	ljmp	_send_keyboard_report
      007BB4                       1634 00119$:
                                   1635 ;	quantum/action.c:1014: } else if (IS_MODIFIER_KEYCODE(code)) {
      007BB4 12 7D CE         [24] 1636 	lcall	_ak820_outline_0138
      007BB7 BF E0 00         [24] 1637 	cjne	r7,#0xe0,00202$
      007BBA                       1638 00202$:
      007BBA 40 1A            [24] 1639 	jc	00115$
      007BBC EF               [12] 1640 	mov	a,r7
      007BBD 24 18            [12] 1641 	add	a,#0xff - 0xe7
      007BBF 40 15            [24] 1642 	jc	00115$
                                   1643 ;	free result
                                   1644 ;	quantum/action.c:1015: add_owned_mods(MOD_BIT(code));
      007BC1 74 07            [12] 1645 	mov	a,#0x07
      007BC3 5F               [12] 1646 	anl	a,r7
      007BC4 12 7D 9E         [24] 1647 	lcall	_ak820_outline_0063
      007BC7 80 02            [24] 1648 	sjmp	00206$
      007BC9                       1649 00205$:
      007BC9 25 E0            [12] 1650 	add	a,acc
      007BCB                       1651 00206$:
      007BCB D5 F0 FB         [24] 1652 	djnz	b,00205$
      007BCE F5 82            [12] 1653 	mov	dpl,a
      007BD0 12 83 89         [24] 1654 	lcall	_add_owned_mods
                                   1655 ;	quantum/action.c:1016: send_keyboard_report();
      007BD3 02 86 C4         [24] 1656 	ljmp	_send_keyboard_report
      007BD6                       1657 00115$:
                                   1658 ;	quantum/action.c:1019: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      007BD6 12 7D CE         [24] 1659 	lcall	_ak820_outline_0138
      007BD9 BF A5 00         [24] 1660 	cjne	r7,#0xa5,00207$
      007BDC                       1661 00207$:
      007BDC 40 05            [24] 1662 	jc	00113$
      007BDE EF               [12] 1663 	mov	a,r7
      007BDF 24 58            [12] 1664 	add	a,#0xff - 0xa7
      007BE1 50 0D            [24] 1665 	jnc	00108$
                                   1666 ;	free result
      007BE3                       1667 00113$:
      007BE3 12 7D CE         [24] 1668 	lcall	_ak820_outline_0138
      007BE6 BF A8 00         [24] 1669 	cjne	r7,#0xa8,00210$
      007BE9                       1670 00210$:
      007BE9 40 13            [24] 1671 	jc	00109$
      007BEB EF               [12] 1672 	mov	a,r7
      007BEC 24 3D            [12] 1673 	add	a,#0xff - 0xc2
      007BEE 40 0E            [24] 1674 	jc	00109$
                                   1675 ;	free result
      007BF0                       1676 00108$:
                                   1677 ;	quantum/action.c:1021: owned_usage_key(code, true);
      007BF0 12 7D CE         [24] 1678 	lcall	_ak820_outline_0138
      007BF3 90 0A C3         [24] 1679 	mov	dptr,#_owned_usage_key_PARM_2
      007BF6 74 01            [12] 1680 	mov	a,#0x01
      007BF8 F0               [24] 1681 	movx	@dptr,a
      007BF9 8F 82            [24] 1682 	mov	dpl, r7
      007BFB 02 85 6F         [24] 1683 	ljmp	_owned_usage_key
      007BFE                       1684 00109$:
                                   1685 ;	quantum/action.c:1028: } else if (IS_MOUSE_KEYCODE(code)) {
      007BFE 12 7D CE         [24] 1686 	lcall	_ak820_outline_0138
      007C01 BF CD 00         [24] 1687 	cjne	r7,#0xcd,00213$
      007C04                       1688 00213$:
      007C04 40 10            [24] 1689 	jc	00125$
      007C06 EF               [12] 1690 	mov	a,r7
      007C07 24 20            [12] 1691 	add	a,#0xff - 0xdf
      007C09 40 0B            [24] 1692 	jc	00125$
                                   1693 ;	free result
                                   1694 ;	quantum/action.c:1029: register_mouse(code, true);
      007C0B 90 08 5E         [24] 1695 	mov	dptr,#_register_mouse_PARM_2
      007C0E 74 01            [12] 1696 	mov	a,#0x01
      007C10 F0               [24] 1697 	movx	@dptr,a
      007C11 8F 82            [24] 1698 	mov	dpl, r7
                                   1699 ;	quantum/action.c:1031: }
      007C13 02 78 A5         [24] 1700 	ljmp	_register_mouse
      007C16                       1701 00125$:
      007C16 22               [24] 1702 	ret
                                   1703 ;------------------------------------------------------------
                                   1704 ;Allocation info for local variables in function 'unregister_code'
                                   1705 ;------------------------------------------------------------
                                   1706 ;code          Allocated with name '_unregister_code_code_10000_734'
                                   1707 ;------------------------------------------------------------
                                   1708 ;	quantum/action.c:1037: __attribute__((weak)) void unregister_code(uint8_t code) {
                                   1709 ;	-----------------------------------------
                                   1710 ;	 function unregister_code
                                   1711 ;	-----------------------------------------
      007C17                       1712 _unregister_code:
      007C17 E5 82            [12] 1713 	mov	a,dpl
      007C19 90 08 66         [24] 1714 	mov	dptr,#_unregister_code_code_10000_734
      007C1C F0               [24] 1715 	movx	@dptr,a
                                   1716 ;	quantum/action.c:1038: if (code == KC_NO) {
      007C1D E0               [24] 1717 	movx	a,@dptr
      007C1E FF               [12] 1718 	mov	r7,a
      007C1F 70 01            [24] 1719 	jnz	00121$
                                   1720 ;	quantum/action.c:1039: return;
      007C21 22               [24] 1721 	ret
      007C22                       1722 00121$:
                                   1723 ;	quantum/action.c:1071: } else if (IS_BASIC_KEYCODE(code)) {
      007C22 BF 04 00         [24] 1724 	cjne	r7,#0x04,00196$
      007C25                       1725 00196$:
      007C25 40 12            [24] 1726 	jc	00117$
      007C27 EF               [12] 1727 	mov	a,r7
      007C28 24 5B            [12] 1728 	add	a,#0xff - 0xa4
      007C2A 40 0D            [24] 1729 	jc	00117$
                                   1730 ;	free result
                                   1731 ;	quantum/action.c:1073: if (!del_owned_key(code)) return;
      007C2C 8F 82            [24] 1732 	mov	dpl, r7
      007C2E 12 84 A6         [24] 1733 	lcall	_del_owned_key
      007C31 E5 82            [12] 1734 	mov	a, dpl
      007C33 70 01            [24] 1735 	jnz	00102$
      007C35 22               [24] 1736 	ret
      007C36                       1737 00102$:
                                   1738 ;	quantum/action.c:1080: send_keyboard_report();
      007C36 02 86 C4         [24] 1739 	ljmp	_send_keyboard_report
      007C39                       1740 00117$:
                                   1741 ;	quantum/action.c:1081: } else if (IS_MODIFIER_KEYCODE(code)) {
      007C39 12 7D D4         [24] 1742 	lcall	_ak820_outline_0139
      007C3C BF E0 00         [24] 1743 	cjne	r7,#0xe0,00200$
      007C3F                       1744 00200$:
      007C3F 40 1A            [24] 1745 	jc	00113$
      007C41 EF               [12] 1746 	mov	a,r7
      007C42 24 18            [12] 1747 	add	a,#0xff - 0xe7
      007C44 40 15            [24] 1748 	jc	00113$
                                   1749 ;	free result
                                   1750 ;	quantum/action.c:1082: del_owned_mods(MOD_BIT(code));
      007C46 74 07            [12] 1751 	mov	a,#0x07
      007C48 5F               [12] 1752 	anl	a,r7
      007C49 12 7D 9E         [24] 1753 	lcall	_ak820_outline_0063
      007C4C 80 02            [24] 1754 	sjmp	00204$
      007C4E                       1755 00203$:
      007C4E 25 E0            [12] 1756 	add	a,acc
      007C50                       1757 00204$:
      007C50 D5 F0 FB         [24] 1758 	djnz	b,00203$
      007C53 F5 82            [12] 1759 	mov	dpl,a
      007C55 12 83 99         [24] 1760 	lcall	_del_owned_mods
                                   1761 ;	quantum/action.c:1083: send_keyboard_report();
      007C58 02 86 C4         [24] 1762 	ljmp	_send_keyboard_report
      007C5B                       1763 00113$:
                                   1764 ;	quantum/action.c:1086: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      007C5B 12 7D D4         [24] 1765 	lcall	_ak820_outline_0139
      007C5E BF A5 00         [24] 1766 	cjne	r7,#0xa5,00205$
      007C61                       1767 00205$:
      007C61 40 05            [24] 1768 	jc	00111$
      007C63 EF               [12] 1769 	mov	a,r7
      007C64 24 58            [12] 1770 	add	a,#0xff - 0xa7
      007C66 50 0D            [24] 1771 	jnc	00106$
                                   1772 ;	free result
      007C68                       1773 00111$:
      007C68 12 7D D4         [24] 1774 	lcall	_ak820_outline_0139
      007C6B BF A8 00         [24] 1775 	cjne	r7,#0xa8,00208$
      007C6E                       1776 00208$:
      007C6E 40 11            [24] 1777 	jc	00107$
      007C70 EF               [12] 1778 	mov	a,r7
      007C71 24 3D            [12] 1779 	add	a,#0xff - 0xc2
      007C73 40 0C            [24] 1780 	jc	00107$
                                   1781 ;	free result
      007C75                       1782 00106$:
                                   1783 ;	quantum/action.c:1088: owned_usage_key(code, false);
      007C75 12 7D D4         [24] 1784 	lcall	_ak820_outline_0139
      007C78 90 0A C3         [24] 1785 	mov	dptr,#_owned_usage_key_PARM_2
      007C7B 12 7D DF         [24] 1786 	lcall	_ak820_outline_0184
      007C7E 02 85 6F         [24] 1787 	ljmp	_owned_usage_key
      007C81                       1788 00107$:
                                   1789 ;	quantum/action.c:1095: } else if (IS_MOUSE_KEYCODE(code)) {
      007C81 12 7D D4         [24] 1790 	lcall	_ak820_outline_0139
      007C84 BF CD 00         [24] 1791 	cjne	r7,#0xcd,00211$
      007C87                       1792 00211$:
      007C87 40 0E            [24] 1793 	jc	00123$
      007C89 EF               [12] 1794 	mov	a,r7
      007C8A 24 20            [12] 1795 	add	a,#0xff - 0xdf
      007C8C 40 09            [24] 1796 	jc	00123$
                                   1797 ;	free result
                                   1798 ;	quantum/action.c:1096: register_mouse(code, false);
      007C8E 90 08 5E         [24] 1799 	mov	dptr,#_register_mouse_PARM_2
      007C91 12 7D DF         [24] 1800 	lcall	_ak820_outline_0184
                                   1801 ;	quantum/action.c:1098: }
      007C94 02 78 A5         [24] 1802 	ljmp	_register_mouse
      007C97                       1803 00123$:
      007C97 22               [24] 1804 	ret
                                   1805 ;------------------------------------------------------------
                                   1806 ;Allocation info for local variables in function 'tap_code_delay'
                                   1807 ;------------------------------------------------------------
                                   1808 ;delay         Allocated with name '_tap_code_delay_PARM_2'
                                   1809 ;code          Allocated with name '_tap_code_delay_code_10000_747'
                                   1810 ;i             Allocated with name '_tap_code_delay_i_20000_749'
                                   1811 ;i             Allocated with name '_tap_code_delay_i_50000_752'
                                   1812 ;------------------------------------------------------------
                                   1813 ;	quantum/action.c:1105: __attribute__((weak)) void tap_code_delay(uint8_t code, uint16_t delay) {
                                   1814 ;	-----------------------------------------
                                   1815 ;	 function tap_code_delay
                                   1816 ;	-----------------------------------------
      007C98                       1817 _tap_code_delay:
      007C98 E5 82            [12] 1818 	mov	a,dpl
      007C9A 90 08 69         [24] 1819 	mov	dptr,#_tap_code_delay_code_10000_747
      007C9D F0               [24] 1820 	movx	@dptr,a
                                   1821 ;	quantum/action.c:1106: register_code(code);
      007C9E E0               [24] 1822 	movx	a,@dptr
      007C9F FF               [12] 1823 	mov	r7,a
      007CA0 F5 82            [12] 1824 	mov	dpl,a
      007CA2 C0 07            [24] 1825 	push	ar7
      007CA4 12 7B 92         [24] 1826 	lcall	_register_code
      007CA7 D0 07            [24] 1827 	pop	ar7
                                   1828 ;	quantum/action.c:1107: for (uint16_t i = delay; i > 0; i--) {
      007CA9 90 08 67         [24] 1829 	mov	dptr,#_tap_code_delay_PARM_2
      007CAC 12 45 BD         [24] 1830 	lcall	_ak820_outline_0097
      007CAF                       1831 00110$:
      007CAF ED               [12] 1832 	mov	a,r5
      007CB0 4E               [12] 1833 	orl	a,r6
      007CB1 60 0D            [24] 1834 	jz	00105$
                                   1835 ;	quantum/action.c:1108: wait_ms(1);
      007CB3 90 00 01         [24] 1836 	mov	dptr,#0x0001
      007CB6 12 5E 7F         [24] 1837 	lcall	_mDelaymS
                                   1838 ;	quantum/action.c:1107: for (uint16_t i = delay; i > 0; i--) {
      007CB9 1D               [12] 1839 	dec	r5
      007CBA BD FF 01         [24] 1840 	cjne	r5,#0xff,00141$
      007CBD 1E               [12] 1841 	dec	r6
      007CBE                       1842 00141$:
      007CBE 80 EF            [24] 1843 	sjmp	00110$
      007CC0                       1844 00105$:
                                   1845 ;	quantum/action.c:1110: unregister_code(code);
      007CC0 8F 82            [24] 1846 	mov	dpl, r7
                                   1847 ;	quantum/action.c:1111: }
      007CC2 02 7C 17         [24] 1848 	ljmp	_unregister_code
                                   1849 ;------------------------------------------------------------
                                   1850 ;Allocation info for local variables in function 'tap_code'
                                   1851 ;------------------------------------------------------------
                                   1852 ;code          Allocated with name '_tap_code_code_10000_754'
                                   1853 ;------------------------------------------------------------
                                   1854 ;	quantum/action.c:1117: __attribute__((weak)) void tap_code(uint8_t code) {
                                   1855 ;	-----------------------------------------
                                   1856 ;	 function tap_code
                                   1857 ;	-----------------------------------------
      007CC5                       1858 _tap_code:
      007CC5 E5 82            [12] 1859 	mov	a,dpl
      007CC7 90 08 6A         [24] 1860 	mov	dptr,#_tap_code_code_10000_754
      007CCA F0               [24] 1861 	movx	@dptr,a
                                   1862 ;	quantum/action.c:1118: tap_code_delay(code, code == KC_CAPS ? QS_tap_hold_caps_delay : QS_tap_code_delay);
      007CCB E0               [24] 1863 	movx	a,@dptr
      007CCC FF               [12] 1864 	mov	r7,a
      007CCD BF 39 04         [24] 1865 	cjne	r7,#0x39,00103$
      007CD0 7E 50            [12] 1866 	mov	r6,#0x50
      007CD2 80 02            [24] 1867 	sjmp	00104$
      007CD4                       1868 00103$:
      007CD4 7E 00            [12] 1869 	mov	r6,#0x00
      007CD6                       1870 00104$:
      007CD6 90 08 67         [24] 1871 	mov	dptr,#_tap_code_delay_PARM_2
      007CD9 EE               [12] 1872 	mov	a,r6
      007CDA 12 3A AB         [24] 1873 	lcall	_ak820_outline_0123
      007CDD 8F 82            [24] 1874 	mov	dpl, r7
                                   1875 ;	quantum/action.c:1119: }
      007CDF 02 7C 98         [24] 1876 	ljmp	_tap_code_delay
                                   1877 ;------------------------------------------------------------
                                   1878 ;Allocation info for local variables in function 'register_mods'
                                   1879 ;------------------------------------------------------------
                                   1880 ;mods          Allocated with name '_register_mods_mods_10000_756'
                                   1881 ;------------------------------------------------------------
                                   1882 ;	quantum/action.c:1125: __attribute__((weak)) void register_mods(uint8_t mods) {
                                   1883 ;	-----------------------------------------
                                   1884 ;	 function register_mods
                                   1885 ;	-----------------------------------------
      007CE2                       1886 _register_mods:
      007CE2 E5 82            [12] 1887 	mov	a,dpl
      007CE4 90 08 6B         [24] 1888 	mov	dptr,#_register_mods_mods_10000_756
      007CE7 F0               [24] 1889 	movx	@dptr,a
                                   1890 ;	quantum/action.c:1126: if (mods) {
      007CE8 E0               [24] 1891 	movx	a,@dptr
      007CE9 FF               [12] 1892 	mov	r7,a
      007CEA E0               [24] 1893 	movx	a,@dptr
      007CEB 60 08            [24] 1894 	jz	00103$
                                   1895 ;	quantum/action.c:1127: add_owned_mods(mods);
      007CED 8F 82            [24] 1896 	mov	dpl, r7
      007CEF 12 83 89         [24] 1897 	lcall	_add_owned_mods
                                   1898 ;	quantum/action.c:1128: send_keyboard_report();
                                   1899 ;	quantum/action.c:1130: }
      007CF2 02 86 C4         [24] 1900 	ljmp	_send_keyboard_report
      007CF5                       1901 00103$:
      007CF5 22               [24] 1902 	ret
                                   1903 ;------------------------------------------------------------
                                   1904 ;Allocation info for local variables in function 'unregister_mods'
                                   1905 ;------------------------------------------------------------
                                   1906 ;mods          Allocated with name '_unregister_mods_mods_10000_760'
                                   1907 ;------------------------------------------------------------
                                   1908 ;	quantum/action.c:1136: __attribute__((weak)) void unregister_mods(uint8_t mods) {
                                   1909 ;	-----------------------------------------
                                   1910 ;	 function unregister_mods
                                   1911 ;	-----------------------------------------
      007CF6                       1912 _unregister_mods:
      007CF6 E5 82            [12] 1913 	mov	a,dpl
      007CF8 90 08 6C         [24] 1914 	mov	dptr,#_unregister_mods_mods_10000_760
      007CFB F0               [24] 1915 	movx	@dptr,a
                                   1916 ;	quantum/action.c:1137: if (mods) {
      007CFC E0               [24] 1917 	movx	a,@dptr
      007CFD FF               [12] 1918 	mov	r7,a
      007CFE E0               [24] 1919 	movx	a,@dptr
      007CFF 60 08            [24] 1920 	jz	00103$
                                   1921 ;	quantum/action.c:1138: del_owned_mods(mods);
      007D01 8F 82            [24] 1922 	mov	dpl, r7
      007D03 12 83 99         [24] 1923 	lcall	_del_owned_mods
                                   1924 ;	quantum/action.c:1139: send_keyboard_report();
                                   1925 ;	quantum/action.c:1141: }
      007D06 02 86 C4         [24] 1926 	ljmp	_send_keyboard_report
      007D09                       1927 00103$:
      007D09 22               [24] 1928 	ret
                                   1929 ;------------------------------------------------------------
                                   1930 ;Allocation info for local variables in function 'register_weak_mods'
                                   1931 ;------------------------------------------------------------
                                   1932 ;mods          Allocated with name '_register_weak_mods_mods_10000_764'
                                   1933 ;------------------------------------------------------------
                                   1934 ;	quantum/action.c:1147: __attribute__((weak)) void register_weak_mods(uint8_t mods) {
                                   1935 ;	-----------------------------------------
                                   1936 ;	 function register_weak_mods
                                   1937 ;	-----------------------------------------
      007D0A                       1938 _register_weak_mods:
      007D0A E5 82            [12] 1939 	mov	a,dpl
      007D0C 90 08 6D         [24] 1940 	mov	dptr,#_register_weak_mods_mods_10000_764
      007D0F F0               [24] 1941 	movx	@dptr,a
                                   1942 ;	quantum/action.c:1148: if (mods) {
      007D10 E0               [24] 1943 	movx	a,@dptr
      007D11 FF               [12] 1944 	mov	r7,a
      007D12 E0               [24] 1945 	movx	a,@dptr
      007D13 60 08            [24] 1946 	jz	00103$
                                   1947 ;	quantum/action.c:1149: add_owned_weak_mods(mods);
      007D15 8F 82            [24] 1948 	mov	dpl, r7
      007D17 12 83 A7         [24] 1949 	lcall	_add_owned_weak_mods
                                   1950 ;	quantum/action.c:1150: send_keyboard_report();
                                   1951 ;	quantum/action.c:1152: }
      007D1A 02 86 C4         [24] 1952 	ljmp	_send_keyboard_report
      007D1D                       1953 00103$:
      007D1D 22               [24] 1954 	ret
                                   1955 ;------------------------------------------------------------
                                   1956 ;Allocation info for local variables in function 'unregister_weak_mods'
                                   1957 ;------------------------------------------------------------
                                   1958 ;mods          Allocated with name '_unregister_weak_mods_mods_10000_768'
                                   1959 ;------------------------------------------------------------
                                   1960 ;	quantum/action.c:1158: __attribute__((weak)) void unregister_weak_mods(uint8_t mods) {
                                   1961 ;	-----------------------------------------
                                   1962 ;	 function unregister_weak_mods
                                   1963 ;	-----------------------------------------
      007D1E                       1964 _unregister_weak_mods:
      007D1E E5 82            [12] 1965 	mov	a,dpl
      007D20 90 08 6E         [24] 1966 	mov	dptr,#_unregister_weak_mods_mods_10000_768
      007D23 F0               [24] 1967 	movx	@dptr,a
                                   1968 ;	quantum/action.c:1159: if (mods) {
      007D24 E0               [24] 1969 	movx	a,@dptr
      007D25 FF               [12] 1970 	mov	r7,a
      007D26 E0               [24] 1971 	movx	a,@dptr
      007D27 60 08            [24] 1972 	jz	00103$
                                   1973 ;	quantum/action.c:1160: del_owned_weak_mods(mods);
      007D29 8F 82            [24] 1974 	mov	dpl, r7
      007D2B 12 83 B7         [24] 1975 	lcall	_del_owned_weak_mods
                                   1976 ;	quantum/action.c:1161: send_keyboard_report();
                                   1977 ;	quantum/action.c:1163: }
      007D2E 02 86 C4         [24] 1978 	ljmp	_send_keyboard_report
      007D31                       1979 00103$:
      007D31 22               [24] 1980 	ret
                                   1981 ;------------------------------------------------------------
                                   1982 ;Allocation info for local variables in function 'clear_keyboard'
                                   1983 ;------------------------------------------------------------
                                   1984 ;	quantum/action.c:1169: void clear_keyboard(void) {
                                   1985 ;	-----------------------------------------
                                   1986 ;	 function clear_keyboard
                                   1987 ;	-----------------------------------------
      007D32                       1988 _clear_keyboard:
                                   1989 ;	quantum/action.c:1170: clear_mods();
      007D32 12 87 48         [24] 1990 	lcall	_clear_mods
                                   1991 ;	quantum/action.c:1171: clear_keyboard_but_mods();
                                   1992 ;	quantum/action.c:1172: }
      007D35 02 7D 38         [24] 1993 	ljmp	_clear_keyboard_but_mods
                                   1994 ;------------------------------------------------------------
                                   1995 ;Allocation info for local variables in function 'clear_keyboard_but_mods'
                                   1996 ;------------------------------------------------------------
                                   1997 ;	quantum/action.c:1178: void clear_keyboard_but_mods(void) {
                                   1998 ;	-----------------------------------------
                                   1999 ;	 function clear_keyboard_but_mods
                                   2000 ;	-----------------------------------------
      007D38                       2001 _clear_keyboard_but_mods:
                                   2002 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007D38 90 0D D0         [24] 2003 	mov	dptr,#_actual_keyboard_report
      007D3B 12 75 B6         [24] 2004 	lcall	_clear_keys_from_report
                                   2005 ;	quantum/action.c:1180: clear_keyboard_but_mods_and_keys();
                                   2006 ;	quantum/action.c:1181: }
      007D3E 02 7D 41         [24] 2007 	ljmp	_clear_keyboard_but_mods_and_keys
                                   2008 ;------------------------------------------------------------
                                   2009 ;Allocation info for local variables in function 'clear_keyboard_but_mods_and_keys'
                                   2010 ;------------------------------------------------------------
                                   2011 ;	quantum/action.c:1187: void clear_keyboard_but_mods_and_keys(void) {
                                   2012 ;	-----------------------------------------
                                   2013 ;	 function clear_keyboard_but_mods_and_keys
                                   2014 ;	-----------------------------------------
      007D41                       2015 _clear_keyboard_but_mods_and_keys:
                                   2016 ;	quantum/action.c:1189: ak820_tapping_cancel();
      007D41 12 49 FC         [24] 2017 	lcall	_ak820_tapping_cancel
                                   2018 ;	quantum/action.c:1203: ak820_autoshift_cancel();
      007D44 12 33 45         [24] 2019 	lcall	_ak820_autoshift_cancel
                                   2020 ;	quantum/action.c:1206: ak820_oneshot_cancel();
      007D47 12 2E A4         [24] 2021 	lcall	_ak820_oneshot_cancel
                                   2022 ;	quantum/action.c:1209: ak820_combo_cancel();
      007D4A 12 37 6D         [24] 2023 	lcall	_ak820_combo_cancel
                                   2024 ;	quantum/action.c:1212: repeat_key_cancel();
      007D4D 12 A7 3C         [24] 2025 	lcall	_repeat_key_cancel
                                   2026 ;	quantum/action.c:1214: clear_owned_mods();
      007D50 12 83 C7         [24] 2027 	lcall	_clear_owned_mods
                                   2028 ;	quantum/action.c:1215: clear_owned_keys();
      007D53 12 83 FF         [24] 2029 	lcall	_clear_owned_keys
                                   2030 ;	quantum/action.c:1216: clear_owned_usages();
      007D56 12 85 37         [24] 2031 	lcall	_clear_owned_usages
                                   2032 ;	quantum/action.c:1217: layer_hold_clear();
      007D59 12 7F 24         [24] 2033 	lcall	_layer_hold_clear
                                   2034 ;	quantum/action.c:1219: clear_macro_tri_layer();
      007D5C 12 A2 BA         [24] 2035 	lcall	_clear_macro_tri_layer
                                   2036 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007D5F 90 0D D0         [24] 2037 	mov	dptr,#_actual_keyboard_report
      007D62 12 75 B6         [24] 2038 	lcall	_clear_keys_from_report
                                   2039 ;	quantum/action.c:1224: host_system_send(0);
      007D65 90 00 00         [24] 2040 	mov	dptr,#0x0000
      007D68 12 73 91         [24] 2041 	lcall	_host_system_send
                                   2042 ;	quantum/action.c:1225: host_consumer_send(0);
      007D6B 90 00 00         [24] 2043 	mov	dptr,#0x0000
      007D6E 12 73 C1         [24] 2044 	lcall	_host_consumer_send
                                   2045 ;	quantum/action.c:1227: clear_weak_mods();
      007D71 12 87 7D         [24] 2046 	lcall	_clear_weak_mods
                                   2047 ;	quantum/action.c:1228: send_keyboard_report();
      007D74 12 86 C4         [24] 2048 	lcall	_send_keyboard_report
                                   2049 ;	quantum/action.c:1230: mousekey_clear();
      007D77 12 54 F5         [24] 2050 	lcall	_mousekey_clear
                                   2051 ;	quantum/action.c:1231: mousekey_send();
                                   2052 ;	quantum/action.c:1236: }
      007D7A 02 53 BD         [24] 2053 	ljmp	_mousekey_send
                                   2054 ;------------------------------------------------------------
                                   2055 ;Allocation info for local variables in function 'is_tap_record'
                                   2056 ;------------------------------------------------------------
                                   2057 ;record        Allocated with name '_is_tap_record_record_10000_784'
                                   2058 ;action        Allocated with name '_is_tap_record_action_10001_788'
                                   2059 ;------------------------------------------------------------
                                   2060 ;	quantum/action.c:1242: bool is_tap_record(keyrecord_t *record) {
                                   2061 ;	-----------------------------------------
                                   2062 	.area CSEG    (CODE)
                                   2063 	.area CONST   (CODE)
                                   2064 	.area XINIT   (CODE)
      00C6FD                       2065 __xinit__disable_action_cache:
      00C6FD 00                    2066 	.db #0x00	;  0
                                   2067 	.area CABS    (ABS,CODE)
                                   2068 
                                   2069 ; Experimental exact instruction outlining.
                                   2070 	.globl _ak820_outline_0004
                                   2071 	.globl _ak820_outline_0009
                                   2072 	.globl _ak820_outline_0010
                                   2073 	.globl _ak820_outline_0011
                                   2074 	.globl _ak820_outline_0012
                                   2075 	.globl _ak820_outline_0016
                                   2076 	.globl _ak820_outline_0017
                                   2077 	.globl _ak820_outline_0019
                                   2078 	.globl _ak820_outline_0031
                                   2079 	.globl _ak820_outline_0039
                                   2080 	.globl _ak820_outline_0050
                                   2081 	.globl _ak820_outline_0051
                                   2082 	.globl _ak820_outline_0055
                                   2083 	.globl _ak820_outline_0058
                                   2084 	.globl _ak820_outline_0063
                                   2085 	.globl _ak820_outline_0071
                                   2086 	.globl _ak820_outline_0075
                                   2087 	.globl _ak820_outline_0085
                                   2088 	.globl _ak820_outline_0097
                                   2089 	.globl _ak820_outline_0103
                                   2090 	.globl _ak820_outline_0104
                                   2091 	.globl _ak820_outline_0106
                                   2092 	.globl _ak820_outline_0107
                                   2093 	.globl _ak820_outline_0109
                                   2094 	.globl _ak820_outline_0116
                                   2095 	.globl _ak820_outline_0121
                                   2096 	.globl _ak820_outline_0122
                                   2097 	.globl _ak820_outline_0123
                                   2098 	.globl _ak820_outline_0129
                                   2099 	.globl _ak820_outline_0138
                                   2100 	.globl _ak820_outline_0139
                                   2101 	.globl _ak820_outline_0141
                                   2102 	.globl _ak820_outline_0142
                                   2103 	.globl _ak820_outline_0147
                                   2104 	.globl _ak820_outline_0148
                                   2105 	.globl _ak820_outline_0178
                                   2106 	.globl _ak820_outline_0184
                                   2107 	.globl _ak820_outline_0185
                                   2108 
                                   2109 	.area CSEG (CODE)
                                   2110 ; function ak820_outline_0019
      007D7D                       2111 _ak820_outline_0019:
      007D7D 8E 82            [24] 2112 	mov	dpl,r6
      007D7F 8F 83            [24] 2113 	mov	dph,r7
      007D81 A3               [24] 2114 	inc	dptr
      007D82 E0               [24] 2115 	movx	a,@dptr
      007D83 FC               [12] 2116 	mov	r4,a
      007D84 7D 00            [12] 2117 	mov	r5,#0x00
      007D86 8E 82            [24] 2118 	mov	dpl,r6
      007D88 8F 83            [24] 2119 	mov	dph,r7
      007D8A E0               [24] 2120 	movx	a,@dptr
      007D8B 22               [24] 2121 	ret
                                   2122 
                                   2123 	.area CSEG (CODE)
                                   2124 ; function ak820_outline_0039
      007D8C                       2125 _ak820_outline_0039:
      007D8C 90 08 61         [24] 2126 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007D8F E0               [24] 2127 	movx	a,@dptr
      007D90 54 1F            [12] 2128 	anl	a,#0x1f
      007D92 F5 82            [12] 2129 	mov	dpl,a
      007D94 22               [24] 2130 	ret
                                   2131 
                                   2132 	.area CSEG (CODE)
                                   2133 ; function ak820_outline_0050
      007D95                       2134 _ak820_outline_0050:
      007D95 A3               [24] 2135 	inc	dptr
      007D96 F0               [24] 2136 	movx	@dptr,a
      007D97 E4               [12] 2137 	clr	a
      007D98 A3               [24] 2138 	inc	dptr
      007D99 F0               [24] 2139 	movx	@dptr,a
      007D9A 90 0D AD         [24] 2140 	mov	dptr,#___memcpy_PARM_3
      007D9D 22               [24] 2141 	ret
                                   2142 
                                   2143 	.area CSEG (CODE)
                                   2144 ; function ak820_outline_0063
      007D9E                       2145 _ak820_outline_0063:
      007D9E F5 F0            [12] 2146 	mov	b,a
      007DA0 05 F0            [12] 2147 	inc	b
      007DA2 74 01            [12] 2148 	mov	a,#0x01
      007DA4 22               [24] 2149 	ret
                                   2150 
                                   2151 	.area CSEG (CODE)
                                   2152 ; function ak820_outline_0075
      007DA5                       2153 _ak820_outline_0075:
      007DA5 90 08 60         [24] 2154 	mov	dptr,#_process_action_PARM_2
      007DA8 E0               [24] 2155 	movx	a,@dptr
      007DA9 F5 82            [12] 2156 	mov	dpl,a
      007DAB 22               [24] 2157 	ret
                                   2158 
                                   2159 	.area CSEG (CODE)
                                   2160 ; function ak820_outline_0085
      007DAC                       2161 _ak820_outline_0085:
      007DAC 90 08 61         [24] 2162 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007DAF E0               [24] 2163 	movx	a,@dptr
      007DB0 03               [12] 2164 	rr	a
      007DB1 03               [12] 2165 	rr	a
      007DB2 54 03            [12] 2166 	anl	a,#0x03
      007DB4 22               [24] 2167 	ret
                                   2168 
                                   2169 	.area CSEG (CODE)
                                   2170 ; function ak820_outline_0107
      007DB5                       2171 _ak820_outline_0107:
      007DB5 74 06            [12] 2172 	mov	a,#0x06
      007DB7 F0               [24] 2173 	movx	@dptr,a
      007DB8 E4               [12] 2174 	clr	a
      007DB9 A3               [24] 2175 	inc	dptr
      007DBA F0               [24] 2176 	movx	@dptr,a
      007DBB 22               [24] 2177 	ret
                                   2178 
                                   2179 	.area CSEG (CODE)
                                   2180 ; function ak820_outline_0109
      007DBC                       2181 _ak820_outline_0109:
      007DBC 90 08 61         [24] 2182 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007DBF E0               [24] 2183 	movx	a,@dptr
      007DC0 54 0F            [12] 2184 	anl	a,#0x0f
      007DC2 22               [24] 2185 	ret
                                   2186 
                                   2187 	.area CSEG (CODE)
                                   2188 ; function ak820_outline_0129
      007DC3                       2189 _ak820_outline_0129:
      007DC3 90 08 60         [24] 2190 	mov	dptr,#_process_action_PARM_2
      007DC6 E0               [24] 2191 	movx	a,@dptr
      007DC7 FE               [12] 2192 	mov	r6,a
      007DC8 A3               [24] 2193 	inc	dptr
      007DC9 E0               [24] 2194 	movx	a,@dptr
      007DCA 54 03            [12] 2195 	anl	a,#0x03
      007DCC FF               [12] 2196 	mov	r7,a
      007DCD 22               [24] 2197 	ret
                                   2198 
                                   2199 	.area CSEG (CODE)
                                   2200 ; function ak820_outline_0138
      007DCE                       2201 _ak820_outline_0138:
      007DCE 90 08 65         [24] 2202 	mov	dptr,#_register_code_code_10000_720
      007DD1 E0               [24] 2203 	movx	a,@dptr
      007DD2 FF               [12] 2204 	mov	r7,a
      007DD3 22               [24] 2205 	ret
                                   2206 
                                   2207 	.area CSEG (CODE)
                                   2208 ; function ak820_outline_0139
      007DD4                       2209 _ak820_outline_0139:
      007DD4 90 08 66         [24] 2210 	mov	dptr,#_unregister_code_code_10000_734
      007DD7 E0               [24] 2211 	movx	a,@dptr
      007DD8 FF               [12] 2212 	mov	r7,a
      007DD9 22               [24] 2213 	ret
                                   2214 
                                   2215 	.area CSEG (CODE)
                                   2216 ; function ak820_outline_0147
      007DDA                       2217 _ak820_outline_0147:
      007DDA 90 08 60         [24] 2218 	mov	dptr,#_process_action_PARM_2
      007DDD E0               [24] 2219 	movx	a,@dptr
      007DDE 22               [24] 2220 	ret
                                   2221 
                                   2222 	.area CSEG (CODE)
                                   2223 ; function ak820_outline_0184
      007DDF                       2224 _ak820_outline_0184:
      007DDF E4               [12] 2225 	clr	a
      007DE0 F0               [24] 2226 	movx	@dptr,a
      007DE1 8F 82            [24] 2227 	mov	dpl,r7
      007DE3 22               [24] 2228 	ret
