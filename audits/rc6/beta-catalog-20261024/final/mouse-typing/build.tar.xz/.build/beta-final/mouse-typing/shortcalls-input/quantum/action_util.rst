                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action_util
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _host_consumer_send
                                     12 	.globl _host_system_send
                                     13 	.globl _host_keyboard_send
                                     14 	.globl _clear_keys_from_report
                                     15 	.globl _del_key_from_report
                                     16 	.globl _add_key_to_report
                                     17 	.globl _KEYCODE2CONSUMER
                                     18 	.globl _ADC_START
                                     19 	.globl _S0_R_FIFO
                                     20 	.globl _S0_T_FIFO
                                     21 	.globl _S0_FREE
                                     22 	.globl _S0_IF_BYTE
                                     23 	.globl _S0_IF_FIRST
                                     24 	.globl _S0_IF_OV
                                     25 	.globl _S0_FST_ACT
                                     26 	.globl _CP_RL2
                                     27 	.globl _C_T2
                                     28 	.globl _TR2
                                     29 	.globl _EXEN2
                                     30 	.globl _TCLK
                                     31 	.globl _RCLK
                                     32 	.globl _EXF2
                                     33 	.globl _CAP1F
                                     34 	.globl _TF2
                                     35 	.globl _RI
                                     36 	.globl _TI
                                     37 	.globl _RB8
                                     38 	.globl _TB8
                                     39 	.globl _REN
                                     40 	.globl _SM2
                                     41 	.globl _SM1
                                     42 	.globl _SM0
                                     43 	.globl _IT0
                                     44 	.globl _IE0
                                     45 	.globl _IT1
                                     46 	.globl _IE1
                                     47 	.globl _TR0
                                     48 	.globl _TF0
                                     49 	.globl _TR1
                                     50 	.globl _TF1
                                     51 	.globl _P4_0
                                     52 	.globl _P4_1
                                     53 	.globl _P4_2
                                     54 	.globl _P4_3
                                     55 	.globl _P4_4
                                     56 	.globl _P4_5
                                     57 	.globl _P4_6
                                     58 	.globl _RXD
                                     59 	.globl _TXD
                                     60 	.globl _INT0
                                     61 	.globl _INT1
                                     62 	.globl _T0
                                     63 	.globl _T1
                                     64 	.globl _MOSI1
                                     65 	.globl _MISO1
                                     66 	.globl _SCK1
                                     67 	.globl _P3_0
                                     68 	.globl _P3_1
                                     69 	.globl _P3_2
                                     70 	.globl _P3_3
                                     71 	.globl _P3_4
                                     72 	.globl _P3_5
                                     73 	.globl _P3_6
                                     74 	.globl _P3_7
                                     75 	.globl _CAP1_
                                     76 	.globl _T2_
                                     77 	.globl _CAP2_
                                     78 	.globl _T2EX_
                                     79 	.globl _RXD1
                                     80 	.globl _TXD1
                                     81 	.globl _P2_0
                                     82 	.globl _P2_1
                                     83 	.globl _P2_2
                                     84 	.globl _P2_3
                                     85 	.globl _P2_4
                                     86 	.globl _P2_5
                                     87 	.globl _P2_6
                                     88 	.globl _P2_7
                                     89 	.globl _AIN0
                                     90 	.globl _AIN1
                                     91 	.globl _AIN2
                                     92 	.globl _AIN3
                                     93 	.globl _AIN4
                                     94 	.globl _AIN5
                                     95 	.globl _AIN6
                                     96 	.globl _AIN7
                                     97 	.globl _CAP1
                                     98 	.globl _T2
                                     99 	.globl _CAP2
                                    100 	.globl _T2EX
                                    101 	.globl _INT0_
                                    102 	.globl _SCS
                                    103 	.globl _MOSI
                                    104 	.globl _MISO
                                    105 	.globl _SCK
                                    106 	.globl _RXD1_
                                    107 	.globl _TXD1_
                                    108 	.globl _P1_0
                                    109 	.globl _P1_1
                                    110 	.globl _P1_2
                                    111 	.globl _P1_3
                                    112 	.globl _P1_4
                                    113 	.globl _P1_5
                                    114 	.globl _P1_6
                                    115 	.globl _P1_7
                                    116 	.globl _AIN8
                                    117 	.globl _AIN9
                                    118 	.globl _AIN10
                                    119 	.globl _AIN11
                                    120 	.globl _AIN12
                                    121 	.globl _AIN13
                                    122 	.globl _RXD_
                                    123 	.globl _TXD_
                                    124 	.globl _SCL0
                                    125 	.globl _SDA0
                                    126 	.globl _P0_0
                                    127 	.globl _P0_1
                                    128 	.globl _P0_2
                                    129 	.globl _P0_3
                                    130 	.globl _P0_4
                                    131 	.globl _P0_5
                                    132 	.globl _P0_6
                                    133 	.globl _P0_7
                                    134 	.globl _IE_SPI0
                                    135 	.globl _IE_USB
                                    136 	.globl _IE_ADC
                                    137 	.globl _IE_UART1
                                    138 	.globl _IE_PWM_I2C
                                    139 	.globl _IE_GPIO
                                    140 	.globl _IE_WDOG
                                    141 	.globl _PX0
                                    142 	.globl _PT0
                                    143 	.globl _PX1
                                    144 	.globl _PT1
                                    145 	.globl _PS
                                    146 	.globl _PT2
                                    147 	.globl _PL_FLAG
                                    148 	.globl _PH_FLAG
                                    149 	.globl _EX0
                                    150 	.globl _ET0
                                    151 	.globl _EX1
                                    152 	.globl _ET1
                                    153 	.globl _ES
                                    154 	.globl _ET2
                                    155 	.globl _E_DIS
                                    156 	.globl _EA
                                    157 	.globl _P
                                    158 	.globl _F1
                                    159 	.globl _OV
                                    160 	.globl _RS0
                                    161 	.globl _RS1
                                    162 	.globl _F0
                                    163 	.globl _AC
                                    164 	.globl _CY
                                    165 	.globl _I2CS_INT_ST
                                    166 	.globl _I2CX_INT
                                    167 	.globl _LED_STATUS
                                    168 	.globl _LED_DMA_H
                                    169 	.globl _LED_DMA_L
                                    170 	.globl _LED_DMA
                                    171 	.globl _LED_PWM_OE
                                    172 	.globl _LED_COMMON
                                    173 	.globl _ADC_CHAN
                                    174 	.globl _ADC_DAT_H
                                    175 	.globl _ADC_DAT_L
                                    176 	.globl _ADC_DAT
                                    177 	.globl _ADC_CTRL
                                    178 	.globl _SPI1_CK_SE
                                    179 	.globl _SPI1_CTRL
                                    180 	.globl _SPI1_DATA
                                    181 	.globl _SPI1_STAT
                                    182 	.globl _SIF1
                                    183 	.globl _SBAUD1
                                    184 	.globl _SBUF1
                                    185 	.globl _SCON1
                                    186 	.globl _SPI0_SETUP
                                    187 	.globl _SPI0_CK_SE
                                    188 	.globl _SPI0_CTRL
                                    189 	.globl _SPI0_DATA
                                    190 	.globl _SPI0_STAT
                                    191 	.globl _T2CAP1H
                                    192 	.globl _T2CAP1L
                                    193 	.globl _T2CAP1
                                    194 	.globl _TH2
                                    195 	.globl _TL2
                                    196 	.globl _T2COUNT
                                    197 	.globl _RCAP2H
                                    198 	.globl _RCAP2L
                                    199 	.globl _RCAP2
                                    200 	.globl _T2MOD
                                    201 	.globl _T2CON
                                    202 	.globl _SBUF
                                    203 	.globl _SCON
                                    204 	.globl _TH1
                                    205 	.globl _TH0
                                    206 	.globl _TL1
                                    207 	.globl _TL0
                                    208 	.globl _TMOD
                                    209 	.globl _TCON
                                    210 	.globl _XBUS_AUX
                                    211 	.globl _P7
                                    212 	.globl _P6_DIR
                                    213 	.globl _P6_OUT_PU
                                    214 	.globl _P6_IN
                                    215 	.globl _P5_DIR
                                    216 	.globl _P5_OUT_PU
                                    217 	.globl _P5_IN
                                    218 	.globl _P4_LED_KEY
                                    219 	.globl _P4_DIR_PU
                                    220 	.globl _P4_MOD_OC
                                    221 	.globl _P4
                                    222 	.globl _P3_DIR_PU
                                    223 	.globl _P3_MOD_OC
                                    224 	.globl _P3
                                    225 	.globl _P2_DIR_PU
                                    226 	.globl _P2_MOD_OC
                                    227 	.globl _P2
                                    228 	.globl _P1_DIR_PU
                                    229 	.globl _P1_MOD_OC
                                    230 	.globl _P1
                                    231 	.globl _P0_DIR_PU
                                    232 	.globl _P0_MOD_OC
                                    233 	.globl _P0
                                    234 	.globl _ROM_CTRL
                                    235 	.globl _ROM_DATA_HH
                                    236 	.globl _ROM_DATA_HL
                                    237 	.globl _ROM_DATA_HI
                                    238 	.globl _ROM_ADDR_H
                                    239 	.globl _ROM_ADDR_L
                                    240 	.globl _ROM_ADDR
                                    241 	.globl _GPIO_IE
                                    242 	.globl _IP_EX
                                    243 	.globl _IE_EX
                                    244 	.globl _IP
                                    245 	.globl _IE
                                    246 	.globl _WDOG_COUNT
                                    247 	.globl _RESET_KEEP
                                    248 	.globl _WAKE_CTRL
                                    249 	.globl _CLOCK_CFG
                                    250 	.globl _POWER_CFG
                                    251 	.globl _PCON
                                    252 	.globl _GLOBAL_CFG
                                    253 	.globl _SAFE_MOD
                                    254 	.globl _DPH
                                    255 	.globl _DPL
                                    256 	.globl _SP
                                    257 	.globl _A_INV
                                    258 	.globl _B
                                    259 	.globl _ACC
                                    260 	.globl _PSW
                                    261 	.globl _actual_keyboard_report
                                    262 	.globl _owned_usage_key_PARM_2
                                    263 	.globl _ak820_macro_change_PARM_3
                                    264 	.globl _ak820_macro_change_PARM_2
                                    265 	.globl _ak820_macro_cancelled
                                    266 	.globl _ak820_macro_primitive
                                    267 	.globl _ak820_gui_process_PARM_2
                                    268 	.globl _ak820_gui_process
                                    269 	.globl _ak820_macro_change
                                    270 	.globl _add_owned_mods
                                    271 	.globl _del_owned_mods
                                    272 	.globl _add_owned_weak_mods
                                    273 	.globl _del_owned_weak_mods
                                    274 	.globl _clear_owned_mods
                                    275 	.globl _clear_owned_keys
                                    276 	.globl _add_owned_key
                                    277 	.globl _del_owned_key
                                    278 	.globl _clear_owned_usages
                                    279 	.globl _owned_usage_key
                                    280 	.globl _send_keyboard_report
                                    281 	.globl _get_mods
                                    282 	.globl _clear_mods
                                    283 	.globl _get_weak_mods
                                    284 	.globl _add_weak_mods
                                    285 	.globl _del_weak_mods
                                    286 	.globl _clear_weak_mods
                                    287 ;--------------------------------------------------------
                                    288 ; special function registers
                                    289 ;--------------------------------------------------------
                                    290 	.area RSEG    (ABS,DATA)
      000000                        291 	.org 0x0000
                           0000D0   292 _PSW	=	0x00d0
                           0000E0   293 _ACC	=	0x00e0
                           0000F0   294 _B	=	0x00f0
                           0000FD   295 _A_INV	=	0x00fd
                           000081   296 _SP	=	0x0081
                           000082   297 _DPL	=	0x0082
                           000083   298 _DPH	=	0x0083
                           0000A1   299 _SAFE_MOD	=	0x00a1
                           0000B1   300 _GLOBAL_CFG	=	0x00b1
                           000087   301 _PCON	=	0x0087
                           0000BA   302 _POWER_CFG	=	0x00ba
                           0000B9   303 _CLOCK_CFG	=	0x00b9
                           0000A9   304 _WAKE_CTRL	=	0x00a9
                           0000FE   305 _RESET_KEEP	=	0x00fe
                           0000FF   306 _WDOG_COUNT	=	0x00ff
                           0000A8   307 _IE	=	0x00a8
                           0000B8   308 _IP	=	0x00b8
                           0000E8   309 _IE_EX	=	0x00e8
                           0000E9   310 _IP_EX	=	0x00e9
                           0000B2   311 _GPIO_IE	=	0x00b2
                           008584   312 _ROM_ADDR	=	0x8584
                           000084   313 _ROM_ADDR_L	=	0x0084
                           000085   314 _ROM_ADDR_H	=	0x0085
                           008F8E   315 _ROM_DATA_HI	=	0x8f8e
                           00008E   316 _ROM_DATA_HL	=	0x008e
                           00008F   317 _ROM_DATA_HH	=	0x008f
                           000086   318 _ROM_CTRL	=	0x0086
                           000080   319 _P0	=	0x0080
                           0000C4   320 _P0_MOD_OC	=	0x00c4
                           0000C5   321 _P0_DIR_PU	=	0x00c5
                           000090   322 _P1	=	0x0090
                           000092   323 _P1_MOD_OC	=	0x0092
                           000093   324 _P1_DIR_PU	=	0x0093
                           0000A0   325 _P2	=	0x00a0
                           000094   326 _P2_MOD_OC	=	0x0094
                           000095   327 _P2_DIR_PU	=	0x0095
                           0000B0   328 _P3	=	0x00b0
                           000096   329 _P3_MOD_OC	=	0x0096
                           000097   330 _P3_DIR_PU	=	0x0097
                           0000C0   331 _P4	=	0x00c0
                           0000C2   332 _P4_MOD_OC	=	0x00c2
                           0000C3   333 _P4_DIR_PU	=	0x00c3
                           0000C1   334 _P4_LED_KEY	=	0x00c1
                           0000AA   335 _P5_IN	=	0x00aa
                           0000AB   336 _P5_OUT_PU	=	0x00ab
                           0000AC   337 _P5_DIR	=	0x00ac
                           0000AD   338 _P6_IN	=	0x00ad
                           0000AE   339 _P6_OUT_PU	=	0x00ae
                           0000AF   340 _P6_DIR	=	0x00af
                           0000F1   341 _P7	=	0x00f1
                           0000A2   342 _XBUS_AUX	=	0x00a2
                           000088   343 _TCON	=	0x0088
                           000089   344 _TMOD	=	0x0089
                           00008A   345 _TL0	=	0x008a
                           00008B   346 _TL1	=	0x008b
                           00008C   347 _TH0	=	0x008c
                           00008D   348 _TH1	=	0x008d
                           000098   349 _SCON	=	0x0098
                           000099   350 _SBUF	=	0x0099
                           0000C8   351 _T2CON	=	0x00c8
                           0000C9   352 _T2MOD	=	0x00c9
                           00CBCA   353 _RCAP2	=	0xcbca
                           0000CA   354 _RCAP2L	=	0x00ca
                           0000CB   355 _RCAP2H	=	0x00cb
                           00CDCC   356 _T2COUNT	=	0xcdcc
                           0000CC   357 _TL2	=	0x00cc
                           0000CD   358 _TH2	=	0x00cd
                           00CFCE   359 _T2CAP1	=	0xcfce
                           0000CE   360 _T2CAP1L	=	0x00ce
                           0000CF   361 _T2CAP1H	=	0x00cf
                           0000F8   362 _SPI0_STAT	=	0x00f8
                           0000F9   363 _SPI0_DATA	=	0x00f9
                           0000FA   364 _SPI0_CTRL	=	0x00fa
                           0000FB   365 _SPI0_CK_SE	=	0x00fb
                           0000FC   366 _SPI0_SETUP	=	0x00fc
                           0000BC   367 _SCON1	=	0x00bc
                           0000BD   368 _SBUF1	=	0x00bd
                           0000BE   369 _SBAUD1	=	0x00be
                           0000BF   370 _SIF1	=	0x00bf
                           0000B4   371 _SPI1_STAT	=	0x00b4
                           0000B5   372 _SPI1_DATA	=	0x00b5
                           0000B6   373 _SPI1_CTRL	=	0x00b6
                           0000B7   374 _SPI1_CK_SE	=	0x00b7
                           0000F3   375 _ADC_CTRL	=	0x00f3
                           00F5F4   376 _ADC_DAT	=	0xf5f4
                           0000F4   377 _ADC_DAT_L	=	0x00f4
                           0000F5   378 _ADC_DAT_H	=	0x00f5
                           0000F6   379 _ADC_CHAN	=	0x00f6
                           0000A6   380 _LED_COMMON	=	0x00a6
                           0000A7   381 _LED_PWM_OE	=	0x00a7
                           00C7C6   382 _LED_DMA	=	0xc7c6
                           0000C6   383 _LED_DMA_L	=	0x00c6
                           0000C7   384 _LED_DMA_H	=	0x00c7
                           0000F7   385 _LED_STATUS	=	0x00f7
                           0000B3   386 _I2CX_INT	=	0x00b3
                           0000BB   387 _I2CS_INT_ST	=	0x00bb
                                    388 ;--------------------------------------------------------
                                    389 ; special function bits
                                    390 ;--------------------------------------------------------
                                    391 	.area RSEG    (ABS,DATA)
      000000                        392 	.org 0x0000
                           0000D7   393 _CY	=	0x00d7
                           0000D6   394 _AC	=	0x00d6
                           0000D5   395 _F0	=	0x00d5
                           0000D4   396 _RS1	=	0x00d4
                           0000D3   397 _RS0	=	0x00d3
                           0000D2   398 _OV	=	0x00d2
                           0000D1   399 _F1	=	0x00d1
                           0000D0   400 _P	=	0x00d0
                           0000AF   401 _EA	=	0x00af
                           0000AE   402 _E_DIS	=	0x00ae
                           0000AD   403 _ET2	=	0x00ad
                           0000AC   404 _ES	=	0x00ac
                           0000AB   405 _ET1	=	0x00ab
                           0000AA   406 _EX1	=	0x00aa
                           0000A9   407 _ET0	=	0x00a9
                           0000A8   408 _EX0	=	0x00a8
                           0000BF   409 _PH_FLAG	=	0x00bf
                           0000BE   410 _PL_FLAG	=	0x00be
                           0000BD   411 _PT2	=	0x00bd
                           0000BC   412 _PS	=	0x00bc
                           0000BB   413 _PT1	=	0x00bb
                           0000BA   414 _PX1	=	0x00ba
                           0000B9   415 _PT0	=	0x00b9
                           0000B8   416 _PX0	=	0x00b8
                           0000EF   417 _IE_WDOG	=	0x00ef
                           0000EE   418 _IE_GPIO	=	0x00ee
                           0000ED   419 _IE_PWM_I2C	=	0x00ed
                           0000EC   420 _IE_UART1	=	0x00ec
                           0000EB   421 _IE_ADC	=	0x00eb
                           0000E9   422 _IE_USB	=	0x00e9
                           0000E8   423 _IE_SPI0	=	0x00e8
                           000087   424 _P0_7	=	0x0087
                           000086   425 _P0_6	=	0x0086
                           000085   426 _P0_5	=	0x0085
                           000084   427 _P0_4	=	0x0084
                           000083   428 _P0_3	=	0x0083
                           000082   429 _P0_2	=	0x0082
                           000081   430 _P0_1	=	0x0081
                           000080   431 _P0_0	=	0x0080
                           000081   432 _SDA0	=	0x0081
                           000080   433 _SCL0	=	0x0080
                           000083   434 _TXD_	=	0x0083
                           000082   435 _RXD_	=	0x0082
                           000085   436 _AIN13	=	0x0085
                           000084   437 _AIN12	=	0x0084
                           000083   438 _AIN11	=	0x0083
                           000082   439 _AIN10	=	0x0082
                           000081   440 _AIN9	=	0x0081
                           000080   441 _AIN8	=	0x0080
                           000097   442 _P1_7	=	0x0097
                           000096   443 _P1_6	=	0x0096
                           000095   444 _P1_5	=	0x0095
                           000094   445 _P1_4	=	0x0094
                           000093   446 _P1_3	=	0x0093
                           000092   447 _P1_2	=	0x0092
                           000091   448 _P1_1	=	0x0091
                           000090   449 _P1_0	=	0x0090
                           000097   450 _TXD1_	=	0x0097
                           000096   451 _RXD1_	=	0x0096
                           000097   452 _SCK	=	0x0097
                           000096   453 _MISO	=	0x0096
                           000095   454 _MOSI	=	0x0095
                           000094   455 _SCS	=	0x0094
                           000092   456 _INT0_	=	0x0092
                           000091   457 _T2EX	=	0x0091
                           000091   458 _CAP2	=	0x0091
                           000090   459 _T2	=	0x0090
                           000090   460 _CAP1	=	0x0090
                           000097   461 _AIN7	=	0x0097
                           000096   462 _AIN6	=	0x0096
                           000095   463 _AIN5	=	0x0095
                           000094   464 _AIN4	=	0x0094
                           000093   465 _AIN3	=	0x0093
                           000092   466 _AIN2	=	0x0092
                           000091   467 _AIN1	=	0x0091
                           000090   468 _AIN0	=	0x0090
                           0000A7   469 _P2_7	=	0x00a7
                           0000A6   470 _P2_6	=	0x00a6
                           0000A5   471 _P2_5	=	0x00a5
                           0000A4   472 _P2_4	=	0x00a4
                           0000A3   473 _P2_3	=	0x00a3
                           0000A2   474 _P2_2	=	0x00a2
                           0000A1   475 _P2_1	=	0x00a1
                           0000A0   476 _P2_0	=	0x00a0
                           0000A7   477 _TXD1	=	0x00a7
                           0000A6   478 _RXD1	=	0x00a6
                           0000A5   479 _T2EX_	=	0x00a5
                           0000A5   480 _CAP2_	=	0x00a5
                           0000A4   481 _T2_	=	0x00a4
                           0000A4   482 _CAP1_	=	0x00a4
                           0000B7   483 _P3_7	=	0x00b7
                           0000B6   484 _P3_6	=	0x00b6
                           0000B5   485 _P3_5	=	0x00b5
                           0000B4   486 _P3_4	=	0x00b4
                           0000B3   487 _P3_3	=	0x00b3
                           0000B2   488 _P3_2	=	0x00b2
                           0000B1   489 _P3_1	=	0x00b1
                           0000B0   490 _P3_0	=	0x00b0
                           0000B7   491 _SCK1	=	0x00b7
                           0000B6   492 _MISO1	=	0x00b6
                           0000B5   493 _MOSI1	=	0x00b5
                           0000B5   494 _T1	=	0x00b5
                           0000B4   495 _T0	=	0x00b4
                           0000B3   496 _INT1	=	0x00b3
                           0000B2   497 _INT0	=	0x00b2
                           0000B1   498 _TXD	=	0x00b1
                           0000B0   499 _RXD	=	0x00b0
                           0000C6   500 _P4_6	=	0x00c6
                           0000C5   501 _P4_5	=	0x00c5
                           0000C4   502 _P4_4	=	0x00c4
                           0000C3   503 _P4_3	=	0x00c3
                           0000C2   504 _P4_2	=	0x00c2
                           0000C1   505 _P4_1	=	0x00c1
                           0000C0   506 _P4_0	=	0x00c0
                           00008F   507 _TF1	=	0x008f
                           00008E   508 _TR1	=	0x008e
                           00008D   509 _TF0	=	0x008d
                           00008C   510 _TR0	=	0x008c
                           00008B   511 _IE1	=	0x008b
                           00008A   512 _IT1	=	0x008a
                           000089   513 _IE0	=	0x0089
                           000088   514 _IT0	=	0x0088
                           00009F   515 _SM0	=	0x009f
                           00009E   516 _SM1	=	0x009e
                           00009D   517 _SM2	=	0x009d
                           00009C   518 _REN	=	0x009c
                           00009B   519 _TB8	=	0x009b
                           00009A   520 _RB8	=	0x009a
                           000099   521 _TI	=	0x0099
                           000098   522 _RI	=	0x0098
                           0000CF   523 _TF2	=	0x00cf
                           0000CF   524 _CAP1F	=	0x00cf
                           0000CE   525 _EXF2	=	0x00ce
                           0000CD   526 _RCLK	=	0x00cd
                           0000CC   527 _TCLK	=	0x00cc
                           0000CB   528 _EXEN2	=	0x00cb
                           0000CA   529 _TR2	=	0x00ca
                           0000C9   530 _C_T2	=	0x00c9
                           0000C8   531 _CP_RL2	=	0x00c8
                           0000FF   532 _S0_FST_ACT	=	0x00ff
                           0000FE   533 _S0_IF_OV	=	0x00fe
                           0000FD   534 _S0_IF_FIRST	=	0x00fd
                           0000FC   535 _S0_IF_BYTE	=	0x00fc
                           0000FB   536 _S0_FREE	=	0x00fb
                           0000FA   537 _S0_T_FIFO	=	0x00fa
                           0000F8   538 _S0_R_FIFO	=	0x00f8
                           0000F7   539 _ADC_START	=	0x00f7
                                    540 ;--------------------------------------------------------
                                    541 ; overlayable register banks
                                    542 ;--------------------------------------------------------
                                    543 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        544 	.ds 8
                                    545 ;--------------------------------------------------------
                                    546 ; internal ram data
                                    547 ;--------------------------------------------------------
                                    548 	.area DSEG    (DATA)
                                    549 ;--------------------------------------------------------
                                    550 ; overlayable items in internal ram
                                    551 ;--------------------------------------------------------
                                    552 	.area	OSEG    (OVR,DATA)
      000054                        553 _change_owned_sloc1_1_0:
      000054                        554 	.ds 1
                                    555 ;--------------------------------------------------------
                                    556 ; indirectly addressable internal ram data
                                    557 ;--------------------------------------------------------
                                    558 	.area ISEG    (DATA)
                                    559 ;--------------------------------------------------------
                                    560 ; absolute internal ram data
                                    561 ;--------------------------------------------------------
                                    562 	.area IABS    (ABS,DATA)
                                    563 	.area IABS    (ABS,DATA)
                                    564 ;--------------------------------------------------------
                                    565 ; bit data
                                    566 ;--------------------------------------------------------
                                    567 	.area BSEG    (BIT)
      00001F                        568 _gui_disabled:
      00001F                        569 	.ds 1
      000020                        570 _ak820_gui_process_sloc0_1_0:
      000020                        571 	.ds 1
      000021                        572 _ak820_macro_change_sloc0_1_0:
      000021                        573 	.ds 1
      000022                        574 _change_owned_sloc0_1_0:
      000022                        575 	.ds 1
      000023                        576 _owned_usage_key_sloc0_1_0:
      000023                        577 	.ds 1
                                    578 ;--------------------------------------------------------
                                    579 ; paged external ram data
                                    580 ;--------------------------------------------------------
                                    581 	.area PSEG    (PAG,XDATA)
                                    582 ;--------------------------------------------------------
                                    583 ; uninitialized external ram data
                                    584 ;--------------------------------------------------------
                                    585 	.area XSEG    (XDATA)
      00099F                        586 _ak820_gui_process_PARM_2:
      00099F                        587 	.ds 1
      0009A0                        588 _ak820_gui_process_code_10000_295:
      0009A0                        589 	.ds 2
      0009A2                        590 _owned_mod_refs:
      0009A2                        591 	.ds 8
      0009AA                        592 _owned_weak_refs:
      0009AA                        593 	.ds 8
      0009B2                        594 _owned_mods:
      0009B2                        595 	.ds 1
      0009B3                        596 _owned_weak_mods:
      0009B3                        597 	.ds 1
      0009B4                        598 _macro_mods:
      0009B4                        599 	.ds 2
      0009B6                        600 _ak820_macro_primitive::
      0009B6                        601 	.ds 1
      0009B7                        602 _ak820_macro_cancelled::
      0009B7                        603 	.ds 1
      0009B8                        604 _ak820_macro_change_PARM_2:
      0009B8                        605 	.ds 1
      0009B9                        606 _ak820_macro_change_PARM_3:
      0009B9                        607 	.ds 1
      0009BA                        608 _ak820_macro_change_bits_10000_300:
      0009BA                        609 	.ds 2
      0009BC                        610 _change_owned_PARM_2:
      0009BC                        611 	.ds 1
      0009BD                        612 _change_owned_mods_10000_305:
      0009BD                        613 	.ds 1
      0009BE                        614 _change_owned_result_10001_309:
      0009BE                        615 	.ds 1
      0009BF                        616 _change_owned_bit_20001_310:
      0009BF                        617 	.ds 1
      0009C0                        618 _add_owned_mods_mods_10000_318:
      0009C0                        619 	.ds 1
      0009C1                        620 _del_owned_mods_mods_10000_320:
      0009C1                        621 	.ds 1
      0009C2                        622 _add_owned_weak_mods_mods_10000_322:
      0009C2                        623 	.ds 1
      0009C3                        624 _del_owned_weak_mods_mods_10000_324:
      0009C3                        625 	.ds 1
      0009C4                        626 _key_refs:
      0009C4                        627 	.ds 165
      000A69                        628 _distinct_keys:
      000A69                        629 	.ds 1
      000A6A                        630 _macro_keys:
      000A6A                        631 	.ds 21
      000A7F                        632 _add_owned_key_code_10000_333:
      000A7F                        633 	.ds 1
      000A80                        634 _del_owned_key_code_10000_348:
      000A80                        635 	.ds 1
      000A81                        636 _usage_refs:
      000A81                        637 	.ds 30
      000A9F                        638 _usage_order:
      000A9F                        639 	.ds 30
      000ABD                        640 _usage_lengths:
      000ABD                        641 	.ds 2
      000ABF                        642 _macro_usages:
      000ABF                        643 	.ds 4
      000AC3                        644 _owned_usage_key_PARM_2:
      000AC3                        645 	.ds 1
      000AC4                        646 _owned_usage_key_code_10000_375:
      000AC4                        647 	.ds 1
      000AC5                        648 _owned_usage_key___200000085_20000_376:
      000AC5                        649 	.ds 2
      000AC7                        650 _owned_usage_key_which_10000_376:
      000AC7                        651 	.ds 1
      000AC8                        652 _owned_usage_key_count_10000_376:
      000AC8                        653 	.ds 1
      000AC9                        654 _owned_usage_key_pos_30001_383:
      000AC9                        655 	.ds 1
      000ACA                        656 _owned_usage_key_key_40000_388:
      000ACA                        657 	.ds 1
      000ACB                        658 _send_keyboard_report_last_report_10001_396:
      000ACB                        659 	.ds 32
      000AEB                        660 _send_keyboard_report_changed_10001_396:
      000AEB                        661 	.ds 1
      000AEC                        662 _add_weak_mods_mods_10000_414:
      000AEC                        663 	.ds 1
      000AED                        664 _del_weak_mods_mods_10000_416:
      000AED                        665 	.ds 1
                                    666 ;--------------------------------------------------------
                                    667 ; absolute external ram data
                                    668 ;--------------------------------------------------------
                                    669 	.area XABS    (ABS,XDATA)
                                    670 ;--------------------------------------------------------
                                    671 ; initialized external ram data
                                    672 ;--------------------------------------------------------
                                    673 	.area XISEG   (XDATA)
      000DCE                        674 _real_mods:
      000DCE                        675 	.ds 1
      000DCF                        676 _weak_mods:
      000DCF                        677 	.ds 1
      000DD0                        678 _actual_keyboard_report::
      000DD0                        679 	.ds 32
                                    680 	.area HOME    (CODE)
                                    681 	.area GSINIT0 (CODE)
                                    682 	.area GSINIT1 (CODE)
                                    683 	.area GSINIT2 (CODE)
                                    684 	.area GSINIT3 (CODE)
                                    685 	.area GSINIT4 (CODE)
                                    686 	.area GSINIT5 (CODE)
                                    687 	.area GSINIT  (CODE)
                                    688 	.area GSFINAL (CODE)
                                    689 	.area CSEG    (CODE)
                                    690 ;--------------------------------------------------------
                                    691 ; global & static initialisations
                                    692 ;--------------------------------------------------------
                                    693 	.area HOME    (CODE)
                                    694 	.area GSINIT  (CODE)
                                    695 	.area GSFINAL (CODE)
                                    696 	.area GSINIT  (CODE)
                                    697 ;--------------------------------------------------------
                                    698 ; Home
                                    699 ;--------------------------------------------------------
                                    700 	.area HOME    (CODE)
                                    701 	.area HOME    (CODE)
                                    702 ;--------------------------------------------------------
                                    703 ; code
                                    704 ;--------------------------------------------------------
                                    705 	.area CSEG    (CODE)
                                    706 ;------------------------------------------------------------
                                    707 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    708 ;------------------------------------------------------------
                                    709 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    710 ;------------------------------------------------------------
                                    711 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    712 ;	-----------------------------------------
                           000007   713 	ar7 = 0x07
                           000006   714 	ar6 = 0x06
                           000005   715 	ar5 = 0x05
                           000004   716 	ar4 = 0x04
                           000003   717 	ar3 = 0x03
                           000002   718 	ar2 = 0x02
                           000001   719 	ar1 = 0x01
                           000000   720 	ar0 = 0x00
                                    721 ;	 function ak820_gui_process
                                    722 ;	-----------------------------------------
      0081FE                        723 _ak820_gui_process:
      0081FE 12 3A 89         [24]  724 	lcall	_ak820_outline_0103
      008201 90 09 A0         [24]  725 	mov	dptr,#_ak820_gui_process_code_10000_295
      008204 12 3A 8E         [24]  726 	lcall	_ak820_outline_0104
                                    727 ;	quantum/action_util.c:80: if (code < QK_MAGIC_GUI_ON || code > QK_MAGIC_TOGGLE_GUI) return true;
      008207 90 09 A0         [24]  728 	mov	dptr,#_ak820_gui_process_code_10000_295
      00820A 12 3A 46         [24]  729 	lcall	_ak820_outline_0051
      00820D C3               [12]  730 	clr	c
      00820E EE               [12]  731 	mov	a,r6
      00820F 94 09            [12]  732 	subb	a,#0x09
      008211 EF               [12]  733 	mov	a,r7
      008212 94 70            [12]  734 	subb	a,#0x70
      008214 40 08            [24]  735 	jc	00101$
      008216 74 0B            [12]  736 	mov	a,#0x0b
      008218 9E               [12]  737 	subb	a,r6
      008219 74 70            [12]  738 	mov	a,#0x70
      00821B 9F               [12]  739 	subb	a,r7
      00821C 50 04            [24]  740 	jnc	00102$
                                    741 ;	free result
      00821E                        742 00101$:
      00821E 75 82 01         [24]  743 	mov	dpl, #0x01
      008221 22               [24]  744 	ret
      008222                        745 00102$:
                                    746 ;	quantum/action_util.c:81: if (pressed) {
      008222 90 09 9F         [24]  747 	mov	dptr,#_ak820_gui_process_PARM_2
      008225 E0               [24]  748 	movx	a,@dptr
      008226 60 21            [24]  749 	jz	00105$
                                    750 ;	quantum/action_util.c:82: gui_disabled = code == QK_MAGIC_TOGGLE_GUI ? !gui_disabled : code == QK_MAGIC_GUI_OFF;
      008228 BE 0B 0D         [24]  751 	cjne	r6,#0x0b,00108$
      00822B BF 70 0A         [24]  752 	cjne	r7,#0x70,00108$
      00822E A2 1F            [12]  753 	mov	c,_gui_disabled
      008230 B3               [12]  754 	cpl	c
      008231 92 20            [24]  755 	mov  _ak820_gui_process_sloc0_1_0,c
      008233 E4               [12]  756 	clr	a
      008234 33               [12]  757 	rlc	a
      008235 FD               [12]  758 	mov	r5,a
      008236 80 09            [24]  759 	sjmp	00109$
      008238                        760 00108$:
      008238 E4               [12]  761 	clr	a
      008239 BE 0A 04         [24]  762 	cjne	r6,#0x0a,00136$
      00823C BF 70 01         [24]  763 	cjne	r7,#0x70,00136$
      00823F 04               [12]  764 	inc	a
      008240                        765 00136$:
      008240 FD               [12]  766 	mov	r5,a
      008241                        767 00109$:
                                    768 ;	assignBit
      008241 ED               [12]  769 	mov	a,r5
      008242 24 FF            [12]  770 	add	a,#0xff
      008244 92 1F            [24]  771 	mov	_gui_disabled,c
                                    772 ;	quantum/action_util.c:83: send_keyboard_report();
      008246 12 86 C4         [24]  773 	lcall	_send_keyboard_report
      008249                        774 00105$:
                                    775 ;	quantum/action_util.c:85: return false;
      008249 75 82 00         [24]  776 	mov	dpl, #0x00
                                    777 ;	quantum/action_util.c:89: }
      00824C 22               [24]  778 	ret
                                    779 ;------------------------------------------------------------
                                    780 ;Allocation info for local variables in function 'ak820_macro_change'
                                    781 ;------------------------------------------------------------
                                    782 ;index         Allocated with name '_ak820_macro_change_PARM_2'
                                    783 ;pressed       Allocated with name '_ak820_macro_change_PARM_3'
                                    784 ;bits          Allocated with name '_ak820_macro_change_bits_10000_300'
                                    785 ;mask          Allocated with name '_ak820_macro_change_mask_10001_303'
                                    786 ;------------------------------------------------------------
                                    787 ;	quantum/action_util.c:98: bool ak820_macro_change(uint8_t AK820_STATE_MEM *bits, uint8_t index, bool pressed) {
                                    788 ;	-----------------------------------------
                                    789 ;	 function ak820_macro_change
                                    790 ;	-----------------------------------------
      00824D                        791 _ak820_macro_change:
      00824D 12 3A 89         [24]  792 	lcall	_ak820_outline_0103
      008250 90 09 BA         [24]  793 	mov	dptr,#_ak820_macro_change_bits_10000_300
      008253 12 3A 8E         [24]  794 	lcall	_ak820_outline_0104
                                    795 ;	quantum/action_util.c:99: if (!ak820_macro_primitive) return true;
      008256 90 09 B6         [24]  796 	mov	dptr,#_ak820_macro_primitive
      008259 E0               [24]  797 	movx	a,@dptr
      00825A 70 04            [24]  798 	jnz	00102$
      00825C 75 82 01         [24]  799 	mov	dpl, #0x01
      00825F 22               [24]  800 	ret
      008260                        801 00102$:
                                    802 ;	quantum/action_util.c:100: uint8_t mask = 1u << (index & 7);
      008260 90 09 B8         [24]  803 	mov	dptr,#_ak820_macro_change_PARM_2
      008263 E0               [24]  804 	movx	a,@dptr
      008264 FF               [12]  805 	mov	r7,a
      008265 74 07            [12]  806 	mov	a,#0x07
      008267 5F               [12]  807 	anl	a,r7
      008268 12 7D 9E         [24]  808 	lcall	_ak820_outline_0063
      00826B 80 02            [24]  809 	sjmp	00123$
      00826D                        810 00122$:
      00826D 25 E0            [12]  811 	add	a,acc
      00826F                        812 00123$:
      00826F D5 F0 FB         [24]  813 	djnz	b,00122$
      008272 FE               [12]  814 	mov	r6,a
                                    815 ;	quantum/action_util.c:101: bits += index >> 3;
      008273 EF               [12]  816 	mov	a,r7
      008274 12 5C F8         [24]  817 	lcall	_ak820_outline_0183
      008277 FF               [12]  818 	mov	r7,a
      008278 90 09 BA         [24]  819 	mov	dptr,#_ak820_macro_change_bits_10000_300
      00827B 12 3A 65         [24]  820 	lcall	_ak820_outline_0060
      00827E 90 09 BA         [24]  821 	mov	dptr,#_ak820_macro_change_bits_10000_300
      008281 EF               [12]  822 	mov	a,r7
      008282 2C               [12]  823 	add	a, r4
      008283 F0               [24]  824 	movx	@dptr,a
      008284 E4               [12]  825 	clr	a
      008285 3D               [12]  826 	addc	a, r5
      008286 A3               [24]  827 	inc	dptr
      008287 F0               [24]  828 	movx	@dptr,a
                                    829 ;	quantum/action_util.c:102: if (((*bits & mask) != 0) == pressed) return false;
      008288 90 09 BA         [24]  830 	mov	dptr,#_ak820_macro_change_bits_10000_300
      00828B E0               [24]  831 	movx	a,@dptr
      00828C FD               [12]  832 	mov	r5,a
      00828D A3               [24]  833 	inc	dptr
      00828E E0               [24]  834 	movx	a,@dptr
      00828F FF               [12]  835 	mov	r7,a
      008290 12 87 DD         [24]  836 	lcall	_ak820_outline_0186
      008293 E0               [24]  837 	movx	a,@dptr
      008294 FC               [12]  838 	mov	r4,a
      008295 EE               [12]  839 	mov	a,r6
      008296 5C               [12]  840 	anl	a,r4
      008297 B4 01 00         [24]  841 	cjne	a,#0x01,00124$
      00829A                        842 00124$:
      00829A B3               [12]  843 	cpl	c
      00829B 92 21            [24]  844 	mov	_ak820_macro_change_sloc0_1_0,c
      00829D 90 09 B9         [24]  845 	mov	dptr,#_ak820_macro_change_PARM_3
      0082A0 E0               [24]  846 	movx	a,@dptr
      0082A1 FB               [12]  847 	mov	r3,a
      0082A2 A2 21            [12]  848 	mov	c,_ak820_macro_change_sloc0_1_0
      0082A4 E4               [12]  849 	clr	a
      0082A5 33               [12]  850 	rlc	a
      0082A6 B5 03 04         [24]  851 	cjne	a,ar3,00104$
      0082A9 75 82 00         [24]  852 	mov	dpl, #0x00
      0082AC 22               [24]  853 	ret
      0082AD                        854 00104$:
                                    855 ;	quantum/action_util.c:103: *bits ^= mask;
      0082AD EC               [12]  856 	mov	a,r4
      0082AE 62 06            [12]  857 	xrl	ar6,a
      0082B0 12 87 DD         [24]  858 	lcall	_ak820_outline_0186
      0082B3 EE               [12]  859 	mov	a,r6
      0082B4 F0               [24]  860 	movx	@dptr,a
                                    861 ;	quantum/action_util.c:104: return true;
      0082B5 75 82 01         [24]  862 	mov	dpl, #0x01
                                    863 ;	quantum/action_util.c:105: }
      0082B8 22               [24]  864 	ret
                                    865 ;------------------------------------------------------------
                                    866 ;Allocation info for local variables in function 'change_owned'
                                    867 ;------------------------------------------------------------
                                    868 ;mode          Allocated with name '_change_owned_PARM_2'
                                    869 ;mods          Allocated with name '_change_owned_mods_10000_305'
                                    870 ;kind          Allocated with name '_change_owned_kind_10000_306'
                                    871 ;pressed       Allocated with name '_change_owned_pressed_10000_306'
                                    872 ;refs          Allocated with name '_change_owned_refs_10000_306'
                                    873 ;old           Allocated with name '_change_owned_old_30000_308'
                                    874 ;result        Allocated with name '_change_owned_result_10001_309'
                                    875 ;i             Allocated with name '_change_owned_i_20001_310'
                                    876 ;bit           Allocated with name '_change_owned_bit_20001_310'
                                    877 ;sloc1         Allocated with name '_change_owned_sloc1_1_0'
                                    878 ;------------------------------------------------------------
                                    879 ;	quantum/action_util.c:106: static void change_owned(uint8_t mods, uint8_t mode) {
                                    880 ;	-----------------------------------------
                                    881 ;	 function change_owned
                                    882 ;	-----------------------------------------
      0082B9                        883 _change_owned:
      0082B9 E5 82            [12]  884 	mov	a,dpl
      0082BB 90 09 BD         [24]  885 	mov	dptr,#_change_owned_mods_10000_305
      0082BE F0               [24]  886 	movx	@dptr,a
                                    887 ;	quantum/action_util.c:107: uint8_t kind = mode >> 1;
      0082BF 90 09 BC         [24]  888 	mov	dptr,#_change_owned_PARM_2
      0082C2 E0               [24]  889 	movx	a,@dptr
      0082C3 FF               [12]  890 	mov	r7,a
      0082C4 C3               [12]  891 	clr	c
      0082C5 13               [12]  892 	rrc	a
      0082C6 FE               [12]  893 	mov	r6,a
                                    894 ;	quantum/action_util.c:108: bool pressed = (mode & 1) != 0;
      0082C7 53 07 01         [24]  895 	anl	ar7,#0x01
      0082CA EF               [12]  896 	mov	a,r7
      0082CB B4 01 00         [24]  897 	cjne	a,#0x01,00205$
      0082CE                        898 00205$:
      0082CE 92 22            [24]  899 	mov  _change_owned_sloc0_1_0,c
      0082D0 B3               [12]  900 	cpl	c
      0082D1 E4               [12]  901 	clr	a
      0082D2 33               [12]  902 	rlc	a
      0082D3 F5 54            [12]  903 	mov	_change_owned_sloc1_1_0,a
                                    904 ;	quantum/action_util.c:109: uint8_t AK820_STATE_MEM *refs = kind ? owned_weak_refs : owned_mod_refs;
      0082D5 EE               [12]  905 	mov	a,r6
      0082D6 60 06            [24]  906 	jz	00121$
      0082D8 7D AA            [12]  907 	mov	r5,#_owned_weak_refs
      0082DA 7F 09            [12]  908 	mov	r7,#(_owned_weak_refs >> 8)
      0082DC 80 04            [24]  909 	sjmp	00122$
      0082DE                        910 00121$:
      0082DE 7D A2            [12]  911 	mov	r5,#_owned_mod_refs
      0082E0 7F 09            [12]  912 	mov	r7,#(_owned_mod_refs >> 8)
      0082E2                        913 00122$:
                                    914 ;	quantum/action_util.c:110: if (ak820_macro_primitive) {
      0082E2 90 09 B6         [24]  915 	mov	dptr,#_ak820_macro_primitive
      0082E5 E0               [24]  916 	movx	a,@dptr
      0082E6 60 37            [24]  917 	jz	00102$
                                    918 ;	quantum/action_util.c:111: uint8_t old = macro_mods[kind];
      0082E8 EE               [12]  919 	mov	a,r6
      0082E9 24 B4            [12]  920 	add	a, #_macro_mods
      0082EB FB               [12]  921 	mov	r3,a
      0082EC E4               [12]  922 	clr	a
      0082ED 34 09            [12]  923 	addc	a, #(_macro_mods >> 8)
      0082EF FC               [12]  924 	mov	r4,a
      0082F0 12 4B D0         [24]  925 	lcall	_ak820_outline_0065
                                    926 ;	quantum/action_util.c:112: macro_mods[kind] = pressed ? old | mods : old & ~mods;
      0082F3 E5 54            [12]  927 	mov	a,_change_owned_sloc1_1_0
      0082F5 60 0A            [24]  928 	jz	00123$
      0082F7 90 09 BD         [24]  929 	mov	dptr,#_change_owned_mods_10000_305
      0082FA E0               [24]  930 	movx	a,@dptr
      0082FB F9               [12]  931 	mov	r1,a
      0082FC EA               [12]  932 	mov	a,r2
      0082FD 42 01            [12]  933 	orl	ar1,a
      0082FF 80 07            [24]  934 	sjmp	00124$
      008301                        935 00123$:
      008301 90 09 BD         [24]  936 	mov	dptr,#_change_owned_mods_10000_305
      008304 E0               [24]  937 	movx	a,@dptr
      008305 F4               [12]  938 	cpl	a
      008306 5A               [12]  939 	anl	a,r2
      008307 F9               [12]  940 	mov	r1,a
      008308                        941 00124$:
      008308 12 36 42         [24]  942 	lcall	_ak820_outline_0122
      00830B E9               [12]  943 	mov	a,r1
      00830C F0               [24]  944 	movx	@dptr,a
                                    945 ;	quantum/action_util.c:113: mods &= pressed ? ~old : old;
      00830D E5 54            [12]  946 	mov	a,_change_owned_sloc1_1_0
      00830F 60 06            [24]  947 	jz	00125$
      008311 74 FF            [12]  948 	mov	a,#0xff
      008313 6A               [12]  949 	xrl	a,r2
      008314 FC               [12]  950 	mov	r4,a
      008315 80 02            [24]  951 	sjmp	00126$
      008317                        952 00125$:
      008317 8A 04            [24]  953 	mov	ar4,r2
      008319                        954 00126$:
      008319 90 09 BD         [24]  955 	mov	dptr,#_change_owned_mods_10000_305
      00831C E0               [24]  956 	movx	a,@dptr
      00831D 5C               [12]  957 	anl	a,r4
      00831E F0               [24]  958 	movx	@dptr,a
      00831F                        959 00102$:
                                    960 ;	quantum/action_util.c:115: uint8_t result = 0;
      00831F 90 09 BE         [24]  961 	mov	dptr,#_change_owned_result_10001_309
      008322 E4               [12]  962 	clr	a
      008323 F0               [24]  963 	movx	@dptr,a
                                    964 ;	quantum/action_util.c:116: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      008324 90 09 BF         [24]  965 	mov	dptr,#_change_owned_bit_20001_310
      008327 04               [12]  966 	inc	a
      008328 F0               [24]  967 	movx	@dptr,a
      008329 90 09 BD         [24]  968 	mov	dptr,#_change_owned_mods_10000_305
      00832C E0               [24]  969 	movx	a,@dptr
      00832D FC               [12]  970 	mov	r4,a
      00832E 7B 00            [12]  971 	mov	r3,#0x00
      008330                        972 00117$:
      008330 BB 08 00         [24]  973 	cjne	r3,#0x08,00210$
      008333                        974 00210$:
      008333 50 3F            [24]  975 	jnc	00112$
                                    976 ;	quantum/action_util.c:117: if (mods & bit) {
      008335 90 09 BF         [24]  977 	mov	dptr,#_change_owned_bit_20001_310
      008338 E0               [24]  978 	movx	a,@dptr
      008339 5C               [12]  979 	anl	a,r4
      00833A 60 1C            [24]  980 	jz	00109$
                                    981 ;	quantum/action_util.c:118: if (pressed) ++refs[i];
      00833C E5 54            [12]  982 	mov	a,_change_owned_sloc1_1_0
      00833E 60 0C            [24]  983 	jz	00106$
      008340 EB               [12]  984 	mov	a,r3
      008341 2D               [12]  985 	add	a, r5
      008342 12 3A 1B         [24]  986 	lcall	_ak820_outline_0014
      008345 F8               [12]  987 	mov	r0,a
      008346 08               [12]  988 	inc	r0
      008347 12 87 91         [24]  989 	lcall	_ak820_outline_0064
      00834A 80 0C            [24]  990 	sjmp	00109$
      00834C                        991 00106$:
                                    992 ;	quantum/action_util.c:119: else if (refs[i]) --refs[i];
      00834C EB               [12]  993 	mov	a,r3
      00834D 2D               [12]  994 	add	a, r5
      00834E 12 3A 1B         [24]  995 	lcall	_ak820_outline_0014
      008351 F8               [12]  996 	mov	r0,a
      008352 60 04            [24]  997 	jz	00109$
      008354 18               [12]  998 	dec	r0
      008355 12 87 91         [24]  999 	lcall	_ak820_outline_0064
      008358                       1000 00109$:
                                   1001 ;	quantum/action_util.c:121: if (refs[i]) result |= bit;
      008358 EB               [12] 1002 	mov	a,r3
      008359 2D               [12] 1003 	add	a, r5
      00835A 12 3A 1B         [24] 1004 	lcall	_ak820_outline_0014
      00835D 60 0B            [24] 1005 	jz	00118$
      00835F 90 09 BF         [24] 1006 	mov	dptr,#_change_owned_bit_20001_310
      008362 E0               [24] 1007 	movx	a,@dptr
      008363 FA               [12] 1008 	mov	r2,a
      008364 90 09 BE         [24] 1009 	mov	dptr,#_change_owned_result_10001_309
      008367 E0               [24] 1010 	movx	a,@dptr
      008368 4A               [12] 1011 	orl	a,r2
      008369 F0               [24] 1012 	movx	@dptr,a
      00836A                       1013 00118$:
                                   1014 ;	quantum/action_util.c:116: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      00836A 0B               [12] 1015 	inc	r3
      00836B 90 09 BF         [24] 1016 	mov	dptr,#_change_owned_bit_20001_310
      00836E E0               [24] 1017 	movx	a,@dptr
      00836F 25 E0            [12] 1018 	add	a,acc
      008371 F0               [24] 1019 	movx	@dptr,a
      008372 80 BC            [24] 1020 	sjmp	00117$
      008374                       1021 00112$:
                                   1022 ;	quantum/action_util.c:123: if (kind) owned_weak_mods = result;
      008374 EE               [12] 1023 	mov	a,r6
      008375 60 09            [24] 1024 	jz	00114$
      008377 90 09 BE         [24] 1025 	mov	dptr,#_change_owned_result_10001_309
      00837A E0               [24] 1026 	movx	a,@dptr
      00837B 90 09 B3         [24] 1027 	mov	dptr,#_owned_weak_mods
      00837E F0               [24] 1028 	movx	@dptr,a
      00837F 22               [24] 1029 	ret
      008380                       1030 00114$:
                                   1031 ;	quantum/action_util.c:124: else owned_mods = result;
      008380 90 09 BE         [24] 1032 	mov	dptr,#_change_owned_result_10001_309
      008383 E0               [24] 1033 	movx	a,@dptr
      008384 90 09 B2         [24] 1034 	mov	dptr,#_owned_mods
      008387 F0               [24] 1035 	movx	@dptr,a
                                   1036 ;	quantum/action_util.c:125: }
      008388 22               [24] 1037 	ret
                                   1038 ;------------------------------------------------------------
                                   1039 ;Allocation info for local variables in function 'add_owned_mods'
                                   1040 ;------------------------------------------------------------
                                   1041 ;mods          Allocated with name '_add_owned_mods_mods_10000_318'
                                   1042 ;------------------------------------------------------------
                                   1043 ;	quantum/action_util.c:126: void add_owned_mods(uint8_t mods) { change_owned(mods, 1); }
                                   1044 ;	-----------------------------------------
                                   1045 ;	 function add_owned_mods
                                   1046 ;	-----------------------------------------
      008389                       1047 _add_owned_mods:
      008389 E5 82            [12] 1048 	mov	a,dpl
      00838B 90 09 C0         [24] 1049 	mov	dptr,#_add_owned_mods_mods_10000_318
      00838E 12 87 B1         [24] 1050 	lcall	_ak820_outline_0113
      008391 74 01            [12] 1051 	mov	a,#0x01
      008393 F0               [24] 1052 	movx	@dptr,a
      008394 8F 82            [24] 1053 	mov	dpl, r7
      008396 02 82 B9         [24] 1054 	ljmp	_change_owned
                                   1055 ;------------------------------------------------------------
                                   1056 ;Allocation info for local variables in function 'del_owned_mods'
                                   1057 ;------------------------------------------------------------
                                   1058 ;mods          Allocated with name '_del_owned_mods_mods_10000_320'
                                   1059 ;------------------------------------------------------------
                                   1060 ;	quantum/action_util.c:127: void del_owned_mods(uint8_t mods) { change_owned(mods, 0); }
                                   1061 ;	-----------------------------------------
                                   1062 ;	 function del_owned_mods
                                   1063 ;	-----------------------------------------
      008399                       1064 _del_owned_mods:
      008399 E5 82            [12] 1065 	mov	a,dpl
      00839B 90 09 C1         [24] 1066 	mov	dptr,#_del_owned_mods_mods_10000_320
      00839E 12 87 B1         [24] 1067 	lcall	_ak820_outline_0113
      0083A1 12 7D DF         [24] 1068 	lcall	_ak820_outline_0184
      0083A4 02 82 B9         [24] 1069 	ljmp	_change_owned
                                   1070 ;------------------------------------------------------------
                                   1071 ;Allocation info for local variables in function 'add_owned_weak_mods'
                                   1072 ;------------------------------------------------------------
                                   1073 ;mods          Allocated with name '_add_owned_weak_mods_mods_10000_322'
                                   1074 ;------------------------------------------------------------
                                   1075 ;	quantum/action_util.c:128: void add_owned_weak_mods(uint8_t mods) { change_owned(mods, 3); }
                                   1076 ;	-----------------------------------------
                                   1077 ;	 function add_owned_weak_mods
                                   1078 ;	-----------------------------------------
      0083A7                       1079 _add_owned_weak_mods:
      0083A7 E5 82            [12] 1080 	mov	a,dpl
      0083A9 90 09 C2         [24] 1081 	mov	dptr,#_add_owned_weak_mods_mods_10000_322
      0083AC 12 87 B1         [24] 1082 	lcall	_ak820_outline_0113
      0083AF 74 03            [12] 1083 	mov	a,#0x03
      0083B1 F0               [24] 1084 	movx	@dptr,a
      0083B2 8F 82            [24] 1085 	mov	dpl, r7
      0083B4 02 82 B9         [24] 1086 	ljmp	_change_owned
                                   1087 ;------------------------------------------------------------
                                   1088 ;Allocation info for local variables in function 'del_owned_weak_mods'
                                   1089 ;------------------------------------------------------------
                                   1090 ;mods          Allocated with name '_del_owned_weak_mods_mods_10000_324'
                                   1091 ;------------------------------------------------------------
                                   1092 ;	quantum/action_util.c:129: void del_owned_weak_mods(uint8_t mods) { change_owned(mods, 2); }
                                   1093 ;	-----------------------------------------
                                   1094 ;	 function del_owned_weak_mods
                                   1095 ;	-----------------------------------------
      0083B7                       1096 _del_owned_weak_mods:
      0083B7 E5 82            [12] 1097 	mov	a,dpl
      0083B9 90 09 C3         [24] 1098 	mov	dptr,#_del_owned_weak_mods_mods_10000_324
      0083BC 12 87 B1         [24] 1099 	lcall	_ak820_outline_0113
      0083BF 74 02            [12] 1100 	mov	a,#0x02
      0083C1 F0               [24] 1101 	movx	@dptr,a
      0083C2 8F 82            [24] 1102 	mov	dpl, r7
      0083C4 02 82 B9         [24] 1103 	ljmp	_change_owned
                                   1104 ;------------------------------------------------------------
                                   1105 ;Allocation info for local variables in function 'clear_owned_mods'
                                   1106 ;------------------------------------------------------------
                                   1107 ;i             Allocated with name '_clear_owned_mods_i_20000_328'
                                   1108 ;------------------------------------------------------------
                                   1109 ;	quantum/action_util.c:130: void clear_owned_mods(void) {
                                   1110 ;	-----------------------------------------
                                   1111 ;	 function clear_owned_mods
                                   1112 ;	-----------------------------------------
      0083C7                       1113 _clear_owned_mods:
                                   1114 ;	quantum/action_util.c:131: for (uint8_t i = 0; i < 8; ++i) owned_mod_refs[i] = owned_weak_refs[i] = 0;
      0083C7 7F 00            [12] 1115 	mov	r7,#0x00
      0083C9                       1116 00103$:
      0083C9 BF 08 00         [24] 1117 	cjne	r7,#0x08,00122$
      0083CC                       1118 00122$:
      0083CC 50 1A            [24] 1119 	jnc	00101$
      0083CE EF               [12] 1120 	mov	a,r7
      0083CF 24 A2            [12] 1121 	add	a, #_owned_mod_refs
      0083D1 FD               [12] 1122 	mov	r5,a
      0083D2 E4               [12] 1123 	clr	a
      0083D3 34 09            [12] 1124 	addc	a, #(_owned_mod_refs >> 8)
      0083D5 FE               [12] 1125 	mov	r6,a
      0083D6 EF               [12] 1126 	mov	a,r7
      0083D7 24 AA            [12] 1127 	add	a, #_owned_weak_refs
      0083D9 F5 82            [12] 1128 	mov	dpl,a
      0083DB E4               [12] 1129 	clr	a
      0083DC 34 09            [12] 1130 	addc	a, #(_owned_weak_refs >> 8)
      0083DE F5 83            [12] 1131 	mov	dph,a
      0083E0 E4               [12] 1132 	clr	a
      0083E1 F0               [24] 1133 	movx	@dptr,a
      0083E2 12 87 B8         [24] 1134 	lcall	_ak820_outline_0118
      0083E5 0F               [12] 1135 	inc	r7
      0083E6 80 E1            [24] 1136 	sjmp	00103$
      0083E8                       1137 00101$:
                                   1138 ;	quantum/action_util.c:132: owned_mods = owned_weak_mods = macro_mods[0] = macro_mods[1] = 0;
      0083E8 90 09 B5         [24] 1139 	mov	dptr,#(_macro_mods + 0x0001)
      0083EB E4               [12] 1140 	clr	a
      0083EC F0               [24] 1141 	movx	@dptr,a
      0083ED 90 09 B4         [24] 1142 	mov	dptr,#_macro_mods
      0083F0 F0               [24] 1143 	movx	@dptr,a
      0083F1 90 09 B3         [24] 1144 	mov	dptr,#_owned_weak_mods
      0083F4 F0               [24] 1145 	movx	@dptr,a
      0083F5 90 09 B2         [24] 1146 	mov	dptr,#_owned_mods
      0083F8 F0               [24] 1147 	movx	@dptr,a
                                   1148 ;	quantum/action_util.c:133: ak820_macro_cancelled = true;
      0083F9 90 09 B7         [24] 1149 	mov	dptr,#_ak820_macro_cancelled
      0083FC 04               [12] 1150 	inc	a
      0083FD F0               [24] 1151 	movx	@dptr,a
                                   1152 ;	quantum/action_util.c:134: }
      0083FE 22               [24] 1153 	ret
                                   1154 ;------------------------------------------------------------
                                   1155 ;Allocation info for local variables in function 'clear_owned_keys'
                                   1156 ;------------------------------------------------------------
                                   1157 ;i             Allocated with name '_clear_owned_keys_i_20000_331'
                                   1158 ;i             Allocated with name '_clear_owned_keys_i_20000_332'
                                   1159 ;------------------------------------------------------------
                                   1160 ;	quantum/action_util.c:140: void clear_owned_keys(void) {
                                   1161 ;	-----------------------------------------
                                   1162 ;	 function clear_owned_keys
                                   1163 ;	-----------------------------------------
      0083FF                       1164 _clear_owned_keys:
                                   1165 ;	quantum/action_util.c:141: for (uint8_t i = 0; i <= KC_EXSEL; ++i) key_refs[i] = 0;
      0083FF 7F 00            [12] 1166 	mov	r7,#0x00
      008401                       1167 00104$:
      008401 EF               [12] 1168 	mov	a,r7
      008402 24 5B            [12] 1169 	add	a,#0xff - 0xa4
      008404 40 0D            [24] 1170 	jc	00101$
                                   1171 ;	free result
      008406 EF               [12] 1172 	mov	a,r7
      008407 24 C4            [12] 1173 	add	a, #_key_refs
      008409 F5 82            [12] 1174 	mov	dpl,a
      00840B E4               [12] 1175 	clr	a
      00840C 34 09            [12] 1176 	addc	a, #(_key_refs >> 8)
      00840E 12 81 EF         [24] 1177 	lcall	_ak820_outline_0160
      008411 80 EE            [24] 1178 	sjmp	00104$
      008413                       1179 00101$:
                                   1180 ;	quantum/action_util.c:142: distinct_keys = 0;
      008413 90 0A 69         [24] 1181 	mov	dptr,#_distinct_keys
      008416 E4               [12] 1182 	clr	a
      008417 F0               [24] 1183 	movx	@dptr,a
                                   1184 ;	quantum/action_util.c:143: for (uint8_t i = 0; i < sizeof(macro_keys); ++i) macro_keys[i] = 0;
      008418 FF               [12] 1185 	mov	r7,a
      008419                       1186 00107$:
      008419 BF 15 00         [24] 1187 	cjne	r7,#0x15,00142$
      00841C                       1188 00142$:
      00841C 50 0D            [24] 1189 	jnc	00109$
      00841E EF               [12] 1190 	mov	a,r7
      00841F 24 6A            [12] 1191 	add	a, #_macro_keys
      008421 F5 82            [12] 1192 	mov	dpl,a
      008423 E4               [12] 1193 	clr	a
      008424 34 0A            [12] 1194 	addc	a, #(_macro_keys >> 8)
      008426 12 81 EF         [24] 1195 	lcall	_ak820_outline_0160
      008429 80 EE            [24] 1196 	sjmp	00107$
      00842B                       1197 00109$:
                                   1198 ;	quantum/action_util.c:144: }
      00842B 22               [24] 1199 	ret
                                   1200 ;------------------------------------------------------------
                                   1201 ;Allocation info for local variables in function 'add_owned_key'
                                   1202 ;------------------------------------------------------------
                                   1203 ;code          Allocated with name '_add_owned_key_code_10000_333'
                                   1204 ;__400000074   Allocated with name '_add_owned_key___400000074_40000_342'
                                   1205 ;key           Allocated with name '_add_owned_key_key_50000_343'
                                   1206 ;i             Allocated with name '_add_owned_key_i_40000_341'
                                   1207 ;__300000076   Allocated with name '_add_owned_key___300000076_30000_345'
                                   1208 ;key           Allocated with name '_add_owned_key_key_40000_346'
                                   1209 ;------------------------------------------------------------
                                   1210 ;	quantum/action_util.c:145: bool add_owned_key(uint8_t code) {
                                   1211 ;	-----------------------------------------
                                   1212 ;	 function add_owned_key
                                   1213 ;	-----------------------------------------
      00842C                       1214 _add_owned_key:
      00842C E5 82            [12] 1215 	mov	a,dpl
      00842E 90 0A 7F         [24] 1216 	mov	dptr,#_add_owned_key_code_10000_333
      008431 12 87 C9         [24] 1217 	lcall	_ak820_outline_0130
                                   1218 ;	quantum/action_util.c:146: if (!ak820_macro_change(macro_keys, code, true)) return false;
      008434 74 01            [12] 1219 	mov	a,#0x01
      008436 F0               [24] 1220 	movx	@dptr,a
      008437 90 0A 6A         [24] 1221 	mov	dptr,#_macro_keys
      00843A C0 07            [24] 1222 	push	ar7
      00843C 12 82 4D         [24] 1223 	lcall	_ak820_macro_change
      00843F E5 82            [12] 1224 	mov	a, dpl
      008441 D0 07            [24] 1225 	pop	ar7
      008443 70 03            [24] 1226 	jnz	00102$
      008445 F5 82            [12] 1227 	mov	dpl,a
      008447 22               [24] 1228 	ret
      008448                       1229 00102$:
                                   1230 ;	quantum/action_util.c:147: if (key_refs[code]++) return false;
      008448 12 87 83         [24] 1231 	lcall	_ak820_outline_0029
      00844B FC               [12] 1232 	mov	r4,a
      00844C 04               [12] 1233 	inc	a
      00844D 12 87 B8         [24] 1234 	lcall	_ak820_outline_0118
      008450 EC               [12] 1235 	mov	a,r4
      008451 60 04            [24] 1236 	jz	00104$
      008453 75 82 00         [24] 1237 	mov	dpl, #0x00
      008456 22               [24] 1238 	ret
      008457                       1239 00104$:
                                   1240 ;	quantum/action_util.c:148: ++distinct_keys;
      008457 90 0A 69         [24] 1241 	mov	dptr,#_distinct_keys
      00845A E0               [24] 1242 	movx	a,@dptr
      00845B 24 01            [12] 1243 	add	a, #0x01
      00845D F0               [24] 1244 	movx	@dptr,a
                                   1245 ;	quantum/action_util.c:150: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      00845E 90 0D BD         [24] 1246 	mov	dptr,#_keyboard_protocol
      008461 E0               [24] 1247 	movx	a,@dptr
      008462 60 11            [24] 1248 	jz	00106$
      008464 90 0A EE         [24] 1249 	mov	dptr,#_keymap_config
      008467 E0               [24] 1250 	movx	a,@dptr
      008468 30 E7 0A         [24] 1251 	jnb	acc.7,00106$
                                   1252 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      00846B 12 87 D4         [24] 1253 	lcall	_ak820_outline_0171
      00846E 12 75 4A         [24] 1254 	lcall	_add_key_to_report
                                   1255 ;	quantum/action_util.c:150: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      008471 75 82 01         [24] 1256 	mov	dpl, #0x01
      008474 22               [24] 1257 	ret
      008475                       1258 00106$:
                                   1259 ;	quantum/action_util.c:152: if (distinct_keys > KEYBOARD_REPORT_KEYS) {
      008475 90 0A 69         [24] 1260 	mov	dptr,#_distinct_keys
      008478 E0               [24] 1261 	movx	a,@dptr
      008479 24 F9            [12] 1262 	add	a,#0xff - 0x06
      00847B 50 17            [24] 1263 	jnc	00110$
                                   1264 ;	free result
                                   1265 ;	quantum/action_util.c:153: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; ++i) keyboard_report->keys[i] = 1; /* HID ErrorRollOver */
      00847D 7F 00            [12] 1266 	mov	r7,#0x00
      00847F                       1267 00115$:
      00847F BF 06 00         [24] 1268 	cjne	r7,#0x06,00174$
      008482                       1269 00174$:
      008482 50 1E            [24] 1270 	jnc	00111$
      008484 EF               [12] 1271 	mov	a,r7
      008485 24 D2            [12] 1272 	add	a, #(_actual_keyboard_report + 0x0002)
      008487 F5 82            [12] 1273 	mov	dpl,a
      008489 E4               [12] 1274 	clr	a
      00848A 34 0D            [12] 1275 	addc	a, #((_actual_keyboard_report + 0x0002) >> 8)
      00848C F5 83            [12] 1276 	mov	dph,a
      00848E 74 01            [12] 1277 	mov	a,#0x01
      008490 F0               [24] 1278 	movx	@dptr,a
      008491 0F               [12] 1279 	inc	r7
      008492 80 EB            [24] 1280 	sjmp	00115$
      008494                       1281 00110$:
                                   1282 ;	quantum/action_util.c:154: } else add_key(code);
      008494 90 0A 7F         [24] 1283 	mov	dptr,#_add_owned_key_code_10000_333
      008497 E0               [24] 1284 	movx	a,@dptr
                                   1285 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      008498 90 08 30         [24] 1286 	mov	dptr,#_add_key_to_report_PARM_2
      00849B F0               [24] 1287 	movx	@dptr,a
      00849C 90 0D D0         [24] 1288 	mov	dptr,#_actual_keyboard_report
      00849F 12 75 4A         [24] 1289 	lcall	_add_key_to_report
                                   1290 ;	quantum/action_util.c:154: } else add_key(code);
      0084A2                       1291 00111$:
                                   1292 ;	quantum/action_util.c:155: return true;
      0084A2 75 82 01         [24] 1293 	mov	dpl, #0x01
                                   1294 ;	quantum/action_util.c:156: }
      0084A5 22               [24] 1295 	ret
                                   1296 ;------------------------------------------------------------
                                   1297 ;Allocation info for local variables in function 'del_owned_key'
                                   1298 ;------------------------------------------------------------
                                   1299 ;code          Allocated with name '_del_owned_key_code_10000_348'
                                   1300 ;__400000078   Allocated with name '_del_owned_key___400000078_40000_359'
                                   1301 ;key           Allocated with name '_del_owned_key_key_50000_360'
                                   1302 ;key           Allocated with name '_del_owned_key_key_40000_357'
                                   1303 ;__600000081   Allocated with name '_del_owned_key___600000081_60000_365'
                                   1304 ;key           Allocated with name '_del_owned_key_key_70000_366'
                                   1305 ;__300000083   Allocated with name '_del_owned_key___300000083_30000_368'
                                   1306 ;key           Allocated with name '_del_owned_key_key_40000_369'
                                   1307 ;------------------------------------------------------------
                                   1308 ;	quantum/action_util.c:157: bool del_owned_key(uint8_t code) {
                                   1309 ;	-----------------------------------------
                                   1310 ;	 function del_owned_key
                                   1311 ;	-----------------------------------------
      0084A6                       1312 _del_owned_key:
      0084A6 E5 82            [12] 1313 	mov	a,dpl
      0084A8 90 0A 80         [24] 1314 	mov	dptr,#_del_owned_key_code_10000_348
      0084AB 12 87 C9         [24] 1315 	lcall	_ak820_outline_0130
                                   1316 ;	quantum/action_util.c:158: if (!ak820_macro_change(macro_keys, code, false)) return false;
      0084AE E4               [12] 1317 	clr	a
      0084AF F0               [24] 1318 	movx	@dptr,a
      0084B0 90 0A 6A         [24] 1319 	mov	dptr,#_macro_keys
      0084B3 C0 07            [24] 1320 	push	ar7
      0084B5 12 82 4D         [24] 1321 	lcall	_ak820_macro_change
      0084B8 E5 82            [12] 1322 	mov	a, dpl
      0084BA D0 07            [24] 1323 	pop	ar7
      0084BC 70 03            [24] 1324 	jnz	00102$
      0084BE F5 82            [12] 1325 	mov	dpl,a
      0084C0 22               [24] 1326 	ret
      0084C1                       1327 00102$:
                                   1328 ;	quantum/action_util.c:159: if (!key_refs[code] || --key_refs[code]) return false;
      0084C1 12 87 83         [24] 1329 	lcall	_ak820_outline_0029
      0084C4 FC               [12] 1330 	mov	r4,a
      0084C5 60 09            [24] 1331 	jz	00103$
      0084C7 1C               [12] 1332 	dec	r4
      0084C8 12 3A B0         [24] 1333 	lcall	_ak820_outline_0131
      0084CB EC               [12] 1334 	mov	a,r4
      0084CC F0               [24] 1335 	movx	@dptr,a
      0084CD EC               [12] 1336 	mov	a,r4
      0084CE 60 04            [24] 1337 	jz	00104$
      0084D0                       1338 00103$:
      0084D0 75 82 00         [24] 1339 	mov	dpl, #0x00
      0084D3 22               [24] 1340 	ret
      0084D4                       1341 00104$:
                                   1342 ;	quantum/action_util.c:160: --distinct_keys;
      0084D4 90 0A 69         [24] 1343 	mov	dptr,#_distinct_keys
      0084D7 E0               [24] 1344 	movx	a,@dptr
      0084D8 14               [12] 1345 	dec	a
      0084D9 F0               [24] 1346 	movx	@dptr,a
                                   1347 ;	quantum/action_util.c:162: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      0084DA 90 0D BD         [24] 1348 	mov	dptr,#_keyboard_protocol
      0084DD E0               [24] 1349 	movx	a,@dptr
      0084DE 60 16            [24] 1350 	jz	00107$
      0084E0 90 0A EE         [24] 1351 	mov	dptr,#_keymap_config
      0084E3 E0               [24] 1352 	movx	a,@dptr
      0084E4 30 E7 0F         [24] 1353 	jnb	acc.7,00107$
                                   1354 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      0084E7 90 08 33         [24] 1355 	mov	dptr,#_del_key_from_report_PARM_2
      0084EA EF               [12] 1356 	mov	a,r7
      0084EB F0               [24] 1357 	movx	@dptr,a
      0084EC 90 0D D0         [24] 1358 	mov	dptr,#_actual_keyboard_report
      0084EF 12 75 80         [24] 1359 	lcall	_del_key_from_report
                                   1360 ;	quantum/action_util.c:162: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      0084F2 75 82 01         [24] 1361 	mov	dpl, #0x01
      0084F5 22               [24] 1362 	ret
      0084F6                       1363 00107$:
                                   1364 ;	quantum/action_util.c:164: if (distinct_keys > KEYBOARD_REPORT_KEYS) return true;
      0084F6 90 0A 69         [24] 1365 	mov	dptr,#_distinct_keys
      0084F9 E0               [24] 1366 	movx	a,@dptr
      0084FA FF               [12] 1367 	mov  r7,a
      0084FB 24 F9            [12] 1368 	add	a,#0xff - 0x06
      0084FD 50 04            [24] 1369 	jnc	00110$
                                   1370 ;	free result
      0084FF 75 82 01         [24] 1371 	mov	dpl, #0x01
      008502 22               [24] 1372 	ret
      008503                       1373 00110$:
                                   1374 ;	quantum/action_util.c:165: if (distinct_keys == KEYBOARD_REPORT_KEYS) {
      008503 BF 06 1F         [24] 1375 	cjne	r7,#0x06,00115$
                                   1376 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      008506 90 0D D0         [24] 1377 	mov	dptr,#_actual_keyboard_report
      008509 12 75 B6         [24] 1378 	lcall	_clear_keys_from_report
                                   1379 ;	quantum/action_util.c:168: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      00850C 7F 04            [12] 1380 	mov	r7,#0x04
      00850E                       1381 00122$:
      00850E EF               [12] 1382 	mov	a,r7
      00850F 24 5B            [12] 1383 	add	a,#0xff - 0xa4
      008511 40 20            [24] 1384 	jc	00116$
                                   1385 ;	free result
      008513 12 87 83         [24] 1386 	lcall	_ak820_outline_0029
      008516 60 0A            [24] 1387 	jz	00123$
                                   1388 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      008518 12 87 D4         [24] 1389 	lcall	_ak820_outline_0171
      00851B C0 07            [24] 1390 	push	ar7
      00851D 12 75 4A         [24] 1391 	lcall	_add_key_to_report
      008520 D0 07            [24] 1392 	pop	ar7
                                   1393 ;	quantum/action_util.c:168: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      008522                       1394 00123$:
      008522 0F               [12] 1395 	inc	r7
      008523 80 E9            [24] 1396 	sjmp	00122$
      008525                       1397 00115$:
                                   1398 ;	quantum/action_util.c:169: } else del_key(code);
      008525 90 0A 80         [24] 1399 	mov	dptr,#_del_owned_key_code_10000_348
      008528 E0               [24] 1400 	movx	a,@dptr
                                   1401 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      008529 90 08 33         [24] 1402 	mov	dptr,#_del_key_from_report_PARM_2
      00852C F0               [24] 1403 	movx	@dptr,a
      00852D 90 0D D0         [24] 1404 	mov	dptr,#_actual_keyboard_report
      008530 12 75 80         [24] 1405 	lcall	_del_key_from_report
                                   1406 ;	quantum/action_util.c:169: } else del_key(code);
      008533                       1407 00116$:
                                   1408 ;	quantum/action_util.c:170: return true;
      008533 75 82 01         [24] 1409 	mov	dpl, #0x01
                                   1410 ;	quantum/action_util.c:171: }
      008536 22               [24] 1411 	ret
                                   1412 ;------------------------------------------------------------
                                   1413 ;Allocation info for local variables in function 'clear_owned_usages'
                                   1414 ;------------------------------------------------------------
                                   1415 ;i             Allocated with name '_clear_owned_usages_i_20000_373'
                                   1416 ;i             Allocated with name '_clear_owned_usages_i_20000_374'
                                   1417 ;------------------------------------------------------------
                                   1418 ;	quantum/action_util.c:181: void clear_owned_usages(void) {
                                   1419 ;	-----------------------------------------
                                   1420 ;	 function clear_owned_usages
                                   1421 ;	-----------------------------------------
      008537                       1422 _clear_owned_usages:
                                   1423 ;	quantum/action_util.c:182: for (uint8_t i = 0; i < USAGE_COUNT; ++i) usage_refs[i] = usage_order[i] = 0;
      008537 7F 00            [12] 1424 	mov	r7,#0x00
      008539                       1425 00104$:
      008539 BF 1E 00         [24] 1426 	cjne	r7,#0x1e,00141$
      00853C                       1427 00141$:
      00853C 50 14            [24] 1428 	jnc	00101$
      00853E EF               [12] 1429 	mov	a,r7
      00853F 24 81            [12] 1430 	add	a, #_usage_refs
      008541 FD               [12] 1431 	mov	r5,a
      008542 E4               [12] 1432 	clr	a
      008543 34 0A            [12] 1433 	addc	a, #(_usage_refs >> 8)
      008545 FE               [12] 1434 	mov	r6,a
      008546 EF               [12] 1435 	mov	a,r7
      008547 12 87 98         [24] 1436 	lcall	_ak820_outline_0068
      00854A E4               [12] 1437 	clr	a
      00854B F0               [24] 1438 	movx	@dptr,a
      00854C 12 87 B8         [24] 1439 	lcall	_ak820_outline_0118
      00854F 0F               [12] 1440 	inc	r7
      008550 80 E7            [24] 1441 	sjmp	00104$
      008552                       1442 00101$:
                                   1443 ;	quantum/action_util.c:183: usage_lengths[0] = usage_lengths[1] = 0;
      008552 90 0A BE         [24] 1444 	mov	dptr,#(_usage_lengths + 0x0001)
      008555 E4               [12] 1445 	clr	a
      008556 F0               [24] 1446 	movx	@dptr,a
      008557 90 0A BD         [24] 1447 	mov	dptr,#_usage_lengths
      00855A F0               [24] 1448 	movx	@dptr,a
                                   1449 ;	quantum/action_util.c:184: for (uint8_t i = 0; i < sizeof(macro_usages); ++i) macro_usages[i] = 0;
      00855B FF               [12] 1450 	mov	r7,a
      00855C                       1451 00107$:
      00855C BF 04 00         [24] 1452 	cjne	r7,#0x04,00143$
      00855F                       1453 00143$:
      00855F 50 0D            [24] 1454 	jnc	00109$
      008561 EF               [12] 1455 	mov	a,r7
      008562 24 BF            [12] 1456 	add	a, #_macro_usages
      008564 F5 82            [12] 1457 	mov	dpl,a
      008566 E4               [12] 1458 	clr	a
      008567 34 0A            [12] 1459 	addc	a, #(_macro_usages >> 8)
      008569 12 81 EF         [24] 1460 	lcall	_ak820_outline_0160
      00856C 80 EE            [24] 1461 	sjmp	00107$
      00856E                       1462 00109$:
                                   1463 ;	quantum/action_util.c:185: }
      00856E 22               [24] 1464 	ret
                                   1465 ;------------------------------------------------------------
                                   1466 ;Allocation info for local variables in function 'owned_usage_key'
                                   1467 ;------------------------------------------------------------
                                   1468 ;pressed       Allocated with name '_owned_usage_key_PARM_2'
                                   1469 ;code          Allocated with name '_owned_usage_key_code_10000_375'
                                   1470 ;__200000085   Allocated with name '_owned_usage_key___200000085_20000_376'
                                   1471 ;which         Allocated with name '_owned_usage_key_which_10000_376'
                                   1472 ;base          Allocated with name '_owned_usage_key_base_10000_376'
                                   1473 ;count         Allocated with name '_owned_usage_key_count_10000_376'
                                   1474 ;index         Allocated with name '_owned_usage_key_index_10000_376'
                                   1475 ;pos           Allocated with name '_owned_usage_key_pos_30001_383'
                                   1476 ;i             Allocated with name '_owned_usage_key_i_40001_384'
                                   1477 ;__300000086   Allocated with name '_owned_usage_key___300000086_30000_387'
                                   1478 ;key           Allocated with name '_owned_usage_key_key_40000_388'
                                   1479 ;------------------------------------------------------------
                                   1480 ;	quantum/action_util.c:186: void owned_usage_key(uint8_t code, bool pressed) {
                                   1481 ;	-----------------------------------------
                                   1482 ;	 function owned_usage_key
                                   1483 ;	-----------------------------------------
      00856F                       1484 _owned_usage_key:
      00856F E5 82            [12] 1485 	mov	a,dpl
      008571 90 0A C4         [24] 1486 	mov	dptr,#_owned_usage_key_code_10000_375
      008574 F0               [24] 1487 	movx	@dptr,a
                                   1488 ;	quantum/action_util.c:187: uint8_t which = code >= KC_AUDIO_MUTE;
      008575 E0               [24] 1489 	movx	a,@dptr
      008576 FF               [12] 1490 	mov	r7,a
      008577 BF A8 00         [24] 1491 	cjne	r7,#0xa8,00244$
      00857A                       1492 00244$:
      00857A B3               [12] 1493 	cpl	c
      00857B 92 23            [24] 1494 	mov	_owned_usage_key_sloc0_1_0,c
      00857D E4               [12] 1495 	clr	a
      00857E 33               [12] 1496 	rlc	a
      00857F FF               [12] 1497 	mov	r7,a
      008580 90 0A C7         [24] 1498 	mov	dptr,#_owned_usage_key_which_10000_376
      008583 F0               [24] 1499 	movx	@dptr,a
                                   1500 ;	quantum/action_util.c:188: uint8_t base = which ? SYSTEM_COUNT : 0;
      008584 EF               [12] 1501 	mov	a,r7
      008585 60 02            [24] 1502 	jz	00129$
      008587 74 03            [12] 1503 	mov	a,#0x03
      008589                       1504 00129$:
      008589 FE               [12] 1505 	mov	r6,a
                                   1506 ;	quantum/action_util.c:189: uint8_t count = usage_lengths[which];
      00858A EF               [12] 1507 	mov	a,r7
      00858B 24 BD            [12] 1508 	add	a, #_usage_lengths
      00858D FD               [12] 1509 	mov	r5,a
      00858E E4               [12] 1510 	clr	a
      00858F 34 0A            [12] 1511 	addc	a, #(_usage_lengths >> 8)
      008591 FF               [12] 1512 	mov	r7,a
      008592 12 87 DD         [24] 1513 	lcall	_ak820_outline_0186
      008595 E0               [24] 1514 	movx	a,@dptr
      008596 FC               [12] 1515 	mov	r4,a
                                   1516 ;	quantum/action_util.c:190: uint8_t index = code - KC_SYSTEM_POWER;
      008597 90 0A C4         [24] 1517 	mov	dptr,#_owned_usage_key_code_10000_375
      00859A E0               [24] 1518 	movx	a,@dptr
      00859B 24 5B            [12] 1519 	add	a,#0x5b
      00859D FB               [12] 1520 	mov	r3,a
                                   1521 ;	quantum/action_util.c:191: if (!ak820_macro_change(macro_usages, index, pressed)) return;
      00859E 90 0A C3         [24] 1522 	mov	dptr,#_owned_usage_key_PARM_2
      0085A1 E0               [24] 1523 	movx	a,@dptr
      0085A2 FA               [12] 1524 	mov	r2,a
      0085A3 90 09 B8         [24] 1525 	mov	dptr,#_ak820_macro_change_PARM_2
      0085A6 EB               [12] 1526 	mov	a,r3
      0085A7 F0               [24] 1527 	movx	@dptr,a
      0085A8 90 09 B9         [24] 1528 	mov	dptr,#_ak820_macro_change_PARM_3
      0085AB EA               [12] 1529 	mov	a,r2
      0085AC F0               [24] 1530 	movx	@dptr,a
      0085AD 90 0A BF         [24] 1531 	mov	dptr,#_macro_usages
      0085B0 C0 07            [24] 1532 	push	ar7
      0085B2 C0 06            [24] 1533 	push	ar6
      0085B4 C0 05            [24] 1534 	push	ar5
      0085B6 C0 04            [24] 1535 	push	ar4
      0085B8 C0 03            [24] 1536 	push	ar3
      0085BA C0 02            [24] 1537 	push	ar2
      0085BC 12 82 4D         [24] 1538 	lcall	_ak820_macro_change
      0085BF E5 82            [12] 1539 	mov	a, dpl
      0085C1 D0 02            [24] 1540 	pop	ar2
      0085C3 D0 03            [24] 1541 	pop	ar3
      0085C5 D0 04            [24] 1542 	pop	ar4
      0085C7 D0 05            [24] 1543 	pop	ar5
      0085C9 D0 06            [24] 1544 	pop	ar6
      0085CB D0 07            [24] 1545 	pop	ar7
      0085CD 70 01            [24] 1546 	jnz	00102$
      0085CF 22               [24] 1547 	ret
      0085D0                       1548 00102$:
                                   1549 ;	quantum/action_util.c:192: if (pressed) {
      0085D0 EA               [12] 1550 	mov	a,r2
      0085D1 60 1B            [24] 1551 	jz	00115$
                                   1552 ;	quantum/action_util.c:193: if (usage_refs[index]++) return;
      0085D3 12 87 A2         [24] 1553 	lcall	_ak820_outline_0074
      0085D6 04               [12] 1554 	inc	a
      0085D7 12 72 CE         [24] 1555 	lcall	_ak820_outline_0136
      0085DA E8               [12] 1556 	mov	a,r0
      0085DB 60 01            [24] 1557 	jz	00104$
      0085DD 22               [24] 1558 	ret
      0085DE                       1559 00104$:
                                   1560 ;	quantum/action_util.c:194: usage_order[base + count++] = index;
      0085DE 90 0A C8         [24] 1561 	mov	dptr,#_owned_usage_key_count_10000_376
      0085E1 EC               [12] 1562 	mov	a,r4
      0085E2 04               [12] 1563 	inc	a
      0085E3 F0               [24] 1564 	movx	@dptr,a
      0085E4 EC               [12] 1565 	mov	a,r4
      0085E5 2E               [12] 1566 	add	a, r6
      0085E6 12 87 98         [24] 1567 	lcall	_ak820_outline_0068
      0085E9 EB               [12] 1568 	mov	a,r3
      0085EA F0               [24] 1569 	movx	@dptr,a
      0085EB 02 86 4F         [24] 1570 	ljmp	00116$
      0085EE                       1571 00115$:
                                   1572 ;	quantum/action_util.c:196: if (!usage_refs[index] || --usage_refs[index]) return;
      0085EE 12 87 A2         [24] 1573 	lcall	_ak820_outline_0074
      0085F1 60 07            [24] 1574 	jz	00105$
      0085F3 18               [12] 1575 	dec	r0
      0085F4 12 87 91         [24] 1576 	lcall	_ak820_outline_0064
      0085F7 E8               [12] 1577 	mov	a,r0
      0085F8 60 01            [24] 1578 	jz	00106$
      0085FA                       1579 00105$:
      0085FA 22               [24] 1580 	ret
      0085FB                       1581 00106$:
                                   1582 ;	quantum/action_util.c:198: while (usage_order[base + pos] != index) ++pos;
      0085FB 7A 00            [12] 1583 	mov	r2,#0x00
      0085FD                       1584 00108$:
      0085FD EA               [12] 1585 	mov	a,r2
      0085FE 2E               [12] 1586 	add	a, r6
      0085FF 12 87 98         [24] 1587 	lcall	_ak820_outline_0068
      008602 E0               [24] 1588 	movx	a,@dptr
      008603 B5 03 02         [24] 1589 	cjne	a,ar3,00251$
      008606 80 03            [24] 1590 	sjmp	00167$
      008608                       1591 00251$:
      008608 0A               [12] 1592 	inc	r2
      008609 80 F2            [24] 1593 	sjmp	00108$
      00860B                       1594 00167$:
      00860B 90 0A C9         [24] 1595 	mov	dptr,#_owned_usage_key_pos_30001_383
      00860E EA               [12] 1596 	mov	a,r2
      00860F F0               [24] 1597 	movx	@dptr,a
                                   1598 ;	quantum/action_util.c:199: --count;
      008610 1C               [12] 1599 	dec	r4
      008611 90 0A C8         [24] 1600 	mov	dptr,#_owned_usage_key_count_10000_376
      008614 EC               [12] 1601 	mov	a,r4
      008615 F0               [24] 1602 	movx	@dptr,a
                                   1603 ;	quantum/action_util.c:200: for (uint8_t i = pos; i < count; ++i) usage_order[base + i] = usage_order[base + i + 1];
      008616 8A 03            [24] 1604 	mov	ar3,r2
      008618                       1605 00125$:
      008618 C3               [12] 1606 	clr	c
      008619 EB               [12] 1607 	mov	a,r3
      00861A 9C               [12] 1608 	subb	a,r4
      00861B 50 23            [24] 1609 	jnc	00111$
      00861D C0 05            [24] 1610 	push	ar5
      00861F C0 07            [24] 1611 	push	ar7
      008621 EB               [12] 1612 	mov	a,r3
      008622 2E               [12] 1613 	add	a, r6
      008623 FA               [12] 1614 	mov	r2,a
      008624 24 9F            [12] 1615 	add	a, #_usage_order
      008626 F8               [12] 1616 	mov	r0,a
      008627 E4               [12] 1617 	clr	a
      008628 34 0A            [12] 1618 	addc	a, #(_usage_order >> 8)
      00862A F9               [12] 1619 	mov	r1,a
      00862B 0A               [12] 1620 	inc	r2
      00862C EA               [12] 1621 	mov	a,r2
      00862D 33               [12] 1622 	rlc	a
      00862E 95 E0            [12] 1623 	subb	a,acc
      008630 FF               [12] 1624 	mov	r7,a
      008631 EA               [12] 1625 	mov	a,r2
      008632 12 87 BE         [24] 1626 	lcall	_ak820_outline_0124
      008635 12 3A BB         [24] 1627 	lcall	_ak820_outline_0155
      008638 F0               [24] 1628 	movx	@dptr,a
      008639 0B               [12] 1629 	inc	r3
      00863A D0 07            [24] 1630 	pop	ar7
      00863C D0 05            [24] 1631 	pop	ar5
      00863E 80 D8            [24] 1632 	sjmp	00125$
      008640                       1633 00111$:
                                   1634 ;	quantum/action_util.c:201: usage_lengths[which] = count;
      008640 12 87 DD         [24] 1635 	lcall	_ak820_outline_0186
      008643 EC               [12] 1636 	mov	a,r4
      008644 F0               [24] 1637 	movx	@dptr,a
                                   1638 ;	quantum/action_util.c:202: if (pos != count) return; /* A non-winning owner changed only storage. */
      008645 90 0A C9         [24] 1639 	mov	dptr,#_owned_usage_key_pos_30001_383
      008648 E0               [24] 1640 	movx	a,@dptr
      008649 B5 04 02         [24] 1641 	cjne	a,ar4,00253$
      00864C 80 01            [24] 1642 	sjmp	00116$
      00864E                       1643 00253$:
      00864E 22               [24] 1644 	ret
      00864F                       1645 00116$:
                                   1646 ;	quantum/action_util.c:204: usage_lengths[which] = count;
      00864F 90 0A C8         [24] 1647 	mov	dptr,#_owned_usage_key_count_10000_376
      008652 E0               [24] 1648 	movx	a,@dptr
      008653 FC               [12] 1649 	mov	r4,a
      008654 12 87 DD         [24] 1650 	lcall	_ak820_outline_0186
      008657 F0               [24] 1651 	movx	@dptr,a
                                   1652 ;	quantum/action_util.c:205: code = count ? usage_order[base + count - 1] + KC_SYSTEM_POWER : 0;
      008658 EC               [12] 1653 	mov	a,r4
      008659 60 15            [24] 1654 	jz	00131$
      00865B EC               [12] 1655 	mov	a,r4
      00865C 2E               [12] 1656 	add	a, r6
      00865D FE               [12] 1657 	mov	r6,a
      00865E 1E               [12] 1658 	dec	r6
      00865F EE               [12] 1659 	mov	a,r6
      008660 33               [12] 1660 	rlc	a
      008661 95 E0            [12] 1661 	subb	a,acc
      008663 FF               [12] 1662 	mov	r7,a
      008664 EE               [12] 1663 	mov	a,r6
      008665 12 87 BE         [24] 1664 	lcall	_ak820_outline_0124
      008668 24 A5            [12] 1665 	add	a,#0xa5
      00866A FE               [12] 1666 	mov	r6,a
      00866B 33               [12] 1667 	rlc	a
      00866C 95 E0            [12] 1668 	subb	a,acc
      00866E 80 02            [24] 1669 	sjmp	00132$
      008670                       1670 00131$:
      008670 7E 00            [12] 1671 	mov	r6,#0x00
      008672                       1672 00132$:
      008672 90 0A C4         [24] 1673 	mov	dptr,#_owned_usage_key_code_10000_375
      008675 EE               [12] 1674 	mov	a,r6
      008676 F0               [24] 1675 	movx	@dptr,a
                                   1676 ;	quantum/action_util.c:206: if (which) host_consumer_send(code ? KEYCODE2CONSUMER(code) : 0);
      008677 90 0A C7         [24] 1677 	mov	dptr,#_owned_usage_key_which_10000_376
      00867A E0               [24] 1678 	movx	a,@dptr
      00867B 60 18            [24] 1679 	jz	00118$
      00867D EE               [12] 1680 	mov	a,r6
      00867E 60 0B            [24] 1681 	jz	00133$
      008680 8E 82            [24] 1682 	mov	dpl, r6
      008682 12 74 07         [24] 1683 	lcall	_KEYCODE2CONSUMER
      008685 AD 82            [24] 1684 	mov	r5, dpl
      008687 AF 83            [24] 1685 	mov	r7, dph
      008689 80 04            [24] 1686 	sjmp	00134$
      00868B                       1687 00133$:
      00868B 7D 00            [12] 1688 	mov	r5,#0x00
      00868D 7F 00            [12] 1689 	mov	r7,#0x00
      00868F                       1690 00134$:
      00868F 12 87 DD         [24] 1691 	lcall	_ak820_outline_0186
      008692 02 73 C1         [24] 1692 	ljmp	_host_consumer_send
      008695                       1693 00118$:
                                   1694 ;	quantum/action_util.c:207: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      008695 EE               [12] 1695 	mov	a,r6
      008696 60 22            [24] 1696 	jz	00135$
                                   1697 ;	tmk_core/protocol/report.h:264: if (key < KC_SYSTEM_POWER || key > KC_SYSTEM_WAKE) return 0;
      008698 BE A5 00         [24] 1698 	cjne	r6,#0xa5,00258$
      00869B                       1699 00258$:
      00869B 40 05            [24] 1700 	jc	00121$
      00869D EE               [12] 1701 	mov	a,r6
      00869E 24 58            [12] 1702 	add	a,#0xff - 0xa7
      0086A0 50 08            [24] 1703 	jnc	00122$
                                   1704 ;	free result
      0086A2                       1705 00121$:
      0086A2 90 0A C5         [24] 1706 	mov	dptr,#_owned_usage_key___200000085_20000_376
      0086A5 12 52 9A         [24] 1707 	lcall	_ak820_outline_0178
      0086A8 80 09            [24] 1708 	sjmp	00123$
      0086AA                       1709 00122$:
                                   1710 ;	tmk_core/protocol/report.h:265: return SYSTEM_POWER_DOWN + (key - KC_SYSTEM_POWER);
      0086AA 74 DC            [12] 1711 	mov	a,#0xdc
      0086AC 2E               [12] 1712 	add	a, r6
      0086AD 90 0A C5         [24] 1713 	mov	dptr,#_owned_usage_key___200000085_20000_376
      0086B0 12 3A AB         [24] 1714 	lcall	_ak820_outline_0123
                                   1715 ;	quantum/action_util.c:207: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      0086B3                       1716 00123$:
      0086B3 90 0A C5         [24] 1717 	mov	dptr,#_owned_usage_key___200000085_20000_376
      0086B6 E0               [24] 1718 	movx	a,@dptr
      0086B7 FF               [12] 1719 	mov	r7,a
      0086B8 80 02            [24] 1720 	sjmp	00136$
      0086BA                       1721 00135$:
      0086BA 7F 00            [12] 1722 	mov	r7,#0x00
      0086BC                       1723 00136$:
      0086BC 7E 00            [12] 1724 	mov	r6,#0x00
      0086BE 12 45 F5         [24] 1725 	lcall	_ak820_outline_0156
                                   1726 ;	quantum/action_util.c:208: }
      0086C1 02 73 91         [24] 1727 	ljmp	_host_system_send
                                   1728 ;------------------------------------------------------------
                                   1729 ;Allocation info for local variables in function 'send_keyboard_report'
                                   1730 ;------------------------------------------------------------
                                   1731 ;last_report   Allocated with name '_send_keyboard_report_last_report_10001_396'
                                   1732 ;changed       Allocated with name '_send_keyboard_report_changed_10001_396'
                                   1733 ;dest          Allocated with name '_send_keyboard_report_dest_10001_396'
                                   1734 ;src           Allocated with name '_send_keyboard_report_src_10001_396'
                                   1735 ;i             Allocated with name '_send_keyboard_report_i_20001_397'
                                   1736 ;------------------------------------------------------------
                                   1737 ;	quantum/action_util.c:430: void send_keyboard_report(void) {
                                   1738 ;	-----------------------------------------
                                   1739 ;	 function send_keyboard_report
                                   1740 ;	-----------------------------------------
      0086C4                       1741 _send_keyboard_report:
                                   1742 ;	quantum/action_util.c:431: keyboard_report->mods = real_mods;
      0086C4 90 0D CE         [24] 1743 	mov	dptr,#_real_mods
      0086C7 E0               [24] 1744 	movx	a,@dptr
      0086C8 FF               [12] 1745 	mov	r7,a
      0086C9 90 0D D0         [24] 1746 	mov	dptr,#_actual_keyboard_report
      0086CC F0               [24] 1747 	movx	@dptr,a
                                   1748 ;	quantum/action_util.c:432: keyboard_report->mods |= weak_mods;
      0086CD 90 0D CF         [24] 1749 	mov	dptr,#_weak_mods
      0086D0 E0               [24] 1750 	movx	a,@dptr
      0086D1 42 07            [12] 1751 	orl	ar7,a
      0086D3 90 0D D0         [24] 1752 	mov	dptr,#_actual_keyboard_report
      0086D6 EF               [12] 1753 	mov	a,r7
      0086D7 F0               [24] 1754 	movx	@dptr,a
                                   1755 ;	quantum/action_util.c:434: keyboard_report->mods |= owned_mods | owned_weak_mods;
      0086D8 90 09 B3         [24] 1756 	mov	dptr,#_owned_weak_mods
      0086DB E0               [24] 1757 	movx	a,@dptr
      0086DC FE               [12] 1758 	mov	r6,a
      0086DD 90 09 B2         [24] 1759 	mov	dptr,#_owned_mods
      0086E0 E0               [24] 1760 	movx	a,@dptr
      0086E1 4E               [12] 1761 	orl	a,r6
      0086E2 42 07            [12] 1762 	orl	ar7,a
      0086E4 90 0D D0         [24] 1763 	mov	dptr,#_actual_keyboard_report
      0086E7 EF               [12] 1764 	mov	a,r7
      0086E8 F0               [24] 1765 	movx	@dptr,a
                                   1766 ;	quantum/action_util.c:475: if (gui_disabled) keyboard_report->mods &= ~(MOD_BIT(KC_LGUI) | MOD_BIT(KC_RGUI));
      0086E9 30 1F 07         [24] 1767 	jnb	_gui_disabled,00102$
      0086EC 90 0D D0         [24] 1768 	mov	dptr,#_actual_keyboard_report
      0086EF E0               [24] 1769 	movx	a,@dptr
      0086F0 54 77            [12] 1770 	anl	a,#0x77
      0086F2 F0               [24] 1771 	movx	@dptr,a
      0086F3                       1772 00102$:
                                   1773 ;	quantum/action_util.c:515: bool changed = false;
      0086F3 90 0A EB         [24] 1774 	mov	dptr,#_send_keyboard_report_changed_10001_396
      0086F6 E4               [12] 1775 	clr	a
      0086F7 F0               [24] 1776 	movx	@dptr,a
                                   1777 ;	quantum/action_util.c:517: uint8_t __xdata *dest = (uint8_t __xdata *)&last_report;
                                   1778 ;	quantum/action_util.c:518: const uint8_t __xdata *src = (const uint8_t __xdata *)AK820_REPORT_OUT;
                                   1779 ;	quantum/action_util.c:523: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      0086F8 FF               [12] 1780 	mov	r7,a
      0086F9                       1781 00109$:
      0086F9 BF 20 00         [24] 1782 	cjne	r7,#0x20,00150$
      0086FC                       1783 00150$:
      0086FC 50 2A            [24] 1784 	jnc	00105$
                                   1785 ;	quantum/action_util.c:524: if (dest[i] != src[i]) {
      0086FE EF               [12] 1786 	mov	a,r7
      0086FF 24 CB            [12] 1787 	add	a, #_send_keyboard_report_last_report_10001_396
      008701 FD               [12] 1788 	mov	r5,a
      008702 E4               [12] 1789 	clr	a
      008703 34 0A            [12] 1790 	addc	a, #(_send_keyboard_report_last_report_10001_396 >> 8)
      008705 12 4B C2         [24] 1791 	lcall	_ak820_outline_0057
      008708 EF               [12] 1792 	mov	a,r7
      008709 24 D0            [12] 1793 	add	a, #_actual_keyboard_report
      00870B F5 82            [12] 1794 	mov	dpl,a
      00870D E4               [12] 1795 	clr	a
      00870E 34 0D            [12] 1796 	addc	a, #(_actual_keyboard_report >> 8)
      008710 F5 83            [12] 1797 	mov	dph,a
      008712 E0               [24] 1798 	movx	a,@dptr
      008713 FB               [12] 1799 	mov	r3,a
      008714 EC               [12] 1800 	mov	a,r4
      008715 B5 03 02         [24] 1801 	cjne	a,ar3,00152$
      008718 80 0B            [24] 1802 	sjmp	00110$
      00871A                       1803 00152$:
                                   1804 ;	quantum/action_util.c:525: dest[i] = src[i];
      00871A 12 3A B0         [24] 1805 	lcall	_ak820_outline_0131
      00871D EB               [12] 1806 	mov	a,r3
      00871E F0               [24] 1807 	movx	@dptr,a
                                   1808 ;	quantum/action_util.c:526: changed = true;
      00871F 90 0A EB         [24] 1809 	mov	dptr,#_send_keyboard_report_changed_10001_396
      008722 74 01            [12] 1810 	mov	a,#0x01
      008724 F0               [24] 1811 	movx	@dptr,a
      008725                       1812 00110$:
                                   1813 ;	quantum/action_util.c:523: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      008725 0F               [12] 1814 	inc	r7
      008726 80 D1            [24] 1815 	sjmp	00109$
      008728                       1816 00105$:
                                   1817 ;	quantum/action_util.c:529: if (changed) host_keyboard_send(AK820_REPORT_OUT);
      008728 90 0A EB         [24] 1818 	mov	dptr,#_send_keyboard_report_changed_10001_396
      00872B E0               [24] 1819 	movx	a,@dptr
      00872C 60 09            [24] 1820 	jz	00111$
      00872E 90 0D D0         [24] 1821 	mov	dptr,#_actual_keyboard_report
      008731 75 F0 00         [24] 1822 	mov	b, #0x00
                                   1823 ;	quantum/action_util.c:538: }
      008734 02 73 06         [24] 1824 	ljmp	_host_keyboard_send
      008737                       1825 00111$:
      008737 22               [24] 1826 	ret
                                   1827 ;------------------------------------------------------------
                                   1828 ;Allocation info for local variables in function 'get_mods'
                                   1829 ;------------------------------------------------------------
                                   1830 ;	quantum/action_util.c:544: uint8_t get_mods(void) {
                                   1831 ;	-----------------------------------------
                                   1832 ;	 function get_mods
                                   1833 ;	-----------------------------------------
      008738                       1834 _get_mods:
      008738 C0 07            [24] 1835 	push	ar7
                                   1836 ;	quantum/action_util.c:549: ;
      00873A 90 09 B2         [24] 1837 	mov	dptr,#_owned_mods
      00873D E0               [24] 1838 	movx	a,@dptr
      00873E FF               [12] 1839 	mov	r7,a
      00873F 90 0D CE         [24] 1840 	mov	dptr,#_real_mods
      008742 12 81 E9         [24] 1841 	lcall	_ak820_outline_0140
                                   1842 ;	quantum/action_util.c:550: }
      008745 D0 07            [24] 1843 	pop	ar7
      008747 22               [24] 1844 	ret
                                   1845 ;------------------------------------------------------------
                                   1846 ;Allocation info for local variables in function 'add_mods'
                                   1847 ;------------------------------------------------------------
                                   1848 ;mods          Allocated with name '_add_mods_mods_10000_404'
                                   1849 ;------------------------------------------------------------
                                   1850 ;	quantum/action_util.c:555: void add_mods(uint8_t mods) {
                                   1851 ;	-----------------------------------------
                                   1852 ;	 function clear_mods
                                   1853 ;	-----------------------------------------
      008748                       1854 _clear_mods:
                                   1855 ;	quantum/action_util.c:577: real_mods = 0;
      008748 90 0D CE         [24] 1856 	mov	dptr,#_real_mods
      00874B E4               [12] 1857 	clr	a
      00874C F0               [24] 1858 	movx	@dptr,a
                                   1859 ;	quantum/action_util.c:578: }
      00874D 22               [24] 1860 	ret
                                   1861 ;------------------------------------------------------------
                                   1862 ;Allocation info for local variables in function 'get_weak_mods'
                                   1863 ;------------------------------------------------------------
                                   1864 ;	quantum/action_util.c:584: uint8_t get_weak_mods(void) {
                                   1865 ;	-----------------------------------------
                                   1866 ;	 function get_weak_mods
                                   1867 ;	-----------------------------------------
      00874E                       1868 _get_weak_mods:
      00874E C0 07            [24] 1869 	push	ar7
                                   1870 ;	quantum/action_util.c:589: ;
      008750 90 09 B3         [24] 1871 	mov	dptr,#_owned_weak_mods
      008753 E0               [24] 1872 	movx	a,@dptr
      008754 FF               [12] 1873 	mov	r7,a
      008755 90 0D CF         [24] 1874 	mov	dptr,#_weak_mods
      008758 12 81 E9         [24] 1875 	lcall	_ak820_outline_0140
                                   1876 ;	quantum/action_util.c:590: }
      00875B D0 07            [24] 1877 	pop	ar7
      00875D 22               [24] 1878 	ret
                                   1879 ;------------------------------------------------------------
                                   1880 ;Allocation info for local variables in function 'add_weak_mods'
                                   1881 ;------------------------------------------------------------
                                   1882 ;mods          Allocated with name '_add_weak_mods_mods_10000_414'
                                   1883 ;------------------------------------------------------------
                                   1884 ;	quantum/action_util.c:595: void add_weak_mods(uint8_t mods) {
                                   1885 ;	-----------------------------------------
                                   1886 ;	 function add_weak_mods
                                   1887 ;	-----------------------------------------
      00875E                       1888 _add_weak_mods:
      00875E E5 82            [12] 1889 	mov	a,dpl
      008760 90 0A EC         [24] 1890 	mov	dptr,#_add_weak_mods_mods_10000_414
      008763 F0               [24] 1891 	movx	@dptr,a
                                   1892 ;	quantum/action_util.c:596: weak_mods |= mods;
      008764 E0               [24] 1893 	movx	a,@dptr
      008765 FF               [12] 1894 	mov	r7,a
      008766 90 0D CF         [24] 1895 	mov	dptr,#_weak_mods
      008769 E0               [24] 1896 	movx	a,@dptr
      00876A 4F               [12] 1897 	orl	a,r7
      00876B F0               [24] 1898 	movx	@dptr,a
                                   1899 ;	quantum/action_util.c:597: }
      00876C 22               [24] 1900 	ret
                                   1901 ;------------------------------------------------------------
                                   1902 ;Allocation info for local variables in function 'del_weak_mods'
                                   1903 ;------------------------------------------------------------
                                   1904 ;mods          Allocated with name '_del_weak_mods_mods_10000_416'
                                   1905 ;------------------------------------------------------------
                                   1906 ;	quantum/action_util.c:602: void del_weak_mods(uint8_t mods) {
                                   1907 ;	-----------------------------------------
                                   1908 ;	 function del_weak_mods
                                   1909 ;	-----------------------------------------
      00876D                       1910 _del_weak_mods:
      00876D E5 82            [12] 1911 	mov	a,dpl
      00876F 90 0A ED         [24] 1912 	mov	dptr,#_del_weak_mods_mods_10000_416
      008772 F0               [24] 1913 	movx	@dptr,a
                                   1914 ;	quantum/action_util.c:603: weak_mods &= ~mods;
      008773 E0               [24] 1915 	movx	a,@dptr
      008774 F4               [12] 1916 	cpl	a
      008775 FF               [12] 1917 	mov	r7,a
      008776 90 0D CF         [24] 1918 	mov	dptr,#_weak_mods
      008779 E0               [24] 1919 	movx	a,@dptr
      00877A 5F               [12] 1920 	anl	a,r7
      00877B F0               [24] 1921 	movx	@dptr,a
                                   1922 ;	quantum/action_util.c:604: }
      00877C 22               [24] 1923 	ret
                                   1924 ;------------------------------------------------------------
                                   1925 ;Allocation info for local variables in function 'set_weak_mods'
                                   1926 ;------------------------------------------------------------
                                   1927 ;mods          Allocated with name '_set_weak_mods_mods_10000_418'
                                   1928 ;------------------------------------------------------------
                                   1929 ;	quantum/action_util.c:609: void set_weak_mods(uint8_t mods) {
                                   1930 ;	-----------------------------------------
                                   1931 ;	 function clear_weak_mods
                                   1932 ;	-----------------------------------------
      00877D                       1933 _clear_weak_mods:
                                   1934 ;	quantum/action_util.c:617: weak_mods = 0;
      00877D 90 0D CF         [24] 1935 	mov	dptr,#_weak_mods
      008780 E4               [12] 1936 	clr	a
      008781 F0               [24] 1937 	movx	@dptr,a
                                   1938 ;	quantum/action_util.c:618: }
      008782 22               [24] 1939 	ret
                                   1940 ;------------------------------------------------------------
                                   1941 ;Allocation info for local variables in function 'oneshot_locked_mods_changed_user'
                                   1942 ;------------------------------------------------------------
                                   1943 ;mods          Allocated with name '_oneshot_locked_mods_changed_user_mods_10000_422'
                                   1944 ;------------------------------------------------------------
                                   1945 ;	quantum/action_util.c:700: __attribute__((weak)) void oneshot_locked_mods_changed_user(uint8_t mods) {}
                                   1946 ;	-----------------------------------------
                                   1947 	.area CSEG    (CODE)
                                   1948 	.area CONST   (CODE)
                                   1949 	.area XINIT   (CODE)
      00C700                       1950 __xinit__real_mods:
      00C700 00                    1951 	.db #0x00	; 0
      00C701                       1952 __xinit__weak_mods:
      00C701 00                    1953 	.db #0x00	; 0
      00C702                       1954 __xinit__actual_keyboard_report:
      00C702 00                    1955 	.db #0x00	; 0
      00C703 00                    1956 	.db #0x00	; 0
      00C704 00                    1957 	.db #0x00	; 0
      00C705 00                    1958 	.db #0x00	; 0
      00C706 00                    1959 	.db #0x00	; 0
      00C707 00                    1960 	.db #0x00	; 0
      00C708 00                    1961 	.db #0x00	; 0
      00C709 00                    1962 	.db #0x00	; 0
      00C70A 00                    1963 	.db 0x00
      00C70B 00                    1964 	.db 0x00
      00C70C 00                    1965 	.db 0x00
      00C70D 00                    1966 	.db 0x00
      00C70E 00                    1967 	.db 0x00
      00C70F 00                    1968 	.db 0x00
      00C710 00                    1969 	.db 0x00
      00C711 00                    1970 	.db 0x00
      00C712 00                    1971 	.db 0x00
      00C713 00                    1972 	.db 0x00
      00C714 00                    1973 	.db 0x00
      00C715 00                    1974 	.db 0x00
      00C716 00                    1975 	.db 0x00
      00C717 00                    1976 	.db 0x00
      00C718 00                    1977 	.db 0x00
      00C719 00                    1978 	.db 0x00
      00C71A 00                    1979 	.db 0x00
      00C71B 00                    1980 	.db 0x00
      00C71C 00                    1981 	.db 0x00
      00C71D 00                    1982 	.db 0x00
      00C71E 00                    1983 	.db 0x00
      00C71F 00                    1984 	.db 0x00
      00C720 00                    1985 	.db 0x00
      00C721 00                    1986 	.db 0x00
                                   1987 	.area CABS    (ABS,CODE)
                                   1988 
                                   1989 ; Experimental exact instruction outlining.
                                   1990 	.globl _ak820_outline_0014
                                   1991 	.globl _ak820_outline_0029
                                   1992 	.globl _ak820_outline_0051
                                   1993 	.globl _ak820_outline_0057
                                   1994 	.globl _ak820_outline_0060
                                   1995 	.globl _ak820_outline_0063
                                   1996 	.globl _ak820_outline_0064
                                   1997 	.globl _ak820_outline_0065
                                   1998 	.globl _ak820_outline_0068
                                   1999 	.globl _ak820_outline_0074
                                   2000 	.globl _ak820_outline_0103
                                   2001 	.globl _ak820_outline_0104
                                   2002 	.globl _ak820_outline_0113
                                   2003 	.globl _ak820_outline_0118
                                   2004 	.globl _ak820_outline_0122
                                   2005 	.globl _ak820_outline_0123
                                   2006 	.globl _ak820_outline_0124
                                   2007 	.globl _ak820_outline_0130
                                   2008 	.globl _ak820_outline_0131
                                   2009 	.globl _ak820_outline_0136
                                   2010 	.globl _ak820_outline_0140
                                   2011 	.globl _ak820_outline_0155
                                   2012 	.globl _ak820_outline_0156
                                   2013 	.globl _ak820_outline_0160
                                   2014 	.globl _ak820_outline_0171
                                   2015 	.globl _ak820_outline_0178
                                   2016 	.globl _ak820_outline_0183
                                   2017 	.globl _ak820_outline_0184
                                   2018 	.globl _ak820_outline_0186
                                   2019 
                                   2020 	.area CSEG (CODE)
                                   2021 ; function ak820_outline_0029
      008783                       2022 _ak820_outline_0029:
      008783 EF               [12] 2023 	mov	a,r7
      008784 24 C4            [12] 2024 	add	a,#_key_refs
      008786 FD               [12] 2025 	mov	r5,a
      008787 E4               [12] 2026 	clr	a
      008788 34 09            [12] 2027 	addc	a,#(_key_refs>>8)
      00878A FE               [12] 2028 	mov	r6,a
      00878B 8D 82            [24] 2029 	mov	dpl,r5
      00878D 8E 83            [24] 2030 	mov	dph,r6
      00878F E0               [24] 2031 	movx	a,@dptr
      008790 22               [24] 2032 	ret
                                   2033 
                                   2034 	.area CSEG (CODE)
                                   2035 ; function ak820_outline_0064
      008791                       2036 _ak820_outline_0064:
      008791 89 82            [24] 2037 	mov	dpl,r1
      008793 8A 83            [24] 2038 	mov	dph,r2
      008795 E8               [12] 2039 	mov	a,r0
      008796 F0               [24] 2040 	movx	@dptr,a
      008797 22               [24] 2041 	ret
                                   2042 
                                   2043 	.area CSEG (CODE)
                                   2044 ; function ak820_outline_0068
      008798                       2045 _ak820_outline_0068:
      008798 24 9F            [12] 2046 	add	a,#_usage_order
      00879A F5 82            [12] 2047 	mov	dpl,a
      00879C E4               [12] 2048 	clr	a
      00879D 34 0A            [12] 2049 	addc	a,#(_usage_order>>8)
      00879F F5 83            [12] 2050 	mov	dph,a
      0087A1 22               [24] 2051 	ret
                                   2052 
                                   2053 	.area CSEG (CODE)
                                   2054 ; function ak820_outline_0074
      0087A2                       2055 _ak820_outline_0074:
      0087A2 EB               [12] 2056 	mov	a,r3
      0087A3 24 81            [12] 2057 	add	a,#_usage_refs
      0087A5 F9               [12] 2058 	mov	r1,a
      0087A6 E4               [12] 2059 	clr	a
      0087A7 34 0A            [12] 2060 	addc	a,#(_usage_refs>>8)
      0087A9 FA               [12] 2061 	mov	r2,a
      0087AA 89 82            [24] 2062 	mov	dpl,r1
      0087AC 8A 83            [24] 2063 	mov	dph,r2
      0087AE E0               [24] 2064 	movx	a,@dptr
      0087AF F8               [12] 2065 	mov	r0,a
      0087B0 22               [24] 2066 	ret
                                   2067 
                                   2068 	.area CSEG (CODE)
                                   2069 ; function ak820_outline_0113
      0087B1                       2070 _ak820_outline_0113:
      0087B1 F0               [24] 2071 	movx	@dptr,a
      0087B2 E0               [24] 2072 	movx	a,@dptr
      0087B3 FF               [12] 2073 	mov	r7,a
      0087B4 90 09 BC         [24] 2074 	mov	dptr,#_change_owned_PARM_2
      0087B7 22               [24] 2075 	ret
                                   2076 
                                   2077 	.area CSEG (CODE)
                                   2078 ; function ak820_outline_0118
      0087B8                       2079 _ak820_outline_0118:
      0087B8 8D 82            [24] 2080 	mov	dpl,r5
      0087BA 8E 83            [24] 2081 	mov	dph,r6
      0087BC F0               [24] 2082 	movx	@dptr,a
      0087BD 22               [24] 2083 	ret
                                   2084 
                                   2085 	.area CSEG (CODE)
                                   2086 ; function ak820_outline_0124
      0087BE                       2087 _ak820_outline_0124:
      0087BE 24 9F            [12] 2088 	add	a,#_usage_order
      0087C0 F5 82            [12] 2089 	mov	dpl,a
      0087C2 EF               [12] 2090 	mov	a,r7
      0087C3 34 0A            [12] 2091 	addc	a,#(_usage_order>>8)
      0087C5 F5 83            [12] 2092 	mov	dph,a
      0087C7 E0               [24] 2093 	movx	a,@dptr
      0087C8 22               [24] 2094 	ret
                                   2095 
                                   2096 	.area CSEG (CODE)
                                   2097 ; function ak820_outline_0130
      0087C9                       2098 _ak820_outline_0130:
      0087C9 F0               [24] 2099 	movx	@dptr,a
      0087CA E0               [24] 2100 	movx	a,@dptr
      0087CB FF               [12] 2101 	mov	r7,a
      0087CC 90 09 B8         [24] 2102 	mov	dptr,#_ak820_macro_change_PARM_2
      0087CF F0               [24] 2103 	movx	@dptr,a
      0087D0 90 09 B9         [24] 2104 	mov	dptr,#_ak820_macro_change_PARM_3
      0087D3 22               [24] 2105 	ret
                                   2106 
                                   2107 	.area CSEG (CODE)
                                   2108 ; function ak820_outline_0171
      0087D4                       2109 _ak820_outline_0171:
      0087D4 90 08 30         [24] 2110 	mov	dptr,#_add_key_to_report_PARM_2
      0087D7 EF               [12] 2111 	mov	a,r7
      0087D8 F0               [24] 2112 	movx	@dptr,a
      0087D9 90 0D D0         [24] 2113 	mov	dptr,#_actual_keyboard_report
      0087DC 22               [24] 2114 	ret
                                   2115 
                                   2116 	.area CSEG (CODE)
                                   2117 ; function ak820_outline_0186
      0087DD                       2118 _ak820_outline_0186:
      0087DD 8D 82            [24] 2119 	mov	dpl,r5
      0087DF 8F 83            [24] 2120 	mov	dph,r7
      0087E1 22               [24] 2121 	ret
