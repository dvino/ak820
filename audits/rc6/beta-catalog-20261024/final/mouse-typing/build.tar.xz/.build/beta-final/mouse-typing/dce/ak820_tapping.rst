                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_tapping
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _get_repeat_key_count
                                     12 	.globl _del_owned_mods
                                     13 	.globl _add_owned_mods
                                     14 	.globl _send_keyboard_report
                                     15 	.globl _layer_hold_off
                                     16 	.globl _layer_hold_on
                                     17 	.globl _unregister_mods
                                     18 	.globl _register_mods
                                     19 	.globl _process_record
                                     20 	.globl _ADC_START
                                     21 	.globl _S0_R_FIFO
                                     22 	.globl _S0_T_FIFO
                                     23 	.globl _S0_FREE
                                     24 	.globl _S0_IF_BYTE
                                     25 	.globl _S0_IF_FIRST
                                     26 	.globl _S0_IF_OV
                                     27 	.globl _S0_FST_ACT
                                     28 	.globl _CP_RL2
                                     29 	.globl _C_T2
                                     30 	.globl _TR2
                                     31 	.globl _EXEN2
                                     32 	.globl _TCLK
                                     33 	.globl _RCLK
                                     34 	.globl _EXF2
                                     35 	.globl _CAP1F
                                     36 	.globl _TF2
                                     37 	.globl _RI
                                     38 	.globl _TI
                                     39 	.globl _RB8
                                     40 	.globl _TB8
                                     41 	.globl _REN
                                     42 	.globl _SM2
                                     43 	.globl _SM1
                                     44 	.globl _SM0
                                     45 	.globl _IT0
                                     46 	.globl _IE0
                                     47 	.globl _IT1
                                     48 	.globl _IE1
                                     49 	.globl _TR0
                                     50 	.globl _TF0
                                     51 	.globl _TR1
                                     52 	.globl _TF1
                                     53 	.globl _P4_0
                                     54 	.globl _P4_1
                                     55 	.globl _P4_2
                                     56 	.globl _P4_3
                                     57 	.globl _P4_4
                                     58 	.globl _P4_5
                                     59 	.globl _P4_6
                                     60 	.globl _RXD
                                     61 	.globl _TXD
                                     62 	.globl _INT0
                                     63 	.globl _INT1
                                     64 	.globl _T0
                                     65 	.globl _T1
                                     66 	.globl _MOSI1
                                     67 	.globl _MISO1
                                     68 	.globl _SCK1
                                     69 	.globl _P3_0
                                     70 	.globl _P3_1
                                     71 	.globl _P3_2
                                     72 	.globl _P3_3
                                     73 	.globl _P3_4
                                     74 	.globl _P3_5
                                     75 	.globl _P3_6
                                     76 	.globl _P3_7
                                     77 	.globl _CAP1_
                                     78 	.globl _T2_
                                     79 	.globl _CAP2_
                                     80 	.globl _T2EX_
                                     81 	.globl _RXD1
                                     82 	.globl _TXD1
                                     83 	.globl _P2_0
                                     84 	.globl _P2_1
                                     85 	.globl _P2_2
                                     86 	.globl _P2_3
                                     87 	.globl _P2_4
                                     88 	.globl _P2_5
                                     89 	.globl _P2_6
                                     90 	.globl _P2_7
                                     91 	.globl _AIN0
                                     92 	.globl _AIN1
                                     93 	.globl _AIN2
                                     94 	.globl _AIN3
                                     95 	.globl _AIN4
                                     96 	.globl _AIN5
                                     97 	.globl _AIN6
                                     98 	.globl _AIN7
                                     99 	.globl _CAP1
                                    100 	.globl _T2
                                    101 	.globl _CAP2
                                    102 	.globl _T2EX
                                    103 	.globl _INT0_
                                    104 	.globl _SCS
                                    105 	.globl _MOSI
                                    106 	.globl _MISO
                                    107 	.globl _SCK
                                    108 	.globl _RXD1_
                                    109 	.globl _TXD1_
                                    110 	.globl _P1_0
                                    111 	.globl _P1_1
                                    112 	.globl _P1_2
                                    113 	.globl _P1_3
                                    114 	.globl _P1_4
                                    115 	.globl _P1_5
                                    116 	.globl _P1_6
                                    117 	.globl _P1_7
                                    118 	.globl _AIN8
                                    119 	.globl _AIN9
                                    120 	.globl _AIN10
                                    121 	.globl _AIN11
                                    122 	.globl _AIN12
                                    123 	.globl _AIN13
                                    124 	.globl _RXD_
                                    125 	.globl _TXD_
                                    126 	.globl _SCL0
                                    127 	.globl _SDA0
                                    128 	.globl _P0_0
                                    129 	.globl _P0_1
                                    130 	.globl _P0_2
                                    131 	.globl _P0_3
                                    132 	.globl _P0_4
                                    133 	.globl _P0_5
                                    134 	.globl _P0_6
                                    135 	.globl _P0_7
                                    136 	.globl _IE_SPI0
                                    137 	.globl _IE_USB
                                    138 	.globl _IE_ADC
                                    139 	.globl _IE_UART1
                                    140 	.globl _IE_PWM_I2C
                                    141 	.globl _IE_GPIO
                                    142 	.globl _IE_WDOG
                                    143 	.globl _PX0
                                    144 	.globl _PT0
                                    145 	.globl _PX1
                                    146 	.globl _PT1
                                    147 	.globl _PS
                                    148 	.globl _PT2
                                    149 	.globl _PL_FLAG
                                    150 	.globl _PH_FLAG
                                    151 	.globl _EX0
                                    152 	.globl _ET0
                                    153 	.globl _EX1
                                    154 	.globl _ET1
                                    155 	.globl _ES
                                    156 	.globl _ET2
                                    157 	.globl _E_DIS
                                    158 	.globl _EA
                                    159 	.globl _P
                                    160 	.globl _F1
                                    161 	.globl _OV
                                    162 	.globl _RS0
                                    163 	.globl _RS1
                                    164 	.globl _F0
                                    165 	.globl _AC
                                    166 	.globl _CY
                                    167 	.globl _I2CS_INT_ST
                                    168 	.globl _I2CX_INT
                                    169 	.globl _LED_STATUS
                                    170 	.globl _LED_DMA_H
                                    171 	.globl _LED_DMA_L
                                    172 	.globl _LED_DMA
                                    173 	.globl _LED_PWM_OE
                                    174 	.globl _LED_COMMON
                                    175 	.globl _ADC_CHAN
                                    176 	.globl _ADC_DAT_H
                                    177 	.globl _ADC_DAT_L
                                    178 	.globl _ADC_DAT
                                    179 	.globl _ADC_CTRL
                                    180 	.globl _SPI1_CK_SE
                                    181 	.globl _SPI1_CTRL
                                    182 	.globl _SPI1_DATA
                                    183 	.globl _SPI1_STAT
                                    184 	.globl _SIF1
                                    185 	.globl _SBAUD1
                                    186 	.globl _SBUF1
                                    187 	.globl _SCON1
                                    188 	.globl _SPI0_SETUP
                                    189 	.globl _SPI0_CK_SE
                                    190 	.globl _SPI0_CTRL
                                    191 	.globl _SPI0_DATA
                                    192 	.globl _SPI0_STAT
                                    193 	.globl _T2CAP1H
                                    194 	.globl _T2CAP1L
                                    195 	.globl _T2CAP1
                                    196 	.globl _TH2
                                    197 	.globl _TL2
                                    198 	.globl _T2COUNT
                                    199 	.globl _RCAP2H
                                    200 	.globl _RCAP2L
                                    201 	.globl _RCAP2
                                    202 	.globl _T2MOD
                                    203 	.globl _T2CON
                                    204 	.globl _SBUF
                                    205 	.globl _SCON
                                    206 	.globl _TH1
                                    207 	.globl _TH0
                                    208 	.globl _TL1
                                    209 	.globl _TL0
                                    210 	.globl _TMOD
                                    211 	.globl _TCON
                                    212 	.globl _XBUS_AUX
                                    213 	.globl _P7
                                    214 	.globl _P6_DIR
                                    215 	.globl _P6_OUT_PU
                                    216 	.globl _P6_IN
                                    217 	.globl _P5_DIR
                                    218 	.globl _P5_OUT_PU
                                    219 	.globl _P5_IN
                                    220 	.globl _P4_LED_KEY
                                    221 	.globl _P4_DIR_PU
                                    222 	.globl _P4_MOD_OC
                                    223 	.globl _P4
                                    224 	.globl _P3_DIR_PU
                                    225 	.globl _P3_MOD_OC
                                    226 	.globl _P3
                                    227 	.globl _P2_DIR_PU
                                    228 	.globl _P2_MOD_OC
                                    229 	.globl _P2
                                    230 	.globl _P1_DIR_PU
                                    231 	.globl _P1_MOD_OC
                                    232 	.globl _P1
                                    233 	.globl _P0_DIR_PU
                                    234 	.globl _P0_MOD_OC
                                    235 	.globl _P0
                                    236 	.globl _ROM_CTRL
                                    237 	.globl _ROM_DATA_HH
                                    238 	.globl _ROM_DATA_HL
                                    239 	.globl _ROM_DATA_HI
                                    240 	.globl _ROM_ADDR_H
                                    241 	.globl _ROM_ADDR_L
                                    242 	.globl _ROM_ADDR
                                    243 	.globl _GPIO_IE
                                    244 	.globl _IP_EX
                                    245 	.globl _IE_EX
                                    246 	.globl _IP
                                    247 	.globl _IE
                                    248 	.globl _WDOG_COUNT
                                    249 	.globl _RESET_KEEP
                                    250 	.globl _WAKE_CTRL
                                    251 	.globl _CLOCK_CFG
                                    252 	.globl _POWER_CFG
                                    253 	.globl _PCON
                                    254 	.globl _GLOBAL_CFG
                                    255 	.globl _SAFE_MOD
                                    256 	.globl _DPH
                                    257 	.globl _DPL
                                    258 	.globl _SP
                                    259 	.globl _A_INV
                                    260 	.globl _B
                                    261 	.globl _ACC
                                    262 	.globl _PSW
                                    263 	.globl _ak820_oneshot_target
                                    264 	.globl _ak820_oneshot_process_PARM_3
                                    265 	.globl _ak820_oneshot_process_PARM_2
                                    266 	.globl _ak820_oneshot_consumed
                                    267 	.globl _ak820_oneshot_mods
                                    268 	.globl _ak820_tapping_source_PARM_1
                                    269 	.globl _ak820_tapping_source
                                    270 	.globl _ak820_tapping_before
                                    271 	.globl _ak820_tapping_process
                                    272 	.globl _ak820_tapping_cancel
                                    273 	.globl _ak820_oneshot_process
                                    274 ;--------------------------------------------------------
                                    275 ; special function registers
                                    276 ;--------------------------------------------------------
                                    277 	.area RSEG    (ABS,DATA)
      000000                        278 	.org 0x0000
                           0000D0   279 _PSW	=	0x00d0
                           0000E0   280 _ACC	=	0x00e0
                           0000F0   281 _B	=	0x00f0
                           0000FD   282 _A_INV	=	0x00fd
                           000081   283 _SP	=	0x0081
                           000082   284 _DPL	=	0x0082
                           000083   285 _DPH	=	0x0083
                           0000A1   286 _SAFE_MOD	=	0x00a1
                           0000B1   287 _GLOBAL_CFG	=	0x00b1
                           000087   288 _PCON	=	0x0087
                           0000BA   289 _POWER_CFG	=	0x00ba
                           0000B9   290 _CLOCK_CFG	=	0x00b9
                           0000A9   291 _WAKE_CTRL	=	0x00a9
                           0000FE   292 _RESET_KEEP	=	0x00fe
                           0000FF   293 _WDOG_COUNT	=	0x00ff
                           0000A8   294 _IE	=	0x00a8
                           0000B8   295 _IP	=	0x00b8
                           0000E8   296 _IE_EX	=	0x00e8
                           0000E9   297 _IP_EX	=	0x00e9
                           0000B2   298 _GPIO_IE	=	0x00b2
                           008584   299 _ROM_ADDR	=	0x8584
                           000084   300 _ROM_ADDR_L	=	0x0084
                           000085   301 _ROM_ADDR_H	=	0x0085
                           008F8E   302 _ROM_DATA_HI	=	0x8f8e
                           00008E   303 _ROM_DATA_HL	=	0x008e
                           00008F   304 _ROM_DATA_HH	=	0x008f
                           000086   305 _ROM_CTRL	=	0x0086
                           000080   306 _P0	=	0x0080
                           0000C4   307 _P0_MOD_OC	=	0x00c4
                           0000C5   308 _P0_DIR_PU	=	0x00c5
                           000090   309 _P1	=	0x0090
                           000092   310 _P1_MOD_OC	=	0x0092
                           000093   311 _P1_DIR_PU	=	0x0093
                           0000A0   312 _P2	=	0x00a0
                           000094   313 _P2_MOD_OC	=	0x0094
                           000095   314 _P2_DIR_PU	=	0x0095
                           0000B0   315 _P3	=	0x00b0
                           000096   316 _P3_MOD_OC	=	0x0096
                           000097   317 _P3_DIR_PU	=	0x0097
                           0000C0   318 _P4	=	0x00c0
                           0000C2   319 _P4_MOD_OC	=	0x00c2
                           0000C3   320 _P4_DIR_PU	=	0x00c3
                           0000C1   321 _P4_LED_KEY	=	0x00c1
                           0000AA   322 _P5_IN	=	0x00aa
                           0000AB   323 _P5_OUT_PU	=	0x00ab
                           0000AC   324 _P5_DIR	=	0x00ac
                           0000AD   325 _P6_IN	=	0x00ad
                           0000AE   326 _P6_OUT_PU	=	0x00ae
                           0000AF   327 _P6_DIR	=	0x00af
                           0000F1   328 _P7	=	0x00f1
                           0000A2   329 _XBUS_AUX	=	0x00a2
                           000088   330 _TCON	=	0x0088
                           000089   331 _TMOD	=	0x0089
                           00008A   332 _TL0	=	0x008a
                           00008B   333 _TL1	=	0x008b
                           00008C   334 _TH0	=	0x008c
                           00008D   335 _TH1	=	0x008d
                           000098   336 _SCON	=	0x0098
                           000099   337 _SBUF	=	0x0099
                           0000C8   338 _T2CON	=	0x00c8
                           0000C9   339 _T2MOD	=	0x00c9
                           00CBCA   340 _RCAP2	=	0xcbca
                           0000CA   341 _RCAP2L	=	0x00ca
                           0000CB   342 _RCAP2H	=	0x00cb
                           00CDCC   343 _T2COUNT	=	0xcdcc
                           0000CC   344 _TL2	=	0x00cc
                           0000CD   345 _TH2	=	0x00cd
                           00CFCE   346 _T2CAP1	=	0xcfce
                           0000CE   347 _T2CAP1L	=	0x00ce
                           0000CF   348 _T2CAP1H	=	0x00cf
                           0000F8   349 _SPI0_STAT	=	0x00f8
                           0000F9   350 _SPI0_DATA	=	0x00f9
                           0000FA   351 _SPI0_CTRL	=	0x00fa
                           0000FB   352 _SPI0_CK_SE	=	0x00fb
                           0000FC   353 _SPI0_SETUP	=	0x00fc
                           0000BC   354 _SCON1	=	0x00bc
                           0000BD   355 _SBUF1	=	0x00bd
                           0000BE   356 _SBAUD1	=	0x00be
                           0000BF   357 _SIF1	=	0x00bf
                           0000B4   358 _SPI1_STAT	=	0x00b4
                           0000B5   359 _SPI1_DATA	=	0x00b5
                           0000B6   360 _SPI1_CTRL	=	0x00b6
                           0000B7   361 _SPI1_CK_SE	=	0x00b7
                           0000F3   362 _ADC_CTRL	=	0x00f3
                           00F5F4   363 _ADC_DAT	=	0xf5f4
                           0000F4   364 _ADC_DAT_L	=	0x00f4
                           0000F5   365 _ADC_DAT_H	=	0x00f5
                           0000F6   366 _ADC_CHAN	=	0x00f6
                           0000A6   367 _LED_COMMON	=	0x00a6
                           0000A7   368 _LED_PWM_OE	=	0x00a7
                           00C7C6   369 _LED_DMA	=	0xc7c6
                           0000C6   370 _LED_DMA_L	=	0x00c6
                           0000C7   371 _LED_DMA_H	=	0x00c7
                           0000F7   372 _LED_STATUS	=	0x00f7
                           0000B3   373 _I2CX_INT	=	0x00b3
                           0000BB   374 _I2CS_INT_ST	=	0x00bb
                                    375 ;--------------------------------------------------------
                                    376 ; special function bits
                                    377 ;--------------------------------------------------------
                                    378 	.area RSEG    (ABS,DATA)
      000000                        379 	.org 0x0000
                           0000D7   380 _CY	=	0x00d7
                           0000D6   381 _AC	=	0x00d6
                           0000D5   382 _F0	=	0x00d5
                           0000D4   383 _RS1	=	0x00d4
                           0000D3   384 _RS0	=	0x00d3
                           0000D2   385 _OV	=	0x00d2
                           0000D1   386 _F1	=	0x00d1
                           0000D0   387 _P	=	0x00d0
                           0000AF   388 _EA	=	0x00af
                           0000AE   389 _E_DIS	=	0x00ae
                           0000AD   390 _ET2	=	0x00ad
                           0000AC   391 _ES	=	0x00ac
                           0000AB   392 _ET1	=	0x00ab
                           0000AA   393 _EX1	=	0x00aa
                           0000A9   394 _ET0	=	0x00a9
                           0000A8   395 _EX0	=	0x00a8
                           0000BF   396 _PH_FLAG	=	0x00bf
                           0000BE   397 _PL_FLAG	=	0x00be
                           0000BD   398 _PT2	=	0x00bd
                           0000BC   399 _PS	=	0x00bc
                           0000BB   400 _PT1	=	0x00bb
                           0000BA   401 _PX1	=	0x00ba
                           0000B9   402 _PT0	=	0x00b9
                           0000B8   403 _PX0	=	0x00b8
                           0000EF   404 _IE_WDOG	=	0x00ef
                           0000EE   405 _IE_GPIO	=	0x00ee
                           0000ED   406 _IE_PWM_I2C	=	0x00ed
                           0000EC   407 _IE_UART1	=	0x00ec
                           0000EB   408 _IE_ADC	=	0x00eb
                           0000E9   409 _IE_USB	=	0x00e9
                           0000E8   410 _IE_SPI0	=	0x00e8
                           000087   411 _P0_7	=	0x0087
                           000086   412 _P0_6	=	0x0086
                           000085   413 _P0_5	=	0x0085
                           000084   414 _P0_4	=	0x0084
                           000083   415 _P0_3	=	0x0083
                           000082   416 _P0_2	=	0x0082
                           000081   417 _P0_1	=	0x0081
                           000080   418 _P0_0	=	0x0080
                           000081   419 _SDA0	=	0x0081
                           000080   420 _SCL0	=	0x0080
                           000083   421 _TXD_	=	0x0083
                           000082   422 _RXD_	=	0x0082
                           000085   423 _AIN13	=	0x0085
                           000084   424 _AIN12	=	0x0084
                           000083   425 _AIN11	=	0x0083
                           000082   426 _AIN10	=	0x0082
                           000081   427 _AIN9	=	0x0081
                           000080   428 _AIN8	=	0x0080
                           000097   429 _P1_7	=	0x0097
                           000096   430 _P1_6	=	0x0096
                           000095   431 _P1_5	=	0x0095
                           000094   432 _P1_4	=	0x0094
                           000093   433 _P1_3	=	0x0093
                           000092   434 _P1_2	=	0x0092
                           000091   435 _P1_1	=	0x0091
                           000090   436 _P1_0	=	0x0090
                           000097   437 _TXD1_	=	0x0097
                           000096   438 _RXD1_	=	0x0096
                           000097   439 _SCK	=	0x0097
                           000096   440 _MISO	=	0x0096
                           000095   441 _MOSI	=	0x0095
                           000094   442 _SCS	=	0x0094
                           000092   443 _INT0_	=	0x0092
                           000091   444 _T2EX	=	0x0091
                           000091   445 _CAP2	=	0x0091
                           000090   446 _T2	=	0x0090
                           000090   447 _CAP1	=	0x0090
                           000097   448 _AIN7	=	0x0097
                           000096   449 _AIN6	=	0x0096
                           000095   450 _AIN5	=	0x0095
                           000094   451 _AIN4	=	0x0094
                           000093   452 _AIN3	=	0x0093
                           000092   453 _AIN2	=	0x0092
                           000091   454 _AIN1	=	0x0091
                           000090   455 _AIN0	=	0x0090
                           0000A7   456 _P2_7	=	0x00a7
                           0000A6   457 _P2_6	=	0x00a6
                           0000A5   458 _P2_5	=	0x00a5
                           0000A4   459 _P2_4	=	0x00a4
                           0000A3   460 _P2_3	=	0x00a3
                           0000A2   461 _P2_2	=	0x00a2
                           0000A1   462 _P2_1	=	0x00a1
                           0000A0   463 _P2_0	=	0x00a0
                           0000A7   464 _TXD1	=	0x00a7
                           0000A6   465 _RXD1	=	0x00a6
                           0000A5   466 _T2EX_	=	0x00a5
                           0000A5   467 _CAP2_	=	0x00a5
                           0000A4   468 _T2_	=	0x00a4
                           0000A4   469 _CAP1_	=	0x00a4
                           0000B7   470 _P3_7	=	0x00b7
                           0000B6   471 _P3_6	=	0x00b6
                           0000B5   472 _P3_5	=	0x00b5
                           0000B4   473 _P3_4	=	0x00b4
                           0000B3   474 _P3_3	=	0x00b3
                           0000B2   475 _P3_2	=	0x00b2
                           0000B1   476 _P3_1	=	0x00b1
                           0000B0   477 _P3_0	=	0x00b0
                           0000B7   478 _SCK1	=	0x00b7
                           0000B6   479 _MISO1	=	0x00b6
                           0000B5   480 _MOSI1	=	0x00b5
                           0000B5   481 _T1	=	0x00b5
                           0000B4   482 _T0	=	0x00b4
                           0000B3   483 _INT1	=	0x00b3
                           0000B2   484 _INT0	=	0x00b2
                           0000B1   485 _TXD	=	0x00b1
                           0000B0   486 _RXD	=	0x00b0
                           0000C6   487 _P4_6	=	0x00c6
                           0000C5   488 _P4_5	=	0x00c5
                           0000C4   489 _P4_4	=	0x00c4
                           0000C3   490 _P4_3	=	0x00c3
                           0000C2   491 _P4_2	=	0x00c2
                           0000C1   492 _P4_1	=	0x00c1
                           0000C0   493 _P4_0	=	0x00c0
                           00008F   494 _TF1	=	0x008f
                           00008E   495 _TR1	=	0x008e
                           00008D   496 _TF0	=	0x008d
                           00008C   497 _TR0	=	0x008c
                           00008B   498 _IE1	=	0x008b
                           00008A   499 _IT1	=	0x008a
                           000089   500 _IE0	=	0x0089
                           000088   501 _IT0	=	0x0088
                           00009F   502 _SM0	=	0x009f
                           00009E   503 _SM1	=	0x009e
                           00009D   504 _SM2	=	0x009d
                           00009C   505 _REN	=	0x009c
                           00009B   506 _TB8	=	0x009b
                           00009A   507 _RB8	=	0x009a
                           000099   508 _TI	=	0x0099
                           000098   509 _RI	=	0x0098
                           0000CF   510 _TF2	=	0x00cf
                           0000CF   511 _CAP1F	=	0x00cf
                           0000CE   512 _EXF2	=	0x00ce
                           0000CD   513 _RCLK	=	0x00cd
                           0000CC   514 _TCLK	=	0x00cc
                           0000CB   515 _EXEN2	=	0x00cb
                           0000CA   516 _TR2	=	0x00ca
                           0000C9   517 _C_T2	=	0x00c9
                           0000C8   518 _CP_RL2	=	0x00c8
                           0000FF   519 _S0_FST_ACT	=	0x00ff
                           0000FE   520 _S0_IF_OV	=	0x00fe
                           0000FD   521 _S0_IF_FIRST	=	0x00fd
                           0000FC   522 _S0_IF_BYTE	=	0x00fc
                           0000FB   523 _S0_FREE	=	0x00fb
                           0000FA   524 _S0_T_FIFO	=	0x00fa
                           0000F8   525 _S0_R_FIFO	=	0x00f8
                           0000F7   526 _ADC_START	=	0x00f7
                                    527 ;--------------------------------------------------------
                                    528 ; overlayable register banks
                                    529 ;--------------------------------------------------------
                                    530 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        531 	.ds 8
                                    532 ;--------------------------------------------------------
                                    533 ; internal ram data
                                    534 ;--------------------------------------------------------
                                    535 	.area DSEG    (DATA)
                                    536 ;--------------------------------------------------------
                                    537 ; overlayable items in internal ram
                                    538 ;--------------------------------------------------------
                                    539 ;--------------------------------------------------------
                                    540 ; indirectly addressable internal ram data
                                    541 ;--------------------------------------------------------
                                    542 	.area ISEG    (DATA)
                                    543 ;--------------------------------------------------------
                                    544 ; absolute internal ram data
                                    545 ;--------------------------------------------------------
                                    546 	.area IABS    (ABS,DATA)
                                    547 	.area IABS    (ABS,DATA)
                                    548 ;--------------------------------------------------------
                                    549 ; bit data
                                    550 ;--------------------------------------------------------
                                    551 	.area BSEG    (BIT)
      00000D                        552 _ak820_tapping_before_sloc0_1_0:
      00000D                        553 	.ds 1
                                    554 ;--------------------------------------------------------
                                    555 ; paged external ram data
                                    556 ;--------------------------------------------------------
                                    557 	.area PSEG    (PAG,XDATA)
                                    558 ;--------------------------------------------------------
                                    559 ; uninitialized external ram data
                                    560 ;--------------------------------------------------------
                                    561 	.area XSEG    (XDATA)
      0005B2                        562 _source_state:
      0005B2                        563 	.ds 130
      000634                        564 _pending_time:
      000634                        565 	.ds 2
      000636                        566 _pending_code:
      000636                        567 	.ds 2
      000638                        568 _ak820_tapping_source_PARM_1:
      000638                        569 	.ds 2
      00063A                        570 _hold_PARM_2:
      00063A                        571 	.ds 1
      00063B                        572 _hold_code_10000_603:
      00063B                        573 	.ds 2
      00063D                        574 _hold_mods_30000_606:
      00063D                        575 	.ds 1
      00063E                        576 _commit_pending_id_10000_612:
      00063E                        577 	.ds 1
      00063F                        578 _ak820_tapping_before_event_10000_613:
      00063F                        579 	.ds 2
      000641                        580 _ak820_tapping_process_record_10000_624:
      000641                        581 	.ds 2
      000643                        582 _ak820_tapping_process_code_10000_625:
      000643                        583 	.ds 2
      000645                        584 _ak820_tapping_process_sc_mods_10000_625:
      000645                        585 	.ds 1
      000646                        586 _ak820_oneshot_mods::
      000646                        587 	.ds 1
      000647                        588 _ak820_oneshot_consumed::
      000647                        589 	.ds 1
      000648                        590 _ak820_oneshot_process_PARM_2:
      000648                        591 	.ds 1
      000649                        592 _ak820_oneshot_process_PARM_3:
      000649                        593 	.ds 1
      00064A                        594 _ak820_oneshot_process_code_10000_650:
      00064A                        595 	.ds 2
      00064C                        596 _ak820_oneshot_process_mods_10000_651:
      00064C                        597 	.ds 1
                                    598 ;--------------------------------------------------------
                                    599 ; absolute external ram data
                                    600 ;--------------------------------------------------------
                                    601 	.area XABS    (ABS,XDATA)
                                    602 ;--------------------------------------------------------
                                    603 ; initialized external ram data
                                    604 ;--------------------------------------------------------
                                    605 	.area XISEG   (XDATA)
      000DBB                        606 _pending:
      000DBB                        607 	.ds 1
      000DBC                        608 _ak820_oneshot_target::
      000DBC                        609 	.ds 1
                                    610 	.area HOME    (CODE)
                                    611 	.area GSINIT0 (CODE)
                                    612 	.area GSINIT1 (CODE)
                                    613 	.area GSINIT2 (CODE)
                                    614 	.area GSINIT3 (CODE)
                                    615 	.area GSINIT4 (CODE)
                                    616 	.area GSINIT5 (CODE)
                                    617 	.area GSINIT  (CODE)
                                    618 	.area GSFINAL (CODE)
                                    619 	.area CSEG    (CODE)
                                    620 ;--------------------------------------------------------
                                    621 ; global & static initialisations
                                    622 ;--------------------------------------------------------
                                    623 	.area HOME    (CODE)
                                    624 	.area GSINIT  (CODE)
                                    625 	.area GSFINAL (CODE)
                                    626 	.area GSINIT  (CODE)
                                    627 ;--------------------------------------------------------
                                    628 ; Home
                                    629 ;--------------------------------------------------------
                                    630 	.area HOME    (CODE)
                                    631 	.area HOME    (CODE)
                                    632 ;--------------------------------------------------------
                                    633 ; code
                                    634 ;--------------------------------------------------------
                                    635 	.area CSEG    (CODE)
                                    636 ;------------------------------------------------------------
                                    637 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    638 ;------------------------------------------------------------
                                    639 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    640 ;------------------------------------------------------------
                                    641 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    642 ;	-----------------------------------------
                           000007   643 	ar7 = 0x07
                           000006   644 	ar6 = 0x06
                           000005   645 	ar5 = 0x05
                           000004   646 	ar4 = 0x04
                           000003   647 	ar3 = 0x03
                           000002   648 	ar2 = 0x02
                           000001   649 	ar1 = 0x01
                           000000   650 	ar0 = 0x00
                                    651 ;	 function ak820_tapping_source
                                    652 ;	-----------------------------------------
      0046CF                        653 _ak820_tapping_source:
                                    654 ;	keyboards/ajazz/ak820/ak820_tapping.c:40: if (key.row < MATRIX_ROWS && key.col < MATRIX_COLS) return key.row * MATRIX_COLS + key.col;
      0046CF 90 06 39         [24]  655 	mov	dptr,#(_ak820_tapping_source_PARM_1 + 0x0001)
      0046D2 E0               [24]  656 	movx	a,@dptr
      0046D3 FF               [12]  657 	mov	r7,a
      0046D4 BF 10 00         [24]  658 	cjne	r7,#0x10,00147$
      0046D7                        659 00147$:
      0046D7 50 14            [24]  660 	jnc	00102$
      0046D9 90 06 38         [24]  661 	mov	dptr,#_ak820_tapping_source_PARM_1
      0046DC E0               [24]  662 	movx	a,@dptr
      0046DD FE               [12]  663 	mov	r6,a
      0046DE BE 08 00         [24]  664 	cjne	r6,#0x08,00149$
      0046E1                        665 00149$:
      0046E1 50 0A            [24]  666 	jnc	00102$
      0046E3 8F 05            [24]  667 	mov	ar5,r7
      0046E5 ED               [12]  668 	mov	a,r5
      0046E6 12 3A D0         [24]  669 	lcall	_ak820_outline_0187
      0046E9 2E               [12]  670 	add	a,r6
      0046EA F5 82            [12]  671 	mov	dpl,a
      0046EC 22               [24]  672 	ret
      0046ED                        673 00102$:
                                    674 ;	keyboards/ajazz/ak820/ak820_tapping.c:41: if (key.col < NUM_ENCODERS) {
      0046ED 90 06 38         [24]  675 	mov	dptr,#_ak820_tapping_source_PARM_1
      0046F0 E0               [24]  676 	movx	a,@dptr
      0046F1 FE               [12]  677 	mov	r6,a
      0046F2 BE 01 00         [24]  678 	cjne	r6,#0x01,00151$
      0046F5                        679 00151$:
      0046F5 50 0E            [24]  680 	jnc	00109$
                                    681 ;	keyboards/ajazz/ak820/ak820_tapping.c:42: if (key.row == KEYLOC_ENCODER_CW) return MATRIX_ROWS * MATRIX_COLS + key.col;
      0046F7 BF FD 04         [24]  682 	cjne	r7,#0xfd,00105$
      0046FA 75 82 80         [24]  683 	mov	dpl, #0x80
      0046FD 22               [24]  684 	ret
      0046FE                        685 00105$:
                                    686 ;	keyboards/ajazz/ak820/ak820_tapping.c:43: if (key.row == KEYLOC_ENCODER_CCW) return MATRIX_ROWS * MATRIX_COLS + NUM_ENCODERS + key.col;
      0046FE BF FC 04         [24]  687 	cjne	r7,#0xfc,00109$
      004701 75 82 81         [24]  688 	mov	dpl, #0x81
      004704 22               [24]  689 	ret
      004705                        690 00109$:
                                    691 ;	keyboards/ajazz/ak820/ak820_tapping.c:45: return NONE;
      004705 75 82 FF         [24]  692 	mov	dpl, #0xff
                                    693 ;	keyboards/ajazz/ak820/ak820_tapping.c:46: }
      004708 22               [24]  694 	ret
                                    695 ;------------------------------------------------------------
                                    696 ;Allocation info for local variables in function 'hold'
                                    697 ;------------------------------------------------------------
                                    698 ;pressed       Allocated with name '_hold_PARM_2'
                                    699 ;code          Allocated with name '_hold_code_10000_603'
                                    700 ;mods          Allocated with name '_hold_mods_30000_606'
                                    701 ;layer         Allocated with name '_hold_layer_30000_609'
                                    702 ;------------------------------------------------------------
                                    703 ;	keyboards/ajazz/ak820/ak820_tapping.c:47: static void hold(uint16_t code, bool pressed) {
                                    704 ;	-----------------------------------------
                                    705 ;	 function hold
                                    706 ;	-----------------------------------------
      004709                        707 _hold:
      004709 12 3A 83         [24]  708 	lcall	_ak820_outline_0103
      00470C 90 06 3B         [24]  709 	mov	dptr,#_hold_code_10000_603
      00470F 12 3A 88         [24]  710 	lcall	_ak820_outline_0104
                                    711 ;	keyboards/ajazz/ak820/ak820_tapping.c:48: if (code < QK_LAYER_TAP) {
      004712 90 06 3B         [24]  712 	mov	dptr,#_hold_code_10000_603
      004715 12 3A 0B         [24]  713 	lcall	_ak820_outline_0011
      004718 74 C0            [12]  714 	mov	a,#0x100 - 0x40
      00471A 2D               [12]  715 	add	a,r5
      00471B 40 2E            [24]  716 	jc	00110$
                                    717 ;	keyboards/ajazz/ak820/ak820_tapping.c:49: uint8_t mods = (code >> 8) & 31;
      00471D 8F 05            [24]  718 	mov	ar5,r7
      00471F 53 05 1F         [24]  719 	anl	ar5,#0x1f
      004722 90 06 3D         [24]  720 	mov	dptr,#_hold_mods_30000_606
      004725 ED               [12]  721 	mov	a,r5
      004726 F0               [24]  722 	movx	@dptr,a
                                    723 ;	keyboards/ajazz/ak820/ak820_tapping.c:50: if (mods & 16) mods <<= 4;
      004727 ED               [12]  724 	mov	a,r5
      004728 30 E4 08         [24]  725 	jnb	acc.4,00102$
      00472B ED               [12]  726 	mov	a,r5
      00472C C4               [12]  727 	swap	a
      00472D 54 F0            [12]  728 	anl	a,#0xf0
      00472F 90 06 3D         [24]  729 	mov	dptr,#_hold_mods_30000_606
      004732 F0               [24]  730 	movx	@dptr,a
      004733                        731 00102$:
                                    732 ;	keyboards/ajazz/ak820/ak820_tapping.c:51: if (pressed) register_mods(mods);
      004733 90 06 3A         [24]  733 	mov	dptr,#_hold_PARM_2
      004736 E0               [24]  734 	movx	a,@dptr
      004737 60 09            [24]  735 	jz	00104$
      004739 90 06 3D         [24]  736 	mov	dptr,#_hold_mods_30000_606
      00473C E0               [24]  737 	movx	a,@dptr
      00473D F5 82            [12]  738 	mov	dpl,a
      00473F 02 7C AF         [24]  739 	ljmp	_register_mods
      004742                        740 00104$:
                                    741 ;	keyboards/ajazz/ak820/ak820_tapping.c:52: else unregister_mods(mods);
      004742 90 06 3D         [24]  742 	mov	dptr,#_hold_mods_30000_606
      004745 E0               [24]  743 	movx	a,@dptr
      004746 F5 82            [12]  744 	mov	dpl,a
      004748 02 7C C3         [24]  745 	ljmp	_unregister_mods
      00474B                        746 00110$:
                                    747 ;	keyboards/ajazz/ak820/ak820_tapping.c:54: uint8_t layer = (code >> 8) & 15;
      00474B 8F 06            [24]  748 	mov	ar6,r7
      00474D 74 0F            [12]  749 	mov	a,#0x0f
      00474F 5E               [12]  750 	anl	a,r6
      004750 FF               [12]  751 	mov	r7,a
                                    752 ;	keyboards/ajazz/ak820/ak820_tapping.c:55: if (pressed) layer_hold_on(layer);
      004751 90 06 3A         [24]  753 	mov	dptr,#_hold_PARM_2
      004754 E0               [24]  754 	movx	a,@dptr
      004755 60 05            [24]  755 	jz	00107$
      004757 8F 82            [24]  756 	mov	dpl, r7
      004759 02 7E 76         [24]  757 	ljmp	_layer_hold_on
      00475C                        758 00107$:
                                    759 ;	keyboards/ajazz/ak820/ak820_tapping.c:56: else layer_hold_off(layer);
      00475C 8F 82            [24]  760 	mov	dpl, r7
                                    761 ;	keyboards/ajazz/ak820/ak820_tapping.c:58: }
      00475E 02 7E AD         [24]  762 	ljmp	_layer_hold_off
                                    763 ;------------------------------------------------------------
                                    764 ;Allocation info for local variables in function 'commit_pending'
                                    765 ;------------------------------------------------------------
                                    766 ;id            Allocated with name '_commit_pending_id_10000_612'
                                    767 ;------------------------------------------------------------
                                    768 ;	keyboards/ajazz/ak820/ak820_tapping.c:59: static void commit_pending(void) {
                                    769 ;	-----------------------------------------
                                    770 ;	 function commit_pending
                                    771 ;	-----------------------------------------
      004761                        772 _commit_pending:
                                    773 ;	keyboards/ajazz/ak820/ak820_tapping.c:60: uint8_t id = pending;
      004761 90 0D BB         [24]  774 	mov	dptr,#_pending
      004764 E0               [24]  775 	movx	a,@dptr
      004765 90 06 3E         [24]  776 	mov	dptr,#_commit_pending_id_10000_612
      004768 F0               [24]  777 	movx	@dptr,a
                                    778 ;	keyboards/ajazz/ak820/ak820_tapping.c:61: pending = NONE; /* A report callback cannot resurrect the decision. */
      004769 12 4B E0         [24]  779 	lcall	_ak820_outline_0153
                                    780 ;	keyboards/ajazz/ak820/ak820_tapping.c:62: source_state[id] |= SOURCE_HELD;
      00476C 90 06 3E         [24]  781 	mov	dptr,#_commit_pending_id_10000_612
      00476F E0               [24]  782 	movx	a,@dptr
      004770 24 B2            [12]  783 	add	a,#_source_state
      004772 FF               [12]  784 	mov	r7,a
      004773 E4               [12]  785 	clr	a
      004774 34 05            [12]  786 	addc	a, #(_source_state >> 8)
      004776 FE               [12]  787 	mov	r6,a
      004777 12 45 EF         [24]  788 	lcall	_ak820_outline_0156
      00477A E0               [24]  789 	movx	a,@dptr
      00477B FD               [12]  790 	mov	r5,a
      00477C 43 05 04         [24]  791 	orl	ar5,#0x04
      00477F 12 45 EF         [24]  792 	lcall	_ak820_outline_0156
      004782 ED               [12]  793 	mov	a,r5
      004783 F0               [24]  794 	movx	@dptr,a
                                    795 ;	keyboards/ajazz/ak820/ak820_tapping.c:63: hold(pending_code, true);
      004784 90 06 36         [24]  796 	mov	dptr,#_pending_code
      004787 12 3A 40         [24]  797 	lcall	_ak820_outline_0051
      00478A 90 06 3A         [24]  798 	mov	dptr,#_hold_PARM_2
      00478D 12 4B AE         [24]  799 	lcall	_ak820_outline_0055
                                    800 ;	keyboards/ajazz/ak820/ak820_tapping.c:64: }
      004790 E1 09            [12]  801 	ajmp	_hold
                                    802 ;------------------------------------------------------------
                                    803 ;Allocation info for local variables in function 'ak820_tapping_before'
                                    804 ;------------------------------------------------------------
                                    805 ;event         Allocated with name '_ak820_tapping_before_event_10000_613'
                                    806 ;id            Allocated with name '_ak820_tapping_before_id_10000_614'
                                    807 ;------------------------------------------------------------
                                    808 ;	keyboards/ajazz/ak820/ak820_tapping.c:65: bool ak820_tapping_before(const keyevent_t AK820_STATE_MEM *event) {
                                    809 ;	-----------------------------------------
                                    810 ;	 function ak820_tapping_before
                                    811 ;	-----------------------------------------
      004792                        812 _ak820_tapping_before:
      004792 12 3A 83         [24]  813 	lcall	_ak820_outline_0103
      004795 90 06 3F         [24]  814 	mov	dptr,#_ak820_tapping_before_event_10000_613
      004798 12 3A 88         [24]  815 	lcall	_ak820_outline_0104
                                    816 ;	keyboards/ajazz/ak820/ak820_tapping.c:66: uint8_t id = ak820_tapping_source(event->key);
      00479B 90 06 3F         [24]  817 	mov	dptr,#_ak820_tapping_before_event_10000_613
      00479E 12 3A 0B         [24]  818 	lcall	_ak820_outline_0011
      0047A1 12 4B 7B         [24]  819 	lcall	_ak820_outline_0022
      0047A4 C0 07            [24]  820 	push	ar7
      0047A6 C0 06            [24]  821 	push	ar6
      0047A8 12 BC F8         [24]  822 	lcall	___memcpy
      0047AB D1 CF            [12]  823 	acall	_ak820_tapping_source
      0047AD AD 82            [24]  824 	mov	r5, dpl
      0047AF D0 06            [24]  825 	pop	ar6
      0047B1 D0 07            [24]  826 	pop	ar7
                                    827 ;	keyboards/ajazz/ak820/ak820_tapping.c:68: if (vial_unlock_in_progress) {
      0047B3 90 0E 2C         [24]  828 	mov	dptr,#_vial_unlock_in_progress
      0047B6 E0               [24]  829 	movx	a,@dptr
      0047B7 60 21            [24]  830 	jz	00106$
                                    831 ;	keyboards/ajazz/ak820/ak820_tapping.c:69: if (IS_EVENT(*event) && id != NONE && !event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      0047B9 74 04            [12]  832 	mov	a,#0x04
      0047BB 12 4B 70         [24]  833 	lcall	_ak820_outline_0013
      0047BE 60 16            [24]  834 	jz	00102$
      0047C0 BD FF 02         [24]  835 	cjne	r5,#0xff,00218$
      0047C3 80 11            [24]  836 	sjmp	00102$
      0047C5                        837 00218$:
      0047C5 74 05            [12]  838 	mov	a,#0x05
      0047C7 12 4B 70         [24]  839 	lcall	_ak820_outline_0013
      0047CA 70 0A            [24]  840 	jnz	00102$
      0047CC ED               [12]  841 	mov	a,r5
      0047CD 12 4B 95         [24]  842 	lcall	_ak820_outline_0024
      0047D0 53 02 FD         [24]  843 	anl	ar2,#0xfd
      0047D3 12 4B D9         [24]  844 	lcall	_ak820_outline_0091
      0047D6                        845 00102$:
                                    846 ;	keyboards/ajazz/ak820/ak820_tapping.c:70: return false;
      0047D6 75 82 00         [24]  847 	mov	dpl, #0x00
      0047D9 22               [24]  848 	ret
      0047DA                        849 00106$:
                                    850 ;	keyboards/ajazz/ak820/ak820_tapping.c:73: if (pending != NONE && ((uint16_t)(event->time - pending_time) >= AK820_TAPPING_TERM ||
      0047DA 90 0D BB         [24]  851 	mov	dptr,#_pending
      0047DD E0               [24]  852 	movx	a,@dptr
      0047DE FC               [12]  853 	mov	r4,a
      0047DF BC FF 02         [24]  854 	cjne	r4,#0xff,00220$
      0047E2 80 3B            [24]  855 	sjmp	00108$
      0047E4                        856 00220$:
      0047E4 12 3A 38         [24]  857 	lcall	_ak820_outline_0034
      0047E7 FA               [12]  858 	mov	r2,a
      0047E8 A3               [24]  859 	inc	dptr
      0047E9 E0               [24]  860 	movx	a,@dptr
      0047EA FB               [12]  861 	mov	r3,a
      0047EB 90 06 34         [24]  862 	mov	dptr,#_pending_time
      0047EE 12 3A 7D         [24]  863 	lcall	_ak820_outline_0100
      0047F1 EA               [12]  864 	mov	a,r2
      0047F2 C3               [12]  865 	clr	c
      0047F3 98               [12]  866 	subb	a,r0
      0047F4 FA               [12]  867 	mov	r2,a
      0047F5 EB               [12]  868 	mov	a,r3
      0047F6 99               [12]  869 	subb	a,r1
      0047F7 FB               [12]  870 	mov	r3,a
      0047F8 C3               [12]  871 	clr	c
      0047F9 EA               [12]  872 	mov	a,r2
      0047FA 94 C8            [12]  873 	subb	a,#0xc8
      0047FC EB               [12]  874 	mov	a,r3
      0047FD 94 00            [12]  875 	subb	a,#0x00
      0047FF 50 17            [24]  876 	jnc	00107$
                                    877 ;	keyboards/ajazz/ak820/ak820_tapping.c:74: (IS_EVENT(*event) && event->pressed && (id == NONE || id != pending)))) commit_pending();
      004801 74 04            [12]  878 	mov	a,#0x04
      004803 12 4B A3         [24]  879 	lcall	_ak820_outline_0046
      004806 60 17            [24]  880 	jz	00108$
      004808 12 39 EA         [24]  881 	lcall	_ak820_outline_0005
      00480B 60 12            [24]  882 	jz	00108$
      00480D BD FF 02         [24]  883 	cjne	r5,#0xff,00224$
      004810 80 06            [24]  884 	sjmp	00107$
      004812                        885 00224$:
      004812 ED               [12]  886 	mov	a,r5
      004813 B5 04 02         [24]  887 	cjne	a,ar4,00225$
      004816 80 07            [24]  888 	sjmp	00108$
      004818                        889 00225$:
      004818                        890 00107$:
      004818 C0 05            [24]  891 	push	ar5
      00481A 12 47 61         [24]  892 	lcall	_commit_pending
      00481D D0 05            [24]  893 	pop	ar5
      00481F                        894 00108$:
                                    895 ;	keyboards/ajazz/ak820/ak820_tapping.c:75: if (IS_NOEVENT(*event) || id == NONE) return true;
      00481F 90 06 3F         [24]  896 	mov	dptr,#_ak820_tapping_before_event_10000_613
      004822 12 3A 40         [24]  897 	lcall	_ak820_outline_0051
      004825 74 04            [12]  898 	mov	a,#0x04
      004827 12 4B 70         [24]  899 	lcall	_ak820_outline_0013
      00482A 60 03            [24]  900 	jz	00114$
      00482C BD FF 04         [24]  901 	cjne	r5,#0xff,00115$
      00482F                        902 00114$:
      00482F 75 82 01         [24]  903 	mov	dpl, #0x01
      004832 22               [24]  904 	ret
      004833                        905 00115$:
                                    906 ;	keyboards/ajazz/ak820/ak820_tapping.c:76: if ((source_state[id] & SOURCE_BLOCKED)) {
      004833 ED               [12]  907 	mov	a,r5
      004834 12 4B CB         [24]  908 	lcall	_ak820_outline_0077
      004837 30 E1 13         [24]  909 	jnb	acc.1,00120$
                                    910 ;	keyboards/ajazz/ak820/ak820_tapping.c:77: if (!event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      00483A 74 05            [12]  911 	mov	a,#0x05
      00483C 2E               [12]  912 	add	a, r6
      00483D 12 3A 15         [24]  913 	lcall	_ak820_outline_0014
      004840 70 07            [24]  914 	jnz	00118$
      004842 74 FD            [12]  915 	mov	a,#0xfd
      004844 5B               [12]  916 	anl	a,r3
      004845 12 3A A0         [24]  917 	lcall	_ak820_outline_0121
      004848 F0               [24]  918 	movx	@dptr,a
      004849                        919 00118$:
                                    920 ;	keyboards/ajazz/ak820/ak820_tapping.c:78: return false;
      004849 75 82 00         [24]  921 	mov	dpl, #0x00
      00484C 22               [24]  922 	ret
      00484D                        923 00120$:
                                    924 ;	keyboards/ajazz/ak820/ak820_tapping.c:81: if (event->pressed == ((source_state[id] & SOURCE_ACTIVE) != 0)) return false;
      00484D 12 45 75         [24]  925 	lcall	_ak820_outline_0010
      004850 E0               [24]  926 	movx	a,@dptr
      004851 FF               [12]  927 	mov	r7,a
      004852 8B 06            [24]  928 	mov	ar6,r3
      004854 53 06 01         [24]  929 	anl	ar6,#0x01
      004857 EE               [12]  930 	mov	a,r6
      004858 B4 01 00         [24]  931 	cjne	a,#0x01,00231$
      00485B                        932 00231$:
      00485B B3               [12]  933 	cpl	c
      00485C 92 0D            [24]  934 	mov	_ak820_tapping_before_sloc0_1_0,c
      00485E 8F F0            [24]  935 	mov	b,r7
      004860 E4               [12]  936 	clr	a
      004861 33               [12]  937 	rlc	a
      004862 B5 F0 04         [24]  938 	cjne	a,b,00122$
      004865 75 82 00         [24]  939 	mov	dpl, #0x00
      004868 22               [24]  940 	ret
      004869                        941 00122$:
                                    942 ;	keyboards/ajazz/ak820/ak820_tapping.c:82: source_state[id] ^= SOURCE_ACTIVE;
      004869 63 03 01         [24]  943 	xrl	ar3,#0x01
      00486C 12 3A A0         [24]  944 	lcall	_ak820_outline_0121
      00486F EB               [12]  945 	mov	a,r3
      004870 F0               [24]  946 	movx	@dptr,a
                                    947 ;	keyboards/ajazz/ak820/ak820_tapping.c:83: return true;
      004871 75 82 01         [24]  948 	mov	dpl, #0x01
                                    949 ;	keyboards/ajazz/ak820/ak820_tapping.c:84: }
      004874 22               [24]  950 	ret
                                    951 ;------------------------------------------------------------
                                    952 ;Allocation info for local variables in function 'ak820_tapping_process'
                                    953 ;------------------------------------------------------------
                                    954 ;record        Allocated with name '_ak820_tapping_process_record_10000_624'
                                    955 ;id            Allocated with name '_ak820_tapping_process_id_10000_625'
                                    956 ;kind          Allocated with name '_ak820_tapping_process_kind_10000_625'
                                    957 ;code          Allocated with name '_ak820_tapping_process_code_10000_625'
                                    958 ;sc_mods       Allocated with name '_ak820_tapping_process_sc_mods_10000_625'
                                    959 ;------------------------------------------------------------
                                    960 ;	keyboards/ajazz/ak820/ak820_tapping.c:85: bool ak820_tapping_process(keyrecord_t AK820_STATE_MEM *record) {
                                    961 ;	-----------------------------------------
                                    962 ;	 function ak820_tapping_process
                                    963 ;	-----------------------------------------
      004875                        964 _ak820_tapping_process:
      004875 12 3A 83         [24]  965 	lcall	_ak820_outline_0103
      004878 90 06 41         [24]  966 	mov	dptr,#_ak820_tapping_process_record_10000_624
      00487B 12 3A 88         [24]  967 	lcall	_ak820_outline_0104
                                    968 ;	keyboards/ajazz/ak820/ak820_tapping.c:89: uint8_t sc_mods = 0;
      00487E 90 06 45         [24]  969 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_625
      004881 E4               [12]  970 	clr	a
      004882 F0               [24]  971 	movx	@dptr,a
                                    972 ;	keyboards/ajazz/ak820/ak820_tapping.c:91: if (IS_NOEVENT(record->event)) return true;
      004883 90 06 41         [24]  973 	mov	dptr,#_ak820_tapping_process_record_10000_624
      004886 12 3A 40         [24]  974 	lcall	_ak820_outline_0051
      004889 74 04            [12]  975 	mov	a,#0x04
      00488B 12 4B 65         [24]  976 	lcall	_ak820_outline_0012
      00488E 70 04            [24]  977 	jnz	00102$
      004890 75 82 01         [24]  978 	mov	dpl, #0x01
      004893 22               [24]  979 	ret
      004894                        980 00102$:
                                    981 ;	keyboards/ajazz/ak820/ak820_tapping.c:92: id = ak820_tapping_source(record->event.key);
      004894 8E 04            [24]  982 	mov	ar4,r6
      004896 8F 05            [24]  983 	mov	ar5,r7
      004898 12 4B 7B         [24]  984 	lcall	_ak820_outline_0022
      00489B C0 07            [24]  985 	push	ar7
      00489D C0 06            [24]  986 	push	ar6
      00489F 12 BC F8         [24]  987 	lcall	___memcpy
      0048A2 12 46 CF         [24]  988 	lcall	_ak820_tapping_source
      0048A5 AD 82            [24]  989 	mov	r5, dpl
      0048A7 D0 06            [24]  990 	pop	ar6
      0048A9 D0 07            [24]  991 	pop	ar7
                                    992 ;	keyboards/ajazz/ak820/ak820_tapping.c:93: if (id == NONE) return true;
      0048AB BD FF 04         [24]  993 	cjne	r5,#0xff,00104$
      0048AE 75 82 01         [24]  994 	mov	dpl, #0x01
      0048B1 22               [24]  995 	ret
      0048B2                        996 00104$:
                                    997 ;	keyboards/ajazz/ak820/ak820_tapping.c:94: code = record->keycode;
      0048B2 74 07            [12]  998 	mov	a,#0x07
      0048B4 12 3A 27         [24]  999 	lcall	_ak820_outline_0017
      0048B7 FE               [12] 1000 	mov	r6,a
      0048B8 A3               [24] 1001 	inc	dptr
      0048B9 E0               [24] 1002 	movx	a,@dptr
      0048BA FF               [12] 1003 	mov	r7,a
      0048BB 90 06 43         [24] 1004 	mov	dptr,#_ak820_tapping_process_code_10000_625
      0048BE 12 4B BE         [24] 1005 	lcall	_ak820_outline_0059
                                   1006 ;	keyboards/ajazz/ak820/ak820_tapping.c:96: if (code == SC_LSPO) { code = MT(MOD_LSFT, KC_9); sc_mods = MOD_BIT(KC_LEFT_SHIFT); }
      0048C1 BE 1A 15         [24] 1007 	cjne	r6,#0x1a,00111$
      0048C4 BF 7C 12         [24] 1008 	cjne	r7,#0x7c,00111$
      0048C7 90 06 43         [24] 1009 	mov	dptr,#_ak820_tapping_process_code_10000_625
      0048CA 74 26            [12] 1010 	mov	a,#0x26
      0048CC F0               [24] 1011 	movx	@dptr,a
      0048CD 74 22            [12] 1012 	mov	a,#0x22
      0048CF A3               [24] 1013 	inc	dptr
      0048D0 F0               [24] 1014 	movx	@dptr,a
      0048D1 90 06 45         [24] 1015 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_625
      0048D4 74 02            [12] 1016 	mov	a,#0x02
      0048D6 F0               [24] 1017 	movx	@dptr,a
      0048D7 80 28            [24] 1018 	sjmp	00112$
      0048D9                       1019 00111$:
                                   1020 ;	keyboards/ajazz/ak820/ak820_tapping.c:97: else if (code == SC_RSPC) { code = MT(MOD_RSFT, KC_0); sc_mods = MOD_BIT(KC_RIGHT_SHIFT); }
      0048D9 BE 1B 15         [24] 1021 	cjne	r6,#0x1b,00108$
      0048DC BF 7C 12         [24] 1022 	cjne	r7,#0x7c,00108$
      0048DF 90 06 43         [24] 1023 	mov	dptr,#_ak820_tapping_process_code_10000_625
      0048E2 74 27            [12] 1024 	mov	a,#0x27
      0048E4 F0               [24] 1025 	movx	@dptr,a
      0048E5 74 32            [12] 1026 	mov	a,#0x32
      0048E7 A3               [24] 1027 	inc	dptr
      0048E8 F0               [24] 1028 	movx	@dptr,a
      0048E9 90 06 45         [24] 1029 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_625
      0048EC 74 20            [12] 1030 	mov	a,#0x20
      0048EE F0               [24] 1031 	movx	@dptr,a
      0048EF 80 10            [24] 1032 	sjmp	00112$
      0048F1                       1033 00108$:
                                   1034 ;	keyboards/ajazz/ak820/ak820_tapping.c:98: else if (code == SC_SENT) code = MT(MOD_RSFT, KC_ENTER);
      0048F1 BE 1E 0D         [24] 1035 	cjne	r6,#0x1e,00112$
      0048F4 BF 7C 0A         [24] 1036 	cjne	r7,#0x7c,00112$
      0048F7 90 06 43         [24] 1037 	mov	dptr,#_ak820_tapping_process_code_10000_625
      0048FA 74 28            [12] 1038 	mov	a,#0x28
      0048FC F0               [24] 1039 	movx	@dptr,a
      0048FD 74 32            [12] 1040 	mov	a,#0x32
      0048FF A3               [24] 1041 	inc	dptr
      004900 F0               [24] 1042 	movx	@dptr,a
      004901                       1043 00112$:
                                   1044 ;	keyboards/ajazz/ak820/ak820_tapping.c:100: kind = code >> 8;
      004901 90 06 43         [24] 1045 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004904 E0               [24] 1046 	movx	a,@dptr
      004905 A3               [24] 1047 	inc	dptr
      004906 E0               [24] 1048 	movx	a,@dptr
      004907 FF               [12] 1049 	mov	r7,a
                                   1050 ;	keyboards/ajazz/ak820/ak820_tapping.c:101: if (kind < 0x20 || kind >= 0x50) return true;
      004908 BF 20 00         [24] 1051 	cjne	r7,#0x20,00242$
      00490B                       1052 00242$:
      00490B 40 05            [24] 1053 	jc	00113$
      00490D BF 50 00         [24] 1054 	cjne	r7,#0x50,00244$
      004910                       1055 00244$:
      004910 40 04            [24] 1056 	jc	00114$
      004912                       1057 00113$:
      004912 75 82 01         [24] 1058 	mov	dpl, #0x01
      004915 22               [24] 1059 	ret
      004916                       1060 00114$:
                                   1061 ;	keyboards/ajazz/ak820/ak820_tapping.c:102: if (kind >= 0x40 && (kind & 15) >= MAX_LAYER) return false;
      004916 BF 40 00         [24] 1062 	cjne	r7,#0x40,00246$
      004919                       1063 00246$:
      004919 40 0C            [24] 1064 	jc	00117$
      00491B 53 07 0F         [24] 1065 	anl	ar7,#0x0f
      00491E BF 06 00         [24] 1066 	cjne	r7,#0x06,00248$
      004921                       1067 00248$:
      004921 40 04            [24] 1068 	jc	00117$
      004923 75 82 00         [24] 1069 	mov	dpl, #0x00
      004926 22               [24] 1070 	ret
      004927                       1071 00117$:
                                   1072 ;	keyboards/ajazz/ak820/ak820_tapping.c:103: if (record->event.pressed) {
      004927 90 06 41         [24] 1073 	mov	dptr,#_ak820_tapping_process_record_10000_624
      00492A 12 3A 40         [24] 1074 	lcall	_ak820_outline_0051
      00492D 74 05            [12] 1075 	mov	a,#0x05
      00492F 12 4B 70         [24] 1076 	lcall	_ak820_outline_0013
      004932 60 1E            [24] 1077 	jz	00131$
                                   1078 ;	keyboards/ajazz/ak820/ak820_tapping.c:104: pending = id;
      004934 90 0D BB         [24] 1079 	mov	dptr,#_pending
      004937 ED               [12] 1080 	mov	a,r5
      004938 12 45 7F         [24] 1081 	lcall	_ak820_outline_0030
                                   1082 ;	keyboards/ajazz/ak820/ak820_tapping.c:105: pending_time = record->event.time;
      00493B 12 3A 40         [24] 1083 	lcall	_ak820_outline_0051
      00493E 90 06 34         [24] 1084 	mov	dptr,#_pending_time
      004941 12 4B BE         [24] 1085 	lcall	_ak820_outline_0059
                                   1086 ;	keyboards/ajazz/ak820/ak820_tapping.c:106: pending_code = code;
      004944 90 06 43         [24] 1087 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004947 12 3A 40         [24] 1088 	lcall	_ak820_outline_0051
      00494A 90 06 36         [24] 1089 	mov	dptr,#_pending_code
      00494D 12 4B BE         [24] 1090 	lcall	_ak820_outline_0059
      004950 21 EE            [12] 1091 	ajmp	00132$
      004952                       1092 00131$:
                                   1093 ;	keyboards/ajazz/ak820/ak820_tapping.c:107: } else if (id == pending) {
      004952 90 0D BB         [24] 1094 	mov	dptr,#_pending
      004955 E0               [24] 1095 	movx	a,@dptr
      004956 FF               [12] 1096 	mov	r7,a
      004957 ED               [12] 1097 	mov	a,r5
      004958 B5 07 02         [24] 1098 	cjne	a,ar7,00251$
      00495B 80 02            [24] 1099 	sjmp	00252$
      00495D                       1100 00251$:
      00495D 21 C7            [24] 1101 	ajmp	00128$
      00495F                       1102 00252$:
                                   1103 ;	keyboards/ajazz/ak820/ak820_tapping.c:108: pending = NONE;
      00495F 12 4B E0         [24] 1104 	lcall	_ak820_outline_0153
                                   1105 ;	keyboards/ajazz/ak820/ak820_tapping.c:110: if (sc_mods) add_owned_mods(sc_mods);
      004962 90 06 45         [24] 1106 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_625
      004965 E0               [24] 1107 	movx	a,@dptr
      004966 FF               [12] 1108 	mov	r7,a
      004967 E0               [24] 1109 	movx	a,@dptr
      004968 60 05            [24] 1110 	jz	00120$
      00496A 8F 82            [24] 1111 	mov	dpl, r7
      00496C 12 83 3A         [24] 1112 	lcall	_add_owned_mods
      00496F                       1113 00120$:
                                   1114 ;	keyboards/ajazz/ak820/ak820_tapping.c:114: record->keycode = (uint8_t)code;
      00496F 90 06 41         [24] 1115 	mov	dptr,#_ak820_tapping_process_record_10000_624
      004972 12 3A 40         [24] 1116 	lcall	_ak820_outline_0051
      004975 74 07            [12] 1117 	mov	a,#0x07
      004977 2E               [12] 1118 	add	a, r6
      004978 FB               [12] 1119 	mov	r3,a
      004979 E4               [12] 1120 	clr	a
      00497A 3F               [12] 1121 	addc	a, r7
      00497B FC               [12] 1122 	mov	r4,a
      00497C 90 06 43         [24] 1123 	mov	dptr,#_ak820_tapping_process_code_10000_625
      00497F E0               [24] 1124 	movx	a,@dptr
      004980 F9               [12] 1125 	mov	r1,a
      004981 7A 00            [12] 1126 	mov	r2,#0x00
      004983 12 36 42         [24] 1127 	lcall	_ak820_outline_0122
      004986 E9               [12] 1128 	mov	a,r1
      004987 F0               [24] 1129 	movx	@dptr,a
      004988 EA               [12] 1130 	mov	a,r2
      004989 A3               [24] 1131 	inc	dptr
      00498A F0               [24] 1132 	movx	@dptr,a
                                   1133 ;	keyboards/ajazz/ak820/ak820_tapping.c:115: if (record->keycode > KC_TRANSPARENT) {
      00498B C3               [12] 1134 	clr	c
      00498C 04               [12] 1135 	inc	a
      00498D 99               [12] 1136 	subb	a,r1
      00498E 50 25            [24] 1137 	jnc	00122$
                                   1138 ;	free result
                                   1139 ;	keyboards/ajazz/ak820/ak820_tapping.c:116: record->tap.count = 1;
      004990 74 06            [12] 1140 	mov	a,#0x06
      004992 12 3A 27         [24] 1141 	lcall	_ak820_outline_0017
      004995 54 0F            [12] 1142 	anl	a,#0x0f
      004997 44 10            [12] 1143 	orl	a,#0x10
      004999 F0               [24] 1144 	movx	@dptr,a
                                   1145 ;	keyboards/ajazz/ak820/ak820_tapping.c:117: record->event.pressed = true;
      00499A 12 45 75         [24] 1146 	lcall	_ak820_outline_0010
      00499D 12 4B AE         [24] 1147 	lcall	_ak820_outline_0055
                                   1148 ;	keyboards/ajazz/ak820/ak820_tapping.c:118: process_record(record);
      0049A0 12 77 21         [24] 1149 	lcall	_process_record
                                   1150 ;	keyboards/ajazz/ak820/ak820_tapping.c:119: record->event.pressed = false;
      0049A3 90 06 41         [24] 1151 	mov	dptr,#_ak820_tapping_process_record_10000_624
      0049A6 12 39 E0         [24] 1152 	lcall	_ak820_outline_0004
      0049A9 A3               [24] 1153 	inc	dptr
      0049AA A3               [24] 1154 	inc	dptr
      0049AB A3               [24] 1155 	inc	dptr
      0049AC A3               [24] 1156 	inc	dptr
      0049AD A3               [24] 1157 	inc	dptr
      0049AE E4               [12] 1158 	clr	a
      0049AF 12 45 AB         [24] 1159 	lcall	_ak820_outline_0061
                                   1160 ;	keyboards/ajazz/ak820/ak820_tapping.c:120: process_record(record);
      0049B2 12 77 21         [24] 1161 	lcall	_process_record
      0049B5                       1162 00122$:
                                   1163 ;	keyboards/ajazz/ak820/ak820_tapping.c:123: if (sc_mods) {
      0049B5 90 06 45         [24] 1164 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_625
      0049B8 E0               [24] 1165 	movx	a,@dptr
      0049B9 FF               [12] 1166 	mov	r7,a
      0049BA E0               [24] 1167 	movx	a,@dptr
      0049BB 60 31            [24] 1168 	jz	00132$
                                   1169 ;	keyboards/ajazz/ak820/ak820_tapping.c:124: del_owned_mods(sc_mods);
      0049BD 8F 82            [24] 1170 	mov	dpl, r7
      0049BF 12 83 49         [24] 1171 	lcall	_del_owned_mods
                                   1172 ;	keyboards/ajazz/ak820/ak820_tapping.c:125: send_keyboard_report();
      0049C2 12 86 6D         [24] 1173 	lcall	_send_keyboard_report
      0049C5 80 27            [24] 1174 	sjmp	00132$
      0049C7                       1175 00128$:
                                   1176 ;	keyboards/ajazz/ak820/ak820_tapping.c:128: } else if ((source_state[id] & SOURCE_HELD)) {
      0049C7 ED               [12] 1177 	mov	a,r5
      0049C8 24 B2            [12] 1178 	add	a, #_source_state
      0049CA FE               [12] 1179 	mov	r6,a
      0049CB E4               [12] 1180 	clr	a
      0049CC 34 05            [12] 1181 	addc	a, #(_source_state >> 8)
      0049CE FF               [12] 1182 	mov	r7,a
      0049CF 12 3A 77         [24] 1183 	lcall	_ak820_outline_0098
      0049D2 FD               [12] 1184 	mov	r5,a
      0049D3 30 E2 18         [24] 1185 	jnb	acc.2,00132$
                                   1186 ;	keyboards/ajazz/ak820/ak820_tapping.c:129: source_state[id] &= ~SOURCE_HELD;
      0049D6 53 05 FB         [24] 1187 	anl	ar5,#0xfb
      0049D9 12 45 C9         [24] 1188 	lcall	_ak820_outline_0116
      0049DC ED               [12] 1189 	mov	a,r5
      0049DD F0               [24] 1190 	movx	@dptr,a
                                   1191 ;	keyboards/ajazz/ak820/ak820_tapping.c:130: hold(code, false);
      0049DE 90 06 43         [24] 1192 	mov	dptr,#_ak820_tapping_process_code_10000_625
      0049E1 12 3A 40         [24] 1193 	lcall	_ak820_outline_0051
      0049E4 90 06 3A         [24] 1194 	mov	dptr,#_hold_PARM_2
      0049E7 E4               [12] 1195 	clr	a
      0049E8 12 45 AB         [24] 1196 	lcall	_ak820_outline_0061
      0049EB 12 47 09         [24] 1197 	lcall	_hold
      0049EE                       1198 00132$:
                                   1199 ;	keyboards/ajazz/ak820/ak820_tapping.c:132: return false;
      0049EE 75 82 00         [24] 1200 	mov	dpl, #0x00
                                   1201 ;	keyboards/ajazz/ak820/ak820_tapping.c:133: }
      0049F1 22               [24] 1202 	ret
                                   1203 ;------------------------------------------------------------
                                   1204 ;Allocation info for local variables in function 'ak820_tapping_cancel'
                                   1205 ;------------------------------------------------------------
                                   1206 ;i             Allocated with name '_ak820_tapping_cancel_i_20000_648'
                                   1207 ;state         Allocated with name '_ak820_tapping_cancel_state_30000_649'
                                   1208 ;------------------------------------------------------------
                                   1209 ;	keyboards/ajazz/ak820/ak820_tapping.c:134: void ak820_tapping_cancel(void) {
                                   1210 ;	-----------------------------------------
                                   1211 ;	 function ak820_tapping_cancel
                                   1212 ;	-----------------------------------------
      0049F2                       1213 _ak820_tapping_cancel:
                                   1214 ;	keyboards/ajazz/ak820/ak820_tapping.c:135: pending = NONE;
      0049F2 12 4B E0         [24] 1215 	lcall	_ak820_outline_0153
                                   1216 ;	keyboards/ajazz/ak820/ak820_tapping.c:136: for (uint8_t i = 0; i < SOURCES; ++i) {
      0049F5 7F 00            [12] 1217 	mov	r7,#0x00
      0049F7                       1218 00103$:
      0049F7 BF 82 00         [24] 1219 	cjne	r7,#0x82,00122$
      0049FA                       1220 00122$:
      0049FA 50 1D            [24] 1221 	jnc	00105$
                                   1222 ;	keyboards/ajazz/ak820/ak820_tapping.c:137: uint8_t state = source_state[i];
      0049FC EF               [12] 1223 	mov	a,r7
      0049FD 24 B2            [12] 1224 	add	a, #_source_state
      0049FF FD               [12] 1225 	mov	r5,a
      004A00 E4               [12] 1226 	clr	a
      004A01 34 05            [12] 1227 	addc	a, #(_source_state >> 8)
      004A03 12 4B B6         [24] 1228 	lcall	_ak820_outline_0057
                                   1229 ;	keyboards/ajazz/ak820/ak820_tapping.c:138: source_state[i] = (state & SOURCE_BLOCKED) | ((state & SOURCE_ACTIVE) << 1);
      004A06 74 02            [12] 1230 	mov	a,#0x02
      004A08 5C               [12] 1231 	anl	a,r4
      004A09 FB               [12] 1232 	mov	r3,a
      004A0A 53 04 01         [24] 1233 	anl	ar4,#0x01
      004A0D EC               [12] 1234 	mov	a,r4
      004A0E 2C               [12] 1235 	add	a,r4
      004A0F 42 03            [12] 1236 	orl	ar3,a
      004A11 12 3A AA         [24] 1237 	lcall	_ak820_outline_0131
      004A14 EB               [12] 1238 	mov	a,r3
      004A15 F0               [24] 1239 	movx	@dptr,a
                                   1240 ;	keyboards/ajazz/ak820/ak820_tapping.c:136: for (uint8_t i = 0; i < SOURCES; ++i) {
      004A16 0F               [12] 1241 	inc	r7
      004A17 80 DE            [24] 1242 	sjmp	00103$
      004A19                       1243 00105$:
                                   1244 ;	keyboards/ajazz/ak820/ak820_tapping.c:140: }
      004A19 22               [24] 1245 	ret
                                   1246 ;------------------------------------------------------------
                                   1247 ;Allocation info for local variables in function 'ak820_oneshot_process'
                                   1248 ;------------------------------------------------------------
                                   1249 ;id            Allocated with name '_ak820_oneshot_process_PARM_2'
                                   1250 ;pressed       Allocated with name '_ak820_oneshot_process_PARM_3'
                                   1251 ;code          Allocated with name '_ak820_oneshot_process_code_10000_650'
                                   1252 ;mods          Allocated with name '_ak820_oneshot_process_mods_10000_651'
                                   1253 ;i             Allocated with name '_ak820_oneshot_process_i_40000_666'
                                   1254 ;------------------------------------------------------------
                                   1255 ;	keyboards/ajazz/ak820/ak820_tapping.c:149: bool ak820_oneshot_process(uint16_t code, uint8_t id, bool pressed) {
                                   1256 ;	-----------------------------------------
                                   1257 ;	 function ak820_oneshot_process
                                   1258 ;	-----------------------------------------
      004A1A                       1259 _ak820_oneshot_process:
      004A1A 12 3A 83         [24] 1260 	lcall	_ak820_outline_0103
      004A1D 90 06 4A         [24] 1261 	mov	dptr,#_ak820_oneshot_process_code_10000_650
      004A20 12 3A 88         [24] 1262 	lcall	_ak820_outline_0104
                                   1263 ;	keyboards/ajazz/ak820/ak820_tapping.c:151: if (id == NONE || get_repeat_key_count()) return true;
      004A23 90 06 48         [24] 1264 	mov	dptr,#_ak820_oneshot_process_PARM_2
      004A26 E0               [24] 1265 	movx	a,@dptr
      004A27 FF               [12] 1266 	mov	r7,a
      004A28 BF FF 02         [24] 1267 	cjne	r7,#0xff,00265$
      004A2B 80 07            [24] 1268 	sjmp	00101$
      004A2D                       1269 00265$:
      004A2D 12 A7 1C         [24] 1270 	lcall	_get_repeat_key_count
      004A30 E5 82            [12] 1271 	mov	a, dpl
      004A32 60 04            [24] 1272 	jz	00102$
      004A34                       1273 00101$:
      004A34 75 82 01         [24] 1274 	mov	dpl, #0x01
      004A37 22               [24] 1275 	ret
      004A38                       1276 00102$:
                                   1277 ;	keyboards/ajazz/ak820/ak820_tapping.c:154: if (code >= QK_MAGIC_GUI_ON && code <= QK_MAGIC_TOGGLE_GUI) return true;
      004A38 90 06 4A         [24] 1278 	mov	dptr,#_ak820_oneshot_process_code_10000_650
      004A3B 12 45 B7         [24] 1279 	lcall	_ak820_outline_0097
      004A3E C3               [12] 1280 	clr	c
      004A3F ED               [12] 1281 	mov	a,r5
      004A40 94 09            [12] 1282 	subb	a,#0x09
      004A42 EE               [12] 1283 	mov	a,r6
      004A43 94 70            [12] 1284 	subb	a,#0x70
      004A45 40 0C            [24] 1285 	jc	00105$
      004A47 74 0B            [12] 1286 	mov	a,#0x0b
      004A49 9D               [12] 1287 	subb	a,r5
      004A4A 74 70            [12] 1288 	mov	a,#0x70
      004A4C 9E               [12] 1289 	subb	a,r6
      004A4D 40 04            [24] 1290 	jc	00105$
                                   1291 ;	free result
      004A4F 75 82 01         [24] 1292 	mov	dpl, #0x01
      004A52 22               [24] 1293 	ret
      004A53                       1294 00105$:
                                   1295 ;	keyboards/ajazz/ak820/ak820_tapping.c:164: if ((code >> 8) == 0x52 && ((uint8_t)code & 0xe0) == 0xa0) {
      004A53 90 06 4A         [24] 1296 	mov	dptr,#_ak820_oneshot_process_code_10000_650
      004A56 E0               [24] 1297 	movx	a,@dptr
      004A57 FB               [12] 1298 	mov	r3,a
      004A58 A3               [24] 1299 	inc	dptr
      004A59 E0               [24] 1300 	movx	a,@dptr
      004A5A F9               [12] 1301 	mov	r1,a
      004A5B B9 52 02         [24] 1302 	cjne	r1,#0x52,00269$
      004A5E 80 02            [24] 1303 	sjmp	00270$
      004A60                       1304 00269$:
      004A60 61 05            [12] 1305 	ajmp	00119$
      004A62                       1306 00270$:
      004A62 8B 02            [24] 1307 	mov	ar2,r3
      004A64 53 02 E0         [24] 1308 	anl	ar2,#0xe0
      004A67 BA A0 02         [24] 1309 	cjne	r2,#0xa0,00271$
      004A6A 80 02            [24] 1310 	sjmp	00272$
      004A6C                       1311 00271$:
      004A6C 61 05            [12] 1312 	ajmp	00119$
      004A6E                       1313 00272$:
                                   1314 ;	keyboards/ajazz/ak820/ak820_tapping.c:165: mods = code & 15;
      004A6E 8B 02            [24] 1315 	mov	ar2,r3
      004A70 53 02 0F         [24] 1316 	anl	ar2,#0x0f
      004A73 90 06 4C         [24] 1317 	mov	dptr,#_ak820_oneshot_process_mods_10000_651
      004A76 EA               [12] 1318 	mov	a,r2
      004A77 F0               [24] 1319 	movx	@dptr,a
                                   1320 ;	keyboards/ajazz/ak820/ak820_tapping.c:166: if (code & 16) mods <<= 4;
      004A78 EB               [12] 1321 	mov	a,r3
      004A79 30 E4 08         [24] 1322 	jnb	acc.4,00108$
      004A7C EA               [12] 1323 	mov	a,r2
      004A7D C4               [12] 1324 	swap	a
      004A7E 54 F0            [12] 1325 	anl	a,#0xf0
      004A80 90 06 4C         [24] 1326 	mov	dptr,#_ak820_oneshot_process_mods_10000_651
      004A83 F0               [24] 1327 	movx	@dptr,a
      004A84                       1328 00108$:
                                   1329 ;	keyboards/ajazz/ak820/ak820_tapping.c:167: if (pressed) {
      004A84 90 06 49         [24] 1330 	mov	dptr,#_ak820_oneshot_process_PARM_3
      004A87 E0               [24] 1331 	movx	a,@dptr
      004A88 60 2E            [24] 1332 	jz	00116$
                                   1333 ;	keyboards/ajazz/ak820/ak820_tapping.c:168: source_state[id] |= SOURCE_ONESHOT;
      004A8A EF               [12] 1334 	mov	a,r7
      004A8B 12 4B 95         [24] 1335 	lcall	_ak820_outline_0024
      004A8E 43 02 08         [24] 1336 	orl	ar2,#0x08
      004A91 12 4B D9         [24] 1337 	lcall	_ak820_outline_0091
                                   1338 ;	keyboards/ajazz/ak820/ak820_tapping.c:169: source_state[id] &= ~SOURCE_ONESHOT_USED;
      004A94 53 02 EF         [24] 1339 	anl	ar2,#0xef
      004A97 12 4B D9         [24] 1340 	lcall	_ak820_outline_0091
                                   1341 ;	keyboards/ajazz/ak820/ak820_tapping.c:170: if (ak820_oneshot_target != NONE) source_state[id] |= SOURCE_ONESHOT_USED;
      004A9A 90 0D BC         [24] 1342 	mov	dptr,#_ak820_oneshot_target
      004A9D E0               [24] 1343 	movx	a,@dptr
      004A9E FA               [12] 1344 	mov	r2,a
      004A9F BA FF 02         [24] 1345 	cjne	r2,#0xff,00275$
      004AA2 80 09            [24] 1346 	sjmp	00110$
      004AA4                       1347 00275$:
      004AA4 12 4B C4         [24] 1348 	lcall	_ak820_outline_0065
      004AA7 43 02 10         [24] 1349 	orl	ar2,#0x10
      004AAA 12 4B D9         [24] 1350 	lcall	_ak820_outline_0091
      004AAD                       1351 00110$:
                                   1352 ;	keyboards/ajazz/ak820/ak820_tapping.c:171: register_mods(mods);
      004AAD 90 06 4C         [24] 1353 	mov	dptr,#_ak820_oneshot_process_mods_10000_651
      004AB0 E0               [24] 1354 	movx	a,@dptr
      004AB1 F5 82            [12] 1355 	mov	dpl,a
      004AB3 12 7C AF         [24] 1356 	lcall	_register_mods
      004AB6 80 49            [24] 1357 	sjmp	00117$
      004AB8                       1358 00116$:
                                   1359 ;	keyboards/ajazz/ak820/ak820_tapping.c:172: } else if (source_state[id] & SOURCE_ONESHOT) {
      004AB8 EF               [12] 1360 	mov	a,r7
      004AB9 12 4B 95         [24] 1361 	lcall	_ak820_outline_0024
      004ABC 30 E3 42         [24] 1362 	jnb	acc.3,00117$
                                   1363 ;	keyboards/ajazz/ak820/ak820_tapping.c:173: if (!(source_state[id] & SOURCE_ONESHOT_USED)) {
      004ABF EA               [12] 1364 	mov	a,r2
      004AC0 20 E4 24         [24] 1365 	jb	acc.4,00112$
                                   1366 ;	keyboards/ajazz/ak820/ak820_tapping.c:174: add_owned_mods(mods & ~ak820_oneshot_mods);
      004AC3 90 06 46         [24] 1367 	mov	dptr,#_ak820_oneshot_mods
      004AC6 E0               [24] 1368 	movx	a,@dptr
      004AC7 F4               [12] 1369 	cpl	a
      004AC8 FA               [12] 1370 	mov	r2,a
      004AC9 90 06 4C         [24] 1371 	mov	dptr,#_ak820_oneshot_process_mods_10000_651
      004ACC E0               [24] 1372 	movx	a,@dptr
      004ACD F9               [12] 1373 	mov	r1,a
      004ACE 52 02            [12] 1374 	anl	ar2,a
      004AD0 8A 82            [24] 1375 	mov	dpl, r2
      004AD2 C0 04            [24] 1376 	push	ar4
      004AD4 C0 03            [24] 1377 	push	ar3
      004AD6 C0 01            [24] 1378 	push	ar1
      004AD8 12 83 3A         [24] 1379 	lcall	_add_owned_mods
      004ADB D0 01            [24] 1380 	pop	ar1
      004ADD D0 03            [24] 1381 	pop	ar3
      004ADF D0 04            [24] 1382 	pop	ar4
                                   1383 ;	keyboards/ajazz/ak820/ak820_tapping.c:175: ak820_oneshot_mods |= mods;
      004AE1 90 06 46         [24] 1384 	mov	dptr,#_ak820_oneshot_mods
      004AE4 E0               [24] 1385 	movx	a,@dptr
      004AE5 49               [12] 1386 	orl	a,r1
      004AE6 F0               [24] 1387 	movx	@dptr,a
      004AE7                       1388 00112$:
                                   1389 ;	keyboards/ajazz/ak820/ak820_tapping.c:177: unregister_mods(mods);
      004AE7 90 06 4C         [24] 1390 	mov	dptr,#_ak820_oneshot_process_mods_10000_651
      004AEA E0               [24] 1391 	movx	a,@dptr
      004AEB F5 82            [12] 1392 	mov	dpl,a
      004AED C0 04            [24] 1393 	push	ar4
      004AEF C0 03            [24] 1394 	push	ar3
      004AF1 12 7C C3         [24] 1395 	lcall	_unregister_mods
      004AF4 D0 03            [24] 1396 	pop	ar3
      004AF6 D0 04            [24] 1397 	pop	ar4
                                   1398 ;	keyboards/ajazz/ak820/ak820_tapping.c:178: source_state[id] &= ~(SOURCE_ONESHOT | SOURCE_ONESHOT_USED);
      004AF8 12 4B C4         [24] 1399 	lcall	_ak820_outline_0065
      004AFB 53 02 E7         [24] 1400 	anl	ar2,#0xe7
      004AFE 12 4B D9         [24] 1401 	lcall	_ak820_outline_0091
      004B01                       1402 00117$:
                                   1403 ;	keyboards/ajazz/ak820/ak820_tapping.c:180: return false;
      004B01 75 82 00         [24] 1404 	mov	dpl, #0x00
      004B04 22               [24] 1405 	ret
      004B05                       1406 00119$:
                                   1407 ;	keyboards/ajazz/ak820/ak820_tapping.c:182: if (pressed && code > KC_TRANSPARENT &&
      004B05 90 06 49         [24] 1408 	mov	dptr,#_ak820_oneshot_process_PARM_3
      004B08 E0               [24] 1409 	movx	a,@dptr
      004B09 60 56            [24] 1410 	jz	00127$
      004B0B C3               [12] 1411 	clr	c
      004B0C 74 01            [12] 1412 	mov	a,#0x01
      004B0E 9D               [12] 1413 	subb	a,r5
      004B0F E4               [12] 1414 	clr	a
      004B10 9E               [12] 1415 	subb	a,r6
      004B11 50 4E            [24] 1416 	jnc	00127$
                                   1417 ;	free result
                                   1418 ;	keyboards/ajazz/ak820/ak820_tapping.c:183: !(code >= KC_LCTL && code <= KC_RGUI) &&
      004B13 C3               [12] 1419 	clr	c
      004B14 ED               [12] 1420 	mov	a,r5
      004B15 94 E0            [12] 1421 	subb	a,#0xe0
      004B17 EE               [12] 1422 	mov	a,r6
      004B18 94 00            [12] 1423 	subb	a,#0x00
      004B1A 40 07            [24] 1424 	jc	00132$
      004B1C 74 E7            [12] 1425 	mov	a,#0xe7
      004B1E 9D               [12] 1426 	subb	a,r5
      004B1F E4               [12] 1427 	clr	a
      004B20 9E               [12] 1428 	subb	a,r6
      004B21 50 3E            [24] 1429 	jnc	00127$
                                   1430 ;	free result
      004B23                       1431 00132$:
                                   1432 ;	keyboards/ajazz/ak820/ak820_tapping.c:184: !(code >= QK_TO && code <= QK_LAYER_TAP_TOGGLE_MAX)) {
      004B23 74 AE            [12] 1433 	mov	a,#0x100 - 0x52
      004B25 2E               [12] 1434 	add	a,r6
      004B26 50 09            [24] 1435 	jnc	00172$
      004B28 C3               [12] 1436 	clr	c
      004B29 74 DF            [12] 1437 	mov	a,#0xdf
      004B2B 9D               [12] 1438 	subb	a,r5
      004B2C 74 52            [12] 1439 	mov	a,#0x52
      004B2E 9E               [12] 1440 	subb	a,r6
      004B2F 50 30            [24] 1441 	jnc	00127$
                                   1442 ;	free result
                                   1443 ;	keyboards/ajazz/ak820/ak820_tapping.c:185: for (uint8_t i = 0; i < SOURCES; ++i)
      004B31                       1444 00172$:
      004B31 7E 00            [12] 1445 	mov	r6,#0x00
      004B33                       1446 00134$:
      004B33 BE 82 00         [24] 1447 	cjne	r6,#0x82,00284$
      004B36                       1448 00284$:
      004B36 50 12            [24] 1449 	jnc	00123$
                                   1450 ;	keyboards/ajazz/ak820/ak820_tapping.c:186: if (source_state[i] & SOURCE_ONESHOT) source_state[i] |= SOURCE_ONESHOT_USED;
      004B38 EE               [12] 1451 	mov	a,r6
      004B39 12 4B CB         [24] 1452 	lcall	_ak820_outline_0077
      004B3C 30 E3 08         [24] 1453 	jnb	acc.3,00135$
      004B3F 43 03 10         [24] 1454 	orl	ar3,#0x10
      004B42 12 3A A0         [24] 1455 	lcall	_ak820_outline_0121
      004B45 EB               [12] 1456 	mov	a,r3
      004B46 F0               [24] 1457 	movx	@dptr,a
      004B47                       1458 00135$:
                                   1459 ;	keyboards/ajazz/ak820/ak820_tapping.c:185: for (uint8_t i = 0; i < SOURCES; ++i)
      004B47 0E               [12] 1460 	inc	r6
      004B48 80 E9            [24] 1461 	sjmp	00134$
      004B4A                       1462 00123$:
                                   1463 ;	keyboards/ajazz/ak820/ak820_tapping.c:187: if (ak820_oneshot_mods) {
      004B4A 90 06 46         [24] 1464 	mov	dptr,#_ak820_oneshot_mods
      004B4D E0               [24] 1465 	movx	a,@dptr
      004B4E FE               [12] 1466 	mov	r6,a
      004B4F E0               [24] 1467 	movx	a,@dptr
      004B50 60 0F            [24] 1468 	jz	00127$
                                   1469 ;	keyboards/ajazz/ak820/ak820_tapping.c:188: ak820_oneshot_consumed = ak820_oneshot_mods;
      004B52 90 06 47         [24] 1470 	mov	dptr,#_ak820_oneshot_consumed
      004B55 EE               [12] 1471 	mov	a,r6
      004B56 F0               [24] 1472 	movx	@dptr,a
                                   1473 ;	keyboards/ajazz/ak820/ak820_tapping.c:189: ak820_oneshot_target = id;
      004B57 90 0D BC         [24] 1474 	mov	dptr,#_ak820_oneshot_target
      004B5A EF               [12] 1475 	mov	a,r7
      004B5B F0               [24] 1476 	movx	@dptr,a
                                   1477 ;	keyboards/ajazz/ak820/ak820_tapping.c:190: ak820_oneshot_mods = 0;
      004B5C 90 06 46         [24] 1478 	mov	dptr,#_ak820_oneshot_mods
      004B5F E4               [12] 1479 	clr	a
      004B60 F0               [24] 1480 	movx	@dptr,a
      004B61                       1481 00127$:
                                   1482 ;	keyboards/ajazz/ak820/ak820_tapping.c:193: return true;
      004B61 75 82 01         [24] 1483 	mov	dpl, #0x01
                                   1484 ;	keyboards/ajazz/ak820/ak820_tapping.c:194: }
      004B64 22               [24] 1485 	ret
                                   1486 	.area CSEG    (CODE)
                                   1487 	.area CONST   (CODE)
                                   1488 	.area XINIT   (CODE)
      00C60A                       1489 __xinit__pending:
      00C60A FF                    1490 	.db #0xff	; 255
      00C60B                       1491 __xinit__ak820_oneshot_target:
      00C60B FF                    1492 	.db #0xff	; 255
                                   1493 	.area CABS    (ABS,CODE)
                                   1494 
                                   1495 ; Experimental exact instruction outlining.
                                   1496 	.globl _ak820_outline_0004
                                   1497 	.globl _ak820_outline_0005
                                   1498 	.globl _ak820_outline_0010
                                   1499 	.globl _ak820_outline_0011
                                   1500 	.globl _ak820_outline_0012
                                   1501 	.globl _ak820_outline_0013
                                   1502 	.globl _ak820_outline_0014
                                   1503 	.globl _ak820_outline_0017
                                   1504 	.globl _ak820_outline_0022
                                   1505 	.globl _ak820_outline_0024
                                   1506 	.globl _ak820_outline_0030
                                   1507 	.globl _ak820_outline_0034
                                   1508 	.globl _ak820_outline_0046
                                   1509 	.globl _ak820_outline_0051
                                   1510 	.globl _ak820_outline_0055
                                   1511 	.globl _ak820_outline_0057
                                   1512 	.globl _ak820_outline_0059
                                   1513 	.globl _ak820_outline_0061
                                   1514 	.globl _ak820_outline_0065
                                   1515 	.globl _ak820_outline_0077
                                   1516 	.globl _ak820_outline_0091
                                   1517 	.globl _ak820_outline_0097
                                   1518 	.globl _ak820_outline_0098
                                   1519 	.globl _ak820_outline_0100
                                   1520 	.globl _ak820_outline_0103
                                   1521 	.globl _ak820_outline_0104
                                   1522 	.globl _ak820_outline_0116
                                   1523 	.globl _ak820_outline_0121
                                   1524 	.globl _ak820_outline_0122
                                   1525 	.globl _ak820_outline_0131
                                   1526 	.globl _ak820_outline_0153
                                   1527 	.globl _ak820_outline_0156
                                   1528 	.globl _ak820_outline_0187
                                   1529 
                                   1530 	.area CSEG (CODE)
                                   1531 ; function ak820_outline_0012
      004B65                       1532 _ak820_outline_0012:
      004B65 2E               [12] 1533 	add	a,r6
      004B66 FC               [12] 1534 	mov	r4,a
      004B67 E4               [12] 1535 	clr	a
      004B68 3F               [12] 1536 	addc	a,r7
      004B69 FD               [12] 1537 	mov	r5,a
      004B6A 8C 82            [24] 1538 	mov	dpl,r4
      004B6C 8D 83            [24] 1539 	mov	dph,r5
      004B6E E0               [24] 1540 	movx	a,@dptr
      004B6F 22               [24] 1541 	ret
                                   1542 
                                   1543 	.area CSEG (CODE)
                                   1544 ; function ak820_outline_0013
      004B70                       1545 _ak820_outline_0013:
      004B70 2E               [12] 1546 	add	a,r6
      004B71 FB               [12] 1547 	mov	r3,a
      004B72 E4               [12] 1548 	clr	a
      004B73 3F               [12] 1549 	addc	a,r7
      004B74 FC               [12] 1550 	mov	r4,a
      004B75 8B 82            [24] 1551 	mov	dpl,r3
      004B77 8C 83            [24] 1552 	mov	dph,r4
      004B79 E0               [24] 1553 	movx	a,@dptr
      004B7A 22               [24] 1554 	ret
                                   1555 
                                   1556 	.area CSEG (CODE)
                                   1557 ; function ak820_outline_0022
      004B7B                       1558 _ak820_outline_0022:
      004B7B 90 0D AA         [24] 1559 	mov	dptr,#___memcpy_PARM_2
      004B7E EC               [12] 1560 	mov	a,r4
      004B7F F0               [24] 1561 	movx	@dptr,a
      004B80 ED               [12] 1562 	mov	a,r5
      004B81 A3               [24] 1563 	inc	dptr
      004B82 F0               [24] 1564 	movx	@dptr,a
      004B83 E4               [12] 1565 	clr	a
      004B84 A3               [24] 1566 	inc	dptr
      004B85 F0               [24] 1567 	movx	@dptr,a
      004B86 90 0D AD         [24] 1568 	mov	dptr,#___memcpy_PARM_3
      004B89 74 02            [12] 1569 	mov	a,#0x02
      004B8B F0               [24] 1570 	movx	@dptr,a
      004B8C E4               [12] 1571 	clr	a
      004B8D A3               [24] 1572 	inc	dptr
      004B8E F0               [24] 1573 	movx	@dptr,a
      004B8F 90 06 38         [24] 1574 	mov	dptr,#_ak820_tapping_source_PARM_1
      004B92 F5 F0            [12] 1575 	mov	b,a
      004B94 22               [24] 1576 	ret
                                   1577 
                                   1578 	.area CSEG (CODE)
                                   1579 ; function ak820_outline_0024
      004B95                       1580 _ak820_outline_0024:
      004B95 24 B2            [12] 1581 	add	a,#_source_state
      004B97 FB               [12] 1582 	mov	r3,a
      004B98 E4               [12] 1583 	clr	a
      004B99 34 05            [12] 1584 	addc	a,#(_source_state>>8)
      004B9B FC               [12] 1585 	mov	r4,a
      004B9C 8B 82            [24] 1586 	mov	dpl,r3
      004B9E 8C 83            [24] 1587 	mov	dph,r4
      004BA0 E0               [24] 1588 	movx	a,@dptr
      004BA1 FA               [12] 1589 	mov	r2,a
      004BA2 22               [24] 1590 	ret
                                   1591 
                                   1592 	.area CSEG (CODE)
                                   1593 ; function ak820_outline_0046
      004BA3                       1594 _ak820_outline_0046:
      004BA3 2E               [12] 1595 	add	a,r6
      004BA4 FA               [12] 1596 	mov	r2,a
      004BA5 E4               [12] 1597 	clr	a
      004BA6 3F               [12] 1598 	addc	a,r7
      004BA7 FB               [12] 1599 	mov	r3,a
      004BA8 8A 82            [24] 1600 	mov	dpl,r2
      004BAA 8B 83            [24] 1601 	mov	dph,r3
      004BAC E0               [24] 1602 	movx	a,@dptr
      004BAD 22               [24] 1603 	ret
                                   1604 
                                   1605 	.area CSEG (CODE)
                                   1606 ; function ak820_outline_0055
      004BAE                       1607 _ak820_outline_0055:
      004BAE 74 01            [12] 1608 	mov	a,#0x01
      004BB0 F0               [24] 1609 	movx	@dptr,a
      004BB1 8E 82            [24] 1610 	mov	dpl,r6
      004BB3 8F 83            [24] 1611 	mov	dph,r7
      004BB5 22               [24] 1612 	ret
                                   1613 
                                   1614 	.area CSEG (CODE)
                                   1615 ; function ak820_outline_0057
      004BB6                       1616 _ak820_outline_0057:
      004BB6 FE               [12] 1617 	mov	r6,a
      004BB7 8D 82            [24] 1618 	mov	dpl,r5
      004BB9 8E 83            [24] 1619 	mov	dph,r6
      004BBB E0               [24] 1620 	movx	a,@dptr
      004BBC FC               [12] 1621 	mov	r4,a
      004BBD 22               [24] 1622 	ret
                                   1623 
                                   1624 	.area CSEG (CODE)
                                   1625 ; function ak820_outline_0059
      004BBE                       1626 _ak820_outline_0059:
      004BBE EE               [12] 1627 	mov	a,r6
      004BBF F0               [24] 1628 	movx	@dptr,a
      004BC0 EF               [12] 1629 	mov	a,r7
      004BC1 A3               [24] 1630 	inc	dptr
      004BC2 F0               [24] 1631 	movx	@dptr,a
      004BC3 22               [24] 1632 	ret
                                   1633 
                                   1634 	.area CSEG (CODE)
                                   1635 ; function ak820_outline_0065
      004BC4                       1636 _ak820_outline_0065:
      004BC4 8B 82            [24] 1637 	mov	dpl,r3
      004BC6 8C 83            [24] 1638 	mov	dph,r4
      004BC8 E0               [24] 1639 	movx	a,@dptr
      004BC9 FA               [12] 1640 	mov	r2,a
      004BCA 22               [24] 1641 	ret
                                   1642 
                                   1643 	.area CSEG (CODE)
                                   1644 ; function ak820_outline_0077
      004BCB                       1645 _ak820_outline_0077:
      004BCB 24 B2            [12] 1646 	add	a,#_source_state
      004BCD FC               [12] 1647 	mov	r4,a
      004BCE E4               [12] 1648 	clr	a
      004BCF 34 05            [12] 1649 	addc	a,#(_source_state>>8)
      004BD1 FD               [12] 1650 	mov	r5,a
      004BD2 8C 82            [24] 1651 	mov	dpl,r4
      004BD4 8D 83            [24] 1652 	mov	dph,r5
      004BD6 E0               [24] 1653 	movx	a,@dptr
      004BD7 FB               [12] 1654 	mov	r3,a
      004BD8 22               [24] 1655 	ret
                                   1656 
                                   1657 	.area CSEG (CODE)
                                   1658 ; function ak820_outline_0091
      004BD9                       1659 _ak820_outline_0091:
      004BD9 8B 82            [24] 1660 	mov	dpl,r3
      004BDB 8C 83            [24] 1661 	mov	dph,r4
      004BDD EA               [12] 1662 	mov	a,r2
      004BDE F0               [24] 1663 	movx	@dptr,a
      004BDF 22               [24] 1664 	ret
                                   1665 
                                   1666 	.area CSEG (CODE)
                                   1667 ; function ak820_outline_0153
      004BE0                       1668 _ak820_outline_0153:
      004BE0 90 0D BB         [24] 1669 	mov	dptr,#_pending
      004BE3 74 FF            [12] 1670 	mov	a,#0xff
      004BE5 F0               [24] 1671 	movx	@dptr,a
      004BE6 22               [24] 1672 	ret
