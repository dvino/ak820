                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module quantum
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _shutdown_quantum
                                     12 	.globl _extract_mod_bits
                                     13 	.globl _process_tri_layer
                                     14 	.globl _process_rgb
                                     15 	.globl _process_grave_esc
                                     16 	.globl _ak820_combo_process
                                     17 	.globl _ak820_tap_dance_process
                                     18 	.globl _process_repeat_key
                                     19 	.globl _process_last_key
                                     20 	.globl _process_caps_word
                                     21 	.globl _process_record_via
                                     22 	.globl _mcu_reset
                                     23 	.globl _bootloader_jump
                                     24 	.globl _ak820_resolve_key
                                     25 	.globl _default_layer_set
                                     26 	.globl _clear_keyboard
                                     27 	.globl _unregister_weak_mods
                                     28 	.globl _register_weak_mods
                                     29 	.globl _unregister_mods
                                     30 	.globl _register_mods
                                     31 	.globl _unregister_code
                                     32 	.globl _register_code
                                     33 	.globl _eeconfig_disable
                                     34 	.globl _rgb_matrix_set_suspend_state
                                     35 	.globl _rgb_matrix_task
                                     36 	.globl _mDelaymS
                                     37 	.globl _ADC_START
                                     38 	.globl _S0_R_FIFO
                                     39 	.globl _S0_T_FIFO
                                     40 	.globl _S0_FREE
                                     41 	.globl _S0_IF_BYTE
                                     42 	.globl _S0_IF_FIRST
                                     43 	.globl _S0_IF_OV
                                     44 	.globl _S0_FST_ACT
                                     45 	.globl _CP_RL2
                                     46 	.globl _C_T2
                                     47 	.globl _TR2
                                     48 	.globl _EXEN2
                                     49 	.globl _TCLK
                                     50 	.globl _RCLK
                                     51 	.globl _EXF2
                                     52 	.globl _CAP1F
                                     53 	.globl _TF2
                                     54 	.globl _RI
                                     55 	.globl _TI
                                     56 	.globl _RB8
                                     57 	.globl _TB8
                                     58 	.globl _REN
                                     59 	.globl _SM2
                                     60 	.globl _SM1
                                     61 	.globl _SM0
                                     62 	.globl _IT0
                                     63 	.globl _IE0
                                     64 	.globl _IT1
                                     65 	.globl _IE1
                                     66 	.globl _TR0
                                     67 	.globl _TF0
                                     68 	.globl _TR1
                                     69 	.globl _TF1
                                     70 	.globl _P4_0
                                     71 	.globl _P4_1
                                     72 	.globl _P4_2
                                     73 	.globl _P4_3
                                     74 	.globl _P4_4
                                     75 	.globl _P4_5
                                     76 	.globl _P4_6
                                     77 	.globl _RXD
                                     78 	.globl _TXD
                                     79 	.globl _INT0
                                     80 	.globl _INT1
                                     81 	.globl _T0
                                     82 	.globl _T1
                                     83 	.globl _MOSI1
                                     84 	.globl _MISO1
                                     85 	.globl _SCK1
                                     86 	.globl _P3_0
                                     87 	.globl _P3_1
                                     88 	.globl _P3_2
                                     89 	.globl _P3_3
                                     90 	.globl _P3_4
                                     91 	.globl _P3_5
                                     92 	.globl _P3_6
                                     93 	.globl _P3_7
                                     94 	.globl _CAP1_
                                     95 	.globl _T2_
                                     96 	.globl _CAP2_
                                     97 	.globl _T2EX_
                                     98 	.globl _RXD1
                                     99 	.globl _TXD1
                                    100 	.globl _P2_0
                                    101 	.globl _P2_1
                                    102 	.globl _P2_2
                                    103 	.globl _P2_3
                                    104 	.globl _P2_4
                                    105 	.globl _P2_5
                                    106 	.globl _P2_6
                                    107 	.globl _P2_7
                                    108 	.globl _AIN0
                                    109 	.globl _AIN1
                                    110 	.globl _AIN2
                                    111 	.globl _AIN3
                                    112 	.globl _AIN4
                                    113 	.globl _AIN5
                                    114 	.globl _AIN6
                                    115 	.globl _AIN7
                                    116 	.globl _CAP1
                                    117 	.globl _T2
                                    118 	.globl _CAP2
                                    119 	.globl _T2EX
                                    120 	.globl _INT0_
                                    121 	.globl _SCS
                                    122 	.globl _MOSI
                                    123 	.globl _MISO
                                    124 	.globl _SCK
                                    125 	.globl _RXD1_
                                    126 	.globl _TXD1_
                                    127 	.globl _P1_0
                                    128 	.globl _P1_1
                                    129 	.globl _P1_2
                                    130 	.globl _P1_3
                                    131 	.globl _P1_4
                                    132 	.globl _P1_5
                                    133 	.globl _P1_6
                                    134 	.globl _P1_7
                                    135 	.globl _AIN8
                                    136 	.globl _AIN9
                                    137 	.globl _AIN10
                                    138 	.globl _AIN11
                                    139 	.globl _AIN12
                                    140 	.globl _AIN13
                                    141 	.globl _RXD_
                                    142 	.globl _TXD_
                                    143 	.globl _SCL0
                                    144 	.globl _SDA0
                                    145 	.globl _P0_0
                                    146 	.globl _P0_1
                                    147 	.globl _P0_2
                                    148 	.globl _P0_3
                                    149 	.globl _P0_4
                                    150 	.globl _P0_5
                                    151 	.globl _P0_6
                                    152 	.globl _P0_7
                                    153 	.globl _IE_SPI0
                                    154 	.globl _IE_USB
                                    155 	.globl _IE_ADC
                                    156 	.globl _IE_UART1
                                    157 	.globl _IE_PWM_I2C
                                    158 	.globl _IE_GPIO
                                    159 	.globl _IE_WDOG
                                    160 	.globl _PX0
                                    161 	.globl _PT0
                                    162 	.globl _PX1
                                    163 	.globl _PT1
                                    164 	.globl _PS
                                    165 	.globl _PT2
                                    166 	.globl _PL_FLAG
                                    167 	.globl _PH_FLAG
                                    168 	.globl _EX0
                                    169 	.globl _ET0
                                    170 	.globl _EX1
                                    171 	.globl _ET1
                                    172 	.globl _ES
                                    173 	.globl _ET2
                                    174 	.globl _E_DIS
                                    175 	.globl _EA
                                    176 	.globl _P
                                    177 	.globl _F1
                                    178 	.globl _OV
                                    179 	.globl _RS0
                                    180 	.globl _RS1
                                    181 	.globl _F0
                                    182 	.globl _AC
                                    183 	.globl _CY
                                    184 	.globl _I2CS_INT_ST
                                    185 	.globl _I2CX_INT
                                    186 	.globl _LED_STATUS
                                    187 	.globl _LED_DMA_H
                                    188 	.globl _LED_DMA_L
                                    189 	.globl _LED_DMA
                                    190 	.globl _LED_PWM_OE
                                    191 	.globl _LED_COMMON
                                    192 	.globl _ADC_CHAN
                                    193 	.globl _ADC_DAT_H
                                    194 	.globl _ADC_DAT_L
                                    195 	.globl _ADC_DAT
                                    196 	.globl _ADC_CTRL
                                    197 	.globl _SPI1_CK_SE
                                    198 	.globl _SPI1_CTRL
                                    199 	.globl _SPI1_DATA
                                    200 	.globl _SPI1_STAT
                                    201 	.globl _SIF1
                                    202 	.globl _SBAUD1
                                    203 	.globl _SBUF1
                                    204 	.globl _SCON1
                                    205 	.globl _SPI0_SETUP
                                    206 	.globl _SPI0_CK_SE
                                    207 	.globl _SPI0_CTRL
                                    208 	.globl _SPI0_DATA
                                    209 	.globl _SPI0_STAT
                                    210 	.globl _T2CAP1H
                                    211 	.globl _T2CAP1L
                                    212 	.globl _T2CAP1
                                    213 	.globl _TH2
                                    214 	.globl _TL2
                                    215 	.globl _T2COUNT
                                    216 	.globl _RCAP2H
                                    217 	.globl _RCAP2L
                                    218 	.globl _RCAP2
                                    219 	.globl _T2MOD
                                    220 	.globl _T2CON
                                    221 	.globl _SBUF
                                    222 	.globl _SCON
                                    223 	.globl _TH1
                                    224 	.globl _TH0
                                    225 	.globl _TL1
                                    226 	.globl _TL0
                                    227 	.globl _TMOD
                                    228 	.globl _TCON
                                    229 	.globl _XBUS_AUX
                                    230 	.globl _P7
                                    231 	.globl _P6_DIR
                                    232 	.globl _P6_OUT_PU
                                    233 	.globl _P6_IN
                                    234 	.globl _P5_DIR
                                    235 	.globl _P5_OUT_PU
                                    236 	.globl _P5_IN
                                    237 	.globl _P4_LED_KEY
                                    238 	.globl _P4_DIR_PU
                                    239 	.globl _P4_MOD_OC
                                    240 	.globl _P4
                                    241 	.globl _P3_DIR_PU
                                    242 	.globl _P3_MOD_OC
                                    243 	.globl _P3
                                    244 	.globl _P2_DIR_PU
                                    245 	.globl _P2_MOD_OC
                                    246 	.globl _P2
                                    247 	.globl _P1_DIR_PU
                                    248 	.globl _P1_MOD_OC
                                    249 	.globl _P1
                                    250 	.globl _P0_DIR_PU
                                    251 	.globl _P0_MOD_OC
                                    252 	.globl _P0
                                    253 	.globl _ROM_CTRL
                                    254 	.globl _ROM_DATA_HH
                                    255 	.globl _ROM_DATA_HL
                                    256 	.globl _ROM_DATA_HI
                                    257 	.globl _ROM_ADDR_H
                                    258 	.globl _ROM_ADDR_L
                                    259 	.globl _ROM_ADDR
                                    260 	.globl _GPIO_IE
                                    261 	.globl _IP_EX
                                    262 	.globl _IE_EX
                                    263 	.globl _IP
                                    264 	.globl _IE
                                    265 	.globl _WDOG_COUNT
                                    266 	.globl _RESET_KEEP
                                    267 	.globl _WAKE_CTRL
                                    268 	.globl _CLOCK_CFG
                                    269 	.globl _POWER_CFG
                                    270 	.globl _PCON
                                    271 	.globl _GLOBAL_CFG
                                    272 	.globl _SAFE_MOD
                                    273 	.globl _DPH
                                    274 	.globl _DPL
                                    275 	.globl _SP
                                    276 	.globl _A_INV
                                    277 	.globl _B
                                    278 	.globl _ACC
                                    279 	.globl _PSW
                                    280 	.globl _process_record_quantum_helper_PARM_2
                                    281 	.globl _get_record_keycode_PARM_2
                                    282 	.globl _register_code16
                                    283 	.globl _unregister_code16
                                    284 	.globl _reset_keyboard
                                    285 	.globl _soft_reset_keyboard
                                    286 	.globl _get_record_keycode
                                    287 	.globl _pre_process_record_quantum
                                    288 	.globl _process_record_quantum
                                    289 	.globl _process_record_quantum_helper
                                    290 	.globl _shutdown_user
                                    291 ;--------------------------------------------------------
                                    292 ; special function registers
                                    293 ;--------------------------------------------------------
                                    294 	.area RSEG    (ABS,DATA)
      000000                        295 	.org 0x0000
                           0000D0   296 _PSW	=	0x00d0
                           0000E0   297 _ACC	=	0x00e0
                           0000F0   298 _B	=	0x00f0
                           0000FD   299 _A_INV	=	0x00fd
                           000081   300 _SP	=	0x0081
                           000082   301 _DPL	=	0x0082
                           000083   302 _DPH	=	0x0083
                           0000A1   303 _SAFE_MOD	=	0x00a1
                           0000B1   304 _GLOBAL_CFG	=	0x00b1
                           000087   305 _PCON	=	0x0087
                           0000BA   306 _POWER_CFG	=	0x00ba
                           0000B9   307 _CLOCK_CFG	=	0x00b9
                           0000A9   308 _WAKE_CTRL	=	0x00a9
                           0000FE   309 _RESET_KEEP	=	0x00fe
                           0000FF   310 _WDOG_COUNT	=	0x00ff
                           0000A8   311 _IE	=	0x00a8
                           0000B8   312 _IP	=	0x00b8
                           0000E8   313 _IE_EX	=	0x00e8
                           0000E9   314 _IP_EX	=	0x00e9
                           0000B2   315 _GPIO_IE	=	0x00b2
                           008584   316 _ROM_ADDR	=	0x8584
                           000084   317 _ROM_ADDR_L	=	0x0084
                           000085   318 _ROM_ADDR_H	=	0x0085
                           008F8E   319 _ROM_DATA_HI	=	0x8f8e
                           00008E   320 _ROM_DATA_HL	=	0x008e
                           00008F   321 _ROM_DATA_HH	=	0x008f
                           000086   322 _ROM_CTRL	=	0x0086
                           000080   323 _P0	=	0x0080
                           0000C4   324 _P0_MOD_OC	=	0x00c4
                           0000C5   325 _P0_DIR_PU	=	0x00c5
                           000090   326 _P1	=	0x0090
                           000092   327 _P1_MOD_OC	=	0x0092
                           000093   328 _P1_DIR_PU	=	0x0093
                           0000A0   329 _P2	=	0x00a0
                           000094   330 _P2_MOD_OC	=	0x0094
                           000095   331 _P2_DIR_PU	=	0x0095
                           0000B0   332 _P3	=	0x00b0
                           000096   333 _P3_MOD_OC	=	0x0096
                           000097   334 _P3_DIR_PU	=	0x0097
                           0000C0   335 _P4	=	0x00c0
                           0000C2   336 _P4_MOD_OC	=	0x00c2
                           0000C3   337 _P4_DIR_PU	=	0x00c3
                           0000C1   338 _P4_LED_KEY	=	0x00c1
                           0000AA   339 _P5_IN	=	0x00aa
                           0000AB   340 _P5_OUT_PU	=	0x00ab
                           0000AC   341 _P5_DIR	=	0x00ac
                           0000AD   342 _P6_IN	=	0x00ad
                           0000AE   343 _P6_OUT_PU	=	0x00ae
                           0000AF   344 _P6_DIR	=	0x00af
                           0000F1   345 _P7	=	0x00f1
                           0000A2   346 _XBUS_AUX	=	0x00a2
                           000088   347 _TCON	=	0x0088
                           000089   348 _TMOD	=	0x0089
                           00008A   349 _TL0	=	0x008a
                           00008B   350 _TL1	=	0x008b
                           00008C   351 _TH0	=	0x008c
                           00008D   352 _TH1	=	0x008d
                           000098   353 _SCON	=	0x0098
                           000099   354 _SBUF	=	0x0099
                           0000C8   355 _T2CON	=	0x00c8
                           0000C9   356 _T2MOD	=	0x00c9
                           00CBCA   357 _RCAP2	=	0xcbca
                           0000CA   358 _RCAP2L	=	0x00ca
                           0000CB   359 _RCAP2H	=	0x00cb
                           00CDCC   360 _T2COUNT	=	0xcdcc
                           0000CC   361 _TL2	=	0x00cc
                           0000CD   362 _TH2	=	0x00cd
                           00CFCE   363 _T2CAP1	=	0xcfce
                           0000CE   364 _T2CAP1L	=	0x00ce
                           0000CF   365 _T2CAP1H	=	0x00cf
                           0000F8   366 _SPI0_STAT	=	0x00f8
                           0000F9   367 _SPI0_DATA	=	0x00f9
                           0000FA   368 _SPI0_CTRL	=	0x00fa
                           0000FB   369 _SPI0_CK_SE	=	0x00fb
                           0000FC   370 _SPI0_SETUP	=	0x00fc
                           0000BC   371 _SCON1	=	0x00bc
                           0000BD   372 _SBUF1	=	0x00bd
                           0000BE   373 _SBAUD1	=	0x00be
                           0000BF   374 _SIF1	=	0x00bf
                           0000B4   375 _SPI1_STAT	=	0x00b4
                           0000B5   376 _SPI1_DATA	=	0x00b5
                           0000B6   377 _SPI1_CTRL	=	0x00b6
                           0000B7   378 _SPI1_CK_SE	=	0x00b7
                           0000F3   379 _ADC_CTRL	=	0x00f3
                           00F5F4   380 _ADC_DAT	=	0xf5f4
                           0000F4   381 _ADC_DAT_L	=	0x00f4
                           0000F5   382 _ADC_DAT_H	=	0x00f5
                           0000F6   383 _ADC_CHAN	=	0x00f6
                           0000A6   384 _LED_COMMON	=	0x00a6
                           0000A7   385 _LED_PWM_OE	=	0x00a7
                           00C7C6   386 _LED_DMA	=	0xc7c6
                           0000C6   387 _LED_DMA_L	=	0x00c6
                           0000C7   388 _LED_DMA_H	=	0x00c7
                           0000F7   389 _LED_STATUS	=	0x00f7
                           0000B3   390 _I2CX_INT	=	0x00b3
                           0000BB   391 _I2CS_INT_ST	=	0x00bb
                                    392 ;--------------------------------------------------------
                                    393 ; special function bits
                                    394 ;--------------------------------------------------------
                                    395 	.area RSEG    (ABS,DATA)
      000000                        396 	.org 0x0000
                           0000D7   397 _CY	=	0x00d7
                           0000D6   398 _AC	=	0x00d6
                           0000D5   399 _F0	=	0x00d5
                           0000D4   400 _RS1	=	0x00d4
                           0000D3   401 _RS0	=	0x00d3
                           0000D2   402 _OV	=	0x00d2
                           0000D1   403 _F1	=	0x00d1
                           0000D0   404 _P	=	0x00d0
                           0000AF   405 _EA	=	0x00af
                           0000AE   406 _E_DIS	=	0x00ae
                           0000AD   407 _ET2	=	0x00ad
                           0000AC   408 _ES	=	0x00ac
                           0000AB   409 _ET1	=	0x00ab
                           0000AA   410 _EX1	=	0x00aa
                           0000A9   411 _ET0	=	0x00a9
                           0000A8   412 _EX0	=	0x00a8
                           0000BF   413 _PH_FLAG	=	0x00bf
                           0000BE   414 _PL_FLAG	=	0x00be
                           0000BD   415 _PT2	=	0x00bd
                           0000BC   416 _PS	=	0x00bc
                           0000BB   417 _PT1	=	0x00bb
                           0000BA   418 _PX1	=	0x00ba
                           0000B9   419 _PT0	=	0x00b9
                           0000B8   420 _PX0	=	0x00b8
                           0000EF   421 _IE_WDOG	=	0x00ef
                           0000EE   422 _IE_GPIO	=	0x00ee
                           0000ED   423 _IE_PWM_I2C	=	0x00ed
                           0000EC   424 _IE_UART1	=	0x00ec
                           0000EB   425 _IE_ADC	=	0x00eb
                           0000E9   426 _IE_USB	=	0x00e9
                           0000E8   427 _IE_SPI0	=	0x00e8
                           000087   428 _P0_7	=	0x0087
                           000086   429 _P0_6	=	0x0086
                           000085   430 _P0_5	=	0x0085
                           000084   431 _P0_4	=	0x0084
                           000083   432 _P0_3	=	0x0083
                           000082   433 _P0_2	=	0x0082
                           000081   434 _P0_1	=	0x0081
                           000080   435 _P0_0	=	0x0080
                           000081   436 _SDA0	=	0x0081
                           000080   437 _SCL0	=	0x0080
                           000083   438 _TXD_	=	0x0083
                           000082   439 _RXD_	=	0x0082
                           000085   440 _AIN13	=	0x0085
                           000084   441 _AIN12	=	0x0084
                           000083   442 _AIN11	=	0x0083
                           000082   443 _AIN10	=	0x0082
                           000081   444 _AIN9	=	0x0081
                           000080   445 _AIN8	=	0x0080
                           000097   446 _P1_7	=	0x0097
                           000096   447 _P1_6	=	0x0096
                           000095   448 _P1_5	=	0x0095
                           000094   449 _P1_4	=	0x0094
                           000093   450 _P1_3	=	0x0093
                           000092   451 _P1_2	=	0x0092
                           000091   452 _P1_1	=	0x0091
                           000090   453 _P1_0	=	0x0090
                           000097   454 _TXD1_	=	0x0097
                           000096   455 _RXD1_	=	0x0096
                           000097   456 _SCK	=	0x0097
                           000096   457 _MISO	=	0x0096
                           000095   458 _MOSI	=	0x0095
                           000094   459 _SCS	=	0x0094
                           000092   460 _INT0_	=	0x0092
                           000091   461 _T2EX	=	0x0091
                           000091   462 _CAP2	=	0x0091
                           000090   463 _T2	=	0x0090
                           000090   464 _CAP1	=	0x0090
                           000097   465 _AIN7	=	0x0097
                           000096   466 _AIN6	=	0x0096
                           000095   467 _AIN5	=	0x0095
                           000094   468 _AIN4	=	0x0094
                           000093   469 _AIN3	=	0x0093
                           000092   470 _AIN2	=	0x0092
                           000091   471 _AIN1	=	0x0091
                           000090   472 _AIN0	=	0x0090
                           0000A7   473 _P2_7	=	0x00a7
                           0000A6   474 _P2_6	=	0x00a6
                           0000A5   475 _P2_5	=	0x00a5
                           0000A4   476 _P2_4	=	0x00a4
                           0000A3   477 _P2_3	=	0x00a3
                           0000A2   478 _P2_2	=	0x00a2
                           0000A1   479 _P2_1	=	0x00a1
                           0000A0   480 _P2_0	=	0x00a0
                           0000A7   481 _TXD1	=	0x00a7
                           0000A6   482 _RXD1	=	0x00a6
                           0000A5   483 _T2EX_	=	0x00a5
                           0000A5   484 _CAP2_	=	0x00a5
                           0000A4   485 _T2_	=	0x00a4
                           0000A4   486 _CAP1_	=	0x00a4
                           0000B7   487 _P3_7	=	0x00b7
                           0000B6   488 _P3_6	=	0x00b6
                           0000B5   489 _P3_5	=	0x00b5
                           0000B4   490 _P3_4	=	0x00b4
                           0000B3   491 _P3_3	=	0x00b3
                           0000B2   492 _P3_2	=	0x00b2
                           0000B1   493 _P3_1	=	0x00b1
                           0000B0   494 _P3_0	=	0x00b0
                           0000B7   495 _SCK1	=	0x00b7
                           0000B6   496 _MISO1	=	0x00b6
                           0000B5   497 _MOSI1	=	0x00b5
                           0000B5   498 _T1	=	0x00b5
                           0000B4   499 _T0	=	0x00b4
                           0000B3   500 _INT1	=	0x00b3
                           0000B2   501 _INT0	=	0x00b2
                           0000B1   502 _TXD	=	0x00b1
                           0000B0   503 _RXD	=	0x00b0
                           0000C6   504 _P4_6	=	0x00c6
                           0000C5   505 _P4_5	=	0x00c5
                           0000C4   506 _P4_4	=	0x00c4
                           0000C3   507 _P4_3	=	0x00c3
                           0000C2   508 _P4_2	=	0x00c2
                           0000C1   509 _P4_1	=	0x00c1
                           0000C0   510 _P4_0	=	0x00c0
                           00008F   511 _TF1	=	0x008f
                           00008E   512 _TR1	=	0x008e
                           00008D   513 _TF0	=	0x008d
                           00008C   514 _TR0	=	0x008c
                           00008B   515 _IE1	=	0x008b
                           00008A   516 _IT1	=	0x008a
                           000089   517 _IE0	=	0x0089
                           000088   518 _IT0	=	0x0088
                           00009F   519 _SM0	=	0x009f
                           00009E   520 _SM1	=	0x009e
                           00009D   521 _SM2	=	0x009d
                           00009C   522 _REN	=	0x009c
                           00009B   523 _TB8	=	0x009b
                           00009A   524 _RB8	=	0x009a
                           000099   525 _TI	=	0x0099
                           000098   526 _RI	=	0x0098
                           0000CF   527 _TF2	=	0x00cf
                           0000CF   528 _CAP1F	=	0x00cf
                           0000CE   529 _EXF2	=	0x00ce
                           0000CD   530 _RCLK	=	0x00cd
                           0000CC   531 _TCLK	=	0x00cc
                           0000CB   532 _EXEN2	=	0x00cb
                           0000CA   533 _TR2	=	0x00ca
                           0000C9   534 _C_T2	=	0x00c9
                           0000C8   535 _CP_RL2	=	0x00c8
                           0000FF   536 _S0_FST_ACT	=	0x00ff
                           0000FE   537 _S0_IF_OV	=	0x00fe
                           0000FD   538 _S0_IF_FIRST	=	0x00fd
                           0000FC   539 _S0_IF_BYTE	=	0x00fc
                           0000FB   540 _S0_FREE	=	0x00fb
                           0000FA   541 _S0_T_FIFO	=	0x00fa
                           0000F8   542 _S0_R_FIFO	=	0x00f8
                           0000F7   543 _ADC_START	=	0x00f7
                                    544 ;--------------------------------------------------------
                                    545 ; overlayable register banks
                                    546 ;--------------------------------------------------------
                                    547 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        548 	.ds 8
                                    549 ;--------------------------------------------------------
                                    550 ; internal ram data
                                    551 ;--------------------------------------------------------
                                    552 	.area DSEG    (DATA)
                                    553 ;--------------------------------------------------------
                                    554 ; overlayable items in internal ram
                                    555 ;--------------------------------------------------------
                                    556 ;--------------------------------------------------------
                                    557 ; indirectly addressable internal ram data
                                    558 ;--------------------------------------------------------
                                    559 	.area ISEG    (DATA)
                                    560 ;--------------------------------------------------------
                                    561 ; absolute internal ram data
                                    562 ;--------------------------------------------------------
                                    563 	.area IABS    (ABS,DATA)
                                    564 	.area IABS    (ABS,DATA)
                                    565 ;--------------------------------------------------------
                                    566 ; bit data
                                    567 ;--------------------------------------------------------
                                    568 	.area BSEG    (BIT)
      000026                        569 _get_record_keycode_sloc0_1_0:
      000026                        570 	.ds 1
      000027                        571 _pre_process_record_quantum_sloc0_1_0:
      000027                        572 	.ds 1
      000028                        573 _process_ak820_nkro_sloc0_1_0:
      000028                        574 	.ds 1
                                    575 ;--------------------------------------------------------
                                    576 ; paged external ram data
                                    577 ;--------------------------------------------------------
                                    578 	.area PSEG    (PAG,XDATA)
                                    579 ;--------------------------------------------------------
                                    580 ; uninitialized external ram data
                                    581 ;--------------------------------------------------------
                                    582 	.area XSEG    (XDATA)
      000CA8                        583 _extract_mod_bits_code_10000_606:
      000CA8                        584 	.ds 2
      000CAA                        585 _register_code16_code_10000_612:
      000CAA                        586 	.ds 2
      000CAC                        587 _unregister_code16_code_10000_617:
      000CAC                        588 	.ds 2
      000CAE                        589 _get_record_keycode_PARM_2:
      000CAE                        590 	.ds 1
      000CAF                        591 _get_record_keycode_record_argument_10000_655:
      000CAF                        592 	.ds 2
      000CB1                        593 _pre_process_record_quantum_record_argument_10000_661:
      000CB1                        594 	.ds 2
      000CB3                        595 _process_record_quantum_record_10000_666:
      000CB3                        596 	.ds 2
      000CB5                        597 _process_ak820_nkro_PARM_2:
      000CB5                        598 	.ds 3
      000CB8                        599 _process_ak820_nkro_keycode_10000_668:
      000CB8                        600 	.ds 2
      000CBA                        601 _process_record_quantum_helper_PARM_2:
      000CBA                        602 	.ds 2
      000CBC                        603 _process_record_quantum_helper_keycode_10000_673:
      000CBC                        604 	.ds 2
      000CBE                        605 _get_u8_str_last_num_10000_699:
      000CBE                        606 	.ds 1
      000CBF                        607 _get_u16_str_last_num_10000_703:
      000CBF                        608 	.ds 2
                                    609 ;--------------------------------------------------------
                                    610 ; absolute external ram data
                                    611 ;--------------------------------------------------------
                                    612 	.area XABS    (ABS,XDATA)
                                    613 ;--------------------------------------------------------
                                    614 ; initialized external ram data
                                    615 ;--------------------------------------------------------
                                    616 	.area XISEG   (XDATA)
                                    617 	.area HOME    (CODE)
                                    618 	.area GSINIT0 (CODE)
                                    619 	.area GSINIT1 (CODE)
                                    620 	.area GSINIT2 (CODE)
                                    621 	.area GSINIT3 (CODE)
                                    622 	.area GSINIT4 (CODE)
                                    623 	.area GSINIT5 (CODE)
                                    624 	.area GSINIT  (CODE)
                                    625 	.area GSFINAL (CODE)
                                    626 	.area CSEG    (CODE)
                                    627 ;--------------------------------------------------------
                                    628 ; global & static initialisations
                                    629 ;--------------------------------------------------------
                                    630 	.area HOME    (CODE)
                                    631 	.area GSINIT  (CODE)
                                    632 	.area GSFINAL (CODE)
                                    633 	.area GSINIT  (CODE)
                                    634 ;------------------------------------------------------------
                                    635 ;Allocation info for local variables in function 'get_u8_str'
                                    636 ;------------------------------------------------------------
                                    637 ;curr_pad      Allocated with name '_get_u8_str_PARM_2'
                                    638 ;curr_num      Allocated with name '_get_u8_str_curr_num_10000_698'
                                    639 ;buf           Allocated with name '_get_u8_str_buf_10000_699'
                                    640 ;last_num      Allocated with name '_get_u8_str_last_num_10000_699'
                                    641 ;last_pad      Allocated with name '_get_u8_str_last_pad_10000_699'
                                    642 ;------------------------------------------------------------
                                    643 ;	quantum/quantum.c:789: static uint8_t last_num = 0xFF;
      0030F3 90 0C BE         [24]  644 	mov	dptr,#_get_u8_str_last_num_10000_699
      0030F6 74 FF            [12]  645 	mov	a,#0xff
      0030F8 F0               [24]  646 	movx	@dptr,a
                                    647 ;------------------------------------------------------------
                                    648 ;Allocation info for local variables in function 'get_u16_str'
                                    649 ;------------------------------------------------------------
                                    650 ;curr_pad      Allocated with name '_get_u16_str_PARM_2'
                                    651 ;curr_num      Allocated with name '_get_u16_str_curr_num_10000_702'
                                    652 ;buf           Allocated with name '_get_u16_str_buf_10000_703'
                                    653 ;last_num      Allocated with name '_get_u16_str_last_num_10000_703'
                                    654 ;last_pad      Allocated with name '_get_u16_str_last_pad_10000_703'
                                    655 ;------------------------------------------------------------
                                    656 ;	quantum/quantum.c:809: static uint16_t last_num = 0xFF;
      0030F9 90 0C BF         [24]  657 	mov	dptr,#_get_u16_str_last_num_10000_703
      0030FC 74 FF            [12]  658 	mov	a,#0xff
      0030FE F0               [24]  659 	movx	@dptr,a
      0030FF E4               [12]  660 	clr	a
      003100 A3               [24]  661 	inc	dptr
      003101 F0               [24]  662 	movx	@dptr,a
                                    663 ;--------------------------------------------------------
                                    664 ; Home
                                    665 ;--------------------------------------------------------
                                    666 	.area HOME    (CODE)
                                    667 	.area HOME    (CODE)
                                    668 ;--------------------------------------------------------
                                    669 ; code
                                    670 ;--------------------------------------------------------
                                    671 	.area CSEG    (CODE)
                                    672 ;------------------------------------------------------------
                                    673 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    674 ;------------------------------------------------------------
                                    675 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_193'
                                    676 ;------------------------------------------------------------
                                    677 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    678 ;	-----------------------------------------
                           000007   679 	ar7 = 0x07
                           000006   680 	ar6 = 0x06
                           000005   681 	ar5 = 0x05
                           000004   682 	ar4 = 0x04
                           000003   683 	ar3 = 0x03
                           000002   684 	ar2 = 0x02
                           000001   685 	ar1 = 0x01
                           000000   686 	ar0 = 0x00
                                    687 ;	 function extract_mod_bits
                                    688 ;	-----------------------------------------
      00A225                        689 _extract_mod_bits:
      00A225 12 38 4C         [24]  690 	lcall	_ak820_outline_0106
      00A228 90 0C A8         [24]  691 	mov	dptr,#_extract_mod_bits_code_10000_606
      00A22B 12 38 47         [24]  692 	lcall	_ak820_outline_0105
                                    693 ;	quantum/quantum.c:113: uint8_t mods = (uint8_t)(code >> 8);
      00A22E 90 0C A8         [24]  694 	mov	dptr,#_extract_mod_bits_code_10000_606
      00A231 E0               [24]  695 	movx	a,@dptr
      00A232 A3               [24]  696 	inc	dptr
      00A233 E0               [24]  697 	movx	a,@dptr
                                    698 ;	quantum/quantum.c:114: if (!mods || mods > (QK_MODS_MAX >> 8)) return 0;
      00A234 FF               [12]  699 	mov	r7,a
      00A235 60 05            [24]  700 	jz	00101$
      00A237 EF               [12]  701 	mov	a,r7
      00A238 24 E0            [12]  702 	add	a,#0xff - 0x1f
      00A23A 50 04            [24]  703 	jnc	00102$
                                    704 ;	free result
      00A23C                        705 00101$:
      00A23C 75 82 00         [24]  706 	mov	dpl, #0x00
      00A23F 22               [24]  707 	ret
      00A240                        708 00102$:
                                    709 ;	quantum/quantum.c:115: return (mods & 0x10) ? (uint8_t)(mods << 4) : mods;
      00A240 EF               [12]  710 	mov	a,r7
      00A241 30 E4 07         [24]  711 	jnb	acc.4,00106$
      00A244 EF               [12]  712 	mov	a,r7
      00A245 C4               [12]  713 	swap	a
      00A246 54 F0            [12]  714 	anl	a,#0xf0
      00A248 FE               [12]  715 	mov	r6,a
      00A249 80 02            [24]  716 	sjmp	00107$
      00A24B                        717 00106$:
      00A24B 8F 06            [24]  718 	mov	ar6,r7
      00A24D                        719 00107$:
      00A24D 8E 82            [24]  720 	mov	dpl, r6
                                    721 ;	quantum/quantum.c:143: }
      00A24F 22               [24]  722 	ret
                                    723 ;------------------------------------------------------------
                                    724 ;Allocation info for local variables in function 'do_code16'
                                    725 ;------------------------------------------------------------
                                    726 ;f             Allocated with name '_do_code16_PARM_2'
                                    727 ;code          Allocated with name '_do_code16_code_10000_609'
                                    728 ;------------------------------------------------------------
                                    729 ;	quantum/quantum.c:145: void do_code16(uint16_t code, void (*f)(uint8_t)) {
                                    730 ;	-----------------------------------------
                                    731 ;	 function register_code16
                                    732 ;	-----------------------------------------
      00A250                        733 _register_code16:
      00A250 12 38 4C         [24]  734 	lcall	_ak820_outline_0106
      00A253 90 0C AA         [24]  735 	mov	dptr,#_register_code16_code_10000_612
      00A256 12 38 47         [24]  736 	lcall	_ak820_outline_0105
                                    737 ;	quantum/quantum.c:151: uint8_t mods = extract_mod_bits(code);
      00A259 90 0C AA         [24]  738 	mov	dptr,#_register_code16_code_10000_612
      00A25C 12 37 A8         [24]  739 	lcall	_ak820_outline_0005
      00A25F C0 07            [24]  740 	push	ar7
      00A261 C0 06            [24]  741 	push	ar6
      00A263 51 25            [12]  742 	acall	_extract_mod_bits
      00A265 AD 82            [24]  743 	mov	r5, dpl
      00A267 D0 06            [24]  744 	pop	ar6
      00A269 D0 07            [24]  745 	pop	ar7
                                    746 ;	quantum/quantum.c:152: if (IS_MODIFIER_KEYCODE(code) || code == KC_NO) {
      00A26B 12 A0 66         [24]  747 	lcall	_ak820_outline_0120
      00A26E 40 07            [24]  748 	jc	00105$
      00A270 74 E7            [12]  749 	mov	a,#0xe7
      00A272 9E               [12]  750 	subb	a,r6
      00A273 E4               [12]  751 	clr	a
      00A274 9F               [12]  752 	subb	a,r7
      00A275 50 08            [24]  753 	jnc	00101$
                                    754 ;	free result
      00A277                        755 00105$:
      00A277 90 0C AA         [24]  756 	mov	dptr,#_register_code16_code_10000_612
      00A27A 12 48 AC         [24]  757 	lcall	_ak820_outline_0037
      00A27D 70 07            [24]  758 	jnz	00102$
      00A27F                        759 00101$:
                                    760 ;	quantum/quantum.c:153: register_mods(mods);
      00A27F 8D 82            [24]  761 	mov	dpl, r5
      00A281 12 7A A4         [24]  762 	lcall	_register_mods
      00A284 80 05            [24]  763 	sjmp	00103$
      00A286                        764 00102$:
                                    765 ;	quantum/quantum.c:155: register_weak_mods(mods);
      00A286 8D 82            [24]  766 	mov	dpl, r5
      00A288 12 7A CC         [24]  767 	lcall	_register_weak_mods
      00A28B                        768 00103$:
                                    769 ;	quantum/quantum.c:157: register_code(code);
      00A28B 90 0C AA         [24]  770 	mov	dptr,#_register_code16_code_10000_612
      00A28E E0               [24]  771 	movx	a,@dptr
      00A28F F5 82            [12]  772 	mov	dpl,a
                                    773 ;	quantum/quantum.c:167: }
      00A291 02 79 84         [24]  774 	ljmp	_register_code
                                    775 ;------------------------------------------------------------
                                    776 ;Allocation info for local variables in function 'unregister_code16'
                                    777 ;------------------------------------------------------------
                                    778 ;code          Allocated with name '_unregister_code16_code_10000_617'
                                    779 ;mods          Allocated with name '_unregister_code16_mods_10000_618'
                                    780 ;------------------------------------------------------------
                                    781 ;	quantum/quantum.c:169: __attribute__((weak)) void unregister_code16(uint16_t code) {
                                    782 ;	-----------------------------------------
                                    783 ;	 function unregister_code16
                                    784 ;	-----------------------------------------
      00A294                        785 _unregister_code16:
      00A294 12 38 4C         [24]  786 	lcall	_ak820_outline_0106
      00A297 90 0C AC         [24]  787 	mov	dptr,#_unregister_code16_code_10000_617
      00A29A 12 38 47         [24]  788 	lcall	_ak820_outline_0105
                                    789 ;	quantum/quantum.c:171: uint8_t mods = extract_mod_bits(code);
      00A29D 90 0C AC         [24]  790 	mov	dptr,#_unregister_code16_code_10000_617
      00A2A0 12 37 A8         [24]  791 	lcall	_ak820_outline_0005
      00A2A3 C0 07            [24]  792 	push	ar7
      00A2A5 C0 06            [24]  793 	push	ar6
      00A2A7 51 25            [12]  794 	acall	_extract_mod_bits
      00A2A9 AD 82            [24]  795 	mov	r5, dpl
      00A2AB D0 06            [24]  796 	pop	ar6
                                    797 ;	quantum/quantum.c:172: unregister_code(code);
      00A2AD 8E 04            [24]  798 	mov	ar4,r6
      00A2AF 8C 82            [24]  799 	mov	dpl, r4
      00A2B1 C0 06            [24]  800 	push	ar6
      00A2B3 C0 05            [24]  801 	push	ar5
      00A2B5 12 79 F1         [24]  802 	lcall	_unregister_code
      00A2B8 D0 05            [24]  803 	pop	ar5
      00A2BA D0 06            [24]  804 	pop	ar6
      00A2BC D0 07            [24]  805 	pop	ar7
                                    806 ;	quantum/quantum.c:173: if (IS_MODIFIER_KEYCODE(code) || code == KC_NO) {
      00A2BE 12 A0 66         [24]  807 	lcall	_ak820_outline_0120
      00A2C1 40 07            [24]  808 	jc	00105$
      00A2C3 74 E7            [12]  809 	mov	a,#0xe7
      00A2C5 9E               [12]  810 	subb	a,r6
      00A2C6 E4               [12]  811 	clr	a
      00A2C7 9F               [12]  812 	subb	a,r7
      00A2C8 50 08            [24]  813 	jnc	00101$
                                    814 ;	free result
      00A2CA                        815 00105$:
      00A2CA 90 0C AC         [24]  816 	mov	dptr,#_unregister_code16_code_10000_617
      00A2CD 12 48 AC         [24]  817 	lcall	_ak820_outline_0037
      00A2D0 70 05            [24]  818 	jnz	00102$
      00A2D2                        819 00101$:
                                    820 ;	quantum/quantum.c:174: unregister_mods(mods);
      00A2D2 8D 82            [24]  821 	mov	dpl, r5
      00A2D4 02 7A B8         [24]  822 	ljmp	_unregister_mods
      00A2D7                        823 00102$:
                                    824 ;	quantum/quantum.c:176: unregister_weak_mods(mods);
      00A2D7 8D 82            [24]  825 	mov	dpl, r5
                                    826 ;	quantum/quantum.c:187: }
      00A2D9 02 7A E0         [24]  827 	ljmp	_unregister_weak_mods
                                    828 ;------------------------------------------------------------
                                    829 ;Allocation info for local variables in function 'tap_code16_delay'
                                    830 ;------------------------------------------------------------
                                    831 ;delay         Allocated with name '_tap_code16_delay_PARM_2'
                                    832 ;code          Allocated with name '_tap_code16_delay_code_10000_622'
                                    833 ;i             Allocated with name '_tap_code16_delay_i_20000_624'
                                    834 ;i             Allocated with name '_tap_code16_delay_i_50000_627'
                                    835 ;------------------------------------------------------------
                                    836 ;	quantum/quantum.c:194: __attribute__((weak)) void tap_code16_delay(uint16_t code, uint16_t delay) {
                                    837 ;	-----------------------------------------
                                    838 ;	 function shutdown_quantum
                                    839 ;	-----------------------------------------
      00A2DC                        840 _shutdown_quantum:
                                    841 ;	quantum/quantum.c:237: clear_keyboard();
      00A2DC 12 7A F4         [24]  842 	lcall	_clear_keyboard
                                    843 ;	quantum/quantum.c:252: shutdown_user();
      00A2DF B1 6B            [12]  844 	acall	_shutdown_user
                                    845 ;	quantum/quantum.c:253: wait_ms(250);
      00A2E1 7F FA            [12]  846 	mov	r7,#0xfa
      00A2E3                        847 00106$:
      00A2E3 EF               [12]  848 	mov	a,r7
      00A2E4 60 09            [24]  849 	jz	00108$
      00A2E6 90 00 01         [24]  850 	mov	dptr,#0x0001
      00A2E9 12 5D A5         [24]  851 	lcall	_mDelaymS
      00A2EC 1F               [12]  852 	dec	r7
      00A2ED 80 F4            [24]  853 	sjmp	00106$
      00A2EF                        854 00108$:
                                    855 ;	quantum/quantum.c:258: }
      00A2EF 22               [24]  856 	ret
                                    857 ;------------------------------------------------------------
                                    858 ;Allocation info for local variables in function 'reset_keyboard'
                                    859 ;------------------------------------------------------------
                                    860 ;	quantum/quantum.c:260: void reset_keyboard(void) {
                                    861 ;	-----------------------------------------
                                    862 ;	 function reset_keyboard
                                    863 ;	-----------------------------------------
      00A2F0                        864 _reset_keyboard:
                                    865 ;	quantum/quantum.c:261: shutdown_quantum();
      00A2F0 51 DC            [12]  866 	acall	_shutdown_quantum
                                    867 ;	quantum/quantum.c:262: bootloader_jump();
                                    868 ;	quantum/quantum.c:263: }
      00A2F2 02 34 0E         [24]  869 	ljmp	_bootloader_jump
                                    870 ;------------------------------------------------------------
                                    871 ;Allocation info for local variables in function 'soft_reset_keyboard'
                                    872 ;------------------------------------------------------------
                                    873 ;	quantum/quantum.c:265: void soft_reset_keyboard(void) {
                                    874 ;	-----------------------------------------
                                    875 ;	 function soft_reset_keyboard
                                    876 ;	-----------------------------------------
      00A2F5                        877 _soft_reset_keyboard:
                                    878 ;	quantum/quantum.c:266: shutdown_quantum();
      00A2F5 51 DC            [12]  879 	acall	_shutdown_quantum
                                    880 ;	quantum/quantum.c:267: mcu_reset();
                                    881 ;	quantum/quantum.c:268: }
      00A2F7 02 34 01         [24]  882 	ljmp	_mcu_reset
                                    883 ;------------------------------------------------------------
                                    884 ;Allocation info for local variables in function 'get_record_keycode'
                                    885 ;------------------------------------------------------------
                                    886 ;update_layer_cache Allocated with name '_get_record_keycode_PARM_2'
                                    887 ;record_argument Allocated with name '_get_record_keycode_record_argument_10000_655'
                                    888 ;record        Allocated with name '_get_record_keycode_record_10000_656'
                                    889 ;------------------------------------------------------------
                                    890 ;	quantum/quantum.c:271: uint16_t get_record_keycode(keyrecord_t AK820_RECORD_MEM *record_argument, bool update_layer_cache) {
                                    891 ;	-----------------------------------------
                                    892 ;	 function get_record_keycode
                                    893 ;	-----------------------------------------
      00A2FA                        894 _get_record_keycode:
      00A2FA 12 38 4C         [24]  895 	lcall	_ak820_outline_0106
      00A2FD 90 0C AF         [24]  896 	mov	dptr,#_get_record_keycode_record_argument_10000_655
      00A300 12 38 47         [24]  897 	lcall	_ak820_outline_0105
                                    898 ;	quantum/quantum.c:273: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A303 90 0C AF         [24]  899 	mov	dptr,#_get_record_keycode_record_argument_10000_655
      00A306 12 37 B2         [24]  900 	lcall	_ak820_outline_0008
                                    901 ;	quantum/quantum.c:278: if (record->keycode) {
      00A309 FC               [12]  902 	mov	r4,a
      00A30A A3               [24]  903 	inc	dptr
      00A30B E0               [24]  904 	movx	a,@dptr
      00A30C FD               [12]  905 	mov	r5,a
      00A30D 4C               [12]  906 	orl	a,r4
      00A30E 60 04            [24]  907 	jz	00102$
                                    908 ;	quantum/quantum.c:279: return record->keycode;
      00A310 12 38 51         [24]  909 	lcall	_ak820_outline_0123
      00A313 22               [24]  910 	ret
      00A314                        911 00102$:
                                    912 ;	quantum/quantum.c:283: return ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed && update_layer_cache);
      00A314 12 7B 36         [24]  913 	lcall	_ak820_outline_0021
      00A317 7A 00            [12]  914 	mov	r2,#0x00
      00A319 12 43 32         [24]  915 	lcall	_ak820_outline_0142
      00A31C 12 37 9B         [24]  916 	lcall	_ak820_outline_0001
      00A31F 60 06            [24]  917 	jz	00105$
      00A321 90 0C AE         [24]  918 	mov	dptr,#_get_record_keycode_PARM_2
      00A324 E0               [24]  919 	movx	a,@dptr
      00A325 70 04            [24]  920 	jnz	00106$
      00A327                        921 00105$:
                                    922 ;	assignBit
      00A327 C2 26            [12]  923 	clr	_get_record_keycode_sloc0_1_0
      00A329 80 02            [24]  924 	sjmp	00107$
      00A32B                        925 00106$:
                                    926 ;	assignBit
      00A32B D2 26            [12]  927 	setb	_get_record_keycode_sloc0_1_0
      00A32D                        928 00107$:
      00A32D 90 0A 2C         [24]  929 	mov	dptr,#_ak820_resolve_key_PARM_2
      00A330 A2 26            [12]  930 	mov	c,_get_record_keycode_sloc0_1_0
      00A332 E4               [12]  931 	clr	a
      00A333 33               [12]  932 	rlc	a
      00A334 F0               [24]  933 	movx	@dptr,a
      00A335 8D 82            [24]  934 	mov	dpl, r5
      00A337 8C 83            [24]  935 	mov	dph, r4
                                    936 ;	quantum/quantum.c:287: }
      00A339 02 7E B9         [24]  937 	ljmp	_ak820_resolve_key
                                    938 ;------------------------------------------------------------
                                    939 ;Allocation info for local variables in function 'get_event_keycode'
                                    940 ;------------------------------------------------------------
                                    941 ;event         Allocated with name '_get_event_keycode_PARM_1'
                                    942 ;update_layer_cache Allocated with name '_get_event_keycode_update_layer_cache_10000_659'
                                    943 ;------------------------------------------------------------
                                    944 ;	quantum/quantum.c:295: uint16_t get_event_keycode(keyevent_t event, bool update_layer_cache) {
                                    945 ;	-----------------------------------------
                                    946 ;	 function pre_process_record_quantum
                                    947 ;	-----------------------------------------
      00A33C                        948 _pre_process_record_quantum:
      00A33C 12 38 4C         [24]  949 	lcall	_ak820_outline_0106
      00A33F 90 0C B1         [24]  950 	mov	dptr,#_pre_process_record_quantum_record_argument_10000_661
      00A342 12 38 47         [24]  951 	lcall	_ak820_outline_0105
                                    952 ;	quantum/quantum.c:328: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A345 90 0C B1         [24]  953 	mov	dptr,#_pre_process_record_quantum_record_argument_10000_661
      00A348 12 37 F7         [24]  954 	lcall	_ak820_outline_0056
                                    955 ;	quantum/quantum.c:332: uint16_t keycode = get_record_keycode(record, true);
      00A34B 90 0C AE         [24]  956 	mov	dptr,#_get_record_keycode_PARM_2
      00A34E 12 4D A6         [24]  957 	lcall	_ak820_outline_0060
      00A351 C0 07            [24]  958 	push	ar7
      00A353 C0 06            [24]  959 	push	ar6
      00A355 51 FA            [12]  960 	acall	_get_record_keycode
      00A357 12 43 3D         [24]  961 	lcall	_ak820_outline_0151
      00A35A D0 06            [24]  962 	pop	ar6
      00A35C D0 07            [24]  963 	pop	ar7
                                    964 ;	quantum/quantum.c:334: record->keycode = keycode;
      00A35E 74 07            [12]  965 	mov	a,#0x07
      00A360 12 37 EF         [24]  966 	lcall	_ak820_outline_0035
      00A363 EC               [12]  967 	mov	a,r4
      00A364 F0               [24]  968 	movx	@dptr,a
      00A365 ED               [12]  969 	mov	a,r5
      00A366 A3               [24]  970 	inc	dptr
      00A367 12 42 F8         [24]  971 	lcall	_ak820_outline_0066
                                    972 ;	quantum/quantum.c:351: if (!ak820_tap_dance_process((keyrecord_t AK820_STATE_MEM *)record)) return false;
      00A36A C0 07            [24]  973 	push	ar7
      00A36C C0 06            [24]  974 	push	ar6
      00A36E 12 46 B7         [24]  975 	lcall	_ak820_tap_dance_process
      00A371 E5 82            [12]  976 	mov	a, dpl
      00A373 D0 06            [24]  977 	pop	ar6
      00A375 D0 07            [24]  978 	pop	ar7
      00A377 70 03            [24]  979 	jnz	00102$
      00A379 F5 82            [12]  980 	mov	dpl,a
      00A37B 22               [24]  981 	ret
      00A37C                        982 00102$:
                                    983 ;	quantum/quantum.c:361: ak820_combo_process((keyrecord_t AK820_STATE_MEM *)record) &&
      00A37C 12 43 23         [24]  984 	lcall	_ak820_outline_0119
      00A37F 12 35 EC         [24]  985 	lcall	_ak820_combo_process
      00A382 E5 82            [12]  986 	mov	a, dpl
      00A384 70 04            [24]  987 	jnz	00106$
                                    988 ;	quantum/quantum.c:366: true;
                                    989 ;	assignBit
      00A386 C2 27            [12]  990 	clr	_pre_process_record_quantum_sloc0_1_0
      00A388 80 02            [24]  991 	sjmp	00107$
      00A38A                        992 00106$:
                                    993 ;	assignBit
      00A38A D2 27            [12]  994 	setb	_pre_process_record_quantum_sloc0_1_0
      00A38C                        995 00107$:
      00A38C A2 27            [12]  996 	mov	c,_pre_process_record_quantum_sloc0_1_0
      00A38E 12 38 66         [24]  997 	lcall	_ak820_outline_0149
                                    998 ;	quantum/quantum.c:367: }
      00A391 22               [24]  999 	ret
                                   1000 ;------------------------------------------------------------
                                   1001 ;Allocation info for local variables in function 'post_process_record_quantum'
                                   1002 ;------------------------------------------------------------
                                   1003 ;record        Allocated with name '_post_process_record_quantum_record_10000_664'
                                   1004 ;keycode       Allocated with name '_post_process_record_quantum_keycode_10000_665'
                                   1005 ;------------------------------------------------------------
                                   1006 ;	quantum/quantum.c:370: void post_process_record_quantum(keyrecord_t AK820_RECORD_MEM *record) {
                                   1007 ;	-----------------------------------------
                                   1008 ;	 function process_record_quantum
                                   1009 ;	-----------------------------------------
      00A392                       1010 _process_record_quantum:
      00A392 12 38 4C         [24] 1011 	lcall	_ak820_outline_0106
      00A395 90 0C B3         [24] 1012 	mov	dptr,#_process_record_quantum_record_10000_666
      00A398 12 38 47         [24] 1013 	lcall	_ak820_outline_0105
                                   1014 ;	quantum/quantum.c:377: uint16_t keycode = get_record_keycode(record, false);
      00A39B 90 0C B3         [24] 1015 	mov	dptr,#_process_record_quantum_record_10000_666
      00A39E 12 37 F7         [24] 1016 	lcall	_ak820_outline_0056
      00A3A1 90 0C AE         [24] 1017 	mov	dptr,#_get_record_keycode_PARM_2
      00A3A4 E4               [12] 1018 	clr	a
      00A3A5 12 42 F8         [24] 1019 	lcall	_ak820_outline_0066
      00A3A8 51 FA            [12] 1020 	acall	_get_record_keycode
      00A3AA 12 43 2D         [24] 1021 	lcall	_ak820_outline_0136
                                   1022 ;	quantum/quantum.c:381: return process_record_quantum_helper(keycode, record);
      00A3AD 90 0C B3         [24] 1023 	mov	dptr,#_process_record_quantum_record_10000_666
      00A3B0 12 38 16         [24] 1024 	lcall	_ak820_outline_0065
      00A3B3 90 0C BA         [24] 1025 	mov	dptr,#_process_record_quantum_helper_PARM_2
      00A3B6 EC               [12] 1026 	mov	a,r4
      00A3B7 F0               [24] 1027 	movx	@dptr,a
      00A3B8 ED               [12] 1028 	mov	a,r5
      00A3B9 A3               [24] 1029 	inc	dptr
      00A3BA 12 42 F8         [24] 1030 	lcall	_ak820_outline_0066
                                   1031 ;	quantum/quantum.c:382: }
      00A3BD 81 2A            [24] 1032 	ajmp	_process_record_quantum_helper
                                   1033 ;------------------------------------------------------------
                                   1034 ;Allocation info for local variables in function 'process_ak820_nkro'
                                   1035 ;------------------------------------------------------------
                                   1036 ;record_argument Allocated with name '_process_ak820_nkro_PARM_2'
                                   1037 ;keycode       Allocated with name '_process_ak820_nkro_keycode_10000_668'
                                   1038 ;record        Allocated with name '_process_ak820_nkro_record_10000_669'
                                   1039 ;------------------------------------------------------------
                                   1040 ;	quantum/quantum.c:399: static bool process_ak820_nkro(uint16_t keycode, keyrecord_t *record_argument) {
                                   1041 ;	-----------------------------------------
                                   1042 ;	 function process_ak820_nkro
                                   1043 ;	-----------------------------------------
      00A3BF                       1044 _process_ak820_nkro:
      00A3BF 12 38 4C         [24] 1045 	lcall	_ak820_outline_0106
      00A3C2 90 0C B8         [24] 1046 	mov	dptr,#_process_ak820_nkro_keycode_10000_668
      00A3C5 12 38 47         [24] 1047 	lcall	_ak820_outline_0105
                                   1048 ;	quantum/quantum.c:401: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A3C8 90 0C B5         [24] 1049 	mov	dptr,#_process_ak820_nkro_PARM_2
      00A3CB 12 37 F7         [24] 1050 	lcall	_ak820_outline_0056
                                   1051 ;	quantum/quantum.c:405: if (keycode < QK_MAGIC_NKRO_ON || keycode > QK_MAGIC_TOGGLE_NKRO) return true;
      00A3CE 90 0C B8         [24] 1052 	mov	dptr,#_process_ak820_nkro_keycode_10000_668
      00A3D1 12 38 16         [24] 1053 	lcall	_ak820_outline_0065
      00A3D4 C3               [12] 1054 	clr	c
      00A3D5 EC               [12] 1055 	mov	a,r4
      00A3D6 94 11            [12] 1056 	subb	a,#0x11
      00A3D8 ED               [12] 1057 	mov	a,r5
      00A3D9 94 70            [12] 1058 	subb	a,#0x70
      00A3DB 40 08            [24] 1059 	jc	00101$
      00A3DD 74 13            [12] 1060 	mov	a,#0x13
      00A3DF 9C               [12] 1061 	subb	a,r4
      00A3E0 74 70            [12] 1062 	mov	a,#0x70
      00A3E2 9D               [12] 1063 	subb	a,r5
      00A3E3 50 04            [24] 1064 	jnc	00102$
                                   1065 ;	free result
      00A3E5                       1066 00101$:
      00A3E5 75 82 01         [24] 1067 	mov	dpl, #0x01
      00A3E8 22               [24] 1068 	ret
      00A3E9                       1069 00102$:
                                   1070 ;	quantum/quantum.c:406: if (record->event.pressed) {
      00A3E9 12 37 9B         [24] 1071 	lcall	_ak820_outline_0001
      00A3EC 60 38            [24] 1072 	jz	00105$
                                   1073 ;	quantum/quantum.c:407: clear_keyboard();
      00A3EE C0 05            [24] 1074 	push	ar5
      00A3F0 C0 04            [24] 1075 	push	ar4
      00A3F2 12 7A F4         [24] 1076 	lcall	_clear_keyboard
      00A3F5 D0 04            [24] 1077 	pop	ar4
      00A3F7 D0 05            [24] 1078 	pop	ar5
                                   1079 ;	quantum/quantum.c:408: keymap_config.nkro = keycode == QK_MAGIC_TOGGLE_NKRO ? !keymap_config.nkro : keycode == QK_MAGIC_NKRO_ON;
      00A3F9 BC 13 14         [24] 1080 	cjne	r4,#0x13,00108$
      00A3FC BD 70 11         [24] 1081 	cjne	r5,#0x70,00108$
      00A3FF 90 0B 7E         [24] 1082 	mov	dptr,#_keymap_config
      00A402 E0               [24] 1083 	movx	a,@dptr
      00A403 23               [12] 1084 	rl	a
      00A404 54 01            [12] 1085 	anl	a,#0x01
      00A406 B4 01 00         [24] 1086 	cjne	a,#0x01,00136$
      00A409                       1087 00136$:
      00A409 92 28            [24] 1088 	mov  _process_ak820_nkro_sloc0_1_0,c
      00A40B E4               [12] 1089 	clr	a
      00A40C 33               [12] 1090 	rlc	a
      00A40D FF               [12] 1091 	mov	r7,a
      00A40E 80 09            [24] 1092 	sjmp	00109$
      00A410                       1093 00108$:
      00A410 E4               [12] 1094 	clr	a
      00A411 BC 11 04         [24] 1095 	cjne	r4,#0x11,00137$
      00A414 BD 70 01         [24] 1096 	cjne	r5,#0x70,00137$
      00A417 04               [12] 1097 	inc	a
      00A418                       1098 00137$:
      00A418 FF               [12] 1099 	mov	r7,a
      00A419                       1100 00109$:
                                   1101 ;	assignBit
      00A419 EF               [12] 1102 	mov	a,r7
      00A41A 24 FF            [12] 1103 	add	a,#0xff
      00A41C E4               [12] 1104 	clr	a
      00A41D 33               [12] 1105 	rlc	a
      00A41E 90 0B 7E         [24] 1106 	mov	dptr,#_keymap_config
      00A421 13               [12] 1107 	rrc	a
      00A422 E0               [24] 1108 	movx	a,@dptr
      00A423 92 E7            [24] 1109 	mov	acc.7,c
      00A425 F0               [24] 1110 	movx	@dptr,a
      00A426                       1111 00105$:
                                   1112 ;	quantum/quantum.c:410: return false;
      00A426 75 82 00         [24] 1113 	mov	dpl, #0x00
                                   1114 ;	quantum/quantum.c:411: }
      00A429 22               [24] 1115 	ret
                                   1116 ;------------------------------------------------------------
                                   1117 ;Allocation info for local variables in function 'process_record_quantum_helper'
                                   1118 ;------------------------------------------------------------
                                   1119 ;record_argument Allocated with name '_process_record_quantum_helper_PARM_2'
                                   1120 ;keycode       Allocated with name '_process_record_quantum_helper_keycode_10000_673'
                                   1121 ;record        Allocated with name '_process_record_quantum_helper_record_10000_674'
                                   1122 ;------------------------------------------------------------
                                   1123 ;	quantum/quantum.c:414: bool process_record_quantum_helper(uint16_t keycode, keyrecord_t AK820_RECORD_MEM *record_argument) {
                                   1124 ;	-----------------------------------------
                                   1125 ;	 function process_record_quantum_helper
                                   1126 ;	-----------------------------------------
      00A42A                       1127 _process_record_quantum_helper:
      00A42A 12 38 4C         [24] 1128 	lcall	_ak820_outline_0106
      00A42D 90 0C BC         [24] 1129 	mov	dptr,#_process_record_quantum_helper_keycode_10000_673
      00A430 12 38 47         [24] 1130 	lcall	_ak820_outline_0105
                                   1131 ;	quantum/quantum.c:416: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A433 90 0C BA         [24] 1132 	mov	dptr,#_process_record_quantum_helper_PARM_2
      00A436 12 37 F7         [24] 1133 	lcall	_ak820_outline_0056
                                   1134 ;	quantum/quantum.c:459: process_ak820_nkro(keycode, record) &&
      00A439 90 0C BC         [24] 1135 	mov	dptr,#_process_record_quantum_helper_keycode_10000_673
      00A43C 12 38 16         [24] 1136 	lcall	_ak820_outline_0065
      00A43F 90 0C B5         [24] 1137 	mov	dptr,#_process_ak820_nkro_PARM_2
      00A442 12 A5 6C         [24] 1138 	lcall	_ak820_outline_0006
      00A445 C0 07            [24] 1139 	push	ar7
      00A447 C0 06            [24] 1140 	push	ar6
      00A449 C0 05            [24] 1141 	push	ar5
      00A44B C0 04            [24] 1142 	push	ar4
      00A44D 71 BF            [24] 1143 	acall	_process_ak820_nkro
      00A44F E5 82            [12] 1144 	mov	a, dpl
      00A451 D0 04            [24] 1145 	pop	ar4
      00A453 D0 05            [24] 1146 	pop	ar5
      00A455 D0 06            [24] 1147 	pop	ar6
      00A457 D0 07            [24] 1148 	pop	ar7
      00A459 70 02            [24] 1149 	jnz	00196$
      00A45B A1 31            [12] 1150 	ajmp	00101$
      00A45D                       1151 00196$:
                                   1152 ;	quantum/quantum.c:470: process_last_key(keycode, record) && process_repeat_key(keycode, record) &&
      00A45D 90 0C 93         [24] 1153 	mov	dptr,#_process_last_key_PARM_2
      00A460 12 48 CB         [24] 1154 	lcall	_ak820_outline_0064
      00A463 12 38 51         [24] 1155 	lcall	_ak820_outline_0123
      00A466 C0 07            [24] 1156 	push	ar7
      00A468 C0 06            [24] 1157 	push	ar6
      00A46A C0 05            [24] 1158 	push	ar5
      00A46C C0 04            [24] 1159 	push	ar4
      00A46E 12 9F A9         [24] 1160 	lcall	_process_last_key
      00A471 E5 82            [12] 1161 	mov	a, dpl
      00A473 D0 04            [24] 1162 	pop	ar4
      00A475 D0 05            [24] 1163 	pop	ar5
      00A477 D0 06            [24] 1164 	pop	ar6
      00A479 D0 07            [24] 1165 	pop	ar7
      00A47B 70 02            [24] 1166 	jnz	00197$
      00A47D A1 31            [12] 1167 	ajmp	00101$
      00A47F                       1168 00197$:
      00A47F 90 0C 98         [24] 1169 	mov	dptr,#_process_repeat_key_PARM_2
      00A482 12 48 CB         [24] 1170 	lcall	_ak820_outline_0064
      00A485 12 38 51         [24] 1171 	lcall	_ak820_outline_0123
      00A488 C0 07            [24] 1172 	push	ar7
      00A48A C0 06            [24] 1173 	push	ar6
      00A48C C0 05            [24] 1174 	push	ar5
      00A48E C0 04            [24] 1175 	push	ar4
      00A490 11 21            [12] 1176 	acall	_process_repeat_key
      00A492 E5 82            [12] 1177 	mov	a, dpl
      00A494 D0 04            [24] 1178 	pop	ar4
      00A496 D0 05            [24] 1179 	pop	ar5
      00A498 D0 06            [24] 1180 	pop	ar6
      00A49A D0 07            [24] 1181 	pop	ar7
      00A49C 70 02            [24] 1182 	jnz	00198$
      00A49E A1 31            [12] 1183 	ajmp	00101$
      00A4A0                       1184 00198$:
                                   1185 ;	quantum/quantum.c:479: process_record_via(keycode, record) &&
      00A4A0 90 0C F5         [24] 1186 	mov	dptr,#_process_record_via_PARM_2
      00A4A3 12 A5 6C         [24] 1187 	lcall	_ak820_outline_0006
      00A4A6 C0 07            [24] 1188 	push	ar7
      00A4A8 C0 06            [24] 1189 	push	ar6
      00A4AA C0 05            [24] 1190 	push	ar5
      00A4AC C0 04            [24] 1191 	push	ar4
      00A4AE 12 AA 50         [24] 1192 	lcall	_process_record_via
      00A4B1 E5 82            [12] 1193 	mov	a, dpl
      00A4B3 D0 04            [24] 1194 	pop	ar4
      00A4B5 D0 05            [24] 1195 	pop	ar5
      00A4B7 D0 06            [24] 1196 	pop	ar6
      00A4B9 D0 07            [24] 1197 	pop	ar7
      00A4BB 70 02            [24] 1198 	jnz	00199$
      00A4BD A1 31            [12] 1199 	ajmp	00101$
      00A4BF                       1200 00199$:
                                   1201 ;	quantum/quantum.c:514: process_caps_word(keycode, record) &&
      00A4BF 90 0C 7C         [24] 1202 	mov	dptr,#_process_caps_word_PARM_2
      00A4C2 12 A5 6C         [24] 1203 	lcall	_ak820_outline_0006
      00A4C5 C0 07            [24] 1204 	push	ar7
      00A4C7 C0 06            [24] 1205 	push	ar6
      00A4C9 C0 05            [24] 1206 	push	ar5
      00A4CB C0 04            [24] 1207 	push	ar4
      00A4CD 12 9D 49         [24] 1208 	lcall	_process_caps_word
      00A4D0 E5 82            [12] 1209 	mov	a, dpl
      00A4D2 D0 04            [24] 1210 	pop	ar4
      00A4D4 D0 05            [24] 1211 	pop	ar5
      00A4D6 D0 06            [24] 1212 	pop	ar6
      00A4D8 D0 07            [24] 1213 	pop	ar7
      00A4DA 60 55            [24] 1214 	jz	00101$
                                   1215 ;	quantum/quantum.c:544: process_grave_esc(keycode, record) &&
      00A4DC 90 0C 81         [24] 1216 	mov	dptr,#_process_grave_esc_PARM_2
      00A4DF 12 A5 6C         [24] 1217 	lcall	_ak820_outline_0006
      00A4E2 C0 07            [24] 1218 	push	ar7
      00A4E4 C0 06            [24] 1219 	push	ar6
      00A4E6 C0 05            [24] 1220 	push	ar5
      00A4E8 C0 04            [24] 1221 	push	ar4
      00A4EA 12 9E 5C         [24] 1222 	lcall	_process_grave_esc
      00A4ED E5 82            [12] 1223 	mov	a, dpl
      00A4EF D0 04            [24] 1224 	pop	ar4
      00A4F1 D0 05            [24] 1225 	pop	ar5
      00A4F3 D0 06            [24] 1226 	pop	ar6
      00A4F5 D0 07            [24] 1227 	pop	ar7
      00A4F7 60 38            [24] 1228 	jz	00101$
                                   1229 ;	quantum/quantum.c:547: process_rgb(keycode, record) &&
      00A4F9 90 0C 9C         [24] 1230 	mov	dptr,#_process_rgb_PARM_2
      00A4FC 12 A5 6C         [24] 1231 	lcall	_ak820_outline_0006
      00A4FF C0 07            [24] 1232 	push	ar7
      00A501 C0 06            [24] 1233 	push	ar6
      00A503 C0 05            [24] 1234 	push	ar5
      00A505 C0 04            [24] 1235 	push	ar4
      00A507 11 6E            [12] 1236 	acall	_process_rgb
      00A509 E5 82            [12] 1237 	mov	a, dpl
      00A50B D0 04            [24] 1238 	pop	ar4
      00A50D D0 05            [24] 1239 	pop	ar5
      00A50F D0 06            [24] 1240 	pop	ar6
      00A511 D0 07            [24] 1241 	pop	ar7
      00A513 60 1C            [24] 1242 	jz	00101$
                                   1243 ;	quantum/quantum.c:559: process_tri_layer(keycode, record) &&
      00A515 90 0C A2         [24] 1244 	mov	dptr,#_process_tri_layer_PARM_2
      00A518 12 A5 6C         [24] 1245 	lcall	_ak820_outline_0006
      00A51B C0 07            [24] 1246 	push	ar7
      00A51D C0 06            [24] 1247 	push	ar6
      00A51F C0 05            [24] 1248 	push	ar5
      00A521 C0 04            [24] 1249 	push	ar4
      00A523 31 1F            [12] 1250 	acall	_process_tri_layer
      00A525 E5 82            [12] 1251 	mov	a, dpl
      00A527 D0 04            [24] 1252 	pop	ar4
      00A529 D0 05            [24] 1253 	pop	ar5
      00A52B D0 06            [24] 1254 	pop	ar6
      00A52D D0 07            [24] 1255 	pop	ar7
      00A52F 70 04            [24] 1256 	jnz	00102$
                                   1257 ;	quantum/quantum.c:561: true)) {
      00A531                       1258 00101$:
                                   1259 ;	quantum/quantum.c:562: return false;
      00A531 75 82 00         [24] 1260 	mov	dpl, #0x00
      00A534 22               [24] 1261 	ret
      00A535                       1262 00102$:
                                   1263 ;	quantum/quantum.c:565: if (record->event.pressed) {
      00A535 12 37 9B         [24] 1264 	lcall	_ak820_outline_0001
      00A538 60 2D            [24] 1265 	jz	00116$
                                   1266 ;	quantum/quantum.c:566: switch (keycode) {
      00A53A BC 00 05         [24] 1267 	cjne	r4,#0x00,00205$
      00A53D BD 7C 02         [24] 1268 	cjne	r5,#0x7c,00205$
      00A540 80 10            [24] 1269 	sjmp	00111$
      00A542                       1270 00205$:
      00A542 BC 01 05         [24] 1271 	cjne	r4,#0x01,00206$
      00A545 BD 7C 02         [24] 1272 	cjne	r5,#0x7c,00206$
      00A548 80 0E            [24] 1273 	sjmp	00112$
      00A54A                       1274 00206$:
                                   1275 ;	quantum/quantum.c:568: case QK_BOOTLOADER:
      00A54A BC 03 1A         [24] 1276 	cjne	r4,#0x03,00116$
      00A54D BD 7C 17         [24] 1277 	cjne	r5,#0x7c,00116$
      00A550 80 0C            [24] 1278 	sjmp	00113$
      00A552                       1279 00111$:
                                   1280 ;	quantum/quantum.c:569: reset_keyboard();
      00A552 51 F0            [12] 1281 	acall	_reset_keyboard
                                   1282 ;	quantum/quantum.c:570: return false;
      00A554 75 82 00         [24] 1283 	mov	dpl, #0x00
                                   1284 ;	quantum/quantum.c:571: case QK_REBOOT:
      00A557 22               [24] 1285 	ret
      00A558                       1286 00112$:
                                   1287 ;	quantum/quantum.c:572: soft_reset_keyboard();
      00A558 51 F5            [12] 1288 	acall	_soft_reset_keyboard
                                   1289 ;	quantum/quantum.c:573: return false;
      00A55A 75 82 00         [24] 1290 	mov	dpl, #0x00
                                   1291 ;	quantum/quantum.c:585: case QK_CLEAR_EEPROM:
      00A55D 22               [24] 1292 	ret
      00A55E                       1293 00113$:
                                   1294 ;	quantum/quantum.c:592: eeconfig_disable();
      00A55E 12 94 CD         [24] 1295 	lcall	_eeconfig_disable
                                   1296 ;	quantum/quantum.c:593: soft_reset_keyboard();
      00A561 51 F5            [12] 1297 	acall	_soft_reset_keyboard
                                   1298 ;	quantum/quantum.c:595: return false;
      00A563 75 82 00         [24] 1299 	mov	dpl, #0x00
                                   1300 ;	quantum/quantum.c:650: }
      00A566 22               [24] 1301 	ret
      00A567                       1302 00116$:
                                   1303 ;	quantum/quantum.c:654: return true;
      00A567 75 82 01         [24] 1304 	mov	dpl, #0x01
                                   1305 ;	quantum/quantum.c:658: }
      00A56A 22               [24] 1306 	ret
                                   1307 ;------------------------------------------------------------
                                   1308 ;Allocation info for local variables in function 'set_single_persistent_default_layer'
                                   1309 ;------------------------------------------------------------
                                   1310 ;default_layer Allocated with name '_set_single_persistent_default_layer_default_layer_10000_681'
                                   1311 ;------------------------------------------------------------
                                   1312 ;	quantum/quantum.c:660: void set_single_persistent_default_layer(uint8_t default_layer) {
                                   1313 ;	-----------------------------------------
                                   1314 ;	 function shutdown_user
                                   1315 ;	-----------------------------------------
      00A56B                       1316 _shutdown_user:
      00A56B 22               [24] 1317 	ret
                                   1318 ;------------------------------------------------------------
                                   1319 ;Allocation info for local variables in function 'suspend_power_down_quantum'
                                   1320 ;------------------------------------------------------------
                                   1321 ;	quantum/quantum.c:676: void suspend_power_down_quantum(void) {
                                   1322 ;	-----------------------------------------
                                   1323 	.area CSEG    (CODE)
                                   1324 	.area CONST   (CODE)
                                   1325 	.area XINIT   (CODE)
                                   1326 	.area CABS    (ABS,CODE)
                                   1327 
                                   1328 ; Experimental exact instruction outlining.
                                   1329 	.globl _ak820_outline_0001
                                   1330 	.globl _ak820_outline_0005
                                   1331 	.globl _ak820_outline_0006
                                   1332 	.globl _ak820_outline_0008
                                   1333 	.globl _ak820_outline_0021
                                   1334 	.globl _ak820_outline_0035
                                   1335 	.globl _ak820_outline_0037
                                   1336 	.globl _ak820_outline_0056
                                   1337 	.globl _ak820_outline_0060
                                   1338 	.globl _ak820_outline_0064
                                   1339 	.globl _ak820_outline_0065
                                   1340 	.globl _ak820_outline_0066
                                   1341 	.globl _ak820_outline_0105
                                   1342 	.globl _ak820_outline_0106
                                   1343 	.globl _ak820_outline_0119
                                   1344 	.globl _ak820_outline_0120
                                   1345 	.globl _ak820_outline_0123
                                   1346 	.globl _ak820_outline_0136
                                   1347 	.globl _ak820_outline_0142
                                   1348 	.globl _ak820_outline_0149
                                   1349 	.globl _ak820_outline_0151
                                   1350 
                                   1351 	.area CSEG (CODE)
                                   1352 ; function ak820_outline_0006
      00A56C                       1353 _ak820_outline_0006:
      00A56C EE               [12] 1354 	mov	a,r6
      00A56D F0               [24] 1355 	movx	@dptr,a
      00A56E EF               [12] 1356 	mov	a,r7
      00A56F A3               [24] 1357 	inc	dptr
      00A570 F0               [24] 1358 	movx	@dptr,a
      00A571 E4               [12] 1359 	clr	a
      00A572 A3               [24] 1360 	inc	dptr
      00A573 F0               [24] 1361 	movx	@dptr,a
      00A574 8C 82            [24] 1362 	mov	dpl,r4
      00A576 8D 83            [24] 1363 	mov	dph,r5
      00A578 22               [24] 1364 	ret
