                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_nvm
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _eeprom_driver_erase
                                     12 	.globl _eeprom_read_byte
                                     13 	.globl _eeprom_driver_init
                                     14 	.globl _ak820_macro_init
                                     15 	.globl _ak820_flash_program_page
                                     16 	.globl _ak820_flash_program
                                     17 	.globl _ak820_flash_erase
                                     18 	.globl _ak820_flash_read
                                     19 	.globl _ak820_eeprom_update_block_xdata_PARM_3
                                     20 	.globl _ak820_eeprom_update_block_xdata_PARM_2
                                     21 	.globl _ak820_eeprom_write_block_xdata_PARM_3
                                     22 	.globl _ak820_eeprom_write_block_xdata_PARM_2
                                     23 	.globl _ak820_eeprom_read_block_xdata_PARM_3
                                     24 	.globl _ak820_eeprom_read_block_xdata_PARM_2
                                     25 	.globl _ak820_nvm_diagnostic
                                     26 	.globl _ak820_nvm_ok
                                     27 	.globl _ak820_nvm_schema_fault
                                     28 	.globl _ak820_nvm_flush
                                     29 	.globl _ak820_nvm_begin
                                     30 	.globl _ak820_nvm_end
                                     31 	.globl _ak820_eeprom_read_block_xdata
                                     32 	.globl _ak820_eeprom_write_block_xdata
                                     33 	.globl _ak820_eeprom_update_block_xdata
                                     34 ;--------------------------------------------------------
                                     35 ; special function registers
                                     36 ;--------------------------------------------------------
                                     37 	.area RSEG    (ABS,DATA)
      000000                         38 	.org 0x0000
                                     39 ;--------------------------------------------------------
                                     40 ; special function bits
                                     41 ;--------------------------------------------------------
                                     42 	.area RSEG    (ABS,DATA)
      000000                         43 	.org 0x0000
                                     44 ;--------------------------------------------------------
                                     45 ; overlayable register banks
                                     46 ;--------------------------------------------------------
                                     47 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         48 	.ds 8
                                     49 ;--------------------------------------------------------
                                     50 ; overlayable bit register bank
                                     51 ;--------------------------------------------------------
                                     52 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         53 bits:
      000026                         54 	.ds 1
                           008000    55 	b0 = bits[0]
                           008100    56 	b1 = bits[1]
                           008200    57 	b2 = bits[2]
                           008300    58 	b3 = bits[3]
                           008400    59 	b4 = bits[4]
                           008500    60 	b5 = bits[5]
                           008600    61 	b6 = bits[6]
                           008700    62 	b7 = bits[7]
                                     63 ;--------------------------------------------------------
                                     64 ; internal ram data
                                     65 ;--------------------------------------------------------
                                     66 	.area DSEG    (DATA)
      00000C                         67 _ak820_eeprom_write_block_xdata_sloc0_1_0:
      00000C                         68 	.ds 2
      00000E                         69 _ak820_eeprom_update_block_xdata_sloc0_1_0:
      00000E                         70 	.ds 2
      000010                         71 _ak820_eeprom_update_block_xdata_sloc1_1_0:
      000010                         72 	.ds 2
      000012                         73 _ak820_eeprom_update_block_xdata_sloc2_1_0:
      000012                         74 	.ds 3
                                     75 ;--------------------------------------------------------
                                     76 ; overlayable items in internal ram
                                     77 ;--------------------------------------------------------
                                     78 ;--------------------------------------------------------
                                     79 ; indirectly addressable internal ram data
                                     80 ;--------------------------------------------------------
                                     81 	.area ISEG    (DATA)
                                     82 ;--------------------------------------------------------
                                     83 ; absolute internal ram data
                                     84 ;--------------------------------------------------------
                                     85 	.area IABS    (ABS,DATA)
                                     86 	.area IABS    (ABS,DATA)
                                     87 ;--------------------------------------------------------
                                     88 ; bit data
                                     89 ;--------------------------------------------------------
                                     90 	.area BSEG    (BIT)
      000007                         91 _page_valid:
      000007                         92 	.ds 1
      000008                         93 _page_dirty:
      000008                         94 	.ds 1
      000009                         95 _storage_failed:
      000009                         96 	.ds 1
      00000A                         97 _ak820_nvm_ok_sloc0_1_0:
      00000A                         98 	.ds 1
      00000B                         99 _load_page_sloc0_1_0:
      00000B                        100 	.ds 1
                                    101 ;--------------------------------------------------------
                                    102 ; paged external ram data
                                    103 ;--------------------------------------------------------
                                    104 	.area PSEG    (PAG,XDATA)
                                    105 ;--------------------------------------------------------
                                    106 ; uninitialized external ram data
                                    107 ;--------------------------------------------------------
                                    108 	.area XSEG    (XDATA)
      000519                        109 _page_data:
      000519                        110 	.ds 64
      000559                        111 _cached_page:
      000559                        112 	.ds 1
      00055A                        113 _batch_depth:
      00055A                        114 	.ds 1
      00055B                        115 _first_failure_stage:
      00055B                        116 	.ds 1
      00055C                        117 _nvm_fail_stage_10000_20:
      00055C                        118 	.ds 1
      00055D                        119 _ak820_nvm_diagnostic_out_10000_23:
      00055D                        120 	.ds 2
      00055F                        121 _crc_byte_PARM_2:
      00055F                        122 	.ds 1
      000560                        123 _crc_byte_crc_10000_25:
      000560                        124 	.ds 2
      000562                        125 _page_crc_crc_10000_30:
      000562                        126 	.ds 2
      000564                        127 _write_page_address_10000_32:
      000564                        128 	.ds 2
      000566                        129 _journal_header_valid_header_10000_39:
      000566                        130 	.ds 2
      000568                        131 _recover_journal_header_10000_46:
      000568                        132 	.ds 9
      000571                        133 _ak820_nvm_flush_header_10000_62:
      000571                        134 	.ds 9
      00057A                        135 _ak820_nvm_flush_stage_10000_62:
      00057A                        136 	.ds 1
      00057B                        137 _load_page_page_10000_87:
      00057B                        138 	.ds 1
      00057C                        139 _read_offset_offset_10000_93:
      00057C                        140 	.ds 2
      00057E                        141 _eeprom_read_byte_addr_10000_97:
      00057E                        142 	.ds 3
      000581                        143 _ak820_eeprom_read_block_xdata_PARM_2:
      000581                        144 	.ds 3
      000584                        145 _ak820_eeprom_read_block_xdata_PARM_3:
      000584                        146 	.ds 2
      000586                        147 _ak820_eeprom_read_block_xdata_buf_10000_113:
      000586                        148 	.ds 2
      000588                        149 _ak820_eeprom_read_block_xdata_out_10000_114:
      000588                        150 	.ds 2
      00058A                        151 _ak820_eeprom_write_block_xdata_PARM_2:
      00058A                        152 	.ds 3
      00058D                        153 _ak820_eeprom_write_block_xdata_PARM_3:
      00058D                        154 	.ds 2
      00058F                        155 _ak820_eeprom_write_block_xdata_buf_10000_118:
      00058F                        156 	.ds 2
      000591                        157 _ak820_eeprom_update_block_xdata_PARM_2:
      000591                        158 	.ds 3
      000594                        159 _ak820_eeprom_update_block_xdata_PARM_3:
      000594                        160 	.ds 2
      000596                        161 _ak820_eeprom_update_block_xdata_buf_10000_127:
      000596                        162 	.ds 2
                                    163 ;--------------------------------------------------------
                                    164 ; absolute external ram data
                                    165 ;--------------------------------------------------------
                                    166 	.area XABS    (ABS,XDATA)
                                    167 ;--------------------------------------------------------
                                    168 ; initialized external ram data
                                    169 ;--------------------------------------------------------
                                    170 	.area XISEG   (XDATA)
                                    171 	.area HOME    (CODE)
                                    172 	.area GSINIT0 (CODE)
                                    173 	.area GSINIT1 (CODE)
                                    174 	.area GSINIT2 (CODE)
                                    175 	.area GSINIT3 (CODE)
                                    176 	.area GSINIT4 (CODE)
                                    177 	.area GSINIT5 (CODE)
                                    178 	.area GSINIT  (CODE)
                                    179 	.area GSFINAL (CODE)
                                    180 	.area CSEG    (CODE)
                                    181 ;--------------------------------------------------------
                                    182 ; global & static initialisations
                                    183 ;--------------------------------------------------------
                                    184 	.area HOME    (CODE)
                                    185 	.area GSINIT  (CODE)
                                    186 	.area GSFINAL (CODE)
                                    187 	.area GSINIT  (CODE)
                                    188 ;--------------------------------------------------------
                                    189 ; Home
                                    190 ;--------------------------------------------------------
                                    191 	.area HOME    (CODE)
                                    192 	.area HOME    (CODE)
                                    193 ;--------------------------------------------------------
                                    194 ; code
                                    195 ;--------------------------------------------------------
                                    196 	.area CSEG    (CODE)
                                    197 ;------------------------------------------------------------
                                    198 ;Allocation info for local variables in function 'nvm_fail'
                                    199 ;------------------------------------------------------------
                                    200 ;stage         Allocated with name '_nvm_fail_stage_10000_20'
                                    201 ;------------------------------------------------------------
                                    202 ;	keyboards/ajazz/ak820/ak820_nvm.c:31: static void nvm_fail(uint8_t stage) {
                                    203 ;	-----------------------------------------
                                    204 ;	 function nvm_fail
                                    205 ;	-----------------------------------------
      003B4C                        206 _nvm_fail:
                           000007   207 	ar7 = 0x07
                           000006   208 	ar6 = 0x06
                           000005   209 	ar5 = 0x05
                           000004   210 	ar4 = 0x04
                           000003   211 	ar3 = 0x03
                           000002   212 	ar2 = 0x02
                           000001   213 	ar1 = 0x01
                           000000   214 	ar0 = 0x00
      003B4C E5 82            [12]  215 	mov	a,dpl
      003B4E 90 05 5C         [24]  216 	mov	dptr,#_nvm_fail_stage_10000_20
      003B51 F0               [24]  217 	movx	@dptr,a
                                    218 ;	keyboards/ajazz/ak820/ak820_nvm.c:32: if (!storage_failed) first_failure_stage = stage;
      003B52 20 09 08         [24]  219 	jb	_storage_failed,00102$
      003B55 90 05 5C         [24]  220 	mov	dptr,#_nvm_fail_stage_10000_20
      003B58 E0               [24]  221 	movx	a,@dptr
      003B59 90 05 5B         [24]  222 	mov	dptr,#_first_failure_stage
      003B5C F0               [24]  223 	movx	@dptr,a
      003B5D                        224 00102$:
                                    225 ;	keyboards/ajazz/ak820/ak820_nvm.c:33: storage_failed = true;
                                    226 ;	assignBit
      003B5D D2 09            [12]  227 	setb	_storage_failed
                                    228 ;	keyboards/ajazz/ak820/ak820_nvm.c:34: }
      003B5F 22               [24]  229 	ret
                                    230 ;------------------------------------------------------------
                                    231 ;Allocation info for local variables in function 'ak820_nvm_diagnostic'
                                    232 ;------------------------------------------------------------
                                    233 ;out           Allocated with name '_ak820_nvm_diagnostic_out_10000_23'
                                    234 ;------------------------------------------------------------
                                    235 ;	keyboards/ajazz/ak820/ak820_nvm.c:36: void ak820_nvm_diagnostic(uint8_t AK820_XDATA *out) {
                                    236 ;	-----------------------------------------
                                    237 ;	 function ak820_nvm_diagnostic
                                    238 ;	-----------------------------------------
      003B60                        239 _ak820_nvm_diagnostic:
      003B60 12 38 55         [24]  240 	lcall	_ak820_outline_0106
      003B63 90 05 5D         [24]  241 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003B66 12 38 50         [24]  242 	lcall	_ak820_outline_0105
                                    243 ;	keyboards/ajazz/ak820/ak820_nvm.c:37: out[0] = storage_failed;
      003B69 90 05 5D         [24]  244 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003B6C 12 38 00         [24]  245 	lcall	_ak820_outline_0056
      003B6F A2 09            [12]  246 	mov	c,_storage_failed
      003B71 E4               [12]  247 	clr	a
      003B72 33               [12]  248 	rlc	a
      003B73 12 43 2C         [24]  249 	lcall	_ak820_outline_0119
      003B76 12 43 01         [24]  250 	lcall	_ak820_outline_0066
                                    251 ;	keyboards/ajazz/ak820/ak820_nvm.c:38: out[1] = page_valid;
      003B79 A3               [24]  252 	inc	dptr
      003B7A A2 07            [12]  253 	mov	c,_page_valid
      003B7C E4               [12]  254 	clr	a
      003B7D 33               [12]  255 	rlc	a
      003B7E 12 42 D5         [24]  256 	lcall	_ak820_outline_0036
                                    257 ;	keyboards/ajazz/ak820/ak820_nvm.c:39: out[2] = page_dirty;
      003B81 A2 08            [12]  258 	mov	c,_page_dirty
      003B83 E4               [12]  259 	clr	a
      003B84 33               [12]  260 	rlc	a
      003B85 F0               [24]  261 	movx	@dptr,a
                                    262 ;	keyboards/ajazz/ak820/ak820_nvm.c:40: out[3] = batch_depth;
      003B86 74 03            [12]  263 	mov	a,#0x03
      003B88 12 43 50         [24]  264 	lcall	_ak820_outline_0163
      003B8B 90 05 5A         [24]  265 	mov	dptr,#_batch_depth
      003B8E E0               [24]  266 	movx	a,@dptr
      003B8F 12 38 5A         [24]  267 	lcall	_ak820_outline_0123
      003B92 F0               [24]  268 	movx	@dptr,a
                                    269 ;	keyboards/ajazz/ak820/ak820_nvm.c:41: out[4] = (uint8_t)cached_page;
      003B93 74 04            [12]  270 	mov	a,#0x04
      003B95 12 43 50         [24]  271 	lcall	_ak820_outline_0163
      003B98 90 05 59         [24]  272 	mov	dptr,#_cached_page
      003B9B E0               [24]  273 	movx	a,@dptr
      003B9C 12 38 5A         [24]  274 	lcall	_ak820_outline_0123
      003B9F F0               [24]  275 	movx	@dptr,a
                                    276 ;	keyboards/ajazz/ak820/ak820_nvm.c:42: out[5] = (uint8_t)(cached_page >> 8);
      003BA0 12 42 CB         [24]  277 	lcall	_ak820_outline_0013
      003BA3 E4               [12]  278 	clr	a
      003BA4 F0               [24]  279 	movx	@dptr,a
                                    280 ;	keyboards/ajazz/ak820/ak820_nvm.c:43: out[6] = first_failure_stage;
      003BA5 74 06            [12]  281 	mov	a,#0x06
      003BA7 2E               [12]  282 	add	a, r6
      003BA8 FE               [12]  283 	mov	r6,a
      003BA9 E4               [12]  284 	clr	a
      003BAA 3F               [12]  285 	addc	a, r7
      003BAB FF               [12]  286 	mov	r7,a
      003BAC 90 05 5B         [24]  287 	mov	dptr,#_first_failure_stage
      003BAF E0               [24]  288 	movx	a,@dptr
      003BB0 12 43 2C         [24]  289 	lcall	_ak820_outline_0119
      003BB3 F0               [24]  290 	movx	@dptr,a
                                    291 ;	keyboards/ajazz/ak820/ak820_nvm.c:44: }
      003BB4 22               [24]  292 	ret
                                    293 ;------------------------------------------------------------
                                    294 ;Allocation info for local variables in function 'crc_byte'
                                    295 ;------------------------------------------------------------
                                    296 ;value         Allocated with name '_crc_byte_PARM_2'
                                    297 ;crc           Allocated with name '_crc_byte_crc_10000_25'
                                    298 ;bit           Allocated with name '_crc_byte_bit_10000_26'
                                    299 ;------------------------------------------------------------
                                    300 ;	keyboards/ajazz/ak820/ak820_nvm.c:46: static uint16_t crc_byte(uint16_t crc, uint8_t value) {
                                    301 ;	-----------------------------------------
                                    302 ;	 function crc_byte
                                    303 ;	-----------------------------------------
      003BB5                        304 _crc_byte:
      003BB5 12 38 55         [24]  305 	lcall	_ak820_outline_0106
      003BB8 90 05 60         [24]  306 	mov	dptr,#_crc_byte_crc_10000_25
      003BBB 12 38 50         [24]  307 	lcall	_ak820_outline_0105
                                    308 ;	keyboards/ajazz/ak820/ak820_nvm.c:48: crc ^= (uint16_t)value << 8;
      003BBE 90 05 5F         [24]  309 	mov	dptr,#_crc_byte_PARM_2
      003BC1 E0               [24]  310 	movx	a,@dptr
      003BC2 FF               [12]  311 	mov	r7,a
      003BC3 7E 00            [12]  312 	mov	r6,#0x00
      003BC5 90 05 60         [24]  313 	mov	dptr,#_crc_byte_crc_10000_25
      003BC8 E0               [24]  314 	movx	a,@dptr
      003BC9 6E               [12]  315 	xrl	a,r6
      003BCA F0               [24]  316 	movx	@dptr,a
      003BCB A3               [24]  317 	inc	dptr
      003BCC E0               [24]  318 	movx	a,@dptr
      003BCD 6F               [12]  319 	xrl	a,r7
      003BCE F0               [24]  320 	movx	@dptr,a
                                    321 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003BCF 7F 00            [12]  322 	mov	r7,#0x00
      003BD1                        323 00102$:
                                    324 ;	keyboards/ajazz/ak820/ak820_nvm.c:50: crc = (crc & 0x8000u) ? (uint16_t)((crc << 1) ^ 0x1021u) : (uint16_t)(crc << 1);
      003BD1 90 05 60         [24]  325 	mov	dptr,#_crc_byte_crc_10000_25
      003BD4 12 43 1A         [24]  326 	lcall	_ak820_outline_0098
      003BD7 30 E7 0E         [24]  327 	jnb	acc.7,00106$
      003BDA ED               [12]  328 	mov	a,r5
      003BDB 2D               [12]  329 	add	a,r5
      003BDC FB               [12]  330 	mov	r3,a
      003BDD EE               [12]  331 	mov	a,r6
      003BDE 33               [12]  332 	rlc	a
      003BDF FC               [12]  333 	mov	r4,a
      003BE0 63 03 21         [24]  334 	xrl	ar3,#0x21
      003BE3 63 04 10         [24]  335 	xrl	ar4,#0x10
      003BE6 80 06            [24]  336 	sjmp	00107$
      003BE8                        337 00106$:
      003BE8 ED               [12]  338 	mov	a,r5
      003BE9 2D               [12]  339 	add	a,r5
      003BEA FB               [12]  340 	mov	r3,a
      003BEB EE               [12]  341 	mov	a,r6
      003BEC 33               [12]  342 	rlc	a
      003BED FC               [12]  343 	mov	r4,a
      003BEE                        344 00107$:
      003BEE 90 05 60         [24]  345 	mov	dptr,#_crc_byte_crc_10000_25
      003BF1 12 38 38         [24]  346 	lcall	_ak820_outline_0081
                                    347 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003BF4 0F               [12]  348 	inc	r7
      003BF5 BF 08 D9         [24]  349 	cjne	r7,#0x08,00102$
                                    350 ;	keyboards/ajazz/ak820/ak820_nvm.c:52: return crc;
      003BF8 12 33 FC         [24]  351 	lcall	_ak820_outline_0124
                                    352 ;	keyboards/ajazz/ak820/ak820_nvm.c:53: }
      003BFB 22               [24]  353 	ret
                                    354 ;------------------------------------------------------------
                                    355 ;Allocation info for local variables in function 'page_crc'
                                    356 ;------------------------------------------------------------
                                    357 ;crc           Allocated with name '_page_crc_crc_10000_30'
                                    358 ;i             Allocated with name '_page_crc_i_10000_30'
                                    359 ;------------------------------------------------------------
                                    360 ;	keyboards/ajazz/ak820/ak820_nvm.c:55: static uint16_t page_crc(void) {
                                    361 ;	-----------------------------------------
                                    362 ;	 function page_crc
                                    363 ;	-----------------------------------------
      003BFC                        364 _page_crc:
                                    365 ;	keyboards/ajazz/ak820/ak820_nvm.c:56: uint16_t crc = 0xFFFFu;
      003BFC 90 05 62         [24]  366 	mov	dptr,#_page_crc_crc_10000_30
      003BFF 74 FF            [12]  367 	mov	a,#0xff
      003C01 F0               [24]  368 	movx	@dptr,a
      003C02 A3               [24]  369 	inc	dptr
      003C03 F0               [24]  370 	movx	@dptr,a
                                    371 ;	keyboards/ajazz/ak820/ak820_nvm.c:58: for (i = 0; i != AK820_FLASH_PAGE; ++i) crc = crc_byte(crc, page_data[i]);
      003C04 7F 00            [12]  372 	mov	r7,#0x00
      003C06                        373 00102$:
      003C06 90 05 62         [24]  374 	mov	dptr,#_page_crc_crc_10000_30
      003C09 12 43 1A         [24]  375 	lcall	_ak820_outline_0098
      003C0C 12 43 20         [24]  376 	lcall	_ak820_outline_0108
      003C0F 90 05 5F         [24]  377 	mov	dptr,#_crc_byte_PARM_2
      003C12 F0               [24]  378 	movx	@dptr,a
      003C13 12 38 6A         [24]  379 	lcall	_ak820_outline_0137
      003C16 C0 07            [24]  380 	push	ar7
      003C18 12 3B B5         [24]  381 	lcall	_crc_byte
      003C1B AD 82            [24]  382 	mov	r5, dpl
      003C1D AE 83            [24]  383 	mov	r6, dph
      003C1F D0 07            [24]  384 	pop	ar7
      003C21 90 05 62         [24]  385 	mov	dptr,#_page_crc_crc_10000_30
      003C24 12 43 56         [24]  386 	lcall	_ak820_outline_0164
      003C27 0F               [12]  387 	inc	r7
      003C28 BF 40 DB         [24]  388 	cjne	r7,#0x40,00102$
                                    389 ;	keyboards/ajazz/ak820/ak820_nvm.c:59: return crc;
      003C2B 12 38 6A         [24]  390 	lcall	_ak820_outline_0137
                                    391 ;	keyboards/ajazz/ak820/ak820_nvm.c:60: }
      003C2E 22               [24]  392 	ret
                                    393 ;------------------------------------------------------------
                                    394 ;Allocation info for local variables in function 'write_page'
                                    395 ;------------------------------------------------------------
                                    396 ;address       Allocated with name '_write_page_address_10000_32'
                                    397 ;i             Allocated with name '_write_page_i_10000_33'
                                    398 ;------------------------------------------------------------
                                    399 ;	keyboards/ajazz/ak820/ak820_nvm.c:62: static bool write_page(uint16_t address) {
                                    400 ;	-----------------------------------------
                                    401 ;	 function write_page
                                    402 ;	-----------------------------------------
      003C2F                        403 _write_page:
      003C2F 12 38 55         [24]  404 	lcall	_ak820_outline_0106
      003C32 90 05 64         [24]  405 	mov	dptr,#_write_page_address_10000_32
      003C35 12 38 50         [24]  406 	lcall	_ak820_outline_0105
                                    407 ;	keyboards/ajazz/ak820/ak820_nvm.c:64: if (!ak820_flash_erase(address)) return false;
      003C38 90 05 64         [24]  408 	mov	dptr,#_write_page_address_10000_32
      003C3B 12 37 B1         [24]  409 	lcall	_ak820_outline_0005
      003C3E C0 07            [24]  410 	push	ar7
      003C40 C0 06            [24]  411 	push	ar6
      003C42 12 39 C5         [24]  412 	lcall	_ak820_flash_erase
      003C45 E5 82            [12]  413 	mov	a, dpl
      003C47 D0 06            [24]  414 	pop	ar6
      003C49 D0 07            [24]  415 	pop	ar7
      003C4B 70 03            [24]  416 	jnz	00102$
      003C4D F5 82            [12]  417 	mov	dpl,a
      003C4F 22               [24]  418 	ret
      003C50                        419 00102$:
                                    420 ;	keyboards/ajazz/ak820/ak820_nvm.c:65: if (!ak820_flash_program_page(address, page_data)) return false;
      003C50 90 04 F5         [24]  421 	mov	dptr,#_ak820_flash_program_page_PARM_2
      003C53 74 19            [12]  422 	mov	a,#_page_data
      003C55 F0               [24]  423 	movx	@dptr,a
      003C56 74 05            [12]  424 	mov	a,#(_page_data >> 8)
      003C58 A3               [24]  425 	inc	dptr
      003C59 12 43 01         [24]  426 	lcall	_ak820_outline_0066
      003C5C 12 3A D9         [24]  427 	lcall	_ak820_flash_program_page
      003C5F E5 82            [12]  428 	mov	a, dpl
      003C61 70 03            [24]  429 	jnz	00120$
      003C63 F5 82            [12]  430 	mov	dpl,a
                                    431 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003C65 22               [24]  432 	ret
      003C66                        433 00120$:
      003C66 7F 00            [12]  434 	mov	r7,#0x00
      003C68                        435 00108$:
                                    436 ;	keyboards/ajazz/ak820/ak820_nvm.c:67: if (ak820_flash_read(address + i) != page_data[i]) return false;
      003C68 8F 05            [24]  437 	mov	ar5,r7
      003C6A 7E 00            [12]  438 	mov	r6,#0x00
      003C6C 90 05 64         [24]  439 	mov	dptr,#_write_page_address_10000_32
      003C6F 12 38 4A         [24]  440 	lcall	_ak820_outline_0103
      003C72 ED               [12]  441 	mov	a,r5
      003C73 2B               [12]  442 	add	a, r3
      003C74 FB               [12]  443 	mov	r3,a
      003C75 EE               [12]  444 	mov	a,r6
      003C76 3C               [12]  445 	addc	a, r4
      003C77 FC               [12]  446 	mov	r4,a
      003C78 12 33 FC         [24]  447 	lcall	_ak820_outline_0124
      003C7B 12 38 B8         [24]  448 	lcall	_ak820_flash_read
      003C7E AE 82            [24]  449 	mov	r6, dpl
      003C80 12 43 20         [24]  450 	lcall	_ak820_outline_0108
      003C83 FD               [12]  451 	mov	r5,a
      003C84 EE               [12]  452 	mov	a,r6
      003C85 B5 05 02         [24]  453 	cjne	a,ar5,00149$
      003C88 80 04            [24]  454 	sjmp	00109$
      003C8A                        455 00149$:
      003C8A 75 82 00         [24]  456 	mov	dpl, #0x00
      003C8D 22               [24]  457 	ret
      003C8E                        458 00109$:
                                    459 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003C8E 0F               [12]  460 	inc	r7
      003C8F BF 40 D6         [24]  461 	cjne	r7,#0x40,00108$
                                    462 ;	keyboards/ajazz/ak820/ak820_nvm.c:69: return true;
      003C92 75 82 01         [24]  463 	mov	dpl, #0x01
                                    464 ;	keyboards/ajazz/ak820/ak820_nvm.c:70: }
      003C95 22               [24]  465 	ret
                                    466 ;------------------------------------------------------------
                                    467 ;Allocation info for local variables in function 'journal_header_valid'
                                    468 ;------------------------------------------------------------
                                    469 ;header        Allocated with name '_journal_header_valid_header_10000_39'
                                    470 ;i             Allocated with name '_journal_header_valid_i_10000_40'
                                    471 ;------------------------------------------------------------
                                    472 ;	keyboards/ajazz/ak820/ak820_nvm.c:72: static bool journal_header_valid(uint8_t AK820_XDATA *header) {
                                    473 ;	-----------------------------------------
                                    474 ;	 function journal_header_valid
                                    475 ;	-----------------------------------------
      003C96                        476 _journal_header_valid:
      003C96 12 38 55         [24]  477 	lcall	_ak820_outline_0106
      003C99 90 05 66         [24]  478 	mov	dptr,#_journal_header_valid_header_10000_39
      003C9C 12 38 50         [24]  479 	lcall	_ak820_outline_0105
                                    480 ;	keyboards/ajazz/ak820/ak820_nvm.c:74: if (header[0] != 0xA5u) return false;
      003C9F 90 05 66         [24]  481 	mov	dptr,#_journal_header_valid_header_10000_39
      003CA2 12 37 B1         [24]  482 	lcall	_ak820_outline_0005
      003CA5 E0               [24]  483 	movx	a,@dptr
      003CA6 FD               [12]  484 	mov	r5,a
      003CA7 BD A5 02         [24]  485 	cjne	r5,#0xa5,00138$
      003CAA 80 04            [24]  486 	sjmp	00116$
      003CAC                        487 00138$:
      003CAC 75 82 00         [24]  488 	mov	dpl, #0x00
                                    489 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      003CAF 22               [24]  490 	ret
      003CB0                        491 00116$:
      003CB0 7D 01            [12]  492 	mov	r5,#0x01
      003CB2                        493 00106$:
                                    494 ;	keyboards/ajazz/ak820/ak820_nvm.c:76: if ((uint8_t)(header[i] ^ header[i + 4]) != 0xFFu) return false;
      003CB2 ED               [12]  495 	mov	a,r5
      003CB3 12 37 DF         [24]  496 	lcall	_ak820_outline_0017
      003CB6 FC               [12]  497 	mov	r4,a
      003CB7 8D 02            [24]  498 	mov	ar2,r5
      003CB9 7B 00            [12]  499 	mov	r3,#0x00
      003CBB 74 04            [12]  500 	mov	a,#0x04
      003CBD 2A               [12]  501 	add	a, r2
      003CBE FA               [12]  502 	mov	r2,a
      003CBF E4               [12]  503 	clr	a
      003CC0 3B               [12]  504 	addc	a, r3
      003CC1 FB               [12]  505 	mov	r3,a
      003CC2 EA               [12]  506 	mov	a,r2
      003CC3 2E               [12]  507 	add	a, r6
      003CC4 F5 82            [12]  508 	mov	dpl,a
      003CC6 EB               [12]  509 	mov	a,r3
      003CC7 3F               [12]  510 	addc	a, r7
      003CC8 F5 83            [12]  511 	mov	dph,a
      003CCA E0               [24]  512 	movx	a,@dptr
      003CCB 62 04            [12]  513 	xrl	ar4,a
      003CCD BC FF 02         [24]  514 	cjne	r4,#0xff,00139$
      003CD0 80 04            [24]  515 	sjmp	00107$
      003CD2                        516 00139$:
      003CD2 75 82 00         [24]  517 	mov	dpl, #0x00
      003CD5 22               [24]  518 	ret
      003CD6                        519 00107$:
                                    520 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      003CD6 0D               [12]  521 	inc	r5
      003CD7 BD 05 D8         [24]  522 	cjne	r5,#0x05,00106$
                                    523 ;	keyboards/ajazz/ak820/ak820_nvm.c:78: return true;
      003CDA 75 82 01         [24]  524 	mov	dpl, #0x01
                                    525 ;	keyboards/ajazz/ak820/ak820_nvm.c:79: }
      003CDD 22               [24]  526 	ret
                                    527 ;------------------------------------------------------------
                                    528 ;Allocation info for local variables in function 'recover_journal'
                                    529 ;------------------------------------------------------------
                                    530 ;header        Allocated with name '_recover_journal_header_10000_46'
                                    531 ;i             Allocated with name '_recover_journal_i_10000_46'
                                    532 ;page          Allocated with name '_recover_journal_page_10000_46'
                                    533 ;crc           Allocated with name '_recover_journal_crc_10000_46'
                                    534 ;------------------------------------------------------------
                                    535 ;	keyboards/ajazz/ak820/ak820_nvm.c:81: static void recover_journal(void) {
                                    536 ;	-----------------------------------------
                                    537 ;	 function recover_journal
                                    538 ;	-----------------------------------------
      003CDE                        539 _recover_journal:
                                    540 ;	keyboards/ajazz/ak820/ak820_nvm.c:85: for (i = 0; i != sizeof(header); ++i) header[i] = ak820_flash_read(AK820_JOURNAL_HEADER + i);
      003CDE 7F 00            [12]  541 	mov	r7,#0x00
      003CE0                        542 00115$:
      003CE0 EF               [12]  543 	mov	a,r7
      003CE1 24 68            [12]  544 	add	a, #_recover_journal_header_10000_46
      003CE3 FD               [12]  545 	mov	r5,a
      003CE4 E4               [12]  546 	clr	a
      003CE5 34 05            [12]  547 	addc	a, #(_recover_journal_header_10000_46 >> 8)
      003CE7 FE               [12]  548 	mov	r6,a
      003CE8 8F 04            [24]  549 	mov	ar4,r7
      003CEA 7B 00            [12]  550 	mov	r3,#0x00
      003CEC 74 40            [12]  551 	mov	a,#0x40
      003CEE 2C               [12]  552 	add	a, r4
      003CEF FC               [12]  553 	mov	r4,a
      003CF0 74 EF            [12]  554 	mov	a,#0xef
      003CF2 3B               [12]  555 	addc	a, r3
      003CF3 FB               [12]  556 	mov	r3,a
      003CF4 12 43 5C         [24]  557 	lcall	_ak820_outline_0184
      003CF7 12 38 B8         [24]  558 	lcall	_ak820_flash_read
      003CFA AC 82            [24]  559 	mov	r4, dpl
      003CFC 12 43 07         [24]  560 	lcall	_ak820_outline_0069
      003CFF 0F               [12]  561 	inc	r7
      003D00 BF 09 DD         [24]  562 	cjne	r7,#0x09,00115$
                                    563 ;	keyboards/ajazz/ak820/ak820_nvm.c:88: if (!journal_header_valid(header)) return;
      003D03 90 05 68         [24]  564 	mov	dptr,#_recover_journal_header_10000_46
      003D06 12 3C 96         [24]  565 	lcall	_journal_header_valid
      003D09 E5 82            [12]  566 	mov	a, dpl
      003D0B 70 01            [24]  567 	jnz	00103$
      003D0D 22               [24]  568 	ret
      003D0E                        569 00103$:
                                    570 ;	keyboards/ajazz/ak820/ak820_nvm.c:89: page = (uint16_t)header[1] | ((uint16_t)header[2] << 8);
      003D0E 90 05 69         [24]  571 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0001)
      003D11 E0               [24]  572 	movx	a,@dptr
      003D12 FF               [12]  573 	mov	r7,a
      003D13 7E 00            [12]  574 	mov	r6,#0x00
      003D15 90 05 6A         [24]  575 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0002)
      003D18 E0               [24]  576 	movx	a,@dptr
      003D19 FC               [12]  577 	mov	r4,a
      003D1A E4               [12]  578 	clr	a
      003D1B 42 07            [12]  579 	orl	ar7,a
      003D1D EC               [12]  580 	mov	a,r4
      003D1E 42 06            [12]  581 	orl	ar6,a
                                    582 ;	keyboards/ajazz/ak820/ak820_nvm.c:90: crc = (uint16_t)header[3] | ((uint16_t)header[4] << 8);
      003D20 90 05 6B         [24]  583 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0003)
      003D23 E0               [24]  584 	movx	a,@dptr
      003D24 FD               [12]  585 	mov	r5,a
      003D25 7C 00            [12]  586 	mov	r4,#0x00
      003D27 90 05 6C         [24]  587 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0004)
      003D2A E0               [24]  588 	movx	a,@dptr
      003D2B FA               [12]  589 	mov	r2,a
      003D2C E4               [12]  590 	clr	a
      003D2D 12 43 3B         [24]  591 	lcall	_ak820_outline_0142
                                    592 ;	keyboards/ajazz/ak820/ak820_nvm.c:91: if (page >= AK820_NVM_SIZE / AK820_FLASH_PAGE) {
      003D30 C3               [12]  593 	clr	c
      003D31 EF               [12]  594 	mov	a,r7
      003D32 94 A0            [12]  595 	subb	a,#0xa0
      003D34 EE               [12]  596 	mov	a,r6
      003D35 94 00            [12]  597 	subb	a,#0x00
      003D37 40 06            [24]  598 	jc	00134$
                                    599 ;	keyboards/ajazz/ak820/ak820_nvm.c:92: nvm_fail(AK820_NVM_FAULT_RECOVERY_PAGE);
      003D39 75 82 01         [24]  600 	mov	dpl, #0x01
                                    601 ;	keyboards/ajazz/ak820/ak820_nvm.c:93: return;
      003D3C 02 3B 4C         [24]  602 	ljmp	_nvm_fail
                                    603 ;	keyboards/ajazz/ak820/ak820_nvm.c:95: for (i = 0; i != AK820_FLASH_PAGE; ++i) page_data[i] = ak820_flash_read(AK820_JOURNAL_DATA + i);
      003D3F                        604 00134$:
      003D3F 7B 00            [12]  605 	mov	r3,#0x00
      003D41                        606 00117$:
      003D41 C0 05            [24]  607 	push	ar5
      003D43 C0 04            [24]  608 	push	ar4
      003D45 EB               [12]  609 	mov	a,r3
      003D46 24 19            [12]  610 	add	a, #_page_data
      003D48 F9               [12]  611 	mov	r1,a
      003D49 E4               [12]  612 	clr	a
      003D4A 34 05            [12]  613 	addc	a, #(_page_data >> 8)
      003D4C FA               [12]  614 	mov	r2,a
      003D4D 8B 00            [24]  615 	mov	ar0,r3
      003D4F 7D 00            [12]  616 	mov	r5,#0x00
      003D51 74 EF            [12]  617 	mov	a,#0xef
      003D53 2D               [12]  618 	add	a, r5
      003D54 FD               [12]  619 	mov	r5,a
      003D55 88 82            [24]  620 	mov	dpl, r0
      003D57 8D 83            [24]  621 	mov	dph, r5
      003D59 12 38 B8         [24]  622 	lcall	_ak820_flash_read
      003D5C AD 82            [24]  623 	mov	r5, dpl
      003D5E 12 43 41         [24]  624 	lcall	_ak820_outline_0150
      003D61 ED               [12]  625 	mov	a,r5
      003D62 F0               [24]  626 	movx	@dptr,a
      003D63 0B               [12]  627 	inc	r3
      003D64 BB 40 02         [24]  628 	cjne	r3,#0x40,00190$
      003D67 80 06            [24]  629 	sjmp	00191$
      003D69                        630 00190$:
      003D69 D0 04            [24]  631 	pop	ar4
      003D6B D0 05            [24]  632 	pop	ar5
      003D6D 80 D2            [24]  633 	sjmp	00117$
      003D6F                        634 00191$:
      003D6F D0 04            [24]  635 	pop	ar4
      003D71 D0 05            [24]  636 	pop	ar5
                                    637 ;	keyboards/ajazz/ak820/ak820_nvm.c:96: if (page_crc() != crc) nvm_fail(AK820_NVM_FAULT_RECOVERY_CRC);
      003D73 C0 07            [24]  638 	push	ar7
      003D75 C0 06            [24]  639 	push	ar6
      003D77 C0 05            [24]  640 	push	ar5
      003D79 C0 04            [24]  641 	push	ar4
      003D7B 12 3B FC         [24]  642 	lcall	_page_crc
      003D7E AA 82            [24]  643 	mov	r2, dpl
      003D80 AB 83            [24]  644 	mov	r3, dph
      003D82 D0 04            [24]  645 	pop	ar4
      003D84 D0 05            [24]  646 	pop	ar5
      003D86 D0 06            [24]  647 	pop	ar6
      003D88 D0 07            [24]  648 	pop	ar7
      003D8A EA               [12]  649 	mov	a,r2
      003D8B B5 05 06         [24]  650 	cjne	a,ar5,00192$
      003D8E EB               [12]  651 	mov	a,r3
      003D8F B5 04 02         [24]  652 	cjne	a,ar4,00192$
      003D92 80 06            [24]  653 	sjmp	00113$
      003D94                        654 00192$:
      003D94 75 82 02         [24]  655 	mov	dpl, #0x02
      003D97 02 3B 4C         [24]  656 	ljmp	_nvm_fail
      003D9A                        657 00113$:
                                    658 ;	keyboards/ajazz/ak820/ak820_nvm.c:97: else if (!write_page(AK820_NVM_BASE + page * AK820_FLASH_PAGE)) nvm_fail(AK820_NVM_FAULT_RECOVERY_WRITE);
      003D9A EE               [12]  659 	mov	a,r6
      003D9B 54 03            [12]  660 	anl	a,#0x03
      003D9D A2 E0            [12]  661 	mov	c,acc.0
      003D9F CF               [12]  662 	xch	a,r7
      003DA0 13               [12]  663 	rrc	a
      003DA1 CF               [12]  664 	xch	a,r7
      003DA2 13               [12]  665 	rrc	a
      003DA3 A2 E0            [12]  666 	mov	c,acc.0
      003DA5 CF               [12]  667 	xch	a,r7
      003DA6 13               [12]  668 	rrc	a
      003DA7 CF               [12]  669 	xch	a,r7
      003DA8 13               [12]  670 	rrc	a
      003DA9 CF               [12]  671 	xch	a,r7
      003DAA 24 C7            [12]  672 	add	a,#0xc7
      003DAC FE               [12]  673 	mov	r6,a
      003DAD 12 43 4B         [24]  674 	lcall	_ak820_outline_0159
      003DB0 12 3C 2F         [24]  675 	lcall	_write_page
      003DB3 E5 82            [12]  676 	mov	a, dpl
      003DB5 70 06            [24]  677 	jnz	00110$
      003DB7 75 82 03         [24]  678 	mov	dpl, #0x03
      003DBA 02 3B 4C         [24]  679 	ljmp	_nvm_fail
      003DBD                        680 00110$:
                                    681 ;	keyboards/ajazz/ak820/ak820_nvm.c:98: else if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) nvm_fail(AK820_NVM_FAULT_RECOVERY_CLEANUP);
      003DBD 90 EF 40         [24]  682 	mov	dptr,#0xef40
      003DC0 12 39 C5         [24]  683 	lcall	_ak820_flash_erase
      003DC3 E5 82            [12]  684 	mov	a, dpl
      003DC5 70 06            [24]  685 	jnz	00119$
      003DC7 75 82 04         [24]  686 	mov	dpl, #0x04
                                    687 ;	keyboards/ajazz/ak820/ak820_nvm.c:99: }
      003DCA 02 3B 4C         [24]  688 	ljmp	_nvm_fail
      003DCD                        689 00119$:
      003DCD 22               [24]  690 	ret
                                    691 ;------------------------------------------------------------
                                    692 ;Allocation info for local variables in function 'eeprom_driver_init'
                                    693 ;------------------------------------------------------------
                                    694 ;	keyboards/ajazz/ak820/ak820_nvm.c:101: void eeprom_driver_init(void) {
                                    695 ;	-----------------------------------------
                                    696 ;	 function eeprom_driver_init
                                    697 ;	-----------------------------------------
      003DCE                        698 _eeprom_driver_init:
                                    699 ;	keyboards/ajazz/ak820/ak820_nvm.c:102: storage_failed = false;
                                    700 ;	assignBit
      003DCE C2 09            [12]  701 	clr	_storage_failed
                                    702 ;	keyboards/ajazz/ak820/ak820_nvm.c:103: first_failure_stage = AK820_NVM_FAULT_NONE;
      003DD0 90 05 5B         [24]  703 	mov	dptr,#_first_failure_stage
      003DD3 E4               [12]  704 	clr	a
      003DD4 F0               [24]  705 	movx	@dptr,a
                                    706 ;	keyboards/ajazz/ak820/ak820_nvm.c:104: page_valid = page_dirty = false;
                                    707 ;	assignBit
      003DD5 C2 08            [12]  708 	clr	_page_dirty
                                    709 ;	assignBit
      003DD7 C2 07            [12]  710 	clr	_page_valid
                                    711 ;	keyboards/ajazz/ak820/ak820_nvm.c:105: batch_depth = 0;
      003DD9 90 05 5A         [24]  712 	mov	dptr,#_batch_depth
      003DDC E4               [12]  713 	clr	a
      003DDD F0               [24]  714 	movx	@dptr,a
                                    715 ;	keyboards/ajazz/ak820/ak820_nvm.c:106: recover_journal();
      003DDE 12 3C DE         [24]  716 	lcall	_recover_journal
                                    717 ;	keyboards/ajazz/ak820/ak820_nvm.c:108: ak820_macro_init();
                                    718 ;	keyboards/ajazz/ak820/ak820_nvm.c:110: }
      003DE1 02 2A B7         [24]  719 	ljmp	_ak820_macro_init
                                    720 ;------------------------------------------------------------
                                    721 ;Allocation info for local variables in function 'ak820_nvm_ok'
                                    722 ;------------------------------------------------------------
                                    723 ;	keyboards/ajazz/ak820/ak820_nvm.c:112: bool ak820_nvm_ok(void) { return !storage_failed; }
                                    724 ;	-----------------------------------------
                                    725 ;	 function ak820_nvm_ok
                                    726 ;	-----------------------------------------
      003DE4                        727 _ak820_nvm_ok:
      003DE4 A2 09            [12]  728 	mov	c,_storage_failed
      003DE6 B3               [12]  729 	cpl	c
      003DE7 92 0A            [24]  730 	mov  _ak820_nvm_ok_sloc0_1_0,c
      003DE9 12 38 6F         [24]  731 	lcall	_ak820_outline_0149
      003DEC 22               [24]  732 	ret
                                    733 ;------------------------------------------------------------
                                    734 ;Allocation info for local variables in function 'ak820_nvm_schema_fault'
                                    735 ;------------------------------------------------------------
                                    736 ;	keyboards/ajazz/ak820/ak820_nvm.c:114: void ak820_nvm_schema_fault(void) { nvm_fail(AK820_NVM_FAULT_SCHEMA); }
                                    737 ;	-----------------------------------------
                                    738 ;	 function ak820_nvm_schema_fault
                                    739 ;	-----------------------------------------
      003DED                        740 _ak820_nvm_schema_fault:
      003DED 75 82 10         [24]  741 	mov	dpl, #0x10
      003DF0 02 3B 4C         [24]  742 	ljmp	_nvm_fail
                                    743 ;------------------------------------------------------------
                                    744 ;Allocation info for local variables in function 'ak820_nvm_flush'
                                    745 ;------------------------------------------------------------
                                    746 ;header        Allocated with name '_ak820_nvm_flush_header_10000_62'
                                    747 ;crc           Allocated with name '_ak820_nvm_flush_crc_10000_62'
                                    748 ;i             Allocated with name '_ak820_nvm_flush_i_10000_62'
                                    749 ;stage         Allocated with name '_ak820_nvm_flush_stage_10000_62'
                                    750 ;------------------------------------------------------------
                                    751 ;	keyboards/ajazz/ak820/ak820_nvm.c:116: void ak820_nvm_flush(void) {
                                    752 ;	-----------------------------------------
                                    753 ;	 function ak820_nvm_flush
                                    754 ;	-----------------------------------------
      003DF3                        755 _ak820_nvm_flush:
                                    756 ;	keyboards/ajazz/ak820/ak820_nvm.c:121: if (!page_dirty || storage_failed) return;
      003DF3 30 08 03         [24]  757 	jnb	_page_dirty,00101$
      003DF6 30 09 01         [24]  758 	jnb	_storage_failed,00102$
      003DF9                        759 00101$:
      003DF9 22               [24]  760 	ret
      003DFA                        761 00102$:
                                    762 ;	keyboards/ajazz/ak820/ak820_nvm.c:122: crc = page_crc();
      003DFA 12 3B FC         [24]  763 	lcall	_page_crc
      003DFD 12 43 36         [24]  764 	lcall	_ak820_outline_0136
                                    765 ;	keyboards/ajazz/ak820/ak820_nvm.c:123: header[0] = 0xA5u;
      003E00 90 05 71         [24]  766 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003E03 74 A5            [12]  767 	mov	a,#0xa5
      003E05 F0               [24]  768 	movx	@dptr,a
                                    769 ;	keyboards/ajazz/ak820/ak820_nvm.c:124: header[1] = (uint8_t)cached_page;
      003E06 90 05 59         [24]  770 	mov	dptr,#_cached_page
      003E09 E0               [24]  771 	movx	a,@dptr
      003E0A 90 05 72         [24]  772 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0001)
      003E0D F0               [24]  773 	movx	@dptr,a
                                    774 ;	keyboards/ajazz/ak820/ak820_nvm.c:125: header[2] = (uint8_t)(cached_page >> 8);
      003E0E 90 05 73         [24]  775 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0002)
      003E11 E4               [12]  776 	clr	a
      003E12 F0               [24]  777 	movx	@dptr,a
                                    778 ;	keyboards/ajazz/ak820/ak820_nvm.c:126: header[3] = (uint8_t)crc;
      003E13 8E 05            [24]  779 	mov	ar5,r6
      003E15 90 05 74         [24]  780 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0003)
      003E18 ED               [12]  781 	mov	a,r5
      003E19 F0               [24]  782 	movx	@dptr,a
                                    783 ;	keyboards/ajazz/ak820/ak820_nvm.c:127: header[4] = (uint8_t)(crc >> 8);
      003E1A 8F 06            [24]  784 	mov	ar6,r7
      003E1C 90 05 75         [24]  785 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0004)
      003E1F EE               [12]  786 	mov	a,r6
      003E20 F0               [24]  787 	movx	@dptr,a
                                    788 ;	keyboards/ajazz/ak820/ak820_nvm.c:128: for (i = 1; i != 5; ++i) header[i + 4] = (uint8_t)~header[i];
      003E21 7F 01            [12]  789 	mov	r7,#0x01
      003E23                        790 00128$:
      003E23 8F 06            [24]  791 	mov	ar6,r7
      003E25 EE               [12]  792 	mov	a,r6
      003E26 24 04            [12]  793 	add	a,#0x04
      003E28 FE               [12]  794 	mov	r6,a
      003E29 33               [12]  795 	rlc	a
      003E2A 95 E0            [12]  796 	subb	a,acc
      003E2C FD               [12]  797 	mov	r5,a
      003E2D EE               [12]  798 	mov	a,r6
      003E2E 24 71            [12]  799 	add	a, #_ak820_nvm_flush_header_10000_62
      003E30 FE               [12]  800 	mov	r6,a
      003E31 ED               [12]  801 	mov	a,r5
      003E32 34 05            [12]  802 	addc	a, #(_ak820_nvm_flush_header_10000_62 >> 8)
      003E34 FD               [12]  803 	mov	r5,a
      003E35 12 42 E4         [24]  804 	lcall	_ak820_outline_0045
      003E38 FC               [12]  805 	mov	r4,a
      003E39 63 04 FF         [24]  806 	xrl	ar4,#0xff
      003E3C 8E 82            [24]  807 	mov	dpl,r6
      003E3E 8D 83            [24]  808 	mov	dph,r5
      003E40 EC               [12]  809 	mov	a,r4
      003E41 F0               [24]  810 	movx	@dptr,a
      003E42 0F               [12]  811 	inc	r7
      003E43 BF 05 DD         [24]  812 	cjne	r7,#0x05,00128$
                                    813 ;	keyboards/ajazz/ak820/ak820_nvm.c:131: stage = AK820_NVM_FAULT_HEADER_ERASE;
      003E46 90 05 7A         [24]  814 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003E49 74 05            [12]  815 	mov	a,#0x05
      003E4B F0               [24]  816 	movx	@dptr,a
                                    817 ;	keyboards/ajazz/ak820/ak820_nvm.c:132: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      003E4C 90 EF 40         [24]  818 	mov	dptr,#0xef40
      003E4F 12 39 C5         [24]  819 	lcall	_ak820_flash_erase
      003E52 E5 82            [12]  820 	mov	a, dpl
      003E54 70 03            [24]  821 	jnz	00269$
      003E56 02 3F 3D         [24]  822 	ljmp	00127$
      003E59                        823 00269$:
                                    824 ;	keyboards/ajazz/ak820/ak820_nvm.c:133: stage = AK820_NVM_FAULT_HEADER_ZERO;
      003E59 90 05 7A         [24]  825 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003E5C 74 06            [12]  826 	mov	a,#0x06
      003E5E F0               [24]  827 	movx	@dptr,a
                                    828 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003E5F 7F 00            [12]  829 	mov	r7,#0x00
      003E61                        830 00130$:
                                    831 ;	keyboards/ajazz/ak820/ak820_nvm.c:135: if (ak820_flash_read(AK820_JOURNAL_HEADER + i)) goto failed;
      003E61 12 42 F0         [24]  832 	lcall	_ak820_outline_0057
      003E64 12 38 B8         [24]  833 	lcall	_ak820_flash_read
      003E67 E5 82            [12]  834 	mov	a, dpl
      003E69 60 03            [24]  835 	jz	00270$
      003E6B 02 3F 3D         [24]  836 	ljmp	00127$
      003E6E                        837 00270$:
                                    838 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003E6E 0F               [12]  839 	inc	r7
      003E6F BF 40 EF         [24]  840 	cjne	r7,#0x40,00130$
                                    841 ;	keyboards/ajazz/ak820/ak820_nvm.c:137: stage = AK820_NVM_FAULT_JOURNAL_WRITE;
      003E72 90 05 7A         [24]  842 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003E75 74 07            [12]  843 	mov	a,#0x07
      003E77 F0               [24]  844 	movx	@dptr,a
                                    845 ;	keyboards/ajazz/ak820/ak820_nvm.c:138: if (!write_page(AK820_JOURNAL_DATA)) goto failed;
      003E78 90 EF 00         [24]  846 	mov	dptr,#0xef00
      003E7B 12 3C 2F         [24]  847 	lcall	_write_page
      003E7E E5 82            [12]  848 	mov	a, dpl
      003E80 70 03            [24]  849 	jnz	00273$
      003E82 02 3F 3D         [24]  850 	ljmp	00127$
      003E85                        851 00273$:
                                    852 ;	keyboards/ajazz/ak820/ak820_nvm.c:139: stage = AK820_NVM_FAULT_METADATA_PROGRAM;
      003E85 90 05 7A         [24]  853 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003E88 74 08            [12]  854 	mov	a,#0x08
      003E8A F0               [24]  855 	movx	@dptr,a
                                    856 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      003E8B 7F 01            [12]  857 	mov	r7,#0x01
      003E8D                        858 00132$:
                                    859 ;	keyboards/ajazz/ak820/ak820_nvm.c:141: if (header[i] && !ak820_flash_program(AK820_JOURNAL_HEADER + i, header[i])) goto failed;
      003E8D 12 42 E4         [24]  860 	lcall	_ak820_outline_0045
      003E90 FE               [12]  861 	mov	r6,a
      003E91 60 23            [24]  862 	jz	00133$
      003E93 8F 05            [24]  863 	mov	ar5,r7
      003E95 7C 00            [12]  864 	mov	r4,#0x00
      003E97 74 40            [12]  865 	mov	a,#0x40
      003E99 2D               [12]  866 	add	a, r5
      003E9A FD               [12]  867 	mov	r5,a
      003E9B 74 EF            [12]  868 	mov	a,#0xef
      003E9D 3C               [12]  869 	addc	a, r4
      003E9E FC               [12]  870 	mov	r4,a
      003E9F 90 04 F2         [24]  871 	mov	dptr,#_ak820_flash_program_PARM_2
      003EA2 EE               [12]  872 	mov	a,r6
      003EA3 F0               [24]  873 	movx	@dptr,a
      003EA4 8D 82            [24]  874 	mov	dpl, r5
      003EA6 8C 83            [24]  875 	mov	dph, r4
      003EA8 C0 07            [24]  876 	push	ar7
      003EAA 12 3A 25         [24]  877 	lcall	_ak820_flash_program
      003EAD E5 82            [12]  878 	mov	a, dpl
      003EAF D0 07            [24]  879 	pop	ar7
      003EB1 70 03            [24]  880 	jnz	00275$
      003EB3 02 3F 3D         [24]  881 	ljmp	00127$
      003EB6                        882 00275$:
      003EB6                        883 00133$:
                                    884 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      003EB6 0F               [12]  885 	inc	r7
      003EB7 BF 09 D3         [24]  886 	cjne	r7,#0x09,00132$
                                    887 ;	keyboards/ajazz/ak820/ak820_nvm.c:143: stage = AK820_NVM_FAULT_METADATA_READBACK;
      003EBA 90 05 7A         [24]  888 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003EBD 74 09            [12]  889 	mov	a,#0x09
      003EBF F0               [24]  890 	movx	@dptr,a
                                    891 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      003EC0 7F 01            [12]  892 	mov	r7,#0x01
      003EC2                        893 00134$:
                                    894 ;	keyboards/ajazz/ak820/ak820_nvm.c:145: if (ak820_flash_read(AK820_JOURNAL_HEADER + i) != header[i]) goto failed;
      003EC2 12 42 F0         [24]  895 	lcall	_ak820_outline_0057
      003EC5 12 38 B8         [24]  896 	lcall	_ak820_flash_read
      003EC8 AE 82            [24]  897 	mov	r6, dpl
      003ECA 12 42 E4         [24]  898 	lcall	_ak820_outline_0045
      003ECD FD               [12]  899 	mov	r5,a
      003ECE EE               [12]  900 	mov	a,r6
      003ECF B5 05 6B         [24]  901 	cjne	a,ar5,00127$
                                    902 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      003ED2 0F               [12]  903 	inc	r7
      003ED3 BF 09 EC         [24]  904 	cjne	r7,#0x09,00134$
                                    905 ;	keyboards/ajazz/ak820/ak820_nvm.c:148: stage = AK820_NVM_FAULT_COMMIT_PROGRAM;
      003ED6 90 05 7A         [24]  906 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003ED9 74 0A            [12]  907 	mov	a,#0x0a
      003EDB F0               [24]  908 	movx	@dptr,a
                                    909 ;	keyboards/ajazz/ak820/ak820_nvm.c:149: if (!ak820_flash_program(AK820_JOURNAL_HEADER, header[0])) goto failed;
      003EDC 90 05 71         [24]  910 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003EDF E0               [24]  911 	movx	a,@dptr
      003EE0 90 04 F2         [24]  912 	mov	dptr,#_ak820_flash_program_PARM_2
      003EE3 F0               [24]  913 	movx	@dptr,a
      003EE4 90 EF 40         [24]  914 	mov	dptr,#0xef40
      003EE7 12 3A 25         [24]  915 	lcall	_ak820_flash_program
      003EEA E5 82            [12]  916 	mov	a, dpl
      003EEC 60 4F            [24]  917 	jz	00127$
                                    918 ;	keyboards/ajazz/ak820/ak820_nvm.c:150: stage = AK820_NVM_FAULT_COMMIT_READBACK;
      003EEE 90 05 7A         [24]  919 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003EF1 74 0B            [12]  920 	mov	a,#0x0b
      003EF3 F0               [24]  921 	movx	@dptr,a
                                    922 ;	keyboards/ajazz/ak820/ak820_nvm.c:151: if (ak820_flash_read(AK820_JOURNAL_HEADER) != header[0]) goto failed;
      003EF4 90 EF 40         [24]  923 	mov	dptr,#0xef40
      003EF7 12 38 B8         [24]  924 	lcall	_ak820_flash_read
      003EFA AF 82            [24]  925 	mov	r7, dpl
      003EFC 90 05 71         [24]  926 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003EFF E0               [24]  927 	movx	a,@dptr
      003F00 FE               [12]  928 	mov	r6,a
      003F01 EF               [12]  929 	mov	a,r7
      003F02 B5 06 38         [24]  930 	cjne	a,ar6,00127$
                                    931 ;	keyboards/ajazz/ak820/ak820_nvm.c:152: stage = AK820_NVM_FAULT_TARGET_WRITE;
      003F05 90 05 7A         [24]  932 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F08 74 0C            [12]  933 	mov	a,#0x0c
      003F0A F0               [24]  934 	movx	@dptr,a
                                    935 ;	keyboards/ajazz/ak820/ak820_nvm.c:153: if (!write_page(AK820_NVM_BASE + cached_page * AK820_FLASH_PAGE)) goto failed;
      003F0B 90 05 59         [24]  936 	mov	dptr,#_cached_page
      003F0E E0               [24]  937 	movx	a,@dptr
      003F0F FE               [12]  938 	mov	r6,a
      003F10 E4               [12]  939 	clr	a
      003F11 C3               [12]  940 	clr	c
      003F12 CE               [12]  941 	xch	a,r6
      003F13 13               [12]  942 	rrc	a
      003F14 CE               [12]  943 	xch	a,r6
      003F15 13               [12]  944 	rrc	a
      003F16 A2 E0            [12]  945 	mov	c,acc.0
      003F18 CE               [12]  946 	xch	a,r6
      003F19 13               [12]  947 	rrc	a
      003F1A CE               [12]  948 	xch	a,r6
      003F1B 13               [12]  949 	rrc	a
      003F1C CE               [12]  950 	xch	a,r6
      003F1D 24 C7            [12]  951 	add	a,#0xc7
      003F1F FF               [12]  952 	mov	r7,a
      003F20 12 43 2C         [24]  953 	lcall	_ak820_outline_0119
      003F23 12 3C 2F         [24]  954 	lcall	_write_page
      003F26 E5 82            [12]  955 	mov	a, dpl
      003F28 60 13            [24]  956 	jz	00127$
                                    957 ;	keyboards/ajazz/ak820/ak820_nvm.c:154: stage = AK820_NVM_FAULT_CLEANUP;
      003F2A 90 05 7A         [24]  958 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F2D 74 0D            [12]  959 	mov	a,#0x0d
      003F2F F0               [24]  960 	movx	@dptr,a
                                    961 ;	keyboards/ajazz/ak820/ak820_nvm.c:155: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      003F30 90 EF 40         [24]  962 	mov	dptr,#0xef40
      003F33 12 39 C5         [24]  963 	lcall	_ak820_flash_erase
      003F36 E5 82            [12]  964 	mov	a, dpl
      003F38 60 03            [24]  965 	jz	00127$
                                    966 ;	keyboards/ajazz/ak820/ak820_nvm.c:156: page_dirty = false;
                                    967 ;	assignBit
      003F3A C2 08            [12]  968 	clr	_page_dirty
                                    969 ;	keyboards/ajazz/ak820/ak820_nvm.c:157: return;
                                    970 ;	keyboards/ajazz/ak820/ak820_nvm.c:158: failed:
      003F3C 22               [24]  971 	ret
      003F3D                        972 00127$:
                                    973 ;	keyboards/ajazz/ak820/ak820_nvm.c:159: nvm_fail(stage);
      003F3D 90 05 7A         [24]  974 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F40 E0               [24]  975 	movx	a,@dptr
      003F41 F5 82            [12]  976 	mov	dpl,a
                                    977 ;	keyboards/ajazz/ak820/ak820_nvm.c:160: }
      003F43 02 3B 4C         [24]  978 	ljmp	_nvm_fail
                                    979 ;------------------------------------------------------------
                                    980 ;Allocation info for local variables in function 'ak820_nvm_begin'
                                    981 ;------------------------------------------------------------
                                    982 ;	keyboards/ajazz/ak820/ak820_nvm.c:162: void ak820_nvm_begin(void) {
                                    983 ;	-----------------------------------------
                                    984 ;	 function ak820_nvm_begin
                                    985 ;	-----------------------------------------
      003F46                        986 _ak820_nvm_begin:
                                    987 ;	keyboards/ajazz/ak820/ak820_nvm.c:163: if (batch_depth == 255u) nvm_fail(AK820_NVM_FAULT_BATCH_OVERFLOW);
      003F46 90 05 5A         [24]  988 	mov	dptr,#_batch_depth
      003F49 E0               [24]  989 	movx	a,@dptr
      003F4A FF               [12]  990 	mov	r7,a
      003F4B BF FF 06         [24]  991 	cjne	r7,#0xff,00102$
      003F4E 75 82 0F         [24]  992 	mov	dpl, #0x0f
      003F51 02 3B 4C         [24]  993 	ljmp	_nvm_fail
      003F54                        994 00102$:
                                    995 ;	keyboards/ajazz/ak820/ak820_nvm.c:164: else ++batch_depth;
      003F54 90 05 5A         [24]  996 	mov	dptr,#_batch_depth
      003F57 EF               [12]  997 	mov	a,r7
      003F58 04               [12]  998 	inc	a
      003F59 F0               [24]  999 	movx	@dptr,a
                                   1000 ;	keyboards/ajazz/ak820/ak820_nvm.c:165: }
      003F5A 22               [24] 1001 	ret
                                   1002 ;------------------------------------------------------------
                                   1003 ;Allocation info for local variables in function 'ak820_nvm_end'
                                   1004 ;------------------------------------------------------------
                                   1005 ;	keyboards/ajazz/ak820/ak820_nvm.c:167: void ak820_nvm_end(void) {
                                   1006 ;	-----------------------------------------
                                   1007 ;	 function ak820_nvm_end
                                   1008 ;	-----------------------------------------
      003F5B                       1009 _ak820_nvm_end:
                                   1010 ;	keyboards/ajazz/ak820/ak820_nvm.c:168: if (batch_depth) --batch_depth;
      003F5B 90 05 5A         [24] 1011 	mov	dptr,#_batch_depth
      003F5E E0               [24] 1012 	movx	a,@dptr
      003F5F FF               [12] 1013 	mov	r7,a
      003F60 E0               [24] 1014 	movx	a,@dptr
      003F61 60 06            [24] 1015 	jz	00102$
      003F63 EF               [12] 1016 	mov	a,r7
      003F64 14               [12] 1017 	dec	a
      003F65 90 05 5A         [24] 1018 	mov	dptr,#_batch_depth
      003F68 F0               [24] 1019 	movx	@dptr,a
      003F69                       1020 00102$:
                                   1021 ;	keyboards/ajazz/ak820/ak820_nvm.c:169: if (!batch_depth) ak820_nvm_flush();
      003F69 90 05 5A         [24] 1022 	mov	dptr,#_batch_depth
      003F6C E0               [24] 1023 	movx	a,@dptr
      003F6D 70 03            [24] 1024 	jnz	00105$
                                   1025 ;	keyboards/ajazz/ak820/ak820_nvm.c:170: }
      003F6F 02 3D F3         [24] 1026 	ljmp	_ak820_nvm_flush
      003F72                       1027 00105$:
      003F72 22               [24] 1028 	ret
                                   1029 ;------------------------------------------------------------
                                   1030 ;Allocation info for local variables in function 'load_page'
                                   1031 ;------------------------------------------------------------
                                   1032 ;page          Allocated with name '_load_page_page_10000_87'
                                   1033 ;i             Allocated with name '_load_page_i_10000_88'
                                   1034 ;------------------------------------------------------------
                                   1035 ;	keyboards/ajazz/ak820/ak820_nvm.c:172: static bool load_page(uint8_t page) {
                                   1036 ;	-----------------------------------------
                                   1037 ;	 function load_page
                                   1038 ;	-----------------------------------------
      003F73                       1039 _load_page:
      003F73 E5 82            [12] 1040 	mov	a,dpl
      003F75 90 05 7B         [24] 1041 	mov	dptr,#_load_page_page_10000_87
      003F78 F0               [24] 1042 	movx	@dptr,a
                                   1043 ;	keyboards/ajazz/ak820/ak820_nvm.c:174: if (page_valid && cached_page == page) return !storage_failed;
      003F79 30 07 17         [24] 1044 	jnb	_page_valid,00102$
      003F7C 90 05 59         [24] 1045 	mov	dptr,#_cached_page
      003F7F E0               [24] 1046 	movx	a,@dptr
      003F80 FF               [12] 1047 	mov	r7,a
      003F81 90 05 7B         [24] 1048 	mov	dptr,#_load_page_page_10000_87
      003F84 E0               [24] 1049 	movx	a,@dptr
      003F85 FE               [12] 1050 	mov	r6,a
      003F86 EF               [12] 1051 	mov	a,r7
      003F87 B5 06 09         [24] 1052 	cjne	a,ar6,00102$
      003F8A A2 09            [12] 1053 	mov	c,_storage_failed
      003F8C B3               [12] 1054 	cpl	c
      003F8D 92 0B            [24] 1055 	mov  _load_page_sloc0_1_0,c
      003F8F 12 38 6F         [24] 1056 	lcall	_ak820_outline_0149
      003F92 22               [24] 1057 	ret
      003F93                       1058 00102$:
                                   1059 ;	keyboards/ajazz/ak820/ak820_nvm.c:175: ak820_nvm_flush();
      003F93 12 3D F3         [24] 1060 	lcall	_ak820_nvm_flush
                                   1061 ;	keyboards/ajazz/ak820/ak820_nvm.c:176: if (storage_failed) return false;
      003F96 30 09 04         [24] 1062 	jnb	_storage_failed,00119$
      003F99 75 82 00         [24] 1063 	mov	dpl, #0x00
                                   1064 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003F9C 22               [24] 1065 	ret
      003F9D                       1066 00119$:
      003F9D 7F 00            [12] 1067 	mov	r7,#0x00
      003F9F                       1068 00107$:
                                   1069 ;	keyboards/ajazz/ak820/ak820_nvm.c:178: page_data[i] = ak820_flash_read(AK820_NVM_BASE + page * AK820_FLASH_PAGE + i);
      003F9F EF               [12] 1070 	mov	a,r7
      003FA0 24 19            [12] 1071 	add	a, #_page_data
      003FA2 FD               [12] 1072 	mov	r5,a
      003FA3 E4               [12] 1073 	clr	a
      003FA4 34 05            [12] 1074 	addc	a, #(_page_data >> 8)
      003FA6 FE               [12] 1075 	mov	r6,a
      003FA7 90 05 7B         [24] 1076 	mov	dptr,#_load_page_page_10000_87
      003FAA E0               [24] 1077 	movx	a,@dptr
      003FAB FC               [12] 1078 	mov	r4,a
      003FAC FA               [12] 1079 	mov	r2,a
      003FAD E4               [12] 1080 	clr	a
      003FAE C3               [12] 1081 	clr	c
      003FAF CA               [12] 1082 	xch	a,r2
      003FB0 13               [12] 1083 	rrc	a
      003FB1 CA               [12] 1084 	xch	a,r2
      003FB2 13               [12] 1085 	rrc	a
      003FB3 A2 E0            [12] 1086 	mov	c,acc.0
      003FB5 CA               [12] 1087 	xch	a,r2
      003FB6 13               [12] 1088 	rrc	a
      003FB7 CA               [12] 1089 	xch	a,r2
      003FB8 13               [12] 1090 	rrc	a
      003FB9 CA               [12] 1091 	xch	a,r2
      003FBA 24 C7            [12] 1092 	add	a,#0xc7
      003FBC FB               [12] 1093 	mov	r3,a
      003FBD 8F 01            [24] 1094 	mov	ar1,r7
      003FBF 89 00            [24] 1095 	mov	ar0,r1
      003FC1 79 00            [12] 1096 	mov	r1,#0x00
      003FC3 E8               [12] 1097 	mov	a,r0
      003FC4 2A               [12] 1098 	add	a, r2
      003FC5 FA               [12] 1099 	mov	r2,a
      003FC6 E9               [12] 1100 	mov	a,r1
      003FC7 3B               [12] 1101 	addc	a, r3
      003FC8 FB               [12] 1102 	mov	r3,a
      003FC9 12 43 31         [24] 1103 	lcall	_ak820_outline_0135
      003FCC 12 38 B8         [24] 1104 	lcall	_ak820_flash_read
      003FCF AB 82            [24] 1105 	mov	r3, dpl
      003FD1 12 38 6A         [24] 1106 	lcall	_ak820_outline_0137
      003FD4 EB               [12] 1107 	mov	a,r3
      003FD5 F0               [24] 1108 	movx	@dptr,a
                                   1109 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003FD6 0F               [12] 1110 	inc	r7
      003FD7 BF 40 C5         [24] 1111 	cjne	r7,#0x40,00107$
                                   1112 ;	keyboards/ajazz/ak820/ak820_nvm.c:180: cached_page = page;
      003FDA 90 05 59         [24] 1113 	mov	dptr,#_cached_page
      003FDD EC               [12] 1114 	mov	a,r4
      003FDE F0               [24] 1115 	movx	@dptr,a
                                   1116 ;	keyboards/ajazz/ak820/ak820_nvm.c:181: page_valid = true;
                                   1117 ;	assignBit
      003FDF D2 07            [12] 1118 	setb	_page_valid
                                   1119 ;	keyboards/ajazz/ak820/ak820_nvm.c:182: return true;
      003FE1 75 82 01         [24] 1120 	mov	dpl, #0x01
                                   1121 ;	keyboards/ajazz/ak820/ak820_nvm.c:183: }
      003FE4 22               [24] 1122 	ret
                                   1123 ;------------------------------------------------------------
                                   1124 ;Allocation info for local variables in function 'read_offset'
                                   1125 ;------------------------------------------------------------
                                   1126 ;offset        Allocated with name '_read_offset_offset_10000_93'
                                   1127 ;------------------------------------------------------------
                                   1128 ;	keyboards/ajazz/ak820/ak820_nvm.c:185: static uint8_t read_offset(uint16_t offset) {
                                   1129 ;	-----------------------------------------
                                   1130 ;	 function read_offset
                                   1131 ;	-----------------------------------------
      003FE5                       1132 _read_offset:
      003FE5 12 38 55         [24] 1133 	lcall	_ak820_outline_0106
      003FE8 90 05 7C         [24] 1134 	mov	dptr,#_read_offset_offset_10000_93
      003FEB 12 38 50         [24] 1135 	lcall	_ak820_outline_0105
                                   1136 ;	keyboards/ajazz/ak820/ak820_nvm.c:186: if (offset >= AK820_NVM_SIZE) return 0;
      003FEE 90 05 7C         [24] 1137 	mov	dptr,#_read_offset_offset_10000_93
      003FF1 12 38 00         [24] 1138 	lcall	_ak820_outline_0056
      003FF4 C3               [12] 1139 	clr	c
      003FF5 94 28            [12] 1140 	subb	a,#0x28
      003FF7 40 04            [24] 1141 	jc	00102$
      003FF9 75 82 00         [24] 1142 	mov	dpl, #0x00
      003FFC 22               [24] 1143 	ret
      003FFD                       1144 00102$:
                                   1145 ;	keyboards/ajazz/ak820/ak820_nvm.c:187: if (page_valid && (offset / AK820_FLASH_PAGE) == cached_page)
      003FFD 30 07 34         [24] 1146 	jnb	_page_valid,00104$
      004000 8E 04            [24] 1147 	mov	ar4,r6
      004002 EF               [12] 1148 	mov	a,r7
      004003 A2 E7            [12] 1149 	mov	c,acc.7
      004005 CC               [12] 1150 	xch	a,r4
      004006 33               [12] 1151 	rlc	a
      004007 CC               [12] 1152 	xch	a,r4
      004008 33               [12] 1153 	rlc	a
      004009 A2 E7            [12] 1154 	mov	c,acc.7
      00400B CC               [12] 1155 	xch	a,r4
      00400C 33               [12] 1156 	rlc	a
      00400D CC               [12] 1157 	xch	a,r4
      00400E 33               [12] 1158 	rlc	a
      00400F CC               [12] 1159 	xch	a,r4
      004010 54 03            [12] 1160 	anl	a,#0x03
      004012 FD               [12] 1161 	mov	r5,a
      004013 90 05 59         [24] 1162 	mov	dptr,#_cached_page
      004016 E0               [24] 1163 	movx	a,@dptr
      004017 FA               [12] 1164 	mov	r2,a
      004018 7B 00            [12] 1165 	mov	r3,#0x00
      00401A EC               [12] 1166 	mov	a,r4
      00401B B5 02 16         [24] 1167 	cjne	a,ar2,00104$
      00401E ED               [12] 1168 	mov	a,r5
      00401F B5 03 12         [24] 1169 	cjne	a,ar3,00104$
                                   1170 ;	keyboards/ajazz/ak820/ak820_nvm.c:188: return page_data[offset % AK820_FLASH_PAGE];
      004022 74 3F            [12] 1171 	mov	a,#0x3f
      004024 5E               [12] 1172 	anl	a,r6
      004025 7D 00            [12] 1173 	mov	r5,#0x00
      004027 24 19            [12] 1174 	add	a, #_page_data
      004029 F5 82            [12] 1175 	mov	dpl,a
      00402B ED               [12] 1176 	mov	a,r5
      00402C 34 05            [12] 1177 	addc	a, #(_page_data >> 8)
      00402E F5 83            [12] 1178 	mov	dph,a
      004030 E0               [24] 1179 	movx	a,@dptr
      004031 F5 82            [12] 1180 	mov	dpl,a
      004033 22               [24] 1181 	ret
      004034                       1182 00104$:
                                   1183 ;	keyboards/ajazz/ak820/ak820_nvm.c:189: return ak820_flash_read(AK820_NVM_BASE + offset);
      004034 74 C7            [12] 1184 	mov	a,#0xc7
      004036 2F               [12] 1185 	add	a, r7
      004037 FF               [12] 1186 	mov	r7,a
      004038 12 43 2C         [24] 1187 	lcall	_ak820_outline_0119
                                   1188 ;	keyboards/ajazz/ak820/ak820_nvm.c:190: }
      00403B 02 38 B8         [24] 1189 	ljmp	_ak820_flash_read
                                   1190 ;------------------------------------------------------------
                                   1191 ;Allocation info for local variables in function 'eeprom_read_byte'
                                   1192 ;------------------------------------------------------------
                                   1193 ;addr          Allocated with name '_eeprom_read_byte_addr_10000_97'
                                   1194 ;------------------------------------------------------------
                                   1195 ;	keyboards/ajazz/ak820/ak820_nvm.c:193: uint8_t eeprom_read_byte(const uint8_t *addr) {
                                   1196 ;	-----------------------------------------
                                   1197 ;	 function eeprom_read_byte
                                   1198 ;	-----------------------------------------
      00403E                       1199 _eeprom_read_byte:
      00403E C0 07            [24] 1200 	push	ar7
      004040 C0 06            [24] 1201 	push	ar6
      004042 12 42 DD         [24] 1202 	lcall	_ak820_outline_0042
      004045 90 05 7E         [24] 1203 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      004048 12 37 E8         [24] 1204 	lcall	_ak820_outline_0018
                                   1205 ;	keyboards/ajazz/ak820/ak820_nvm.c:194: return read_offset((uint16_t)(uintptr_t)addr);
      00404B 90 05 7E         [24] 1206 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      00404E 12 37 B1         [24] 1207 	lcall	_ak820_outline_0005
      004051 C0 06            [24] 1208 	push	ar6
      004053 C0 05            [24] 1209 	push	ar5
      004055 C0 04            [24] 1210 	push	ar4
      004057 C0 03            [24] 1211 	push	ar3
      004059 C0 02            [24] 1212 	push	ar2
      00405B C0 01            [24] 1213 	push	ar1
      00405D C0 00            [24] 1214 	push	ar0
      00405F 12 3F E5         [24] 1215 	lcall	_read_offset
      004062 AF 82            [24] 1216 	mov	r7, dpl
      004064 D0 00            [24] 1217 	pop	ar0
      004066 D0 01            [24] 1218 	pop	ar1
      004068 D0 02            [24] 1219 	pop	ar2
      00406A D0 03            [24] 1220 	pop	ar3
      00406C D0 04            [24] 1221 	pop	ar4
      00406E D0 05            [24] 1222 	pop	ar5
      004070 D0 06            [24] 1223 	pop	ar6
      004072 8F 82            [24] 1224 	mov	dpl, r7
                                   1225 ;	keyboards/ajazz/ak820/ak820_nvm.c:195: }
      004074 D0 06            [24] 1226 	pop	ar6
      004076 D0 07            [24] 1227 	pop	ar7
      004078 22               [24] 1228 	ret
                                   1229 ;------------------------------------------------------------
                                   1230 ;Allocation info for local variables in function 'eeprom_read_block'
                                   1231 ;------------------------------------------------------------
                                   1232 ;addr          Allocated with name '_eeprom_read_block_PARM_2'
                                   1233 ;len           Allocated with name '_eeprom_read_block_PARM_3'
                                   1234 ;buf           Allocated with name '_eeprom_read_block_buf_10000_99'
                                   1235 ;offset        Allocated with name '_eeprom_read_block_offset_10000_100'
                                   1236 ;out           Allocated with name '_eeprom_read_block_out_10000_100'
                                   1237 ;------------------------------------------------------------
                                   1238 ;	keyboards/ajazz/ak820/ak820_nvm.c:199: void eeprom_read_block(void *buf, const void *addr, size_t len) {
                                   1239 ;	-----------------------------------------
                                   1240 ;	 function ak820_eeprom_read_block_xdata
                                   1241 ;	-----------------------------------------
      004079                       1242 _ak820_eeprom_read_block_xdata:
      004079 12 38 55         [24] 1243 	lcall	_ak820_outline_0106
      00407C 90 05 86         [24] 1244 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      00407F 12 38 50         [24] 1245 	lcall	_ak820_outline_0105
                                   1246 ;	keyboards/ajazz/ak820/ak820_nvm.c:230: uint16_t offset = (uint16_t)(uintptr_t)addr;
      004082 90 05 81         [24] 1247 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      004085 12 38 00         [24] 1248 	lcall	_ak820_outline_0056
                                   1249 ;	keyboards/ajazz/ak820/ak820_nvm.c:231: uint8_t AK820_XDATA *out = (uint8_t AK820_XDATA *)buf;
      004088 90 05 86         [24] 1250 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      00408B 12 38 1F         [24] 1251 	lcall	_ak820_outline_0065
      00408E 90 05 88         [24] 1252 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004091 12 38 2B         [24] 1253 	lcall	_ak820_outline_0077
                                   1254 ;	keyboards/ajazz/ak820/ak820_nvm.c:232: while (len--) {
      004094 90 05 84         [24] 1255 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      004097 12 38 1F         [24] 1256 	lcall	_ak820_outline_0065
      00409A                       1257 00103$:
      00409A 8C 02            [24] 1258 	mov	ar2,r4
      00409C 8D 03            [24] 1259 	mov	ar3,r5
      00409E 1C               [12] 1260 	dec	r4
      00409F BC FF 01         [24] 1261 	cjne	r4,#0xff,00130$
      0040A2 1D               [12] 1262 	dec	r5
      0040A3                       1263 00130$:
      0040A3 EA               [12] 1264 	mov	a,r2
      0040A4 4B               [12] 1265 	orl	a,r3
      0040A5 60 5D            [24] 1266 	jz	00106$
                                   1267 ;	keyboards/ajazz/ak820/ak820_nvm.c:233: if (offset >= AK820_NVM_SIZE) { *out++ = 0; continue; }
      0040A7 8E 02            [24] 1268 	mov	ar2,r6
      0040A9 8F 03            [24] 1269 	mov	ar3,r7
      0040AB 74 D8            [12] 1270 	mov	a,#0x100 - 0x28
      0040AD 2B               [12] 1271 	add	a,r3
      0040AE 50 17            [24] 1272 	jnc	00102$
      0040B0 90 05 88         [24] 1273 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0040B3 12 43 0E         [24] 1274 	lcall	_ak820_outline_0082
      0040B6 12 43 31         [24] 1275 	lcall	_ak820_outline_0135
      0040B9 E4               [12] 1276 	clr	a
      0040BA F0               [24] 1277 	movx	@dptr,a
      0040BB 90 05 88         [24] 1278 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0040BE 04               [12] 1279 	inc	a
      0040BF 2A               [12] 1280 	add	a, r2
      0040C0 F0               [24] 1281 	movx	@dptr,a
      0040C1 E4               [12] 1282 	clr	a
      0040C2 3B               [12] 1283 	addc	a, r3
      0040C3 A3               [24] 1284 	inc	dptr
      0040C4 F0               [24] 1285 	movx	@dptr,a
      0040C5 80 D3            [24] 1286 	sjmp	00103$
      0040C7                       1287 00102$:
                                   1288 ;	keyboards/ajazz/ak820/ak820_nvm.c:234: *out++ = read_offset(offset);
      0040C7 90 05 88         [24] 1289 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0040CA 12 43 0E         [24] 1290 	lcall	_ak820_outline_0082
      0040CD 12 43 2C         [24] 1291 	lcall	_ak820_outline_0119
      0040D0 C0 07            [24] 1292 	push	ar7
      0040D2 C0 06            [24] 1293 	push	ar6
      0040D4 C0 05            [24] 1294 	push	ar5
      0040D6 C0 04            [24] 1295 	push	ar4
      0040D8 C0 03            [24] 1296 	push	ar3
      0040DA C0 02            [24] 1297 	push	ar2
      0040DC 12 3F E5         [24] 1298 	lcall	_read_offset
      0040DF A9 82            [24] 1299 	mov	r1, dpl
      0040E1 D0 02            [24] 1300 	pop	ar2
      0040E3 D0 03            [24] 1301 	pop	ar3
      0040E5 D0 04            [24] 1302 	pop	ar4
      0040E7 D0 05            [24] 1303 	pop	ar5
      0040E9 D0 06            [24] 1304 	pop	ar6
      0040EB D0 07            [24] 1305 	pop	ar7
      0040ED 12 43 31         [24] 1306 	lcall	_ak820_outline_0135
      0040F0 E9               [12] 1307 	mov	a,r1
      0040F1 F0               [24] 1308 	movx	@dptr,a
      0040F2 90 05 88         [24] 1309 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0040F5 74 01            [12] 1310 	mov	a,#0x01
      0040F7 2A               [12] 1311 	add	a, r2
      0040F8 F0               [24] 1312 	movx	@dptr,a
      0040F9 E4               [12] 1313 	clr	a
      0040FA 3B               [12] 1314 	addc	a, r3
      0040FB A3               [24] 1315 	inc	dptr
      0040FC F0               [24] 1316 	movx	@dptr,a
                                   1317 ;	keyboards/ajazz/ak820/ak820_nvm.c:235: ++offset;
      0040FD 0E               [12] 1318 	inc	r6
      0040FE BE 00 99         [24] 1319 	cjne	r6,#0x00,00103$
      004101 0F               [12] 1320 	inc	r7
      004102 80 96            [24] 1321 	sjmp	00103$
      004104                       1322 00106$:
                                   1323 ;	keyboards/ajazz/ak820/ak820_nvm.c:237: }
      004104 22               [24] 1324 	ret
                                   1325 ;------------------------------------------------------------
                                   1326 ;Allocation info for local variables in function 'ak820_eeprom_write_block_xdata'
                                   1327 ;------------------------------------------------------------
                                   1328 ;sloc0         Allocated with name '_ak820_eeprom_write_block_xdata_sloc0_1_0'
                                   1329 ;addr          Allocated with name '_ak820_eeprom_write_block_xdata_PARM_2'
                                   1330 ;len           Allocated with name '_ak820_eeprom_write_block_xdata_PARM_3'
                                   1331 ;buf           Allocated with name '_ak820_eeprom_write_block_xdata_buf_10000_118'
                                   1332 ;offset        Allocated with name '_ak820_eeprom_write_block_xdata_offset_10000_119'
                                   1333 ;in            Allocated with name '_ak820_eeprom_write_block_xdata_in_10000_119'
                                   1334 ;value         Allocated with name '_ak820_eeprom_write_block_xdata_value_20000_122'
                                   1335 ;------------------------------------------------------------
                                   1336 ;	keyboards/ajazz/ak820/ak820_nvm.c:239: void ak820_eeprom_write_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1337 ;	-----------------------------------------
                                   1338 ;	 function ak820_eeprom_write_block_xdata
                                   1339 ;	-----------------------------------------
      004105                       1340 _ak820_eeprom_write_block_xdata:
      004105 12 38 55         [24] 1341 	lcall	_ak820_outline_0106
      004108 90 05 8F         [24] 1342 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      00410B 12 38 50         [24] 1343 	lcall	_ak820_outline_0105
                                   1344 ;	keyboards/ajazz/ak820/ak820_nvm.c:240: uint16_t offset = (uint16_t)(uintptr_t)addr;
      00410E 90 05 8A         [24] 1345 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      004111 12 38 00         [24] 1346 	lcall	_ak820_outline_0056
                                   1347 ;	keyboards/ajazz/ak820/ak820_nvm.c:241: const uint8_t AK820_XDATA *in = (const uint8_t AK820_XDATA *)buf;
      004114 90 05 8F         [24] 1348 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      004117 12 38 1F         [24] 1349 	lcall	_ak820_outline_0065
                                   1350 ;	keyboards/ajazz/ak820/ak820_nvm.c:243: if (offset > AK820_NVM_SIZE || len > AK820_NVM_SIZE - offset) {
      00411A 8E 02            [24] 1351 	mov	ar2,r6
      00411C 8F 03            [24] 1352 	mov	ar3,r7
      00411E C3               [12] 1353 	clr	c
      00411F E4               [12] 1354 	clr	a
      004120 9A               [12] 1355 	subb	a,r2
      004121 74 28            [12] 1356 	mov	a,#0x28
      004123 9B               [12] 1357 	subb	a,r3
      004124 40 15            [24] 1358 	jc	00101$
                                   1359 ;	free result
      004126 E4               [12] 1360 	clr	a
      004127 C3               [12] 1361 	clr	c
      004128 9E               [12] 1362 	subb	a,r6
      004129 FA               [12] 1363 	mov	r2,a
      00412A 74 28            [12] 1364 	mov	a,#0x28
      00412C 9F               [12] 1365 	subb	a,r7
      00412D FB               [12] 1366 	mov	r3,a
      00412E 90 05 8D         [24] 1367 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004131 12 38 44         [24] 1368 	lcall	_ak820_outline_0102
      004134 C3               [12] 1369 	clr	c
      004135 EA               [12] 1370 	mov	a,r2
      004136 98               [12] 1371 	subb	a,r0
      004137 EB               [12] 1372 	mov	a,r3
      004138 99               [12] 1373 	subb	a,r1
      004139 50 06            [24] 1374 	jnc	00125$
                                   1375 ;	free result
      00413B                       1376 00101$:
                                   1377 ;	keyboards/ajazz/ak820/ak820_nvm.c:244: nvm_fail(AK820_NVM_FAULT_WRITE_RANGE);
      00413B 75 82 0E         [24] 1378 	mov	dpl, #0x0e
                                   1379 ;	keyboards/ajazz/ak820/ak820_nvm.c:245: return;
      00413E 02 3B 4C         [24] 1380 	ljmp	_nvm_fail
                                   1381 ;	keyboards/ajazz/ak820/ak820_nvm.c:247: while (len--) {
      004141                       1382 00125$:
      004141 90 05 8D         [24] 1383 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004144 12 43 0E         [24] 1384 	lcall	_ak820_outline_0082
      004147                       1385 00108$:
      004147 8A 00            [24] 1386 	mov	ar0,r2
      004149 8B 01            [24] 1387 	mov	ar1,r3
      00414B 1A               [12] 1388 	dec	r2
      00414C BA FF 01         [24] 1389 	cjne	r2,#0xff,00159$
      00414F 1B               [12] 1390 	dec	r3
      004150                       1391 00159$:
      004150 E8               [12] 1392 	mov	a,r0
      004151 49               [12] 1393 	orl	a,r1
      004152 70 03            [24] 1394 	jnz	00160$
      004154 02 41 DE         [24] 1395 	ljmp	00110$
      004157                       1396 00160$:
                                   1397 ;	keyboards/ajazz/ak820/ak820_nvm.c:248: uint8_t value = *in++;
      004157 C0 02            [24] 1398 	push	ar2
      004159 C0 03            [24] 1399 	push	ar3
      00415B 12 43 14         [24] 1400 	lcall	_ak820_outline_0097
      00415E F9               [12] 1401 	mov	r1,a
      00415F A3               [24] 1402 	inc	dptr
      004160 12 43 46         [24] 1403 	lcall	_ak820_outline_0151
                                   1404 ;	keyboards/ajazz/ak820/ak820_nvm.c:249: if (!load_page(offset / AK820_FLASH_PAGE)) return;
      004163 8E 0C            [24] 1405 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,r6
      004165 8F 0D            [24] 1406 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),r7
      004167 A8 0C            [24] 1407 	mov	r0,_ak820_eeprom_write_block_xdata_sloc0_1_0
      004169 E5 0D            [12] 1408 	mov	a,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      00416B A2 E7            [12] 1409 	mov	c,acc.7
      00416D C8               [12] 1410 	xch	a,r0
      00416E 33               [12] 1411 	rlc	a
      00416F C8               [12] 1412 	xch	a,r0
      004170 33               [12] 1413 	rlc	a
      004171 A2 E7            [12] 1414 	mov	c,acc.7
      004173 C8               [12] 1415 	xch	a,r0
      004174 33               [12] 1416 	rlc	a
      004175 C8               [12] 1417 	xch	a,r0
      004176 33               [12] 1418 	rlc	a
      004177 C8               [12] 1419 	xch	a,r0
      004178 54 03            [12] 1420 	anl	a,#0x03
      00417A FB               [12] 1421 	mov	r3,a
      00417B 88 82            [24] 1422 	mov	dpl, r0
      00417D C0 07            [24] 1423 	push	ar7
      00417F C0 06            [24] 1424 	push	ar6
      004181 C0 05            [24] 1425 	push	ar5
      004183 C0 04            [24] 1426 	push	ar4
      004185 C0 03            [24] 1427 	push	ar3
      004187 C0 02            [24] 1428 	push	ar2
      004189 C0 01            [24] 1429 	push	ar1
      00418B 12 3F 73         [24] 1430 	lcall	_load_page
      00418E E5 82            [12] 1431 	mov	a, dpl
      004190 D0 01            [24] 1432 	pop	ar1
      004192 D0 02            [24] 1433 	pop	ar2
      004194 D0 03            [24] 1434 	pop	ar3
      004196 D0 04            [24] 1435 	pop	ar4
      004198 D0 05            [24] 1436 	pop	ar5
      00419A D0 06            [24] 1437 	pop	ar6
      00419C D0 07            [24] 1438 	pop	ar7
      00419E D0 03            [24] 1439 	pop	ar3
      0041A0 D0 02            [24] 1440 	pop	ar2
      0041A2 70 01            [24] 1441 	jnz	00105$
      0041A4 22               [24] 1442 	ret
      0041A5                       1443 00105$:
                                   1444 ;	keyboards/ajazz/ak820/ak820_nvm.c:250: if (page_data[offset % AK820_FLASH_PAGE] != value) {
      0041A5 C0 06            [24] 1445 	push	ar6
      0041A7 C0 07            [24] 1446 	push	ar7
      0041A9 74 3F            [12] 1447 	mov	a,#0x3f
      0041AB 55 0C            [12] 1448 	anl	a,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0041AD 7F 00            [12] 1449 	mov	r7,#0x00
      0041AF 24 19            [12] 1450 	add	a, #_page_data
      0041B1 F5 0C            [12] 1451 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,a
      0041B3 EF               [12] 1452 	mov	a,r7
      0041B4 34 05            [12] 1453 	addc	a, #(_page_data >> 8)
      0041B6 F5 0D            [12] 1454 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),a
      0041B8 85 0C 82         [24] 1455 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0041BB 85 0D 83         [24] 1456 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      0041BE E0               [24] 1457 	movx	a,@dptr
      0041BF B5 01 06         [24] 1458 	cjne	a,ar1,00162$
      0041C2 D0 07            [24] 1459 	pop	ar7
      0041C4 D0 06            [24] 1460 	pop	ar6
      0041C6 80 0E            [24] 1461 	sjmp	00107$
      0041C8                       1462 00162$:
      0041C8 D0 07            [24] 1463 	pop	ar7
      0041CA D0 06            [24] 1464 	pop	ar6
                                   1465 ;	keyboards/ajazz/ak820/ak820_nvm.c:251: page_data[offset % AK820_FLASH_PAGE] = value;
      0041CC 85 0C 82         [24] 1466 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0041CF 85 0D 83         [24] 1467 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      0041D2 E9               [12] 1468 	mov	a,r1
      0041D3 F0               [24] 1469 	movx	@dptr,a
                                   1470 ;	keyboards/ajazz/ak820/ak820_nvm.c:252: page_dirty = true;
                                   1471 ;	assignBit
      0041D4 D2 08            [12] 1472 	setb	_page_dirty
      0041D6                       1473 00107$:
                                   1474 ;	keyboards/ajazz/ak820/ak820_nvm.c:254: ++offset;
      0041D6 0E               [12] 1475 	inc	r6
      0041D7 BE 00 01         [24] 1476 	cjne	r6,#0x00,00163$
      0041DA 0F               [12] 1477 	inc	r7
      0041DB                       1478 00163$:
      0041DB 02 41 47         [24] 1479 	ljmp	00108$
      0041DE                       1480 00110$:
                                   1481 ;	keyboards/ajazz/ak820/ak820_nvm.c:256: if (!batch_depth) ak820_nvm_flush();
      0041DE 90 05 5A         [24] 1482 	mov	dptr,#_batch_depth
      0041E1 E0               [24] 1483 	movx	a,@dptr
      0041E2 70 03            [24] 1484 	jnz	00113$
                                   1485 ;	keyboards/ajazz/ak820/ak820_nvm.c:257: }
      0041E4 02 3D F3         [24] 1486 	ljmp	_ak820_nvm_flush
      0041E7                       1487 00113$:
      0041E7 22               [24] 1488 	ret
                                   1489 ;------------------------------------------------------------
                                   1490 ;Allocation info for local variables in function 'ak820_eeprom_update_block_xdata'
                                   1491 ;------------------------------------------------------------
                                   1492 ;sloc0         Allocated with name '_ak820_eeprom_update_block_xdata_sloc0_1_0'
                                   1493 ;sloc1         Allocated with name '_ak820_eeprom_update_block_xdata_sloc1_1_0'
                                   1494 ;sloc2         Allocated with name '_ak820_eeprom_update_block_xdata_sloc2_1_0'
                                   1495 ;addr          Allocated with name '_ak820_eeprom_update_block_xdata_PARM_2'
                                   1496 ;len           Allocated with name '_ak820_eeprom_update_block_xdata_PARM_3'
                                   1497 ;buf           Allocated with name '_ak820_eeprom_update_block_xdata_buf_10000_127'
                                   1498 ;source        Allocated with name '_ak820_eeprom_update_block_xdata_source_10000_128'
                                   1499 ;offset        Allocated with name '_ak820_eeprom_update_block_xdata_offset_10000_128'
                                   1500 ;i             Allocated with name '_ak820_eeprom_update_block_xdata_i_10000_128'
                                   1501 ;------------------------------------------------------------
                                   1502 ;	keyboards/ajazz/ak820/ak820_nvm.c:259: void ak820_eeprom_update_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1503 ;	-----------------------------------------
                                   1504 ;	 function ak820_eeprom_update_block_xdata
                                   1505 ;	-----------------------------------------
      0041E8                       1506 _ak820_eeprom_update_block_xdata:
      0041E8 12 38 55         [24] 1507 	lcall	_ak820_outline_0106
      0041EB 90 05 96         [24] 1508 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      0041EE 12 38 50         [24] 1509 	lcall	_ak820_outline_0105
                                   1510 ;	keyboards/ajazz/ak820/ak820_nvm.c:260: const uint8_t AK820_XDATA *source = (const uint8_t AK820_XDATA *)buf;
      0041F1 90 05 96         [24] 1511 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      0041F4 12 38 00         [24] 1512 	lcall	_ak820_outline_0056
                                   1513 ;	keyboards/ajazz/ak820/ak820_nvm.c:261: uint16_t offset = (uint16_t)(uintptr_t)addr;
      0041F7 90 05 91         [24] 1514 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      0041FA E0               [24] 1515 	movx	a,@dptr
      0041FB F5 12            [12] 1516 	mov	_ak820_eeprom_update_block_xdata_sloc2_1_0,a
      0041FD A3               [24] 1517 	inc	dptr
      0041FE E0               [24] 1518 	movx	a,@dptr
      0041FF F5 13            [12] 1519 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1),a
      004201 A3               [24] 1520 	inc	dptr
      004202 E0               [24] 1521 	movx	a,@dptr
      004203 F5 14            [12] 1522 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2),a
      004205 A9 12            [24] 1523 	mov	r1,_ak820_eeprom_update_block_xdata_sloc2_1_0
      004207 AA 13            [24] 1524 	mov	r2,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
                                   1525 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      004209 E4               [12] 1526 	clr	a
      00420A F5 0E            [12] 1527 	mov	_ak820_eeprom_update_block_xdata_sloc0_1_0,a
      00420C F5 0F            [12] 1528 	mov	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1),a
      00420E                       1529 00105$:
      00420E 90 05 94         [24] 1530 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      004211 E0               [24] 1531 	movx	a,@dptr
      004212 F5 10            [12] 1532 	mov	_ak820_eeprom_update_block_xdata_sloc1_1_0,a
      004214 A3               [24] 1533 	inc	dptr
      004215 E0               [24] 1534 	movx	a,@dptr
      004216 F5 11            [12] 1535 	mov	(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1),a
      004218 C3               [12] 1536 	clr	c
      004219 E5 0E            [12] 1537 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      00421B 95 10            [12] 1538 	subb	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      00421D E5 0F            [12] 1539 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      00421F 95 11            [12] 1540 	subb	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      004221 50 68            [24] 1541 	jnc	00107$
                                   1542 ;	keyboards/ajazz/ak820/ak820_nvm.c:264: if (read_offset(offset + i) != source[i]) {
      004223 89 00            [24] 1543 	mov	ar0,r1
      004225 8A 05            [24] 1544 	mov	ar5,r2
      004227 E5 0E            [12] 1545 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      004229 28               [12] 1546 	add	a, r0
      00422A F8               [12] 1547 	mov	r0,a
      00422B E5 0F            [12] 1548 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      00422D 3D               [12] 1549 	addc	a, r5
      00422E FD               [12] 1550 	mov	r5,a
      00422F 88 82            [24] 1551 	mov	dpl, r0
      004231 8D 83            [24] 1552 	mov	dph, r5
      004233 C0 07            [24] 1553 	push	ar7
      004235 C0 06            [24] 1554 	push	ar6
      004237 C0 02            [24] 1555 	push	ar2
      004239 C0 01            [24] 1556 	push	ar1
      00423B 12 3F E5         [24] 1557 	lcall	_read_offset
      00423E AD 82            [24] 1558 	mov	r5, dpl
      004240 D0 01            [24] 1559 	pop	ar1
      004242 D0 02            [24] 1560 	pop	ar2
      004244 D0 06            [24] 1561 	pop	ar6
      004246 D0 07            [24] 1562 	pop	ar7
      004248 E5 0E            [12] 1563 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      00424A 2E               [12] 1564 	add	a, r6
      00424B F5 82            [12] 1565 	mov	dpl,a
      00424D E5 0F            [12] 1566 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      00424F 3F               [12] 1567 	addc	a, r7
      004250 F5 83            [12] 1568 	mov	dph,a
      004252 E0               [24] 1569 	movx	a,@dptr
      004253 FC               [12] 1570 	mov	r4,a
      004254 ED               [12] 1571 	mov	a,r5
      004255 B5 04 02         [24] 1572 	cjne	a,ar4,00131$
      004258 80 27            [24] 1573 	sjmp	00106$
      00425A                       1574 00131$:
                                   1575 ;	keyboards/ajazz/ak820/ak820_nvm.c:265: ak820_eeprom_write_block_xdata(buf, addr, len);
      00425A 90 05 96         [24] 1576 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      00425D E0               [24] 1577 	movx	a,@dptr
      00425E F8               [12] 1578 	mov	r0,a
      00425F A3               [24] 1579 	inc	dptr
      004260 E0               [24] 1580 	movx	a,@dptr
      004261 FD               [12] 1581 	mov	r5,a
      004262 90 05 8A         [24] 1582 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      004265 E5 12            [12] 1583 	mov	a,_ak820_eeprom_update_block_xdata_sloc2_1_0
      004267 F0               [24] 1584 	movx	@dptr,a
      004268 E5 13            [12] 1585 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
      00426A A3               [24] 1586 	inc	dptr
      00426B F0               [24] 1587 	movx	@dptr,a
      00426C E5 14            [12] 1588 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2)
      00426E A3               [24] 1589 	inc	dptr
      00426F F0               [24] 1590 	movx	@dptr,a
      004270 90 05 8D         [24] 1591 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004273 E5 10            [12] 1592 	mov	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      004275 F0               [24] 1593 	movx	@dptr,a
      004276 E5 11            [12] 1594 	mov	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      004278 A3               [24] 1595 	inc	dptr
      004279 F0               [24] 1596 	movx	@dptr,a
      00427A 88 82            [24] 1597 	mov	dpl, r0
      00427C 8D 83            [24] 1598 	mov	dph, r5
                                   1599 ;	keyboards/ajazz/ak820/ak820_nvm.c:266: return;
      00427E 02 41 05         [24] 1600 	ljmp	_ak820_eeprom_write_block_xdata
      004281                       1601 00106$:
                                   1602 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      004281 05 0E            [12] 1603 	inc	_ak820_eeprom_update_block_xdata_sloc0_1_0
      004283 E4               [12] 1604 	clr	a
      004284 B5 0E 87         [24] 1605 	cjne	a,_ak820_eeprom_update_block_xdata_sloc0_1_0,00105$
      004287 05 0F            [12] 1606 	inc	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      004289 80 83            [24] 1607 	sjmp	00105$
      00428B                       1608 00107$:
                                   1609 ;	keyboards/ajazz/ak820/ak820_nvm.c:269: }
      00428B 22               [24] 1610 	ret
                                   1611 ;------------------------------------------------------------
                                   1612 ;Allocation info for local variables in function 'eeprom_driver_erase'
                                   1613 ;------------------------------------------------------------
                                   1614 ;page          Allocated with name '_eeprom_driver_erase_page_10000_134'
                                   1615 ;i             Allocated with name '_eeprom_driver_erase_i_10000_134'
                                   1616 ;------------------------------------------------------------
                                   1617 ;	keyboards/ajazz/ak820/ak820_nvm.c:271: void eeprom_driver_erase(void) {
                                   1618 ;	-----------------------------------------
                                   1619 ;	 function eeprom_driver_erase
                                   1620 ;	-----------------------------------------
      00428C                       1621 _eeprom_driver_erase:
                                   1622 ;	keyboards/ajazz/ak820/ak820_nvm.c:274: ak820_nvm_flush();
      00428C 12 3D F3         [24] 1623 	lcall	_ak820_nvm_flush
                                   1624 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      00428F 7F 00            [12] 1625 	mov	r7,#0x00
      004291                       1626 00111$:
      004291 BF A0 01         [24] 1627 	cjne	r7,#0xa0,00165$
      004294 22               [24] 1628 	ret
      004295                       1629 00165$:
      004295 20 09 32         [24] 1630 	jb	_storage_failed,00113$
                                   1631 ;	keyboards/ajazz/ak820/ak820_nvm.c:276: if (!load_page(page)) return;
      004298 8F 82            [24] 1632 	mov	dpl, r7
      00429A C0 07            [24] 1633 	push	ar7
      00429C 12 3F 73         [24] 1634 	lcall	_load_page
      00429F E5 82            [12] 1635 	mov	a, dpl
      0042A1 D0 07            [24] 1636 	pop	ar7
      0042A3 70 01            [24] 1637 	jnz	00126$
                                   1638 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      0042A5 22               [24] 1639 	ret
      0042A6                       1640 00126$:
      0042A6 7E 00            [12] 1641 	mov	r6,#0x00
      0042A8                       1642 00107$:
                                   1643 ;	keyboards/ajazz/ak820/ak820_nvm.c:278: if (page_data[i]) { page_data[i] = 0; page_dirty = true; }
      0042A8 EE               [12] 1644 	mov	a,r6
      0042A9 24 19            [12] 1645 	add	a, #_page_data
      0042AB FC               [12] 1646 	mov	r4,a
      0042AC E4               [12] 1647 	clr	a
      0042AD 34 05            [12] 1648 	addc	a, #(_page_data >> 8)
      0042AF FD               [12] 1649 	mov	r5,a
      0042B0 12 43 14         [24] 1650 	lcall	_ak820_outline_0097
      0042B3 60 07            [24] 1651 	jz	00108$
      0042B5 12 38 5A         [24] 1652 	lcall	_ak820_outline_0123
      0042B8 E4               [12] 1653 	clr	a
      0042B9 F0               [24] 1654 	movx	@dptr,a
                                   1655 ;	assignBit
      0042BA D2 08            [12] 1656 	setb	_page_dirty
      0042BC                       1657 00108$:
                                   1658 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      0042BC 0E               [12] 1659 	inc	r6
      0042BD BE 40 E8         [24] 1660 	cjne	r6,#0x40,00107$
                                   1661 ;	keyboards/ajazz/ak820/ak820_nvm.c:280: ak820_nvm_flush();
      0042C0 C0 07            [24] 1662 	push	ar7
      0042C2 12 3D F3         [24] 1663 	lcall	_ak820_nvm_flush
      0042C5 D0 07            [24] 1664 	pop	ar7
                                   1665 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      0042C7 0F               [12] 1666 	inc	r7
      0042C8 80 C7            [24] 1667 	sjmp	00111$
      0042CA                       1668 00113$:
                                   1669 ;	keyboards/ajazz/ak820/ak820_nvm.c:282: }
      0042CA 22               [24] 1670 	ret
                                   1671 	.area CSEG    (CODE)
                                   1672 	.area CONST   (CODE)
                                   1673 	.area XINIT   (CODE)
                                   1674 	.area CABS    (ABS,CODE)
                                   1675 
                                   1676 ; Experimental exact instruction outlining.
                                   1677 	.globl _ak820_outline_0005
                                   1678 	.globl _ak820_outline_0013
                                   1679 	.globl _ak820_outline_0017
                                   1680 	.globl _ak820_outline_0018
                                   1681 	.globl _ak820_outline_0036
                                   1682 	.globl _ak820_outline_0042
                                   1683 	.globl _ak820_outline_0045
                                   1684 	.globl _ak820_outline_0056
                                   1685 	.globl _ak820_outline_0057
                                   1686 	.globl _ak820_outline_0065
                                   1687 	.globl _ak820_outline_0066
                                   1688 	.globl _ak820_outline_0069
                                   1689 	.globl _ak820_outline_0077
                                   1690 	.globl _ak820_outline_0081
                                   1691 	.globl _ak820_outline_0082
                                   1692 	.globl _ak820_outline_0097
                                   1693 	.globl _ak820_outline_0098
                                   1694 	.globl _ak820_outline_0102
                                   1695 	.globl _ak820_outline_0103
                                   1696 	.globl _ak820_outline_0105
                                   1697 	.globl _ak820_outline_0106
                                   1698 	.globl _ak820_outline_0108
                                   1699 	.globl _ak820_outline_0119
                                   1700 	.globl _ak820_outline_0123
                                   1701 	.globl _ak820_outline_0124
                                   1702 	.globl _ak820_outline_0135
                                   1703 	.globl _ak820_outline_0136
                                   1704 	.globl _ak820_outline_0137
                                   1705 	.globl _ak820_outline_0142
                                   1706 	.globl _ak820_outline_0149
                                   1707 	.globl _ak820_outline_0150
                                   1708 	.globl _ak820_outline_0151
                                   1709 	.globl _ak820_outline_0159
                                   1710 	.globl _ak820_outline_0163
                                   1711 	.globl _ak820_outline_0164
                                   1712 	.globl _ak820_outline_0184
                                   1713 
                                   1714 	.area CSEG (CODE)
                                   1715 ; function ak820_outline_0013
      0042CB                       1716 _ak820_outline_0013:
      0042CB 8E 82            [24] 1717 	mov	dpl,r6
      0042CD 8F 83            [24] 1718 	mov	dph,r7
      0042CF A3               [24] 1719 	inc	dptr
      0042D0 A3               [24] 1720 	inc	dptr
      0042D1 A3               [24] 1721 	inc	dptr
      0042D2 A3               [24] 1722 	inc	dptr
      0042D3 A3               [24] 1723 	inc	dptr
      0042D4 22               [24] 1724 	ret
                                   1725 
                                   1726 	.area CSEG (CODE)
                                   1727 ; function ak820_outline_0036
      0042D5                       1728 _ak820_outline_0036:
      0042D5 F0               [24] 1729 	movx	@dptr,a
      0042D6 8E 82            [24] 1730 	mov	dpl,r6
      0042D8 8F 83            [24] 1731 	mov	dph,r7
      0042DA A3               [24] 1732 	inc	dptr
      0042DB A3               [24] 1733 	inc	dptr
      0042DC 22               [24] 1734 	ret
                                   1735 
                                   1736 	.area CSEG (CODE)
                                   1737 ; function ak820_outline_0042
      0042DD                       1738 _ak820_outline_0042:
      0042DD AF F0            [24] 1739 	mov	r7,b
      0042DF AE 83            [24] 1740 	mov	r6,dph
      0042E1 E5 82            [12] 1741 	mov	a,dpl
      0042E3 22               [24] 1742 	ret
                                   1743 
                                   1744 	.area CSEG (CODE)
                                   1745 ; function ak820_outline_0045
      0042E4                       1746 _ak820_outline_0045:
      0042E4 EF               [12] 1747 	mov	a,r7
      0042E5 24 71            [12] 1748 	add	a,#_ak820_nvm_flush_header_10000_62
      0042E7 F5 82            [12] 1749 	mov	dpl,a
      0042E9 E4               [12] 1750 	clr	a
      0042EA 34 05            [12] 1751 	addc	a,#(_ak820_nvm_flush_header_10000_62>>8)
      0042EC F5 83            [12] 1752 	mov	dph,a
      0042EE E0               [24] 1753 	movx	a,@dptr
      0042EF 22               [24] 1754 	ret
                                   1755 
                                   1756 	.area CSEG (CODE)
                                   1757 ; function ak820_outline_0057
      0042F0                       1758 _ak820_outline_0057:
      0042F0 8F 06            [24] 1759 	mov	ar6,r7
      0042F2 7D 00            [12] 1760 	mov	r5,#0x00
      0042F4 74 40            [12] 1761 	mov	a,#0x40
      0042F6 2E               [12] 1762 	add	a,r6
      0042F7 FE               [12] 1763 	mov	r6,a
      0042F8 74 EF            [12] 1764 	mov	a,#0xef
      0042FA 3D               [12] 1765 	addc	a,r5
      0042FB FD               [12] 1766 	mov	r5,a
      0042FC 8E 82            [24] 1767 	mov	dpl,r6
      0042FE 8D 83            [24] 1768 	mov	dph,r5
      004300 22               [24] 1769 	ret
                                   1770 
                                   1771 	.area CSEG (CODE)
                                   1772 ; function ak820_outline_0066
      004301                       1773 _ak820_outline_0066:
      004301 F0               [24] 1774 	movx	@dptr,a
      004302 8E 82            [24] 1775 	mov	dpl,r6
      004304 8F 83            [24] 1776 	mov	dph,r7
      004306 22               [24] 1777 	ret
                                   1778 
                                   1779 	.area CSEG (CODE)
                                   1780 ; function ak820_outline_0069
      004307                       1781 _ak820_outline_0069:
      004307 8D 82            [24] 1782 	mov	dpl,r5
      004309 8E 83            [24] 1783 	mov	dph,r6
      00430B EC               [12] 1784 	mov	a,r4
      00430C F0               [24] 1785 	movx	@dptr,a
      00430D 22               [24] 1786 	ret
                                   1787 
                                   1788 	.area CSEG (CODE)
                                   1789 ; function ak820_outline_0082
      00430E                       1790 _ak820_outline_0082:
      00430E E0               [24] 1791 	movx	a,@dptr
      00430F FA               [12] 1792 	mov	r2,a
      004310 A3               [24] 1793 	inc	dptr
      004311 E0               [24] 1794 	movx	a,@dptr
      004312 FB               [12] 1795 	mov	r3,a
      004313 22               [24] 1796 	ret
                                   1797 
                                   1798 	.area CSEG (CODE)
                                   1799 ; function ak820_outline_0097
      004314                       1800 _ak820_outline_0097:
      004314 8C 82            [24] 1801 	mov	dpl,r4
      004316 8D 83            [24] 1802 	mov	dph,r5
      004318 E0               [24] 1803 	movx	a,@dptr
      004319 22               [24] 1804 	ret
                                   1805 
                                   1806 	.area CSEG (CODE)
                                   1807 ; function ak820_outline_0098
      00431A                       1808 _ak820_outline_0098:
      00431A E0               [24] 1809 	movx	a,@dptr
      00431B FD               [12] 1810 	mov	r5,a
      00431C A3               [24] 1811 	inc	dptr
      00431D E0               [24] 1812 	movx	a,@dptr
      00431E FE               [12] 1813 	mov	r6,a
      00431F 22               [24] 1814 	ret
                                   1815 
                                   1816 	.area CSEG (CODE)
                                   1817 ; function ak820_outline_0108
      004320                       1818 _ak820_outline_0108:
      004320 EF               [12] 1819 	mov	a,r7
      004321 24 19            [12] 1820 	add	a,#_page_data
      004323 F5 82            [12] 1821 	mov	dpl,a
      004325 E4               [12] 1822 	clr	a
      004326 34 05            [12] 1823 	addc	a,#(_page_data>>8)
      004328 F5 83            [12] 1824 	mov	dph,a
      00432A E0               [24] 1825 	movx	a,@dptr
      00432B 22               [24] 1826 	ret
                                   1827 
                                   1828 	.area CSEG (CODE)
                                   1829 ; function ak820_outline_0119
      00432C                       1830 _ak820_outline_0119:
      00432C 8E 82            [24] 1831 	mov	dpl,r6
      00432E 8F 83            [24] 1832 	mov	dph,r7
      004330 22               [24] 1833 	ret
                                   1834 
                                   1835 	.area CSEG (CODE)
                                   1836 ; function ak820_outline_0135
      004331                       1837 _ak820_outline_0135:
      004331 8A 82            [24] 1838 	mov	dpl,r2
      004333 8B 83            [24] 1839 	mov	dph,r3
      004335 22               [24] 1840 	ret
                                   1841 
                                   1842 	.area CSEG (CODE)
                                   1843 ; function ak820_outline_0136
      004336                       1844 _ak820_outline_0136:
      004336 AE 82            [24] 1845 	mov	r6,dpl
      004338 AF 83            [24] 1846 	mov	r7,dph
      00433A 22               [24] 1847 	ret
                                   1848 
                                   1849 	.area CSEG (CODE)
                                   1850 ; function ak820_outline_0142
      00433B                       1851 _ak820_outline_0142:
      00433B 42 05            [12] 1852 	orl	ar5,a
      00433D EA               [12] 1853 	mov	a,r2
      00433E 42 04            [12] 1854 	orl	ar4,a
      004340 22               [24] 1855 	ret
                                   1856 
                                   1857 	.area CSEG (CODE)
                                   1858 ; function ak820_outline_0150
      004341                       1859 _ak820_outline_0150:
      004341 89 82            [24] 1860 	mov	dpl,r1
      004343 8A 83            [24] 1861 	mov	dph,r2
      004345 22               [24] 1862 	ret
                                   1863 
                                   1864 	.area CSEG (CODE)
                                   1865 ; function ak820_outline_0151
      004346                       1866 _ak820_outline_0151:
      004346 AC 82            [24] 1867 	mov	r4,dpl
      004348 AD 83            [24] 1868 	mov	r5,dph
      00434A 22               [24] 1869 	ret
                                   1870 
                                   1871 	.area CSEG (CODE)
                                   1872 ; function ak820_outline_0159
      00434B                       1873 _ak820_outline_0159:
      00434B 8F 82            [24] 1874 	mov	dpl,r7
      00434D 8E 83            [24] 1875 	mov	dph,r6
      00434F 22               [24] 1876 	ret
                                   1877 
                                   1878 	.area CSEG (CODE)
                                   1879 ; function ak820_outline_0163
      004350                       1880 _ak820_outline_0163:
      004350 2E               [12] 1881 	add	a,r6
      004351 FC               [12] 1882 	mov	r4,a
      004352 E4               [12] 1883 	clr	a
      004353 3F               [12] 1884 	addc	a,r7
      004354 FD               [12] 1885 	mov	r5,a
      004355 22               [24] 1886 	ret
                                   1887 
                                   1888 	.area CSEG (CODE)
                                   1889 ; function ak820_outline_0164
      004356                       1890 _ak820_outline_0164:
      004356 ED               [12] 1891 	mov	a,r5
      004357 F0               [24] 1892 	movx	@dptr,a
      004358 EE               [12] 1893 	mov	a,r6
      004359 A3               [24] 1894 	inc	dptr
      00435A F0               [24] 1895 	movx	@dptr,a
      00435B 22               [24] 1896 	ret
                                   1897 
                                   1898 	.area CSEG (CODE)
                                   1899 ; function ak820_outline_0184
      00435C                       1900 _ak820_outline_0184:
      00435C 8C 82            [24] 1901 	mov	dpl,r4
      00435E 8B 83            [24] 1902 	mov	dph,r3
      004360 22               [24] 1903 	ret
