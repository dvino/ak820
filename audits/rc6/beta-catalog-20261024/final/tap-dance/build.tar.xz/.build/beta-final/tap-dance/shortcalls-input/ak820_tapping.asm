;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (Linux)
;--------------------------------------------------------
	.module ak820_tapping
	
	.optsdcc -mmcs51 --model-large
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _get_repeat_key_count
	.globl _del_owned_mods
	.globl _add_owned_mods
	.globl _send_keyboard_report
	.globl _layer_hold_off
	.globl _layer_hold_on
	.globl _unregister_mods
	.globl _register_mods
	.globl _process_record
	.globl _ADC_START
	.globl _S0_R_FIFO
	.globl _S0_T_FIFO
	.globl _S0_FREE
	.globl _S0_IF_BYTE
	.globl _S0_IF_FIRST
	.globl _S0_IF_OV
	.globl _S0_FST_ACT
	.globl _CP_RL2
	.globl _C_T2
	.globl _TR2
	.globl _EXEN2
	.globl _TCLK
	.globl _RCLK
	.globl _EXF2
	.globl _CAP1F
	.globl _TF2
	.globl _RI
	.globl _TI
	.globl _RB8
	.globl _TB8
	.globl _REN
	.globl _SM2
	.globl _SM1
	.globl _SM0
	.globl _IT0
	.globl _IE0
	.globl _IT1
	.globl _IE1
	.globl _TR0
	.globl _TF0
	.globl _TR1
	.globl _TF1
	.globl _P4_0
	.globl _P4_1
	.globl _P4_2
	.globl _P4_3
	.globl _P4_4
	.globl _P4_5
	.globl _P4_6
	.globl _RXD
	.globl _TXD
	.globl _INT0
	.globl _INT1
	.globl _T0
	.globl _T1
	.globl _MOSI1
	.globl _MISO1
	.globl _SCK1
	.globl _P3_0
	.globl _P3_1
	.globl _P3_2
	.globl _P3_3
	.globl _P3_4
	.globl _P3_5
	.globl _P3_6
	.globl _P3_7
	.globl _CAP1_
	.globl _T2_
	.globl _CAP2_
	.globl _T2EX_
	.globl _RXD1
	.globl _TXD1
	.globl _P2_0
	.globl _P2_1
	.globl _P2_2
	.globl _P2_3
	.globl _P2_4
	.globl _P2_5
	.globl _P2_6
	.globl _P2_7
	.globl _AIN0
	.globl _AIN1
	.globl _AIN2
	.globl _AIN3
	.globl _AIN4
	.globl _AIN5
	.globl _AIN6
	.globl _AIN7
	.globl _CAP1
	.globl _T2
	.globl _CAP2
	.globl _T2EX
	.globl _INT0_
	.globl _SCS
	.globl _MOSI
	.globl _MISO
	.globl _SCK
	.globl _RXD1_
	.globl _TXD1_
	.globl _P1_0
	.globl _P1_1
	.globl _P1_2
	.globl _P1_3
	.globl _P1_4
	.globl _P1_5
	.globl _P1_6
	.globl _P1_7
	.globl _AIN8
	.globl _AIN9
	.globl _AIN10
	.globl _AIN11
	.globl _AIN12
	.globl _AIN13
	.globl _RXD_
	.globl _TXD_
	.globl _SCL0
	.globl _SDA0
	.globl _P0_0
	.globl _P0_1
	.globl _P0_2
	.globl _P0_3
	.globl _P0_4
	.globl _P0_5
	.globl _P0_6
	.globl _P0_7
	.globl _IE_SPI0
	.globl _IE_USB
	.globl _IE_ADC
	.globl _IE_UART1
	.globl _IE_PWM_I2C
	.globl _IE_GPIO
	.globl _IE_WDOG
	.globl _PX0
	.globl _PT0
	.globl _PX1
	.globl _PT1
	.globl _PS
	.globl _PT2
	.globl _PL_FLAG
	.globl _PH_FLAG
	.globl _EX0
	.globl _ET0
	.globl _EX1
	.globl _ET1
	.globl _ES
	.globl _ET2
	.globl _E_DIS
	.globl _EA
	.globl _P
	.globl _F1
	.globl _OV
	.globl _RS0
	.globl _RS1
	.globl _F0
	.globl _AC
	.globl _CY
	.globl _I2CS_INT_ST
	.globl _I2CX_INT
	.globl _LED_STATUS
	.globl _LED_DMA_H
	.globl _LED_DMA_L
	.globl _LED_DMA
	.globl _LED_PWM_OE
	.globl _LED_COMMON
	.globl _ADC_CHAN
	.globl _ADC_DAT_H
	.globl _ADC_DAT_L
	.globl _ADC_DAT
	.globl _ADC_CTRL
	.globl _SPI1_CK_SE
	.globl _SPI1_CTRL
	.globl _SPI1_DATA
	.globl _SPI1_STAT
	.globl _SIF1
	.globl _SBAUD1
	.globl _SBUF1
	.globl _SCON1
	.globl _SPI0_SETUP
	.globl _SPI0_CK_SE
	.globl _SPI0_CTRL
	.globl _SPI0_DATA
	.globl _SPI0_STAT
	.globl _T2CAP1H
	.globl _T2CAP1L
	.globl _T2CAP1
	.globl _TH2
	.globl _TL2
	.globl _T2COUNT
	.globl _RCAP2H
	.globl _RCAP2L
	.globl _RCAP2
	.globl _T2MOD
	.globl _T2CON
	.globl _SBUF
	.globl _SCON
	.globl _TH1
	.globl _TH0
	.globl _TL1
	.globl _TL0
	.globl _TMOD
	.globl _TCON
	.globl _XBUS_AUX
	.globl _P7
	.globl _P6_DIR
	.globl _P6_OUT_PU
	.globl _P6_IN
	.globl _P5_DIR
	.globl _P5_OUT_PU
	.globl _P5_IN
	.globl _P4_LED_KEY
	.globl _P4_DIR_PU
	.globl _P4_MOD_OC
	.globl _P4
	.globl _P3_DIR_PU
	.globl _P3_MOD_OC
	.globl _P3
	.globl _P2_DIR_PU
	.globl _P2_MOD_OC
	.globl _P2
	.globl _P1_DIR_PU
	.globl _P1_MOD_OC
	.globl _P1
	.globl _P0_DIR_PU
	.globl _P0_MOD_OC
	.globl _P0
	.globl _ROM_CTRL
	.globl _ROM_DATA_HH
	.globl _ROM_DATA_HL
	.globl _ROM_DATA_HI
	.globl _ROM_ADDR_H
	.globl _ROM_ADDR_L
	.globl _ROM_ADDR
	.globl _GPIO_IE
	.globl _IP_EX
	.globl _IE_EX
	.globl _IP
	.globl _IE
	.globl _WDOG_COUNT
	.globl _RESET_KEEP
	.globl _WAKE_CTRL
	.globl _CLOCK_CFG
	.globl _POWER_CFG
	.globl _PCON
	.globl _GLOBAL_CFG
	.globl _SAFE_MOD
	.globl _DPH
	.globl _DPL
	.globl _SP
	.globl _A_INV
	.globl _B
	.globl _ACC
	.globl _PSW
	.globl _ak820_oneshot_target
	.globl _ak820_oneshot_process_PARM_3
	.globl _ak820_oneshot_process_PARM_2
	.globl _ak820_oneshot_consumed
	.globl _ak820_oneshot_mods
	.globl _ak820_tapping_source_PARM_1
	.globl _ak820_tapping_source
	.globl _ak820_tapping_before
	.globl _ak820_tapping_process
	.globl _ak820_tapping_cancel
	.globl _ak820_oneshot_process
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
_PSW	=	0x00d0
_ACC	=	0x00e0
_B	=	0x00f0
_A_INV	=	0x00fd
_SP	=	0x0081
_DPL	=	0x0082
_DPH	=	0x0083
_SAFE_MOD	=	0x00a1
_GLOBAL_CFG	=	0x00b1
_PCON	=	0x0087
_POWER_CFG	=	0x00ba
_CLOCK_CFG	=	0x00b9
_WAKE_CTRL	=	0x00a9
_RESET_KEEP	=	0x00fe
_WDOG_COUNT	=	0x00ff
_IE	=	0x00a8
_IP	=	0x00b8
_IE_EX	=	0x00e8
_IP_EX	=	0x00e9
_GPIO_IE	=	0x00b2
_ROM_ADDR	=	0x8584
_ROM_ADDR_L	=	0x0084
_ROM_ADDR_H	=	0x0085
_ROM_DATA_HI	=	0x8f8e
_ROM_DATA_HL	=	0x008e
_ROM_DATA_HH	=	0x008f
_ROM_CTRL	=	0x0086
_P0	=	0x0080
_P0_MOD_OC	=	0x00c4
_P0_DIR_PU	=	0x00c5
_P1	=	0x0090
_P1_MOD_OC	=	0x0092
_P1_DIR_PU	=	0x0093
_P2	=	0x00a0
_P2_MOD_OC	=	0x0094
_P2_DIR_PU	=	0x0095
_P3	=	0x00b0
_P3_MOD_OC	=	0x0096
_P3_DIR_PU	=	0x0097
_P4	=	0x00c0
_P4_MOD_OC	=	0x00c2
_P4_DIR_PU	=	0x00c3
_P4_LED_KEY	=	0x00c1
_P5_IN	=	0x00aa
_P5_OUT_PU	=	0x00ab
_P5_DIR	=	0x00ac
_P6_IN	=	0x00ad
_P6_OUT_PU	=	0x00ae
_P6_DIR	=	0x00af
_P7	=	0x00f1
_XBUS_AUX	=	0x00a2
_TCON	=	0x0088
_TMOD	=	0x0089
_TL0	=	0x008a
_TL1	=	0x008b
_TH0	=	0x008c
_TH1	=	0x008d
_SCON	=	0x0098
_SBUF	=	0x0099
_T2CON	=	0x00c8
_T2MOD	=	0x00c9
_RCAP2	=	0xcbca
_RCAP2L	=	0x00ca
_RCAP2H	=	0x00cb
_T2COUNT	=	0xcdcc
_TL2	=	0x00cc
_TH2	=	0x00cd
_T2CAP1	=	0xcfce
_T2CAP1L	=	0x00ce
_T2CAP1H	=	0x00cf
_SPI0_STAT	=	0x00f8
_SPI0_DATA	=	0x00f9
_SPI0_CTRL	=	0x00fa
_SPI0_CK_SE	=	0x00fb
_SPI0_SETUP	=	0x00fc
_SCON1	=	0x00bc
_SBUF1	=	0x00bd
_SBAUD1	=	0x00be
_SIF1	=	0x00bf
_SPI1_STAT	=	0x00b4
_SPI1_DATA	=	0x00b5
_SPI1_CTRL	=	0x00b6
_SPI1_CK_SE	=	0x00b7
_ADC_CTRL	=	0x00f3
_ADC_DAT	=	0xf5f4
_ADC_DAT_L	=	0x00f4
_ADC_DAT_H	=	0x00f5
_ADC_CHAN	=	0x00f6
_LED_COMMON	=	0x00a6
_LED_PWM_OE	=	0x00a7
_LED_DMA	=	0xc7c6
_LED_DMA_L	=	0x00c6
_LED_DMA_H	=	0x00c7
_LED_STATUS	=	0x00f7
_I2CX_INT	=	0x00b3
_I2CS_INT_ST	=	0x00bb
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
_CY	=	0x00d7
_AC	=	0x00d6
_F0	=	0x00d5
_RS1	=	0x00d4
_RS0	=	0x00d3
_OV	=	0x00d2
_F1	=	0x00d1
_P	=	0x00d0
_EA	=	0x00af
_E_DIS	=	0x00ae
_ET2	=	0x00ad
_ES	=	0x00ac
_ET1	=	0x00ab
_EX1	=	0x00aa
_ET0	=	0x00a9
_EX0	=	0x00a8
_PH_FLAG	=	0x00bf
_PL_FLAG	=	0x00be
_PT2	=	0x00bd
_PS	=	0x00bc
_PT1	=	0x00bb
_PX1	=	0x00ba
_PT0	=	0x00b9
_PX0	=	0x00b8
_IE_WDOG	=	0x00ef
_IE_GPIO	=	0x00ee
_IE_PWM_I2C	=	0x00ed
_IE_UART1	=	0x00ec
_IE_ADC	=	0x00eb
_IE_USB	=	0x00e9
_IE_SPI0	=	0x00e8
_P0_7	=	0x0087
_P0_6	=	0x0086
_P0_5	=	0x0085
_P0_4	=	0x0084
_P0_3	=	0x0083
_P0_2	=	0x0082
_P0_1	=	0x0081
_P0_0	=	0x0080
_SDA0	=	0x0081
_SCL0	=	0x0080
_TXD_	=	0x0083
_RXD_	=	0x0082
_AIN13	=	0x0085
_AIN12	=	0x0084
_AIN11	=	0x0083
_AIN10	=	0x0082
_AIN9	=	0x0081
_AIN8	=	0x0080
_P1_7	=	0x0097
_P1_6	=	0x0096
_P1_5	=	0x0095
_P1_4	=	0x0094
_P1_3	=	0x0093
_P1_2	=	0x0092
_P1_1	=	0x0091
_P1_0	=	0x0090
_TXD1_	=	0x0097
_RXD1_	=	0x0096
_SCK	=	0x0097
_MISO	=	0x0096
_MOSI	=	0x0095
_SCS	=	0x0094
_INT0_	=	0x0092
_T2EX	=	0x0091
_CAP2	=	0x0091
_T2	=	0x0090
_CAP1	=	0x0090
_AIN7	=	0x0097
_AIN6	=	0x0096
_AIN5	=	0x0095
_AIN4	=	0x0094
_AIN3	=	0x0093
_AIN2	=	0x0092
_AIN1	=	0x0091
_AIN0	=	0x0090
_P2_7	=	0x00a7
_P2_6	=	0x00a6
_P2_5	=	0x00a5
_P2_4	=	0x00a4
_P2_3	=	0x00a3
_P2_2	=	0x00a2
_P2_1	=	0x00a1
_P2_0	=	0x00a0
_TXD1	=	0x00a7
_RXD1	=	0x00a6
_T2EX_	=	0x00a5
_CAP2_	=	0x00a5
_T2_	=	0x00a4
_CAP1_	=	0x00a4
_P3_7	=	0x00b7
_P3_6	=	0x00b6
_P3_5	=	0x00b5
_P3_4	=	0x00b4
_P3_3	=	0x00b3
_P3_2	=	0x00b2
_P3_1	=	0x00b1
_P3_0	=	0x00b0
_SCK1	=	0x00b7
_MISO1	=	0x00b6
_MOSI1	=	0x00b5
_T1	=	0x00b5
_T0	=	0x00b4
_INT1	=	0x00b3
_INT0	=	0x00b2
_TXD	=	0x00b1
_RXD	=	0x00b0
_P4_6	=	0x00c6
_P4_5	=	0x00c5
_P4_4	=	0x00c4
_P4_3	=	0x00c3
_P4_2	=	0x00c2
_P4_1	=	0x00c1
_P4_0	=	0x00c0
_TF1	=	0x008f
_TR1	=	0x008e
_TF0	=	0x008d
_TR0	=	0x008c
_IE1	=	0x008b
_IT1	=	0x008a
_IE0	=	0x0089
_IT0	=	0x0088
_SM0	=	0x009f
_SM1	=	0x009e
_SM2	=	0x009d
_REN	=	0x009c
_TB8	=	0x009b
_RB8	=	0x009a
_TI	=	0x0099
_RI	=	0x0098
_TF2	=	0x00cf
_CAP1F	=	0x00cf
_EXF2	=	0x00ce
_RCLK	=	0x00cd
_TCLK	=	0x00cc
_EXEN2	=	0x00cb
_TR2	=	0x00ca
_C_T2	=	0x00c9
_CP_RL2	=	0x00c8
_S0_FST_ACT	=	0x00ff
_S0_IF_OV	=	0x00fe
_S0_IF_FIRST	=	0x00fd
_S0_IF_BYTE	=	0x00fc
_S0_FREE	=	0x00fb
_S0_T_FIFO	=	0x00fa
_S0_R_FIFO	=	0x00f8
_ADC_START	=	0x00f7
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram
;--------------------------------------------------------
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; absolute internal ram data
;--------------------------------------------------------
	.area IABS    (ABS,DATA)
	.area IABS    (ABS,DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
_ak820_tapping_before_sloc0_1_0:
	.ds 1
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; uninitialized external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
_source_state:
	.ds 130
_pending_time:
	.ds 2
_pending_code:
	.ds 2
_ak820_tapping_source_PARM_1:
	.ds 2
_hold_PARM_2:
	.ds 1
_hold_code_10000_603:
	.ds 2
_hold_mods_30000_606:
	.ds 1
_commit_pending_id_10000_612:
	.ds 1
_ak820_tapping_before_event_10000_613:
	.ds 2
_ak820_tapping_process_record_10000_624:
	.ds 2
_ak820_tapping_process_code_10000_625:
	.ds 2
_ak820_tapping_process_sc_mods_10000_625:
	.ds 1
_ak820_oneshot_mods::
	.ds 1
_ak820_oneshot_consumed::
	.ds 1
_ak820_oneshot_process_PARM_2:
	.ds 1
_ak820_oneshot_process_PARM_3:
	.ds 1
_ak820_oneshot_process_code_10000_650:
	.ds 2
_ak820_oneshot_process_mods_10000_651:
	.ds 1
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area XABS    (ABS,XDATA)
;--------------------------------------------------------
; initialized external ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
_pending:
	.ds 1
_ak820_oneshot_target::
	.ds 1
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area HOME    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
;------------------------------------------------------------
;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
;------------------------------------------------------------
;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
;	-----------------------------------------
	ar7 = 0x07
	ar6 = 0x06
	ar5 = 0x05
	ar4 = 0x04
	ar3 = 0x03
	ar2 = 0x02
	ar1 = 0x01
	ar0 = 0x00
;	 function ak820_tapping_source
;	-----------------------------------------
_ak820_tapping_source:
;	keyboards/ajazz/ak820/ak820_tapping.c:40: if (key.row < MATRIX_ROWS && key.col < MATRIX_COLS) return key.row * MATRIX_COLS + key.col;
	mov	dptr,#(_ak820_tapping_source_PARM_1 + 0x0001)
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0x10,00147$
00147$:
	jnc	00102$
	mov	dptr,#_ak820_tapping_source_PARM_1
	movx	a,@dptr
	mov	r6,a
	cjne	r6,#0x08,00149$
00149$:
	jnc	00102$
	mov	ar5,r7
	mov	a,r5
	lcall	_ak820_outline_0161
	add	a,r6
	mov	dpl,a
	ret
00102$:
;	keyboards/ajazz/ak820/ak820_tapping.c:41: if (key.col < NUM_ENCODERS) {
	mov	dptr,#_ak820_tapping_source_PARM_1
	movx	a,@dptr
	mov	r6,a
	cjne	r6,#0x01,00151$
00151$:
	jnc	00109$
;	keyboards/ajazz/ak820/ak820_tapping.c:42: if (key.row == KEYLOC_ENCODER_CW) return MATRIX_ROWS * MATRIX_COLS + key.col;
	cjne	r7,#0xfd,00105$
	mov	dpl, #0x80
	ret
00105$:
;	keyboards/ajazz/ak820/ak820_tapping.c:43: if (key.row == KEYLOC_ENCODER_CCW) return MATRIX_ROWS * MATRIX_COLS + NUM_ENCODERS + key.col;
	cjne	r7,#0xfc,00109$
	mov	dpl, #0x81
	ret
00109$:
;	keyboards/ajazz/ak820/ak820_tapping.c:45: return NONE;
	mov	dpl, #0xff
;	keyboards/ajazz/ak820/ak820_tapping.c:46: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'hold'
;------------------------------------------------------------
;pressed       Allocated with name '_hold_PARM_2'
;code          Allocated with name '_hold_code_10000_603'
;mods          Allocated with name '_hold_mods_30000_606'
;layer         Allocated with name '_hold_layer_30000_609'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_tapping.c:47: static void hold(uint16_t code, bool pressed) {
;	-----------------------------------------
;	 function hold
;	-----------------------------------------
_hold:
	lcall	_ak820_outline_0106
	mov	dptr,#_hold_code_10000_603
	lcall	_ak820_outline_0105
;	keyboards/ajazz/ak820/ak820_tapping.c:48: if (code < QK_LAYER_TAP) {
	mov	dptr,#_hold_code_10000_603
	lcall	_ak820_outline_0010
	mov	a,#0x100 - 0x40
	add	a,r5
	jc	00110$
;	keyboards/ajazz/ak820/ak820_tapping.c:49: uint8_t mods = (code >> 8) & 31;
	mov	ar5,r7
	anl	ar5,#0x1f
	mov	dptr,#_hold_mods_30000_606
	mov	a,r5
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tapping.c:50: if (mods & 16) mods <<= 4;
	mov	a,r5
	jnb	acc.4,00102$
	mov	a,r5
	swap	a
	anl	a,#0xf0
	mov	dptr,#_hold_mods_30000_606
	movx	@dptr,a
00102$:
;	keyboards/ajazz/ak820/ak820_tapping.c:51: if (pressed) register_mods(mods);
	mov	dptr,#_hold_PARM_2
	movx	a,@dptr
	jz	00104$
	mov	dptr,#_hold_mods_30000_606
	movx	a,@dptr
	mov	dpl,a
	ljmp	_register_mods
00104$:
;	keyboards/ajazz/ak820/ak820_tapping.c:52: else unregister_mods(mods);
	mov	dptr,#_hold_mods_30000_606
	movx	a,@dptr
	mov	dpl,a
	ljmp	_unregister_mods
00110$:
;	keyboards/ajazz/ak820/ak820_tapping.c:54: uint8_t layer = (code >> 8) & 15;
	mov	ar6,r7
	mov	a,#0x0f
	anl	a,r6
	mov	r7,a
;	keyboards/ajazz/ak820/ak820_tapping.c:55: if (pressed) layer_hold_on(layer);
	mov	dptr,#_hold_PARM_2
	movx	a,@dptr
	jz	00107$
	mov	dpl, r7
	ljmp	_layer_hold_on
00107$:
;	keyboards/ajazz/ak820/ak820_tapping.c:56: else layer_hold_off(layer);
	mov	dpl, r7
;	keyboards/ajazz/ak820/ak820_tapping.c:58: }
	ljmp	_layer_hold_off
;------------------------------------------------------------
;Allocation info for local variables in function 'commit_pending'
;------------------------------------------------------------
;id            Allocated with name '_commit_pending_id_10000_612'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_tapping.c:59: static void commit_pending(void) {
;	-----------------------------------------
;	 function commit_pending
;	-----------------------------------------
_commit_pending:
;	keyboards/ajazz/ak820/ak820_tapping.c:60: uint8_t id = pending;
	mov	dptr,#_pending
	movx	a,@dptr
	mov	dptr,#_commit_pending_id_10000_612
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tapping.c:61: pending = NONE; /* A report callback cannot resurrect the decision. */
	lcall	_ak820_outline_0156
;	keyboards/ajazz/ak820/ak820_tapping.c:62: source_state[id] |= SOURCE_HELD;
	mov	dptr,#_commit_pending_id_10000_612
	movx	a,@dptr
	add	a,#_source_state
	mov	r7,a
	clr	a
	addc	a, #(_source_state >> 8)
	mov	r6,a
	lcall	_ak820_outline_0159
	movx	a,@dptr
	mov	r5,a
	orl	ar5,#0x04
	lcall	_ak820_outline_0159
	mov	a,r5
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tapping.c:63: hold(pending_code, true);
	mov	dptr,#_pending_code
	lcall	_ak820_outline_0056
	mov	dptr,#_hold_PARM_2
	lcall	_ak820_outline_0060
;	keyboards/ajazz/ak820/ak820_tapping.c:64: }
	ljmp	_hold
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_tapping_before'
;------------------------------------------------------------
;event         Allocated with name '_ak820_tapping_before_event_10000_613'
;id            Allocated with name '_ak820_tapping_before_id_10000_614'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_tapping.c:65: bool ak820_tapping_before(const keyevent_t AK820_STATE_MEM *event) {
;	-----------------------------------------
;	 function ak820_tapping_before
;	-----------------------------------------
_ak820_tapping_before:
	lcall	_ak820_outline_0106
	mov	dptr,#_ak820_tapping_before_event_10000_613
	lcall	_ak820_outline_0105
;	keyboards/ajazz/ak820/ak820_tapping.c:66: uint8_t id = ak820_tapping_source(event->key);
	mov	dptr,#_ak820_tapping_before_event_10000_613
	lcall	_ak820_outline_0010
	lcall	_ak820_outline_0024
	push	ar7
	push	ar6
	lcall	___memcpy
	lcall	_ak820_tapping_source
	mov	r5, dpl
	pop	ar6
	pop	ar7
;	keyboards/ajazz/ak820/ak820_tapping.c:68: if (vial_unlock_in_progress) {
	mov	dptr,#_vial_unlock_in_progress
	movx	a,@dptr
	jz	00106$
;	keyboards/ajazz/ak820/ak820_tapping.c:69: if (IS_EVENT(*event) && id != NONE && !event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
	mov	a,#0x04
	lcall	_ak820_outline_0014
	jz	00102$
	cjne	r5,#0xff,00218$
	sjmp	00102$
00218$:
	mov	a,#0x05
	lcall	_ak820_outline_0014
	jnz	00102$
	mov	a,r5
	add	a, #_source_state
	mov	r3,a
	clr	a
	addc	a, #(_source_state >> 8)
	lcall	_ak820_outline_0049
	anl	ar2,#0xfd
	lcall	_ak820_outline_0124
	mov	a,r2
	movx	@dptr,a
00102$:
;	keyboards/ajazz/ak820/ak820_tapping.c:70: return false;
	mov	dpl, #0x00
	ret
00106$:
;	keyboards/ajazz/ak820/ak820_tapping.c:73: if (pending != NONE && ((uint16_t)(event->time - pending_time) >= AK820_TAPPING_TERM ||
	mov	dptr,#_pending
	movx	a,@dptr
	mov	r4,a
	cjne	r4,#0xff,00220$
	sjmp	00108$
00220$:
	lcall	_ak820_outline_0034
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	mov	dptr,#_pending_time
	lcall	_ak820_outline_0102
	mov	a,r2
	clr	c
	subb	a,r0
	mov	r2,a
	mov	a,r3
	subb	a,r1
	mov	r3,a
	clr	c
	mov	a,r2
	subb	a,#0xc8
	mov	a,r3
	subb	a,#0x00
	jnc	00107$
;	keyboards/ajazz/ak820/ak820_tapping.c:74: (IS_EVENT(*event) && event->pressed && (id == NONE || id != pending)))) commit_pending();
	mov	a,#0x04
	add	a, r6
	lcall	_ak820_outline_0033
	jz	00108$
	lcall	_ak820_outline_0001
	jz	00108$
	cjne	r5,#0xff,00224$
	sjmp	00107$
00224$:
	mov	a,r5
	cjne	a,ar4,00225$
	sjmp	00108$
00225$:
00107$:
	push	ar5
	lcall	_commit_pending
	pop	ar5
00108$:
;	keyboards/ajazz/ak820/ak820_tapping.c:75: if (IS_NOEVENT(*event) || id == NONE) return true;
	mov	dptr,#_ak820_tapping_before_event_10000_613
	lcall	_ak820_outline_0056
	mov	a,#0x04
	lcall	_ak820_outline_0014
	jz	00114$
	cjne	r5,#0xff,00115$
00114$:
	mov	dpl, #0x01
	ret
00115$:
;	keyboards/ajazz/ak820/ak820_tapping.c:76: if ((source_state[id] & SOURCE_BLOCKED)) {
	mov	a,r5
	lcall	_ak820_outline_0083
	jnb	acc.1,00120$
;	keyboards/ajazz/ak820/ak820_tapping.c:77: if (!event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
	mov	a,#0x05
	add	a, r6
	lcall	_ak820_outline_0016
	jnz	00118$
	mov	a,#0xfd
	anl	a,r3
	lcall	_ak820_outline_0123
	movx	@dptr,a
00118$:
;	keyboards/ajazz/ak820/ak820_tapping.c:78: return false;
	mov	dpl, #0x00
	ret
00120$:
;	keyboards/ajazz/ak820/ak820_tapping.c:81: if (event->pressed == ((source_state[id] & SOURCE_ACTIVE) != 0)) return false;
	lcall	_ak820_outline_0013
	movx	a,@dptr
	mov	r7,a
	mov	ar6,r3
	anl	ar6,#0x01
	mov	a,r6
	cjne	a,#0x01,00231$
00231$:
	cpl	c
	mov	_ak820_tapping_before_sloc0_1_0,c
	mov	b,r7
	clr	a
	rlc	a
	cjne	a,b,00122$
	mov	dpl, #0x00
	ret
00122$:
;	keyboards/ajazz/ak820/ak820_tapping.c:82: source_state[id] ^= SOURCE_ACTIVE;
	xrl	ar3,#0x01
	lcall	_ak820_outline_0123
	mov	a,r3
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tapping.c:83: return true;
	mov	dpl, #0x01
;	keyboards/ajazz/ak820/ak820_tapping.c:84: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_tapping_process'
;------------------------------------------------------------
;record        Allocated with name '_ak820_tapping_process_record_10000_624'
;id            Allocated with name '_ak820_tapping_process_id_10000_625'
;kind          Allocated with name '_ak820_tapping_process_kind_10000_625'
;code          Allocated with name '_ak820_tapping_process_code_10000_625'
;sc_mods       Allocated with name '_ak820_tapping_process_sc_mods_10000_625'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_tapping.c:85: bool ak820_tapping_process(keyrecord_t AK820_STATE_MEM *record) {
;	-----------------------------------------
;	 function ak820_tapping_process
;	-----------------------------------------
_ak820_tapping_process:
	lcall	_ak820_outline_0106
	mov	dptr,#_ak820_tapping_process_record_10000_624
	lcall	_ak820_outline_0105
;	keyboards/ajazz/ak820/ak820_tapping.c:89: uint8_t sc_mods = 0;
	mov	dptr,#_ak820_tapping_process_sc_mods_10000_625
	clr	a
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tapping.c:91: if (IS_NOEVENT(record->event)) return true;
	mov	dptr,#_ak820_tapping_process_record_10000_624
	lcall	_ak820_outline_0056
	mov	a,#0x04
	lcall	_ak820_outline_0012
	jnz	00102$
	mov	dpl, #0x01
	ret
00102$:
;	keyboards/ajazz/ak820/ak820_tapping.c:92: id = ak820_tapping_source(record->event.key);
	mov	ar4,r6
	mov	ar5,r7
	lcall	_ak820_outline_0024
	push	ar7
	push	ar6
	lcall	___memcpy
	lcall	_ak820_tapping_source
	mov	r5, dpl
	pop	ar6
	pop	ar7
;	keyboards/ajazz/ak820/ak820_tapping.c:93: if (id == NONE) return true;
	cjne	r5,#0xff,00104$
	mov	dpl, #0x01
	ret
00104$:
;	keyboards/ajazz/ak820/ak820_tapping.c:94: code = record->keycode;
	mov	a,#0x07
	lcall	_ak820_outline_0017
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_ak820_tapping_process_code_10000_625
	lcall	_ak820_outline_0064
;	keyboards/ajazz/ak820/ak820_tapping.c:96: if (code == SC_LSPO) { code = MT(MOD_LSFT, KC_9); sc_mods = MOD_BIT(KC_LEFT_SHIFT); }
	cjne	r6,#0x1a,00111$
	cjne	r7,#0x7c,00111$
	mov	dptr,#_ak820_tapping_process_code_10000_625
	mov	a,#0x26
	movx	@dptr,a
	mov	a,#0x22
	inc	dptr
	movx	@dptr,a
	mov	dptr,#_ak820_tapping_process_sc_mods_10000_625
	mov	a,#0x02
	movx	@dptr,a
	sjmp	00112$
00111$:
;	keyboards/ajazz/ak820/ak820_tapping.c:97: else if (code == SC_RSPC) { code = MT(MOD_RSFT, KC_0); sc_mods = MOD_BIT(KC_RIGHT_SHIFT); }
	cjne	r6,#0x1b,00108$
	cjne	r7,#0x7c,00108$
	mov	dptr,#_ak820_tapping_process_code_10000_625
	mov	a,#0x27
	movx	@dptr,a
	mov	a,#0x32
	inc	dptr
	movx	@dptr,a
	mov	dptr,#_ak820_tapping_process_sc_mods_10000_625
	mov	a,#0x20
	movx	@dptr,a
	sjmp	00112$
00108$:
;	keyboards/ajazz/ak820/ak820_tapping.c:98: else if (code == SC_SENT) code = MT(MOD_RSFT, KC_ENTER);
	cjne	r6,#0x1e,00112$
	cjne	r7,#0x7c,00112$
	mov	dptr,#_ak820_tapping_process_code_10000_625
	mov	a,#0x28
	movx	@dptr,a
	mov	a,#0x32
	inc	dptr
	movx	@dptr,a
00112$:
;	keyboards/ajazz/ak820/ak820_tapping.c:100: kind = code >> 8;
	mov	dptr,#_ak820_tapping_process_code_10000_625
	movx	a,@dptr
	inc	dptr
	movx	a,@dptr
	mov	r7,a
;	keyboards/ajazz/ak820/ak820_tapping.c:101: if (kind < 0x20 || kind >= 0x50) return true;
	cjne	r7,#0x20,00242$
00242$:
	jc	00113$
	cjne	r7,#0x50,00244$
00244$:
	jc	00114$
00113$:
	mov	dpl, #0x01
	ret
00114$:
;	keyboards/ajazz/ak820/ak820_tapping.c:102: if (kind >= 0x40 && (kind & 15) >= MAX_LAYER) return false;
	cjne	r7,#0x40,00246$
00246$:
	jc	00117$
	anl	ar7,#0x0f
	cjne	r7,#0x06,00248$
00248$:
	jc	00117$
	mov	dpl, #0x00
	ret
00117$:
;	keyboards/ajazz/ak820/ak820_tapping.c:103: if (record->event.pressed) {
	mov	dptr,#_ak820_tapping_process_record_10000_624
	lcall	_ak820_outline_0056
	mov	a,#0x05
	lcall	_ak820_outline_0014
	jz	00131$
;	keyboards/ajazz/ak820/ak820_tapping.c:104: pending = id;
	mov	dptr,#_pending
	mov	a,r5
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tapping.c:105: pending_time = record->event.time;
	lcall	_ak820_outline_0034
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_pending_time
	lcall	_ak820_outline_0064
;	keyboards/ajazz/ak820/ak820_tapping.c:106: pending_code = code;
	mov	dptr,#_ak820_tapping_process_code_10000_625
	lcall	_ak820_outline_0056
	mov	dptr,#_pending_code
	lcall	_ak820_outline_0064
	ljmp	00132$
00131$:
;	keyboards/ajazz/ak820/ak820_tapping.c:107: } else if (id == pending) {
	mov	dptr,#_pending
	movx	a,@dptr
	mov	r7,a
	mov	a,r5
	cjne	a,ar7,00251$
	sjmp	00252$
00251$:
	ljmp	00128$
00252$:
;	keyboards/ajazz/ak820/ak820_tapping.c:108: pending = NONE;
	lcall	_ak820_outline_0156
;	keyboards/ajazz/ak820/ak820_tapping.c:110: if (sc_mods) add_owned_mods(sc_mods);
	mov	dptr,#_ak820_tapping_process_sc_mods_10000_625
	movx	a,@dptr
	mov	r7,a
	movx	a,@dptr
	jz	00120$
	mov	dpl, r7
	lcall	_add_owned_mods
00120$:
;	keyboards/ajazz/ak820/ak820_tapping.c:114: record->keycode = (uint8_t)code;
	mov	dptr,#_ak820_tapping_process_record_10000_624
	lcall	_ak820_outline_0056
	mov	a,#0x07
	add	a, r6
	mov	r3,a
	clr	a
	addc	a, r7
	mov	r4,a
	mov	dptr,#_ak820_tapping_process_code_10000_625
	movx	a,@dptr
	mov	r1,a
	mov	r2,#0x00
	lcall	_ak820_outline_0124
	mov	a,r1
	movx	@dptr,a
	mov	a,r2
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tapping.c:115: if (record->keycode > KC_TRANSPARENT) {
	clr	c
	inc	a
	subb	a,r1
	jnc	00122$
;	free result
;	keyboards/ajazz/ak820/ak820_tapping.c:116: record->tap.count = 1;
	mov	a,#0x06
	lcall	_ak820_outline_0017
	anl	a,#0x0f
	orl	a,#0x10
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tapping.c:117: record->event.pressed = true;
	lcall	_ak820_outline_0013
	lcall	_ak820_outline_0060
;	keyboards/ajazz/ak820/ak820_tapping.c:118: process_record(record);
	lcall	_process_record
;	keyboards/ajazz/ak820/ak820_tapping.c:119: record->event.pressed = false;
	mov	dptr,#_ak820_tapping_process_record_10000_624
	lcall	_ak820_outline_0005
	inc	dptr
	inc	dptr
	inc	dptr
	inc	dptr
	inc	dptr
	clr	a
	lcall	_ak820_outline_0066
;	keyboards/ajazz/ak820/ak820_tapping.c:120: process_record(record);
	lcall	_process_record
00122$:
;	keyboards/ajazz/ak820/ak820_tapping.c:123: if (sc_mods) {
	mov	dptr,#_ak820_tapping_process_sc_mods_10000_625
	movx	a,@dptr
	mov	r7,a
	movx	a,@dptr
	jz	00132$
;	keyboards/ajazz/ak820/ak820_tapping.c:124: del_owned_mods(sc_mods);
	mov	dpl, r7
	lcall	_del_owned_mods
;	keyboards/ajazz/ak820/ak820_tapping.c:125: send_keyboard_report();
	lcall	_send_keyboard_report
	sjmp	00132$
00128$:
;	keyboards/ajazz/ak820/ak820_tapping.c:128: } else if ((source_state[id] & SOURCE_HELD)) {
	mov	a,r5
	add	a, #_source_state
	mov	r6,a
	clr	a
	addc	a, #(_source_state >> 8)
	mov	r7,a
	lcall	_ak820_outline_0088
	mov	r5,a
	jnb	acc.2,00132$
;	keyboards/ajazz/ak820/ak820_tapping.c:129: source_state[id] &= ~SOURCE_HELD;
	anl	ar5,#0xfb
	lcall	_ak820_outline_0119
	mov	a,r5
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tapping.c:130: hold(code, false);
	mov	dptr,#_ak820_tapping_process_code_10000_625
	lcall	_ak820_outline_0056
	mov	dptr,#_hold_PARM_2
	clr	a
	lcall	_ak820_outline_0066
	lcall	_hold
00132$:
;	keyboards/ajazz/ak820/ak820_tapping.c:132: return false;
	mov	dpl, #0x00
;	keyboards/ajazz/ak820/ak820_tapping.c:133: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_tapping_cancel'
;------------------------------------------------------------
;i             Allocated with name '_ak820_tapping_cancel_i_20000_648'
;state         Allocated with name '_ak820_tapping_cancel_state_30000_649'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_tapping.c:134: void ak820_tapping_cancel(void) {
;	-----------------------------------------
;	 function ak820_tapping_cancel
;	-----------------------------------------
_ak820_tapping_cancel:
;	keyboards/ajazz/ak820/ak820_tapping.c:135: pending = NONE;
	lcall	_ak820_outline_0156
;	keyboards/ajazz/ak820/ak820_tapping.c:136: for (uint8_t i = 0; i < SOURCES; ++i) {
	mov	r7,#0x00
00103$:
	cjne	r7,#0x82,00122$
00122$:
	jnc	00105$
;	keyboards/ajazz/ak820/ak820_tapping.c:137: uint8_t state = source_state[i];
	lcall	_ak820_outline_0020
;	keyboards/ajazz/ak820/ak820_tapping.c:138: source_state[i] = (state & SOURCE_BLOCKED) | ((state & SOURCE_ACTIVE) << 1);
	mov	a,#0x02
	anl	a,r4
	mov	r3,a
	anl	ar4,#0x01
	mov	a,r4
	add	a,r4
	orl	ar3,a
	lcall	_ak820_outline_0137
	mov	a,r3
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tapping.c:136: for (uint8_t i = 0; i < SOURCES; ++i) {
	inc	r7
	sjmp	00103$
00105$:
;	keyboards/ajazz/ak820/ak820_tapping.c:140: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_oneshot_process'
;------------------------------------------------------------
;id            Allocated with name '_ak820_oneshot_process_PARM_2'
;pressed       Allocated with name '_ak820_oneshot_process_PARM_3'
;code          Allocated with name '_ak820_oneshot_process_code_10000_650'
;mods          Allocated with name '_ak820_oneshot_process_mods_10000_651'
;i             Allocated with name '_ak820_oneshot_process_i_40000_665'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_tapping.c:149: bool ak820_oneshot_process(uint16_t code, uint8_t id, bool pressed) {
;	-----------------------------------------
;	 function ak820_oneshot_process
;	-----------------------------------------
_ak820_oneshot_process:
	lcall	_ak820_outline_0106
	mov	dptr,#_ak820_oneshot_process_code_10000_650
	lcall	_ak820_outline_0105
;	keyboards/ajazz/ak820/ak820_tapping.c:151: if (id == NONE || get_repeat_key_count()) return true;
	mov	dptr,#_ak820_oneshot_process_PARM_2
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0xff,00248$
	sjmp	00101$
00248$:
	lcall	_get_repeat_key_count
	mov	a, dpl
	jz	00102$
00101$:
	mov	dpl, #0x01
	ret
00102$:
;	keyboards/ajazz/ak820/ak820_tapping.c:164: if ((code >> 8) == 0x52 && ((uint8_t)code & 0xe0) == 0xa0) {
	mov	dptr,#_ak820_oneshot_process_code_10000_650
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	cjne	r3,#0x52,00250$
	sjmp	00251$
00250$:
	ljmp	00116$
00251$:
	mov	ar4,r5
	anl	ar4,#0xe0
	cjne	r4,#0xa0,00252$
	sjmp	00253$
00252$:
	ljmp	00116$
00253$:
;	keyboards/ajazz/ak820/ak820_tapping.c:165: mods = code & 15;
	mov	ar4,r5
	anl	ar4,#0x0f
	mov	dptr,#_ak820_oneshot_process_mods_10000_651
	mov	a,r4
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tapping.c:166: if (code & 16) mods <<= 4;
	mov	a,r5
	jnb	acc.4,00105$
	mov	a,r4
	swap	a
	anl	a,#0xf0
	mov	dptr,#_ak820_oneshot_process_mods_10000_651
	movx	@dptr,a
00105$:
;	keyboards/ajazz/ak820/ak820_tapping.c:167: if (pressed) {
	mov	dptr,#_ak820_oneshot_process_PARM_3
	movx	a,@dptr
	jz	00113$
;	keyboards/ajazz/ak820/ak820_tapping.c:168: source_state[id] |= SOURCE_ONESHOT;
	lcall	_ak820_outline_0020
	orl	ar4,#0x08
	lcall	_ak820_outline_0069
;	keyboards/ajazz/ak820/ak820_tapping.c:169: source_state[id] &= ~SOURCE_ONESHOT_USED;
	anl	ar4,#0xef
	lcall	_ak820_outline_0069
;	keyboards/ajazz/ak820/ak820_tapping.c:170: if (ak820_oneshot_target != NONE) source_state[id] |= SOURCE_ONESHOT_USED;
	mov	dptr,#_ak820_oneshot_target
	movx	a,@dptr
	mov	r4,a
	cjne	r4,#0xff,00256$
	sjmp	00107$
00256$:
	lcall	_ak820_outline_0078
	orl	ar4,#0x10
	lcall	_ak820_outline_0069
00107$:
;	keyboards/ajazz/ak820/ak820_tapping.c:171: register_mods(mods);
	mov	dptr,#_ak820_oneshot_process_mods_10000_651
	movx	a,@dptr
	mov	dpl,a
	lcall	_register_mods
	sjmp	00114$
00113$:
;	keyboards/ajazz/ak820/ak820_tapping.c:172: } else if (source_state[id] & SOURCE_ONESHOT) {
	lcall	_ak820_outline_0020
	jnb	acc.3,00114$
;	keyboards/ajazz/ak820/ak820_tapping.c:173: if (!(source_state[id] & SOURCE_ONESHOT_USED)) {
	mov	a,r4
	jb	acc.4,00109$
;	keyboards/ajazz/ak820/ak820_tapping.c:174: add_owned_mods(mods & ~ak820_oneshot_mods);
	mov	dptr,#_ak820_oneshot_mods
	movx	a,@dptr
	cpl	a
	mov	r4,a
	mov	dptr,#_ak820_oneshot_process_mods_10000_651
	movx	a,@dptr
	mov	r3,a
	anl	ar4,a
	mov	dpl, r4
	push	ar6
	push	ar5
	push	ar3
	lcall	_add_owned_mods
	pop	ar3
	pop	ar5
	pop	ar6
;	keyboards/ajazz/ak820/ak820_tapping.c:175: ak820_oneshot_mods |= mods;
	mov	dptr,#_ak820_oneshot_mods
	movx	a,@dptr
	orl	a,r3
	movx	@dptr,a
00109$:
;	keyboards/ajazz/ak820/ak820_tapping.c:177: unregister_mods(mods);
	mov	dptr,#_ak820_oneshot_process_mods_10000_651
	movx	a,@dptr
	mov	dpl,a
	push	ar6
	push	ar5
	lcall	_unregister_mods
	pop	ar5
	pop	ar6
;	keyboards/ajazz/ak820/ak820_tapping.c:178: source_state[id] &= ~(SOURCE_ONESHOT | SOURCE_ONESHOT_USED);
	lcall	_ak820_outline_0078
	anl	ar4,#0xe7
	lcall	_ak820_outline_0069
00114$:
;	keyboards/ajazz/ak820/ak820_tapping.c:180: return false;
	mov	dpl, #0x00
	ret
00116$:
;	keyboards/ajazz/ak820/ak820_tapping.c:182: if (pressed && code > KC_TRANSPARENT &&
	mov	dptr,#_ak820_oneshot_process_PARM_3
	movx	a,@dptr
	jz	00124$
	mov	dptr,#_ak820_oneshot_process_code_10000_650
	lcall	_ak820_outline_0098
	clr	c
	mov	a,#0x01
	subb	a,r5
	clr	a
	subb	a,r6
	jnc	00124$
;	free result
;	keyboards/ajazz/ak820/ak820_tapping.c:183: !(code >= KC_LCTL && code <= KC_RGUI) &&
	clr	c
	mov	a,r5
	subb	a,#0xe0
	mov	a,r6
	subb	a,#0x00
	jc	00129$
	mov	a,#0xe7
	subb	a,r5
	clr	a
	subb	a,r6
	jnc	00124$
;	free result
00129$:
;	keyboards/ajazz/ak820/ak820_tapping.c:184: !(code >= QK_TO && code <= QK_LAYER_TAP_TOGGLE_MAX)) {
	mov	a,#0x100 - 0x52
	add	a,r6
	jnc	00165$
	clr	c
	mov	a,#0xdf
	subb	a,r5
	mov	a,#0x52
	subb	a,r6
	jnc	00124$
;	free result
;	keyboards/ajazz/ak820/ak820_tapping.c:185: for (uint8_t i = 0; i < SOURCES; ++i)
00165$:
	mov	r6,#0x00
00131$:
	cjne	r6,#0x82,00265$
00265$:
	jnc	00120$
;	keyboards/ajazz/ak820/ak820_tapping.c:186: if (source_state[i] & SOURCE_ONESHOT) source_state[i] |= SOURCE_ONESHOT_USED;
	mov	a,r6
	lcall	_ak820_outline_0083
	jnb	acc.3,00132$
	orl	ar3,#0x10
	lcall	_ak820_outline_0123
	mov	a,r3
	movx	@dptr,a
00132$:
;	keyboards/ajazz/ak820/ak820_tapping.c:185: for (uint8_t i = 0; i < SOURCES; ++i)
	inc	r6
	sjmp	00131$
00120$:
;	keyboards/ajazz/ak820/ak820_tapping.c:187: if (ak820_oneshot_mods) {
	mov	dptr,#_ak820_oneshot_mods
	movx	a,@dptr
	mov	r6,a
	movx	a,@dptr
	jz	00124$
;	keyboards/ajazz/ak820/ak820_tapping.c:188: ak820_oneshot_consumed = ak820_oneshot_mods;
	mov	dptr,#_ak820_oneshot_consumed
	mov	a,r6
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tapping.c:189: ak820_oneshot_target = id;
	mov	dptr,#_ak820_oneshot_target
	mov	a,r7
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tapping.c:190: ak820_oneshot_mods = 0;
	mov	dptr,#_ak820_oneshot_mods
	clr	a
	movx	@dptr,a
00124$:
;	keyboards/ajazz/ak820/ak820_tapping.c:193: return true;
	mov	dpl, #0x01
;	keyboards/ajazz/ak820/ak820_tapping.c:194: }
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
__xinit__pending:
	.db #0xff	; 255
__xinit__ak820_oneshot_target:
	.db #0xff	; 255
	.area CABS    (ABS,CODE)

; Experimental exact instruction outlining.
	.globl _ak820_outline_0001
	.globl _ak820_outline_0005
	.globl _ak820_outline_0010
	.globl _ak820_outline_0012
	.globl _ak820_outline_0013
	.globl _ak820_outline_0014
	.globl _ak820_outline_0016
	.globl _ak820_outline_0017
	.globl _ak820_outline_0020
	.globl _ak820_outline_0024
	.globl _ak820_outline_0033
	.globl _ak820_outline_0034
	.globl _ak820_outline_0049
	.globl _ak820_outline_0056
	.globl _ak820_outline_0060
	.globl _ak820_outline_0064
	.globl _ak820_outline_0066
	.globl _ak820_outline_0069
	.globl _ak820_outline_0078
	.globl _ak820_outline_0083
	.globl _ak820_outline_0088
	.globl _ak820_outline_0098
	.globl _ak820_outline_0102
	.globl _ak820_outline_0105
	.globl _ak820_outline_0106
	.globl _ak820_outline_0119
	.globl _ak820_outline_0123
	.globl _ak820_outline_0124
	.globl _ak820_outline_0137
	.globl _ak820_outline_0156
	.globl _ak820_outline_0159
	.globl _ak820_outline_0161

	.area CSEG (CODE)
; function ak820_outline_0014
_ak820_outline_0014:
	add	a,r6
	mov	r3,a
	clr	a
	addc	a,r7
	mov	r4,a
	mov	dpl,r3
	mov	dph,r4
	movx	a,@dptr
	ret

	.area CSEG (CODE)
; function ak820_outline_0020
_ak820_outline_0020:
	mov	a,r7
	add	a,#_source_state
	mov	r5,a
	clr	a
	addc	a,#(_source_state>>8)
	mov	r6,a
	mov	dpl,r5
	mov	dph,r6
	movx	a,@dptr
	mov	r4,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0024
_ak820_outline_0024:
	mov	dptr,#___memcpy_PARM_2
	mov	a,r4
	movx	@dptr,a
	mov	a,r5
	inc	dptr
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	mov	dptr,#___memcpy_PARM_3
	mov	a,#0x02
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	mov	dptr,#_ak820_tapping_source_PARM_1
	mov	b,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0060
_ak820_outline_0060:
	mov	a,#0x01
	movx	@dptr,a
	mov	dpl,r6
	mov	dph,r7
	ret

	.area CSEG (CODE)
; function ak820_outline_0078
_ak820_outline_0078:
	mov	dpl,r5
	mov	dph,r6
	movx	a,@dptr
	mov	r4,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0083
_ak820_outline_0083:
	add	a,#_source_state
	mov	r4,a
	clr	a
	addc	a,#(_source_state>>8)
	mov	r5,a
	mov	dpl,r4
	mov	dph,r5
	movx	a,@dptr
	mov	r3,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0156
_ak820_outline_0156:
	mov	dptr,#_pending
	mov	a,#0xff
	movx	@dptr,a
	ret
