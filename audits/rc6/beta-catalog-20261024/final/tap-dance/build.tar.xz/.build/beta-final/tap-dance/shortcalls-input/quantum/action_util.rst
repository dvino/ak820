                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action_util
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _host_consumer_send
                                     12 	.globl _host_system_send
                                     13 	.globl _host_keyboard_send
                                     14 	.globl _clear_keys_from_report
                                     15 	.globl _del_key_from_report
                                     16 	.globl _add_key_to_report
                                     17 	.globl _KEYCODE2CONSUMER
                                     18 	.globl _ADC_START
                                     19 	.globl _S0_R_FIFO
                                     20 	.globl _S0_T_FIFO
                                     21 	.globl _S0_FREE
                                     22 	.globl _S0_IF_BYTE
                                     23 	.globl _S0_IF_FIRST
                                     24 	.globl _S0_IF_OV
                                     25 	.globl _S0_FST_ACT
                                     26 	.globl _CP_RL2
                                     27 	.globl _C_T2
                                     28 	.globl _TR2
                                     29 	.globl _EXEN2
                                     30 	.globl _TCLK
                                     31 	.globl _RCLK
                                     32 	.globl _EXF2
                                     33 	.globl _CAP1F
                                     34 	.globl _TF2
                                     35 	.globl _RI
                                     36 	.globl _TI
                                     37 	.globl _RB8
                                     38 	.globl _TB8
                                     39 	.globl _REN
                                     40 	.globl _SM2
                                     41 	.globl _SM1
                                     42 	.globl _SM0
                                     43 	.globl _IT0
                                     44 	.globl _IE0
                                     45 	.globl _IT1
                                     46 	.globl _IE1
                                     47 	.globl _TR0
                                     48 	.globl _TF0
                                     49 	.globl _TR1
                                     50 	.globl _TF1
                                     51 	.globl _P4_0
                                     52 	.globl _P4_1
                                     53 	.globl _P4_2
                                     54 	.globl _P4_3
                                     55 	.globl _P4_4
                                     56 	.globl _P4_5
                                     57 	.globl _P4_6
                                     58 	.globl _RXD
                                     59 	.globl _TXD
                                     60 	.globl _INT0
                                     61 	.globl _INT1
                                     62 	.globl _T0
                                     63 	.globl _T1
                                     64 	.globl _MOSI1
                                     65 	.globl _MISO1
                                     66 	.globl _SCK1
                                     67 	.globl _P3_0
                                     68 	.globl _P3_1
                                     69 	.globl _P3_2
                                     70 	.globl _P3_3
                                     71 	.globl _P3_4
                                     72 	.globl _P3_5
                                     73 	.globl _P3_6
                                     74 	.globl _P3_7
                                     75 	.globl _CAP1_
                                     76 	.globl _T2_
                                     77 	.globl _CAP2_
                                     78 	.globl _T2EX_
                                     79 	.globl _RXD1
                                     80 	.globl _TXD1
                                     81 	.globl _P2_0
                                     82 	.globl _P2_1
                                     83 	.globl _P2_2
                                     84 	.globl _P2_3
                                     85 	.globl _P2_4
                                     86 	.globl _P2_5
                                     87 	.globl _P2_6
                                     88 	.globl _P2_7
                                     89 	.globl _AIN0
                                     90 	.globl _AIN1
                                     91 	.globl _AIN2
                                     92 	.globl _AIN3
                                     93 	.globl _AIN4
                                     94 	.globl _AIN5
                                     95 	.globl _AIN6
                                     96 	.globl _AIN7
                                     97 	.globl _CAP1
                                     98 	.globl _T2
                                     99 	.globl _CAP2
                                    100 	.globl _T2EX
                                    101 	.globl _INT0_
                                    102 	.globl _SCS
                                    103 	.globl _MOSI
                                    104 	.globl _MISO
                                    105 	.globl _SCK
                                    106 	.globl _RXD1_
                                    107 	.globl _TXD1_
                                    108 	.globl _P1_0
                                    109 	.globl _P1_1
                                    110 	.globl _P1_2
                                    111 	.globl _P1_3
                                    112 	.globl _P1_4
                                    113 	.globl _P1_5
                                    114 	.globl _P1_6
                                    115 	.globl _P1_7
                                    116 	.globl _AIN8
                                    117 	.globl _AIN9
                                    118 	.globl _AIN10
                                    119 	.globl _AIN11
                                    120 	.globl _AIN12
                                    121 	.globl _AIN13
                                    122 	.globl _RXD_
                                    123 	.globl _TXD_
                                    124 	.globl _SCL0
                                    125 	.globl _SDA0
                                    126 	.globl _P0_0
                                    127 	.globl _P0_1
                                    128 	.globl _P0_2
                                    129 	.globl _P0_3
                                    130 	.globl _P0_4
                                    131 	.globl _P0_5
                                    132 	.globl _P0_6
                                    133 	.globl _P0_7
                                    134 	.globl _IE_SPI0
                                    135 	.globl _IE_USB
                                    136 	.globl _IE_ADC
                                    137 	.globl _IE_UART1
                                    138 	.globl _IE_PWM_I2C
                                    139 	.globl _IE_GPIO
                                    140 	.globl _IE_WDOG
                                    141 	.globl _PX0
                                    142 	.globl _PT0
                                    143 	.globl _PX1
                                    144 	.globl _PT1
                                    145 	.globl _PS
                                    146 	.globl _PT2
                                    147 	.globl _PL_FLAG
                                    148 	.globl _PH_FLAG
                                    149 	.globl _EX0
                                    150 	.globl _ET0
                                    151 	.globl _EX1
                                    152 	.globl _ET1
                                    153 	.globl _ES
                                    154 	.globl _ET2
                                    155 	.globl _E_DIS
                                    156 	.globl _EA
                                    157 	.globl _P
                                    158 	.globl _F1
                                    159 	.globl _OV
                                    160 	.globl _RS0
                                    161 	.globl _RS1
                                    162 	.globl _F0
                                    163 	.globl _AC
                                    164 	.globl _CY
                                    165 	.globl _I2CS_INT_ST
                                    166 	.globl _I2CX_INT
                                    167 	.globl _LED_STATUS
                                    168 	.globl _LED_DMA_H
                                    169 	.globl _LED_DMA_L
                                    170 	.globl _LED_DMA
                                    171 	.globl _LED_PWM_OE
                                    172 	.globl _LED_COMMON
                                    173 	.globl _ADC_CHAN
                                    174 	.globl _ADC_DAT_H
                                    175 	.globl _ADC_DAT_L
                                    176 	.globl _ADC_DAT
                                    177 	.globl _ADC_CTRL
                                    178 	.globl _SPI1_CK_SE
                                    179 	.globl _SPI1_CTRL
                                    180 	.globl _SPI1_DATA
                                    181 	.globl _SPI1_STAT
                                    182 	.globl _SIF1
                                    183 	.globl _SBAUD1
                                    184 	.globl _SBUF1
                                    185 	.globl _SCON1
                                    186 	.globl _SPI0_SETUP
                                    187 	.globl _SPI0_CK_SE
                                    188 	.globl _SPI0_CTRL
                                    189 	.globl _SPI0_DATA
                                    190 	.globl _SPI0_STAT
                                    191 	.globl _T2CAP1H
                                    192 	.globl _T2CAP1L
                                    193 	.globl _T2CAP1
                                    194 	.globl _TH2
                                    195 	.globl _TL2
                                    196 	.globl _T2COUNT
                                    197 	.globl _RCAP2H
                                    198 	.globl _RCAP2L
                                    199 	.globl _RCAP2
                                    200 	.globl _T2MOD
                                    201 	.globl _T2CON
                                    202 	.globl _SBUF
                                    203 	.globl _SCON
                                    204 	.globl _TH1
                                    205 	.globl _TH0
                                    206 	.globl _TL1
                                    207 	.globl _TL0
                                    208 	.globl _TMOD
                                    209 	.globl _TCON
                                    210 	.globl _XBUS_AUX
                                    211 	.globl _P7
                                    212 	.globl _P6_DIR
                                    213 	.globl _P6_OUT_PU
                                    214 	.globl _P6_IN
                                    215 	.globl _P5_DIR
                                    216 	.globl _P5_OUT_PU
                                    217 	.globl _P5_IN
                                    218 	.globl _P4_LED_KEY
                                    219 	.globl _P4_DIR_PU
                                    220 	.globl _P4_MOD_OC
                                    221 	.globl _P4
                                    222 	.globl _P3_DIR_PU
                                    223 	.globl _P3_MOD_OC
                                    224 	.globl _P3
                                    225 	.globl _P2_DIR_PU
                                    226 	.globl _P2_MOD_OC
                                    227 	.globl _P2
                                    228 	.globl _P1_DIR_PU
                                    229 	.globl _P1_MOD_OC
                                    230 	.globl _P1
                                    231 	.globl _P0_DIR_PU
                                    232 	.globl _P0_MOD_OC
                                    233 	.globl _P0
                                    234 	.globl _ROM_CTRL
                                    235 	.globl _ROM_DATA_HH
                                    236 	.globl _ROM_DATA_HL
                                    237 	.globl _ROM_DATA_HI
                                    238 	.globl _ROM_ADDR_H
                                    239 	.globl _ROM_ADDR_L
                                    240 	.globl _ROM_ADDR
                                    241 	.globl _GPIO_IE
                                    242 	.globl _IP_EX
                                    243 	.globl _IE_EX
                                    244 	.globl _IP
                                    245 	.globl _IE
                                    246 	.globl _WDOG_COUNT
                                    247 	.globl _RESET_KEEP
                                    248 	.globl _WAKE_CTRL
                                    249 	.globl _CLOCK_CFG
                                    250 	.globl _POWER_CFG
                                    251 	.globl _PCON
                                    252 	.globl _GLOBAL_CFG
                                    253 	.globl _SAFE_MOD
                                    254 	.globl _DPH
                                    255 	.globl _DPL
                                    256 	.globl _SP
                                    257 	.globl _A_INV
                                    258 	.globl _B
                                    259 	.globl _ACC
                                    260 	.globl _PSW
                                    261 	.globl _actual_keyboard_report
                                    262 	.globl _owned_usage_key_PARM_2
                                    263 	.globl _ak820_macro_change_PARM_3
                                    264 	.globl _ak820_macro_change_PARM_2
                                    265 	.globl _ak820_macro_cancelled
                                    266 	.globl _ak820_macro_primitive
                                    267 	.globl _ak820_macro_change
                                    268 	.globl _add_owned_mods
                                    269 	.globl _del_owned_mods
                                    270 	.globl _add_owned_weak_mods
                                    271 	.globl _del_owned_weak_mods
                                    272 	.globl _clear_owned_mods
                                    273 	.globl _clear_owned_keys
                                    274 	.globl _add_owned_key
                                    275 	.globl _del_owned_key
                                    276 	.globl _clear_owned_usages
                                    277 	.globl _owned_usage_key
                                    278 	.globl _send_keyboard_report
                                    279 	.globl _get_mods
                                    280 	.globl _clear_mods
                                    281 	.globl _get_weak_mods
                                    282 	.globl _add_weak_mods
                                    283 	.globl _del_weak_mods
                                    284 	.globl _clear_weak_mods
                                    285 ;--------------------------------------------------------
                                    286 ; special function registers
                                    287 ;--------------------------------------------------------
                                    288 	.area RSEG    (ABS,DATA)
      000000                        289 	.org 0x0000
                           0000D0   290 _PSW	=	0x00d0
                           0000E0   291 _ACC	=	0x00e0
                           0000F0   292 _B	=	0x00f0
                           0000FD   293 _A_INV	=	0x00fd
                           000081   294 _SP	=	0x0081
                           000082   295 _DPL	=	0x0082
                           000083   296 _DPH	=	0x0083
                           0000A1   297 _SAFE_MOD	=	0x00a1
                           0000B1   298 _GLOBAL_CFG	=	0x00b1
                           000087   299 _PCON	=	0x0087
                           0000BA   300 _POWER_CFG	=	0x00ba
                           0000B9   301 _CLOCK_CFG	=	0x00b9
                           0000A9   302 _WAKE_CTRL	=	0x00a9
                           0000FE   303 _RESET_KEEP	=	0x00fe
                           0000FF   304 _WDOG_COUNT	=	0x00ff
                           0000A8   305 _IE	=	0x00a8
                           0000B8   306 _IP	=	0x00b8
                           0000E8   307 _IE_EX	=	0x00e8
                           0000E9   308 _IP_EX	=	0x00e9
                           0000B2   309 _GPIO_IE	=	0x00b2
                           008584   310 _ROM_ADDR	=	0x8584
                           000084   311 _ROM_ADDR_L	=	0x0084
                           000085   312 _ROM_ADDR_H	=	0x0085
                           008F8E   313 _ROM_DATA_HI	=	0x8f8e
                           00008E   314 _ROM_DATA_HL	=	0x008e
                           00008F   315 _ROM_DATA_HH	=	0x008f
                           000086   316 _ROM_CTRL	=	0x0086
                           000080   317 _P0	=	0x0080
                           0000C4   318 _P0_MOD_OC	=	0x00c4
                           0000C5   319 _P0_DIR_PU	=	0x00c5
                           000090   320 _P1	=	0x0090
                           000092   321 _P1_MOD_OC	=	0x0092
                           000093   322 _P1_DIR_PU	=	0x0093
                           0000A0   323 _P2	=	0x00a0
                           000094   324 _P2_MOD_OC	=	0x0094
                           000095   325 _P2_DIR_PU	=	0x0095
                           0000B0   326 _P3	=	0x00b0
                           000096   327 _P3_MOD_OC	=	0x0096
                           000097   328 _P3_DIR_PU	=	0x0097
                           0000C0   329 _P4	=	0x00c0
                           0000C2   330 _P4_MOD_OC	=	0x00c2
                           0000C3   331 _P4_DIR_PU	=	0x00c3
                           0000C1   332 _P4_LED_KEY	=	0x00c1
                           0000AA   333 _P5_IN	=	0x00aa
                           0000AB   334 _P5_OUT_PU	=	0x00ab
                           0000AC   335 _P5_DIR	=	0x00ac
                           0000AD   336 _P6_IN	=	0x00ad
                           0000AE   337 _P6_OUT_PU	=	0x00ae
                           0000AF   338 _P6_DIR	=	0x00af
                           0000F1   339 _P7	=	0x00f1
                           0000A2   340 _XBUS_AUX	=	0x00a2
                           000088   341 _TCON	=	0x0088
                           000089   342 _TMOD	=	0x0089
                           00008A   343 _TL0	=	0x008a
                           00008B   344 _TL1	=	0x008b
                           00008C   345 _TH0	=	0x008c
                           00008D   346 _TH1	=	0x008d
                           000098   347 _SCON	=	0x0098
                           000099   348 _SBUF	=	0x0099
                           0000C8   349 _T2CON	=	0x00c8
                           0000C9   350 _T2MOD	=	0x00c9
                           00CBCA   351 _RCAP2	=	0xcbca
                           0000CA   352 _RCAP2L	=	0x00ca
                           0000CB   353 _RCAP2H	=	0x00cb
                           00CDCC   354 _T2COUNT	=	0xcdcc
                           0000CC   355 _TL2	=	0x00cc
                           0000CD   356 _TH2	=	0x00cd
                           00CFCE   357 _T2CAP1	=	0xcfce
                           0000CE   358 _T2CAP1L	=	0x00ce
                           0000CF   359 _T2CAP1H	=	0x00cf
                           0000F8   360 _SPI0_STAT	=	0x00f8
                           0000F9   361 _SPI0_DATA	=	0x00f9
                           0000FA   362 _SPI0_CTRL	=	0x00fa
                           0000FB   363 _SPI0_CK_SE	=	0x00fb
                           0000FC   364 _SPI0_SETUP	=	0x00fc
                           0000BC   365 _SCON1	=	0x00bc
                           0000BD   366 _SBUF1	=	0x00bd
                           0000BE   367 _SBAUD1	=	0x00be
                           0000BF   368 _SIF1	=	0x00bf
                           0000B4   369 _SPI1_STAT	=	0x00b4
                           0000B5   370 _SPI1_DATA	=	0x00b5
                           0000B6   371 _SPI1_CTRL	=	0x00b6
                           0000B7   372 _SPI1_CK_SE	=	0x00b7
                           0000F3   373 _ADC_CTRL	=	0x00f3
                           00F5F4   374 _ADC_DAT	=	0xf5f4
                           0000F4   375 _ADC_DAT_L	=	0x00f4
                           0000F5   376 _ADC_DAT_H	=	0x00f5
                           0000F6   377 _ADC_CHAN	=	0x00f6
                           0000A6   378 _LED_COMMON	=	0x00a6
                           0000A7   379 _LED_PWM_OE	=	0x00a7
                           00C7C6   380 _LED_DMA	=	0xc7c6
                           0000C6   381 _LED_DMA_L	=	0x00c6
                           0000C7   382 _LED_DMA_H	=	0x00c7
                           0000F7   383 _LED_STATUS	=	0x00f7
                           0000B3   384 _I2CX_INT	=	0x00b3
                           0000BB   385 _I2CS_INT_ST	=	0x00bb
                                    386 ;--------------------------------------------------------
                                    387 ; special function bits
                                    388 ;--------------------------------------------------------
                                    389 	.area RSEG    (ABS,DATA)
      000000                        390 	.org 0x0000
                           0000D7   391 _CY	=	0x00d7
                           0000D6   392 _AC	=	0x00d6
                           0000D5   393 _F0	=	0x00d5
                           0000D4   394 _RS1	=	0x00d4
                           0000D3   395 _RS0	=	0x00d3
                           0000D2   396 _OV	=	0x00d2
                           0000D1   397 _F1	=	0x00d1
                           0000D0   398 _P	=	0x00d0
                           0000AF   399 _EA	=	0x00af
                           0000AE   400 _E_DIS	=	0x00ae
                           0000AD   401 _ET2	=	0x00ad
                           0000AC   402 _ES	=	0x00ac
                           0000AB   403 _ET1	=	0x00ab
                           0000AA   404 _EX1	=	0x00aa
                           0000A9   405 _ET0	=	0x00a9
                           0000A8   406 _EX0	=	0x00a8
                           0000BF   407 _PH_FLAG	=	0x00bf
                           0000BE   408 _PL_FLAG	=	0x00be
                           0000BD   409 _PT2	=	0x00bd
                           0000BC   410 _PS	=	0x00bc
                           0000BB   411 _PT1	=	0x00bb
                           0000BA   412 _PX1	=	0x00ba
                           0000B9   413 _PT0	=	0x00b9
                           0000B8   414 _PX0	=	0x00b8
                           0000EF   415 _IE_WDOG	=	0x00ef
                           0000EE   416 _IE_GPIO	=	0x00ee
                           0000ED   417 _IE_PWM_I2C	=	0x00ed
                           0000EC   418 _IE_UART1	=	0x00ec
                           0000EB   419 _IE_ADC	=	0x00eb
                           0000E9   420 _IE_USB	=	0x00e9
                           0000E8   421 _IE_SPI0	=	0x00e8
                           000087   422 _P0_7	=	0x0087
                           000086   423 _P0_6	=	0x0086
                           000085   424 _P0_5	=	0x0085
                           000084   425 _P0_4	=	0x0084
                           000083   426 _P0_3	=	0x0083
                           000082   427 _P0_2	=	0x0082
                           000081   428 _P0_1	=	0x0081
                           000080   429 _P0_0	=	0x0080
                           000081   430 _SDA0	=	0x0081
                           000080   431 _SCL0	=	0x0080
                           000083   432 _TXD_	=	0x0083
                           000082   433 _RXD_	=	0x0082
                           000085   434 _AIN13	=	0x0085
                           000084   435 _AIN12	=	0x0084
                           000083   436 _AIN11	=	0x0083
                           000082   437 _AIN10	=	0x0082
                           000081   438 _AIN9	=	0x0081
                           000080   439 _AIN8	=	0x0080
                           000097   440 _P1_7	=	0x0097
                           000096   441 _P1_6	=	0x0096
                           000095   442 _P1_5	=	0x0095
                           000094   443 _P1_4	=	0x0094
                           000093   444 _P1_3	=	0x0093
                           000092   445 _P1_2	=	0x0092
                           000091   446 _P1_1	=	0x0091
                           000090   447 _P1_0	=	0x0090
                           000097   448 _TXD1_	=	0x0097
                           000096   449 _RXD1_	=	0x0096
                           000097   450 _SCK	=	0x0097
                           000096   451 _MISO	=	0x0096
                           000095   452 _MOSI	=	0x0095
                           000094   453 _SCS	=	0x0094
                           000092   454 _INT0_	=	0x0092
                           000091   455 _T2EX	=	0x0091
                           000091   456 _CAP2	=	0x0091
                           000090   457 _T2	=	0x0090
                           000090   458 _CAP1	=	0x0090
                           000097   459 _AIN7	=	0x0097
                           000096   460 _AIN6	=	0x0096
                           000095   461 _AIN5	=	0x0095
                           000094   462 _AIN4	=	0x0094
                           000093   463 _AIN3	=	0x0093
                           000092   464 _AIN2	=	0x0092
                           000091   465 _AIN1	=	0x0091
                           000090   466 _AIN0	=	0x0090
                           0000A7   467 _P2_7	=	0x00a7
                           0000A6   468 _P2_6	=	0x00a6
                           0000A5   469 _P2_5	=	0x00a5
                           0000A4   470 _P2_4	=	0x00a4
                           0000A3   471 _P2_3	=	0x00a3
                           0000A2   472 _P2_2	=	0x00a2
                           0000A1   473 _P2_1	=	0x00a1
                           0000A0   474 _P2_0	=	0x00a0
                           0000A7   475 _TXD1	=	0x00a7
                           0000A6   476 _RXD1	=	0x00a6
                           0000A5   477 _T2EX_	=	0x00a5
                           0000A5   478 _CAP2_	=	0x00a5
                           0000A4   479 _T2_	=	0x00a4
                           0000A4   480 _CAP1_	=	0x00a4
                           0000B7   481 _P3_7	=	0x00b7
                           0000B6   482 _P3_6	=	0x00b6
                           0000B5   483 _P3_5	=	0x00b5
                           0000B4   484 _P3_4	=	0x00b4
                           0000B3   485 _P3_3	=	0x00b3
                           0000B2   486 _P3_2	=	0x00b2
                           0000B1   487 _P3_1	=	0x00b1
                           0000B0   488 _P3_0	=	0x00b0
                           0000B7   489 _SCK1	=	0x00b7
                           0000B6   490 _MISO1	=	0x00b6
                           0000B5   491 _MOSI1	=	0x00b5
                           0000B5   492 _T1	=	0x00b5
                           0000B4   493 _T0	=	0x00b4
                           0000B3   494 _INT1	=	0x00b3
                           0000B2   495 _INT0	=	0x00b2
                           0000B1   496 _TXD	=	0x00b1
                           0000B0   497 _RXD	=	0x00b0
                           0000C6   498 _P4_6	=	0x00c6
                           0000C5   499 _P4_5	=	0x00c5
                           0000C4   500 _P4_4	=	0x00c4
                           0000C3   501 _P4_3	=	0x00c3
                           0000C2   502 _P4_2	=	0x00c2
                           0000C1   503 _P4_1	=	0x00c1
                           0000C0   504 _P4_0	=	0x00c0
                           00008F   505 _TF1	=	0x008f
                           00008E   506 _TR1	=	0x008e
                           00008D   507 _TF0	=	0x008d
                           00008C   508 _TR0	=	0x008c
                           00008B   509 _IE1	=	0x008b
                           00008A   510 _IT1	=	0x008a
                           000089   511 _IE0	=	0x0089
                           000088   512 _IT0	=	0x0088
                           00009F   513 _SM0	=	0x009f
                           00009E   514 _SM1	=	0x009e
                           00009D   515 _SM2	=	0x009d
                           00009C   516 _REN	=	0x009c
                           00009B   517 _TB8	=	0x009b
                           00009A   518 _RB8	=	0x009a
                           000099   519 _TI	=	0x0099
                           000098   520 _RI	=	0x0098
                           0000CF   521 _TF2	=	0x00cf
                           0000CF   522 _CAP1F	=	0x00cf
                           0000CE   523 _EXF2	=	0x00ce
                           0000CD   524 _RCLK	=	0x00cd
                           0000CC   525 _TCLK	=	0x00cc
                           0000CB   526 _EXEN2	=	0x00cb
                           0000CA   527 _TR2	=	0x00ca
                           0000C9   528 _C_T2	=	0x00c9
                           0000C8   529 _CP_RL2	=	0x00c8
                           0000FF   530 _S0_FST_ACT	=	0x00ff
                           0000FE   531 _S0_IF_OV	=	0x00fe
                           0000FD   532 _S0_IF_FIRST	=	0x00fd
                           0000FC   533 _S0_IF_BYTE	=	0x00fc
                           0000FB   534 _S0_FREE	=	0x00fb
                           0000FA   535 _S0_T_FIFO	=	0x00fa
                           0000F8   536 _S0_R_FIFO	=	0x00f8
                           0000F7   537 _ADC_START	=	0x00f7
                                    538 ;--------------------------------------------------------
                                    539 ; overlayable register banks
                                    540 ;--------------------------------------------------------
                                    541 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        542 	.ds 8
                                    543 ;--------------------------------------------------------
                                    544 ; internal ram data
                                    545 ;--------------------------------------------------------
                                    546 	.area DSEG    (DATA)
                                    547 ;--------------------------------------------------------
                                    548 ; overlayable items in internal ram
                                    549 ;--------------------------------------------------------
                                    550 	.area	OSEG    (OVR,DATA)
      000054                        551 _change_owned_sloc1_1_0:
      000054                        552 	.ds 1
                                    553 ;--------------------------------------------------------
                                    554 ; indirectly addressable internal ram data
                                    555 ;--------------------------------------------------------
                                    556 	.area ISEG    (DATA)
                                    557 ;--------------------------------------------------------
                                    558 ; absolute internal ram data
                                    559 ;--------------------------------------------------------
                                    560 	.area IABS    (ABS,DATA)
                                    561 	.area IABS    (ABS,DATA)
                                    562 ;--------------------------------------------------------
                                    563 ; bit data
                                    564 ;--------------------------------------------------------
                                    565 	.area BSEG    (BIT)
      000021                        566 _ak820_macro_change_sloc0_1_0:
      000021                        567 	.ds 1
      000022                        568 _change_owned_sloc0_1_0:
      000022                        569 	.ds 1
      000023                        570 _owned_usage_key_sloc0_1_0:
      000023                        571 	.ds 1
                                    572 ;--------------------------------------------------------
                                    573 ; paged external ram data
                                    574 ;--------------------------------------------------------
                                    575 	.area PSEG    (PAG,XDATA)
                                    576 ;--------------------------------------------------------
                                    577 ; uninitialized external ram data
                                    578 ;--------------------------------------------------------
                                    579 	.area XSEG    (XDATA)
      000A32                        580 _owned_mod_refs:
      000A32                        581 	.ds 8
      000A3A                        582 _owned_weak_refs:
      000A3A                        583 	.ds 8
      000A42                        584 _owned_mods:
      000A42                        585 	.ds 1
      000A43                        586 _owned_weak_mods:
      000A43                        587 	.ds 1
      000A44                        588 _macro_mods:
      000A44                        589 	.ds 2
      000A46                        590 _ak820_macro_primitive::
      000A46                        591 	.ds 1
      000A47                        592 _ak820_macro_cancelled::
      000A47                        593 	.ds 1
      000A48                        594 _ak820_macro_change_PARM_2:
      000A48                        595 	.ds 1
      000A49                        596 _ak820_macro_change_PARM_3:
      000A49                        597 	.ds 1
      000A4A                        598 _ak820_macro_change_bits_10000_293:
      000A4A                        599 	.ds 2
      000A4C                        600 _change_owned_PARM_2:
      000A4C                        601 	.ds 1
      000A4D                        602 _change_owned_mods_10000_298:
      000A4D                        603 	.ds 1
      000A4E                        604 _change_owned_result_10001_302:
      000A4E                        605 	.ds 1
      000A4F                        606 _change_owned_bit_20001_303:
      000A4F                        607 	.ds 1
      000A50                        608 _add_owned_mods_mods_10000_311:
      000A50                        609 	.ds 1
      000A51                        610 _del_owned_mods_mods_10000_313:
      000A51                        611 	.ds 1
      000A52                        612 _add_owned_weak_mods_mods_10000_315:
      000A52                        613 	.ds 1
      000A53                        614 _del_owned_weak_mods_mods_10000_317:
      000A53                        615 	.ds 1
      000A54                        616 _key_refs:
      000A54                        617 	.ds 165
      000AF9                        618 _distinct_keys:
      000AF9                        619 	.ds 1
      000AFA                        620 _macro_keys:
      000AFA                        621 	.ds 21
      000B0F                        622 _add_owned_key_code_10000_326:
      000B0F                        623 	.ds 1
      000B10                        624 _del_owned_key_code_10000_341:
      000B10                        625 	.ds 1
      000B11                        626 _usage_refs:
      000B11                        627 	.ds 30
      000B2F                        628 _usage_order:
      000B2F                        629 	.ds 30
      000B4D                        630 _usage_lengths:
      000B4D                        631 	.ds 2
      000B4F                        632 _macro_usages:
      000B4F                        633 	.ds 4
      000B53                        634 _owned_usage_key_PARM_2:
      000B53                        635 	.ds 1
      000B54                        636 _owned_usage_key_code_10000_368:
      000B54                        637 	.ds 1
      000B55                        638 _owned_usage_key___200000085_20000_369:
      000B55                        639 	.ds 2
      000B57                        640 _owned_usage_key_which_10000_369:
      000B57                        641 	.ds 1
      000B58                        642 _owned_usage_key_count_10000_369:
      000B58                        643 	.ds 1
      000B59                        644 _owned_usage_key_pos_30001_376:
      000B59                        645 	.ds 1
      000B5A                        646 _owned_usage_key_key_40000_381:
      000B5A                        647 	.ds 1
      000B5B                        648 _send_keyboard_report_last_report_10001_388:
      000B5B                        649 	.ds 32
      000B7B                        650 _send_keyboard_report_changed_10001_388:
      000B7B                        651 	.ds 1
      000B7C                        652 _add_weak_mods_mods_10000_406:
      000B7C                        653 	.ds 1
      000B7D                        654 _del_weak_mods_mods_10000_408:
      000B7D                        655 	.ds 1
                                    656 ;--------------------------------------------------------
                                    657 ; absolute external ram data
                                    658 ;--------------------------------------------------------
                                    659 	.area XABS    (ABS,XDATA)
                                    660 ;--------------------------------------------------------
                                    661 ; initialized external ram data
                                    662 ;--------------------------------------------------------
                                    663 	.area XISEG   (XDATA)
      000E83                        664 _real_mods:
      000E83                        665 	.ds 1
      000E84                        666 _weak_mods:
      000E84                        667 	.ds 1
      000E85                        668 _actual_keyboard_report::
      000E85                        669 	.ds 32
                                    670 	.area HOME    (CODE)
                                    671 	.area GSINIT0 (CODE)
                                    672 	.area GSINIT1 (CODE)
                                    673 	.area GSINIT2 (CODE)
                                    674 	.area GSINIT3 (CODE)
                                    675 	.area GSINIT4 (CODE)
                                    676 	.area GSINIT5 (CODE)
                                    677 	.area GSINIT  (CODE)
                                    678 	.area GSFINAL (CODE)
                                    679 	.area CSEG    (CODE)
                                    680 ;--------------------------------------------------------
                                    681 ; global & static initialisations
                                    682 ;--------------------------------------------------------
                                    683 	.area HOME    (CODE)
                                    684 	.area GSINIT  (CODE)
                                    685 	.area GSFINAL (CODE)
                                    686 	.area GSINIT  (CODE)
                                    687 ;--------------------------------------------------------
                                    688 ; Home
                                    689 ;--------------------------------------------------------
                                    690 	.area HOME    (CODE)
                                    691 	.area HOME    (CODE)
                                    692 ;--------------------------------------------------------
                                    693 ; code
                                    694 ;--------------------------------------------------------
                                    695 	.area CSEG    (CODE)
                                    696 ;------------------------------------------------------------
                                    697 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    698 ;------------------------------------------------------------
                                    699 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    700 ;------------------------------------------------------------
                                    701 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    702 ;	-----------------------------------------
                           000007   703 	ar7 = 0x07
                           000006   704 	ar6 = 0x06
                           000005   705 	ar5 = 0x05
                           000004   706 	ar4 = 0x04
                           000003   707 	ar3 = 0x03
                           000002   708 	ar2 = 0x02
                           000001   709 	ar1 = 0x01
                           000000   710 	ar0 = 0x00
                                    711 ;	 function ak820_macro_change
                                    712 ;	-----------------------------------------
      007FEB                        713 _ak820_macro_change:
      007FEB 12 38 55         [24]  714 	lcall	_ak820_outline_0106
      007FEE 90 0A 4A         [24]  715 	mov	dptr,#_ak820_macro_change_bits_10000_293
      007FF1 12 38 50         [24]  716 	lcall	_ak820_outline_0105
                                    717 ;	quantum/action_util.c:99: if (!ak820_macro_primitive) return true;
      007FF4 90 0A 46         [24]  718 	mov	dptr,#_ak820_macro_primitive
      007FF7 E0               [24]  719 	movx	a,@dptr
      007FF8 70 04            [24]  720 	jnz	00102$
      007FFA 75 82 01         [24]  721 	mov	dpl, #0x01
      007FFD 22               [24]  722 	ret
      007FFE                        723 00102$:
                                    724 ;	quantum/action_util.c:100: uint8_t mask = 1u << (index & 7);
      007FFE 90 0A 48         [24]  725 	mov	dptr,#_ak820_macro_change_PARM_2
      008001 E0               [24]  726 	movx	a,@dptr
      008002 FF               [12]  727 	mov	r7,a
      008003 74 07            [12]  728 	mov	a,#0x07
      008005 5F               [12]  729 	anl	a,r7
      008006 12 7B 91         [24]  730 	lcall	_ak820_outline_0068
      008009 80 02            [24]  731 	sjmp	00123$
      00800B                        732 00122$:
      00800B 25 E0            [12]  733 	add	a,acc
      00800D                        734 00123$:
      00800D D5 F0 FB         [24]  735 	djnz	b,00122$
      008010 FE               [12]  736 	mov	r6,a
                                    737 ;	quantum/action_util.c:101: bits += index >> 3;
      008011 EF               [12]  738 	mov	a,r7
      008012 12 5C 48         [24]  739 	lcall	_ak820_outline_0188
      008015 FF               [12]  740 	mov	r7,a
      008016 90 0A 4A         [24]  741 	mov	dptr,#_ak820_macro_change_bits_10000_293
      008019 12 38 1F         [24]  742 	lcall	_ak820_outline_0065
      00801C 90 0A 4A         [24]  743 	mov	dptr,#_ak820_macro_change_bits_10000_293
      00801F EF               [12]  744 	mov	a,r7
      008020 2C               [12]  745 	add	a, r4
      008021 F0               [24]  746 	movx	@dptr,a
      008022 E4               [12]  747 	clr	a
      008023 3D               [12]  748 	addc	a, r5
      008024 A3               [24]  749 	inc	dptr
      008025 F0               [24]  750 	movx	@dptr,a
                                    751 ;	quantum/action_util.c:102: if (((*bits & mask) != 0) == pressed) return false;
      008026 90 0A 4A         [24]  752 	mov	dptr,#_ak820_macro_change_bits_10000_293
      008029 E0               [24]  753 	movx	a,@dptr
      00802A FD               [12]  754 	mov	r5,a
      00802B A3               [24]  755 	inc	dptr
      00802C E0               [24]  756 	movx	a,@dptr
      00802D FF               [12]  757 	mov	r7,a
      00802E 12 85 69         [24]  758 	lcall	_ak820_outline_0190
      008031 E0               [24]  759 	movx	a,@dptr
      008032 FC               [12]  760 	mov	r4,a
      008033 EE               [12]  761 	mov	a,r6
      008034 5C               [12]  762 	anl	a,r4
      008035 B4 01 00         [24]  763 	cjne	a,#0x01,00124$
      008038                        764 00124$:
      008038 B3               [12]  765 	cpl	c
      008039 92 21            [24]  766 	mov	_ak820_macro_change_sloc0_1_0,c
      00803B 90 0A 49         [24]  767 	mov	dptr,#_ak820_macro_change_PARM_3
      00803E E0               [24]  768 	movx	a,@dptr
      00803F FB               [12]  769 	mov	r3,a
      008040 A2 21            [12]  770 	mov	c,_ak820_macro_change_sloc0_1_0
      008042 E4               [12]  771 	clr	a
      008043 33               [12]  772 	rlc	a
      008044 B5 03 04         [24]  773 	cjne	a,ar3,00104$
      008047 75 82 00         [24]  774 	mov	dpl, #0x00
      00804A 22               [24]  775 	ret
      00804B                        776 00104$:
                                    777 ;	quantum/action_util.c:103: *bits ^= mask;
      00804B EC               [12]  778 	mov	a,r4
      00804C 62 06            [12]  779 	xrl	ar6,a
      00804E 12 85 69         [24]  780 	lcall	_ak820_outline_0190
      008051 EE               [12]  781 	mov	a,r6
      008052 F0               [24]  782 	movx	@dptr,a
                                    783 ;	quantum/action_util.c:104: return true;
      008053 75 82 01         [24]  784 	mov	dpl, #0x01
                                    785 ;	quantum/action_util.c:105: }
      008056 22               [24]  786 	ret
                                    787 ;------------------------------------------------------------
                                    788 ;Allocation info for local variables in function 'change_owned'
                                    789 ;------------------------------------------------------------
                                    790 ;mode          Allocated with name '_change_owned_PARM_2'
                                    791 ;mods          Allocated with name '_change_owned_mods_10000_298'
                                    792 ;kind          Allocated with name '_change_owned_kind_10000_299'
                                    793 ;pressed       Allocated with name '_change_owned_pressed_10000_299'
                                    794 ;refs          Allocated with name '_change_owned_refs_10000_299'
                                    795 ;old           Allocated with name '_change_owned_old_30000_301'
                                    796 ;result        Allocated with name '_change_owned_result_10001_302'
                                    797 ;i             Allocated with name '_change_owned_i_20001_303'
                                    798 ;bit           Allocated with name '_change_owned_bit_20001_303'
                                    799 ;sloc1         Allocated with name '_change_owned_sloc1_1_0'
                                    800 ;------------------------------------------------------------
                                    801 ;	quantum/action_util.c:106: static void change_owned(uint8_t mods, uint8_t mode) {
                                    802 ;	-----------------------------------------
                                    803 ;	 function change_owned
                                    804 ;	-----------------------------------------
      008057                        805 _change_owned:
      008057 E5 82            [12]  806 	mov	a,dpl
      008059 90 0A 4D         [24]  807 	mov	dptr,#_change_owned_mods_10000_298
      00805C F0               [24]  808 	movx	@dptr,a
                                    809 ;	quantum/action_util.c:107: uint8_t kind = mode >> 1;
      00805D 90 0A 4C         [24]  810 	mov	dptr,#_change_owned_PARM_2
      008060 E0               [24]  811 	movx	a,@dptr
      008061 FF               [12]  812 	mov	r7,a
      008062 C3               [12]  813 	clr	c
      008063 13               [12]  814 	rrc	a
      008064 FE               [12]  815 	mov	r6,a
                                    816 ;	quantum/action_util.c:108: bool pressed = (mode & 1) != 0;
      008065 53 07 01         [24]  817 	anl	ar7,#0x01
      008068 EF               [12]  818 	mov	a,r7
      008069 B4 01 00         [24]  819 	cjne	a,#0x01,00205$
      00806C                        820 00205$:
      00806C 92 22            [24]  821 	mov  _change_owned_sloc0_1_0,c
      00806E B3               [12]  822 	cpl	c
      00806F E4               [12]  823 	clr	a
      008070 33               [12]  824 	rlc	a
      008071 F5 54            [12]  825 	mov	_change_owned_sloc1_1_0,a
                                    826 ;	quantum/action_util.c:109: uint8_t AK820_STATE_MEM *refs = kind ? owned_weak_refs : owned_mod_refs;
      008073 EE               [12]  827 	mov	a,r6
      008074 60 06            [24]  828 	jz	00121$
      008076 7D 3A            [12]  829 	mov	r5,#_owned_weak_refs
      008078 7F 0A            [12]  830 	mov	r7,#(_owned_weak_refs >> 8)
      00807A 80 04            [24]  831 	sjmp	00122$
      00807C                        832 00121$:
      00807C 7D 32            [12]  833 	mov	r5,#_owned_mod_refs
      00807E 7F 0A            [12]  834 	mov	r7,#(_owned_mod_refs >> 8)
      008080                        835 00122$:
                                    836 ;	quantum/action_util.c:110: if (ak820_macro_primitive) {
      008080 90 0A 46         [24]  837 	mov	dptr,#_ak820_macro_primitive
      008083 E0               [24]  838 	movx	a,@dptr
      008084 60 36            [24]  839 	jz	00102$
                                    840 ;	quantum/action_util.c:111: uint8_t old = macro_mods[kind];
      008086 EE               [12]  841 	mov	a,r6
      008087 24 44            [12]  842 	add	a, #_macro_mods
      008089 FB               [12]  843 	mov	r3,a
      00808A E4               [12]  844 	clr	a
      00808B 34 0A            [12]  845 	addc	a, #(_macro_mods >> 8)
      00808D 12 48 C5         [24]  846 	lcall	_ak820_outline_0049
                                    847 ;	quantum/action_util.c:112: macro_mods[kind] = pressed ? old | mods : old & ~mods;
      008090 E5 54            [12]  848 	mov	a,_change_owned_sloc1_1_0
      008092 60 0A            [24]  849 	jz	00123$
      008094 90 0A 4D         [24]  850 	mov	dptr,#_change_owned_mods_10000_298
      008097 E0               [24]  851 	movx	a,@dptr
      008098 F9               [12]  852 	mov	r1,a
      008099 EA               [12]  853 	mov	a,r2
      00809A 42 01            [12]  854 	orl	ar1,a
      00809C 80 07            [24]  855 	sjmp	00124$
      00809E                        856 00123$:
      00809E 90 0A 4D         [24]  857 	mov	dptr,#_change_owned_mods_10000_298
      0080A1 E0               [24]  858 	movx	a,@dptr
      0080A2 F4               [12]  859 	cpl	a
      0080A3 5A               [12]  860 	anl	a,r2
      0080A4 F9               [12]  861 	mov	r1,a
      0080A5                        862 00124$:
      0080A5 12 33 FC         [24]  863 	lcall	_ak820_outline_0124
      0080A8 E9               [12]  864 	mov	a,r1
      0080A9 F0               [24]  865 	movx	@dptr,a
                                    866 ;	quantum/action_util.c:113: mods &= pressed ? ~old : old;
      0080AA E5 54            [12]  867 	mov	a,_change_owned_sloc1_1_0
      0080AC 60 06            [24]  868 	jz	00125$
      0080AE 74 FF            [12]  869 	mov	a,#0xff
      0080B0 6A               [12]  870 	xrl	a,r2
      0080B1 FC               [12]  871 	mov	r4,a
      0080B2 80 02            [24]  872 	sjmp	00126$
      0080B4                        873 00125$:
      0080B4 8A 04            [24]  874 	mov	ar4,r2
      0080B6                        875 00126$:
      0080B6 90 0A 4D         [24]  876 	mov	dptr,#_change_owned_mods_10000_298
      0080B9 E0               [24]  877 	movx	a,@dptr
      0080BA 5C               [12]  878 	anl	a,r4
      0080BB F0               [24]  879 	movx	@dptr,a
      0080BC                        880 00102$:
                                    881 ;	quantum/action_util.c:115: uint8_t result = 0;
      0080BC 90 0A 4E         [24]  882 	mov	dptr,#_change_owned_result_10001_302
      0080BF E4               [12]  883 	clr	a
      0080C0 F0               [24]  884 	movx	@dptr,a
                                    885 ;	quantum/action_util.c:116: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      0080C1 90 0A 4F         [24]  886 	mov	dptr,#_change_owned_bit_20001_303
      0080C4 04               [12]  887 	inc	a
      0080C5 F0               [24]  888 	movx	@dptr,a
      0080C6 90 0A 4D         [24]  889 	mov	dptr,#_change_owned_mods_10000_298
      0080C9 E0               [24]  890 	movx	a,@dptr
      0080CA FC               [12]  891 	mov	r4,a
      0080CB 7B 00            [12]  892 	mov	r3,#0x00
      0080CD                        893 00117$:
      0080CD BB 08 00         [24]  894 	cjne	r3,#0x08,00210$
      0080D0                        895 00210$:
      0080D0 50 3F            [24]  896 	jnc	00112$
                                    897 ;	quantum/action_util.c:117: if (mods & bit) {
      0080D2 90 0A 4F         [24]  898 	mov	dptr,#_change_owned_bit_20001_303
      0080D5 E0               [24]  899 	movx	a,@dptr
      0080D6 5C               [12]  900 	anl	a,r4
      0080D7 60 1C            [24]  901 	jz	00109$
                                    902 ;	quantum/action_util.c:118: if (pressed) ++refs[i];
      0080D9 E5 54            [12]  903 	mov	a,_change_owned_sloc1_1_0
      0080DB 60 0C            [24]  904 	jz	00106$
      0080DD EB               [12]  905 	mov	a,r3
      0080DE 2D               [12]  906 	add	a, r5
      0080DF 12 37 D5         [24]  907 	lcall	_ak820_outline_0016
      0080E2 F8               [12]  908 	mov	r0,a
      0080E3 08               [12]  909 	inc	r0
      0080E4 12 48 CD         [24]  910 	lcall	_ak820_outline_0063
      0080E7 80 0C            [24]  911 	sjmp	00109$
      0080E9                        912 00106$:
                                    913 ;	quantum/action_util.c:119: else if (refs[i]) --refs[i];
      0080E9 EB               [12]  914 	mov	a,r3
      0080EA 2D               [12]  915 	add	a, r5
      0080EB 12 37 D5         [24]  916 	lcall	_ak820_outline_0016
      0080EE F8               [12]  917 	mov	r0,a
      0080EF 60 04            [24]  918 	jz	00109$
      0080F1 18               [12]  919 	dec	r0
      0080F2 12 48 CD         [24]  920 	lcall	_ak820_outline_0063
      0080F5                        921 00109$:
                                    922 ;	quantum/action_util.c:121: if (refs[i]) result |= bit;
      0080F5 EB               [12]  923 	mov	a,r3
      0080F6 2D               [12]  924 	add	a, r5
      0080F7 12 37 D5         [24]  925 	lcall	_ak820_outline_0016
      0080FA 60 0B            [24]  926 	jz	00118$
      0080FC 90 0A 4F         [24]  927 	mov	dptr,#_change_owned_bit_20001_303
      0080FF E0               [24]  928 	movx	a,@dptr
      008100 FA               [12]  929 	mov	r2,a
      008101 90 0A 4E         [24]  930 	mov	dptr,#_change_owned_result_10001_302
      008104 E0               [24]  931 	movx	a,@dptr
      008105 4A               [12]  932 	orl	a,r2
      008106 F0               [24]  933 	movx	@dptr,a
      008107                        934 00118$:
                                    935 ;	quantum/action_util.c:116: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      008107 0B               [12]  936 	inc	r3
      008108 90 0A 4F         [24]  937 	mov	dptr,#_change_owned_bit_20001_303
      00810B E0               [24]  938 	movx	a,@dptr
      00810C 25 E0            [12]  939 	add	a,acc
      00810E F0               [24]  940 	movx	@dptr,a
      00810F 80 BC            [24]  941 	sjmp	00117$
      008111                        942 00112$:
                                    943 ;	quantum/action_util.c:123: if (kind) owned_weak_mods = result;
      008111 EE               [12]  944 	mov	a,r6
      008112 60 09            [24]  945 	jz	00114$
      008114 90 0A 4E         [24]  946 	mov	dptr,#_change_owned_result_10001_302
      008117 E0               [24]  947 	movx	a,@dptr
      008118 90 0A 43         [24]  948 	mov	dptr,#_owned_weak_mods
      00811B F0               [24]  949 	movx	@dptr,a
      00811C 22               [24]  950 	ret
      00811D                        951 00114$:
                                    952 ;	quantum/action_util.c:124: else owned_mods = result;
      00811D 90 0A 4E         [24]  953 	mov	dptr,#_change_owned_result_10001_302
      008120 E0               [24]  954 	movx	a,@dptr
      008121 90 0A 42         [24]  955 	mov	dptr,#_owned_mods
      008124 F0               [24]  956 	movx	@dptr,a
                                    957 ;	quantum/action_util.c:125: }
      008125 22               [24]  958 	ret
                                    959 ;------------------------------------------------------------
                                    960 ;Allocation info for local variables in function 'add_owned_mods'
                                    961 ;------------------------------------------------------------
                                    962 ;mods          Allocated with name '_add_owned_mods_mods_10000_311'
                                    963 ;------------------------------------------------------------
                                    964 ;	quantum/action_util.c:126: void add_owned_mods(uint8_t mods) { change_owned(mods, 1); }
                                    965 ;	-----------------------------------------
                                    966 ;	 function add_owned_mods
                                    967 ;	-----------------------------------------
      008126                        968 _add_owned_mods:
      008126 E5 82            [12]  969 	mov	a,dpl
      008128 90 0A 50         [24]  970 	mov	dptr,#_add_owned_mods_mods_10000_311
      00812B 12 85 3D         [24]  971 	lcall	_ak820_outline_0118
      00812E 74 01            [12]  972 	mov	a,#0x01
      008130 F0               [24]  973 	movx	@dptr,a
      008131 8F 82            [24]  974 	mov	dpl, r7
      008133 02 80 57         [24]  975 	ljmp	_change_owned
                                    976 ;------------------------------------------------------------
                                    977 ;Allocation info for local variables in function 'del_owned_mods'
                                    978 ;------------------------------------------------------------
                                    979 ;mods          Allocated with name '_del_owned_mods_mods_10000_313'
                                    980 ;------------------------------------------------------------
                                    981 ;	quantum/action_util.c:127: void del_owned_mods(uint8_t mods) { change_owned(mods, 0); }
                                    982 ;	-----------------------------------------
                                    983 ;	 function del_owned_mods
                                    984 ;	-----------------------------------------
      008136                        985 _del_owned_mods:
      008136 E5 82            [12]  986 	mov	a,dpl
      008138 90 0A 51         [24]  987 	mov	dptr,#_del_owned_mods_mods_10000_313
      00813B 12 85 3D         [24]  988 	lcall	_ak820_outline_0118
      00813E E4               [12]  989 	clr	a
      00813F F0               [24]  990 	movx	@dptr,a
      008140 8F 82            [24]  991 	mov	dpl, r7
      008142 02 80 57         [24]  992 	ljmp	_change_owned
                                    993 ;------------------------------------------------------------
                                    994 ;Allocation info for local variables in function 'add_owned_weak_mods'
                                    995 ;------------------------------------------------------------
                                    996 ;mods          Allocated with name '_add_owned_weak_mods_mods_10000_315'
                                    997 ;------------------------------------------------------------
                                    998 ;	quantum/action_util.c:128: void add_owned_weak_mods(uint8_t mods) { change_owned(mods, 3); }
                                    999 ;	-----------------------------------------
                                   1000 ;	 function add_owned_weak_mods
                                   1001 ;	-----------------------------------------
      008145                       1002 _add_owned_weak_mods:
      008145 E5 82            [12] 1003 	mov	a,dpl
      008147 90 0A 52         [24] 1004 	mov	dptr,#_add_owned_weak_mods_mods_10000_315
      00814A 12 85 3D         [24] 1005 	lcall	_ak820_outline_0118
      00814D 74 03            [12] 1006 	mov	a,#0x03
      00814F F0               [24] 1007 	movx	@dptr,a
      008150 8F 82            [24] 1008 	mov	dpl, r7
      008152 02 80 57         [24] 1009 	ljmp	_change_owned
                                   1010 ;------------------------------------------------------------
                                   1011 ;Allocation info for local variables in function 'del_owned_weak_mods'
                                   1012 ;------------------------------------------------------------
                                   1013 ;mods          Allocated with name '_del_owned_weak_mods_mods_10000_317'
                                   1014 ;------------------------------------------------------------
                                   1015 ;	quantum/action_util.c:129: void del_owned_weak_mods(uint8_t mods) { change_owned(mods, 2); }
                                   1016 ;	-----------------------------------------
                                   1017 ;	 function del_owned_weak_mods
                                   1018 ;	-----------------------------------------
      008155                       1019 _del_owned_weak_mods:
      008155 E5 82            [12] 1020 	mov	a,dpl
      008157 90 0A 53         [24] 1021 	mov	dptr,#_del_owned_weak_mods_mods_10000_317
      00815A 12 85 3D         [24] 1022 	lcall	_ak820_outline_0118
      00815D 74 02            [12] 1023 	mov	a,#0x02
      00815F F0               [24] 1024 	movx	@dptr,a
      008160 8F 82            [24] 1025 	mov	dpl, r7
      008162 02 80 57         [24] 1026 	ljmp	_change_owned
                                   1027 ;------------------------------------------------------------
                                   1028 ;Allocation info for local variables in function 'clear_owned_mods'
                                   1029 ;------------------------------------------------------------
                                   1030 ;i             Allocated with name '_clear_owned_mods_i_20000_321'
                                   1031 ;------------------------------------------------------------
                                   1032 ;	quantum/action_util.c:130: void clear_owned_mods(void) {
                                   1033 ;	-----------------------------------------
                                   1034 ;	 function clear_owned_mods
                                   1035 ;	-----------------------------------------
      008165                       1036 _clear_owned_mods:
                                   1037 ;	quantum/action_util.c:131: for (uint8_t i = 0; i < 8; ++i) owned_mod_refs[i] = owned_weak_refs[i] = 0;
      008165 7F 00            [12] 1038 	mov	r7,#0x00
      008167                       1039 00103$:
      008167 BF 08 00         [24] 1040 	cjne	r7,#0x08,00122$
      00816A                       1041 00122$:
      00816A 50 1A            [24] 1042 	jnc	00101$
      00816C EF               [12] 1043 	mov	a,r7
      00816D 24 32            [12] 1044 	add	a, #_owned_mod_refs
      00816F FD               [12] 1045 	mov	r5,a
      008170 E4               [12] 1046 	clr	a
      008171 34 0A            [12] 1047 	addc	a, #(_owned_mod_refs >> 8)
      008173 FE               [12] 1048 	mov	r6,a
      008174 EF               [12] 1049 	mov	a,r7
      008175 24 3A            [12] 1050 	add	a, #_owned_weak_refs
      008177 F5 82            [12] 1051 	mov	dpl,a
      008179 E4               [12] 1052 	clr	a
      00817A 34 0A            [12] 1053 	addc	a, #(_owned_weak_refs >> 8)
      00817C F5 83            [12] 1054 	mov	dph,a
      00817E E4               [12] 1055 	clr	a
      00817F F0               [24] 1056 	movx	@dptr,a
      008180 12 85 44         [24] 1057 	lcall	_ak820_outline_0126
      008183 0F               [12] 1058 	inc	r7
      008184 80 E1            [24] 1059 	sjmp	00103$
      008186                       1060 00101$:
                                   1061 ;	quantum/action_util.c:132: owned_mods = owned_weak_mods = macro_mods[0] = macro_mods[1] = 0;
      008186 90 0A 45         [24] 1062 	mov	dptr,#(_macro_mods + 0x0001)
      008189 E4               [12] 1063 	clr	a
      00818A F0               [24] 1064 	movx	@dptr,a
      00818B 90 0A 44         [24] 1065 	mov	dptr,#_macro_mods
      00818E F0               [24] 1066 	movx	@dptr,a
      00818F 90 0A 43         [24] 1067 	mov	dptr,#_owned_weak_mods
      008192 F0               [24] 1068 	movx	@dptr,a
      008193 90 0A 42         [24] 1069 	mov	dptr,#_owned_mods
      008196 F0               [24] 1070 	movx	@dptr,a
                                   1071 ;	quantum/action_util.c:133: ak820_macro_cancelled = true;
      008197 90 0A 47         [24] 1072 	mov	dptr,#_ak820_macro_cancelled
      00819A 04               [12] 1073 	inc	a
      00819B F0               [24] 1074 	movx	@dptr,a
                                   1075 ;	quantum/action_util.c:134: }
      00819C 22               [24] 1076 	ret
                                   1077 ;------------------------------------------------------------
                                   1078 ;Allocation info for local variables in function 'clear_owned_keys'
                                   1079 ;------------------------------------------------------------
                                   1080 ;i             Allocated with name '_clear_owned_keys_i_20000_324'
                                   1081 ;i             Allocated with name '_clear_owned_keys_i_20000_325'
                                   1082 ;------------------------------------------------------------
                                   1083 ;	quantum/action_util.c:140: void clear_owned_keys(void) {
                                   1084 ;	-----------------------------------------
                                   1085 ;	 function clear_owned_keys
                                   1086 ;	-----------------------------------------
      00819D                       1087 _clear_owned_keys:
                                   1088 ;	quantum/action_util.c:141: for (uint8_t i = 0; i <= KC_EXSEL; ++i) key_refs[i] = 0;
      00819D 7F 00            [12] 1089 	mov	r7,#0x00
      00819F                       1090 00104$:
      00819F EF               [12] 1091 	mov	a,r7
      0081A0 24 5B            [12] 1092 	add	a,#0xff - 0xa4
      0081A2 40 0D            [24] 1093 	jc	00101$
                                   1094 ;	free result
      0081A4 EF               [12] 1095 	mov	a,r7
      0081A5 24 54            [12] 1096 	add	a, #_key_refs
      0081A7 F5 82            [12] 1097 	mov	dpl,a
      0081A9 E4               [12] 1098 	clr	a
      0081AA 34 0A            [12] 1099 	addc	a, #(_key_refs >> 8)
      0081AC 12 7F DC         [24] 1100 	lcall	_ak820_outline_0165
      0081AF 80 EE            [24] 1101 	sjmp	00104$
      0081B1                       1102 00101$:
                                   1103 ;	quantum/action_util.c:142: distinct_keys = 0;
      0081B1 90 0A F9         [24] 1104 	mov	dptr,#_distinct_keys
      0081B4 E4               [12] 1105 	clr	a
      0081B5 F0               [24] 1106 	movx	@dptr,a
                                   1107 ;	quantum/action_util.c:143: for (uint8_t i = 0; i < sizeof(macro_keys); ++i) macro_keys[i] = 0;
      0081B6 FF               [12] 1108 	mov	r7,a
      0081B7                       1109 00107$:
      0081B7 BF 15 00         [24] 1110 	cjne	r7,#0x15,00142$
      0081BA                       1111 00142$:
      0081BA 50 0D            [24] 1112 	jnc	00109$
      0081BC EF               [12] 1113 	mov	a,r7
      0081BD 24 FA            [12] 1114 	add	a, #_macro_keys
      0081BF F5 82            [12] 1115 	mov	dpl,a
      0081C1 E4               [12] 1116 	clr	a
      0081C2 34 0A            [12] 1117 	addc	a, #(_macro_keys >> 8)
      0081C4 12 7F DC         [24] 1118 	lcall	_ak820_outline_0165
      0081C7 80 EE            [24] 1119 	sjmp	00107$
      0081C9                       1120 00109$:
                                   1121 ;	quantum/action_util.c:144: }
      0081C9 22               [24] 1122 	ret
                                   1123 ;------------------------------------------------------------
                                   1124 ;Allocation info for local variables in function 'add_owned_key'
                                   1125 ;------------------------------------------------------------
                                   1126 ;code          Allocated with name '_add_owned_key_code_10000_326'
                                   1127 ;__400000074   Allocated with name '_add_owned_key___400000074_40000_335'
                                   1128 ;key           Allocated with name '_add_owned_key_key_50000_336'
                                   1129 ;i             Allocated with name '_add_owned_key_i_40000_334'
                                   1130 ;__300000076   Allocated with name '_add_owned_key___300000076_30000_338'
                                   1131 ;key           Allocated with name '_add_owned_key_key_40000_339'
                                   1132 ;------------------------------------------------------------
                                   1133 ;	quantum/action_util.c:145: bool add_owned_key(uint8_t code) {
                                   1134 ;	-----------------------------------------
                                   1135 ;	 function add_owned_key
                                   1136 ;	-----------------------------------------
      0081CA                       1137 _add_owned_key:
      0081CA E5 82            [12] 1138 	mov	a,dpl
      0081CC 90 0B 0F         [24] 1139 	mov	dptr,#_add_owned_key_code_10000_326
      0081CF 12 85 55         [24] 1140 	lcall	_ak820_outline_0134
                                   1141 ;	quantum/action_util.c:146: if (!ak820_macro_change(macro_keys, code, true)) return false;
      0081D2 74 01            [12] 1142 	mov	a,#0x01
      0081D4 F0               [24] 1143 	movx	@dptr,a
      0081D5 90 0A FA         [24] 1144 	mov	dptr,#_macro_keys
      0081D8 C0 07            [24] 1145 	push	ar7
      0081DA 12 7F EB         [24] 1146 	lcall	_ak820_macro_change
      0081DD E5 82            [12] 1147 	mov	a, dpl
      0081DF D0 07            [24] 1148 	pop	ar7
      0081E1 70 03            [24] 1149 	jnz	00102$
      0081E3 F5 82            [12] 1150 	mov	dpl,a
      0081E5 22               [24] 1151 	ret
      0081E6                       1152 00102$:
                                   1153 ;	quantum/action_util.c:147: if (key_refs[code]++) return false;
      0081E6 12 85 16         [24] 1154 	lcall	_ak820_outline_0030
      0081E9 FC               [12] 1155 	mov	r4,a
      0081EA 04               [12] 1156 	inc	a
      0081EB 12 85 44         [24] 1157 	lcall	_ak820_outline_0126
      0081EE EC               [12] 1158 	mov	a,r4
      0081EF 60 04            [24] 1159 	jz	00104$
      0081F1 75 82 00         [24] 1160 	mov	dpl, #0x00
      0081F4 22               [24] 1161 	ret
      0081F5                       1162 00104$:
                                   1163 ;	quantum/action_util.c:148: ++distinct_keys;
      0081F5 90 0A F9         [24] 1164 	mov	dptr,#_distinct_keys
      0081F8 E0               [24] 1165 	movx	a,@dptr
      0081F9 24 01            [12] 1166 	add	a, #0x01
      0081FB F0               [24] 1167 	movx	@dptr,a
                                   1168 ;	quantum/action_util.c:150: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      0081FC 90 0E 72         [24] 1169 	mov	dptr,#_keyboard_protocol
      0081FF E0               [24] 1170 	movx	a,@dptr
      008200 60 11            [24] 1171 	jz	00106$
      008202 90 0B 7E         [24] 1172 	mov	dptr,#_keymap_config
      008205 E0               [24] 1173 	movx	a,@dptr
      008206 30 E7 0A         [24] 1174 	jnb	acc.7,00106$
                                   1175 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      008209 12 85 60         [24] 1176 	lcall	_ak820_outline_0177
      00820C 12 73 A4         [24] 1177 	lcall	_add_key_to_report
                                   1178 ;	quantum/action_util.c:150: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      00820F 75 82 01         [24] 1179 	mov	dpl, #0x01
      008212 22               [24] 1180 	ret
      008213                       1181 00106$:
                                   1182 ;	quantum/action_util.c:152: if (distinct_keys > KEYBOARD_REPORT_KEYS) {
      008213 90 0A F9         [24] 1183 	mov	dptr,#_distinct_keys
      008216 E0               [24] 1184 	movx	a,@dptr
      008217 24 F9            [12] 1185 	add	a,#0xff - 0x06
      008219 50 17            [24] 1186 	jnc	00110$
                                   1187 ;	free result
                                   1188 ;	quantum/action_util.c:153: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; ++i) keyboard_report->keys[i] = 1; /* HID ErrorRollOver */
      00821B 7F 00            [12] 1189 	mov	r7,#0x00
      00821D                       1190 00115$:
      00821D BF 06 00         [24] 1191 	cjne	r7,#0x06,00174$
      008220                       1192 00174$:
      008220 50 1E            [24] 1193 	jnc	00111$
      008222 EF               [12] 1194 	mov	a,r7
      008223 24 87            [12] 1195 	add	a, #(_actual_keyboard_report + 0x0002)
      008225 F5 82            [12] 1196 	mov	dpl,a
      008227 E4               [12] 1197 	clr	a
      008228 34 0E            [12] 1198 	addc	a, #((_actual_keyboard_report + 0x0002) >> 8)
      00822A F5 83            [12] 1199 	mov	dph,a
      00822C 74 01            [12] 1200 	mov	a,#0x01
      00822E F0               [24] 1201 	movx	@dptr,a
      00822F 0F               [12] 1202 	inc	r7
      008230 80 EB            [24] 1203 	sjmp	00115$
      008232                       1204 00110$:
                                   1205 ;	quantum/action_util.c:154: } else add_key(code);
      008232 90 0B 0F         [24] 1206 	mov	dptr,#_add_owned_key_code_10000_326
      008235 E0               [24] 1207 	movx	a,@dptr
                                   1208 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      008236 90 08 C5         [24] 1209 	mov	dptr,#_add_key_to_report_PARM_2
      008239 F0               [24] 1210 	movx	@dptr,a
      00823A 90 0E 85         [24] 1211 	mov	dptr,#_actual_keyboard_report
      00823D 12 73 A4         [24] 1212 	lcall	_add_key_to_report
                                   1213 ;	quantum/action_util.c:154: } else add_key(code);
      008240                       1214 00111$:
                                   1215 ;	quantum/action_util.c:155: return true;
      008240 75 82 01         [24] 1216 	mov	dpl, #0x01
                                   1217 ;	quantum/action_util.c:156: }
      008243 22               [24] 1218 	ret
                                   1219 ;------------------------------------------------------------
                                   1220 ;Allocation info for local variables in function 'del_owned_key'
                                   1221 ;------------------------------------------------------------
                                   1222 ;code          Allocated with name '_del_owned_key_code_10000_341'
                                   1223 ;__400000078   Allocated with name '_del_owned_key___400000078_40000_352'
                                   1224 ;key           Allocated with name '_del_owned_key_key_50000_353'
                                   1225 ;key           Allocated with name '_del_owned_key_key_40000_350'
                                   1226 ;__600000081   Allocated with name '_del_owned_key___600000081_60000_358'
                                   1227 ;key           Allocated with name '_del_owned_key_key_70000_359'
                                   1228 ;__300000083   Allocated with name '_del_owned_key___300000083_30000_361'
                                   1229 ;key           Allocated with name '_del_owned_key_key_40000_362'
                                   1230 ;------------------------------------------------------------
                                   1231 ;	quantum/action_util.c:157: bool del_owned_key(uint8_t code) {
                                   1232 ;	-----------------------------------------
                                   1233 ;	 function del_owned_key
                                   1234 ;	-----------------------------------------
      008244                       1235 _del_owned_key:
      008244 E5 82            [12] 1236 	mov	a,dpl
      008246 90 0B 10         [24] 1237 	mov	dptr,#_del_owned_key_code_10000_341
      008249 12 85 55         [24] 1238 	lcall	_ak820_outline_0134
                                   1239 ;	quantum/action_util.c:158: if (!ak820_macro_change(macro_keys, code, false)) return false;
      00824C E4               [12] 1240 	clr	a
      00824D F0               [24] 1241 	movx	@dptr,a
      00824E 90 0A FA         [24] 1242 	mov	dptr,#_macro_keys
      008251 C0 07            [24] 1243 	push	ar7
      008253 12 7F EB         [24] 1244 	lcall	_ak820_macro_change
      008256 E5 82            [12] 1245 	mov	a, dpl
      008258 D0 07            [24] 1246 	pop	ar7
      00825A 70 03            [24] 1247 	jnz	00102$
      00825C F5 82            [12] 1248 	mov	dpl,a
      00825E 22               [24] 1249 	ret
      00825F                       1250 00102$:
                                   1251 ;	quantum/action_util.c:159: if (!key_refs[code] || --key_refs[code]) return false;
      00825F 12 85 16         [24] 1252 	lcall	_ak820_outline_0030
      008262 FC               [12] 1253 	mov	r4,a
      008263 60 07            [24] 1254 	jz	00103$
      008265 1C               [12] 1255 	dec	r4
      008266 12 43 07         [24] 1256 	lcall	_ak820_outline_0069
      008269 EC               [12] 1257 	mov	a,r4
      00826A 60 04            [24] 1258 	jz	00104$
      00826C                       1259 00103$:
      00826C 75 82 00         [24] 1260 	mov	dpl, #0x00
      00826F 22               [24] 1261 	ret
      008270                       1262 00104$:
                                   1263 ;	quantum/action_util.c:160: --distinct_keys;
      008270 90 0A F9         [24] 1264 	mov	dptr,#_distinct_keys
      008273 E0               [24] 1265 	movx	a,@dptr
      008274 14               [12] 1266 	dec	a
      008275 F0               [24] 1267 	movx	@dptr,a
                                   1268 ;	quantum/action_util.c:162: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      008276 90 0E 72         [24] 1269 	mov	dptr,#_keyboard_protocol
      008279 E0               [24] 1270 	movx	a,@dptr
      00827A 60 16            [24] 1271 	jz	00107$
      00827C 90 0B 7E         [24] 1272 	mov	dptr,#_keymap_config
      00827F E0               [24] 1273 	movx	a,@dptr
      008280 30 E7 0F         [24] 1274 	jnb	acc.7,00107$
                                   1275 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      008283 90 08 C8         [24] 1276 	mov	dptr,#_del_key_from_report_PARM_2
      008286 EF               [12] 1277 	mov	a,r7
      008287 F0               [24] 1278 	movx	@dptr,a
      008288 90 0E 85         [24] 1279 	mov	dptr,#_actual_keyboard_report
      00828B 12 73 DA         [24] 1280 	lcall	_del_key_from_report
                                   1281 ;	quantum/action_util.c:162: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      00828E 75 82 01         [24] 1282 	mov	dpl, #0x01
      008291 22               [24] 1283 	ret
      008292                       1284 00107$:
                                   1285 ;	quantum/action_util.c:164: if (distinct_keys > KEYBOARD_REPORT_KEYS) return true;
      008292 90 0A F9         [24] 1286 	mov	dptr,#_distinct_keys
      008295 E0               [24] 1287 	movx	a,@dptr
      008296 FF               [12] 1288 	mov  r7,a
      008297 24 F9            [12] 1289 	add	a,#0xff - 0x06
      008299 50 04            [24] 1290 	jnc	00110$
                                   1291 ;	free result
      00829B 75 82 01         [24] 1292 	mov	dpl, #0x01
      00829E 22               [24] 1293 	ret
      00829F                       1294 00110$:
                                   1295 ;	quantum/action_util.c:165: if (distinct_keys == KEYBOARD_REPORT_KEYS) {
      00829F BF 06 1F         [24] 1296 	cjne	r7,#0x06,00115$
                                   1297 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      0082A2 90 0E 85         [24] 1298 	mov	dptr,#_actual_keyboard_report
      0082A5 12 74 10         [24] 1299 	lcall	_clear_keys_from_report
                                   1300 ;	quantum/action_util.c:168: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      0082A8 7F 04            [12] 1301 	mov	r7,#0x04
      0082AA                       1302 00122$:
      0082AA EF               [12] 1303 	mov	a,r7
      0082AB 24 5B            [12] 1304 	add	a,#0xff - 0xa4
      0082AD 40 20            [24] 1305 	jc	00116$
                                   1306 ;	free result
      0082AF 12 85 16         [24] 1307 	lcall	_ak820_outline_0030
      0082B2 60 0A            [24] 1308 	jz	00123$
                                   1309 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      0082B4 12 85 60         [24] 1310 	lcall	_ak820_outline_0177
      0082B7 C0 07            [24] 1311 	push	ar7
      0082B9 12 73 A4         [24] 1312 	lcall	_add_key_to_report
      0082BC D0 07            [24] 1313 	pop	ar7
                                   1314 ;	quantum/action_util.c:168: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      0082BE                       1315 00123$:
      0082BE 0F               [12] 1316 	inc	r7
      0082BF 80 E9            [24] 1317 	sjmp	00122$
      0082C1                       1318 00115$:
                                   1319 ;	quantum/action_util.c:169: } else del_key(code);
      0082C1 90 0B 10         [24] 1320 	mov	dptr,#_del_owned_key_code_10000_341
      0082C4 E0               [24] 1321 	movx	a,@dptr
                                   1322 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      0082C5 90 08 C8         [24] 1323 	mov	dptr,#_del_key_from_report_PARM_2
      0082C8 F0               [24] 1324 	movx	@dptr,a
      0082C9 90 0E 85         [24] 1325 	mov	dptr,#_actual_keyboard_report
      0082CC 12 73 DA         [24] 1326 	lcall	_del_key_from_report
                                   1327 ;	quantum/action_util.c:169: } else del_key(code);
      0082CF                       1328 00116$:
                                   1329 ;	quantum/action_util.c:170: return true;
      0082CF 75 82 01         [24] 1330 	mov	dpl, #0x01
                                   1331 ;	quantum/action_util.c:171: }
      0082D2 22               [24] 1332 	ret
                                   1333 ;------------------------------------------------------------
                                   1334 ;Allocation info for local variables in function 'clear_owned_usages'
                                   1335 ;------------------------------------------------------------
                                   1336 ;i             Allocated with name '_clear_owned_usages_i_20000_366'
                                   1337 ;i             Allocated with name '_clear_owned_usages_i_20000_367'
                                   1338 ;------------------------------------------------------------
                                   1339 ;	quantum/action_util.c:181: void clear_owned_usages(void) {
                                   1340 ;	-----------------------------------------
                                   1341 ;	 function clear_owned_usages
                                   1342 ;	-----------------------------------------
      0082D3                       1343 _clear_owned_usages:
                                   1344 ;	quantum/action_util.c:182: for (uint8_t i = 0; i < USAGE_COUNT; ++i) usage_refs[i] = usage_order[i] = 0;
      0082D3 7F 00            [12] 1345 	mov	r7,#0x00
      0082D5                       1346 00104$:
      0082D5 BF 1E 00         [24] 1347 	cjne	r7,#0x1e,00141$
      0082D8                       1348 00141$:
      0082D8 50 14            [24] 1349 	jnc	00101$
      0082DA EF               [12] 1350 	mov	a,r7
      0082DB 24 11            [12] 1351 	add	a, #_usage_refs
      0082DD FD               [12] 1352 	mov	r5,a
      0082DE E4               [12] 1353 	clr	a
      0082DF 34 0B            [12] 1354 	addc	a, #(_usage_refs >> 8)
      0082E1 FE               [12] 1355 	mov	r6,a
      0082E2 EF               [12] 1356 	mov	a,r7
      0082E3 12 85 24         [24] 1357 	lcall	_ak820_outline_0072
      0082E6 E4               [12] 1358 	clr	a
      0082E7 F0               [24] 1359 	movx	@dptr,a
      0082E8 12 85 44         [24] 1360 	lcall	_ak820_outline_0126
      0082EB 0F               [12] 1361 	inc	r7
      0082EC 80 E7            [24] 1362 	sjmp	00104$
      0082EE                       1363 00101$:
                                   1364 ;	quantum/action_util.c:183: usage_lengths[0] = usage_lengths[1] = 0;
      0082EE 90 0B 4E         [24] 1365 	mov	dptr,#(_usage_lengths + 0x0001)
      0082F1 E4               [12] 1366 	clr	a
      0082F2 F0               [24] 1367 	movx	@dptr,a
      0082F3 90 0B 4D         [24] 1368 	mov	dptr,#_usage_lengths
      0082F6 F0               [24] 1369 	movx	@dptr,a
                                   1370 ;	quantum/action_util.c:184: for (uint8_t i = 0; i < sizeof(macro_usages); ++i) macro_usages[i] = 0;
      0082F7 FF               [12] 1371 	mov	r7,a
      0082F8                       1372 00107$:
      0082F8 BF 04 00         [24] 1373 	cjne	r7,#0x04,00143$
      0082FB                       1374 00143$:
      0082FB 50 0D            [24] 1375 	jnc	00109$
      0082FD EF               [12] 1376 	mov	a,r7
      0082FE 24 4F            [12] 1377 	add	a, #_macro_usages
      008300 F5 82            [12] 1378 	mov	dpl,a
      008302 E4               [12] 1379 	clr	a
      008303 34 0B            [12] 1380 	addc	a, #(_macro_usages >> 8)
      008305 12 7F DC         [24] 1381 	lcall	_ak820_outline_0165
      008308 80 EE            [24] 1382 	sjmp	00107$
      00830A                       1383 00109$:
                                   1384 ;	quantum/action_util.c:185: }
      00830A 22               [24] 1385 	ret
                                   1386 ;------------------------------------------------------------
                                   1387 ;Allocation info for local variables in function 'owned_usage_key'
                                   1388 ;------------------------------------------------------------
                                   1389 ;pressed       Allocated with name '_owned_usage_key_PARM_2'
                                   1390 ;code          Allocated with name '_owned_usage_key_code_10000_368'
                                   1391 ;__200000085   Allocated with name '_owned_usage_key___200000085_20000_369'
                                   1392 ;which         Allocated with name '_owned_usage_key_which_10000_369'
                                   1393 ;base          Allocated with name '_owned_usage_key_base_10000_369'
                                   1394 ;count         Allocated with name '_owned_usage_key_count_10000_369'
                                   1395 ;index         Allocated with name '_owned_usage_key_index_10000_369'
                                   1396 ;pos           Allocated with name '_owned_usage_key_pos_30001_376'
                                   1397 ;i             Allocated with name '_owned_usage_key_i_40001_377'
                                   1398 ;__300000086   Allocated with name '_owned_usage_key___300000086_30000_380'
                                   1399 ;key           Allocated with name '_owned_usage_key_key_40000_381'
                                   1400 ;------------------------------------------------------------
                                   1401 ;	quantum/action_util.c:186: void owned_usage_key(uint8_t code, bool pressed) {
                                   1402 ;	-----------------------------------------
                                   1403 ;	 function owned_usage_key
                                   1404 ;	-----------------------------------------
      00830B                       1405 _owned_usage_key:
      00830B E5 82            [12] 1406 	mov	a,dpl
      00830D 90 0B 54         [24] 1407 	mov	dptr,#_owned_usage_key_code_10000_368
      008310 F0               [24] 1408 	movx	@dptr,a
                                   1409 ;	quantum/action_util.c:187: uint8_t which = code >= KC_AUDIO_MUTE;
      008311 E0               [24] 1410 	movx	a,@dptr
      008312 FF               [12] 1411 	mov	r7,a
      008313 BF A8 00         [24] 1412 	cjne	r7,#0xa8,00244$
      008316                       1413 00244$:
      008316 B3               [12] 1414 	cpl	c
      008317 92 23            [24] 1415 	mov	_owned_usage_key_sloc0_1_0,c
      008319 E4               [12] 1416 	clr	a
      00831A 33               [12] 1417 	rlc	a
      00831B FF               [12] 1418 	mov	r7,a
      00831C 90 0B 57         [24] 1419 	mov	dptr,#_owned_usage_key_which_10000_369
      00831F F0               [24] 1420 	movx	@dptr,a
                                   1421 ;	quantum/action_util.c:188: uint8_t base = which ? SYSTEM_COUNT : 0;
      008320 EF               [12] 1422 	mov	a,r7
      008321 60 02            [24] 1423 	jz	00129$
      008323 74 03            [12] 1424 	mov	a,#0x03
      008325                       1425 00129$:
      008325 FE               [12] 1426 	mov	r6,a
                                   1427 ;	quantum/action_util.c:189: uint8_t count = usage_lengths[which];
      008326 EF               [12] 1428 	mov	a,r7
      008327 24 4D            [12] 1429 	add	a, #_usage_lengths
      008329 FD               [12] 1430 	mov	r5,a
      00832A E4               [12] 1431 	clr	a
      00832B 34 0B            [12] 1432 	addc	a, #(_usage_lengths >> 8)
      00832D FF               [12] 1433 	mov	r7,a
      00832E 12 85 69         [24] 1434 	lcall	_ak820_outline_0190
      008331 E0               [24] 1435 	movx	a,@dptr
      008332 FC               [12] 1436 	mov	r4,a
                                   1437 ;	quantum/action_util.c:190: uint8_t index = code - KC_SYSTEM_POWER;
      008333 90 0B 54         [24] 1438 	mov	dptr,#_owned_usage_key_code_10000_368
      008336 E0               [24] 1439 	movx	a,@dptr
      008337 24 5B            [12] 1440 	add	a,#0x5b
      008339 FB               [12] 1441 	mov	r3,a
                                   1442 ;	quantum/action_util.c:191: if (!ak820_macro_change(macro_usages, index, pressed)) return;
      00833A 90 0B 53         [24] 1443 	mov	dptr,#_owned_usage_key_PARM_2
      00833D E0               [24] 1444 	movx	a,@dptr
      00833E FA               [12] 1445 	mov	r2,a
      00833F 90 0A 48         [24] 1446 	mov	dptr,#_ak820_macro_change_PARM_2
      008342 EB               [12] 1447 	mov	a,r3
      008343 F0               [24] 1448 	movx	@dptr,a
      008344 90 0A 49         [24] 1449 	mov	dptr,#_ak820_macro_change_PARM_3
      008347 EA               [12] 1450 	mov	a,r2
      008348 F0               [24] 1451 	movx	@dptr,a
      008349 90 0B 4F         [24] 1452 	mov	dptr,#_macro_usages
      00834C C0 07            [24] 1453 	push	ar7
      00834E C0 06            [24] 1454 	push	ar6
      008350 C0 05            [24] 1455 	push	ar5
      008352 C0 04            [24] 1456 	push	ar4
      008354 C0 03            [24] 1457 	push	ar3
      008356 C0 02            [24] 1458 	push	ar2
      008358 12 7F EB         [24] 1459 	lcall	_ak820_macro_change
      00835B E5 82            [12] 1460 	mov	a, dpl
      00835D D0 02            [24] 1461 	pop	ar2
      00835F D0 03            [24] 1462 	pop	ar3
      008361 D0 04            [24] 1463 	pop	ar4
      008363 D0 05            [24] 1464 	pop	ar5
      008365 D0 06            [24] 1465 	pop	ar6
      008367 D0 07            [24] 1466 	pop	ar7
      008369 70 01            [24] 1467 	jnz	00102$
      00836B 22               [24] 1468 	ret
      00836C                       1469 00102$:
                                   1470 ;	quantum/action_util.c:192: if (pressed) {
      00836C EA               [12] 1471 	mov	a,r2
      00836D 60 1B            [24] 1472 	jz	00115$
                                   1473 ;	quantum/action_util.c:193: if (usage_refs[index]++) return;
      00836F 12 85 2E         [24] 1474 	lcall	_ak820_outline_0076
      008372 04               [12] 1475 	inc	a
      008373 12 71 32         [24] 1476 	lcall	_ak820_outline_0139
      008376 E8               [12] 1477 	mov	a,r0
      008377 60 01            [24] 1478 	jz	00104$
      008379 22               [24] 1479 	ret
      00837A                       1480 00104$:
                                   1481 ;	quantum/action_util.c:194: usage_order[base + count++] = index;
      00837A 90 0B 58         [24] 1482 	mov	dptr,#_owned_usage_key_count_10000_369
      00837D EC               [12] 1483 	mov	a,r4
      00837E 04               [12] 1484 	inc	a
      00837F F0               [24] 1485 	movx	@dptr,a
      008380 EC               [12] 1486 	mov	a,r4
      008381 2E               [12] 1487 	add	a, r6
      008382 12 85 24         [24] 1488 	lcall	_ak820_outline_0072
      008385 EB               [12] 1489 	mov	a,r3
      008386 F0               [24] 1490 	movx	@dptr,a
      008387 02 83 EB         [24] 1491 	ljmp	00116$
      00838A                       1492 00115$:
                                   1493 ;	quantum/action_util.c:196: if (!usage_refs[index] || --usage_refs[index]) return;
      00838A 12 85 2E         [24] 1494 	lcall	_ak820_outline_0076
      00838D 60 07            [24] 1495 	jz	00105$
      00838F 18               [12] 1496 	dec	r0
      008390 12 48 CD         [24] 1497 	lcall	_ak820_outline_0063
      008393 E8               [12] 1498 	mov	a,r0
      008394 60 01            [24] 1499 	jz	00106$
      008396                       1500 00105$:
      008396 22               [24] 1501 	ret
      008397                       1502 00106$:
                                   1503 ;	quantum/action_util.c:198: while (usage_order[base + pos] != index) ++pos;
      008397 7A 00            [12] 1504 	mov	r2,#0x00
      008399                       1505 00108$:
      008399 EA               [12] 1506 	mov	a,r2
      00839A 2E               [12] 1507 	add	a, r6
      00839B 12 85 24         [24] 1508 	lcall	_ak820_outline_0072
      00839E E0               [24] 1509 	movx	a,@dptr
      00839F B5 03 02         [24] 1510 	cjne	a,ar3,00251$
      0083A2 80 03            [24] 1511 	sjmp	00167$
      0083A4                       1512 00251$:
      0083A4 0A               [12] 1513 	inc	r2
      0083A5 80 F2            [24] 1514 	sjmp	00108$
      0083A7                       1515 00167$:
      0083A7 90 0B 59         [24] 1516 	mov	dptr,#_owned_usage_key_pos_30001_376
      0083AA EA               [12] 1517 	mov	a,r2
      0083AB F0               [24] 1518 	movx	@dptr,a
                                   1519 ;	quantum/action_util.c:199: --count;
      0083AC 1C               [12] 1520 	dec	r4
      0083AD 90 0B 58         [24] 1521 	mov	dptr,#_owned_usage_key_count_10000_369
      0083B0 EC               [12] 1522 	mov	a,r4
      0083B1 F0               [24] 1523 	movx	@dptr,a
                                   1524 ;	quantum/action_util.c:200: for (uint8_t i = pos; i < count; ++i) usage_order[base + i] = usage_order[base + i + 1];
      0083B2 8A 03            [24] 1525 	mov	ar3,r2
      0083B4                       1526 00125$:
      0083B4 C3               [12] 1527 	clr	c
      0083B5 EB               [12] 1528 	mov	a,r3
      0083B6 9C               [12] 1529 	subb	a,r4
      0083B7 50 23            [24] 1530 	jnc	00111$
      0083B9 C0 05            [24] 1531 	push	ar5
      0083BB C0 07            [24] 1532 	push	ar7
      0083BD EB               [12] 1533 	mov	a,r3
      0083BE 2E               [12] 1534 	add	a, r6
      0083BF FA               [12] 1535 	mov	r2,a
      0083C0 24 2F            [12] 1536 	add	a, #_usage_order
      0083C2 F8               [12] 1537 	mov	r0,a
      0083C3 E4               [12] 1538 	clr	a
      0083C4 34 0B            [12] 1539 	addc	a, #(_usage_order >> 8)
      0083C6 F9               [12] 1540 	mov	r1,a
      0083C7 0A               [12] 1541 	inc	r2
      0083C8 EA               [12] 1542 	mov	a,r2
      0083C9 33               [12] 1543 	rlc	a
      0083CA 95 E0            [12] 1544 	subb	a,acc
      0083CC FF               [12] 1545 	mov	r7,a
      0083CD EA               [12] 1546 	mov	a,r2
      0083CE 12 85 4A         [24] 1547 	lcall	_ak820_outline_0128
      0083D1 12 38 74         [24] 1548 	lcall	_ak820_outline_0158
      0083D4 F0               [24] 1549 	movx	@dptr,a
      0083D5 0B               [12] 1550 	inc	r3
      0083D6 D0 07            [24] 1551 	pop	ar7
      0083D8 D0 05            [24] 1552 	pop	ar5
      0083DA 80 D8            [24] 1553 	sjmp	00125$
      0083DC                       1554 00111$:
                                   1555 ;	quantum/action_util.c:201: usage_lengths[which] = count;
      0083DC 12 85 69         [24] 1556 	lcall	_ak820_outline_0190
      0083DF EC               [12] 1557 	mov	a,r4
      0083E0 F0               [24] 1558 	movx	@dptr,a
                                   1559 ;	quantum/action_util.c:202: if (pos != count) return; /* A non-winning owner changed only storage. */
      0083E1 90 0B 59         [24] 1560 	mov	dptr,#_owned_usage_key_pos_30001_376
      0083E4 E0               [24] 1561 	movx	a,@dptr
      0083E5 B5 04 02         [24] 1562 	cjne	a,ar4,00253$
      0083E8 80 01            [24] 1563 	sjmp	00116$
      0083EA                       1564 00253$:
      0083EA 22               [24] 1565 	ret
      0083EB                       1566 00116$:
                                   1567 ;	quantum/action_util.c:204: usage_lengths[which] = count;
      0083EB 90 0B 58         [24] 1568 	mov	dptr,#_owned_usage_key_count_10000_369
      0083EE E0               [24] 1569 	movx	a,@dptr
      0083EF FC               [12] 1570 	mov	r4,a
      0083F0 12 85 69         [24] 1571 	lcall	_ak820_outline_0190
      0083F3 F0               [24] 1572 	movx	@dptr,a
                                   1573 ;	quantum/action_util.c:205: code = count ? usage_order[base + count - 1] + KC_SYSTEM_POWER : 0;
      0083F4 EC               [12] 1574 	mov	a,r4
      0083F5 60 15            [24] 1575 	jz	00131$
      0083F7 EC               [12] 1576 	mov	a,r4
      0083F8 2E               [12] 1577 	add	a, r6
      0083F9 FE               [12] 1578 	mov	r6,a
      0083FA 1E               [12] 1579 	dec	r6
      0083FB EE               [12] 1580 	mov	a,r6
      0083FC 33               [12] 1581 	rlc	a
      0083FD 95 E0            [12] 1582 	subb	a,acc
      0083FF FF               [12] 1583 	mov	r7,a
      008400 EE               [12] 1584 	mov	a,r6
      008401 12 85 4A         [24] 1585 	lcall	_ak820_outline_0128
      008404 24 A5            [12] 1586 	add	a,#0xa5
      008406 FE               [12] 1587 	mov	r6,a
      008407 33               [12] 1588 	rlc	a
      008408 95 E0            [12] 1589 	subb	a,acc
      00840A 80 02            [24] 1590 	sjmp	00132$
      00840C                       1591 00131$:
      00840C 7E 00            [12] 1592 	mov	r6,#0x00
      00840E                       1593 00132$:
      00840E 90 0B 54         [24] 1594 	mov	dptr,#_owned_usage_key_code_10000_368
      008411 EE               [12] 1595 	mov	a,r6
      008412 F0               [24] 1596 	movx	@dptr,a
                                   1597 ;	quantum/action_util.c:206: if (which) host_consumer_send(code ? KEYCODE2CONSUMER(code) : 0);
      008413 90 0B 57         [24] 1598 	mov	dptr,#_owned_usage_key_which_10000_369
      008416 E0               [24] 1599 	movx	a,@dptr
      008417 60 18            [24] 1600 	jz	00118$
      008419 EE               [12] 1601 	mov	a,r6
      00841A 60 0B            [24] 1602 	jz	00133$
      00841C 8E 82            [24] 1603 	mov	dpl, r6
      00841E 12 72 63         [24] 1604 	lcall	_KEYCODE2CONSUMER
      008421 AD 82            [24] 1605 	mov	r5, dpl
      008423 AF 83            [24] 1606 	mov	r7, dph
      008425 80 04            [24] 1607 	sjmp	00134$
      008427                       1608 00133$:
      008427 7D 00            [12] 1609 	mov	r5,#0x00
      008429 7F 00            [12] 1610 	mov	r7,#0x00
      00842B                       1611 00134$:
      00842B 12 85 69         [24] 1612 	lcall	_ak820_outline_0190
      00842E 02 72 25         [24] 1613 	ljmp	_host_consumer_send
      008431                       1614 00118$:
                                   1615 ;	quantum/action_util.c:207: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      008431 EE               [12] 1616 	mov	a,r6
      008432 60 22            [24] 1617 	jz	00135$
                                   1618 ;	tmk_core/protocol/report.h:264: if (key < KC_SYSTEM_POWER || key > KC_SYSTEM_WAKE) return 0;
      008434 BE A5 00         [24] 1619 	cjne	r6,#0xa5,00258$
      008437                       1620 00258$:
      008437 40 05            [24] 1621 	jc	00121$
      008439 EE               [12] 1622 	mov	a,r6
      00843A 24 58            [12] 1623 	add	a,#0xff - 0xa7
      00843C 50 08            [24] 1624 	jnc	00122$
                                   1625 ;	free result
      00843E                       1626 00121$:
      00843E 90 0B 55         [24] 1627 	mov	dptr,#_owned_usage_key___200000085_20000_369
      008441 12 48 E2         [24] 1628 	lcall	_ak820_outline_0143
      008444 80 09            [24] 1629 	sjmp	00123$
      008446                       1630 00122$:
                                   1631 ;	tmk_core/protocol/report.h:265: return SYSTEM_POWER_DOWN + (key - KC_SYSTEM_POWER);
      008446 74 DC            [12] 1632 	mov	a,#0xdc
      008448 2E               [12] 1633 	add	a, r6
      008449 90 0B 55         [24] 1634 	mov	dptr,#_owned_usage_key___200000085_20000_369
      00844C 12 38 65         [24] 1635 	lcall	_ak820_outline_0127
                                   1636 ;	quantum/action_util.c:207: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      00844F                       1637 00123$:
      00844F 90 0B 55         [24] 1638 	mov	dptr,#_owned_usage_key___200000085_20000_369
      008452 E0               [24] 1639 	movx	a,@dptr
      008453 FF               [12] 1640 	mov	r7,a
      008454 80 02            [24] 1641 	sjmp	00136$
      008456                       1642 00135$:
      008456 7F 00            [12] 1643 	mov	r7,#0x00
      008458                       1644 00136$:
      008458 7E 00            [12] 1645 	mov	r6,#0x00
      00845A 12 43 4B         [24] 1646 	lcall	_ak820_outline_0159
                                   1647 ;	quantum/action_util.c:208: }
      00845D 02 71 F5         [24] 1648 	ljmp	_host_system_send
                                   1649 ;------------------------------------------------------------
                                   1650 ;Allocation info for local variables in function 'send_keyboard_report'
                                   1651 ;------------------------------------------------------------
                                   1652 ;last_report   Allocated with name '_send_keyboard_report_last_report_10001_388'
                                   1653 ;changed       Allocated with name '_send_keyboard_report_changed_10001_388'
                                   1654 ;dest          Allocated with name '_send_keyboard_report_dest_10001_388'
                                   1655 ;src           Allocated with name '_send_keyboard_report_src_10001_388'
                                   1656 ;i             Allocated with name '_send_keyboard_report_i_20001_389'
                                   1657 ;------------------------------------------------------------
                                   1658 ;	quantum/action_util.c:430: void send_keyboard_report(void) {
                                   1659 ;	-----------------------------------------
                                   1660 ;	 function send_keyboard_report
                                   1661 ;	-----------------------------------------
      008460                       1662 _send_keyboard_report:
                                   1663 ;	quantum/action_util.c:431: keyboard_report->mods = real_mods;
      008460 90 0E 83         [24] 1664 	mov	dptr,#_real_mods
      008463 E0               [24] 1665 	movx	a,@dptr
      008464 FF               [12] 1666 	mov	r7,a
      008465 90 0E 85         [24] 1667 	mov	dptr,#_actual_keyboard_report
      008468 F0               [24] 1668 	movx	@dptr,a
                                   1669 ;	quantum/action_util.c:432: keyboard_report->mods |= weak_mods;
      008469 90 0E 84         [24] 1670 	mov	dptr,#_weak_mods
      00846C E0               [24] 1671 	movx	a,@dptr
      00846D 42 07            [12] 1672 	orl	ar7,a
      00846F 90 0E 85         [24] 1673 	mov	dptr,#_actual_keyboard_report
      008472 EF               [12] 1674 	mov	a,r7
      008473 F0               [24] 1675 	movx	@dptr,a
                                   1676 ;	quantum/action_util.c:434: keyboard_report->mods |= owned_mods | owned_weak_mods;
      008474 90 0A 43         [24] 1677 	mov	dptr,#_owned_weak_mods
      008477 E0               [24] 1678 	movx	a,@dptr
      008478 FE               [12] 1679 	mov	r6,a
      008479 90 0A 42         [24] 1680 	mov	dptr,#_owned_mods
      00847C E0               [24] 1681 	movx	a,@dptr
      00847D 4E               [12] 1682 	orl	a,r6
      00847E 42 07            [12] 1683 	orl	ar7,a
      008480 90 0E 85         [24] 1684 	mov	dptr,#_actual_keyboard_report
      008483 EF               [12] 1685 	mov	a,r7
      008484 F0               [24] 1686 	movx	@dptr,a
                                   1687 ;	quantum/action_util.c:515: bool changed = false;
      008485 90 0B 7B         [24] 1688 	mov	dptr,#_send_keyboard_report_changed_10001_388
      008488 E4               [12] 1689 	clr	a
      008489 F0               [24] 1690 	movx	@dptr,a
                                   1691 ;	quantum/action_util.c:517: uint8_t __xdata *dest = (uint8_t __xdata *)&last_report;
                                   1692 ;	quantum/action_util.c:518: const uint8_t __xdata *src = (const uint8_t __xdata *)AK820_REPORT_OUT;
                                   1693 ;	quantum/action_util.c:523: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      00848A FF               [12] 1694 	mov	r7,a
      00848B                       1695 00107$:
      00848B BF 20 00         [24] 1696 	cjne	r7,#0x20,00140$
      00848E                       1697 00140$:
      00848E 50 2B            [24] 1698 	jnc	00103$
                                   1699 ;	quantum/action_util.c:524: if (dest[i] != src[i]) {
      008490 EF               [12] 1700 	mov	a,r7
      008491 24 5B            [12] 1701 	add	a, #_send_keyboard_report_last_report_10001_388
      008493 FD               [12] 1702 	mov	r5,a
      008494 E4               [12] 1703 	clr	a
      008495 34 0B            [12] 1704 	addc	a, #(_send_keyboard_report_last_report_10001_388 >> 8)
      008497 FE               [12] 1705 	mov	r6,a
      008498 12 4D C0         [24] 1706 	lcall	_ak820_outline_0078
      00849B EF               [12] 1707 	mov	a,r7
      00849C 24 85            [12] 1708 	add	a, #_actual_keyboard_report
      00849E F5 82            [12] 1709 	mov	dpl,a
      0084A0 E4               [12] 1710 	clr	a
      0084A1 34 0E            [12] 1711 	addc	a, #(_actual_keyboard_report >> 8)
      0084A3 F5 83            [12] 1712 	mov	dph,a
      0084A5 E0               [24] 1713 	movx	a,@dptr
      0084A6 FB               [12] 1714 	mov	r3,a
      0084A7 EC               [12] 1715 	mov	a,r4
      0084A8 B5 03 02         [24] 1716 	cjne	a,ar3,00142$
      0084AB 80 0B            [24] 1717 	sjmp	00108$
      0084AD                       1718 00142$:
                                   1719 ;	quantum/action_util.c:525: dest[i] = src[i];
      0084AD 12 38 6A         [24] 1720 	lcall	_ak820_outline_0137
      0084B0 EB               [12] 1721 	mov	a,r3
      0084B1 F0               [24] 1722 	movx	@dptr,a
                                   1723 ;	quantum/action_util.c:526: changed = true;
      0084B2 90 0B 7B         [24] 1724 	mov	dptr,#_send_keyboard_report_changed_10001_388
      0084B5 74 01            [12] 1725 	mov	a,#0x01
      0084B7 F0               [24] 1726 	movx	@dptr,a
      0084B8                       1727 00108$:
                                   1728 ;	quantum/action_util.c:523: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      0084B8 0F               [12] 1729 	inc	r7
      0084B9 80 D0            [24] 1730 	sjmp	00107$
      0084BB                       1731 00103$:
                                   1732 ;	quantum/action_util.c:529: if (changed) host_keyboard_send(AK820_REPORT_OUT);
      0084BB 90 0B 7B         [24] 1733 	mov	dptr,#_send_keyboard_report_changed_10001_388
      0084BE E0               [24] 1734 	movx	a,@dptr
      0084BF 60 09            [24] 1735 	jz	00109$
      0084C1 90 0E 85         [24] 1736 	mov	dptr,#_actual_keyboard_report
      0084C4 75 F0 00         [24] 1737 	mov	b, #0x00
                                   1738 ;	quantum/action_util.c:538: }
      0084C7 02 71 6A         [24] 1739 	ljmp	_host_keyboard_send
      0084CA                       1740 00109$:
      0084CA 22               [24] 1741 	ret
                                   1742 ;------------------------------------------------------------
                                   1743 ;Allocation info for local variables in function 'get_mods'
                                   1744 ;------------------------------------------------------------
                                   1745 ;	quantum/action_util.c:544: uint8_t get_mods(void) {
                                   1746 ;	-----------------------------------------
                                   1747 ;	 function get_mods
                                   1748 ;	-----------------------------------------
      0084CB                       1749 _get_mods:
      0084CB C0 07            [24] 1750 	push	ar7
                                   1751 ;	quantum/action_util.c:549: ;
      0084CD 90 0A 42         [24] 1752 	mov	dptr,#_owned_mods
      0084D0 E0               [24] 1753 	movx	a,@dptr
      0084D1 FF               [12] 1754 	mov	r7,a
      0084D2 90 0E 83         [24] 1755 	mov	dptr,#_real_mods
      0084D5 12 7F D6         [24] 1756 	lcall	_ak820_outline_0141
                                   1757 ;	quantum/action_util.c:550: }
      0084D8 D0 07            [24] 1758 	pop	ar7
      0084DA 22               [24] 1759 	ret
                                   1760 ;------------------------------------------------------------
                                   1761 ;Allocation info for local variables in function 'add_mods'
                                   1762 ;------------------------------------------------------------
                                   1763 ;mods          Allocated with name '_add_mods_mods_10000_396'
                                   1764 ;------------------------------------------------------------
                                   1765 ;	quantum/action_util.c:555: void add_mods(uint8_t mods) {
                                   1766 ;	-----------------------------------------
                                   1767 ;	 function clear_mods
                                   1768 ;	-----------------------------------------
      0084DB                       1769 _clear_mods:
                                   1770 ;	quantum/action_util.c:577: real_mods = 0;
      0084DB 90 0E 83         [24] 1771 	mov	dptr,#_real_mods
      0084DE E4               [12] 1772 	clr	a
      0084DF F0               [24] 1773 	movx	@dptr,a
                                   1774 ;	quantum/action_util.c:578: }
      0084E0 22               [24] 1775 	ret
                                   1776 ;------------------------------------------------------------
                                   1777 ;Allocation info for local variables in function 'get_weak_mods'
                                   1778 ;------------------------------------------------------------
                                   1779 ;	quantum/action_util.c:584: uint8_t get_weak_mods(void) {
                                   1780 ;	-----------------------------------------
                                   1781 ;	 function get_weak_mods
                                   1782 ;	-----------------------------------------
      0084E1                       1783 _get_weak_mods:
      0084E1 C0 07            [24] 1784 	push	ar7
                                   1785 ;	quantum/action_util.c:589: ;
      0084E3 90 0A 43         [24] 1786 	mov	dptr,#_owned_weak_mods
      0084E6 E0               [24] 1787 	movx	a,@dptr
      0084E7 FF               [12] 1788 	mov	r7,a
      0084E8 90 0E 84         [24] 1789 	mov	dptr,#_weak_mods
      0084EB 12 7F D6         [24] 1790 	lcall	_ak820_outline_0141
                                   1791 ;	quantum/action_util.c:590: }
      0084EE D0 07            [24] 1792 	pop	ar7
      0084F0 22               [24] 1793 	ret
                                   1794 ;------------------------------------------------------------
                                   1795 ;Allocation info for local variables in function 'add_weak_mods'
                                   1796 ;------------------------------------------------------------
                                   1797 ;mods          Allocated with name '_add_weak_mods_mods_10000_406'
                                   1798 ;------------------------------------------------------------
                                   1799 ;	quantum/action_util.c:595: void add_weak_mods(uint8_t mods) {
                                   1800 ;	-----------------------------------------
                                   1801 ;	 function add_weak_mods
                                   1802 ;	-----------------------------------------
      0084F1                       1803 _add_weak_mods:
      0084F1 E5 82            [12] 1804 	mov	a,dpl
      0084F3 90 0B 7C         [24] 1805 	mov	dptr,#_add_weak_mods_mods_10000_406
      0084F6 F0               [24] 1806 	movx	@dptr,a
                                   1807 ;	quantum/action_util.c:596: weak_mods |= mods;
      0084F7 E0               [24] 1808 	movx	a,@dptr
      0084F8 FF               [12] 1809 	mov	r7,a
      0084F9 90 0E 84         [24] 1810 	mov	dptr,#_weak_mods
      0084FC E0               [24] 1811 	movx	a,@dptr
      0084FD 4F               [12] 1812 	orl	a,r7
      0084FE F0               [24] 1813 	movx	@dptr,a
                                   1814 ;	quantum/action_util.c:597: }
      0084FF 22               [24] 1815 	ret
                                   1816 ;------------------------------------------------------------
                                   1817 ;Allocation info for local variables in function 'del_weak_mods'
                                   1818 ;------------------------------------------------------------
                                   1819 ;mods          Allocated with name '_del_weak_mods_mods_10000_408'
                                   1820 ;------------------------------------------------------------
                                   1821 ;	quantum/action_util.c:602: void del_weak_mods(uint8_t mods) {
                                   1822 ;	-----------------------------------------
                                   1823 ;	 function del_weak_mods
                                   1824 ;	-----------------------------------------
      008500                       1825 _del_weak_mods:
      008500 E5 82            [12] 1826 	mov	a,dpl
      008502 90 0B 7D         [24] 1827 	mov	dptr,#_del_weak_mods_mods_10000_408
      008505 F0               [24] 1828 	movx	@dptr,a
                                   1829 ;	quantum/action_util.c:603: weak_mods &= ~mods;
      008506 E0               [24] 1830 	movx	a,@dptr
      008507 F4               [12] 1831 	cpl	a
      008508 FF               [12] 1832 	mov	r7,a
      008509 90 0E 84         [24] 1833 	mov	dptr,#_weak_mods
      00850C E0               [24] 1834 	movx	a,@dptr
      00850D 5F               [12] 1835 	anl	a,r7
      00850E F0               [24] 1836 	movx	@dptr,a
                                   1837 ;	quantum/action_util.c:604: }
      00850F 22               [24] 1838 	ret
                                   1839 ;------------------------------------------------------------
                                   1840 ;Allocation info for local variables in function 'set_weak_mods'
                                   1841 ;------------------------------------------------------------
                                   1842 ;mods          Allocated with name '_set_weak_mods_mods_10000_410'
                                   1843 ;------------------------------------------------------------
                                   1844 ;	quantum/action_util.c:609: void set_weak_mods(uint8_t mods) {
                                   1845 ;	-----------------------------------------
                                   1846 ;	 function clear_weak_mods
                                   1847 ;	-----------------------------------------
      008510                       1848 _clear_weak_mods:
                                   1849 ;	quantum/action_util.c:617: weak_mods = 0;
      008510 90 0E 84         [24] 1850 	mov	dptr,#_weak_mods
      008513 E4               [12] 1851 	clr	a
      008514 F0               [24] 1852 	movx	@dptr,a
                                   1853 ;	quantum/action_util.c:618: }
      008515 22               [24] 1854 	ret
                                   1855 ;------------------------------------------------------------
                                   1856 ;Allocation info for local variables in function 'oneshot_locked_mods_changed_user'
                                   1857 ;------------------------------------------------------------
                                   1858 ;mods          Allocated with name '_oneshot_locked_mods_changed_user_mods_10000_414'
                                   1859 ;------------------------------------------------------------
                                   1860 ;	quantum/action_util.c:700: __attribute__((weak)) void oneshot_locked_mods_changed_user(uint8_t mods) {}
                                   1861 ;	-----------------------------------------
                                   1862 	.area CSEG    (CODE)
                                   1863 	.area CONST   (CODE)
                                   1864 	.area XINIT   (CODE)
      00C632                       1865 __xinit__real_mods:
      00C632 00                    1866 	.db #0x00	; 0
      00C633                       1867 __xinit__weak_mods:
      00C633 00                    1868 	.db #0x00	; 0
      00C634                       1869 __xinit__actual_keyboard_report:
      00C634 00                    1870 	.db #0x00	; 0
      00C635 00                    1871 	.db #0x00	; 0
      00C636 00                    1872 	.db #0x00	; 0
      00C637 00                    1873 	.db #0x00	; 0
      00C638 00                    1874 	.db #0x00	; 0
      00C639 00                    1875 	.db #0x00	; 0
      00C63A 00                    1876 	.db #0x00	; 0
      00C63B 00                    1877 	.db #0x00	; 0
      00C63C 00                    1878 	.db 0x00
      00C63D 00                    1879 	.db 0x00
      00C63E 00                    1880 	.db 0x00
      00C63F 00                    1881 	.db 0x00
      00C640 00                    1882 	.db 0x00
      00C641 00                    1883 	.db 0x00
      00C642 00                    1884 	.db 0x00
      00C643 00                    1885 	.db 0x00
      00C644 00                    1886 	.db 0x00
      00C645 00                    1887 	.db 0x00
      00C646 00                    1888 	.db 0x00
      00C647 00                    1889 	.db 0x00
      00C648 00                    1890 	.db 0x00
      00C649 00                    1891 	.db 0x00
      00C64A 00                    1892 	.db 0x00
      00C64B 00                    1893 	.db 0x00
      00C64C 00                    1894 	.db 0x00
      00C64D 00                    1895 	.db 0x00
      00C64E 00                    1896 	.db 0x00
      00C64F 00                    1897 	.db 0x00
      00C650 00                    1898 	.db 0x00
      00C651 00                    1899 	.db 0x00
      00C652 00                    1900 	.db 0x00
      00C653 00                    1901 	.db 0x00
                                   1902 	.area CABS    (ABS,CODE)
                                   1903 
                                   1904 ; Experimental exact instruction outlining.
                                   1905 	.globl _ak820_outline_0016
                                   1906 	.globl _ak820_outline_0030
                                   1907 	.globl _ak820_outline_0049
                                   1908 	.globl _ak820_outline_0063
                                   1909 	.globl _ak820_outline_0065
                                   1910 	.globl _ak820_outline_0068
                                   1911 	.globl _ak820_outline_0069
                                   1912 	.globl _ak820_outline_0072
                                   1913 	.globl _ak820_outline_0076
                                   1914 	.globl _ak820_outline_0078
                                   1915 	.globl _ak820_outline_0105
                                   1916 	.globl _ak820_outline_0106
                                   1917 	.globl _ak820_outline_0118
                                   1918 	.globl _ak820_outline_0124
                                   1919 	.globl _ak820_outline_0126
                                   1920 	.globl _ak820_outline_0127
                                   1921 	.globl _ak820_outline_0128
                                   1922 	.globl _ak820_outline_0134
                                   1923 	.globl _ak820_outline_0137
                                   1924 	.globl _ak820_outline_0139
                                   1925 	.globl _ak820_outline_0141
                                   1926 	.globl _ak820_outline_0143
                                   1927 	.globl _ak820_outline_0158
                                   1928 	.globl _ak820_outline_0159
                                   1929 	.globl _ak820_outline_0165
                                   1930 	.globl _ak820_outline_0177
                                   1931 	.globl _ak820_outline_0188
                                   1932 	.globl _ak820_outline_0190
                                   1933 
                                   1934 	.area CSEG (CODE)
                                   1935 ; function ak820_outline_0030
      008516                       1936 _ak820_outline_0030:
      008516 EF               [12] 1937 	mov	a,r7
      008517 24 54            [12] 1938 	add	a,#_key_refs
      008519 FD               [12] 1939 	mov	r5,a
      00851A E4               [12] 1940 	clr	a
      00851B 34 0A            [12] 1941 	addc	a,#(_key_refs>>8)
      00851D FE               [12] 1942 	mov	r6,a
      00851E 8D 82            [24] 1943 	mov	dpl,r5
      008520 8E 83            [24] 1944 	mov	dph,r6
      008522 E0               [24] 1945 	movx	a,@dptr
      008523 22               [24] 1946 	ret
                                   1947 
                                   1948 	.area CSEG (CODE)
                                   1949 ; function ak820_outline_0072
      008524                       1950 _ak820_outline_0072:
      008524 24 2F            [12] 1951 	add	a,#_usage_order
      008526 F5 82            [12] 1952 	mov	dpl,a
      008528 E4               [12] 1953 	clr	a
      008529 34 0B            [12] 1954 	addc	a,#(_usage_order>>8)
      00852B F5 83            [12] 1955 	mov	dph,a
      00852D 22               [24] 1956 	ret
                                   1957 
                                   1958 	.area CSEG (CODE)
                                   1959 ; function ak820_outline_0076
      00852E                       1960 _ak820_outline_0076:
      00852E EB               [12] 1961 	mov	a,r3
      00852F 24 11            [12] 1962 	add	a,#_usage_refs
      008531 F9               [12] 1963 	mov	r1,a
      008532 E4               [12] 1964 	clr	a
      008533 34 0B            [12] 1965 	addc	a,#(_usage_refs>>8)
      008535 FA               [12] 1966 	mov	r2,a
      008536 89 82            [24] 1967 	mov	dpl,r1
      008538 8A 83            [24] 1968 	mov	dph,r2
      00853A E0               [24] 1969 	movx	a,@dptr
      00853B F8               [12] 1970 	mov	r0,a
      00853C 22               [24] 1971 	ret
                                   1972 
                                   1973 	.area CSEG (CODE)
                                   1974 ; function ak820_outline_0118
      00853D                       1975 _ak820_outline_0118:
      00853D F0               [24] 1976 	movx	@dptr,a
      00853E E0               [24] 1977 	movx	a,@dptr
      00853F FF               [12] 1978 	mov	r7,a
      008540 90 0A 4C         [24] 1979 	mov	dptr,#_change_owned_PARM_2
      008543 22               [24] 1980 	ret
                                   1981 
                                   1982 	.area CSEG (CODE)
                                   1983 ; function ak820_outline_0126
      008544                       1984 _ak820_outline_0126:
      008544 8D 82            [24] 1985 	mov	dpl,r5
      008546 8E 83            [24] 1986 	mov	dph,r6
      008548 F0               [24] 1987 	movx	@dptr,a
      008549 22               [24] 1988 	ret
                                   1989 
                                   1990 	.area CSEG (CODE)
                                   1991 ; function ak820_outline_0128
      00854A                       1992 _ak820_outline_0128:
      00854A 24 2F            [12] 1993 	add	a,#_usage_order
      00854C F5 82            [12] 1994 	mov	dpl,a
      00854E EF               [12] 1995 	mov	a,r7
      00854F 34 0B            [12] 1996 	addc	a,#(_usage_order>>8)
      008551 F5 83            [12] 1997 	mov	dph,a
      008553 E0               [24] 1998 	movx	a,@dptr
      008554 22               [24] 1999 	ret
                                   2000 
                                   2001 	.area CSEG (CODE)
                                   2002 ; function ak820_outline_0134
      008555                       2003 _ak820_outline_0134:
      008555 F0               [24] 2004 	movx	@dptr,a
      008556 E0               [24] 2005 	movx	a,@dptr
      008557 FF               [12] 2006 	mov	r7,a
      008558 90 0A 48         [24] 2007 	mov	dptr,#_ak820_macro_change_PARM_2
      00855B F0               [24] 2008 	movx	@dptr,a
      00855C 90 0A 49         [24] 2009 	mov	dptr,#_ak820_macro_change_PARM_3
      00855F 22               [24] 2010 	ret
                                   2011 
                                   2012 	.area CSEG (CODE)
                                   2013 ; function ak820_outline_0177
      008560                       2014 _ak820_outline_0177:
      008560 90 08 C5         [24] 2015 	mov	dptr,#_add_key_to_report_PARM_2
      008563 EF               [12] 2016 	mov	a,r7
      008564 F0               [24] 2017 	movx	@dptr,a
      008565 90 0E 85         [24] 2018 	mov	dptr,#_actual_keyboard_report
      008568 22               [24] 2019 	ret
                                   2020 
                                   2021 	.area CSEG (CODE)
                                   2022 ; function ak820_outline_0190
      008569                       2023 _ak820_outline_0190:
      008569 8D 82            [24] 2024 	mov	dpl,r5
      00856B 8F 83            [24] 2025 	mov	dph,r7
      00856D 22               [24] 2026 	ret
