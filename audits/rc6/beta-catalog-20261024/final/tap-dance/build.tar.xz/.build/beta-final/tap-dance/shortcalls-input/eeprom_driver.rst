                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module eeprom_driver
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_eeprom_write_block_xdata
                                     12 	.globl _ak820_eeprom_read_block_xdata
                                     13 	.globl _eeprom_read_byte
                                     14 	.globl _eeprom_update_dword_PARM_2
                                     15 	.globl _eeprom_update_word_PARM_2
                                     16 	.globl _eeprom_update_byte_PARM_2
                                     17 	.globl _eeprom_write_dword_PARM_2
                                     18 	.globl _eeprom_write_word_PARM_2
                                     19 	.globl _eeprom_write_byte_PARM_2
                                     20 	.globl _eeprom_read_word
                                     21 	.globl _eeprom_read_dword
                                     22 	.globl _eeprom_write_byte
                                     23 	.globl _eeprom_write_word
                                     24 	.globl _eeprom_write_dword
                                     25 	.globl _eeprom_update_byte
                                     26 	.globl _eeprom_update_word
                                     27 	.globl _eeprom_update_dword
                                     28 ;--------------------------------------------------------
                                     29 ; special function registers
                                     30 ;--------------------------------------------------------
                                     31 	.area RSEG    (ABS,DATA)
      000000                         32 	.org 0x0000
                                     33 ;--------------------------------------------------------
                                     34 ; special function bits
                                     35 ;--------------------------------------------------------
                                     36 	.area RSEG    (ABS,DATA)
      000000                         37 	.org 0x0000
                                     38 ;--------------------------------------------------------
                                     39 ; overlayable register banks
                                     40 ;--------------------------------------------------------
                                     41 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         42 	.ds 8
                                     43 ;--------------------------------------------------------
                                     44 ; overlayable bit register bank
                                     45 ;--------------------------------------------------------
                                     46 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         47 bits:
      000026                         48 	.ds 1
                           008000    49 	b0 = bits[0]
                           008100    50 	b1 = bits[1]
                           008200    51 	b2 = bits[2]
                           008300    52 	b3 = bits[3]
                           008400    53 	b4 = bits[4]
                           008500    54 	b5 = bits[5]
                           008600    55 	b6 = bits[6]
                           008700    56 	b7 = bits[7]
                                     57 ;--------------------------------------------------------
                                     58 ; internal ram data
                                     59 ;--------------------------------------------------------
                                     60 	.area DSEG    (DATA)
                                     61 ;--------------------------------------------------------
                                     62 ; overlayable items in internal ram
                                     63 ;--------------------------------------------------------
                                     64 ;--------------------------------------------------------
                                     65 ; indirectly addressable internal ram data
                                     66 ;--------------------------------------------------------
                                     67 	.area ISEG    (DATA)
                                     68 ;--------------------------------------------------------
                                     69 ; absolute internal ram data
                                     70 ;--------------------------------------------------------
                                     71 	.area IABS    (ABS,DATA)
                                     72 	.area IABS    (ABS,DATA)
                                     73 ;--------------------------------------------------------
                                     74 ; bit data
                                     75 ;--------------------------------------------------------
                                     76 	.area BSEG    (BIT)
                                     77 ;--------------------------------------------------------
                                     78 ; paged external ram data
                                     79 ;--------------------------------------------------------
                                     80 	.area PSEG    (PAG,XDATA)
                                     81 ;--------------------------------------------------------
                                     82 ; uninitialized external ram data
                                     83 ;--------------------------------------------------------
                                     84 	.area XSEG    (XDATA)
      000745                         85 _eeprom_read_word_addr_10000_91:
      000745                         86 	.ds 3
      000748                         87 _eeprom_read_word_ret_10000_92:
      000748                         88 	.ds 2
      00074A                         89 _eeprom_read_dword_addr_10000_93:
      00074A                         90 	.ds 3
      00074D                         91 _eeprom_read_dword_ret_10000_94:
      00074D                         92 	.ds 4
      000751                         93 _eeprom_write_byte_PARM_2:
      000751                         94 	.ds 1
      000752                         95 _eeprom_write_byte_addr_10000_95:
      000752                         96 	.ds 3
      000755                         97 _eeprom_write_word_PARM_2:
      000755                         98 	.ds 2
      000757                         99 _eeprom_write_word_addr_10000_97:
      000757                        100 	.ds 3
      00075A                        101 _eeprom_write_dword_PARM_2:
      00075A                        102 	.ds 4
      00075E                        103 _eeprom_write_dword_addr_10000_99:
      00075E                        104 	.ds 3
      000761                        105 _eeprom_update_byte_PARM_2:
      000761                        106 	.ds 1
      000762                        107 _eeprom_update_byte_addr_10000_107:
      000762                        108 	.ds 3
      000765                        109 _eeprom_update_word_PARM_2:
      000765                        110 	.ds 2
      000767                        111 _eeprom_update_word_addr_10000_111:
      000767                        112 	.ds 3
      00076A                        113 _eeprom_update_dword_PARM_2:
      00076A                        114 	.ds 4
      00076E                        115 _eeprom_update_dword_addr_10000_115:
      00076E                        116 	.ds 3
                                    117 ;--------------------------------------------------------
                                    118 ; absolute external ram data
                                    119 ;--------------------------------------------------------
                                    120 	.area XABS    (ABS,XDATA)
                                    121 ;--------------------------------------------------------
                                    122 ; initialized external ram data
                                    123 ;--------------------------------------------------------
                                    124 	.area XISEG   (XDATA)
                                    125 	.area HOME    (CODE)
                                    126 	.area GSINIT0 (CODE)
                                    127 	.area GSINIT1 (CODE)
                                    128 	.area GSINIT2 (CODE)
                                    129 	.area GSINIT3 (CODE)
                                    130 	.area GSINIT4 (CODE)
                                    131 	.area GSINIT5 (CODE)
                                    132 	.area GSINIT  (CODE)
                                    133 	.area GSFINAL (CODE)
                                    134 	.area CSEG    (CODE)
                                    135 ;--------------------------------------------------------
                                    136 ; global & static initialisations
                                    137 ;--------------------------------------------------------
                                    138 	.area HOME    (CODE)
                                    139 	.area GSINIT  (CODE)
                                    140 	.area GSFINAL (CODE)
                                    141 	.area GSINIT  (CODE)
                                    142 ;--------------------------------------------------------
                                    143 ; Home
                                    144 ;--------------------------------------------------------
                                    145 	.area HOME    (CODE)
                                    146 	.area HOME    (CODE)
                                    147 ;--------------------------------------------------------
                                    148 ; code
                                    149 ;--------------------------------------------------------
                                    150 	.area CSEG    (CODE)
                                    151 ;------------------------------------------------------------
                                    152 ;Allocation info for local variables in function 'eeprom_read_word'
                                    153 ;------------------------------------------------------------
                                    154 ;addr          Allocated with name '_eeprom_read_word_addr_10000_91'
                                    155 ;ret           Allocated with name '_eeprom_read_word_ret_10000_92'
                                    156 ;------------------------------------------------------------
                                    157 ;	drivers/eeprom/eeprom_driver.c:44: uint16_t eeprom_read_word(const uint16_t *addr) {
                                    158 ;	-----------------------------------------
                                    159 ;	 function eeprom_read_word
                                    160 ;	-----------------------------------------
      00524D                        161 _eeprom_read_word:
                           000007   162 	ar7 = 0x07
                           000006   163 	ar6 = 0x06
                           000005   164 	ar5 = 0x05
                           000004   165 	ar4 = 0x04
                           000003   166 	ar3 = 0x03
                           000002   167 	ar2 = 0x02
                           000001   168 	ar1 = 0x01
                           000000   169 	ar0 = 0x00
      00524D 12 42 DD         [24]  170 	lcall	_ak820_outline_0042
      005250 90 07 45         [24]  171 	mov	dptr,#_eeprom_read_word_addr_10000_91
      005253 12 37 E8         [24]  172 	lcall	_ak820_outline_0018
                                    173 ;	drivers/eeprom/eeprom_driver.c:45: uint16_t ret = 0;
      005256 90 07 48         [24]  174 	mov	dptr,#_eeprom_read_word_ret_10000_92
      005259 12 48 E2         [24]  175 	lcall	_ak820_outline_0143
                                    176 ;	drivers/eeprom/eeprom_driver.c:46: EEPROM_LOCAL_READ(&ret, addr, 2);
      00525C 90 07 45         [24]  177 	mov	dptr,#_eeprom_read_word_addr_10000_91
      00525F 12 54 08         [24]  178 	lcall	_ak820_outline_0023
      005262 90 05 81         [24]  179 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      005265 ED               [12]  180 	mov	a,r5
      005266 12 37 E8         [24]  181 	lcall	_ak820_outline_0018
      005269 90 05 84         [24]  182 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      00526C 12 54 43         [24]  183 	lcall	_ak820_outline_0111
      00526F 90 07 48         [24]  184 	mov	dptr,#_eeprom_read_word_ret_10000_92
      005272 12 40 79         [24]  185 	lcall	_ak820_eeprom_read_block_xdata
                                    186 ;	drivers/eeprom/eeprom_driver.c:47: return ret;
      005275 90 07 48         [24]  187 	mov	dptr,#_eeprom_read_word_ret_10000_92
      005278 12 54 3A         [24]  188 	lcall	_ak820_outline_0094
                                    189 ;	drivers/eeprom/eeprom_driver.c:48: }
      00527B 22               [24]  190 	ret
                                    191 ;------------------------------------------------------------
                                    192 ;Allocation info for local variables in function 'eeprom_read_dword'
                                    193 ;------------------------------------------------------------
                                    194 ;addr          Allocated with name '_eeprom_read_dword_addr_10000_93'
                                    195 ;ret           Allocated with name '_eeprom_read_dword_ret_10000_94'
                                    196 ;------------------------------------------------------------
                                    197 ;	drivers/eeprom/eeprom_driver.c:50: uint32_t eeprom_read_dword(const uint32_t *addr) {
                                    198 ;	-----------------------------------------
                                    199 ;	 function eeprom_read_dword
                                    200 ;	-----------------------------------------
      00527C                        201 _eeprom_read_dword:
      00527C 12 42 DD         [24]  202 	lcall	_ak820_outline_0042
      00527F 90 07 4A         [24]  203 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      005282 12 37 E8         [24]  204 	lcall	_ak820_outline_0018
                                    205 ;	drivers/eeprom/eeprom_driver.c:51: uint32_t ret = 0;
      005285 90 07 4D         [24]  206 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      005288 12 54 18         [24]  207 	lcall	_ak820_outline_0054
                                    208 ;	drivers/eeprom/eeprom_driver.c:52: EEPROM_LOCAL_READ(&ret, addr, 4);
      00528B 90 07 4A         [24]  209 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      00528E 12 54 08         [24]  210 	lcall	_ak820_outline_0023
      005291 90 05 81         [24]  211 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      005294 ED               [12]  212 	mov	a,r5
      005295 12 37 E8         [24]  213 	lcall	_ak820_outline_0018
      005298 90 05 84         [24]  214 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      00529B 74 04            [12]  215 	mov	a,#0x04
      00529D 12 38 65         [24]  216 	lcall	_ak820_outline_0127
      0052A0 90 07 4D         [24]  217 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      0052A3 12 40 79         [24]  218 	lcall	_ak820_eeprom_read_block_xdata
                                    219 ;	drivers/eeprom/eeprom_driver.c:53: return ret;
      0052A6 90 07 4D         [24]  220 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      0052A9 12 54 21         [24]  221 	lcall	_ak820_outline_0059
                                    222 ;	drivers/eeprom/eeprom_driver.c:54: }
      0052AC 22               [24]  223 	ret
                                    224 ;------------------------------------------------------------
                                    225 ;Allocation info for local variables in function 'eeprom_write_byte'
                                    226 ;------------------------------------------------------------
                                    227 ;value         Allocated with name '_eeprom_write_byte_PARM_2'
                                    228 ;addr          Allocated with name '_eeprom_write_byte_addr_10000_95'
                                    229 ;------------------------------------------------------------
                                    230 ;	drivers/eeprom/eeprom_driver.c:56: void eeprom_write_byte(uint8_t *addr, uint8_t value) {
                                    231 ;	-----------------------------------------
                                    232 ;	 function eeprom_write_byte
                                    233 ;	-----------------------------------------
      0052AD                        234 _eeprom_write_byte:
      0052AD 12 42 DD         [24]  235 	lcall	_ak820_outline_0042
      0052B0 90 07 52         [24]  236 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      0052B3 12 37 E8         [24]  237 	lcall	_ak820_outline_0018
                                    238 ;	drivers/eeprom/eeprom_driver.c:57: EEPROM_LOCAL_WRITE(&value, addr, 1);
      0052B6 90 07 52         [24]  239 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      0052B9 12 53 E2         [24]  240 	lcall	_ak820_outline_0003
      0052BC 74 01            [12]  241 	mov	a,#0x01
      0052BE 12 38 65         [24]  242 	lcall	_ak820_outline_0127
      0052C1 90 07 51         [24]  243 	mov	dptr,#_eeprom_write_byte_PARM_2
                                    244 ;	drivers/eeprom/eeprom_driver.c:58: }
      0052C4 02 41 05         [24]  245 	ljmp	_ak820_eeprom_write_block_xdata
                                    246 ;------------------------------------------------------------
                                    247 ;Allocation info for local variables in function 'eeprom_write_word'
                                    248 ;------------------------------------------------------------
                                    249 ;value         Allocated with name '_eeprom_write_word_PARM_2'
                                    250 ;addr          Allocated with name '_eeprom_write_word_addr_10000_97'
                                    251 ;------------------------------------------------------------
                                    252 ;	drivers/eeprom/eeprom_driver.c:60: void eeprom_write_word(uint16_t *addr, uint16_t value) {
                                    253 ;	-----------------------------------------
                                    254 ;	 function eeprom_write_word
                                    255 ;	-----------------------------------------
      0052C7                        256 _eeprom_write_word:
      0052C7 12 42 DD         [24]  257 	lcall	_ak820_outline_0042
      0052CA 90 07 57         [24]  258 	mov	dptr,#_eeprom_write_word_addr_10000_97
      0052CD 12 37 E8         [24]  259 	lcall	_ak820_outline_0018
                                    260 ;	drivers/eeprom/eeprom_driver.c:61: EEPROM_LOCAL_WRITE(&value, addr, 2);
      0052D0 90 07 57         [24]  261 	mov	dptr,#_eeprom_write_word_addr_10000_97
      0052D3 12 53 E2         [24]  262 	lcall	_ak820_outline_0003
      0052D6 12 54 43         [24]  263 	lcall	_ak820_outline_0111
      0052D9 90 07 55         [24]  264 	mov	dptr,#_eeprom_write_word_PARM_2
                                    265 ;	drivers/eeprom/eeprom_driver.c:62: }
      0052DC 02 41 05         [24]  266 	ljmp	_ak820_eeprom_write_block_xdata
                                    267 ;------------------------------------------------------------
                                    268 ;Allocation info for local variables in function 'eeprom_write_dword'
                                    269 ;------------------------------------------------------------
                                    270 ;value         Allocated with name '_eeprom_write_dword_PARM_2'
                                    271 ;addr          Allocated with name '_eeprom_write_dword_addr_10000_99'
                                    272 ;------------------------------------------------------------
                                    273 ;	drivers/eeprom/eeprom_driver.c:64: void eeprom_write_dword(uint32_t *addr, uint32_t value) {
                                    274 ;	-----------------------------------------
                                    275 ;	 function eeprom_write_dword
                                    276 ;	-----------------------------------------
      0052DF                        277 _eeprom_write_dword:
      0052DF 12 42 DD         [24]  278 	lcall	_ak820_outline_0042
      0052E2 90 07 5E         [24]  279 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      0052E5 12 37 E8         [24]  280 	lcall	_ak820_outline_0018
                                    281 ;	drivers/eeprom/eeprom_driver.c:65: EEPROM_LOCAL_WRITE(&value, addr, 4);
      0052E8 90 07 5E         [24]  282 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      0052EB 12 53 E2         [24]  283 	lcall	_ak820_outline_0003
      0052EE 74 04            [12]  284 	mov	a,#0x04
      0052F0 12 38 65         [24]  285 	lcall	_ak820_outline_0127
      0052F3 90 07 5A         [24]  286 	mov	dptr,#_eeprom_write_dword_PARM_2
                                    287 ;	drivers/eeprom/eeprom_driver.c:66: }
      0052F6 02 41 05         [24]  288 	ljmp	_ak820_eeprom_write_block_xdata
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'eeprom_update_block'
                                    291 ;------------------------------------------------------------
                                    292 ;sloc0         Allocated with name '_eeprom_update_block_sloc0_1_0'
                                    293 ;sloc1         Allocated with name '_eeprom_update_block_sloc1_1_0'
                                    294 ;sloc2         Allocated with name '_eeprom_update_block_sloc2_1_0'
                                    295 ;sloc3         Allocated with name '_eeprom_update_block_sloc3_1_0'
                                    296 ;addr          Allocated with name '_eeprom_update_block_PARM_2'
                                    297 ;len           Allocated with name '_eeprom_update_block_PARM_3'
                                    298 ;buf           Allocated with name '_eeprom_update_block_buf_10000_101'
                                    299 ;source        Allocated with name '_eeprom_update_block_source_10000_102'
                                    300 ;target        Allocated with name '_eeprom_update_block_target_10000_102'
                                    301 ;i             Allocated with name '_eeprom_update_block_i_10000_102'
                                    302 ;------------------------------------------------------------
                                    303 ;	drivers/eeprom/eeprom_driver.c:68: void eeprom_update_block(const void *buf, void *addr, size_t len) {
                                    304 ;	-----------------------------------------
                                    305 ;	 function eeprom_update_byte
                                    306 ;	-----------------------------------------
      0052F9                        307 _eeprom_update_byte:
      0052F9 C0 07            [24]  308 	push	ar7
      0052FB C0 06            [24]  309 	push	ar6
      0052FD C0 05            [24]  310 	push	ar5
      0052FF C0 04            [24]  311 	push	ar4
      005301 12 42 DD         [24]  312 	lcall	_ak820_outline_0042
      005304 90 07 62         [24]  313 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      005307 12 37 E8         [24]  314 	lcall	_ak820_outline_0018
                                    315 ;	drivers/eeprom/eeprom_driver.c:83: uint8_t orig = eeprom_read_byte(addr);
      00530A 90 07 62         [24]  316 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      00530D 12 53 F9         [24]  317 	lcall	_ak820_outline_0004
      005310 12 40 3E         [24]  318 	lcall	_eeprom_read_byte
      005313 AF 82            [24]  319 	mov	r7, dpl
                                    320 ;	drivers/eeprom/eeprom_driver.c:84: if (orig != value) {
      005315 90 07 61         [24]  321 	mov	dptr,#_eeprom_update_byte_PARM_2
      005318 E0               [24]  322 	movx	a,@dptr
      005319 FE               [12]  323 	mov	r6,a
      00531A EF               [12]  324 	mov	a,r7
      00531B B5 06 02         [24]  325 	cjne	a,ar6,00112$
      00531E 80 36            [24]  326 	sjmp	00103$
      005320                        327 00112$:
                                    328 ;	drivers/eeprom/eeprom_driver.c:85: eeprom_write_byte(addr, value);
      005320 90 07 62         [24]  329 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      005323 12 38 1F         [24]  330 	lcall	_ak820_outline_0065
      005326 A3               [24]  331 	inc	dptr
      005327 E0               [24]  332 	movx	a,@dptr
      005328 FF               [12]  333 	mov	r7,a
      005329 90 07 51         [24]  334 	mov	dptr,#_eeprom_write_byte_PARM_2
      00532C EE               [12]  335 	mov	a,r6
      00532D F0               [24]  336 	movx	@dptr,a
      00532E 12 38 5A         [24]  337 	lcall	_ak820_outline_0123
      005331 8F F0            [24]  338 	mov	b, r7
      005333 C0 07            [24]  339 	push	ar7
      005335 C0 06            [24]  340 	push	ar6
      005337 C0 05            [24]  341 	push	ar5
      005339 C0 04            [24]  342 	push	ar4
      00533B C0 03            [24]  343 	push	ar3
      00533D C0 02            [24]  344 	push	ar2
      00533F C0 01            [24]  345 	push	ar1
      005341 C0 00            [24]  346 	push	ar0
      005343 12 52 AD         [24]  347 	lcall	_eeprom_write_byte
      005346 D0 00            [24]  348 	pop	ar0
      005348 D0 01            [24]  349 	pop	ar1
      00534A D0 02            [24]  350 	pop	ar2
      00534C D0 03            [24]  351 	pop	ar3
      00534E D0 04            [24]  352 	pop	ar4
      005350 D0 05            [24]  353 	pop	ar5
      005352 D0 06            [24]  354 	pop	ar6
      005354 D0 07            [24]  355 	pop	ar7
      005356                        356 00103$:
                                    357 ;	drivers/eeprom/eeprom_driver.c:87: }
      005356 D0 04            [24]  358 	pop	ar4
      005358 D0 05            [24]  359 	pop	ar5
      00535A D0 06            [24]  360 	pop	ar6
      00535C D0 07            [24]  361 	pop	ar7
      00535E 22               [24]  362 	ret
                                    363 ;------------------------------------------------------------
                                    364 ;Allocation info for local variables in function 'eeprom_update_word'
                                    365 ;------------------------------------------------------------
                                    366 ;value         Allocated with name '_eeprom_update_word_PARM_2'
                                    367 ;addr          Allocated with name '_eeprom_update_word_addr_10000_111'
                                    368 ;orig          Allocated with name '_eeprom_update_word_orig_10000_112'
                                    369 ;------------------------------------------------------------
                                    370 ;	drivers/eeprom/eeprom_driver.c:89: void eeprom_update_word(uint16_t *addr, uint16_t value) {
                                    371 ;	-----------------------------------------
                                    372 ;	 function eeprom_update_word
                                    373 ;	-----------------------------------------
      00535F                        374 _eeprom_update_word:
      00535F 12 42 DD         [24]  375 	lcall	_ak820_outline_0042
      005362 90 07 67         [24]  376 	mov	dptr,#_eeprom_update_word_addr_10000_111
      005365 12 37 E8         [24]  377 	lcall	_ak820_outline_0018
                                    378 ;	drivers/eeprom/eeprom_driver.c:90: uint16_t orig = eeprom_read_word(addr);
      005368 90 07 67         [24]  379 	mov	dptr,#_eeprom_update_word_addr_10000_111
      00536B 12 53 F9         [24]  380 	lcall	_ak820_outline_0004
      00536E 12 52 4D         [24]  381 	lcall	_eeprom_read_word
      005371 12 43 36         [24]  382 	lcall	_ak820_outline_0136
                                    383 ;	drivers/eeprom/eeprom_driver.c:91: if (orig != value) {
      005374 90 07 65         [24]  384 	mov	dptr,#_eeprom_update_word_PARM_2
      005377 12 38 1F         [24]  385 	lcall	_ak820_outline_0065
      00537A EE               [12]  386 	mov	a,r6
      00537B B5 04 05         [24]  387 	cjne	a,ar4,00112$
      00537E EF               [12]  388 	mov	a,r7
      00537F B5 05 01         [24]  389 	cjne	a,ar5,00112$
      005382 22               [24]  390 	ret
      005383                        391 00112$:
                                    392 ;	drivers/eeprom/eeprom_driver.c:92: eeprom_write_word(addr, value);
      005383 90 07 67         [24]  393 	mov	dptr,#_eeprom_update_word_addr_10000_111
      005386 E0               [24]  394 	movx	a,@dptr
      005387 FB               [12]  395 	mov	r3,a
      005388 A3               [24]  396 	inc	dptr
      005389 12 38 00         [24]  397 	lcall	_ak820_outline_0056
      00538C 90 07 55         [24]  398 	mov	dptr,#_eeprom_write_word_PARM_2
      00538F 12 38 2B         [24]  399 	lcall	_ak820_outline_0077
      005392 8B 82            [24]  400 	mov	dpl, r3
      005394 8E 83            [24]  401 	mov	dph, r6
      005396 8F F0            [24]  402 	mov	b, r7
                                    403 ;	drivers/eeprom/eeprom_driver.c:94: }
      005398 02 52 C7         [24]  404 	ljmp	_eeprom_write_word
                                    405 ;------------------------------------------------------------
                                    406 ;Allocation info for local variables in function 'eeprom_update_dword'
                                    407 ;------------------------------------------------------------
                                    408 ;value         Allocated with name '_eeprom_update_dword_PARM_2'
                                    409 ;addr          Allocated with name '_eeprom_update_dword_addr_10000_115'
                                    410 ;orig          Allocated with name '_eeprom_update_dword_orig_10000_116'
                                    411 ;------------------------------------------------------------
                                    412 ;	drivers/eeprom/eeprom_driver.c:96: void eeprom_update_dword(uint32_t *addr, uint32_t value) {
                                    413 ;	-----------------------------------------
                                    414 ;	 function eeprom_update_dword
                                    415 ;	-----------------------------------------
      00539B                        416 _eeprom_update_dword:
      00539B 12 42 DD         [24]  417 	lcall	_ak820_outline_0042
      00539E 90 07 6E         [24]  418 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      0053A1 12 37 E8         [24]  419 	lcall	_ak820_outline_0018
                                    420 ;	drivers/eeprom/eeprom_driver.c:97: uint32_t orig = eeprom_read_dword(addr);
      0053A4 90 07 6E         [24]  421 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      0053A7 12 53 F9         [24]  422 	lcall	_ak820_outline_0004
      0053AA 12 52 7C         [24]  423 	lcall	_eeprom_read_dword
      0053AD 12 54 32         [24]  424 	lcall	_ak820_outline_0061
                                    425 ;	drivers/eeprom/eeprom_driver.c:98: if (orig != value) {
      0053B0 90 07 6A         [24]  426 	mov	dptr,#_eeprom_update_dword_PARM_2
      0053B3 12 38 44         [24]  427 	lcall	_ak820_outline_0102
      0053B6 A3               [24]  428 	inc	dptr
      0053B7 12 43 0E         [24]  429 	lcall	_ak820_outline_0082
      0053BA EC               [12]  430 	mov	a,r4
      0053BB B5 00 0D         [24]  431 	cjne	a,ar0,00112$
      0053BE ED               [12]  432 	mov	a,r5
      0053BF B5 01 09         [24]  433 	cjne	a,ar1,00112$
      0053C2 EE               [12]  434 	mov	a,r6
      0053C3 B5 02 05         [24]  435 	cjne	a,ar2,00112$
      0053C6 EF               [12]  436 	mov	a,r7
      0053C7 B5 03 01         [24]  437 	cjne	a,ar3,00112$
      0053CA 22               [24]  438 	ret
      0053CB                        439 00112$:
                                    440 ;	drivers/eeprom/eeprom_driver.c:99: eeprom_write_dword(addr, value);
      0053CB 90 07 6E         [24]  441 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      0053CE 12 54 08         [24]  442 	lcall	_ak820_outline_0023
      0053D1 90 07 5A         [24]  443 	mov	dptr,#_eeprom_write_dword_PARM_2
      0053D4 E8               [12]  444 	mov	a,r0
      0053D5 F0               [24]  445 	movx	@dptr,a
      0053D6 E9               [12]  446 	mov	a,r1
      0053D7 A3               [24]  447 	inc	dptr
      0053D8 12 54 4A         [24]  448 	lcall	_ak820_outline_0157
      0053DB F0               [24]  449 	movx	@dptr,a
      0053DC 12 54 11         [24]  450 	lcall	_ak820_outline_0050
                                    451 ;	drivers/eeprom/eeprom_driver.c:101: }
      0053DF 02 52 DF         [24]  452 	ljmp	_eeprom_write_dword
                                    453 	.area CSEG    (CODE)
                                    454 	.area CONST   (CODE)
                                    455 	.area XINIT   (CODE)
                                    456 	.area CABS    (ABS,CODE)
                                    457 
                                    458 ; Experimental exact instruction outlining.
                                    459 	.globl _ak820_outline_0003
                                    460 	.globl _ak820_outline_0004
                                    461 	.globl _ak820_outline_0018
                                    462 	.globl _ak820_outline_0023
                                    463 	.globl _ak820_outline_0042
                                    464 	.globl _ak820_outline_0050
                                    465 	.globl _ak820_outline_0054
                                    466 	.globl _ak820_outline_0056
                                    467 	.globl _ak820_outline_0059
                                    468 	.globl _ak820_outline_0061
                                    469 	.globl _ak820_outline_0065
                                    470 	.globl _ak820_outline_0077
                                    471 	.globl _ak820_outline_0082
                                    472 	.globl _ak820_outline_0094
                                    473 	.globl _ak820_outline_0102
                                    474 	.globl _ak820_outline_0111
                                    475 	.globl _ak820_outline_0123
                                    476 	.globl _ak820_outline_0127
                                    477 	.globl _ak820_outline_0136
                                    478 	.globl _ak820_outline_0143
                                    479 	.globl _ak820_outline_0157
                                    480 
                                    481 	.area CSEG (CODE)
                                    482 ; function ak820_outline_0003
      0053E2                        483 _ak820_outline_0003:
      0053E2 E0               [24]  484 	movx	a,@dptr
      0053E3 FD               [12]  485 	mov	r5,a
      0053E4 A3               [24]  486 	inc	dptr
      0053E5 E0               [24]  487 	movx	a,@dptr
      0053E6 FE               [12]  488 	mov	r6,a
      0053E7 A3               [24]  489 	inc	dptr
      0053E8 E0               [24]  490 	movx	a,@dptr
      0053E9 FF               [12]  491 	mov	r7,a
      0053EA 90 05 8A         [24]  492 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      0053ED ED               [12]  493 	mov	a,r5
      0053EE F0               [24]  494 	movx	@dptr,a
      0053EF EE               [12]  495 	mov	a,r6
      0053F0 A3               [24]  496 	inc	dptr
      0053F1 F0               [24]  497 	movx	@dptr,a
      0053F2 EF               [12]  498 	mov	a,r7
      0053F3 A3               [24]  499 	inc	dptr
      0053F4 F0               [24]  500 	movx	@dptr,a
      0053F5 90 05 8D         [24]  501 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0053F8 22               [24]  502 	ret
                                    503 
                                    504 	.area CSEG (CODE)
                                    505 ; function ak820_outline_0004
      0053F9                        506 _ak820_outline_0004:
      0053F9 E0               [24]  507 	movx	a,@dptr
      0053FA FD               [12]  508 	mov	r5,a
      0053FB A3               [24]  509 	inc	dptr
      0053FC E0               [24]  510 	movx	a,@dptr
      0053FD FE               [12]  511 	mov	r6,a
      0053FE A3               [24]  512 	inc	dptr
      0053FF E0               [24]  513 	movx	a,@dptr
      005400 FF               [12]  514 	mov	r7,a
      005401 8D 82            [24]  515 	mov	dpl,r5
      005403 8E 83            [24]  516 	mov	dph,r6
      005405 8F F0            [24]  517 	mov	b,r7
      005407 22               [24]  518 	ret
                                    519 
                                    520 	.area CSEG (CODE)
                                    521 ; function ak820_outline_0023
      005408                        522 _ak820_outline_0023:
      005408 E0               [24]  523 	movx	a,@dptr
      005409 FD               [12]  524 	mov	r5,a
      00540A A3               [24]  525 	inc	dptr
      00540B E0               [24]  526 	movx	a,@dptr
      00540C FE               [12]  527 	mov	r6,a
      00540D A3               [24]  528 	inc	dptr
      00540E E0               [24]  529 	movx	a,@dptr
      00540F FF               [12]  530 	mov	r7,a
      005410 22               [24]  531 	ret
                                    532 
                                    533 	.area CSEG (CODE)
                                    534 ; function ak820_outline_0050
      005411                        535 _ak820_outline_0050:
      005411 8D 82            [24]  536 	mov	dpl,r5
      005413 8E 83            [24]  537 	mov	dph,r6
      005415 8F F0            [24]  538 	mov	b,r7
      005417 22               [24]  539 	ret
                                    540 
                                    541 	.area CSEG (CODE)
                                    542 ; function ak820_outline_0054
      005418                        543 _ak820_outline_0054:
      005418 E4               [12]  544 	clr	a
      005419 F0               [24]  545 	movx	@dptr,a
      00541A A3               [24]  546 	inc	dptr
      00541B F0               [24]  547 	movx	@dptr,a
      00541C A3               [24]  548 	inc	dptr
      00541D F0               [24]  549 	movx	@dptr,a
      00541E A3               [24]  550 	inc	dptr
      00541F F0               [24]  551 	movx	@dptr,a
      005420 22               [24]  552 	ret
                                    553 
                                    554 	.area CSEG (CODE)
                                    555 ; function ak820_outline_0059
      005421                        556 _ak820_outline_0059:
      005421 E0               [24]  557 	movx	a,@dptr
      005422 FC               [12]  558 	mov	r4,a
      005423 A3               [24]  559 	inc	dptr
      005424 E0               [24]  560 	movx	a,@dptr
      005425 FD               [12]  561 	mov	r5,a
      005426 A3               [24]  562 	inc	dptr
      005427 E0               [24]  563 	movx	a,@dptr
      005428 FE               [12]  564 	mov	r6,a
      005429 A3               [24]  565 	inc	dptr
      00542A E0               [24]  566 	movx	a,@dptr
      00542B 8C 82            [24]  567 	mov	dpl,r4
      00542D 8D 83            [24]  568 	mov	dph,r5
      00542F 8E F0            [24]  569 	mov	b,r6
      005431 22               [24]  570 	ret
                                    571 
                                    572 	.area CSEG (CODE)
                                    573 ; function ak820_outline_0061
      005432                        574 _ak820_outline_0061:
      005432 AC 82            [24]  575 	mov	r4,dpl
      005434 AD 83            [24]  576 	mov	r5,dph
      005436 AE F0            [24]  577 	mov	r6,b
      005438 FF               [12]  578 	mov	r7,a
      005439 22               [24]  579 	ret
                                    580 
                                    581 	.area CSEG (CODE)
                                    582 ; function ak820_outline_0094
      00543A                        583 _ak820_outline_0094:
      00543A E0               [24]  584 	movx	a,@dptr
      00543B FE               [12]  585 	mov	r6,a
      00543C A3               [24]  586 	inc	dptr
      00543D E0               [24]  587 	movx	a,@dptr
      00543E 8E 82            [24]  588 	mov	dpl,r6
      005440 F5 83            [12]  589 	mov	dph,a
      005442 22               [24]  590 	ret
                                    591 
                                    592 	.area CSEG (CODE)
                                    593 ; function ak820_outline_0111
      005443                        594 _ak820_outline_0111:
      005443 74 02            [12]  595 	mov	a,#0x02
      005445 F0               [24]  596 	movx	@dptr,a
      005446 E4               [12]  597 	clr	a
      005447 A3               [24]  598 	inc	dptr
      005448 F0               [24]  599 	movx	@dptr,a
      005449 22               [24]  600 	ret
                                    601 
                                    602 	.area CSEG (CODE)
                                    603 ; function ak820_outline_0157
      00544A                        604 _ak820_outline_0157:
      00544A F0               [24]  605 	movx	@dptr,a
      00544B EA               [12]  606 	mov	a,r2
      00544C A3               [24]  607 	inc	dptr
      00544D F0               [24]  608 	movx	@dptr,a
      00544E EB               [12]  609 	mov	a,r3
      00544F A3               [24]  610 	inc	dptr
      005450 22               [24]  611 	ret
