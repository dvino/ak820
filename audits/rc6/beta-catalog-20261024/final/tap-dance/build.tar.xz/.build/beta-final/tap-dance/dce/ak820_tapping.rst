                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_tapping
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _get_repeat_key_count
                                     12 	.globl _del_owned_mods
                                     13 	.globl _add_owned_mods
                                     14 	.globl _send_keyboard_report
                                     15 	.globl _layer_hold_off
                                     16 	.globl _layer_hold_on
                                     17 	.globl _unregister_mods
                                     18 	.globl _register_mods
                                     19 	.globl _process_record
                                     20 	.globl _ADC_START
                                     21 	.globl _S0_R_FIFO
                                     22 	.globl _S0_T_FIFO
                                     23 	.globl _S0_FREE
                                     24 	.globl _S0_IF_BYTE
                                     25 	.globl _S0_IF_FIRST
                                     26 	.globl _S0_IF_OV
                                     27 	.globl _S0_FST_ACT
                                     28 	.globl _CP_RL2
                                     29 	.globl _C_T2
                                     30 	.globl _TR2
                                     31 	.globl _EXEN2
                                     32 	.globl _TCLK
                                     33 	.globl _RCLK
                                     34 	.globl _EXF2
                                     35 	.globl _CAP1F
                                     36 	.globl _TF2
                                     37 	.globl _RI
                                     38 	.globl _TI
                                     39 	.globl _RB8
                                     40 	.globl _TB8
                                     41 	.globl _REN
                                     42 	.globl _SM2
                                     43 	.globl _SM1
                                     44 	.globl _SM0
                                     45 	.globl _IT0
                                     46 	.globl _IE0
                                     47 	.globl _IT1
                                     48 	.globl _IE1
                                     49 	.globl _TR0
                                     50 	.globl _TF0
                                     51 	.globl _TR1
                                     52 	.globl _TF1
                                     53 	.globl _P4_0
                                     54 	.globl _P4_1
                                     55 	.globl _P4_2
                                     56 	.globl _P4_3
                                     57 	.globl _P4_4
                                     58 	.globl _P4_5
                                     59 	.globl _P4_6
                                     60 	.globl _RXD
                                     61 	.globl _TXD
                                     62 	.globl _INT0
                                     63 	.globl _INT1
                                     64 	.globl _T0
                                     65 	.globl _T1
                                     66 	.globl _MOSI1
                                     67 	.globl _MISO1
                                     68 	.globl _SCK1
                                     69 	.globl _P3_0
                                     70 	.globl _P3_1
                                     71 	.globl _P3_2
                                     72 	.globl _P3_3
                                     73 	.globl _P3_4
                                     74 	.globl _P3_5
                                     75 	.globl _P3_6
                                     76 	.globl _P3_7
                                     77 	.globl _CAP1_
                                     78 	.globl _T2_
                                     79 	.globl _CAP2_
                                     80 	.globl _T2EX_
                                     81 	.globl _RXD1
                                     82 	.globl _TXD1
                                     83 	.globl _P2_0
                                     84 	.globl _P2_1
                                     85 	.globl _P2_2
                                     86 	.globl _P2_3
                                     87 	.globl _P2_4
                                     88 	.globl _P2_5
                                     89 	.globl _P2_6
                                     90 	.globl _P2_7
                                     91 	.globl _AIN0
                                     92 	.globl _AIN1
                                     93 	.globl _AIN2
                                     94 	.globl _AIN3
                                     95 	.globl _AIN4
                                     96 	.globl _AIN5
                                     97 	.globl _AIN6
                                     98 	.globl _AIN7
                                     99 	.globl _CAP1
                                    100 	.globl _T2
                                    101 	.globl _CAP2
                                    102 	.globl _T2EX
                                    103 	.globl _INT0_
                                    104 	.globl _SCS
                                    105 	.globl _MOSI
                                    106 	.globl _MISO
                                    107 	.globl _SCK
                                    108 	.globl _RXD1_
                                    109 	.globl _TXD1_
                                    110 	.globl _P1_0
                                    111 	.globl _P1_1
                                    112 	.globl _P1_2
                                    113 	.globl _P1_3
                                    114 	.globl _P1_4
                                    115 	.globl _P1_5
                                    116 	.globl _P1_6
                                    117 	.globl _P1_7
                                    118 	.globl _AIN8
                                    119 	.globl _AIN9
                                    120 	.globl _AIN10
                                    121 	.globl _AIN11
                                    122 	.globl _AIN12
                                    123 	.globl _AIN13
                                    124 	.globl _RXD_
                                    125 	.globl _TXD_
                                    126 	.globl _SCL0
                                    127 	.globl _SDA0
                                    128 	.globl _P0_0
                                    129 	.globl _P0_1
                                    130 	.globl _P0_2
                                    131 	.globl _P0_3
                                    132 	.globl _P0_4
                                    133 	.globl _P0_5
                                    134 	.globl _P0_6
                                    135 	.globl _P0_7
                                    136 	.globl _IE_SPI0
                                    137 	.globl _IE_USB
                                    138 	.globl _IE_ADC
                                    139 	.globl _IE_UART1
                                    140 	.globl _IE_PWM_I2C
                                    141 	.globl _IE_GPIO
                                    142 	.globl _IE_WDOG
                                    143 	.globl _PX0
                                    144 	.globl _PT0
                                    145 	.globl _PX1
                                    146 	.globl _PT1
                                    147 	.globl _PS
                                    148 	.globl _PT2
                                    149 	.globl _PL_FLAG
                                    150 	.globl _PH_FLAG
                                    151 	.globl _EX0
                                    152 	.globl _ET0
                                    153 	.globl _EX1
                                    154 	.globl _ET1
                                    155 	.globl _ES
                                    156 	.globl _ET2
                                    157 	.globl _E_DIS
                                    158 	.globl _EA
                                    159 	.globl _P
                                    160 	.globl _F1
                                    161 	.globl _OV
                                    162 	.globl _RS0
                                    163 	.globl _RS1
                                    164 	.globl _F0
                                    165 	.globl _AC
                                    166 	.globl _CY
                                    167 	.globl _I2CS_INT_ST
                                    168 	.globl _I2CX_INT
                                    169 	.globl _LED_STATUS
                                    170 	.globl _LED_DMA_H
                                    171 	.globl _LED_DMA_L
                                    172 	.globl _LED_DMA
                                    173 	.globl _LED_PWM_OE
                                    174 	.globl _LED_COMMON
                                    175 	.globl _ADC_CHAN
                                    176 	.globl _ADC_DAT_H
                                    177 	.globl _ADC_DAT_L
                                    178 	.globl _ADC_DAT
                                    179 	.globl _ADC_CTRL
                                    180 	.globl _SPI1_CK_SE
                                    181 	.globl _SPI1_CTRL
                                    182 	.globl _SPI1_DATA
                                    183 	.globl _SPI1_STAT
                                    184 	.globl _SIF1
                                    185 	.globl _SBAUD1
                                    186 	.globl _SBUF1
                                    187 	.globl _SCON1
                                    188 	.globl _SPI0_SETUP
                                    189 	.globl _SPI0_CK_SE
                                    190 	.globl _SPI0_CTRL
                                    191 	.globl _SPI0_DATA
                                    192 	.globl _SPI0_STAT
                                    193 	.globl _T2CAP1H
                                    194 	.globl _T2CAP1L
                                    195 	.globl _T2CAP1
                                    196 	.globl _TH2
                                    197 	.globl _TL2
                                    198 	.globl _T2COUNT
                                    199 	.globl _RCAP2H
                                    200 	.globl _RCAP2L
                                    201 	.globl _RCAP2
                                    202 	.globl _T2MOD
                                    203 	.globl _T2CON
                                    204 	.globl _SBUF
                                    205 	.globl _SCON
                                    206 	.globl _TH1
                                    207 	.globl _TH0
                                    208 	.globl _TL1
                                    209 	.globl _TL0
                                    210 	.globl _TMOD
                                    211 	.globl _TCON
                                    212 	.globl _XBUS_AUX
                                    213 	.globl _P7
                                    214 	.globl _P6_DIR
                                    215 	.globl _P6_OUT_PU
                                    216 	.globl _P6_IN
                                    217 	.globl _P5_DIR
                                    218 	.globl _P5_OUT_PU
                                    219 	.globl _P5_IN
                                    220 	.globl _P4_LED_KEY
                                    221 	.globl _P4_DIR_PU
                                    222 	.globl _P4_MOD_OC
                                    223 	.globl _P4
                                    224 	.globl _P3_DIR_PU
                                    225 	.globl _P3_MOD_OC
                                    226 	.globl _P3
                                    227 	.globl _P2_DIR_PU
                                    228 	.globl _P2_MOD_OC
                                    229 	.globl _P2
                                    230 	.globl _P1_DIR_PU
                                    231 	.globl _P1_MOD_OC
                                    232 	.globl _P1
                                    233 	.globl _P0_DIR_PU
                                    234 	.globl _P0_MOD_OC
                                    235 	.globl _P0
                                    236 	.globl _ROM_CTRL
                                    237 	.globl _ROM_DATA_HH
                                    238 	.globl _ROM_DATA_HL
                                    239 	.globl _ROM_DATA_HI
                                    240 	.globl _ROM_ADDR_H
                                    241 	.globl _ROM_ADDR_L
                                    242 	.globl _ROM_ADDR
                                    243 	.globl _GPIO_IE
                                    244 	.globl _IP_EX
                                    245 	.globl _IE_EX
                                    246 	.globl _IP
                                    247 	.globl _IE
                                    248 	.globl _WDOG_COUNT
                                    249 	.globl _RESET_KEEP
                                    250 	.globl _WAKE_CTRL
                                    251 	.globl _CLOCK_CFG
                                    252 	.globl _POWER_CFG
                                    253 	.globl _PCON
                                    254 	.globl _GLOBAL_CFG
                                    255 	.globl _SAFE_MOD
                                    256 	.globl _DPH
                                    257 	.globl _DPL
                                    258 	.globl _SP
                                    259 	.globl _A_INV
                                    260 	.globl _B
                                    261 	.globl _ACC
                                    262 	.globl _PSW
                                    263 	.globl _ak820_oneshot_target
                                    264 	.globl _ak820_oneshot_process_PARM_3
                                    265 	.globl _ak820_oneshot_process_PARM_2
                                    266 	.globl _ak820_oneshot_consumed
                                    267 	.globl _ak820_oneshot_mods
                                    268 	.globl _ak820_tapping_source_PARM_1
                                    269 	.globl _ak820_tapping_source
                                    270 	.globl _ak820_tapping_before
                                    271 	.globl _ak820_tapping_process
                                    272 	.globl _ak820_tapping_cancel
                                    273 	.globl _ak820_oneshot_process
                                    274 ;--------------------------------------------------------
                                    275 ; special function registers
                                    276 ;--------------------------------------------------------
                                    277 	.area RSEG    (ABS,DATA)
      000000                        278 	.org 0x0000
                           0000D0   279 _PSW	=	0x00d0
                           0000E0   280 _ACC	=	0x00e0
                           0000F0   281 _B	=	0x00f0
                           0000FD   282 _A_INV	=	0x00fd
                           000081   283 _SP	=	0x0081
                           000082   284 _DPL	=	0x0082
                           000083   285 _DPH	=	0x0083
                           0000A1   286 _SAFE_MOD	=	0x00a1
                           0000B1   287 _GLOBAL_CFG	=	0x00b1
                           000087   288 _PCON	=	0x0087
                           0000BA   289 _POWER_CFG	=	0x00ba
                           0000B9   290 _CLOCK_CFG	=	0x00b9
                           0000A9   291 _WAKE_CTRL	=	0x00a9
                           0000FE   292 _RESET_KEEP	=	0x00fe
                           0000FF   293 _WDOG_COUNT	=	0x00ff
                           0000A8   294 _IE	=	0x00a8
                           0000B8   295 _IP	=	0x00b8
                           0000E8   296 _IE_EX	=	0x00e8
                           0000E9   297 _IP_EX	=	0x00e9
                           0000B2   298 _GPIO_IE	=	0x00b2
                           008584   299 _ROM_ADDR	=	0x8584
                           000084   300 _ROM_ADDR_L	=	0x0084
                           000085   301 _ROM_ADDR_H	=	0x0085
                           008F8E   302 _ROM_DATA_HI	=	0x8f8e
                           00008E   303 _ROM_DATA_HL	=	0x008e
                           00008F   304 _ROM_DATA_HH	=	0x008f
                           000086   305 _ROM_CTRL	=	0x0086
                           000080   306 _P0	=	0x0080
                           0000C4   307 _P0_MOD_OC	=	0x00c4
                           0000C5   308 _P0_DIR_PU	=	0x00c5
                           000090   309 _P1	=	0x0090
                           000092   310 _P1_MOD_OC	=	0x0092
                           000093   311 _P1_DIR_PU	=	0x0093
                           0000A0   312 _P2	=	0x00a0
                           000094   313 _P2_MOD_OC	=	0x0094
                           000095   314 _P2_DIR_PU	=	0x0095
                           0000B0   315 _P3	=	0x00b0
                           000096   316 _P3_MOD_OC	=	0x0096
                           000097   317 _P3_DIR_PU	=	0x0097
                           0000C0   318 _P4	=	0x00c0
                           0000C2   319 _P4_MOD_OC	=	0x00c2
                           0000C3   320 _P4_DIR_PU	=	0x00c3
                           0000C1   321 _P4_LED_KEY	=	0x00c1
                           0000AA   322 _P5_IN	=	0x00aa
                           0000AB   323 _P5_OUT_PU	=	0x00ab
                           0000AC   324 _P5_DIR	=	0x00ac
                           0000AD   325 _P6_IN	=	0x00ad
                           0000AE   326 _P6_OUT_PU	=	0x00ae
                           0000AF   327 _P6_DIR	=	0x00af
                           0000F1   328 _P7	=	0x00f1
                           0000A2   329 _XBUS_AUX	=	0x00a2
                           000088   330 _TCON	=	0x0088
                           000089   331 _TMOD	=	0x0089
                           00008A   332 _TL0	=	0x008a
                           00008B   333 _TL1	=	0x008b
                           00008C   334 _TH0	=	0x008c
                           00008D   335 _TH1	=	0x008d
                           000098   336 _SCON	=	0x0098
                           000099   337 _SBUF	=	0x0099
                           0000C8   338 _T2CON	=	0x00c8
                           0000C9   339 _T2MOD	=	0x00c9
                           00CBCA   340 _RCAP2	=	0xcbca
                           0000CA   341 _RCAP2L	=	0x00ca
                           0000CB   342 _RCAP2H	=	0x00cb
                           00CDCC   343 _T2COUNT	=	0xcdcc
                           0000CC   344 _TL2	=	0x00cc
                           0000CD   345 _TH2	=	0x00cd
                           00CFCE   346 _T2CAP1	=	0xcfce
                           0000CE   347 _T2CAP1L	=	0x00ce
                           0000CF   348 _T2CAP1H	=	0x00cf
                           0000F8   349 _SPI0_STAT	=	0x00f8
                           0000F9   350 _SPI0_DATA	=	0x00f9
                           0000FA   351 _SPI0_CTRL	=	0x00fa
                           0000FB   352 _SPI0_CK_SE	=	0x00fb
                           0000FC   353 _SPI0_SETUP	=	0x00fc
                           0000BC   354 _SCON1	=	0x00bc
                           0000BD   355 _SBUF1	=	0x00bd
                           0000BE   356 _SBAUD1	=	0x00be
                           0000BF   357 _SIF1	=	0x00bf
                           0000B4   358 _SPI1_STAT	=	0x00b4
                           0000B5   359 _SPI1_DATA	=	0x00b5
                           0000B6   360 _SPI1_CTRL	=	0x00b6
                           0000B7   361 _SPI1_CK_SE	=	0x00b7
                           0000F3   362 _ADC_CTRL	=	0x00f3
                           00F5F4   363 _ADC_DAT	=	0xf5f4
                           0000F4   364 _ADC_DAT_L	=	0x00f4
                           0000F5   365 _ADC_DAT_H	=	0x00f5
                           0000F6   366 _ADC_CHAN	=	0x00f6
                           0000A6   367 _LED_COMMON	=	0x00a6
                           0000A7   368 _LED_PWM_OE	=	0x00a7
                           00C7C6   369 _LED_DMA	=	0xc7c6
                           0000C6   370 _LED_DMA_L	=	0x00c6
                           0000C7   371 _LED_DMA_H	=	0x00c7
                           0000F7   372 _LED_STATUS	=	0x00f7
                           0000B3   373 _I2CX_INT	=	0x00b3
                           0000BB   374 _I2CS_INT_ST	=	0x00bb
                                    375 ;--------------------------------------------------------
                                    376 ; special function bits
                                    377 ;--------------------------------------------------------
                                    378 	.area RSEG    (ABS,DATA)
      000000                        379 	.org 0x0000
                           0000D7   380 _CY	=	0x00d7
                           0000D6   381 _AC	=	0x00d6
                           0000D5   382 _F0	=	0x00d5
                           0000D4   383 _RS1	=	0x00d4
                           0000D3   384 _RS0	=	0x00d3
                           0000D2   385 _OV	=	0x00d2
                           0000D1   386 _F1	=	0x00d1
                           0000D0   387 _P	=	0x00d0
                           0000AF   388 _EA	=	0x00af
                           0000AE   389 _E_DIS	=	0x00ae
                           0000AD   390 _ET2	=	0x00ad
                           0000AC   391 _ES	=	0x00ac
                           0000AB   392 _ET1	=	0x00ab
                           0000AA   393 _EX1	=	0x00aa
                           0000A9   394 _ET0	=	0x00a9
                           0000A8   395 _EX0	=	0x00a8
                           0000BF   396 _PH_FLAG	=	0x00bf
                           0000BE   397 _PL_FLAG	=	0x00be
                           0000BD   398 _PT2	=	0x00bd
                           0000BC   399 _PS	=	0x00bc
                           0000BB   400 _PT1	=	0x00bb
                           0000BA   401 _PX1	=	0x00ba
                           0000B9   402 _PT0	=	0x00b9
                           0000B8   403 _PX0	=	0x00b8
                           0000EF   404 _IE_WDOG	=	0x00ef
                           0000EE   405 _IE_GPIO	=	0x00ee
                           0000ED   406 _IE_PWM_I2C	=	0x00ed
                           0000EC   407 _IE_UART1	=	0x00ec
                           0000EB   408 _IE_ADC	=	0x00eb
                           0000E9   409 _IE_USB	=	0x00e9
                           0000E8   410 _IE_SPI0	=	0x00e8
                           000087   411 _P0_7	=	0x0087
                           000086   412 _P0_6	=	0x0086
                           000085   413 _P0_5	=	0x0085
                           000084   414 _P0_4	=	0x0084
                           000083   415 _P0_3	=	0x0083
                           000082   416 _P0_2	=	0x0082
                           000081   417 _P0_1	=	0x0081
                           000080   418 _P0_0	=	0x0080
                           000081   419 _SDA0	=	0x0081
                           000080   420 _SCL0	=	0x0080
                           000083   421 _TXD_	=	0x0083
                           000082   422 _RXD_	=	0x0082
                           000085   423 _AIN13	=	0x0085
                           000084   424 _AIN12	=	0x0084
                           000083   425 _AIN11	=	0x0083
                           000082   426 _AIN10	=	0x0082
                           000081   427 _AIN9	=	0x0081
                           000080   428 _AIN8	=	0x0080
                           000097   429 _P1_7	=	0x0097
                           000096   430 _P1_6	=	0x0096
                           000095   431 _P1_5	=	0x0095
                           000094   432 _P1_4	=	0x0094
                           000093   433 _P1_3	=	0x0093
                           000092   434 _P1_2	=	0x0092
                           000091   435 _P1_1	=	0x0091
                           000090   436 _P1_0	=	0x0090
                           000097   437 _TXD1_	=	0x0097
                           000096   438 _RXD1_	=	0x0096
                           000097   439 _SCK	=	0x0097
                           000096   440 _MISO	=	0x0096
                           000095   441 _MOSI	=	0x0095
                           000094   442 _SCS	=	0x0094
                           000092   443 _INT0_	=	0x0092
                           000091   444 _T2EX	=	0x0091
                           000091   445 _CAP2	=	0x0091
                           000090   446 _T2	=	0x0090
                           000090   447 _CAP1	=	0x0090
                           000097   448 _AIN7	=	0x0097
                           000096   449 _AIN6	=	0x0096
                           000095   450 _AIN5	=	0x0095
                           000094   451 _AIN4	=	0x0094
                           000093   452 _AIN3	=	0x0093
                           000092   453 _AIN2	=	0x0092
                           000091   454 _AIN1	=	0x0091
                           000090   455 _AIN0	=	0x0090
                           0000A7   456 _P2_7	=	0x00a7
                           0000A6   457 _P2_6	=	0x00a6
                           0000A5   458 _P2_5	=	0x00a5
                           0000A4   459 _P2_4	=	0x00a4
                           0000A3   460 _P2_3	=	0x00a3
                           0000A2   461 _P2_2	=	0x00a2
                           0000A1   462 _P2_1	=	0x00a1
                           0000A0   463 _P2_0	=	0x00a0
                           0000A7   464 _TXD1	=	0x00a7
                           0000A6   465 _RXD1	=	0x00a6
                           0000A5   466 _T2EX_	=	0x00a5
                           0000A5   467 _CAP2_	=	0x00a5
                           0000A4   468 _T2_	=	0x00a4
                           0000A4   469 _CAP1_	=	0x00a4
                           0000B7   470 _P3_7	=	0x00b7
                           0000B6   471 _P3_6	=	0x00b6
                           0000B5   472 _P3_5	=	0x00b5
                           0000B4   473 _P3_4	=	0x00b4
                           0000B3   474 _P3_3	=	0x00b3
                           0000B2   475 _P3_2	=	0x00b2
                           0000B1   476 _P3_1	=	0x00b1
                           0000B0   477 _P3_0	=	0x00b0
                           0000B7   478 _SCK1	=	0x00b7
                           0000B6   479 _MISO1	=	0x00b6
                           0000B5   480 _MOSI1	=	0x00b5
                           0000B5   481 _T1	=	0x00b5
                           0000B4   482 _T0	=	0x00b4
                           0000B3   483 _INT1	=	0x00b3
                           0000B2   484 _INT0	=	0x00b2
                           0000B1   485 _TXD	=	0x00b1
                           0000B0   486 _RXD	=	0x00b0
                           0000C6   487 _P4_6	=	0x00c6
                           0000C5   488 _P4_5	=	0x00c5
                           0000C4   489 _P4_4	=	0x00c4
                           0000C3   490 _P4_3	=	0x00c3
                           0000C2   491 _P4_2	=	0x00c2
                           0000C1   492 _P4_1	=	0x00c1
                           0000C0   493 _P4_0	=	0x00c0
                           00008F   494 _TF1	=	0x008f
                           00008E   495 _TR1	=	0x008e
                           00008D   496 _TF0	=	0x008d
                           00008C   497 _TR0	=	0x008c
                           00008B   498 _IE1	=	0x008b
                           00008A   499 _IT1	=	0x008a
                           000089   500 _IE0	=	0x0089
                           000088   501 _IT0	=	0x0088
                           00009F   502 _SM0	=	0x009f
                           00009E   503 _SM1	=	0x009e
                           00009D   504 _SM2	=	0x009d
                           00009C   505 _REN	=	0x009c
                           00009B   506 _TB8	=	0x009b
                           00009A   507 _RB8	=	0x009a
                           000099   508 _TI	=	0x0099
                           000098   509 _RI	=	0x0098
                           0000CF   510 _TF2	=	0x00cf
                           0000CF   511 _CAP1F	=	0x00cf
                           0000CE   512 _EXF2	=	0x00ce
                           0000CD   513 _RCLK	=	0x00cd
                           0000CC   514 _TCLK	=	0x00cc
                           0000CB   515 _EXEN2	=	0x00cb
                           0000CA   516 _TR2	=	0x00ca
                           0000C9   517 _C_T2	=	0x00c9
                           0000C8   518 _CP_RL2	=	0x00c8
                           0000FF   519 _S0_FST_ACT	=	0x00ff
                           0000FE   520 _S0_IF_OV	=	0x00fe
                           0000FD   521 _S0_IF_FIRST	=	0x00fd
                           0000FC   522 _S0_IF_BYTE	=	0x00fc
                           0000FB   523 _S0_FREE	=	0x00fb
                           0000FA   524 _S0_T_FIFO	=	0x00fa
                           0000F8   525 _S0_R_FIFO	=	0x00f8
                           0000F7   526 _ADC_START	=	0x00f7
                                    527 ;--------------------------------------------------------
                                    528 ; overlayable register banks
                                    529 ;--------------------------------------------------------
                                    530 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        531 	.ds 8
                                    532 ;--------------------------------------------------------
                                    533 ; internal ram data
                                    534 ;--------------------------------------------------------
                                    535 	.area DSEG    (DATA)
                                    536 ;--------------------------------------------------------
                                    537 ; overlayable items in internal ram
                                    538 ;--------------------------------------------------------
                                    539 ;--------------------------------------------------------
                                    540 ; indirectly addressable internal ram data
                                    541 ;--------------------------------------------------------
                                    542 	.area ISEG    (DATA)
                                    543 ;--------------------------------------------------------
                                    544 ; absolute internal ram data
                                    545 ;--------------------------------------------------------
                                    546 	.area IABS    (ABS,DATA)
                                    547 	.area IABS    (ABS,DATA)
                                    548 ;--------------------------------------------------------
                                    549 ; bit data
                                    550 ;--------------------------------------------------------
                                    551 	.area BSEG    (BIT)
      00000F                        552 _ak820_tapping_before_sloc0_1_0:
      00000F                        553 	.ds 1
                                    554 ;--------------------------------------------------------
                                    555 ; paged external ram data
                                    556 ;--------------------------------------------------------
                                    557 	.area PSEG    (PAG,XDATA)
                                    558 ;--------------------------------------------------------
                                    559 ; uninitialized external ram data
                                    560 ;--------------------------------------------------------
                                    561 	.area XSEG    (XDATA)
      000664                        562 _source_state:
      000664                        563 	.ds 130
      0006E6                        564 _pending_time:
      0006E6                        565 	.ds 2
      0006E8                        566 _pending_code:
      0006E8                        567 	.ds 2
      0006EA                        568 _ak820_tapping_source_PARM_1:
      0006EA                        569 	.ds 2
      0006EC                        570 _hold_PARM_2:
      0006EC                        571 	.ds 1
      0006ED                        572 _hold_code_10000_603:
      0006ED                        573 	.ds 2
      0006EF                        574 _hold_mods_30000_606:
      0006EF                        575 	.ds 1
      0006F0                        576 _commit_pending_id_10000_612:
      0006F0                        577 	.ds 1
      0006F1                        578 _ak820_tapping_before_event_10000_613:
      0006F1                        579 	.ds 2
      0006F3                        580 _ak820_tapping_process_record_10000_624:
      0006F3                        581 	.ds 2
      0006F5                        582 _ak820_tapping_process_code_10000_625:
      0006F5                        583 	.ds 2
      0006F7                        584 _ak820_tapping_process_sc_mods_10000_625:
      0006F7                        585 	.ds 1
      0006F8                        586 _ak820_oneshot_mods::
      0006F8                        587 	.ds 1
      0006F9                        588 _ak820_oneshot_consumed::
      0006F9                        589 	.ds 1
      0006FA                        590 _ak820_oneshot_process_PARM_2:
      0006FA                        591 	.ds 1
      0006FB                        592 _ak820_oneshot_process_PARM_3:
      0006FB                        593 	.ds 1
      0006FC                        594 _ak820_oneshot_process_code_10000_650:
      0006FC                        595 	.ds 2
      0006FE                        596 _ak820_oneshot_process_mods_10000_651:
      0006FE                        597 	.ds 1
                                    598 ;--------------------------------------------------------
                                    599 ; absolute external ram data
                                    600 ;--------------------------------------------------------
                                    601 	.area XABS    (ABS,XDATA)
                                    602 ;--------------------------------------------------------
                                    603 ; initialized external ram data
                                    604 ;--------------------------------------------------------
                                    605 	.area XISEG   (XDATA)
      000E70                        606 _pending:
      000E70                        607 	.ds 1
      000E71                        608 _ak820_oneshot_target::
      000E71                        609 	.ds 1
                                    610 	.area HOME    (CODE)
                                    611 	.area GSINIT0 (CODE)
                                    612 	.area GSINIT1 (CODE)
                                    613 	.area GSINIT2 (CODE)
                                    614 	.area GSINIT3 (CODE)
                                    615 	.area GSINIT4 (CODE)
                                    616 	.area GSINIT5 (CODE)
                                    617 	.area GSINIT  (CODE)
                                    618 	.area GSFINAL (CODE)
                                    619 	.area CSEG    (CODE)
                                    620 ;--------------------------------------------------------
                                    621 ; global & static initialisations
                                    622 ;--------------------------------------------------------
                                    623 	.area HOME    (CODE)
                                    624 	.area GSINIT  (CODE)
                                    625 	.area GSFINAL (CODE)
                                    626 	.area GSINIT  (CODE)
                                    627 ;--------------------------------------------------------
                                    628 ; Home
                                    629 ;--------------------------------------------------------
                                    630 	.area HOME    (CODE)
                                    631 	.area HOME    (CODE)
                                    632 ;--------------------------------------------------------
                                    633 ; code
                                    634 ;--------------------------------------------------------
                                    635 	.area CSEG    (CODE)
                                    636 ;------------------------------------------------------------
                                    637 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    638 ;------------------------------------------------------------
                                    639 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    640 ;------------------------------------------------------------
                                    641 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    642 ;	-----------------------------------------
                           000007   643 	ar7 = 0x07
                           000006   644 	ar6 = 0x06
                           000005   645 	ar5 = 0x05
                           000004   646 	ar4 = 0x04
                           000003   647 	ar3 = 0x03
                           000002   648 	ar2 = 0x02
                           000001   649 	ar1 = 0x01
                           000000   650 	ar0 = 0x00
                                    651 ;	 function ak820_tapping_source
                                    652 ;	-----------------------------------------
      0048F2                        653 _ak820_tapping_source:
                                    654 ;	keyboards/ajazz/ak820/ak820_tapping.c:40: if (key.row < MATRIX_ROWS && key.col < MATRIX_COLS) return key.row * MATRIX_COLS + key.col;
      0048F2 90 06 EB         [24]  655 	mov	dptr,#(_ak820_tapping_source_PARM_1 + 0x0001)
      0048F5 E0               [24]  656 	movx	a,@dptr
      0048F6 FF               [12]  657 	mov	r7,a
      0048F7 BF 10 00         [24]  658 	cjne	r7,#0x10,00147$
      0048FA                        659 00147$:
      0048FA 50 14            [24]  660 	jnc	00102$
      0048FC 90 06 EA         [24]  661 	mov	dptr,#_ak820_tapping_source_PARM_1
      0048FF E0               [24]  662 	movx	a,@dptr
      004900 FE               [12]  663 	mov	r6,a
      004901 BE 08 00         [24]  664 	cjne	r6,#0x08,00149$
      004904                        665 00149$:
      004904 50 0A            [24]  666 	jnc	00102$
      004906 8F 05            [24]  667 	mov	ar5,r7
      004908 ED               [12]  668 	mov	a,r5
      004909 12 38 70         [24]  669 	lcall	_ak820_outline_0161
      00490C 2E               [12]  670 	add	a,r6
      00490D F5 82            [12]  671 	mov	dpl,a
      00490F 22               [24]  672 	ret
      004910                        673 00102$:
                                    674 ;	keyboards/ajazz/ak820/ak820_tapping.c:41: if (key.col < NUM_ENCODERS) {
      004910 90 06 EA         [24]  675 	mov	dptr,#_ak820_tapping_source_PARM_1
      004913 E0               [24]  676 	movx	a,@dptr
      004914 FE               [12]  677 	mov	r6,a
      004915 BE 01 00         [24]  678 	cjne	r6,#0x01,00151$
      004918                        679 00151$:
      004918 50 0E            [24]  680 	jnc	00109$
                                    681 ;	keyboards/ajazz/ak820/ak820_tapping.c:42: if (key.row == KEYLOC_ENCODER_CW) return MATRIX_ROWS * MATRIX_COLS + key.col;
      00491A BF FD 04         [24]  682 	cjne	r7,#0xfd,00105$
      00491D 75 82 80         [24]  683 	mov	dpl, #0x80
      004920 22               [24]  684 	ret
      004921                        685 00105$:
                                    686 ;	keyboards/ajazz/ak820/ak820_tapping.c:43: if (key.row == KEYLOC_ENCODER_CCW) return MATRIX_ROWS * MATRIX_COLS + NUM_ENCODERS + key.col;
      004921 BF FC 04         [24]  687 	cjne	r7,#0xfc,00109$
      004924 75 82 81         [24]  688 	mov	dpl, #0x81
      004927 22               [24]  689 	ret
      004928                        690 00109$:
                                    691 ;	keyboards/ajazz/ak820/ak820_tapping.c:45: return NONE;
      004928 75 82 FF         [24]  692 	mov	dpl, #0xff
                                    693 ;	keyboards/ajazz/ak820/ak820_tapping.c:46: }
      00492B 22               [24]  694 	ret
                                    695 ;------------------------------------------------------------
                                    696 ;Allocation info for local variables in function 'hold'
                                    697 ;------------------------------------------------------------
                                    698 ;pressed       Allocated with name '_hold_PARM_2'
                                    699 ;code          Allocated with name '_hold_code_10000_603'
                                    700 ;mods          Allocated with name '_hold_mods_30000_606'
                                    701 ;layer         Allocated with name '_hold_layer_30000_609'
                                    702 ;------------------------------------------------------------
                                    703 ;	keyboards/ajazz/ak820/ak820_tapping.c:47: static void hold(uint16_t code, bool pressed) {
                                    704 ;	-----------------------------------------
                                    705 ;	 function hold
                                    706 ;	-----------------------------------------
      00492C                        707 _hold:
      00492C 12 38 4C         [24]  708 	lcall	_ak820_outline_0106
      00492F 90 06 ED         [24]  709 	mov	dptr,#_hold_code_10000_603
      004932 12 38 47         [24]  710 	lcall	_ak820_outline_0105
                                    711 ;	keyboards/ajazz/ak820/ak820_tapping.c:48: if (code < QK_LAYER_TAP) {
      004935 90 06 ED         [24]  712 	mov	dptr,#_hold_code_10000_603
      004938 12 37 C2         [24]  713 	lcall	_ak820_outline_0010
      00493B 74 C0            [12]  714 	mov	a,#0x100 - 0x40
      00493D 2D               [12]  715 	add	a,r5
      00493E 40 2E            [24]  716 	jc	00110$
                                    717 ;	keyboards/ajazz/ak820/ak820_tapping.c:49: uint8_t mods = (code >> 8) & 31;
      004940 8F 05            [24]  718 	mov	ar5,r7
      004942 53 05 1F         [24]  719 	anl	ar5,#0x1f
      004945 90 06 EF         [24]  720 	mov	dptr,#_hold_mods_30000_606
      004948 ED               [12]  721 	mov	a,r5
      004949 F0               [24]  722 	movx	@dptr,a
                                    723 ;	keyboards/ajazz/ak820/ak820_tapping.c:50: if (mods & 16) mods <<= 4;
      00494A ED               [12]  724 	mov	a,r5
      00494B 30 E4 08         [24]  725 	jnb	acc.4,00102$
      00494E ED               [12]  726 	mov	a,r5
      00494F C4               [12]  727 	swap	a
      004950 54 F0            [12]  728 	anl	a,#0xf0
      004952 90 06 EF         [24]  729 	mov	dptr,#_hold_mods_30000_606
      004955 F0               [24]  730 	movx	@dptr,a
      004956                        731 00102$:
                                    732 ;	keyboards/ajazz/ak820/ak820_tapping.c:51: if (pressed) register_mods(mods);
      004956 90 06 EC         [24]  733 	mov	dptr,#_hold_PARM_2
      004959 E0               [24]  734 	movx	a,@dptr
      00495A 60 09            [24]  735 	jz	00104$
      00495C 90 06 EF         [24]  736 	mov	dptr,#_hold_mods_30000_606
      00495F E0               [24]  737 	movx	a,@dptr
      004960 F5 82            [12]  738 	mov	dpl,a
      004962 02 7A A4         [24]  739 	ljmp	_register_mods
      004965                        740 00104$:
                                    741 ;	keyboards/ajazz/ak820/ak820_tapping.c:52: else unregister_mods(mods);
      004965 90 06 EF         [24]  742 	mov	dptr,#_hold_mods_30000_606
      004968 E0               [24]  743 	movx	a,@dptr
      004969 F5 82            [12]  744 	mov	dpl,a
      00496B 02 7A B8         [24]  745 	ljmp	_unregister_mods
      00496E                        746 00110$:
                                    747 ;	keyboards/ajazz/ak820/ak820_tapping.c:54: uint8_t layer = (code >> 8) & 15;
      00496E 8F 06            [24]  748 	mov	ar6,r7
      004970 74 0F            [12]  749 	mov	a,#0x0f
      004972 5E               [12]  750 	anl	a,r6
      004973 FF               [12]  751 	mov	r7,a
                                    752 ;	keyboards/ajazz/ak820/ak820_tapping.c:55: if (pressed) layer_hold_on(layer);
      004974 90 06 EC         [24]  753 	mov	dptr,#_hold_PARM_2
      004977 E0               [24]  754 	movx	a,@dptr
      004978 60 05            [24]  755 	jz	00107$
      00497A 8F 82            [24]  756 	mov	dpl, r7
      00497C 02 7C 60         [24]  757 	ljmp	_layer_hold_on
      00497F                        758 00107$:
                                    759 ;	keyboards/ajazz/ak820/ak820_tapping.c:56: else layer_hold_off(layer);
      00497F 8F 82            [24]  760 	mov	dpl, r7
                                    761 ;	keyboards/ajazz/ak820/ak820_tapping.c:58: }
      004981 02 7C 96         [24]  762 	ljmp	_layer_hold_off
                                    763 ;------------------------------------------------------------
                                    764 ;Allocation info for local variables in function 'commit_pending'
                                    765 ;------------------------------------------------------------
                                    766 ;id            Allocated with name '_commit_pending_id_10000_612'
                                    767 ;------------------------------------------------------------
                                    768 ;	keyboards/ajazz/ak820/ak820_tapping.c:59: static void commit_pending(void) {
                                    769 ;	-----------------------------------------
                                    770 ;	 function commit_pending
                                    771 ;	-----------------------------------------
      004984                        772 _commit_pending:
                                    773 ;	keyboards/ajazz/ak820/ak820_tapping.c:60: uint8_t id = pending;
      004984 90 0E 70         [24]  774 	mov	dptr,#_pending
      004987 E0               [24]  775 	movx	a,@dptr
      004988 90 06 F0         [24]  776 	mov	dptr,#_commit_pending_id_10000_612
      00498B F0               [24]  777 	movx	@dptr,a
                                    778 ;	keyboards/ajazz/ak820/ak820_tapping.c:61: pending = NONE; /* A report callback cannot resurrect the decision. */
      00498C 12 4D C3         [24]  779 	lcall	_ak820_outline_0156
                                    780 ;	keyboards/ajazz/ak820/ak820_tapping.c:62: source_state[id] |= SOURCE_HELD;
      00498F 90 06 F0         [24]  781 	mov	dptr,#_commit_pending_id_10000_612
      004992 E0               [24]  782 	movx	a,@dptr
      004993 24 64            [12]  783 	add	a,#_source_state
      004995 FF               [12]  784 	mov	r7,a
      004996 E4               [12]  785 	clr	a
      004997 34 06            [12]  786 	addc	a, #(_source_state >> 8)
      004999 FE               [12]  787 	mov	r6,a
      00499A 12 43 42         [24]  788 	lcall	_ak820_outline_0159
      00499D E0               [24]  789 	movx	a,@dptr
      00499E FD               [12]  790 	mov	r5,a
      00499F 43 05 04         [24]  791 	orl	ar5,#0x04
      0049A2 12 43 42         [24]  792 	lcall	_ak820_outline_0159
      0049A5 ED               [12]  793 	mov	a,r5
      0049A6 F0               [24]  794 	movx	@dptr,a
                                    795 ;	keyboards/ajazz/ak820/ak820_tapping.c:63: hold(pending_code, true);
      0049A7 90 06 E8         [24]  796 	mov	dptr,#_pending_code
      0049AA 12 37 F7         [24]  797 	lcall	_ak820_outline_0056
      0049AD 90 06 EC         [24]  798 	mov	dptr,#_hold_PARM_2
      0049B0 12 4D A6         [24]  799 	lcall	_ak820_outline_0060
                                    800 ;	keyboards/ajazz/ak820/ak820_tapping.c:64: }
      0049B3 21 2C            [12]  801 	ajmp	_hold
                                    802 ;------------------------------------------------------------
                                    803 ;Allocation info for local variables in function 'ak820_tapping_before'
                                    804 ;------------------------------------------------------------
                                    805 ;event         Allocated with name '_ak820_tapping_before_event_10000_613'
                                    806 ;id            Allocated with name '_ak820_tapping_before_id_10000_614'
                                    807 ;------------------------------------------------------------
                                    808 ;	keyboards/ajazz/ak820/ak820_tapping.c:65: bool ak820_tapping_before(const keyevent_t AK820_STATE_MEM *event) {
                                    809 ;	-----------------------------------------
                                    810 ;	 function ak820_tapping_before
                                    811 ;	-----------------------------------------
      0049B5                        812 _ak820_tapping_before:
      0049B5 12 38 4C         [24]  813 	lcall	_ak820_outline_0106
      0049B8 90 06 F1         [24]  814 	mov	dptr,#_ak820_tapping_before_event_10000_613
      0049BB 12 38 47         [24]  815 	lcall	_ak820_outline_0105
                                    816 ;	keyboards/ajazz/ak820/ak820_tapping.c:66: uint8_t id = ak820_tapping_source(event->key);
      0049BE 90 06 F1         [24]  817 	mov	dptr,#_ak820_tapping_before_event_10000_613
      0049C1 12 37 C2         [24]  818 	lcall	_ak820_outline_0010
      0049C4 12 4D 8C         [24]  819 	lcall	_ak820_outline_0024
      0049C7 C0 07            [24]  820 	push	ar7
      0049C9 C0 06            [24]  821 	push	ar6
      0049CB 12 BC 8E         [24]  822 	lcall	___memcpy
      0049CE 11 F2            [12]  823 	acall	_ak820_tapping_source
      0049D0 AD 82            [24]  824 	mov	r5, dpl
      0049D2 D0 06            [24]  825 	pop	ar6
      0049D4 D0 07            [24]  826 	pop	ar7
                                    827 ;	keyboards/ajazz/ak820/ak820_tapping.c:68: if (vial_unlock_in_progress) {
      0049D6 90 0E E1         [24]  828 	mov	dptr,#_vial_unlock_in_progress
      0049D9 E0               [24]  829 	movx	a,@dptr
      0049DA 60 29            [24]  830 	jz	00106$
                                    831 ;	keyboards/ajazz/ak820/ak820_tapping.c:69: if (IS_EVENT(*event) && id != NONE && !event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      0049DC 74 04            [12]  832 	mov	a,#0x04
      0049DE 12 4D 72         [24]  833 	lcall	_ak820_outline_0014
      0049E1 60 1E            [24]  834 	jz	00102$
      0049E3 BD FF 02         [24]  835 	cjne	r5,#0xff,00218$
      0049E6 80 19            [24]  836 	sjmp	00102$
      0049E8                        837 00218$:
      0049E8 74 05            [12]  838 	mov	a,#0x05
      0049EA 12 4D 72         [24]  839 	lcall	_ak820_outline_0014
      0049ED 70 12            [24]  840 	jnz	00102$
      0049EF ED               [12]  841 	mov	a,r5
      0049F0 24 64            [12]  842 	add	a, #_source_state
      0049F2 FB               [12]  843 	mov	r3,a
      0049F3 E4               [12]  844 	clr	a
      0049F4 34 06            [12]  845 	addc	a, #(_source_state >> 8)
      0049F6 12 48 BC         [24]  846 	lcall	_ak820_outline_0049
      0049F9 53 02 FD         [24]  847 	anl	ar2,#0xfd
      0049FC 12 33 FC         [24]  848 	lcall	_ak820_outline_0124
      0049FF EA               [12]  849 	mov	a,r2
      004A00 F0               [24]  850 	movx	@dptr,a
      004A01                        851 00102$:
                                    852 ;	keyboards/ajazz/ak820/ak820_tapping.c:70: return false;
      004A01 75 82 00         [24]  853 	mov	dpl, #0x00
      004A04 22               [24]  854 	ret
      004A05                        855 00106$:
                                    856 ;	keyboards/ajazz/ak820/ak820_tapping.c:73: if (pending != NONE && ((uint16_t)(event->time - pending_time) >= AK820_TAPPING_TERM ||
      004A05 90 0E 70         [24]  857 	mov	dptr,#_pending
      004A08 E0               [24]  858 	movx	a,@dptr
      004A09 FC               [12]  859 	mov	r4,a
      004A0A BC FF 02         [24]  860 	cjne	r4,#0xff,00220$
      004A0D 80 3B            [24]  861 	sjmp	00108$
      004A0F                        862 00220$:
      004A0F 12 37 E7         [24]  863 	lcall	_ak820_outline_0034
      004A12 FA               [12]  864 	mov	r2,a
      004A13 A3               [24]  865 	inc	dptr
      004A14 E0               [24]  866 	movx	a,@dptr
      004A15 FB               [12]  867 	mov	r3,a
      004A16 90 06 E6         [24]  868 	mov	dptr,#_pending_time
      004A19 12 38 3B         [24]  869 	lcall	_ak820_outline_0102
      004A1C EA               [12]  870 	mov	a,r2
      004A1D C3               [12]  871 	clr	c
      004A1E 98               [12]  872 	subb	a,r0
      004A1F FA               [12]  873 	mov	r2,a
      004A20 EB               [12]  874 	mov	a,r3
      004A21 99               [12]  875 	subb	a,r1
      004A22 FB               [12]  876 	mov	r3,a
      004A23 C3               [12]  877 	clr	c
      004A24 EA               [12]  878 	mov	a,r2
      004A25 94 C8            [12]  879 	subb	a,#0xc8
      004A27 EB               [12]  880 	mov	a,r3
      004A28 94 00            [12]  881 	subb	a,#0x00
      004A2A 50 18            [24]  882 	jnc	00107$
                                    883 ;	keyboards/ajazz/ak820/ak820_tapping.c:74: (IS_EVENT(*event) && event->pressed && (id == NONE || id != pending)))) commit_pending();
      004A2C 74 04            [12]  884 	mov	a,#0x04
      004A2E 2E               [12]  885 	add	a, r6
      004A2F 12 48 A2         [24]  886 	lcall	_ak820_outline_0033
      004A32 60 16            [24]  887 	jz	00108$
      004A34 12 37 9B         [24]  888 	lcall	_ak820_outline_0001
      004A37 60 11            [24]  889 	jz	00108$
      004A39 BD FF 02         [24]  890 	cjne	r5,#0xff,00224$
      004A3C 80 06            [24]  891 	sjmp	00107$
      004A3E                        892 00224$:
      004A3E ED               [12]  893 	mov	a,r5
      004A3F B5 04 02         [24]  894 	cjne	a,ar4,00225$
      004A42 80 06            [24]  895 	sjmp	00108$
      004A44                        896 00225$:
      004A44                        897 00107$:
      004A44 C0 05            [24]  898 	push	ar5
      004A46 31 84            [12]  899 	acall	_commit_pending
      004A48 D0 05            [24]  900 	pop	ar5
      004A4A                        901 00108$:
                                    902 ;	keyboards/ajazz/ak820/ak820_tapping.c:75: if (IS_NOEVENT(*event) || id == NONE) return true;
      004A4A 90 06 F1         [24]  903 	mov	dptr,#_ak820_tapping_before_event_10000_613
      004A4D 12 37 F7         [24]  904 	lcall	_ak820_outline_0056
      004A50 74 04            [12]  905 	mov	a,#0x04
      004A52 12 4D 72         [24]  906 	lcall	_ak820_outline_0014
      004A55 60 03            [24]  907 	jz	00114$
      004A57 BD FF 04         [24]  908 	cjne	r5,#0xff,00115$
      004A5A                        909 00114$:
      004A5A 75 82 01         [24]  910 	mov	dpl, #0x01
      004A5D 22               [24]  911 	ret
      004A5E                        912 00115$:
                                    913 ;	keyboards/ajazz/ak820/ak820_tapping.c:76: if ((source_state[id] & SOURCE_BLOCKED)) {
      004A5E ED               [12]  914 	mov	a,r5
      004A5F 12 4D B5         [24]  915 	lcall	_ak820_outline_0083
      004A62 30 E1 13         [24]  916 	jnb	acc.1,00120$
                                    917 ;	keyboards/ajazz/ak820/ak820_tapping.c:77: if (!event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      004A65 74 05            [12]  918 	mov	a,#0x05
      004A67 2E               [12]  919 	add	a, r6
      004A68 12 37 CC         [24]  920 	lcall	_ak820_outline_0016
      004A6B 70 07            [24]  921 	jnz	00118$
      004A6D 74 FD            [12]  922 	mov	a,#0xfd
      004A6F 5B               [12]  923 	anl	a,r3
      004A70 12 38 51         [24]  924 	lcall	_ak820_outline_0123
      004A73 F0               [24]  925 	movx	@dptr,a
      004A74                        926 00118$:
                                    927 ;	keyboards/ajazz/ak820/ak820_tapping.c:78: return false;
      004A74 75 82 00         [24]  928 	mov	dpl, #0x00
      004A77 22               [24]  929 	ret
      004A78                        930 00120$:
                                    931 ;	keyboards/ajazz/ak820/ak820_tapping.c:81: if (event->pressed == ((source_state[id] & SOURCE_ACTIVE) != 0)) return false;
      004A78 12 42 C2         [24]  932 	lcall	_ak820_outline_0013
      004A7B E0               [24]  933 	movx	a,@dptr
      004A7C FF               [12]  934 	mov	r7,a
      004A7D 8B 06            [24]  935 	mov	ar6,r3
      004A7F 53 06 01         [24]  936 	anl	ar6,#0x01
      004A82 EE               [12]  937 	mov	a,r6
      004A83 B4 01 00         [24]  938 	cjne	a,#0x01,00231$
      004A86                        939 00231$:
      004A86 B3               [12]  940 	cpl	c
      004A87 92 0F            [24]  941 	mov	_ak820_tapping_before_sloc0_1_0,c
      004A89 8F F0            [24]  942 	mov	b,r7
      004A8B E4               [12]  943 	clr	a
      004A8C 33               [12]  944 	rlc	a
      004A8D B5 F0 04         [24]  945 	cjne	a,b,00122$
      004A90 75 82 00         [24]  946 	mov	dpl, #0x00
      004A93 22               [24]  947 	ret
      004A94                        948 00122$:
                                    949 ;	keyboards/ajazz/ak820/ak820_tapping.c:82: source_state[id] ^= SOURCE_ACTIVE;
      004A94 63 03 01         [24]  950 	xrl	ar3,#0x01
      004A97 12 38 51         [24]  951 	lcall	_ak820_outline_0123
      004A9A EB               [12]  952 	mov	a,r3
      004A9B F0               [24]  953 	movx	@dptr,a
                                    954 ;	keyboards/ajazz/ak820/ak820_tapping.c:83: return true;
      004A9C 75 82 01         [24]  955 	mov	dpl, #0x01
                                    956 ;	keyboards/ajazz/ak820/ak820_tapping.c:84: }
      004A9F 22               [24]  957 	ret
                                    958 ;------------------------------------------------------------
                                    959 ;Allocation info for local variables in function 'ak820_tapping_process'
                                    960 ;------------------------------------------------------------
                                    961 ;record        Allocated with name '_ak820_tapping_process_record_10000_624'
                                    962 ;id            Allocated with name '_ak820_tapping_process_id_10000_625'
                                    963 ;kind          Allocated with name '_ak820_tapping_process_kind_10000_625'
                                    964 ;code          Allocated with name '_ak820_tapping_process_code_10000_625'
                                    965 ;sc_mods       Allocated with name '_ak820_tapping_process_sc_mods_10000_625'
                                    966 ;------------------------------------------------------------
                                    967 ;	keyboards/ajazz/ak820/ak820_tapping.c:85: bool ak820_tapping_process(keyrecord_t AK820_STATE_MEM *record) {
                                    968 ;	-----------------------------------------
                                    969 ;	 function ak820_tapping_process
                                    970 ;	-----------------------------------------
      004AA0                        971 _ak820_tapping_process:
      004AA0 12 38 4C         [24]  972 	lcall	_ak820_outline_0106
      004AA3 90 06 F3         [24]  973 	mov	dptr,#_ak820_tapping_process_record_10000_624
      004AA6 12 38 47         [24]  974 	lcall	_ak820_outline_0105
                                    975 ;	keyboards/ajazz/ak820/ak820_tapping.c:89: uint8_t sc_mods = 0;
      004AA9 90 06 F7         [24]  976 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_625
      004AAC E4               [12]  977 	clr	a
      004AAD F0               [24]  978 	movx	@dptr,a
                                    979 ;	keyboards/ajazz/ak820/ak820_tapping.c:91: if (IS_NOEVENT(record->event)) return true;
      004AAE 90 06 F3         [24]  980 	mov	dptr,#_ak820_tapping_process_record_10000_624
      004AB1 12 37 F7         [24]  981 	lcall	_ak820_outline_0056
      004AB4 74 04            [12]  982 	mov	a,#0x04
      004AB6 12 48 76         [24]  983 	lcall	_ak820_outline_0012
      004AB9 70 04            [24]  984 	jnz	00102$
      004ABB 75 82 01         [24]  985 	mov	dpl, #0x01
      004ABE 22               [24]  986 	ret
      004ABF                        987 00102$:
                                    988 ;	keyboards/ajazz/ak820/ak820_tapping.c:92: id = ak820_tapping_source(record->event.key);
      004ABF 8E 04            [24]  989 	mov	ar4,r6
      004AC1 8F 05            [24]  990 	mov	ar5,r7
      004AC3 12 4D 8C         [24]  991 	lcall	_ak820_outline_0024
      004AC6 C0 07            [24]  992 	push	ar7
      004AC8 C0 06            [24]  993 	push	ar6
      004ACA 12 BC 8E         [24]  994 	lcall	___memcpy
      004ACD 11 F2            [12]  995 	acall	_ak820_tapping_source
      004ACF AD 82            [24]  996 	mov	r5, dpl
      004AD1 D0 06            [24]  997 	pop	ar6
      004AD3 D0 07            [24]  998 	pop	ar7
                                    999 ;	keyboards/ajazz/ak820/ak820_tapping.c:93: if (id == NONE) return true;
      004AD5 BD FF 04         [24] 1000 	cjne	r5,#0xff,00104$
      004AD8 75 82 01         [24] 1001 	mov	dpl, #0x01
      004ADB 22               [24] 1002 	ret
      004ADC                       1003 00104$:
                                   1004 ;	keyboards/ajazz/ak820/ak820_tapping.c:94: code = record->keycode;
      004ADC 74 07            [12] 1005 	mov	a,#0x07
      004ADE 12 37 D6         [24] 1006 	lcall	_ak820_outline_0017
      004AE1 FE               [12] 1007 	mov	r6,a
      004AE2 A3               [24] 1008 	inc	dptr
      004AE3 E0               [24] 1009 	movx	a,@dptr
      004AE4 FF               [12] 1010 	mov	r7,a
      004AE5 90 06 F5         [24] 1011 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004AE8 12 48 CB         [24] 1012 	lcall	_ak820_outline_0064
                                   1013 ;	keyboards/ajazz/ak820/ak820_tapping.c:96: if (code == SC_LSPO) { code = MT(MOD_LSFT, KC_9); sc_mods = MOD_BIT(KC_LEFT_SHIFT); }
      004AEB BE 1A 15         [24] 1014 	cjne	r6,#0x1a,00111$
      004AEE BF 7C 12         [24] 1015 	cjne	r7,#0x7c,00111$
      004AF1 90 06 F5         [24] 1016 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004AF4 74 26            [12] 1017 	mov	a,#0x26
      004AF6 F0               [24] 1018 	movx	@dptr,a
      004AF7 74 22            [12] 1019 	mov	a,#0x22
      004AF9 A3               [24] 1020 	inc	dptr
      004AFA F0               [24] 1021 	movx	@dptr,a
      004AFB 90 06 F7         [24] 1022 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_625
      004AFE 74 02            [12] 1023 	mov	a,#0x02
      004B00 F0               [24] 1024 	movx	@dptr,a
      004B01 80 28            [24] 1025 	sjmp	00112$
      004B03                       1026 00111$:
                                   1027 ;	keyboards/ajazz/ak820/ak820_tapping.c:97: else if (code == SC_RSPC) { code = MT(MOD_RSFT, KC_0); sc_mods = MOD_BIT(KC_RIGHT_SHIFT); }
      004B03 BE 1B 15         [24] 1028 	cjne	r6,#0x1b,00108$
      004B06 BF 7C 12         [24] 1029 	cjne	r7,#0x7c,00108$
      004B09 90 06 F5         [24] 1030 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004B0C 74 27            [12] 1031 	mov	a,#0x27
      004B0E F0               [24] 1032 	movx	@dptr,a
      004B0F 74 32            [12] 1033 	mov	a,#0x32
      004B11 A3               [24] 1034 	inc	dptr
      004B12 F0               [24] 1035 	movx	@dptr,a
      004B13 90 06 F7         [24] 1036 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_625
      004B16 74 20            [12] 1037 	mov	a,#0x20
      004B18 F0               [24] 1038 	movx	@dptr,a
      004B19 80 10            [24] 1039 	sjmp	00112$
      004B1B                       1040 00108$:
                                   1041 ;	keyboards/ajazz/ak820/ak820_tapping.c:98: else if (code == SC_SENT) code = MT(MOD_RSFT, KC_ENTER);
      004B1B BE 1E 0D         [24] 1042 	cjne	r6,#0x1e,00112$
      004B1E BF 7C 0A         [24] 1043 	cjne	r7,#0x7c,00112$
      004B21 90 06 F5         [24] 1044 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004B24 74 28            [12] 1045 	mov	a,#0x28
      004B26 F0               [24] 1046 	movx	@dptr,a
      004B27 74 32            [12] 1047 	mov	a,#0x32
      004B29 A3               [24] 1048 	inc	dptr
      004B2A F0               [24] 1049 	movx	@dptr,a
      004B2B                       1050 00112$:
                                   1051 ;	keyboards/ajazz/ak820/ak820_tapping.c:100: kind = code >> 8;
      004B2B 90 06 F5         [24] 1052 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004B2E E0               [24] 1053 	movx	a,@dptr
      004B2F A3               [24] 1054 	inc	dptr
      004B30 E0               [24] 1055 	movx	a,@dptr
      004B31 FF               [12] 1056 	mov	r7,a
                                   1057 ;	keyboards/ajazz/ak820/ak820_tapping.c:101: if (kind < 0x20 || kind >= 0x50) return true;
      004B32 BF 20 00         [24] 1058 	cjne	r7,#0x20,00242$
      004B35                       1059 00242$:
      004B35 40 05            [24] 1060 	jc	00113$
      004B37 BF 50 00         [24] 1061 	cjne	r7,#0x50,00244$
      004B3A                       1062 00244$:
      004B3A 40 04            [24] 1063 	jc	00114$
      004B3C                       1064 00113$:
      004B3C 75 82 01         [24] 1065 	mov	dpl, #0x01
      004B3F 22               [24] 1066 	ret
      004B40                       1067 00114$:
                                   1068 ;	keyboards/ajazz/ak820/ak820_tapping.c:102: if (kind >= 0x40 && (kind & 15) >= MAX_LAYER) return false;
      004B40 BF 40 00         [24] 1069 	cjne	r7,#0x40,00246$
      004B43                       1070 00246$:
      004B43 40 0C            [24] 1071 	jc	00117$
      004B45 53 07 0F         [24] 1072 	anl	ar7,#0x0f
      004B48 BF 06 00         [24] 1073 	cjne	r7,#0x06,00248$
      004B4B                       1074 00248$:
      004B4B 40 04            [24] 1075 	jc	00117$
      004B4D 75 82 00         [24] 1076 	mov	dpl, #0x00
      004B50 22               [24] 1077 	ret
      004B51                       1078 00117$:
                                   1079 ;	keyboards/ajazz/ak820/ak820_tapping.c:103: if (record->event.pressed) {
      004B51 90 06 F3         [24] 1080 	mov	dptr,#_ak820_tapping_process_record_10000_624
      004B54 12 37 F7         [24] 1081 	lcall	_ak820_outline_0056
      004B57 74 05            [12] 1082 	mov	a,#0x05
      004B59 12 4D 72         [24] 1083 	lcall	_ak820_outline_0014
      004B5C 60 20            [24] 1084 	jz	00131$
                                   1085 ;	keyboards/ajazz/ak820/ak820_tapping.c:104: pending = id;
      004B5E 90 0E 70         [24] 1086 	mov	dptr,#_pending
      004B61 ED               [12] 1087 	mov	a,r5
      004B62 F0               [24] 1088 	movx	@dptr,a
                                   1089 ;	keyboards/ajazz/ak820/ak820_tapping.c:105: pending_time = record->event.time;
      004B63 12 37 E7         [24] 1090 	lcall	_ak820_outline_0034
      004B66 FE               [12] 1091 	mov	r6,a
      004B67 A3               [24] 1092 	inc	dptr
      004B68 E0               [24] 1093 	movx	a,@dptr
      004B69 FF               [12] 1094 	mov	r7,a
      004B6A 90 06 E6         [24] 1095 	mov	dptr,#_pending_time
      004B6D 12 48 CB         [24] 1096 	lcall	_ak820_outline_0064
                                   1097 ;	keyboards/ajazz/ak820/ak820_tapping.c:106: pending_code = code;
      004B70 90 06 F5         [24] 1098 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004B73 12 37 F7         [24] 1099 	lcall	_ak820_outline_0056
      004B76 90 06 E8         [24] 1100 	mov	dptr,#_pending_code
      004B79 12 48 CB         [24] 1101 	lcall	_ak820_outline_0064
      004B7C 81 19            [12] 1102 	ajmp	00132$
      004B7E                       1103 00131$:
                                   1104 ;	keyboards/ajazz/ak820/ak820_tapping.c:107: } else if (id == pending) {
      004B7E 90 0E 70         [24] 1105 	mov	dptr,#_pending
      004B81 E0               [24] 1106 	movx	a,@dptr
      004B82 FF               [12] 1107 	mov	r7,a
      004B83 ED               [12] 1108 	mov	a,r5
      004B84 B5 07 02         [24] 1109 	cjne	a,ar7,00251$
      004B87 80 02            [24] 1110 	sjmp	00252$
      004B89                       1111 00251$:
      004B89 61 F3            [12] 1112 	ajmp	00128$
      004B8B                       1113 00252$:
                                   1114 ;	keyboards/ajazz/ak820/ak820_tapping.c:108: pending = NONE;
      004B8B 12 4D C3         [24] 1115 	lcall	_ak820_outline_0156
                                   1116 ;	keyboards/ajazz/ak820/ak820_tapping.c:110: if (sc_mods) add_owned_mods(sc_mods);
      004B8E 90 06 F7         [24] 1117 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_625
      004B91 E0               [24] 1118 	movx	a,@dptr
      004B92 FF               [12] 1119 	mov	r7,a
      004B93 E0               [24] 1120 	movx	a,@dptr
      004B94 60 05            [24] 1121 	jz	00120$
      004B96 8F 82            [24] 1122 	mov	dpl, r7
      004B98 12 80 CF         [24] 1123 	lcall	_add_owned_mods
      004B9B                       1124 00120$:
                                   1125 ;	keyboards/ajazz/ak820/ak820_tapping.c:114: record->keycode = (uint8_t)code;
      004B9B 90 06 F3         [24] 1126 	mov	dptr,#_ak820_tapping_process_record_10000_624
      004B9E 12 37 F7         [24] 1127 	lcall	_ak820_outline_0056
      004BA1 74 07            [12] 1128 	mov	a,#0x07
      004BA3 2E               [12] 1129 	add	a, r6
      004BA4 FB               [12] 1130 	mov	r3,a
      004BA5 E4               [12] 1131 	clr	a
      004BA6 3F               [12] 1132 	addc	a, r7
      004BA7 FC               [12] 1133 	mov	r4,a
      004BA8 90 06 F5         [24] 1134 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004BAB E0               [24] 1135 	movx	a,@dptr
      004BAC F9               [12] 1136 	mov	r1,a
      004BAD 7A 00            [12] 1137 	mov	r2,#0x00
      004BAF 12 33 FC         [24] 1138 	lcall	_ak820_outline_0124
      004BB2 E9               [12] 1139 	mov	a,r1
      004BB3 F0               [24] 1140 	movx	@dptr,a
      004BB4 EA               [12] 1141 	mov	a,r2
      004BB5 A3               [24] 1142 	inc	dptr
      004BB6 F0               [24] 1143 	movx	@dptr,a
                                   1144 ;	keyboards/ajazz/ak820/ak820_tapping.c:115: if (record->keycode > KC_TRANSPARENT) {
      004BB7 C3               [12] 1145 	clr	c
      004BB8 04               [12] 1146 	inc	a
      004BB9 99               [12] 1147 	subb	a,r1
      004BBA 50 25            [24] 1148 	jnc	00122$
                                   1149 ;	free result
                                   1150 ;	keyboards/ajazz/ak820/ak820_tapping.c:116: record->tap.count = 1;
      004BBC 74 06            [12] 1151 	mov	a,#0x06
      004BBE 12 37 D6         [24] 1152 	lcall	_ak820_outline_0017
      004BC1 54 0F            [12] 1153 	anl	a,#0x0f
      004BC3 44 10            [12] 1154 	orl	a,#0x10
      004BC5 F0               [24] 1155 	movx	@dptr,a
                                   1156 ;	keyboards/ajazz/ak820/ak820_tapping.c:117: record->event.pressed = true;
      004BC6 12 42 C2         [24] 1157 	lcall	_ak820_outline_0013
      004BC9 12 4D A6         [24] 1158 	lcall	_ak820_outline_0060
                                   1159 ;	keyboards/ajazz/ak820/ak820_tapping.c:118: process_record(record);
      004BCC 12 75 71         [24] 1160 	lcall	_process_record
                                   1161 ;	keyboards/ajazz/ak820/ak820_tapping.c:119: record->event.pressed = false;
      004BCF 90 06 F3         [24] 1162 	mov	dptr,#_ak820_tapping_process_record_10000_624
      004BD2 12 37 A8         [24] 1163 	lcall	_ak820_outline_0005
      004BD5 A3               [24] 1164 	inc	dptr
      004BD6 A3               [24] 1165 	inc	dptr
      004BD7 A3               [24] 1166 	inc	dptr
      004BD8 A3               [24] 1167 	inc	dptr
      004BD9 A3               [24] 1168 	inc	dptr
      004BDA E4               [12] 1169 	clr	a
      004BDB 12 42 F8         [24] 1170 	lcall	_ak820_outline_0066
                                   1171 ;	keyboards/ajazz/ak820/ak820_tapping.c:120: process_record(record);
      004BDE 12 75 71         [24] 1172 	lcall	_process_record
      004BE1                       1173 00122$:
                                   1174 ;	keyboards/ajazz/ak820/ak820_tapping.c:123: if (sc_mods) {
      004BE1 90 06 F7         [24] 1175 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_625
      004BE4 E0               [24] 1176 	movx	a,@dptr
      004BE5 FF               [12] 1177 	mov	r7,a
      004BE6 E0               [24] 1178 	movx	a,@dptr
      004BE7 60 30            [24] 1179 	jz	00132$
                                   1180 ;	keyboards/ajazz/ak820/ak820_tapping.c:124: del_owned_mods(sc_mods);
      004BE9 8F 82            [24] 1181 	mov	dpl, r7
      004BEB 12 80 DF         [24] 1182 	lcall	_del_owned_mods
                                   1183 ;	keyboards/ajazz/ak820/ak820_tapping.c:125: send_keyboard_report();
      004BEE 12 84 08         [24] 1184 	lcall	_send_keyboard_report
      004BF1 80 26            [24] 1185 	sjmp	00132$
      004BF3                       1186 00128$:
                                   1187 ;	keyboards/ajazz/ak820/ak820_tapping.c:128: } else if ((source_state[id] & SOURCE_HELD)) {
      004BF3 ED               [12] 1188 	mov	a,r5
      004BF4 24 64            [12] 1189 	add	a, #_source_state
      004BF6 FE               [12] 1190 	mov	r6,a
      004BF7 E4               [12] 1191 	clr	a
      004BF8 34 06            [12] 1192 	addc	a, #(_source_state >> 8)
      004BFA FF               [12] 1193 	mov	r7,a
      004BFB 12 38 35         [24] 1194 	lcall	_ak820_outline_0088
      004BFE FD               [12] 1195 	mov	r5,a
      004BFF 30 E2 17         [24] 1196 	jnb	acc.2,00132$
                                   1197 ;	keyboards/ajazz/ak820/ak820_tapping.c:129: source_state[id] &= ~SOURCE_HELD;
      004C02 53 05 FB         [24] 1198 	anl	ar5,#0xfb
      004C05 12 43 23         [24] 1199 	lcall	_ak820_outline_0119
      004C08 ED               [12] 1200 	mov	a,r5
      004C09 F0               [24] 1201 	movx	@dptr,a
                                   1202 ;	keyboards/ajazz/ak820/ak820_tapping.c:130: hold(code, false);
      004C0A 90 06 F5         [24] 1203 	mov	dptr,#_ak820_tapping_process_code_10000_625
      004C0D 12 37 F7         [24] 1204 	lcall	_ak820_outline_0056
      004C10 90 06 EC         [24] 1205 	mov	dptr,#_hold_PARM_2
      004C13 E4               [12] 1206 	clr	a
      004C14 12 42 F8         [24] 1207 	lcall	_ak820_outline_0066
      004C17 31 2C            [12] 1208 	acall	_hold
      004C19                       1209 00132$:
                                   1210 ;	keyboards/ajazz/ak820/ak820_tapping.c:132: return false;
      004C19 75 82 00         [24] 1211 	mov	dpl, #0x00
                                   1212 ;	keyboards/ajazz/ak820/ak820_tapping.c:133: }
      004C1C 22               [24] 1213 	ret
                                   1214 ;------------------------------------------------------------
                                   1215 ;Allocation info for local variables in function 'ak820_tapping_cancel'
                                   1216 ;------------------------------------------------------------
                                   1217 ;i             Allocated with name '_ak820_tapping_cancel_i_20000_648'
                                   1218 ;state         Allocated with name '_ak820_tapping_cancel_state_30000_649'
                                   1219 ;------------------------------------------------------------
                                   1220 ;	keyboards/ajazz/ak820/ak820_tapping.c:134: void ak820_tapping_cancel(void) {
                                   1221 ;	-----------------------------------------
                                   1222 ;	 function ak820_tapping_cancel
                                   1223 ;	-----------------------------------------
      004C1D                       1224 _ak820_tapping_cancel:
                                   1225 ;	keyboards/ajazz/ak820/ak820_tapping.c:135: pending = NONE;
      004C1D 12 4D C3         [24] 1226 	lcall	_ak820_outline_0156
                                   1227 ;	keyboards/ajazz/ak820/ak820_tapping.c:136: for (uint8_t i = 0; i < SOURCES; ++i) {
      004C20 7F 00            [12] 1228 	mov	r7,#0x00
      004C22                       1229 00103$:
      004C22 BF 82 00         [24] 1230 	cjne	r7,#0x82,00122$
      004C25                       1231 00122$:
      004C25 50 16            [24] 1232 	jnc	00105$
                                   1233 ;	keyboards/ajazz/ak820/ak820_tapping.c:137: uint8_t state = source_state[i];
      004C27 12 4D 7D         [24] 1234 	lcall	_ak820_outline_0020
                                   1235 ;	keyboards/ajazz/ak820/ak820_tapping.c:138: source_state[i] = (state & SOURCE_BLOCKED) | ((state & SOURCE_ACTIVE) << 1);
      004C2A 74 02            [12] 1236 	mov	a,#0x02
      004C2C 5C               [12] 1237 	anl	a,r4
      004C2D FB               [12] 1238 	mov	r3,a
      004C2E 53 04 01         [24] 1239 	anl	ar4,#0x01
      004C31 EC               [12] 1240 	mov	a,r4
      004C32 2C               [12] 1241 	add	a,r4
      004C33 42 03            [12] 1242 	orl	ar3,a
      004C35 12 38 61         [24] 1243 	lcall	_ak820_outline_0137
      004C38 EB               [12] 1244 	mov	a,r3
      004C39 F0               [24] 1245 	movx	@dptr,a
                                   1246 ;	keyboards/ajazz/ak820/ak820_tapping.c:136: for (uint8_t i = 0; i < SOURCES; ++i) {
      004C3A 0F               [12] 1247 	inc	r7
      004C3B 80 E5            [24] 1248 	sjmp	00103$
      004C3D                       1249 00105$:
                                   1250 ;	keyboards/ajazz/ak820/ak820_tapping.c:140: }
      004C3D 22               [24] 1251 	ret
                                   1252 ;------------------------------------------------------------
                                   1253 ;Allocation info for local variables in function 'ak820_oneshot_process'
                                   1254 ;------------------------------------------------------------
                                   1255 ;id            Allocated with name '_ak820_oneshot_process_PARM_2'
                                   1256 ;pressed       Allocated with name '_ak820_oneshot_process_PARM_3'
                                   1257 ;code          Allocated with name '_ak820_oneshot_process_code_10000_650'
                                   1258 ;mods          Allocated with name '_ak820_oneshot_process_mods_10000_651'
                                   1259 ;i             Allocated with name '_ak820_oneshot_process_i_40000_665'
                                   1260 ;------------------------------------------------------------
                                   1261 ;	keyboards/ajazz/ak820/ak820_tapping.c:149: bool ak820_oneshot_process(uint16_t code, uint8_t id, bool pressed) {
                                   1262 ;	-----------------------------------------
                                   1263 ;	 function ak820_oneshot_process
                                   1264 ;	-----------------------------------------
      004C3E                       1265 _ak820_oneshot_process:
      004C3E 12 38 4C         [24] 1266 	lcall	_ak820_outline_0106
      004C41 90 06 FC         [24] 1267 	mov	dptr,#_ak820_oneshot_process_code_10000_650
      004C44 12 38 47         [24] 1268 	lcall	_ak820_outline_0105
                                   1269 ;	keyboards/ajazz/ak820/ak820_tapping.c:151: if (id == NONE || get_repeat_key_count()) return true;
      004C47 90 06 FA         [24] 1270 	mov	dptr,#_ak820_oneshot_process_PARM_2
      004C4A E0               [24] 1271 	movx	a,@dptr
      004C4B FF               [12] 1272 	mov	r7,a
      004C4C BF FF 02         [24] 1273 	cjne	r7,#0xff,00248$
      004C4F 80 07            [24] 1274 	sjmp	00101$
      004C51                       1275 00248$:
      004C51 12 A6 0D         [24] 1276 	lcall	_get_repeat_key_count
      004C54 E5 82            [12] 1277 	mov	a, dpl
      004C56 60 04            [24] 1278 	jz	00102$
      004C58                       1279 00101$:
      004C58 75 82 01         [24] 1280 	mov	dpl, #0x01
      004C5B 22               [24] 1281 	ret
      004C5C                       1282 00102$:
                                   1283 ;	keyboards/ajazz/ak820/ak820_tapping.c:164: if ((code >> 8) == 0x52 && ((uint8_t)code & 0xe0) == 0xa0) {
      004C5C 90 06 FC         [24] 1284 	mov	dptr,#_ak820_oneshot_process_code_10000_650
      004C5F E0               [24] 1285 	movx	a,@dptr
      004C60 FD               [12] 1286 	mov	r5,a
      004C61 A3               [24] 1287 	inc	dptr
      004C62 E0               [24] 1288 	movx	a,@dptr
      004C63 FB               [12] 1289 	mov	r3,a
      004C64 BB 52 02         [24] 1290 	cjne	r3,#0x52,00250$
      004C67 80 02            [24] 1291 	sjmp	00251$
      004C69                       1292 00250$:
      004C69 A1 0C            [12] 1293 	ajmp	00116$
      004C6B                       1294 00251$:
      004C6B 8D 04            [24] 1295 	mov	ar4,r5
      004C6D 53 04 E0         [24] 1296 	anl	ar4,#0xe0
      004C70 BC A0 02         [24] 1297 	cjne	r4,#0xa0,00252$
      004C73 80 02            [24] 1298 	sjmp	00253$
      004C75                       1299 00252$:
      004C75 A1 0C            [12] 1300 	ajmp	00116$
      004C77                       1301 00253$:
                                   1302 ;	keyboards/ajazz/ak820/ak820_tapping.c:165: mods = code & 15;
      004C77 8D 04            [24] 1303 	mov	ar4,r5
      004C79 53 04 0F         [24] 1304 	anl	ar4,#0x0f
      004C7C 90 06 FE         [24] 1305 	mov	dptr,#_ak820_oneshot_process_mods_10000_651
      004C7F EC               [12] 1306 	mov	a,r4
      004C80 F0               [24] 1307 	movx	@dptr,a
                                   1308 ;	keyboards/ajazz/ak820/ak820_tapping.c:166: if (code & 16) mods <<= 4;
      004C81 ED               [12] 1309 	mov	a,r5
      004C82 30 E4 08         [24] 1310 	jnb	acc.4,00105$
      004C85 EC               [12] 1311 	mov	a,r4
      004C86 C4               [12] 1312 	swap	a
      004C87 54 F0            [12] 1313 	anl	a,#0xf0
      004C89 90 06 FE         [24] 1314 	mov	dptr,#_ak820_oneshot_process_mods_10000_651
      004C8C F0               [24] 1315 	movx	@dptr,a
      004C8D                       1316 00105$:
                                   1317 ;	keyboards/ajazz/ak820/ak820_tapping.c:167: if (pressed) {
      004C8D 90 06 FB         [24] 1318 	mov	dptr,#_ak820_oneshot_process_PARM_3
      004C90 E0               [24] 1319 	movx	a,@dptr
      004C91 60 2D            [24] 1320 	jz	00113$
                                   1321 ;	keyboards/ajazz/ak820/ak820_tapping.c:168: source_state[id] |= SOURCE_ONESHOT;
      004C93 12 4D 7D         [24] 1322 	lcall	_ak820_outline_0020
      004C96 43 04 08         [24] 1323 	orl	ar4,#0x08
      004C99 12 42 FE         [24] 1324 	lcall	_ak820_outline_0069
                                   1325 ;	keyboards/ajazz/ak820/ak820_tapping.c:169: source_state[id] &= ~SOURCE_ONESHOT_USED;
      004C9C 53 04 EF         [24] 1326 	anl	ar4,#0xef
      004C9F 12 42 FE         [24] 1327 	lcall	_ak820_outline_0069
                                   1328 ;	keyboards/ajazz/ak820/ak820_tapping.c:170: if (ak820_oneshot_target != NONE) source_state[id] |= SOURCE_ONESHOT_USED;
      004CA2 90 0E 71         [24] 1329 	mov	dptr,#_ak820_oneshot_target
      004CA5 E0               [24] 1330 	movx	a,@dptr
      004CA6 FC               [12] 1331 	mov	r4,a
      004CA7 BC FF 02         [24] 1332 	cjne	r4,#0xff,00256$
      004CAA 80 09            [24] 1333 	sjmp	00107$
      004CAC                       1334 00256$:
      004CAC 12 4D AE         [24] 1335 	lcall	_ak820_outline_0078
      004CAF 43 04 10         [24] 1336 	orl	ar4,#0x10
      004CB2 12 42 FE         [24] 1337 	lcall	_ak820_outline_0069
      004CB5                       1338 00107$:
                                   1339 ;	keyboards/ajazz/ak820/ak820_tapping.c:171: register_mods(mods);
      004CB5 90 06 FE         [24] 1340 	mov	dptr,#_ak820_oneshot_process_mods_10000_651
      004CB8 E0               [24] 1341 	movx	a,@dptr
      004CB9 F5 82            [12] 1342 	mov	dpl,a
      004CBB 12 7A A4         [24] 1343 	lcall	_register_mods
      004CBE 80 48            [24] 1344 	sjmp	00114$
      004CC0                       1345 00113$:
                                   1346 ;	keyboards/ajazz/ak820/ak820_tapping.c:172: } else if (source_state[id] & SOURCE_ONESHOT) {
      004CC0 12 4D 7D         [24] 1347 	lcall	_ak820_outline_0020
      004CC3 30 E3 42         [24] 1348 	jnb	acc.3,00114$
                                   1349 ;	keyboards/ajazz/ak820/ak820_tapping.c:173: if (!(source_state[id] & SOURCE_ONESHOT_USED)) {
      004CC6 EC               [12] 1350 	mov	a,r4
      004CC7 20 E4 24         [24] 1351 	jb	acc.4,00109$
                                   1352 ;	keyboards/ajazz/ak820/ak820_tapping.c:174: add_owned_mods(mods & ~ak820_oneshot_mods);
      004CCA 90 06 F8         [24] 1353 	mov	dptr,#_ak820_oneshot_mods
      004CCD E0               [24] 1354 	movx	a,@dptr
      004CCE F4               [12] 1355 	cpl	a
      004CCF FC               [12] 1356 	mov	r4,a
      004CD0 90 06 FE         [24] 1357 	mov	dptr,#_ak820_oneshot_process_mods_10000_651
      004CD3 E0               [24] 1358 	movx	a,@dptr
      004CD4 FB               [12] 1359 	mov	r3,a
      004CD5 52 04            [12] 1360 	anl	ar4,a
      004CD7 8C 82            [24] 1361 	mov	dpl, r4
      004CD9 C0 06            [24] 1362 	push	ar6
      004CDB C0 05            [24] 1363 	push	ar5
      004CDD C0 03            [24] 1364 	push	ar3
      004CDF 12 80 CF         [24] 1365 	lcall	_add_owned_mods
      004CE2 D0 03            [24] 1366 	pop	ar3
      004CE4 D0 05            [24] 1367 	pop	ar5
      004CE6 D0 06            [24] 1368 	pop	ar6
                                   1369 ;	keyboards/ajazz/ak820/ak820_tapping.c:175: ak820_oneshot_mods |= mods;
      004CE8 90 06 F8         [24] 1370 	mov	dptr,#_ak820_oneshot_mods
      004CEB E0               [24] 1371 	movx	a,@dptr
      004CEC 4B               [12] 1372 	orl	a,r3
      004CED F0               [24] 1373 	movx	@dptr,a
      004CEE                       1374 00109$:
                                   1375 ;	keyboards/ajazz/ak820/ak820_tapping.c:177: unregister_mods(mods);
      004CEE 90 06 FE         [24] 1376 	mov	dptr,#_ak820_oneshot_process_mods_10000_651
      004CF1 E0               [24] 1377 	movx	a,@dptr
      004CF2 F5 82            [12] 1378 	mov	dpl,a
      004CF4 C0 06            [24] 1379 	push	ar6
      004CF6 C0 05            [24] 1380 	push	ar5
      004CF8 12 7A B8         [24] 1381 	lcall	_unregister_mods
      004CFB D0 05            [24] 1382 	pop	ar5
      004CFD D0 06            [24] 1383 	pop	ar6
                                   1384 ;	keyboards/ajazz/ak820/ak820_tapping.c:178: source_state[id] &= ~(SOURCE_ONESHOT | SOURCE_ONESHOT_USED);
      004CFF 12 4D AE         [24] 1385 	lcall	_ak820_outline_0078
      004D02 53 04 E7         [24] 1386 	anl	ar4,#0xe7
      004D05 12 42 FE         [24] 1387 	lcall	_ak820_outline_0069
      004D08                       1388 00114$:
                                   1389 ;	keyboards/ajazz/ak820/ak820_tapping.c:180: return false;
      004D08 75 82 00         [24] 1390 	mov	dpl, #0x00
      004D0B 22               [24] 1391 	ret
      004D0C                       1392 00116$:
                                   1393 ;	keyboards/ajazz/ak820/ak820_tapping.c:182: if (pressed && code > KC_TRANSPARENT &&
      004D0C 90 06 FB         [24] 1394 	mov	dptr,#_ak820_oneshot_process_PARM_3
      004D0F E0               [24] 1395 	movx	a,@dptr
      004D10 60 5C            [24] 1396 	jz	00124$
      004D12 90 06 FC         [24] 1397 	mov	dptr,#_ak820_oneshot_process_code_10000_650
      004D15 12 43 11         [24] 1398 	lcall	_ak820_outline_0098
      004D18 C3               [12] 1399 	clr	c
      004D19 74 01            [12] 1400 	mov	a,#0x01
      004D1B 9D               [12] 1401 	subb	a,r5
      004D1C E4               [12] 1402 	clr	a
      004D1D 9E               [12] 1403 	subb	a,r6
      004D1E 50 4E            [24] 1404 	jnc	00124$
                                   1405 ;	free result
                                   1406 ;	keyboards/ajazz/ak820/ak820_tapping.c:183: !(code >= KC_LCTL && code <= KC_RGUI) &&
      004D20 C3               [12] 1407 	clr	c
      004D21 ED               [12] 1408 	mov	a,r5
      004D22 94 E0            [12] 1409 	subb	a,#0xe0
      004D24 EE               [12] 1410 	mov	a,r6
      004D25 94 00            [12] 1411 	subb	a,#0x00
      004D27 40 07            [24] 1412 	jc	00129$
      004D29 74 E7            [12] 1413 	mov	a,#0xe7
      004D2B 9D               [12] 1414 	subb	a,r5
      004D2C E4               [12] 1415 	clr	a
      004D2D 9E               [12] 1416 	subb	a,r6
      004D2E 50 3E            [24] 1417 	jnc	00124$
                                   1418 ;	free result
      004D30                       1419 00129$:
                                   1420 ;	keyboards/ajazz/ak820/ak820_tapping.c:184: !(code >= QK_TO && code <= QK_LAYER_TAP_TOGGLE_MAX)) {
      004D30 74 AE            [12] 1421 	mov	a,#0x100 - 0x52
      004D32 2E               [12] 1422 	add	a,r6
      004D33 50 09            [24] 1423 	jnc	00165$
      004D35 C3               [12] 1424 	clr	c
      004D36 74 DF            [12] 1425 	mov	a,#0xdf
      004D38 9D               [12] 1426 	subb	a,r5
      004D39 74 52            [12] 1427 	mov	a,#0x52
      004D3B 9E               [12] 1428 	subb	a,r6
      004D3C 50 30            [24] 1429 	jnc	00124$
                                   1430 ;	free result
                                   1431 ;	keyboards/ajazz/ak820/ak820_tapping.c:185: for (uint8_t i = 0; i < SOURCES; ++i)
      004D3E                       1432 00165$:
      004D3E 7E 00            [12] 1433 	mov	r6,#0x00
      004D40                       1434 00131$:
      004D40 BE 82 00         [24] 1435 	cjne	r6,#0x82,00265$
      004D43                       1436 00265$:
      004D43 50 12            [24] 1437 	jnc	00120$
                                   1438 ;	keyboards/ajazz/ak820/ak820_tapping.c:186: if (source_state[i] & SOURCE_ONESHOT) source_state[i] |= SOURCE_ONESHOT_USED;
      004D45 EE               [12] 1439 	mov	a,r6
      004D46 12 4D B5         [24] 1440 	lcall	_ak820_outline_0083
      004D49 30 E3 08         [24] 1441 	jnb	acc.3,00132$
      004D4C 43 03 10         [24] 1442 	orl	ar3,#0x10
      004D4F 12 38 51         [24] 1443 	lcall	_ak820_outline_0123
      004D52 EB               [12] 1444 	mov	a,r3
      004D53 F0               [24] 1445 	movx	@dptr,a
      004D54                       1446 00132$:
                                   1447 ;	keyboards/ajazz/ak820/ak820_tapping.c:185: for (uint8_t i = 0; i < SOURCES; ++i)
      004D54 0E               [12] 1448 	inc	r6
      004D55 80 E9            [24] 1449 	sjmp	00131$
      004D57                       1450 00120$:
                                   1451 ;	keyboards/ajazz/ak820/ak820_tapping.c:187: if (ak820_oneshot_mods) {
      004D57 90 06 F8         [24] 1452 	mov	dptr,#_ak820_oneshot_mods
      004D5A E0               [24] 1453 	movx	a,@dptr
      004D5B FE               [12] 1454 	mov	r6,a
      004D5C E0               [24] 1455 	movx	a,@dptr
      004D5D 60 0F            [24] 1456 	jz	00124$
                                   1457 ;	keyboards/ajazz/ak820/ak820_tapping.c:188: ak820_oneshot_consumed = ak820_oneshot_mods;
      004D5F 90 06 F9         [24] 1458 	mov	dptr,#_ak820_oneshot_consumed
      004D62 EE               [12] 1459 	mov	a,r6
      004D63 F0               [24] 1460 	movx	@dptr,a
                                   1461 ;	keyboards/ajazz/ak820/ak820_tapping.c:189: ak820_oneshot_target = id;
      004D64 90 0E 71         [24] 1462 	mov	dptr,#_ak820_oneshot_target
      004D67 EF               [12] 1463 	mov	a,r7
      004D68 F0               [24] 1464 	movx	@dptr,a
                                   1465 ;	keyboards/ajazz/ak820/ak820_tapping.c:190: ak820_oneshot_mods = 0;
      004D69 90 06 F8         [24] 1466 	mov	dptr,#_ak820_oneshot_mods
      004D6C E4               [12] 1467 	clr	a
      004D6D F0               [24] 1468 	movx	@dptr,a
      004D6E                       1469 00124$:
                                   1470 ;	keyboards/ajazz/ak820/ak820_tapping.c:193: return true;
      004D6E 75 82 01         [24] 1471 	mov	dpl, #0x01
                                   1472 ;	keyboards/ajazz/ak820/ak820_tapping.c:194: }
      004D71 22               [24] 1473 	ret
                                   1474 	.area CSEG    (CODE)
                                   1475 	.area CONST   (CODE)
                                   1476 	.area XINIT   (CODE)
      00C54E                       1477 __xinit__pending:
      00C54E FF                    1478 	.db #0xff	; 255
      00C54F                       1479 __xinit__ak820_oneshot_target:
      00C54F FF                    1480 	.db #0xff	; 255
                                   1481 	.area CABS    (ABS,CODE)
                                   1482 
                                   1483 ; Experimental exact instruction outlining.
                                   1484 	.globl _ak820_outline_0001
                                   1485 	.globl _ak820_outline_0005
                                   1486 	.globl _ak820_outline_0010
                                   1487 	.globl _ak820_outline_0012
                                   1488 	.globl _ak820_outline_0013
                                   1489 	.globl _ak820_outline_0014
                                   1490 	.globl _ak820_outline_0016
                                   1491 	.globl _ak820_outline_0017
                                   1492 	.globl _ak820_outline_0020
                                   1493 	.globl _ak820_outline_0024
                                   1494 	.globl _ak820_outline_0033
                                   1495 	.globl _ak820_outline_0034
                                   1496 	.globl _ak820_outline_0049
                                   1497 	.globl _ak820_outline_0056
                                   1498 	.globl _ak820_outline_0060
                                   1499 	.globl _ak820_outline_0064
                                   1500 	.globl _ak820_outline_0066
                                   1501 	.globl _ak820_outline_0069
                                   1502 	.globl _ak820_outline_0078
                                   1503 	.globl _ak820_outline_0083
                                   1504 	.globl _ak820_outline_0088
                                   1505 	.globl _ak820_outline_0098
                                   1506 	.globl _ak820_outline_0102
                                   1507 	.globl _ak820_outline_0105
                                   1508 	.globl _ak820_outline_0106
                                   1509 	.globl _ak820_outline_0119
                                   1510 	.globl _ak820_outline_0123
                                   1511 	.globl _ak820_outline_0124
                                   1512 	.globl _ak820_outline_0137
                                   1513 	.globl _ak820_outline_0156
                                   1514 	.globl _ak820_outline_0159
                                   1515 	.globl _ak820_outline_0161
                                   1516 
                                   1517 	.area CSEG (CODE)
                                   1518 ; function ak820_outline_0014
      004D72                       1519 _ak820_outline_0014:
      004D72 2E               [12] 1520 	add	a,r6
      004D73 FB               [12] 1521 	mov	r3,a
      004D74 E4               [12] 1522 	clr	a
      004D75 3F               [12] 1523 	addc	a,r7
      004D76 FC               [12] 1524 	mov	r4,a
      004D77 8B 82            [24] 1525 	mov	dpl,r3
      004D79 8C 83            [24] 1526 	mov	dph,r4
      004D7B E0               [24] 1527 	movx	a,@dptr
      004D7C 22               [24] 1528 	ret
                                   1529 
                                   1530 	.area CSEG (CODE)
                                   1531 ; function ak820_outline_0020
      004D7D                       1532 _ak820_outline_0020:
      004D7D EF               [12] 1533 	mov	a,r7
      004D7E 24 64            [12] 1534 	add	a,#_source_state
      004D80 FD               [12] 1535 	mov	r5,a
      004D81 E4               [12] 1536 	clr	a
      004D82 34 06            [12] 1537 	addc	a,#(_source_state>>8)
      004D84 FE               [12] 1538 	mov	r6,a
      004D85 8D 82            [24] 1539 	mov	dpl,r5
      004D87 8E 83            [24] 1540 	mov	dph,r6
      004D89 E0               [24] 1541 	movx	a,@dptr
      004D8A FC               [12] 1542 	mov	r4,a
      004D8B 22               [24] 1543 	ret
                                   1544 
                                   1545 	.area CSEG (CODE)
                                   1546 ; function ak820_outline_0024
      004D8C                       1547 _ak820_outline_0024:
      004D8C 90 0E 60         [24] 1548 	mov	dptr,#___memcpy_PARM_2
      004D8F EC               [12] 1549 	mov	a,r4
      004D90 F0               [24] 1550 	movx	@dptr,a
      004D91 ED               [12] 1551 	mov	a,r5
      004D92 A3               [24] 1552 	inc	dptr
      004D93 F0               [24] 1553 	movx	@dptr,a
      004D94 E4               [12] 1554 	clr	a
      004D95 A3               [24] 1555 	inc	dptr
      004D96 F0               [24] 1556 	movx	@dptr,a
      004D97 90 0E 63         [24] 1557 	mov	dptr,#___memcpy_PARM_3
      004D9A 74 02            [12] 1558 	mov	a,#0x02
      004D9C F0               [24] 1559 	movx	@dptr,a
      004D9D E4               [12] 1560 	clr	a
      004D9E A3               [24] 1561 	inc	dptr
      004D9F F0               [24] 1562 	movx	@dptr,a
      004DA0 90 06 EA         [24] 1563 	mov	dptr,#_ak820_tapping_source_PARM_1
      004DA3 F5 F0            [12] 1564 	mov	b,a
      004DA5 22               [24] 1565 	ret
                                   1566 
                                   1567 	.area CSEG (CODE)
                                   1568 ; function ak820_outline_0060
      004DA6                       1569 _ak820_outline_0060:
      004DA6 74 01            [12] 1570 	mov	a,#0x01
      004DA8 F0               [24] 1571 	movx	@dptr,a
      004DA9 8E 82            [24] 1572 	mov	dpl,r6
      004DAB 8F 83            [24] 1573 	mov	dph,r7
      004DAD 22               [24] 1574 	ret
                                   1575 
                                   1576 	.area CSEG (CODE)
                                   1577 ; function ak820_outline_0078
      004DAE                       1578 _ak820_outline_0078:
      004DAE 8D 82            [24] 1579 	mov	dpl,r5
      004DB0 8E 83            [24] 1580 	mov	dph,r6
      004DB2 E0               [24] 1581 	movx	a,@dptr
      004DB3 FC               [12] 1582 	mov	r4,a
      004DB4 22               [24] 1583 	ret
                                   1584 
                                   1585 	.area CSEG (CODE)
                                   1586 ; function ak820_outline_0083
      004DB5                       1587 _ak820_outline_0083:
      004DB5 24 64            [12] 1588 	add	a,#_source_state
      004DB7 FC               [12] 1589 	mov	r4,a
      004DB8 E4               [12] 1590 	clr	a
      004DB9 34 06            [12] 1591 	addc	a,#(_source_state>>8)
      004DBB FD               [12] 1592 	mov	r5,a
      004DBC 8C 82            [24] 1593 	mov	dpl,r4
      004DBE 8D 83            [24] 1594 	mov	dph,r5
      004DC0 E0               [24] 1595 	movx	a,@dptr
      004DC1 FB               [12] 1596 	mov	r3,a
      004DC2 22               [24] 1597 	ret
                                   1598 
                                   1599 	.area CSEG (CODE)
                                   1600 ; function ak820_outline_0156
      004DC3                       1601 _ak820_outline_0156:
      004DC3 90 0E 70         [24] 1602 	mov	dptr,#_pending
      004DC6 74 FF            [12] 1603 	mov	a,#0xff
      004DC8 F0               [24] 1604 	movx	@dptr,a
      004DC9 22               [24] 1605 	ret
