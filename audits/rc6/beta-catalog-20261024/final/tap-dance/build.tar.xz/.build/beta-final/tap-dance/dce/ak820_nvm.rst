                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_nvm
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _eeprom_driver_erase
                                     12 	.globl _eeprom_read_byte
                                     13 	.globl _eeprom_driver_init
                                     14 	.globl _ak820_macro_init
                                     15 	.globl _ak820_flash_program_page
                                     16 	.globl _ak820_flash_program
                                     17 	.globl _ak820_flash_erase
                                     18 	.globl _ak820_flash_read
                                     19 	.globl _ak820_eeprom_update_block_xdata_PARM_3
                                     20 	.globl _ak820_eeprom_update_block_xdata_PARM_2
                                     21 	.globl _ak820_eeprom_write_block_xdata_PARM_3
                                     22 	.globl _ak820_eeprom_write_block_xdata_PARM_2
                                     23 	.globl _ak820_eeprom_read_block_xdata_PARM_3
                                     24 	.globl _ak820_eeprom_read_block_xdata_PARM_2
                                     25 	.globl _ak820_nvm_diagnostic
                                     26 	.globl _ak820_nvm_ok
                                     27 	.globl _ak820_nvm_schema_fault
                                     28 	.globl _ak820_nvm_flush
                                     29 	.globl _ak820_nvm_begin
                                     30 	.globl _ak820_nvm_end
                                     31 	.globl _ak820_eeprom_read_block_xdata
                                     32 	.globl _ak820_eeprom_write_block_xdata
                                     33 	.globl _ak820_eeprom_update_block_xdata
                                     34 ;--------------------------------------------------------
                                     35 ; special function registers
                                     36 ;--------------------------------------------------------
                                     37 	.area RSEG    (ABS,DATA)
      000000                         38 	.org 0x0000
                                     39 ;--------------------------------------------------------
                                     40 ; special function bits
                                     41 ;--------------------------------------------------------
                                     42 	.area RSEG    (ABS,DATA)
      000000                         43 	.org 0x0000
                                     44 ;--------------------------------------------------------
                                     45 ; overlayable register banks
                                     46 ;--------------------------------------------------------
                                     47 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         48 	.ds 8
                                     49 ;--------------------------------------------------------
                                     50 ; overlayable bit register bank
                                     51 ;--------------------------------------------------------
                                     52 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         53 bits:
      000026                         54 	.ds 1
                           008000    55 	b0 = bits[0]
                           008100    56 	b1 = bits[1]
                           008200    57 	b2 = bits[2]
                           008300    58 	b3 = bits[3]
                           008400    59 	b4 = bits[4]
                           008500    60 	b5 = bits[5]
                           008600    61 	b6 = bits[6]
                           008700    62 	b7 = bits[7]
                                     63 ;--------------------------------------------------------
                                     64 ; internal ram data
                                     65 ;--------------------------------------------------------
                                     66 	.area DSEG    (DATA)
      00000C                         67 _ak820_eeprom_write_block_xdata_sloc0_1_0:
      00000C                         68 	.ds 2
      00000E                         69 _ak820_eeprom_update_block_xdata_sloc0_1_0:
      00000E                         70 	.ds 2
      000010                         71 _ak820_eeprom_update_block_xdata_sloc1_1_0:
      000010                         72 	.ds 2
      000012                         73 _ak820_eeprom_update_block_xdata_sloc2_1_0:
      000012                         74 	.ds 3
                                     75 ;--------------------------------------------------------
                                     76 ; overlayable items in internal ram
                                     77 ;--------------------------------------------------------
                                     78 ;--------------------------------------------------------
                                     79 ; indirectly addressable internal ram data
                                     80 ;--------------------------------------------------------
                                     81 	.area ISEG    (DATA)
                                     82 ;--------------------------------------------------------
                                     83 ; absolute internal ram data
                                     84 ;--------------------------------------------------------
                                     85 	.area IABS    (ABS,DATA)
                                     86 	.area IABS    (ABS,DATA)
                                     87 ;--------------------------------------------------------
                                     88 ; bit data
                                     89 ;--------------------------------------------------------
                                     90 	.area BSEG    (BIT)
      000007                         91 _page_valid:
      000007                         92 	.ds 1
      000008                         93 _page_dirty:
      000008                         94 	.ds 1
      000009                         95 _storage_failed:
      000009                         96 	.ds 1
      00000A                         97 _ak820_nvm_ok_sloc0_1_0:
      00000A                         98 	.ds 1
      00000B                         99 _load_page_sloc0_1_0:
      00000B                        100 	.ds 1
                                    101 ;--------------------------------------------------------
                                    102 ; paged external ram data
                                    103 ;--------------------------------------------------------
                                    104 	.area PSEG    (PAG,XDATA)
                                    105 ;--------------------------------------------------------
                                    106 ; uninitialized external ram data
                                    107 ;--------------------------------------------------------
                                    108 	.area XSEG    (XDATA)
      000519                        109 _page_data:
      000519                        110 	.ds 64
      000559                        111 _cached_page:
      000559                        112 	.ds 1
      00055A                        113 _batch_depth:
      00055A                        114 	.ds 1
      00055B                        115 _first_failure_stage:
      00055B                        116 	.ds 1
      00055C                        117 _nvm_fail_stage_10000_20:
      00055C                        118 	.ds 1
      00055D                        119 _ak820_nvm_diagnostic_out_10000_23:
      00055D                        120 	.ds 2
      00055F                        121 _crc_byte_PARM_2:
      00055F                        122 	.ds 1
      000560                        123 _crc_byte_crc_10000_25:
      000560                        124 	.ds 2
      000562                        125 _page_crc_crc_10000_30:
      000562                        126 	.ds 2
      000564                        127 _write_page_address_10000_32:
      000564                        128 	.ds 2
      000566                        129 _journal_header_valid_header_10000_39:
      000566                        130 	.ds 2
      000568                        131 _recover_journal_header_10000_46:
      000568                        132 	.ds 9
      000571                        133 _ak820_nvm_flush_header_10000_62:
      000571                        134 	.ds 9
      00057A                        135 _ak820_nvm_flush_stage_10000_62:
      00057A                        136 	.ds 1
      00057B                        137 _load_page_page_10000_87:
      00057B                        138 	.ds 1
      00057C                        139 _read_offset_offset_10000_93:
      00057C                        140 	.ds 2
      00057E                        141 _eeprom_read_byte_addr_10000_97:
      00057E                        142 	.ds 3
      000581                        143 _ak820_eeprom_read_block_xdata_PARM_2:
      000581                        144 	.ds 3
      000584                        145 _ak820_eeprom_read_block_xdata_PARM_3:
      000584                        146 	.ds 2
      000586                        147 _ak820_eeprom_read_block_xdata_buf_10000_113:
      000586                        148 	.ds 2
      000588                        149 _ak820_eeprom_read_block_xdata_out_10000_114:
      000588                        150 	.ds 2
      00058A                        151 _ak820_eeprom_write_block_xdata_PARM_2:
      00058A                        152 	.ds 3
      00058D                        153 _ak820_eeprom_write_block_xdata_PARM_3:
      00058D                        154 	.ds 2
      00058F                        155 _ak820_eeprom_write_block_xdata_buf_10000_118:
      00058F                        156 	.ds 2
      000591                        157 _ak820_eeprom_update_block_xdata_PARM_2:
      000591                        158 	.ds 3
      000594                        159 _ak820_eeprom_update_block_xdata_PARM_3:
      000594                        160 	.ds 2
      000596                        161 _ak820_eeprom_update_block_xdata_buf_10000_127:
      000596                        162 	.ds 2
                                    163 ;--------------------------------------------------------
                                    164 ; absolute external ram data
                                    165 ;--------------------------------------------------------
                                    166 	.area XABS    (ABS,XDATA)
                                    167 ;--------------------------------------------------------
                                    168 ; initialized external ram data
                                    169 ;--------------------------------------------------------
                                    170 	.area XISEG   (XDATA)
                                    171 	.area HOME    (CODE)
                                    172 	.area GSINIT0 (CODE)
                                    173 	.area GSINIT1 (CODE)
                                    174 	.area GSINIT2 (CODE)
                                    175 	.area GSINIT3 (CODE)
                                    176 	.area GSINIT4 (CODE)
                                    177 	.area GSINIT5 (CODE)
                                    178 	.area GSINIT  (CODE)
                                    179 	.area GSFINAL (CODE)
                                    180 	.area CSEG    (CODE)
                                    181 ;--------------------------------------------------------
                                    182 ; global & static initialisations
                                    183 ;--------------------------------------------------------
                                    184 	.area HOME    (CODE)
                                    185 	.area GSINIT  (CODE)
                                    186 	.area GSFINAL (CODE)
                                    187 	.area GSINIT  (CODE)
                                    188 ;--------------------------------------------------------
                                    189 ; Home
                                    190 ;--------------------------------------------------------
                                    191 	.area HOME    (CODE)
                                    192 	.area HOME    (CODE)
                                    193 ;--------------------------------------------------------
                                    194 ; code
                                    195 ;--------------------------------------------------------
                                    196 	.area CSEG    (CODE)
                                    197 ;------------------------------------------------------------
                                    198 ;Allocation info for local variables in function 'nvm_fail'
                                    199 ;------------------------------------------------------------
                                    200 ;stage         Allocated with name '_nvm_fail_stage_10000_20'
                                    201 ;------------------------------------------------------------
                                    202 ;	keyboards/ajazz/ak820/ak820_nvm.c:31: static void nvm_fail(uint8_t stage) {
                                    203 ;	-----------------------------------------
                                    204 ;	 function nvm_fail
                                    205 ;	-----------------------------------------
      003B43                        206 _nvm_fail:
                           000007   207 	ar7 = 0x07
                           000006   208 	ar6 = 0x06
                           000005   209 	ar5 = 0x05
                           000004   210 	ar4 = 0x04
                           000003   211 	ar3 = 0x03
                           000002   212 	ar2 = 0x02
                           000001   213 	ar1 = 0x01
                           000000   214 	ar0 = 0x00
      003B43 E5 82            [12]  215 	mov	a,dpl
      003B45 90 05 5C         [24]  216 	mov	dptr,#_nvm_fail_stage_10000_20
      003B48 F0               [24]  217 	movx	@dptr,a
                                    218 ;	keyboards/ajazz/ak820/ak820_nvm.c:32: if (!storage_failed) first_failure_stage = stage;
      003B49 20 09 08         [24]  219 	jb	_storage_failed,00102$
      003B4C 90 05 5C         [24]  220 	mov	dptr,#_nvm_fail_stage_10000_20
      003B4F E0               [24]  221 	movx	a,@dptr
      003B50 90 05 5B         [24]  222 	mov	dptr,#_first_failure_stage
      003B53 F0               [24]  223 	movx	@dptr,a
      003B54                        224 00102$:
                                    225 ;	keyboards/ajazz/ak820/ak820_nvm.c:33: storage_failed = true;
                                    226 ;	assignBit
      003B54 D2 09            [12]  227 	setb	_storage_failed
                                    228 ;	keyboards/ajazz/ak820/ak820_nvm.c:34: }
      003B56 22               [24]  229 	ret
                                    230 ;------------------------------------------------------------
                                    231 ;Allocation info for local variables in function 'ak820_nvm_diagnostic'
                                    232 ;------------------------------------------------------------
                                    233 ;out           Allocated with name '_ak820_nvm_diagnostic_out_10000_23'
                                    234 ;------------------------------------------------------------
                                    235 ;	keyboards/ajazz/ak820/ak820_nvm.c:36: void ak820_nvm_diagnostic(uint8_t AK820_XDATA *out) {
                                    236 ;	-----------------------------------------
                                    237 ;	 function ak820_nvm_diagnostic
                                    238 ;	-----------------------------------------
      003B57                        239 _ak820_nvm_diagnostic:
      003B57 12 38 4C         [24]  240 	lcall	_ak820_outline_0106
      003B5A 90 05 5D         [24]  241 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003B5D 12 38 47         [24]  242 	lcall	_ak820_outline_0105
                                    243 ;	keyboards/ajazz/ak820/ak820_nvm.c:37: out[0] = storage_failed;
      003B60 90 05 5D         [24]  244 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003B63 12 37 F7         [24]  245 	lcall	_ak820_outline_0056
      003B66 A2 09            [12]  246 	mov	c,_storage_failed
      003B68 E4               [12]  247 	clr	a
      003B69 33               [12]  248 	rlc	a
      003B6A 12 43 23         [24]  249 	lcall	_ak820_outline_0119
      003B6D 12 42 F8         [24]  250 	lcall	_ak820_outline_0066
                                    251 ;	keyboards/ajazz/ak820/ak820_nvm.c:38: out[1] = page_valid;
      003B70 A3               [24]  252 	inc	dptr
      003B71 A2 07            [12]  253 	mov	c,_page_valid
      003B73 E4               [12]  254 	clr	a
      003B74 33               [12]  255 	rlc	a
      003B75 12 42 CC         [24]  256 	lcall	_ak820_outline_0036
                                    257 ;	keyboards/ajazz/ak820/ak820_nvm.c:39: out[2] = page_dirty;
      003B78 A2 08            [12]  258 	mov	c,_page_dirty
      003B7A E4               [12]  259 	clr	a
      003B7B 33               [12]  260 	rlc	a
      003B7C F0               [24]  261 	movx	@dptr,a
                                    262 ;	keyboards/ajazz/ak820/ak820_nvm.c:40: out[3] = batch_depth;
      003B7D 74 03            [12]  263 	mov	a,#0x03
      003B7F 12 43 47         [24]  264 	lcall	_ak820_outline_0163
      003B82 90 05 5A         [24]  265 	mov	dptr,#_batch_depth
      003B85 E0               [24]  266 	movx	a,@dptr
      003B86 12 38 51         [24]  267 	lcall	_ak820_outline_0123
      003B89 F0               [24]  268 	movx	@dptr,a
                                    269 ;	keyboards/ajazz/ak820/ak820_nvm.c:41: out[4] = (uint8_t)cached_page;
      003B8A 74 04            [12]  270 	mov	a,#0x04
      003B8C 12 43 47         [24]  271 	lcall	_ak820_outline_0163
      003B8F 90 05 59         [24]  272 	mov	dptr,#_cached_page
      003B92 E0               [24]  273 	movx	a,@dptr
      003B93 12 38 51         [24]  274 	lcall	_ak820_outline_0123
      003B96 F0               [24]  275 	movx	@dptr,a
                                    276 ;	keyboards/ajazz/ak820/ak820_nvm.c:42: out[5] = (uint8_t)(cached_page >> 8);
      003B97 12 42 C2         [24]  277 	lcall	_ak820_outline_0013
      003B9A E4               [12]  278 	clr	a
      003B9B F0               [24]  279 	movx	@dptr,a
                                    280 ;	keyboards/ajazz/ak820/ak820_nvm.c:43: out[6] = first_failure_stage;
      003B9C 74 06            [12]  281 	mov	a,#0x06
      003B9E 2E               [12]  282 	add	a, r6
      003B9F FE               [12]  283 	mov	r6,a
      003BA0 E4               [12]  284 	clr	a
      003BA1 3F               [12]  285 	addc	a, r7
      003BA2 FF               [12]  286 	mov	r7,a
      003BA3 90 05 5B         [24]  287 	mov	dptr,#_first_failure_stage
      003BA6 E0               [24]  288 	movx	a,@dptr
      003BA7 12 43 23         [24]  289 	lcall	_ak820_outline_0119
      003BAA F0               [24]  290 	movx	@dptr,a
                                    291 ;	keyboards/ajazz/ak820/ak820_nvm.c:44: }
      003BAB 22               [24]  292 	ret
                                    293 ;------------------------------------------------------------
                                    294 ;Allocation info for local variables in function 'crc_byte'
                                    295 ;------------------------------------------------------------
                                    296 ;value         Allocated with name '_crc_byte_PARM_2'
                                    297 ;crc           Allocated with name '_crc_byte_crc_10000_25'
                                    298 ;bit           Allocated with name '_crc_byte_bit_10000_26'
                                    299 ;------------------------------------------------------------
                                    300 ;	keyboards/ajazz/ak820/ak820_nvm.c:46: static uint16_t crc_byte(uint16_t crc, uint8_t value) {
                                    301 ;	-----------------------------------------
                                    302 ;	 function crc_byte
                                    303 ;	-----------------------------------------
      003BAC                        304 _crc_byte:
      003BAC 12 38 4C         [24]  305 	lcall	_ak820_outline_0106
      003BAF 90 05 60         [24]  306 	mov	dptr,#_crc_byte_crc_10000_25
      003BB2 12 38 47         [24]  307 	lcall	_ak820_outline_0105
                                    308 ;	keyboards/ajazz/ak820/ak820_nvm.c:48: crc ^= (uint16_t)value << 8;
      003BB5 90 05 5F         [24]  309 	mov	dptr,#_crc_byte_PARM_2
      003BB8 E0               [24]  310 	movx	a,@dptr
      003BB9 FF               [12]  311 	mov	r7,a
      003BBA 7E 00            [12]  312 	mov	r6,#0x00
      003BBC 90 05 60         [24]  313 	mov	dptr,#_crc_byte_crc_10000_25
      003BBF E0               [24]  314 	movx	a,@dptr
      003BC0 6E               [12]  315 	xrl	a,r6
      003BC1 F0               [24]  316 	movx	@dptr,a
      003BC2 A3               [24]  317 	inc	dptr
      003BC3 E0               [24]  318 	movx	a,@dptr
      003BC4 6F               [12]  319 	xrl	a,r7
      003BC5 F0               [24]  320 	movx	@dptr,a
                                    321 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003BC6 7F 00            [12]  322 	mov	r7,#0x00
      003BC8                        323 00102$:
                                    324 ;	keyboards/ajazz/ak820/ak820_nvm.c:50: crc = (crc & 0x8000u) ? (uint16_t)((crc << 1) ^ 0x1021u) : (uint16_t)(crc << 1);
      003BC8 90 05 60         [24]  325 	mov	dptr,#_crc_byte_crc_10000_25
      003BCB 12 43 11         [24]  326 	lcall	_ak820_outline_0098
      003BCE 30 E7 0E         [24]  327 	jnb	acc.7,00106$
      003BD1 ED               [12]  328 	mov	a,r5
      003BD2 2D               [12]  329 	add	a,r5
      003BD3 FB               [12]  330 	mov	r3,a
      003BD4 EE               [12]  331 	mov	a,r6
      003BD5 33               [12]  332 	rlc	a
      003BD6 FC               [12]  333 	mov	r4,a
      003BD7 63 03 21         [24]  334 	xrl	ar3,#0x21
      003BDA 63 04 10         [24]  335 	xrl	ar4,#0x10
      003BDD 80 06            [24]  336 	sjmp	00107$
      003BDF                        337 00106$:
      003BDF ED               [12]  338 	mov	a,r5
      003BE0 2D               [12]  339 	add	a,r5
      003BE1 FB               [12]  340 	mov	r3,a
      003BE2 EE               [12]  341 	mov	a,r6
      003BE3 33               [12]  342 	rlc	a
      003BE4 FC               [12]  343 	mov	r4,a
      003BE5                        344 00107$:
      003BE5 90 05 60         [24]  345 	mov	dptr,#_crc_byte_crc_10000_25
      003BE8 12 38 2F         [24]  346 	lcall	_ak820_outline_0081
                                    347 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003BEB 0F               [12]  348 	inc	r7
      003BEC BF 08 D9         [24]  349 	cjne	r7,#0x08,00102$
                                    350 ;	keyboards/ajazz/ak820/ak820_nvm.c:52: return crc;
      003BEF 12 33 FC         [24]  351 	lcall	_ak820_outline_0124
                                    352 ;	keyboards/ajazz/ak820/ak820_nvm.c:53: }
      003BF2 22               [24]  353 	ret
                                    354 ;------------------------------------------------------------
                                    355 ;Allocation info for local variables in function 'page_crc'
                                    356 ;------------------------------------------------------------
                                    357 ;crc           Allocated with name '_page_crc_crc_10000_30'
                                    358 ;i             Allocated with name '_page_crc_i_10000_30'
                                    359 ;------------------------------------------------------------
                                    360 ;	keyboards/ajazz/ak820/ak820_nvm.c:55: static uint16_t page_crc(void) {
                                    361 ;	-----------------------------------------
                                    362 ;	 function page_crc
                                    363 ;	-----------------------------------------
      003BF3                        364 _page_crc:
                                    365 ;	keyboards/ajazz/ak820/ak820_nvm.c:56: uint16_t crc = 0xFFFFu;
      003BF3 90 05 62         [24]  366 	mov	dptr,#_page_crc_crc_10000_30
      003BF6 74 FF            [12]  367 	mov	a,#0xff
      003BF8 F0               [24]  368 	movx	@dptr,a
      003BF9 A3               [24]  369 	inc	dptr
      003BFA F0               [24]  370 	movx	@dptr,a
                                    371 ;	keyboards/ajazz/ak820/ak820_nvm.c:58: for (i = 0; i != AK820_FLASH_PAGE; ++i) crc = crc_byte(crc, page_data[i]);
      003BFB 7F 00            [12]  372 	mov	r7,#0x00
      003BFD                        373 00102$:
      003BFD 90 05 62         [24]  374 	mov	dptr,#_page_crc_crc_10000_30
      003C00 12 43 11         [24]  375 	lcall	_ak820_outline_0098
      003C03 12 43 17         [24]  376 	lcall	_ak820_outline_0108
      003C06 90 05 5F         [24]  377 	mov	dptr,#_crc_byte_PARM_2
      003C09 F0               [24]  378 	movx	@dptr,a
      003C0A 12 38 61         [24]  379 	lcall	_ak820_outline_0137
      003C0D C0 07            [24]  380 	push	ar7
      003C0F 12 3B AC         [24]  381 	lcall	_crc_byte
      003C12 AD 82            [24]  382 	mov	r5, dpl
      003C14 AE 83            [24]  383 	mov	r6, dph
      003C16 D0 07            [24]  384 	pop	ar7
      003C18 90 05 62         [24]  385 	mov	dptr,#_page_crc_crc_10000_30
      003C1B 12 43 4D         [24]  386 	lcall	_ak820_outline_0164
      003C1E 0F               [12]  387 	inc	r7
      003C1F BF 40 DB         [24]  388 	cjne	r7,#0x40,00102$
                                    389 ;	keyboards/ajazz/ak820/ak820_nvm.c:59: return crc;
      003C22 12 38 61         [24]  390 	lcall	_ak820_outline_0137
                                    391 ;	keyboards/ajazz/ak820/ak820_nvm.c:60: }
      003C25 22               [24]  392 	ret
                                    393 ;------------------------------------------------------------
                                    394 ;Allocation info for local variables in function 'write_page'
                                    395 ;------------------------------------------------------------
                                    396 ;address       Allocated with name '_write_page_address_10000_32'
                                    397 ;i             Allocated with name '_write_page_i_10000_33'
                                    398 ;------------------------------------------------------------
                                    399 ;	keyboards/ajazz/ak820/ak820_nvm.c:62: static bool write_page(uint16_t address) {
                                    400 ;	-----------------------------------------
                                    401 ;	 function write_page
                                    402 ;	-----------------------------------------
      003C26                        403 _write_page:
      003C26 12 38 4C         [24]  404 	lcall	_ak820_outline_0106
      003C29 90 05 64         [24]  405 	mov	dptr,#_write_page_address_10000_32
      003C2C 12 38 47         [24]  406 	lcall	_ak820_outline_0105
                                    407 ;	keyboards/ajazz/ak820/ak820_nvm.c:64: if (!ak820_flash_erase(address)) return false;
      003C2F 90 05 64         [24]  408 	mov	dptr,#_write_page_address_10000_32
      003C32 12 37 A8         [24]  409 	lcall	_ak820_outline_0005
      003C35 C0 07            [24]  410 	push	ar7
      003C37 C0 06            [24]  411 	push	ar6
      003C39 12 39 BC         [24]  412 	lcall	_ak820_flash_erase
      003C3C E5 82            [12]  413 	mov	a, dpl
      003C3E D0 06            [24]  414 	pop	ar6
      003C40 D0 07            [24]  415 	pop	ar7
      003C42 70 03            [24]  416 	jnz	00102$
      003C44 F5 82            [12]  417 	mov	dpl,a
      003C46 22               [24]  418 	ret
      003C47                        419 00102$:
                                    420 ;	keyboards/ajazz/ak820/ak820_nvm.c:65: if (!ak820_flash_program_page(address, page_data)) return false;
      003C47 90 04 F5         [24]  421 	mov	dptr,#_ak820_flash_program_page_PARM_2
      003C4A 74 19            [12]  422 	mov	a,#_page_data
      003C4C F0               [24]  423 	movx	@dptr,a
      003C4D 74 05            [12]  424 	mov	a,#(_page_data >> 8)
      003C4F A3               [24]  425 	inc	dptr
      003C50 12 42 F8         [24]  426 	lcall	_ak820_outline_0066
      003C53 12 3A D0         [24]  427 	lcall	_ak820_flash_program_page
      003C56 E5 82            [12]  428 	mov	a, dpl
      003C58 70 03            [24]  429 	jnz	00120$
      003C5A F5 82            [12]  430 	mov	dpl,a
                                    431 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003C5C 22               [24]  432 	ret
      003C5D                        433 00120$:
      003C5D 7F 00            [12]  434 	mov	r7,#0x00
      003C5F                        435 00108$:
                                    436 ;	keyboards/ajazz/ak820/ak820_nvm.c:67: if (ak820_flash_read(address + i) != page_data[i]) return false;
      003C5F 8F 05            [24]  437 	mov	ar5,r7
      003C61 7E 00            [12]  438 	mov	r6,#0x00
      003C63 90 05 64         [24]  439 	mov	dptr,#_write_page_address_10000_32
      003C66 12 38 41         [24]  440 	lcall	_ak820_outline_0103
      003C69 ED               [12]  441 	mov	a,r5
      003C6A 2B               [12]  442 	add	a, r3
      003C6B FB               [12]  443 	mov	r3,a
      003C6C EE               [12]  444 	mov	a,r6
      003C6D 3C               [12]  445 	addc	a, r4
      003C6E FC               [12]  446 	mov	r4,a
      003C6F 12 33 FC         [24]  447 	lcall	_ak820_outline_0124
      003C72 12 38 AF         [24]  448 	lcall	_ak820_flash_read
      003C75 AE 82            [24]  449 	mov	r6, dpl
      003C77 12 43 17         [24]  450 	lcall	_ak820_outline_0108
      003C7A FD               [12]  451 	mov	r5,a
      003C7B EE               [12]  452 	mov	a,r6
      003C7C B5 05 02         [24]  453 	cjne	a,ar5,00149$
      003C7F 80 04            [24]  454 	sjmp	00109$
      003C81                        455 00149$:
      003C81 75 82 00         [24]  456 	mov	dpl, #0x00
      003C84 22               [24]  457 	ret
      003C85                        458 00109$:
                                    459 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003C85 0F               [12]  460 	inc	r7
      003C86 BF 40 D6         [24]  461 	cjne	r7,#0x40,00108$
                                    462 ;	keyboards/ajazz/ak820/ak820_nvm.c:69: return true;
      003C89 75 82 01         [24]  463 	mov	dpl, #0x01
                                    464 ;	keyboards/ajazz/ak820/ak820_nvm.c:70: }
      003C8C 22               [24]  465 	ret
                                    466 ;------------------------------------------------------------
                                    467 ;Allocation info for local variables in function 'journal_header_valid'
                                    468 ;------------------------------------------------------------
                                    469 ;header        Allocated with name '_journal_header_valid_header_10000_39'
                                    470 ;i             Allocated with name '_journal_header_valid_i_10000_40'
                                    471 ;------------------------------------------------------------
                                    472 ;	keyboards/ajazz/ak820/ak820_nvm.c:72: static bool journal_header_valid(uint8_t AK820_XDATA *header) {
                                    473 ;	-----------------------------------------
                                    474 ;	 function journal_header_valid
                                    475 ;	-----------------------------------------
      003C8D                        476 _journal_header_valid:
      003C8D 12 38 4C         [24]  477 	lcall	_ak820_outline_0106
      003C90 90 05 66         [24]  478 	mov	dptr,#_journal_header_valid_header_10000_39
      003C93 12 38 47         [24]  479 	lcall	_ak820_outline_0105
                                    480 ;	keyboards/ajazz/ak820/ak820_nvm.c:74: if (header[0] != 0xA5u) return false;
      003C96 90 05 66         [24]  481 	mov	dptr,#_journal_header_valid_header_10000_39
      003C99 12 37 A8         [24]  482 	lcall	_ak820_outline_0005
      003C9C E0               [24]  483 	movx	a,@dptr
      003C9D FD               [12]  484 	mov	r5,a
      003C9E BD A5 02         [24]  485 	cjne	r5,#0xa5,00138$
      003CA1 80 04            [24]  486 	sjmp	00116$
      003CA3                        487 00138$:
      003CA3 75 82 00         [24]  488 	mov	dpl, #0x00
                                    489 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      003CA6 22               [24]  490 	ret
      003CA7                        491 00116$:
      003CA7 7D 01            [12]  492 	mov	r5,#0x01
      003CA9                        493 00106$:
                                    494 ;	keyboards/ajazz/ak820/ak820_nvm.c:76: if ((uint8_t)(header[i] ^ header[i + 4]) != 0xFFu) return false;
      003CA9 ED               [12]  495 	mov	a,r5
      003CAA 12 37 D6         [24]  496 	lcall	_ak820_outline_0017
      003CAD FC               [12]  497 	mov	r4,a
      003CAE 8D 02            [24]  498 	mov	ar2,r5
      003CB0 7B 00            [12]  499 	mov	r3,#0x00
      003CB2 74 04            [12]  500 	mov	a,#0x04
      003CB4 2A               [12]  501 	add	a, r2
      003CB5 FA               [12]  502 	mov	r2,a
      003CB6 E4               [12]  503 	clr	a
      003CB7 3B               [12]  504 	addc	a, r3
      003CB8 FB               [12]  505 	mov	r3,a
      003CB9 EA               [12]  506 	mov	a,r2
      003CBA 2E               [12]  507 	add	a, r6
      003CBB F5 82            [12]  508 	mov	dpl,a
      003CBD EB               [12]  509 	mov	a,r3
      003CBE 3F               [12]  510 	addc	a, r7
      003CBF F5 83            [12]  511 	mov	dph,a
      003CC1 E0               [24]  512 	movx	a,@dptr
      003CC2 62 04            [12]  513 	xrl	ar4,a
      003CC4 BC FF 02         [24]  514 	cjne	r4,#0xff,00139$
      003CC7 80 04            [24]  515 	sjmp	00107$
      003CC9                        516 00139$:
      003CC9 75 82 00         [24]  517 	mov	dpl, #0x00
      003CCC 22               [24]  518 	ret
      003CCD                        519 00107$:
                                    520 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      003CCD 0D               [12]  521 	inc	r5
      003CCE BD 05 D8         [24]  522 	cjne	r5,#0x05,00106$
                                    523 ;	keyboards/ajazz/ak820/ak820_nvm.c:78: return true;
      003CD1 75 82 01         [24]  524 	mov	dpl, #0x01
                                    525 ;	keyboards/ajazz/ak820/ak820_nvm.c:79: }
      003CD4 22               [24]  526 	ret
                                    527 ;------------------------------------------------------------
                                    528 ;Allocation info for local variables in function 'recover_journal'
                                    529 ;------------------------------------------------------------
                                    530 ;header        Allocated with name '_recover_journal_header_10000_46'
                                    531 ;i             Allocated with name '_recover_journal_i_10000_46'
                                    532 ;page          Allocated with name '_recover_journal_page_10000_46'
                                    533 ;crc           Allocated with name '_recover_journal_crc_10000_46'
                                    534 ;------------------------------------------------------------
                                    535 ;	keyboards/ajazz/ak820/ak820_nvm.c:81: static void recover_journal(void) {
                                    536 ;	-----------------------------------------
                                    537 ;	 function recover_journal
                                    538 ;	-----------------------------------------
      003CD5                        539 _recover_journal:
                                    540 ;	keyboards/ajazz/ak820/ak820_nvm.c:85: for (i = 0; i != sizeof(header); ++i) header[i] = ak820_flash_read(AK820_JOURNAL_HEADER + i);
      003CD5 7F 00            [12]  541 	mov	r7,#0x00
      003CD7                        542 00115$:
      003CD7 EF               [12]  543 	mov	a,r7
      003CD8 24 68            [12]  544 	add	a, #_recover_journal_header_10000_46
      003CDA FD               [12]  545 	mov	r5,a
      003CDB E4               [12]  546 	clr	a
      003CDC 34 05            [12]  547 	addc	a, #(_recover_journal_header_10000_46 >> 8)
      003CDE FE               [12]  548 	mov	r6,a
      003CDF 8F 04            [24]  549 	mov	ar4,r7
      003CE1 7B 00            [12]  550 	mov	r3,#0x00
      003CE3 74 40            [12]  551 	mov	a,#0x40
      003CE5 2C               [12]  552 	add	a, r4
      003CE6 FC               [12]  553 	mov	r4,a
      003CE7 74 EF            [12]  554 	mov	a,#0xef
      003CE9 3B               [12]  555 	addc	a, r3
      003CEA FB               [12]  556 	mov	r3,a
      003CEB 12 43 53         [24]  557 	lcall	_ak820_outline_0184
      003CEE 12 38 AF         [24]  558 	lcall	_ak820_flash_read
      003CF1 AC 82            [24]  559 	mov	r4, dpl
      003CF3 12 42 FE         [24]  560 	lcall	_ak820_outline_0069
      003CF6 0F               [12]  561 	inc	r7
      003CF7 BF 09 DD         [24]  562 	cjne	r7,#0x09,00115$
                                    563 ;	keyboards/ajazz/ak820/ak820_nvm.c:88: if (!journal_header_valid(header)) return;
      003CFA 90 05 68         [24]  564 	mov	dptr,#_recover_journal_header_10000_46
      003CFD 12 3C 8D         [24]  565 	lcall	_journal_header_valid
      003D00 E5 82            [12]  566 	mov	a, dpl
      003D02 70 01            [24]  567 	jnz	00103$
      003D04 22               [24]  568 	ret
      003D05                        569 00103$:
                                    570 ;	keyboards/ajazz/ak820/ak820_nvm.c:89: page = (uint16_t)header[1] | ((uint16_t)header[2] << 8);
      003D05 90 05 69         [24]  571 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0001)
      003D08 E0               [24]  572 	movx	a,@dptr
      003D09 FF               [12]  573 	mov	r7,a
      003D0A 7E 00            [12]  574 	mov	r6,#0x00
      003D0C 90 05 6A         [24]  575 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0002)
      003D0F E0               [24]  576 	movx	a,@dptr
      003D10 FC               [12]  577 	mov	r4,a
      003D11 E4               [12]  578 	clr	a
      003D12 42 07            [12]  579 	orl	ar7,a
      003D14 EC               [12]  580 	mov	a,r4
      003D15 42 06            [12]  581 	orl	ar6,a
                                    582 ;	keyboards/ajazz/ak820/ak820_nvm.c:90: crc = (uint16_t)header[3] | ((uint16_t)header[4] << 8);
      003D17 90 05 6B         [24]  583 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0003)
      003D1A E0               [24]  584 	movx	a,@dptr
      003D1B FD               [12]  585 	mov	r5,a
      003D1C 7C 00            [12]  586 	mov	r4,#0x00
      003D1E 90 05 6C         [24]  587 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0004)
      003D21 E0               [24]  588 	movx	a,@dptr
      003D22 FA               [12]  589 	mov	r2,a
      003D23 E4               [12]  590 	clr	a
      003D24 12 43 32         [24]  591 	lcall	_ak820_outline_0142
                                    592 ;	keyboards/ajazz/ak820/ak820_nvm.c:91: if (page >= AK820_NVM_SIZE / AK820_FLASH_PAGE) {
      003D27 C3               [12]  593 	clr	c
      003D28 EF               [12]  594 	mov	a,r7
      003D29 94 A0            [12]  595 	subb	a,#0xa0
      003D2B EE               [12]  596 	mov	a,r6
      003D2C 94 00            [12]  597 	subb	a,#0x00
      003D2E 40 06            [24]  598 	jc	00134$
                                    599 ;	keyboards/ajazz/ak820/ak820_nvm.c:92: nvm_fail(AK820_NVM_FAULT_RECOVERY_PAGE);
      003D30 75 82 01         [24]  600 	mov	dpl, #0x01
                                    601 ;	keyboards/ajazz/ak820/ak820_nvm.c:93: return;
      003D33 02 3B 43         [24]  602 	ljmp	_nvm_fail
                                    603 ;	keyboards/ajazz/ak820/ak820_nvm.c:95: for (i = 0; i != AK820_FLASH_PAGE; ++i) page_data[i] = ak820_flash_read(AK820_JOURNAL_DATA + i);
      003D36                        604 00134$:
      003D36 7B 00            [12]  605 	mov	r3,#0x00
      003D38                        606 00117$:
      003D38 C0 05            [24]  607 	push	ar5
      003D3A C0 04            [24]  608 	push	ar4
      003D3C EB               [12]  609 	mov	a,r3
      003D3D 24 19            [12]  610 	add	a, #_page_data
      003D3F F9               [12]  611 	mov	r1,a
      003D40 E4               [12]  612 	clr	a
      003D41 34 05            [12]  613 	addc	a, #(_page_data >> 8)
      003D43 FA               [12]  614 	mov	r2,a
      003D44 8B 00            [24]  615 	mov	ar0,r3
      003D46 7D 00            [12]  616 	mov	r5,#0x00
      003D48 74 EF            [12]  617 	mov	a,#0xef
      003D4A 2D               [12]  618 	add	a, r5
      003D4B FD               [12]  619 	mov	r5,a
      003D4C 88 82            [24]  620 	mov	dpl, r0
      003D4E 8D 83            [24]  621 	mov	dph, r5
      003D50 12 38 AF         [24]  622 	lcall	_ak820_flash_read
      003D53 AD 82            [24]  623 	mov	r5, dpl
      003D55 12 43 38         [24]  624 	lcall	_ak820_outline_0150
      003D58 ED               [12]  625 	mov	a,r5
      003D59 F0               [24]  626 	movx	@dptr,a
      003D5A 0B               [12]  627 	inc	r3
      003D5B BB 40 02         [24]  628 	cjne	r3,#0x40,00190$
      003D5E 80 06            [24]  629 	sjmp	00191$
      003D60                        630 00190$:
      003D60 D0 04            [24]  631 	pop	ar4
      003D62 D0 05            [24]  632 	pop	ar5
      003D64 80 D2            [24]  633 	sjmp	00117$
      003D66                        634 00191$:
      003D66 D0 04            [24]  635 	pop	ar4
      003D68 D0 05            [24]  636 	pop	ar5
                                    637 ;	keyboards/ajazz/ak820/ak820_nvm.c:96: if (page_crc() != crc) nvm_fail(AK820_NVM_FAULT_RECOVERY_CRC);
      003D6A C0 07            [24]  638 	push	ar7
      003D6C C0 06            [24]  639 	push	ar6
      003D6E C0 05            [24]  640 	push	ar5
      003D70 C0 04            [24]  641 	push	ar4
      003D72 12 3B F3         [24]  642 	lcall	_page_crc
      003D75 AA 82            [24]  643 	mov	r2, dpl
      003D77 AB 83            [24]  644 	mov	r3, dph
      003D79 D0 04            [24]  645 	pop	ar4
      003D7B D0 05            [24]  646 	pop	ar5
      003D7D D0 06            [24]  647 	pop	ar6
      003D7F D0 07            [24]  648 	pop	ar7
      003D81 EA               [12]  649 	mov	a,r2
      003D82 B5 05 06         [24]  650 	cjne	a,ar5,00192$
      003D85 EB               [12]  651 	mov	a,r3
      003D86 B5 04 02         [24]  652 	cjne	a,ar4,00192$
      003D89 80 06            [24]  653 	sjmp	00113$
      003D8B                        654 00192$:
      003D8B 75 82 02         [24]  655 	mov	dpl, #0x02
      003D8E 02 3B 43         [24]  656 	ljmp	_nvm_fail
      003D91                        657 00113$:
                                    658 ;	keyboards/ajazz/ak820/ak820_nvm.c:97: else if (!write_page(AK820_NVM_BASE + page * AK820_FLASH_PAGE)) nvm_fail(AK820_NVM_FAULT_RECOVERY_WRITE);
      003D91 EE               [12]  659 	mov	a,r6
      003D92 54 03            [12]  660 	anl	a,#0x03
      003D94 A2 E0            [12]  661 	mov	c,acc.0
      003D96 CF               [12]  662 	xch	a,r7
      003D97 13               [12]  663 	rrc	a
      003D98 CF               [12]  664 	xch	a,r7
      003D99 13               [12]  665 	rrc	a
      003D9A A2 E0            [12]  666 	mov	c,acc.0
      003D9C CF               [12]  667 	xch	a,r7
      003D9D 13               [12]  668 	rrc	a
      003D9E CF               [12]  669 	xch	a,r7
      003D9F 13               [12]  670 	rrc	a
      003DA0 CF               [12]  671 	xch	a,r7
      003DA1 24 C7            [12]  672 	add	a,#0xc7
      003DA3 FE               [12]  673 	mov	r6,a
      003DA4 12 43 42         [24]  674 	lcall	_ak820_outline_0159
      003DA7 12 3C 26         [24]  675 	lcall	_write_page
      003DAA E5 82            [12]  676 	mov	a, dpl
      003DAC 70 06            [24]  677 	jnz	00110$
      003DAE 75 82 03         [24]  678 	mov	dpl, #0x03
      003DB1 02 3B 43         [24]  679 	ljmp	_nvm_fail
      003DB4                        680 00110$:
                                    681 ;	keyboards/ajazz/ak820/ak820_nvm.c:98: else if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) nvm_fail(AK820_NVM_FAULT_RECOVERY_CLEANUP);
      003DB4 90 EF 40         [24]  682 	mov	dptr,#0xef40
      003DB7 12 39 BC         [24]  683 	lcall	_ak820_flash_erase
      003DBA E5 82            [12]  684 	mov	a, dpl
      003DBC 70 06            [24]  685 	jnz	00119$
      003DBE 75 82 04         [24]  686 	mov	dpl, #0x04
                                    687 ;	keyboards/ajazz/ak820/ak820_nvm.c:99: }
      003DC1 02 3B 43         [24]  688 	ljmp	_nvm_fail
      003DC4                        689 00119$:
      003DC4 22               [24]  690 	ret
                                    691 ;------------------------------------------------------------
                                    692 ;Allocation info for local variables in function 'eeprom_driver_init'
                                    693 ;------------------------------------------------------------
                                    694 ;	keyboards/ajazz/ak820/ak820_nvm.c:101: void eeprom_driver_init(void) {
                                    695 ;	-----------------------------------------
                                    696 ;	 function eeprom_driver_init
                                    697 ;	-----------------------------------------
      003DC5                        698 _eeprom_driver_init:
                                    699 ;	keyboards/ajazz/ak820/ak820_nvm.c:102: storage_failed = false;
                                    700 ;	assignBit
      003DC5 C2 09            [12]  701 	clr	_storage_failed
                                    702 ;	keyboards/ajazz/ak820/ak820_nvm.c:103: first_failure_stage = AK820_NVM_FAULT_NONE;
      003DC7 90 05 5B         [24]  703 	mov	dptr,#_first_failure_stage
      003DCA E4               [12]  704 	clr	a
      003DCB F0               [24]  705 	movx	@dptr,a
                                    706 ;	keyboards/ajazz/ak820/ak820_nvm.c:104: page_valid = page_dirty = false;
                                    707 ;	assignBit
      003DCC C2 08            [12]  708 	clr	_page_dirty
                                    709 ;	assignBit
      003DCE C2 07            [12]  710 	clr	_page_valid
                                    711 ;	keyboards/ajazz/ak820/ak820_nvm.c:105: batch_depth = 0;
      003DD0 90 05 5A         [24]  712 	mov	dptr,#_batch_depth
      003DD3 E4               [12]  713 	clr	a
      003DD4 F0               [24]  714 	movx	@dptr,a
                                    715 ;	keyboards/ajazz/ak820/ak820_nvm.c:106: recover_journal();
      003DD5 12 3C D5         [24]  716 	lcall	_recover_journal
                                    717 ;	keyboards/ajazz/ak820/ak820_nvm.c:108: ak820_macro_init();
                                    718 ;	keyboards/ajazz/ak820/ak820_nvm.c:110: }
      003DD8 02 2A B7         [24]  719 	ljmp	_ak820_macro_init
                                    720 ;------------------------------------------------------------
                                    721 ;Allocation info for local variables in function 'ak820_nvm_ok'
                                    722 ;------------------------------------------------------------
                                    723 ;	keyboards/ajazz/ak820/ak820_nvm.c:112: bool ak820_nvm_ok(void) { return !storage_failed; }
                                    724 ;	-----------------------------------------
                                    725 ;	 function ak820_nvm_ok
                                    726 ;	-----------------------------------------
      003DDB                        727 _ak820_nvm_ok:
      003DDB A2 09            [12]  728 	mov	c,_storage_failed
      003DDD B3               [12]  729 	cpl	c
      003DDE 92 0A            [24]  730 	mov  _ak820_nvm_ok_sloc0_1_0,c
      003DE0 12 38 66         [24]  731 	lcall	_ak820_outline_0149
      003DE3 22               [24]  732 	ret
                                    733 ;------------------------------------------------------------
                                    734 ;Allocation info for local variables in function 'ak820_nvm_schema_fault'
                                    735 ;------------------------------------------------------------
                                    736 ;	keyboards/ajazz/ak820/ak820_nvm.c:114: void ak820_nvm_schema_fault(void) { nvm_fail(AK820_NVM_FAULT_SCHEMA); }
                                    737 ;	-----------------------------------------
                                    738 ;	 function ak820_nvm_schema_fault
                                    739 ;	-----------------------------------------
      003DE4                        740 _ak820_nvm_schema_fault:
      003DE4 75 82 10         [24]  741 	mov	dpl, #0x10
      003DE7 02 3B 43         [24]  742 	ljmp	_nvm_fail
                                    743 ;------------------------------------------------------------
                                    744 ;Allocation info for local variables in function 'ak820_nvm_flush'
                                    745 ;------------------------------------------------------------
                                    746 ;header        Allocated with name '_ak820_nvm_flush_header_10000_62'
                                    747 ;crc           Allocated with name '_ak820_nvm_flush_crc_10000_62'
                                    748 ;i             Allocated with name '_ak820_nvm_flush_i_10000_62'
                                    749 ;stage         Allocated with name '_ak820_nvm_flush_stage_10000_62'
                                    750 ;------------------------------------------------------------
                                    751 ;	keyboards/ajazz/ak820/ak820_nvm.c:116: void ak820_nvm_flush(void) {
                                    752 ;	-----------------------------------------
                                    753 ;	 function ak820_nvm_flush
                                    754 ;	-----------------------------------------
      003DEA                        755 _ak820_nvm_flush:
                                    756 ;	keyboards/ajazz/ak820/ak820_nvm.c:121: if (!page_dirty || storage_failed) return;
      003DEA 30 08 03         [24]  757 	jnb	_page_dirty,00101$
      003DED 30 09 01         [24]  758 	jnb	_storage_failed,00102$
      003DF0                        759 00101$:
      003DF0 22               [24]  760 	ret
      003DF1                        761 00102$:
                                    762 ;	keyboards/ajazz/ak820/ak820_nvm.c:122: crc = page_crc();
      003DF1 12 3B F3         [24]  763 	lcall	_page_crc
      003DF4 12 43 2D         [24]  764 	lcall	_ak820_outline_0136
                                    765 ;	keyboards/ajazz/ak820/ak820_nvm.c:123: header[0] = 0xA5u;
      003DF7 90 05 71         [24]  766 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003DFA 74 A5            [12]  767 	mov	a,#0xa5
      003DFC F0               [24]  768 	movx	@dptr,a
                                    769 ;	keyboards/ajazz/ak820/ak820_nvm.c:124: header[1] = (uint8_t)cached_page;
      003DFD 90 05 59         [24]  770 	mov	dptr,#_cached_page
      003E00 E0               [24]  771 	movx	a,@dptr
      003E01 90 05 72         [24]  772 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0001)
      003E04 F0               [24]  773 	movx	@dptr,a
                                    774 ;	keyboards/ajazz/ak820/ak820_nvm.c:125: header[2] = (uint8_t)(cached_page >> 8);
      003E05 90 05 73         [24]  775 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0002)
      003E08 E4               [12]  776 	clr	a
      003E09 F0               [24]  777 	movx	@dptr,a
                                    778 ;	keyboards/ajazz/ak820/ak820_nvm.c:126: header[3] = (uint8_t)crc;
      003E0A 8E 05            [24]  779 	mov	ar5,r6
      003E0C 90 05 74         [24]  780 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0003)
      003E0F ED               [12]  781 	mov	a,r5
      003E10 F0               [24]  782 	movx	@dptr,a
                                    783 ;	keyboards/ajazz/ak820/ak820_nvm.c:127: header[4] = (uint8_t)(crc >> 8);
      003E11 8F 06            [24]  784 	mov	ar6,r7
      003E13 90 05 75         [24]  785 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0004)
      003E16 EE               [12]  786 	mov	a,r6
      003E17 F0               [24]  787 	movx	@dptr,a
                                    788 ;	keyboards/ajazz/ak820/ak820_nvm.c:128: for (i = 1; i != 5; ++i) header[i + 4] = (uint8_t)~header[i];
      003E18 7F 01            [12]  789 	mov	r7,#0x01
      003E1A                        790 00128$:
      003E1A 8F 06            [24]  791 	mov	ar6,r7
      003E1C EE               [12]  792 	mov	a,r6
      003E1D 24 04            [12]  793 	add	a,#0x04
      003E1F FE               [12]  794 	mov	r6,a
      003E20 33               [12]  795 	rlc	a
      003E21 95 E0            [12]  796 	subb	a,acc
      003E23 FD               [12]  797 	mov	r5,a
      003E24 EE               [12]  798 	mov	a,r6
      003E25 24 71            [12]  799 	add	a, #_ak820_nvm_flush_header_10000_62
      003E27 FE               [12]  800 	mov	r6,a
      003E28 ED               [12]  801 	mov	a,r5
      003E29 34 05            [12]  802 	addc	a, #(_ak820_nvm_flush_header_10000_62 >> 8)
      003E2B FD               [12]  803 	mov	r5,a
      003E2C 12 42 DB         [24]  804 	lcall	_ak820_outline_0045
      003E2F FC               [12]  805 	mov	r4,a
      003E30 63 04 FF         [24]  806 	xrl	ar4,#0xff
      003E33 8E 82            [24]  807 	mov	dpl,r6
      003E35 8D 83            [24]  808 	mov	dph,r5
      003E37 EC               [12]  809 	mov	a,r4
      003E38 F0               [24]  810 	movx	@dptr,a
      003E39 0F               [12]  811 	inc	r7
      003E3A BF 05 DD         [24]  812 	cjne	r7,#0x05,00128$
                                    813 ;	keyboards/ajazz/ak820/ak820_nvm.c:131: stage = AK820_NVM_FAULT_HEADER_ERASE;
      003E3D 90 05 7A         [24]  814 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003E40 74 05            [12]  815 	mov	a,#0x05
      003E42 F0               [24]  816 	movx	@dptr,a
                                    817 ;	keyboards/ajazz/ak820/ak820_nvm.c:132: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      003E43 90 EF 40         [24]  818 	mov	dptr,#0xef40
      003E46 12 39 BC         [24]  819 	lcall	_ak820_flash_erase
      003E49 E5 82            [12]  820 	mov	a, dpl
      003E4B 70 03            [24]  821 	jnz	00269$
      003E4D 02 3F 34         [24]  822 	ljmp	00127$
      003E50                        823 00269$:
                                    824 ;	keyboards/ajazz/ak820/ak820_nvm.c:133: stage = AK820_NVM_FAULT_HEADER_ZERO;
      003E50 90 05 7A         [24]  825 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003E53 74 06            [12]  826 	mov	a,#0x06
      003E55 F0               [24]  827 	movx	@dptr,a
                                    828 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003E56 7F 00            [12]  829 	mov	r7,#0x00
      003E58                        830 00130$:
                                    831 ;	keyboards/ajazz/ak820/ak820_nvm.c:135: if (ak820_flash_read(AK820_JOURNAL_HEADER + i)) goto failed;
      003E58 12 42 E7         [24]  832 	lcall	_ak820_outline_0057
      003E5B 12 38 AF         [24]  833 	lcall	_ak820_flash_read
      003E5E E5 82            [12]  834 	mov	a, dpl
      003E60 60 03            [24]  835 	jz	00270$
      003E62 02 3F 34         [24]  836 	ljmp	00127$
      003E65                        837 00270$:
                                    838 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003E65 0F               [12]  839 	inc	r7
      003E66 BF 40 EF         [24]  840 	cjne	r7,#0x40,00130$
                                    841 ;	keyboards/ajazz/ak820/ak820_nvm.c:137: stage = AK820_NVM_FAULT_JOURNAL_WRITE;
      003E69 90 05 7A         [24]  842 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003E6C 74 07            [12]  843 	mov	a,#0x07
      003E6E F0               [24]  844 	movx	@dptr,a
                                    845 ;	keyboards/ajazz/ak820/ak820_nvm.c:138: if (!write_page(AK820_JOURNAL_DATA)) goto failed;
      003E6F 90 EF 00         [24]  846 	mov	dptr,#0xef00
      003E72 12 3C 26         [24]  847 	lcall	_write_page
      003E75 E5 82            [12]  848 	mov	a, dpl
      003E77 70 03            [24]  849 	jnz	00273$
      003E79 02 3F 34         [24]  850 	ljmp	00127$
      003E7C                        851 00273$:
                                    852 ;	keyboards/ajazz/ak820/ak820_nvm.c:139: stage = AK820_NVM_FAULT_METADATA_PROGRAM;
      003E7C 90 05 7A         [24]  853 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003E7F 74 08            [12]  854 	mov	a,#0x08
      003E81 F0               [24]  855 	movx	@dptr,a
                                    856 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      003E82 7F 01            [12]  857 	mov	r7,#0x01
      003E84                        858 00132$:
                                    859 ;	keyboards/ajazz/ak820/ak820_nvm.c:141: if (header[i] && !ak820_flash_program(AK820_JOURNAL_HEADER + i, header[i])) goto failed;
      003E84 12 42 DB         [24]  860 	lcall	_ak820_outline_0045
      003E87 FE               [12]  861 	mov	r6,a
      003E88 60 23            [24]  862 	jz	00133$
      003E8A 8F 05            [24]  863 	mov	ar5,r7
      003E8C 7C 00            [12]  864 	mov	r4,#0x00
      003E8E 74 40            [12]  865 	mov	a,#0x40
      003E90 2D               [12]  866 	add	a, r5
      003E91 FD               [12]  867 	mov	r5,a
      003E92 74 EF            [12]  868 	mov	a,#0xef
      003E94 3C               [12]  869 	addc	a, r4
      003E95 FC               [12]  870 	mov	r4,a
      003E96 90 04 F2         [24]  871 	mov	dptr,#_ak820_flash_program_PARM_2
      003E99 EE               [12]  872 	mov	a,r6
      003E9A F0               [24]  873 	movx	@dptr,a
      003E9B 8D 82            [24]  874 	mov	dpl, r5
      003E9D 8C 83            [24]  875 	mov	dph, r4
      003E9F C0 07            [24]  876 	push	ar7
      003EA1 12 3A 1C         [24]  877 	lcall	_ak820_flash_program
      003EA4 E5 82            [12]  878 	mov	a, dpl
      003EA6 D0 07            [24]  879 	pop	ar7
      003EA8 70 03            [24]  880 	jnz	00275$
      003EAA 02 3F 34         [24]  881 	ljmp	00127$
      003EAD                        882 00275$:
      003EAD                        883 00133$:
                                    884 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      003EAD 0F               [12]  885 	inc	r7
      003EAE BF 09 D3         [24]  886 	cjne	r7,#0x09,00132$
                                    887 ;	keyboards/ajazz/ak820/ak820_nvm.c:143: stage = AK820_NVM_FAULT_METADATA_READBACK;
      003EB1 90 05 7A         [24]  888 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003EB4 74 09            [12]  889 	mov	a,#0x09
      003EB6 F0               [24]  890 	movx	@dptr,a
                                    891 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      003EB7 7F 01            [12]  892 	mov	r7,#0x01
      003EB9                        893 00134$:
                                    894 ;	keyboards/ajazz/ak820/ak820_nvm.c:145: if (ak820_flash_read(AK820_JOURNAL_HEADER + i) != header[i]) goto failed;
      003EB9 12 42 E7         [24]  895 	lcall	_ak820_outline_0057
      003EBC 12 38 AF         [24]  896 	lcall	_ak820_flash_read
      003EBF AE 82            [24]  897 	mov	r6, dpl
      003EC1 12 42 DB         [24]  898 	lcall	_ak820_outline_0045
      003EC4 FD               [12]  899 	mov	r5,a
      003EC5 EE               [12]  900 	mov	a,r6
      003EC6 B5 05 6B         [24]  901 	cjne	a,ar5,00127$
                                    902 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      003EC9 0F               [12]  903 	inc	r7
      003ECA BF 09 EC         [24]  904 	cjne	r7,#0x09,00134$
                                    905 ;	keyboards/ajazz/ak820/ak820_nvm.c:148: stage = AK820_NVM_FAULT_COMMIT_PROGRAM;
      003ECD 90 05 7A         [24]  906 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003ED0 74 0A            [12]  907 	mov	a,#0x0a
      003ED2 F0               [24]  908 	movx	@dptr,a
                                    909 ;	keyboards/ajazz/ak820/ak820_nvm.c:149: if (!ak820_flash_program(AK820_JOURNAL_HEADER, header[0])) goto failed;
      003ED3 90 05 71         [24]  910 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003ED6 E0               [24]  911 	movx	a,@dptr
      003ED7 90 04 F2         [24]  912 	mov	dptr,#_ak820_flash_program_PARM_2
      003EDA F0               [24]  913 	movx	@dptr,a
      003EDB 90 EF 40         [24]  914 	mov	dptr,#0xef40
      003EDE 12 3A 1C         [24]  915 	lcall	_ak820_flash_program
      003EE1 E5 82            [12]  916 	mov	a, dpl
      003EE3 60 4F            [24]  917 	jz	00127$
                                    918 ;	keyboards/ajazz/ak820/ak820_nvm.c:150: stage = AK820_NVM_FAULT_COMMIT_READBACK;
      003EE5 90 05 7A         [24]  919 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003EE8 74 0B            [12]  920 	mov	a,#0x0b
      003EEA F0               [24]  921 	movx	@dptr,a
                                    922 ;	keyboards/ajazz/ak820/ak820_nvm.c:151: if (ak820_flash_read(AK820_JOURNAL_HEADER) != header[0]) goto failed;
      003EEB 90 EF 40         [24]  923 	mov	dptr,#0xef40
      003EEE 12 38 AF         [24]  924 	lcall	_ak820_flash_read
      003EF1 AF 82            [24]  925 	mov	r7, dpl
      003EF3 90 05 71         [24]  926 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003EF6 E0               [24]  927 	movx	a,@dptr
      003EF7 FE               [12]  928 	mov	r6,a
      003EF8 EF               [12]  929 	mov	a,r7
      003EF9 B5 06 38         [24]  930 	cjne	a,ar6,00127$
                                    931 ;	keyboards/ajazz/ak820/ak820_nvm.c:152: stage = AK820_NVM_FAULT_TARGET_WRITE;
      003EFC 90 05 7A         [24]  932 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003EFF 74 0C            [12]  933 	mov	a,#0x0c
      003F01 F0               [24]  934 	movx	@dptr,a
                                    935 ;	keyboards/ajazz/ak820/ak820_nvm.c:153: if (!write_page(AK820_NVM_BASE + cached_page * AK820_FLASH_PAGE)) goto failed;
      003F02 90 05 59         [24]  936 	mov	dptr,#_cached_page
      003F05 E0               [24]  937 	movx	a,@dptr
      003F06 FE               [12]  938 	mov	r6,a
      003F07 E4               [12]  939 	clr	a
      003F08 C3               [12]  940 	clr	c
      003F09 CE               [12]  941 	xch	a,r6
      003F0A 13               [12]  942 	rrc	a
      003F0B CE               [12]  943 	xch	a,r6
      003F0C 13               [12]  944 	rrc	a
      003F0D A2 E0            [12]  945 	mov	c,acc.0
      003F0F CE               [12]  946 	xch	a,r6
      003F10 13               [12]  947 	rrc	a
      003F11 CE               [12]  948 	xch	a,r6
      003F12 13               [12]  949 	rrc	a
      003F13 CE               [12]  950 	xch	a,r6
      003F14 24 C7            [12]  951 	add	a,#0xc7
      003F16 FF               [12]  952 	mov	r7,a
      003F17 12 43 23         [24]  953 	lcall	_ak820_outline_0119
      003F1A 12 3C 26         [24]  954 	lcall	_write_page
      003F1D E5 82            [12]  955 	mov	a, dpl
      003F1F 60 13            [24]  956 	jz	00127$
                                    957 ;	keyboards/ajazz/ak820/ak820_nvm.c:154: stage = AK820_NVM_FAULT_CLEANUP;
      003F21 90 05 7A         [24]  958 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F24 74 0D            [12]  959 	mov	a,#0x0d
      003F26 F0               [24]  960 	movx	@dptr,a
                                    961 ;	keyboards/ajazz/ak820/ak820_nvm.c:155: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      003F27 90 EF 40         [24]  962 	mov	dptr,#0xef40
      003F2A 12 39 BC         [24]  963 	lcall	_ak820_flash_erase
      003F2D E5 82            [12]  964 	mov	a, dpl
      003F2F 60 03            [24]  965 	jz	00127$
                                    966 ;	keyboards/ajazz/ak820/ak820_nvm.c:156: page_dirty = false;
                                    967 ;	assignBit
      003F31 C2 08            [12]  968 	clr	_page_dirty
                                    969 ;	keyboards/ajazz/ak820/ak820_nvm.c:157: return;
                                    970 ;	keyboards/ajazz/ak820/ak820_nvm.c:158: failed:
      003F33 22               [24]  971 	ret
      003F34                        972 00127$:
                                    973 ;	keyboards/ajazz/ak820/ak820_nvm.c:159: nvm_fail(stage);
      003F34 90 05 7A         [24]  974 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F37 E0               [24]  975 	movx	a,@dptr
      003F38 F5 82            [12]  976 	mov	dpl,a
                                    977 ;	keyboards/ajazz/ak820/ak820_nvm.c:160: }
      003F3A 02 3B 43         [24]  978 	ljmp	_nvm_fail
                                    979 ;------------------------------------------------------------
                                    980 ;Allocation info for local variables in function 'ak820_nvm_begin'
                                    981 ;------------------------------------------------------------
                                    982 ;	keyboards/ajazz/ak820/ak820_nvm.c:162: void ak820_nvm_begin(void) {
                                    983 ;	-----------------------------------------
                                    984 ;	 function ak820_nvm_begin
                                    985 ;	-----------------------------------------
      003F3D                        986 _ak820_nvm_begin:
                                    987 ;	keyboards/ajazz/ak820/ak820_nvm.c:163: if (batch_depth == 255u) nvm_fail(AK820_NVM_FAULT_BATCH_OVERFLOW);
      003F3D 90 05 5A         [24]  988 	mov	dptr,#_batch_depth
      003F40 E0               [24]  989 	movx	a,@dptr
      003F41 FF               [12]  990 	mov	r7,a
      003F42 BF FF 06         [24]  991 	cjne	r7,#0xff,00102$
      003F45 75 82 0F         [24]  992 	mov	dpl, #0x0f
      003F48 02 3B 43         [24]  993 	ljmp	_nvm_fail
      003F4B                        994 00102$:
                                    995 ;	keyboards/ajazz/ak820/ak820_nvm.c:164: else ++batch_depth;
      003F4B 90 05 5A         [24]  996 	mov	dptr,#_batch_depth
      003F4E EF               [12]  997 	mov	a,r7
      003F4F 04               [12]  998 	inc	a
      003F50 F0               [24]  999 	movx	@dptr,a
                                   1000 ;	keyboards/ajazz/ak820/ak820_nvm.c:165: }
      003F51 22               [24] 1001 	ret
                                   1002 ;------------------------------------------------------------
                                   1003 ;Allocation info for local variables in function 'ak820_nvm_end'
                                   1004 ;------------------------------------------------------------
                                   1005 ;	keyboards/ajazz/ak820/ak820_nvm.c:167: void ak820_nvm_end(void) {
                                   1006 ;	-----------------------------------------
                                   1007 ;	 function ak820_nvm_end
                                   1008 ;	-----------------------------------------
      003F52                       1009 _ak820_nvm_end:
                                   1010 ;	keyboards/ajazz/ak820/ak820_nvm.c:168: if (batch_depth) --batch_depth;
      003F52 90 05 5A         [24] 1011 	mov	dptr,#_batch_depth
      003F55 E0               [24] 1012 	movx	a,@dptr
      003F56 FF               [12] 1013 	mov	r7,a
      003F57 E0               [24] 1014 	movx	a,@dptr
      003F58 60 06            [24] 1015 	jz	00102$
      003F5A EF               [12] 1016 	mov	a,r7
      003F5B 14               [12] 1017 	dec	a
      003F5C 90 05 5A         [24] 1018 	mov	dptr,#_batch_depth
      003F5F F0               [24] 1019 	movx	@dptr,a
      003F60                       1020 00102$:
                                   1021 ;	keyboards/ajazz/ak820/ak820_nvm.c:169: if (!batch_depth) ak820_nvm_flush();
      003F60 90 05 5A         [24] 1022 	mov	dptr,#_batch_depth
      003F63 E0               [24] 1023 	movx	a,@dptr
      003F64 70 03            [24] 1024 	jnz	00105$
                                   1025 ;	keyboards/ajazz/ak820/ak820_nvm.c:170: }
      003F66 02 3D EA         [24] 1026 	ljmp	_ak820_nvm_flush
      003F69                       1027 00105$:
      003F69 22               [24] 1028 	ret
                                   1029 ;------------------------------------------------------------
                                   1030 ;Allocation info for local variables in function 'load_page'
                                   1031 ;------------------------------------------------------------
                                   1032 ;page          Allocated with name '_load_page_page_10000_87'
                                   1033 ;i             Allocated with name '_load_page_i_10000_88'
                                   1034 ;------------------------------------------------------------
                                   1035 ;	keyboards/ajazz/ak820/ak820_nvm.c:172: static bool load_page(uint8_t page) {
                                   1036 ;	-----------------------------------------
                                   1037 ;	 function load_page
                                   1038 ;	-----------------------------------------
      003F6A                       1039 _load_page:
      003F6A E5 82            [12] 1040 	mov	a,dpl
      003F6C 90 05 7B         [24] 1041 	mov	dptr,#_load_page_page_10000_87
      003F6F F0               [24] 1042 	movx	@dptr,a
                                   1043 ;	keyboards/ajazz/ak820/ak820_nvm.c:174: if (page_valid && cached_page == page) return !storage_failed;
      003F70 30 07 17         [24] 1044 	jnb	_page_valid,00102$
      003F73 90 05 59         [24] 1045 	mov	dptr,#_cached_page
      003F76 E0               [24] 1046 	movx	a,@dptr
      003F77 FF               [12] 1047 	mov	r7,a
      003F78 90 05 7B         [24] 1048 	mov	dptr,#_load_page_page_10000_87
      003F7B E0               [24] 1049 	movx	a,@dptr
      003F7C FE               [12] 1050 	mov	r6,a
      003F7D EF               [12] 1051 	mov	a,r7
      003F7E B5 06 09         [24] 1052 	cjne	a,ar6,00102$
      003F81 A2 09            [12] 1053 	mov	c,_storage_failed
      003F83 B3               [12] 1054 	cpl	c
      003F84 92 0B            [24] 1055 	mov  _load_page_sloc0_1_0,c
      003F86 12 38 66         [24] 1056 	lcall	_ak820_outline_0149
      003F89 22               [24] 1057 	ret
      003F8A                       1058 00102$:
                                   1059 ;	keyboards/ajazz/ak820/ak820_nvm.c:175: ak820_nvm_flush();
      003F8A 12 3D EA         [24] 1060 	lcall	_ak820_nvm_flush
                                   1061 ;	keyboards/ajazz/ak820/ak820_nvm.c:176: if (storage_failed) return false;
      003F8D 30 09 04         [24] 1062 	jnb	_storage_failed,00119$
      003F90 75 82 00         [24] 1063 	mov	dpl, #0x00
                                   1064 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003F93 22               [24] 1065 	ret
      003F94                       1066 00119$:
      003F94 7F 00            [12] 1067 	mov	r7,#0x00
      003F96                       1068 00107$:
                                   1069 ;	keyboards/ajazz/ak820/ak820_nvm.c:178: page_data[i] = ak820_flash_read(AK820_NVM_BASE + page * AK820_FLASH_PAGE + i);
      003F96 EF               [12] 1070 	mov	a,r7
      003F97 24 19            [12] 1071 	add	a, #_page_data
      003F99 FD               [12] 1072 	mov	r5,a
      003F9A E4               [12] 1073 	clr	a
      003F9B 34 05            [12] 1074 	addc	a, #(_page_data >> 8)
      003F9D FE               [12] 1075 	mov	r6,a
      003F9E 90 05 7B         [24] 1076 	mov	dptr,#_load_page_page_10000_87
      003FA1 E0               [24] 1077 	movx	a,@dptr
      003FA2 FC               [12] 1078 	mov	r4,a
      003FA3 FA               [12] 1079 	mov	r2,a
      003FA4 E4               [12] 1080 	clr	a
      003FA5 C3               [12] 1081 	clr	c
      003FA6 CA               [12] 1082 	xch	a,r2
      003FA7 13               [12] 1083 	rrc	a
      003FA8 CA               [12] 1084 	xch	a,r2
      003FA9 13               [12] 1085 	rrc	a
      003FAA A2 E0            [12] 1086 	mov	c,acc.0
      003FAC CA               [12] 1087 	xch	a,r2
      003FAD 13               [12] 1088 	rrc	a
      003FAE CA               [12] 1089 	xch	a,r2
      003FAF 13               [12] 1090 	rrc	a
      003FB0 CA               [12] 1091 	xch	a,r2
      003FB1 24 C7            [12] 1092 	add	a,#0xc7
      003FB3 FB               [12] 1093 	mov	r3,a
      003FB4 8F 01            [24] 1094 	mov	ar1,r7
      003FB6 89 00            [24] 1095 	mov	ar0,r1
      003FB8 79 00            [12] 1096 	mov	r1,#0x00
      003FBA E8               [12] 1097 	mov	a,r0
      003FBB 2A               [12] 1098 	add	a, r2
      003FBC FA               [12] 1099 	mov	r2,a
      003FBD E9               [12] 1100 	mov	a,r1
      003FBE 3B               [12] 1101 	addc	a, r3
      003FBF FB               [12] 1102 	mov	r3,a
      003FC0 12 43 28         [24] 1103 	lcall	_ak820_outline_0135
      003FC3 12 38 AF         [24] 1104 	lcall	_ak820_flash_read
      003FC6 AB 82            [24] 1105 	mov	r3, dpl
      003FC8 12 38 61         [24] 1106 	lcall	_ak820_outline_0137
      003FCB EB               [12] 1107 	mov	a,r3
      003FCC F0               [24] 1108 	movx	@dptr,a
                                   1109 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003FCD 0F               [12] 1110 	inc	r7
      003FCE BF 40 C5         [24] 1111 	cjne	r7,#0x40,00107$
                                   1112 ;	keyboards/ajazz/ak820/ak820_nvm.c:180: cached_page = page;
      003FD1 90 05 59         [24] 1113 	mov	dptr,#_cached_page
      003FD4 EC               [12] 1114 	mov	a,r4
      003FD5 F0               [24] 1115 	movx	@dptr,a
                                   1116 ;	keyboards/ajazz/ak820/ak820_nvm.c:181: page_valid = true;
                                   1117 ;	assignBit
      003FD6 D2 07            [12] 1118 	setb	_page_valid
                                   1119 ;	keyboards/ajazz/ak820/ak820_nvm.c:182: return true;
      003FD8 75 82 01         [24] 1120 	mov	dpl, #0x01
                                   1121 ;	keyboards/ajazz/ak820/ak820_nvm.c:183: }
      003FDB 22               [24] 1122 	ret
                                   1123 ;------------------------------------------------------------
                                   1124 ;Allocation info for local variables in function 'read_offset'
                                   1125 ;------------------------------------------------------------
                                   1126 ;offset        Allocated with name '_read_offset_offset_10000_93'
                                   1127 ;------------------------------------------------------------
                                   1128 ;	keyboards/ajazz/ak820/ak820_nvm.c:185: static uint8_t read_offset(uint16_t offset) {
                                   1129 ;	-----------------------------------------
                                   1130 ;	 function read_offset
                                   1131 ;	-----------------------------------------
      003FDC                       1132 _read_offset:
      003FDC 12 38 4C         [24] 1133 	lcall	_ak820_outline_0106
      003FDF 90 05 7C         [24] 1134 	mov	dptr,#_read_offset_offset_10000_93
      003FE2 12 38 47         [24] 1135 	lcall	_ak820_outline_0105
                                   1136 ;	keyboards/ajazz/ak820/ak820_nvm.c:186: if (offset >= AK820_NVM_SIZE) return 0;
      003FE5 90 05 7C         [24] 1137 	mov	dptr,#_read_offset_offset_10000_93
      003FE8 12 37 F7         [24] 1138 	lcall	_ak820_outline_0056
      003FEB C3               [12] 1139 	clr	c
      003FEC 94 28            [12] 1140 	subb	a,#0x28
      003FEE 40 04            [24] 1141 	jc	00102$
      003FF0 75 82 00         [24] 1142 	mov	dpl, #0x00
      003FF3 22               [24] 1143 	ret
      003FF4                       1144 00102$:
                                   1145 ;	keyboards/ajazz/ak820/ak820_nvm.c:187: if (page_valid && (offset / AK820_FLASH_PAGE) == cached_page)
      003FF4 30 07 34         [24] 1146 	jnb	_page_valid,00104$
      003FF7 8E 04            [24] 1147 	mov	ar4,r6
      003FF9 EF               [12] 1148 	mov	a,r7
      003FFA A2 E7            [12] 1149 	mov	c,acc.7
      003FFC CC               [12] 1150 	xch	a,r4
      003FFD 33               [12] 1151 	rlc	a
      003FFE CC               [12] 1152 	xch	a,r4
      003FFF 33               [12] 1153 	rlc	a
      004000 A2 E7            [12] 1154 	mov	c,acc.7
      004002 CC               [12] 1155 	xch	a,r4
      004003 33               [12] 1156 	rlc	a
      004004 CC               [12] 1157 	xch	a,r4
      004005 33               [12] 1158 	rlc	a
      004006 CC               [12] 1159 	xch	a,r4
      004007 54 03            [12] 1160 	anl	a,#0x03
      004009 FD               [12] 1161 	mov	r5,a
      00400A 90 05 59         [24] 1162 	mov	dptr,#_cached_page
      00400D E0               [24] 1163 	movx	a,@dptr
      00400E FA               [12] 1164 	mov	r2,a
      00400F 7B 00            [12] 1165 	mov	r3,#0x00
      004011 EC               [12] 1166 	mov	a,r4
      004012 B5 02 16         [24] 1167 	cjne	a,ar2,00104$
      004015 ED               [12] 1168 	mov	a,r5
      004016 B5 03 12         [24] 1169 	cjne	a,ar3,00104$
                                   1170 ;	keyboards/ajazz/ak820/ak820_nvm.c:188: return page_data[offset % AK820_FLASH_PAGE];
      004019 74 3F            [12] 1171 	mov	a,#0x3f
      00401B 5E               [12] 1172 	anl	a,r6
      00401C 7D 00            [12] 1173 	mov	r5,#0x00
      00401E 24 19            [12] 1174 	add	a, #_page_data
      004020 F5 82            [12] 1175 	mov	dpl,a
      004022 ED               [12] 1176 	mov	a,r5
      004023 34 05            [12] 1177 	addc	a, #(_page_data >> 8)
      004025 F5 83            [12] 1178 	mov	dph,a
      004027 E0               [24] 1179 	movx	a,@dptr
      004028 F5 82            [12] 1180 	mov	dpl,a
      00402A 22               [24] 1181 	ret
      00402B                       1182 00104$:
                                   1183 ;	keyboards/ajazz/ak820/ak820_nvm.c:189: return ak820_flash_read(AK820_NVM_BASE + offset);
      00402B 74 C7            [12] 1184 	mov	a,#0xc7
      00402D 2F               [12] 1185 	add	a, r7
      00402E FF               [12] 1186 	mov	r7,a
      00402F 12 43 23         [24] 1187 	lcall	_ak820_outline_0119
                                   1188 ;	keyboards/ajazz/ak820/ak820_nvm.c:190: }
      004032 02 38 AF         [24] 1189 	ljmp	_ak820_flash_read
                                   1190 ;------------------------------------------------------------
                                   1191 ;Allocation info for local variables in function 'eeprom_read_byte'
                                   1192 ;------------------------------------------------------------
                                   1193 ;addr          Allocated with name '_eeprom_read_byte_addr_10000_97'
                                   1194 ;------------------------------------------------------------
                                   1195 ;	keyboards/ajazz/ak820/ak820_nvm.c:193: uint8_t eeprom_read_byte(const uint8_t *addr) {
                                   1196 ;	-----------------------------------------
                                   1197 ;	 function eeprom_read_byte
                                   1198 ;	-----------------------------------------
      004035                       1199 _eeprom_read_byte:
      004035 C0 07            [24] 1200 	push	ar7
      004037 C0 06            [24] 1201 	push	ar6
      004039 12 42 D4         [24] 1202 	lcall	_ak820_outline_0042
      00403C 90 05 7E         [24] 1203 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      00403F 12 37 DF         [24] 1204 	lcall	_ak820_outline_0018
                                   1205 ;	keyboards/ajazz/ak820/ak820_nvm.c:194: return read_offset((uint16_t)(uintptr_t)addr);
      004042 90 05 7E         [24] 1206 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      004045 12 37 A8         [24] 1207 	lcall	_ak820_outline_0005
      004048 C0 06            [24] 1208 	push	ar6
      00404A C0 05            [24] 1209 	push	ar5
      00404C C0 04            [24] 1210 	push	ar4
      00404E C0 03            [24] 1211 	push	ar3
      004050 C0 02            [24] 1212 	push	ar2
      004052 C0 01            [24] 1213 	push	ar1
      004054 C0 00            [24] 1214 	push	ar0
      004056 12 3F DC         [24] 1215 	lcall	_read_offset
      004059 AF 82            [24] 1216 	mov	r7, dpl
      00405B D0 00            [24] 1217 	pop	ar0
      00405D D0 01            [24] 1218 	pop	ar1
      00405F D0 02            [24] 1219 	pop	ar2
      004061 D0 03            [24] 1220 	pop	ar3
      004063 D0 04            [24] 1221 	pop	ar4
      004065 D0 05            [24] 1222 	pop	ar5
      004067 D0 06            [24] 1223 	pop	ar6
      004069 8F 82            [24] 1224 	mov	dpl, r7
                                   1225 ;	keyboards/ajazz/ak820/ak820_nvm.c:195: }
      00406B D0 06            [24] 1226 	pop	ar6
      00406D D0 07            [24] 1227 	pop	ar7
      00406F 22               [24] 1228 	ret
                                   1229 ;------------------------------------------------------------
                                   1230 ;Allocation info for local variables in function 'eeprom_read_block'
                                   1231 ;------------------------------------------------------------
                                   1232 ;addr          Allocated with name '_eeprom_read_block_PARM_2'
                                   1233 ;len           Allocated with name '_eeprom_read_block_PARM_3'
                                   1234 ;buf           Allocated with name '_eeprom_read_block_buf_10000_99'
                                   1235 ;offset        Allocated with name '_eeprom_read_block_offset_10000_100'
                                   1236 ;out           Allocated with name '_eeprom_read_block_out_10000_100'
                                   1237 ;------------------------------------------------------------
                                   1238 ;	keyboards/ajazz/ak820/ak820_nvm.c:199: void eeprom_read_block(void *buf, const void *addr, size_t len) {
                                   1239 ;	-----------------------------------------
                                   1240 ;	 function ak820_eeprom_read_block_xdata
                                   1241 ;	-----------------------------------------
      004070                       1242 _ak820_eeprom_read_block_xdata:
      004070 12 38 4C         [24] 1243 	lcall	_ak820_outline_0106
      004073 90 05 86         [24] 1244 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      004076 12 38 47         [24] 1245 	lcall	_ak820_outline_0105
                                   1246 ;	keyboards/ajazz/ak820/ak820_nvm.c:230: uint16_t offset = (uint16_t)(uintptr_t)addr;
      004079 90 05 81         [24] 1247 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      00407C 12 37 F7         [24] 1248 	lcall	_ak820_outline_0056
                                   1249 ;	keyboards/ajazz/ak820/ak820_nvm.c:231: uint8_t AK820_XDATA *out = (uint8_t AK820_XDATA *)buf;
      00407F 90 05 86         [24] 1250 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      004082 12 38 16         [24] 1251 	lcall	_ak820_outline_0065
      004085 90 05 88         [24] 1252 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004088 12 38 22         [24] 1253 	lcall	_ak820_outline_0077
                                   1254 ;	keyboards/ajazz/ak820/ak820_nvm.c:232: while (len--) {
      00408B 90 05 84         [24] 1255 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      00408E 12 38 16         [24] 1256 	lcall	_ak820_outline_0065
      004091                       1257 00103$:
      004091 8C 02            [24] 1258 	mov	ar2,r4
      004093 8D 03            [24] 1259 	mov	ar3,r5
      004095 1C               [12] 1260 	dec	r4
      004096 BC FF 01         [24] 1261 	cjne	r4,#0xff,00130$
      004099 1D               [12] 1262 	dec	r5
      00409A                       1263 00130$:
      00409A EA               [12] 1264 	mov	a,r2
      00409B 4B               [12] 1265 	orl	a,r3
      00409C 60 5D            [24] 1266 	jz	00106$
                                   1267 ;	keyboards/ajazz/ak820/ak820_nvm.c:233: if (offset >= AK820_NVM_SIZE) { *out++ = 0; continue; }
      00409E 8E 02            [24] 1268 	mov	ar2,r6
      0040A0 8F 03            [24] 1269 	mov	ar3,r7
      0040A2 74 D8            [12] 1270 	mov	a,#0x100 - 0x28
      0040A4 2B               [12] 1271 	add	a,r3
      0040A5 50 17            [24] 1272 	jnc	00102$
      0040A7 90 05 88         [24] 1273 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0040AA 12 43 05         [24] 1274 	lcall	_ak820_outline_0082
      0040AD 12 43 28         [24] 1275 	lcall	_ak820_outline_0135
      0040B0 E4               [12] 1276 	clr	a
      0040B1 F0               [24] 1277 	movx	@dptr,a
      0040B2 90 05 88         [24] 1278 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0040B5 04               [12] 1279 	inc	a
      0040B6 2A               [12] 1280 	add	a, r2
      0040B7 F0               [24] 1281 	movx	@dptr,a
      0040B8 E4               [12] 1282 	clr	a
      0040B9 3B               [12] 1283 	addc	a, r3
      0040BA A3               [24] 1284 	inc	dptr
      0040BB F0               [24] 1285 	movx	@dptr,a
      0040BC 80 D3            [24] 1286 	sjmp	00103$
      0040BE                       1287 00102$:
                                   1288 ;	keyboards/ajazz/ak820/ak820_nvm.c:234: *out++ = read_offset(offset);
      0040BE 90 05 88         [24] 1289 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0040C1 12 43 05         [24] 1290 	lcall	_ak820_outline_0082
      0040C4 12 43 23         [24] 1291 	lcall	_ak820_outline_0119
      0040C7 C0 07            [24] 1292 	push	ar7
      0040C9 C0 06            [24] 1293 	push	ar6
      0040CB C0 05            [24] 1294 	push	ar5
      0040CD C0 04            [24] 1295 	push	ar4
      0040CF C0 03            [24] 1296 	push	ar3
      0040D1 C0 02            [24] 1297 	push	ar2
      0040D3 12 3F DC         [24] 1298 	lcall	_read_offset
      0040D6 A9 82            [24] 1299 	mov	r1, dpl
      0040D8 D0 02            [24] 1300 	pop	ar2
      0040DA D0 03            [24] 1301 	pop	ar3
      0040DC D0 04            [24] 1302 	pop	ar4
      0040DE D0 05            [24] 1303 	pop	ar5
      0040E0 D0 06            [24] 1304 	pop	ar6
      0040E2 D0 07            [24] 1305 	pop	ar7
      0040E4 12 43 28         [24] 1306 	lcall	_ak820_outline_0135
      0040E7 E9               [12] 1307 	mov	a,r1
      0040E8 F0               [24] 1308 	movx	@dptr,a
      0040E9 90 05 88         [24] 1309 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0040EC 74 01            [12] 1310 	mov	a,#0x01
      0040EE 2A               [12] 1311 	add	a, r2
      0040EF F0               [24] 1312 	movx	@dptr,a
      0040F0 E4               [12] 1313 	clr	a
      0040F1 3B               [12] 1314 	addc	a, r3
      0040F2 A3               [24] 1315 	inc	dptr
      0040F3 F0               [24] 1316 	movx	@dptr,a
                                   1317 ;	keyboards/ajazz/ak820/ak820_nvm.c:235: ++offset;
      0040F4 0E               [12] 1318 	inc	r6
      0040F5 BE 00 99         [24] 1319 	cjne	r6,#0x00,00103$
      0040F8 0F               [12] 1320 	inc	r7
      0040F9 80 96            [24] 1321 	sjmp	00103$
      0040FB                       1322 00106$:
                                   1323 ;	keyboards/ajazz/ak820/ak820_nvm.c:237: }
      0040FB 22               [24] 1324 	ret
                                   1325 ;------------------------------------------------------------
                                   1326 ;Allocation info for local variables in function 'ak820_eeprom_write_block_xdata'
                                   1327 ;------------------------------------------------------------
                                   1328 ;sloc0         Allocated with name '_ak820_eeprom_write_block_xdata_sloc0_1_0'
                                   1329 ;addr          Allocated with name '_ak820_eeprom_write_block_xdata_PARM_2'
                                   1330 ;len           Allocated with name '_ak820_eeprom_write_block_xdata_PARM_3'
                                   1331 ;buf           Allocated with name '_ak820_eeprom_write_block_xdata_buf_10000_118'
                                   1332 ;offset        Allocated with name '_ak820_eeprom_write_block_xdata_offset_10000_119'
                                   1333 ;in            Allocated with name '_ak820_eeprom_write_block_xdata_in_10000_119'
                                   1334 ;value         Allocated with name '_ak820_eeprom_write_block_xdata_value_20000_122'
                                   1335 ;------------------------------------------------------------
                                   1336 ;	keyboards/ajazz/ak820/ak820_nvm.c:239: void ak820_eeprom_write_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1337 ;	-----------------------------------------
                                   1338 ;	 function ak820_eeprom_write_block_xdata
                                   1339 ;	-----------------------------------------
      0040FC                       1340 _ak820_eeprom_write_block_xdata:
      0040FC 12 38 4C         [24] 1341 	lcall	_ak820_outline_0106
      0040FF 90 05 8F         [24] 1342 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      004102 12 38 47         [24] 1343 	lcall	_ak820_outline_0105
                                   1344 ;	keyboards/ajazz/ak820/ak820_nvm.c:240: uint16_t offset = (uint16_t)(uintptr_t)addr;
      004105 90 05 8A         [24] 1345 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      004108 12 37 F7         [24] 1346 	lcall	_ak820_outline_0056
                                   1347 ;	keyboards/ajazz/ak820/ak820_nvm.c:241: const uint8_t AK820_XDATA *in = (const uint8_t AK820_XDATA *)buf;
      00410B 90 05 8F         [24] 1348 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      00410E 12 38 16         [24] 1349 	lcall	_ak820_outline_0065
                                   1350 ;	keyboards/ajazz/ak820/ak820_nvm.c:243: if (offset > AK820_NVM_SIZE || len > AK820_NVM_SIZE - offset) {
      004111 8E 02            [24] 1351 	mov	ar2,r6
      004113 8F 03            [24] 1352 	mov	ar3,r7
      004115 C3               [12] 1353 	clr	c
      004116 E4               [12] 1354 	clr	a
      004117 9A               [12] 1355 	subb	a,r2
      004118 74 28            [12] 1356 	mov	a,#0x28
      00411A 9B               [12] 1357 	subb	a,r3
      00411B 40 15            [24] 1358 	jc	00101$
                                   1359 ;	free result
      00411D E4               [12] 1360 	clr	a
      00411E C3               [12] 1361 	clr	c
      00411F 9E               [12] 1362 	subb	a,r6
      004120 FA               [12] 1363 	mov	r2,a
      004121 74 28            [12] 1364 	mov	a,#0x28
      004123 9F               [12] 1365 	subb	a,r7
      004124 FB               [12] 1366 	mov	r3,a
      004125 90 05 8D         [24] 1367 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004128 12 38 3B         [24] 1368 	lcall	_ak820_outline_0102
      00412B C3               [12] 1369 	clr	c
      00412C EA               [12] 1370 	mov	a,r2
      00412D 98               [12] 1371 	subb	a,r0
      00412E EB               [12] 1372 	mov	a,r3
      00412F 99               [12] 1373 	subb	a,r1
      004130 50 06            [24] 1374 	jnc	00125$
                                   1375 ;	free result
      004132                       1376 00101$:
                                   1377 ;	keyboards/ajazz/ak820/ak820_nvm.c:244: nvm_fail(AK820_NVM_FAULT_WRITE_RANGE);
      004132 75 82 0E         [24] 1378 	mov	dpl, #0x0e
                                   1379 ;	keyboards/ajazz/ak820/ak820_nvm.c:245: return;
      004135 02 3B 43         [24] 1380 	ljmp	_nvm_fail
                                   1381 ;	keyboards/ajazz/ak820/ak820_nvm.c:247: while (len--) {
      004138                       1382 00125$:
      004138 90 05 8D         [24] 1383 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      00413B 12 43 05         [24] 1384 	lcall	_ak820_outline_0082
      00413E                       1385 00108$:
      00413E 8A 00            [24] 1386 	mov	ar0,r2
      004140 8B 01            [24] 1387 	mov	ar1,r3
      004142 1A               [12] 1388 	dec	r2
      004143 BA FF 01         [24] 1389 	cjne	r2,#0xff,00159$
      004146 1B               [12] 1390 	dec	r3
      004147                       1391 00159$:
      004147 E8               [12] 1392 	mov	a,r0
      004148 49               [12] 1393 	orl	a,r1
      004149 70 03            [24] 1394 	jnz	00160$
      00414B 02 41 D5         [24] 1395 	ljmp	00110$
      00414E                       1396 00160$:
                                   1397 ;	keyboards/ajazz/ak820/ak820_nvm.c:248: uint8_t value = *in++;
      00414E C0 02            [24] 1398 	push	ar2
      004150 C0 03            [24] 1399 	push	ar3
      004152 12 43 0B         [24] 1400 	lcall	_ak820_outline_0097
      004155 F9               [12] 1401 	mov	r1,a
      004156 A3               [24] 1402 	inc	dptr
      004157 12 43 3D         [24] 1403 	lcall	_ak820_outline_0151
                                   1404 ;	keyboards/ajazz/ak820/ak820_nvm.c:249: if (!load_page(offset / AK820_FLASH_PAGE)) return;
      00415A 8E 0C            [24] 1405 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,r6
      00415C 8F 0D            [24] 1406 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),r7
      00415E A8 0C            [24] 1407 	mov	r0,_ak820_eeprom_write_block_xdata_sloc0_1_0
      004160 E5 0D            [12] 1408 	mov	a,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      004162 A2 E7            [12] 1409 	mov	c,acc.7
      004164 C8               [12] 1410 	xch	a,r0
      004165 33               [12] 1411 	rlc	a
      004166 C8               [12] 1412 	xch	a,r0
      004167 33               [12] 1413 	rlc	a
      004168 A2 E7            [12] 1414 	mov	c,acc.7
      00416A C8               [12] 1415 	xch	a,r0
      00416B 33               [12] 1416 	rlc	a
      00416C C8               [12] 1417 	xch	a,r0
      00416D 33               [12] 1418 	rlc	a
      00416E C8               [12] 1419 	xch	a,r0
      00416F 54 03            [12] 1420 	anl	a,#0x03
      004171 FB               [12] 1421 	mov	r3,a
      004172 88 82            [24] 1422 	mov	dpl, r0
      004174 C0 07            [24] 1423 	push	ar7
      004176 C0 06            [24] 1424 	push	ar6
      004178 C0 05            [24] 1425 	push	ar5
      00417A C0 04            [24] 1426 	push	ar4
      00417C C0 03            [24] 1427 	push	ar3
      00417E C0 02            [24] 1428 	push	ar2
      004180 C0 01            [24] 1429 	push	ar1
      004182 12 3F 6A         [24] 1430 	lcall	_load_page
      004185 E5 82            [12] 1431 	mov	a, dpl
      004187 D0 01            [24] 1432 	pop	ar1
      004189 D0 02            [24] 1433 	pop	ar2
      00418B D0 03            [24] 1434 	pop	ar3
      00418D D0 04            [24] 1435 	pop	ar4
      00418F D0 05            [24] 1436 	pop	ar5
      004191 D0 06            [24] 1437 	pop	ar6
      004193 D0 07            [24] 1438 	pop	ar7
      004195 D0 03            [24] 1439 	pop	ar3
      004197 D0 02            [24] 1440 	pop	ar2
      004199 70 01            [24] 1441 	jnz	00105$
      00419B 22               [24] 1442 	ret
      00419C                       1443 00105$:
                                   1444 ;	keyboards/ajazz/ak820/ak820_nvm.c:250: if (page_data[offset % AK820_FLASH_PAGE] != value) {
      00419C C0 06            [24] 1445 	push	ar6
      00419E C0 07            [24] 1446 	push	ar7
      0041A0 74 3F            [12] 1447 	mov	a,#0x3f
      0041A2 55 0C            [12] 1448 	anl	a,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0041A4 7F 00            [12] 1449 	mov	r7,#0x00
      0041A6 24 19            [12] 1450 	add	a, #_page_data
      0041A8 F5 0C            [12] 1451 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,a
      0041AA EF               [12] 1452 	mov	a,r7
      0041AB 34 05            [12] 1453 	addc	a, #(_page_data >> 8)
      0041AD F5 0D            [12] 1454 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),a
      0041AF 85 0C 82         [24] 1455 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0041B2 85 0D 83         [24] 1456 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      0041B5 E0               [24] 1457 	movx	a,@dptr
      0041B6 B5 01 06         [24] 1458 	cjne	a,ar1,00162$
      0041B9 D0 07            [24] 1459 	pop	ar7
      0041BB D0 06            [24] 1460 	pop	ar6
      0041BD 80 0E            [24] 1461 	sjmp	00107$
      0041BF                       1462 00162$:
      0041BF D0 07            [24] 1463 	pop	ar7
      0041C1 D0 06            [24] 1464 	pop	ar6
                                   1465 ;	keyboards/ajazz/ak820/ak820_nvm.c:251: page_data[offset % AK820_FLASH_PAGE] = value;
      0041C3 85 0C 82         [24] 1466 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0041C6 85 0D 83         [24] 1467 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      0041C9 E9               [12] 1468 	mov	a,r1
      0041CA F0               [24] 1469 	movx	@dptr,a
                                   1470 ;	keyboards/ajazz/ak820/ak820_nvm.c:252: page_dirty = true;
                                   1471 ;	assignBit
      0041CB D2 08            [12] 1472 	setb	_page_dirty
      0041CD                       1473 00107$:
                                   1474 ;	keyboards/ajazz/ak820/ak820_nvm.c:254: ++offset;
      0041CD 0E               [12] 1475 	inc	r6
      0041CE BE 00 01         [24] 1476 	cjne	r6,#0x00,00163$
      0041D1 0F               [12] 1477 	inc	r7
      0041D2                       1478 00163$:
      0041D2 02 41 3E         [24] 1479 	ljmp	00108$
      0041D5                       1480 00110$:
                                   1481 ;	keyboards/ajazz/ak820/ak820_nvm.c:256: if (!batch_depth) ak820_nvm_flush();
      0041D5 90 05 5A         [24] 1482 	mov	dptr,#_batch_depth
      0041D8 E0               [24] 1483 	movx	a,@dptr
      0041D9 70 03            [24] 1484 	jnz	00113$
                                   1485 ;	keyboards/ajazz/ak820/ak820_nvm.c:257: }
      0041DB 02 3D EA         [24] 1486 	ljmp	_ak820_nvm_flush
      0041DE                       1487 00113$:
      0041DE 22               [24] 1488 	ret
                                   1489 ;------------------------------------------------------------
                                   1490 ;Allocation info for local variables in function 'ak820_eeprom_update_block_xdata'
                                   1491 ;------------------------------------------------------------
                                   1492 ;sloc0         Allocated with name '_ak820_eeprom_update_block_xdata_sloc0_1_0'
                                   1493 ;sloc1         Allocated with name '_ak820_eeprom_update_block_xdata_sloc1_1_0'
                                   1494 ;sloc2         Allocated with name '_ak820_eeprom_update_block_xdata_sloc2_1_0'
                                   1495 ;addr          Allocated with name '_ak820_eeprom_update_block_xdata_PARM_2'
                                   1496 ;len           Allocated with name '_ak820_eeprom_update_block_xdata_PARM_3'
                                   1497 ;buf           Allocated with name '_ak820_eeprom_update_block_xdata_buf_10000_127'
                                   1498 ;source        Allocated with name '_ak820_eeprom_update_block_xdata_source_10000_128'
                                   1499 ;offset        Allocated with name '_ak820_eeprom_update_block_xdata_offset_10000_128'
                                   1500 ;i             Allocated with name '_ak820_eeprom_update_block_xdata_i_10000_128'
                                   1501 ;------------------------------------------------------------
                                   1502 ;	keyboards/ajazz/ak820/ak820_nvm.c:259: void ak820_eeprom_update_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1503 ;	-----------------------------------------
                                   1504 ;	 function ak820_eeprom_update_block_xdata
                                   1505 ;	-----------------------------------------
      0041DF                       1506 _ak820_eeprom_update_block_xdata:
      0041DF 12 38 4C         [24] 1507 	lcall	_ak820_outline_0106
      0041E2 90 05 96         [24] 1508 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      0041E5 12 38 47         [24] 1509 	lcall	_ak820_outline_0105
                                   1510 ;	keyboards/ajazz/ak820/ak820_nvm.c:260: const uint8_t AK820_XDATA *source = (const uint8_t AK820_XDATA *)buf;
      0041E8 90 05 96         [24] 1511 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      0041EB 12 37 F7         [24] 1512 	lcall	_ak820_outline_0056
                                   1513 ;	keyboards/ajazz/ak820/ak820_nvm.c:261: uint16_t offset = (uint16_t)(uintptr_t)addr;
      0041EE 90 05 91         [24] 1514 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      0041F1 E0               [24] 1515 	movx	a,@dptr
      0041F2 F5 12            [12] 1516 	mov	_ak820_eeprom_update_block_xdata_sloc2_1_0,a
      0041F4 A3               [24] 1517 	inc	dptr
      0041F5 E0               [24] 1518 	movx	a,@dptr
      0041F6 F5 13            [12] 1519 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1),a
      0041F8 A3               [24] 1520 	inc	dptr
      0041F9 E0               [24] 1521 	movx	a,@dptr
      0041FA F5 14            [12] 1522 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2),a
      0041FC A9 12            [24] 1523 	mov	r1,_ak820_eeprom_update_block_xdata_sloc2_1_0
      0041FE AA 13            [24] 1524 	mov	r2,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
                                   1525 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      004200 E4               [12] 1526 	clr	a
      004201 F5 0E            [12] 1527 	mov	_ak820_eeprom_update_block_xdata_sloc0_1_0,a
      004203 F5 0F            [12] 1528 	mov	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1),a
      004205                       1529 00105$:
      004205 90 05 94         [24] 1530 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      004208 E0               [24] 1531 	movx	a,@dptr
      004209 F5 10            [12] 1532 	mov	_ak820_eeprom_update_block_xdata_sloc1_1_0,a
      00420B A3               [24] 1533 	inc	dptr
      00420C E0               [24] 1534 	movx	a,@dptr
      00420D F5 11            [12] 1535 	mov	(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1),a
      00420F C3               [12] 1536 	clr	c
      004210 E5 0E            [12] 1537 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      004212 95 10            [12] 1538 	subb	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      004214 E5 0F            [12] 1539 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      004216 95 11            [12] 1540 	subb	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      004218 50 68            [24] 1541 	jnc	00107$
                                   1542 ;	keyboards/ajazz/ak820/ak820_nvm.c:264: if (read_offset(offset + i) != source[i]) {
      00421A 89 00            [24] 1543 	mov	ar0,r1
      00421C 8A 05            [24] 1544 	mov	ar5,r2
      00421E E5 0E            [12] 1545 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      004220 28               [12] 1546 	add	a, r0
      004221 F8               [12] 1547 	mov	r0,a
      004222 E5 0F            [12] 1548 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      004224 3D               [12] 1549 	addc	a, r5
      004225 FD               [12] 1550 	mov	r5,a
      004226 88 82            [24] 1551 	mov	dpl, r0
      004228 8D 83            [24] 1552 	mov	dph, r5
      00422A C0 07            [24] 1553 	push	ar7
      00422C C0 06            [24] 1554 	push	ar6
      00422E C0 02            [24] 1555 	push	ar2
      004230 C0 01            [24] 1556 	push	ar1
      004232 12 3F DC         [24] 1557 	lcall	_read_offset
      004235 AD 82            [24] 1558 	mov	r5, dpl
      004237 D0 01            [24] 1559 	pop	ar1
      004239 D0 02            [24] 1560 	pop	ar2
      00423B D0 06            [24] 1561 	pop	ar6
      00423D D0 07            [24] 1562 	pop	ar7
      00423F E5 0E            [12] 1563 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      004241 2E               [12] 1564 	add	a, r6
      004242 F5 82            [12] 1565 	mov	dpl,a
      004244 E5 0F            [12] 1566 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      004246 3F               [12] 1567 	addc	a, r7
      004247 F5 83            [12] 1568 	mov	dph,a
      004249 E0               [24] 1569 	movx	a,@dptr
      00424A FC               [12] 1570 	mov	r4,a
      00424B ED               [12] 1571 	mov	a,r5
      00424C B5 04 02         [24] 1572 	cjne	a,ar4,00131$
      00424F 80 27            [24] 1573 	sjmp	00106$
      004251                       1574 00131$:
                                   1575 ;	keyboards/ajazz/ak820/ak820_nvm.c:265: ak820_eeprom_write_block_xdata(buf, addr, len);
      004251 90 05 96         [24] 1576 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      004254 E0               [24] 1577 	movx	a,@dptr
      004255 F8               [12] 1578 	mov	r0,a
      004256 A3               [24] 1579 	inc	dptr
      004257 E0               [24] 1580 	movx	a,@dptr
      004258 FD               [12] 1581 	mov	r5,a
      004259 90 05 8A         [24] 1582 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      00425C E5 12            [12] 1583 	mov	a,_ak820_eeprom_update_block_xdata_sloc2_1_0
      00425E F0               [24] 1584 	movx	@dptr,a
      00425F E5 13            [12] 1585 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
      004261 A3               [24] 1586 	inc	dptr
      004262 F0               [24] 1587 	movx	@dptr,a
      004263 E5 14            [12] 1588 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2)
      004265 A3               [24] 1589 	inc	dptr
      004266 F0               [24] 1590 	movx	@dptr,a
      004267 90 05 8D         [24] 1591 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      00426A E5 10            [12] 1592 	mov	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      00426C F0               [24] 1593 	movx	@dptr,a
      00426D E5 11            [12] 1594 	mov	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      00426F A3               [24] 1595 	inc	dptr
      004270 F0               [24] 1596 	movx	@dptr,a
      004271 88 82            [24] 1597 	mov	dpl, r0
      004273 8D 83            [24] 1598 	mov	dph, r5
                                   1599 ;	keyboards/ajazz/ak820/ak820_nvm.c:266: return;
      004275 02 40 FC         [24] 1600 	ljmp	_ak820_eeprom_write_block_xdata
      004278                       1601 00106$:
                                   1602 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      004278 05 0E            [12] 1603 	inc	_ak820_eeprom_update_block_xdata_sloc0_1_0
      00427A E4               [12] 1604 	clr	a
      00427B B5 0E 87         [24] 1605 	cjne	a,_ak820_eeprom_update_block_xdata_sloc0_1_0,00105$
      00427E 05 0F            [12] 1606 	inc	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      004280 80 83            [24] 1607 	sjmp	00105$
      004282                       1608 00107$:
                                   1609 ;	keyboards/ajazz/ak820/ak820_nvm.c:269: }
      004282 22               [24] 1610 	ret
                                   1611 ;------------------------------------------------------------
                                   1612 ;Allocation info for local variables in function 'eeprom_driver_erase'
                                   1613 ;------------------------------------------------------------
                                   1614 ;page          Allocated with name '_eeprom_driver_erase_page_10000_134'
                                   1615 ;i             Allocated with name '_eeprom_driver_erase_i_10000_134'
                                   1616 ;------------------------------------------------------------
                                   1617 ;	keyboards/ajazz/ak820/ak820_nvm.c:271: void eeprom_driver_erase(void) {
                                   1618 ;	-----------------------------------------
                                   1619 ;	 function eeprom_driver_erase
                                   1620 ;	-----------------------------------------
      004283                       1621 _eeprom_driver_erase:
                                   1622 ;	keyboards/ajazz/ak820/ak820_nvm.c:274: ak820_nvm_flush();
      004283 12 3D EA         [24] 1623 	lcall	_ak820_nvm_flush
                                   1624 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      004286 7F 00            [12] 1625 	mov	r7,#0x00
      004288                       1626 00111$:
      004288 BF A0 01         [24] 1627 	cjne	r7,#0xa0,00165$
      00428B 22               [24] 1628 	ret
      00428C                       1629 00165$:
      00428C 20 09 32         [24] 1630 	jb	_storage_failed,00113$
                                   1631 ;	keyboards/ajazz/ak820/ak820_nvm.c:276: if (!load_page(page)) return;
      00428F 8F 82            [24] 1632 	mov	dpl, r7
      004291 C0 07            [24] 1633 	push	ar7
      004293 12 3F 6A         [24] 1634 	lcall	_load_page
      004296 E5 82            [12] 1635 	mov	a, dpl
      004298 D0 07            [24] 1636 	pop	ar7
      00429A 70 01            [24] 1637 	jnz	00126$
                                   1638 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      00429C 22               [24] 1639 	ret
      00429D                       1640 00126$:
      00429D 7E 00            [12] 1641 	mov	r6,#0x00
      00429F                       1642 00107$:
                                   1643 ;	keyboards/ajazz/ak820/ak820_nvm.c:278: if (page_data[i]) { page_data[i] = 0; page_dirty = true; }
      00429F EE               [12] 1644 	mov	a,r6
      0042A0 24 19            [12] 1645 	add	a, #_page_data
      0042A2 FC               [12] 1646 	mov	r4,a
      0042A3 E4               [12] 1647 	clr	a
      0042A4 34 05            [12] 1648 	addc	a, #(_page_data >> 8)
      0042A6 FD               [12] 1649 	mov	r5,a
      0042A7 12 43 0B         [24] 1650 	lcall	_ak820_outline_0097
      0042AA 60 07            [24] 1651 	jz	00108$
      0042AC 12 38 51         [24] 1652 	lcall	_ak820_outline_0123
      0042AF E4               [12] 1653 	clr	a
      0042B0 F0               [24] 1654 	movx	@dptr,a
                                   1655 ;	assignBit
      0042B1 D2 08            [12] 1656 	setb	_page_dirty
      0042B3                       1657 00108$:
                                   1658 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      0042B3 0E               [12] 1659 	inc	r6
      0042B4 BE 40 E8         [24] 1660 	cjne	r6,#0x40,00107$
                                   1661 ;	keyboards/ajazz/ak820/ak820_nvm.c:280: ak820_nvm_flush();
      0042B7 C0 07            [24] 1662 	push	ar7
      0042B9 12 3D EA         [24] 1663 	lcall	_ak820_nvm_flush
      0042BC D0 07            [24] 1664 	pop	ar7
                                   1665 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      0042BE 0F               [12] 1666 	inc	r7
      0042BF 80 C7            [24] 1667 	sjmp	00111$
      0042C1                       1668 00113$:
                                   1669 ;	keyboards/ajazz/ak820/ak820_nvm.c:282: }
      0042C1 22               [24] 1670 	ret
                                   1671 	.area CSEG    (CODE)
                                   1672 	.area CONST   (CODE)
                                   1673 	.area XINIT   (CODE)
                                   1674 	.area CABS    (ABS,CODE)
                                   1675 
                                   1676 ; Experimental exact instruction outlining.
                                   1677 	.globl _ak820_outline_0005
                                   1678 	.globl _ak820_outline_0013
                                   1679 	.globl _ak820_outline_0017
                                   1680 	.globl _ak820_outline_0018
                                   1681 	.globl _ak820_outline_0036
                                   1682 	.globl _ak820_outline_0042
                                   1683 	.globl _ak820_outline_0045
                                   1684 	.globl _ak820_outline_0056
                                   1685 	.globl _ak820_outline_0057
                                   1686 	.globl _ak820_outline_0065
                                   1687 	.globl _ak820_outline_0066
                                   1688 	.globl _ak820_outline_0069
                                   1689 	.globl _ak820_outline_0077
                                   1690 	.globl _ak820_outline_0081
                                   1691 	.globl _ak820_outline_0082
                                   1692 	.globl _ak820_outline_0097
                                   1693 	.globl _ak820_outline_0098
                                   1694 	.globl _ak820_outline_0102
                                   1695 	.globl _ak820_outline_0103
                                   1696 	.globl _ak820_outline_0105
                                   1697 	.globl _ak820_outline_0106
                                   1698 	.globl _ak820_outline_0108
                                   1699 	.globl _ak820_outline_0119
                                   1700 	.globl _ak820_outline_0123
                                   1701 	.globl _ak820_outline_0124
                                   1702 	.globl _ak820_outline_0135
                                   1703 	.globl _ak820_outline_0136
                                   1704 	.globl _ak820_outline_0137
                                   1705 	.globl _ak820_outline_0142
                                   1706 	.globl _ak820_outline_0149
                                   1707 	.globl _ak820_outline_0150
                                   1708 	.globl _ak820_outline_0151
                                   1709 	.globl _ak820_outline_0159
                                   1710 	.globl _ak820_outline_0163
                                   1711 	.globl _ak820_outline_0164
                                   1712 	.globl _ak820_outline_0184
                                   1713 
                                   1714 	.area CSEG (CODE)
                                   1715 ; function ak820_outline_0013
      0042C2                       1716 _ak820_outline_0013:
      0042C2 8E 82            [24] 1717 	mov	dpl,r6
      0042C4 8F 83            [24] 1718 	mov	dph,r7
      0042C6 A3               [24] 1719 	inc	dptr
      0042C7 A3               [24] 1720 	inc	dptr
      0042C8 A3               [24] 1721 	inc	dptr
      0042C9 A3               [24] 1722 	inc	dptr
      0042CA A3               [24] 1723 	inc	dptr
      0042CB 22               [24] 1724 	ret
                                   1725 
                                   1726 	.area CSEG (CODE)
                                   1727 ; function ak820_outline_0036
      0042CC                       1728 _ak820_outline_0036:
      0042CC F0               [24] 1729 	movx	@dptr,a
      0042CD 8E 82            [24] 1730 	mov	dpl,r6
      0042CF 8F 83            [24] 1731 	mov	dph,r7
      0042D1 A3               [24] 1732 	inc	dptr
      0042D2 A3               [24] 1733 	inc	dptr
      0042D3 22               [24] 1734 	ret
                                   1735 
                                   1736 	.area CSEG (CODE)
                                   1737 ; function ak820_outline_0042
      0042D4                       1738 _ak820_outline_0042:
      0042D4 AF F0            [24] 1739 	mov	r7,b
      0042D6 AE 83            [24] 1740 	mov	r6,dph
      0042D8 E5 82            [12] 1741 	mov	a,dpl
      0042DA 22               [24] 1742 	ret
                                   1743 
                                   1744 	.area CSEG (CODE)
                                   1745 ; function ak820_outline_0045
      0042DB                       1746 _ak820_outline_0045:
      0042DB EF               [12] 1747 	mov	a,r7
      0042DC 24 71            [12] 1748 	add	a,#_ak820_nvm_flush_header_10000_62
      0042DE F5 82            [12] 1749 	mov	dpl,a
      0042E0 E4               [12] 1750 	clr	a
      0042E1 34 05            [12] 1751 	addc	a,#(_ak820_nvm_flush_header_10000_62>>8)
      0042E3 F5 83            [12] 1752 	mov	dph,a
      0042E5 E0               [24] 1753 	movx	a,@dptr
      0042E6 22               [24] 1754 	ret
                                   1755 
                                   1756 	.area CSEG (CODE)
                                   1757 ; function ak820_outline_0057
      0042E7                       1758 _ak820_outline_0057:
      0042E7 8F 06            [24] 1759 	mov	ar6,r7
      0042E9 7D 00            [12] 1760 	mov	r5,#0x00
      0042EB 74 40            [12] 1761 	mov	a,#0x40
      0042ED 2E               [12] 1762 	add	a,r6
      0042EE FE               [12] 1763 	mov	r6,a
      0042EF 74 EF            [12] 1764 	mov	a,#0xef
      0042F1 3D               [12] 1765 	addc	a,r5
      0042F2 FD               [12] 1766 	mov	r5,a
      0042F3 8E 82            [24] 1767 	mov	dpl,r6
      0042F5 8D 83            [24] 1768 	mov	dph,r5
      0042F7 22               [24] 1769 	ret
                                   1770 
                                   1771 	.area CSEG (CODE)
                                   1772 ; function ak820_outline_0066
      0042F8                       1773 _ak820_outline_0066:
      0042F8 F0               [24] 1774 	movx	@dptr,a
      0042F9 8E 82            [24] 1775 	mov	dpl,r6
      0042FB 8F 83            [24] 1776 	mov	dph,r7
      0042FD 22               [24] 1777 	ret
                                   1778 
                                   1779 	.area CSEG (CODE)
                                   1780 ; function ak820_outline_0069
      0042FE                       1781 _ak820_outline_0069:
      0042FE 8D 82            [24] 1782 	mov	dpl,r5
      004300 8E 83            [24] 1783 	mov	dph,r6
      004302 EC               [12] 1784 	mov	a,r4
      004303 F0               [24] 1785 	movx	@dptr,a
      004304 22               [24] 1786 	ret
                                   1787 
                                   1788 	.area CSEG (CODE)
                                   1789 ; function ak820_outline_0082
      004305                       1790 _ak820_outline_0082:
      004305 E0               [24] 1791 	movx	a,@dptr
      004306 FA               [12] 1792 	mov	r2,a
      004307 A3               [24] 1793 	inc	dptr
      004308 E0               [24] 1794 	movx	a,@dptr
      004309 FB               [12] 1795 	mov	r3,a
      00430A 22               [24] 1796 	ret
                                   1797 
                                   1798 	.area CSEG (CODE)
                                   1799 ; function ak820_outline_0097
      00430B                       1800 _ak820_outline_0097:
      00430B 8C 82            [24] 1801 	mov	dpl,r4
      00430D 8D 83            [24] 1802 	mov	dph,r5
      00430F E0               [24] 1803 	movx	a,@dptr
      004310 22               [24] 1804 	ret
                                   1805 
                                   1806 	.area CSEG (CODE)
                                   1807 ; function ak820_outline_0098
      004311                       1808 _ak820_outline_0098:
      004311 E0               [24] 1809 	movx	a,@dptr
      004312 FD               [12] 1810 	mov	r5,a
      004313 A3               [24] 1811 	inc	dptr
      004314 E0               [24] 1812 	movx	a,@dptr
      004315 FE               [12] 1813 	mov	r6,a
      004316 22               [24] 1814 	ret
                                   1815 
                                   1816 	.area CSEG (CODE)
                                   1817 ; function ak820_outline_0108
      004317                       1818 _ak820_outline_0108:
      004317 EF               [12] 1819 	mov	a,r7
      004318 24 19            [12] 1820 	add	a,#_page_data
      00431A F5 82            [12] 1821 	mov	dpl,a
      00431C E4               [12] 1822 	clr	a
      00431D 34 05            [12] 1823 	addc	a,#(_page_data>>8)
      00431F F5 83            [12] 1824 	mov	dph,a
      004321 E0               [24] 1825 	movx	a,@dptr
      004322 22               [24] 1826 	ret
                                   1827 
                                   1828 	.area CSEG (CODE)
                                   1829 ; function ak820_outline_0119
      004323                       1830 _ak820_outline_0119:
      004323 8E 82            [24] 1831 	mov	dpl,r6
      004325 8F 83            [24] 1832 	mov	dph,r7
      004327 22               [24] 1833 	ret
                                   1834 
                                   1835 	.area CSEG (CODE)
                                   1836 ; function ak820_outline_0135
      004328                       1837 _ak820_outline_0135:
      004328 8A 82            [24] 1838 	mov	dpl,r2
      00432A 8B 83            [24] 1839 	mov	dph,r3
      00432C 22               [24] 1840 	ret
                                   1841 
                                   1842 	.area CSEG (CODE)
                                   1843 ; function ak820_outline_0136
      00432D                       1844 _ak820_outline_0136:
      00432D AE 82            [24] 1845 	mov	r6,dpl
      00432F AF 83            [24] 1846 	mov	r7,dph
      004331 22               [24] 1847 	ret
                                   1848 
                                   1849 	.area CSEG (CODE)
                                   1850 ; function ak820_outline_0142
      004332                       1851 _ak820_outline_0142:
      004332 42 05            [12] 1852 	orl	ar5,a
      004334 EA               [12] 1853 	mov	a,r2
      004335 42 04            [12] 1854 	orl	ar4,a
      004337 22               [24] 1855 	ret
                                   1856 
                                   1857 	.area CSEG (CODE)
                                   1858 ; function ak820_outline_0150
      004338                       1859 _ak820_outline_0150:
      004338 89 82            [24] 1860 	mov	dpl,r1
      00433A 8A 83            [24] 1861 	mov	dph,r2
      00433C 22               [24] 1862 	ret
                                   1863 
                                   1864 	.area CSEG (CODE)
                                   1865 ; function ak820_outline_0151
      00433D                       1866 _ak820_outline_0151:
      00433D AC 82            [24] 1867 	mov	r4,dpl
      00433F AD 83            [24] 1868 	mov	r5,dph
      004341 22               [24] 1869 	ret
                                   1870 
                                   1871 	.area CSEG (CODE)
                                   1872 ; function ak820_outline_0159
      004342                       1873 _ak820_outline_0159:
      004342 8F 82            [24] 1874 	mov	dpl,r7
      004344 8E 83            [24] 1875 	mov	dph,r6
      004346 22               [24] 1876 	ret
                                   1877 
                                   1878 	.area CSEG (CODE)
                                   1879 ; function ak820_outline_0163
      004347                       1880 _ak820_outline_0163:
      004347 2E               [12] 1881 	add	a,r6
      004348 FC               [12] 1882 	mov	r4,a
      004349 E4               [12] 1883 	clr	a
      00434A 3F               [12] 1884 	addc	a,r7
      00434B FD               [12] 1885 	mov	r5,a
      00434C 22               [24] 1886 	ret
                                   1887 
                                   1888 	.area CSEG (CODE)
                                   1889 ; function ak820_outline_0164
      00434D                       1890 _ak820_outline_0164:
      00434D ED               [12] 1891 	mov	a,r5
      00434E F0               [24] 1892 	movx	@dptr,a
      00434F EE               [12] 1893 	mov	a,r6
      004350 A3               [24] 1894 	inc	dptr
      004351 F0               [24] 1895 	movx	@dptr,a
      004352 22               [24] 1896 	ret
                                   1897 
                                   1898 	.area CSEG (CODE)
                                   1899 ; function ak820_outline_0184
      004353                       1900 _ak820_outline_0184:
      004353 8C 82            [24] 1901 	mov	dpl,r4
      004355 8B 83            [24] 1902 	mov	dph,r3
      004357 22               [24] 1903 	ret
