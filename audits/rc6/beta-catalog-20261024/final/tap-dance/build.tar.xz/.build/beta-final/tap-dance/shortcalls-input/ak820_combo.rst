                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_combo
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _dynamic_keymap_get_combo
                                     12 	.globl _process_record
                                     13 	.globl _ADC_START
                                     14 	.globl _S0_R_FIFO
                                     15 	.globl _S0_T_FIFO
                                     16 	.globl _S0_FREE
                                     17 	.globl _S0_IF_BYTE
                                     18 	.globl _S0_IF_FIRST
                                     19 	.globl _S0_IF_OV
                                     20 	.globl _S0_FST_ACT
                                     21 	.globl _CP_RL2
                                     22 	.globl _C_T2
                                     23 	.globl _TR2
                                     24 	.globl _EXEN2
                                     25 	.globl _TCLK
                                     26 	.globl _RCLK
                                     27 	.globl _EXF2
                                     28 	.globl _CAP1F
                                     29 	.globl _TF2
                                     30 	.globl _RI
                                     31 	.globl _TI
                                     32 	.globl _RB8
                                     33 	.globl _TB8
                                     34 	.globl _REN
                                     35 	.globl _SM2
                                     36 	.globl _SM1
                                     37 	.globl _SM0
                                     38 	.globl _IT0
                                     39 	.globl _IE0
                                     40 	.globl _IT1
                                     41 	.globl _IE1
                                     42 	.globl _TR0
                                     43 	.globl _TF0
                                     44 	.globl _TR1
                                     45 	.globl _TF1
                                     46 	.globl _P4_0
                                     47 	.globl _P4_1
                                     48 	.globl _P4_2
                                     49 	.globl _P4_3
                                     50 	.globl _P4_4
                                     51 	.globl _P4_5
                                     52 	.globl _P4_6
                                     53 	.globl _RXD
                                     54 	.globl _TXD
                                     55 	.globl _INT0
                                     56 	.globl _INT1
                                     57 	.globl _T0
                                     58 	.globl _T1
                                     59 	.globl _MOSI1
                                     60 	.globl _MISO1
                                     61 	.globl _SCK1
                                     62 	.globl _P3_0
                                     63 	.globl _P3_1
                                     64 	.globl _P3_2
                                     65 	.globl _P3_3
                                     66 	.globl _P3_4
                                     67 	.globl _P3_5
                                     68 	.globl _P3_6
                                     69 	.globl _P3_7
                                     70 	.globl _CAP1_
                                     71 	.globl _T2_
                                     72 	.globl _CAP2_
                                     73 	.globl _T2EX_
                                     74 	.globl _RXD1
                                     75 	.globl _TXD1
                                     76 	.globl _P2_0
                                     77 	.globl _P2_1
                                     78 	.globl _P2_2
                                     79 	.globl _P2_3
                                     80 	.globl _P2_4
                                     81 	.globl _P2_5
                                     82 	.globl _P2_6
                                     83 	.globl _P2_7
                                     84 	.globl _AIN0
                                     85 	.globl _AIN1
                                     86 	.globl _AIN2
                                     87 	.globl _AIN3
                                     88 	.globl _AIN4
                                     89 	.globl _AIN5
                                     90 	.globl _AIN6
                                     91 	.globl _AIN7
                                     92 	.globl _CAP1
                                     93 	.globl _T2
                                     94 	.globl _CAP2
                                     95 	.globl _T2EX
                                     96 	.globl _INT0_
                                     97 	.globl _SCS
                                     98 	.globl _MOSI
                                     99 	.globl _MISO
                                    100 	.globl _SCK
                                    101 	.globl _RXD1_
                                    102 	.globl _TXD1_
                                    103 	.globl _P1_0
                                    104 	.globl _P1_1
                                    105 	.globl _P1_2
                                    106 	.globl _P1_3
                                    107 	.globl _P1_4
                                    108 	.globl _P1_5
                                    109 	.globl _P1_6
                                    110 	.globl _P1_7
                                    111 	.globl _AIN8
                                    112 	.globl _AIN9
                                    113 	.globl _AIN10
                                    114 	.globl _AIN11
                                    115 	.globl _AIN12
                                    116 	.globl _AIN13
                                    117 	.globl _RXD_
                                    118 	.globl _TXD_
                                    119 	.globl _SCL0
                                    120 	.globl _SDA0
                                    121 	.globl _P0_0
                                    122 	.globl _P0_1
                                    123 	.globl _P0_2
                                    124 	.globl _P0_3
                                    125 	.globl _P0_4
                                    126 	.globl _P0_5
                                    127 	.globl _P0_6
                                    128 	.globl _P0_7
                                    129 	.globl _IE_SPI0
                                    130 	.globl _IE_USB
                                    131 	.globl _IE_ADC
                                    132 	.globl _IE_UART1
                                    133 	.globl _IE_PWM_I2C
                                    134 	.globl _IE_GPIO
                                    135 	.globl _IE_WDOG
                                    136 	.globl _PX0
                                    137 	.globl _PT0
                                    138 	.globl _PX1
                                    139 	.globl _PT1
                                    140 	.globl _PS
                                    141 	.globl _PT2
                                    142 	.globl _PL_FLAG
                                    143 	.globl _PH_FLAG
                                    144 	.globl _EX0
                                    145 	.globl _ET0
                                    146 	.globl _EX1
                                    147 	.globl _ET1
                                    148 	.globl _ES
                                    149 	.globl _ET2
                                    150 	.globl _E_DIS
                                    151 	.globl _EA
                                    152 	.globl _P
                                    153 	.globl _F1
                                    154 	.globl _OV
                                    155 	.globl _RS0
                                    156 	.globl _RS1
                                    157 	.globl _F0
                                    158 	.globl _AC
                                    159 	.globl _CY
                                    160 	.globl _I2CS_INT_ST
                                    161 	.globl _I2CX_INT
                                    162 	.globl _LED_STATUS
                                    163 	.globl _LED_DMA_H
                                    164 	.globl _LED_DMA_L
                                    165 	.globl _LED_DMA
                                    166 	.globl _LED_PWM_OE
                                    167 	.globl _LED_COMMON
                                    168 	.globl _ADC_CHAN
                                    169 	.globl _ADC_DAT_H
                                    170 	.globl _ADC_DAT_L
                                    171 	.globl _ADC_DAT
                                    172 	.globl _ADC_CTRL
                                    173 	.globl _SPI1_CK_SE
                                    174 	.globl _SPI1_CTRL
                                    175 	.globl _SPI1_DATA
                                    176 	.globl _SPI1_STAT
                                    177 	.globl _SIF1
                                    178 	.globl _SBAUD1
                                    179 	.globl _SBUF1
                                    180 	.globl _SCON1
                                    181 	.globl _SPI0_SETUP
                                    182 	.globl _SPI0_CK_SE
                                    183 	.globl _SPI0_CTRL
                                    184 	.globl _SPI0_DATA
                                    185 	.globl _SPI0_STAT
                                    186 	.globl _T2CAP1H
                                    187 	.globl _T2CAP1L
                                    188 	.globl _T2CAP1
                                    189 	.globl _TH2
                                    190 	.globl _TL2
                                    191 	.globl _T2COUNT
                                    192 	.globl _RCAP2H
                                    193 	.globl _RCAP2L
                                    194 	.globl _RCAP2
                                    195 	.globl _T2MOD
                                    196 	.globl _T2CON
                                    197 	.globl _SBUF
                                    198 	.globl _SCON
                                    199 	.globl _TH1
                                    200 	.globl _TH0
                                    201 	.globl _TL1
                                    202 	.globl _TL0
                                    203 	.globl _TMOD
                                    204 	.globl _TCON
                                    205 	.globl _XBUS_AUX
                                    206 	.globl _P7
                                    207 	.globl _P6_DIR
                                    208 	.globl _P6_OUT_PU
                                    209 	.globl _P6_IN
                                    210 	.globl _P5_DIR
                                    211 	.globl _P5_OUT_PU
                                    212 	.globl _P5_IN
                                    213 	.globl _P4_LED_KEY
                                    214 	.globl _P4_DIR_PU
                                    215 	.globl _P4_MOD_OC
                                    216 	.globl _P4
                                    217 	.globl _P3_DIR_PU
                                    218 	.globl _P3_MOD_OC
                                    219 	.globl _P3
                                    220 	.globl _P2_DIR_PU
                                    221 	.globl _P2_MOD_OC
                                    222 	.globl _P2
                                    223 	.globl _P1_DIR_PU
                                    224 	.globl _P1_MOD_OC
                                    225 	.globl _P1
                                    226 	.globl _P0_DIR_PU
                                    227 	.globl _P0_MOD_OC
                                    228 	.globl _P0
                                    229 	.globl _ROM_CTRL
                                    230 	.globl _ROM_DATA_HH
                                    231 	.globl _ROM_DATA_HL
                                    232 	.globl _ROM_DATA_HI
                                    233 	.globl _ROM_ADDR_H
                                    234 	.globl _ROM_ADDR_L
                                    235 	.globl _ROM_ADDR
                                    236 	.globl _GPIO_IE
                                    237 	.globl _IP_EX
                                    238 	.globl _IE_EX
                                    239 	.globl _IP
                                    240 	.globl _IE
                                    241 	.globl _WDOG_COUNT
                                    242 	.globl _RESET_KEEP
                                    243 	.globl _WAKE_CTRL
                                    244 	.globl _CLOCK_CFG
                                    245 	.globl _POWER_CFG
                                    246 	.globl _PCON
                                    247 	.globl _GLOBAL_CFG
                                    248 	.globl _SAFE_MOD
                                    249 	.globl _DPH
                                    250 	.globl _DPL
                                    251 	.globl _SP
                                    252 	.globl _A_INV
                                    253 	.globl _B
                                    254 	.globl _ACC
                                    255 	.globl _PSW
                                    256 	.globl _ak820_combo_valid
                                    257 	.globl _ak820_combo_cancel
                                    258 	.globl _ak820_combo_reload
                                    259 	.globl _ak820_combo_tick
                                    260 	.globl _ak820_combo_process
                                    261 ;--------------------------------------------------------
                                    262 ; special function registers
                                    263 ;--------------------------------------------------------
                                    264 	.area RSEG    (ABS,DATA)
      000000                        265 	.org 0x0000
                           0000D0   266 _PSW	=	0x00d0
                           0000E0   267 _ACC	=	0x00e0
                           0000F0   268 _B	=	0x00f0
                           0000FD   269 _A_INV	=	0x00fd
                           000081   270 _SP	=	0x0081
                           000082   271 _DPL	=	0x0082
                           000083   272 _DPH	=	0x0083
                           0000A1   273 _SAFE_MOD	=	0x00a1
                           0000B1   274 _GLOBAL_CFG	=	0x00b1
                           000087   275 _PCON	=	0x0087
                           0000BA   276 _POWER_CFG	=	0x00ba
                           0000B9   277 _CLOCK_CFG	=	0x00b9
                           0000A9   278 _WAKE_CTRL	=	0x00a9
                           0000FE   279 _RESET_KEEP	=	0x00fe
                           0000FF   280 _WDOG_COUNT	=	0x00ff
                           0000A8   281 _IE	=	0x00a8
                           0000B8   282 _IP	=	0x00b8
                           0000E8   283 _IE_EX	=	0x00e8
                           0000E9   284 _IP_EX	=	0x00e9
                           0000B2   285 _GPIO_IE	=	0x00b2
                           008584   286 _ROM_ADDR	=	0x8584
                           000084   287 _ROM_ADDR_L	=	0x0084
                           000085   288 _ROM_ADDR_H	=	0x0085
                           008F8E   289 _ROM_DATA_HI	=	0x8f8e
                           00008E   290 _ROM_DATA_HL	=	0x008e
                           00008F   291 _ROM_DATA_HH	=	0x008f
                           000086   292 _ROM_CTRL	=	0x0086
                           000080   293 _P0	=	0x0080
                           0000C4   294 _P0_MOD_OC	=	0x00c4
                           0000C5   295 _P0_DIR_PU	=	0x00c5
                           000090   296 _P1	=	0x0090
                           000092   297 _P1_MOD_OC	=	0x0092
                           000093   298 _P1_DIR_PU	=	0x0093
                           0000A0   299 _P2	=	0x00a0
                           000094   300 _P2_MOD_OC	=	0x0094
                           000095   301 _P2_DIR_PU	=	0x0095
                           0000B0   302 _P3	=	0x00b0
                           000096   303 _P3_MOD_OC	=	0x0096
                           000097   304 _P3_DIR_PU	=	0x0097
                           0000C0   305 _P4	=	0x00c0
                           0000C2   306 _P4_MOD_OC	=	0x00c2
                           0000C3   307 _P4_DIR_PU	=	0x00c3
                           0000C1   308 _P4_LED_KEY	=	0x00c1
                           0000AA   309 _P5_IN	=	0x00aa
                           0000AB   310 _P5_OUT_PU	=	0x00ab
                           0000AC   311 _P5_DIR	=	0x00ac
                           0000AD   312 _P6_IN	=	0x00ad
                           0000AE   313 _P6_OUT_PU	=	0x00ae
                           0000AF   314 _P6_DIR	=	0x00af
                           0000F1   315 _P7	=	0x00f1
                           0000A2   316 _XBUS_AUX	=	0x00a2
                           000088   317 _TCON	=	0x0088
                           000089   318 _TMOD	=	0x0089
                           00008A   319 _TL0	=	0x008a
                           00008B   320 _TL1	=	0x008b
                           00008C   321 _TH0	=	0x008c
                           00008D   322 _TH1	=	0x008d
                           000098   323 _SCON	=	0x0098
                           000099   324 _SBUF	=	0x0099
                           0000C8   325 _T2CON	=	0x00c8
                           0000C9   326 _T2MOD	=	0x00c9
                           00CBCA   327 _RCAP2	=	0xcbca
                           0000CA   328 _RCAP2L	=	0x00ca
                           0000CB   329 _RCAP2H	=	0x00cb
                           00CDCC   330 _T2COUNT	=	0xcdcc
                           0000CC   331 _TL2	=	0x00cc
                           0000CD   332 _TH2	=	0x00cd
                           00CFCE   333 _T2CAP1	=	0xcfce
                           0000CE   334 _T2CAP1L	=	0x00ce
                           0000CF   335 _T2CAP1H	=	0x00cf
                           0000F8   336 _SPI0_STAT	=	0x00f8
                           0000F9   337 _SPI0_DATA	=	0x00f9
                           0000FA   338 _SPI0_CTRL	=	0x00fa
                           0000FB   339 _SPI0_CK_SE	=	0x00fb
                           0000FC   340 _SPI0_SETUP	=	0x00fc
                           0000BC   341 _SCON1	=	0x00bc
                           0000BD   342 _SBUF1	=	0x00bd
                           0000BE   343 _SBAUD1	=	0x00be
                           0000BF   344 _SIF1	=	0x00bf
                           0000B4   345 _SPI1_STAT	=	0x00b4
                           0000B5   346 _SPI1_DATA	=	0x00b5
                           0000B6   347 _SPI1_CTRL	=	0x00b6
                           0000B7   348 _SPI1_CK_SE	=	0x00b7
                           0000F3   349 _ADC_CTRL	=	0x00f3
                           00F5F4   350 _ADC_DAT	=	0xf5f4
                           0000F4   351 _ADC_DAT_L	=	0x00f4
                           0000F5   352 _ADC_DAT_H	=	0x00f5
                           0000F6   353 _ADC_CHAN	=	0x00f6
                           0000A6   354 _LED_COMMON	=	0x00a6
                           0000A7   355 _LED_PWM_OE	=	0x00a7
                           00C7C6   356 _LED_DMA	=	0xc7c6
                           0000C6   357 _LED_DMA_L	=	0x00c6
                           0000C7   358 _LED_DMA_H	=	0x00c7
                           0000F7   359 _LED_STATUS	=	0x00f7
                           0000B3   360 _I2CX_INT	=	0x00b3
                           0000BB   361 _I2CS_INT_ST	=	0x00bb
                                    362 ;--------------------------------------------------------
                                    363 ; special function bits
                                    364 ;--------------------------------------------------------
                                    365 	.area RSEG    (ABS,DATA)
      000000                        366 	.org 0x0000
                           0000D7   367 _CY	=	0x00d7
                           0000D6   368 _AC	=	0x00d6
                           0000D5   369 _F0	=	0x00d5
                           0000D4   370 _RS1	=	0x00d4
                           0000D3   371 _RS0	=	0x00d3
                           0000D2   372 _OV	=	0x00d2
                           0000D1   373 _F1	=	0x00d1
                           0000D0   374 _P	=	0x00d0
                           0000AF   375 _EA	=	0x00af
                           0000AE   376 _E_DIS	=	0x00ae
                           0000AD   377 _ET2	=	0x00ad
                           0000AC   378 _ES	=	0x00ac
                           0000AB   379 _ET1	=	0x00ab
                           0000AA   380 _EX1	=	0x00aa
                           0000A9   381 _ET0	=	0x00a9
                           0000A8   382 _EX0	=	0x00a8
                           0000BF   383 _PH_FLAG	=	0x00bf
                           0000BE   384 _PL_FLAG	=	0x00be
                           0000BD   385 _PT2	=	0x00bd
                           0000BC   386 _PS	=	0x00bc
                           0000BB   387 _PT1	=	0x00bb
                           0000BA   388 _PX1	=	0x00ba
                           0000B9   389 _PT0	=	0x00b9
                           0000B8   390 _PX0	=	0x00b8
                           0000EF   391 _IE_WDOG	=	0x00ef
                           0000EE   392 _IE_GPIO	=	0x00ee
                           0000ED   393 _IE_PWM_I2C	=	0x00ed
                           0000EC   394 _IE_UART1	=	0x00ec
                           0000EB   395 _IE_ADC	=	0x00eb
                           0000E9   396 _IE_USB	=	0x00e9
                           0000E8   397 _IE_SPI0	=	0x00e8
                           000087   398 _P0_7	=	0x0087
                           000086   399 _P0_6	=	0x0086
                           000085   400 _P0_5	=	0x0085
                           000084   401 _P0_4	=	0x0084
                           000083   402 _P0_3	=	0x0083
                           000082   403 _P0_2	=	0x0082
                           000081   404 _P0_1	=	0x0081
                           000080   405 _P0_0	=	0x0080
                           000081   406 _SDA0	=	0x0081
                           000080   407 _SCL0	=	0x0080
                           000083   408 _TXD_	=	0x0083
                           000082   409 _RXD_	=	0x0082
                           000085   410 _AIN13	=	0x0085
                           000084   411 _AIN12	=	0x0084
                           000083   412 _AIN11	=	0x0083
                           000082   413 _AIN10	=	0x0082
                           000081   414 _AIN9	=	0x0081
                           000080   415 _AIN8	=	0x0080
                           000097   416 _P1_7	=	0x0097
                           000096   417 _P1_6	=	0x0096
                           000095   418 _P1_5	=	0x0095
                           000094   419 _P1_4	=	0x0094
                           000093   420 _P1_3	=	0x0093
                           000092   421 _P1_2	=	0x0092
                           000091   422 _P1_1	=	0x0091
                           000090   423 _P1_0	=	0x0090
                           000097   424 _TXD1_	=	0x0097
                           000096   425 _RXD1_	=	0x0096
                           000097   426 _SCK	=	0x0097
                           000096   427 _MISO	=	0x0096
                           000095   428 _MOSI	=	0x0095
                           000094   429 _SCS	=	0x0094
                           000092   430 _INT0_	=	0x0092
                           000091   431 _T2EX	=	0x0091
                           000091   432 _CAP2	=	0x0091
                           000090   433 _T2	=	0x0090
                           000090   434 _CAP1	=	0x0090
                           000097   435 _AIN7	=	0x0097
                           000096   436 _AIN6	=	0x0096
                           000095   437 _AIN5	=	0x0095
                           000094   438 _AIN4	=	0x0094
                           000093   439 _AIN3	=	0x0093
                           000092   440 _AIN2	=	0x0092
                           000091   441 _AIN1	=	0x0091
                           000090   442 _AIN0	=	0x0090
                           0000A7   443 _P2_7	=	0x00a7
                           0000A6   444 _P2_6	=	0x00a6
                           0000A5   445 _P2_5	=	0x00a5
                           0000A4   446 _P2_4	=	0x00a4
                           0000A3   447 _P2_3	=	0x00a3
                           0000A2   448 _P2_2	=	0x00a2
                           0000A1   449 _P2_1	=	0x00a1
                           0000A0   450 _P2_0	=	0x00a0
                           0000A7   451 _TXD1	=	0x00a7
                           0000A6   452 _RXD1	=	0x00a6
                           0000A5   453 _T2EX_	=	0x00a5
                           0000A5   454 _CAP2_	=	0x00a5
                           0000A4   455 _T2_	=	0x00a4
                           0000A4   456 _CAP1_	=	0x00a4
                           0000B7   457 _P3_7	=	0x00b7
                           0000B6   458 _P3_6	=	0x00b6
                           0000B5   459 _P3_5	=	0x00b5
                           0000B4   460 _P3_4	=	0x00b4
                           0000B3   461 _P3_3	=	0x00b3
                           0000B2   462 _P3_2	=	0x00b2
                           0000B1   463 _P3_1	=	0x00b1
                           0000B0   464 _P3_0	=	0x00b0
                           0000B7   465 _SCK1	=	0x00b7
                           0000B6   466 _MISO1	=	0x00b6
                           0000B5   467 _MOSI1	=	0x00b5
                           0000B5   468 _T1	=	0x00b5
                           0000B4   469 _T0	=	0x00b4
                           0000B3   470 _INT1	=	0x00b3
                           0000B2   471 _INT0	=	0x00b2
                           0000B1   472 _TXD	=	0x00b1
                           0000B0   473 _RXD	=	0x00b0
                           0000C6   474 _P4_6	=	0x00c6
                           0000C5   475 _P4_5	=	0x00c5
                           0000C4   476 _P4_4	=	0x00c4
                           0000C3   477 _P4_3	=	0x00c3
                           0000C2   478 _P4_2	=	0x00c2
                           0000C1   479 _P4_1	=	0x00c1
                           0000C0   480 _P4_0	=	0x00c0
                           00008F   481 _TF1	=	0x008f
                           00008E   482 _TR1	=	0x008e
                           00008D   483 _TF0	=	0x008d
                           00008C   484 _TR0	=	0x008c
                           00008B   485 _IE1	=	0x008b
                           00008A   486 _IT1	=	0x008a
                           000089   487 _IE0	=	0x0089
                           000088   488 _IT0	=	0x0088
                           00009F   489 _SM0	=	0x009f
                           00009E   490 _SM1	=	0x009e
                           00009D   491 _SM2	=	0x009d
                           00009C   492 _REN	=	0x009c
                           00009B   493 _TB8	=	0x009b
                           00009A   494 _RB8	=	0x009a
                           000099   495 _TI	=	0x0099
                           000098   496 _RI	=	0x0098
                           0000CF   497 _TF2	=	0x00cf
                           0000CF   498 _CAP1F	=	0x00cf
                           0000CE   499 _EXF2	=	0x00ce
                           0000CD   500 _RCLK	=	0x00cd
                           0000CC   501 _TCLK	=	0x00cc
                           0000CB   502 _EXEN2	=	0x00cb
                           0000CA   503 _TR2	=	0x00ca
                           0000C9   504 _C_T2	=	0x00c9
                           0000C8   505 _CP_RL2	=	0x00c8
                           0000FF   506 _S0_FST_ACT	=	0x00ff
                           0000FE   507 _S0_IF_OV	=	0x00fe
                           0000FD   508 _S0_IF_FIRST	=	0x00fd
                           0000FC   509 _S0_IF_BYTE	=	0x00fc
                           0000FB   510 _S0_FREE	=	0x00fb
                           0000FA   511 _S0_T_FIFO	=	0x00fa
                           0000F8   512 _S0_R_FIFO	=	0x00f8
                           0000F7   513 _ADC_START	=	0x00f7
                                    514 ;--------------------------------------------------------
                                    515 ; overlayable register banks
                                    516 ;--------------------------------------------------------
                                    517 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        518 	.ds 8
                                    519 ;--------------------------------------------------------
                                    520 ; internal ram data
                                    521 ;--------------------------------------------------------
                                    522 	.area DSEG    (DATA)
                                    523 ;--------------------------------------------------------
                                    524 ; overlayable items in internal ram
                                    525 ;--------------------------------------------------------
                                    526 ;--------------------------------------------------------
                                    527 ; indirectly addressable internal ram data
                                    528 ;--------------------------------------------------------
                                    529 	.area ISEG    (DATA)
                                    530 ;--------------------------------------------------------
                                    531 ; absolute internal ram data
                                    532 ;--------------------------------------------------------
                                    533 	.area IABS    (ABS,DATA)
                                    534 	.area IABS    (ABS,DATA)
                                    535 ;--------------------------------------------------------
                                    536 ; bit data
                                    537 ;--------------------------------------------------------
                                    538 	.area BSEG    (BIT)
      000000                        539 _ak820_combo_valid_sloc0_1_0:
      000000                        540 	.ds 1
      000001                        541 _ak820_combo_process_sloc0_1_0:
      000001                        542 	.ds 1
                                    543 ;--------------------------------------------------------
                                    544 ; paged external ram data
                                    545 ;--------------------------------------------------------
                                    546 	.area PSEG    (PAG,XDATA)
                                    547 ;--------------------------------------------------------
                                    548 ; uninitialized external ram data
                                    549 ;--------------------------------------------------------
                                    550 	.area XSEG    (XDATA)
      000422                        551 _combos:
      000422                        552 	.ds 32
      000442                        553 _saved:
      000442                        554 	.ds 9
      00044B                        555 _active:
      00044B                        556 	.ds 1
      00044C                        557 _ak820_combo_valid_entry_10000_594:
      00044C                        558 	.ds 2
      00044E                        559 _ak820_combo_reload_entry_30000_606:
      00044E                        560 	.ds 10
      000458                        561 _ak820_combo_tick_now_10000_611:
      000458                        562 	.ds 2
      00045A                        563 _ak820_combo_process_record_10000_614:
      00045A                        564 	.ds 2
      00045C                        565 _ak820_combo_process_eligible_10001_629:
      00045C                        566 	.ds 1
      00045D                        567 _ak820_combo_process_i_40001_632:
      00045D                        568 	.ds 1
      00045E                        569 _ak820_combo_process_a_50001_633:
      00045E                        570 	.ds 1
      00045F                        571 _ak820_combo_process_b_50001_633:
      00045F                        572 	.ds 1
                                    573 ;--------------------------------------------------------
                                    574 ; absolute external ram data
                                    575 ;--------------------------------------------------------
                                    576 	.area XABS    (ABS,XDATA)
                                    577 ;--------------------------------------------------------
                                    578 ; initialized external ram data
                                    579 ;--------------------------------------------------------
                                    580 	.area XISEG   (XDATA)
      000E6E                        581 _first:
      000E6E                        582 	.ds 1
      000E6F                        583 _second:
      000E6F                        584 	.ds 1
                                    585 	.area HOME    (CODE)
                                    586 	.area GSINIT0 (CODE)
                                    587 	.area GSINIT1 (CODE)
                                    588 	.area GSINIT2 (CODE)
                                    589 	.area GSINIT3 (CODE)
                                    590 	.area GSINIT4 (CODE)
                                    591 	.area GSINIT5 (CODE)
                                    592 	.area GSINIT  (CODE)
                                    593 	.area GSFINAL (CODE)
                                    594 	.area CSEG    (CODE)
                                    595 ;--------------------------------------------------------
                                    596 ; global & static initialisations
                                    597 ;--------------------------------------------------------
                                    598 	.area HOME    (CODE)
                                    599 	.area GSINIT  (CODE)
                                    600 	.area GSFINAL (CODE)
                                    601 	.area GSINIT  (CODE)
                                    602 ;--------------------------------------------------------
                                    603 ; Home
                                    604 ;--------------------------------------------------------
                                    605 	.area HOME    (CODE)
                                    606 	.area HOME    (CODE)
                                    607 ;--------------------------------------------------------
                                    608 ; code
                                    609 ;--------------------------------------------------------
                                    610 	.area CSEG    (CODE)
                                    611 ;------------------------------------------------------------
                                    612 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    613 ;------------------------------------------------------------
                                    614 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    615 ;------------------------------------------------------------
                                    616 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    617 ;	-----------------------------------------
                           000007   618 	ar7 = 0x07
                           000006   619 	ar6 = 0x06
                           000005   620 	ar5 = 0x05
                           000004   621 	ar4 = 0x04
                           000003   622 	ar3 = 0x03
                           000002   623 	ar2 = 0x02
                           000001   624 	ar1 = 0x01
                           000000   625 	ar0 = 0x00
                                    626 ;	 function ak820_combo_valid
                                    627 ;	-----------------------------------------
      003468                        628 _ak820_combo_valid:
      003468 12 38 55         [24]  629 	lcall	_ak820_outline_0106
      00346B 90 04 4C         [24]  630 	mov	dptr,#_ak820_combo_valid_entry_10000_594
      00346E 12 38 50         [24]  631 	lcall	_ak820_outline_0105
                                    632 ;	keyboards/ajazz/ak820/ak820_combo.c:24: if (entry->input[2] || entry->input[3]) return false;
      003471 90 04 4C         [24]  633 	mov	dptr,#_ak820_combo_valid_entry_10000_594
      003474 12 37 B1         [24]  634 	lcall	_ak820_outline_0005
      003477 A3               [24]  635 	inc	dptr
      003478 A3               [24]  636 	inc	dptr
      003479 A3               [24]  637 	inc	dptr
      00347A A3               [24]  638 	inc	dptr
      00347B 12 38 84         [24]  639 	lcall	_ak820_outline_0172
      00347E 70 0B            [24]  640 	jnz	00101$
      003480 74 06            [12]  641 	mov	a,#0x06
      003482 12 37 DF         [24]  642 	lcall	_ak820_outline_0017
      003485 FC               [12]  643 	mov	r4,a
      003486 A3               [24]  644 	inc	dptr
      003487 E0               [24]  645 	movx	a,@dptr
      003488 4C               [12]  646 	orl	a,r4
      003489 60 04            [24]  647 	jz	00102$
      00348B                        648 00101$:
      00348B 75 82 00         [24]  649 	mov	dpl, #0x00
      00348E 22               [24]  650 	ret
      00348F                        651 00102$:
                                    652 ;	keyboards/ajazz/ak820/ak820_combo.c:25: if (!(entry->input[0] | entry->input[1])) return !entry->output;
      00348F 8E 04            [24]  653 	mov	ar4,r6
      003491 8F 05            [24]  654 	mov	ar5,r7
      003493 12 37 F0         [24]  655 	lcall	_ak820_outline_0034
      003496 FA               [12]  656 	mov	r2,a
      003497 A3               [24]  657 	inc	dptr
      003498 E0               [24]  658 	movx	a,@dptr
      003499 FB               [12]  659 	mov	r3,a
      00349A 12 38 5A         [24]  660 	lcall	_ak820_outline_0123
      00349D 12 38 1F         [24]  661 	lcall	_ak820_outline_0065
      0034A0 EA               [12]  662 	mov	a,r2
      0034A1 4C               [12]  663 	orl	a,r4
      0034A2 F8               [12]  664 	mov	r0,a
      0034A3 EB               [12]  665 	mov	a,r3
      0034A4 4D               [12]  666 	orl	a,r5
      0034A5 48               [12]  667 	orl	a,r0
      0034A6 70 12            [24]  668 	jnz	00105$
      0034A8 74 08            [12]  669 	mov	a,#0x08
      0034AA 12 37 DF         [24]  670 	lcall	_ak820_outline_0017
      0034AD F8               [12]  671 	mov	r0,a
      0034AE A3               [24]  672 	inc	dptr
      0034AF E0               [24]  673 	movx	a,@dptr
      0034B0 48               [12]  674 	orl	a,r0
      0034B1 B4 01 00         [24]  675 	cjne	a,#0x01,00187$
      0034B4                        676 00187$:
      0034B4 92 00            [24]  677 	mov  _ak820_combo_valid_sloc0_1_0,c
      0034B6 12 38 6F         [24]  678 	lcall	_ak820_outline_0149
      0034B9 22               [24]  679 	ret
      0034BA                        680 00105$:
                                    681 ;	keyboards/ajazz/ak820/ak820_combo.c:26: if (entry->input[0] == entry->input[1]) return false;
      0034BA EC               [12]  682 	mov	a,r4
      0034BB B5 02 08         [24]  683 	cjne	a,ar2,00107$
      0034BE ED               [12]  684 	mov	a,r5
      0034BF B5 03 04         [24]  685 	cjne	a,ar3,00107$
      0034C2 75 82 00         [24]  686 	mov	dpl, #0x00
      0034C5 22               [24]  687 	ret
      0034C6                        688 00107$:
                                    689 ;	keyboards/ajazz/ak820/ak820_combo.c:27: if (!COMBO_INPUT(entry->input[0])) return false;
      0034C6 C3               [12]  690 	clr	c
      0034C7 EC               [12]  691 	mov	a,r4
      0034C8 94 04            [12]  692 	subb	a,#0x04
      0034CA ED               [12]  693 	mov	a,r5
      0034CB 94 00            [12]  694 	subb	a,#0x00
      0034CD 40 07            [24]  695 	jc	00108$
      0034CF 74 A4            [12]  696 	mov	a,#0xa4
      0034D1 9C               [12]  697 	subb	a,r4
      0034D2 E4               [12]  698 	clr	a
      0034D3 9D               [12]  699 	subb	a,r5
      0034D4 50 04            [24]  700 	jnc	00109$
                                    701 ;	free result
      0034D6                        702 00108$:
      0034D6 75 82 00         [24]  703 	mov	dpl, #0x00
      0034D9 22               [24]  704 	ret
      0034DA                        705 00109$:
                                    706 ;	keyboards/ajazz/ak820/ak820_combo.c:28: if (!COMBO_INPUT(entry->input[1])) return false;
      0034DA C3               [12]  707 	clr	c
      0034DB EA               [12]  708 	mov	a,r2
      0034DC 94 04            [12]  709 	subb	a,#0x04
      0034DE EB               [12]  710 	mov	a,r3
      0034DF 94 00            [12]  711 	subb	a,#0x00
      0034E1 40 07            [24]  712 	jc	00111$
      0034E3 74 A4            [12]  713 	mov	a,#0xa4
      0034E5 9A               [12]  714 	subb	a,r2
      0034E6 E4               [12]  715 	clr	a
      0034E7 9B               [12]  716 	subb	a,r3
      0034E8 50 04            [24]  717 	jnc	00112$
                                    718 ;	free result
      0034EA                        719 00111$:
      0034EA 75 82 00         [24]  720 	mov	dpl, #0x00
      0034ED 22               [24]  721 	ret
      0034EE                        722 00112$:
                                    723 ;	keyboards/ajazz/ak820/ak820_combo.c:29: return COMBO_OUTPUT(entry->output);
      0034EE 74 08            [12]  724 	mov	a,#0x08
      0034F0 12 37 F8         [24]  725 	lcall	_ak820_outline_0035
      0034F3 12 37 CB         [24]  726 	lcall	_ak820_outline_0010
      0034F6 74 E0            [12]  727 	mov	a,#0x100 - 0x20
      0034F8 2D               [12]  728 	add	a,r5
      0034F9 40 20            [24]  729 	jc	00116$
      0034FB BE 04 00         [24]  730 	cjne	r6,#0x04,00195$
      0034FE                        731 00195$:
      0034FE 40 05            [24]  732 	jc	00124$
      003500 EE               [12]  733 	mov	a,r6
      003501 24 5B            [12]  734 	add	a,#0xff - 0xa4
      003503 50 1A            [24]  735 	jnc	00117$
                                    736 ;	free result
      003505                        737 00124$:
      003505 90 04 4C         [24]  738 	mov	dptr,#_ak820_combo_valid_entry_10000_594
      003508 12 38 00         [24]  739 	lcall	_ak820_outline_0056
      00350B 74 08            [12]  740 	mov	a,#0x08
      00350D 12 37 DF         [24]  741 	lcall	_ak820_outline_0017
      003510 FF               [12]  742 	mov	r7,a
      003511 BF E0 00         [24]  743 	cjne	r7,#0xe0,00198$
      003514                        744 00198$:
      003514 40 05            [24]  745 	jc	00116$
      003516 EF               [12]  746 	mov	a,r7
      003517 24 18            [12]  747 	add	a,#0xff - 0xe7
      003519 50 04            [24]  748 	jnc	00117$
                                    749 ;	free result
      00351B                        750 00116$:
                                    751 ;	assignBit
      00351B C2 00            [12]  752 	clr	_ak820_combo_valid_sloc0_1_0
      00351D 80 02            [24]  753 	sjmp	00118$
      00351F                        754 00117$:
                                    755 ;	assignBit
      00351F D2 00            [12]  756 	setb	_ak820_combo_valid_sloc0_1_0
      003521                        757 00118$:
      003521 A2 00            [12]  758 	mov	c,_ak820_combo_valid_sloc0_1_0
      003523 12 38 6F         [24]  759 	lcall	_ak820_outline_0149
                                    760 ;	keyboards/ajazz/ak820/ak820_combo.c:30: }
      003526 22               [24]  761 	ret
                                    762 ;------------------------------------------------------------
                                    763 ;Allocation info for local variables in function 'ak820_combo_cancel'
                                    764 ;------------------------------------------------------------
                                    765 ;	keyboards/ajazz/ak820/ak820_combo.c:33: void ak820_combo_cancel(void) { first = second = NONE; active = false; }
                                    766 ;	-----------------------------------------
                                    767 ;	 function ak820_combo_cancel
                                    768 ;	-----------------------------------------
      003527                        769 _ak820_combo_cancel:
      003527 90 0E 6F         [24]  770 	mov	dptr,#_second
      00352A 74 FF            [12]  771 	mov	a,#0xff
      00352C F0               [24]  772 	movx	@dptr,a
      00352D 90 0E 6E         [24]  773 	mov	dptr,#_first
      003530 F0               [24]  774 	movx	@dptr,a
      003531 90 04 4B         [24]  775 	mov	dptr,#_active
      003534 E4               [12]  776 	clr	a
      003535 F0               [24]  777 	movx	@dptr,a
      003536 22               [24]  778 	ret
                                    779 ;------------------------------------------------------------
                                    780 ;Allocation info for local variables in function 'ak820_combo_reload'
                                    781 ;------------------------------------------------------------
                                    782 ;i             Allocated with name '_ak820_combo_reload_i_20000_605'
                                    783 ;entry         Allocated with name '_ak820_combo_reload_entry_30000_606'
                                    784 ;------------------------------------------------------------
                                    785 ;	keyboards/ajazz/ak820/ak820_combo.c:34: void ak820_combo_reload(void) {
                                    786 ;	-----------------------------------------
                                    787 ;	 function ak820_combo_reload
                                    788 ;	-----------------------------------------
      003537                        789 _ak820_combo_reload:
                                    790 ;	keyboards/ajazz/ak820/ak820_combo.c:35: for (uint8_t i = 0; i < VIAL_COMBO_ENTRIES; ++i) {
      003537 7F 00            [12]  791 	mov	r7,#0x00
      003539                        792 00105$:
      003539 BF 08 00         [24]  793 	cjne	r7,#0x08,00131$
      00353C                        794 00131$:
      00353C 40 01            [24]  795 	jc	00132$
      00353E 22               [24]  796 	ret
      00353F                        797 00132$:
                                    798 ;	keyboards/ajazz/ak820/ak820_combo.c:37: combos[i].a = 0;
      00353F EF               [12]  799 	mov	a,r7
      003540 12 38 8F         [24]  800 	lcall	_ak820_outline_0189
      003543 24 22            [12]  801 	add	a, #_combos
      003545 FD               [12]  802 	mov	r5,a
      003546 74 04            [12]  803 	mov	a,#(_combos >> 8)
      003548 35 F0            [12]  804 	addc	a, b
      00354A FE               [12]  805 	mov	r6,a
      00354B 8D 03            [24]  806 	mov	ar3,r5
      00354D 8E 04            [24]  807 	mov	ar4,r6
      00354F 12 33 FC         [24]  808 	lcall	_ak820_outline_0124
      003552 E4               [12]  809 	clr	a
      003553 F0               [24]  810 	movx	@dptr,a
                                    811 ;	keyboards/ajazz/ak820/ak820_combo.c:38: if (!dynamic_keymap_get_combo(i, &entry)) {
      003554 90 0B B5         [24]  812 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      003557 74 4E            [12]  813 	mov	a,#_ak820_combo_reload_entry_30000_606
      003559 F0               [24]  814 	movx	@dptr,a
      00355A 74 04            [12]  815 	mov	a,#(_ak820_combo_reload_entry_30000_606 >> 8)
      00355C 12 38 25         [24]  816 	lcall	_ak820_outline_0075
      00355F 8F 82            [24]  817 	mov	dpl, r7
      003561 C0 07            [24]  818 	push	ar7
      003563 C0 06            [24]  819 	push	ar6
      003565 C0 05            [24]  820 	push	ar5
      003567 C0 04            [24]  821 	push	ar4
      003569 C0 03            [24]  822 	push	ar3
      00356B 12 8A F0         [24]  823 	lcall	_dynamic_keymap_get_combo
      00356E 12 38 5F         [24]  824 	lcall	_ak820_outline_0125
      003571 D0 03            [24]  825 	pop	ar3
      003573 D0 04            [24]  826 	pop	ar4
      003575 D0 05            [24]  827 	pop	ar5
      003577 D0 06            [24]  828 	pop	ar6
      003579 D0 07            [24]  829 	pop	ar7
      00357B 45 F0            [12]  830 	orl	a,b
      00357D 70 28            [24]  831 	jnz	00106$
                                    832 ;	keyboards/ajazz/ak820/ak820_combo.c:39: combos[i].a = entry.input[0];
      00357F 90 04 4E         [24]  833 	mov	dptr,#_ak820_combo_reload_entry_30000_606
      003582 E0               [24]  834 	movx	a,@dptr
      003583 12 33 FC         [24]  835 	lcall	_ak820_outline_0124
      003586 F0               [24]  836 	movx	@dptr,a
                                    837 ;	keyboards/ajazz/ak820/ak820_combo.c:40: combos[i].b = entry.input[1];
      003587 74 01            [12]  838 	mov	a,#0x01
      003589 2D               [12]  839 	add	a, r5
      00358A FB               [12]  840 	mov	r3,a
      00358B E4               [12]  841 	clr	a
      00358C 3E               [12]  842 	addc	a, r6
      00358D FC               [12]  843 	mov	r4,a
      00358E 90 04 50         [24]  844 	mov	dptr,#(_ak820_combo_reload_entry_30000_606 + 0x0002)
      003591 E0               [24]  845 	movx	a,@dptr
      003592 12 33 FC         [24]  846 	lcall	_ak820_outline_0124
      003595 F0               [24]  847 	movx	@dptr,a
                                    848 ;	keyboards/ajazz/ak820/ak820_combo.c:41: combos[i].output = entry.output;
      003596 74 02            [12]  849 	mov	a,#0x02
      003598 12 38 7E         [24]  850 	lcall	_ak820_outline_0162
      00359B 90 04 56         [24]  851 	mov	dptr,#(_ak820_combo_reload_entry_30000_606 + 0x0008)
      00359E 12 38 4A         [24]  852 	lcall	_ak820_outline_0103
      0035A1 12 38 6A         [24]  853 	lcall	_ak820_outline_0137
      0035A4 12 38 38         [24]  854 	lcall	_ak820_outline_0081
      0035A7                        855 00106$:
                                    856 ;	keyboards/ajazz/ak820/ak820_combo.c:35: for (uint8_t i = 0; i < VIAL_COMBO_ENTRIES; ++i) {
      0035A7 0F               [12]  857 	inc	r7
                                    858 ;	keyboards/ajazz/ak820/ak820_combo.c:44: }
      0035A8 02 35 39         [24]  859 	ljmp	00105$
                                    860 ;------------------------------------------------------------
                                    861 ;Allocation info for local variables in function 'flush'
                                    862 ;------------------------------------------------------------
                                    863 ;	keyboards/ajazz/ak820/ak820_combo.c:45: static void flush(void) {
                                    864 ;	-----------------------------------------
                                    865 ;	 function flush
                                    866 ;	-----------------------------------------
      0035AB                        867 _flush:
                                    868 ;	keyboards/ajazz/ak820/ak820_combo.c:46: first = NONE;
      0035AB 90 0E 6E         [24]  869 	mov	dptr,#_first
      0035AE 74 FF            [12]  870 	mov	a,#0xff
      0035B0 F0               [24]  871 	movx	@dptr,a
                                    872 ;	keyboards/ajazz/ak820/ak820_combo.c:47: process_record(&saved);
      0035B1 90 04 42         [24]  873 	mov	dptr,#_saved
                                    874 ;	keyboards/ajazz/ak820/ak820_combo.c:48: }
      0035B4 02 75 A3         [24]  875 	ljmp	_process_record
                                    876 ;------------------------------------------------------------
                                    877 ;Allocation info for local variables in function 'ak820_combo_tick'
                                    878 ;------------------------------------------------------------
                                    879 ;now           Allocated with name '_ak820_combo_tick_now_10000_611'
                                    880 ;------------------------------------------------------------
                                    881 ;	keyboards/ajazz/ak820/ak820_combo.c:49: void ak820_combo_tick(uint16_t now) {
                                    882 ;	-----------------------------------------
                                    883 ;	 function ak820_combo_tick
                                    884 ;	-----------------------------------------
      0035B7                        885 _ak820_combo_tick:
      0035B7 12 38 55         [24]  886 	lcall	_ak820_outline_0106
      0035BA 90 04 58         [24]  887 	mov	dptr,#_ak820_combo_tick_now_10000_611
      0035BD 12 38 50         [24]  888 	lcall	_ak820_outline_0105
                                    889 ;	keyboards/ajazz/ak820/ak820_combo.c:50: if (first != NONE && !active && (uint16_t)(now - saved.event.time) >= AK820_COMBO_TERM) flush();
      0035C0 12 38 8A         [24]  890 	lcall	_ak820_outline_0186
      0035C3 FF               [12]  891 	mov	r7,a
      0035C4 BF FF 01         [24]  892 	cjne	r7,#0xff,00128$
      0035C7 22               [24]  893 	ret
      0035C8                        894 00128$:
      0035C8 90 04 4B         [24]  895 	mov	dptr,#_active
      0035CB E0               [24]  896 	movx	a,@dptr
      0035CC 70 1F            [24]  897 	jnz	00105$
      0035CE 90 04 44         [24]  898 	mov	dptr,#(_saved + 0x0002)
      0035D1 12 38 00         [24]  899 	lcall	_ak820_outline_0056
      0035D4 90 04 58         [24]  900 	mov	dptr,#_ak820_combo_tick_now_10000_611
      0035D7 12 38 1F         [24]  901 	lcall	_ak820_outline_0065
      0035DA EC               [12]  902 	mov	a,r4
      0035DB C3               [12]  903 	clr	c
      0035DC 9E               [12]  904 	subb	a,r6
      0035DD FE               [12]  905 	mov	r6,a
      0035DE ED               [12]  906 	mov	a,r5
      0035DF 9F               [12]  907 	subb	a,r7
      0035E0 FF               [12]  908 	mov	r7,a
      0035E1 C3               [12]  909 	clr	c
      0035E2 EE               [12]  910 	mov	a,r6
      0035E3 94 28            [12]  911 	subb	a,#0x28
      0035E5 EF               [12]  912 	mov	a,r7
      0035E6 94 00            [12]  913 	subb	a,#0x00
      0035E8 40 03            [24]  914 	jc	00105$
                                    915 ;	keyboards/ajazz/ak820/ak820_combo.c:51: }
      0035EA 02 35 AB         [24]  916 	ljmp	_flush
      0035ED                        917 00105$:
      0035ED 22               [24]  918 	ret
                                    919 ;------------------------------------------------------------
                                    920 ;Allocation info for local variables in function 'ak820_combo_process'
                                    921 ;------------------------------------------------------------
                                    922 ;record        Allocated with name '_ak820_combo_process_record_10000_614'
                                    923 ;id            Allocated with name '_ak820_combo_process_id_10000_615'
                                    924 ;code          Allocated with name '_ak820_combo_process_code_10000_615'
                                    925 ;eligible      Allocated with name '_ak820_combo_process_eligible_10001_629'
                                    926 ;previous      Allocated with name '_ak820_combo_process_previous_30001_631'
                                    927 ;i             Allocated with name '_ak820_combo_process_i_40001_632'
                                    928 ;a             Allocated with name '_ak820_combo_process_a_50001_633'
                                    929 ;b             Allocated with name '_ak820_combo_process_b_50001_633'
                                    930 ;------------------------------------------------------------
                                    931 ;	keyboards/ajazz/ak820/ak820_combo.c:52: bool ak820_combo_process(keyrecord_t AK820_STATE_MEM *record) {
                                    932 ;	-----------------------------------------
                                    933 ;	 function ak820_combo_process
                                    934 ;	-----------------------------------------
      0035EE                        935 _ak820_combo_process:
      0035EE 12 38 55         [24]  936 	lcall	_ak820_outline_0106
      0035F1 90 04 5A         [24]  937 	mov	dptr,#_ak820_combo_process_record_10000_614
      0035F4 12 38 50         [24]  938 	lcall	_ak820_outline_0105
                                    939 ;	keyboards/ajazz/ak820/ak820_combo.c:53: uint8_t id, code = record->keycode;
      0035F7 90 04 5A         [24]  940 	mov	dptr,#_ak820_combo_process_record_10000_614
      0035FA 12 37 BB         [24]  941 	lcall	_ak820_outline_0008
      0035FD FC               [12]  942 	mov	r4,a
      0035FE A3               [24]  943 	inc	dptr
      0035FF E0               [24]  944 	movx	a,@dptr
      003600 FD               [12]  945 	mov	r5,a
      003601 8C 03            [24]  946 	mov	ar3,r4
                                    947 ;	keyboards/ajazz/ak820/ak820_combo.c:54: if (IS_NOEVENT(record->event)) return true;
      003603 74 04            [12]  948 	mov	a,#0x04
      003605 2E               [12]  949 	add	a, r6
      003606 12 37 D5         [24]  950 	lcall	_ak820_outline_0016
      003609 70 04            [24]  951 	jnz	00102$
      00360B 75 82 01         [24]  952 	mov	dpl, #0x01
      00360E 22               [24]  953 	ret
      00360F                        954 00102$:
                                    955 ;	keyboards/ajazz/ak820/ak820_combo.c:56: if (record->event.key.row >= MATRIX_ROWS || record->event.key.col >= MATRIX_COLS) {
      00360F 12 38 31         [24]  956 	lcall	_ak820_outline_0079
      003612 FA               [12]  957 	mov	r2,a
      003613 BA 10 00         [24]  958 	cjne	r2,#0x10,00308$
      003616                        959 00308$:
      003616 50 09            [24]  960 	jnc	00106$
      003618 12 38 3E         [24]  961 	lcall	_ak820_outline_0088
      00361B F9               [12]  962 	mov	r1,a
      00361C B9 08 00         [24]  963 	cjne	r1,#0x08,00310$
      00361F                        964 00310$:
      00361F 40 16            [24]  965 	jc	00107$
      003621                        966 00106$:
                                    967 ;	keyboards/ajazz/ak820/ak820_combo.c:57: if (first != NONE && !active) flush();
      003621 12 38 8A         [24]  968 	lcall	_ak820_outline_0186
      003624 F8               [12]  969 	mov	r0,a
      003625 B8 FF 02         [24]  970 	cjne	r0,#0xff,00312$
      003628 80 09            [24]  971 	sjmp	00104$
      00362A                        972 00312$:
      00362A 90 04 4B         [24]  973 	mov	dptr,#_active
      00362D E0               [24]  974 	movx	a,@dptr
      00362E 70 03            [24]  975 	jnz	00104$
      003630 12 35 AB         [24]  976 	lcall	_flush
      003633                        977 00104$:
                                    978 ;	keyboards/ajazz/ak820/ak820_combo.c:58: return true;
      003633 75 82 01         [24]  979 	mov	dpl, #0x01
      003636 22               [24]  980 	ret
      003637                        981 00107$:
                                    982 ;	keyboards/ajazz/ak820/ak820_combo.c:60: id = record->event.key.row * MATRIX_COLS + record->event.key.col;
      003637 EA               [12]  983 	mov	a,r2
      003638 12 38 79         [24]  984 	lcall	_ak820_outline_0161
      00363B 29               [12]  985 	add	a,r1
      00363C FA               [12]  986 	mov	r2,a
                                    987 ;	keyboards/ajazz/ak820/ak820_combo.c:61: if (active) {
      00363D 90 04 4B         [24]  988 	mov	dptr,#_active
      003640 E0               [24]  989 	movx	a,@dptr
      003641 60 6F            [24]  990 	jz	00123$
                                    991 ;	keyboards/ajazz/ak820/ak820_combo.c:62: if (id != first && id != second) return true;
      003643 12 38 8A         [24]  992 	lcall	_ak820_outline_0186
      003646 F9               [12]  993 	mov	r1,a
      003647 EA               [12]  994 	mov	a,r2
      003648 B5 01 02         [24]  995 	cjne	a,ar1,00315$
      00364B 80 0F            [24]  996 	sjmp	00110$
      00364D                        997 00315$:
      00364D 90 0E 6F         [24]  998 	mov	dptr,#_second
      003650 E0               [24]  999 	movx	a,@dptr
      003651 F9               [12] 1000 	mov	r1,a
      003652 EA               [12] 1001 	mov	a,r2
      003653 B5 01 02         [24] 1002 	cjne	a,ar1,00316$
      003656 80 04            [24] 1003 	sjmp	00110$
      003658                       1004 00316$:
      003658 75 82 01         [24] 1005 	mov	dpl, #0x01
      00365B 22               [24] 1006 	ret
      00365C                       1007 00110$:
                                   1008 ;	keyboards/ajazz/ak820/ak820_combo.c:63: if (!record->event.pressed) {
      00365C 90 04 5A         [24] 1009 	mov	dptr,#_ak820_combo_process_record_10000_614
      00365F 12 38 44         [24] 1010 	lcall	_ak820_outline_0102
      003662 74 05            [12] 1011 	mov	a,#0x05
      003664 28               [12] 1012 	add	a, r0
      003665 F8               [12] 1013 	mov	r0,a
      003666 E4               [12] 1014 	clr	a
      003667 39               [12] 1015 	addc	a, r1
      003668 F9               [12] 1016 	mov	r1,a
      003669 12 38 74         [24] 1017 	lcall	_ak820_outline_0158
      00366C E0               [24] 1018 	movx	a,@dptr
      00366D 70 3F            [24] 1019 	jnz	00121$
                                   1020 ;	keyboards/ajazz/ak820/ak820_combo.c:64: if (saved.event.pressed) {
      00366F 90 04 47         [24] 1021 	mov	dptr,#(_saved + 0x0005)
      003672 E0               [24] 1022 	movx	a,@dptr
      003673 60 0F            [24] 1023 	jz	00113$
                                   1024 ;	keyboards/ajazz/ak820/ak820_combo.c:65: saved.event.pressed = false;
      003675 90 04 47         [24] 1025 	mov	dptr,#(_saved + 0x0005)
      003678 E4               [12] 1026 	clr	a
      003679 F0               [24] 1027 	movx	@dptr,a
                                   1028 ;	keyboards/ajazz/ak820/ak820_combo.c:66: process_record(&saved);
      00367A 90 04 42         [24] 1029 	mov	dptr,#_saved
      00367D C0 02            [24] 1030 	push	ar2
      00367F 12 75 A3         [24] 1031 	lcall	_process_record
      003682 D0 02            [24] 1032 	pop	ar2
      003684                       1033 00113$:
                                   1034 ;	keyboards/ajazz/ak820/ak820_combo.c:68: if (id == first) first = NONE;
      003684 12 38 8A         [24] 1035 	lcall	_ak820_outline_0186
      003687 F9               [12] 1036 	mov	r1,a
      003688 EA               [12] 1037 	mov	a,r2
      003689 B5 01 08         [24] 1038 	cjne	a,ar1,00115$
      00368C 90 0E 6E         [24] 1039 	mov	dptr,#_first
      00368F 74 FF            [12] 1040 	mov	a,#0xff
      003691 F0               [24] 1041 	movx	@dptr,a
      003692 80 06            [24] 1042 	sjmp	00116$
      003694                       1043 00115$:
                                   1044 ;	keyboards/ajazz/ak820/ak820_combo.c:69: else second = NONE;
      003694 90 0E 6F         [24] 1045 	mov	dptr,#_second
      003697 74 FF            [12] 1046 	mov	a,#0xff
      003699 F0               [24] 1047 	movx	@dptr,a
      00369A                       1048 00116$:
                                   1049 ;	keyboards/ajazz/ak820/ak820_combo.c:70: if (first == NONE && second == NONE) active = false;
      00369A 12 38 8A         [24] 1050 	lcall	_ak820_outline_0186
      00369D F9               [12] 1051 	mov	r1,a
      00369E B9 FF 0D         [24] 1052 	cjne	r1,#0xff,00121$
      0036A1 90 0E 6F         [24] 1053 	mov	dptr,#_second
      0036A4 E0               [24] 1054 	movx	a,@dptr
      0036A5 F9               [12] 1055 	mov	r1,a
      0036A6 B9 FF 05         [24] 1056 	cjne	r1,#0xff,00121$
      0036A9 90 04 4B         [24] 1057 	mov	dptr,#_active
      0036AC E4               [12] 1058 	clr	a
      0036AD F0               [24] 1059 	movx	@dptr,a
      0036AE                       1060 00121$:
                                   1061 ;	keyboards/ajazz/ak820/ak820_combo.c:72: return false;
      0036AE 75 82 00         [24] 1062 	mov	dpl, #0x00
      0036B1 22               [24] 1063 	ret
      0036B2                       1064 00123$:
                                   1065 ;	keyboards/ajazz/ak820/ak820_combo.c:74: bool eligible = false;
      0036B2 90 04 5C         [24] 1066 	mov	dptr,#_ak820_combo_process_eligible_10001_629
      0036B5 E4               [12] 1067 	clr	a
      0036B6 F0               [24] 1068 	movx	@dptr,a
                                   1069 ;	keyboards/ajazz/ak820/ak820_combo.c:75: if (record->event.pressed && COMBO_INPUT(record->keycode)) {
      0036B7 12 37 A4         [24] 1070 	lcall	_ak820_outline_0001
      0036BA 70 03            [24] 1071 	jnz	00325$
      0036BC 02 37 64         [24] 1072 	ljmp	00134$
      0036BF                       1073 00325$:
      0036BF C3               [12] 1074 	clr	c
      0036C0 EC               [12] 1075 	mov	a,r4
      0036C1 94 04            [12] 1076 	subb	a,#0x04
      0036C3 ED               [12] 1077 	mov	a,r5
      0036C4 94 00            [12] 1078 	subb	a,#0x00
      0036C6 50 03            [24] 1079 	jnc	00326$
      0036C8 02 37 64         [24] 1080 	ljmp	00134$
      0036CB                       1081 00326$:
      0036CB C3               [12] 1082 	clr	c
      0036CC 74 A4            [12] 1083 	mov	a,#0xa4
      0036CE 9C               [12] 1084 	subb	a,r4
      0036CF E4               [12] 1085 	clr	a
      0036D0 9D               [12] 1086 	subb	a,r5
      0036D1 50 03            [24] 1087 	jnc	00327$
      0036D3 02 37 64         [24] 1088 	ljmp	00134$
      0036D6                       1089 00327$:
                                   1090 ;	free result
                                   1091 ;	keyboards/ajazz/ak820/ak820_combo.c:76: uint8_t previous = saved.keycode;
      0036D6 90 04 49         [24] 1092 	mov	dptr,#(_saved + 0x0007)
      0036D9 E0               [24] 1093 	movx	a,@dptr
      0036DA FF               [12] 1094 	mov	r7,a
                                   1095 ;	keyboards/ajazz/ak820/ak820_combo.c:77: for (uint8_t i = 0; i < VIAL_COMBO_ENTRIES; ++i) {
      0036DB 90 04 5D         [24] 1096 	mov	dptr,#_ak820_combo_process_i_40001_632
      0036DE E4               [12] 1097 	clr	a
      0036DF F0               [24] 1098 	movx	@dptr,a
      0036E0 EB               [12] 1099 	mov	a,r3
      0036E1 B5 07 03         [24] 1100 	cjne	a,ar7,00328$
      0036E4 D3               [12] 1101 	setb	c
      0036E5 80 01            [24] 1102 	sjmp	00329$
      0036E7                       1103 00328$:
      0036E7 C3               [12] 1104 	clr	c
      0036E8                       1105 00329$:
      0036E8 92 01            [24] 1106 	mov	_ak820_combo_process_sloc0_1_0,c
      0036EA 7E 00            [12] 1107 	mov	r6,#0x00
      0036EC                       1108 00142$:
      0036EC BE 08 00         [24] 1109 	cjne	r6,#0x08,00330$
      0036EF                       1110 00330$:
      0036EF 40 03            [24] 1111 	jc	00331$
      0036F1 02 37 64         [24] 1112 	ljmp	00134$
      0036F4                       1113 00331$:
                                   1114 ;	keyboards/ajazz/ak820/ak820_combo.c:78: uint8_t a = combos[i].a, b = combos[i].b;
      0036F4 EE               [12] 1115 	mov	a,r6
      0036F5 12 38 06         [24] 1116 	lcall	_ak820_outline_0058
      0036F8 E0               [24] 1117 	movx	a,@dptr
      0036F9 F9               [12] 1118 	mov	r1,a
      0036FA 90 04 5E         [24] 1119 	mov	dptr,#_ak820_combo_process_a_50001_633
      0036FD F0               [24] 1120 	movx	@dptr,a
      0036FE 12 38 5A         [24] 1121 	lcall	_ak820_outline_0123
      003701 A3               [24] 1122 	inc	dptr
      003702 E0               [24] 1123 	movx	a,@dptr
      003703 FD               [12] 1124 	mov	r5,a
      003704 90 04 5F         [24] 1125 	mov	dptr,#_ak820_combo_process_b_50001_633
      003707 F0               [24] 1126 	movx	@dptr,a
                                   1127 ;	keyboards/ajazz/ak820/ak820_combo.c:79: if (a == code || b == code) {
      003708 E9               [12] 1128 	mov	a,r1
      003709 B5 03 02         [24] 1129 	cjne	a,ar3,00332$
      00370C 80 04            [24] 1130 	sjmp	00129$
      00370E                       1131 00332$:
      00370E ED               [12] 1132 	mov	a,r5
      00370F B5 03 49         [24] 1133 	cjne	a,ar3,00143$
      003712                       1134 00129$:
                                   1135 ;	keyboards/ajazz/ak820/ak820_combo.c:80: eligible = true;
      003712 90 04 5C         [24] 1136 	mov	dptr,#_ak820_combo_process_eligible_10001_629
      003715 74 01            [12] 1137 	mov	a,#0x01
      003717 F0               [24] 1138 	movx	@dptr,a
                                   1139 ;	keyboards/ajazz/ak820/ak820_combo.c:81: if (first != NONE && code != previous && (a == previous || b == previous)) {
      003718 12 38 8A         [24] 1140 	lcall	_ak820_outline_0186
      00371B FD               [12] 1141 	mov	r5,a
      00371C BD FF 02         [24] 1142 	cjne	r5,#0xff,00335$
      00371F 80 3A            [24] 1143 	sjmp	00143$
      003721                       1144 00335$:
      003721 20 01 37         [24] 1145 	jb	_ak820_combo_process_sloc0_1_0,00143$
      003724 90 04 5E         [24] 1146 	mov	dptr,#_ak820_combo_process_a_50001_633
      003727 E0               [24] 1147 	movx	a,@dptr
      003728 B5 07 02         [24] 1148 	cjne	a,ar7,00337$
      00372B 80 07            [24] 1149 	sjmp	00124$
      00372D                       1150 00337$:
      00372D 90 04 5F         [24] 1151 	mov	dptr,#_ak820_combo_process_b_50001_633
      003730 E0               [24] 1152 	movx	a,@dptr
      003731 B5 07 27         [24] 1153 	cjne	a,ar7,00143$
      003734                       1154 00124$:
                                   1155 ;	keyboards/ajazz/ak820/ak820_combo.c:82: second = id;
      003734 90 0E 6F         [24] 1156 	mov	dptr,#_second
      003737 EA               [12] 1157 	mov	a,r2
      003738 F0               [24] 1158 	movx	@dptr,a
                                   1159 ;	keyboards/ajazz/ak820/ak820_combo.c:83: active = true;
      003739 90 04 4B         [24] 1160 	mov	dptr,#_active
      00373C 74 01            [12] 1161 	mov	a,#0x01
      00373E F0               [24] 1162 	movx	@dptr,a
                                   1163 ;	keyboards/ajazz/ak820/ak820_combo.c:84: saved.keycode = combos[i].output;
      00373F 90 04 5D         [24] 1164 	mov	dptr,#_ak820_combo_process_i_40001_632
      003742 E0               [24] 1165 	movx	a,@dptr
      003743 12 38 06         [24] 1166 	lcall	_ak820_outline_0058
      003746 A3               [24] 1167 	inc	dptr
      003747 A3               [24] 1168 	inc	dptr
      003748 12 38 1F         [24] 1169 	lcall	_ak820_outline_0065
      00374B 90 04 49         [24] 1170 	mov	dptr,#(_saved + 0x0007)
      00374E 12 38 2B         [24] 1171 	lcall	_ak820_outline_0077
                                   1172 ;	keyboards/ajazz/ak820/ak820_combo.c:85: process_record(&saved);
      003751 90 04 42         [24] 1173 	mov	dptr,#_saved
      003754 12 75 A3         [24] 1174 	lcall	_process_record
                                   1175 ;	keyboards/ajazz/ak820/ak820_combo.c:86: return false;
      003757 75 82 00         [24] 1176 	mov	dpl, #0x00
      00375A 22               [24] 1177 	ret
      00375B                       1178 00143$:
                                   1179 ;	keyboards/ajazz/ak820/ak820_combo.c:77: for (uint8_t i = 0; i < VIAL_COMBO_ENTRIES; ++i) {
      00375B 0E               [12] 1180 	inc	r6
      00375C 90 04 5D         [24] 1181 	mov	dptr,#_ak820_combo_process_i_40001_632
      00375F EE               [12] 1182 	mov	a,r6
      003760 F0               [24] 1183 	movx	@dptr,a
      003761 02 36 EC         [24] 1184 	ljmp	00142$
      003764                       1185 00134$:
                                   1186 ;	keyboards/ajazz/ak820/ak820_combo.c:91: if (first != NONE) flush();
      003764 12 38 8A         [24] 1187 	lcall	_ak820_outline_0186
      003767 FF               [12] 1188 	mov	r7,a
      003768 BF FF 02         [24] 1189 	cjne	r7,#0xff,00340$
      00376B 80 07            [24] 1190 	sjmp	00138$
      00376D                       1191 00340$:
      00376D C0 02            [24] 1192 	push	ar2
      00376F 12 35 AB         [24] 1193 	lcall	_flush
      003772 D0 02            [24] 1194 	pop	ar2
      003774                       1195 00138$:
                                   1196 ;	keyboards/ajazz/ak820/ak820_combo.c:92: if (eligible) {
      003774 90 04 5C         [24] 1197 	mov	dptr,#_ak820_combo_process_eligible_10001_629
      003777 E0               [24] 1198 	movx	a,@dptr
      003778 60 26            [24] 1199 	jz	00140$
                                   1200 ;	keyboards/ajazz/ak820/ak820_combo.c:93: first = id;
      00377A 90 0E 6E         [24] 1201 	mov	dptr,#_first
      00377D EA               [12] 1202 	mov	a,r2
      00377E F0               [24] 1203 	movx	@dptr,a
                                   1204 ;	keyboards/ajazz/ak820/ak820_combo.c:94: saved = *record;
      00377F 90 04 5A         [24] 1205 	mov	dptr,#_ak820_combo_process_record_10000_614
      003782 12 38 17         [24] 1206 	lcall	_ak820_outline_0062
      003785 90 0E 60         [24] 1207 	mov	dptr,#___memcpy_PARM_2
      003788 ED               [12] 1208 	mov	a,r5
      003789 12 37 E8         [24] 1209 	lcall	_ak820_outline_0018
      00378C 90 0E 63         [24] 1210 	mov	dptr,#___memcpy_PARM_3
      00378F 74 09            [12] 1211 	mov	a,#0x09
      003791 12 38 65         [24] 1212 	lcall	_ak820_outline_0127
      003794 90 04 42         [24] 1213 	mov	dptr,#_saved
      003797 F5 F0            [12] 1214 	mov	b,a
      003799 12 BD 5F         [24] 1215 	lcall	___memcpy
                                   1216 ;	keyboards/ajazz/ak820/ak820_combo.c:95: return false;
      00379C 75 82 00         [24] 1217 	mov	dpl, #0x00
      00379F 22               [24] 1218 	ret
      0037A0                       1219 00140$:
                                   1220 ;	keyboards/ajazz/ak820/ak820_combo.c:97: return true;
      0037A0 75 82 01         [24] 1221 	mov	dpl, #0x01
                                   1222 ;	keyboards/ajazz/ak820/ak820_combo.c:98: }
      0037A3 22               [24] 1223 	ret
                                   1224 	.area CSEG    (CODE)
                                   1225 	.area CONST   (CODE)
                                   1226 	.area XINIT   (CODE)
      00C61D                       1227 __xinit__first:
      00C61D FF                    1228 	.db #0xff	; 255
      00C61E                       1229 __xinit__second:
      00C61E FF                    1230 	.db #0xff	; 255
                                   1231 	.area CABS    (ABS,CODE)
                                   1232 
                                   1233 ; Experimental exact instruction outlining.
                                   1234 	.globl _ak820_outline_0001
                                   1235 	.globl _ak820_outline_0005
                                   1236 	.globl _ak820_outline_0008
                                   1237 	.globl _ak820_outline_0010
                                   1238 	.globl _ak820_outline_0016
                                   1239 	.globl _ak820_outline_0017
                                   1240 	.globl _ak820_outline_0018
                                   1241 	.globl _ak820_outline_0034
                                   1242 	.globl _ak820_outline_0035
                                   1243 	.globl _ak820_outline_0056
                                   1244 	.globl _ak820_outline_0058
                                   1245 	.globl _ak820_outline_0062
                                   1246 	.globl _ak820_outline_0065
                                   1247 	.globl _ak820_outline_0075
                                   1248 	.globl _ak820_outline_0077
                                   1249 	.globl _ak820_outline_0079
                                   1250 	.globl _ak820_outline_0081
                                   1251 	.globl _ak820_outline_0088
                                   1252 	.globl _ak820_outline_0102
                                   1253 	.globl _ak820_outline_0103
                                   1254 	.globl _ak820_outline_0105
                                   1255 	.globl _ak820_outline_0106
                                   1256 	.globl _ak820_outline_0123
                                   1257 	.globl _ak820_outline_0124
                                   1258 	.globl _ak820_outline_0125
                                   1259 	.globl _ak820_outline_0127
                                   1260 	.globl _ak820_outline_0137
                                   1261 	.globl _ak820_outline_0149
                                   1262 	.globl _ak820_outline_0158
                                   1263 	.globl _ak820_outline_0161
                                   1264 	.globl _ak820_outline_0162
                                   1265 	.globl _ak820_outline_0172
                                   1266 	.globl _ak820_outline_0186
                                   1267 	.globl _ak820_outline_0189
                                   1268 
                                   1269 	.area CSEG (CODE)
                                   1270 ; function ak820_outline_0001
      0037A4                       1271 _ak820_outline_0001:
      0037A4 74 05            [12] 1272 	mov	a,#0x05
      0037A6 2E               [12] 1273 	add	a,r6
      0037A7 FE               [12] 1274 	mov	r6,a
      0037A8 E4               [12] 1275 	clr	a
      0037A9 3F               [12] 1276 	addc	a,r7
      0037AA FF               [12] 1277 	mov	r7,a
      0037AB 8E 82            [24] 1278 	mov	dpl,r6
      0037AD 8F 83            [24] 1279 	mov	dph,r7
      0037AF E0               [24] 1280 	movx	a,@dptr
      0037B0 22               [24] 1281 	ret
                                   1282 
                                   1283 	.area CSEG (CODE)
                                   1284 ; function ak820_outline_0005
      0037B1                       1285 _ak820_outline_0005:
      0037B1 E0               [24] 1286 	movx	a,@dptr
      0037B2 FE               [12] 1287 	mov	r6,a
      0037B3 A3               [24] 1288 	inc	dptr
      0037B4 E0               [24] 1289 	movx	a,@dptr
      0037B5 FF               [12] 1290 	mov	r7,a
      0037B6 8E 82            [24] 1291 	mov	dpl,r6
      0037B8 8F 83            [24] 1292 	mov	dph,r7
      0037BA 22               [24] 1293 	ret
                                   1294 
                                   1295 	.area CSEG (CODE)
                                   1296 ; function ak820_outline_0008
      0037BB                       1297 _ak820_outline_0008:
      0037BB E0               [24] 1298 	movx	a,@dptr
      0037BC FE               [12] 1299 	mov	r6,a
      0037BD A3               [24] 1300 	inc	dptr
      0037BE E0               [24] 1301 	movx	a,@dptr
      0037BF FF               [12] 1302 	mov	r7,a
      0037C0 74 07            [12] 1303 	mov	a,#0x07
      0037C2 2E               [12] 1304 	add	a,r6
      0037C3 F5 82            [12] 1305 	mov	dpl,a
      0037C5 E4               [12] 1306 	clr	a
      0037C6 3F               [12] 1307 	addc	a,r7
      0037C7 F5 83            [12] 1308 	mov	dph,a
      0037C9 E0               [24] 1309 	movx	a,@dptr
      0037CA 22               [24] 1310 	ret
                                   1311 
                                   1312 	.area CSEG (CODE)
                                   1313 ; function ak820_outline_0010
      0037CB                       1314 _ak820_outline_0010:
      0037CB E0               [24] 1315 	movx	a,@dptr
      0037CC FE               [12] 1316 	mov	r6,a
      0037CD A3               [24] 1317 	inc	dptr
      0037CE E0               [24] 1318 	movx	a,@dptr
      0037CF FF               [12] 1319 	mov	r7,a
      0037D0 8E 04            [24] 1320 	mov	ar4,r6
      0037D2 8F 05            [24] 1321 	mov	ar5,r7
      0037D4 22               [24] 1322 	ret
                                   1323 
                                   1324 	.area CSEG (CODE)
                                   1325 ; function ak820_outline_0016
      0037D5                       1326 _ak820_outline_0016:
      0037D5 F9               [12] 1327 	mov	r1,a
      0037D6 E4               [12] 1328 	clr	a
      0037D7 3F               [12] 1329 	addc	a,r7
      0037D8 FA               [12] 1330 	mov	r2,a
      0037D9 89 82            [24] 1331 	mov	dpl,r1
      0037DB 8A 83            [24] 1332 	mov	dph,r2
      0037DD E0               [24] 1333 	movx	a,@dptr
      0037DE 22               [24] 1334 	ret
                                   1335 
                                   1336 	.area CSEG (CODE)
                                   1337 ; function ak820_outline_0017
      0037DF                       1338 _ak820_outline_0017:
      0037DF 2E               [12] 1339 	add	a,r6
      0037E0 F5 82            [12] 1340 	mov	dpl,a
      0037E2 E4               [12] 1341 	clr	a
      0037E3 3F               [12] 1342 	addc	a,r7
      0037E4 F5 83            [12] 1343 	mov	dph,a
      0037E6 E0               [24] 1344 	movx	a,@dptr
      0037E7 22               [24] 1345 	ret
                                   1346 
                                   1347 	.area CSEG (CODE)
                                   1348 ; function ak820_outline_0018
      0037E8                       1349 _ak820_outline_0018:
      0037E8 F0               [24] 1350 	movx	@dptr,a
      0037E9 EE               [12] 1351 	mov	a,r6
      0037EA A3               [24] 1352 	inc	dptr
      0037EB F0               [24] 1353 	movx	@dptr,a
      0037EC EF               [12] 1354 	mov	a,r7
      0037ED A3               [24] 1355 	inc	dptr
      0037EE F0               [24] 1356 	movx	@dptr,a
      0037EF 22               [24] 1357 	ret
                                   1358 
                                   1359 	.area CSEG (CODE)
                                   1360 ; function ak820_outline_0034
      0037F0                       1361 _ak820_outline_0034:
      0037F0 8E 82            [24] 1362 	mov	dpl,r6
      0037F2 8F 83            [24] 1363 	mov	dph,r7
      0037F4 A3               [24] 1364 	inc	dptr
      0037F5 A3               [24] 1365 	inc	dptr
      0037F6 E0               [24] 1366 	movx	a,@dptr
      0037F7 22               [24] 1367 	ret
                                   1368 
                                   1369 	.area CSEG (CODE)
                                   1370 ; function ak820_outline_0035
      0037F8                       1371 _ak820_outline_0035:
      0037F8 2E               [12] 1372 	add	a,r6
      0037F9 F5 82            [12] 1373 	mov	dpl,a
      0037FB E4               [12] 1374 	clr	a
      0037FC 3F               [12] 1375 	addc	a,r7
      0037FD F5 83            [12] 1376 	mov	dph,a
      0037FF 22               [24] 1377 	ret
                                   1378 
                                   1379 	.area CSEG (CODE)
                                   1380 ; function ak820_outline_0056
      003800                       1381 _ak820_outline_0056:
      003800 E0               [24] 1382 	movx	a,@dptr
      003801 FE               [12] 1383 	mov	r6,a
      003802 A3               [24] 1384 	inc	dptr
      003803 E0               [24] 1385 	movx	a,@dptr
      003804 FF               [12] 1386 	mov	r7,a
      003805 22               [24] 1387 	ret
                                   1388 
                                   1389 	.area CSEG (CODE)
                                   1390 ; function ak820_outline_0058
      003806                       1391 _ak820_outline_0058:
      003806 75 F0 04         [24] 1392 	mov	b,#0x04
      003809 A4               [48] 1393 	mul	ab
      00380A 24 22            [12] 1394 	add	a,#_combos
      00380C FC               [12] 1395 	mov	r4,a
      00380D 74 04            [12] 1396 	mov	a,#(_combos>>8)
      00380F 35 F0            [12] 1397 	addc	a,b
      003811 FD               [12] 1398 	mov	r5,a
      003812 8C 82            [24] 1399 	mov	dpl,r4
      003814 8D 83            [24] 1400 	mov	dph,r5
      003816 22               [24] 1401 	ret
                                   1402 
                                   1403 	.area CSEG (CODE)
                                   1404 ; function ak820_outline_0062
      003817                       1405 _ak820_outline_0062:
      003817 E0               [24] 1406 	movx	a,@dptr
      003818 FD               [12] 1407 	mov	r5,a
      003819 A3               [24] 1408 	inc	dptr
      00381A E0               [24] 1409 	movx	a,@dptr
      00381B FE               [12] 1410 	mov	r6,a
      00381C 7F 00            [12] 1411 	mov	r7,#0x00
      00381E 22               [24] 1412 	ret
                                   1413 
                                   1414 	.area CSEG (CODE)
                                   1415 ; function ak820_outline_0065
      00381F                       1416 _ak820_outline_0065:
      00381F E0               [24] 1417 	movx	a,@dptr
      003820 FC               [12] 1418 	mov	r4,a
      003821 A3               [24] 1419 	inc	dptr
      003822 E0               [24] 1420 	movx	a,@dptr
      003823 FD               [12] 1421 	mov	r5,a
      003824 22               [24] 1422 	ret
                                   1423 
                                   1424 	.area CSEG (CODE)
                                   1425 ; function ak820_outline_0075
      003825                       1426 _ak820_outline_0075:
      003825 A3               [24] 1427 	inc	dptr
      003826 F0               [24] 1428 	movx	@dptr,a
      003827 E4               [12] 1429 	clr	a
      003828 A3               [24] 1430 	inc	dptr
      003829 F0               [24] 1431 	movx	@dptr,a
      00382A 22               [24] 1432 	ret
                                   1433 
                                   1434 	.area CSEG (CODE)
                                   1435 ; function ak820_outline_0077
      00382B                       1436 _ak820_outline_0077:
      00382B EC               [12] 1437 	mov	a,r4
      00382C F0               [24] 1438 	movx	@dptr,a
      00382D ED               [12] 1439 	mov	a,r5
      00382E A3               [24] 1440 	inc	dptr
      00382F F0               [24] 1441 	movx	@dptr,a
      003830 22               [24] 1442 	ret
                                   1443 
                                   1444 	.area CSEG (CODE)
                                   1445 ; function ak820_outline_0079
      003831                       1446 _ak820_outline_0079:
      003831 8E 82            [24] 1447 	mov	dpl,r6
      003833 8F 83            [24] 1448 	mov	dph,r7
      003835 A3               [24] 1449 	inc	dptr
      003836 E0               [24] 1450 	movx	a,@dptr
      003837 22               [24] 1451 	ret
                                   1452 
                                   1453 	.area CSEG (CODE)
                                   1454 ; function ak820_outline_0081
      003838                       1455 _ak820_outline_0081:
      003838 EB               [12] 1456 	mov	a,r3
      003839 F0               [24] 1457 	movx	@dptr,a
      00383A EC               [12] 1458 	mov	a,r4
      00383B A3               [24] 1459 	inc	dptr
      00383C F0               [24] 1460 	movx	@dptr,a
      00383D 22               [24] 1461 	ret
                                   1462 
                                   1463 	.area CSEG (CODE)
                                   1464 ; function ak820_outline_0088
      00383E                       1465 _ak820_outline_0088:
      00383E 8E 82            [24] 1466 	mov	dpl,r6
      003840 8F 83            [24] 1467 	mov	dph,r7
      003842 E0               [24] 1468 	movx	a,@dptr
      003843 22               [24] 1469 	ret
                                   1470 
                                   1471 	.area CSEG (CODE)
                                   1472 ; function ak820_outline_0102
      003844                       1473 _ak820_outline_0102:
      003844 E0               [24] 1474 	movx	a,@dptr
      003845 F8               [12] 1475 	mov	r0,a
      003846 A3               [24] 1476 	inc	dptr
      003847 E0               [24] 1477 	movx	a,@dptr
      003848 F9               [12] 1478 	mov	r1,a
      003849 22               [24] 1479 	ret
                                   1480 
                                   1481 	.area CSEG (CODE)
                                   1482 ; function ak820_outline_0103
      00384A                       1483 _ak820_outline_0103:
      00384A E0               [24] 1484 	movx	a,@dptr
      00384B FB               [12] 1485 	mov	r3,a
      00384C A3               [24] 1486 	inc	dptr
      00384D E0               [24] 1487 	movx	a,@dptr
      00384E FC               [12] 1488 	mov	r4,a
      00384F 22               [24] 1489 	ret
                                   1490 
                                   1491 	.area CSEG (CODE)
                                   1492 ; function ak820_outline_0105
      003850                       1493 _ak820_outline_0105:
      003850 F0               [24] 1494 	movx	@dptr,a
      003851 EF               [12] 1495 	mov	a,r7
      003852 A3               [24] 1496 	inc	dptr
      003853 F0               [24] 1497 	movx	@dptr,a
      003854 22               [24] 1498 	ret
                                   1499 
                                   1500 	.area CSEG (CODE)
                                   1501 ; function ak820_outline_0106
      003855                       1502 _ak820_outline_0106:
      003855 AF 83            [24] 1503 	mov	r7,dph
      003857 E5 82            [12] 1504 	mov	a,dpl
      003859 22               [24] 1505 	ret
                                   1506 
                                   1507 	.area CSEG (CODE)
                                   1508 ; function ak820_outline_0123
      00385A                       1509 _ak820_outline_0123:
      00385A 8C 82            [24] 1510 	mov	dpl,r4
      00385C 8D 83            [24] 1511 	mov	dph,r5
      00385E 22               [24] 1512 	ret
                                   1513 
                                   1514 	.area CSEG (CODE)
                                   1515 ; function ak820_outline_0125
      00385F                       1516 _ak820_outline_0125:
      00385F E5 82            [12] 1517 	mov	a,dpl
      003861 85 83 F0         [24] 1518 	mov	b,dph
      003864 22               [24] 1519 	ret
                                   1520 
                                   1521 	.area CSEG (CODE)
                                   1522 ; function ak820_outline_0127
      003865                       1523 _ak820_outline_0127:
      003865 F0               [24] 1524 	movx	@dptr,a
      003866 E4               [12] 1525 	clr	a
      003867 A3               [24] 1526 	inc	dptr
      003868 F0               [24] 1527 	movx	@dptr,a
      003869 22               [24] 1528 	ret
                                   1529 
                                   1530 	.area CSEG (CODE)
                                   1531 ; function ak820_outline_0137
      00386A                       1532 _ak820_outline_0137:
      00386A 8D 82            [24] 1533 	mov	dpl,r5
      00386C 8E 83            [24] 1534 	mov	dph,r6
      00386E 22               [24] 1535 	ret
                                   1536 
                                   1537 	.area CSEG (CODE)
                                   1538 ; function ak820_outline_0149
      00386F                       1539 _ak820_outline_0149:
      00386F E4               [12] 1540 	clr	a
      003870 33               [12] 1541 	rlc	a
      003871 F5 82            [12] 1542 	mov	dpl,a
      003873 22               [24] 1543 	ret
                                   1544 
                                   1545 	.area CSEG (CODE)
                                   1546 ; function ak820_outline_0158
      003874                       1547 _ak820_outline_0158:
      003874 88 82            [24] 1548 	mov	dpl,r0
      003876 89 83            [24] 1549 	mov	dph,r1
      003878 22               [24] 1550 	ret
                                   1551 
                                   1552 	.area CSEG (CODE)
                                   1553 ; function ak820_outline_0161
      003879                       1554 _ak820_outline_0161:
      003879 C4               [12] 1555 	swap	a
      00387A 03               [12] 1556 	rr	a
      00387B 54 F8            [12] 1557 	anl	a,#0xf8
      00387D 22               [24] 1558 	ret
                                   1559 
                                   1560 	.area CSEG (CODE)
                                   1561 ; function ak820_outline_0162
      00387E                       1562 _ak820_outline_0162:
      00387E 2D               [12] 1563 	add	a,r5
      00387F FD               [12] 1564 	mov	r5,a
      003880 E4               [12] 1565 	clr	a
      003881 3E               [12] 1566 	addc	a,r6
      003882 FE               [12] 1567 	mov	r6,a
      003883 22               [24] 1568 	ret
                                   1569 
                                   1570 	.area CSEG (CODE)
                                   1571 ; function ak820_outline_0172
      003884                       1572 _ak820_outline_0172:
      003884 E0               [24] 1573 	movx	a,@dptr
      003885 FC               [12] 1574 	mov	r4,a
      003886 A3               [24] 1575 	inc	dptr
      003887 E0               [24] 1576 	movx	a,@dptr
      003888 4C               [12] 1577 	orl	a,r4
      003889 22               [24] 1578 	ret
                                   1579 
                                   1580 	.area CSEG (CODE)
                                   1581 ; function ak820_outline_0186
      00388A                       1582 _ak820_outline_0186:
      00388A 90 0E 6E         [24] 1583 	mov	dptr,#_first
      00388D E0               [24] 1584 	movx	a,@dptr
      00388E 22               [24] 1585 	ret
                                   1586 
                                   1587 	.area CSEG (CODE)
                                   1588 ; function ak820_outline_0189
      00388F                       1589 _ak820_outline_0189:
      00388F 75 F0 04         [24] 1590 	mov	b,#0x04
      003892 A4               [48] 1591 	mul	ab
      003893 22               [24] 1592 	ret
