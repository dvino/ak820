                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module vialrgb
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _rgb_matrix_get_speed
                                     12 	.globl _rgb_matrix_set_speed_noeeprom
                                     13 	.globl _rgb_matrix_get_val
                                     14 	.globl _rgb_matrix_get_sat
                                     15 	.globl _rgb_matrix_get_hue
                                     16 	.globl _rgb_matrix_sethsv_noeeprom
                                     17 	.globl _rgb_matrix_get_mode
                                     18 	.globl _rgb_matrix_mode_noeeprom
                                     19 	.globl _rgb_matrix_is_enabled
                                     20 	.globl _rgb_matrix_disable_noeeprom
                                     21 	.globl _rgb_matrix_enable_noeeprom
                                     22 	.globl _eeconfig_update_rgb_matrix
                                     23 	.globl _ADC_START
                                     24 	.globl _S0_R_FIFO
                                     25 	.globl _S0_T_FIFO
                                     26 	.globl _S0_FREE
                                     27 	.globl _S0_IF_BYTE
                                     28 	.globl _S0_IF_FIRST
                                     29 	.globl _S0_IF_OV
                                     30 	.globl _S0_FST_ACT
                                     31 	.globl _CP_RL2
                                     32 	.globl _C_T2
                                     33 	.globl _TR2
                                     34 	.globl _EXEN2
                                     35 	.globl _TCLK
                                     36 	.globl _RCLK
                                     37 	.globl _EXF2
                                     38 	.globl _CAP1F
                                     39 	.globl _TF2
                                     40 	.globl _RI
                                     41 	.globl _TI
                                     42 	.globl _RB8
                                     43 	.globl _TB8
                                     44 	.globl _REN
                                     45 	.globl _SM2
                                     46 	.globl _SM1
                                     47 	.globl _SM0
                                     48 	.globl _IT0
                                     49 	.globl _IE0
                                     50 	.globl _IT1
                                     51 	.globl _IE1
                                     52 	.globl _TR0
                                     53 	.globl _TF0
                                     54 	.globl _TR1
                                     55 	.globl _TF1
                                     56 	.globl _P4_0
                                     57 	.globl _P4_1
                                     58 	.globl _P4_2
                                     59 	.globl _P4_3
                                     60 	.globl _P4_4
                                     61 	.globl _P4_5
                                     62 	.globl _P4_6
                                     63 	.globl _RXD
                                     64 	.globl _TXD
                                     65 	.globl _INT0
                                     66 	.globl _INT1
                                     67 	.globl _T0
                                     68 	.globl _T1
                                     69 	.globl _MOSI1
                                     70 	.globl _MISO1
                                     71 	.globl _SCK1
                                     72 	.globl _P3_0
                                     73 	.globl _P3_1
                                     74 	.globl _P3_2
                                     75 	.globl _P3_3
                                     76 	.globl _P3_4
                                     77 	.globl _P3_5
                                     78 	.globl _P3_6
                                     79 	.globl _P3_7
                                     80 	.globl _CAP1_
                                     81 	.globl _T2_
                                     82 	.globl _CAP2_
                                     83 	.globl _T2EX_
                                     84 	.globl _RXD1
                                     85 	.globl _TXD1
                                     86 	.globl _P2_0
                                     87 	.globl _P2_1
                                     88 	.globl _P2_2
                                     89 	.globl _P2_3
                                     90 	.globl _P2_4
                                     91 	.globl _P2_5
                                     92 	.globl _P2_6
                                     93 	.globl _P2_7
                                     94 	.globl _AIN0
                                     95 	.globl _AIN1
                                     96 	.globl _AIN2
                                     97 	.globl _AIN3
                                     98 	.globl _AIN4
                                     99 	.globl _AIN5
                                    100 	.globl _AIN6
                                    101 	.globl _AIN7
                                    102 	.globl _CAP1
                                    103 	.globl _T2
                                    104 	.globl _CAP2
                                    105 	.globl _T2EX
                                    106 	.globl _INT0_
                                    107 	.globl _SCS
                                    108 	.globl _MOSI
                                    109 	.globl _MISO
                                    110 	.globl _SCK
                                    111 	.globl _RXD1_
                                    112 	.globl _TXD1_
                                    113 	.globl _P1_0
                                    114 	.globl _P1_1
                                    115 	.globl _P1_2
                                    116 	.globl _P1_3
                                    117 	.globl _P1_4
                                    118 	.globl _P1_5
                                    119 	.globl _P1_6
                                    120 	.globl _P1_7
                                    121 	.globl _AIN8
                                    122 	.globl _AIN9
                                    123 	.globl _AIN10
                                    124 	.globl _AIN11
                                    125 	.globl _AIN12
                                    126 	.globl _AIN13
                                    127 	.globl _RXD_
                                    128 	.globl _TXD_
                                    129 	.globl _SCL0
                                    130 	.globl _SDA0
                                    131 	.globl _P0_0
                                    132 	.globl _P0_1
                                    133 	.globl _P0_2
                                    134 	.globl _P0_3
                                    135 	.globl _P0_4
                                    136 	.globl _P0_5
                                    137 	.globl _P0_6
                                    138 	.globl _P0_7
                                    139 	.globl _IE_SPI0
                                    140 	.globl _IE_USB
                                    141 	.globl _IE_ADC
                                    142 	.globl _IE_UART1
                                    143 	.globl _IE_PWM_I2C
                                    144 	.globl _IE_GPIO
                                    145 	.globl _IE_WDOG
                                    146 	.globl _PX0
                                    147 	.globl _PT0
                                    148 	.globl _PX1
                                    149 	.globl _PT1
                                    150 	.globl _PS
                                    151 	.globl _PT2
                                    152 	.globl _PL_FLAG
                                    153 	.globl _PH_FLAG
                                    154 	.globl _EX0
                                    155 	.globl _ET0
                                    156 	.globl _EX1
                                    157 	.globl _ET1
                                    158 	.globl _ES
                                    159 	.globl _ET2
                                    160 	.globl _E_DIS
                                    161 	.globl _EA
                                    162 	.globl _P
                                    163 	.globl _F1
                                    164 	.globl _OV
                                    165 	.globl _RS0
                                    166 	.globl _RS1
                                    167 	.globl _F0
                                    168 	.globl _AC
                                    169 	.globl _CY
                                    170 	.globl _I2CS_INT_ST
                                    171 	.globl _I2CX_INT
                                    172 	.globl _LED_STATUS
                                    173 	.globl _LED_DMA_H
                                    174 	.globl _LED_DMA_L
                                    175 	.globl _LED_DMA
                                    176 	.globl _LED_PWM_OE
                                    177 	.globl _LED_COMMON
                                    178 	.globl _ADC_CHAN
                                    179 	.globl _ADC_DAT_H
                                    180 	.globl _ADC_DAT_L
                                    181 	.globl _ADC_DAT
                                    182 	.globl _ADC_CTRL
                                    183 	.globl _SPI1_CK_SE
                                    184 	.globl _SPI1_CTRL
                                    185 	.globl _SPI1_DATA
                                    186 	.globl _SPI1_STAT
                                    187 	.globl _SIF1
                                    188 	.globl _SBAUD1
                                    189 	.globl _SBUF1
                                    190 	.globl _SCON1
                                    191 	.globl _SPI0_SETUP
                                    192 	.globl _SPI0_CK_SE
                                    193 	.globl _SPI0_CTRL
                                    194 	.globl _SPI0_DATA
                                    195 	.globl _SPI0_STAT
                                    196 	.globl _T2CAP1H
                                    197 	.globl _T2CAP1L
                                    198 	.globl _T2CAP1
                                    199 	.globl _TH2
                                    200 	.globl _TL2
                                    201 	.globl _T2COUNT
                                    202 	.globl _RCAP2H
                                    203 	.globl _RCAP2L
                                    204 	.globl _RCAP2
                                    205 	.globl _T2MOD
                                    206 	.globl _T2CON
                                    207 	.globl _SBUF
                                    208 	.globl _SCON
                                    209 	.globl _TH1
                                    210 	.globl _TH0
                                    211 	.globl _TL1
                                    212 	.globl _TL0
                                    213 	.globl _TMOD
                                    214 	.globl _TCON
                                    215 	.globl _XBUS_AUX
                                    216 	.globl _P7
                                    217 	.globl _P6_DIR
                                    218 	.globl _P6_OUT_PU
                                    219 	.globl _P6_IN
                                    220 	.globl _P5_DIR
                                    221 	.globl _P5_OUT_PU
                                    222 	.globl _P5_IN
                                    223 	.globl _P4_LED_KEY
                                    224 	.globl _P4_DIR_PU
                                    225 	.globl _P4_MOD_OC
                                    226 	.globl _P4
                                    227 	.globl _P3_DIR_PU
                                    228 	.globl _P3_MOD_OC
                                    229 	.globl _P3
                                    230 	.globl _P2_DIR_PU
                                    231 	.globl _P2_MOD_OC
                                    232 	.globl _P2
                                    233 	.globl _P1_DIR_PU
                                    234 	.globl _P1_MOD_OC
                                    235 	.globl _P1
                                    236 	.globl _P0_DIR_PU
                                    237 	.globl _P0_MOD_OC
                                    238 	.globl _P0
                                    239 	.globl _ROM_CTRL
                                    240 	.globl _ROM_DATA_HH
                                    241 	.globl _ROM_DATA_HL
                                    242 	.globl _ROM_DATA_HI
                                    243 	.globl _ROM_ADDR_H
                                    244 	.globl _ROM_ADDR_L
                                    245 	.globl _ROM_ADDR
                                    246 	.globl _GPIO_IE
                                    247 	.globl _IP_EX
                                    248 	.globl _IE_EX
                                    249 	.globl _IP
                                    250 	.globl _IE
                                    251 	.globl _WDOG_COUNT
                                    252 	.globl _RESET_KEEP
                                    253 	.globl _WAKE_CTRL
                                    254 	.globl _CLOCK_CFG
                                    255 	.globl _POWER_CFG
                                    256 	.globl _PCON
                                    257 	.globl _GLOBAL_CFG
                                    258 	.globl _SAFE_MOD
                                    259 	.globl _DPH
                                    260 	.globl _DPL
                                    261 	.globl _SP
                                    262 	.globl _A_INV
                                    263 	.globl _B
                                    264 	.globl _ACC
                                    265 	.globl _PSW
                                    266 	.globl _vialrgb_save_PARM_2
                                    267 	.globl _vialrgb_set_value_PARM_2
                                    268 	.globl _vialrgb_get_value_PARM_2
                                    269 	.globl _g_direct_mode_colors
                                    270 	.globl _vialrgb_get_value
                                    271 	.globl _vialrgb_set_value
                                    272 	.globl _vialrgb_save
                                    273 ;--------------------------------------------------------
                                    274 ; special function registers
                                    275 ;--------------------------------------------------------
                                    276 	.area RSEG    (ABS,DATA)
      000000                        277 	.org 0x0000
                           0000D0   278 _PSW	=	0x00d0
                           0000E0   279 _ACC	=	0x00e0
                           0000F0   280 _B	=	0x00f0
                           0000FD   281 _A_INV	=	0x00fd
                           000081   282 _SP	=	0x0081
                           000082   283 _DPL	=	0x0082
                           000083   284 _DPH	=	0x0083
                           0000A1   285 _SAFE_MOD	=	0x00a1
                           0000B1   286 _GLOBAL_CFG	=	0x00b1
                           000087   287 _PCON	=	0x0087
                           0000BA   288 _POWER_CFG	=	0x00ba
                           0000B9   289 _CLOCK_CFG	=	0x00b9
                           0000A9   290 _WAKE_CTRL	=	0x00a9
                           0000FE   291 _RESET_KEEP	=	0x00fe
                           0000FF   292 _WDOG_COUNT	=	0x00ff
                           0000A8   293 _IE	=	0x00a8
                           0000B8   294 _IP	=	0x00b8
                           0000E8   295 _IE_EX	=	0x00e8
                           0000E9   296 _IP_EX	=	0x00e9
                           0000B2   297 _GPIO_IE	=	0x00b2
                           008584   298 _ROM_ADDR	=	0x8584
                           000084   299 _ROM_ADDR_L	=	0x0084
                           000085   300 _ROM_ADDR_H	=	0x0085
                           008F8E   301 _ROM_DATA_HI	=	0x8f8e
                           00008E   302 _ROM_DATA_HL	=	0x008e
                           00008F   303 _ROM_DATA_HH	=	0x008f
                           000086   304 _ROM_CTRL	=	0x0086
                           000080   305 _P0	=	0x0080
                           0000C4   306 _P0_MOD_OC	=	0x00c4
                           0000C5   307 _P0_DIR_PU	=	0x00c5
                           000090   308 _P1	=	0x0090
                           000092   309 _P1_MOD_OC	=	0x0092
                           000093   310 _P1_DIR_PU	=	0x0093
                           0000A0   311 _P2	=	0x00a0
                           000094   312 _P2_MOD_OC	=	0x0094
                           000095   313 _P2_DIR_PU	=	0x0095
                           0000B0   314 _P3	=	0x00b0
                           000096   315 _P3_MOD_OC	=	0x0096
                           000097   316 _P3_DIR_PU	=	0x0097
                           0000C0   317 _P4	=	0x00c0
                           0000C2   318 _P4_MOD_OC	=	0x00c2
                           0000C3   319 _P4_DIR_PU	=	0x00c3
                           0000C1   320 _P4_LED_KEY	=	0x00c1
                           0000AA   321 _P5_IN	=	0x00aa
                           0000AB   322 _P5_OUT_PU	=	0x00ab
                           0000AC   323 _P5_DIR	=	0x00ac
                           0000AD   324 _P6_IN	=	0x00ad
                           0000AE   325 _P6_OUT_PU	=	0x00ae
                           0000AF   326 _P6_DIR	=	0x00af
                           0000F1   327 _P7	=	0x00f1
                           0000A2   328 _XBUS_AUX	=	0x00a2
                           000088   329 _TCON	=	0x0088
                           000089   330 _TMOD	=	0x0089
                           00008A   331 _TL0	=	0x008a
                           00008B   332 _TL1	=	0x008b
                           00008C   333 _TH0	=	0x008c
                           00008D   334 _TH1	=	0x008d
                           000098   335 _SCON	=	0x0098
                           000099   336 _SBUF	=	0x0099
                           0000C8   337 _T2CON	=	0x00c8
                           0000C9   338 _T2MOD	=	0x00c9
                           00CBCA   339 _RCAP2	=	0xcbca
                           0000CA   340 _RCAP2L	=	0x00ca
                           0000CB   341 _RCAP2H	=	0x00cb
                           00CDCC   342 _T2COUNT	=	0xcdcc
                           0000CC   343 _TL2	=	0x00cc
                           0000CD   344 _TH2	=	0x00cd
                           00CFCE   345 _T2CAP1	=	0xcfce
                           0000CE   346 _T2CAP1L	=	0x00ce
                           0000CF   347 _T2CAP1H	=	0x00cf
                           0000F8   348 _SPI0_STAT	=	0x00f8
                           0000F9   349 _SPI0_DATA	=	0x00f9
                           0000FA   350 _SPI0_CTRL	=	0x00fa
                           0000FB   351 _SPI0_CK_SE	=	0x00fb
                           0000FC   352 _SPI0_SETUP	=	0x00fc
                           0000BC   353 _SCON1	=	0x00bc
                           0000BD   354 _SBUF1	=	0x00bd
                           0000BE   355 _SBAUD1	=	0x00be
                           0000BF   356 _SIF1	=	0x00bf
                           0000B4   357 _SPI1_STAT	=	0x00b4
                           0000B5   358 _SPI1_DATA	=	0x00b5
                           0000B6   359 _SPI1_CTRL	=	0x00b6
                           0000B7   360 _SPI1_CK_SE	=	0x00b7
                           0000F3   361 _ADC_CTRL	=	0x00f3
                           00F5F4   362 _ADC_DAT	=	0xf5f4
                           0000F4   363 _ADC_DAT_L	=	0x00f4
                           0000F5   364 _ADC_DAT_H	=	0x00f5
                           0000F6   365 _ADC_CHAN	=	0x00f6
                           0000A6   366 _LED_COMMON	=	0x00a6
                           0000A7   367 _LED_PWM_OE	=	0x00a7
                           00C7C6   368 _LED_DMA	=	0xc7c6
                           0000C6   369 _LED_DMA_L	=	0x00c6
                           0000C7   370 _LED_DMA_H	=	0x00c7
                           0000F7   371 _LED_STATUS	=	0x00f7
                           0000B3   372 _I2CX_INT	=	0x00b3
                           0000BB   373 _I2CS_INT_ST	=	0x00bb
                                    374 ;--------------------------------------------------------
                                    375 ; special function bits
                                    376 ;--------------------------------------------------------
                                    377 	.area RSEG    (ABS,DATA)
      000000                        378 	.org 0x0000
                           0000D7   379 _CY	=	0x00d7
                           0000D6   380 _AC	=	0x00d6
                           0000D5   381 _F0	=	0x00d5
                           0000D4   382 _RS1	=	0x00d4
                           0000D3   383 _RS0	=	0x00d3
                           0000D2   384 _OV	=	0x00d2
                           0000D1   385 _F1	=	0x00d1
                           0000D0   386 _P	=	0x00d0
                           0000AF   387 _EA	=	0x00af
                           0000AE   388 _E_DIS	=	0x00ae
                           0000AD   389 _ET2	=	0x00ad
                           0000AC   390 _ES	=	0x00ac
                           0000AB   391 _ET1	=	0x00ab
                           0000AA   392 _EX1	=	0x00aa
                           0000A9   393 _ET0	=	0x00a9
                           0000A8   394 _EX0	=	0x00a8
                           0000BF   395 _PH_FLAG	=	0x00bf
                           0000BE   396 _PL_FLAG	=	0x00be
                           0000BD   397 _PT2	=	0x00bd
                           0000BC   398 _PS	=	0x00bc
                           0000BB   399 _PT1	=	0x00bb
                           0000BA   400 _PX1	=	0x00ba
                           0000B9   401 _PT0	=	0x00b9
                           0000B8   402 _PX0	=	0x00b8
                           0000EF   403 _IE_WDOG	=	0x00ef
                           0000EE   404 _IE_GPIO	=	0x00ee
                           0000ED   405 _IE_PWM_I2C	=	0x00ed
                           0000EC   406 _IE_UART1	=	0x00ec
                           0000EB   407 _IE_ADC	=	0x00eb
                           0000E9   408 _IE_USB	=	0x00e9
                           0000E8   409 _IE_SPI0	=	0x00e8
                           000087   410 _P0_7	=	0x0087
                           000086   411 _P0_6	=	0x0086
                           000085   412 _P0_5	=	0x0085
                           000084   413 _P0_4	=	0x0084
                           000083   414 _P0_3	=	0x0083
                           000082   415 _P0_2	=	0x0082
                           000081   416 _P0_1	=	0x0081
                           000080   417 _P0_0	=	0x0080
                           000081   418 _SDA0	=	0x0081
                           000080   419 _SCL0	=	0x0080
                           000083   420 _TXD_	=	0x0083
                           000082   421 _RXD_	=	0x0082
                           000085   422 _AIN13	=	0x0085
                           000084   423 _AIN12	=	0x0084
                           000083   424 _AIN11	=	0x0083
                           000082   425 _AIN10	=	0x0082
                           000081   426 _AIN9	=	0x0081
                           000080   427 _AIN8	=	0x0080
                           000097   428 _P1_7	=	0x0097
                           000096   429 _P1_6	=	0x0096
                           000095   430 _P1_5	=	0x0095
                           000094   431 _P1_4	=	0x0094
                           000093   432 _P1_3	=	0x0093
                           000092   433 _P1_2	=	0x0092
                           000091   434 _P1_1	=	0x0091
                           000090   435 _P1_0	=	0x0090
                           000097   436 _TXD1_	=	0x0097
                           000096   437 _RXD1_	=	0x0096
                           000097   438 _SCK	=	0x0097
                           000096   439 _MISO	=	0x0096
                           000095   440 _MOSI	=	0x0095
                           000094   441 _SCS	=	0x0094
                           000092   442 _INT0_	=	0x0092
                           000091   443 _T2EX	=	0x0091
                           000091   444 _CAP2	=	0x0091
                           000090   445 _T2	=	0x0090
                           000090   446 _CAP1	=	0x0090
                           000097   447 _AIN7	=	0x0097
                           000096   448 _AIN6	=	0x0096
                           000095   449 _AIN5	=	0x0095
                           000094   450 _AIN4	=	0x0094
                           000093   451 _AIN3	=	0x0093
                           000092   452 _AIN2	=	0x0092
                           000091   453 _AIN1	=	0x0091
                           000090   454 _AIN0	=	0x0090
                           0000A7   455 _P2_7	=	0x00a7
                           0000A6   456 _P2_6	=	0x00a6
                           0000A5   457 _P2_5	=	0x00a5
                           0000A4   458 _P2_4	=	0x00a4
                           0000A3   459 _P2_3	=	0x00a3
                           0000A2   460 _P2_2	=	0x00a2
                           0000A1   461 _P2_1	=	0x00a1
                           0000A0   462 _P2_0	=	0x00a0
                           0000A7   463 _TXD1	=	0x00a7
                           0000A6   464 _RXD1	=	0x00a6
                           0000A5   465 _T2EX_	=	0x00a5
                           0000A5   466 _CAP2_	=	0x00a5
                           0000A4   467 _T2_	=	0x00a4
                           0000A4   468 _CAP1_	=	0x00a4
                           0000B7   469 _P3_7	=	0x00b7
                           0000B6   470 _P3_6	=	0x00b6
                           0000B5   471 _P3_5	=	0x00b5
                           0000B4   472 _P3_4	=	0x00b4
                           0000B3   473 _P3_3	=	0x00b3
                           0000B2   474 _P3_2	=	0x00b2
                           0000B1   475 _P3_1	=	0x00b1
                           0000B0   476 _P3_0	=	0x00b0
                           0000B7   477 _SCK1	=	0x00b7
                           0000B6   478 _MISO1	=	0x00b6
                           0000B5   479 _MOSI1	=	0x00b5
                           0000B5   480 _T1	=	0x00b5
                           0000B4   481 _T0	=	0x00b4
                           0000B3   482 _INT1	=	0x00b3
                           0000B2   483 _INT0	=	0x00b2
                           0000B1   484 _TXD	=	0x00b1
                           0000B0   485 _RXD	=	0x00b0
                           0000C6   486 _P4_6	=	0x00c6
                           0000C5   487 _P4_5	=	0x00c5
                           0000C4   488 _P4_4	=	0x00c4
                           0000C3   489 _P4_3	=	0x00c3
                           0000C2   490 _P4_2	=	0x00c2
                           0000C1   491 _P4_1	=	0x00c1
                           0000C0   492 _P4_0	=	0x00c0
                           00008F   493 _TF1	=	0x008f
                           00008E   494 _TR1	=	0x008e
                           00008D   495 _TF0	=	0x008d
                           00008C   496 _TR0	=	0x008c
                           00008B   497 _IE1	=	0x008b
                           00008A   498 _IT1	=	0x008a
                           000089   499 _IE0	=	0x0089
                           000088   500 _IT0	=	0x0088
                           00009F   501 _SM0	=	0x009f
                           00009E   502 _SM1	=	0x009e
                           00009D   503 _SM2	=	0x009d
                           00009C   504 _REN	=	0x009c
                           00009B   505 _TB8	=	0x009b
                           00009A   506 _RB8	=	0x009a
                           000099   507 _TI	=	0x0099
                           000098   508 _RI	=	0x0098
                           0000CF   509 _TF2	=	0x00cf
                           0000CF   510 _CAP1F	=	0x00cf
                           0000CE   511 _EXF2	=	0x00ce
                           0000CD   512 _RCLK	=	0x00cd
                           0000CC   513 _TCLK	=	0x00cc
                           0000CB   514 _EXEN2	=	0x00cb
                           0000CA   515 _TR2	=	0x00ca
                           0000C9   516 _C_T2	=	0x00c9
                           0000C8   517 _CP_RL2	=	0x00c8
                           0000FF   518 _S0_FST_ACT	=	0x00ff
                           0000FE   519 _S0_IF_OV	=	0x00fe
                           0000FD   520 _S0_IF_FIRST	=	0x00fd
                           0000FC   521 _S0_IF_BYTE	=	0x00fc
                           0000FB   522 _S0_FREE	=	0x00fb
                           0000FA   523 _S0_T_FIFO	=	0x00fa
                           0000F8   524 _S0_R_FIFO	=	0x00f8
                           0000F7   525 _ADC_START	=	0x00f7
                                    526 ;--------------------------------------------------------
                                    527 ; overlayable register banks
                                    528 ;--------------------------------------------------------
                                    529 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        530 	.ds 8
                                    531 ;--------------------------------------------------------
                                    532 ; internal ram data
                                    533 ;--------------------------------------------------------
                                    534 	.area DSEG    (DATA)
      00004A                        535 _fast_set_leds_sloc0_1_0:
      00004A                        536 	.ds 2
      00004C                        537 _fast_set_leds_sloc1_1_0:
      00004C                        538 	.ds 2
      00004E                        539 _vialrgb_get_value_sloc0_1_0:
      00004E                        540 	.ds 2
      000050                        541 _vialrgb_get_value_sloc1_1_0:
      000050                        542 	.ds 2
      000052                        543 _vialrgb_set_value_sloc0_1_0:
      000052                        544 	.ds 2
                                    545 ;--------------------------------------------------------
                                    546 ; overlayable items in internal ram
                                    547 ;--------------------------------------------------------
                                    548 ;--------------------------------------------------------
                                    549 ; indirectly addressable internal ram data
                                    550 ;--------------------------------------------------------
                                    551 	.area ISEG    (DATA)
                                    552 ;--------------------------------------------------------
                                    553 ; absolute internal ram data
                                    554 ;--------------------------------------------------------
                                    555 	.area IABS    (ABS,DATA)
                                    556 	.area IABS    (ABS,DATA)
                                    557 ;--------------------------------------------------------
                                    558 ; bit data
                                    559 ;--------------------------------------------------------
                                    560 	.area BSEG    (BIT)
                                    561 ;--------------------------------------------------------
                                    562 ; paged external ram data
                                    563 ;--------------------------------------------------------
                                    564 	.area PSEG    (PAG,XDATA)
                                    565 ;--------------------------------------------------------
                                    566 ; uninitialized external ram data
                                    567 ;--------------------------------------------------------
                                    568 	.area XSEG    (XDATA)
      000D4C                        569 _g_direct_mode_colors::
      000D4C                        570 	.ds 246
      000E42                        571 _get_supported_PARM_2:
      000E42                        572 	.ds 1
      000E43                        573 _get_supported_args_10000_255:
      000E43                        574 	.ds 2
      000E45                        575 _qmk_id_to_vialrgb_id_id_10000_262:
      000E45                        576 	.ds 2
      000E47                        577 _vialrgb_id_to_qmk_id_id_10000_267:
      000E47                        578 	.ds 2
      000E49                        579 _set_mode_mode_10000_275:
      000E49                        580 	.ds 2
      000E4B                        581 _get_matrix_pos_for_led_PARM_2:
      000E4B                        582 	.ds 2
      000E4D                        583 _get_matrix_pos_for_led_led_10000_280:
      000E4D                        584 	.ds 2
      000E4F                        585 _fast_set_leds_PARM_2:
      000E4F                        586 	.ds 1
      000E50                        587 _fast_set_leds_args_10000_282:
      000E50                        588 	.ds 2
      000E52                        589 _fast_set_leds_first_index_10001_285:
      000E52                        590 	.ds 2
      000E54                        591 _fast_set_leds_num_leds_10001_285:
      000E54                        592 	.ds 1
      000E55                        593 _vialrgb_get_value_PARM_2:
      000E55                        594 	.ds 1
      000E56                        595 _vialrgb_get_value_data_10000_291:
      000E56                        596 	.ds 3
      000E59                        597 _vialrgb_set_value_PARM_2:
      000E59                        598 	.ds 1
      000E5A                        599 _vialrgb_set_value_data_10000_302:
      000E5A                        600 	.ds 3
      000E5D                        601 _vialrgb_save_PARM_2:
      000E5D                        602 	.ds 1
                                    603 ;--------------------------------------------------------
                                    604 ; absolute external ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area XABS    (ABS,XDATA)
                                    607 ;--------------------------------------------------------
                                    608 ; initialized external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area XISEG   (XDATA)
                                    611 	.area HOME    (CODE)
                                    612 	.area GSINIT0 (CODE)
                                    613 	.area GSINIT1 (CODE)
                                    614 	.area GSINIT2 (CODE)
                                    615 	.area GSINIT3 (CODE)
                                    616 	.area GSINIT4 (CODE)
                                    617 	.area GSINIT5 (CODE)
                                    618 	.area GSINIT  (CODE)
                                    619 	.area GSFINAL (CODE)
                                    620 	.area CSEG    (CODE)
                                    621 ;--------------------------------------------------------
                                    622 ; global & static initialisations
                                    623 ;--------------------------------------------------------
                                    624 	.area HOME    (CODE)
                                    625 	.area GSINIT  (CODE)
                                    626 	.area GSFINAL (CODE)
                                    627 	.area GSINIT  (CODE)
                                    628 ;--------------------------------------------------------
                                    629 ; Home
                                    630 ;--------------------------------------------------------
                                    631 	.area HOME    (CODE)
                                    632 	.area HOME    (CODE)
                                    633 ;--------------------------------------------------------
                                    634 ; code
                                    635 ;--------------------------------------------------------
                                    636 	.area CSEG    (CODE)
                                    637 ;------------------------------------------------------------
                                    638 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    639 ;------------------------------------------------------------
                                    640 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_167'
                                    641 ;------------------------------------------------------------
                                    642 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    643 ;	-----------------------------------------
                           000007   644 	ar7 = 0x07
                           000006   645 	ar6 = 0x06
                           000005   646 	ar5 = 0x05
                           000004   647 	ar4 = 0x04
                           000003   648 	ar3 = 0x03
                           000002   649 	ar2 = 0x02
                           000001   650 	ar1 = 0x01
                           000000   651 	ar0 = 0x00
                                    652 ;	 function get_supported
                                    653 ;	-----------------------------------------
      00B6F6                        654 _get_supported:
      00B6F6 12 38 4C         [24]  655 	lcall	_ak820_outline_0106
      00B6F9 90 0E 43         [24]  656 	mov	dptr,#_get_supported_args_10000_255
      00B6FC 12 38 47         [24]  657 	lcall	_ak820_outline_0105
                                    658 ;	quantum/vialrgb.c:44: uint16_t gt = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00B6FF 90 0E 43         [24]  659 	mov	dptr,#_get_supported_args_10000_255
      00B702 12 37 A8         [24]  660 	lcall	_ak820_outline_0005
      00B705 E0               [24]  661 	movx	a,@dptr
      00B706 FD               [12]  662 	mov	r5,a
      00B707 7C 00            [12]  663 	mov	r4,#0x00
      00B709 12 38 28         [24]  664 	lcall	_ak820_outline_0079
      00B70C FA               [12]  665 	mov	r2,a
      00B70D E4               [12]  666 	clr	a
      00B70E 12 43 32         [24]  667 	lcall	_ak820_outline_0142
                                    668 ;	quantum/vialrgb.c:45: for (uint8_t i = 0; i < length; ++i) args[i] = 0xff;
      00B711 90 0E 42         [24]  669 	mov	dptr,#_get_supported_PARM_2
      00B714 E0               [24]  670 	movx	a,@dptr
      00B715 FB               [12]  671 	mov	r3,a
      00B716 7A 00            [12]  672 	mov	r2,#0x00
      00B718                        673 00107$:
      00B718 C3               [12]  674 	clr	c
      00B719 EA               [12]  675 	mov	a,r2
      00B71A 9B               [12]  676 	subb	a,r3
      00B71B 50 0A            [24]  677 	jnc	00101$
      00B71D EA               [12]  678 	mov	a,r2
      00B71E 12 37 EF         [24]  679 	lcall	_ak820_outline_0035
      00B721 74 FF            [12]  680 	mov	a,#0xff
      00B723 F0               [24]  681 	movx	@dptr,a
      00B724 0A               [12]  682 	inc	r2
      00B725 80 F1            [24]  683 	sjmp	00107$
      00B727                        684 00101$:
                                    685 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B727 8D 06            [24]  686 	mov	ar6,r5
      00B729 8C 07            [24]  687 	mov	ar7,r4
      00B72B 8B 05            [24]  688 	mov	ar5,r3
      00B72D 90 0E 43         [24]  689 	mov	dptr,#_get_supported_args_10000_255
      00B730 12 38 41         [24]  690 	lcall	_ak820_outline_0103
      00B733 7A 00            [12]  691 	mov	r2,#0x00
      00B735                        692 00110$:
      00B735 BA 07 00         [24]  693 	cjne	r2,#0x07,00159$
      00B738                        694 00159$:
      00B738 50 46            [24]  695 	jnc	00127$
                                    696 ;	quantum/vialrgb.c:47: uint16_t id = READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00B73A EA               [12]  697 	mov	a,r2
      00B73B 75 F0 02         [24]  698 	mov	b,#0x02
      00B73E A4               [48]  699 	mul	ab
      00B73F 24 90            [12]  700 	add	a, #_supported_modes
      00B741 F5 82            [12]  701 	mov	dpl,a
      00B743 74 C3            [12]  702 	mov	a,#(_supported_modes >> 8)
      00B745 12 5B E8         [24]  703 	lcall	_ak820_outline_0110
      00B748 F8               [12]  704 	mov	r0,a
      00B749 79 00            [12]  705 	mov	r1,#0x00
                                    706 ;	quantum/vialrgb.c:48: if (id > gt && length >= sizeof(id)) {
      00B74B C3               [12]  707 	clr	c
      00B74C EE               [12]  708 	mov	a,r6
      00B74D 98               [12]  709 	subb	a,r0
      00B74E EF               [12]  710 	mov	a,r7
      00B74F 99               [12]  711 	subb	a,r1
      00B750 50 2B            [24]  712 	jnc	00111$
                                    713 ;	free result
      00B752 BD 02 00         [24]  714 	cjne	r5,#0x02,00162$
      00B755                        715 00162$:
      00B755 40 26            [24]  716 	jc	00111$
                                    717 ;	quantum/vialrgb.c:49: args[0] = id;
      00B757 C0 06            [24]  718 	push	ar6
      00B759 C0 07            [24]  719 	push	ar7
      00B75B 88 07            [24]  720 	mov	ar7,r0
      00B75D 12 33 FC         [24]  721 	lcall	_ak820_outline_0124
      00B760 EF               [12]  722 	mov	a,r7
      00B761 F0               [24]  723 	movx	@dptr,a
                                    724 ;	quantum/vialrgb.c:50: args[1] = id >> 8;
      00B762 12 33 FC         [24]  725 	lcall	_ak820_outline_0124
      00B765 A3               [24]  726 	inc	dptr
      00B766 89 00            [24]  727 	mov	ar0,r1
      00B768 E8               [12]  728 	mov	a,r0
      00B769 F0               [24]  729 	movx	@dptr,a
                                    730 ;	quantum/vialrgb.c:51: length -= sizeof(id);
      00B76A 1D               [12]  731 	dec	r5
      00B76B 1D               [12]  732 	dec	r5
                                    733 ;	quantum/vialrgb.c:52: args += sizeof(id);
      00B76C 74 02            [12]  734 	mov	a,#0x02
      00B76E 2B               [12]  735 	add	a, r3
      00B76F FB               [12]  736 	mov	r3,a
      00B770 E4               [12]  737 	clr	a
      00B771 3C               [12]  738 	addc	a, r4
      00B772 FC               [12]  739 	mov	r4,a
      00B773 90 0E 43         [24]  740 	mov	dptr,#_get_supported_args_10000_255
      00B776 12 38 2F         [24]  741 	lcall	_ak820_outline_0081
                                    742 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B779 D0 07            [24]  743 	pop	ar7
      00B77B D0 06            [24]  744 	pop	ar6
                                    745 ;	quantum/vialrgb.c:52: args += sizeof(id);
      00B77D                        746 00111$:
                                    747 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B77D 0A               [12]  748 	inc	r2
      00B77E 80 B5            [24]  749 	sjmp	00110$
      00B780                        750 00127$:
      00B780 90 0E 43         [24]  751 	mov	dptr,#_get_supported_args_10000_255
      00B783 12 38 2F         [24]  752 	lcall	_ak820_outline_0081
                                    753 ;	quantum/vialrgb.c:55: }
      00B786 22               [24]  754 	ret
                                    755 ;------------------------------------------------------------
                                    756 ;Allocation info for local variables in function 'qmk_id_to_vialrgb_id'
                                    757 ;------------------------------------------------------------
                                    758 ;id            Allocated with name '_qmk_id_to_vialrgb_id_id_10000_262'
                                    759 ;i             Allocated with name '_qmk_id_to_vialrgb_id_i_20000_264'
                                    760 ;qmk_id        Allocated with name '_qmk_id_to_vialrgb_id_qmk_id_30000_265'
                                    761 ;------------------------------------------------------------
                                    762 ;	quantum/vialrgb.c:57: static uint16_t qmk_id_to_vialrgb_id(uint16_t id) {
                                    763 ;	-----------------------------------------
                                    764 ;	 function qmk_id_to_vialrgb_id
                                    765 ;	-----------------------------------------
      00B787                        766 _qmk_id_to_vialrgb_id:
      00B787 12 38 4C         [24]  767 	lcall	_ak820_outline_0106
      00B78A 90 0E 45         [24]  768 	mov	dptr,#_qmk_id_to_vialrgb_id_id_10000_262
      00B78D 12 38 47         [24]  769 	lcall	_ak820_outline_0105
                                    770 ;	quantum/vialrgb.c:58: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B790 90 0E 45         [24]  771 	mov	dptr,#_qmk_id_to_vialrgb_id_id_10000_262
      00B793 12 37 F7         [24]  772 	lcall	_ak820_outline_0056
      00B796 7D 00            [12]  773 	mov	r5,#0x00
      00B798                        774 00105$:
      00B798 BD 07 00         [24]  775 	cjne	r5,#0x07,00130$
      00B79B                        776 00130$:
      00B79B 50 19            [24]  777 	jnc	00103$
                                    778 ;	quantum/vialrgb.c:59: uint16_t qmk_id = READ_MODE_ID(&supported_modes[i].qmk_id);
      00B79D 12 BB AF         [24]  779 	lcall	_ak820_outline_0051
      00B7A0 A3               [24]  780 	inc	dptr
      00B7A1 E4               [12]  781 	clr	a
      00B7A2 93               [24]  782 	movc	a,@a+dptr
                                    783 ;	quantum/vialrgb.c:60: if (qmk_id == id)
      00B7A3 7A 00            [12]  784 	mov	r2,#0x00
      00B7A5 B5 06 0B         [24]  785 	cjne	a,ar6,00106$
      00B7A8 EA               [12]  786 	mov	a,r2
      00B7A9 B5 07 07         [24]  787 	cjne	a,ar7,00106$
                                    788 ;	quantum/vialrgb.c:61: return READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00B7AC 12 33 FC         [24]  789 	lcall	_ak820_outline_0124
      00B7AF 12 BB DB         [24]  790 	lcall	_ak820_outline_0144
      00B7B2 22               [24]  791 	ret
      00B7B3                        792 00106$:
                                    793 ;	quantum/vialrgb.c:58: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B7B3 0D               [12]  794 	inc	r5
      00B7B4 80 E2            [24]  795 	sjmp	00105$
      00B7B6                        796 00103$:
                                    797 ;	quantum/vialrgb.c:63: return 0;
      00B7B6 90 00 00         [24]  798 	mov	dptr,#0x0000
                                    799 ;	quantum/vialrgb.c:64: }
      00B7B9 22               [24]  800 	ret
                                    801 ;------------------------------------------------------------
                                    802 ;Allocation info for local variables in function 'vialrgb_id_to_qmk_id'
                                    803 ;------------------------------------------------------------
                                    804 ;id            Allocated with name '_vialrgb_id_to_qmk_id_id_10000_267'
                                    805 ;i             Allocated with name '_vialrgb_id_to_qmk_id_i_20000_269'
                                    806 ;vialrgb_id    Allocated with name '_vialrgb_id_to_qmk_id_vialrgb_id_30000_270'
                                    807 ;------------------------------------------------------------
                                    808 ;	quantum/vialrgb.c:66: static uint16_t vialrgb_id_to_qmk_id(uint16_t id) {
                                    809 ;	-----------------------------------------
                                    810 ;	 function vialrgb_id_to_qmk_id
                                    811 ;	-----------------------------------------
      00B7BA                        812 _vialrgb_id_to_qmk_id:
      00B7BA 12 38 4C         [24]  813 	lcall	_ak820_outline_0106
      00B7BD 90 0E 47         [24]  814 	mov	dptr,#_vialrgb_id_to_qmk_id_id_10000_267
      00B7C0 12 38 47         [24]  815 	lcall	_ak820_outline_0105
                                    816 ;	quantum/vialrgb.c:67: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B7C3 90 0E 47         [24]  817 	mov	dptr,#_vialrgb_id_to_qmk_id_id_10000_267
      00B7C6 12 37 F7         [24]  818 	lcall	_ak820_outline_0056
      00B7C9 7D 00            [12]  819 	mov	r5,#0x00
      00B7CB                        820 00105$:
      00B7CB BD 07 00         [24]  821 	cjne	r5,#0x07,00130$
      00B7CE                        822 00130$:
      00B7CE 50 19            [24]  823 	jnc	00103$
                                    824 ;	quantum/vialrgb.c:68: uint16_t vialrgb_id = READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00B7D0 12 BB AF         [24]  825 	lcall	_ak820_outline_0051
      00B7D3 E4               [12]  826 	clr	a
      00B7D4 93               [24]  827 	movc	a,@a+dptr
                                    828 ;	quantum/vialrgb.c:69: if (vialrgb_id == id)
      00B7D5 7A 00            [12]  829 	mov	r2,#0x00
      00B7D7 B5 06 0C         [24]  830 	cjne	a,ar6,00106$
      00B7DA EA               [12]  831 	mov	a,r2
      00B7DB B5 07 08         [24]  832 	cjne	a,ar7,00106$
                                    833 ;	quantum/vialrgb.c:70: return READ_MODE_ID(&supported_modes[i].qmk_id);
      00B7DE 12 33 FC         [24]  834 	lcall	_ak820_outline_0124
      00B7E1 A3               [24]  835 	inc	dptr
      00B7E2 12 BB DB         [24]  836 	lcall	_ak820_outline_0144
      00B7E5 22               [24]  837 	ret
      00B7E6                        838 00106$:
                                    839 ;	quantum/vialrgb.c:67: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B7E6 0D               [12]  840 	inc	r5
      00B7E7 80 E2            [24]  841 	sjmp	00105$
      00B7E9                        842 00103$:
                                    843 ;	quantum/vialrgb.c:72: return 0;
      00B7E9 90 00 00         [24]  844 	mov	dptr,#0x0000
                                    845 ;	quantum/vialrgb.c:73: }
      00B7EC 22               [24]  846 	ret
                                    847 ;------------------------------------------------------------
                                    848 ;Allocation info for local variables in function 'get_mode'
                                    849 ;------------------------------------------------------------
                                    850 ;	quantum/vialrgb.c:75: static uint16_t get_mode(void) {
                                    851 ;	-----------------------------------------
                                    852 ;	 function get_mode
                                    853 ;	-----------------------------------------
      00B7ED                        854 _get_mode:
                                    855 ;	quantum/vialrgb.c:77: if (!rgb_matrix_is_enabled())
      00B7ED 12 59 EB         [24]  856 	lcall	_rgb_matrix_is_enabled
      00B7F0 E5 82            [12]  857 	mov	a, dpl
      00B7F2 70 04            [24]  858 	jnz	00102$
                                    859 ;	quantum/vialrgb.c:78: return VIALRGB_EFFECT_OFF;
      00B7F4 90 00 00         [24]  860 	mov	dptr,#0x0000
      00B7F7 22               [24]  861 	ret
      00B7F8                        862 00102$:
                                    863 ;	quantum/vialrgb.c:79: return qmk_id_to_vialrgb_id(rgb_matrix_get_mode());
      00B7F8 12 59 F1         [24]  864 	lcall	_rgb_matrix_get_mode
      00B7FB 7E 00            [12]  865 	mov	r6,#0x00
      00B7FD 8E 83            [24]  866 	mov	dph, r6
                                    867 ;	quantum/vialrgb.c:80: }
      00B7FF 02 B7 87         [24]  868 	ljmp	_qmk_id_to_vialrgb_id
                                    869 ;------------------------------------------------------------
                                    870 ;Allocation info for local variables in function 'set_mode'
                                    871 ;------------------------------------------------------------
                                    872 ;mode          Allocated with name '_set_mode_mode_10000_275'
                                    873 ;------------------------------------------------------------
                                    874 ;	quantum/vialrgb.c:82: static void set_mode(uint16_t mode) {
                                    875 ;	-----------------------------------------
                                    876 ;	 function set_mode
                                    877 ;	-----------------------------------------
      00B802                        878 _set_mode:
      00B802 12 38 4C         [24]  879 	lcall	_ak820_outline_0106
      00B805 90 0E 49         [24]  880 	mov	dptr,#_set_mode_mode_10000_275
      00B808 12 38 47         [24]  881 	lcall	_ak820_outline_0105
                                    882 ;	quantum/vialrgb.c:84: if (mode == VIALRGB_EFFECT_OFF) {
      00B80B 90 0E 49         [24]  883 	mov	dptr,#_set_mode_mode_10000_275
      00B80E 12 37 F7         [24]  884 	lcall	_ak820_outline_0056
      00B811 90 0E 49         [24]  885 	mov	dptr,#_set_mode_mode_10000_275
      00B814 12 48 AC         [24]  886 	lcall	_ak820_outline_0037
      00B817 70 03            [24]  887 	jnz	00102$
                                    888 ;	quantum/vialrgb.c:85: rgb_matrix_disable_noeeprom();
      00B819 02 5A 3E         [24]  889 	ljmp	_rgb_matrix_disable_noeeprom
      00B81C                        890 00102$:
                                    891 ;	quantum/vialrgb.c:87: rgb_matrix_enable_noeeprom();
      00B81C C0 07            [24]  892 	push	ar7
      00B81E C0 06            [24]  893 	push	ar6
      00B820 12 5A 2D         [24]  894 	lcall	_rgb_matrix_enable_noeeprom
      00B823 D0 06            [24]  895 	pop	ar6
      00B825 D0 07            [24]  896 	pop	ar7
                                    897 ;	quantum/vialrgb.c:88: rgb_matrix_mode_noeeprom(vialrgb_id_to_qmk_id(mode));
      00B827 12 43 23         [24]  898 	lcall	_ak820_outline_0119
      00B82A 12 B7 BA         [24]  899 	lcall	_vialrgb_id_to_qmk_id
                                    900 ;	quantum/vialrgb.c:90: }
      00B82D 02 5A 47         [24]  901 	ljmp	_rgb_matrix_mode_noeeprom
                                    902 ;------------------------------------------------------------
                                    903 ;Allocation info for local variables in function 'get_matrix_pos_for_led'
                                    904 ;------------------------------------------------------------
                                    905 ;output        Allocated with name '_get_matrix_pos_for_led_PARM_2'
                                    906 ;led           Allocated with name '_get_matrix_pos_for_led_led_10000_280'
                                    907 ;slot          Allocated with name '_get_matrix_pos_for_led_slot_10000_281'
                                    908 ;------------------------------------------------------------
                                    909 ;	quantum/vialrgb.c:93: static void get_matrix_pos_for_led(uint16_t led, uint8_t VIALRGB_BUFFER *output) {
                                    910 ;	-----------------------------------------
                                    911 ;	 function get_matrix_pos_for_led
                                    912 ;	-----------------------------------------
      00B830                        913 _get_matrix_pos_for_led:
      00B830 12 38 4C         [24]  914 	lcall	_ak820_outline_0106
      00B833 90 0E 4D         [24]  915 	mov	dptr,#_get_matrix_pos_for_led_led_10000_280
      00B836 12 38 47         [24]  916 	lcall	_ak820_outline_0105
                                    917 ;	quantum/vialrgb.c:95: uint8_t slot = ak820_rgb_slots[led];
      00B839 90 0E 4D         [24]  918 	mov	dptr,#_get_matrix_pos_for_led_led_10000_280
      00B83C 12 37 F7         [24]  919 	lcall	_ak820_outline_0056
      00B83F EE               [12]  920 	mov	a,r6
      00B840 24 97            [12]  921 	add	a, #_ak820_rgb_slots
      00B842 F5 82            [12]  922 	mov	dpl,a
      00B844 EF               [12]  923 	mov	a,r7
      00B845 34 BD            [12]  924 	addc	a, #(_ak820_rgb_slots >> 8)
      00B847 F5 83            [12]  925 	mov	dph,a
      00B849 E4               [12]  926 	clr	a
      00B84A 93               [24]  927 	movc	a,@a+dptr
      00B84B FF               [12]  928 	mov	r7,a
                                    929 ;	quantum/vialrgb.c:96: output[0] = slot >> 3;
      00B84C 90 0E 4B         [24]  930 	mov	dptr,#_get_matrix_pos_for_led_PARM_2
      00B84F 12 43 11         [24]  931 	lcall	_ak820_outline_0098
      00B852 EF               [12]  932 	mov	a,r7
      00B853 12 5C 1E         [24]  933 	lcall	_ak820_outline_0188
      00B856 12 84 EC         [24]  934 	lcall	_ak820_outline_0126
                                    935 ;	quantum/vialrgb.c:97: output[1] = slot & 7;
      00B859 12 38 61         [24]  936 	lcall	_ak820_outline_0137
      00B85C A3               [24]  937 	inc	dptr
      00B85D 53 07 07         [24]  938 	anl	ar7,#0x07
      00B860 EF               [12]  939 	mov	a,r7
      00B861 F0               [24]  940 	movx	@dptr,a
                                    941 ;	quantum/vialrgb.c:110: }
      00B862 22               [24]  942 	ret
                                    943 ;------------------------------------------------------------
                                    944 ;Allocation info for local variables in function 'fast_set_leds'
                                    945 ;------------------------------------------------------------
                                    946 ;sloc0         Allocated with name '_fast_set_leds_sloc0_1_0'
                                    947 ;sloc1         Allocated with name '_fast_set_leds_sloc1_1_0'
                                    948 ;length        Allocated with name '_fast_set_leds_PARM_2'
                                    949 ;args          Allocated with name '_fast_set_leds_args_10000_282'
                                    950 ;first_index   Allocated with name '_fast_set_leds_first_index_10001_285'
                                    951 ;num_leds      Allocated with name '_fast_set_leds_num_leds_10001_285'
                                    952 ;i             Allocated with name '_fast_set_leds_i_20001_288'
                                    953 ;color         Allocated with name '_fast_set_leds_color_30001_289'
                                    954 ;val           Allocated with name '_fast_set_leds_val_30002_290'
                                    955 ;------------------------------------------------------------
                                    956 ;	quantum/vialrgb.c:112: static void fast_set_leds(uint8_t VIALRGB_BUFFER *args, uint8_t length) {
                                    957 ;	-----------------------------------------
                                    958 ;	 function fast_set_leds
                                    959 ;	-----------------------------------------
      00B863                        960 _fast_set_leds:
      00B863 12 38 4C         [24]  961 	lcall	_ak820_outline_0106
      00B866 90 0E 50         [24]  962 	mov	dptr,#_fast_set_leds_args_10000_282
      00B869 12 38 47         [24]  963 	lcall	_ak820_outline_0105
                                    964 ;	quantum/vialrgb.c:115: if (length < 3) return;
      00B86C 90 0E 4F         [24]  965 	mov	dptr,#_fast_set_leds_PARM_2
      00B86F E0               [24]  966 	movx	a,@dptr
      00B870 FF               [12]  967 	mov	r7,a
      00B871 BF 03 00         [24]  968 	cjne	r7,#0x03,00159$
      00B874                        969 00159$:
      00B874 50 01            [24]  970 	jnc	00102$
      00B876 22               [24]  971 	ret
      00B877                        972 00102$:
                                    973 ;	quantum/vialrgb.c:117: uint16_t first_index = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00B877 90 0E 50         [24]  974 	mov	dptr,#_fast_set_leds_args_10000_282
      00B87A 12 43 11         [24]  975 	lcall	_ak820_outline_0098
      00B87D 12 4D AE         [24]  976 	lcall	_ak820_outline_0078
      00B880 7B 00            [12]  977 	mov	r3,#0x00
      00B882 12 38 61         [24]  978 	lcall	_ak820_outline_0137
      00B885 A3               [24]  979 	inc	dptr
      00B886 E0               [24]  980 	movx	a,@dptr
      00B887 FA               [12]  981 	mov	r2,a
      00B888 79 00            [12]  982 	mov	r1,#0x00
      00B88A 90 0E 52         [24]  983 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00B88D E9               [12]  984 	mov	a,r1
      00B88E 4C               [12]  985 	orl	a,r4
      00B88F F0               [24]  986 	movx	@dptr,a
      00B890 EA               [12]  987 	mov	a,r2
      00B891 4B               [12]  988 	orl	a,r3
      00B892 A3               [24]  989 	inc	dptr
      00B893 F0               [24]  990 	movx	@dptr,a
                                    991 ;	quantum/vialrgb.c:118: uint8_t num_leds = args[2];
      00B894 12 38 61         [24]  992 	lcall	_ak820_outline_0137
      00B897 A3               [24]  993 	inc	dptr
      00B898 A3               [24]  994 	inc	dptr
      00B899 E0               [24]  995 	movx	a,@dptr
      00B89A 90 0E 54         [24]  996 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B89D F0               [24]  997 	movx	@dptr,a
                                    998 ;	quantum/vialrgb.c:119: length -= 3;
      00B89E EF               [12]  999 	mov	a,r7
      00B89F 24 FD            [12] 1000 	add	a,#0xfd
      00B8A1 90 0E 4F         [24] 1001 	mov	dptr,#_fast_set_leds_PARM_2
      00B8A4 F0               [24] 1002 	movx	@dptr,a
                                   1003 ;	quantum/vialrgb.c:120: args += 3;
      00B8A5 90 0E 50         [24] 1004 	mov	dptr,#_fast_set_leds_args_10000_282
      00B8A8 74 03            [12] 1005 	mov	a,#0x03
      00B8AA 2D               [12] 1006 	add	a, r5
      00B8AB F0               [24] 1007 	movx	@dptr,a
      00B8AC E4               [12] 1008 	clr	a
      00B8AD 3E               [12] 1009 	addc	a, r6
      00B8AE A3               [24] 1010 	inc	dptr
      00B8AF F0               [24] 1011 	movx	@dptr,a
                                   1012 ;	quantum/vialrgb.c:123: if ((uint16_t)num_leds * 3u > length || first_index >= RGB_MATRIX_LED_COUNT) return;
      00B8B0 90 0E 54         [24] 1013 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B8B3 E0               [24] 1014 	movx	a,@dptr
      00B8B4 FF               [12] 1015 	mov	r7,a
      00B8B5 75 F0 03         [24] 1016 	mov	b,#0x03
      00B8B8 A4               [48] 1017 	mul	ab
      00B8B9 FE               [12] 1018 	mov	r6,a
      00B8BA AD F0            [24] 1019 	mov	r5,b
      00B8BC 90 0E 4F         [24] 1020 	mov	dptr,#_fast_set_leds_PARM_2
      00B8BF E0               [24] 1021 	movx	a,@dptr
      00B8C0 FB               [12] 1022 	mov	r3,a
      00B8C1 7C 00            [12] 1023 	mov	r4,#0x00
      00B8C3 C3               [12] 1024 	clr	c
      00B8C4 EB               [12] 1025 	mov	a,r3
      00B8C5 9E               [12] 1026 	subb	a,r6
      00B8C6 EC               [12] 1027 	mov	a,r4
      00B8C7 9D               [12] 1028 	subb	a,r5
      00B8C8 40 13            [24] 1029 	jc	00103$
                                   1030 ;	free result
      00B8CA 90 0E 52         [24] 1031 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00B8CD 12 43 11         [24] 1032 	lcall	_ak820_outline_0098
      00B8D0 8D 03            [24] 1033 	mov	ar3,r5
      00B8D2 8E 04            [24] 1034 	mov	ar4,r6
      00B8D4 C3               [12] 1035 	clr	c
      00B8D5 EB               [12] 1036 	mov	a,r3
      00B8D6 94 52            [12] 1037 	subb	a,#0x52
      00B8D8 EC               [12] 1038 	mov	a,r4
      00B8D9 94 00            [12] 1039 	subb	a,#0x00
      00B8DB 40 01            [24] 1040 	jc	00104$
      00B8DD                       1041 00103$:
      00B8DD 22               [24] 1042 	ret
      00B8DE                       1043 00104$:
                                   1044 ;	quantum/vialrgb.c:124: if (num_leds > RGB_MATRIX_LED_COUNT - first_index) num_leds = RGB_MATRIX_LED_COUNT - first_index;
      00B8DE 74 52            [12] 1045 	mov	a,#0x52
      00B8E0 C3               [12] 1046 	clr	c
      00B8E1 9D               [12] 1047 	subb	a,r5
      00B8E2 FB               [12] 1048 	mov	r3,a
      00B8E3 E4               [12] 1049 	clr	a
      00B8E4 9E               [12] 1050 	subb	a,r6
      00B8E5 FC               [12] 1051 	mov	r4,a
      00B8E6 7A 00            [12] 1052 	mov	r2,#0x00
      00B8E8 C3               [12] 1053 	clr	c
      00B8E9 EB               [12] 1054 	mov	a,r3
      00B8EA 9F               [12] 1055 	subb	a,r7
      00B8EB EC               [12] 1056 	mov	a,r4
      00B8EC 9A               [12] 1057 	subb	a,r2
      00B8ED 50 08            [24] 1058 	jnc	00127$
                                   1059 ;	free result
      00B8EF 90 0E 54         [24] 1060 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B8F2 74 52            [12] 1061 	mov	a,#0x52
      00B8F4 C3               [12] 1062 	clr	c
      00B8F5 9D               [12] 1063 	subb	a,r5
      00B8F6 F0               [24] 1064 	movx	@dptr,a
                                   1065 ;	quantum/vialrgb.c:126: for (uint8_t i = 0; i < num_leds; ++i) {
      00B8F7                       1066 00127$:
      00B8F7 90 0E 54         [24] 1067 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B8FA E0               [24] 1068 	movx	a,@dptr
      00B8FB FF               [12] 1069 	mov	r7,a
      00B8FC 90 0E 52         [24] 1070 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00B8FF 12 43 11         [24] 1071 	lcall	_ak820_outline_0098
      00B902 7C 00            [12] 1072 	mov	r4,#0x00
      00B904                       1073 00110$:
      00B904 C3               [12] 1074 	clr	c
      00B905 EC               [12] 1075 	mov	a,r4
      00B906 9F               [12] 1076 	subb	a,r7
      00B907 40 01            [24] 1077 	jc	00164$
      00B909 22               [24] 1078 	ret
      00B90A                       1079 00164$:
                                   1080 ;	quantum/vialrgb.c:127: HSV VIALRGB_BUFFER *color = &g_direct_mode_colors[first_index++];
      00B90A C0 07            [24] 1081 	push	ar7
      00B90C 90 0E 6C         [24] 1082 	mov	dptr,#__mulint_PARM_2
      00B90F 12 43 4D         [24] 1083 	lcall	_ak820_outline_0164
      00B912 90 00 03         [24] 1084 	mov	dptr,#0x0003
      00B915 C0 07            [24] 1085 	push	ar7
      00B917 C0 06            [24] 1086 	push	ar6
      00B919 C0 05            [24] 1087 	push	ar5
      00B91B C0 04            [24] 1088 	push	ar4
      00B91D B1 47            [12] 1089 	acall	__mulint
      00B91F AA 82            [24] 1090 	mov	r2, dpl
      00B921 AB 83            [24] 1091 	mov	r3, dph
      00B923 D0 04            [24] 1092 	pop	ar4
      00B925 D0 05            [24] 1093 	pop	ar5
      00B927 D0 06            [24] 1094 	pop	ar6
      00B929 D0 07            [24] 1095 	pop	ar7
      00B92B 0D               [12] 1096 	inc	r5
      00B92C BD 00 01         [24] 1097 	cjne	r5,#0x00,00165$
      00B92F 0E               [12] 1098 	inc	r6
      00B930                       1099 00165$:
      00B930 EA               [12] 1100 	mov	a,r2
      00B931 24 4C            [12] 1101 	add	a, #_g_direct_mode_colors
      00B933 FA               [12] 1102 	mov	r2,a
      00B934 EB               [12] 1103 	mov	a,r3
      00B935 34 0D            [12] 1104 	addc	a, #(_g_direct_mode_colors >> 8)
      00B937 FB               [12] 1105 	mov	r3,a
                                   1106 ;	quantum/vialrgb.c:128: color->h = *args++;
      00B938 8A 4A            [24] 1107 	mov	_fast_set_leds_sloc0_1_0,r2
      00B93A 8B 4B            [24] 1108 	mov	(_fast_set_leds_sloc0_1_0 + 1),r3
      00B93C 12 BB C1         [24] 1109 	lcall	_ak820_outline_0087
      00B93F F8               [12] 1110 	mov	r0,a
      00B940 12 BB CF         [24] 1111 	lcall	_ak820_outline_0109
      00B943 85 4A 82         [24] 1112 	mov	dpl,_fast_set_leds_sloc0_1_0
      00B946 85 4B 83         [24] 1113 	mov	dph,(_fast_set_leds_sloc0_1_0 + 1)
      00B949 E8               [12] 1114 	mov	a,r0
      00B94A F0               [24] 1115 	movx	@dptr,a
                                   1116 ;	quantum/vialrgb.c:129: color->s = *args++;
      00B94B 74 01            [12] 1117 	mov	a,#0x01
      00B94D 2A               [12] 1118 	add	a, r2
      00B94E F5 4A            [12] 1119 	mov	_fast_set_leds_sloc0_1_0,a
      00B950 E4               [12] 1120 	clr	a
      00B951 3B               [12] 1121 	addc	a, r3
      00B952 F5 4B            [12] 1122 	mov	(_fast_set_leds_sloc0_1_0 + 1),a
      00B954 90 0E 50         [24] 1123 	mov	dptr,#_fast_set_leds_args_10000_282
      00B957 E0               [24] 1124 	movx	a,@dptr
      00B958 F8               [12] 1125 	mov	r0,a
      00B959 A3               [24] 1126 	inc	dptr
      00B95A E0               [24] 1127 	movx	a,@dptr
      00B95B FF               [12] 1128 	mov	r7,a
      00B95C 88 82            [24] 1129 	mov	dpl,r0
      00B95E 8F 83            [24] 1130 	mov	dph,r7
      00B960 E0               [24] 1131 	movx	a,@dptr
      00B961 F9               [12] 1132 	mov	r1,a
      00B962 90 0E 50         [24] 1133 	mov	dptr,#_fast_set_leds_args_10000_282
      00B965 74 01            [12] 1134 	mov	a,#0x01
      00B967 28               [12] 1135 	add	a, r0
      00B968 F0               [24] 1136 	movx	@dptr,a
      00B969 E4               [12] 1137 	clr	a
      00B96A 3F               [12] 1138 	addc	a, r7
      00B96B A3               [24] 1139 	inc	dptr
      00B96C F0               [24] 1140 	movx	@dptr,a
      00B96D 85 4A 82         [24] 1141 	mov	dpl,_fast_set_leds_sloc0_1_0
      00B970 85 4B 83         [24] 1142 	mov	dph,(_fast_set_leds_sloc0_1_0 + 1)
      00B973 E9               [12] 1143 	mov	a,r1
      00B974 F0               [24] 1144 	movx	@dptr,a
                                   1145 ;	quantum/vialrgb.c:130: uint8_t val = *args++;
      00B975 12 BB C1         [24] 1146 	lcall	_ak820_outline_0087
      00B978 F5 4A            [12] 1147 	mov	_fast_set_leds_sloc0_1_0,a
      00B97A 12 BB CF         [24] 1148 	lcall	_ak820_outline_0109
                                   1149 ;	quantum/vialrgb.c:131: color->v = (val > RGB_MATRIX_MAXIMUM_BRIGHTNESS) ? RGB_MATRIX_MAXIMUM_BRIGHTNESS : val;
      00B97D 74 02            [12] 1150 	mov	a,#0x02
      00B97F 2A               [12] 1151 	add	a, r2
      00B980 F5 4C            [12] 1152 	mov	_fast_set_leds_sloc1_1_0,a
      00B982 E4               [12] 1153 	clr	a
      00B983 3B               [12] 1154 	addc	a, r3
      00B984 F5 4D            [12] 1155 	mov	(_fast_set_leds_sloc1_1_0 + 1),a
      00B986 C3               [12] 1156 	clr	c
      00B987 74 A0            [12] 1157 	mov	a,#0xa0
      00B989 95 4A            [12] 1158 	subb	a,_fast_set_leds_sloc0_1_0
      00B98B D0 07            [24] 1159 	pop	ar7
      00B98D 50 04            [24] 1160 	jnc	00114$
                                   1161 ;	free result
      00B98F 7B A0            [12] 1162 	mov	r3,#0xa0
      00B991 80 04            [24] 1163 	sjmp	00115$
      00B993                       1164 00114$:
      00B993 AA 4A            [24] 1165 	mov	r2,_fast_set_leds_sloc0_1_0
      00B995 8A 03            [24] 1166 	mov	ar3,r2
      00B997                       1167 00115$:
      00B997 85 4C 82         [24] 1168 	mov	dpl,_fast_set_leds_sloc1_1_0
      00B99A 85 4D 83         [24] 1169 	mov	dph,(_fast_set_leds_sloc1_1_0 + 1)
      00B99D EB               [12] 1170 	mov	a,r3
      00B99E F0               [24] 1171 	movx	@dptr,a
                                   1172 ;	quantum/vialrgb.c:126: for (uint8_t i = 0; i < num_leds; ++i) {
      00B99F 0C               [12] 1173 	inc	r4
                                   1174 ;	quantum/vialrgb.c:133: }
      00B9A0 21 04            [24] 1175 	ajmp	00110$
                                   1176 ;------------------------------------------------------------
                                   1177 ;Allocation info for local variables in function 'vialrgb_get_value'
                                   1178 ;------------------------------------------------------------
                                   1179 ;sloc0         Allocated with name '_vialrgb_get_value_sloc0_1_0'
                                   1180 ;sloc1         Allocated with name '_vialrgb_get_value_sloc1_1_0'
                                   1181 ;length        Allocated with name '_vialrgb_get_value_PARM_2'
                                   1182 ;data          Allocated with name '_vialrgb_get_value_data_10000_291'
                                   1183 ;args          Allocated with name '_vialrgb_get_value_args_10001_294'
                                   1184 ;cmd           Allocated with name '_vialrgb_get_value_cmd_10001_294'
                                   1185 ;vialrgb_id    Allocated with name '_vialrgb_get_value_vialrgb_id_40001_297'
                                   1186 ;led           Allocated with name '_vialrgb_get_value_led_40001_300'
                                   1187 ;------------------------------------------------------------
                                   1188 ;	quantum/vialrgb.c:136: void vialrgb_get_value(uint8_t *data, uint8_t length) {
                                   1189 ;	-----------------------------------------
                                   1190 ;	 function vialrgb_get_value
                                   1191 ;	-----------------------------------------
      00B9A2                       1192 _vialrgb_get_value:
      00B9A2 12 42 D4         [24] 1193 	lcall	_ak820_outline_0042
      00B9A5 90 0E 56         [24] 1194 	mov	dptr,#_vialrgb_get_value_data_10000_291
      00B9A8 12 37 DF         [24] 1195 	lcall	_ak820_outline_0018
                                   1196 ;	quantum/vialrgb.c:137: if (length != VIAL_RAW_EPSIZE) return;
      00B9AB 90 0E 55         [24] 1197 	mov	dptr,#_vialrgb_get_value_PARM_2
      00B9AE E0               [24] 1198 	movx	a,@dptr
      00B9AF FF               [12] 1199 	mov	r7,a
      00B9B0 BF 20 02         [24] 1200 	cjne	r7,#0x20,00162$
      00B9B3 80 01            [24] 1201 	sjmp	00102$
      00B9B5                       1202 00162$:
      00B9B5 22               [24] 1203 	ret
      00B9B6                       1204 00102$:
                                   1205 ;	quantum/vialrgb.c:140: uint8_t VIALRGB_BUFFER *args = (uint8_t VIALRGB_BUFFER *)data + 2;
      00B9B6 90 0E 56         [24] 1206 	mov	dptr,#_vialrgb_get_value_data_10000_291
      00B9B9 12 BB 9B         [24] 1207 	lcall	_ak820_outline_0048
                                   1208 ;	quantum/vialrgb.c:141: uint8_t cmd = args[-1];
                                   1209 ;	quantum/vialrgb.c:142: switch (cmd) {
      00B9BC BA 40 02         [24] 1210 	cjne	r2,#0x40,00163$
      00B9BF 80 15            [24] 1211 	sjmp	00103$
      00B9C1                       1212 00163$:
      00B9C1 BA 41 02         [24] 1213 	cjne	r2,#0x41,00164$
      00B9C4 80 23            [24] 1214 	sjmp	00104$
      00B9C6                       1215 00164$:
      00B9C6 BA 42 02         [24] 1216 	cjne	r2,#0x42,00165$
      00B9C9 41 7B            [12] 1217 	ajmp	00105$
      00B9CB                       1218 00165$:
      00B9CB BA 43 02         [24] 1219 	cjne	r2,#0x43,00166$
      00B9CE 41 88            [12] 1220 	ajmp	00106$
      00B9D0                       1221 00166$:
      00B9D0 BA 44 02         [24] 1222 	cjne	r2,#0x44,00167$
      00B9D3 41 94            [12] 1223 	ajmp	00107$
      00B9D5                       1224 00167$:
      00B9D5 22               [24] 1225 	ret
                                   1226 ;	quantum/vialrgb.c:143: case vialrgb_get_info:
      00B9D6                       1227 00103$:
                                   1228 ;	quantum/vialrgb.c:144: args[0] = VIALRGB_PROTOCOL_VERSION & 0xFF;
      00B9D6 12 33 FC         [24] 1229 	lcall	_ak820_outline_0124
      00B9D9 74 01            [12] 1230 	mov	a,#0x01
      00B9DB F0               [24] 1231 	movx	@dptr,a
                                   1232 ;	quantum/vialrgb.c:145: args[1] = VIALRGB_PROTOCOL_VERSION >> 8;
      00B9DC 12 48 B4         [24] 1233 	lcall	_ak820_outline_0040
      00B9DF E4               [12] 1234 	clr	a
      00B9E0 F0               [24] 1235 	movx	@dptr,a
                                   1236 ;	quantum/vialrgb.c:146: args[2] = RGB_MATRIX_MAXIMUM_BRIGHTNESS;
      00B9E1 12 48 B4         [24] 1237 	lcall	_ak820_outline_0040
      00B9E4 A3               [24] 1238 	inc	dptr
      00B9E5 74 A0            [12] 1239 	mov	a,#0xa0
      00B9E7 F0               [24] 1240 	movx	@dptr,a
                                   1241 ;	quantum/vialrgb.c:147: break;
      00B9E8 22               [24] 1242 	ret
                                   1243 ;	quantum/vialrgb.c:148: case vialrgb_get_mode: {
      00B9E9                       1244 00104$:
                                   1245 ;	quantum/vialrgb.c:149: uint16_t vialrgb_id = get_mode();
      00B9E9 C0 06            [24] 1246 	push	ar6
      00B9EB C0 05            [24] 1247 	push	ar5
      00B9ED C0 04            [24] 1248 	push	ar4
      00B9EF C0 03            [24] 1249 	push	ar3
      00B9F1 12 B7 ED         [24] 1250 	lcall	_get_mode
      00B9F4 A9 82            [24] 1251 	mov	r1, dpl
      00B9F6 AA 83            [24] 1252 	mov	r2, dph
      00B9F8 D0 03            [24] 1253 	pop	ar3
      00B9FA D0 04            [24] 1254 	pop	ar4
      00B9FC D0 05            [24] 1255 	pop	ar5
      00B9FE D0 06            [24] 1256 	pop	ar6
                                   1257 ;	quantum/vialrgb.c:150: args[0] = vialrgb_id & 0xFF;
      00BA00 89 00            [24] 1258 	mov	ar0,r1
      00BA02 12 33 FC         [24] 1259 	lcall	_ak820_outline_0124
      00BA05 E8               [12] 1260 	mov	a,r0
      00BA06 F0               [24] 1261 	movx	@dptr,a
                                   1262 ;	quantum/vialrgb.c:151: args[1] = vialrgb_id >> 8;
      00BA07 12 48 B4         [24] 1263 	lcall	_ak820_outline_0040
      00BA0A 8A 01            [24] 1264 	mov	ar1,r2
      00BA0C E9               [12] 1265 	mov	a,r1
      00BA0D F0               [24] 1266 	movx	@dptr,a
                                   1267 ;	quantum/vialrgb.c:152: args[2] = rgb_matrix_get_speed();
      00BA0E 74 04            [12] 1268 	mov	a,#0x04
      00BA10 12 93 C3         [24] 1269 	lcall	_ak820_outline_0138
      00BA13 C0 06            [24] 1270 	push	ar6
      00BA15 C0 05            [24] 1271 	push	ar5
      00BA17 C0 02            [24] 1272 	push	ar2
      00BA19 C0 01            [24] 1273 	push	ar1
      00BA1B 12 5A 0C         [24] 1274 	lcall	_rgb_matrix_get_speed
      00BA1E A8 82            [24] 1275 	mov	r0, dpl
      00BA20 D0 01            [24] 1276 	pop	ar1
      00BA22 D0 02            [24] 1277 	pop	ar2
      00BA24 D0 05            [24] 1278 	pop	ar5
      00BA26 D0 06            [24] 1279 	pop	ar6
      00BA28 12 48 C4         [24] 1280 	lcall	_ak820_outline_0063
                                   1281 ;	quantum/vialrgb.c:153: args[3] = rgb_matrix_get_hue();
      00BA2B 74 05            [12] 1282 	mov	a,#0x05
      00BA2D 12 93 C3         [24] 1283 	lcall	_ak820_outline_0138
      00BA30 C0 06            [24] 1284 	push	ar6
      00BA32 C0 05            [24] 1285 	push	ar5
      00BA34 C0 02            [24] 1286 	push	ar2
      00BA36 C0 01            [24] 1287 	push	ar1
      00BA38 12 59 F7         [24] 1288 	lcall	_rgb_matrix_get_hue
      00BA3B A8 82            [24] 1289 	mov	r0, dpl
      00BA3D D0 01            [24] 1290 	pop	ar1
      00BA3F D0 02            [24] 1291 	pop	ar2
      00BA41 D0 05            [24] 1292 	pop	ar5
      00BA43 D0 06            [24] 1293 	pop	ar6
      00BA45 12 48 C4         [24] 1294 	lcall	_ak820_outline_0063
                                   1295 ;	quantum/vialrgb.c:154: args[4] = rgb_matrix_get_sat();
      00BA48 74 06            [12] 1296 	mov	a,#0x06
      00BA4A 12 93 C3         [24] 1297 	lcall	_ak820_outline_0138
      00BA4D C0 06            [24] 1298 	push	ar6
      00BA4F C0 05            [24] 1299 	push	ar5
      00BA51 C0 02            [24] 1300 	push	ar2
      00BA53 C0 01            [24] 1301 	push	ar1
      00BA55 12 59 FE         [24] 1302 	lcall	_rgb_matrix_get_sat
      00BA58 A8 82            [24] 1303 	mov	r0, dpl
      00BA5A D0 01            [24] 1304 	pop	ar1
      00BA5C D0 02            [24] 1305 	pop	ar2
      00BA5E D0 05            [24] 1306 	pop	ar5
      00BA60 D0 06            [24] 1307 	pop	ar6
      00BA62 12 48 C4         [24] 1308 	lcall	_ak820_outline_0063
                                   1309 ;	quantum/vialrgb.c:155: args[5] = rgb_matrix_get_val();
      00BA65 74 07            [12] 1310 	mov	a,#0x07
      00BA67 12 93 C3         [24] 1311 	lcall	_ak820_outline_0138
      00BA6A C0 02            [24] 1312 	push	ar2
      00BA6C C0 01            [24] 1313 	push	ar1
      00BA6E 12 5A 05         [24] 1314 	lcall	_rgb_matrix_get_val
      00BA71 A8 82            [24] 1315 	mov	r0, dpl
      00BA73 D0 01            [24] 1316 	pop	ar1
      00BA75 D0 02            [24] 1317 	pop	ar2
      00BA77 12 48 C4         [24] 1318 	lcall	_ak820_outline_0063
                                   1319 ;	quantum/vialrgb.c:156: break;
      00BA7A 22               [24] 1320 	ret
                                   1321 ;	quantum/vialrgb.c:158: case vialrgb_get_supported: {
      00BA7B                       1322 00105$:
                                   1323 ;	quantum/vialrgb.c:159: get_supported(args, length - 2);
      00BA7B EF               [12] 1324 	mov	a,r7
      00BA7C 24 FE            [12] 1325 	add	a,#0xfe
      00BA7E 90 0E 42         [24] 1326 	mov	dptr,#_get_supported_PARM_2
      00BA81 F0               [24] 1327 	movx	@dptr,a
      00BA82 12 33 FC         [24] 1328 	lcall	_ak820_outline_0124
                                   1329 ;	quantum/vialrgb.c:160: break;
      00BA85 02 B6 F6         [24] 1330 	ljmp	_get_supported
                                   1331 ;	quantum/vialrgb.c:163: case vialrgb_get_number_leds: {
      00BA88                       1332 00106$:
                                   1333 ;	quantum/vialrgb.c:164: args[0] = RGB_MATRIX_LED_COUNT & 0xFF;
      00BA88 12 33 FC         [24] 1334 	lcall	_ak820_outline_0124
      00BA8B 74 52            [12] 1335 	mov	a,#0x52
      00BA8D F0               [24] 1336 	movx	@dptr,a
                                   1337 ;	quantum/vialrgb.c:165: args[1] = RGB_MATRIX_LED_COUNT >> 8;
      00BA8E 12 48 B4         [24] 1338 	lcall	_ak820_outline_0040
      00BA91 E4               [12] 1339 	clr	a
      00BA92 F0               [24] 1340 	movx	@dptr,a
                                   1341 ;	quantum/vialrgb.c:166: break;
      00BA93 22               [24] 1342 	ret
                                   1343 ;	quantum/vialrgb.c:168: case vialrgb_get_led_info: {
      00BA94                       1344 00107$:
                                   1345 ;	quantum/vialrgb.c:169: uint16_t led = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00BA94 12 33 FC         [24] 1346 	lcall	_ak820_outline_0124
      00BA97 E0               [24] 1347 	movx	a,@dptr
      00BA98 FF               [12] 1348 	mov	r7,a
      00BA99 7A 00            [12] 1349 	mov	r2,#0x00
      00BA9B 74 03            [12] 1350 	mov	a,#0x03
      00BA9D 2D               [12] 1351 	add	a, r5
      00BA9E F8               [12] 1352 	mov	r0,a
      00BA9F E4               [12] 1353 	clr	a
      00BAA0 3E               [12] 1354 	addc	a, r6
      00BAA1 F9               [12] 1355 	mov	r1,a
      00BAA2 C0 03            [24] 1356 	push	ar3
      00BAA4 C0 04            [24] 1357 	push	ar4
      00BAA6 12 38 6B         [24] 1358 	lcall	_ak820_outline_0158
      00BAA9 E0               [24] 1359 	movx	a,@dptr
      00BAAA FB               [12] 1360 	mov	r3,a
      00BAAB E4               [12] 1361 	clr	a
      00BAAC 4F               [12] 1362 	orl	a,r7
      00BAAD F5 4E            [12] 1363 	mov	_vialrgb_get_value_sloc0_1_0,a
      00BAAF EB               [12] 1364 	mov	a,r3
      00BAB0 4A               [12] 1365 	orl	a,r2
      00BAB1 F5 4F            [12] 1366 	mov	(_vialrgb_get_value_sloc0_1_0 + 1),a
                                   1367 ;	quantum/vialrgb.c:170: if (led >= RGB_MATRIX_LED_COUNT) return;
      00BAB3 AC 4E            [24] 1368 	mov	r4,_vialrgb_get_value_sloc0_1_0
      00BAB5 AF 4F            [24] 1369 	mov	r7,(_vialrgb_get_value_sloc0_1_0 + 1)
      00BAB7 C3               [12] 1370 	clr	c
      00BAB8 EC               [12] 1371 	mov	a,r4
      00BAB9 94 52            [12] 1372 	subb	a,#0x52
      00BABB EF               [12] 1373 	mov	a,r7
      00BABC 94 00            [12] 1374 	subb	a,#0x00
      00BABE D0 04            [24] 1375 	pop	ar4
      00BAC0 D0 03            [24] 1376 	pop	ar3
      00BAC2 40 01            [24] 1377 	jc	00109$
      00BAC4 22               [24] 1378 	ret
      00BAC5                       1379 00109$:
                                   1380 ;	quantum/vialrgb.c:172: args[0] = ak820_led_points[led].x;
      00BAC5 E5 4E            [12] 1381 	mov	a,_vialrgb_get_value_sloc0_1_0
      00BAC7 25 4E            [12] 1382 	add	a,_vialrgb_get_value_sloc0_1_0
      00BAC9 FA               [12] 1383 	mov	r2,a
      00BACA E5 4F            [12] 1384 	mov	a,(_vialrgb_get_value_sloc0_1_0 + 1)
      00BACC 33               [12] 1385 	rlc	a
      00BACD FF               [12] 1386 	mov	r7,a
      00BACE EA               [12] 1387 	mov	a,r2
      00BACF 24 51            [12] 1388 	add	a, #_ak820_led_points
      00BAD1 F5 50            [12] 1389 	mov	_vialrgb_get_value_sloc1_1_0,a
      00BAD3 EF               [12] 1390 	mov	a,r7
      00BAD4 34 C0            [12] 1391 	addc	a, #(_ak820_led_points >> 8)
      00BAD6 F5 51            [12] 1392 	mov	(_vialrgb_get_value_sloc1_1_0 + 1),a
      00BAD8 85 50 82         [24] 1393 	mov	dpl,_vialrgb_get_value_sloc1_1_0
      00BADB 85 51 83         [24] 1394 	mov	dph,(_vialrgb_get_value_sloc1_1_0 + 1)
      00BADE E4               [12] 1395 	clr	a
      00BADF 93               [24] 1396 	movc	a,@a+dptr
      00BAE0 12 33 FC         [24] 1397 	lcall	_ak820_outline_0124
      00BAE3 F0               [24] 1398 	movx	@dptr,a
                                   1399 ;	quantum/vialrgb.c:173: args[1] = ak820_led_points[led].y;
      00BAE4 85 50 82         [24] 1400 	mov	dpl,_vialrgb_get_value_sloc1_1_0
      00BAE7 85 51 83         [24] 1401 	mov	dph,(_vialrgb_get_value_sloc1_1_0 + 1)
      00BAEA A3               [24] 1402 	inc	dptr
      00BAEB E4               [12] 1403 	clr	a
      00BAEC 93               [24] 1404 	movc	a,@a+dptr
      00BAED 12 38 6B         [24] 1405 	lcall	_ak820_outline_0158
      00BAF0 F0               [24] 1406 	movx	@dptr,a
                                   1407 ;	quantum/vialrgb.c:174: args[2] = LED_FLAG_KEYLIGHT;
      00BAF1 12 48 B4         [24] 1408 	lcall	_ak820_outline_0040
      00BAF4 A3               [24] 1409 	inc	dptr
      00BAF5 74 04            [12] 1410 	mov	a,#0x04
      00BAF7 F0               [24] 1411 	movx	@dptr,a
                                   1412 ;	quantum/vialrgb.c:183: get_matrix_pos_for_led(led, &args[3]);
      00BAF8 90 0E 4B         [24] 1413 	mov	dptr,#_get_matrix_pos_for_led_PARM_2
      00BAFB 04               [12] 1414 	inc	a
      00BAFC 2D               [12] 1415 	add	a, r5
      00BAFD F0               [24] 1416 	movx	@dptr,a
      00BAFE E4               [12] 1417 	clr	a
      00BAFF 3E               [12] 1418 	addc	a, r6
      00BB00 A3               [24] 1419 	inc	dptr
      00BB01 F0               [24] 1420 	movx	@dptr,a
      00BB02 85 4E 82         [24] 1421 	mov	dpl, _vialrgb_get_value_sloc0_1_0
      00BB05 85 4F 83         [24] 1422 	mov	dph, (_vialrgb_get_value_sloc0_1_0 + 1)
                                   1423 ;	quantum/vialrgb.c:187: }
                                   1424 ;	quantum/vialrgb.c:188: }
      00BB08 01 30            [24] 1425 	ajmp	_get_matrix_pos_for_led
                                   1426 ;------------------------------------------------------------
                                   1427 ;Allocation info for local variables in function 'vialrgb_set_value'
                                   1428 ;------------------------------------------------------------
                                   1429 ;sloc0         Allocated with name '_vialrgb_set_value_sloc0_1_0'
                                   1430 ;length        Allocated with name '_vialrgb_set_value_PARM_2'
                                   1431 ;data          Allocated with name '_vialrgb_set_value_data_10000_302'
                                   1432 ;args          Allocated with name '_vialrgb_set_value_args_10001_305'
                                   1433 ;cmd           Allocated with name '_vialrgb_set_value_cmd_10001_305'
                                   1434 ;vialrgb_id    Allocated with name '_vialrgb_set_value_vialrgb_id_40001_308'
                                   1435 ;------------------------------------------------------------
                                   1436 ;	quantum/vialrgb.c:190: void vialrgb_set_value(uint8_t *data, uint8_t length) {
                                   1437 ;	-----------------------------------------
                                   1438 ;	 function vialrgb_set_value
                                   1439 ;	-----------------------------------------
      00BB0A                       1440 _vialrgb_set_value:
      00BB0A 12 42 D4         [24] 1441 	lcall	_ak820_outline_0042
      00BB0D 90 0E 5A         [24] 1442 	mov	dptr,#_vialrgb_set_value_data_10000_302
      00BB10 12 37 DF         [24] 1443 	lcall	_ak820_outline_0018
                                   1444 ;	quantum/vialrgb.c:191: if (length != VIAL_RAW_EPSIZE) return;
      00BB13 90 0E 59         [24] 1445 	mov	dptr,#_vialrgb_set_value_PARM_2
      00BB16 E0               [24] 1446 	movx	a,@dptr
      00BB17 FF               [12] 1447 	mov	r7,a
      00BB18 BF 20 02         [24] 1448 	cjne	r7,#0x20,00129$
      00BB1B 80 01            [24] 1449 	sjmp	00102$
      00BB1D                       1450 00129$:
      00BB1D 22               [24] 1451 	ret
      00BB1E                       1452 00102$:
                                   1453 ;	quantum/vialrgb.c:194: uint8_t VIALRGB_BUFFER *args = (uint8_t VIALRGB_BUFFER *)data + 2;
      00BB1E 90 0E 5A         [24] 1454 	mov	dptr,#_vialrgb_set_value_data_10000_302
      00BB21 12 BB 9B         [24] 1455 	lcall	_ak820_outline_0048
                                   1456 ;	quantum/vialrgb.c:195: uint8_t cmd = args[-1];
                                   1457 ;	quantum/vialrgb.c:196: switch (cmd) {
      00BB24 BA 41 02         [24] 1458 	cjne	r2,#0x41,00130$
      00BB27 80 06            [24] 1459 	sjmp	00103$
      00BB29                       1460 00130$:
      00BB29 BA 42 02         [24] 1461 	cjne	r2,#0x42,00131$
      00BB2C 80 5E            [24] 1462 	sjmp	00104$
      00BB2E                       1463 00131$:
      00BB2E 22               [24] 1464 	ret
                                   1465 ;	quantum/vialrgb.c:197: case vialrgb_set_mode: {
      00BB2F                       1466 00103$:
                                   1467 ;	quantum/vialrgb.c:198: uint16_t vialrgb_id = args[0] | (args[1] << 8);
      00BB2F 12 33 FC         [24] 1468 	lcall	_ak820_outline_0124
      00BB32 E0               [24] 1469 	movx	a,@dptr
      00BB33 FA               [12] 1470 	mov	r2,a
      00BB34 12 48 B4         [24] 1471 	lcall	_ak820_outline_0040
      00BB37 E0               [24] 1472 	movx	a,@dptr
      00BB38 F8               [12] 1473 	mov	r0,a
      00BB39 79 00            [12] 1474 	mov	r1,#0x00
      00BB3B 88 53            [24] 1475 	mov	(_vialrgb_set_value_sloc0_1_0 + 1),r0
      00BB3D 89 52            [24] 1476 	mov	_vialrgb_set_value_sloc0_1_0,r1
      00BB3F 8A 01            [24] 1477 	mov	ar1,r2
      00BB41 7A 00            [12] 1478 	mov	r2,#0x00
      00BB43 E5 53            [12] 1479 	mov	a,(_vialrgb_set_value_sloc0_1_0 + 1)
      00BB45 42 02            [12] 1480 	orl	ar2,a
                                   1481 ;	quantum/vialrgb.c:199: set_mode(vialrgb_id);
      00BB47 12 43 38         [24] 1482 	lcall	_ak820_outline_0150
      00BB4A C0 06            [24] 1483 	push	ar6
      00BB4C C0 05            [24] 1484 	push	ar5
      00BB4E 12 B8 02         [24] 1485 	lcall	_set_mode
      00BB51 D0 05            [24] 1486 	pop	ar5
      00BB53 D0 06            [24] 1487 	pop	ar6
                                   1488 ;	quantum/vialrgb.c:200: rgb_matrix_set_speed_noeeprom(args[2]);
      00BB55 12 48 B4         [24] 1489 	lcall	_ak820_outline_0040
      00BB58 A3               [24] 1490 	inc	dptr
      00BB59 E0               [24] 1491 	movx	a,@dptr
      00BB5A F5 82            [12] 1492 	mov	dpl,a
      00BB5C C0 06            [24] 1493 	push	ar6
      00BB5E C0 05            [24] 1494 	push	ar5
      00BB60 12 5A D8         [24] 1495 	lcall	_rgb_matrix_set_speed_noeeprom
      00BB63 D0 05            [24] 1496 	pop	ar5
      00BB65 D0 06            [24] 1497 	pop	ar6
                                   1498 ;	quantum/vialrgb.c:201: rgb_matrix_sethsv_noeeprom(args[3], args[4], args[5]);
      00BB67 12 48 B4         [24] 1499 	lcall	_ak820_outline_0040
      00BB6A A3               [24] 1500 	inc	dptr
      00BB6B A3               [24] 1501 	inc	dptr
      00BB6C E0               [24] 1502 	movx	a,@dptr
      00BB6D F9               [12] 1503 	mov	r1,a
      00BB6E 7A 00            [12] 1504 	mov	r2,#0x00
      00BB70 74 06            [12] 1505 	mov	a,#0x06
      00BB72 12 BB E5         [24] 1506 	lcall	_ak820_outline_0174
      00BB75 F8               [12] 1507 	mov	r0,a
      00BB76 74 07            [12] 1508 	mov	a,#0x07
      00BB78 12 BB E5         [24] 1509 	lcall	_ak820_outline_0174
      00BB7B FE               [12] 1510 	mov	r6,a
      00BB7C 90 07 F6         [24] 1511 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_2
      00BB7F E8               [12] 1512 	mov	a,r0
      00BB80 F0               [24] 1513 	movx	@dptr,a
      00BB81 90 07 F7         [24] 1514 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_3
      00BB84 EE               [12] 1515 	mov	a,r6
      00BB85 F0               [24] 1516 	movx	@dptr,a
      00BB86 12 43 38         [24] 1517 	lcall	_ak820_outline_0150
                                   1518 ;	quantum/vialrgb.c:202: break;
                                   1519 ;	quantum/vialrgb.c:205: case vialrgb_direct_fastset: {
      00BB89 02 5A A9         [24] 1520 	ljmp	_rgb_matrix_sethsv_noeeprom
      00BB8C                       1521 00104$:
                                   1522 ;	quantum/vialrgb.c:206: fast_set_leds(args, length - 2);
      00BB8C EF               [12] 1523 	mov	a,r7
      00BB8D 24 FE            [12] 1524 	add	a,#0xfe
      00BB8F 90 0E 4F         [24] 1525 	mov	dptr,#_fast_set_leds_PARM_2
      00BB92 F0               [24] 1526 	movx	@dptr,a
      00BB93 12 33 FC         [24] 1527 	lcall	_ak820_outline_0124
                                   1528 ;	quantum/vialrgb.c:210: }
                                   1529 ;	quantum/vialrgb.c:211: }
      00BB96 01 63            [24] 1530 	ajmp	_fast_set_leds
                                   1531 ;------------------------------------------------------------
                                   1532 ;Allocation info for local variables in function 'vialrgb_save'
                                   1533 ;------------------------------------------------------------
                                   1534 ;length        Allocated with name '_vialrgb_save_PARM_2'
                                   1535 ;data          Allocated with name '_vialrgb_save_data_10000_310'
                                   1536 ;------------------------------------------------------------
                                   1537 ;	quantum/vialrgb.c:213: void vialrgb_save(uint8_t *data, uint8_t length) {
                                   1538 ;	-----------------------------------------
                                   1539 ;	 function vialrgb_save
                                   1540 ;	-----------------------------------------
      00BB98                       1541 _vialrgb_save:
                                   1542 ;	quantum/vialrgb.c:217: eeconfig_update_rgb_matrix();
                                   1543 ;	quantum/vialrgb.c:218: }
      00BB98 02 55 2B         [24] 1544 	ljmp	_eeconfig_update_rgb_matrix
                                   1545 	.area CSEG    (CODE)
                                   1546 	.area CONST   (CODE)
                                   1547 	.area CONST   (CODE)
      00C390                       1548 _supported_modes:
      00C390 00                    1549 	.db #0x00	; 0
      00C391 00                    1550 	.db #0x00	; 0
      00C392 01                    1551 	.db #0x01	; 1
      00C393 05                    1552 	.db #0x05	; 5
      00C394 02                    1553 	.db #0x02	; 2
      00C395 01                    1554 	.db #0x01	; 1
      00C396 06                    1555 	.db #0x06	; 6
      00C397 02                    1556 	.db #0x02	; 2
      00C398 0D                    1557 	.db #0x0d	; 13
      00C399 03                    1558 	.db #0x03	; 3
      00C39A 0E                    1559 	.db #0x0e	; 14
      00C39B 04                    1560 	.db #0x04	; 4
      00C39C 1F                    1561 	.db #0x1f	; 31
      00C39D 06                    1562 	.db #0x06	; 6
                                   1563 	.area CSEG    (CODE)
                                   1564 	.area XINIT   (CODE)
                                   1565 	.area CABS    (ABS,CODE)
                                   1566 
                                   1567 ; Experimental exact instruction outlining.
                                   1568 	.globl _ak820_outline_0005
                                   1569 	.globl _ak820_outline_0018
                                   1570 	.globl _ak820_outline_0035
                                   1571 	.globl _ak820_outline_0037
                                   1572 	.globl _ak820_outline_0040
                                   1573 	.globl _ak820_outline_0042
                                   1574 	.globl _ak820_outline_0048
                                   1575 	.globl _ak820_outline_0051
                                   1576 	.globl _ak820_outline_0056
                                   1577 	.globl _ak820_outline_0063
                                   1578 	.globl _ak820_outline_0078
                                   1579 	.globl _ak820_outline_0079
                                   1580 	.globl _ak820_outline_0081
                                   1581 	.globl _ak820_outline_0087
                                   1582 	.globl _ak820_outline_0098
                                   1583 	.globl _ak820_outline_0103
                                   1584 	.globl _ak820_outline_0105
                                   1585 	.globl _ak820_outline_0106
                                   1586 	.globl _ak820_outline_0109
                                   1587 	.globl _ak820_outline_0110
                                   1588 	.globl _ak820_outline_0119
                                   1589 	.globl _ak820_outline_0124
                                   1590 	.globl _ak820_outline_0126
                                   1591 	.globl _ak820_outline_0137
                                   1592 	.globl _ak820_outline_0138
                                   1593 	.globl _ak820_outline_0142
                                   1594 	.globl _ak820_outline_0144
                                   1595 	.globl _ak820_outline_0150
                                   1596 	.globl _ak820_outline_0158
                                   1597 	.globl _ak820_outline_0164
                                   1598 	.globl _ak820_outline_0174
                                   1599 	.globl _ak820_outline_0188
                                   1600 
                                   1601 	.area CSEG (CODE)
                                   1602 ; function ak820_outline_0048
      00BB9B                       1603 _ak820_outline_0048:
      00BB9B E0               [24] 1604 	movx	a,@dptr
      00BB9C FD               [12] 1605 	mov	r5,a
      00BB9D A3               [24] 1606 	inc	dptr
      00BB9E E0               [24] 1607 	movx	a,@dptr
      00BB9F FE               [12] 1608 	mov	r6,a
      00BBA0 74 02            [12] 1609 	mov	a,#0x02
      00BBA2 2D               [12] 1610 	add	a,r5
      00BBA3 FB               [12] 1611 	mov	r3,a
      00BBA4 E4               [12] 1612 	clr	a
      00BBA5 3E               [12] 1613 	addc	a,r6
      00BBA6 FC               [12] 1614 	mov	r4,a
      00BBA7 8D 82            [24] 1615 	mov	dpl,r5
      00BBA9 8E 83            [24] 1616 	mov	dph,r6
      00BBAB A3               [24] 1617 	inc	dptr
      00BBAC E0               [24] 1618 	movx	a,@dptr
      00BBAD FA               [12] 1619 	mov	r2,a
      00BBAE 22               [24] 1620 	ret
                                   1621 
                                   1622 	.area CSEG (CODE)
                                   1623 ; function ak820_outline_0051
      00BBAF                       1624 _ak820_outline_0051:
      00BBAF ED               [12] 1625 	mov	a,r5
      00BBB0 75 F0 02         [24] 1626 	mov	b,#0x02
      00BBB3 A4               [48] 1627 	mul	ab
      00BBB4 24 90            [12] 1628 	add	a,#_supported_modes
      00BBB6 FB               [12] 1629 	mov	r3,a
      00BBB7 74 C3            [12] 1630 	mov	a,#(_supported_modes>>8)
      00BBB9 35 F0            [12] 1631 	addc	a,b
      00BBBB FC               [12] 1632 	mov	r4,a
      00BBBC 8B 82            [24] 1633 	mov	dpl,r3
      00BBBE 8C 83            [24] 1634 	mov	dph,r4
      00BBC0 22               [24] 1635 	ret
                                   1636 
                                   1637 	.area CSEG (CODE)
                                   1638 ; function ak820_outline_0087
      00BBC1                       1639 _ak820_outline_0087:
      00BBC1 90 0E 50         [24] 1640 	mov	dptr,#_fast_set_leds_args_10000_282
      00BBC4 E0               [24] 1641 	movx	a,@dptr
      00BBC5 F9               [12] 1642 	mov	r1,a
      00BBC6 A3               [24] 1643 	inc	dptr
      00BBC7 E0               [24] 1644 	movx	a,@dptr
      00BBC8 FF               [12] 1645 	mov	r7,a
      00BBC9 89 82            [24] 1646 	mov	dpl,r1
      00BBCB 8F 83            [24] 1647 	mov	dph,r7
      00BBCD E0               [24] 1648 	movx	a,@dptr
      00BBCE 22               [24] 1649 	ret
                                   1650 
                                   1651 	.area CSEG (CODE)
                                   1652 ; function ak820_outline_0109
      00BBCF                       1653 _ak820_outline_0109:
      00BBCF 90 0E 50         [24] 1654 	mov	dptr,#_fast_set_leds_args_10000_282
      00BBD2 74 01            [12] 1655 	mov	a,#0x01
      00BBD4 29               [12] 1656 	add	a,r1
      00BBD5 F0               [24] 1657 	movx	@dptr,a
      00BBD6 E4               [12] 1658 	clr	a
      00BBD7 3F               [12] 1659 	addc	a,r7
      00BBD8 A3               [24] 1660 	inc	dptr
      00BBD9 F0               [24] 1661 	movx	@dptr,a
      00BBDA 22               [24] 1662 	ret
                                   1663 
                                   1664 	.area CSEG (CODE)
                                   1665 ; function ak820_outline_0144
      00BBDB                       1666 _ak820_outline_0144:
      00BBDB E4               [12] 1667 	clr	a
      00BBDC 93               [24] 1668 	movc	a,@a+dptr
      00BBDD FC               [12] 1669 	mov	r4,a
      00BBDE 7B 00            [12] 1670 	mov	r3,#0x00
      00BBE0 8C 82            [24] 1671 	mov	dpl,r4
      00BBE2 8B 83            [24] 1672 	mov	dph,r3
      00BBE4 22               [24] 1673 	ret
                                   1674 
                                   1675 	.area CSEG (CODE)
                                   1676 ; function ak820_outline_0174
      00BBE5                       1677 _ak820_outline_0174:
      00BBE5 2D               [12] 1678 	add	a,r5
      00BBE6 F5 82            [12] 1679 	mov	dpl,a
      00BBE8 E4               [12] 1680 	clr	a
      00BBE9 3E               [12] 1681 	addc	a,r6
      00BBEA F5 83            [12] 1682 	mov	dph,a
      00BBEC E0               [24] 1683 	movx	a,@dptr
      00BBED 22               [24] 1684 	ret
