                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module dynamic_keymap
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _dynamic_keymap_encoder_to_eeprom_address
                                     12 	.globl _ak820_combo_valid
                                     13 	.globl _ak820_tap_dance_valid
                                     14 	.globl _ak820_eeprom_update_block_xdata
                                     15 	.globl _ak820_eeprom_write_block_xdata
                                     16 	.globl _ak820_eeprom_read_block_xdata
                                     17 	.globl _ak820_nvm_flush
                                     18 	.globl _ak820_nvm_ok
                                     19 	.globl _ak820_macro_reset
                                     20 	.globl _ak820_macro_write
                                     21 	.globl _ak820_macro_length
                                     22 	.globl _ak820_macro_ready
                                     23 	.globl _send_char
                                     24 	.globl _keycode_at_encodermap_location_raw
                                     25 	.globl _keycode_at_keymap_location_raw
                                     26 	.globl _vial_keycode_tap
                                     27 	.globl _vial_keycode_up
                                     28 	.globl _vial_keycode_down
                                     29 	.globl _clear_keyboard
                                     30 	.globl _tap_code
                                     31 	.globl _unregister_code
                                     32 	.globl _register_code
                                     33 	.globl _mDelaymS
                                     34 	.globl ___memcpy
                                     35 	.globl _memset
                                     36 	.globl _eeprom_update_byte
                                     37 	.globl _eeprom_read_byte
                                     38 	.globl _ADC_START
                                     39 	.globl _S0_R_FIFO
                                     40 	.globl _S0_T_FIFO
                                     41 	.globl _S0_FREE
                                     42 	.globl _S0_IF_BYTE
                                     43 	.globl _S0_IF_FIRST
                                     44 	.globl _S0_IF_OV
                                     45 	.globl _S0_FST_ACT
                                     46 	.globl _CP_RL2
                                     47 	.globl _C_T2
                                     48 	.globl _TR2
                                     49 	.globl _EXEN2
                                     50 	.globl _TCLK
                                     51 	.globl _RCLK
                                     52 	.globl _EXF2
                                     53 	.globl _CAP1F
                                     54 	.globl _TF2
                                     55 	.globl _RI
                                     56 	.globl _TI
                                     57 	.globl _RB8
                                     58 	.globl _TB8
                                     59 	.globl _REN
                                     60 	.globl _SM2
                                     61 	.globl _SM1
                                     62 	.globl _SM0
                                     63 	.globl _IT0
                                     64 	.globl _IE0
                                     65 	.globl _IT1
                                     66 	.globl _IE1
                                     67 	.globl _TR0
                                     68 	.globl _TF0
                                     69 	.globl _TR1
                                     70 	.globl _TF1
                                     71 	.globl _P4_0
                                     72 	.globl _P4_1
                                     73 	.globl _P4_2
                                     74 	.globl _P4_3
                                     75 	.globl _P4_4
                                     76 	.globl _P4_5
                                     77 	.globl _P4_6
                                     78 	.globl _RXD
                                     79 	.globl _TXD
                                     80 	.globl _INT0
                                     81 	.globl _INT1
                                     82 	.globl _T0
                                     83 	.globl _T1
                                     84 	.globl _MOSI1
                                     85 	.globl _MISO1
                                     86 	.globl _SCK1
                                     87 	.globl _P3_0
                                     88 	.globl _P3_1
                                     89 	.globl _P3_2
                                     90 	.globl _P3_3
                                     91 	.globl _P3_4
                                     92 	.globl _P3_5
                                     93 	.globl _P3_6
                                     94 	.globl _P3_7
                                     95 	.globl _CAP1_
                                     96 	.globl _T2_
                                     97 	.globl _CAP2_
                                     98 	.globl _T2EX_
                                     99 	.globl _RXD1
                                    100 	.globl _TXD1
                                    101 	.globl _P2_0
                                    102 	.globl _P2_1
                                    103 	.globl _P2_2
                                    104 	.globl _P2_3
                                    105 	.globl _P2_4
                                    106 	.globl _P2_5
                                    107 	.globl _P2_6
                                    108 	.globl _P2_7
                                    109 	.globl _AIN0
                                    110 	.globl _AIN1
                                    111 	.globl _AIN2
                                    112 	.globl _AIN3
                                    113 	.globl _AIN4
                                    114 	.globl _AIN5
                                    115 	.globl _AIN6
                                    116 	.globl _AIN7
                                    117 	.globl _CAP1
                                    118 	.globl _T2
                                    119 	.globl _CAP2
                                    120 	.globl _T2EX
                                    121 	.globl _INT0_
                                    122 	.globl _SCS
                                    123 	.globl _MOSI
                                    124 	.globl _MISO
                                    125 	.globl _SCK
                                    126 	.globl _RXD1_
                                    127 	.globl _TXD1_
                                    128 	.globl _P1_0
                                    129 	.globl _P1_1
                                    130 	.globl _P1_2
                                    131 	.globl _P1_3
                                    132 	.globl _P1_4
                                    133 	.globl _P1_5
                                    134 	.globl _P1_6
                                    135 	.globl _P1_7
                                    136 	.globl _AIN8
                                    137 	.globl _AIN9
                                    138 	.globl _AIN10
                                    139 	.globl _AIN11
                                    140 	.globl _AIN12
                                    141 	.globl _AIN13
                                    142 	.globl _RXD_
                                    143 	.globl _TXD_
                                    144 	.globl _SCL0
                                    145 	.globl _SDA0
                                    146 	.globl _P0_0
                                    147 	.globl _P0_1
                                    148 	.globl _P0_2
                                    149 	.globl _P0_3
                                    150 	.globl _P0_4
                                    151 	.globl _P0_5
                                    152 	.globl _P0_6
                                    153 	.globl _P0_7
                                    154 	.globl _IE_SPI0
                                    155 	.globl _IE_USB
                                    156 	.globl _IE_ADC
                                    157 	.globl _IE_UART1
                                    158 	.globl _IE_PWM_I2C
                                    159 	.globl _IE_GPIO
                                    160 	.globl _IE_WDOG
                                    161 	.globl _PX0
                                    162 	.globl _PT0
                                    163 	.globl _PX1
                                    164 	.globl _PT1
                                    165 	.globl _PS
                                    166 	.globl _PT2
                                    167 	.globl _PL_FLAG
                                    168 	.globl _PH_FLAG
                                    169 	.globl _EX0
                                    170 	.globl _ET0
                                    171 	.globl _EX1
                                    172 	.globl _ET1
                                    173 	.globl _ES
                                    174 	.globl _ET2
                                    175 	.globl _E_DIS
                                    176 	.globl _EA
                                    177 	.globl _P
                                    178 	.globl _F1
                                    179 	.globl _OV
                                    180 	.globl _RS0
                                    181 	.globl _RS1
                                    182 	.globl _F0
                                    183 	.globl _AC
                                    184 	.globl _CY
                                    185 	.globl _I2CS_INT_ST
                                    186 	.globl _I2CX_INT
                                    187 	.globl _LED_STATUS
                                    188 	.globl _LED_DMA_H
                                    189 	.globl _LED_DMA_L
                                    190 	.globl _LED_DMA
                                    191 	.globl _LED_PWM_OE
                                    192 	.globl _LED_COMMON
                                    193 	.globl _ADC_CHAN
                                    194 	.globl _ADC_DAT_H
                                    195 	.globl _ADC_DAT_L
                                    196 	.globl _ADC_DAT
                                    197 	.globl _ADC_CTRL
                                    198 	.globl _SPI1_CK_SE
                                    199 	.globl _SPI1_CTRL
                                    200 	.globl _SPI1_DATA
                                    201 	.globl _SPI1_STAT
                                    202 	.globl _SIF1
                                    203 	.globl _SBAUD1
                                    204 	.globl _SBUF1
                                    205 	.globl _SCON1
                                    206 	.globl _SPI0_SETUP
                                    207 	.globl _SPI0_CK_SE
                                    208 	.globl _SPI0_CTRL
                                    209 	.globl _SPI0_DATA
                                    210 	.globl _SPI0_STAT
                                    211 	.globl _T2CAP1H
                                    212 	.globl _T2CAP1L
                                    213 	.globl _T2CAP1
                                    214 	.globl _TH2
                                    215 	.globl _TL2
                                    216 	.globl _T2COUNT
                                    217 	.globl _RCAP2H
                                    218 	.globl _RCAP2L
                                    219 	.globl _RCAP2
                                    220 	.globl _T2MOD
                                    221 	.globl _T2CON
                                    222 	.globl _SBUF
                                    223 	.globl _SCON
                                    224 	.globl _TH1
                                    225 	.globl _TH0
                                    226 	.globl _TL1
                                    227 	.globl _TL0
                                    228 	.globl _TMOD
                                    229 	.globl _TCON
                                    230 	.globl _XBUS_AUX
                                    231 	.globl _P7
                                    232 	.globl _P6_DIR
                                    233 	.globl _P6_OUT_PU
                                    234 	.globl _P6_IN
                                    235 	.globl _P5_DIR
                                    236 	.globl _P5_OUT_PU
                                    237 	.globl _P5_IN
                                    238 	.globl _P4_LED_KEY
                                    239 	.globl _P4_DIR_PU
                                    240 	.globl _P4_MOD_OC
                                    241 	.globl _P4
                                    242 	.globl _P3_DIR_PU
                                    243 	.globl _P3_MOD_OC
                                    244 	.globl _P3
                                    245 	.globl _P2_DIR_PU
                                    246 	.globl _P2_MOD_OC
                                    247 	.globl _P2
                                    248 	.globl _P1_DIR_PU
                                    249 	.globl _P1_MOD_OC
                                    250 	.globl _P1
                                    251 	.globl _P0_DIR_PU
                                    252 	.globl _P0_MOD_OC
                                    253 	.globl _P0
                                    254 	.globl _ROM_CTRL
                                    255 	.globl _ROM_DATA_HH
                                    256 	.globl _ROM_DATA_HL
                                    257 	.globl _ROM_DATA_HI
                                    258 	.globl _ROM_ADDR_H
                                    259 	.globl _ROM_ADDR_L
                                    260 	.globl _ROM_ADDR
                                    261 	.globl _GPIO_IE
                                    262 	.globl _IP_EX
                                    263 	.globl _IE_EX
                                    264 	.globl _IP
                                    265 	.globl _IE
                                    266 	.globl _WDOG_COUNT
                                    267 	.globl _RESET_KEEP
                                    268 	.globl _WAKE_CTRL
                                    269 	.globl _CLOCK_CFG
                                    270 	.globl _POWER_CFG
                                    271 	.globl _PCON
                                    272 	.globl _GLOBAL_CFG
                                    273 	.globl _SAFE_MOD
                                    274 	.globl _DPH
                                    275 	.globl _DPL
                                    276 	.globl _SP
                                    277 	.globl _A_INV
                                    278 	.globl _B
                                    279 	.globl _ACC
                                    280 	.globl _PSW
                                    281 	.globl _dynamic_keymap_macro_set_buffer_PARM_3
                                    282 	.globl _dynamic_keymap_macro_set_buffer_PARM_2
                                    283 	.globl _dynamic_keymap_macro_get_buffer_PARM_3
                                    284 	.globl _dynamic_keymap_macro_get_buffer_PARM_2
                                    285 	.globl _keycode_at_encodermap_location_PARM_3
                                    286 	.globl _keycode_at_encodermap_location_PARM_2
                                    287 	.globl _keycode_at_keymap_location_PARM_3
                                    288 	.globl _keycode_at_keymap_location_PARM_2
                                    289 	.globl _dynamic_keymap_set_buffer_PARM_3
                                    290 	.globl _dynamic_keymap_set_buffer_PARM_2
                                    291 	.globl _dynamic_keymap_get_buffer_PARM_3
                                    292 	.globl _dynamic_keymap_get_buffer_PARM_2
                                    293 	.globl _dynamic_keymap_set_combo_PARM_2
                                    294 	.globl _dynamic_keymap_get_combo_PARM_2
                                    295 	.globl _dynamic_keymap_set_tap_dance_PARM_2
                                    296 	.globl _dynamic_keymap_get_tap_dance_PARM_2
                                    297 	.globl _dynamic_keymap_set_encoder_PARM_4
                                    298 	.globl _dynamic_keymap_set_encoder_PARM_3
                                    299 	.globl _dynamic_keymap_set_encoder_PARM_2
                                    300 	.globl _dynamic_keymap_get_encoder_PARM_3
                                    301 	.globl _dynamic_keymap_get_encoder_PARM_2
                                    302 	.globl _dynamic_keymap_encoder_to_eeprom_address_PARM_2
                                    303 	.globl _dynamic_keymap_set_keycode_PARM_4
                                    304 	.globl _dynamic_keymap_set_keycode_PARM_3
                                    305 	.globl _dynamic_keymap_set_keycode_PARM_2
                                    306 	.globl _dynamic_keymap_get_keycode_PARM_3
                                    307 	.globl _dynamic_keymap_get_keycode_PARM_2
                                    308 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_3
                                    309 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_2
                                    310 	.globl _dynamic_keymap_get_layer_count
                                    311 	.globl _dynamic_keymap_key_to_eeprom_address
                                    312 	.globl _dynamic_keymap_get_keycode
                                    313 	.globl _dynamic_keymap_set_keycode
                                    314 	.globl _dynamic_keymap_get_encoder
                                    315 	.globl _dynamic_keymap_set_encoder
                                    316 	.globl _dynamic_keymap_get_tap_dance
                                    317 	.globl _dynamic_keymap_set_tap_dance
                                    318 	.globl _dynamic_keymap_get_combo
                                    319 	.globl _dynamic_keymap_set_combo
                                    320 	.globl _dynamic_keymap_reset
                                    321 	.globl _dynamic_keymap_get_buffer
                                    322 	.globl _dynamic_keymap_set_buffer
                                    323 	.globl _keycode_at_keymap_location
                                    324 	.globl _keycode_at_encodermap_location
                                    325 	.globl _dynamic_keymap_macro_get_count
                                    326 	.globl _dynamic_keymap_macro_get_buffer_size
                                    327 	.globl _dynamic_keymap_macro_get_buffer
                                    328 	.globl _dynamic_keymap_macro_set_buffer
                                    329 	.globl _dynamic_keymap_macro_reset
                                    330 	.globl _dynamic_keymap_macro_send
                                    331 ;--------------------------------------------------------
                                    332 ; special function registers
                                    333 ;--------------------------------------------------------
                                    334 	.area RSEG    (ABS,DATA)
      000000                        335 	.org 0x0000
                           0000D0   336 _PSW	=	0x00d0
                           0000E0   337 _ACC	=	0x00e0
                           0000F0   338 _B	=	0x00f0
                           0000FD   339 _A_INV	=	0x00fd
                           000081   340 _SP	=	0x0081
                           000082   341 _DPL	=	0x0082
                           000083   342 _DPH	=	0x0083
                           0000A1   343 _SAFE_MOD	=	0x00a1
                           0000B1   344 _GLOBAL_CFG	=	0x00b1
                           000087   345 _PCON	=	0x0087
                           0000BA   346 _POWER_CFG	=	0x00ba
                           0000B9   347 _CLOCK_CFG	=	0x00b9
                           0000A9   348 _WAKE_CTRL	=	0x00a9
                           0000FE   349 _RESET_KEEP	=	0x00fe
                           0000FF   350 _WDOG_COUNT	=	0x00ff
                           0000A8   351 _IE	=	0x00a8
                           0000B8   352 _IP	=	0x00b8
                           0000E8   353 _IE_EX	=	0x00e8
                           0000E9   354 _IP_EX	=	0x00e9
                           0000B2   355 _GPIO_IE	=	0x00b2
                           008584   356 _ROM_ADDR	=	0x8584
                           000084   357 _ROM_ADDR_L	=	0x0084
                           000085   358 _ROM_ADDR_H	=	0x0085
                           008F8E   359 _ROM_DATA_HI	=	0x8f8e
                           00008E   360 _ROM_DATA_HL	=	0x008e
                           00008F   361 _ROM_DATA_HH	=	0x008f
                           000086   362 _ROM_CTRL	=	0x0086
                           000080   363 _P0	=	0x0080
                           0000C4   364 _P0_MOD_OC	=	0x00c4
                           0000C5   365 _P0_DIR_PU	=	0x00c5
                           000090   366 _P1	=	0x0090
                           000092   367 _P1_MOD_OC	=	0x0092
                           000093   368 _P1_DIR_PU	=	0x0093
                           0000A0   369 _P2	=	0x00a0
                           000094   370 _P2_MOD_OC	=	0x0094
                           000095   371 _P2_DIR_PU	=	0x0095
                           0000B0   372 _P3	=	0x00b0
                           000096   373 _P3_MOD_OC	=	0x0096
                           000097   374 _P3_DIR_PU	=	0x0097
                           0000C0   375 _P4	=	0x00c0
                           0000C2   376 _P4_MOD_OC	=	0x00c2
                           0000C3   377 _P4_DIR_PU	=	0x00c3
                           0000C1   378 _P4_LED_KEY	=	0x00c1
                           0000AA   379 _P5_IN	=	0x00aa
                           0000AB   380 _P5_OUT_PU	=	0x00ab
                           0000AC   381 _P5_DIR	=	0x00ac
                           0000AD   382 _P6_IN	=	0x00ad
                           0000AE   383 _P6_OUT_PU	=	0x00ae
                           0000AF   384 _P6_DIR	=	0x00af
                           0000F1   385 _P7	=	0x00f1
                           0000A2   386 _XBUS_AUX	=	0x00a2
                           000088   387 _TCON	=	0x0088
                           000089   388 _TMOD	=	0x0089
                           00008A   389 _TL0	=	0x008a
                           00008B   390 _TL1	=	0x008b
                           00008C   391 _TH0	=	0x008c
                           00008D   392 _TH1	=	0x008d
                           000098   393 _SCON	=	0x0098
                           000099   394 _SBUF	=	0x0099
                           0000C8   395 _T2CON	=	0x00c8
                           0000C9   396 _T2MOD	=	0x00c9
                           00CBCA   397 _RCAP2	=	0xcbca
                           0000CA   398 _RCAP2L	=	0x00ca
                           0000CB   399 _RCAP2H	=	0x00cb
                           00CDCC   400 _T2COUNT	=	0xcdcc
                           0000CC   401 _TL2	=	0x00cc
                           0000CD   402 _TH2	=	0x00cd
                           00CFCE   403 _T2CAP1	=	0xcfce
                           0000CE   404 _T2CAP1L	=	0x00ce
                           0000CF   405 _T2CAP1H	=	0x00cf
                           0000F8   406 _SPI0_STAT	=	0x00f8
                           0000F9   407 _SPI0_DATA	=	0x00f9
                           0000FA   408 _SPI0_CTRL	=	0x00fa
                           0000FB   409 _SPI0_CK_SE	=	0x00fb
                           0000FC   410 _SPI0_SETUP	=	0x00fc
                           0000BC   411 _SCON1	=	0x00bc
                           0000BD   412 _SBUF1	=	0x00bd
                           0000BE   413 _SBAUD1	=	0x00be
                           0000BF   414 _SIF1	=	0x00bf
                           0000B4   415 _SPI1_STAT	=	0x00b4
                           0000B5   416 _SPI1_DATA	=	0x00b5
                           0000B6   417 _SPI1_CTRL	=	0x00b6
                           0000B7   418 _SPI1_CK_SE	=	0x00b7
                           0000F3   419 _ADC_CTRL	=	0x00f3
                           00F5F4   420 _ADC_DAT	=	0xf5f4
                           0000F4   421 _ADC_DAT_L	=	0x00f4
                           0000F5   422 _ADC_DAT_H	=	0x00f5
                           0000F6   423 _ADC_CHAN	=	0x00f6
                           0000A6   424 _LED_COMMON	=	0x00a6
                           0000A7   425 _LED_PWM_OE	=	0x00a7
                           00C7C6   426 _LED_DMA	=	0xc7c6
                           0000C6   427 _LED_DMA_L	=	0x00c6
                           0000C7   428 _LED_DMA_H	=	0x00c7
                           0000F7   429 _LED_STATUS	=	0x00f7
                           0000B3   430 _I2CX_INT	=	0x00b3
                           0000BB   431 _I2CS_INT_ST	=	0x00bb
                                    432 ;--------------------------------------------------------
                                    433 ; special function bits
                                    434 ;--------------------------------------------------------
                                    435 	.area RSEG    (ABS,DATA)
      000000                        436 	.org 0x0000
                           0000D7   437 _CY	=	0x00d7
                           0000D6   438 _AC	=	0x00d6
                           0000D5   439 _F0	=	0x00d5
                           0000D4   440 _RS1	=	0x00d4
                           0000D3   441 _RS0	=	0x00d3
                           0000D2   442 _OV	=	0x00d2
                           0000D1   443 _F1	=	0x00d1
                           0000D0   444 _P	=	0x00d0
                           0000AF   445 _EA	=	0x00af
                           0000AE   446 _E_DIS	=	0x00ae
                           0000AD   447 _ET2	=	0x00ad
                           0000AC   448 _ES	=	0x00ac
                           0000AB   449 _ET1	=	0x00ab
                           0000AA   450 _EX1	=	0x00aa
                           0000A9   451 _ET0	=	0x00a9
                           0000A8   452 _EX0	=	0x00a8
                           0000BF   453 _PH_FLAG	=	0x00bf
                           0000BE   454 _PL_FLAG	=	0x00be
                           0000BD   455 _PT2	=	0x00bd
                           0000BC   456 _PS	=	0x00bc
                           0000BB   457 _PT1	=	0x00bb
                           0000BA   458 _PX1	=	0x00ba
                           0000B9   459 _PT0	=	0x00b9
                           0000B8   460 _PX0	=	0x00b8
                           0000EF   461 _IE_WDOG	=	0x00ef
                           0000EE   462 _IE_GPIO	=	0x00ee
                           0000ED   463 _IE_PWM_I2C	=	0x00ed
                           0000EC   464 _IE_UART1	=	0x00ec
                           0000EB   465 _IE_ADC	=	0x00eb
                           0000E9   466 _IE_USB	=	0x00e9
                           0000E8   467 _IE_SPI0	=	0x00e8
                           000087   468 _P0_7	=	0x0087
                           000086   469 _P0_6	=	0x0086
                           000085   470 _P0_5	=	0x0085
                           000084   471 _P0_4	=	0x0084
                           000083   472 _P0_3	=	0x0083
                           000082   473 _P0_2	=	0x0082
                           000081   474 _P0_1	=	0x0081
                           000080   475 _P0_0	=	0x0080
                           000081   476 _SDA0	=	0x0081
                           000080   477 _SCL0	=	0x0080
                           000083   478 _TXD_	=	0x0083
                           000082   479 _RXD_	=	0x0082
                           000085   480 _AIN13	=	0x0085
                           000084   481 _AIN12	=	0x0084
                           000083   482 _AIN11	=	0x0083
                           000082   483 _AIN10	=	0x0082
                           000081   484 _AIN9	=	0x0081
                           000080   485 _AIN8	=	0x0080
                           000097   486 _P1_7	=	0x0097
                           000096   487 _P1_6	=	0x0096
                           000095   488 _P1_5	=	0x0095
                           000094   489 _P1_4	=	0x0094
                           000093   490 _P1_3	=	0x0093
                           000092   491 _P1_2	=	0x0092
                           000091   492 _P1_1	=	0x0091
                           000090   493 _P1_0	=	0x0090
                           000097   494 _TXD1_	=	0x0097
                           000096   495 _RXD1_	=	0x0096
                           000097   496 _SCK	=	0x0097
                           000096   497 _MISO	=	0x0096
                           000095   498 _MOSI	=	0x0095
                           000094   499 _SCS	=	0x0094
                           000092   500 _INT0_	=	0x0092
                           000091   501 _T2EX	=	0x0091
                           000091   502 _CAP2	=	0x0091
                           000090   503 _T2	=	0x0090
                           000090   504 _CAP1	=	0x0090
                           000097   505 _AIN7	=	0x0097
                           000096   506 _AIN6	=	0x0096
                           000095   507 _AIN5	=	0x0095
                           000094   508 _AIN4	=	0x0094
                           000093   509 _AIN3	=	0x0093
                           000092   510 _AIN2	=	0x0092
                           000091   511 _AIN1	=	0x0091
                           000090   512 _AIN0	=	0x0090
                           0000A7   513 _P2_7	=	0x00a7
                           0000A6   514 _P2_6	=	0x00a6
                           0000A5   515 _P2_5	=	0x00a5
                           0000A4   516 _P2_4	=	0x00a4
                           0000A3   517 _P2_3	=	0x00a3
                           0000A2   518 _P2_2	=	0x00a2
                           0000A1   519 _P2_1	=	0x00a1
                           0000A0   520 _P2_0	=	0x00a0
                           0000A7   521 _TXD1	=	0x00a7
                           0000A6   522 _RXD1	=	0x00a6
                           0000A5   523 _T2EX_	=	0x00a5
                           0000A5   524 _CAP2_	=	0x00a5
                           0000A4   525 _T2_	=	0x00a4
                           0000A4   526 _CAP1_	=	0x00a4
                           0000B7   527 _P3_7	=	0x00b7
                           0000B6   528 _P3_6	=	0x00b6
                           0000B5   529 _P3_5	=	0x00b5
                           0000B4   530 _P3_4	=	0x00b4
                           0000B3   531 _P3_3	=	0x00b3
                           0000B2   532 _P3_2	=	0x00b2
                           0000B1   533 _P3_1	=	0x00b1
                           0000B0   534 _P3_0	=	0x00b0
                           0000B7   535 _SCK1	=	0x00b7
                           0000B6   536 _MISO1	=	0x00b6
                           0000B5   537 _MOSI1	=	0x00b5
                           0000B5   538 _T1	=	0x00b5
                           0000B4   539 _T0	=	0x00b4
                           0000B3   540 _INT1	=	0x00b3
                           0000B2   541 _INT0	=	0x00b2
                           0000B1   542 _TXD	=	0x00b1
                           0000B0   543 _RXD	=	0x00b0
                           0000C6   544 _P4_6	=	0x00c6
                           0000C5   545 _P4_5	=	0x00c5
                           0000C4   546 _P4_4	=	0x00c4
                           0000C3   547 _P4_3	=	0x00c3
                           0000C2   548 _P4_2	=	0x00c2
                           0000C1   549 _P4_1	=	0x00c1
                           0000C0   550 _P4_0	=	0x00c0
                           00008F   551 _TF1	=	0x008f
                           00008E   552 _TR1	=	0x008e
                           00008D   553 _TF0	=	0x008d
                           00008C   554 _TR0	=	0x008c
                           00008B   555 _IE1	=	0x008b
                           00008A   556 _IT1	=	0x008a
                           000089   557 _IE0	=	0x0089
                           000088   558 _IT0	=	0x0088
                           00009F   559 _SM0	=	0x009f
                           00009E   560 _SM1	=	0x009e
                           00009D   561 _SM2	=	0x009d
                           00009C   562 _REN	=	0x009c
                           00009B   563 _TB8	=	0x009b
                           00009A   564 _RB8	=	0x009a
                           000099   565 _TI	=	0x0099
                           000098   566 _RI	=	0x0098
                           0000CF   567 _TF2	=	0x00cf
                           0000CF   568 _CAP1F	=	0x00cf
                           0000CE   569 _EXF2	=	0x00ce
                           0000CD   570 _RCLK	=	0x00cd
                           0000CC   571 _TCLK	=	0x00cc
                           0000CB   572 _EXEN2	=	0x00cb
                           0000CA   573 _TR2	=	0x00ca
                           0000C9   574 _C_T2	=	0x00c9
                           0000C8   575 _CP_RL2	=	0x00c8
                           0000FF   576 _S0_FST_ACT	=	0x00ff
                           0000FE   577 _S0_IF_OV	=	0x00fe
                           0000FD   578 _S0_IF_FIRST	=	0x00fd
                           0000FC   579 _S0_IF_BYTE	=	0x00fc
                           0000FB   580 _S0_FREE	=	0x00fb
                           0000FA   581 _S0_T_FIFO	=	0x00fa
                           0000F8   582 _S0_R_FIFO	=	0x00f8
                           0000F7   583 _ADC_START	=	0x00f7
                                    584 ;--------------------------------------------------------
                                    585 ; overlayable register banks
                                    586 ;--------------------------------------------------------
                                    587 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        588 	.ds 8
                                    589 ;--------------------------------------------------------
                                    590 ; internal ram data
                                    591 ;--------------------------------------------------------
                                    592 	.area DSEG    (DATA)
      000029                        593 _dynamic_keymap_set_encoder_sloc0_1_0:
      000029                        594 	.ds 2
      00002B                        595 _dynamic_keymap_get_combo_sloc0_1_0:
      00002B                        596 	.ds 1
      00002C                        597 _ak820_dynamic_read_buffer_sloc0_1_0:
      00002C                        598 	.ds 1
      00002D                        599 _dynamic_keymap_set_buffer_sloc0_1_0:
      00002D                        600 	.ds 2
      00002F                        601 _dynamic_keymap_set_buffer_sloc1_1_0:
      00002F                        602 	.ds 2
      000031                        603 _dynamic_keymap_set_buffer_sloc2_1_0:
      000031                        604 	.ds 1
      000032                        605 _dynamic_keymap_macro_get_buffer_sloc0_1_0:
      000032                        606 	.ds 2
                                    607 ;--------------------------------------------------------
                                    608 ; overlayable items in internal ram
                                    609 ;--------------------------------------------------------
                                    610 ;--------------------------------------------------------
                                    611 ; indirectly addressable internal ram data
                                    612 ;--------------------------------------------------------
                                    613 	.area ISEG    (DATA)
                                    614 ;--------------------------------------------------------
                                    615 ; absolute internal ram data
                                    616 ;--------------------------------------------------------
                                    617 	.area IABS    (ABS,DATA)
                                    618 	.area IABS    (ABS,DATA)
                                    619 ;--------------------------------------------------------
                                    620 ; bit data
                                    621 ;--------------------------------------------------------
                                    622 	.area BSEG    (BIT)
      000025                        623 _dynamic_keymap_macro_send_sloc0_1_0:
      000025                        624 	.ds 1
                                    625 ;--------------------------------------------------------
                                    626 ; paged external ram data
                                    627 ;--------------------------------------------------------
                                    628 	.area PSEG    (PAG,XDATA)
                                    629 ;--------------------------------------------------------
                                    630 ; uninitialized external ram data
                                    631 ;--------------------------------------------------------
                                    632 	.area XSEG    (XDATA)
      000B98                        633 _dynamic_keymap_key_to_eeprom_address_PARM_2:
      000B98                        634 	.ds 1
      000B99                        635 _dynamic_keymap_key_to_eeprom_address_PARM_3:
      000B99                        636 	.ds 1
      000B9A                        637 _dynamic_keymap_key_to_eeprom_address_layer_10000_371:
      000B9A                        638 	.ds 1
      000B9B                        639 _dynamic_keymap_get_keycode_PARM_2:
      000B9B                        640 	.ds 1
      000B9C                        641 _dynamic_keymap_get_keycode_PARM_3:
      000B9C                        642 	.ds 1
      000B9D                        643 _dynamic_keymap_get_keycode_layer_10000_373:
      000B9D                        644 	.ds 1
      000B9E                        645 _dynamic_keymap_set_keycode_PARM_2:
      000B9E                        646 	.ds 1
      000B9F                        647 _dynamic_keymap_set_keycode_PARM_3:
      000B9F                        648 	.ds 1
      000BA0                        649 _dynamic_keymap_set_keycode_PARM_4:
      000BA0                        650 	.ds 2
      000BA2                        651 _dynamic_keymap_set_keycode_layer_10000_377:
      000BA2                        652 	.ds 1
      000BA3                        653 _dynamic_keymap_encoder_to_eeprom_address_PARM_2:
      000BA3                        654 	.ds 1
      000BA4                        655 _dynamic_keymap_encoder_to_eeprom_address_layer_10000_381:
      000BA4                        656 	.ds 1
      000BA5                        657 _dynamic_keymap_get_encoder_PARM_2:
      000BA5                        658 	.ds 1
      000BA6                        659 _dynamic_keymap_get_encoder_PARM_3:
      000BA6                        660 	.ds 1
      000BA7                        661 _dynamic_keymap_get_encoder_layer_10000_383:
      000BA7                        662 	.ds 1
      000BA8                        663 _dynamic_keymap_set_encoder_PARM_2:
      000BA8                        664 	.ds 1
      000BA9                        665 _dynamic_keymap_set_encoder_PARM_3:
      000BA9                        666 	.ds 1
      000BAA                        667 _dynamic_keymap_set_encoder_PARM_4:
      000BAA                        668 	.ds 2
      000BAC                        669 _dynamic_keymap_set_encoder_layer_10000_387:
      000BAC                        670 	.ds 1
      000BAD                        671 _dynamic_keymap_get_tap_dance_PARM_2:
      000BAD                        672 	.ds 3
      000BB0                        673 _dynamic_keymap_get_tap_dance_index_10000_391:
      000BB0                        674 	.ds 1
      000BB1                        675 _dynamic_keymap_set_tap_dance_PARM_2:
      000BB1                        676 	.ds 3
      000BB4                        677 _dynamic_keymap_set_tap_dance_index_10000_395:
      000BB4                        678 	.ds 1
      000BB5                        679 _dynamic_keymap_get_combo_PARM_2:
      000BB5                        680 	.ds 3
      000BB8                        681 _dynamic_keymap_get_combo_index_10000_398:
      000BB8                        682 	.ds 1
      000BB9                        683 _dynamic_keymap_set_combo_PARM_2:
      000BB9                        684 	.ds 3
      000BBC                        685 _dynamic_keymap_set_combo_index_10000_404:
      000BBC                        686 	.ds 1
      000BBD                        687 _dynamic_keymap_set_combo_stored_10002_409:
      000BBD                        688 	.ds 10
      000BC7                        689 _dynamic_keymap_reset_vial_unlocked_prev_10000_412:
      000BC7                        690 	.ds 1
      000BC8                        691 _dynamic_keymap_reset_td_10001_421:
      000BC8                        692 	.ds 10
      000BD2                        693 _dynamic_keymap_reset_combo_10002_424:
      000BD2                        694 	.ds 10
      000BDC                        695 _ak820_dynamic_read_buffer_PARM_2:
      000BDC                        696 	.ds 2
      000BDE                        697 _ak820_dynamic_read_buffer_PARM_3:
      000BDE                        698 	.ds 2
      000BE0                        699 _ak820_dynamic_read_buffer_PARM_4:
      000BE0                        700 	.ds 2
      000BE2                        701 _ak820_dynamic_read_buffer_PARM_5:
      000BE2                        702 	.ds 3
      000BE5                        703 _ak820_dynamic_read_buffer_base_10000_426:
      000BE5                        704 	.ds 2
      000BE7                        705 _ak820_dynamic_read_buffer_available_10000_427:
      000BE7                        706 	.ds 1
      000BE8                        707 _dynamic_keymap_get_buffer_PARM_2:
      000BE8                        708 	.ds 2
      000BEA                        709 _dynamic_keymap_get_buffer_PARM_3:
      000BEA                        710 	.ds 3
      000BED                        711 _dynamic_keymap_get_buffer_offset_10000_433:
      000BED                        712 	.ds 2
      000BEF                        713 _dynamic_keymap_set_buffer_PARM_2:
      000BEF                        714 	.ds 2
      000BF1                        715 _dynamic_keymap_set_buffer_PARM_3:
      000BF1                        716 	.ds 3
      000BF4                        717 _dynamic_keymap_set_buffer_offset_10000_435:
      000BF4                        718 	.ds 2
      000BF6                        719 _dynamic_keymap_set_buffer_chk_offset_30001_442:
      000BF6                        720 	.ds 1
      000BF7                        721 _dynamic_keymap_set_buffer_chk_sz_30001_442:
      000BF7                        722 	.ds 1
      000BF8                        723 _dynamic_keymap_set_buffer_i_40001_449:
      000BF8                        724 	.ds 1
      000BF9                        725 _keycode_at_keymap_location_PARM_2:
      000BF9                        726 	.ds 1
      000BFA                        727 _keycode_at_keymap_location_PARM_3:
      000BFA                        728 	.ds 1
      000BFB                        729 _keycode_at_keymap_location_layer_num_10000_453:
      000BFB                        730 	.ds 1
      000BFC                        731 _keycode_at_encodermap_location_PARM_2:
      000BFC                        732 	.ds 1
      000BFD                        733 _keycode_at_encodermap_location_PARM_3:
      000BFD                        734 	.ds 1
      000BFE                        735 _keycode_at_encodermap_location_layer_num_10000_457:
      000BFE                        736 	.ds 1
      000BFF                        737 _dynamic_keymap_macro_get_buffer_PARM_2:
      000BFF                        738 	.ds 2
      000C01                        739 _dynamic_keymap_macro_get_buffer_PARM_3:
      000C01                        740 	.ds 3
      000C04                        741 _dynamic_keymap_macro_get_buffer_offset_10000_465:
      000C04                        742 	.ds 2
      000C06                        743 _dynamic_keymap_macro_set_buffer_PARM_2:
      000C06                        744 	.ds 2
      000C08                        745 _dynamic_keymap_macro_set_buffer_PARM_3:
      000C08                        746 	.ds 3
      000C0B                        747 _dynamic_keymap_macro_set_buffer_offset_10000_467:
      000C0B                        748 	.ds 2
      000C0D                        749 _decode_keycode_kc_10000_471:
      000C0D                        750 	.ds 2
      000C0F                        751 _dynamic_keymap_macro_send_id_10000_474:
      000C0F                        752 	.ds 1
      000C10                        753 _dynamic_keymap_macro_send_sending_10000_475:
      000C10                        754 	.ds 1
      000C11                        755 _dynamic_keymap_macro_send_p_10001_480:
      000C11                        756 	.ds 2
      000C13                        757 _dynamic_keymap_macro_send_data_10003_487:
      000C13                        758 	.ds 4
                                    759 ;--------------------------------------------------------
                                    760 ; absolute external ram data
                                    761 ;--------------------------------------------------------
                                    762 	.area XABS    (ABS,XDATA)
                                    763 ;--------------------------------------------------------
                                    764 ; initialized external ram data
                                    765 ;--------------------------------------------------------
                                    766 	.area XISEG   (XDATA)
                                    767 	.area HOME    (CODE)
                                    768 	.area GSINIT0 (CODE)
                                    769 	.area GSINIT1 (CODE)
                                    770 	.area GSINIT2 (CODE)
                                    771 	.area GSINIT3 (CODE)
                                    772 	.area GSINIT4 (CODE)
                                    773 	.area GSINIT5 (CODE)
                                    774 	.area GSINIT  (CODE)
                                    775 	.area GSFINAL (CODE)
                                    776 	.area CSEG    (CODE)
                                    777 ;--------------------------------------------------------
                                    778 ; global & static initialisations
                                    779 ;--------------------------------------------------------
                                    780 	.area HOME    (CODE)
                                    781 	.area GSINIT  (CODE)
                                    782 	.area GSFINAL (CODE)
                                    783 	.area GSINIT  (CODE)
                                    784 ;--------------------------------------------------------
                                    785 ; Home
                                    786 ;--------------------------------------------------------
                                    787 	.area HOME    (CODE)
                                    788 	.area HOME    (CODE)
                                    789 ;--------------------------------------------------------
                                    790 ; code
                                    791 ;--------------------------------------------------------
                                    792 	.area CSEG    (CODE)
                                    793 ;------------------------------------------------------------
                                    794 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    795 ;------------------------------------------------------------
                                    796 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_232'
                                    797 ;------------------------------------------------------------
                                    798 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    799 ;	-----------------------------------------
                           000007   800 	ar7 = 0x07
                           000006   801 	ar6 = 0x06
                           000005   802 	ar5 = 0x05
                           000004   803 	ar4 = 0x04
                           000003   804 	ar3 = 0x03
                           000002   805 	ar2 = 0x02
                           000001   806 	ar1 = 0x01
                           000000   807 	ar0 = 0x00
                                    808 ;	 function dynamic_keymap_get_layer_count
                                    809 ;	-----------------------------------------
      0087A3                        810 _dynamic_keymap_get_layer_count:
                                    811 ;	quantum/dynamic_keymap.c:200: return DYNAMIC_KEYMAP_LAYER_COUNT;
      0087A3 75 82 06         [24]  812 	mov	dpl, #0x06
                                    813 ;	quantum/dynamic_keymap.c:201: }
      0087A6 22               [24]  814 	ret
                                    815 ;------------------------------------------------------------
                                    816 ;Allocation info for local variables in function 'dynamic_keymap_key_to_eeprom_address'
                                    817 ;------------------------------------------------------------
                                    818 ;row           Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_2'
                                    819 ;column        Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_3'
                                    820 ;layer         Allocated with name '_dynamic_keymap_key_to_eeprom_address_layer_10000_371'
                                    821 ;------------------------------------------------------------
                                    822 ;	quantum/dynamic_keymap.c:203: void *dynamic_keymap_key_to_eeprom_address(uint8_t layer, uint8_t row, uint8_t column) {
                                    823 ;	-----------------------------------------
                                    824 ;	 function dynamic_keymap_key_to_eeprom_address
                                    825 ;	-----------------------------------------
      0087A7                        826 _dynamic_keymap_key_to_eeprom_address:
      0087A7 E5 82            [12]  827 	mov	a,dpl
      0087A9 90 0B 9A         [24]  828 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_layer_10000_371
      0087AC F0               [24]  829 	movx	@dptr,a
                                    830 ;	quantum/dynamic_keymap.c:205: return ((uint8_t *)DYNAMIC_KEYMAP_EEPROM_ADDR) + (layer * MATRIX_ROWS * MATRIX_COLS * 2) + (row * MATRIX_COLS * 2) + (column * 2);
      0087AD E0               [24]  831 	movx	a,@dptr
      0087AE FF               [12]  832 	mov	r7,a
      0087AF 7E 00            [12]  833 	mov	r6,#0x00
      0087B1 74 40            [12]  834 	mov	a,#0x40
      0087B3 2E               [12]  835 	add	a, r6
      0087B4 FE               [12]  836 	mov	r6,a
      0087B5 E4               [12]  837 	clr	a
      0087B6 3F               [12]  838 	addc	a, r7
      0087B7 FF               [12]  839 	mov	r7,a
      0087B8 7D 00            [12]  840 	mov	r5,#0x00
      0087BA 90 0B 98         [24]  841 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      0087BD E0               [24]  842 	movx	a,@dptr
      0087BE 75 F0 10         [24]  843 	mov	b,#0x10
      0087C1 A4               [48]  844 	mul	ab
      0087C2 2E               [12]  845 	add	a, r6
      0087C3 FE               [12]  846 	mov	r6,a
      0087C4 EF               [12]  847 	mov	a,r7
      0087C5 35 F0            [12]  848 	addc	a, b
      0087C7 FF               [12]  849 	mov	r7,a
      0087C8 90 0B 99         [24]  850 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      0087CB E0               [24]  851 	movx	a,@dptr
      0087CC 7C 00            [12]  852 	mov	r4,#0x00
      0087CE 25 E0            [12]  853 	add	a,acc
      0087D0 FB               [12]  854 	mov	r3,a
      0087D1 EC               [12]  855 	mov	a,r4
      0087D2 33               [12]  856 	rlc	a
      0087D3 FC               [12]  857 	mov	r4,a
      0087D4 EB               [12]  858 	mov	a,r3
      0087D5 2E               [12]  859 	add	a, r6
      0087D6 FE               [12]  860 	mov	r6,a
      0087D7 EC               [12]  861 	mov	a,r4
      0087D8 3F               [12]  862 	addc	a, r7
      0087D9 FF               [12]  863 	mov	r7,a
      0087DA 12 43 23         [24]  864 	lcall	_ak820_outline_0119
      0087DD 8D F0            [24]  865 	mov	b, r5
                                    866 ;	quantum/dynamic_keymap.c:206: }
      0087DF 22               [24]  867 	ret
                                    868 ;------------------------------------------------------------
                                    869 ;Allocation info for local variables in function 'dynamic_keymap_get_keycode'
                                    870 ;------------------------------------------------------------
                                    871 ;row           Allocated with name '_dynamic_keymap_get_keycode_PARM_2'
                                    872 ;column        Allocated with name '_dynamic_keymap_get_keycode_PARM_3'
                                    873 ;layer         Allocated with name '_dynamic_keymap_get_keycode_layer_10000_373'
                                    874 ;address       Allocated with name '_dynamic_keymap_get_keycode_address_10001_376'
                                    875 ;keycode       Allocated with name '_dynamic_keymap_get_keycode_keycode_10001_376'
                                    876 ;------------------------------------------------------------
                                    877 ;	quantum/dynamic_keymap.c:208: uint16_t dynamic_keymap_get_keycode(uint8_t layer, uint8_t row, uint8_t column) {
                                    878 ;	-----------------------------------------
                                    879 ;	 function dynamic_keymap_get_keycode
                                    880 ;	-----------------------------------------
      0087E0                        881 _dynamic_keymap_get_keycode:
      0087E0 E5 82            [12]  882 	mov	a,dpl
      0087E2 90 0B 9D         [24]  883 	mov	dptr,#_dynamic_keymap_get_keycode_layer_10000_373
      0087E5 F0               [24]  884 	movx	@dptr,a
                                    885 ;	quantum/dynamic_keymap.c:209: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return KC_NO;
      0087E6 E0               [24]  886 	movx	a,@dptr
      0087E7 FF               [12]  887 	mov	r7,a
      0087E8 BF 06 00         [24]  888 	cjne	r7,#0x06,00121$
      0087EB                        889 00121$:
      0087EB 50 14            [24]  890 	jnc	00101$
      0087ED 90 0B 9B         [24]  891 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      0087F0 E0               [24]  892 	movx	a,@dptr
      0087F1 FE               [12]  893 	mov	r6,a
      0087F2 BE 10 00         [24]  894 	cjne	r6,#0x10,00123$
      0087F5                        895 00123$:
      0087F5 50 0A            [24]  896 	jnc	00101$
      0087F7 90 0B 9C         [24]  897 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      0087FA E0               [24]  898 	movx	a,@dptr
      0087FB FD               [12]  899 	mov	r5,a
      0087FC BD 08 00         [24]  900 	cjne	r5,#0x08,00125$
      0087FF                        901 00125$:
      0087FF 40 04            [24]  902 	jc	00102$
      008801                        903 00101$:
      008801 90 00 00         [24]  904 	mov	dptr,#0x0000
      008804 22               [24]  905 	ret
      008805                        906 00102$:
                                    907 ;	quantum/dynamic_keymap.c:210: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      008805 12 93 9D         [24]  908 	lcall	_ak820_outline_0101
      008808 12 87 A7         [24]  909 	lcall	_dynamic_keymap_key_to_eeprom_address
                                    910 ;	quantum/dynamic_keymap.c:212: uint16_t keycode = eeprom_read_byte(address) << 8;
      00880B 12 93 B1         [24]  911 	lcall	_ak820_outline_0117
      00880E 12 40 35         [24]  912 	lcall	_eeprom_read_byte
      008811 AB 82            [24]  913 	mov	r3,dpl
      008813 7C 00            [12]  914 	mov	r4,#0x00
                                    915 ;	quantum/dynamic_keymap.c:213: keycode |= eeprom_read_byte(address + 1);
      008815 0D               [12]  916 	inc	r5
      008816 BD 00 01         [24]  917 	cjne	r5,#0x00,00127$
      008819 0E               [12]  918 	inc	r6
      00881A                        919 00127$:
      00881A 12 53 FF         [24]  920 	lcall	_ak820_outline_0050
      00881D 12 40 35         [24]  921 	lcall	_eeprom_read_byte
      008820 AF 82            [24]  922 	mov	r7, dpl
      008822 7E 00            [12]  923 	mov	r6,#0x00
      008824 EF               [12]  924 	mov	a,r7
      008825 42 04            [12]  925 	orl	ar4,a
      008827 EE               [12]  926 	mov	a,r6
      008828 42 03            [12]  927 	orl	ar3,a
                                    928 ;	quantum/dynamic_keymap.c:214: return keycode;
      00882A 12 43 53         [24]  929 	lcall	_ak820_outline_0184
                                    930 ;	quantum/dynamic_keymap.c:215: }
      00882D 22               [24]  931 	ret
                                    932 ;------------------------------------------------------------
                                    933 ;Allocation info for local variables in function 'dynamic_keymap_set_keycode'
                                    934 ;------------------------------------------------------------
                                    935 ;row           Allocated with name '_dynamic_keymap_set_keycode_PARM_2'
                                    936 ;column        Allocated with name '_dynamic_keymap_set_keycode_PARM_3'
                                    937 ;keycode       Allocated with name '_dynamic_keymap_set_keycode_PARM_4'
                                    938 ;layer         Allocated with name '_dynamic_keymap_set_keycode_layer_10000_377'
                                    939 ;address       Allocated with name '_dynamic_keymap_set_keycode_address_10001_380'
                                    940 ;------------------------------------------------------------
                                    941 ;	quantum/dynamic_keymap.c:217: void dynamic_keymap_set_keycode(uint8_t layer, uint8_t row, uint8_t column, uint16_t keycode) {
                                    942 ;	-----------------------------------------
                                    943 ;	 function dynamic_keymap_set_keycode
                                    944 ;	-----------------------------------------
      00882E                        945 _dynamic_keymap_set_keycode:
      00882E E5 82            [12]  946 	mov	a,dpl
      008830 90 0B A2         [24]  947 	mov	dptr,#_dynamic_keymap_set_keycode_layer_10000_377
      008833 F0               [24]  948 	movx	@dptr,a
                                    949 ;	quantum/dynamic_keymap.c:218: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return;
      008834 E0               [24]  950 	movx	a,@dptr
      008835 FF               [12]  951 	mov	r7,a
      008836 BF 06 00         [24]  952 	cjne	r7,#0x06,00121$
      008839                        953 00121$:
      008839 50 14            [24]  954 	jnc	00101$
      00883B 90 0B 9E         [24]  955 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      00883E E0               [24]  956 	movx	a,@dptr
      00883F FE               [12]  957 	mov	r6,a
      008840 BE 10 00         [24]  958 	cjne	r6,#0x10,00123$
      008843                        959 00123$:
      008843 50 0A            [24]  960 	jnc	00101$
      008845 90 0B 9F         [24]  961 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      008848 E0               [24]  962 	movx	a,@dptr
      008849 FD               [12]  963 	mov	r5,a
      00884A BD 08 00         [24]  964 	cjne	r5,#0x08,00125$
      00884D                        965 00125$:
      00884D 40 01            [24]  966 	jc	00102$
      00884F                        967 00101$:
      00884F 22               [24]  968 	ret
      008850                        969 00102$:
                                    970 ;	quantum/dynamic_keymap.c:219: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      008850 12 93 9D         [24]  971 	lcall	_ak820_outline_0101
      008853 12 87 A7         [24]  972 	lcall	_dynamic_keymap_key_to_eeprom_address
      008856 12 93 B1         [24]  973 	lcall	_ak820_outline_0117
                                    974 ;	quantum/dynamic_keymap.c:221: eeprom_update_byte(address, (uint8_t)(keycode >> 8));
      008859 90 0B A0         [24]  975 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      00885C E0               [24]  976 	movx	a,@dptr
      00885D FB               [12]  977 	mov	r3,a
      00885E A3               [24]  978 	inc	dptr
      00885F E0               [24]  979 	movx	a,@dptr
      008860 90 07 61         [24]  980 	mov	dptr,#_eeprom_update_byte_PARM_2
      008863 F0               [24]  981 	movx	@dptr,a
      008864 12 53 FF         [24]  982 	lcall	_ak820_outline_0050
      008867 12 52 E7         [24]  983 	lcall	_eeprom_update_byte
                                    984 ;	quantum/dynamic_keymap.c:222: eeprom_update_byte(address + 1, (uint8_t)(keycode & 0xFF));
      00886A 0D               [12]  985 	inc	r5
      00886B BD 00 01         [24]  986 	cjne	r5,#0x00,00127$
      00886E 0E               [12]  987 	inc	r6
      00886F                        988 00127$:
      00886F 90 07 61         [24]  989 	mov	dptr,#_eeprom_update_byte_PARM_2
      008872 EB               [12]  990 	mov	a,r3
      008873 F0               [24]  991 	movx	@dptr,a
      008874 12 53 FF         [24]  992 	lcall	_ak820_outline_0050
                                    993 ;	quantum/dynamic_keymap.c:223: }
      008877 02 52 E7         [24]  994 	ljmp	_eeprom_update_byte
                                    995 ;------------------------------------------------------------
                                    996 ;Allocation info for local variables in function 'dynamic_keymap_encoder_to_eeprom_address'
                                    997 ;------------------------------------------------------------
                                    998 ;encoder_id    Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_PARM_2'
                                    999 ;layer         Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_layer_10000_381'
                                   1000 ;------------------------------------------------------------
                                   1001 ;	quantum/dynamic_keymap.c:226: void *dynamic_keymap_encoder_to_eeprom_address(uint8_t layer, uint8_t encoder_id) {
                                   1002 ;	-----------------------------------------
                                   1003 ;	 function dynamic_keymap_encoder_to_eeprom_address
                                   1004 ;	-----------------------------------------
      00887A                       1005 _dynamic_keymap_encoder_to_eeprom_address:
      00887A E5 82            [12] 1006 	mov	a,dpl
      00887C 90 0B A4         [24] 1007 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_layer_10000_381
      00887F F0               [24] 1008 	movx	@dptr,a
                                   1009 ;	quantum/dynamic_keymap.c:227: return ((uint8_t *)DYNAMIC_KEYMAP_ENCODER_EEPROM_ADDR) + (layer * NUM_ENCODERS * 2 * 2) + (encoder_id * 2 * 2);
      008880 E0               [24] 1010 	movx	a,@dptr
      008881 12 38 86         [24] 1011 	lcall	_ak820_outline_0189
      008884 24 40            [12] 1012 	add	a, #0x40
      008886 FD               [12] 1013 	mov	r5,a
      008887 74 06            [12] 1014 	mov	a,#0x06
      008889 35 F0            [12] 1015 	addc	a, b
      00888B FE               [12] 1016 	mov	r6,a
      00888C 7F 00            [12] 1017 	mov	r7,#0x00
      00888E 90 0B A3         [24] 1018 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      008891 E0               [24] 1019 	movx	a,@dptr
      008892 12 38 86         [24] 1020 	lcall	_ak820_outline_0189
      008895 2D               [12] 1021 	add	a, r5
      008896 FD               [12] 1022 	mov	r5,a
      008897 EE               [12] 1023 	mov	a,r6
      008898 35 F0            [12] 1024 	addc	a, b
      00889A FE               [12] 1025 	mov	r6,a
      00889B 12 53 FF         [24] 1026 	lcall	_ak820_outline_0050
                                   1027 ;	quantum/dynamic_keymap.c:228: }
      00889E 22               [24] 1028 	ret
                                   1029 ;------------------------------------------------------------
                                   1030 ;Allocation info for local variables in function 'dynamic_keymap_get_encoder'
                                   1031 ;------------------------------------------------------------
                                   1032 ;encoder_id    Allocated with name '_dynamic_keymap_get_encoder_PARM_2'
                                   1033 ;clockwise     Allocated with name '_dynamic_keymap_get_encoder_PARM_3'
                                   1034 ;layer         Allocated with name '_dynamic_keymap_get_encoder_layer_10000_383'
                                   1035 ;address       Allocated with name '_dynamic_keymap_get_encoder_address_10001_386'
                                   1036 ;keycode       Allocated with name '_dynamic_keymap_get_encoder_keycode_10001_386'
                                   1037 ;------------------------------------------------------------
                                   1038 ;	quantum/dynamic_keymap.c:230: uint16_t dynamic_keymap_get_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise) {
                                   1039 ;	-----------------------------------------
                                   1040 ;	 function dynamic_keymap_get_encoder
                                   1041 ;	-----------------------------------------
      00889F                       1042 _dynamic_keymap_get_encoder:
      00889F E5 82            [12] 1043 	mov	a,dpl
      0088A1 90 0B A7         [24] 1044 	mov	dptr,#_dynamic_keymap_get_encoder_layer_10000_383
      0088A4 F0               [24] 1045 	movx	@dptr,a
                                   1046 ;	quantum/dynamic_keymap.c:231: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return KC_NO;
      0088A5 E0               [24] 1047 	movx	a,@dptr
      0088A6 FF               [12] 1048 	mov	r7,a
      0088A7 BF 06 00         [24] 1049 	cjne	r7,#0x06,00131$
      0088AA                       1050 00131$:
      0088AA 50 0A            [24] 1051 	jnc	00101$
      0088AC 90 0B A5         [24] 1052 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      0088AF E0               [24] 1053 	movx	a,@dptr
      0088B0 FE               [12] 1054 	mov	r6,a
      0088B1 BE 01 00         [24] 1055 	cjne	r6,#0x01,00133$
      0088B4                       1056 00133$:
      0088B4 40 04            [24] 1057 	jc	00102$
      0088B6                       1058 00101$:
      0088B6 90 00 00         [24] 1059 	mov	dptr,#0x0000
      0088B9 22               [24] 1060 	ret
      0088BA                       1061 00102$:
                                   1062 ;	quantum/dynamic_keymap.c:232: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      0088BA 90 0B A3         [24] 1063 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      0088BD E4               [12] 1064 	clr	a
      0088BE F0               [24] 1065 	movx	@dptr,a
      0088BF 8F 82            [24] 1066 	mov	dpl, r7
      0088C1 11 7A            [12] 1067 	acall	_dynamic_keymap_encoder_to_eeprom_address
      0088C3 12 93 B1         [24] 1068 	lcall	_ak820_outline_0117
                                   1069 ;	quantum/dynamic_keymap.c:234: uint16_t keycode = ((uint16_t)eeprom_read_byte(address + (clockwise ? 0 : 2))) << 8;
      0088C6 90 0B A6         [24] 1070 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      0088C9 E0               [24] 1071 	movx	a,@dptr
      0088CA FC               [12] 1072 	mov	r4,a
      0088CB E0               [24] 1073 	movx	a,@dptr
      0088CC 60 04            [24] 1074 	jz	00106$
      0088CE 7B 00            [12] 1075 	mov	r3,#0x00
      0088D0 80 02            [24] 1076 	sjmp	00107$
      0088D2                       1077 00106$:
      0088D2 7B 02            [12] 1078 	mov	r3,#0x02
      0088D4                       1079 00107$:
      0088D4 EB               [12] 1080 	mov	a,r3
      0088D5 12 93 66         [24] 1081 	lcall	_ak820_outline_0026
      0088D8 12 40 35         [24] 1082 	lcall	_eeprom_read_byte
      0088DB AA 82            [24] 1083 	mov	r2,dpl
      0088DD 7B 00            [12] 1084 	mov	r3,#0x00
                                   1085 ;	quantum/dynamic_keymap.c:235: keycode |= eeprom_read_byte(address + (clockwise ? 0 : 2) + 1);
      0088DF EC               [12] 1086 	mov	a,r4
      0088E0 60 04            [24] 1087 	jz	00108$
      0088E2 7C 00            [12] 1088 	mov	r4,#0x00
      0088E4 80 02            [24] 1089 	sjmp	00109$
      0088E6                       1090 00108$:
      0088E6 7C 02            [12] 1091 	mov	r4,#0x02
      0088E8                       1092 00109$:
      0088E8 EC               [12] 1093 	mov	a,r4
      0088E9 12 38 75         [24] 1094 	lcall	_ak820_outline_0162
      0088EC 0D               [12] 1095 	inc	r5
      0088ED BD 00 01         [24] 1096 	cjne	r5,#0x00,00137$
      0088F0 0E               [12] 1097 	inc	r6
      0088F1                       1098 00137$:
      0088F1 12 53 FF         [24] 1099 	lcall	_ak820_outline_0050
      0088F4 12 40 35         [24] 1100 	lcall	_eeprom_read_byte
      0088F7 AF 82            [24] 1101 	mov	r7, dpl
      0088F9 7E 00            [12] 1102 	mov	r6,#0x00
      0088FB EF               [12] 1103 	mov	a,r7
      0088FC 42 03            [12] 1104 	orl	ar3,a
      0088FE EE               [12] 1105 	mov	a,r6
      0088FF 42 02            [12] 1106 	orl	ar2,a
                                   1107 ;	quantum/dynamic_keymap.c:236: return keycode;
      008901 8B 82            [24] 1108 	mov	dpl, r3
      008903 8A 83            [24] 1109 	mov	dph, r2
                                   1110 ;	quantum/dynamic_keymap.c:237: }
      008905 22               [24] 1111 	ret
                                   1112 ;------------------------------------------------------------
                                   1113 ;Allocation info for local variables in function 'dynamic_keymap_set_encoder'
                                   1114 ;------------------------------------------------------------
                                   1115 ;sloc0         Allocated with name '_dynamic_keymap_set_encoder_sloc0_1_0'
                                   1116 ;encoder_id    Allocated with name '_dynamic_keymap_set_encoder_PARM_2'
                                   1117 ;clockwise     Allocated with name '_dynamic_keymap_set_encoder_PARM_3'
                                   1118 ;keycode       Allocated with name '_dynamic_keymap_set_encoder_PARM_4'
                                   1119 ;layer         Allocated with name '_dynamic_keymap_set_encoder_layer_10000_387'
                                   1120 ;address       Allocated with name '_dynamic_keymap_set_encoder_address_10001_390'
                                   1121 ;------------------------------------------------------------
                                   1122 ;	quantum/dynamic_keymap.c:239: void dynamic_keymap_set_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise, uint16_t keycode) {
                                   1123 ;	-----------------------------------------
                                   1124 ;	 function dynamic_keymap_set_encoder
                                   1125 ;	-----------------------------------------
      008906                       1126 _dynamic_keymap_set_encoder:
      008906 E5 82            [12] 1127 	mov	a,dpl
      008908 90 0B AC         [24] 1128 	mov	dptr,#_dynamic_keymap_set_encoder_layer_10000_387
      00890B F0               [24] 1129 	movx	@dptr,a
                                   1130 ;	quantum/dynamic_keymap.c:240: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return;
      00890C E0               [24] 1131 	movx	a,@dptr
      00890D FF               [12] 1132 	mov	r7,a
      00890E BF 06 00         [24] 1133 	cjne	r7,#0x06,00131$
      008911                       1134 00131$:
      008911 50 0A            [24] 1135 	jnc	00101$
      008913 90 0B A8         [24] 1136 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      008916 E0               [24] 1137 	movx	a,@dptr
      008917 FE               [12] 1138 	mov	r6,a
      008918 BE 01 00         [24] 1139 	cjne	r6,#0x01,00133$
      00891B                       1140 00133$:
      00891B 40 01            [24] 1141 	jc	00102$
      00891D                       1142 00101$:
      00891D 22               [24] 1143 	ret
      00891E                       1144 00102$:
                                   1145 ;	quantum/dynamic_keymap.c:241: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      00891E 90 0B A3         [24] 1146 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      008921 E4               [12] 1147 	clr	a
      008922 F0               [24] 1148 	movx	@dptr,a
      008923 8F 82            [24] 1149 	mov	dpl, r7
      008925 11 7A            [12] 1150 	acall	_dynamic_keymap_encoder_to_eeprom_address
      008927 12 93 B1         [24] 1151 	lcall	_ak820_outline_0117
                                   1152 ;	quantum/dynamic_keymap.c:243: eeprom_update_byte(address + (clockwise ? 0 : 2), (uint8_t)(keycode >> 8));
      00892A 90 0B A9         [24] 1153 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      00892D E0               [24] 1154 	movx	a,@dptr
      00892E FC               [12] 1155 	mov	r4,a
      00892F E0               [24] 1156 	movx	a,@dptr
      008930 60 04            [24] 1157 	jz	00106$
      008932 7B 00            [12] 1158 	mov	r3,#0x00
      008934 80 02            [24] 1159 	sjmp	00107$
      008936                       1160 00106$:
      008936 7B 02            [12] 1161 	mov	r3,#0x02
      008938                       1162 00107$:
      008938 EB               [12] 1163 	mov	a,r3
      008939 12 93 C3         [24] 1164 	lcall	_ak820_outline_0138
      00893C 8F 03            [24] 1165 	mov	ar3,r7
      00893E 90 0B AA         [24] 1166 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008941 E0               [24] 1167 	movx	a,@dptr
      008942 F5 29            [12] 1168 	mov	_dynamic_keymap_set_encoder_sloc0_1_0,a
      008944 A3               [24] 1169 	inc	dptr
      008945 E0               [24] 1170 	movx	a,@dptr
      008946 F5 2A            [12] 1171 	mov	(_dynamic_keymap_set_encoder_sloc0_1_0 + 1),a
      008948 90 07 61         [24] 1172 	mov	dptr,#_eeprom_update_byte_PARM_2
      00894B F0               [24] 1173 	movx	@dptr,a
      00894C 12 43 38         [24] 1174 	lcall	_ak820_outline_0150
      00894F 8B F0            [24] 1175 	mov	b, r3
      008951 12 52 E7         [24] 1176 	lcall	_eeprom_update_byte
                                   1177 ;	quantum/dynamic_keymap.c:244: eeprom_update_byte(address + (clockwise ? 0 : 2) + 1, (uint8_t)(keycode & 0xFF));
      008954 EC               [12] 1178 	mov	a,r4
      008955 60 04            [24] 1179 	jz	00108$
      008957 7C 00            [12] 1180 	mov	r4,#0x00
      008959 80 02            [24] 1181 	sjmp	00109$
      00895B                       1182 00108$:
      00895B 7C 02            [12] 1183 	mov	r4,#0x02
      00895D                       1184 00109$:
      00895D EC               [12] 1185 	mov	a,r4
      00895E 12 38 75         [24] 1186 	lcall	_ak820_outline_0162
      008961 0D               [12] 1187 	inc	r5
      008962 BD 00 01         [24] 1188 	cjne	r5,#0x00,00137$
      008965 0E               [12] 1189 	inc	r6
      008966                       1190 00137$:
      008966 90 07 61         [24] 1191 	mov	dptr,#_eeprom_update_byte_PARM_2
      008969 E5 29            [12] 1192 	mov	a,_dynamic_keymap_set_encoder_sloc0_1_0
      00896B F0               [24] 1193 	movx	@dptr,a
      00896C 12 53 FF         [24] 1194 	lcall	_ak820_outline_0050
                                   1195 ;	quantum/dynamic_keymap.c:245: }
      00896F 02 52 E7         [24] 1196 	ljmp	_eeprom_update_byte
                                   1197 ;------------------------------------------------------------
                                   1198 ;Allocation info for local variables in function 'dynamic_keymap_get_tap_dance'
                                   1199 ;------------------------------------------------------------
                                   1200 ;buffer        Allocated with name '_dynamic_keymap_get_tap_dance_PARM_2'
                                   1201 ;index         Allocated with name '_dynamic_keymap_get_tap_dance_index_10000_391'
                                   1202 ;entry         Allocated with name '_dynamic_keymap_get_tap_dance_entry_10000_392'
                                   1203 ;------------------------------------------------------------
                                   1204 ;	quantum/dynamic_keymap.c:268: int dynamic_keymap_get_tap_dance(uint8_t index, vial_tap_dance_entry_t *buffer) {
                                   1205 ;	-----------------------------------------
                                   1206 ;	 function dynamic_keymap_get_tap_dance
                                   1207 ;	-----------------------------------------
      008972                       1208 _dynamic_keymap_get_tap_dance:
      008972 E5 82            [12] 1209 	mov	a,dpl
      008974 90 0B B0         [24] 1210 	mov	dptr,#_dynamic_keymap_get_tap_dance_index_10000_391
      008977 F0               [24] 1211 	movx	@dptr,a
                                   1212 ;	quantum/dynamic_keymap.c:269: vial_tap_dance_entry_t AK820_STATE_MEM *entry = (vial_tap_dance_entry_t AK820_STATE_MEM *)buffer;
      008978 90 0B AD         [24] 1213 	mov	dptr,#_dynamic_keymap_get_tap_dance_PARM_2
      00897B 12 37 F7         [24] 1214 	lcall	_ak820_outline_0056
                                   1215 ;	quantum/dynamic_keymap.c:270: if (index >= AK820_EXTENSION_ENTRIES) return -1;
      00897E 90 0B B0         [24] 1216 	mov	dptr,#_dynamic_keymap_get_tap_dance_index_10000_391
      008981 E0               [24] 1217 	movx	a,@dptr
      008982 FD               [12] 1218 	mov	r5,a
      008983 BD 08 00         [24] 1219 	cjne	r5,#0x08,00130$
      008986                       1220 00130$:
      008986 40 04            [24] 1221 	jc	00102$
      008988 90 FF FF         [24] 1222 	mov	dptr,#0xffff
      00898B 22               [24] 1223 	ret
      00898C                       1224 00102$:
                                   1225 ;	quantum/dynamic_keymap.c:271: ak820_eeprom_read_block_xdata(entry, (const void *)(VIAL_TAP_DANCE_EEPROM_ADDR + AK820_EXTENSION_OFFSET(index)), sizeof(*entry));
      00898C 8E 03            [24] 1226 	mov	ar3,r6
      00898E 8F 04            [24] 1227 	mov	ar4,r7
      008990 BD 06 00         [24] 1228 	cjne	r5,#0x06,00132$
      008993                       1229 00132$:
      008993 50 0C            [24] 1230 	jnc	00107$
      008995 8D 02            [24] 1231 	mov	ar2,r5
      008997 EA               [12] 1232 	mov	a,r2
      008998 75 F0 0A         [24] 1233 	mov	b,#0x0a
      00899B A4               [48] 1234 	mul	ab
      00899C F9               [12] 1235 	mov	r1,a
      00899D 7A 00            [12] 1236 	mov	r2,#0x00
      00899F 80 11            [24] 1237 	sjmp	00108$
      0089A1                       1238 00107$:
      0089A1 ED               [12] 1239 	mov	a,r5
      0089A2 24 FA            [12] 1240 	add	a,#0xfa
      0089A4 75 F0 0A         [24] 1241 	mov	b,#0x0a
      0089A7 A4               [48] 1242 	mul	ab
      0089A8 F8               [12] 1243 	mov	r0,a
      0089A9 7D 00            [12] 1244 	mov	r5,#0x00
      0089AB 74 40            [12] 1245 	mov	a,#0x40
      0089AD 28               [12] 1246 	add	a, r0
      0089AE F9               [12] 1247 	mov	r1,a
      0089AF E4               [12] 1248 	clr	a
      0089B0 3D               [12] 1249 	addc	a, r5
      0089B1 FA               [12] 1250 	mov	r2,a
      0089B2                       1251 00108$:
      0089B2 74 C0            [12] 1252 	mov	a,#0xc0
      0089B4 29               [12] 1253 	add	a, r1
      0089B5 F9               [12] 1254 	mov	r1,a
      0089B6 74 06            [12] 1255 	mov	a,#0x06
      0089B8 3A               [12] 1256 	addc	a, r2
      0089B9 FA               [12] 1257 	mov	r2,a
      0089BA 90 05 81         [24] 1258 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      0089BD E9               [12] 1259 	mov	a,r1
      0089BE F0               [24] 1260 	movx	@dptr,a
      0089BF EA               [12] 1261 	mov	a,r2
      0089C0 12 38 1C         [24] 1262 	lcall	_ak820_outline_0075
      0089C3 90 05 84         [24] 1263 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      0089C6 12 93 AA         [24] 1264 	lcall	_ak820_outline_0113
      0089C9 12 33 FC         [24] 1265 	lcall	_ak820_outline_0124
      0089CC C0 07            [24] 1266 	push	ar7
      0089CE C0 06            [24] 1267 	push	ar6
      0089D0 12 40 70         [24] 1268 	lcall	_ak820_eeprom_read_block_xdata
      0089D3 D0 06            [24] 1269 	pop	ar6
      0089D5 D0 07            [24] 1270 	pop	ar7
                                   1271 ;	quantum/dynamic_keymap.c:272: if (!ak820_tap_dance_valid(entry)) memset(entry, 0, sizeof(*entry));
      0089D7 12 43 23         [24] 1272 	lcall	_ak820_outline_0119
      0089DA C0 07            [24] 1273 	push	ar7
      0089DC C0 06            [24] 1274 	push	ar6
      0089DE 12 43 58         [24] 1275 	lcall	_ak820_tap_dance_valid
      0089E1 E5 82            [12] 1276 	mov	a, dpl
      0089E3 D0 06            [24] 1277 	pop	ar6
      0089E5 D0 07            [24] 1278 	pop	ar7
      0089E7 70 07            [24] 1279 	jnz	00104$
      0089E9 FD               [12] 1280 	mov	r5,a
      0089EA 12 93 74         [24] 1281 	lcall	_ak820_outline_0041
      0089ED 12 BD 04         [24] 1282 	lcall	_memset
      0089F0                       1283 00104$:
                                   1284 ;	quantum/dynamic_keymap.c:273: return 0;
      0089F0 90 00 00         [24] 1285 	mov	dptr,#0x0000
                                   1286 ;	quantum/dynamic_keymap.c:274: }
      0089F3 22               [24] 1287 	ret
                                   1288 ;------------------------------------------------------------
                                   1289 ;Allocation info for local variables in function 'dynamic_keymap_set_tap_dance'
                                   1290 ;------------------------------------------------------------
                                   1291 ;buffer        Allocated with name '_dynamic_keymap_set_tap_dance_PARM_2'
                                   1292 ;index         Allocated with name '_dynamic_keymap_set_tap_dance_index_10000_395'
                                   1293 ;entry         Allocated with name '_dynamic_keymap_set_tap_dance_entry_10000_396'
                                   1294 ;------------------------------------------------------------
                                   1295 ;	quantum/dynamic_keymap.c:275: int dynamic_keymap_set_tap_dance(uint8_t index, const vial_tap_dance_entry_t *buffer) {
                                   1296 ;	-----------------------------------------
                                   1297 ;	 function dynamic_keymap_set_tap_dance
                                   1298 ;	-----------------------------------------
      0089F4                       1299 _dynamic_keymap_set_tap_dance:
      0089F4 E5 82            [12] 1300 	mov	a,dpl
      0089F6 90 0B B4         [24] 1301 	mov	dptr,#_dynamic_keymap_set_tap_dance_index_10000_395
      0089F9 F0               [24] 1302 	movx	@dptr,a
                                   1303 ;	quantum/dynamic_keymap.c:276: const vial_tap_dance_entry_t AK820_STATE_MEM *entry = (const vial_tap_dance_entry_t AK820_STATE_MEM *)buffer;
      0089FA 90 0B B1         [24] 1304 	mov	dptr,#_dynamic_keymap_set_tap_dance_PARM_2
      0089FD 12 37 F7         [24] 1305 	lcall	_ak820_outline_0056
                                   1306 ;	quantum/dynamic_keymap.c:277: if (index >= AK820_EXTENSION_ENTRIES || !ak820_tap_dance_valid(entry) || !ak820_nvm_ok()) return -1;
      008A00 90 0B B4         [24] 1307 	mov	dptr,#_dynamic_keymap_set_tap_dance_index_10000_395
      008A03 E0               [24] 1308 	movx	a,@dptr
      008A04 FD               [12] 1309 	mov	r5,a
      008A05 BD 08 00         [24] 1310 	cjne	r5,#0x08,00139$
      008A08                       1311 00139$:
      008A08 50 1D            [24] 1312 	jnc	00101$
      008A0A 12 43 23         [24] 1313 	lcall	_ak820_outline_0119
      008A0D C0 07            [24] 1314 	push	ar7
      008A0F C0 06            [24] 1315 	push	ar6
      008A11 C0 05            [24] 1316 	push	ar5
      008A13 12 43 58         [24] 1317 	lcall	_ak820_tap_dance_valid
      008A16 E5 82            [12] 1318 	mov	a, dpl
      008A18 D0 05            [24] 1319 	pop	ar5
      008A1A D0 06            [24] 1320 	pop	ar6
      008A1C D0 07            [24] 1321 	pop	ar7
      008A1E 60 07            [24] 1322 	jz	00101$
      008A20 12 3D DB         [24] 1323 	lcall	_ak820_nvm_ok
      008A23 E5 82            [12] 1324 	mov	a, dpl
      008A25 70 04            [24] 1325 	jnz	00102$
      008A27                       1326 00101$:
      008A27 90 FF FF         [24] 1327 	mov	dptr,#0xffff
      008A2A 22               [24] 1328 	ret
      008A2B                       1329 00102$:
                                   1330 ;	quantum/dynamic_keymap.c:278: clear_keyboard();
      008A2B C0 07            [24] 1331 	push	ar7
      008A2D C0 06            [24] 1332 	push	ar6
      008A2F C0 05            [24] 1333 	push	ar5
      008A31 12 7A F4         [24] 1334 	lcall	_clear_keyboard
      008A34 D0 05            [24] 1335 	pop	ar5
      008A36 D0 06            [24] 1336 	pop	ar6
      008A38 D0 07            [24] 1337 	pop	ar7
                                   1338 ;	quantum/dynamic_keymap.c:279: ak820_eeprom_update_block_xdata(entry, (void *)(VIAL_TAP_DANCE_EEPROM_ADDR + AK820_EXTENSION_OFFSET(index)), sizeof(*entry));
      008A3A BD 06 00         [24] 1339 	cjne	r5,#0x06,00143$
      008A3D                       1340 00143$:
      008A3D 50 0C            [24] 1341 	jnc	00107$
      008A3F 8D 04            [24] 1342 	mov	ar4,r5
      008A41 EC               [12] 1343 	mov	a,r4
      008A42 75 F0 0A         [24] 1344 	mov	b,#0x0a
      008A45 A4               [48] 1345 	mul	ab
      008A46 FB               [12] 1346 	mov	r3,a
      008A47 7C 00            [12] 1347 	mov	r4,#0x00
      008A49 80 11            [24] 1348 	sjmp	00108$
      008A4B                       1349 00107$:
      008A4B ED               [12] 1350 	mov	a,r5
      008A4C 24 FA            [12] 1351 	add	a,#0xfa
      008A4E 75 F0 0A         [24] 1352 	mov	b,#0x0a
      008A51 A4               [48] 1353 	mul	ab
      008A52 FD               [12] 1354 	mov	r5,a
      008A53 7A 00            [12] 1355 	mov	r2,#0x00
      008A55 74 40            [12] 1356 	mov	a,#0x40
      008A57 2D               [12] 1357 	add	a, r5
      008A58 FB               [12] 1358 	mov	r3,a
      008A59 E4               [12] 1359 	clr	a
      008A5A 3A               [12] 1360 	addc	a, r2
      008A5B FC               [12] 1361 	mov	r4,a
      008A5C                       1362 00108$:
      008A5C 74 C0            [12] 1363 	mov	a,#0xc0
      008A5E 2B               [12] 1364 	add	a, r3
      008A5F FB               [12] 1365 	mov	r3,a
      008A60 74 06            [12] 1366 	mov	a,#0x06
      008A62 3C               [12] 1367 	addc	a, r4
      008A63 FC               [12] 1368 	mov	r4,a
      008A64 90 05 91         [24] 1369 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      008A67 EB               [12] 1370 	mov	a,r3
      008A68 F0               [24] 1371 	movx	@dptr,a
      008A69 EC               [12] 1372 	mov	a,r4
      008A6A 12 38 1C         [24] 1373 	lcall	_ak820_outline_0075
      008A6D 90 05 94         [24] 1374 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      008A70 74 0A            [12] 1375 	mov	a,#0x0a
      008A72 F0               [24] 1376 	movx	@dptr,a
      008A73 E4               [12] 1377 	clr	a
      008A74 A3               [24] 1378 	inc	dptr
      008A75 12 42 F8         [24] 1379 	lcall	_ak820_outline_0066
      008A78 12 41 DF         [24] 1380 	lcall	_ak820_eeprom_update_block_xdata
                                   1381 ;	quantum/dynamic_keymap.c:280: ak820_nvm_flush();
      008A7B 12 3D EA         [24] 1382 	lcall	_ak820_nvm_flush
                                   1383 ;	quantum/dynamic_keymap.c:281: return ak820_nvm_ok() ? 0 : -1;
      008A7E 12 3D DB         [24] 1384 	lcall	_ak820_nvm_ok
      008A81 E5 82            [12] 1385 	mov	a, dpl
      008A83 60 06            [24] 1386 	jz	00109$
      008A85 7E 00            [12] 1387 	mov	r6,#0x00
      008A87 7F 00            [12] 1388 	mov	r7,#0x00
      008A89 80 04            [24] 1389 	sjmp	00110$
      008A8B                       1390 00109$:
      008A8B 7E FF            [12] 1391 	mov	r6,#0xff
      008A8D 7F FF            [12] 1392 	mov	r7,#0xff
      008A8F                       1393 00110$:
      008A8F 12 43 23         [24] 1394 	lcall	_ak820_outline_0119
                                   1395 ;	quantum/dynamic_keymap.c:282: }
      008A92 22               [24] 1396 	ret
                                   1397 ;------------------------------------------------------------
                                   1398 ;Allocation info for local variables in function 'dynamic_keymap_get_combo'
                                   1399 ;------------------------------------------------------------
                                   1400 ;sloc0         Allocated with name '_dynamic_keymap_get_combo_sloc0_1_0'
                                   1401 ;buffer        Allocated with name '_dynamic_keymap_get_combo_PARM_2'
                                   1402 ;index         Allocated with name '_dynamic_keymap_get_combo_index_10000_398'
                                   1403 ;entry         Allocated with name '_dynamic_keymap_get_combo_entry_10000_399'
                                   1404 ;address       Allocated with name '_dynamic_keymap_get_combo_address_10001_401'
                                   1405 ;marked        Allocated with name '_dynamic_keymap_get_combo_marked_10002_402'
                                   1406 ;------------------------------------------------------------
                                   1407 ;	quantum/dynamic_keymap.c:307: int dynamic_keymap_get_combo(uint8_t index, vial_combo_entry_t *buffer) {
                                   1408 ;	-----------------------------------------
                                   1409 ;	 function dynamic_keymap_get_combo
                                   1410 ;	-----------------------------------------
      008A93                       1411 _dynamic_keymap_get_combo:
      008A93 E5 82            [12] 1412 	mov	a,dpl
      008A95 90 0B B8         [24] 1413 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_398
      008A98 F0               [24] 1414 	movx	@dptr,a
                                   1415 ;	quantum/dynamic_keymap.c:310: vial_combo_entry_t AK820_STATE_MEM *entry = (vial_combo_entry_t AK820_STATE_MEM *)buffer;
      008A99 90 0B B5         [24] 1416 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      008A9C 12 37 F7         [24] 1417 	lcall	_ak820_outline_0056
                                   1418 ;	quantum/dynamic_keymap.c:314: if (index >= VIAL_COMBO_ENTRIES)
      008A9F 90 0B B8         [24] 1419 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_398
      008AA2 E0               [24] 1420 	movx	a,@dptr
      008AA3 FD               [12] 1421 	mov	r5,a
      008AA4 BD 08 00         [24] 1422 	cjne	r5,#0x08,00132$
      008AA7                       1423 00132$:
      008AA7 40 04            [24] 1424 	jc	00102$
                                   1425 ;	quantum/dynamic_keymap.c:315: return -1;
      008AA9 90 FF FF         [24] 1426 	mov	dptr,#0xffff
      008AAC 22               [24] 1427 	ret
      008AAD                       1428 00102$:
                                   1429 ;	quantum/dynamic_keymap.c:317: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      008AAD 12 93 89         [24] 1430 	lcall	_ak820_outline_0084
                                   1431 ;	quantum/dynamic_keymap.c:319: ak820_eeprom_read_block_xdata(entry, address, sizeof(vial_combo_entry_t));
      008AB0 8E 02            [24] 1432 	mov	ar2,r6
      008AB2 8F 03            [24] 1433 	mov	ar3,r7
      008AB4 90 05 81         [24] 1434 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      008AB7 EC               [12] 1435 	mov	a,r4
      008AB8 F0               [24] 1436 	movx	@dptr,a
      008AB9 ED               [12] 1437 	mov	a,r5
      008ABA 12 38 1C         [24] 1438 	lcall	_ak820_outline_0075
      008ABD 90 05 84         [24] 1439 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      008AC0 12 93 AA         [24] 1440 	lcall	_ak820_outline_0113
      008AC3 12 43 28         [24] 1441 	lcall	_ak820_outline_0135
      008AC6 C0 07            [24] 1442 	push	ar7
      008AC8 C0 06            [24] 1443 	push	ar6
      008ACA 12 40 70         [24] 1444 	lcall	_ak820_eeprom_read_block_xdata
      008ACD D0 06            [24] 1445 	pop	ar6
      008ACF D0 07            [24] 1446 	pop	ar7
                                   1447 ;	quantum/dynamic_keymap.c:324: bool marked = entry->input[2] == AK820_COMBO_MARKER && entry->input[3] == AK820_COMBO_VERSION;
      008AD1 74 04            [12] 1448 	mov	a,#0x04
      008AD3 12 48 76         [24] 1449 	lcall	_ak820_outline_0012
      008AD6 FA               [12] 1450 	mov	r2,a
      008AD7 A3               [24] 1451 	inc	dptr
      008AD8 E0               [24] 1452 	movx	a,@dptr
      008AD9 FB               [12] 1453 	mov	r3,a
      008ADA BA 20 14         [24] 1454 	cjne	r2,#0x20,00108$
      008ADD BB 08 11         [24] 1455 	cjne	r3,#0x08,00108$
      008AE0 74 06            [12] 1456 	mov	a,#0x06
      008AE2 12 37 D6         [24] 1457 	lcall	_ak820_outline_0017
      008AE5 FA               [12] 1458 	mov	r2,a
      008AE6 A3               [24] 1459 	inc	dptr
      008AE7 E0               [24] 1460 	movx	a,@dptr
      008AE8 FB               [12] 1461 	mov	r3,a
      008AE9 BA 01 05         [24] 1462 	cjne	r2,#0x01,00136$
      008AEC BB 00 02         [24] 1463 	cjne	r3,#0x00,00136$
      008AEF 80 05            [24] 1464 	sjmp	00109$
      008AF1                       1465 00136$:
      008AF1                       1466 00108$:
      008AF1 75 2B 00         [24] 1467 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x00
      008AF4 80 03            [24] 1468 	sjmp	00110$
      008AF6                       1469 00109$:
      008AF6 75 2B 01         [24] 1470 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x01
      008AF9                       1471 00110$:
                                   1472 ;	quantum/dynamic_keymap.c:325: entry->input[2] = entry->input[3] = 0;
      008AF9 74 06            [12] 1473 	mov	a,#0x06
      008AFB 12 37 EF         [24] 1474 	lcall	_ak820_outline_0035
      008AFE 12 48 D9         [24] 1475 	lcall	_ak820_outline_0143
      008B01 12 38 51         [24] 1476 	lcall	_ak820_outline_0123
      008B04 F0               [24] 1477 	movx	@dptr,a
      008B05 A3               [24] 1478 	inc	dptr
      008B06 F0               [24] 1479 	movx	@dptr,a
                                   1480 ;	quantum/dynamic_keymap.c:326: if (!marked || !ak820_combo_valid(entry)) memset(entry, 0, sizeof(*entry));
      008B07 E5 2B            [12] 1481 	mov	a,_dynamic_keymap_get_combo_sloc0_1_0
      008B09 60 12            [24] 1482 	jz	00103$
      008B0B 12 43 23         [24] 1483 	lcall	_ak820_outline_0119
      008B0E C0 07            [24] 1484 	push	ar7
      008B10 C0 06            [24] 1485 	push	ar6
      008B12 12 34 68         [24] 1486 	lcall	_ak820_combo_valid
      008B15 E5 82            [12] 1487 	mov	a, dpl
      008B17 D0 06            [24] 1488 	pop	ar6
      008B19 D0 07            [24] 1489 	pop	ar7
      008B1B 70 08            [24] 1490 	jnz	00104$
      008B1D                       1491 00103$:
      008B1D 7D 00            [12] 1492 	mov	r5,#0x00
      008B1F 12 93 74         [24] 1493 	lcall	_ak820_outline_0041
      008B22 12 BD 04         [24] 1494 	lcall	_memset
      008B25                       1495 00104$:
                                   1496 ;	quantum/dynamic_keymap.c:329: return 0;
      008B25 90 00 00         [24] 1497 	mov	dptr,#0x0000
                                   1498 ;	quantum/dynamic_keymap.c:330: }
      008B28 22               [24] 1499 	ret
                                   1500 ;------------------------------------------------------------
                                   1501 ;Allocation info for local variables in function 'dynamic_keymap_set_combo'
                                   1502 ;------------------------------------------------------------
                                   1503 ;buffer        Allocated with name '_dynamic_keymap_set_combo_PARM_2'
                                   1504 ;index         Allocated with name '_dynamic_keymap_set_combo_index_10000_404'
                                   1505 ;entry         Allocated with name '_dynamic_keymap_set_combo_entry_10000_405'
                                   1506 ;address       Allocated with name '_dynamic_keymap_set_combo_address_10001_408'
                                   1507 ;stored        Allocated with name '_dynamic_keymap_set_combo_stored_10002_409'
                                   1508 ;------------------------------------------------------------
                                   1509 ;	quantum/dynamic_keymap.c:332: int dynamic_keymap_set_combo(uint8_t index, const vial_combo_entry_t *buffer) {
                                   1510 ;	-----------------------------------------
                                   1511 ;	 function dynamic_keymap_set_combo
                                   1512 ;	-----------------------------------------
      008B29                       1513 _dynamic_keymap_set_combo:
      008B29 E5 82            [12] 1514 	mov	a,dpl
      008B2B 90 0B BC         [24] 1515 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_404
      008B2E F0               [24] 1516 	movx	@dptr,a
                                   1517 ;	quantum/dynamic_keymap.c:334: const vial_combo_entry_t AK820_STATE_MEM *entry = (const vial_combo_entry_t AK820_STATE_MEM *)buffer;
      008B2F 90 0B B9         [24] 1518 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      008B32 12 37 A8         [24] 1519 	lcall	_ak820_outline_0005
                                   1520 ;	quantum/dynamic_keymap.c:339: if (!ak820_combo_valid(entry) || !ak820_nvm_ok()) return -1;
      008B35 C0 07            [24] 1521 	push	ar7
      008B37 C0 06            [24] 1522 	push	ar6
      008B39 12 34 68         [24] 1523 	lcall	_ak820_combo_valid
      008B3C E5 82            [12] 1524 	mov	a, dpl
      008B3E D0 06            [24] 1525 	pop	ar6
      008B40 D0 07            [24] 1526 	pop	ar7
      008B42 60 07            [24] 1527 	jz	00101$
      008B44 12 3D DB         [24] 1528 	lcall	_ak820_nvm_ok
      008B47 E5 82            [12] 1529 	mov	a, dpl
      008B49 70 04            [24] 1530 	jnz	00102$
      008B4B                       1531 00101$:
      008B4B 90 FF FF         [24] 1532 	mov	dptr,#0xffff
      008B4E 22               [24] 1533 	ret
      008B4F                       1534 00102$:
                                   1535 ;	quantum/dynamic_keymap.c:341: if (index >= VIAL_COMBO_ENTRIES)
      008B4F 90 0B BC         [24] 1536 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_404
      008B52 E0               [24] 1537 	movx	a,@dptr
      008B53 FD               [12] 1538 	mov	r5,a
      008B54 BD 08 00         [24] 1539 	cjne	r5,#0x08,00133$
      008B57                       1540 00133$:
      008B57 40 04            [24] 1541 	jc	00105$
                                   1542 ;	quantum/dynamic_keymap.c:342: return -1;
      008B59 90 FF FF         [24] 1543 	mov	dptr,#0xffff
      008B5C 22               [24] 1544 	ret
      008B5D                       1545 00105$:
                                   1546 ;	quantum/dynamic_keymap.c:344: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      008B5D 12 93 89         [24] 1547 	lcall	_ak820_outline_0084
                                   1548 ;	quantum/dynamic_keymap.c:346: clear_keyboard();
      008B60 C0 07            [24] 1549 	push	ar7
      008B62 C0 06            [24] 1550 	push	ar6
      008B64 C0 05            [24] 1551 	push	ar5
      008B66 C0 04            [24] 1552 	push	ar4
      008B68 12 7A F4         [24] 1553 	lcall	_clear_keyboard
      008B6B D0 04            [24] 1554 	pop	ar4
      008B6D D0 05            [24] 1555 	pop	ar5
      008B6F D0 06            [24] 1556 	pop	ar6
      008B71 D0 07            [24] 1557 	pop	ar7
                                   1558 ;	quantum/dynamic_keymap.c:347: vial_combo_entry_t stored = *entry;
      008B73 90 0E 60         [24] 1559 	mov	dptr,#___memcpy_PARM_2
      008B76 12 48 CB         [24] 1560 	lcall	_ak820_outline_0064
      008B79 E4               [12] 1561 	clr	a
      008B7A A3               [24] 1562 	inc	dptr
      008B7B F0               [24] 1563 	movx	@dptr,a
      008B7C 90 0E 63         [24] 1564 	mov	dptr,#___memcpy_PARM_3
      008B7F 12 93 AA         [24] 1565 	lcall	_ak820_outline_0113
      008B82 90 0B BD         [24] 1566 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_409
      008B85 F5 F0            [12] 1567 	mov	b,a
      008B87 C0 05            [24] 1568 	push	ar5
      008B89 C0 04            [24] 1569 	push	ar4
      008B8B 12 BC 8E         [24] 1570 	lcall	___memcpy
      008B8E D0 04            [24] 1571 	pop	ar4
      008B90 D0 05            [24] 1572 	pop	ar5
                                   1573 ;	quantum/dynamic_keymap.c:348: stored.input[2] = AK820_COMBO_MARKER;
      008B92 90 0B C1         [24] 1574 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_409 + 0x0004)
      008B95 74 20            [12] 1575 	mov	a,#0x20
      008B97 F0               [24] 1576 	movx	@dptr,a
      008B98 74 08            [12] 1577 	mov	a,#0x08
      008B9A A3               [24] 1578 	inc	dptr
      008B9B F0               [24] 1579 	movx	@dptr,a
                                   1580 ;	quantum/dynamic_keymap.c:349: stored.input[3] = AK820_COMBO_VERSION;
      008B9C 90 0B C3         [24] 1581 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_409 + 0x0006)
      008B9F 74 01            [12] 1582 	mov	a,#0x01
      008BA1 12 38 5C         [24] 1583 	lcall	_ak820_outline_0127
                                   1584 ;	quantum/dynamic_keymap.c:350: ak820_eeprom_write_block_xdata(&stored, address, sizeof(stored));
      008BA4 90 05 8A         [24] 1585 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      008BA7 EC               [12] 1586 	mov	a,r4
      008BA8 F0               [24] 1587 	movx	@dptr,a
      008BA9 ED               [12] 1588 	mov	a,r5
      008BAA 12 38 1C         [24] 1589 	lcall	_ak820_outline_0075
      008BAD 90 05 8D         [24] 1590 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      008BB0 12 93 AA         [24] 1591 	lcall	_ak820_outline_0113
      008BB3 90 0B BD         [24] 1592 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_409
      008BB6 12 40 FC         [24] 1593 	lcall	_ak820_eeprom_write_block_xdata
                                   1594 ;	quantum/dynamic_keymap.c:355: ak820_nvm_flush();
      008BB9 12 3D EA         [24] 1595 	lcall	_ak820_nvm_flush
                                   1596 ;	quantum/dynamic_keymap.c:356: if (!ak820_nvm_ok()) return -1;
      008BBC 12 3D DB         [24] 1597 	lcall	_ak820_nvm_ok
      008BBF E5 82            [12] 1598 	mov	a, dpl
      008BC1 70 04            [24] 1599 	jnz	00107$
      008BC3 90 FF FF         [24] 1600 	mov	dptr,#0xffff
      008BC6 22               [24] 1601 	ret
      008BC7                       1602 00107$:
                                   1603 ;	quantum/dynamic_keymap.c:360: return 0;
      008BC7 90 00 00         [24] 1604 	mov	dptr,#0x0000
                                   1605 ;	quantum/dynamic_keymap.c:361: }
      008BCA 22               [24] 1606 	ret
                                   1607 ;------------------------------------------------------------
                                   1608 ;Allocation info for local variables in function 'dynamic_keymap_reset'
                                   1609 ;------------------------------------------------------------
                                   1610 ;vial_unlocked_prev Allocated with name '_dynamic_keymap_reset_vial_unlocked_prev_10000_412'
                                   1611 ;layer         Allocated with name '_dynamic_keymap_reset_layer_20000_413'
                                   1612 ;row           Allocated with name '_dynamic_keymap_reset_row_40000_415'
                                   1613 ;column        Allocated with name '_dynamic_keymap_reset_column_60000_417'
                                   1614 ;encoder       Allocated with name '_dynamic_keymap_reset_encoder_40000_419'
                                   1615 ;td            Allocated with name '_dynamic_keymap_reset_td_10001_421'
                                   1616 ;i             Allocated with name '_dynamic_keymap_reset_i_20001_422'
                                   1617 ;combo         Allocated with name '_dynamic_keymap_reset_combo_10002_424'
                                   1618 ;i             Allocated with name '_dynamic_keymap_reset_i_20002_425'
                                   1619 ;------------------------------------------------------------
                                   1620 ;	quantum/dynamic_keymap.c:404: void dynamic_keymap_reset(void) {
                                   1621 ;	-----------------------------------------
                                   1622 ;	 function dynamic_keymap_reset
                                   1623 ;	-----------------------------------------
      008BCB                       1624 _dynamic_keymap_reset:
                                   1625 ;	quantum/dynamic_keymap.c:415: bool vial_unlocked_prev = vial_unlocked;
      008BCB 90 0E E0         [24] 1626 	mov	dptr,#_vial_unlocked
      008BCE E0               [24] 1627 	movx	a,@dptr
      008BCF 90 0B C7         [24] 1628 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_412
      008BD2 F0               [24] 1629 	movx	@dptr,a
                                   1630 ;	quantum/dynamic_keymap.c:416: vial_unlocked = 1;
      008BD3 90 0E E0         [24] 1631 	mov	dptr,#_vial_unlocked
      008BD6 74 01            [12] 1632 	mov	a,#0x01
      008BD8 F0               [24] 1633 	movx	@dptr,a
                                   1634 ;	quantum/dynamic_keymap.c:420: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      008BD9 7F 00            [12] 1635 	mov	r7,#0x00
      008BDB                       1636 00117$:
      008BDB BF 06 00         [24] 1637 	cjne	r7,#0x06,00217$
      008BDE                       1638 00217$:
      008BDE 40 02            [24] 1639 	jc	00218$
      008BE0 81 89            [12] 1640 	ajmp	00104$
      008BE2                       1641 00218$:
                                   1642 ;	quantum/dynamic_keymap.c:421: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      008BE2 7E 00            [12] 1643 	mov	r6,#0x00
      008BE4                       1644 00111$:
      008BE4 BE 10 00         [24] 1645 	cjne	r6,#0x10,00219$
      008BE7                       1646 00219$:
      008BE7 50 4C            [24] 1647 	jnc	00102$
                                   1648 ;	quantum/dynamic_keymap.c:422: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      008BE9 7D 00            [12] 1649 	mov	r5,#0x00
      008BEB                       1650 00108$:
      008BEB BD 08 00         [24] 1651 	cjne	r5,#0x08,00221$
      008BEE                       1652 00221$:
      008BEE 50 42            [24] 1653 	jnc	00112$
                                   1654 ;	quantum/dynamic_keymap.c:423: dynamic_keymap_set_keycode(layer, row, column, keycode_at_keymap_location_raw(layer, row, column));
      008BF0 90 0C 6D         [24] 1655 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_2
      008BF3 EE               [12] 1656 	mov	a,r6
      008BF4 F0               [24] 1657 	movx	@dptr,a
      008BF5 90 0C 6E         [24] 1658 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_3
      008BF8 ED               [12] 1659 	mov	a,r5
      008BF9 F0               [24] 1660 	movx	@dptr,a
      008BFA 8F 82            [24] 1661 	mov	dpl, r7
      008BFC C0 07            [24] 1662 	push	ar7
      008BFE C0 06            [24] 1663 	push	ar6
      008C00 C0 05            [24] 1664 	push	ar5
      008C02 12 9B C0         [24] 1665 	lcall	_keycode_at_keymap_location_raw
      008C05 AB 82            [24] 1666 	mov	r3, dpl
      008C07 AC 83            [24] 1667 	mov	r4, dph
      008C09 D0 05            [24] 1668 	pop	ar5
      008C0B D0 06            [24] 1669 	pop	ar6
      008C0D D0 07            [24] 1670 	pop	ar7
      008C0F 90 0B 9E         [24] 1671 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      008C12 EE               [12] 1672 	mov	a,r6
      008C13 F0               [24] 1673 	movx	@dptr,a
      008C14 90 0B 9F         [24] 1674 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      008C17 ED               [12] 1675 	mov	a,r5
      008C18 F0               [24] 1676 	movx	@dptr,a
      008C19 90 0B A0         [24] 1677 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      008C1C 12 38 2F         [24] 1678 	lcall	_ak820_outline_0081
      008C1F 8F 82            [24] 1679 	mov	dpl, r7
      008C21 C0 07            [24] 1680 	push	ar7
      008C23 C0 06            [24] 1681 	push	ar6
      008C25 C0 05            [24] 1682 	push	ar5
      008C27 11 2E            [12] 1683 	acall	_dynamic_keymap_set_keycode
      008C29 D0 05            [24] 1684 	pop	ar5
      008C2B D0 06            [24] 1685 	pop	ar6
      008C2D D0 07            [24] 1686 	pop	ar7
                                   1687 ;	quantum/dynamic_keymap.c:422: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      008C2F 0D               [12] 1688 	inc	r5
      008C30 80 B9            [24] 1689 	sjmp	00108$
      008C32                       1690 00112$:
                                   1691 ;	quantum/dynamic_keymap.c:421: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      008C32 0E               [12] 1692 	inc	r6
      008C33 80 AF            [24] 1693 	sjmp	00111$
      008C35                       1694 00102$:
                                   1695 ;	quantum/dynamic_keymap.c:427: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      008C35 7E 00            [12] 1696 	mov	r6,#0x00
      008C37                       1697 00114$:
      008C37 BE 01 00         [24] 1698 	cjne	r6,#0x01,00223$
      008C3A                       1699 00223$:
      008C3A 50 4A            [24] 1700 	jnc	00118$
                                   1701 ;	quantum/dynamic_keymap.c:428: dynamic_keymap_set_encoder(layer, encoder, true, keycode_at_encodermap_location_raw(layer, encoder, true));
      008C3C 12 93 DF         [24] 1702 	lcall	_ak820_outline_0180
      008C3F 04               [12] 1703 	inc	a
      008C40 F0               [24] 1704 	movx	@dptr,a
      008C41 8F 82            [24] 1705 	mov	dpl, r7
      008C43 C0 07            [24] 1706 	push	ar7
      008C45 12 9C 05         [24] 1707 	lcall	_keycode_at_encodermap_location_raw
      008C48 12 43 3D         [24] 1708 	lcall	_ak820_outline_0151
      008C4B D0 07            [24] 1709 	pop	ar7
      008C4D 12 93 D6         [24] 1710 	lcall	_ak820_outline_0179
      008C50 04               [12] 1711 	inc	a
      008C51 F0               [24] 1712 	movx	@dptr,a
      008C52 90 0B AA         [24] 1713 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008C55 12 38 22         [24] 1714 	lcall	_ak820_outline_0077
      008C58 8F 82            [24] 1715 	mov	dpl, r7
      008C5A C0 07            [24] 1716 	push	ar7
      008C5C 31 06            [24] 1717 	acall	_dynamic_keymap_set_encoder
      008C5E D0 07            [24] 1718 	pop	ar7
                                   1719 ;	quantum/dynamic_keymap.c:429: dynamic_keymap_set_encoder(layer, encoder, false, keycode_at_encodermap_location_raw(layer, encoder, false));
      008C60 12 93 DF         [24] 1720 	lcall	_ak820_outline_0180
      008C63 F0               [24] 1721 	movx	@dptr,a
      008C64 8F 82            [24] 1722 	mov	dpl, r7
      008C66 C0 07            [24] 1723 	push	ar7
      008C68 12 9C 05         [24] 1724 	lcall	_keycode_at_encodermap_location_raw
      008C6B 12 43 3D         [24] 1725 	lcall	_ak820_outline_0151
      008C6E D0 07            [24] 1726 	pop	ar7
      008C70 12 93 D6         [24] 1727 	lcall	_ak820_outline_0179
      008C73 F0               [24] 1728 	movx	@dptr,a
      008C74 90 0B AA         [24] 1729 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008C77 12 38 22         [24] 1730 	lcall	_ak820_outline_0077
      008C7A 8F 82            [24] 1731 	mov	dpl, r7
      008C7C C0 07            [24] 1732 	push	ar7
      008C7E 31 06            [24] 1733 	acall	_dynamic_keymap_set_encoder
      008C80 D0 07            [24] 1734 	pop	ar7
                                   1735 ;	quantum/dynamic_keymap.c:427: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      008C82 7E 01            [12] 1736 	mov	r6,#0x01
      008C84 80 B1            [24] 1737 	sjmp	00114$
      008C86                       1738 00118$:
                                   1739 ;	quantum/dynamic_keymap.c:420: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      008C86 0F               [12] 1740 	inc	r7
      008C87 61 DB            [12] 1741 	ajmp	00117$
      008C89                       1742 00104$:
                                   1743 ;	quantum/dynamic_keymap.c:442: vial_tap_dance_entry_t td = { KC_NO, KC_NO, KC_NO, KC_NO, TAPPING_TERM };
      008C89 90 0B C8         [24] 1744 	mov	dptr,#_dynamic_keymap_reset_td_10001_421
      008C8C 12 48 D9         [24] 1745 	lcall	_ak820_outline_0143
      008C8F 90 0B CA         [24] 1746 	mov	dptr,#(_dynamic_keymap_reset_td_10001_421 + 0x0002)
      008C92 F0               [24] 1747 	movx	@dptr,a
      008C93 A3               [24] 1748 	inc	dptr
      008C94 F0               [24] 1749 	movx	@dptr,a
      008C95 90 0B CC         [24] 1750 	mov	dptr,#(_dynamic_keymap_reset_td_10001_421 + 0x0004)
      008C98 F0               [24] 1751 	movx	@dptr,a
      008C99 A3               [24] 1752 	inc	dptr
      008C9A F0               [24] 1753 	movx	@dptr,a
      008C9B 90 0B CE         [24] 1754 	mov	dptr,#(_dynamic_keymap_reset_td_10001_421 + 0x0006)
      008C9E F0               [24] 1755 	movx	@dptr,a
      008C9F A3               [24] 1756 	inc	dptr
      008CA0 F0               [24] 1757 	movx	@dptr,a
      008CA1 90 0B D0         [24] 1758 	mov	dptr,#(_dynamic_keymap_reset_td_10001_421 + 0x0008)
      008CA4 74 C8            [12] 1759 	mov	a,#0xc8
      008CA6 12 38 5C         [24] 1760 	lcall	_ak820_outline_0127
                                   1761 ;	quantum/dynamic_keymap.c:443: for (reset_index_t i = 0; i < VIAL_TAP_DANCE_ENTRIES; ++i) {
      008CA9 FF               [12] 1762 	mov	r7,a
      008CAA                       1763 00120$:
      008CAA BF 08 00         [24] 1764 	cjne	r7,#0x08,00225$
      008CAD                       1765 00225$:
      008CAD 50 16            [24] 1766 	jnc	00105$
                                   1767 ;	quantum/dynamic_keymap.c:444: dynamic_keymap_set_tap_dance(i, &td);
      008CAF 90 0B B1         [24] 1768 	mov	dptr,#_dynamic_keymap_set_tap_dance_PARM_2
      008CB2 74 C8            [12] 1769 	mov	a,#_dynamic_keymap_reset_td_10001_421
      008CB4 F0               [24] 1770 	movx	@dptr,a
      008CB5 74 0B            [12] 1771 	mov	a,#(_dynamic_keymap_reset_td_10001_421 >> 8)
      008CB7 12 38 1C         [24] 1772 	lcall	_ak820_outline_0075
      008CBA 8F 82            [24] 1773 	mov	dpl, r7
      008CBC C0 07            [24] 1774 	push	ar7
      008CBE 31 F4            [24] 1775 	acall	_dynamic_keymap_set_tap_dance
      008CC0 D0 07            [24] 1776 	pop	ar7
                                   1777 ;	quantum/dynamic_keymap.c:443: for (reset_index_t i = 0; i < VIAL_TAP_DANCE_ENTRIES; ++i) {
      008CC2 0F               [12] 1778 	inc	r7
      008CC3 80 E5            [24] 1779 	sjmp	00120$
      008CC5                       1780 00105$:
                                   1781 ;	quantum/dynamic_keymap.c:449: vial_combo_entry_t combo = { { 0 }, 0 };
      008CC5 90 0B D2         [24] 1782 	mov	dptr,#_dynamic_keymap_reset_combo_10002_424
      008CC8 12 48 D9         [24] 1783 	lcall	_ak820_outline_0143
      008CCB 90 0B D4         [24] 1784 	mov	dptr,#(_dynamic_keymap_reset_combo_10002_424 + 0x0002)
      008CCE F0               [24] 1785 	movx	@dptr,a
      008CCF A3               [24] 1786 	inc	dptr
      008CD0 F0               [24] 1787 	movx	@dptr,a
      008CD1 90 0B D6         [24] 1788 	mov	dptr,#(_dynamic_keymap_reset_combo_10002_424 + 0x0004)
      008CD4 F0               [24] 1789 	movx	@dptr,a
      008CD5 A3               [24] 1790 	inc	dptr
      008CD6 F0               [24] 1791 	movx	@dptr,a
      008CD7 90 0B D8         [24] 1792 	mov	dptr,#(_dynamic_keymap_reset_combo_10002_424 + 0x0006)
      008CDA F0               [24] 1793 	movx	@dptr,a
      008CDB A3               [24] 1794 	inc	dptr
      008CDC F0               [24] 1795 	movx	@dptr,a
      008CDD 90 0B DA         [24] 1796 	mov	dptr,#(_dynamic_keymap_reset_combo_10002_424 + 0x0008)
      008CE0 F0               [24] 1797 	movx	@dptr,a
      008CE1 A3               [24] 1798 	inc	dptr
      008CE2 F0               [24] 1799 	movx	@dptr,a
                                   1800 ;	quantum/dynamic_keymap.c:450: for (reset_index_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      008CE3 FF               [12] 1801 	mov	r7,a
      008CE4                       1802 00123$:
      008CE4 BF 08 00         [24] 1803 	cjne	r7,#0x08,00227$
      008CE7                       1804 00227$:
      008CE7 50 16            [24] 1805 	jnc	00106$
                                   1806 ;	quantum/dynamic_keymap.c:451: dynamic_keymap_set_combo(i, &combo);
      008CE9 90 0B B9         [24] 1807 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      008CEC 74 D2            [12] 1808 	mov	a,#_dynamic_keymap_reset_combo_10002_424
      008CEE F0               [24] 1809 	movx	@dptr,a
      008CEF 74 0B            [12] 1810 	mov	a,#(_dynamic_keymap_reset_combo_10002_424 >> 8)
      008CF1 12 38 1C         [24] 1811 	lcall	_ak820_outline_0075
      008CF4 8F 82            [24] 1812 	mov	dpl, r7
      008CF6 C0 07            [24] 1813 	push	ar7
      008CF8 71 29            [12] 1814 	acall	_dynamic_keymap_set_combo
      008CFA D0 07            [24] 1815 	pop	ar7
                                   1816 ;	quantum/dynamic_keymap.c:450: for (reset_index_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      008CFC 0F               [12] 1817 	inc	r7
      008CFD 80 E5            [24] 1818 	sjmp	00123$
      008CFF                       1819 00106$:
                                   1820 ;	quantum/dynamic_keymap.c:466: vial_unlocked = vial_unlocked_prev;
      008CFF 90 0B C7         [24] 1821 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_412
      008D02 E0               [24] 1822 	movx	a,@dptr
      008D03 90 0E E0         [24] 1823 	mov	dptr,#_vial_unlocked
      008D06 F0               [24] 1824 	movx	@dptr,a
                                   1825 ;	quantum/dynamic_keymap.c:468: }
      008D07 22               [24] 1826 	ret
                                   1827 ;------------------------------------------------------------
                                   1828 ;Allocation info for local variables in function 'ak820_dynamic_read_buffer'
                                   1829 ;------------------------------------------------------------
                                   1830 ;sloc0         Allocated with name '_ak820_dynamic_read_buffer_sloc0_1_0'
                                   1831 ;limit         Allocated with name '_ak820_dynamic_read_buffer_PARM_2'
                                   1832 ;offset        Allocated with name '_ak820_dynamic_read_buffer_PARM_3'
                                   1833 ;size          Allocated with name '_ak820_dynamic_read_buffer_PARM_4'
                                   1834 ;data          Allocated with name '_ak820_dynamic_read_buffer_PARM_5'
                                   1835 ;base          Allocated with name '_ak820_dynamic_read_buffer_base_10000_426'
                                   1836 ;target        Allocated with name '_ak820_dynamic_read_buffer_target_10000_427'
                                   1837 ;available     Allocated with name '_ak820_dynamic_read_buffer_available_10000_427'
                                   1838 ;remaining     Allocated with name '_ak820_dynamic_read_buffer_remaining_30000_430'
                                   1839 ;i             Allocated with name '_ak820_dynamic_read_buffer_i_20000_432'
                                   1840 ;------------------------------------------------------------
                                   1841 ;	quantum/dynamic_keymap.c:473: static void ak820_dynamic_read_buffer(uint16_t base, uint16_t limit, uint16_t offset, uint16_t size, uint8_t *data) {
                                   1842 ;	-----------------------------------------
                                   1843 ;	 function ak820_dynamic_read_buffer
                                   1844 ;	-----------------------------------------
      008D08                       1845 _ak820_dynamic_read_buffer:
      008D08 12 38 4C         [24] 1846 	lcall	_ak820_outline_0106
      008D0B 90 0B E5         [24] 1847 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_426
      008D0E 12 38 47         [24] 1848 	lcall	_ak820_outline_0105
                                   1849 ;	quantum/dynamic_keymap.c:474: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      008D11 90 0B E2         [24] 1850 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008D14 12 37 F7         [24] 1851 	lcall	_ak820_outline_0056
                                   1852 ;	quantum/dynamic_keymap.c:475: uint8_t available = 0;
      008D17 90 0B E7         [24] 1853 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_427
      008D1A E4               [12] 1854 	clr	a
      008D1B F0               [24] 1855 	movx	@dptr,a
                                   1856 ;	quantum/dynamic_keymap.c:476: if (size > 28) return;
      008D1C 90 0B E0         [24] 1857 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008D1F 12 38 16         [24] 1858 	lcall	_ak820_outline_0065
      008D22 8C 02            [24] 1859 	mov	ar2,r4
      008D24 8D 03            [24] 1860 	mov	ar3,r5
      008D26 C3               [12] 1861 	clr	c
      008D27 74 1C            [12] 1862 	mov	a,#0x1c
      008D29 9A               [12] 1863 	subb	a,r2
      008D2A E4               [12] 1864 	clr	a
      008D2B 9B               [12] 1865 	subb	a,r3
      008D2C 50 01            [24] 1866 	jnc	00102$
                                   1867 ;	free result
      008D2E 22               [24] 1868 	ret
      008D2F                       1869 00102$:
                                   1870 ;	quantum/dynamic_keymap.c:477: if (offset < limit) {
      008D2F 90 0B DE         [24] 1871 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008D32 12 43 05         [24] 1872 	lcall	_ak820_outline_0082
      008D35 90 0B DC         [24] 1873 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008D38 12 38 3B         [24] 1874 	lcall	_ak820_outline_0102
      008D3B C3               [12] 1875 	clr	c
      008D3C EA               [12] 1876 	mov	a,r2
      008D3D 98               [12] 1877 	subb	a,r0
      008D3E EB               [12] 1878 	mov	a,r3
      008D3F 99               [12] 1879 	subb	a,r1
      008D40 50 17            [24] 1880 	jnc	00104$
                                   1881 ;	quantum/dynamic_keymap.c:478: uint16_t remaining = limit - offset;
      008D42 E8               [12] 1882 	mov	a,r0
      008D43 C3               [12] 1883 	clr	c
      008D44 9A               [12] 1884 	subb	a,r2
      008D45 F8               [12] 1885 	mov	r0,a
      008D46 E9               [12] 1886 	mov	a,r1
      008D47 9B               [12] 1887 	subb	a,r3
      008D48 F9               [12] 1888 	mov	r1,a
                                   1889 ;	quantum/dynamic_keymap.c:479: available = remaining < size ? remaining : size;
      008D49 C3               [12] 1890 	clr	c
      008D4A E8               [12] 1891 	mov	a,r0
      008D4B 9C               [12] 1892 	subb	a,r4
      008D4C E9               [12] 1893 	mov	a,r1
      008D4D 9D               [12] 1894 	subb	a,r5
      008D4E 40 04            [24] 1895 	jc	00114$
      008D50 8C 00            [24] 1896 	mov	ar0,r4
      008D52 8D 01            [24] 1897 	mov	ar1,r5
      008D54                       1898 00114$:
      008D54 90 0B E7         [24] 1899 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_427
      008D57 E8               [12] 1900 	mov	a,r0
      008D58 F0               [24] 1901 	movx	@dptr,a
      008D59                       1902 00104$:
                                   1903 ;	quantum/dynamic_keymap.c:481: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      008D59 90 0B E7         [24] 1904 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_427
      008D5C E0               [24] 1905 	movx	a,@dptr
      008D5D F5 2C            [12] 1906 	mov	_ak820_dynamic_read_buffer_sloc0_1_0,a
      008D5F E0               [24] 1907 	movx	a,@dptr
      008D60 60 42            [24] 1908 	jz	00106$
      008D62 C0 04            [24] 1909 	push	ar4
      008D64 C0 05            [24] 1910 	push	ar5
      008D66 8E 00            [24] 1911 	mov	ar0,r6
      008D68 8F 05            [24] 1912 	mov	ar5,r7
      008D6A 90 0B E5         [24] 1913 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_426
      008D6D E0               [24] 1914 	movx	a,@dptr
      008D6E F9               [12] 1915 	mov	r1,a
      008D6F A3               [24] 1916 	inc	dptr
      008D70 E0               [24] 1917 	movx	a,@dptr
      008D71 FC               [12] 1918 	mov	r4,a
      008D72 EA               [12] 1919 	mov	a,r2
      008D73 29               [12] 1920 	add	a, r1
      008D74 FA               [12] 1921 	mov	r2,a
      008D75 EB               [12] 1922 	mov	a,r3
      008D76 3C               [12] 1923 	addc	a, r4
      008D77 FB               [12] 1924 	mov	r3,a
      008D78 90 05 81         [24] 1925 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      008D7B EA               [12] 1926 	mov	a,r2
      008D7C F0               [24] 1927 	movx	@dptr,a
      008D7D EB               [12] 1928 	mov	a,r3
      008D7E 12 38 1C         [24] 1929 	lcall	_ak820_outline_0075
      008D81 90 05 84         [24] 1930 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      008D84 E5 2C            [12] 1931 	mov	a,_ak820_dynamic_read_buffer_sloc0_1_0
      008D86 12 38 5C         [24] 1932 	lcall	_ak820_outline_0127
      008D89 88 82            [24] 1933 	mov	dpl, r0
      008D8B 8D 83            [24] 1934 	mov	dph, r5
      008D8D C0 07            [24] 1935 	push	ar7
      008D8F C0 06            [24] 1936 	push	ar6
      008D91 C0 05            [24] 1937 	push	ar5
      008D93 C0 04            [24] 1938 	push	ar4
      008D95 12 40 70         [24] 1939 	lcall	_ak820_eeprom_read_block_xdata
      008D98 D0 04            [24] 1940 	pop	ar4
      008D9A D0 05            [24] 1941 	pop	ar5
      008D9C D0 06            [24] 1942 	pop	ar6
      008D9E D0 07            [24] 1943 	pop	ar7
                                   1944 ;	quantum/dynamic_keymap.c:482: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      008DA0 D0 05            [24] 1945 	pop	ar5
      008DA2 D0 04            [24] 1946 	pop	ar4
                                   1947 ;	quantum/dynamic_keymap.c:481: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      008DA4                       1948 00106$:
                                   1949 ;	quantum/dynamic_keymap.c:482: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      008DA4 90 0B E7         [24] 1950 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_427
      008DA7 E0               [24] 1951 	movx	a,@dptr
      008DA8 FB               [12] 1952 	mov	r3,a
      008DA9                       1953 00109$:
      008DA9 8B 01            [24] 1954 	mov	ar1,r3
      008DAB 7A 00            [12] 1955 	mov	r2,#0x00
      008DAD C3               [12] 1956 	clr	c
      008DAE E9               [12] 1957 	mov	a,r1
      008DAF 9C               [12] 1958 	subb	a,r4
      008DB0 EA               [12] 1959 	mov	a,r2
      008DB1 9D               [12] 1960 	subb	a,r5
      008DB2 50 09            [24] 1961 	jnc	00111$
      008DB4 EB               [12] 1962 	mov	a,r3
      008DB5 12 37 EF         [24] 1963 	lcall	_ak820_outline_0035
      008DB8 E4               [12] 1964 	clr	a
      008DB9 F0               [24] 1965 	movx	@dptr,a
      008DBA 0B               [12] 1966 	inc	r3
      008DBB 80 EC            [24] 1967 	sjmp	00109$
      008DBD                       1968 00111$:
                                   1969 ;	quantum/dynamic_keymap.c:483: }
      008DBD 22               [24] 1970 	ret
                                   1971 ;------------------------------------------------------------
                                   1972 ;Allocation info for local variables in function 'dynamic_keymap_get_buffer'
                                   1973 ;------------------------------------------------------------
                                   1974 ;size          Allocated with name '_dynamic_keymap_get_buffer_PARM_2'
                                   1975 ;data          Allocated with name '_dynamic_keymap_get_buffer_PARM_3'
                                   1976 ;offset        Allocated with name '_dynamic_keymap_get_buffer_offset_10000_433'
                                   1977 ;------------------------------------------------------------
                                   1978 ;	quantum/dynamic_keymap.c:486: void dynamic_keymap_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   1979 ;	-----------------------------------------
                                   1980 ;	 function dynamic_keymap_get_buffer
                                   1981 ;	-----------------------------------------
      008DBE                       1982 _dynamic_keymap_get_buffer:
      008DBE 12 38 4C         [24] 1983 	lcall	_ak820_outline_0106
      008DC1 90 0B ED         [24] 1984 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_433
      008DC4 12 38 47         [24] 1985 	lcall	_ak820_outline_0105
                                   1986 ;	quantum/dynamic_keymap.c:489: DYNAMIC_KEYMAP_LAYER_COUNT * MATRIX_ROWS * MATRIX_COLS * 2, offset, size, data);
      008DC7 90 0B ED         [24] 1987 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_433
      008DCA 12 37 F7         [24] 1988 	lcall	_ak820_outline_0056
      008DCD 90 0B E8         [24] 1989 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_2
      008DD0 12 38 16         [24] 1990 	lcall	_ak820_outline_0065
      008DD3 90 0B EA         [24] 1991 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_3
      008DD6 E0               [24] 1992 	movx	a,@dptr
      008DD7 F9               [12] 1993 	mov	r1,a
      008DD8 A3               [24] 1994 	inc	dptr
      008DD9 12 43 05         [24] 1995 	lcall	_ak820_outline_0082
      008DDC 90 0B DC         [24] 1996 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008DDF E4               [12] 1997 	clr	a
      008DE0 F0               [24] 1998 	movx	@dptr,a
      008DE1 74 06            [12] 1999 	mov	a,#0x06
      008DE3 A3               [24] 2000 	inc	dptr
      008DE4 F0               [24] 2001 	movx	@dptr,a
      008DE5 90 0B DE         [24] 2002 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008DE8 12 48 CB         [24] 2003 	lcall	_ak820_outline_0064
      008DEB 90 0B E0         [24] 2004 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008DEE 12 38 22         [24] 2005 	lcall	_ak820_outline_0077
      008DF1 90 0B E2         [24] 2006 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008DF4 E9               [12] 2007 	mov	a,r1
      008DF5 12 54 38         [24] 2008 	lcall	_ak820_outline_0157
      008DF8 F0               [24] 2009 	movx	@dptr,a
      008DF9 90 00 40         [24] 2010 	mov	dptr,#0x0040
                                   2011 ;	quantum/dynamic_keymap.c:511: }
      008DFC A1 08            [12] 2012 	ajmp	_ak820_dynamic_read_buffer
                                   2013 ;------------------------------------------------------------
                                   2014 ;Allocation info for local variables in function 'dynamic_keymap_set_buffer'
                                   2015 ;------------------------------------------------------------
                                   2016 ;sloc0         Allocated with name '_dynamic_keymap_set_buffer_sloc0_1_0'
                                   2017 ;sloc1         Allocated with name '_dynamic_keymap_set_buffer_sloc1_1_0'
                                   2018 ;sloc2         Allocated with name '_dynamic_keymap_set_buffer_sloc2_1_0'
                                   2019 ;size          Allocated with name '_dynamic_keymap_set_buffer_PARM_2'
                                   2020 ;data          Allocated with name '_dynamic_keymap_set_buffer_PARM_3'
                                   2021 ;offset        Allocated with name '_dynamic_keymap_set_buffer_offset_10000_435'
                                   2022 ;dynamic_keymap_eeprom_size Allocated with name '_dynamic_keymap_set_buffer_dynamic_keymap_eeprom_size_10000_436'
                                   2023 ;target        Allocated with name '_dynamic_keymap_set_buffer_target_10000_436'
                                   2024 ;buffer        Allocated with name '_dynamic_keymap_set_buffer_buffer_10000_436'
                                   2025 ;count         Allocated with name '_dynamic_keymap_set_buffer_count_10001_439'
                                   2026 ;chk_offset    Allocated with name '_dynamic_keymap_set_buffer_chk_offset_30001_442'
                                   2027 ;chk_sz        Allocated with name '_dynamic_keymap_set_buffer_chk_sz_30001_442'
                                   2028 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_444'
                                   2029 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_447'
                                   2030 ;i             Allocated with name '_dynamic_keymap_set_buffer_i_40001_449'
                                   2031 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_450'
                                   2032 ;------------------------------------------------------------
                                   2033 ;	quantum/dynamic_keymap.c:513: void dynamic_keymap_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2034 ;	-----------------------------------------
                                   2035 ;	 function dynamic_keymap_set_buffer
                                   2036 ;	-----------------------------------------
      008DFE                       2037 _dynamic_keymap_set_buffer:
      008DFE 12 38 4C         [24] 2038 	lcall	_ak820_outline_0106
      008E01 90 0B F4         [24] 2039 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_435
      008E04 12 38 47         [24] 2040 	lcall	_ak820_outline_0105
                                   2041 ;	quantum/dynamic_keymap.c:515: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset);
      008E07 90 0B F4         [24] 2042 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_435
      008E0A 12 37 C2         [24] 2043 	lcall	_ak820_outline_0010
      008E0D 74 40            [12] 2044 	mov	a,#0x40
      008E0F 2C               [12] 2045 	add	a, r4
      008E10 FA               [12] 2046 	mov	r2,a
      008E11 E4               [12] 2047 	clr	a
      008E12 3D               [12] 2048 	addc	a, r5
      008E13 FB               [12] 2049 	mov	r3,a
                                   2050 ;	quantum/dynamic_keymap.c:516: uint8_t DYNAMIC_BUFFER_MEM *buffer = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      008E14 90 0B F1         [24] 2051 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_3
      008E17 12 38 3B         [24] 2052 	lcall	_ak820_outline_0102
                                   2053 ;	quantum/dynamic_keymap.c:520: if (!size) return;
      008E1A 90 0B EF         [24] 2054 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_2
      008E1D E0               [24] 2055 	movx	a,@dptr
      008E1E F5 2D            [12] 2056 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,a
      008E20 A3               [24] 2057 	inc	dptr
      008E21 E0               [24] 2058 	movx	a,@dptr
      008E22 F5 2E            [12] 2059 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),a
      008E24 E5 2D            [12] 2060 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008E26 45 2E            [12] 2061 	orl	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008E28 70 01            [24] 2062 	jnz	00102$
      008E2A 22               [24] 2063 	ret
      008E2B                       2064 00102$:
                                   2065 ;	quantum/dynamic_keymap.c:522: if (size > 28) return;
      008E2B 85 2D 2F         [24] 2066 	mov	_dynamic_keymap_set_buffer_sloc1_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
      008E2E 85 2E 30         [24] 2067 	mov	(_dynamic_keymap_set_buffer_sloc1_1_0 + 1),(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008E31 C3               [12] 2068 	clr	c
      008E32 74 1C            [12] 2069 	mov	a,#0x1c
      008E34 95 2F            [12] 2070 	subb	a,_dynamic_keymap_set_buffer_sloc1_1_0
      008E36 E4               [12] 2071 	clr	a
      008E37 95 30            [12] 2072 	subb	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      008E39 50 01            [24] 2073 	jnc	00104$
                                   2074 ;	free result
      008E3B 22               [24] 2075 	ret
      008E3C                       2076 00104$:
                                   2077 ;	quantum/dynamic_keymap.c:524: dynamic_buffer_size_t count = size;
      008E3C 85 2D 31         [24] 2078 	mov	_dynamic_keymap_set_buffer_sloc2_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
                                   2079 ;	quantum/dynamic_keymap.c:528: if (offset >= dynamic_keymap_eeprom_size || dynamic_keymap_eeprom_size - offset < size)
      008E3F 74 FA            [12] 2080 	mov	a,#0x100 - 0x06
      008E41 2F               [12] 2081 	add	a,r7
      008E42 40 11            [24] 2082 	jc	00105$
      008E44 E4               [12] 2083 	clr	a
      008E45 C3               [12] 2084 	clr	c
      008E46 9E               [12] 2085 	subb	a,r6
      008E47 FE               [12] 2086 	mov	r6,a
      008E48 74 06            [12] 2087 	mov	a,#0x06
      008E4A 9F               [12] 2088 	subb	a,r7
      008E4B FF               [12] 2089 	mov	r7,a
      008E4C C3               [12] 2090 	clr	c
      008E4D EE               [12] 2091 	mov	a,r6
      008E4E 95 2D            [12] 2092 	subb	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008E50 EF               [12] 2093 	mov	a,r7
      008E51 95 2E            [12] 2094 	subb	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008E53 50 01            [24] 2095 	jnc	00106$
      008E55                       2096 00105$:
                                   2097 ;	quantum/dynamic_keymap.c:529: return;
      008E55 22               [24] 2098 	ret
      008E56                       2099 00106$:
                                   2100 ;	quantum/dynamic_keymap.c:533: if (!vial_unlocked) {
      008E56 90 0E E0         [24] 2101 	mov	dptr,#_vial_unlocked
      008E59 E0               [24] 2102 	movx	a,@dptr
      008E5A 60 02            [24] 2103 	jz	00207$
      008E5C E1 6A            [12] 2104 	ajmp	00120$
      008E5E                       2105 00207$:
                                   2106 ;	quantum/dynamic_keymap.c:535: dynamic_buffer_size_t chk_offset = 0;
      008E5E 90 0B F6         [24] 2107 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_442
      008E61 E4               [12] 2108 	clr	a
      008E62 F0               [24] 2109 	movx	@dptr,a
                                   2110 ;	quantum/dynamic_keymap.c:536: dynamic_buffer_size_t chk_sz = count;
      008E63 90 0B F7         [24] 2111 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_442
      008E66 E5 31            [12] 2112 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008E68 F0               [24] 2113 	movx	@dptr,a
                                   2114 ;	quantum/dynamic_keymap.c:539: if (offset % 2 != 0) {
      008E69 EC               [12] 2115 	mov	a,r4
      008E6A 30 E0 33         [24] 2116 	jnb	acc.0,00111$
                                   2117 ;	quantum/dynamic_keymap.c:540: uint16_t kc = (eeprom_read_byte(target - 1) << 8) | buffer[0];
      008E6D EA               [12] 2118 	mov	a,r2
      008E6E 24 FF            [12] 2119 	add	a,#0xff
      008E70 FE               [12] 2120 	mov	r6,a
      008E71 EB               [12] 2121 	mov	a,r3
      008E72 34 FF            [12] 2122 	addc	a,#0xff
      008E74 FF               [12] 2123 	mov	r7,a
      008E75 7D 00            [12] 2124 	mov	r5,#0x00
      008E77 12 43 23         [24] 2125 	lcall	_ak820_outline_0119
      008E7A 8D F0            [24] 2126 	mov	b, r5
      008E7C 12 40 35         [24] 2127 	lcall	_eeprom_read_byte
      008E7F AE 82            [24] 2128 	mov	r6,dpl
      008E81 7F 00            [12] 2129 	mov	r7,#0x00
      008E83 12 38 6B         [24] 2130 	lcall	_ak820_outline_0158
      008E86 E0               [24] 2131 	movx	a,@dptr
      008E87 7C 00            [12] 2132 	mov	r4,#0x00
      008E89 42 07            [12] 2133 	orl	ar7,a
      008E8B EC               [12] 2134 	mov	a,r4
      008E8C 42 06            [12] 2135 	orl	ar6,a
                                   2136 ;	quantum/dynamic_keymap.c:541: if (kc == QK_BOOT)
      008E8E BF 00 09         [24] 2137 	cjne	r7,#0x00,00109$
      008E91 BE 7C 06         [24] 2138 	cjne	r6,#0x7c,00109$
                                   2139 ;	quantum/dynamic_keymap.c:542: buffer[0] = 0xFF;
      008E94 12 38 6B         [24] 2140 	lcall	_ak820_outline_0158
      008E97 74 FF            [12] 2141 	mov	a,#0xff
      008E99 F0               [24] 2142 	movx	@dptr,a
      008E9A                       2143 00109$:
                                   2144 ;	quantum/dynamic_keymap.c:545: chk_offset += 1;
      008E9A 90 0B F6         [24] 2145 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_442
      008E9D 74 01            [12] 2146 	mov	a,#0x01
      008E9F F0               [24] 2147 	movx	@dptr,a
      008EA0                       2148 00111$:
                                   2149 ;	quantum/dynamic_keymap.c:549: if ((offset + size) % 2 != 0) {
      008EA0 90 0B F4         [24] 2150 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_435
      008EA3 12 37 F7         [24] 2151 	lcall	_ak820_outline_0056
      008EA6 E5 2D            [12] 2152 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008EA8 2E               [12] 2153 	add	a, r6
      008EA9 FE               [12] 2154 	mov	r6,a
      008EAA E5 2E            [12] 2155 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008EAC 3F               [12] 2156 	addc	a, r7
      008EAD EE               [12] 2157 	mov	a,r6
      008EAE 30 E0 5A         [24] 2158 	jnb	acc.0,00115$
                                   2159 ;	quantum/dynamic_keymap.c:550: uint16_t kc = (buffer[count - 1] << 8) | eeprom_read_byte(target + count);
      008EB1 AE 31            [24] 2160 	mov	r6,_dynamic_keymap_set_buffer_sloc2_1_0
      008EB3 7F 00            [12] 2161 	mov	r7,#0x00
      008EB5 EE               [12] 2162 	mov	a,r6
      008EB6 24 FF            [12] 2163 	add	a,#0xff
      008EB8 FC               [12] 2164 	mov	r4,a
      008EB9 EF               [12] 2165 	mov	a,r7
      008EBA 34 FF            [12] 2166 	addc	a,#0xff
      008EBC FD               [12] 2167 	mov	r5,a
      008EBD EC               [12] 2168 	mov	a,r4
      008EBE 28               [12] 2169 	add	a, r0
      008EBF F5 82            [12] 2170 	mov	dpl,a
      008EC1 ED               [12] 2171 	mov	a,r5
      008EC2 39               [12] 2172 	addc	a, r1
      008EC3 F5 83            [12] 2173 	mov	dph,a
      008EC5 E0               [24] 2174 	movx	a,@dptr
      008EC6 FC               [12] 2175 	mov	r4,a
      008EC7 7D 00            [12] 2176 	mov	r5,#0x00
      008EC9 E5 31            [12] 2177 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008ECB 2A               [12] 2178 	add	a, r2
      008ECC FA               [12] 2179 	mov	r2,a
      008ECD E4               [12] 2180 	clr	a
      008ECE 3B               [12] 2181 	addc	a, r3
      008ECF FB               [12] 2182 	mov	r3,a
      008ED0 C0 00            [24] 2183 	push	ar0
      008ED2 C0 01            [24] 2184 	push	ar1
      008ED4 8B 01            [24] 2185 	mov	ar1,r3
      008ED6 7B 00            [12] 2186 	mov	r3,#0x00
      008ED8 8A 82            [24] 2187 	mov	dpl, r2
      008EDA 89 83            [24] 2188 	mov	dph, r1
      008EDC 8B F0            [24] 2189 	mov	b, r3
      008EDE 12 40 35         [24] 2190 	lcall	_eeprom_read_byte
      008EE1 AB 82            [24] 2191 	mov	r3, dpl
      008EE3 7A 00            [12] 2192 	mov	r2,#0x00
      008EE5 EB               [12] 2193 	mov	a,r3
      008EE6 12 43 32         [24] 2194 	lcall	_ak820_outline_0142
                                   2195 ;	quantum/dynamic_keymap.c:551: if (kc == QK_BOOT)
      008EE9 BD 00 05         [24] 2196 	cjne	r5,#0x00,00212$
      008EEC BC 7C 02         [24] 2197 	cjne	r4,#0x7c,00212$
      008EEF 80 06            [24] 2198 	sjmp	00213$
      008EF1                       2199 00212$:
      008EF1 D0 01            [24] 2200 	pop	ar1
      008EF3 D0 00            [24] 2201 	pop	ar0
      008EF5 80 0D            [24] 2202 	sjmp	00113$
      008EF7                       2203 00213$:
      008EF7 D0 01            [24] 2204 	pop	ar1
      008EF9 D0 00            [24] 2205 	pop	ar0
                                   2206 ;	quantum/dynamic_keymap.c:552: buffer[count - 1] = 0xFF;
      008EFB 1E               [12] 2207 	dec	r6
      008EFC BE FF 01         [24] 2208 	cjne	r6,#0xff,00214$
      008EFF 1F               [12] 2209 	dec	r7
      008F00                       2210 00214$:
      008F00 EE               [12] 2211 	mov	a,r6
      008F01 12 93 B8         [24] 2212 	lcall	_ak820_outline_0131
      008F04                       2213 00113$:
                                   2214 ;	quantum/dynamic_keymap.c:555: chk_sz -= 1;
      008F04 E5 31            [12] 2215 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008F06 14               [12] 2216 	dec	a
      008F07 90 0B F7         [24] 2217 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_442
      008F0A F0               [24] 2218 	movx	@dptr,a
      008F0B                       2219 00115$:
                                   2220 ;	quantum/dynamic_keymap.c:559: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      008F0B 90 0B F6         [24] 2221 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_442
      008F0E E0               [24] 2222 	movx	a,@dptr
      008F0F 90 0B F8         [24] 2223 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_449
      008F12 F0               [24] 2224 	movx	@dptr,a
      008F13                       2225 00122$:
      008F13 90 0B F8         [24] 2226 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_449
      008F16 E0               [24] 2227 	movx	a,@dptr
      008F17 FF               [12] 2228 	mov	r7,a
      008F18 90 0B F7         [24] 2229 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_442
      008F1B E0               [24] 2230 	movx	a,@dptr
      008F1C FE               [12] 2231 	mov	r6,a
      008F1D C3               [12] 2232 	clr	c
      008F1E EF               [12] 2233 	mov	a,r7
      008F1F 9E               [12] 2234 	subb	a,r6
      008F20 50 48            [24] 2235 	jnc	00120$
                                   2236 ;	quantum/dynamic_keymap.c:560: uint16_t kc = (buffer[i] << 8) | buffer[i + 1];
      008F22 EF               [12] 2237 	mov	a,r7
      008F23 28               [12] 2238 	add	a, r0
      008F24 FD               [12] 2239 	mov	r5,a
      008F25 E4               [12] 2240 	clr	a
      008F26 39               [12] 2241 	addc	a, r1
      008F27 FE               [12] 2242 	mov	r6,a
      008F28 12 4D AE         [24] 2243 	lcall	_ak820_outline_0078
      008F2B 7B 00            [12] 2244 	mov	r3,#0x00
      008F2D 8C 2E            [24] 2245 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),r4
      008F2F 8B 2D            [24] 2246 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,r3
      008F31 8F 02            [24] 2247 	mov	ar2,r7
      008F33 7F 00            [12] 2248 	mov	r7,#0x00
      008F35 74 01            [12] 2249 	mov	a,#0x01
      008F37 2A               [12] 2250 	add	a, r2
      008F38 FB               [12] 2251 	mov	r3,a
      008F39 E4               [12] 2252 	clr	a
      008F3A 3F               [12] 2253 	addc	a, r7
      008F3B FC               [12] 2254 	mov	r4,a
      008F3C EB               [12] 2255 	mov	a,r3
      008F3D 28               [12] 2256 	add	a, r0
      008F3E F5 82            [12] 2257 	mov	dpl,a
      008F40 EC               [12] 2258 	mov	a,r4
      008F41 39               [12] 2259 	addc	a, r1
      008F42 F5 83            [12] 2260 	mov	dph,a
      008F44 E0               [24] 2261 	movx	a,@dptr
      008F45 FC               [12] 2262 	mov	r4,a
      008F46 7B 00            [12] 2263 	mov	r3,#0x00
      008F48 E5 2E            [12] 2264 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008F4A 42 03            [12] 2265 	orl	ar3,a
                                   2266 ;	quantum/dynamic_keymap.c:561: if (kc == QK_BOOT) {
      008F4C BC 00 12         [24] 2267 	cjne	r4,#0x00,00123$
      008F4F BB 7C 0F         [24] 2268 	cjne	r3,#0x7c,00123$
                                   2269 ;	quantum/dynamic_keymap.c:562: buffer[i] = 0xFF;
      008F52 12 38 61         [24] 2270 	lcall	_ak820_outline_0137
      008F55 74 FF            [12] 2271 	mov	a,#0xff
      008F57 F0               [24] 2272 	movx	@dptr,a
                                   2273 ;	quantum/dynamic_keymap.c:563: buffer[i + 1] = 0xFF;
      008F58 0A               [12] 2274 	inc	r2
      008F59 BA 00 01         [24] 2275 	cjne	r2,#0x00,00218$
      008F5C 0F               [12] 2276 	inc	r7
      008F5D                       2277 00218$:
      008F5D EA               [12] 2278 	mov	a,r2
      008F5E 12 93 B8         [24] 2279 	lcall	_ak820_outline_0131
      008F61                       2280 00123$:
                                   2281 ;	quantum/dynamic_keymap.c:559: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      008F61 90 0B F8         [24] 2282 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_449
      008F64 E0               [24] 2283 	movx	a,@dptr
      008F65 24 02            [12] 2284 	add	a,#0x02
      008F67 F0               [24] 2285 	movx	@dptr,a
      008F68 80 A9            [24] 2286 	sjmp	00122$
      008F6A                       2287 00120$:
                                   2288 ;	quantum/dynamic_keymap.c:574: ak820_eeprom_write_block_xdata(buffer, (void *)(uintptr_t)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset), size);
      008F6A 90 0B F4         [24] 2289 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_435
      008F6D 12 37 F7         [24] 2290 	lcall	_ak820_outline_0056
      008F70 74 40            [12] 2291 	mov	a,#0x40
      008F72 2E               [12] 2292 	add	a, r6
      008F73 FE               [12] 2293 	mov	r6,a
      008F74 E4               [12] 2294 	clr	a
      008F75 3F               [12] 2295 	addc	a, r7
      008F76 FF               [12] 2296 	mov	r7,a
      008F77 90 05 8A         [24] 2297 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      008F7A 12 48 CB         [24] 2298 	lcall	_ak820_outline_0064
      008F7D E4               [12] 2299 	clr	a
      008F7E A3               [24] 2300 	inc	dptr
      008F7F F0               [24] 2301 	movx	@dptr,a
      008F80 90 05 8D         [24] 2302 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      008F83 E5 2F            [12] 2303 	mov	a,_dynamic_keymap_set_buffer_sloc1_1_0
      008F85 F0               [24] 2304 	movx	@dptr,a
      008F86 E5 30            [12] 2305 	mov	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      008F88 A3               [24] 2306 	inc	dptr
      008F89 F0               [24] 2307 	movx	@dptr,a
      008F8A 12 38 6B         [24] 2308 	lcall	_ak820_outline_0158
                                   2309 ;	quantum/dynamic_keymap.c:584: }
      008F8D 02 40 FC         [24] 2310 	ljmp	_ak820_eeprom_write_block_xdata
                                   2311 ;------------------------------------------------------------
                                   2312 ;Allocation info for local variables in function 'keycode_at_keymap_location'
                                   2313 ;------------------------------------------------------------
                                   2314 ;row           Allocated with name '_keycode_at_keymap_location_PARM_2'
                                   2315 ;column        Allocated with name '_keycode_at_keymap_location_PARM_3'
                                   2316 ;layer_num     Allocated with name '_keycode_at_keymap_location_layer_num_10000_453'
                                   2317 ;------------------------------------------------------------
                                   2318 ;	quantum/dynamic_keymap.c:586: uint16_t keycode_at_keymap_location(uint8_t layer_num, uint8_t row, uint8_t column) {
                                   2319 ;	-----------------------------------------
                                   2320 ;	 function keycode_at_keymap_location
                                   2321 ;	-----------------------------------------
      008F90                       2322 _keycode_at_keymap_location:
      008F90 E5 82            [12] 2323 	mov	a,dpl
      008F92 90 0B FB         [24] 2324 	mov	dptr,#_keycode_at_keymap_location_layer_num_10000_453
      008F95 F0               [24] 2325 	movx	@dptr,a
                                   2326 ;	quantum/dynamic_keymap.c:587: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && row < MATRIX_ROWS && column < MATRIX_COLS) {
      008F96 E0               [24] 2327 	movx	a,@dptr
      008F97 FF               [12] 2328 	mov	r7,a
      008F98 BF 06 00         [24] 2329 	cjne	r7,#0x06,00128$
      008F9B                       2330 00128$:
      008F9B 50 23            [24] 2331 	jnc	00102$
      008F9D 90 0B F9         [24] 2332 	mov	dptr,#_keycode_at_keymap_location_PARM_2
      008FA0 E0               [24] 2333 	movx	a,@dptr
      008FA1 FE               [12] 2334 	mov	r6,a
      008FA2 BE 10 00         [24] 2335 	cjne	r6,#0x10,00130$
      008FA5                       2336 00130$:
      008FA5 50 19            [24] 2337 	jnc	00102$
      008FA7 90 0B FA         [24] 2338 	mov	dptr,#_keycode_at_keymap_location_PARM_3
      008FAA E0               [24] 2339 	movx	a,@dptr
      008FAB FD               [12] 2340 	mov	r5,a
      008FAC BD 08 00         [24] 2341 	cjne	r5,#0x08,00132$
      008FAF                       2342 00132$:
      008FAF 50 0F            [24] 2343 	jnc	00102$
                                   2344 ;	quantum/dynamic_keymap.c:588: return dynamic_keymap_get_keycode(layer_num, row, column);
      008FB1 90 0B 9B         [24] 2345 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      008FB4 EE               [12] 2346 	mov	a,r6
      008FB5 F0               [24] 2347 	movx	@dptr,a
      008FB6 90 0B 9C         [24] 2348 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      008FB9 ED               [12] 2349 	mov	a,r5
      008FBA F0               [24] 2350 	movx	@dptr,a
      008FBB 8F 82            [24] 2351 	mov	dpl, r7
      008FBD 02 87 E0         [24] 2352 	ljmp	_dynamic_keymap_get_keycode
      008FC0                       2353 00102$:
                                   2354 ;	quantum/dynamic_keymap.c:590: return KC_NO;
      008FC0 90 00 00         [24] 2355 	mov	dptr,#0x0000
                                   2356 ;	quantum/dynamic_keymap.c:591: }
      008FC3 22               [24] 2357 	ret
                                   2358 ;------------------------------------------------------------
                                   2359 ;Allocation info for local variables in function 'keycode_at_encodermap_location'
                                   2360 ;------------------------------------------------------------
                                   2361 ;encoder_idx   Allocated with name '_keycode_at_encodermap_location_PARM_2'
                                   2362 ;clockwise     Allocated with name '_keycode_at_encodermap_location_PARM_3'
                                   2363 ;layer_num     Allocated with name '_keycode_at_encodermap_location_layer_num_10000_457'
                                   2364 ;------------------------------------------------------------
                                   2365 ;	quantum/dynamic_keymap.c:594: uint16_t keycode_at_encodermap_location(uint8_t layer_num, uint8_t encoder_idx, bool clockwise) {
                                   2366 ;	-----------------------------------------
                                   2367 ;	 function keycode_at_encodermap_location
                                   2368 ;	-----------------------------------------
      008FC4                       2369 _keycode_at_encodermap_location:
      008FC4 E5 82            [12] 2370 	mov	a,dpl
      008FC6 90 0B FE         [24] 2371 	mov	dptr,#_keycode_at_encodermap_location_layer_num_10000_457
      008FC9 F0               [24] 2372 	movx	@dptr,a
                                   2373 ;	quantum/dynamic_keymap.c:595: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && encoder_idx < NUM_ENCODERS) {
      008FCA E0               [24] 2374 	movx	a,@dptr
      008FCB FF               [12] 2375 	mov	r7,a
      008FCC BF 06 00         [24] 2376 	cjne	r7,#0x06,00120$
      008FCF                       2377 00120$:
      008FCF 50 1E            [24] 2378 	jnc	00102$
      008FD1 90 0B FC         [24] 2379 	mov	dptr,#_keycode_at_encodermap_location_PARM_2
      008FD4 E0               [24] 2380 	movx	a,@dptr
      008FD5 FE               [12] 2381 	mov	r6,a
      008FD6 BE 01 00         [24] 2382 	cjne	r6,#0x01,00122$
      008FD9                       2383 00122$:
      008FD9 50 14            [24] 2384 	jnc	00102$
                                   2385 ;	quantum/dynamic_keymap.c:596: return dynamic_keymap_get_encoder(layer_num, encoder_idx, clockwise);
      008FDB 90 0B FD         [24] 2386 	mov	dptr,#_keycode_at_encodermap_location_PARM_3
      008FDE E0               [24] 2387 	movx	a,@dptr
      008FDF FE               [12] 2388 	mov	r6,a
      008FE0 90 0B A5         [24] 2389 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      008FE3 E4               [12] 2390 	clr	a
      008FE4 F0               [24] 2391 	movx	@dptr,a
      008FE5 90 0B A6         [24] 2392 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      008FE8 EE               [12] 2393 	mov	a,r6
      008FE9 F0               [24] 2394 	movx	@dptr,a
      008FEA 8F 82            [24] 2395 	mov	dpl, r7
      008FEC 02 88 9F         [24] 2396 	ljmp	_dynamic_keymap_get_encoder
      008FEF                       2397 00102$:
                                   2398 ;	quantum/dynamic_keymap.c:598: return KC_NO;
      008FEF 90 00 00         [24] 2399 	mov	dptr,#0x0000
                                   2400 ;	quantum/dynamic_keymap.c:599: }
      008FF2 22               [24] 2401 	ret
                                   2402 ;------------------------------------------------------------
                                   2403 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_count'
                                   2404 ;------------------------------------------------------------
                                   2405 ;	quantum/dynamic_keymap.c:602: uint8_t dynamic_keymap_macro_get_count(void) {
                                   2406 ;	-----------------------------------------
                                   2407 ;	 function dynamic_keymap_macro_get_count
                                   2408 ;	-----------------------------------------
      008FF3                       2409 _dynamic_keymap_macro_get_count:
                                   2410 ;	quantum/dynamic_keymap.c:603: return DYNAMIC_KEYMAP_MACRO_COUNT;
      008FF3 75 82 10         [24] 2411 	mov	dpl, #0x10
                                   2412 ;	quantum/dynamic_keymap.c:604: }
      008FF6 22               [24] 2413 	ret
                                   2414 ;------------------------------------------------------------
                                   2415 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer_size'
                                   2416 ;------------------------------------------------------------
                                   2417 ;	quantum/dynamic_keymap.c:606: uint16_t dynamic_keymap_macro_get_buffer_size(void) {
                                   2418 ;	-----------------------------------------
                                   2419 ;	 function dynamic_keymap_macro_get_buffer_size
                                   2420 ;	-----------------------------------------
      008FF7                       2421 _dynamic_keymap_macro_get_buffer_size:
                                   2422 ;	quantum/dynamic_keymap.c:607: return DYNAMIC_KEYMAP_MACRO_EEPROM_SIZE;
      008FF7 90 20 00         [24] 2423 	mov	dptr,#0x2000
                                   2424 ;	quantum/dynamic_keymap.c:608: }
      008FFA 22               [24] 2425 	ret
                                   2426 ;------------------------------------------------------------
                                   2427 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer'
                                   2428 ;------------------------------------------------------------
                                   2429 ;sloc0         Allocated with name '_dynamic_keymap_macro_get_buffer_sloc0_1_0'
                                   2430 ;size          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_2'
                                   2431 ;data          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_3'
                                   2432 ;offset        Allocated with name '_dynamic_keymap_macro_get_buffer_offset_10000_465'
                                   2433 ;------------------------------------------------------------
                                   2434 ;	quantum/dynamic_keymap.c:610: void dynamic_keymap_macro_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2435 ;	-----------------------------------------
                                   2436 ;	 function dynamic_keymap_macro_get_buffer
                                   2437 ;	-----------------------------------------
      008FFB                       2438 _dynamic_keymap_macro_get_buffer:
      008FFB 12 38 4C         [24] 2439 	lcall	_ak820_outline_0106
      008FFE 90 0C 04         [24] 2440 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_465
      009001 12 38 47         [24] 2441 	lcall	_ak820_outline_0105
                                   2442 ;	quantum/dynamic_keymap.c:613: ak820_macro_length(), offset, size, data);
      009004 12 2B 2B         [24] 2443 	lcall	_ak820_macro_length
      009007 12 43 2D         [24] 2444 	lcall	_ak820_outline_0136
      00900A 90 0C 04         [24] 2445 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_465
      00900D 12 38 16         [24] 2446 	lcall	_ak820_outline_0065
      009010 90 0B FF         [24] 2447 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_2
      009013 E0               [24] 2448 	movx	a,@dptr
      009014 F5 32            [12] 2449 	mov	_dynamic_keymap_macro_get_buffer_sloc0_1_0,a
      009016 A3               [24] 2450 	inc	dptr
      009017 E0               [24] 2451 	movx	a,@dptr
      009018 F5 33            [12] 2452 	mov	(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1),a
      00901A 90 0C 01         [24] 2453 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_3
      00901D 12 38 3B         [24] 2454 	lcall	_ak820_outline_0102
      009020 A3               [24] 2455 	inc	dptr
      009021 E0               [24] 2456 	movx	a,@dptr
      009022 FB               [12] 2457 	mov	r3,a
      009023 90 0B DC         [24] 2458 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      009026 12 48 CB         [24] 2459 	lcall	_ak820_outline_0064
      009029 90 0B DE         [24] 2460 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      00902C 12 38 22         [24] 2461 	lcall	_ak820_outline_0077
      00902F 90 0B E0         [24] 2462 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      009032 E5 32            [12] 2463 	mov	a,_dynamic_keymap_macro_get_buffer_sloc0_1_0
      009034 F0               [24] 2464 	movx	@dptr,a
      009035 E5 33            [12] 2465 	mov	a,(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1)
      009037 A3               [24] 2466 	inc	dptr
      009038 F0               [24] 2467 	movx	@dptr,a
      009039 90 0B E2         [24] 2468 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      00903C E8               [12] 2469 	mov	a,r0
      00903D F0               [24] 2470 	movx	@dptr,a
      00903E E9               [12] 2471 	mov	a,r1
      00903F A3               [24] 2472 	inc	dptr
      009040 12 48 ED         [24] 2473 	lcall	_ak820_outline_0191
      009043 90 08 00         [24] 2474 	mov	dptr,#0x0800
                                   2475 ;	quantum/dynamic_keymap.c:635: }
      009046 02 8D 08         [24] 2476 	ljmp	_ak820_dynamic_read_buffer
                                   2477 ;------------------------------------------------------------
                                   2478 ;Allocation info for local variables in function 'dynamic_keymap_macro_set_buffer'
                                   2479 ;------------------------------------------------------------
                                   2480 ;size          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_2'
                                   2481 ;data          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_3'
                                   2482 ;offset        Allocated with name '_dynamic_keymap_macro_set_buffer_offset_10000_467'
                                   2483 ;------------------------------------------------------------
                                   2484 ;	quantum/dynamic_keymap.c:638: bool dynamic_keymap_macro_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2485 ;	-----------------------------------------
                                   2486 ;	 function dynamic_keymap_macro_set_buffer
                                   2487 ;	-----------------------------------------
      009049                       2488 _dynamic_keymap_macro_set_buffer:
      009049 12 38 4C         [24] 2489 	lcall	_ak820_outline_0106
      00904C 90 0C 0B         [24] 2490 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_467
      00904F 12 38 47         [24] 2491 	lcall	_ak820_outline_0105
                                   2492 ;	quantum/dynamic_keymap.c:639: return ak820_macro_write(offset, size, data);
      009052 90 0C 0B         [24] 2493 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_467
      009055 12 37 F7         [24] 2494 	lcall	_ak820_outline_0056
      009058 90 0C 06         [24] 2495 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_2
      00905B 12 38 16         [24] 2496 	lcall	_ak820_outline_0065
      00905E 90 0C 08         [24] 2497 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_3
      009061 E0               [24] 2498 	movx	a,@dptr
      009062 F9               [12] 2499 	mov	r1,a
      009063 A3               [24] 2500 	inc	dptr
      009064 12 43 05         [24] 2501 	lcall	_ak820_outline_0082
      009067 90 05 10         [24] 2502 	mov	dptr,#_ak820_macro_write_PARM_2
      00906A 12 38 22         [24] 2503 	lcall	_ak820_outline_0077
      00906D 90 05 12         [24] 2504 	mov	dptr,#_ak820_macro_write_PARM_3
      009070 E9               [12] 2505 	mov	a,r1
      009071 12 54 38         [24] 2506 	lcall	_ak820_outline_0157
      009074 12 42 F8         [24] 2507 	lcall	_ak820_outline_0066
                                   2508 ;	quantum/dynamic_keymap.c:640: }
      009077 02 2B 45         [24] 2509 	ljmp	_ak820_macro_write
                                   2510 ;------------------------------------------------------------
                                   2511 ;Allocation info for local variables in function 'dynamic_keymap_macro_reset'
                                   2512 ;------------------------------------------------------------
                                   2513 ;	quantum/dynamic_keymap.c:655: void dynamic_keymap_macro_reset(void) {
                                   2514 ;	-----------------------------------------
                                   2515 ;	 function dynamic_keymap_macro_reset
                                   2516 ;	-----------------------------------------
      00907A                       2517 _dynamic_keymap_macro_reset:
                                   2518 ;	quantum/dynamic_keymap.c:657: ak820_macro_reset();
                                   2519 ;	quantum/dynamic_keymap.c:666: }
      00907A 02 2E 64         [24] 2520 	ljmp	_ak820_macro_reset
                                   2521 ;------------------------------------------------------------
                                   2522 ;Allocation info for local variables in function 'decode_keycode'
                                   2523 ;------------------------------------------------------------
                                   2524 ;kc            Allocated with name '_decode_keycode_kc_10000_471'
                                   2525 ;------------------------------------------------------------
                                   2526 ;	quantum/dynamic_keymap.c:668: static uint16_t decode_keycode(uint16_t kc) {
                                   2527 ;	-----------------------------------------
                                   2528 ;	 function decode_keycode
                                   2529 ;	-----------------------------------------
      00907D                       2530 _decode_keycode:
      00907D 12 38 4C         [24] 2531 	lcall	_ak820_outline_0106
      009080 90 0C 0D         [24] 2532 	mov	dptr,#_decode_keycode_kc_10000_471
      009083 12 38 47         [24] 2533 	lcall	_ak820_outline_0105
                                   2534 ;	quantum/dynamic_keymap.c:670: if (kc > 0xFF00)
      009086 90 0C 0D         [24] 2535 	mov	dptr,#_decode_keycode_kc_10000_471
      009089 12 37 C2         [24] 2536 	lcall	_ak820_outline_0010
      00908C C3               [12] 2537 	clr	c
      00908D E4               [12] 2538 	clr	a
      00908E 9C               [12] 2539 	subb	a,r4
      00908F 74 FF            [12] 2540 	mov	a,#0xff
      009091 9D               [12] 2541 	subb	a,r5
      009092 50 08            [24] 2542 	jnc	00102$
                                   2543 ;	free result
                                   2544 ;	quantum/dynamic_keymap.c:671: return (kc & 0xFF) << 8;
      009094 8C 05            [24] 2545 	mov	ar5,r4
      009096 7C 00            [12] 2546 	mov	r4,#0x00
      009098 12 38 51         [24] 2547 	lcall	_ak820_outline_0123
      00909B 22               [24] 2548 	ret
      00909C                       2549 00102$:
                                   2550 ;	quantum/dynamic_keymap.c:672: return kc;
      00909C 12 43 23         [24] 2551 	lcall	_ak820_outline_0119
                                   2552 ;	quantum/dynamic_keymap.c:673: }
      00909F 22               [24] 2553 	ret
                                   2554 ;------------------------------------------------------------
                                   2555 ;Allocation info for local variables in function 'dynamic_keymap_macro_send'
                                   2556 ;------------------------------------------------------------
                                   2557 ;id            Allocated with name '_dynamic_keymap_macro_send_id_10000_474'
                                   2558 ;sending       Allocated with name '_dynamic_keymap_macro_send_sending_10000_475'
                                   2559 ;p             Allocated with name '_dynamic_keymap_macro_send_p_10001_480'
                                   2560 ;end           Allocated with name '_dynamic_keymap_macro_send_end_10002_481'
                                   2561 ;data          Allocated with name '_dynamic_keymap_macro_send_data_10003_487'
                                   2562 ;kc            Allocated with name '_dynamic_keymap_macro_send_kc_110003_505'
                                   2563 ;d0            Allocated with name '_dynamic_keymap_macro_send_d0_80003_509'
                                   2564 ;d1            Allocated with name '_dynamic_keymap_macro_send_d1_80003_509'
                                   2565 ;ms            Allocated with name '_dynamic_keymap_macro_send_ms_80004_511'
                                   2566 ;i             Allocated with name '_dynamic_keymap_macro_send_i_100004_513'
                                   2567 ;delay         Allocated with name '_dynamic_keymap_macro_send_delay_50003_517'
                                   2568 ;i             Allocated with name '_dynamic_keymap_macro_send_i_70003_519'
                                   2569 ;------------------------------------------------------------
                                   2570 ;	quantum/dynamic_keymap.c:675: void dynamic_keymap_macro_send(uint8_t id) {
                                   2571 ;	-----------------------------------------
                                   2572 ;	 function dynamic_keymap_macro_send
                                   2573 ;	-----------------------------------------
      0090A0                       2574 _dynamic_keymap_macro_send:
      0090A0 E5 82            [12] 2575 	mov	a,dpl
      0090A2 90 0C 0F         [24] 2576 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_474
      0090A5 F0               [24] 2577 	movx	@dptr,a
                                   2578 ;	quantum/dynamic_keymap.c:680: if (sending) return;
      0090A6 90 0C 10         [24] 2579 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_475
      0090A9 E0               [24] 2580 	movx	a,@dptr
      0090AA 60 01            [24] 2581 	jz	00102$
      0090AC 22               [24] 2582 	ret
      0090AD                       2583 00102$:
                                   2584 ;	quantum/dynamic_keymap.c:682: if (id >= DYNAMIC_KEYMAP_MACRO_COUNT) {
      0090AD 90 0C 0F         [24] 2585 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_474
      0090B0 E0               [24] 2586 	movx	a,@dptr
      0090B1 FF               [12] 2587 	mov	r7,a
      0090B2 BF 10 00         [24] 2588 	cjne	r7,#0x10,00422$
      0090B5                       2589 00422$:
      0090B5 40 01            [24] 2590 	jc	00104$
                                   2591 ;	quantum/dynamic_keymap.c:683: return;
      0090B7 22               [24] 2592 	ret
      0090B8                       2593 00104$:
                                   2594 ;	quantum/dynamic_keymap.c:689: if (!ak820_macro_ready()) return;
      0090B8 C0 07            [24] 2595 	push	ar7
      0090BA 12 2A F2         [24] 2596 	lcall	_ak820_macro_ready
      0090BD E5 82            [12] 2597 	mov	a, dpl
      0090BF D0 07            [24] 2598 	pop	ar7
      0090C1 70 01            [24] 2599 	jnz	00106$
      0090C3 22               [24] 2600 	ret
      0090C4                       2601 00106$:
                                   2602 ;	quantum/dynamic_keymap.c:706: p = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR;
      0090C4 90 0C 11         [24] 2603 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_480
      0090C7 E4               [12] 2604 	clr	a
      0090C8 F0               [24] 2605 	movx	@dptr,a
      0090C9 74 08            [12] 2606 	mov	a,#0x08
      0090CB A3               [24] 2607 	inc	dptr
      0090CC F0               [24] 2608 	movx	@dptr,a
                                   2609 ;	quantum/dynamic_keymap.c:707: uint16_t end = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR + ak820_macro_length();
      0090CD C0 07            [24] 2610 	push	ar7
      0090CF 12 2B 2B         [24] 2611 	lcall	_ak820_macro_length
      0090D2 AD 82            [24] 2612 	mov	r5, dpl
      0090D4 AE 83            [24] 2613 	mov	r6, dph
      0090D6 D0 07            [24] 2614 	pop	ar7
      0090D8 74 08            [12] 2615 	mov	a,#0x08
      0090DA 2E               [12] 2616 	add	a, r6
      0090DB FE               [12] 2617 	mov	r6,a
                                   2618 ;	quantum/dynamic_keymap.c:712: while (id > 0) {
      0090DC 7B 00            [12] 2619 	mov	r3,#0x00
      0090DE 7C 08            [12] 2620 	mov	r4,#0x08
      0090E0                       2621 00111$:
      0090E0 EF               [12] 2622 	mov	a,r7
      0090E1 60 31            [24] 2623 	jz	00113$
                                   2624 ;	quantum/dynamic_keymap.c:716: if (p == end) {
      0090E3 EB               [12] 2625 	mov	a,r3
      0090E4 B5 05 05         [24] 2626 	cjne	a,ar5,00108$
      0090E7 EC               [12] 2627 	mov	a,r4
      0090E8 B5 06 01         [24] 2628 	cjne	a,ar6,00108$
                                   2629 ;	quantum/dynamic_keymap.c:717: return;
      0090EB 22               [24] 2630 	ret
      0090EC                       2631 00108$:
                                   2632 ;	quantum/dynamic_keymap.c:719: if (eeprom_read_byte((const uint8_t *)(uintptr_t)p) == 0) {
      0090EC 8B 01            [24] 2633 	mov	ar1,r3
      0090EE 8C 02            [24] 2634 	mov	ar2,r4
      0090F0 8A 00            [24] 2635 	mov	ar0,r2
      0090F2 7A 00            [12] 2636 	mov	r2,#0x00
      0090F4 89 82            [24] 2637 	mov	dpl, r1
      0090F6 88 83            [24] 2638 	mov	dph, r0
      0090F8 8A F0            [24] 2639 	mov	b, r2
      0090FA 12 40 35         [24] 2640 	lcall	_eeprom_read_byte
      0090FD E5 82            [12] 2641 	mov	a, dpl
      0090FF 70 06            [24] 2642 	jnz	00110$
                                   2643 ;	quantum/dynamic_keymap.c:720: --id;
      009101 1F               [12] 2644 	dec	r7
      009102 90 0C 0F         [24] 2645 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_474
      009105 EF               [12] 2646 	mov	a,r7
      009106 F0               [24] 2647 	movx	@dptr,a
      009107                       2648 00110$:
                                   2649 ;	quantum/dynamic_keymap.c:722: ++p;
      009107 0B               [12] 2650 	inc	r3
      009108 BB 00 01         [24] 2651 	cjne	r3,#0x00,00429$
      00910B 0C               [12] 2652 	inc	r4
      00910C                       2653 00429$:
      00910C 90 0C 11         [24] 2654 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_480
      00910F 12 38 2F         [24] 2655 	lcall	_ak820_outline_0081
      009112 80 CC            [24] 2656 	sjmp	00111$
      009114                       2657 00113$:
                                   2658 ;	quantum/dynamic_keymap.c:728: sending = true;
      009114 90 0C 10         [24] 2659 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_475
      009117 74 01            [12] 2660 	mov	a,#0x01
      009119 F0               [24] 2661 	movx	@dptr,a
                                   2662 ;	quantum/dynamic_keymap.c:730: ak820_macro_cancelled = ak820_macro_primitive = false;
      00911A 12 93 D0         [24] 2663 	lcall	_ak820_outline_0167
      00911D 90 0A 47         [24] 2664 	mov	dptr,#_ak820_macro_cancelled
      009120 F0               [24] 2665 	movx	@dptr,a
                                   2666 ;	quantum/dynamic_keymap.c:735: char data[4] = {0, 0, 0, 0};
      009121 90 0C 13         [24] 2667 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_487
      009124 F0               [24] 2668 	movx	@dptr,a
      009125 90 0C 14         [24] 2669 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_487 + 0x0001)
      009128 F0               [24] 2670 	movx	@dptr,a
      009129 90 0C 15         [24] 2671 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_487 + 0x0002)
      00912C F0               [24] 2672 	movx	@dptr,a
      00912D 90 0C 16         [24] 2673 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_487 + 0x0003)
      009130 F0               [24] 2674 	movx	@dptr,a
                                   2675 ;	quantum/dynamic_keymap.c:738: while (p < end
      009131                       2676 00167$:
                                   2677 ;	quantum/dynamic_keymap.c:740: && !ak820_macro_cancelled
      009131 90 0C 11         [24] 2678 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_480
      009134 E0               [24] 2679 	movx	a,@dptr
      009135 FC               [12] 2680 	mov	r4,a
      009136 A3               [24] 2681 	inc	dptr
      009137 E0               [24] 2682 	movx	a,@dptr
      009138 FF               [12] 2683 	mov	r7,a
      009139 C3               [12] 2684 	clr	c
      00913A EC               [12] 2685 	mov	a,r4
      00913B 9D               [12] 2686 	subb	a,r5
      00913C EF               [12] 2687 	mov	a,r7
      00913D 9E               [12] 2688 	subb	a,r6
      00913E 40 02            [24] 2689 	jc	00430$
      009140 61 42            [12] 2690 	ajmp	00169$
      009142                       2691 00430$:
      009142 90 0A 47         [24] 2692 	mov	dptr,#_ak820_macro_cancelled
      009145 E0               [24] 2693 	movx	a,@dptr
      009146 60 02            [24] 2694 	jz	00431$
      009148 61 42            [12] 2695 	ajmp	00169$
      00914A                       2696 00431$:
                                   2697 ;	quantum/dynamic_keymap.c:743: data[0] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      00914A 8C 02            [24] 2698 	mov	ar2,r4
      00914C 8F 03            [24] 2699 	mov	ar3,r7
      00914E 90 0C 11         [24] 2700 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_480
      009151 74 01            [12] 2701 	mov	a,#0x01
      009153 2C               [12] 2702 	add	a, r4
      009154 F0               [24] 2703 	movx	@dptr,a
      009155 E4               [12] 2704 	clr	a
      009156 3F               [12] 2705 	addc	a, r7
      009157 A3               [24] 2706 	inc	dptr
      009158 F0               [24] 2707 	movx	@dptr,a
      009159 7F 00            [12] 2708 	mov	r7,#0x00
      00915B 12 43 28         [24] 2709 	lcall	_ak820_outline_0135
      00915E 8F F0            [24] 2710 	mov	b, r7
      009160 12 40 35         [24] 2711 	lcall	_eeprom_read_byte
      009163 AF 82            [24] 2712 	mov	r7, dpl
      009165 90 0C 13         [24] 2713 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_487
      009168 EF               [12] 2714 	mov	a,r7
      009169 F0               [24] 2715 	movx	@dptr,a
                                   2716 ;	quantum/dynamic_keymap.c:744: data[1] = 0;
      00916A 90 0C 14         [24] 2717 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_487 + 0x0001)
      00916D E4               [12] 2718 	clr	a
      00916E F0               [24] 2719 	movx	@dptr,a
                                   2720 ;	quantum/dynamic_keymap.c:746: if (data[0] == 0) {
      00916F 90 0C 13         [24] 2721 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_487
      009172 E0               [24] 2722 	movx	a,@dptr
      009173 70 02            [24] 2723 	jnz	00432$
      009175 61 42            [12] 2724 	ajmp	00169$
      009177                       2725 00432$:
                                   2726 ;	quantum/dynamic_keymap.c:749: if (data[0] == SS_QMK_PREFIX) {
      009177 90 0C 13         [24] 2727 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_487
      00917A E0               [24] 2728 	movx	a,@dptr
      00917B FF               [12] 2729 	mov	r7,a
      00917C BF 01 02         [24] 2730 	cjne	r7,#0x01,00433$
      00917F 80 02            [24] 2731 	sjmp	00434$
      009181                       2732 00433$:
      009181 61 25            [12] 2733 	ajmp	00164$
      009183                       2734 00434$:
                                   2735 ;	quantum/dynamic_keymap.c:752: data[1] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      009183 12 93 4A         [24] 2736 	lcall	_ak820_outline_0000
      009186 12 40 35         [24] 2737 	lcall	_eeprom_read_byte
      009189 AF 82            [24] 2738 	mov	r7, dpl
      00918B 90 0C 14         [24] 2739 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_487 + 0x0001)
      00918E EF               [12] 2740 	mov	a,r7
      00918F F0               [24] 2741 	movx	@dptr,a
                                   2742 ;	quantum/dynamic_keymap.c:753: if (data[1] == 0)
      009190 EF               [12] 2743 	mov	a,r7
      009191 70 02            [24] 2744 	jnz	00435$
      009193 61 42            [12] 2745 	ajmp	00169$
      009195                       2746 00435$:
                                   2747 ;	quantum/dynamic_keymap.c:755: if (data[1] == SS_TAP_CODE || data[1] == SS_DOWN_CODE || data[1] == SS_UP_CODE) {
      009195 12 93 97         [24] 2748 	lcall	_ak820_outline_0095
      009198 BF 01 02         [24] 2749 	cjne	r7,#0x01,00436$
      00919B 80 12            [24] 2750 	sjmp	00151$
      00919D                       2751 00436$:
      00919D 12 93 97         [24] 2752 	lcall	_ak820_outline_0095
      0091A0 BF 02 02         [24] 2753 	cjne	r7,#0x02,00437$
      0091A3 80 0A            [24] 2754 	sjmp	00151$
      0091A5                       2755 00437$:
      0091A5 12 93 97         [24] 2756 	lcall	_ak820_outline_0095
      0091A8 BF 03 02         [24] 2757 	cjne	r7,#0x03,00438$
      0091AB 80 02            [24] 2758 	sjmp	00439$
      0091AD                       2759 00438$:
      0091AD 41 0E            [12] 2760 	ajmp	00152$
      0091AF                       2761 00439$:
      0091AF                       2762 00151$:
                                   2763 ;	quantum/dynamic_keymap.c:757: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      0091AF 12 93 4A         [24] 2764 	lcall	_ak820_outline_0000
      0091B2 12 40 35         [24] 2765 	lcall	_eeprom_read_byte
      0091B5 12 93 E8         [24] 2766 	lcall	_ak820_outline_0183
                                   2767 ;	quantum/dynamic_keymap.c:761: if (data[2] != 0) {
      0091B8 70 02            [24] 2768 	jnz	00440$
      0091BA 21 31            [12] 2769 	ajmp	00167$
      0091BC                       2770 00440$:
                                   2771 ;	quantum/dynamic_keymap.c:763: ak820_macro_primitive = data[1] != SS_TAP_CODE;
      0091BC 12 93 97         [24] 2772 	lcall	_ak820_outline_0095
      0091BF BF 01 03         [24] 2773 	cjne	r7,#0x01,00441$
      0091C2 D3               [12] 2774 	setb	c
      0091C3 80 01            [24] 2775 	sjmp	00442$
      0091C5                       2776 00441$:
      0091C5 C3               [12] 2777 	clr	c
      0091C6                       2778 00442$:
      0091C6 92 25            [24] 2779 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      0091C8 90 0A 46         [24] 2780 	mov	dptr,#_ak820_macro_primitive
      0091CB B3               [12] 2781 	cpl	c
      0091CC E4               [12] 2782 	clr	a
      0091CD 33               [12] 2783 	rlc	a
      0091CE F0               [24] 2784 	movx	@dptr,a
                                   2785 ;	quantum/dynamic_keymap.c:765: if (data[1] == SS_TAP_CODE) tap_code((uint8_t)data[2]);
      0091CF 12 93 97         [24] 2786 	lcall	_ak820_outline_0095
      0091D2 BF 01 10         [24] 2787 	cjne	r7,#0x01,00122$
      0091D5 12 93 C9         [24] 2788 	lcall	_ak820_outline_0153
      0091D8 C0 06            [24] 2789 	push	ar6
      0091DA C0 05            [24] 2790 	push	ar5
      0091DC 12 7A 88         [24] 2791 	lcall	_tap_code
      0091DF D0 05            [24] 2792 	pop	ar5
      0091E1 D0 06            [24] 2793 	pop	ar6
      0091E3 80 24            [24] 2794 	sjmp	00123$
      0091E5                       2795 00122$:
                                   2796 ;	quantum/dynamic_keymap.c:766: else if (data[1] == SS_DOWN_CODE) register_code((uint8_t)data[2]);
      0091E5 12 93 97         [24] 2797 	lcall	_ak820_outline_0095
      0091E8 BF 02 10         [24] 2798 	cjne	r7,#0x02,00119$
      0091EB 12 93 C9         [24] 2799 	lcall	_ak820_outline_0153
      0091EE C0 06            [24] 2800 	push	ar6
      0091F0 C0 05            [24] 2801 	push	ar5
      0091F2 12 79 84         [24] 2802 	lcall	_register_code
      0091F5 D0 05            [24] 2803 	pop	ar5
      0091F7 D0 06            [24] 2804 	pop	ar6
      0091F9 80 0E            [24] 2805 	sjmp	00123$
      0091FB                       2806 00119$:
                                   2807 ;	quantum/dynamic_keymap.c:767: else unregister_code((uint8_t)data[2]);
      0091FB 12 93 C9         [24] 2808 	lcall	_ak820_outline_0153
      0091FE C0 06            [24] 2809 	push	ar6
      009200 C0 05            [24] 2810 	push	ar5
      009202 12 79 F1         [24] 2811 	lcall	_unregister_code
      009205 D0 05            [24] 2812 	pop	ar5
      009207 D0 06            [24] 2813 	pop	ar6
      009209                       2814 00123$:
                                   2815 ;	quantum/dynamic_keymap.c:769: ak820_macro_primitive = false;
      009209 12 93 D0         [24] 2816 	lcall	_ak820_outline_0167
      00920C 21 31            [12] 2817 	ajmp	00167$
      00920E                       2818 00152$:
                                   2819 ;	quantum/dynamic_keymap.c:777: } else if (data[1] == VIAL_MACRO_EXT_TAP || data[1] == VIAL_MACRO_EXT_DOWN || data[1] == VIAL_MACRO_EXT_UP) {
      00920E 12 93 97         [24] 2820 	lcall	_ak820_outline_0095
      009211 BF 05 02         [24] 2821 	cjne	r7,#0x05,00447$
      009214 80 12            [24] 2822 	sjmp	00146$
      009216                       2823 00447$:
      009216 12 93 97         [24] 2824 	lcall	_ak820_outline_0095
      009219 BF 06 02         [24] 2825 	cjne	r7,#0x06,00448$
      00921C 80 0A            [24] 2826 	sjmp	00146$
      00921E                       2827 00448$:
      00921E 12 93 97         [24] 2828 	lcall	_ak820_outline_0095
      009221 BF 07 02         [24] 2829 	cjne	r7,#0x07,00449$
      009224 80 02            [24] 2830 	sjmp	00450$
      009226                       2831 00449$:
      009226 41 C7            [12] 2832 	ajmp	00147$
      009228                       2833 00450$:
      009228                       2834 00146$:
                                   2835 ;	quantum/dynamic_keymap.c:778: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      009228 12 93 4A         [24] 2836 	lcall	_ak820_outline_0000
      00922B 12 40 35         [24] 2837 	lcall	_eeprom_read_byte
      00922E 12 93 E8         [24] 2838 	lcall	_ak820_outline_0183
                                   2839 ;	quantum/dynamic_keymap.c:779: if (data[2] != 0) {
      009231 70 02            [24] 2840 	jnz	00451$
      009233 21 31            [12] 2841 	ajmp	00167$
      009235                       2842 00451$:
                                   2843 ;	quantum/dynamic_keymap.c:780: data[3] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      009235 12 93 4A         [24] 2844 	lcall	_ak820_outline_0000
      009238 12 40 35         [24] 2845 	lcall	_eeprom_read_byte
      00923B AF 82            [24] 2846 	mov	r7, dpl
      00923D 90 0C 16         [24] 2847 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_487 + 0x0003)
      009240 EF               [12] 2848 	mov	a,r7
      009241 F0               [24] 2849 	movx	@dptr,a
                                   2850 ;	quantum/dynamic_keymap.c:781: if (data[3] != 0) {
      009242 EF               [12] 2851 	mov	a,r7
      009243 70 02            [24] 2852 	jnz	00452$
      009245 21 31            [12] 2853 	ajmp	00167$
      009247                       2854 00452$:
                                   2855 ;	quantum/dynamic_keymap.c:784: kc = (uint8_t)data[2] | ((uint16_t)(uint8_t)data[3] << 8);
      009247 90 0C 15         [24] 2856 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_487 + 0x0002)
      00924A E0               [24] 2857 	movx	a,@dptr
      00924B FF               [12] 2858 	mov	r7,a
      00924C 90 0C 16         [24] 2859 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_487 + 0x0003)
      00924F E0               [24] 2860 	movx	a,@dptr
      009250 FB               [12] 2861 	mov	r3,a
      009251 E4               [12] 2862 	clr	a
      009252 FC               [12] 2863 	mov	r4,a
      009253 FA               [12] 2864 	mov	r2,a
      009254 EF               [12] 2865 	mov	a,r7
      009255 42 04            [12] 2866 	orl	ar4,a
      009257 EA               [12] 2867 	mov	a,r2
      009258 42 03            [12] 2868 	orl	ar3,a
                                   2869 ;	quantum/dynamic_keymap.c:788: kc = decode_keycode(kc);
      00925A 12 43 53         [24] 2870 	lcall	_ak820_outline_0184
      00925D C0 06            [24] 2871 	push	ar6
      00925F C0 05            [24] 2872 	push	ar5
      009261 11 7D            [12] 2873 	acall	_decode_keycode
      009263 AC 82            [24] 2874 	mov	r4, dpl
      009265 AF 83            [24] 2875 	mov	r7, dph
      009267 D0 05            [24] 2876 	pop	ar5
      009269 D0 06            [24] 2877 	pop	ar6
                                   2878 ;	quantum/dynamic_keymap.c:790: ak820_macro_primitive = data[1] != VIAL_MACRO_EXT_TAP;
      00926B 90 0C 14         [24] 2879 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_487 + 0x0001)
      00926E E0               [24] 2880 	movx	a,@dptr
      00926F FB               [12] 2881 	mov	r3,a
      009270 BB 05 03         [24] 2882 	cjne	r3,#0x05,00453$
      009273 D3               [12] 2883 	setb	c
      009274 80 01            [24] 2884 	sjmp	00454$
      009276                       2885 00453$:
      009276 C3               [12] 2886 	clr	c
      009277                       2887 00454$:
      009277 92 25            [24] 2888 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      009279 90 0A 46         [24] 2889 	mov	dptr,#_ak820_macro_primitive
      00927C B3               [12] 2890 	cpl	c
      00927D E4               [12] 2891 	clr	a
      00927E 33               [12] 2892 	rlc	a
      00927F F0               [24] 2893 	movx	@dptr,a
                                   2894 ;	quantum/dynamic_keymap.c:792: switch (data[1]) {
      009280 90 0C 14         [24] 2895 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_487 + 0x0001)
      009283 E0               [24] 2896 	movx	a,@dptr
      009284 FB               [12] 2897 	mov	r3,a
      009285 BB 05 02         [24] 2898 	cjne	r3,#0x05,00455$
      009288 80 0A            [24] 2899 	sjmp	00126$
      00928A                       2900 00455$:
      00928A BB 06 02         [24] 2901 	cjne	r3,#0x06,00456$
      00928D 80 15            [24] 2902 	sjmp	00127$
      00928F                       2903 00456$:
                                   2904 ;	quantum/dynamic_keymap.c:793: case VIAL_MACRO_EXT_TAP:
      00928F BB 07 30         [24] 2905 	cjne	r3,#0x07,00129$
      009292 80 20            [24] 2906 	sjmp	00128$
      009294                       2907 00126$:
                                   2908 ;	quantum/dynamic_keymap.c:794: vial_keycode_tap(kc);
      009294 12 48 E8         [24] 2909 	lcall	_ak820_outline_0185
      009297 C0 06            [24] 2910 	push	ar6
      009299 C0 05            [24] 2911 	push	ar5
      00929B 12 B6 9A         [24] 2912 	lcall	_vial_keycode_tap
      00929E D0 05            [24] 2913 	pop	ar5
      0092A0 D0 06            [24] 2914 	pop	ar6
                                   2915 ;	quantum/dynamic_keymap.c:795: break;
                                   2916 ;	quantum/dynamic_keymap.c:796: case VIAL_MACRO_EXT_DOWN:
      0092A2 80 1E            [24] 2917 	sjmp	00129$
      0092A4                       2918 00127$:
                                   2919 ;	quantum/dynamic_keymap.c:797: vial_keycode_down(kc);
      0092A4 12 48 E8         [24] 2920 	lcall	_ak820_outline_0185
      0092A7 C0 06            [24] 2921 	push	ar6
      0092A9 C0 05            [24] 2922 	push	ar5
      0092AB 12 B5 CF         [24] 2923 	lcall	_vial_keycode_down
      0092AE D0 05            [24] 2924 	pop	ar5
      0092B0 D0 06            [24] 2925 	pop	ar6
                                   2926 ;	quantum/dynamic_keymap.c:798: break;
                                   2927 ;	quantum/dynamic_keymap.c:799: case VIAL_MACRO_EXT_UP:
      0092B2 80 0E            [24] 2928 	sjmp	00129$
      0092B4                       2929 00128$:
                                   2930 ;	quantum/dynamic_keymap.c:800: vial_keycode_up(kc);
      0092B4 12 48 E8         [24] 2931 	lcall	_ak820_outline_0185
      0092B7 C0 06            [24] 2932 	push	ar6
      0092B9 C0 05            [24] 2933 	push	ar5
      0092BB 12 B6 35         [24] 2934 	lcall	_vial_keycode_up
      0092BE D0 05            [24] 2935 	pop	ar5
      0092C0 D0 06            [24] 2936 	pop	ar6
                                   2937 ;	quantum/dynamic_keymap.c:802: }
      0092C2                       2938 00129$:
                                   2939 ;	quantum/dynamic_keymap.c:804: ak820_macro_primitive = false;
      0092C2 12 93 D0         [24] 2940 	lcall	_ak820_outline_0167
      0092C5 21 31            [12] 2941 	ajmp	00167$
      0092C7                       2942 00147$:
                                   2943 ;	quantum/dynamic_keymap.c:808: } else if (data[1] == SS_DELAY_CODE) {
      0092C7 12 93 97         [24] 2944 	lcall	_ak820_outline_0095
      0092CA BF 04 02         [24] 2945 	cjne	r7,#0x04,00458$
      0092CD 80 02            [24] 2946 	sjmp	00459$
      0092CF                       2947 00458$:
      0092CF 21 31            [12] 2948 	ajmp	00167$
      0092D1                       2949 00459$:
                                   2950 ;	quantum/dynamic_keymap.c:810: uint8_t d0 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      0092D1 12 93 4A         [24] 2951 	lcall	_ak820_outline_0000
      0092D4 12 40 35         [24] 2952 	lcall	_eeprom_read_byte
      0092D7 AF 82            [24] 2953 	mov	r7, dpl
                                   2954 ;	quantum/dynamic_keymap.c:811: uint8_t d1 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      0092D9 90 0C 11         [24] 2955 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_480
      0092DC 12 38 41         [24] 2956 	lcall	_ak820_outline_0103
      0092DF 90 0C 11         [24] 2957 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_480
      0092E2 74 01            [12] 2958 	mov	a,#0x01
      0092E4 2B               [12] 2959 	add	a, r3
      0092E5 F0               [24] 2960 	movx	@dptr,a
      0092E6 E4               [12] 2961 	clr	a
      0092E7 3C               [12] 2962 	addc	a, r4
      0092E8 A3               [24] 2963 	inc	dptr
      0092E9 F0               [24] 2964 	movx	@dptr,a
      0092EA 7A 00            [12] 2965 	mov	r2,#0x00
      0092EC 12 33 FC         [24] 2966 	lcall	_ak820_outline_0124
      0092EF 8A F0            [24] 2967 	mov	b, r2
      0092F1 12 40 35         [24] 2968 	lcall	_eeprom_read_byte
      0092F4 AC 82            [24] 2969 	mov	r4, dpl
                                   2970 ;	quantum/dynamic_keymap.c:812: if (d0 == 0 || d1 == 0)
      0092F6 EF               [12] 2971 	mov	a,r7
      0092F7 60 49            [24] 2972 	jz	00169$
      0092F9 EC               [12] 2973 	mov	a,r4
      0092FA 60 46            [24] 2974 	jz	00169$
                                   2975 ;	quantum/dynamic_keymap.c:815: uint16_t ms = (uint16_t)(d0 - 1) + (uint16_t)(d1 - 1) * 255u;
      0092FC 1F               [12] 2976 	dec	r7
      0092FD 1C               [12] 2977 	dec	r4
      0092FE EC               [12] 2978 	mov	a,r4
      0092FF 75 F0 FF         [24] 2979 	mov	b,#0xff
      009302 A4               [48] 2980 	mul	ab
      009303 FC               [12] 2981 	mov	r4,a
      009304 AB F0            [24] 2982 	mov	r3,b
      009306 7A 00            [12] 2983 	mov	r2,#0x00
      009308 EC               [12] 2984 	mov	a,r4
      009309 2F               [12] 2985 	add	a, r7
      00930A FC               [12] 2986 	mov	r4,a
      00930B EB               [12] 2987 	mov	a,r3
      00930C 3A               [12] 2988 	addc	a, r2
      00930D FB               [12] 2989 	mov	r3,a
                                   2990 ;	quantum/dynamic_keymap.c:816: while (ms--) wait_ms(1);
      00930E                       2991 00141$:
      00930E 8C 02            [24] 2992 	mov	ar2,r4
      009310 8B 07            [24] 2993 	mov	ar7,r3
      009312 1C               [12] 2994 	dec	r4
      009313 BC FF 01         [24] 2995 	cjne	r4,#0xff,00462$
      009316 1B               [12] 2996 	dec	r3
      009317                       2997 00462$:
      009317 EA               [12] 2998 	mov	a,r2
      009318 4F               [12] 2999 	orl	a,r7
      009319 70 02            [24] 3000 	jnz	00463$
      00931B 21 31            [12] 3001 	ajmp	00167$
      00931D                       3002 00463$:
      00931D 90 00 01         [24] 3003 	mov	dptr,#0x0001
      009320 12 5D A5         [24] 3004 	lcall	_mDelaymS
      009323 80 E9            [24] 3005 	sjmp	00141$
      009325                       3006 00164$:
                                   3007 ;	quantum/dynamic_keymap.c:822: if ((uint8_t)data[0] >= 128) break;
      009325 90 0C 13         [24] 3008 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_487
      009328 E0               [24] 3009 	movx	a,@dptr
      009329 FF               [12] 3010 	mov	r7,a
      00932A BF 80 00         [24] 3011 	cjne	r7,#0x80,00464$
      00932D                       3012 00464$:
      00932D 50 13            [24] 3013 	jnc	00169$
                                   3014 ;	quantum/dynamic_keymap.c:826: send_char(data[0]);
      00932F 90 0C 13         [24] 3015 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_487
      009332 E0               [24] 3016 	movx	a,@dptr
      009333 F5 82            [12] 3017 	mov	dpl,a
      009335 C0 06            [24] 3018 	push	ar6
      009337 C0 05            [24] 3019 	push	ar5
      009339 12 A8 AE         [24] 3020 	lcall	_send_char
      00933C D0 05            [24] 3021 	pop	ar5
      00933E D0 06            [24] 3022 	pop	ar6
                                   3023 ;	quantum/dynamic_keymap.c:827: for (uint8_t delay = DYNAMIC_KEYMAP_MACRO_DELAY; delay; --delay) wait_ms(1);
      009340 21 31            [12] 3024 	ajmp	00167$
      009342                       3025 00169$:
                                   3026 ;	quantum/dynamic_keymap.c:835: ak820_macro_primitive = false;
      009342 12 93 D0         [24] 3027 	lcall	_ak820_outline_0167
                                   3028 ;	quantum/dynamic_keymap.c:837: sending = false;
      009345 90 0C 10         [24] 3029 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_475
      009348 F0               [24] 3030 	movx	@dptr,a
                                   3031 ;	quantum/dynamic_keymap.c:839: }
      009349 22               [24] 3032 	ret
                                   3033 	.area CSEG    (CODE)
                                   3034 	.area CONST   (CODE)
                                   3035 	.area XINIT   (CODE)
                                   3036 	.area CABS    (ABS,CODE)
                                   3037 
                                   3038 ; Experimental exact instruction outlining.
                                   3039 	.globl _ak820_outline_0000
                                   3040 	.globl _ak820_outline_0005
                                   3041 	.globl _ak820_outline_0010
                                   3042 	.globl _ak820_outline_0012
                                   3043 	.globl _ak820_outline_0017
                                   3044 	.globl _ak820_outline_0026
                                   3045 	.globl _ak820_outline_0035
                                   3046 	.globl _ak820_outline_0041
                                   3047 	.globl _ak820_outline_0050
                                   3048 	.globl _ak820_outline_0056
                                   3049 	.globl _ak820_outline_0064
                                   3050 	.globl _ak820_outline_0065
                                   3051 	.globl _ak820_outline_0066
                                   3052 	.globl _ak820_outline_0075
                                   3053 	.globl _ak820_outline_0077
                                   3054 	.globl _ak820_outline_0078
                                   3055 	.globl _ak820_outline_0081
                                   3056 	.globl _ak820_outline_0082
                                   3057 	.globl _ak820_outline_0084
                                   3058 	.globl _ak820_outline_0095
                                   3059 	.globl _ak820_outline_0101
                                   3060 	.globl _ak820_outline_0102
                                   3061 	.globl _ak820_outline_0103
                                   3062 	.globl _ak820_outline_0105
                                   3063 	.globl _ak820_outline_0106
                                   3064 	.globl _ak820_outline_0113
                                   3065 	.globl _ak820_outline_0117
                                   3066 	.globl _ak820_outline_0119
                                   3067 	.globl _ak820_outline_0123
                                   3068 	.globl _ak820_outline_0124
                                   3069 	.globl _ak820_outline_0127
                                   3070 	.globl _ak820_outline_0131
                                   3071 	.globl _ak820_outline_0135
                                   3072 	.globl _ak820_outline_0136
                                   3073 	.globl _ak820_outline_0137
                                   3074 	.globl _ak820_outline_0138
                                   3075 	.globl _ak820_outline_0142
                                   3076 	.globl _ak820_outline_0143
                                   3077 	.globl _ak820_outline_0150
                                   3078 	.globl _ak820_outline_0151
                                   3079 	.globl _ak820_outline_0153
                                   3080 	.globl _ak820_outline_0157
                                   3081 	.globl _ak820_outline_0158
                                   3082 	.globl _ak820_outline_0162
                                   3083 	.globl _ak820_outline_0167
                                   3084 	.globl _ak820_outline_0179
                                   3085 	.globl _ak820_outline_0180
                                   3086 	.globl _ak820_outline_0183
                                   3087 	.globl _ak820_outline_0184
                                   3088 	.globl _ak820_outline_0185
                                   3089 	.globl _ak820_outline_0189
                                   3090 	.globl _ak820_outline_0191
                                   3091 
                                   3092 	.area CSEG (CODE)
                                   3093 ; function ak820_outline_0000
      00934A                       3094 _ak820_outline_0000:
      00934A 90 0C 11         [24] 3095 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_480
      00934D E0               [24] 3096 	movx	a,@dptr
      00934E FC               [12] 3097 	mov	r4,a
      00934F A3               [24] 3098 	inc	dptr
      009350 E0               [24] 3099 	movx	a,@dptr
      009351 FF               [12] 3100 	mov	r7,a
      009352 90 0C 11         [24] 3101 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_480
      009355 74 01            [12] 3102 	mov	a,#0x01
      009357 2C               [12] 3103 	add	a,r4
      009358 F0               [24] 3104 	movx	@dptr,a
      009359 E4               [12] 3105 	clr	a
      00935A 3F               [12] 3106 	addc	a,r7
      00935B A3               [24] 3107 	inc	dptr
      00935C F0               [24] 3108 	movx	@dptr,a
      00935D 7B 00            [12] 3109 	mov	r3,#0x00
      00935F 8C 82            [24] 3110 	mov	dpl,r4
      009361 8F 83            [24] 3111 	mov	dph,r7
      009363 8B F0            [24] 3112 	mov	b,r3
      009365 22               [24] 3113 	ret
                                   3114 
                                   3115 	.area CSEG (CODE)
                                   3116 ; function ak820_outline_0026
      009366                       3117 _ak820_outline_0026:
      009366 2D               [12] 3118 	add	a,r5
      009367 F9               [12] 3119 	mov	r1,a
      009368 E4               [12] 3120 	clr	a
      009369 3E               [12] 3121 	addc	a,r6
      00936A FA               [12] 3122 	mov	r2,a
      00936B 8F 03            [24] 3123 	mov	ar3,r7
      00936D 89 82            [24] 3124 	mov	dpl,r1
      00936F 8A 83            [24] 3125 	mov	dph,r2
      009371 8B F0            [24] 3126 	mov	b,r3
      009373 22               [24] 3127 	ret
                                   3128 
                                   3129 	.area CSEG (CODE)
                                   3130 ; function ak820_outline_0041
      009374                       3131 _ak820_outline_0041:
      009374 90 0E 68         [24] 3132 	mov	dptr,#_memset_PARM_2
      009377 E4               [12] 3133 	clr	a
      009378 F0               [24] 3134 	movx	@dptr,a
      009379 90 0E 69         [24] 3135 	mov	dptr,#_memset_PARM_3
      00937C 74 0A            [12] 3136 	mov	a,#0x0a
      00937E F0               [24] 3137 	movx	@dptr,a
      00937F E4               [12] 3138 	clr	a
      009380 A3               [24] 3139 	inc	dptr
      009381 F0               [24] 3140 	movx	@dptr,a
      009382 8E 82            [24] 3141 	mov	dpl,r6
      009384 8F 83            [24] 3142 	mov	dph,r7
      009386 8D F0            [24] 3143 	mov	b,r5
      009388 22               [24] 3144 	ret
                                   3145 
                                   3146 	.area CSEG (CODE)
                                   3147 ; function ak820_outline_0084
      009389                       3148 _ak820_outline_0084:
      009389 ED               [12] 3149 	mov	a,r5
      00938A 75 F0 0A         [24] 3150 	mov	b,#0x0a
      00938D A4               [48] 3151 	mul	ab
      00938E 24 58            [12] 3152 	add	a,#0x58
      009390 FC               [12] 3153 	mov	r4,a
      009391 74 06            [12] 3154 	mov	a,#0x06
      009393 35 F0            [12] 3155 	addc	a,b
      009395 FD               [12] 3156 	mov	r5,a
      009396 22               [24] 3157 	ret
                                   3158 
                                   3159 	.area CSEG (CODE)
                                   3160 ; function ak820_outline_0095
      009397                       3161 _ak820_outline_0095:
      009397 90 0C 14         [24] 3162 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_487+0x0001)
      00939A E0               [24] 3163 	movx	a,@dptr
      00939B FF               [12] 3164 	mov	r7,a
      00939C 22               [24] 3165 	ret
                                   3166 
                                   3167 	.area CSEG (CODE)
                                   3168 ; function ak820_outline_0101
      00939D                       3169 _ak820_outline_0101:
      00939D 90 0B 98         [24] 3170 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      0093A0 EE               [12] 3171 	mov	a,r6
      0093A1 F0               [24] 3172 	movx	@dptr,a
      0093A2 90 0B 99         [24] 3173 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      0093A5 ED               [12] 3174 	mov	a,r5
      0093A6 F0               [24] 3175 	movx	@dptr,a
      0093A7 8F 82            [24] 3176 	mov	dpl,r7
      0093A9 22               [24] 3177 	ret
                                   3178 
                                   3179 	.area CSEG (CODE)
                                   3180 ; function ak820_outline_0113
      0093AA                       3181 _ak820_outline_0113:
      0093AA 74 0A            [12] 3182 	mov	a,#0x0a
      0093AC F0               [24] 3183 	movx	@dptr,a
      0093AD E4               [12] 3184 	clr	a
      0093AE A3               [24] 3185 	inc	dptr
      0093AF F0               [24] 3186 	movx	@dptr,a
      0093B0 22               [24] 3187 	ret
                                   3188 
                                   3189 	.area CSEG (CODE)
                                   3190 ; function ak820_outline_0117
      0093B1                       3191 _ak820_outline_0117:
      0093B1 AD 82            [24] 3192 	mov	r5,dpl
      0093B3 AE 83            [24] 3193 	mov	r6,dph
      0093B5 AF F0            [24] 3194 	mov	r7,b
      0093B7 22               [24] 3195 	ret
                                   3196 
                                   3197 	.area CSEG (CODE)
                                   3198 ; function ak820_outline_0131
      0093B8                       3199 _ak820_outline_0131:
      0093B8 28               [12] 3200 	add	a,r0
      0093B9 F5 82            [12] 3201 	mov	dpl,a
      0093BB EF               [12] 3202 	mov	a,r7
      0093BC 39               [12] 3203 	addc	a,r1
      0093BD F5 83            [12] 3204 	mov	dph,a
      0093BF 74 FF            [12] 3205 	mov	a,#0xff
      0093C1 F0               [24] 3206 	movx	@dptr,a
      0093C2 22               [24] 3207 	ret
                                   3208 
                                   3209 	.area CSEG (CODE)
                                   3210 ; function ak820_outline_0138
      0093C3                       3211 _ak820_outline_0138:
      0093C3 2D               [12] 3212 	add	a,r5
      0093C4 F9               [12] 3213 	mov	r1,a
      0093C5 E4               [12] 3214 	clr	a
      0093C6 3E               [12] 3215 	addc	a,r6
      0093C7 FA               [12] 3216 	mov	r2,a
      0093C8 22               [24] 3217 	ret
                                   3218 
                                   3219 	.area CSEG (CODE)
                                   3220 ; function ak820_outline_0153
      0093C9                       3221 _ak820_outline_0153:
      0093C9 90 0C 15         [24] 3222 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_487+0x0002)
      0093CC E0               [24] 3223 	movx	a,@dptr
      0093CD F5 82            [12] 3224 	mov	dpl,a
      0093CF 22               [24] 3225 	ret
                                   3226 
                                   3227 	.area CSEG (CODE)
                                   3228 ; function ak820_outline_0167
      0093D0                       3229 _ak820_outline_0167:
      0093D0 90 0A 46         [24] 3230 	mov	dptr,#_ak820_macro_primitive
      0093D3 E4               [12] 3231 	clr	a
      0093D4 F0               [24] 3232 	movx	@dptr,a
      0093D5 22               [24] 3233 	ret
                                   3234 
                                   3235 	.area CSEG (CODE)
                                   3236 ; function ak820_outline_0179
      0093D6                       3237 _ak820_outline_0179:
      0093D6 90 0B A8         [24] 3238 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      0093D9 E4               [12] 3239 	clr	a
      0093DA F0               [24] 3240 	movx	@dptr,a
      0093DB 90 0B A9         [24] 3241 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      0093DE 22               [24] 3242 	ret
                                   3243 
                                   3244 	.area CSEG (CODE)
                                   3245 ; function ak820_outline_0180
      0093DF                       3246 _ak820_outline_0180:
      0093DF 90 0C 70         [24] 3247 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_2
      0093E2 E4               [12] 3248 	clr	a
      0093E3 F0               [24] 3249 	movx	@dptr,a
      0093E4 90 0C 71         [24] 3250 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_3
      0093E7 22               [24] 3251 	ret
                                   3252 
                                   3253 	.area CSEG (CODE)
                                   3254 ; function ak820_outline_0183
      0093E8                       3255 _ak820_outline_0183:
      0093E8 AF 82            [24] 3256 	mov	r7,dpl
      0093EA 90 0C 15         [24] 3257 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_487+0x0002)
      0093ED EF               [12] 3258 	mov	a,r7
      0093EE F0               [24] 3259 	movx	@dptr,a
      0093EF EF               [12] 3260 	mov	a,r7
      0093F0 22               [24] 3261 	ret
