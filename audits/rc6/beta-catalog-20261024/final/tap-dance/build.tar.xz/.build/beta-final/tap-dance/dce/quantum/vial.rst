                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module vial
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _unregister_code16
                                     12 	.globl _register_code16
                                     13 	.globl _matrix_is_on
                                     14 	.globl _dynamic_keymap_set_combo
                                     15 	.globl _dynamic_keymap_get_combo
                                     16 	.globl _dynamic_keymap_set_tap_dance
                                     17 	.globl _dynamic_keymap_get_tap_dance
                                     18 	.globl _dynamic_keymap_set_encoder
                                     19 	.globl _dynamic_keymap_get_encoder
                                     20 	.globl _repeat_key_cancel
                                     21 	.globl _ak820_combo_reload
                                     22 	.globl _clear_keyboard
                                     23 	.globl _ak820_action_exec
                                     24 	.globl _timer_elapsed32
                                     25 	.globl _timer_read32
                                     26 	.globl _timer_read
                                     27 	.globl ___memcpy
                                     28 	.globl _ADC_START
                                     29 	.globl _S0_R_FIFO
                                     30 	.globl _S0_T_FIFO
                                     31 	.globl _S0_FREE
                                     32 	.globl _S0_IF_BYTE
                                     33 	.globl _S0_IF_FIRST
                                     34 	.globl _S0_IF_OV
                                     35 	.globl _S0_FST_ACT
                                     36 	.globl _CP_RL2
                                     37 	.globl _C_T2
                                     38 	.globl _TR2
                                     39 	.globl _EXEN2
                                     40 	.globl _TCLK
                                     41 	.globl _RCLK
                                     42 	.globl _EXF2
                                     43 	.globl _CAP1F
                                     44 	.globl _TF2
                                     45 	.globl _RI
                                     46 	.globl _TI
                                     47 	.globl _RB8
                                     48 	.globl _TB8
                                     49 	.globl _REN
                                     50 	.globl _SM2
                                     51 	.globl _SM1
                                     52 	.globl _SM0
                                     53 	.globl _IT0
                                     54 	.globl _IE0
                                     55 	.globl _IT1
                                     56 	.globl _IE1
                                     57 	.globl _TR0
                                     58 	.globl _TF0
                                     59 	.globl _TR1
                                     60 	.globl _TF1
                                     61 	.globl _P4_0
                                     62 	.globl _P4_1
                                     63 	.globl _P4_2
                                     64 	.globl _P4_3
                                     65 	.globl _P4_4
                                     66 	.globl _P4_5
                                     67 	.globl _P4_6
                                     68 	.globl _RXD
                                     69 	.globl _TXD
                                     70 	.globl _INT0
                                     71 	.globl _INT1
                                     72 	.globl _T0
                                     73 	.globl _T1
                                     74 	.globl _MOSI1
                                     75 	.globl _MISO1
                                     76 	.globl _SCK1
                                     77 	.globl _P3_0
                                     78 	.globl _P3_1
                                     79 	.globl _P3_2
                                     80 	.globl _P3_3
                                     81 	.globl _P3_4
                                     82 	.globl _P3_5
                                     83 	.globl _P3_6
                                     84 	.globl _P3_7
                                     85 	.globl _CAP1_
                                     86 	.globl _T2_
                                     87 	.globl _CAP2_
                                     88 	.globl _T2EX_
                                     89 	.globl _RXD1
                                     90 	.globl _TXD1
                                     91 	.globl _P2_0
                                     92 	.globl _P2_1
                                     93 	.globl _P2_2
                                     94 	.globl _P2_3
                                     95 	.globl _P2_4
                                     96 	.globl _P2_5
                                     97 	.globl _P2_6
                                     98 	.globl _P2_7
                                     99 	.globl _AIN0
                                    100 	.globl _AIN1
                                    101 	.globl _AIN2
                                    102 	.globl _AIN3
                                    103 	.globl _AIN4
                                    104 	.globl _AIN5
                                    105 	.globl _AIN6
                                    106 	.globl _AIN7
                                    107 	.globl _CAP1
                                    108 	.globl _T2
                                    109 	.globl _CAP2
                                    110 	.globl _T2EX
                                    111 	.globl _INT0_
                                    112 	.globl _SCS
                                    113 	.globl _MOSI
                                    114 	.globl _MISO
                                    115 	.globl _SCK
                                    116 	.globl _RXD1_
                                    117 	.globl _TXD1_
                                    118 	.globl _P1_0
                                    119 	.globl _P1_1
                                    120 	.globl _P1_2
                                    121 	.globl _P1_3
                                    122 	.globl _P1_4
                                    123 	.globl _P1_5
                                    124 	.globl _P1_6
                                    125 	.globl _P1_7
                                    126 	.globl _AIN8
                                    127 	.globl _AIN9
                                    128 	.globl _AIN10
                                    129 	.globl _AIN11
                                    130 	.globl _AIN12
                                    131 	.globl _AIN13
                                    132 	.globl _RXD_
                                    133 	.globl _TXD_
                                    134 	.globl _SCL0
                                    135 	.globl _SDA0
                                    136 	.globl _P0_0
                                    137 	.globl _P0_1
                                    138 	.globl _P0_2
                                    139 	.globl _P0_3
                                    140 	.globl _P0_4
                                    141 	.globl _P0_5
                                    142 	.globl _P0_6
                                    143 	.globl _P0_7
                                    144 	.globl _IE_SPI0
                                    145 	.globl _IE_USB
                                    146 	.globl _IE_ADC
                                    147 	.globl _IE_UART1
                                    148 	.globl _IE_PWM_I2C
                                    149 	.globl _IE_GPIO
                                    150 	.globl _IE_WDOG
                                    151 	.globl _PX0
                                    152 	.globl _PT0
                                    153 	.globl _PX1
                                    154 	.globl _PT1
                                    155 	.globl _PS
                                    156 	.globl _PT2
                                    157 	.globl _PL_FLAG
                                    158 	.globl _PH_FLAG
                                    159 	.globl _EX0
                                    160 	.globl _ET0
                                    161 	.globl _EX1
                                    162 	.globl _ET1
                                    163 	.globl _ES
                                    164 	.globl _ET2
                                    165 	.globl _E_DIS
                                    166 	.globl _EA
                                    167 	.globl _P
                                    168 	.globl _F1
                                    169 	.globl _OV
                                    170 	.globl _RS0
                                    171 	.globl _RS1
                                    172 	.globl _F0
                                    173 	.globl _AC
                                    174 	.globl _CY
                                    175 	.globl _I2CS_INT_ST
                                    176 	.globl _I2CX_INT
                                    177 	.globl _LED_STATUS
                                    178 	.globl _LED_DMA_H
                                    179 	.globl _LED_DMA_L
                                    180 	.globl _LED_DMA
                                    181 	.globl _LED_PWM_OE
                                    182 	.globl _LED_COMMON
                                    183 	.globl _ADC_CHAN
                                    184 	.globl _ADC_DAT_H
                                    185 	.globl _ADC_DAT_L
                                    186 	.globl _ADC_DAT
                                    187 	.globl _ADC_CTRL
                                    188 	.globl _SPI1_CK_SE
                                    189 	.globl _SPI1_CTRL
                                    190 	.globl _SPI1_DATA
                                    191 	.globl _SPI1_STAT
                                    192 	.globl _SIF1
                                    193 	.globl _SBAUD1
                                    194 	.globl _SBUF1
                                    195 	.globl _SCON1
                                    196 	.globl _SPI0_SETUP
                                    197 	.globl _SPI0_CK_SE
                                    198 	.globl _SPI0_CTRL
                                    199 	.globl _SPI0_DATA
                                    200 	.globl _SPI0_STAT
                                    201 	.globl _T2CAP1H
                                    202 	.globl _T2CAP1L
                                    203 	.globl _T2CAP1
                                    204 	.globl _TH2
                                    205 	.globl _TL2
                                    206 	.globl _T2COUNT
                                    207 	.globl _RCAP2H
                                    208 	.globl _RCAP2L
                                    209 	.globl _RCAP2
                                    210 	.globl _T2MOD
                                    211 	.globl _T2CON
                                    212 	.globl _SBUF
                                    213 	.globl _SCON
                                    214 	.globl _TH1
                                    215 	.globl _TH0
                                    216 	.globl _TL1
                                    217 	.globl _TL0
                                    218 	.globl _TMOD
                                    219 	.globl _TCON
                                    220 	.globl _XBUS_AUX
                                    221 	.globl _P7
                                    222 	.globl _P6_DIR
                                    223 	.globl _P6_OUT_PU
                                    224 	.globl _P6_IN
                                    225 	.globl _P5_DIR
                                    226 	.globl _P5_OUT_PU
                                    227 	.globl _P5_IN
                                    228 	.globl _P4_LED_KEY
                                    229 	.globl _P4_DIR_PU
                                    230 	.globl _P4_MOD_OC
                                    231 	.globl _P4
                                    232 	.globl _P3_DIR_PU
                                    233 	.globl _P3_MOD_OC
                                    234 	.globl _P3
                                    235 	.globl _P2_DIR_PU
                                    236 	.globl _P2_MOD_OC
                                    237 	.globl _P2
                                    238 	.globl _P1_DIR_PU
                                    239 	.globl _P1_MOD_OC
                                    240 	.globl _P1
                                    241 	.globl _P0_DIR_PU
                                    242 	.globl _P0_MOD_OC
                                    243 	.globl _P0
                                    244 	.globl _ROM_CTRL
                                    245 	.globl _ROM_DATA_HH
                                    246 	.globl _ROM_DATA_HL
                                    247 	.globl _ROM_DATA_HI
                                    248 	.globl _ROM_ADDR_H
                                    249 	.globl _ROM_ADDR_L
                                    250 	.globl _ROM_ADDR
                                    251 	.globl _GPIO_IE
                                    252 	.globl _IP_EX
                                    253 	.globl _IE_EX
                                    254 	.globl _IP
                                    255 	.globl _IE
                                    256 	.globl _WDOG_COUNT
                                    257 	.globl _RESET_KEEP
                                    258 	.globl _WAKE_CTRL
                                    259 	.globl _CLOCK_CFG
                                    260 	.globl _POWER_CFG
                                    261 	.globl _PCON
                                    262 	.globl _GLOBAL_CFG
                                    263 	.globl _SAFE_MOD
                                    264 	.globl _DPH
                                    265 	.globl _DPL
                                    266 	.globl _SP
                                    267 	.globl _A_INV
                                    268 	.globl _B
                                    269 	.globl _ACC
                                    270 	.globl _PSW
                                    271 	.globl _vial_unlock_in_progress
                                    272 	.globl _vial_unlocked
                                    273 	.globl _g_vial_magic_keycode_override
                                    274 	.globl _vial_handle_cmd_PARM_2
                                    275 	.globl _vial_unlock_task
                                    276 	.globl _vial_init
                                    277 	.globl _vial_handle_cmd
                                    278 	.globl _vial_keycode_down
                                    279 	.globl _vial_keycode_up
                                    280 	.globl _vial_keycode_tap
                                    281 ;--------------------------------------------------------
                                    282 ; special function registers
                                    283 ;--------------------------------------------------------
                                    284 	.area RSEG    (ABS,DATA)
      000000                        285 	.org 0x0000
                           0000D0   286 _PSW	=	0x00d0
                           0000E0   287 _ACC	=	0x00e0
                           0000F0   288 _B	=	0x00f0
                           0000FD   289 _A_INV	=	0x00fd
                           000081   290 _SP	=	0x0081
                           000082   291 _DPL	=	0x0082
                           000083   292 _DPH	=	0x0083
                           0000A1   293 _SAFE_MOD	=	0x00a1
                           0000B1   294 _GLOBAL_CFG	=	0x00b1
                           000087   295 _PCON	=	0x0087
                           0000BA   296 _POWER_CFG	=	0x00ba
                           0000B9   297 _CLOCK_CFG	=	0x00b9
                           0000A9   298 _WAKE_CTRL	=	0x00a9
                           0000FE   299 _RESET_KEEP	=	0x00fe
                           0000FF   300 _WDOG_COUNT	=	0x00ff
                           0000A8   301 _IE	=	0x00a8
                           0000B8   302 _IP	=	0x00b8
                           0000E8   303 _IE_EX	=	0x00e8
                           0000E9   304 _IP_EX	=	0x00e9
                           0000B2   305 _GPIO_IE	=	0x00b2
                           008584   306 _ROM_ADDR	=	0x8584
                           000084   307 _ROM_ADDR_L	=	0x0084
                           000085   308 _ROM_ADDR_H	=	0x0085
                           008F8E   309 _ROM_DATA_HI	=	0x8f8e
                           00008E   310 _ROM_DATA_HL	=	0x008e
                           00008F   311 _ROM_DATA_HH	=	0x008f
                           000086   312 _ROM_CTRL	=	0x0086
                           000080   313 _P0	=	0x0080
                           0000C4   314 _P0_MOD_OC	=	0x00c4
                           0000C5   315 _P0_DIR_PU	=	0x00c5
                           000090   316 _P1	=	0x0090
                           000092   317 _P1_MOD_OC	=	0x0092
                           000093   318 _P1_DIR_PU	=	0x0093
                           0000A0   319 _P2	=	0x00a0
                           000094   320 _P2_MOD_OC	=	0x0094
                           000095   321 _P2_DIR_PU	=	0x0095
                           0000B0   322 _P3	=	0x00b0
                           000096   323 _P3_MOD_OC	=	0x0096
                           000097   324 _P3_DIR_PU	=	0x0097
                           0000C0   325 _P4	=	0x00c0
                           0000C2   326 _P4_MOD_OC	=	0x00c2
                           0000C3   327 _P4_DIR_PU	=	0x00c3
                           0000C1   328 _P4_LED_KEY	=	0x00c1
                           0000AA   329 _P5_IN	=	0x00aa
                           0000AB   330 _P5_OUT_PU	=	0x00ab
                           0000AC   331 _P5_DIR	=	0x00ac
                           0000AD   332 _P6_IN	=	0x00ad
                           0000AE   333 _P6_OUT_PU	=	0x00ae
                           0000AF   334 _P6_DIR	=	0x00af
                           0000F1   335 _P7	=	0x00f1
                           0000A2   336 _XBUS_AUX	=	0x00a2
                           000088   337 _TCON	=	0x0088
                           000089   338 _TMOD	=	0x0089
                           00008A   339 _TL0	=	0x008a
                           00008B   340 _TL1	=	0x008b
                           00008C   341 _TH0	=	0x008c
                           00008D   342 _TH1	=	0x008d
                           000098   343 _SCON	=	0x0098
                           000099   344 _SBUF	=	0x0099
                           0000C8   345 _T2CON	=	0x00c8
                           0000C9   346 _T2MOD	=	0x00c9
                           00CBCA   347 _RCAP2	=	0xcbca
                           0000CA   348 _RCAP2L	=	0x00ca
                           0000CB   349 _RCAP2H	=	0x00cb
                           00CDCC   350 _T2COUNT	=	0xcdcc
                           0000CC   351 _TL2	=	0x00cc
                           0000CD   352 _TH2	=	0x00cd
                           00CFCE   353 _T2CAP1	=	0xcfce
                           0000CE   354 _T2CAP1L	=	0x00ce
                           0000CF   355 _T2CAP1H	=	0x00cf
                           0000F8   356 _SPI0_STAT	=	0x00f8
                           0000F9   357 _SPI0_DATA	=	0x00f9
                           0000FA   358 _SPI0_CTRL	=	0x00fa
                           0000FB   359 _SPI0_CK_SE	=	0x00fb
                           0000FC   360 _SPI0_SETUP	=	0x00fc
                           0000BC   361 _SCON1	=	0x00bc
                           0000BD   362 _SBUF1	=	0x00bd
                           0000BE   363 _SBAUD1	=	0x00be
                           0000BF   364 _SIF1	=	0x00bf
                           0000B4   365 _SPI1_STAT	=	0x00b4
                           0000B5   366 _SPI1_DATA	=	0x00b5
                           0000B6   367 _SPI1_CTRL	=	0x00b6
                           0000B7   368 _SPI1_CK_SE	=	0x00b7
                           0000F3   369 _ADC_CTRL	=	0x00f3
                           00F5F4   370 _ADC_DAT	=	0xf5f4
                           0000F4   371 _ADC_DAT_L	=	0x00f4
                           0000F5   372 _ADC_DAT_H	=	0x00f5
                           0000F6   373 _ADC_CHAN	=	0x00f6
                           0000A6   374 _LED_COMMON	=	0x00a6
                           0000A7   375 _LED_PWM_OE	=	0x00a7
                           00C7C6   376 _LED_DMA	=	0xc7c6
                           0000C6   377 _LED_DMA_L	=	0x00c6
                           0000C7   378 _LED_DMA_H	=	0x00c7
                           0000F7   379 _LED_STATUS	=	0x00f7
                           0000B3   380 _I2CX_INT	=	0x00b3
                           0000BB   381 _I2CS_INT_ST	=	0x00bb
                                    382 ;--------------------------------------------------------
                                    383 ; special function bits
                                    384 ;--------------------------------------------------------
                                    385 	.area RSEG    (ABS,DATA)
      000000                        386 	.org 0x0000
                           0000D7   387 _CY	=	0x00d7
                           0000D6   388 _AC	=	0x00d6
                           0000D5   389 _F0	=	0x00d5
                           0000D4   390 _RS1	=	0x00d4
                           0000D3   391 _RS0	=	0x00d3
                           0000D2   392 _OV	=	0x00d2
                           0000D1   393 _F1	=	0x00d1
                           0000D0   394 _P	=	0x00d0
                           0000AF   395 _EA	=	0x00af
                           0000AE   396 _E_DIS	=	0x00ae
                           0000AD   397 _ET2	=	0x00ad
                           0000AC   398 _ES	=	0x00ac
                           0000AB   399 _ET1	=	0x00ab
                           0000AA   400 _EX1	=	0x00aa
                           0000A9   401 _ET0	=	0x00a9
                           0000A8   402 _EX0	=	0x00a8
                           0000BF   403 _PH_FLAG	=	0x00bf
                           0000BE   404 _PL_FLAG	=	0x00be
                           0000BD   405 _PT2	=	0x00bd
                           0000BC   406 _PS	=	0x00bc
                           0000BB   407 _PT1	=	0x00bb
                           0000BA   408 _PX1	=	0x00ba
                           0000B9   409 _PT0	=	0x00b9
                           0000B8   410 _PX0	=	0x00b8
                           0000EF   411 _IE_WDOG	=	0x00ef
                           0000EE   412 _IE_GPIO	=	0x00ee
                           0000ED   413 _IE_PWM_I2C	=	0x00ed
                           0000EC   414 _IE_UART1	=	0x00ec
                           0000EB   415 _IE_ADC	=	0x00eb
                           0000E9   416 _IE_USB	=	0x00e9
                           0000E8   417 _IE_SPI0	=	0x00e8
                           000087   418 _P0_7	=	0x0087
                           000086   419 _P0_6	=	0x0086
                           000085   420 _P0_5	=	0x0085
                           000084   421 _P0_4	=	0x0084
                           000083   422 _P0_3	=	0x0083
                           000082   423 _P0_2	=	0x0082
                           000081   424 _P0_1	=	0x0081
                           000080   425 _P0_0	=	0x0080
                           000081   426 _SDA0	=	0x0081
                           000080   427 _SCL0	=	0x0080
                           000083   428 _TXD_	=	0x0083
                           000082   429 _RXD_	=	0x0082
                           000085   430 _AIN13	=	0x0085
                           000084   431 _AIN12	=	0x0084
                           000083   432 _AIN11	=	0x0083
                           000082   433 _AIN10	=	0x0082
                           000081   434 _AIN9	=	0x0081
                           000080   435 _AIN8	=	0x0080
                           000097   436 _P1_7	=	0x0097
                           000096   437 _P1_6	=	0x0096
                           000095   438 _P1_5	=	0x0095
                           000094   439 _P1_4	=	0x0094
                           000093   440 _P1_3	=	0x0093
                           000092   441 _P1_2	=	0x0092
                           000091   442 _P1_1	=	0x0091
                           000090   443 _P1_0	=	0x0090
                           000097   444 _TXD1_	=	0x0097
                           000096   445 _RXD1_	=	0x0096
                           000097   446 _SCK	=	0x0097
                           000096   447 _MISO	=	0x0096
                           000095   448 _MOSI	=	0x0095
                           000094   449 _SCS	=	0x0094
                           000092   450 _INT0_	=	0x0092
                           000091   451 _T2EX	=	0x0091
                           000091   452 _CAP2	=	0x0091
                           000090   453 _T2	=	0x0090
                           000090   454 _CAP1	=	0x0090
                           000097   455 _AIN7	=	0x0097
                           000096   456 _AIN6	=	0x0096
                           000095   457 _AIN5	=	0x0095
                           000094   458 _AIN4	=	0x0094
                           000093   459 _AIN3	=	0x0093
                           000092   460 _AIN2	=	0x0092
                           000091   461 _AIN1	=	0x0091
                           000090   462 _AIN0	=	0x0090
                           0000A7   463 _P2_7	=	0x00a7
                           0000A6   464 _P2_6	=	0x00a6
                           0000A5   465 _P2_5	=	0x00a5
                           0000A4   466 _P2_4	=	0x00a4
                           0000A3   467 _P2_3	=	0x00a3
                           0000A2   468 _P2_2	=	0x00a2
                           0000A1   469 _P2_1	=	0x00a1
                           0000A0   470 _P2_0	=	0x00a0
                           0000A7   471 _TXD1	=	0x00a7
                           0000A6   472 _RXD1	=	0x00a6
                           0000A5   473 _T2EX_	=	0x00a5
                           0000A5   474 _CAP2_	=	0x00a5
                           0000A4   475 _T2_	=	0x00a4
                           0000A4   476 _CAP1_	=	0x00a4
                           0000B7   477 _P3_7	=	0x00b7
                           0000B6   478 _P3_6	=	0x00b6
                           0000B5   479 _P3_5	=	0x00b5
                           0000B4   480 _P3_4	=	0x00b4
                           0000B3   481 _P3_3	=	0x00b3
                           0000B2   482 _P3_2	=	0x00b2
                           0000B1   483 _P3_1	=	0x00b1
                           0000B0   484 _P3_0	=	0x00b0
                           0000B7   485 _SCK1	=	0x00b7
                           0000B6   486 _MISO1	=	0x00b6
                           0000B5   487 _MOSI1	=	0x00b5
                           0000B5   488 _T1	=	0x00b5
                           0000B4   489 _T0	=	0x00b4
                           0000B3   490 _INT1	=	0x00b3
                           0000B2   491 _INT0	=	0x00b2
                           0000B1   492 _TXD	=	0x00b1
                           0000B0   493 _RXD	=	0x00b0
                           0000C6   494 _P4_6	=	0x00c6
                           0000C5   495 _P4_5	=	0x00c5
                           0000C4   496 _P4_4	=	0x00c4
                           0000C3   497 _P4_3	=	0x00c3
                           0000C2   498 _P4_2	=	0x00c2
                           0000C1   499 _P4_1	=	0x00c1
                           0000C0   500 _P4_0	=	0x00c0
                           00008F   501 _TF1	=	0x008f
                           00008E   502 _TR1	=	0x008e
                           00008D   503 _TF0	=	0x008d
                           00008C   504 _TR0	=	0x008c
                           00008B   505 _IE1	=	0x008b
                           00008A   506 _IT1	=	0x008a
                           000089   507 _IE0	=	0x0089
                           000088   508 _IT0	=	0x0088
                           00009F   509 _SM0	=	0x009f
                           00009E   510 _SM1	=	0x009e
                           00009D   511 _SM2	=	0x009d
                           00009C   512 _REN	=	0x009c
                           00009B   513 _TB8	=	0x009b
                           00009A   514 _RB8	=	0x009a
                           000099   515 _TI	=	0x0099
                           000098   516 _RI	=	0x0098
                           0000CF   517 _TF2	=	0x00cf
                           0000CF   518 _CAP1F	=	0x00cf
                           0000CE   519 _EXF2	=	0x00ce
                           0000CD   520 _RCLK	=	0x00cd
                           0000CC   521 _TCLK	=	0x00cc
                           0000CB   522 _EXEN2	=	0x00cb
                           0000CA   523 _TR2	=	0x00ca
                           0000C9   524 _C_T2	=	0x00c9
                           0000C8   525 _CP_RL2	=	0x00c8
                           0000FF   526 _S0_FST_ACT	=	0x00ff
                           0000FE   527 _S0_IF_OV	=	0x00fe
                           0000FD   528 _S0_IF_FIRST	=	0x00fd
                           0000FC   529 _S0_IF_BYTE	=	0x00fc
                           0000FB   530 _S0_FREE	=	0x00fb
                           0000FA   531 _S0_T_FIFO	=	0x00fa
                           0000F8   532 _S0_R_FIFO	=	0x00f8
                           0000F7   533 _ADC_START	=	0x00f7
                                    534 ;--------------------------------------------------------
                                    535 ; overlayable register banks
                                    536 ;--------------------------------------------------------
                                    537 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        538 	.ds 8
                                    539 ;--------------------------------------------------------
                                    540 ; internal ram data
                                    541 ;--------------------------------------------------------
                                    542 	.area DSEG    (DATA)
      000042                        543 _vial_handle_cmd_sloc0_1_0:
      000042                        544 	.ds 2
      000044                        545 _vial_handle_cmd_sloc1_1_0:
      000044                        546 	.ds 2
      000046                        547 _vial_handle_cmd_sloc2_1_0:
      000046                        548 	.ds 2
      000048                        549 _vial_handle_cmd_sloc3_1_0:
      000048                        550 	.ds 2
                                    551 ;--------------------------------------------------------
                                    552 ; overlayable items in internal ram
                                    553 ;--------------------------------------------------------
                                    554 ;--------------------------------------------------------
                                    555 ; indirectly addressable internal ram data
                                    556 ;--------------------------------------------------------
                                    557 	.area ISEG    (DATA)
                                    558 ;--------------------------------------------------------
                                    559 ; absolute internal ram data
                                    560 ;--------------------------------------------------------
                                    561 	.area IABS    (ABS,DATA)
                                    562 	.area IABS    (ABS,DATA)
                                    563 ;--------------------------------------------------------
                                    564 ; bit data
                                    565 ;--------------------------------------------------------
                                    566 	.area BSEG    (BIT)
                                    567 ;--------------------------------------------------------
                                    568 ; paged external ram data
                                    569 ;--------------------------------------------------------
                                    570 	.area PSEG    (PAG,XDATA)
                                    571 ;--------------------------------------------------------
                                    572 ; uninitialized external ram data
                                    573 ;--------------------------------------------------------
                                    574 	.area XSEG    (XDATA)
      000D02                        575 _vial_unlock_timer:
      000D02                        576 	.ds 4
      000D06                        577 _vial_unlock_holding:
      000D06                        578 	.ds 1
      000D07                        579 _vial_keycode_firewall_in_10000_611:
      000D07                        580 	.ds 2
      000D09                        581 _vial_fill_packet_PARM_2:
      000D09                        582 	.ds 1
      000D0A                        583 _vial_fill_packet_msg_10000_614:
      000D0A                        584 	.ds 2
      000D0C                        585 _vial_handle_cmd_PARM_2:
      000D0C                        586 	.ds 1
      000D0D                        587 _vial_handle_cmd_data_10000_619:
      000D0D                        588 	.ds 3
      000D10                        589 _vial_handle_cmd_td_70000_647:
      000D10                        590 	.ds 10
      000D1A                        591 _vial_handle_cmd_td_70000_648:
      000D1A                        592 	.ds 10
      000D24                        593 _vial_handle_cmd_entry_70000_649:
      000D24                        594 	.ds 10
      000D2E                        595 _vial_handle_cmd_entry_70000_650:
      000D2E                        596 	.ds 10
      000D38                        597 _g_vial_magic_keycode_override::
      000D38                        598 	.ds 2
      000D3A                        599 _vial_keycode_down_keycode_10000_652:
      000D3A                        600 	.ds 2
      000D3C                        601 _vial_keycode_down_dummy_event_30000_659:
      000D3C                        602 	.ds 6
      000D42                        603 _vial_keycode_up_keycode_10000_660:
      000D42                        604 	.ds 2
      000D44                        605 _vial_keycode_up_dummy_event_30000_667:
      000D44                        606 	.ds 6
      000D4A                        607 _vial_keycode_tap_keycode_10000_668:
      000D4A                        608 	.ds 2
                                    609 ;--------------------------------------------------------
                                    610 ; absolute external ram data
                                    611 ;--------------------------------------------------------
                                    612 	.area XABS    (ABS,XDATA)
                                    613 ;--------------------------------------------------------
                                    614 ; initialized external ram data
                                    615 ;--------------------------------------------------------
                                    616 	.area XISEG   (XDATA)
      000EE0                        617 _vial_unlocked::
      000EE0                        618 	.ds 1
      000EE1                        619 _vial_unlock_in_progress::
      000EE1                        620 	.ds 1
      000EE2                        621 _vial_unlock_counter:
      000EE2                        622 	.ds 1
      000EE3                        623 _vial_unlock_combo_rows:
      000EE3                        624 	.ds 2
      000EE5                        625 _vial_unlock_combo_cols:
      000EE5                        626 	.ds 2
                                    627 	.area HOME    (CODE)
                                    628 	.area GSINIT0 (CODE)
                                    629 	.area GSINIT1 (CODE)
                                    630 	.area GSINIT2 (CODE)
                                    631 	.area GSINIT3 (CODE)
                                    632 	.area GSINIT4 (CODE)
                                    633 	.area GSINIT5 (CODE)
                                    634 	.area GSINIT  (CODE)
                                    635 	.area GSFINAL (CODE)
                                    636 	.area CSEG    (CODE)
                                    637 ;--------------------------------------------------------
                                    638 ; global & static initialisations
                                    639 ;--------------------------------------------------------
                                    640 	.area HOME    (CODE)
                                    641 	.area GSINIT  (CODE)
                                    642 	.area GSFINAL (CODE)
                                    643 	.area GSINIT  (CODE)
                                    644 ;--------------------------------------------------------
                                    645 ; Home
                                    646 ;--------------------------------------------------------
                                    647 	.area HOME    (CODE)
                                    648 	.area HOME    (CODE)
                                    649 ;--------------------------------------------------------
                                    650 ; code
                                    651 ;--------------------------------------------------------
                                    652 	.area CSEG    (CODE)
                                    653 ;------------------------------------------------------------
                                    654 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    655 ;------------------------------------------------------------
                                    656 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_176'
                                    657 ;------------------------------------------------------------
                                    658 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    659 ;	-----------------------------------------
                           000007   660 	ar7 = 0x07
                           000006   661 	ar6 = 0x06
                           000005   662 	ar5 = 0x05
                           000004   663 	ar4 = 0x04
                           000003   664 	ar3 = 0x03
                           000002   665 	ar2 = 0x02
                           000001   666 	ar1 = 0x01
                           000000   667 	ar0 = 0x00
                                    668 ;	 function vial_unlock_task
                                    669 ;	-----------------------------------------
      00B079                        670 _vial_unlock_task:
                                    671 ;	quantum/vial.c:64: if (!vial_unlock_in_progress) return;
      00B079 90 0E E1         [24]  672 	mov	dptr,#_vial_unlock_in_progress
      00B07C E0               [24]  673 	movx	a,@dptr
      00B07D 70 01            [24]  674 	jnz	00131$
      00B07F 22               [24]  675 	ret
                                    676 ;	quantum/vial.c:65: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B080                        677 00131$:
      00B080 7F 00            [12]  678 	mov	r7,#0x00
      00B082                        679 00115$:
      00B082 BF 02 00         [24]  680 	cjne	r7,#0x02,00184$
      00B085                        681 00184$:
      00B085 50 29            [24]  682 	jnc	00105$
                                    683 ;	quantum/vial.c:66: if (!matrix_is_on(vial_unlock_combo_rows[i], vial_unlock_combo_cols[i])) {
      00B087 EF               [12]  684 	mov	a,r7
      00B088 12 B6 EB         [24]  685 	lcall	_ak820_outline_0130
      00B08B FE               [12]  686 	mov	r6,a
      00B08C EF               [12]  687 	mov	a,r7
      00B08D 12 B6 E0         [24]  688 	lcall	_ak820_outline_0129
      00B090 90 08 25         [24]  689 	mov	dptr,#_matrix_is_on_PARM_2
      00B093 F0               [24]  690 	movx	@dptr,a
      00B094 8E 82            [24]  691 	mov	dpl, r6
      00B096 C0 07            [24]  692 	push	ar7
      00B098 12 5E 17         [24]  693 	lcall	_matrix_is_on
      00B09B E5 82            [12]  694 	mov	a, dpl
      00B09D D0 07            [24]  695 	pop	ar7
      00B09F 70 0C            [24]  696 	jnz	00116$
                                    697 ;	quantum/vial.c:67: vial_unlock_holding = false;
      00B0A1 90 0D 06         [24]  698 	mov	dptr,#_vial_unlock_holding
      00B0A4 E4               [12]  699 	clr	a
      00B0A5 F0               [24]  700 	movx	@dptr,a
                                    701 ;	quantum/vial.c:68: vial_unlock_counter = VIAL_UNLOCK_COUNTER_MAX;
      00B0A6 90 0E E2         [24]  702 	mov	dptr,#_vial_unlock_counter
      00B0A9 74 1E            [12]  703 	mov	a,#0x1e
      00B0AB F0               [24]  704 	movx	@dptr,a
                                    705 ;	quantum/vial.c:69: return;
      00B0AC 22               [24]  706 	ret
      00B0AD                        707 00116$:
                                    708 ;	quantum/vial.c:65: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B0AD 0F               [12]  709 	inc	r7
      00B0AE 80 D2            [24]  710 	sjmp	00115$
      00B0B0                        711 00105$:
                                    712 ;	quantum/vial.c:72: if (!vial_unlock_holding) {
      00B0B0 90 0D 06         [24]  713 	mov	dptr,#_vial_unlock_holding
      00B0B3 E0               [24]  714 	movx	a,@dptr
      00B0B4 70 12            [24]  715 	jnz	00107$
                                    716 ;	quantum/vial.c:73: vial_unlock_holding = true;
      00B0B6 90 0D 06         [24]  717 	mov	dptr,#_vial_unlock_holding
      00B0B9 74 01            [12]  718 	mov	a,#0x01
      00B0BB F0               [24]  719 	movx	@dptr,a
                                    720 ;	quantum/vial.c:74: vial_unlock_timer = timer_read32();
      00B0BC 12 4E 0F         [24]  721 	lcall	_timer_read32
      00B0BF 12 54 20         [24]  722 	lcall	_ak820_outline_0061
      00B0C2 90 0D 02         [24]  723 	mov	dptr,#_vial_unlock_timer
      00B0C5 12 95 66         [24]  724 	lcall	_ak820_outline_0009
      00B0C8                        725 00107$:
                                    726 ;	quantum/vial.c:76: uint32_t elapsed = timer_elapsed32(vial_unlock_timer);
      00B0C8 90 0D 02         [24]  727 	mov	dptr,#_vial_unlock_timer
      00B0CB 12 54 0F         [24]  728 	lcall	_ak820_outline_0059
      00B0CE 12 4E 68         [24]  729 	lcall	_timer_elapsed32
      00B0D1 12 54 20         [24]  730 	lcall	_ak820_outline_0061
                                    731 ;	quantum/vial.c:80: while (counter && elapsed >= VIAL_UNLOCK_COUNTER_TICK_MS) {
      00B0D4 7B 1E            [12]  732 	mov	r3,#0x1e
      00B0D6                        733 00109$:
      00B0D6 EB               [12]  734 	mov	a,r3
      00B0D7 60 22            [24]  735 	jz	00111$
      00B0D9 C3               [12]  736 	clr	c
      00B0DA EC               [12]  737 	mov	a,r4
      00B0DB 94 64            [12]  738 	subb	a,#0x64
      00B0DD ED               [12]  739 	mov	a,r5
      00B0DE 94 00            [12]  740 	subb	a,#0x00
      00B0E0 EE               [12]  741 	mov	a,r6
      00B0E1 94 00            [12]  742 	subb	a,#0x00
      00B0E3 EF               [12]  743 	mov	a,r7
      00B0E4 94 00            [12]  744 	subb	a,#0x00
      00B0E6 40 13            [24]  745 	jc	00111$
                                    746 ;	quantum/vial.c:81: elapsed -= VIAL_UNLOCK_COUNTER_TICK_MS;
      00B0E8 EC               [12]  747 	mov	a,r4
      00B0E9 24 9C            [12]  748 	add	a,#0x9c
      00B0EB FC               [12]  749 	mov	r4,a
      00B0EC ED               [12]  750 	mov	a,r5
      00B0ED 34 FF            [12]  751 	addc	a,#0xff
      00B0EF FD               [12]  752 	mov	r5,a
      00B0F0 EE               [12]  753 	mov	a,r6
      00B0F1 34 FF            [12]  754 	addc	a,#0xff
      00B0F3 FE               [12]  755 	mov	r6,a
      00B0F4 EF               [12]  756 	mov	a,r7
      00B0F5 34 FF            [12]  757 	addc	a,#0xff
      00B0F7 FF               [12]  758 	mov	r7,a
                                    759 ;	quantum/vial.c:82: --counter;
      00B0F8 1B               [12]  760 	dec	r3
      00B0F9 80 DB            [24]  761 	sjmp	00109$
      00B0FB                        762 00111$:
                                    763 ;	quantum/vial.c:84: vial_unlock_counter = counter;
      00B0FB 90 0E E2         [24]  764 	mov	dptr,#_vial_unlock_counter
      00B0FE EB               [12]  765 	mov	a,r3
      00B0FF F0               [24]  766 	movx	@dptr,a
                                    767 ;	quantum/vial.c:85: if (!counter) {
      00B100 EB               [12]  768 	mov	a,r3
      00B101 70 0A            [24]  769 	jnz	00117$
                                    770 ;	quantum/vial.c:86: vial_unlock_in_progress = 0;
      00B103 90 0E E1         [24]  771 	mov	dptr,#_vial_unlock_in_progress
      00B106 E4               [12]  772 	clr	a
      00B107 F0               [24]  773 	movx	@dptr,a
                                    774 ;	quantum/vial.c:87: vial_unlocked = 1;
      00B108 90 0E E0         [24]  775 	mov	dptr,#_vial_unlocked
      00B10B 04               [12]  776 	inc	a
      00B10C F0               [24]  777 	movx	@dptr,a
      00B10D                        778 00117$:
                                    779 ;	quantum/vial.c:90: }
      00B10D 22               [24]  780 	ret
                                    781 ;------------------------------------------------------------
                                    782 ;Allocation info for local variables in function 'vial_init'
                                    783 ;------------------------------------------------------------
                                    784 ;	quantum/vial.c:117: void vial_init(void) {
                                    785 ;	-----------------------------------------
                                    786 ;	 function vial_init
                                    787 ;	-----------------------------------------
      00B10E                        788 _vial_init:
                                    789 ;	quantum/vial.c:125: reload_combo();
                                    790 ;	quantum/vial.c:130: }
      00B10E 02 35 37         [24]  791 	ljmp	_ak820_combo_reload
                                    792 ;------------------------------------------------------------
                                    793 ;Allocation info for local variables in function 'vial_keycode_firewall'
                                    794 ;------------------------------------------------------------
                                    795 ;in            Allocated with name '_vial_keycode_firewall_in_10000_611'
                                    796 ;------------------------------------------------------------
                                    797 ;	quantum/vial.c:132: __attribute__((unused)) static uint16_t vial_keycode_firewall(uint16_t in) {
                                    798 ;	-----------------------------------------
                                    799 ;	 function vial_keycode_firewall
                                    800 ;	-----------------------------------------
      00B111                        801 _vial_keycode_firewall:
      00B111 12 38 4C         [24]  802 	lcall	_ak820_outline_0106
      00B114 90 0D 07         [24]  803 	mov	dptr,#_vial_keycode_firewall_in_10000_611
      00B117 12 38 47         [24]  804 	lcall	_ak820_outline_0105
                                    805 ;	quantum/vial.c:133: if (in == QK_BOOT && !vial_unlocked)
      00B11A 90 0D 07         [24]  806 	mov	dptr,#_vial_keycode_firewall_in_10000_611
      00B11D 12 37 C2         [24]  807 	lcall	_ak820_outline_0010
      00B120 BC 00 0D         [24]  808 	cjne	r4,#0x00,00102$
      00B123 BD 7C 0A         [24]  809 	cjne	r5,#0x7c,00102$
      00B126 90 0E E0         [24]  810 	mov	dptr,#_vial_unlocked
      00B129 E0               [24]  811 	movx	a,@dptr
      00B12A 70 04            [24]  812 	jnz	00102$
                                    813 ;	quantum/vial.c:134: return 0;
      00B12C 90 00 00         [24]  814 	mov	dptr,#0x0000
      00B12F 22               [24]  815 	ret
      00B130                        816 00102$:
                                    817 ;	quantum/vial.c:135: return in;
      00B130 12 43 23         [24]  818 	lcall	_ak820_outline_0119
                                    819 ;	quantum/vial.c:136: }
      00B133 22               [24]  820 	ret
                                    821 ;------------------------------------------------------------
                                    822 ;Allocation info for local variables in function 'vial_fill_packet'
                                    823 ;------------------------------------------------------------
                                    824 ;value         Allocated with name '_vial_fill_packet_PARM_2'
                                    825 ;msg           Allocated with name '_vial_fill_packet_msg_10000_614'
                                    826 ;i             Allocated with name '_vial_fill_packet_i_20000_616'
                                    827 ;------------------------------------------------------------
                                    828 ;	quantum/vial.c:139: static void vial_fill_packet(uint8_t __xdata *msg, uint8_t value) {
                                    829 ;	-----------------------------------------
                                    830 ;	 function vial_fill_packet
                                    831 ;	-----------------------------------------
      00B134                        832 _vial_fill_packet:
      00B134 12 38 4C         [24]  833 	lcall	_ak820_outline_0106
      00B137 90 0D 0A         [24]  834 	mov	dptr,#_vial_fill_packet_msg_10000_614
      00B13A 12 38 47         [24]  835 	lcall	_ak820_outline_0105
                                    836 ;	quantum/vial.c:140: for (uint8_t i = 0; i < VIAL_RAW_EPSIZE; ++i) msg[i] = value;
      00B13D 90 0D 0A         [24]  837 	mov	dptr,#_vial_fill_packet_msg_10000_614
      00B140 12 37 F7         [24]  838 	lcall	_ak820_outline_0056
      00B143 90 0D 09         [24]  839 	mov	dptr,#_vial_fill_packet_PARM_2
      00B146 E0               [24]  840 	movx	a,@dptr
      00B147 FD               [12]  841 	mov	r5,a
      00B148 7C 00            [12]  842 	mov	r4,#0x00
      00B14A                        843 00103$:
      00B14A BC 20 00         [24]  844 	cjne	r4,#0x20,00122$
      00B14D                        845 00122$:
      00B14D 50 09            [24]  846 	jnc	00105$
      00B14F EC               [12]  847 	mov	a,r4
      00B150 12 37 EF         [24]  848 	lcall	_ak820_outline_0035
      00B153 ED               [12]  849 	mov	a,r5
      00B154 F0               [24]  850 	movx	@dptr,a
      00B155 0C               [12]  851 	inc	r4
      00B156 80 F2            [24]  852 	sjmp	00103$
      00B158                        853 00105$:
                                    854 ;	quantum/vial.c:141: }
      00B158 22               [24]  855 	ret
                                    856 ;------------------------------------------------------------
                                    857 ;Allocation info for local variables in function 'vial_release_held_state'
                                    858 ;------------------------------------------------------------
                                    859 ;	quantum/vial.c:152: static void vial_release_held_state(void) {
                                    860 ;	-----------------------------------------
                                    861 ;	 function vial_release_held_state
                                    862 ;	-----------------------------------------
      00B159                        863 _vial_release_held_state:
                                    864 ;	quantum/vial.c:174: repeat_key_cancel();
      00B159 12 A5 79         [24]  865 	lcall	_repeat_key_cancel
                                    866 ;	quantum/vial.c:176: clear_keyboard();
                                    867 ;	quantum/vial.c:177: }
      00B15C 02 7A F4         [24]  868 	ljmp	_clear_keyboard
                                    869 ;------------------------------------------------------------
                                    870 ;Allocation info for local variables in function 'vial_handle_cmd'
                                    871 ;------------------------------------------------------------
                                    872 ;sloc0         Allocated with name '_vial_handle_cmd_sloc0_1_0'
                                    873 ;sloc1         Allocated with name '_vial_handle_cmd_sloc1_1_0'
                                    874 ;sloc2         Allocated with name '_vial_handle_cmd_sloc2_1_0'
                                    875 ;sloc3         Allocated with name '_vial_handle_cmd_sloc3_1_0'
                                    876 ;length        Allocated with name '_vial_handle_cmd_PARM_2'
                                    877 ;data          Allocated with name '_vial_handle_cmd_data_10000_619'
                                    878 ;msg           Allocated with name '_vial_handle_cmd_msg_10000_620'
                                    879 ;i             Allocated with name '_vial_handle_cmd_i_50000_625'
                                    880 ;sz            Allocated with name '_vial_handle_cmd_sz_40000_626'
                                    881 ;page          Allocated with name '_vial_handle_cmd_page_40001_629'
                                    882 ;start         Allocated with name '_vial_handle_cmd_start_40002_631'
                                    883 ;remaining     Allocated with name '_vial_handle_cmd_remaining_40002_631'
                                    884 ;count         Allocated with name '_vial_handle_cmd_count_40002_631'
                                    885 ;i             Allocated with name '_vial_handle_cmd_i_50002_632'
                                    886 ;layer         Allocated with name '_vial_handle_cmd_layer_40000_633'
                                    887 ;idx           Allocated with name '_vial_handle_cmd_idx_40000_633'
                                    888 ;keycode       Allocated with name '_vial_handle_cmd_keycode_40000_633'
                                    889 ;i             Allocated with name '_vial_handle_cmd_i_50000_636'
                                    890 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_647'
                                    891 ;td            Allocated with name '_vial_handle_cmd_td_70000_647'
                                    892 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_648'
                                    893 ;td            Allocated with name '_vial_handle_cmd_td_70000_648'
                                    894 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_649'
                                    895 ;entry         Allocated with name '_vial_handle_cmd_entry_70000_649'
                                    896 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_650'
                                    897 ;entry         Allocated with name '_vial_handle_cmd_entry_70000_650'
                                    898 ;------------------------------------------------------------
                                    899 ;	quantum/vial.c:180: void vial_handle_cmd(uint8_t *data, uint8_t length) {
                                    900 ;	-----------------------------------------
                                    901 ;	 function vial_handle_cmd
                                    902 ;	-----------------------------------------
      00B15F                        903 _vial_handle_cmd:
      00B15F 12 42 D4         [24]  904 	lcall	_ak820_outline_0042
      00B162 90 0D 0D         [24]  905 	mov	dptr,#_vial_handle_cmd_data_10000_619
      00B165 12 37 DF         [24]  906 	lcall	_ak820_outline_0018
                                    907 ;	quantum/vial.c:184: uint8_t __xdata *msg = (uint8_t __xdata *)data;
      00B168 90 0D 0D         [24]  908 	mov	dptr,#_vial_handle_cmd_data_10000_619
      00B16B 12 37 F7         [24]  909 	lcall	_ak820_outline_0056
                                    910 ;	quantum/vial.c:189: if (length != VIAL_RAW_EPSIZE)
      00B16E 90 0D 0C         [24]  911 	mov	dptr,#_vial_handle_cmd_PARM_2
      00B171 E0               [24]  912 	movx	a,@dptr
      00B172 FD               [12]  913 	mov	r5,a
      00B173 BD 20 02         [24]  914 	cjne	r5,#0x20,00246$
      00B176 80 01            [24]  915 	sjmp	00102$
      00B178                        916 00246$:
                                    917 ;	quantum/vial.c:190: return;
      00B178 22               [24]  918 	ret
      00B179                        919 00102$:
                                    920 ;	quantum/vial.c:193: switch (msg[1]) {
      00B179 74 01            [12]  921 	mov	a,#0x01
      00B17B 12 48 76         [24]  922 	lcall	_ak820_outline_0012
      00B17E FB               [12]  923 	mov  r3,a
      00B17F 24 F2            [12]  924 	add	a,#0xff - 0x0d
      00B181 50 01            [24]  925 	jnc	00247$
      00B183 22               [24]  926 	ret
      00B184                        927 00247$:
                                    928 ;	free result
      00B184 EB               [12]  929 	mov	a,r3
      00B185 24 0A            [12]  930 	add	a,#(00248$-3-.)
      00B187 83               [24]  931 	movc	a,@a+pc
      00B188 F5 82            [12]  932 	mov	dpl,a
      00B18A EB               [12]  933 	mov	a,r3
      00B18B 24 12            [12]  934 	add	a,#(00249$-3-.)
      00B18D 83               [24]  935 	movc	a,@a+pc
      00B18E F5 83            [12]  936 	mov	dph,a
      00B190 E4               [12]  937 	clr	a
      00B191 73               [24]  938 	jmp	@a+dptr
      00B192                        939 00248$:
      00B192 AE                     940 	.db	00103$
      00B193 F6                     941 	.db	00105$
      00B194 0B                     942 	.db	00106$
      00B195 97                     943 	.db	00112$
      00B196 1E                     944 	.db	00113$
      00B197 68                     945 	.db	00114$
      00B198 D7                     946 	.db	00116$
      00B199 F2                     947 	.db	00119$
      00B19A 12                     948 	.db	00120$
      00B19B 20                     949 	.db	00121$
      00B19C CE                     950 	.db	00141$
      00B19D CE                     951 	.db	00141$
      00B19E CE                     952 	.db	00141$
      00B19F 2B                     953 	.db	00122$
      00B1A0                        954 00249$:
      00B1A0 B1                     955 	.db	00103$>>8
      00B1A1 B1                     956 	.db	00105$>>8
      00B1A2 B2                     957 	.db	00106$>>8
      00B1A3 B2                     958 	.db	00112$>>8
      00B1A4 B3                     959 	.db	00113$>>8
      00B1A5 B3                     960 	.db	00114$>>8
      00B1A6 B3                     961 	.db	00116$>>8
      00B1A7 B3                     962 	.db	00119$>>8
      00B1A8 B4                     963 	.db	00120$>>8
      00B1A9 B4                     964 	.db	00121$>>8
      00B1AA B5                     965 	.db	00141$>>8
      00B1AB B5                     966 	.db	00141$>>8
      00B1AC B5                     967 	.db	00141$>>8
      00B1AD B4                     968 	.db	00122$>>8
                                    969 ;	quantum/vial.c:195: case vial_get_keyboard_id: {
      00B1AE                        970 00103$:
                                    971 ;	quantum/vial.c:198: VIAL_FILL_PACKET(msg, 0, length);
      00B1AE 90 0D 09         [24]  972 	mov	dptr,#_vial_fill_packet_PARM_2
      00B1B1 E4               [12]  973 	clr	a
      00B1B2 12 42 F8         [24]  974 	lcall	_ak820_outline_0066
      00B1B5 C0 07            [24]  975 	push	ar7
      00B1B7 C0 06            [24]  976 	push	ar6
      00B1B9 12 B1 34         [24]  977 	lcall	_vial_fill_packet
      00B1BC D0 06            [24]  978 	pop	ar6
      00B1BE D0 07            [24]  979 	pop	ar7
                                    980 ;	quantum/vial.c:199: msg[0] = VIAL_PROTOCOL_VERSION & 0xFF;
      00B1C0 12 43 23         [24]  981 	lcall	_ak820_outline_0119
      00B1C3 74 06            [12]  982 	mov	a,#0x06
      00B1C5 12 42 F8         [24]  983 	lcall	_ak820_outline_0066
                                    984 ;	quantum/vial.c:200: msg[1] = (VIAL_PROTOCOL_VERSION >> 8) & 0xFF;
      00B1C8 A3               [24]  985 	inc	dptr
      00B1C9 E4               [12]  986 	clr	a
      00B1CA 12 42 CC         [24]  987 	lcall	_ak820_outline_0036
                                    988 ;	quantum/vial.c:201: msg[2] = (VIAL_PROTOCOL_VERSION >> 16) & 0xFF;
      00B1CD 12 42 CC         [24]  989 	lcall	_ak820_outline_0036
                                    990 ;	quantum/vial.c:202: msg[3] = (VIAL_PROTOCOL_VERSION >> 24) & 0xFF;
      00B1D0 A3               [24]  991 	inc	dptr
      00B1D1 F0               [24]  992 	movx	@dptr,a
                                    993 ;	quantum/vial.c:203: for (uint8_t i = 0; i < 8; ++i) msg[4 + i] = pgm_read_byte(&keyboard_uid[i]);
      00B1D2 FB               [12]  994 	mov	r3,a
      00B1D3                        995 00133$:
      00B1D3 BB 08 00         [24]  996 	cjne	r3,#0x08,00250$
      00B1D6                        997 00250$:
      00B1D6 50 15            [24]  998 	jnc	00104$
      00B1D8 8B 02            [24]  999 	mov	ar2,r3
      00B1DA 74 04            [12] 1000 	mov	a,#0x04
      00B1DC 2A               [12] 1001 	add	a, r2
      00B1DD 2E               [12] 1002 	add	a, r6
      00B1DE F9               [12] 1003 	mov	r1,a
      00B1DF E4               [12] 1004 	clr	a
      00B1E0 3F               [12] 1005 	addc	a,r7
      00B1E1 FA               [12] 1006 	mov	r2,a
      00B1E2 EB               [12] 1007 	mov	a,r3
      00B1E3 90 C3 88         [24] 1008 	mov	dptr,#_vial_handle_cmd_keyboard_uid_40000_624
      00B1E6 93               [24] 1009 	movc	a,@a+dptr
      00B1E7 12 71 08         [24] 1010 	lcall	_ak820_outline_0139
      00B1EA 0B               [12] 1011 	inc	r3
      00B1EB 80 E6            [24] 1012 	sjmp	00133$
      00B1ED                       1013 00104$:
                                   1014 ;	quantum/vial.c:205: msg[12] = 1; /* bit flag to indicate vialrgb is supported - so third-party apps don't have to query json */
      00B1ED 74 0C            [12] 1015 	mov	a,#0x0c
      00B1EF 12 37 EF         [24] 1016 	lcall	_ak820_outline_0035
      00B1F2 74 01            [12] 1017 	mov	a,#0x01
      00B1F4 F0               [24] 1018 	movx	@dptr,a
                                   1019 ;	quantum/vial.c:207: break;
      00B1F5 22               [24] 1020 	ret
                                   1021 ;	quantum/vial.c:210: case vial_get_size: {
      00B1F6                       1022 00105$:
                                   1023 ;	quantum/vial.c:212: msg[0] = sz & 0xFF;
      00B1F6 12 43 23         [24] 1024 	lcall	_ak820_outline_0119
      00B1F9 74 7C            [12] 1025 	mov	a,#0x7c
      00B1FB F0               [24] 1026 	movx	@dptr,a
                                   1027 ;	quantum/vial.c:213: msg[1] = (sz >> 8) & 0xFF;
      00B1FC 12 38 51         [24] 1028 	lcall	_ak820_outline_0123
      00B1FF 74 01            [12] 1029 	mov	a,#0x01
      00B201 12 42 CC         [24] 1030 	lcall	_ak820_outline_0036
                                   1031 ;	quantum/vial.c:214: msg[2] = (sz >> 16) & 0xFF;
      00B204 E4               [12] 1032 	clr	a
      00B205 12 42 CC         [24] 1033 	lcall	_ak820_outline_0036
                                   1034 ;	quantum/vial.c:215: msg[3] = (sz >> 24) & 0xFF;
      00B208 A3               [24] 1035 	inc	dptr
      00B209 F0               [24] 1036 	movx	@dptr,a
                                   1037 ;	quantum/vial.c:216: break;
      00B20A 22               [24] 1038 	ret
                                   1039 ;	quantum/vial.c:219: case vial_get_def: {
      00B20B                       1040 00106$:
                                   1041 ;	quantum/vial.c:226: if (msg[4] | msg[5]) return;
      00B20B 12 B0 3D         [24] 1042 	lcall	_ak820_outline_0022
      00B20E E0               [24] 1043 	movx	a,@dptr
      00B20F FB               [12] 1044 	mov	r3,a
      00B210 12 42 C2         [24] 1045 	lcall	_ak820_outline_0013
      00B213 E0               [24] 1046 	movx	a,@dptr
      00B214 4B               [12] 1047 	orl	a,r3
      00B215 60 01            [24] 1048 	jz	00108$
      00B217 22               [24] 1049 	ret
      00B218                       1050 00108$:
                                   1051 ;	quantum/vial.c:227: uint16_t page = (uint16_t)msg[2] | ((uint16_t)msg[3] << 8);
      00B218 12 37 E7         [24] 1052 	lcall	_ak820_outline_0034
      00B21B FB               [12] 1053 	mov	r3,a
      00B21C 7A 00            [12] 1054 	mov	r2,#0x00
      00B21E 12 48 81         [24] 1055 	lcall	_ak820_outline_0015
      00B221 F9               [12] 1056 	mov	r1,a
      00B222 E4               [12] 1057 	clr	a
      00B223 42 03            [12] 1058 	orl	ar3,a
      00B225 E9               [12] 1059 	mov	a,r1
      00B226 42 02            [12] 1060 	orl	ar2,a
                                   1061 ;	quantum/vial.c:228: if (page >= (sizeof(keyboard_definition) + VIAL_RAW_EPSIZE - 1) / VIAL_RAW_EPSIZE) return;
      00B228 C3               [12] 1062 	clr	c
      00B229 EB               [12] 1063 	mov	a,r3
      00B22A 94 0C            [12] 1064 	subb	a,#0x0c
      00B22C EA               [12] 1065 	mov	a,r2
      00B22D 94 00            [12] 1066 	subb	a,#0x00
      00B22F 40 01            [24] 1067 	jc	00110$
      00B231 22               [24] 1068 	ret
      00B232                       1069 00110$:
                                   1070 ;	quantum/vial.c:229: uint16_t start = page * VIAL_RAW_EPSIZE;
      00B232 EA               [12] 1071 	mov	a,r2
      00B233 C4               [12] 1072 	swap	a
      00B234 23               [12] 1073 	rl	a
      00B235 54 E0            [12] 1074 	anl	a,#0xe0
      00B237 CB               [12] 1075 	xch	a,r3
      00B238 C4               [12] 1076 	swap	a
      00B239 23               [12] 1077 	rl	a
      00B23A CB               [12] 1078 	xch	a,r3
      00B23B 6B               [12] 1079 	xrl	a,r3
      00B23C CB               [12] 1080 	xch	a,r3
      00B23D 54 E0            [12] 1081 	anl	a,#0xe0
      00B23F CB               [12] 1082 	xch	a,r3
      00B240 6B               [12] 1083 	xrl	a,r3
      00B241 FA               [12] 1084 	mov	r2,a
      00B242 8B 42            [24] 1085 	mov	_vial_handle_cmd_sloc0_1_0,r3
      00B244 8A 43            [24] 1086 	mov	(_vial_handle_cmd_sloc0_1_0 + 1),r2
                                   1087 ;	quantum/vial.c:230: uint16_t remaining = sizeof(keyboard_definition) - start;
      00B246 74 7C            [12] 1088 	mov	a,#0x7c
      00B248 C3               [12] 1089 	clr	c
      00B249 95 42            [12] 1090 	subb	a,_vial_handle_cmd_sloc0_1_0
      00B24B F8               [12] 1091 	mov	r0,a
      00B24C 74 01            [12] 1092 	mov	a,#0x01
      00B24E 95 43            [12] 1093 	subb	a,(_vial_handle_cmd_sloc0_1_0 + 1)
      00B250 F9               [12] 1094 	mov	r1,a
                                   1095 ;	quantum/vial.c:231: uint8_t count = remaining < VIAL_RAW_EPSIZE ? remaining : VIAL_RAW_EPSIZE;
      00B251 C3               [12] 1096 	clr	c
      00B252 E8               [12] 1097 	mov	a,r0
      00B253 94 20            [12] 1098 	subb	a,#0x20
      00B255 E9               [12] 1099 	mov	a,r1
      00B256 94 00            [12] 1100 	subb	a,#0x00
      00B258 40 02            [24] 1101 	jc	00144$
      00B25A 78 20            [12] 1102 	mov	r0,#0x20
      00B25C                       1103 00144$:
                                   1104 ;	quantum/vial.c:232: for (uint8_t i = 0; i < count; ++i) msg[i] = pgm_read_byte(&keyboard_definition[start + i]);
      00B25C 79 00            [12] 1105 	mov	r1,#0x00
      00B25E                       1106 00136$:
      00B25E C3               [12] 1107 	clr	c
      00B25F E9               [12] 1108 	mov	a,r1
      00B260 98               [12] 1109 	subb	a,r0
      00B261 40 01            [24] 1110 	jc	00255$
      00B263 22               [24] 1111 	ret
      00B264                       1112 00255$:
      00B264 C0 00            [24] 1113 	push	ar0
      00B266 E9               [12] 1114 	mov	a,r1
      00B267 2E               [12] 1115 	add	a, r6
      00B268 F5 44            [12] 1116 	mov	_vial_handle_cmd_sloc1_1_0,a
      00B26A E4               [12] 1117 	clr	a
      00B26B 3F               [12] 1118 	addc	a, r7
      00B26C F5 45            [12] 1119 	mov	(_vial_handle_cmd_sloc1_1_0 + 1),a
      00B26E 89 46            [24] 1120 	mov	_vial_handle_cmd_sloc2_1_0,r1
      00B270 75 47 00         [24] 1121 	mov	(_vial_handle_cmd_sloc2_1_0 + 1),#0x00
      00B273 A8 42            [24] 1122 	mov	r0,_vial_handle_cmd_sloc0_1_0
      00B275 AB 43            [24] 1123 	mov	r3,(_vial_handle_cmd_sloc0_1_0 + 1)
      00B277 E5 46            [12] 1124 	mov	a,_vial_handle_cmd_sloc2_1_0
      00B279 28               [12] 1125 	add	a, r0
      00B27A F8               [12] 1126 	mov	r0,a
      00B27B E5 47            [12] 1127 	mov	a,(_vial_handle_cmd_sloc2_1_0 + 1)
      00B27D 3B               [12] 1128 	addc	a, r3
      00B27E FB               [12] 1129 	mov	r3,a
      00B27F E8               [12] 1130 	mov	a,r0
      00B280 24 0C            [12] 1131 	add	a, #_keyboard_definition
      00B282 F5 82            [12] 1132 	mov	dpl,a
      00B284 EB               [12] 1133 	mov	a,r3
      00B285 34 C2            [12] 1134 	addc	a, #(_keyboard_definition >> 8)
      00B287 F5 83            [12] 1135 	mov	dph,a
      00B289 E4               [12] 1136 	clr	a
      00B28A 93               [24] 1137 	movc	a,@a+dptr
      00B28B 85 44 82         [24] 1138 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00B28E 85 45 83         [24] 1139 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00B291 F0               [24] 1140 	movx	@dptr,a
      00B292 09               [12] 1141 	inc	r1
      00B293 D0 00            [24] 1142 	pop	ar0
                                   1143 ;	quantum/vial.c:246: case vial_get_encoder: {
      00B295 80 C7            [24] 1144 	sjmp	00136$
      00B297                       1145 00112$:
                                   1146 ;	quantum/vial.c:247: uint8_t layer = msg[2];
      00B297 74 02            [12] 1147 	mov	a,#0x02
      00B299 2E               [12] 1148 	add	a, r6
      00B29A 12 48 A2         [24] 1149 	lcall	_ak820_outline_0033
      00B29D F5 46            [12] 1150 	mov	_vial_handle_cmd_sloc2_1_0,a
                                   1151 ;	quantum/vial.c:248: uint8_t idx = msg[3];
      00B29F 74 03            [12] 1152 	mov	a,#0x03
      00B2A1 2E               [12] 1153 	add	a, r6
      00B2A2 F5 44            [12] 1154 	mov	_vial_handle_cmd_sloc1_1_0,a
      00B2A4 E4               [12] 1155 	clr	a
      00B2A5 3F               [12] 1156 	addc	a, r7
      00B2A6 F5 45            [12] 1157 	mov	(_vial_handle_cmd_sloc1_1_0 + 1),a
      00B2A8 85 44 82         [24] 1158 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00B2AB 85 45 83         [24] 1159 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00B2AE E0               [24] 1160 	movx	a,@dptr
                                   1161 ;	quantum/vial.c:249: uint16_t keycode = dynamic_keymap_get_encoder(layer, idx, 0);
      00B2AF F5 42            [12] 1162 	mov	_vial_handle_cmd_sloc0_1_0,a
      00B2B1 90 0B A5         [24] 1163 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      00B2B4 F0               [24] 1164 	movx	@dptr,a
      00B2B5 90 0B A6         [24] 1165 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      00B2B8 E4               [12] 1166 	clr	a
      00B2B9 F0               [24] 1167 	movx	@dptr,a
      00B2BA 85 46 82         [24] 1168 	mov	dpl, _vial_handle_cmd_sloc2_1_0
      00B2BD C0 07            [24] 1169 	push	ar7
      00B2BF C0 06            [24] 1170 	push	ar6
      00B2C1 C0 05            [24] 1171 	push	ar5
      00B2C3 C0 04            [24] 1172 	push	ar4
      00B2C5 C0 03            [24] 1173 	push	ar3
      00B2C7 C0 02            [24] 1174 	push	ar2
      00B2C9 12 88 9F         [24] 1175 	lcall	_dynamic_keymap_get_encoder
      00B2CC 85 82 48         [24] 1176 	mov	_vial_handle_cmd_sloc3_1_0,dpl
      00B2CF 85 83 49         [24] 1177 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),dph
      00B2D2 D0 02            [24] 1178 	pop	ar2
      00B2D4 D0 03            [24] 1179 	pop	ar3
      00B2D6 D0 04            [24] 1180 	pop	ar4
      00B2D8 D0 05            [24] 1181 	pop	ar5
      00B2DA D0 06            [24] 1182 	pop	ar6
      00B2DC D0 07            [24] 1183 	pop	ar7
                                   1184 ;	quantum/vial.c:250: msg[0]  = keycode >> 8;
      00B2DE A9 49            [24] 1185 	mov	r1,(_vial_handle_cmd_sloc3_1_0 + 1)
      00B2E0 12 43 23         [24] 1186 	lcall	_ak820_outline_0119
      00B2E3 E9               [12] 1187 	mov	a,r1
      00B2E4 F0               [24] 1188 	movx	@dptr,a
                                   1189 ;	quantum/vial.c:251: msg[1]  = keycode & 0xFF;
      00B2E5 A8 48            [24] 1190 	mov	r0,_vial_handle_cmd_sloc3_1_0
      00B2E7 12 38 51         [24] 1191 	lcall	_ak820_outline_0123
      00B2EA E8               [12] 1192 	mov	a,r0
      00B2EB F0               [24] 1193 	movx	@dptr,a
                                   1194 ;	quantum/vial.c:252: keycode = dynamic_keymap_get_encoder(layer, idx, 1);
      00B2EC 90 0B A5         [24] 1195 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      00B2EF E5 42            [12] 1196 	mov	a,_vial_handle_cmd_sloc0_1_0
      00B2F1 F0               [24] 1197 	movx	@dptr,a
      00B2F2 90 0B A6         [24] 1198 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      00B2F5 74 01            [12] 1199 	mov	a,#0x01
      00B2F7 F0               [24] 1200 	movx	@dptr,a
      00B2F8 85 46 82         [24] 1201 	mov	dpl, _vial_handle_cmd_sloc2_1_0
      00B2FB C0 03            [24] 1202 	push	ar3
      00B2FD C0 02            [24] 1203 	push	ar2
      00B2FF 12 88 9F         [24] 1204 	lcall	_dynamic_keymap_get_encoder
      00B302 85 82 48         [24] 1205 	mov	_vial_handle_cmd_sloc3_1_0,dpl
      00B305 85 83 49         [24] 1206 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),dph
      00B308 D0 02            [24] 1207 	pop	ar2
      00B30A D0 03            [24] 1208 	pop	ar3
                                   1209 ;	quantum/vial.c:253: msg[2] = keycode >> 8;
      00B30C A9 49            [24] 1210 	mov	r1,(_vial_handle_cmd_sloc3_1_0 + 1)
      00B30E 12 43 28         [24] 1211 	lcall	_ak820_outline_0135
      00B311 E9               [12] 1212 	mov	a,r1
      00B312 F0               [24] 1213 	movx	@dptr,a
                                   1214 ;	quantum/vial.c:254: msg[3] = keycode & 0xFF;
      00B313 A8 48            [24] 1215 	mov	r0,_vial_handle_cmd_sloc3_1_0
      00B315 85 44 82         [24] 1216 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00B318 85 45 83         [24] 1217 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00B31B E8               [12] 1218 	mov	a,r0
      00B31C F0               [24] 1219 	movx	@dptr,a
                                   1220 ;	quantum/vial.c:255: break;
      00B31D 22               [24] 1221 	ret
                                   1222 ;	quantum/vial.c:257: case vial_set_encoder: {
      00B31E                       1223 00113$:
                                   1224 ;	quantum/vial.c:258: dynamic_keymap_set_encoder(msg[2], msg[3], msg[4], vial_keycode_firewall((msg[5] << 8) | msg[6]));
      00B31E 12 37 E7         [24] 1225 	lcall	_ak820_outline_0034
      00B321 F5 44            [12] 1226 	mov	_vial_handle_cmd_sloc1_1_0,a
      00B323 12 48 81         [24] 1227 	lcall	_ak820_outline_0015
      00B326 F5 46            [12] 1228 	mov	_vial_handle_cmd_sloc2_1_0,a
      00B328 12 B0 3D         [24] 1229 	lcall	_ak820_outline_0022
      00B32B E0               [24] 1230 	movx	a,@dptr
                                   1231 ;	assignBit
      00B32C 24 FF            [12] 1232 	add	a,#0xff
      00B32E E4               [12] 1233 	clr	a
      00B32F 33               [12] 1234 	rlc	a
      00B330 F5 48            [12] 1235 	mov	_vial_handle_cmd_sloc3_1_0,a
      00B332 12 42 C2         [24] 1236 	lcall	_ak820_outline_0013
      00B335 E0               [24] 1237 	movx	a,@dptr
      00B336 F9               [12] 1238 	mov	r1,a
      00B337 78 00            [12] 1239 	mov	r0,#0x00
      00B339 74 06            [12] 1240 	mov	a,#0x06
      00B33B 12 37 D6         [24] 1241 	lcall	_ak820_outline_0017
      00B33E 7B 00            [12] 1242 	mov	r3,#0x00
      00B340 42 00            [12] 1243 	orl	ar0,a
      00B342 EB               [12] 1244 	mov	a,r3
      00B343 42 01            [12] 1245 	orl	ar1,a
      00B345 12 38 6B         [24] 1246 	lcall	_ak820_outline_0158
      00B348 12 B1 11         [24] 1247 	lcall	_vial_keycode_firewall
      00B34B AA 82            [24] 1248 	mov	r2, dpl
      00B34D AB 83            [24] 1249 	mov	r3, dph
      00B34F 90 0B A8         [24] 1250 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      00B352 E5 46            [12] 1251 	mov	a,_vial_handle_cmd_sloc2_1_0
      00B354 F0               [24] 1252 	movx	@dptr,a
      00B355 90 0B A9         [24] 1253 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      00B358 E5 48            [12] 1254 	mov	a,_vial_handle_cmd_sloc3_1_0
      00B35A F0               [24] 1255 	movx	@dptr,a
      00B35B 90 0B AA         [24] 1256 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      00B35E EA               [12] 1257 	mov	a,r2
      00B35F 12 48 ED         [24] 1258 	lcall	_ak820_outline_0191
      00B362 85 44 82         [24] 1259 	mov	dpl, _vial_handle_cmd_sloc1_1_0
                                   1260 ;	quantum/vial.c:259: break;
      00B365 02 89 06         [24] 1261 	ljmp	_dynamic_keymap_set_encoder
                                   1262 ;	quantum/vial.c:262: case vial_get_unlock_status: {
      00B368                       1263 00114$:
                                   1264 ;	quantum/vial.c:264: VIAL_FILL_PACKET(msg, 0xFF, length);
      00B368 90 0D 09         [24] 1265 	mov	dptr,#_vial_fill_packet_PARM_2
      00B36B 74 FF            [12] 1266 	mov	a,#0xff
      00B36D 12 42 F8         [24] 1267 	lcall	_ak820_outline_0066
      00B370 C0 07            [24] 1268 	push	ar7
      00B372 C0 06            [24] 1269 	push	ar6
      00B374 12 B1 34         [24] 1270 	lcall	_vial_fill_packet
      00B377 D0 06            [24] 1271 	pop	ar6
      00B379 D0 07            [24] 1272 	pop	ar7
                                   1273 ;	quantum/vial.c:266: msg[0] = vial_unlocked;
      00B37B 90 0E E0         [24] 1274 	mov	dptr,#_vial_unlocked
      00B37E E0               [24] 1275 	movx	a,@dptr
      00B37F 12 43 23         [24] 1276 	lcall	_ak820_outline_0119
      00B382 F0               [24] 1277 	movx	@dptr,a
                                   1278 ;	quantum/vial.c:268: msg[1] = vial_unlock_in_progress;
      00B383 74 01            [12] 1279 	mov	a,#0x01
      00B385 2E               [12] 1280 	add	a, r6
      00B386 FA               [12] 1281 	mov	r2,a
      00B387 E4               [12] 1282 	clr	a
      00B388 3F               [12] 1283 	addc	a, r7
      00B389 FB               [12] 1284 	mov	r3,a
      00B38A 90 0E E1         [24] 1285 	mov	dptr,#_vial_unlock_in_progress
      00B38D E0               [24] 1286 	movx	a,@dptr
      00B38E 12 43 28         [24] 1287 	lcall	_ak820_outline_0135
      00B391 F0               [24] 1288 	movx	@dptr,a
                                   1289 ;	quantum/vial.c:271: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B392 7B 00            [12] 1290 	mov	r3,#0x00
      00B394                       1291 00139$:
      00B394 BB 02 00         [24] 1292 	cjne	r3,#0x02,00256$
      00B397                       1293 00256$:
      00B397 40 01            [24] 1294 	jc	00257$
      00B399 22               [24] 1295 	ret
      00B39A                       1296 00257$:
                                   1297 ;	quantum/vial.c:272: msg[2 + i * 2] = vial_unlock_combo_rows[i];
      00B39A 8B 01            [24] 1298 	mov	ar1,r3
      00B39C 7A 00            [12] 1299 	mov	r2,#0x00
      00B39E E9               [12] 1300 	mov	a,r1
      00B39F 29               [12] 1301 	add	a,r1
      00B3A0 F5 48            [12] 1302 	mov	_vial_handle_cmd_sloc3_1_0,a
      00B3A2 EA               [12] 1303 	mov	a,r2
      00B3A3 33               [12] 1304 	rlc	a
      00B3A4 F5 49            [12] 1305 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),a
      00B3A6 74 02            [12] 1306 	mov	a,#0x02
      00B3A8 25 48            [12] 1307 	add	a, _vial_handle_cmd_sloc3_1_0
      00B3AA F8               [12] 1308 	mov	r0,a
      00B3AB E4               [12] 1309 	clr	a
      00B3AC 35 49            [12] 1310 	addc	a, (_vial_handle_cmd_sloc3_1_0 + 1)
      00B3AE FA               [12] 1311 	mov	r2,a
      00B3AF E8               [12] 1312 	mov	a,r0
      00B3B0 2E               [12] 1313 	add	a, r6
      00B3B1 F8               [12] 1314 	mov	r0,a
      00B3B2 EA               [12] 1315 	mov	a,r2
      00B3B3 3F               [12] 1316 	addc	a, r7
      00B3B4 FA               [12] 1317 	mov	r2,a
      00B3B5 EB               [12] 1318 	mov	a,r3
      00B3B6 12 B6 EB         [24] 1319 	lcall	_ak820_outline_0130
      00B3B9 88 82            [24] 1320 	mov	dpl,r0
      00B3BB 8A 83            [24] 1321 	mov	dph,r2
      00B3BD F0               [24] 1322 	movx	@dptr,a
                                   1323 ;	quantum/vial.c:273: msg[2 + i * 2 + 1] = vial_unlock_combo_cols[i];
      00B3BE 74 03            [12] 1324 	mov	a,#0x03
      00B3C0 25 48            [12] 1325 	add	a, _vial_handle_cmd_sloc3_1_0
      00B3C2 F9               [12] 1326 	mov	r1,a
      00B3C3 E4               [12] 1327 	clr	a
      00B3C4 35 49            [12] 1328 	addc	a, (_vial_handle_cmd_sloc3_1_0 + 1)
      00B3C6 FA               [12] 1329 	mov	r2,a
      00B3C7 E9               [12] 1330 	mov	a,r1
      00B3C8 2E               [12] 1331 	add	a, r6
      00B3C9 F9               [12] 1332 	mov	r1,a
      00B3CA EA               [12] 1333 	mov	a,r2
      00B3CB 3F               [12] 1334 	addc	a, r7
      00B3CC FA               [12] 1335 	mov	r2,a
      00B3CD EB               [12] 1336 	mov	a,r3
      00B3CE 12 B6 E0         [24] 1337 	lcall	_ak820_outline_0129
      00B3D1 12 71 08         [24] 1338 	lcall	_ak820_outline_0139
                                   1339 ;	quantum/vial.c:271: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B3D4 0B               [12] 1340 	inc	r3
                                   1341 ;	quantum/vial.c:278: case vial_unlock_start: {
      00B3D5 80 BD            [24] 1342 	sjmp	00139$
      00B3D7                       1343 00116$:
                                   1344 ;	quantum/vial.c:280: if (!vial_unlock_in_progress) vial_release_held_state();
      00B3D7 90 0E E1         [24] 1345 	mov	dptr,#_vial_unlock_in_progress
      00B3DA E0               [24] 1346 	movx	a,@dptr
      00B3DB 70 03            [24] 1347 	jnz	00118$
      00B3DD 12 B1 59         [24] 1348 	lcall	_vial_release_held_state
      00B3E0                       1349 00118$:
                                   1350 ;	quantum/vial.c:282: vial_unlock_in_progress = 1;
      00B3E0 90 0E E1         [24] 1351 	mov	dptr,#_vial_unlock_in_progress
      00B3E3 74 01            [12] 1352 	mov	a,#0x01
      00B3E5 F0               [24] 1353 	movx	@dptr,a
                                   1354 ;	quantum/vial.c:283: vial_unlock_counter = VIAL_UNLOCK_COUNTER_MAX;
      00B3E6 90 0E E2         [24] 1355 	mov	dptr,#_vial_unlock_counter
      00B3E9 74 1E            [12] 1356 	mov	a,#0x1e
      00B3EB F0               [24] 1357 	movx	@dptr,a
                                   1358 ;	quantum/vial.c:285: vial_unlock_holding = false;
      00B3EC 90 0D 06         [24] 1359 	mov	dptr,#_vial_unlock_holding
      00B3EF E4               [12] 1360 	clr	a
      00B3F0 F0               [24] 1361 	movx	@dptr,a
                                   1362 ;	quantum/vial.c:287: break;
      00B3F1 22               [24] 1363 	ret
                                   1364 ;	quantum/vial.c:289: case vial_unlock_poll: {
      00B3F2                       1365 00119$:
                                   1366 ;	quantum/vial.c:290: msg[0] = vial_unlocked;
      00B3F2 90 0E E0         [24] 1367 	mov	dptr,#_vial_unlocked
      00B3F5 E0               [24] 1368 	movx	a,@dptr
      00B3F6 12 43 23         [24] 1369 	lcall	_ak820_outline_0119
      00B3F9 F0               [24] 1370 	movx	@dptr,a
                                   1371 ;	quantum/vial.c:291: msg[1] = vial_unlock_in_progress;
      00B3FA 90 0E E1         [24] 1372 	mov	dptr,#_vial_unlock_in_progress
      00B3FD E0               [24] 1373 	movx	a,@dptr
      00B3FE 12 38 51         [24] 1374 	lcall	_ak820_outline_0123
      00B401 F0               [24] 1375 	movx	@dptr,a
                                   1376 ;	quantum/vial.c:292: msg[2] = vial_unlock_counter;
      00B402 74 02            [12] 1377 	mov	a,#0x02
      00B404 2E               [12] 1378 	add	a, r6
      00B405 FA               [12] 1379 	mov	r2,a
      00B406 E4               [12] 1380 	clr	a
      00B407 3F               [12] 1381 	addc	a, r7
      00B408 FB               [12] 1382 	mov	r3,a
      00B409 90 0E E2         [24] 1383 	mov	dptr,#_vial_unlock_counter
      00B40C E0               [24] 1384 	movx	a,@dptr
      00B40D 12 43 28         [24] 1385 	lcall	_ak820_outline_0135
      00B410 F0               [24] 1386 	movx	@dptr,a
                                   1387 ;	quantum/vial.c:293: break;
      00B411 22               [24] 1388 	ret
                                   1389 ;	quantum/vial.c:295: case vial_lock: {
      00B412                       1390 00120$:
                                   1391 ;	quantum/vial.c:297: vial_unlocked = 0;
      00B412 90 0E E0         [24] 1392 	mov	dptr,#_vial_unlocked
      00B415 E4               [12] 1393 	clr	a
      00B416 F0               [24] 1394 	movx	@dptr,a
                                   1395 ;	quantum/vial.c:298: vial_unlock_in_progress = 0;
      00B417 90 0E E1         [24] 1396 	mov	dptr,#_vial_unlock_in_progress
      00B41A F0               [24] 1397 	movx	@dptr,a
                                   1398 ;	quantum/vial.c:299: vial_unlock_holding = false;
      00B41B 90 0D 06         [24] 1399 	mov	dptr,#_vial_unlock_holding
      00B41E F0               [24] 1400 	movx	@dptr,a
                                   1401 ;	quantum/vial.c:301: break;
      00B41F 22               [24] 1402 	ret
                                   1403 ;	quantum/vial.c:303: case vial_qmk_settings_query: {
      00B420                       1404 00121$:
                                   1405 ;	quantum/vial.c:312: VIAL_FILL_PACKET(msg, 0xFF, length); /* indicate that we don't support any qsid */
      00B420 90 0D 09         [24] 1406 	mov	dptr,#_vial_fill_packet_PARM_2
      00B423 74 FF            [12] 1407 	mov	a,#0xff
      00B425 12 42 F8         [24] 1408 	lcall	_ak820_outline_0066
                                   1409 ;	quantum/vial.c:314: break;
      00B428 02 B1 34         [24] 1410 	ljmp	_vial_fill_packet
                                   1411 ;	quantum/vial.c:346: case vial_dynamic_entry_op: {
      00B42B                       1412 00122$:
                                   1413 ;	quantum/vial.c:347: switch (msg[2]) {
      00B42B 12 37 E7         [24] 1414 	lcall	_ak820_outline_0034
      00B42E FB               [12] 1415 	mov  r3,a
      00B42F 24 FB            [12] 1416 	add	a,#0xff - 0x04
      00B431 50 01            [24] 1417 	jnc	00259$
      00B433 22               [24] 1418 	ret
      00B434                       1419 00259$:
                                   1420 ;	free result
      00B434 EB               [12] 1421 	mov	a,r3
      00B435 2B               [12] 1422 	add	a,r3
      00B436 2B               [12] 1423 	add	a,r3
      00B437 90 B4 3B         [24] 1424 	mov	dptr,#00260$
      00B43A 73               [24] 1425 	jmp	@a+dptr
      00B43B                       1426 00260$:
      00B43B 02 B4 4A         [24] 1427 	ljmp	00123$
      00B43E 02 B4 73         [24] 1428 	ljmp	00124$
      00B441 02 B4 D5         [24] 1429 	ljmp	00125$
      00B444 02 B5 15         [24] 1430 	ljmp	00126$
      00B447 02 B5 73         [24] 1431 	ljmp	00127$
                                   1432 ;	quantum/vial.c:348: case dynamic_vial_get_number_of_entries: {
      00B44A                       1433 00123$:
                                   1434 ;	quantum/vial.c:349: VIAL_FILL_PACKET(msg, 0, length);
      00B44A 90 0D 09         [24] 1435 	mov	dptr,#_vial_fill_packet_PARM_2
      00B44D E4               [12] 1436 	clr	a
      00B44E 12 42 F8         [24] 1437 	lcall	_ak820_outline_0066
      00B451 C0 07            [24] 1438 	push	ar7
      00B453 C0 06            [24] 1439 	push	ar6
      00B455 12 B1 34         [24] 1440 	lcall	_vial_fill_packet
      00B458 D0 06            [24] 1441 	pop	ar6
      00B45A D0 07            [24] 1442 	pop	ar7
                                   1443 ;	quantum/vial.c:350: msg[0] = VIAL_TAP_DANCE_ENTRIES;
      00B45C 12 43 23         [24] 1444 	lcall	_ak820_outline_0119
      00B45F 74 08            [12] 1445 	mov	a,#0x08
      00B461 12 42 F8         [24] 1446 	lcall	_ak820_outline_0066
                                   1447 ;	quantum/vial.c:351: msg[1] = VIAL_COMBO_ENTRIES;
      00B464 A3               [24] 1448 	inc	dptr
      00B465 12 42 CC         [24] 1449 	lcall	_ak820_outline_0036
                                   1450 ;	quantum/vial.c:352: msg[2] = VIAL_KEY_OVERRIDE_ENTRIES;
      00B468 E4               [12] 1451 	clr	a
      00B469 F0               [24] 1452 	movx	@dptr,a
                                   1453 ;	quantum/vial.c:354: msg[VIAL_RAW_EPSIZE - 1] = 1; /* Standard Vial feature bit 0. */
      00B46A 74 1F            [12] 1454 	mov	a,#0x1f
      00B46C 12 37 EF         [24] 1455 	lcall	_ak820_outline_0035
      00B46F 74 01            [12] 1456 	mov	a,#0x01
      00B471 F0               [24] 1457 	movx	@dptr,a
                                   1458 ;	quantum/vial.c:356: break;
      00B472 22               [24] 1459 	ret
                                   1460 ;	quantum/vial.c:359: case dynamic_vial_tap_dance_get: {
      00B473                       1461 00124$:
                                   1462 ;	quantum/vial.c:360: uint8_t idx = msg[3];
      00B473 12 48 81         [24] 1463 	lcall	_ak820_outline_0015
      00B476 FB               [12] 1464 	mov	r3,a
                                   1465 ;	quantum/vial.c:361: vial_tap_dance_entry_t td = { 0 };
      00B477 90 0D 10         [24] 1466 	mov	dptr,#_vial_handle_cmd_td_70000_647
      00B47A 12 48 D9         [24] 1467 	lcall	_ak820_outline_0143
      00B47D 90 0D 12         [24] 1468 	mov	dptr,#(_vial_handle_cmd_td_70000_647 + 0x0002)
      00B480 F0               [24] 1469 	movx	@dptr,a
      00B481 A3               [24] 1470 	inc	dptr
      00B482 F0               [24] 1471 	movx	@dptr,a
      00B483 90 0D 14         [24] 1472 	mov	dptr,#(_vial_handle_cmd_td_70000_647 + 0x0004)
      00B486 F0               [24] 1473 	movx	@dptr,a
      00B487 A3               [24] 1474 	inc	dptr
      00B488 F0               [24] 1475 	movx	@dptr,a
      00B489 90 0D 16         [24] 1476 	mov	dptr,#(_vial_handle_cmd_td_70000_647 + 0x0006)
      00B48C F0               [24] 1477 	movx	@dptr,a
      00B48D A3               [24] 1478 	inc	dptr
      00B48E F0               [24] 1479 	movx	@dptr,a
      00B48F 90 0D 18         [24] 1480 	mov	dptr,#(_vial_handle_cmd_td_70000_647 + 0x0008)
      00B492 F0               [24] 1481 	movx	@dptr,a
      00B493 A3               [24] 1482 	inc	dptr
      00B494 F0               [24] 1483 	movx	@dptr,a
                                   1484 ;	quantum/vial.c:362: msg[0] = dynamic_keymap_get_tap_dance(idx, &td);
      00B495 90 0B AD         [24] 1485 	mov	dptr,#_dynamic_keymap_get_tap_dance_PARM_2
      00B498 74 10            [12] 1486 	mov	a,#_vial_handle_cmd_td_70000_647
      00B49A F0               [24] 1487 	movx	@dptr,a
      00B49B 74 0D            [12] 1488 	mov	a,#(_vial_handle_cmd_td_70000_647 >> 8)
      00B49D 12 38 1C         [24] 1489 	lcall	_ak820_outline_0075
      00B4A0 8B 82            [24] 1490 	mov	dpl, r3
      00B4A2 C0 07            [24] 1491 	push	ar7
      00B4A4 C0 06            [24] 1492 	push	ar6
      00B4A6 C0 05            [24] 1493 	push	ar5
      00B4A8 C0 04            [24] 1494 	push	ar4
      00B4AA 12 89 72         [24] 1495 	lcall	_dynamic_keymap_get_tap_dance
      00B4AD AA 82            [24] 1496 	mov	r2, dpl
      00B4AF D0 04            [24] 1497 	pop	ar4
      00B4B1 D0 05            [24] 1498 	pop	ar5
      00B4B3 D0 06            [24] 1499 	pop	ar6
      00B4B5 D0 07            [24] 1500 	pop	ar7
      00B4B7 12 43 23         [24] 1501 	lcall	_ak820_outline_0119
      00B4BA EA               [12] 1502 	mov	a,r2
      00B4BB F0               [24] 1503 	movx	@dptr,a
                                   1504 ;	quantum/vial.c:363: memcpy(&msg[1], &td, sizeof(td));
      00B4BC 8C 01            [24] 1505 	mov	ar1,r4
      00B4BE 8D 02            [24] 1506 	mov	ar2,r5
      00B4C0 7B 00            [12] 1507 	mov	r3,#0x00
      00B4C2 90 0E 60         [24] 1508 	mov	dptr,#___memcpy_PARM_2
      00B4C5 74 10            [12] 1509 	mov	a,#_vial_handle_cmd_td_70000_647
      00B4C7 F0               [24] 1510 	movx	@dptr,a
      00B4C8 74 0D            [12] 1511 	mov	a,#(_vial_handle_cmd_td_70000_647 >> 8)
      00B4CA 12 B6 B8         [24] 1512 	lcall	_ak820_outline_0011
      00B4CD 12 43 38         [24] 1513 	lcall	_ak820_outline_0150
      00B4D0 8B F0            [24] 1514 	mov	b, r3
                                   1515 ;	quantum/vial.c:364: break;
      00B4D2 02 BC 8E         [24] 1516 	ljmp	___memcpy
                                   1517 ;	quantum/vial.c:366: case dynamic_vial_tap_dance_set: {
      00B4D5                       1518 00125$:
                                   1519 ;	quantum/vial.c:367: uint8_t idx = msg[3];
      00B4D5 12 48 81         [24] 1520 	lcall	_ak820_outline_0015
      00B4D8 FB               [12] 1521 	mov	r3,a
                                   1522 ;	quantum/vial.c:369: memcpy(&td, &msg[4], sizeof(td));
      00B4D9 74 04            [12] 1523 	mov	a,#0x04
      00B4DB 2E               [12] 1524 	add	a, r6
      00B4DC F9               [12] 1525 	mov	r1,a
      00B4DD E4               [12] 1526 	clr	a
      00B4DE 3F               [12] 1527 	addc	a, r7
      00B4DF FA               [12] 1528 	mov	r2,a
      00B4E0 90 0E 60         [24] 1529 	mov	dptr,#___memcpy_PARM_2
      00B4E3 E9               [12] 1530 	mov	a,r1
      00B4E4 F0               [24] 1531 	movx	@dptr,a
      00B4E5 EA               [12] 1532 	mov	a,r2
      00B4E6 12 B6 B8         [24] 1533 	lcall	_ak820_outline_0011
      00B4E9 90 0D 1A         [24] 1534 	mov	dptr,#_vial_handle_cmd_td_70000_648
      00B4EC F5 F0            [12] 1535 	mov	b,a
      00B4EE C0 07            [24] 1536 	push	ar7
      00B4F0 C0 06            [24] 1537 	push	ar6
      00B4F2 C0 03            [24] 1538 	push	ar3
      00B4F4 12 BC 8E         [24] 1539 	lcall	___memcpy
      00B4F7 D0 03            [24] 1540 	pop	ar3
                                   1541 ;	quantum/vial.c:376: msg[0] = dynamic_keymap_set_tap_dance(idx, &td);
      00B4F9 90 0B B1         [24] 1542 	mov	dptr,#_dynamic_keymap_set_tap_dance_PARM_2
      00B4FC 74 1A            [12] 1543 	mov	a,#_vial_handle_cmd_td_70000_648
      00B4FE F0               [24] 1544 	movx	@dptr,a
      00B4FF 74 0D            [12] 1545 	mov	a,#(_vial_handle_cmd_td_70000_648 >> 8)
      00B501 12 38 1C         [24] 1546 	lcall	_ak820_outline_0075
      00B504 8B 82            [24] 1547 	mov	dpl, r3
      00B506 12 89 F4         [24] 1548 	lcall	_dynamic_keymap_set_tap_dance
      00B509 AA 82            [24] 1549 	mov	r2, dpl
      00B50B D0 06            [24] 1550 	pop	ar6
      00B50D D0 07            [24] 1551 	pop	ar7
      00B50F 12 43 23         [24] 1552 	lcall	_ak820_outline_0119
      00B512 EA               [12] 1553 	mov	a,r2
      00B513 F0               [24] 1554 	movx	@dptr,a
                                   1555 ;	quantum/vial.c:378: break;
      00B514 22               [24] 1556 	ret
                                   1557 ;	quantum/vial.c:382: case dynamic_vial_combo_get: {
      00B515                       1558 00126$:
                                   1559 ;	quantum/vial.c:383: uint8_t idx = msg[3];
      00B515 12 48 81         [24] 1560 	lcall	_ak820_outline_0015
      00B518 FB               [12] 1561 	mov	r3,a
                                   1562 ;	quantum/vial.c:384: vial_combo_entry_t entry = { { 0 }, 0 };
      00B519 90 0D 24         [24] 1563 	mov	dptr,#_vial_handle_cmd_entry_70000_649
      00B51C 12 48 D9         [24] 1564 	lcall	_ak820_outline_0143
      00B51F 90 0D 26         [24] 1565 	mov	dptr,#(_vial_handle_cmd_entry_70000_649 + 0x0002)
      00B522 F0               [24] 1566 	movx	@dptr,a
      00B523 A3               [24] 1567 	inc	dptr
      00B524 F0               [24] 1568 	movx	@dptr,a
      00B525 90 0D 28         [24] 1569 	mov	dptr,#(_vial_handle_cmd_entry_70000_649 + 0x0004)
      00B528 F0               [24] 1570 	movx	@dptr,a
      00B529 A3               [24] 1571 	inc	dptr
      00B52A F0               [24] 1572 	movx	@dptr,a
      00B52B 90 0D 2A         [24] 1573 	mov	dptr,#(_vial_handle_cmd_entry_70000_649 + 0x0006)
      00B52E F0               [24] 1574 	movx	@dptr,a
      00B52F A3               [24] 1575 	inc	dptr
      00B530 F0               [24] 1576 	movx	@dptr,a
      00B531 90 0D 2C         [24] 1577 	mov	dptr,#(_vial_handle_cmd_entry_70000_649 + 0x0008)
      00B534 F0               [24] 1578 	movx	@dptr,a
      00B535 A3               [24] 1579 	inc	dptr
      00B536 F0               [24] 1580 	movx	@dptr,a
                                   1581 ;	quantum/vial.c:385: msg[0] = dynamic_keymap_get_combo(idx, &entry);
      00B537 90 0B B5         [24] 1582 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      00B53A 74 24            [12] 1583 	mov	a,#_vial_handle_cmd_entry_70000_649
      00B53C F0               [24] 1584 	movx	@dptr,a
      00B53D 74 0D            [12] 1585 	mov	a,#(_vial_handle_cmd_entry_70000_649 >> 8)
      00B53F 12 38 1C         [24] 1586 	lcall	_ak820_outline_0075
      00B542 8B 82            [24] 1587 	mov	dpl, r3
      00B544 C0 07            [24] 1588 	push	ar7
      00B546 C0 06            [24] 1589 	push	ar6
      00B548 C0 05            [24] 1590 	push	ar5
      00B54A C0 04            [24] 1591 	push	ar4
      00B54C 12 8A 93         [24] 1592 	lcall	_dynamic_keymap_get_combo
      00B54F AA 82            [24] 1593 	mov	r2, dpl
      00B551 D0 04            [24] 1594 	pop	ar4
      00B553 D0 05            [24] 1595 	pop	ar5
      00B555 D0 06            [24] 1596 	pop	ar6
      00B557 D0 07            [24] 1597 	pop	ar7
      00B559 12 43 23         [24] 1598 	lcall	_ak820_outline_0119
      00B55C EA               [12] 1599 	mov	a,r2
      00B55D F0               [24] 1600 	movx	@dptr,a
                                   1601 ;	quantum/vial.c:386: memcpy(&msg[1], &entry, sizeof(entry));
      00B55E 7B 00            [12] 1602 	mov	r3,#0x00
      00B560 90 0E 60         [24] 1603 	mov	dptr,#___memcpy_PARM_2
      00B563 74 24            [12] 1604 	mov	a,#_vial_handle_cmd_entry_70000_649
      00B565 F0               [24] 1605 	movx	@dptr,a
      00B566 74 0D            [12] 1606 	mov	a,#(_vial_handle_cmd_entry_70000_649 >> 8)
      00B568 12 B6 B8         [24] 1607 	lcall	_ak820_outline_0011
      00B56B 12 38 51         [24] 1608 	lcall	_ak820_outline_0123
      00B56E 8B F0            [24] 1609 	mov	b, r3
                                   1610 ;	quantum/vial.c:387: break;
      00B570 02 BC 8E         [24] 1611 	ljmp	___memcpy
                                   1612 ;	quantum/vial.c:389: case dynamic_vial_combo_set: {
      00B573                       1613 00127$:
                                   1614 ;	quantum/vial.c:390: uint8_t idx = msg[3];
      00B573 12 48 81         [24] 1615 	lcall	_ak820_outline_0015
      00B576 FD               [12] 1616 	mov	r5,a
                                   1617 ;	quantum/vial.c:392: memcpy(&entry, &msg[4], sizeof(entry));
      00B577 74 04            [12] 1618 	mov	a,#0x04
      00B579 2E               [12] 1619 	add	a, r6
      00B57A FB               [12] 1620 	mov	r3,a
      00B57B E4               [12] 1621 	clr	a
      00B57C 3F               [12] 1622 	addc	a, r7
      00B57D FC               [12] 1623 	mov	r4,a
      00B57E 90 0E 60         [24] 1624 	mov	dptr,#___memcpy_PARM_2
      00B581 EB               [12] 1625 	mov	a,r3
      00B582 F0               [24] 1626 	movx	@dptr,a
      00B583 EC               [12] 1627 	mov	a,r4
      00B584 12 B6 B8         [24] 1628 	lcall	_ak820_outline_0011
      00B587 90 0D 2E         [24] 1629 	mov	dptr,#_vial_handle_cmd_entry_70000_650
      00B58A F5 F0            [12] 1630 	mov	b,a
      00B58C C0 07            [24] 1631 	push	ar7
      00B58E C0 06            [24] 1632 	push	ar6
      00B590 C0 05            [24] 1633 	push	ar5
      00B592 12 BC 8E         [24] 1634 	lcall	___memcpy
                                   1635 ;	quantum/vial.c:393: entry.output = vial_keycode_firewall(entry.output);
      00B595 90 0D 36         [24] 1636 	mov	dptr,#(_vial_handle_cmd_entry_70000_650 + 0x0008)
      00B598 12 38 41         [24] 1637 	lcall	_ak820_outline_0103
      00B59B 12 33 FC         [24] 1638 	lcall	_ak820_outline_0124
      00B59E 12 B1 11         [24] 1639 	lcall	_vial_keycode_firewall
      00B5A1 AB 82            [24] 1640 	mov	r3, dpl
      00B5A3 AC 83            [24] 1641 	mov	r4, dph
      00B5A5 D0 05            [24] 1642 	pop	ar5
      00B5A7 90 0D 36         [24] 1643 	mov	dptr,#(_vial_handle_cmd_entry_70000_650 + 0x0008)
      00B5AA 12 38 2F         [24] 1644 	lcall	_ak820_outline_0081
                                   1645 ;	quantum/vial.c:394: msg[0] = dynamic_keymap_set_combo(idx, &entry);
      00B5AD 90 0B B9         [24] 1646 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      00B5B0 74 2E            [12] 1647 	mov	a,#_vial_handle_cmd_entry_70000_650
      00B5B2 F0               [24] 1648 	movx	@dptr,a
      00B5B3 74 0D            [12] 1649 	mov	a,#(_vial_handle_cmd_entry_70000_650 >> 8)
      00B5B5 12 38 1C         [24] 1650 	lcall	_ak820_outline_0075
      00B5B8 8D 82            [24] 1651 	mov	dpl, r5
      00B5BA 12 8B 29         [24] 1652 	lcall	_dynamic_keymap_set_combo
      00B5BD AC 82            [24] 1653 	mov	r4, dpl
      00B5BF D0 06            [24] 1654 	pop	ar6
      00B5C1 D0 07            [24] 1655 	pop	ar7
      00B5C3 12 43 23         [24] 1656 	lcall	_ak820_outline_0119
      00B5C6 EC               [12] 1657 	mov	a,r4
      00B5C7 F0               [24] 1658 	movx	@dptr,a
                                   1659 ;	quantum/vial.c:395: if (!msg[0]) reload_combo();
      00B5C8 EC               [12] 1660 	mov	a,r4
      00B5C9 70 03            [24] 1661 	jnz	00141$
                                   1662 ;	quantum/vial.c:423: }
                                   1663 ;	quantum/vial.c:424: }
      00B5CB 02 35 37         [24] 1664 	ljmp	_ak820_combo_reload
      00B5CE                       1665 00141$:
      00B5CE 22               [24] 1666 	ret
                                   1667 ;------------------------------------------------------------
                                   1668 ;Allocation info for local variables in function 'vial_keycode_down'
                                   1669 ;------------------------------------------------------------
                                   1670 ;keycode       Allocated with name '_vial_keycode_down_keycode_10000_652'
                                   1671 ;dummy_event   Allocated with name '_vial_keycode_down_dummy_event_30000_659'
                                   1672 ;------------------------------------------------------------
                                   1673 ;	quantum/vial.c:428: void vial_keycode_down(uint16_t keycode) {
                                   1674 ;	-----------------------------------------
                                   1675 ;	 function vial_keycode_down
                                   1676 ;	-----------------------------------------
      00B5CF                       1677 _vial_keycode_down:
      00B5CF 12 38 4C         [24] 1678 	lcall	_ak820_outline_0106
      00B5D2 90 0D 3A         [24] 1679 	mov	dptr,#_vial_keycode_down_keycode_10000_652
      00B5D5 12 38 47         [24] 1680 	lcall	_ak820_outline_0105
                                   1681 ;	quantum/vial.c:432: if (keycode >= QK_MOD_TAP && keycode <= QK_LAYER_TAP_MAX) {
      00B5D8 90 0D 3A         [24] 1682 	mov	dptr,#_vial_keycode_down_keycode_10000_652
      00B5DB 12 37 C2         [24] 1683 	lcall	_ak820_outline_0010
      00B5DE 74 E0            [12] 1684 	mov	a,#0x100 - 0x20
      00B5E0 2D               [12] 1685 	add	a,r5
      00B5E1 50 19            [24] 1686 	jnc	00104$
      00B5E3 C3               [12] 1687 	clr	c
      00B5E4 74 FF            [12] 1688 	mov	a,#0xff
      00B5E6 9C               [12] 1689 	subb	a,r4
      00B5E7 74 4F            [12] 1690 	mov	a,#0x4f
      00B5E9 9D               [12] 1691 	subb	a,r5
      00B5EA 40 10            [24] 1692 	jc	00104$
                                   1693 ;	free result
                                   1694 ;	quantum/vial.c:433: keycode = (uint8_t)keycode;
      00B5EC 90 0D 3A         [24] 1695 	mov	dptr,#_vial_keycode_down_keycode_10000_652
      00B5EF EE               [12] 1696 	mov	a,r6
      00B5F0 12 38 5C         [24] 1697 	lcall	_ak820_outline_0127
                                   1698 ;	quantum/vial.c:434: if (keycode <= KC_TRANSPARENT) return;
      00B5F3 90 0D 3A         [24] 1699 	mov	dptr,#_vial_keycode_down_keycode_10000_652
      00B5F6 E0               [24] 1700 	movx	a,@dptr
      00B5F7 24 FE            [12] 1701 	add	a,#0xff - 0x01
      00B5F9 40 01            [24] 1702 	jc	00104$
                                   1703 ;	free result
      00B5FB 22               [24] 1704 	ret
      00B5FC                       1705 00104$:
                                   1706 ;	quantum/vial.c:437: g_vial_magic_keycode_override = keycode;
      00B5FC 90 0D 3A         [24] 1707 	mov	dptr,#_vial_keycode_down_keycode_10000_652
      00B5FF 12 B6 C7         [24] 1708 	lcall	_ak820_outline_0025
                                   1709 ;	quantum/vial.c:439: if (keycode <= QK_MODS_MAX) {
      00B602 40 06            [24] 1710 	jc	00107$
                                   1711 ;	free result
                                   1712 ;	quantum/vial.c:440: register_code16(keycode);
      00B604 12 43 23         [24] 1713 	lcall	_ak820_outline_0119
      00B607 02 A2 50         [24] 1714 	ljmp	_register_code16
      00B60A                       1715 00107$:
                                   1716 ;	quantum/vial.c:442: keyevent_t dummy_event = {
      00B60A 90 0D 40         [24] 1717 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_659 + 0x0004)
      00B60D 74 01            [12] 1718 	mov	a,#0x01
      00B60F F0               [24] 1719 	movx	@dptr,a
      00B610 90 0D 3D         [24] 1720 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_659 + 0x0001)
      00B613 74 F0            [12] 1721 	mov	a,#0xf0
      00B615 F0               [24] 1722 	movx	@dptr,a
      00B616 90 0D 3C         [24] 1723 	mov	dptr,#_vial_keycode_down_dummy_event_30000_659
      00B619 F0               [24] 1724 	movx	@dptr,a
      00B61A 90 0D 41         [24] 1725 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_659 + 0x0005)
      00B61D 74 01            [12] 1726 	mov	a,#0x01
      00B61F F0               [24] 1727 	movx	@dptr,a
      00B620 12 4E 40         [24] 1728 	lcall	_timer_read
      00B623 12 43 2D         [24] 1729 	lcall	_ak820_outline_0136
      00B626 43 06 01         [24] 1730 	orl	ar6,#0x01
      00B629 90 0D 3E         [24] 1731 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_659 + 0x0002)
      00B62C 12 48 CB         [24] 1732 	lcall	_ak820_outline_0064
                                   1733 ;	quantum/vial.c:446: AK820_ACTION_EXEC(dummy_event);
      00B62F 90 0D 3C         [24] 1734 	mov	dptr,#_vial_keycode_down_dummy_event_30000_659
                                   1735 ;	quantum/vial.c:448: }
      00B632 02 75 35         [24] 1736 	ljmp	_ak820_action_exec
                                   1737 ;------------------------------------------------------------
                                   1738 ;Allocation info for local variables in function 'vial_keycode_up'
                                   1739 ;------------------------------------------------------------
                                   1740 ;keycode       Allocated with name '_vial_keycode_up_keycode_10000_660'
                                   1741 ;dummy_event   Allocated with name '_vial_keycode_up_dummy_event_30000_667'
                                   1742 ;------------------------------------------------------------
                                   1743 ;	quantum/vial.c:450: void vial_keycode_up(uint16_t keycode) {
                                   1744 ;	-----------------------------------------
                                   1745 ;	 function vial_keycode_up
                                   1746 ;	-----------------------------------------
      00B635                       1747 _vial_keycode_up:
      00B635 12 38 4C         [24] 1748 	lcall	_ak820_outline_0106
      00B638 90 0D 42         [24] 1749 	mov	dptr,#_vial_keycode_up_keycode_10000_660
      00B63B 12 38 47         [24] 1750 	lcall	_ak820_outline_0105
                                   1751 ;	quantum/vial.c:454: if (keycode >= QK_MOD_TAP && keycode <= QK_LAYER_TAP_MAX) {
      00B63E 90 0D 42         [24] 1752 	mov	dptr,#_vial_keycode_up_keycode_10000_660
      00B641 12 37 C2         [24] 1753 	lcall	_ak820_outline_0010
      00B644 74 E0            [12] 1754 	mov	a,#0x100 - 0x20
      00B646 2D               [12] 1755 	add	a,r5
      00B647 50 19            [24] 1756 	jnc	00104$
      00B649 C3               [12] 1757 	clr	c
      00B64A 74 FF            [12] 1758 	mov	a,#0xff
      00B64C 9C               [12] 1759 	subb	a,r4
      00B64D 74 4F            [12] 1760 	mov	a,#0x4f
      00B64F 9D               [12] 1761 	subb	a,r5
      00B650 40 10            [24] 1762 	jc	00104$
                                   1763 ;	free result
                                   1764 ;	quantum/vial.c:455: keycode = (uint8_t)keycode;
      00B652 90 0D 42         [24] 1765 	mov	dptr,#_vial_keycode_up_keycode_10000_660
      00B655 EE               [12] 1766 	mov	a,r6
      00B656 12 38 5C         [24] 1767 	lcall	_ak820_outline_0127
                                   1768 ;	quantum/vial.c:456: if (keycode <= KC_TRANSPARENT) return;
      00B659 90 0D 42         [24] 1769 	mov	dptr,#_vial_keycode_up_keycode_10000_660
      00B65C E0               [24] 1770 	movx	a,@dptr
      00B65D 24 FE            [12] 1771 	add	a,#0xff - 0x01
      00B65F 40 01            [24] 1772 	jc	00104$
                                   1773 ;	free result
      00B661 22               [24] 1774 	ret
      00B662                       1775 00104$:
                                   1776 ;	quantum/vial.c:459: g_vial_magic_keycode_override = keycode;
      00B662 90 0D 42         [24] 1777 	mov	dptr,#_vial_keycode_up_keycode_10000_660
      00B665 12 B6 C7         [24] 1778 	lcall	_ak820_outline_0025
                                   1779 ;	quantum/vial.c:461: if (keycode <= QK_MODS_MAX) {
      00B668 40 06            [24] 1780 	jc	00107$
                                   1781 ;	free result
                                   1782 ;	quantum/vial.c:462: unregister_code16(keycode);
      00B66A 12 43 23         [24] 1783 	lcall	_ak820_outline_0119
      00B66D 02 A2 94         [24] 1784 	ljmp	_unregister_code16
      00B670                       1785 00107$:
                                   1786 ;	quantum/vial.c:464: keyevent_t dummy_event = {
      00B670 90 0D 48         [24] 1787 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_667 + 0x0004)
      00B673 74 01            [12] 1788 	mov	a,#0x01
      00B675 F0               [24] 1789 	movx	@dptr,a
      00B676 90 0D 45         [24] 1790 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_667 + 0x0001)
      00B679 74 F0            [12] 1791 	mov	a,#0xf0
      00B67B F0               [24] 1792 	movx	@dptr,a
      00B67C 90 0D 44         [24] 1793 	mov	dptr,#_vial_keycode_up_dummy_event_30000_667
      00B67F F0               [24] 1794 	movx	@dptr,a
      00B680 90 0D 49         [24] 1795 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_667 + 0x0005)
      00B683 E4               [12] 1796 	clr	a
      00B684 F0               [24] 1797 	movx	@dptr,a
      00B685 12 4E 40         [24] 1798 	lcall	_timer_read
      00B688 12 43 2D         [24] 1799 	lcall	_ak820_outline_0136
      00B68B 43 06 01         [24] 1800 	orl	ar6,#0x01
      00B68E 90 0D 46         [24] 1801 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_667 + 0x0002)
      00B691 12 48 CB         [24] 1802 	lcall	_ak820_outline_0064
                                   1803 ;	quantum/vial.c:468: AK820_ACTION_EXEC(dummy_event);
      00B694 90 0D 44         [24] 1804 	mov	dptr,#_vial_keycode_up_dummy_event_30000_667
                                   1805 ;	quantum/vial.c:470: }
      00B697 02 75 35         [24] 1806 	ljmp	_ak820_action_exec
                                   1807 ;------------------------------------------------------------
                                   1808 ;Allocation info for local variables in function 'vial_keycode_tap'
                                   1809 ;------------------------------------------------------------
                                   1810 ;keycode       Allocated with name '_vial_keycode_tap_keycode_10000_668'
                                   1811 ;i             Allocated with name '_vial_keycode_tap_i_30000_671'
                                   1812 ;------------------------------------------------------------
                                   1813 ;	quantum/vial.c:472: void vial_keycode_tap(uint16_t keycode) {
                                   1814 ;	-----------------------------------------
                                   1815 ;	 function vial_keycode_tap
                                   1816 ;	-----------------------------------------
      00B69A                       1817 _vial_keycode_tap:
      00B69A 12 38 4C         [24] 1818 	lcall	_ak820_outline_0106
      00B69D 90 0D 4A         [24] 1819 	mov	dptr,#_vial_keycode_tap_keycode_10000_668
      00B6A0 12 38 47         [24] 1820 	lcall	_ak820_outline_0105
                                   1821 ;	quantum/vial.c:473: vial_keycode_down(keycode);
      00B6A3 90 0D 4A         [24] 1822 	mov	dptr,#_vial_keycode_tap_keycode_10000_668
      00B6A6 12 37 A8         [24] 1823 	lcall	_ak820_outline_0005
      00B6A9 C0 07            [24] 1824 	push	ar7
      00B6AB C0 06            [24] 1825 	push	ar6
      00B6AD B1 CF            [12] 1826 	acall	_vial_keycode_down
      00B6AF D0 06            [24] 1827 	pop	ar6
      00B6B1 D0 07            [24] 1828 	pop	ar7
                                   1829 ;	quantum/vial.c:475: vial_keycode_up(keycode);
      00B6B3 12 43 23         [24] 1830 	lcall	_ak820_outline_0119
                                   1831 ;	quantum/vial.c:476: }
      00B6B6 C1 35            [12] 1832 	ajmp	_vial_keycode_up
                                   1833 ;------------------------------------------------------------
                                   1834 ;Allocation info for local variables in function 'process_record_vial'
                                   1835 ;------------------------------------------------------------
                                   1836 ;record        Allocated with name '_process_record_vial_PARM_2'
                                   1837 ;keycode       Allocated with name '_process_record_vial_keycode_10000_673'
                                   1838 ;------------------------------------------------------------
                                   1839 ;	quantum/vial.c:686: bool process_record_vial(uint16_t keycode, keyrecord_t *record) {
                                   1840 ;	-----------------------------------------
                                   1841 	.area CSEG    (CODE)
                                   1842 	.area CONST   (CODE)
                                   1843 	.area CONST   (CODE)
      00C20C                       1844 _keyboard_definition:
      00C20C FD                    1845 	.db #0xfd	; 253
      00C20D 37                    1846 	.db #0x37	; 55	'7'
      00C20E 7A                    1847 	.db #0x7a	; 122	'z'
      00C20F 58                    1848 	.db #0x58	; 88	'X'
      00C210 5A                    1849 	.db #0x5a	; 90	'Z'
      00C211 00                    1850 	.db #0x00	; 0
      00C212 00                    1851 	.db #0x00	; 0
      00C213 04                    1852 	.db #0x04	; 4
      00C214 E6                    1853 	.db #0xe6	; 230
      00C215 D6                    1854 	.db #0xd6	; 214
      00C216 B4                    1855 	.db #0xb4	; 180
      00C217 46                    1856 	.db #0x46	; 70	'F'
      00C218 02                    1857 	.db #0x02	; 2
      00C219 00                    1858 	.db #0x00	; 0
      00C21A 21                    1859 	.db #0x21	; 33
      00C21B 01                    1860 	.db #0x01	; 1
      00C21C 00                    1861 	.db #0x00	; 0
      00C21D 00                    1862 	.db #0x00	; 0
      00C21E 00                    1863 	.db #0x00	; 0
      00C21F 00                    1864 	.db #0x00	; 0
      00C220 37                    1865 	.db #0x37	; 55	'7'
      00C221 27                    1866 	.db #0x27	; 39
      00C222 97                    1867 	.db #0x97	; 151
      00C223 D6                    1868 	.db #0xd6	; 214
      00C224 E0                    1869 	.db #0xe0	; 224
      00C225 03                    1870 	.db #0x03	; 3
      00C226 CB                    1871 	.db #0xcb	; 203
      00C227 01                    1872 	.db #0x01	; 1
      00C228 3C                    1873 	.db #0x3c	; 60
      00C229 00                    1874 	.db #0x00	; 0
      00C22A 00                    1875 	.db #0x00	; 0
      00C22B 3D                    1876 	.db #0x3d	; 61
      00C22C 88                    1877 	.db #0x88	; 136
      00C22D CD                    1878 	.db #0xcd	; 205
      00C22E A5                    1879 	.db #0xa5	; 165
      00C22F AA                    1880 	.db #0xaa	; 170
      00C230 E5                    1881 	.db #0xe5	; 229
      00C231 A8                    1882 	.db #0xa8	; 168
      00C232 76                    1883 	.db #0x76	; 118	'v'
      00C233 F6                    1884 	.db #0xf6	; 246
      00C234 43                    1885 	.db #0x43	; 67	'C'
      00C235 0E                    1886 	.db #0x0e	; 14
      00C236 D2                    1887 	.db #0xd2	; 210
      00C237 90                    1888 	.db #0x90	; 144
      00C238 7D                    1889 	.db #0x7d	; 125
      00C239 94                    1890 	.db #0x94	; 148
      00C23A 79                    1891 	.db #0x79	; 121	'y'
      00C23B 78                    1892 	.db #0x78	; 120	'x'
      00C23C EF                    1893 	.db #0xef	; 239
      00C23D 49                    1894 	.db #0x49	; 73	'I'
      00C23E 3E                    1895 	.db #0x3e	; 62
      00C23F EF                    1896 	.db #0xef	; 239
      00C240 FD                    1897 	.db #0xfd	; 253
      00C241 8F                    1898 	.db #0x8f	; 143
      00C242 EF                    1899 	.db #0xef	; 239
      00C243 00                    1900 	.db #0x00	; 0
      00C244 C6                    1901 	.db #0xc6	; 198
      00C245 D1                    1902 	.db #0xd1	; 209
      00C246 DB                    1903 	.db #0xdb	; 219
      00C247 FB                    1904 	.db #0xfb	; 251
      00C248 EB                    1905 	.db #0xeb	; 235
      00C249 DE                    1906 	.db #0xde	; 222
      00C24A 66                    1907 	.db #0x66	; 102	'f'
      00C24B 63                    1908 	.db #0x63	; 99	'c'
      00C24C 0C                    1909 	.db #0x0c	; 12
      00C24D 92                    1910 	.db #0x92	; 146
      00C24E 7B                    1911 	.db #0x7b	; 123
      00C24F F9                    1912 	.db #0xf9	; 249
      00C250 D4                    1913 	.db #0xd4	; 212
      00C251 7A                    1914 	.db #0x7a	; 122	'z'
      00C252 4F                    1915 	.db #0x4f	; 79	'O'
      00C253 83                    1916 	.db #0x83	; 131
      00C254 4B                    1917 	.db #0x4b	; 75	'K'
      00C255 86                    1918 	.db #0x86	; 134
      00C256 0E                    1919 	.db #0x0e	; 14
      00C257 6A                    1920 	.db #0x6a	; 106	'j'
      00C258 F2                    1921 	.db #0xf2	; 242
      00C259 22                    1922 	.db #0x22	; 34
      00C25A 22                    1923 	.db #0x22	; 34
      00C25B 0B                    1924 	.db #0x0b	; 11
      00C25C 03                    1925 	.db #0x03	; 3
      00C25D BA                    1926 	.db #0xba	; 186
      00C25E 67                    1927 	.db #0x67	; 103	'g'
      00C25F 9B                    1928 	.db #0x9b	; 155
      00C260 7A                    1929 	.db #0x7a	; 122	'z'
      00C261 E1                    1930 	.db #0xe1	; 225
      00C262 BC                    1931 	.db #0xbc	; 188
      00C263 37                    1932 	.db #0x37	; 55	'7'
      00C264 26                    1933 	.db #0x26	; 38
      00C265 46                    1934 	.db #0x46	; 70	'F'
      00C266 78                    1935 	.db #0x78	; 120	'x'
      00C267 05                    1936 	.db #0x05	; 5
      00C268 0D                    1937 	.db #0x0d	; 13
      00C269 95                    1938 	.db #0x95	; 149
      00C26A 02                    1939 	.db #0x02	; 2
      00C26B E4                    1940 	.db #0xe4	; 228
      00C26C 18                    1941 	.db #0x18	; 24
      00C26D CA                    1942 	.db #0xca	; 202
      00C26E 33                    1943 	.db #0x33	; 51	'3'
      00C26F EA                    1944 	.db #0xea	; 234
      00C270 24                    1945 	.db #0x24	; 36
      00C271 C8                    1946 	.db #0xc8	; 200
      00C272 81                    1947 	.db #0x81	; 129
      00C273 4E                    1948 	.db #0x4e	; 78	'N'
      00C274 47                    1949 	.db #0x47	; 71	'G'
      00C275 A8                    1950 	.db #0xa8	; 168
      00C276 44                    1951 	.db #0x44	; 68	'D'
      00C277 DD                    1952 	.db #0xdd	; 221
      00C278 91                    1953 	.db #0x91	; 145
      00C279 6D                    1954 	.db #0x6d	; 109	'm'
      00C27A 69                    1955 	.db #0x69	; 105	'i'
      00C27B DB                    1956 	.db #0xdb	; 219
      00C27C 4F                    1957 	.db #0x4f	; 79	'O'
      00C27D 3A                    1958 	.db #0x3a	; 58
      00C27E 43                    1959 	.db #0x43	; 67	'C'
      00C27F 9D                    1960 	.db #0x9d	; 157
      00C280 26                    1961 	.db #0x26	; 38
      00C281 49                    1962 	.db #0x49	; 73	'I'
      00C282 4C                    1963 	.db #0x4c	; 76	'L'
      00C283 EF                    1964 	.db #0xef	; 239
      00C284 2B                    1965 	.db #0x2b	; 43
      00C285 D8                    1966 	.db #0xd8	; 216
      00C286 55                    1967 	.db #0x55	; 85	'U'
      00C287 95                    1968 	.db #0x95	; 149
      00C288 70                    1969 	.db #0x70	; 112	'p'
      00C289 B1                    1970 	.db #0xb1	; 177
      00C28A CC                    1971 	.db #0xcc	; 204
      00C28B CF                    1972 	.db #0xcf	; 207
      00C28C 13                    1973 	.db #0x13	; 19
      00C28D 32                    1974 	.db #0x32	; 50	'2'
      00C28E 6A                    1975 	.db #0x6a	; 106	'j'
      00C28F A1                    1976 	.db #0xa1	; 161
      00C290 FF                    1977 	.db #0xff	; 255
      00C291 99                    1978 	.db #0x99	; 153
      00C292 61                    1979 	.db #0x61	; 97	'a'
      00C293 95                    1980 	.db #0x95	; 149
      00C294 B1                    1981 	.db #0xb1	; 177
      00C295 89                    1982 	.db #0x89	; 137
      00C296 9B                    1983 	.db #0x9b	; 155
      00C297 11                    1984 	.db #0x11	; 17
      00C298 D9                    1985 	.db #0xd9	; 217
      00C299 35                    1986 	.db #0x35	; 53	'5'
      00C29A 78                    1987 	.db #0x78	; 120	'x'
      00C29B ED                    1988 	.db #0xed	; 237
      00C29C CD                    1989 	.db #0xcd	; 205
      00C29D 94                    1990 	.db #0x94	; 148
      00C29E 6E                    1991 	.db #0x6e	; 110	'n'
      00C29F 60                    1992 	.db #0x60	; 96
      00C2A0 8E                    1993 	.db #0x8e	; 142
      00C2A1 63                    1994 	.db #0x63	; 99	'c'
      00C2A2 8B                    1995 	.db #0x8b	; 139
      00C2A3 FF                    1996 	.db #0xff	; 255
      00C2A4 4E                    1997 	.db #0x4e	; 78	'N'
      00C2A5 20                    1998 	.db #0x20	; 32
      00C2A6 7A                    1999 	.db #0x7a	; 122	'z'
      00C2A7 B5                    2000 	.db #0xb5	; 181
      00C2A8 87                    2001 	.db #0x87	; 135
      00C2A9 C2                    2002 	.db #0xc2	; 194
      00C2AA 35                    2003 	.db #0x35	; 53	'5'
      00C2AB A4                    2004 	.db #0xa4	; 164
      00C2AC 6D                    2005 	.db #0x6d	; 109	'm'
      00C2AD 18                    2006 	.db #0x18	; 24
      00C2AE C1                    2007 	.db #0xc1	; 193
      00C2AF A3                    2008 	.db #0xa3	; 163
      00C2B0 DB                    2009 	.db #0xdb	; 219
      00C2B1 53                    2010 	.db #0x53	; 83	'S'
      00C2B2 1D                    2011 	.db #0x1d	; 29
      00C2B3 EC                    2012 	.db #0xec	; 236
      00C2B4 F0                    2013 	.db #0xf0	; 240
      00C2B5 BF                    2014 	.db #0xbf	; 191
      00C2B6 4A                    2015 	.db #0x4a	; 74	'J'
      00C2B7 4C                    2016 	.db #0x4c	; 76	'L'
      00C2B8 4A                    2017 	.db #0x4a	; 74	'J'
      00C2B9 C4                    2018 	.db #0xc4	; 196
      00C2BA AA                    2019 	.db #0xaa	; 170
      00C2BB 37                    2020 	.db #0x37	; 55	'7'
      00C2BC 19                    2021 	.db #0x19	; 25
      00C2BD 34                    2022 	.db #0x34	; 52	'4'
      00C2BE 3F                    2023 	.db #0x3f	; 63
      00C2BF A1                    2024 	.db #0xa1	; 161
      00C2C0 D3                    2025 	.db #0xd3	; 211
      00C2C1 1A                    2026 	.db #0x1a	; 26
      00C2C2 5C                    2027 	.db #0x5c	; 92
      00C2C3 03                    2028 	.db #0x03	; 3
      00C2C4 4D                    2029 	.db #0x4d	; 77	'M'
      00C2C5 BC                    2030 	.db #0xbc	; 188
      00C2C6 10                    2031 	.db #0x10	; 16
      00C2C7 2E                    2032 	.db #0x2e	; 46
      00C2C8 80                    2033 	.db #0x80	; 128
      00C2C9 F7                    2034 	.db #0xf7	; 247
      00C2CA D6                    2035 	.db #0xd6	; 214
      00C2CB 82                    2036 	.db #0x82	; 130
      00C2CC 24                    2037 	.db #0x24	; 36
      00C2CD 4C                    2038 	.db #0x4c	; 76	'L'
      00C2CE 87                    2039 	.db #0x87	; 135
      00C2CF B9                    2040 	.db #0xb9	; 185
      00C2D0 F8                    2041 	.db #0xf8	; 248
      00C2D1 BE                    2042 	.db #0xbe	; 190
      00C2D2 67                    2043 	.db #0x67	; 103	'g'
      00C2D3 96                    2044 	.db #0x96	; 150
      00C2D4 89                    2045 	.db #0x89	; 137
      00C2D5 30                    2046 	.db #0x30	; 48	'0'
      00C2D6 C8                    2047 	.db #0xc8	; 200
      00C2D7 8D                    2048 	.db #0x8d	; 141
      00C2D8 2C                    2049 	.db #0x2c	; 44
      00C2D9 F5                    2050 	.db #0xf5	; 245
      00C2DA 06                    2051 	.db #0x06	; 6
      00C2DB 05                    2052 	.db #0x05	; 5
      00C2DC 7C                    2053 	.db #0x7c	; 124
      00C2DD 48                    2054 	.db #0x48	; 72	'H'
      00C2DE 1B                    2055 	.db #0x1b	; 27
      00C2DF 76                    2056 	.db #0x76	; 118	'v'
      00C2E0 AA                    2057 	.db #0xaa	; 170
      00C2E1 3D                    2058 	.db #0x3d	; 61
      00C2E2 28                    2059 	.db #0x28	; 40
      00C2E3 FC                    2060 	.db #0xfc	; 252
      00C2E4 80                    2061 	.db #0x80	; 128
      00C2E5 75                    2062 	.db #0x75	; 117	'u'
      00C2E6 EB                    2063 	.db #0xeb	; 235
      00C2E7 78                    2064 	.db #0x78	; 120	'x'
      00C2E8 D0                    2065 	.db #0xd0	; 208
      00C2E9 8A                    2066 	.db #0x8a	; 138
      00C2EA 8F                    2067 	.db #0x8f	; 143
      00C2EB 27                    2068 	.db #0x27	; 39
      00C2EC F7                    2069 	.db #0xf7	; 247
      00C2ED F2                    2070 	.db #0xf2	; 242
      00C2EE EB                    2071 	.db #0xeb	; 235
      00C2EF 58                    2072 	.db #0x58	; 88	'X'
      00C2F0 37                    2073 	.db #0x37	; 55	'7'
      00C2F1 3C                    2074 	.db #0x3c	; 60
      00C2F2 2B                    2075 	.db #0x2b	; 43
      00C2F3 6F                    2076 	.db #0x6f	; 111	'o'
      00C2F4 0E                    2077 	.db #0x0e	; 14
      00C2F5 C7                    2078 	.db #0xc7	; 199
      00C2F6 E2                    2079 	.db #0xe2	; 226
      00C2F7 A0                    2080 	.db #0xa0	; 160
      00C2F8 97                    2081 	.db #0x97	; 151
      00C2F9 EE                    2082 	.db #0xee	; 238
      00C2FA FD                    2083 	.db #0xfd	; 253
      00C2FB 9F                    2084 	.db #0x9f	; 159
      00C2FC 45                    2085 	.db #0x45	; 69	'E'
      00C2FD 17                    2086 	.db #0x17	; 23
      00C2FE 94                    2087 	.db #0x94	; 148
      00C2FF E6                    2088 	.db #0xe6	; 230
      00C300 E7                    2089 	.db #0xe7	; 231
      00C301 FA                    2090 	.db #0xfa	; 250
      00C302 4C                    2091 	.db #0x4c	; 76	'L'
      00C303 7A                    2092 	.db #0x7a	; 122	'z'
      00C304 D6                    2093 	.db #0xd6	; 214
      00C305 7A                    2094 	.db #0x7a	; 122	'z'
      00C306 7B                    2095 	.db #0x7b	; 123
      00C307 ED                    2096 	.db #0xed	; 237
      00C308 10                    2097 	.db #0x10	; 16
      00C309 C5                    2098 	.db #0xc5	; 197
      00C30A BC                    2099 	.db #0xbc	; 188
      00C30B E3                    2100 	.db #0xe3	; 227
      00C30C A9                    2101 	.db #0xa9	; 169
      00C30D 1F                    2102 	.db #0x1f	; 31
      00C30E CF                    2103 	.db #0xcf	; 207
      00C30F C4                    2104 	.db #0xc4	; 196
      00C310 9D                    2105 	.db #0x9d	; 157
      00C311 DC                    2106 	.db #0xdc	; 220
      00C312 45                    2107 	.db #0x45	; 69	'E'
      00C313 2A                    2108 	.db #0x2a	; 42
      00C314 69                    2109 	.db #0x69	; 105	'i'
      00C315 57                    2110 	.db #0x57	; 87	'W'
      00C316 8F                    2111 	.db #0x8f	; 143
      00C317 EC                    2112 	.db #0xec	; 236
      00C318 85                    2113 	.db #0x85	; 133
      00C319 6C                    2114 	.db #0x6c	; 108	'l'
      00C31A 43                    2115 	.db #0x43	; 67	'C'
      00C31B 1C                    2116 	.db #0x1c	; 28
      00C31C BA                    2117 	.db #0xba	; 186
      00C31D 89                    2118 	.db #0x89	; 137
      00C31E 68                    2119 	.db #0x68	; 104	'h'
      00C31F 4A                    2120 	.db #0x4a	; 74	'J'
      00C320 1C                    2121 	.db #0x1c	; 28
      00C321 91                    2122 	.db #0x91	; 145
      00C322 3F                    2123 	.db #0x3f	; 63
      00C323 D1                    2124 	.db #0xd1	; 209
      00C324 B3                    2125 	.db #0xb3	; 179
      00C325 96                    2126 	.db #0x96	; 150
      00C326 1D                    2127 	.db #0x1d	; 29
      00C327 7C                    2128 	.db #0x7c	; 124
      00C328 14                    2129 	.db #0x14	; 20
      00C329 77                    2130 	.db #0x77	; 119	'w'
      00C32A 9C                    2131 	.db #0x9c	; 156
      00C32B 74                    2132 	.db #0x74	; 116	't'
      00C32C 36                    2133 	.db #0x36	; 54	'6'
      00C32D FF                    2134 	.db #0xff	; 255
      00C32E 2C                    2135 	.db #0x2c	; 44
      00C32F 66                    2136 	.db #0x66	; 102	'f'
      00C330 AF                    2137 	.db #0xaf	; 175
      00C331 0F                    2138 	.db #0x0f	; 15
      00C332 3C                    2139 	.db #0x3c	; 60
      00C333 A2                    2140 	.db #0xa2	; 162
      00C334 23                    2141 	.db #0x23	; 35
      00C335 85                    2142 	.db #0x85	; 133
      00C336 05                    2143 	.db #0x05	; 5
      00C337 87                    2144 	.db #0x87	; 135
      00C338 DA                    2145 	.db #0xda	; 218
      00C339 61                    2146 	.db #0x61	; 97	'a'
      00C33A 5E                    2147 	.db #0x5e	; 94
      00C33B 42                    2148 	.db #0x42	; 66	'B'
      00C33C 54                    2149 	.db #0x54	; 84	'T'
      00C33D 60                    2150 	.db #0x60	; 96
      00C33E 23                    2151 	.db #0x23	; 35
      00C33F CA                    2152 	.db #0xca	; 202
      00C340 BC                    2153 	.db #0xbc	; 188
      00C341 B3                    2154 	.db #0xb3	; 179
      00C342 18                    2155 	.db #0x18	; 24
      00C343 1D                    2156 	.db #0x1d	; 29
      00C344 F8                    2157 	.db #0xf8	; 248
      00C345 0A                    2158 	.db #0x0a	; 10
      00C346 55                    2159 	.db #0x55	; 85	'U'
      00C347 CD                    2160 	.db #0xcd	; 205
      00C348 A3                    2161 	.db #0xa3	; 163
      00C349 DE                    2162 	.db #0xde	; 222
      00C34A FF                    2163 	.db #0xff	; 255
      00C34B B2                    2164 	.db #0xb2	; 178
      00C34C 2A                    2165 	.db #0x2a	; 42
      00C34D 35                    2166 	.db #0x35	; 53	'5'
      00C34E 00                    2167 	.db #0x00	; 0
      00C34F D6                    2168 	.db #0xd6	; 214
      00C350 7B                    2169 	.db #0x7b	; 123
      00C351 E8                    2170 	.db #0xe8	; 232
      00C352 F2                    2171 	.db #0xf2	; 242
      00C353 1A                    2172 	.db #0x1a	; 26
      00C354 BC                    2173 	.db #0xbc	; 188
      00C355 F5                    2174 	.db #0xf5	; 245
      00C356 7E                    2175 	.db #0x7e	; 126
      00C357 48                    2176 	.db #0x48	; 72	'H'
      00C358 72                    2177 	.db #0x72	; 114	'r'
      00C359 E0                    2178 	.db #0xe0	; 224
      00C35A E4                    2179 	.db #0xe4	; 228
      00C35B E0                    2180 	.db #0xe0	; 224
      00C35C 27                    2181 	.db #0x27	; 39
      00C35D 87                    2182 	.db #0x87	; 135
      00C35E 9A                    2183 	.db #0x9a	; 154
      00C35F 51                    2184 	.db #0x51	; 81	'Q'
      00C360 D4                    2185 	.db #0xd4	; 212
      00C361 DD                    2186 	.db #0xdd	; 221
      00C362 C3                    2187 	.db #0xc3	; 195
      00C363 AA                    2188 	.db #0xaa	; 170
      00C364 49                    2189 	.db #0x49	; 73	'I'
      00C365 5A                    2190 	.db #0x5a	; 90	'Z'
      00C366 2A                    2191 	.db #0x2a	; 42
      00C367 00                    2192 	.db #0x00	; 0
      00C368 A0                    2193 	.db #0xa0	; 160
      00C369 8C                    2194 	.db #0x8c	; 140
      00C36A FF                    2195 	.db #0xff	; 255
      00C36B 74                    2196 	.db #0x74	; 116	't'
      00C36C BF                    2197 	.db #0xbf	; 191
      00C36D EC                    2198 	.db #0xec	; 236
      00C36E 1D                    2199 	.db #0x1d	; 29
      00C36F F1                    2200 	.db #0xf1	; 241
      00C370 00                    2201 	.db #0x00	; 0
      00C371 01                    2202 	.db #0x01	; 1
      00C372 D8                    2203 	.db #0xd8	; 216
      00C373 02                    2204 	.db #0x02	; 2
      00C374 CC                    2205 	.db #0xcc	; 204
      00C375 07                    2206 	.db #0x07	; 7
      00C376 00                    2207 	.db #0x00	; 0
      00C377 00                    2208 	.db #0x00	; 0
      00C378 C4                    2209 	.db #0xc4	; 196
      00C379 5E                    2210 	.db #0x5e	; 94
      00C37A 2C                    2211 	.db #0x2c	; 44
      00C37B 7E                    2212 	.db #0x7e	; 126
      00C37C B1                    2213 	.db #0xb1	; 177
      00C37D C4                    2214 	.db #0xc4	; 196
      00C37E 67                    2215 	.db #0x67	; 103	'g'
      00C37F FB                    2216 	.db #0xfb	; 251
      00C380 02                    2217 	.db #0x02	; 2
      00C381 00                    2218 	.db #0x00	; 0
      00C382 00                    2219 	.db #0x00	; 0
      00C383 00                    2220 	.db #0x00	; 0
      00C384 00                    2221 	.db #0x00	; 0
      00C385 04                    2222 	.db #0x04	; 4
      00C386 59                    2223 	.db #0x59	; 89	'Y'
      00C387 5A                    2224 	.db #0x5a	; 90	'Z'
                                   2225 	.area CSEG    (CODE)
                                   2226 	.area CONST   (CODE)
      00C388                       2227 _vial_handle_cmd_keyboard_uid_40000_624:
      00C388 04                    2228 	.db #0x04	; 4
      00C389 70                    2229 	.db #0x70	; 112	'p'
      00C38A FF                    2230 	.db #0xff	; 255
      00C38B 90                    2231 	.db #0x90	; 144
      00C38C 01                    2232 	.db #0x01	; 1
      00C38D B9                    2233 	.db #0xb9	; 185
      00C38E 15                    2234 	.db #0x15	; 21
      00C38F D3                    2235 	.db #0xd3	; 211
                                   2236 	.area CSEG    (CODE)
                                   2237 	.area XINIT   (CODE)
      00C5BE                       2238 __xinit__vial_unlocked:
      00C5BE 00                    2239 	.db #0x00	;  0
      00C5BF                       2240 __xinit__vial_unlock_in_progress:
      00C5BF 00                    2241 	.db #0x00	;  0
      00C5C0                       2242 __xinit__vial_unlock_counter:
      00C5C0 00                    2243 	.db #0x00	; 0
      00C5C1                       2244 __xinit__vial_unlock_combo_rows:
      00C5C1 00                    2245 	.db #0x00	; 0
      00C5C2 00                    2246 	.db #0x00	; 0
      00C5C3                       2247 __xinit__vial_unlock_combo_cols:
      00C5C3 00                    2248 	.db #0x00	; 0
      00C5C4 05                    2249 	.db #0x05	; 5
                                   2250 	.area CABS    (ABS,CODE)
                                   2251 
                                   2252 ; Experimental exact instruction outlining.
                                   2253 	.globl _ak820_outline_0005
                                   2254 	.globl _ak820_outline_0009
                                   2255 	.globl _ak820_outline_0010
                                   2256 	.globl _ak820_outline_0011
                                   2257 	.globl _ak820_outline_0012
                                   2258 	.globl _ak820_outline_0013
                                   2259 	.globl _ak820_outline_0015
                                   2260 	.globl _ak820_outline_0017
                                   2261 	.globl _ak820_outline_0018
                                   2262 	.globl _ak820_outline_0022
                                   2263 	.globl _ak820_outline_0025
                                   2264 	.globl _ak820_outline_0033
                                   2265 	.globl _ak820_outline_0034
                                   2266 	.globl _ak820_outline_0035
                                   2267 	.globl _ak820_outline_0036
                                   2268 	.globl _ak820_outline_0042
                                   2269 	.globl _ak820_outline_0056
                                   2270 	.globl _ak820_outline_0059
                                   2271 	.globl _ak820_outline_0061
                                   2272 	.globl _ak820_outline_0064
                                   2273 	.globl _ak820_outline_0066
                                   2274 	.globl _ak820_outline_0075
                                   2275 	.globl _ak820_outline_0081
                                   2276 	.globl _ak820_outline_0103
                                   2277 	.globl _ak820_outline_0105
                                   2278 	.globl _ak820_outline_0106
                                   2279 	.globl _ak820_outline_0119
                                   2280 	.globl _ak820_outline_0123
                                   2281 	.globl _ak820_outline_0124
                                   2282 	.globl _ak820_outline_0127
                                   2283 	.globl _ak820_outline_0129
                                   2284 	.globl _ak820_outline_0130
                                   2285 	.globl _ak820_outline_0135
                                   2286 	.globl _ak820_outline_0136
                                   2287 	.globl _ak820_outline_0139
                                   2288 	.globl _ak820_outline_0143
                                   2289 	.globl _ak820_outline_0150
                                   2290 	.globl _ak820_outline_0158
                                   2291 	.globl _ak820_outline_0191
                                   2292 
                                   2293 	.area CSEG (CODE)
                                   2294 ; function ak820_outline_0011
      00B6B8                       2295 _ak820_outline_0011:
      00B6B8 A3               [24] 2296 	inc	dptr
      00B6B9 F0               [24] 2297 	movx	@dptr,a
      00B6BA E4               [12] 2298 	clr	a
      00B6BB A3               [24] 2299 	inc	dptr
      00B6BC F0               [24] 2300 	movx	@dptr,a
      00B6BD 90 0E 63         [24] 2301 	mov	dptr,#___memcpy_PARM_3
      00B6C0 74 0A            [12] 2302 	mov	a,#0x0a
      00B6C2 F0               [24] 2303 	movx	@dptr,a
      00B6C3 E4               [12] 2304 	clr	a
      00B6C4 A3               [24] 2305 	inc	dptr
      00B6C5 F0               [24] 2306 	movx	@dptr,a
      00B6C6 22               [24] 2307 	ret
                                   2308 
                                   2309 	.area CSEG (CODE)
                                   2310 ; function ak820_outline_0025
      00B6C7                       2311 _ak820_outline_0025:
      00B6C7 E0               [24] 2312 	movx	a,@dptr
      00B6C8 FE               [12] 2313 	mov	r6,a
      00B6C9 A3               [24] 2314 	inc	dptr
      00B6CA E0               [24] 2315 	movx	a,@dptr
      00B6CB FF               [12] 2316 	mov	r7,a
      00B6CC 90 0D 38         [24] 2317 	mov	dptr,#_g_vial_magic_keycode_override
      00B6CF EE               [12] 2318 	mov	a,r6
      00B6D0 F0               [24] 2319 	movx	@dptr,a
      00B6D1 EF               [12] 2320 	mov	a,r7
      00B6D2 A3               [24] 2321 	inc	dptr
      00B6D3 F0               [24] 2322 	movx	@dptr,a
      00B6D4 8E 04            [24] 2323 	mov	ar4,r6
      00B6D6 8F 05            [24] 2324 	mov	ar5,r7
      00B6D8 C3               [12] 2325 	clr	c
      00B6D9 74 FF            [12] 2326 	mov	a,#0xff
      00B6DB 9C               [12] 2327 	subb	a,r4
      00B6DC 74 1F            [12] 2328 	mov	a,#0x1f
      00B6DE 9D               [12] 2329 	subb	a,r5
      00B6DF 22               [24] 2330 	ret
                                   2331 
                                   2332 	.area CSEG (CODE)
                                   2333 ; function ak820_outline_0129
      00B6E0                       2334 _ak820_outline_0129:
      00B6E0 24 E5            [12] 2335 	add	a,#_vial_unlock_combo_cols
      00B6E2 F5 82            [12] 2336 	mov	dpl,a
      00B6E4 E4               [12] 2337 	clr	a
      00B6E5 34 0E            [12] 2338 	addc	a,#(_vial_unlock_combo_cols>>8)
      00B6E7 F5 83            [12] 2339 	mov	dph,a
      00B6E9 E0               [24] 2340 	movx	a,@dptr
      00B6EA 22               [24] 2341 	ret
                                   2342 
                                   2343 	.area CSEG (CODE)
                                   2344 ; function ak820_outline_0130
      00B6EB                       2345 _ak820_outline_0130:
      00B6EB 24 E3            [12] 2346 	add	a,#_vial_unlock_combo_rows
      00B6ED F5 82            [12] 2347 	mov	dpl,a
      00B6EF E4               [12] 2348 	clr	a
      00B6F0 34 0E            [12] 2349 	addc	a,#(_vial_unlock_combo_rows>>8)
      00B6F2 F5 83            [12] 2350 	mov	dph,a
      00B6F4 E0               [24] 2351 	movx	a,@dptr
      00B6F5 22               [24] 2352 	ret
