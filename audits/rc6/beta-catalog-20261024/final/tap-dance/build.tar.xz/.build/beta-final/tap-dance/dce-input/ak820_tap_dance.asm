;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (Linux)
;--------------------------------------------------------
	.module ak820_tap_dance
	
	.optsdcc -mmcs51 --model-large
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _get_repeat_key_count
	.globl _dynamic_keymap_get_tap_dance
	.globl _process_record
	.globl _ADC_START
	.globl _S0_R_FIFO
	.globl _S0_T_FIFO
	.globl _S0_FREE
	.globl _S0_IF_BYTE
	.globl _S0_IF_FIRST
	.globl _S0_IF_OV
	.globl _S0_FST_ACT
	.globl _CP_RL2
	.globl _C_T2
	.globl _TR2
	.globl _EXEN2
	.globl _TCLK
	.globl _RCLK
	.globl _EXF2
	.globl _CAP1F
	.globl _TF2
	.globl _RI
	.globl _TI
	.globl _RB8
	.globl _TB8
	.globl _REN
	.globl _SM2
	.globl _SM1
	.globl _SM0
	.globl _IT0
	.globl _IE0
	.globl _IT1
	.globl _IE1
	.globl _TR0
	.globl _TF0
	.globl _TR1
	.globl _TF1
	.globl _P4_0
	.globl _P4_1
	.globl _P4_2
	.globl _P4_3
	.globl _P4_4
	.globl _P4_5
	.globl _P4_6
	.globl _RXD
	.globl _TXD
	.globl _INT0
	.globl _INT1
	.globl _T0
	.globl _T1
	.globl _MOSI1
	.globl _MISO1
	.globl _SCK1
	.globl _P3_0
	.globl _P3_1
	.globl _P3_2
	.globl _P3_3
	.globl _P3_4
	.globl _P3_5
	.globl _P3_6
	.globl _P3_7
	.globl _CAP1_
	.globl _T2_
	.globl _CAP2_
	.globl _T2EX_
	.globl _RXD1
	.globl _TXD1
	.globl _P2_0
	.globl _P2_1
	.globl _P2_2
	.globl _P2_3
	.globl _P2_4
	.globl _P2_5
	.globl _P2_6
	.globl _P2_7
	.globl _AIN0
	.globl _AIN1
	.globl _AIN2
	.globl _AIN3
	.globl _AIN4
	.globl _AIN5
	.globl _AIN6
	.globl _AIN7
	.globl _CAP1
	.globl _T2
	.globl _CAP2
	.globl _T2EX
	.globl _INT0_
	.globl _SCS
	.globl _MOSI
	.globl _MISO
	.globl _SCK
	.globl _RXD1_
	.globl _TXD1_
	.globl _P1_0
	.globl _P1_1
	.globl _P1_2
	.globl _P1_3
	.globl _P1_4
	.globl _P1_5
	.globl _P1_6
	.globl _P1_7
	.globl _AIN8
	.globl _AIN9
	.globl _AIN10
	.globl _AIN11
	.globl _AIN12
	.globl _AIN13
	.globl _RXD_
	.globl _TXD_
	.globl _SCL0
	.globl _SDA0
	.globl _P0_0
	.globl _P0_1
	.globl _P0_2
	.globl _P0_3
	.globl _P0_4
	.globl _P0_5
	.globl _P0_6
	.globl _P0_7
	.globl _IE_SPI0
	.globl _IE_USB
	.globl _IE_ADC
	.globl _IE_UART1
	.globl _IE_PWM_I2C
	.globl _IE_GPIO
	.globl _IE_WDOG
	.globl _PX0
	.globl _PT0
	.globl _PX1
	.globl _PT1
	.globl _PS
	.globl _PT2
	.globl _PL_FLAG
	.globl _PH_FLAG
	.globl _EX0
	.globl _ET0
	.globl _EX1
	.globl _ET1
	.globl _ES
	.globl _ET2
	.globl _E_DIS
	.globl _EA
	.globl _P
	.globl _F1
	.globl _OV
	.globl _RS0
	.globl _RS1
	.globl _F0
	.globl _AC
	.globl _CY
	.globl _I2CS_INT_ST
	.globl _I2CX_INT
	.globl _LED_STATUS
	.globl _LED_DMA_H
	.globl _LED_DMA_L
	.globl _LED_DMA
	.globl _LED_PWM_OE
	.globl _LED_COMMON
	.globl _ADC_CHAN
	.globl _ADC_DAT_H
	.globl _ADC_DAT_L
	.globl _ADC_DAT
	.globl _ADC_CTRL
	.globl _SPI1_CK_SE
	.globl _SPI1_CTRL
	.globl _SPI1_DATA
	.globl _SPI1_STAT
	.globl _SIF1
	.globl _SBAUD1
	.globl _SBUF1
	.globl _SCON1
	.globl _SPI0_SETUP
	.globl _SPI0_CK_SE
	.globl _SPI0_CTRL
	.globl _SPI0_DATA
	.globl _SPI0_STAT
	.globl _T2CAP1H
	.globl _T2CAP1L
	.globl _T2CAP1
	.globl _TH2
	.globl _TL2
	.globl _T2COUNT
	.globl _RCAP2H
	.globl _RCAP2L
	.globl _RCAP2
	.globl _T2MOD
	.globl _T2CON
	.globl _SBUF
	.globl _SCON
	.globl _TH1
	.globl _TH0
	.globl _TL1
	.globl _TL0
	.globl _TMOD
	.globl _TCON
	.globl _XBUS_AUX
	.globl _P7
	.globl _P6_DIR
	.globl _P6_OUT_PU
	.globl _P6_IN
	.globl _P5_DIR
	.globl _P5_OUT_PU
	.globl _P5_IN
	.globl _P4_LED_KEY
	.globl _P4_DIR_PU
	.globl _P4_MOD_OC
	.globl _P4
	.globl _P3_DIR_PU
	.globl _P3_MOD_OC
	.globl _P3
	.globl _P2_DIR_PU
	.globl _P2_MOD_OC
	.globl _P2
	.globl _P1_DIR_PU
	.globl _P1_MOD_OC
	.globl _P1
	.globl _P0_DIR_PU
	.globl _P0_MOD_OC
	.globl _P0
	.globl _ROM_CTRL
	.globl _ROM_DATA_HH
	.globl _ROM_DATA_HL
	.globl _ROM_DATA_HI
	.globl _ROM_ADDR_H
	.globl _ROM_ADDR_L
	.globl _ROM_ADDR
	.globl _GPIO_IE
	.globl _IP_EX
	.globl _IE_EX
	.globl _IP
	.globl _IE
	.globl _WDOG_COUNT
	.globl _RESET_KEEP
	.globl _WAKE_CTRL
	.globl _CLOCK_CFG
	.globl _POWER_CFG
	.globl _PCON
	.globl _GLOBAL_CFG
	.globl _SAFE_MOD
	.globl _DPH
	.globl _DPL
	.globl _SP
	.globl _A_INV
	.globl _B
	.globl _ACC
	.globl _PSW
	.globl _ak820_tap_dance_valid
	.globl _ak820_tap_dance_task
	.globl _ak820_tap_dance_before
	.globl _ak820_tap_dance_process
	.globl _ak820_tap_dance_cancel
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
_PSW	=	0x00d0
_ACC	=	0x00e0
_B	=	0x00f0
_A_INV	=	0x00fd
_SP	=	0x0081
_DPL	=	0x0082
_DPH	=	0x0083
_SAFE_MOD	=	0x00a1
_GLOBAL_CFG	=	0x00b1
_PCON	=	0x0087
_POWER_CFG	=	0x00ba
_CLOCK_CFG	=	0x00b9
_WAKE_CTRL	=	0x00a9
_RESET_KEEP	=	0x00fe
_WDOG_COUNT	=	0x00ff
_IE	=	0x00a8
_IP	=	0x00b8
_IE_EX	=	0x00e8
_IP_EX	=	0x00e9
_GPIO_IE	=	0x00b2
_ROM_ADDR	=	0x8584
_ROM_ADDR_L	=	0x0084
_ROM_ADDR_H	=	0x0085
_ROM_DATA_HI	=	0x8f8e
_ROM_DATA_HL	=	0x008e
_ROM_DATA_HH	=	0x008f
_ROM_CTRL	=	0x0086
_P0	=	0x0080
_P0_MOD_OC	=	0x00c4
_P0_DIR_PU	=	0x00c5
_P1	=	0x0090
_P1_MOD_OC	=	0x0092
_P1_DIR_PU	=	0x0093
_P2	=	0x00a0
_P2_MOD_OC	=	0x0094
_P2_DIR_PU	=	0x0095
_P3	=	0x00b0
_P3_MOD_OC	=	0x0096
_P3_DIR_PU	=	0x0097
_P4	=	0x00c0
_P4_MOD_OC	=	0x00c2
_P4_DIR_PU	=	0x00c3
_P4_LED_KEY	=	0x00c1
_P5_IN	=	0x00aa
_P5_OUT_PU	=	0x00ab
_P5_DIR	=	0x00ac
_P6_IN	=	0x00ad
_P6_OUT_PU	=	0x00ae
_P6_DIR	=	0x00af
_P7	=	0x00f1
_XBUS_AUX	=	0x00a2
_TCON	=	0x0088
_TMOD	=	0x0089
_TL0	=	0x008a
_TL1	=	0x008b
_TH0	=	0x008c
_TH1	=	0x008d
_SCON	=	0x0098
_SBUF	=	0x0099
_T2CON	=	0x00c8
_T2MOD	=	0x00c9
_RCAP2	=	0xcbca
_RCAP2L	=	0x00ca
_RCAP2H	=	0x00cb
_T2COUNT	=	0xcdcc
_TL2	=	0x00cc
_TH2	=	0x00cd
_T2CAP1	=	0xcfce
_T2CAP1L	=	0x00ce
_T2CAP1H	=	0x00cf
_SPI0_STAT	=	0x00f8
_SPI0_DATA	=	0x00f9
_SPI0_CTRL	=	0x00fa
_SPI0_CK_SE	=	0x00fb
_SPI0_SETUP	=	0x00fc
_SCON1	=	0x00bc
_SBUF1	=	0x00bd
_SBAUD1	=	0x00be
_SIF1	=	0x00bf
_SPI1_STAT	=	0x00b4
_SPI1_DATA	=	0x00b5
_SPI1_CTRL	=	0x00b6
_SPI1_CK_SE	=	0x00b7
_ADC_CTRL	=	0x00f3
_ADC_DAT	=	0xf5f4
_ADC_DAT_L	=	0x00f4
_ADC_DAT_H	=	0x00f5
_ADC_CHAN	=	0x00f6
_LED_COMMON	=	0x00a6
_LED_PWM_OE	=	0x00a7
_LED_DMA	=	0xc7c6
_LED_DMA_L	=	0x00c6
_LED_DMA_H	=	0x00c7
_LED_STATUS	=	0x00f7
_I2CX_INT	=	0x00b3
_I2CS_INT_ST	=	0x00bb
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
_CY	=	0x00d7
_AC	=	0x00d6
_F0	=	0x00d5
_RS1	=	0x00d4
_RS0	=	0x00d3
_OV	=	0x00d2
_F1	=	0x00d1
_P	=	0x00d0
_EA	=	0x00af
_E_DIS	=	0x00ae
_ET2	=	0x00ad
_ES	=	0x00ac
_ET1	=	0x00ab
_EX1	=	0x00aa
_ET0	=	0x00a9
_EX0	=	0x00a8
_PH_FLAG	=	0x00bf
_PL_FLAG	=	0x00be
_PT2	=	0x00bd
_PS	=	0x00bc
_PT1	=	0x00bb
_PX1	=	0x00ba
_PT0	=	0x00b9
_PX0	=	0x00b8
_IE_WDOG	=	0x00ef
_IE_GPIO	=	0x00ee
_IE_PWM_I2C	=	0x00ed
_IE_UART1	=	0x00ec
_IE_ADC	=	0x00eb
_IE_USB	=	0x00e9
_IE_SPI0	=	0x00e8
_P0_7	=	0x0087
_P0_6	=	0x0086
_P0_5	=	0x0085
_P0_4	=	0x0084
_P0_3	=	0x0083
_P0_2	=	0x0082
_P0_1	=	0x0081
_P0_0	=	0x0080
_SDA0	=	0x0081
_SCL0	=	0x0080
_TXD_	=	0x0083
_RXD_	=	0x0082
_AIN13	=	0x0085
_AIN12	=	0x0084
_AIN11	=	0x0083
_AIN10	=	0x0082
_AIN9	=	0x0081
_AIN8	=	0x0080
_P1_7	=	0x0097
_P1_6	=	0x0096
_P1_5	=	0x0095
_P1_4	=	0x0094
_P1_3	=	0x0093
_P1_2	=	0x0092
_P1_1	=	0x0091
_P1_0	=	0x0090
_TXD1_	=	0x0097
_RXD1_	=	0x0096
_SCK	=	0x0097
_MISO	=	0x0096
_MOSI	=	0x0095
_SCS	=	0x0094
_INT0_	=	0x0092
_T2EX	=	0x0091
_CAP2	=	0x0091
_T2	=	0x0090
_CAP1	=	0x0090
_AIN7	=	0x0097
_AIN6	=	0x0096
_AIN5	=	0x0095
_AIN4	=	0x0094
_AIN3	=	0x0093
_AIN2	=	0x0092
_AIN1	=	0x0091
_AIN0	=	0x0090
_P2_7	=	0x00a7
_P2_6	=	0x00a6
_P2_5	=	0x00a5
_P2_4	=	0x00a4
_P2_3	=	0x00a3
_P2_2	=	0x00a2
_P2_1	=	0x00a1
_P2_0	=	0x00a0
_TXD1	=	0x00a7
_RXD1	=	0x00a6
_T2EX_	=	0x00a5
_CAP2_	=	0x00a5
_T2_	=	0x00a4
_CAP1_	=	0x00a4
_P3_7	=	0x00b7
_P3_6	=	0x00b6
_P3_5	=	0x00b5
_P3_4	=	0x00b4
_P3_3	=	0x00b3
_P3_2	=	0x00b2
_P3_1	=	0x00b1
_P3_0	=	0x00b0
_SCK1	=	0x00b7
_MISO1	=	0x00b6
_MOSI1	=	0x00b5
_T1	=	0x00b5
_T0	=	0x00b4
_INT1	=	0x00b3
_INT0	=	0x00b2
_TXD	=	0x00b1
_RXD	=	0x00b0
_P4_6	=	0x00c6
_P4_5	=	0x00c5
_P4_4	=	0x00c4
_P4_3	=	0x00c3
_P4_2	=	0x00c2
_P4_1	=	0x00c1
_P4_0	=	0x00c0
_TF1	=	0x008f
_TR1	=	0x008e
_TF0	=	0x008d
_TR0	=	0x008c
_IE1	=	0x008b
_IT1	=	0x008a
_IE0	=	0x0089
_IT0	=	0x0088
_SM0	=	0x009f
_SM1	=	0x009e
_SM2	=	0x009d
_REN	=	0x009c
_TB8	=	0x009b
_RB8	=	0x009a
_TI	=	0x0099
_RI	=	0x0098
_TF2	=	0x00cf
_CAP1F	=	0x00cf
_EXF2	=	0x00ce
_RCLK	=	0x00cd
_TCLK	=	0x00cc
_EXEN2	=	0x00cb
_TR2	=	0x00ca
_C_T2	=	0x00c9
_CP_RL2	=	0x00c8
_S0_FST_ACT	=	0x00ff
_S0_IF_OV	=	0x00fe
_S0_IF_FIRST	=	0x00fd
_S0_IF_BYTE	=	0x00fc
_S0_FREE	=	0x00fb
_S0_T_FIFO	=	0x00fa
_S0_R_FIFO	=	0x00f8
_ADC_START	=	0x00f7
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram
;--------------------------------------------------------
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; absolute internal ram data
;--------------------------------------------------------
	.area IABS    (ABS,DATA)
	.area IABS    (ABS,DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
_td_finish_sloc0_1_0:
	.ds 1
_ak820_tap_dance_before_sloc0_1_0:
	.ds 1
_ak820_tap_dance_process_sloc0_1_0:
	.ds 1
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; uninitialized external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
_td_slots:
	.ds 32
_td_wait:
	.ds 2
_td_work:
	.ds 2
_td_entry:
	.ds 10
_td_time:
	.ds 2
_td_map:
	.ds 128
_td_record:
	.ds 9
_td_step:
	.ds 1
_ak820_td_invoking:
	.ds 1
_ak820_tap_dance_valid_entry_10000_594:
	.ds 2
_ak820_tap_dance_valid_basic_30000_598:
	.ds 1
_td_finish_interrupted_10000_603:
	.ds 1
_td_finish_choice_10000_604:
	.ds 1
_td_finish_state_10000_604:
	.ds 1
_td_finish_extra_10000_604:
	.ds 1
_ak820_tap_dance_task_now_10000_621:
	.ds 2
_ak820_tap_dance_task_term_10000_622:
	.ds 2
_ak820_tap_dance_before_event_10000_625:
	.ds 2
_ak820_tap_dance_process_record_10000_641:
	.ds 2
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area XABS    (ABS,XDATA)
;--------------------------------------------------------
; initialized external ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area HOME    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
;------------------------------------------------------------
;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
;------------------------------------------------------------
;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
;	-----------------------------------------
	ar7 = 0x07
	ar6 = 0x06
	ar5 = 0x05
	ar4 = 0x04
	ar3 = 0x03
	ar2 = 0x02
	ar1 = 0x01
	ar0 = 0x00
;	 function ak820_tap_dance_valid
;	-----------------------------------------
_ak820_tap_dance_valid:
	mov	r7,dph
	mov	a,dpl
	mov	dptr,#_ak820_tap_dance_valid_entry_10000_594
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:26: const uint8_t AK820_STATE_MEM *bytes = (const uint8_t AK820_STATE_MEM *)entry;
	mov	dptr,#_ak820_tap_dance_valid_entry_10000_594
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:27: if (bytes[9] & 128) return false;
	mov	a,#0x09
	add	a, r6
	mov	dpl,a
	clr	a
	addc	a, r7
	mov	dph,a
	movx	a,@dptr
	jnb	acc.7,00130$
	mov	dpl, #0x00
;	keyboards/ajazz/ak820/ak820_tap_dance.c:28: for (uint8_t i = 0; i < 4; ++i, bytes += 2) {
	ret
00130$:
	mov	r5,#0x00
00114$:
	cjne	r5,#0x04,00167$
00167$:
	jnc	00112$
;	keyboards/ajazz/ak820/ak820_tap_dance.c:29: uint8_t basic = bytes[0], mods = bytes[1];
	mov	dpl,r6
	mov	dph,r7
	movx	a,@dptr
	mov	r4,a
	mov	dptr,#_ak820_tap_dance_valid_basic_30000_598
	movx	@dptr,a
	mov	dpl,r6
	mov	dph,r7
	inc	dptr
	movx	a,@dptr
;	keyboards/ajazz/ak820/ak820_tap_dance.c:30: if (!(basic | mods)) continue;
	mov	r3,a
	orl	a,r4
	jz	00111$
;	keyboards/ajazz/ak820/ak820_tap_dance.c:31: if (mods >= 32 || !((basic >= KC_A && basic <= KC_EXSEL) ||
	cjne	r3,#0x20,00170$
00170$:
	jnc	00105$
	cjne	r4,#0x04,00172$
00172$:
	jc	00109$
	mov	a,r4
	add	a,#0xff - 0xa4
	jnc	00111$
;	free result
00109$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:32: (basic >= KC_LEFT_CTRL && basic <= KC_RIGHT_GUI))) return false;
	mov	dptr,#_ak820_tap_dance_valid_basic_30000_598
	movx	a,@dptr
	mov	r4,a
	cjne	r4,#0xe0,00175$
00175$:
	jc	00105$
	mov	a,r4
	add	a,#0xff - 0xe7
	jnc	00111$
;	free result
00105$:
	mov	dpl, #0x00
	ret
00111$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:28: for (uint8_t i = 0; i < 4; ++i, bytes += 2) {
	inc	r5
	mov	a,#0x02
	add	a, r6
	mov	r6,a
	clr	a
	addc	a, r7
	mov	r7,a
	sjmp	00114$
00112$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:34: return true;
	mov	dpl, #0x01
;	keyboards/ajazz/ak820/ak820_tap_dance.c:35: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'td_prepare'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_tap_dance.c:38: static void td_prepare(void) {
;	-----------------------------------------
;	 function td_prepare
;	-----------------------------------------
_td_prepare:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:39: td_record.event.key.row = td_work->source / MATRIX_COLS;
	mov	dptr,#_td_work
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dpl,r6
	mov	dph,r7
	inc	dptr
	inc	dptr
	movx	a,@dptr
	mov	b,#0x08
	div	ab
	mov	dptr,#(_td_record + 0x0001)
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:40: td_record.event.key.col = td_work->source % MATRIX_COLS;
	mov	dptr,#_td_work
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dpl,r6
	mov	dph,r7
	inc	dptr
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	anl	ar7,#0x07
	mov	dptr,#_td_record
	mov	a,r7
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:41: td_record.event.type = KEY_EVENT;
	mov	dptr,#(_td_record + 0x0004)
	mov	a,#0x01
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:42: td_record.event.time = td_time;
	mov	dptr,#_td_time
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#(_td_record + 0x0002)
	mov	a,r6
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:43: td_record.tap.count = 1;
	mov	dptr,#(_td_record + 0x0006)
	movx	a,@dptr
	anl	a,#0x0f
	orl	a,#0x10
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:44: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'td_finish'
;------------------------------------------------------------
;interrupted   Allocated with name '_td_finish_interrupted_10000_603'
;choice        Allocated with name '_td_finish_choice_10000_604'
;state         Allocated with name '_td_finish_state_10000_604'
;extra         Allocated with name '_td_finish_extra_10000_604'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_tap_dance.c:45: static void td_finish(bool interrupted) {
;	-----------------------------------------
;	 function td_finish
;	-----------------------------------------
_td_finish:
	mov	a,dpl
	mov	dptr,#_td_finish_interrupted_10000_603
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:46: uint8_t choice = 0, state;
	mov	dptr,#_td_finish_choice_10000_604
	clr	a
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:47: bool extra = false;
	mov	dptr,#_td_finish_extra_10000_604
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:48: if (ak820_td_invoking) return;
	mov	dptr,#_ak820_td_invoking
	movx	a,@dptr
	jz	00102$
	ret
00102$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:49: if (!td_wait) return;
	mov	dptr,#_td_wait
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_td_wait
	movx	a,@dptr
	mov	b,a
	inc	dptr
	movx	a,@dptr
	orl	a,b
	jnz	00104$
	ret
00104$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:50: ak820_td_invoking = true;
	mov	dptr,#_ak820_td_invoking
	mov	a,#0x01
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:51: td_work = td_wait;
	mov	dptr,#_td_work
	mov	a,r6
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:52: td_wait = 0;
	mov	dptr,#_td_wait
	clr	a
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:53: state = td_work->state;
	mov	dptr,#_td_work
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	a,#0x03
	add	a, r6
	mov	r6,a
	clr	a
	addc	a, r7
	mov	r7,a
	mov	dpl,r6
	mov	dph,r7
	movx	a,@dptr
	mov	r5,a
	mov	dptr,#_td_finish_state_10000_604
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:54: td_work->state = state | TD_DONE;
	orl	ar5,#0x08
	mov	dpl,r6
	mov	dph,r7
	mov	a,r5
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:55: if ((state & 3) == 1) {
	mov	dptr,#_td_finish_state_10000_604
	movx	a,@dptr
	mov	r7,a
	mov	r6,a
	anl	ar6,#0x03
	cjne	r6,#0x01,00112$
;	keyboards/ajazz/ak820/ak820_tap_dance.c:56: if ((state & TD_DOWN) && !interrupted) choice = 1;
	mov	a,r7
	jnb	acc.2,00113$
	mov	dptr,#_td_finish_interrupted_10000_603
	movx	a,@dptr
	jnz	00113$
	mov	dptr,#_td_finish_choice_10000_604
	mov	a,#0x01
	movx	@dptr,a
	sjmp	00113$
00112$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:57: } else if (interrupted) extra = true;
	mov	dptr,#_td_finish_interrupted_10000_603
	movx	a,@dptr
	jz	00109$
	mov	dptr,#_td_finish_extra_10000_604
	mov	a,#0x01
	movx	@dptr,a
	sjmp	00113$
00109$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:58: else choice = (state & TD_DOWN) ? 3 : 2;
	mov	a,r7
	jnb	acc.2,00136$
	mov	r7,#0x03
	sjmp	00137$
00136$:
	mov	r7,#0x02
00137$:
	mov	dptr,#_td_finish_choice_10000_604
	mov	a,r7
	movx	@dptr,a
00113$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:59: td_work->output = ((uint16_t AK820_STATE_MEM *)&td_entry)[choice];
	mov	dptr,#_td_work
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_td_finish_choice_10000_604
	movx	a,@dptr
	mov	r5,a
	mov	b,#0x02
	mul	ab
	add	a, #_td_entry
	mov	dpl,a
	mov	a,#(_td_entry >> 8)
	addc	a, b
	mov	dph,a
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	mov	dpl,r6
	mov	dph,r7
	mov	a,r3
	movx	@dptr,a
	mov	a,r4
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:60: if (!td_work->output) {
	mov	dptr,#_td_work
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dpl,r6
	mov	dph,r7
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	orl	a,r3
	jnz	00117$
;	keyboards/ajazz/ak820/ak820_tap_dance.c:61: if (choice >= 2) extra = true;
	cjne	r5,#0x02,00286$
00286$:
	jc	00115$
	mov	dptr,#_td_finish_extra_10000_604
	mov	a,#0x01
	movx	@dptr,a
00115$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:62: td_work->output = choice == 3 && td_entry.on_hold ? td_entry.on_hold : td_entry.on_tap;
	mov	dptr,#_td_finish_choice_10000_604
	movx	a,@dptr
	mov	r5,a
	cjne	r5,#0x03,00138$
	mov	dptr,#(_td_entry + 0x0002)
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	orl	a,r4
	jnz	00139$
00138$:
	mov	dptr,#_td_entry
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
00139$:
	mov	dpl,r6
	mov	dph,r7
	mov	a,r4
	movx	@dptr,a
	mov	a,r5
	inc	dptr
	movx	@dptr,a
00117$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:64: td_step = extra ? 0 : 2;
	mov	dptr,#_td_finish_extra_10000_604
	movx	a,@dptr
	jz	00143$
	mov	r7,#0x00
	sjmp	00144$
00143$:
	mov	r7,#0x02
00144$:
	mov	dptr,#_td_step
	mov	a,r7
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:65: td_record.keycode = td_entry.on_tap;
	mov	dptr,#_td_entry
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#(_td_record + 0x0007)
	mov	a,r6
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:66: td_prepare();
	lcall	_td_prepare
00132$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:69: for (; td_step < 4; ++td_step) {
	mov	dptr,#_td_step
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0x04,00292$
00292$:
	jnc	00127$
;	keyboards/ajazz/ak820/ak820_tap_dance.c:70: if (td_step == 2) td_record.keycode = td_work->output;
	cjne	r7,#0x02,00119$
	mov	dptr,#_td_work
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dpl,r6
	mov	dph,r7
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#(_td_record + 0x0007)
	mov	a,r6
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
00119$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:71: if (td_step == 3 && (td_work->state & TD_DOWN)) break;
	mov	dptr,#_td_step
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0x03,00121$
	mov	dptr,#_td_work
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dpl,r6
	mov	dph,r7
	inc	dptr
	inc	dptr
	inc	dptr
	movx	a,@dptr
	jb	acc.2,00127$
00121$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:72: td_record.event.pressed = !(td_step & 1);
	mov	dptr,#_td_step
	movx	a,@dptr
	anl	a,#0x01
	cjne	a,#0x01,00299$
00299$:
	mov	_td_finish_sloc0_1_0,c
	mov	dptr,#(_td_record + 0x0005)
	clr	a
	rlc	a
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:73: if (td_record.keycode) process_record(&td_record);
	mov	dptr,#(_td_record + 0x0007)
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	orl	a,r6
	jz	00124$
	mov	dptr,#_td_record
	lcall	_process_record
00124$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:74: if (!td_work->state) goto done;
	mov	dptr,#_td_work
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	a,#0x03
	add	a, r6
	mov	r6,a
	clr	a
	addc	a, r7
	mov	r7,a
	mov	dpl,r6
	mov	dph,r7
	movx	a,@dptr
	jz	00130$
;	keyboards/ajazz/ak820/ak820_tap_dance.c:69: for (; td_step < 4; ++td_step) {
	mov	dptr,#_td_step
	movx	a,@dptr
	add	a, #0x01
	movx	@dptr,a
	ljmp	00132$
00127$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:76: if (!(td_work->state & TD_DOWN)) td_work->state = 0;
	mov	dptr,#_td_work
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	a,#0x03
	add	a, r6
	mov	r6,a
	clr	a
	addc	a, r7
	mov	r7,a
	mov	dpl,r6
	mov	dph,r7
	movx	a,@dptr
	jb	acc.2,00130$
	mov	dpl,r6
	mov	dph,r7
	clr	a
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:77: done:
00130$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:78: ak820_td_invoking = false;
	mov	dptr,#_ak820_td_invoking
	clr	a
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:79: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_tap_dance_task'
;------------------------------------------------------------
;now           Allocated with name '_ak820_tap_dance_task_now_10000_621'
;term          Allocated with name '_ak820_tap_dance_task_term_10000_622'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_tap_dance.c:80: void ak820_tap_dance_task(uint16_t now) {
;	-----------------------------------------
;	 function ak820_tap_dance_task
;	-----------------------------------------
_ak820_tap_dance_task:
	mov	r7,dph
	mov	a,dpl
	mov	dptr,#_ak820_tap_dance_task_now_10000_621
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:81: uint16_t term = td_entry.custom_tapping_term;
	mov	dptr,#(_td_entry + 0x0008)
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_ak820_tap_dance_task_term_10000_622
	mov	a,r6
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:82: if (!term) term = 200;
	mov	a,r6
	orl	a,r7
	jnz	00102$
	mov	dptr,#_ak820_tap_dance_task_term_10000_622
	mov	a,#0xc8
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
00102$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:83: if (td_wait && (uint16_t)(now - td_time) >= term) td_finish(false);
	mov	dptr,#_td_wait
	movx	a,@dptr
	mov	b,a
	inc	dptr
	movx	a,@dptr
	orl	a,b
	jz	00106$
	mov	dptr,#_td_time
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_ak820_tap_dance_task_now_10000_621
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	mov	a,r4
	clr	c
	subb	a,r6
	mov	r6,a
	mov	a,r5
	subb	a,r7
	mov	r7,a
	mov	dptr,#_ak820_tap_dance_task_term_10000_622
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	clr	c
	mov	a,r6
	subb	a,r4
	mov	a,r7
	subb	a,r5
	jc	00106$
	mov	dpl, #0x00
;	keyboards/ajazz/ak820/ak820_tap_dance.c:84: }
	ljmp	_td_finish
00106$:
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_tap_dance_before'
;------------------------------------------------------------
;event         Allocated with name '_ak820_tap_dance_before_event_10000_625'
;id            Allocated with name '_ak820_tap_dance_before_id_10000_626'
;slot          Allocated with name '_ak820_tap_dance_before_slot_10000_626'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_tap_dance.c:85: bool ak820_tap_dance_before(const keyevent_t AK820_STATE_MEM *event) {
;	-----------------------------------------
;	 function ak820_tap_dance_before
;	-----------------------------------------
_ak820_tap_dance_before:
	mov	r7,dph
	mov	a,dpl
	mov	dptr,#_ak820_tap_dance_before_event_10000_625
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:88: if (IS_NOEVENT(*event)) return true;
	mov	dptr,#_ak820_tap_dance_before_event_10000_625
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	a,#0x04
	add	a, r6
	mov	r4,a
	clr	a
	addc	a, r7
	mov	r5,a
	mov	dpl,r4
	mov	dph,r5
	movx	a,@dptr
	jnz	00102$
	mov	dpl, #0x01
	ret
00102$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:89: if (event->key.row >= MATRIX_ROWS || event->key.col >= MATRIX_COLS) {
	mov	dpl,r6
	mov	dph,r7
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	cjne	r5,#0x10,00220$
00220$:
	jnc	00105$
	mov	dpl,r6
	mov	dph,r7
	movx	a,@dptr
	mov	r4,a
	cjne	r4,#0x08,00222$
00222$:
	jc	00106$
00105$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:90: if (event->pressed) td_finish(true);
	mov	dptr,#_ak820_tap_dance_before_event_10000_625
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	mov	a,#0x05
	add	a, r2
	mov	r2,a
	clr	a
	addc	a, r3
	mov	r3,a
	mov	dpl,r2
	mov	dph,r3
	movx	a,@dptr
	jz	00104$
	mov	dpl, #0x01
	lcall	_td_finish
00104$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:91: return true;
	mov	dpl, #0x01
	ret
00106$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:93: id = event->key.row * MATRIX_COLS + event->key.col;
	mov	a,r5
	swap	a
	rr	a
	anl	a,#0xf8
;	keyboards/ajazz/ak820/ak820_tap_dance.c:94: if (td_map[id] == TD_NONE) {
	add	a,r4
	mov	r5,a
	add	a, #_td_map
	mov	r3,a
	clr	a
	addc	a, #(_td_map >> 8)
	mov	r4,a
	mov	dpl,r3
	mov	dph,r4
	movx	a,@dptr
	mov	r2,a
	cjne	r2,#0xff,00111$
;	keyboards/ajazz/ak820/ak820_tap_dance.c:95: if (!event->pressed) td_map[id] = 0;
	mov	a,#0x05
	add	a, r6
	mov	r1,a
	clr	a
	addc	a, r7
	mov	r2,a
	mov	dpl,r1
	mov	dph,r2
	movx	a,@dptr
	jnz	00109$
	mov	dpl,r3
	mov	dph,r4
	clr	a
	movx	@dptr,a
00109$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:96: return false;
	mov	dpl, #0x00
	ret
00111$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:98: if (event->pressed && td_wait && (td_wait->source != id || (td_wait->state & 3) == 2)) td_finish(true);
	mov	a,#0x05
	add	a, r6
	mov	r6,a
	clr	a
	addc	a, r7
	mov	r7,a
	mov	dpl,r6
	mov	dph,r7
	movx	a,@dptr
	jz	00113$
	mov	dptr,#_td_wait
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	orl	a,r6
	jz	00113$
	mov	dpl,r6
	mov	dph,r7
	inc	dptr
	inc	dptr
	movx	a,@dptr
	cjne	a,ar5,00112$
	mov	dpl,r6
	mov	dph,r7
	inc	dptr
	inc	dptr
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	anl	ar7,#0x03
	cjne	r7,#0x02,00113$
00112$:
	mov	dpl, #0x01
	lcall	_td_finish
00113$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:99: id = event->key.row * MATRIX_COLS + event->key.col;
	mov	dptr,#_ak820_tap_dance_before_event_10000_625
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dpl,r6
	mov	dph,r7
	inc	dptr
	movx	a,@dptr
	swap	a
	rr	a
	anl	a,#0xf8
	mov	r5,a
	mov	dpl,r6
	mov	dph,r7
	movx	a,@dptr
	add	a, r5
;	keyboards/ajazz/ak820/ak820_tap_dance.c:100: slot = td_slots + td_map[id];
	mov	r5,a
	add	a, #_td_map
	mov	dpl,a
	clr	a
	addc	a, #(_td_map >> 8)
	mov	dph,a
	movx	a,@dptr
	mov	b,#0x04
	mul	ab
	add	a, #_td_slots
	mov	r3,a
	mov	a,#(_td_slots >> 8)
	addc	a, b
	mov	r4,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:101: if (slot->state && slot->source == id) {
	mov	a,#0x03
	add	a, r3
	mov	r1,a
	clr	a
	addc	a, r4
	mov	r2,a
	mov	dpl,r1
	mov	dph,r2
	movx	a,@dptr
	mov	r0,a
	jz	00124$
	push	ar0
	mov	dpl,r3
	mov	dph,r4
	inc	dptr
	inc	dptr
	movx	a,@dptr
	cjne	a,ar5,00235$
	sjmp	00236$
00235$:
	pop	ar0
	sjmp	00124$
00236$:
	pop	ar0
;	keyboards/ajazz/ak820/ak820_tap_dance.c:102: if (event->pressed) return !(slot->state & TD_DONE);
	mov	a,#0x05
	add	a, r6
	mov	r6,a
	clr	a
	addc	a, r7
	mov	r7,a
	mov	dpl,r6
	mov	dph,r7
	movx	a,@dptr
	jz	00118$
	mov	a,r0
	mov	c,acc.3
	clr	a
	rlc	a
	cjne	a,#0x01,00238$
00238$:
	mov  _ak820_tap_dance_before_sloc0_1_0,c
	clr	a
	rlc	a
	mov	dpl, a
	ret
00118$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:103: slot->state &= ~TD_DOWN;
	anl	ar0,#0xfb
	mov	dpl,r1
	mov	dph,r2
	mov	a,r0
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:104: if (slot->state & TD_DONE) {
	mov	a,r0
	jnb	acc.3,00122$
;	keyboards/ajazz/ak820/ak820_tap_dance.c:105: td_work = slot;
	mov	dptr,#_td_work
	mov	a,r3
	movx	@dptr,a
	mov	a,r4
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:106: td_record.keycode = slot->output;
	mov	dpl,r3
	mov	dph,r4
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#(_td_record + 0x0007)
	mov	a,r6
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:107: slot->state = 0;
	mov	dpl,r1
	mov	dph,r2
	clr	a
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:108: td_prepare();
	lcall	_td_prepare
;	keyboards/ajazz/ak820/ak820_tap_dance.c:109: td_record.event.pressed = false;
	mov	dptr,#(_td_record + 0x0005)
	clr	a
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:110: if (td_record.keycode) process_record(&td_record);
	mov	dptr,#(_td_record + 0x0007)
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	orl	a,r6
	jz	00122$
	mov	dptr,#_td_record
	lcall	_process_record
00122$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:112: return false;
	mov	dpl, #0x00
	ret
00124$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:114: return true;
	mov	dpl, #0x01
;	keyboards/ajazz/ak820/ak820_tap_dance.c:115: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_tap_dance_process'
;------------------------------------------------------------
;record        Allocated with name '_ak820_tap_dance_process_record_10000_641'
;index         Allocated with name '_ak820_tap_dance_process_index_10000_642'
;id            Allocated with name '_ak820_tap_dance_process_id_10000_642'
;slot          Allocated with name '_ak820_tap_dance_process_slot_10000_642'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_tap_dance.c:116: bool ak820_tap_dance_process(keyrecord_t AK820_STATE_MEM *record) {
;	-----------------------------------------
;	 function ak820_tap_dance_process
;	-----------------------------------------
_ak820_tap_dance_process:
	mov	r7,dph
	mov	a,dpl
	mov	dptr,#_ak820_tap_dance_process_record_10000_641
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:119: if (get_repeat_key_count() || ak820_macro_primitive || record->event.type != KEY_EVENT ||
	lcall	_get_repeat_key_count
	mov	a, dpl
	jnz	00101$
	mov	dptr,#_ak820_macro_primitive
	movx	a,@dptr
	jnz	00101$
	mov	dptr,#_ak820_tap_dance_process_record_10000_641
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dpl,r6
	mov	dph,r7
	inc	dptr
	inc	dptr
	inc	dptr
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	cjne	r5,#0x01,00101$
;	keyboards/ajazz/ak820/ak820_tap_dance.c:120: record->event.key.row >= MATRIX_ROWS || record->event.key.col >= MATRIX_COLS ||
	mov	dpl,r6
	mov	dph,r7
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	cjne	r5,#0x10,00228$
00228$:
	jnc	00101$
	mov	dpl,r6
	mov	dph,r7
	movx	a,@dptr
	mov	r4,a
	cjne	r4,#0x08,00230$
00230$:
	jnc	00101$
;	keyboards/ajazz/ak820/ak820_tap_dance.c:121: !record->event.pressed) return (record->keycode >> 8) != (QK_TAP_DANCE >> 8);
	mov	a,#0x05
	add	a, r6
	mov	r2,a
	clr	a
	addc	a, r7
	mov	r3,a
	mov	dpl,r2
	mov	dph,r3
	movx	a,@dptr
	jnz	00102$
00101$:
	mov	dptr,#_ak820_tap_dance_process_record_10000_641
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	mov	a,#0x07
	add	a, r2
	mov	dpl,a
	clr	a
	addc	a, r3
	mov	dph,a
	movx	a,@dptr
	inc	dptr
	movx	a,@dptr
	mov	r2,a
	mov	r3,#0x00
	cjne	r2,#0x57,00233$
	cjne	r3,#0x00,00233$
	setb	c
	sjmp	00234$
00233$:
	clr	c
00234$:
	cpl	c
	mov	_ak820_tap_dance_process_sloc0_1_0,c
	clr	a
	rlc	a
	mov	dpl, a
	ret
00102$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:122: id = record->event.key.row * MATRIX_COLS + record->event.key.col;
	mov	a,r5
	swap	a
	rr	a
	anl	a,#0xf8
	add	a,r4
	mov	r5,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:124: if (td_wait && !(td_wait->state & TD_DOWN) && td_wait->source == id &&
	mov	dptr,#_td_wait
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	orl	a,r3
	jz	00109$
	mov	dpl,r3
	mov	dph,r4
	inc	dptr
	inc	dptr
	inc	dptr
	movx	a,@dptr
	jb	acc.2,00109$
	mov	dpl,r3
	mov	dph,r4
	inc	dptr
	inc	dptr
	movx	a,@dptr
	cjne	a,ar5,00109$
;	keyboards/ajazz/ak820/ak820_tap_dance.c:125: record->keycode != (QK_TAP_DANCE | td_map[id])) td_finish(true);
	mov	a,#0x07
	add	a, r6
	mov	dpl,a
	clr	a
	addc	a, r7
	mov	dph,a
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	a,r5
	add	a, #_td_map
	mov	dpl,a
	clr	a
	addc	a, #(_td_map >> 8)
	mov	dph,a
	movx	a,@dptr
	mov	r4,a
	mov	r3,#0x00
	orl	ar3,#0x57
	mov	a,r6
	cjne	a,ar4,00239$
	mov	a,r7
	cjne	a,ar3,00239$
	sjmp	00109$
00239$:
	mov	dpl, #0x01
	push	ar5
	lcall	_td_finish
	pop	ar5
00109$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:126: if ((record->keycode >> 8) != (QK_TAP_DANCE >> 8)) return true;
	mov	dptr,#_ak820_tap_dance_process_record_10000_641
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	a,#0x07
	add	a, r6
	mov	dpl,a
	clr	a
	addc	a, r7
	mov	dph,a
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	mov	r4,#0x00
	cjne	r3,#0x57,00240$
	cjne	r4,#0x00,00240$
	sjmp	00114$
00240$:
	mov	dpl, #0x01
	ret
00114$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:127: index = (uint8_t)record->keycode;
;	keyboards/ajazz/ak820/ak820_tap_dance.c:128: slot = td_slots + (index & 7);
	mov	ar4,r6
	anl	ar4,#0x07
	mov	r7,#0x00
	mov	a,r4
	add	a,r4
	mov	r4,a
	mov	a,r7
	rlc	a
	mov	r7,a
	mov	a,r4
	add	a,r4
	mov	r4,a
	mov	a,r7
	rlc	a
	mov	r7,a
	mov	a,r4
	add	a, #_td_slots
	mov	r4,a
	mov	a,r7
	addc	a, #(_td_slots >> 8)
	mov	r7,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:129: if (index >= VIAL_TAP_DANCE_ENTRIES || (slot->state && slot->source != id)) goto suppress;
	cjne	r6,#0x08,00241$
00241$:
	jc	00242$
	ljmp	00123$
00242$:
	mov	a,#0x03
	add	a, r4
	mov	r2,a
	clr	a
	addc	a, r7
	mov	r3,a
	mov	dpl,r2
	mov	dph,r3
	movx	a,@dptr
	mov	r1,a
	jz	00116$
	mov	dpl,r4
	mov	dph,r7
	inc	dptr
	inc	dptr
	movx	a,@dptr
	cjne	a,ar5,00244$
	sjmp	00245$
00244$:
	ljmp	00123$
00245$:
00116$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:130: if (!slot->state) {
	mov	a,r1
	jnz	00122$
;	keyboards/ajazz/ak820/ak820_tap_dance.c:131: if (dynamic_keymap_get_tap_dance(index, &td_entry)) goto suppress;
	mov	dptr,#_dynamic_keymap_get_tap_dance_PARM_2
	mov	a,#_td_entry
	movx	@dptr,a
	mov	a,#(_td_entry >> 8)
	inc	dptr
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	mov	dpl, r6
	push	ar7
	push	ar6
	push	ar5
	push	ar4
	push	ar3
	push	ar2
	lcall	_dynamic_keymap_get_tap_dance
	mov	a, dpl
	mov	b, dph
	pop	ar2
	pop	ar3
	pop	ar4
	pop	ar5
	pop	ar6
	pop	ar7
	orl	a,b
	jnz	00123$
;	keyboards/ajazz/ak820/ak820_tap_dance.c:132: slot->source = id;
	mov	dpl,r4
	mov	dph,r7
	inc	dptr
	inc	dptr
	mov	a,r5
	movx	@dptr,a
00122$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:134: slot->state = (slot->state & 3) + 1 + TD_DOWN;
	mov	dpl,r2
	mov	dph,r3
	movx	a,@dptr
	mov	r1,a
	mov	a,#0x03
	anl	a,r1
	add	a, #0x05
	mov	dpl,r2
	mov	dph,r3
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:135: td_time = record->event.time;
	mov	dptr,#_ak820_tap_dance_process_record_10000_641
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	mov	dpl,r2
	mov	dph,r3
	inc	dptr
	inc	dptr
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	mov	dptr,#_td_time
	mov	a,r2
	movx	@dptr,a
	mov	a,r3
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:136: td_wait = slot;
	mov	dptr,#_td_wait
	mov	a,r4
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:137: td_map[id] = index;
	mov	a,r5
	add	a, #_td_map
	mov	dpl,a
	clr	a
	addc	a, #(_td_map >> 8)
	mov	dph,a
	mov	a,r6
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:138: return false;
	mov	dpl, #0x00
;	keyboards/ajazz/ak820/ak820_tap_dance.c:139: suppress:
	ret
00123$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:140: td_map[id] = TD_NONE;
	mov	a,r5
	add	a, #_td_map
	mov	dpl,a
	clr	a
	addc	a, #(_td_map >> 8)
	mov	dph,a
	mov	a,#0xff
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:141: return false;
	mov	dpl, #0x00
;	keyboards/ajazz/ak820/ak820_tap_dance.c:142: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_tap_dance_cancel'
;------------------------------------------------------------
;i             Allocated with name '_ak820_tap_dance_cancel_i_20000_652'
;i             Allocated with name '_ak820_tap_dance_cancel_i_20000_653'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_tap_dance.c:143: void ak820_tap_dance_cancel(void) {
;	-----------------------------------------
;	 function ak820_tap_dance_cancel
;	-----------------------------------------
_ak820_tap_dance_cancel:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:144: td_wait = 0;
	mov	dptr,#_td_wait
	clr	a
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_tap_dance.c:145: for (uint8_t i = 0; i < VIAL_TAP_DANCE_ENTRIES; ++i) td_slots[i].state = 0;
	mov	r7,a
00104$:
	cjne	r7,#0x08,00141$
00141$:
	jnc	00101$
	mov	a,r7
	mov	b,#0x04
	mul	ab
	add	a, #_td_slots
	mov	r5,a
	mov	a,#(_td_slots >> 8)
	addc	a, b
	mov	r6,a
	mov	dpl,r5
	mov	dph,r6
	inc	dptr
	inc	dptr
	inc	dptr
	clr	a
	movx	@dptr,a
	inc	r7
	sjmp	00104$
00101$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:146: for (uint8_t i = 0; i < sizeof(td_map); ++i) td_map[i] = 0;
	mov	r7,#0x00
00107$:
	cjne	r7,#0x80,00143$
00143$:
	jnc	00109$
	mov	a,r7
	add	a, #_td_map
	mov	dpl,a
	clr	a
	addc	a, #(_td_map >> 8)
	mov	dph,a
	clr	a
	movx	@dptr,a
	inc	r7
	sjmp	00107$
00109$:
;	keyboards/ajazz/ak820/ak820_tap_dance.c:147: }
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
	.area CABS    (ABS,CODE)
