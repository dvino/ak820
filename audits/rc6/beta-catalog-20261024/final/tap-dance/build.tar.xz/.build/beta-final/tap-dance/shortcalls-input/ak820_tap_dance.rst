                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_tap_dance
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _get_repeat_key_count
                                     12 	.globl _dynamic_keymap_get_tap_dance
                                     13 	.globl _process_record
                                     14 	.globl _ADC_START
                                     15 	.globl _S0_R_FIFO
                                     16 	.globl _S0_T_FIFO
                                     17 	.globl _S0_FREE
                                     18 	.globl _S0_IF_BYTE
                                     19 	.globl _S0_IF_FIRST
                                     20 	.globl _S0_IF_OV
                                     21 	.globl _S0_FST_ACT
                                     22 	.globl _CP_RL2
                                     23 	.globl _C_T2
                                     24 	.globl _TR2
                                     25 	.globl _EXEN2
                                     26 	.globl _TCLK
                                     27 	.globl _RCLK
                                     28 	.globl _EXF2
                                     29 	.globl _CAP1F
                                     30 	.globl _TF2
                                     31 	.globl _RI
                                     32 	.globl _TI
                                     33 	.globl _RB8
                                     34 	.globl _TB8
                                     35 	.globl _REN
                                     36 	.globl _SM2
                                     37 	.globl _SM1
                                     38 	.globl _SM0
                                     39 	.globl _IT0
                                     40 	.globl _IE0
                                     41 	.globl _IT1
                                     42 	.globl _IE1
                                     43 	.globl _TR0
                                     44 	.globl _TF0
                                     45 	.globl _TR1
                                     46 	.globl _TF1
                                     47 	.globl _P4_0
                                     48 	.globl _P4_1
                                     49 	.globl _P4_2
                                     50 	.globl _P4_3
                                     51 	.globl _P4_4
                                     52 	.globl _P4_5
                                     53 	.globl _P4_6
                                     54 	.globl _RXD
                                     55 	.globl _TXD
                                     56 	.globl _INT0
                                     57 	.globl _INT1
                                     58 	.globl _T0
                                     59 	.globl _T1
                                     60 	.globl _MOSI1
                                     61 	.globl _MISO1
                                     62 	.globl _SCK1
                                     63 	.globl _P3_0
                                     64 	.globl _P3_1
                                     65 	.globl _P3_2
                                     66 	.globl _P3_3
                                     67 	.globl _P3_4
                                     68 	.globl _P3_5
                                     69 	.globl _P3_6
                                     70 	.globl _P3_7
                                     71 	.globl _CAP1_
                                     72 	.globl _T2_
                                     73 	.globl _CAP2_
                                     74 	.globl _T2EX_
                                     75 	.globl _RXD1
                                     76 	.globl _TXD1
                                     77 	.globl _P2_0
                                     78 	.globl _P2_1
                                     79 	.globl _P2_2
                                     80 	.globl _P2_3
                                     81 	.globl _P2_4
                                     82 	.globl _P2_5
                                     83 	.globl _P2_6
                                     84 	.globl _P2_7
                                     85 	.globl _AIN0
                                     86 	.globl _AIN1
                                     87 	.globl _AIN2
                                     88 	.globl _AIN3
                                     89 	.globl _AIN4
                                     90 	.globl _AIN5
                                     91 	.globl _AIN6
                                     92 	.globl _AIN7
                                     93 	.globl _CAP1
                                     94 	.globl _T2
                                     95 	.globl _CAP2
                                     96 	.globl _T2EX
                                     97 	.globl _INT0_
                                     98 	.globl _SCS
                                     99 	.globl _MOSI
                                    100 	.globl _MISO
                                    101 	.globl _SCK
                                    102 	.globl _RXD1_
                                    103 	.globl _TXD1_
                                    104 	.globl _P1_0
                                    105 	.globl _P1_1
                                    106 	.globl _P1_2
                                    107 	.globl _P1_3
                                    108 	.globl _P1_4
                                    109 	.globl _P1_5
                                    110 	.globl _P1_6
                                    111 	.globl _P1_7
                                    112 	.globl _AIN8
                                    113 	.globl _AIN9
                                    114 	.globl _AIN10
                                    115 	.globl _AIN11
                                    116 	.globl _AIN12
                                    117 	.globl _AIN13
                                    118 	.globl _RXD_
                                    119 	.globl _TXD_
                                    120 	.globl _SCL0
                                    121 	.globl _SDA0
                                    122 	.globl _P0_0
                                    123 	.globl _P0_1
                                    124 	.globl _P0_2
                                    125 	.globl _P0_3
                                    126 	.globl _P0_4
                                    127 	.globl _P0_5
                                    128 	.globl _P0_6
                                    129 	.globl _P0_7
                                    130 	.globl _IE_SPI0
                                    131 	.globl _IE_USB
                                    132 	.globl _IE_ADC
                                    133 	.globl _IE_UART1
                                    134 	.globl _IE_PWM_I2C
                                    135 	.globl _IE_GPIO
                                    136 	.globl _IE_WDOG
                                    137 	.globl _PX0
                                    138 	.globl _PT0
                                    139 	.globl _PX1
                                    140 	.globl _PT1
                                    141 	.globl _PS
                                    142 	.globl _PT2
                                    143 	.globl _PL_FLAG
                                    144 	.globl _PH_FLAG
                                    145 	.globl _EX0
                                    146 	.globl _ET0
                                    147 	.globl _EX1
                                    148 	.globl _ET1
                                    149 	.globl _ES
                                    150 	.globl _ET2
                                    151 	.globl _E_DIS
                                    152 	.globl _EA
                                    153 	.globl _P
                                    154 	.globl _F1
                                    155 	.globl _OV
                                    156 	.globl _RS0
                                    157 	.globl _RS1
                                    158 	.globl _F0
                                    159 	.globl _AC
                                    160 	.globl _CY
                                    161 	.globl _I2CS_INT_ST
                                    162 	.globl _I2CX_INT
                                    163 	.globl _LED_STATUS
                                    164 	.globl _LED_DMA_H
                                    165 	.globl _LED_DMA_L
                                    166 	.globl _LED_DMA
                                    167 	.globl _LED_PWM_OE
                                    168 	.globl _LED_COMMON
                                    169 	.globl _ADC_CHAN
                                    170 	.globl _ADC_DAT_H
                                    171 	.globl _ADC_DAT_L
                                    172 	.globl _ADC_DAT
                                    173 	.globl _ADC_CTRL
                                    174 	.globl _SPI1_CK_SE
                                    175 	.globl _SPI1_CTRL
                                    176 	.globl _SPI1_DATA
                                    177 	.globl _SPI1_STAT
                                    178 	.globl _SIF1
                                    179 	.globl _SBAUD1
                                    180 	.globl _SBUF1
                                    181 	.globl _SCON1
                                    182 	.globl _SPI0_SETUP
                                    183 	.globl _SPI0_CK_SE
                                    184 	.globl _SPI0_CTRL
                                    185 	.globl _SPI0_DATA
                                    186 	.globl _SPI0_STAT
                                    187 	.globl _T2CAP1H
                                    188 	.globl _T2CAP1L
                                    189 	.globl _T2CAP1
                                    190 	.globl _TH2
                                    191 	.globl _TL2
                                    192 	.globl _T2COUNT
                                    193 	.globl _RCAP2H
                                    194 	.globl _RCAP2L
                                    195 	.globl _RCAP2
                                    196 	.globl _T2MOD
                                    197 	.globl _T2CON
                                    198 	.globl _SBUF
                                    199 	.globl _SCON
                                    200 	.globl _TH1
                                    201 	.globl _TH0
                                    202 	.globl _TL1
                                    203 	.globl _TL0
                                    204 	.globl _TMOD
                                    205 	.globl _TCON
                                    206 	.globl _XBUS_AUX
                                    207 	.globl _P7
                                    208 	.globl _P6_DIR
                                    209 	.globl _P6_OUT_PU
                                    210 	.globl _P6_IN
                                    211 	.globl _P5_DIR
                                    212 	.globl _P5_OUT_PU
                                    213 	.globl _P5_IN
                                    214 	.globl _P4_LED_KEY
                                    215 	.globl _P4_DIR_PU
                                    216 	.globl _P4_MOD_OC
                                    217 	.globl _P4
                                    218 	.globl _P3_DIR_PU
                                    219 	.globl _P3_MOD_OC
                                    220 	.globl _P3
                                    221 	.globl _P2_DIR_PU
                                    222 	.globl _P2_MOD_OC
                                    223 	.globl _P2
                                    224 	.globl _P1_DIR_PU
                                    225 	.globl _P1_MOD_OC
                                    226 	.globl _P1
                                    227 	.globl _P0_DIR_PU
                                    228 	.globl _P0_MOD_OC
                                    229 	.globl _P0
                                    230 	.globl _ROM_CTRL
                                    231 	.globl _ROM_DATA_HH
                                    232 	.globl _ROM_DATA_HL
                                    233 	.globl _ROM_DATA_HI
                                    234 	.globl _ROM_ADDR_H
                                    235 	.globl _ROM_ADDR_L
                                    236 	.globl _ROM_ADDR
                                    237 	.globl _GPIO_IE
                                    238 	.globl _IP_EX
                                    239 	.globl _IE_EX
                                    240 	.globl _IP
                                    241 	.globl _IE
                                    242 	.globl _WDOG_COUNT
                                    243 	.globl _RESET_KEEP
                                    244 	.globl _WAKE_CTRL
                                    245 	.globl _CLOCK_CFG
                                    246 	.globl _POWER_CFG
                                    247 	.globl _PCON
                                    248 	.globl _GLOBAL_CFG
                                    249 	.globl _SAFE_MOD
                                    250 	.globl _DPH
                                    251 	.globl _DPL
                                    252 	.globl _SP
                                    253 	.globl _A_INV
                                    254 	.globl _B
                                    255 	.globl _ACC
                                    256 	.globl _PSW
                                    257 	.globl _ak820_tap_dance_valid
                                    258 	.globl _ak820_tap_dance_task
                                    259 	.globl _ak820_tap_dance_before
                                    260 	.globl _ak820_tap_dance_process
                                    261 	.globl _ak820_tap_dance_cancel
                                    262 ;--------------------------------------------------------
                                    263 ; special function registers
                                    264 ;--------------------------------------------------------
                                    265 	.area RSEG    (ABS,DATA)
      000000                        266 	.org 0x0000
                           0000D0   267 _PSW	=	0x00d0
                           0000E0   268 _ACC	=	0x00e0
                           0000F0   269 _B	=	0x00f0
                           0000FD   270 _A_INV	=	0x00fd
                           000081   271 _SP	=	0x0081
                           000082   272 _DPL	=	0x0082
                           000083   273 _DPH	=	0x0083
                           0000A1   274 _SAFE_MOD	=	0x00a1
                           0000B1   275 _GLOBAL_CFG	=	0x00b1
                           000087   276 _PCON	=	0x0087
                           0000BA   277 _POWER_CFG	=	0x00ba
                           0000B9   278 _CLOCK_CFG	=	0x00b9
                           0000A9   279 _WAKE_CTRL	=	0x00a9
                           0000FE   280 _RESET_KEEP	=	0x00fe
                           0000FF   281 _WDOG_COUNT	=	0x00ff
                           0000A8   282 _IE	=	0x00a8
                           0000B8   283 _IP	=	0x00b8
                           0000E8   284 _IE_EX	=	0x00e8
                           0000E9   285 _IP_EX	=	0x00e9
                           0000B2   286 _GPIO_IE	=	0x00b2
                           008584   287 _ROM_ADDR	=	0x8584
                           000084   288 _ROM_ADDR_L	=	0x0084
                           000085   289 _ROM_ADDR_H	=	0x0085
                           008F8E   290 _ROM_DATA_HI	=	0x8f8e
                           00008E   291 _ROM_DATA_HL	=	0x008e
                           00008F   292 _ROM_DATA_HH	=	0x008f
                           000086   293 _ROM_CTRL	=	0x0086
                           000080   294 _P0	=	0x0080
                           0000C4   295 _P0_MOD_OC	=	0x00c4
                           0000C5   296 _P0_DIR_PU	=	0x00c5
                           000090   297 _P1	=	0x0090
                           000092   298 _P1_MOD_OC	=	0x0092
                           000093   299 _P1_DIR_PU	=	0x0093
                           0000A0   300 _P2	=	0x00a0
                           000094   301 _P2_MOD_OC	=	0x0094
                           000095   302 _P2_DIR_PU	=	0x0095
                           0000B0   303 _P3	=	0x00b0
                           000096   304 _P3_MOD_OC	=	0x0096
                           000097   305 _P3_DIR_PU	=	0x0097
                           0000C0   306 _P4	=	0x00c0
                           0000C2   307 _P4_MOD_OC	=	0x00c2
                           0000C3   308 _P4_DIR_PU	=	0x00c3
                           0000C1   309 _P4_LED_KEY	=	0x00c1
                           0000AA   310 _P5_IN	=	0x00aa
                           0000AB   311 _P5_OUT_PU	=	0x00ab
                           0000AC   312 _P5_DIR	=	0x00ac
                           0000AD   313 _P6_IN	=	0x00ad
                           0000AE   314 _P6_OUT_PU	=	0x00ae
                           0000AF   315 _P6_DIR	=	0x00af
                           0000F1   316 _P7	=	0x00f1
                           0000A2   317 _XBUS_AUX	=	0x00a2
                           000088   318 _TCON	=	0x0088
                           000089   319 _TMOD	=	0x0089
                           00008A   320 _TL0	=	0x008a
                           00008B   321 _TL1	=	0x008b
                           00008C   322 _TH0	=	0x008c
                           00008D   323 _TH1	=	0x008d
                           000098   324 _SCON	=	0x0098
                           000099   325 _SBUF	=	0x0099
                           0000C8   326 _T2CON	=	0x00c8
                           0000C9   327 _T2MOD	=	0x00c9
                           00CBCA   328 _RCAP2	=	0xcbca
                           0000CA   329 _RCAP2L	=	0x00ca
                           0000CB   330 _RCAP2H	=	0x00cb
                           00CDCC   331 _T2COUNT	=	0xcdcc
                           0000CC   332 _TL2	=	0x00cc
                           0000CD   333 _TH2	=	0x00cd
                           00CFCE   334 _T2CAP1	=	0xcfce
                           0000CE   335 _T2CAP1L	=	0x00ce
                           0000CF   336 _T2CAP1H	=	0x00cf
                           0000F8   337 _SPI0_STAT	=	0x00f8
                           0000F9   338 _SPI0_DATA	=	0x00f9
                           0000FA   339 _SPI0_CTRL	=	0x00fa
                           0000FB   340 _SPI0_CK_SE	=	0x00fb
                           0000FC   341 _SPI0_SETUP	=	0x00fc
                           0000BC   342 _SCON1	=	0x00bc
                           0000BD   343 _SBUF1	=	0x00bd
                           0000BE   344 _SBAUD1	=	0x00be
                           0000BF   345 _SIF1	=	0x00bf
                           0000B4   346 _SPI1_STAT	=	0x00b4
                           0000B5   347 _SPI1_DATA	=	0x00b5
                           0000B6   348 _SPI1_CTRL	=	0x00b6
                           0000B7   349 _SPI1_CK_SE	=	0x00b7
                           0000F3   350 _ADC_CTRL	=	0x00f3
                           00F5F4   351 _ADC_DAT	=	0xf5f4
                           0000F4   352 _ADC_DAT_L	=	0x00f4
                           0000F5   353 _ADC_DAT_H	=	0x00f5
                           0000F6   354 _ADC_CHAN	=	0x00f6
                           0000A6   355 _LED_COMMON	=	0x00a6
                           0000A7   356 _LED_PWM_OE	=	0x00a7
                           00C7C6   357 _LED_DMA	=	0xc7c6
                           0000C6   358 _LED_DMA_L	=	0x00c6
                           0000C7   359 _LED_DMA_H	=	0x00c7
                           0000F7   360 _LED_STATUS	=	0x00f7
                           0000B3   361 _I2CX_INT	=	0x00b3
                           0000BB   362 _I2CS_INT_ST	=	0x00bb
                                    363 ;--------------------------------------------------------
                                    364 ; special function bits
                                    365 ;--------------------------------------------------------
                                    366 	.area RSEG    (ABS,DATA)
      000000                        367 	.org 0x0000
                           0000D7   368 _CY	=	0x00d7
                           0000D6   369 _AC	=	0x00d6
                           0000D5   370 _F0	=	0x00d5
                           0000D4   371 _RS1	=	0x00d4
                           0000D3   372 _RS0	=	0x00d3
                           0000D2   373 _OV	=	0x00d2
                           0000D1   374 _F1	=	0x00d1
                           0000D0   375 _P	=	0x00d0
                           0000AF   376 _EA	=	0x00af
                           0000AE   377 _E_DIS	=	0x00ae
                           0000AD   378 _ET2	=	0x00ad
                           0000AC   379 _ES	=	0x00ac
                           0000AB   380 _ET1	=	0x00ab
                           0000AA   381 _EX1	=	0x00aa
                           0000A9   382 _ET0	=	0x00a9
                           0000A8   383 _EX0	=	0x00a8
                           0000BF   384 _PH_FLAG	=	0x00bf
                           0000BE   385 _PL_FLAG	=	0x00be
                           0000BD   386 _PT2	=	0x00bd
                           0000BC   387 _PS	=	0x00bc
                           0000BB   388 _PT1	=	0x00bb
                           0000BA   389 _PX1	=	0x00ba
                           0000B9   390 _PT0	=	0x00b9
                           0000B8   391 _PX0	=	0x00b8
                           0000EF   392 _IE_WDOG	=	0x00ef
                           0000EE   393 _IE_GPIO	=	0x00ee
                           0000ED   394 _IE_PWM_I2C	=	0x00ed
                           0000EC   395 _IE_UART1	=	0x00ec
                           0000EB   396 _IE_ADC	=	0x00eb
                           0000E9   397 _IE_USB	=	0x00e9
                           0000E8   398 _IE_SPI0	=	0x00e8
                           000087   399 _P0_7	=	0x0087
                           000086   400 _P0_6	=	0x0086
                           000085   401 _P0_5	=	0x0085
                           000084   402 _P0_4	=	0x0084
                           000083   403 _P0_3	=	0x0083
                           000082   404 _P0_2	=	0x0082
                           000081   405 _P0_1	=	0x0081
                           000080   406 _P0_0	=	0x0080
                           000081   407 _SDA0	=	0x0081
                           000080   408 _SCL0	=	0x0080
                           000083   409 _TXD_	=	0x0083
                           000082   410 _RXD_	=	0x0082
                           000085   411 _AIN13	=	0x0085
                           000084   412 _AIN12	=	0x0084
                           000083   413 _AIN11	=	0x0083
                           000082   414 _AIN10	=	0x0082
                           000081   415 _AIN9	=	0x0081
                           000080   416 _AIN8	=	0x0080
                           000097   417 _P1_7	=	0x0097
                           000096   418 _P1_6	=	0x0096
                           000095   419 _P1_5	=	0x0095
                           000094   420 _P1_4	=	0x0094
                           000093   421 _P1_3	=	0x0093
                           000092   422 _P1_2	=	0x0092
                           000091   423 _P1_1	=	0x0091
                           000090   424 _P1_0	=	0x0090
                           000097   425 _TXD1_	=	0x0097
                           000096   426 _RXD1_	=	0x0096
                           000097   427 _SCK	=	0x0097
                           000096   428 _MISO	=	0x0096
                           000095   429 _MOSI	=	0x0095
                           000094   430 _SCS	=	0x0094
                           000092   431 _INT0_	=	0x0092
                           000091   432 _T2EX	=	0x0091
                           000091   433 _CAP2	=	0x0091
                           000090   434 _T2	=	0x0090
                           000090   435 _CAP1	=	0x0090
                           000097   436 _AIN7	=	0x0097
                           000096   437 _AIN6	=	0x0096
                           000095   438 _AIN5	=	0x0095
                           000094   439 _AIN4	=	0x0094
                           000093   440 _AIN3	=	0x0093
                           000092   441 _AIN2	=	0x0092
                           000091   442 _AIN1	=	0x0091
                           000090   443 _AIN0	=	0x0090
                           0000A7   444 _P2_7	=	0x00a7
                           0000A6   445 _P2_6	=	0x00a6
                           0000A5   446 _P2_5	=	0x00a5
                           0000A4   447 _P2_4	=	0x00a4
                           0000A3   448 _P2_3	=	0x00a3
                           0000A2   449 _P2_2	=	0x00a2
                           0000A1   450 _P2_1	=	0x00a1
                           0000A0   451 _P2_0	=	0x00a0
                           0000A7   452 _TXD1	=	0x00a7
                           0000A6   453 _RXD1	=	0x00a6
                           0000A5   454 _T2EX_	=	0x00a5
                           0000A5   455 _CAP2_	=	0x00a5
                           0000A4   456 _T2_	=	0x00a4
                           0000A4   457 _CAP1_	=	0x00a4
                           0000B7   458 _P3_7	=	0x00b7
                           0000B6   459 _P3_6	=	0x00b6
                           0000B5   460 _P3_5	=	0x00b5
                           0000B4   461 _P3_4	=	0x00b4
                           0000B3   462 _P3_3	=	0x00b3
                           0000B2   463 _P3_2	=	0x00b2
                           0000B1   464 _P3_1	=	0x00b1
                           0000B0   465 _P3_0	=	0x00b0
                           0000B7   466 _SCK1	=	0x00b7
                           0000B6   467 _MISO1	=	0x00b6
                           0000B5   468 _MOSI1	=	0x00b5
                           0000B5   469 _T1	=	0x00b5
                           0000B4   470 _T0	=	0x00b4
                           0000B3   471 _INT1	=	0x00b3
                           0000B2   472 _INT0	=	0x00b2
                           0000B1   473 _TXD	=	0x00b1
                           0000B0   474 _RXD	=	0x00b0
                           0000C6   475 _P4_6	=	0x00c6
                           0000C5   476 _P4_5	=	0x00c5
                           0000C4   477 _P4_4	=	0x00c4
                           0000C3   478 _P4_3	=	0x00c3
                           0000C2   479 _P4_2	=	0x00c2
                           0000C1   480 _P4_1	=	0x00c1
                           0000C0   481 _P4_0	=	0x00c0
                           00008F   482 _TF1	=	0x008f
                           00008E   483 _TR1	=	0x008e
                           00008D   484 _TF0	=	0x008d
                           00008C   485 _TR0	=	0x008c
                           00008B   486 _IE1	=	0x008b
                           00008A   487 _IT1	=	0x008a
                           000089   488 _IE0	=	0x0089
                           000088   489 _IT0	=	0x0088
                           00009F   490 _SM0	=	0x009f
                           00009E   491 _SM1	=	0x009e
                           00009D   492 _SM2	=	0x009d
                           00009C   493 _REN	=	0x009c
                           00009B   494 _TB8	=	0x009b
                           00009A   495 _RB8	=	0x009a
                           000099   496 _TI	=	0x0099
                           000098   497 _RI	=	0x0098
                           0000CF   498 _TF2	=	0x00cf
                           0000CF   499 _CAP1F	=	0x00cf
                           0000CE   500 _EXF2	=	0x00ce
                           0000CD   501 _RCLK	=	0x00cd
                           0000CC   502 _TCLK	=	0x00cc
                           0000CB   503 _EXEN2	=	0x00cb
                           0000CA   504 _TR2	=	0x00ca
                           0000C9   505 _C_T2	=	0x00c9
                           0000C8   506 _CP_RL2	=	0x00c8
                           0000FF   507 _S0_FST_ACT	=	0x00ff
                           0000FE   508 _S0_IF_OV	=	0x00fe
                           0000FD   509 _S0_IF_FIRST	=	0x00fd
                           0000FC   510 _S0_IF_BYTE	=	0x00fc
                           0000FB   511 _S0_FREE	=	0x00fb
                           0000FA   512 _S0_T_FIFO	=	0x00fa
                           0000F8   513 _S0_R_FIFO	=	0x00f8
                           0000F7   514 _ADC_START	=	0x00f7
                                    515 ;--------------------------------------------------------
                                    516 ; overlayable register banks
                                    517 ;--------------------------------------------------------
                                    518 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        519 	.ds 8
                                    520 ;--------------------------------------------------------
                                    521 ; internal ram data
                                    522 ;--------------------------------------------------------
                                    523 	.area DSEG    (DATA)
                                    524 ;--------------------------------------------------------
                                    525 ; overlayable items in internal ram
                                    526 ;--------------------------------------------------------
                                    527 ;--------------------------------------------------------
                                    528 ; indirectly addressable internal ram data
                                    529 ;--------------------------------------------------------
                                    530 	.area ISEG    (DATA)
                                    531 ;--------------------------------------------------------
                                    532 ; absolute internal ram data
                                    533 ;--------------------------------------------------------
                                    534 	.area IABS    (ABS,DATA)
                                    535 	.area IABS    (ABS,DATA)
                                    536 ;--------------------------------------------------------
                                    537 ; bit data
                                    538 ;--------------------------------------------------------
                                    539 	.area BSEG    (BIT)
      00000C                        540 _td_finish_sloc0_1_0:
      00000C                        541 	.ds 1
      00000D                        542 _ak820_tap_dance_before_sloc0_1_0:
      00000D                        543 	.ds 1
      00000E                        544 _ak820_tap_dance_process_sloc0_1_0:
      00000E                        545 	.ds 1
                                    546 ;--------------------------------------------------------
                                    547 ; paged external ram data
                                    548 ;--------------------------------------------------------
                                    549 	.area PSEG    (PAG,XDATA)
                                    550 ;--------------------------------------------------------
                                    551 ; uninitialized external ram data
                                    552 ;--------------------------------------------------------
                                    553 	.area XSEG    (XDATA)
      00059A                        554 _td_slots:
      00059A                        555 	.ds 32
      0005BA                        556 _td_wait:
      0005BA                        557 	.ds 2
      0005BC                        558 _td_work:
      0005BC                        559 	.ds 2
      0005BE                        560 _td_entry:
      0005BE                        561 	.ds 10
      0005C8                        562 _td_time:
      0005C8                        563 	.ds 2
      0005CA                        564 _td_map:
      0005CA                        565 	.ds 128
      00064A                        566 _td_record:
      00064A                        567 	.ds 9
      000653                        568 _td_step:
      000653                        569 	.ds 1
      000654                        570 _ak820_td_invoking:
      000654                        571 	.ds 1
      000655                        572 _ak820_tap_dance_valid_entry_10000_594:
      000655                        573 	.ds 2
      000657                        574 _ak820_tap_dance_valid_basic_30000_598:
      000657                        575 	.ds 1
      000658                        576 _td_finish_interrupted_10000_603:
      000658                        577 	.ds 1
      000659                        578 _td_finish_choice_10000_604:
      000659                        579 	.ds 1
      00065A                        580 _td_finish_state_10000_604:
      00065A                        581 	.ds 1
      00065B                        582 _td_finish_extra_10000_604:
      00065B                        583 	.ds 1
      00065C                        584 _ak820_tap_dance_task_now_10000_621:
      00065C                        585 	.ds 2
      00065E                        586 _ak820_tap_dance_task_term_10000_622:
      00065E                        587 	.ds 2
      000660                        588 _ak820_tap_dance_before_event_10000_625:
      000660                        589 	.ds 2
      000662                        590 _ak820_tap_dance_process_record_10000_641:
      000662                        591 	.ds 2
                                    592 ;--------------------------------------------------------
                                    593 ; absolute external ram data
                                    594 ;--------------------------------------------------------
                                    595 	.area XABS    (ABS,XDATA)
                                    596 ;--------------------------------------------------------
                                    597 ; initialized external ram data
                                    598 ;--------------------------------------------------------
                                    599 	.area XISEG   (XDATA)
                                    600 	.area HOME    (CODE)
                                    601 	.area GSINIT0 (CODE)
                                    602 	.area GSINIT1 (CODE)
                                    603 	.area GSINIT2 (CODE)
                                    604 	.area GSINIT3 (CODE)
                                    605 	.area GSINIT4 (CODE)
                                    606 	.area GSINIT5 (CODE)
                                    607 	.area GSINIT  (CODE)
                                    608 	.area GSFINAL (CODE)
                                    609 	.area CSEG    (CODE)
                                    610 ;--------------------------------------------------------
                                    611 ; global & static initialisations
                                    612 ;--------------------------------------------------------
                                    613 	.area HOME    (CODE)
                                    614 	.area GSINIT  (CODE)
                                    615 	.area GSFINAL (CODE)
                                    616 	.area GSINIT  (CODE)
                                    617 ;--------------------------------------------------------
                                    618 ; Home
                                    619 ;--------------------------------------------------------
                                    620 	.area HOME    (CODE)
                                    621 	.area HOME    (CODE)
                                    622 ;--------------------------------------------------------
                                    623 ; code
                                    624 ;--------------------------------------------------------
                                    625 	.area CSEG    (CODE)
                                    626 ;------------------------------------------------------------
                                    627 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    628 ;------------------------------------------------------------
                                    629 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    630 ;------------------------------------------------------------
                                    631 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    632 ;	-----------------------------------------
                           000007   633 	ar7 = 0x07
                           000006   634 	ar6 = 0x06
                           000005   635 	ar5 = 0x05
                           000004   636 	ar4 = 0x04
                           000003   637 	ar3 = 0x03
                           000002   638 	ar2 = 0x02
                           000001   639 	ar1 = 0x01
                           000000   640 	ar0 = 0x00
                                    641 ;	 function ak820_tap_dance_valid
                                    642 ;	-----------------------------------------
      004361                        643 _ak820_tap_dance_valid:
      004361 12 38 55         [24]  644 	lcall	_ak820_outline_0106
      004364 90 06 55         [24]  645 	mov	dptr,#_ak820_tap_dance_valid_entry_10000_594
      004367 12 38 50         [24]  646 	lcall	_ak820_outline_0105
                                    647 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:26: const uint8_t AK820_STATE_MEM *bytes = (const uint8_t AK820_STATE_MEM *)entry;
      00436A 90 06 55         [24]  648 	mov	dptr,#_ak820_tap_dance_valid_entry_10000_594
      00436D 12 38 00         [24]  649 	lcall	_ak820_outline_0056
                                    650 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:27: if (bytes[9] & 128) return false;
      004370 74 09            [12]  651 	mov	a,#0x09
      004372 12 37 DF         [24]  652 	lcall	_ak820_outline_0017
      004375 30 E7 04         [24]  653 	jnb	acc.7,00130$
      004378 75 82 00         [24]  654 	mov	dpl, #0x00
                                    655 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:28: for (uint8_t i = 0; i < 4; ++i, bytes += 2) {
      00437B 22               [24]  656 	ret
      00437C                        657 00130$:
      00437C 7D 00            [12]  658 	mov	r5,#0x00
      00437E                        659 00114$:
      00437E BD 04 00         [24]  660 	cjne	r5,#0x04,00167$
      004381                        661 00167$:
      004381 50 38            [24]  662 	jnc	00112$
                                    663 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:29: uint8_t basic = bytes[0], mods = bytes[1];
      004383 12 38 3E         [24]  664 	lcall	_ak820_outline_0088
      004386 FC               [12]  665 	mov	r4,a
      004387 90 06 57         [24]  666 	mov	dptr,#_ak820_tap_dance_valid_basic_30000_598
      00438A 12 43 01         [24]  667 	lcall	_ak820_outline_0066
      00438D A3               [24]  668 	inc	dptr
      00438E E0               [24]  669 	movx	a,@dptr
                                    670 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:30: if (!(basic | mods)) continue;
      00438F FB               [12]  671 	mov	r3,a
      004390 4C               [12]  672 	orl	a,r4
      004391 60 22            [24]  673 	jz	00111$
                                    674 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:31: if (mods >= 32 || !((basic >= KC_A && basic <= KC_EXSEL) ||
      004393 BB 20 00         [24]  675 	cjne	r3,#0x20,00170$
      004396                        676 00170$:
      004396 50 19            [24]  677 	jnc	00105$
      004398 BC 04 00         [24]  678 	cjne	r4,#0x04,00172$
      00439B                        679 00172$:
      00439B 40 05            [24]  680 	jc	00109$
      00439D EC               [12]  681 	mov	a,r4
      00439E 24 5B            [12]  682 	add	a,#0xff - 0xa4
      0043A0 50 13            [24]  683 	jnc	00111$
                                    684 ;	free result
      0043A2                        685 00109$:
                                    686 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:32: (basic >= KC_LEFT_CTRL && basic <= KC_RIGHT_GUI))) return false;
      0043A2 90 06 57         [24]  687 	mov	dptr,#_ak820_tap_dance_valid_basic_30000_598
      0043A5 E0               [24]  688 	movx	a,@dptr
      0043A6 FC               [12]  689 	mov	r4,a
      0043A7 BC E0 00         [24]  690 	cjne	r4,#0xe0,00175$
      0043AA                        691 00175$:
      0043AA 40 05            [24]  692 	jc	00105$
      0043AC EC               [12]  693 	mov	a,r4
      0043AD 24 18            [12]  694 	add	a,#0xff - 0xe7
      0043AF 50 04            [24]  695 	jnc	00111$
                                    696 ;	free result
      0043B1                        697 00105$:
      0043B1 75 82 00         [24]  698 	mov	dpl, #0x00
      0043B4 22               [24]  699 	ret
      0043B5                        700 00111$:
                                    701 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:28: for (uint8_t i = 0; i < 4; ++i, bytes += 2) {
      0043B5 0D               [12]  702 	inc	r5
      0043B6 12 48 DA         [24]  703 	lcall	_ak820_outline_0121
      0043B9 80 C3            [24]  704 	sjmp	00114$
      0043BB                        705 00112$:
                                    706 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:34: return true;
      0043BB 75 82 01         [24]  707 	mov	dpl, #0x01
                                    708 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:35: }
      0043BE 22               [24]  709 	ret
                                    710 ;------------------------------------------------------------
                                    711 ;Allocation info for local variables in function 'td_prepare'
                                    712 ;------------------------------------------------------------
                                    713 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:38: static void td_prepare(void) {
                                    714 ;	-----------------------------------------
                                    715 ;	 function td_prepare
                                    716 ;	-----------------------------------------
      0043BF                        717 _td_prepare:
                                    718 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:39: td_record.event.key.row = td_work->source / MATRIX_COLS;
      0043BF 90 05 BC         [24]  719 	mov	dptr,#_td_work
      0043C2 12 37 B1         [24]  720 	lcall	_ak820_outline_0005
      0043C5 A3               [24]  721 	inc	dptr
      0043C6 A3               [24]  722 	inc	dptr
      0043C7 E0               [24]  723 	movx	a,@dptr
      0043C8 75 F0 08         [24]  724 	mov	b,#0x08
      0043CB 84               [48]  725 	div	ab
      0043CC 90 06 4B         [24]  726 	mov	dptr,#(_td_record + 0x0001)
      0043CF F0               [24]  727 	movx	@dptr,a
                                    728 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:40: td_record.event.key.col = td_work->source % MATRIX_COLS;
      0043D0 90 05 BC         [24]  729 	mov	dptr,#_td_work
      0043D3 12 37 B1         [24]  730 	lcall	_ak820_outline_0005
      0043D6 A3               [24]  731 	inc	dptr
      0043D7 A3               [24]  732 	inc	dptr
      0043D8 E0               [24]  733 	movx	a,@dptr
      0043D9 FF               [12]  734 	mov	r7,a
      0043DA 53 07 07         [24]  735 	anl	ar7,#0x07
      0043DD 90 06 4A         [24]  736 	mov	dptr,#_td_record
      0043E0 EF               [12]  737 	mov	a,r7
      0043E1 F0               [24]  738 	movx	@dptr,a
                                    739 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:41: td_record.event.type = KEY_EVENT;
      0043E2 90 06 4E         [24]  740 	mov	dptr,#(_td_record + 0x0004)
      0043E5 74 01            [12]  741 	mov	a,#0x01
      0043E7 F0               [24]  742 	movx	@dptr,a
                                    743 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:42: td_record.event.time = td_time;
      0043E8 90 05 C8         [24]  744 	mov	dptr,#_td_time
      0043EB 12 38 00         [24]  745 	lcall	_ak820_outline_0056
      0043EE 90 06 4C         [24]  746 	mov	dptr,#(_td_record + 0x0002)
      0043F1 12 48 D4         [24]  747 	lcall	_ak820_outline_0064
                                    748 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:43: td_record.tap.count = 1;
      0043F4 90 06 50         [24]  749 	mov	dptr,#(_td_record + 0x0006)
      0043F7 E0               [24]  750 	movx	a,@dptr
      0043F8 54 0F            [12]  751 	anl	a,#0x0f
      0043FA 44 10            [12]  752 	orl	a,#0x10
      0043FC F0               [24]  753 	movx	@dptr,a
                                    754 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:44: }
      0043FD 22               [24]  755 	ret
                                    756 ;------------------------------------------------------------
                                    757 ;Allocation info for local variables in function 'td_finish'
                                    758 ;------------------------------------------------------------
                                    759 ;interrupted   Allocated with name '_td_finish_interrupted_10000_603'
                                    760 ;choice        Allocated with name '_td_finish_choice_10000_604'
                                    761 ;state         Allocated with name '_td_finish_state_10000_604'
                                    762 ;extra         Allocated with name '_td_finish_extra_10000_604'
                                    763 ;------------------------------------------------------------
                                    764 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:45: static void td_finish(bool interrupted) {
                                    765 ;	-----------------------------------------
                                    766 ;	 function td_finish
                                    767 ;	-----------------------------------------
      0043FE                        768 _td_finish:
      0043FE E5 82            [12]  769 	mov	a,dpl
      004400 90 06 58         [24]  770 	mov	dptr,#_td_finish_interrupted_10000_603
      004403 F0               [24]  771 	movx	@dptr,a
                                    772 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:46: uint8_t choice = 0, state;
      004404 90 06 59         [24]  773 	mov	dptr,#_td_finish_choice_10000_604
      004407 E4               [12]  774 	clr	a
      004408 F0               [24]  775 	movx	@dptr,a
                                    776 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:47: bool extra = false;
      004409 90 06 5B         [24]  777 	mov	dptr,#_td_finish_extra_10000_604
      00440C F0               [24]  778 	movx	@dptr,a
                                    779 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:48: if (ak820_td_invoking) return;
      00440D 90 06 54         [24]  780 	mov	dptr,#_ak820_td_invoking
      004410 E0               [24]  781 	movx	a,@dptr
      004411 60 01            [24]  782 	jz	00102$
      004413 22               [24]  783 	ret
      004414                        784 00102$:
                                    785 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:49: if (!td_wait) return;
      004414 90 05 BA         [24]  786 	mov	dptr,#_td_wait
      004417 12 38 00         [24]  787 	lcall	_ak820_outline_0056
      00441A 90 05 BA         [24]  788 	mov	dptr,#_td_wait
      00441D 12 48 B5         [24]  789 	lcall	_ak820_outline_0037
      004420 70 01            [24]  790 	jnz	00104$
      004422 22               [24]  791 	ret
      004423                        792 00104$:
                                    793 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:50: ak820_td_invoking = true;
      004423 90 06 54         [24]  794 	mov	dptr,#_ak820_td_invoking
      004426 74 01            [12]  795 	mov	a,#0x01
      004428 F0               [24]  796 	movx	@dptr,a
                                    797 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:51: td_work = td_wait;
      004429 90 05 BC         [24]  798 	mov	dptr,#_td_work
      00442C 12 48 D4         [24]  799 	lcall	_ak820_outline_0064
                                    800 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:52: td_wait = 0;
      00442F 90 05 BA         [24]  801 	mov	dptr,#_td_wait
      004432 12 48 E2         [24]  802 	lcall	_ak820_outline_0143
                                    803 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:53: state = td_work->state;
      004435 12 48 6A         [24]  804 	lcall	_ak820_outline_0007
      004438 FD               [12]  805 	mov	r5,a
      004439 90 06 5A         [24]  806 	mov	dptr,#_td_finish_state_10000_604
      00443C F0               [24]  807 	movx	@dptr,a
                                    808 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:54: td_work->state = state | TD_DONE;
      00443D 43 05 08         [24]  809 	orl	ar5,#0x08
      004440 12 43 2C         [24]  810 	lcall	_ak820_outline_0119
      004443 ED               [12]  811 	mov	a,r5
      004444 F0               [24]  812 	movx	@dptr,a
                                    813 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:55: if ((state & 3) == 1) {
      004445 90 06 5A         [24]  814 	mov	dptr,#_td_finish_state_10000_604
      004448 E0               [24]  815 	movx	a,@dptr
      004449 FF               [12]  816 	mov	r7,a
      00444A FE               [12]  817 	mov	r6,a
      00444B 53 06 03         [24]  818 	anl	ar6,#0x03
      00444E BE 01 12         [24]  819 	cjne	r6,#0x01,00112$
                                    820 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:56: if ((state & TD_DOWN) && !interrupted) choice = 1;
      004451 EF               [12]  821 	mov	a,r7
      004452 30 E2 2B         [24]  822 	jnb	acc.2,00113$
      004455 90 06 58         [24]  823 	mov	dptr,#_td_finish_interrupted_10000_603
      004458 E0               [24]  824 	movx	a,@dptr
      004459 70 25            [24]  825 	jnz	00113$
      00445B 90 06 59         [24]  826 	mov	dptr,#_td_finish_choice_10000_604
      00445E 74 01            [12]  827 	mov	a,#0x01
      004460 F0               [24]  828 	movx	@dptr,a
      004461 80 1D            [24]  829 	sjmp	00113$
      004463                        830 00112$:
                                    831 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:57: } else if (interrupted) extra = true;
      004463 90 06 58         [24]  832 	mov	dptr,#_td_finish_interrupted_10000_603
      004466 E0               [24]  833 	movx	a,@dptr
      004467 60 08            [24]  834 	jz	00109$
      004469 90 06 5B         [24]  835 	mov	dptr,#_td_finish_extra_10000_604
      00446C 74 01            [12]  836 	mov	a,#0x01
      00446E F0               [24]  837 	movx	@dptr,a
      00446F 80 0F            [24]  838 	sjmp	00113$
      004471                        839 00109$:
                                    840 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:58: else choice = (state & TD_DOWN) ? 3 : 2;
      004471 EF               [12]  841 	mov	a,r7
      004472 30 E2 04         [24]  842 	jnb	acc.2,00136$
      004475 7F 03            [12]  843 	mov	r7,#0x03
      004477 80 02            [24]  844 	sjmp	00137$
      004479                        845 00136$:
      004479 7F 02            [12]  846 	mov	r7,#0x02
      00447B                        847 00137$:
      00447B 90 06 59         [24]  848 	mov	dptr,#_td_finish_choice_10000_604
      00447E EF               [12]  849 	mov	a,r7
      00447F F0               [24]  850 	movx	@dptr,a
      004480                        851 00113$:
                                    852 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:59: td_work->output = ((uint16_t AK820_STATE_MEM *)&td_entry)[choice];
      004480 90 05 BC         [24]  853 	mov	dptr,#_td_work
      004483 12 38 00         [24]  854 	lcall	_ak820_outline_0056
      004486 90 06 59         [24]  855 	mov	dptr,#_td_finish_choice_10000_604
      004489 E0               [24]  856 	movx	a,@dptr
      00448A FD               [12]  857 	mov	r5,a
      00448B 75 F0 02         [24]  858 	mov	b,#0x02
      00448E A4               [48]  859 	mul	ab
      00448F 24 BE            [12]  860 	add	a, #_td_entry
      004491 F5 82            [12]  861 	mov	dpl,a
      004493 74 05            [12]  862 	mov	a,#(_td_entry >> 8)
      004495 35 F0            [12]  863 	addc	a, b
      004497 F5 83            [12]  864 	mov	dph,a
      004499 12 38 4A         [24]  865 	lcall	_ak820_outline_0103
      00449C 12 43 2C         [24]  866 	lcall	_ak820_outline_0119
      00449F 12 38 38         [24]  867 	lcall	_ak820_outline_0081
                                    868 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:60: if (!td_work->output) {
      0044A2 90 05 BC         [24]  869 	mov	dptr,#_td_work
      0044A5 12 37 B1         [24]  870 	lcall	_ak820_outline_0005
      0044A8 E0               [24]  871 	movx	a,@dptr
      0044A9 FB               [12]  872 	mov	r3,a
      0044AA A3               [24]  873 	inc	dptr
      0044AB E0               [24]  874 	movx	a,@dptr
      0044AC 4B               [12]  875 	orl	a,r3
      0044AD 70 28            [24]  876 	jnz	00117$
                                    877 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:61: if (choice >= 2) extra = true;
      0044AF BD 02 00         [24]  878 	cjne	r5,#0x02,00286$
      0044B2                        879 00286$:
      0044B2 40 06            [24]  880 	jc	00115$
      0044B4 90 06 5B         [24]  881 	mov	dptr,#_td_finish_extra_10000_604
      0044B7 74 01            [12]  882 	mov	a,#0x01
      0044B9 F0               [24]  883 	movx	@dptr,a
      0044BA                        884 00115$:
                                    885 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:62: td_work->output = choice == 3 && td_entry.on_hold ? td_entry.on_hold : td_entry.on_tap;
      0044BA 90 06 59         [24]  886 	mov	dptr,#_td_finish_choice_10000_604
      0044BD E0               [24]  887 	movx	a,@dptr
      0044BE FD               [12]  888 	mov	r5,a
      0044BF BD 03 09         [24]  889 	cjne	r5,#0x03,00138$
      0044C2 90 05 C0         [24]  890 	mov	dptr,#(_td_entry + 0x0002)
      0044C5 12 38 1F         [24]  891 	lcall	_ak820_outline_0065
      0044C8 4C               [12]  892 	orl	a,r4
      0044C9 70 06            [24]  893 	jnz	00139$
      0044CB                        894 00138$:
      0044CB 90 05 BE         [24]  895 	mov	dptr,#_td_entry
      0044CE 12 38 1F         [24]  896 	lcall	_ak820_outline_0065
      0044D1                        897 00139$:
      0044D1 12 43 2C         [24]  898 	lcall	_ak820_outline_0119
      0044D4 12 38 2B         [24]  899 	lcall	_ak820_outline_0077
      0044D7                        900 00117$:
                                    901 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:64: td_step = extra ? 0 : 2;
      0044D7 90 06 5B         [24]  902 	mov	dptr,#_td_finish_extra_10000_604
      0044DA E0               [24]  903 	movx	a,@dptr
      0044DB 60 04            [24]  904 	jz	00143$
      0044DD 7F 00            [12]  905 	mov	r7,#0x00
      0044DF 80 02            [24]  906 	sjmp	00144$
      0044E1                        907 00143$:
      0044E1 7F 02            [12]  908 	mov	r7,#0x02
      0044E3                        909 00144$:
      0044E3 90 06 53         [24]  910 	mov	dptr,#_td_step
      0044E6 EF               [12]  911 	mov	a,r7
      0044E7 F0               [24]  912 	movx	@dptr,a
                                    913 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:65: td_record.keycode = td_entry.on_tap;
      0044E8 90 05 BE         [24]  914 	mov	dptr,#_td_entry
      0044EB 12 48 93         [24]  915 	lcall	_ak820_outline_0031
                                    916 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:66: td_prepare();
      0044EE 12 43 BF         [24]  917 	lcall	_td_prepare
      0044F1                        918 00132$:
                                    919 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:69: for (; td_step < 4; ++td_step) {
      0044F1 90 06 53         [24]  920 	mov	dptr,#_td_step
      0044F4 E0               [24]  921 	movx	a,@dptr
      0044F5 FF               [12]  922 	mov	r7,a
      0044F6 BF 04 00         [24]  923 	cjne	r7,#0x04,00292$
      0044F9                        924 00292$:
      0044F9 50 4B            [24]  925 	jnc	00127$
                                    926 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:70: if (td_step == 2) td_record.keycode = td_work->output;
      0044FB BF 02 09         [24]  927 	cjne	r7,#0x02,00119$
      0044FE 90 05 BC         [24]  928 	mov	dptr,#_td_work
      004501 12 37 B1         [24]  929 	lcall	_ak820_outline_0005
      004504 12 48 93         [24]  930 	lcall	_ak820_outline_0031
      004507                        931 00119$:
                                    932 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:71: if (td_step == 3 && (td_work->state & TD_DOWN)) break;
      004507 90 06 53         [24]  933 	mov	dptr,#_td_step
      00450A E0               [24]  934 	movx	a,@dptr
      00450B FF               [12]  935 	mov	r7,a
      00450C BF 03 0D         [24]  936 	cjne	r7,#0x03,00121$
      00450F 90 05 BC         [24]  937 	mov	dptr,#_td_work
      004512 12 37 B1         [24]  938 	lcall	_ak820_outline_0005
      004515 A3               [24]  939 	inc	dptr
      004516 A3               [24]  940 	inc	dptr
      004517 A3               [24]  941 	inc	dptr
      004518 E0               [24]  942 	movx	a,@dptr
      004519 20 E2 2A         [24]  943 	jb	acc.2,00127$
      00451C                        944 00121$:
                                    945 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:72: td_record.event.pressed = !(td_step & 1);
      00451C 90 06 53         [24]  946 	mov	dptr,#_td_step
      00451F E0               [24]  947 	movx	a,@dptr
      004520 54 01            [12]  948 	anl	a,#0x01
      004522 B4 01 00         [24]  949 	cjne	a,#0x01,00299$
      004525                        950 00299$:
      004525 92 0C            [24]  951 	mov	_td_finish_sloc0_1_0,c
      004527 90 06 4F         [24]  952 	mov	dptr,#(_td_record + 0x0005)
      00452A E4               [12]  953 	clr	a
      00452B 33               [12]  954 	rlc	a
      00452C 12 48 E7         [24]  955 	lcall	_ak820_outline_0146
                                    956 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:73: if (td_record.keycode) process_record(&td_record);
      00452F 60 06            [24]  957 	jz	00124$
      004531 90 06 4A         [24]  958 	mov	dptr,#_td_record
      004534 12 75 A3         [24]  959 	lcall	_process_record
      004537                        960 00124$:
                                    961 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:74: if (!td_work->state) goto done;
      004537 12 48 6A         [24]  962 	lcall	_ak820_outline_0007
      00453A 60 15            [24]  963 	jz	00130$
                                    964 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:69: for (; td_step < 4; ++td_step) {
      00453C 90 06 53         [24]  965 	mov	dptr,#_td_step
      00453F E0               [24]  966 	movx	a,@dptr
      004540 24 01            [12]  967 	add	a, #0x01
      004542 F0               [24]  968 	movx	@dptr,a
      004543 02 44 F1         [24]  969 	ljmp	00132$
      004546                        970 00127$:
                                    971 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:76: if (!(td_work->state & TD_DOWN)) td_work->state = 0;
      004546 12 48 6A         [24]  972 	lcall	_ak820_outline_0007
      004549 20 E2 05         [24]  973 	jb	acc.2,00130$
      00454C 12 43 2C         [24]  974 	lcall	_ak820_outline_0119
      00454F E4               [12]  975 	clr	a
      004550 F0               [24]  976 	movx	@dptr,a
                                    977 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:77: done:
      004551                        978 00130$:
                                    979 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:78: ak820_td_invoking = false;
      004551 90 06 54         [24]  980 	mov	dptr,#_ak820_td_invoking
      004554 E4               [12]  981 	clr	a
      004555 F0               [24]  982 	movx	@dptr,a
                                    983 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:79: }
      004556 22               [24]  984 	ret
                                    985 ;------------------------------------------------------------
                                    986 ;Allocation info for local variables in function 'ak820_tap_dance_task'
                                    987 ;------------------------------------------------------------
                                    988 ;now           Allocated with name '_ak820_tap_dance_task_now_10000_621'
                                    989 ;term          Allocated with name '_ak820_tap_dance_task_term_10000_622'
                                    990 ;------------------------------------------------------------
                                    991 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:80: void ak820_tap_dance_task(uint16_t now) {
                                    992 ;	-----------------------------------------
                                    993 ;	 function ak820_tap_dance_task
                                    994 ;	-----------------------------------------
      004557                        995 _ak820_tap_dance_task:
      004557 12 38 55         [24]  996 	lcall	_ak820_outline_0106
      00455A 90 06 5C         [24]  997 	mov	dptr,#_ak820_tap_dance_task_now_10000_621
      00455D 12 38 50         [24]  998 	lcall	_ak820_outline_0105
                                    999 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:81: uint16_t term = td_entry.custom_tapping_term;
      004560 90 05 C6         [24] 1000 	mov	dptr,#(_td_entry + 0x0008)
      004563 12 38 00         [24] 1001 	lcall	_ak820_outline_0056
      004566 90 06 5E         [24] 1002 	mov	dptr,#_ak820_tap_dance_task_term_10000_622
      004569 12 48 D4         [24] 1003 	lcall	_ak820_outline_0064
                                   1004 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:82: if (!term) term = 200;
      00456C EE               [12] 1005 	mov	a,r6
      00456D 4F               [12] 1006 	orl	a,r7
      00456E 70 08            [24] 1007 	jnz	00102$
      004570 90 06 5E         [24] 1008 	mov	dptr,#_ak820_tap_dance_task_term_10000_622
      004573 74 C8            [12] 1009 	mov	a,#0xc8
      004575 12 38 65         [24] 1010 	lcall	_ak820_outline_0127
      004578                       1011 00102$:
                                   1012 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:83: if (td_wait && (uint16_t)(now - td_time) >= term) td_finish(false);
      004578 90 05 BA         [24] 1013 	mov	dptr,#_td_wait
      00457B 12 48 B5         [24] 1014 	lcall	_ak820_outline_0037
      00457E 60 26            [24] 1015 	jz	00106$
      004580 90 05 C8         [24] 1016 	mov	dptr,#_td_time
      004583 12 38 00         [24] 1017 	lcall	_ak820_outline_0056
      004586 90 06 5C         [24] 1018 	mov	dptr,#_ak820_tap_dance_task_now_10000_621
      004589 12 38 1F         [24] 1019 	lcall	_ak820_outline_0065
      00458C EC               [12] 1020 	mov	a,r4
      00458D C3               [12] 1021 	clr	c
      00458E 9E               [12] 1022 	subb	a,r6
      00458F FE               [12] 1023 	mov	r6,a
      004590 ED               [12] 1024 	mov	a,r5
      004591 9F               [12] 1025 	subb	a,r7
      004592 FF               [12] 1026 	mov	r7,a
      004593 90 06 5E         [24] 1027 	mov	dptr,#_ak820_tap_dance_task_term_10000_622
      004596 12 38 1F         [24] 1028 	lcall	_ak820_outline_0065
      004599 C3               [12] 1029 	clr	c
      00459A EE               [12] 1030 	mov	a,r6
      00459B 9C               [12] 1031 	subb	a,r4
      00459C EF               [12] 1032 	mov	a,r7
      00459D 9D               [12] 1033 	subb	a,r5
      00459E 40 06            [24] 1034 	jc	00106$
      0045A0 75 82 00         [24] 1035 	mov	dpl, #0x00
                                   1036 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:84: }
      0045A3 02 43 FE         [24] 1037 	ljmp	_td_finish
      0045A6                       1038 00106$:
      0045A6 22               [24] 1039 	ret
                                   1040 ;------------------------------------------------------------
                                   1041 ;Allocation info for local variables in function 'ak820_tap_dance_before'
                                   1042 ;------------------------------------------------------------
                                   1043 ;event         Allocated with name '_ak820_tap_dance_before_event_10000_625'
                                   1044 ;id            Allocated with name '_ak820_tap_dance_before_id_10000_626'
                                   1045 ;slot          Allocated with name '_ak820_tap_dance_before_slot_10000_626'
                                   1046 ;------------------------------------------------------------
                                   1047 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:85: bool ak820_tap_dance_before(const keyevent_t AK820_STATE_MEM *event) {
                                   1048 ;	-----------------------------------------
                                   1049 ;	 function ak820_tap_dance_before
                                   1050 ;	-----------------------------------------
      0045A7                       1051 _ak820_tap_dance_before:
      0045A7 12 38 55         [24] 1052 	lcall	_ak820_outline_0106
      0045AA 90 06 60         [24] 1053 	mov	dptr,#_ak820_tap_dance_before_event_10000_625
      0045AD 12 38 50         [24] 1054 	lcall	_ak820_outline_0105
                                   1055 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:88: if (IS_NOEVENT(*event)) return true;
      0045B0 90 06 60         [24] 1056 	mov	dptr,#_ak820_tap_dance_before_event_10000_625
      0045B3 12 38 00         [24] 1057 	lcall	_ak820_outline_0056
      0045B6 74 04            [12] 1058 	mov	a,#0x04
      0045B8 12 48 7F         [24] 1059 	lcall	_ak820_outline_0012
      0045BB 70 04            [24] 1060 	jnz	00102$
      0045BD 75 82 01         [24] 1061 	mov	dpl, #0x01
      0045C0 22               [24] 1062 	ret
      0045C1                       1063 00102$:
                                   1064 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:89: if (event->key.row >= MATRIX_ROWS || event->key.col >= MATRIX_COLS) {
      0045C1 12 38 31         [24] 1065 	lcall	_ak820_outline_0079
      0045C4 FD               [12] 1066 	mov	r5,a
      0045C5 BD 10 00         [24] 1067 	cjne	r5,#0x10,00220$
      0045C8                       1068 00220$:
      0045C8 50 09            [24] 1069 	jnc	00105$
      0045CA 12 38 3E         [24] 1070 	lcall	_ak820_outline_0088
      0045CD FC               [12] 1071 	mov	r4,a
      0045CE BC 08 00         [24] 1072 	cjne	r4,#0x08,00222$
      0045D1                       1073 00222$:
      0045D1 40 1D            [24] 1074 	jc	00106$
      0045D3                       1075 00105$:
                                   1076 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:90: if (event->pressed) td_finish(true);
      0045D3 90 06 60         [24] 1077 	mov	dptr,#_ak820_tap_dance_before_event_10000_625
      0045D6 12 43 0E         [24] 1078 	lcall	_ak820_outline_0082
      0045D9 74 05            [12] 1079 	mov	a,#0x05
      0045DB 2A               [12] 1080 	add	a, r2
      0045DC FA               [12] 1081 	mov	r2,a
      0045DD E4               [12] 1082 	clr	a
      0045DE 3B               [12] 1083 	addc	a, r3
      0045DF FB               [12] 1084 	mov	r3,a
      0045E0 12 43 31         [24] 1085 	lcall	_ak820_outline_0135
      0045E3 E0               [24] 1086 	movx	a,@dptr
      0045E4 60 06            [24] 1087 	jz	00104$
      0045E6 75 82 01         [24] 1088 	mov	dpl, #0x01
      0045E9 12 43 FE         [24] 1089 	lcall	_td_finish
      0045EC                       1090 00104$:
                                   1091 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:91: return true;
      0045EC 75 82 01         [24] 1092 	mov	dpl, #0x01
      0045EF 22               [24] 1093 	ret
      0045F0                       1094 00106$:
                                   1095 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:93: id = event->key.row * MATRIX_COLS + event->key.col;
      0045F0 ED               [12] 1096 	mov	a,r5
      0045F1 12 38 79         [24] 1097 	lcall	_ak820_outline_0161
                                   1098 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:94: if (td_map[id] == TD_NONE) {
      0045F4 2C               [12] 1099 	add	a,r4
      0045F5 FD               [12] 1100 	mov	r5,a
      0045F6 24 CA            [12] 1101 	add	a, #_td_map
      0045F8 FB               [12] 1102 	mov	r3,a
      0045F9 E4               [12] 1103 	clr	a
      0045FA 34 05            [12] 1104 	addc	a, #(_td_map >> 8)
      0045FC 12 48 C5         [24] 1105 	lcall	_ak820_outline_0049
      0045FF BA FF 11         [24] 1106 	cjne	r2,#0xff,00111$
                                   1107 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:95: if (!event->pressed) td_map[id] = 0;
      004602 74 05            [12] 1108 	mov	a,#0x05
      004604 2E               [12] 1109 	add	a, r6
      004605 12 37 D5         [24] 1110 	lcall	_ak820_outline_0016
      004608 70 05            [24] 1111 	jnz	00109$
      00460A 12 33 FC         [24] 1112 	lcall	_ak820_outline_0124
      00460D E4               [12] 1113 	clr	a
      00460E F0               [24] 1114 	movx	@dptr,a
      00460F                       1115 00109$:
                                   1116 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:96: return false;
      00460F 75 82 00         [24] 1117 	mov	dpl, #0x00
      004612 22               [24] 1118 	ret
      004613                       1119 00111$:
                                   1120 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:98: if (event->pressed && td_wait && (td_wait->source != id || (td_wait->state & 3) == 2)) td_finish(true);
      004613 12 37 A4         [24] 1121 	lcall	_ak820_outline_0001
      004616 60 1F            [24] 1122 	jz	00113$
      004618 90 05 BA         [24] 1123 	mov	dptr,#_td_wait
      00461B 12 38 00         [24] 1124 	lcall	_ak820_outline_0056
      00461E 4E               [12] 1125 	orl	a,r6
      00461F 60 16            [24] 1126 	jz	00113$
      004621 12 37 F0         [24] 1127 	lcall	_ak820_outline_0034
      004624 B5 05 0A         [24] 1128 	cjne	a,ar5,00112$
      004627 12 48 8A         [24] 1129 	lcall	_ak820_outline_0015
      00462A FF               [12] 1130 	mov	r7,a
      00462B 53 07 03         [24] 1131 	anl	ar7,#0x03
      00462E BF 02 06         [24] 1132 	cjne	r7,#0x02,00113$
      004631                       1133 00112$:
      004631 75 82 01         [24] 1134 	mov	dpl, #0x01
      004634 12 43 FE         [24] 1135 	lcall	_td_finish
      004637                       1136 00113$:
                                   1137 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:99: id = event->key.row * MATRIX_COLS + event->key.col;
      004637 90 06 60         [24] 1138 	mov	dptr,#_ak820_tap_dance_before_event_10000_625
      00463A 12 37 B1         [24] 1139 	lcall	_ak820_outline_0005
      00463D A3               [24] 1140 	inc	dptr
      00463E E0               [24] 1141 	movx	a,@dptr
      00463F 12 38 79         [24] 1142 	lcall	_ak820_outline_0161
      004642 FD               [12] 1143 	mov	r5,a
      004643 12 38 3E         [24] 1144 	lcall	_ak820_outline_0088
      004646 2D               [12] 1145 	add	a, r5
                                   1146 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:100: slot = td_slots + td_map[id];
      004647 FD               [12] 1147 	mov	r5,a
      004648 12 48 A1         [24] 1148 	lcall	_ak820_outline_0032
      00464B E0               [24] 1149 	movx	a,@dptr
      00464C 12 38 8F         [24] 1150 	lcall	_ak820_outline_0189
      00464F 24 9A            [12] 1151 	add	a, #_td_slots
      004651 FB               [12] 1152 	mov	r3,a
      004652 74 05            [12] 1153 	mov	a,#(_td_slots >> 8)
      004654 35 F0            [12] 1154 	addc	a, b
      004656 FC               [12] 1155 	mov	r4,a
                                   1156 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:101: if (slot->state && slot->source == id) {
      004657 74 03            [12] 1157 	mov	a,#0x03
      004659 2B               [12] 1158 	add	a, r3
      00465A F9               [12] 1159 	mov	r1,a
      00465B E4               [12] 1160 	clr	a
      00465C 3C               [12] 1161 	addc	a, r4
      00465D FA               [12] 1162 	mov	r2,a
      00465E 12 43 41         [24] 1163 	lcall	_ak820_outline_0150
      004661 E0               [24] 1164 	movx	a,@dptr
      004662 F8               [12] 1165 	mov	r0,a
      004663 60 57            [24] 1166 	jz	00124$
      004665 C0 00            [24] 1167 	push	ar0
      004667 12 33 FC         [24] 1168 	lcall	_ak820_outline_0124
      00466A A3               [24] 1169 	inc	dptr
      00466B A3               [24] 1170 	inc	dptr
      00466C E0               [24] 1171 	movx	a,@dptr
      00466D B5 05 02         [24] 1172 	cjne	a,ar5,00235$
      004670 80 04            [24] 1173 	sjmp	00236$
      004672                       1174 00235$:
      004672 D0 00            [24] 1175 	pop	ar0
      004674 80 46            [24] 1176 	sjmp	00124$
      004676                       1177 00236$:
      004676 D0 00            [24] 1178 	pop	ar0
                                   1179 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:102: if (event->pressed) return !(slot->state & TD_DONE);
      004678 12 37 A4         [24] 1180 	lcall	_ak820_outline_0001
      00467B 60 0E            [24] 1181 	jz	00118$
      00467D E8               [12] 1182 	mov	a,r0
      00467E A2 E3            [12] 1183 	mov	c,acc.3
      004680 E4               [12] 1184 	clr	a
      004681 33               [12] 1185 	rlc	a
      004682 B4 01 00         [24] 1186 	cjne	a,#0x01,00238$
      004685                       1187 00238$:
      004685 92 0D            [24] 1188 	mov  _ak820_tap_dance_before_sloc0_1_0,c
      004687 12 38 6F         [24] 1189 	lcall	_ak820_outline_0149
      00468A 22               [24] 1190 	ret
      00468B                       1191 00118$:
                                   1192 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:103: slot->state &= ~TD_DOWN;
      00468B 53 00 FB         [24] 1193 	anl	ar0,#0xfb
      00468E 12 48 CD         [24] 1194 	lcall	_ak820_outline_0063
                                   1195 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:104: if (slot->state & TD_DONE) {
      004691 E8               [12] 1196 	mov	a,r0
      004692 30 E3 23         [24] 1197 	jnb	acc.3,00122$
                                   1198 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:105: td_work = slot;
      004695 90 05 BC         [24] 1199 	mov	dptr,#_td_work
      004698 12 38 38         [24] 1200 	lcall	_ak820_outline_0081
                                   1201 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:106: td_record.keycode = slot->output;
      00469B 12 33 FC         [24] 1202 	lcall	_ak820_outline_0124
      00469E 12 48 93         [24] 1203 	lcall	_ak820_outline_0031
                                   1204 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:107: slot->state = 0;
      0046A1 12 43 41         [24] 1205 	lcall	_ak820_outline_0150
      0046A4 E4               [12] 1206 	clr	a
      0046A5 F0               [24] 1207 	movx	@dptr,a
                                   1208 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:108: td_prepare();
      0046A6 12 43 BF         [24] 1209 	lcall	_td_prepare
                                   1210 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:109: td_record.event.pressed = false;
      0046A9 90 06 4F         [24] 1211 	mov	dptr,#(_td_record + 0x0005)
      0046AC E4               [12] 1212 	clr	a
      0046AD 12 48 E7         [24] 1213 	lcall	_ak820_outline_0146
                                   1214 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:110: if (td_record.keycode) process_record(&td_record);
      0046B0 60 06            [24] 1215 	jz	00122$
      0046B2 90 06 4A         [24] 1216 	mov	dptr,#_td_record
      0046B5 12 75 A3         [24] 1217 	lcall	_process_record
      0046B8                       1218 00122$:
                                   1219 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:112: return false;
      0046B8 75 82 00         [24] 1220 	mov	dpl, #0x00
      0046BB 22               [24] 1221 	ret
      0046BC                       1222 00124$:
                                   1223 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:114: return true;
      0046BC 75 82 01         [24] 1224 	mov	dpl, #0x01
                                   1225 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:115: }
      0046BF 22               [24] 1226 	ret
                                   1227 ;------------------------------------------------------------
                                   1228 ;Allocation info for local variables in function 'ak820_tap_dance_process'
                                   1229 ;------------------------------------------------------------
                                   1230 ;record        Allocated with name '_ak820_tap_dance_process_record_10000_641'
                                   1231 ;index         Allocated with name '_ak820_tap_dance_process_index_10000_642'
                                   1232 ;id            Allocated with name '_ak820_tap_dance_process_id_10000_642'
                                   1233 ;slot          Allocated with name '_ak820_tap_dance_process_slot_10000_642'
                                   1234 ;------------------------------------------------------------
                                   1235 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:116: bool ak820_tap_dance_process(keyrecord_t AK820_STATE_MEM *record) {
                                   1236 ;	-----------------------------------------
                                   1237 ;	 function ak820_tap_dance_process
                                   1238 ;	-----------------------------------------
      0046C0                       1239 _ak820_tap_dance_process:
      0046C0 12 38 55         [24] 1240 	lcall	_ak820_outline_0106
      0046C3 90 06 62         [24] 1241 	mov	dptr,#_ak820_tap_dance_process_record_10000_641
      0046C6 12 38 50         [24] 1242 	lcall	_ak820_outline_0105
                                   1243 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:119: if (get_repeat_key_count() || ak820_macro_primitive || record->event.type != KEY_EVENT ||
      0046C9 12 A6 B7         [24] 1244 	lcall	_get_repeat_key_count
      0046CC E5 82            [12] 1245 	mov	a, dpl
      0046CE 70 2F            [24] 1246 	jnz	00101$
      0046D0 90 0A 46         [24] 1247 	mov	dptr,#_ak820_macro_primitive
      0046D3 E0               [24] 1248 	movx	a,@dptr
      0046D4 70 29            [24] 1249 	jnz	00101$
      0046D6 90 06 62         [24] 1250 	mov	dptr,#_ak820_tap_dance_process_record_10000_641
      0046D9 12 37 B1         [24] 1251 	lcall	_ak820_outline_0005
      0046DC A3               [24] 1252 	inc	dptr
      0046DD A3               [24] 1253 	inc	dptr
      0046DE A3               [24] 1254 	inc	dptr
      0046DF A3               [24] 1255 	inc	dptr
      0046E0 E0               [24] 1256 	movx	a,@dptr
      0046E1 FD               [12] 1257 	mov	r5,a
      0046E2 BD 01 1A         [24] 1258 	cjne	r5,#0x01,00101$
                                   1259 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:120: record->event.key.row >= MATRIX_ROWS || record->event.key.col >= MATRIX_COLS ||
      0046E5 12 38 31         [24] 1260 	lcall	_ak820_outline_0079
      0046E8 FD               [12] 1261 	mov	r5,a
      0046E9 BD 10 00         [24] 1262 	cjne	r5,#0x10,00228$
      0046EC                       1263 00228$:
      0046EC 50 11            [24] 1264 	jnc	00101$
      0046EE 12 38 3E         [24] 1265 	lcall	_ak820_outline_0088
      0046F1 FC               [12] 1266 	mov	r4,a
      0046F2 BC 08 00         [24] 1267 	cjne	r4,#0x08,00230$
      0046F5                       1268 00230$:
      0046F5 50 08            [24] 1269 	jnc	00101$
                                   1270 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:121: !record->event.pressed) return (record->keycode >> 8) != (QK_TAP_DANCE >> 8);
      0046F7 74 05            [12] 1271 	mov	a,#0x05
      0046F9 2E               [12] 1272 	add	a, r6
      0046FA 12 48 AB         [24] 1273 	lcall	_ak820_outline_0033
      0046FD 70 26            [24] 1274 	jnz	00102$
      0046FF                       1275 00101$:
      0046FF 90 06 62         [24] 1276 	mov	dptr,#_ak820_tap_dance_process_record_10000_641
      004702 12 43 0E         [24] 1277 	lcall	_ak820_outline_0082
      004705 74 07            [12] 1278 	mov	a,#0x07
      004707 2A               [12] 1279 	add	a, r2
      004708 F5 82            [12] 1280 	mov	dpl,a
      00470A E4               [12] 1281 	clr	a
      00470B 3B               [12] 1282 	addc	a, r3
      00470C F5 83            [12] 1283 	mov	dph,a
      00470E E0               [24] 1284 	movx	a,@dptr
      00470F A3               [24] 1285 	inc	dptr
      004710 E0               [24] 1286 	movx	a,@dptr
      004711 FA               [12] 1287 	mov	r2,a
      004712 7B 00            [12] 1288 	mov	r3,#0x00
      004714 BA 57 06         [24] 1289 	cjne	r2,#0x57,00233$
      004717 BB 00 03         [24] 1290 	cjne	r3,#0x00,00233$
      00471A D3               [12] 1291 	setb	c
      00471B 80 01            [24] 1292 	sjmp	00234$
      00471D                       1293 00233$:
      00471D C3               [12] 1294 	clr	c
      00471E                       1295 00234$:
      00471E B3               [12] 1296 	cpl	c
      00471F 92 0E            [24] 1297 	mov	_ak820_tap_dance_process_sloc0_1_0,c
      004721 12 38 6F         [24] 1298 	lcall	_ak820_outline_0149
      004724 22               [24] 1299 	ret
      004725                       1300 00102$:
                                   1301 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:122: id = record->event.key.row * MATRIX_COLS + record->event.key.col;
      004725 ED               [12] 1302 	mov	a,r5
      004726 12 38 79         [24] 1303 	lcall	_ak820_outline_0161
      004729 2C               [12] 1304 	add	a,r4
      00472A FD               [12] 1305 	mov	r5,a
                                   1306 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:124: if (td_wait && !(td_wait->state & TD_DOWN) && td_wait->source == id &&
      00472B 90 05 BA         [24] 1307 	mov	dptr,#_td_wait
      00472E 12 38 4A         [24] 1308 	lcall	_ak820_outline_0103
      004731 4B               [12] 1309 	orl	a,r3
      004732 60 3B            [24] 1310 	jz	00109$
      004734 12 33 FC         [24] 1311 	lcall	_ak820_outline_0124
      004737 A3               [24] 1312 	inc	dptr
      004738 A3               [24] 1313 	inc	dptr
      004739 A3               [24] 1314 	inc	dptr
      00473A E0               [24] 1315 	movx	a,@dptr
      00473B 20 E2 31         [24] 1316 	jb	acc.2,00109$
      00473E 12 33 FC         [24] 1317 	lcall	_ak820_outline_0124
      004741 A3               [24] 1318 	inc	dptr
      004742 A3               [24] 1319 	inc	dptr
      004743 E0               [24] 1320 	movx	a,@dptr
      004744 B5 05 28         [24] 1321 	cjne	a,ar5,00109$
                                   1322 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:125: record->keycode != (QK_TAP_DANCE | td_map[id])) td_finish(true);
      004747 74 07            [12] 1323 	mov	a,#0x07
      004749 12 37 DF         [24] 1324 	lcall	_ak820_outline_0017
      00474C FE               [12] 1325 	mov	r6,a
      00474D A3               [24] 1326 	inc	dptr
      00474E E0               [24] 1327 	movx	a,@dptr
      00474F FF               [12] 1328 	mov	r7,a
      004750 ED               [12] 1329 	mov	a,r5
      004751 12 48 A1         [24] 1330 	lcall	_ak820_outline_0032
      004754 E0               [24] 1331 	movx	a,@dptr
      004755 FC               [12] 1332 	mov	r4,a
      004756 7B 00            [12] 1333 	mov	r3,#0x00
      004758 43 03 57         [24] 1334 	orl	ar3,#0x57
      00475B EE               [12] 1335 	mov	a,r6
      00475C B5 04 06         [24] 1336 	cjne	a,ar4,00239$
      00475F EF               [12] 1337 	mov	a,r7
      004760 B5 03 02         [24] 1338 	cjne	a,ar3,00239$
      004763 80 0A            [24] 1339 	sjmp	00109$
      004765                       1340 00239$:
      004765 75 82 01         [24] 1341 	mov	dpl, #0x01
      004768 C0 05            [24] 1342 	push	ar5
      00476A 12 43 FE         [24] 1343 	lcall	_td_finish
      00476D D0 05            [24] 1344 	pop	ar5
      00476F                       1345 00109$:
                                   1346 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:126: if ((record->keycode >> 8) != (QK_TAP_DANCE >> 8)) return true;
      00476F 90 06 62         [24] 1347 	mov	dptr,#_ak820_tap_dance_process_record_10000_641
      004772 12 37 BB         [24] 1348 	lcall	_ak820_outline_0008
      004775 FE               [12] 1349 	mov	r6,a
      004776 A3               [24] 1350 	inc	dptr
      004777 E0               [24] 1351 	movx	a,@dptr
      004778 FB               [12] 1352 	mov	r3,a
      004779 7C 00            [12] 1353 	mov	r4,#0x00
      00477B BB 57 05         [24] 1354 	cjne	r3,#0x57,00240$
      00477E BC 00 02         [24] 1355 	cjne	r4,#0x00,00240$
      004781 80 04            [24] 1356 	sjmp	00114$
      004783                       1357 00240$:
      004783 75 82 01         [24] 1358 	mov	dpl, #0x01
      004786 22               [24] 1359 	ret
      004787                       1360 00114$:
                                   1361 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:127: index = (uint8_t)record->keycode;
                                   1362 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:128: slot = td_slots + (index & 7);
      004787 8E 04            [24] 1363 	mov	ar4,r6
      004789 53 04 07         [24] 1364 	anl	ar4,#0x07
      00478C 7F 00            [12] 1365 	mov	r7,#0x00
      00478E EC               [12] 1366 	mov	a,r4
      00478F 2C               [12] 1367 	add	a,r4
      004790 FC               [12] 1368 	mov	r4,a
      004791 EF               [12] 1369 	mov	a,r7
      004792 33               [12] 1370 	rlc	a
      004793 FF               [12] 1371 	mov	r7,a
      004794 EC               [12] 1372 	mov	a,r4
      004795 2C               [12] 1373 	add	a,r4
      004796 FC               [12] 1374 	mov	r4,a
      004797 EF               [12] 1375 	mov	a,r7
      004798 33               [12] 1376 	rlc	a
      004799 FF               [12] 1377 	mov	r7,a
      00479A EC               [12] 1378 	mov	a,r4
      00479B 24 9A            [12] 1379 	add	a, #_td_slots
      00479D FC               [12] 1380 	mov	r4,a
      00479E EF               [12] 1381 	mov	a,r7
      00479F 34 05            [12] 1382 	addc	a, #(_td_slots >> 8)
      0047A1 FF               [12] 1383 	mov	r7,a
                                   1384 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:129: if (index >= VIAL_TAP_DANCE_ENTRIES || (slot->state && slot->source != id)) goto suppress;
      0047A2 BE 08 00         [24] 1385 	cjne	r6,#0x08,00241$
      0047A5                       1386 00241$:
      0047A5 40 03            [24] 1387 	jc	00242$
      0047A7 02 48 2E         [24] 1388 	ljmp	00123$
      0047AA                       1389 00242$:
      0047AA 74 03            [12] 1390 	mov	a,#0x03
      0047AC 2C               [12] 1391 	add	a, r4
      0047AD 12 48 AB         [24] 1392 	lcall	_ak820_outline_0033
      0047B0 F9               [12] 1393 	mov	r1,a
      0047B1 60 0E            [24] 1394 	jz	00116$
      0047B3 12 48 F1         [24] 1395 	lcall	_ak820_outline_0185
      0047B6 A3               [24] 1396 	inc	dptr
      0047B7 A3               [24] 1397 	inc	dptr
      0047B8 E0               [24] 1398 	movx	a,@dptr
      0047B9 B5 05 02         [24] 1399 	cjne	a,ar5,00244$
      0047BC 80 03            [24] 1400 	sjmp	00245$
      0047BE                       1401 00244$:
      0047BE 02 48 2E         [24] 1402 	ljmp	00123$
      0047C1                       1403 00245$:
      0047C1                       1404 00116$:
                                   1405 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:130: if (!slot->state) {
      0047C1 E9               [12] 1406 	mov	a,r1
      0047C2 70 36            [24] 1407 	jnz	00122$
                                   1408 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:131: if (dynamic_keymap_get_tap_dance(index, &td_entry)) goto suppress;
      0047C4 90 0B AD         [24] 1409 	mov	dptr,#_dynamic_keymap_get_tap_dance_PARM_2
      0047C7 74 BE            [12] 1410 	mov	a,#_td_entry
      0047C9 F0               [24] 1411 	movx	@dptr,a
      0047CA 74 05            [12] 1412 	mov	a,#(_td_entry >> 8)
      0047CC 12 38 25         [24] 1413 	lcall	_ak820_outline_0075
      0047CF 8E 82            [24] 1414 	mov	dpl, r6
      0047D1 C0 07            [24] 1415 	push	ar7
      0047D3 C0 06            [24] 1416 	push	ar6
      0047D5 C0 05            [24] 1417 	push	ar5
      0047D7 C0 04            [24] 1418 	push	ar4
      0047D9 C0 03            [24] 1419 	push	ar3
      0047DB C0 02            [24] 1420 	push	ar2
      0047DD 12 89 CF         [24] 1421 	lcall	_dynamic_keymap_get_tap_dance
      0047E0 12 38 5F         [24] 1422 	lcall	_ak820_outline_0125
      0047E3 D0 02            [24] 1423 	pop	ar2
      0047E5 D0 03            [24] 1424 	pop	ar3
      0047E7 D0 04            [24] 1425 	pop	ar4
      0047E9 D0 05            [24] 1426 	pop	ar5
      0047EB D0 06            [24] 1427 	pop	ar6
      0047ED D0 07            [24] 1428 	pop	ar7
      0047EF 45 F0            [12] 1429 	orl	a,b
      0047F1 70 3B            [24] 1430 	jnz	00123$
                                   1431 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:132: slot->source = id;
      0047F3 12 48 F1         [24] 1432 	lcall	_ak820_outline_0185
      0047F6 A3               [24] 1433 	inc	dptr
      0047F7 A3               [24] 1434 	inc	dptr
      0047F8 ED               [12] 1435 	mov	a,r5
      0047F9 F0               [24] 1436 	movx	@dptr,a
      0047FA                       1437 00122$:
                                   1438 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:134: slot->state = (slot->state & 3) + 1 + TD_DOWN;
      0047FA 12 43 31         [24] 1439 	lcall	_ak820_outline_0135
      0047FD E0               [24] 1440 	movx	a,@dptr
      0047FE F9               [12] 1441 	mov	r1,a
      0047FF 74 03            [12] 1442 	mov	a,#0x03
      004801 59               [12] 1443 	anl	a,r1
      004802 24 05            [12] 1444 	add	a, #0x05
      004804 12 43 31         [24] 1445 	lcall	_ak820_outline_0135
      004807 F0               [24] 1446 	movx	@dptr,a
                                   1447 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:135: td_time = record->event.time;
      004808 90 06 62         [24] 1448 	mov	dptr,#_ak820_tap_dance_process_record_10000_641
      00480B 12 43 0E         [24] 1449 	lcall	_ak820_outline_0082
      00480E 12 43 31         [24] 1450 	lcall	_ak820_outline_0135
      004811 A3               [24] 1451 	inc	dptr
      004812 A3               [24] 1452 	inc	dptr
      004813 12 43 0E         [24] 1453 	lcall	_ak820_outline_0082
      004816 90 05 C8         [24] 1454 	mov	dptr,#_td_time
      004819 EA               [12] 1455 	mov	a,r2
      00481A 12 48 F6         [24] 1456 	lcall	_ak820_outline_0191
                                   1457 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:136: td_wait = slot;
      00481D 90 05 BA         [24] 1458 	mov	dptr,#_td_wait
      004820 EC               [12] 1459 	mov	a,r4
      004821 12 38 50         [24] 1460 	lcall	_ak820_outline_0105
                                   1461 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:137: td_map[id] = index;
      004824 ED               [12] 1462 	mov	a,r5
      004825 12 48 A1         [24] 1463 	lcall	_ak820_outline_0032
      004828 EE               [12] 1464 	mov	a,r6
      004829 F0               [24] 1465 	movx	@dptr,a
                                   1466 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:138: return false;
      00482A 75 82 00         [24] 1467 	mov	dpl, #0x00
                                   1468 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:139: suppress:
      00482D 22               [24] 1469 	ret
      00482E                       1470 00123$:
                                   1471 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:140: td_map[id] = TD_NONE;
      00482E ED               [12] 1472 	mov	a,r5
      00482F 12 48 A1         [24] 1473 	lcall	_ak820_outline_0032
      004832 74 FF            [12] 1474 	mov	a,#0xff
      004834 F0               [24] 1475 	movx	@dptr,a
                                   1476 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:141: return false;
      004835 75 82 00         [24] 1477 	mov	dpl, #0x00
                                   1478 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:142: }
      004838 22               [24] 1479 	ret
                                   1480 ;------------------------------------------------------------
                                   1481 ;Allocation info for local variables in function 'ak820_tap_dance_cancel'
                                   1482 ;------------------------------------------------------------
                                   1483 ;i             Allocated with name '_ak820_tap_dance_cancel_i_20000_652'
                                   1484 ;i             Allocated with name '_ak820_tap_dance_cancel_i_20000_653'
                                   1485 ;------------------------------------------------------------
                                   1486 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:143: void ak820_tap_dance_cancel(void) {
                                   1487 ;	-----------------------------------------
                                   1488 ;	 function ak820_tap_dance_cancel
                                   1489 ;	-----------------------------------------
      004839                       1490 _ak820_tap_dance_cancel:
                                   1491 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:144: td_wait = 0;
      004839 90 05 BA         [24] 1492 	mov	dptr,#_td_wait
      00483C 12 48 E2         [24] 1493 	lcall	_ak820_outline_0143
                                   1494 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:145: for (uint8_t i = 0; i < VIAL_TAP_DANCE_ENTRIES; ++i) td_slots[i].state = 0;
      00483F FF               [12] 1495 	mov	r7,a
      004840                       1496 00104$:
      004840 BF 08 00         [24] 1497 	cjne	r7,#0x08,00141$
      004843                       1498 00141$:
      004843 50 14            [24] 1499 	jnc	00101$
      004845 EF               [12] 1500 	mov	a,r7
      004846 12 38 8F         [24] 1501 	lcall	_ak820_outline_0189
      004849 24 9A            [12] 1502 	add	a, #_td_slots
      00484B FD               [12] 1503 	mov	r5,a
      00484C 74 05            [12] 1504 	mov	a,#(_td_slots >> 8)
      00484E 35 F0            [12] 1505 	addc	a, b
      004850 FE               [12] 1506 	mov	r6,a
      004851 12 48 BD         [24] 1507 	lcall	_ak820_outline_0040
      004854 E4               [12] 1508 	clr	a
      004855 F0               [24] 1509 	movx	@dptr,a
      004856 0F               [12] 1510 	inc	r7
      004857 80 E7            [24] 1511 	sjmp	00104$
      004859                       1512 00101$:
                                   1513 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:146: for (uint8_t i = 0; i < sizeof(td_map); ++i) td_map[i] = 0;
      004859 7F 00            [12] 1514 	mov	r7,#0x00
      00485B                       1515 00107$:
      00485B BF 80 00         [24] 1516 	cjne	r7,#0x80,00143$
      00485E                       1517 00143$:
      00485E 50 09            [24] 1518 	jnc	00109$
      004860 EF               [12] 1519 	mov	a,r7
      004861 12 48 A1         [24] 1520 	lcall	_ak820_outline_0032
      004864 E4               [12] 1521 	clr	a
      004865 F0               [24] 1522 	movx	@dptr,a
      004866 0F               [12] 1523 	inc	r7
      004867 80 F2            [24] 1524 	sjmp	00107$
      004869                       1525 00109$:
                                   1526 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:147: }
      004869 22               [24] 1527 	ret
                                   1528 	.area CSEG    (CODE)
                                   1529 	.area CONST   (CODE)
                                   1530 	.area XINIT   (CODE)
                                   1531 	.area CABS    (ABS,CODE)
                                   1532 
                                   1533 ; Experimental exact instruction outlining.
                                   1534 	.globl _ak820_outline_0001
                                   1535 	.globl _ak820_outline_0005
                                   1536 	.globl _ak820_outline_0007
                                   1537 	.globl _ak820_outline_0008
                                   1538 	.globl _ak820_outline_0012
                                   1539 	.globl _ak820_outline_0015
                                   1540 	.globl _ak820_outline_0016
                                   1541 	.globl _ak820_outline_0017
                                   1542 	.globl _ak820_outline_0031
                                   1543 	.globl _ak820_outline_0032
                                   1544 	.globl _ak820_outline_0033
                                   1545 	.globl _ak820_outline_0034
                                   1546 	.globl _ak820_outline_0037
                                   1547 	.globl _ak820_outline_0040
                                   1548 	.globl _ak820_outline_0049
                                   1549 	.globl _ak820_outline_0056
                                   1550 	.globl _ak820_outline_0063
                                   1551 	.globl _ak820_outline_0064
                                   1552 	.globl _ak820_outline_0065
                                   1553 	.globl _ak820_outline_0066
                                   1554 	.globl _ak820_outline_0075
                                   1555 	.globl _ak820_outline_0077
                                   1556 	.globl _ak820_outline_0079
                                   1557 	.globl _ak820_outline_0081
                                   1558 	.globl _ak820_outline_0082
                                   1559 	.globl _ak820_outline_0088
                                   1560 	.globl _ak820_outline_0103
                                   1561 	.globl _ak820_outline_0105
                                   1562 	.globl _ak820_outline_0106
                                   1563 	.globl _ak820_outline_0119
                                   1564 	.globl _ak820_outline_0121
                                   1565 	.globl _ak820_outline_0124
                                   1566 	.globl _ak820_outline_0125
                                   1567 	.globl _ak820_outline_0127
                                   1568 	.globl _ak820_outline_0135
                                   1569 	.globl _ak820_outline_0143
                                   1570 	.globl _ak820_outline_0146
                                   1571 	.globl _ak820_outline_0149
                                   1572 	.globl _ak820_outline_0150
                                   1573 	.globl _ak820_outline_0161
                                   1574 	.globl _ak820_outline_0185
                                   1575 	.globl _ak820_outline_0189
                                   1576 	.globl _ak820_outline_0191
                                   1577 
                                   1578 	.area CSEG (CODE)
                                   1579 ; function ak820_outline_0007
      00486A                       1580 _ak820_outline_0007:
      00486A 90 05 BC         [24] 1581 	mov	dptr,#_td_work
      00486D E0               [24] 1582 	movx	a,@dptr
      00486E FE               [12] 1583 	mov	r6,a
      00486F A3               [24] 1584 	inc	dptr
      004870 E0               [24] 1585 	movx	a,@dptr
      004871 FF               [12] 1586 	mov	r7,a
      004872 74 03            [12] 1587 	mov	a,#0x03
      004874 2E               [12] 1588 	add	a,r6
      004875 FE               [12] 1589 	mov	r6,a
      004876 E4               [12] 1590 	clr	a
      004877 3F               [12] 1591 	addc	a,r7
      004878 FF               [12] 1592 	mov	r7,a
      004879 8E 82            [24] 1593 	mov	dpl,r6
      00487B 8F 83            [24] 1594 	mov	dph,r7
      00487D E0               [24] 1595 	movx	a,@dptr
      00487E 22               [24] 1596 	ret
                                   1597 
                                   1598 	.area CSEG (CODE)
                                   1599 ; function ak820_outline_0012
      00487F                       1600 _ak820_outline_0012:
      00487F 2E               [12] 1601 	add	a,r6
      004880 FC               [12] 1602 	mov	r4,a
      004881 E4               [12] 1603 	clr	a
      004882 3F               [12] 1604 	addc	a,r7
      004883 FD               [12] 1605 	mov	r5,a
      004884 8C 82            [24] 1606 	mov	dpl,r4
      004886 8D 83            [24] 1607 	mov	dph,r5
      004888 E0               [24] 1608 	movx	a,@dptr
      004889 22               [24] 1609 	ret
                                   1610 
                                   1611 	.area CSEG (CODE)
                                   1612 ; function ak820_outline_0015
      00488A                       1613 _ak820_outline_0015:
      00488A 8E 82            [24] 1614 	mov	dpl,r6
      00488C 8F 83            [24] 1615 	mov	dph,r7
      00488E A3               [24] 1616 	inc	dptr
      00488F A3               [24] 1617 	inc	dptr
      004890 A3               [24] 1618 	inc	dptr
      004891 E0               [24] 1619 	movx	a,@dptr
      004892 22               [24] 1620 	ret
                                   1621 
                                   1622 	.area CSEG (CODE)
                                   1623 ; function ak820_outline_0031
      004893                       1624 _ak820_outline_0031:
      004893 E0               [24] 1625 	movx	a,@dptr
      004894 FE               [12] 1626 	mov	r6,a
      004895 A3               [24] 1627 	inc	dptr
      004896 E0               [24] 1628 	movx	a,@dptr
      004897 FF               [12] 1629 	mov	r7,a
      004898 90 06 51         [24] 1630 	mov	dptr,#(_td_record+0x0007)
      00489B EE               [12] 1631 	mov	a,r6
      00489C F0               [24] 1632 	movx	@dptr,a
      00489D EF               [12] 1633 	mov	a,r7
      00489E A3               [24] 1634 	inc	dptr
      00489F F0               [24] 1635 	movx	@dptr,a
      0048A0 22               [24] 1636 	ret
                                   1637 
                                   1638 	.area CSEG (CODE)
                                   1639 ; function ak820_outline_0032
      0048A1                       1640 _ak820_outline_0032:
      0048A1 24 CA            [12] 1641 	add	a,#_td_map
      0048A3 F5 82            [12] 1642 	mov	dpl,a
      0048A5 E4               [12] 1643 	clr	a
      0048A6 34 05            [12] 1644 	addc	a,#(_td_map>>8)
      0048A8 F5 83            [12] 1645 	mov	dph,a
      0048AA 22               [24] 1646 	ret
                                   1647 
                                   1648 	.area CSEG (CODE)
                                   1649 ; function ak820_outline_0033
      0048AB                       1650 _ak820_outline_0033:
      0048AB FA               [12] 1651 	mov	r2,a
      0048AC E4               [12] 1652 	clr	a
      0048AD 3F               [12] 1653 	addc	a,r7
      0048AE FB               [12] 1654 	mov	r3,a
      0048AF 8A 82            [24] 1655 	mov	dpl,r2
      0048B1 8B 83            [24] 1656 	mov	dph,r3
      0048B3 E0               [24] 1657 	movx	a,@dptr
      0048B4 22               [24] 1658 	ret
                                   1659 
                                   1660 	.area CSEG (CODE)
                                   1661 ; function ak820_outline_0037
      0048B5                       1662 _ak820_outline_0037:
      0048B5 E0               [24] 1663 	movx	a,@dptr
      0048B6 F5 F0            [12] 1664 	mov	b,a
      0048B8 A3               [24] 1665 	inc	dptr
      0048B9 E0               [24] 1666 	movx	a,@dptr
      0048BA 45 F0            [12] 1667 	orl	a,b
      0048BC 22               [24] 1668 	ret
                                   1669 
                                   1670 	.area CSEG (CODE)
                                   1671 ; function ak820_outline_0040
      0048BD                       1672 _ak820_outline_0040:
      0048BD 8D 82            [24] 1673 	mov	dpl,r5
      0048BF 8E 83            [24] 1674 	mov	dph,r6
      0048C1 A3               [24] 1675 	inc	dptr
      0048C2 A3               [24] 1676 	inc	dptr
      0048C3 A3               [24] 1677 	inc	dptr
      0048C4 22               [24] 1678 	ret
                                   1679 
                                   1680 	.area CSEG (CODE)
                                   1681 ; function ak820_outline_0049
      0048C5                       1682 _ak820_outline_0049:
      0048C5 FC               [12] 1683 	mov	r4,a
      0048C6 8B 82            [24] 1684 	mov	dpl,r3
      0048C8 8C 83            [24] 1685 	mov	dph,r4
      0048CA E0               [24] 1686 	movx	a,@dptr
      0048CB FA               [12] 1687 	mov	r2,a
      0048CC 22               [24] 1688 	ret
                                   1689 
                                   1690 	.area CSEG (CODE)
                                   1691 ; function ak820_outline_0063
      0048CD                       1692 _ak820_outline_0063:
      0048CD 89 82            [24] 1693 	mov	dpl,r1
      0048CF 8A 83            [24] 1694 	mov	dph,r2
      0048D1 E8               [12] 1695 	mov	a,r0
      0048D2 F0               [24] 1696 	movx	@dptr,a
      0048D3 22               [24] 1697 	ret
                                   1698 
                                   1699 	.area CSEG (CODE)
                                   1700 ; function ak820_outline_0064
      0048D4                       1701 _ak820_outline_0064:
      0048D4 EE               [12] 1702 	mov	a,r6
      0048D5 F0               [24] 1703 	movx	@dptr,a
      0048D6 EF               [12] 1704 	mov	a,r7
      0048D7 A3               [24] 1705 	inc	dptr
      0048D8 F0               [24] 1706 	movx	@dptr,a
      0048D9 22               [24] 1707 	ret
                                   1708 
                                   1709 	.area CSEG (CODE)
                                   1710 ; function ak820_outline_0121
      0048DA                       1711 _ak820_outline_0121:
      0048DA 74 02            [12] 1712 	mov	a,#0x02
      0048DC 2E               [12] 1713 	add	a,r6
      0048DD FE               [12] 1714 	mov	r6,a
      0048DE E4               [12] 1715 	clr	a
      0048DF 3F               [12] 1716 	addc	a,r7
      0048E0 FF               [12] 1717 	mov	r7,a
      0048E1 22               [24] 1718 	ret
                                   1719 
                                   1720 	.area CSEG (CODE)
                                   1721 ; function ak820_outline_0143
      0048E2                       1722 _ak820_outline_0143:
      0048E2 E4               [12] 1723 	clr	a
      0048E3 F0               [24] 1724 	movx	@dptr,a
      0048E4 A3               [24] 1725 	inc	dptr
      0048E5 F0               [24] 1726 	movx	@dptr,a
      0048E6 22               [24] 1727 	ret
                                   1728 
                                   1729 	.area CSEG (CODE)
                                   1730 ; function ak820_outline_0146
      0048E7                       1731 _ak820_outline_0146:
      0048E7 F0               [24] 1732 	movx	@dptr,a
      0048E8 90 06 51         [24] 1733 	mov	dptr,#(_td_record+0x0007)
      0048EB E0               [24] 1734 	movx	a,@dptr
      0048EC FE               [12] 1735 	mov	r6,a
      0048ED A3               [24] 1736 	inc	dptr
      0048EE E0               [24] 1737 	movx	a,@dptr
      0048EF 4E               [12] 1738 	orl	a,r6
      0048F0 22               [24] 1739 	ret
                                   1740 
                                   1741 	.area CSEG (CODE)
                                   1742 ; function ak820_outline_0185
      0048F1                       1743 _ak820_outline_0185:
      0048F1 8C 82            [24] 1744 	mov	dpl,r4
      0048F3 8F 83            [24] 1745 	mov	dph,r7
      0048F5 22               [24] 1746 	ret
                                   1747 
                                   1748 	.area CSEG (CODE)
                                   1749 ; function ak820_outline_0191
      0048F6                       1750 _ak820_outline_0191:
      0048F6 F0               [24] 1751 	movx	@dptr,a
      0048F7 EB               [12] 1752 	mov	a,r3
      0048F8 A3               [24] 1753 	inc	dptr
      0048F9 F0               [24] 1754 	movx	@dptr,a
      0048FA 22               [24] 1755 	ret
