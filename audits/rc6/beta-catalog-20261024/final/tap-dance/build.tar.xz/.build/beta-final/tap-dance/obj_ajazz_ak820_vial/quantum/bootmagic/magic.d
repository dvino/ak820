magic.o: quantum/bootmagic/magic.c keyboards/ajazz/ak820/config.h \
 .build/beta-final/tap-dance/obj_ajazz_ak820_vial/src/info_config.h \
 keyboards/ajazz/ak820/keymaps/vial/config.h \
 quantum/rgb_matrix/post_config.h \
 /workspace/scratch/1875e97a7527/source/ak820/toolchains/sdcc-4.6.0/share/sdcc/include/stdint.h \
 /workspace/scratch/1875e97a7527/source/ak820/toolchains/sdcc-4.6.0/share/sdcc/include/stdbool.h \
 platforms/wait.h \
 /workspace/scratch/1875e97a7527/source/ak820/toolchains/sdcc-4.6.0/share/sdcc/include/inttypes.h \
 platforms/mcs51/_wait.h lib/ch555/hal.h \
 /workspace/scratch/1875e97a7527/source/ak820/toolchains/sdcc-4.6.0/share/sdcc/include/stdio.h \
 /workspace/scratch/1875e97a7527/source/ak820/toolchains/sdcc-4.6.0/share/sdcc/include/stdarg.h \
 /workspace/scratch/1875e97a7527/source/ak820/toolchains/sdcc-4.6.0/share/sdcc/include/sdcc-lib.h \
 /workspace/scratch/1875e97a7527/source/ak820/toolchains/sdcc-4.6.0/share/sdcc/include/asm/mcs51/features.h \
 /workspace/scratch/1875e97a7527/source/ak820/toolchains/sdcc-4.6.0/share/sdcc/include/string.h \
 lib/ch555/ch555.h quantum/matrix.h platforms/sdcc_dummy_macros.h \
 tmk_core/protocol/ch555/usb_device.h lib/ch555/ch555.h \
 tmk_core/protocol/ch555/usb.h tmk_core/protocol/usb_descriptor.h \
 tmk_core/protocol/ch555/lufa_utils/LUFA/Drivers/USB/USB.h \
 platforms/progmem.h \
 /workspace/scratch/1875e97a7527/source/ak820/toolchains/sdcc-4.6.0/share/sdcc/include/stddef.h \
 lib/lufa/LUFA/Common/Architectures.h \
 lib/lufa/LUFA/Drivers/USB/Class/Common/HIDClassCommon.h \
 lib/lufa/LUFA/Drivers/USB/Class/Common/../../Core/StdDescriptors.h \
 lib/lufa/LUFA/Drivers/USB/Class/Common/../../Core/../../../Common/Common.h \
 lib/lufa/LUFA/Drivers/USB/Class/Common/../../Core/USBMode.h \
 lib/lufa/LUFA/Drivers/USB/Class/Common/../../Core/Events.h \
 lib/lufa/LUFA/Drivers/USB/Class/Common/HIDParser.h \
 lib/lufa/LUFA/Drivers/USB/Class/Common/HIDReportData.h \
 lib/lufa/LUFA/Drivers/USB/Class/Common/CDCClassCommon.h \
 lib/lufa/LUFA/Drivers/USB/Class/Common/AudioClassCommon.h \
 lib/lufa/LUFA/Drivers/USB/Class/Common/MIDIClassCommon.h \
 lib/lufa/LUFA/Drivers/USB/Class/Common/AudioClassCommon.h \
 lib/lufa/LUFA/Drivers/USB/Core/USBController.h \
 lib/lufa/LUFA/Drivers/USB/Core/../../../Common/Common.h \
 lib/lufa/LUFA/Drivers/USB/Core/USBMode.h platforms/gpio.h \
 platforms/pin_defs.h platforms/mcs51/_pin_defs.h platforms/mcs51/gpio.h \
 platforms/bootloader.h quantum/logging/debug.h quantum/logging/print.h \
 quantum/util.h quantum/bitwise.h quantum/logging/sendchar.h \
 quantum/keycode_config.h quantum/eeconfig.h quantum/keycode.h \
 quantum/keycodes.h quantum/modifiers.h quantum/action_code.h \
 tmk_core/protocol/host.h tmk_core/protocol/report.h \
 tmk_core/protocol/host_driver.h quantum/led.h quantum/action_layer.h \
 quantum/keyboard.h platforms/timer.h platforms/mcs51/_timer.h \
 platforms/mcs51/atomic_util.h quantum/action.h \
 quantum/bootmagic/bootmagic.h quantum/bootmagic/bootmagic_lite.h
