                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_tapping
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_settings_tapping_term
                                     12 	.globl _get_repeat_key_count
                                     13 	.globl _del_owned_mods
                                     14 	.globl _add_owned_mods
                                     15 	.globl _send_keyboard_report
                                     16 	.globl _layer_hold_off
                                     17 	.globl _layer_hold_on
                                     18 	.globl _unregister_mods
                                     19 	.globl _register_mods
                                     20 	.globl _process_record
                                     21 	.globl _ADC_START
                                     22 	.globl _S0_R_FIFO
                                     23 	.globl _S0_T_FIFO
                                     24 	.globl _S0_FREE
                                     25 	.globl _S0_IF_BYTE
                                     26 	.globl _S0_IF_FIRST
                                     27 	.globl _S0_IF_OV
                                     28 	.globl _S0_FST_ACT
                                     29 	.globl _CP_RL2
                                     30 	.globl _C_T2
                                     31 	.globl _TR2
                                     32 	.globl _EXEN2
                                     33 	.globl _TCLK
                                     34 	.globl _RCLK
                                     35 	.globl _EXF2
                                     36 	.globl _CAP1F
                                     37 	.globl _TF2
                                     38 	.globl _RI
                                     39 	.globl _TI
                                     40 	.globl _RB8
                                     41 	.globl _TB8
                                     42 	.globl _REN
                                     43 	.globl _SM2
                                     44 	.globl _SM1
                                     45 	.globl _SM0
                                     46 	.globl _IT0
                                     47 	.globl _IE0
                                     48 	.globl _IT1
                                     49 	.globl _IE1
                                     50 	.globl _TR0
                                     51 	.globl _TF0
                                     52 	.globl _TR1
                                     53 	.globl _TF1
                                     54 	.globl _P4_0
                                     55 	.globl _P4_1
                                     56 	.globl _P4_2
                                     57 	.globl _P4_3
                                     58 	.globl _P4_4
                                     59 	.globl _P4_5
                                     60 	.globl _P4_6
                                     61 	.globl _RXD
                                     62 	.globl _TXD
                                     63 	.globl _INT0
                                     64 	.globl _INT1
                                     65 	.globl _T0
                                     66 	.globl _T1
                                     67 	.globl _MOSI1
                                     68 	.globl _MISO1
                                     69 	.globl _SCK1
                                     70 	.globl _P3_0
                                     71 	.globl _P3_1
                                     72 	.globl _P3_2
                                     73 	.globl _P3_3
                                     74 	.globl _P3_4
                                     75 	.globl _P3_5
                                     76 	.globl _P3_6
                                     77 	.globl _P3_7
                                     78 	.globl _CAP1_
                                     79 	.globl _T2_
                                     80 	.globl _CAP2_
                                     81 	.globl _T2EX_
                                     82 	.globl _RXD1
                                     83 	.globl _TXD1
                                     84 	.globl _P2_0
                                     85 	.globl _P2_1
                                     86 	.globl _P2_2
                                     87 	.globl _P2_3
                                     88 	.globl _P2_4
                                     89 	.globl _P2_5
                                     90 	.globl _P2_6
                                     91 	.globl _P2_7
                                     92 	.globl _AIN0
                                     93 	.globl _AIN1
                                     94 	.globl _AIN2
                                     95 	.globl _AIN3
                                     96 	.globl _AIN4
                                     97 	.globl _AIN5
                                     98 	.globl _AIN6
                                     99 	.globl _AIN7
                                    100 	.globl _CAP1
                                    101 	.globl _T2
                                    102 	.globl _CAP2
                                    103 	.globl _T2EX
                                    104 	.globl _INT0_
                                    105 	.globl _SCS
                                    106 	.globl _MOSI
                                    107 	.globl _MISO
                                    108 	.globl _SCK
                                    109 	.globl _RXD1_
                                    110 	.globl _TXD1_
                                    111 	.globl _P1_0
                                    112 	.globl _P1_1
                                    113 	.globl _P1_2
                                    114 	.globl _P1_3
                                    115 	.globl _P1_4
                                    116 	.globl _P1_5
                                    117 	.globl _P1_6
                                    118 	.globl _P1_7
                                    119 	.globl _AIN8
                                    120 	.globl _AIN9
                                    121 	.globl _AIN10
                                    122 	.globl _AIN11
                                    123 	.globl _AIN12
                                    124 	.globl _AIN13
                                    125 	.globl _RXD_
                                    126 	.globl _TXD_
                                    127 	.globl _SCL0
                                    128 	.globl _SDA0
                                    129 	.globl _P0_0
                                    130 	.globl _P0_1
                                    131 	.globl _P0_2
                                    132 	.globl _P0_3
                                    133 	.globl _P0_4
                                    134 	.globl _P0_5
                                    135 	.globl _P0_6
                                    136 	.globl _P0_7
                                    137 	.globl _IE_SPI0
                                    138 	.globl _IE_USB
                                    139 	.globl _IE_ADC
                                    140 	.globl _IE_UART1
                                    141 	.globl _IE_PWM_I2C
                                    142 	.globl _IE_GPIO
                                    143 	.globl _IE_WDOG
                                    144 	.globl _PX0
                                    145 	.globl _PT0
                                    146 	.globl _PX1
                                    147 	.globl _PT1
                                    148 	.globl _PS
                                    149 	.globl _PT2
                                    150 	.globl _PL_FLAG
                                    151 	.globl _PH_FLAG
                                    152 	.globl _EX0
                                    153 	.globl _ET0
                                    154 	.globl _EX1
                                    155 	.globl _ET1
                                    156 	.globl _ES
                                    157 	.globl _ET2
                                    158 	.globl _E_DIS
                                    159 	.globl _EA
                                    160 	.globl _P
                                    161 	.globl _F1
                                    162 	.globl _OV
                                    163 	.globl _RS0
                                    164 	.globl _RS1
                                    165 	.globl _F0
                                    166 	.globl _AC
                                    167 	.globl _CY
                                    168 	.globl _I2CS_INT_ST
                                    169 	.globl _I2CX_INT
                                    170 	.globl _LED_STATUS
                                    171 	.globl _LED_DMA_H
                                    172 	.globl _LED_DMA_L
                                    173 	.globl _LED_DMA
                                    174 	.globl _LED_PWM_OE
                                    175 	.globl _LED_COMMON
                                    176 	.globl _ADC_CHAN
                                    177 	.globl _ADC_DAT_H
                                    178 	.globl _ADC_DAT_L
                                    179 	.globl _ADC_DAT
                                    180 	.globl _ADC_CTRL
                                    181 	.globl _SPI1_CK_SE
                                    182 	.globl _SPI1_CTRL
                                    183 	.globl _SPI1_DATA
                                    184 	.globl _SPI1_STAT
                                    185 	.globl _SIF1
                                    186 	.globl _SBAUD1
                                    187 	.globl _SBUF1
                                    188 	.globl _SCON1
                                    189 	.globl _SPI0_SETUP
                                    190 	.globl _SPI0_CK_SE
                                    191 	.globl _SPI0_CTRL
                                    192 	.globl _SPI0_DATA
                                    193 	.globl _SPI0_STAT
                                    194 	.globl _T2CAP1H
                                    195 	.globl _T2CAP1L
                                    196 	.globl _T2CAP1
                                    197 	.globl _TH2
                                    198 	.globl _TL2
                                    199 	.globl _T2COUNT
                                    200 	.globl _RCAP2H
                                    201 	.globl _RCAP2L
                                    202 	.globl _RCAP2
                                    203 	.globl _T2MOD
                                    204 	.globl _T2CON
                                    205 	.globl _SBUF
                                    206 	.globl _SCON
                                    207 	.globl _TH1
                                    208 	.globl _TH0
                                    209 	.globl _TL1
                                    210 	.globl _TL0
                                    211 	.globl _TMOD
                                    212 	.globl _TCON
                                    213 	.globl _XBUS_AUX
                                    214 	.globl _P7
                                    215 	.globl _P6_DIR
                                    216 	.globl _P6_OUT_PU
                                    217 	.globl _P6_IN
                                    218 	.globl _P5_DIR
                                    219 	.globl _P5_OUT_PU
                                    220 	.globl _P5_IN
                                    221 	.globl _P4_LED_KEY
                                    222 	.globl _P4_DIR_PU
                                    223 	.globl _P4_MOD_OC
                                    224 	.globl _P4
                                    225 	.globl _P3_DIR_PU
                                    226 	.globl _P3_MOD_OC
                                    227 	.globl _P3
                                    228 	.globl _P2_DIR_PU
                                    229 	.globl _P2_MOD_OC
                                    230 	.globl _P2
                                    231 	.globl _P1_DIR_PU
                                    232 	.globl _P1_MOD_OC
                                    233 	.globl _P1
                                    234 	.globl _P0_DIR_PU
                                    235 	.globl _P0_MOD_OC
                                    236 	.globl _P0
                                    237 	.globl _ROM_CTRL
                                    238 	.globl _ROM_DATA_HH
                                    239 	.globl _ROM_DATA_HL
                                    240 	.globl _ROM_DATA_HI
                                    241 	.globl _ROM_ADDR_H
                                    242 	.globl _ROM_ADDR_L
                                    243 	.globl _ROM_ADDR
                                    244 	.globl _GPIO_IE
                                    245 	.globl _IP_EX
                                    246 	.globl _IE_EX
                                    247 	.globl _IP
                                    248 	.globl _IE
                                    249 	.globl _WDOG_COUNT
                                    250 	.globl _RESET_KEEP
                                    251 	.globl _WAKE_CTRL
                                    252 	.globl _CLOCK_CFG
                                    253 	.globl _POWER_CFG
                                    254 	.globl _PCON
                                    255 	.globl _GLOBAL_CFG
                                    256 	.globl _SAFE_MOD
                                    257 	.globl _DPH
                                    258 	.globl _DPL
                                    259 	.globl _SP
                                    260 	.globl _A_INV
                                    261 	.globl _B
                                    262 	.globl _ACC
                                    263 	.globl _PSW
                                    264 	.globl _ak820_oneshot_target
                                    265 	.globl _ak820_oneshot_process_PARM_3
                                    266 	.globl _ak820_oneshot_process_PARM_2
                                    267 	.globl _ak820_oneshot_consumed
                                    268 	.globl _ak820_oneshot_mods
                                    269 	.globl _ak820_tapping_source_PARM_1
                                    270 	.globl _ak820_tapping_source
                                    271 	.globl _ak820_tapping_before
                                    272 	.globl _ak820_tapping_process
                                    273 	.globl _ak820_tapping_cancel
                                    274 	.globl _ak820_oneshot_process
                                    275 ;--------------------------------------------------------
                                    276 ; special function registers
                                    277 ;--------------------------------------------------------
                                    278 	.area RSEG    (ABS,DATA)
      000000                        279 	.org 0x0000
                           0000D0   280 _PSW	=	0x00d0
                           0000E0   281 _ACC	=	0x00e0
                           0000F0   282 _B	=	0x00f0
                           0000FD   283 _A_INV	=	0x00fd
                           000081   284 _SP	=	0x0081
                           000082   285 _DPL	=	0x0082
                           000083   286 _DPH	=	0x0083
                           0000A1   287 _SAFE_MOD	=	0x00a1
                           0000B1   288 _GLOBAL_CFG	=	0x00b1
                           000087   289 _PCON	=	0x0087
                           0000BA   290 _POWER_CFG	=	0x00ba
                           0000B9   291 _CLOCK_CFG	=	0x00b9
                           0000A9   292 _WAKE_CTRL	=	0x00a9
                           0000FE   293 _RESET_KEEP	=	0x00fe
                           0000FF   294 _WDOG_COUNT	=	0x00ff
                           0000A8   295 _IE	=	0x00a8
                           0000B8   296 _IP	=	0x00b8
                           0000E8   297 _IE_EX	=	0x00e8
                           0000E9   298 _IP_EX	=	0x00e9
                           0000B2   299 _GPIO_IE	=	0x00b2
                           008584   300 _ROM_ADDR	=	0x8584
                           000084   301 _ROM_ADDR_L	=	0x0084
                           000085   302 _ROM_ADDR_H	=	0x0085
                           008F8E   303 _ROM_DATA_HI	=	0x8f8e
                           00008E   304 _ROM_DATA_HL	=	0x008e
                           00008F   305 _ROM_DATA_HH	=	0x008f
                           000086   306 _ROM_CTRL	=	0x0086
                           000080   307 _P0	=	0x0080
                           0000C4   308 _P0_MOD_OC	=	0x00c4
                           0000C5   309 _P0_DIR_PU	=	0x00c5
                           000090   310 _P1	=	0x0090
                           000092   311 _P1_MOD_OC	=	0x0092
                           000093   312 _P1_DIR_PU	=	0x0093
                           0000A0   313 _P2	=	0x00a0
                           000094   314 _P2_MOD_OC	=	0x0094
                           000095   315 _P2_DIR_PU	=	0x0095
                           0000B0   316 _P3	=	0x00b0
                           000096   317 _P3_MOD_OC	=	0x0096
                           000097   318 _P3_DIR_PU	=	0x0097
                           0000C0   319 _P4	=	0x00c0
                           0000C2   320 _P4_MOD_OC	=	0x00c2
                           0000C3   321 _P4_DIR_PU	=	0x00c3
                           0000C1   322 _P4_LED_KEY	=	0x00c1
                           0000AA   323 _P5_IN	=	0x00aa
                           0000AB   324 _P5_OUT_PU	=	0x00ab
                           0000AC   325 _P5_DIR	=	0x00ac
                           0000AD   326 _P6_IN	=	0x00ad
                           0000AE   327 _P6_OUT_PU	=	0x00ae
                           0000AF   328 _P6_DIR	=	0x00af
                           0000F1   329 _P7	=	0x00f1
                           0000A2   330 _XBUS_AUX	=	0x00a2
                           000088   331 _TCON	=	0x0088
                           000089   332 _TMOD	=	0x0089
                           00008A   333 _TL0	=	0x008a
                           00008B   334 _TL1	=	0x008b
                           00008C   335 _TH0	=	0x008c
                           00008D   336 _TH1	=	0x008d
                           000098   337 _SCON	=	0x0098
                           000099   338 _SBUF	=	0x0099
                           0000C8   339 _T2CON	=	0x00c8
                           0000C9   340 _T2MOD	=	0x00c9
                           00CBCA   341 _RCAP2	=	0xcbca
                           0000CA   342 _RCAP2L	=	0x00ca
                           0000CB   343 _RCAP2H	=	0x00cb
                           00CDCC   344 _T2COUNT	=	0xcdcc
                           0000CC   345 _TL2	=	0x00cc
                           0000CD   346 _TH2	=	0x00cd
                           00CFCE   347 _T2CAP1	=	0xcfce
                           0000CE   348 _T2CAP1L	=	0x00ce
                           0000CF   349 _T2CAP1H	=	0x00cf
                           0000F8   350 _SPI0_STAT	=	0x00f8
                           0000F9   351 _SPI0_DATA	=	0x00f9
                           0000FA   352 _SPI0_CTRL	=	0x00fa
                           0000FB   353 _SPI0_CK_SE	=	0x00fb
                           0000FC   354 _SPI0_SETUP	=	0x00fc
                           0000BC   355 _SCON1	=	0x00bc
                           0000BD   356 _SBUF1	=	0x00bd
                           0000BE   357 _SBAUD1	=	0x00be
                           0000BF   358 _SIF1	=	0x00bf
                           0000B4   359 _SPI1_STAT	=	0x00b4
                           0000B5   360 _SPI1_DATA	=	0x00b5
                           0000B6   361 _SPI1_CTRL	=	0x00b6
                           0000B7   362 _SPI1_CK_SE	=	0x00b7
                           0000F3   363 _ADC_CTRL	=	0x00f3
                           00F5F4   364 _ADC_DAT	=	0xf5f4
                           0000F4   365 _ADC_DAT_L	=	0x00f4
                           0000F5   366 _ADC_DAT_H	=	0x00f5
                           0000F6   367 _ADC_CHAN	=	0x00f6
                           0000A6   368 _LED_COMMON	=	0x00a6
                           0000A7   369 _LED_PWM_OE	=	0x00a7
                           00C7C6   370 _LED_DMA	=	0xc7c6
                           0000C6   371 _LED_DMA_L	=	0x00c6
                           0000C7   372 _LED_DMA_H	=	0x00c7
                           0000F7   373 _LED_STATUS	=	0x00f7
                           0000B3   374 _I2CX_INT	=	0x00b3
                           0000BB   375 _I2CS_INT_ST	=	0x00bb
                                    376 ;--------------------------------------------------------
                                    377 ; special function bits
                                    378 ;--------------------------------------------------------
                                    379 	.area RSEG    (ABS,DATA)
      000000                        380 	.org 0x0000
                           0000D7   381 _CY	=	0x00d7
                           0000D6   382 _AC	=	0x00d6
                           0000D5   383 _F0	=	0x00d5
                           0000D4   384 _RS1	=	0x00d4
                           0000D3   385 _RS0	=	0x00d3
                           0000D2   386 _OV	=	0x00d2
                           0000D1   387 _F1	=	0x00d1
                           0000D0   388 _P	=	0x00d0
                           0000AF   389 _EA	=	0x00af
                           0000AE   390 _E_DIS	=	0x00ae
                           0000AD   391 _ET2	=	0x00ad
                           0000AC   392 _ES	=	0x00ac
                           0000AB   393 _ET1	=	0x00ab
                           0000AA   394 _EX1	=	0x00aa
                           0000A9   395 _ET0	=	0x00a9
                           0000A8   396 _EX0	=	0x00a8
                           0000BF   397 _PH_FLAG	=	0x00bf
                           0000BE   398 _PL_FLAG	=	0x00be
                           0000BD   399 _PT2	=	0x00bd
                           0000BC   400 _PS	=	0x00bc
                           0000BB   401 _PT1	=	0x00bb
                           0000BA   402 _PX1	=	0x00ba
                           0000B9   403 _PT0	=	0x00b9
                           0000B8   404 _PX0	=	0x00b8
                           0000EF   405 _IE_WDOG	=	0x00ef
                           0000EE   406 _IE_GPIO	=	0x00ee
                           0000ED   407 _IE_PWM_I2C	=	0x00ed
                           0000EC   408 _IE_UART1	=	0x00ec
                           0000EB   409 _IE_ADC	=	0x00eb
                           0000E9   410 _IE_USB	=	0x00e9
                           0000E8   411 _IE_SPI0	=	0x00e8
                           000087   412 _P0_7	=	0x0087
                           000086   413 _P0_6	=	0x0086
                           000085   414 _P0_5	=	0x0085
                           000084   415 _P0_4	=	0x0084
                           000083   416 _P0_3	=	0x0083
                           000082   417 _P0_2	=	0x0082
                           000081   418 _P0_1	=	0x0081
                           000080   419 _P0_0	=	0x0080
                           000081   420 _SDA0	=	0x0081
                           000080   421 _SCL0	=	0x0080
                           000083   422 _TXD_	=	0x0083
                           000082   423 _RXD_	=	0x0082
                           000085   424 _AIN13	=	0x0085
                           000084   425 _AIN12	=	0x0084
                           000083   426 _AIN11	=	0x0083
                           000082   427 _AIN10	=	0x0082
                           000081   428 _AIN9	=	0x0081
                           000080   429 _AIN8	=	0x0080
                           000097   430 _P1_7	=	0x0097
                           000096   431 _P1_6	=	0x0096
                           000095   432 _P1_5	=	0x0095
                           000094   433 _P1_4	=	0x0094
                           000093   434 _P1_3	=	0x0093
                           000092   435 _P1_2	=	0x0092
                           000091   436 _P1_1	=	0x0091
                           000090   437 _P1_0	=	0x0090
                           000097   438 _TXD1_	=	0x0097
                           000096   439 _RXD1_	=	0x0096
                           000097   440 _SCK	=	0x0097
                           000096   441 _MISO	=	0x0096
                           000095   442 _MOSI	=	0x0095
                           000094   443 _SCS	=	0x0094
                           000092   444 _INT0_	=	0x0092
                           000091   445 _T2EX	=	0x0091
                           000091   446 _CAP2	=	0x0091
                           000090   447 _T2	=	0x0090
                           000090   448 _CAP1	=	0x0090
                           000097   449 _AIN7	=	0x0097
                           000096   450 _AIN6	=	0x0096
                           000095   451 _AIN5	=	0x0095
                           000094   452 _AIN4	=	0x0094
                           000093   453 _AIN3	=	0x0093
                           000092   454 _AIN2	=	0x0092
                           000091   455 _AIN1	=	0x0091
                           000090   456 _AIN0	=	0x0090
                           0000A7   457 _P2_7	=	0x00a7
                           0000A6   458 _P2_6	=	0x00a6
                           0000A5   459 _P2_5	=	0x00a5
                           0000A4   460 _P2_4	=	0x00a4
                           0000A3   461 _P2_3	=	0x00a3
                           0000A2   462 _P2_2	=	0x00a2
                           0000A1   463 _P2_1	=	0x00a1
                           0000A0   464 _P2_0	=	0x00a0
                           0000A7   465 _TXD1	=	0x00a7
                           0000A6   466 _RXD1	=	0x00a6
                           0000A5   467 _T2EX_	=	0x00a5
                           0000A5   468 _CAP2_	=	0x00a5
                           0000A4   469 _T2_	=	0x00a4
                           0000A4   470 _CAP1_	=	0x00a4
                           0000B7   471 _P3_7	=	0x00b7
                           0000B6   472 _P3_6	=	0x00b6
                           0000B5   473 _P3_5	=	0x00b5
                           0000B4   474 _P3_4	=	0x00b4
                           0000B3   475 _P3_3	=	0x00b3
                           0000B2   476 _P3_2	=	0x00b2
                           0000B1   477 _P3_1	=	0x00b1
                           0000B0   478 _P3_0	=	0x00b0
                           0000B7   479 _SCK1	=	0x00b7
                           0000B6   480 _MISO1	=	0x00b6
                           0000B5   481 _MOSI1	=	0x00b5
                           0000B5   482 _T1	=	0x00b5
                           0000B4   483 _T0	=	0x00b4
                           0000B3   484 _INT1	=	0x00b3
                           0000B2   485 _INT0	=	0x00b2
                           0000B1   486 _TXD	=	0x00b1
                           0000B0   487 _RXD	=	0x00b0
                           0000C6   488 _P4_6	=	0x00c6
                           0000C5   489 _P4_5	=	0x00c5
                           0000C4   490 _P4_4	=	0x00c4
                           0000C3   491 _P4_3	=	0x00c3
                           0000C2   492 _P4_2	=	0x00c2
                           0000C1   493 _P4_1	=	0x00c1
                           0000C0   494 _P4_0	=	0x00c0
                           00008F   495 _TF1	=	0x008f
                           00008E   496 _TR1	=	0x008e
                           00008D   497 _TF0	=	0x008d
                           00008C   498 _TR0	=	0x008c
                           00008B   499 _IE1	=	0x008b
                           00008A   500 _IT1	=	0x008a
                           000089   501 _IE0	=	0x0089
                           000088   502 _IT0	=	0x0088
                           00009F   503 _SM0	=	0x009f
                           00009E   504 _SM1	=	0x009e
                           00009D   505 _SM2	=	0x009d
                           00009C   506 _REN	=	0x009c
                           00009B   507 _TB8	=	0x009b
                           00009A   508 _RB8	=	0x009a
                           000099   509 _TI	=	0x0099
                           000098   510 _RI	=	0x0098
                           0000CF   511 _TF2	=	0x00cf
                           0000CF   512 _CAP1F	=	0x00cf
                           0000CE   513 _EXF2	=	0x00ce
                           0000CD   514 _RCLK	=	0x00cd
                           0000CC   515 _TCLK	=	0x00cc
                           0000CB   516 _EXEN2	=	0x00cb
                           0000CA   517 _TR2	=	0x00ca
                           0000C9   518 _C_T2	=	0x00c9
                           0000C8   519 _CP_RL2	=	0x00c8
                           0000FF   520 _S0_FST_ACT	=	0x00ff
                           0000FE   521 _S0_IF_OV	=	0x00fe
                           0000FD   522 _S0_IF_FIRST	=	0x00fd
                           0000FC   523 _S0_IF_BYTE	=	0x00fc
                           0000FB   524 _S0_FREE	=	0x00fb
                           0000FA   525 _S0_T_FIFO	=	0x00fa
                           0000F8   526 _S0_R_FIFO	=	0x00f8
                           0000F7   527 _ADC_START	=	0x00f7
                                    528 ;--------------------------------------------------------
                                    529 ; overlayable register banks
                                    530 ;--------------------------------------------------------
                                    531 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        532 	.ds 8
                                    533 ;--------------------------------------------------------
                                    534 ; internal ram data
                                    535 ;--------------------------------------------------------
                                    536 	.area DSEG    (DATA)
                                    537 ;--------------------------------------------------------
                                    538 ; overlayable items in internal ram
                                    539 ;--------------------------------------------------------
                                    540 ;--------------------------------------------------------
                                    541 ; indirectly addressable internal ram data
                                    542 ;--------------------------------------------------------
                                    543 	.area ISEG    (DATA)
                                    544 ;--------------------------------------------------------
                                    545 ; absolute internal ram data
                                    546 ;--------------------------------------------------------
                                    547 	.area IABS    (ABS,DATA)
                                    548 	.area IABS    (ABS,DATA)
                                    549 ;--------------------------------------------------------
                                    550 ; bit data
                                    551 ;--------------------------------------------------------
                                    552 	.area BSEG    (BIT)
      00000D                        553 _ak820_tapping_before_sloc0_1_0:
      00000D                        554 	.ds 1
                                    555 ;--------------------------------------------------------
                                    556 ; paged external ram data
                                    557 ;--------------------------------------------------------
                                    558 	.area PSEG    (PAG,XDATA)
                                    559 ;--------------------------------------------------------
                                    560 ; uninitialized external ram data
                                    561 ;--------------------------------------------------------
                                    562 	.area XSEG    (XDATA)
      0005E6                        563 _source_state:
      0005E6                        564 	.ds 130
      000668                        565 _pending_time:
      000668                        566 	.ds 2
      00066A                        567 _pending_code:
      00066A                        568 	.ds 2
      00066C                        569 _ak820_tapping_source_PARM_1:
      00066C                        570 	.ds 2
      00066E                        571 _hold_PARM_2:
      00066E                        572 	.ds 1
      00066F                        573 _hold_code_10000_625:
      00066F                        574 	.ds 2
      000671                        575 _hold_mods_30000_628:
      000671                        576 	.ds 1
      000672                        577 _commit_pending_id_10000_634:
      000672                        578 	.ds 1
      000673                        579 _ak820_tapping_before_event_10000_635:
      000673                        580 	.ds 2
      000675                        581 _ak820_tapping_process_record_10000_646:
      000675                        582 	.ds 2
      000677                        583 _ak820_tapping_process_code_10000_647:
      000677                        584 	.ds 2
      000679                        585 _ak820_tapping_process_sc_mods_10000_647:
      000679                        586 	.ds 1
      00067A                        587 _ak820_oneshot_mods::
      00067A                        588 	.ds 1
      00067B                        589 _ak820_oneshot_consumed::
      00067B                        590 	.ds 1
      00067C                        591 _ak820_oneshot_process_PARM_2:
      00067C                        592 	.ds 1
      00067D                        593 _ak820_oneshot_process_PARM_3:
      00067D                        594 	.ds 1
      00067E                        595 _ak820_oneshot_process_code_10000_672:
      00067E                        596 	.ds 2
      000680                        597 _ak820_oneshot_process_mods_10000_673:
      000680                        598 	.ds 1
                                    599 ;--------------------------------------------------------
                                    600 ; absolute external ram data
                                    601 ;--------------------------------------------------------
                                    602 	.area XABS    (ABS,XDATA)
                                    603 ;--------------------------------------------------------
                                    604 ; initialized external ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area XISEG   (XDATA)
      000DD5                        607 _pending:
      000DD5                        608 	.ds 1
      000DD6                        609 _ak820_oneshot_target::
      000DD6                        610 	.ds 1
                                    611 	.area HOME    (CODE)
                                    612 	.area GSINIT0 (CODE)
                                    613 	.area GSINIT1 (CODE)
                                    614 	.area GSINIT2 (CODE)
                                    615 	.area GSINIT3 (CODE)
                                    616 	.area GSINIT4 (CODE)
                                    617 	.area GSINIT5 (CODE)
                                    618 	.area GSINIT  (CODE)
                                    619 	.area GSFINAL (CODE)
                                    620 	.area CSEG    (CODE)
                                    621 ;--------------------------------------------------------
                                    622 ; global & static initialisations
                                    623 ;--------------------------------------------------------
                                    624 	.area HOME    (CODE)
                                    625 	.area GSINIT  (CODE)
                                    626 	.area GSFINAL (CODE)
                                    627 	.area GSINIT  (CODE)
                                    628 ;--------------------------------------------------------
                                    629 ; Home
                                    630 ;--------------------------------------------------------
                                    631 	.area HOME    (CODE)
                                    632 	.area HOME    (CODE)
                                    633 ;--------------------------------------------------------
                                    634 ; code
                                    635 ;--------------------------------------------------------
                                    636 	.area CSEG    (CODE)
                                    637 ;------------------------------------------------------------
                                    638 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    639 ;------------------------------------------------------------
                                    640 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    641 ;------------------------------------------------------------
                                    642 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    643 ;	-----------------------------------------
                           000007   644 	ar7 = 0x07
                           000006   645 	ar6 = 0x06
                           000005   646 	ar5 = 0x05
                           000004   647 	ar4 = 0x04
                           000003   648 	ar3 = 0x03
                           000002   649 	ar2 = 0x02
                           000001   650 	ar1 = 0x01
                           000000   651 	ar0 = 0x00
                                    652 ;	 function ak820_tapping_source
                                    653 ;	-----------------------------------------
      00481A                        654 _ak820_tapping_source:
                                    655 ;	keyboards/ajazz/ak820/ak820_tapping.c:40: if (key.row < MATRIX_ROWS && key.col < MATRIX_COLS) return key.row * MATRIX_COLS + key.col;
      00481A 90 06 6D         [24]  656 	mov	dptr,#(_ak820_tapping_source_PARM_1 + 0x0001)
      00481D E0               [24]  657 	movx	a,@dptr
      00481E FF               [12]  658 	mov	r7,a
      00481F BF 10 00         [24]  659 	cjne	r7,#0x10,00147$
      004822                        660 00147$:
      004822 50 14            [24]  661 	jnc	00102$
      004824 90 06 6C         [24]  662 	mov	dptr,#_ak820_tapping_source_PARM_1
      004827 E0               [24]  663 	movx	a,@dptr
      004828 FE               [12]  664 	mov	r6,a
      004829 BE 08 00         [24]  665 	cjne	r6,#0x08,00149$
      00482C                        666 00149$:
      00482C 50 0A            [24]  667 	jnc	00102$
      00482E 8F 05            [24]  668 	mov	ar5,r7
      004830 ED               [12]  669 	mov	a,r5
      004831 12 38 94         [24]  670 	lcall	_ak820_outline_0193
      004834 2E               [12]  671 	add	a,r6
      004835 F5 82            [12]  672 	mov	dpl,a
      004837 22               [24]  673 	ret
      004838                        674 00102$:
                                    675 ;	keyboards/ajazz/ak820/ak820_tapping.c:41: if (key.col < NUM_ENCODERS) {
      004838 90 06 6C         [24]  676 	mov	dptr,#_ak820_tapping_source_PARM_1
      00483B E0               [24]  677 	movx	a,@dptr
      00483C FE               [12]  678 	mov	r6,a
      00483D BE 01 00         [24]  679 	cjne	r6,#0x01,00151$
      004840                        680 00151$:
      004840 50 0E            [24]  681 	jnc	00109$
                                    682 ;	keyboards/ajazz/ak820/ak820_tapping.c:42: if (key.row == KEYLOC_ENCODER_CW) return MATRIX_ROWS * MATRIX_COLS + key.col;
      004842 BF FD 04         [24]  683 	cjne	r7,#0xfd,00105$
      004845 75 82 80         [24]  684 	mov	dpl, #0x80
      004848 22               [24]  685 	ret
      004849                        686 00105$:
                                    687 ;	keyboards/ajazz/ak820/ak820_tapping.c:43: if (key.row == KEYLOC_ENCODER_CCW) return MATRIX_ROWS * MATRIX_COLS + NUM_ENCODERS + key.col;
      004849 BF FC 04         [24]  688 	cjne	r7,#0xfc,00109$
      00484C 75 82 81         [24]  689 	mov	dpl, #0x81
      00484F 22               [24]  690 	ret
      004850                        691 00109$:
                                    692 ;	keyboards/ajazz/ak820/ak820_tapping.c:45: return NONE;
      004850 75 82 FF         [24]  693 	mov	dpl, #0xff
                                    694 ;	keyboards/ajazz/ak820/ak820_tapping.c:46: }
      004853 22               [24]  695 	ret
                                    696 ;------------------------------------------------------------
                                    697 ;Allocation info for local variables in function 'hold'
                                    698 ;------------------------------------------------------------
                                    699 ;pressed       Allocated with name '_hold_PARM_2'
                                    700 ;code          Allocated with name '_hold_code_10000_625'
                                    701 ;mods          Allocated with name '_hold_mods_30000_628'
                                    702 ;layer         Allocated with name '_hold_layer_30000_631'
                                    703 ;------------------------------------------------------------
                                    704 ;	keyboards/ajazz/ak820/ak820_tapping.c:47: static void hold(uint16_t code, bool pressed) {
                                    705 ;	-----------------------------------------
                                    706 ;	 function hold
                                    707 ;	-----------------------------------------
      004854                        708 _hold:
      004854 12 38 5B         [24]  709 	lcall	_ak820_outline_0106
      004857 90 06 6F         [24]  710 	mov	dptr,#_hold_code_10000_625
      00485A 12 38 60         [24]  711 	lcall	_ak820_outline_0107
                                    712 ;	keyboards/ajazz/ak820/ak820_tapping.c:48: if (code < QK_LAYER_TAP) {
      00485D 90 06 6F         [24]  713 	mov	dptr,#_hold_code_10000_625
      004860 12 37 D9         [24]  714 	lcall	_ak820_outline_0010
      004863 74 C0            [12]  715 	mov	a,#0x100 - 0x40
      004865 2D               [12]  716 	add	a,r5
      004866 40 2E            [24]  717 	jc	00110$
                                    718 ;	keyboards/ajazz/ak820/ak820_tapping.c:49: uint8_t mods = (code >> 8) & 31;
      004868 8F 05            [24]  719 	mov	ar5,r7
      00486A 53 05 1F         [24]  720 	anl	ar5,#0x1f
      00486D 90 06 71         [24]  721 	mov	dptr,#_hold_mods_30000_628
      004870 ED               [12]  722 	mov	a,r5
      004871 F0               [24]  723 	movx	@dptr,a
                                    724 ;	keyboards/ajazz/ak820/ak820_tapping.c:50: if (mods & 16) mods <<= 4;
      004872 ED               [12]  725 	mov	a,r5
      004873 30 E4 08         [24]  726 	jnb	acc.4,00102$
      004876 ED               [12]  727 	mov	a,r5
      004877 C4               [12]  728 	swap	a
      004878 54 F0            [12]  729 	anl	a,#0xf0
      00487A 90 06 71         [24]  730 	mov	dptr,#_hold_mods_30000_628
      00487D F0               [24]  731 	movx	@dptr,a
      00487E                        732 00102$:
                                    733 ;	keyboards/ajazz/ak820/ak820_tapping.c:51: if (pressed) register_mods(mods);
      00487E 90 06 6E         [24]  734 	mov	dptr,#_hold_PARM_2
      004881 E0               [24]  735 	movx	a,@dptr
      004882 60 09            [24]  736 	jz	00104$
      004884 90 06 71         [24]  737 	mov	dptr,#_hold_mods_30000_628
      004887 E0               [24]  738 	movx	a,@dptr
      004888 F5 82            [12]  739 	mov	dpl,a
      00488A 02 7A 2C         [24]  740 	ljmp	_register_mods
      00488D                        741 00104$:
                                    742 ;	keyboards/ajazz/ak820/ak820_tapping.c:52: else unregister_mods(mods);
      00488D 90 06 71         [24]  743 	mov	dptr,#_hold_mods_30000_628
      004890 E0               [24]  744 	movx	a,@dptr
      004891 F5 82            [12]  745 	mov	dpl,a
      004893 02 7A 40         [24]  746 	ljmp	_unregister_mods
      004896                        747 00110$:
                                    748 ;	keyboards/ajazz/ak820/ak820_tapping.c:54: uint8_t layer = (code >> 8) & 15;
      004896 8F 06            [24]  749 	mov	ar6,r7
      004898 74 0F            [12]  750 	mov	a,#0x0f
      00489A 5E               [12]  751 	anl	a,r6
      00489B FF               [12]  752 	mov	r7,a
                                    753 ;	keyboards/ajazz/ak820/ak820_tapping.c:55: if (pressed) layer_hold_on(layer);
      00489C 90 06 6E         [24]  754 	mov	dptr,#_hold_PARM_2
      00489F E0               [24]  755 	movx	a,@dptr
      0048A0 60 05            [24]  756 	jz	00107$
      0048A2 8F 82            [24]  757 	mov	dpl, r7
      0048A4 02 7B F0         [24]  758 	ljmp	_layer_hold_on
      0048A7                        759 00107$:
                                    760 ;	keyboards/ajazz/ak820/ak820_tapping.c:56: else layer_hold_off(layer);
      0048A7 8F 82            [24]  761 	mov	dpl, r7
                                    762 ;	keyboards/ajazz/ak820/ak820_tapping.c:58: }
      0048A9 02 7C 28         [24]  763 	ljmp	_layer_hold_off
                                    764 ;------------------------------------------------------------
                                    765 ;Allocation info for local variables in function 'commit_pending'
                                    766 ;------------------------------------------------------------
                                    767 ;id            Allocated with name '_commit_pending_id_10000_634'
                                    768 ;------------------------------------------------------------
                                    769 ;	keyboards/ajazz/ak820/ak820_tapping.c:59: static void commit_pending(void) {
                                    770 ;	-----------------------------------------
                                    771 ;	 function commit_pending
                                    772 ;	-----------------------------------------
      0048AC                        773 _commit_pending:
                                    774 ;	keyboards/ajazz/ak820/ak820_tapping.c:60: uint8_t id = pending;
      0048AC 90 0D D5         [24]  775 	mov	dptr,#_pending
      0048AF E0               [24]  776 	movx	a,@dptr
      0048B0 90 06 72         [24]  777 	mov	dptr,#_commit_pending_id_10000_634
      0048B3 F0               [24]  778 	movx	@dptr,a
                                    779 ;	keyboards/ajazz/ak820/ak820_tapping.c:61: pending = NONE; /* A report callback cannot resurrect the decision. */
      0048B4 12 4D 2D         [24]  780 	lcall	_ak820_outline_0159
                                    781 ;	keyboards/ajazz/ak820/ak820_tapping.c:62: source_state[id] |= SOURCE_HELD;
      0048B7 90 06 72         [24]  782 	mov	dptr,#_commit_pending_id_10000_634
      0048BA E0               [24]  783 	movx	a,@dptr
      0048BB 24 E6            [12]  784 	add	a,#_source_state
      0048BD FF               [12]  785 	mov	r7,a
      0048BE E4               [12]  786 	clr	a
      0048BF 34 05            [12]  787 	addc	a, #(_source_state >> 8)
      0048C1 FE               [12]  788 	mov	r6,a
      0048C2 12 43 55         [24]  789 	lcall	_ak820_outline_0161
      0048C5 E0               [24]  790 	movx	a,@dptr
      0048C6 FD               [12]  791 	mov	r5,a
      0048C7 43 05 04         [24]  792 	orl	ar5,#0x04
      0048CA 12 43 55         [24]  793 	lcall	_ak820_outline_0161
      0048CD ED               [12]  794 	mov	a,r5
      0048CE F0               [24]  795 	movx	@dptr,a
                                    796 ;	keyboards/ajazz/ak820/ak820_tapping.c:63: hold(pending_code, true);
      0048CF 90 06 6A         [24]  797 	mov	dptr,#_pending_code
      0048D2 12 38 05         [24]  798 	lcall	_ak820_outline_0051
      0048D5 90 06 6E         [24]  799 	mov	dptr,#_hold_PARM_2
      0048D8 12 4C FC         [24]  800 	lcall	_ak820_outline_0055
                                    801 ;	keyboards/ajazz/ak820/ak820_tapping.c:64: }
      0048DB 02 48 54         [24]  802 	ljmp	_hold
                                    803 ;------------------------------------------------------------
                                    804 ;Allocation info for local variables in function 'ak820_tapping_before'
                                    805 ;------------------------------------------------------------
                                    806 ;event         Allocated with name '_ak820_tapping_before_event_10000_635'
                                    807 ;id            Allocated with name '_ak820_tapping_before_id_10000_636'
                                    808 ;------------------------------------------------------------
                                    809 ;	keyboards/ajazz/ak820/ak820_tapping.c:65: bool ak820_tapping_before(const keyevent_t AK820_STATE_MEM *event) {
                                    810 ;	-----------------------------------------
                                    811 ;	 function ak820_tapping_before
                                    812 ;	-----------------------------------------
      0048DE                        813 _ak820_tapping_before:
      0048DE 12 38 5B         [24]  814 	lcall	_ak820_outline_0106
      0048E1 90 06 73         [24]  815 	mov	dptr,#_ak820_tapping_before_event_10000_635
      0048E4 12 38 60         [24]  816 	lcall	_ak820_outline_0107
                                    817 ;	keyboards/ajazz/ak820/ak820_tapping.c:66: uint8_t id = ak820_tapping_source(event->key);
      0048E7 90 06 73         [24]  818 	mov	dptr,#_ak820_tapping_before_event_10000_635
      0048EA 12 37 D9         [24]  819 	lcall	_ak820_outline_0010
      0048ED 12 4C E2         [24]  820 	lcall	_ak820_outline_0024
      0048F0 C0 07            [24]  821 	push	ar7
      0048F2 C0 06            [24]  822 	push	ar6
      0048F4 12 BB FD         [24]  823 	lcall	___memcpy
      0048F7 12 48 1A         [24]  824 	lcall	_ak820_tapping_source
      0048FA AD 82            [24]  825 	mov	r5, dpl
      0048FC D0 06            [24]  826 	pop	ar6
      0048FE D0 07            [24]  827 	pop	ar7
                                    828 ;	keyboards/ajazz/ak820/ak820_tapping.c:68: if (vial_unlock_in_progress) {
      004900 90 0E 46         [24]  829 	mov	dptr,#_vial_unlock_in_progress
      004903 E0               [24]  830 	movx	a,@dptr
      004904 60 29            [24]  831 	jz	00106$
                                    832 ;	keyboards/ajazz/ak820/ak820_tapping.c:69: if (IS_EVENT(*event) && id != NONE && !event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      004906 74 04            [12]  833 	mov	a,#0x04
      004908 12 4C BD         [24]  834 	lcall	_ak820_outline_0012
      00490B 60 1E            [24]  835 	jz	00102$
      00490D BD FF 02         [24]  836 	cjne	r5,#0xff,00218$
      004910 80 19            [24]  837 	sjmp	00102$
      004912                        838 00218$:
      004912 74 05            [12]  839 	mov	a,#0x05
      004914 12 4C BD         [24]  840 	lcall	_ak820_outline_0012
      004917 70 12            [24]  841 	jnz	00102$
      004919 ED               [12]  842 	mov	a,r5
      00491A 24 E6            [12]  843 	add	a, #_source_state
      00491C FB               [12]  844 	mov	r3,a
      00491D E4               [12]  845 	clr	a
      00491E 34 05            [12]  846 	addc	a, #(_source_state >> 8)
      004920 12 4D 04         [24]  847 	lcall	_ak820_outline_0056
      004923 53 02 FD         [24]  848 	anl	ar2,#0xfd
      004926 12 33 FC         [24]  849 	lcall	_ak820_outline_0126
      004929 EA               [12]  850 	mov	a,r2
      00492A F0               [24]  851 	movx	@dptr,a
      00492B                        852 00102$:
                                    853 ;	keyboards/ajazz/ak820/ak820_tapping.c:70: return false;
      00492B 75 82 00         [24]  854 	mov	dpl, #0x00
      00492E 22               [24]  855 	ret
      00492F                        856 00106$:
                                    857 ;	keyboards/ajazz/ak820/ak820_tapping.c:73: if (pending != NONE && ((uint16_t)(event->time - pending_time) >= AK820_TAPPING_TERM ||
      00492F 90 0D D5         [24]  858 	mov	dptr,#_pending
      004932 E0               [24]  859 	movx	a,@dptr
      004933 FC               [12]  860 	mov	r4,a
      004934 BC FF 02         [24]  861 	cjne	r4,#0xff,00220$
      004937 80 5A            [24]  862 	sjmp	00108$
      004939                        863 00220$:
      004939 12 37 FD         [24]  864 	lcall	_ak820_outline_0034
      00493C FB               [12]  865 	mov	r3,a
      00493D A3               [24]  866 	inc	dptr
      00493E E0               [24]  867 	movx	a,@dptr
      00493F FC               [12]  868 	mov	r4,a
      004940 90 06 68         [24]  869 	mov	dptr,#_pending_time
      004943 E0               [24]  870 	movx	a,@dptr
      004944 F9               [12]  871 	mov	r1,a
      004945 A3               [24]  872 	inc	dptr
      004946 E0               [24]  873 	movx	a,@dptr
      004947 FA               [12]  874 	mov	r2,a
      004948 EB               [12]  875 	mov	a,r3
      004949 C3               [12]  876 	clr	c
      00494A 99               [12]  877 	subb	a,r1
      00494B FB               [12]  878 	mov	r3,a
      00494C EC               [12]  879 	mov	a,r4
      00494D 9A               [12]  880 	subb	a,r2
      00494E FC               [12]  881 	mov	r4,a
      00494F C0 07            [24]  882 	push	ar7
      004951 C0 06            [24]  883 	push	ar6
      004953 C0 05            [24]  884 	push	ar5
      004955 C0 04            [24]  885 	push	ar4
      004957 C0 03            [24]  886 	push	ar3
      004959 12 47 BA         [24]  887 	lcall	_ak820_settings_tapping_term
      00495C 12 4D 34         [24]  888 	lcall	_ak820_outline_0189
      00495F D0 03            [24]  889 	pop	ar3
      004961 D0 04            [24]  890 	pop	ar4
      004963 D0 05            [24]  891 	pop	ar5
      004965 D0 06            [24]  892 	pop	ar6
      004967 D0 07            [24]  893 	pop	ar7
      004969 C3               [12]  894 	clr	c
      00496A EB               [12]  895 	mov	a,r3
      00496B 99               [12]  896 	subb	a,r1
      00496C EC               [12]  897 	mov	a,r4
      00496D 9A               [12]  898 	subb	a,r2
      00496E 50 1C            [24]  899 	jnc	00107$
                                    900 ;	keyboards/ajazz/ak820/ak820_tapping.c:74: (IS_EVENT(*event) && event->pressed && (id == NONE || id != pending)))) commit_pending();
      004970 74 04            [12]  901 	mov	a,#0x04
      004972 12 4C BD         [24]  902 	lcall	_ak820_outline_0012
      004975 60 1C            [24]  903 	jz	00108$
      004977 12 37 B8         [24]  904 	lcall	_ak820_outline_0005
      00497A 60 17            [24]  905 	jz	00108$
      00497C BD FF 02         [24]  906 	cjne	r5,#0xff,00224$
      00497F 80 0B            [24]  907 	sjmp	00107$
      004981                        908 00224$:
      004981 90 0D D5         [24]  909 	mov	dptr,#_pending
      004984 E0               [24]  910 	movx	a,@dptr
      004985 FF               [12]  911 	mov	r7,a
      004986 ED               [12]  912 	mov	a,r5
      004987 B5 07 02         [24]  913 	cjne	a,ar7,00225$
      00498A 80 07            [24]  914 	sjmp	00108$
      00498C                        915 00225$:
      00498C                        916 00107$:
      00498C C0 05            [24]  917 	push	ar5
      00498E 12 48 AC         [24]  918 	lcall	_commit_pending
      004991 D0 05            [24]  919 	pop	ar5
      004993                        920 00108$:
                                    921 ;	keyboards/ajazz/ak820/ak820_tapping.c:75: if (IS_NOEVENT(*event) || id == NONE) return true;
      004993 90 06 73         [24]  922 	mov	dptr,#_ak820_tapping_before_event_10000_635
      004996 12 38 05         [24]  923 	lcall	_ak820_outline_0051
      004999 74 04            [12]  924 	mov	a,#0x04
      00499B 12 4C BD         [24]  925 	lcall	_ak820_outline_0012
      00499E 60 03            [24]  926 	jz	00114$
      0049A0 BD FF 04         [24]  927 	cjne	r5,#0xff,00115$
      0049A3                        928 00114$:
      0049A3 75 82 01         [24]  929 	mov	dpl, #0x01
      0049A6 22               [24]  930 	ret
      0049A7                        931 00115$:
                                    932 ;	keyboards/ajazz/ak820/ak820_tapping.c:76: if ((source_state[id] & SOURCE_BLOCKED)) {
      0049A7 ED               [12]  933 	mov	a,r5
      0049A8 12 4D 19         [24]  934 	lcall	_ak820_outline_0079
      0049AB 30 E1 13         [24]  935 	jnb	acc.1,00120$
                                    936 ;	keyboards/ajazz/ak820/ak820_tapping.c:77: if (!event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      0049AE 74 05            [12]  937 	mov	a,#0x05
      0049B0 2E               [12]  938 	add	a, r6
      0049B1 12 37 E3         [24]  939 	lcall	_ak820_outline_0014
      0049B4 70 07            [24]  940 	jnz	00118$
      0049B6 74 FD            [12]  941 	mov	a,#0xfd
      0049B8 5B               [12]  942 	anl	a,r3
      0049B9 12 38 65         [24]  943 	lcall	_ak820_outline_0125
      0049BC F0               [24]  944 	movx	@dptr,a
      0049BD                        945 00118$:
                                    946 ;	keyboards/ajazz/ak820/ak820_tapping.c:78: return false;
      0049BD 75 82 00         [24]  947 	mov	dpl, #0x00
      0049C0 22               [24]  948 	ret
      0049C1                        949 00120$:
                                    950 ;	keyboards/ajazz/ak820/ak820_tapping.c:81: if (event->pressed == ((source_state[id] & SOURCE_ACTIVE) != 0)) return false;
      0049C1 12 42 CC         [24]  951 	lcall	_ak820_outline_0011
      0049C4 E0               [24]  952 	movx	a,@dptr
      0049C5 FF               [12]  953 	mov	r7,a
      0049C6 8B 06            [24]  954 	mov	ar6,r3
      0049C8 53 06 01         [24]  955 	anl	ar6,#0x01
      0049CB EE               [12]  956 	mov	a,r6
      0049CC B4 01 00         [24]  957 	cjne	a,#0x01,00231$
      0049CF                        958 00231$:
      0049CF B3               [12]  959 	cpl	c
      0049D0 92 0D            [24]  960 	mov	_ak820_tapping_before_sloc0_1_0,c
      0049D2 8F F0            [24]  961 	mov	b,r7
      0049D4 E4               [12]  962 	clr	a
      0049D5 33               [12]  963 	rlc	a
      0049D6 B5 F0 04         [24]  964 	cjne	a,b,00122$
      0049D9 75 82 00         [24]  965 	mov	dpl, #0x00
      0049DC 22               [24]  966 	ret
      0049DD                        967 00122$:
                                    968 ;	keyboards/ajazz/ak820/ak820_tapping.c:82: source_state[id] ^= SOURCE_ACTIVE;
      0049DD 63 03 01         [24]  969 	xrl	ar3,#0x01
      0049E0 12 38 65         [24]  970 	lcall	_ak820_outline_0125
      0049E3 EB               [12]  971 	mov	a,r3
      0049E4 F0               [24]  972 	movx	@dptr,a
                                    973 ;	keyboards/ajazz/ak820/ak820_tapping.c:83: return true;
      0049E5 75 82 01         [24]  974 	mov	dpl, #0x01
                                    975 ;	keyboards/ajazz/ak820/ak820_tapping.c:84: }
      0049E8 22               [24]  976 	ret
                                    977 ;------------------------------------------------------------
                                    978 ;Allocation info for local variables in function 'ak820_tapping_process'
                                    979 ;------------------------------------------------------------
                                    980 ;record        Allocated with name '_ak820_tapping_process_record_10000_646'
                                    981 ;id            Allocated with name '_ak820_tapping_process_id_10000_647'
                                    982 ;kind          Allocated with name '_ak820_tapping_process_kind_10000_647'
                                    983 ;code          Allocated with name '_ak820_tapping_process_code_10000_647'
                                    984 ;sc_mods       Allocated with name '_ak820_tapping_process_sc_mods_10000_647'
                                    985 ;------------------------------------------------------------
                                    986 ;	keyboards/ajazz/ak820/ak820_tapping.c:85: bool ak820_tapping_process(keyrecord_t AK820_STATE_MEM *record) {
                                    987 ;	-----------------------------------------
                                    988 ;	 function ak820_tapping_process
                                    989 ;	-----------------------------------------
      0049E9                        990 _ak820_tapping_process:
      0049E9 12 38 5B         [24]  991 	lcall	_ak820_outline_0106
      0049EC 90 06 75         [24]  992 	mov	dptr,#_ak820_tapping_process_record_10000_646
      0049EF 12 38 60         [24]  993 	lcall	_ak820_outline_0107
                                    994 ;	keyboards/ajazz/ak820/ak820_tapping.c:89: uint8_t sc_mods = 0;
      0049F2 90 06 79         [24]  995 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_647
      0049F5 E4               [12]  996 	clr	a
      0049F6 F0               [24]  997 	movx	@dptr,a
                                    998 ;	keyboards/ajazz/ak820/ak820_tapping.c:91: if (IS_NOEVENT(record->event)) return true;
      0049F7 90 06 75         [24]  999 	mov	dptr,#_ak820_tapping_process_record_10000_646
      0049FA 12 38 05         [24] 1000 	lcall	_ak820_outline_0051
      0049FD 74 04            [12] 1001 	mov	a,#0x04
      0049FF 12 4C C8         [24] 1002 	lcall	_ak820_outline_0013
      004A02 70 04            [24] 1003 	jnz	00102$
      004A04 75 82 01         [24] 1004 	mov	dpl, #0x01
      004A07 22               [24] 1005 	ret
      004A08                       1006 00102$:
                                   1007 ;	keyboards/ajazz/ak820/ak820_tapping.c:92: id = ak820_tapping_source(record->event.key);
      004A08 8E 04            [24] 1008 	mov	ar4,r6
      004A0A 8F 05            [24] 1009 	mov	ar5,r7
      004A0C 12 4C E2         [24] 1010 	lcall	_ak820_outline_0024
      004A0F C0 07            [24] 1011 	push	ar7
      004A11 C0 06            [24] 1012 	push	ar6
      004A13 12 BB FD         [24] 1013 	lcall	___memcpy
      004A16 12 48 1A         [24] 1014 	lcall	_ak820_tapping_source
      004A19 AD 82            [24] 1015 	mov	r5, dpl
      004A1B D0 06            [24] 1016 	pop	ar6
      004A1D D0 07            [24] 1017 	pop	ar7
                                   1018 ;	keyboards/ajazz/ak820/ak820_tapping.c:93: if (id == NONE) return true;
      004A1F BD FF 04         [24] 1019 	cjne	r5,#0xff,00104$
      004A22 75 82 01         [24] 1020 	mov	dpl, #0x01
      004A25 22               [24] 1021 	ret
      004A26                       1022 00104$:
                                   1023 ;	keyboards/ajazz/ak820/ak820_tapping.c:94: code = record->keycode;
      004A26 74 07            [12] 1024 	mov	a,#0x07
      004A28 12 37 F5         [24] 1025 	lcall	_ak820_outline_0017
      004A2B 12 38 05         [24] 1026 	lcall	_ak820_outline_0051
      004A2E 90 06 77         [24] 1027 	mov	dptr,#_ak820_tapping_process_code_10000_647
      004A31 12 4D 0C         [24] 1028 	lcall	_ak820_outline_0060
                                   1029 ;	keyboards/ajazz/ak820/ak820_tapping.c:96: if (code == SC_LSPO) { code = MT(MOD_LSFT, KC_9); sc_mods = MOD_BIT(KC_LEFT_SHIFT); }
      004A34 BE 1A 15         [24] 1030 	cjne	r6,#0x1a,00111$
      004A37 BF 7C 12         [24] 1031 	cjne	r7,#0x7c,00111$
      004A3A 90 06 77         [24] 1032 	mov	dptr,#_ak820_tapping_process_code_10000_647
      004A3D 74 26            [12] 1033 	mov	a,#0x26
      004A3F F0               [24] 1034 	movx	@dptr,a
      004A40 74 22            [12] 1035 	mov	a,#0x22
      004A42 A3               [24] 1036 	inc	dptr
      004A43 F0               [24] 1037 	movx	@dptr,a
      004A44 90 06 79         [24] 1038 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_647
      004A47 74 02            [12] 1039 	mov	a,#0x02
      004A49 F0               [24] 1040 	movx	@dptr,a
      004A4A 80 28            [24] 1041 	sjmp	00112$
      004A4C                       1042 00111$:
                                   1043 ;	keyboards/ajazz/ak820/ak820_tapping.c:97: else if (code == SC_RSPC) { code = MT(MOD_RSFT, KC_0); sc_mods = MOD_BIT(KC_RIGHT_SHIFT); }
      004A4C BE 1B 15         [24] 1044 	cjne	r6,#0x1b,00108$
      004A4F BF 7C 12         [24] 1045 	cjne	r7,#0x7c,00108$
      004A52 90 06 77         [24] 1046 	mov	dptr,#_ak820_tapping_process_code_10000_647
      004A55 74 27            [12] 1047 	mov	a,#0x27
      004A57 F0               [24] 1048 	movx	@dptr,a
      004A58 74 32            [12] 1049 	mov	a,#0x32
      004A5A A3               [24] 1050 	inc	dptr
      004A5B F0               [24] 1051 	movx	@dptr,a
      004A5C 90 06 79         [24] 1052 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_647
      004A5F 74 20            [12] 1053 	mov	a,#0x20
      004A61 F0               [24] 1054 	movx	@dptr,a
      004A62 80 10            [24] 1055 	sjmp	00112$
      004A64                       1056 00108$:
                                   1057 ;	keyboards/ajazz/ak820/ak820_tapping.c:98: else if (code == SC_SENT) code = MT(MOD_RSFT, KC_ENTER);
      004A64 BE 1E 0D         [24] 1058 	cjne	r6,#0x1e,00112$
      004A67 BF 7C 0A         [24] 1059 	cjne	r7,#0x7c,00112$
      004A6A 90 06 77         [24] 1060 	mov	dptr,#_ak820_tapping_process_code_10000_647
      004A6D 74 28            [12] 1061 	mov	a,#0x28
      004A6F F0               [24] 1062 	movx	@dptr,a
      004A70 74 32            [12] 1063 	mov	a,#0x32
      004A72 A3               [24] 1064 	inc	dptr
      004A73 F0               [24] 1065 	movx	@dptr,a
      004A74                       1066 00112$:
                                   1067 ;	keyboards/ajazz/ak820/ak820_tapping.c:100: kind = code >> 8;
      004A74 90 06 77         [24] 1068 	mov	dptr,#_ak820_tapping_process_code_10000_647
      004A77 E0               [24] 1069 	movx	a,@dptr
      004A78 A3               [24] 1070 	inc	dptr
      004A79 E0               [24] 1071 	movx	a,@dptr
      004A7A FF               [12] 1072 	mov	r7,a
                                   1073 ;	keyboards/ajazz/ak820/ak820_tapping.c:101: if (kind < 0x20 || kind >= 0x50) return true;
      004A7B BF 20 00         [24] 1074 	cjne	r7,#0x20,00242$
      004A7E                       1075 00242$:
      004A7E 40 05            [24] 1076 	jc	00113$
      004A80 BF 50 00         [24] 1077 	cjne	r7,#0x50,00244$
      004A83                       1078 00244$:
      004A83 40 04            [24] 1079 	jc	00114$
      004A85                       1080 00113$:
      004A85 75 82 01         [24] 1081 	mov	dpl, #0x01
      004A88 22               [24] 1082 	ret
      004A89                       1083 00114$:
                                   1084 ;	keyboards/ajazz/ak820/ak820_tapping.c:102: if (kind >= 0x40 && (kind & 15) >= MAX_LAYER) return false;
      004A89 BF 40 00         [24] 1085 	cjne	r7,#0x40,00246$
      004A8C                       1086 00246$:
      004A8C 40 0C            [24] 1087 	jc	00117$
      004A8E 53 07 0F         [24] 1088 	anl	ar7,#0x0f
      004A91 BF 06 00         [24] 1089 	cjne	r7,#0x06,00248$
      004A94                       1090 00248$:
      004A94 40 04            [24] 1091 	jc	00117$
      004A96 75 82 00         [24] 1092 	mov	dpl, #0x00
      004A99 22               [24] 1093 	ret
      004A9A                       1094 00117$:
                                   1095 ;	keyboards/ajazz/ak820/ak820_tapping.c:103: if (record->event.pressed) {
      004A9A 90 06 75         [24] 1096 	mov	dptr,#_ak820_tapping_process_record_10000_646
      004A9D 12 38 05         [24] 1097 	lcall	_ak820_outline_0051
      004AA0 74 05            [12] 1098 	mov	a,#0x05
      004AA2 12 4C BD         [24] 1099 	lcall	_ak820_outline_0012
      004AA5 60 1F            [24] 1100 	jz	00131$
                                   1101 ;	keyboards/ajazz/ak820/ak820_tapping.c:104: pending = id;
      004AA7 90 0D D5         [24] 1102 	mov	dptr,#_pending
      004AAA ED               [12] 1103 	mov	a,r5
      004AAB 12 42 D6         [24] 1104 	lcall	_ak820_outline_0031
                                   1105 ;	keyboards/ajazz/ak820/ak820_tapping.c:105: pending_time = record->event.time;
      004AAE 12 38 05         [24] 1106 	lcall	_ak820_outline_0051
      004AB1 90 06 68         [24] 1107 	mov	dptr,#_pending_time
      004AB4 12 4D 0C         [24] 1108 	lcall	_ak820_outline_0060
                                   1109 ;	keyboards/ajazz/ak820/ak820_tapping.c:106: pending_code = code;
      004AB7 90 06 77         [24] 1110 	mov	dptr,#_ak820_tapping_process_code_10000_647
      004ABA 12 38 05         [24] 1111 	lcall	_ak820_outline_0051
      004ABD 90 06 6A         [24] 1112 	mov	dptr,#_pending_code
      004AC0 12 4D 0C         [24] 1113 	lcall	_ak820_outline_0060
      004AC3 02 4B 62         [24] 1114 	ljmp	00132$
      004AC6                       1115 00131$:
                                   1116 ;	keyboards/ajazz/ak820/ak820_tapping.c:107: } else if (id == pending) {
      004AC6 90 0D D5         [24] 1117 	mov	dptr,#_pending
      004AC9 E0               [24] 1118 	movx	a,@dptr
      004ACA FF               [12] 1119 	mov	r7,a
      004ACB ED               [12] 1120 	mov	a,r5
      004ACC B5 07 02         [24] 1121 	cjne	a,ar7,00251$
      004ACF 80 03            [24] 1122 	sjmp	00252$
      004AD1                       1123 00251$:
      004AD1 02 4B 3B         [24] 1124 	ljmp	00128$
      004AD4                       1125 00252$:
                                   1126 ;	keyboards/ajazz/ak820/ak820_tapping.c:108: pending = NONE;
      004AD4 12 4D 2D         [24] 1127 	lcall	_ak820_outline_0159
                                   1128 ;	keyboards/ajazz/ak820/ak820_tapping.c:110: if (sc_mods) add_owned_mods(sc_mods);
      004AD7 90 06 79         [24] 1129 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_647
      004ADA E0               [24] 1130 	movx	a,@dptr
      004ADB FF               [12] 1131 	mov	r7,a
      004ADC E0               [24] 1132 	movx	a,@dptr
      004ADD 60 05            [24] 1133 	jz	00120$
      004ADF 8F 82            [24] 1134 	mov	dpl, r7
      004AE1 12 80 75         [24] 1135 	lcall	_add_owned_mods
      004AE4                       1136 00120$:
                                   1137 ;	keyboards/ajazz/ak820/ak820_tapping.c:114: record->keycode = (uint8_t)code;
      004AE4 90 06 75         [24] 1138 	mov	dptr,#_ak820_tapping_process_record_10000_646
      004AE7 12 38 05         [24] 1139 	lcall	_ak820_outline_0051
      004AEA 74 07            [12] 1140 	mov	a,#0x07
      004AEC 2E               [12] 1141 	add	a, r6
      004AED FB               [12] 1142 	mov	r3,a
      004AEE E4               [12] 1143 	clr	a
      004AEF 3F               [12] 1144 	addc	a, r7
      004AF0 FC               [12] 1145 	mov	r4,a
      004AF1 90 06 77         [24] 1146 	mov	dptr,#_ak820_tapping_process_code_10000_647
      004AF4 E0               [24] 1147 	movx	a,@dptr
      004AF5 F9               [12] 1148 	mov	r1,a
      004AF6 7A 00            [12] 1149 	mov	r2,#0x00
      004AF8 12 33 FC         [24] 1150 	lcall	_ak820_outline_0126
      004AFB 12 4D 27         [24] 1151 	lcall	_ak820_outline_0139
                                   1152 ;	keyboards/ajazz/ak820/ak820_tapping.c:115: if (record->keycode > KC_TRANSPARENT) {
      004AFE C3               [12] 1153 	clr	c
      004AFF 04               [12] 1154 	inc	a
      004B00 99               [12] 1155 	subb	a,r1
      004B01 50 26            [24] 1156 	jnc	00122$
                                   1157 ;	free result
                                   1158 ;	keyboards/ajazz/ak820/ak820_tapping.c:116: record->tap.count = 1;
      004B03 74 06            [12] 1159 	mov	a,#0x06
      004B05 12 37 F5         [24] 1160 	lcall	_ak820_outline_0017
      004B08 E0               [24] 1161 	movx	a,@dptr
      004B09 54 0F            [12] 1162 	anl	a,#0x0f
      004B0B 44 10            [12] 1163 	orl	a,#0x10
      004B0D F0               [24] 1164 	movx	@dptr,a
                                   1165 ;	keyboards/ajazz/ak820/ak820_tapping.c:117: record->event.pressed = true;
      004B0E 12 42 CC         [24] 1166 	lcall	_ak820_outline_0011
      004B11 12 4C FC         [24] 1167 	lcall	_ak820_outline_0055
                                   1168 ;	keyboards/ajazz/ak820/ak820_tapping.c:118: process_record(record);
      004B14 12 74 ED         [24] 1169 	lcall	_process_record
                                   1170 ;	keyboards/ajazz/ak820/ak820_tapping.c:119: record->event.pressed = false;
      004B17 90 06 75         [24] 1171 	mov	dptr,#_ak820_tapping_process_record_10000_646
      004B1A 12 37 AE         [24] 1172 	lcall	_ak820_outline_0004
      004B1D A3               [24] 1173 	inc	dptr
      004B1E A3               [24] 1174 	inc	dptr
      004B1F A3               [24] 1175 	inc	dptr
      004B20 A3               [24] 1176 	inc	dptr
      004B21 A3               [24] 1177 	inc	dptr
      004B22 E4               [12] 1178 	clr	a
      004B23 12 43 02         [24] 1179 	lcall	_ak820_outline_0061
                                   1180 ;	keyboards/ajazz/ak820/ak820_tapping.c:120: process_record(record);
      004B26 12 74 ED         [24] 1181 	lcall	_process_record
      004B29                       1182 00122$:
                                   1183 ;	keyboards/ajazz/ak820/ak820_tapping.c:123: if (sc_mods) {
      004B29 90 06 79         [24] 1184 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_647
      004B2C E0               [24] 1185 	movx	a,@dptr
      004B2D FF               [12] 1186 	mov	r7,a
      004B2E E0               [24] 1187 	movx	a,@dptr
      004B2F 60 31            [24] 1188 	jz	00132$
                                   1189 ;	keyboards/ajazz/ak820/ak820_tapping.c:124: del_owned_mods(sc_mods);
      004B31 8F 82            [24] 1190 	mov	dpl, r7
      004B33 12 80 85         [24] 1191 	lcall	_del_owned_mods
                                   1192 ;	keyboards/ajazz/ak820/ak820_tapping.c:125: send_keyboard_report();
      004B36 12 83 AF         [24] 1193 	lcall	_send_keyboard_report
      004B39 80 27            [24] 1194 	sjmp	00132$
      004B3B                       1195 00128$:
                                   1196 ;	keyboards/ajazz/ak820/ak820_tapping.c:128: } else if ((source_state[id] & SOURCE_HELD)) {
      004B3B ED               [12] 1197 	mov	a,r5
      004B3C 24 E6            [12] 1198 	add	a, #_source_state
      004B3E FE               [12] 1199 	mov	r6,a
      004B3F E4               [12] 1200 	clr	a
      004B40 34 05            [12] 1201 	addc	a, #(_source_state >> 8)
      004B42 FF               [12] 1202 	mov	r7,a
      004B43 12 38 43         [24] 1203 	lcall	_ak820_outline_0100
      004B46 FD               [12] 1204 	mov	r5,a
      004B47 30 E2 18         [24] 1205 	jnb	acc.2,00132$
                                   1206 ;	keyboards/ajazz/ak820/ak820_tapping.c:129: source_state[id] &= ~SOURCE_HELD;
      004B4A 53 05 FB         [24] 1207 	anl	ar5,#0xfb
      004B4D 12 43 34         [24] 1208 	lcall	_ak820_outline_0121
      004B50 ED               [12] 1209 	mov	a,r5
      004B51 F0               [24] 1210 	movx	@dptr,a
                                   1211 ;	keyboards/ajazz/ak820/ak820_tapping.c:130: hold(code, false);
      004B52 90 06 77         [24] 1212 	mov	dptr,#_ak820_tapping_process_code_10000_647
      004B55 12 38 05         [24] 1213 	lcall	_ak820_outline_0051
      004B58 90 06 6E         [24] 1214 	mov	dptr,#_hold_PARM_2
      004B5B E4               [12] 1215 	clr	a
      004B5C 12 43 02         [24] 1216 	lcall	_ak820_outline_0061
      004B5F 12 48 54         [24] 1217 	lcall	_hold
      004B62                       1218 00132$:
                                   1219 ;	keyboards/ajazz/ak820/ak820_tapping.c:132: return false;
      004B62 75 82 00         [24] 1220 	mov	dpl, #0x00
                                   1221 ;	keyboards/ajazz/ak820/ak820_tapping.c:133: }
      004B65 22               [24] 1222 	ret
                                   1223 ;------------------------------------------------------------
                                   1224 ;Allocation info for local variables in function 'ak820_tapping_cancel'
                                   1225 ;------------------------------------------------------------
                                   1226 ;i             Allocated with name '_ak820_tapping_cancel_i_20000_670'
                                   1227 ;state         Allocated with name '_ak820_tapping_cancel_state_30000_671'
                                   1228 ;------------------------------------------------------------
                                   1229 ;	keyboards/ajazz/ak820/ak820_tapping.c:134: void ak820_tapping_cancel(void) {
                                   1230 ;	-----------------------------------------
                                   1231 ;	 function ak820_tapping_cancel
                                   1232 ;	-----------------------------------------
      004B66                       1233 _ak820_tapping_cancel:
                                   1234 ;	keyboards/ajazz/ak820/ak820_tapping.c:135: pending = NONE;
      004B66 12 4D 2D         [24] 1235 	lcall	_ak820_outline_0159
                                   1236 ;	keyboards/ajazz/ak820/ak820_tapping.c:136: for (uint8_t i = 0; i < SOURCES; ++i) {
      004B69 7F 00            [12] 1237 	mov	r7,#0x00
      004B6B                       1238 00103$:
      004B6B BF 82 00         [24] 1239 	cjne	r7,#0x82,00122$
      004B6E                       1240 00122$:
      004B6E 50 16            [24] 1241 	jnc	00105$
                                   1242 ;	keyboards/ajazz/ak820/ak820_tapping.c:137: uint8_t state = source_state[i];
      004B70 12 4C D3         [24] 1243 	lcall	_ak820_outline_0020
                                   1244 ;	keyboards/ajazz/ak820/ak820_tapping.c:138: source_state[i] = (state & SOURCE_BLOCKED) | ((state & SOURCE_ACTIVE) << 1);
      004B73 74 02            [12] 1245 	mov	a,#0x02
      004B75 5C               [12] 1246 	anl	a,r4
      004B76 FB               [12] 1247 	mov	r3,a
      004B77 53 04 01         [24] 1248 	anl	ar4,#0x01
      004B7A EC               [12] 1249 	mov	a,r4
      004B7B 2C               [12] 1250 	add	a,r4
      004B7C 42 03            [12] 1251 	orl	ar3,a
      004B7E 12 38 6F         [24] 1252 	lcall	_ak820_outline_0136
      004B81 EB               [12] 1253 	mov	a,r3
      004B82 F0               [24] 1254 	movx	@dptr,a
                                   1255 ;	keyboards/ajazz/ak820/ak820_tapping.c:136: for (uint8_t i = 0; i < SOURCES; ++i) {
      004B83 0F               [12] 1256 	inc	r7
      004B84 80 E5            [24] 1257 	sjmp	00103$
      004B86                       1258 00105$:
                                   1259 ;	keyboards/ajazz/ak820/ak820_tapping.c:140: }
      004B86 22               [24] 1260 	ret
                                   1261 ;------------------------------------------------------------
                                   1262 ;Allocation info for local variables in function 'ak820_oneshot_process'
                                   1263 ;------------------------------------------------------------
                                   1264 ;id            Allocated with name '_ak820_oneshot_process_PARM_2'
                                   1265 ;pressed       Allocated with name '_ak820_oneshot_process_PARM_3'
                                   1266 ;code          Allocated with name '_ak820_oneshot_process_code_10000_672'
                                   1267 ;mods          Allocated with name '_ak820_oneshot_process_mods_10000_673'
                                   1268 ;i             Allocated with name '_ak820_oneshot_process_i_40000_687'
                                   1269 ;------------------------------------------------------------
                                   1270 ;	keyboards/ajazz/ak820/ak820_tapping.c:149: bool ak820_oneshot_process(uint16_t code, uint8_t id, bool pressed) {
                                   1271 ;	-----------------------------------------
                                   1272 ;	 function ak820_oneshot_process
                                   1273 ;	-----------------------------------------
      004B87                       1274 _ak820_oneshot_process:
      004B87 12 38 5B         [24] 1275 	lcall	_ak820_outline_0106
      004B8A 90 06 7E         [24] 1276 	mov	dptr,#_ak820_oneshot_process_code_10000_672
      004B8D 12 38 60         [24] 1277 	lcall	_ak820_outline_0107
                                   1278 ;	keyboards/ajazz/ak820/ak820_tapping.c:151: if (id == NONE || get_repeat_key_count()) return true;
      004B90 90 06 7C         [24] 1279 	mov	dptr,#_ak820_oneshot_process_PARM_2
      004B93 E0               [24] 1280 	movx	a,@dptr
      004B94 FF               [12] 1281 	mov	r7,a
      004B95 BF FF 02         [24] 1282 	cjne	r7,#0xff,00248$
      004B98 80 07            [24] 1283 	sjmp	00101$
      004B9A                       1284 00248$:
      004B9A 12 A5 1E         [24] 1285 	lcall	_get_repeat_key_count
      004B9D E5 82            [12] 1286 	mov	a, dpl
      004B9F 60 04            [24] 1287 	jz	00102$
      004BA1                       1288 00101$:
      004BA1 75 82 01         [24] 1289 	mov	dpl, #0x01
      004BA4 22               [24] 1290 	ret
      004BA5                       1291 00102$:
                                   1292 ;	keyboards/ajazz/ak820/ak820_tapping.c:164: if ((code >> 8) == 0x52 && ((uint8_t)code & 0xe0) == 0xa0) {
      004BA5 90 06 7E         [24] 1293 	mov	dptr,#_ak820_oneshot_process_code_10000_672
      004BA8 E0               [24] 1294 	movx	a,@dptr
      004BA9 FD               [12] 1295 	mov	r5,a
      004BAA A3               [24] 1296 	inc	dptr
      004BAB E0               [24] 1297 	movx	a,@dptr
      004BAC FB               [12] 1298 	mov	r3,a
      004BAD BB 52 02         [24] 1299 	cjne	r3,#0x52,00250$
      004BB0 80 03            [24] 1300 	sjmp	00251$
      004BB2                       1301 00250$:
      004BB2 02 4C 57         [24] 1302 	ljmp	00116$
      004BB5                       1303 00251$:
      004BB5 8D 04            [24] 1304 	mov	ar4,r5
      004BB7 53 04 E0         [24] 1305 	anl	ar4,#0xe0
      004BBA BC A0 02         [24] 1306 	cjne	r4,#0xa0,00252$
      004BBD 80 03            [24] 1307 	sjmp	00253$
      004BBF                       1308 00252$:
      004BBF 02 4C 57         [24] 1309 	ljmp	00116$
      004BC2                       1310 00253$:
                                   1311 ;	keyboards/ajazz/ak820/ak820_tapping.c:165: mods = code & 15;
      004BC2 8D 04            [24] 1312 	mov	ar4,r5
      004BC4 53 04 0F         [24] 1313 	anl	ar4,#0x0f
      004BC7 90 06 80         [24] 1314 	mov	dptr,#_ak820_oneshot_process_mods_10000_673
      004BCA EC               [12] 1315 	mov	a,r4
      004BCB F0               [24] 1316 	movx	@dptr,a
                                   1317 ;	keyboards/ajazz/ak820/ak820_tapping.c:166: if (code & 16) mods <<= 4;
      004BCC ED               [12] 1318 	mov	a,r5
      004BCD 30 E4 08         [24] 1319 	jnb	acc.4,00105$
      004BD0 EC               [12] 1320 	mov	a,r4
      004BD1 C4               [12] 1321 	swap	a
      004BD2 54 F0            [12] 1322 	anl	a,#0xf0
      004BD4 90 06 80         [24] 1323 	mov	dptr,#_ak820_oneshot_process_mods_10000_673
      004BD7 F0               [24] 1324 	movx	@dptr,a
      004BD8                       1325 00105$:
                                   1326 ;	keyboards/ajazz/ak820/ak820_tapping.c:167: if (pressed) {
      004BD8 90 06 7D         [24] 1327 	mov	dptr,#_ak820_oneshot_process_PARM_3
      004BDB E0               [24] 1328 	movx	a,@dptr
      004BDC 60 2D            [24] 1329 	jz	00113$
                                   1330 ;	keyboards/ajazz/ak820/ak820_tapping.c:168: source_state[id] |= SOURCE_ONESHOT;
      004BDE 12 4C D3         [24] 1331 	lcall	_ak820_outline_0020
      004BE1 43 04 08         [24] 1332 	orl	ar4,#0x08
      004BE4 12 43 08         [24] 1333 	lcall	_ak820_outline_0066
                                   1334 ;	keyboards/ajazz/ak820/ak820_tapping.c:169: source_state[id] &= ~SOURCE_ONESHOT_USED;
      004BE7 53 04 EF         [24] 1335 	anl	ar4,#0xef
      004BEA 12 43 08         [24] 1336 	lcall	_ak820_outline_0066
                                   1337 ;	keyboards/ajazz/ak820/ak820_tapping.c:170: if (ak820_oneshot_target != NONE) source_state[id] |= SOURCE_ONESHOT_USED;
      004BED 90 0D D6         [24] 1338 	mov	dptr,#_ak820_oneshot_target
      004BF0 E0               [24] 1339 	movx	a,@dptr
      004BF1 FC               [12] 1340 	mov	r4,a
      004BF2 BC FF 02         [24] 1341 	cjne	r4,#0xff,00256$
      004BF5 80 09            [24] 1342 	sjmp	00107$
      004BF7                       1343 00256$:
      004BF7 12 4D 12         [24] 1344 	lcall	_ak820_outline_0076
      004BFA 43 04 10         [24] 1345 	orl	ar4,#0x10
      004BFD 12 43 08         [24] 1346 	lcall	_ak820_outline_0066
      004C00                       1347 00107$:
                                   1348 ;	keyboards/ajazz/ak820/ak820_tapping.c:171: register_mods(mods);
      004C00 90 06 80         [24] 1349 	mov	dptr,#_ak820_oneshot_process_mods_10000_673
      004C03 E0               [24] 1350 	movx	a,@dptr
      004C04 F5 82            [12] 1351 	mov	dpl,a
      004C06 12 7A 2C         [24] 1352 	lcall	_register_mods
      004C09 80 48            [24] 1353 	sjmp	00114$
      004C0B                       1354 00113$:
                                   1355 ;	keyboards/ajazz/ak820/ak820_tapping.c:172: } else if (source_state[id] & SOURCE_ONESHOT) {
      004C0B 12 4C D3         [24] 1356 	lcall	_ak820_outline_0020
      004C0E 30 E3 42         [24] 1357 	jnb	acc.3,00114$
                                   1358 ;	keyboards/ajazz/ak820/ak820_tapping.c:173: if (!(source_state[id] & SOURCE_ONESHOT_USED)) {
      004C11 EC               [12] 1359 	mov	a,r4
      004C12 20 E4 24         [24] 1360 	jb	acc.4,00109$
                                   1361 ;	keyboards/ajazz/ak820/ak820_tapping.c:174: add_owned_mods(mods & ~ak820_oneshot_mods);
      004C15 90 06 7A         [24] 1362 	mov	dptr,#_ak820_oneshot_mods
      004C18 E0               [24] 1363 	movx	a,@dptr
      004C19 F4               [12] 1364 	cpl	a
      004C1A FC               [12] 1365 	mov	r4,a
      004C1B 90 06 80         [24] 1366 	mov	dptr,#_ak820_oneshot_process_mods_10000_673
      004C1E E0               [24] 1367 	movx	a,@dptr
      004C1F FB               [12] 1368 	mov	r3,a
      004C20 52 04            [12] 1369 	anl	ar4,a
      004C22 8C 82            [24] 1370 	mov	dpl, r4
      004C24 C0 06            [24] 1371 	push	ar6
      004C26 C0 05            [24] 1372 	push	ar5
      004C28 C0 03            [24] 1373 	push	ar3
      004C2A 12 80 75         [24] 1374 	lcall	_add_owned_mods
      004C2D D0 03            [24] 1375 	pop	ar3
      004C2F D0 05            [24] 1376 	pop	ar5
      004C31 D0 06            [24] 1377 	pop	ar6
                                   1378 ;	keyboards/ajazz/ak820/ak820_tapping.c:175: ak820_oneshot_mods |= mods;
      004C33 90 06 7A         [24] 1379 	mov	dptr,#_ak820_oneshot_mods
      004C36 E0               [24] 1380 	movx	a,@dptr
      004C37 4B               [12] 1381 	orl	a,r3
      004C38 F0               [24] 1382 	movx	@dptr,a
      004C39                       1383 00109$:
                                   1384 ;	keyboards/ajazz/ak820/ak820_tapping.c:177: unregister_mods(mods);
      004C39 90 06 80         [24] 1385 	mov	dptr,#_ak820_oneshot_process_mods_10000_673
      004C3C E0               [24] 1386 	movx	a,@dptr
      004C3D F5 82            [12] 1387 	mov	dpl,a
      004C3F C0 06            [24] 1388 	push	ar6
      004C41 C0 05            [24] 1389 	push	ar5
      004C43 12 7A 40         [24] 1390 	lcall	_unregister_mods
      004C46 D0 05            [24] 1391 	pop	ar5
      004C48 D0 06            [24] 1392 	pop	ar6
                                   1393 ;	keyboards/ajazz/ak820/ak820_tapping.c:178: source_state[id] &= ~(SOURCE_ONESHOT | SOURCE_ONESHOT_USED);
      004C4A 12 4D 12         [24] 1394 	lcall	_ak820_outline_0076
      004C4D 53 04 E7         [24] 1395 	anl	ar4,#0xe7
      004C50 12 43 08         [24] 1396 	lcall	_ak820_outline_0066
      004C53                       1397 00114$:
                                   1398 ;	keyboards/ajazz/ak820/ak820_tapping.c:180: return false;
      004C53 75 82 00         [24] 1399 	mov	dpl, #0x00
      004C56 22               [24] 1400 	ret
      004C57                       1401 00116$:
                                   1402 ;	keyboards/ajazz/ak820/ak820_tapping.c:182: if (pressed && code > KC_TRANSPARENT &&
      004C57 90 06 7D         [24] 1403 	mov	dptr,#_ak820_oneshot_process_PARM_3
      004C5A E0               [24] 1404 	movx	a,@dptr
      004C5B 60 5C            [24] 1405 	jz	00124$
      004C5D 90 06 7E         [24] 1406 	mov	dptr,#_ak820_oneshot_process_code_10000_672
      004C60 12 43 22         [24] 1407 	lcall	_ak820_outline_0096
      004C63 C3               [12] 1408 	clr	c
      004C64 74 01            [12] 1409 	mov	a,#0x01
      004C66 9D               [12] 1410 	subb	a,r5
      004C67 E4               [12] 1411 	clr	a
      004C68 9E               [12] 1412 	subb	a,r6
      004C69 50 4E            [24] 1413 	jnc	00124$
                                   1414 ;	free result
                                   1415 ;	keyboards/ajazz/ak820/ak820_tapping.c:183: !(code >= KC_LCTL && code <= KC_RGUI) &&
      004C6B C3               [12] 1416 	clr	c
      004C6C ED               [12] 1417 	mov	a,r5
      004C6D 94 E0            [12] 1418 	subb	a,#0xe0
      004C6F EE               [12] 1419 	mov	a,r6
      004C70 94 00            [12] 1420 	subb	a,#0x00
      004C72 40 07            [24] 1421 	jc	00129$
      004C74 74 E7            [12] 1422 	mov	a,#0xe7
      004C76 9D               [12] 1423 	subb	a,r5
      004C77 E4               [12] 1424 	clr	a
      004C78 9E               [12] 1425 	subb	a,r6
      004C79 50 3E            [24] 1426 	jnc	00124$
                                   1427 ;	free result
      004C7B                       1428 00129$:
                                   1429 ;	keyboards/ajazz/ak820/ak820_tapping.c:184: !(code >= QK_TO && code <= QK_LAYER_TAP_TOGGLE_MAX)) {
      004C7B 74 AE            [12] 1430 	mov	a,#0x100 - 0x52
      004C7D 2E               [12] 1431 	add	a,r6
      004C7E 50 09            [24] 1432 	jnc	00165$
      004C80 C3               [12] 1433 	clr	c
      004C81 74 DF            [12] 1434 	mov	a,#0xdf
      004C83 9D               [12] 1435 	subb	a,r5
      004C84 74 52            [12] 1436 	mov	a,#0x52
      004C86 9E               [12] 1437 	subb	a,r6
      004C87 50 30            [24] 1438 	jnc	00124$
                                   1439 ;	free result
                                   1440 ;	keyboards/ajazz/ak820/ak820_tapping.c:185: for (uint8_t i = 0; i < SOURCES; ++i)
      004C89                       1441 00165$:
      004C89 7E 00            [12] 1442 	mov	r6,#0x00
      004C8B                       1443 00131$:
      004C8B BE 82 00         [24] 1444 	cjne	r6,#0x82,00265$
      004C8E                       1445 00265$:
      004C8E 50 12            [24] 1446 	jnc	00120$
                                   1447 ;	keyboards/ajazz/ak820/ak820_tapping.c:186: if (source_state[i] & SOURCE_ONESHOT) source_state[i] |= SOURCE_ONESHOT_USED;
      004C90 EE               [12] 1448 	mov	a,r6
      004C91 12 4D 19         [24] 1449 	lcall	_ak820_outline_0079
      004C94 30 E3 08         [24] 1450 	jnb	acc.3,00132$
      004C97 43 03 10         [24] 1451 	orl	ar3,#0x10
      004C9A 12 38 65         [24] 1452 	lcall	_ak820_outline_0125
      004C9D EB               [12] 1453 	mov	a,r3
      004C9E F0               [24] 1454 	movx	@dptr,a
      004C9F                       1455 00132$:
                                   1456 ;	keyboards/ajazz/ak820/ak820_tapping.c:185: for (uint8_t i = 0; i < SOURCES; ++i)
      004C9F 0E               [12] 1457 	inc	r6
      004CA0 80 E9            [24] 1458 	sjmp	00131$
      004CA2                       1459 00120$:
                                   1460 ;	keyboards/ajazz/ak820/ak820_tapping.c:187: if (ak820_oneshot_mods) {
      004CA2 90 06 7A         [24] 1461 	mov	dptr,#_ak820_oneshot_mods
      004CA5 E0               [24] 1462 	movx	a,@dptr
      004CA6 FE               [12] 1463 	mov	r6,a
      004CA7 E0               [24] 1464 	movx	a,@dptr
      004CA8 60 0F            [24] 1465 	jz	00124$
                                   1466 ;	keyboards/ajazz/ak820/ak820_tapping.c:188: ak820_oneshot_consumed = ak820_oneshot_mods;
      004CAA 90 06 7B         [24] 1467 	mov	dptr,#_ak820_oneshot_consumed
      004CAD EE               [12] 1468 	mov	a,r6
      004CAE F0               [24] 1469 	movx	@dptr,a
                                   1470 ;	keyboards/ajazz/ak820/ak820_tapping.c:189: ak820_oneshot_target = id;
      004CAF 90 0D D6         [24] 1471 	mov	dptr,#_ak820_oneshot_target
      004CB2 EF               [12] 1472 	mov	a,r7
      004CB3 F0               [24] 1473 	movx	@dptr,a
                                   1474 ;	keyboards/ajazz/ak820/ak820_tapping.c:190: ak820_oneshot_mods = 0;
      004CB4 90 06 7A         [24] 1475 	mov	dptr,#_ak820_oneshot_mods
      004CB7 E4               [12] 1476 	clr	a
      004CB8 F0               [24] 1477 	movx	@dptr,a
      004CB9                       1478 00124$:
                                   1479 ;	keyboards/ajazz/ak820/ak820_tapping.c:193: return true;
      004CB9 75 82 01         [24] 1480 	mov	dpl, #0x01
                                   1481 ;	keyboards/ajazz/ak820/ak820_tapping.c:194: }
      004CBC 22               [24] 1482 	ret
                                   1483 	.area CSEG    (CODE)
                                   1484 	.area CONST   (CODE)
                                   1485 	.area XINIT   (CODE)
      00C5C9                       1486 __xinit__pending:
      00C5C9 FF                    1487 	.db #0xff	; 255
      00C5CA                       1488 __xinit__ak820_oneshot_target:
      00C5CA FF                    1489 	.db #0xff	; 255
                                   1490 	.area CABS    (ABS,CODE)
                                   1491 
                                   1492 ; Experimental exact instruction outlining.
                                   1493 	.globl _ak820_outline_0004
                                   1494 	.globl _ak820_outline_0005
                                   1495 	.globl _ak820_outline_0010
                                   1496 	.globl _ak820_outline_0011
                                   1497 	.globl _ak820_outline_0012
                                   1498 	.globl _ak820_outline_0013
                                   1499 	.globl _ak820_outline_0014
                                   1500 	.globl _ak820_outline_0017
                                   1501 	.globl _ak820_outline_0020
                                   1502 	.globl _ak820_outline_0024
                                   1503 	.globl _ak820_outline_0031
                                   1504 	.globl _ak820_outline_0034
                                   1505 	.globl _ak820_outline_0051
                                   1506 	.globl _ak820_outline_0055
                                   1507 	.globl _ak820_outline_0056
                                   1508 	.globl _ak820_outline_0060
                                   1509 	.globl _ak820_outline_0061
                                   1510 	.globl _ak820_outline_0066
                                   1511 	.globl _ak820_outline_0076
                                   1512 	.globl _ak820_outline_0079
                                   1513 	.globl _ak820_outline_0096
                                   1514 	.globl _ak820_outline_0100
                                   1515 	.globl _ak820_outline_0106
                                   1516 	.globl _ak820_outline_0107
                                   1517 	.globl _ak820_outline_0121
                                   1518 	.globl _ak820_outline_0125
                                   1519 	.globl _ak820_outline_0126
                                   1520 	.globl _ak820_outline_0136
                                   1521 	.globl _ak820_outline_0139
                                   1522 	.globl _ak820_outline_0159
                                   1523 	.globl _ak820_outline_0161
                                   1524 	.globl _ak820_outline_0189
                                   1525 	.globl _ak820_outline_0193
                                   1526 
                                   1527 	.area CSEG (CODE)
                                   1528 ; function ak820_outline_0012
      004CBD                       1529 _ak820_outline_0012:
      004CBD 2E               [12] 1530 	add	a,r6
      004CBE FB               [12] 1531 	mov	r3,a
      004CBF E4               [12] 1532 	clr	a
      004CC0 3F               [12] 1533 	addc	a,r7
      004CC1 FC               [12] 1534 	mov	r4,a
      004CC2 8B 82            [24] 1535 	mov	dpl,r3
      004CC4 8C 83            [24] 1536 	mov	dph,r4
      004CC6 E0               [24] 1537 	movx	a,@dptr
      004CC7 22               [24] 1538 	ret
                                   1539 
                                   1540 	.area CSEG (CODE)
                                   1541 ; function ak820_outline_0013
      004CC8                       1542 _ak820_outline_0013:
      004CC8 2E               [12] 1543 	add	a,r6
      004CC9 FC               [12] 1544 	mov	r4,a
      004CCA E4               [12] 1545 	clr	a
      004CCB 3F               [12] 1546 	addc	a,r7
      004CCC FD               [12] 1547 	mov	r5,a
      004CCD 8C 82            [24] 1548 	mov	dpl,r4
      004CCF 8D 83            [24] 1549 	mov	dph,r5
      004CD1 E0               [24] 1550 	movx	a,@dptr
      004CD2 22               [24] 1551 	ret
                                   1552 
                                   1553 	.area CSEG (CODE)
                                   1554 ; function ak820_outline_0020
      004CD3                       1555 _ak820_outline_0020:
      004CD3 EF               [12] 1556 	mov	a,r7
      004CD4 24 E6            [12] 1557 	add	a,#_source_state
      004CD6 FD               [12] 1558 	mov	r5,a
      004CD7 E4               [12] 1559 	clr	a
      004CD8 34 05            [12] 1560 	addc	a,#(_source_state>>8)
      004CDA FE               [12] 1561 	mov	r6,a
      004CDB 8D 82            [24] 1562 	mov	dpl,r5
      004CDD 8E 83            [24] 1563 	mov	dph,r6
      004CDF E0               [24] 1564 	movx	a,@dptr
      004CE0 FC               [12] 1565 	mov	r4,a
      004CE1 22               [24] 1566 	ret
                                   1567 
                                   1568 	.area CSEG (CODE)
                                   1569 ; function ak820_outline_0024
      004CE2                       1570 _ak820_outline_0024:
      004CE2 90 0D BD         [24] 1571 	mov	dptr,#___memcpy_PARM_2
      004CE5 EC               [12] 1572 	mov	a,r4
      004CE6 F0               [24] 1573 	movx	@dptr,a
      004CE7 ED               [12] 1574 	mov	a,r5
      004CE8 A3               [24] 1575 	inc	dptr
      004CE9 F0               [24] 1576 	movx	@dptr,a
      004CEA E4               [12] 1577 	clr	a
      004CEB A3               [24] 1578 	inc	dptr
      004CEC F0               [24] 1579 	movx	@dptr,a
      004CED 90 0D C0         [24] 1580 	mov	dptr,#___memcpy_PARM_3
      004CF0 74 02            [12] 1581 	mov	a,#0x02
      004CF2 F0               [24] 1582 	movx	@dptr,a
      004CF3 E4               [12] 1583 	clr	a
      004CF4 A3               [24] 1584 	inc	dptr
      004CF5 F0               [24] 1585 	movx	@dptr,a
      004CF6 90 06 6C         [24] 1586 	mov	dptr,#_ak820_tapping_source_PARM_1
      004CF9 F5 F0            [12] 1587 	mov	b,a
      004CFB 22               [24] 1588 	ret
                                   1589 
                                   1590 	.area CSEG (CODE)
                                   1591 ; function ak820_outline_0055
      004CFC                       1592 _ak820_outline_0055:
      004CFC 74 01            [12] 1593 	mov	a,#0x01
      004CFE F0               [24] 1594 	movx	@dptr,a
      004CFF 8E 82            [24] 1595 	mov	dpl,r6
      004D01 8F 83            [24] 1596 	mov	dph,r7
      004D03 22               [24] 1597 	ret
                                   1598 
                                   1599 	.area CSEG (CODE)
                                   1600 ; function ak820_outline_0056
      004D04                       1601 _ak820_outline_0056:
      004D04 FC               [12] 1602 	mov	r4,a
      004D05 8B 82            [24] 1603 	mov	dpl,r3
      004D07 8C 83            [24] 1604 	mov	dph,r4
      004D09 E0               [24] 1605 	movx	a,@dptr
      004D0A FA               [12] 1606 	mov	r2,a
      004D0B 22               [24] 1607 	ret
                                   1608 
                                   1609 	.area CSEG (CODE)
                                   1610 ; function ak820_outline_0060
      004D0C                       1611 _ak820_outline_0060:
      004D0C EE               [12] 1612 	mov	a,r6
      004D0D F0               [24] 1613 	movx	@dptr,a
      004D0E EF               [12] 1614 	mov	a,r7
      004D0F A3               [24] 1615 	inc	dptr
      004D10 F0               [24] 1616 	movx	@dptr,a
      004D11 22               [24] 1617 	ret
                                   1618 
                                   1619 	.area CSEG (CODE)
                                   1620 ; function ak820_outline_0076
      004D12                       1621 _ak820_outline_0076:
      004D12 8D 82            [24] 1622 	mov	dpl,r5
      004D14 8E 83            [24] 1623 	mov	dph,r6
      004D16 E0               [24] 1624 	movx	a,@dptr
      004D17 FC               [12] 1625 	mov	r4,a
      004D18 22               [24] 1626 	ret
                                   1627 
                                   1628 	.area CSEG (CODE)
                                   1629 ; function ak820_outline_0079
      004D19                       1630 _ak820_outline_0079:
      004D19 24 E6            [12] 1631 	add	a,#_source_state
      004D1B FC               [12] 1632 	mov	r4,a
      004D1C E4               [12] 1633 	clr	a
      004D1D 34 05            [12] 1634 	addc	a,#(_source_state>>8)
      004D1F FD               [12] 1635 	mov	r5,a
      004D20 8C 82            [24] 1636 	mov	dpl,r4
      004D22 8D 83            [24] 1637 	mov	dph,r5
      004D24 E0               [24] 1638 	movx	a,@dptr
      004D25 FB               [12] 1639 	mov	r3,a
      004D26 22               [24] 1640 	ret
                                   1641 
                                   1642 	.area CSEG (CODE)
                                   1643 ; function ak820_outline_0139
      004D27                       1644 _ak820_outline_0139:
      004D27 E9               [12] 1645 	mov	a,r1
      004D28 F0               [24] 1646 	movx	@dptr,a
      004D29 EA               [12] 1647 	mov	a,r2
      004D2A A3               [24] 1648 	inc	dptr
      004D2B F0               [24] 1649 	movx	@dptr,a
      004D2C 22               [24] 1650 	ret
                                   1651 
                                   1652 	.area CSEG (CODE)
                                   1653 ; function ak820_outline_0159
      004D2D                       1654 _ak820_outline_0159:
      004D2D 90 0D D5         [24] 1655 	mov	dptr,#_pending
      004D30 74 FF            [12] 1656 	mov	a,#0xff
      004D32 F0               [24] 1657 	movx	@dptr,a
      004D33 22               [24] 1658 	ret
                                   1659 
                                   1660 	.area CSEG (CODE)
                                   1661 ; function ak820_outline_0189
      004D34                       1662 _ak820_outline_0189:
      004D34 A9 82            [24] 1663 	mov	r1,dpl
      004D36 AA 83            [24] 1664 	mov	r2,dph
      004D38 22               [24] 1665 	ret
