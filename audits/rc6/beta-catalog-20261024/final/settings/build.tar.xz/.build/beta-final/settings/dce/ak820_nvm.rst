                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_nvm
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _eeprom_driver_erase
                                     12 	.globl _eeprom_read_byte
                                     13 	.globl _eeprom_driver_init
                                     14 	.globl _ak820_macro_init
                                     15 	.globl _ak820_flash_program_page
                                     16 	.globl _ak820_flash_program
                                     17 	.globl _ak820_flash_erase
                                     18 	.globl _ak820_flash_read
                                     19 	.globl _ak820_eeprom_update_block_xdata_PARM_3
                                     20 	.globl _ak820_eeprom_update_block_xdata_PARM_2
                                     21 	.globl _ak820_eeprom_write_block_xdata_PARM_3
                                     22 	.globl _ak820_eeprom_write_block_xdata_PARM_2
                                     23 	.globl _ak820_eeprom_read_block_xdata_PARM_3
                                     24 	.globl _ak820_eeprom_read_block_xdata_PARM_2
                                     25 	.globl _ak820_nvm_diagnostic
                                     26 	.globl _ak820_nvm_ok
                                     27 	.globl _ak820_nvm_schema_fault
                                     28 	.globl _ak820_nvm_flush
                                     29 	.globl _ak820_nvm_begin
                                     30 	.globl _ak820_nvm_end
                                     31 	.globl _ak820_eeprom_read_block_xdata
                                     32 	.globl _ak820_eeprom_write_block_xdata
                                     33 	.globl _ak820_eeprom_update_block_xdata
                                     34 ;--------------------------------------------------------
                                     35 ; special function registers
                                     36 ;--------------------------------------------------------
                                     37 	.area RSEG    (ABS,DATA)
      000000                         38 	.org 0x0000
                                     39 ;--------------------------------------------------------
                                     40 ; special function bits
                                     41 ;--------------------------------------------------------
                                     42 	.area RSEG    (ABS,DATA)
      000000                         43 	.org 0x0000
                                     44 ;--------------------------------------------------------
                                     45 ; overlayable register banks
                                     46 ;--------------------------------------------------------
                                     47 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         48 	.ds 8
                                     49 ;--------------------------------------------------------
                                     50 ; overlayable bit register bank
                                     51 ;--------------------------------------------------------
                                     52 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         53 bits:
      000026                         54 	.ds 1
                           008000    55 	b0 = bits[0]
                           008100    56 	b1 = bits[1]
                           008200    57 	b2 = bits[2]
                           008300    58 	b3 = bits[3]
                           008400    59 	b4 = bits[4]
                           008500    60 	b5 = bits[5]
                           008600    61 	b6 = bits[6]
                           008700    62 	b7 = bits[7]
                                     63 ;--------------------------------------------------------
                                     64 ; internal ram data
                                     65 ;--------------------------------------------------------
                                     66 	.area DSEG    (DATA)
      00000C                         67 _ak820_eeprom_write_block_xdata_sloc0_1_0:
      00000C                         68 	.ds 2
      00000E                         69 _ak820_eeprom_update_block_xdata_sloc0_1_0:
      00000E                         70 	.ds 2
      000010                         71 _ak820_eeprom_update_block_xdata_sloc1_1_0:
      000010                         72 	.ds 2
      000012                         73 _ak820_eeprom_update_block_xdata_sloc2_1_0:
      000012                         74 	.ds 3
                                     75 ;--------------------------------------------------------
                                     76 ; overlayable items in internal ram
                                     77 ;--------------------------------------------------------
                                     78 ;--------------------------------------------------------
                                     79 ; indirectly addressable internal ram data
                                     80 ;--------------------------------------------------------
                                     81 	.area ISEG    (DATA)
                                     82 ;--------------------------------------------------------
                                     83 ; absolute internal ram data
                                     84 ;--------------------------------------------------------
                                     85 	.area IABS    (ABS,DATA)
                                     86 	.area IABS    (ABS,DATA)
                                     87 ;--------------------------------------------------------
                                     88 ; bit data
                                     89 ;--------------------------------------------------------
                                     90 	.area BSEG    (BIT)
      000007                         91 _page_valid:
      000007                         92 	.ds 1
      000008                         93 _page_dirty:
      000008                         94 	.ds 1
      000009                         95 _storage_failed:
      000009                         96 	.ds 1
      00000A                         97 _ak820_nvm_ok_sloc0_1_0:
      00000A                         98 	.ds 1
      00000B                         99 _load_page_sloc0_1_0:
      00000B                        100 	.ds 1
                                    101 ;--------------------------------------------------------
                                    102 ; paged external ram data
                                    103 ;--------------------------------------------------------
                                    104 	.area PSEG    (PAG,XDATA)
                                    105 ;--------------------------------------------------------
                                    106 ; uninitialized external ram data
                                    107 ;--------------------------------------------------------
                                    108 	.area XSEG    (XDATA)
      000519                        109 _page_data:
      000519                        110 	.ds 64
      000559                        111 _cached_page:
      000559                        112 	.ds 1
      00055A                        113 _batch_depth:
      00055A                        114 	.ds 1
      00055B                        115 _first_failure_stage:
      00055B                        116 	.ds 1
      00055C                        117 _nvm_fail_stage_10000_20:
      00055C                        118 	.ds 1
      00055D                        119 _ak820_nvm_diagnostic_out_10000_23:
      00055D                        120 	.ds 2
      00055F                        121 _crc_byte_PARM_2:
      00055F                        122 	.ds 1
      000560                        123 _crc_byte_crc_10000_25:
      000560                        124 	.ds 2
      000562                        125 _page_crc_crc_10000_30:
      000562                        126 	.ds 2
      000564                        127 _write_page_address_10000_32:
      000564                        128 	.ds 2
      000566                        129 _journal_header_valid_header_10000_39:
      000566                        130 	.ds 2
      000568                        131 _recover_journal_header_10000_46:
      000568                        132 	.ds 9
      000571                        133 _ak820_nvm_flush_header_10000_62:
      000571                        134 	.ds 9
      00057A                        135 _ak820_nvm_flush_stage_10000_62:
      00057A                        136 	.ds 1
      00057B                        137 _load_page_page_10000_87:
      00057B                        138 	.ds 1
      00057C                        139 _read_offset_offset_10000_93:
      00057C                        140 	.ds 2
      00057E                        141 _eeprom_read_byte_addr_10000_97:
      00057E                        142 	.ds 3
      000581                        143 _ak820_eeprom_read_block_xdata_PARM_2:
      000581                        144 	.ds 3
      000584                        145 _ak820_eeprom_read_block_xdata_PARM_3:
      000584                        146 	.ds 2
      000586                        147 _ak820_eeprom_read_block_xdata_buf_10000_113:
      000586                        148 	.ds 2
      000588                        149 _ak820_eeprom_read_block_xdata_out_10000_114:
      000588                        150 	.ds 2
      00058A                        151 _ak820_eeprom_write_block_xdata_PARM_2:
      00058A                        152 	.ds 3
      00058D                        153 _ak820_eeprom_write_block_xdata_PARM_3:
      00058D                        154 	.ds 2
      00058F                        155 _ak820_eeprom_write_block_xdata_buf_10000_118:
      00058F                        156 	.ds 2
      000591                        157 _ak820_eeprom_update_block_xdata_PARM_2:
      000591                        158 	.ds 3
      000594                        159 _ak820_eeprom_update_block_xdata_PARM_3:
      000594                        160 	.ds 2
      000596                        161 _ak820_eeprom_update_block_xdata_buf_10000_127:
      000596                        162 	.ds 2
                                    163 ;--------------------------------------------------------
                                    164 ; absolute external ram data
                                    165 ;--------------------------------------------------------
                                    166 	.area XABS    (ABS,XDATA)
                                    167 ;--------------------------------------------------------
                                    168 ; initialized external ram data
                                    169 ;--------------------------------------------------------
                                    170 	.area XISEG   (XDATA)
                                    171 	.area HOME    (CODE)
                                    172 	.area GSINIT0 (CODE)
                                    173 	.area GSINIT1 (CODE)
                                    174 	.area GSINIT2 (CODE)
                                    175 	.area GSINIT3 (CODE)
                                    176 	.area GSINIT4 (CODE)
                                    177 	.area GSINIT5 (CODE)
                                    178 	.area GSINIT  (CODE)
                                    179 	.area GSFINAL (CODE)
                                    180 	.area CSEG    (CODE)
                                    181 ;--------------------------------------------------------
                                    182 ; global & static initialisations
                                    183 ;--------------------------------------------------------
                                    184 	.area HOME    (CODE)
                                    185 	.area GSINIT  (CODE)
                                    186 	.area GSFINAL (CODE)
                                    187 	.area GSINIT  (CODE)
                                    188 ;--------------------------------------------------------
                                    189 ; Home
                                    190 ;--------------------------------------------------------
                                    191 	.area HOME    (CODE)
                                    192 	.area HOME    (CODE)
                                    193 ;--------------------------------------------------------
                                    194 ; code
                                    195 ;--------------------------------------------------------
                                    196 	.area CSEG    (CODE)
                                    197 ;------------------------------------------------------------
                                    198 ;Allocation info for local variables in function 'nvm_fail'
                                    199 ;------------------------------------------------------------
                                    200 ;stage         Allocated with name '_nvm_fail_stage_10000_20'
                                    201 ;------------------------------------------------------------
                                    202 ;	keyboards/ajazz/ak820/ak820_nvm.c:31: static void nvm_fail(uint8_t stage) {
                                    203 ;	-----------------------------------------
                                    204 ;	 function nvm_fail
                                    205 ;	-----------------------------------------
      003B48                        206 _nvm_fail:
                           000007   207 	ar7 = 0x07
                           000006   208 	ar6 = 0x06
                           000005   209 	ar5 = 0x05
                           000004   210 	ar4 = 0x04
                           000003   211 	ar3 = 0x03
                           000002   212 	ar2 = 0x02
                           000001   213 	ar1 = 0x01
                           000000   214 	ar0 = 0x00
      003B48 E5 82            [12]  215 	mov	a,dpl
      003B4A 90 05 5C         [24]  216 	mov	dptr,#_nvm_fail_stage_10000_20
      003B4D F0               [24]  217 	movx	@dptr,a
                                    218 ;	keyboards/ajazz/ak820/ak820_nvm.c:32: if (!storage_failed) first_failure_stage = stage;
      003B4E 20 09 08         [24]  219 	jb	_storage_failed,00102$
      003B51 90 05 5C         [24]  220 	mov	dptr,#_nvm_fail_stage_10000_20
      003B54 E0               [24]  221 	movx	a,@dptr
      003B55 90 05 5B         [24]  222 	mov	dptr,#_first_failure_stage
      003B58 F0               [24]  223 	movx	@dptr,a
      003B59                        224 00102$:
                                    225 ;	keyboards/ajazz/ak820/ak820_nvm.c:33: storage_failed = true;
                                    226 ;	assignBit
      003B59 D2 09            [12]  227 	setb	_storage_failed
                                    228 ;	keyboards/ajazz/ak820/ak820_nvm.c:34: }
      003B5B 22               [24]  229 	ret
                                    230 ;------------------------------------------------------------
                                    231 ;Allocation info for local variables in function 'ak820_nvm_diagnostic'
                                    232 ;------------------------------------------------------------
                                    233 ;out           Allocated with name '_ak820_nvm_diagnostic_out_10000_23'
                                    234 ;------------------------------------------------------------
                                    235 ;	keyboards/ajazz/ak820/ak820_nvm.c:36: void ak820_nvm_diagnostic(uint8_t AK820_XDATA *out) {
                                    236 ;	-----------------------------------------
                                    237 ;	 function ak820_nvm_diagnostic
                                    238 ;	-----------------------------------------
      003B5C                        239 _ak820_nvm_diagnostic:
      003B5C 12 38 52         [24]  240 	lcall	_ak820_outline_0106
      003B5F 90 05 5D         [24]  241 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003B62 12 38 57         [24]  242 	lcall	_ak820_outline_0107
                                    243 ;	keyboards/ajazz/ak820/ak820_nvm.c:37: out[0] = storage_failed;
      003B65 90 05 5D         [24]  244 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003B68 12 37 FC         [24]  245 	lcall	_ak820_outline_0051
      003B6B A2 09            [12]  246 	mov	c,_storage_failed
      003B6D E4               [12]  247 	clr	a
      003B6E 33               [12]  248 	rlc	a
      003B6F 12 43 2B         [24]  249 	lcall	_ak820_outline_0121
      003B72 12 42 F9         [24]  250 	lcall	_ak820_outline_0061
                                    251 ;	keyboards/ajazz/ak820/ak820_nvm.c:38: out[1] = page_valid;
      003B75 A3               [24]  252 	inc	dptr
      003B76 A2 07            [12]  253 	mov	c,_page_valid
      003B78 E4               [12]  254 	clr	a
      003B79 33               [12]  255 	rlc	a
      003B7A 12 42 CD         [24]  256 	lcall	_ak820_outline_0031
                                    257 ;	keyboards/ajazz/ak820/ak820_nvm.c:39: out[2] = page_dirty;
      003B7D A2 08            [12]  258 	mov	c,_page_dirty
      003B7F E4               [12]  259 	clr	a
      003B80 33               [12]  260 	rlc	a
      003B81 F0               [24]  261 	movx	@dptr,a
                                    262 ;	keyboards/ajazz/ak820/ak820_nvm.c:40: out[3] = batch_depth;
      003B82 74 03            [12]  263 	mov	a,#0x03
      003B84 12 43 51         [24]  264 	lcall	_ak820_outline_0164
      003B87 90 05 5A         [24]  265 	mov	dptr,#_batch_depth
      003B8A E0               [24]  266 	movx	a,@dptr
      003B8B 12 38 5C         [24]  267 	lcall	_ak820_outline_0125
      003B8E F0               [24]  268 	movx	@dptr,a
                                    269 ;	keyboards/ajazz/ak820/ak820_nvm.c:41: out[4] = (uint8_t)cached_page;
      003B8F 74 04            [12]  270 	mov	a,#0x04
      003B91 12 43 51         [24]  271 	lcall	_ak820_outline_0164
      003B94 90 05 59         [24]  272 	mov	dptr,#_cached_page
      003B97 E0               [24]  273 	movx	a,@dptr
      003B98 12 38 5C         [24]  274 	lcall	_ak820_outline_0125
      003B9B F0               [24]  275 	movx	@dptr,a
                                    276 ;	keyboards/ajazz/ak820/ak820_nvm.c:42: out[5] = (uint8_t)(cached_page >> 8);
      003B9C 12 42 C3         [24]  277 	lcall	_ak820_outline_0011
      003B9F E4               [12]  278 	clr	a
      003BA0 F0               [24]  279 	movx	@dptr,a
                                    280 ;	keyboards/ajazz/ak820/ak820_nvm.c:43: out[6] = first_failure_stage;
      003BA1 74 06            [12]  281 	mov	a,#0x06
      003BA3 12 43 35         [24]  282 	lcall	_ak820_outline_0138
      003BA6 90 05 5B         [24]  283 	mov	dptr,#_first_failure_stage
      003BA9 12 43 0C         [24]  284 	lcall	_ak820_outline_0094
                                    285 ;	keyboards/ajazz/ak820/ak820_nvm.c:44: }
      003BAC 22               [24]  286 	ret
                                    287 ;------------------------------------------------------------
                                    288 ;Allocation info for local variables in function 'crc_byte'
                                    289 ;------------------------------------------------------------
                                    290 ;value         Allocated with name '_crc_byte_PARM_2'
                                    291 ;crc           Allocated with name '_crc_byte_crc_10000_25'
                                    292 ;bit           Allocated with name '_crc_byte_bit_10000_26'
                                    293 ;------------------------------------------------------------
                                    294 ;	keyboards/ajazz/ak820/ak820_nvm.c:46: static uint16_t crc_byte(uint16_t crc, uint8_t value) {
                                    295 ;	-----------------------------------------
                                    296 ;	 function crc_byte
                                    297 ;	-----------------------------------------
      003BAD                        298 _crc_byte:
      003BAD 12 38 52         [24]  299 	lcall	_ak820_outline_0106
      003BB0 90 05 60         [24]  300 	mov	dptr,#_crc_byte_crc_10000_25
      003BB3 12 38 57         [24]  301 	lcall	_ak820_outline_0107
                                    302 ;	keyboards/ajazz/ak820/ak820_nvm.c:48: crc ^= (uint16_t)value << 8;
      003BB6 90 05 5F         [24]  303 	mov	dptr,#_crc_byte_PARM_2
      003BB9 E0               [24]  304 	movx	a,@dptr
      003BBA FF               [12]  305 	mov	r7,a
      003BBB 7E 00            [12]  306 	mov	r6,#0x00
      003BBD 90 05 60         [24]  307 	mov	dptr,#_crc_byte_crc_10000_25
      003BC0 E0               [24]  308 	movx	a,@dptr
      003BC1 6E               [12]  309 	xrl	a,r6
      003BC2 F0               [24]  310 	movx	@dptr,a
      003BC3 A3               [24]  311 	inc	dptr
      003BC4 E0               [24]  312 	movx	a,@dptr
      003BC5 6F               [12]  313 	xrl	a,r7
      003BC6 F0               [24]  314 	movx	@dptr,a
                                    315 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003BC7 7F 00            [12]  316 	mov	r7,#0x00
      003BC9                        317 00102$:
                                    318 ;	keyboards/ajazz/ak820/ak820_nvm.c:50: crc = (crc & 0x8000u) ? (uint16_t)((crc << 1) ^ 0x1021u) : (uint16_t)(crc << 1);
      003BC9 90 05 60         [24]  319 	mov	dptr,#_crc_byte_crc_10000_25
      003BCC 12 43 19         [24]  320 	lcall	_ak820_outline_0096
      003BCF 30 E7 0E         [24]  321 	jnb	acc.7,00106$
      003BD2 ED               [12]  322 	mov	a,r5
      003BD3 2D               [12]  323 	add	a,r5
      003BD4 FB               [12]  324 	mov	r3,a
      003BD5 EE               [12]  325 	mov	a,r6
      003BD6 33               [12]  326 	rlc	a
      003BD7 FC               [12]  327 	mov	r4,a
      003BD8 63 03 21         [24]  328 	xrl	ar3,#0x21
      003BDB 63 04 10         [24]  329 	xrl	ar4,#0x10
      003BDE 80 06            [24]  330 	sjmp	00107$
      003BE0                        331 00106$:
      003BE0 ED               [12]  332 	mov	a,r5
      003BE1 2D               [12]  333 	add	a,r5
      003BE2 FB               [12]  334 	mov	r3,a
      003BE3 EE               [12]  335 	mov	a,r6
      003BE4 33               [12]  336 	rlc	a
      003BE5 FC               [12]  337 	mov	r4,a
      003BE6                        338 00107$:
      003BE6 90 05 60         [24]  339 	mov	dptr,#_crc_byte_crc_10000_25
      003BE9 12 38 34         [24]  340 	lcall	_ak820_outline_0085
                                    341 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003BEC 0F               [12]  342 	inc	r7
      003BED BF 08 D9         [24]  343 	cjne	r7,#0x08,00102$
                                    344 ;	keyboards/ajazz/ak820/ak820_nvm.c:52: return crc;
      003BF0 12 33 FC         [24]  345 	lcall	_ak820_outline_0126
                                    346 ;	keyboards/ajazz/ak820/ak820_nvm.c:53: }
      003BF3 22               [24]  347 	ret
                                    348 ;------------------------------------------------------------
                                    349 ;Allocation info for local variables in function 'page_crc'
                                    350 ;------------------------------------------------------------
                                    351 ;crc           Allocated with name '_page_crc_crc_10000_30'
                                    352 ;i             Allocated with name '_page_crc_i_10000_30'
                                    353 ;------------------------------------------------------------
                                    354 ;	keyboards/ajazz/ak820/ak820_nvm.c:55: static uint16_t page_crc(void) {
                                    355 ;	-----------------------------------------
                                    356 ;	 function page_crc
                                    357 ;	-----------------------------------------
      003BF4                        358 _page_crc:
                                    359 ;	keyboards/ajazz/ak820/ak820_nvm.c:56: uint16_t crc = 0xFFFFu;
      003BF4 90 05 62         [24]  360 	mov	dptr,#_page_crc_crc_10000_30
      003BF7 74 FF            [12]  361 	mov	a,#0xff
      003BF9 F0               [24]  362 	movx	@dptr,a
      003BFA A3               [24]  363 	inc	dptr
      003BFB F0               [24]  364 	movx	@dptr,a
                                    365 ;	keyboards/ajazz/ak820/ak820_nvm.c:58: for (i = 0; i != AK820_FLASH_PAGE; ++i) crc = crc_byte(crc, page_data[i]);
      003BFC 7F 00            [12]  366 	mov	r7,#0x00
      003BFE                        367 00102$:
      003BFE 90 05 62         [24]  368 	mov	dptr,#_page_crc_crc_10000_30
      003C01 12 43 19         [24]  369 	lcall	_ak820_outline_0096
      003C04 12 43 1F         [24]  370 	lcall	_ak820_outline_0110
      003C07 90 05 5F         [24]  371 	mov	dptr,#_crc_byte_PARM_2
      003C0A F0               [24]  372 	movx	@dptr,a
      003C0B 12 38 66         [24]  373 	lcall	_ak820_outline_0136
      003C0E C0 07            [24]  374 	push	ar7
      003C10 12 3B AD         [24]  375 	lcall	_crc_byte
      003C13 12 43 61         [24]  376 	lcall	_ak820_outline_0192
      003C16 D0 07            [24]  377 	pop	ar7
      003C18 90 05 62         [24]  378 	mov	dptr,#_page_crc_crc_10000_30
      003C1B 12 43 3B         [24]  379 	lcall	_ak820_outline_0140
      003C1E 0F               [12]  380 	inc	r7
      003C1F BF 40 DC         [24]  381 	cjne	r7,#0x40,00102$
                                    382 ;	keyboards/ajazz/ak820/ak820_nvm.c:59: return crc;
      003C22 12 38 66         [24]  383 	lcall	_ak820_outline_0136
                                    384 ;	keyboards/ajazz/ak820/ak820_nvm.c:60: }
      003C25 22               [24]  385 	ret
                                    386 ;------------------------------------------------------------
                                    387 ;Allocation info for local variables in function 'write_page'
                                    388 ;------------------------------------------------------------
                                    389 ;address       Allocated with name '_write_page_address_10000_32'
                                    390 ;i             Allocated with name '_write_page_i_10000_33'
                                    391 ;------------------------------------------------------------
                                    392 ;	keyboards/ajazz/ak820/ak820_nvm.c:62: static bool write_page(uint16_t address) {
                                    393 ;	-----------------------------------------
                                    394 ;	 function write_page
                                    395 ;	-----------------------------------------
      003C26                        396 _write_page:
      003C26 12 38 52         [24]  397 	lcall	_ak820_outline_0106
      003C29 90 05 64         [24]  398 	mov	dptr,#_write_page_address_10000_32
      003C2C 12 38 57         [24]  399 	lcall	_ak820_outline_0107
                                    400 ;	keyboards/ajazz/ak820/ak820_nvm.c:64: if (!ak820_flash_erase(address)) return false;
      003C2F 90 05 64         [24]  401 	mov	dptr,#_write_page_address_10000_32
      003C32 12 37 A5         [24]  402 	lcall	_ak820_outline_0004
      003C35 C0 07            [24]  403 	push	ar7
      003C37 C0 06            [24]  404 	push	ar6
      003C39 12 39 C1         [24]  405 	lcall	_ak820_flash_erase
      003C3C E5 82            [12]  406 	mov	a, dpl
      003C3E D0 06            [24]  407 	pop	ar6
      003C40 D0 07            [24]  408 	pop	ar7
      003C42 70 03            [24]  409 	jnz	00102$
      003C44 F5 82            [12]  410 	mov	dpl,a
      003C46 22               [24]  411 	ret
      003C47                        412 00102$:
                                    413 ;	keyboards/ajazz/ak820/ak820_nvm.c:65: if (!ak820_flash_program_page(address, page_data)) return false;
      003C47 90 04 F5         [24]  414 	mov	dptr,#_ak820_flash_program_page_PARM_2
      003C4A 74 19            [12]  415 	mov	a,#_page_data
      003C4C F0               [24]  416 	movx	@dptr,a
      003C4D 74 05            [12]  417 	mov	a,#(_page_data >> 8)
      003C4F A3               [24]  418 	inc	dptr
      003C50 12 42 F9         [24]  419 	lcall	_ak820_outline_0061
      003C53 12 3A D5         [24]  420 	lcall	_ak820_flash_program_page
      003C56 E5 82            [12]  421 	mov	a, dpl
      003C58 70 03            [24]  422 	jnz	00120$
      003C5A F5 82            [12]  423 	mov	dpl,a
                                    424 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003C5C 22               [24]  425 	ret
      003C5D                        426 00120$:
      003C5D 7F 00            [12]  427 	mov	r7,#0x00
      003C5F                        428 00108$:
                                    429 ;	keyboards/ajazz/ak820/ak820_nvm.c:67: if (ak820_flash_read(address + i) != page_data[i]) return false;
      003C5F 8F 05            [24]  430 	mov	ar5,r7
      003C61 7E 00            [12]  431 	mov	r6,#0x00
      003C63 90 05 64         [24]  432 	mov	dptr,#_write_page_address_10000_32
      003C66 12 38 4C         [24]  433 	lcall	_ak820_outline_0105
      003C69 ED               [12]  434 	mov	a,r5
      003C6A 2B               [12]  435 	add	a, r3
      003C6B FB               [12]  436 	mov	r3,a
      003C6C EE               [12]  437 	mov	a,r6
      003C6D 3C               [12]  438 	addc	a, r4
      003C6E FC               [12]  439 	mov	r4,a
      003C6F 12 33 FC         [24]  440 	lcall	_ak820_outline_0126
      003C72 12 38 B4         [24]  441 	lcall	_ak820_flash_read
      003C75 AE 82            [24]  442 	mov	r6, dpl
      003C77 12 43 1F         [24]  443 	lcall	_ak820_outline_0110
      003C7A FD               [12]  444 	mov	r5,a
      003C7B EE               [12]  445 	mov	a,r6
      003C7C B5 05 02         [24]  446 	cjne	a,ar5,00149$
      003C7F 80 04            [24]  447 	sjmp	00109$
      003C81                        448 00149$:
      003C81 75 82 00         [24]  449 	mov	dpl, #0x00
      003C84 22               [24]  450 	ret
      003C85                        451 00109$:
                                    452 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003C85 0F               [12]  453 	inc	r7
      003C86 BF 40 D6         [24]  454 	cjne	r7,#0x40,00108$
                                    455 ;	keyboards/ajazz/ak820/ak820_nvm.c:69: return true;
      003C89 75 82 01         [24]  456 	mov	dpl, #0x01
                                    457 ;	keyboards/ajazz/ak820/ak820_nvm.c:70: }
      003C8C 22               [24]  458 	ret
                                    459 ;------------------------------------------------------------
                                    460 ;Allocation info for local variables in function 'journal_header_valid'
                                    461 ;------------------------------------------------------------
                                    462 ;header        Allocated with name '_journal_header_valid_header_10000_39'
                                    463 ;i             Allocated with name '_journal_header_valid_i_10000_40'
                                    464 ;------------------------------------------------------------
                                    465 ;	keyboards/ajazz/ak820/ak820_nvm.c:72: static bool journal_header_valid(uint8_t AK820_XDATA *header) {
                                    466 ;	-----------------------------------------
                                    467 ;	 function journal_header_valid
                                    468 ;	-----------------------------------------
      003C8D                        469 _journal_header_valid:
      003C8D 12 38 52         [24]  470 	lcall	_ak820_outline_0106
      003C90 90 05 66         [24]  471 	mov	dptr,#_journal_header_valid_header_10000_39
      003C93 12 38 57         [24]  472 	lcall	_ak820_outline_0107
                                    473 ;	keyboards/ajazz/ak820/ak820_nvm.c:74: if (header[0] != 0xA5u) return false;
      003C96 90 05 66         [24]  474 	mov	dptr,#_journal_header_valid_header_10000_39
      003C99 12 37 A5         [24]  475 	lcall	_ak820_outline_0004
      003C9C E0               [24]  476 	movx	a,@dptr
      003C9D FD               [12]  477 	mov	r5,a
      003C9E BD A5 02         [24]  478 	cjne	r5,#0xa5,00138$
      003CA1 80 04            [24]  479 	sjmp	00116$
      003CA3                        480 00138$:
      003CA3 75 82 00         [24]  481 	mov	dpl, #0x00
                                    482 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      003CA6 22               [24]  483 	ret
      003CA7                        484 00116$:
      003CA7 7D 01            [12]  485 	mov	r5,#0x01
      003CA9                        486 00106$:
                                    487 ;	keyboards/ajazz/ak820/ak820_nvm.c:76: if ((uint8_t)(header[i] ^ header[i + 4]) != 0xFFu) return false;
      003CA9 ED               [12]  488 	mov	a,r5
      003CAA 12 37 EC         [24]  489 	lcall	_ak820_outline_0017
      003CAD E0               [24]  490 	movx	a,@dptr
      003CAE FC               [12]  491 	mov	r4,a
      003CAF 8D 02            [24]  492 	mov	ar2,r5
      003CB1 7B 00            [12]  493 	mov	r3,#0x00
      003CB3 74 04            [12]  494 	mov	a,#0x04
      003CB5 2A               [12]  495 	add	a, r2
      003CB6 FA               [12]  496 	mov	r2,a
      003CB7 E4               [12]  497 	clr	a
      003CB8 3B               [12]  498 	addc	a, r3
      003CB9 FB               [12]  499 	mov	r3,a
      003CBA EA               [12]  500 	mov	a,r2
      003CBB 2E               [12]  501 	add	a, r6
      003CBC F5 82            [12]  502 	mov	dpl,a
      003CBE EB               [12]  503 	mov	a,r3
      003CBF 3F               [12]  504 	addc	a, r7
      003CC0 F5 83            [12]  505 	mov	dph,a
      003CC2 E0               [24]  506 	movx	a,@dptr
      003CC3 62 04            [12]  507 	xrl	ar4,a
      003CC5 BC FF 02         [24]  508 	cjne	r4,#0xff,00139$
      003CC8 80 04            [24]  509 	sjmp	00107$
      003CCA                        510 00139$:
      003CCA 75 82 00         [24]  511 	mov	dpl, #0x00
      003CCD 22               [24]  512 	ret
      003CCE                        513 00107$:
                                    514 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      003CCE 0D               [12]  515 	inc	r5
      003CCF BD 05 D7         [24]  516 	cjne	r5,#0x05,00106$
                                    517 ;	keyboards/ajazz/ak820/ak820_nvm.c:78: return true;
      003CD2 75 82 01         [24]  518 	mov	dpl, #0x01
                                    519 ;	keyboards/ajazz/ak820/ak820_nvm.c:79: }
      003CD5 22               [24]  520 	ret
                                    521 ;------------------------------------------------------------
                                    522 ;Allocation info for local variables in function 'recover_journal'
                                    523 ;------------------------------------------------------------
                                    524 ;header        Allocated with name '_recover_journal_header_10000_46'
                                    525 ;i             Allocated with name '_recover_journal_i_10000_46'
                                    526 ;page          Allocated with name '_recover_journal_page_10000_46'
                                    527 ;crc           Allocated with name '_recover_journal_crc_10000_46'
                                    528 ;------------------------------------------------------------
                                    529 ;	keyboards/ajazz/ak820/ak820_nvm.c:81: static void recover_journal(void) {
                                    530 ;	-----------------------------------------
                                    531 ;	 function recover_journal
                                    532 ;	-----------------------------------------
      003CD6                        533 _recover_journal:
                                    534 ;	keyboards/ajazz/ak820/ak820_nvm.c:85: for (i = 0; i != sizeof(header); ++i) header[i] = ak820_flash_read(AK820_JOURNAL_HEADER + i);
      003CD6 7F 00            [12]  535 	mov	r7,#0x00
      003CD8                        536 00115$:
      003CD8 EF               [12]  537 	mov	a,r7
      003CD9 24 68            [12]  538 	add	a, #_recover_journal_header_10000_46
      003CDB FD               [12]  539 	mov	r5,a
      003CDC E4               [12]  540 	clr	a
      003CDD 34 05            [12]  541 	addc	a, #(_recover_journal_header_10000_46 >> 8)
      003CDF FE               [12]  542 	mov	r6,a
      003CE0 8F 04            [24]  543 	mov	ar4,r7
      003CE2 7B 00            [12]  544 	mov	r3,#0x00
      003CE4 74 40            [12]  545 	mov	a,#0x40
      003CE6 2C               [12]  546 	add	a, r4
      003CE7 FC               [12]  547 	mov	r4,a
      003CE8 74 EF            [12]  548 	mov	a,#0xef
      003CEA 3B               [12]  549 	addc	a, r3
      003CEB FB               [12]  550 	mov	r3,a
      003CEC 12 43 57         [24]  551 	lcall	_ak820_outline_0185
      003CEF 12 38 B4         [24]  552 	lcall	_ak820_flash_read
      003CF2 AC 82            [24]  553 	mov	r4, dpl
      003CF4 12 42 FF         [24]  554 	lcall	_ak820_outline_0066
      003CF7 0F               [12]  555 	inc	r7
      003CF8 BF 09 DD         [24]  556 	cjne	r7,#0x09,00115$
                                    557 ;	keyboards/ajazz/ak820/ak820_nvm.c:88: if (!journal_header_valid(header)) return;
      003CFB 90 05 68         [24]  558 	mov	dptr,#_recover_journal_header_10000_46
      003CFE 12 3C 8D         [24]  559 	lcall	_journal_header_valid
      003D01 E5 82            [12]  560 	mov	a, dpl
      003D03 70 01            [24]  561 	jnz	00103$
      003D05 22               [24]  562 	ret
      003D06                        563 00103$:
                                    564 ;	keyboards/ajazz/ak820/ak820_nvm.c:89: page = (uint16_t)header[1] | ((uint16_t)header[2] << 8);
      003D06 90 05 69         [24]  565 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0001)
      003D09 E0               [24]  566 	movx	a,@dptr
      003D0A FF               [12]  567 	mov	r7,a
      003D0B 7E 00            [12]  568 	mov	r6,#0x00
      003D0D 90 05 6A         [24]  569 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0002)
      003D10 E0               [24]  570 	movx	a,@dptr
      003D11 FC               [12]  571 	mov	r4,a
      003D12 E4               [12]  572 	clr	a
      003D13 42 07            [12]  573 	orl	ar7,a
      003D15 EC               [12]  574 	mov	a,r4
      003D16 42 06            [12]  575 	orl	ar6,a
                                    576 ;	keyboards/ajazz/ak820/ak820_nvm.c:90: crc = (uint16_t)header[3] | ((uint16_t)header[4] << 8);
      003D18 90 05 6B         [24]  577 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0003)
      003D1B E0               [24]  578 	movx	a,@dptr
      003D1C FD               [12]  579 	mov	r5,a
      003D1D 7C 00            [12]  580 	mov	r4,#0x00
      003D1F 90 05 6C         [24]  581 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0004)
      003D22 E0               [24]  582 	movx	a,@dptr
      003D23 FA               [12]  583 	mov	r2,a
      003D24 E4               [12]  584 	clr	a
      003D25 12 43 41         [24]  585 	lcall	_ak820_outline_0147
                                    586 ;	keyboards/ajazz/ak820/ak820_nvm.c:91: if (page >= AK820_NVM_SIZE / AK820_FLASH_PAGE) {
      003D28 C3               [12]  587 	clr	c
      003D29 EF               [12]  588 	mov	a,r7
      003D2A 94 A0            [12]  589 	subb	a,#0xa0
      003D2C EE               [12]  590 	mov	a,r6
      003D2D 94 00            [12]  591 	subb	a,#0x00
      003D2F 40 06            [24]  592 	jc	00134$
                                    593 ;	keyboards/ajazz/ak820/ak820_nvm.c:92: nvm_fail(AK820_NVM_FAULT_RECOVERY_PAGE);
      003D31 75 82 01         [24]  594 	mov	dpl, #0x01
                                    595 ;	keyboards/ajazz/ak820/ak820_nvm.c:93: return;
      003D34 02 3B 48         [24]  596 	ljmp	_nvm_fail
                                    597 ;	keyboards/ajazz/ak820/ak820_nvm.c:95: for (i = 0; i != AK820_FLASH_PAGE; ++i) page_data[i] = ak820_flash_read(AK820_JOURNAL_DATA + i);
      003D37                        598 00134$:
      003D37 7B 00            [12]  599 	mov	r3,#0x00
      003D39                        600 00117$:
      003D39 C0 05            [24]  601 	push	ar5
      003D3B C0 04            [24]  602 	push	ar4
      003D3D EB               [12]  603 	mov	a,r3
      003D3E 24 19            [12]  604 	add	a, #_page_data
      003D40 F9               [12]  605 	mov	r1,a
      003D41 E4               [12]  606 	clr	a
      003D42 34 05            [12]  607 	addc	a, #(_page_data >> 8)
      003D44 FA               [12]  608 	mov	r2,a
      003D45 8B 00            [24]  609 	mov	ar0,r3
      003D47 7D 00            [12]  610 	mov	r5,#0x00
      003D49 74 EF            [12]  611 	mov	a,#0xef
      003D4B 2D               [12]  612 	add	a, r5
      003D4C FD               [12]  613 	mov	r5,a
      003D4D 88 82            [24]  614 	mov	dpl, r0
      003D4F 8D 83            [24]  615 	mov	dph, r5
      003D51 12 38 B4         [24]  616 	lcall	_ak820_flash_read
      003D54 AD 82            [24]  617 	mov	r5, dpl
      003D56 89 82            [24]  618 	mov	dpl,r1
      003D58 8A 83            [24]  619 	mov	dph,r2
      003D5A ED               [12]  620 	mov	a,r5
      003D5B F0               [24]  621 	movx	@dptr,a
      003D5C 0B               [12]  622 	inc	r3
      003D5D BB 40 02         [24]  623 	cjne	r3,#0x40,00190$
      003D60 80 06            [24]  624 	sjmp	00191$
      003D62                        625 00190$:
      003D62 D0 04            [24]  626 	pop	ar4
      003D64 D0 05            [24]  627 	pop	ar5
      003D66 80 D1            [24]  628 	sjmp	00117$
      003D68                        629 00191$:
      003D68 D0 04            [24]  630 	pop	ar4
      003D6A D0 05            [24]  631 	pop	ar5
                                    632 ;	keyboards/ajazz/ak820/ak820_nvm.c:96: if (page_crc() != crc) nvm_fail(AK820_NVM_FAULT_RECOVERY_CRC);
      003D6C C0 07            [24]  633 	push	ar7
      003D6E C0 06            [24]  634 	push	ar6
      003D70 C0 05            [24]  635 	push	ar5
      003D72 C0 04            [24]  636 	push	ar4
      003D74 12 3B F4         [24]  637 	lcall	_page_crc
      003D77 AA 82            [24]  638 	mov	r2, dpl
      003D79 AB 83            [24]  639 	mov	r3, dph
      003D7B D0 04            [24]  640 	pop	ar4
      003D7D D0 05            [24]  641 	pop	ar5
      003D7F D0 06            [24]  642 	pop	ar6
      003D81 D0 07            [24]  643 	pop	ar7
      003D83 EA               [12]  644 	mov	a,r2
      003D84 B5 05 06         [24]  645 	cjne	a,ar5,00192$
      003D87 EB               [12]  646 	mov	a,r3
      003D88 B5 04 02         [24]  647 	cjne	a,ar4,00192$
      003D8B 80 06            [24]  648 	sjmp	00113$
      003D8D                        649 00192$:
      003D8D 75 82 02         [24]  650 	mov	dpl, #0x02
      003D90 02 3B 48         [24]  651 	ljmp	_nvm_fail
      003D93                        652 00113$:
                                    653 ;	keyboards/ajazz/ak820/ak820_nvm.c:97: else if (!write_page(AK820_NVM_BASE + page * AK820_FLASH_PAGE)) nvm_fail(AK820_NVM_FAULT_RECOVERY_WRITE);
      003D93 EE               [12]  654 	mov	a,r6
      003D94 54 03            [12]  655 	anl	a,#0x03
      003D96 A2 E0            [12]  656 	mov	c,acc.0
      003D98 CF               [12]  657 	xch	a,r7
      003D99 13               [12]  658 	rrc	a
      003D9A CF               [12]  659 	xch	a,r7
      003D9B 13               [12]  660 	rrc	a
      003D9C A2 E0            [12]  661 	mov	c,acc.0
      003D9E CF               [12]  662 	xch	a,r7
      003D9F 13               [12]  663 	rrc	a
      003DA0 CF               [12]  664 	xch	a,r7
      003DA1 13               [12]  665 	rrc	a
      003DA2 CF               [12]  666 	xch	a,r7
      003DA3 24 C7            [12]  667 	add	a,#0xc7
      003DA5 FE               [12]  668 	mov	r6,a
      003DA6 12 43 4C         [24]  669 	lcall	_ak820_outline_0161
      003DA9 12 3C 26         [24]  670 	lcall	_write_page
      003DAC E5 82            [12]  671 	mov	a, dpl
      003DAE 70 06            [24]  672 	jnz	00110$
      003DB0 75 82 03         [24]  673 	mov	dpl, #0x03
      003DB3 02 3B 48         [24]  674 	ljmp	_nvm_fail
      003DB6                        675 00110$:
                                    676 ;	keyboards/ajazz/ak820/ak820_nvm.c:98: else if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) nvm_fail(AK820_NVM_FAULT_RECOVERY_CLEANUP);
      003DB6 90 EF 40         [24]  677 	mov	dptr,#0xef40
      003DB9 12 39 C1         [24]  678 	lcall	_ak820_flash_erase
      003DBC E5 82            [12]  679 	mov	a, dpl
      003DBE 70 06            [24]  680 	jnz	00119$
      003DC0 75 82 04         [24]  681 	mov	dpl, #0x04
                                    682 ;	keyboards/ajazz/ak820/ak820_nvm.c:99: }
      003DC3 02 3B 48         [24]  683 	ljmp	_nvm_fail
      003DC6                        684 00119$:
      003DC6 22               [24]  685 	ret
                                    686 ;------------------------------------------------------------
                                    687 ;Allocation info for local variables in function 'eeprom_driver_init'
                                    688 ;------------------------------------------------------------
                                    689 ;	keyboards/ajazz/ak820/ak820_nvm.c:101: void eeprom_driver_init(void) {
                                    690 ;	-----------------------------------------
                                    691 ;	 function eeprom_driver_init
                                    692 ;	-----------------------------------------
      003DC7                        693 _eeprom_driver_init:
                                    694 ;	keyboards/ajazz/ak820/ak820_nvm.c:102: storage_failed = false;
                                    695 ;	assignBit
      003DC7 C2 09            [12]  696 	clr	_storage_failed
                                    697 ;	keyboards/ajazz/ak820/ak820_nvm.c:103: first_failure_stage = AK820_NVM_FAULT_NONE;
      003DC9 90 05 5B         [24]  698 	mov	dptr,#_first_failure_stage
      003DCC E4               [12]  699 	clr	a
      003DCD F0               [24]  700 	movx	@dptr,a
                                    701 ;	keyboards/ajazz/ak820/ak820_nvm.c:104: page_valid = page_dirty = false;
                                    702 ;	assignBit
      003DCE C2 08            [12]  703 	clr	_page_dirty
                                    704 ;	assignBit
      003DD0 C2 07            [12]  705 	clr	_page_valid
                                    706 ;	keyboards/ajazz/ak820/ak820_nvm.c:105: batch_depth = 0;
      003DD2 90 05 5A         [24]  707 	mov	dptr,#_batch_depth
      003DD5 E4               [12]  708 	clr	a
      003DD6 F0               [24]  709 	movx	@dptr,a
                                    710 ;	keyboards/ajazz/ak820/ak820_nvm.c:106: recover_journal();
      003DD7 12 3C D6         [24]  711 	lcall	_recover_journal
                                    712 ;	keyboards/ajazz/ak820/ak820_nvm.c:108: ak820_macro_init();
                                    713 ;	keyboards/ajazz/ak820/ak820_nvm.c:110: }
      003DDA 02 2A B7         [24]  714 	ljmp	_ak820_macro_init
                                    715 ;------------------------------------------------------------
                                    716 ;Allocation info for local variables in function 'ak820_nvm_ok'
                                    717 ;------------------------------------------------------------
                                    718 ;	keyboards/ajazz/ak820/ak820_nvm.c:112: bool ak820_nvm_ok(void) { return !storage_failed; }
                                    719 ;	-----------------------------------------
                                    720 ;	 function ak820_nvm_ok
                                    721 ;	-----------------------------------------
      003DDD                        722 _ak820_nvm_ok:
      003DDD A2 09            [12]  723 	mov	c,_storage_failed
      003DDF B3               [12]  724 	cpl	c
      003DE0 92 0A            [24]  725 	mov  _ak820_nvm_ok_sloc0_1_0,c
      003DE2 12 38 7B         [24]  726 	lcall	_ak820_outline_0160
      003DE5 22               [24]  727 	ret
                                    728 ;------------------------------------------------------------
                                    729 ;Allocation info for local variables in function 'ak820_nvm_schema_fault'
                                    730 ;------------------------------------------------------------
                                    731 ;	keyboards/ajazz/ak820/ak820_nvm.c:114: void ak820_nvm_schema_fault(void) { nvm_fail(AK820_NVM_FAULT_SCHEMA); }
                                    732 ;	-----------------------------------------
                                    733 ;	 function ak820_nvm_schema_fault
                                    734 ;	-----------------------------------------
      003DE6                        735 _ak820_nvm_schema_fault:
      003DE6 75 82 10         [24]  736 	mov	dpl, #0x10
      003DE9 02 3B 48         [24]  737 	ljmp	_nvm_fail
                                    738 ;------------------------------------------------------------
                                    739 ;Allocation info for local variables in function 'ak820_nvm_flush'
                                    740 ;------------------------------------------------------------
                                    741 ;header        Allocated with name '_ak820_nvm_flush_header_10000_62'
                                    742 ;crc           Allocated with name '_ak820_nvm_flush_crc_10000_62'
                                    743 ;i             Allocated with name '_ak820_nvm_flush_i_10000_62'
                                    744 ;stage         Allocated with name '_ak820_nvm_flush_stage_10000_62'
                                    745 ;------------------------------------------------------------
                                    746 ;	keyboards/ajazz/ak820/ak820_nvm.c:116: void ak820_nvm_flush(void) {
                                    747 ;	-----------------------------------------
                                    748 ;	 function ak820_nvm_flush
                                    749 ;	-----------------------------------------
      003DEC                        750 _ak820_nvm_flush:
                                    751 ;	keyboards/ajazz/ak820/ak820_nvm.c:121: if (!page_dirty || storage_failed) return;
      003DEC 30 08 03         [24]  752 	jnb	_page_dirty,00101$
      003DEF 30 09 01         [24]  753 	jnb	_storage_failed,00102$
      003DF2                        754 00101$:
      003DF2 22               [24]  755 	ret
      003DF3                        756 00102$:
                                    757 ;	keyboards/ajazz/ak820/ak820_nvm.c:122: crc = page_crc();
      003DF3 12 3B F4         [24]  758 	lcall	_page_crc
      003DF6 12 43 30         [24]  759 	lcall	_ak820_outline_0135
                                    760 ;	keyboards/ajazz/ak820/ak820_nvm.c:123: header[0] = 0xA5u;
      003DF9 90 05 71         [24]  761 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003DFC 74 A5            [12]  762 	mov	a,#0xa5
      003DFE F0               [24]  763 	movx	@dptr,a
                                    764 ;	keyboards/ajazz/ak820/ak820_nvm.c:124: header[1] = (uint8_t)cached_page;
      003DFF 90 05 59         [24]  765 	mov	dptr,#_cached_page
      003E02 E0               [24]  766 	movx	a,@dptr
      003E03 90 05 72         [24]  767 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0001)
      003E06 F0               [24]  768 	movx	@dptr,a
                                    769 ;	keyboards/ajazz/ak820/ak820_nvm.c:125: header[2] = (uint8_t)(cached_page >> 8);
      003E07 90 05 73         [24]  770 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0002)
      003E0A E4               [12]  771 	clr	a
      003E0B F0               [24]  772 	movx	@dptr,a
                                    773 ;	keyboards/ajazz/ak820/ak820_nvm.c:126: header[3] = (uint8_t)crc;
      003E0C 8E 05            [24]  774 	mov	ar5,r6
      003E0E 90 05 74         [24]  775 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0003)
      003E11 ED               [12]  776 	mov	a,r5
      003E12 F0               [24]  777 	movx	@dptr,a
                                    778 ;	keyboards/ajazz/ak820/ak820_nvm.c:127: header[4] = (uint8_t)(crc >> 8);
      003E13 8F 06            [24]  779 	mov	ar6,r7
      003E15 90 05 75         [24]  780 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0004)
      003E18 EE               [12]  781 	mov	a,r6
      003E19 F0               [24]  782 	movx	@dptr,a
                                    783 ;	keyboards/ajazz/ak820/ak820_nvm.c:128: for (i = 1; i != 5; ++i) header[i + 4] = (uint8_t)~header[i];
      003E1A 7F 01            [12]  784 	mov	r7,#0x01
      003E1C                        785 00128$:
      003E1C 8F 06            [24]  786 	mov	ar6,r7
      003E1E EE               [12]  787 	mov	a,r6
      003E1F 24 04            [12]  788 	add	a,#0x04
      003E21 FE               [12]  789 	mov	r6,a
      003E22 33               [12]  790 	rlc	a
      003E23 95 E0            [12]  791 	subb	a,acc
      003E25 FD               [12]  792 	mov	r5,a
      003E26 EE               [12]  793 	mov	a,r6
      003E27 24 71            [12]  794 	add	a, #_ak820_nvm_flush_header_10000_62
      003E29 FE               [12]  795 	mov	r6,a
      003E2A ED               [12]  796 	mov	a,r5
      003E2B 34 05            [12]  797 	addc	a, #(_ak820_nvm_flush_header_10000_62 >> 8)
      003E2D FD               [12]  798 	mov	r5,a
      003E2E 12 42 DC         [24]  799 	lcall	_ak820_outline_0041
      003E31 FC               [12]  800 	mov	r4,a
      003E32 63 04 FF         [24]  801 	xrl	ar4,#0xff
      003E35 8E 82            [24]  802 	mov	dpl,r6
      003E37 8D 83            [24]  803 	mov	dph,r5
      003E39 EC               [12]  804 	mov	a,r4
      003E3A F0               [24]  805 	movx	@dptr,a
      003E3B 0F               [12]  806 	inc	r7
      003E3C BF 05 DD         [24]  807 	cjne	r7,#0x05,00128$
                                    808 ;	keyboards/ajazz/ak820/ak820_nvm.c:131: stage = AK820_NVM_FAULT_HEADER_ERASE;
      003E3F 90 05 7A         [24]  809 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003E42 74 05            [12]  810 	mov	a,#0x05
      003E44 F0               [24]  811 	movx	@dptr,a
                                    812 ;	keyboards/ajazz/ak820/ak820_nvm.c:132: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      003E45 90 EF 40         [24]  813 	mov	dptr,#0xef40
      003E48 12 39 C1         [24]  814 	lcall	_ak820_flash_erase
      003E4B E5 82            [12]  815 	mov	a, dpl
      003E4D 70 03            [24]  816 	jnz	00269$
      003E4F 02 3F 35         [24]  817 	ljmp	00127$
      003E52                        818 00269$:
                                    819 ;	keyboards/ajazz/ak820/ak820_nvm.c:133: stage = AK820_NVM_FAULT_HEADER_ZERO;
      003E52 90 05 7A         [24]  820 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003E55 74 06            [12]  821 	mov	a,#0x06
      003E57 F0               [24]  822 	movx	@dptr,a
                                    823 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003E58 7F 00            [12]  824 	mov	r7,#0x00
      003E5A                        825 00130$:
                                    826 ;	keyboards/ajazz/ak820/ak820_nvm.c:135: if (ak820_flash_read(AK820_JOURNAL_HEADER + i)) goto failed;
      003E5A 12 42 E8         [24]  827 	lcall	_ak820_outline_0052
      003E5D 12 38 B4         [24]  828 	lcall	_ak820_flash_read
      003E60 E5 82            [12]  829 	mov	a, dpl
      003E62 60 03            [24]  830 	jz	00270$
      003E64 02 3F 35         [24]  831 	ljmp	00127$
      003E67                        832 00270$:
                                    833 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003E67 0F               [12]  834 	inc	r7
      003E68 BF 40 EF         [24]  835 	cjne	r7,#0x40,00130$
                                    836 ;	keyboards/ajazz/ak820/ak820_nvm.c:137: stage = AK820_NVM_FAULT_JOURNAL_WRITE;
      003E6B 90 05 7A         [24]  837 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003E6E 74 07            [12]  838 	mov	a,#0x07
      003E70 F0               [24]  839 	movx	@dptr,a
                                    840 ;	keyboards/ajazz/ak820/ak820_nvm.c:138: if (!write_page(AK820_JOURNAL_DATA)) goto failed;
      003E71 90 EF 00         [24]  841 	mov	dptr,#0xef00
      003E74 12 3C 26         [24]  842 	lcall	_write_page
      003E77 E5 82            [12]  843 	mov	a, dpl
      003E79 70 03            [24]  844 	jnz	00273$
      003E7B 02 3F 35         [24]  845 	ljmp	00127$
      003E7E                        846 00273$:
                                    847 ;	keyboards/ajazz/ak820/ak820_nvm.c:139: stage = AK820_NVM_FAULT_METADATA_PROGRAM;
      003E7E 90 05 7A         [24]  848 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003E81 74 08            [12]  849 	mov	a,#0x08
      003E83 F0               [24]  850 	movx	@dptr,a
                                    851 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      003E84 7F 01            [12]  852 	mov	r7,#0x01
      003E86                        853 00132$:
                                    854 ;	keyboards/ajazz/ak820/ak820_nvm.c:141: if (header[i] && !ak820_flash_program(AK820_JOURNAL_HEADER + i, header[i])) goto failed;
      003E86 12 42 DC         [24]  855 	lcall	_ak820_outline_0041
      003E89 FE               [12]  856 	mov	r6,a
      003E8A 60 22            [24]  857 	jz	00133$
      003E8C 8F 05            [24]  858 	mov	ar5,r7
      003E8E 7C 00            [12]  859 	mov	r4,#0x00
      003E90 74 40            [12]  860 	mov	a,#0x40
      003E92 2D               [12]  861 	add	a, r5
      003E93 FD               [12]  862 	mov	r5,a
      003E94 74 EF            [12]  863 	mov	a,#0xef
      003E96 3C               [12]  864 	addc	a, r4
      003E97 FC               [12]  865 	mov	r4,a
      003E98 90 04 F2         [24]  866 	mov	dptr,#_ak820_flash_program_PARM_2
      003E9B EE               [12]  867 	mov	a,r6
      003E9C F0               [24]  868 	movx	@dptr,a
      003E9D 12 43 5C         [24]  869 	lcall	_ak820_outline_0186
      003EA0 C0 07            [24]  870 	push	ar7
      003EA2 12 3A 21         [24]  871 	lcall	_ak820_flash_program
      003EA5 E5 82            [12]  872 	mov	a, dpl
      003EA7 D0 07            [24]  873 	pop	ar7
      003EA9 70 03            [24]  874 	jnz	00275$
      003EAB 02 3F 35         [24]  875 	ljmp	00127$
      003EAE                        876 00275$:
      003EAE                        877 00133$:
                                    878 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      003EAE 0F               [12]  879 	inc	r7
      003EAF BF 09 D4         [24]  880 	cjne	r7,#0x09,00132$
                                    881 ;	keyboards/ajazz/ak820/ak820_nvm.c:143: stage = AK820_NVM_FAULT_METADATA_READBACK;
      003EB2 90 05 7A         [24]  882 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003EB5 74 09            [12]  883 	mov	a,#0x09
      003EB7 F0               [24]  884 	movx	@dptr,a
                                    885 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      003EB8 7F 01            [12]  886 	mov	r7,#0x01
      003EBA                        887 00134$:
                                    888 ;	keyboards/ajazz/ak820/ak820_nvm.c:145: if (ak820_flash_read(AK820_JOURNAL_HEADER + i) != header[i]) goto failed;
      003EBA 12 42 E8         [24]  889 	lcall	_ak820_outline_0052
      003EBD 12 38 B4         [24]  890 	lcall	_ak820_flash_read
      003EC0 AE 82            [24]  891 	mov	r6, dpl
      003EC2 12 42 DC         [24]  892 	lcall	_ak820_outline_0041
      003EC5 FD               [12]  893 	mov	r5,a
      003EC6 EE               [12]  894 	mov	a,r6
      003EC7 B5 05 6B         [24]  895 	cjne	a,ar5,00127$
                                    896 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      003ECA 0F               [12]  897 	inc	r7
      003ECB BF 09 EC         [24]  898 	cjne	r7,#0x09,00134$
                                    899 ;	keyboards/ajazz/ak820/ak820_nvm.c:148: stage = AK820_NVM_FAULT_COMMIT_PROGRAM;
      003ECE 90 05 7A         [24]  900 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003ED1 74 0A            [12]  901 	mov	a,#0x0a
      003ED3 F0               [24]  902 	movx	@dptr,a
                                    903 ;	keyboards/ajazz/ak820/ak820_nvm.c:149: if (!ak820_flash_program(AK820_JOURNAL_HEADER, header[0])) goto failed;
      003ED4 90 05 71         [24]  904 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003ED7 E0               [24]  905 	movx	a,@dptr
      003ED8 90 04 F2         [24]  906 	mov	dptr,#_ak820_flash_program_PARM_2
      003EDB F0               [24]  907 	movx	@dptr,a
      003EDC 90 EF 40         [24]  908 	mov	dptr,#0xef40
      003EDF 12 3A 21         [24]  909 	lcall	_ak820_flash_program
      003EE2 E5 82            [12]  910 	mov	a, dpl
      003EE4 60 4F            [24]  911 	jz	00127$
                                    912 ;	keyboards/ajazz/ak820/ak820_nvm.c:150: stage = AK820_NVM_FAULT_COMMIT_READBACK;
      003EE6 90 05 7A         [24]  913 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003EE9 74 0B            [12]  914 	mov	a,#0x0b
      003EEB F0               [24]  915 	movx	@dptr,a
                                    916 ;	keyboards/ajazz/ak820/ak820_nvm.c:151: if (ak820_flash_read(AK820_JOURNAL_HEADER) != header[0]) goto failed;
      003EEC 90 EF 40         [24]  917 	mov	dptr,#0xef40
      003EEF 12 38 B4         [24]  918 	lcall	_ak820_flash_read
      003EF2 AF 82            [24]  919 	mov	r7, dpl
      003EF4 90 05 71         [24]  920 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003EF7 E0               [24]  921 	movx	a,@dptr
      003EF8 FE               [12]  922 	mov	r6,a
      003EF9 EF               [12]  923 	mov	a,r7
      003EFA B5 06 38         [24]  924 	cjne	a,ar6,00127$
                                    925 ;	keyboards/ajazz/ak820/ak820_nvm.c:152: stage = AK820_NVM_FAULT_TARGET_WRITE;
      003EFD 90 05 7A         [24]  926 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F00 74 0C            [12]  927 	mov	a,#0x0c
      003F02 F0               [24]  928 	movx	@dptr,a
                                    929 ;	keyboards/ajazz/ak820/ak820_nvm.c:153: if (!write_page(AK820_NVM_BASE + cached_page * AK820_FLASH_PAGE)) goto failed;
      003F03 90 05 59         [24]  930 	mov	dptr,#_cached_page
      003F06 E0               [24]  931 	movx	a,@dptr
      003F07 FE               [12]  932 	mov	r6,a
      003F08 E4               [12]  933 	clr	a
      003F09 C3               [12]  934 	clr	c
      003F0A CE               [12]  935 	xch	a,r6
      003F0B 13               [12]  936 	rrc	a
      003F0C CE               [12]  937 	xch	a,r6
      003F0D 13               [12]  938 	rrc	a
      003F0E A2 E0            [12]  939 	mov	c,acc.0
      003F10 CE               [12]  940 	xch	a,r6
      003F11 13               [12]  941 	rrc	a
      003F12 CE               [12]  942 	xch	a,r6
      003F13 13               [12]  943 	rrc	a
      003F14 CE               [12]  944 	xch	a,r6
      003F15 24 C7            [12]  945 	add	a,#0xc7
      003F17 FF               [12]  946 	mov	r7,a
      003F18 12 43 2B         [24]  947 	lcall	_ak820_outline_0121
      003F1B 12 3C 26         [24]  948 	lcall	_write_page
      003F1E E5 82            [12]  949 	mov	a, dpl
      003F20 60 13            [24]  950 	jz	00127$
                                    951 ;	keyboards/ajazz/ak820/ak820_nvm.c:154: stage = AK820_NVM_FAULT_CLEANUP;
      003F22 90 05 7A         [24]  952 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F25 74 0D            [12]  953 	mov	a,#0x0d
      003F27 F0               [24]  954 	movx	@dptr,a
                                    955 ;	keyboards/ajazz/ak820/ak820_nvm.c:155: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      003F28 90 EF 40         [24]  956 	mov	dptr,#0xef40
      003F2B 12 39 C1         [24]  957 	lcall	_ak820_flash_erase
      003F2E E5 82            [12]  958 	mov	a, dpl
      003F30 60 03            [24]  959 	jz	00127$
                                    960 ;	keyboards/ajazz/ak820/ak820_nvm.c:156: page_dirty = false;
                                    961 ;	assignBit
      003F32 C2 08            [12]  962 	clr	_page_dirty
                                    963 ;	keyboards/ajazz/ak820/ak820_nvm.c:157: return;
                                    964 ;	keyboards/ajazz/ak820/ak820_nvm.c:158: failed:
      003F34 22               [24]  965 	ret
      003F35                        966 00127$:
                                    967 ;	keyboards/ajazz/ak820/ak820_nvm.c:159: nvm_fail(stage);
      003F35 90 05 7A         [24]  968 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F38 E0               [24]  969 	movx	a,@dptr
      003F39 F5 82            [12]  970 	mov	dpl,a
                                    971 ;	keyboards/ajazz/ak820/ak820_nvm.c:160: }
      003F3B 02 3B 48         [24]  972 	ljmp	_nvm_fail
                                    973 ;------------------------------------------------------------
                                    974 ;Allocation info for local variables in function 'ak820_nvm_begin'
                                    975 ;------------------------------------------------------------
                                    976 ;	keyboards/ajazz/ak820/ak820_nvm.c:162: void ak820_nvm_begin(void) {
                                    977 ;	-----------------------------------------
                                    978 ;	 function ak820_nvm_begin
                                    979 ;	-----------------------------------------
      003F3E                        980 _ak820_nvm_begin:
                                    981 ;	keyboards/ajazz/ak820/ak820_nvm.c:163: if (batch_depth == 255u) nvm_fail(AK820_NVM_FAULT_BATCH_OVERFLOW);
      003F3E 90 05 5A         [24]  982 	mov	dptr,#_batch_depth
      003F41 E0               [24]  983 	movx	a,@dptr
      003F42 FF               [12]  984 	mov	r7,a
      003F43 BF FF 06         [24]  985 	cjne	r7,#0xff,00102$
      003F46 75 82 0F         [24]  986 	mov	dpl, #0x0f
      003F49 02 3B 48         [24]  987 	ljmp	_nvm_fail
      003F4C                        988 00102$:
                                    989 ;	keyboards/ajazz/ak820/ak820_nvm.c:164: else ++batch_depth;
      003F4C 90 05 5A         [24]  990 	mov	dptr,#_batch_depth
      003F4F EF               [12]  991 	mov	a,r7
      003F50 04               [12]  992 	inc	a
      003F51 F0               [24]  993 	movx	@dptr,a
                                    994 ;	keyboards/ajazz/ak820/ak820_nvm.c:165: }
      003F52 22               [24]  995 	ret
                                    996 ;------------------------------------------------------------
                                    997 ;Allocation info for local variables in function 'ak820_nvm_end'
                                    998 ;------------------------------------------------------------
                                    999 ;	keyboards/ajazz/ak820/ak820_nvm.c:167: void ak820_nvm_end(void) {
                                   1000 ;	-----------------------------------------
                                   1001 ;	 function ak820_nvm_end
                                   1002 ;	-----------------------------------------
      003F53                       1003 _ak820_nvm_end:
                                   1004 ;	keyboards/ajazz/ak820/ak820_nvm.c:168: if (batch_depth) --batch_depth;
      003F53 90 05 5A         [24] 1005 	mov	dptr,#_batch_depth
      003F56 E0               [24] 1006 	movx	a,@dptr
      003F57 FF               [12] 1007 	mov	r7,a
      003F58 E0               [24] 1008 	movx	a,@dptr
      003F59 60 06            [24] 1009 	jz	00102$
      003F5B EF               [12] 1010 	mov	a,r7
      003F5C 14               [12] 1011 	dec	a
      003F5D 90 05 5A         [24] 1012 	mov	dptr,#_batch_depth
      003F60 F0               [24] 1013 	movx	@dptr,a
      003F61                       1014 00102$:
                                   1015 ;	keyboards/ajazz/ak820/ak820_nvm.c:169: if (!batch_depth) ak820_nvm_flush();
      003F61 90 05 5A         [24] 1016 	mov	dptr,#_batch_depth
      003F64 E0               [24] 1017 	movx	a,@dptr
      003F65 70 03            [24] 1018 	jnz	00105$
                                   1019 ;	keyboards/ajazz/ak820/ak820_nvm.c:170: }
      003F67 02 3D EC         [24] 1020 	ljmp	_ak820_nvm_flush
      003F6A                       1021 00105$:
      003F6A 22               [24] 1022 	ret
                                   1023 ;------------------------------------------------------------
                                   1024 ;Allocation info for local variables in function 'load_page'
                                   1025 ;------------------------------------------------------------
                                   1026 ;page          Allocated with name '_load_page_page_10000_87'
                                   1027 ;i             Allocated with name '_load_page_i_10000_88'
                                   1028 ;------------------------------------------------------------
                                   1029 ;	keyboards/ajazz/ak820/ak820_nvm.c:172: static bool load_page(uint8_t page) {
                                   1030 ;	-----------------------------------------
                                   1031 ;	 function load_page
                                   1032 ;	-----------------------------------------
      003F6B                       1033 _load_page:
      003F6B E5 82            [12] 1034 	mov	a,dpl
      003F6D 90 05 7B         [24] 1035 	mov	dptr,#_load_page_page_10000_87
      003F70 F0               [24] 1036 	movx	@dptr,a
                                   1037 ;	keyboards/ajazz/ak820/ak820_nvm.c:174: if (page_valid && cached_page == page) return !storage_failed;
      003F71 30 07 17         [24] 1038 	jnb	_page_valid,00102$
      003F74 90 05 59         [24] 1039 	mov	dptr,#_cached_page
      003F77 E0               [24] 1040 	movx	a,@dptr
      003F78 FF               [12] 1041 	mov	r7,a
      003F79 90 05 7B         [24] 1042 	mov	dptr,#_load_page_page_10000_87
      003F7C E0               [24] 1043 	movx	a,@dptr
      003F7D FE               [12] 1044 	mov	r6,a
      003F7E EF               [12] 1045 	mov	a,r7
      003F7F B5 06 09         [24] 1046 	cjne	a,ar6,00102$
      003F82 A2 09            [12] 1047 	mov	c,_storage_failed
      003F84 B3               [12] 1048 	cpl	c
      003F85 92 0B            [24] 1049 	mov  _load_page_sloc0_1_0,c
      003F87 12 38 7B         [24] 1050 	lcall	_ak820_outline_0160
      003F8A 22               [24] 1051 	ret
      003F8B                       1052 00102$:
                                   1053 ;	keyboards/ajazz/ak820/ak820_nvm.c:175: ak820_nvm_flush();
      003F8B 12 3D EC         [24] 1054 	lcall	_ak820_nvm_flush
                                   1055 ;	keyboards/ajazz/ak820/ak820_nvm.c:176: if (storage_failed) return false;
      003F8E 30 09 04         [24] 1056 	jnb	_storage_failed,00119$
      003F91 75 82 00         [24] 1057 	mov	dpl, #0x00
                                   1058 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003F94 22               [24] 1059 	ret
      003F95                       1060 00119$:
      003F95 7F 00            [12] 1061 	mov	r7,#0x00
      003F97                       1062 00107$:
                                   1063 ;	keyboards/ajazz/ak820/ak820_nvm.c:178: page_data[i] = ak820_flash_read(AK820_NVM_BASE + page * AK820_FLASH_PAGE + i);
      003F97 EF               [12] 1064 	mov	a,r7
      003F98 24 19            [12] 1065 	add	a, #_page_data
      003F9A FD               [12] 1066 	mov	r5,a
      003F9B E4               [12] 1067 	clr	a
      003F9C 34 05            [12] 1068 	addc	a, #(_page_data >> 8)
      003F9E FE               [12] 1069 	mov	r6,a
      003F9F 90 05 7B         [24] 1070 	mov	dptr,#_load_page_page_10000_87
      003FA2 E0               [24] 1071 	movx	a,@dptr
      003FA3 FC               [12] 1072 	mov	r4,a
      003FA4 FA               [12] 1073 	mov	r2,a
      003FA5 E4               [12] 1074 	clr	a
      003FA6 C3               [12] 1075 	clr	c
      003FA7 CA               [12] 1076 	xch	a,r2
      003FA8 13               [12] 1077 	rrc	a
      003FA9 CA               [12] 1078 	xch	a,r2
      003FAA 13               [12] 1079 	rrc	a
      003FAB A2 E0            [12] 1080 	mov	c,acc.0
      003FAD CA               [12] 1081 	xch	a,r2
      003FAE 13               [12] 1082 	rrc	a
      003FAF CA               [12] 1083 	xch	a,r2
      003FB0 13               [12] 1084 	rrc	a
      003FB1 CA               [12] 1085 	xch	a,r2
      003FB2 24 C7            [12] 1086 	add	a,#0xc7
      003FB4 FB               [12] 1087 	mov	r3,a
      003FB5 8F 01            [24] 1088 	mov	ar1,r7
      003FB7 89 00            [24] 1089 	mov	ar0,r1
      003FB9 79 00            [12] 1090 	mov	r1,#0x00
      003FBB E8               [12] 1091 	mov	a,r0
      003FBC 2A               [12] 1092 	add	a, r2
      003FBD FA               [12] 1093 	mov	r2,a
      003FBE E9               [12] 1094 	mov	a,r1
      003FBF 3B               [12] 1095 	addc	a, r3
      003FC0 FB               [12] 1096 	mov	r3,a
      003FC1 12 43 47         [24] 1097 	lcall	_ak820_outline_0148
      003FC4 12 38 B4         [24] 1098 	lcall	_ak820_flash_read
      003FC7 AB 82            [24] 1099 	mov	r3, dpl
      003FC9 12 38 66         [24] 1100 	lcall	_ak820_outline_0136
      003FCC EB               [12] 1101 	mov	a,r3
      003FCD F0               [24] 1102 	movx	@dptr,a
                                   1103 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003FCE 0F               [12] 1104 	inc	r7
      003FCF BF 40 C5         [24] 1105 	cjne	r7,#0x40,00107$
                                   1106 ;	keyboards/ajazz/ak820/ak820_nvm.c:180: cached_page = page;
      003FD2 90 05 59         [24] 1107 	mov	dptr,#_cached_page
      003FD5 EC               [12] 1108 	mov	a,r4
      003FD6 F0               [24] 1109 	movx	@dptr,a
                                   1110 ;	keyboards/ajazz/ak820/ak820_nvm.c:181: page_valid = true;
                                   1111 ;	assignBit
      003FD7 D2 07            [12] 1112 	setb	_page_valid
                                   1113 ;	keyboards/ajazz/ak820/ak820_nvm.c:182: return true;
      003FD9 75 82 01         [24] 1114 	mov	dpl, #0x01
                                   1115 ;	keyboards/ajazz/ak820/ak820_nvm.c:183: }
      003FDC 22               [24] 1116 	ret
                                   1117 ;------------------------------------------------------------
                                   1118 ;Allocation info for local variables in function 'read_offset'
                                   1119 ;------------------------------------------------------------
                                   1120 ;offset        Allocated with name '_read_offset_offset_10000_93'
                                   1121 ;------------------------------------------------------------
                                   1122 ;	keyboards/ajazz/ak820/ak820_nvm.c:185: static uint8_t read_offset(uint16_t offset) {
                                   1123 ;	-----------------------------------------
                                   1124 ;	 function read_offset
                                   1125 ;	-----------------------------------------
      003FDD                       1126 _read_offset:
      003FDD 12 38 52         [24] 1127 	lcall	_ak820_outline_0106
      003FE0 90 05 7C         [24] 1128 	mov	dptr,#_read_offset_offset_10000_93
      003FE3 12 38 57         [24] 1129 	lcall	_ak820_outline_0107
                                   1130 ;	keyboards/ajazz/ak820/ak820_nvm.c:186: if (offset >= AK820_NVM_SIZE) return 0;
      003FE6 90 05 7C         [24] 1131 	mov	dptr,#_read_offset_offset_10000_93
      003FE9 12 37 FC         [24] 1132 	lcall	_ak820_outline_0051
      003FEC C3               [12] 1133 	clr	c
      003FED 94 28            [12] 1134 	subb	a,#0x28
      003FEF 40 04            [24] 1135 	jc	00102$
      003FF1 75 82 00         [24] 1136 	mov	dpl, #0x00
      003FF4 22               [24] 1137 	ret
      003FF5                       1138 00102$:
                                   1139 ;	keyboards/ajazz/ak820/ak820_nvm.c:187: if (page_valid && (offset / AK820_FLASH_PAGE) == cached_page)
      003FF5 30 07 34         [24] 1140 	jnb	_page_valid,00104$
      003FF8 8E 04            [24] 1141 	mov	ar4,r6
      003FFA EF               [12] 1142 	mov	a,r7
      003FFB A2 E7            [12] 1143 	mov	c,acc.7
      003FFD CC               [12] 1144 	xch	a,r4
      003FFE 33               [12] 1145 	rlc	a
      003FFF CC               [12] 1146 	xch	a,r4
      004000 33               [12] 1147 	rlc	a
      004001 A2 E7            [12] 1148 	mov	c,acc.7
      004003 CC               [12] 1149 	xch	a,r4
      004004 33               [12] 1150 	rlc	a
      004005 CC               [12] 1151 	xch	a,r4
      004006 33               [12] 1152 	rlc	a
      004007 CC               [12] 1153 	xch	a,r4
      004008 54 03            [12] 1154 	anl	a,#0x03
      00400A FD               [12] 1155 	mov	r5,a
      00400B 90 05 59         [24] 1156 	mov	dptr,#_cached_page
      00400E E0               [24] 1157 	movx	a,@dptr
      00400F FA               [12] 1158 	mov	r2,a
      004010 7B 00            [12] 1159 	mov	r3,#0x00
      004012 EC               [12] 1160 	mov	a,r4
      004013 B5 02 16         [24] 1161 	cjne	a,ar2,00104$
      004016 ED               [12] 1162 	mov	a,r5
      004017 B5 03 12         [24] 1163 	cjne	a,ar3,00104$
                                   1164 ;	keyboards/ajazz/ak820/ak820_nvm.c:188: return page_data[offset % AK820_FLASH_PAGE];
      00401A 74 3F            [12] 1165 	mov	a,#0x3f
      00401C 5E               [12] 1166 	anl	a,r6
      00401D 7D 00            [12] 1167 	mov	r5,#0x00
      00401F 24 19            [12] 1168 	add	a, #_page_data
      004021 F5 82            [12] 1169 	mov	dpl,a
      004023 ED               [12] 1170 	mov	a,r5
      004024 34 05            [12] 1171 	addc	a, #(_page_data >> 8)
      004026 F5 83            [12] 1172 	mov	dph,a
      004028 E0               [24] 1173 	movx	a,@dptr
      004029 F5 82            [12] 1174 	mov	dpl,a
      00402B 22               [24] 1175 	ret
      00402C                       1176 00104$:
                                   1177 ;	keyboards/ajazz/ak820/ak820_nvm.c:189: return ak820_flash_read(AK820_NVM_BASE + offset);
      00402C 74 C7            [12] 1178 	mov	a,#0xc7
      00402E 2F               [12] 1179 	add	a, r7
      00402F FF               [12] 1180 	mov	r7,a
      004030 12 43 2B         [24] 1181 	lcall	_ak820_outline_0121
                                   1182 ;	keyboards/ajazz/ak820/ak820_nvm.c:190: }
      004033 02 38 B4         [24] 1183 	ljmp	_ak820_flash_read
                                   1184 ;------------------------------------------------------------
                                   1185 ;Allocation info for local variables in function 'eeprom_read_byte'
                                   1186 ;------------------------------------------------------------
                                   1187 ;addr          Allocated with name '_eeprom_read_byte_addr_10000_97'
                                   1188 ;------------------------------------------------------------
                                   1189 ;	keyboards/ajazz/ak820/ak820_nvm.c:193: uint8_t eeprom_read_byte(const uint8_t *addr) {
                                   1190 ;	-----------------------------------------
                                   1191 ;	 function eeprom_read_byte
                                   1192 ;	-----------------------------------------
      004036                       1193 _eeprom_read_byte:
      004036 C0 07            [24] 1194 	push	ar7
      004038 C0 06            [24] 1195 	push	ar6
      00403A 12 42 D5         [24] 1196 	lcall	_ak820_outline_0037
      00403D 90 05 7E         [24] 1197 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      004040 12 37 E4         [24] 1198 	lcall	_ak820_outline_0016
                                   1199 ;	keyboards/ajazz/ak820/ak820_nvm.c:194: return read_offset((uint16_t)(uintptr_t)addr);
      004043 90 05 7E         [24] 1200 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      004046 12 37 A5         [24] 1201 	lcall	_ak820_outline_0004
      004049 C0 06            [24] 1202 	push	ar6
      00404B C0 05            [24] 1203 	push	ar5
      00404D C0 04            [24] 1204 	push	ar4
      00404F C0 03            [24] 1205 	push	ar3
      004051 C0 02            [24] 1206 	push	ar2
      004053 C0 01            [24] 1207 	push	ar1
      004055 C0 00            [24] 1208 	push	ar0
      004057 12 3F DD         [24] 1209 	lcall	_read_offset
      00405A AF 82            [24] 1210 	mov	r7, dpl
      00405C D0 00            [24] 1211 	pop	ar0
      00405E D0 01            [24] 1212 	pop	ar1
      004060 D0 02            [24] 1213 	pop	ar2
      004062 D0 03            [24] 1214 	pop	ar3
      004064 D0 04            [24] 1215 	pop	ar4
      004066 D0 05            [24] 1216 	pop	ar5
      004068 D0 06            [24] 1217 	pop	ar6
      00406A 8F 82            [24] 1218 	mov	dpl, r7
                                   1219 ;	keyboards/ajazz/ak820/ak820_nvm.c:195: }
      00406C D0 06            [24] 1220 	pop	ar6
      00406E D0 07            [24] 1221 	pop	ar7
      004070 22               [24] 1222 	ret
                                   1223 ;------------------------------------------------------------
                                   1224 ;Allocation info for local variables in function 'eeprom_read_block'
                                   1225 ;------------------------------------------------------------
                                   1226 ;addr          Allocated with name '_eeprom_read_block_PARM_2'
                                   1227 ;len           Allocated with name '_eeprom_read_block_PARM_3'
                                   1228 ;buf           Allocated with name '_eeprom_read_block_buf_10000_99'
                                   1229 ;offset        Allocated with name '_eeprom_read_block_offset_10000_100'
                                   1230 ;out           Allocated with name '_eeprom_read_block_out_10000_100'
                                   1231 ;------------------------------------------------------------
                                   1232 ;	keyboards/ajazz/ak820/ak820_nvm.c:199: void eeprom_read_block(void *buf, const void *addr, size_t len) {
                                   1233 ;	-----------------------------------------
                                   1234 ;	 function ak820_eeprom_read_block_xdata
                                   1235 ;	-----------------------------------------
      004071                       1236 _ak820_eeprom_read_block_xdata:
      004071 12 38 52         [24] 1237 	lcall	_ak820_outline_0106
      004074 90 05 86         [24] 1238 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      004077 12 38 57         [24] 1239 	lcall	_ak820_outline_0107
                                   1240 ;	keyboards/ajazz/ak820/ak820_nvm.c:230: uint16_t offset = (uint16_t)(uintptr_t)addr;
      00407A 90 05 81         [24] 1241 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      00407D 12 37 FC         [24] 1242 	lcall	_ak820_outline_0051
                                   1243 ;	keyboards/ajazz/ak820/ak820_nvm.c:231: uint8_t AK820_XDATA *out = (uint8_t AK820_XDATA *)buf;
      004080 90 05 86         [24] 1244 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      004083 12 38 1B         [24] 1245 	lcall	_ak820_outline_0059
      004086 90 05 88         [24] 1246 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004089 12 38 21         [24] 1247 	lcall	_ak820_outline_0072
                                   1248 ;	keyboards/ajazz/ak820/ak820_nvm.c:232: while (len--) {
      00408C 90 05 84         [24] 1249 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      00408F 12 38 1B         [24] 1250 	lcall	_ak820_outline_0059
      004092                       1251 00103$:
      004092 8C 02            [24] 1252 	mov	ar2,r4
      004094 8D 03            [24] 1253 	mov	ar3,r5
      004096 1C               [12] 1254 	dec	r4
      004097 BC FF 01         [24] 1255 	cjne	r4,#0xff,00130$
      00409A 1D               [12] 1256 	dec	r5
      00409B                       1257 00130$:
      00409B EA               [12] 1258 	mov	a,r2
      00409C 4B               [12] 1259 	orl	a,r3
      00409D 60 5D            [24] 1260 	jz	00106$
                                   1261 ;	keyboards/ajazz/ak820/ak820_nvm.c:233: if (offset >= AK820_NVM_SIZE) { *out++ = 0; continue; }
      00409F 8E 02            [24] 1262 	mov	ar2,r6
      0040A1 8F 03            [24] 1263 	mov	ar3,r7
      0040A3 74 D8            [12] 1264 	mov	a,#0x100 - 0x28
      0040A5 2B               [12] 1265 	add	a,r3
      0040A6 50 17            [24] 1266 	jnc	00102$
      0040A8 90 05 88         [24] 1267 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0040AB 12 43 06         [24] 1268 	lcall	_ak820_outline_0086
      0040AE 12 43 47         [24] 1269 	lcall	_ak820_outline_0148
      0040B1 E4               [12] 1270 	clr	a
      0040B2 F0               [24] 1271 	movx	@dptr,a
      0040B3 90 05 88         [24] 1272 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0040B6 04               [12] 1273 	inc	a
      0040B7 2A               [12] 1274 	add	a, r2
      0040B8 F0               [24] 1275 	movx	@dptr,a
      0040B9 E4               [12] 1276 	clr	a
      0040BA 3B               [12] 1277 	addc	a, r3
      0040BB A3               [24] 1278 	inc	dptr
      0040BC F0               [24] 1279 	movx	@dptr,a
      0040BD 80 D3            [24] 1280 	sjmp	00103$
      0040BF                       1281 00102$:
                                   1282 ;	keyboards/ajazz/ak820/ak820_nvm.c:234: *out++ = read_offset(offset);
      0040BF 90 05 88         [24] 1283 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0040C2 12 43 06         [24] 1284 	lcall	_ak820_outline_0086
      0040C5 12 43 2B         [24] 1285 	lcall	_ak820_outline_0121
      0040C8 C0 07            [24] 1286 	push	ar7
      0040CA C0 06            [24] 1287 	push	ar6
      0040CC C0 05            [24] 1288 	push	ar5
      0040CE C0 04            [24] 1289 	push	ar4
      0040D0 C0 03            [24] 1290 	push	ar3
      0040D2 C0 02            [24] 1291 	push	ar2
      0040D4 12 3F DD         [24] 1292 	lcall	_read_offset
      0040D7 A9 82            [24] 1293 	mov	r1, dpl
      0040D9 D0 02            [24] 1294 	pop	ar2
      0040DB D0 03            [24] 1295 	pop	ar3
      0040DD D0 04            [24] 1296 	pop	ar4
      0040DF D0 05            [24] 1297 	pop	ar5
      0040E1 D0 06            [24] 1298 	pop	ar6
      0040E3 D0 07            [24] 1299 	pop	ar7
      0040E5 12 43 47         [24] 1300 	lcall	_ak820_outline_0148
      0040E8 E9               [12] 1301 	mov	a,r1
      0040E9 F0               [24] 1302 	movx	@dptr,a
      0040EA 90 05 88         [24] 1303 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0040ED 74 01            [12] 1304 	mov	a,#0x01
      0040EF 2A               [12] 1305 	add	a, r2
      0040F0 F0               [24] 1306 	movx	@dptr,a
      0040F1 E4               [12] 1307 	clr	a
      0040F2 3B               [12] 1308 	addc	a, r3
      0040F3 A3               [24] 1309 	inc	dptr
      0040F4 F0               [24] 1310 	movx	@dptr,a
                                   1311 ;	keyboards/ajazz/ak820/ak820_nvm.c:235: ++offset;
      0040F5 0E               [12] 1312 	inc	r6
      0040F6 BE 00 99         [24] 1313 	cjne	r6,#0x00,00103$
      0040F9 0F               [12] 1314 	inc	r7
      0040FA 80 96            [24] 1315 	sjmp	00103$
      0040FC                       1316 00106$:
                                   1317 ;	keyboards/ajazz/ak820/ak820_nvm.c:237: }
      0040FC 22               [24] 1318 	ret
                                   1319 ;------------------------------------------------------------
                                   1320 ;Allocation info for local variables in function 'ak820_eeprom_write_block_xdata'
                                   1321 ;------------------------------------------------------------
                                   1322 ;sloc0         Allocated with name '_ak820_eeprom_write_block_xdata_sloc0_1_0'
                                   1323 ;addr          Allocated with name '_ak820_eeprom_write_block_xdata_PARM_2'
                                   1324 ;len           Allocated with name '_ak820_eeprom_write_block_xdata_PARM_3'
                                   1325 ;buf           Allocated with name '_ak820_eeprom_write_block_xdata_buf_10000_118'
                                   1326 ;offset        Allocated with name '_ak820_eeprom_write_block_xdata_offset_10000_119'
                                   1327 ;in            Allocated with name '_ak820_eeprom_write_block_xdata_in_10000_119'
                                   1328 ;value         Allocated with name '_ak820_eeprom_write_block_xdata_value_20000_122'
                                   1329 ;------------------------------------------------------------
                                   1330 ;	keyboards/ajazz/ak820/ak820_nvm.c:239: void ak820_eeprom_write_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1331 ;	-----------------------------------------
                                   1332 ;	 function ak820_eeprom_write_block_xdata
                                   1333 ;	-----------------------------------------
      0040FD                       1334 _ak820_eeprom_write_block_xdata:
      0040FD 12 38 52         [24] 1335 	lcall	_ak820_outline_0106
      004100 90 05 8F         [24] 1336 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      004103 12 38 57         [24] 1337 	lcall	_ak820_outline_0107
                                   1338 ;	keyboards/ajazz/ak820/ak820_nvm.c:240: uint16_t offset = (uint16_t)(uintptr_t)addr;
      004106 90 05 8A         [24] 1339 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      004109 12 37 FC         [24] 1340 	lcall	_ak820_outline_0051
                                   1341 ;	keyboards/ajazz/ak820/ak820_nvm.c:241: const uint8_t AK820_XDATA *in = (const uint8_t AK820_XDATA *)buf;
      00410C 90 05 8F         [24] 1342 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      00410F 12 38 1B         [24] 1343 	lcall	_ak820_outline_0059
                                   1344 ;	keyboards/ajazz/ak820/ak820_nvm.c:243: if (offset > AK820_NVM_SIZE || len > AK820_NVM_SIZE - offset) {
      004112 8E 02            [24] 1345 	mov	ar2,r6
      004114 8F 03            [24] 1346 	mov	ar3,r7
      004116 C3               [12] 1347 	clr	c
      004117 E4               [12] 1348 	clr	a
      004118 9A               [12] 1349 	subb	a,r2
      004119 74 28            [12] 1350 	mov	a,#0x28
      00411B 9B               [12] 1351 	subb	a,r3
      00411C 40 15            [24] 1352 	jc	00101$
                                   1353 ;	free result
      00411E E4               [12] 1354 	clr	a
      00411F C3               [12] 1355 	clr	c
      004120 9E               [12] 1356 	subb	a,r6
      004121 FA               [12] 1357 	mov	r2,a
      004122 74 28            [12] 1358 	mov	a,#0x28
      004124 9F               [12] 1359 	subb	a,r7
      004125 FB               [12] 1360 	mov	r3,a
      004126 90 05 8D         [24] 1361 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004129 12 38 46         [24] 1362 	lcall	_ak820_outline_0104
      00412C C3               [12] 1363 	clr	c
      00412D EA               [12] 1364 	mov	a,r2
      00412E 98               [12] 1365 	subb	a,r0
      00412F EB               [12] 1366 	mov	a,r3
      004130 99               [12] 1367 	subb	a,r1
      004131 50 06            [24] 1368 	jnc	00125$
                                   1369 ;	free result
      004133                       1370 00101$:
                                   1371 ;	keyboards/ajazz/ak820/ak820_nvm.c:244: nvm_fail(AK820_NVM_FAULT_WRITE_RANGE);
      004133 75 82 0E         [24] 1372 	mov	dpl, #0x0e
                                   1373 ;	keyboards/ajazz/ak820/ak820_nvm.c:245: return;
      004136 02 3B 48         [24] 1374 	ljmp	_nvm_fail
                                   1375 ;	keyboards/ajazz/ak820/ak820_nvm.c:247: while (len--) {
      004139                       1376 00125$:
      004139 90 05 8D         [24] 1377 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      00413C 12 43 06         [24] 1378 	lcall	_ak820_outline_0086
      00413F                       1379 00108$:
      00413F 8A 00            [24] 1380 	mov	ar0,r2
      004141 8B 01            [24] 1381 	mov	ar1,r3
      004143 1A               [12] 1382 	dec	r2
      004144 BA FF 01         [24] 1383 	cjne	r2,#0xff,00159$
      004147 1B               [12] 1384 	dec	r3
      004148                       1385 00159$:
      004148 E8               [12] 1386 	mov	a,r0
      004149 49               [12] 1387 	orl	a,r1
      00414A 70 03            [24] 1388 	jnz	00160$
      00414C 02 41 D6         [24] 1389 	ljmp	00110$
      00414F                       1390 00160$:
                                   1391 ;	keyboards/ajazz/ak820/ak820_nvm.c:248: uint8_t value = *in++;
      00414F C0 02            [24] 1392 	push	ar2
      004151 C0 03            [24] 1393 	push	ar3
      004153 12 43 13         [24] 1394 	lcall	_ak820_outline_0095
      004156 F9               [12] 1395 	mov	r1,a
      004157 A3               [24] 1396 	inc	dptr
      004158 12 38 71         [24] 1397 	lcall	_ak820_outline_0149
                                   1398 ;	keyboards/ajazz/ak820/ak820_nvm.c:249: if (!load_page(offset / AK820_FLASH_PAGE)) return;
      00415B 8E 0C            [24] 1399 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,r6
      00415D 8F 0D            [24] 1400 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),r7
      00415F A8 0C            [24] 1401 	mov	r0,_ak820_eeprom_write_block_xdata_sloc0_1_0
      004161 E5 0D            [12] 1402 	mov	a,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      004163 A2 E7            [12] 1403 	mov	c,acc.7
      004165 C8               [12] 1404 	xch	a,r0
      004166 33               [12] 1405 	rlc	a
      004167 C8               [12] 1406 	xch	a,r0
      004168 33               [12] 1407 	rlc	a
      004169 A2 E7            [12] 1408 	mov	c,acc.7
      00416B C8               [12] 1409 	xch	a,r0
      00416C 33               [12] 1410 	rlc	a
      00416D C8               [12] 1411 	xch	a,r0
      00416E 33               [12] 1412 	rlc	a
      00416F C8               [12] 1413 	xch	a,r0
      004170 54 03            [12] 1414 	anl	a,#0x03
      004172 FB               [12] 1415 	mov	r3,a
      004173 88 82            [24] 1416 	mov	dpl, r0
      004175 C0 07            [24] 1417 	push	ar7
      004177 C0 06            [24] 1418 	push	ar6
      004179 C0 05            [24] 1419 	push	ar5
      00417B C0 04            [24] 1420 	push	ar4
      00417D C0 03            [24] 1421 	push	ar3
      00417F C0 02            [24] 1422 	push	ar2
      004181 C0 01            [24] 1423 	push	ar1
      004183 12 3F 6B         [24] 1424 	lcall	_load_page
      004186 E5 82            [12] 1425 	mov	a, dpl
      004188 D0 01            [24] 1426 	pop	ar1
      00418A D0 02            [24] 1427 	pop	ar2
      00418C D0 03            [24] 1428 	pop	ar3
      00418E D0 04            [24] 1429 	pop	ar4
      004190 D0 05            [24] 1430 	pop	ar5
      004192 D0 06            [24] 1431 	pop	ar6
      004194 D0 07            [24] 1432 	pop	ar7
      004196 D0 03            [24] 1433 	pop	ar3
      004198 D0 02            [24] 1434 	pop	ar2
      00419A 70 01            [24] 1435 	jnz	00105$
      00419C 22               [24] 1436 	ret
      00419D                       1437 00105$:
                                   1438 ;	keyboards/ajazz/ak820/ak820_nvm.c:250: if (page_data[offset % AK820_FLASH_PAGE] != value) {
      00419D C0 06            [24] 1439 	push	ar6
      00419F C0 07            [24] 1440 	push	ar7
      0041A1 74 3F            [12] 1441 	mov	a,#0x3f
      0041A3 55 0C            [12] 1442 	anl	a,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0041A5 7F 00            [12] 1443 	mov	r7,#0x00
      0041A7 24 19            [12] 1444 	add	a, #_page_data
      0041A9 F5 0C            [12] 1445 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,a
      0041AB EF               [12] 1446 	mov	a,r7
      0041AC 34 05            [12] 1447 	addc	a, #(_page_data >> 8)
      0041AE F5 0D            [12] 1448 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),a
      0041B0 85 0C 82         [24] 1449 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0041B3 85 0D 83         [24] 1450 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      0041B6 E0               [24] 1451 	movx	a,@dptr
      0041B7 B5 01 06         [24] 1452 	cjne	a,ar1,00162$
      0041BA D0 07            [24] 1453 	pop	ar7
      0041BC D0 06            [24] 1454 	pop	ar6
      0041BE 80 0E            [24] 1455 	sjmp	00107$
      0041C0                       1456 00162$:
      0041C0 D0 07            [24] 1457 	pop	ar7
      0041C2 D0 06            [24] 1458 	pop	ar6
                                   1459 ;	keyboards/ajazz/ak820/ak820_nvm.c:251: page_data[offset % AK820_FLASH_PAGE] = value;
      0041C4 85 0C 82         [24] 1460 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0041C7 85 0D 83         [24] 1461 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      0041CA E9               [12] 1462 	mov	a,r1
      0041CB F0               [24] 1463 	movx	@dptr,a
                                   1464 ;	keyboards/ajazz/ak820/ak820_nvm.c:252: page_dirty = true;
                                   1465 ;	assignBit
      0041CC D2 08            [12] 1466 	setb	_page_dirty
      0041CE                       1467 00107$:
                                   1468 ;	keyboards/ajazz/ak820/ak820_nvm.c:254: ++offset;
      0041CE 0E               [12] 1469 	inc	r6
      0041CF BE 00 01         [24] 1470 	cjne	r6,#0x00,00163$
      0041D2 0F               [12] 1471 	inc	r7
      0041D3                       1472 00163$:
      0041D3 02 41 3F         [24] 1473 	ljmp	00108$
      0041D6                       1474 00110$:
                                   1475 ;	keyboards/ajazz/ak820/ak820_nvm.c:256: if (!batch_depth) ak820_nvm_flush();
      0041D6 90 05 5A         [24] 1476 	mov	dptr,#_batch_depth
      0041D9 E0               [24] 1477 	movx	a,@dptr
      0041DA 70 03            [24] 1478 	jnz	00113$
                                   1479 ;	keyboards/ajazz/ak820/ak820_nvm.c:257: }
      0041DC 02 3D EC         [24] 1480 	ljmp	_ak820_nvm_flush
      0041DF                       1481 00113$:
      0041DF 22               [24] 1482 	ret
                                   1483 ;------------------------------------------------------------
                                   1484 ;Allocation info for local variables in function 'ak820_eeprom_update_block_xdata'
                                   1485 ;------------------------------------------------------------
                                   1486 ;sloc0         Allocated with name '_ak820_eeprom_update_block_xdata_sloc0_1_0'
                                   1487 ;sloc1         Allocated with name '_ak820_eeprom_update_block_xdata_sloc1_1_0'
                                   1488 ;sloc2         Allocated with name '_ak820_eeprom_update_block_xdata_sloc2_1_0'
                                   1489 ;addr          Allocated with name '_ak820_eeprom_update_block_xdata_PARM_2'
                                   1490 ;len           Allocated with name '_ak820_eeprom_update_block_xdata_PARM_3'
                                   1491 ;buf           Allocated with name '_ak820_eeprom_update_block_xdata_buf_10000_127'
                                   1492 ;source        Allocated with name '_ak820_eeprom_update_block_xdata_source_10000_128'
                                   1493 ;offset        Allocated with name '_ak820_eeprom_update_block_xdata_offset_10000_128'
                                   1494 ;i             Allocated with name '_ak820_eeprom_update_block_xdata_i_10000_128'
                                   1495 ;------------------------------------------------------------
                                   1496 ;	keyboards/ajazz/ak820/ak820_nvm.c:259: void ak820_eeprom_update_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1497 ;	-----------------------------------------
                                   1498 ;	 function ak820_eeprom_update_block_xdata
                                   1499 ;	-----------------------------------------
      0041E0                       1500 _ak820_eeprom_update_block_xdata:
      0041E0 12 38 52         [24] 1501 	lcall	_ak820_outline_0106
      0041E3 90 05 96         [24] 1502 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      0041E6 12 38 57         [24] 1503 	lcall	_ak820_outline_0107
                                   1504 ;	keyboards/ajazz/ak820/ak820_nvm.c:260: const uint8_t AK820_XDATA *source = (const uint8_t AK820_XDATA *)buf;
      0041E9 90 05 96         [24] 1505 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      0041EC 12 37 FC         [24] 1506 	lcall	_ak820_outline_0051
                                   1507 ;	keyboards/ajazz/ak820/ak820_nvm.c:261: uint16_t offset = (uint16_t)(uintptr_t)addr;
      0041EF 90 05 91         [24] 1508 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      0041F2 E0               [24] 1509 	movx	a,@dptr
      0041F3 F5 12            [12] 1510 	mov	_ak820_eeprom_update_block_xdata_sloc2_1_0,a
      0041F5 A3               [24] 1511 	inc	dptr
      0041F6 E0               [24] 1512 	movx	a,@dptr
      0041F7 F5 13            [12] 1513 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1),a
      0041F9 A3               [24] 1514 	inc	dptr
      0041FA E0               [24] 1515 	movx	a,@dptr
      0041FB F5 14            [12] 1516 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2),a
      0041FD A9 12            [24] 1517 	mov	r1,_ak820_eeprom_update_block_xdata_sloc2_1_0
      0041FF AA 13            [24] 1518 	mov	r2,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
                                   1519 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      004201 E4               [12] 1520 	clr	a
      004202 F5 0E            [12] 1521 	mov	_ak820_eeprom_update_block_xdata_sloc0_1_0,a
      004204 F5 0F            [12] 1522 	mov	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1),a
      004206                       1523 00105$:
      004206 90 05 94         [24] 1524 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      004209 E0               [24] 1525 	movx	a,@dptr
      00420A F5 10            [12] 1526 	mov	_ak820_eeprom_update_block_xdata_sloc1_1_0,a
      00420C A3               [24] 1527 	inc	dptr
      00420D E0               [24] 1528 	movx	a,@dptr
      00420E F5 11            [12] 1529 	mov	(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1),a
      004210 C3               [12] 1530 	clr	c
      004211 E5 0E            [12] 1531 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      004213 95 10            [12] 1532 	subb	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      004215 E5 0F            [12] 1533 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      004217 95 11            [12] 1534 	subb	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      004219 50 68            [24] 1535 	jnc	00107$
                                   1536 ;	keyboards/ajazz/ak820/ak820_nvm.c:264: if (read_offset(offset + i) != source[i]) {
      00421B 89 00            [24] 1537 	mov	ar0,r1
      00421D 8A 05            [24] 1538 	mov	ar5,r2
      00421F E5 0E            [12] 1539 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      004221 28               [12] 1540 	add	a, r0
      004222 F8               [12] 1541 	mov	r0,a
      004223 E5 0F            [12] 1542 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      004225 3D               [12] 1543 	addc	a, r5
      004226 FD               [12] 1544 	mov	r5,a
      004227 88 82            [24] 1545 	mov	dpl, r0
      004229 8D 83            [24] 1546 	mov	dph, r5
      00422B C0 07            [24] 1547 	push	ar7
      00422D C0 06            [24] 1548 	push	ar6
      00422F C0 02            [24] 1549 	push	ar2
      004231 C0 01            [24] 1550 	push	ar1
      004233 12 3F DD         [24] 1551 	lcall	_read_offset
      004236 AD 82            [24] 1552 	mov	r5, dpl
      004238 D0 01            [24] 1553 	pop	ar1
      00423A D0 02            [24] 1554 	pop	ar2
      00423C D0 06            [24] 1555 	pop	ar6
      00423E D0 07            [24] 1556 	pop	ar7
      004240 E5 0E            [12] 1557 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      004242 2E               [12] 1558 	add	a, r6
      004243 F5 82            [12] 1559 	mov	dpl,a
      004245 E5 0F            [12] 1560 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      004247 3F               [12] 1561 	addc	a, r7
      004248 F5 83            [12] 1562 	mov	dph,a
      00424A E0               [24] 1563 	movx	a,@dptr
      00424B FC               [12] 1564 	mov	r4,a
      00424C ED               [12] 1565 	mov	a,r5
      00424D B5 04 02         [24] 1566 	cjne	a,ar4,00131$
      004250 80 27            [24] 1567 	sjmp	00106$
      004252                       1568 00131$:
                                   1569 ;	keyboards/ajazz/ak820/ak820_nvm.c:265: ak820_eeprom_write_block_xdata(buf, addr, len);
      004252 90 05 96         [24] 1570 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      004255 E0               [24] 1571 	movx	a,@dptr
      004256 F8               [12] 1572 	mov	r0,a
      004257 A3               [24] 1573 	inc	dptr
      004258 E0               [24] 1574 	movx	a,@dptr
      004259 FD               [12] 1575 	mov	r5,a
      00425A 90 05 8A         [24] 1576 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      00425D E5 12            [12] 1577 	mov	a,_ak820_eeprom_update_block_xdata_sloc2_1_0
      00425F F0               [24] 1578 	movx	@dptr,a
      004260 E5 13            [12] 1579 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
      004262 A3               [24] 1580 	inc	dptr
      004263 F0               [24] 1581 	movx	@dptr,a
      004264 E5 14            [12] 1582 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2)
      004266 A3               [24] 1583 	inc	dptr
      004267 F0               [24] 1584 	movx	@dptr,a
      004268 90 05 8D         [24] 1585 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      00426B E5 10            [12] 1586 	mov	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      00426D F0               [24] 1587 	movx	@dptr,a
      00426E E5 11            [12] 1588 	mov	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      004270 A3               [24] 1589 	inc	dptr
      004271 F0               [24] 1590 	movx	@dptr,a
      004272 88 82            [24] 1591 	mov	dpl, r0
      004274 8D 83            [24] 1592 	mov	dph, r5
                                   1593 ;	keyboards/ajazz/ak820/ak820_nvm.c:266: return;
      004276 02 40 FD         [24] 1594 	ljmp	_ak820_eeprom_write_block_xdata
      004279                       1595 00106$:
                                   1596 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      004279 05 0E            [12] 1597 	inc	_ak820_eeprom_update_block_xdata_sloc0_1_0
      00427B E4               [12] 1598 	clr	a
      00427C B5 0E 87         [24] 1599 	cjne	a,_ak820_eeprom_update_block_xdata_sloc0_1_0,00105$
      00427F 05 0F            [12] 1600 	inc	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      004281 80 83            [24] 1601 	sjmp	00105$
      004283                       1602 00107$:
                                   1603 ;	keyboards/ajazz/ak820/ak820_nvm.c:269: }
      004283 22               [24] 1604 	ret
                                   1605 ;------------------------------------------------------------
                                   1606 ;Allocation info for local variables in function 'eeprom_driver_erase'
                                   1607 ;------------------------------------------------------------
                                   1608 ;page          Allocated with name '_eeprom_driver_erase_page_10000_134'
                                   1609 ;i             Allocated with name '_eeprom_driver_erase_i_10000_134'
                                   1610 ;------------------------------------------------------------
                                   1611 ;	keyboards/ajazz/ak820/ak820_nvm.c:271: void eeprom_driver_erase(void) {
                                   1612 ;	-----------------------------------------
                                   1613 ;	 function eeprom_driver_erase
                                   1614 ;	-----------------------------------------
      004284                       1615 _eeprom_driver_erase:
                                   1616 ;	keyboards/ajazz/ak820/ak820_nvm.c:274: ak820_nvm_flush();
      004284 12 3D EC         [24] 1617 	lcall	_ak820_nvm_flush
                                   1618 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      004287 7F 00            [12] 1619 	mov	r7,#0x00
      004289                       1620 00111$:
      004289 BF A0 01         [24] 1621 	cjne	r7,#0xa0,00165$
      00428C 22               [24] 1622 	ret
      00428D                       1623 00165$:
      00428D 20 09 32         [24] 1624 	jb	_storage_failed,00113$
                                   1625 ;	keyboards/ajazz/ak820/ak820_nvm.c:276: if (!load_page(page)) return;
      004290 8F 82            [24] 1626 	mov	dpl, r7
      004292 C0 07            [24] 1627 	push	ar7
      004294 12 3F 6B         [24] 1628 	lcall	_load_page
      004297 E5 82            [12] 1629 	mov	a, dpl
      004299 D0 07            [24] 1630 	pop	ar7
      00429B 70 01            [24] 1631 	jnz	00126$
                                   1632 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      00429D 22               [24] 1633 	ret
      00429E                       1634 00126$:
      00429E 7E 00            [12] 1635 	mov	r6,#0x00
      0042A0                       1636 00107$:
                                   1637 ;	keyboards/ajazz/ak820/ak820_nvm.c:278: if (page_data[i]) { page_data[i] = 0; page_dirty = true; }
      0042A0 EE               [12] 1638 	mov	a,r6
      0042A1 24 19            [12] 1639 	add	a, #_page_data
      0042A3 FC               [12] 1640 	mov	r4,a
      0042A4 E4               [12] 1641 	clr	a
      0042A5 34 05            [12] 1642 	addc	a, #(_page_data >> 8)
      0042A7 FD               [12] 1643 	mov	r5,a
      0042A8 12 43 13         [24] 1644 	lcall	_ak820_outline_0095
      0042AB 60 07            [24] 1645 	jz	00108$
      0042AD 12 38 5C         [24] 1646 	lcall	_ak820_outline_0125
      0042B0 E4               [12] 1647 	clr	a
      0042B1 F0               [24] 1648 	movx	@dptr,a
                                   1649 ;	assignBit
      0042B2 D2 08            [12] 1650 	setb	_page_dirty
      0042B4                       1651 00108$:
                                   1652 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      0042B4 0E               [12] 1653 	inc	r6
      0042B5 BE 40 E8         [24] 1654 	cjne	r6,#0x40,00107$
                                   1655 ;	keyboards/ajazz/ak820/ak820_nvm.c:280: ak820_nvm_flush();
      0042B8 C0 07            [24] 1656 	push	ar7
      0042BA 12 3D EC         [24] 1657 	lcall	_ak820_nvm_flush
      0042BD D0 07            [24] 1658 	pop	ar7
                                   1659 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      0042BF 0F               [12] 1660 	inc	r7
      0042C0 80 C7            [24] 1661 	sjmp	00111$
      0042C2                       1662 00113$:
                                   1663 ;	keyboards/ajazz/ak820/ak820_nvm.c:282: }
      0042C2 22               [24] 1664 	ret
                                   1665 	.area CSEG    (CODE)
                                   1666 	.area CONST   (CODE)
                                   1667 	.area XINIT   (CODE)
                                   1668 	.area CABS    (ABS,CODE)
                                   1669 
                                   1670 ; Experimental exact instruction outlining.
                                   1671 	.globl _ak820_outline_0004
                                   1672 	.globl _ak820_outline_0011
                                   1673 	.globl _ak820_outline_0016
                                   1674 	.globl _ak820_outline_0017
                                   1675 	.globl _ak820_outline_0031
                                   1676 	.globl _ak820_outline_0037
                                   1677 	.globl _ak820_outline_0041
                                   1678 	.globl _ak820_outline_0051
                                   1679 	.globl _ak820_outline_0052
                                   1680 	.globl _ak820_outline_0059
                                   1681 	.globl _ak820_outline_0061
                                   1682 	.globl _ak820_outline_0066
                                   1683 	.globl _ak820_outline_0072
                                   1684 	.globl _ak820_outline_0085
                                   1685 	.globl _ak820_outline_0086
                                   1686 	.globl _ak820_outline_0094
                                   1687 	.globl _ak820_outline_0095
                                   1688 	.globl _ak820_outline_0096
                                   1689 	.globl _ak820_outline_0104
                                   1690 	.globl _ak820_outline_0105
                                   1691 	.globl _ak820_outline_0106
                                   1692 	.globl _ak820_outline_0107
                                   1693 	.globl _ak820_outline_0110
                                   1694 	.globl _ak820_outline_0121
                                   1695 	.globl _ak820_outline_0125
                                   1696 	.globl _ak820_outline_0126
                                   1697 	.globl _ak820_outline_0135
                                   1698 	.globl _ak820_outline_0136
                                   1699 	.globl _ak820_outline_0138
                                   1700 	.globl _ak820_outline_0140
                                   1701 	.globl _ak820_outline_0147
                                   1702 	.globl _ak820_outline_0148
                                   1703 	.globl _ak820_outline_0149
                                   1704 	.globl _ak820_outline_0160
                                   1705 	.globl _ak820_outline_0161
                                   1706 	.globl _ak820_outline_0164
                                   1707 	.globl _ak820_outline_0185
                                   1708 	.globl _ak820_outline_0186
                                   1709 	.globl _ak820_outline_0192
                                   1710 
                                   1711 	.area CSEG (CODE)
                                   1712 ; function ak820_outline_0011
      0042C3                       1713 _ak820_outline_0011:
      0042C3 8E 82            [24] 1714 	mov	dpl,r6
      0042C5 8F 83            [24] 1715 	mov	dph,r7
      0042C7 A3               [24] 1716 	inc	dptr
      0042C8 A3               [24] 1717 	inc	dptr
      0042C9 A3               [24] 1718 	inc	dptr
      0042CA A3               [24] 1719 	inc	dptr
      0042CB A3               [24] 1720 	inc	dptr
      0042CC 22               [24] 1721 	ret
                                   1722 
                                   1723 	.area CSEG (CODE)
                                   1724 ; function ak820_outline_0031
      0042CD                       1725 _ak820_outline_0031:
      0042CD F0               [24] 1726 	movx	@dptr,a
      0042CE 8E 82            [24] 1727 	mov	dpl,r6
      0042D0 8F 83            [24] 1728 	mov	dph,r7
      0042D2 A3               [24] 1729 	inc	dptr
      0042D3 A3               [24] 1730 	inc	dptr
      0042D4 22               [24] 1731 	ret
                                   1732 
                                   1733 	.area CSEG (CODE)
                                   1734 ; function ak820_outline_0037
      0042D5                       1735 _ak820_outline_0037:
      0042D5 AF F0            [24] 1736 	mov	r7,b
      0042D7 AE 83            [24] 1737 	mov	r6,dph
      0042D9 E5 82            [12] 1738 	mov	a,dpl
      0042DB 22               [24] 1739 	ret
                                   1740 
                                   1741 	.area CSEG (CODE)
                                   1742 ; function ak820_outline_0041
      0042DC                       1743 _ak820_outline_0041:
      0042DC EF               [12] 1744 	mov	a,r7
      0042DD 24 71            [12] 1745 	add	a,#_ak820_nvm_flush_header_10000_62
      0042DF F5 82            [12] 1746 	mov	dpl,a
      0042E1 E4               [12] 1747 	clr	a
      0042E2 34 05            [12] 1748 	addc	a,#(_ak820_nvm_flush_header_10000_62>>8)
      0042E4 F5 83            [12] 1749 	mov	dph,a
      0042E6 E0               [24] 1750 	movx	a,@dptr
      0042E7 22               [24] 1751 	ret
                                   1752 
                                   1753 	.area CSEG (CODE)
                                   1754 ; function ak820_outline_0052
      0042E8                       1755 _ak820_outline_0052:
      0042E8 8F 06            [24] 1756 	mov	ar6,r7
      0042EA 7D 00            [12] 1757 	mov	r5,#0x00
      0042EC 74 40            [12] 1758 	mov	a,#0x40
      0042EE 2E               [12] 1759 	add	a,r6
      0042EF FE               [12] 1760 	mov	r6,a
      0042F0 74 EF            [12] 1761 	mov	a,#0xef
      0042F2 3D               [12] 1762 	addc	a,r5
      0042F3 FD               [12] 1763 	mov	r5,a
      0042F4 8E 82            [24] 1764 	mov	dpl,r6
      0042F6 8D 83            [24] 1765 	mov	dph,r5
      0042F8 22               [24] 1766 	ret
                                   1767 
                                   1768 	.area CSEG (CODE)
                                   1769 ; function ak820_outline_0061
      0042F9                       1770 _ak820_outline_0061:
      0042F9 F0               [24] 1771 	movx	@dptr,a
      0042FA 8E 82            [24] 1772 	mov	dpl,r6
      0042FC 8F 83            [24] 1773 	mov	dph,r7
      0042FE 22               [24] 1774 	ret
                                   1775 
                                   1776 	.area CSEG (CODE)
                                   1777 ; function ak820_outline_0066
      0042FF                       1778 _ak820_outline_0066:
      0042FF 8D 82            [24] 1779 	mov	dpl,r5
      004301 8E 83            [24] 1780 	mov	dph,r6
      004303 EC               [12] 1781 	mov	a,r4
      004304 F0               [24] 1782 	movx	@dptr,a
      004305 22               [24] 1783 	ret
                                   1784 
                                   1785 	.area CSEG (CODE)
                                   1786 ; function ak820_outline_0086
      004306                       1787 _ak820_outline_0086:
      004306 E0               [24] 1788 	movx	a,@dptr
      004307 FA               [12] 1789 	mov	r2,a
      004308 A3               [24] 1790 	inc	dptr
      004309 E0               [24] 1791 	movx	a,@dptr
      00430A FB               [12] 1792 	mov	r3,a
      00430B 22               [24] 1793 	ret
                                   1794 
                                   1795 	.area CSEG (CODE)
                                   1796 ; function ak820_outline_0094
      00430C                       1797 _ak820_outline_0094:
      00430C E0               [24] 1798 	movx	a,@dptr
      00430D 8E 82            [24] 1799 	mov	dpl,r6
      00430F 8F 83            [24] 1800 	mov	dph,r7
      004311 F0               [24] 1801 	movx	@dptr,a
      004312 22               [24] 1802 	ret
                                   1803 
                                   1804 	.area CSEG (CODE)
                                   1805 ; function ak820_outline_0095
      004313                       1806 _ak820_outline_0095:
      004313 8C 82            [24] 1807 	mov	dpl,r4
      004315 8D 83            [24] 1808 	mov	dph,r5
      004317 E0               [24] 1809 	movx	a,@dptr
      004318 22               [24] 1810 	ret
                                   1811 
                                   1812 	.area CSEG (CODE)
                                   1813 ; function ak820_outline_0096
      004319                       1814 _ak820_outline_0096:
      004319 E0               [24] 1815 	movx	a,@dptr
      00431A FD               [12] 1816 	mov	r5,a
      00431B A3               [24] 1817 	inc	dptr
      00431C E0               [24] 1818 	movx	a,@dptr
      00431D FE               [12] 1819 	mov	r6,a
      00431E 22               [24] 1820 	ret
                                   1821 
                                   1822 	.area CSEG (CODE)
                                   1823 ; function ak820_outline_0110
      00431F                       1824 _ak820_outline_0110:
      00431F EF               [12] 1825 	mov	a,r7
      004320 24 19            [12] 1826 	add	a,#_page_data
      004322 F5 82            [12] 1827 	mov	dpl,a
      004324 E4               [12] 1828 	clr	a
      004325 34 05            [12] 1829 	addc	a,#(_page_data>>8)
      004327 F5 83            [12] 1830 	mov	dph,a
      004329 E0               [24] 1831 	movx	a,@dptr
      00432A 22               [24] 1832 	ret
                                   1833 
                                   1834 	.area CSEG (CODE)
                                   1835 ; function ak820_outline_0121
      00432B                       1836 _ak820_outline_0121:
      00432B 8E 82            [24] 1837 	mov	dpl,r6
      00432D 8F 83            [24] 1838 	mov	dph,r7
      00432F 22               [24] 1839 	ret
                                   1840 
                                   1841 	.area CSEG (CODE)
                                   1842 ; function ak820_outline_0135
      004330                       1843 _ak820_outline_0135:
      004330 AE 82            [24] 1844 	mov	r6,dpl
      004332 AF 83            [24] 1845 	mov	r7,dph
      004334 22               [24] 1846 	ret
                                   1847 
                                   1848 	.area CSEG (CODE)
                                   1849 ; function ak820_outline_0138
      004335                       1850 _ak820_outline_0138:
      004335 2E               [12] 1851 	add	a,r6
      004336 FE               [12] 1852 	mov	r6,a
      004337 E4               [12] 1853 	clr	a
      004338 3F               [12] 1854 	addc	a,r7
      004339 FF               [12] 1855 	mov	r7,a
      00433A 22               [24] 1856 	ret
                                   1857 
                                   1858 	.area CSEG (CODE)
                                   1859 ; function ak820_outline_0140
      00433B                       1860 _ak820_outline_0140:
      00433B ED               [12] 1861 	mov	a,r5
      00433C F0               [24] 1862 	movx	@dptr,a
      00433D EE               [12] 1863 	mov	a,r6
      00433E A3               [24] 1864 	inc	dptr
      00433F F0               [24] 1865 	movx	@dptr,a
      004340 22               [24] 1866 	ret
                                   1867 
                                   1868 	.area CSEG (CODE)
                                   1869 ; function ak820_outline_0147
      004341                       1870 _ak820_outline_0147:
      004341 42 05            [12] 1871 	orl	ar5,a
      004343 EA               [12] 1872 	mov	a,r2
      004344 42 04            [12] 1873 	orl	ar4,a
      004346 22               [24] 1874 	ret
                                   1875 
                                   1876 	.area CSEG (CODE)
                                   1877 ; function ak820_outline_0148
      004347                       1878 _ak820_outline_0148:
      004347 8A 82            [24] 1879 	mov	dpl,r2
      004349 8B 83            [24] 1880 	mov	dph,r3
      00434B 22               [24] 1881 	ret
                                   1882 
                                   1883 	.area CSEG (CODE)
                                   1884 ; function ak820_outline_0161
      00434C                       1885 _ak820_outline_0161:
      00434C 8F 82            [24] 1886 	mov	dpl,r7
      00434E 8E 83            [24] 1887 	mov	dph,r6
      004350 22               [24] 1888 	ret
                                   1889 
                                   1890 	.area CSEG (CODE)
                                   1891 ; function ak820_outline_0164
      004351                       1892 _ak820_outline_0164:
      004351 2E               [12] 1893 	add	a,r6
      004352 FC               [12] 1894 	mov	r4,a
      004353 E4               [12] 1895 	clr	a
      004354 3F               [12] 1896 	addc	a,r7
      004355 FD               [12] 1897 	mov	r5,a
      004356 22               [24] 1898 	ret
                                   1899 
                                   1900 	.area CSEG (CODE)
                                   1901 ; function ak820_outline_0185
      004357                       1902 _ak820_outline_0185:
      004357 8C 82            [24] 1903 	mov	dpl,r4
      004359 8B 83            [24] 1904 	mov	dph,r3
      00435B 22               [24] 1905 	ret
                                   1906 
                                   1907 	.area CSEG (CODE)
                                   1908 ; function ak820_outline_0186
      00435C                       1909 _ak820_outline_0186:
      00435C 8D 82            [24] 1910 	mov	dpl,r5
      00435E 8C 83            [24] 1911 	mov	dph,r4
      004360 22               [24] 1912 	ret
                                   1913 
                                   1914 	.area CSEG (CODE)
                                   1915 ; function ak820_outline_0192
      004361                       1916 _ak820_outline_0192:
      004361 AD 82            [24] 1917 	mov	r5,dpl
      004363 AE 83            [24] 1918 	mov	r6,dph
      004365 22               [24] 1919 	ret
