;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (Linux)
;--------------------------------------------------------
	.module ak820_settings
	
	.optsdcc -mmcs51 --model-large
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _clear_keyboard
	.globl ___memcpy
	.globl _memcmp
	.globl _ak820_eeprom_update_block_xdata
	.globl _ak820_eeprom_read_block_xdata
	.globl _ak820_nvm_end
	.globl _ak820_nvm_begin
	.globl _ak820_nvm_schema_fault
	.globl _ak820_nvm_ok
	.globl _ak820_settings_set_PARM_3
	.globl _ak820_settings_set_PARM_2
	.globl _ak820_settings_get_PARM_3
	.globl _ak820_settings_get_PARM_2
	.globl _ak820_settings_query_PARM_3
	.globl _ak820_settings_query_PARM_2
	.globl _ak820_settings_init
	.globl _ak820_settings_query
	.globl _ak820_settings_get
	.globl _ak820_settings_set
	.globl _ak820_settings_reset
	.globl _ak820_settings_grave_esc
	.globl _ak820_settings_combo_term
	.globl _ak820_settings_tapping_term
	.globl _ak820_settings_tap_code_delay
	.globl _ak820_settings_caps_delay
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram
;--------------------------------------------------------
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; absolute internal ram data
;--------------------------------------------------------
	.area IABS    (ABS,DATA)
	.area IABS    (ABS,DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
_valid_sloc0_1_0:
	.ds 1
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; uninitialized external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
_current:
	.ds 24
_candidate:
	.ds 24
_word_p_10000_54:
	.ds 2
_put_word_PARM_2:
	.ds 2
_put_word_p_10000_56:
	.ds 2
_checksum_crc_10000_59:
	.ds 2
_valid_i_10000_69:
	.ds 1
_ak820_settings_init_blank_zero_10000_86:
	.ds 1
_ak820_settings_init_blank_erased_10000_86:
	.ds 1
_offset_id_10000_94:
	.ds 1
_ak820_settings_query_PARM_2:
	.ds 2
_ak820_settings_query_PARM_3:
	.ds 1
_ak820_settings_query_greater_than_10000_98:
	.ds 2
_ak820_settings_query_used_10000_99:
	.ds 1
_ak820_settings_get_PARM_2:
	.ds 2
_ak820_settings_get_PARM_3:
	.ds 1
_ak820_settings_get_id_10000_106:
	.ds 2
_ak820_settings_set_PARM_2:
	.ds 2
_ak820_settings_set_PARM_3:
	.ds 1
_ak820_settings_set_id_10000_111:
	.ds 2
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area XABS    (ABS,XDATA)
;--------------------------------------------------------
; initialized external ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area HOME    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'word'
;------------------------------------------------------------
;p             Allocated with name '_word_p_10000_54'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_settings.c:13: static uint16_t word(const uint8_t AK820_XDATA *p) {
;	-----------------------------------------
;	 function word
;	-----------------------------------------
_word:
	ar7 = 0x07
	ar6 = 0x06
	ar5 = 0x05
	ar4 = 0x04
	ar3 = 0x03
	ar2 = 0x02
	ar1 = 0x01
	ar0 = 0x00
	lcall	_ak820_outline_0106
	mov	dptr,#_word_p_10000_54
	lcall	_ak820_outline_0107
;	keyboards/ajazz/ak820/ak820_settings.c:14: return (uint16_t)p[0] | ((uint16_t)p[1] << 8);
	mov	dptr,#_word_p_10000_54
	lcall	_ak820_outline_0004
	movx	a,@dptr
	mov	r5,a
	mov	r4,#0x00
	lcall	_ak820_outline_0077
	mov	r6,a
	clr	a
	orl	ar5,a
	mov	a,r6
	orl	ar4,a
	lcall	_ak820_outline_0186
;	keyboards/ajazz/ak820/ak820_settings.c:15: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'put_word'
;------------------------------------------------------------
;v             Allocated with name '_put_word_PARM_2'
;p             Allocated with name '_put_word_p_10000_56'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_settings.c:16: static void put_word(uint8_t AK820_XDATA *p, uint16_t v) { p[0] = v; p[1] = v >> 8; }
;	-----------------------------------------
;	 function put_word
;	-----------------------------------------
_put_word:
	lcall	_ak820_outline_0106
	mov	dptr,#_put_word_p_10000_56
	lcall	_ak820_outline_0107
	mov	dptr,#_put_word_p_10000_56
	lcall	_ak820_outline_0051
	mov	dptr,#_put_word_PARM_2
	lcall	_ak820_outline_0059
	mov	ar3,r4
	lcall	_ak820_outline_0121
	mov	a,r3
	lcall	_ak820_outline_0061
	inc	dptr
	mov	ar4,r5
	mov	a,r4
	movx	@dptr,a
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'checksum'
;------------------------------------------------------------
;crc           Allocated with name '_checksum_crc_10000_59'
;i             Allocated with name '_checksum_i_10000_59'
;bit           Allocated with name '_checksum_bit_10000_59'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_settings.c:17: static uint16_t checksum(void) {
;	-----------------------------------------
;	 function checksum
;	-----------------------------------------
_checksum:
;	keyboards/ajazz/ak820/ak820_settings.c:18: uint16_t crc = 0xFFFFu;
	mov	dptr,#_checksum_crc_10000_59
	mov	a,#0xff
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_settings.c:20: for (i = 0; i < 22; ++i) {
	mov	r7,#0x00
00106$:
;	keyboards/ajazz/ak820/ak820_settings.c:21: crc ^= (uint16_t)candidate[i] << 8;
	lcall	_ak820_outline_0109
	mov	r5,a
	mov	r6,#0x00
	mov	dptr,#_checksum_crc_10000_59
	movx	a,@dptr
	xrl	a,r6
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	xrl	a,r5
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_settings.c:22: for (bit = 0; bit < 8; ++bit) crc = (crc & 0x8000u) ? (crc << 1) ^ 0x1021u : (uint16_t)(crc << 1);
	mov	r6,#0x08
00105$:
	mov	dptr,#_checksum_crc_10000_59
	lcall	_ak820_outline_0059
	jnb	acc.7,00110$
	mov	a,r4
	add	a,r4
	mov	r2,a
	mov	a,r5
	rlc	a
	mov	r3,a
	xrl	ar2,#0x21
	xrl	ar3,#0x10
	sjmp	00111$
00110$:
	mov	a,r4
	add	a,r4
	mov	r2,a
	mov	a,r5
	rlc	a
	mov	r3,a
00111$:
	mov	dptr,#_checksum_crc_10000_59
	mov	a,r2
	movx	@dptr,a
	mov	a,r3
	inc	dptr
	movx	@dptr,a
	djnz	r6,00105$
;	keyboards/ajazz/ak820/ak820_settings.c:20: for (i = 0; i < 22; ++i) {
	inc	r7
	cjne	r7,#0x16,00151$
00151$:
	jc	00106$
;	keyboards/ajazz/ak820/ak820_settings.c:24: return crc;
	lcall	_ak820_outline_0148
;	keyboards/ajazz/ak820/ak820_settings.c:25: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'seal'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_settings.c:26: static void seal(void) { put_word(candidate + 22, checksum()); }
;	-----------------------------------------
;	 function seal
;	-----------------------------------------
_seal:
	lcall	_checksum
	lcall	_ak820_outline_0101
	mov	dptr,#_put_word_PARM_2
	lcall	_ak820_outline_0143
	mov	dptr,#(_candidate + 0x0016)
	ljmp	_put_word
;------------------------------------------------------------
;Allocation info for local variables in function 'defaults'
;------------------------------------------------------------
;i             Allocated with name '_defaults_i_20000_67'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_settings.c:34: static void defaults(void) {
;	-----------------------------------------
;	 function defaults
;	-----------------------------------------
_defaults:
;	keyboards/ajazz/ak820/ak820_settings.c:35: for (uint8_t i = 0; i < AK820_SETTINGS_SIZE; ++i) candidate[i] = default_record[i];
	mov	r7,#0x00
00103$:
	cjne	r7,#0x18,00122$
00122$:
	jnc	00105$
	mov	a,r7
	add	a, #_candidate
	mov	r5,a
	clr	a
	addc	a, #(_candidate >> 8)
	mov	r6,a
	mov	a,r7
	mov	dptr,#_default_record
	movc	a,@a+dptr
	lcall	_ak820_outline_0102
	inc	r7
	sjmp	00103$
00105$:
;	keyboards/ajazz/ak820/ak820_settings.c:36: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'valid'
;------------------------------------------------------------
;i             Allocated with name '_valid_i_10000_69'
;value         Allocated with name '_valid_value_10000_69'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_settings.c:37: static bool valid(void) {
;	-----------------------------------------
;	 function valid
;	-----------------------------------------
_valid:
;	keyboards/ajazz/ak820/ak820_settings.c:40: if (candidate[0] != 'Q' || candidate[1] != 'S' || candidate[2] != AK820_SETTINGS_VERSION || candidate[3] != 11 || candidate[4] != AK820_SETTINGS_CAPABILITIES) return false;
	mov	dptr,#_candidate
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0x51,00101$
	mov	dptr,#(_candidate + 0x0001)
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0x53,00101$
	mov	dptr,#(_candidate + 0x0002)
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0x01,00101$
	mov	dptr,#(_candidate + 0x0003)
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0x0b,00101$
	mov	dptr,#(_candidate + 0x0004)
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0x3f,00227$
	sjmp	00102$
00227$:
00101$:
	mov	dpl, #0x00
	ret
00102$:
;	keyboards/ajazz/ak820/ak820_settings.c:41: if (candidate[5] & 0xF0u) return false;
	mov	dptr,#(_candidate + 0x0005)
	movx	a,@dptr
	anl	a,#0xf0
	jz	00108$
	mov	dpl, #0x00
	ret
00108$:
;	keyboards/ajazz/ak820/ak820_settings.c:42: for (i = 6; i <= 14; i += 2) {
	mov	dptr,#_valid_i_10000_69
	mov	a,#0x06
	movx	@dptr,a
00122$:
;	keyboards/ajazz/ak820/ak820_settings.c:43: value = word(candidate + i);
	mov	dptr,#_valid_i_10000_69
	movx	a,@dptr
	mov	r7,a
	lcall	_ak820_outline_0040
	push	ar7
	lcall	_word
	lcall	_ak820_outline_0192
	pop	ar7
;	keyboards/ajazz/ak820/ak820_settings.c:44: if (i == 10 || i == 12) { if (value > 100) return false; }
	cjne	r7,#0x0a,00229$
	sjmp	00114$
00229$:
	cjne	r7,#0x0c,00115$
00114$:
	mov	ar4,r5
	mov	ar7,r6
	clr	c
	mov	a,#0x64
	subb	a,r4
	clr	a
	subb	a,r7
	jnc	00123$
;	free result
	mov	dpl, #0x00
	ret
00115$:
;	keyboards/ajazz/ak820/ak820_settings.c:45: else if (!value || value > 1000) return false;
	mov	a,r5
	orl	a,r6
	jz	00111$
	clr	c
	mov	a,#0xe8
	subb	a,r5
	mov	a,#0x03
	subb	a,r6
	jnc	00123$
;	free result
00111$:
	mov	dpl, #0x00
	ret
00123$:
;	keyboards/ajazz/ak820/ak820_settings.c:42: for (i = 6; i <= 14; i += 2) {
	mov	dptr,#_valid_i_10000_69
	movx	a,@dptr
	add	a,#0x02
	movx	@dptr,a
	movx	a,@dptr
	add	a,#0xff - 0x0e
	jnc	00122$
;	free result
;	keyboards/ajazz/ak820/ak820_settings.c:47: for (i = 16; i < 22; ++i) if (candidate[i]) return false;
	mov	r7,#0x10
00124$:
	mov	a,r7
	lcall	_ak820_outline_0040
	movx	a,@dptr
	jz	00125$
	mov	dpl, #0x00
	ret
00125$:
	inc	r7
	cjne	r7,#0x16,00237$
00237$:
	jc	00124$
;	keyboards/ajazz/ak820/ak820_settings.c:48: return word(candidate + 22) == checksum();
	mov	dptr,#(_candidate + 0x0016)
	lcall	_word
	lcall	_ak820_outline_0135
	push	ar7
	push	ar6
	lcall	_checksum
	lcall	_ak820_outline_0149
	pop	ar6
	pop	ar7
	mov	a,r6
	cjne	a,ar4,00239$
	mov	a,r7
	cjne	a,ar5,00239$
	setb	c
	sjmp	00240$
00239$:
	clr	c
00240$:
	mov  _valid_sloc0_1_0,c
	lcall	_ak820_outline_0160
;	keyboards/ajazz/ak820/ak820_settings.c:49: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'commit'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_settings.c:53: static int commit(void) {
;	-----------------------------------------
;	 function commit
;	-----------------------------------------
_commit:
;	keyboards/ajazz/ak820/ak820_settings.c:54: if (!ak820_nvm_ok()) return -1;
	lcall	_ak820_nvm_ok
	mov	a, dpl
	jnz	00102$
	mov	dptr,#0xffff
	ret
00102$:
;	keyboards/ajazz/ak820/ak820_settings.c:55: if (!memcmp(current, candidate, sizeof(current))) return 0;
	mov	dptr,#_memcmp_PARM_2
	mov	a,#_candidate
	movx	@dptr,a
	mov	a,#(_candidate >> 8)
	lcall	_ak820_outline_0084
	mov	dptr,#_memcmp_PARM_3
	lcall	_ak820_outline_0063
	mov	dptr,#_current
	mov	b,a
	lcall	_memcmp
	lcall	_ak820_outline_0101
	orl	a,b
	jnz	00104$
	mov	dptr,#0x0000
	ret
00104$:
;	keyboards/ajazz/ak820/ak820_settings.c:56: clear_keyboard();
	lcall	_clear_keyboard
;	keyboards/ajazz/ak820/ak820_settings.c:57: ak820_nvm_begin();
	lcall	_ak820_nvm_begin
;	keyboards/ajazz/ak820/ak820_settings.c:58: ak820_eeprom_update_block_xdata(candidate, (void *)AK820_SETTINGS_ADDR, sizeof(candidate));
	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
	mov	a,#0xa8
	movx	@dptr,a
	mov	a,#0x06
	lcall	_ak820_outline_0084
	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
	lcall	_ak820_outline_0063
	mov	dptr,#_candidate
	lcall	_ak820_eeprom_update_block_xdata
;	keyboards/ajazz/ak820/ak820_settings.c:59: ak820_nvm_end();
	lcall	_ak820_nvm_end
;	keyboards/ajazz/ak820/ak820_settings.c:60: if (!ak820_nvm_ok()) return -1;
	lcall	_ak820_nvm_ok
	mov	a, dpl
	jnz	00106$
	mov	dptr,#0xffff
	ret
00106$:
;	keyboards/ajazz/ak820/ak820_settings.c:61: memcpy(current, candidate, sizeof(current));
	lcall	_ak820_outline_0018
	lcall	___memcpy
;	keyboards/ajazz/ak820/ak820_settings.c:62: return 0;
	mov	dptr,#0x0000
;	keyboards/ajazz/ak820/ak820_settings.c:63: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_settings_init'
;------------------------------------------------------------
;i             Allocated with name '_ak820_settings_init_i_10000_86'
;blank_zero    Allocated with name '_ak820_settings_init_blank_zero_10000_86'
;blank_erased  Allocated with name '_ak820_settings_init_blank_erased_10000_86'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_settings.c:64: void ak820_settings_init(void) {
;	-----------------------------------------
;	 function ak820_settings_init
;	-----------------------------------------
_ak820_settings_init:
;	keyboards/ajazz/ak820/ak820_settings.c:66: bool blank_zero = true, blank_erased = true;
	mov	dptr,#_ak820_settings_init_blank_zero_10000_86
	mov	a,#0x01
	movx	@dptr,a
	mov	dptr,#_ak820_settings_init_blank_erased_10000_86
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_settings.c:67: ak820_eeprom_read_block_xdata(candidate, (const void *)AK820_SETTINGS_ADDR, sizeof(candidate));
	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
	mov	a,#0xa8
	movx	@dptr,a
	mov	a,#0x06
	lcall	_ak820_outline_0084
	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
	lcall	_ak820_outline_0063
	mov	dptr,#_candidate
	lcall	_ak820_eeprom_read_block_xdata
;	keyboards/ajazz/ak820/ak820_settings.c:68: if (!valid()) {
	lcall	_valid
	mov	a, dpl
;	keyboards/ajazz/ak820/ak820_settings.c:71: for (i = 0; i < sizeof(candidate); ++i) {
	jnz	00110$
	mov	r7,a
00111$:
;	keyboards/ajazz/ak820/ak820_settings.c:72: if (candidate[i]) blank_zero = false;
	mov	a,r7
	lcall	_ak820_outline_0040
	movx	a,@dptr
	jz	00102$
	mov	dptr,#_ak820_settings_init_blank_zero_10000_86
	clr	a
	movx	@dptr,a
00102$:
;	keyboards/ajazz/ak820/ak820_settings.c:73: if (candidate[i] != 0xFF) blank_erased = false;
	lcall	_ak820_outline_0109
	mov	r6,a
	cjne	r6,#0xff,00167$
	sjmp	00112$
00167$:
	mov	dptr,#_ak820_settings_init_blank_erased_10000_86
	clr	a
	movx	@dptr,a
00112$:
;	keyboards/ajazz/ak820/ak820_settings.c:71: for (i = 0; i < sizeof(candidate); ++i) {
	inc	r7
	cjne	r7,#0x18,00168$
00168$:
	jc	00111$
;	keyboards/ajazz/ak820/ak820_settings.c:75: if (!blank_zero && !blank_erased) ak820_nvm_schema_fault();
	mov	dptr,#_ak820_settings_init_blank_zero_10000_86
	movx	a,@dptr
	jnz	00107$
	mov	dptr,#_ak820_settings_init_blank_erased_10000_86
	movx	a,@dptr
	jnz	00107$
	lcall	_ak820_nvm_schema_fault
00107$:
;	keyboards/ajazz/ak820/ak820_settings.c:76: defaults();
	lcall	_defaults
00110$:
;	keyboards/ajazz/ak820/ak820_settings.c:78: memcpy(current, candidate, sizeof(current));
	lcall	_ak820_outline_0018
;	keyboards/ajazz/ak820/ak820_settings.c:79: }
	ljmp	___memcpy
;------------------------------------------------------------
;Allocation info for local variables in function 'offset'
;------------------------------------------------------------
;id            Allocated with name '_offset_id_10000_94'
;i             Allocated with name '_offset_i_20000_96'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_settings.c:95: static uint8_t offset(uint8_t id) {
;	-----------------------------------------
;	 function offset
;	-----------------------------------------
_offset:
	mov	a,dpl
	mov	dptr,#_offset_id_10000_94
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_settings.c:96: for (uint8_t i = 0; i < sizeof(ids); ++i) if (ids[i] == id) return positions[i];
	movx	a,@dptr
	mov	r7,a
	mov	r6,#0x00
00105$:
	cjne	r6,#0x05,00130$
00130$:
	jnc	00103$
	mov	a,r6
	mov	dptr,#_ids
	movc	a,@a+dptr
	cjne	a,ar7,00106$
	mov	a,r6
	mov	dptr,#_positions
	movc	a,@a+dptr
	mov	dpl,a
	ret
00106$:
	inc	r6
	sjmp	00105$
00103$:
;	keyboards/ajazz/ak820/ak820_settings.c:97: return 0;
	mov	dpl, #0x00
;	keyboards/ajazz/ak820/ak820_settings.c:98: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_settings_query'
;------------------------------------------------------------
;buffer        Allocated with name '_ak820_settings_query_PARM_2'
;size          Allocated with name '_ak820_settings_query_PARM_3'
;greater_than  Allocated with name '_ak820_settings_query_greater_than_10000_98'
;i             Allocated with name '_ak820_settings_query_i_10000_99'
;used          Allocated with name '_ak820_settings_query_used_10000_99'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_settings.c:99: void ak820_settings_query(uint16_t greater_than, uint8_t AK820_XDATA *buffer, uint8_t size) {
;	-----------------------------------------
;	 function ak820_settings_query
;	-----------------------------------------
_ak820_settings_query:
	lcall	_ak820_outline_0106
	mov	dptr,#_ak820_settings_query_greater_than_10000_98
	lcall	_ak820_outline_0107
;	keyboards/ajazz/ak820/ak820_settings.c:100: uint8_t i, used = 0;
	mov	dptr,#_ak820_settings_query_used_10000_99
	clr	a
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_settings.c:101: for (i = 0; i < size; ++i) buffer[i] = 0xFF;
	mov	dptr,#_ak820_settings_query_PARM_2
	lcall	_ak820_outline_0051
	mov	dptr,#_ak820_settings_query_PARM_3
	movx	a,@dptr
	mov	r5,a
	mov	r4,#0x00
00108$:
	clr	c
	mov	a,r4
	subb	a,r5
	jnc	00101$
	mov	a,r4
	lcall	_ak820_outline_0017
	mov	a,#0xff
	movx	@dptr,a
	inc	r4
	sjmp	00108$
00101$:
;	keyboards/ajazz/ak820/ak820_settings.c:102: if (greater_than >= 19) return;
	mov	dptr,#_ak820_settings_query_greater_than_10000_98
	lcall	_ak820_outline_0105
	clr	c
	mov	a,r3
	subb	a,#0x13
	mov	a,r4
	subb	a,#0x00
	jc	00129$
;	keyboards/ajazz/ak820/ak820_settings.c:103: for (i = 0; i < sizeof(ids) && used + 2 <= size; ++i) {
	ret
00129$:
	mov	r4,#0x00
00112$:
	cjne	r4,#0x05,00169$
00169$:
	jnc	00114$
	push	ar6
	push	ar7
	mov	dptr,#_ak820_settings_query_used_10000_99
	movx	a,@dptr
	mov	r3,a
	mov	r1,a
	mov	r2,#0x00
	mov	a,#0x02
	add	a, r1
	mov	r1,a
	clr	a
	addc	a, r2
	mov	r2,a
	mov	ar0,r5
	mov	r7,#0x00
	clr	c
	mov	a,r0
	subb	a,r1
	mov	a,r7
	xrl	a,#0x80
	mov	b,r2
	xrl	b,#0x80
	subb	a,b
	pop	ar7
	pop	ar6
	jc	00114$
;	free result
;	keyboards/ajazz/ak820/ak820_settings.c:104: if (ids[i] > (uint8_t)greater_than) { buffer[used++] = ids[i]; buffer[used++] = 0; }
	mov	a,r4
	mov	dptr,#_ids
	movc	a,@a+dptr
	mov	r2,a
	mov	dptr,#_ak820_settings_query_greater_than_10000_98
	movx	a,@dptr
	clr	c
	subb	a,r2
	jnc	00113$
;	free result
	mov	dptr,#_ak820_settings_query_used_10000_99
	mov	a,r3
	inc	a
	movx	@dptr,a
	mov	a,r3
	lcall	_ak820_outline_0017
	mov	a,r2
	movx	@dptr,a
	mov	dptr,#_ak820_settings_query_used_10000_99
	movx	a,@dptr
	mov	r3,a
	inc	a
	movx	@dptr,a
	mov	a,r3
	lcall	_ak820_outline_0017
	clr	a
	movx	@dptr,a
00113$:
;	keyboards/ajazz/ak820/ak820_settings.c:103: for (i = 0; i < sizeof(ids) && used + 2 <= size; ++i) {
	inc	r4
	sjmp	00112$
00114$:
;	keyboards/ajazz/ak820/ak820_settings.c:106: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_settings_get'
;------------------------------------------------------------
;buffer        Allocated with name '_ak820_settings_get_PARM_2'
;capacity      Allocated with name '_ak820_settings_get_PARM_3'
;id            Allocated with name '_ak820_settings_get_id_10000_106'
;out           Allocated with name '_ak820_settings_get_out_10000_107'
;pos           Allocated with name '_ak820_settings_get_pos_10000_107'
;width         Allocated with name '_ak820_settings_get_width_10000_107'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_settings.c:107: int ak820_settings_get(uint16_t id, uint8_t AK820_XDATA *buffer, uint8_t capacity) {
;	-----------------------------------------
;	 function ak820_settings_get
;	-----------------------------------------
_ak820_settings_get:
	lcall	_ak820_outline_0106
	mov	dptr,#_ak820_settings_get_id_10000_106
	lcall	_ak820_outline_0107
;	keyboards/ajazz/ak820/ak820_settings.c:108: uint8_t AK820_XDATA *out = buffer;
	mov	dptr,#_ak820_settings_get_PARM_2
	lcall	_ak820_outline_0051
;	keyboards/ajazz/ak820/ak820_settings.c:109: uint8_t pos, width = id == 1 ? 1 : 2;
	mov	dptr,#_ak820_settings_get_id_10000_106
	lcall	_ak820_outline_0059
	cjne	r4,#0x01,00110$
	cjne	r5,#0x00,00110$
	mov	r3,#0x01
	sjmp	00111$
00110$:
	mov	r3,#0x02
00111$:
;	keyboards/ajazz/ak820/ak820_settings.c:110: if (id > 255) return -1;
	lcall	_ak820_outline_0113
	jnc	00102$
;	free result
	mov	dptr,#0xffff
	ret
00102$:
;	keyboards/ajazz/ak820/ak820_settings.c:111: pos = offset((uint8_t)id);
	mov	dptr,#_ak820_settings_get_id_10000_106
	movx	a,@dptr
	mov	dpl,a
	push	ar7
	push	ar6
	push	ar3
	lcall	_offset
	mov	r5, dpl
	pop	ar3
	pop	ar6
	pop	ar7
;	keyboards/ajazz/ak820/ak820_settings.c:112: if (!pos || capacity < width) return -1;
	mov	a,r5
	jz	00103$
	mov	dptr,#_ak820_settings_get_PARM_3
	movx	a,@dptr
	clr	c
	subb	a,r3
	jnc	00104$
00103$:
	mov	dptr,#0xffff
	ret
00104$:
;	keyboards/ajazz/ak820/ak820_settings.c:113: out[0] = current[pos];
	mov	a,r5
	add	a, #_current
	mov	dpl,a
	clr	a
	addc	a, #(_current >> 8)
	mov	dph,a
	lcall	_ak820_outline_0094
;	keyboards/ajazz/ak820/ak820_settings.c:114: if (width == 2) out[1] = current[pos + 1];
	cjne	r3,#0x02,00107$
	inc	r6
	cjne	r6,#0x00,00147$
	inc	r7
00147$:
	inc	r5
	mov	a,r5
	rlc	a
	subb	a,acc
	mov	r4,a
	mov	a,r5
	add	a, #_current
	mov	dpl,a
	mov	a,r4
	addc	a, #(_current >> 8)
	mov	dph,a
	lcall	_ak820_outline_0094
00107$:
;	keyboards/ajazz/ak820/ak820_settings.c:115: return 0;
	mov	dptr,#0x0000
;	keyboards/ajazz/ak820/ak820_settings.c:116: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_settings_set'
;------------------------------------------------------------
;buffer        Allocated with name '_ak820_settings_set_PARM_2'
;capacity      Allocated with name '_ak820_settings_set_PARM_3'
;id            Allocated with name '_ak820_settings_set_id_10000_111'
;in            Allocated with name '_ak820_settings_set_in_10000_112'
;pos           Allocated with name '_ak820_settings_set_pos_10000_112'
;width         Allocated with name '_ak820_settings_set_width_10000_112'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_settings.c:117: int ak820_settings_set(uint16_t id, const uint8_t AK820_XDATA *buffer, uint8_t capacity) {
;	-----------------------------------------
;	 function ak820_settings_set
;	-----------------------------------------
_ak820_settings_set:
	lcall	_ak820_outline_0106
	mov	dptr,#_ak820_settings_set_id_10000_111
	lcall	_ak820_outline_0107
;	keyboards/ajazz/ak820/ak820_settings.c:118: const uint8_t AK820_XDATA *in = buffer;
	mov	dptr,#_ak820_settings_set_PARM_2
	lcall	_ak820_outline_0051
;	keyboards/ajazz/ak820/ak820_settings.c:119: uint8_t pos, width = id == 1 ? 1 : 2;
	mov	dptr,#_ak820_settings_set_id_10000_111
	lcall	_ak820_outline_0059
	cjne	r4,#0x01,00113$
	cjne	r5,#0x00,00113$
	mov	r3,#0x01
	sjmp	00114$
00113$:
	mov	r3,#0x02
00114$:
;	keyboards/ajazz/ak820/ak820_settings.c:120: if (id > 255) return -1;
	lcall	_ak820_outline_0113
	jnc	00102$
;	free result
	mov	dptr,#0xffff
	ret
00102$:
;	keyboards/ajazz/ak820/ak820_settings.c:121: pos = offset((uint8_t)id);
	mov	dptr,#_ak820_settings_set_id_10000_111
	movx	a,@dptr
	mov	dpl,a
	push	ar7
	push	ar6
	push	ar3
	lcall	_offset
	mov	r5, dpl
	pop	ar3
	pop	ar6
	pop	ar7
;	keyboards/ajazz/ak820/ak820_settings.c:122: if (!pos || capacity < width || !ak820_nvm_ok()) return -1;
	mov	a,r5
	jz	00103$
	mov	dptr,#_ak820_settings_set_PARM_3
	movx	a,@dptr
	clr	c
	subb	a,r3
	jc	00103$
	lcall	_ak820_nvm_ok
	mov	a, dpl
	jnz	00104$
00103$:
	mov	dptr,#0xffff
	ret
00104$:
;	keyboards/ajazz/ak820/ak820_settings.c:123: memcpy(candidate, current, sizeof(candidate));
	mov	dptr,#___memcpy_PARM_2
	mov	a,#_current
	movx	@dptr,a
	mov	a,#(_current >> 8)
	lcall	_ak820_outline_0084
	mov	dptr,#___memcpy_PARM_3
	lcall	_ak820_outline_0063
	mov	dptr,#_candidate
	mov	b,a
	push	ar7
	push	ar6
	push	ar5
	push	ar3
	lcall	___memcpy
	pop	ar3
	pop	ar5
	pop	ar6
	pop	ar7
;	keyboards/ajazz/ak820/ak820_settings.c:124: candidate[pos] = in[0];
	mov	a,r5
	add	a, #_candidate
	mov	r2,a
	clr	a
	addc	a, #(_candidate >> 8)
	mov	r4,a
	lcall	_ak820_outline_0100
	mov	dpl,r2
	mov	dph,r4
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_settings.c:125: if (width == 2) candidate[pos + 1] = in[1];
	cjne	r3,#0x02,00108$
	inc	r5
	mov	a,r5
	rlc	a
	subb	a,acc
	mov	r4,a
	mov	a,r5
	add	a, #_candidate
	mov	r5,a
	mov	a,r4
	addc	a, #(_candidate >> 8)
	mov	r4,a
	lcall	_ak820_outline_0077
	lcall	_ak820_outline_0186
	movx	@dptr,a
00108$:
;	keyboards/ajazz/ak820/ak820_settings.c:126: seal();
	lcall	_seal
;	keyboards/ajazz/ak820/ak820_settings.c:127: if (!valid()) return -1;
	lcall	_valid
	mov	a, dpl
	jnz	00110$
	mov	dptr,#0xffff
	ret
00110$:
;	keyboards/ajazz/ak820/ak820_settings.c:128: return commit();
;	keyboards/ajazz/ak820/ak820_settings.c:129: }
	ljmp	_commit
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_settings_reset'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_settings.c:130: int ak820_settings_reset(void) { defaults(); return commit(); }
;	-----------------------------------------
;	 function ak820_settings_reset
;	-----------------------------------------
_ak820_settings_reset:
	lcall	_defaults
	ljmp	_commit
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_settings_grave_esc'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_settings.c:131: uint8_t ak820_settings_grave_esc(void) { return current[5]; }
;	-----------------------------------------
;	 function ak820_settings_grave_esc
;	-----------------------------------------
_ak820_settings_grave_esc:
	mov	dptr,#(_current + 0x0005)
	movx	a,@dptr
	mov	dpl,a
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_settings_combo_term'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_settings.c:132: uint16_t ak820_settings_combo_term(void) { return word(current + 6); }
;	-----------------------------------------
;	 function ak820_settings_combo_term
;	-----------------------------------------
_ak820_settings_combo_term:
	mov	dptr,#(_current + 0x0006)
	ljmp	_word
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_settings_tapping_term'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_settings.c:133: uint16_t ak820_settings_tapping_term(void) { return word(current + 8); }
;	-----------------------------------------
;	 function ak820_settings_tapping_term
;	-----------------------------------------
_ak820_settings_tapping_term:
	mov	dptr,#(_current + 0x0008)
	ljmp	_word
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_settings_tap_code_delay'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_settings.c:134: uint16_t ak820_settings_tap_code_delay(void) { return word(current + 10); }
;	-----------------------------------------
;	 function ak820_settings_tap_code_delay
;	-----------------------------------------
_ak820_settings_tap_code_delay:
	mov	dptr,#(_current + 0x000a)
	ljmp	_word
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_settings_caps_delay'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_settings.c:135: uint16_t ak820_settings_caps_delay(void) { return word(current + 12); }
;	-----------------------------------------
;	 function ak820_settings_caps_delay
;	-----------------------------------------
_ak820_settings_caps_delay:
	mov	dptr,#(_current + 0x000c)
	ljmp	_word
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_settings_autoshift_timeout'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_settings.c:136: uint16_t ak820_settings_autoshift_timeout(void) { return word(current + 14); }
;	-----------------------------------------
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area CONST   (CODE)
_default_record:
	.db #0x51	; 81	'Q'
	.db #0x53	; 83	'S'
	.db #0x01	; 1
	.db #0x0b	; 11
	.db #0x3f	; 63
	.db #0x00	; 0
	.db #0x28	; 40
	.db #0x00	; 0
	.db #0xc8	; 200
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x50	; 80	'P'
	.db #0x00	; 0
	.db #0xaf	; 175
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x7b	; 123
	.db #0xc9	; 201
	.area CSEG    (CODE)
	.area CONST   (CODE)
_ids:
	.db #0x01	; 1
	.db #0x02	; 2
	.db #0x07	; 7
	.db #0x12	; 18
	.db #0x13	; 19
	.area CSEG    (CODE)
	.area CONST   (CODE)
_positions:
	.db #0x05	; 5
	.db #0x06	; 6
	.db #0x08	; 8
	.db #0x0a	; 10
	.db #0x0c	; 12
	.area CSEG    (CODE)
	.area XINIT   (CODE)
	.area CABS    (ABS,CODE)

; Experimental exact instruction outlining.
	.globl _ak820_outline_0004
	.globl _ak820_outline_0017
	.globl _ak820_outline_0018
	.globl _ak820_outline_0040
	.globl _ak820_outline_0051
	.globl _ak820_outline_0059
	.globl _ak820_outline_0061
	.globl _ak820_outline_0063
	.globl _ak820_outline_0077
	.globl _ak820_outline_0084
	.globl _ak820_outline_0094
	.globl _ak820_outline_0100
	.globl _ak820_outline_0101
	.globl _ak820_outline_0102
	.globl _ak820_outline_0105
	.globl _ak820_outline_0106
	.globl _ak820_outline_0107
	.globl _ak820_outline_0109
	.globl _ak820_outline_0113
	.globl _ak820_outline_0121
	.globl _ak820_outline_0135
	.globl _ak820_outline_0143
	.globl _ak820_outline_0148
	.globl _ak820_outline_0149
	.globl _ak820_outline_0160
	.globl _ak820_outline_0186
	.globl _ak820_outline_0192

	.area CSEG (CODE)
; function ak820_outline_0018
_ak820_outline_0018:
	mov	dptr,#___memcpy_PARM_2
	mov	a,#_candidate
	movx	@dptr,a
	mov	a,#(_candidate>>8)
	inc	dptr
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	mov	dptr,#___memcpy_PARM_3
	mov	a,#0x18
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	mov	dptr,#_current
	mov	b,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0040
_ak820_outline_0040:
	add	a,#_candidate
	mov	r5,a
	clr	a
	addc	a,#(_candidate>>8)
	mov	r6,a
	mov	dpl,r5
	mov	dph,r6
	ret

	.area CSEG (CODE)
; function ak820_outline_0063
_ak820_outline_0063:
	mov	a,#0x18
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0102
_ak820_outline_0102:
	mov	dpl,r5
	mov	dph,r6
	movx	@dptr,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0109
_ak820_outline_0109:
	mov	a,r7
	add	a,#_candidate
	mov	dpl,a
	clr	a
	addc	a,#(_candidate>>8)
	mov	dph,a
	movx	a,@dptr
	ret

	.area CSEG (CODE)
; function ak820_outline_0113
_ak820_outline_0113:
	clr	c
	mov	a,#0xff
	subb	a,r4
	clr	a
	subb	a,r5
	ret

	.area CSEG (CODE)
; function ak820_outline_0143
_ak820_outline_0143:
	movx	@dptr,a
	mov	a,b
	inc	dptr
	movx	@dptr,a
	ret
