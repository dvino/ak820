                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module quantum
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _shutdown_quantum
                                     12 	.globl _extract_mod_bits
                                     13 	.globl _process_tri_layer
                                     14 	.globl _process_rgb
                                     15 	.globl _process_grave_esc
                                     16 	.globl _ak820_settings_caps_delay
                                     17 	.globl _ak820_settings_tap_code_delay
                                     18 	.globl _ak820_combo_process
                                     19 	.globl _process_repeat_key
                                     20 	.globl _process_last_key
                                     21 	.globl _process_caps_word
                                     22 	.globl _process_record_via
                                     23 	.globl _mcu_reset
                                     24 	.globl _bootloader_jump
                                     25 	.globl _ak820_resolve_key
                                     26 	.globl _default_layer_set
                                     27 	.globl _clear_keyboard
                                     28 	.globl _unregister_weak_mods
                                     29 	.globl _register_weak_mods
                                     30 	.globl _unregister_mods
                                     31 	.globl _register_mods
                                     32 	.globl _unregister_code
                                     33 	.globl _register_code
                                     34 	.globl _eeconfig_disable
                                     35 	.globl _rgb_matrix_set_suspend_state
                                     36 	.globl _rgb_matrix_task
                                     37 	.globl _mDelaymS
                                     38 	.globl _ADC_START
                                     39 	.globl _S0_R_FIFO
                                     40 	.globl _S0_T_FIFO
                                     41 	.globl _S0_FREE
                                     42 	.globl _S0_IF_BYTE
                                     43 	.globl _S0_IF_FIRST
                                     44 	.globl _S0_IF_OV
                                     45 	.globl _S0_FST_ACT
                                     46 	.globl _CP_RL2
                                     47 	.globl _C_T2
                                     48 	.globl _TR2
                                     49 	.globl _EXEN2
                                     50 	.globl _TCLK
                                     51 	.globl _RCLK
                                     52 	.globl _EXF2
                                     53 	.globl _CAP1F
                                     54 	.globl _TF2
                                     55 	.globl _RI
                                     56 	.globl _TI
                                     57 	.globl _RB8
                                     58 	.globl _TB8
                                     59 	.globl _REN
                                     60 	.globl _SM2
                                     61 	.globl _SM1
                                     62 	.globl _SM0
                                     63 	.globl _IT0
                                     64 	.globl _IE0
                                     65 	.globl _IT1
                                     66 	.globl _IE1
                                     67 	.globl _TR0
                                     68 	.globl _TF0
                                     69 	.globl _TR1
                                     70 	.globl _TF1
                                     71 	.globl _P4_0
                                     72 	.globl _P4_1
                                     73 	.globl _P4_2
                                     74 	.globl _P4_3
                                     75 	.globl _P4_4
                                     76 	.globl _P4_5
                                     77 	.globl _P4_6
                                     78 	.globl _RXD
                                     79 	.globl _TXD
                                     80 	.globl _INT0
                                     81 	.globl _INT1
                                     82 	.globl _T0
                                     83 	.globl _T1
                                     84 	.globl _MOSI1
                                     85 	.globl _MISO1
                                     86 	.globl _SCK1
                                     87 	.globl _P3_0
                                     88 	.globl _P3_1
                                     89 	.globl _P3_2
                                     90 	.globl _P3_3
                                     91 	.globl _P3_4
                                     92 	.globl _P3_5
                                     93 	.globl _P3_6
                                     94 	.globl _P3_7
                                     95 	.globl _CAP1_
                                     96 	.globl _T2_
                                     97 	.globl _CAP2_
                                     98 	.globl _T2EX_
                                     99 	.globl _RXD1
                                    100 	.globl _TXD1
                                    101 	.globl _P2_0
                                    102 	.globl _P2_1
                                    103 	.globl _P2_2
                                    104 	.globl _P2_3
                                    105 	.globl _P2_4
                                    106 	.globl _P2_5
                                    107 	.globl _P2_6
                                    108 	.globl _P2_7
                                    109 	.globl _AIN0
                                    110 	.globl _AIN1
                                    111 	.globl _AIN2
                                    112 	.globl _AIN3
                                    113 	.globl _AIN4
                                    114 	.globl _AIN5
                                    115 	.globl _AIN6
                                    116 	.globl _AIN7
                                    117 	.globl _CAP1
                                    118 	.globl _T2
                                    119 	.globl _CAP2
                                    120 	.globl _T2EX
                                    121 	.globl _INT0_
                                    122 	.globl _SCS
                                    123 	.globl _MOSI
                                    124 	.globl _MISO
                                    125 	.globl _SCK
                                    126 	.globl _RXD1_
                                    127 	.globl _TXD1_
                                    128 	.globl _P1_0
                                    129 	.globl _P1_1
                                    130 	.globl _P1_2
                                    131 	.globl _P1_3
                                    132 	.globl _P1_4
                                    133 	.globl _P1_5
                                    134 	.globl _P1_6
                                    135 	.globl _P1_7
                                    136 	.globl _AIN8
                                    137 	.globl _AIN9
                                    138 	.globl _AIN10
                                    139 	.globl _AIN11
                                    140 	.globl _AIN12
                                    141 	.globl _AIN13
                                    142 	.globl _RXD_
                                    143 	.globl _TXD_
                                    144 	.globl _SCL0
                                    145 	.globl _SDA0
                                    146 	.globl _P0_0
                                    147 	.globl _P0_1
                                    148 	.globl _P0_2
                                    149 	.globl _P0_3
                                    150 	.globl _P0_4
                                    151 	.globl _P0_5
                                    152 	.globl _P0_6
                                    153 	.globl _P0_7
                                    154 	.globl _IE_SPI0
                                    155 	.globl _IE_USB
                                    156 	.globl _IE_ADC
                                    157 	.globl _IE_UART1
                                    158 	.globl _IE_PWM_I2C
                                    159 	.globl _IE_GPIO
                                    160 	.globl _IE_WDOG
                                    161 	.globl _PX0
                                    162 	.globl _PT0
                                    163 	.globl _PX1
                                    164 	.globl _PT1
                                    165 	.globl _PS
                                    166 	.globl _PT2
                                    167 	.globl _PL_FLAG
                                    168 	.globl _PH_FLAG
                                    169 	.globl _EX0
                                    170 	.globl _ET0
                                    171 	.globl _EX1
                                    172 	.globl _ET1
                                    173 	.globl _ES
                                    174 	.globl _ET2
                                    175 	.globl _E_DIS
                                    176 	.globl _EA
                                    177 	.globl _P
                                    178 	.globl _F1
                                    179 	.globl _OV
                                    180 	.globl _RS0
                                    181 	.globl _RS1
                                    182 	.globl _F0
                                    183 	.globl _AC
                                    184 	.globl _CY
                                    185 	.globl _I2CS_INT_ST
                                    186 	.globl _I2CX_INT
                                    187 	.globl _LED_STATUS
                                    188 	.globl _LED_DMA_H
                                    189 	.globl _LED_DMA_L
                                    190 	.globl _LED_DMA
                                    191 	.globl _LED_PWM_OE
                                    192 	.globl _LED_COMMON
                                    193 	.globl _ADC_CHAN
                                    194 	.globl _ADC_DAT_H
                                    195 	.globl _ADC_DAT_L
                                    196 	.globl _ADC_DAT
                                    197 	.globl _ADC_CTRL
                                    198 	.globl _SPI1_CK_SE
                                    199 	.globl _SPI1_CTRL
                                    200 	.globl _SPI1_DATA
                                    201 	.globl _SPI1_STAT
                                    202 	.globl _SIF1
                                    203 	.globl _SBAUD1
                                    204 	.globl _SBUF1
                                    205 	.globl _SCON1
                                    206 	.globl _SPI0_SETUP
                                    207 	.globl _SPI0_CK_SE
                                    208 	.globl _SPI0_CTRL
                                    209 	.globl _SPI0_DATA
                                    210 	.globl _SPI0_STAT
                                    211 	.globl _T2CAP1H
                                    212 	.globl _T2CAP1L
                                    213 	.globl _T2CAP1
                                    214 	.globl _TH2
                                    215 	.globl _TL2
                                    216 	.globl _T2COUNT
                                    217 	.globl _RCAP2H
                                    218 	.globl _RCAP2L
                                    219 	.globl _RCAP2
                                    220 	.globl _T2MOD
                                    221 	.globl _T2CON
                                    222 	.globl _SBUF
                                    223 	.globl _SCON
                                    224 	.globl _TH1
                                    225 	.globl _TH0
                                    226 	.globl _TL1
                                    227 	.globl _TL0
                                    228 	.globl _TMOD
                                    229 	.globl _TCON
                                    230 	.globl _XBUS_AUX
                                    231 	.globl _P7
                                    232 	.globl _P6_DIR
                                    233 	.globl _P6_OUT_PU
                                    234 	.globl _P6_IN
                                    235 	.globl _P5_DIR
                                    236 	.globl _P5_OUT_PU
                                    237 	.globl _P5_IN
                                    238 	.globl _P4_LED_KEY
                                    239 	.globl _P4_DIR_PU
                                    240 	.globl _P4_MOD_OC
                                    241 	.globl _P4
                                    242 	.globl _P3_DIR_PU
                                    243 	.globl _P3_MOD_OC
                                    244 	.globl _P3
                                    245 	.globl _P2_DIR_PU
                                    246 	.globl _P2_MOD_OC
                                    247 	.globl _P2
                                    248 	.globl _P1_DIR_PU
                                    249 	.globl _P1_MOD_OC
                                    250 	.globl _P1
                                    251 	.globl _P0_DIR_PU
                                    252 	.globl _P0_MOD_OC
                                    253 	.globl _P0
                                    254 	.globl _ROM_CTRL
                                    255 	.globl _ROM_DATA_HH
                                    256 	.globl _ROM_DATA_HL
                                    257 	.globl _ROM_DATA_HI
                                    258 	.globl _ROM_ADDR_H
                                    259 	.globl _ROM_ADDR_L
                                    260 	.globl _ROM_ADDR
                                    261 	.globl _GPIO_IE
                                    262 	.globl _IP_EX
                                    263 	.globl _IE_EX
                                    264 	.globl _IP
                                    265 	.globl _IE
                                    266 	.globl _WDOG_COUNT
                                    267 	.globl _RESET_KEEP
                                    268 	.globl _WAKE_CTRL
                                    269 	.globl _CLOCK_CFG
                                    270 	.globl _POWER_CFG
                                    271 	.globl _PCON
                                    272 	.globl _GLOBAL_CFG
                                    273 	.globl _SAFE_MOD
                                    274 	.globl _DPH
                                    275 	.globl _DPL
                                    276 	.globl _SP
                                    277 	.globl _A_INV
                                    278 	.globl _B
                                    279 	.globl _ACC
                                    280 	.globl _PSW
                                    281 	.globl _process_record_quantum_helper_PARM_2
                                    282 	.globl _get_record_keycode_PARM_2
                                    283 	.globl _register_code16
                                    284 	.globl _unregister_code16
                                    285 	.globl _reset_keyboard
                                    286 	.globl _soft_reset_keyboard
                                    287 	.globl _get_record_keycode
                                    288 	.globl _pre_process_record_quantum
                                    289 	.globl _process_record_quantum
                                    290 	.globl _process_record_quantum_helper
                                    291 	.globl _shutdown_user
                                    292 ;--------------------------------------------------------
                                    293 ; special function registers
                                    294 ;--------------------------------------------------------
                                    295 	.area RSEG    (ABS,DATA)
      000000                        296 	.org 0x0000
                           0000D0   297 _PSW	=	0x00d0
                           0000E0   298 _ACC	=	0x00e0
                           0000F0   299 _B	=	0x00f0
                           0000FD   300 _A_INV	=	0x00fd
                           000081   301 _SP	=	0x0081
                           000082   302 _DPL	=	0x0082
                           000083   303 _DPH	=	0x0083
                           0000A1   304 _SAFE_MOD	=	0x00a1
                           0000B1   305 _GLOBAL_CFG	=	0x00b1
                           000087   306 _PCON	=	0x0087
                           0000BA   307 _POWER_CFG	=	0x00ba
                           0000B9   308 _CLOCK_CFG	=	0x00b9
                           0000A9   309 _WAKE_CTRL	=	0x00a9
                           0000FE   310 _RESET_KEEP	=	0x00fe
                           0000FF   311 _WDOG_COUNT	=	0x00ff
                           0000A8   312 _IE	=	0x00a8
                           0000B8   313 _IP	=	0x00b8
                           0000E8   314 _IE_EX	=	0x00e8
                           0000E9   315 _IP_EX	=	0x00e9
                           0000B2   316 _GPIO_IE	=	0x00b2
                           008584   317 _ROM_ADDR	=	0x8584
                           000084   318 _ROM_ADDR_L	=	0x0084
                           000085   319 _ROM_ADDR_H	=	0x0085
                           008F8E   320 _ROM_DATA_HI	=	0x8f8e
                           00008E   321 _ROM_DATA_HL	=	0x008e
                           00008F   322 _ROM_DATA_HH	=	0x008f
                           000086   323 _ROM_CTRL	=	0x0086
                           000080   324 _P0	=	0x0080
                           0000C4   325 _P0_MOD_OC	=	0x00c4
                           0000C5   326 _P0_DIR_PU	=	0x00c5
                           000090   327 _P1	=	0x0090
                           000092   328 _P1_MOD_OC	=	0x0092
                           000093   329 _P1_DIR_PU	=	0x0093
                           0000A0   330 _P2	=	0x00a0
                           000094   331 _P2_MOD_OC	=	0x0094
                           000095   332 _P2_DIR_PU	=	0x0095
                           0000B0   333 _P3	=	0x00b0
                           000096   334 _P3_MOD_OC	=	0x0096
                           000097   335 _P3_DIR_PU	=	0x0097
                           0000C0   336 _P4	=	0x00c0
                           0000C2   337 _P4_MOD_OC	=	0x00c2
                           0000C3   338 _P4_DIR_PU	=	0x00c3
                           0000C1   339 _P4_LED_KEY	=	0x00c1
                           0000AA   340 _P5_IN	=	0x00aa
                           0000AB   341 _P5_OUT_PU	=	0x00ab
                           0000AC   342 _P5_DIR	=	0x00ac
                           0000AD   343 _P6_IN	=	0x00ad
                           0000AE   344 _P6_OUT_PU	=	0x00ae
                           0000AF   345 _P6_DIR	=	0x00af
                           0000F1   346 _P7	=	0x00f1
                           0000A2   347 _XBUS_AUX	=	0x00a2
                           000088   348 _TCON	=	0x0088
                           000089   349 _TMOD	=	0x0089
                           00008A   350 _TL0	=	0x008a
                           00008B   351 _TL1	=	0x008b
                           00008C   352 _TH0	=	0x008c
                           00008D   353 _TH1	=	0x008d
                           000098   354 _SCON	=	0x0098
                           000099   355 _SBUF	=	0x0099
                           0000C8   356 _T2CON	=	0x00c8
                           0000C9   357 _T2MOD	=	0x00c9
                           00CBCA   358 _RCAP2	=	0xcbca
                           0000CA   359 _RCAP2L	=	0x00ca
                           0000CB   360 _RCAP2H	=	0x00cb
                           00CDCC   361 _T2COUNT	=	0xcdcc
                           0000CC   362 _TL2	=	0x00cc
                           0000CD   363 _TH2	=	0x00cd
                           00CFCE   364 _T2CAP1	=	0xcfce
                           0000CE   365 _T2CAP1L	=	0x00ce
                           0000CF   366 _T2CAP1H	=	0x00cf
                           0000F8   367 _SPI0_STAT	=	0x00f8
                           0000F9   368 _SPI0_DATA	=	0x00f9
                           0000FA   369 _SPI0_CTRL	=	0x00fa
                           0000FB   370 _SPI0_CK_SE	=	0x00fb
                           0000FC   371 _SPI0_SETUP	=	0x00fc
                           0000BC   372 _SCON1	=	0x00bc
                           0000BD   373 _SBUF1	=	0x00bd
                           0000BE   374 _SBAUD1	=	0x00be
                           0000BF   375 _SIF1	=	0x00bf
                           0000B4   376 _SPI1_STAT	=	0x00b4
                           0000B5   377 _SPI1_DATA	=	0x00b5
                           0000B6   378 _SPI1_CTRL	=	0x00b6
                           0000B7   379 _SPI1_CK_SE	=	0x00b7
                           0000F3   380 _ADC_CTRL	=	0x00f3
                           00F5F4   381 _ADC_DAT	=	0xf5f4
                           0000F4   382 _ADC_DAT_L	=	0x00f4
                           0000F5   383 _ADC_DAT_H	=	0x00f5
                           0000F6   384 _ADC_CHAN	=	0x00f6
                           0000A6   385 _LED_COMMON	=	0x00a6
                           0000A7   386 _LED_PWM_OE	=	0x00a7
                           00C7C6   387 _LED_DMA	=	0xc7c6
                           0000C6   388 _LED_DMA_L	=	0x00c6
                           0000C7   389 _LED_DMA_H	=	0x00c7
                           0000F7   390 _LED_STATUS	=	0x00f7
                           0000B3   391 _I2CX_INT	=	0x00b3
                           0000BB   392 _I2CS_INT_ST	=	0x00bb
                                    393 ;--------------------------------------------------------
                                    394 ; special function bits
                                    395 ;--------------------------------------------------------
                                    396 	.area RSEG    (ABS,DATA)
      000000                        397 	.org 0x0000
                           0000D7   398 _CY	=	0x00d7
                           0000D6   399 _AC	=	0x00d6
                           0000D5   400 _F0	=	0x00d5
                           0000D4   401 _RS1	=	0x00d4
                           0000D3   402 _RS0	=	0x00d3
                           0000D2   403 _OV	=	0x00d2
                           0000D1   404 _F1	=	0x00d1
                           0000D0   405 _P	=	0x00d0
                           0000AF   406 _EA	=	0x00af
                           0000AE   407 _E_DIS	=	0x00ae
                           0000AD   408 _ET2	=	0x00ad
                           0000AC   409 _ES	=	0x00ac
                           0000AB   410 _ET1	=	0x00ab
                           0000AA   411 _EX1	=	0x00aa
                           0000A9   412 _ET0	=	0x00a9
                           0000A8   413 _EX0	=	0x00a8
                           0000BF   414 _PH_FLAG	=	0x00bf
                           0000BE   415 _PL_FLAG	=	0x00be
                           0000BD   416 _PT2	=	0x00bd
                           0000BC   417 _PS	=	0x00bc
                           0000BB   418 _PT1	=	0x00bb
                           0000BA   419 _PX1	=	0x00ba
                           0000B9   420 _PT0	=	0x00b9
                           0000B8   421 _PX0	=	0x00b8
                           0000EF   422 _IE_WDOG	=	0x00ef
                           0000EE   423 _IE_GPIO	=	0x00ee
                           0000ED   424 _IE_PWM_I2C	=	0x00ed
                           0000EC   425 _IE_UART1	=	0x00ec
                           0000EB   426 _IE_ADC	=	0x00eb
                           0000E9   427 _IE_USB	=	0x00e9
                           0000E8   428 _IE_SPI0	=	0x00e8
                           000087   429 _P0_7	=	0x0087
                           000086   430 _P0_6	=	0x0086
                           000085   431 _P0_5	=	0x0085
                           000084   432 _P0_4	=	0x0084
                           000083   433 _P0_3	=	0x0083
                           000082   434 _P0_2	=	0x0082
                           000081   435 _P0_1	=	0x0081
                           000080   436 _P0_0	=	0x0080
                           000081   437 _SDA0	=	0x0081
                           000080   438 _SCL0	=	0x0080
                           000083   439 _TXD_	=	0x0083
                           000082   440 _RXD_	=	0x0082
                           000085   441 _AIN13	=	0x0085
                           000084   442 _AIN12	=	0x0084
                           000083   443 _AIN11	=	0x0083
                           000082   444 _AIN10	=	0x0082
                           000081   445 _AIN9	=	0x0081
                           000080   446 _AIN8	=	0x0080
                           000097   447 _P1_7	=	0x0097
                           000096   448 _P1_6	=	0x0096
                           000095   449 _P1_5	=	0x0095
                           000094   450 _P1_4	=	0x0094
                           000093   451 _P1_3	=	0x0093
                           000092   452 _P1_2	=	0x0092
                           000091   453 _P1_1	=	0x0091
                           000090   454 _P1_0	=	0x0090
                           000097   455 _TXD1_	=	0x0097
                           000096   456 _RXD1_	=	0x0096
                           000097   457 _SCK	=	0x0097
                           000096   458 _MISO	=	0x0096
                           000095   459 _MOSI	=	0x0095
                           000094   460 _SCS	=	0x0094
                           000092   461 _INT0_	=	0x0092
                           000091   462 _T2EX	=	0x0091
                           000091   463 _CAP2	=	0x0091
                           000090   464 _T2	=	0x0090
                           000090   465 _CAP1	=	0x0090
                           000097   466 _AIN7	=	0x0097
                           000096   467 _AIN6	=	0x0096
                           000095   468 _AIN5	=	0x0095
                           000094   469 _AIN4	=	0x0094
                           000093   470 _AIN3	=	0x0093
                           000092   471 _AIN2	=	0x0092
                           000091   472 _AIN1	=	0x0091
                           000090   473 _AIN0	=	0x0090
                           0000A7   474 _P2_7	=	0x00a7
                           0000A6   475 _P2_6	=	0x00a6
                           0000A5   476 _P2_5	=	0x00a5
                           0000A4   477 _P2_4	=	0x00a4
                           0000A3   478 _P2_3	=	0x00a3
                           0000A2   479 _P2_2	=	0x00a2
                           0000A1   480 _P2_1	=	0x00a1
                           0000A0   481 _P2_0	=	0x00a0
                           0000A7   482 _TXD1	=	0x00a7
                           0000A6   483 _RXD1	=	0x00a6
                           0000A5   484 _T2EX_	=	0x00a5
                           0000A5   485 _CAP2_	=	0x00a5
                           0000A4   486 _T2_	=	0x00a4
                           0000A4   487 _CAP1_	=	0x00a4
                           0000B7   488 _P3_7	=	0x00b7
                           0000B6   489 _P3_6	=	0x00b6
                           0000B5   490 _P3_5	=	0x00b5
                           0000B4   491 _P3_4	=	0x00b4
                           0000B3   492 _P3_3	=	0x00b3
                           0000B2   493 _P3_2	=	0x00b2
                           0000B1   494 _P3_1	=	0x00b1
                           0000B0   495 _P3_0	=	0x00b0
                           0000B7   496 _SCK1	=	0x00b7
                           0000B6   497 _MISO1	=	0x00b6
                           0000B5   498 _MOSI1	=	0x00b5
                           0000B5   499 _T1	=	0x00b5
                           0000B4   500 _T0	=	0x00b4
                           0000B3   501 _INT1	=	0x00b3
                           0000B2   502 _INT0	=	0x00b2
                           0000B1   503 _TXD	=	0x00b1
                           0000B0   504 _RXD	=	0x00b0
                           0000C6   505 _P4_6	=	0x00c6
                           0000C5   506 _P4_5	=	0x00c5
                           0000C4   507 _P4_4	=	0x00c4
                           0000C3   508 _P4_3	=	0x00c3
                           0000C2   509 _P4_2	=	0x00c2
                           0000C1   510 _P4_1	=	0x00c1
                           0000C0   511 _P4_0	=	0x00c0
                           00008F   512 _TF1	=	0x008f
                           00008E   513 _TR1	=	0x008e
                           00008D   514 _TF0	=	0x008d
                           00008C   515 _TR0	=	0x008c
                           00008B   516 _IE1	=	0x008b
                           00008A   517 _IT1	=	0x008a
                           000089   518 _IE0	=	0x0089
                           000088   519 _IT0	=	0x0088
                           00009F   520 _SM0	=	0x009f
                           00009E   521 _SM1	=	0x009e
                           00009D   522 _SM2	=	0x009d
                           00009C   523 _REN	=	0x009c
                           00009B   524 _TB8	=	0x009b
                           00009A   525 _RB8	=	0x009a
                           000099   526 _TI	=	0x0099
                           000098   527 _RI	=	0x0098
                           0000CF   528 _TF2	=	0x00cf
                           0000CF   529 _CAP1F	=	0x00cf
                           0000CE   530 _EXF2	=	0x00ce
                           0000CD   531 _RCLK	=	0x00cd
                           0000CC   532 _TCLK	=	0x00cc
                           0000CB   533 _EXEN2	=	0x00cb
                           0000CA   534 _TR2	=	0x00ca
                           0000C9   535 _C_T2	=	0x00c9
                           0000C8   536 _CP_RL2	=	0x00c8
                           0000FF   537 _S0_FST_ACT	=	0x00ff
                           0000FE   538 _S0_IF_OV	=	0x00fe
                           0000FD   539 _S0_IF_FIRST	=	0x00fd
                           0000FC   540 _S0_IF_BYTE	=	0x00fc
                           0000FB   541 _S0_FREE	=	0x00fb
                           0000FA   542 _S0_T_FIFO	=	0x00fa
                           0000F8   543 _S0_R_FIFO	=	0x00f8
                           0000F7   544 _ADC_START	=	0x00f7
                                    545 ;--------------------------------------------------------
                                    546 ; overlayable register banks
                                    547 ;--------------------------------------------------------
                                    548 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        549 	.ds 8
                                    550 ;--------------------------------------------------------
                                    551 ; internal ram data
                                    552 ;--------------------------------------------------------
                                    553 	.area DSEG    (DATA)
                                    554 ;--------------------------------------------------------
                                    555 ; overlayable items in internal ram
                                    556 ;--------------------------------------------------------
                                    557 ;--------------------------------------------------------
                                    558 ; indirectly addressable internal ram data
                                    559 ;--------------------------------------------------------
                                    560 	.area ISEG    (DATA)
                                    561 ;--------------------------------------------------------
                                    562 ; absolute internal ram data
                                    563 ;--------------------------------------------------------
                                    564 	.area IABS    (ABS,DATA)
                                    565 	.area IABS    (ABS,DATA)
                                    566 ;--------------------------------------------------------
                                    567 ; bit data
                                    568 ;--------------------------------------------------------
                                    569 	.area BSEG    (BIT)
      000024                        570 _get_record_keycode_sloc0_1_0:
      000024                        571 	.ds 1
      000025                        572 _pre_process_record_quantum_sloc0_1_0:
      000025                        573 	.ds 1
      000026                        574 _process_ak820_nkro_sloc0_1_0:
      000026                        575 	.ds 1
                                    576 ;--------------------------------------------------------
                                    577 ; paged external ram data
                                    578 ;--------------------------------------------------------
                                    579 	.area PSEG    (PAG,XDATA)
                                    580 ;--------------------------------------------------------
                                    581 ; uninitialized external ram data
                                    582 ;--------------------------------------------------------
                                    583 	.area XSEG    (XDATA)
      000C19                        584 _extract_mod_bits_code_10000_623:
      000C19                        585 	.ds 2
      000C1B                        586 _register_code16_code_10000_629:
      000C1B                        587 	.ds 2
      000C1D                        588 _unregister_code16_code_10000_634:
      000C1D                        589 	.ds 2
      000C1F                        590 _get_record_keycode_PARM_2:
      000C1F                        591 	.ds 1
      000C20                        592 _get_record_keycode_record_argument_10000_672:
      000C20                        593 	.ds 2
      000C22                        594 _pre_process_record_quantum_record_argument_10000_678:
      000C22                        595 	.ds 2
      000C24                        596 _process_record_quantum_record_10000_682:
      000C24                        597 	.ds 2
      000C26                        598 _process_ak820_nkro_PARM_2:
      000C26                        599 	.ds 3
      000C29                        600 _process_ak820_nkro_keycode_10000_684:
      000C29                        601 	.ds 2
      000C2B                        602 _process_record_quantum_helper_PARM_2:
      000C2B                        603 	.ds 2
      000C2D                        604 _process_record_quantum_helper_keycode_10000_689:
      000C2D                        605 	.ds 2
      000C2F                        606 _get_u8_str_last_num_10000_715:
      000C2F                        607 	.ds 1
      000C30                        608 _get_u16_str_last_num_10000_719:
      000C30                        609 	.ds 2
                                    610 ;--------------------------------------------------------
                                    611 ; absolute external ram data
                                    612 ;--------------------------------------------------------
                                    613 	.area XABS    (ABS,XDATA)
                                    614 ;--------------------------------------------------------
                                    615 ; initialized external ram data
                                    616 ;--------------------------------------------------------
                                    617 	.area XISEG   (XDATA)
                                    618 	.area HOME    (CODE)
                                    619 	.area GSINIT0 (CODE)
                                    620 	.area GSINIT1 (CODE)
                                    621 	.area GSINIT2 (CODE)
                                    622 	.area GSINIT3 (CODE)
                                    623 	.area GSINIT4 (CODE)
                                    624 	.area GSINIT5 (CODE)
                                    625 	.area GSINIT  (CODE)
                                    626 	.area GSFINAL (CODE)
                                    627 	.area CSEG    (CODE)
                                    628 ;--------------------------------------------------------
                                    629 ; global & static initialisations
                                    630 ;--------------------------------------------------------
                                    631 	.area HOME    (CODE)
                                    632 	.area GSINIT  (CODE)
                                    633 	.area GSFINAL (CODE)
                                    634 	.area GSINIT  (CODE)
                                    635 ;------------------------------------------------------------
                                    636 ;Allocation info for local variables in function 'get_u8_str'
                                    637 ;------------------------------------------------------------
                                    638 ;curr_pad      Allocated with name '_get_u8_str_PARM_2'
                                    639 ;curr_num      Allocated with name '_get_u8_str_curr_num_10000_714'
                                    640 ;buf           Allocated with name '_get_u8_str_buf_10000_715'
                                    641 ;last_num      Allocated with name '_get_u8_str_last_num_10000_715'
                                    642 ;last_pad      Allocated with name '_get_u8_str_last_pad_10000_715'
                                    643 ;------------------------------------------------------------
                                    644 ;	quantum/quantum.c:789: static uint8_t last_num = 0xFF;
      0030F3 90 0C 2F         [24]  645 	mov	dptr,#_get_u8_str_last_num_10000_715
      0030F6 74 FF            [12]  646 	mov	a,#0xff
      0030F8 F0               [24]  647 	movx	@dptr,a
                                    648 ;------------------------------------------------------------
                                    649 ;Allocation info for local variables in function 'get_u16_str'
                                    650 ;------------------------------------------------------------
                                    651 ;curr_pad      Allocated with name '_get_u16_str_PARM_2'
                                    652 ;curr_num      Allocated with name '_get_u16_str_curr_num_10000_718'
                                    653 ;buf           Allocated with name '_get_u16_str_buf_10000_719'
                                    654 ;last_num      Allocated with name '_get_u16_str_last_num_10000_719'
                                    655 ;last_pad      Allocated with name '_get_u16_str_last_pad_10000_719'
                                    656 ;------------------------------------------------------------
                                    657 ;	quantum/quantum.c:809: static uint16_t last_num = 0xFF;
      0030F9 90 0C 30         [24]  658 	mov	dptr,#_get_u16_str_last_num_10000_719
      0030FC 74 FF            [12]  659 	mov	a,#0xff
      0030FE F0               [24]  660 	movx	@dptr,a
      0030FF E4               [12]  661 	clr	a
      003100 A3               [24]  662 	inc	dptr
      003101 F0               [24]  663 	movx	@dptr,a
                                    664 ;--------------------------------------------------------
                                    665 ; Home
                                    666 ;--------------------------------------------------------
                                    667 	.area HOME    (CODE)
                                    668 	.area HOME    (CODE)
                                    669 ;--------------------------------------------------------
                                    670 ; code
                                    671 ;--------------------------------------------------------
                                    672 	.area CSEG    (CODE)
                                    673 ;------------------------------------------------------------
                                    674 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    675 ;------------------------------------------------------------
                                    676 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_193'
                                    677 ;------------------------------------------------------------
                                    678 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    679 ;	-----------------------------------------
                           000007   680 	ar7 = 0x07
                           000006   681 	ar6 = 0x06
                           000005   682 	ar5 = 0x05
                           000004   683 	ar4 = 0x04
                           000003   684 	ar3 = 0x03
                           000002   685 	ar2 = 0x02
                           000001   686 	ar1 = 0x01
                           000000   687 	ar0 = 0x00
                                    688 ;	 function extract_mod_bits
                                    689 ;	-----------------------------------------
      00A0BC                        690 _extract_mod_bits:
      00A0BC 12 38 52         [24]  691 	lcall	_ak820_outline_0106
      00A0BF 90 0C 19         [24]  692 	mov	dptr,#_extract_mod_bits_code_10000_623
      00A0C2 12 38 57         [24]  693 	lcall	_ak820_outline_0107
                                    694 ;	quantum/quantum.c:113: uint8_t mods = (uint8_t)(code >> 8);
      00A0C5 90 0C 19         [24]  695 	mov	dptr,#_extract_mod_bits_code_10000_623
      00A0C8 E0               [24]  696 	movx	a,@dptr
      00A0C9 A3               [24]  697 	inc	dptr
      00A0CA E0               [24]  698 	movx	a,@dptr
                                    699 ;	quantum/quantum.c:114: if (!mods || mods > (QK_MODS_MAX >> 8)) return 0;
      00A0CB FF               [12]  700 	mov	r7,a
      00A0CC 60 05            [24]  701 	jz	00101$
      00A0CE EF               [12]  702 	mov	a,r7
      00A0CF 24 E0            [12]  703 	add	a,#0xff - 0x1f
      00A0D1 50 04            [24]  704 	jnc	00102$
                                    705 ;	free result
      00A0D3                        706 00101$:
      00A0D3 75 82 00         [24]  707 	mov	dpl, #0x00
      00A0D6 22               [24]  708 	ret
      00A0D7                        709 00102$:
                                    710 ;	quantum/quantum.c:115: return (mods & 0x10) ? (uint8_t)(mods << 4) : mods;
      00A0D7 EF               [12]  711 	mov	a,r7
      00A0D8 30 E4 07         [24]  712 	jnb	acc.4,00106$
      00A0DB EF               [12]  713 	mov	a,r7
      00A0DC C4               [12]  714 	swap	a
      00A0DD 54 F0            [12]  715 	anl	a,#0xf0
      00A0DF FE               [12]  716 	mov	r6,a
      00A0E0 80 02            [24]  717 	sjmp	00107$
      00A0E2                        718 00106$:
      00A0E2 8F 06            [24]  719 	mov	ar6,r7
      00A0E4                        720 00107$:
      00A0E4 8E 82            [24]  721 	mov	dpl, r6
                                    722 ;	quantum/quantum.c:143: }
      00A0E6 22               [24]  723 	ret
                                    724 ;------------------------------------------------------------
                                    725 ;Allocation info for local variables in function 'do_code16'
                                    726 ;------------------------------------------------------------
                                    727 ;f             Allocated with name '_do_code16_PARM_2'
                                    728 ;code          Allocated with name '_do_code16_code_10000_626'
                                    729 ;------------------------------------------------------------
                                    730 ;	quantum/quantum.c:145: void do_code16(uint16_t code, void (*f)(uint8_t)) {
                                    731 ;	-----------------------------------------
                                    732 ;	 function register_code16
                                    733 ;	-----------------------------------------
      00A0E7                        734 _register_code16:
      00A0E7 12 38 52         [24]  735 	lcall	_ak820_outline_0106
      00A0EA 90 0C 1B         [24]  736 	mov	dptr,#_register_code16_code_10000_629
      00A0ED 12 38 57         [24]  737 	lcall	_ak820_outline_0107
                                    738 ;	quantum/quantum.c:151: uint8_t mods = extract_mod_bits(code);
      00A0F0 90 0C 1B         [24]  739 	mov	dptr,#_register_code16_code_10000_629
      00A0F3 12 37 A5         [24]  740 	lcall	_ak820_outline_0004
      00A0F6 C0 07            [24]  741 	push	ar7
      00A0F8 C0 06            [24]  742 	push	ar6
      00A0FA 11 BC            [12]  743 	acall	_extract_mod_bits
      00A0FC AD 82            [24]  744 	mov	r5, dpl
      00A0FE D0 06            [24]  745 	pop	ar6
      00A100 D0 07            [24]  746 	pop	ar7
                                    747 ;	quantum/quantum.c:152: if (IS_MODIFIER_KEYCODE(code) || code == KC_NO) {
      00A102 12 9E F8         [24]  748 	lcall	_ak820_outline_0122
      00A105 40 07            [24]  749 	jc	00105$
      00A107 74 E7            [12]  750 	mov	a,#0xe7
      00A109 9E               [12]  751 	subb	a,r6
      00A10A E4               [12]  752 	clr	a
      00A10B 9F               [12]  753 	subb	a,r7
      00A10C 50 08            [24]  754 	jnc	00101$
                                    755 ;	free result
      00A10E                        756 00105$:
      00A10E 90 0C 1B         [24]  757 	mov	dptr,#_register_code16_code_10000_629
      00A111 12 71 8A         [24]  758 	lcall	_ak820_outline_0036
      00A114 70 07            [24]  759 	jnz	00102$
      00A116                        760 00101$:
                                    761 ;	quantum/quantum.c:153: register_mods(mods);
      00A116 8D 82            [24]  762 	mov	dpl, r5
      00A118 12 79 F5         [24]  763 	lcall	_register_mods
      00A11B 80 05            [24]  764 	sjmp	00103$
      00A11D                        765 00102$:
                                    766 ;	quantum/quantum.c:155: register_weak_mods(mods);
      00A11D 8D 82            [24]  767 	mov	dpl, r5
      00A11F 12 7A 1D         [24]  768 	lcall	_register_weak_mods
      00A122                        769 00103$:
                                    770 ;	quantum/quantum.c:157: register_code(code);
      00A122 90 0C 1B         [24]  771 	mov	dptr,#_register_code16_code_10000_629
      00A125 E0               [24]  772 	movx	a,@dptr
      00A126 F5 82            [12]  773 	mov	dpl,a
                                    774 ;	quantum/quantum.c:167: }
      00A128 02 78 C6         [24]  775 	ljmp	_register_code
                                    776 ;------------------------------------------------------------
                                    777 ;Allocation info for local variables in function 'unregister_code16'
                                    778 ;------------------------------------------------------------
                                    779 ;code          Allocated with name '_unregister_code16_code_10000_634'
                                    780 ;mods          Allocated with name '_unregister_code16_mods_10000_635'
                                    781 ;------------------------------------------------------------
                                    782 ;	quantum/quantum.c:169: __attribute__((weak)) void unregister_code16(uint16_t code) {
                                    783 ;	-----------------------------------------
                                    784 ;	 function unregister_code16
                                    785 ;	-----------------------------------------
      00A12B                        786 _unregister_code16:
      00A12B 12 38 52         [24]  787 	lcall	_ak820_outline_0106
      00A12E 90 0C 1D         [24]  788 	mov	dptr,#_unregister_code16_code_10000_634
      00A131 12 38 57         [24]  789 	lcall	_ak820_outline_0107
                                    790 ;	quantum/quantum.c:171: uint8_t mods = extract_mod_bits(code);
      00A134 90 0C 1D         [24]  791 	mov	dptr,#_unregister_code16_code_10000_634
      00A137 12 37 A5         [24]  792 	lcall	_ak820_outline_0004
      00A13A C0 07            [24]  793 	push	ar7
      00A13C C0 06            [24]  794 	push	ar6
      00A13E 11 BC            [12]  795 	acall	_extract_mod_bits
      00A140 AD 82            [24]  796 	mov	r5, dpl
      00A142 D0 06            [24]  797 	pop	ar6
                                    798 ;	quantum/quantum.c:172: unregister_code(code);
      00A144 8E 04            [24]  799 	mov	ar4,r6
      00A146 8C 82            [24]  800 	mov	dpl, r4
      00A148 C0 06            [24]  801 	push	ar6
      00A14A C0 05            [24]  802 	push	ar5
      00A14C 12 79 33         [24]  803 	lcall	_unregister_code
      00A14F D0 05            [24]  804 	pop	ar5
      00A151 D0 06            [24]  805 	pop	ar6
      00A153 D0 07            [24]  806 	pop	ar7
                                    807 ;	quantum/quantum.c:173: if (IS_MODIFIER_KEYCODE(code) || code == KC_NO) {
      00A155 12 9E F8         [24]  808 	lcall	_ak820_outline_0122
      00A158 40 07            [24]  809 	jc	00105$
      00A15A 74 E7            [12]  810 	mov	a,#0xe7
      00A15C 9E               [12]  811 	subb	a,r6
      00A15D E4               [12]  812 	clr	a
      00A15E 9F               [12]  813 	subb	a,r7
      00A15F 50 08            [24]  814 	jnc	00101$
                                    815 ;	free result
      00A161                        816 00105$:
      00A161 90 0C 1D         [24]  817 	mov	dptr,#_unregister_code16_code_10000_634
      00A164 12 71 8A         [24]  818 	lcall	_ak820_outline_0036
      00A167 70 05            [24]  819 	jnz	00102$
      00A169                        820 00101$:
                                    821 ;	quantum/quantum.c:174: unregister_mods(mods);
      00A169 8D 82            [24]  822 	mov	dpl, r5
      00A16B 02 7A 09         [24]  823 	ljmp	_unregister_mods
      00A16E                        824 00102$:
                                    825 ;	quantum/quantum.c:176: unregister_weak_mods(mods);
      00A16E 8D 82            [24]  826 	mov	dpl, r5
                                    827 ;	quantum/quantum.c:187: }
      00A170 02 7A 31         [24]  828 	ljmp	_unregister_weak_mods
                                    829 ;------------------------------------------------------------
                                    830 ;Allocation info for local variables in function 'tap_code16_delay'
                                    831 ;------------------------------------------------------------
                                    832 ;delay         Allocated with name '_tap_code16_delay_PARM_2'
                                    833 ;code          Allocated with name '_tap_code16_delay_code_10000_639'
                                    834 ;i             Allocated with name '_tap_code16_delay_i_20000_641'
                                    835 ;i             Allocated with name '_tap_code16_delay_i_50000_644'
                                    836 ;------------------------------------------------------------
                                    837 ;	quantum/quantum.c:194: __attribute__((weak)) void tap_code16_delay(uint16_t code, uint16_t delay) {
                                    838 ;	-----------------------------------------
                                    839 ;	 function shutdown_quantum
                                    840 ;	-----------------------------------------
      00A173                        841 _shutdown_quantum:
                                    842 ;	quantum/quantum.c:237: clear_keyboard();
      00A173 12 7A 45         [24]  843 	lcall	_clear_keyboard
                                    844 ;	quantum/quantum.c:252: shutdown_user();
      00A176 71 EB            [12]  845 	acall	_shutdown_user
                                    846 ;	quantum/quantum.c:253: wait_ms(250);
      00A178 7F FA            [12]  847 	mov	r7,#0xfa
      00A17A                        848 00106$:
      00A17A EF               [12]  849 	mov	a,r7
      00A17B 60 09            [24]  850 	jz	00108$
      00A17D 90 00 01         [24]  851 	mov	dptr,#0x0001
      00A180 12 5C F8         [24]  852 	lcall	_mDelaymS
      00A183 1F               [12]  853 	dec	r7
      00A184 80 F4            [24]  854 	sjmp	00106$
      00A186                        855 00108$:
                                    856 ;	quantum/quantum.c:258: }
      00A186 22               [24]  857 	ret
                                    858 ;------------------------------------------------------------
                                    859 ;Allocation info for local variables in function 'reset_keyboard'
                                    860 ;------------------------------------------------------------
                                    861 ;	quantum/quantum.c:260: void reset_keyboard(void) {
                                    862 ;	-----------------------------------------
                                    863 ;	 function reset_keyboard
                                    864 ;	-----------------------------------------
      00A187                        865 _reset_keyboard:
                                    866 ;	quantum/quantum.c:261: shutdown_quantum();
      00A187 31 73            [12]  867 	acall	_shutdown_quantum
                                    868 ;	quantum/quantum.c:262: bootloader_jump();
                                    869 ;	quantum/quantum.c:263: }
      00A189 02 34 0E         [24]  870 	ljmp	_bootloader_jump
                                    871 ;------------------------------------------------------------
                                    872 ;Allocation info for local variables in function 'soft_reset_keyboard'
                                    873 ;------------------------------------------------------------
                                    874 ;	quantum/quantum.c:265: void soft_reset_keyboard(void) {
                                    875 ;	-----------------------------------------
                                    876 ;	 function soft_reset_keyboard
                                    877 ;	-----------------------------------------
      00A18C                        878 _soft_reset_keyboard:
                                    879 ;	quantum/quantum.c:266: shutdown_quantum();
      00A18C 31 73            [12]  880 	acall	_shutdown_quantum
                                    881 ;	quantum/quantum.c:267: mcu_reset();
                                    882 ;	quantum/quantum.c:268: }
      00A18E 02 34 01         [24]  883 	ljmp	_mcu_reset
                                    884 ;------------------------------------------------------------
                                    885 ;Allocation info for local variables in function 'get_record_keycode'
                                    886 ;------------------------------------------------------------
                                    887 ;update_layer_cache Allocated with name '_get_record_keycode_PARM_2'
                                    888 ;record_argument Allocated with name '_get_record_keycode_record_argument_10000_672'
                                    889 ;record        Allocated with name '_get_record_keycode_record_10000_673'
                                    890 ;------------------------------------------------------------
                                    891 ;	quantum/quantum.c:271: uint16_t get_record_keycode(keyrecord_t AK820_RECORD_MEM *record_argument, bool update_layer_cache) {
                                    892 ;	-----------------------------------------
                                    893 ;	 function get_record_keycode
                                    894 ;	-----------------------------------------
      00A191                        895 _get_record_keycode:
      00A191 12 38 52         [24]  896 	lcall	_ak820_outline_0106
      00A194 90 0C 20         [24]  897 	mov	dptr,#_get_record_keycode_record_argument_10000_672
      00A197 12 38 57         [24]  898 	lcall	_ak820_outline_0107
                                    899 ;	quantum/quantum.c:273: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A19A 90 0C 20         [24]  900 	mov	dptr,#_get_record_keycode_record_argument_10000_672
      00A19D 12 37 BC         [24]  901 	lcall	_ak820_outline_0009
                                    902 ;	quantum/quantum.c:278: if (record->keycode) {
      00A1A0 4C               [12]  903 	orl	a,r4
      00A1A1 60 04            [24]  904 	jz	00102$
                                    905 ;	quantum/quantum.c:279: return record->keycode;
      00A1A3 12 38 5C         [24]  906 	lcall	_ak820_outline_0125
      00A1A6 22               [24]  907 	ret
      00A1A7                        908 00102$:
                                    909 ;	quantum/quantum.c:283: return ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed && update_layer_cache);
      00A1A7 12 7A 84         [24]  910 	lcall	_ak820_outline_0021
      00A1AA 7A 00            [12]  911 	mov	r2,#0x00
      00A1AC 12 43 41         [24]  912 	lcall	_ak820_outline_0147
      00A1AF 12 37 AF         [24]  913 	lcall	_ak820_outline_0005
      00A1B2 60 06            [24]  914 	jz	00105$
      00A1B4 90 0C 1F         [24]  915 	mov	dptr,#_get_record_keycode_PARM_2
      00A1B7 E0               [24]  916 	movx	a,@dptr
      00A1B8 70 04            [24]  917 	jnz	00106$
      00A1BA                        918 00105$:
                                    919 ;	assignBit
      00A1BA C2 24            [12]  920 	clr	_get_record_keycode_sloc0_1_0
      00A1BC 80 02            [24]  921 	sjmp	00107$
      00A1BE                        922 00106$:
                                    923 ;	assignBit
      00A1BE D2 24            [12]  924 	setb	_get_record_keycode_sloc0_1_0
      00A1C0                        925 00107$:
      00A1C0 90 09 AE         [24]  926 	mov	dptr,#_ak820_resolve_key_PARM_2
      00A1C3 A2 24            [12]  927 	mov	c,_get_record_keycode_sloc0_1_0
      00A1C5 E4               [12]  928 	clr	a
      00A1C6 33               [12]  929 	rlc	a
      00A1C7 F0               [24]  930 	movx	@dptr,a
      00A1C8 12 43 5C         [24]  931 	lcall	_ak820_outline_0186
                                    932 ;	quantum/quantum.c:287: }
      00A1CB 02 7E 08         [24]  933 	ljmp	_ak820_resolve_key
                                    934 ;------------------------------------------------------------
                                    935 ;Allocation info for local variables in function 'get_event_keycode'
                                    936 ;------------------------------------------------------------
                                    937 ;event         Allocated with name '_get_event_keycode_PARM_1'
                                    938 ;update_layer_cache Allocated with name '_get_event_keycode_update_layer_cache_10000_676'
                                    939 ;------------------------------------------------------------
                                    940 ;	quantum/quantum.c:295: uint16_t get_event_keycode(keyevent_t event, bool update_layer_cache) {
                                    941 ;	-----------------------------------------
                                    942 ;	 function pre_process_record_quantum
                                    943 ;	-----------------------------------------
      00A1CE                        944 _pre_process_record_quantum:
      00A1CE 12 38 52         [24]  945 	lcall	_ak820_outline_0106
      00A1D1 90 0C 22         [24]  946 	mov	dptr,#_pre_process_record_quantum_record_argument_10000_678
      00A1D4 12 38 57         [24]  947 	lcall	_ak820_outline_0107
                                    948 ;	quantum/quantum.c:328: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A1D7 90 0C 22         [24]  949 	mov	dptr,#_pre_process_record_quantum_record_argument_10000_678
      00A1DA 12 37 FC         [24]  950 	lcall	_ak820_outline_0051
                                    951 ;	quantum/quantum.c:332: uint16_t keycode = get_record_keycode(record, true);
      00A1DD 90 0C 1F         [24]  952 	mov	dptr,#_get_record_keycode_PARM_2
      00A1E0 12 4C EA         [24]  953 	lcall	_ak820_outline_0055
      00A1E3 C0 07            [24]  954 	push	ar7
      00A1E5 C0 06            [24]  955 	push	ar6
      00A1E7 31 91            [12]  956 	acall	_get_record_keycode
      00A1E9 12 38 71         [24]  957 	lcall	_ak820_outline_0149
      00A1EC D0 06            [24]  958 	pop	ar6
      00A1EE D0 07            [24]  959 	pop	ar7
                                    960 ;	quantum/quantum.c:334: record->keycode = keycode;
      00A1F0 74 07            [12]  961 	mov	a,#0x07
      00A1F2 12 37 EC         [24]  962 	lcall	_ak820_outline_0017
      00A1F5 EC               [12]  963 	mov	a,r4
      00A1F6 F0               [24]  964 	movx	@dptr,a
      00A1F7 ED               [12]  965 	mov	a,r5
      00A1F8 A3               [24]  966 	inc	dptr
      00A1F9 12 42 F9         [24]  967 	lcall	_ak820_outline_0061
                                    968 ;	quantum/quantum.c:361: ak820_combo_process((keyrecord_t AK820_STATE_MEM *)record) &&
      00A1FC 12 35 FA         [24]  969 	lcall	_ak820_combo_process
      00A1FF E5 82            [12]  970 	mov	a, dpl
      00A201 70 04            [24]  971 	jnz	00104$
                                    972 ;	quantum/quantum.c:366: true;
                                    973 ;	assignBit
      00A203 C2 25            [12]  974 	clr	_pre_process_record_quantum_sloc0_1_0
      00A205 80 02            [24]  975 	sjmp	00105$
      00A207                        976 00104$:
                                    977 ;	assignBit
      00A207 D2 25            [12]  978 	setb	_pre_process_record_quantum_sloc0_1_0
      00A209                        979 00105$:
      00A209 A2 25            [12]  980 	mov	c,_pre_process_record_quantum_sloc0_1_0
      00A20B 12 38 7B         [24]  981 	lcall	_ak820_outline_0160
                                    982 ;	quantum/quantum.c:367: }
      00A20E 22               [24]  983 	ret
                                    984 ;------------------------------------------------------------
                                    985 ;Allocation info for local variables in function 'post_process_record_quantum'
                                    986 ;------------------------------------------------------------
                                    987 ;record        Allocated with name '_post_process_record_quantum_record_10000_680'
                                    988 ;keycode       Allocated with name '_post_process_record_quantum_keycode_10000_681'
                                    989 ;------------------------------------------------------------
                                    990 ;	quantum/quantum.c:370: void post_process_record_quantum(keyrecord_t AK820_RECORD_MEM *record) {
                                    991 ;	-----------------------------------------
                                    992 ;	 function process_record_quantum
                                    993 ;	-----------------------------------------
      00A20F                        994 _process_record_quantum:
      00A20F 12 38 52         [24]  995 	lcall	_ak820_outline_0106
      00A212 90 0C 24         [24]  996 	mov	dptr,#_process_record_quantum_record_10000_682
      00A215 12 38 57         [24]  997 	lcall	_ak820_outline_0107
                                    998 ;	quantum/quantum.c:377: uint16_t keycode = get_record_keycode(record, false);
      00A218 90 0C 24         [24]  999 	mov	dptr,#_process_record_quantum_record_10000_682
      00A21B 12 37 FC         [24] 1000 	lcall	_ak820_outline_0051
      00A21E 90 0C 1F         [24] 1001 	mov	dptr,#_get_record_keycode_PARM_2
      00A221 E4               [12] 1002 	clr	a
      00A222 12 42 F9         [24] 1003 	lcall	_ak820_outline_0061
      00A225 31 91            [12] 1004 	acall	_get_record_keycode
      00A227 12 43 30         [24] 1005 	lcall	_ak820_outline_0135
                                   1006 ;	quantum/quantum.c:381: return process_record_quantum_helper(keycode, record);
      00A22A 90 0C 24         [24] 1007 	mov	dptr,#_process_record_quantum_record_10000_682
      00A22D 12 38 1B         [24] 1008 	lcall	_ak820_outline_0059
      00A230 90 0C 2B         [24] 1009 	mov	dptr,#_process_record_quantum_helper_PARM_2
      00A233 EC               [12] 1010 	mov	a,r4
      00A234 F0               [24] 1011 	movx	@dptr,a
      00A235 ED               [12] 1012 	mov	a,r5
      00A236 A3               [24] 1013 	inc	dptr
      00A237 12 42 F9         [24] 1014 	lcall	_ak820_outline_0061
                                   1015 ;	quantum/quantum.c:382: }
      00A23A 41 A7            [24] 1016 	ajmp	_process_record_quantum_helper
                                   1017 ;------------------------------------------------------------
                                   1018 ;Allocation info for local variables in function 'process_ak820_nkro'
                                   1019 ;------------------------------------------------------------
                                   1020 ;record_argument Allocated with name '_process_ak820_nkro_PARM_2'
                                   1021 ;keycode       Allocated with name '_process_ak820_nkro_keycode_10000_684'
                                   1022 ;record        Allocated with name '_process_ak820_nkro_record_10000_685'
                                   1023 ;------------------------------------------------------------
                                   1024 ;	quantum/quantum.c:399: static bool process_ak820_nkro(uint16_t keycode, keyrecord_t *record_argument) {
                                   1025 ;	-----------------------------------------
                                   1026 ;	 function process_ak820_nkro
                                   1027 ;	-----------------------------------------
      00A23C                       1028 _process_ak820_nkro:
      00A23C 12 38 52         [24] 1029 	lcall	_ak820_outline_0106
      00A23F 90 0C 29         [24] 1030 	mov	dptr,#_process_ak820_nkro_keycode_10000_684
      00A242 12 38 57         [24] 1031 	lcall	_ak820_outline_0107
                                   1032 ;	quantum/quantum.c:401: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A245 90 0C 26         [24] 1033 	mov	dptr,#_process_ak820_nkro_PARM_2
      00A248 12 37 FC         [24] 1034 	lcall	_ak820_outline_0051
                                   1035 ;	quantum/quantum.c:405: if (keycode < QK_MAGIC_NKRO_ON || keycode > QK_MAGIC_TOGGLE_NKRO) return true;
      00A24B 90 0C 29         [24] 1036 	mov	dptr,#_process_ak820_nkro_keycode_10000_684
      00A24E 12 38 1B         [24] 1037 	lcall	_ak820_outline_0059
      00A251 C3               [12] 1038 	clr	c
      00A252 EC               [12] 1039 	mov	a,r4
      00A253 94 11            [12] 1040 	subb	a,#0x11
      00A255 ED               [12] 1041 	mov	a,r5
      00A256 94 70            [12] 1042 	subb	a,#0x70
      00A258 40 08            [24] 1043 	jc	00101$
      00A25A 74 13            [12] 1044 	mov	a,#0x13
      00A25C 9C               [12] 1045 	subb	a,r4
      00A25D 74 70            [12] 1046 	mov	a,#0x70
      00A25F 9D               [12] 1047 	subb	a,r5
      00A260 50 04            [24] 1048 	jnc	00102$
                                   1049 ;	free result
      00A262                       1050 00101$:
      00A262 75 82 01         [24] 1051 	mov	dpl, #0x01
      00A265 22               [24] 1052 	ret
      00A266                       1053 00102$:
                                   1054 ;	quantum/quantum.c:406: if (record->event.pressed) {
      00A266 12 37 AF         [24] 1055 	lcall	_ak820_outline_0005
      00A269 60 38            [24] 1056 	jz	00105$
                                   1057 ;	quantum/quantum.c:407: clear_keyboard();
      00A26B C0 05            [24] 1058 	push	ar5
      00A26D C0 04            [24] 1059 	push	ar4
      00A26F 12 7A 45         [24] 1060 	lcall	_clear_keyboard
      00A272 D0 04            [24] 1061 	pop	ar4
      00A274 D0 05            [24] 1062 	pop	ar5
                                   1063 ;	quantum/quantum.c:408: keymap_config.nkro = keycode == QK_MAGIC_TOGGLE_NKRO ? !keymap_config.nkro : keycode == QK_MAGIC_NKRO_ON;
      00A276 BC 13 14         [24] 1064 	cjne	r4,#0x13,00108$
      00A279 BD 70 11         [24] 1065 	cjne	r5,#0x70,00108$
      00A27C 90 0B 00         [24] 1066 	mov	dptr,#_keymap_config
      00A27F E0               [24] 1067 	movx	a,@dptr
      00A280 23               [12] 1068 	rl	a
      00A281 54 01            [12] 1069 	anl	a,#0x01
      00A283 B4 01 00         [24] 1070 	cjne	a,#0x01,00136$
      00A286                       1071 00136$:
      00A286 92 26            [24] 1072 	mov  _process_ak820_nkro_sloc0_1_0,c
      00A288 E4               [12] 1073 	clr	a
      00A289 33               [12] 1074 	rlc	a
      00A28A FF               [12] 1075 	mov	r7,a
      00A28B 80 09            [24] 1076 	sjmp	00109$
      00A28D                       1077 00108$:
      00A28D E4               [12] 1078 	clr	a
      00A28E BC 11 04         [24] 1079 	cjne	r4,#0x11,00137$
      00A291 BD 70 01         [24] 1080 	cjne	r5,#0x70,00137$
      00A294 04               [12] 1081 	inc	a
      00A295                       1082 00137$:
      00A295 FF               [12] 1083 	mov	r7,a
      00A296                       1084 00109$:
                                   1085 ;	assignBit
      00A296 EF               [12] 1086 	mov	a,r7
      00A297 24 FF            [12] 1087 	add	a,#0xff
      00A299 E4               [12] 1088 	clr	a
      00A29A 33               [12] 1089 	rlc	a
      00A29B 90 0B 00         [24] 1090 	mov	dptr,#_keymap_config
      00A29E 13               [12] 1091 	rrc	a
      00A29F E0               [24] 1092 	movx	a,@dptr
      00A2A0 92 E7            [24] 1093 	mov	acc.7,c
      00A2A2 F0               [24] 1094 	movx	@dptr,a
      00A2A3                       1095 00105$:
                                   1096 ;	quantum/quantum.c:410: return false;
      00A2A3 75 82 00         [24] 1097 	mov	dpl, #0x00
                                   1098 ;	quantum/quantum.c:411: }
      00A2A6 22               [24] 1099 	ret
                                   1100 ;------------------------------------------------------------
                                   1101 ;Allocation info for local variables in function 'process_record_quantum_helper'
                                   1102 ;------------------------------------------------------------
                                   1103 ;record_argument Allocated with name '_process_record_quantum_helper_PARM_2'
                                   1104 ;keycode       Allocated with name '_process_record_quantum_helper_keycode_10000_689'
                                   1105 ;record        Allocated with name '_process_record_quantum_helper_record_10000_690'
                                   1106 ;------------------------------------------------------------
                                   1107 ;	quantum/quantum.c:414: bool process_record_quantum_helper(uint16_t keycode, keyrecord_t AK820_RECORD_MEM *record_argument) {
                                   1108 ;	-----------------------------------------
                                   1109 ;	 function process_record_quantum_helper
                                   1110 ;	-----------------------------------------
      00A2A7                       1111 _process_record_quantum_helper:
      00A2A7 12 38 52         [24] 1112 	lcall	_ak820_outline_0106
      00A2AA 90 0C 2D         [24] 1113 	mov	dptr,#_process_record_quantum_helper_keycode_10000_689
      00A2AD 12 38 57         [24] 1114 	lcall	_ak820_outline_0107
                                   1115 ;	quantum/quantum.c:416: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A2B0 90 0C 2B         [24] 1116 	mov	dptr,#_process_record_quantum_helper_PARM_2
      00A2B3 12 37 FC         [24] 1117 	lcall	_ak820_outline_0051
                                   1118 ;	quantum/quantum.c:459: process_ak820_nkro(keycode, record) &&
      00A2B6 90 0C 2D         [24] 1119 	mov	dptr,#_process_record_quantum_helper_keycode_10000_689
      00A2B9 12 38 1B         [24] 1120 	lcall	_ak820_outline_0059
      00A2BC 90 0C 26         [24] 1121 	mov	dptr,#_process_ak820_nkro_PARM_2
      00A2BF 12 A3 EC         [24] 1122 	lcall	_ak820_outline_0006
      00A2C2 C0 07            [24] 1123 	push	ar7
      00A2C4 C0 06            [24] 1124 	push	ar6
      00A2C6 C0 05            [24] 1125 	push	ar5
      00A2C8 C0 04            [24] 1126 	push	ar4
      00A2CA 51 3C            [24] 1127 	acall	_process_ak820_nkro
      00A2CC E5 82            [12] 1128 	mov	a, dpl
      00A2CE D0 04            [24] 1129 	pop	ar4
      00A2D0 D0 05            [24] 1130 	pop	ar5
      00A2D2 D0 06            [24] 1131 	pop	ar6
      00A2D4 D0 07            [24] 1132 	pop	ar7
      00A2D6 70 02            [24] 1133 	jnz	00196$
      00A2D8 61 B1            [24] 1134 	ajmp	00101$
      00A2DA                       1135 00196$:
                                   1136 ;	quantum/quantum.c:470: process_last_key(keycode, record) && process_repeat_key(keycode, record) &&
      00A2DA 90 0C 04         [24] 1137 	mov	dptr,#_process_last_key_PARM_2
      00A2DD 12 4C FA         [24] 1138 	lcall	_ak820_outline_0060
      00A2E0 12 38 5C         [24] 1139 	lcall	_ak820_outline_0125
      00A2E3 C0 07            [24] 1140 	push	ar7
      00A2E5 C0 06            [24] 1141 	push	ar6
      00A2E7 C0 05            [24] 1142 	push	ar5
      00A2E9 C0 04            [24] 1143 	push	ar4
      00A2EB 12 9E 39         [24] 1144 	lcall	_process_last_key
      00A2EE E5 82            [12] 1145 	mov	a, dpl
      00A2F0 D0 04            [24] 1146 	pop	ar4
      00A2F2 D0 05            [24] 1147 	pop	ar5
      00A2F4 D0 06            [24] 1148 	pop	ar6
      00A2F6 D0 07            [24] 1149 	pop	ar7
      00A2F8 70 02            [24] 1150 	jnz	00197$
      00A2FA 61 B1            [24] 1151 	ajmp	00101$
      00A2FC                       1152 00197$:
      00A2FC 90 0C 09         [24] 1153 	mov	dptr,#_process_repeat_key_PARM_2
      00A2FF 12 4C FA         [24] 1154 	lcall	_ak820_outline_0060
      00A302 12 38 5C         [24] 1155 	lcall	_ak820_outline_0125
      00A305 C0 07            [24] 1156 	push	ar7
      00A307 C0 06            [24] 1157 	push	ar6
      00A309 C0 05            [24] 1158 	push	ar5
      00A30B C0 04            [24] 1159 	push	ar4
      00A30D 12 9E B1         [24] 1160 	lcall	_process_repeat_key
      00A310 E5 82            [12] 1161 	mov	a, dpl
      00A312 D0 04            [24] 1162 	pop	ar4
      00A314 D0 05            [24] 1163 	pop	ar5
      00A316 D0 06            [24] 1164 	pop	ar6
      00A318 D0 07            [24] 1165 	pop	ar7
      00A31A 70 02            [24] 1166 	jnz	00198$
      00A31C 61 B1            [24] 1167 	ajmp	00101$
      00A31E                       1168 00198$:
                                   1169 ;	quantum/quantum.c:479: process_record_via(keycode, record) &&
      00A31E 90 0C 66         [24] 1170 	mov	dptr,#_process_record_via_PARM_2
      00A321 12 A3 EC         [24] 1171 	lcall	_ak820_outline_0006
      00A324 C0 07            [24] 1172 	push	ar7
      00A326 C0 06            [24] 1173 	push	ar6
      00A328 C0 05            [24] 1174 	push	ar5
      00A32A C0 04            [24] 1175 	push	ar4
      00A32C 12 A8 C7         [24] 1176 	lcall	_process_record_via
      00A32F E5 82            [12] 1177 	mov	a, dpl
      00A331 D0 04            [24] 1178 	pop	ar4
      00A333 D0 05            [24] 1179 	pop	ar5
      00A335 D0 06            [24] 1180 	pop	ar6
      00A337 D0 07            [24] 1181 	pop	ar7
      00A339 70 02            [24] 1182 	jnz	00199$
      00A33B 61 B1            [24] 1183 	ajmp	00101$
      00A33D                       1184 00199$:
                                   1185 ;	quantum/quantum.c:514: process_caps_word(keycode, record) &&
      00A33D 90 0B EC         [24] 1186 	mov	dptr,#_process_caps_word_PARM_2
      00A340 12 A3 EC         [24] 1187 	lcall	_ak820_outline_0006
      00A343 C0 07            [24] 1188 	push	ar7
      00A345 C0 06            [24] 1189 	push	ar6
      00A347 C0 05            [24] 1190 	push	ar5
      00A349 C0 04            [24] 1191 	push	ar4
      00A34B 12 9B 56         [24] 1192 	lcall	_process_caps_word
      00A34E E5 82            [12] 1193 	mov	a, dpl
      00A350 D0 04            [24] 1194 	pop	ar4
      00A352 D0 05            [24] 1195 	pop	ar5
      00A354 D0 06            [24] 1196 	pop	ar6
      00A356 D0 07            [24] 1197 	pop	ar7
      00A358 60 57            [24] 1198 	jz	00101$
                                   1199 ;	quantum/quantum.c:544: process_grave_esc(keycode, record) &&
      00A35A 90 0B F1         [24] 1200 	mov	dptr,#_process_grave_esc_PARM_2
      00A35D 12 A3 EC         [24] 1201 	lcall	_ak820_outline_0006
      00A360 C0 07            [24] 1202 	push	ar7
      00A362 C0 06            [24] 1203 	push	ar6
      00A364 C0 05            [24] 1204 	push	ar5
      00A366 C0 04            [24] 1205 	push	ar4
      00A368 12 9C 6E         [24] 1206 	lcall	_process_grave_esc
      00A36B E5 82            [12] 1207 	mov	a, dpl
      00A36D D0 04            [24] 1208 	pop	ar4
      00A36F D0 05            [24] 1209 	pop	ar5
      00A371 D0 06            [24] 1210 	pop	ar6
      00A373 D0 07            [24] 1211 	pop	ar7
      00A375 60 3A            [24] 1212 	jz	00101$
                                   1213 ;	quantum/quantum.c:547: process_rgb(keycode, record) &&
      00A377 90 0C 0D         [24] 1214 	mov	dptr,#_process_rgb_PARM_2
      00A37A 12 A3 EC         [24] 1215 	lcall	_ak820_outline_0006
      00A37D C0 07            [24] 1216 	push	ar7
      00A37F C0 06            [24] 1217 	push	ar6
      00A381 C0 05            [24] 1218 	push	ar5
      00A383 C0 04            [24] 1219 	push	ar4
      00A385 12 9F 00         [24] 1220 	lcall	_process_rgb
      00A388 E5 82            [12] 1221 	mov	a, dpl
      00A38A D0 04            [24] 1222 	pop	ar4
      00A38C D0 05            [24] 1223 	pop	ar5
      00A38E D0 06            [24] 1224 	pop	ar6
      00A390 D0 07            [24] 1225 	pop	ar7
      00A392 60 1D            [24] 1226 	jz	00101$
                                   1227 ;	quantum/quantum.c:559: process_tri_layer(keycode, record) &&
      00A394 90 0C 13         [24] 1228 	mov	dptr,#_process_tri_layer_PARM_2
      00A397 12 A3 EC         [24] 1229 	lcall	_ak820_outline_0006
      00A39A C0 07            [24] 1230 	push	ar7
      00A39C C0 06            [24] 1231 	push	ar6
      00A39E C0 05            [24] 1232 	push	ar5
      00A3A0 C0 04            [24] 1233 	push	ar4
      00A3A2 12 9F B1         [24] 1234 	lcall	_process_tri_layer
      00A3A5 E5 82            [12] 1235 	mov	a, dpl
      00A3A7 D0 04            [24] 1236 	pop	ar4
      00A3A9 D0 05            [24] 1237 	pop	ar5
      00A3AB D0 06            [24] 1238 	pop	ar6
      00A3AD D0 07            [24] 1239 	pop	ar7
      00A3AF 70 04            [24] 1240 	jnz	00102$
                                   1241 ;	quantum/quantum.c:561: true)) {
      00A3B1                       1242 00101$:
                                   1243 ;	quantum/quantum.c:562: return false;
      00A3B1 75 82 00         [24] 1244 	mov	dpl, #0x00
      00A3B4 22               [24] 1245 	ret
      00A3B5                       1246 00102$:
                                   1247 ;	quantum/quantum.c:565: if (record->event.pressed) {
      00A3B5 12 37 AF         [24] 1248 	lcall	_ak820_outline_0005
      00A3B8 60 2D            [24] 1249 	jz	00116$
                                   1250 ;	quantum/quantum.c:566: switch (keycode) {
      00A3BA BC 00 05         [24] 1251 	cjne	r4,#0x00,00205$
      00A3BD BD 7C 02         [24] 1252 	cjne	r5,#0x7c,00205$
      00A3C0 80 10            [24] 1253 	sjmp	00111$
      00A3C2                       1254 00205$:
      00A3C2 BC 01 05         [24] 1255 	cjne	r4,#0x01,00206$
      00A3C5 BD 7C 02         [24] 1256 	cjne	r5,#0x7c,00206$
      00A3C8 80 0E            [24] 1257 	sjmp	00112$
      00A3CA                       1258 00206$:
                                   1259 ;	quantum/quantum.c:568: case QK_BOOTLOADER:
      00A3CA BC 03 1A         [24] 1260 	cjne	r4,#0x03,00116$
      00A3CD BD 7C 17         [24] 1261 	cjne	r5,#0x7c,00116$
      00A3D0 80 0C            [24] 1262 	sjmp	00113$
      00A3D2                       1263 00111$:
                                   1264 ;	quantum/quantum.c:569: reset_keyboard();
      00A3D2 31 87            [12] 1265 	acall	_reset_keyboard
                                   1266 ;	quantum/quantum.c:570: return false;
      00A3D4 75 82 00         [24] 1267 	mov	dpl, #0x00
                                   1268 ;	quantum/quantum.c:571: case QK_REBOOT:
      00A3D7 22               [24] 1269 	ret
      00A3D8                       1270 00112$:
                                   1271 ;	quantum/quantum.c:572: soft_reset_keyboard();
      00A3D8 31 8C            [12] 1272 	acall	_soft_reset_keyboard
                                   1273 ;	quantum/quantum.c:573: return false;
      00A3DA 75 82 00         [24] 1274 	mov	dpl, #0x00
                                   1275 ;	quantum/quantum.c:585: case QK_CLEAR_EEPROM:
      00A3DD 22               [24] 1276 	ret
      00A3DE                       1277 00113$:
                                   1278 ;	quantum/quantum.c:592: eeconfig_disable();
      00A3DE 12 92 D3         [24] 1279 	lcall	_eeconfig_disable
                                   1280 ;	quantum/quantum.c:593: soft_reset_keyboard();
      00A3E1 31 8C            [12] 1281 	acall	_soft_reset_keyboard
                                   1282 ;	quantum/quantum.c:595: return false;
      00A3E3 75 82 00         [24] 1283 	mov	dpl, #0x00
                                   1284 ;	quantum/quantum.c:650: }
      00A3E6 22               [24] 1285 	ret
      00A3E7                       1286 00116$:
                                   1287 ;	quantum/quantum.c:654: return true;
      00A3E7 75 82 01         [24] 1288 	mov	dpl, #0x01
                                   1289 ;	quantum/quantum.c:658: }
      00A3EA 22               [24] 1290 	ret
                                   1291 ;------------------------------------------------------------
                                   1292 ;Allocation info for local variables in function 'set_single_persistent_default_layer'
                                   1293 ;------------------------------------------------------------
                                   1294 ;default_layer Allocated with name '_set_single_persistent_default_layer_default_layer_10000_697'
                                   1295 ;------------------------------------------------------------
                                   1296 ;	quantum/quantum.c:660: void set_single_persistent_default_layer(uint8_t default_layer) {
                                   1297 ;	-----------------------------------------
                                   1298 ;	 function shutdown_user
                                   1299 ;	-----------------------------------------
      00A3EB                       1300 _shutdown_user:
      00A3EB 22               [24] 1301 	ret
                                   1302 ;------------------------------------------------------------
                                   1303 ;Allocation info for local variables in function 'suspend_power_down_quantum'
                                   1304 ;------------------------------------------------------------
                                   1305 ;	quantum/quantum.c:676: void suspend_power_down_quantum(void) {
                                   1306 ;	-----------------------------------------
                                   1307 	.area CSEG    (CODE)
                                   1308 	.area CONST   (CODE)
                                   1309 	.area XINIT   (CODE)
                                   1310 	.area CABS    (ABS,CODE)
                                   1311 
                                   1312 ; Experimental exact instruction outlining.
                                   1313 	.globl _ak820_outline_0004
                                   1314 	.globl _ak820_outline_0005
                                   1315 	.globl _ak820_outline_0006
                                   1316 	.globl _ak820_outline_0009
                                   1317 	.globl _ak820_outline_0017
                                   1318 	.globl _ak820_outline_0021
                                   1319 	.globl _ak820_outline_0036
                                   1320 	.globl _ak820_outline_0051
                                   1321 	.globl _ak820_outline_0055
                                   1322 	.globl _ak820_outline_0059
                                   1323 	.globl _ak820_outline_0060
                                   1324 	.globl _ak820_outline_0061
                                   1325 	.globl _ak820_outline_0106
                                   1326 	.globl _ak820_outline_0107
                                   1327 	.globl _ak820_outline_0122
                                   1328 	.globl _ak820_outline_0125
                                   1329 	.globl _ak820_outline_0135
                                   1330 	.globl _ak820_outline_0147
                                   1331 	.globl _ak820_outline_0149
                                   1332 	.globl _ak820_outline_0160
                                   1333 	.globl _ak820_outline_0186
                                   1334 
                                   1335 	.area CSEG (CODE)
                                   1336 ; function ak820_outline_0006
      00A3EC                       1337 _ak820_outline_0006:
      00A3EC EE               [12] 1338 	mov	a,r6
      00A3ED F0               [24] 1339 	movx	@dptr,a
      00A3EE EF               [12] 1340 	mov	a,r7
      00A3EF A3               [24] 1341 	inc	dptr
      00A3F0 F0               [24] 1342 	movx	@dptr,a
      00A3F1 E4               [12] 1343 	clr	a
      00A3F2 A3               [24] 1344 	inc	dptr
      00A3F3 F0               [24] 1345 	movx	@dptr,a
      00A3F4 8C 82            [24] 1346 	mov	dpl,r4
      00A3F6 8D 83            [24] 1347 	mov	dph,r5
      00A3F8 22               [24] 1348 	ret
