                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module via
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _raw_hid_receive_kb
                                     12 	.globl _vialrgb_save
                                     13 	.globl _vialrgb_set_value
                                     14 	.globl _vialrgb_get_value
                                     15 	.globl _ak820_nvm_schema_fault
                                     16 	.globl _raw_hid_send
                                     17 	.globl _dynamic_keymap_macro_send
                                     18 	.globl _dynamic_keymap_macro_reset
                                     19 	.globl _dynamic_keymap_macro_set_buffer
                                     20 	.globl _dynamic_keymap_macro_get_buffer
                                     21 	.globl _dynamic_keymap_macro_get_buffer_size
                                     22 	.globl _dynamic_keymap_macro_get_count
                                     23 	.globl _dynamic_keymap_set_buffer
                                     24 	.globl _dynamic_keymap_get_buffer
                                     25 	.globl _dynamic_keymap_reset
                                     26 	.globl _dynamic_keymap_set_keycode
                                     27 	.globl _dynamic_keymap_get_keycode
                                     28 	.globl _dynamic_keymap_get_layer_count
                                     29 	.globl _vial_handle_cmd
                                     30 	.globl _eeprom_update_byte
                                     31 	.globl _eeprom_read_byte
                                     32 	.globl _bootloader_jump
                                     33 	.globl _timer_read32
                                     34 	.globl _matrix_get_row
                                     35 	.globl _mDelaymS
                                     36 	.globl _ADC_START
                                     37 	.globl _S0_R_FIFO
                                     38 	.globl _S0_T_FIFO
                                     39 	.globl _S0_FREE
                                     40 	.globl _S0_IF_BYTE
                                     41 	.globl _S0_IF_FIRST
                                     42 	.globl _S0_IF_OV
                                     43 	.globl _S0_FST_ACT
                                     44 	.globl _CP_RL2
                                     45 	.globl _C_T2
                                     46 	.globl _TR2
                                     47 	.globl _EXEN2
                                     48 	.globl _TCLK
                                     49 	.globl _RCLK
                                     50 	.globl _EXF2
                                     51 	.globl _CAP1F
                                     52 	.globl _TF2
                                     53 	.globl _RI
                                     54 	.globl _TI
                                     55 	.globl _RB8
                                     56 	.globl _TB8
                                     57 	.globl _REN
                                     58 	.globl _SM2
                                     59 	.globl _SM1
                                     60 	.globl _SM0
                                     61 	.globl _IT0
                                     62 	.globl _IE0
                                     63 	.globl _IT1
                                     64 	.globl _IE1
                                     65 	.globl _TR0
                                     66 	.globl _TF0
                                     67 	.globl _TR1
                                     68 	.globl _TF1
                                     69 	.globl _P4_0
                                     70 	.globl _P4_1
                                     71 	.globl _P4_2
                                     72 	.globl _P4_3
                                     73 	.globl _P4_4
                                     74 	.globl _P4_5
                                     75 	.globl _P4_6
                                     76 	.globl _RXD
                                     77 	.globl _TXD
                                     78 	.globl _INT0
                                     79 	.globl _INT1
                                     80 	.globl _T0
                                     81 	.globl _T1
                                     82 	.globl _MOSI1
                                     83 	.globl _MISO1
                                     84 	.globl _SCK1
                                     85 	.globl _P3_0
                                     86 	.globl _P3_1
                                     87 	.globl _P3_2
                                     88 	.globl _P3_3
                                     89 	.globl _P3_4
                                     90 	.globl _P3_5
                                     91 	.globl _P3_6
                                     92 	.globl _P3_7
                                     93 	.globl _CAP1_
                                     94 	.globl _T2_
                                     95 	.globl _CAP2_
                                     96 	.globl _T2EX_
                                     97 	.globl _RXD1
                                     98 	.globl _TXD1
                                     99 	.globl _P2_0
                                    100 	.globl _P2_1
                                    101 	.globl _P2_2
                                    102 	.globl _P2_3
                                    103 	.globl _P2_4
                                    104 	.globl _P2_5
                                    105 	.globl _P2_6
                                    106 	.globl _P2_7
                                    107 	.globl _AIN0
                                    108 	.globl _AIN1
                                    109 	.globl _AIN2
                                    110 	.globl _AIN3
                                    111 	.globl _AIN4
                                    112 	.globl _AIN5
                                    113 	.globl _AIN6
                                    114 	.globl _AIN7
                                    115 	.globl _CAP1
                                    116 	.globl _T2
                                    117 	.globl _CAP2
                                    118 	.globl _T2EX
                                    119 	.globl _INT0_
                                    120 	.globl _SCS
                                    121 	.globl _MOSI
                                    122 	.globl _MISO
                                    123 	.globl _SCK
                                    124 	.globl _RXD1_
                                    125 	.globl _TXD1_
                                    126 	.globl _P1_0
                                    127 	.globl _P1_1
                                    128 	.globl _P1_2
                                    129 	.globl _P1_3
                                    130 	.globl _P1_4
                                    131 	.globl _P1_5
                                    132 	.globl _P1_6
                                    133 	.globl _P1_7
                                    134 	.globl _AIN8
                                    135 	.globl _AIN9
                                    136 	.globl _AIN10
                                    137 	.globl _AIN11
                                    138 	.globl _AIN12
                                    139 	.globl _AIN13
                                    140 	.globl _RXD_
                                    141 	.globl _TXD_
                                    142 	.globl _SCL0
                                    143 	.globl _SDA0
                                    144 	.globl _P0_0
                                    145 	.globl _P0_1
                                    146 	.globl _P0_2
                                    147 	.globl _P0_3
                                    148 	.globl _P0_4
                                    149 	.globl _P0_5
                                    150 	.globl _P0_6
                                    151 	.globl _P0_7
                                    152 	.globl _IE_SPI0
                                    153 	.globl _IE_USB
                                    154 	.globl _IE_ADC
                                    155 	.globl _IE_UART1
                                    156 	.globl _IE_PWM_I2C
                                    157 	.globl _IE_GPIO
                                    158 	.globl _IE_WDOG
                                    159 	.globl _PX0
                                    160 	.globl _PT0
                                    161 	.globl _PX1
                                    162 	.globl _PT1
                                    163 	.globl _PS
                                    164 	.globl _PT2
                                    165 	.globl _PL_FLAG
                                    166 	.globl _PH_FLAG
                                    167 	.globl _EX0
                                    168 	.globl _ET0
                                    169 	.globl _EX1
                                    170 	.globl _ET1
                                    171 	.globl _ES
                                    172 	.globl _ET2
                                    173 	.globl _E_DIS
                                    174 	.globl _EA
                                    175 	.globl _P
                                    176 	.globl _F1
                                    177 	.globl _OV
                                    178 	.globl _RS0
                                    179 	.globl _RS1
                                    180 	.globl _F0
                                    181 	.globl _AC
                                    182 	.globl _CY
                                    183 	.globl _I2CS_INT_ST
                                    184 	.globl _I2CX_INT
                                    185 	.globl _LED_STATUS
                                    186 	.globl _LED_DMA_H
                                    187 	.globl _LED_DMA_L
                                    188 	.globl _LED_DMA
                                    189 	.globl _LED_PWM_OE
                                    190 	.globl _LED_COMMON
                                    191 	.globl _ADC_CHAN
                                    192 	.globl _ADC_DAT_H
                                    193 	.globl _ADC_DAT_L
                                    194 	.globl _ADC_DAT
                                    195 	.globl _ADC_CTRL
                                    196 	.globl _SPI1_CK_SE
                                    197 	.globl _SPI1_CTRL
                                    198 	.globl _SPI1_DATA
                                    199 	.globl _SPI1_STAT
                                    200 	.globl _SIF1
                                    201 	.globl _SBAUD1
                                    202 	.globl _SBUF1
                                    203 	.globl _SCON1
                                    204 	.globl _SPI0_SETUP
                                    205 	.globl _SPI0_CK_SE
                                    206 	.globl _SPI0_CTRL
                                    207 	.globl _SPI0_DATA
                                    208 	.globl _SPI0_STAT
                                    209 	.globl _T2CAP1H
                                    210 	.globl _T2CAP1L
                                    211 	.globl _T2CAP1
                                    212 	.globl _TH2
                                    213 	.globl _TL2
                                    214 	.globl _T2COUNT
                                    215 	.globl _RCAP2H
                                    216 	.globl _RCAP2L
                                    217 	.globl _RCAP2
                                    218 	.globl _T2MOD
                                    219 	.globl _T2CON
                                    220 	.globl _SBUF
                                    221 	.globl _SCON
                                    222 	.globl _TH1
                                    223 	.globl _TH0
                                    224 	.globl _TL1
                                    225 	.globl _TL0
                                    226 	.globl _TMOD
                                    227 	.globl _TCON
                                    228 	.globl _XBUS_AUX
                                    229 	.globl _P7
                                    230 	.globl _P6_DIR
                                    231 	.globl _P6_OUT_PU
                                    232 	.globl _P6_IN
                                    233 	.globl _P5_DIR
                                    234 	.globl _P5_OUT_PU
                                    235 	.globl _P5_IN
                                    236 	.globl _P4_LED_KEY
                                    237 	.globl _P4_DIR_PU
                                    238 	.globl _P4_MOD_OC
                                    239 	.globl _P4
                                    240 	.globl _P3_DIR_PU
                                    241 	.globl _P3_MOD_OC
                                    242 	.globl _P3
                                    243 	.globl _P2_DIR_PU
                                    244 	.globl _P2_MOD_OC
                                    245 	.globl _P2
                                    246 	.globl _P1_DIR_PU
                                    247 	.globl _P1_MOD_OC
                                    248 	.globl _P1
                                    249 	.globl _P0_DIR_PU
                                    250 	.globl _P0_MOD_OC
                                    251 	.globl _P0
                                    252 	.globl _ROM_CTRL
                                    253 	.globl _ROM_DATA_HH
                                    254 	.globl _ROM_DATA_HL
                                    255 	.globl _ROM_DATA_HI
                                    256 	.globl _ROM_ADDR_H
                                    257 	.globl _ROM_ADDR_L
                                    258 	.globl _ROM_ADDR
                                    259 	.globl _GPIO_IE
                                    260 	.globl _IP_EX
                                    261 	.globl _IE_EX
                                    262 	.globl _IP
                                    263 	.globl _IE
                                    264 	.globl _WDOG_COUNT
                                    265 	.globl _RESET_KEEP
                                    266 	.globl _WAKE_CTRL
                                    267 	.globl _CLOCK_CFG
                                    268 	.globl _POWER_CFG
                                    269 	.globl _PCON
                                    270 	.globl _GLOBAL_CFG
                                    271 	.globl _SAFE_MOD
                                    272 	.globl _DPH
                                    273 	.globl _DPL
                                    274 	.globl _SP
                                    275 	.globl _A_INV
                                    276 	.globl _B
                                    277 	.globl _ACC
                                    278 	.globl _PSW
                                    279 	.globl _raw_hid_receive_PARM_2
                                    280 	.globl _raw_hid_receive_kb_PARM_2
                                    281 	.globl _process_record_via_PARM_2
                                    282 	.globl _via_eeprom_is_valid
                                    283 	.globl _via_eeprom_set_valid
                                    284 	.globl _via_init
                                    285 	.globl _eeconfig_init_via
                                    286 	.globl _via_get_layout_options
                                    287 	.globl _via_set_layout_options_kb
                                    288 	.globl _via_set_layout_options
                                    289 	.globl _process_record_via
                                    290 	.globl _raw_hid_receive
                                    291 ;--------------------------------------------------------
                                    292 ; special function registers
                                    293 ;--------------------------------------------------------
                                    294 	.area RSEG    (ABS,DATA)
      000000                        295 	.org 0x0000
                           0000D0   296 _PSW	=	0x00d0
                           0000E0   297 _ACC	=	0x00e0
                           0000F0   298 _B	=	0x00f0
                           0000FD   299 _A_INV	=	0x00fd
                           000081   300 _SP	=	0x0081
                           000082   301 _DPL	=	0x0082
                           000083   302 _DPH	=	0x0083
                           0000A1   303 _SAFE_MOD	=	0x00a1
                           0000B1   304 _GLOBAL_CFG	=	0x00b1
                           000087   305 _PCON	=	0x0087
                           0000BA   306 _POWER_CFG	=	0x00ba
                           0000B9   307 _CLOCK_CFG	=	0x00b9
                           0000A9   308 _WAKE_CTRL	=	0x00a9
                           0000FE   309 _RESET_KEEP	=	0x00fe
                           0000FF   310 _WDOG_COUNT	=	0x00ff
                           0000A8   311 _IE	=	0x00a8
                           0000B8   312 _IP	=	0x00b8
                           0000E8   313 _IE_EX	=	0x00e8
                           0000E9   314 _IP_EX	=	0x00e9
                           0000B2   315 _GPIO_IE	=	0x00b2
                           008584   316 _ROM_ADDR	=	0x8584
                           000084   317 _ROM_ADDR_L	=	0x0084
                           000085   318 _ROM_ADDR_H	=	0x0085
                           008F8E   319 _ROM_DATA_HI	=	0x8f8e
                           00008E   320 _ROM_DATA_HL	=	0x008e
                           00008F   321 _ROM_DATA_HH	=	0x008f
                           000086   322 _ROM_CTRL	=	0x0086
                           000080   323 _P0	=	0x0080
                           0000C4   324 _P0_MOD_OC	=	0x00c4
                           0000C5   325 _P0_DIR_PU	=	0x00c5
                           000090   326 _P1	=	0x0090
                           000092   327 _P1_MOD_OC	=	0x0092
                           000093   328 _P1_DIR_PU	=	0x0093
                           0000A0   329 _P2	=	0x00a0
                           000094   330 _P2_MOD_OC	=	0x0094
                           000095   331 _P2_DIR_PU	=	0x0095
                           0000B0   332 _P3	=	0x00b0
                           000096   333 _P3_MOD_OC	=	0x0096
                           000097   334 _P3_DIR_PU	=	0x0097
                           0000C0   335 _P4	=	0x00c0
                           0000C2   336 _P4_MOD_OC	=	0x00c2
                           0000C3   337 _P4_DIR_PU	=	0x00c3
                           0000C1   338 _P4_LED_KEY	=	0x00c1
                           0000AA   339 _P5_IN	=	0x00aa
                           0000AB   340 _P5_OUT_PU	=	0x00ab
                           0000AC   341 _P5_DIR	=	0x00ac
                           0000AD   342 _P6_IN	=	0x00ad
                           0000AE   343 _P6_OUT_PU	=	0x00ae
                           0000AF   344 _P6_DIR	=	0x00af
                           0000F1   345 _P7	=	0x00f1
                           0000A2   346 _XBUS_AUX	=	0x00a2
                           000088   347 _TCON	=	0x0088
                           000089   348 _TMOD	=	0x0089
                           00008A   349 _TL0	=	0x008a
                           00008B   350 _TL1	=	0x008b
                           00008C   351 _TH0	=	0x008c
                           00008D   352 _TH1	=	0x008d
                           000098   353 _SCON	=	0x0098
                           000099   354 _SBUF	=	0x0099
                           0000C8   355 _T2CON	=	0x00c8
                           0000C9   356 _T2MOD	=	0x00c9
                           00CBCA   357 _RCAP2	=	0xcbca
                           0000CA   358 _RCAP2L	=	0x00ca
                           0000CB   359 _RCAP2H	=	0x00cb
                           00CDCC   360 _T2COUNT	=	0xcdcc
                           0000CC   361 _TL2	=	0x00cc
                           0000CD   362 _TH2	=	0x00cd
                           00CFCE   363 _T2CAP1	=	0xcfce
                           0000CE   364 _T2CAP1L	=	0x00ce
                           0000CF   365 _T2CAP1H	=	0x00cf
                           0000F8   366 _SPI0_STAT	=	0x00f8
                           0000F9   367 _SPI0_DATA	=	0x00f9
                           0000FA   368 _SPI0_CTRL	=	0x00fa
                           0000FB   369 _SPI0_CK_SE	=	0x00fb
                           0000FC   370 _SPI0_SETUP	=	0x00fc
                           0000BC   371 _SCON1	=	0x00bc
                           0000BD   372 _SBUF1	=	0x00bd
                           0000BE   373 _SBAUD1	=	0x00be
                           0000BF   374 _SIF1	=	0x00bf
                           0000B4   375 _SPI1_STAT	=	0x00b4
                           0000B5   376 _SPI1_DATA	=	0x00b5
                           0000B6   377 _SPI1_CTRL	=	0x00b6
                           0000B7   378 _SPI1_CK_SE	=	0x00b7
                           0000F3   379 _ADC_CTRL	=	0x00f3
                           00F5F4   380 _ADC_DAT	=	0xf5f4
                           0000F4   381 _ADC_DAT_L	=	0x00f4
                           0000F5   382 _ADC_DAT_H	=	0x00f5
                           0000F6   383 _ADC_CHAN	=	0x00f6
                           0000A6   384 _LED_COMMON	=	0x00a6
                           0000A7   385 _LED_PWM_OE	=	0x00a7
                           00C7C6   386 _LED_DMA	=	0xc7c6
                           0000C6   387 _LED_DMA_L	=	0x00c6
                           0000C7   388 _LED_DMA_H	=	0x00c7
                           0000F7   389 _LED_STATUS	=	0x00f7
                           0000B3   390 _I2CX_INT	=	0x00b3
                           0000BB   391 _I2CS_INT_ST	=	0x00bb
                                    392 ;--------------------------------------------------------
                                    393 ; special function bits
                                    394 ;--------------------------------------------------------
                                    395 	.area RSEG    (ABS,DATA)
      000000                        396 	.org 0x0000
                           0000D7   397 _CY	=	0x00d7
                           0000D6   398 _AC	=	0x00d6
                           0000D5   399 _F0	=	0x00d5
                           0000D4   400 _RS1	=	0x00d4
                           0000D3   401 _RS0	=	0x00d3
                           0000D2   402 _OV	=	0x00d2
                           0000D1   403 _F1	=	0x00d1
                           0000D0   404 _P	=	0x00d0
                           0000AF   405 _EA	=	0x00af
                           0000AE   406 _E_DIS	=	0x00ae
                           0000AD   407 _ET2	=	0x00ad
                           0000AC   408 _ES	=	0x00ac
                           0000AB   409 _ET1	=	0x00ab
                           0000AA   410 _EX1	=	0x00aa
                           0000A9   411 _ET0	=	0x00a9
                           0000A8   412 _EX0	=	0x00a8
                           0000BF   413 _PH_FLAG	=	0x00bf
                           0000BE   414 _PL_FLAG	=	0x00be
                           0000BD   415 _PT2	=	0x00bd
                           0000BC   416 _PS	=	0x00bc
                           0000BB   417 _PT1	=	0x00bb
                           0000BA   418 _PX1	=	0x00ba
                           0000B9   419 _PT0	=	0x00b9
                           0000B8   420 _PX0	=	0x00b8
                           0000EF   421 _IE_WDOG	=	0x00ef
                           0000EE   422 _IE_GPIO	=	0x00ee
                           0000ED   423 _IE_PWM_I2C	=	0x00ed
                           0000EC   424 _IE_UART1	=	0x00ec
                           0000EB   425 _IE_ADC	=	0x00eb
                           0000E9   426 _IE_USB	=	0x00e9
                           0000E8   427 _IE_SPI0	=	0x00e8
                           000087   428 _P0_7	=	0x0087
                           000086   429 _P0_6	=	0x0086
                           000085   430 _P0_5	=	0x0085
                           000084   431 _P0_4	=	0x0084
                           000083   432 _P0_3	=	0x0083
                           000082   433 _P0_2	=	0x0082
                           000081   434 _P0_1	=	0x0081
                           000080   435 _P0_0	=	0x0080
                           000081   436 _SDA0	=	0x0081
                           000080   437 _SCL0	=	0x0080
                           000083   438 _TXD_	=	0x0083
                           000082   439 _RXD_	=	0x0082
                           000085   440 _AIN13	=	0x0085
                           000084   441 _AIN12	=	0x0084
                           000083   442 _AIN11	=	0x0083
                           000082   443 _AIN10	=	0x0082
                           000081   444 _AIN9	=	0x0081
                           000080   445 _AIN8	=	0x0080
                           000097   446 _P1_7	=	0x0097
                           000096   447 _P1_6	=	0x0096
                           000095   448 _P1_5	=	0x0095
                           000094   449 _P1_4	=	0x0094
                           000093   450 _P1_3	=	0x0093
                           000092   451 _P1_2	=	0x0092
                           000091   452 _P1_1	=	0x0091
                           000090   453 _P1_0	=	0x0090
                           000097   454 _TXD1_	=	0x0097
                           000096   455 _RXD1_	=	0x0096
                           000097   456 _SCK	=	0x0097
                           000096   457 _MISO	=	0x0096
                           000095   458 _MOSI	=	0x0095
                           000094   459 _SCS	=	0x0094
                           000092   460 _INT0_	=	0x0092
                           000091   461 _T2EX	=	0x0091
                           000091   462 _CAP2	=	0x0091
                           000090   463 _T2	=	0x0090
                           000090   464 _CAP1	=	0x0090
                           000097   465 _AIN7	=	0x0097
                           000096   466 _AIN6	=	0x0096
                           000095   467 _AIN5	=	0x0095
                           000094   468 _AIN4	=	0x0094
                           000093   469 _AIN3	=	0x0093
                           000092   470 _AIN2	=	0x0092
                           000091   471 _AIN1	=	0x0091
                           000090   472 _AIN0	=	0x0090
                           0000A7   473 _P2_7	=	0x00a7
                           0000A6   474 _P2_6	=	0x00a6
                           0000A5   475 _P2_5	=	0x00a5
                           0000A4   476 _P2_4	=	0x00a4
                           0000A3   477 _P2_3	=	0x00a3
                           0000A2   478 _P2_2	=	0x00a2
                           0000A1   479 _P2_1	=	0x00a1
                           0000A0   480 _P2_0	=	0x00a0
                           0000A7   481 _TXD1	=	0x00a7
                           0000A6   482 _RXD1	=	0x00a6
                           0000A5   483 _T2EX_	=	0x00a5
                           0000A5   484 _CAP2_	=	0x00a5
                           0000A4   485 _T2_	=	0x00a4
                           0000A4   486 _CAP1_	=	0x00a4
                           0000B7   487 _P3_7	=	0x00b7
                           0000B6   488 _P3_6	=	0x00b6
                           0000B5   489 _P3_5	=	0x00b5
                           0000B4   490 _P3_4	=	0x00b4
                           0000B3   491 _P3_3	=	0x00b3
                           0000B2   492 _P3_2	=	0x00b2
                           0000B1   493 _P3_1	=	0x00b1
                           0000B0   494 _P3_0	=	0x00b0
                           0000B7   495 _SCK1	=	0x00b7
                           0000B6   496 _MISO1	=	0x00b6
                           0000B5   497 _MOSI1	=	0x00b5
                           0000B5   498 _T1	=	0x00b5
                           0000B4   499 _T0	=	0x00b4
                           0000B3   500 _INT1	=	0x00b3
                           0000B2   501 _INT0	=	0x00b2
                           0000B1   502 _TXD	=	0x00b1
                           0000B0   503 _RXD	=	0x00b0
                           0000C6   504 _P4_6	=	0x00c6
                           0000C5   505 _P4_5	=	0x00c5
                           0000C4   506 _P4_4	=	0x00c4
                           0000C3   507 _P4_3	=	0x00c3
                           0000C2   508 _P4_2	=	0x00c2
                           0000C1   509 _P4_1	=	0x00c1
                           0000C0   510 _P4_0	=	0x00c0
                           00008F   511 _TF1	=	0x008f
                           00008E   512 _TR1	=	0x008e
                           00008D   513 _TF0	=	0x008d
                           00008C   514 _TR0	=	0x008c
                           00008B   515 _IE1	=	0x008b
                           00008A   516 _IT1	=	0x008a
                           000089   517 _IE0	=	0x0089
                           000088   518 _IT0	=	0x0088
                           00009F   519 _SM0	=	0x009f
                           00009E   520 _SM1	=	0x009e
                           00009D   521 _SM2	=	0x009d
                           00009C   522 _REN	=	0x009c
                           00009B   523 _TB8	=	0x009b
                           00009A   524 _RB8	=	0x009a
                           000099   525 _TI	=	0x0099
                           000098   526 _RI	=	0x0098
                           0000CF   527 _TF2	=	0x00cf
                           0000CF   528 _CAP1F	=	0x00cf
                           0000CE   529 _EXF2	=	0x00ce
                           0000CD   530 _RCLK	=	0x00cd
                           0000CC   531 _TCLK	=	0x00cc
                           0000CB   532 _EXEN2	=	0x00cb
                           0000CA   533 _TR2	=	0x00ca
                           0000C9   534 _C_T2	=	0x00c9
                           0000C8   535 _CP_RL2	=	0x00c8
                           0000FF   536 _S0_FST_ACT	=	0x00ff
                           0000FE   537 _S0_IF_OV	=	0x00fe
                           0000FD   538 _S0_IF_FIRST	=	0x00fd
                           0000FC   539 _S0_IF_BYTE	=	0x00fc
                           0000FB   540 _S0_FREE	=	0x00fb
                           0000FA   541 _S0_T_FIFO	=	0x00fa
                           0000F8   542 _S0_R_FIFO	=	0x00f8
                           0000F7   543 _ADC_START	=	0x00f7
                                    544 ;--------------------------------------------------------
                                    545 ; overlayable register banks
                                    546 ;--------------------------------------------------------
                                    547 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        548 	.ds 8
                                    549 ;--------------------------------------------------------
                                    550 ; internal ram data
                                    551 ;--------------------------------------------------------
                                    552 	.area DSEG    (DATA)
      000038                        553 _raw_hid_receive_sloc0_1_0:
      000038                        554 	.ds 4
      00003C                        555 _raw_hid_receive_sloc1_1_0:
      00003C                        556 	.ds 1
      00003D                        557 _raw_hid_receive_sloc2_1_0:
      00003D                        558 	.ds 1
      00003E                        559 _raw_hid_receive_sloc3_1_0:
      00003E                        560 	.ds 2
      000040                        561 _raw_hid_receive_sloc4_1_0:
      000040                        562 	.ds 2
                                    563 ;--------------------------------------------------------
                                    564 ; overlayable items in internal ram
                                    565 ;--------------------------------------------------------
                                    566 ;--------------------------------------------------------
                                    567 ; indirectly addressable internal ram data
                                    568 ;--------------------------------------------------------
                                    569 	.area ISEG    (DATA)
                                    570 ;--------------------------------------------------------
                                    571 ; absolute internal ram data
                                    572 ;--------------------------------------------------------
                                    573 	.area IABS    (ABS,DATA)
                                    574 	.area IABS    (ABS,DATA)
                                    575 ;--------------------------------------------------------
                                    576 ; bit data
                                    577 ;--------------------------------------------------------
                                    578 	.area BSEG    (BIT)
      000028                        579 _via_eeprom_is_valid_sloc0_1_0:
      000028                        580 	.ds 1
                                    581 ;--------------------------------------------------------
                                    582 ; paged external ram data
                                    583 ;--------------------------------------------------------
                                    584 	.area PSEG    (PAG,XDATA)
                                    585 ;--------------------------------------------------------
                                    586 ; uninitialized external ram data
                                    587 ;--------------------------------------------------------
                                    588 	.area XSEG    (XDATA)
      000C61                        589 _via_eeprom_set_valid_valid_10000_609:
      000C61                        590 	.ds 1
      000C62                        591 _via_set_layout_options_value_10000_625:
      000C62                        592 	.ds 4
      000C66                        593 _process_record_via_PARM_2:
      000C66                        594 	.ds 3
      000C69                        595 _process_record_via_keycode_10000_627:
      000C69                        596 	.ds 2
      000C6B                        597 _raw_hid_receive_kb_PARM_2:
      000C6B                        598 	.ds 1
      000C6C                        599 _raw_hid_receive_kb_data_10000_633:
      000C6C                        600 	.ds 3
      000C6F                        601 _raw_hid_receive_PARM_2:
      000C6F                        602 	.ds 1
      000C70                        603 _raw_hid_receive_packet_10000_635:
      000C70                        604 	.ds 3
                                    605 ;--------------------------------------------------------
                                    606 ; absolute external ram data
                                    607 ;--------------------------------------------------------
                                    608 	.area XABS    (ABS,XDATA)
                                    609 ;--------------------------------------------------------
                                    610 ; initialized external ram data
                                    611 ;--------------------------------------------------------
                                    612 	.area XISEG   (XDATA)
                                    613 	.area HOME    (CODE)
                                    614 	.area GSINIT0 (CODE)
                                    615 	.area GSINIT1 (CODE)
                                    616 	.area GSINIT2 (CODE)
                                    617 	.area GSINIT3 (CODE)
                                    618 	.area GSINIT4 (CODE)
                                    619 	.area GSINIT5 (CODE)
                                    620 	.area GSINIT  (CODE)
                                    621 	.area GSFINAL (CODE)
                                    622 	.area CSEG    (CODE)
                                    623 ;--------------------------------------------------------
                                    624 ; global & static initialisations
                                    625 ;--------------------------------------------------------
                                    626 	.area HOME    (CODE)
                                    627 	.area GSINIT  (CODE)
                                    628 	.area GSFINAL (CODE)
                                    629 	.area GSINIT  (CODE)
                                    630 ;--------------------------------------------------------
                                    631 ; Home
                                    632 ;--------------------------------------------------------
                                    633 	.area HOME    (CODE)
                                    634 	.area HOME    (CODE)
                                    635 ;--------------------------------------------------------
                                    636 ; code
                                    637 ;--------------------------------------------------------
                                    638 	.area CSEG    (CODE)
                                    639 ;------------------------------------------------------------
                                    640 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    641 ;------------------------------------------------------------
                                    642 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_193'
                                    643 ;------------------------------------------------------------
                                    644 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    645 ;	-----------------------------------------
                           000007   646 	ar7 = 0x07
                           000006   647 	ar6 = 0x06
                           000005   648 	ar5 = 0x05
                           000004   649 	ar4 = 0x04
                           000003   650 	ar3 = 0x03
                           000002   651 	ar2 = 0x02
                           000001   652 	ar1 = 0x01
                           000000   653 	ar0 = 0x00
                                    654 ;	 function via_eeprom_is_valid
                                    655 ;	-----------------------------------------
      00A7E7                        656 _via_eeprom_is_valid:
                                    657 ;	quantum/via.c:103: return (eeprom_read_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 0) == magic0 && eeprom_read_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 1) == magic1 && eeprom_read_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 2) == magic2);
      00A7E7 90 00 25         [24]  658 	mov	dptr,#0x0025
      00A7EA 75 F0 00         [24]  659 	mov	b, #0x00
      00A7ED 12 40 36         [24]  660 	lcall	_eeprom_read_byte
      00A7F0 AF 82            [24]  661 	mov	r7, dpl
      00A7F2 BF 03 1E         [24]  662 	cjne	r7,#0x03,00103$
      00A7F5 90 00 26         [24]  663 	mov	dptr,#0x0026
      00A7F8 75 F0 00         [24]  664 	mov	b, #0x00
      00A7FB 12 40 36         [24]  665 	lcall	_eeprom_read_byte
      00A7FE AF 82            [24]  666 	mov	r7, dpl
      00A800 BF 20 10         [24]  667 	cjne	r7,#0x20,00103$
      00A803 90 00 27         [24]  668 	mov	dptr,#0x0027
      00A806 75 F0 00         [24]  669 	mov	b, #0x00
      00A809 12 40 36         [24]  670 	lcall	_eeprom_read_byte
      00A80C AF 82            [24]  671 	mov	r7, dpl
      00A80E BF 08 02         [24]  672 	cjne	r7,#0x08,00126$
      00A811 80 04            [24]  673 	sjmp	00104$
      00A813                        674 00126$:
      00A813                        675 00103$:
                                    676 ;	assignBit
      00A813 C2 28            [12]  677 	clr	_via_eeprom_is_valid_sloc0_1_0
      00A815 80 02            [24]  678 	sjmp	00105$
      00A817                        679 00104$:
                                    680 ;	assignBit
      00A817 D2 28            [12]  681 	setb	_via_eeprom_is_valid_sloc0_1_0
      00A819                        682 00105$:
      00A819 A2 28            [12]  683 	mov	c,_via_eeprom_is_valid_sloc0_1_0
      00A81B 12 38 7B         [24]  684 	lcall	_ak820_outline_0160
                                    685 ;	quantum/via.c:104: }
      00A81E 22               [24]  686 	ret
                                    687 ;------------------------------------------------------------
                                    688 ;Allocation info for local variables in function 'via_eeprom_set_valid'
                                    689 ;------------------------------------------------------------
                                    690 ;valid         Allocated with name '_via_eeprom_set_valid_valid_10000_609'
                                    691 ;magic0        Allocated with name '_via_eeprom_set_valid_magic0_10000_610'
                                    692 ;magic1        Allocated with name '_via_eeprom_set_valid_magic1_10000_610'
                                    693 ;magic2        Allocated with name '_via_eeprom_set_valid_magic2_10000_610'
                                    694 ;------------------------------------------------------------
                                    695 ;	quantum/via.c:108: void via_eeprom_set_valid(__xdata bool valid) {
                                    696 ;	-----------------------------------------
                                    697 ;	 function via_eeprom_set_valid
                                    698 ;	-----------------------------------------
      00A81F                        699 _via_eeprom_set_valid:
      00A81F E5 82            [12]  700 	mov	a,dpl
      00A821 90 0C 61         [24]  701 	mov	dptr,#_via_eeprom_set_valid_valid_10000_609
      00A824 F0               [24]  702 	movx	@dptr,a
                                    703 ;	quantum/via.c:120: eeprom_update_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 0, valid ? magic0 : 0xFF);
      00A825 E0               [24]  704 	movx	a,@dptr
      00A826 60 04            [24]  705 	jz	00103$
      00A828 7F 03            [12]  706 	mov	r7,#0x03
      00A82A 80 02            [24]  707 	sjmp	00104$
      00A82C                        708 00103$:
      00A82C 7F FF            [12]  709 	mov	r7,#0xff
      00A82E                        710 00104$:
      00A82E 90 06 E3         [24]  711 	mov	dptr,#_eeprom_update_byte_PARM_2
      00A831 EF               [12]  712 	mov	a,r7
      00A832 F0               [24]  713 	movx	@dptr,a
      00A833 90 00 25         [24]  714 	mov	dptr,#0x0025
      00A836 75 F0 00         [24]  715 	mov	b, #0x00
      00A839 12 52 44         [24]  716 	lcall	_eeprom_update_byte
                                    717 ;	quantum/via.c:121: eeprom_update_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 1, valid ? magic1 : 0xFF);
      00A83C 90 0C 61         [24]  718 	mov	dptr,#_via_eeprom_set_valid_valid_10000_609
      00A83F E0               [24]  719 	movx	a,@dptr
      00A840 60 04            [24]  720 	jz	00105$
      00A842 7F 20            [12]  721 	mov	r7,#0x20
      00A844 80 02            [24]  722 	sjmp	00106$
      00A846                        723 00105$:
      00A846 7F FF            [12]  724 	mov	r7,#0xff
      00A848                        725 00106$:
      00A848 90 06 E3         [24]  726 	mov	dptr,#_eeprom_update_byte_PARM_2
      00A84B EF               [12]  727 	mov	a,r7
      00A84C F0               [24]  728 	movx	@dptr,a
      00A84D 90 00 26         [24]  729 	mov	dptr,#0x0026
      00A850 75 F0 00         [24]  730 	mov	b, #0x00
      00A853 12 52 44         [24]  731 	lcall	_eeprom_update_byte
                                    732 ;	quantum/via.c:122: eeprom_update_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 2, valid ? magic2 : 0xFF);
      00A856 90 0C 61         [24]  733 	mov	dptr,#_via_eeprom_set_valid_valid_10000_609
      00A859 E0               [24]  734 	movx	a,@dptr
      00A85A 60 04            [24]  735 	jz	00107$
      00A85C 7F 08            [12]  736 	mov	r7,#0x08
      00A85E 80 02            [24]  737 	sjmp	00108$
      00A860                        738 00107$:
      00A860 7F FF            [12]  739 	mov	r7,#0xff
      00A862                        740 00108$:
      00A862 90 06 E3         [24]  741 	mov	dptr,#_eeprom_update_byte_PARM_2
      00A865 EF               [12]  742 	mov	a,r7
      00A866 F0               [24]  743 	movx	@dptr,a
      00A867 90 00 27         [24]  744 	mov	dptr,#0x0027
      00A86A 75 F0 00         [24]  745 	mov	b, #0x00
                                    746 ;	quantum/via.c:123: }
      00A86D 02 52 44         [24]  747 	ljmp	_eeprom_update_byte
                                    748 ;------------------------------------------------------------
                                    749 ;Allocation info for local variables in function 'via_init_kb'
                                    750 ;------------------------------------------------------------
                                    751 ;	quantum/via.c:131: __attribute__((weak)) void via_init_kb(void) {}
                                    752 ;	-----------------------------------------
                                    753 ;	 function via_init
                                    754 ;	-----------------------------------------
      00A870                        755 _via_init:
                                    756 ;	quantum/via.c:138: via_set_layout_options_kb(via_get_layout_options());
      00A870 11 94            [12]  757 	acall	_via_get_layout_options
      00A872 11 AC            [12]  758 	acall	_via_set_layout_options_kb
                                    759 ;	quantum/via.c:142: if (!via_eeprom_is_valid()) {
      00A874 12 A7 E7         [24]  760 	lcall	_via_eeprom_is_valid
      00A877 E5 82            [12]  761 	mov	a, dpl
      00A879 70 03            [24]  762 	jnz	00103$
                                    763 ;	quantum/via.c:147: ak820_nvm_schema_fault();
                                    764 ;	quantum/via.c:152: }
      00A87B 02 3D E6         [24]  765 	ljmp	_ak820_nvm_schema_fault
      00A87E                        766 00103$:
      00A87E 22               [24]  767 	ret
                                    768 ;------------------------------------------------------------
                                    769 ;Allocation info for local variables in function 'eeconfig_init_via'
                                    770 ;------------------------------------------------------------
                                    771 ;	quantum/via.c:154: void eeconfig_init_via(void) {
                                    772 ;	-----------------------------------------
                                    773 ;	 function eeconfig_init_via
                                    774 ;	-----------------------------------------
      00A87F                        775 _eeconfig_init_via:
                                    776 ;	quantum/via.c:156: via_eeprom_set_valid(false);
      00A87F 75 82 00         [24]  777 	mov	dpl, #0x00
      00A882 11 1F            [12]  778 	acall	_via_eeprom_set_valid
                                    779 ;	quantum/via.c:158: via_set_layout_options(VIA_EEPROM_LAYOUT_OPTIONS_DEFAULT);
      00A884 12 93 92         [24]  780 	lcall	_ak820_outline_0157
      00A887 11 AD            [12]  781 	acall	_via_set_layout_options
                                    782 ;	quantum/via.c:160: dynamic_keymap_reset();
      00A889 12 8A 0E         [24]  783 	lcall	_dynamic_keymap_reset
                                    784 ;	quantum/via.c:162: dynamic_keymap_macro_reset();
      00A88C 12 8E 83         [24]  785 	lcall	_dynamic_keymap_macro_reset
                                    786 ;	quantum/via.c:164: via_eeprom_set_valid(true);
      00A88F 75 82 01         [24]  787 	mov	dpl, #0x01
                                    788 ;	quantum/via.c:165: }
      00A892 01 1F            [12]  789 	ajmp	_via_eeprom_set_valid
                                    790 ;------------------------------------------------------------
                                    791 ;Allocation info for local variables in function 'via_get_layout_options'
                                    792 ;------------------------------------------------------------
                                    793 ;	quantum/via.c:169: uint32_t via_get_layout_options(void) {
                                    794 ;	-----------------------------------------
                                    795 ;	 function via_get_layout_options
                                    796 ;	-----------------------------------------
      00A894                        797 _via_get_layout_options:
                                    798 ;	quantum/via.c:173: return eeprom_read_byte((uint8_t *)VIA_EEPROM_LAYOUT_OPTIONS_ADDR);
      00A894 90 00 28         [24]  799 	mov	dptr,#0x0028
      00A897 75 F0 00         [24]  800 	mov	b, #0x00
      00A89A 12 40 36         [24]  801 	lcall	_eeprom_read_byte
      00A89D AF 82            [24]  802 	mov	r7, dpl
      00A89F 7E 00            [12]  803 	mov	r6,#0x00
      00A8A1 7D 00            [12]  804 	mov	r5,#0x00
      00A8A3 7C 00            [12]  805 	mov	r4,#0x00
      00A8A5 12 43 4C         [24]  806 	lcall	_ak820_outline_0161
      00A8A8 8D F0            [24]  807 	mov	b, r5
      00A8AA EC               [12]  808 	mov	a, r4
                                    809 ;	quantum/via.c:185: }
      00A8AB 22               [24]  810 	ret
                                    811 ;------------------------------------------------------------
                                    812 ;Allocation info for local variables in function 'via_set_layout_options_kb'
                                    813 ;------------------------------------------------------------
                                    814 ;value         Allocated with name '_via_set_layout_options_kb_value_10000_622'
                                    815 ;------------------------------------------------------------
                                    816 ;	quantum/via.c:187: __attribute__((weak)) void via_set_layout_options_kb(uint32_t value) {}
                                    817 ;	-----------------------------------------
                                    818 ;	 function via_set_layout_options_kb
                                    819 ;	-----------------------------------------
      00A8AC                        820 _via_set_layout_options_kb:
      00A8AC 22               [24]  821 	ret
                                    822 ;------------------------------------------------------------
                                    823 ;Allocation info for local variables in function 'via_set_layout_options'
                                    824 ;------------------------------------------------------------
                                    825 ;value         Allocated with name '_via_set_layout_options_value_10000_625'
                                    826 ;------------------------------------------------------------
                                    827 ;	quantum/via.c:189: void via_set_layout_options(uint32_t value) {
                                    828 ;	-----------------------------------------
                                    829 ;	 function via_set_layout_options
                                    830 ;	-----------------------------------------
      00A8AD                        831 _via_set_layout_options:
      00A8AD 12 93 8A         [24]  832 	lcall	_ak820_outline_0123
      00A8B0 90 0C 62         [24]  833 	mov	dptr,#_via_set_layout_options_value_10000_625
      00A8B3 12 93 78         [24]  834 	lcall	_ak820_outline_0042
                                    835 ;	quantum/via.c:192: eeprom_update_byte((uint8_t *)VIA_EEPROM_LAYOUT_OPTIONS_ADDR, (uint8_t)value);
      00A8B6 90 0C 62         [24]  836 	mov	dptr,#_via_set_layout_options_value_10000_625
      00A8B9 E0               [24]  837 	movx	a,@dptr
      00A8BA 90 06 E3         [24]  838 	mov	dptr,#_eeprom_update_byte_PARM_2
      00A8BD F0               [24]  839 	movx	@dptr,a
      00A8BE 90 00 28         [24]  840 	mov	dptr,#0x0028
      00A8C1 75 F0 00         [24]  841 	mov	b, #0x00
                                    842 ;	quantum/via.c:202: }
      00A8C4 02 52 44         [24]  843 	ljmp	_eeprom_update_byte
                                    844 ;------------------------------------------------------------
                                    845 ;Allocation info for local variables in function 'process_record_via'
                                    846 ;------------------------------------------------------------
                                    847 ;record        Allocated with name '_process_record_via_PARM_2'
                                    848 ;keycode       Allocated with name '_process_record_via_keycode_10000_627'
                                    849 ;id            Allocated with name '_process_record_via_id_50000_632'
                                    850 ;------------------------------------------------------------
                                    851 ;	quantum/via.c:205: bool process_record_via(uint16_t keycode, keyrecord_t *record) {
                                    852 ;	-----------------------------------------
                                    853 ;	 function process_record_via
                                    854 ;	-----------------------------------------
      00A8C7                        855 _process_record_via:
      00A8C7 12 38 52         [24]  856 	lcall	_ak820_outline_0106
      00A8CA 90 0C 69         [24]  857 	mov	dptr,#_process_record_via_keycode_10000_627
      00A8CD 12 38 57         [24]  858 	lcall	_ak820_outline_0107
                                    859 ;	quantum/via.c:207: if (record->event.pressed) {
      00A8D0 90 0C 66         [24]  860 	mov	dptr,#_process_record_via_PARM_2
      00A8D3 12 53 54         [24]  861 	lcall	_ak820_outline_0023
      00A8D6 74 05            [12]  862 	mov	a,#0x05
      00A8D8 12 38 80         [24]  863 	lcall	_ak820_outline_0163
      00A8DB 12 53 5D         [24]  864 	lcall	_ak820_outline_0045
      00A8DE 12 BC E3         [24]  865 	lcall	__gptrget
      00A8E1 60 1D            [24]  866 	jz	00105$
                                    867 ;	quantum/via.c:208: if (keycode >= QK_MACRO && keycode <= QK_MACRO_MAX) {
      00A8E3 90 0C 69         [24]  868 	mov	dptr,#_process_record_via_keycode_10000_627
      00A8E6 12 37 D0         [24]  869 	lcall	_ak820_outline_0010
      00A8E9 74 89            [12]  870 	mov	a,#0x100 - 0x77
      00A8EB 2D               [12]  871 	add	a,r5
      00A8EC 50 12            [24]  872 	jnc	00105$
      00A8EE C3               [12]  873 	clr	c
      00A8EF 74 7F            [12]  874 	mov	a,#0x7f
      00A8F1 9C               [12]  875 	subb	a,r4
      00A8F2 74 77            [12]  876 	mov	a,#0x77
      00A8F4 9D               [12]  877 	subb	a,r5
      00A8F5 40 09            [24]  878 	jc	00105$
                                    879 ;	free result
                                    880 ;	quantum/via.c:209: uint8_t id = keycode - QK_MACRO;
                                    881 ;	quantum/via.c:210: dynamic_keymap_macro_send(id);
      00A8F7 8E 82            [24]  882 	mov	dpl, r6
      00A8F9 12 8E A9         [24]  883 	lcall	_dynamic_keymap_macro_send
                                    884 ;	quantum/via.c:211: return false;
      00A8FC 75 82 00         [24]  885 	mov	dpl, #0x00
      00A8FF 22               [24]  886 	ret
      00A900                        887 00105$:
                                    888 ;	quantum/via.c:215: return true;
      00A900 75 82 01         [24]  889 	mov	dpl, #0x01
                                    890 ;	quantum/via.c:216: }
      00A903 22               [24]  891 	ret
                                    892 ;------------------------------------------------------------
                                    893 ;Allocation info for local variables in function 'raw_hid_receive_kb'
                                    894 ;------------------------------------------------------------
                                    895 ;length        Allocated with name '_raw_hid_receive_kb_PARM_2'
                                    896 ;data          Allocated with name '_raw_hid_receive_kb_data_10000_633'
                                    897 ;command_id    Allocated with name '_raw_hid_receive_kb_command_id_10000_634'
                                    898 ;------------------------------------------------------------
                                    899 ;	quantum/via.c:221: __attribute__((weak)) void raw_hid_receive_kb(uint8_t *data, uint8_t length) {
                                    900 ;	-----------------------------------------
                                    901 ;	 function raw_hid_receive_kb
                                    902 ;	-----------------------------------------
      00A904                        903 _raw_hid_receive_kb:
      00A904 12 42 D5         [24]  904 	lcall	_ak820_outline_0037
      00A907 90 0C 6C         [24]  905 	mov	dptr,#_raw_hid_receive_kb_data_10000_633
      00A90A 12 37 E4         [24]  906 	lcall	_ak820_outline_0016
                                    907 ;	quantum/via.c:222: uint8_t *command_id = &(data[0]);
      00A90D 90 0C 6C         [24]  908 	mov	dptr,#_raw_hid_receive_kb_data_10000_633
      00A910 12 53 45         [24]  909 	lcall	_ak820_outline_0003
                                    910 ;	quantum/via.c:223: *command_id         = id_unhandled;
      00A913 74 FF            [12]  911 	mov	a,#0xff
                                    912 ;	quantum/via.c:224: }
      00A915 02 BB BE         [24]  913 	ljmp	__gptrput
                                    914 ;------------------------------------------------------------
                                    915 ;Allocation info for local variables in function 'raw_hid_receive'
                                    916 ;------------------------------------------------------------
                                    917 ;sloc0         Allocated with name '_raw_hid_receive_sloc0_1_0'
                                    918 ;sloc1         Allocated with name '_raw_hid_receive_sloc1_1_0'
                                    919 ;sloc2         Allocated with name '_raw_hid_receive_sloc2_1_0'
                                    920 ;sloc3         Allocated with name '_raw_hid_receive_sloc3_1_0'
                                    921 ;sloc4         Allocated with name '_raw_hid_receive_sloc4_1_0'
                                    922 ;length        Allocated with name '_raw_hid_receive_PARM_2'
                                    923 ;packet        Allocated with name '_raw_hid_receive_packet_10000_635'
                                    924 ;data          Allocated with name '_raw_hid_receive_data_10000_636'
                                    925 ;command_id    Allocated with name '_raw_hid_receive_command_id_10000_636'
                                    926 ;command_data  Allocated with name '_raw_hid_receive_command_data_10000_636'
                                    927 ;cmd           Allocated with name '_raw_hid_receive_cmd_30001_642'
                                    928 ;value         Allocated with name '_raw_hid_receive_value_70000_650'
                                    929 ;value         Allocated with name '_raw_hid_receive_value_70000_651'
                                    930 ;i             Allocated with name '_raw_hid_receive_i_70001_654'
                                    931 ;row           Allocated with name '_raw_hid_receive_row_80001_655'
                                    932 ;value         Allocated with name '_raw_hid_receive_value_90001_656'
                                    933 ;value         Allocated with name '_raw_hid_receive_value_70000_661'
                                    934 ;keycode       Allocated with name '_raw_hid_receive_keycode_40000_663'
                                    935 ;size          Allocated with name '_raw_hid_receive_size_40000_672'
                                    936 ;offset        Allocated with name '_raw_hid_receive_offset_40000_673'
                                    937 ;size          Allocated with name '_raw_hid_receive_size_40000_673'
                                    938 ;offset        Allocated with name '_raw_hid_receive_offset_40001_678'
                                    939 ;size          Allocated with name '_raw_hid_receive_size_40001_678'
                                    940 ;offset        Allocated with name '_raw_hid_receive_offset_40000_683'
                                    941 ;size          Allocated with name '_raw_hid_receive_size_40000_683'
                                    942 ;offset        Allocated with name '_raw_hid_receive_offset_40000_685'
                                    943 ;size          Allocated with name '_raw_hid_receive_size_40000_685'
                                    944 ;i             Allocated with name '_raw_hid_receive_i_60000_690'
                                    945 ;------------------------------------------------------------
                                    946 ;	quantum/via.c:233: void raw_hid_receive(uint8_t *packet, uint8_t length) {
                                    947 ;	-----------------------------------------
                                    948 ;	 function raw_hid_receive
                                    949 ;	-----------------------------------------
      00A918                        950 _raw_hid_receive:
      00A918 12 42 D5         [24]  951 	lcall	_ak820_outline_0037
      00A91B 90 0C 70         [24]  952 	mov	dptr,#_raw_hid_receive_packet_10000_635
      00A91E 12 37 E4         [24]  953 	lcall	_ak820_outline_0016
                                    954 ;	quantum/via.c:236: uint8_t __xdata *data = (uint8_t __xdata *)packet;
      00A921 90 0C 70         [24]  955 	mov	dptr,#_raw_hid_receive_packet_10000_635
      00A924 12 37 FC         [24]  956 	lcall	_ak820_outline_0051
                                    957 ;	quantum/via.c:238: uint8_t __xdata *command_data = &data[1];
      00A927 74 01            [12]  958 	mov	a,#0x01
      00A929 12 43 51         [24]  959 	lcall	_ak820_outline_0164
                                    960 ;	quantum/via.c:245: if (length != 32) return;
      00A92C 90 0C 6F         [24]  961 	mov	dptr,#_raw_hid_receive_PARM_2
      00A92F E0               [24]  962 	movx	a,@dptr
      00A930 FB               [12]  963 	mov	r3,a
      00A931 BB 20 02         [24]  964 	cjne	r3,#0x20,00520$
      00A934 80 01            [24]  965 	sjmp	00102$
      00A936                        966 00520$:
      00A936 22               [24]  967 	ret
      00A937                        968 00102$:
                                    969 ;	quantum/via.c:249: if (vial_unlock_in_progress) {
      00A937 90 0E 46         [24]  970 	mov	dptr,#_vial_unlock_in_progress
      00A93A E0               [24]  971 	movx	a,@dptr
      00A93B 60 30            [24]  972 	jz	00114$
                                    973 ;	quantum/via.c:250: if (data[0] != id_vial_prefix) {
      00A93D 12 38 3A         [24]  974 	lcall	_ak820_outline_0100
      00A940 FA               [12]  975 	mov	r2,a
      00A941 BA FE 02         [24]  976 	cjne	r2,#0xfe,00522$
      00A944 80 01            [24]  977 	sjmp	00104$
      00A946                        978 00522$:
                                    979 ;	quantum/via.c:252: return;
      00A946 22               [24]  980 	ret
      00A947                        981 00104$:
                                    982 ;	quantum/via.c:257: uint8_t cmd = data[1];
      00A947 12 43 13         [24]  983 	lcall	_ak820_outline_0095
                                    984 ;	quantum/via.c:258: if (cmd != vial_get_keyboard_id && cmd != vial_get_size && cmd != vial_get_def && cmd != vial_get_unlock_status && cmd != vial_unlock_start && cmd != vial_unlock_poll && cmd != vial_lock)
      00A94A FA               [12]  985 	mov	r2,a
      00A94B 60 20            [24]  986 	jz	00114$
      00A94D BA 01 02         [24]  987 	cjne	r2,#0x01,00524$
      00A950 80 1B            [24]  988 	sjmp	00114$
      00A952                        989 00524$:
      00A952 BA 02 02         [24]  990 	cjne	r2,#0x02,00525$
      00A955 80 16            [24]  991 	sjmp	00114$
      00A957                        992 00525$:
      00A957 BA 05 02         [24]  993 	cjne	r2,#0x05,00526$
      00A95A 80 11            [24]  994 	sjmp	00114$
      00A95C                        995 00526$:
      00A95C BA 06 02         [24]  996 	cjne	r2,#0x06,00527$
      00A95F 80 0C            [24]  997 	sjmp	00114$
      00A961                        998 00527$:
      00A961 BA 07 02         [24]  999 	cjne	r2,#0x07,00528$
      00A964 80 07            [24] 1000 	sjmp	00114$
      00A966                       1001 00528$:
      00A966 BA 08 02         [24] 1002 	cjne	r2,#0x08,00529$
      00A969 80 02            [24] 1003 	sjmp	00530$
      00A96B                       1004 00529$:
      00A96B C1 6C            [12] 1005 	ajmp	00171$
      00A96D                       1006 00530$:
                                   1007 ;	quantum/via.c:259: goto skip;
      00A96D                       1008 00114$:
                                   1009 ;	quantum/via.c:263: switch (*command_id) {
      00A96D 12 38 3A         [24] 1010 	lcall	_ak820_outline_0100
      00A970 FA               [12] 1011 	mov	r2,a
      00A971 BA 01 02         [24] 1012 	cjne	r2,#0x01,00531$
      00A974 80 5C            [24] 1013 	sjmp	00115$
      00A976                       1014 00531$:
      00A976 BA 02 02         [24] 1015 	cjne	r2,#0x02,00532$
      00A979 80 63            [24] 1016 	sjmp	00116$
      00A97B                       1017 00532$:
      00A97B BA 03 02         [24] 1018 	cjne	r2,#0x03,00533$
      00A97E 41 97            [24] 1019 	ajmp	00125$
      00A980                       1020 00533$:
      00A980 BA 04 02         [24] 1021 	cjne	r2,#0x04,00534$
      00A983 61 29            [12] 1022 	ajmp	00129$
      00A985                       1023 00534$:
      00A985 BA 05 02         [24] 1024 	cjne	r2,#0x05,00535$
      00A988 61 61            [12] 1025 	ajmp	00130$
      00A98A                       1026 00535$:
      00A98A BA 06 02         [24] 1027 	cjne	r2,#0x06,00536$
      00A98D 61 CC            [12] 1028 	ajmp	00135$
      00A98F                       1029 00536$:
      00A98F BA 07 02         [24] 1030 	cjne	r2,#0x07,00537$
      00A992 61 DD            [12] 1031 	ajmp	00136$
      00A994                       1032 00537$:
      00A994 BA 08 02         [24] 1033 	cjne	r2,#0x08,00538$
      00A997 61 F7            [12] 1034 	ajmp	00137$
      00A999                       1035 00538$:
      00A999 BA 09 02         [24] 1036 	cjne	r2,#0x09,00539$
      00A99C 81 11            [12] 1037 	ajmp	00138$
      00A99E                       1038 00539$:
      00A99E BA 0B 02         [24] 1039 	cjne	r2,#0x0b,00540$
      00A9A1 A1 FC            [12] 1040 	ajmp	00161$
      00A9A3                       1041 00540$:
      00A9A3 BA 0C 02         [24] 1042 	cjne	r2,#0x0c,00541$
      00A9A6 81 2B            [12] 1043 	ajmp	00139$
      00A9A8                       1044 00541$:
      00A9A8 BA 0D 02         [24] 1045 	cjne	r2,#0x0d,00542$
      00A9AB 81 4B            [12] 1046 	ajmp	00140$
      00A9AD                       1047 00542$:
      00A9AD BA 0E 02         [24] 1048 	cjne	r2,#0x0e,00543$
      00A9B0 81 72            [12] 1049 	ajmp	00141$
      00A9B2                       1050 00543$:
      00A9B2 BA 0F 02         [24] 1051 	cjne	r2,#0x0f,00544$
      00A9B5 81 B8            [12] 1052 	ajmp	00144$
      00A9B7                       1053 00544$:
      00A9B7 BA 10 02         [24] 1054 	cjne	r2,#0x10,00545$
      00A9BA A1 26            [12] 1055 	ajmp	00151$
      00A9BC                       1056 00545$:
      00A9BC BA 11 02         [24] 1057 	cjne	r2,#0x11,00546$
      00A9BF A1 3E            [12] 1058 	ajmp	00154$
      00A9C1                       1059 00546$:
      00A9C1 BA 12 02         [24] 1060 	cjne	r2,#0x12,00547$
      00A9C4 A1 5E            [12] 1061 	ajmp	00155$
      00A9C6                       1062 00547$:
      00A9C6 BA 13 02         [24] 1063 	cjne	r2,#0x13,00548$
      00A9C9 A1 A4            [12] 1064 	ajmp	00158$
      00A9CB                       1065 00548$:
      00A9CB BA FE 02         [24] 1066 	cjne	r2,#0xfe,00549$
      00A9CE C1 3B            [12] 1067 	ajmp	00168$
      00A9D0                       1068 00549$:
      00A9D0 C1 55            [12] 1069 	ajmp	00169$
                                   1070 ;	quantum/via.c:264: case id_get_protocol_version: {
      00A9D2                       1071 00115$:
                                   1072 ;	quantum/via.c:265: command_data[0] = VIA_PROTOCOL_VERSION >> 8;
      00A9D2 12 38 5C         [24] 1073 	lcall	_ak820_outline_0125
      00A9D5 E4               [12] 1074 	clr	a
      00A9D6 12 42 CD         [24] 1075 	lcall	_ak820_outline_0031
                                   1076 ;	quantum/via.c:266: command_data[1] = VIA_PROTOCOL_VERSION & 0xFF;
      00A9D9 74 09            [12] 1077 	mov	a,#0x09
      00A9DB F0               [24] 1078 	movx	@dptr,a
                                   1079 ;	quantum/via.c:267: break;
      00A9DC C1 6C            [12] 1080 	ajmp	00171$
                                   1081 ;	quantum/via.c:269: case id_get_keyboard_value: {
      00A9DE                       1082 00116$:
                                   1083 ;	quantum/via.c:270: switch (command_data[0]) {
      00A9DE 12 43 13         [24] 1084 	lcall	_ak820_outline_0095
      00A9E1 FA               [12] 1085 	mov	r2,a
      00A9E2 BA 01 02         [24] 1086 	cjne	r2,#0x01,00550$
      00A9E5 80 0C            [24] 1087 	sjmp	00117$
      00A9E7                       1088 00550$:
      00A9E7 BA 02 02         [24] 1089 	cjne	r2,#0x02,00551$
      00A9EA 80 31            [24] 1090 	sjmp	00118$
      00A9EC                       1091 00551$:
      00A9EC BA 03 02         [24] 1092 	cjne	r2,#0x03,00552$
      00A9EF 41 56            [24] 1093 	ajmp	00119$
      00A9F1                       1094 00552$:
      00A9F1 41 7E            [24] 1095 	ajmp	00123$
                                   1096 ;	quantum/via.c:271: case id_uptime: {
      00A9F3                       1097 00117$:
                                   1098 ;	quantum/via.c:272: uint32_t value  = timer_read32();
      00A9F3 12 4D 6C         [24] 1099 	lcall	_timer_read32
      00A9F6 85 82 38         [24] 1100 	mov	_raw_hid_receive_sloc0_1_0,dpl
      00A9F9 85 83 39         [24] 1101 	mov	(_raw_hid_receive_sloc0_1_0 + 1),dph
      00A9FC 85 F0 3A         [24] 1102 	mov	(_raw_hid_receive_sloc0_1_0 + 2),b
      00A9FF F5 3B            [12] 1103 	mov	(_raw_hid_receive_sloc0_1_0 + 3),a
                                   1104 ;	quantum/via.c:273: command_data[1] = (value >> 24) & 0xFF;
      00AA01 12 43 2B         [24] 1105 	lcall	_ak820_outline_0121
      00AA04 A3               [24] 1106 	inc	dptr
      00AA05 A3               [24] 1107 	inc	dptr
      00AA06 E5 3B            [12] 1108 	mov	a,(_raw_hid_receive_sloc0_1_0 + 3)
      00AA08 12 42 CD         [24] 1109 	lcall	_ak820_outline_0031
                                   1110 ;	quantum/via.c:274: command_data[2] = (value >> 16) & 0xFF;
      00AA0B A3               [24] 1111 	inc	dptr
      00AA0C E5 3A            [12] 1112 	mov	a,(_raw_hid_receive_sloc0_1_0 + 2)
      00AA0E F0               [24] 1113 	movx	@dptr,a
                                   1114 ;	quantum/via.c:275: command_data[3] = (value >> 8) & 0xFF;
      00AA0F 12 AE 9A         [24] 1115 	lcall	_ak820_outline_0022
      00AA12 E5 39            [12] 1116 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00AA14 F0               [24] 1117 	movx	@dptr,a
                                   1118 ;	quantum/via.c:276: command_data[4] = value & 0xFF;
      00AA15 12 42 C3         [24] 1119 	lcall	_ak820_outline_0011
      00AA18 E5 38            [12] 1120 	mov	a,_raw_hid_receive_sloc0_1_0
      00AA1A F0               [24] 1121 	movx	@dptr,a
                                   1122 ;	quantum/via.c:277: break;
      00AA1B C1 6C            [12] 1123 	ajmp	00171$
                                   1124 ;	quantum/via.c:279: case id_layout_options: {
      00AA1D                       1125 00118$:
                                   1126 ;	quantum/via.c:280: uint32_t value  = via_get_layout_options();
      00AA1D C0 03            [24] 1127 	push	ar3
      00AA1F C0 07            [24] 1128 	push	ar7
      00AA21 C0 06            [24] 1129 	push	ar6
      00AA23 C0 03            [24] 1130 	push	ar3
      00AA25 11 94            [12] 1131 	acall	_via_get_layout_options
      00AA27 85 82 38         [24] 1132 	mov	_raw_hid_receive_sloc0_1_0,dpl
      00AA2A 85 83 39         [24] 1133 	mov	(_raw_hid_receive_sloc0_1_0 + 1),dph
      00AA2D 85 F0 3A         [24] 1134 	mov	(_raw_hid_receive_sloc0_1_0 + 2),b
      00AA30 F5 3B            [12] 1135 	mov	(_raw_hid_receive_sloc0_1_0 + 3),a
      00AA32 D0 03            [24] 1136 	pop	ar3
      00AA34 D0 06            [24] 1137 	pop	ar6
      00AA36 D0 07            [24] 1138 	pop	ar7
                                   1139 ;	quantum/via.c:281: command_data[1] = (value >> 24) & 0xFF;
      00AA38 12 43 2B         [24] 1140 	lcall	_ak820_outline_0121
      00AA3B A3               [24] 1141 	inc	dptr
      00AA3C A3               [24] 1142 	inc	dptr
      00AA3D E5 3B            [12] 1143 	mov	a,(_raw_hid_receive_sloc0_1_0 + 3)
      00AA3F 12 42 CD         [24] 1144 	lcall	_ak820_outline_0031
                                   1145 ;	quantum/via.c:282: command_data[2] = (value >> 16) & 0xFF;
      00AA42 A3               [24] 1146 	inc	dptr
      00AA43 E5 3A            [12] 1147 	mov	a,(_raw_hid_receive_sloc0_1_0 + 2)
      00AA45 F0               [24] 1148 	movx	@dptr,a
                                   1149 ;	quantum/via.c:283: command_data[3] = (value >> 8) & 0xFF;
      00AA46 12 AE 9A         [24] 1150 	lcall	_ak820_outline_0022
      00AA49 E5 39            [12] 1151 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00AA4B F0               [24] 1152 	movx	@dptr,a
                                   1153 ;	quantum/via.c:284: command_data[4] = value & 0xFF;
      00AA4C 12 42 C3         [24] 1154 	lcall	_ak820_outline_0011
      00AA4F E5 38            [12] 1155 	mov	a,_raw_hid_receive_sloc0_1_0
      00AA51 F0               [24] 1156 	movx	@dptr,a
                                   1157 ;	quantum/via.c:285: break;
      00AA52 D0 03            [24] 1158 	pop	ar3
      00AA54 C1 6C            [12] 1159 	ajmp	00171$
                                   1160 ;	quantum/via.c:287: case id_switch_matrix_state: {
      00AA56                       1161 00119$:
                                   1162 ;	quantum/via.c:290: if (!vial_unlocked)
      00AA56 90 0E 45         [24] 1163 	mov	dptr,#_vial_unlocked
      00AA59 E0               [24] 1164 	movx	a,@dptr
      00AA5A 70 02            [24] 1165 	jnz	00553$
      00AA5C C1 6C            [12] 1166 	ajmp	00171$
      00AA5E                       1167 00553$:
                                   1168 ;	quantum/via.c:296: for (uint8_t row = 0; row < MATRIX_ROWS; row++) {
      00AA5E 7A 01            [12] 1169 	mov	r2,#0x01
      00AA60 79 00            [12] 1170 	mov	r1,#0x00
      00AA62                       1171 00173$:
      00AA62 B9 10 00         [24] 1172 	cjne	r1,#0x10,00554$
      00AA65                       1173 00554$:
      00AA65 40 02            [24] 1174 	jc	00555$
      00AA67 C1 6C            [12] 1175 	ajmp	00171$
      00AA69                       1176 00555$:
                                   1177 ;	quantum/via.c:297: matrix_row_t value = matrix_get_row(row);
      00AA69 89 82            [24] 1178 	mov	dpl, r1
      00AA6B 12 5D B9         [24] 1179 	lcall	_matrix_get_row
      00AA6E A8 82            [24] 1180 	mov	r0, dpl
                                   1181 ;	quantum/via.c:307: command_data[i++] = value & 0xFF;
      00AA70 EA               [12] 1182 	mov	a,r2
      00AA71 2C               [12] 1183 	add	a, r4
      00AA72 F5 82            [12] 1184 	mov	dpl,a
      00AA74 E4               [12] 1185 	clr	a
      00AA75 3D               [12] 1186 	addc	a, r5
      00AA76 F5 83            [12] 1187 	mov	dph,a
      00AA78 0A               [12] 1188 	inc	r2
      00AA79 E8               [12] 1189 	mov	a,r0
      00AA7A F0               [24] 1190 	movx	@dptr,a
                                   1191 ;	quantum/via.c:296: for (uint8_t row = 0; row < MATRIX_ROWS; row++) {
      00AA7B 09               [12] 1192 	inc	r1
                                   1193 ;	quantum/via.c:312: default: {
      00AA7C 80 E4            [24] 1194 	sjmp	00173$
      00AA7E                       1195 00123$:
                                   1196 ;	quantum/via.c:313: raw_hid_receive_kb(data, length);
      00AA7E 12 AE C8         [24] 1197 	lcall	_ak820_outline_0093
      00AA81 90 0C 6B         [24] 1198 	mov	dptr,#_raw_hid_receive_kb_PARM_2
      00AA84 12 AE A3         [24] 1199 	lcall	_ak820_outline_0038
      00AA87 C0 07            [24] 1200 	push	ar7
      00AA89 C0 06            [24] 1201 	push	ar6
      00AA8B C0 03            [24] 1202 	push	ar3
      00AA8D 31 04            [24] 1203 	acall	_raw_hid_receive_kb
      00AA8F D0 03            [24] 1204 	pop	ar3
      00AA91 D0 06            [24] 1205 	pop	ar6
      00AA93 D0 07            [24] 1206 	pop	ar7
                                   1207 ;	quantum/via.c:317: break;
      00AA95 C1 6C            [12] 1208 	ajmp	00171$
                                   1209 ;	quantum/via.c:319: case id_set_keyboard_value: {
      00AA97                       1210 00125$:
                                   1211 ;	quantum/via.c:320: switch (command_data[0]) {
      00AA97 12 43 13         [24] 1212 	lcall	_ak820_outline_0095
      00AA9A FA               [12] 1213 	mov	r2,a
      00AA9B BA 02 02         [24] 1214 	cjne	r2,#0x02,00556$
      00AA9E 80 02            [24] 1215 	sjmp	00557$
      00AAA0                       1216 00556$:
      00AAA0 61 10            [12] 1217 	ajmp	00127$
      00AAA2                       1218 00557$:
                                   1219 ;	quantum/via.c:322: uint32_t value = ((uint32_t)command_data[1] << 24) | ((uint32_t)command_data[2] << 16) | ((uint32_t)command_data[3] << 8) | (uint32_t)command_data[4];
      00AAA2 C0 03            [24] 1220 	push	ar3
      00AAA4 12 37 F4         [24] 1221 	lcall	_ak820_outline_0034
      00AAA7 F8               [12] 1222 	mov	r0,a
      00AAA8 79 00            [12] 1223 	mov	r1,#0x00
      00AAAA 7B 00            [12] 1224 	mov	r3,#0x00
      00AAAC 88 3B            [24] 1225 	mov	(_raw_hid_receive_sloc0_1_0 + 3),r0
      00AAAE 8B 38            [24] 1226 	mov	_raw_hid_receive_sloc0_1_0,r3
      00AAB0 8B 39            [24] 1227 	mov	(_raw_hid_receive_sloc0_1_0 + 1),r3
      00AAB2 8B 3A            [24] 1228 	mov	(_raw_hid_receive_sloc0_1_0 + 2),r3
      00AAB4 12 AE 91         [24] 1229 	lcall	_ak820_outline_0015
      00AAB7 F8               [12] 1230 	mov	r0,a
      00AAB8 89 03            [24] 1231 	mov	ar3,r1
      00AABA 88 02            [24] 1232 	mov	ar2,r0
      00AABC E4               [12] 1233 	clr	a
      00AABD 42 38            [12] 1234 	orl	_raw_hid_receive_sloc0_1_0,a
      00AABF E9               [12] 1235 	mov	a,r1
      00AAC0 42 39            [12] 1236 	orl	(_raw_hid_receive_sloc0_1_0 + 1),a
      00AAC2 EA               [12] 1237 	mov	a,r2
      00AAC3 42 3A            [12] 1238 	orl	(_raw_hid_receive_sloc0_1_0 + 2),a
      00AAC5 EB               [12] 1239 	mov	a,r3
      00AAC6 42 3B            [12] 1240 	orl	(_raw_hid_receive_sloc0_1_0 + 3),a
      00AAC8 12 AE 9A         [24] 1241 	lcall	_ak820_outline_0022
      00AACB E0               [24] 1242 	movx	a,@dptr
      00AACC F8               [12] 1243 	mov	r0,a
      00AACD 79 00            [12] 1244 	mov	r1,#0x00
      00AACF 7A 00            [12] 1245 	mov	r2,#0x00
      00AAD1 8A 03            [24] 1246 	mov	ar3,r2
      00AAD3 89 02            [24] 1247 	mov	ar2,r1
      00AAD5 88 01            [24] 1248 	mov	ar1,r0
      00AAD7 E4               [12] 1249 	clr	a
      00AAD8 42 38            [12] 1250 	orl	_raw_hid_receive_sloc0_1_0,a
      00AADA E9               [12] 1251 	mov	a,r1
      00AADB 42 39            [12] 1252 	orl	(_raw_hid_receive_sloc0_1_0 + 1),a
      00AADD EA               [12] 1253 	mov	a,r2
      00AADE 42 3A            [12] 1254 	orl	(_raw_hid_receive_sloc0_1_0 + 2),a
      00AAE0 EB               [12] 1255 	mov	a,r3
      00AAE1 42 3B            [12] 1256 	orl	(_raw_hid_receive_sloc0_1_0 + 3),a
      00AAE3 12 42 C3         [24] 1257 	lcall	_ak820_outline_0011
      00AAE6 E0               [24] 1258 	movx	a,@dptr
      00AAE7 F8               [12] 1259 	mov	r0,a
      00AAE8 E4               [12] 1260 	clr	a
      00AAE9 F9               [12] 1261 	mov	r1,a
      00AAEA FA               [12] 1262 	mov	r2,a
      00AAEB FB               [12] 1263 	mov	r3,a
      00AAEC E5 39            [12] 1264 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00AAEE 42 01            [12] 1265 	orl	ar1,a
      00AAF0 E5 3A            [12] 1266 	mov	a,(_raw_hid_receive_sloc0_1_0 + 2)
      00AAF2 42 02            [12] 1267 	orl	ar2,a
      00AAF4 E5 3B            [12] 1268 	mov	a,(_raw_hid_receive_sloc0_1_0 + 3)
      00AAF6 42 03            [12] 1269 	orl	ar3,a
                                   1270 ;	quantum/via.c:323: via_set_layout_options(value);
      00AAF8 12 38 76         [24] 1271 	lcall	_ak820_outline_0154
      00AAFB 8A F0            [24] 1272 	mov	b, r2
      00AAFD EB               [12] 1273 	mov	a, r3
      00AAFE C0 07            [24] 1274 	push	ar7
      00AB00 C0 06            [24] 1275 	push	ar6
      00AB02 C0 03            [24] 1276 	push	ar3
      00AB04 11 AD            [12] 1277 	acall	_via_set_layout_options
      00AB06 D0 03            [24] 1278 	pop	ar3
      00AB08 D0 06            [24] 1279 	pop	ar6
      00AB0A D0 07            [24] 1280 	pop	ar7
                                   1281 ;	quantum/via.c:324: break;
      00AB0C D0 03            [24] 1282 	pop	ar3
      00AB0E C1 6C            [12] 1283 	ajmp	00171$
                                   1284 ;	quantum/via.c:326: default: {
      00AB10                       1285 00127$:
                                   1286 ;	quantum/via.c:327: raw_hid_receive_kb(data, length);
      00AB10 12 AE C8         [24] 1287 	lcall	_ak820_outline_0093
      00AB13 90 0C 6B         [24] 1288 	mov	dptr,#_raw_hid_receive_kb_PARM_2
      00AB16 12 AE A3         [24] 1289 	lcall	_ak820_outline_0038
      00AB19 C0 07            [24] 1290 	push	ar7
      00AB1B C0 06            [24] 1291 	push	ar6
      00AB1D C0 03            [24] 1292 	push	ar3
      00AB1F 31 04            [24] 1293 	acall	_raw_hid_receive_kb
      00AB21 D0 03            [24] 1294 	pop	ar3
      00AB23 D0 06            [24] 1295 	pop	ar6
      00AB25 D0 07            [24] 1296 	pop	ar7
                                   1297 ;	quantum/via.c:331: break;
      00AB27 C1 6C            [12] 1298 	ajmp	00171$
                                   1299 ;	quantum/via.c:333: case id_dynamic_keymap_get_keycode: {
      00AB29                       1300 00129$:
                                   1301 ;	quantum/via.c:334: uint16_t keycode = dynamic_keymap_get_keycode(command_data[0], command_data[1], command_data[2]);
      00AB29 12 43 13         [24] 1302 	lcall	_ak820_outline_0095
      00AB2C FA               [12] 1303 	mov	r2,a
      00AB2D 12 37 F4         [24] 1304 	lcall	_ak820_outline_0034
      00AB30 F9               [12] 1305 	mov	r1,a
      00AB31 12 AE 91         [24] 1306 	lcall	_ak820_outline_0015
      00AB34 F8               [12] 1307 	mov	r0,a
      00AB35 90 0B 1D         [24] 1308 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      00AB38 E9               [12] 1309 	mov	a,r1
      00AB39 F0               [24] 1310 	movx	@dptr,a
      00AB3A 90 0B 1E         [24] 1311 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      00AB3D E8               [12] 1312 	mov	a,r0
      00AB3E F0               [24] 1313 	movx	@dptr,a
      00AB3F 8A 82            [24] 1314 	mov	dpl, r2
      00AB41 C0 07            [24] 1315 	push	ar7
      00AB43 C0 06            [24] 1316 	push	ar6
      00AB45 C0 03            [24] 1317 	push	ar3
      00AB47 12 87 2F         [24] 1318 	lcall	_dynamic_keymap_get_keycode
      00AB4A 12 4D 22         [24] 1319 	lcall	_ak820_outline_0189
      00AB4D D0 03            [24] 1320 	pop	ar3
      00AB4F D0 06            [24] 1321 	pop	ar6
      00AB51 D0 07            [24] 1322 	pop	ar7
                                   1323 ;	quantum/via.c:335: command_data[3]  = keycode >> 8;
      00AB53 12 AE 9A         [24] 1324 	lcall	_ak820_outline_0022
      00AB56 8A 00            [24] 1325 	mov	ar0,r2
      00AB58 E8               [12] 1326 	mov	a,r0
      00AB59 F0               [24] 1327 	movx	@dptr,a
                                   1328 ;	quantum/via.c:336: command_data[4]  = keycode & 0xFF;
      00AB5A 12 42 C3         [24] 1329 	lcall	_ak820_outline_0011
      00AB5D E9               [12] 1330 	mov	a,r1
      00AB5E F0               [24] 1331 	movx	@dptr,a
                                   1332 ;	quantum/via.c:337: break;
      00AB5F C1 6C            [12] 1333 	ajmp	00171$
                                   1334 ;	quantum/via.c:339: case id_dynamic_keymap_set_keycode: {
      00AB61                       1335 00130$:
                                   1336 ;	quantum/via.c:343: if (!vial_unlocked && command_data[3] == (QK_BOOT >> 8) && command_data[4] == (QK_BOOT & 0xFF)) {
      00AB61 90 0E 45         [24] 1337 	mov	dptr,#_vial_unlocked
      00AB64 E0               [24] 1338 	movx	a,@dptr
      00AB65 70 18            [24] 1339 	jnz	00132$
      00AB67 12 AE 9A         [24] 1340 	lcall	_ak820_outline_0022
      00AB6A E0               [24] 1341 	movx	a,@dptr
      00AB6B FA               [12] 1342 	mov	r2,a
      00AB6C BA 7C 10         [24] 1343 	cjne	r2,#0x7c,00132$
      00AB6F 74 05            [12] 1344 	mov	a,#0x05
      00AB71 2E               [12] 1345 	add	a, r6
      00AB72 12 37 DA         [24] 1346 	lcall	_ak820_outline_0014
      00AB75 70 08            [24] 1347 	jnz	00132$
                                   1348 ;	quantum/via.c:344: *command_id = id_unhandled;
      00AB77 12 43 2B         [24] 1349 	lcall	_ak820_outline_0121
      00AB7A 74 FF            [12] 1350 	mov	a,#0xff
      00AB7C F0               [24] 1351 	movx	@dptr,a
                                   1352 ;	quantum/via.c:345: break;
      00AB7D C1 6C            [12] 1353 	ajmp	00171$
      00AB7F                       1354 00132$:
                                   1355 ;	quantum/via.c:348: dynamic_keymap_set_keycode(command_data[0], command_data[1], command_data[2], (command_data[3] << 8) | command_data[4]);
      00AB7F C0 03            [24] 1356 	push	ar3
      00AB81 12 43 13         [24] 1357 	lcall	_ak820_outline_0095
      00AB84 F5 3D            [12] 1358 	mov	_raw_hid_receive_sloc2_1_0,a
      00AB86 12 37 F4         [24] 1359 	lcall	_ak820_outline_0034
      00AB89 F5 3C            [12] 1360 	mov	_raw_hid_receive_sloc1_1_0,a
      00AB8B 12 AE 91         [24] 1361 	lcall	_ak820_outline_0015
      00AB8E F5 38            [12] 1362 	mov	_raw_hid_receive_sloc0_1_0,a
      00AB90 12 AE 9A         [24] 1363 	lcall	_ak820_outline_0022
      00AB93 E0               [24] 1364 	movx	a,@dptr
      00AB94 FB               [12] 1365 	mov	r3,a
      00AB95 78 00            [12] 1366 	mov	r0,#0x00
      00AB97 12 42 C3         [24] 1367 	lcall	_ak820_outline_0011
      00AB9A E0               [24] 1368 	movx	a,@dptr
      00AB9B 7A 00            [12] 1369 	mov	r2,#0x00
      00AB9D 42 00            [12] 1370 	orl	ar0,a
      00AB9F EA               [12] 1371 	mov	a,r2
      00ABA0 42 03            [12] 1372 	orl	ar3,a
      00ABA2 90 0B 20         [24] 1373 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      00ABA5 E5 3C            [12] 1374 	mov	a,_raw_hid_receive_sloc1_1_0
      00ABA7 F0               [24] 1375 	movx	@dptr,a
      00ABA8 90 0B 21         [24] 1376 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      00ABAB E5 38            [12] 1377 	mov	a,_raw_hid_receive_sloc0_1_0
      00ABAD F0               [24] 1378 	movx	@dptr,a
      00ABAE 90 0B 22         [24] 1379 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      00ABB1 E8               [12] 1380 	mov	a,r0
      00ABB2 F0               [24] 1381 	movx	@dptr,a
      00ABB3 EB               [12] 1382 	mov	a,r3
      00ABB4 A3               [24] 1383 	inc	dptr
      00ABB5 F0               [24] 1384 	movx	@dptr,a
      00ABB6 85 3D 82         [24] 1385 	mov	dpl, _raw_hid_receive_sloc2_1_0
      00ABB9 C0 07            [24] 1386 	push	ar7
      00ABBB C0 06            [24] 1387 	push	ar6
      00ABBD C0 03            [24] 1388 	push	ar3
      00ABBF 12 87 7C         [24] 1389 	lcall	_dynamic_keymap_set_keycode
      00ABC2 D0 03            [24] 1390 	pop	ar3
      00ABC4 D0 06            [24] 1391 	pop	ar6
      00ABC6 D0 07            [24] 1392 	pop	ar7
                                   1393 ;	quantum/via.c:349: break;
      00ABC8 D0 03            [24] 1394 	pop	ar3
      00ABCA C1 6C            [12] 1395 	ajmp	00171$
                                   1396 ;	quantum/via.c:351: case id_dynamic_keymap_reset: {
      00ABCC                       1397 00135$:
                                   1398 ;	quantum/via.c:352: dynamic_keymap_reset();
      00ABCC C0 07            [24] 1399 	push	ar7
      00ABCE C0 06            [24] 1400 	push	ar6
      00ABD0 C0 03            [24] 1401 	push	ar3
      00ABD2 12 8A 0E         [24] 1402 	lcall	_dynamic_keymap_reset
      00ABD5 D0 03            [24] 1403 	pop	ar3
      00ABD7 D0 06            [24] 1404 	pop	ar6
      00ABD9 D0 07            [24] 1405 	pop	ar7
                                   1406 ;	quantum/via.c:353: break;
      00ABDB C1 6C            [12] 1407 	ajmp	00171$
                                   1408 ;	quantum/via.c:355: case id_lighting_set_value: {
      00ABDD                       1409 00136$:
                                   1410 ;	quantum/via.c:363: vialrgb_set_value(data, length);
      00ABDD 12 AE C8         [24] 1411 	lcall	_ak820_outline_0093
      00ABE0 90 0D B6         [24] 1412 	mov	dptr,#_vialrgb_set_value_PARM_2
      00ABE3 12 AE A3         [24] 1413 	lcall	_ak820_outline_0038
      00ABE6 C0 07            [24] 1414 	push	ar7
      00ABE8 C0 06            [24] 1415 	push	ar6
      00ABEA C0 03            [24] 1416 	push	ar3
      00ABEC 12 B9 94         [24] 1417 	lcall	_vialrgb_set_value
      00ABEF D0 03            [24] 1418 	pop	ar3
      00ABF1 D0 06            [24] 1419 	pop	ar6
      00ABF3 D0 07            [24] 1420 	pop	ar7
                                   1421 ;	quantum/via.c:375: break;
      00ABF5 C1 6C            [12] 1422 	ajmp	00171$
                                   1423 ;	quantum/via.c:377: case id_lighting_get_value: {
      00ABF7                       1424 00137$:
                                   1425 ;	quantum/via.c:385: vialrgb_get_value(data, length);
      00ABF7 12 AE C8         [24] 1426 	lcall	_ak820_outline_0093
      00ABFA 90 0D B2         [24] 1427 	mov	dptr,#_vialrgb_get_value_PARM_2
      00ABFD 12 AE A3         [24] 1428 	lcall	_ak820_outline_0038
      00AC00 C0 07            [24] 1429 	push	ar7
      00AC02 C0 06            [24] 1430 	push	ar6
      00AC04 C0 03            [24] 1431 	push	ar3
      00AC06 12 B8 2D         [24] 1432 	lcall	_vialrgb_get_value
      00AC09 D0 03            [24] 1433 	pop	ar3
      00AC0B D0 06            [24] 1434 	pop	ar6
      00AC0D D0 07            [24] 1435 	pop	ar7
                                   1436 ;	quantum/via.c:397: break;
      00AC0F C1 6C            [12] 1437 	ajmp	00171$
                                   1438 ;	quantum/via.c:399: case id_lighting_save: {
      00AC11                       1439 00138$:
                                   1440 ;	quantum/via.c:407: vialrgb_save(data, length);
      00AC11 12 AE C8         [24] 1441 	lcall	_ak820_outline_0093
      00AC14 90 0D BA         [24] 1442 	mov	dptr,#_vialrgb_save_PARM_2
      00AC17 12 AE A3         [24] 1443 	lcall	_ak820_outline_0038
      00AC1A C0 07            [24] 1444 	push	ar7
      00AC1C C0 06            [24] 1445 	push	ar6
      00AC1E C0 03            [24] 1446 	push	ar3
      00AC20 12 BA 22         [24] 1447 	lcall	_vialrgb_save
      00AC23 D0 03            [24] 1448 	pop	ar3
      00AC25 D0 06            [24] 1449 	pop	ar6
      00AC27 D0 07            [24] 1450 	pop	ar7
                                   1451 ;	quantum/via.c:419: break;
      00AC29 C1 6C            [12] 1452 	ajmp	00171$
                                   1453 ;	quantum/via.c:428: case id_dynamic_keymap_macro_get_count: {
      00AC2B                       1454 00139$:
                                   1455 ;	quantum/via.c:429: command_data[0] = dynamic_keymap_macro_get_count();
      00AC2B C0 07            [24] 1456 	push	ar7
      00AC2D C0 06            [24] 1457 	push	ar6
      00AC2F C0 05            [24] 1458 	push	ar5
      00AC31 C0 04            [24] 1459 	push	ar4
      00AC33 C0 03            [24] 1460 	push	ar3
      00AC35 12 8D FD         [24] 1461 	lcall	_dynamic_keymap_macro_get_count
      00AC38 AA 82            [24] 1462 	mov	r2, dpl
      00AC3A D0 03            [24] 1463 	pop	ar3
      00AC3C D0 04            [24] 1464 	pop	ar4
      00AC3E D0 05            [24] 1465 	pop	ar5
      00AC40 D0 06            [24] 1466 	pop	ar6
      00AC42 D0 07            [24] 1467 	pop	ar7
      00AC44 12 38 5C         [24] 1468 	lcall	_ak820_outline_0125
      00AC47 EA               [12] 1469 	mov	a,r2
      00AC48 F0               [24] 1470 	movx	@dptr,a
                                   1471 ;	quantum/via.c:430: break;
      00AC49 C1 6C            [12] 1472 	ajmp	00171$
                                   1473 ;	quantum/via.c:432: case id_dynamic_keymap_macro_get_buffer_size: {
      00AC4B                       1474 00140$:
                                   1475 ;	quantum/via.c:433: uint16_t size   = dynamic_keymap_macro_get_buffer_size();
      00AC4B C0 07            [24] 1476 	push	ar7
      00AC4D C0 06            [24] 1477 	push	ar6
      00AC4F C0 05            [24] 1478 	push	ar5
      00AC51 C0 04            [24] 1479 	push	ar4
      00AC53 C0 03            [24] 1480 	push	ar3
      00AC55 12 8E 01         [24] 1481 	lcall	_dynamic_keymap_macro_get_buffer_size
      00AC58 12 4D 22         [24] 1482 	lcall	_ak820_outline_0189
      00AC5B D0 03            [24] 1483 	pop	ar3
      00AC5D D0 04            [24] 1484 	pop	ar4
      00AC5F D0 05            [24] 1485 	pop	ar5
      00AC61 D0 06            [24] 1486 	pop	ar6
      00AC63 D0 07            [24] 1487 	pop	ar7
                                   1488 ;	quantum/via.c:434: command_data[0] = size >> 8;
      00AC65 8A 00            [24] 1489 	mov	ar0,r2
      00AC67 12 38 5C         [24] 1490 	lcall	_ak820_outline_0125
      00AC6A E8               [12] 1491 	mov	a,r0
      00AC6B 12 42 CD         [24] 1492 	lcall	_ak820_outline_0031
                                   1493 ;	quantum/via.c:435: command_data[1] = size & 0xFF;
      00AC6E E9               [12] 1494 	mov	a,r1
      00AC6F F0               [24] 1495 	movx	@dptr,a
                                   1496 ;	quantum/via.c:436: break;
      00AC70 C1 6C            [12] 1497 	ajmp	00171$
                                   1498 ;	quantum/via.c:438: case id_dynamic_keymap_macro_get_buffer: {
      00AC72                       1499 00141$:
                                   1500 ;	quantum/via.c:439: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00AC72 C0 03            [24] 1501 	push	ar3
      00AC74 12 AE 7A         [24] 1502 	lcall	_ak820_outline_0001
      00AC77 89 38            [24] 1503 	mov	_raw_hid_receive_sloc0_1_0,r1
      00AC79 8A 39            [24] 1504 	mov	(_raw_hid_receive_sloc0_1_0 + 1),r2
                                   1505 ;	quantum/via.c:440: uint16_t size   = command_data[2]; // size <= 28
      00AC7B 12 AE 91         [24] 1506 	lcall	_ak820_outline_0015
      00AC7E FB               [12] 1507 	mov	r3,a
                                   1508 ;	quantum/via.c:441: if (size <= 28)
      00AC7F 8B 3E            [24] 1509 	mov	_raw_hid_receive_sloc3_1_0,r3
      00AC81 75 3F 00         [24] 1510 	mov	(_raw_hid_receive_sloc3_1_0 + 1),#0x00
      00AC84 C3               [12] 1511 	clr	c
      00AC85 74 1C            [12] 1512 	mov	a,#0x1c
      00AC87 9B               [12] 1513 	subb	a,r3
      00AC88 D0 03            [24] 1514 	pop	ar3
      00AC8A 50 02            [24] 1515 	jnc	00562$
      00AC8C C1 6C            [12] 1516 	ajmp	00171$
      00AC8E                       1517 00562$:
                                   1518 ;	free result
                                   1519 ;	quantum/via.c:442: dynamic_keymap_macro_get_buffer(offset, size, &command_data[3]);
      00AC8E 12 AE AC         [24] 1520 	lcall	_ak820_outline_0070
      00AC91 90 0B 6F         [24] 1521 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_2
      00AC94 E5 3E            [12] 1522 	mov	a,_raw_hid_receive_sloc3_1_0
      00AC96 F0               [24] 1523 	movx	@dptr,a
      00AC97 E5 3F            [12] 1524 	mov	a,(_raw_hid_receive_sloc3_1_0 + 1)
      00AC99 A3               [24] 1525 	inc	dptr
      00AC9A F0               [24] 1526 	movx	@dptr,a
      00AC9B 90 0B 71         [24] 1527 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_3
      00AC9E 12 AE B6         [24] 1528 	lcall	_ak820_outline_0087
      00ACA1 85 38 82         [24] 1529 	mov	dpl, _raw_hid_receive_sloc0_1_0
      00ACA4 85 39 83         [24] 1530 	mov	dph, (_raw_hid_receive_sloc0_1_0 + 1)
      00ACA7 C0 07            [24] 1531 	push	ar7
      00ACA9 C0 06            [24] 1532 	push	ar6
      00ACAB C0 03            [24] 1533 	push	ar3
      00ACAD 12 8E 05         [24] 1534 	lcall	_dynamic_keymap_macro_get_buffer
      00ACB0 D0 03            [24] 1535 	pop	ar3
      00ACB2 D0 06            [24] 1536 	pop	ar6
      00ACB4 D0 07            [24] 1537 	pop	ar7
                                   1538 ;	quantum/via.c:443: break;
      00ACB6 C1 6C            [12] 1539 	ajmp	00171$
                                   1540 ;	quantum/via.c:445: case id_dynamic_keymap_macro_set_buffer: {
      00ACB8                       1541 00144$:
                                   1542 ;	quantum/via.c:448: if (!vial_unlocked) {
      00ACB8 90 0E 45         [24] 1543 	mov	dptr,#_vial_unlocked
      00ACBB E0               [24] 1544 	movx	a,@dptr
      00ACBC 70 01            [24] 1545 	jnz	00146$
                                   1546 ;	quantum/via.c:450: return;
      00ACBE 22               [24] 1547 	ret
      00ACBF                       1548 00146$:
                                   1549 ;	quantum/via.c:456: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00ACBF C0 03            [24] 1550 	push	ar3
      00ACC1 12 AE 7A         [24] 1551 	lcall	_ak820_outline_0001
      00ACC4 89 3E            [24] 1552 	mov	_raw_hid_receive_sloc3_1_0,r1
      00ACC6 8A 3F            [24] 1553 	mov	(_raw_hid_receive_sloc3_1_0 + 1),r2
                                   1554 ;	quantum/via.c:457: uint16_t size   = command_data[2]; // size <= 28
      00ACC8 12 AE 91         [24] 1555 	lcall	_ak820_outline_0015
      00ACCB F5 38            [12] 1556 	mov	_raw_hid_receive_sloc0_1_0, a
      00ACCD 75 39 00         [24] 1557 	mov	(_raw_hid_receive_sloc0_1_0 + 1),#0x00
                                   1558 ;	quantum/via.c:461: if (size > 28 || size > length - 4 || !dynamic_keymap_macro_set_buffer(offset, size, &command_data[3])) return;
      00ACD0 85 38 40         [24] 1559 	mov	_raw_hid_receive_sloc4_1_0,_raw_hid_receive_sloc0_1_0
      00ACD3 85 39 41         [24] 1560 	mov	(_raw_hid_receive_sloc4_1_0 + 1),(_raw_hid_receive_sloc0_1_0 + 1)
      00ACD6 C3               [12] 1561 	clr	c
      00ACD7 74 1C            [12] 1562 	mov	a,#0x1c
      00ACD9 95 40            [12] 1563 	subb	a,_raw_hid_receive_sloc4_1_0
      00ACDB E4               [12] 1564 	clr	a
      00ACDC 95 41            [12] 1565 	subb	a,(_raw_hid_receive_sloc4_1_0 + 1)
      00ACDE D0 03            [24] 1566 	pop	ar3
      00ACE0 40 43            [24] 1567 	jc	00147$
                                   1568 ;	free result
      00ACE2 8B 01            [24] 1569 	mov	ar1,r3
      00ACE4 7A 00            [12] 1570 	mov	r2,#0x00
      00ACE6 E9               [12] 1571 	mov	a,r1
      00ACE7 24 FC            [12] 1572 	add	a,#0xfc
      00ACE9 F9               [12] 1573 	mov	r1,a
      00ACEA EA               [12] 1574 	mov	a,r2
      00ACEB 34 FF            [12] 1575 	addc	a,#0xff
      00ACED FA               [12] 1576 	mov	r2,a
      00ACEE C3               [12] 1577 	clr	c
      00ACEF E9               [12] 1578 	mov	a,r1
      00ACF0 95 40            [12] 1579 	subb	a,_raw_hid_receive_sloc4_1_0
      00ACF2 EA               [12] 1580 	mov	a,r2
      00ACF3 95 41            [12] 1581 	subb	a,(_raw_hid_receive_sloc4_1_0 + 1)
      00ACF5 40 2E            [24] 1582 	jc	00147$
                                   1583 ;	free result
      00ACF7 12 AE AC         [24] 1584 	lcall	_ak820_outline_0070
      00ACFA 90 0B 76         [24] 1585 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_2
      00ACFD E5 38            [12] 1586 	mov	a,_raw_hid_receive_sloc0_1_0
      00ACFF F0               [24] 1587 	movx	@dptr,a
      00AD00 E5 39            [12] 1588 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00AD02 A3               [24] 1589 	inc	dptr
      00AD03 F0               [24] 1590 	movx	@dptr,a
      00AD04 90 0B 78         [24] 1591 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_3
      00AD07 12 AE B6         [24] 1592 	lcall	_ak820_outline_0087
      00AD0A 85 3E 82         [24] 1593 	mov	dpl, _raw_hid_receive_sloc3_1_0
      00AD0D 85 3F 83         [24] 1594 	mov	dph, (_raw_hid_receive_sloc3_1_0 + 1)
      00AD10 C0 07            [24] 1595 	push	ar7
      00AD12 C0 06            [24] 1596 	push	ar6
      00AD14 C0 03            [24] 1597 	push	ar3
      00AD16 12 8E 51         [24] 1598 	lcall	_dynamic_keymap_macro_set_buffer
      00AD19 E5 82            [12] 1599 	mov	a, dpl
      00AD1B D0 03            [24] 1600 	pop	ar3
      00AD1D D0 06            [24] 1601 	pop	ar6
      00AD1F D0 07            [24] 1602 	pop	ar7
      00AD21 60 02            [24] 1603 	jz	00566$
      00AD23 C1 6C            [12] 1604 	ajmp	00171$
      00AD25                       1605 00566$:
      00AD25                       1606 00147$:
      00AD25 22               [24] 1607 	ret
                                   1608 ;	quantum/via.c:468: case id_dynamic_keymap_macro_reset: {
      00AD26                       1609 00151$:
                                   1610 ;	quantum/via.c:470: if (!vial_unlocked) return;
      00AD26 90 0E 45         [24] 1611 	mov	dptr,#_vial_unlocked
      00AD29 E0               [24] 1612 	movx	a,@dptr
      00AD2A 70 01            [24] 1613 	jnz	00153$
      00AD2C 22               [24] 1614 	ret
      00AD2D                       1615 00153$:
                                   1616 ;	quantum/via.c:472: dynamic_keymap_macro_reset();
      00AD2D C0 07            [24] 1617 	push	ar7
      00AD2F C0 06            [24] 1618 	push	ar6
      00AD31 C0 03            [24] 1619 	push	ar3
      00AD33 12 8E 83         [24] 1620 	lcall	_dynamic_keymap_macro_reset
      00AD36 D0 03            [24] 1621 	pop	ar3
      00AD38 D0 06            [24] 1622 	pop	ar6
      00AD3A D0 07            [24] 1623 	pop	ar7
                                   1624 ;	quantum/via.c:473: break;
      00AD3C C1 6C            [12] 1625 	ajmp	00171$
                                   1626 ;	quantum/via.c:475: case id_dynamic_keymap_get_layer_count: {
      00AD3E                       1627 00154$:
                                   1628 ;	quantum/via.c:476: command_data[0] = dynamic_keymap_get_layer_count();
      00AD3E C0 07            [24] 1629 	push	ar7
      00AD40 C0 06            [24] 1630 	push	ar6
      00AD42 C0 05            [24] 1631 	push	ar5
      00AD44 C0 04            [24] 1632 	push	ar4
      00AD46 C0 03            [24] 1633 	push	ar3
      00AD48 12 86 F4         [24] 1634 	lcall	_dynamic_keymap_get_layer_count
      00AD4B AA 82            [24] 1635 	mov	r2, dpl
      00AD4D D0 03            [24] 1636 	pop	ar3
      00AD4F D0 04            [24] 1637 	pop	ar4
      00AD51 D0 05            [24] 1638 	pop	ar5
      00AD53 D0 06            [24] 1639 	pop	ar6
      00AD55 D0 07            [24] 1640 	pop	ar7
      00AD57 12 38 5C         [24] 1641 	lcall	_ak820_outline_0125
      00AD5A EA               [12] 1642 	mov	a,r2
      00AD5B F0               [24] 1643 	movx	@dptr,a
                                   1644 ;	quantum/via.c:477: break;
      00AD5C C1 6C            [12] 1645 	ajmp	00171$
                                   1646 ;	quantum/via.c:479: case id_dynamic_keymap_get_buffer: {
      00AD5E                       1647 00155$:
                                   1648 ;	quantum/via.c:480: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00AD5E C0 03            [24] 1649 	push	ar3
      00AD60 12 AE 7A         [24] 1650 	lcall	_ak820_outline_0001
      00AD63 89 40            [24] 1651 	mov	_raw_hid_receive_sloc4_1_0,r1
      00AD65 8A 41            [24] 1652 	mov	(_raw_hid_receive_sloc4_1_0 + 1),r2
                                   1653 ;	quantum/via.c:481: uint16_t size   = command_data[2]; // size <= 28
      00AD67 12 AE 91         [24] 1654 	lcall	_ak820_outline_0015
      00AD6A FB               [12] 1655 	mov	r3,a
                                   1656 ;	quantum/via.c:482: if (size <= 28)
      00AD6B 8B 3E            [24] 1657 	mov	_raw_hid_receive_sloc3_1_0,r3
      00AD6D 75 3F 00         [24] 1658 	mov	(_raw_hid_receive_sloc3_1_0 + 1),#0x00
      00AD70 C3               [12] 1659 	clr	c
      00AD71 74 1C            [12] 1660 	mov	a,#0x1c
      00AD73 9B               [12] 1661 	subb	a,r3
      00AD74 D0 03            [24] 1662 	pop	ar3
      00AD76 50 02            [24] 1663 	jnc	00568$
      00AD78 C1 6C            [12] 1664 	ajmp	00171$
      00AD7A                       1665 00568$:
                                   1666 ;	free result
                                   1667 ;	quantum/via.c:483: dynamic_keymap_get_buffer(offset, size, &command_data[3]);
      00AD7A 12 AE AC         [24] 1668 	lcall	_ak820_outline_0070
      00AD7D 90 0B 58         [24] 1669 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_2
      00AD80 E5 3E            [12] 1670 	mov	a,_raw_hid_receive_sloc3_1_0
      00AD82 F0               [24] 1671 	movx	@dptr,a
      00AD83 E5 3F            [12] 1672 	mov	a,(_raw_hid_receive_sloc3_1_0 + 1)
      00AD85 A3               [24] 1673 	inc	dptr
      00AD86 F0               [24] 1674 	movx	@dptr,a
      00AD87 90 0B 5A         [24] 1675 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_3
      00AD8A 12 AE B6         [24] 1676 	lcall	_ak820_outline_0087
      00AD8D 85 40 82         [24] 1677 	mov	dpl, _raw_hid_receive_sloc4_1_0
      00AD90 85 41 83         [24] 1678 	mov	dph, (_raw_hid_receive_sloc4_1_0 + 1)
      00AD93 C0 07            [24] 1679 	push	ar7
      00AD95 C0 06            [24] 1680 	push	ar6
      00AD97 C0 03            [24] 1681 	push	ar3
      00AD99 12 8B C9         [24] 1682 	lcall	_dynamic_keymap_get_buffer
      00AD9C D0 03            [24] 1683 	pop	ar3
      00AD9E D0 06            [24] 1684 	pop	ar6
      00ADA0 D0 07            [24] 1685 	pop	ar7
                                   1686 ;	quantum/via.c:484: break;
      00ADA2 C1 6C            [12] 1687 	ajmp	00171$
                                   1688 ;	quantum/via.c:486: case id_dynamic_keymap_set_buffer: {
      00ADA4                       1689 00158$:
                                   1690 ;	quantum/via.c:487: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00ADA4 12 43 13         [24] 1691 	lcall	_ak820_outline_0095
      00ADA7 FD               [12] 1692 	mov	r5,a
      00ADA8 7C 00            [12] 1693 	mov	r4,#0x00
      00ADAA 12 37 F4         [24] 1694 	lcall	_ak820_outline_0034
      00ADAD 7A 00            [12] 1695 	mov	r2,#0x00
      00ADAF 42 04            [12] 1696 	orl	ar4,a
      00ADB1 EA               [12] 1697 	mov	a,r2
      00ADB2 42 05            [12] 1698 	orl	ar5,a
      00ADB4 8C 40            [24] 1699 	mov	_raw_hid_receive_sloc4_1_0,r4
      00ADB6 8D 41            [24] 1700 	mov	(_raw_hid_receive_sloc4_1_0 + 1),r5
                                   1701 ;	quantum/via.c:488: uint16_t size   = command_data[2]; // size <= 28
      00ADB8 12 AE 91         [24] 1702 	lcall	_ak820_outline_0015
      00ADBB F9               [12] 1703 	mov	r1,a
      00ADBC 7A 00            [12] 1704 	mov	r2,#0x00
                                   1705 ;	quantum/via.c:489: if (size <= 28)
      00ADBE 89 00            [24] 1706 	mov	ar0,r1
      00ADC0 E8               [12] 1707 	mov	a,r0
      00ADC1 24 E3            [12] 1708 	add	a,#0xff - 0x1c
      00ADC3 50 02            [24] 1709 	jnc	00569$
      00ADC5 C1 6C            [12] 1710 	ajmp	00171$
      00ADC7                       1711 00569$:
                                   1712 ;	free result
                                   1713 ;	quantum/via.c:490: dynamic_keymap_set_buffer(offset, size, &command_data[3]);
      00ADC7 C0 03            [24] 1714 	push	ar3
      00ADC9 74 04            [12] 1715 	mov	a,#0x04
      00ADCB 2E               [12] 1716 	add	a, r6
      00ADCC F8               [12] 1717 	mov	r0,a
      00ADCD E4               [12] 1718 	clr	a
      00ADCE 3F               [12] 1719 	addc	a, r7
      00ADCF FB               [12] 1720 	mov	r3,a
      00ADD0 7D 00            [12] 1721 	mov	r5,#0x00
      00ADD2 90 0B 5F         [24] 1722 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_2
      00ADD5 12 4D 15         [24] 1723 	lcall	_ak820_outline_0139
      00ADD8 90 0B 61         [24] 1724 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_3
      00ADDB E8               [12] 1725 	mov	a,r0
      00ADDC F0               [24] 1726 	movx	@dptr,a
      00ADDD EB               [12] 1727 	mov	a,r3
      00ADDE A3               [24] 1728 	inc	dptr
      00ADDF F0               [24] 1729 	movx	@dptr,a
      00ADE0 ED               [12] 1730 	mov	a,r5
      00ADE1 A3               [24] 1731 	inc	dptr
      00ADE2 F0               [24] 1732 	movx	@dptr,a
      00ADE3 85 40 82         [24] 1733 	mov	dpl, _raw_hid_receive_sloc4_1_0
      00ADE6 85 41 83         [24] 1734 	mov	dph, (_raw_hid_receive_sloc4_1_0 + 1)
      00ADE9 C0 07            [24] 1735 	push	ar7
      00ADEB C0 06            [24] 1736 	push	ar6
      00ADED C0 03            [24] 1737 	push	ar3
      00ADEF 12 8C 0A         [24] 1738 	lcall	_dynamic_keymap_set_buffer
      00ADF2 D0 03            [24] 1739 	pop	ar3
      00ADF4 D0 06            [24] 1740 	pop	ar6
      00ADF6 D0 07            [24] 1741 	pop	ar7
                                   1742 ;	quantum/via.c:491: break;
      00ADF8 D0 03            [24] 1743 	pop	ar3
      00ADFA C1 6C            [12] 1744 	ajmp	00171$
                                   1745 ;	quantum/via.c:495: case id_bootloader_jump: {
      00ADFC                       1746 00161$:
                                   1747 ;	quantum/via.c:497: if (!vial_unlocked)
      00ADFC 90 0E 45         [24] 1748 	mov	dptr,#_vial_unlocked
      00ADFF E0               [24] 1749 	movx	a,@dptr
      00AE00 70 02            [24] 1750 	jnz	00570$
      00AE02 C1 6C            [12] 1751 	ajmp	00171$
      00AE04                       1752 00570$:
                                   1753 ;	quantum/via.c:501: raw_hid_send(data, length);
      00AE04 12 AE CF         [24] 1754 	lcall	_ak820_outline_0155
      00AE07 90 06 BD         [24] 1755 	mov	dptr,#_raw_hid_send_PARM_2
      00AE0A 12 AE BF         [24] 1756 	lcall	_ak820_outline_0088
      00AE0D C0 07            [24] 1757 	push	ar7
      00AE0F C0 06            [24] 1758 	push	ar6
      00AE11 C0 03            [24] 1759 	push	ar3
      00AE13 12 4F 58         [24] 1760 	lcall	_raw_hid_send
      00AE16 D0 03            [24] 1761 	pop	ar3
      00AE18 D0 06            [24] 1762 	pop	ar6
      00AE1A D0 07            [24] 1763 	pop	ar7
                                   1764 ;	quantum/via.c:503: wait_ms(100);
      00AE1C 7D 64            [12] 1765 	mov	r5,#0x64
      00AE1E                       1766 00176$:
      00AE1E ED               [12] 1767 	mov	a,r5
      00AE1F 60 09            [24] 1768 	jz	00166$
      00AE21 90 00 01         [24] 1769 	mov	dptr,#0x0001
      00AE24 12 5C F8         [24] 1770 	lcall	_mDelaymS
      00AE27 1D               [12] 1771 	dec	r5
      00AE28 80 F4            [24] 1772 	sjmp	00176$
      00AE2A                       1773 00166$:
                                   1774 ;	quantum/via.c:504: bootloader_jump();
      00AE2A C0 07            [24] 1775 	push	ar7
      00AE2C C0 06            [24] 1776 	push	ar6
      00AE2E C0 03            [24] 1777 	push	ar3
      00AE30 12 34 0E         [24] 1778 	lcall	_bootloader_jump
      00AE33 D0 03            [24] 1779 	pop	ar3
      00AE35 D0 06            [24] 1780 	pop	ar6
      00AE37 D0 07            [24] 1781 	pop	ar7
                                   1782 ;	quantum/via.c:505: break;
                                   1783 ;	quantum/via.c:509: case id_vial_prefix: {
      00AE39 80 31            [24] 1784 	sjmp	00171$
      00AE3B                       1785 00168$:
                                   1786 ;	quantum/via.c:510: vial_handle_cmd(data, length);
      00AE3B 12 AE CF         [24] 1787 	lcall	_ak820_outline_0155
      00AE3E 90 0C 7D         [24] 1788 	mov	dptr,#_vial_handle_cmd_PARM_2
      00AE41 12 AE BF         [24] 1789 	lcall	_ak820_outline_0088
      00AE44 C0 07            [24] 1790 	push	ar7
      00AE46 C0 06            [24] 1791 	push	ar6
      00AE48 C0 03            [24] 1792 	push	ar3
      00AE4A 12 AF BF         [24] 1793 	lcall	_vial_handle_cmd
      00AE4D D0 03            [24] 1794 	pop	ar3
      00AE4F D0 06            [24] 1795 	pop	ar6
      00AE51 D0 07            [24] 1796 	pop	ar7
                                   1797 ;	quantum/via.c:511: break;
                                   1798 ;	quantum/via.c:514: default: {
      00AE53 80 17            [24] 1799 	sjmp	00171$
      00AE55                       1800 00169$:
                                   1801 ;	quantum/via.c:516: raw_hid_receive_kb(data, length);
      00AE55 12 AE CF         [24] 1802 	lcall	_ak820_outline_0155
      00AE58 90 0C 6B         [24] 1803 	mov	dptr,#_raw_hid_receive_kb_PARM_2
      00AE5B 12 AE BF         [24] 1804 	lcall	_ak820_outline_0088
      00AE5E C0 07            [24] 1805 	push	ar7
      00AE60 C0 06            [24] 1806 	push	ar6
      00AE62 C0 03            [24] 1807 	push	ar3
      00AE64 31 04            [24] 1808 	acall	_raw_hid_receive_kb
      00AE66 D0 03            [24] 1809 	pop	ar3
      00AE68 D0 06            [24] 1810 	pop	ar6
      00AE6A D0 07            [24] 1811 	pop	ar7
                                   1812 ;	quantum/via.c:521: skip:
      00AE6C                       1813 00171$:
                                   1814 ;	quantum/via.c:525: raw_hid_send(data, length);
      00AE6C 7D 00            [12] 1815 	mov	r5,#0x00
      00AE6E 90 06 BD         [24] 1816 	mov	dptr,#_raw_hid_send_PARM_2
      00AE71 EB               [12] 1817 	mov	a,r3
      00AE72 12 42 F9         [24] 1818 	lcall	_ak820_outline_0061
      00AE75 8D F0            [24] 1819 	mov	b, r5
                                   1820 ;	quantum/via.c:526: }
      00AE77 02 4F 58         [24] 1821 	ljmp	_raw_hid_send
                                   1822 	.area CSEG    (CODE)
                                   1823 	.area CONST   (CODE)
                                   1824 	.area XINIT   (CODE)
                                   1825 	.area CABS    (ABS,CODE)
                                   1826 
                                   1827 ; Experimental exact instruction outlining.
                                   1828 	.globl _ak820_outline_0001
                                   1829 	.globl _ak820_outline_0003
                                   1830 	.globl _ak820_outline_0010
                                   1831 	.globl _ak820_outline_0011
                                   1832 	.globl _ak820_outline_0014
                                   1833 	.globl _ak820_outline_0015
                                   1834 	.globl _ak820_outline_0016
                                   1835 	.globl _ak820_outline_0022
                                   1836 	.globl _ak820_outline_0023
                                   1837 	.globl _ak820_outline_0031
                                   1838 	.globl _ak820_outline_0034
                                   1839 	.globl _ak820_outline_0037
                                   1840 	.globl _ak820_outline_0038
                                   1841 	.globl _ak820_outline_0042
                                   1842 	.globl _ak820_outline_0045
                                   1843 	.globl _ak820_outline_0051
                                   1844 	.globl _ak820_outline_0061
                                   1845 	.globl _ak820_outline_0070
                                   1846 	.globl _ak820_outline_0087
                                   1847 	.globl _ak820_outline_0088
                                   1848 	.globl _ak820_outline_0093
                                   1849 	.globl _ak820_outline_0095
                                   1850 	.globl _ak820_outline_0100
                                   1851 	.globl _ak820_outline_0106
                                   1852 	.globl _ak820_outline_0107
                                   1853 	.globl _ak820_outline_0121
                                   1854 	.globl _ak820_outline_0123
                                   1855 	.globl _ak820_outline_0125
                                   1856 	.globl _ak820_outline_0139
                                   1857 	.globl _ak820_outline_0154
                                   1858 	.globl _ak820_outline_0155
                                   1859 	.globl _ak820_outline_0157
                                   1860 	.globl _ak820_outline_0160
                                   1861 	.globl _ak820_outline_0161
                                   1862 	.globl _ak820_outline_0163
                                   1863 	.globl _ak820_outline_0164
                                   1864 	.globl _ak820_outline_0189
                                   1865 
                                   1866 	.area CSEG (CODE)
                                   1867 ; function ak820_outline_0001
      00AE7A                       1868 _ak820_outline_0001:
      00AE7A 8C 82            [24] 1869 	mov	dpl,r4
      00AE7C 8D 83            [24] 1870 	mov	dph,r5
      00AE7E E0               [24] 1871 	movx	a,@dptr
      00AE7F FA               [12] 1872 	mov	r2,a
      00AE80 79 00            [12] 1873 	mov	r1,#0x00
      00AE82 8E 82            [24] 1874 	mov	dpl,r6
      00AE84 8F 83            [24] 1875 	mov	dph,r7
      00AE86 A3               [24] 1876 	inc	dptr
      00AE87 A3               [24] 1877 	inc	dptr
      00AE88 E0               [24] 1878 	movx	a,@dptr
      00AE89 7B 00            [12] 1879 	mov	r3,#0x00
      00AE8B 42 01            [12] 1880 	orl	ar1,a
      00AE8D EB               [12] 1881 	mov	a,r3
      00AE8E 42 02            [12] 1882 	orl	ar2,a
      00AE90 22               [24] 1883 	ret
                                   1884 
                                   1885 	.area CSEG (CODE)
                                   1886 ; function ak820_outline_0015
      00AE91                       1887 _ak820_outline_0015:
      00AE91 8E 82            [24] 1888 	mov	dpl,r6
      00AE93 8F 83            [24] 1889 	mov	dph,r7
      00AE95 A3               [24] 1890 	inc	dptr
      00AE96 A3               [24] 1891 	inc	dptr
      00AE97 A3               [24] 1892 	inc	dptr
      00AE98 E0               [24] 1893 	movx	a,@dptr
      00AE99 22               [24] 1894 	ret
                                   1895 
                                   1896 	.area CSEG (CODE)
                                   1897 ; function ak820_outline_0022
      00AE9A                       1898 _ak820_outline_0022:
      00AE9A 8E 82            [24] 1899 	mov	dpl,r6
      00AE9C 8F 83            [24] 1900 	mov	dph,r7
      00AE9E A3               [24] 1901 	inc	dptr
      00AE9F A3               [24] 1902 	inc	dptr
      00AEA0 A3               [24] 1903 	inc	dptr
      00AEA1 A3               [24] 1904 	inc	dptr
      00AEA2 22               [24] 1905 	ret
                                   1906 
                                   1907 	.area CSEG (CODE)
                                   1908 ; function ak820_outline_0038
      00AEA3                       1909 _ak820_outline_0038:
      00AEA3 EB               [12] 1910 	mov	a,r3
      00AEA4 F0               [24] 1911 	movx	@dptr,a
      00AEA5 88 82            [24] 1912 	mov	dpl,r0
      00AEA7 89 83            [24] 1913 	mov	dph,r1
      00AEA9 8A F0            [24] 1914 	mov	b,r2
      00AEAB 22               [24] 1915 	ret
                                   1916 
                                   1917 	.area CSEG (CODE)
                                   1918 ; function ak820_outline_0070
      00AEAC                       1919 _ak820_outline_0070:
      00AEAC 74 04            [12] 1920 	mov	a,#0x04
      00AEAE 2E               [12] 1921 	add	a,r6
      00AEAF F9               [12] 1922 	mov	r1,a
      00AEB0 E4               [12] 1923 	clr	a
      00AEB1 3F               [12] 1924 	addc	a,r7
      00AEB2 F8               [12] 1925 	mov	r0,a
      00AEB3 7A 00            [12] 1926 	mov	r2,#0x00
      00AEB5 22               [24] 1927 	ret
                                   1928 
                                   1929 	.area CSEG (CODE)
                                   1930 ; function ak820_outline_0087
      00AEB6                       1931 _ak820_outline_0087:
      00AEB6 E9               [12] 1932 	mov	a,r1
      00AEB7 F0               [24] 1933 	movx	@dptr,a
      00AEB8 E8               [12] 1934 	mov	a,r0
      00AEB9 A3               [24] 1935 	inc	dptr
      00AEBA F0               [24] 1936 	movx	@dptr,a
      00AEBB EA               [12] 1937 	mov	a,r2
      00AEBC A3               [24] 1938 	inc	dptr
      00AEBD F0               [24] 1939 	movx	@dptr,a
      00AEBE 22               [24] 1940 	ret
                                   1941 
                                   1942 	.area CSEG (CODE)
                                   1943 ; function ak820_outline_0088
      00AEBF                       1944 _ak820_outline_0088:
      00AEBF EB               [12] 1945 	mov	a,r3
      00AEC0 F0               [24] 1946 	movx	@dptr,a
      00AEC1 8A 82            [24] 1947 	mov	dpl,r2
      00AEC3 8C 83            [24] 1948 	mov	dph,r4
      00AEC5 8D F0            [24] 1949 	mov	b,r5
      00AEC7 22               [24] 1950 	ret
                                   1951 
                                   1952 	.area CSEG (CODE)
                                   1953 ; function ak820_outline_0093
      00AEC8                       1954 _ak820_outline_0093:
      00AEC8 8E 00            [24] 1955 	mov	ar0,r6
      00AECA 8F 01            [24] 1956 	mov	ar1,r7
      00AECC 7A 00            [12] 1957 	mov	r2,#0x00
      00AECE 22               [24] 1958 	ret
                                   1959 
                                   1960 	.area CSEG (CODE)
                                   1961 ; function ak820_outline_0155
      00AECF                       1962 _ak820_outline_0155:
      00AECF 8E 02            [24] 1963 	mov	ar2,r6
      00AED1 8F 04            [24] 1964 	mov	ar4,r7
      00AED3 7D 00            [12] 1965 	mov	r5,#0x00
      00AED5 22               [24] 1966 	ret
