                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module process_grave_esc
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _get_repeat_key_count
                                     12 	.globl _ak820_cache_keycode
                                     13 	.globl _get_weak_mods
                                     14 	.globl _get_mods
                                     15 	.globl _ak820_settings_grave_esc
                                     16 	.globl _unregister_code
                                     17 	.globl _register_code
                                     18 	.globl _ADC_START
                                     19 	.globl _S0_R_FIFO
                                     20 	.globl _S0_T_FIFO
                                     21 	.globl _S0_FREE
                                     22 	.globl _S0_IF_BYTE
                                     23 	.globl _S0_IF_FIRST
                                     24 	.globl _S0_IF_OV
                                     25 	.globl _S0_FST_ACT
                                     26 	.globl _CP_RL2
                                     27 	.globl _C_T2
                                     28 	.globl _TR2
                                     29 	.globl _EXEN2
                                     30 	.globl _TCLK
                                     31 	.globl _RCLK
                                     32 	.globl _EXF2
                                     33 	.globl _CAP1F
                                     34 	.globl _TF2
                                     35 	.globl _RI
                                     36 	.globl _TI
                                     37 	.globl _RB8
                                     38 	.globl _TB8
                                     39 	.globl _REN
                                     40 	.globl _SM2
                                     41 	.globl _SM1
                                     42 	.globl _SM0
                                     43 	.globl _IT0
                                     44 	.globl _IE0
                                     45 	.globl _IT1
                                     46 	.globl _IE1
                                     47 	.globl _TR0
                                     48 	.globl _TF0
                                     49 	.globl _TR1
                                     50 	.globl _TF1
                                     51 	.globl _P4_0
                                     52 	.globl _P4_1
                                     53 	.globl _P4_2
                                     54 	.globl _P4_3
                                     55 	.globl _P4_4
                                     56 	.globl _P4_5
                                     57 	.globl _P4_6
                                     58 	.globl _RXD
                                     59 	.globl _TXD
                                     60 	.globl _INT0
                                     61 	.globl _INT1
                                     62 	.globl _T0
                                     63 	.globl _T1
                                     64 	.globl _MOSI1
                                     65 	.globl _MISO1
                                     66 	.globl _SCK1
                                     67 	.globl _P3_0
                                     68 	.globl _P3_1
                                     69 	.globl _P3_2
                                     70 	.globl _P3_3
                                     71 	.globl _P3_4
                                     72 	.globl _P3_5
                                     73 	.globl _P3_6
                                     74 	.globl _P3_7
                                     75 	.globl _CAP1_
                                     76 	.globl _T2_
                                     77 	.globl _CAP2_
                                     78 	.globl _T2EX_
                                     79 	.globl _RXD1
                                     80 	.globl _TXD1
                                     81 	.globl _P2_0
                                     82 	.globl _P2_1
                                     83 	.globl _P2_2
                                     84 	.globl _P2_3
                                     85 	.globl _P2_4
                                     86 	.globl _P2_5
                                     87 	.globl _P2_6
                                     88 	.globl _P2_7
                                     89 	.globl _AIN0
                                     90 	.globl _AIN1
                                     91 	.globl _AIN2
                                     92 	.globl _AIN3
                                     93 	.globl _AIN4
                                     94 	.globl _AIN5
                                     95 	.globl _AIN6
                                     96 	.globl _AIN7
                                     97 	.globl _CAP1
                                     98 	.globl _T2
                                     99 	.globl _CAP2
                                    100 	.globl _T2EX
                                    101 	.globl _INT0_
                                    102 	.globl _SCS
                                    103 	.globl _MOSI
                                    104 	.globl _MISO
                                    105 	.globl _SCK
                                    106 	.globl _RXD1_
                                    107 	.globl _TXD1_
                                    108 	.globl _P1_0
                                    109 	.globl _P1_1
                                    110 	.globl _P1_2
                                    111 	.globl _P1_3
                                    112 	.globl _P1_4
                                    113 	.globl _P1_5
                                    114 	.globl _P1_6
                                    115 	.globl _P1_7
                                    116 	.globl _AIN8
                                    117 	.globl _AIN9
                                    118 	.globl _AIN10
                                    119 	.globl _AIN11
                                    120 	.globl _AIN12
                                    121 	.globl _AIN13
                                    122 	.globl _RXD_
                                    123 	.globl _TXD_
                                    124 	.globl _SCL0
                                    125 	.globl _SDA0
                                    126 	.globl _P0_0
                                    127 	.globl _P0_1
                                    128 	.globl _P0_2
                                    129 	.globl _P0_3
                                    130 	.globl _P0_4
                                    131 	.globl _P0_5
                                    132 	.globl _P0_6
                                    133 	.globl _P0_7
                                    134 	.globl _IE_SPI0
                                    135 	.globl _IE_USB
                                    136 	.globl _IE_ADC
                                    137 	.globl _IE_UART1
                                    138 	.globl _IE_PWM_I2C
                                    139 	.globl _IE_GPIO
                                    140 	.globl _IE_WDOG
                                    141 	.globl _PX0
                                    142 	.globl _PT0
                                    143 	.globl _PX1
                                    144 	.globl _PT1
                                    145 	.globl _PS
                                    146 	.globl _PT2
                                    147 	.globl _PL_FLAG
                                    148 	.globl _PH_FLAG
                                    149 	.globl _EX0
                                    150 	.globl _ET0
                                    151 	.globl _EX1
                                    152 	.globl _ET1
                                    153 	.globl _ES
                                    154 	.globl _ET2
                                    155 	.globl _E_DIS
                                    156 	.globl _EA
                                    157 	.globl _P
                                    158 	.globl _F1
                                    159 	.globl _OV
                                    160 	.globl _RS0
                                    161 	.globl _RS1
                                    162 	.globl _F0
                                    163 	.globl _AC
                                    164 	.globl _CY
                                    165 	.globl _I2CS_INT_ST
                                    166 	.globl _I2CX_INT
                                    167 	.globl _LED_STATUS
                                    168 	.globl _LED_DMA_H
                                    169 	.globl _LED_DMA_L
                                    170 	.globl _LED_DMA
                                    171 	.globl _LED_PWM_OE
                                    172 	.globl _LED_COMMON
                                    173 	.globl _ADC_CHAN
                                    174 	.globl _ADC_DAT_H
                                    175 	.globl _ADC_DAT_L
                                    176 	.globl _ADC_DAT
                                    177 	.globl _ADC_CTRL
                                    178 	.globl _SPI1_CK_SE
                                    179 	.globl _SPI1_CTRL
                                    180 	.globl _SPI1_DATA
                                    181 	.globl _SPI1_STAT
                                    182 	.globl _SIF1
                                    183 	.globl _SBAUD1
                                    184 	.globl _SBUF1
                                    185 	.globl _SCON1
                                    186 	.globl _SPI0_SETUP
                                    187 	.globl _SPI0_CK_SE
                                    188 	.globl _SPI0_CTRL
                                    189 	.globl _SPI0_DATA
                                    190 	.globl _SPI0_STAT
                                    191 	.globl _T2CAP1H
                                    192 	.globl _T2CAP1L
                                    193 	.globl _T2CAP1
                                    194 	.globl _TH2
                                    195 	.globl _TL2
                                    196 	.globl _T2COUNT
                                    197 	.globl _RCAP2H
                                    198 	.globl _RCAP2L
                                    199 	.globl _RCAP2
                                    200 	.globl _T2MOD
                                    201 	.globl _T2CON
                                    202 	.globl _SBUF
                                    203 	.globl _SCON
                                    204 	.globl _TH1
                                    205 	.globl _TH0
                                    206 	.globl _TL1
                                    207 	.globl _TL0
                                    208 	.globl _TMOD
                                    209 	.globl _TCON
                                    210 	.globl _XBUS_AUX
                                    211 	.globl _P7
                                    212 	.globl _P6_DIR
                                    213 	.globl _P6_OUT_PU
                                    214 	.globl _P6_IN
                                    215 	.globl _P5_DIR
                                    216 	.globl _P5_OUT_PU
                                    217 	.globl _P5_IN
                                    218 	.globl _P4_LED_KEY
                                    219 	.globl _P4_DIR_PU
                                    220 	.globl _P4_MOD_OC
                                    221 	.globl _P4
                                    222 	.globl _P3_DIR_PU
                                    223 	.globl _P3_MOD_OC
                                    224 	.globl _P3
                                    225 	.globl _P2_DIR_PU
                                    226 	.globl _P2_MOD_OC
                                    227 	.globl _P2
                                    228 	.globl _P1_DIR_PU
                                    229 	.globl _P1_MOD_OC
                                    230 	.globl _P1
                                    231 	.globl _P0_DIR_PU
                                    232 	.globl _P0_MOD_OC
                                    233 	.globl _P0
                                    234 	.globl _ROM_CTRL
                                    235 	.globl _ROM_DATA_HH
                                    236 	.globl _ROM_DATA_HL
                                    237 	.globl _ROM_DATA_HI
                                    238 	.globl _ROM_ADDR_H
                                    239 	.globl _ROM_ADDR_L
                                    240 	.globl _ROM_ADDR
                                    241 	.globl _GPIO_IE
                                    242 	.globl _IP_EX
                                    243 	.globl _IE_EX
                                    244 	.globl _IP
                                    245 	.globl _IE
                                    246 	.globl _WDOG_COUNT
                                    247 	.globl _RESET_KEEP
                                    248 	.globl _WAKE_CTRL
                                    249 	.globl _CLOCK_CFG
                                    250 	.globl _POWER_CFG
                                    251 	.globl _PCON
                                    252 	.globl _GLOBAL_CFG
                                    253 	.globl _SAFE_MOD
                                    254 	.globl _DPH
                                    255 	.globl _DPL
                                    256 	.globl _SP
                                    257 	.globl _A_INV
                                    258 	.globl _B
                                    259 	.globl _ACC
                                    260 	.globl _PSW
                                    261 	.globl _process_grave_esc_PARM_2
                                    262 	.globl _process_grave_esc
                                    263 ;--------------------------------------------------------
                                    264 ; special function registers
                                    265 ;--------------------------------------------------------
                                    266 	.area RSEG    (ABS,DATA)
      000000                        267 	.org 0x0000
                           0000D0   268 _PSW	=	0x00d0
                           0000E0   269 _ACC	=	0x00e0
                           0000F0   270 _B	=	0x00f0
                           0000FD   271 _A_INV	=	0x00fd
                           000081   272 _SP	=	0x0081
                           000082   273 _DPL	=	0x0082
                           000083   274 _DPH	=	0x0083
                           0000A1   275 _SAFE_MOD	=	0x00a1
                           0000B1   276 _GLOBAL_CFG	=	0x00b1
                           000087   277 _PCON	=	0x0087
                           0000BA   278 _POWER_CFG	=	0x00ba
                           0000B9   279 _CLOCK_CFG	=	0x00b9
                           0000A9   280 _WAKE_CTRL	=	0x00a9
                           0000FE   281 _RESET_KEEP	=	0x00fe
                           0000FF   282 _WDOG_COUNT	=	0x00ff
                           0000A8   283 _IE	=	0x00a8
                           0000B8   284 _IP	=	0x00b8
                           0000E8   285 _IE_EX	=	0x00e8
                           0000E9   286 _IP_EX	=	0x00e9
                           0000B2   287 _GPIO_IE	=	0x00b2
                           008584   288 _ROM_ADDR	=	0x8584
                           000084   289 _ROM_ADDR_L	=	0x0084
                           000085   290 _ROM_ADDR_H	=	0x0085
                           008F8E   291 _ROM_DATA_HI	=	0x8f8e
                           00008E   292 _ROM_DATA_HL	=	0x008e
                           00008F   293 _ROM_DATA_HH	=	0x008f
                           000086   294 _ROM_CTRL	=	0x0086
                           000080   295 _P0	=	0x0080
                           0000C4   296 _P0_MOD_OC	=	0x00c4
                           0000C5   297 _P0_DIR_PU	=	0x00c5
                           000090   298 _P1	=	0x0090
                           000092   299 _P1_MOD_OC	=	0x0092
                           000093   300 _P1_DIR_PU	=	0x0093
                           0000A0   301 _P2	=	0x00a0
                           000094   302 _P2_MOD_OC	=	0x0094
                           000095   303 _P2_DIR_PU	=	0x0095
                           0000B0   304 _P3	=	0x00b0
                           000096   305 _P3_MOD_OC	=	0x0096
                           000097   306 _P3_DIR_PU	=	0x0097
                           0000C0   307 _P4	=	0x00c0
                           0000C2   308 _P4_MOD_OC	=	0x00c2
                           0000C3   309 _P4_DIR_PU	=	0x00c3
                           0000C1   310 _P4_LED_KEY	=	0x00c1
                           0000AA   311 _P5_IN	=	0x00aa
                           0000AB   312 _P5_OUT_PU	=	0x00ab
                           0000AC   313 _P5_DIR	=	0x00ac
                           0000AD   314 _P6_IN	=	0x00ad
                           0000AE   315 _P6_OUT_PU	=	0x00ae
                           0000AF   316 _P6_DIR	=	0x00af
                           0000F1   317 _P7	=	0x00f1
                           0000A2   318 _XBUS_AUX	=	0x00a2
                           000088   319 _TCON	=	0x0088
                           000089   320 _TMOD	=	0x0089
                           00008A   321 _TL0	=	0x008a
                           00008B   322 _TL1	=	0x008b
                           00008C   323 _TH0	=	0x008c
                           00008D   324 _TH1	=	0x008d
                           000098   325 _SCON	=	0x0098
                           000099   326 _SBUF	=	0x0099
                           0000C8   327 _T2CON	=	0x00c8
                           0000C9   328 _T2MOD	=	0x00c9
                           00CBCA   329 _RCAP2	=	0xcbca
                           0000CA   330 _RCAP2L	=	0x00ca
                           0000CB   331 _RCAP2H	=	0x00cb
                           00CDCC   332 _T2COUNT	=	0xcdcc
                           0000CC   333 _TL2	=	0x00cc
                           0000CD   334 _TH2	=	0x00cd
                           00CFCE   335 _T2CAP1	=	0xcfce
                           0000CE   336 _T2CAP1L	=	0x00ce
                           0000CF   337 _T2CAP1H	=	0x00cf
                           0000F8   338 _SPI0_STAT	=	0x00f8
                           0000F9   339 _SPI0_DATA	=	0x00f9
                           0000FA   340 _SPI0_CTRL	=	0x00fa
                           0000FB   341 _SPI0_CK_SE	=	0x00fb
                           0000FC   342 _SPI0_SETUP	=	0x00fc
                           0000BC   343 _SCON1	=	0x00bc
                           0000BD   344 _SBUF1	=	0x00bd
                           0000BE   345 _SBAUD1	=	0x00be
                           0000BF   346 _SIF1	=	0x00bf
                           0000B4   347 _SPI1_STAT	=	0x00b4
                           0000B5   348 _SPI1_DATA	=	0x00b5
                           0000B6   349 _SPI1_CTRL	=	0x00b6
                           0000B7   350 _SPI1_CK_SE	=	0x00b7
                           0000F3   351 _ADC_CTRL	=	0x00f3
                           00F5F4   352 _ADC_DAT	=	0xf5f4
                           0000F4   353 _ADC_DAT_L	=	0x00f4
                           0000F5   354 _ADC_DAT_H	=	0x00f5
                           0000F6   355 _ADC_CHAN	=	0x00f6
                           0000A6   356 _LED_COMMON	=	0x00a6
                           0000A7   357 _LED_PWM_OE	=	0x00a7
                           00C7C6   358 _LED_DMA	=	0xc7c6
                           0000C6   359 _LED_DMA_L	=	0x00c6
                           0000C7   360 _LED_DMA_H	=	0x00c7
                           0000F7   361 _LED_STATUS	=	0x00f7
                           0000B3   362 _I2CX_INT	=	0x00b3
                           0000BB   363 _I2CS_INT_ST	=	0x00bb
                                    364 ;--------------------------------------------------------
                                    365 ; special function bits
                                    366 ;--------------------------------------------------------
                                    367 	.area RSEG    (ABS,DATA)
      000000                        368 	.org 0x0000
                           0000D7   369 _CY	=	0x00d7
                           0000D6   370 _AC	=	0x00d6
                           0000D5   371 _F0	=	0x00d5
                           0000D4   372 _RS1	=	0x00d4
                           0000D3   373 _RS0	=	0x00d3
                           0000D2   374 _OV	=	0x00d2
                           0000D1   375 _F1	=	0x00d1
                           0000D0   376 _P	=	0x00d0
                           0000AF   377 _EA	=	0x00af
                           0000AE   378 _E_DIS	=	0x00ae
                           0000AD   379 _ET2	=	0x00ad
                           0000AC   380 _ES	=	0x00ac
                           0000AB   381 _ET1	=	0x00ab
                           0000AA   382 _EX1	=	0x00aa
                           0000A9   383 _ET0	=	0x00a9
                           0000A8   384 _EX0	=	0x00a8
                           0000BF   385 _PH_FLAG	=	0x00bf
                           0000BE   386 _PL_FLAG	=	0x00be
                           0000BD   387 _PT2	=	0x00bd
                           0000BC   388 _PS	=	0x00bc
                           0000BB   389 _PT1	=	0x00bb
                           0000BA   390 _PX1	=	0x00ba
                           0000B9   391 _PT0	=	0x00b9
                           0000B8   392 _PX0	=	0x00b8
                           0000EF   393 _IE_WDOG	=	0x00ef
                           0000EE   394 _IE_GPIO	=	0x00ee
                           0000ED   395 _IE_PWM_I2C	=	0x00ed
                           0000EC   396 _IE_UART1	=	0x00ec
                           0000EB   397 _IE_ADC	=	0x00eb
                           0000E9   398 _IE_USB	=	0x00e9
                           0000E8   399 _IE_SPI0	=	0x00e8
                           000087   400 _P0_7	=	0x0087
                           000086   401 _P0_6	=	0x0086
                           000085   402 _P0_5	=	0x0085
                           000084   403 _P0_4	=	0x0084
                           000083   404 _P0_3	=	0x0083
                           000082   405 _P0_2	=	0x0082
                           000081   406 _P0_1	=	0x0081
                           000080   407 _P0_0	=	0x0080
                           000081   408 _SDA0	=	0x0081
                           000080   409 _SCL0	=	0x0080
                           000083   410 _TXD_	=	0x0083
                           000082   411 _RXD_	=	0x0082
                           000085   412 _AIN13	=	0x0085
                           000084   413 _AIN12	=	0x0084
                           000083   414 _AIN11	=	0x0083
                           000082   415 _AIN10	=	0x0082
                           000081   416 _AIN9	=	0x0081
                           000080   417 _AIN8	=	0x0080
                           000097   418 _P1_7	=	0x0097
                           000096   419 _P1_6	=	0x0096
                           000095   420 _P1_5	=	0x0095
                           000094   421 _P1_4	=	0x0094
                           000093   422 _P1_3	=	0x0093
                           000092   423 _P1_2	=	0x0092
                           000091   424 _P1_1	=	0x0091
                           000090   425 _P1_0	=	0x0090
                           000097   426 _TXD1_	=	0x0097
                           000096   427 _RXD1_	=	0x0096
                           000097   428 _SCK	=	0x0097
                           000096   429 _MISO	=	0x0096
                           000095   430 _MOSI	=	0x0095
                           000094   431 _SCS	=	0x0094
                           000092   432 _INT0_	=	0x0092
                           000091   433 _T2EX	=	0x0091
                           000091   434 _CAP2	=	0x0091
                           000090   435 _T2	=	0x0090
                           000090   436 _CAP1	=	0x0090
                           000097   437 _AIN7	=	0x0097
                           000096   438 _AIN6	=	0x0096
                           000095   439 _AIN5	=	0x0095
                           000094   440 _AIN4	=	0x0094
                           000093   441 _AIN3	=	0x0093
                           000092   442 _AIN2	=	0x0092
                           000091   443 _AIN1	=	0x0091
                           000090   444 _AIN0	=	0x0090
                           0000A7   445 _P2_7	=	0x00a7
                           0000A6   446 _P2_6	=	0x00a6
                           0000A5   447 _P2_5	=	0x00a5
                           0000A4   448 _P2_4	=	0x00a4
                           0000A3   449 _P2_3	=	0x00a3
                           0000A2   450 _P2_2	=	0x00a2
                           0000A1   451 _P2_1	=	0x00a1
                           0000A0   452 _P2_0	=	0x00a0
                           0000A7   453 _TXD1	=	0x00a7
                           0000A6   454 _RXD1	=	0x00a6
                           0000A5   455 _T2EX_	=	0x00a5
                           0000A5   456 _CAP2_	=	0x00a5
                           0000A4   457 _T2_	=	0x00a4
                           0000A4   458 _CAP1_	=	0x00a4
                           0000B7   459 _P3_7	=	0x00b7
                           0000B6   460 _P3_6	=	0x00b6
                           0000B5   461 _P3_5	=	0x00b5
                           0000B4   462 _P3_4	=	0x00b4
                           0000B3   463 _P3_3	=	0x00b3
                           0000B2   464 _P3_2	=	0x00b2
                           0000B1   465 _P3_1	=	0x00b1
                           0000B0   466 _P3_0	=	0x00b0
                           0000B7   467 _SCK1	=	0x00b7
                           0000B6   468 _MISO1	=	0x00b6
                           0000B5   469 _MOSI1	=	0x00b5
                           0000B5   470 _T1	=	0x00b5
                           0000B4   471 _T0	=	0x00b4
                           0000B3   472 _INT1	=	0x00b3
                           0000B2   473 _INT0	=	0x00b2
                           0000B1   474 _TXD	=	0x00b1
                           0000B0   475 _RXD	=	0x00b0
                           0000C6   476 _P4_6	=	0x00c6
                           0000C5   477 _P4_5	=	0x00c5
                           0000C4   478 _P4_4	=	0x00c4
                           0000C3   479 _P4_3	=	0x00c3
                           0000C2   480 _P4_2	=	0x00c2
                           0000C1   481 _P4_1	=	0x00c1
                           0000C0   482 _P4_0	=	0x00c0
                           00008F   483 _TF1	=	0x008f
                           00008E   484 _TR1	=	0x008e
                           00008D   485 _TF0	=	0x008d
                           00008C   486 _TR0	=	0x008c
                           00008B   487 _IE1	=	0x008b
                           00008A   488 _IT1	=	0x008a
                           000089   489 _IE0	=	0x0089
                           000088   490 _IT0	=	0x0088
                           00009F   491 _SM0	=	0x009f
                           00009E   492 _SM1	=	0x009e
                           00009D   493 _SM2	=	0x009d
                           00009C   494 _REN	=	0x009c
                           00009B   495 _TB8	=	0x009b
                           00009A   496 _RB8	=	0x009a
                           000099   497 _TI	=	0x0099
                           000098   498 _RI	=	0x0098
                           0000CF   499 _TF2	=	0x00cf
                           0000CF   500 _CAP1F	=	0x00cf
                           0000CE   501 _EXF2	=	0x00ce
                           0000CD   502 _RCLK	=	0x00cd
                           0000CC   503 _TCLK	=	0x00cc
                           0000CB   504 _EXEN2	=	0x00cb
                           0000CA   505 _TR2	=	0x00ca
                           0000C9   506 _C_T2	=	0x00c9
                           0000C8   507 _CP_RL2	=	0x00c8
                           0000FF   508 _S0_FST_ACT	=	0x00ff
                           0000FE   509 _S0_IF_OV	=	0x00fe
                           0000FD   510 _S0_IF_FIRST	=	0x00fd
                           0000FC   511 _S0_IF_BYTE	=	0x00fc
                           0000FB   512 _S0_FREE	=	0x00fb
                           0000FA   513 _S0_T_FIFO	=	0x00fa
                           0000F8   514 _S0_R_FIFO	=	0x00f8
                           0000F7   515 _ADC_START	=	0x00f7
                                    516 ;--------------------------------------------------------
                                    517 ; overlayable register banks
                                    518 ;--------------------------------------------------------
                                    519 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        520 	.ds 8
                                    521 ;--------------------------------------------------------
                                    522 ; internal ram data
                                    523 ;--------------------------------------------------------
                                    524 	.area DSEG    (DATA)
                                    525 ;--------------------------------------------------------
                                    526 ; overlayable items in internal ram
                                    527 ;--------------------------------------------------------
                                    528 ;--------------------------------------------------------
                                    529 ; indirectly addressable internal ram data
                                    530 ;--------------------------------------------------------
                                    531 	.area ISEG    (DATA)
                                    532 ;--------------------------------------------------------
                                    533 ; absolute internal ram data
                                    534 ;--------------------------------------------------------
                                    535 	.area IABS    (ABS,DATA)
                                    536 	.area IABS    (ABS,DATA)
                                    537 ;--------------------------------------------------------
                                    538 ; bit data
                                    539 ;--------------------------------------------------------
                                    540 	.area BSEG    (BIT)
                                    541 ;--------------------------------------------------------
                                    542 ; paged external ram data
                                    543 ;--------------------------------------------------------
                                    544 	.area PSEG    (PAG,XDATA)
                                    545 ;--------------------------------------------------------
                                    546 ; uninitialized external ram data
                                    547 ;--------------------------------------------------------
                                    548 	.area XSEG    (XDATA)
      000BF1                        549 _process_grave_esc_PARM_2:
      000BF1                        550 	.ds 3
      000BF4                        551 _process_grave_esc_keycode_10000_278:
      000BF4                        552 	.ds 2
      000BF6                        553 _process_grave_esc_shifted_30000_281:
      000BF6                        554 	.ds 1
                                    555 ;--------------------------------------------------------
                                    556 ; absolute external ram data
                                    557 ;--------------------------------------------------------
                                    558 	.area XABS    (ABS,XDATA)
                                    559 ;--------------------------------------------------------
                                    560 ; initialized external ram data
                                    561 ;--------------------------------------------------------
                                    562 	.area XISEG   (XDATA)
      000E3A                        563 _grave_esc_was_shifted:
      000E3A                        564 	.ds 1
                                    565 	.area HOME    (CODE)
                                    566 	.area GSINIT0 (CODE)
                                    567 	.area GSINIT1 (CODE)
                                    568 	.area GSINIT2 (CODE)
                                    569 	.area GSINIT3 (CODE)
                                    570 	.area GSINIT4 (CODE)
                                    571 	.area GSINIT5 (CODE)
                                    572 	.area GSINIT  (CODE)
                                    573 	.area GSFINAL (CODE)
                                    574 	.area CSEG    (CODE)
                                    575 ;--------------------------------------------------------
                                    576 ; global & static initialisations
                                    577 ;--------------------------------------------------------
                                    578 	.area HOME    (CODE)
                                    579 	.area GSINIT  (CODE)
                                    580 	.area GSFINAL (CODE)
                                    581 	.area GSINIT  (CODE)
                                    582 ;--------------------------------------------------------
                                    583 ; Home
                                    584 ;--------------------------------------------------------
                                    585 	.area HOME    (CODE)
                                    586 	.area HOME    (CODE)
                                    587 ;--------------------------------------------------------
                                    588 ; code
                                    589 ;--------------------------------------------------------
                                    590 	.area CSEG    (CODE)
                                    591 ;------------------------------------------------------------
                                    592 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    593 ;------------------------------------------------------------
                                    594 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_147'
                                    595 ;------------------------------------------------------------
                                    596 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    597 ;	-----------------------------------------
                           000007   598 	ar7 = 0x07
                           000006   599 	ar6 = 0x06
                           000005   600 	ar5 = 0x05
                           000004   601 	ar4 = 0x04
                           000003   602 	ar3 = 0x03
                           000002   603 	ar2 = 0x02
                           000001   604 	ar1 = 0x01
                           000000   605 	ar0 = 0x00
                                    606 ;	 function process_grave_esc
                                    607 ;	-----------------------------------------
      009C6E                        608 _process_grave_esc:
      009C6E 12 38 52         [24]  609 	lcall	_ak820_outline_0106
      009C71 90 0B F4         [24]  610 	mov	dptr,#_process_grave_esc_keycode_10000_278
      009C74 12 38 57         [24]  611 	lcall	_ak820_outline_0107
                                    612 ;	quantum/process_keycode/process_grave_esc.c:36: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      009C77 90 0B F1         [24]  613 	mov	dptr,#_process_grave_esc_PARM_2
      009C7A 12 37 FC         [24]  614 	lcall	_ak820_outline_0051
                                    615 ;	quantum/process_keycode/process_grave_esc.c:40: if (keycode == QK_GRAVE_ESCAPE) {
      009C7D 90 0B F4         [24]  616 	mov	dptr,#_process_grave_esc_keycode_10000_278
      009C80 12 38 1B         [24]  617 	lcall	_ak820_outline_0059
      009C83 BC 16 05         [24]  618 	cjne	r4,#0x16,00240$
      009C86 BD 7C 02         [24]  619 	cjne	r5,#0x7c,00240$
      009C89 80 02            [24]  620 	sjmp	00241$
      009C8B                        621 00240$:
      009C8B A1 8D            [24]  622 	ajmp	00126$
      009C8D                        623 00241$:
                                    624 ;	quantum/process_keycode/process_grave_esc.c:43: const uint8_t mods    = get_mods() | get_weak_mods();
      009C8D 12 83 C2         [24]  625 	lcall	_get_mods
      009C90 AD 82            [24]  626 	mov	r5, dpl
      009C92 12 83 D8         [24]  627 	lcall	_get_weak_mods
      009C95 E5 82            [12]  628 	mov	a,dpl
      009C97 42 05            [12]  629 	orl	ar5,a
                                    630 ;	quantum/process_keycode/process_grave_esc.c:44: uint8_t       shifted = mods & MOD_MASK_SG;
      009C99 90 0B F6         [24]  631 	mov	dptr,#_process_grave_esc_shifted_30000_281
      009C9C 74 AA            [12]  632 	mov	a,#0xaa
      009C9E 5D               [12]  633 	anl	a,r5
      009C9F F0               [24]  634 	movx	@dptr,a
                                    635 ;	quantum/process_keycode/process_grave_esc.c:46: if (QS_grave_esc_alt_override) {
      009CA0 C0 07            [24]  636 	push	ar7
      009CA2 C0 06            [24]  637 	push	ar6
      009CA4 C0 05            [24]  638 	push	ar5
      009CA6 12 47 A4         [24]  639 	lcall	_ak820_settings_grave_esc
      009CA9 E5 82            [12]  640 	mov	a, dpl
      009CAB D0 05            [24]  641 	pop	ar5
      009CAD D0 06            [24]  642 	pop	ar6
      009CAF D0 07            [24]  643 	pop	ar7
      009CB1 30 E0 08         [24]  644 	jnb	acc.0,00104$
                                    645 ;	quantum/process_keycode/process_grave_esc.c:49: if (mods & MOD_MASK_ALT) {
      009CB4 ED               [12]  646 	mov	a,r5
      009CB5 54 44            [12]  647 	anl	a,#0x44
      009CB7 60 03            [24]  648 	jz	00104$
                                    649 ;	quantum/process_keycode/process_grave_esc.c:50: shifted = 0;
      009CB9 12 9D 91         [24]  650 	lcall	_ak820_outline_0169
      009CBC                        651 00104$:
                                    652 ;	quantum/process_keycode/process_grave_esc.c:54: if (QS_grave_esc_ctrl_override) {
      009CBC C0 07            [24]  653 	push	ar7
      009CBE C0 06            [24]  654 	push	ar6
      009CC0 C0 05            [24]  655 	push	ar5
      009CC2 12 47 A4         [24]  656 	lcall	_ak820_settings_grave_esc
      009CC5 E5 82            [12]  657 	mov	a, dpl
      009CC7 D0 05            [24]  658 	pop	ar5
      009CC9 D0 06            [24]  659 	pop	ar6
      009CCB D0 07            [24]  660 	pop	ar7
      009CCD 30 E1 08         [24]  661 	jnb	acc.1,00108$
                                    662 ;	quantum/process_keycode/process_grave_esc.c:57: if (mods & MOD_MASK_CTRL) {
      009CD0 ED               [12]  663 	mov	a,r5
      009CD1 54 11            [12]  664 	anl	a,#0x11
      009CD3 60 03            [24]  665 	jz	00108$
                                    666 ;	quantum/process_keycode/process_grave_esc.c:58: shifted = 0;
      009CD5 12 9D 91         [24]  667 	lcall	_ak820_outline_0169
      009CD8                        668 00108$:
                                    669 ;	quantum/process_keycode/process_grave_esc.c:62: if (QS_grave_esc_gui_override) {
      009CD8 C0 07            [24]  670 	push	ar7
      009CDA C0 06            [24]  671 	push	ar6
      009CDC C0 05            [24]  672 	push	ar5
      009CDE 12 47 A4         [24]  673 	lcall	_ak820_settings_grave_esc
      009CE1 E5 82            [12]  674 	mov	a, dpl
      009CE3 D0 05            [24]  675 	pop	ar5
      009CE5 D0 06            [24]  676 	pop	ar6
      009CE7 D0 07            [24]  677 	pop	ar7
      009CE9 30 E2 08         [24]  678 	jnb	acc.2,00112$
                                    679 ;	quantum/process_keycode/process_grave_esc.c:64: if (mods & MOD_MASK_GUI) {
      009CEC ED               [12]  680 	mov	a,r5
      009CED 54 88            [12]  681 	anl	a,#0x88
      009CEF 60 03            [24]  682 	jz	00112$
                                    683 ;	quantum/process_keycode/process_grave_esc.c:65: shifted = 0;
      009CF1 12 9D 91         [24]  684 	lcall	_ak820_outline_0169
      009CF4                        685 00112$:
                                    686 ;	quantum/process_keycode/process_grave_esc.c:69: if (QS_grave_esc_shift_override) {
      009CF4 C0 07            [24]  687 	push	ar7
      009CF6 C0 06            [24]  688 	push	ar6
      009CF8 C0 05            [24]  689 	push	ar5
      009CFA 12 47 A4         [24]  690 	lcall	_ak820_settings_grave_esc
      009CFD E5 82            [12]  691 	mov	a, dpl
      009CFF D0 05            [24]  692 	pop	ar5
      009D01 D0 06            [24]  693 	pop	ar6
      009D03 D0 07            [24]  694 	pop	ar7
      009D05 30 E3 08         [24]  695 	jnb	acc.3,00116$
                                    696 ;	quantum/process_keycode/process_grave_esc.c:71: if (mods & MOD_MASK_SHIFT) {
      009D08 ED               [12]  697 	mov	a,r5
      009D09 54 22            [12]  698 	anl	a,#0x22
      009D0B 60 03            [24]  699 	jz	00116$
                                    700 ;	quantum/process_keycode/process_grave_esc.c:72: shifted = 0;
      009D0D 12 9D 91         [24]  701 	lcall	_ak820_outline_0169
      009D10                        702 00116$:
                                    703 ;	quantum/process_keycode/process_grave_esc.c:76: if (record->event.pressed) {
      009D10 74 05            [12]  704 	mov	a,#0x05
      009D12 12 4C B6         [24]  705 	lcall	_ak820_outline_0013
      009D15 60 61            [24]  706 	jz	00123$
                                    707 ;	quantum/process_keycode/process_grave_esc.c:80: uint16_t resolved = shifted ? KC_GRAVE : KC_ESCAPE;
      009D17 90 0B F6         [24]  708 	mov	dptr,#_process_grave_esc_shifted_30000_281
      009D1A E0               [24]  709 	movx	a,@dptr
      009D1B 60 04            [24]  710 	jz	00129$
      009D1D 7D 35            [12]  711 	mov	r5,#0x35
      009D1F 80 02            [24]  712 	sjmp	00130$
      009D21                        713 00129$:
      009D21 7D 29            [12]  714 	mov	r5,#0x29
      009D23                        715 00130$:
      009D23 8D 04            [24]  716 	mov	ar4,r5
      009D25 7D 00            [12]  717 	mov	r5,#0x00
                                    718 ;	quantum/process_keycode/process_grave_esc.c:86: if (get_repeat_key_count()) {
      009D27 12 A4 8D         [24]  719 	lcall	_get_repeat_key_count
      009D2A E5 82            [12]  720 	mov	a, dpl
      009D2C 60 0A            [24]  721 	jz	00120$
                                    722 ;	quantum/process_keycode/process_grave_esc.c:90: record->keycode = resolved;
      009D2E 74 07            [12]  723 	mov	a,#0x07
      009D30 12 37 EC         [24]  724 	lcall	_ak820_outline_0017
      009D33 12 38 21         [24]  725 	lcall	_ak820_outline_0072
      009D36 80 2D            [24]  726 	sjmp	00121$
      009D38                        727 00120$:
                                    728 ;	quantum/process_keycode/process_grave_esc.c:93: if (!ak820_cache_keycode(AK820_KEYPOS_VALUE(record->event.key), resolved)) {
      009D38 12 38 27         [24]  729 	lcall	_ak820_outline_0077
      009D3B FA               [12]  730 	mov	r2,a
      009D3C 7B 00            [12]  731 	mov	r3,#0x00
      009D3E 12 38 3A         [24]  732 	lcall	_ak820_outline_0100
      009D41 7E 00            [12]  733 	mov	r6,#0x00
      009D43 42 03            [12]  734 	orl	ar3,a
      009D45 EE               [12]  735 	mov	a,r6
      009D46 42 02            [12]  736 	orl	ar2,a
      009D48 90 09 A5         [24]  737 	mov	dptr,#_ak820_cache_keycode_PARM_2
      009D4B 12 38 21         [24]  738 	lcall	_ak820_outline_0072
      009D4E 8B 82            [24]  739 	mov	dpl, r3
      009D50 8A 83            [24]  740 	mov	dph, r2
      009D52 12 7D 4D         [24]  741 	lcall	_ak820_cache_keycode
      009D55 E5 82            [12]  742 	mov	a, dpl
      009D57 70 0C            [24]  743 	jnz	00121$
                                    744 ;	quantum/process_keycode/process_grave_esc.c:94: grave_esc_was_shifted = shifted;
      009D59 90 0B F6         [24]  745 	mov	dptr,#_process_grave_esc_shifted_30000_281
                                    746 ;	assignBit
      009D5C E0               [24]  747 	movx	a,@dptr
      009D5D 24 FF            [12]  748 	add	a,#0xff
      009D5F E4               [12]  749 	clr	a
      009D60 33               [12]  750 	rlc	a
      009D61 90 0E 3A         [24]  751 	mov	dptr,#_grave_esc_was_shifted
      009D64 F0               [24]  752 	movx	@dptr,a
      009D65                        753 00121$:
                                    754 ;	quantum/process_keycode/process_grave_esc.c:100: register_code(shifted ? KC_GRAVE : KC_ESCAPE);
      009D65 90 0B F6         [24]  755 	mov	dptr,#_process_grave_esc_shifted_30000_281
      009D68 E0               [24]  756 	movx	a,@dptr
      009D69 60 04            [24]  757 	jz	00131$
      009D6B 7F 35            [12]  758 	mov	r7,#0x35
      009D6D 80 02            [24]  759 	sjmp	00132$
      009D6F                        760 00131$:
      009D6F 7F 29            [12]  761 	mov	r7,#0x29
      009D71                        762 00132$:
      009D71 8F 82            [24]  763 	mov	dpl, r7
      009D73 12 78 C6         [24]  764 	lcall	_register_code
      009D76 80 11            [24]  765 	sjmp	00124$
      009D78                        766 00123$:
                                    767 ;	quantum/process_keycode/process_grave_esc.c:106: unregister_code(grave_esc_was_shifted ? KC_GRAVE : KC_ESCAPE);
      009D78 90 0E 3A         [24]  768 	mov	dptr,#_grave_esc_was_shifted
      009D7B E0               [24]  769 	movx	a,@dptr
      009D7C 60 04            [24]  770 	jz	00133$
      009D7E 7F 35            [12]  771 	mov	r7,#0x35
      009D80 80 02            [24]  772 	sjmp	00134$
      009D82                        773 00133$:
      009D82 7F 29            [12]  774 	mov	r7,#0x29
      009D84                        775 00134$:
      009D84 8F 82            [24]  776 	mov	dpl, r7
      009D86 12 79 33         [24]  777 	lcall	_unregister_code
      009D89                        778 00124$:
                                    779 ;	quantum/process_keycode/process_grave_esc.c:115: return false;
      009D89 75 82 00         [24]  780 	mov	dpl, #0x00
      009D8C 22               [24]  781 	ret
      009D8D                        782 00126$:
                                    783 ;	quantum/process_keycode/process_grave_esc.c:119: return true;
      009D8D 75 82 01         [24]  784 	mov	dpl, #0x01
                                    785 ;	quantum/process_keycode/process_grave_esc.c:120: }
      009D90 22               [24]  786 	ret
                                    787 	.area CSEG    (CODE)
                                    788 	.area CONST   (CODE)
                                    789 	.area XINIT   (CODE)
      00C551                        790 __xinit__grave_esc_was_shifted:
      00C551 00                     791 	.db #0x00	;  0
                                    792 	.area CABS    (ABS,CODE)
                                    793 
                                    794 ; Experimental exact instruction outlining.
                                    795 	.globl _ak820_outline_0013
                                    796 	.globl _ak820_outline_0017
                                    797 	.globl _ak820_outline_0051
                                    798 	.globl _ak820_outline_0059
                                    799 	.globl _ak820_outline_0072
                                    800 	.globl _ak820_outline_0077
                                    801 	.globl _ak820_outline_0100
                                    802 	.globl _ak820_outline_0106
                                    803 	.globl _ak820_outline_0107
                                    804 	.globl _ak820_outline_0169
                                    805 
                                    806 	.area CSEG (CODE)
                                    807 ; function ak820_outline_0169
      009D91                        808 _ak820_outline_0169:
      009D91 90 0B F6         [24]  809 	mov	dptr,#_process_grave_esc_shifted_30000_281
      009D94 E4               [12]  810 	clr	a
      009D95 F0               [24]  811 	movx	@dptr,a
      009D96 22               [24]  812 	ret
