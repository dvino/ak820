                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module dynamic_keymap
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _dynamic_keymap_encoder_to_eeprom_address
                                     12 	.globl _ak820_combo_valid
                                     13 	.globl _ak820_settings_reset
                                     14 	.globl _ak820_eeprom_write_block_xdata
                                     15 	.globl _ak820_eeprom_read_block_xdata
                                     16 	.globl _ak820_nvm_flush
                                     17 	.globl _ak820_nvm_ok
                                     18 	.globl _ak820_macro_reset
                                     19 	.globl _ak820_macro_write
                                     20 	.globl _ak820_macro_length
                                     21 	.globl _ak820_macro_ready
                                     22 	.globl _send_char
                                     23 	.globl _keycode_at_encodermap_location_raw
                                     24 	.globl _keycode_at_keymap_location_raw
                                     25 	.globl _vial_keycode_tap
                                     26 	.globl _vial_keycode_up
                                     27 	.globl _vial_keycode_down
                                     28 	.globl _clear_keyboard
                                     29 	.globl _tap_code
                                     30 	.globl _unregister_code
                                     31 	.globl _register_code
                                     32 	.globl _mDelaymS
                                     33 	.globl ___memcpy
                                     34 	.globl _memset
                                     35 	.globl _eeprom_update_byte
                                     36 	.globl _eeprom_read_byte
                                     37 	.globl _ADC_START
                                     38 	.globl _S0_R_FIFO
                                     39 	.globl _S0_T_FIFO
                                     40 	.globl _S0_FREE
                                     41 	.globl _S0_IF_BYTE
                                     42 	.globl _S0_IF_FIRST
                                     43 	.globl _S0_IF_OV
                                     44 	.globl _S0_FST_ACT
                                     45 	.globl _CP_RL2
                                     46 	.globl _C_T2
                                     47 	.globl _TR2
                                     48 	.globl _EXEN2
                                     49 	.globl _TCLK
                                     50 	.globl _RCLK
                                     51 	.globl _EXF2
                                     52 	.globl _CAP1F
                                     53 	.globl _TF2
                                     54 	.globl _RI
                                     55 	.globl _TI
                                     56 	.globl _RB8
                                     57 	.globl _TB8
                                     58 	.globl _REN
                                     59 	.globl _SM2
                                     60 	.globl _SM1
                                     61 	.globl _SM0
                                     62 	.globl _IT0
                                     63 	.globl _IE0
                                     64 	.globl _IT1
                                     65 	.globl _IE1
                                     66 	.globl _TR0
                                     67 	.globl _TF0
                                     68 	.globl _TR1
                                     69 	.globl _TF1
                                     70 	.globl _P4_0
                                     71 	.globl _P4_1
                                     72 	.globl _P4_2
                                     73 	.globl _P4_3
                                     74 	.globl _P4_4
                                     75 	.globl _P4_5
                                     76 	.globl _P4_6
                                     77 	.globl _RXD
                                     78 	.globl _TXD
                                     79 	.globl _INT0
                                     80 	.globl _INT1
                                     81 	.globl _T0
                                     82 	.globl _T1
                                     83 	.globl _MOSI1
                                     84 	.globl _MISO1
                                     85 	.globl _SCK1
                                     86 	.globl _P3_0
                                     87 	.globl _P3_1
                                     88 	.globl _P3_2
                                     89 	.globl _P3_3
                                     90 	.globl _P3_4
                                     91 	.globl _P3_5
                                     92 	.globl _P3_6
                                     93 	.globl _P3_7
                                     94 	.globl _CAP1_
                                     95 	.globl _T2_
                                     96 	.globl _CAP2_
                                     97 	.globl _T2EX_
                                     98 	.globl _RXD1
                                     99 	.globl _TXD1
                                    100 	.globl _P2_0
                                    101 	.globl _P2_1
                                    102 	.globl _P2_2
                                    103 	.globl _P2_3
                                    104 	.globl _P2_4
                                    105 	.globl _P2_5
                                    106 	.globl _P2_6
                                    107 	.globl _P2_7
                                    108 	.globl _AIN0
                                    109 	.globl _AIN1
                                    110 	.globl _AIN2
                                    111 	.globl _AIN3
                                    112 	.globl _AIN4
                                    113 	.globl _AIN5
                                    114 	.globl _AIN6
                                    115 	.globl _AIN7
                                    116 	.globl _CAP1
                                    117 	.globl _T2
                                    118 	.globl _CAP2
                                    119 	.globl _T2EX
                                    120 	.globl _INT0_
                                    121 	.globl _SCS
                                    122 	.globl _MOSI
                                    123 	.globl _MISO
                                    124 	.globl _SCK
                                    125 	.globl _RXD1_
                                    126 	.globl _TXD1_
                                    127 	.globl _P1_0
                                    128 	.globl _P1_1
                                    129 	.globl _P1_2
                                    130 	.globl _P1_3
                                    131 	.globl _P1_4
                                    132 	.globl _P1_5
                                    133 	.globl _P1_6
                                    134 	.globl _P1_7
                                    135 	.globl _AIN8
                                    136 	.globl _AIN9
                                    137 	.globl _AIN10
                                    138 	.globl _AIN11
                                    139 	.globl _AIN12
                                    140 	.globl _AIN13
                                    141 	.globl _RXD_
                                    142 	.globl _TXD_
                                    143 	.globl _SCL0
                                    144 	.globl _SDA0
                                    145 	.globl _P0_0
                                    146 	.globl _P0_1
                                    147 	.globl _P0_2
                                    148 	.globl _P0_3
                                    149 	.globl _P0_4
                                    150 	.globl _P0_5
                                    151 	.globl _P0_6
                                    152 	.globl _P0_7
                                    153 	.globl _IE_SPI0
                                    154 	.globl _IE_USB
                                    155 	.globl _IE_ADC
                                    156 	.globl _IE_UART1
                                    157 	.globl _IE_PWM_I2C
                                    158 	.globl _IE_GPIO
                                    159 	.globl _IE_WDOG
                                    160 	.globl _PX0
                                    161 	.globl _PT0
                                    162 	.globl _PX1
                                    163 	.globl _PT1
                                    164 	.globl _PS
                                    165 	.globl _PT2
                                    166 	.globl _PL_FLAG
                                    167 	.globl _PH_FLAG
                                    168 	.globl _EX0
                                    169 	.globl _ET0
                                    170 	.globl _EX1
                                    171 	.globl _ET1
                                    172 	.globl _ES
                                    173 	.globl _ET2
                                    174 	.globl _E_DIS
                                    175 	.globl _EA
                                    176 	.globl _P
                                    177 	.globl _F1
                                    178 	.globl _OV
                                    179 	.globl _RS0
                                    180 	.globl _RS1
                                    181 	.globl _F0
                                    182 	.globl _AC
                                    183 	.globl _CY
                                    184 	.globl _I2CS_INT_ST
                                    185 	.globl _I2CX_INT
                                    186 	.globl _LED_STATUS
                                    187 	.globl _LED_DMA_H
                                    188 	.globl _LED_DMA_L
                                    189 	.globl _LED_DMA
                                    190 	.globl _LED_PWM_OE
                                    191 	.globl _LED_COMMON
                                    192 	.globl _ADC_CHAN
                                    193 	.globl _ADC_DAT_H
                                    194 	.globl _ADC_DAT_L
                                    195 	.globl _ADC_DAT
                                    196 	.globl _ADC_CTRL
                                    197 	.globl _SPI1_CK_SE
                                    198 	.globl _SPI1_CTRL
                                    199 	.globl _SPI1_DATA
                                    200 	.globl _SPI1_STAT
                                    201 	.globl _SIF1
                                    202 	.globl _SBAUD1
                                    203 	.globl _SBUF1
                                    204 	.globl _SCON1
                                    205 	.globl _SPI0_SETUP
                                    206 	.globl _SPI0_CK_SE
                                    207 	.globl _SPI0_CTRL
                                    208 	.globl _SPI0_DATA
                                    209 	.globl _SPI0_STAT
                                    210 	.globl _T2CAP1H
                                    211 	.globl _T2CAP1L
                                    212 	.globl _T2CAP1
                                    213 	.globl _TH2
                                    214 	.globl _TL2
                                    215 	.globl _T2COUNT
                                    216 	.globl _RCAP2H
                                    217 	.globl _RCAP2L
                                    218 	.globl _RCAP2
                                    219 	.globl _T2MOD
                                    220 	.globl _T2CON
                                    221 	.globl _SBUF
                                    222 	.globl _SCON
                                    223 	.globl _TH1
                                    224 	.globl _TH0
                                    225 	.globl _TL1
                                    226 	.globl _TL0
                                    227 	.globl _TMOD
                                    228 	.globl _TCON
                                    229 	.globl _XBUS_AUX
                                    230 	.globl _P7
                                    231 	.globl _P6_DIR
                                    232 	.globl _P6_OUT_PU
                                    233 	.globl _P6_IN
                                    234 	.globl _P5_DIR
                                    235 	.globl _P5_OUT_PU
                                    236 	.globl _P5_IN
                                    237 	.globl _P4_LED_KEY
                                    238 	.globl _P4_DIR_PU
                                    239 	.globl _P4_MOD_OC
                                    240 	.globl _P4
                                    241 	.globl _P3_DIR_PU
                                    242 	.globl _P3_MOD_OC
                                    243 	.globl _P3
                                    244 	.globl _P2_DIR_PU
                                    245 	.globl _P2_MOD_OC
                                    246 	.globl _P2
                                    247 	.globl _P1_DIR_PU
                                    248 	.globl _P1_MOD_OC
                                    249 	.globl _P1
                                    250 	.globl _P0_DIR_PU
                                    251 	.globl _P0_MOD_OC
                                    252 	.globl _P0
                                    253 	.globl _ROM_CTRL
                                    254 	.globl _ROM_DATA_HH
                                    255 	.globl _ROM_DATA_HL
                                    256 	.globl _ROM_DATA_HI
                                    257 	.globl _ROM_ADDR_H
                                    258 	.globl _ROM_ADDR_L
                                    259 	.globl _ROM_ADDR
                                    260 	.globl _GPIO_IE
                                    261 	.globl _IP_EX
                                    262 	.globl _IE_EX
                                    263 	.globl _IP
                                    264 	.globl _IE
                                    265 	.globl _WDOG_COUNT
                                    266 	.globl _RESET_KEEP
                                    267 	.globl _WAKE_CTRL
                                    268 	.globl _CLOCK_CFG
                                    269 	.globl _POWER_CFG
                                    270 	.globl _PCON
                                    271 	.globl _GLOBAL_CFG
                                    272 	.globl _SAFE_MOD
                                    273 	.globl _DPH
                                    274 	.globl _DPL
                                    275 	.globl _SP
                                    276 	.globl _A_INV
                                    277 	.globl _B
                                    278 	.globl _ACC
                                    279 	.globl _PSW
                                    280 	.globl _dynamic_keymap_macro_set_buffer_PARM_3
                                    281 	.globl _dynamic_keymap_macro_set_buffer_PARM_2
                                    282 	.globl _dynamic_keymap_macro_get_buffer_PARM_3
                                    283 	.globl _dynamic_keymap_macro_get_buffer_PARM_2
                                    284 	.globl _keycode_at_encodermap_location_PARM_3
                                    285 	.globl _keycode_at_encodermap_location_PARM_2
                                    286 	.globl _keycode_at_keymap_location_PARM_3
                                    287 	.globl _keycode_at_keymap_location_PARM_2
                                    288 	.globl _dynamic_keymap_set_buffer_PARM_3
                                    289 	.globl _dynamic_keymap_set_buffer_PARM_2
                                    290 	.globl _dynamic_keymap_get_buffer_PARM_3
                                    291 	.globl _dynamic_keymap_get_buffer_PARM_2
                                    292 	.globl _dynamic_keymap_set_combo_PARM_2
                                    293 	.globl _dynamic_keymap_get_combo_PARM_2
                                    294 	.globl _dynamic_keymap_set_encoder_PARM_4
                                    295 	.globl _dynamic_keymap_set_encoder_PARM_3
                                    296 	.globl _dynamic_keymap_set_encoder_PARM_2
                                    297 	.globl _dynamic_keymap_get_encoder_PARM_3
                                    298 	.globl _dynamic_keymap_get_encoder_PARM_2
                                    299 	.globl _dynamic_keymap_encoder_to_eeprom_address_PARM_2
                                    300 	.globl _dynamic_keymap_set_keycode_PARM_4
                                    301 	.globl _dynamic_keymap_set_keycode_PARM_3
                                    302 	.globl _dynamic_keymap_set_keycode_PARM_2
                                    303 	.globl _dynamic_keymap_get_keycode_PARM_3
                                    304 	.globl _dynamic_keymap_get_keycode_PARM_2
                                    305 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_3
                                    306 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_2
                                    307 	.globl _dynamic_keymap_get_layer_count
                                    308 	.globl _dynamic_keymap_key_to_eeprom_address
                                    309 	.globl _dynamic_keymap_get_keycode
                                    310 	.globl _dynamic_keymap_set_keycode
                                    311 	.globl _dynamic_keymap_get_encoder
                                    312 	.globl _dynamic_keymap_set_encoder
                                    313 	.globl _dynamic_keymap_get_combo
                                    314 	.globl _dynamic_keymap_set_combo
                                    315 	.globl _dynamic_keymap_reset
                                    316 	.globl _dynamic_keymap_get_buffer
                                    317 	.globl _dynamic_keymap_set_buffer
                                    318 	.globl _keycode_at_keymap_location
                                    319 	.globl _keycode_at_encodermap_location
                                    320 	.globl _dynamic_keymap_macro_get_count
                                    321 	.globl _dynamic_keymap_macro_get_buffer_size
                                    322 	.globl _dynamic_keymap_macro_get_buffer
                                    323 	.globl _dynamic_keymap_macro_set_buffer
                                    324 	.globl _dynamic_keymap_macro_reset
                                    325 	.globl _dynamic_keymap_macro_send
                                    326 ;--------------------------------------------------------
                                    327 ; special function registers
                                    328 ;--------------------------------------------------------
                                    329 	.area RSEG    (ABS,DATA)
      000000                        330 	.org 0x0000
                           0000D0   331 _PSW	=	0x00d0
                           0000E0   332 _ACC	=	0x00e0
                           0000F0   333 _B	=	0x00f0
                           0000FD   334 _A_INV	=	0x00fd
                           000081   335 _SP	=	0x0081
                           000082   336 _DPL	=	0x0082
                           000083   337 _DPH	=	0x0083
                           0000A1   338 _SAFE_MOD	=	0x00a1
                           0000B1   339 _GLOBAL_CFG	=	0x00b1
                           000087   340 _PCON	=	0x0087
                           0000BA   341 _POWER_CFG	=	0x00ba
                           0000B9   342 _CLOCK_CFG	=	0x00b9
                           0000A9   343 _WAKE_CTRL	=	0x00a9
                           0000FE   344 _RESET_KEEP	=	0x00fe
                           0000FF   345 _WDOG_COUNT	=	0x00ff
                           0000A8   346 _IE	=	0x00a8
                           0000B8   347 _IP	=	0x00b8
                           0000E8   348 _IE_EX	=	0x00e8
                           0000E9   349 _IP_EX	=	0x00e9
                           0000B2   350 _GPIO_IE	=	0x00b2
                           008584   351 _ROM_ADDR	=	0x8584
                           000084   352 _ROM_ADDR_L	=	0x0084
                           000085   353 _ROM_ADDR_H	=	0x0085
                           008F8E   354 _ROM_DATA_HI	=	0x8f8e
                           00008E   355 _ROM_DATA_HL	=	0x008e
                           00008F   356 _ROM_DATA_HH	=	0x008f
                           000086   357 _ROM_CTRL	=	0x0086
                           000080   358 _P0	=	0x0080
                           0000C4   359 _P0_MOD_OC	=	0x00c4
                           0000C5   360 _P0_DIR_PU	=	0x00c5
                           000090   361 _P1	=	0x0090
                           000092   362 _P1_MOD_OC	=	0x0092
                           000093   363 _P1_DIR_PU	=	0x0093
                           0000A0   364 _P2	=	0x00a0
                           000094   365 _P2_MOD_OC	=	0x0094
                           000095   366 _P2_DIR_PU	=	0x0095
                           0000B0   367 _P3	=	0x00b0
                           000096   368 _P3_MOD_OC	=	0x0096
                           000097   369 _P3_DIR_PU	=	0x0097
                           0000C0   370 _P4	=	0x00c0
                           0000C2   371 _P4_MOD_OC	=	0x00c2
                           0000C3   372 _P4_DIR_PU	=	0x00c3
                           0000C1   373 _P4_LED_KEY	=	0x00c1
                           0000AA   374 _P5_IN	=	0x00aa
                           0000AB   375 _P5_OUT_PU	=	0x00ab
                           0000AC   376 _P5_DIR	=	0x00ac
                           0000AD   377 _P6_IN	=	0x00ad
                           0000AE   378 _P6_OUT_PU	=	0x00ae
                           0000AF   379 _P6_DIR	=	0x00af
                           0000F1   380 _P7	=	0x00f1
                           0000A2   381 _XBUS_AUX	=	0x00a2
                           000088   382 _TCON	=	0x0088
                           000089   383 _TMOD	=	0x0089
                           00008A   384 _TL0	=	0x008a
                           00008B   385 _TL1	=	0x008b
                           00008C   386 _TH0	=	0x008c
                           00008D   387 _TH1	=	0x008d
                           000098   388 _SCON	=	0x0098
                           000099   389 _SBUF	=	0x0099
                           0000C8   390 _T2CON	=	0x00c8
                           0000C9   391 _T2MOD	=	0x00c9
                           00CBCA   392 _RCAP2	=	0xcbca
                           0000CA   393 _RCAP2L	=	0x00ca
                           0000CB   394 _RCAP2H	=	0x00cb
                           00CDCC   395 _T2COUNT	=	0xcdcc
                           0000CC   396 _TL2	=	0x00cc
                           0000CD   397 _TH2	=	0x00cd
                           00CFCE   398 _T2CAP1	=	0xcfce
                           0000CE   399 _T2CAP1L	=	0x00ce
                           0000CF   400 _T2CAP1H	=	0x00cf
                           0000F8   401 _SPI0_STAT	=	0x00f8
                           0000F9   402 _SPI0_DATA	=	0x00f9
                           0000FA   403 _SPI0_CTRL	=	0x00fa
                           0000FB   404 _SPI0_CK_SE	=	0x00fb
                           0000FC   405 _SPI0_SETUP	=	0x00fc
                           0000BC   406 _SCON1	=	0x00bc
                           0000BD   407 _SBUF1	=	0x00bd
                           0000BE   408 _SBAUD1	=	0x00be
                           0000BF   409 _SIF1	=	0x00bf
                           0000B4   410 _SPI1_STAT	=	0x00b4
                           0000B5   411 _SPI1_DATA	=	0x00b5
                           0000B6   412 _SPI1_CTRL	=	0x00b6
                           0000B7   413 _SPI1_CK_SE	=	0x00b7
                           0000F3   414 _ADC_CTRL	=	0x00f3
                           00F5F4   415 _ADC_DAT	=	0xf5f4
                           0000F4   416 _ADC_DAT_L	=	0x00f4
                           0000F5   417 _ADC_DAT_H	=	0x00f5
                           0000F6   418 _ADC_CHAN	=	0x00f6
                           0000A6   419 _LED_COMMON	=	0x00a6
                           0000A7   420 _LED_PWM_OE	=	0x00a7
                           00C7C6   421 _LED_DMA	=	0xc7c6
                           0000C6   422 _LED_DMA_L	=	0x00c6
                           0000C7   423 _LED_DMA_H	=	0x00c7
                           0000F7   424 _LED_STATUS	=	0x00f7
                           0000B3   425 _I2CX_INT	=	0x00b3
                           0000BB   426 _I2CS_INT_ST	=	0x00bb
                                    427 ;--------------------------------------------------------
                                    428 ; special function bits
                                    429 ;--------------------------------------------------------
                                    430 	.area RSEG    (ABS,DATA)
      000000                        431 	.org 0x0000
                           0000D7   432 _CY	=	0x00d7
                           0000D6   433 _AC	=	0x00d6
                           0000D5   434 _F0	=	0x00d5
                           0000D4   435 _RS1	=	0x00d4
                           0000D3   436 _RS0	=	0x00d3
                           0000D2   437 _OV	=	0x00d2
                           0000D1   438 _F1	=	0x00d1
                           0000D0   439 _P	=	0x00d0
                           0000AF   440 _EA	=	0x00af
                           0000AE   441 _E_DIS	=	0x00ae
                           0000AD   442 _ET2	=	0x00ad
                           0000AC   443 _ES	=	0x00ac
                           0000AB   444 _ET1	=	0x00ab
                           0000AA   445 _EX1	=	0x00aa
                           0000A9   446 _ET0	=	0x00a9
                           0000A8   447 _EX0	=	0x00a8
                           0000BF   448 _PH_FLAG	=	0x00bf
                           0000BE   449 _PL_FLAG	=	0x00be
                           0000BD   450 _PT2	=	0x00bd
                           0000BC   451 _PS	=	0x00bc
                           0000BB   452 _PT1	=	0x00bb
                           0000BA   453 _PX1	=	0x00ba
                           0000B9   454 _PT0	=	0x00b9
                           0000B8   455 _PX0	=	0x00b8
                           0000EF   456 _IE_WDOG	=	0x00ef
                           0000EE   457 _IE_GPIO	=	0x00ee
                           0000ED   458 _IE_PWM_I2C	=	0x00ed
                           0000EC   459 _IE_UART1	=	0x00ec
                           0000EB   460 _IE_ADC	=	0x00eb
                           0000E9   461 _IE_USB	=	0x00e9
                           0000E8   462 _IE_SPI0	=	0x00e8
                           000087   463 _P0_7	=	0x0087
                           000086   464 _P0_6	=	0x0086
                           000085   465 _P0_5	=	0x0085
                           000084   466 _P0_4	=	0x0084
                           000083   467 _P0_3	=	0x0083
                           000082   468 _P0_2	=	0x0082
                           000081   469 _P0_1	=	0x0081
                           000080   470 _P0_0	=	0x0080
                           000081   471 _SDA0	=	0x0081
                           000080   472 _SCL0	=	0x0080
                           000083   473 _TXD_	=	0x0083
                           000082   474 _RXD_	=	0x0082
                           000085   475 _AIN13	=	0x0085
                           000084   476 _AIN12	=	0x0084
                           000083   477 _AIN11	=	0x0083
                           000082   478 _AIN10	=	0x0082
                           000081   479 _AIN9	=	0x0081
                           000080   480 _AIN8	=	0x0080
                           000097   481 _P1_7	=	0x0097
                           000096   482 _P1_6	=	0x0096
                           000095   483 _P1_5	=	0x0095
                           000094   484 _P1_4	=	0x0094
                           000093   485 _P1_3	=	0x0093
                           000092   486 _P1_2	=	0x0092
                           000091   487 _P1_1	=	0x0091
                           000090   488 _P1_0	=	0x0090
                           000097   489 _TXD1_	=	0x0097
                           000096   490 _RXD1_	=	0x0096
                           000097   491 _SCK	=	0x0097
                           000096   492 _MISO	=	0x0096
                           000095   493 _MOSI	=	0x0095
                           000094   494 _SCS	=	0x0094
                           000092   495 _INT0_	=	0x0092
                           000091   496 _T2EX	=	0x0091
                           000091   497 _CAP2	=	0x0091
                           000090   498 _T2	=	0x0090
                           000090   499 _CAP1	=	0x0090
                           000097   500 _AIN7	=	0x0097
                           000096   501 _AIN6	=	0x0096
                           000095   502 _AIN5	=	0x0095
                           000094   503 _AIN4	=	0x0094
                           000093   504 _AIN3	=	0x0093
                           000092   505 _AIN2	=	0x0092
                           000091   506 _AIN1	=	0x0091
                           000090   507 _AIN0	=	0x0090
                           0000A7   508 _P2_7	=	0x00a7
                           0000A6   509 _P2_6	=	0x00a6
                           0000A5   510 _P2_5	=	0x00a5
                           0000A4   511 _P2_4	=	0x00a4
                           0000A3   512 _P2_3	=	0x00a3
                           0000A2   513 _P2_2	=	0x00a2
                           0000A1   514 _P2_1	=	0x00a1
                           0000A0   515 _P2_0	=	0x00a0
                           0000A7   516 _TXD1	=	0x00a7
                           0000A6   517 _RXD1	=	0x00a6
                           0000A5   518 _T2EX_	=	0x00a5
                           0000A5   519 _CAP2_	=	0x00a5
                           0000A4   520 _T2_	=	0x00a4
                           0000A4   521 _CAP1_	=	0x00a4
                           0000B7   522 _P3_7	=	0x00b7
                           0000B6   523 _P3_6	=	0x00b6
                           0000B5   524 _P3_5	=	0x00b5
                           0000B4   525 _P3_4	=	0x00b4
                           0000B3   526 _P3_3	=	0x00b3
                           0000B2   527 _P3_2	=	0x00b2
                           0000B1   528 _P3_1	=	0x00b1
                           0000B0   529 _P3_0	=	0x00b0
                           0000B7   530 _SCK1	=	0x00b7
                           0000B6   531 _MISO1	=	0x00b6
                           0000B5   532 _MOSI1	=	0x00b5
                           0000B5   533 _T1	=	0x00b5
                           0000B4   534 _T0	=	0x00b4
                           0000B3   535 _INT1	=	0x00b3
                           0000B2   536 _INT0	=	0x00b2
                           0000B1   537 _TXD	=	0x00b1
                           0000B0   538 _RXD	=	0x00b0
                           0000C6   539 _P4_6	=	0x00c6
                           0000C5   540 _P4_5	=	0x00c5
                           0000C4   541 _P4_4	=	0x00c4
                           0000C3   542 _P4_3	=	0x00c3
                           0000C2   543 _P4_2	=	0x00c2
                           0000C1   544 _P4_1	=	0x00c1
                           0000C0   545 _P4_0	=	0x00c0
                           00008F   546 _TF1	=	0x008f
                           00008E   547 _TR1	=	0x008e
                           00008D   548 _TF0	=	0x008d
                           00008C   549 _TR0	=	0x008c
                           00008B   550 _IE1	=	0x008b
                           00008A   551 _IT1	=	0x008a
                           000089   552 _IE0	=	0x0089
                           000088   553 _IT0	=	0x0088
                           00009F   554 _SM0	=	0x009f
                           00009E   555 _SM1	=	0x009e
                           00009D   556 _SM2	=	0x009d
                           00009C   557 _REN	=	0x009c
                           00009B   558 _TB8	=	0x009b
                           00009A   559 _RB8	=	0x009a
                           000099   560 _TI	=	0x0099
                           000098   561 _RI	=	0x0098
                           0000CF   562 _TF2	=	0x00cf
                           0000CF   563 _CAP1F	=	0x00cf
                           0000CE   564 _EXF2	=	0x00ce
                           0000CD   565 _RCLK	=	0x00cd
                           0000CC   566 _TCLK	=	0x00cc
                           0000CB   567 _EXEN2	=	0x00cb
                           0000CA   568 _TR2	=	0x00ca
                           0000C9   569 _C_T2	=	0x00c9
                           0000C8   570 _CP_RL2	=	0x00c8
                           0000FF   571 _S0_FST_ACT	=	0x00ff
                           0000FE   572 _S0_IF_OV	=	0x00fe
                           0000FD   573 _S0_IF_FIRST	=	0x00fd
                           0000FC   574 _S0_IF_BYTE	=	0x00fc
                           0000FB   575 _S0_FREE	=	0x00fb
                           0000FA   576 _S0_T_FIFO	=	0x00fa
                           0000F8   577 _S0_R_FIFO	=	0x00f8
                           0000F7   578 _ADC_START	=	0x00f7
                                    579 ;--------------------------------------------------------
                                    580 ; overlayable register banks
                                    581 ;--------------------------------------------------------
                                    582 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        583 	.ds 8
                                    584 ;--------------------------------------------------------
                                    585 ; internal ram data
                                    586 ;--------------------------------------------------------
                                    587 	.area DSEG    (DATA)
      000029                        588 _dynamic_keymap_set_encoder_sloc0_1_0:
      000029                        589 	.ds 2
      00002B                        590 _dynamic_keymap_get_combo_sloc0_1_0:
      00002B                        591 	.ds 1
      00002C                        592 _ak820_dynamic_read_buffer_sloc0_1_0:
      00002C                        593 	.ds 1
      00002D                        594 _dynamic_keymap_set_buffer_sloc0_1_0:
      00002D                        595 	.ds 2
      00002F                        596 _dynamic_keymap_set_buffer_sloc1_1_0:
      00002F                        597 	.ds 2
      000031                        598 _dynamic_keymap_set_buffer_sloc2_1_0:
      000031                        599 	.ds 1
      000032                        600 _dynamic_keymap_macro_get_buffer_sloc0_1_0:
      000032                        601 	.ds 2
                                    602 ;--------------------------------------------------------
                                    603 ; overlayable items in internal ram
                                    604 ;--------------------------------------------------------
                                    605 ;--------------------------------------------------------
                                    606 ; indirectly addressable internal ram data
                                    607 ;--------------------------------------------------------
                                    608 	.area ISEG    (DATA)
                                    609 ;--------------------------------------------------------
                                    610 ; absolute internal ram data
                                    611 ;--------------------------------------------------------
                                    612 	.area IABS    (ABS,DATA)
                                    613 	.area IABS    (ABS,DATA)
                                    614 ;--------------------------------------------------------
                                    615 ; bit data
                                    616 ;--------------------------------------------------------
                                    617 	.area BSEG    (BIT)
      000023                        618 _dynamic_keymap_macro_send_sloc0_1_0:
      000023                        619 	.ds 1
                                    620 ;--------------------------------------------------------
                                    621 ; paged external ram data
                                    622 ;--------------------------------------------------------
                                    623 	.area PSEG    (PAG,XDATA)
                                    624 ;--------------------------------------------------------
                                    625 ; uninitialized external ram data
                                    626 ;--------------------------------------------------------
                                    627 	.area XSEG    (XDATA)
      000B1A                        628 _dynamic_keymap_key_to_eeprom_address_PARM_2:
      000B1A                        629 	.ds 1
      000B1B                        630 _dynamic_keymap_key_to_eeprom_address_PARM_3:
      000B1B                        631 	.ds 1
      000B1C                        632 _dynamic_keymap_key_to_eeprom_address_layer_10000_375:
      000B1C                        633 	.ds 1
      000B1D                        634 _dynamic_keymap_get_keycode_PARM_2:
      000B1D                        635 	.ds 1
      000B1E                        636 _dynamic_keymap_get_keycode_PARM_3:
      000B1E                        637 	.ds 1
      000B1F                        638 _dynamic_keymap_get_keycode_layer_10000_377:
      000B1F                        639 	.ds 1
      000B20                        640 _dynamic_keymap_set_keycode_PARM_2:
      000B20                        641 	.ds 1
      000B21                        642 _dynamic_keymap_set_keycode_PARM_3:
      000B21                        643 	.ds 1
      000B22                        644 _dynamic_keymap_set_keycode_PARM_4:
      000B22                        645 	.ds 2
      000B24                        646 _dynamic_keymap_set_keycode_layer_10000_381:
      000B24                        647 	.ds 1
      000B25                        648 _dynamic_keymap_encoder_to_eeprom_address_PARM_2:
      000B25                        649 	.ds 1
      000B26                        650 _dynamic_keymap_encoder_to_eeprom_address_layer_10000_385:
      000B26                        651 	.ds 1
      000B27                        652 _dynamic_keymap_get_encoder_PARM_2:
      000B27                        653 	.ds 1
      000B28                        654 _dynamic_keymap_get_encoder_PARM_3:
      000B28                        655 	.ds 1
      000B29                        656 _dynamic_keymap_get_encoder_layer_10000_387:
      000B29                        657 	.ds 1
      000B2A                        658 _dynamic_keymap_set_encoder_PARM_2:
      000B2A                        659 	.ds 1
      000B2B                        660 _dynamic_keymap_set_encoder_PARM_3:
      000B2B                        661 	.ds 1
      000B2C                        662 _dynamic_keymap_set_encoder_PARM_4:
      000B2C                        663 	.ds 2
      000B2E                        664 _dynamic_keymap_set_encoder_layer_10000_391:
      000B2E                        665 	.ds 1
      000B2F                        666 _dynamic_keymap_get_combo_PARM_2:
      000B2F                        667 	.ds 3
      000B32                        668 _dynamic_keymap_get_combo_index_10000_395:
      000B32                        669 	.ds 1
      000B33                        670 _dynamic_keymap_set_combo_PARM_2:
      000B33                        671 	.ds 3
      000B36                        672 _dynamic_keymap_set_combo_index_10000_401:
      000B36                        673 	.ds 1
      000B37                        674 _dynamic_keymap_set_combo_stored_10002_406:
      000B37                        675 	.ds 10
      000B41                        676 _dynamic_keymap_reset_vial_unlocked_prev_10000_409:
      000B41                        677 	.ds 1
      000B42                        678 _dynamic_keymap_reset_combo_10001_418:
      000B42                        679 	.ds 10
      000B4C                        680 _ak820_dynamic_read_buffer_PARM_2:
      000B4C                        681 	.ds 2
      000B4E                        682 _ak820_dynamic_read_buffer_PARM_3:
      000B4E                        683 	.ds 2
      000B50                        684 _ak820_dynamic_read_buffer_PARM_4:
      000B50                        685 	.ds 2
      000B52                        686 _ak820_dynamic_read_buffer_PARM_5:
      000B52                        687 	.ds 3
      000B55                        688 _ak820_dynamic_read_buffer_base_10000_420:
      000B55                        689 	.ds 2
      000B57                        690 _ak820_dynamic_read_buffer_available_10000_421:
      000B57                        691 	.ds 1
      000B58                        692 _dynamic_keymap_get_buffer_PARM_2:
      000B58                        693 	.ds 2
      000B5A                        694 _dynamic_keymap_get_buffer_PARM_3:
      000B5A                        695 	.ds 3
      000B5D                        696 _dynamic_keymap_get_buffer_offset_10000_427:
      000B5D                        697 	.ds 2
      000B5F                        698 _dynamic_keymap_set_buffer_PARM_2:
      000B5F                        699 	.ds 2
      000B61                        700 _dynamic_keymap_set_buffer_PARM_3:
      000B61                        701 	.ds 3
      000B64                        702 _dynamic_keymap_set_buffer_offset_10000_429:
      000B64                        703 	.ds 2
      000B66                        704 _dynamic_keymap_set_buffer_chk_offset_30001_436:
      000B66                        705 	.ds 1
      000B67                        706 _dynamic_keymap_set_buffer_chk_sz_30001_436:
      000B67                        707 	.ds 1
      000B68                        708 _dynamic_keymap_set_buffer_i_40001_443:
      000B68                        709 	.ds 1
      000B69                        710 _keycode_at_keymap_location_PARM_2:
      000B69                        711 	.ds 1
      000B6A                        712 _keycode_at_keymap_location_PARM_3:
      000B6A                        713 	.ds 1
      000B6B                        714 _keycode_at_keymap_location_layer_num_10000_447:
      000B6B                        715 	.ds 1
      000B6C                        716 _keycode_at_encodermap_location_PARM_2:
      000B6C                        717 	.ds 1
      000B6D                        718 _keycode_at_encodermap_location_PARM_3:
      000B6D                        719 	.ds 1
      000B6E                        720 _keycode_at_encodermap_location_layer_num_10000_451:
      000B6E                        721 	.ds 1
      000B6F                        722 _dynamic_keymap_macro_get_buffer_PARM_2:
      000B6F                        723 	.ds 2
      000B71                        724 _dynamic_keymap_macro_get_buffer_PARM_3:
      000B71                        725 	.ds 3
      000B74                        726 _dynamic_keymap_macro_get_buffer_offset_10000_459:
      000B74                        727 	.ds 2
      000B76                        728 _dynamic_keymap_macro_set_buffer_PARM_2:
      000B76                        729 	.ds 2
      000B78                        730 _dynamic_keymap_macro_set_buffer_PARM_3:
      000B78                        731 	.ds 3
      000B7B                        732 _dynamic_keymap_macro_set_buffer_offset_10000_461:
      000B7B                        733 	.ds 2
      000B7D                        734 _decode_keycode_kc_10000_465:
      000B7D                        735 	.ds 2
      000B7F                        736 _dynamic_keymap_macro_send_id_10000_468:
      000B7F                        737 	.ds 1
      000B80                        738 _dynamic_keymap_macro_send_sending_10000_469:
      000B80                        739 	.ds 1
      000B81                        740 _dynamic_keymap_macro_send_p_10001_474:
      000B81                        741 	.ds 2
      000B83                        742 _dynamic_keymap_macro_send_data_10003_481:
      000B83                        743 	.ds 4
                                    744 ;--------------------------------------------------------
                                    745 ; absolute external ram data
                                    746 ;--------------------------------------------------------
                                    747 	.area XABS    (ABS,XDATA)
                                    748 ;--------------------------------------------------------
                                    749 ; initialized external ram data
                                    750 ;--------------------------------------------------------
                                    751 	.area XISEG   (XDATA)
                                    752 	.area HOME    (CODE)
                                    753 	.area GSINIT0 (CODE)
                                    754 	.area GSINIT1 (CODE)
                                    755 	.area GSINIT2 (CODE)
                                    756 	.area GSINIT3 (CODE)
                                    757 	.area GSINIT4 (CODE)
                                    758 	.area GSINIT5 (CODE)
                                    759 	.area GSINIT  (CODE)
                                    760 	.area GSFINAL (CODE)
                                    761 	.area CSEG    (CODE)
                                    762 ;--------------------------------------------------------
                                    763 ; global & static initialisations
                                    764 ;--------------------------------------------------------
                                    765 	.area HOME    (CODE)
                                    766 	.area GSINIT  (CODE)
                                    767 	.area GSFINAL (CODE)
                                    768 	.area GSINIT  (CODE)
                                    769 ;--------------------------------------------------------
                                    770 ; Home
                                    771 ;--------------------------------------------------------
                                    772 	.area HOME    (CODE)
                                    773 	.area HOME    (CODE)
                                    774 ;--------------------------------------------------------
                                    775 ; code
                                    776 ;--------------------------------------------------------
                                    777 	.area CSEG    (CODE)
                                    778 ;------------------------------------------------------------
                                    779 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    780 ;------------------------------------------------------------
                                    781 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_241'
                                    782 ;------------------------------------------------------------
                                    783 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    784 ;	-----------------------------------------
                           000007   785 	ar7 = 0x07
                           000006   786 	ar6 = 0x06
                           000005   787 	ar5 = 0x05
                           000004   788 	ar4 = 0x04
                           000003   789 	ar3 = 0x03
                           000002   790 	ar2 = 0x02
                           000001   791 	ar1 = 0x01
                           000000   792 	ar0 = 0x00
                                    793 ;	 function dynamic_keymap_get_layer_count
                                    794 ;	-----------------------------------------
      0086F4                        795 _dynamic_keymap_get_layer_count:
                                    796 ;	quantum/dynamic_keymap.c:200: return DYNAMIC_KEYMAP_LAYER_COUNT;
      0086F4 75 82 06         [24]  797 	mov	dpl, #0x06
                                    798 ;	quantum/dynamic_keymap.c:201: }
      0086F7 22               [24]  799 	ret
                                    800 ;------------------------------------------------------------
                                    801 ;Allocation info for local variables in function 'dynamic_keymap_key_to_eeprom_address'
                                    802 ;------------------------------------------------------------
                                    803 ;row           Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_2'
                                    804 ;column        Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_3'
                                    805 ;layer         Allocated with name '_dynamic_keymap_key_to_eeprom_address_layer_10000_375'
                                    806 ;------------------------------------------------------------
                                    807 ;	quantum/dynamic_keymap.c:203: void *dynamic_keymap_key_to_eeprom_address(uint8_t layer, uint8_t row, uint8_t column) {
                                    808 ;	-----------------------------------------
                                    809 ;	 function dynamic_keymap_key_to_eeprom_address
                                    810 ;	-----------------------------------------
      0086F8                        811 _dynamic_keymap_key_to_eeprom_address:
      0086F8 E5 82            [12]  812 	mov	a,dpl
      0086FA 90 0B 1C         [24]  813 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_layer_10000_375
      0086FD F0               [24]  814 	movx	@dptr,a
                                    815 ;	quantum/dynamic_keymap.c:205: return ((uint8_t *)DYNAMIC_KEYMAP_EEPROM_ADDR) + (layer * MATRIX_ROWS * MATRIX_COLS * 2) + (row * MATRIX_COLS * 2) + (column * 2);
      0086FE E0               [24]  816 	movx	a,@dptr
      0086FF FF               [12]  817 	mov	r7,a
      008700 7E 00            [12]  818 	mov	r6,#0x00
      008702 74 40            [12]  819 	mov	a,#0x40
      008704 12 43 35         [24]  820 	lcall	_ak820_outline_0138
      008707 7D 00            [12]  821 	mov	r5,#0x00
      008709 90 0B 1A         [24]  822 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      00870C E0               [24]  823 	movx	a,@dptr
      00870D 75 F0 10         [24]  824 	mov	b,#0x10
      008710 A4               [48]  825 	mul	ab
      008711 2E               [12]  826 	add	a, r6
      008712 FE               [12]  827 	mov	r6,a
      008713 EF               [12]  828 	mov	a,r7
      008714 35 F0            [12]  829 	addc	a, b
      008716 FF               [12]  830 	mov	r7,a
      008717 90 0B 1B         [24]  831 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      00871A E0               [24]  832 	movx	a,@dptr
      00871B 7C 00            [12]  833 	mov	r4,#0x00
      00871D 25 E0            [12]  834 	add	a,acc
      00871F FB               [12]  835 	mov	r3,a
      008720 EC               [12]  836 	mov	a,r4
      008721 33               [12]  837 	rlc	a
      008722 FC               [12]  838 	mov	r4,a
      008723 EB               [12]  839 	mov	a,r3
      008724 2E               [12]  840 	add	a, r6
      008725 FE               [12]  841 	mov	r6,a
      008726 EC               [12]  842 	mov	a,r4
      008727 3F               [12]  843 	addc	a, r7
      008728 FF               [12]  844 	mov	r7,a
      008729 12 43 2B         [24]  845 	lcall	_ak820_outline_0121
      00872C 8D F0            [24]  846 	mov	b, r5
                                    847 ;	quantum/dynamic_keymap.c:206: }
      00872E 22               [24]  848 	ret
                                    849 ;------------------------------------------------------------
                                    850 ;Allocation info for local variables in function 'dynamic_keymap_get_keycode'
                                    851 ;------------------------------------------------------------
                                    852 ;row           Allocated with name '_dynamic_keymap_get_keycode_PARM_2'
                                    853 ;column        Allocated with name '_dynamic_keymap_get_keycode_PARM_3'
                                    854 ;layer         Allocated with name '_dynamic_keymap_get_keycode_layer_10000_377'
                                    855 ;address       Allocated with name '_dynamic_keymap_get_keycode_address_10001_380'
                                    856 ;keycode       Allocated with name '_dynamic_keymap_get_keycode_keycode_10001_380'
                                    857 ;------------------------------------------------------------
                                    858 ;	quantum/dynamic_keymap.c:208: uint16_t dynamic_keymap_get_keycode(uint8_t layer, uint8_t row, uint8_t column) {
                                    859 ;	-----------------------------------------
                                    860 ;	 function dynamic_keymap_get_keycode
                                    861 ;	-----------------------------------------
      00872F                        862 _dynamic_keymap_get_keycode:
      00872F E5 82            [12]  863 	mov	a,dpl
      008731 90 0B 1F         [24]  864 	mov	dptr,#_dynamic_keymap_get_keycode_layer_10000_377
      008734 F0               [24]  865 	movx	@dptr,a
                                    866 ;	quantum/dynamic_keymap.c:209: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return KC_NO;
      008735 E0               [24]  867 	movx	a,@dptr
      008736 FF               [12]  868 	mov	r7,a
      008737 BF 06 00         [24]  869 	cjne	r7,#0x06,00121$
      00873A                        870 00121$:
      00873A 50 14            [24]  871 	jnc	00101$
      00873C 90 0B 1D         [24]  872 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      00873F E0               [24]  873 	movx	a,@dptr
      008740 FE               [12]  874 	mov	r6,a
      008741 BE 10 00         [24]  875 	cjne	r6,#0x10,00123$
      008744                        876 00123$:
      008744 50 0A            [24]  877 	jnc	00101$
      008746 90 0B 1E         [24]  878 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      008749 E0               [24]  879 	movx	a,@dptr
      00874A FD               [12]  880 	mov	r5,a
      00874B BD 08 00         [24]  881 	cjne	r5,#0x08,00125$
      00874E                        882 00125$:
      00874E 40 04            [24]  883 	jc	00102$
      008750                        884 00101$:
      008750 90 00 00         [24]  885 	mov	dptr,#0x0000
      008753 22               [24]  886 	ret
      008754                        887 00102$:
                                    888 ;	quantum/dynamic_keymap.c:210: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      008754 12 91 A2         [24]  889 	lcall	_ak820_outline_0099
      008757 D1 F8            [12]  890 	acall	_dynamic_keymap_key_to_eeprom_address
                                    891 ;	quantum/dynamic_keymap.c:212: uint16_t keycode = eeprom_read_byte(address) << 8;
      008759 12 91 AF         [24]  892 	lcall	_ak820_outline_0119
      00875C 12 40 36         [24]  893 	lcall	_eeprom_read_byte
      00875F AB 82            [24]  894 	mov	r3,dpl
      008761 7C 00            [12]  895 	mov	r4,#0x00
                                    896 ;	quantum/dynamic_keymap.c:213: keycode |= eeprom_read_byte(address + 1);
      008763 0D               [12]  897 	inc	r5
      008764 BD 00 01         [24]  898 	cjne	r5,#0x00,00127$
      008767 0E               [12]  899 	inc	r6
      008768                        900 00127$:
      008768 12 53 5D         [24]  901 	lcall	_ak820_outline_0045
      00876B 12 40 36         [24]  902 	lcall	_eeprom_read_byte
      00876E AF 82            [24]  903 	mov	r7, dpl
      008770 7E 00            [12]  904 	mov	r6,#0x00
      008772 EF               [12]  905 	mov	a,r7
      008773 42 04            [12]  906 	orl	ar4,a
      008775 EE               [12]  907 	mov	a,r6
      008776 42 03            [12]  908 	orl	ar3,a
                                    909 ;	quantum/dynamic_keymap.c:214: return keycode;
      008778 12 43 57         [24]  910 	lcall	_ak820_outline_0185
                                    911 ;	quantum/dynamic_keymap.c:215: }
      00877B 22               [24]  912 	ret
                                    913 ;------------------------------------------------------------
                                    914 ;Allocation info for local variables in function 'dynamic_keymap_set_keycode'
                                    915 ;------------------------------------------------------------
                                    916 ;row           Allocated with name '_dynamic_keymap_set_keycode_PARM_2'
                                    917 ;column        Allocated with name '_dynamic_keymap_set_keycode_PARM_3'
                                    918 ;keycode       Allocated with name '_dynamic_keymap_set_keycode_PARM_4'
                                    919 ;layer         Allocated with name '_dynamic_keymap_set_keycode_layer_10000_381'
                                    920 ;address       Allocated with name '_dynamic_keymap_set_keycode_address_10001_384'
                                    921 ;------------------------------------------------------------
                                    922 ;	quantum/dynamic_keymap.c:217: void dynamic_keymap_set_keycode(uint8_t layer, uint8_t row, uint8_t column, uint16_t keycode) {
                                    923 ;	-----------------------------------------
                                    924 ;	 function dynamic_keymap_set_keycode
                                    925 ;	-----------------------------------------
      00877C                        926 _dynamic_keymap_set_keycode:
      00877C E5 82            [12]  927 	mov	a,dpl
      00877E 90 0B 24         [24]  928 	mov	dptr,#_dynamic_keymap_set_keycode_layer_10000_381
      008781 F0               [24]  929 	movx	@dptr,a
                                    930 ;	quantum/dynamic_keymap.c:218: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return;
      008782 E0               [24]  931 	movx	a,@dptr
      008783 FF               [12]  932 	mov	r7,a
      008784 BF 06 00         [24]  933 	cjne	r7,#0x06,00121$
      008787                        934 00121$:
      008787 50 14            [24]  935 	jnc	00101$
      008789 90 0B 20         [24]  936 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      00878C E0               [24]  937 	movx	a,@dptr
      00878D FE               [12]  938 	mov	r6,a
      00878E BE 10 00         [24]  939 	cjne	r6,#0x10,00123$
      008791                        940 00123$:
      008791 50 0A            [24]  941 	jnc	00101$
      008793 90 0B 21         [24]  942 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      008796 E0               [24]  943 	movx	a,@dptr
      008797 FD               [12]  944 	mov	r5,a
      008798 BD 08 00         [24]  945 	cjne	r5,#0x08,00125$
      00879B                        946 00125$:
      00879B 40 01            [24]  947 	jc	00102$
      00879D                        948 00101$:
      00879D 22               [24]  949 	ret
      00879E                        950 00102$:
                                    951 ;	quantum/dynamic_keymap.c:219: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      00879E 12 91 A2         [24]  952 	lcall	_ak820_outline_0099
      0087A1 D1 F8            [12]  953 	acall	_dynamic_keymap_key_to_eeprom_address
      0087A3 12 91 AF         [24]  954 	lcall	_ak820_outline_0119
                                    955 ;	quantum/dynamic_keymap.c:221: eeprom_update_byte(address, (uint8_t)(keycode >> 8));
      0087A6 90 0B 22         [24]  956 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      0087A9 E0               [24]  957 	movx	a,@dptr
      0087AA FB               [12]  958 	mov	r3,a
      0087AB A3               [24]  959 	inc	dptr
      0087AC E0               [24]  960 	movx	a,@dptr
      0087AD 90 06 E3         [24]  961 	mov	dptr,#_eeprom_update_byte_PARM_2
      0087B0 F0               [24]  962 	movx	@dptr,a
      0087B1 12 53 5D         [24]  963 	lcall	_ak820_outline_0045
      0087B4 12 52 44         [24]  964 	lcall	_eeprom_update_byte
                                    965 ;	quantum/dynamic_keymap.c:222: eeprom_update_byte(address + 1, (uint8_t)(keycode & 0xFF));
      0087B7 0D               [12]  966 	inc	r5
      0087B8 BD 00 01         [24]  967 	cjne	r5,#0x00,00127$
      0087BB 0E               [12]  968 	inc	r6
      0087BC                        969 00127$:
      0087BC 90 06 E3         [24]  970 	mov	dptr,#_eeprom_update_byte_PARM_2
      0087BF EB               [12]  971 	mov	a,r3
      0087C0 F0               [24]  972 	movx	@dptr,a
      0087C1 12 53 5D         [24]  973 	lcall	_ak820_outline_0045
                                    974 ;	quantum/dynamic_keymap.c:223: }
      0087C4 02 52 44         [24]  975 	ljmp	_eeprom_update_byte
                                    976 ;------------------------------------------------------------
                                    977 ;Allocation info for local variables in function 'dynamic_keymap_encoder_to_eeprom_address'
                                    978 ;------------------------------------------------------------
                                    979 ;encoder_id    Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_PARM_2'
                                    980 ;layer         Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_layer_10000_385'
                                    981 ;------------------------------------------------------------
                                    982 ;	quantum/dynamic_keymap.c:226: void *dynamic_keymap_encoder_to_eeprom_address(uint8_t layer, uint8_t encoder_id) {
                                    983 ;	-----------------------------------------
                                    984 ;	 function dynamic_keymap_encoder_to_eeprom_address
                                    985 ;	-----------------------------------------
      0087C7                        986 _dynamic_keymap_encoder_to_eeprom_address:
      0087C7 E5 82            [12]  987 	mov	a,dpl
      0087C9 90 0B 26         [24]  988 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_layer_10000_385
      0087CC F0               [24]  989 	movx	@dptr,a
                                    990 ;	quantum/dynamic_keymap.c:227: return ((uint8_t *)DYNAMIC_KEYMAP_ENCODER_EEPROM_ADDR) + (layer * NUM_ENCODERS * 2 * 2) + (encoder_id * 2 * 2);
      0087CD E0               [24]  991 	movx	a,@dptr
      0087CE 75 F0 04         [24]  992 	mov	b,#0x04
      0087D1 A4               [48]  993 	mul	ab
      0087D2 24 40            [12]  994 	add	a, #0x40
      0087D4 FD               [12]  995 	mov	r5,a
      0087D5 74 06            [12]  996 	mov	a,#0x06
      0087D7 35 F0            [12]  997 	addc	a, b
      0087D9 FE               [12]  998 	mov	r6,a
      0087DA 7F 00            [12]  999 	mov	r7,#0x00
      0087DC 90 0B 25         [24] 1000 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      0087DF E0               [24] 1001 	movx	a,@dptr
      0087E0 75 F0 04         [24] 1002 	mov	b,#0x04
      0087E3 A4               [48] 1003 	mul	ab
      0087E4 2D               [12] 1004 	add	a, r5
      0087E5 FD               [12] 1005 	mov	r5,a
      0087E6 EE               [12] 1006 	mov	a,r6
      0087E7 35 F0            [12] 1007 	addc	a, b
      0087E9 FE               [12] 1008 	mov	r6,a
      0087EA 12 53 5D         [24] 1009 	lcall	_ak820_outline_0045
                                   1010 ;	quantum/dynamic_keymap.c:228: }
      0087ED 22               [24] 1011 	ret
                                   1012 ;------------------------------------------------------------
                                   1013 ;Allocation info for local variables in function 'dynamic_keymap_get_encoder'
                                   1014 ;------------------------------------------------------------
                                   1015 ;encoder_id    Allocated with name '_dynamic_keymap_get_encoder_PARM_2'
                                   1016 ;clockwise     Allocated with name '_dynamic_keymap_get_encoder_PARM_3'
                                   1017 ;layer         Allocated with name '_dynamic_keymap_get_encoder_layer_10000_387'
                                   1018 ;address       Allocated with name '_dynamic_keymap_get_encoder_address_10001_390'
                                   1019 ;keycode       Allocated with name '_dynamic_keymap_get_encoder_keycode_10001_390'
                                   1020 ;------------------------------------------------------------
                                   1021 ;	quantum/dynamic_keymap.c:230: uint16_t dynamic_keymap_get_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise) {
                                   1022 ;	-----------------------------------------
                                   1023 ;	 function dynamic_keymap_get_encoder
                                   1024 ;	-----------------------------------------
      0087EE                       1025 _dynamic_keymap_get_encoder:
      0087EE E5 82            [12] 1026 	mov	a,dpl
      0087F0 90 0B 29         [24] 1027 	mov	dptr,#_dynamic_keymap_get_encoder_layer_10000_387
      0087F3 F0               [24] 1028 	movx	@dptr,a
                                   1029 ;	quantum/dynamic_keymap.c:231: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return KC_NO;
      0087F4 E0               [24] 1030 	movx	a,@dptr
      0087F5 FF               [12] 1031 	mov	r7,a
      0087F6 BF 06 00         [24] 1032 	cjne	r7,#0x06,00131$
      0087F9                       1033 00131$:
      0087F9 50 0A            [24] 1034 	jnc	00101$
      0087FB 90 0B 27         [24] 1035 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      0087FE E0               [24] 1036 	movx	a,@dptr
      0087FF FE               [12] 1037 	mov	r6,a
      008800 BE 01 00         [24] 1038 	cjne	r6,#0x01,00133$
      008803                       1039 00133$:
      008803 40 04            [24] 1040 	jc	00102$
      008805                       1041 00101$:
      008805 90 00 00         [24] 1042 	mov	dptr,#0x0000
      008808 22               [24] 1043 	ret
      008809                       1044 00102$:
                                   1045 ;	quantum/dynamic_keymap.c:232: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      008809 90 0B 25         [24] 1046 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      00880C E4               [12] 1047 	clr	a
      00880D F0               [24] 1048 	movx	@dptr,a
      00880E 8F 82            [24] 1049 	mov	dpl, r7
      008810 12 87 C7         [24] 1050 	lcall	_dynamic_keymap_encoder_to_eeprom_address
      008813 12 91 AF         [24] 1051 	lcall	_ak820_outline_0119
                                   1052 ;	quantum/dynamic_keymap.c:234: uint16_t keycode = ((uint16_t)eeprom_read_byte(address + (clockwise ? 0 : 2))) << 8;
      008816 90 0B 28         [24] 1053 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      008819 E0               [24] 1054 	movx	a,@dptr
      00881A FC               [12] 1055 	mov	r4,a
      00881B E0               [24] 1056 	movx	a,@dptr
      00881C 60 04            [24] 1057 	jz	00106$
      00881E 7B 00            [12] 1058 	mov	r3,#0x00
      008820 80 02            [24] 1059 	sjmp	00107$
      008822                       1060 00106$:
      008822 7B 02            [12] 1061 	mov	r3,#0x02
      008824                       1062 00107$:
      008824 EB               [12] 1063 	mov	a,r3
      008825 12 91 80         [24] 1064 	lcall	_ak820_outline_0026
      008828 12 40 36         [24] 1065 	lcall	_eeprom_read_byte
      00882B AA 82            [24] 1066 	mov	r2,dpl
      00882D 7B 00            [12] 1067 	mov	r3,#0x00
                                   1068 ;	quantum/dynamic_keymap.c:235: keycode |= eeprom_read_byte(address + (clockwise ? 0 : 2) + 1);
      00882F EC               [12] 1069 	mov	a,r4
      008830 60 04            [24] 1070 	jz	00108$
      008832 7C 00            [12] 1071 	mov	r4,#0x00
      008834 80 02            [24] 1072 	sjmp	00109$
      008836                       1073 00108$:
      008836 7C 02            [12] 1074 	mov	r4,#0x02
      008838                       1075 00109$:
      008838 EC               [12] 1076 	mov	a,r4
      008839 12 38 80         [24] 1077 	lcall	_ak820_outline_0163
      00883C 0D               [12] 1078 	inc	r5
      00883D BD 00 01         [24] 1079 	cjne	r5,#0x00,00137$
      008840 0E               [12] 1080 	inc	r6
      008841                       1081 00137$:
      008841 12 53 5D         [24] 1082 	lcall	_ak820_outline_0045
      008844 12 40 36         [24] 1083 	lcall	_eeprom_read_byte
      008847 AF 82            [24] 1084 	mov	r7, dpl
      008849 7E 00            [12] 1085 	mov	r6,#0x00
      00884B EF               [12] 1086 	mov	a,r7
      00884C 42 03            [12] 1087 	orl	ar3,a
      00884E EE               [12] 1088 	mov	a,r6
      00884F 42 02            [12] 1089 	orl	ar2,a
                                   1090 ;	quantum/dynamic_keymap.c:236: return keycode;
      008851 8B 82            [24] 1091 	mov	dpl, r3
      008853 8A 83            [24] 1092 	mov	dph, r2
                                   1093 ;	quantum/dynamic_keymap.c:237: }
      008855 22               [24] 1094 	ret
                                   1095 ;------------------------------------------------------------
                                   1096 ;Allocation info for local variables in function 'dynamic_keymap_set_encoder'
                                   1097 ;------------------------------------------------------------
                                   1098 ;sloc0         Allocated with name '_dynamic_keymap_set_encoder_sloc0_1_0'
                                   1099 ;encoder_id    Allocated with name '_dynamic_keymap_set_encoder_PARM_2'
                                   1100 ;clockwise     Allocated with name '_dynamic_keymap_set_encoder_PARM_3'
                                   1101 ;keycode       Allocated with name '_dynamic_keymap_set_encoder_PARM_4'
                                   1102 ;layer         Allocated with name '_dynamic_keymap_set_encoder_layer_10000_391'
                                   1103 ;address       Allocated with name '_dynamic_keymap_set_encoder_address_10001_394'
                                   1104 ;------------------------------------------------------------
                                   1105 ;	quantum/dynamic_keymap.c:239: void dynamic_keymap_set_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise, uint16_t keycode) {
                                   1106 ;	-----------------------------------------
                                   1107 ;	 function dynamic_keymap_set_encoder
                                   1108 ;	-----------------------------------------
      008856                       1109 _dynamic_keymap_set_encoder:
      008856 E5 82            [12] 1110 	mov	a,dpl
      008858 90 0B 2E         [24] 1111 	mov	dptr,#_dynamic_keymap_set_encoder_layer_10000_391
      00885B F0               [24] 1112 	movx	@dptr,a
                                   1113 ;	quantum/dynamic_keymap.c:240: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return;
      00885C E0               [24] 1114 	movx	a,@dptr
      00885D FF               [12] 1115 	mov	r7,a
      00885E BF 06 00         [24] 1116 	cjne	r7,#0x06,00131$
      008861                       1117 00131$:
      008861 50 0A            [24] 1118 	jnc	00101$
      008863 90 0B 2A         [24] 1119 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      008866 E0               [24] 1120 	movx	a,@dptr
      008867 FE               [12] 1121 	mov	r6,a
      008868 BE 01 00         [24] 1122 	cjne	r6,#0x01,00133$
      00886B                       1123 00133$:
      00886B 40 01            [24] 1124 	jc	00102$
      00886D                       1125 00101$:
      00886D 22               [24] 1126 	ret
      00886E                       1127 00102$:
                                   1128 ;	quantum/dynamic_keymap.c:241: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      00886E 90 0B 25         [24] 1129 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      008871 E4               [12] 1130 	clr	a
      008872 F0               [24] 1131 	movx	@dptr,a
      008873 8F 82            [24] 1132 	mov	dpl, r7
      008875 12 87 C7         [24] 1133 	lcall	_dynamic_keymap_encoder_to_eeprom_address
      008878 12 91 AF         [24] 1134 	lcall	_ak820_outline_0119
                                   1135 ;	quantum/dynamic_keymap.c:243: eeprom_update_byte(address + (clockwise ? 0 : 2), (uint8_t)(keycode >> 8));
      00887B 90 0B 2B         [24] 1136 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      00887E E0               [24] 1137 	movx	a,@dptr
      00887F FC               [12] 1138 	mov	r4,a
      008880 E0               [24] 1139 	movx	a,@dptr
      008881 60 04            [24] 1140 	jz	00106$
      008883 7B 00            [12] 1141 	mov	r3,#0x00
      008885 80 02            [24] 1142 	sjmp	00107$
      008887                       1143 00106$:
      008887 7B 02            [12] 1144 	mov	r3,#0x02
      008889                       1145 00107$:
      008889 EB               [12] 1146 	mov	a,r3
      00888A 12 91 C1         [24] 1147 	lcall	_ak820_outline_0137
      00888D 8F 03            [24] 1148 	mov	ar3,r7
      00888F 90 0B 2C         [24] 1149 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008892 E0               [24] 1150 	movx	a,@dptr
      008893 F5 29            [12] 1151 	mov	_dynamic_keymap_set_encoder_sloc0_1_0,a
      008895 A3               [24] 1152 	inc	dptr
      008896 E0               [24] 1153 	movx	a,@dptr
      008897 F5 2A            [12] 1154 	mov	(_dynamic_keymap_set_encoder_sloc0_1_0 + 1),a
      008899 90 06 E3         [24] 1155 	mov	dptr,#_eeprom_update_byte_PARM_2
      00889C 12 91 C7         [24] 1156 	lcall	_ak820_outline_0144
      00889F 8B F0            [24] 1157 	mov	b, r3
      0088A1 12 52 44         [24] 1158 	lcall	_eeprom_update_byte
                                   1159 ;	quantum/dynamic_keymap.c:244: eeprom_update_byte(address + (clockwise ? 0 : 2) + 1, (uint8_t)(keycode & 0xFF));
      0088A4 EC               [12] 1160 	mov	a,r4
      0088A5 60 04            [24] 1161 	jz	00108$
      0088A7 7C 00            [12] 1162 	mov	r4,#0x00
      0088A9 80 02            [24] 1163 	sjmp	00109$
      0088AB                       1164 00108$:
      0088AB 7C 02            [12] 1165 	mov	r4,#0x02
      0088AD                       1166 00109$:
      0088AD EC               [12] 1167 	mov	a,r4
      0088AE 12 38 80         [24] 1168 	lcall	_ak820_outline_0163
      0088B1 0D               [12] 1169 	inc	r5
      0088B2 BD 00 01         [24] 1170 	cjne	r5,#0x00,00137$
      0088B5 0E               [12] 1171 	inc	r6
      0088B6                       1172 00137$:
      0088B6 90 06 E3         [24] 1173 	mov	dptr,#_eeprom_update_byte_PARM_2
      0088B9 E5 29            [12] 1174 	mov	a,_dynamic_keymap_set_encoder_sloc0_1_0
      0088BB F0               [24] 1175 	movx	@dptr,a
      0088BC 12 53 5D         [24] 1176 	lcall	_ak820_outline_0045
                                   1177 ;	quantum/dynamic_keymap.c:245: }
      0088BF 02 52 44         [24] 1178 	ljmp	_eeprom_update_byte
                                   1179 ;------------------------------------------------------------
                                   1180 ;Allocation info for local variables in function 'dynamic_keymap_get_combo'
                                   1181 ;------------------------------------------------------------
                                   1182 ;sloc0         Allocated with name '_dynamic_keymap_get_combo_sloc0_1_0'
                                   1183 ;buffer        Allocated with name '_dynamic_keymap_get_combo_PARM_2'
                                   1184 ;index         Allocated with name '_dynamic_keymap_get_combo_index_10000_395'
                                   1185 ;entry         Allocated with name '_dynamic_keymap_get_combo_entry_10000_396'
                                   1186 ;address       Allocated with name '_dynamic_keymap_get_combo_address_10001_398'
                                   1187 ;marked        Allocated with name '_dynamic_keymap_get_combo_marked_10002_399'
                                   1188 ;------------------------------------------------------------
                                   1189 ;	quantum/dynamic_keymap.c:307: int dynamic_keymap_get_combo(uint8_t index, vial_combo_entry_t *buffer) {
                                   1190 ;	-----------------------------------------
                                   1191 ;	 function dynamic_keymap_get_combo
                                   1192 ;	-----------------------------------------
      0088C2                       1193 _dynamic_keymap_get_combo:
      0088C2 E5 82            [12] 1194 	mov	a,dpl
      0088C4 90 0B 32         [24] 1195 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_395
      0088C7 F0               [24] 1196 	movx	@dptr,a
                                   1197 ;	quantum/dynamic_keymap.c:310: vial_combo_entry_t AK820_STATE_MEM *entry = (vial_combo_entry_t AK820_STATE_MEM *)buffer;
      0088C8 90 0B 2F         [24] 1198 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      0088CB 12 37 FC         [24] 1199 	lcall	_ak820_outline_0051
                                   1200 ;	quantum/dynamic_keymap.c:314: if (index >= VIAL_COMBO_ENTRIES)
      0088CE 90 0B 32         [24] 1201 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_395
      0088D1 E0               [24] 1202 	movx	a,@dptr
      0088D2 FD               [12] 1203 	mov	r5,a
      0088D3 BD 08 00         [24] 1204 	cjne	r5,#0x08,00132$
      0088D6                       1205 00132$:
      0088D6 40 04            [24] 1206 	jc	00102$
                                   1207 ;	quantum/dynamic_keymap.c:315: return -1;
      0088D8 90 FF FF         [24] 1208 	mov	dptr,#0xffff
      0088DB 22               [24] 1209 	ret
      0088DC                       1210 00102$:
                                   1211 ;	quantum/dynamic_keymap.c:317: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      0088DC 12 91 8E         [24] 1212 	lcall	_ak820_outline_0080
                                   1213 ;	quantum/dynamic_keymap.c:319: ak820_eeprom_read_block_xdata(entry, address, sizeof(vial_combo_entry_t));
      0088DF 8E 02            [24] 1214 	mov	ar2,r6
      0088E1 8F 03            [24] 1215 	mov	ar3,r7
      0088E3 90 05 81         [24] 1216 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      0088E6 12 38 21         [24] 1217 	lcall	_ak820_outline_0072
      0088E9 E4               [12] 1218 	clr	a
      0088EA A3               [24] 1219 	inc	dptr
      0088EB F0               [24] 1220 	movx	@dptr,a
      0088EC 90 05 84         [24] 1221 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      0088EF 74 0A            [12] 1222 	mov	a,#0x0a
      0088F1 12 38 61         [24] 1223 	lcall	_ak820_outline_0127
      0088F4 12 43 47         [24] 1224 	lcall	_ak820_outline_0148
      0088F7 C0 07            [24] 1225 	push	ar7
      0088F9 C0 06            [24] 1226 	push	ar6
      0088FB 12 40 71         [24] 1227 	lcall	_ak820_eeprom_read_block_xdata
      0088FE D0 06            [24] 1228 	pop	ar6
      008900 D0 07            [24] 1229 	pop	ar7
                                   1230 ;	quantum/dynamic_keymap.c:324: bool marked = entry->input[2] == AK820_COMBO_MARKER && entry->input[3] == AK820_COMBO_VERSION;
      008902 74 04            [12] 1231 	mov	a,#0x04
      008904 12 4C B6         [24] 1232 	lcall	_ak820_outline_0013
      008907 FA               [12] 1233 	mov	r2,a
      008908 A3               [24] 1234 	inc	dptr
      008909 E0               [24] 1235 	movx	a,@dptr
      00890A FB               [12] 1236 	mov	r3,a
      00890B BA 20 13         [24] 1237 	cjne	r2,#0x20,00108$
      00890E BB 08 10         [24] 1238 	cjne	r3,#0x08,00108$
      008911 74 06            [12] 1239 	mov	a,#0x06
      008913 12 37 EC         [24] 1240 	lcall	_ak820_outline_0017
      008916 12 43 06         [24] 1241 	lcall	_ak820_outline_0086
      008919 BA 01 05         [24] 1242 	cjne	r2,#0x01,00136$
      00891C BB 00 02         [24] 1243 	cjne	r3,#0x00,00136$
      00891F 80 05            [24] 1244 	sjmp	00109$
      008921                       1245 00136$:
      008921                       1246 00108$:
      008921 75 2B 00         [24] 1247 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x00
      008924 80 03            [24] 1248 	sjmp	00110$
      008926                       1249 00109$:
      008926 75 2B 01         [24] 1250 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x01
      008929                       1251 00110$:
                                   1252 ;	quantum/dynamic_keymap.c:325: entry->input[2] = entry->input[3] = 0;
      008929 74 06            [12] 1253 	mov	a,#0x06
      00892B 12 37 EC         [24] 1254 	lcall	_ak820_outline_0017
      00892E 12 53 9C         [24] 1255 	lcall	_ak820_outline_0173
      008931 12 38 5C         [24] 1256 	lcall	_ak820_outline_0125
      008934 F0               [24] 1257 	movx	@dptr,a
      008935 A3               [24] 1258 	inc	dptr
      008936 F0               [24] 1259 	movx	@dptr,a
                                   1260 ;	quantum/dynamic_keymap.c:326: if (!marked || !ak820_combo_valid(entry)) memset(entry, 0, sizeof(*entry));
      008937 E5 2B            [12] 1261 	mov	a,_dynamic_keymap_get_combo_sloc0_1_0
      008939 60 12            [24] 1262 	jz	00103$
      00893B 12 43 2B         [24] 1263 	lcall	_ak820_outline_0121
      00893E C0 07            [24] 1264 	push	ar7
      008940 C0 06            [24] 1265 	push	ar6
      008942 12 34 68         [24] 1266 	lcall	_ak820_combo_valid
      008945 E5 82            [12] 1267 	mov	a, dpl
      008947 D0 06            [24] 1268 	pop	ar6
      008949 D0 07            [24] 1269 	pop	ar7
      00894B 70 17            [24] 1270 	jnz	00104$
      00894D                       1271 00103$:
      00894D 7D 00            [12] 1272 	mov	r5,#0x00
      00894F 90 0D C5         [24] 1273 	mov	dptr,#_memset_PARM_2
      008952 E4               [12] 1274 	clr	a
      008953 F0               [24] 1275 	movx	@dptr,a
      008954 90 0D C6         [24] 1276 	mov	dptr,#_memset_PARM_3
      008957 74 0A            [12] 1277 	mov	a,#0x0a
      008959 F0               [24] 1278 	movx	@dptr,a
      00895A E4               [12] 1279 	clr	a
      00895B A3               [24] 1280 	inc	dptr
      00895C 12 42 F9         [24] 1281 	lcall	_ak820_outline_0061
      00895F 8D F0            [24] 1282 	mov	b, r5
      008961 12 BB 96         [24] 1283 	lcall	_memset
      008964                       1284 00104$:
                                   1285 ;	quantum/dynamic_keymap.c:329: return 0;
      008964 90 00 00         [24] 1286 	mov	dptr,#0x0000
                                   1287 ;	quantum/dynamic_keymap.c:330: }
      008967 22               [24] 1288 	ret
                                   1289 ;------------------------------------------------------------
                                   1290 ;Allocation info for local variables in function 'dynamic_keymap_set_combo'
                                   1291 ;------------------------------------------------------------
                                   1292 ;buffer        Allocated with name '_dynamic_keymap_set_combo_PARM_2'
                                   1293 ;index         Allocated with name '_dynamic_keymap_set_combo_index_10000_401'
                                   1294 ;entry         Allocated with name '_dynamic_keymap_set_combo_entry_10000_402'
                                   1295 ;address       Allocated with name '_dynamic_keymap_set_combo_address_10001_405'
                                   1296 ;stored        Allocated with name '_dynamic_keymap_set_combo_stored_10002_406'
                                   1297 ;------------------------------------------------------------
                                   1298 ;	quantum/dynamic_keymap.c:332: int dynamic_keymap_set_combo(uint8_t index, const vial_combo_entry_t *buffer) {
                                   1299 ;	-----------------------------------------
                                   1300 ;	 function dynamic_keymap_set_combo
                                   1301 ;	-----------------------------------------
      008968                       1302 _dynamic_keymap_set_combo:
      008968 E5 82            [12] 1303 	mov	a,dpl
      00896A 90 0B 36         [24] 1304 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_401
      00896D F0               [24] 1305 	movx	@dptr,a
                                   1306 ;	quantum/dynamic_keymap.c:334: const vial_combo_entry_t AK820_STATE_MEM *entry = (const vial_combo_entry_t AK820_STATE_MEM *)buffer;
      00896E 90 0B 33         [24] 1307 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      008971 12 37 A5         [24] 1308 	lcall	_ak820_outline_0004
                                   1309 ;	quantum/dynamic_keymap.c:339: if (!ak820_combo_valid(entry) || !ak820_nvm_ok()) return -1;
      008974 C0 07            [24] 1310 	push	ar7
      008976 C0 06            [24] 1311 	push	ar6
      008978 12 34 68         [24] 1312 	lcall	_ak820_combo_valid
      00897B E5 82            [12] 1313 	mov	a, dpl
      00897D D0 06            [24] 1314 	pop	ar6
      00897F D0 07            [24] 1315 	pop	ar7
      008981 60 07            [24] 1316 	jz	00101$
      008983 12 3D DD         [24] 1317 	lcall	_ak820_nvm_ok
      008986 E5 82            [12] 1318 	mov	a, dpl
      008988 70 04            [24] 1319 	jnz	00102$
      00898A                       1320 00101$:
      00898A 90 FF FF         [24] 1321 	mov	dptr,#0xffff
      00898D 22               [24] 1322 	ret
      00898E                       1323 00102$:
                                   1324 ;	quantum/dynamic_keymap.c:341: if (index >= VIAL_COMBO_ENTRIES)
      00898E 90 0B 36         [24] 1325 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_401
      008991 E0               [24] 1326 	movx	a,@dptr
      008992 FD               [12] 1327 	mov	r5,a
      008993 BD 08 00         [24] 1328 	cjne	r5,#0x08,00133$
      008996                       1329 00133$:
      008996 40 04            [24] 1330 	jc	00105$
                                   1331 ;	quantum/dynamic_keymap.c:342: return -1;
      008998 90 FF FF         [24] 1332 	mov	dptr,#0xffff
      00899B 22               [24] 1333 	ret
      00899C                       1334 00105$:
                                   1335 ;	quantum/dynamic_keymap.c:344: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      00899C 12 91 8E         [24] 1336 	lcall	_ak820_outline_0080
                                   1337 ;	quantum/dynamic_keymap.c:346: clear_keyboard();
      00899F C0 07            [24] 1338 	push	ar7
      0089A1 C0 06            [24] 1339 	push	ar6
      0089A3 C0 05            [24] 1340 	push	ar5
      0089A5 C0 04            [24] 1341 	push	ar4
      0089A7 12 7A 45         [24] 1342 	lcall	_clear_keyboard
      0089AA D0 04            [24] 1343 	pop	ar4
      0089AC D0 05            [24] 1344 	pop	ar5
      0089AE D0 06            [24] 1345 	pop	ar6
      0089B0 D0 07            [24] 1346 	pop	ar7
                                   1347 ;	quantum/dynamic_keymap.c:347: vial_combo_entry_t stored = *entry;
      0089B2 90 0D BD         [24] 1348 	mov	dptr,#___memcpy_PARM_2
      0089B5 12 4C FA         [24] 1349 	lcall	_ak820_outline_0060
      0089B8 E4               [12] 1350 	clr	a
      0089B9 A3               [24] 1351 	inc	dptr
      0089BA F0               [24] 1352 	movx	@dptr,a
      0089BB 90 0D C0         [24] 1353 	mov	dptr,#___memcpy_PARM_3
      0089BE 74 0A            [12] 1354 	mov	a,#0x0a
      0089C0 12 38 61         [24] 1355 	lcall	_ak820_outline_0127
      0089C3 90 0B 37         [24] 1356 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_406
      0089C6 F5 F0            [12] 1357 	mov	b,a
      0089C8 C0 05            [24] 1358 	push	ar5
      0089CA C0 04            [24] 1359 	push	ar4
      0089CC 12 BB 20         [24] 1360 	lcall	___memcpy
      0089CF D0 04            [24] 1361 	pop	ar4
      0089D1 D0 05            [24] 1362 	pop	ar5
                                   1363 ;	quantum/dynamic_keymap.c:348: stored.input[2] = AK820_COMBO_MARKER;
      0089D3 90 0B 3B         [24] 1364 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_406 + 0x0004)
      0089D6 74 20            [12] 1365 	mov	a,#0x20
      0089D8 F0               [24] 1366 	movx	@dptr,a
      0089D9 74 08            [12] 1367 	mov	a,#0x08
      0089DB A3               [24] 1368 	inc	dptr
      0089DC F0               [24] 1369 	movx	@dptr,a
                                   1370 ;	quantum/dynamic_keymap.c:349: stored.input[3] = AK820_COMBO_VERSION;
      0089DD 90 0B 3D         [24] 1371 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_406 + 0x0006)
      0089E0 74 01            [12] 1372 	mov	a,#0x01
      0089E2 12 38 61         [24] 1373 	lcall	_ak820_outline_0127
                                   1374 ;	quantum/dynamic_keymap.c:350: ak820_eeprom_write_block_xdata(&stored, address, sizeof(stored));
      0089E5 90 05 8A         [24] 1375 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      0089E8 12 38 21         [24] 1376 	lcall	_ak820_outline_0072
      0089EB E4               [12] 1377 	clr	a
      0089EC A3               [24] 1378 	inc	dptr
      0089ED F0               [24] 1379 	movx	@dptr,a
      0089EE 90 05 8D         [24] 1380 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0089F1 74 0A            [12] 1381 	mov	a,#0x0a
      0089F3 12 38 61         [24] 1382 	lcall	_ak820_outline_0127
      0089F6 90 0B 37         [24] 1383 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_406
      0089F9 12 40 FD         [24] 1384 	lcall	_ak820_eeprom_write_block_xdata
                                   1385 ;	quantum/dynamic_keymap.c:355: ak820_nvm_flush();
      0089FC 12 3D EC         [24] 1386 	lcall	_ak820_nvm_flush
                                   1387 ;	quantum/dynamic_keymap.c:356: if (!ak820_nvm_ok()) return -1;
      0089FF 12 3D DD         [24] 1388 	lcall	_ak820_nvm_ok
      008A02 E5 82            [12] 1389 	mov	a, dpl
      008A04 70 04            [24] 1390 	jnz	00107$
      008A06 90 FF FF         [24] 1391 	mov	dptr,#0xffff
      008A09 22               [24] 1392 	ret
      008A0A                       1393 00107$:
                                   1394 ;	quantum/dynamic_keymap.c:360: return 0;
      008A0A 90 00 00         [24] 1395 	mov	dptr,#0x0000
                                   1396 ;	quantum/dynamic_keymap.c:361: }
      008A0D 22               [24] 1397 	ret
                                   1398 ;------------------------------------------------------------
                                   1399 ;Allocation info for local variables in function 'dynamic_keymap_reset'
                                   1400 ;------------------------------------------------------------
                                   1401 ;vial_unlocked_prev Allocated with name '_dynamic_keymap_reset_vial_unlocked_prev_10000_409'
                                   1402 ;layer         Allocated with name '_dynamic_keymap_reset_layer_20000_410'
                                   1403 ;row           Allocated with name '_dynamic_keymap_reset_row_40000_412'
                                   1404 ;column        Allocated with name '_dynamic_keymap_reset_column_60000_414'
                                   1405 ;encoder       Allocated with name '_dynamic_keymap_reset_encoder_40000_416'
                                   1406 ;combo         Allocated with name '_dynamic_keymap_reset_combo_10001_418'
                                   1407 ;i             Allocated with name '_dynamic_keymap_reset_i_20001_419'
                                   1408 ;------------------------------------------------------------
                                   1409 ;	quantum/dynamic_keymap.c:404: void dynamic_keymap_reset(void) {
                                   1410 ;	-----------------------------------------
                                   1411 ;	 function dynamic_keymap_reset
                                   1412 ;	-----------------------------------------
      008A0E                       1413 _dynamic_keymap_reset:
                                   1414 ;	quantum/dynamic_keymap.c:415: bool vial_unlocked_prev = vial_unlocked;
      008A0E 90 0E 45         [24] 1415 	mov	dptr,#_vial_unlocked
      008A11 E0               [24] 1416 	movx	a,@dptr
      008A12 90 0B 41         [24] 1417 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_409
      008A15 F0               [24] 1418 	movx	@dptr,a
                                   1419 ;	quantum/dynamic_keymap.c:416: vial_unlocked = 1;
      008A16 90 0E 45         [24] 1420 	mov	dptr,#_vial_unlocked
      008A19 74 01            [12] 1421 	mov	a,#0x01
      008A1B F0               [24] 1422 	movx	@dptr,a
                                   1423 ;	quantum/dynamic_keymap.c:420: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      008A1C 7F 00            [12] 1424 	mov	r7,#0x00
      008A1E                       1425 00116$:
      008A1E BF 06 00         [24] 1426 	cjne	r7,#0x06,00198$
      008A21                       1427 00198$:
      008A21 40 02            [24] 1428 	jc	00199$
      008A23 41 CD            [12] 1429 	ajmp	00104$
      008A25                       1430 00199$:
                                   1431 ;	quantum/dynamic_keymap.c:421: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      008A25 7E 00            [12] 1432 	mov	r6,#0x00
      008A27                       1433 00110$:
      008A27 BE 10 00         [24] 1434 	cjne	r6,#0x10,00200$
      008A2A                       1435 00200$:
      008A2A 50 4D            [24] 1436 	jnc	00102$
                                   1437 ;	quantum/dynamic_keymap.c:422: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      008A2C 7D 00            [12] 1438 	mov	r5,#0x00
      008A2E                       1439 00107$:
      008A2E BD 08 00         [24] 1440 	cjne	r5,#0x08,00202$
      008A31                       1441 00202$:
      008A31 50 43            [24] 1442 	jnc	00111$
                                   1443 ;	quantum/dynamic_keymap.c:423: dynamic_keymap_set_keycode(layer, row, column, keycode_at_keymap_location_raw(layer, row, column));
      008A33 90 0B DD         [24] 1444 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_2
      008A36 EE               [12] 1445 	mov	a,r6
      008A37 F0               [24] 1446 	movx	@dptr,a
      008A38 90 0B DE         [24] 1447 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_3
      008A3B ED               [12] 1448 	mov	a,r5
      008A3C F0               [24] 1449 	movx	@dptr,a
      008A3D 8F 82            [24] 1450 	mov	dpl, r7
      008A3F C0 07            [24] 1451 	push	ar7
      008A41 C0 06            [24] 1452 	push	ar6
      008A43 C0 05            [24] 1453 	push	ar5
      008A45 12 99 CB         [24] 1454 	lcall	_keycode_at_keymap_location_raw
      008A48 AB 82            [24] 1455 	mov	r3, dpl
      008A4A AC 83            [24] 1456 	mov	r4, dph
      008A4C D0 05            [24] 1457 	pop	ar5
      008A4E D0 06            [24] 1458 	pop	ar6
      008A50 D0 07            [24] 1459 	pop	ar7
      008A52 90 0B 20         [24] 1460 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      008A55 EE               [12] 1461 	mov	a,r6
      008A56 F0               [24] 1462 	movx	@dptr,a
      008A57 90 0B 21         [24] 1463 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      008A5A ED               [12] 1464 	mov	a,r5
      008A5B F0               [24] 1465 	movx	@dptr,a
      008A5C 90 0B 22         [24] 1466 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      008A5F 12 38 34         [24] 1467 	lcall	_ak820_outline_0085
      008A62 8F 82            [24] 1468 	mov	dpl, r7
      008A64 C0 07            [24] 1469 	push	ar7
      008A66 C0 06            [24] 1470 	push	ar6
      008A68 C0 05            [24] 1471 	push	ar5
      008A6A 12 87 7C         [24] 1472 	lcall	_dynamic_keymap_set_keycode
      008A6D D0 05            [24] 1473 	pop	ar5
      008A6F D0 06            [24] 1474 	pop	ar6
      008A71 D0 07            [24] 1475 	pop	ar7
                                   1476 ;	quantum/dynamic_keymap.c:422: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      008A73 0D               [12] 1477 	inc	r5
      008A74 80 B8            [24] 1478 	sjmp	00107$
      008A76                       1479 00111$:
                                   1480 ;	quantum/dynamic_keymap.c:421: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      008A76 0E               [12] 1481 	inc	r6
      008A77 80 AE            [24] 1482 	sjmp	00110$
      008A79                       1483 00102$:
                                   1484 ;	quantum/dynamic_keymap.c:427: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      008A79 7E 00            [12] 1485 	mov	r6,#0x00
      008A7B                       1486 00113$:
      008A7B BE 01 00         [24] 1487 	cjne	r6,#0x01,00204$
      008A7E                       1488 00204$:
      008A7E 50 4A            [24] 1489 	jnc	00117$
                                   1490 ;	quantum/dynamic_keymap.c:428: dynamic_keymap_set_encoder(layer, encoder, true, keycode_at_encodermap_location_raw(layer, encoder, true));
      008A80 12 91 E3         [24] 1491 	lcall	_ak820_outline_0181
      008A83 04               [12] 1492 	inc	a
      008A84 F0               [24] 1493 	movx	@dptr,a
      008A85 8F 82            [24] 1494 	mov	dpl, r7
      008A87 C0 07            [24] 1495 	push	ar7
      008A89 12 9A 10         [24] 1496 	lcall	_keycode_at_encodermap_location_raw
      008A8C 12 38 71         [24] 1497 	lcall	_ak820_outline_0149
      008A8F D0 07            [24] 1498 	pop	ar7
      008A91 12 91 DA         [24] 1499 	lcall	_ak820_outline_0180
      008A94 04               [12] 1500 	inc	a
      008A95 F0               [24] 1501 	movx	@dptr,a
      008A96 90 0B 2C         [24] 1502 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008A99 12 38 21         [24] 1503 	lcall	_ak820_outline_0072
      008A9C 8F 82            [24] 1504 	mov	dpl, r7
      008A9E C0 07            [24] 1505 	push	ar7
      008AA0 11 56            [24] 1506 	acall	_dynamic_keymap_set_encoder
      008AA2 D0 07            [24] 1507 	pop	ar7
                                   1508 ;	quantum/dynamic_keymap.c:429: dynamic_keymap_set_encoder(layer, encoder, false, keycode_at_encodermap_location_raw(layer, encoder, false));
      008AA4 12 91 E3         [24] 1509 	lcall	_ak820_outline_0181
      008AA7 F0               [24] 1510 	movx	@dptr,a
      008AA8 8F 82            [24] 1511 	mov	dpl, r7
      008AAA C0 07            [24] 1512 	push	ar7
      008AAC 12 9A 10         [24] 1513 	lcall	_keycode_at_encodermap_location_raw
      008AAF 12 38 71         [24] 1514 	lcall	_ak820_outline_0149
      008AB2 D0 07            [24] 1515 	pop	ar7
      008AB4 12 91 DA         [24] 1516 	lcall	_ak820_outline_0180
      008AB7 F0               [24] 1517 	movx	@dptr,a
      008AB8 90 0B 2C         [24] 1518 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008ABB 12 38 21         [24] 1519 	lcall	_ak820_outline_0072
      008ABE 8F 82            [24] 1520 	mov	dpl, r7
      008AC0 C0 07            [24] 1521 	push	ar7
      008AC2 11 56            [24] 1522 	acall	_dynamic_keymap_set_encoder
      008AC4 D0 07            [24] 1523 	pop	ar7
                                   1524 ;	quantum/dynamic_keymap.c:427: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      008AC6 7E 01            [12] 1525 	mov	r6,#0x01
      008AC8 80 B1            [24] 1526 	sjmp	00113$
      008ACA                       1527 00117$:
                                   1528 ;	quantum/dynamic_keymap.c:420: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      008ACA 0F               [12] 1529 	inc	r7
      008ACB 41 1E            [12] 1530 	ajmp	00116$
      008ACD                       1531 00104$:
                                   1532 ;	quantum/dynamic_keymap.c:435: ak820_settings_reset();
      008ACD 12 47 9E         [24] 1533 	lcall	_ak820_settings_reset
                                   1534 ;	quantum/dynamic_keymap.c:449: vial_combo_entry_t combo = { { 0 }, 0 };
      008AD0 90 0B 42         [24] 1535 	mov	dptr,#_dynamic_keymap_reset_combo_10001_418
      008AD3 12 53 9C         [24] 1536 	lcall	_ak820_outline_0173
      008AD6 90 0B 44         [24] 1537 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_418 + 0x0002)
      008AD9 F0               [24] 1538 	movx	@dptr,a
      008ADA A3               [24] 1539 	inc	dptr
      008ADB F0               [24] 1540 	movx	@dptr,a
      008ADC 90 0B 46         [24] 1541 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_418 + 0x0004)
      008ADF F0               [24] 1542 	movx	@dptr,a
      008AE0 A3               [24] 1543 	inc	dptr
      008AE1 F0               [24] 1544 	movx	@dptr,a
      008AE2 90 0B 48         [24] 1545 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_418 + 0x0006)
      008AE5 F0               [24] 1546 	movx	@dptr,a
      008AE6 A3               [24] 1547 	inc	dptr
      008AE7 F0               [24] 1548 	movx	@dptr,a
      008AE8 90 0B 4A         [24] 1549 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_418 + 0x0008)
      008AEB F0               [24] 1550 	movx	@dptr,a
      008AEC A3               [24] 1551 	inc	dptr
      008AED F0               [24] 1552 	movx	@dptr,a
                                   1553 ;	quantum/dynamic_keymap.c:450: for (reset_index_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      008AEE FF               [12] 1554 	mov	r7,a
      008AEF                       1555 00119$:
      008AEF BF 08 00         [24] 1556 	cjne	r7,#0x08,00206$
      008AF2                       1557 00206$:
      008AF2 50 16            [24] 1558 	jnc	00105$
                                   1559 ;	quantum/dynamic_keymap.c:451: dynamic_keymap_set_combo(i, &combo);
      008AF4 90 0B 33         [24] 1560 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      008AF7 74 42            [12] 1561 	mov	a,#_dynamic_keymap_reset_combo_10001_418
      008AF9 F0               [24] 1562 	movx	@dptr,a
      008AFA 74 0B            [12] 1563 	mov	a,#(_dynamic_keymap_reset_combo_10001_418 >> 8)
      008AFC 12 38 2E         [24] 1564 	lcall	_ak820_outline_0084
      008AFF 8F 82            [24] 1565 	mov	dpl, r7
      008B01 C0 07            [24] 1566 	push	ar7
      008B03 31 68            [24] 1567 	acall	_dynamic_keymap_set_combo
      008B05 D0 07            [24] 1568 	pop	ar7
                                   1569 ;	quantum/dynamic_keymap.c:450: for (reset_index_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      008B07 0F               [12] 1570 	inc	r7
      008B08 80 E5            [24] 1571 	sjmp	00119$
      008B0A                       1572 00105$:
                                   1573 ;	quantum/dynamic_keymap.c:466: vial_unlocked = vial_unlocked_prev;
      008B0A 90 0B 41         [24] 1574 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_409
      008B0D E0               [24] 1575 	movx	a,@dptr
      008B0E 90 0E 45         [24] 1576 	mov	dptr,#_vial_unlocked
      008B11 F0               [24] 1577 	movx	@dptr,a
                                   1578 ;	quantum/dynamic_keymap.c:468: }
      008B12 22               [24] 1579 	ret
                                   1580 ;------------------------------------------------------------
                                   1581 ;Allocation info for local variables in function 'ak820_dynamic_read_buffer'
                                   1582 ;------------------------------------------------------------
                                   1583 ;sloc0         Allocated with name '_ak820_dynamic_read_buffer_sloc0_1_0'
                                   1584 ;limit         Allocated with name '_ak820_dynamic_read_buffer_PARM_2'
                                   1585 ;offset        Allocated with name '_ak820_dynamic_read_buffer_PARM_3'
                                   1586 ;size          Allocated with name '_ak820_dynamic_read_buffer_PARM_4'
                                   1587 ;data          Allocated with name '_ak820_dynamic_read_buffer_PARM_5'
                                   1588 ;base          Allocated with name '_ak820_dynamic_read_buffer_base_10000_420'
                                   1589 ;target        Allocated with name '_ak820_dynamic_read_buffer_target_10000_421'
                                   1590 ;available     Allocated with name '_ak820_dynamic_read_buffer_available_10000_421'
                                   1591 ;remaining     Allocated with name '_ak820_dynamic_read_buffer_remaining_30000_424'
                                   1592 ;i             Allocated with name '_ak820_dynamic_read_buffer_i_20000_426'
                                   1593 ;------------------------------------------------------------
                                   1594 ;	quantum/dynamic_keymap.c:473: static void ak820_dynamic_read_buffer(uint16_t base, uint16_t limit, uint16_t offset, uint16_t size, uint8_t *data) {
                                   1595 ;	-----------------------------------------
                                   1596 ;	 function ak820_dynamic_read_buffer
                                   1597 ;	-----------------------------------------
      008B13                       1598 _ak820_dynamic_read_buffer:
      008B13 12 38 52         [24] 1599 	lcall	_ak820_outline_0106
      008B16 90 0B 55         [24] 1600 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_420
      008B19 12 38 57         [24] 1601 	lcall	_ak820_outline_0107
                                   1602 ;	quantum/dynamic_keymap.c:474: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      008B1C 90 0B 52         [24] 1603 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008B1F 12 37 FC         [24] 1604 	lcall	_ak820_outline_0051
                                   1605 ;	quantum/dynamic_keymap.c:475: uint8_t available = 0;
      008B22 90 0B 57         [24] 1606 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_421
      008B25 E4               [12] 1607 	clr	a
      008B26 F0               [24] 1608 	movx	@dptr,a
                                   1609 ;	quantum/dynamic_keymap.c:476: if (size > 28) return;
      008B27 90 0B 50         [24] 1610 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008B2A 12 38 1B         [24] 1611 	lcall	_ak820_outline_0059
      008B2D 8C 02            [24] 1612 	mov	ar2,r4
      008B2F 8D 03            [24] 1613 	mov	ar3,r5
      008B31 C3               [12] 1614 	clr	c
      008B32 74 1C            [12] 1615 	mov	a,#0x1c
      008B34 9A               [12] 1616 	subb	a,r2
      008B35 E4               [12] 1617 	clr	a
      008B36 9B               [12] 1618 	subb	a,r3
      008B37 50 01            [24] 1619 	jnc	00102$
                                   1620 ;	free result
      008B39 22               [24] 1621 	ret
      008B3A                       1622 00102$:
                                   1623 ;	quantum/dynamic_keymap.c:477: if (offset < limit) {
      008B3A 90 0B 4E         [24] 1624 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008B3D 12 43 06         [24] 1625 	lcall	_ak820_outline_0086
      008B40 90 0B 4C         [24] 1626 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008B43 12 38 46         [24] 1627 	lcall	_ak820_outline_0104
      008B46 C3               [12] 1628 	clr	c
      008B47 EA               [12] 1629 	mov	a,r2
      008B48 98               [12] 1630 	subb	a,r0
      008B49 EB               [12] 1631 	mov	a,r3
      008B4A 99               [12] 1632 	subb	a,r1
      008B4B 50 17            [24] 1633 	jnc	00104$
                                   1634 ;	quantum/dynamic_keymap.c:478: uint16_t remaining = limit - offset;
      008B4D E8               [12] 1635 	mov	a,r0
      008B4E C3               [12] 1636 	clr	c
      008B4F 9A               [12] 1637 	subb	a,r2
      008B50 F8               [12] 1638 	mov	r0,a
      008B51 E9               [12] 1639 	mov	a,r1
      008B52 9B               [12] 1640 	subb	a,r3
      008B53 F9               [12] 1641 	mov	r1,a
                                   1642 ;	quantum/dynamic_keymap.c:479: available = remaining < size ? remaining : size;
      008B54 C3               [12] 1643 	clr	c
      008B55 E8               [12] 1644 	mov	a,r0
      008B56 9C               [12] 1645 	subb	a,r4
      008B57 E9               [12] 1646 	mov	a,r1
      008B58 9D               [12] 1647 	subb	a,r5
      008B59 40 04            [24] 1648 	jc	00114$
      008B5B 8C 00            [24] 1649 	mov	ar0,r4
      008B5D 8D 01            [24] 1650 	mov	ar1,r5
      008B5F                       1651 00114$:
      008B5F 90 0B 57         [24] 1652 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_421
      008B62 E8               [12] 1653 	mov	a,r0
      008B63 F0               [24] 1654 	movx	@dptr,a
      008B64                       1655 00104$:
                                   1656 ;	quantum/dynamic_keymap.c:481: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      008B64 90 0B 57         [24] 1657 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_421
      008B67 E0               [24] 1658 	movx	a,@dptr
      008B68 F5 2C            [12] 1659 	mov	_ak820_dynamic_read_buffer_sloc0_1_0,a
      008B6A E0               [24] 1660 	movx	a,@dptr
      008B6B 60 42            [24] 1661 	jz	00106$
      008B6D C0 04            [24] 1662 	push	ar4
      008B6F C0 05            [24] 1663 	push	ar5
      008B71 8E 00            [24] 1664 	mov	ar0,r6
      008B73 8F 05            [24] 1665 	mov	ar5,r7
      008B75 90 0B 55         [24] 1666 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_420
      008B78 E0               [24] 1667 	movx	a,@dptr
      008B79 F9               [12] 1668 	mov	r1,a
      008B7A A3               [24] 1669 	inc	dptr
      008B7B E0               [24] 1670 	movx	a,@dptr
      008B7C FC               [12] 1671 	mov	r4,a
      008B7D EA               [12] 1672 	mov	a,r2
      008B7E 29               [12] 1673 	add	a, r1
      008B7F FA               [12] 1674 	mov	r2,a
      008B80 EB               [12] 1675 	mov	a,r3
      008B81 3C               [12] 1676 	addc	a, r4
      008B82 FB               [12] 1677 	mov	r3,a
      008B83 90 05 81         [24] 1678 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      008B86 EA               [12] 1679 	mov	a,r2
      008B87 F0               [24] 1680 	movx	@dptr,a
      008B88 EB               [12] 1681 	mov	a,r3
      008B89 12 38 2E         [24] 1682 	lcall	_ak820_outline_0084
      008B8C 90 05 84         [24] 1683 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      008B8F E5 2C            [12] 1684 	mov	a,_ak820_dynamic_read_buffer_sloc0_1_0
      008B91 12 38 61         [24] 1685 	lcall	_ak820_outline_0127
      008B94 88 82            [24] 1686 	mov	dpl, r0
      008B96 8D 83            [24] 1687 	mov	dph, r5
      008B98 C0 07            [24] 1688 	push	ar7
      008B9A C0 06            [24] 1689 	push	ar6
      008B9C C0 05            [24] 1690 	push	ar5
      008B9E C0 04            [24] 1691 	push	ar4
      008BA0 12 40 71         [24] 1692 	lcall	_ak820_eeprom_read_block_xdata
      008BA3 D0 04            [24] 1693 	pop	ar4
      008BA5 D0 05            [24] 1694 	pop	ar5
      008BA7 D0 06            [24] 1695 	pop	ar6
      008BA9 D0 07            [24] 1696 	pop	ar7
                                   1697 ;	quantum/dynamic_keymap.c:482: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      008BAB D0 05            [24] 1698 	pop	ar5
      008BAD D0 04            [24] 1699 	pop	ar4
                                   1700 ;	quantum/dynamic_keymap.c:481: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      008BAF                       1701 00106$:
                                   1702 ;	quantum/dynamic_keymap.c:482: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      008BAF 90 0B 57         [24] 1703 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_421
      008BB2 E0               [24] 1704 	movx	a,@dptr
      008BB3 FB               [12] 1705 	mov	r3,a
      008BB4                       1706 00109$:
      008BB4 8B 01            [24] 1707 	mov	ar1,r3
      008BB6 7A 00            [12] 1708 	mov	r2,#0x00
      008BB8 C3               [12] 1709 	clr	c
      008BB9 E9               [12] 1710 	mov	a,r1
      008BBA 9C               [12] 1711 	subb	a,r4
      008BBB EA               [12] 1712 	mov	a,r2
      008BBC 9D               [12] 1713 	subb	a,r5
      008BBD 50 09            [24] 1714 	jnc	00111$
      008BBF EB               [12] 1715 	mov	a,r3
      008BC0 12 37 EC         [24] 1716 	lcall	_ak820_outline_0017
      008BC3 E4               [12] 1717 	clr	a
      008BC4 F0               [24] 1718 	movx	@dptr,a
      008BC5 0B               [12] 1719 	inc	r3
      008BC6 80 EC            [24] 1720 	sjmp	00109$
      008BC8                       1721 00111$:
                                   1722 ;	quantum/dynamic_keymap.c:483: }
      008BC8 22               [24] 1723 	ret
                                   1724 ;------------------------------------------------------------
                                   1725 ;Allocation info for local variables in function 'dynamic_keymap_get_buffer'
                                   1726 ;------------------------------------------------------------
                                   1727 ;size          Allocated with name '_dynamic_keymap_get_buffer_PARM_2'
                                   1728 ;data          Allocated with name '_dynamic_keymap_get_buffer_PARM_3'
                                   1729 ;offset        Allocated with name '_dynamic_keymap_get_buffer_offset_10000_427'
                                   1730 ;------------------------------------------------------------
                                   1731 ;	quantum/dynamic_keymap.c:486: void dynamic_keymap_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   1732 ;	-----------------------------------------
                                   1733 ;	 function dynamic_keymap_get_buffer
                                   1734 ;	-----------------------------------------
      008BC9                       1735 _dynamic_keymap_get_buffer:
      008BC9 12 38 52         [24] 1736 	lcall	_ak820_outline_0106
      008BCC 90 0B 5D         [24] 1737 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_427
      008BCF 12 38 57         [24] 1738 	lcall	_ak820_outline_0107
                                   1739 ;	quantum/dynamic_keymap.c:489: DYNAMIC_KEYMAP_LAYER_COUNT * MATRIX_ROWS * MATRIX_COLS * 2, offset, size, data);
      008BD2 90 0B 5D         [24] 1740 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_427
      008BD5 12 37 FC         [24] 1741 	lcall	_ak820_outline_0051
      008BD8 90 0B 58         [24] 1742 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_2
      008BDB 12 38 1B         [24] 1743 	lcall	_ak820_outline_0059
      008BDE 90 0B 5A         [24] 1744 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_3
      008BE1 E0               [24] 1745 	movx	a,@dptr
      008BE2 F9               [12] 1746 	mov	r1,a
      008BE3 A3               [24] 1747 	inc	dptr
      008BE4 12 43 06         [24] 1748 	lcall	_ak820_outline_0086
      008BE7 90 0B 4C         [24] 1749 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008BEA E4               [12] 1750 	clr	a
      008BEB F0               [24] 1751 	movx	@dptr,a
      008BEC 74 06            [12] 1752 	mov	a,#0x06
      008BEE A3               [24] 1753 	inc	dptr
      008BEF F0               [24] 1754 	movx	@dptr,a
      008BF0 90 0B 4E         [24] 1755 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008BF3 12 4C FA         [24] 1756 	lcall	_ak820_outline_0060
      008BF6 90 0B 50         [24] 1757 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008BF9 12 38 21         [24] 1758 	lcall	_ak820_outline_0072
      008BFC 90 0B 52         [24] 1759 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008BFF 12 4D 15         [24] 1760 	lcall	_ak820_outline_0139
      008C02 EB               [12] 1761 	mov	a,r3
      008C03 A3               [24] 1762 	inc	dptr
      008C04 F0               [24] 1763 	movx	@dptr,a
      008C05 90 00 40         [24] 1764 	mov	dptr,#0x0040
                                   1765 ;	quantum/dynamic_keymap.c:511: }
      008C08 61 13            [12] 1766 	ajmp	_ak820_dynamic_read_buffer
                                   1767 ;------------------------------------------------------------
                                   1768 ;Allocation info for local variables in function 'dynamic_keymap_set_buffer'
                                   1769 ;------------------------------------------------------------
                                   1770 ;sloc0         Allocated with name '_dynamic_keymap_set_buffer_sloc0_1_0'
                                   1771 ;sloc1         Allocated with name '_dynamic_keymap_set_buffer_sloc1_1_0'
                                   1772 ;sloc2         Allocated with name '_dynamic_keymap_set_buffer_sloc2_1_0'
                                   1773 ;size          Allocated with name '_dynamic_keymap_set_buffer_PARM_2'
                                   1774 ;data          Allocated with name '_dynamic_keymap_set_buffer_PARM_3'
                                   1775 ;offset        Allocated with name '_dynamic_keymap_set_buffer_offset_10000_429'
                                   1776 ;dynamic_keymap_eeprom_size Allocated with name '_dynamic_keymap_set_buffer_dynamic_keymap_eeprom_size_10000_430'
                                   1777 ;target        Allocated with name '_dynamic_keymap_set_buffer_target_10000_430'
                                   1778 ;buffer        Allocated with name '_dynamic_keymap_set_buffer_buffer_10000_430'
                                   1779 ;count         Allocated with name '_dynamic_keymap_set_buffer_count_10001_433'
                                   1780 ;chk_offset    Allocated with name '_dynamic_keymap_set_buffer_chk_offset_30001_436'
                                   1781 ;chk_sz        Allocated with name '_dynamic_keymap_set_buffer_chk_sz_30001_436'
                                   1782 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_438'
                                   1783 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_441'
                                   1784 ;i             Allocated with name '_dynamic_keymap_set_buffer_i_40001_443'
                                   1785 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_444'
                                   1786 ;------------------------------------------------------------
                                   1787 ;	quantum/dynamic_keymap.c:513: void dynamic_keymap_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   1788 ;	-----------------------------------------
                                   1789 ;	 function dynamic_keymap_set_buffer
                                   1790 ;	-----------------------------------------
      008C0A                       1791 _dynamic_keymap_set_buffer:
      008C0A 12 38 52         [24] 1792 	lcall	_ak820_outline_0106
      008C0D 90 0B 64         [24] 1793 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_429
      008C10 12 38 57         [24] 1794 	lcall	_ak820_outline_0107
                                   1795 ;	quantum/dynamic_keymap.c:515: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset);
      008C13 90 0B 64         [24] 1796 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_429
      008C16 12 37 D0         [24] 1797 	lcall	_ak820_outline_0010
      008C19 74 40            [12] 1798 	mov	a,#0x40
      008C1B 2C               [12] 1799 	add	a, r4
      008C1C FA               [12] 1800 	mov	r2,a
      008C1D E4               [12] 1801 	clr	a
      008C1E 3D               [12] 1802 	addc	a, r5
      008C1F FB               [12] 1803 	mov	r3,a
                                   1804 ;	quantum/dynamic_keymap.c:516: uint8_t DYNAMIC_BUFFER_MEM *buffer = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      008C20 90 0B 61         [24] 1805 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_3
      008C23 12 38 46         [24] 1806 	lcall	_ak820_outline_0104
                                   1807 ;	quantum/dynamic_keymap.c:520: if (!size) return;
      008C26 90 0B 5F         [24] 1808 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_2
      008C29 E0               [24] 1809 	movx	a,@dptr
      008C2A F5 2D            [12] 1810 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,a
      008C2C A3               [24] 1811 	inc	dptr
      008C2D E0               [24] 1812 	movx	a,@dptr
      008C2E F5 2E            [12] 1813 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),a
      008C30 E5 2D            [12] 1814 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008C32 45 2E            [12] 1815 	orl	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008C34 70 01            [24] 1816 	jnz	00102$
      008C36 22               [24] 1817 	ret
      008C37                       1818 00102$:
                                   1819 ;	quantum/dynamic_keymap.c:522: if (size > 28) return;
      008C37 85 2D 2F         [24] 1820 	mov	_dynamic_keymap_set_buffer_sloc1_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
      008C3A 85 2E 30         [24] 1821 	mov	(_dynamic_keymap_set_buffer_sloc1_1_0 + 1),(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008C3D C3               [12] 1822 	clr	c
      008C3E 74 1C            [12] 1823 	mov	a,#0x1c
      008C40 95 2F            [12] 1824 	subb	a,_dynamic_keymap_set_buffer_sloc1_1_0
      008C42 E4               [12] 1825 	clr	a
      008C43 95 30            [12] 1826 	subb	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      008C45 50 01            [24] 1827 	jnc	00104$
                                   1828 ;	free result
      008C47 22               [24] 1829 	ret
      008C48                       1830 00104$:
                                   1831 ;	quantum/dynamic_keymap.c:524: dynamic_buffer_size_t count = size;
      008C48 85 2D 31         [24] 1832 	mov	_dynamic_keymap_set_buffer_sloc2_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
                                   1833 ;	quantum/dynamic_keymap.c:528: if (offset >= dynamic_keymap_eeprom_size || dynamic_keymap_eeprom_size - offset < size)
      008C4B 74 FA            [12] 1834 	mov	a,#0x100 - 0x06
      008C4D 2F               [12] 1835 	add	a,r7
      008C4E 40 11            [24] 1836 	jc	00105$
      008C50 E4               [12] 1837 	clr	a
      008C51 C3               [12] 1838 	clr	c
      008C52 9E               [12] 1839 	subb	a,r6
      008C53 FE               [12] 1840 	mov	r6,a
      008C54 74 06            [12] 1841 	mov	a,#0x06
      008C56 9F               [12] 1842 	subb	a,r7
      008C57 FF               [12] 1843 	mov	r7,a
      008C58 C3               [12] 1844 	clr	c
      008C59 EE               [12] 1845 	mov	a,r6
      008C5A 95 2D            [12] 1846 	subb	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008C5C EF               [12] 1847 	mov	a,r7
      008C5D 95 2E            [12] 1848 	subb	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008C5F 50 01            [24] 1849 	jnc	00106$
      008C61                       1850 00105$:
                                   1851 ;	quantum/dynamic_keymap.c:529: return;
      008C61 22               [24] 1852 	ret
      008C62                       1853 00106$:
                                   1854 ;	quantum/dynamic_keymap.c:533: if (!vial_unlocked) {
      008C62 90 0E 45         [24] 1855 	mov	dptr,#_vial_unlocked
      008C65 E0               [24] 1856 	movx	a,@dptr
      008C66 60 02            [24] 1857 	jz	00207$
      008C68 A1 76            [12] 1858 	ajmp	00120$
      008C6A                       1859 00207$:
                                   1860 ;	quantum/dynamic_keymap.c:535: dynamic_buffer_size_t chk_offset = 0;
      008C6A 90 0B 66         [24] 1861 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_436
      008C6D E4               [12] 1862 	clr	a
      008C6E F0               [24] 1863 	movx	@dptr,a
                                   1864 ;	quantum/dynamic_keymap.c:536: dynamic_buffer_size_t chk_sz = count;
      008C6F 90 0B 67         [24] 1865 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_436
      008C72 E5 31            [12] 1866 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008C74 F0               [24] 1867 	movx	@dptr,a
                                   1868 ;	quantum/dynamic_keymap.c:539: if (offset % 2 != 0) {
      008C75 EC               [12] 1869 	mov	a,r4
      008C76 30 E0 33         [24] 1870 	jnb	acc.0,00111$
                                   1871 ;	quantum/dynamic_keymap.c:540: uint16_t kc = (eeprom_read_byte(target - 1) << 8) | buffer[0];
      008C79 EA               [12] 1872 	mov	a,r2
      008C7A 24 FF            [12] 1873 	add	a,#0xff
      008C7C FE               [12] 1874 	mov	r6,a
      008C7D EB               [12] 1875 	mov	a,r3
      008C7E 34 FF            [12] 1876 	addc	a,#0xff
      008C80 FF               [12] 1877 	mov	r7,a
      008C81 7D 00            [12] 1878 	mov	r5,#0x00
      008C83 12 43 2B         [24] 1879 	lcall	_ak820_outline_0121
      008C86 8D F0            [24] 1880 	mov	b, r5
      008C88 12 40 36         [24] 1881 	lcall	_eeprom_read_byte
      008C8B AE 82            [24] 1882 	mov	r6,dpl
      008C8D 7F 00            [12] 1883 	mov	r7,#0x00
      008C8F 12 38 76         [24] 1884 	lcall	_ak820_outline_0154
      008C92 E0               [24] 1885 	movx	a,@dptr
      008C93 7C 00            [12] 1886 	mov	r4,#0x00
      008C95 42 07            [12] 1887 	orl	ar7,a
      008C97 EC               [12] 1888 	mov	a,r4
      008C98 42 06            [12] 1889 	orl	ar6,a
                                   1890 ;	quantum/dynamic_keymap.c:541: if (kc == QK_BOOT)
      008C9A BF 00 09         [24] 1891 	cjne	r7,#0x00,00109$
      008C9D BE 7C 06         [24] 1892 	cjne	r6,#0x7c,00109$
                                   1893 ;	quantum/dynamic_keymap.c:542: buffer[0] = 0xFF;
      008CA0 12 38 76         [24] 1894 	lcall	_ak820_outline_0154
      008CA3 74 FF            [12] 1895 	mov	a,#0xff
      008CA5 F0               [24] 1896 	movx	@dptr,a
      008CA6                       1897 00109$:
                                   1898 ;	quantum/dynamic_keymap.c:545: chk_offset += 1;
      008CA6 90 0B 66         [24] 1899 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_436
      008CA9 74 01            [12] 1900 	mov	a,#0x01
      008CAB F0               [24] 1901 	movx	@dptr,a
      008CAC                       1902 00111$:
                                   1903 ;	quantum/dynamic_keymap.c:549: if ((offset + size) % 2 != 0) {
      008CAC 90 0B 64         [24] 1904 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_429
      008CAF 12 37 FC         [24] 1905 	lcall	_ak820_outline_0051
      008CB2 E5 2D            [12] 1906 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008CB4 2E               [12] 1907 	add	a, r6
      008CB5 FE               [12] 1908 	mov	r6,a
      008CB6 E5 2E            [12] 1909 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008CB8 3F               [12] 1910 	addc	a, r7
      008CB9 EE               [12] 1911 	mov	a,r6
      008CBA 30 E0 5A         [24] 1912 	jnb	acc.0,00115$
                                   1913 ;	quantum/dynamic_keymap.c:550: uint16_t kc = (buffer[count - 1] << 8) | eeprom_read_byte(target + count);
      008CBD AE 31            [24] 1914 	mov	r6,_dynamic_keymap_set_buffer_sloc2_1_0
      008CBF 7F 00            [12] 1915 	mov	r7,#0x00
      008CC1 EE               [12] 1916 	mov	a,r6
      008CC2 24 FF            [12] 1917 	add	a,#0xff
      008CC4 FC               [12] 1918 	mov	r4,a
      008CC5 EF               [12] 1919 	mov	a,r7
      008CC6 34 FF            [12] 1920 	addc	a,#0xff
      008CC8 FD               [12] 1921 	mov	r5,a
      008CC9 EC               [12] 1922 	mov	a,r4
      008CCA 28               [12] 1923 	add	a, r0
      008CCB F5 82            [12] 1924 	mov	dpl,a
      008CCD ED               [12] 1925 	mov	a,r5
      008CCE 39               [12] 1926 	addc	a, r1
      008CCF F5 83            [12] 1927 	mov	dph,a
      008CD1 E0               [24] 1928 	movx	a,@dptr
      008CD2 FC               [12] 1929 	mov	r4,a
      008CD3 7D 00            [12] 1930 	mov	r5,#0x00
      008CD5 E5 31            [12] 1931 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008CD7 2A               [12] 1932 	add	a, r2
      008CD8 FA               [12] 1933 	mov	r2,a
      008CD9 E4               [12] 1934 	clr	a
      008CDA 3B               [12] 1935 	addc	a, r3
      008CDB FB               [12] 1936 	mov	r3,a
      008CDC C0 00            [24] 1937 	push	ar0
      008CDE C0 01            [24] 1938 	push	ar1
      008CE0 8B 01            [24] 1939 	mov	ar1,r3
      008CE2 7B 00            [12] 1940 	mov	r3,#0x00
      008CE4 8A 82            [24] 1941 	mov	dpl, r2
      008CE6 89 83            [24] 1942 	mov	dph, r1
      008CE8 8B F0            [24] 1943 	mov	b, r3
      008CEA 12 40 36         [24] 1944 	lcall	_eeprom_read_byte
      008CED AB 82            [24] 1945 	mov	r3, dpl
      008CEF 7A 00            [12] 1946 	mov	r2,#0x00
      008CF1 EB               [12] 1947 	mov	a,r3
      008CF2 12 43 41         [24] 1948 	lcall	_ak820_outline_0147
                                   1949 ;	quantum/dynamic_keymap.c:551: if (kc == QK_BOOT)
      008CF5 BD 00 05         [24] 1950 	cjne	r5,#0x00,00212$
      008CF8 BC 7C 02         [24] 1951 	cjne	r4,#0x7c,00212$
      008CFB 80 06            [24] 1952 	sjmp	00213$
      008CFD                       1953 00212$:
      008CFD D0 01            [24] 1954 	pop	ar1
      008CFF D0 00            [24] 1955 	pop	ar0
      008D01 80 0D            [24] 1956 	sjmp	00113$
      008D03                       1957 00213$:
      008D03 D0 01            [24] 1958 	pop	ar1
      008D05 D0 00            [24] 1959 	pop	ar0
                                   1960 ;	quantum/dynamic_keymap.c:552: buffer[count - 1] = 0xFF;
      008D07 1E               [12] 1961 	dec	r6
      008D08 BE FF 01         [24] 1962 	cjne	r6,#0xff,00214$
      008D0B 1F               [12] 1963 	dec	r7
      008D0C                       1964 00214$:
      008D0C EE               [12] 1965 	mov	a,r6
      008D0D 12 91 B6         [24] 1966 	lcall	_ak820_outline_0131
      008D10                       1967 00113$:
                                   1968 ;	quantum/dynamic_keymap.c:555: chk_sz -= 1;
      008D10 E5 31            [12] 1969 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008D12 14               [12] 1970 	dec	a
      008D13 90 0B 67         [24] 1971 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_436
      008D16 F0               [24] 1972 	movx	@dptr,a
      008D17                       1973 00115$:
                                   1974 ;	quantum/dynamic_keymap.c:559: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      008D17 90 0B 66         [24] 1975 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_436
      008D1A E0               [24] 1976 	movx	a,@dptr
      008D1B 90 0B 68         [24] 1977 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_443
      008D1E F0               [24] 1978 	movx	@dptr,a
      008D1F                       1979 00122$:
      008D1F 90 0B 68         [24] 1980 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_443
      008D22 E0               [24] 1981 	movx	a,@dptr
      008D23 FF               [12] 1982 	mov	r7,a
      008D24 90 0B 67         [24] 1983 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_436
      008D27 E0               [24] 1984 	movx	a,@dptr
      008D28 FE               [12] 1985 	mov	r6,a
      008D29 C3               [12] 1986 	clr	c
      008D2A EF               [12] 1987 	mov	a,r7
      008D2B 9E               [12] 1988 	subb	a,r6
      008D2C 50 48            [24] 1989 	jnc	00120$
                                   1990 ;	quantum/dynamic_keymap.c:560: uint16_t kc = (buffer[i] << 8) | buffer[i + 1];
      008D2E EF               [12] 1991 	mov	a,r7
      008D2F 28               [12] 1992 	add	a, r0
      008D30 FD               [12] 1993 	mov	r5,a
      008D31 E4               [12] 1994 	clr	a
      008D32 39               [12] 1995 	addc	a, r1
      008D33 FE               [12] 1996 	mov	r6,a
      008D34 12 4D 00         [24] 1997 	lcall	_ak820_outline_0076
      008D37 7B 00            [12] 1998 	mov	r3,#0x00
      008D39 8C 2E            [24] 1999 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),r4
      008D3B 8B 2D            [24] 2000 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,r3
      008D3D 8F 02            [24] 2001 	mov	ar2,r7
      008D3F 7F 00            [12] 2002 	mov	r7,#0x00
      008D41 74 01            [12] 2003 	mov	a,#0x01
      008D43 2A               [12] 2004 	add	a, r2
      008D44 FB               [12] 2005 	mov	r3,a
      008D45 E4               [12] 2006 	clr	a
      008D46 3F               [12] 2007 	addc	a, r7
      008D47 FC               [12] 2008 	mov	r4,a
      008D48 EB               [12] 2009 	mov	a,r3
      008D49 28               [12] 2010 	add	a, r0
      008D4A F5 82            [12] 2011 	mov	dpl,a
      008D4C EC               [12] 2012 	mov	a,r4
      008D4D 39               [12] 2013 	addc	a, r1
      008D4E F5 83            [12] 2014 	mov	dph,a
      008D50 E0               [24] 2015 	movx	a,@dptr
      008D51 FC               [12] 2016 	mov	r4,a
      008D52 7B 00            [12] 2017 	mov	r3,#0x00
      008D54 E5 2E            [12] 2018 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008D56 42 03            [12] 2019 	orl	ar3,a
                                   2020 ;	quantum/dynamic_keymap.c:561: if (kc == QK_BOOT) {
      008D58 BC 00 12         [24] 2021 	cjne	r4,#0x00,00123$
      008D5B BB 7C 0F         [24] 2022 	cjne	r3,#0x7c,00123$
                                   2023 ;	quantum/dynamic_keymap.c:562: buffer[i] = 0xFF;
      008D5E 12 38 66         [24] 2024 	lcall	_ak820_outline_0136
      008D61 74 FF            [12] 2025 	mov	a,#0xff
      008D63 F0               [24] 2026 	movx	@dptr,a
                                   2027 ;	quantum/dynamic_keymap.c:563: buffer[i + 1] = 0xFF;
      008D64 0A               [12] 2028 	inc	r2
      008D65 BA 00 01         [24] 2029 	cjne	r2,#0x00,00218$
      008D68 0F               [12] 2030 	inc	r7
      008D69                       2031 00218$:
      008D69 EA               [12] 2032 	mov	a,r2
      008D6A 12 91 B6         [24] 2033 	lcall	_ak820_outline_0131
      008D6D                       2034 00123$:
                                   2035 ;	quantum/dynamic_keymap.c:559: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      008D6D 90 0B 68         [24] 2036 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_443
      008D70 E0               [24] 2037 	movx	a,@dptr
      008D71 24 02            [12] 2038 	add	a,#0x02
      008D73 F0               [24] 2039 	movx	@dptr,a
      008D74 80 A9            [24] 2040 	sjmp	00122$
      008D76                       2041 00120$:
                                   2042 ;	quantum/dynamic_keymap.c:574: ak820_eeprom_write_block_xdata(buffer, (void *)(uintptr_t)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset), size);
      008D76 90 0B 64         [24] 2043 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_429
      008D79 12 37 FC         [24] 2044 	lcall	_ak820_outline_0051
      008D7C 74 40            [12] 2045 	mov	a,#0x40
      008D7E 12 43 35         [24] 2046 	lcall	_ak820_outline_0138
      008D81 90 05 8A         [24] 2047 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      008D84 12 4C FA         [24] 2048 	lcall	_ak820_outline_0060
      008D87 E4               [12] 2049 	clr	a
      008D88 A3               [24] 2050 	inc	dptr
      008D89 F0               [24] 2051 	movx	@dptr,a
      008D8A 90 05 8D         [24] 2052 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      008D8D E5 2F            [12] 2053 	mov	a,_dynamic_keymap_set_buffer_sloc1_1_0
      008D8F F0               [24] 2054 	movx	@dptr,a
      008D90 E5 30            [12] 2055 	mov	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      008D92 A3               [24] 2056 	inc	dptr
      008D93 F0               [24] 2057 	movx	@dptr,a
      008D94 12 38 76         [24] 2058 	lcall	_ak820_outline_0154
                                   2059 ;	quantum/dynamic_keymap.c:584: }
      008D97 02 40 FD         [24] 2060 	ljmp	_ak820_eeprom_write_block_xdata
                                   2061 ;------------------------------------------------------------
                                   2062 ;Allocation info for local variables in function 'keycode_at_keymap_location'
                                   2063 ;------------------------------------------------------------
                                   2064 ;row           Allocated with name '_keycode_at_keymap_location_PARM_2'
                                   2065 ;column        Allocated with name '_keycode_at_keymap_location_PARM_3'
                                   2066 ;layer_num     Allocated with name '_keycode_at_keymap_location_layer_num_10000_447'
                                   2067 ;------------------------------------------------------------
                                   2068 ;	quantum/dynamic_keymap.c:586: uint16_t keycode_at_keymap_location(uint8_t layer_num, uint8_t row, uint8_t column) {
                                   2069 ;	-----------------------------------------
                                   2070 ;	 function keycode_at_keymap_location
                                   2071 ;	-----------------------------------------
      008D9A                       2072 _keycode_at_keymap_location:
      008D9A E5 82            [12] 2073 	mov	a,dpl
      008D9C 90 0B 6B         [24] 2074 	mov	dptr,#_keycode_at_keymap_location_layer_num_10000_447
      008D9F F0               [24] 2075 	movx	@dptr,a
                                   2076 ;	quantum/dynamic_keymap.c:587: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && row < MATRIX_ROWS && column < MATRIX_COLS) {
      008DA0 E0               [24] 2077 	movx	a,@dptr
      008DA1 FF               [12] 2078 	mov	r7,a
      008DA2 BF 06 00         [24] 2079 	cjne	r7,#0x06,00128$
      008DA5                       2080 00128$:
      008DA5 50 23            [24] 2081 	jnc	00102$
      008DA7 90 0B 69         [24] 2082 	mov	dptr,#_keycode_at_keymap_location_PARM_2
      008DAA E0               [24] 2083 	movx	a,@dptr
      008DAB FE               [12] 2084 	mov	r6,a
      008DAC BE 10 00         [24] 2085 	cjne	r6,#0x10,00130$
      008DAF                       2086 00130$:
      008DAF 50 19            [24] 2087 	jnc	00102$
      008DB1 90 0B 6A         [24] 2088 	mov	dptr,#_keycode_at_keymap_location_PARM_3
      008DB4 E0               [24] 2089 	movx	a,@dptr
      008DB5 FD               [12] 2090 	mov	r5,a
      008DB6 BD 08 00         [24] 2091 	cjne	r5,#0x08,00132$
      008DB9                       2092 00132$:
      008DB9 50 0F            [24] 2093 	jnc	00102$
                                   2094 ;	quantum/dynamic_keymap.c:588: return dynamic_keymap_get_keycode(layer_num, row, column);
      008DBB 90 0B 1D         [24] 2095 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      008DBE EE               [12] 2096 	mov	a,r6
      008DBF F0               [24] 2097 	movx	@dptr,a
      008DC0 90 0B 1E         [24] 2098 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      008DC3 ED               [12] 2099 	mov	a,r5
      008DC4 F0               [24] 2100 	movx	@dptr,a
      008DC5 8F 82            [24] 2101 	mov	dpl, r7
      008DC7 02 87 2F         [24] 2102 	ljmp	_dynamic_keymap_get_keycode
      008DCA                       2103 00102$:
                                   2104 ;	quantum/dynamic_keymap.c:590: return KC_NO;
      008DCA 90 00 00         [24] 2105 	mov	dptr,#0x0000
                                   2106 ;	quantum/dynamic_keymap.c:591: }
      008DCD 22               [24] 2107 	ret
                                   2108 ;------------------------------------------------------------
                                   2109 ;Allocation info for local variables in function 'keycode_at_encodermap_location'
                                   2110 ;------------------------------------------------------------
                                   2111 ;encoder_idx   Allocated with name '_keycode_at_encodermap_location_PARM_2'
                                   2112 ;clockwise     Allocated with name '_keycode_at_encodermap_location_PARM_3'
                                   2113 ;layer_num     Allocated with name '_keycode_at_encodermap_location_layer_num_10000_451'
                                   2114 ;------------------------------------------------------------
                                   2115 ;	quantum/dynamic_keymap.c:594: uint16_t keycode_at_encodermap_location(uint8_t layer_num, uint8_t encoder_idx, bool clockwise) {
                                   2116 ;	-----------------------------------------
                                   2117 ;	 function keycode_at_encodermap_location
                                   2118 ;	-----------------------------------------
      008DCE                       2119 _keycode_at_encodermap_location:
      008DCE E5 82            [12] 2120 	mov	a,dpl
      008DD0 90 0B 6E         [24] 2121 	mov	dptr,#_keycode_at_encodermap_location_layer_num_10000_451
      008DD3 F0               [24] 2122 	movx	@dptr,a
                                   2123 ;	quantum/dynamic_keymap.c:595: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && encoder_idx < NUM_ENCODERS) {
      008DD4 E0               [24] 2124 	movx	a,@dptr
      008DD5 FF               [12] 2125 	mov	r7,a
      008DD6 BF 06 00         [24] 2126 	cjne	r7,#0x06,00120$
      008DD9                       2127 00120$:
      008DD9 50 1E            [24] 2128 	jnc	00102$
      008DDB 90 0B 6C         [24] 2129 	mov	dptr,#_keycode_at_encodermap_location_PARM_2
      008DDE E0               [24] 2130 	movx	a,@dptr
      008DDF FE               [12] 2131 	mov	r6,a
      008DE0 BE 01 00         [24] 2132 	cjne	r6,#0x01,00122$
      008DE3                       2133 00122$:
      008DE3 50 14            [24] 2134 	jnc	00102$
                                   2135 ;	quantum/dynamic_keymap.c:596: return dynamic_keymap_get_encoder(layer_num, encoder_idx, clockwise);
      008DE5 90 0B 6D         [24] 2136 	mov	dptr,#_keycode_at_encodermap_location_PARM_3
      008DE8 E0               [24] 2137 	movx	a,@dptr
      008DE9 FE               [12] 2138 	mov	r6,a
      008DEA 90 0B 27         [24] 2139 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      008DED E4               [12] 2140 	clr	a
      008DEE F0               [24] 2141 	movx	@dptr,a
      008DEF 90 0B 28         [24] 2142 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      008DF2 EE               [12] 2143 	mov	a,r6
      008DF3 F0               [24] 2144 	movx	@dptr,a
      008DF4 8F 82            [24] 2145 	mov	dpl, r7
      008DF6 02 87 EE         [24] 2146 	ljmp	_dynamic_keymap_get_encoder
      008DF9                       2147 00102$:
                                   2148 ;	quantum/dynamic_keymap.c:598: return KC_NO;
      008DF9 90 00 00         [24] 2149 	mov	dptr,#0x0000
                                   2150 ;	quantum/dynamic_keymap.c:599: }
      008DFC 22               [24] 2151 	ret
                                   2152 ;------------------------------------------------------------
                                   2153 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_count'
                                   2154 ;------------------------------------------------------------
                                   2155 ;	quantum/dynamic_keymap.c:602: uint8_t dynamic_keymap_macro_get_count(void) {
                                   2156 ;	-----------------------------------------
                                   2157 ;	 function dynamic_keymap_macro_get_count
                                   2158 ;	-----------------------------------------
      008DFD                       2159 _dynamic_keymap_macro_get_count:
                                   2160 ;	quantum/dynamic_keymap.c:603: return DYNAMIC_KEYMAP_MACRO_COUNT;
      008DFD 75 82 10         [24] 2161 	mov	dpl, #0x10
                                   2162 ;	quantum/dynamic_keymap.c:604: }
      008E00 22               [24] 2163 	ret
                                   2164 ;------------------------------------------------------------
                                   2165 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer_size'
                                   2166 ;------------------------------------------------------------
                                   2167 ;	quantum/dynamic_keymap.c:606: uint16_t dynamic_keymap_macro_get_buffer_size(void) {
                                   2168 ;	-----------------------------------------
                                   2169 ;	 function dynamic_keymap_macro_get_buffer_size
                                   2170 ;	-----------------------------------------
      008E01                       2171 _dynamic_keymap_macro_get_buffer_size:
                                   2172 ;	quantum/dynamic_keymap.c:607: return DYNAMIC_KEYMAP_MACRO_EEPROM_SIZE;
      008E01 90 20 00         [24] 2173 	mov	dptr,#0x2000
                                   2174 ;	quantum/dynamic_keymap.c:608: }
      008E04 22               [24] 2175 	ret
                                   2176 ;------------------------------------------------------------
                                   2177 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer'
                                   2178 ;------------------------------------------------------------
                                   2179 ;sloc0         Allocated with name '_dynamic_keymap_macro_get_buffer_sloc0_1_0'
                                   2180 ;size          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_2'
                                   2181 ;data          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_3'
                                   2182 ;offset        Allocated with name '_dynamic_keymap_macro_get_buffer_offset_10000_459'
                                   2183 ;------------------------------------------------------------
                                   2184 ;	quantum/dynamic_keymap.c:610: void dynamic_keymap_macro_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2185 ;	-----------------------------------------
                                   2186 ;	 function dynamic_keymap_macro_get_buffer
                                   2187 ;	-----------------------------------------
      008E05                       2188 _dynamic_keymap_macro_get_buffer:
      008E05 12 38 52         [24] 2189 	lcall	_ak820_outline_0106
      008E08 90 0B 74         [24] 2190 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_459
      008E0B 12 38 57         [24] 2191 	lcall	_ak820_outline_0107
                                   2192 ;	quantum/dynamic_keymap.c:613: ak820_macro_length(), offset, size, data);
      008E0E 12 2B 2B         [24] 2193 	lcall	_ak820_macro_length
      008E11 12 43 30         [24] 2194 	lcall	_ak820_outline_0135
      008E14 90 0B 74         [24] 2195 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_459
      008E17 12 38 1B         [24] 2196 	lcall	_ak820_outline_0059
      008E1A 90 0B 6F         [24] 2197 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_2
      008E1D E0               [24] 2198 	movx	a,@dptr
      008E1E F5 32            [12] 2199 	mov	_dynamic_keymap_macro_get_buffer_sloc0_1_0,a
      008E20 A3               [24] 2200 	inc	dptr
      008E21 E0               [24] 2201 	movx	a,@dptr
      008E22 F5 33            [12] 2202 	mov	(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1),a
      008E24 90 0B 71         [24] 2203 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_3
      008E27 12 38 46         [24] 2204 	lcall	_ak820_outline_0104
      008E2A A3               [24] 2205 	inc	dptr
      008E2B E0               [24] 2206 	movx	a,@dptr
      008E2C FB               [12] 2207 	mov	r3,a
      008E2D 90 0B 4C         [24] 2208 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008E30 12 4C FA         [24] 2209 	lcall	_ak820_outline_0060
      008E33 90 0B 4E         [24] 2210 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008E36 12 38 21         [24] 2211 	lcall	_ak820_outline_0072
      008E39 90 0B 50         [24] 2212 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008E3C E5 32            [12] 2213 	mov	a,_dynamic_keymap_macro_get_buffer_sloc0_1_0
      008E3E F0               [24] 2214 	movx	@dptr,a
      008E3F E5 33            [12] 2215 	mov	a,(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1)
      008E41 A3               [24] 2216 	inc	dptr
      008E42 F0               [24] 2217 	movx	@dptr,a
      008E43 90 0B 52         [24] 2218 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008E46 12 53 96         [24] 2219 	lcall	_ak820_outline_0165
      008E49 EB               [12] 2220 	mov	a,r3
      008E4A A3               [24] 2221 	inc	dptr
      008E4B F0               [24] 2222 	movx	@dptr,a
      008E4C 90 08 00         [24] 2223 	mov	dptr,#0x0800
                                   2224 ;	quantum/dynamic_keymap.c:635: }
      008E4F 61 13            [12] 2225 	ajmp	_ak820_dynamic_read_buffer
                                   2226 ;------------------------------------------------------------
                                   2227 ;Allocation info for local variables in function 'dynamic_keymap_macro_set_buffer'
                                   2228 ;------------------------------------------------------------
                                   2229 ;size          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_2'
                                   2230 ;data          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_3'
                                   2231 ;offset        Allocated with name '_dynamic_keymap_macro_set_buffer_offset_10000_461'
                                   2232 ;------------------------------------------------------------
                                   2233 ;	quantum/dynamic_keymap.c:638: bool dynamic_keymap_macro_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2234 ;	-----------------------------------------
                                   2235 ;	 function dynamic_keymap_macro_set_buffer
                                   2236 ;	-----------------------------------------
      008E51                       2237 _dynamic_keymap_macro_set_buffer:
      008E51 12 38 52         [24] 2238 	lcall	_ak820_outline_0106
      008E54 90 0B 7B         [24] 2239 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_461
      008E57 12 38 57         [24] 2240 	lcall	_ak820_outline_0107
                                   2241 ;	quantum/dynamic_keymap.c:639: return ak820_macro_write(offset, size, data);
      008E5A 90 0B 7B         [24] 2242 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_461
      008E5D 12 37 FC         [24] 2243 	lcall	_ak820_outline_0051
      008E60 90 0B 76         [24] 2244 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_2
      008E63 12 38 1B         [24] 2245 	lcall	_ak820_outline_0059
      008E66 90 0B 78         [24] 2246 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_3
      008E69 E0               [24] 2247 	movx	a,@dptr
      008E6A F9               [12] 2248 	mov	r1,a
      008E6B A3               [24] 2249 	inc	dptr
      008E6C 12 43 06         [24] 2250 	lcall	_ak820_outline_0086
      008E6F 90 05 10         [24] 2251 	mov	dptr,#_ak820_macro_write_PARM_2
      008E72 12 38 21         [24] 2252 	lcall	_ak820_outline_0072
      008E75 90 05 12         [24] 2253 	mov	dptr,#_ak820_macro_write_PARM_3
      008E78 12 4D 15         [24] 2254 	lcall	_ak820_outline_0139
      008E7B EB               [12] 2255 	mov	a,r3
      008E7C A3               [24] 2256 	inc	dptr
      008E7D 12 42 F9         [24] 2257 	lcall	_ak820_outline_0061
                                   2258 ;	quantum/dynamic_keymap.c:640: }
      008E80 02 2B 45         [24] 2259 	ljmp	_ak820_macro_write
                                   2260 ;------------------------------------------------------------
                                   2261 ;Allocation info for local variables in function 'dynamic_keymap_macro_reset'
                                   2262 ;------------------------------------------------------------
                                   2263 ;	quantum/dynamic_keymap.c:655: void dynamic_keymap_macro_reset(void) {
                                   2264 ;	-----------------------------------------
                                   2265 ;	 function dynamic_keymap_macro_reset
                                   2266 ;	-----------------------------------------
      008E83                       2267 _dynamic_keymap_macro_reset:
                                   2268 ;	quantum/dynamic_keymap.c:657: ak820_macro_reset();
                                   2269 ;	quantum/dynamic_keymap.c:666: }
      008E83 02 2E 64         [24] 2270 	ljmp	_ak820_macro_reset
                                   2271 ;------------------------------------------------------------
                                   2272 ;Allocation info for local variables in function 'decode_keycode'
                                   2273 ;------------------------------------------------------------
                                   2274 ;kc            Allocated with name '_decode_keycode_kc_10000_465'
                                   2275 ;------------------------------------------------------------
                                   2276 ;	quantum/dynamic_keymap.c:668: static uint16_t decode_keycode(uint16_t kc) {
                                   2277 ;	-----------------------------------------
                                   2278 ;	 function decode_keycode
                                   2279 ;	-----------------------------------------
      008E86                       2280 _decode_keycode:
      008E86 12 38 52         [24] 2281 	lcall	_ak820_outline_0106
      008E89 90 0B 7D         [24] 2282 	mov	dptr,#_decode_keycode_kc_10000_465
      008E8C 12 38 57         [24] 2283 	lcall	_ak820_outline_0107
                                   2284 ;	quantum/dynamic_keymap.c:670: if (kc > 0xFF00)
      008E8F 90 0B 7D         [24] 2285 	mov	dptr,#_decode_keycode_kc_10000_465
      008E92 12 37 D0         [24] 2286 	lcall	_ak820_outline_0010
      008E95 C3               [12] 2287 	clr	c
      008E96 E4               [12] 2288 	clr	a
      008E97 9C               [12] 2289 	subb	a,r4
      008E98 74 FF            [12] 2290 	mov	a,#0xff
      008E9A 9D               [12] 2291 	subb	a,r5
      008E9B 50 08            [24] 2292 	jnc	00102$
                                   2293 ;	free result
                                   2294 ;	quantum/dynamic_keymap.c:671: return (kc & 0xFF) << 8;
      008E9D 8C 05            [24] 2295 	mov	ar5,r4
      008E9F 7C 00            [12] 2296 	mov	r4,#0x00
      008EA1 12 38 5C         [24] 2297 	lcall	_ak820_outline_0125
      008EA4 22               [24] 2298 	ret
      008EA5                       2299 00102$:
                                   2300 ;	quantum/dynamic_keymap.c:672: return kc;
      008EA5 12 43 2B         [24] 2301 	lcall	_ak820_outline_0121
                                   2302 ;	quantum/dynamic_keymap.c:673: }
      008EA8 22               [24] 2303 	ret
                                   2304 ;------------------------------------------------------------
                                   2305 ;Allocation info for local variables in function 'dynamic_keymap_macro_send'
                                   2306 ;------------------------------------------------------------
                                   2307 ;id            Allocated with name '_dynamic_keymap_macro_send_id_10000_468'
                                   2308 ;sending       Allocated with name '_dynamic_keymap_macro_send_sending_10000_469'
                                   2309 ;p             Allocated with name '_dynamic_keymap_macro_send_p_10001_474'
                                   2310 ;end           Allocated with name '_dynamic_keymap_macro_send_end_10002_475'
                                   2311 ;data          Allocated with name '_dynamic_keymap_macro_send_data_10003_481'
                                   2312 ;kc            Allocated with name '_dynamic_keymap_macro_send_kc_110003_499'
                                   2313 ;d0            Allocated with name '_dynamic_keymap_macro_send_d0_80003_503'
                                   2314 ;d1            Allocated with name '_dynamic_keymap_macro_send_d1_80003_503'
                                   2315 ;ms            Allocated with name '_dynamic_keymap_macro_send_ms_80004_505'
                                   2316 ;i             Allocated with name '_dynamic_keymap_macro_send_i_100004_507'
                                   2317 ;delay         Allocated with name '_dynamic_keymap_macro_send_delay_50003_511'
                                   2318 ;i             Allocated with name '_dynamic_keymap_macro_send_i_70003_513'
                                   2319 ;------------------------------------------------------------
                                   2320 ;	quantum/dynamic_keymap.c:675: void dynamic_keymap_macro_send(uint8_t id) {
                                   2321 ;	-----------------------------------------
                                   2322 ;	 function dynamic_keymap_macro_send
                                   2323 ;	-----------------------------------------
      008EA9                       2324 _dynamic_keymap_macro_send:
      008EA9 E5 82            [12] 2325 	mov	a,dpl
      008EAB 90 0B 7F         [24] 2326 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_468
      008EAE F0               [24] 2327 	movx	@dptr,a
                                   2328 ;	quantum/dynamic_keymap.c:680: if (sending) return;
      008EAF 90 0B 80         [24] 2329 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_469
      008EB2 E0               [24] 2330 	movx	a,@dptr
      008EB3 60 01            [24] 2331 	jz	00102$
      008EB5 22               [24] 2332 	ret
      008EB6                       2333 00102$:
                                   2334 ;	quantum/dynamic_keymap.c:682: if (id >= DYNAMIC_KEYMAP_MACRO_COUNT) {
      008EB6 90 0B 7F         [24] 2335 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_468
      008EB9 E0               [24] 2336 	movx	a,@dptr
      008EBA FF               [12] 2337 	mov	r7,a
      008EBB BF 10 00         [24] 2338 	cjne	r7,#0x10,00422$
      008EBE                       2339 00422$:
      008EBE 40 01            [24] 2340 	jc	00104$
                                   2341 ;	quantum/dynamic_keymap.c:683: return;
      008EC0 22               [24] 2342 	ret
      008EC1                       2343 00104$:
                                   2344 ;	quantum/dynamic_keymap.c:689: if (!ak820_macro_ready()) return;
      008EC1 C0 07            [24] 2345 	push	ar7
      008EC3 12 2A F2         [24] 2346 	lcall	_ak820_macro_ready
      008EC6 E5 82            [12] 2347 	mov	a, dpl
      008EC8 D0 07            [24] 2348 	pop	ar7
      008ECA 70 01            [24] 2349 	jnz	00106$
      008ECC 22               [24] 2350 	ret
      008ECD                       2351 00106$:
                                   2352 ;	quantum/dynamic_keymap.c:706: p = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR;
      008ECD 90 0B 81         [24] 2353 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_474
      008ED0 E4               [12] 2354 	clr	a
      008ED1 F0               [24] 2355 	movx	@dptr,a
      008ED2 74 08            [12] 2356 	mov	a,#0x08
      008ED4 A3               [24] 2357 	inc	dptr
      008ED5 F0               [24] 2358 	movx	@dptr,a
                                   2359 ;	quantum/dynamic_keymap.c:707: uint16_t end = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR + ak820_macro_length();
      008ED6 C0 07            [24] 2360 	push	ar7
      008ED8 12 2B 2B         [24] 2361 	lcall	_ak820_macro_length
      008EDB 12 43 61         [24] 2362 	lcall	_ak820_outline_0192
      008EDE D0 07            [24] 2363 	pop	ar7
      008EE0 74 08            [12] 2364 	mov	a,#0x08
      008EE2 2E               [12] 2365 	add	a, r6
      008EE3 FE               [12] 2366 	mov	r6,a
                                   2367 ;	quantum/dynamic_keymap.c:712: while (id > 0) {
      008EE4 7B 00            [12] 2368 	mov	r3,#0x00
      008EE6 7C 08            [12] 2369 	mov	r4,#0x08
      008EE8                       2370 00111$:
      008EE8 EF               [12] 2371 	mov	a,r7
      008EE9 60 31            [24] 2372 	jz	00113$
                                   2373 ;	quantum/dynamic_keymap.c:716: if (p == end) {
      008EEB EB               [12] 2374 	mov	a,r3
      008EEC B5 05 05         [24] 2375 	cjne	a,ar5,00108$
      008EEF EC               [12] 2376 	mov	a,r4
      008EF0 B5 06 01         [24] 2377 	cjne	a,ar6,00108$
                                   2378 ;	quantum/dynamic_keymap.c:717: return;
      008EF3 22               [24] 2379 	ret
      008EF4                       2380 00108$:
                                   2381 ;	quantum/dynamic_keymap.c:719: if (eeprom_read_byte((const uint8_t *)(uintptr_t)p) == 0) {
      008EF4 8B 01            [24] 2382 	mov	ar1,r3
      008EF6 8C 02            [24] 2383 	mov	ar2,r4
      008EF8 8A 00            [24] 2384 	mov	ar0,r2
      008EFA 7A 00            [12] 2385 	mov	r2,#0x00
      008EFC 89 82            [24] 2386 	mov	dpl, r1
      008EFE 88 83            [24] 2387 	mov	dph, r0
      008F00 8A F0            [24] 2388 	mov	b, r2
      008F02 12 40 36         [24] 2389 	lcall	_eeprom_read_byte
      008F05 E5 82            [12] 2390 	mov	a, dpl
      008F07 70 06            [24] 2391 	jnz	00110$
                                   2392 ;	quantum/dynamic_keymap.c:720: --id;
      008F09 1F               [12] 2393 	dec	r7
      008F0A 90 0B 7F         [24] 2394 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_468
      008F0D EF               [12] 2395 	mov	a,r7
      008F0E F0               [24] 2396 	movx	@dptr,a
      008F0F                       2397 00110$:
                                   2398 ;	quantum/dynamic_keymap.c:722: ++p;
      008F0F 0B               [12] 2399 	inc	r3
      008F10 BB 00 01         [24] 2400 	cjne	r3,#0x00,00429$
      008F13 0C               [12] 2401 	inc	r4
      008F14                       2402 00429$:
      008F14 90 0B 81         [24] 2403 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_474
      008F17 12 38 34         [24] 2404 	lcall	_ak820_outline_0085
      008F1A 80 CC            [24] 2405 	sjmp	00111$
      008F1C                       2406 00113$:
                                   2407 ;	quantum/dynamic_keymap.c:728: sending = true;
      008F1C 90 0B 80         [24] 2408 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_469
      008F1F 74 01            [12] 2409 	mov	a,#0x01
      008F21 F0               [24] 2410 	movx	@dptr,a
                                   2411 ;	quantum/dynamic_keymap.c:730: ak820_macro_cancelled = ak820_macro_primitive = false;
      008F22 12 91 D4         [24] 2412 	lcall	_ak820_outline_0168
      008F25 90 09 C9         [24] 2413 	mov	dptr,#_ak820_macro_cancelled
      008F28 F0               [24] 2414 	movx	@dptr,a
                                   2415 ;	quantum/dynamic_keymap.c:735: char data[4] = {0, 0, 0, 0};
      008F29 90 0B 83         [24] 2416 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_481
      008F2C F0               [24] 2417 	movx	@dptr,a
      008F2D 90 0B 84         [24] 2418 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_481 + 0x0001)
      008F30 F0               [24] 2419 	movx	@dptr,a
      008F31 90 0B 85         [24] 2420 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_481 + 0x0002)
      008F34 F0               [24] 2421 	movx	@dptr,a
      008F35 90 0B 86         [24] 2422 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_481 + 0x0003)
      008F38 F0               [24] 2423 	movx	@dptr,a
                                   2424 ;	quantum/dynamic_keymap.c:738: while (p < end
      008F39                       2425 00167$:
                                   2426 ;	quantum/dynamic_keymap.c:740: && !ak820_macro_cancelled
      008F39 90 0B 81         [24] 2427 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_474
      008F3C E0               [24] 2428 	movx	a,@dptr
      008F3D FC               [12] 2429 	mov	r4,a
      008F3E A3               [24] 2430 	inc	dptr
      008F3F E0               [24] 2431 	movx	a,@dptr
      008F40 FF               [12] 2432 	mov	r7,a
      008F41 C3               [12] 2433 	clr	c
      008F42 EC               [12] 2434 	mov	a,r4
      008F43 9D               [12] 2435 	subb	a,r5
      008F44 EF               [12] 2436 	mov	a,r7
      008F45 9E               [12] 2437 	subb	a,r6
      008F46 40 03            [24] 2438 	jc	00430$
      008F48 02 91 5C         [24] 2439 	ljmp	00169$
      008F4B                       2440 00430$:
      008F4B 90 09 C9         [24] 2441 	mov	dptr,#_ak820_macro_cancelled
      008F4E E0               [24] 2442 	movx	a,@dptr
      008F4F 60 03            [24] 2443 	jz	00431$
      008F51 02 91 5C         [24] 2444 	ljmp	00169$
      008F54                       2445 00431$:
                                   2446 ;	quantum/dynamic_keymap.c:743: data[0] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008F54 8C 02            [24] 2447 	mov	ar2,r4
      008F56 8F 03            [24] 2448 	mov	ar3,r7
      008F58 90 0B 81         [24] 2449 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_474
      008F5B 74 01            [12] 2450 	mov	a,#0x01
      008F5D 2C               [12] 2451 	add	a, r4
      008F5E F0               [24] 2452 	movx	@dptr,a
      008F5F E4               [12] 2453 	clr	a
      008F60 3F               [12] 2454 	addc	a, r7
      008F61 A3               [24] 2455 	inc	dptr
      008F62 F0               [24] 2456 	movx	@dptr,a
      008F63 7F 00            [12] 2457 	mov	r7,#0x00
      008F65 12 43 47         [24] 2458 	lcall	_ak820_outline_0148
      008F68 8F F0            [24] 2459 	mov	b, r7
      008F6A 12 40 36         [24] 2460 	lcall	_eeprom_read_byte
      008F6D AF 82            [24] 2461 	mov	r7, dpl
      008F6F 90 0B 83         [24] 2462 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_481
      008F72 EF               [12] 2463 	mov	a,r7
      008F73 F0               [24] 2464 	movx	@dptr,a
                                   2465 ;	quantum/dynamic_keymap.c:744: data[1] = 0;
      008F74 90 0B 84         [24] 2466 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_481 + 0x0001)
      008F77 E4               [12] 2467 	clr	a
      008F78 F0               [24] 2468 	movx	@dptr,a
                                   2469 ;	quantum/dynamic_keymap.c:746: if (data[0] == 0) {
      008F79 90 0B 83         [24] 2470 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_481
      008F7C E0               [24] 2471 	movx	a,@dptr
      008F7D 70 03            [24] 2472 	jnz	00432$
      008F7F 02 91 5C         [24] 2473 	ljmp	00169$
      008F82                       2474 00432$:
                                   2475 ;	quantum/dynamic_keymap.c:749: if (data[0] == SS_QMK_PREFIX) {
      008F82 90 0B 83         [24] 2476 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_481
      008F85 E0               [24] 2477 	movx	a,@dptr
      008F86 FF               [12] 2478 	mov	r7,a
      008F87 BF 01 02         [24] 2479 	cjne	r7,#0x01,00433$
      008F8A 80 03            [24] 2480 	sjmp	00434$
      008F8C                       2481 00433$:
      008F8C 02 91 3E         [24] 2482 	ljmp	00164$
      008F8F                       2483 00434$:
                                   2484 ;	quantum/dynamic_keymap.c:752: data[1] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008F8F 12 91 64         [24] 2485 	lcall	_ak820_outline_0000
      008F92 12 40 36         [24] 2486 	lcall	_eeprom_read_byte
      008F95 AF 82            [24] 2487 	mov	r7, dpl
      008F97 90 0B 84         [24] 2488 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_481 + 0x0001)
      008F9A EF               [12] 2489 	mov	a,r7
      008F9B F0               [24] 2490 	movx	@dptr,a
                                   2491 ;	quantum/dynamic_keymap.c:753: if (data[1] == 0)
      008F9C EF               [12] 2492 	mov	a,r7
      008F9D 70 03            [24] 2493 	jnz	00435$
      008F9F 02 91 5C         [24] 2494 	ljmp	00169$
      008FA2                       2495 00435$:
                                   2496 ;	quantum/dynamic_keymap.c:755: if (data[1] == SS_TAP_CODE || data[1] == SS_DOWN_CODE || data[1] == SS_UP_CODE) {
      008FA2 12 91 9C         [24] 2497 	lcall	_ak820_outline_0092
      008FA5 BF 01 02         [24] 2498 	cjne	r7,#0x01,00436$
      008FA8 80 13            [24] 2499 	sjmp	00151$
      008FAA                       2500 00436$:
      008FAA 12 91 9C         [24] 2501 	lcall	_ak820_outline_0092
      008FAD BF 02 02         [24] 2502 	cjne	r7,#0x02,00437$
      008FB0 80 0B            [24] 2503 	sjmp	00151$
      008FB2                       2504 00437$:
      008FB2 12 91 9C         [24] 2505 	lcall	_ak820_outline_0092
      008FB5 BF 03 02         [24] 2506 	cjne	r7,#0x03,00438$
      008FB8 80 03            [24] 2507 	sjmp	00439$
      008FBA                       2508 00438$:
      008FBA 02 90 1E         [24] 2509 	ljmp	00152$
      008FBD                       2510 00439$:
      008FBD                       2511 00151$:
                                   2512 ;	quantum/dynamic_keymap.c:757: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008FBD 12 91 64         [24] 2513 	lcall	_ak820_outline_0000
      008FC0 12 40 36         [24] 2514 	lcall	_eeprom_read_byte
      008FC3 12 91 EC         [24] 2515 	lcall	_ak820_outline_0184
                                   2516 ;	quantum/dynamic_keymap.c:761: if (data[2] != 0) {
      008FC6 70 03            [24] 2517 	jnz	00440$
      008FC8 02 8F 39         [24] 2518 	ljmp	00167$
      008FCB                       2519 00440$:
                                   2520 ;	quantum/dynamic_keymap.c:763: ak820_macro_primitive = data[1] != SS_TAP_CODE;
      008FCB 12 91 9C         [24] 2521 	lcall	_ak820_outline_0092
      008FCE BF 01 03         [24] 2522 	cjne	r7,#0x01,00441$
      008FD1 D3               [12] 2523 	setb	c
      008FD2 80 01            [24] 2524 	sjmp	00442$
      008FD4                       2525 00441$:
      008FD4 C3               [12] 2526 	clr	c
      008FD5                       2527 00442$:
      008FD5 92 23            [24] 2528 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      008FD7 90 09 C8         [24] 2529 	mov	dptr,#_ak820_macro_primitive
      008FDA B3               [12] 2530 	cpl	c
      008FDB E4               [12] 2531 	clr	a
      008FDC 33               [12] 2532 	rlc	a
      008FDD F0               [24] 2533 	movx	@dptr,a
                                   2534 ;	quantum/dynamic_keymap.c:765: if (data[1] == SS_TAP_CODE) tap_code((uint8_t)data[2]);
      008FDE 12 91 9C         [24] 2535 	lcall	_ak820_outline_0092
      008FE1 BF 01 10         [24] 2536 	cjne	r7,#0x01,00122$
      008FE4 12 91 CD         [24] 2537 	lcall	_ak820_outline_0156
      008FE7 C0 06            [24] 2538 	push	ar6
      008FE9 C0 05            [24] 2539 	push	ar5
      008FEB 12 79 CA         [24] 2540 	lcall	_tap_code
      008FEE D0 05            [24] 2541 	pop	ar5
      008FF0 D0 06            [24] 2542 	pop	ar6
      008FF2 80 24            [24] 2543 	sjmp	00123$
      008FF4                       2544 00122$:
                                   2545 ;	quantum/dynamic_keymap.c:766: else if (data[1] == SS_DOWN_CODE) register_code((uint8_t)data[2]);
      008FF4 12 91 9C         [24] 2546 	lcall	_ak820_outline_0092
      008FF7 BF 02 10         [24] 2547 	cjne	r7,#0x02,00119$
      008FFA 12 91 CD         [24] 2548 	lcall	_ak820_outline_0156
      008FFD C0 06            [24] 2549 	push	ar6
      008FFF C0 05            [24] 2550 	push	ar5
      009001 12 78 C6         [24] 2551 	lcall	_register_code
      009004 D0 05            [24] 2552 	pop	ar5
      009006 D0 06            [24] 2553 	pop	ar6
      009008 80 0E            [24] 2554 	sjmp	00123$
      00900A                       2555 00119$:
                                   2556 ;	quantum/dynamic_keymap.c:767: else unregister_code((uint8_t)data[2]);
      00900A 12 91 CD         [24] 2557 	lcall	_ak820_outline_0156
      00900D C0 06            [24] 2558 	push	ar6
      00900F C0 05            [24] 2559 	push	ar5
      009011 12 79 33         [24] 2560 	lcall	_unregister_code
      009014 D0 05            [24] 2561 	pop	ar5
      009016 D0 06            [24] 2562 	pop	ar6
      009018                       2563 00123$:
                                   2564 ;	quantum/dynamic_keymap.c:769: ak820_macro_primitive = false;
      009018 12 91 D4         [24] 2565 	lcall	_ak820_outline_0168
      00901B 02 8F 39         [24] 2566 	ljmp	00167$
      00901E                       2567 00152$:
                                   2568 ;	quantum/dynamic_keymap.c:777: } else if (data[1] == VIAL_MACRO_EXT_TAP || data[1] == VIAL_MACRO_EXT_DOWN || data[1] == VIAL_MACRO_EXT_UP) {
      00901E 12 91 9C         [24] 2569 	lcall	_ak820_outline_0092
      009021 BF 05 02         [24] 2570 	cjne	r7,#0x05,00447$
      009024 80 12            [24] 2571 	sjmp	00146$
      009026                       2572 00447$:
      009026 12 91 9C         [24] 2573 	lcall	_ak820_outline_0092
      009029 BF 06 02         [24] 2574 	cjne	r7,#0x06,00448$
      00902C 80 0A            [24] 2575 	sjmp	00146$
      00902E                       2576 00448$:
      00902E 12 91 9C         [24] 2577 	lcall	_ak820_outline_0092
      009031 BF 07 02         [24] 2578 	cjne	r7,#0x07,00449$
      009034 80 02            [24] 2579 	sjmp	00450$
      009036                       2580 00449$:
      009036 01 DE            [12] 2581 	ajmp	00147$
      009038                       2582 00450$:
      009038                       2583 00146$:
                                   2584 ;	quantum/dynamic_keymap.c:778: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      009038 12 91 64         [24] 2585 	lcall	_ak820_outline_0000
      00903B 12 40 36         [24] 2586 	lcall	_eeprom_read_byte
      00903E 12 91 EC         [24] 2587 	lcall	_ak820_outline_0184
                                   2588 ;	quantum/dynamic_keymap.c:779: if (data[2] != 0) {
      009041 70 03            [24] 2589 	jnz	00451$
      009043 02 8F 39         [24] 2590 	ljmp	00167$
      009046                       2591 00451$:
                                   2592 ;	quantum/dynamic_keymap.c:780: data[3] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      009046 12 91 64         [24] 2593 	lcall	_ak820_outline_0000
      009049 12 40 36         [24] 2594 	lcall	_eeprom_read_byte
      00904C AF 82            [24] 2595 	mov	r7, dpl
      00904E 90 0B 86         [24] 2596 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_481 + 0x0003)
      009051 EF               [12] 2597 	mov	a,r7
      009052 F0               [24] 2598 	movx	@dptr,a
                                   2599 ;	quantum/dynamic_keymap.c:781: if (data[3] != 0) {
      009053 EF               [12] 2600 	mov	a,r7
      009054 70 03            [24] 2601 	jnz	00452$
      009056 02 8F 39         [24] 2602 	ljmp	00167$
      009059                       2603 00452$:
                                   2604 ;	quantum/dynamic_keymap.c:784: kc = (uint8_t)data[2] | ((uint16_t)(uint8_t)data[3] << 8);
      009059 90 0B 85         [24] 2605 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_481 + 0x0002)
      00905C E0               [24] 2606 	movx	a,@dptr
      00905D FF               [12] 2607 	mov	r7,a
      00905E 90 0B 86         [24] 2608 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_481 + 0x0003)
      009061 E0               [24] 2609 	movx	a,@dptr
      009062 FB               [12] 2610 	mov	r3,a
      009063 E4               [12] 2611 	clr	a
      009064 FC               [12] 2612 	mov	r4,a
      009065 FA               [12] 2613 	mov	r2,a
      009066 EF               [12] 2614 	mov	a,r7
      009067 42 04            [12] 2615 	orl	ar4,a
      009069 EA               [12] 2616 	mov	a,r2
      00906A 42 03            [12] 2617 	orl	ar3,a
                                   2618 ;	quantum/dynamic_keymap.c:788: kc = decode_keycode(kc);
      00906C 12 43 57         [24] 2619 	lcall	_ak820_outline_0185
      00906F C0 06            [24] 2620 	push	ar6
      009071 C0 05            [24] 2621 	push	ar5
      009073 12 8E 86         [24] 2622 	lcall	_decode_keycode
      009076 AC 82            [24] 2623 	mov	r4, dpl
      009078 AF 83            [24] 2624 	mov	r7, dph
      00907A D0 05            [24] 2625 	pop	ar5
      00907C D0 06            [24] 2626 	pop	ar6
                                   2627 ;	quantum/dynamic_keymap.c:790: ak820_macro_primitive = data[1] != VIAL_MACRO_EXT_TAP;
      00907E 90 0B 84         [24] 2628 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_481 + 0x0001)
      009081 E0               [24] 2629 	movx	a,@dptr
      009082 FB               [12] 2630 	mov	r3,a
      009083 BB 05 03         [24] 2631 	cjne	r3,#0x05,00453$
      009086 D3               [12] 2632 	setb	c
      009087 80 01            [24] 2633 	sjmp	00454$
      009089                       2634 00453$:
      009089 C3               [12] 2635 	clr	c
      00908A                       2636 00454$:
      00908A 92 23            [24] 2637 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      00908C 90 09 C8         [24] 2638 	mov	dptr,#_ak820_macro_primitive
      00908F B3               [12] 2639 	cpl	c
      009090 E4               [12] 2640 	clr	a
      009091 33               [12] 2641 	rlc	a
      009092 F0               [24] 2642 	movx	@dptr,a
                                   2643 ;	quantum/dynamic_keymap.c:792: switch (data[1]) {
      009093 90 0B 84         [24] 2644 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_481 + 0x0001)
      009096 E0               [24] 2645 	movx	a,@dptr
      009097 FB               [12] 2646 	mov	r3,a
      009098 BB 05 02         [24] 2647 	cjne	r3,#0x05,00455$
      00909B 80 0A            [24] 2648 	sjmp	00126$
      00909D                       2649 00455$:
      00909D BB 06 02         [24] 2650 	cjne	r3,#0x06,00456$
      0090A0 80 16            [24] 2651 	sjmp	00127$
      0090A2                       2652 00456$:
                                   2653 ;	quantum/dynamic_keymap.c:793: case VIAL_MACRO_EXT_TAP:
      0090A2 BB 07 33         [24] 2654 	cjne	r3,#0x07,00129$
      0090A5 80 22            [24] 2655 	sjmp	00128$
      0090A7                       2656 00126$:
                                   2657 ;	quantum/dynamic_keymap.c:794: vial_keycode_tap(kc);
      0090A7 8C 82            [24] 2658 	mov	dpl, r4
      0090A9 8F 83            [24] 2659 	mov	dph, r7
      0090AB C0 06            [24] 2660 	push	ar6
      0090AD C0 05            [24] 2661 	push	ar5
      0090AF 12 B4 FB         [24] 2662 	lcall	_vial_keycode_tap
      0090B2 D0 05            [24] 2663 	pop	ar5
      0090B4 D0 06            [24] 2664 	pop	ar6
                                   2665 ;	quantum/dynamic_keymap.c:795: break;
                                   2666 ;	quantum/dynamic_keymap.c:796: case VIAL_MACRO_EXT_DOWN:
      0090B6 80 20            [24] 2667 	sjmp	00129$
      0090B8                       2668 00127$:
                                   2669 ;	quantum/dynamic_keymap.c:797: vial_keycode_down(kc);
      0090B8 8C 82            [24] 2670 	mov	dpl, r4
      0090BA 8F 83            [24] 2671 	mov	dph, r7
      0090BC C0 06            [24] 2672 	push	ar6
      0090BE C0 05            [24] 2673 	push	ar5
      0090C0 12 B4 30         [24] 2674 	lcall	_vial_keycode_down
      0090C3 D0 05            [24] 2675 	pop	ar5
      0090C5 D0 06            [24] 2676 	pop	ar6
                                   2677 ;	quantum/dynamic_keymap.c:798: break;
                                   2678 ;	quantum/dynamic_keymap.c:799: case VIAL_MACRO_EXT_UP:
      0090C7 80 0F            [24] 2679 	sjmp	00129$
      0090C9                       2680 00128$:
                                   2681 ;	quantum/dynamic_keymap.c:800: vial_keycode_up(kc);
      0090C9 8C 82            [24] 2682 	mov	dpl, r4
      0090CB 8F 83            [24] 2683 	mov	dph, r7
      0090CD C0 06            [24] 2684 	push	ar6
      0090CF C0 05            [24] 2685 	push	ar5
      0090D1 12 B4 96         [24] 2686 	lcall	_vial_keycode_up
      0090D4 D0 05            [24] 2687 	pop	ar5
      0090D6 D0 06            [24] 2688 	pop	ar6
                                   2689 ;	quantum/dynamic_keymap.c:802: }
      0090D8                       2690 00129$:
                                   2691 ;	quantum/dynamic_keymap.c:804: ak820_macro_primitive = false;
      0090D8 12 91 D4         [24] 2692 	lcall	_ak820_outline_0168
      0090DB 02 8F 39         [24] 2693 	ljmp	00167$
      0090DE                       2694 00147$:
                                   2695 ;	quantum/dynamic_keymap.c:808: } else if (data[1] == SS_DELAY_CODE) {
      0090DE 12 91 9C         [24] 2696 	lcall	_ak820_outline_0092
      0090E1 BF 04 02         [24] 2697 	cjne	r7,#0x04,00458$
      0090E4 80 03            [24] 2698 	sjmp	00459$
      0090E6                       2699 00458$:
      0090E6 02 8F 39         [24] 2700 	ljmp	00167$
      0090E9                       2701 00459$:
                                   2702 ;	quantum/dynamic_keymap.c:810: uint8_t d0 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      0090E9 12 91 64         [24] 2703 	lcall	_ak820_outline_0000
      0090EC 12 40 36         [24] 2704 	lcall	_eeprom_read_byte
      0090EF AF 82            [24] 2705 	mov	r7, dpl
                                   2706 ;	quantum/dynamic_keymap.c:811: uint8_t d1 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      0090F1 90 0B 81         [24] 2707 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_474
      0090F4 12 38 4C         [24] 2708 	lcall	_ak820_outline_0105
      0090F7 90 0B 81         [24] 2709 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_474
      0090FA 74 01            [12] 2710 	mov	a,#0x01
      0090FC 2B               [12] 2711 	add	a, r3
      0090FD F0               [24] 2712 	movx	@dptr,a
      0090FE E4               [12] 2713 	clr	a
      0090FF 3C               [12] 2714 	addc	a, r4
      009100 A3               [24] 2715 	inc	dptr
      009101 F0               [24] 2716 	movx	@dptr,a
      009102 7A 00            [12] 2717 	mov	r2,#0x00
      009104 12 33 FC         [24] 2718 	lcall	_ak820_outline_0126
      009107 8A F0            [24] 2719 	mov	b, r2
      009109 12 40 36         [24] 2720 	lcall	_eeprom_read_byte
      00910C AC 82            [24] 2721 	mov	r4, dpl
                                   2722 ;	quantum/dynamic_keymap.c:812: if (d0 == 0 || d1 == 0)
      00910E EF               [12] 2723 	mov	a,r7
      00910F 60 4B            [24] 2724 	jz	00169$
      009111 EC               [12] 2725 	mov	a,r4
      009112 60 48            [24] 2726 	jz	00169$
                                   2727 ;	quantum/dynamic_keymap.c:815: uint16_t ms = (uint16_t)(d0 - 1) + (uint16_t)(d1 - 1) * 255u;
      009114 1F               [12] 2728 	dec	r7
      009115 1C               [12] 2729 	dec	r4
      009116 EC               [12] 2730 	mov	a,r4
      009117 75 F0 FF         [24] 2731 	mov	b,#0xff
      00911A A4               [48] 2732 	mul	ab
      00911B FC               [12] 2733 	mov	r4,a
      00911C AB F0            [24] 2734 	mov	r3,b
      00911E 7A 00            [12] 2735 	mov	r2,#0x00
      009120 EC               [12] 2736 	mov	a,r4
      009121 2F               [12] 2737 	add	a, r7
      009122 FC               [12] 2738 	mov	r4,a
      009123 EB               [12] 2739 	mov	a,r3
      009124 3A               [12] 2740 	addc	a, r2
      009125 FB               [12] 2741 	mov	r3,a
                                   2742 ;	quantum/dynamic_keymap.c:816: while (ms--) wait_ms(1);
      009126                       2743 00141$:
      009126 8C 02            [24] 2744 	mov	ar2,r4
      009128 8B 07            [24] 2745 	mov	ar7,r3
      00912A 1C               [12] 2746 	dec	r4
      00912B BC FF 01         [24] 2747 	cjne	r4,#0xff,00462$
      00912E 1B               [12] 2748 	dec	r3
      00912F                       2749 00462$:
      00912F EA               [12] 2750 	mov	a,r2
      009130 4F               [12] 2751 	orl	a,r7
      009131 70 03            [24] 2752 	jnz	00463$
      009133 02 8F 39         [24] 2753 	ljmp	00167$
      009136                       2754 00463$:
      009136 90 00 01         [24] 2755 	mov	dptr,#0x0001
      009139 12 5C F8         [24] 2756 	lcall	_mDelaymS
      00913C 80 E8            [24] 2757 	sjmp	00141$
      00913E                       2758 00164$:
                                   2759 ;	quantum/dynamic_keymap.c:822: if ((uint8_t)data[0] >= 128) break;
      00913E 90 0B 83         [24] 2760 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_481
      009141 E0               [24] 2761 	movx	a,@dptr
      009142 FF               [12] 2762 	mov	r7,a
      009143 BF 80 00         [24] 2763 	cjne	r7,#0x80,00464$
      009146                       2764 00464$:
      009146 50 14            [24] 2765 	jnc	00169$
                                   2766 ;	quantum/dynamic_keymap.c:826: send_char(data[0]);
      009148 90 0B 83         [24] 2767 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_481
      00914B E0               [24] 2768 	movx	a,@dptr
      00914C F5 82            [12] 2769 	mov	dpl,a
      00914E C0 06            [24] 2770 	push	ar6
      009150 C0 05            [24] 2771 	push	ar5
      009152 12 A7 24         [24] 2772 	lcall	_send_char
      009155 D0 05            [24] 2773 	pop	ar5
      009157 D0 06            [24] 2774 	pop	ar6
                                   2775 ;	quantum/dynamic_keymap.c:827: for (uint8_t delay = DYNAMIC_KEYMAP_MACRO_DELAY; delay; --delay) wait_ms(1);
      009159 02 8F 39         [24] 2776 	ljmp	00167$
      00915C                       2777 00169$:
                                   2778 ;	quantum/dynamic_keymap.c:835: ak820_macro_primitive = false;
      00915C 12 91 D4         [24] 2779 	lcall	_ak820_outline_0168
                                   2780 ;	quantum/dynamic_keymap.c:837: sending = false;
      00915F 90 0B 80         [24] 2781 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_469
      009162 F0               [24] 2782 	movx	@dptr,a
                                   2783 ;	quantum/dynamic_keymap.c:839: }
      009163 22               [24] 2784 	ret
                                   2785 	.area CSEG    (CODE)
                                   2786 	.area CONST   (CODE)
                                   2787 	.area XINIT   (CODE)
                                   2788 	.area CABS    (ABS,CODE)
                                   2789 
                                   2790 ; Experimental exact instruction outlining.
                                   2791 	.globl _ak820_outline_0000
                                   2792 	.globl _ak820_outline_0004
                                   2793 	.globl _ak820_outline_0010
                                   2794 	.globl _ak820_outline_0013
                                   2795 	.globl _ak820_outline_0017
                                   2796 	.globl _ak820_outline_0026
                                   2797 	.globl _ak820_outline_0045
                                   2798 	.globl _ak820_outline_0051
                                   2799 	.globl _ak820_outline_0059
                                   2800 	.globl _ak820_outline_0060
                                   2801 	.globl _ak820_outline_0061
                                   2802 	.globl _ak820_outline_0072
                                   2803 	.globl _ak820_outline_0076
                                   2804 	.globl _ak820_outline_0080
                                   2805 	.globl _ak820_outline_0084
                                   2806 	.globl _ak820_outline_0085
                                   2807 	.globl _ak820_outline_0086
                                   2808 	.globl _ak820_outline_0092
                                   2809 	.globl _ak820_outline_0099
                                   2810 	.globl _ak820_outline_0104
                                   2811 	.globl _ak820_outline_0105
                                   2812 	.globl _ak820_outline_0106
                                   2813 	.globl _ak820_outline_0107
                                   2814 	.globl _ak820_outline_0119
                                   2815 	.globl _ak820_outline_0121
                                   2816 	.globl _ak820_outline_0125
                                   2817 	.globl _ak820_outline_0126
                                   2818 	.globl _ak820_outline_0127
                                   2819 	.globl _ak820_outline_0131
                                   2820 	.globl _ak820_outline_0135
                                   2821 	.globl _ak820_outline_0136
                                   2822 	.globl _ak820_outline_0137
                                   2823 	.globl _ak820_outline_0138
                                   2824 	.globl _ak820_outline_0139
                                   2825 	.globl _ak820_outline_0144
                                   2826 	.globl _ak820_outline_0147
                                   2827 	.globl _ak820_outline_0148
                                   2828 	.globl _ak820_outline_0149
                                   2829 	.globl _ak820_outline_0154
                                   2830 	.globl _ak820_outline_0156
                                   2831 	.globl _ak820_outline_0163
                                   2832 	.globl _ak820_outline_0165
                                   2833 	.globl _ak820_outline_0168
                                   2834 	.globl _ak820_outline_0173
                                   2835 	.globl _ak820_outline_0180
                                   2836 	.globl _ak820_outline_0181
                                   2837 	.globl _ak820_outline_0184
                                   2838 	.globl _ak820_outline_0185
                                   2839 	.globl _ak820_outline_0192
                                   2840 
                                   2841 	.area CSEG (CODE)
                                   2842 ; function ak820_outline_0000
      009164                       2843 _ak820_outline_0000:
      009164 90 0B 81         [24] 2844 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_474
      009167 E0               [24] 2845 	movx	a,@dptr
      009168 FC               [12] 2846 	mov	r4,a
      009169 A3               [24] 2847 	inc	dptr
      00916A E0               [24] 2848 	movx	a,@dptr
      00916B FF               [12] 2849 	mov	r7,a
      00916C 90 0B 81         [24] 2850 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_474
      00916F 74 01            [12] 2851 	mov	a,#0x01
      009171 2C               [12] 2852 	add	a,r4
      009172 F0               [24] 2853 	movx	@dptr,a
      009173 E4               [12] 2854 	clr	a
      009174 3F               [12] 2855 	addc	a,r7
      009175 A3               [24] 2856 	inc	dptr
      009176 F0               [24] 2857 	movx	@dptr,a
      009177 7B 00            [12] 2858 	mov	r3,#0x00
      009179 8C 82            [24] 2859 	mov	dpl,r4
      00917B 8F 83            [24] 2860 	mov	dph,r7
      00917D 8B F0            [24] 2861 	mov	b,r3
      00917F 22               [24] 2862 	ret
                                   2863 
                                   2864 	.area CSEG (CODE)
                                   2865 ; function ak820_outline_0026
      009180                       2866 _ak820_outline_0026:
      009180 2D               [12] 2867 	add	a,r5
      009181 F9               [12] 2868 	mov	r1,a
      009182 E4               [12] 2869 	clr	a
      009183 3E               [12] 2870 	addc	a,r6
      009184 FA               [12] 2871 	mov	r2,a
      009185 8F 03            [24] 2872 	mov	ar3,r7
      009187 89 82            [24] 2873 	mov	dpl,r1
      009189 8A 83            [24] 2874 	mov	dph,r2
      00918B 8B F0            [24] 2875 	mov	b,r3
      00918D 22               [24] 2876 	ret
                                   2877 
                                   2878 	.area CSEG (CODE)
                                   2879 ; function ak820_outline_0080
      00918E                       2880 _ak820_outline_0080:
      00918E ED               [12] 2881 	mov	a,r5
      00918F 75 F0 0A         [24] 2882 	mov	b,#0x0a
      009192 A4               [48] 2883 	mul	ab
      009193 24 58            [12] 2884 	add	a,#0x58
      009195 FC               [12] 2885 	mov	r4,a
      009196 74 06            [12] 2886 	mov	a,#0x06
      009198 35 F0            [12] 2887 	addc	a,b
      00919A FD               [12] 2888 	mov	r5,a
      00919B 22               [24] 2889 	ret
                                   2890 
                                   2891 	.area CSEG (CODE)
                                   2892 ; function ak820_outline_0092
      00919C                       2893 _ak820_outline_0092:
      00919C 90 0B 84         [24] 2894 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_481+0x0001)
      00919F E0               [24] 2895 	movx	a,@dptr
      0091A0 FF               [12] 2896 	mov	r7,a
      0091A1 22               [24] 2897 	ret
                                   2898 
                                   2899 	.area CSEG (CODE)
                                   2900 ; function ak820_outline_0099
      0091A2                       2901 _ak820_outline_0099:
      0091A2 90 0B 1A         [24] 2902 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      0091A5 EE               [12] 2903 	mov	a,r6
      0091A6 F0               [24] 2904 	movx	@dptr,a
      0091A7 90 0B 1B         [24] 2905 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      0091AA ED               [12] 2906 	mov	a,r5
      0091AB F0               [24] 2907 	movx	@dptr,a
      0091AC 8F 82            [24] 2908 	mov	dpl,r7
      0091AE 22               [24] 2909 	ret
                                   2910 
                                   2911 	.area CSEG (CODE)
                                   2912 ; function ak820_outline_0119
      0091AF                       2913 _ak820_outline_0119:
      0091AF AD 82            [24] 2914 	mov	r5,dpl
      0091B1 AE 83            [24] 2915 	mov	r6,dph
      0091B3 AF F0            [24] 2916 	mov	r7,b
      0091B5 22               [24] 2917 	ret
                                   2918 
                                   2919 	.area CSEG (CODE)
                                   2920 ; function ak820_outline_0131
      0091B6                       2921 _ak820_outline_0131:
      0091B6 28               [12] 2922 	add	a,r0
      0091B7 F5 82            [12] 2923 	mov	dpl,a
      0091B9 EF               [12] 2924 	mov	a,r7
      0091BA 39               [12] 2925 	addc	a,r1
      0091BB F5 83            [12] 2926 	mov	dph,a
      0091BD 74 FF            [12] 2927 	mov	a,#0xff
      0091BF F0               [24] 2928 	movx	@dptr,a
      0091C0 22               [24] 2929 	ret
                                   2930 
                                   2931 	.area CSEG (CODE)
                                   2932 ; function ak820_outline_0137
      0091C1                       2933 _ak820_outline_0137:
      0091C1 2D               [12] 2934 	add	a,r5
      0091C2 F9               [12] 2935 	mov	r1,a
      0091C3 E4               [12] 2936 	clr	a
      0091C4 3E               [12] 2937 	addc	a,r6
      0091C5 FA               [12] 2938 	mov	r2,a
      0091C6 22               [24] 2939 	ret
                                   2940 
                                   2941 	.area CSEG (CODE)
                                   2942 ; function ak820_outline_0144
      0091C7                       2943 _ak820_outline_0144:
      0091C7 F0               [24] 2944 	movx	@dptr,a
      0091C8 89 82            [24] 2945 	mov	dpl,r1
      0091CA 8A 83            [24] 2946 	mov	dph,r2
      0091CC 22               [24] 2947 	ret
                                   2948 
                                   2949 	.area CSEG (CODE)
                                   2950 ; function ak820_outline_0156
      0091CD                       2951 _ak820_outline_0156:
      0091CD 90 0B 85         [24] 2952 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_481+0x0002)
      0091D0 E0               [24] 2953 	movx	a,@dptr
      0091D1 F5 82            [12] 2954 	mov	dpl,a
      0091D3 22               [24] 2955 	ret
                                   2956 
                                   2957 	.area CSEG (CODE)
                                   2958 ; function ak820_outline_0168
      0091D4                       2959 _ak820_outline_0168:
      0091D4 90 09 C8         [24] 2960 	mov	dptr,#_ak820_macro_primitive
      0091D7 E4               [12] 2961 	clr	a
      0091D8 F0               [24] 2962 	movx	@dptr,a
      0091D9 22               [24] 2963 	ret
                                   2964 
                                   2965 	.area CSEG (CODE)
                                   2966 ; function ak820_outline_0180
      0091DA                       2967 _ak820_outline_0180:
      0091DA 90 0B 2A         [24] 2968 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      0091DD E4               [12] 2969 	clr	a
      0091DE F0               [24] 2970 	movx	@dptr,a
      0091DF 90 0B 2B         [24] 2971 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      0091E2 22               [24] 2972 	ret
                                   2973 
                                   2974 	.area CSEG (CODE)
                                   2975 ; function ak820_outline_0181
      0091E3                       2976 _ak820_outline_0181:
      0091E3 90 0B E0         [24] 2977 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_2
      0091E6 E4               [12] 2978 	clr	a
      0091E7 F0               [24] 2979 	movx	@dptr,a
      0091E8 90 0B E1         [24] 2980 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_3
      0091EB 22               [24] 2981 	ret
                                   2982 
                                   2983 	.area CSEG (CODE)
                                   2984 ; function ak820_outline_0184
      0091EC                       2985 _ak820_outline_0184:
      0091EC AF 82            [24] 2986 	mov	r7,dpl
      0091EE 90 0B 85         [24] 2987 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_481+0x0002)
      0091F1 EF               [12] 2988 	mov	a,r7
      0091F2 F0               [24] 2989 	movx	@dptr,a
      0091F3 EF               [12] 2990 	mov	a,r7
      0091F4 22               [24] 2991 	ret
