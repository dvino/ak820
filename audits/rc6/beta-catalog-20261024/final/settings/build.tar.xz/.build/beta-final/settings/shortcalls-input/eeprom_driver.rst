                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module eeprom_driver
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_eeprom_write_block_xdata
                                     12 	.globl _ak820_eeprom_read_block_xdata
                                     13 	.globl _eeprom_read_byte
                                     14 	.globl _eeprom_update_dword_PARM_2
                                     15 	.globl _eeprom_update_word_PARM_2
                                     16 	.globl _eeprom_update_byte_PARM_2
                                     17 	.globl _eeprom_write_dword_PARM_2
                                     18 	.globl _eeprom_write_word_PARM_2
                                     19 	.globl _eeprom_write_byte_PARM_2
                                     20 	.globl _eeprom_read_word
                                     21 	.globl _eeprom_read_dword
                                     22 	.globl _eeprom_write_byte
                                     23 	.globl _eeprom_write_word
                                     24 	.globl _eeprom_write_dword
                                     25 	.globl _eeprom_update_byte
                                     26 	.globl _eeprom_update_word
                                     27 	.globl _eeprom_update_dword
                                     28 ;--------------------------------------------------------
                                     29 ; special function registers
                                     30 ;--------------------------------------------------------
                                     31 	.area RSEG    (ABS,DATA)
      000000                         32 	.org 0x0000
                                     33 ;--------------------------------------------------------
                                     34 ; special function bits
                                     35 ;--------------------------------------------------------
                                     36 	.area RSEG    (ABS,DATA)
      000000                         37 	.org 0x0000
                                     38 ;--------------------------------------------------------
                                     39 ; overlayable register banks
                                     40 ;--------------------------------------------------------
                                     41 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         42 	.ds 8
                                     43 ;--------------------------------------------------------
                                     44 ; overlayable bit register bank
                                     45 ;--------------------------------------------------------
                                     46 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         47 bits:
      000026                         48 	.ds 1
                           008000    49 	b0 = bits[0]
                           008100    50 	b1 = bits[1]
                           008200    51 	b2 = bits[2]
                           008300    52 	b3 = bits[3]
                           008400    53 	b4 = bits[4]
                           008500    54 	b5 = bits[5]
                           008600    55 	b6 = bits[6]
                           008700    56 	b7 = bits[7]
                                     57 ;--------------------------------------------------------
                                     58 ; internal ram data
                                     59 ;--------------------------------------------------------
                                     60 	.area DSEG    (DATA)
                                     61 ;--------------------------------------------------------
                                     62 ; overlayable items in internal ram
                                     63 ;--------------------------------------------------------
                                     64 ;--------------------------------------------------------
                                     65 ; indirectly addressable internal ram data
                                     66 ;--------------------------------------------------------
                                     67 	.area ISEG    (DATA)
                                     68 ;--------------------------------------------------------
                                     69 ; absolute internal ram data
                                     70 ;--------------------------------------------------------
                                     71 	.area IABS    (ABS,DATA)
                                     72 	.area IABS    (ABS,DATA)
                                     73 ;--------------------------------------------------------
                                     74 ; bit data
                                     75 ;--------------------------------------------------------
                                     76 	.area BSEG    (BIT)
                                     77 ;--------------------------------------------------------
                                     78 ; paged external ram data
                                     79 ;--------------------------------------------------------
                                     80 	.area PSEG    (PAG,XDATA)
                                     81 ;--------------------------------------------------------
                                     82 ; uninitialized external ram data
                                     83 ;--------------------------------------------------------
                                     84 	.area XSEG    (XDATA)
      0006C7                         85 _eeprom_read_word_addr_10000_91:
      0006C7                         86 	.ds 3
      0006CA                         87 _eeprom_read_word_ret_10000_92:
      0006CA                         88 	.ds 2
      0006CC                         89 _eeprom_read_dword_addr_10000_93:
      0006CC                         90 	.ds 3
      0006CF                         91 _eeprom_read_dword_ret_10000_94:
      0006CF                         92 	.ds 4
      0006D3                         93 _eeprom_write_byte_PARM_2:
      0006D3                         94 	.ds 1
      0006D4                         95 _eeprom_write_byte_addr_10000_95:
      0006D4                         96 	.ds 3
      0006D7                         97 _eeprom_write_word_PARM_2:
      0006D7                         98 	.ds 2
      0006D9                         99 _eeprom_write_word_addr_10000_97:
      0006D9                        100 	.ds 3
      0006DC                        101 _eeprom_write_dword_PARM_2:
      0006DC                        102 	.ds 4
      0006E0                        103 _eeprom_write_dword_addr_10000_99:
      0006E0                        104 	.ds 3
      0006E3                        105 _eeprom_update_byte_PARM_2:
      0006E3                        106 	.ds 1
      0006E4                        107 _eeprom_update_byte_addr_10000_107:
      0006E4                        108 	.ds 3
      0006E7                        109 _eeprom_update_word_PARM_2:
      0006E7                        110 	.ds 2
      0006E9                        111 _eeprom_update_word_addr_10000_111:
      0006E9                        112 	.ds 3
      0006EC                        113 _eeprom_update_dword_PARM_2:
      0006EC                        114 	.ds 4
      0006F0                        115 _eeprom_update_dword_addr_10000_115:
      0006F0                        116 	.ds 3
                                    117 ;--------------------------------------------------------
                                    118 ; absolute external ram data
                                    119 ;--------------------------------------------------------
                                    120 	.area XABS    (ABS,XDATA)
                                    121 ;--------------------------------------------------------
                                    122 ; initialized external ram data
                                    123 ;--------------------------------------------------------
                                    124 	.area XISEG   (XDATA)
                                    125 	.area HOME    (CODE)
                                    126 	.area GSINIT0 (CODE)
                                    127 	.area GSINIT1 (CODE)
                                    128 	.area GSINIT2 (CODE)
                                    129 	.area GSINIT3 (CODE)
                                    130 	.area GSINIT4 (CODE)
                                    131 	.area GSINIT5 (CODE)
                                    132 	.area GSINIT  (CODE)
                                    133 	.area GSFINAL (CODE)
                                    134 	.area CSEG    (CODE)
                                    135 ;--------------------------------------------------------
                                    136 ; global & static initialisations
                                    137 ;--------------------------------------------------------
                                    138 	.area HOME    (CODE)
                                    139 	.area GSINIT  (CODE)
                                    140 	.area GSFINAL (CODE)
                                    141 	.area GSINIT  (CODE)
                                    142 ;--------------------------------------------------------
                                    143 ; Home
                                    144 ;--------------------------------------------------------
                                    145 	.area HOME    (CODE)
                                    146 	.area HOME    (CODE)
                                    147 ;--------------------------------------------------------
                                    148 ; code
                                    149 ;--------------------------------------------------------
                                    150 	.area CSEG    (CODE)
                                    151 ;------------------------------------------------------------
                                    152 ;Allocation info for local variables in function 'eeprom_read_word'
                                    153 ;------------------------------------------------------------
                                    154 ;addr          Allocated with name '_eeprom_read_word_addr_10000_91'
                                    155 ;ret           Allocated with name '_eeprom_read_word_ret_10000_92'
                                    156 ;------------------------------------------------------------
                                    157 ;	drivers/eeprom/eeprom_driver.c:44: uint16_t eeprom_read_word(const uint16_t *addr) {
                                    158 ;	-----------------------------------------
                                    159 ;	 function eeprom_read_word
                                    160 ;	-----------------------------------------
      0051AA                        161 _eeprom_read_word:
                           000007   162 	ar7 = 0x07
                           000006   163 	ar6 = 0x06
                           000005   164 	ar5 = 0x05
                           000004   165 	ar4 = 0x04
                           000003   166 	ar3 = 0x03
                           000002   167 	ar2 = 0x02
                           000001   168 	ar1 = 0x01
                           000000   169 	ar0 = 0x00
      0051AA 12 42 DE         [24]  170 	lcall	_ak820_outline_0037
      0051AD 90 06 C7         [24]  171 	mov	dptr,#_eeprom_read_word_addr_10000_91
      0051B0 12 37 ED         [24]  172 	lcall	_ak820_outline_0016
                                    173 ;	drivers/eeprom/eeprom_driver.c:45: uint16_t ret = 0;
      0051B3 90 06 CA         [24]  174 	mov	dptr,#_eeprom_read_word_ret_10000_92
      0051B6 12 53 AE         [24]  175 	lcall	_ak820_outline_0173
                                    176 ;	drivers/eeprom/eeprom_driver.c:46: EEPROM_LOCAL_READ(&ret, addr, 2);
      0051B9 90 06 C7         [24]  177 	mov	dptr,#_eeprom_read_word_addr_10000_91
      0051BC 12 53 66         [24]  178 	lcall	_ak820_outline_0023
      0051BF 90 05 81         [24]  179 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      0051C2 ED               [12]  180 	mov	a,r5
      0051C3 12 37 ED         [24]  181 	lcall	_ak820_outline_0016
      0051C6 90 05 84         [24]  182 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      0051C9 12 53 A1         [24]  183 	lcall	_ak820_outline_0114
      0051CC 90 06 CA         [24]  184 	mov	dptr,#_eeprom_read_word_ret_10000_92
      0051CF 12 40 7A         [24]  185 	lcall	_ak820_eeprom_read_block_xdata
                                    186 ;	drivers/eeprom/eeprom_driver.c:47: return ret;
      0051D2 90 06 CA         [24]  187 	mov	dptr,#_eeprom_read_word_ret_10000_92
      0051D5 12 53 98         [24]  188 	lcall	_ak820_outline_0091
                                    189 ;	drivers/eeprom/eeprom_driver.c:48: }
      0051D8 22               [24]  190 	ret
                                    191 ;------------------------------------------------------------
                                    192 ;Allocation info for local variables in function 'eeprom_read_dword'
                                    193 ;------------------------------------------------------------
                                    194 ;addr          Allocated with name '_eeprom_read_dword_addr_10000_93'
                                    195 ;ret           Allocated with name '_eeprom_read_dword_ret_10000_94'
                                    196 ;------------------------------------------------------------
                                    197 ;	drivers/eeprom/eeprom_driver.c:50: uint32_t eeprom_read_dword(const uint32_t *addr) {
                                    198 ;	-----------------------------------------
                                    199 ;	 function eeprom_read_dword
                                    200 ;	-----------------------------------------
      0051D9                        201 _eeprom_read_dword:
      0051D9 12 42 DE         [24]  202 	lcall	_ak820_outline_0037
      0051DC 90 06 CC         [24]  203 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      0051DF 12 37 ED         [24]  204 	lcall	_ak820_outline_0016
                                    205 ;	drivers/eeprom/eeprom_driver.c:51: uint32_t ret = 0;
      0051E2 90 06 CF         [24]  206 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      0051E5 12 53 76         [24]  207 	lcall	_ak820_outline_0049
                                    208 ;	drivers/eeprom/eeprom_driver.c:52: EEPROM_LOCAL_READ(&ret, addr, 4);
      0051E8 90 06 CC         [24]  209 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      0051EB 12 53 66         [24]  210 	lcall	_ak820_outline_0023
      0051EE 90 05 81         [24]  211 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      0051F1 ED               [12]  212 	mov	a,r5
      0051F2 12 37 ED         [24]  213 	lcall	_ak820_outline_0016
      0051F5 90 05 84         [24]  214 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      0051F8 74 04            [12]  215 	mov	a,#0x04
      0051FA 12 38 6A         [24]  216 	lcall	_ak820_outline_0127
      0051FD 90 06 CF         [24]  217 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      005200 12 40 7A         [24]  218 	lcall	_ak820_eeprom_read_block_xdata
                                    219 ;	drivers/eeprom/eeprom_driver.c:53: return ret;
      005203 90 06 CF         [24]  220 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      005206 12 53 7F         [24]  221 	lcall	_ak820_outline_0054
                                    222 ;	drivers/eeprom/eeprom_driver.c:54: }
      005209 22               [24]  223 	ret
                                    224 ;------------------------------------------------------------
                                    225 ;Allocation info for local variables in function 'eeprom_write_byte'
                                    226 ;------------------------------------------------------------
                                    227 ;value         Allocated with name '_eeprom_write_byte_PARM_2'
                                    228 ;addr          Allocated with name '_eeprom_write_byte_addr_10000_95'
                                    229 ;------------------------------------------------------------
                                    230 ;	drivers/eeprom/eeprom_driver.c:56: void eeprom_write_byte(uint8_t *addr, uint8_t value) {
                                    231 ;	-----------------------------------------
                                    232 ;	 function eeprom_write_byte
                                    233 ;	-----------------------------------------
      00520A                        234 _eeprom_write_byte:
      00520A 12 42 DE         [24]  235 	lcall	_ak820_outline_0037
      00520D 90 06 D4         [24]  236 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      005210 12 37 ED         [24]  237 	lcall	_ak820_outline_0016
                                    238 ;	drivers/eeprom/eeprom_driver.c:57: EEPROM_LOCAL_WRITE(&value, addr, 1);
      005213 90 06 D4         [24]  239 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      005216 12 53 40         [24]  240 	lcall	_ak820_outline_0002
      005219 74 01            [12]  241 	mov	a,#0x01
      00521B 12 38 6A         [24]  242 	lcall	_ak820_outline_0127
      00521E 90 06 D3         [24]  243 	mov	dptr,#_eeprom_write_byte_PARM_2
                                    244 ;	drivers/eeprom/eeprom_driver.c:58: }
      005221 02 41 06         [24]  245 	ljmp	_ak820_eeprom_write_block_xdata
                                    246 ;------------------------------------------------------------
                                    247 ;Allocation info for local variables in function 'eeprom_write_word'
                                    248 ;------------------------------------------------------------
                                    249 ;value         Allocated with name '_eeprom_write_word_PARM_2'
                                    250 ;addr          Allocated with name '_eeprom_write_word_addr_10000_97'
                                    251 ;------------------------------------------------------------
                                    252 ;	drivers/eeprom/eeprom_driver.c:60: void eeprom_write_word(uint16_t *addr, uint16_t value) {
                                    253 ;	-----------------------------------------
                                    254 ;	 function eeprom_write_word
                                    255 ;	-----------------------------------------
      005224                        256 _eeprom_write_word:
      005224 12 42 DE         [24]  257 	lcall	_ak820_outline_0037
      005227 90 06 D9         [24]  258 	mov	dptr,#_eeprom_write_word_addr_10000_97
      00522A 12 37 ED         [24]  259 	lcall	_ak820_outline_0016
                                    260 ;	drivers/eeprom/eeprom_driver.c:61: EEPROM_LOCAL_WRITE(&value, addr, 2);
      00522D 90 06 D9         [24]  261 	mov	dptr,#_eeprom_write_word_addr_10000_97
      005230 12 53 40         [24]  262 	lcall	_ak820_outline_0002
      005233 12 53 A1         [24]  263 	lcall	_ak820_outline_0114
      005236 90 06 D7         [24]  264 	mov	dptr,#_eeprom_write_word_PARM_2
                                    265 ;	drivers/eeprom/eeprom_driver.c:62: }
      005239 02 41 06         [24]  266 	ljmp	_ak820_eeprom_write_block_xdata
                                    267 ;------------------------------------------------------------
                                    268 ;Allocation info for local variables in function 'eeprom_write_dword'
                                    269 ;------------------------------------------------------------
                                    270 ;value         Allocated with name '_eeprom_write_dword_PARM_2'
                                    271 ;addr          Allocated with name '_eeprom_write_dword_addr_10000_99'
                                    272 ;------------------------------------------------------------
                                    273 ;	drivers/eeprom/eeprom_driver.c:64: void eeprom_write_dword(uint32_t *addr, uint32_t value) {
                                    274 ;	-----------------------------------------
                                    275 ;	 function eeprom_write_dword
                                    276 ;	-----------------------------------------
      00523C                        277 _eeprom_write_dword:
      00523C 12 42 DE         [24]  278 	lcall	_ak820_outline_0037
      00523F 90 06 E0         [24]  279 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      005242 12 37 ED         [24]  280 	lcall	_ak820_outline_0016
                                    281 ;	drivers/eeprom/eeprom_driver.c:65: EEPROM_LOCAL_WRITE(&value, addr, 4);
      005245 90 06 E0         [24]  282 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      005248 12 53 40         [24]  283 	lcall	_ak820_outline_0002
      00524B 74 04            [12]  284 	mov	a,#0x04
      00524D 12 38 6A         [24]  285 	lcall	_ak820_outline_0127
      005250 90 06 DC         [24]  286 	mov	dptr,#_eeprom_write_dword_PARM_2
                                    287 ;	drivers/eeprom/eeprom_driver.c:66: }
      005253 02 41 06         [24]  288 	ljmp	_ak820_eeprom_write_block_xdata
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'eeprom_update_block'
                                    291 ;------------------------------------------------------------
                                    292 ;sloc0         Allocated with name '_eeprom_update_block_sloc0_1_0'
                                    293 ;sloc1         Allocated with name '_eeprom_update_block_sloc1_1_0'
                                    294 ;sloc2         Allocated with name '_eeprom_update_block_sloc2_1_0'
                                    295 ;sloc3         Allocated with name '_eeprom_update_block_sloc3_1_0'
                                    296 ;addr          Allocated with name '_eeprom_update_block_PARM_2'
                                    297 ;len           Allocated with name '_eeprom_update_block_PARM_3'
                                    298 ;buf           Allocated with name '_eeprom_update_block_buf_10000_101'
                                    299 ;source        Allocated with name '_eeprom_update_block_source_10000_102'
                                    300 ;target        Allocated with name '_eeprom_update_block_target_10000_102'
                                    301 ;i             Allocated with name '_eeprom_update_block_i_10000_102'
                                    302 ;------------------------------------------------------------
                                    303 ;	drivers/eeprom/eeprom_driver.c:68: void eeprom_update_block(const void *buf, void *addr, size_t len) {
                                    304 ;	-----------------------------------------
                                    305 ;	 function eeprom_update_byte
                                    306 ;	-----------------------------------------
      005256                        307 _eeprom_update_byte:
      005256 C0 07            [24]  308 	push	ar7
      005258 C0 06            [24]  309 	push	ar6
      00525A C0 05            [24]  310 	push	ar5
      00525C C0 04            [24]  311 	push	ar4
      00525E 12 42 DE         [24]  312 	lcall	_ak820_outline_0037
      005261 90 06 E4         [24]  313 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      005264 12 37 ED         [24]  314 	lcall	_ak820_outline_0016
                                    315 ;	drivers/eeprom/eeprom_driver.c:83: uint8_t orig = eeprom_read_byte(addr);
      005267 90 06 E4         [24]  316 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      00526A 12 53 57         [24]  317 	lcall	_ak820_outline_0003
      00526D 12 40 3F         [24]  318 	lcall	_eeprom_read_byte
      005270 AF 82            [24]  319 	mov	r7, dpl
                                    320 ;	drivers/eeprom/eeprom_driver.c:84: if (orig != value) {
      005272 90 06 E3         [24]  321 	mov	dptr,#_eeprom_update_byte_PARM_2
      005275 E0               [24]  322 	movx	a,@dptr
      005276 FE               [12]  323 	mov	r6,a
      005277 EF               [12]  324 	mov	a,r7
      005278 B5 06 02         [24]  325 	cjne	a,ar6,00112$
      00527B 80 36            [24]  326 	sjmp	00103$
      00527D                        327 00112$:
                                    328 ;	drivers/eeprom/eeprom_driver.c:85: eeprom_write_byte(addr, value);
      00527D 90 06 E4         [24]  329 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      005280 12 38 24         [24]  330 	lcall	_ak820_outline_0059
      005283 A3               [24]  331 	inc	dptr
      005284 E0               [24]  332 	movx	a,@dptr
      005285 FF               [12]  333 	mov	r7,a
      005286 90 06 D3         [24]  334 	mov	dptr,#_eeprom_write_byte_PARM_2
      005289 EE               [12]  335 	mov	a,r6
      00528A F0               [24]  336 	movx	@dptr,a
      00528B 12 38 65         [24]  337 	lcall	_ak820_outline_0125
      00528E 8F F0            [24]  338 	mov	b, r7
      005290 C0 07            [24]  339 	push	ar7
      005292 C0 06            [24]  340 	push	ar6
      005294 C0 05            [24]  341 	push	ar5
      005296 C0 04            [24]  342 	push	ar4
      005298 C0 03            [24]  343 	push	ar3
      00529A C0 02            [24]  344 	push	ar2
      00529C C0 01            [24]  345 	push	ar1
      00529E C0 00            [24]  346 	push	ar0
      0052A0 12 52 0A         [24]  347 	lcall	_eeprom_write_byte
      0052A3 D0 00            [24]  348 	pop	ar0
      0052A5 D0 01            [24]  349 	pop	ar1
      0052A7 D0 02            [24]  350 	pop	ar2
      0052A9 D0 03            [24]  351 	pop	ar3
      0052AB D0 04            [24]  352 	pop	ar4
      0052AD D0 05            [24]  353 	pop	ar5
      0052AF D0 06            [24]  354 	pop	ar6
      0052B1 D0 07            [24]  355 	pop	ar7
      0052B3                        356 00103$:
                                    357 ;	drivers/eeprom/eeprom_driver.c:87: }
      0052B3 D0 04            [24]  358 	pop	ar4
      0052B5 D0 05            [24]  359 	pop	ar5
      0052B7 D0 06            [24]  360 	pop	ar6
      0052B9 D0 07            [24]  361 	pop	ar7
      0052BB 22               [24]  362 	ret
                                    363 ;------------------------------------------------------------
                                    364 ;Allocation info for local variables in function 'eeprom_update_word'
                                    365 ;------------------------------------------------------------
                                    366 ;value         Allocated with name '_eeprom_update_word_PARM_2'
                                    367 ;addr          Allocated with name '_eeprom_update_word_addr_10000_111'
                                    368 ;orig          Allocated with name '_eeprom_update_word_orig_10000_112'
                                    369 ;------------------------------------------------------------
                                    370 ;	drivers/eeprom/eeprom_driver.c:89: void eeprom_update_word(uint16_t *addr, uint16_t value) {
                                    371 ;	-----------------------------------------
                                    372 ;	 function eeprom_update_word
                                    373 ;	-----------------------------------------
      0052BC                        374 _eeprom_update_word:
      0052BC 12 42 DE         [24]  375 	lcall	_ak820_outline_0037
      0052BF 90 06 E9         [24]  376 	mov	dptr,#_eeprom_update_word_addr_10000_111
      0052C2 12 37 ED         [24]  377 	lcall	_ak820_outline_0016
                                    378 ;	drivers/eeprom/eeprom_driver.c:90: uint16_t orig = eeprom_read_word(addr);
      0052C5 90 06 E9         [24]  379 	mov	dptr,#_eeprom_update_word_addr_10000_111
      0052C8 12 53 57         [24]  380 	lcall	_ak820_outline_0003
      0052CB 12 51 AA         [24]  381 	lcall	_eeprom_read_word
      0052CE 12 43 39         [24]  382 	lcall	_ak820_outline_0135
                                    383 ;	drivers/eeprom/eeprom_driver.c:91: if (orig != value) {
      0052D1 90 06 E7         [24]  384 	mov	dptr,#_eeprom_update_word_PARM_2
      0052D4 12 38 24         [24]  385 	lcall	_ak820_outline_0059
      0052D7 EE               [12]  386 	mov	a,r6
      0052D8 B5 04 05         [24]  387 	cjne	a,ar4,00112$
      0052DB EF               [12]  388 	mov	a,r7
      0052DC B5 05 01         [24]  389 	cjne	a,ar5,00112$
      0052DF 22               [24]  390 	ret
      0052E0                        391 00112$:
                                    392 ;	drivers/eeprom/eeprom_driver.c:92: eeprom_write_word(addr, value);
      0052E0 90 06 E9         [24]  393 	mov	dptr,#_eeprom_update_word_addr_10000_111
      0052E3 E0               [24]  394 	movx	a,@dptr
      0052E4 FB               [12]  395 	mov	r3,a
      0052E5 A3               [24]  396 	inc	dptr
      0052E6 12 38 05         [24]  397 	lcall	_ak820_outline_0051
      0052E9 90 06 D7         [24]  398 	mov	dptr,#_eeprom_write_word_PARM_2
      0052EC 12 38 2A         [24]  399 	lcall	_ak820_outline_0072
      0052EF 8B 82            [24]  400 	mov	dpl, r3
      0052F1 8E 83            [24]  401 	mov	dph, r6
      0052F3 8F F0            [24]  402 	mov	b, r7
                                    403 ;	drivers/eeprom/eeprom_driver.c:94: }
      0052F5 02 52 24         [24]  404 	ljmp	_eeprom_write_word
                                    405 ;------------------------------------------------------------
                                    406 ;Allocation info for local variables in function 'eeprom_update_dword'
                                    407 ;------------------------------------------------------------
                                    408 ;value         Allocated with name '_eeprom_update_dword_PARM_2'
                                    409 ;addr          Allocated with name '_eeprom_update_dword_addr_10000_115'
                                    410 ;orig          Allocated with name '_eeprom_update_dword_orig_10000_116'
                                    411 ;------------------------------------------------------------
                                    412 ;	drivers/eeprom/eeprom_driver.c:96: void eeprom_update_dword(uint32_t *addr, uint32_t value) {
                                    413 ;	-----------------------------------------
                                    414 ;	 function eeprom_update_dword
                                    415 ;	-----------------------------------------
      0052F8                        416 _eeprom_update_dword:
      0052F8 12 42 DE         [24]  417 	lcall	_ak820_outline_0037
      0052FB 90 06 F0         [24]  418 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      0052FE 12 37 ED         [24]  419 	lcall	_ak820_outline_0016
                                    420 ;	drivers/eeprom/eeprom_driver.c:97: uint32_t orig = eeprom_read_dword(addr);
      005301 90 06 F0         [24]  421 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      005304 12 53 57         [24]  422 	lcall	_ak820_outline_0003
      005307 12 51 D9         [24]  423 	lcall	_eeprom_read_dword
      00530A 12 53 90         [24]  424 	lcall	_ak820_outline_0057
                                    425 ;	drivers/eeprom/eeprom_driver.c:98: if (orig != value) {
      00530D 90 06 EC         [24]  426 	mov	dptr,#_eeprom_update_dword_PARM_2
      005310 12 38 4F         [24]  427 	lcall	_ak820_outline_0104
      005313 A3               [24]  428 	inc	dptr
      005314 12 43 0F         [24]  429 	lcall	_ak820_outline_0086
      005317 EC               [12]  430 	mov	a,r4
      005318 B5 00 0D         [24]  431 	cjne	a,ar0,00112$
      00531B ED               [12]  432 	mov	a,r5
      00531C B5 01 09         [24]  433 	cjne	a,ar1,00112$
      00531F EE               [12]  434 	mov	a,r6
      005320 B5 02 05         [24]  435 	cjne	a,ar2,00112$
      005323 EF               [12]  436 	mov	a,r7
      005324 B5 03 01         [24]  437 	cjne	a,ar3,00112$
      005327 22               [24]  438 	ret
      005328                        439 00112$:
                                    440 ;	drivers/eeprom/eeprom_driver.c:99: eeprom_write_dword(addr, value);
      005328 90 06 F0         [24]  441 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      00532B 12 53 66         [24]  442 	lcall	_ak820_outline_0023
      00532E 90 06 DC         [24]  443 	mov	dptr,#_eeprom_write_dword_PARM_2
      005331 12 53 A8         [24]  444 	lcall	_ak820_outline_0165
      005334 EA               [12]  445 	mov	a,r2
      005335 A3               [24]  446 	inc	dptr
      005336 F0               [24]  447 	movx	@dptr,a
      005337 EB               [12]  448 	mov	a,r3
      005338 A3               [24]  449 	inc	dptr
      005339 F0               [24]  450 	movx	@dptr,a
      00533A 12 53 6F         [24]  451 	lcall	_ak820_outline_0045
                                    452 ;	drivers/eeprom/eeprom_driver.c:101: }
      00533D 02 52 3C         [24]  453 	ljmp	_eeprom_write_dword
                                    454 	.area CSEG    (CODE)
                                    455 	.area CONST   (CODE)
                                    456 	.area XINIT   (CODE)
                                    457 	.area CABS    (ABS,CODE)
                                    458 
                                    459 ; Experimental exact instruction outlining.
                                    460 	.globl _ak820_outline_0002
                                    461 	.globl _ak820_outline_0003
                                    462 	.globl _ak820_outline_0016
                                    463 	.globl _ak820_outline_0023
                                    464 	.globl _ak820_outline_0037
                                    465 	.globl _ak820_outline_0045
                                    466 	.globl _ak820_outline_0049
                                    467 	.globl _ak820_outline_0051
                                    468 	.globl _ak820_outline_0054
                                    469 	.globl _ak820_outline_0057
                                    470 	.globl _ak820_outline_0059
                                    471 	.globl _ak820_outline_0072
                                    472 	.globl _ak820_outline_0086
                                    473 	.globl _ak820_outline_0091
                                    474 	.globl _ak820_outline_0104
                                    475 	.globl _ak820_outline_0114
                                    476 	.globl _ak820_outline_0125
                                    477 	.globl _ak820_outline_0127
                                    478 	.globl _ak820_outline_0135
                                    479 	.globl _ak820_outline_0165
                                    480 	.globl _ak820_outline_0173
                                    481 
                                    482 	.area CSEG (CODE)
                                    483 ; function ak820_outline_0002
      005340                        484 _ak820_outline_0002:
      005340 E0               [24]  485 	movx	a,@dptr
      005341 FD               [12]  486 	mov	r5,a
      005342 A3               [24]  487 	inc	dptr
      005343 E0               [24]  488 	movx	a,@dptr
      005344 FE               [12]  489 	mov	r6,a
      005345 A3               [24]  490 	inc	dptr
      005346 E0               [24]  491 	movx	a,@dptr
      005347 FF               [12]  492 	mov	r7,a
      005348 90 05 8A         [24]  493 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      00534B ED               [12]  494 	mov	a,r5
      00534C F0               [24]  495 	movx	@dptr,a
      00534D EE               [12]  496 	mov	a,r6
      00534E A3               [24]  497 	inc	dptr
      00534F F0               [24]  498 	movx	@dptr,a
      005350 EF               [12]  499 	mov	a,r7
      005351 A3               [24]  500 	inc	dptr
      005352 F0               [24]  501 	movx	@dptr,a
      005353 90 05 8D         [24]  502 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      005356 22               [24]  503 	ret
                                    504 
                                    505 	.area CSEG (CODE)
                                    506 ; function ak820_outline_0003
      005357                        507 _ak820_outline_0003:
      005357 E0               [24]  508 	movx	a,@dptr
      005358 FD               [12]  509 	mov	r5,a
      005359 A3               [24]  510 	inc	dptr
      00535A E0               [24]  511 	movx	a,@dptr
      00535B FE               [12]  512 	mov	r6,a
      00535C A3               [24]  513 	inc	dptr
      00535D E0               [24]  514 	movx	a,@dptr
      00535E FF               [12]  515 	mov	r7,a
      00535F 8D 82            [24]  516 	mov	dpl,r5
      005361 8E 83            [24]  517 	mov	dph,r6
      005363 8F F0            [24]  518 	mov	b,r7
      005365 22               [24]  519 	ret
                                    520 
                                    521 	.area CSEG (CODE)
                                    522 ; function ak820_outline_0023
      005366                        523 _ak820_outline_0023:
      005366 E0               [24]  524 	movx	a,@dptr
      005367 FD               [12]  525 	mov	r5,a
      005368 A3               [24]  526 	inc	dptr
      005369 E0               [24]  527 	movx	a,@dptr
      00536A FE               [12]  528 	mov	r6,a
      00536B A3               [24]  529 	inc	dptr
      00536C E0               [24]  530 	movx	a,@dptr
      00536D FF               [12]  531 	mov	r7,a
      00536E 22               [24]  532 	ret
                                    533 
                                    534 	.area CSEG (CODE)
                                    535 ; function ak820_outline_0045
      00536F                        536 _ak820_outline_0045:
      00536F 8D 82            [24]  537 	mov	dpl,r5
      005371 8E 83            [24]  538 	mov	dph,r6
      005373 8F F0            [24]  539 	mov	b,r7
      005375 22               [24]  540 	ret
                                    541 
                                    542 	.area CSEG (CODE)
                                    543 ; function ak820_outline_0049
      005376                        544 _ak820_outline_0049:
      005376 E4               [12]  545 	clr	a
      005377 F0               [24]  546 	movx	@dptr,a
      005378 A3               [24]  547 	inc	dptr
      005379 F0               [24]  548 	movx	@dptr,a
      00537A A3               [24]  549 	inc	dptr
      00537B F0               [24]  550 	movx	@dptr,a
      00537C A3               [24]  551 	inc	dptr
      00537D F0               [24]  552 	movx	@dptr,a
      00537E 22               [24]  553 	ret
                                    554 
                                    555 	.area CSEG (CODE)
                                    556 ; function ak820_outline_0054
      00537F                        557 _ak820_outline_0054:
      00537F E0               [24]  558 	movx	a,@dptr
      005380 FC               [12]  559 	mov	r4,a
      005381 A3               [24]  560 	inc	dptr
      005382 E0               [24]  561 	movx	a,@dptr
      005383 FD               [12]  562 	mov	r5,a
      005384 A3               [24]  563 	inc	dptr
      005385 E0               [24]  564 	movx	a,@dptr
      005386 FE               [12]  565 	mov	r6,a
      005387 A3               [24]  566 	inc	dptr
      005388 E0               [24]  567 	movx	a,@dptr
      005389 8C 82            [24]  568 	mov	dpl,r4
      00538B 8D 83            [24]  569 	mov	dph,r5
      00538D 8E F0            [24]  570 	mov	b,r6
      00538F 22               [24]  571 	ret
                                    572 
                                    573 	.area CSEG (CODE)
                                    574 ; function ak820_outline_0057
      005390                        575 _ak820_outline_0057:
      005390 AC 82            [24]  576 	mov	r4,dpl
      005392 AD 83            [24]  577 	mov	r5,dph
      005394 AE F0            [24]  578 	mov	r6,b
      005396 FF               [12]  579 	mov	r7,a
      005397 22               [24]  580 	ret
                                    581 
                                    582 	.area CSEG (CODE)
                                    583 ; function ak820_outline_0091
      005398                        584 _ak820_outline_0091:
      005398 E0               [24]  585 	movx	a,@dptr
      005399 FE               [12]  586 	mov	r6,a
      00539A A3               [24]  587 	inc	dptr
      00539B E0               [24]  588 	movx	a,@dptr
      00539C 8E 82            [24]  589 	mov	dpl,r6
      00539E F5 83            [12]  590 	mov	dph,a
      0053A0 22               [24]  591 	ret
                                    592 
                                    593 	.area CSEG (CODE)
                                    594 ; function ak820_outline_0114
      0053A1                        595 _ak820_outline_0114:
      0053A1 74 02            [12]  596 	mov	a,#0x02
      0053A3 F0               [24]  597 	movx	@dptr,a
      0053A4 E4               [12]  598 	clr	a
      0053A5 A3               [24]  599 	inc	dptr
      0053A6 F0               [24]  600 	movx	@dptr,a
      0053A7 22               [24]  601 	ret
                                    602 
                                    603 	.area CSEG (CODE)
                                    604 ; function ak820_outline_0165
      0053A8                        605 _ak820_outline_0165:
      0053A8 E8               [12]  606 	mov	a,r0
      0053A9 F0               [24]  607 	movx	@dptr,a
      0053AA E9               [12]  608 	mov	a,r1
      0053AB A3               [24]  609 	inc	dptr
      0053AC F0               [24]  610 	movx	@dptr,a
      0053AD 22               [24]  611 	ret
                                    612 
                                    613 	.area CSEG (CODE)
                                    614 ; function ak820_outline_0173
      0053AE                        615 _ak820_outline_0173:
      0053AE E4               [12]  616 	clr	a
      0053AF F0               [24]  617 	movx	@dptr,a
      0053B0 A3               [24]  618 	inc	dptr
      0053B1 F0               [24]  619 	movx	@dptr,a
      0053B2 22               [24]  620 	ret
