                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_settings
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _clear_keyboard
                                     12 	.globl ___memcpy
                                     13 	.globl _memcmp
                                     14 	.globl _ak820_eeprom_update_block_xdata
                                     15 	.globl _ak820_eeprom_read_block_xdata
                                     16 	.globl _ak820_nvm_end
                                     17 	.globl _ak820_nvm_begin
                                     18 	.globl _ak820_nvm_schema_fault
                                     19 	.globl _ak820_nvm_ok
                                     20 	.globl _ak820_settings_set_PARM_3
                                     21 	.globl _ak820_settings_set_PARM_2
                                     22 	.globl _ak820_settings_get_PARM_3
                                     23 	.globl _ak820_settings_get_PARM_2
                                     24 	.globl _ak820_settings_query_PARM_3
                                     25 	.globl _ak820_settings_query_PARM_2
                                     26 	.globl _ak820_settings_init
                                     27 	.globl _ak820_settings_query
                                     28 	.globl _ak820_settings_get
                                     29 	.globl _ak820_settings_set
                                     30 	.globl _ak820_settings_reset
                                     31 	.globl _ak820_settings_grave_esc
                                     32 	.globl _ak820_settings_combo_term
                                     33 	.globl _ak820_settings_tapping_term
                                     34 	.globl _ak820_settings_tap_code_delay
                                     35 	.globl _ak820_settings_caps_delay
                                     36 ;--------------------------------------------------------
                                     37 ; special function registers
                                     38 ;--------------------------------------------------------
                                     39 	.area RSEG    (ABS,DATA)
      000000                         40 	.org 0x0000
                                     41 ;--------------------------------------------------------
                                     42 ; special function bits
                                     43 ;--------------------------------------------------------
                                     44 	.area RSEG    (ABS,DATA)
      000000                         45 	.org 0x0000
                                     46 ;--------------------------------------------------------
                                     47 ; overlayable register banks
                                     48 ;--------------------------------------------------------
                                     49 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         50 	.ds 8
                                     51 ;--------------------------------------------------------
                                     52 ; internal ram data
                                     53 ;--------------------------------------------------------
                                     54 	.area DSEG    (DATA)
                                     55 ;--------------------------------------------------------
                                     56 ; overlayable items in internal ram
                                     57 ;--------------------------------------------------------
                                     58 ;--------------------------------------------------------
                                     59 ; indirectly addressable internal ram data
                                     60 ;--------------------------------------------------------
                                     61 	.area ISEG    (DATA)
                                     62 ;--------------------------------------------------------
                                     63 ; absolute internal ram data
                                     64 ;--------------------------------------------------------
                                     65 	.area IABS    (ABS,DATA)
                                     66 	.area IABS    (ABS,DATA)
                                     67 ;--------------------------------------------------------
                                     68 ; bit data
                                     69 ;--------------------------------------------------------
                                     70 	.area BSEG    (BIT)
      00000C                         71 _valid_sloc0_1_0:
      00000C                         72 	.ds 1
                                     73 ;--------------------------------------------------------
                                     74 ; paged external ram data
                                     75 ;--------------------------------------------------------
                                     76 	.area PSEG    (PAG,XDATA)
                                     77 ;--------------------------------------------------------
                                     78 ; uninitialized external ram data
                                     79 ;--------------------------------------------------------
                                     80 	.area XSEG    (XDATA)
      00059A                         81 _current:
      00059A                         82 	.ds 24
      0005B2                         83 _candidate:
      0005B2                         84 	.ds 24
      0005CA                         85 _word_p_10000_54:
      0005CA                         86 	.ds 2
      0005CC                         87 _put_word_PARM_2:
      0005CC                         88 	.ds 2
      0005CE                         89 _put_word_p_10000_56:
      0005CE                         90 	.ds 2
      0005D0                         91 _checksum_crc_10000_59:
      0005D0                         92 	.ds 2
      0005D2                         93 _valid_i_10000_69:
      0005D2                         94 	.ds 1
      0005D3                         95 _ak820_settings_init_blank_zero_10000_86:
      0005D3                         96 	.ds 1
      0005D4                         97 _ak820_settings_init_blank_erased_10000_86:
      0005D4                         98 	.ds 1
      0005D5                         99 _offset_id_10000_94:
      0005D5                        100 	.ds 1
      0005D6                        101 _ak820_settings_query_PARM_2:
      0005D6                        102 	.ds 2
      0005D8                        103 _ak820_settings_query_PARM_3:
      0005D8                        104 	.ds 1
      0005D9                        105 _ak820_settings_query_greater_than_10000_98:
      0005D9                        106 	.ds 2
      0005DB                        107 _ak820_settings_query_used_10000_99:
      0005DB                        108 	.ds 1
      0005DC                        109 _ak820_settings_get_PARM_2:
      0005DC                        110 	.ds 2
      0005DE                        111 _ak820_settings_get_PARM_3:
      0005DE                        112 	.ds 1
      0005DF                        113 _ak820_settings_get_id_10000_106:
      0005DF                        114 	.ds 2
      0005E1                        115 _ak820_settings_set_PARM_2:
      0005E1                        116 	.ds 2
      0005E3                        117 _ak820_settings_set_PARM_3:
      0005E3                        118 	.ds 1
      0005E4                        119 _ak820_settings_set_id_10000_111:
      0005E4                        120 	.ds 2
                                    121 ;--------------------------------------------------------
                                    122 ; absolute external ram data
                                    123 ;--------------------------------------------------------
                                    124 	.area XABS    (ABS,XDATA)
                                    125 ;--------------------------------------------------------
                                    126 ; initialized external ram data
                                    127 ;--------------------------------------------------------
                                    128 	.area XISEG   (XDATA)
                                    129 	.area HOME    (CODE)
                                    130 	.area GSINIT0 (CODE)
                                    131 	.area GSINIT1 (CODE)
                                    132 	.area GSINIT2 (CODE)
                                    133 	.area GSINIT3 (CODE)
                                    134 	.area GSINIT4 (CODE)
                                    135 	.area GSINIT5 (CODE)
                                    136 	.area GSINIT  (CODE)
                                    137 	.area GSFINAL (CODE)
                                    138 	.area CSEG    (CODE)
                                    139 ;--------------------------------------------------------
                                    140 ; global & static initialisations
                                    141 ;--------------------------------------------------------
                                    142 	.area HOME    (CODE)
                                    143 	.area GSINIT  (CODE)
                                    144 	.area GSFINAL (CODE)
                                    145 	.area GSINIT  (CODE)
                                    146 ;--------------------------------------------------------
                                    147 ; Home
                                    148 ;--------------------------------------------------------
                                    149 	.area HOME    (CODE)
                                    150 	.area HOME    (CODE)
                                    151 ;--------------------------------------------------------
                                    152 ; code
                                    153 ;--------------------------------------------------------
                                    154 	.area CSEG    (CODE)
                                    155 ;------------------------------------------------------------
                                    156 ;Allocation info for local variables in function 'word'
                                    157 ;------------------------------------------------------------
                                    158 ;p             Allocated with name '_word_p_10000_54'
                                    159 ;------------------------------------------------------------
                                    160 ;	keyboards/ajazz/ak820/ak820_settings.c:13: static uint16_t word(const uint8_t AK820_XDATA *p) {
                                    161 ;	-----------------------------------------
                                    162 ;	 function word
                                    163 ;	-----------------------------------------
      004366                        164 _word:
                           000007   165 	ar7 = 0x07
                           000006   166 	ar6 = 0x06
                           000005   167 	ar5 = 0x05
                           000004   168 	ar4 = 0x04
                           000003   169 	ar3 = 0x03
                           000002   170 	ar2 = 0x02
                           000001   171 	ar1 = 0x01
                           000000   172 	ar0 = 0x00
      004366 12 38 52         [24]  173 	lcall	_ak820_outline_0106
      004369 90 05 CA         [24]  174 	mov	dptr,#_word_p_10000_54
      00436C 12 38 57         [24]  175 	lcall	_ak820_outline_0107
                                    176 ;	keyboards/ajazz/ak820/ak820_settings.c:14: return (uint16_t)p[0] | ((uint16_t)p[1] << 8);
      00436F 90 05 CA         [24]  177 	mov	dptr,#_word_p_10000_54
      004372 12 37 A5         [24]  178 	lcall	_ak820_outline_0004
      004375 E0               [24]  179 	movx	a,@dptr
      004376 FD               [12]  180 	mov	r5,a
      004377 7C 00            [12]  181 	mov	r4,#0x00
      004379 12 38 27         [24]  182 	lcall	_ak820_outline_0077
      00437C FE               [12]  183 	mov	r6,a
      00437D E4               [12]  184 	clr	a
      00437E 42 05            [12]  185 	orl	ar5,a
      004380 EE               [12]  186 	mov	a,r6
      004381 42 04            [12]  187 	orl	ar4,a
      004383 12 43 5C         [24]  188 	lcall	_ak820_outline_0186
                                    189 ;	keyboards/ajazz/ak820/ak820_settings.c:15: }
      004386 22               [24]  190 	ret
                                    191 ;------------------------------------------------------------
                                    192 ;Allocation info for local variables in function 'put_word'
                                    193 ;------------------------------------------------------------
                                    194 ;v             Allocated with name '_put_word_PARM_2'
                                    195 ;p             Allocated with name '_put_word_p_10000_56'
                                    196 ;------------------------------------------------------------
                                    197 ;	keyboards/ajazz/ak820/ak820_settings.c:16: static void put_word(uint8_t AK820_XDATA *p, uint16_t v) { p[0] = v; p[1] = v >> 8; }
                                    198 ;	-----------------------------------------
                                    199 ;	 function put_word
                                    200 ;	-----------------------------------------
      004387                        201 _put_word:
      004387 12 38 52         [24]  202 	lcall	_ak820_outline_0106
      00438A 90 05 CE         [24]  203 	mov	dptr,#_put_word_p_10000_56
      00438D 12 38 57         [24]  204 	lcall	_ak820_outline_0107
      004390 90 05 CE         [24]  205 	mov	dptr,#_put_word_p_10000_56
      004393 12 37 FC         [24]  206 	lcall	_ak820_outline_0051
      004396 90 05 CC         [24]  207 	mov	dptr,#_put_word_PARM_2
      004399 12 38 1B         [24]  208 	lcall	_ak820_outline_0059
      00439C 8C 03            [24]  209 	mov	ar3,r4
      00439E 12 43 2B         [24]  210 	lcall	_ak820_outline_0121
      0043A1 EB               [12]  211 	mov	a,r3
      0043A2 12 42 F9         [24]  212 	lcall	_ak820_outline_0061
      0043A5 A3               [24]  213 	inc	dptr
      0043A6 8D 04            [24]  214 	mov	ar4,r5
      0043A8 EC               [12]  215 	mov	a,r4
      0043A9 F0               [24]  216 	movx	@dptr,a
      0043AA 22               [24]  217 	ret
                                    218 ;------------------------------------------------------------
                                    219 ;Allocation info for local variables in function 'checksum'
                                    220 ;------------------------------------------------------------
                                    221 ;crc           Allocated with name '_checksum_crc_10000_59'
                                    222 ;i             Allocated with name '_checksum_i_10000_59'
                                    223 ;bit           Allocated with name '_checksum_bit_10000_59'
                                    224 ;------------------------------------------------------------
                                    225 ;	keyboards/ajazz/ak820/ak820_settings.c:17: static uint16_t checksum(void) {
                                    226 ;	-----------------------------------------
                                    227 ;	 function checksum
                                    228 ;	-----------------------------------------
      0043AB                        229 _checksum:
                                    230 ;	keyboards/ajazz/ak820/ak820_settings.c:18: uint16_t crc = 0xFFFFu;
      0043AB 90 05 D0         [24]  231 	mov	dptr,#_checksum_crc_10000_59
      0043AE 74 FF            [12]  232 	mov	a,#0xff
      0043B0 F0               [24]  233 	movx	@dptr,a
      0043B1 A3               [24]  234 	inc	dptr
      0043B2 F0               [24]  235 	movx	@dptr,a
                                    236 ;	keyboards/ajazz/ak820/ak820_settings.c:20: for (i = 0; i < 22; ++i) {
      0043B3 7F 00            [12]  237 	mov	r7,#0x00
      0043B5                        238 00106$:
                                    239 ;	keyboards/ajazz/ak820/ak820_settings.c:21: crc ^= (uint16_t)candidate[i] << 8;
      0043B5 12 47 F8         [24]  240 	lcall	_ak820_outline_0109
      0043B8 FD               [12]  241 	mov	r5,a
      0043B9 7E 00            [12]  242 	mov	r6,#0x00
      0043BB 90 05 D0         [24]  243 	mov	dptr,#_checksum_crc_10000_59
      0043BE E0               [24]  244 	movx	a,@dptr
      0043BF 6E               [12]  245 	xrl	a,r6
      0043C0 F0               [24]  246 	movx	@dptr,a
      0043C1 A3               [24]  247 	inc	dptr
      0043C2 E0               [24]  248 	movx	a,@dptr
      0043C3 6D               [12]  249 	xrl	a,r5
      0043C4 F0               [24]  250 	movx	@dptr,a
                                    251 ;	keyboards/ajazz/ak820/ak820_settings.c:22: for (bit = 0; bit < 8; ++bit) crc = (crc & 0x8000u) ? (crc << 1) ^ 0x1021u : (uint16_t)(crc << 1);
      0043C5 7E 08            [12]  252 	mov	r6,#0x08
      0043C7                        253 00105$:
      0043C7 90 05 D0         [24]  254 	mov	dptr,#_checksum_crc_10000_59
      0043CA 12 38 1B         [24]  255 	lcall	_ak820_outline_0059
      0043CD 30 E7 0E         [24]  256 	jnb	acc.7,00110$
      0043D0 EC               [12]  257 	mov	a,r4
      0043D1 2C               [12]  258 	add	a,r4
      0043D2 FA               [12]  259 	mov	r2,a
      0043D3 ED               [12]  260 	mov	a,r5
      0043D4 33               [12]  261 	rlc	a
      0043D5 FB               [12]  262 	mov	r3,a
      0043D6 63 02 21         [24]  263 	xrl	ar2,#0x21
      0043D9 63 03 10         [24]  264 	xrl	ar3,#0x10
      0043DC 80 06            [24]  265 	sjmp	00111$
      0043DE                        266 00110$:
      0043DE EC               [12]  267 	mov	a,r4
      0043DF 2C               [12]  268 	add	a,r4
      0043E0 FA               [12]  269 	mov	r2,a
      0043E1 ED               [12]  270 	mov	a,r5
      0043E2 33               [12]  271 	rlc	a
      0043E3 FB               [12]  272 	mov	r3,a
      0043E4                        273 00111$:
      0043E4 90 05 D0         [24]  274 	mov	dptr,#_checksum_crc_10000_59
      0043E7 EA               [12]  275 	mov	a,r2
      0043E8 F0               [24]  276 	movx	@dptr,a
      0043E9 EB               [12]  277 	mov	a,r3
      0043EA A3               [24]  278 	inc	dptr
      0043EB F0               [24]  279 	movx	@dptr,a
      0043EC DE D9            [24]  280 	djnz	r6,00105$
                                    281 ;	keyboards/ajazz/ak820/ak820_settings.c:20: for (i = 0; i < 22; ++i) {
      0043EE 0F               [12]  282 	inc	r7
      0043EF BF 16 00         [24]  283 	cjne	r7,#0x16,00151$
      0043F2                        284 00151$:
      0043F2 40 C1            [24]  285 	jc	00106$
                                    286 ;	keyboards/ajazz/ak820/ak820_settings.c:24: return crc;
      0043F4 12 43 47         [24]  287 	lcall	_ak820_outline_0148
                                    288 ;	keyboards/ajazz/ak820/ak820_settings.c:25: }
      0043F7 22               [24]  289 	ret
                                    290 ;------------------------------------------------------------
                                    291 ;Allocation info for local variables in function 'seal'
                                    292 ;------------------------------------------------------------
                                    293 ;	keyboards/ajazz/ak820/ak820_settings.c:26: static void seal(void) { put_word(candidate + 22, checksum()); }
                                    294 ;	-----------------------------------------
                                    295 ;	 function seal
                                    296 ;	-----------------------------------------
      0043F8                        297 _seal:
      0043F8 12 43 AB         [24]  298 	lcall	_checksum
      0043FB 12 38 40         [24]  299 	lcall	_ak820_outline_0101
      0043FE 90 05 CC         [24]  300 	mov	dptr,#_put_word_PARM_2
      004401 12 48 0B         [24]  301 	lcall	_ak820_outline_0143
      004404 90 05 C8         [24]  302 	mov	dptr,#(_candidate + 0x0016)
      004407 02 43 87         [24]  303 	ljmp	_put_word
                                    304 ;------------------------------------------------------------
                                    305 ;Allocation info for local variables in function 'defaults'
                                    306 ;------------------------------------------------------------
                                    307 ;i             Allocated with name '_defaults_i_20000_67'
                                    308 ;------------------------------------------------------------
                                    309 ;	keyboards/ajazz/ak820/ak820_settings.c:34: static void defaults(void) {
                                    310 ;	-----------------------------------------
                                    311 ;	 function defaults
                                    312 ;	-----------------------------------------
      00440A                        313 _defaults:
                                    314 ;	keyboards/ajazz/ak820/ak820_settings.c:35: for (uint8_t i = 0; i < AK820_SETTINGS_SIZE; ++i) candidate[i] = default_record[i];
      00440A 7F 00            [12]  315 	mov	r7,#0x00
      00440C                        316 00103$:
      00440C BF 18 00         [24]  317 	cjne	r7,#0x18,00122$
      00440F                        318 00122$:
      00440F 50 13            [24]  319 	jnc	00105$
      004411 EF               [12]  320 	mov	a,r7
      004412 24 B2            [12]  321 	add	a, #_candidate
      004414 FD               [12]  322 	mov	r5,a
      004415 E4               [12]  323 	clr	a
      004416 34 05            [12]  324 	addc	a, #(_candidate >> 8)
      004418 FE               [12]  325 	mov	r6,a
      004419 EF               [12]  326 	mov	a,r7
      00441A 90 BD 65         [24]  327 	mov	dptr,#_default_record
      00441D 93               [24]  328 	movc	a,@a+dptr
      00441E 12 47 F2         [24]  329 	lcall	_ak820_outline_0102
      004421 0F               [12]  330 	inc	r7
      004422 80 E8            [24]  331 	sjmp	00103$
      004424                        332 00105$:
                                    333 ;	keyboards/ajazz/ak820/ak820_settings.c:36: }
      004424 22               [24]  334 	ret
                                    335 ;------------------------------------------------------------
                                    336 ;Allocation info for local variables in function 'valid'
                                    337 ;------------------------------------------------------------
                                    338 ;i             Allocated with name '_valid_i_10000_69'
                                    339 ;value         Allocated with name '_valid_value_10000_69'
                                    340 ;------------------------------------------------------------
                                    341 ;	keyboards/ajazz/ak820/ak820_settings.c:37: static bool valid(void) {
                                    342 ;	-----------------------------------------
                                    343 ;	 function valid
                                    344 ;	-----------------------------------------
      004425                        345 _valid:
                                    346 ;	keyboards/ajazz/ak820/ak820_settings.c:40: if (candidate[0] != 'Q' || candidate[1] != 'S' || candidate[2] != AK820_SETTINGS_VERSION || candidate[3] != 11 || candidate[4] != AK820_SETTINGS_CAPABILITIES) return false;
      004425 90 05 B2         [24]  347 	mov	dptr,#_candidate
      004428 E0               [24]  348 	movx	a,@dptr
      004429 FF               [12]  349 	mov	r7,a
      00442A BF 51 22         [24]  350 	cjne	r7,#0x51,00101$
      00442D 90 05 B3         [24]  351 	mov	dptr,#(_candidate + 0x0001)
      004430 E0               [24]  352 	movx	a,@dptr
      004431 FF               [12]  353 	mov	r7,a
      004432 BF 53 1A         [24]  354 	cjne	r7,#0x53,00101$
      004435 90 05 B4         [24]  355 	mov	dptr,#(_candidate + 0x0002)
      004438 E0               [24]  356 	movx	a,@dptr
      004439 FF               [12]  357 	mov	r7,a
      00443A BF 01 12         [24]  358 	cjne	r7,#0x01,00101$
      00443D 90 05 B5         [24]  359 	mov	dptr,#(_candidate + 0x0003)
      004440 E0               [24]  360 	movx	a,@dptr
      004441 FF               [12]  361 	mov	r7,a
      004442 BF 0B 0A         [24]  362 	cjne	r7,#0x0b,00101$
      004445 90 05 B6         [24]  363 	mov	dptr,#(_candidate + 0x0004)
      004448 E0               [24]  364 	movx	a,@dptr
      004449 FF               [12]  365 	mov	r7,a
      00444A BF 3F 02         [24]  366 	cjne	r7,#0x3f,00227$
      00444D 80 04            [24]  367 	sjmp	00102$
      00444F                        368 00227$:
      00444F                        369 00101$:
      00444F 75 82 00         [24]  370 	mov	dpl, #0x00
      004452 22               [24]  371 	ret
      004453                        372 00102$:
                                    373 ;	keyboards/ajazz/ak820/ak820_settings.c:41: if (candidate[5] & 0xF0u) return false;
      004453 90 05 B7         [24]  374 	mov	dptr,#(_candidate + 0x0005)
      004456 E0               [24]  375 	movx	a,@dptr
      004457 54 F0            [12]  376 	anl	a,#0xf0
      004459 60 04            [24]  377 	jz	00108$
      00445B 75 82 00         [24]  378 	mov	dpl, #0x00
      00445E 22               [24]  379 	ret
      00445F                        380 00108$:
                                    381 ;	keyboards/ajazz/ak820/ak820_settings.c:42: for (i = 6; i <= 14; i += 2) {
      00445F 90 05 D2         [24]  382 	mov	dptr,#_valid_i_10000_69
      004462 74 06            [12]  383 	mov	a,#0x06
      004464 F0               [24]  384 	movx	@dptr,a
      004465                        385 00122$:
                                    386 ;	keyboards/ajazz/ak820/ak820_settings.c:43: value = word(candidate + i);
      004465 90 05 D2         [24]  387 	mov	dptr,#_valid_i_10000_69
      004468 E0               [24]  388 	movx	a,@dptr
      004469 FF               [12]  389 	mov	r7,a
      00446A 12 47 DF         [24]  390 	lcall	_ak820_outline_0040
      00446D C0 07            [24]  391 	push	ar7
      00446F 12 43 66         [24]  392 	lcall	_word
      004472 12 43 61         [24]  393 	lcall	_ak820_outline_0192
      004475 D0 07            [24]  394 	pop	ar7
                                    395 ;	keyboards/ajazz/ak820/ak820_settings.c:44: if (i == 10 || i == 12) { if (value > 100) return false; }
      004477 BF 0A 02         [24]  396 	cjne	r7,#0x0a,00229$
      00447A 80 03            [24]  397 	sjmp	00114$
      00447C                        398 00229$:
      00447C BF 0C 10         [24]  399 	cjne	r7,#0x0c,00115$
      00447F                        400 00114$:
      00447F 8D 04            [24]  401 	mov	ar4,r5
      004481 8E 07            [24]  402 	mov	ar7,r6
      004483 C3               [12]  403 	clr	c
      004484 74 64            [12]  404 	mov	a,#0x64
      004486 9C               [12]  405 	subb	a,r4
      004487 E4               [12]  406 	clr	a
      004488 9F               [12]  407 	subb	a,r7
      004489 50 15            [24]  408 	jnc	00123$
                                    409 ;	free result
      00448B 75 82 00         [24]  410 	mov	dpl, #0x00
      00448E 22               [24]  411 	ret
      00448F                        412 00115$:
                                    413 ;	keyboards/ajazz/ak820/ak820_settings.c:45: else if (!value || value > 1000) return false;
      00448F ED               [12]  414 	mov	a,r5
      004490 4E               [12]  415 	orl	a,r6
      004491 60 09            [24]  416 	jz	00111$
      004493 C3               [12]  417 	clr	c
      004494 74 E8            [12]  418 	mov	a,#0xe8
      004496 9D               [12]  419 	subb	a,r5
      004497 74 03            [12]  420 	mov	a,#0x03
      004499 9E               [12]  421 	subb	a,r6
      00449A 50 04            [24]  422 	jnc	00123$
                                    423 ;	free result
      00449C                        424 00111$:
      00449C 75 82 00         [24]  425 	mov	dpl, #0x00
      00449F 22               [24]  426 	ret
      0044A0                        427 00123$:
                                    428 ;	keyboards/ajazz/ak820/ak820_settings.c:42: for (i = 6; i <= 14; i += 2) {
      0044A0 90 05 D2         [24]  429 	mov	dptr,#_valid_i_10000_69
      0044A3 E0               [24]  430 	movx	a,@dptr
      0044A4 24 02            [12]  431 	add	a,#0x02
      0044A6 F0               [24]  432 	movx	@dptr,a
      0044A7 E0               [24]  433 	movx	a,@dptr
      0044A8 24 F1            [12]  434 	add	a,#0xff - 0x0e
      0044AA 50 B9            [24]  435 	jnc	00122$
                                    436 ;	free result
                                    437 ;	keyboards/ajazz/ak820/ak820_settings.c:47: for (i = 16; i < 22; ++i) if (candidate[i]) return false;
      0044AC 7F 10            [12]  438 	mov	r7,#0x10
      0044AE                        439 00124$:
      0044AE EF               [12]  440 	mov	a,r7
      0044AF 12 47 DF         [24]  441 	lcall	_ak820_outline_0040
      0044B2 E0               [24]  442 	movx	a,@dptr
      0044B3 60 04            [24]  443 	jz	00125$
      0044B5 75 82 00         [24]  444 	mov	dpl, #0x00
      0044B8 22               [24]  445 	ret
      0044B9                        446 00125$:
      0044B9 0F               [12]  447 	inc	r7
      0044BA BF 16 00         [24]  448 	cjne	r7,#0x16,00237$
      0044BD                        449 00237$:
      0044BD 40 EF            [24]  450 	jc	00124$
                                    451 ;	keyboards/ajazz/ak820/ak820_settings.c:48: return word(candidate + 22) == checksum();
      0044BF 90 05 C8         [24]  452 	mov	dptr,#(_candidate + 0x0016)
      0044C2 12 43 66         [24]  453 	lcall	_word
      0044C5 12 43 30         [24]  454 	lcall	_ak820_outline_0135
      0044C8 C0 07            [24]  455 	push	ar7
      0044CA C0 06            [24]  456 	push	ar6
      0044CC 12 43 AB         [24]  457 	lcall	_checksum
      0044CF 12 38 71         [24]  458 	lcall	_ak820_outline_0149
      0044D2 D0 06            [24]  459 	pop	ar6
      0044D4 D0 07            [24]  460 	pop	ar7
      0044D6 EE               [12]  461 	mov	a,r6
      0044D7 B5 04 07         [24]  462 	cjne	a,ar4,00239$
      0044DA EF               [12]  463 	mov	a,r7
      0044DB B5 05 03         [24]  464 	cjne	a,ar5,00239$
      0044DE D3               [12]  465 	setb	c
      0044DF 80 01            [24]  466 	sjmp	00240$
      0044E1                        467 00239$:
      0044E1 C3               [12]  468 	clr	c
      0044E2                        469 00240$:
      0044E2 92 0C            [24]  470 	mov  _valid_sloc0_1_0,c
      0044E4 12 38 7B         [24]  471 	lcall	_ak820_outline_0160
                                    472 ;	keyboards/ajazz/ak820/ak820_settings.c:49: }
      0044E7 22               [24]  473 	ret
                                    474 ;------------------------------------------------------------
                                    475 ;Allocation info for local variables in function 'commit'
                                    476 ;------------------------------------------------------------
                                    477 ;	keyboards/ajazz/ak820/ak820_settings.c:53: static int commit(void) {
                                    478 ;	-----------------------------------------
                                    479 ;	 function commit
                                    480 ;	-----------------------------------------
      0044E8                        481 _commit:
                                    482 ;	keyboards/ajazz/ak820/ak820_settings.c:54: if (!ak820_nvm_ok()) return -1;
      0044E8 12 3D DD         [24]  483 	lcall	_ak820_nvm_ok
      0044EB E5 82            [12]  484 	mov	a, dpl
      0044ED 70 04            [24]  485 	jnz	00102$
      0044EF 90 FF FF         [24]  486 	mov	dptr,#0xffff
      0044F2 22               [24]  487 	ret
      0044F3                        488 00102$:
                                    489 ;	keyboards/ajazz/ak820/ak820_settings.c:55: if (!memcmp(current, candidate, sizeof(current))) return 0;
      0044F3 90 0D CB         [24]  490 	mov	dptr,#_memcmp_PARM_2
      0044F6 74 B2            [12]  491 	mov	a,#_candidate
      0044F8 F0               [24]  492 	movx	@dptr,a
      0044F9 74 05            [12]  493 	mov	a,#(_candidate >> 8)
      0044FB 12 38 2E         [24]  494 	lcall	_ak820_outline_0084
      0044FE 90 0D CE         [24]  495 	mov	dptr,#_memcmp_PARM_3
      004501 12 47 EB         [24]  496 	lcall	_ak820_outline_0063
      004504 90 05 9A         [24]  497 	mov	dptr,#_current
      004507 F5 F0            [12]  498 	mov	b,a
      004509 12 BB F9         [24]  499 	lcall	_memcmp
      00450C 12 38 40         [24]  500 	lcall	_ak820_outline_0101
      00450F 45 F0            [12]  501 	orl	a,b
      004511 70 04            [24]  502 	jnz	00104$
      004513 90 00 00         [24]  503 	mov	dptr,#0x0000
      004516 22               [24]  504 	ret
      004517                        505 00104$:
                                    506 ;	keyboards/ajazz/ak820/ak820_settings.c:56: clear_keyboard();
      004517 12 7A 45         [24]  507 	lcall	_clear_keyboard
                                    508 ;	keyboards/ajazz/ak820/ak820_settings.c:57: ak820_nvm_begin();
      00451A 12 3F 3E         [24]  509 	lcall	_ak820_nvm_begin
                                    510 ;	keyboards/ajazz/ak820/ak820_settings.c:58: ak820_eeprom_update_block_xdata(candidate, (void *)AK820_SETTINGS_ADDR, sizeof(candidate));
      00451D 90 05 91         [24]  511 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      004520 74 A8            [12]  512 	mov	a,#0xa8
      004522 F0               [24]  513 	movx	@dptr,a
      004523 74 06            [12]  514 	mov	a,#0x06
      004525 12 38 2E         [24]  515 	lcall	_ak820_outline_0084
      004528 90 05 94         [24]  516 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      00452B 12 47 EB         [24]  517 	lcall	_ak820_outline_0063
      00452E 90 05 B2         [24]  518 	mov	dptr,#_candidate
      004531 12 41 E0         [24]  519 	lcall	_ak820_eeprom_update_block_xdata
                                    520 ;	keyboards/ajazz/ak820/ak820_settings.c:59: ak820_nvm_end();
      004534 12 3F 53         [24]  521 	lcall	_ak820_nvm_end
                                    522 ;	keyboards/ajazz/ak820/ak820_settings.c:60: if (!ak820_nvm_ok()) return -1;
      004537 12 3D DD         [24]  523 	lcall	_ak820_nvm_ok
      00453A E5 82            [12]  524 	mov	a, dpl
      00453C 70 04            [24]  525 	jnz	00106$
      00453E 90 FF FF         [24]  526 	mov	dptr,#0xffff
      004541 22               [24]  527 	ret
      004542                        528 00106$:
                                    529 ;	keyboards/ajazz/ak820/ak820_settings.c:61: memcpy(current, candidate, sizeof(current));
      004542 12 47 C3         [24]  530 	lcall	_ak820_outline_0018
      004545 12 BB 20         [24]  531 	lcall	___memcpy
                                    532 ;	keyboards/ajazz/ak820/ak820_settings.c:62: return 0;
      004548 90 00 00         [24]  533 	mov	dptr,#0x0000
                                    534 ;	keyboards/ajazz/ak820/ak820_settings.c:63: }
      00454B 22               [24]  535 	ret
                                    536 ;------------------------------------------------------------
                                    537 ;Allocation info for local variables in function 'ak820_settings_init'
                                    538 ;------------------------------------------------------------
                                    539 ;i             Allocated with name '_ak820_settings_init_i_10000_86'
                                    540 ;blank_zero    Allocated with name '_ak820_settings_init_blank_zero_10000_86'
                                    541 ;blank_erased  Allocated with name '_ak820_settings_init_blank_erased_10000_86'
                                    542 ;------------------------------------------------------------
                                    543 ;	keyboards/ajazz/ak820/ak820_settings.c:64: void ak820_settings_init(void) {
                                    544 ;	-----------------------------------------
                                    545 ;	 function ak820_settings_init
                                    546 ;	-----------------------------------------
      00454C                        547 _ak820_settings_init:
                                    548 ;	keyboards/ajazz/ak820/ak820_settings.c:66: bool blank_zero = true, blank_erased = true;
      00454C 90 05 D3         [24]  549 	mov	dptr,#_ak820_settings_init_blank_zero_10000_86
      00454F 74 01            [12]  550 	mov	a,#0x01
      004551 F0               [24]  551 	movx	@dptr,a
      004552 90 05 D4         [24]  552 	mov	dptr,#_ak820_settings_init_blank_erased_10000_86
      004555 F0               [24]  553 	movx	@dptr,a
                                    554 ;	keyboards/ajazz/ak820/ak820_settings.c:67: ak820_eeprom_read_block_xdata(candidate, (const void *)AK820_SETTINGS_ADDR, sizeof(candidate));
      004556 90 05 81         [24]  555 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      004559 74 A8            [12]  556 	mov	a,#0xa8
      00455B F0               [24]  557 	movx	@dptr,a
      00455C 74 06            [12]  558 	mov	a,#0x06
      00455E 12 38 2E         [24]  559 	lcall	_ak820_outline_0084
      004561 90 05 84         [24]  560 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      004564 12 47 EB         [24]  561 	lcall	_ak820_outline_0063
      004567 90 05 B2         [24]  562 	mov	dptr,#_candidate
      00456A 12 40 71         [24]  563 	lcall	_ak820_eeprom_read_block_xdata
                                    564 ;	keyboards/ajazz/ak820/ak820_settings.c:68: if (!valid()) {
      00456D 12 44 25         [24]  565 	lcall	_valid
      004570 E5 82            [12]  566 	mov	a, dpl
                                    567 ;	keyboards/ajazz/ak820/ak820_settings.c:71: for (i = 0; i < sizeof(candidate); ++i) {
      004572 70 33            [24]  568 	jnz	00110$
      004574 FF               [12]  569 	mov	r7,a
      004575                        570 00111$:
                                    571 ;	keyboards/ajazz/ak820/ak820_settings.c:72: if (candidate[i]) blank_zero = false;
      004575 EF               [12]  572 	mov	a,r7
      004576 12 47 DF         [24]  573 	lcall	_ak820_outline_0040
      004579 E0               [24]  574 	movx	a,@dptr
      00457A 60 05            [24]  575 	jz	00102$
      00457C 90 05 D3         [24]  576 	mov	dptr,#_ak820_settings_init_blank_zero_10000_86
      00457F E4               [12]  577 	clr	a
      004580 F0               [24]  578 	movx	@dptr,a
      004581                        579 00102$:
                                    580 ;	keyboards/ajazz/ak820/ak820_settings.c:73: if (candidate[i] != 0xFF) blank_erased = false;
      004581 12 47 F8         [24]  581 	lcall	_ak820_outline_0109
      004584 FE               [12]  582 	mov	r6,a
      004585 BE FF 02         [24]  583 	cjne	r6,#0xff,00167$
      004588 80 05            [24]  584 	sjmp	00112$
      00458A                        585 00167$:
      00458A 90 05 D4         [24]  586 	mov	dptr,#_ak820_settings_init_blank_erased_10000_86
      00458D E4               [12]  587 	clr	a
      00458E F0               [24]  588 	movx	@dptr,a
      00458F                        589 00112$:
                                    590 ;	keyboards/ajazz/ak820/ak820_settings.c:71: for (i = 0; i < sizeof(candidate); ++i) {
      00458F 0F               [12]  591 	inc	r7
      004590 BF 18 00         [24]  592 	cjne	r7,#0x18,00168$
      004593                        593 00168$:
      004593 40 E0            [24]  594 	jc	00111$
                                    595 ;	keyboards/ajazz/ak820/ak820_settings.c:75: if (!blank_zero && !blank_erased) ak820_nvm_schema_fault();
      004595 90 05 D3         [24]  596 	mov	dptr,#_ak820_settings_init_blank_zero_10000_86
      004598 E0               [24]  597 	movx	a,@dptr
      004599 70 09            [24]  598 	jnz	00107$
      00459B 90 05 D4         [24]  599 	mov	dptr,#_ak820_settings_init_blank_erased_10000_86
      00459E E0               [24]  600 	movx	a,@dptr
      00459F 70 03            [24]  601 	jnz	00107$
      0045A1 12 3D E6         [24]  602 	lcall	_ak820_nvm_schema_fault
      0045A4                        603 00107$:
                                    604 ;	keyboards/ajazz/ak820/ak820_settings.c:76: defaults();
      0045A4 12 44 0A         [24]  605 	lcall	_defaults
      0045A7                        606 00110$:
                                    607 ;	keyboards/ajazz/ak820/ak820_settings.c:78: memcpy(current, candidate, sizeof(current));
      0045A7 12 47 C3         [24]  608 	lcall	_ak820_outline_0018
                                    609 ;	keyboards/ajazz/ak820/ak820_settings.c:79: }
      0045AA 02 BB 20         [24]  610 	ljmp	___memcpy
                                    611 ;------------------------------------------------------------
                                    612 ;Allocation info for local variables in function 'offset'
                                    613 ;------------------------------------------------------------
                                    614 ;id            Allocated with name '_offset_id_10000_94'
                                    615 ;i             Allocated with name '_offset_i_20000_96'
                                    616 ;------------------------------------------------------------
                                    617 ;	keyboards/ajazz/ak820/ak820_settings.c:95: static uint8_t offset(uint8_t id) {
                                    618 ;	-----------------------------------------
                                    619 ;	 function offset
                                    620 ;	-----------------------------------------
      0045AD                        621 _offset:
      0045AD E5 82            [12]  622 	mov	a,dpl
      0045AF 90 05 D5         [24]  623 	mov	dptr,#_offset_id_10000_94
      0045B2 F0               [24]  624 	movx	@dptr,a
                                    625 ;	keyboards/ajazz/ak820/ak820_settings.c:96: for (uint8_t i = 0; i < sizeof(ids); ++i) if (ids[i] == id) return positions[i];
      0045B3 E0               [24]  626 	movx	a,@dptr
      0045B4 FF               [12]  627 	mov	r7,a
      0045B5 7E 00            [12]  628 	mov	r6,#0x00
      0045B7                        629 00105$:
      0045B7 BE 05 00         [24]  630 	cjne	r6,#0x05,00130$
      0045BA                        631 00130$:
      0045BA 50 13            [24]  632 	jnc	00103$
      0045BC EE               [12]  633 	mov	a,r6
      0045BD 90 BD 7D         [24]  634 	mov	dptr,#_ids
      0045C0 93               [24]  635 	movc	a,@a+dptr
      0045C1 B5 07 08         [24]  636 	cjne	a,ar7,00106$
      0045C4 EE               [12]  637 	mov	a,r6
      0045C5 90 BD 82         [24]  638 	mov	dptr,#_positions
      0045C8 93               [24]  639 	movc	a,@a+dptr
      0045C9 F5 82            [12]  640 	mov	dpl,a
      0045CB 22               [24]  641 	ret
      0045CC                        642 00106$:
      0045CC 0E               [12]  643 	inc	r6
      0045CD 80 E8            [24]  644 	sjmp	00105$
      0045CF                        645 00103$:
                                    646 ;	keyboards/ajazz/ak820/ak820_settings.c:97: return 0;
      0045CF 75 82 00         [24]  647 	mov	dpl, #0x00
                                    648 ;	keyboards/ajazz/ak820/ak820_settings.c:98: }
      0045D2 22               [24]  649 	ret
                                    650 ;------------------------------------------------------------
                                    651 ;Allocation info for local variables in function 'ak820_settings_query'
                                    652 ;------------------------------------------------------------
                                    653 ;buffer        Allocated with name '_ak820_settings_query_PARM_2'
                                    654 ;size          Allocated with name '_ak820_settings_query_PARM_3'
                                    655 ;greater_than  Allocated with name '_ak820_settings_query_greater_than_10000_98'
                                    656 ;i             Allocated with name '_ak820_settings_query_i_10000_99'
                                    657 ;used          Allocated with name '_ak820_settings_query_used_10000_99'
                                    658 ;------------------------------------------------------------
                                    659 ;	keyboards/ajazz/ak820/ak820_settings.c:99: void ak820_settings_query(uint16_t greater_than, uint8_t AK820_XDATA *buffer, uint8_t size) {
                                    660 ;	-----------------------------------------
                                    661 ;	 function ak820_settings_query
                                    662 ;	-----------------------------------------
      0045D3                        663 _ak820_settings_query:
      0045D3 12 38 52         [24]  664 	lcall	_ak820_outline_0106
      0045D6 90 05 D9         [24]  665 	mov	dptr,#_ak820_settings_query_greater_than_10000_98
      0045D9 12 38 57         [24]  666 	lcall	_ak820_outline_0107
                                    667 ;	keyboards/ajazz/ak820/ak820_settings.c:100: uint8_t i, used = 0;
      0045DC 90 05 DB         [24]  668 	mov	dptr,#_ak820_settings_query_used_10000_99
      0045DF E4               [12]  669 	clr	a
      0045E0 F0               [24]  670 	movx	@dptr,a
                                    671 ;	keyboards/ajazz/ak820/ak820_settings.c:101: for (i = 0; i < size; ++i) buffer[i] = 0xFF;
      0045E1 90 05 D6         [24]  672 	mov	dptr,#_ak820_settings_query_PARM_2
      0045E4 12 37 FC         [24]  673 	lcall	_ak820_outline_0051
      0045E7 90 05 D8         [24]  674 	mov	dptr,#_ak820_settings_query_PARM_3
      0045EA E0               [24]  675 	movx	a,@dptr
      0045EB FD               [12]  676 	mov	r5,a
      0045EC 7C 00            [12]  677 	mov	r4,#0x00
      0045EE                        678 00108$:
      0045EE C3               [12]  679 	clr	c
      0045EF EC               [12]  680 	mov	a,r4
      0045F0 9D               [12]  681 	subb	a,r5
      0045F1 50 0A            [24]  682 	jnc	00101$
      0045F3 EC               [12]  683 	mov	a,r4
      0045F4 12 37 EC         [24]  684 	lcall	_ak820_outline_0017
      0045F7 74 FF            [12]  685 	mov	a,#0xff
      0045F9 F0               [24]  686 	movx	@dptr,a
      0045FA 0C               [12]  687 	inc	r4
      0045FB 80 F1            [24]  688 	sjmp	00108$
      0045FD                        689 00101$:
                                    690 ;	keyboards/ajazz/ak820/ak820_settings.c:102: if (greater_than >= 19) return;
      0045FD 90 05 D9         [24]  691 	mov	dptr,#_ak820_settings_query_greater_than_10000_98
      004600 12 38 4C         [24]  692 	lcall	_ak820_outline_0105
      004603 C3               [12]  693 	clr	c
      004604 EB               [12]  694 	mov	a,r3
      004605 94 13            [12]  695 	subb	a,#0x13
      004607 EC               [12]  696 	mov	a,r4
      004608 94 00            [12]  697 	subb	a,#0x00
      00460A 40 01            [24]  698 	jc	00129$
                                    699 ;	keyboards/ajazz/ak820/ak820_settings.c:103: for (i = 0; i < sizeof(ids) && used + 2 <= size; ++i) {
      00460C 22               [24]  700 	ret
      00460D                        701 00129$:
      00460D 7C 00            [12]  702 	mov	r4,#0x00
      00460F                        703 00112$:
      00460F BC 05 00         [24]  704 	cjne	r4,#0x05,00169$
      004612                        705 00169$:
      004612 50 54            [24]  706 	jnc	00114$
      004614 C0 06            [24]  707 	push	ar6
      004616 C0 07            [24]  708 	push	ar7
      004618 90 05 DB         [24]  709 	mov	dptr,#_ak820_settings_query_used_10000_99
      00461B E0               [24]  710 	movx	a,@dptr
      00461C FB               [12]  711 	mov	r3,a
      00461D F9               [12]  712 	mov	r1,a
      00461E 7A 00            [12]  713 	mov	r2,#0x00
      004620 74 02            [12]  714 	mov	a,#0x02
      004622 29               [12]  715 	add	a, r1
      004623 F9               [12]  716 	mov	r1,a
      004624 E4               [12]  717 	clr	a
      004625 3A               [12]  718 	addc	a, r2
      004626 FA               [12]  719 	mov	r2,a
      004627 8D 00            [24]  720 	mov	ar0,r5
      004629 7F 00            [12]  721 	mov	r7,#0x00
      00462B C3               [12]  722 	clr	c
      00462C E8               [12]  723 	mov	a,r0
      00462D 99               [12]  724 	subb	a,r1
      00462E EF               [12]  725 	mov	a,r7
      00462F 64 80            [12]  726 	xrl	a,#0x80
      004631 8A F0            [24]  727 	mov	b,r2
      004633 63 F0 80         [24]  728 	xrl	b,#0x80
      004636 95 F0            [12]  729 	subb	a,b
      004638 D0 07            [24]  730 	pop	ar7
      00463A D0 06            [24]  731 	pop	ar6
      00463C 40 2A            [24]  732 	jc	00114$
                                    733 ;	free result
                                    734 ;	keyboards/ajazz/ak820/ak820_settings.c:104: if (ids[i] > (uint8_t)greater_than) { buffer[used++] = ids[i]; buffer[used++] = 0; }
      00463E EC               [12]  735 	mov	a,r4
      00463F 90 BD 7D         [24]  736 	mov	dptr,#_ids
      004642 93               [24]  737 	movc	a,@a+dptr
      004643 FA               [12]  738 	mov	r2,a
      004644 90 05 D9         [24]  739 	mov	dptr,#_ak820_settings_query_greater_than_10000_98
      004647 E0               [24]  740 	movx	a,@dptr
      004648 C3               [12]  741 	clr	c
      004649 9A               [12]  742 	subb	a,r2
      00464A 50 19            [24]  743 	jnc	00113$
                                    744 ;	free result
      00464C 90 05 DB         [24]  745 	mov	dptr,#_ak820_settings_query_used_10000_99
      00464F EB               [12]  746 	mov	a,r3
      004650 04               [12]  747 	inc	a
      004651 F0               [24]  748 	movx	@dptr,a
      004652 EB               [12]  749 	mov	a,r3
      004653 12 37 EC         [24]  750 	lcall	_ak820_outline_0017
      004656 EA               [12]  751 	mov	a,r2
      004657 F0               [24]  752 	movx	@dptr,a
      004658 90 05 DB         [24]  753 	mov	dptr,#_ak820_settings_query_used_10000_99
      00465B E0               [24]  754 	movx	a,@dptr
      00465C FB               [12]  755 	mov	r3,a
      00465D 04               [12]  756 	inc	a
      00465E F0               [24]  757 	movx	@dptr,a
      00465F EB               [12]  758 	mov	a,r3
      004660 12 37 EC         [24]  759 	lcall	_ak820_outline_0017
      004663 E4               [12]  760 	clr	a
      004664 F0               [24]  761 	movx	@dptr,a
      004665                        762 00113$:
                                    763 ;	keyboards/ajazz/ak820/ak820_settings.c:103: for (i = 0; i < sizeof(ids) && used + 2 <= size; ++i) {
      004665 0C               [12]  764 	inc	r4
      004666 80 A7            [24]  765 	sjmp	00112$
      004668                        766 00114$:
                                    767 ;	keyboards/ajazz/ak820/ak820_settings.c:106: }
      004668 22               [24]  768 	ret
                                    769 ;------------------------------------------------------------
                                    770 ;Allocation info for local variables in function 'ak820_settings_get'
                                    771 ;------------------------------------------------------------
                                    772 ;buffer        Allocated with name '_ak820_settings_get_PARM_2'
                                    773 ;capacity      Allocated with name '_ak820_settings_get_PARM_3'
                                    774 ;id            Allocated with name '_ak820_settings_get_id_10000_106'
                                    775 ;out           Allocated with name '_ak820_settings_get_out_10000_107'
                                    776 ;pos           Allocated with name '_ak820_settings_get_pos_10000_107'
                                    777 ;width         Allocated with name '_ak820_settings_get_width_10000_107'
                                    778 ;------------------------------------------------------------
                                    779 ;	keyboards/ajazz/ak820/ak820_settings.c:107: int ak820_settings_get(uint16_t id, uint8_t AK820_XDATA *buffer, uint8_t capacity) {
                                    780 ;	-----------------------------------------
                                    781 ;	 function ak820_settings_get
                                    782 ;	-----------------------------------------
      004669                        783 _ak820_settings_get:
      004669 12 38 52         [24]  784 	lcall	_ak820_outline_0106
      00466C 90 05 DF         [24]  785 	mov	dptr,#_ak820_settings_get_id_10000_106
      00466F 12 38 57         [24]  786 	lcall	_ak820_outline_0107
                                    787 ;	keyboards/ajazz/ak820/ak820_settings.c:108: uint8_t AK820_XDATA *out = buffer;
      004672 90 05 DC         [24]  788 	mov	dptr,#_ak820_settings_get_PARM_2
      004675 12 37 FC         [24]  789 	lcall	_ak820_outline_0051
                                    790 ;	keyboards/ajazz/ak820/ak820_settings.c:109: uint8_t pos, width = id == 1 ? 1 : 2;
      004678 90 05 DF         [24]  791 	mov	dptr,#_ak820_settings_get_id_10000_106
      00467B 12 38 1B         [24]  792 	lcall	_ak820_outline_0059
      00467E BC 01 07         [24]  793 	cjne	r4,#0x01,00110$
      004681 BD 00 04         [24]  794 	cjne	r5,#0x00,00110$
      004684 7B 01            [12]  795 	mov	r3,#0x01
      004686 80 02            [24]  796 	sjmp	00111$
      004688                        797 00110$:
      004688 7B 02            [12]  798 	mov	r3,#0x02
      00468A                        799 00111$:
                                    800 ;	keyboards/ajazz/ak820/ak820_settings.c:110: if (id > 255) return -1;
      00468A 12 48 04         [24]  801 	lcall	_ak820_outline_0113
      00468D 50 04            [24]  802 	jnc	00102$
                                    803 ;	free result
      00468F 90 FF FF         [24]  804 	mov	dptr,#0xffff
      004692 22               [24]  805 	ret
      004693                        806 00102$:
                                    807 ;	keyboards/ajazz/ak820/ak820_settings.c:111: pos = offset((uint8_t)id);
      004693 90 05 DF         [24]  808 	mov	dptr,#_ak820_settings_get_id_10000_106
      004696 E0               [24]  809 	movx	a,@dptr
      004697 F5 82            [12]  810 	mov	dpl,a
      004699 C0 07            [24]  811 	push	ar7
      00469B C0 06            [24]  812 	push	ar6
      00469D C0 03            [24]  813 	push	ar3
      00469F 12 45 AD         [24]  814 	lcall	_offset
      0046A2 AD 82            [24]  815 	mov	r5, dpl
      0046A4 D0 03            [24]  816 	pop	ar3
      0046A6 D0 06            [24]  817 	pop	ar6
      0046A8 D0 07            [24]  818 	pop	ar7
                                    819 ;	keyboards/ajazz/ak820/ak820_settings.c:112: if (!pos || capacity < width) return -1;
      0046AA ED               [12]  820 	mov	a,r5
      0046AB 60 08            [24]  821 	jz	00103$
      0046AD 90 05 DE         [24]  822 	mov	dptr,#_ak820_settings_get_PARM_3
      0046B0 E0               [24]  823 	movx	a,@dptr
      0046B1 C3               [12]  824 	clr	c
      0046B2 9B               [12]  825 	subb	a,r3
      0046B3 50 04            [24]  826 	jnc	00104$
      0046B5                        827 00103$:
      0046B5 90 FF FF         [24]  828 	mov	dptr,#0xffff
      0046B8 22               [24]  829 	ret
      0046B9                        830 00104$:
                                    831 ;	keyboards/ajazz/ak820/ak820_settings.c:113: out[0] = current[pos];
      0046B9 ED               [12]  832 	mov	a,r5
      0046BA 24 9A            [12]  833 	add	a, #_current
      0046BC F5 82            [12]  834 	mov	dpl,a
      0046BE E4               [12]  835 	clr	a
      0046BF 34 05            [12]  836 	addc	a, #(_current >> 8)
      0046C1 F5 83            [12]  837 	mov	dph,a
      0046C3 12 43 0C         [24]  838 	lcall	_ak820_outline_0094
                                    839 ;	keyboards/ajazz/ak820/ak820_settings.c:114: if (width == 2) out[1] = current[pos + 1];
      0046C6 BB 02 18         [24]  840 	cjne	r3,#0x02,00107$
      0046C9 0E               [12]  841 	inc	r6
      0046CA BE 00 01         [24]  842 	cjne	r6,#0x00,00147$
      0046CD 0F               [12]  843 	inc	r7
      0046CE                        844 00147$:
      0046CE 0D               [12]  845 	inc	r5
      0046CF ED               [12]  846 	mov	a,r5
      0046D0 33               [12]  847 	rlc	a
      0046D1 95 E0            [12]  848 	subb	a,acc
      0046D3 FC               [12]  849 	mov	r4,a
      0046D4 ED               [12]  850 	mov	a,r5
      0046D5 24 9A            [12]  851 	add	a, #_current
      0046D7 F5 82            [12]  852 	mov	dpl,a
      0046D9 EC               [12]  853 	mov	a,r4
      0046DA 34 05            [12]  854 	addc	a, #(_current >> 8)
      0046DC F5 83            [12]  855 	mov	dph,a
      0046DE 12 43 0C         [24]  856 	lcall	_ak820_outline_0094
      0046E1                        857 00107$:
                                    858 ;	keyboards/ajazz/ak820/ak820_settings.c:115: return 0;
      0046E1 90 00 00         [24]  859 	mov	dptr,#0x0000
                                    860 ;	keyboards/ajazz/ak820/ak820_settings.c:116: }
      0046E4 22               [24]  861 	ret
                                    862 ;------------------------------------------------------------
                                    863 ;Allocation info for local variables in function 'ak820_settings_set'
                                    864 ;------------------------------------------------------------
                                    865 ;buffer        Allocated with name '_ak820_settings_set_PARM_2'
                                    866 ;capacity      Allocated with name '_ak820_settings_set_PARM_3'
                                    867 ;id            Allocated with name '_ak820_settings_set_id_10000_111'
                                    868 ;in            Allocated with name '_ak820_settings_set_in_10000_112'
                                    869 ;pos           Allocated with name '_ak820_settings_set_pos_10000_112'
                                    870 ;width         Allocated with name '_ak820_settings_set_width_10000_112'
                                    871 ;------------------------------------------------------------
                                    872 ;	keyboards/ajazz/ak820/ak820_settings.c:117: int ak820_settings_set(uint16_t id, const uint8_t AK820_XDATA *buffer, uint8_t capacity) {
                                    873 ;	-----------------------------------------
                                    874 ;	 function ak820_settings_set
                                    875 ;	-----------------------------------------
      0046E5                        876 _ak820_settings_set:
      0046E5 12 38 52         [24]  877 	lcall	_ak820_outline_0106
      0046E8 90 05 E4         [24]  878 	mov	dptr,#_ak820_settings_set_id_10000_111
      0046EB 12 38 57         [24]  879 	lcall	_ak820_outline_0107
                                    880 ;	keyboards/ajazz/ak820/ak820_settings.c:118: const uint8_t AK820_XDATA *in = buffer;
      0046EE 90 05 E1         [24]  881 	mov	dptr,#_ak820_settings_set_PARM_2
      0046F1 12 37 FC         [24]  882 	lcall	_ak820_outline_0051
                                    883 ;	keyboards/ajazz/ak820/ak820_settings.c:119: uint8_t pos, width = id == 1 ? 1 : 2;
      0046F4 90 05 E4         [24]  884 	mov	dptr,#_ak820_settings_set_id_10000_111
      0046F7 12 38 1B         [24]  885 	lcall	_ak820_outline_0059
      0046FA BC 01 07         [24]  886 	cjne	r4,#0x01,00113$
      0046FD BD 00 04         [24]  887 	cjne	r5,#0x00,00113$
      004700 7B 01            [12]  888 	mov	r3,#0x01
      004702 80 02            [24]  889 	sjmp	00114$
      004704                        890 00113$:
      004704 7B 02            [12]  891 	mov	r3,#0x02
      004706                        892 00114$:
                                    893 ;	keyboards/ajazz/ak820/ak820_settings.c:120: if (id > 255) return -1;
      004706 12 48 04         [24]  894 	lcall	_ak820_outline_0113
      004709 50 04            [24]  895 	jnc	00102$
                                    896 ;	free result
      00470B 90 FF FF         [24]  897 	mov	dptr,#0xffff
      00470E 22               [24]  898 	ret
      00470F                        899 00102$:
                                    900 ;	keyboards/ajazz/ak820/ak820_settings.c:121: pos = offset((uint8_t)id);
      00470F 90 05 E4         [24]  901 	mov	dptr,#_ak820_settings_set_id_10000_111
      004712 E0               [24]  902 	movx	a,@dptr
      004713 F5 82            [12]  903 	mov	dpl,a
      004715 C0 07            [24]  904 	push	ar7
      004717 C0 06            [24]  905 	push	ar6
      004719 C0 03            [24]  906 	push	ar3
      00471B 12 45 AD         [24]  907 	lcall	_offset
      00471E AD 82            [24]  908 	mov	r5, dpl
      004720 D0 03            [24]  909 	pop	ar3
      004722 D0 06            [24]  910 	pop	ar6
      004724 D0 07            [24]  911 	pop	ar7
                                    912 ;	keyboards/ajazz/ak820/ak820_settings.c:122: if (!pos || capacity < width || !ak820_nvm_ok()) return -1;
      004726 ED               [12]  913 	mov	a,r5
      004727 60 0F            [24]  914 	jz	00103$
      004729 90 05 E3         [24]  915 	mov	dptr,#_ak820_settings_set_PARM_3
      00472C E0               [24]  916 	movx	a,@dptr
      00472D C3               [12]  917 	clr	c
      00472E 9B               [12]  918 	subb	a,r3
      00472F 40 07            [24]  919 	jc	00103$
      004731 12 3D DD         [24]  920 	lcall	_ak820_nvm_ok
      004734 E5 82            [12]  921 	mov	a, dpl
      004736 70 04            [24]  922 	jnz	00104$
      004738                        923 00103$:
      004738 90 FF FF         [24]  924 	mov	dptr,#0xffff
      00473B 22               [24]  925 	ret
      00473C                        926 00104$:
                                    927 ;	keyboards/ajazz/ak820/ak820_settings.c:123: memcpy(candidate, current, sizeof(candidate));
      00473C 90 0D BD         [24]  928 	mov	dptr,#___memcpy_PARM_2
      00473F 74 9A            [12]  929 	mov	a,#_current
      004741 F0               [24]  930 	movx	@dptr,a
      004742 74 05            [12]  931 	mov	a,#(_current >> 8)
      004744 12 38 2E         [24]  932 	lcall	_ak820_outline_0084
      004747 90 0D C0         [24]  933 	mov	dptr,#___memcpy_PARM_3
      00474A 12 47 EB         [24]  934 	lcall	_ak820_outline_0063
      00474D 90 05 B2         [24]  935 	mov	dptr,#_candidate
      004750 F5 F0            [12]  936 	mov	b,a
      004752 C0 07            [24]  937 	push	ar7
      004754 C0 06            [24]  938 	push	ar6
      004756 C0 05            [24]  939 	push	ar5
      004758 C0 03            [24]  940 	push	ar3
      00475A 12 BB 20         [24]  941 	lcall	___memcpy
      00475D D0 03            [24]  942 	pop	ar3
      00475F D0 05            [24]  943 	pop	ar5
      004761 D0 06            [24]  944 	pop	ar6
      004763 D0 07            [24]  945 	pop	ar7
                                    946 ;	keyboards/ajazz/ak820/ak820_settings.c:124: candidate[pos] = in[0];
      004765 ED               [12]  947 	mov	a,r5
      004766 24 B2            [12]  948 	add	a, #_candidate
      004768 FA               [12]  949 	mov	r2,a
      004769 E4               [12]  950 	clr	a
      00476A 34 05            [12]  951 	addc	a, #(_candidate >> 8)
      00476C FC               [12]  952 	mov	r4,a
      00476D 12 38 3A         [24]  953 	lcall	_ak820_outline_0100
      004770 8A 82            [24]  954 	mov	dpl,r2
      004772 8C 83            [24]  955 	mov	dph,r4
      004774 F0               [24]  956 	movx	@dptr,a
                                    957 ;	keyboards/ajazz/ak820/ak820_settings.c:125: if (width == 2) candidate[pos + 1] = in[1];
      004775 BB 02 15         [24]  958 	cjne	r3,#0x02,00108$
      004778 0D               [12]  959 	inc	r5
      004779 ED               [12]  960 	mov	a,r5
      00477A 33               [12]  961 	rlc	a
      00477B 95 E0            [12]  962 	subb	a,acc
      00477D FC               [12]  963 	mov	r4,a
      00477E ED               [12]  964 	mov	a,r5
      00477F 24 B2            [12]  965 	add	a, #_candidate
      004781 FD               [12]  966 	mov	r5,a
      004782 EC               [12]  967 	mov	a,r4
      004783 34 05            [12]  968 	addc	a, #(_candidate >> 8)
      004785 FC               [12]  969 	mov	r4,a
      004786 12 38 27         [24]  970 	lcall	_ak820_outline_0077
      004789 12 43 5C         [24]  971 	lcall	_ak820_outline_0186
      00478C F0               [24]  972 	movx	@dptr,a
      00478D                        973 00108$:
                                    974 ;	keyboards/ajazz/ak820/ak820_settings.c:126: seal();
      00478D 12 43 F8         [24]  975 	lcall	_seal
                                    976 ;	keyboards/ajazz/ak820/ak820_settings.c:127: if (!valid()) return -1;
      004790 12 44 25         [24]  977 	lcall	_valid
      004793 E5 82            [12]  978 	mov	a, dpl
      004795 70 04            [24]  979 	jnz	00110$
      004797 90 FF FF         [24]  980 	mov	dptr,#0xffff
      00479A 22               [24]  981 	ret
      00479B                        982 00110$:
                                    983 ;	keyboards/ajazz/ak820/ak820_settings.c:128: return commit();
                                    984 ;	keyboards/ajazz/ak820/ak820_settings.c:129: }
      00479B 02 44 E8         [24]  985 	ljmp	_commit
                                    986 ;------------------------------------------------------------
                                    987 ;Allocation info for local variables in function 'ak820_settings_reset'
                                    988 ;------------------------------------------------------------
                                    989 ;	keyboards/ajazz/ak820/ak820_settings.c:130: int ak820_settings_reset(void) { defaults(); return commit(); }
                                    990 ;	-----------------------------------------
                                    991 ;	 function ak820_settings_reset
                                    992 ;	-----------------------------------------
      00479E                        993 _ak820_settings_reset:
      00479E 12 44 0A         [24]  994 	lcall	_defaults
      0047A1 02 44 E8         [24]  995 	ljmp	_commit
                                    996 ;------------------------------------------------------------
                                    997 ;Allocation info for local variables in function 'ak820_settings_grave_esc'
                                    998 ;------------------------------------------------------------
                                    999 ;	keyboards/ajazz/ak820/ak820_settings.c:131: uint8_t ak820_settings_grave_esc(void) { return current[5]; }
                                   1000 ;	-----------------------------------------
                                   1001 ;	 function ak820_settings_grave_esc
                                   1002 ;	-----------------------------------------
      0047A4                       1003 _ak820_settings_grave_esc:
      0047A4 90 05 9F         [24] 1004 	mov	dptr,#(_current + 0x0005)
      0047A7 E0               [24] 1005 	movx	a,@dptr
      0047A8 F5 82            [12] 1006 	mov	dpl,a
      0047AA 22               [24] 1007 	ret
                                   1008 ;------------------------------------------------------------
                                   1009 ;Allocation info for local variables in function 'ak820_settings_combo_term'
                                   1010 ;------------------------------------------------------------
                                   1011 ;	keyboards/ajazz/ak820/ak820_settings.c:132: uint16_t ak820_settings_combo_term(void) { return word(current + 6); }
                                   1012 ;	-----------------------------------------
                                   1013 ;	 function ak820_settings_combo_term
                                   1014 ;	-----------------------------------------
      0047AB                       1015 _ak820_settings_combo_term:
      0047AB 90 05 A0         [24] 1016 	mov	dptr,#(_current + 0x0006)
      0047AE 02 43 66         [24] 1017 	ljmp	_word
                                   1018 ;------------------------------------------------------------
                                   1019 ;Allocation info for local variables in function 'ak820_settings_tapping_term'
                                   1020 ;------------------------------------------------------------
                                   1021 ;	keyboards/ajazz/ak820/ak820_settings.c:133: uint16_t ak820_settings_tapping_term(void) { return word(current + 8); }
                                   1022 ;	-----------------------------------------
                                   1023 ;	 function ak820_settings_tapping_term
                                   1024 ;	-----------------------------------------
      0047B1                       1025 _ak820_settings_tapping_term:
      0047B1 90 05 A2         [24] 1026 	mov	dptr,#(_current + 0x0008)
      0047B4 02 43 66         [24] 1027 	ljmp	_word
                                   1028 ;------------------------------------------------------------
                                   1029 ;Allocation info for local variables in function 'ak820_settings_tap_code_delay'
                                   1030 ;------------------------------------------------------------
                                   1031 ;	keyboards/ajazz/ak820/ak820_settings.c:134: uint16_t ak820_settings_tap_code_delay(void) { return word(current + 10); }
                                   1032 ;	-----------------------------------------
                                   1033 ;	 function ak820_settings_tap_code_delay
                                   1034 ;	-----------------------------------------
      0047B7                       1035 _ak820_settings_tap_code_delay:
      0047B7 90 05 A4         [24] 1036 	mov	dptr,#(_current + 0x000a)
      0047BA 02 43 66         [24] 1037 	ljmp	_word
                                   1038 ;------------------------------------------------------------
                                   1039 ;Allocation info for local variables in function 'ak820_settings_caps_delay'
                                   1040 ;------------------------------------------------------------
                                   1041 ;	keyboards/ajazz/ak820/ak820_settings.c:135: uint16_t ak820_settings_caps_delay(void) { return word(current + 12); }
                                   1042 ;	-----------------------------------------
                                   1043 ;	 function ak820_settings_caps_delay
                                   1044 ;	-----------------------------------------
      0047BD                       1045 _ak820_settings_caps_delay:
      0047BD 90 05 A6         [24] 1046 	mov	dptr,#(_current + 0x000c)
      0047C0 02 43 66         [24] 1047 	ljmp	_word
                                   1048 ;------------------------------------------------------------
                                   1049 ;Allocation info for local variables in function 'ak820_settings_autoshift_timeout'
                                   1050 ;------------------------------------------------------------
                                   1051 ;	keyboards/ajazz/ak820/ak820_settings.c:136: uint16_t ak820_settings_autoshift_timeout(void) { return word(current + 14); }
                                   1052 ;	-----------------------------------------
                                   1053 	.area CSEG    (CODE)
                                   1054 	.area CONST   (CODE)
                                   1055 	.area CONST   (CODE)
      00BD65                       1056 _default_record:
      00BD65 51                    1057 	.db #0x51	; 81	'Q'
      00BD66 53                    1058 	.db #0x53	; 83	'S'
      00BD67 01                    1059 	.db #0x01	; 1
      00BD68 0B                    1060 	.db #0x0b	; 11
      00BD69 3F                    1061 	.db #0x3f	; 63
      00BD6A 00                    1062 	.db #0x00	; 0
      00BD6B 28                    1063 	.db #0x28	; 40
      00BD6C 00                    1064 	.db #0x00	; 0
      00BD6D C8                    1065 	.db #0xc8	; 200
      00BD6E 00                    1066 	.db #0x00	; 0
      00BD6F 00                    1067 	.db #0x00	; 0
      00BD70 00                    1068 	.db #0x00	; 0
      00BD71 50                    1069 	.db #0x50	; 80	'P'
      00BD72 00                    1070 	.db #0x00	; 0
      00BD73 AF                    1071 	.db #0xaf	; 175
      00BD74 00                    1072 	.db #0x00	; 0
      00BD75 00                    1073 	.db #0x00	; 0
      00BD76 00                    1074 	.db #0x00	; 0
      00BD77 00                    1075 	.db #0x00	; 0
      00BD78 00                    1076 	.db #0x00	; 0
      00BD79 00                    1077 	.db #0x00	; 0
      00BD7A 00                    1078 	.db #0x00	; 0
      00BD7B 7B                    1079 	.db #0x7b	; 123
      00BD7C C9                    1080 	.db #0xc9	; 201
                                   1081 	.area CSEG    (CODE)
                                   1082 	.area CONST   (CODE)
      00BD7D                       1083 _ids:
      00BD7D 01                    1084 	.db #0x01	; 1
      00BD7E 02                    1085 	.db #0x02	; 2
      00BD7F 07                    1086 	.db #0x07	; 7
      00BD80 12                    1087 	.db #0x12	; 18
      00BD81 13                    1088 	.db #0x13	; 19
                                   1089 	.area CSEG    (CODE)
                                   1090 	.area CONST   (CODE)
      00BD82                       1091 _positions:
      00BD82 05                    1092 	.db #0x05	; 5
      00BD83 06                    1093 	.db #0x06	; 6
      00BD84 08                    1094 	.db #0x08	; 8
      00BD85 0A                    1095 	.db #0x0a	; 10
      00BD86 0C                    1096 	.db #0x0c	; 12
                                   1097 	.area CSEG    (CODE)
                                   1098 	.area XINIT   (CODE)
                                   1099 	.area CABS    (ABS,CODE)
                                   1100 
                                   1101 ; Experimental exact instruction outlining.
                                   1102 	.globl _ak820_outline_0004
                                   1103 	.globl _ak820_outline_0017
                                   1104 	.globl _ak820_outline_0018
                                   1105 	.globl _ak820_outline_0040
                                   1106 	.globl _ak820_outline_0051
                                   1107 	.globl _ak820_outline_0059
                                   1108 	.globl _ak820_outline_0061
                                   1109 	.globl _ak820_outline_0063
                                   1110 	.globl _ak820_outline_0077
                                   1111 	.globl _ak820_outline_0084
                                   1112 	.globl _ak820_outline_0094
                                   1113 	.globl _ak820_outline_0100
                                   1114 	.globl _ak820_outline_0101
                                   1115 	.globl _ak820_outline_0102
                                   1116 	.globl _ak820_outline_0105
                                   1117 	.globl _ak820_outline_0106
                                   1118 	.globl _ak820_outline_0107
                                   1119 	.globl _ak820_outline_0109
                                   1120 	.globl _ak820_outline_0113
                                   1121 	.globl _ak820_outline_0121
                                   1122 	.globl _ak820_outline_0135
                                   1123 	.globl _ak820_outline_0143
                                   1124 	.globl _ak820_outline_0148
                                   1125 	.globl _ak820_outline_0149
                                   1126 	.globl _ak820_outline_0160
                                   1127 	.globl _ak820_outline_0186
                                   1128 	.globl _ak820_outline_0192
                                   1129 
                                   1130 	.area CSEG (CODE)
                                   1131 ; function ak820_outline_0018
      0047C3                       1132 _ak820_outline_0018:
      0047C3 90 0D BD         [24] 1133 	mov	dptr,#___memcpy_PARM_2
      0047C6 74 B2            [12] 1134 	mov	a,#_candidate
      0047C8 F0               [24] 1135 	movx	@dptr,a
      0047C9 74 05            [12] 1136 	mov	a,#(_candidate>>8)
      0047CB A3               [24] 1137 	inc	dptr
      0047CC F0               [24] 1138 	movx	@dptr,a
      0047CD E4               [12] 1139 	clr	a
      0047CE A3               [24] 1140 	inc	dptr
      0047CF F0               [24] 1141 	movx	@dptr,a
      0047D0 90 0D C0         [24] 1142 	mov	dptr,#___memcpy_PARM_3
      0047D3 74 18            [12] 1143 	mov	a,#0x18
      0047D5 F0               [24] 1144 	movx	@dptr,a
      0047D6 E4               [12] 1145 	clr	a
      0047D7 A3               [24] 1146 	inc	dptr
      0047D8 F0               [24] 1147 	movx	@dptr,a
      0047D9 90 05 9A         [24] 1148 	mov	dptr,#_current
      0047DC F5 F0            [12] 1149 	mov	b,a
      0047DE 22               [24] 1150 	ret
                                   1151 
                                   1152 	.area CSEG (CODE)
                                   1153 ; function ak820_outline_0040
      0047DF                       1154 _ak820_outline_0040:
      0047DF 24 B2            [12] 1155 	add	a,#_candidate
      0047E1 FD               [12] 1156 	mov	r5,a
      0047E2 E4               [12] 1157 	clr	a
      0047E3 34 05            [12] 1158 	addc	a,#(_candidate>>8)
      0047E5 FE               [12] 1159 	mov	r6,a
      0047E6 8D 82            [24] 1160 	mov	dpl,r5
      0047E8 8E 83            [24] 1161 	mov	dph,r6
      0047EA 22               [24] 1162 	ret
                                   1163 
                                   1164 	.area CSEG (CODE)
                                   1165 ; function ak820_outline_0063
      0047EB                       1166 _ak820_outline_0063:
      0047EB 74 18            [12] 1167 	mov	a,#0x18
      0047ED F0               [24] 1168 	movx	@dptr,a
      0047EE E4               [12] 1169 	clr	a
      0047EF A3               [24] 1170 	inc	dptr
      0047F0 F0               [24] 1171 	movx	@dptr,a
      0047F1 22               [24] 1172 	ret
                                   1173 
                                   1174 	.area CSEG (CODE)
                                   1175 ; function ak820_outline_0102
      0047F2                       1176 _ak820_outline_0102:
      0047F2 8D 82            [24] 1177 	mov	dpl,r5
      0047F4 8E 83            [24] 1178 	mov	dph,r6
      0047F6 F0               [24] 1179 	movx	@dptr,a
      0047F7 22               [24] 1180 	ret
                                   1181 
                                   1182 	.area CSEG (CODE)
                                   1183 ; function ak820_outline_0109
      0047F8                       1184 _ak820_outline_0109:
      0047F8 EF               [12] 1185 	mov	a,r7
      0047F9 24 B2            [12] 1186 	add	a,#_candidate
      0047FB F5 82            [12] 1187 	mov	dpl,a
      0047FD E4               [12] 1188 	clr	a
      0047FE 34 05            [12] 1189 	addc	a,#(_candidate>>8)
      004800 F5 83            [12] 1190 	mov	dph,a
      004802 E0               [24] 1191 	movx	a,@dptr
      004803 22               [24] 1192 	ret
                                   1193 
                                   1194 	.area CSEG (CODE)
                                   1195 ; function ak820_outline_0113
      004804                       1196 _ak820_outline_0113:
      004804 C3               [12] 1197 	clr	c
      004805 74 FF            [12] 1198 	mov	a,#0xff
      004807 9C               [12] 1199 	subb	a,r4
      004808 E4               [12] 1200 	clr	a
      004809 9D               [12] 1201 	subb	a,r5
      00480A 22               [24] 1202 	ret
                                   1203 
                                   1204 	.area CSEG (CODE)
                                   1205 ; function ak820_outline_0143
      00480B                       1206 _ak820_outline_0143:
      00480B F0               [24] 1207 	movx	@dptr,a
      00480C E5 F0            [12] 1208 	mov	a,b
      00480E A3               [24] 1209 	inc	dptr
      00480F F0               [24] 1210 	movx	@dptr,a
      004810 22               [24] 1211 	ret
