                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_combo
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_settings_combo_term
                                     12 	.globl _dynamic_keymap_get_combo
                                     13 	.globl _process_record
                                     14 	.globl _ADC_START
                                     15 	.globl _S0_R_FIFO
                                     16 	.globl _S0_T_FIFO
                                     17 	.globl _S0_FREE
                                     18 	.globl _S0_IF_BYTE
                                     19 	.globl _S0_IF_FIRST
                                     20 	.globl _S0_IF_OV
                                     21 	.globl _S0_FST_ACT
                                     22 	.globl _CP_RL2
                                     23 	.globl _C_T2
                                     24 	.globl _TR2
                                     25 	.globl _EXEN2
                                     26 	.globl _TCLK
                                     27 	.globl _RCLK
                                     28 	.globl _EXF2
                                     29 	.globl _CAP1F
                                     30 	.globl _TF2
                                     31 	.globl _RI
                                     32 	.globl _TI
                                     33 	.globl _RB8
                                     34 	.globl _TB8
                                     35 	.globl _REN
                                     36 	.globl _SM2
                                     37 	.globl _SM1
                                     38 	.globl _SM0
                                     39 	.globl _IT0
                                     40 	.globl _IE0
                                     41 	.globl _IT1
                                     42 	.globl _IE1
                                     43 	.globl _TR0
                                     44 	.globl _TF0
                                     45 	.globl _TR1
                                     46 	.globl _TF1
                                     47 	.globl _P4_0
                                     48 	.globl _P4_1
                                     49 	.globl _P4_2
                                     50 	.globl _P4_3
                                     51 	.globl _P4_4
                                     52 	.globl _P4_5
                                     53 	.globl _P4_6
                                     54 	.globl _RXD
                                     55 	.globl _TXD
                                     56 	.globl _INT0
                                     57 	.globl _INT1
                                     58 	.globl _T0
                                     59 	.globl _T1
                                     60 	.globl _MOSI1
                                     61 	.globl _MISO1
                                     62 	.globl _SCK1
                                     63 	.globl _P3_0
                                     64 	.globl _P3_1
                                     65 	.globl _P3_2
                                     66 	.globl _P3_3
                                     67 	.globl _P3_4
                                     68 	.globl _P3_5
                                     69 	.globl _P3_6
                                     70 	.globl _P3_7
                                     71 	.globl _CAP1_
                                     72 	.globl _T2_
                                     73 	.globl _CAP2_
                                     74 	.globl _T2EX_
                                     75 	.globl _RXD1
                                     76 	.globl _TXD1
                                     77 	.globl _P2_0
                                     78 	.globl _P2_1
                                     79 	.globl _P2_2
                                     80 	.globl _P2_3
                                     81 	.globl _P2_4
                                     82 	.globl _P2_5
                                     83 	.globl _P2_6
                                     84 	.globl _P2_7
                                     85 	.globl _AIN0
                                     86 	.globl _AIN1
                                     87 	.globl _AIN2
                                     88 	.globl _AIN3
                                     89 	.globl _AIN4
                                     90 	.globl _AIN5
                                     91 	.globl _AIN6
                                     92 	.globl _AIN7
                                     93 	.globl _CAP1
                                     94 	.globl _T2
                                     95 	.globl _CAP2
                                     96 	.globl _T2EX
                                     97 	.globl _INT0_
                                     98 	.globl _SCS
                                     99 	.globl _MOSI
                                    100 	.globl _MISO
                                    101 	.globl _SCK
                                    102 	.globl _RXD1_
                                    103 	.globl _TXD1_
                                    104 	.globl _P1_0
                                    105 	.globl _P1_1
                                    106 	.globl _P1_2
                                    107 	.globl _P1_3
                                    108 	.globl _P1_4
                                    109 	.globl _P1_5
                                    110 	.globl _P1_6
                                    111 	.globl _P1_7
                                    112 	.globl _AIN8
                                    113 	.globl _AIN9
                                    114 	.globl _AIN10
                                    115 	.globl _AIN11
                                    116 	.globl _AIN12
                                    117 	.globl _AIN13
                                    118 	.globl _RXD_
                                    119 	.globl _TXD_
                                    120 	.globl _SCL0
                                    121 	.globl _SDA0
                                    122 	.globl _P0_0
                                    123 	.globl _P0_1
                                    124 	.globl _P0_2
                                    125 	.globl _P0_3
                                    126 	.globl _P0_4
                                    127 	.globl _P0_5
                                    128 	.globl _P0_6
                                    129 	.globl _P0_7
                                    130 	.globl _IE_SPI0
                                    131 	.globl _IE_USB
                                    132 	.globl _IE_ADC
                                    133 	.globl _IE_UART1
                                    134 	.globl _IE_PWM_I2C
                                    135 	.globl _IE_GPIO
                                    136 	.globl _IE_WDOG
                                    137 	.globl _PX0
                                    138 	.globl _PT0
                                    139 	.globl _PX1
                                    140 	.globl _PT1
                                    141 	.globl _PS
                                    142 	.globl _PT2
                                    143 	.globl _PL_FLAG
                                    144 	.globl _PH_FLAG
                                    145 	.globl _EX0
                                    146 	.globl _ET0
                                    147 	.globl _EX1
                                    148 	.globl _ET1
                                    149 	.globl _ES
                                    150 	.globl _ET2
                                    151 	.globl _E_DIS
                                    152 	.globl _EA
                                    153 	.globl _P
                                    154 	.globl _F1
                                    155 	.globl _OV
                                    156 	.globl _RS0
                                    157 	.globl _RS1
                                    158 	.globl _F0
                                    159 	.globl _AC
                                    160 	.globl _CY
                                    161 	.globl _I2CS_INT_ST
                                    162 	.globl _I2CX_INT
                                    163 	.globl _LED_STATUS
                                    164 	.globl _LED_DMA_H
                                    165 	.globl _LED_DMA_L
                                    166 	.globl _LED_DMA
                                    167 	.globl _LED_PWM_OE
                                    168 	.globl _LED_COMMON
                                    169 	.globl _ADC_CHAN
                                    170 	.globl _ADC_DAT_H
                                    171 	.globl _ADC_DAT_L
                                    172 	.globl _ADC_DAT
                                    173 	.globl _ADC_CTRL
                                    174 	.globl _SPI1_CK_SE
                                    175 	.globl _SPI1_CTRL
                                    176 	.globl _SPI1_DATA
                                    177 	.globl _SPI1_STAT
                                    178 	.globl _SIF1
                                    179 	.globl _SBAUD1
                                    180 	.globl _SBUF1
                                    181 	.globl _SCON1
                                    182 	.globl _SPI0_SETUP
                                    183 	.globl _SPI0_CK_SE
                                    184 	.globl _SPI0_CTRL
                                    185 	.globl _SPI0_DATA
                                    186 	.globl _SPI0_STAT
                                    187 	.globl _T2CAP1H
                                    188 	.globl _T2CAP1L
                                    189 	.globl _T2CAP1
                                    190 	.globl _TH2
                                    191 	.globl _TL2
                                    192 	.globl _T2COUNT
                                    193 	.globl _RCAP2H
                                    194 	.globl _RCAP2L
                                    195 	.globl _RCAP2
                                    196 	.globl _T2MOD
                                    197 	.globl _T2CON
                                    198 	.globl _SBUF
                                    199 	.globl _SCON
                                    200 	.globl _TH1
                                    201 	.globl _TH0
                                    202 	.globl _TL1
                                    203 	.globl _TL0
                                    204 	.globl _TMOD
                                    205 	.globl _TCON
                                    206 	.globl _XBUS_AUX
                                    207 	.globl _P7
                                    208 	.globl _P6_DIR
                                    209 	.globl _P6_OUT_PU
                                    210 	.globl _P6_IN
                                    211 	.globl _P5_DIR
                                    212 	.globl _P5_OUT_PU
                                    213 	.globl _P5_IN
                                    214 	.globl _P4_LED_KEY
                                    215 	.globl _P4_DIR_PU
                                    216 	.globl _P4_MOD_OC
                                    217 	.globl _P4
                                    218 	.globl _P3_DIR_PU
                                    219 	.globl _P3_MOD_OC
                                    220 	.globl _P3
                                    221 	.globl _P2_DIR_PU
                                    222 	.globl _P2_MOD_OC
                                    223 	.globl _P2
                                    224 	.globl _P1_DIR_PU
                                    225 	.globl _P1_MOD_OC
                                    226 	.globl _P1
                                    227 	.globl _P0_DIR_PU
                                    228 	.globl _P0_MOD_OC
                                    229 	.globl _P0
                                    230 	.globl _ROM_CTRL
                                    231 	.globl _ROM_DATA_HH
                                    232 	.globl _ROM_DATA_HL
                                    233 	.globl _ROM_DATA_HI
                                    234 	.globl _ROM_ADDR_H
                                    235 	.globl _ROM_ADDR_L
                                    236 	.globl _ROM_ADDR
                                    237 	.globl _GPIO_IE
                                    238 	.globl _IP_EX
                                    239 	.globl _IE_EX
                                    240 	.globl _IP
                                    241 	.globl _IE
                                    242 	.globl _WDOG_COUNT
                                    243 	.globl _RESET_KEEP
                                    244 	.globl _WAKE_CTRL
                                    245 	.globl _CLOCK_CFG
                                    246 	.globl _POWER_CFG
                                    247 	.globl _PCON
                                    248 	.globl _GLOBAL_CFG
                                    249 	.globl _SAFE_MOD
                                    250 	.globl _DPH
                                    251 	.globl _DPL
                                    252 	.globl _SP
                                    253 	.globl _A_INV
                                    254 	.globl _B
                                    255 	.globl _ACC
                                    256 	.globl _PSW
                                    257 	.globl _ak820_combo_valid
                                    258 	.globl _ak820_combo_cancel
                                    259 	.globl _ak820_combo_reload
                                    260 	.globl _ak820_combo_tick
                                    261 	.globl _ak820_combo_process
                                    262 ;--------------------------------------------------------
                                    263 ; special function registers
                                    264 ;--------------------------------------------------------
                                    265 	.area RSEG    (ABS,DATA)
      000000                        266 	.org 0x0000
                           0000D0   267 _PSW	=	0x00d0
                           0000E0   268 _ACC	=	0x00e0
                           0000F0   269 _B	=	0x00f0
                           0000FD   270 _A_INV	=	0x00fd
                           000081   271 _SP	=	0x0081
                           000082   272 _DPL	=	0x0082
                           000083   273 _DPH	=	0x0083
                           0000A1   274 _SAFE_MOD	=	0x00a1
                           0000B1   275 _GLOBAL_CFG	=	0x00b1
                           000087   276 _PCON	=	0x0087
                           0000BA   277 _POWER_CFG	=	0x00ba
                           0000B9   278 _CLOCK_CFG	=	0x00b9
                           0000A9   279 _WAKE_CTRL	=	0x00a9
                           0000FE   280 _RESET_KEEP	=	0x00fe
                           0000FF   281 _WDOG_COUNT	=	0x00ff
                           0000A8   282 _IE	=	0x00a8
                           0000B8   283 _IP	=	0x00b8
                           0000E8   284 _IE_EX	=	0x00e8
                           0000E9   285 _IP_EX	=	0x00e9
                           0000B2   286 _GPIO_IE	=	0x00b2
                           008584   287 _ROM_ADDR	=	0x8584
                           000084   288 _ROM_ADDR_L	=	0x0084
                           000085   289 _ROM_ADDR_H	=	0x0085
                           008F8E   290 _ROM_DATA_HI	=	0x8f8e
                           00008E   291 _ROM_DATA_HL	=	0x008e
                           00008F   292 _ROM_DATA_HH	=	0x008f
                           000086   293 _ROM_CTRL	=	0x0086
                           000080   294 _P0	=	0x0080
                           0000C4   295 _P0_MOD_OC	=	0x00c4
                           0000C5   296 _P0_DIR_PU	=	0x00c5
                           000090   297 _P1	=	0x0090
                           000092   298 _P1_MOD_OC	=	0x0092
                           000093   299 _P1_DIR_PU	=	0x0093
                           0000A0   300 _P2	=	0x00a0
                           000094   301 _P2_MOD_OC	=	0x0094
                           000095   302 _P2_DIR_PU	=	0x0095
                           0000B0   303 _P3	=	0x00b0
                           000096   304 _P3_MOD_OC	=	0x0096
                           000097   305 _P3_DIR_PU	=	0x0097
                           0000C0   306 _P4	=	0x00c0
                           0000C2   307 _P4_MOD_OC	=	0x00c2
                           0000C3   308 _P4_DIR_PU	=	0x00c3
                           0000C1   309 _P4_LED_KEY	=	0x00c1
                           0000AA   310 _P5_IN	=	0x00aa
                           0000AB   311 _P5_OUT_PU	=	0x00ab
                           0000AC   312 _P5_DIR	=	0x00ac
                           0000AD   313 _P6_IN	=	0x00ad
                           0000AE   314 _P6_OUT_PU	=	0x00ae
                           0000AF   315 _P6_DIR	=	0x00af
                           0000F1   316 _P7	=	0x00f1
                           0000A2   317 _XBUS_AUX	=	0x00a2
                           000088   318 _TCON	=	0x0088
                           000089   319 _TMOD	=	0x0089
                           00008A   320 _TL0	=	0x008a
                           00008B   321 _TL1	=	0x008b
                           00008C   322 _TH0	=	0x008c
                           00008D   323 _TH1	=	0x008d
                           000098   324 _SCON	=	0x0098
                           000099   325 _SBUF	=	0x0099
                           0000C8   326 _T2CON	=	0x00c8
                           0000C9   327 _T2MOD	=	0x00c9
                           00CBCA   328 _RCAP2	=	0xcbca
                           0000CA   329 _RCAP2L	=	0x00ca
                           0000CB   330 _RCAP2H	=	0x00cb
                           00CDCC   331 _T2COUNT	=	0xcdcc
                           0000CC   332 _TL2	=	0x00cc
                           0000CD   333 _TH2	=	0x00cd
                           00CFCE   334 _T2CAP1	=	0xcfce
                           0000CE   335 _T2CAP1L	=	0x00ce
                           0000CF   336 _T2CAP1H	=	0x00cf
                           0000F8   337 _SPI0_STAT	=	0x00f8
                           0000F9   338 _SPI0_DATA	=	0x00f9
                           0000FA   339 _SPI0_CTRL	=	0x00fa
                           0000FB   340 _SPI0_CK_SE	=	0x00fb
                           0000FC   341 _SPI0_SETUP	=	0x00fc
                           0000BC   342 _SCON1	=	0x00bc
                           0000BD   343 _SBUF1	=	0x00bd
                           0000BE   344 _SBAUD1	=	0x00be
                           0000BF   345 _SIF1	=	0x00bf
                           0000B4   346 _SPI1_STAT	=	0x00b4
                           0000B5   347 _SPI1_DATA	=	0x00b5
                           0000B6   348 _SPI1_CTRL	=	0x00b6
                           0000B7   349 _SPI1_CK_SE	=	0x00b7
                           0000F3   350 _ADC_CTRL	=	0x00f3
                           00F5F4   351 _ADC_DAT	=	0xf5f4
                           0000F4   352 _ADC_DAT_L	=	0x00f4
                           0000F5   353 _ADC_DAT_H	=	0x00f5
                           0000F6   354 _ADC_CHAN	=	0x00f6
                           0000A6   355 _LED_COMMON	=	0x00a6
                           0000A7   356 _LED_PWM_OE	=	0x00a7
                           00C7C6   357 _LED_DMA	=	0xc7c6
                           0000C6   358 _LED_DMA_L	=	0x00c6
                           0000C7   359 _LED_DMA_H	=	0x00c7
                           0000F7   360 _LED_STATUS	=	0x00f7
                           0000B3   361 _I2CX_INT	=	0x00b3
                           0000BB   362 _I2CS_INT_ST	=	0x00bb
                                    363 ;--------------------------------------------------------
                                    364 ; special function bits
                                    365 ;--------------------------------------------------------
                                    366 	.area RSEG    (ABS,DATA)
      000000                        367 	.org 0x0000
                           0000D7   368 _CY	=	0x00d7
                           0000D6   369 _AC	=	0x00d6
                           0000D5   370 _F0	=	0x00d5
                           0000D4   371 _RS1	=	0x00d4
                           0000D3   372 _RS0	=	0x00d3
                           0000D2   373 _OV	=	0x00d2
                           0000D1   374 _F1	=	0x00d1
                           0000D0   375 _P	=	0x00d0
                           0000AF   376 _EA	=	0x00af
                           0000AE   377 _E_DIS	=	0x00ae
                           0000AD   378 _ET2	=	0x00ad
                           0000AC   379 _ES	=	0x00ac
                           0000AB   380 _ET1	=	0x00ab
                           0000AA   381 _EX1	=	0x00aa
                           0000A9   382 _ET0	=	0x00a9
                           0000A8   383 _EX0	=	0x00a8
                           0000BF   384 _PH_FLAG	=	0x00bf
                           0000BE   385 _PL_FLAG	=	0x00be
                           0000BD   386 _PT2	=	0x00bd
                           0000BC   387 _PS	=	0x00bc
                           0000BB   388 _PT1	=	0x00bb
                           0000BA   389 _PX1	=	0x00ba
                           0000B9   390 _PT0	=	0x00b9
                           0000B8   391 _PX0	=	0x00b8
                           0000EF   392 _IE_WDOG	=	0x00ef
                           0000EE   393 _IE_GPIO	=	0x00ee
                           0000ED   394 _IE_PWM_I2C	=	0x00ed
                           0000EC   395 _IE_UART1	=	0x00ec
                           0000EB   396 _IE_ADC	=	0x00eb
                           0000E9   397 _IE_USB	=	0x00e9
                           0000E8   398 _IE_SPI0	=	0x00e8
                           000087   399 _P0_7	=	0x0087
                           000086   400 _P0_6	=	0x0086
                           000085   401 _P0_5	=	0x0085
                           000084   402 _P0_4	=	0x0084
                           000083   403 _P0_3	=	0x0083
                           000082   404 _P0_2	=	0x0082
                           000081   405 _P0_1	=	0x0081
                           000080   406 _P0_0	=	0x0080
                           000081   407 _SDA0	=	0x0081
                           000080   408 _SCL0	=	0x0080
                           000083   409 _TXD_	=	0x0083
                           000082   410 _RXD_	=	0x0082
                           000085   411 _AIN13	=	0x0085
                           000084   412 _AIN12	=	0x0084
                           000083   413 _AIN11	=	0x0083
                           000082   414 _AIN10	=	0x0082
                           000081   415 _AIN9	=	0x0081
                           000080   416 _AIN8	=	0x0080
                           000097   417 _P1_7	=	0x0097
                           000096   418 _P1_6	=	0x0096
                           000095   419 _P1_5	=	0x0095
                           000094   420 _P1_4	=	0x0094
                           000093   421 _P1_3	=	0x0093
                           000092   422 _P1_2	=	0x0092
                           000091   423 _P1_1	=	0x0091
                           000090   424 _P1_0	=	0x0090
                           000097   425 _TXD1_	=	0x0097
                           000096   426 _RXD1_	=	0x0096
                           000097   427 _SCK	=	0x0097
                           000096   428 _MISO	=	0x0096
                           000095   429 _MOSI	=	0x0095
                           000094   430 _SCS	=	0x0094
                           000092   431 _INT0_	=	0x0092
                           000091   432 _T2EX	=	0x0091
                           000091   433 _CAP2	=	0x0091
                           000090   434 _T2	=	0x0090
                           000090   435 _CAP1	=	0x0090
                           000097   436 _AIN7	=	0x0097
                           000096   437 _AIN6	=	0x0096
                           000095   438 _AIN5	=	0x0095
                           000094   439 _AIN4	=	0x0094
                           000093   440 _AIN3	=	0x0093
                           000092   441 _AIN2	=	0x0092
                           000091   442 _AIN1	=	0x0091
                           000090   443 _AIN0	=	0x0090
                           0000A7   444 _P2_7	=	0x00a7
                           0000A6   445 _P2_6	=	0x00a6
                           0000A5   446 _P2_5	=	0x00a5
                           0000A4   447 _P2_4	=	0x00a4
                           0000A3   448 _P2_3	=	0x00a3
                           0000A2   449 _P2_2	=	0x00a2
                           0000A1   450 _P2_1	=	0x00a1
                           0000A0   451 _P2_0	=	0x00a0
                           0000A7   452 _TXD1	=	0x00a7
                           0000A6   453 _RXD1	=	0x00a6
                           0000A5   454 _T2EX_	=	0x00a5
                           0000A5   455 _CAP2_	=	0x00a5
                           0000A4   456 _T2_	=	0x00a4
                           0000A4   457 _CAP1_	=	0x00a4
                           0000B7   458 _P3_7	=	0x00b7
                           0000B6   459 _P3_6	=	0x00b6
                           0000B5   460 _P3_5	=	0x00b5
                           0000B4   461 _P3_4	=	0x00b4
                           0000B3   462 _P3_3	=	0x00b3
                           0000B2   463 _P3_2	=	0x00b2
                           0000B1   464 _P3_1	=	0x00b1
                           0000B0   465 _P3_0	=	0x00b0
                           0000B7   466 _SCK1	=	0x00b7
                           0000B6   467 _MISO1	=	0x00b6
                           0000B5   468 _MOSI1	=	0x00b5
                           0000B5   469 _T1	=	0x00b5
                           0000B4   470 _T0	=	0x00b4
                           0000B3   471 _INT1	=	0x00b3
                           0000B2   472 _INT0	=	0x00b2
                           0000B1   473 _TXD	=	0x00b1
                           0000B0   474 _RXD	=	0x00b0
                           0000C6   475 _P4_6	=	0x00c6
                           0000C5   476 _P4_5	=	0x00c5
                           0000C4   477 _P4_4	=	0x00c4
                           0000C3   478 _P4_3	=	0x00c3
                           0000C2   479 _P4_2	=	0x00c2
                           0000C1   480 _P4_1	=	0x00c1
                           0000C0   481 _P4_0	=	0x00c0
                           00008F   482 _TF1	=	0x008f
                           00008E   483 _TR1	=	0x008e
                           00008D   484 _TF0	=	0x008d
                           00008C   485 _TR0	=	0x008c
                           00008B   486 _IE1	=	0x008b
                           00008A   487 _IT1	=	0x008a
                           000089   488 _IE0	=	0x0089
                           000088   489 _IT0	=	0x0088
                           00009F   490 _SM0	=	0x009f
                           00009E   491 _SM1	=	0x009e
                           00009D   492 _SM2	=	0x009d
                           00009C   493 _REN	=	0x009c
                           00009B   494 _TB8	=	0x009b
                           00009A   495 _RB8	=	0x009a
                           000099   496 _TI	=	0x0099
                           000098   497 _RI	=	0x0098
                           0000CF   498 _TF2	=	0x00cf
                           0000CF   499 _CAP1F	=	0x00cf
                           0000CE   500 _EXF2	=	0x00ce
                           0000CD   501 _RCLK	=	0x00cd
                           0000CC   502 _TCLK	=	0x00cc
                           0000CB   503 _EXEN2	=	0x00cb
                           0000CA   504 _TR2	=	0x00ca
                           0000C9   505 _C_T2	=	0x00c9
                           0000C8   506 _CP_RL2	=	0x00c8
                           0000FF   507 _S0_FST_ACT	=	0x00ff
                           0000FE   508 _S0_IF_OV	=	0x00fe
                           0000FD   509 _S0_IF_FIRST	=	0x00fd
                           0000FC   510 _S0_IF_BYTE	=	0x00fc
                           0000FB   511 _S0_FREE	=	0x00fb
                           0000FA   512 _S0_T_FIFO	=	0x00fa
                           0000F8   513 _S0_R_FIFO	=	0x00f8
                           0000F7   514 _ADC_START	=	0x00f7
                                    515 ;--------------------------------------------------------
                                    516 ; overlayable register banks
                                    517 ;--------------------------------------------------------
                                    518 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        519 	.ds 8
                                    520 ;--------------------------------------------------------
                                    521 ; internal ram data
                                    522 ;--------------------------------------------------------
                                    523 	.area DSEG    (DATA)
                                    524 ;--------------------------------------------------------
                                    525 ; overlayable items in internal ram
                                    526 ;--------------------------------------------------------
                                    527 ;--------------------------------------------------------
                                    528 ; indirectly addressable internal ram data
                                    529 ;--------------------------------------------------------
                                    530 	.area ISEG    (DATA)
                                    531 ;--------------------------------------------------------
                                    532 ; absolute internal ram data
                                    533 ;--------------------------------------------------------
                                    534 	.area IABS    (ABS,DATA)
                                    535 	.area IABS    (ABS,DATA)
                                    536 ;--------------------------------------------------------
                                    537 ; bit data
                                    538 ;--------------------------------------------------------
                                    539 	.area BSEG    (BIT)
      000000                        540 _ak820_combo_valid_sloc0_1_0:
      000000                        541 	.ds 1
      000001                        542 _ak820_combo_process_sloc0_1_0:
      000001                        543 	.ds 1
                                    544 ;--------------------------------------------------------
                                    545 ; paged external ram data
                                    546 ;--------------------------------------------------------
                                    547 	.area PSEG    (PAG,XDATA)
                                    548 ;--------------------------------------------------------
                                    549 ; uninitialized external ram data
                                    550 ;--------------------------------------------------------
                                    551 	.area XSEG    (XDATA)
      000422                        552 _combos:
      000422                        553 	.ds 32
      000442                        554 _saved:
      000442                        555 	.ds 9
      00044B                        556 _active:
      00044B                        557 	.ds 1
      00044C                        558 _ak820_combo_valid_entry_10000_616:
      00044C                        559 	.ds 2
      00044E                        560 _ak820_combo_reload_entry_30000_628:
      00044E                        561 	.ds 10
      000458                        562 _ak820_combo_tick_now_10000_633:
      000458                        563 	.ds 2
      00045A                        564 _ak820_combo_process_record_10000_636:
      00045A                        565 	.ds 2
      00045C                        566 _ak820_combo_process_eligible_10001_651:
      00045C                        567 	.ds 1
      00045D                        568 _ak820_combo_process_i_40001_654:
      00045D                        569 	.ds 1
      00045E                        570 _ak820_combo_process_a_50001_655:
      00045E                        571 	.ds 1
      00045F                        572 _ak820_combo_process_b_50001_655:
      00045F                        573 	.ds 1
                                    574 ;--------------------------------------------------------
                                    575 ; absolute external ram data
                                    576 ;--------------------------------------------------------
                                    577 	.area XABS    (ABS,XDATA)
                                    578 ;--------------------------------------------------------
                                    579 ; initialized external ram data
                                    580 ;--------------------------------------------------------
                                    581 	.area XISEG   (XDATA)
      000DD3                        582 _first:
      000DD3                        583 	.ds 1
      000DD4                        584 _second:
      000DD4                        585 	.ds 1
                                    586 	.area HOME    (CODE)
                                    587 	.area GSINIT0 (CODE)
                                    588 	.area GSINIT1 (CODE)
                                    589 	.area GSINIT2 (CODE)
                                    590 	.area GSINIT3 (CODE)
                                    591 	.area GSINIT4 (CODE)
                                    592 	.area GSINIT5 (CODE)
                                    593 	.area GSINIT  (CODE)
                                    594 	.area GSFINAL (CODE)
                                    595 	.area CSEG    (CODE)
                                    596 ;--------------------------------------------------------
                                    597 ; global & static initialisations
                                    598 ;--------------------------------------------------------
                                    599 	.area HOME    (CODE)
                                    600 	.area GSINIT  (CODE)
                                    601 	.area GSFINAL (CODE)
                                    602 	.area GSINIT  (CODE)
                                    603 ;--------------------------------------------------------
                                    604 ; Home
                                    605 ;--------------------------------------------------------
                                    606 	.area HOME    (CODE)
                                    607 	.area HOME    (CODE)
                                    608 ;--------------------------------------------------------
                                    609 ; code
                                    610 ;--------------------------------------------------------
                                    611 	.area CSEG    (CODE)
                                    612 ;------------------------------------------------------------
                                    613 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    614 ;------------------------------------------------------------
                                    615 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    616 ;------------------------------------------------------------
                                    617 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    618 ;	-----------------------------------------
                           000007   619 	ar7 = 0x07
                           000006   620 	ar6 = 0x06
                           000005   621 	ar5 = 0x05
                           000004   622 	ar4 = 0x04
                           000003   623 	ar3 = 0x03
                           000002   624 	ar2 = 0x02
                           000001   625 	ar1 = 0x01
                           000000   626 	ar0 = 0x00
                                    627 ;	 function ak820_combo_valid
                                    628 ;	-----------------------------------------
      003468                        629 _ak820_combo_valid:
      003468 12 38 5B         [24]  630 	lcall	_ak820_outline_0106
      00346B 90 04 4C         [24]  631 	mov	dptr,#_ak820_combo_valid_entry_10000_616
      00346E 12 38 60         [24]  632 	lcall	_ak820_outline_0107
                                    633 ;	keyboards/ajazz/ak820/ak820_combo.c:24: if (entry->input[2] || entry->input[3]) return false;
      003471 90 04 4C         [24]  634 	mov	dptr,#_ak820_combo_valid_entry_10000_616
      003474 12 37 AE         [24]  635 	lcall	_ak820_outline_0004
      003477 A3               [24]  636 	inc	dptr
      003478 A3               [24]  637 	inc	dptr
      003479 A3               [24]  638 	inc	dptr
      00347A A3               [24]  639 	inc	dptr
      00347B 12 38 74         [24]  640 	lcall	_ak820_outline_0145
      00347E 70 0A            [24]  641 	jnz	00101$
      003480 74 06            [12]  642 	mov	a,#0x06
      003482 12 37 F5         [24]  643 	lcall	_ak820_outline_0017
      003485 12 38 74         [24]  644 	lcall	_ak820_outline_0145
      003488 60 04            [24]  645 	jz	00102$
      00348A                        646 00101$:
      00348A 75 82 00         [24]  647 	mov	dpl, #0x00
      00348D 22               [24]  648 	ret
      00348E                        649 00102$:
                                    650 ;	keyboards/ajazz/ak820/ak820_combo.c:25: if (!(entry->input[0] | entry->input[1])) return !entry->output;
      00348E 8E 04            [24]  651 	mov	ar4,r6
      003490 8F 05            [24]  652 	mov	ar5,r7
      003492 12 37 FD         [24]  653 	lcall	_ak820_outline_0034
      003495 FA               [12]  654 	mov	r2,a
      003496 A3               [24]  655 	inc	dptr
      003497 E0               [24]  656 	movx	a,@dptr
      003498 FB               [12]  657 	mov	r3,a
      003499 12 38 65         [24]  658 	lcall	_ak820_outline_0125
      00349C 12 38 24         [24]  659 	lcall	_ak820_outline_0059
      00349F EA               [12]  660 	mov	a,r2
      0034A0 4C               [12]  661 	orl	a,r4
      0034A1 F8               [12]  662 	mov	r0,a
      0034A2 EB               [12]  663 	mov	a,r3
      0034A3 4D               [12]  664 	orl	a,r5
      0034A4 48               [12]  665 	orl	a,r0
      0034A5 70 13            [24]  666 	jnz	00105$
      0034A7 74 08            [12]  667 	mov	a,#0x08
      0034A9 12 37 F5         [24]  668 	lcall	_ak820_outline_0017
      0034AC E0               [24]  669 	movx	a,@dptr
      0034AD F8               [12]  670 	mov	r0,a
      0034AE A3               [24]  671 	inc	dptr
      0034AF E0               [24]  672 	movx	a,@dptr
      0034B0 48               [12]  673 	orl	a,r0
      0034B1 B4 01 00         [24]  674 	cjne	a,#0x01,00187$
      0034B4                        675 00187$:
      0034B4 92 00            [24]  676 	mov  _ak820_combo_valid_sloc0_1_0,c
      0034B6 12 38 84         [24]  677 	lcall	_ak820_outline_0160
      0034B9 22               [24]  678 	ret
      0034BA                        679 00105$:
                                    680 ;	keyboards/ajazz/ak820/ak820_combo.c:26: if (entry->input[0] == entry->input[1]) return false;
      0034BA EC               [12]  681 	mov	a,r4
      0034BB B5 02 08         [24]  682 	cjne	a,ar2,00107$
      0034BE ED               [12]  683 	mov	a,r5
      0034BF B5 03 04         [24]  684 	cjne	a,ar3,00107$
      0034C2 75 82 00         [24]  685 	mov	dpl, #0x00
      0034C5 22               [24]  686 	ret
      0034C6                        687 00107$:
                                    688 ;	keyboards/ajazz/ak820/ak820_combo.c:27: if (!COMBO_INPUT(entry->input[0])) return false;
      0034C6 C3               [12]  689 	clr	c
      0034C7 EC               [12]  690 	mov	a,r4
      0034C8 94 04            [12]  691 	subb	a,#0x04
      0034CA ED               [12]  692 	mov	a,r5
      0034CB 94 00            [12]  693 	subb	a,#0x00
      0034CD 40 07            [24]  694 	jc	00108$
      0034CF 74 A4            [12]  695 	mov	a,#0xa4
      0034D1 9C               [12]  696 	subb	a,r4
      0034D2 E4               [12]  697 	clr	a
      0034D3 9D               [12]  698 	subb	a,r5
      0034D4 50 04            [24]  699 	jnc	00109$
                                    700 ;	free result
      0034D6                        701 00108$:
      0034D6 75 82 00         [24]  702 	mov	dpl, #0x00
      0034D9 22               [24]  703 	ret
      0034DA                        704 00109$:
                                    705 ;	keyboards/ajazz/ak820/ak820_combo.c:28: if (!COMBO_INPUT(entry->input[1])) return false;
      0034DA C3               [12]  706 	clr	c
      0034DB EA               [12]  707 	mov	a,r2
      0034DC 94 04            [12]  708 	subb	a,#0x04
      0034DE EB               [12]  709 	mov	a,r3
      0034DF 94 00            [12]  710 	subb	a,#0x00
      0034E1 40 07            [24]  711 	jc	00111$
      0034E3 74 A4            [12]  712 	mov	a,#0xa4
      0034E5 9A               [12]  713 	subb	a,r2
      0034E6 E4               [12]  714 	clr	a
      0034E7 9B               [12]  715 	subb	a,r3
      0034E8 50 04            [24]  716 	jnc	00112$
                                    717 ;	free result
      0034EA                        718 00111$:
      0034EA 75 82 00         [24]  719 	mov	dpl, #0x00
      0034ED 22               [24]  720 	ret
      0034EE                        721 00112$:
                                    722 ;	keyboards/ajazz/ak820/ak820_combo.c:29: return COMBO_OUTPUT(entry->output);
      0034EE 74 08            [12]  723 	mov	a,#0x08
      0034F0 12 37 F5         [24]  724 	lcall	_ak820_outline_0017
      0034F3 12 37 D9         [24]  725 	lcall	_ak820_outline_0010
      0034F6 74 E0            [12]  726 	mov	a,#0x100 - 0x20
      0034F8 2D               [12]  727 	add	a,r5
      0034F9 40 21            [24]  728 	jc	00116$
      0034FB BE 04 00         [24]  729 	cjne	r6,#0x04,00195$
      0034FE                        730 00195$:
      0034FE 40 05            [24]  731 	jc	00124$
      003500 EE               [12]  732 	mov	a,r6
      003501 24 5B            [12]  733 	add	a,#0xff - 0xa4
      003503 50 1B            [24]  734 	jnc	00117$
                                    735 ;	free result
      003505                        736 00124$:
      003505 90 04 4C         [24]  737 	mov	dptr,#_ak820_combo_valid_entry_10000_616
      003508 12 38 05         [24]  738 	lcall	_ak820_outline_0051
      00350B 74 08            [12]  739 	mov	a,#0x08
      00350D 12 37 F5         [24]  740 	lcall	_ak820_outline_0017
      003510 E0               [24]  741 	movx	a,@dptr
      003511 FF               [12]  742 	mov	r7,a
      003512 BF E0 00         [24]  743 	cjne	r7,#0xe0,00198$
      003515                        744 00198$:
      003515 40 05            [24]  745 	jc	00116$
      003517 EF               [12]  746 	mov	a,r7
      003518 24 18            [12]  747 	add	a,#0xff - 0xe7
      00351A 50 04            [24]  748 	jnc	00117$
                                    749 ;	free result
      00351C                        750 00116$:
                                    751 ;	assignBit
      00351C C2 00            [12]  752 	clr	_ak820_combo_valid_sloc0_1_0
      00351E 80 02            [24]  753 	sjmp	00118$
      003520                        754 00117$:
                                    755 ;	assignBit
      003520 D2 00            [12]  756 	setb	_ak820_combo_valid_sloc0_1_0
      003522                        757 00118$:
      003522 A2 00            [12]  758 	mov	c,_ak820_combo_valid_sloc0_1_0
      003524 12 38 84         [24]  759 	lcall	_ak820_outline_0160
                                    760 ;	keyboards/ajazz/ak820/ak820_combo.c:30: }
      003527 22               [24]  761 	ret
                                    762 ;------------------------------------------------------------
                                    763 ;Allocation info for local variables in function 'ak820_combo_cancel'
                                    764 ;------------------------------------------------------------
                                    765 ;	keyboards/ajazz/ak820/ak820_combo.c:33: void ak820_combo_cancel(void) { first = second = NONE; active = false; }
                                    766 ;	-----------------------------------------
                                    767 ;	 function ak820_combo_cancel
                                    768 ;	-----------------------------------------
      003528                        769 _ak820_combo_cancel:
      003528 90 0D D4         [24]  770 	mov	dptr,#_second
      00352B 74 FF            [12]  771 	mov	a,#0xff
      00352D F0               [24]  772 	movx	@dptr,a
      00352E 90 0D D3         [24]  773 	mov	dptr,#_first
      003531 F0               [24]  774 	movx	@dptr,a
      003532 90 04 4B         [24]  775 	mov	dptr,#_active
      003535 E4               [12]  776 	clr	a
      003536 F0               [24]  777 	movx	@dptr,a
      003537 22               [24]  778 	ret
                                    779 ;------------------------------------------------------------
                                    780 ;Allocation info for local variables in function 'ak820_combo_reload'
                                    781 ;------------------------------------------------------------
                                    782 ;i             Allocated with name '_ak820_combo_reload_i_20000_627'
                                    783 ;entry         Allocated with name '_ak820_combo_reload_entry_30000_628'
                                    784 ;------------------------------------------------------------
                                    785 ;	keyboards/ajazz/ak820/ak820_combo.c:34: void ak820_combo_reload(void) {
                                    786 ;	-----------------------------------------
                                    787 ;	 function ak820_combo_reload
                                    788 ;	-----------------------------------------
      003538                        789 _ak820_combo_reload:
                                    790 ;	keyboards/ajazz/ak820/ak820_combo.c:35: for (uint8_t i = 0; i < VIAL_COMBO_ENTRIES; ++i) {
      003538 7F 00            [12]  791 	mov	r7,#0x00
      00353A                        792 00105$:
      00353A BF 08 00         [24]  793 	cjne	r7,#0x08,00131$
      00353D                        794 00131$:
      00353D 40 01            [24]  795 	jc	00132$
      00353F 22               [24]  796 	ret
      003540                        797 00132$:
                                    798 ;	keyboards/ajazz/ak820/ak820_combo.c:37: combos[i].a = 0;
      003540 EF               [12]  799 	mov	a,r7
      003541 75 F0 04         [24]  800 	mov	b,#0x04
      003544 A4               [48]  801 	mul	ab
      003545 24 22            [12]  802 	add	a, #_combos
      003547 FD               [12]  803 	mov	r5,a
      003548 74 04            [12]  804 	mov	a,#(_combos >> 8)
      00354A 35 F0            [12]  805 	addc	a, b
      00354C FE               [12]  806 	mov	r6,a
      00354D 8D 03            [24]  807 	mov	ar3,r5
      00354F 8E 04            [24]  808 	mov	ar4,r6
      003551 12 33 FC         [24]  809 	lcall	_ak820_outline_0126
      003554 E4               [12]  810 	clr	a
      003555 F0               [24]  811 	movx	@dptr,a
                                    812 ;	keyboards/ajazz/ak820/ak820_combo.c:38: if (!dynamic_keymap_get_combo(i, &entry)) {
      003556 90 0B 2F         [24]  813 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      003559 74 4E            [12]  814 	mov	a,#_ak820_combo_reload_entry_30000_628
      00355B F0               [24]  815 	movx	@dptr,a
      00355C 74 04            [12]  816 	mov	a,#(_ak820_combo_reload_entry_30000_628 >> 8)
      00355E 12 38 37         [24]  817 	lcall	_ak820_outline_0084
      003561 8F 82            [24]  818 	mov	dpl, r7
      003563 C0 07            [24]  819 	push	ar7
      003565 C0 06            [24]  820 	push	ar6
      003567 C0 05            [24]  821 	push	ar5
      003569 C0 04            [24]  822 	push	ar4
      00356B C0 03            [24]  823 	push	ar3
      00356D 12 89 1F         [24]  824 	lcall	_dynamic_keymap_get_combo
      003570 12 38 49         [24]  825 	lcall	_ak820_outline_0101
      003573 D0 03            [24]  826 	pop	ar3
      003575 D0 04            [24]  827 	pop	ar4
      003577 D0 05            [24]  828 	pop	ar5
      003579 D0 06            [24]  829 	pop	ar6
      00357B D0 07            [24]  830 	pop	ar7
      00357D 45 F0            [12]  831 	orl	a,b
      00357F 70 28            [24]  832 	jnz	00106$
                                    833 ;	keyboards/ajazz/ak820/ak820_combo.c:39: combos[i].a = entry.input[0];
      003581 90 04 4E         [24]  834 	mov	dptr,#_ak820_combo_reload_entry_30000_628
      003584 E0               [24]  835 	movx	a,@dptr
      003585 12 33 FC         [24]  836 	lcall	_ak820_outline_0126
      003588 F0               [24]  837 	movx	@dptr,a
                                    838 ;	keyboards/ajazz/ak820/ak820_combo.c:40: combos[i].b = entry.input[1];
      003589 74 01            [12]  839 	mov	a,#0x01
      00358B 2D               [12]  840 	add	a, r5
      00358C FB               [12]  841 	mov	r3,a
      00358D E4               [12]  842 	clr	a
      00358E 3E               [12]  843 	addc	a, r6
      00358F FC               [12]  844 	mov	r4,a
      003590 90 04 50         [24]  845 	mov	dptr,#(_ak820_combo_reload_entry_30000_628 + 0x0002)
      003593 E0               [24]  846 	movx	a,@dptr
      003594 12 33 FC         [24]  847 	lcall	_ak820_outline_0126
      003597 F0               [24]  848 	movx	@dptr,a
                                    849 ;	keyboards/ajazz/ak820/ak820_combo.c:41: combos[i].output = entry.output;
      003598 74 02            [12]  850 	mov	a,#0x02
      00359A 12 38 89         [24]  851 	lcall	_ak820_outline_0163
      00359D 90 04 56         [24]  852 	mov	dptr,#(_ak820_combo_reload_entry_30000_628 + 0x0008)
      0035A0 12 38 55         [24]  853 	lcall	_ak820_outline_0105
      0035A3 12 38 6F         [24]  854 	lcall	_ak820_outline_0136
      0035A6 12 38 3D         [24]  855 	lcall	_ak820_outline_0085
      0035A9                        856 00106$:
                                    857 ;	keyboards/ajazz/ak820/ak820_combo.c:35: for (uint8_t i = 0; i < VIAL_COMBO_ENTRIES; ++i) {
      0035A9 0F               [12]  858 	inc	r7
                                    859 ;	keyboards/ajazz/ak820/ak820_combo.c:44: }
      0035AA 02 35 3A         [24]  860 	ljmp	00105$
                                    861 ;------------------------------------------------------------
                                    862 ;Allocation info for local variables in function 'flush'
                                    863 ;------------------------------------------------------------
                                    864 ;	keyboards/ajazz/ak820/ak820_combo.c:45: static void flush(void) {
                                    865 ;	-----------------------------------------
                                    866 ;	 function flush
                                    867 ;	-----------------------------------------
      0035AD                        868 _flush:
                                    869 ;	keyboards/ajazz/ak820/ak820_combo.c:46: first = NONE;
      0035AD 90 0D D3         [24]  870 	mov	dptr,#_first
      0035B0 74 FF            [12]  871 	mov	a,#0xff
      0035B2 F0               [24]  872 	movx	@dptr,a
                                    873 ;	keyboards/ajazz/ak820/ak820_combo.c:47: process_record(&saved);
      0035B3 90 04 42         [24]  874 	mov	dptr,#_saved
                                    875 ;	keyboards/ajazz/ak820/ak820_combo.c:48: }
      0035B6 02 74 ED         [24]  876 	ljmp	_process_record
                                    877 ;------------------------------------------------------------
                                    878 ;Allocation info for local variables in function 'ak820_combo_tick'
                                    879 ;------------------------------------------------------------
                                    880 ;now           Allocated with name '_ak820_combo_tick_now_10000_633'
                                    881 ;------------------------------------------------------------
                                    882 ;	keyboards/ajazz/ak820/ak820_combo.c:49: void ak820_combo_tick(uint16_t now) {
                                    883 ;	-----------------------------------------
                                    884 ;	 function ak820_combo_tick
                                    885 ;	-----------------------------------------
      0035B9                        886 _ak820_combo_tick:
      0035B9 12 38 5B         [24]  887 	lcall	_ak820_outline_0106
      0035BC 90 04 58         [24]  888 	mov	dptr,#_ak820_combo_tick_now_10000_633
      0035BF 12 38 60         [24]  889 	lcall	_ak820_outline_0107
                                    890 ;	keyboards/ajazz/ak820/ak820_combo.c:50: if (first != NONE && !active && (uint16_t)(now - saved.event.time) >= AK820_COMBO_TERM) flush();
      0035C2 12 38 8F         [24]  891 	lcall	_ak820_outline_0187
      0035C5 FF               [12]  892 	mov	r7,a
      0035C6 BF FF 01         [24]  893 	cjne	r7,#0xff,00128$
      0035C9 22               [24]  894 	ret
      0035CA                        895 00128$:
      0035CA 90 04 4B         [24]  896 	mov	dptr,#_active
      0035CD E0               [24]  897 	movx	a,@dptr
      0035CE 70 2B            [24]  898 	jnz	00105$
      0035D0 90 04 44         [24]  899 	mov	dptr,#(_saved + 0x0002)
      0035D3 12 38 05         [24]  900 	lcall	_ak820_outline_0051
      0035D6 90 04 58         [24]  901 	mov	dptr,#_ak820_combo_tick_now_10000_633
      0035D9 12 38 24         [24]  902 	lcall	_ak820_outline_0059
      0035DC EC               [12]  903 	mov	a,r4
      0035DD C3               [12]  904 	clr	c
      0035DE 9E               [12]  905 	subb	a,r6
      0035DF FE               [12]  906 	mov	r6,a
      0035E0 ED               [12]  907 	mov	a,r5
      0035E1 9F               [12]  908 	subb	a,r7
      0035E2 FF               [12]  909 	mov	r7,a
      0035E3 C0 07            [24]  910 	push	ar7
      0035E5 C0 06            [24]  911 	push	ar6
      0035E7 12 47 B4         [24]  912 	lcall	_ak820_settings_combo_term
      0035EA 12 38 7A         [24]  913 	lcall	_ak820_outline_0149
      0035ED D0 06            [24]  914 	pop	ar6
      0035EF D0 07            [24]  915 	pop	ar7
      0035F1 C3               [12]  916 	clr	c
      0035F2 EE               [12]  917 	mov	a,r6
      0035F3 9C               [12]  918 	subb	a,r4
      0035F4 EF               [12]  919 	mov	a,r7
      0035F5 9D               [12]  920 	subb	a,r5
      0035F6 40 03            [24]  921 	jc	00105$
                                    922 ;	keyboards/ajazz/ak820/ak820_combo.c:51: }
      0035F8 02 35 AD         [24]  923 	ljmp	_flush
      0035FB                        924 00105$:
      0035FB 22               [24]  925 	ret
                                    926 ;------------------------------------------------------------
                                    927 ;Allocation info for local variables in function 'ak820_combo_process'
                                    928 ;------------------------------------------------------------
                                    929 ;record        Allocated with name '_ak820_combo_process_record_10000_636'
                                    930 ;id            Allocated with name '_ak820_combo_process_id_10000_637'
                                    931 ;code          Allocated with name '_ak820_combo_process_code_10000_637'
                                    932 ;eligible      Allocated with name '_ak820_combo_process_eligible_10001_651'
                                    933 ;previous      Allocated with name '_ak820_combo_process_previous_30001_653'
                                    934 ;i             Allocated with name '_ak820_combo_process_i_40001_654'
                                    935 ;a             Allocated with name '_ak820_combo_process_a_50001_655'
                                    936 ;b             Allocated with name '_ak820_combo_process_b_50001_655'
                                    937 ;------------------------------------------------------------
                                    938 ;	keyboards/ajazz/ak820/ak820_combo.c:52: bool ak820_combo_process(keyrecord_t AK820_STATE_MEM *record) {
                                    939 ;	-----------------------------------------
                                    940 ;	 function ak820_combo_process
                                    941 ;	-----------------------------------------
      0035FC                        942 _ak820_combo_process:
      0035FC 12 38 5B         [24]  943 	lcall	_ak820_outline_0106
      0035FF 90 04 5A         [24]  944 	mov	dptr,#_ak820_combo_process_record_10000_636
      003602 12 38 60         [24]  945 	lcall	_ak820_outline_0107
                                    946 ;	keyboards/ajazz/ak820/ak820_combo.c:53: uint8_t id, code = record->keycode;
      003605 90 04 5A         [24]  947 	mov	dptr,#_ak820_combo_process_record_10000_636
      003608 12 37 C5         [24]  948 	lcall	_ak820_outline_0009
      00360B 8C 03            [24]  949 	mov	ar3,r4
                                    950 ;	keyboards/ajazz/ak820/ak820_combo.c:54: if (IS_NOEVENT(record->event)) return true;
      00360D 74 04            [12]  951 	mov	a,#0x04
      00360F 2E               [12]  952 	add	a, r6
      003610 12 37 E3         [24]  953 	lcall	_ak820_outline_0014
      003613 70 04            [24]  954 	jnz	00102$
      003615 75 82 01         [24]  955 	mov	dpl, #0x01
      003618 22               [24]  956 	ret
      003619                        957 00102$:
                                    958 ;	keyboards/ajazz/ak820/ak820_combo.c:56: if (record->event.key.row >= MATRIX_ROWS || record->event.key.col >= MATRIX_COLS) {
      003619 12 38 30         [24]  959 	lcall	_ak820_outline_0077
      00361C FA               [12]  960 	mov	r2,a
      00361D BA 10 00         [24]  961 	cjne	r2,#0x10,00308$
      003620                        962 00308$:
      003620 50 09            [24]  963 	jnc	00106$
      003622 12 38 43         [24]  964 	lcall	_ak820_outline_0100
      003625 F9               [12]  965 	mov	r1,a
      003626 B9 08 00         [24]  966 	cjne	r1,#0x08,00310$
      003629                        967 00310$:
      003629 40 16            [24]  968 	jc	00107$
      00362B                        969 00106$:
                                    970 ;	keyboards/ajazz/ak820/ak820_combo.c:57: if (first != NONE && !active) flush();
      00362B 12 38 8F         [24]  971 	lcall	_ak820_outline_0187
      00362E F8               [12]  972 	mov	r0,a
      00362F B8 FF 02         [24]  973 	cjne	r0,#0xff,00312$
      003632 80 09            [24]  974 	sjmp	00104$
      003634                        975 00312$:
      003634 90 04 4B         [24]  976 	mov	dptr,#_active
      003637 E0               [24]  977 	movx	a,@dptr
      003638 70 03            [24]  978 	jnz	00104$
      00363A 12 35 AD         [24]  979 	lcall	_flush
      00363D                        980 00104$:
                                    981 ;	keyboards/ajazz/ak820/ak820_combo.c:58: return true;
      00363D 75 82 01         [24]  982 	mov	dpl, #0x01
      003640 22               [24]  983 	ret
      003641                        984 00107$:
                                    985 ;	keyboards/ajazz/ak820/ak820_combo.c:60: id = record->event.key.row * MATRIX_COLS + record->event.key.col;
      003641 EA               [12]  986 	mov	a,r2
      003642 12 38 94         [24]  987 	lcall	_ak820_outline_0193
      003645 29               [12]  988 	add	a,r1
      003646 FA               [12]  989 	mov	r2,a
                                    990 ;	keyboards/ajazz/ak820/ak820_combo.c:61: if (active) {
      003647 90 04 4B         [24]  991 	mov	dptr,#_active
      00364A E0               [24]  992 	movx	a,@dptr
      00364B 60 6F            [24]  993 	jz	00123$
                                    994 ;	keyboards/ajazz/ak820/ak820_combo.c:62: if (id != first && id != second) return true;
      00364D 12 38 8F         [24]  995 	lcall	_ak820_outline_0187
      003650 F9               [12]  996 	mov	r1,a
      003651 EA               [12]  997 	mov	a,r2
      003652 B5 01 02         [24]  998 	cjne	a,ar1,00315$
      003655 80 0F            [24]  999 	sjmp	00110$
      003657                       1000 00315$:
      003657 90 0D D4         [24] 1001 	mov	dptr,#_second
      00365A E0               [24] 1002 	movx	a,@dptr
      00365B F9               [12] 1003 	mov	r1,a
      00365C EA               [12] 1004 	mov	a,r2
      00365D B5 01 02         [24] 1005 	cjne	a,ar1,00316$
      003660 80 04            [24] 1006 	sjmp	00110$
      003662                       1007 00316$:
      003662 75 82 01         [24] 1008 	mov	dpl, #0x01
      003665 22               [24] 1009 	ret
      003666                       1010 00110$:
                                   1011 ;	keyboards/ajazz/ak820/ak820_combo.c:63: if (!record->event.pressed) {
      003666 90 04 5A         [24] 1012 	mov	dptr,#_ak820_combo_process_record_10000_636
      003669 12 38 4F         [24] 1013 	lcall	_ak820_outline_0104
      00366C 74 05            [12] 1014 	mov	a,#0x05
      00366E 28               [12] 1015 	add	a, r0
      00366F F8               [12] 1016 	mov	r0,a
      003670 E4               [12] 1017 	clr	a
      003671 39               [12] 1018 	addc	a, r1
      003672 F9               [12] 1019 	mov	r1,a
      003673 12 38 7F         [24] 1020 	lcall	_ak820_outline_0154
      003676 E0               [24] 1021 	movx	a,@dptr
      003677 70 3F            [24] 1022 	jnz	00121$
                                   1023 ;	keyboards/ajazz/ak820/ak820_combo.c:64: if (saved.event.pressed) {
      003679 90 04 47         [24] 1024 	mov	dptr,#(_saved + 0x0005)
      00367C E0               [24] 1025 	movx	a,@dptr
      00367D 60 0F            [24] 1026 	jz	00113$
                                   1027 ;	keyboards/ajazz/ak820/ak820_combo.c:65: saved.event.pressed = false;
      00367F 90 04 47         [24] 1028 	mov	dptr,#(_saved + 0x0005)
      003682 E4               [12] 1029 	clr	a
      003683 F0               [24] 1030 	movx	@dptr,a
                                   1031 ;	keyboards/ajazz/ak820/ak820_combo.c:66: process_record(&saved);
      003684 90 04 42         [24] 1032 	mov	dptr,#_saved
      003687 C0 02            [24] 1033 	push	ar2
      003689 12 74 ED         [24] 1034 	lcall	_process_record
      00368C D0 02            [24] 1035 	pop	ar2
      00368E                       1036 00113$:
                                   1037 ;	keyboards/ajazz/ak820/ak820_combo.c:68: if (id == first) first = NONE;
      00368E 12 38 8F         [24] 1038 	lcall	_ak820_outline_0187
      003691 F9               [12] 1039 	mov	r1,a
      003692 EA               [12] 1040 	mov	a,r2
      003693 B5 01 08         [24] 1041 	cjne	a,ar1,00115$
      003696 90 0D D3         [24] 1042 	mov	dptr,#_first
      003699 74 FF            [12] 1043 	mov	a,#0xff
      00369B F0               [24] 1044 	movx	@dptr,a
      00369C 80 06            [24] 1045 	sjmp	00116$
      00369E                       1046 00115$:
                                   1047 ;	keyboards/ajazz/ak820/ak820_combo.c:69: else second = NONE;
      00369E 90 0D D4         [24] 1048 	mov	dptr,#_second
      0036A1 74 FF            [12] 1049 	mov	a,#0xff
      0036A3 F0               [24] 1050 	movx	@dptr,a
      0036A4                       1051 00116$:
                                   1052 ;	keyboards/ajazz/ak820/ak820_combo.c:70: if (first == NONE && second == NONE) active = false;
      0036A4 12 38 8F         [24] 1053 	lcall	_ak820_outline_0187
      0036A7 F9               [12] 1054 	mov	r1,a
      0036A8 B9 FF 0D         [24] 1055 	cjne	r1,#0xff,00121$
      0036AB 90 0D D4         [24] 1056 	mov	dptr,#_second
      0036AE E0               [24] 1057 	movx	a,@dptr
      0036AF F9               [12] 1058 	mov	r1,a
      0036B0 B9 FF 05         [24] 1059 	cjne	r1,#0xff,00121$
      0036B3 90 04 4B         [24] 1060 	mov	dptr,#_active
      0036B6 E4               [12] 1061 	clr	a
      0036B7 F0               [24] 1062 	movx	@dptr,a
      0036B8                       1063 00121$:
                                   1064 ;	keyboards/ajazz/ak820/ak820_combo.c:72: return false;
      0036B8 75 82 00         [24] 1065 	mov	dpl, #0x00
      0036BB 22               [24] 1066 	ret
      0036BC                       1067 00123$:
                                   1068 ;	keyboards/ajazz/ak820/ak820_combo.c:74: bool eligible = false;
      0036BC 90 04 5C         [24] 1069 	mov	dptr,#_ak820_combo_process_eligible_10001_651
      0036BF E4               [12] 1070 	clr	a
      0036C0 F0               [24] 1071 	movx	@dptr,a
                                   1072 ;	keyboards/ajazz/ak820/ak820_combo.c:75: if (record->event.pressed && COMBO_INPUT(record->keycode)) {
      0036C1 12 37 B8         [24] 1073 	lcall	_ak820_outline_0005
      0036C4 70 03            [24] 1074 	jnz	00325$
      0036C6 02 37 6E         [24] 1075 	ljmp	00134$
      0036C9                       1076 00325$:
      0036C9 C3               [12] 1077 	clr	c
      0036CA EC               [12] 1078 	mov	a,r4
      0036CB 94 04            [12] 1079 	subb	a,#0x04
      0036CD ED               [12] 1080 	mov	a,r5
      0036CE 94 00            [12] 1081 	subb	a,#0x00
      0036D0 50 03            [24] 1082 	jnc	00326$
      0036D2 02 37 6E         [24] 1083 	ljmp	00134$
      0036D5                       1084 00326$:
      0036D5 C3               [12] 1085 	clr	c
      0036D6 74 A4            [12] 1086 	mov	a,#0xa4
      0036D8 9C               [12] 1087 	subb	a,r4
      0036D9 E4               [12] 1088 	clr	a
      0036DA 9D               [12] 1089 	subb	a,r5
      0036DB 50 03            [24] 1090 	jnc	00327$
      0036DD 02 37 6E         [24] 1091 	ljmp	00134$
      0036E0                       1092 00327$:
                                   1093 ;	free result
                                   1094 ;	keyboards/ajazz/ak820/ak820_combo.c:76: uint8_t previous = saved.keycode;
      0036E0 90 04 49         [24] 1095 	mov	dptr,#(_saved + 0x0007)
      0036E3 E0               [24] 1096 	movx	a,@dptr
      0036E4 FF               [12] 1097 	mov	r7,a
                                   1098 ;	keyboards/ajazz/ak820/ak820_combo.c:77: for (uint8_t i = 0; i < VIAL_COMBO_ENTRIES; ++i) {
      0036E5 90 04 5D         [24] 1099 	mov	dptr,#_ak820_combo_process_i_40001_654
      0036E8 E4               [12] 1100 	clr	a
      0036E9 F0               [24] 1101 	movx	@dptr,a
      0036EA EB               [12] 1102 	mov	a,r3
      0036EB B5 07 03         [24] 1103 	cjne	a,ar7,00328$
      0036EE D3               [12] 1104 	setb	c
      0036EF 80 01            [24] 1105 	sjmp	00329$
      0036F1                       1106 00328$:
      0036F1 C3               [12] 1107 	clr	c
      0036F2                       1108 00329$:
      0036F2 92 01            [24] 1109 	mov	_ak820_combo_process_sloc0_1_0,c
      0036F4 7E 00            [12] 1110 	mov	r6,#0x00
      0036F6                       1111 00142$:
      0036F6 BE 08 00         [24] 1112 	cjne	r6,#0x08,00330$
      0036F9                       1113 00330$:
      0036F9 40 03            [24] 1114 	jc	00331$
      0036FB 02 37 6E         [24] 1115 	ljmp	00134$
      0036FE                       1116 00331$:
                                   1117 ;	keyboards/ajazz/ak820/ak820_combo.c:78: uint8_t a = combos[i].a, b = combos[i].b;
      0036FE EE               [12] 1118 	mov	a,r6
      0036FF 12 38 0B         [24] 1119 	lcall	_ak820_outline_0053
      003702 E0               [24] 1120 	movx	a,@dptr
      003703 F9               [12] 1121 	mov	r1,a
      003704 90 04 5E         [24] 1122 	mov	dptr,#_ak820_combo_process_a_50001_655
      003707 F0               [24] 1123 	movx	@dptr,a
      003708 12 38 65         [24] 1124 	lcall	_ak820_outline_0125
      00370B A3               [24] 1125 	inc	dptr
      00370C E0               [24] 1126 	movx	a,@dptr
      00370D FD               [12] 1127 	mov	r5,a
      00370E 90 04 5F         [24] 1128 	mov	dptr,#_ak820_combo_process_b_50001_655
      003711 F0               [24] 1129 	movx	@dptr,a
                                   1130 ;	keyboards/ajazz/ak820/ak820_combo.c:79: if (a == code || b == code) {
      003712 E9               [12] 1131 	mov	a,r1
      003713 B5 03 02         [24] 1132 	cjne	a,ar3,00332$
      003716 80 04            [24] 1133 	sjmp	00129$
      003718                       1134 00332$:
      003718 ED               [12] 1135 	mov	a,r5
      003719 B5 03 49         [24] 1136 	cjne	a,ar3,00143$
      00371C                       1137 00129$:
                                   1138 ;	keyboards/ajazz/ak820/ak820_combo.c:80: eligible = true;
      00371C 90 04 5C         [24] 1139 	mov	dptr,#_ak820_combo_process_eligible_10001_651
      00371F 74 01            [12] 1140 	mov	a,#0x01
      003721 F0               [24] 1141 	movx	@dptr,a
                                   1142 ;	keyboards/ajazz/ak820/ak820_combo.c:81: if (first != NONE && code != previous && (a == previous || b == previous)) {
      003722 12 38 8F         [24] 1143 	lcall	_ak820_outline_0187
      003725 FD               [12] 1144 	mov	r5,a
      003726 BD FF 02         [24] 1145 	cjne	r5,#0xff,00335$
      003729 80 3A            [24] 1146 	sjmp	00143$
      00372B                       1147 00335$:
      00372B 20 01 37         [24] 1148 	jb	_ak820_combo_process_sloc0_1_0,00143$
      00372E 90 04 5E         [24] 1149 	mov	dptr,#_ak820_combo_process_a_50001_655
      003731 E0               [24] 1150 	movx	a,@dptr
      003732 B5 07 02         [24] 1151 	cjne	a,ar7,00337$
      003735 80 07            [24] 1152 	sjmp	00124$
      003737                       1153 00337$:
      003737 90 04 5F         [24] 1154 	mov	dptr,#_ak820_combo_process_b_50001_655
      00373A E0               [24] 1155 	movx	a,@dptr
      00373B B5 07 27         [24] 1156 	cjne	a,ar7,00143$
      00373E                       1157 00124$:
                                   1158 ;	keyboards/ajazz/ak820/ak820_combo.c:82: second = id;
      00373E 90 0D D4         [24] 1159 	mov	dptr,#_second
      003741 EA               [12] 1160 	mov	a,r2
      003742 F0               [24] 1161 	movx	@dptr,a
                                   1162 ;	keyboards/ajazz/ak820/ak820_combo.c:83: active = true;
      003743 90 04 4B         [24] 1163 	mov	dptr,#_active
      003746 74 01            [12] 1164 	mov	a,#0x01
      003748 F0               [24] 1165 	movx	@dptr,a
                                   1166 ;	keyboards/ajazz/ak820/ak820_combo.c:84: saved.keycode = combos[i].output;
      003749 90 04 5D         [24] 1167 	mov	dptr,#_ak820_combo_process_i_40001_654
      00374C E0               [24] 1168 	movx	a,@dptr
      00374D 12 38 0B         [24] 1169 	lcall	_ak820_outline_0053
      003750 A3               [24] 1170 	inc	dptr
      003751 A3               [24] 1171 	inc	dptr
      003752 12 38 24         [24] 1172 	lcall	_ak820_outline_0059
      003755 90 04 49         [24] 1173 	mov	dptr,#(_saved + 0x0007)
      003758 12 38 2A         [24] 1174 	lcall	_ak820_outline_0072
                                   1175 ;	keyboards/ajazz/ak820/ak820_combo.c:85: process_record(&saved);
      00375B 90 04 42         [24] 1176 	mov	dptr,#_saved
      00375E 12 74 ED         [24] 1177 	lcall	_process_record
                                   1178 ;	keyboards/ajazz/ak820/ak820_combo.c:86: return false;
      003761 75 82 00         [24] 1179 	mov	dpl, #0x00
      003764 22               [24] 1180 	ret
      003765                       1181 00143$:
                                   1182 ;	keyboards/ajazz/ak820/ak820_combo.c:77: for (uint8_t i = 0; i < VIAL_COMBO_ENTRIES; ++i) {
      003765 0E               [12] 1183 	inc	r6
      003766 90 04 5D         [24] 1184 	mov	dptr,#_ak820_combo_process_i_40001_654
      003769 EE               [12] 1185 	mov	a,r6
      00376A F0               [24] 1186 	movx	@dptr,a
      00376B 02 36 F6         [24] 1187 	ljmp	00142$
      00376E                       1188 00134$:
                                   1189 ;	keyboards/ajazz/ak820/ak820_combo.c:91: if (first != NONE) flush();
      00376E 12 38 8F         [24] 1190 	lcall	_ak820_outline_0187
      003771 FF               [12] 1191 	mov	r7,a
      003772 BF FF 02         [24] 1192 	cjne	r7,#0xff,00340$
      003775 80 07            [24] 1193 	sjmp	00138$
      003777                       1194 00340$:
      003777 C0 02            [24] 1195 	push	ar2
      003779 12 35 AD         [24] 1196 	lcall	_flush
      00377C D0 02            [24] 1197 	pop	ar2
      00377E                       1198 00138$:
                                   1199 ;	keyboards/ajazz/ak820/ak820_combo.c:92: if (eligible) {
      00377E 90 04 5C         [24] 1200 	mov	dptr,#_ak820_combo_process_eligible_10001_651
      003781 E0               [24] 1201 	movx	a,@dptr
      003782 60 26            [24] 1202 	jz	00140$
                                   1203 ;	keyboards/ajazz/ak820/ak820_combo.c:93: first = id;
      003784 90 0D D3         [24] 1204 	mov	dptr,#_first
      003787 EA               [12] 1205 	mov	a,r2
      003788 F0               [24] 1206 	movx	@dptr,a
                                   1207 ;	keyboards/ajazz/ak820/ak820_combo.c:94: saved = *record;
      003789 90 04 5A         [24] 1208 	mov	dptr,#_ak820_combo_process_record_10000_636
      00378C 12 38 1C         [24] 1209 	lcall	_ak820_outline_0058
      00378F 90 0D BD         [24] 1210 	mov	dptr,#___memcpy_PARM_2
      003792 ED               [12] 1211 	mov	a,r5
      003793 12 37 ED         [24] 1212 	lcall	_ak820_outline_0016
      003796 90 0D C0         [24] 1213 	mov	dptr,#___memcpy_PARM_3
      003799 74 09            [12] 1214 	mov	a,#0x09
      00379B 12 38 6A         [24] 1215 	lcall	_ak820_outline_0127
      00379E 90 04 42         [24] 1216 	mov	dptr,#_saved
      0037A1 F5 F0            [12] 1217 	mov	b,a
      0037A3 12 BB FD         [24] 1218 	lcall	___memcpy
                                   1219 ;	keyboards/ajazz/ak820/ak820_combo.c:95: return false;
      0037A6 75 82 00         [24] 1220 	mov	dpl, #0x00
      0037A9 22               [24] 1221 	ret
      0037AA                       1222 00140$:
                                   1223 ;	keyboards/ajazz/ak820/ak820_combo.c:97: return true;
      0037AA 75 82 01         [24] 1224 	mov	dpl, #0x01
                                   1225 ;	keyboards/ajazz/ak820/ak820_combo.c:98: }
      0037AD 22               [24] 1226 	ret
                                   1227 	.area CSEG    (CODE)
                                   1228 	.area CONST   (CODE)
                                   1229 	.area XINIT   (CODE)
      00C5C7                       1230 __xinit__first:
      00C5C7 FF                    1231 	.db #0xff	; 255
      00C5C8                       1232 __xinit__second:
      00C5C8 FF                    1233 	.db #0xff	; 255
                                   1234 	.area CABS    (ABS,CODE)
                                   1235 
                                   1236 ; Experimental exact instruction outlining.
                                   1237 	.globl _ak820_outline_0004
                                   1238 	.globl _ak820_outline_0005
                                   1239 	.globl _ak820_outline_0009
                                   1240 	.globl _ak820_outline_0010
                                   1241 	.globl _ak820_outline_0014
                                   1242 	.globl _ak820_outline_0016
                                   1243 	.globl _ak820_outline_0017
                                   1244 	.globl _ak820_outline_0034
                                   1245 	.globl _ak820_outline_0051
                                   1246 	.globl _ak820_outline_0053
                                   1247 	.globl _ak820_outline_0058
                                   1248 	.globl _ak820_outline_0059
                                   1249 	.globl _ak820_outline_0072
                                   1250 	.globl _ak820_outline_0077
                                   1251 	.globl _ak820_outline_0084
                                   1252 	.globl _ak820_outline_0085
                                   1253 	.globl _ak820_outline_0100
                                   1254 	.globl _ak820_outline_0101
                                   1255 	.globl _ak820_outline_0104
                                   1256 	.globl _ak820_outline_0105
                                   1257 	.globl _ak820_outline_0106
                                   1258 	.globl _ak820_outline_0107
                                   1259 	.globl _ak820_outline_0125
                                   1260 	.globl _ak820_outline_0126
                                   1261 	.globl _ak820_outline_0127
                                   1262 	.globl _ak820_outline_0136
                                   1263 	.globl _ak820_outline_0145
                                   1264 	.globl _ak820_outline_0149
                                   1265 	.globl _ak820_outline_0154
                                   1266 	.globl _ak820_outline_0160
                                   1267 	.globl _ak820_outline_0163
                                   1268 	.globl _ak820_outline_0187
                                   1269 	.globl _ak820_outline_0193
                                   1270 
                                   1271 	.area CSEG (CODE)
                                   1272 ; function ak820_outline_0004
      0037AE                       1273 _ak820_outline_0004:
      0037AE E0               [24] 1274 	movx	a,@dptr
      0037AF FE               [12] 1275 	mov	r6,a
      0037B0 A3               [24] 1276 	inc	dptr
      0037B1 E0               [24] 1277 	movx	a,@dptr
      0037B2 FF               [12] 1278 	mov	r7,a
      0037B3 8E 82            [24] 1279 	mov	dpl,r6
      0037B5 8F 83            [24] 1280 	mov	dph,r7
      0037B7 22               [24] 1281 	ret
                                   1282 
                                   1283 	.area CSEG (CODE)
                                   1284 ; function ak820_outline_0005
      0037B8                       1285 _ak820_outline_0005:
      0037B8 74 05            [12] 1286 	mov	a,#0x05
      0037BA 2E               [12] 1287 	add	a,r6
      0037BB FE               [12] 1288 	mov	r6,a
      0037BC E4               [12] 1289 	clr	a
      0037BD 3F               [12] 1290 	addc	a,r7
      0037BE FF               [12] 1291 	mov	r7,a
      0037BF 8E 82            [24] 1292 	mov	dpl,r6
      0037C1 8F 83            [24] 1293 	mov	dph,r7
      0037C3 E0               [24] 1294 	movx	a,@dptr
      0037C4 22               [24] 1295 	ret
                                   1296 
                                   1297 	.area CSEG (CODE)
                                   1298 ; function ak820_outline_0009
      0037C5                       1299 _ak820_outline_0009:
      0037C5 E0               [24] 1300 	movx	a,@dptr
      0037C6 FE               [12] 1301 	mov	r6,a
      0037C7 A3               [24] 1302 	inc	dptr
      0037C8 E0               [24] 1303 	movx	a,@dptr
      0037C9 FF               [12] 1304 	mov	r7,a
      0037CA 74 07            [12] 1305 	mov	a,#0x07
      0037CC 2E               [12] 1306 	add	a,r6
      0037CD F5 82            [12] 1307 	mov	dpl,a
      0037CF E4               [12] 1308 	clr	a
      0037D0 3F               [12] 1309 	addc	a,r7
      0037D1 F5 83            [12] 1310 	mov	dph,a
      0037D3 E0               [24] 1311 	movx	a,@dptr
      0037D4 FC               [12] 1312 	mov	r4,a
      0037D5 A3               [24] 1313 	inc	dptr
      0037D6 E0               [24] 1314 	movx	a,@dptr
      0037D7 FD               [12] 1315 	mov	r5,a
      0037D8 22               [24] 1316 	ret
                                   1317 
                                   1318 	.area CSEG (CODE)
                                   1319 ; function ak820_outline_0010
      0037D9                       1320 _ak820_outline_0010:
      0037D9 E0               [24] 1321 	movx	a,@dptr
      0037DA FE               [12] 1322 	mov	r6,a
      0037DB A3               [24] 1323 	inc	dptr
      0037DC E0               [24] 1324 	movx	a,@dptr
      0037DD FF               [12] 1325 	mov	r7,a
      0037DE 8E 04            [24] 1326 	mov	ar4,r6
      0037E0 8F 05            [24] 1327 	mov	ar5,r7
      0037E2 22               [24] 1328 	ret
                                   1329 
                                   1330 	.area CSEG (CODE)
                                   1331 ; function ak820_outline_0014
      0037E3                       1332 _ak820_outline_0014:
      0037E3 F9               [12] 1333 	mov	r1,a
      0037E4 E4               [12] 1334 	clr	a
      0037E5 3F               [12] 1335 	addc	a,r7
      0037E6 FA               [12] 1336 	mov	r2,a
      0037E7 89 82            [24] 1337 	mov	dpl,r1
      0037E9 8A 83            [24] 1338 	mov	dph,r2
      0037EB E0               [24] 1339 	movx	a,@dptr
      0037EC 22               [24] 1340 	ret
                                   1341 
                                   1342 	.area CSEG (CODE)
                                   1343 ; function ak820_outline_0016
      0037ED                       1344 _ak820_outline_0016:
      0037ED F0               [24] 1345 	movx	@dptr,a
      0037EE EE               [12] 1346 	mov	a,r6
      0037EF A3               [24] 1347 	inc	dptr
      0037F0 F0               [24] 1348 	movx	@dptr,a
      0037F1 EF               [12] 1349 	mov	a,r7
      0037F2 A3               [24] 1350 	inc	dptr
      0037F3 F0               [24] 1351 	movx	@dptr,a
      0037F4 22               [24] 1352 	ret
                                   1353 
                                   1354 	.area CSEG (CODE)
                                   1355 ; function ak820_outline_0017
      0037F5                       1356 _ak820_outline_0017:
      0037F5 2E               [12] 1357 	add	a,r6
      0037F6 F5 82            [12] 1358 	mov	dpl,a
      0037F8 E4               [12] 1359 	clr	a
      0037F9 3F               [12] 1360 	addc	a,r7
      0037FA F5 83            [12] 1361 	mov	dph,a
      0037FC 22               [24] 1362 	ret
                                   1363 
                                   1364 	.area CSEG (CODE)
                                   1365 ; function ak820_outline_0034
      0037FD                       1366 _ak820_outline_0034:
      0037FD 8E 82            [24] 1367 	mov	dpl,r6
      0037FF 8F 83            [24] 1368 	mov	dph,r7
      003801 A3               [24] 1369 	inc	dptr
      003802 A3               [24] 1370 	inc	dptr
      003803 E0               [24] 1371 	movx	a,@dptr
      003804 22               [24] 1372 	ret
                                   1373 
                                   1374 	.area CSEG (CODE)
                                   1375 ; function ak820_outline_0051
      003805                       1376 _ak820_outline_0051:
      003805 E0               [24] 1377 	movx	a,@dptr
      003806 FE               [12] 1378 	mov	r6,a
      003807 A3               [24] 1379 	inc	dptr
      003808 E0               [24] 1380 	movx	a,@dptr
      003809 FF               [12] 1381 	mov	r7,a
      00380A 22               [24] 1382 	ret
                                   1383 
                                   1384 	.area CSEG (CODE)
                                   1385 ; function ak820_outline_0053
      00380B                       1386 _ak820_outline_0053:
      00380B 75 F0 04         [24] 1387 	mov	b,#0x04
      00380E A4               [48] 1388 	mul	ab
      00380F 24 22            [12] 1389 	add	a,#_combos
      003811 FC               [12] 1390 	mov	r4,a
      003812 74 04            [12] 1391 	mov	a,#(_combos>>8)
      003814 35 F0            [12] 1392 	addc	a,b
      003816 FD               [12] 1393 	mov	r5,a
      003817 8C 82            [24] 1394 	mov	dpl,r4
      003819 8D 83            [24] 1395 	mov	dph,r5
      00381B 22               [24] 1396 	ret
                                   1397 
                                   1398 	.area CSEG (CODE)
                                   1399 ; function ak820_outline_0058
      00381C                       1400 _ak820_outline_0058:
      00381C E0               [24] 1401 	movx	a,@dptr
      00381D FD               [12] 1402 	mov	r5,a
      00381E A3               [24] 1403 	inc	dptr
      00381F E0               [24] 1404 	movx	a,@dptr
      003820 FE               [12] 1405 	mov	r6,a
      003821 7F 00            [12] 1406 	mov	r7,#0x00
      003823 22               [24] 1407 	ret
                                   1408 
                                   1409 	.area CSEG (CODE)
                                   1410 ; function ak820_outline_0059
      003824                       1411 _ak820_outline_0059:
      003824 E0               [24] 1412 	movx	a,@dptr
      003825 FC               [12] 1413 	mov	r4,a
      003826 A3               [24] 1414 	inc	dptr
      003827 E0               [24] 1415 	movx	a,@dptr
      003828 FD               [12] 1416 	mov	r5,a
      003829 22               [24] 1417 	ret
                                   1418 
                                   1419 	.area CSEG (CODE)
                                   1420 ; function ak820_outline_0072
      00382A                       1421 _ak820_outline_0072:
      00382A EC               [12] 1422 	mov	a,r4
      00382B F0               [24] 1423 	movx	@dptr,a
      00382C ED               [12] 1424 	mov	a,r5
      00382D A3               [24] 1425 	inc	dptr
      00382E F0               [24] 1426 	movx	@dptr,a
      00382F 22               [24] 1427 	ret
                                   1428 
                                   1429 	.area CSEG (CODE)
                                   1430 ; function ak820_outline_0077
      003830                       1431 _ak820_outline_0077:
      003830 8E 82            [24] 1432 	mov	dpl,r6
      003832 8F 83            [24] 1433 	mov	dph,r7
      003834 A3               [24] 1434 	inc	dptr
      003835 E0               [24] 1435 	movx	a,@dptr
      003836 22               [24] 1436 	ret
                                   1437 
                                   1438 	.area CSEG (CODE)
                                   1439 ; function ak820_outline_0084
      003837                       1440 _ak820_outline_0084:
      003837 A3               [24] 1441 	inc	dptr
      003838 F0               [24] 1442 	movx	@dptr,a
      003839 E4               [12] 1443 	clr	a
      00383A A3               [24] 1444 	inc	dptr
      00383B F0               [24] 1445 	movx	@dptr,a
      00383C 22               [24] 1446 	ret
                                   1447 
                                   1448 	.area CSEG (CODE)
                                   1449 ; function ak820_outline_0085
      00383D                       1450 _ak820_outline_0085:
      00383D EB               [12] 1451 	mov	a,r3
      00383E F0               [24] 1452 	movx	@dptr,a
      00383F EC               [12] 1453 	mov	a,r4
      003840 A3               [24] 1454 	inc	dptr
      003841 F0               [24] 1455 	movx	@dptr,a
      003842 22               [24] 1456 	ret
                                   1457 
                                   1458 	.area CSEG (CODE)
                                   1459 ; function ak820_outline_0100
      003843                       1460 _ak820_outline_0100:
      003843 8E 82            [24] 1461 	mov	dpl,r6
      003845 8F 83            [24] 1462 	mov	dph,r7
      003847 E0               [24] 1463 	movx	a,@dptr
      003848 22               [24] 1464 	ret
                                   1465 
                                   1466 	.area CSEG (CODE)
                                   1467 ; function ak820_outline_0101
      003849                       1468 _ak820_outline_0101:
      003849 E5 82            [12] 1469 	mov	a,dpl
      00384B 85 83 F0         [24] 1470 	mov	b,dph
      00384E 22               [24] 1471 	ret
                                   1472 
                                   1473 	.area CSEG (CODE)
                                   1474 ; function ak820_outline_0104
      00384F                       1475 _ak820_outline_0104:
      00384F E0               [24] 1476 	movx	a,@dptr
      003850 F8               [12] 1477 	mov	r0,a
      003851 A3               [24] 1478 	inc	dptr
      003852 E0               [24] 1479 	movx	a,@dptr
      003853 F9               [12] 1480 	mov	r1,a
      003854 22               [24] 1481 	ret
                                   1482 
                                   1483 	.area CSEG (CODE)
                                   1484 ; function ak820_outline_0105
      003855                       1485 _ak820_outline_0105:
      003855 E0               [24] 1486 	movx	a,@dptr
      003856 FB               [12] 1487 	mov	r3,a
      003857 A3               [24] 1488 	inc	dptr
      003858 E0               [24] 1489 	movx	a,@dptr
      003859 FC               [12] 1490 	mov	r4,a
      00385A 22               [24] 1491 	ret
                                   1492 
                                   1493 	.area CSEG (CODE)
                                   1494 ; function ak820_outline_0106
      00385B                       1495 _ak820_outline_0106:
      00385B AF 83            [24] 1496 	mov	r7,dph
      00385D E5 82            [12] 1497 	mov	a,dpl
      00385F 22               [24] 1498 	ret
                                   1499 
                                   1500 	.area CSEG (CODE)
                                   1501 ; function ak820_outline_0107
      003860                       1502 _ak820_outline_0107:
      003860 F0               [24] 1503 	movx	@dptr,a
      003861 EF               [12] 1504 	mov	a,r7
      003862 A3               [24] 1505 	inc	dptr
      003863 F0               [24] 1506 	movx	@dptr,a
      003864 22               [24] 1507 	ret
                                   1508 
                                   1509 	.area CSEG (CODE)
                                   1510 ; function ak820_outline_0125
      003865                       1511 _ak820_outline_0125:
      003865 8C 82            [24] 1512 	mov	dpl,r4
      003867 8D 83            [24] 1513 	mov	dph,r5
      003869 22               [24] 1514 	ret
                                   1515 
                                   1516 	.area CSEG (CODE)
                                   1517 ; function ak820_outline_0127
      00386A                       1518 _ak820_outline_0127:
      00386A F0               [24] 1519 	movx	@dptr,a
      00386B E4               [12] 1520 	clr	a
      00386C A3               [24] 1521 	inc	dptr
      00386D F0               [24] 1522 	movx	@dptr,a
      00386E 22               [24] 1523 	ret
                                   1524 
                                   1525 	.area CSEG (CODE)
                                   1526 ; function ak820_outline_0136
      00386F                       1527 _ak820_outline_0136:
      00386F 8D 82            [24] 1528 	mov	dpl,r5
      003871 8E 83            [24] 1529 	mov	dph,r6
      003873 22               [24] 1530 	ret
                                   1531 
                                   1532 	.area CSEG (CODE)
                                   1533 ; function ak820_outline_0145
      003874                       1534 _ak820_outline_0145:
      003874 E0               [24] 1535 	movx	a,@dptr
      003875 FC               [12] 1536 	mov	r4,a
      003876 A3               [24] 1537 	inc	dptr
      003877 E0               [24] 1538 	movx	a,@dptr
      003878 4C               [12] 1539 	orl	a,r4
      003879 22               [24] 1540 	ret
                                   1541 
                                   1542 	.area CSEG (CODE)
                                   1543 ; function ak820_outline_0149
      00387A                       1544 _ak820_outline_0149:
      00387A AC 82            [24] 1545 	mov	r4,dpl
      00387C AD 83            [24] 1546 	mov	r5,dph
      00387E 22               [24] 1547 	ret
                                   1548 
                                   1549 	.area CSEG (CODE)
                                   1550 ; function ak820_outline_0154
      00387F                       1551 _ak820_outline_0154:
      00387F 88 82            [24] 1552 	mov	dpl,r0
      003881 89 83            [24] 1553 	mov	dph,r1
      003883 22               [24] 1554 	ret
                                   1555 
                                   1556 	.area CSEG (CODE)
                                   1557 ; function ak820_outline_0160
      003884                       1558 _ak820_outline_0160:
      003884 E4               [12] 1559 	clr	a
      003885 33               [12] 1560 	rlc	a
      003886 F5 82            [12] 1561 	mov	dpl,a
      003888 22               [24] 1562 	ret
                                   1563 
                                   1564 	.area CSEG (CODE)
                                   1565 ; function ak820_outline_0163
      003889                       1566 _ak820_outline_0163:
      003889 2D               [12] 1567 	add	a,r5
      00388A FD               [12] 1568 	mov	r5,a
      00388B E4               [12] 1569 	clr	a
      00388C 3E               [12] 1570 	addc	a,r6
      00388D FE               [12] 1571 	mov	r6,a
      00388E 22               [24] 1572 	ret
                                   1573 
                                   1574 	.area CSEG (CODE)
                                   1575 ; function ak820_outline_0187
      00388F                       1576 _ak820_outline_0187:
      00388F 90 0D D3         [24] 1577 	mov	dptr,#_first
      003892 E0               [24] 1578 	movx	a,@dptr
      003893 22               [24] 1579 	ret
                                   1580 
                                   1581 	.area CSEG (CODE)
                                   1582 ; function ak820_outline_0193
      003894                       1583 _ak820_outline_0193:
      003894 C4               [12] 1584 	swap	a
      003895 03               [12] 1585 	rr	a
      003896 54 F8            [12] 1586 	anl	a,#0xf8
      003898 22               [24] 1587 	ret
