                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_combo_cancel
                                     12 	.globl _ak820_combo_tick
                                     13 	.globl _ak820_oneshot_cancel
                                     14 	.globl _ak820_oneshot_post
                                     15 	.globl _ak820_oneshot_process
                                     16 	.globl _ak820_tapping_source
                                     17 	.globl _ak820_tapping_cancel
                                     18 	.globl _ak820_tapping_process
                                     19 	.globl _ak820_tapping_before
                                     20 	.globl _pre_process_record_quantum
                                     21 	.globl _get_record_keycode
                                     22 	.globl _repeat_key_cancel
                                     23 	.globl _ak820_settings_caps_delay
                                     24 	.globl _ak820_settings_tap_code_delay
                                     25 	.globl _clear_owned_usages
                                     26 	.globl _owned_usage_key
                                     27 	.globl _clear_owned_keys
                                     28 	.globl _del_owned_key
                                     29 	.globl _add_owned_key
                                     30 	.globl _clear_owned_mods
                                     31 	.globl _del_owned_weak_mods
                                     32 	.globl _add_owned_weak_mods
                                     33 	.globl _del_owned_mods
                                     34 	.globl _add_owned_mods
                                     35 	.globl _clear_weak_mods
                                     36 	.globl _clear_mods
                                     37 	.globl _send_keyboard_report
                                     38 	.globl _layer_hold_clear
                                     39 	.globl _layer_hold_off
                                     40 	.globl _layer_hold_on
                                     41 	.globl _ak820_resolve_key
                                     42 	.globl _layer_xor
                                     43 	.globl _layer_and
                                     44 	.globl _layer_or
                                     45 	.globl _layer_off
                                     46 	.globl _layer_on
                                     47 	.globl _layer_move
                                     48 	.globl _layer_clear
                                     49 	.globl _layer_state_set
                                     50 	.globl _default_layer_xor
                                     51 	.globl _default_layer_and
                                     52 	.globl _default_layer_or
                                     53 	.globl _default_layer_set
                                     54 	.globl _process_record_quantum
                                     55 	.globl _action_for_keycode
                                     56 	.globl _mDelaymS
                                     57 	.globl _host_consumer_send
                                     58 	.globl _host_system_send
                                     59 	.globl _host_keyboard_leds
                                     60 	.globl _led_set
                                     61 	.globl _clear_keys_from_report
                                     62 	.globl ___memcpy
                                     63 	.globl _ADC_START
                                     64 	.globl _S0_R_FIFO
                                     65 	.globl _S0_T_FIFO
                                     66 	.globl _S0_FREE
                                     67 	.globl _S0_IF_BYTE
                                     68 	.globl _S0_IF_FIRST
                                     69 	.globl _S0_IF_OV
                                     70 	.globl _S0_FST_ACT
                                     71 	.globl _CP_RL2
                                     72 	.globl _C_T2
                                     73 	.globl _TR2
                                     74 	.globl _EXEN2
                                     75 	.globl _TCLK
                                     76 	.globl _RCLK
                                     77 	.globl _EXF2
                                     78 	.globl _CAP1F
                                     79 	.globl _TF2
                                     80 	.globl _RI
                                     81 	.globl _TI
                                     82 	.globl _RB8
                                     83 	.globl _TB8
                                     84 	.globl _REN
                                     85 	.globl _SM2
                                     86 	.globl _SM1
                                     87 	.globl _SM0
                                     88 	.globl _IT0
                                     89 	.globl _IE0
                                     90 	.globl _IT1
                                     91 	.globl _IE1
                                     92 	.globl _TR0
                                     93 	.globl _TF0
                                     94 	.globl _TR1
                                     95 	.globl _TF1
                                     96 	.globl _P4_0
                                     97 	.globl _P4_1
                                     98 	.globl _P4_2
                                     99 	.globl _P4_3
                                    100 	.globl _P4_4
                                    101 	.globl _P4_5
                                    102 	.globl _P4_6
                                    103 	.globl _RXD
                                    104 	.globl _TXD
                                    105 	.globl _INT0
                                    106 	.globl _INT1
                                    107 	.globl _T0
                                    108 	.globl _T1
                                    109 	.globl _MOSI1
                                    110 	.globl _MISO1
                                    111 	.globl _SCK1
                                    112 	.globl _P3_0
                                    113 	.globl _P3_1
                                    114 	.globl _P3_2
                                    115 	.globl _P3_3
                                    116 	.globl _P3_4
                                    117 	.globl _P3_5
                                    118 	.globl _P3_6
                                    119 	.globl _P3_7
                                    120 	.globl _CAP1_
                                    121 	.globl _T2_
                                    122 	.globl _CAP2_
                                    123 	.globl _T2EX_
                                    124 	.globl _RXD1
                                    125 	.globl _TXD1
                                    126 	.globl _P2_0
                                    127 	.globl _P2_1
                                    128 	.globl _P2_2
                                    129 	.globl _P2_3
                                    130 	.globl _P2_4
                                    131 	.globl _P2_5
                                    132 	.globl _P2_6
                                    133 	.globl _P2_7
                                    134 	.globl _AIN0
                                    135 	.globl _AIN1
                                    136 	.globl _AIN2
                                    137 	.globl _AIN3
                                    138 	.globl _AIN4
                                    139 	.globl _AIN5
                                    140 	.globl _AIN6
                                    141 	.globl _AIN7
                                    142 	.globl _CAP1
                                    143 	.globl _T2
                                    144 	.globl _CAP2
                                    145 	.globl _T2EX
                                    146 	.globl _INT0_
                                    147 	.globl _SCS
                                    148 	.globl _MOSI
                                    149 	.globl _MISO
                                    150 	.globl _SCK
                                    151 	.globl _RXD1_
                                    152 	.globl _TXD1_
                                    153 	.globl _P1_0
                                    154 	.globl _P1_1
                                    155 	.globl _P1_2
                                    156 	.globl _P1_3
                                    157 	.globl _P1_4
                                    158 	.globl _P1_5
                                    159 	.globl _P1_6
                                    160 	.globl _P1_7
                                    161 	.globl _AIN8
                                    162 	.globl _AIN9
                                    163 	.globl _AIN10
                                    164 	.globl _AIN11
                                    165 	.globl _AIN12
                                    166 	.globl _AIN13
                                    167 	.globl _RXD_
                                    168 	.globl _TXD_
                                    169 	.globl _SCL0
                                    170 	.globl _SDA0
                                    171 	.globl _P0_0
                                    172 	.globl _P0_1
                                    173 	.globl _P0_2
                                    174 	.globl _P0_3
                                    175 	.globl _P0_4
                                    176 	.globl _P0_5
                                    177 	.globl _P0_6
                                    178 	.globl _P0_7
                                    179 	.globl _IE_SPI0
                                    180 	.globl _IE_USB
                                    181 	.globl _IE_ADC
                                    182 	.globl _IE_UART1
                                    183 	.globl _IE_PWM_I2C
                                    184 	.globl _IE_GPIO
                                    185 	.globl _IE_WDOG
                                    186 	.globl _PX0
                                    187 	.globl _PT0
                                    188 	.globl _PX1
                                    189 	.globl _PT1
                                    190 	.globl _PS
                                    191 	.globl _PT2
                                    192 	.globl _PL_FLAG
                                    193 	.globl _PH_FLAG
                                    194 	.globl _EX0
                                    195 	.globl _ET0
                                    196 	.globl _EX1
                                    197 	.globl _ET1
                                    198 	.globl _ES
                                    199 	.globl _ET2
                                    200 	.globl _E_DIS
                                    201 	.globl _EA
                                    202 	.globl _P
                                    203 	.globl _F1
                                    204 	.globl _OV
                                    205 	.globl _RS0
                                    206 	.globl _RS1
                                    207 	.globl _F0
                                    208 	.globl _AC
                                    209 	.globl _CY
                                    210 	.globl _I2CS_INT_ST
                                    211 	.globl _I2CX_INT
                                    212 	.globl _LED_STATUS
                                    213 	.globl _LED_DMA_H
                                    214 	.globl _LED_DMA_L
                                    215 	.globl _LED_DMA
                                    216 	.globl _LED_PWM_OE
                                    217 	.globl _LED_COMMON
                                    218 	.globl _ADC_CHAN
                                    219 	.globl _ADC_DAT_H
                                    220 	.globl _ADC_DAT_L
                                    221 	.globl _ADC_DAT
                                    222 	.globl _ADC_CTRL
                                    223 	.globl _SPI1_CK_SE
                                    224 	.globl _SPI1_CTRL
                                    225 	.globl _SPI1_DATA
                                    226 	.globl _SPI1_STAT
                                    227 	.globl _SIF1
                                    228 	.globl _SBAUD1
                                    229 	.globl _SBUF1
                                    230 	.globl _SCON1
                                    231 	.globl _SPI0_SETUP
                                    232 	.globl _SPI0_CK_SE
                                    233 	.globl _SPI0_CTRL
                                    234 	.globl _SPI0_DATA
                                    235 	.globl _SPI0_STAT
                                    236 	.globl _T2CAP1H
                                    237 	.globl _T2CAP1L
                                    238 	.globl _T2CAP1
                                    239 	.globl _TH2
                                    240 	.globl _TL2
                                    241 	.globl _T2COUNT
                                    242 	.globl _RCAP2H
                                    243 	.globl _RCAP2L
                                    244 	.globl _RCAP2
                                    245 	.globl _T2MOD
                                    246 	.globl _T2CON
                                    247 	.globl _SBUF
                                    248 	.globl _SCON
                                    249 	.globl _TH1
                                    250 	.globl _TH0
                                    251 	.globl _TL1
                                    252 	.globl _TL0
                                    253 	.globl _TMOD
                                    254 	.globl _TCON
                                    255 	.globl _XBUS_AUX
                                    256 	.globl _P7
                                    257 	.globl _P6_DIR
                                    258 	.globl _P6_OUT_PU
                                    259 	.globl _P6_IN
                                    260 	.globl _P5_DIR
                                    261 	.globl _P5_OUT_PU
                                    262 	.globl _P5_IN
                                    263 	.globl _P4_LED_KEY
                                    264 	.globl _P4_DIR_PU
                                    265 	.globl _P4_MOD_OC
                                    266 	.globl _P4
                                    267 	.globl _P3_DIR_PU
                                    268 	.globl _P3_MOD_OC
                                    269 	.globl _P3
                                    270 	.globl _P2_DIR_PU
                                    271 	.globl _P2_MOD_OC
                                    272 	.globl _P2
                                    273 	.globl _P1_DIR_PU
                                    274 	.globl _P1_MOD_OC
                                    275 	.globl _P1
                                    276 	.globl _P0_DIR_PU
                                    277 	.globl _P0_MOD_OC
                                    278 	.globl _P0
                                    279 	.globl _ROM_CTRL
                                    280 	.globl _ROM_DATA_HH
                                    281 	.globl _ROM_DATA_HL
                                    282 	.globl _ROM_DATA_HI
                                    283 	.globl _ROM_ADDR_H
                                    284 	.globl _ROM_ADDR_L
                                    285 	.globl _ROM_ADDR
                                    286 	.globl _GPIO_IE
                                    287 	.globl _IP_EX
                                    288 	.globl _IE_EX
                                    289 	.globl _IP
                                    290 	.globl _IE
                                    291 	.globl _WDOG_COUNT
                                    292 	.globl _RESET_KEEP
                                    293 	.globl _WAKE_CTRL
                                    294 	.globl _CLOCK_CFG
                                    295 	.globl _POWER_CFG
                                    296 	.globl _PCON
                                    297 	.globl _GLOBAL_CFG
                                    298 	.globl _SAFE_MOD
                                    299 	.globl _DPH
                                    300 	.globl _DPL
                                    301 	.globl _SP
                                    302 	.globl _A_INV
                                    303 	.globl _B
                                    304 	.globl _ACC
                                    305 	.globl _PSW
                                    306 	.globl _disable_action_cache
                                    307 	.globl _tap_code_delay_PARM_2
                                    308 	.globl _process_action_PARM_2
                                    309 	.globl _action_exec_PARM_1
                                    310 	.globl _tp_buttons
                                    311 	.globl _action_exec
                                    312 	.globl _ak820_action_exec
                                    313 	.globl _process_record
                                    314 	.globl _process_record_handler
                                    315 	.globl _process_action
                                    316 	.globl _register_code
                                    317 	.globl _unregister_code
                                    318 	.globl _tap_code_delay
                                    319 	.globl _tap_code
                                    320 	.globl _register_mods
                                    321 	.globl _unregister_mods
                                    322 	.globl _register_weak_mods
                                    323 	.globl _unregister_weak_mods
                                    324 	.globl _clear_keyboard
                                    325 	.globl _clear_keyboard_but_mods
                                    326 	.globl _clear_keyboard_but_mods_and_keys
                                    327 ;--------------------------------------------------------
                                    328 ; special function registers
                                    329 ;--------------------------------------------------------
                                    330 	.area RSEG    (ABS,DATA)
      000000                        331 	.org 0x0000
                           0000D0   332 _PSW	=	0x00d0
                           0000E0   333 _ACC	=	0x00e0
                           0000F0   334 _B	=	0x00f0
                           0000FD   335 _A_INV	=	0x00fd
                           000081   336 _SP	=	0x0081
                           000082   337 _DPL	=	0x0082
                           000083   338 _DPH	=	0x0083
                           0000A1   339 _SAFE_MOD	=	0x00a1
                           0000B1   340 _GLOBAL_CFG	=	0x00b1
                           000087   341 _PCON	=	0x0087
                           0000BA   342 _POWER_CFG	=	0x00ba
                           0000B9   343 _CLOCK_CFG	=	0x00b9
                           0000A9   344 _WAKE_CTRL	=	0x00a9
                           0000FE   345 _RESET_KEEP	=	0x00fe
                           0000FF   346 _WDOG_COUNT	=	0x00ff
                           0000A8   347 _IE	=	0x00a8
                           0000B8   348 _IP	=	0x00b8
                           0000E8   349 _IE_EX	=	0x00e8
                           0000E9   350 _IP_EX	=	0x00e9
                           0000B2   351 _GPIO_IE	=	0x00b2
                           008584   352 _ROM_ADDR	=	0x8584
                           000084   353 _ROM_ADDR_L	=	0x0084
                           000085   354 _ROM_ADDR_H	=	0x0085
                           008F8E   355 _ROM_DATA_HI	=	0x8f8e
                           00008E   356 _ROM_DATA_HL	=	0x008e
                           00008F   357 _ROM_DATA_HH	=	0x008f
                           000086   358 _ROM_CTRL	=	0x0086
                           000080   359 _P0	=	0x0080
                           0000C4   360 _P0_MOD_OC	=	0x00c4
                           0000C5   361 _P0_DIR_PU	=	0x00c5
                           000090   362 _P1	=	0x0090
                           000092   363 _P1_MOD_OC	=	0x0092
                           000093   364 _P1_DIR_PU	=	0x0093
                           0000A0   365 _P2	=	0x00a0
                           000094   366 _P2_MOD_OC	=	0x0094
                           000095   367 _P2_DIR_PU	=	0x0095
                           0000B0   368 _P3	=	0x00b0
                           000096   369 _P3_MOD_OC	=	0x0096
                           000097   370 _P3_DIR_PU	=	0x0097
                           0000C0   371 _P4	=	0x00c0
                           0000C2   372 _P4_MOD_OC	=	0x00c2
                           0000C3   373 _P4_DIR_PU	=	0x00c3
                           0000C1   374 _P4_LED_KEY	=	0x00c1
                           0000AA   375 _P5_IN	=	0x00aa
                           0000AB   376 _P5_OUT_PU	=	0x00ab
                           0000AC   377 _P5_DIR	=	0x00ac
                           0000AD   378 _P6_IN	=	0x00ad
                           0000AE   379 _P6_OUT_PU	=	0x00ae
                           0000AF   380 _P6_DIR	=	0x00af
                           0000F1   381 _P7	=	0x00f1
                           0000A2   382 _XBUS_AUX	=	0x00a2
                           000088   383 _TCON	=	0x0088
                           000089   384 _TMOD	=	0x0089
                           00008A   385 _TL0	=	0x008a
                           00008B   386 _TL1	=	0x008b
                           00008C   387 _TH0	=	0x008c
                           00008D   388 _TH1	=	0x008d
                           000098   389 _SCON	=	0x0098
                           000099   390 _SBUF	=	0x0099
                           0000C8   391 _T2CON	=	0x00c8
                           0000C9   392 _T2MOD	=	0x00c9
                           00CBCA   393 _RCAP2	=	0xcbca
                           0000CA   394 _RCAP2L	=	0x00ca
                           0000CB   395 _RCAP2H	=	0x00cb
                           00CDCC   396 _T2COUNT	=	0xcdcc
                           0000CC   397 _TL2	=	0x00cc
                           0000CD   398 _TH2	=	0x00cd
                           00CFCE   399 _T2CAP1	=	0xcfce
                           0000CE   400 _T2CAP1L	=	0x00ce
                           0000CF   401 _T2CAP1H	=	0x00cf
                           0000F8   402 _SPI0_STAT	=	0x00f8
                           0000F9   403 _SPI0_DATA	=	0x00f9
                           0000FA   404 _SPI0_CTRL	=	0x00fa
                           0000FB   405 _SPI0_CK_SE	=	0x00fb
                           0000FC   406 _SPI0_SETUP	=	0x00fc
                           0000BC   407 _SCON1	=	0x00bc
                           0000BD   408 _SBUF1	=	0x00bd
                           0000BE   409 _SBAUD1	=	0x00be
                           0000BF   410 _SIF1	=	0x00bf
                           0000B4   411 _SPI1_STAT	=	0x00b4
                           0000B5   412 _SPI1_DATA	=	0x00b5
                           0000B6   413 _SPI1_CTRL	=	0x00b6
                           0000B7   414 _SPI1_CK_SE	=	0x00b7
                           0000F3   415 _ADC_CTRL	=	0x00f3
                           00F5F4   416 _ADC_DAT	=	0xf5f4
                           0000F4   417 _ADC_DAT_L	=	0x00f4
                           0000F5   418 _ADC_DAT_H	=	0x00f5
                           0000F6   419 _ADC_CHAN	=	0x00f6
                           0000A6   420 _LED_COMMON	=	0x00a6
                           0000A7   421 _LED_PWM_OE	=	0x00a7
                           00C7C6   422 _LED_DMA	=	0xc7c6
                           0000C6   423 _LED_DMA_L	=	0x00c6
                           0000C7   424 _LED_DMA_H	=	0x00c7
                           0000F7   425 _LED_STATUS	=	0x00f7
                           0000B3   426 _I2CX_INT	=	0x00b3
                           0000BB   427 _I2CS_INT_ST	=	0x00bb
                                    428 ;--------------------------------------------------------
                                    429 ; special function bits
                                    430 ;--------------------------------------------------------
                                    431 	.area RSEG    (ABS,DATA)
      000000                        432 	.org 0x0000
                           0000D7   433 _CY	=	0x00d7
                           0000D6   434 _AC	=	0x00d6
                           0000D5   435 _F0	=	0x00d5
                           0000D4   436 _RS1	=	0x00d4
                           0000D3   437 _RS0	=	0x00d3
                           0000D2   438 _OV	=	0x00d2
                           0000D1   439 _F1	=	0x00d1
                           0000D0   440 _P	=	0x00d0
                           0000AF   441 _EA	=	0x00af
                           0000AE   442 _E_DIS	=	0x00ae
                           0000AD   443 _ET2	=	0x00ad
                           0000AC   444 _ES	=	0x00ac
                           0000AB   445 _ET1	=	0x00ab
                           0000AA   446 _EX1	=	0x00aa
                           0000A9   447 _ET0	=	0x00a9
                           0000A8   448 _EX0	=	0x00a8
                           0000BF   449 _PH_FLAG	=	0x00bf
                           0000BE   450 _PL_FLAG	=	0x00be
                           0000BD   451 _PT2	=	0x00bd
                           0000BC   452 _PS	=	0x00bc
                           0000BB   453 _PT1	=	0x00bb
                           0000BA   454 _PX1	=	0x00ba
                           0000B9   455 _PT0	=	0x00b9
                           0000B8   456 _PX0	=	0x00b8
                           0000EF   457 _IE_WDOG	=	0x00ef
                           0000EE   458 _IE_GPIO	=	0x00ee
                           0000ED   459 _IE_PWM_I2C	=	0x00ed
                           0000EC   460 _IE_UART1	=	0x00ec
                           0000EB   461 _IE_ADC	=	0x00eb
                           0000E9   462 _IE_USB	=	0x00e9
                           0000E8   463 _IE_SPI0	=	0x00e8
                           000087   464 _P0_7	=	0x0087
                           000086   465 _P0_6	=	0x0086
                           000085   466 _P0_5	=	0x0085
                           000084   467 _P0_4	=	0x0084
                           000083   468 _P0_3	=	0x0083
                           000082   469 _P0_2	=	0x0082
                           000081   470 _P0_1	=	0x0081
                           000080   471 _P0_0	=	0x0080
                           000081   472 _SDA0	=	0x0081
                           000080   473 _SCL0	=	0x0080
                           000083   474 _TXD_	=	0x0083
                           000082   475 _RXD_	=	0x0082
                           000085   476 _AIN13	=	0x0085
                           000084   477 _AIN12	=	0x0084
                           000083   478 _AIN11	=	0x0083
                           000082   479 _AIN10	=	0x0082
                           000081   480 _AIN9	=	0x0081
                           000080   481 _AIN8	=	0x0080
                           000097   482 _P1_7	=	0x0097
                           000096   483 _P1_6	=	0x0096
                           000095   484 _P1_5	=	0x0095
                           000094   485 _P1_4	=	0x0094
                           000093   486 _P1_3	=	0x0093
                           000092   487 _P1_2	=	0x0092
                           000091   488 _P1_1	=	0x0091
                           000090   489 _P1_0	=	0x0090
                           000097   490 _TXD1_	=	0x0097
                           000096   491 _RXD1_	=	0x0096
                           000097   492 _SCK	=	0x0097
                           000096   493 _MISO	=	0x0096
                           000095   494 _MOSI	=	0x0095
                           000094   495 _SCS	=	0x0094
                           000092   496 _INT0_	=	0x0092
                           000091   497 _T2EX	=	0x0091
                           000091   498 _CAP2	=	0x0091
                           000090   499 _T2	=	0x0090
                           000090   500 _CAP1	=	0x0090
                           000097   501 _AIN7	=	0x0097
                           000096   502 _AIN6	=	0x0096
                           000095   503 _AIN5	=	0x0095
                           000094   504 _AIN4	=	0x0094
                           000093   505 _AIN3	=	0x0093
                           000092   506 _AIN2	=	0x0092
                           000091   507 _AIN1	=	0x0091
                           000090   508 _AIN0	=	0x0090
                           0000A7   509 _P2_7	=	0x00a7
                           0000A6   510 _P2_6	=	0x00a6
                           0000A5   511 _P2_5	=	0x00a5
                           0000A4   512 _P2_4	=	0x00a4
                           0000A3   513 _P2_3	=	0x00a3
                           0000A2   514 _P2_2	=	0x00a2
                           0000A1   515 _P2_1	=	0x00a1
                           0000A0   516 _P2_0	=	0x00a0
                           0000A7   517 _TXD1	=	0x00a7
                           0000A6   518 _RXD1	=	0x00a6
                           0000A5   519 _T2EX_	=	0x00a5
                           0000A5   520 _CAP2_	=	0x00a5
                           0000A4   521 _T2_	=	0x00a4
                           0000A4   522 _CAP1_	=	0x00a4
                           0000B7   523 _P3_7	=	0x00b7
                           0000B6   524 _P3_6	=	0x00b6
                           0000B5   525 _P3_5	=	0x00b5
                           0000B4   526 _P3_4	=	0x00b4
                           0000B3   527 _P3_3	=	0x00b3
                           0000B2   528 _P3_2	=	0x00b2
                           0000B1   529 _P3_1	=	0x00b1
                           0000B0   530 _P3_0	=	0x00b0
                           0000B7   531 _SCK1	=	0x00b7
                           0000B6   532 _MISO1	=	0x00b6
                           0000B5   533 _MOSI1	=	0x00b5
                           0000B5   534 _T1	=	0x00b5
                           0000B4   535 _T0	=	0x00b4
                           0000B3   536 _INT1	=	0x00b3
                           0000B2   537 _INT0	=	0x00b2
                           0000B1   538 _TXD	=	0x00b1
                           0000B0   539 _RXD	=	0x00b0
                           0000C6   540 _P4_6	=	0x00c6
                           0000C5   541 _P4_5	=	0x00c5
                           0000C4   542 _P4_4	=	0x00c4
                           0000C3   543 _P4_3	=	0x00c3
                           0000C2   544 _P4_2	=	0x00c2
                           0000C1   545 _P4_1	=	0x00c1
                           0000C0   546 _P4_0	=	0x00c0
                           00008F   547 _TF1	=	0x008f
                           00008E   548 _TR1	=	0x008e
                           00008D   549 _TF0	=	0x008d
                           00008C   550 _TR0	=	0x008c
                           00008B   551 _IE1	=	0x008b
                           00008A   552 _IT1	=	0x008a
                           000089   553 _IE0	=	0x0089
                           000088   554 _IT0	=	0x0088
                           00009F   555 _SM0	=	0x009f
                           00009E   556 _SM1	=	0x009e
                           00009D   557 _SM2	=	0x009d
                           00009C   558 _REN	=	0x009c
                           00009B   559 _TB8	=	0x009b
                           00009A   560 _RB8	=	0x009a
                           000099   561 _TI	=	0x0099
                           000098   562 _RI	=	0x0098
                           0000CF   563 _TF2	=	0x00cf
                           0000CF   564 _CAP1F	=	0x00cf
                           0000CE   565 _EXF2	=	0x00ce
                           0000CD   566 _RCLK	=	0x00cd
                           0000CC   567 _TCLK	=	0x00cc
                           0000CB   568 _EXEN2	=	0x00cb
                           0000CA   569 _TR2	=	0x00ca
                           0000C9   570 _C_T2	=	0x00c9
                           0000C8   571 _CP_RL2	=	0x00c8
                           0000FF   572 _S0_FST_ACT	=	0x00ff
                           0000FE   573 _S0_IF_OV	=	0x00fe
                           0000FD   574 _S0_IF_FIRST	=	0x00fd
                           0000FC   575 _S0_IF_BYTE	=	0x00fc
                           0000FB   576 _S0_FREE	=	0x00fb
                           0000FA   577 _S0_T_FIFO	=	0x00fa
                           0000F8   578 _S0_R_FIFO	=	0x00f8
                           0000F7   579 _ADC_START	=	0x00f7
                                    580 ;--------------------------------------------------------
                                    581 ; overlayable register banks
                                    582 ;--------------------------------------------------------
                                    583 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        584 	.ds 8
                                    585 ;--------------------------------------------------------
                                    586 ; internal ram data
                                    587 ;--------------------------------------------------------
                                    588 	.area DSEG    (DATA)
      000027                        589 _process_action_sloc0_1_0:
      000027                        590 	.ds 1
                                    591 ;--------------------------------------------------------
                                    592 ; overlayable items in internal ram
                                    593 ;--------------------------------------------------------
                                    594 ;--------------------------------------------------------
                                    595 ; indirectly addressable internal ram data
                                    596 ;--------------------------------------------------------
                                    597 	.area ISEG    (DATA)
                                    598 ;--------------------------------------------------------
                                    599 ; absolute internal ram data
                                    600 ;--------------------------------------------------------
                                    601 	.area IABS    (ABS,DATA)
                                    602 	.area IABS    (ABS,DATA)
                                    603 ;--------------------------------------------------------
                                    604 ; bit data
                                    605 ;--------------------------------------------------------
                                    606 	.area BSEG    (BIT)
      00001E                        607 _process_action_sloc1_1_0:
      00001E                        608 	.ds 1
                                    609 ;--------------------------------------------------------
                                    610 ; paged external ram data
                                    611 ;--------------------------------------------------------
                                    612 	.area PSEG    (PAG,XDATA)
                                    613 ;--------------------------------------------------------
                                    614 ; uninitialized external ram data
                                    615 ;--------------------------------------------------------
                                    616 	.area XSEG    (XDATA)
      000856                        617 _tp_buttons::
      000856                        618 	.ds 2
      000858                        619 _action_exec_PARM_1:
      000858                        620 	.ds 6
      00085E                        621 _action_exec_record_10001_648:
      00085E                        622 	.ds 9
      000867                        623 _ak820_action_exec_event_10000_652:
      000867                        624 	.ds 2
      000869                        625 _ak820_action_exec_snapshot_10000_653:
      000869                        626 	.ds 6
      00086F                        627 _process_record_record_argument_10000_656:
      00086F                        628 	.ds 2
      000871                        629 _process_record_handler_record_argument_10000_664:
      000871                        630 	.ds 2
      000873                        631 _process_record_handler_action_10000_665:
      000873                        632 	.ds 2
      000875                        633 _process_action_PARM_2:
      000875                        634 	.ds 2
      000877                        635 _process_action_record_argument_10000_676:
      000877                        636 	.ds 2
      000879                        637 _process_action_on_40000_699:
      000879                        638 	.ds 1
      00087A                        639 _register_code_code_10000_733:
      00087A                        640 	.ds 1
      00087B                        641 _unregister_code_code_10000_747:
      00087B                        642 	.ds 1
      00087C                        643 _tap_code_delay_PARM_2:
      00087C                        644 	.ds 2
      00087E                        645 _tap_code_delay_code_10000_760:
      00087E                        646 	.ds 1
      00087F                        647 _tap_code_code_10000_767:
      00087F                        648 	.ds 1
      000880                        649 _register_mods_mods_10000_769:
      000880                        650 	.ds 1
      000881                        651 _unregister_mods_mods_10000_773:
      000881                        652 	.ds 1
      000882                        653 _register_weak_mods_mods_10000_777:
      000882                        654 	.ds 1
      000883                        655 _unregister_weak_mods_mods_10000_781:
      000883                        656 	.ds 1
                                    657 ;--------------------------------------------------------
                                    658 ; absolute external ram data
                                    659 ;--------------------------------------------------------
                                    660 	.area XABS    (ABS,XDATA)
                                    661 ;--------------------------------------------------------
                                    662 ; initialized external ram data
                                    663 ;--------------------------------------------------------
                                    664 	.area XISEG   (XDATA)
      000DE5                        665 _disable_action_cache::
      000DE5                        666 	.ds 1
                                    667 	.area HOME    (CODE)
                                    668 	.area GSINIT0 (CODE)
                                    669 	.area GSINIT1 (CODE)
                                    670 	.area GSINIT2 (CODE)
                                    671 	.area GSINIT3 (CODE)
                                    672 	.area GSINIT4 (CODE)
                                    673 	.area GSINIT5 (CODE)
                                    674 	.area GSINIT  (CODE)
                                    675 	.area GSFINAL (CODE)
                                    676 	.area CSEG    (CODE)
                                    677 ;--------------------------------------------------------
                                    678 ; global & static initialisations
                                    679 ;--------------------------------------------------------
                                    680 	.area HOME    (CODE)
                                    681 	.area GSINIT  (CODE)
                                    682 	.area GSFINAL (CODE)
                                    683 	.area GSINIT  (CODE)
                                    684 ;--------------------------------------------------------
                                    685 ; Home
                                    686 ;--------------------------------------------------------
                                    687 	.area HOME    (CODE)
                                    688 	.area HOME    (CODE)
                                    689 ;--------------------------------------------------------
                                    690 ; code
                                    691 ;--------------------------------------------------------
                                    692 	.area CSEG    (CODE)
                                    693 ;------------------------------------------------------------
                                    694 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    695 ;------------------------------------------------------------
                                    696 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    697 ;------------------------------------------------------------
                                    698 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    699 ;	-----------------------------------------
                           000007   700 	ar7 = 0x07
                           000006   701 	ar6 = 0x06
                           000005   702 	ar5 = 0x05
                           000004   703 	ar4 = 0x04
                           000003   704 	ar3 = 0x03
                           000002   705 	ar2 = 0x02
                           000001   706 	ar1 = 0x01
                           000000   707 	ar0 = 0x00
                                    708 ;	 function action_exec
                                    709 ;	-----------------------------------------
      00741E                        710 _action_exec:
                                    711 ;	quantum/action.c:101: ak820_combo_tick(event.time);
      00741E 90 08 5A         [24]  712 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      007421 12 37 A5         [24]  713 	lcall	_ak820_outline_0004
      007424 12 35 B8         [24]  714 	lcall	_ak820_combo_tick
                                    715 ;	quantum/action.c:104: if (!ak820_tapping_before(&event)) return;
      007427 90 08 58         [24]  716 	mov	dptr,#_action_exec_PARM_1
      00742A 12 48 D4         [24]  717 	lcall	_ak820_tapping_before
      00742D E5 82            [12]  718 	mov	a, dpl
      00742F 70 01            [24]  719 	jnz	00102$
      007431 22               [24]  720 	ret
      007432                        721 00102$:
                                    722 ;	quantum/action.c:126: if (event.pressed) {
      007432 90 08 5D         [24]  723 	mov	dptr,#(_action_exec_PARM_1 + 0x0005)
      007435 E0               [24]  724 	movx	a,@dptr
      007436 60 03            [24]  725 	jz	00104$
                                    726 ;	quantum/action.c:128: clear_weak_mods();
      007438 12 84 07         [24]  727 	lcall	_clear_weak_mods
      00743B                        728 00104$:
                                    729 ;	quantum/action.c:140: record.event = event;
      00743B 90 0D BD         [24]  730 	mov	dptr,#___memcpy_PARM_2
      00743E 74 58            [12]  731 	mov	a,#_action_exec_PARM_1
      007440 F0               [24]  732 	movx	@dptr,a
      007441 74 08            [12]  733 	mov	a,#(_action_exec_PARM_1 >> 8)
      007443 12 7A 9C         [24]  734 	lcall	_ak820_outline_0050
      007446 12 7A BC         [24]  735 	lcall	_ak820_outline_0115
      007449 90 08 5E         [24]  736 	mov	dptr,#_action_exec_record_10001_648
      00744C F5 F0            [12]  737 	mov	b,a
      00744E 12 BB 20         [24]  738 	lcall	___memcpy
                                    739 ;	quantum/action.c:142: record.tap.count = 0;
      007451 90 08 64         [24]  740 	mov	dptr,#(_action_exec_record_10001_648 + 0x0006)
      007454 E0               [24]  741 	movx	a,@dptr
      007455 54 0F            [12]  742 	anl	a,#0x0f
      007457 F0               [24]  743 	movx	@dptr,a
                                    744 ;	quantum/action.c:147: record.keycode = 0;
      007458 90 08 65         [24]  745 	mov	dptr,#(_action_exec_record_10001_648 + 0x0007)
      00745B 12 53 9C         [24]  746 	lcall	_ak820_outline_0173
                                    747 ;	quantum/action.c:178: if (IS_NOEVENT(record.event) || pre_process_record_quantum(&record)) {
      00745E 90 08 62         [24]  748 	mov	dptr,#(_action_exec_record_10001_648 + 0x0004)
      007461 E0               [24]  749 	movx	a,@dptr
      007462 60 0A            [24]  750 	jz	00107$
      007464 90 08 5E         [24]  751 	mov	dptr,#_action_exec_record_10001_648
      007467 12 A1 CE         [24]  752 	lcall	_pre_process_record_quantum
      00746A E5 82            [12]  753 	mov	a, dpl
      00746C 60 10            [24]  754 	jz	00110$
      00746E                        755 00107$:
                                    756 ;	quantum/action.c:180: if (!ak820_tapping_process(&record)) return;
      00746E 90 08 5E         [24]  757 	mov	dptr,#_action_exec_record_10001_648
      007471 12 49 DD         [24]  758 	lcall	_ak820_tapping_process
      007474 E5 82            [12]  759 	mov	a, dpl
      007476 70 01            [24]  760 	jnz	00106$
      007478 22               [24]  761 	ret
      007479                        762 00106$:
                                    763 ;	quantum/action.c:185: process_record(&record);
      007479 90 08 5E         [24]  764 	mov	dptr,#_action_exec_record_10001_648
                                    765 ;	quantum/action.c:200: }
      00747C 81 BB            [12]  766 	ajmp	_process_record
      00747E                        767 00110$:
      00747E 22               [24]  768 	ret
                                    769 ;------------------------------------------------------------
                                    770 ;Allocation info for local variables in function 'ak820_action_exec'
                                    771 ;------------------------------------------------------------
                                    772 ;event         Allocated with name '_ak820_action_exec_event_10000_652'
                                    773 ;snapshot      Allocated with name '_ak820_action_exec_snapshot_10000_653'
                                    774 ;------------------------------------------------------------
                                    775 ;	quantum/action.c:203: void ak820_action_exec(const keyevent_t __xdata *event) {
                                    776 ;	-----------------------------------------
                                    777 ;	 function ak820_action_exec
                                    778 ;	-----------------------------------------
      00747F                        779 _ak820_action_exec:
      00747F 12 38 52         [24]  780 	lcall	_ak820_outline_0106
      007482 90 08 67         [24]  781 	mov	dptr,#_ak820_action_exec_event_10000_652
      007485 12 38 57         [24]  782 	lcall	_ak820_outline_0107
                                    783 ;	quantum/action.c:206: keyevent_t snapshot = *event;
      007488 90 08 67         [24]  784 	mov	dptr,#_ak820_action_exec_event_10000_652
      00748B 12 38 13         [24]  785 	lcall	_ak820_outline_0058
      00748E 90 0D BD         [24]  786 	mov	dptr,#___memcpy_PARM_2
      007491 ED               [12]  787 	mov	a,r5
      007492 12 37 E4         [24]  788 	lcall	_ak820_outline_0016
      007495 90 0D C0         [24]  789 	mov	dptr,#___memcpy_PARM_3
      007498 12 7A BC         [24]  790 	lcall	_ak820_outline_0115
      00749B 90 08 69         [24]  791 	mov	dptr,#_ak820_action_exec_snapshot_10000_653
      00749E F5 F0            [12]  792 	mov	b,a
      0074A0 12 BB 20         [24]  793 	lcall	___memcpy
                                    794 ;	quantum/action.c:207: action_exec(snapshot);
      0074A3 90 0D BD         [24]  795 	mov	dptr,#___memcpy_PARM_2
      0074A6 74 69            [12]  796 	mov	a,#_ak820_action_exec_snapshot_10000_653
      0074A8 F0               [24]  797 	movx	@dptr,a
      0074A9 74 08            [12]  798 	mov	a,#(_ak820_action_exec_snapshot_10000_653 >> 8)
      0074AB 12 7A 9C         [24]  799 	lcall	_ak820_outline_0050
      0074AE 12 7A BC         [24]  800 	lcall	_ak820_outline_0115
      0074B1 90 08 58         [24]  801 	mov	dptr,#_action_exec_PARM_1
      0074B4 F5 F0            [12]  802 	mov	b,a
      0074B6 12 BB 20         [24]  803 	lcall	___memcpy
                                    804 ;	quantum/action.c:208: }
      0074B9 81 1E            [12]  805 	ajmp	_action_exec
                                    806 ;------------------------------------------------------------
                                    807 ;Allocation info for local variables in function 'process_record_nocache'
                                    808 ;------------------------------------------------------------
                                    809 ;record        Allocated with name '_process_record_nocache_record_10000_654'
                                    810 ;------------------------------------------------------------
                                    811 ;	quantum/action.c:293: void process_record_nocache(keyrecord_t AK820_RECORD_MEM *record) {
                                    812 ;	-----------------------------------------
                                    813 ;	 function process_record
                                    814 ;	-----------------------------------------
      0074BB                        815 _process_record:
      0074BB 12 38 52         [24]  816 	lcall	_ak820_outline_0106
      0074BE 90 08 6F         [24]  817 	mov	dptr,#_process_record_record_argument_10000_656
      0074C1 12 38 57         [24]  818 	lcall	_ak820_outline_0107
                                    819 ;	quantum/action.c:349: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      0074C4 90 08 6F         [24]  820 	mov	dptr,#_process_record_record_argument_10000_656
      0074C7 12 37 FC         [24]  821 	lcall	_ak820_outline_0051
                                    822 ;	quantum/action.c:353: if (IS_NOEVENT(record->event)) {
      0074CA 74 04            [12]  823 	mov	a,#0x04
      0074CC 12 4C B6         [24]  824 	lcall	_ak820_outline_0013
      0074CF 70 01            [24]  825 	jnz	00102$
                                    826 ;	quantum/action.c:354: return;
      0074D1 22               [24]  827 	ret
      0074D2                        828 00102$:
                                    829 ;	quantum/action.c:362: uint8_t oneshot_source = ak820_tapping_source(record->event.key);
      0074D2 8E 04            [24]  830 	mov	ar4,r6
      0074D4 8F 05            [24]  831 	mov	ar5,r7
      0074D6 90 0D BD         [24]  832 	mov	dptr,#___memcpy_PARM_2
      0074D9 EC               [12]  833 	mov	a,r4
      0074DA F0               [24]  834 	movx	@dptr,a
      0074DB ED               [12]  835 	mov	a,r5
      0074DC 12 7A 9C         [24]  836 	lcall	_ak820_outline_0050
      0074DF 12 53 8F         [24]  837 	lcall	_ak820_outline_0114
      0074E2 90 06 6C         [24]  838 	mov	dptr,#_ak820_tapping_source_PARM_1
      0074E5 F5 F0            [12]  839 	mov	b,a
      0074E7 C0 07            [24]  840 	push	ar7
      0074E9 C0 06            [24]  841 	push	ar6
      0074EB 12 BB 20         [24]  842 	lcall	___memcpy
      0074EE 12 48 11         [24]  843 	lcall	_ak820_tapping_source
      0074F1 AD 82            [24]  844 	mov	r5, dpl
      0074F3 D0 06            [24]  845 	pop	ar6
      0074F5 D0 07            [24]  846 	pop	ar7
                                    847 ;	quantum/action.c:363: bool oneshot_pressed = record->event.pressed;
      0074F7 12 42 C3         [24]  848 	lcall	_ak820_outline_0011
      0074FA E0               [24]  849 	movx	a,@dptr
      0074FB FC               [12]  850 	mov	r4,a
                                    851 ;	quantum/action.c:364: record->keycode = get_record_keycode(record, true);
      0074FC 74 07            [12]  852 	mov	a,#0x07
      0074FE 2E               [12]  853 	add	a, r6
      0074FF FA               [12]  854 	mov	r2,a
      007500 E4               [12]  855 	clr	a
      007501 3F               [12]  856 	addc	a, r7
      007502 FB               [12]  857 	mov	r3,a
      007503 90 0C 1F         [24]  858 	mov	dptr,#_get_record_keycode_PARM_2
      007506 12 4C EA         [24]  859 	lcall	_ak820_outline_0055
      007509 C0 07            [24]  860 	push	ar7
      00750B C0 06            [24]  861 	push	ar6
      00750D C0 05            [24]  862 	push	ar5
      00750F C0 04            [24]  863 	push	ar4
      007511 C0 03            [24]  864 	push	ar3
      007513 C0 02            [24]  865 	push	ar2
      007515 12 A1 91         [24]  866 	lcall	_get_record_keycode
      007518 A8 82            [24]  867 	mov	r0, dpl
      00751A A9 83            [24]  868 	mov	r1, dph
      00751C D0 02            [24]  869 	pop	ar2
      00751E D0 03            [24]  870 	pop	ar3
      007520 D0 04            [24]  871 	pop	ar4
      007522 D0 05            [24]  872 	pop	ar5
      007524 D0 06            [24]  873 	pop	ar6
      007526 D0 07            [24]  874 	pop	ar7
      007528 12 43 47         [24]  875 	lcall	_ak820_outline_0148
      00752B 12 53 96         [24]  876 	lcall	_ak820_outline_0165
                                    877 ;	quantum/action.c:365: if (!ak820_oneshot_process(record->keycode, oneshot_source, oneshot_pressed)) return;
      00752E 74 07            [12]  878 	mov	a,#0x07
      007530 12 37 EC         [24]  879 	lcall	_ak820_outline_0017
      007533 12 43 06         [24]  880 	lcall	_ak820_outline_0086
      007536 90 06 7C         [24]  881 	mov	dptr,#_ak820_oneshot_process_PARM_2
      007539 ED               [12]  882 	mov	a,r5
      00753A F0               [24]  883 	movx	@dptr,a
      00753B 90 06 7D         [24]  884 	mov	dptr,#_ak820_oneshot_process_PARM_3
      00753E EC               [12]  885 	mov	a,r4
      00753F F0               [24]  886 	movx	@dptr,a
      007540 12 43 47         [24]  887 	lcall	_ak820_outline_0148
      007543 C0 07            [24]  888 	push	ar7
      007545 C0 06            [24]  889 	push	ar6
      007547 C0 05            [24]  890 	push	ar5
      007549 C0 04            [24]  891 	push	ar4
      00754B 12 4B 77         [24]  892 	lcall	_ak820_oneshot_process
      00754E E5 82            [12]  893 	mov	a, dpl
      007550 D0 04            [24]  894 	pop	ar4
      007552 D0 05            [24]  895 	pop	ar5
      007554 D0 06            [24]  896 	pop	ar6
      007556 D0 07            [24]  897 	pop	ar7
      007558 70 01            [24]  898 	jnz	00104$
      00755A 22               [24]  899 	ret
      00755B                        900 00104$:
                                    901 ;	quantum/action.c:367: if (!process_record_quantum(record)) {
      00755B 12 43 2B         [24]  902 	lcall	_ak820_outline_0121
      00755E C0 07            [24]  903 	push	ar7
      007560 C0 06            [24]  904 	push	ar6
      007562 C0 05            [24]  905 	push	ar5
      007564 C0 04            [24]  906 	push	ar4
      007566 12 A2 0F         [24]  907 	lcall	_process_record_quantum
      007569 E5 82            [12]  908 	mov	a, dpl
      00756B D0 04            [24]  909 	pop	ar4
      00756D D0 05            [24]  910 	pop	ar5
      00756F D0 06            [24]  911 	pop	ar6
      007571 D0 07            [24]  912 	pop	ar7
      007573 70 0A            [24]  913 	jnz	00106$
                                    914 ;	quantum/action.c:369: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      007575 90 05 98         [24]  915 	mov	dptr,#_ak820_oneshot_post_PARM_2
      007578 EC               [12]  916 	mov	a,r4
      007579 F0               [24]  917 	movx	@dptr,a
      00757A 8D 82            [24]  918 	mov	dpl, r5
                                    919 ;	quantum/action.c:376: return;
      00757C 02 2E BB         [24]  920 	ljmp	_ak820_oneshot_post
      00757F                        921 00106$:
                                    922 ;	quantum/action.c:382: process_record_handler(record);
      00757F 12 43 2B         [24]  923 	lcall	_ak820_outline_0121
      007582 C0 05            [24]  924 	push	ar5
      007584 C0 04            [24]  925 	push	ar4
      007586 B1 96            [24]  926 	acall	_process_record_handler
      007588 D0 04            [24]  927 	pop	ar4
      00758A D0 05            [24]  928 	pop	ar5
                                    929 ;	quantum/action.c:390: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      00758C 90 05 98         [24]  930 	mov	dptr,#_ak820_oneshot_post_PARM_2
      00758F EC               [12]  931 	mov	a,r4
      007590 F0               [24]  932 	movx	@dptr,a
      007591 8D 82            [24]  933 	mov	dpl, r5
                                    934 ;	quantum/action.c:392: }
      007593 02 2E BB         [24]  935 	ljmp	_ak820_oneshot_post
                                    936 ;------------------------------------------------------------
                                    937 ;Allocation info for local variables in function 'process_record_handler'
                                    938 ;------------------------------------------------------------
                                    939 ;record_argument Allocated with name '_process_record_handler_record_argument_10000_664'
                                    940 ;record        Allocated with name '_process_record_handler_record_10000_665'
                                    941 ;action        Allocated with name '_process_record_handler_action_10000_665'
                                    942 ;------------------------------------------------------------
                                    943 ;	quantum/action.c:394: void process_record_handler(keyrecord_t AK820_RECORD_MEM *record_argument) {
                                    944 ;	-----------------------------------------
                                    945 ;	 function process_record_handler
                                    946 ;	-----------------------------------------
      007596                        947 _process_record_handler:
      007596 12 38 52         [24]  948 	lcall	_ak820_outline_0106
      007599 90 08 71         [24]  949 	mov	dptr,#_process_record_handler_record_argument_10000_664
      00759C 12 38 57         [24]  950 	lcall	_ak820_outline_0107
                                    951 ;	quantum/action.c:398: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00759F 90 08 71         [24]  952 	mov	dptr,#_process_record_handler_record_argument_10000_664
      0075A2 12 37 BC         [24]  953 	lcall	_ak820_outline_0009
                                    954 ;	quantum/action.c:405: if (record->keycode) {
      0075A5 4C               [12]  955 	orl	a,r4
      0075A6 60 19            [24]  956 	jz	00102$
                                    957 ;	quantum/action.c:406: action.code = action_for_keycode(record->keycode);
      0075A8 12 38 5C         [24]  958 	lcall	_ak820_outline_0125
      0075AB C0 07            [24]  959 	push	ar7
      0075AD C0 06            [24]  960 	push	ar6
      0075AF 12 97 E8         [24]  961 	lcall	_action_for_keycode
      0075B2 12 38 71         [24]  962 	lcall	_ak820_outline_0149
      0075B5 D0 06            [24]  963 	pop	ar6
      0075B7 D0 07            [24]  964 	pop	ar7
      0075B9 90 08 73         [24]  965 	mov	dptr,#_process_record_handler_action_10000_665
      0075BC 12 38 21         [24]  966 	lcall	_ak820_outline_0072
      0075BF 80 2A            [24]  967 	sjmp	00104$
      0075C1                        968 00102$:
                                    969 ;	quantum/action.c:409: action.code = action_for_keycode(ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed));
      0075C1 12 7A 84         [24]  970 	lcall	_ak820_outline_0021
      0075C4 7A 00            [12]  971 	mov	r2,#0x00
      0075C6 12 43 41         [24]  972 	lcall	_ak820_outline_0147
      0075C9 12 42 C3         [24]  973 	lcall	_ak820_outline_0011
      0075CC E0               [24]  974 	movx	a,@dptr
      0075CD 90 09 AE         [24]  975 	mov	dptr,#_ak820_resolve_key_PARM_2
      0075D0 F0               [24]  976 	movx	@dptr,a
      0075D1 12 43 5C         [24]  977 	lcall	_ak820_outline_0186
      0075D4 C0 07            [24]  978 	push	ar7
      0075D6 C0 06            [24]  979 	push	ar6
      0075D8 12 7E 08         [24]  980 	lcall	_ak820_resolve_key
      0075DB 12 97 E8         [24]  981 	lcall	_action_for_keycode
      0075DE 12 38 71         [24]  982 	lcall	_ak820_outline_0149
      0075E1 D0 06            [24]  983 	pop	ar6
      0075E3 D0 07            [24]  984 	pop	ar7
      0075E5 90 08 73         [24]  985 	mov	dptr,#_process_record_handler_action_10000_665
      0075E8 12 38 21         [24]  986 	lcall	_ak820_outline_0072
                                    987 ;	quantum/action.c:418: ac_dprintf("ACTION: ");
      0075EB                        988 00104$:
                                    989 ;	quantum/action.c:429: process_action(record, action);
      0075EB 90 0D BD         [24]  990 	mov	dptr,#___memcpy_PARM_2
      0075EE 74 73            [12]  991 	mov	a,#_process_record_handler_action_10000_665
      0075F0 F0               [24]  992 	movx	@dptr,a
      0075F1 74 08            [12]  993 	mov	a,#(_process_record_handler_action_10000_665 >> 8)
      0075F3 12 7A 9C         [24]  994 	lcall	_ak820_outline_0050
      0075F6 12 53 8F         [24]  995 	lcall	_ak820_outline_0114
      0075F9 90 08 75         [24]  996 	mov	dptr,#_process_action_PARM_2
      0075FC F5 F0            [12]  997 	mov	b,a
      0075FE C0 07            [24]  998 	push	ar7
      007600 C0 06            [24]  999 	push	ar6
      007602 12 BB 20         [24] 1000 	lcall	___memcpy
      007605 D0 06            [24] 1001 	pop	ar6
      007607 D0 07            [24] 1002 	pop	ar7
      007609 12 43 2B         [24] 1003 	lcall	_ak820_outline_0121
                                   1004 ;	quantum/action.c:430: }
      00760C C1 0E            [24] 1005 	ajmp	_process_action
                                   1006 ;------------------------------------------------------------
                                   1007 ;Allocation info for local variables in function 'register_mouse'
                                   1008 ;------------------------------------------------------------
                                   1009 ;pressed       Allocated with name '_register_mouse_PARM_2'
                                   1010 ;mouse_keycode Allocated with name '_register_mouse_mouse_keycode_10000_673'
                                   1011 ;------------------------------------------------------------
                                   1012 ;	quantum/action.c:442: void register_mouse(uint8_t mouse_keycode, bool pressed) {
                                   1013 ;	-----------------------------------------
                                   1014 ;	 function process_action
                                   1015 ;	-----------------------------------------
      00760E                       1016 _process_action:
      00760E 12 38 52         [24] 1017 	lcall	_ak820_outline_0106
      007611 90 08 77         [24] 1018 	mov	dptr,#_process_action_record_argument_10000_676
      007614 12 38 57         [24] 1019 	lcall	_ak820_outline_0107
                                   1020 ;	quantum/action.c:495: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      007617 90 08 77         [24] 1021 	mov	dptr,#_process_action_record_argument_10000_676
      00761A 12 37 A5         [24] 1022 	lcall	_ak820_outline_0004
                                   1023 ;	quantum/action.c:501: pressed = record->event.pressed;
      00761D A3               [24] 1024 	inc	dptr
      00761E A3               [24] 1025 	inc	dptr
      00761F A3               [24] 1026 	inc	dptr
      007620 A3               [24] 1027 	inc	dptr
      007621 A3               [24] 1028 	inc	dptr
      007622 E0               [24] 1029 	movx	a,@dptr
      007623 F5 27            [12] 1030 	mov	_process_action_sloc0_1_0,a
                                   1031 ;	quantum/action.c:525: switch (action.kind.id) {
      007625 90 08 76         [24] 1032 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007628 E0               [24] 1033 	movx	a,@dptr
      007629 C4               [12] 1034 	swap	a
      00762A 54 0F            [12] 1035 	anl	a,#0x0f
      00762C FD               [12] 1036 	mov  r5,a
      00762D 24 F4            [12] 1037 	add	a,#0xff - 0x0b
      00762F 50 03            [24] 1038 	jnc	00434$
      007631 02 78 AF         [24] 1039 	ljmp	00181$
      007634                       1040 00434$:
                                   1041 ;	free result
      007634 ED               [12] 1042 	mov	a,r5
      007635 24 0A            [12] 1043 	add	a,#(00435$-3-.)
      007637 83               [24] 1044 	movc	a,@a+pc
      007638 F5 82            [12] 1045 	mov	dpl,a
      00763A ED               [12] 1046 	mov	a,r5
      00763B 24 10            [12] 1047 	add	a,#(00436$-3-.)
      00763D 83               [24] 1048 	movc	a,@a+pc
      00763E F5 83            [12] 1049 	mov	dph,a
      007640 E4               [12] 1050 	clr	a
      007641 73               [24] 1051 	jmp	@a+dptr
      007642                       1052 00435$:
      007642 5A                    1053 	.db	00102$
      007643 5A                    1054 	.db	00102$
      007644 AF                    1055 	.db	00181$
      007645 AF                    1056 	.db	00181$
      007646 E4                    1057 	.db	00123$
      007647 AF                    1058 	.db	00181$
      007648 AF                    1059 	.db	00181$
      007649 AF                    1060 	.db	00181$
      00764A 44                    1061 	.db	00131$
      00764B 16                    1062 	.db	00147$
      00764C 3C                    1063 	.db	00152$
      00764D 3C                    1064 	.db	00152$
      00764E                       1065 00436$:
      00764E 76                    1066 	.db	00102$>>8
      00764F 76                    1067 	.db	00102$>>8
      007650 78                    1068 	.db	00181$>>8
      007651 78                    1069 	.db	00181$>>8
      007652 76                    1070 	.db	00123$>>8
      007653 78                    1071 	.db	00181$>>8
      007654 78                    1072 	.db	00181$>>8
      007655 78                    1073 	.db	00181$>>8
      007656 77                    1074 	.db	00131$>>8
      007657 78                    1075 	.db	00147$>>8
      007658 78                    1076 	.db	00152$>>8
      007659 78                    1077 	.db	00152$>>8
                                   1078 ;	quantum/action.c:528: case ACT_RMODS: {
      00765A                       1079 00102$:
                                   1080 ;	quantum/action.c:529: mods = (action.kind.id == ACT_LMODS) ? action.key.mods : action.key.mods << 4;
      00765A 90 08 76         [24] 1081 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      00765D E0               [24] 1082 	movx	a,@dptr
      00765E 54 F0            [12] 1083 	anl	a,#0xf0
      007660 70 06            [24] 1084 	jnz	00194$
      007662 12 7A C3         [24] 1085 	lcall	_ak820_outline_0116
      007665 FD               [12] 1086 	mov	r5,a
      007666 80 07            [24] 1087 	sjmp	00195$
      007668                       1088 00194$:
      007668 12 7A C3         [24] 1089 	lcall	_ak820_outline_0116
      00766B C4               [12] 1090 	swap	a
      00766C 54 F0            [12] 1091 	anl	a,#0xf0
      00766E FD               [12] 1092 	mov	r5,a
      00766F                       1093 00195$:
                                   1094 ;	quantum/action.c:531: if (pressed) {
      00766F E5 27            [12] 1095 	mov	a,_process_action_sloc0_1_0
      007671 60 35            [24] 1096 	jz	00119$
                                   1097 ;	quantum/action.c:532: if (mods) {
      007673 ED               [12] 1098 	mov	a,r5
      007674 60 29            [24] 1099 	jz	00110$
                                   1100 ;	quantum/action.c:533: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      007676 12 7A D5         [24] 1101 	lcall	_ak820_outline_0162
      007679 FC               [12] 1102 	mov	r4,a
      00767A BC E0 00         [24] 1103 	cjne	r4,#0xe0,00440$
      00767D                       1104 00440$:
      00767D 40 07            [24] 1105 	jc	00108$
      00767F 12 7A D5         [24] 1106 	lcall	_ak820_outline_0162
      007682 24 18            [12] 1107 	add	a,#0xff - 0xe7
      007684 50 0A            [24] 1108 	jnc	00104$
                                   1109 ;	free result
      007686                       1110 00108$:
      007686 7B 75            [12] 1111 	mov	r3,#_process_action_PARM_2
      007688 7C 08            [12] 1112 	mov	r4,#(_process_action_PARM_2 >> 8)
      00768A 12 33 FC         [24] 1113 	lcall	_ak820_outline_0126
      00768D E0               [24] 1114 	movx	a,@dptr
      00768E 70 07            [24] 1115 	jnz	00105$
      007690                       1116 00104$:
                                   1117 ;	quantum/action.c:537: add_owned_mods(mods);
      007690 8D 82            [24] 1118 	mov	dpl, r5
      007692 12 80 1E         [24] 1119 	lcall	_add_owned_mods
      007695 80 05            [24] 1120 	sjmp	00106$
      007697                       1121 00105$:
                                   1122 ;	quantum/action.c:539: add_owned_weak_mods(mods);
      007697 8D 82            [24] 1123 	mov	dpl, r5
      007699 12 80 3D         [24] 1124 	lcall	_add_owned_weak_mods
      00769C                       1125 00106$:
                                   1126 ;	quantum/action.c:541: send_keyboard_report();
      00769C 12 83 57         [24] 1127 	lcall	_send_keyboard_report
      00769F                       1128 00110$:
                                   1129 ;	quantum/action.c:543: register_code(action.key.code);
      00769F 12 7A AC         [24] 1130 	lcall	_ak820_outline_0078
      0076A2 12 78 C6         [24] 1131 	lcall	_register_code
      0076A5 02 78 AF         [24] 1132 	ljmp	00181$
      0076A8                       1133 00119$:
                                   1134 ;	quantum/action.c:545: unregister_code(action.key.code);
      0076A8 12 7A AC         [24] 1135 	lcall	_ak820_outline_0078
      0076AB C0 05            [24] 1136 	push	ar5
      0076AD 12 79 33         [24] 1137 	lcall	_unregister_code
      0076B0 D0 05            [24] 1138 	pop	ar5
                                   1139 ;	quantum/action.c:546: if (mods) {
      0076B2 ED               [12] 1140 	mov	a,r5
      0076B3 70 03            [24] 1141 	jnz	00444$
      0076B5 02 78 AF         [24] 1142 	ljmp	00181$
      0076B8                       1143 00444$:
                                   1144 ;	quantum/action.c:547: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      0076B8 12 7A D5         [24] 1145 	lcall	_ak820_outline_0162
      0076BB FC               [12] 1146 	mov	r4,a
      0076BC BC E0 00         [24] 1147 	cjne	r4,#0xe0,00445$
      0076BF                       1148 00445$:
      0076BF 40 07            [24] 1149 	jc	00115$
      0076C1 12 7A D5         [24] 1150 	lcall	_ak820_outline_0162
      0076C4 24 18            [12] 1151 	add	a,#0xff - 0xe7
      0076C6 50 0A            [24] 1152 	jnc	00111$
                                   1153 ;	free result
      0076C8                       1154 00115$:
      0076C8 7B 75            [12] 1155 	mov	r3,#_process_action_PARM_2
      0076CA 7C 08            [12] 1156 	mov	r4,#(_process_action_PARM_2 >> 8)
      0076CC 12 33 FC         [24] 1157 	lcall	_ak820_outline_0126
      0076CF E0               [24] 1158 	movx	a,@dptr
      0076D0 70 07            [24] 1159 	jnz	00112$
      0076D2                       1160 00111$:
                                   1161 ;	quantum/action.c:548: del_owned_mods(mods);
      0076D2 8D 82            [24] 1162 	mov	dpl, r5
      0076D4 12 80 2E         [24] 1163 	lcall	_del_owned_mods
      0076D7 80 05            [24] 1164 	sjmp	00113$
      0076D9                       1165 00112$:
                                   1166 ;	quantum/action.c:550: del_owned_weak_mods(mods);
      0076D9 8D 82            [24] 1167 	mov	dpl, r5
      0076DB 12 80 4D         [24] 1168 	lcall	_del_owned_weak_mods
      0076DE                       1169 00113$:
                                   1170 ;	quantum/action.c:552: send_keyboard_report();
      0076DE 12 83 57         [24] 1171 	lcall	_send_keyboard_report
                                   1172 ;	quantum/action.c:555: } break;
      0076E1 02 78 AF         [24] 1173 	ljmp	00181$
                                   1174 ;	quantum/action.c:632: case ACT_USAGE:
      0076E4                       1175 00123$:
                                   1176 ;	quantum/action.c:638: if (record->keycode >= KC_SYSTEM_POWER && record->keycode <= KC_LAUNCHPAD) {
      0076E4 74 07            [12] 1177 	mov	a,#0x07
      0076E6 12 37 EC         [24] 1178 	lcall	_ak820_outline_0017
      0076E9 12 37 D0         [24] 1179 	lcall	_ak820_outline_0010
      0076EC C3               [12] 1180 	clr	c
      0076ED EC               [12] 1181 	mov	a,r4
      0076EE 94 A5            [12] 1182 	subb	a,#0xa5
      0076F0 ED               [12] 1183 	mov	a,r5
      0076F1 94 00            [12] 1184 	subb	a,#0x00
      0076F3 40 15            [24] 1185 	jc	00125$
      0076F5 74 C2            [12] 1186 	mov	a,#0xc2
      0076F7 9C               [12] 1187 	subb	a,r4
      0076F8 E4               [12] 1188 	clr	a
      0076F9 9D               [12] 1189 	subb	a,r5
      0076FA 40 0E            [24] 1190 	jc	00125$
                                   1191 ;	free result
                                   1192 ;	quantum/action.c:639: owned_usage_key((uint8_t)record->keycode, pressed);
      0076FC 90 0A D5         [24] 1193 	mov	dptr,#_owned_usage_key_PARM_2
      0076FF E5 27            [12] 1194 	mov	a,_process_action_sloc0_1_0
      007701 F0               [24] 1195 	movx	@dptr,a
      007702 8E 82            [24] 1196 	mov	dpl, r6
      007704 12 82 03         [24] 1197 	lcall	_owned_usage_key
                                   1198 ;	quantum/action.c:640: break;
      007707 02 78 AF         [24] 1199 	ljmp	00181$
      00770A                       1200 00125$:
                                   1201 ;	quantum/action.c:643: switch (action.usage.page) {
      00770A 12 7A B3         [24] 1202 	lcall	_ak820_outline_0089
      00770D FF               [12] 1203 	mov	r7,a
      00770E 60 08            [24] 1204 	jz	00127$
      007710 BF 01 02         [24] 1205 	cjne	r7,#0x01,00452$
      007713 80 19            [24] 1206 	sjmp	00128$
      007715                       1207 00452$:
      007715 02 78 AF         [24] 1208 	ljmp	00181$
                                   1209 ;	quantum/action.c:644: case PAGE_SYSTEM:
      007718                       1210 00127$:
                                   1211 ;	quantum/action.c:645: host_system_send(pressed ? action.usage.code : 0);
      007718 E5 27            [12] 1212 	mov	a,_process_action_sloc0_1_0
      00771A 60 05            [24] 1213 	jz	00196$
      00771C 12 7A CA         [24] 1214 	lcall	_ak820_outline_0133
      00771F 80 04            [24] 1215 	sjmp	00197$
      007721                       1216 00196$:
      007721 7E 00            [12] 1217 	mov	r6,#0x00
      007723 7F 00            [12] 1218 	mov	r7,#0x00
      007725                       1219 00197$:
      007725 12 43 2B         [24] 1220 	lcall	_ak820_outline_0121
      007728 12 71 1E         [24] 1221 	lcall	_host_system_send
                                   1222 ;	quantum/action.c:646: break;
      00772B 02 78 AF         [24] 1223 	ljmp	00181$
                                   1224 ;	quantum/action.c:647: case PAGE_CONSUMER:
      00772E                       1225 00128$:
                                   1226 ;	quantum/action.c:648: host_consumer_send(pressed ? action.usage.code : 0);
      00772E E5 27            [12] 1227 	mov	a,_process_action_sloc0_1_0
      007730 60 05            [24] 1228 	jz	00198$
      007732 12 7A CA         [24] 1229 	lcall	_ak820_outline_0133
      007735 80 04            [24] 1230 	sjmp	00199$
      007737                       1231 00198$:
      007737 7E 00            [12] 1232 	mov	r6,#0x00
      007739 7F 00            [12] 1233 	mov	r7,#0x00
      00773B                       1234 00199$:
      00773B 12 43 2B         [24] 1235 	lcall	_ak820_outline_0121
      00773E 12 71 4D         [24] 1236 	lcall	_host_consumer_send
                                   1237 ;	quantum/action.c:651: break;
      007741 02 78 AF         [24] 1238 	ljmp	00181$
                                   1239 ;	quantum/action.c:658: case ACT_LAYER: {
      007744                       1240 00131$:
                                   1241 ;	quantum/action.c:659: uint8_t on = action.layer_bitop.on;
      007744 90 08 76         [24] 1242 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007747 E0               [24] 1243 	movx	a,@dptr
      007748 54 03            [12] 1244 	anl	a,#0x03
      00774A 90 08 79         [24] 1245 	mov	dptr,#_process_action_on_40000_699
      00774D F0               [24] 1246 	movx	@dptr,a
                                   1247 ;	quantum/action.c:662: if (on ? (pressed ? (on & ON_PRESS) : (on & ON_RELEASE)) : !pressed) {
      00774E E0               [24] 1248 	movx	a,@dptr
      00774F FF               [12] 1249 	mov	r7,a
      007750 60 11            [24] 1250 	jz	00200$
      007752 E5 27            [12] 1251 	mov	a,_process_action_sloc0_1_0
      007754 60 07            [24] 1252 	jz	00202$
      007756 8F 06            [24] 1253 	mov	ar6,r7
      007758 53 06 01         [24] 1254 	anl	ar6,#0x01
      00775B 80 10            [24] 1255 	sjmp	00201$
      00775D                       1256 00202$:
      00775D 74 02            [12] 1257 	mov	a,#0x02
      00775F 5F               [12] 1258 	anl	a,r7
      007760 FE               [12] 1259 	mov	r6,a
      007761 80 0A            [24] 1260 	sjmp	00201$
      007763                       1261 00200$:
      007763 E5 27            [12] 1262 	mov	a,_process_action_sloc0_1_0
      007765 B4 01 00         [24] 1263 	cjne	a,#0x01,00457$
      007768                       1264 00457$:
      007768 92 1E            [24] 1265 	mov  _process_action_sloc1_1_0,c
      00776A E4               [12] 1266 	clr	a
      00776B 33               [12] 1267 	rlc	a
      00776C FE               [12] 1268 	mov	r6,a
      00776D                       1269 00201$:
      00776D EE               [12] 1270 	mov	a,r6
      00776E 70 03            [24] 1271 	jnz	00458$
      007770 02 78 AF         [24] 1272 	ljmp	00181$
      007773                       1273 00458$:
                                   1274 ;	quantum/action.c:663: uint8_t shift = action.layer_bitop.part * 4;
      007773 12 7A D5         [24] 1275 	lcall	_ak820_outline_0162
      007776 C4               [12] 1276 	swap	a
      007777 03               [12] 1277 	rr	a
      007778 54 07            [12] 1278 	anl	a,#0x07
      00777A 25 E0            [12] 1279 	add	a,acc
      00777C 25 E0            [12] 1280 	add	a,acc
      00777E FF               [12] 1281 	mov	r7,a
                                   1282 ;	quantum/action.c:664: layer_state_t bits = ((layer_state_t)action.layer_bitop.bits) << shift;
      00777F 12 7A D5         [24] 1283 	lcall	_ak820_outline_0162
      007782 54 0F            [12] 1284 	anl	a,#0x0f
      007784 FE               [12] 1285 	mov	r6,a
      007785 8F F0            [24] 1286 	mov	b,r7
      007787 05 F0            [12] 1287 	inc	b
      007789 EE               [12] 1288 	mov	a,r6
      00778A 80 02            [24] 1289 	sjmp	00460$
      00778C                       1290 00459$:
      00778C 25 E0            [12] 1291 	add	a,acc
      00778E                       1292 00460$:
      00778E D5 F0 FB         [24] 1293 	djnz	b,00459$
      007791 FE               [12] 1294 	mov	r6,a
                                   1295 ;	quantum/action.c:665: layer_state_t mask = action.layer_bitop.xbit ? ~(((layer_state_t)0xf) << shift) : 0;
      007792 12 7A D5         [24] 1296 	lcall	_ak820_outline_0162
      007795 30 E4 11         [24] 1297 	jnb	acc.4,00204$
      007798 8F F0            [24] 1298 	mov	b,r7
      00779A 05 F0            [12] 1299 	inc	b
      00779C 74 0F            [12] 1300 	mov	a,#0x0f
      00779E 80 02            [24] 1301 	sjmp	00463$
      0077A0                       1302 00462$:
      0077A0 25 E0            [12] 1303 	add	a,acc
      0077A2                       1304 00463$:
      0077A2 D5 F0 FB         [24] 1305 	djnz	b,00462$
      0077A5 F4               [12] 1306 	cpl	a
      0077A6 FF               [12] 1307 	mov	r7,a
      0077A7 80 02            [24] 1308 	sjmp	00205$
      0077A9                       1309 00204$:
      0077A9 7F 00            [12] 1310 	mov	r7,#0x00
      0077AB                       1311 00205$:
                                   1312 ;	quantum/action.c:666: bits |= mask;
      0077AB EE               [12] 1313 	mov	a,r6
      0077AC 42 07            [12] 1314 	orl	ar7,a
                                   1315 ;	quantum/action.c:667: if (!on) {
      0077AE 90 08 79         [24] 1316 	mov	dptr,#_process_action_on_40000_699
      0077B1 E0               [24] 1317 	movx	a,@dptr
      0077B2 70 31            [24] 1318 	jnz	00143$
                                   1319 ;	quantum/action.c:668: switch (action.layer_bitop.op) {
      0077B4 12 7A B3         [24] 1320 	lcall	_ak820_outline_0089
      0077B7 FE               [12] 1321 	mov	r6,a
      0077B8 2E               [12] 1322 	add	a,r6
                                   1323 ;	quantum/action.c:669: case OP_BIT_AND: default_layer_and(bits); break;
      0077B9 90 77 BD         [24] 1324 	mov	dptr,#00465$
      0077BC 73               [24] 1325 	jmp	@a+dptr
      0077BD                       1326 00465$:
      0077BD 80 06            [24] 1327 	sjmp	00132$
      0077BF 80 0C            [24] 1328 	sjmp	00133$
      0077C1 80 12            [24] 1329 	sjmp	00134$
      0077C3 80 18            [24] 1330 	sjmp	00135$
      0077C5                       1331 00132$:
      0077C5 8F 82            [24] 1332 	mov	dpl, r7
      0077C7 12 7B 2B         [24] 1333 	lcall	_default_layer_and
      0077CA 02 78 AF         [24] 1334 	ljmp	00181$
                                   1335 ;	quantum/action.c:670: case OP_BIT_OR: default_layer_or(bits); break;
      0077CD                       1336 00133$:
      0077CD 8F 82            [24] 1337 	mov	dpl, r7
      0077CF 12 7B 1B         [24] 1338 	lcall	_default_layer_or
      0077D2 02 78 AF         [24] 1339 	ljmp	00181$
                                   1340 ;	quantum/action.c:671: case OP_BIT_XOR: default_layer_xor(bits); break;
      0077D5                       1341 00134$:
      0077D5 8F 82            [24] 1342 	mov	dpl, r7
      0077D7 12 7B 40         [24] 1343 	lcall	_default_layer_xor
      0077DA 02 78 AF         [24] 1344 	ljmp	00181$
                                   1345 ;	quantum/action.c:672: case OP_BIT_SET: default_layer_set(bits); break;
      0077DD                       1346 00135$:
      0077DD 8F 82            [24] 1347 	mov	dpl, r7
      0077DF 12 7B 11         [24] 1348 	lcall	_default_layer_set
                                   1349 ;	quantum/action.c:673: }
      0077E2 02 78 AF         [24] 1350 	ljmp	00181$
      0077E5                       1351 00143$:
                                   1352 ;	quantum/action.c:675: switch (action.layer_bitop.op) {
      0077E5 12 7A B3         [24] 1353 	lcall	_ak820_outline_0089
      0077E8 FE               [12] 1354 	mov	r6,a
      0077E9 2E               [12] 1355 	add	a,r6
                                   1356 ;	quantum/action.c:676: case OP_BIT_AND: layer_and(bits); break;
      0077EA 90 77 EE         [24] 1357 	mov	dptr,#00466$
      0077ED 73               [24] 1358 	jmp	@a+dptr
      0077EE                       1359 00466$:
      0077EE 80 06            [24] 1360 	sjmp	00137$
      0077F0 80 0C            [24] 1361 	sjmp	00138$
      0077F2 80 12            [24] 1362 	sjmp	00139$
      0077F4 80 18            [24] 1363 	sjmp	00140$
      0077F6                       1364 00137$:
      0077F6 8F 82            [24] 1365 	mov	dpl, r7
      0077F8 12 7C B5         [24] 1366 	lcall	_layer_and
      0077FB 02 78 AF         [24] 1367 	ljmp	00181$
                                   1368 ;	quantum/action.c:677: case OP_BIT_OR: layer_or(bits); break;
      0077FE                       1369 00138$:
      0077FE 8F 82            [24] 1370 	mov	dpl, r7
      007800 12 7C A5         [24] 1371 	lcall	_layer_or
      007803 02 78 AF         [24] 1372 	ljmp	00181$
                                   1373 ;	quantum/action.c:678: case OP_BIT_XOR: layer_xor(bits); break;
      007806                       1374 00139$:
      007806 8F 82            [24] 1375 	mov	dpl, r7
      007808 12 7C CA         [24] 1376 	lcall	_layer_xor
      00780B 02 78 AF         [24] 1377 	ljmp	00181$
                                   1378 ;	quantum/action.c:679: case OP_BIT_SET: layer_state_set(bits); break;
      00780E                       1379 00140$:
      00780E 8F 82            [24] 1380 	mov	dpl, r7
      007810 12 7C 47         [24] 1381 	lcall	_layer_state_set
                                   1382 ;	quantum/action.c:683: break;
      007813 02 78 AF         [24] 1383 	ljmp	00181$
                                   1384 ;	quantum/action.c:685: case ACT_LAYER_MODS:
      007816                       1385 00147$:
                                   1386 ;	quantum/action.c:686: if (pressed) {
      007816 E5 27            [12] 1387 	mov	a,_process_action_sloc0_1_0
      007818 60 11            [24] 1388 	jz	00149$
                                   1389 ;	quantum/action.c:687: layer_hold_on(action.layer_mods.layer);
      00781A 12 7A C3         [24] 1390 	lcall	_ak820_outline_0116
      00781D F5 82            [12] 1391 	mov	dpl,a
      00781F 12 7B AE         [24] 1392 	lcall	_layer_hold_on
                                   1393 ;	quantum/action.c:688: register_mods(action.layer_mods.mods);
      007822 12 7A AC         [24] 1394 	lcall	_ak820_outline_0078
      007825 12 79 F5         [24] 1395 	lcall	_register_mods
      007828 02 78 AF         [24] 1396 	ljmp	00181$
      00782B                       1397 00149$:
                                   1398 ;	quantum/action.c:690: unregister_mods(action.layer_mods.mods);
      00782B 12 7A AC         [24] 1399 	lcall	_ak820_outline_0078
      00782E 12 7A 09         [24] 1400 	lcall	_unregister_mods
                                   1401 ;	quantum/action.c:691: layer_hold_off(action.layer_mods.layer);
      007831 12 7A C3         [24] 1402 	lcall	_ak820_outline_0116
      007834 F5 82            [12] 1403 	mov	dpl,a
      007836 12 7B E4         [24] 1404 	lcall	_layer_hold_off
                                   1405 ;	quantum/action.c:693: break;
      007839 02 78 AF         [24] 1406 	ljmp	00181$
                                   1407 ;	quantum/action.c:695: case ACT_LAYER_TAP_EXT:
      00783C                       1408 00152$:
                                   1409 ;	quantum/action.c:696: switch (action.layer_tap.code) {
      00783C 12 7A D5         [24] 1410 	lcall	_ak820_outline_0162
      00783F FF               [12] 1411 	mov	r7,a
      007840 BF F1 02         [24] 1412 	cjne	r7,#0xf1,00468$
      007843 80 0A            [24] 1413 	sjmp	00154$
      007845                       1414 00468$:
      007845 BF F2 02         [24] 1415 	cjne	r7,#0xf2,00469$
      007848 80 19            [24] 1416 	sjmp	00155$
      00784A                       1417 00469$:
                                   1418 ;	quantum/action.c:712: momentary_layer_action:
      00784A BF F3 3B         [24] 1419 	cjne	r7,#0xf3,00160$
      00784D 80 28            [24] 1420 	sjmp	00156$
      00784F                       1421 00154$:
                                   1422 ;	quantum/action.c:713: pressed ? layer_hold_on(action.layer_tap.val) : layer_hold_off(action.layer_tap.val);
      00784F E5 27            [12] 1423 	mov	a,_process_action_sloc0_1_0
      007851 60 08            [24] 1424 	jz	00206$
      007853 12 7A 93         [24] 1425 	lcall	_ak820_outline_0039
      007856 12 7B AE         [24] 1426 	lcall	_layer_hold_on
      007859 80 54            [24] 1427 	sjmp	00181$
      00785B                       1428 00206$:
      00785B 12 7A 93         [24] 1429 	lcall	_ak820_outline_0039
      00785E 12 7B E4         [24] 1430 	lcall	_layer_hold_off
                                   1431 ;	quantum/action.c:714: break;
                                   1432 ;	quantum/action.c:715: case OP_OFF_ON:
      007861 80 4C            [24] 1433 	sjmp	00181$
      007863                       1434 00155$:
                                   1435 ;	quantum/action.c:716: pressed ? layer_off(action.layer_tap.val) : layer_on(action.layer_tap.val);
      007863 E5 27            [12] 1436 	mov	a,_process_action_sloc0_1_0
      007865 60 08            [24] 1437 	jz	00208$
      007867 12 7A 93         [24] 1438 	lcall	_ak820_outline_0039
      00786A 12 7C 88         [24] 1439 	lcall	_layer_off
      00786D 80 40            [24] 1440 	sjmp	00181$
      00786F                       1441 00208$:
      00786F 12 7A 93         [24] 1442 	lcall	_ak820_outline_0039
      007872 12 7C 6E         [24] 1443 	lcall	_layer_on
                                   1444 ;	quantum/action.c:717: break;
                                   1445 ;	quantum/action.c:718: case OP_SET_CLEAR:
      007875 80 38            [24] 1446 	sjmp	00181$
      007877                       1447 00156$:
                                   1448 ;	quantum/action.c:719: pressed ? layer_move(action.layer_tap.val) : layer_clear();
      007877 E5 27            [12] 1449 	mov	a,_process_action_sloc0_1_0
      007879 60 08            [24] 1450 	jz	00210$
      00787B 12 7A 93         [24] 1451 	lcall	_ak820_outline_0039
      00787E 12 7C 59         [24] 1452 	lcall	_layer_move
      007881 80 2C            [24] 1453 	sjmp	00181$
      007883                       1454 00210$:
      007883 12 7C 54         [24] 1455 	lcall	_layer_clear
                                   1456 ;	quantum/action.c:720: break;
                                   1457 ;	quantum/action.c:766: default:
      007886 80 27            [24] 1458 	sjmp	00181$
      007888                       1459 00160$:
                                   1460 ;	quantum/action.c:773: if (pressed) {
      007888 E5 27            [12] 1461 	mov	a,_process_action_sloc0_1_0
      00788A 60 08            [24] 1462 	jz	00163$
                                   1463 ;	quantum/action.c:775: register_code(action.layer_tap.code);
      00788C 12 7A AC         [24] 1464 	lcall	_ak820_outline_0078
      00788F 12 78 C6         [24] 1465 	lcall	_register_code
                                   1466 ;	quantum/action.c:777: ac_dprintf("KEYMAP_TAP_KEY: Tap: unregister_code\n");
      007892 80 1B            [24] 1467 	sjmp	00181$
      007894                       1468 00163$:
                                   1469 ;	quantum/action.c:778: if (action.layer_tap.code == KC_CAPS) {
      007894 12 7A D5         [24] 1470 	lcall	_ak820_outline_0162
      007897 FF               [12] 1471 	mov	r7,a
      007898 BF 39 0E         [24] 1472 	cjne	r7,#0x39,00175$
                                   1473 ;	quantum/action.c:779: wait_ms(TAP_HOLD_CAPS_DELAY);
      00789B 7F 50            [12] 1474 	mov	r7,#0x50
      00789D                       1475 00187$:
      00789D EF               [12] 1476 	mov	a,r7
      00789E 60 09            [24] 1477 	jz	00175$
      0078A0 90 00 01         [24] 1478 	mov	dptr,#0x0001
      0078A3 12 5C F8         [24] 1479 	lcall	_mDelaymS
      0078A6 1F               [12] 1480 	dec	r7
                                   1481 ;	quantum/action.c:781: wait_ms(TAP_CODE_DELAY);
      0078A7 80 F4            [24] 1482 	sjmp	00187$
      0078A9                       1483 00175$:
                                   1484 ;	quantum/action.c:783: unregister_code(action.layer_tap.code);
      0078A9 12 7A AC         [24] 1485 	lcall	_ak820_outline_0078
      0078AC 12 79 33         [24] 1486 	lcall	_unregister_code
                                   1487 ;	quantum/action.c:866: }
      0078AF                       1488 00181$:
                                   1489 ;	quantum/action.c:887: switch (action.kind.id) {
      0078AF 90 08 76         [24] 1490 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0078B2 E0               [24] 1491 	movx	a,@dptr
      0078B3 C4               [12] 1492 	swap	a
      0078B4 54 0F            [12] 1493 	anl	a,#0x0f
      0078B6 FF               [12] 1494 	mov	r7,a
      0078B7 BF 08 02         [24] 1495 	cjne	r7,#0x08,00478$
      0078BA 80 03            [24] 1496 	sjmp	00183$
      0078BC                       1497 00478$:
      0078BC BF 09 06         [24] 1498 	cjne	r7,#0x09,00192$
                                   1499 ;	quantum/action.c:889: case ACT_LAYER_MODS:
      0078BF                       1500 00183$:
                                   1501 ;	quantum/action.c:894: led_set(host_keyboard_leds());
      0078BF 12 70 83         [24] 1502 	lcall	_host_keyboard_leds
                                   1503 ;	quantum/action.c:898: }
                                   1504 ;	quantum/action.c:951: }
      0078C2 02 9A 9B         [24] 1505 	ljmp	_led_set
      0078C5                       1506 00192$:
      0078C5 22               [24] 1507 	ret
                                   1508 ;------------------------------------------------------------
                                   1509 ;Allocation info for local variables in function 'register_code'
                                   1510 ;------------------------------------------------------------
                                   1511 ;code          Allocated with name '_register_code_code_10000_733'
                                   1512 ;------------------------------------------------------------
                                   1513 ;	quantum/action.c:957: __attribute__((weak)) void register_code(uint8_t code) {
                                   1514 ;	-----------------------------------------
                                   1515 ;	 function register_code
                                   1516 ;	-----------------------------------------
      0078C6                       1517 _register_code:
      0078C6 E5 82            [12] 1518 	mov	a,dpl
      0078C8 90 08 7A         [24] 1519 	mov	dptr,#_register_code_code_10000_733
      0078CB F0               [24] 1520 	movx	@dptr,a
                                   1521 ;	quantum/action.c:958: if (code == KC_NO) {
      0078CC E0               [24] 1522 	movx	a,@dptr
      0078CD FF               [12] 1523 	mov	r7,a
      0078CE 70 01            [24] 1524 	jnz	00123$
                                   1525 ;	quantum/action.c:959: return;
      0078D0 22               [24] 1526 	ret
      0078D1                       1527 00123$:
                                   1528 ;	quantum/action.c:994: } else if (IS_BASIC_KEYCODE(code)) {
      0078D1 BF 04 00         [24] 1529 	cjne	r7,#0x04,00186$
      0078D4                       1530 00186$:
      0078D4 40 12            [24] 1531 	jc	00119$
      0078D6 EF               [12] 1532 	mov	a,r7
      0078D7 24 5B            [12] 1533 	add	a,#0xff - 0xa4
      0078D9 40 0D            [24] 1534 	jc	00119$
                                   1535 ;	free result
                                   1536 ;	quantum/action.c:999: if (!add_owned_key(code)) return;
      0078DB 8F 82            [24] 1537 	mov	dpl, r7
      0078DD 12 80 C2         [24] 1538 	lcall	_add_owned_key
      0078E0 E5 82            [12] 1539 	mov	a, dpl
      0078E2 70 01            [24] 1540 	jnz	00104$
      0078E4 22               [24] 1541 	ret
      0078E5                       1542 00104$:
                                   1543 ;	quantum/action.c:1013: send_keyboard_report();
      0078E5 02 83 57         [24] 1544 	ljmp	_send_keyboard_report
      0078E8                       1545 00119$:
                                   1546 ;	quantum/action.c:1014: } else if (IS_MODIFIER_KEYCODE(code)) {
      0078E8 12 7A DA         [24] 1547 	lcall	_ak820_outline_0171
      0078EB BF E0 00         [24] 1548 	cjne	r7,#0xe0,00190$
      0078EE                       1549 00190$:
      0078EE 40 1A            [24] 1550 	jc	00115$
      0078F0 EF               [12] 1551 	mov	a,r7
      0078F1 24 18            [12] 1552 	add	a,#0xff - 0xe7
      0078F3 40 15            [24] 1553 	jc	00115$
                                   1554 ;	free result
                                   1555 ;	quantum/action.c:1015: add_owned_mods(MOD_BIT(code));
      0078F5 74 07            [12] 1556 	mov	a,#0x07
      0078F7 5F               [12] 1557 	anl	a,r7
      0078F8 12 7A A5         [24] 1558 	lcall	_ak820_outline_0064
      0078FB 80 02            [24] 1559 	sjmp	00194$
      0078FD                       1560 00193$:
      0078FD 25 E0            [12] 1561 	add	a,acc
      0078FF                       1562 00194$:
      0078FF D5 F0 FB         [24] 1563 	djnz	b,00193$
      007902 F5 82            [12] 1564 	mov	dpl,a
      007904 12 80 1E         [24] 1565 	lcall	_add_owned_mods
                                   1566 ;	quantum/action.c:1016: send_keyboard_report();
      007907 02 83 57         [24] 1567 	ljmp	_send_keyboard_report
      00790A                       1568 00115$:
                                   1569 ;	quantum/action.c:1019: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      00790A 12 7A DA         [24] 1570 	lcall	_ak820_outline_0171
      00790D BF A5 00         [24] 1571 	cjne	r7,#0xa5,00195$
      007910                       1572 00195$:
      007910 40 05            [24] 1573 	jc	00113$
      007912 EF               [12] 1574 	mov	a,r7
      007913 24 58            [12] 1575 	add	a,#0xff - 0xa7
      007915 50 0D            [24] 1576 	jnc	00108$
                                   1577 ;	free result
      007917                       1578 00113$:
      007917 12 7A DA         [24] 1579 	lcall	_ak820_outline_0171
      00791A BF A8 00         [24] 1580 	cjne	r7,#0xa8,00198$
      00791D                       1581 00198$:
      00791D 40 13            [24] 1582 	jc	00125$
      00791F EF               [12] 1583 	mov	a,r7
      007920 24 3D            [12] 1584 	add	a,#0xff - 0xc2
      007922 40 0E            [24] 1585 	jc	00125$
                                   1586 ;	free result
      007924                       1587 00108$:
                                   1588 ;	quantum/action.c:1021: owned_usage_key(code, true);
      007924 12 7A DA         [24] 1589 	lcall	_ak820_outline_0171
      007927 90 0A D5         [24] 1590 	mov	dptr,#_owned_usage_key_PARM_2
      00792A 74 01            [12] 1591 	mov	a,#0x01
      00792C F0               [24] 1592 	movx	@dptr,a
      00792D 8F 82            [24] 1593 	mov	dpl, r7
                                   1594 ;	quantum/action.c:1029: register_mouse(code, true);
                                   1595 ;	quantum/action.c:1031: }
      00792F 02 82 03         [24] 1596 	ljmp	_owned_usage_key
      007932                       1597 00125$:
      007932 22               [24] 1598 	ret
                                   1599 ;------------------------------------------------------------
                                   1600 ;Allocation info for local variables in function 'unregister_code'
                                   1601 ;------------------------------------------------------------
                                   1602 ;code          Allocated with name '_unregister_code_code_10000_747'
                                   1603 ;------------------------------------------------------------
                                   1604 ;	quantum/action.c:1037: __attribute__((weak)) void unregister_code(uint8_t code) {
                                   1605 ;	-----------------------------------------
                                   1606 ;	 function unregister_code
                                   1607 ;	-----------------------------------------
      007933                       1608 _unregister_code:
      007933 E5 82            [12] 1609 	mov	a,dpl
      007935 90 08 7B         [24] 1610 	mov	dptr,#_unregister_code_code_10000_747
      007938 F0               [24] 1611 	movx	@dptr,a
                                   1612 ;	quantum/action.c:1038: if (code == KC_NO) {
      007939 E0               [24] 1613 	movx	a,@dptr
      00793A FF               [12] 1614 	mov	r7,a
      00793B 70 01            [24] 1615 	jnz	00121$
                                   1616 ;	quantum/action.c:1039: return;
      00793D 22               [24] 1617 	ret
      00793E                       1618 00121$:
                                   1619 ;	quantum/action.c:1071: } else if (IS_BASIC_KEYCODE(code)) {
      00793E BF 04 00         [24] 1620 	cjne	r7,#0x04,00184$
      007941                       1621 00184$:
      007941 40 12            [24] 1622 	jc	00117$
      007943 EF               [12] 1623 	mov	a,r7
      007944 24 5B            [12] 1624 	add	a,#0xff - 0xa4
      007946 40 0D            [24] 1625 	jc	00117$
                                   1626 ;	free result
                                   1627 ;	quantum/action.c:1073: if (!del_owned_key(code)) return;
      007948 8F 82            [24] 1628 	mov	dpl, r7
      00794A 12 81 3C         [24] 1629 	lcall	_del_owned_key
      00794D E5 82            [12] 1630 	mov	a, dpl
      00794F 70 01            [24] 1631 	jnz	00102$
      007951 22               [24] 1632 	ret
      007952                       1633 00102$:
                                   1634 ;	quantum/action.c:1080: send_keyboard_report();
      007952 02 83 57         [24] 1635 	ljmp	_send_keyboard_report
      007955                       1636 00117$:
                                   1637 ;	quantum/action.c:1081: } else if (IS_MODIFIER_KEYCODE(code)) {
      007955 12 7A E0         [24] 1638 	lcall	_ak820_outline_0172
      007958 BF E0 00         [24] 1639 	cjne	r7,#0xe0,00188$
      00795B                       1640 00188$:
      00795B 40 1A            [24] 1641 	jc	00113$
      00795D EF               [12] 1642 	mov	a,r7
      00795E 24 18            [12] 1643 	add	a,#0xff - 0xe7
      007960 40 15            [24] 1644 	jc	00113$
                                   1645 ;	free result
                                   1646 ;	quantum/action.c:1082: del_owned_mods(MOD_BIT(code));
      007962 74 07            [12] 1647 	mov	a,#0x07
      007964 5F               [12] 1648 	anl	a,r7
      007965 12 7A A5         [24] 1649 	lcall	_ak820_outline_0064
      007968 80 02            [24] 1650 	sjmp	00192$
      00796A                       1651 00191$:
      00796A 25 E0            [12] 1652 	add	a,acc
      00796C                       1653 00192$:
      00796C D5 F0 FB         [24] 1654 	djnz	b,00191$
      00796F F5 82            [12] 1655 	mov	dpl,a
      007971 12 80 2E         [24] 1656 	lcall	_del_owned_mods
                                   1657 ;	quantum/action.c:1083: send_keyboard_report();
      007974 02 83 57         [24] 1658 	ljmp	_send_keyboard_report
      007977                       1659 00113$:
                                   1660 ;	quantum/action.c:1086: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      007977 12 7A E0         [24] 1661 	lcall	_ak820_outline_0172
      00797A BF A5 00         [24] 1662 	cjne	r7,#0xa5,00193$
      00797D                       1663 00193$:
      00797D 40 05            [24] 1664 	jc	00111$
      00797F EF               [12] 1665 	mov	a,r7
      007980 24 58            [12] 1666 	add	a,#0xff - 0xa7
      007982 50 0D            [24] 1667 	jnc	00106$
                                   1668 ;	free result
      007984                       1669 00111$:
      007984 12 7A E0         [24] 1670 	lcall	_ak820_outline_0172
      007987 BF A8 00         [24] 1671 	cjne	r7,#0xa8,00196$
      00798A                       1672 00196$:
      00798A 40 12            [24] 1673 	jc	00123$
      00798C EF               [12] 1674 	mov	a,r7
      00798D 24 3D            [12] 1675 	add	a,#0xff - 0xc2
      00798F 40 0D            [24] 1676 	jc	00123$
                                   1677 ;	free result
      007991                       1678 00106$:
                                   1679 ;	quantum/action.c:1088: owned_usage_key(code, false);
      007991 12 7A E0         [24] 1680 	lcall	_ak820_outline_0172
      007994 90 0A D5         [24] 1681 	mov	dptr,#_owned_usage_key_PARM_2
      007997 E4               [12] 1682 	clr	a
      007998 F0               [24] 1683 	movx	@dptr,a
      007999 8F 82            [24] 1684 	mov	dpl, r7
                                   1685 ;	quantum/action.c:1096: register_mouse(code, false);
                                   1686 ;	quantum/action.c:1098: }
      00799B 02 82 03         [24] 1687 	ljmp	_owned_usage_key
      00799E                       1688 00123$:
      00799E 22               [24] 1689 	ret
                                   1690 ;------------------------------------------------------------
                                   1691 ;Allocation info for local variables in function 'tap_code_delay'
                                   1692 ;------------------------------------------------------------
                                   1693 ;delay         Allocated with name '_tap_code_delay_PARM_2'
                                   1694 ;code          Allocated with name '_tap_code_delay_code_10000_760'
                                   1695 ;i             Allocated with name '_tap_code_delay_i_20000_762'
                                   1696 ;i             Allocated with name '_tap_code_delay_i_50000_765'
                                   1697 ;------------------------------------------------------------
                                   1698 ;	quantum/action.c:1105: __attribute__((weak)) void tap_code_delay(uint8_t code, uint16_t delay) {
                                   1699 ;	-----------------------------------------
                                   1700 ;	 function tap_code_delay
                                   1701 ;	-----------------------------------------
      00799F                       1702 _tap_code_delay:
      00799F E5 82            [12] 1703 	mov	a,dpl
      0079A1 90 08 7E         [24] 1704 	mov	dptr,#_tap_code_delay_code_10000_760
      0079A4 F0               [24] 1705 	movx	@dptr,a
                                   1706 ;	quantum/action.c:1106: register_code(code);
      0079A5 E0               [24] 1707 	movx	a,@dptr
      0079A6 FF               [12] 1708 	mov	r7,a
      0079A7 F5 82            [12] 1709 	mov	dpl,a
      0079A9 C0 07            [24] 1710 	push	ar7
      0079AB 11 C6            [12] 1711 	acall	_register_code
      0079AD D0 07            [24] 1712 	pop	ar7
                                   1713 ;	quantum/action.c:1107: for (uint16_t i = delay; i > 0; i--) {
      0079AF 90 08 7C         [24] 1714 	mov	dptr,#_tap_code_delay_PARM_2
      0079B2 12 43 19         [24] 1715 	lcall	_ak820_outline_0096
      0079B5                       1716 00110$:
      0079B5 ED               [12] 1717 	mov	a,r5
      0079B6 4E               [12] 1718 	orl	a,r6
      0079B7 60 0D            [24] 1719 	jz	00105$
                                   1720 ;	quantum/action.c:1108: wait_ms(1);
      0079B9 90 00 01         [24] 1721 	mov	dptr,#0x0001
      0079BC 12 5C F8         [24] 1722 	lcall	_mDelaymS
                                   1723 ;	quantum/action.c:1107: for (uint16_t i = delay; i > 0; i--) {
      0079BF 1D               [12] 1724 	dec	r5
      0079C0 BD FF 01         [24] 1725 	cjne	r5,#0xff,00141$
      0079C3 1E               [12] 1726 	dec	r6
      0079C4                       1727 00141$:
      0079C4 80 EF            [24] 1728 	sjmp	00110$
      0079C6                       1729 00105$:
                                   1730 ;	quantum/action.c:1110: unregister_code(code);
      0079C6 8F 82            [24] 1731 	mov	dpl, r7
                                   1732 ;	quantum/action.c:1111: }
      0079C8 21 33            [12] 1733 	ajmp	_unregister_code
                                   1734 ;------------------------------------------------------------
                                   1735 ;Allocation info for local variables in function 'tap_code'
                                   1736 ;------------------------------------------------------------
                                   1737 ;code          Allocated with name '_tap_code_code_10000_767'
                                   1738 ;------------------------------------------------------------
                                   1739 ;	quantum/action.c:1117: __attribute__((weak)) void tap_code(uint8_t code) {
                                   1740 ;	-----------------------------------------
                                   1741 ;	 function tap_code
                                   1742 ;	-----------------------------------------
      0079CA                       1743 _tap_code:
      0079CA E5 82            [12] 1744 	mov	a,dpl
      0079CC 90 08 7F         [24] 1745 	mov	dptr,#_tap_code_code_10000_767
      0079CF F0               [24] 1746 	movx	@dptr,a
                                   1747 ;	quantum/action.c:1118: tap_code_delay(code, code == KC_CAPS ? QS_tap_hold_caps_delay : QS_tap_code_delay);
      0079D0 E0               [24] 1748 	movx	a,@dptr
      0079D1 FF               [12] 1749 	mov	r7,a
      0079D2 BF 39 0C         [24] 1750 	cjne	r7,#0x39,00103$
      0079D5 C0 07            [24] 1751 	push	ar7
      0079D7 12 47 BD         [24] 1752 	lcall	_ak820_settings_caps_delay
      0079DA 12 43 61         [24] 1753 	lcall	_ak820_outline_0192
      0079DD D0 07            [24] 1754 	pop	ar7
      0079DF 80 0A            [24] 1755 	sjmp	00104$
      0079E1                       1756 00103$:
      0079E1 C0 07            [24] 1757 	push	ar7
      0079E3 12 47 B7         [24] 1758 	lcall	_ak820_settings_tap_code_delay
      0079E6 12 43 61         [24] 1759 	lcall	_ak820_outline_0192
      0079E9 D0 07            [24] 1760 	pop	ar7
      0079EB                       1761 00104$:
      0079EB 90 08 7C         [24] 1762 	mov	dptr,#_tap_code_delay_PARM_2
      0079EE 12 43 3B         [24] 1763 	lcall	_ak820_outline_0140
      0079F1 8F 82            [24] 1764 	mov	dpl, r7
                                   1765 ;	quantum/action.c:1119: }
      0079F3 21 9F            [12] 1766 	ajmp	_tap_code_delay
                                   1767 ;------------------------------------------------------------
                                   1768 ;Allocation info for local variables in function 'register_mods'
                                   1769 ;------------------------------------------------------------
                                   1770 ;mods          Allocated with name '_register_mods_mods_10000_769'
                                   1771 ;------------------------------------------------------------
                                   1772 ;	quantum/action.c:1125: __attribute__((weak)) void register_mods(uint8_t mods) {
                                   1773 ;	-----------------------------------------
                                   1774 ;	 function register_mods
                                   1775 ;	-----------------------------------------
      0079F5                       1776 _register_mods:
      0079F5 E5 82            [12] 1777 	mov	a,dpl
      0079F7 90 08 80         [24] 1778 	mov	dptr,#_register_mods_mods_10000_769
      0079FA F0               [24] 1779 	movx	@dptr,a
                                   1780 ;	quantum/action.c:1126: if (mods) {
      0079FB E0               [24] 1781 	movx	a,@dptr
      0079FC FF               [12] 1782 	mov	r7,a
      0079FD E0               [24] 1783 	movx	a,@dptr
      0079FE 60 08            [24] 1784 	jz	00103$
                                   1785 ;	quantum/action.c:1127: add_owned_mods(mods);
      007A00 8F 82            [24] 1786 	mov	dpl, r7
      007A02 12 80 1E         [24] 1787 	lcall	_add_owned_mods
                                   1788 ;	quantum/action.c:1128: send_keyboard_report();
                                   1789 ;	quantum/action.c:1130: }
      007A05 02 83 57         [24] 1790 	ljmp	_send_keyboard_report
      007A08                       1791 00103$:
      007A08 22               [24] 1792 	ret
                                   1793 ;------------------------------------------------------------
                                   1794 ;Allocation info for local variables in function 'unregister_mods'
                                   1795 ;------------------------------------------------------------
                                   1796 ;mods          Allocated with name '_unregister_mods_mods_10000_773'
                                   1797 ;------------------------------------------------------------
                                   1798 ;	quantum/action.c:1136: __attribute__((weak)) void unregister_mods(uint8_t mods) {
                                   1799 ;	-----------------------------------------
                                   1800 ;	 function unregister_mods
                                   1801 ;	-----------------------------------------
      007A09                       1802 _unregister_mods:
      007A09 E5 82            [12] 1803 	mov	a,dpl
      007A0B 90 08 81         [24] 1804 	mov	dptr,#_unregister_mods_mods_10000_773
      007A0E F0               [24] 1805 	movx	@dptr,a
                                   1806 ;	quantum/action.c:1137: if (mods) {
      007A0F E0               [24] 1807 	movx	a,@dptr
      007A10 FF               [12] 1808 	mov	r7,a
      007A11 E0               [24] 1809 	movx	a,@dptr
      007A12 60 08            [24] 1810 	jz	00103$
                                   1811 ;	quantum/action.c:1138: del_owned_mods(mods);
      007A14 8F 82            [24] 1812 	mov	dpl, r7
      007A16 12 80 2E         [24] 1813 	lcall	_del_owned_mods
                                   1814 ;	quantum/action.c:1139: send_keyboard_report();
                                   1815 ;	quantum/action.c:1141: }
      007A19 02 83 57         [24] 1816 	ljmp	_send_keyboard_report
      007A1C                       1817 00103$:
      007A1C 22               [24] 1818 	ret
                                   1819 ;------------------------------------------------------------
                                   1820 ;Allocation info for local variables in function 'register_weak_mods'
                                   1821 ;------------------------------------------------------------
                                   1822 ;mods          Allocated with name '_register_weak_mods_mods_10000_777'
                                   1823 ;------------------------------------------------------------
                                   1824 ;	quantum/action.c:1147: __attribute__((weak)) void register_weak_mods(uint8_t mods) {
                                   1825 ;	-----------------------------------------
                                   1826 ;	 function register_weak_mods
                                   1827 ;	-----------------------------------------
      007A1D                       1828 _register_weak_mods:
      007A1D E5 82            [12] 1829 	mov	a,dpl
      007A1F 90 08 82         [24] 1830 	mov	dptr,#_register_weak_mods_mods_10000_777
      007A22 F0               [24] 1831 	movx	@dptr,a
                                   1832 ;	quantum/action.c:1148: if (mods) {
      007A23 E0               [24] 1833 	movx	a,@dptr
      007A24 FF               [12] 1834 	mov	r7,a
      007A25 E0               [24] 1835 	movx	a,@dptr
      007A26 60 08            [24] 1836 	jz	00103$
                                   1837 ;	quantum/action.c:1149: add_owned_weak_mods(mods);
      007A28 8F 82            [24] 1838 	mov	dpl, r7
      007A2A 12 80 3D         [24] 1839 	lcall	_add_owned_weak_mods
                                   1840 ;	quantum/action.c:1150: send_keyboard_report();
                                   1841 ;	quantum/action.c:1152: }
      007A2D 02 83 57         [24] 1842 	ljmp	_send_keyboard_report
      007A30                       1843 00103$:
      007A30 22               [24] 1844 	ret
                                   1845 ;------------------------------------------------------------
                                   1846 ;Allocation info for local variables in function 'unregister_weak_mods'
                                   1847 ;------------------------------------------------------------
                                   1848 ;mods          Allocated with name '_unregister_weak_mods_mods_10000_781'
                                   1849 ;------------------------------------------------------------
                                   1850 ;	quantum/action.c:1158: __attribute__((weak)) void unregister_weak_mods(uint8_t mods) {
                                   1851 ;	-----------------------------------------
                                   1852 ;	 function unregister_weak_mods
                                   1853 ;	-----------------------------------------
      007A31                       1854 _unregister_weak_mods:
      007A31 E5 82            [12] 1855 	mov	a,dpl
      007A33 90 08 83         [24] 1856 	mov	dptr,#_unregister_weak_mods_mods_10000_781
      007A36 F0               [24] 1857 	movx	@dptr,a
                                   1858 ;	quantum/action.c:1159: if (mods) {
      007A37 E0               [24] 1859 	movx	a,@dptr
      007A38 FF               [12] 1860 	mov	r7,a
      007A39 E0               [24] 1861 	movx	a,@dptr
      007A3A 60 08            [24] 1862 	jz	00103$
                                   1863 ;	quantum/action.c:1160: del_owned_weak_mods(mods);
      007A3C 8F 82            [24] 1864 	mov	dpl, r7
      007A3E 12 80 4D         [24] 1865 	lcall	_del_owned_weak_mods
                                   1866 ;	quantum/action.c:1161: send_keyboard_report();
                                   1867 ;	quantum/action.c:1163: }
      007A41 02 83 57         [24] 1868 	ljmp	_send_keyboard_report
      007A44                       1869 00103$:
      007A44 22               [24] 1870 	ret
                                   1871 ;------------------------------------------------------------
                                   1872 ;Allocation info for local variables in function 'clear_keyboard'
                                   1873 ;------------------------------------------------------------
                                   1874 ;	quantum/action.c:1169: void clear_keyboard(void) {
                                   1875 ;	-----------------------------------------
                                   1876 ;	 function clear_keyboard
                                   1877 ;	-----------------------------------------
      007A45                       1878 _clear_keyboard:
                                   1879 ;	quantum/action.c:1170: clear_mods();
      007A45 12 83 D2         [24] 1880 	lcall	_clear_mods
                                   1881 ;	quantum/action.c:1171: clear_keyboard_but_mods();
                                   1882 ;	quantum/action.c:1172: }
      007A48 41 4A            [12] 1883 	ajmp	_clear_keyboard_but_mods
                                   1884 ;------------------------------------------------------------
                                   1885 ;Allocation info for local variables in function 'clear_keyboard_but_mods'
                                   1886 ;------------------------------------------------------------
                                   1887 ;	quantum/action.c:1178: void clear_keyboard_but_mods(void) {
                                   1888 ;	-----------------------------------------
                                   1889 ;	 function clear_keyboard_but_mods
                                   1890 ;	-----------------------------------------
      007A4A                       1891 _clear_keyboard_but_mods:
                                   1892 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007A4A 90 0D EA         [24] 1893 	mov	dptr,#_actual_keyboard_report
      007A4D 12 73 3C         [24] 1894 	lcall	_clear_keys_from_report
                                   1895 ;	quantum/action.c:1180: clear_keyboard_but_mods_and_keys();
                                   1896 ;	quantum/action.c:1181: }
      007A50 41 52            [12] 1897 	ajmp	_clear_keyboard_but_mods_and_keys
                                   1898 ;------------------------------------------------------------
                                   1899 ;Allocation info for local variables in function 'clear_keyboard_but_mods_and_keys'
                                   1900 ;------------------------------------------------------------
                                   1901 ;	quantum/action.c:1187: void clear_keyboard_but_mods_and_keys(void) {
                                   1902 ;	-----------------------------------------
                                   1903 ;	 function clear_keyboard_but_mods_and_keys
                                   1904 ;	-----------------------------------------
      007A52                       1905 _clear_keyboard_but_mods_and_keys:
                                   1906 ;	quantum/action.c:1189: ak820_tapping_cancel();
      007A52 12 4B 56         [24] 1907 	lcall	_ak820_tapping_cancel
                                   1908 ;	quantum/action.c:1206: ak820_oneshot_cancel();
      007A55 12 2E F0         [24] 1909 	lcall	_ak820_oneshot_cancel
                                   1910 ;	quantum/action.c:1209: ak820_combo_cancel();
      007A58 12 35 28         [24] 1911 	lcall	_ak820_combo_cancel
                                   1912 ;	quantum/action.c:1212: repeat_key_cancel();
      007A5B 12 A3 F9         [24] 1913 	lcall	_repeat_key_cancel
                                   1914 ;	quantum/action.c:1214: clear_owned_mods();
      007A5E 12 80 5D         [24] 1915 	lcall	_clear_owned_mods
                                   1916 ;	quantum/action.c:1215: clear_owned_keys();
      007A61 12 80 95         [24] 1917 	lcall	_clear_owned_keys
                                   1918 ;	quantum/action.c:1216: clear_owned_usages();
      007A64 12 81 CB         [24] 1919 	lcall	_clear_owned_usages
                                   1920 ;	quantum/action.c:1217: layer_hold_clear();
      007A67 91 1A            [12] 1921 	acall	_layer_hold_clear
                                   1922 ;	quantum/action.c:1219: clear_macro_tri_layer();
      007A69 12 9F A6         [24] 1923 	lcall	_clear_macro_tri_layer
                                   1924 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007A6C 90 0D EA         [24] 1925 	mov	dptr,#_actual_keyboard_report
      007A6F 12 73 3C         [24] 1926 	lcall	_clear_keys_from_report
                                   1927 ;	quantum/action.c:1224: host_system_send(0);
      007A72 90 00 00         [24] 1928 	mov	dptr,#0x0000
      007A75 12 71 1E         [24] 1929 	lcall	_host_system_send
                                   1930 ;	quantum/action.c:1225: host_consumer_send(0);
      007A78 90 00 00         [24] 1931 	mov	dptr,#0x0000
      007A7B 12 71 4D         [24] 1932 	lcall	_host_consumer_send
                                   1933 ;	quantum/action.c:1227: clear_weak_mods();
      007A7E 12 84 07         [24] 1934 	lcall	_clear_weak_mods
                                   1935 ;	quantum/action.c:1228: send_keyboard_report();
                                   1936 ;	quantum/action.c:1236: }
      007A81 02 83 57         [24] 1937 	ljmp	_send_keyboard_report
                                   1938 ;------------------------------------------------------------
                                   1939 ;Allocation info for local variables in function 'is_tap_record'
                                   1940 ;------------------------------------------------------------
                                   1941 ;record        Allocated with name '_is_tap_record_record_10000_797'
                                   1942 ;action        Allocated with name '_is_tap_record_action_10001_801'
                                   1943 ;------------------------------------------------------------
                                   1944 ;	quantum/action.c:1242: bool is_tap_record(keyrecord_t *record) {
                                   1945 ;	-----------------------------------------
                                   1946 	.area CSEG    (CODE)
                                   1947 	.area CONST   (CODE)
                                   1948 	.area XINIT   (CODE)
      00C4FC                       1949 __xinit__disable_action_cache:
      00C4FC 00                    1950 	.db #0x00	;  0
                                   1951 	.area CABS    (ABS,CODE)
                                   1952 
                                   1953 ; Experimental exact instruction outlining.
                                   1954 	.globl _ak820_outline_0004
                                   1955 	.globl _ak820_outline_0009
                                   1956 	.globl _ak820_outline_0010
                                   1957 	.globl _ak820_outline_0011
                                   1958 	.globl _ak820_outline_0013
                                   1959 	.globl _ak820_outline_0016
                                   1960 	.globl _ak820_outline_0017
                                   1961 	.globl _ak820_outline_0021
                                   1962 	.globl _ak820_outline_0039
                                   1963 	.globl _ak820_outline_0050
                                   1964 	.globl _ak820_outline_0051
                                   1965 	.globl _ak820_outline_0055
                                   1966 	.globl _ak820_outline_0058
                                   1967 	.globl _ak820_outline_0064
                                   1968 	.globl _ak820_outline_0072
                                   1969 	.globl _ak820_outline_0078
                                   1970 	.globl _ak820_outline_0086
                                   1971 	.globl _ak820_outline_0089
                                   1972 	.globl _ak820_outline_0096
                                   1973 	.globl _ak820_outline_0106
                                   1974 	.globl _ak820_outline_0107
                                   1975 	.globl _ak820_outline_0114
                                   1976 	.globl _ak820_outline_0115
                                   1977 	.globl _ak820_outline_0116
                                   1978 	.globl _ak820_outline_0121
                                   1979 	.globl _ak820_outline_0125
                                   1980 	.globl _ak820_outline_0126
                                   1981 	.globl _ak820_outline_0133
                                   1982 	.globl _ak820_outline_0140
                                   1983 	.globl _ak820_outline_0147
                                   1984 	.globl _ak820_outline_0148
                                   1985 	.globl _ak820_outline_0149
                                   1986 	.globl _ak820_outline_0162
                                   1987 	.globl _ak820_outline_0165
                                   1988 	.globl _ak820_outline_0171
                                   1989 	.globl _ak820_outline_0172
                                   1990 	.globl _ak820_outline_0173
                                   1991 	.globl _ak820_outline_0186
                                   1992 	.globl _ak820_outline_0192
                                   1993 
                                   1994 	.area CSEG (CODE)
                                   1995 ; function ak820_outline_0021
      007A84                       1996 _ak820_outline_0021:
      007A84 8E 82            [24] 1997 	mov	dpl,r6
      007A86 8F 83            [24] 1998 	mov	dph,r7
      007A88 A3               [24] 1999 	inc	dptr
      007A89 E0               [24] 2000 	movx	a,@dptr
      007A8A FC               [12] 2001 	mov	r4,a
      007A8B 7D 00            [12] 2002 	mov	r5,#0x00
      007A8D 8E 82            [24] 2003 	mov	dpl,r6
      007A8F 8F 83            [24] 2004 	mov	dph,r7
      007A91 E0               [24] 2005 	movx	a,@dptr
      007A92 22               [24] 2006 	ret
                                   2007 
                                   2008 	.area CSEG (CODE)
                                   2009 ; function ak820_outline_0039
      007A93                       2010 _ak820_outline_0039:
      007A93 90 08 76         [24] 2011 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007A96 E0               [24] 2012 	movx	a,@dptr
      007A97 54 1F            [12] 2013 	anl	a,#0x1f
      007A99 F5 82            [12] 2014 	mov	dpl,a
      007A9B 22               [24] 2015 	ret
                                   2016 
                                   2017 	.area CSEG (CODE)
                                   2018 ; function ak820_outline_0050
      007A9C                       2019 _ak820_outline_0050:
      007A9C A3               [24] 2020 	inc	dptr
      007A9D F0               [24] 2021 	movx	@dptr,a
      007A9E E4               [12] 2022 	clr	a
      007A9F A3               [24] 2023 	inc	dptr
      007AA0 F0               [24] 2024 	movx	@dptr,a
      007AA1 90 0D C0         [24] 2025 	mov	dptr,#___memcpy_PARM_3
      007AA4 22               [24] 2026 	ret
                                   2027 
                                   2028 	.area CSEG (CODE)
                                   2029 ; function ak820_outline_0064
      007AA5                       2030 _ak820_outline_0064:
      007AA5 F5 F0            [12] 2031 	mov	b,a
      007AA7 05 F0            [12] 2032 	inc	b
      007AA9 74 01            [12] 2033 	mov	a,#0x01
      007AAB 22               [24] 2034 	ret
                                   2035 
                                   2036 	.area CSEG (CODE)
                                   2037 ; function ak820_outline_0078
      007AAC                       2038 _ak820_outline_0078:
      007AAC 90 08 75         [24] 2039 	mov	dptr,#_process_action_PARM_2
      007AAF E0               [24] 2040 	movx	a,@dptr
      007AB0 F5 82            [12] 2041 	mov	dpl,a
      007AB2 22               [24] 2042 	ret
                                   2043 
                                   2044 	.area CSEG (CODE)
                                   2045 ; function ak820_outline_0089
      007AB3                       2046 _ak820_outline_0089:
      007AB3 90 08 76         [24] 2047 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007AB6 E0               [24] 2048 	movx	a,@dptr
      007AB7 03               [12] 2049 	rr	a
      007AB8 03               [12] 2050 	rr	a
      007AB9 54 03            [12] 2051 	anl	a,#0x03
      007ABB 22               [24] 2052 	ret
                                   2053 
                                   2054 	.area CSEG (CODE)
                                   2055 ; function ak820_outline_0115
      007ABC                       2056 _ak820_outline_0115:
      007ABC 74 06            [12] 2057 	mov	a,#0x06
      007ABE F0               [24] 2058 	movx	@dptr,a
      007ABF E4               [12] 2059 	clr	a
      007AC0 A3               [24] 2060 	inc	dptr
      007AC1 F0               [24] 2061 	movx	@dptr,a
      007AC2 22               [24] 2062 	ret
                                   2063 
                                   2064 	.area CSEG (CODE)
                                   2065 ; function ak820_outline_0116
      007AC3                       2066 _ak820_outline_0116:
      007AC3 90 08 76         [24] 2067 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007AC6 E0               [24] 2068 	movx	a,@dptr
      007AC7 54 0F            [12] 2069 	anl	a,#0x0f
      007AC9 22               [24] 2070 	ret
                                   2071 
                                   2072 	.area CSEG (CODE)
                                   2073 ; function ak820_outline_0133
      007ACA                       2074 _ak820_outline_0133:
      007ACA 90 08 75         [24] 2075 	mov	dptr,#_process_action_PARM_2
      007ACD E0               [24] 2076 	movx	a,@dptr
      007ACE FE               [12] 2077 	mov	r6,a
      007ACF A3               [24] 2078 	inc	dptr
      007AD0 E0               [24] 2079 	movx	a,@dptr
      007AD1 54 03            [12] 2080 	anl	a,#0x03
      007AD3 FF               [12] 2081 	mov	r7,a
      007AD4 22               [24] 2082 	ret
                                   2083 
                                   2084 	.area CSEG (CODE)
                                   2085 ; function ak820_outline_0162
      007AD5                       2086 _ak820_outline_0162:
      007AD5 90 08 75         [24] 2087 	mov	dptr,#_process_action_PARM_2
      007AD8 E0               [24] 2088 	movx	a,@dptr
      007AD9 22               [24] 2089 	ret
                                   2090 
                                   2091 	.area CSEG (CODE)
                                   2092 ; function ak820_outline_0171
      007ADA                       2093 _ak820_outline_0171:
      007ADA 90 08 7A         [24] 2094 	mov	dptr,#_register_code_code_10000_733
      007ADD E0               [24] 2095 	movx	a,@dptr
      007ADE FF               [12] 2096 	mov	r7,a
      007ADF 22               [24] 2097 	ret
                                   2098 
                                   2099 	.area CSEG (CODE)
                                   2100 ; function ak820_outline_0172
      007AE0                       2101 _ak820_outline_0172:
      007AE0 90 08 7B         [24] 2102 	mov	dptr,#_unregister_code_code_10000_747
      007AE3 E0               [24] 2103 	movx	a,@dptr
      007AE4 FF               [12] 2104 	mov	r7,a
      007AE5 22               [24] 2105 	ret
