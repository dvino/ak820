                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module vialrgb
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _rgb_matrix_get_speed
                                     12 	.globl _rgb_matrix_set_speed_noeeprom
                                     13 	.globl _rgb_matrix_get_val
                                     14 	.globl _rgb_matrix_get_sat
                                     15 	.globl _rgb_matrix_get_hue
                                     16 	.globl _rgb_matrix_sethsv_noeeprom
                                     17 	.globl _rgb_matrix_get_mode
                                     18 	.globl _rgb_matrix_mode_noeeprom
                                     19 	.globl _rgb_matrix_is_enabled
                                     20 	.globl _rgb_matrix_disable_noeeprom
                                     21 	.globl _rgb_matrix_enable_noeeprom
                                     22 	.globl _eeconfig_update_rgb_matrix
                                     23 	.globl _ADC_START
                                     24 	.globl _S0_R_FIFO
                                     25 	.globl _S0_T_FIFO
                                     26 	.globl _S0_FREE
                                     27 	.globl _S0_IF_BYTE
                                     28 	.globl _S0_IF_FIRST
                                     29 	.globl _S0_IF_OV
                                     30 	.globl _S0_FST_ACT
                                     31 	.globl _CP_RL2
                                     32 	.globl _C_T2
                                     33 	.globl _TR2
                                     34 	.globl _EXEN2
                                     35 	.globl _TCLK
                                     36 	.globl _RCLK
                                     37 	.globl _EXF2
                                     38 	.globl _CAP1F
                                     39 	.globl _TF2
                                     40 	.globl _RI
                                     41 	.globl _TI
                                     42 	.globl _RB8
                                     43 	.globl _TB8
                                     44 	.globl _REN
                                     45 	.globl _SM2
                                     46 	.globl _SM1
                                     47 	.globl _SM0
                                     48 	.globl _IT0
                                     49 	.globl _IE0
                                     50 	.globl _IT1
                                     51 	.globl _IE1
                                     52 	.globl _TR0
                                     53 	.globl _TF0
                                     54 	.globl _TR1
                                     55 	.globl _TF1
                                     56 	.globl _P4_0
                                     57 	.globl _P4_1
                                     58 	.globl _P4_2
                                     59 	.globl _P4_3
                                     60 	.globl _P4_4
                                     61 	.globl _P4_5
                                     62 	.globl _P4_6
                                     63 	.globl _RXD
                                     64 	.globl _TXD
                                     65 	.globl _INT0
                                     66 	.globl _INT1
                                     67 	.globl _T0
                                     68 	.globl _T1
                                     69 	.globl _MOSI1
                                     70 	.globl _MISO1
                                     71 	.globl _SCK1
                                     72 	.globl _P3_0
                                     73 	.globl _P3_1
                                     74 	.globl _P3_2
                                     75 	.globl _P3_3
                                     76 	.globl _P3_4
                                     77 	.globl _P3_5
                                     78 	.globl _P3_6
                                     79 	.globl _P3_7
                                     80 	.globl _CAP1_
                                     81 	.globl _T2_
                                     82 	.globl _CAP2_
                                     83 	.globl _T2EX_
                                     84 	.globl _RXD1
                                     85 	.globl _TXD1
                                     86 	.globl _P2_0
                                     87 	.globl _P2_1
                                     88 	.globl _P2_2
                                     89 	.globl _P2_3
                                     90 	.globl _P2_4
                                     91 	.globl _P2_5
                                     92 	.globl _P2_6
                                     93 	.globl _P2_7
                                     94 	.globl _AIN0
                                     95 	.globl _AIN1
                                     96 	.globl _AIN2
                                     97 	.globl _AIN3
                                     98 	.globl _AIN4
                                     99 	.globl _AIN5
                                    100 	.globl _AIN6
                                    101 	.globl _AIN7
                                    102 	.globl _CAP1
                                    103 	.globl _T2
                                    104 	.globl _CAP2
                                    105 	.globl _T2EX
                                    106 	.globl _INT0_
                                    107 	.globl _SCS
                                    108 	.globl _MOSI
                                    109 	.globl _MISO
                                    110 	.globl _SCK
                                    111 	.globl _RXD1_
                                    112 	.globl _TXD1_
                                    113 	.globl _P1_0
                                    114 	.globl _P1_1
                                    115 	.globl _P1_2
                                    116 	.globl _P1_3
                                    117 	.globl _P1_4
                                    118 	.globl _P1_5
                                    119 	.globl _P1_6
                                    120 	.globl _P1_7
                                    121 	.globl _AIN8
                                    122 	.globl _AIN9
                                    123 	.globl _AIN10
                                    124 	.globl _AIN11
                                    125 	.globl _AIN12
                                    126 	.globl _AIN13
                                    127 	.globl _RXD_
                                    128 	.globl _TXD_
                                    129 	.globl _SCL0
                                    130 	.globl _SDA0
                                    131 	.globl _P0_0
                                    132 	.globl _P0_1
                                    133 	.globl _P0_2
                                    134 	.globl _P0_3
                                    135 	.globl _P0_4
                                    136 	.globl _P0_5
                                    137 	.globl _P0_6
                                    138 	.globl _P0_7
                                    139 	.globl _IE_SPI0
                                    140 	.globl _IE_USB
                                    141 	.globl _IE_ADC
                                    142 	.globl _IE_UART1
                                    143 	.globl _IE_PWM_I2C
                                    144 	.globl _IE_GPIO
                                    145 	.globl _IE_WDOG
                                    146 	.globl _PX0
                                    147 	.globl _PT0
                                    148 	.globl _PX1
                                    149 	.globl _PT1
                                    150 	.globl _PS
                                    151 	.globl _PT2
                                    152 	.globl _PL_FLAG
                                    153 	.globl _PH_FLAG
                                    154 	.globl _EX0
                                    155 	.globl _ET0
                                    156 	.globl _EX1
                                    157 	.globl _ET1
                                    158 	.globl _ES
                                    159 	.globl _ET2
                                    160 	.globl _E_DIS
                                    161 	.globl _EA
                                    162 	.globl _P
                                    163 	.globl _F1
                                    164 	.globl _OV
                                    165 	.globl _RS0
                                    166 	.globl _RS1
                                    167 	.globl _F0
                                    168 	.globl _AC
                                    169 	.globl _CY
                                    170 	.globl _I2CS_INT_ST
                                    171 	.globl _I2CX_INT
                                    172 	.globl _LED_STATUS
                                    173 	.globl _LED_DMA_H
                                    174 	.globl _LED_DMA_L
                                    175 	.globl _LED_DMA
                                    176 	.globl _LED_PWM_OE
                                    177 	.globl _LED_COMMON
                                    178 	.globl _ADC_CHAN
                                    179 	.globl _ADC_DAT_H
                                    180 	.globl _ADC_DAT_L
                                    181 	.globl _ADC_DAT
                                    182 	.globl _ADC_CTRL
                                    183 	.globl _SPI1_CK_SE
                                    184 	.globl _SPI1_CTRL
                                    185 	.globl _SPI1_DATA
                                    186 	.globl _SPI1_STAT
                                    187 	.globl _SIF1
                                    188 	.globl _SBAUD1
                                    189 	.globl _SBUF1
                                    190 	.globl _SCON1
                                    191 	.globl _SPI0_SETUP
                                    192 	.globl _SPI0_CK_SE
                                    193 	.globl _SPI0_CTRL
                                    194 	.globl _SPI0_DATA
                                    195 	.globl _SPI0_STAT
                                    196 	.globl _T2CAP1H
                                    197 	.globl _T2CAP1L
                                    198 	.globl _T2CAP1
                                    199 	.globl _TH2
                                    200 	.globl _TL2
                                    201 	.globl _T2COUNT
                                    202 	.globl _RCAP2H
                                    203 	.globl _RCAP2L
                                    204 	.globl _RCAP2
                                    205 	.globl _T2MOD
                                    206 	.globl _T2CON
                                    207 	.globl _SBUF
                                    208 	.globl _SCON
                                    209 	.globl _TH1
                                    210 	.globl _TH0
                                    211 	.globl _TL1
                                    212 	.globl _TL0
                                    213 	.globl _TMOD
                                    214 	.globl _TCON
                                    215 	.globl _XBUS_AUX
                                    216 	.globl _P7
                                    217 	.globl _P6_DIR
                                    218 	.globl _P6_OUT_PU
                                    219 	.globl _P6_IN
                                    220 	.globl _P5_DIR
                                    221 	.globl _P5_OUT_PU
                                    222 	.globl _P5_IN
                                    223 	.globl _P4_LED_KEY
                                    224 	.globl _P4_DIR_PU
                                    225 	.globl _P4_MOD_OC
                                    226 	.globl _P4
                                    227 	.globl _P3_DIR_PU
                                    228 	.globl _P3_MOD_OC
                                    229 	.globl _P3
                                    230 	.globl _P2_DIR_PU
                                    231 	.globl _P2_MOD_OC
                                    232 	.globl _P2
                                    233 	.globl _P1_DIR_PU
                                    234 	.globl _P1_MOD_OC
                                    235 	.globl _P1
                                    236 	.globl _P0_DIR_PU
                                    237 	.globl _P0_MOD_OC
                                    238 	.globl _P0
                                    239 	.globl _ROM_CTRL
                                    240 	.globl _ROM_DATA_HH
                                    241 	.globl _ROM_DATA_HL
                                    242 	.globl _ROM_DATA_HI
                                    243 	.globl _ROM_ADDR_H
                                    244 	.globl _ROM_ADDR_L
                                    245 	.globl _ROM_ADDR
                                    246 	.globl _GPIO_IE
                                    247 	.globl _IP_EX
                                    248 	.globl _IE_EX
                                    249 	.globl _IP
                                    250 	.globl _IE
                                    251 	.globl _WDOG_COUNT
                                    252 	.globl _RESET_KEEP
                                    253 	.globl _WAKE_CTRL
                                    254 	.globl _CLOCK_CFG
                                    255 	.globl _POWER_CFG
                                    256 	.globl _PCON
                                    257 	.globl _GLOBAL_CFG
                                    258 	.globl _SAFE_MOD
                                    259 	.globl _DPH
                                    260 	.globl _DPL
                                    261 	.globl _SP
                                    262 	.globl _A_INV
                                    263 	.globl _B
                                    264 	.globl _ACC
                                    265 	.globl _PSW
                                    266 	.globl _vialrgb_save_PARM_2
                                    267 	.globl _vialrgb_set_value_PARM_2
                                    268 	.globl _vialrgb_get_value_PARM_2
                                    269 	.globl _g_direct_mode_colors
                                    270 	.globl _vialrgb_get_value
                                    271 	.globl _vialrgb_set_value
                                    272 	.globl _vialrgb_save
                                    273 ;--------------------------------------------------------
                                    274 ; special function registers
                                    275 ;--------------------------------------------------------
                                    276 	.area RSEG    (ABS,DATA)
      000000                        277 	.org 0x0000
                           0000D0   278 _PSW	=	0x00d0
                           0000E0   279 _ACC	=	0x00e0
                           0000F0   280 _B	=	0x00f0
                           0000FD   281 _A_INV	=	0x00fd
                           000081   282 _SP	=	0x0081
                           000082   283 _DPL	=	0x0082
                           000083   284 _DPH	=	0x0083
                           0000A1   285 _SAFE_MOD	=	0x00a1
                           0000B1   286 _GLOBAL_CFG	=	0x00b1
                           000087   287 _PCON	=	0x0087
                           0000BA   288 _POWER_CFG	=	0x00ba
                           0000B9   289 _CLOCK_CFG	=	0x00b9
                           0000A9   290 _WAKE_CTRL	=	0x00a9
                           0000FE   291 _RESET_KEEP	=	0x00fe
                           0000FF   292 _WDOG_COUNT	=	0x00ff
                           0000A8   293 _IE	=	0x00a8
                           0000B8   294 _IP	=	0x00b8
                           0000E8   295 _IE_EX	=	0x00e8
                           0000E9   296 _IP_EX	=	0x00e9
                           0000B2   297 _GPIO_IE	=	0x00b2
                           008584   298 _ROM_ADDR	=	0x8584
                           000084   299 _ROM_ADDR_L	=	0x0084
                           000085   300 _ROM_ADDR_H	=	0x0085
                           008F8E   301 _ROM_DATA_HI	=	0x8f8e
                           00008E   302 _ROM_DATA_HL	=	0x008e
                           00008F   303 _ROM_DATA_HH	=	0x008f
                           000086   304 _ROM_CTRL	=	0x0086
                           000080   305 _P0	=	0x0080
                           0000C4   306 _P0_MOD_OC	=	0x00c4
                           0000C5   307 _P0_DIR_PU	=	0x00c5
                           000090   308 _P1	=	0x0090
                           000092   309 _P1_MOD_OC	=	0x0092
                           000093   310 _P1_DIR_PU	=	0x0093
                           0000A0   311 _P2	=	0x00a0
                           000094   312 _P2_MOD_OC	=	0x0094
                           000095   313 _P2_DIR_PU	=	0x0095
                           0000B0   314 _P3	=	0x00b0
                           000096   315 _P3_MOD_OC	=	0x0096
                           000097   316 _P3_DIR_PU	=	0x0097
                           0000C0   317 _P4	=	0x00c0
                           0000C2   318 _P4_MOD_OC	=	0x00c2
                           0000C3   319 _P4_DIR_PU	=	0x00c3
                           0000C1   320 _P4_LED_KEY	=	0x00c1
                           0000AA   321 _P5_IN	=	0x00aa
                           0000AB   322 _P5_OUT_PU	=	0x00ab
                           0000AC   323 _P5_DIR	=	0x00ac
                           0000AD   324 _P6_IN	=	0x00ad
                           0000AE   325 _P6_OUT_PU	=	0x00ae
                           0000AF   326 _P6_DIR	=	0x00af
                           0000F1   327 _P7	=	0x00f1
                           0000A2   328 _XBUS_AUX	=	0x00a2
                           000088   329 _TCON	=	0x0088
                           000089   330 _TMOD	=	0x0089
                           00008A   331 _TL0	=	0x008a
                           00008B   332 _TL1	=	0x008b
                           00008C   333 _TH0	=	0x008c
                           00008D   334 _TH1	=	0x008d
                           000098   335 _SCON	=	0x0098
                           000099   336 _SBUF	=	0x0099
                           0000C8   337 _T2CON	=	0x00c8
                           0000C9   338 _T2MOD	=	0x00c9
                           00CBCA   339 _RCAP2	=	0xcbca
                           0000CA   340 _RCAP2L	=	0x00ca
                           0000CB   341 _RCAP2H	=	0x00cb
                           00CDCC   342 _T2COUNT	=	0xcdcc
                           0000CC   343 _TL2	=	0x00cc
                           0000CD   344 _TH2	=	0x00cd
                           00CFCE   345 _T2CAP1	=	0xcfce
                           0000CE   346 _T2CAP1L	=	0x00ce
                           0000CF   347 _T2CAP1H	=	0x00cf
                           0000F8   348 _SPI0_STAT	=	0x00f8
                           0000F9   349 _SPI0_DATA	=	0x00f9
                           0000FA   350 _SPI0_CTRL	=	0x00fa
                           0000FB   351 _SPI0_CK_SE	=	0x00fb
                           0000FC   352 _SPI0_SETUP	=	0x00fc
                           0000BC   353 _SCON1	=	0x00bc
                           0000BD   354 _SBUF1	=	0x00bd
                           0000BE   355 _SBAUD1	=	0x00be
                           0000BF   356 _SIF1	=	0x00bf
                           0000B4   357 _SPI1_STAT	=	0x00b4
                           0000B5   358 _SPI1_DATA	=	0x00b5
                           0000B6   359 _SPI1_CTRL	=	0x00b6
                           0000B7   360 _SPI1_CK_SE	=	0x00b7
                           0000F3   361 _ADC_CTRL	=	0x00f3
                           00F5F4   362 _ADC_DAT	=	0xf5f4
                           0000F4   363 _ADC_DAT_L	=	0x00f4
                           0000F5   364 _ADC_DAT_H	=	0x00f5
                           0000F6   365 _ADC_CHAN	=	0x00f6
                           0000A6   366 _LED_COMMON	=	0x00a6
                           0000A7   367 _LED_PWM_OE	=	0x00a7
                           00C7C6   368 _LED_DMA	=	0xc7c6
                           0000C6   369 _LED_DMA_L	=	0x00c6
                           0000C7   370 _LED_DMA_H	=	0x00c7
                           0000F7   371 _LED_STATUS	=	0x00f7
                           0000B3   372 _I2CX_INT	=	0x00b3
                           0000BB   373 _I2CS_INT_ST	=	0x00bb
                                    374 ;--------------------------------------------------------
                                    375 ; special function bits
                                    376 ;--------------------------------------------------------
                                    377 	.area RSEG    (ABS,DATA)
      000000                        378 	.org 0x0000
                           0000D7   379 _CY	=	0x00d7
                           0000D6   380 _AC	=	0x00d6
                           0000D5   381 _F0	=	0x00d5
                           0000D4   382 _RS1	=	0x00d4
                           0000D3   383 _RS0	=	0x00d3
                           0000D2   384 _OV	=	0x00d2
                           0000D1   385 _F1	=	0x00d1
                           0000D0   386 _P	=	0x00d0
                           0000AF   387 _EA	=	0x00af
                           0000AE   388 _E_DIS	=	0x00ae
                           0000AD   389 _ET2	=	0x00ad
                           0000AC   390 _ES	=	0x00ac
                           0000AB   391 _ET1	=	0x00ab
                           0000AA   392 _EX1	=	0x00aa
                           0000A9   393 _ET0	=	0x00a9
                           0000A8   394 _EX0	=	0x00a8
                           0000BF   395 _PH_FLAG	=	0x00bf
                           0000BE   396 _PL_FLAG	=	0x00be
                           0000BD   397 _PT2	=	0x00bd
                           0000BC   398 _PS	=	0x00bc
                           0000BB   399 _PT1	=	0x00bb
                           0000BA   400 _PX1	=	0x00ba
                           0000B9   401 _PT0	=	0x00b9
                           0000B8   402 _PX0	=	0x00b8
                           0000EF   403 _IE_WDOG	=	0x00ef
                           0000EE   404 _IE_GPIO	=	0x00ee
                           0000ED   405 _IE_PWM_I2C	=	0x00ed
                           0000EC   406 _IE_UART1	=	0x00ec
                           0000EB   407 _IE_ADC	=	0x00eb
                           0000E9   408 _IE_USB	=	0x00e9
                           0000E8   409 _IE_SPI0	=	0x00e8
                           000087   410 _P0_7	=	0x0087
                           000086   411 _P0_6	=	0x0086
                           000085   412 _P0_5	=	0x0085
                           000084   413 _P0_4	=	0x0084
                           000083   414 _P0_3	=	0x0083
                           000082   415 _P0_2	=	0x0082
                           000081   416 _P0_1	=	0x0081
                           000080   417 _P0_0	=	0x0080
                           000081   418 _SDA0	=	0x0081
                           000080   419 _SCL0	=	0x0080
                           000083   420 _TXD_	=	0x0083
                           000082   421 _RXD_	=	0x0082
                           000085   422 _AIN13	=	0x0085
                           000084   423 _AIN12	=	0x0084
                           000083   424 _AIN11	=	0x0083
                           000082   425 _AIN10	=	0x0082
                           000081   426 _AIN9	=	0x0081
                           000080   427 _AIN8	=	0x0080
                           000097   428 _P1_7	=	0x0097
                           000096   429 _P1_6	=	0x0096
                           000095   430 _P1_5	=	0x0095
                           000094   431 _P1_4	=	0x0094
                           000093   432 _P1_3	=	0x0093
                           000092   433 _P1_2	=	0x0092
                           000091   434 _P1_1	=	0x0091
                           000090   435 _P1_0	=	0x0090
                           000097   436 _TXD1_	=	0x0097
                           000096   437 _RXD1_	=	0x0096
                           000097   438 _SCK	=	0x0097
                           000096   439 _MISO	=	0x0096
                           000095   440 _MOSI	=	0x0095
                           000094   441 _SCS	=	0x0094
                           000092   442 _INT0_	=	0x0092
                           000091   443 _T2EX	=	0x0091
                           000091   444 _CAP2	=	0x0091
                           000090   445 _T2	=	0x0090
                           000090   446 _CAP1	=	0x0090
                           000097   447 _AIN7	=	0x0097
                           000096   448 _AIN6	=	0x0096
                           000095   449 _AIN5	=	0x0095
                           000094   450 _AIN4	=	0x0094
                           000093   451 _AIN3	=	0x0093
                           000092   452 _AIN2	=	0x0092
                           000091   453 _AIN1	=	0x0091
                           000090   454 _AIN0	=	0x0090
                           0000A7   455 _P2_7	=	0x00a7
                           0000A6   456 _P2_6	=	0x00a6
                           0000A5   457 _P2_5	=	0x00a5
                           0000A4   458 _P2_4	=	0x00a4
                           0000A3   459 _P2_3	=	0x00a3
                           0000A2   460 _P2_2	=	0x00a2
                           0000A1   461 _P2_1	=	0x00a1
                           0000A0   462 _P2_0	=	0x00a0
                           0000A7   463 _TXD1	=	0x00a7
                           0000A6   464 _RXD1	=	0x00a6
                           0000A5   465 _T2EX_	=	0x00a5
                           0000A5   466 _CAP2_	=	0x00a5
                           0000A4   467 _T2_	=	0x00a4
                           0000A4   468 _CAP1_	=	0x00a4
                           0000B7   469 _P3_7	=	0x00b7
                           0000B6   470 _P3_6	=	0x00b6
                           0000B5   471 _P3_5	=	0x00b5
                           0000B4   472 _P3_4	=	0x00b4
                           0000B3   473 _P3_3	=	0x00b3
                           0000B2   474 _P3_2	=	0x00b2
                           0000B1   475 _P3_1	=	0x00b1
                           0000B0   476 _P3_0	=	0x00b0
                           0000B7   477 _SCK1	=	0x00b7
                           0000B6   478 _MISO1	=	0x00b6
                           0000B5   479 _MOSI1	=	0x00b5
                           0000B5   480 _T1	=	0x00b5
                           0000B4   481 _T0	=	0x00b4
                           0000B3   482 _INT1	=	0x00b3
                           0000B2   483 _INT0	=	0x00b2
                           0000B1   484 _TXD	=	0x00b1
                           0000B0   485 _RXD	=	0x00b0
                           0000C6   486 _P4_6	=	0x00c6
                           0000C5   487 _P4_5	=	0x00c5
                           0000C4   488 _P4_4	=	0x00c4
                           0000C3   489 _P4_3	=	0x00c3
                           0000C2   490 _P4_2	=	0x00c2
                           0000C1   491 _P4_1	=	0x00c1
                           0000C0   492 _P4_0	=	0x00c0
                           00008F   493 _TF1	=	0x008f
                           00008E   494 _TR1	=	0x008e
                           00008D   495 _TF0	=	0x008d
                           00008C   496 _TR0	=	0x008c
                           00008B   497 _IE1	=	0x008b
                           00008A   498 _IT1	=	0x008a
                           000089   499 _IE0	=	0x0089
                           000088   500 _IT0	=	0x0088
                           00009F   501 _SM0	=	0x009f
                           00009E   502 _SM1	=	0x009e
                           00009D   503 _SM2	=	0x009d
                           00009C   504 _REN	=	0x009c
                           00009B   505 _TB8	=	0x009b
                           00009A   506 _RB8	=	0x009a
                           000099   507 _TI	=	0x0099
                           000098   508 _RI	=	0x0098
                           0000CF   509 _TF2	=	0x00cf
                           0000CF   510 _CAP1F	=	0x00cf
                           0000CE   511 _EXF2	=	0x00ce
                           0000CD   512 _RCLK	=	0x00cd
                           0000CC   513 _TCLK	=	0x00cc
                           0000CB   514 _EXEN2	=	0x00cb
                           0000CA   515 _TR2	=	0x00ca
                           0000C9   516 _C_T2	=	0x00c9
                           0000C8   517 _CP_RL2	=	0x00c8
                           0000FF   518 _S0_FST_ACT	=	0x00ff
                           0000FE   519 _S0_IF_OV	=	0x00fe
                           0000FD   520 _S0_IF_FIRST	=	0x00fd
                           0000FC   521 _S0_IF_BYTE	=	0x00fc
                           0000FB   522 _S0_FREE	=	0x00fb
                           0000FA   523 _S0_T_FIFO	=	0x00fa
                           0000F8   524 _S0_R_FIFO	=	0x00f8
                           0000F7   525 _ADC_START	=	0x00f7
                                    526 ;--------------------------------------------------------
                                    527 ; overlayable register banks
                                    528 ;--------------------------------------------------------
                                    529 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        530 	.ds 8
                                    531 ;--------------------------------------------------------
                                    532 ; internal ram data
                                    533 ;--------------------------------------------------------
                                    534 	.area DSEG    (DATA)
      00004A                        535 _fast_set_leds_sloc0_1_0:
      00004A                        536 	.ds 2
      00004C                        537 _fast_set_leds_sloc1_1_0:
      00004C                        538 	.ds 2
      00004E                        539 _vialrgb_get_value_sloc0_1_0:
      00004E                        540 	.ds 2
      000050                        541 _vialrgb_get_value_sloc1_1_0:
      000050                        542 	.ds 2
      000052                        543 _vialrgb_set_value_sloc0_1_0:
      000052                        544 	.ds 2
                                    545 ;--------------------------------------------------------
                                    546 ; overlayable items in internal ram
                                    547 ;--------------------------------------------------------
                                    548 ;--------------------------------------------------------
                                    549 ; indirectly addressable internal ram data
                                    550 ;--------------------------------------------------------
                                    551 	.area ISEG    (DATA)
                                    552 ;--------------------------------------------------------
                                    553 ; absolute internal ram data
                                    554 ;--------------------------------------------------------
                                    555 	.area IABS    (ABS,DATA)
                                    556 	.area IABS    (ABS,DATA)
                                    557 ;--------------------------------------------------------
                                    558 ; bit data
                                    559 ;--------------------------------------------------------
                                    560 	.area BSEG    (BIT)
                                    561 ;--------------------------------------------------------
                                    562 ; paged external ram data
                                    563 ;--------------------------------------------------------
                                    564 	.area PSEG    (PAG,XDATA)
                                    565 ;--------------------------------------------------------
                                    566 ; uninitialized external ram data
                                    567 ;--------------------------------------------------------
                                    568 	.area XSEG    (XDATA)
      000CA9                        569 _g_direct_mode_colors::
      000CA9                        570 	.ds 246
      000D9F                        571 _get_supported_PARM_2:
      000D9F                        572 	.ds 1
      000DA0                        573 _get_supported_args_10000_255:
      000DA0                        574 	.ds 2
      000DA2                        575 _qmk_id_to_vialrgb_id_id_10000_262:
      000DA2                        576 	.ds 2
      000DA4                        577 _vialrgb_id_to_qmk_id_id_10000_267:
      000DA4                        578 	.ds 2
      000DA6                        579 _set_mode_mode_10000_275:
      000DA6                        580 	.ds 2
      000DA8                        581 _get_matrix_pos_for_led_PARM_2:
      000DA8                        582 	.ds 2
      000DAA                        583 _get_matrix_pos_for_led_led_10000_280:
      000DAA                        584 	.ds 2
      000DAC                        585 _fast_set_leds_PARM_2:
      000DAC                        586 	.ds 1
      000DAD                        587 _fast_set_leds_args_10000_282:
      000DAD                        588 	.ds 2
      000DAF                        589 _fast_set_leds_first_index_10001_285:
      000DAF                        590 	.ds 2
      000DB1                        591 _fast_set_leds_num_leds_10001_285:
      000DB1                        592 	.ds 1
      000DB2                        593 _vialrgb_get_value_PARM_2:
      000DB2                        594 	.ds 1
      000DB3                        595 _vialrgb_get_value_data_10000_291:
      000DB3                        596 	.ds 3
      000DB6                        597 _vialrgb_set_value_PARM_2:
      000DB6                        598 	.ds 1
      000DB7                        599 _vialrgb_set_value_data_10000_302:
      000DB7                        600 	.ds 3
      000DBA                        601 _vialrgb_save_PARM_2:
      000DBA                        602 	.ds 1
                                    603 ;--------------------------------------------------------
                                    604 ; absolute external ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area XABS    (ABS,XDATA)
                                    607 ;--------------------------------------------------------
                                    608 ; initialized external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area XISEG   (XDATA)
                                    611 	.area HOME    (CODE)
                                    612 	.area GSINIT0 (CODE)
                                    613 	.area GSINIT1 (CODE)
                                    614 	.area GSINIT2 (CODE)
                                    615 	.area GSINIT3 (CODE)
                                    616 	.area GSINIT4 (CODE)
                                    617 	.area GSINIT5 (CODE)
                                    618 	.area GSINIT  (CODE)
                                    619 	.area GSFINAL (CODE)
                                    620 	.area CSEG    (CODE)
                                    621 ;--------------------------------------------------------
                                    622 ; global & static initialisations
                                    623 ;--------------------------------------------------------
                                    624 	.area HOME    (CODE)
                                    625 	.area GSINIT  (CODE)
                                    626 	.area GSFINAL (CODE)
                                    627 	.area GSINIT  (CODE)
                                    628 ;--------------------------------------------------------
                                    629 ; Home
                                    630 ;--------------------------------------------------------
                                    631 	.area HOME    (CODE)
                                    632 	.area HOME    (CODE)
                                    633 ;--------------------------------------------------------
                                    634 ; code
                                    635 ;--------------------------------------------------------
                                    636 	.area CSEG    (CODE)
                                    637 ;------------------------------------------------------------
                                    638 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    639 ;------------------------------------------------------------
                                    640 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_167'
                                    641 ;------------------------------------------------------------
                                    642 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    643 ;	-----------------------------------------
                           000007   644 	ar7 = 0x07
                           000006   645 	ar6 = 0x06
                           000005   646 	ar5 = 0x05
                           000004   647 	ar4 = 0x04
                           000003   648 	ar3 = 0x03
                           000002   649 	ar2 = 0x02
                           000001   650 	ar1 = 0x01
                           000000   651 	ar0 = 0x00
                                    652 ;	 function get_supported
                                    653 ;	-----------------------------------------
      00B582                        654 _get_supported:
      00B582 12 38 52         [24]  655 	lcall	_ak820_outline_0106
      00B585 90 0D A0         [24]  656 	mov	dptr,#_get_supported_args_10000_255
      00B588 12 38 57         [24]  657 	lcall	_ak820_outline_0107
                                    658 ;	quantum/vialrgb.c:44: uint16_t gt = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00B58B 90 0D A0         [24]  659 	mov	dptr,#_get_supported_args_10000_255
      00B58E 12 37 A5         [24]  660 	lcall	_ak820_outline_0004
      00B591 E0               [24]  661 	movx	a,@dptr
      00B592 FD               [12]  662 	mov	r5,a
      00B593 7C 00            [12]  663 	mov	r4,#0x00
      00B595 12 38 27         [24]  664 	lcall	_ak820_outline_0077
      00B598 FA               [12]  665 	mov	r2,a
      00B599 E4               [12]  666 	clr	a
      00B59A 12 43 41         [24]  667 	lcall	_ak820_outline_0147
                                    668 ;	quantum/vialrgb.c:45: for (uint8_t i = 0; i < length; ++i) args[i] = 0xff;
      00B59D 90 0D 9F         [24]  669 	mov	dptr,#_get_supported_PARM_2
      00B5A0 E0               [24]  670 	movx	a,@dptr
      00B5A1 FB               [12]  671 	mov	r3,a
      00B5A2 7A 00            [12]  672 	mov	r2,#0x00
      00B5A4                        673 00107$:
      00B5A4 C3               [12]  674 	clr	c
      00B5A5 EA               [12]  675 	mov	a,r2
      00B5A6 9B               [12]  676 	subb	a,r3
      00B5A7 50 0A            [24]  677 	jnc	00101$
      00B5A9 EA               [12]  678 	mov	a,r2
      00B5AA 12 37 EC         [24]  679 	lcall	_ak820_outline_0017
      00B5AD 74 FF            [12]  680 	mov	a,#0xff
      00B5AF F0               [24]  681 	movx	@dptr,a
      00B5B0 0A               [12]  682 	inc	r2
      00B5B1 80 F1            [24]  683 	sjmp	00107$
      00B5B3                        684 00101$:
                                    685 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B5B3 8D 06            [24]  686 	mov	ar6,r5
      00B5B5 8C 07            [24]  687 	mov	ar7,r4
      00B5B7 8B 05            [24]  688 	mov	ar5,r3
      00B5B9 90 0D A0         [24]  689 	mov	dptr,#_get_supported_args_10000_255
      00B5BC 12 38 4C         [24]  690 	lcall	_ak820_outline_0105
      00B5BF 7A 00            [12]  691 	mov	r2,#0x00
      00B5C1                        692 00110$:
      00B5C1 BA 07 00         [24]  693 	cjne	r2,#0x07,00159$
      00B5C4                        694 00159$:
      00B5C4 50 45            [24]  695 	jnc	00127$
                                    696 ;	quantum/vialrgb.c:47: uint16_t id = READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00B5C6 EA               [12]  697 	mov	a,r2
      00B5C7 75 F0 02         [24]  698 	mov	b,#0x02
      00B5CA A4               [48]  699 	mul	ab
      00B5CB 24 2E            [12]  700 	add	a, #_supported_modes
      00B5CD F5 82            [12]  701 	mov	dpl,a
      00B5CF 74 C3            [12]  702 	mov	a,#(_supported_modes >> 8)
      00B5D1 12 5B 41         [24]  703 	lcall	_ak820_outline_0112
      00B5D4 F8               [12]  704 	mov	r0,a
      00B5D5 79 00            [12]  705 	mov	r1,#0x00
                                    706 ;	quantum/vialrgb.c:48: if (id > gt && length >= sizeof(id)) {
      00B5D7 C3               [12]  707 	clr	c
      00B5D8 EE               [12]  708 	mov	a,r6
      00B5D9 98               [12]  709 	subb	a,r0
      00B5DA EF               [12]  710 	mov	a,r7
      00B5DB 99               [12]  711 	subb	a,r1
      00B5DC 50 2A            [24]  712 	jnc	00111$
                                    713 ;	free result
      00B5DE BD 02 00         [24]  714 	cjne	r5,#0x02,00162$
      00B5E1                        715 00162$:
      00B5E1 40 25            [24]  716 	jc	00111$
                                    717 ;	quantum/vialrgb.c:49: args[0] = id;
      00B5E3 C0 06            [24]  718 	push	ar6
      00B5E5 C0 07            [24]  719 	push	ar7
      00B5E7 88 07            [24]  720 	mov	ar7,r0
      00B5E9 12 33 FC         [24]  721 	lcall	_ak820_outline_0126
      00B5EC EF               [12]  722 	mov	a,r7
      00B5ED 12 A0 B6         [24]  723 	lcall	_ak820_outline_0124
                                    724 ;	quantum/vialrgb.c:50: args[1] = id >> 8;
      00B5F0 A3               [24]  725 	inc	dptr
      00B5F1 89 00            [24]  726 	mov	ar0,r1
      00B5F3 E8               [12]  727 	mov	a,r0
      00B5F4 F0               [24]  728 	movx	@dptr,a
                                    729 ;	quantum/vialrgb.c:51: length -= sizeof(id);
      00B5F5 1D               [12]  730 	dec	r5
      00B5F6 1D               [12]  731 	dec	r5
                                    732 ;	quantum/vialrgb.c:52: args += sizeof(id);
      00B5F7 74 02            [12]  733 	mov	a,#0x02
      00B5F9 2B               [12]  734 	add	a, r3
      00B5FA FB               [12]  735 	mov	r3,a
      00B5FB E4               [12]  736 	clr	a
      00B5FC 3C               [12]  737 	addc	a, r4
      00B5FD FC               [12]  738 	mov	r4,a
      00B5FE 90 0D A0         [24]  739 	mov	dptr,#_get_supported_args_10000_255
      00B601 12 38 34         [24]  740 	lcall	_ak820_outline_0085
                                    741 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B604 D0 07            [24]  742 	pop	ar7
      00B606 D0 06            [24]  743 	pop	ar6
                                    744 ;	quantum/vialrgb.c:52: args += sizeof(id);
      00B608                        745 00111$:
                                    746 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B608 0A               [12]  747 	inc	r2
      00B609 80 B6            [24]  748 	sjmp	00110$
      00B60B                        749 00127$:
      00B60B 90 0D A0         [24]  750 	mov	dptr,#_get_supported_args_10000_255
      00B60E 12 38 34         [24]  751 	lcall	_ak820_outline_0085
                                    752 ;	quantum/vialrgb.c:55: }
      00B611 22               [24]  753 	ret
                                    754 ;------------------------------------------------------------
                                    755 ;Allocation info for local variables in function 'qmk_id_to_vialrgb_id'
                                    756 ;------------------------------------------------------------
                                    757 ;id            Allocated with name '_qmk_id_to_vialrgb_id_id_10000_262'
                                    758 ;i             Allocated with name '_qmk_id_to_vialrgb_id_i_20000_264'
                                    759 ;qmk_id        Allocated with name '_qmk_id_to_vialrgb_id_qmk_id_30000_265'
                                    760 ;------------------------------------------------------------
                                    761 ;	quantum/vialrgb.c:57: static uint16_t qmk_id_to_vialrgb_id(uint16_t id) {
                                    762 ;	-----------------------------------------
                                    763 ;	 function qmk_id_to_vialrgb_id
                                    764 ;	-----------------------------------------
      00B612                        765 _qmk_id_to_vialrgb_id:
      00B612 12 38 52         [24]  766 	lcall	_ak820_outline_0106
      00B615 90 0D A2         [24]  767 	mov	dptr,#_qmk_id_to_vialrgb_id_id_10000_262
      00B618 12 38 57         [24]  768 	lcall	_ak820_outline_0107
                                    769 ;	quantum/vialrgb.c:58: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B61B 90 0D A2         [24]  770 	mov	dptr,#_qmk_id_to_vialrgb_id_id_10000_262
      00B61E 12 37 FC         [24]  771 	lcall	_ak820_outline_0051
      00B621 7D 00            [12]  772 	mov	r5,#0x00
      00B623                        773 00105$:
      00B623 BD 07 00         [24]  774 	cjne	r5,#0x07,00130$
      00B626                        775 00130$:
      00B626 50 19            [24]  776 	jnc	00103$
                                    777 ;	quantum/vialrgb.c:59: uint16_t qmk_id = READ_MODE_ID(&supported_modes[i].qmk_id);
      00B628 12 BA 41         [24]  778 	lcall	_ak820_outline_0046
      00B62B A3               [24]  779 	inc	dptr
      00B62C E4               [12]  780 	clr	a
      00B62D 93               [24]  781 	movc	a,@a+dptr
                                    782 ;	quantum/vialrgb.c:60: if (qmk_id == id)
      00B62E 7A 00            [12]  783 	mov	r2,#0x00
      00B630 B5 06 0B         [24]  784 	cjne	a,ar6,00106$
      00B633 EA               [12]  785 	mov	a,r2
      00B634 B5 07 07         [24]  786 	cjne	a,ar7,00106$
                                    787 ;	quantum/vialrgb.c:61: return READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00B637 12 33 FC         [24]  788 	lcall	_ak820_outline_0126
      00B63A 12 BA 6D         [24]  789 	lcall	_ak820_outline_0150
      00B63D 22               [24]  790 	ret
      00B63E                        791 00106$:
                                    792 ;	quantum/vialrgb.c:58: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B63E 0D               [12]  793 	inc	r5
      00B63F 80 E2            [24]  794 	sjmp	00105$
      00B641                        795 00103$:
                                    796 ;	quantum/vialrgb.c:63: return 0;
      00B641 90 00 00         [24]  797 	mov	dptr,#0x0000
                                    798 ;	quantum/vialrgb.c:64: }
      00B644 22               [24]  799 	ret
                                    800 ;------------------------------------------------------------
                                    801 ;Allocation info for local variables in function 'vialrgb_id_to_qmk_id'
                                    802 ;------------------------------------------------------------
                                    803 ;id            Allocated with name '_vialrgb_id_to_qmk_id_id_10000_267'
                                    804 ;i             Allocated with name '_vialrgb_id_to_qmk_id_i_20000_269'
                                    805 ;vialrgb_id    Allocated with name '_vialrgb_id_to_qmk_id_vialrgb_id_30000_270'
                                    806 ;------------------------------------------------------------
                                    807 ;	quantum/vialrgb.c:66: static uint16_t vialrgb_id_to_qmk_id(uint16_t id) {
                                    808 ;	-----------------------------------------
                                    809 ;	 function vialrgb_id_to_qmk_id
                                    810 ;	-----------------------------------------
      00B645                        811 _vialrgb_id_to_qmk_id:
      00B645 12 38 52         [24]  812 	lcall	_ak820_outline_0106
      00B648 90 0D A4         [24]  813 	mov	dptr,#_vialrgb_id_to_qmk_id_id_10000_267
      00B64B 12 38 57         [24]  814 	lcall	_ak820_outline_0107
                                    815 ;	quantum/vialrgb.c:67: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B64E 90 0D A4         [24]  816 	mov	dptr,#_vialrgb_id_to_qmk_id_id_10000_267
      00B651 12 37 FC         [24]  817 	lcall	_ak820_outline_0051
      00B654 7D 00            [12]  818 	mov	r5,#0x00
      00B656                        819 00105$:
      00B656 BD 07 00         [24]  820 	cjne	r5,#0x07,00130$
      00B659                        821 00130$:
      00B659 50 19            [24]  822 	jnc	00103$
                                    823 ;	quantum/vialrgb.c:68: uint16_t vialrgb_id = READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00B65B 12 BA 41         [24]  824 	lcall	_ak820_outline_0046
      00B65E E4               [12]  825 	clr	a
      00B65F 93               [24]  826 	movc	a,@a+dptr
                                    827 ;	quantum/vialrgb.c:69: if (vialrgb_id == id)
      00B660 7A 00            [12]  828 	mov	r2,#0x00
      00B662 B5 06 0C         [24]  829 	cjne	a,ar6,00106$
      00B665 EA               [12]  830 	mov	a,r2
      00B666 B5 07 08         [24]  831 	cjne	a,ar7,00106$
                                    832 ;	quantum/vialrgb.c:70: return READ_MODE_ID(&supported_modes[i].qmk_id);
      00B669 12 33 FC         [24]  833 	lcall	_ak820_outline_0126
      00B66C A3               [24]  834 	inc	dptr
      00B66D 12 BA 6D         [24]  835 	lcall	_ak820_outline_0150
      00B670 22               [24]  836 	ret
      00B671                        837 00106$:
                                    838 ;	quantum/vialrgb.c:67: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B671 0D               [12]  839 	inc	r5
      00B672 80 E2            [24]  840 	sjmp	00105$
      00B674                        841 00103$:
                                    842 ;	quantum/vialrgb.c:72: return 0;
      00B674 90 00 00         [24]  843 	mov	dptr,#0x0000
                                    844 ;	quantum/vialrgb.c:73: }
      00B677 22               [24]  845 	ret
                                    846 ;------------------------------------------------------------
                                    847 ;Allocation info for local variables in function 'get_mode'
                                    848 ;------------------------------------------------------------
                                    849 ;	quantum/vialrgb.c:75: static uint16_t get_mode(void) {
                                    850 ;	-----------------------------------------
                                    851 ;	 function get_mode
                                    852 ;	-----------------------------------------
      00B678                        853 _get_mode:
                                    854 ;	quantum/vialrgb.c:77: if (!rgb_matrix_is_enabled())
      00B678 12 59 3E         [24]  855 	lcall	_rgb_matrix_is_enabled
      00B67B E5 82            [12]  856 	mov	a, dpl
      00B67D 70 04            [24]  857 	jnz	00102$
                                    858 ;	quantum/vialrgb.c:78: return VIALRGB_EFFECT_OFF;
      00B67F 90 00 00         [24]  859 	mov	dptr,#0x0000
      00B682 22               [24]  860 	ret
      00B683                        861 00102$:
                                    862 ;	quantum/vialrgb.c:79: return qmk_id_to_vialrgb_id(rgb_matrix_get_mode());
      00B683 12 59 44         [24]  863 	lcall	_rgb_matrix_get_mode
      00B686 7E 00            [12]  864 	mov	r6,#0x00
      00B688 8E 83            [24]  865 	mov	dph, r6
                                    866 ;	quantum/vialrgb.c:80: }
      00B68A C1 12            [12]  867 	ajmp	_qmk_id_to_vialrgb_id
                                    868 ;------------------------------------------------------------
                                    869 ;Allocation info for local variables in function 'set_mode'
                                    870 ;------------------------------------------------------------
                                    871 ;mode          Allocated with name '_set_mode_mode_10000_275'
                                    872 ;------------------------------------------------------------
                                    873 ;	quantum/vialrgb.c:82: static void set_mode(uint16_t mode) {
                                    874 ;	-----------------------------------------
                                    875 ;	 function set_mode
                                    876 ;	-----------------------------------------
      00B68C                        877 _set_mode:
      00B68C 12 38 52         [24]  878 	lcall	_ak820_outline_0106
      00B68F 90 0D A6         [24]  879 	mov	dptr,#_set_mode_mode_10000_275
      00B692 12 38 57         [24]  880 	lcall	_ak820_outline_0107
                                    881 ;	quantum/vialrgb.c:84: if (mode == VIALRGB_EFFECT_OFF) {
      00B695 90 0D A6         [24]  882 	mov	dptr,#_set_mode_mode_10000_275
      00B698 12 37 FC         [24]  883 	lcall	_ak820_outline_0051
      00B69B 90 0D A6         [24]  884 	mov	dptr,#_set_mode_mode_10000_275
      00B69E 12 71 8A         [24]  885 	lcall	_ak820_outline_0036
      00B6A1 70 03            [24]  886 	jnz	00102$
                                    887 ;	quantum/vialrgb.c:85: rgb_matrix_disable_noeeprom();
      00B6A3 02 59 91         [24]  888 	ljmp	_rgb_matrix_disable_noeeprom
      00B6A6                        889 00102$:
                                    890 ;	quantum/vialrgb.c:87: rgb_matrix_enable_noeeprom();
      00B6A6 C0 07            [24]  891 	push	ar7
      00B6A8 C0 06            [24]  892 	push	ar6
      00B6AA 12 59 80         [24]  893 	lcall	_rgb_matrix_enable_noeeprom
      00B6AD D0 06            [24]  894 	pop	ar6
      00B6AF D0 07            [24]  895 	pop	ar7
                                    896 ;	quantum/vialrgb.c:88: rgb_matrix_mode_noeeprom(vialrgb_id_to_qmk_id(mode));
      00B6B1 12 43 2B         [24]  897 	lcall	_ak820_outline_0121
      00B6B4 D1 45            [12]  898 	acall	_vialrgb_id_to_qmk_id
                                    899 ;	quantum/vialrgb.c:90: }
      00B6B6 02 59 9A         [24]  900 	ljmp	_rgb_matrix_mode_noeeprom
                                    901 ;------------------------------------------------------------
                                    902 ;Allocation info for local variables in function 'get_matrix_pos_for_led'
                                    903 ;------------------------------------------------------------
                                    904 ;output        Allocated with name '_get_matrix_pos_for_led_PARM_2'
                                    905 ;led           Allocated with name '_get_matrix_pos_for_led_led_10000_280'
                                    906 ;slot          Allocated with name '_get_matrix_pos_for_led_slot_10000_281'
                                    907 ;------------------------------------------------------------
                                    908 ;	quantum/vialrgb.c:93: static void get_matrix_pos_for_led(uint16_t led, uint8_t VIALRGB_BUFFER *output) {
                                    909 ;	-----------------------------------------
                                    910 ;	 function get_matrix_pos_for_led
                                    911 ;	-----------------------------------------
      00B6B9                        912 _get_matrix_pos_for_led:
      00B6B9 12 38 52         [24]  913 	lcall	_ak820_outline_0106
      00B6BC 90 0D AA         [24]  914 	mov	dptr,#_get_matrix_pos_for_led_led_10000_280
      00B6BF 12 38 57         [24]  915 	lcall	_ak820_outline_0107
                                    916 ;	quantum/vialrgb.c:95: uint8_t slot = ak820_rgb_slots[led];
      00B6C2 90 0D AA         [24]  917 	mov	dptr,#_get_matrix_pos_for_led_led_10000_280
      00B6C5 12 37 FC         [24]  918 	lcall	_ak820_outline_0051
      00B6C8 EE               [12]  919 	mov	a,r6
      00B6C9 24 13            [12]  920 	add	a, #_ak820_rgb_slots
      00B6CB F5 82            [12]  921 	mov	dpl,a
      00B6CD EF               [12]  922 	mov	a,r7
      00B6CE 34 BD            [12]  923 	addc	a, #(_ak820_rgb_slots >> 8)
      00B6D0 F5 83            [12]  924 	mov	dph,a
      00B6D2 E4               [12]  925 	clr	a
      00B6D3 93               [24]  926 	movc	a,@a+dptr
      00B6D4 FF               [12]  927 	mov	r7,a
                                    928 ;	quantum/vialrgb.c:96: output[0] = slot >> 3;
      00B6D5 90 0D A8         [24]  929 	mov	dptr,#_get_matrix_pos_for_led_PARM_2
      00B6D8 12 43 19         [24]  930 	lcall	_ak820_outline_0096
      00B6DB EF               [12]  931 	mov	a,r7
      00B6DC 12 5B 71         [24]  932 	lcall	_ak820_outline_0190
      00B6DF 12 47 F2         [24]  933 	lcall	_ak820_outline_0102
                                    934 ;	quantum/vialrgb.c:97: output[1] = slot & 7;
      00B6E2 12 38 66         [24]  935 	lcall	_ak820_outline_0136
      00B6E5 A3               [24]  936 	inc	dptr
      00B6E6 53 07 07         [24]  937 	anl	ar7,#0x07
      00B6E9 EF               [12]  938 	mov	a,r7
      00B6EA F0               [24]  939 	movx	@dptr,a
                                    940 ;	quantum/vialrgb.c:110: }
      00B6EB 22               [24]  941 	ret
                                    942 ;------------------------------------------------------------
                                    943 ;Allocation info for local variables in function 'fast_set_leds'
                                    944 ;------------------------------------------------------------
                                    945 ;sloc0         Allocated with name '_fast_set_leds_sloc0_1_0'
                                    946 ;sloc1         Allocated with name '_fast_set_leds_sloc1_1_0'
                                    947 ;length        Allocated with name '_fast_set_leds_PARM_2'
                                    948 ;args          Allocated with name '_fast_set_leds_args_10000_282'
                                    949 ;first_index   Allocated with name '_fast_set_leds_first_index_10001_285'
                                    950 ;num_leds      Allocated with name '_fast_set_leds_num_leds_10001_285'
                                    951 ;i             Allocated with name '_fast_set_leds_i_20001_288'
                                    952 ;color         Allocated with name '_fast_set_leds_color_30001_289'
                                    953 ;val           Allocated with name '_fast_set_leds_val_30002_290'
                                    954 ;------------------------------------------------------------
                                    955 ;	quantum/vialrgb.c:112: static void fast_set_leds(uint8_t VIALRGB_BUFFER *args, uint8_t length) {
                                    956 ;	-----------------------------------------
                                    957 ;	 function fast_set_leds
                                    958 ;	-----------------------------------------
      00B6EC                        959 _fast_set_leds:
      00B6EC 12 38 52         [24]  960 	lcall	_ak820_outline_0106
      00B6EF 90 0D AD         [24]  961 	mov	dptr,#_fast_set_leds_args_10000_282
      00B6F2 12 38 57         [24]  962 	lcall	_ak820_outline_0107
                                    963 ;	quantum/vialrgb.c:115: if (length < 3) return;
      00B6F5 90 0D AC         [24]  964 	mov	dptr,#_fast_set_leds_PARM_2
      00B6F8 E0               [24]  965 	movx	a,@dptr
      00B6F9 FF               [12]  966 	mov	r7,a
      00B6FA BF 03 00         [24]  967 	cjne	r7,#0x03,00159$
      00B6FD                        968 00159$:
      00B6FD 50 01            [24]  969 	jnc	00102$
      00B6FF 22               [24]  970 	ret
      00B700                        971 00102$:
                                    972 ;	quantum/vialrgb.c:117: uint16_t first_index = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00B700 90 0D AD         [24]  973 	mov	dptr,#_fast_set_leds_args_10000_282
      00B703 12 43 19         [24]  974 	lcall	_ak820_outline_0096
      00B706 12 4D 00         [24]  975 	lcall	_ak820_outline_0076
      00B709 7B 00            [12]  976 	mov	r3,#0x00
      00B70B 12 38 66         [24]  977 	lcall	_ak820_outline_0136
      00B70E A3               [24]  978 	inc	dptr
      00B70F E0               [24]  979 	movx	a,@dptr
      00B710 FA               [12]  980 	mov	r2,a
      00B711 79 00            [12]  981 	mov	r1,#0x00
      00B713 90 0D AF         [24]  982 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00B716 E9               [12]  983 	mov	a,r1
      00B717 4C               [12]  984 	orl	a,r4
      00B718 F0               [24]  985 	movx	@dptr,a
      00B719 EA               [12]  986 	mov	a,r2
      00B71A 4B               [12]  987 	orl	a,r3
      00B71B A3               [24]  988 	inc	dptr
      00B71C F0               [24]  989 	movx	@dptr,a
                                    990 ;	quantum/vialrgb.c:118: uint8_t num_leds = args[2];
      00B71D 12 38 66         [24]  991 	lcall	_ak820_outline_0136
      00B720 A3               [24]  992 	inc	dptr
      00B721 A3               [24]  993 	inc	dptr
      00B722 E0               [24]  994 	movx	a,@dptr
      00B723 90 0D B1         [24]  995 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B726 F0               [24]  996 	movx	@dptr,a
                                    997 ;	quantum/vialrgb.c:119: length -= 3;
      00B727 EF               [12]  998 	mov	a,r7
      00B728 24 FD            [12]  999 	add	a,#0xfd
      00B72A 90 0D AC         [24] 1000 	mov	dptr,#_fast_set_leds_PARM_2
      00B72D F0               [24] 1001 	movx	@dptr,a
                                   1002 ;	quantum/vialrgb.c:120: args += 3;
      00B72E 90 0D AD         [24] 1003 	mov	dptr,#_fast_set_leds_args_10000_282
      00B731 74 03            [12] 1004 	mov	a,#0x03
      00B733 2D               [12] 1005 	add	a, r5
      00B734 F0               [24] 1006 	movx	@dptr,a
      00B735 E4               [12] 1007 	clr	a
      00B736 3E               [12] 1008 	addc	a, r6
      00B737 A3               [24] 1009 	inc	dptr
      00B738 F0               [24] 1010 	movx	@dptr,a
                                   1011 ;	quantum/vialrgb.c:123: if ((uint16_t)num_leds * 3u > length || first_index >= RGB_MATRIX_LED_COUNT) return;
      00B739 90 0D B1         [24] 1012 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B73C E0               [24] 1013 	movx	a,@dptr
      00B73D FF               [12] 1014 	mov	r7,a
      00B73E 75 F0 03         [24] 1015 	mov	b,#0x03
      00B741 A4               [48] 1016 	mul	ab
      00B742 FE               [12] 1017 	mov	r6,a
      00B743 AD F0            [24] 1018 	mov	r5,b
      00B745 90 0D AC         [24] 1019 	mov	dptr,#_fast_set_leds_PARM_2
      00B748 E0               [24] 1020 	movx	a,@dptr
      00B749 FB               [12] 1021 	mov	r3,a
      00B74A 7C 00            [12] 1022 	mov	r4,#0x00
      00B74C C3               [12] 1023 	clr	c
      00B74D EB               [12] 1024 	mov	a,r3
      00B74E 9E               [12] 1025 	subb	a,r6
      00B74F EC               [12] 1026 	mov	a,r4
      00B750 9D               [12] 1027 	subb	a,r5
      00B751 40 13            [24] 1028 	jc	00103$
                                   1029 ;	free result
      00B753 90 0D AF         [24] 1030 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00B756 12 43 19         [24] 1031 	lcall	_ak820_outline_0096
      00B759 8D 03            [24] 1032 	mov	ar3,r5
      00B75B 8E 04            [24] 1033 	mov	ar4,r6
      00B75D C3               [12] 1034 	clr	c
      00B75E EB               [12] 1035 	mov	a,r3
      00B75F 94 52            [12] 1036 	subb	a,#0x52
      00B761 EC               [12] 1037 	mov	a,r4
      00B762 94 00            [12] 1038 	subb	a,#0x00
      00B764 40 01            [24] 1039 	jc	00104$
      00B766                       1040 00103$:
      00B766 22               [24] 1041 	ret
      00B767                       1042 00104$:
                                   1043 ;	quantum/vialrgb.c:124: if (num_leds > RGB_MATRIX_LED_COUNT - first_index) num_leds = RGB_MATRIX_LED_COUNT - first_index;
      00B767 74 52            [12] 1044 	mov	a,#0x52
      00B769 C3               [12] 1045 	clr	c
      00B76A 9D               [12] 1046 	subb	a,r5
      00B76B FB               [12] 1047 	mov	r3,a
      00B76C E4               [12] 1048 	clr	a
      00B76D 9E               [12] 1049 	subb	a,r6
      00B76E FC               [12] 1050 	mov	r4,a
      00B76F 7A 00            [12] 1051 	mov	r2,#0x00
      00B771 C3               [12] 1052 	clr	c
      00B772 EB               [12] 1053 	mov	a,r3
      00B773 9F               [12] 1054 	subb	a,r7
      00B774 EC               [12] 1055 	mov	a,r4
      00B775 9A               [12] 1056 	subb	a,r2
      00B776 50 08            [24] 1057 	jnc	00127$
                                   1058 ;	free result
      00B778 90 0D B1         [24] 1059 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B77B 74 52            [12] 1060 	mov	a,#0x52
      00B77D C3               [12] 1061 	clr	c
      00B77E 9D               [12] 1062 	subb	a,r5
      00B77F F0               [24] 1063 	movx	@dptr,a
                                   1064 ;	quantum/vialrgb.c:126: for (uint8_t i = 0; i < num_leds; ++i) {
      00B780                       1065 00127$:
      00B780 90 0D B1         [24] 1066 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B783 E0               [24] 1067 	movx	a,@dptr
      00B784 FF               [12] 1068 	mov	r7,a
      00B785 90 0D AF         [24] 1069 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00B788 12 43 19         [24] 1070 	lcall	_ak820_outline_0096
      00B78B 7C 00            [12] 1071 	mov	r4,#0x00
      00B78D                       1072 00110$:
      00B78D C3               [12] 1073 	clr	c
      00B78E EC               [12] 1074 	mov	a,r4
      00B78F 9F               [12] 1075 	subb	a,r7
      00B790 40 01            [24] 1076 	jc	00164$
      00B792 22               [24] 1077 	ret
      00B793                       1078 00164$:
                                   1079 ;	quantum/vialrgb.c:127: HSV VIALRGB_BUFFER *color = &g_direct_mode_colors[first_index++];
      00B793 C0 07            [24] 1080 	push	ar7
      00B795 90 0D C9         [24] 1081 	mov	dptr,#__mulint_PARM_2
      00B798 12 43 3B         [24] 1082 	lcall	_ak820_outline_0140
      00B79B 90 00 03         [24] 1083 	mov	dptr,#0x0003
      00B79E C0 07            [24] 1084 	push	ar7
      00B7A0 C0 06            [24] 1085 	push	ar6
      00B7A2 C0 05            [24] 1086 	push	ar5
      00B7A4 C0 04            [24] 1087 	push	ar4
      00B7A6 12 BB D9         [24] 1088 	lcall	__mulint
      00B7A9 AA 82            [24] 1089 	mov	r2, dpl
      00B7AB AB 83            [24] 1090 	mov	r3, dph
      00B7AD D0 04            [24] 1091 	pop	ar4
      00B7AF D0 05            [24] 1092 	pop	ar5
      00B7B1 D0 06            [24] 1093 	pop	ar6
      00B7B3 D0 07            [24] 1094 	pop	ar7
      00B7B5 0D               [12] 1095 	inc	r5
      00B7B6 BD 00 01         [24] 1096 	cjne	r5,#0x00,00165$
      00B7B9 0E               [12] 1097 	inc	r6
      00B7BA                       1098 00165$:
      00B7BA EA               [12] 1099 	mov	a,r2
      00B7BB 24 A9            [12] 1100 	add	a, #_g_direct_mode_colors
      00B7BD FA               [12] 1101 	mov	r2,a
      00B7BE EB               [12] 1102 	mov	a,r3
      00B7BF 34 0C            [12] 1103 	addc	a, #(_g_direct_mode_colors >> 8)
      00B7C1 FB               [12] 1104 	mov	r3,a
                                   1105 ;	quantum/vialrgb.c:128: color->h = *args++;
      00B7C2 8A 4A            [24] 1106 	mov	_fast_set_leds_sloc0_1_0,r2
      00B7C4 8B 4B            [24] 1107 	mov	(_fast_set_leds_sloc0_1_0 + 1),r3
      00B7C6 12 BA 53         [24] 1108 	lcall	_ak820_outline_0083
      00B7C9 F8               [12] 1109 	mov	r0,a
      00B7CA 12 BA 61         [24] 1110 	lcall	_ak820_outline_0111
      00B7CD 85 4A 82         [24] 1111 	mov	dpl,_fast_set_leds_sloc0_1_0
      00B7D0 85 4B 83         [24] 1112 	mov	dph,(_fast_set_leds_sloc0_1_0 + 1)
      00B7D3 E8               [12] 1113 	mov	a,r0
      00B7D4 F0               [24] 1114 	movx	@dptr,a
                                   1115 ;	quantum/vialrgb.c:129: color->s = *args++;
      00B7D5 74 01            [12] 1116 	mov	a,#0x01
      00B7D7 2A               [12] 1117 	add	a, r2
      00B7D8 F5 4A            [12] 1118 	mov	_fast_set_leds_sloc0_1_0,a
      00B7DA E4               [12] 1119 	clr	a
      00B7DB 3B               [12] 1120 	addc	a, r3
      00B7DC F5 4B            [12] 1121 	mov	(_fast_set_leds_sloc0_1_0 + 1),a
      00B7DE 90 0D AD         [24] 1122 	mov	dptr,#_fast_set_leds_args_10000_282
      00B7E1 E0               [24] 1123 	movx	a,@dptr
      00B7E2 F8               [12] 1124 	mov	r0,a
      00B7E3 A3               [24] 1125 	inc	dptr
      00B7E4 E0               [24] 1126 	movx	a,@dptr
      00B7E5 FF               [12] 1127 	mov	r7,a
      00B7E6 88 82            [24] 1128 	mov	dpl,r0
      00B7E8 8F 83            [24] 1129 	mov	dph,r7
      00B7EA E0               [24] 1130 	movx	a,@dptr
      00B7EB F9               [12] 1131 	mov	r1,a
      00B7EC 90 0D AD         [24] 1132 	mov	dptr,#_fast_set_leds_args_10000_282
      00B7EF 74 01            [12] 1133 	mov	a,#0x01
      00B7F1 28               [12] 1134 	add	a, r0
      00B7F2 F0               [24] 1135 	movx	@dptr,a
      00B7F3 E4               [12] 1136 	clr	a
      00B7F4 3F               [12] 1137 	addc	a, r7
      00B7F5 A3               [24] 1138 	inc	dptr
      00B7F6 F0               [24] 1139 	movx	@dptr,a
      00B7F7 85 4A 82         [24] 1140 	mov	dpl,_fast_set_leds_sloc0_1_0
      00B7FA 85 4B 83         [24] 1141 	mov	dph,(_fast_set_leds_sloc0_1_0 + 1)
      00B7FD E9               [12] 1142 	mov	a,r1
      00B7FE F0               [24] 1143 	movx	@dptr,a
                                   1144 ;	quantum/vialrgb.c:130: uint8_t val = *args++;
      00B7FF 12 BA 53         [24] 1145 	lcall	_ak820_outline_0083
      00B802 F5 4A            [12] 1146 	mov	_fast_set_leds_sloc0_1_0,a
      00B804 12 BA 61         [24] 1147 	lcall	_ak820_outline_0111
                                   1148 ;	quantum/vialrgb.c:131: color->v = (val > RGB_MATRIX_MAXIMUM_BRIGHTNESS) ? RGB_MATRIX_MAXIMUM_BRIGHTNESS : val;
      00B807 74 02            [12] 1149 	mov	a,#0x02
      00B809 2A               [12] 1150 	add	a, r2
      00B80A F5 4C            [12] 1151 	mov	_fast_set_leds_sloc1_1_0,a
      00B80C E4               [12] 1152 	clr	a
      00B80D 3B               [12] 1153 	addc	a, r3
      00B80E F5 4D            [12] 1154 	mov	(_fast_set_leds_sloc1_1_0 + 1),a
      00B810 C3               [12] 1155 	clr	c
      00B811 74 A0            [12] 1156 	mov	a,#0xa0
      00B813 95 4A            [12] 1157 	subb	a,_fast_set_leds_sloc0_1_0
      00B815 D0 07            [24] 1158 	pop	ar7
      00B817 50 04            [24] 1159 	jnc	00114$
                                   1160 ;	free result
      00B819 7B A0            [12] 1161 	mov	r3,#0xa0
      00B81B 80 04            [24] 1162 	sjmp	00115$
      00B81D                       1163 00114$:
      00B81D AA 4A            [24] 1164 	mov	r2,_fast_set_leds_sloc0_1_0
      00B81F 8A 03            [24] 1165 	mov	ar3,r2
      00B821                       1166 00115$:
      00B821 85 4C 82         [24] 1167 	mov	dpl,_fast_set_leds_sloc1_1_0
      00B824 85 4D 83         [24] 1168 	mov	dph,(_fast_set_leds_sloc1_1_0 + 1)
      00B827 EB               [12] 1169 	mov	a,r3
      00B828 F0               [24] 1170 	movx	@dptr,a
                                   1171 ;	quantum/vialrgb.c:126: for (uint8_t i = 0; i < num_leds; ++i) {
      00B829 0C               [12] 1172 	inc	r4
                                   1173 ;	quantum/vialrgb.c:133: }
      00B82A 02 B7 8D         [24] 1174 	ljmp	00110$
                                   1175 ;------------------------------------------------------------
                                   1176 ;Allocation info for local variables in function 'vialrgb_get_value'
                                   1177 ;------------------------------------------------------------
                                   1178 ;sloc0         Allocated with name '_vialrgb_get_value_sloc0_1_0'
                                   1179 ;sloc1         Allocated with name '_vialrgb_get_value_sloc1_1_0'
                                   1180 ;length        Allocated with name '_vialrgb_get_value_PARM_2'
                                   1181 ;data          Allocated with name '_vialrgb_get_value_data_10000_291'
                                   1182 ;args          Allocated with name '_vialrgb_get_value_args_10001_294'
                                   1183 ;cmd           Allocated with name '_vialrgb_get_value_cmd_10001_294'
                                   1184 ;vialrgb_id    Allocated with name '_vialrgb_get_value_vialrgb_id_40001_297'
                                   1185 ;led           Allocated with name '_vialrgb_get_value_led_40001_300'
                                   1186 ;------------------------------------------------------------
                                   1187 ;	quantum/vialrgb.c:136: void vialrgb_get_value(uint8_t *data, uint8_t length) {
                                   1188 ;	-----------------------------------------
                                   1189 ;	 function vialrgb_get_value
                                   1190 ;	-----------------------------------------
      00B82D                       1191 _vialrgb_get_value:
      00B82D 12 42 D5         [24] 1192 	lcall	_ak820_outline_0037
      00B830 90 0D B3         [24] 1193 	mov	dptr,#_vialrgb_get_value_data_10000_291
      00B833 12 37 E4         [24] 1194 	lcall	_ak820_outline_0016
                                   1195 ;	quantum/vialrgb.c:137: if (length != VIAL_RAW_EPSIZE) return;
      00B836 90 0D B2         [24] 1196 	mov	dptr,#_vialrgb_get_value_PARM_2
      00B839 E0               [24] 1197 	movx	a,@dptr
      00B83A FF               [12] 1198 	mov	r7,a
      00B83B BF 20 02         [24] 1199 	cjne	r7,#0x20,00162$
      00B83E 80 01            [24] 1200 	sjmp	00102$
      00B840                       1201 00162$:
      00B840 22               [24] 1202 	ret
      00B841                       1203 00102$:
                                   1204 ;	quantum/vialrgb.c:140: uint8_t VIALRGB_BUFFER *args = (uint8_t VIALRGB_BUFFER *)data + 2;
      00B841 90 0D B3         [24] 1205 	mov	dptr,#_vialrgb_get_value_data_10000_291
      00B844 12 BA 2D         [24] 1206 	lcall	_ak820_outline_0044
                                   1207 ;	quantum/vialrgb.c:141: uint8_t cmd = args[-1];
                                   1208 ;	quantum/vialrgb.c:142: switch (cmd) {
      00B847 BA 40 02         [24] 1209 	cjne	r2,#0x40,00163$
      00B84A 80 15            [24] 1210 	sjmp	00103$
      00B84C                       1211 00163$:
      00B84C BA 41 02         [24] 1212 	cjne	r2,#0x41,00164$
      00B84F 80 23            [24] 1213 	sjmp	00104$
      00B851                       1214 00164$:
      00B851 BA 42 02         [24] 1215 	cjne	r2,#0x42,00165$
      00B854 21 05            [12] 1216 	ajmp	00105$
      00B856                       1217 00165$:
      00B856 BA 43 02         [24] 1218 	cjne	r2,#0x43,00166$
      00B859 21 11            [12] 1219 	ajmp	00106$
      00B85B                       1220 00166$:
      00B85B BA 44 02         [24] 1221 	cjne	r2,#0x44,00167$
      00B85E 21 1D            [12] 1222 	ajmp	00107$
      00B860                       1223 00167$:
      00B860 22               [24] 1224 	ret
                                   1225 ;	quantum/vialrgb.c:143: case vialrgb_get_info:
      00B861                       1226 00103$:
                                   1227 ;	quantum/vialrgb.c:144: args[0] = VIALRGB_PROTOCOL_VERSION & 0xFF;
      00B861 12 33 FC         [24] 1228 	lcall	_ak820_outline_0126
      00B864 74 01            [12] 1229 	mov	a,#0x01
      00B866 F0               [24] 1230 	movx	@dptr,a
                                   1231 ;	quantum/vialrgb.c:145: args[1] = VIALRGB_PROTOCOL_VERSION >> 8;
      00B867 12 BA 25         [24] 1232 	lcall	_ak820_outline_0035
      00B86A E4               [12] 1233 	clr	a
      00B86B F0               [24] 1234 	movx	@dptr,a
                                   1235 ;	quantum/vialrgb.c:146: args[2] = RGB_MATRIX_MAXIMUM_BRIGHTNESS;
      00B86C 12 BA 25         [24] 1236 	lcall	_ak820_outline_0035
      00B86F A3               [24] 1237 	inc	dptr
      00B870 74 A0            [12] 1238 	mov	a,#0xa0
      00B872 F0               [24] 1239 	movx	@dptr,a
                                   1240 ;	quantum/vialrgb.c:147: break;
      00B873 22               [24] 1241 	ret
                                   1242 ;	quantum/vialrgb.c:148: case vialrgb_get_mode: {
      00B874                       1243 00104$:
                                   1244 ;	quantum/vialrgb.c:149: uint16_t vialrgb_id = get_mode();
      00B874 C0 06            [24] 1245 	push	ar6
      00B876 C0 05            [24] 1246 	push	ar5
      00B878 C0 04            [24] 1247 	push	ar4
      00B87A C0 03            [24] 1248 	push	ar3
      00B87C 12 B6 78         [24] 1249 	lcall	_get_mode
      00B87F 12 4D 22         [24] 1250 	lcall	_ak820_outline_0189
      00B882 D0 03            [24] 1251 	pop	ar3
      00B884 D0 04            [24] 1252 	pop	ar4
      00B886 D0 05            [24] 1253 	pop	ar5
      00B888 D0 06            [24] 1254 	pop	ar6
                                   1255 ;	quantum/vialrgb.c:150: args[0] = vialrgb_id & 0xFF;
      00B88A 89 00            [24] 1256 	mov	ar0,r1
      00B88C 12 33 FC         [24] 1257 	lcall	_ak820_outline_0126
      00B88F E8               [12] 1258 	mov	a,r0
      00B890 F0               [24] 1259 	movx	@dptr,a
                                   1260 ;	quantum/vialrgb.c:151: args[1] = vialrgb_id >> 8;
      00B891 12 BA 25         [24] 1261 	lcall	_ak820_outline_0035
      00B894 8A 01            [24] 1262 	mov	ar1,r2
      00B896 E9               [12] 1263 	mov	a,r1
      00B897 F0               [24] 1264 	movx	@dptr,a
                                   1265 ;	quantum/vialrgb.c:152: args[2] = rgb_matrix_get_speed();
      00B898 74 04            [12] 1266 	mov	a,#0x04
      00B89A 12 91 C1         [24] 1267 	lcall	_ak820_outline_0137
      00B89D C0 06            [24] 1268 	push	ar6
      00B89F C0 05            [24] 1269 	push	ar5
      00B8A1 C0 02            [24] 1270 	push	ar2
      00B8A3 C0 01            [24] 1271 	push	ar1
      00B8A5 12 59 5F         [24] 1272 	lcall	_rgb_matrix_get_speed
      00B8A8 A8 82            [24] 1273 	mov	r0, dpl
      00B8AA D0 01            [24] 1274 	pop	ar1
      00B8AC D0 02            [24] 1275 	pop	ar2
      00B8AE D0 05            [24] 1276 	pop	ar5
      00B8B0 D0 06            [24] 1277 	pop	ar6
      00B8B2 12 84 1B         [24] 1278 	lcall	_ak820_outline_0065
                                   1279 ;	quantum/vialrgb.c:153: args[3] = rgb_matrix_get_hue();
      00B8B5 74 05            [12] 1280 	mov	a,#0x05
      00B8B7 12 91 C1         [24] 1281 	lcall	_ak820_outline_0137
      00B8BA C0 06            [24] 1282 	push	ar6
      00B8BC C0 05            [24] 1283 	push	ar5
      00B8BE C0 02            [24] 1284 	push	ar2
      00B8C0 C0 01            [24] 1285 	push	ar1
      00B8C2 12 59 4A         [24] 1286 	lcall	_rgb_matrix_get_hue
      00B8C5 A8 82            [24] 1287 	mov	r0, dpl
      00B8C7 D0 01            [24] 1288 	pop	ar1
      00B8C9 D0 02            [24] 1289 	pop	ar2
      00B8CB D0 05            [24] 1290 	pop	ar5
      00B8CD D0 06            [24] 1291 	pop	ar6
      00B8CF 12 84 1B         [24] 1292 	lcall	_ak820_outline_0065
                                   1293 ;	quantum/vialrgb.c:154: args[4] = rgb_matrix_get_sat();
      00B8D2 74 06            [12] 1294 	mov	a,#0x06
      00B8D4 12 91 C1         [24] 1295 	lcall	_ak820_outline_0137
      00B8D7 C0 06            [24] 1296 	push	ar6
      00B8D9 C0 05            [24] 1297 	push	ar5
      00B8DB C0 02            [24] 1298 	push	ar2
      00B8DD C0 01            [24] 1299 	push	ar1
      00B8DF 12 59 51         [24] 1300 	lcall	_rgb_matrix_get_sat
      00B8E2 A8 82            [24] 1301 	mov	r0, dpl
      00B8E4 D0 01            [24] 1302 	pop	ar1
      00B8E6 D0 02            [24] 1303 	pop	ar2
      00B8E8 D0 05            [24] 1304 	pop	ar5
      00B8EA D0 06            [24] 1305 	pop	ar6
      00B8EC 12 84 1B         [24] 1306 	lcall	_ak820_outline_0065
                                   1307 ;	quantum/vialrgb.c:155: args[5] = rgb_matrix_get_val();
      00B8EF 74 07            [12] 1308 	mov	a,#0x07
      00B8F1 12 91 C1         [24] 1309 	lcall	_ak820_outline_0137
      00B8F4 C0 02            [24] 1310 	push	ar2
      00B8F6 C0 01            [24] 1311 	push	ar1
      00B8F8 12 59 58         [24] 1312 	lcall	_rgb_matrix_get_val
      00B8FB A8 82            [24] 1313 	mov	r0, dpl
      00B8FD D0 01            [24] 1314 	pop	ar1
      00B8FF D0 02            [24] 1315 	pop	ar2
      00B901 12 84 1B         [24] 1316 	lcall	_ak820_outline_0065
                                   1317 ;	quantum/vialrgb.c:156: break;
      00B904 22               [24] 1318 	ret
                                   1319 ;	quantum/vialrgb.c:158: case vialrgb_get_supported: {
      00B905                       1320 00105$:
                                   1321 ;	quantum/vialrgb.c:159: get_supported(args, length - 2);
      00B905 EF               [12] 1322 	mov	a,r7
      00B906 24 FE            [12] 1323 	add	a,#0xfe
      00B908 90 0D 9F         [24] 1324 	mov	dptr,#_get_supported_PARM_2
      00B90B 12 A0 B6         [24] 1325 	lcall	_ak820_outline_0124
                                   1326 ;	quantum/vialrgb.c:160: break;
      00B90E 02 B5 82         [24] 1327 	ljmp	_get_supported
                                   1328 ;	quantum/vialrgb.c:163: case vialrgb_get_number_leds: {
      00B911                       1329 00106$:
                                   1330 ;	quantum/vialrgb.c:164: args[0] = RGB_MATRIX_LED_COUNT & 0xFF;
      00B911 12 33 FC         [24] 1331 	lcall	_ak820_outline_0126
      00B914 74 52            [12] 1332 	mov	a,#0x52
      00B916 F0               [24] 1333 	movx	@dptr,a
                                   1334 ;	quantum/vialrgb.c:165: args[1] = RGB_MATRIX_LED_COUNT >> 8;
      00B917 12 BA 25         [24] 1335 	lcall	_ak820_outline_0035
      00B91A E4               [12] 1336 	clr	a
      00B91B F0               [24] 1337 	movx	@dptr,a
                                   1338 ;	quantum/vialrgb.c:166: break;
      00B91C 22               [24] 1339 	ret
                                   1340 ;	quantum/vialrgb.c:168: case vialrgb_get_led_info: {
      00B91D                       1341 00107$:
                                   1342 ;	quantum/vialrgb.c:169: uint16_t led = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00B91D 12 33 FC         [24] 1343 	lcall	_ak820_outline_0126
      00B920 E0               [24] 1344 	movx	a,@dptr
      00B921 FF               [12] 1345 	mov	r7,a
      00B922 7A 00            [12] 1346 	mov	r2,#0x00
      00B924 74 03            [12] 1347 	mov	a,#0x03
      00B926 2D               [12] 1348 	add	a, r5
      00B927 F8               [12] 1349 	mov	r0,a
      00B928 E4               [12] 1350 	clr	a
      00B929 3E               [12] 1351 	addc	a, r6
      00B92A F9               [12] 1352 	mov	r1,a
      00B92B C0 03            [24] 1353 	push	ar3
      00B92D C0 04            [24] 1354 	push	ar4
      00B92F 12 38 76         [24] 1355 	lcall	_ak820_outline_0154
      00B932 E0               [24] 1356 	movx	a,@dptr
      00B933 FB               [12] 1357 	mov	r3,a
      00B934 E4               [12] 1358 	clr	a
      00B935 4F               [12] 1359 	orl	a,r7
      00B936 F5 4E            [12] 1360 	mov	_vialrgb_get_value_sloc0_1_0,a
      00B938 EB               [12] 1361 	mov	a,r3
      00B939 4A               [12] 1362 	orl	a,r2
      00B93A F5 4F            [12] 1363 	mov	(_vialrgb_get_value_sloc0_1_0 + 1),a
                                   1364 ;	quantum/vialrgb.c:170: if (led >= RGB_MATRIX_LED_COUNT) return;
      00B93C AC 4E            [24] 1365 	mov	r4,_vialrgb_get_value_sloc0_1_0
      00B93E AF 4F            [24] 1366 	mov	r7,(_vialrgb_get_value_sloc0_1_0 + 1)
      00B940 C3               [12] 1367 	clr	c
      00B941 EC               [12] 1368 	mov	a,r4
      00B942 94 52            [12] 1369 	subb	a,#0x52
      00B944 EF               [12] 1370 	mov	a,r7
      00B945 94 00            [12] 1371 	subb	a,#0x00
      00B947 D0 04            [24] 1372 	pop	ar4
      00B949 D0 03            [24] 1373 	pop	ar3
      00B94B 40 01            [24] 1374 	jc	00109$
      00B94D 22               [24] 1375 	ret
      00B94E                       1376 00109$:
                                   1377 ;	quantum/vialrgb.c:172: args[0] = ak820_led_points[led].x;
      00B94E E5 4E            [12] 1378 	mov	a,_vialrgb_get_value_sloc0_1_0
      00B950 25 4E            [12] 1379 	add	a,_vialrgb_get_value_sloc0_1_0
      00B952 FA               [12] 1380 	mov	r2,a
      00B953 E5 4F            [12] 1381 	mov	a,(_vialrgb_get_value_sloc0_1_0 + 1)
      00B955 33               [12] 1382 	rlc	a
      00B956 FF               [12] 1383 	mov	r7,a
      00B957 EA               [12] 1384 	mov	a,r2
      00B958 24 EF            [12] 1385 	add	a, #_ak820_led_points
      00B95A F5 50            [12] 1386 	mov	_vialrgb_get_value_sloc1_1_0,a
      00B95C EF               [12] 1387 	mov	a,r7
      00B95D 34 BF            [12] 1388 	addc	a, #(_ak820_led_points >> 8)
      00B95F F5 51            [12] 1389 	mov	(_vialrgb_get_value_sloc1_1_0 + 1),a
      00B961 85 50 82         [24] 1390 	mov	dpl,_vialrgb_get_value_sloc1_1_0
      00B964 85 51 83         [24] 1391 	mov	dph,(_vialrgb_get_value_sloc1_1_0 + 1)
      00B967 E4               [12] 1392 	clr	a
      00B968 93               [24] 1393 	movc	a,@a+dptr
      00B969 12 33 FC         [24] 1394 	lcall	_ak820_outline_0126
      00B96C F0               [24] 1395 	movx	@dptr,a
                                   1396 ;	quantum/vialrgb.c:173: args[1] = ak820_led_points[led].y;
      00B96D 85 50 82         [24] 1397 	mov	dpl,_vialrgb_get_value_sloc1_1_0
      00B970 85 51 83         [24] 1398 	mov	dph,(_vialrgb_get_value_sloc1_1_0 + 1)
      00B973 A3               [24] 1399 	inc	dptr
      00B974 E4               [12] 1400 	clr	a
      00B975 93               [24] 1401 	movc	a,@a+dptr
      00B976 12 38 76         [24] 1402 	lcall	_ak820_outline_0154
      00B979 F0               [24] 1403 	movx	@dptr,a
                                   1404 ;	quantum/vialrgb.c:174: args[2] = LED_FLAG_KEYLIGHT;
      00B97A 12 BA 25         [24] 1405 	lcall	_ak820_outline_0035
      00B97D A3               [24] 1406 	inc	dptr
      00B97E 74 04            [12] 1407 	mov	a,#0x04
      00B980 F0               [24] 1408 	movx	@dptr,a
                                   1409 ;	quantum/vialrgb.c:183: get_matrix_pos_for_led(led, &args[3]);
      00B981 90 0D A8         [24] 1410 	mov	dptr,#_get_matrix_pos_for_led_PARM_2
      00B984 04               [12] 1411 	inc	a
      00B985 2D               [12] 1412 	add	a, r5
      00B986 F0               [24] 1413 	movx	@dptr,a
      00B987 E4               [12] 1414 	clr	a
      00B988 3E               [12] 1415 	addc	a, r6
      00B989 A3               [24] 1416 	inc	dptr
      00B98A F0               [24] 1417 	movx	@dptr,a
      00B98B 85 4E 82         [24] 1418 	mov	dpl, _vialrgb_get_value_sloc0_1_0
      00B98E 85 4F 83         [24] 1419 	mov	dph, (_vialrgb_get_value_sloc0_1_0 + 1)
                                   1420 ;	quantum/vialrgb.c:187: }
                                   1421 ;	quantum/vialrgb.c:188: }
      00B991 02 B6 B9         [24] 1422 	ljmp	_get_matrix_pos_for_led
                                   1423 ;------------------------------------------------------------
                                   1424 ;Allocation info for local variables in function 'vialrgb_set_value'
                                   1425 ;------------------------------------------------------------
                                   1426 ;sloc0         Allocated with name '_vialrgb_set_value_sloc0_1_0'
                                   1427 ;length        Allocated with name '_vialrgb_set_value_PARM_2'
                                   1428 ;data          Allocated with name '_vialrgb_set_value_data_10000_302'
                                   1429 ;args          Allocated with name '_vialrgb_set_value_args_10001_305'
                                   1430 ;cmd           Allocated with name '_vialrgb_set_value_cmd_10001_305'
                                   1431 ;vialrgb_id    Allocated with name '_vialrgb_set_value_vialrgb_id_40001_308'
                                   1432 ;------------------------------------------------------------
                                   1433 ;	quantum/vialrgb.c:190: void vialrgb_set_value(uint8_t *data, uint8_t length) {
                                   1434 ;	-----------------------------------------
                                   1435 ;	 function vialrgb_set_value
                                   1436 ;	-----------------------------------------
      00B994                       1437 _vialrgb_set_value:
      00B994 12 42 D5         [24] 1438 	lcall	_ak820_outline_0037
      00B997 90 0D B7         [24] 1439 	mov	dptr,#_vialrgb_set_value_data_10000_302
      00B99A 12 37 E4         [24] 1440 	lcall	_ak820_outline_0016
                                   1441 ;	quantum/vialrgb.c:191: if (length != VIAL_RAW_EPSIZE) return;
      00B99D 90 0D B6         [24] 1442 	mov	dptr,#_vialrgb_set_value_PARM_2
      00B9A0 E0               [24] 1443 	movx	a,@dptr
      00B9A1 FF               [12] 1444 	mov	r7,a
      00B9A2 BF 20 02         [24] 1445 	cjne	r7,#0x20,00129$
      00B9A5 80 01            [24] 1446 	sjmp	00102$
      00B9A7                       1447 00129$:
      00B9A7 22               [24] 1448 	ret
      00B9A8                       1449 00102$:
                                   1450 ;	quantum/vialrgb.c:194: uint8_t VIALRGB_BUFFER *args = (uint8_t VIALRGB_BUFFER *)data + 2;
      00B9A8 90 0D B7         [24] 1451 	mov	dptr,#_vialrgb_set_value_data_10000_302
      00B9AB 12 BA 2D         [24] 1452 	lcall	_ak820_outline_0044
                                   1453 ;	quantum/vialrgb.c:195: uint8_t cmd = args[-1];
                                   1454 ;	quantum/vialrgb.c:196: switch (cmd) {
      00B9AE BA 41 02         [24] 1455 	cjne	r2,#0x41,00130$
      00B9B1 80 06            [24] 1456 	sjmp	00103$
      00B9B3                       1457 00130$:
      00B9B3 BA 42 02         [24] 1458 	cjne	r2,#0x42,00131$
      00B9B6 80 5E            [24] 1459 	sjmp	00104$
      00B9B8                       1460 00131$:
      00B9B8 22               [24] 1461 	ret
                                   1462 ;	quantum/vialrgb.c:197: case vialrgb_set_mode: {
      00B9B9                       1463 00103$:
                                   1464 ;	quantum/vialrgb.c:198: uint16_t vialrgb_id = args[0] | (args[1] << 8);
      00B9B9 12 33 FC         [24] 1465 	lcall	_ak820_outline_0126
      00B9BC E0               [24] 1466 	movx	a,@dptr
      00B9BD FA               [12] 1467 	mov	r2,a
      00B9BE 12 BA 25         [24] 1468 	lcall	_ak820_outline_0035
      00B9C1 E0               [24] 1469 	movx	a,@dptr
      00B9C2 F8               [12] 1470 	mov	r0,a
      00B9C3 79 00            [12] 1471 	mov	r1,#0x00
      00B9C5 88 53            [24] 1472 	mov	(_vialrgb_set_value_sloc0_1_0 + 1),r0
      00B9C7 89 52            [24] 1473 	mov	_vialrgb_set_value_sloc0_1_0,r1
      00B9C9 8A 01            [24] 1474 	mov	ar1,r2
      00B9CB 7A 00            [12] 1475 	mov	r2,#0x00
      00B9CD E5 53            [12] 1476 	mov	a,(_vialrgb_set_value_sloc0_1_0 + 1)
      00B9CF 42 02            [12] 1477 	orl	ar2,a
                                   1478 ;	quantum/vialrgb.c:199: set_mode(vialrgb_id);
      00B9D1 89 82            [24] 1479 	mov	dpl, r1
      00B9D3 8A 83            [24] 1480 	mov	dph, r2
      00B9D5 C0 06            [24] 1481 	push	ar6
      00B9D7 C0 05            [24] 1482 	push	ar5
      00B9D9 12 B6 8C         [24] 1483 	lcall	_set_mode
      00B9DC D0 05            [24] 1484 	pop	ar5
      00B9DE D0 06            [24] 1485 	pop	ar6
                                   1486 ;	quantum/vialrgb.c:200: rgb_matrix_set_speed_noeeprom(args[2]);
      00B9E0 12 BA 25         [24] 1487 	lcall	_ak820_outline_0035
      00B9E3 A3               [24] 1488 	inc	dptr
      00B9E4 E0               [24] 1489 	movx	a,@dptr
      00B9E5 F5 82            [12] 1490 	mov	dpl,a
      00B9E7 C0 06            [24] 1491 	push	ar6
      00B9E9 C0 05            [24] 1492 	push	ar5
      00B9EB 12 5A 2B         [24] 1493 	lcall	_rgb_matrix_set_speed_noeeprom
      00B9EE D0 05            [24] 1494 	pop	ar5
      00B9F0 D0 06            [24] 1495 	pop	ar6
                                   1496 ;	quantum/vialrgb.c:201: rgb_matrix_sethsv_noeeprom(args[3], args[4], args[5]);
      00B9F2 12 BA 25         [24] 1497 	lcall	_ak820_outline_0035
      00B9F5 A3               [24] 1498 	inc	dptr
      00B9F6 A3               [24] 1499 	inc	dptr
      00B9F7 E0               [24] 1500 	movx	a,@dptr
      00B9F8 F9               [12] 1501 	mov	r1,a
      00B9F9 7A 00            [12] 1502 	mov	r2,#0x00
      00B9FB 74 06            [12] 1503 	mov	a,#0x06
      00B9FD 12 BA 77         [24] 1504 	lcall	_ak820_outline_0175
      00BA00 F8               [12] 1505 	mov	r0,a
      00BA01 74 07            [12] 1506 	mov	a,#0x07
      00BA03 12 BA 77         [24] 1507 	lcall	_ak820_outline_0175
      00BA06 FE               [12] 1508 	mov	r6,a
      00BA07 90 07 78         [24] 1509 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_2
      00BA0A E8               [12] 1510 	mov	a,r0
      00BA0B F0               [24] 1511 	movx	@dptr,a
      00BA0C 90 07 79         [24] 1512 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_3
      00BA0F EE               [12] 1513 	mov	a,r6
      00BA10 12 91 C7         [24] 1514 	lcall	_ak820_outline_0144
                                   1515 ;	quantum/vialrgb.c:202: break;
                                   1516 ;	quantum/vialrgb.c:205: case vialrgb_direct_fastset: {
      00BA13 02 59 FC         [24] 1517 	ljmp	_rgb_matrix_sethsv_noeeprom
      00BA16                       1518 00104$:
                                   1519 ;	quantum/vialrgb.c:206: fast_set_leds(args, length - 2);
      00BA16 EF               [12] 1520 	mov	a,r7
      00BA17 24 FE            [12] 1521 	add	a,#0xfe
      00BA19 90 0D AC         [24] 1522 	mov	dptr,#_fast_set_leds_PARM_2
      00BA1C 12 A0 B6         [24] 1523 	lcall	_ak820_outline_0124
                                   1524 ;	quantum/vialrgb.c:210: }
                                   1525 ;	quantum/vialrgb.c:211: }
      00BA1F 02 B6 EC         [24] 1526 	ljmp	_fast_set_leds
                                   1527 ;------------------------------------------------------------
                                   1528 ;Allocation info for local variables in function 'vialrgb_save'
                                   1529 ;------------------------------------------------------------
                                   1530 ;length        Allocated with name '_vialrgb_save_PARM_2'
                                   1531 ;data          Allocated with name '_vialrgb_save_data_10000_310'
                                   1532 ;------------------------------------------------------------
                                   1533 ;	quantum/vialrgb.c:213: void vialrgb_save(uint8_t *data, uint8_t length) {
                                   1534 ;	-----------------------------------------
                                   1535 ;	 function vialrgb_save
                                   1536 ;	-----------------------------------------
      00BA22                       1537 _vialrgb_save:
                                   1538 ;	quantum/vialrgb.c:217: eeconfig_update_rgb_matrix();
                                   1539 ;	quantum/vialrgb.c:218: }
      00BA22 02 54 8A         [24] 1540 	ljmp	_eeconfig_update_rgb_matrix
                                   1541 	.area CSEG    (CODE)
                                   1542 	.area CONST   (CODE)
                                   1543 	.area CONST   (CODE)
      00C32E                       1544 _supported_modes:
      00C32E 00                    1545 	.db #0x00	; 0
      00C32F 00                    1546 	.db #0x00	; 0
      00C330 01                    1547 	.db #0x01	; 1
      00C331 05                    1548 	.db #0x05	; 5
      00C332 02                    1549 	.db #0x02	; 2
      00C333 01                    1550 	.db #0x01	; 1
      00C334 06                    1551 	.db #0x06	; 6
      00C335 02                    1552 	.db #0x02	; 2
      00C336 0D                    1553 	.db #0x0d	; 13
      00C337 03                    1554 	.db #0x03	; 3
      00C338 0E                    1555 	.db #0x0e	; 14
      00C339 04                    1556 	.db #0x04	; 4
      00C33A 1F                    1557 	.db #0x1f	; 31
      00C33B 06                    1558 	.db #0x06	; 6
                                   1559 	.area CSEG    (CODE)
                                   1560 	.area XINIT   (CODE)
                                   1561 	.area CABS    (ABS,CODE)
                                   1562 
                                   1563 ; Experimental exact instruction outlining.
                                   1564 	.globl _ak820_outline_0004
                                   1565 	.globl _ak820_outline_0016
                                   1566 	.globl _ak820_outline_0017
                                   1567 	.globl _ak820_outline_0035
                                   1568 	.globl _ak820_outline_0036
                                   1569 	.globl _ak820_outline_0037
                                   1570 	.globl _ak820_outline_0044
                                   1571 	.globl _ak820_outline_0046
                                   1572 	.globl _ak820_outline_0051
                                   1573 	.globl _ak820_outline_0065
                                   1574 	.globl _ak820_outline_0076
                                   1575 	.globl _ak820_outline_0077
                                   1576 	.globl _ak820_outline_0083
                                   1577 	.globl _ak820_outline_0085
                                   1578 	.globl _ak820_outline_0096
                                   1579 	.globl _ak820_outline_0102
                                   1580 	.globl _ak820_outline_0105
                                   1581 	.globl _ak820_outline_0106
                                   1582 	.globl _ak820_outline_0107
                                   1583 	.globl _ak820_outline_0111
                                   1584 	.globl _ak820_outline_0112
                                   1585 	.globl _ak820_outline_0121
                                   1586 	.globl _ak820_outline_0124
                                   1587 	.globl _ak820_outline_0126
                                   1588 	.globl _ak820_outline_0136
                                   1589 	.globl _ak820_outline_0137
                                   1590 	.globl _ak820_outline_0140
                                   1591 	.globl _ak820_outline_0144
                                   1592 	.globl _ak820_outline_0147
                                   1593 	.globl _ak820_outline_0150
                                   1594 	.globl _ak820_outline_0154
                                   1595 	.globl _ak820_outline_0175
                                   1596 	.globl _ak820_outline_0189
                                   1597 	.globl _ak820_outline_0190
                                   1598 
                                   1599 	.area CSEG (CODE)
                                   1600 ; function ak820_outline_0035
      00BA25                       1601 _ak820_outline_0035:
      00BA25 8D 82            [24] 1602 	mov	dpl,r5
      00BA27 8E 83            [24] 1603 	mov	dph,r6
      00BA29 A3               [24] 1604 	inc	dptr
      00BA2A A3               [24] 1605 	inc	dptr
      00BA2B A3               [24] 1606 	inc	dptr
      00BA2C 22               [24] 1607 	ret
                                   1608 
                                   1609 	.area CSEG (CODE)
                                   1610 ; function ak820_outline_0044
      00BA2D                       1611 _ak820_outline_0044:
      00BA2D E0               [24] 1612 	movx	a,@dptr
      00BA2E FD               [12] 1613 	mov	r5,a
      00BA2F A3               [24] 1614 	inc	dptr
      00BA30 E0               [24] 1615 	movx	a,@dptr
      00BA31 FE               [12] 1616 	mov	r6,a
      00BA32 74 02            [12] 1617 	mov	a,#0x02
      00BA34 2D               [12] 1618 	add	a,r5
      00BA35 FB               [12] 1619 	mov	r3,a
      00BA36 E4               [12] 1620 	clr	a
      00BA37 3E               [12] 1621 	addc	a,r6
      00BA38 FC               [12] 1622 	mov	r4,a
      00BA39 8D 82            [24] 1623 	mov	dpl,r5
      00BA3B 8E 83            [24] 1624 	mov	dph,r6
      00BA3D A3               [24] 1625 	inc	dptr
      00BA3E E0               [24] 1626 	movx	a,@dptr
      00BA3F FA               [12] 1627 	mov	r2,a
      00BA40 22               [24] 1628 	ret
                                   1629 
                                   1630 	.area CSEG (CODE)
                                   1631 ; function ak820_outline_0046
      00BA41                       1632 _ak820_outline_0046:
      00BA41 ED               [12] 1633 	mov	a,r5
      00BA42 75 F0 02         [24] 1634 	mov	b,#0x02
      00BA45 A4               [48] 1635 	mul	ab
      00BA46 24 2E            [12] 1636 	add	a,#_supported_modes
      00BA48 FB               [12] 1637 	mov	r3,a
      00BA49 74 C3            [12] 1638 	mov	a,#(_supported_modes>>8)
      00BA4B 35 F0            [12] 1639 	addc	a,b
      00BA4D FC               [12] 1640 	mov	r4,a
      00BA4E 8B 82            [24] 1641 	mov	dpl,r3
      00BA50 8C 83            [24] 1642 	mov	dph,r4
      00BA52 22               [24] 1643 	ret
                                   1644 
                                   1645 	.area CSEG (CODE)
                                   1646 ; function ak820_outline_0083
      00BA53                       1647 _ak820_outline_0083:
      00BA53 90 0D AD         [24] 1648 	mov	dptr,#_fast_set_leds_args_10000_282
      00BA56 E0               [24] 1649 	movx	a,@dptr
      00BA57 F9               [12] 1650 	mov	r1,a
      00BA58 A3               [24] 1651 	inc	dptr
      00BA59 E0               [24] 1652 	movx	a,@dptr
      00BA5A FF               [12] 1653 	mov	r7,a
      00BA5B 89 82            [24] 1654 	mov	dpl,r1
      00BA5D 8F 83            [24] 1655 	mov	dph,r7
      00BA5F E0               [24] 1656 	movx	a,@dptr
      00BA60 22               [24] 1657 	ret
                                   1658 
                                   1659 	.area CSEG (CODE)
                                   1660 ; function ak820_outline_0111
      00BA61                       1661 _ak820_outline_0111:
      00BA61 90 0D AD         [24] 1662 	mov	dptr,#_fast_set_leds_args_10000_282
      00BA64 74 01            [12] 1663 	mov	a,#0x01
      00BA66 29               [12] 1664 	add	a,r1
      00BA67 F0               [24] 1665 	movx	@dptr,a
      00BA68 E4               [12] 1666 	clr	a
      00BA69 3F               [12] 1667 	addc	a,r7
      00BA6A A3               [24] 1668 	inc	dptr
      00BA6B F0               [24] 1669 	movx	@dptr,a
      00BA6C 22               [24] 1670 	ret
                                   1671 
                                   1672 	.area CSEG (CODE)
                                   1673 ; function ak820_outline_0150
      00BA6D                       1674 _ak820_outline_0150:
      00BA6D E4               [12] 1675 	clr	a
      00BA6E 93               [24] 1676 	movc	a,@a+dptr
      00BA6F FC               [12] 1677 	mov	r4,a
      00BA70 7B 00            [12] 1678 	mov	r3,#0x00
      00BA72 8C 82            [24] 1679 	mov	dpl,r4
      00BA74 8B 83            [24] 1680 	mov	dph,r3
      00BA76 22               [24] 1681 	ret
                                   1682 
                                   1683 	.area CSEG (CODE)
                                   1684 ; function ak820_outline_0175
      00BA77                       1685 _ak820_outline_0175:
      00BA77 2D               [12] 1686 	add	a,r5
      00BA78 F5 82            [12] 1687 	mov	dpl,a
      00BA7A E4               [12] 1688 	clr	a
      00BA7B 3E               [12] 1689 	addc	a,r6
      00BA7C F5 83            [12] 1690 	mov	dph,a
      00BA7E E0               [24] 1691 	movx	a,@dptr
      00BA7F 22               [24] 1692 	ret
