                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_tapping
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_settings_tapping_term
                                     12 	.globl _get_repeat_key_count
                                     13 	.globl _del_owned_mods
                                     14 	.globl _add_owned_mods
                                     15 	.globl _send_keyboard_report
                                     16 	.globl _layer_hold_off
                                     17 	.globl _layer_hold_on
                                     18 	.globl _unregister_mods
                                     19 	.globl _register_mods
                                     20 	.globl _process_record
                                     21 	.globl _ADC_START
                                     22 	.globl _S0_R_FIFO
                                     23 	.globl _S0_T_FIFO
                                     24 	.globl _S0_FREE
                                     25 	.globl _S0_IF_BYTE
                                     26 	.globl _S0_IF_FIRST
                                     27 	.globl _S0_IF_OV
                                     28 	.globl _S0_FST_ACT
                                     29 	.globl _CP_RL2
                                     30 	.globl _C_T2
                                     31 	.globl _TR2
                                     32 	.globl _EXEN2
                                     33 	.globl _TCLK
                                     34 	.globl _RCLK
                                     35 	.globl _EXF2
                                     36 	.globl _CAP1F
                                     37 	.globl _TF2
                                     38 	.globl _RI
                                     39 	.globl _TI
                                     40 	.globl _RB8
                                     41 	.globl _TB8
                                     42 	.globl _REN
                                     43 	.globl _SM2
                                     44 	.globl _SM1
                                     45 	.globl _SM0
                                     46 	.globl _IT0
                                     47 	.globl _IE0
                                     48 	.globl _IT1
                                     49 	.globl _IE1
                                     50 	.globl _TR0
                                     51 	.globl _TF0
                                     52 	.globl _TR1
                                     53 	.globl _TF1
                                     54 	.globl _P4_0
                                     55 	.globl _P4_1
                                     56 	.globl _P4_2
                                     57 	.globl _P4_3
                                     58 	.globl _P4_4
                                     59 	.globl _P4_5
                                     60 	.globl _P4_6
                                     61 	.globl _RXD
                                     62 	.globl _TXD
                                     63 	.globl _INT0
                                     64 	.globl _INT1
                                     65 	.globl _T0
                                     66 	.globl _T1
                                     67 	.globl _MOSI1
                                     68 	.globl _MISO1
                                     69 	.globl _SCK1
                                     70 	.globl _P3_0
                                     71 	.globl _P3_1
                                     72 	.globl _P3_2
                                     73 	.globl _P3_3
                                     74 	.globl _P3_4
                                     75 	.globl _P3_5
                                     76 	.globl _P3_6
                                     77 	.globl _P3_7
                                     78 	.globl _CAP1_
                                     79 	.globl _T2_
                                     80 	.globl _CAP2_
                                     81 	.globl _T2EX_
                                     82 	.globl _RXD1
                                     83 	.globl _TXD1
                                     84 	.globl _P2_0
                                     85 	.globl _P2_1
                                     86 	.globl _P2_2
                                     87 	.globl _P2_3
                                     88 	.globl _P2_4
                                     89 	.globl _P2_5
                                     90 	.globl _P2_6
                                     91 	.globl _P2_7
                                     92 	.globl _AIN0
                                     93 	.globl _AIN1
                                     94 	.globl _AIN2
                                     95 	.globl _AIN3
                                     96 	.globl _AIN4
                                     97 	.globl _AIN5
                                     98 	.globl _AIN6
                                     99 	.globl _AIN7
                                    100 	.globl _CAP1
                                    101 	.globl _T2
                                    102 	.globl _CAP2
                                    103 	.globl _T2EX
                                    104 	.globl _INT0_
                                    105 	.globl _SCS
                                    106 	.globl _MOSI
                                    107 	.globl _MISO
                                    108 	.globl _SCK
                                    109 	.globl _RXD1_
                                    110 	.globl _TXD1_
                                    111 	.globl _P1_0
                                    112 	.globl _P1_1
                                    113 	.globl _P1_2
                                    114 	.globl _P1_3
                                    115 	.globl _P1_4
                                    116 	.globl _P1_5
                                    117 	.globl _P1_6
                                    118 	.globl _P1_7
                                    119 	.globl _AIN8
                                    120 	.globl _AIN9
                                    121 	.globl _AIN10
                                    122 	.globl _AIN11
                                    123 	.globl _AIN12
                                    124 	.globl _AIN13
                                    125 	.globl _RXD_
                                    126 	.globl _TXD_
                                    127 	.globl _SCL0
                                    128 	.globl _SDA0
                                    129 	.globl _P0_0
                                    130 	.globl _P0_1
                                    131 	.globl _P0_2
                                    132 	.globl _P0_3
                                    133 	.globl _P0_4
                                    134 	.globl _P0_5
                                    135 	.globl _P0_6
                                    136 	.globl _P0_7
                                    137 	.globl _IE_SPI0
                                    138 	.globl _IE_USB
                                    139 	.globl _IE_ADC
                                    140 	.globl _IE_UART1
                                    141 	.globl _IE_PWM_I2C
                                    142 	.globl _IE_GPIO
                                    143 	.globl _IE_WDOG
                                    144 	.globl _PX0
                                    145 	.globl _PT0
                                    146 	.globl _PX1
                                    147 	.globl _PT1
                                    148 	.globl _PS
                                    149 	.globl _PT2
                                    150 	.globl _PL_FLAG
                                    151 	.globl _PH_FLAG
                                    152 	.globl _EX0
                                    153 	.globl _ET0
                                    154 	.globl _EX1
                                    155 	.globl _ET1
                                    156 	.globl _ES
                                    157 	.globl _ET2
                                    158 	.globl _E_DIS
                                    159 	.globl _EA
                                    160 	.globl _P
                                    161 	.globl _F1
                                    162 	.globl _OV
                                    163 	.globl _RS0
                                    164 	.globl _RS1
                                    165 	.globl _F0
                                    166 	.globl _AC
                                    167 	.globl _CY
                                    168 	.globl _I2CS_INT_ST
                                    169 	.globl _I2CX_INT
                                    170 	.globl _LED_STATUS
                                    171 	.globl _LED_DMA_H
                                    172 	.globl _LED_DMA_L
                                    173 	.globl _LED_DMA
                                    174 	.globl _LED_PWM_OE
                                    175 	.globl _LED_COMMON
                                    176 	.globl _ADC_CHAN
                                    177 	.globl _ADC_DAT_H
                                    178 	.globl _ADC_DAT_L
                                    179 	.globl _ADC_DAT
                                    180 	.globl _ADC_CTRL
                                    181 	.globl _SPI1_CK_SE
                                    182 	.globl _SPI1_CTRL
                                    183 	.globl _SPI1_DATA
                                    184 	.globl _SPI1_STAT
                                    185 	.globl _SIF1
                                    186 	.globl _SBAUD1
                                    187 	.globl _SBUF1
                                    188 	.globl _SCON1
                                    189 	.globl _SPI0_SETUP
                                    190 	.globl _SPI0_CK_SE
                                    191 	.globl _SPI0_CTRL
                                    192 	.globl _SPI0_DATA
                                    193 	.globl _SPI0_STAT
                                    194 	.globl _T2CAP1H
                                    195 	.globl _T2CAP1L
                                    196 	.globl _T2CAP1
                                    197 	.globl _TH2
                                    198 	.globl _TL2
                                    199 	.globl _T2COUNT
                                    200 	.globl _RCAP2H
                                    201 	.globl _RCAP2L
                                    202 	.globl _RCAP2
                                    203 	.globl _T2MOD
                                    204 	.globl _T2CON
                                    205 	.globl _SBUF
                                    206 	.globl _SCON
                                    207 	.globl _TH1
                                    208 	.globl _TH0
                                    209 	.globl _TL1
                                    210 	.globl _TL0
                                    211 	.globl _TMOD
                                    212 	.globl _TCON
                                    213 	.globl _XBUS_AUX
                                    214 	.globl _P7
                                    215 	.globl _P6_DIR
                                    216 	.globl _P6_OUT_PU
                                    217 	.globl _P6_IN
                                    218 	.globl _P5_DIR
                                    219 	.globl _P5_OUT_PU
                                    220 	.globl _P5_IN
                                    221 	.globl _P4_LED_KEY
                                    222 	.globl _P4_DIR_PU
                                    223 	.globl _P4_MOD_OC
                                    224 	.globl _P4
                                    225 	.globl _P3_DIR_PU
                                    226 	.globl _P3_MOD_OC
                                    227 	.globl _P3
                                    228 	.globl _P2_DIR_PU
                                    229 	.globl _P2_MOD_OC
                                    230 	.globl _P2
                                    231 	.globl _P1_DIR_PU
                                    232 	.globl _P1_MOD_OC
                                    233 	.globl _P1
                                    234 	.globl _P0_DIR_PU
                                    235 	.globl _P0_MOD_OC
                                    236 	.globl _P0
                                    237 	.globl _ROM_CTRL
                                    238 	.globl _ROM_DATA_HH
                                    239 	.globl _ROM_DATA_HL
                                    240 	.globl _ROM_DATA_HI
                                    241 	.globl _ROM_ADDR_H
                                    242 	.globl _ROM_ADDR_L
                                    243 	.globl _ROM_ADDR
                                    244 	.globl _GPIO_IE
                                    245 	.globl _IP_EX
                                    246 	.globl _IE_EX
                                    247 	.globl _IP
                                    248 	.globl _IE
                                    249 	.globl _WDOG_COUNT
                                    250 	.globl _RESET_KEEP
                                    251 	.globl _WAKE_CTRL
                                    252 	.globl _CLOCK_CFG
                                    253 	.globl _POWER_CFG
                                    254 	.globl _PCON
                                    255 	.globl _GLOBAL_CFG
                                    256 	.globl _SAFE_MOD
                                    257 	.globl _DPH
                                    258 	.globl _DPL
                                    259 	.globl _SP
                                    260 	.globl _A_INV
                                    261 	.globl _B
                                    262 	.globl _ACC
                                    263 	.globl _PSW
                                    264 	.globl _ak820_oneshot_target
                                    265 	.globl _ak820_oneshot_process_PARM_3
                                    266 	.globl _ak820_oneshot_process_PARM_2
                                    267 	.globl _ak820_oneshot_consumed
                                    268 	.globl _ak820_oneshot_mods
                                    269 	.globl _ak820_tapping_source_PARM_1
                                    270 	.globl _ak820_tapping_source
                                    271 	.globl _ak820_tapping_before
                                    272 	.globl _ak820_tapping_process
                                    273 	.globl _ak820_tapping_cancel
                                    274 	.globl _ak820_oneshot_process
                                    275 ;--------------------------------------------------------
                                    276 ; special function registers
                                    277 ;--------------------------------------------------------
                                    278 	.area RSEG    (ABS,DATA)
      000000                        279 	.org 0x0000
                           0000D0   280 _PSW	=	0x00d0
                           0000E0   281 _ACC	=	0x00e0
                           0000F0   282 _B	=	0x00f0
                           0000FD   283 _A_INV	=	0x00fd
                           000081   284 _SP	=	0x0081
                           000082   285 _DPL	=	0x0082
                           000083   286 _DPH	=	0x0083
                           0000A1   287 _SAFE_MOD	=	0x00a1
                           0000B1   288 _GLOBAL_CFG	=	0x00b1
                           000087   289 _PCON	=	0x0087
                           0000BA   290 _POWER_CFG	=	0x00ba
                           0000B9   291 _CLOCK_CFG	=	0x00b9
                           0000A9   292 _WAKE_CTRL	=	0x00a9
                           0000FE   293 _RESET_KEEP	=	0x00fe
                           0000FF   294 _WDOG_COUNT	=	0x00ff
                           0000A8   295 _IE	=	0x00a8
                           0000B8   296 _IP	=	0x00b8
                           0000E8   297 _IE_EX	=	0x00e8
                           0000E9   298 _IP_EX	=	0x00e9
                           0000B2   299 _GPIO_IE	=	0x00b2
                           008584   300 _ROM_ADDR	=	0x8584
                           000084   301 _ROM_ADDR_L	=	0x0084
                           000085   302 _ROM_ADDR_H	=	0x0085
                           008F8E   303 _ROM_DATA_HI	=	0x8f8e
                           00008E   304 _ROM_DATA_HL	=	0x008e
                           00008F   305 _ROM_DATA_HH	=	0x008f
                           000086   306 _ROM_CTRL	=	0x0086
                           000080   307 _P0	=	0x0080
                           0000C4   308 _P0_MOD_OC	=	0x00c4
                           0000C5   309 _P0_DIR_PU	=	0x00c5
                           000090   310 _P1	=	0x0090
                           000092   311 _P1_MOD_OC	=	0x0092
                           000093   312 _P1_DIR_PU	=	0x0093
                           0000A0   313 _P2	=	0x00a0
                           000094   314 _P2_MOD_OC	=	0x0094
                           000095   315 _P2_DIR_PU	=	0x0095
                           0000B0   316 _P3	=	0x00b0
                           000096   317 _P3_MOD_OC	=	0x0096
                           000097   318 _P3_DIR_PU	=	0x0097
                           0000C0   319 _P4	=	0x00c0
                           0000C2   320 _P4_MOD_OC	=	0x00c2
                           0000C3   321 _P4_DIR_PU	=	0x00c3
                           0000C1   322 _P4_LED_KEY	=	0x00c1
                           0000AA   323 _P5_IN	=	0x00aa
                           0000AB   324 _P5_OUT_PU	=	0x00ab
                           0000AC   325 _P5_DIR	=	0x00ac
                           0000AD   326 _P6_IN	=	0x00ad
                           0000AE   327 _P6_OUT_PU	=	0x00ae
                           0000AF   328 _P6_DIR	=	0x00af
                           0000F1   329 _P7	=	0x00f1
                           0000A2   330 _XBUS_AUX	=	0x00a2
                           000088   331 _TCON	=	0x0088
                           000089   332 _TMOD	=	0x0089
                           00008A   333 _TL0	=	0x008a
                           00008B   334 _TL1	=	0x008b
                           00008C   335 _TH0	=	0x008c
                           00008D   336 _TH1	=	0x008d
                           000098   337 _SCON	=	0x0098
                           000099   338 _SBUF	=	0x0099
                           0000C8   339 _T2CON	=	0x00c8
                           0000C9   340 _T2MOD	=	0x00c9
                           00CBCA   341 _RCAP2	=	0xcbca
                           0000CA   342 _RCAP2L	=	0x00ca
                           0000CB   343 _RCAP2H	=	0x00cb
                           00CDCC   344 _T2COUNT	=	0xcdcc
                           0000CC   345 _TL2	=	0x00cc
                           0000CD   346 _TH2	=	0x00cd
                           00CFCE   347 _T2CAP1	=	0xcfce
                           0000CE   348 _T2CAP1L	=	0x00ce
                           0000CF   349 _T2CAP1H	=	0x00cf
                           0000F8   350 _SPI0_STAT	=	0x00f8
                           0000F9   351 _SPI0_DATA	=	0x00f9
                           0000FA   352 _SPI0_CTRL	=	0x00fa
                           0000FB   353 _SPI0_CK_SE	=	0x00fb
                           0000FC   354 _SPI0_SETUP	=	0x00fc
                           0000BC   355 _SCON1	=	0x00bc
                           0000BD   356 _SBUF1	=	0x00bd
                           0000BE   357 _SBAUD1	=	0x00be
                           0000BF   358 _SIF1	=	0x00bf
                           0000B4   359 _SPI1_STAT	=	0x00b4
                           0000B5   360 _SPI1_DATA	=	0x00b5
                           0000B6   361 _SPI1_CTRL	=	0x00b6
                           0000B7   362 _SPI1_CK_SE	=	0x00b7
                           0000F3   363 _ADC_CTRL	=	0x00f3
                           00F5F4   364 _ADC_DAT	=	0xf5f4
                           0000F4   365 _ADC_DAT_L	=	0x00f4
                           0000F5   366 _ADC_DAT_H	=	0x00f5
                           0000F6   367 _ADC_CHAN	=	0x00f6
                           0000A6   368 _LED_COMMON	=	0x00a6
                           0000A7   369 _LED_PWM_OE	=	0x00a7
                           00C7C6   370 _LED_DMA	=	0xc7c6
                           0000C6   371 _LED_DMA_L	=	0x00c6
                           0000C7   372 _LED_DMA_H	=	0x00c7
                           0000F7   373 _LED_STATUS	=	0x00f7
                           0000B3   374 _I2CX_INT	=	0x00b3
                           0000BB   375 _I2CS_INT_ST	=	0x00bb
                                    376 ;--------------------------------------------------------
                                    377 ; special function bits
                                    378 ;--------------------------------------------------------
                                    379 	.area RSEG    (ABS,DATA)
      000000                        380 	.org 0x0000
                           0000D7   381 _CY	=	0x00d7
                           0000D6   382 _AC	=	0x00d6
                           0000D5   383 _F0	=	0x00d5
                           0000D4   384 _RS1	=	0x00d4
                           0000D3   385 _RS0	=	0x00d3
                           0000D2   386 _OV	=	0x00d2
                           0000D1   387 _F1	=	0x00d1
                           0000D0   388 _P	=	0x00d0
                           0000AF   389 _EA	=	0x00af
                           0000AE   390 _E_DIS	=	0x00ae
                           0000AD   391 _ET2	=	0x00ad
                           0000AC   392 _ES	=	0x00ac
                           0000AB   393 _ET1	=	0x00ab
                           0000AA   394 _EX1	=	0x00aa
                           0000A9   395 _ET0	=	0x00a9
                           0000A8   396 _EX0	=	0x00a8
                           0000BF   397 _PH_FLAG	=	0x00bf
                           0000BE   398 _PL_FLAG	=	0x00be
                           0000BD   399 _PT2	=	0x00bd
                           0000BC   400 _PS	=	0x00bc
                           0000BB   401 _PT1	=	0x00bb
                           0000BA   402 _PX1	=	0x00ba
                           0000B9   403 _PT0	=	0x00b9
                           0000B8   404 _PX0	=	0x00b8
                           0000EF   405 _IE_WDOG	=	0x00ef
                           0000EE   406 _IE_GPIO	=	0x00ee
                           0000ED   407 _IE_PWM_I2C	=	0x00ed
                           0000EC   408 _IE_UART1	=	0x00ec
                           0000EB   409 _IE_ADC	=	0x00eb
                           0000E9   410 _IE_USB	=	0x00e9
                           0000E8   411 _IE_SPI0	=	0x00e8
                           000087   412 _P0_7	=	0x0087
                           000086   413 _P0_6	=	0x0086
                           000085   414 _P0_5	=	0x0085
                           000084   415 _P0_4	=	0x0084
                           000083   416 _P0_3	=	0x0083
                           000082   417 _P0_2	=	0x0082
                           000081   418 _P0_1	=	0x0081
                           000080   419 _P0_0	=	0x0080
                           000081   420 _SDA0	=	0x0081
                           000080   421 _SCL0	=	0x0080
                           000083   422 _TXD_	=	0x0083
                           000082   423 _RXD_	=	0x0082
                           000085   424 _AIN13	=	0x0085
                           000084   425 _AIN12	=	0x0084
                           000083   426 _AIN11	=	0x0083
                           000082   427 _AIN10	=	0x0082
                           000081   428 _AIN9	=	0x0081
                           000080   429 _AIN8	=	0x0080
                           000097   430 _P1_7	=	0x0097
                           000096   431 _P1_6	=	0x0096
                           000095   432 _P1_5	=	0x0095
                           000094   433 _P1_4	=	0x0094
                           000093   434 _P1_3	=	0x0093
                           000092   435 _P1_2	=	0x0092
                           000091   436 _P1_1	=	0x0091
                           000090   437 _P1_0	=	0x0090
                           000097   438 _TXD1_	=	0x0097
                           000096   439 _RXD1_	=	0x0096
                           000097   440 _SCK	=	0x0097
                           000096   441 _MISO	=	0x0096
                           000095   442 _MOSI	=	0x0095
                           000094   443 _SCS	=	0x0094
                           000092   444 _INT0_	=	0x0092
                           000091   445 _T2EX	=	0x0091
                           000091   446 _CAP2	=	0x0091
                           000090   447 _T2	=	0x0090
                           000090   448 _CAP1	=	0x0090
                           000097   449 _AIN7	=	0x0097
                           000096   450 _AIN6	=	0x0096
                           000095   451 _AIN5	=	0x0095
                           000094   452 _AIN4	=	0x0094
                           000093   453 _AIN3	=	0x0093
                           000092   454 _AIN2	=	0x0092
                           000091   455 _AIN1	=	0x0091
                           000090   456 _AIN0	=	0x0090
                           0000A7   457 _P2_7	=	0x00a7
                           0000A6   458 _P2_6	=	0x00a6
                           0000A5   459 _P2_5	=	0x00a5
                           0000A4   460 _P2_4	=	0x00a4
                           0000A3   461 _P2_3	=	0x00a3
                           0000A2   462 _P2_2	=	0x00a2
                           0000A1   463 _P2_1	=	0x00a1
                           0000A0   464 _P2_0	=	0x00a0
                           0000A7   465 _TXD1	=	0x00a7
                           0000A6   466 _RXD1	=	0x00a6
                           0000A5   467 _T2EX_	=	0x00a5
                           0000A5   468 _CAP2_	=	0x00a5
                           0000A4   469 _T2_	=	0x00a4
                           0000A4   470 _CAP1_	=	0x00a4
                           0000B7   471 _P3_7	=	0x00b7
                           0000B6   472 _P3_6	=	0x00b6
                           0000B5   473 _P3_5	=	0x00b5
                           0000B4   474 _P3_4	=	0x00b4
                           0000B3   475 _P3_3	=	0x00b3
                           0000B2   476 _P3_2	=	0x00b2
                           0000B1   477 _P3_1	=	0x00b1
                           0000B0   478 _P3_0	=	0x00b0
                           0000B7   479 _SCK1	=	0x00b7
                           0000B6   480 _MISO1	=	0x00b6
                           0000B5   481 _MOSI1	=	0x00b5
                           0000B5   482 _T1	=	0x00b5
                           0000B4   483 _T0	=	0x00b4
                           0000B3   484 _INT1	=	0x00b3
                           0000B2   485 _INT0	=	0x00b2
                           0000B1   486 _TXD	=	0x00b1
                           0000B0   487 _RXD	=	0x00b0
                           0000C6   488 _P4_6	=	0x00c6
                           0000C5   489 _P4_5	=	0x00c5
                           0000C4   490 _P4_4	=	0x00c4
                           0000C3   491 _P4_3	=	0x00c3
                           0000C2   492 _P4_2	=	0x00c2
                           0000C1   493 _P4_1	=	0x00c1
                           0000C0   494 _P4_0	=	0x00c0
                           00008F   495 _TF1	=	0x008f
                           00008E   496 _TR1	=	0x008e
                           00008D   497 _TF0	=	0x008d
                           00008C   498 _TR0	=	0x008c
                           00008B   499 _IE1	=	0x008b
                           00008A   500 _IT1	=	0x008a
                           000089   501 _IE0	=	0x0089
                           000088   502 _IT0	=	0x0088
                           00009F   503 _SM0	=	0x009f
                           00009E   504 _SM1	=	0x009e
                           00009D   505 _SM2	=	0x009d
                           00009C   506 _REN	=	0x009c
                           00009B   507 _TB8	=	0x009b
                           00009A   508 _RB8	=	0x009a
                           000099   509 _TI	=	0x0099
                           000098   510 _RI	=	0x0098
                           0000CF   511 _TF2	=	0x00cf
                           0000CF   512 _CAP1F	=	0x00cf
                           0000CE   513 _EXF2	=	0x00ce
                           0000CD   514 _RCLK	=	0x00cd
                           0000CC   515 _TCLK	=	0x00cc
                           0000CB   516 _EXEN2	=	0x00cb
                           0000CA   517 _TR2	=	0x00ca
                           0000C9   518 _C_T2	=	0x00c9
                           0000C8   519 _CP_RL2	=	0x00c8
                           0000FF   520 _S0_FST_ACT	=	0x00ff
                           0000FE   521 _S0_IF_OV	=	0x00fe
                           0000FD   522 _S0_IF_FIRST	=	0x00fd
                           0000FC   523 _S0_IF_BYTE	=	0x00fc
                           0000FB   524 _S0_FREE	=	0x00fb
                           0000FA   525 _S0_T_FIFO	=	0x00fa
                           0000F8   526 _S0_R_FIFO	=	0x00f8
                           0000F7   527 _ADC_START	=	0x00f7
                                    528 ;--------------------------------------------------------
                                    529 ; overlayable register banks
                                    530 ;--------------------------------------------------------
                                    531 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        532 	.ds 8
                                    533 ;--------------------------------------------------------
                                    534 ; internal ram data
                                    535 ;--------------------------------------------------------
                                    536 	.area DSEG    (DATA)
                                    537 ;--------------------------------------------------------
                                    538 ; overlayable items in internal ram
                                    539 ;--------------------------------------------------------
                                    540 ;--------------------------------------------------------
                                    541 ; indirectly addressable internal ram data
                                    542 ;--------------------------------------------------------
                                    543 	.area ISEG    (DATA)
                                    544 ;--------------------------------------------------------
                                    545 ; absolute internal ram data
                                    546 ;--------------------------------------------------------
                                    547 	.area IABS    (ABS,DATA)
                                    548 	.area IABS    (ABS,DATA)
                                    549 ;--------------------------------------------------------
                                    550 ; bit data
                                    551 ;--------------------------------------------------------
                                    552 	.area BSEG    (BIT)
      00000D                        553 _ak820_tapping_before_sloc0_1_0:
      00000D                        554 	.ds 1
                                    555 ;--------------------------------------------------------
                                    556 ; paged external ram data
                                    557 ;--------------------------------------------------------
                                    558 	.area PSEG    (PAG,XDATA)
                                    559 ;--------------------------------------------------------
                                    560 ; uninitialized external ram data
                                    561 ;--------------------------------------------------------
                                    562 	.area XSEG    (XDATA)
      0005E6                        563 _source_state:
      0005E6                        564 	.ds 130
      000668                        565 _pending_time:
      000668                        566 	.ds 2
      00066A                        567 _pending_code:
      00066A                        568 	.ds 2
      00066C                        569 _ak820_tapping_source_PARM_1:
      00066C                        570 	.ds 2
      00066E                        571 _hold_PARM_2:
      00066E                        572 	.ds 1
      00066F                        573 _hold_code_10000_625:
      00066F                        574 	.ds 2
      000671                        575 _hold_mods_30000_628:
      000671                        576 	.ds 1
      000672                        577 _commit_pending_id_10000_634:
      000672                        578 	.ds 1
      000673                        579 _ak820_tapping_before_event_10000_635:
      000673                        580 	.ds 2
      000675                        581 _ak820_tapping_process_record_10000_646:
      000675                        582 	.ds 2
      000677                        583 _ak820_tapping_process_code_10000_647:
      000677                        584 	.ds 2
      000679                        585 _ak820_tapping_process_sc_mods_10000_647:
      000679                        586 	.ds 1
      00067A                        587 _ak820_oneshot_mods::
      00067A                        588 	.ds 1
      00067B                        589 _ak820_oneshot_consumed::
      00067B                        590 	.ds 1
      00067C                        591 _ak820_oneshot_process_PARM_2:
      00067C                        592 	.ds 1
      00067D                        593 _ak820_oneshot_process_PARM_3:
      00067D                        594 	.ds 1
      00067E                        595 _ak820_oneshot_process_code_10000_672:
      00067E                        596 	.ds 2
      000680                        597 _ak820_oneshot_process_mods_10000_673:
      000680                        598 	.ds 1
                                    599 ;--------------------------------------------------------
                                    600 ; absolute external ram data
                                    601 ;--------------------------------------------------------
                                    602 	.area XABS    (ABS,XDATA)
                                    603 ;--------------------------------------------------------
                                    604 ; initialized external ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area XISEG   (XDATA)
      000DD5                        607 _pending:
      000DD5                        608 	.ds 1
      000DD6                        609 _ak820_oneshot_target::
      000DD6                        610 	.ds 1
                                    611 	.area HOME    (CODE)
                                    612 	.area GSINIT0 (CODE)
                                    613 	.area GSINIT1 (CODE)
                                    614 	.area GSINIT2 (CODE)
                                    615 	.area GSINIT3 (CODE)
                                    616 	.area GSINIT4 (CODE)
                                    617 	.area GSINIT5 (CODE)
                                    618 	.area GSINIT  (CODE)
                                    619 	.area GSFINAL (CODE)
                                    620 	.area CSEG    (CODE)
                                    621 ;--------------------------------------------------------
                                    622 ; global & static initialisations
                                    623 ;--------------------------------------------------------
                                    624 	.area HOME    (CODE)
                                    625 	.area GSINIT  (CODE)
                                    626 	.area GSFINAL (CODE)
                                    627 	.area GSINIT  (CODE)
                                    628 ;--------------------------------------------------------
                                    629 ; Home
                                    630 ;--------------------------------------------------------
                                    631 	.area HOME    (CODE)
                                    632 	.area HOME    (CODE)
                                    633 ;--------------------------------------------------------
                                    634 ; code
                                    635 ;--------------------------------------------------------
                                    636 	.area CSEG    (CODE)
                                    637 ;------------------------------------------------------------
                                    638 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    639 ;------------------------------------------------------------
                                    640 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    641 ;------------------------------------------------------------
                                    642 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    643 ;	-----------------------------------------
                           000007   644 	ar7 = 0x07
                           000006   645 	ar6 = 0x06
                           000005   646 	ar5 = 0x05
                           000004   647 	ar4 = 0x04
                           000003   648 	ar3 = 0x03
                           000002   649 	ar2 = 0x02
                           000001   650 	ar1 = 0x01
                           000000   651 	ar0 = 0x00
                                    652 ;	 function ak820_tapping_source
                                    653 ;	-----------------------------------------
      004811                        654 _ak820_tapping_source:
                                    655 ;	keyboards/ajazz/ak820/ak820_tapping.c:40: if (key.row < MATRIX_ROWS && key.col < MATRIX_COLS) return key.row * MATRIX_COLS + key.col;
      004811 90 06 6D         [24]  656 	mov	dptr,#(_ak820_tapping_source_PARM_1 + 0x0001)
      004814 E0               [24]  657 	movx	a,@dptr
      004815 FF               [12]  658 	mov	r7,a
      004816 BF 10 00         [24]  659 	cjne	r7,#0x10,00147$
      004819                        660 00147$:
      004819 50 14            [24]  661 	jnc	00102$
      00481B 90 06 6C         [24]  662 	mov	dptr,#_ak820_tapping_source_PARM_1
      00481E E0               [24]  663 	movx	a,@dptr
      00481F FE               [12]  664 	mov	r6,a
      004820 BE 08 00         [24]  665 	cjne	r6,#0x08,00149$
      004823                        666 00149$:
      004823 50 0A            [24]  667 	jnc	00102$
      004825 8F 05            [24]  668 	mov	ar5,r7
      004827 ED               [12]  669 	mov	a,r5
      004828 12 38 8B         [24]  670 	lcall	_ak820_outline_0193
      00482B 2E               [12]  671 	add	a,r6
      00482C F5 82            [12]  672 	mov	dpl,a
      00482E 22               [24]  673 	ret
      00482F                        674 00102$:
                                    675 ;	keyboards/ajazz/ak820/ak820_tapping.c:41: if (key.col < NUM_ENCODERS) {
      00482F 90 06 6C         [24]  676 	mov	dptr,#_ak820_tapping_source_PARM_1
      004832 E0               [24]  677 	movx	a,@dptr
      004833 FE               [12]  678 	mov	r6,a
      004834 BE 01 00         [24]  679 	cjne	r6,#0x01,00151$
      004837                        680 00151$:
      004837 50 0E            [24]  681 	jnc	00109$
                                    682 ;	keyboards/ajazz/ak820/ak820_tapping.c:42: if (key.row == KEYLOC_ENCODER_CW) return MATRIX_ROWS * MATRIX_COLS + key.col;
      004839 BF FD 04         [24]  683 	cjne	r7,#0xfd,00105$
      00483C 75 82 80         [24]  684 	mov	dpl, #0x80
      00483F 22               [24]  685 	ret
      004840                        686 00105$:
                                    687 ;	keyboards/ajazz/ak820/ak820_tapping.c:43: if (key.row == KEYLOC_ENCODER_CCW) return MATRIX_ROWS * MATRIX_COLS + NUM_ENCODERS + key.col;
      004840 BF FC 04         [24]  688 	cjne	r7,#0xfc,00109$
      004843 75 82 81         [24]  689 	mov	dpl, #0x81
      004846 22               [24]  690 	ret
      004847                        691 00109$:
                                    692 ;	keyboards/ajazz/ak820/ak820_tapping.c:45: return NONE;
      004847 75 82 FF         [24]  693 	mov	dpl, #0xff
                                    694 ;	keyboards/ajazz/ak820/ak820_tapping.c:46: }
      00484A 22               [24]  695 	ret
                                    696 ;------------------------------------------------------------
                                    697 ;Allocation info for local variables in function 'hold'
                                    698 ;------------------------------------------------------------
                                    699 ;pressed       Allocated with name '_hold_PARM_2'
                                    700 ;code          Allocated with name '_hold_code_10000_625'
                                    701 ;mods          Allocated with name '_hold_mods_30000_628'
                                    702 ;layer         Allocated with name '_hold_layer_30000_631'
                                    703 ;------------------------------------------------------------
                                    704 ;	keyboards/ajazz/ak820/ak820_tapping.c:47: static void hold(uint16_t code, bool pressed) {
                                    705 ;	-----------------------------------------
                                    706 ;	 function hold
                                    707 ;	-----------------------------------------
      00484B                        708 _hold:
      00484B 12 38 52         [24]  709 	lcall	_ak820_outline_0106
      00484E 90 06 6F         [24]  710 	mov	dptr,#_hold_code_10000_625
      004851 12 38 57         [24]  711 	lcall	_ak820_outline_0107
                                    712 ;	keyboards/ajazz/ak820/ak820_tapping.c:48: if (code < QK_LAYER_TAP) {
      004854 90 06 6F         [24]  713 	mov	dptr,#_hold_code_10000_625
      004857 12 37 D0         [24]  714 	lcall	_ak820_outline_0010
      00485A 74 C0            [12]  715 	mov	a,#0x100 - 0x40
      00485C 2D               [12]  716 	add	a,r5
      00485D 40 2E            [24]  717 	jc	00110$
                                    718 ;	keyboards/ajazz/ak820/ak820_tapping.c:49: uint8_t mods = (code >> 8) & 31;
      00485F 8F 05            [24]  719 	mov	ar5,r7
      004861 53 05 1F         [24]  720 	anl	ar5,#0x1f
      004864 90 06 71         [24]  721 	mov	dptr,#_hold_mods_30000_628
      004867 ED               [12]  722 	mov	a,r5
      004868 F0               [24]  723 	movx	@dptr,a
                                    724 ;	keyboards/ajazz/ak820/ak820_tapping.c:50: if (mods & 16) mods <<= 4;
      004869 ED               [12]  725 	mov	a,r5
      00486A 30 E4 08         [24]  726 	jnb	acc.4,00102$
      00486D ED               [12]  727 	mov	a,r5
      00486E C4               [12]  728 	swap	a
      00486F 54 F0            [12]  729 	anl	a,#0xf0
      004871 90 06 71         [24]  730 	mov	dptr,#_hold_mods_30000_628
      004874 F0               [24]  731 	movx	@dptr,a
      004875                        732 00102$:
                                    733 ;	keyboards/ajazz/ak820/ak820_tapping.c:51: if (pressed) register_mods(mods);
      004875 90 06 6E         [24]  734 	mov	dptr,#_hold_PARM_2
      004878 E0               [24]  735 	movx	a,@dptr
      004879 60 09            [24]  736 	jz	00104$
      00487B 90 06 71         [24]  737 	mov	dptr,#_hold_mods_30000_628
      00487E E0               [24]  738 	movx	a,@dptr
      00487F F5 82            [12]  739 	mov	dpl,a
      004881 02 79 F5         [24]  740 	ljmp	_register_mods
      004884                        741 00104$:
                                    742 ;	keyboards/ajazz/ak820/ak820_tapping.c:52: else unregister_mods(mods);
      004884 90 06 71         [24]  743 	mov	dptr,#_hold_mods_30000_628
      004887 E0               [24]  744 	movx	a,@dptr
      004888 F5 82            [12]  745 	mov	dpl,a
      00488A 02 7A 09         [24]  746 	ljmp	_unregister_mods
      00488D                        747 00110$:
                                    748 ;	keyboards/ajazz/ak820/ak820_tapping.c:54: uint8_t layer = (code >> 8) & 15;
      00488D 8F 06            [24]  749 	mov	ar6,r7
      00488F 74 0F            [12]  750 	mov	a,#0x0f
      004891 5E               [12]  751 	anl	a,r6
      004892 FF               [12]  752 	mov	r7,a
                                    753 ;	keyboards/ajazz/ak820/ak820_tapping.c:55: if (pressed) layer_hold_on(layer);
      004893 90 06 6E         [24]  754 	mov	dptr,#_hold_PARM_2
      004896 E0               [24]  755 	movx	a,@dptr
      004897 60 05            [24]  756 	jz	00107$
      004899 8F 82            [24]  757 	mov	dpl, r7
      00489B 02 7B AE         [24]  758 	ljmp	_layer_hold_on
      00489E                        759 00107$:
                                    760 ;	keyboards/ajazz/ak820/ak820_tapping.c:56: else layer_hold_off(layer);
      00489E 8F 82            [24]  761 	mov	dpl, r7
                                    762 ;	keyboards/ajazz/ak820/ak820_tapping.c:58: }
      0048A0 02 7B E4         [24]  763 	ljmp	_layer_hold_off
                                    764 ;------------------------------------------------------------
                                    765 ;Allocation info for local variables in function 'commit_pending'
                                    766 ;------------------------------------------------------------
                                    767 ;id            Allocated with name '_commit_pending_id_10000_634'
                                    768 ;------------------------------------------------------------
                                    769 ;	keyboards/ajazz/ak820/ak820_tapping.c:59: static void commit_pending(void) {
                                    770 ;	-----------------------------------------
                                    771 ;	 function commit_pending
                                    772 ;	-----------------------------------------
      0048A3                        773 _commit_pending:
                                    774 ;	keyboards/ajazz/ak820/ak820_tapping.c:60: uint8_t id = pending;
      0048A3 90 0D D5         [24]  775 	mov	dptr,#_pending
      0048A6 E0               [24]  776 	movx	a,@dptr
      0048A7 90 06 72         [24]  777 	mov	dptr,#_commit_pending_id_10000_634
      0048AA F0               [24]  778 	movx	@dptr,a
                                    779 ;	keyboards/ajazz/ak820/ak820_tapping.c:61: pending = NONE; /* A report callback cannot resurrect the decision. */
      0048AB 12 4D 1B         [24]  780 	lcall	_ak820_outline_0159
                                    781 ;	keyboards/ajazz/ak820/ak820_tapping.c:62: source_state[id] |= SOURCE_HELD;
      0048AE 90 06 72         [24]  782 	mov	dptr,#_commit_pending_id_10000_634
      0048B1 E0               [24]  783 	movx	a,@dptr
      0048B2 24 E6            [12]  784 	add	a,#_source_state
      0048B4 FF               [12]  785 	mov	r7,a
      0048B5 E4               [12]  786 	clr	a
      0048B6 34 05            [12]  787 	addc	a, #(_source_state >> 8)
      0048B8 FE               [12]  788 	mov	r6,a
      0048B9 12 43 4C         [24]  789 	lcall	_ak820_outline_0161
      0048BC E0               [24]  790 	movx	a,@dptr
      0048BD FD               [12]  791 	mov	r5,a
      0048BE 43 05 04         [24]  792 	orl	ar5,#0x04
      0048C1 12 43 4C         [24]  793 	lcall	_ak820_outline_0161
      0048C4 ED               [12]  794 	mov	a,r5
      0048C5 F0               [24]  795 	movx	@dptr,a
                                    796 ;	keyboards/ajazz/ak820/ak820_tapping.c:63: hold(pending_code, true);
      0048C6 90 06 6A         [24]  797 	mov	dptr,#_pending_code
      0048C9 12 37 FC         [24]  798 	lcall	_ak820_outline_0051
      0048CC 90 06 6E         [24]  799 	mov	dptr,#_hold_PARM_2
      0048CF 12 4C EA         [24]  800 	lcall	_ak820_outline_0055
                                    801 ;	keyboards/ajazz/ak820/ak820_tapping.c:64: }
      0048D2 01 4B            [12]  802 	ajmp	_hold
                                    803 ;------------------------------------------------------------
                                    804 ;Allocation info for local variables in function 'ak820_tapping_before'
                                    805 ;------------------------------------------------------------
                                    806 ;event         Allocated with name '_ak820_tapping_before_event_10000_635'
                                    807 ;id            Allocated with name '_ak820_tapping_before_id_10000_636'
                                    808 ;------------------------------------------------------------
                                    809 ;	keyboards/ajazz/ak820/ak820_tapping.c:65: bool ak820_tapping_before(const keyevent_t AK820_STATE_MEM *event) {
                                    810 ;	-----------------------------------------
                                    811 ;	 function ak820_tapping_before
                                    812 ;	-----------------------------------------
      0048D4                        813 _ak820_tapping_before:
      0048D4 12 38 52         [24]  814 	lcall	_ak820_outline_0106
      0048D7 90 06 73         [24]  815 	mov	dptr,#_ak820_tapping_before_event_10000_635
      0048DA 12 38 57         [24]  816 	lcall	_ak820_outline_0107
                                    817 ;	keyboards/ajazz/ak820/ak820_tapping.c:66: uint8_t id = ak820_tapping_source(event->key);
      0048DD 90 06 73         [24]  818 	mov	dptr,#_ak820_tapping_before_event_10000_635
      0048E0 12 37 D0         [24]  819 	lcall	_ak820_outline_0010
      0048E3 12 4C D0         [24]  820 	lcall	_ak820_outline_0024
      0048E6 C0 07            [24]  821 	push	ar7
      0048E8 C0 06            [24]  822 	push	ar6
      0048EA 12 BB 20         [24]  823 	lcall	___memcpy
      0048ED 11 11            [12]  824 	acall	_ak820_tapping_source
      0048EF AD 82            [24]  825 	mov	r5, dpl
      0048F1 D0 06            [24]  826 	pop	ar6
      0048F3 D0 07            [24]  827 	pop	ar7
                                    828 ;	keyboards/ajazz/ak820/ak820_tapping.c:68: if (vial_unlock_in_progress) {
      0048F5 90 0E 46         [24]  829 	mov	dptr,#_vial_unlock_in_progress
      0048F8 E0               [24]  830 	movx	a,@dptr
      0048F9 60 29            [24]  831 	jz	00106$
                                    832 ;	keyboards/ajazz/ak820/ak820_tapping.c:69: if (IS_EVENT(*event) && id != NONE && !event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      0048FB 74 04            [12]  833 	mov	a,#0x04
      0048FD 12 4C AB         [24]  834 	lcall	_ak820_outline_0012
      004900 60 1E            [24]  835 	jz	00102$
      004902 BD FF 02         [24]  836 	cjne	r5,#0xff,00218$
      004905 80 19            [24]  837 	sjmp	00102$
      004907                        838 00218$:
      004907 74 05            [12]  839 	mov	a,#0x05
      004909 12 4C AB         [24]  840 	lcall	_ak820_outline_0012
      00490C 70 12            [24]  841 	jnz	00102$
      00490E ED               [12]  842 	mov	a,r5
      00490F 24 E6            [12]  843 	add	a, #_source_state
      004911 FB               [12]  844 	mov	r3,a
      004912 E4               [12]  845 	clr	a
      004913 34 05            [12]  846 	addc	a, #(_source_state >> 8)
      004915 12 4C F2         [24]  847 	lcall	_ak820_outline_0056
      004918 53 02 FD         [24]  848 	anl	ar2,#0xfd
      00491B 12 33 FC         [24]  849 	lcall	_ak820_outline_0126
      00491E EA               [12]  850 	mov	a,r2
      00491F F0               [24]  851 	movx	@dptr,a
      004920                        852 00102$:
                                    853 ;	keyboards/ajazz/ak820/ak820_tapping.c:70: return false;
      004920 75 82 00         [24]  854 	mov	dpl, #0x00
      004923 22               [24]  855 	ret
      004924                        856 00106$:
                                    857 ;	keyboards/ajazz/ak820/ak820_tapping.c:73: if (pending != NONE && ((uint16_t)(event->time - pending_time) >= AK820_TAPPING_TERM ||
      004924 90 0D D5         [24]  858 	mov	dptr,#_pending
      004927 E0               [24]  859 	movx	a,@dptr
      004928 FC               [12]  860 	mov	r4,a
      004929 BC FF 02         [24]  861 	cjne	r4,#0xff,00220$
      00492C 80 59            [24]  862 	sjmp	00108$
      00492E                        863 00220$:
      00492E 12 37 F4         [24]  864 	lcall	_ak820_outline_0034
      004931 FB               [12]  865 	mov	r3,a
      004932 A3               [24]  866 	inc	dptr
      004933 E0               [24]  867 	movx	a,@dptr
      004934 FC               [12]  868 	mov	r4,a
      004935 90 06 68         [24]  869 	mov	dptr,#_pending_time
      004938 E0               [24]  870 	movx	a,@dptr
      004939 F9               [12]  871 	mov	r1,a
      00493A A3               [24]  872 	inc	dptr
      00493B E0               [24]  873 	movx	a,@dptr
      00493C FA               [12]  874 	mov	r2,a
      00493D EB               [12]  875 	mov	a,r3
      00493E C3               [12]  876 	clr	c
      00493F 99               [12]  877 	subb	a,r1
      004940 FB               [12]  878 	mov	r3,a
      004941 EC               [12]  879 	mov	a,r4
      004942 9A               [12]  880 	subb	a,r2
      004943 FC               [12]  881 	mov	r4,a
      004944 C0 07            [24]  882 	push	ar7
      004946 C0 06            [24]  883 	push	ar6
      004948 C0 05            [24]  884 	push	ar5
      00494A C0 04            [24]  885 	push	ar4
      00494C C0 03            [24]  886 	push	ar3
      00494E 12 47 B1         [24]  887 	lcall	_ak820_settings_tapping_term
      004951 12 4D 22         [24]  888 	lcall	_ak820_outline_0189
      004954 D0 03            [24]  889 	pop	ar3
      004956 D0 04            [24]  890 	pop	ar4
      004958 D0 05            [24]  891 	pop	ar5
      00495A D0 06            [24]  892 	pop	ar6
      00495C D0 07            [24]  893 	pop	ar7
      00495E C3               [12]  894 	clr	c
      00495F EB               [12]  895 	mov	a,r3
      004960 99               [12]  896 	subb	a,r1
      004961 EC               [12]  897 	mov	a,r4
      004962 9A               [12]  898 	subb	a,r2
      004963 50 1C            [24]  899 	jnc	00107$
                                    900 ;	keyboards/ajazz/ak820/ak820_tapping.c:74: (IS_EVENT(*event) && event->pressed && (id == NONE || id != pending)))) commit_pending();
      004965 74 04            [12]  901 	mov	a,#0x04
      004967 12 4C AB         [24]  902 	lcall	_ak820_outline_0012
      00496A 60 1B            [24]  903 	jz	00108$
      00496C 12 37 AF         [24]  904 	lcall	_ak820_outline_0005
      00496F 60 16            [24]  905 	jz	00108$
      004971 BD FF 02         [24]  906 	cjne	r5,#0xff,00224$
      004974 80 0B            [24]  907 	sjmp	00107$
      004976                        908 00224$:
      004976 90 0D D5         [24]  909 	mov	dptr,#_pending
      004979 E0               [24]  910 	movx	a,@dptr
      00497A FF               [12]  911 	mov	r7,a
      00497B ED               [12]  912 	mov	a,r5
      00497C B5 07 02         [24]  913 	cjne	a,ar7,00225$
      00497F 80 06            [24]  914 	sjmp	00108$
      004981                        915 00225$:
      004981                        916 00107$:
      004981 C0 05            [24]  917 	push	ar5
      004983 11 A3            [12]  918 	acall	_commit_pending
      004985 D0 05            [24]  919 	pop	ar5
      004987                        920 00108$:
                                    921 ;	keyboards/ajazz/ak820/ak820_tapping.c:75: if (IS_NOEVENT(*event) || id == NONE) return true;
      004987 90 06 73         [24]  922 	mov	dptr,#_ak820_tapping_before_event_10000_635
      00498A 12 37 FC         [24]  923 	lcall	_ak820_outline_0051
      00498D 74 04            [12]  924 	mov	a,#0x04
      00498F 12 4C AB         [24]  925 	lcall	_ak820_outline_0012
      004992 60 03            [24]  926 	jz	00114$
      004994 BD FF 04         [24]  927 	cjne	r5,#0xff,00115$
      004997                        928 00114$:
      004997 75 82 01         [24]  929 	mov	dpl, #0x01
      00499A 22               [24]  930 	ret
      00499B                        931 00115$:
                                    932 ;	keyboards/ajazz/ak820/ak820_tapping.c:76: if ((source_state[id] & SOURCE_BLOCKED)) {
      00499B ED               [12]  933 	mov	a,r5
      00499C 12 4D 07         [24]  934 	lcall	_ak820_outline_0079
      00499F 30 E1 13         [24]  935 	jnb	acc.1,00120$
                                    936 ;	keyboards/ajazz/ak820/ak820_tapping.c:77: if (!event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      0049A2 74 05            [12]  937 	mov	a,#0x05
      0049A4 2E               [12]  938 	add	a, r6
      0049A5 12 37 DA         [24]  939 	lcall	_ak820_outline_0014
      0049A8 70 07            [24]  940 	jnz	00118$
      0049AA 74 FD            [12]  941 	mov	a,#0xfd
      0049AC 5B               [12]  942 	anl	a,r3
      0049AD 12 38 5C         [24]  943 	lcall	_ak820_outline_0125
      0049B0 F0               [24]  944 	movx	@dptr,a
      0049B1                        945 00118$:
                                    946 ;	keyboards/ajazz/ak820/ak820_tapping.c:78: return false;
      0049B1 75 82 00         [24]  947 	mov	dpl, #0x00
      0049B4 22               [24]  948 	ret
      0049B5                        949 00120$:
                                    950 ;	keyboards/ajazz/ak820/ak820_tapping.c:81: if (event->pressed == ((source_state[id] & SOURCE_ACTIVE) != 0)) return false;
      0049B5 12 42 C3         [24]  951 	lcall	_ak820_outline_0011
      0049B8 E0               [24]  952 	movx	a,@dptr
      0049B9 FF               [12]  953 	mov	r7,a
      0049BA 8B 06            [24]  954 	mov	ar6,r3
      0049BC 53 06 01         [24]  955 	anl	ar6,#0x01
      0049BF EE               [12]  956 	mov	a,r6
      0049C0 B4 01 00         [24]  957 	cjne	a,#0x01,00231$
      0049C3                        958 00231$:
      0049C3 B3               [12]  959 	cpl	c
      0049C4 92 0D            [24]  960 	mov	_ak820_tapping_before_sloc0_1_0,c
      0049C6 8F F0            [24]  961 	mov	b,r7
      0049C8 E4               [12]  962 	clr	a
      0049C9 33               [12]  963 	rlc	a
      0049CA B5 F0 04         [24]  964 	cjne	a,b,00122$
      0049CD 75 82 00         [24]  965 	mov	dpl, #0x00
      0049D0 22               [24]  966 	ret
      0049D1                        967 00122$:
                                    968 ;	keyboards/ajazz/ak820/ak820_tapping.c:82: source_state[id] ^= SOURCE_ACTIVE;
      0049D1 63 03 01         [24]  969 	xrl	ar3,#0x01
      0049D4 12 38 5C         [24]  970 	lcall	_ak820_outline_0125
      0049D7 EB               [12]  971 	mov	a,r3
      0049D8 F0               [24]  972 	movx	@dptr,a
                                    973 ;	keyboards/ajazz/ak820/ak820_tapping.c:83: return true;
      0049D9 75 82 01         [24]  974 	mov	dpl, #0x01
                                    975 ;	keyboards/ajazz/ak820/ak820_tapping.c:84: }
      0049DC 22               [24]  976 	ret
                                    977 ;------------------------------------------------------------
                                    978 ;Allocation info for local variables in function 'ak820_tapping_process'
                                    979 ;------------------------------------------------------------
                                    980 ;record        Allocated with name '_ak820_tapping_process_record_10000_646'
                                    981 ;id            Allocated with name '_ak820_tapping_process_id_10000_647'
                                    982 ;kind          Allocated with name '_ak820_tapping_process_kind_10000_647'
                                    983 ;code          Allocated with name '_ak820_tapping_process_code_10000_647'
                                    984 ;sc_mods       Allocated with name '_ak820_tapping_process_sc_mods_10000_647'
                                    985 ;------------------------------------------------------------
                                    986 ;	keyboards/ajazz/ak820/ak820_tapping.c:85: bool ak820_tapping_process(keyrecord_t AK820_STATE_MEM *record) {
                                    987 ;	-----------------------------------------
                                    988 ;	 function ak820_tapping_process
                                    989 ;	-----------------------------------------
      0049DD                        990 _ak820_tapping_process:
      0049DD 12 38 52         [24]  991 	lcall	_ak820_outline_0106
      0049E0 90 06 75         [24]  992 	mov	dptr,#_ak820_tapping_process_record_10000_646
      0049E3 12 38 57         [24]  993 	lcall	_ak820_outline_0107
                                    994 ;	keyboards/ajazz/ak820/ak820_tapping.c:89: uint8_t sc_mods = 0;
      0049E6 90 06 79         [24]  995 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_647
      0049E9 E4               [12]  996 	clr	a
      0049EA F0               [24]  997 	movx	@dptr,a
                                    998 ;	keyboards/ajazz/ak820/ak820_tapping.c:91: if (IS_NOEVENT(record->event)) return true;
      0049EB 90 06 75         [24]  999 	mov	dptr,#_ak820_tapping_process_record_10000_646
      0049EE 12 37 FC         [24] 1000 	lcall	_ak820_outline_0051
      0049F1 74 04            [12] 1001 	mov	a,#0x04
      0049F3 12 4C B6         [24] 1002 	lcall	_ak820_outline_0013
      0049F6 70 04            [24] 1003 	jnz	00102$
      0049F8 75 82 01         [24] 1004 	mov	dpl, #0x01
      0049FB 22               [24] 1005 	ret
      0049FC                       1006 00102$:
                                   1007 ;	keyboards/ajazz/ak820/ak820_tapping.c:92: id = ak820_tapping_source(record->event.key);
      0049FC 8E 04            [24] 1008 	mov	ar4,r6
      0049FE 8F 05            [24] 1009 	mov	ar5,r7
      004A00 12 4C D0         [24] 1010 	lcall	_ak820_outline_0024
      004A03 C0 07            [24] 1011 	push	ar7
      004A05 C0 06            [24] 1012 	push	ar6
      004A07 12 BB 20         [24] 1013 	lcall	___memcpy
      004A0A 11 11            [12] 1014 	acall	_ak820_tapping_source
      004A0C AD 82            [24] 1015 	mov	r5, dpl
      004A0E D0 06            [24] 1016 	pop	ar6
      004A10 D0 07            [24] 1017 	pop	ar7
                                   1018 ;	keyboards/ajazz/ak820/ak820_tapping.c:93: if (id == NONE) return true;
      004A12 BD FF 04         [24] 1019 	cjne	r5,#0xff,00104$
      004A15 75 82 01         [24] 1020 	mov	dpl, #0x01
      004A18 22               [24] 1021 	ret
      004A19                       1022 00104$:
                                   1023 ;	keyboards/ajazz/ak820/ak820_tapping.c:94: code = record->keycode;
      004A19 74 07            [12] 1024 	mov	a,#0x07
      004A1B 12 37 EC         [24] 1025 	lcall	_ak820_outline_0017
      004A1E 12 37 FC         [24] 1026 	lcall	_ak820_outline_0051
      004A21 90 06 77         [24] 1027 	mov	dptr,#_ak820_tapping_process_code_10000_647
      004A24 12 4C FA         [24] 1028 	lcall	_ak820_outline_0060
                                   1029 ;	keyboards/ajazz/ak820/ak820_tapping.c:96: if (code == SC_LSPO) { code = MT(MOD_LSFT, KC_9); sc_mods = MOD_BIT(KC_LEFT_SHIFT); }
      004A27 BE 1A 15         [24] 1030 	cjne	r6,#0x1a,00111$
      004A2A BF 7C 12         [24] 1031 	cjne	r7,#0x7c,00111$
      004A2D 90 06 77         [24] 1032 	mov	dptr,#_ak820_tapping_process_code_10000_647
      004A30 74 26            [12] 1033 	mov	a,#0x26
      004A32 F0               [24] 1034 	movx	@dptr,a
      004A33 74 22            [12] 1035 	mov	a,#0x22
      004A35 A3               [24] 1036 	inc	dptr
      004A36 F0               [24] 1037 	movx	@dptr,a
      004A37 90 06 79         [24] 1038 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_647
      004A3A 74 02            [12] 1039 	mov	a,#0x02
      004A3C F0               [24] 1040 	movx	@dptr,a
      004A3D 80 28            [24] 1041 	sjmp	00112$
      004A3F                       1042 00111$:
                                   1043 ;	keyboards/ajazz/ak820/ak820_tapping.c:97: else if (code == SC_RSPC) { code = MT(MOD_RSFT, KC_0); sc_mods = MOD_BIT(KC_RIGHT_SHIFT); }
      004A3F BE 1B 15         [24] 1044 	cjne	r6,#0x1b,00108$
      004A42 BF 7C 12         [24] 1045 	cjne	r7,#0x7c,00108$
      004A45 90 06 77         [24] 1046 	mov	dptr,#_ak820_tapping_process_code_10000_647
      004A48 74 27            [12] 1047 	mov	a,#0x27
      004A4A F0               [24] 1048 	movx	@dptr,a
      004A4B 74 32            [12] 1049 	mov	a,#0x32
      004A4D A3               [24] 1050 	inc	dptr
      004A4E F0               [24] 1051 	movx	@dptr,a
      004A4F 90 06 79         [24] 1052 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_647
      004A52 74 20            [12] 1053 	mov	a,#0x20
      004A54 F0               [24] 1054 	movx	@dptr,a
      004A55 80 10            [24] 1055 	sjmp	00112$
      004A57                       1056 00108$:
                                   1057 ;	keyboards/ajazz/ak820/ak820_tapping.c:98: else if (code == SC_SENT) code = MT(MOD_RSFT, KC_ENTER);
      004A57 BE 1E 0D         [24] 1058 	cjne	r6,#0x1e,00112$
      004A5A BF 7C 0A         [24] 1059 	cjne	r7,#0x7c,00112$
      004A5D 90 06 77         [24] 1060 	mov	dptr,#_ak820_tapping_process_code_10000_647
      004A60 74 28            [12] 1061 	mov	a,#0x28
      004A62 F0               [24] 1062 	movx	@dptr,a
      004A63 74 32            [12] 1063 	mov	a,#0x32
      004A65 A3               [24] 1064 	inc	dptr
      004A66 F0               [24] 1065 	movx	@dptr,a
      004A67                       1066 00112$:
                                   1067 ;	keyboards/ajazz/ak820/ak820_tapping.c:100: kind = code >> 8;
      004A67 90 06 77         [24] 1068 	mov	dptr,#_ak820_tapping_process_code_10000_647
      004A6A E0               [24] 1069 	movx	a,@dptr
      004A6B A3               [24] 1070 	inc	dptr
      004A6C E0               [24] 1071 	movx	a,@dptr
      004A6D FF               [12] 1072 	mov	r7,a
                                   1073 ;	keyboards/ajazz/ak820/ak820_tapping.c:101: if (kind < 0x20 || kind >= 0x50) return true;
      004A6E BF 20 00         [24] 1074 	cjne	r7,#0x20,00242$
      004A71                       1075 00242$:
      004A71 40 05            [24] 1076 	jc	00113$
      004A73 BF 50 00         [24] 1077 	cjne	r7,#0x50,00244$
      004A76                       1078 00244$:
      004A76 40 04            [24] 1079 	jc	00114$
      004A78                       1080 00113$:
      004A78 75 82 01         [24] 1081 	mov	dpl, #0x01
      004A7B 22               [24] 1082 	ret
      004A7C                       1083 00114$:
                                   1084 ;	keyboards/ajazz/ak820/ak820_tapping.c:102: if (kind >= 0x40 && (kind & 15) >= MAX_LAYER) return false;
      004A7C BF 40 00         [24] 1085 	cjne	r7,#0x40,00246$
      004A7F                       1086 00246$:
      004A7F 40 0C            [24] 1087 	jc	00117$
      004A81 53 07 0F         [24] 1088 	anl	ar7,#0x0f
      004A84 BF 06 00         [24] 1089 	cjne	r7,#0x06,00248$
      004A87                       1090 00248$:
      004A87 40 04            [24] 1091 	jc	00117$
      004A89 75 82 00         [24] 1092 	mov	dpl, #0x00
      004A8C 22               [24] 1093 	ret
      004A8D                       1094 00117$:
                                   1095 ;	keyboards/ajazz/ak820/ak820_tapping.c:103: if (record->event.pressed) {
      004A8D 90 06 75         [24] 1096 	mov	dptr,#_ak820_tapping_process_record_10000_646
      004A90 12 37 FC         [24] 1097 	lcall	_ak820_outline_0051
      004A93 74 05            [12] 1098 	mov	a,#0x05
      004A95 12 4C AB         [24] 1099 	lcall	_ak820_outline_0012
      004A98 60 1E            [24] 1100 	jz	00131$
                                   1101 ;	keyboards/ajazz/ak820/ak820_tapping.c:104: pending = id;
      004A9A 90 0D D5         [24] 1102 	mov	dptr,#_pending
      004A9D ED               [12] 1103 	mov	a,r5
      004A9E 12 42 CD         [24] 1104 	lcall	_ak820_outline_0031
                                   1105 ;	keyboards/ajazz/ak820/ak820_tapping.c:105: pending_time = record->event.time;
      004AA1 12 37 FC         [24] 1106 	lcall	_ak820_outline_0051
      004AA4 90 06 68         [24] 1107 	mov	dptr,#_pending_time
      004AA7 12 4C FA         [24] 1108 	lcall	_ak820_outline_0060
                                   1109 ;	keyboards/ajazz/ak820/ak820_tapping.c:106: pending_code = code;
      004AAA 90 06 77         [24] 1110 	mov	dptr,#_ak820_tapping_process_code_10000_647
      004AAD 12 37 FC         [24] 1111 	lcall	_ak820_outline_0051
      004AB0 90 06 6A         [24] 1112 	mov	dptr,#_pending_code
      004AB3 12 4C FA         [24] 1113 	lcall	_ak820_outline_0060
      004AB6 61 52            [12] 1114 	ajmp	00132$
      004AB8                       1115 00131$:
                                   1116 ;	keyboards/ajazz/ak820/ak820_tapping.c:107: } else if (id == pending) {
      004AB8 90 0D D5         [24] 1117 	mov	dptr,#_pending
      004ABB E0               [24] 1118 	movx	a,@dptr
      004ABC FF               [12] 1119 	mov	r7,a
      004ABD ED               [12] 1120 	mov	a,r5
      004ABE B5 07 02         [24] 1121 	cjne	a,ar7,00251$
      004AC1 80 02            [24] 1122 	sjmp	00252$
      004AC3                       1123 00251$:
      004AC3 61 2C            [12] 1124 	ajmp	00128$
      004AC5                       1125 00252$:
                                   1126 ;	keyboards/ajazz/ak820/ak820_tapping.c:108: pending = NONE;
      004AC5 12 4D 1B         [24] 1127 	lcall	_ak820_outline_0159
                                   1128 ;	keyboards/ajazz/ak820/ak820_tapping.c:110: if (sc_mods) add_owned_mods(sc_mods);
      004AC8 90 06 79         [24] 1129 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_647
      004ACB E0               [24] 1130 	movx	a,@dptr
      004ACC FF               [12] 1131 	mov	r7,a
      004ACD E0               [24] 1132 	movx	a,@dptr
      004ACE 60 05            [24] 1133 	jz	00120$
      004AD0 8F 82            [24] 1134 	mov	dpl, r7
      004AD2 12 80 1E         [24] 1135 	lcall	_add_owned_mods
      004AD5                       1136 00120$:
                                   1137 ;	keyboards/ajazz/ak820/ak820_tapping.c:114: record->keycode = (uint8_t)code;
      004AD5 90 06 75         [24] 1138 	mov	dptr,#_ak820_tapping_process_record_10000_646
      004AD8 12 37 FC         [24] 1139 	lcall	_ak820_outline_0051
      004ADB 74 07            [12] 1140 	mov	a,#0x07
      004ADD 2E               [12] 1141 	add	a, r6
      004ADE FB               [12] 1142 	mov	r3,a
      004ADF E4               [12] 1143 	clr	a
      004AE0 3F               [12] 1144 	addc	a, r7
      004AE1 FC               [12] 1145 	mov	r4,a
      004AE2 90 06 77         [24] 1146 	mov	dptr,#_ak820_tapping_process_code_10000_647
      004AE5 E0               [24] 1147 	movx	a,@dptr
      004AE6 F9               [12] 1148 	mov	r1,a
      004AE7 7A 00            [12] 1149 	mov	r2,#0x00
      004AE9 12 33 FC         [24] 1150 	lcall	_ak820_outline_0126
      004AEC 12 4D 15         [24] 1151 	lcall	_ak820_outline_0139
                                   1152 ;	keyboards/ajazz/ak820/ak820_tapping.c:115: if (record->keycode > KC_TRANSPARENT) {
      004AEF C3               [12] 1153 	clr	c
      004AF0 04               [12] 1154 	inc	a
      004AF1 99               [12] 1155 	subb	a,r1
      004AF2 50 26            [24] 1156 	jnc	00122$
                                   1157 ;	free result
                                   1158 ;	keyboards/ajazz/ak820/ak820_tapping.c:116: record->tap.count = 1;
      004AF4 74 06            [12] 1159 	mov	a,#0x06
      004AF6 12 37 EC         [24] 1160 	lcall	_ak820_outline_0017
      004AF9 E0               [24] 1161 	movx	a,@dptr
      004AFA 54 0F            [12] 1162 	anl	a,#0x0f
      004AFC 44 10            [12] 1163 	orl	a,#0x10
      004AFE F0               [24] 1164 	movx	@dptr,a
                                   1165 ;	keyboards/ajazz/ak820/ak820_tapping.c:117: record->event.pressed = true;
      004AFF 12 42 C3         [24] 1166 	lcall	_ak820_outline_0011
      004B02 12 4C EA         [24] 1167 	lcall	_ak820_outline_0055
                                   1168 ;	keyboards/ajazz/ak820/ak820_tapping.c:118: process_record(record);
      004B05 12 74 BB         [24] 1169 	lcall	_process_record
                                   1170 ;	keyboards/ajazz/ak820/ak820_tapping.c:119: record->event.pressed = false;
      004B08 90 06 75         [24] 1171 	mov	dptr,#_ak820_tapping_process_record_10000_646
      004B0B 12 37 A5         [24] 1172 	lcall	_ak820_outline_0004
      004B0E A3               [24] 1173 	inc	dptr
      004B0F A3               [24] 1174 	inc	dptr
      004B10 A3               [24] 1175 	inc	dptr
      004B11 A3               [24] 1176 	inc	dptr
      004B12 A3               [24] 1177 	inc	dptr
      004B13 E4               [12] 1178 	clr	a
      004B14 12 42 F9         [24] 1179 	lcall	_ak820_outline_0061
                                   1180 ;	keyboards/ajazz/ak820/ak820_tapping.c:120: process_record(record);
      004B17 12 74 BB         [24] 1181 	lcall	_process_record
      004B1A                       1182 00122$:
                                   1183 ;	keyboards/ajazz/ak820/ak820_tapping.c:123: if (sc_mods) {
      004B1A 90 06 79         [24] 1184 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_647
      004B1D E0               [24] 1185 	movx	a,@dptr
      004B1E FF               [12] 1186 	mov	r7,a
      004B1F E0               [24] 1187 	movx	a,@dptr
      004B20 60 30            [24] 1188 	jz	00132$
                                   1189 ;	keyboards/ajazz/ak820/ak820_tapping.c:124: del_owned_mods(sc_mods);
      004B22 8F 82            [24] 1190 	mov	dpl, r7
      004B24 12 80 2E         [24] 1191 	lcall	_del_owned_mods
                                   1192 ;	keyboards/ajazz/ak820/ak820_tapping.c:125: send_keyboard_report();
      004B27 12 83 57         [24] 1193 	lcall	_send_keyboard_report
      004B2A 80 26            [24] 1194 	sjmp	00132$
      004B2C                       1195 00128$:
                                   1196 ;	keyboards/ajazz/ak820/ak820_tapping.c:128: } else if ((source_state[id] & SOURCE_HELD)) {
      004B2C ED               [12] 1197 	mov	a,r5
      004B2D 24 E6            [12] 1198 	add	a, #_source_state
      004B2F FE               [12] 1199 	mov	r6,a
      004B30 E4               [12] 1200 	clr	a
      004B31 34 05            [12] 1201 	addc	a, #(_source_state >> 8)
      004B33 FF               [12] 1202 	mov	r7,a
      004B34 12 38 3A         [24] 1203 	lcall	_ak820_outline_0100
      004B37 FD               [12] 1204 	mov	r5,a
      004B38 30 E2 17         [24] 1205 	jnb	acc.2,00132$
                                   1206 ;	keyboards/ajazz/ak820/ak820_tapping.c:129: source_state[id] &= ~SOURCE_HELD;
      004B3B 53 05 FB         [24] 1207 	anl	ar5,#0xfb
      004B3E 12 43 2B         [24] 1208 	lcall	_ak820_outline_0121
      004B41 ED               [12] 1209 	mov	a,r5
      004B42 F0               [24] 1210 	movx	@dptr,a
                                   1211 ;	keyboards/ajazz/ak820/ak820_tapping.c:130: hold(code, false);
      004B43 90 06 77         [24] 1212 	mov	dptr,#_ak820_tapping_process_code_10000_647
      004B46 12 37 FC         [24] 1213 	lcall	_ak820_outline_0051
      004B49 90 06 6E         [24] 1214 	mov	dptr,#_hold_PARM_2
      004B4C E4               [12] 1215 	clr	a
      004B4D 12 42 F9         [24] 1216 	lcall	_ak820_outline_0061
      004B50 11 4B            [12] 1217 	acall	_hold
      004B52                       1218 00132$:
                                   1219 ;	keyboards/ajazz/ak820/ak820_tapping.c:132: return false;
      004B52 75 82 00         [24] 1220 	mov	dpl, #0x00
                                   1221 ;	keyboards/ajazz/ak820/ak820_tapping.c:133: }
      004B55 22               [24] 1222 	ret
                                   1223 ;------------------------------------------------------------
                                   1224 ;Allocation info for local variables in function 'ak820_tapping_cancel'
                                   1225 ;------------------------------------------------------------
                                   1226 ;i             Allocated with name '_ak820_tapping_cancel_i_20000_670'
                                   1227 ;state         Allocated with name '_ak820_tapping_cancel_state_30000_671'
                                   1228 ;------------------------------------------------------------
                                   1229 ;	keyboards/ajazz/ak820/ak820_tapping.c:134: void ak820_tapping_cancel(void) {
                                   1230 ;	-----------------------------------------
                                   1231 ;	 function ak820_tapping_cancel
                                   1232 ;	-----------------------------------------
      004B56                       1233 _ak820_tapping_cancel:
                                   1234 ;	keyboards/ajazz/ak820/ak820_tapping.c:135: pending = NONE;
      004B56 12 4D 1B         [24] 1235 	lcall	_ak820_outline_0159
                                   1236 ;	keyboards/ajazz/ak820/ak820_tapping.c:136: for (uint8_t i = 0; i < SOURCES; ++i) {
      004B59 7F 00            [12] 1237 	mov	r7,#0x00
      004B5B                       1238 00103$:
      004B5B BF 82 00         [24] 1239 	cjne	r7,#0x82,00122$
      004B5E                       1240 00122$:
      004B5E 50 16            [24] 1241 	jnc	00105$
                                   1242 ;	keyboards/ajazz/ak820/ak820_tapping.c:137: uint8_t state = source_state[i];
      004B60 12 4C C1         [24] 1243 	lcall	_ak820_outline_0020
                                   1244 ;	keyboards/ajazz/ak820/ak820_tapping.c:138: source_state[i] = (state & SOURCE_BLOCKED) | ((state & SOURCE_ACTIVE) << 1);
      004B63 74 02            [12] 1245 	mov	a,#0x02
      004B65 5C               [12] 1246 	anl	a,r4
      004B66 FB               [12] 1247 	mov	r3,a
      004B67 53 04 01         [24] 1248 	anl	ar4,#0x01
      004B6A EC               [12] 1249 	mov	a,r4
      004B6B 2C               [12] 1250 	add	a,r4
      004B6C 42 03            [12] 1251 	orl	ar3,a
      004B6E 12 38 66         [24] 1252 	lcall	_ak820_outline_0136
      004B71 EB               [12] 1253 	mov	a,r3
      004B72 F0               [24] 1254 	movx	@dptr,a
                                   1255 ;	keyboards/ajazz/ak820/ak820_tapping.c:136: for (uint8_t i = 0; i < SOURCES; ++i) {
      004B73 0F               [12] 1256 	inc	r7
      004B74 80 E5            [24] 1257 	sjmp	00103$
      004B76                       1258 00105$:
                                   1259 ;	keyboards/ajazz/ak820/ak820_tapping.c:140: }
      004B76 22               [24] 1260 	ret
                                   1261 ;------------------------------------------------------------
                                   1262 ;Allocation info for local variables in function 'ak820_oneshot_process'
                                   1263 ;------------------------------------------------------------
                                   1264 ;id            Allocated with name '_ak820_oneshot_process_PARM_2'
                                   1265 ;pressed       Allocated with name '_ak820_oneshot_process_PARM_3'
                                   1266 ;code          Allocated with name '_ak820_oneshot_process_code_10000_672'
                                   1267 ;mods          Allocated with name '_ak820_oneshot_process_mods_10000_673'
                                   1268 ;i             Allocated with name '_ak820_oneshot_process_i_40000_687'
                                   1269 ;------------------------------------------------------------
                                   1270 ;	keyboards/ajazz/ak820/ak820_tapping.c:149: bool ak820_oneshot_process(uint16_t code, uint8_t id, bool pressed) {
                                   1271 ;	-----------------------------------------
                                   1272 ;	 function ak820_oneshot_process
                                   1273 ;	-----------------------------------------
      004B77                       1274 _ak820_oneshot_process:
      004B77 12 38 52         [24] 1275 	lcall	_ak820_outline_0106
      004B7A 90 06 7E         [24] 1276 	mov	dptr,#_ak820_oneshot_process_code_10000_672
      004B7D 12 38 57         [24] 1277 	lcall	_ak820_outline_0107
                                   1278 ;	keyboards/ajazz/ak820/ak820_tapping.c:151: if (id == NONE || get_repeat_key_count()) return true;
      004B80 90 06 7C         [24] 1279 	mov	dptr,#_ak820_oneshot_process_PARM_2
      004B83 E0               [24] 1280 	movx	a,@dptr
      004B84 FF               [12] 1281 	mov	r7,a
      004B85 BF FF 02         [24] 1282 	cjne	r7,#0xff,00248$
      004B88 80 07            [24] 1283 	sjmp	00101$
      004B8A                       1284 00248$:
      004B8A 12 A4 8D         [24] 1285 	lcall	_get_repeat_key_count
      004B8D E5 82            [12] 1286 	mov	a, dpl
      004B8F 60 04            [24] 1287 	jz	00102$
      004B91                       1288 00101$:
      004B91 75 82 01         [24] 1289 	mov	dpl, #0x01
      004B94 22               [24] 1290 	ret
      004B95                       1291 00102$:
                                   1292 ;	keyboards/ajazz/ak820/ak820_tapping.c:164: if ((code >> 8) == 0x52 && ((uint8_t)code & 0xe0) == 0xa0) {
      004B95 90 06 7E         [24] 1293 	mov	dptr,#_ak820_oneshot_process_code_10000_672
      004B98 E0               [24] 1294 	movx	a,@dptr
      004B99 FD               [12] 1295 	mov	r5,a
      004B9A A3               [24] 1296 	inc	dptr
      004B9B E0               [24] 1297 	movx	a,@dptr
      004B9C FB               [12] 1298 	mov	r3,a
      004B9D BB 52 02         [24] 1299 	cjne	r3,#0x52,00250$
      004BA0 80 02            [24] 1300 	sjmp	00251$
      004BA2                       1301 00250$:
      004BA2 81 45            [12] 1302 	ajmp	00116$
      004BA4                       1303 00251$:
      004BA4 8D 04            [24] 1304 	mov	ar4,r5
      004BA6 53 04 E0         [24] 1305 	anl	ar4,#0xe0
      004BA9 BC A0 02         [24] 1306 	cjne	r4,#0xa0,00252$
      004BAC 80 02            [24] 1307 	sjmp	00253$
      004BAE                       1308 00252$:
      004BAE 81 45            [12] 1309 	ajmp	00116$
      004BB0                       1310 00253$:
                                   1311 ;	keyboards/ajazz/ak820/ak820_tapping.c:165: mods = code & 15;
      004BB0 8D 04            [24] 1312 	mov	ar4,r5
      004BB2 53 04 0F         [24] 1313 	anl	ar4,#0x0f
      004BB5 90 06 80         [24] 1314 	mov	dptr,#_ak820_oneshot_process_mods_10000_673
      004BB8 EC               [12] 1315 	mov	a,r4
      004BB9 F0               [24] 1316 	movx	@dptr,a
                                   1317 ;	keyboards/ajazz/ak820/ak820_tapping.c:166: if (code & 16) mods <<= 4;
      004BBA ED               [12] 1318 	mov	a,r5
      004BBB 30 E4 08         [24] 1319 	jnb	acc.4,00105$
      004BBE EC               [12] 1320 	mov	a,r4
      004BBF C4               [12] 1321 	swap	a
      004BC0 54 F0            [12] 1322 	anl	a,#0xf0
      004BC2 90 06 80         [24] 1323 	mov	dptr,#_ak820_oneshot_process_mods_10000_673
      004BC5 F0               [24] 1324 	movx	@dptr,a
      004BC6                       1325 00105$:
                                   1326 ;	keyboards/ajazz/ak820/ak820_tapping.c:167: if (pressed) {
      004BC6 90 06 7D         [24] 1327 	mov	dptr,#_ak820_oneshot_process_PARM_3
      004BC9 E0               [24] 1328 	movx	a,@dptr
      004BCA 60 2D            [24] 1329 	jz	00113$
                                   1330 ;	keyboards/ajazz/ak820/ak820_tapping.c:168: source_state[id] |= SOURCE_ONESHOT;
      004BCC 12 4C C1         [24] 1331 	lcall	_ak820_outline_0020
      004BCF 43 04 08         [24] 1332 	orl	ar4,#0x08
      004BD2 12 42 FF         [24] 1333 	lcall	_ak820_outline_0066
                                   1334 ;	keyboards/ajazz/ak820/ak820_tapping.c:169: source_state[id] &= ~SOURCE_ONESHOT_USED;
      004BD5 53 04 EF         [24] 1335 	anl	ar4,#0xef
      004BD8 12 42 FF         [24] 1336 	lcall	_ak820_outline_0066
                                   1337 ;	keyboards/ajazz/ak820/ak820_tapping.c:170: if (ak820_oneshot_target != NONE) source_state[id] |= SOURCE_ONESHOT_USED;
      004BDB 90 0D D6         [24] 1338 	mov	dptr,#_ak820_oneshot_target
      004BDE E0               [24] 1339 	movx	a,@dptr
      004BDF FC               [12] 1340 	mov	r4,a
      004BE0 BC FF 02         [24] 1341 	cjne	r4,#0xff,00256$
      004BE3 80 09            [24] 1342 	sjmp	00107$
      004BE5                       1343 00256$:
      004BE5 12 4D 00         [24] 1344 	lcall	_ak820_outline_0076
      004BE8 43 04 10         [24] 1345 	orl	ar4,#0x10
      004BEB 12 42 FF         [24] 1346 	lcall	_ak820_outline_0066
      004BEE                       1347 00107$:
                                   1348 ;	keyboards/ajazz/ak820/ak820_tapping.c:171: register_mods(mods);
      004BEE 90 06 80         [24] 1349 	mov	dptr,#_ak820_oneshot_process_mods_10000_673
      004BF1 E0               [24] 1350 	movx	a,@dptr
      004BF2 F5 82            [12] 1351 	mov	dpl,a
      004BF4 12 79 F5         [24] 1352 	lcall	_register_mods
      004BF7 80 48            [24] 1353 	sjmp	00114$
      004BF9                       1354 00113$:
                                   1355 ;	keyboards/ajazz/ak820/ak820_tapping.c:172: } else if (source_state[id] & SOURCE_ONESHOT) {
      004BF9 12 4C C1         [24] 1356 	lcall	_ak820_outline_0020
      004BFC 30 E3 42         [24] 1357 	jnb	acc.3,00114$
                                   1358 ;	keyboards/ajazz/ak820/ak820_tapping.c:173: if (!(source_state[id] & SOURCE_ONESHOT_USED)) {
      004BFF EC               [12] 1359 	mov	a,r4
      004C00 20 E4 24         [24] 1360 	jb	acc.4,00109$
                                   1361 ;	keyboards/ajazz/ak820/ak820_tapping.c:174: add_owned_mods(mods & ~ak820_oneshot_mods);
      004C03 90 06 7A         [24] 1362 	mov	dptr,#_ak820_oneshot_mods
      004C06 E0               [24] 1363 	movx	a,@dptr
      004C07 F4               [12] 1364 	cpl	a
      004C08 FC               [12] 1365 	mov	r4,a
      004C09 90 06 80         [24] 1366 	mov	dptr,#_ak820_oneshot_process_mods_10000_673
      004C0C E0               [24] 1367 	movx	a,@dptr
      004C0D FB               [12] 1368 	mov	r3,a
      004C0E 52 04            [12] 1369 	anl	ar4,a
      004C10 8C 82            [24] 1370 	mov	dpl, r4
      004C12 C0 06            [24] 1371 	push	ar6
      004C14 C0 05            [24] 1372 	push	ar5
      004C16 C0 03            [24] 1373 	push	ar3
      004C18 12 80 1E         [24] 1374 	lcall	_add_owned_mods
      004C1B D0 03            [24] 1375 	pop	ar3
      004C1D D0 05            [24] 1376 	pop	ar5
      004C1F D0 06            [24] 1377 	pop	ar6
                                   1378 ;	keyboards/ajazz/ak820/ak820_tapping.c:175: ak820_oneshot_mods |= mods;
      004C21 90 06 7A         [24] 1379 	mov	dptr,#_ak820_oneshot_mods
      004C24 E0               [24] 1380 	movx	a,@dptr
      004C25 4B               [12] 1381 	orl	a,r3
      004C26 F0               [24] 1382 	movx	@dptr,a
      004C27                       1383 00109$:
                                   1384 ;	keyboards/ajazz/ak820/ak820_tapping.c:177: unregister_mods(mods);
      004C27 90 06 80         [24] 1385 	mov	dptr,#_ak820_oneshot_process_mods_10000_673
      004C2A E0               [24] 1386 	movx	a,@dptr
      004C2B F5 82            [12] 1387 	mov	dpl,a
      004C2D C0 06            [24] 1388 	push	ar6
      004C2F C0 05            [24] 1389 	push	ar5
      004C31 12 7A 09         [24] 1390 	lcall	_unregister_mods
      004C34 D0 05            [24] 1391 	pop	ar5
      004C36 D0 06            [24] 1392 	pop	ar6
                                   1393 ;	keyboards/ajazz/ak820/ak820_tapping.c:178: source_state[id] &= ~(SOURCE_ONESHOT | SOURCE_ONESHOT_USED);
      004C38 12 4D 00         [24] 1394 	lcall	_ak820_outline_0076
      004C3B 53 04 E7         [24] 1395 	anl	ar4,#0xe7
      004C3E 12 42 FF         [24] 1396 	lcall	_ak820_outline_0066
      004C41                       1397 00114$:
                                   1398 ;	keyboards/ajazz/ak820/ak820_tapping.c:180: return false;
      004C41 75 82 00         [24] 1399 	mov	dpl, #0x00
      004C44 22               [24] 1400 	ret
      004C45                       1401 00116$:
                                   1402 ;	keyboards/ajazz/ak820/ak820_tapping.c:182: if (pressed && code > KC_TRANSPARENT &&
      004C45 90 06 7D         [24] 1403 	mov	dptr,#_ak820_oneshot_process_PARM_3
      004C48 E0               [24] 1404 	movx	a,@dptr
      004C49 60 5C            [24] 1405 	jz	00124$
      004C4B 90 06 7E         [24] 1406 	mov	dptr,#_ak820_oneshot_process_code_10000_672
      004C4E 12 43 19         [24] 1407 	lcall	_ak820_outline_0096
      004C51 C3               [12] 1408 	clr	c
      004C52 74 01            [12] 1409 	mov	a,#0x01
      004C54 9D               [12] 1410 	subb	a,r5
      004C55 E4               [12] 1411 	clr	a
      004C56 9E               [12] 1412 	subb	a,r6
      004C57 50 4E            [24] 1413 	jnc	00124$
                                   1414 ;	free result
                                   1415 ;	keyboards/ajazz/ak820/ak820_tapping.c:183: !(code >= KC_LCTL && code <= KC_RGUI) &&
      004C59 C3               [12] 1416 	clr	c
      004C5A ED               [12] 1417 	mov	a,r5
      004C5B 94 E0            [12] 1418 	subb	a,#0xe0
      004C5D EE               [12] 1419 	mov	a,r6
      004C5E 94 00            [12] 1420 	subb	a,#0x00
      004C60 40 07            [24] 1421 	jc	00129$
      004C62 74 E7            [12] 1422 	mov	a,#0xe7
      004C64 9D               [12] 1423 	subb	a,r5
      004C65 E4               [12] 1424 	clr	a
      004C66 9E               [12] 1425 	subb	a,r6
      004C67 50 3E            [24] 1426 	jnc	00124$
                                   1427 ;	free result
      004C69                       1428 00129$:
                                   1429 ;	keyboards/ajazz/ak820/ak820_tapping.c:184: !(code >= QK_TO && code <= QK_LAYER_TAP_TOGGLE_MAX)) {
      004C69 74 AE            [12] 1430 	mov	a,#0x100 - 0x52
      004C6B 2E               [12] 1431 	add	a,r6
      004C6C 50 09            [24] 1432 	jnc	00165$
      004C6E C3               [12] 1433 	clr	c
      004C6F 74 DF            [12] 1434 	mov	a,#0xdf
      004C71 9D               [12] 1435 	subb	a,r5
      004C72 74 52            [12] 1436 	mov	a,#0x52
      004C74 9E               [12] 1437 	subb	a,r6
      004C75 50 30            [24] 1438 	jnc	00124$
                                   1439 ;	free result
                                   1440 ;	keyboards/ajazz/ak820/ak820_tapping.c:185: for (uint8_t i = 0; i < SOURCES; ++i)
      004C77                       1441 00165$:
      004C77 7E 00            [12] 1442 	mov	r6,#0x00
      004C79                       1443 00131$:
      004C79 BE 82 00         [24] 1444 	cjne	r6,#0x82,00265$
      004C7C                       1445 00265$:
      004C7C 50 12            [24] 1446 	jnc	00120$
                                   1447 ;	keyboards/ajazz/ak820/ak820_tapping.c:186: if (source_state[i] & SOURCE_ONESHOT) source_state[i] |= SOURCE_ONESHOT_USED;
      004C7E EE               [12] 1448 	mov	a,r6
      004C7F 12 4D 07         [24] 1449 	lcall	_ak820_outline_0079
      004C82 30 E3 08         [24] 1450 	jnb	acc.3,00132$
      004C85 43 03 10         [24] 1451 	orl	ar3,#0x10
      004C88 12 38 5C         [24] 1452 	lcall	_ak820_outline_0125
      004C8B EB               [12] 1453 	mov	a,r3
      004C8C F0               [24] 1454 	movx	@dptr,a
      004C8D                       1455 00132$:
                                   1456 ;	keyboards/ajazz/ak820/ak820_tapping.c:185: for (uint8_t i = 0; i < SOURCES; ++i)
      004C8D 0E               [12] 1457 	inc	r6
      004C8E 80 E9            [24] 1458 	sjmp	00131$
      004C90                       1459 00120$:
                                   1460 ;	keyboards/ajazz/ak820/ak820_tapping.c:187: if (ak820_oneshot_mods) {
      004C90 90 06 7A         [24] 1461 	mov	dptr,#_ak820_oneshot_mods
      004C93 E0               [24] 1462 	movx	a,@dptr
      004C94 FE               [12] 1463 	mov	r6,a
      004C95 E0               [24] 1464 	movx	a,@dptr
      004C96 60 0F            [24] 1465 	jz	00124$
                                   1466 ;	keyboards/ajazz/ak820/ak820_tapping.c:188: ak820_oneshot_consumed = ak820_oneshot_mods;
      004C98 90 06 7B         [24] 1467 	mov	dptr,#_ak820_oneshot_consumed
      004C9B EE               [12] 1468 	mov	a,r6
      004C9C F0               [24] 1469 	movx	@dptr,a
                                   1470 ;	keyboards/ajazz/ak820/ak820_tapping.c:189: ak820_oneshot_target = id;
      004C9D 90 0D D6         [24] 1471 	mov	dptr,#_ak820_oneshot_target
      004CA0 EF               [12] 1472 	mov	a,r7
      004CA1 F0               [24] 1473 	movx	@dptr,a
                                   1474 ;	keyboards/ajazz/ak820/ak820_tapping.c:190: ak820_oneshot_mods = 0;
      004CA2 90 06 7A         [24] 1475 	mov	dptr,#_ak820_oneshot_mods
      004CA5 E4               [12] 1476 	clr	a
      004CA6 F0               [24] 1477 	movx	@dptr,a
      004CA7                       1478 00124$:
                                   1479 ;	keyboards/ajazz/ak820/ak820_tapping.c:193: return true;
      004CA7 75 82 01         [24] 1480 	mov	dpl, #0x01
                                   1481 ;	keyboards/ajazz/ak820/ak820_tapping.c:194: }
      004CAA 22               [24] 1482 	ret
                                   1483 	.area CSEG    (CODE)
                                   1484 	.area CONST   (CODE)
                                   1485 	.area XINIT   (CODE)
      00C4EC                       1486 __xinit__pending:
      00C4EC FF                    1487 	.db #0xff	; 255
      00C4ED                       1488 __xinit__ak820_oneshot_target:
      00C4ED FF                    1489 	.db #0xff	; 255
                                   1490 	.area CABS    (ABS,CODE)
                                   1491 
                                   1492 ; Experimental exact instruction outlining.
                                   1493 	.globl _ak820_outline_0004
                                   1494 	.globl _ak820_outline_0005
                                   1495 	.globl _ak820_outline_0010
                                   1496 	.globl _ak820_outline_0011
                                   1497 	.globl _ak820_outline_0012
                                   1498 	.globl _ak820_outline_0013
                                   1499 	.globl _ak820_outline_0014
                                   1500 	.globl _ak820_outline_0017
                                   1501 	.globl _ak820_outline_0020
                                   1502 	.globl _ak820_outline_0024
                                   1503 	.globl _ak820_outline_0031
                                   1504 	.globl _ak820_outline_0034
                                   1505 	.globl _ak820_outline_0051
                                   1506 	.globl _ak820_outline_0055
                                   1507 	.globl _ak820_outline_0056
                                   1508 	.globl _ak820_outline_0060
                                   1509 	.globl _ak820_outline_0061
                                   1510 	.globl _ak820_outline_0066
                                   1511 	.globl _ak820_outline_0076
                                   1512 	.globl _ak820_outline_0079
                                   1513 	.globl _ak820_outline_0096
                                   1514 	.globl _ak820_outline_0100
                                   1515 	.globl _ak820_outline_0106
                                   1516 	.globl _ak820_outline_0107
                                   1517 	.globl _ak820_outline_0121
                                   1518 	.globl _ak820_outline_0125
                                   1519 	.globl _ak820_outline_0126
                                   1520 	.globl _ak820_outline_0136
                                   1521 	.globl _ak820_outline_0139
                                   1522 	.globl _ak820_outline_0159
                                   1523 	.globl _ak820_outline_0161
                                   1524 	.globl _ak820_outline_0189
                                   1525 	.globl _ak820_outline_0193
                                   1526 
                                   1527 	.area CSEG (CODE)
                                   1528 ; function ak820_outline_0012
      004CAB                       1529 _ak820_outline_0012:
      004CAB 2E               [12] 1530 	add	a,r6
      004CAC FB               [12] 1531 	mov	r3,a
      004CAD E4               [12] 1532 	clr	a
      004CAE 3F               [12] 1533 	addc	a,r7
      004CAF FC               [12] 1534 	mov	r4,a
      004CB0 8B 82            [24] 1535 	mov	dpl,r3
      004CB2 8C 83            [24] 1536 	mov	dph,r4
      004CB4 E0               [24] 1537 	movx	a,@dptr
      004CB5 22               [24] 1538 	ret
                                   1539 
                                   1540 	.area CSEG (CODE)
                                   1541 ; function ak820_outline_0013
      004CB6                       1542 _ak820_outline_0013:
      004CB6 2E               [12] 1543 	add	a,r6
      004CB7 FC               [12] 1544 	mov	r4,a
      004CB8 E4               [12] 1545 	clr	a
      004CB9 3F               [12] 1546 	addc	a,r7
      004CBA FD               [12] 1547 	mov	r5,a
      004CBB 8C 82            [24] 1548 	mov	dpl,r4
      004CBD 8D 83            [24] 1549 	mov	dph,r5
      004CBF E0               [24] 1550 	movx	a,@dptr
      004CC0 22               [24] 1551 	ret
                                   1552 
                                   1553 	.area CSEG (CODE)
                                   1554 ; function ak820_outline_0020
      004CC1                       1555 _ak820_outline_0020:
      004CC1 EF               [12] 1556 	mov	a,r7
      004CC2 24 E6            [12] 1557 	add	a,#_source_state
      004CC4 FD               [12] 1558 	mov	r5,a
      004CC5 E4               [12] 1559 	clr	a
      004CC6 34 05            [12] 1560 	addc	a,#(_source_state>>8)
      004CC8 FE               [12] 1561 	mov	r6,a
      004CC9 8D 82            [24] 1562 	mov	dpl,r5
      004CCB 8E 83            [24] 1563 	mov	dph,r6
      004CCD E0               [24] 1564 	movx	a,@dptr
      004CCE FC               [12] 1565 	mov	r4,a
      004CCF 22               [24] 1566 	ret
                                   1567 
                                   1568 	.area CSEG (CODE)
                                   1569 ; function ak820_outline_0024
      004CD0                       1570 _ak820_outline_0024:
      004CD0 90 0D BD         [24] 1571 	mov	dptr,#___memcpy_PARM_2
      004CD3 EC               [12] 1572 	mov	a,r4
      004CD4 F0               [24] 1573 	movx	@dptr,a
      004CD5 ED               [12] 1574 	mov	a,r5
      004CD6 A3               [24] 1575 	inc	dptr
      004CD7 F0               [24] 1576 	movx	@dptr,a
      004CD8 E4               [12] 1577 	clr	a
      004CD9 A3               [24] 1578 	inc	dptr
      004CDA F0               [24] 1579 	movx	@dptr,a
      004CDB 90 0D C0         [24] 1580 	mov	dptr,#___memcpy_PARM_3
      004CDE 74 02            [12] 1581 	mov	a,#0x02
      004CE0 F0               [24] 1582 	movx	@dptr,a
      004CE1 E4               [12] 1583 	clr	a
      004CE2 A3               [24] 1584 	inc	dptr
      004CE3 F0               [24] 1585 	movx	@dptr,a
      004CE4 90 06 6C         [24] 1586 	mov	dptr,#_ak820_tapping_source_PARM_1
      004CE7 F5 F0            [12] 1587 	mov	b,a
      004CE9 22               [24] 1588 	ret
                                   1589 
                                   1590 	.area CSEG (CODE)
                                   1591 ; function ak820_outline_0055
      004CEA                       1592 _ak820_outline_0055:
      004CEA 74 01            [12] 1593 	mov	a,#0x01
      004CEC F0               [24] 1594 	movx	@dptr,a
      004CED 8E 82            [24] 1595 	mov	dpl,r6
      004CEF 8F 83            [24] 1596 	mov	dph,r7
      004CF1 22               [24] 1597 	ret
                                   1598 
                                   1599 	.area CSEG (CODE)
                                   1600 ; function ak820_outline_0056
      004CF2                       1601 _ak820_outline_0056:
      004CF2 FC               [12] 1602 	mov	r4,a
      004CF3 8B 82            [24] 1603 	mov	dpl,r3
      004CF5 8C 83            [24] 1604 	mov	dph,r4
      004CF7 E0               [24] 1605 	movx	a,@dptr
      004CF8 FA               [12] 1606 	mov	r2,a
      004CF9 22               [24] 1607 	ret
                                   1608 
                                   1609 	.area CSEG (CODE)
                                   1610 ; function ak820_outline_0060
      004CFA                       1611 _ak820_outline_0060:
      004CFA EE               [12] 1612 	mov	a,r6
      004CFB F0               [24] 1613 	movx	@dptr,a
      004CFC EF               [12] 1614 	mov	a,r7
      004CFD A3               [24] 1615 	inc	dptr
      004CFE F0               [24] 1616 	movx	@dptr,a
      004CFF 22               [24] 1617 	ret
                                   1618 
                                   1619 	.area CSEG (CODE)
                                   1620 ; function ak820_outline_0076
      004D00                       1621 _ak820_outline_0076:
      004D00 8D 82            [24] 1622 	mov	dpl,r5
      004D02 8E 83            [24] 1623 	mov	dph,r6
      004D04 E0               [24] 1624 	movx	a,@dptr
      004D05 FC               [12] 1625 	mov	r4,a
      004D06 22               [24] 1626 	ret
                                   1627 
                                   1628 	.area CSEG (CODE)
                                   1629 ; function ak820_outline_0079
      004D07                       1630 _ak820_outline_0079:
      004D07 24 E6            [12] 1631 	add	a,#_source_state
      004D09 FC               [12] 1632 	mov	r4,a
      004D0A E4               [12] 1633 	clr	a
      004D0B 34 05            [12] 1634 	addc	a,#(_source_state>>8)
      004D0D FD               [12] 1635 	mov	r5,a
      004D0E 8C 82            [24] 1636 	mov	dpl,r4
      004D10 8D 83            [24] 1637 	mov	dph,r5
      004D12 E0               [24] 1638 	movx	a,@dptr
      004D13 FB               [12] 1639 	mov	r3,a
      004D14 22               [24] 1640 	ret
                                   1641 
                                   1642 	.area CSEG (CODE)
                                   1643 ; function ak820_outline_0139
      004D15                       1644 _ak820_outline_0139:
      004D15 E9               [12] 1645 	mov	a,r1
      004D16 F0               [24] 1646 	movx	@dptr,a
      004D17 EA               [12] 1647 	mov	a,r2
      004D18 A3               [24] 1648 	inc	dptr
      004D19 F0               [24] 1649 	movx	@dptr,a
      004D1A 22               [24] 1650 	ret
                                   1651 
                                   1652 	.area CSEG (CODE)
                                   1653 ; function ak820_outline_0159
      004D1B                       1654 _ak820_outline_0159:
      004D1B 90 0D D5         [24] 1655 	mov	dptr,#_pending
      004D1E 74 FF            [12] 1656 	mov	a,#0xff
      004D20 F0               [24] 1657 	movx	@dptr,a
      004D21 22               [24] 1658 	ret
                                   1659 
                                   1660 	.area CSEG (CODE)
                                   1661 ; function ak820_outline_0189
      004D22                       1662 _ak820_outline_0189:
      004D22 A9 82            [24] 1663 	mov	r1,dpl
      004D24 AA 83            [24] 1664 	mov	r2,dph
      004D26 22               [24] 1665 	ret
