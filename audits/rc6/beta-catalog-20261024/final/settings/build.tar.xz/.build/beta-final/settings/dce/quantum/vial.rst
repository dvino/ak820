                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module vial
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_settings_tap_code_delay
                                     12 	.globl _ak820_settings_reset
                                     13 	.globl _ak820_settings_set
                                     14 	.globl _ak820_settings_get
                                     15 	.globl _ak820_settings_query
                                     16 	.globl _ak820_settings_init
                                     17 	.globl _unregister_code16
                                     18 	.globl _register_code16
                                     19 	.globl _matrix_is_on
                                     20 	.globl _dynamic_keymap_set_combo
                                     21 	.globl _dynamic_keymap_get_combo
                                     22 	.globl _dynamic_keymap_set_encoder
                                     23 	.globl _dynamic_keymap_get_encoder
                                     24 	.globl _repeat_key_cancel
                                     25 	.globl _ak820_combo_reload
                                     26 	.globl _clear_keyboard
                                     27 	.globl _ak820_action_exec
                                     28 	.globl _timer_elapsed32
                                     29 	.globl _timer_read32
                                     30 	.globl _timer_read
                                     31 	.globl _mDelaymS
                                     32 	.globl ___memcpy
                                     33 	.globl _ADC_START
                                     34 	.globl _S0_R_FIFO
                                     35 	.globl _S0_T_FIFO
                                     36 	.globl _S0_FREE
                                     37 	.globl _S0_IF_BYTE
                                     38 	.globl _S0_IF_FIRST
                                     39 	.globl _S0_IF_OV
                                     40 	.globl _S0_FST_ACT
                                     41 	.globl _CP_RL2
                                     42 	.globl _C_T2
                                     43 	.globl _TR2
                                     44 	.globl _EXEN2
                                     45 	.globl _TCLK
                                     46 	.globl _RCLK
                                     47 	.globl _EXF2
                                     48 	.globl _CAP1F
                                     49 	.globl _TF2
                                     50 	.globl _RI
                                     51 	.globl _TI
                                     52 	.globl _RB8
                                     53 	.globl _TB8
                                     54 	.globl _REN
                                     55 	.globl _SM2
                                     56 	.globl _SM1
                                     57 	.globl _SM0
                                     58 	.globl _IT0
                                     59 	.globl _IE0
                                     60 	.globl _IT1
                                     61 	.globl _IE1
                                     62 	.globl _TR0
                                     63 	.globl _TF0
                                     64 	.globl _TR1
                                     65 	.globl _TF1
                                     66 	.globl _P4_0
                                     67 	.globl _P4_1
                                     68 	.globl _P4_2
                                     69 	.globl _P4_3
                                     70 	.globl _P4_4
                                     71 	.globl _P4_5
                                     72 	.globl _P4_6
                                     73 	.globl _RXD
                                     74 	.globl _TXD
                                     75 	.globl _INT0
                                     76 	.globl _INT1
                                     77 	.globl _T0
                                     78 	.globl _T1
                                     79 	.globl _MOSI1
                                     80 	.globl _MISO1
                                     81 	.globl _SCK1
                                     82 	.globl _P3_0
                                     83 	.globl _P3_1
                                     84 	.globl _P3_2
                                     85 	.globl _P3_3
                                     86 	.globl _P3_4
                                     87 	.globl _P3_5
                                     88 	.globl _P3_6
                                     89 	.globl _P3_7
                                     90 	.globl _CAP1_
                                     91 	.globl _T2_
                                     92 	.globl _CAP2_
                                     93 	.globl _T2EX_
                                     94 	.globl _RXD1
                                     95 	.globl _TXD1
                                     96 	.globl _P2_0
                                     97 	.globl _P2_1
                                     98 	.globl _P2_2
                                     99 	.globl _P2_3
                                    100 	.globl _P2_4
                                    101 	.globl _P2_5
                                    102 	.globl _P2_6
                                    103 	.globl _P2_7
                                    104 	.globl _AIN0
                                    105 	.globl _AIN1
                                    106 	.globl _AIN2
                                    107 	.globl _AIN3
                                    108 	.globl _AIN4
                                    109 	.globl _AIN5
                                    110 	.globl _AIN6
                                    111 	.globl _AIN7
                                    112 	.globl _CAP1
                                    113 	.globl _T2
                                    114 	.globl _CAP2
                                    115 	.globl _T2EX
                                    116 	.globl _INT0_
                                    117 	.globl _SCS
                                    118 	.globl _MOSI
                                    119 	.globl _MISO
                                    120 	.globl _SCK
                                    121 	.globl _RXD1_
                                    122 	.globl _TXD1_
                                    123 	.globl _P1_0
                                    124 	.globl _P1_1
                                    125 	.globl _P1_2
                                    126 	.globl _P1_3
                                    127 	.globl _P1_4
                                    128 	.globl _P1_5
                                    129 	.globl _P1_6
                                    130 	.globl _P1_7
                                    131 	.globl _AIN8
                                    132 	.globl _AIN9
                                    133 	.globl _AIN10
                                    134 	.globl _AIN11
                                    135 	.globl _AIN12
                                    136 	.globl _AIN13
                                    137 	.globl _RXD_
                                    138 	.globl _TXD_
                                    139 	.globl _SCL0
                                    140 	.globl _SDA0
                                    141 	.globl _P0_0
                                    142 	.globl _P0_1
                                    143 	.globl _P0_2
                                    144 	.globl _P0_3
                                    145 	.globl _P0_4
                                    146 	.globl _P0_5
                                    147 	.globl _P0_6
                                    148 	.globl _P0_7
                                    149 	.globl _IE_SPI0
                                    150 	.globl _IE_USB
                                    151 	.globl _IE_ADC
                                    152 	.globl _IE_UART1
                                    153 	.globl _IE_PWM_I2C
                                    154 	.globl _IE_GPIO
                                    155 	.globl _IE_WDOG
                                    156 	.globl _PX0
                                    157 	.globl _PT0
                                    158 	.globl _PX1
                                    159 	.globl _PT1
                                    160 	.globl _PS
                                    161 	.globl _PT2
                                    162 	.globl _PL_FLAG
                                    163 	.globl _PH_FLAG
                                    164 	.globl _EX0
                                    165 	.globl _ET0
                                    166 	.globl _EX1
                                    167 	.globl _ET1
                                    168 	.globl _ES
                                    169 	.globl _ET2
                                    170 	.globl _E_DIS
                                    171 	.globl _EA
                                    172 	.globl _P
                                    173 	.globl _F1
                                    174 	.globl _OV
                                    175 	.globl _RS0
                                    176 	.globl _RS1
                                    177 	.globl _F0
                                    178 	.globl _AC
                                    179 	.globl _CY
                                    180 	.globl _I2CS_INT_ST
                                    181 	.globl _I2CX_INT
                                    182 	.globl _LED_STATUS
                                    183 	.globl _LED_DMA_H
                                    184 	.globl _LED_DMA_L
                                    185 	.globl _LED_DMA
                                    186 	.globl _LED_PWM_OE
                                    187 	.globl _LED_COMMON
                                    188 	.globl _ADC_CHAN
                                    189 	.globl _ADC_DAT_H
                                    190 	.globl _ADC_DAT_L
                                    191 	.globl _ADC_DAT
                                    192 	.globl _ADC_CTRL
                                    193 	.globl _SPI1_CK_SE
                                    194 	.globl _SPI1_CTRL
                                    195 	.globl _SPI1_DATA
                                    196 	.globl _SPI1_STAT
                                    197 	.globl _SIF1
                                    198 	.globl _SBAUD1
                                    199 	.globl _SBUF1
                                    200 	.globl _SCON1
                                    201 	.globl _SPI0_SETUP
                                    202 	.globl _SPI0_CK_SE
                                    203 	.globl _SPI0_CTRL
                                    204 	.globl _SPI0_DATA
                                    205 	.globl _SPI0_STAT
                                    206 	.globl _T2CAP1H
                                    207 	.globl _T2CAP1L
                                    208 	.globl _T2CAP1
                                    209 	.globl _TH2
                                    210 	.globl _TL2
                                    211 	.globl _T2COUNT
                                    212 	.globl _RCAP2H
                                    213 	.globl _RCAP2L
                                    214 	.globl _RCAP2
                                    215 	.globl _T2MOD
                                    216 	.globl _T2CON
                                    217 	.globl _SBUF
                                    218 	.globl _SCON
                                    219 	.globl _TH1
                                    220 	.globl _TH0
                                    221 	.globl _TL1
                                    222 	.globl _TL0
                                    223 	.globl _TMOD
                                    224 	.globl _TCON
                                    225 	.globl _XBUS_AUX
                                    226 	.globl _P7
                                    227 	.globl _P6_DIR
                                    228 	.globl _P6_OUT_PU
                                    229 	.globl _P6_IN
                                    230 	.globl _P5_DIR
                                    231 	.globl _P5_OUT_PU
                                    232 	.globl _P5_IN
                                    233 	.globl _P4_LED_KEY
                                    234 	.globl _P4_DIR_PU
                                    235 	.globl _P4_MOD_OC
                                    236 	.globl _P4
                                    237 	.globl _P3_DIR_PU
                                    238 	.globl _P3_MOD_OC
                                    239 	.globl _P3
                                    240 	.globl _P2_DIR_PU
                                    241 	.globl _P2_MOD_OC
                                    242 	.globl _P2
                                    243 	.globl _P1_DIR_PU
                                    244 	.globl _P1_MOD_OC
                                    245 	.globl _P1
                                    246 	.globl _P0_DIR_PU
                                    247 	.globl _P0_MOD_OC
                                    248 	.globl _P0
                                    249 	.globl _ROM_CTRL
                                    250 	.globl _ROM_DATA_HH
                                    251 	.globl _ROM_DATA_HL
                                    252 	.globl _ROM_DATA_HI
                                    253 	.globl _ROM_ADDR_H
                                    254 	.globl _ROM_ADDR_L
                                    255 	.globl _ROM_ADDR
                                    256 	.globl _GPIO_IE
                                    257 	.globl _IP_EX
                                    258 	.globl _IE_EX
                                    259 	.globl _IP
                                    260 	.globl _IE
                                    261 	.globl _WDOG_COUNT
                                    262 	.globl _RESET_KEEP
                                    263 	.globl _WAKE_CTRL
                                    264 	.globl _CLOCK_CFG
                                    265 	.globl _POWER_CFG
                                    266 	.globl _PCON
                                    267 	.globl _GLOBAL_CFG
                                    268 	.globl _SAFE_MOD
                                    269 	.globl _DPH
                                    270 	.globl _DPL
                                    271 	.globl _SP
                                    272 	.globl _A_INV
                                    273 	.globl _B
                                    274 	.globl _ACC
                                    275 	.globl _PSW
                                    276 	.globl _vial_unlock_in_progress
                                    277 	.globl _vial_unlocked
                                    278 	.globl _g_vial_magic_keycode_override
                                    279 	.globl _vial_handle_cmd_PARM_2
                                    280 	.globl _vial_unlock_task
                                    281 	.globl _vial_init
                                    282 	.globl _vial_handle_cmd
                                    283 	.globl _vial_keycode_down
                                    284 	.globl _vial_keycode_up
                                    285 	.globl _vial_keycode_tap
                                    286 ;--------------------------------------------------------
                                    287 ; special function registers
                                    288 ;--------------------------------------------------------
                                    289 	.area RSEG    (ABS,DATA)
      000000                        290 	.org 0x0000
                           0000D0   291 _PSW	=	0x00d0
                           0000E0   292 _ACC	=	0x00e0
                           0000F0   293 _B	=	0x00f0
                           0000FD   294 _A_INV	=	0x00fd
                           000081   295 _SP	=	0x0081
                           000082   296 _DPL	=	0x0082
                           000083   297 _DPH	=	0x0083
                           0000A1   298 _SAFE_MOD	=	0x00a1
                           0000B1   299 _GLOBAL_CFG	=	0x00b1
                           000087   300 _PCON	=	0x0087
                           0000BA   301 _POWER_CFG	=	0x00ba
                           0000B9   302 _CLOCK_CFG	=	0x00b9
                           0000A9   303 _WAKE_CTRL	=	0x00a9
                           0000FE   304 _RESET_KEEP	=	0x00fe
                           0000FF   305 _WDOG_COUNT	=	0x00ff
                           0000A8   306 _IE	=	0x00a8
                           0000B8   307 _IP	=	0x00b8
                           0000E8   308 _IE_EX	=	0x00e8
                           0000E9   309 _IP_EX	=	0x00e9
                           0000B2   310 _GPIO_IE	=	0x00b2
                           008584   311 _ROM_ADDR	=	0x8584
                           000084   312 _ROM_ADDR_L	=	0x0084
                           000085   313 _ROM_ADDR_H	=	0x0085
                           008F8E   314 _ROM_DATA_HI	=	0x8f8e
                           00008E   315 _ROM_DATA_HL	=	0x008e
                           00008F   316 _ROM_DATA_HH	=	0x008f
                           000086   317 _ROM_CTRL	=	0x0086
                           000080   318 _P0	=	0x0080
                           0000C4   319 _P0_MOD_OC	=	0x00c4
                           0000C5   320 _P0_DIR_PU	=	0x00c5
                           000090   321 _P1	=	0x0090
                           000092   322 _P1_MOD_OC	=	0x0092
                           000093   323 _P1_DIR_PU	=	0x0093
                           0000A0   324 _P2	=	0x00a0
                           000094   325 _P2_MOD_OC	=	0x0094
                           000095   326 _P2_DIR_PU	=	0x0095
                           0000B0   327 _P3	=	0x00b0
                           000096   328 _P3_MOD_OC	=	0x0096
                           000097   329 _P3_DIR_PU	=	0x0097
                           0000C0   330 _P4	=	0x00c0
                           0000C2   331 _P4_MOD_OC	=	0x00c2
                           0000C3   332 _P4_DIR_PU	=	0x00c3
                           0000C1   333 _P4_LED_KEY	=	0x00c1
                           0000AA   334 _P5_IN	=	0x00aa
                           0000AB   335 _P5_OUT_PU	=	0x00ab
                           0000AC   336 _P5_DIR	=	0x00ac
                           0000AD   337 _P6_IN	=	0x00ad
                           0000AE   338 _P6_OUT_PU	=	0x00ae
                           0000AF   339 _P6_DIR	=	0x00af
                           0000F1   340 _P7	=	0x00f1
                           0000A2   341 _XBUS_AUX	=	0x00a2
                           000088   342 _TCON	=	0x0088
                           000089   343 _TMOD	=	0x0089
                           00008A   344 _TL0	=	0x008a
                           00008B   345 _TL1	=	0x008b
                           00008C   346 _TH0	=	0x008c
                           00008D   347 _TH1	=	0x008d
                           000098   348 _SCON	=	0x0098
                           000099   349 _SBUF	=	0x0099
                           0000C8   350 _T2CON	=	0x00c8
                           0000C9   351 _T2MOD	=	0x00c9
                           00CBCA   352 _RCAP2	=	0xcbca
                           0000CA   353 _RCAP2L	=	0x00ca
                           0000CB   354 _RCAP2H	=	0x00cb
                           00CDCC   355 _T2COUNT	=	0xcdcc
                           0000CC   356 _TL2	=	0x00cc
                           0000CD   357 _TH2	=	0x00cd
                           00CFCE   358 _T2CAP1	=	0xcfce
                           0000CE   359 _T2CAP1L	=	0x00ce
                           0000CF   360 _T2CAP1H	=	0x00cf
                           0000F8   361 _SPI0_STAT	=	0x00f8
                           0000F9   362 _SPI0_DATA	=	0x00f9
                           0000FA   363 _SPI0_CTRL	=	0x00fa
                           0000FB   364 _SPI0_CK_SE	=	0x00fb
                           0000FC   365 _SPI0_SETUP	=	0x00fc
                           0000BC   366 _SCON1	=	0x00bc
                           0000BD   367 _SBUF1	=	0x00bd
                           0000BE   368 _SBAUD1	=	0x00be
                           0000BF   369 _SIF1	=	0x00bf
                           0000B4   370 _SPI1_STAT	=	0x00b4
                           0000B5   371 _SPI1_DATA	=	0x00b5
                           0000B6   372 _SPI1_CTRL	=	0x00b6
                           0000B7   373 _SPI1_CK_SE	=	0x00b7
                           0000F3   374 _ADC_CTRL	=	0x00f3
                           00F5F4   375 _ADC_DAT	=	0xf5f4
                           0000F4   376 _ADC_DAT_L	=	0x00f4
                           0000F5   377 _ADC_DAT_H	=	0x00f5
                           0000F6   378 _ADC_CHAN	=	0x00f6
                           0000A6   379 _LED_COMMON	=	0x00a6
                           0000A7   380 _LED_PWM_OE	=	0x00a7
                           00C7C6   381 _LED_DMA	=	0xc7c6
                           0000C6   382 _LED_DMA_L	=	0x00c6
                           0000C7   383 _LED_DMA_H	=	0x00c7
                           0000F7   384 _LED_STATUS	=	0x00f7
                           0000B3   385 _I2CX_INT	=	0x00b3
                           0000BB   386 _I2CS_INT_ST	=	0x00bb
                                    387 ;--------------------------------------------------------
                                    388 ; special function bits
                                    389 ;--------------------------------------------------------
                                    390 	.area RSEG    (ABS,DATA)
      000000                        391 	.org 0x0000
                           0000D7   392 _CY	=	0x00d7
                           0000D6   393 _AC	=	0x00d6
                           0000D5   394 _F0	=	0x00d5
                           0000D4   395 _RS1	=	0x00d4
                           0000D3   396 _RS0	=	0x00d3
                           0000D2   397 _OV	=	0x00d2
                           0000D1   398 _F1	=	0x00d1
                           0000D0   399 _P	=	0x00d0
                           0000AF   400 _EA	=	0x00af
                           0000AE   401 _E_DIS	=	0x00ae
                           0000AD   402 _ET2	=	0x00ad
                           0000AC   403 _ES	=	0x00ac
                           0000AB   404 _ET1	=	0x00ab
                           0000AA   405 _EX1	=	0x00aa
                           0000A9   406 _ET0	=	0x00a9
                           0000A8   407 _EX0	=	0x00a8
                           0000BF   408 _PH_FLAG	=	0x00bf
                           0000BE   409 _PL_FLAG	=	0x00be
                           0000BD   410 _PT2	=	0x00bd
                           0000BC   411 _PS	=	0x00bc
                           0000BB   412 _PT1	=	0x00bb
                           0000BA   413 _PX1	=	0x00ba
                           0000B9   414 _PT0	=	0x00b9
                           0000B8   415 _PX0	=	0x00b8
                           0000EF   416 _IE_WDOG	=	0x00ef
                           0000EE   417 _IE_GPIO	=	0x00ee
                           0000ED   418 _IE_PWM_I2C	=	0x00ed
                           0000EC   419 _IE_UART1	=	0x00ec
                           0000EB   420 _IE_ADC	=	0x00eb
                           0000E9   421 _IE_USB	=	0x00e9
                           0000E8   422 _IE_SPI0	=	0x00e8
                           000087   423 _P0_7	=	0x0087
                           000086   424 _P0_6	=	0x0086
                           000085   425 _P0_5	=	0x0085
                           000084   426 _P0_4	=	0x0084
                           000083   427 _P0_3	=	0x0083
                           000082   428 _P0_2	=	0x0082
                           000081   429 _P0_1	=	0x0081
                           000080   430 _P0_0	=	0x0080
                           000081   431 _SDA0	=	0x0081
                           000080   432 _SCL0	=	0x0080
                           000083   433 _TXD_	=	0x0083
                           000082   434 _RXD_	=	0x0082
                           000085   435 _AIN13	=	0x0085
                           000084   436 _AIN12	=	0x0084
                           000083   437 _AIN11	=	0x0083
                           000082   438 _AIN10	=	0x0082
                           000081   439 _AIN9	=	0x0081
                           000080   440 _AIN8	=	0x0080
                           000097   441 _P1_7	=	0x0097
                           000096   442 _P1_6	=	0x0096
                           000095   443 _P1_5	=	0x0095
                           000094   444 _P1_4	=	0x0094
                           000093   445 _P1_3	=	0x0093
                           000092   446 _P1_2	=	0x0092
                           000091   447 _P1_1	=	0x0091
                           000090   448 _P1_0	=	0x0090
                           000097   449 _TXD1_	=	0x0097
                           000096   450 _RXD1_	=	0x0096
                           000097   451 _SCK	=	0x0097
                           000096   452 _MISO	=	0x0096
                           000095   453 _MOSI	=	0x0095
                           000094   454 _SCS	=	0x0094
                           000092   455 _INT0_	=	0x0092
                           000091   456 _T2EX	=	0x0091
                           000091   457 _CAP2	=	0x0091
                           000090   458 _T2	=	0x0090
                           000090   459 _CAP1	=	0x0090
                           000097   460 _AIN7	=	0x0097
                           000096   461 _AIN6	=	0x0096
                           000095   462 _AIN5	=	0x0095
                           000094   463 _AIN4	=	0x0094
                           000093   464 _AIN3	=	0x0093
                           000092   465 _AIN2	=	0x0092
                           000091   466 _AIN1	=	0x0091
                           000090   467 _AIN0	=	0x0090
                           0000A7   468 _P2_7	=	0x00a7
                           0000A6   469 _P2_6	=	0x00a6
                           0000A5   470 _P2_5	=	0x00a5
                           0000A4   471 _P2_4	=	0x00a4
                           0000A3   472 _P2_3	=	0x00a3
                           0000A2   473 _P2_2	=	0x00a2
                           0000A1   474 _P2_1	=	0x00a1
                           0000A0   475 _P2_0	=	0x00a0
                           0000A7   476 _TXD1	=	0x00a7
                           0000A6   477 _RXD1	=	0x00a6
                           0000A5   478 _T2EX_	=	0x00a5
                           0000A5   479 _CAP2_	=	0x00a5
                           0000A4   480 _T2_	=	0x00a4
                           0000A4   481 _CAP1_	=	0x00a4
                           0000B7   482 _P3_7	=	0x00b7
                           0000B6   483 _P3_6	=	0x00b6
                           0000B5   484 _P3_5	=	0x00b5
                           0000B4   485 _P3_4	=	0x00b4
                           0000B3   486 _P3_3	=	0x00b3
                           0000B2   487 _P3_2	=	0x00b2
                           0000B1   488 _P3_1	=	0x00b1
                           0000B0   489 _P3_0	=	0x00b0
                           0000B7   490 _SCK1	=	0x00b7
                           0000B6   491 _MISO1	=	0x00b6
                           0000B5   492 _MOSI1	=	0x00b5
                           0000B5   493 _T1	=	0x00b5
                           0000B4   494 _T0	=	0x00b4
                           0000B3   495 _INT1	=	0x00b3
                           0000B2   496 _INT0	=	0x00b2
                           0000B1   497 _TXD	=	0x00b1
                           0000B0   498 _RXD	=	0x00b0
                           0000C6   499 _P4_6	=	0x00c6
                           0000C5   500 _P4_5	=	0x00c5
                           0000C4   501 _P4_4	=	0x00c4
                           0000C3   502 _P4_3	=	0x00c3
                           0000C2   503 _P4_2	=	0x00c2
                           0000C1   504 _P4_1	=	0x00c1
                           0000C0   505 _P4_0	=	0x00c0
                           00008F   506 _TF1	=	0x008f
                           00008E   507 _TR1	=	0x008e
                           00008D   508 _TF0	=	0x008d
                           00008C   509 _TR0	=	0x008c
                           00008B   510 _IE1	=	0x008b
                           00008A   511 _IT1	=	0x008a
                           000089   512 _IE0	=	0x0089
                           000088   513 _IT0	=	0x0088
                           00009F   514 _SM0	=	0x009f
                           00009E   515 _SM1	=	0x009e
                           00009D   516 _SM2	=	0x009d
                           00009C   517 _REN	=	0x009c
                           00009B   518 _TB8	=	0x009b
                           00009A   519 _RB8	=	0x009a
                           000099   520 _TI	=	0x0099
                           000098   521 _RI	=	0x0098
                           0000CF   522 _TF2	=	0x00cf
                           0000CF   523 _CAP1F	=	0x00cf
                           0000CE   524 _EXF2	=	0x00ce
                           0000CD   525 _RCLK	=	0x00cd
                           0000CC   526 _TCLK	=	0x00cc
                           0000CB   527 _EXEN2	=	0x00cb
                           0000CA   528 _TR2	=	0x00ca
                           0000C9   529 _C_T2	=	0x00c9
                           0000C8   530 _CP_RL2	=	0x00c8
                           0000FF   531 _S0_FST_ACT	=	0x00ff
                           0000FE   532 _S0_IF_OV	=	0x00fe
                           0000FD   533 _S0_IF_FIRST	=	0x00fd
                           0000FC   534 _S0_IF_BYTE	=	0x00fc
                           0000FB   535 _S0_FREE	=	0x00fb
                           0000FA   536 _S0_T_FIFO	=	0x00fa
                           0000F8   537 _S0_R_FIFO	=	0x00f8
                           0000F7   538 _ADC_START	=	0x00f7
                                    539 ;--------------------------------------------------------
                                    540 ; overlayable register banks
                                    541 ;--------------------------------------------------------
                                    542 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        543 	.ds 8
                                    544 ;--------------------------------------------------------
                                    545 ; internal ram data
                                    546 ;--------------------------------------------------------
                                    547 	.area DSEG    (DATA)
      000042                        548 _vial_handle_cmd_sloc0_1_0:
      000042                        549 	.ds 2
      000044                        550 _vial_handle_cmd_sloc1_1_0:
      000044                        551 	.ds 2
      000046                        552 _vial_handle_cmd_sloc2_1_0:
      000046                        553 	.ds 2
      000048                        554 _vial_handle_cmd_sloc3_1_0:
      000048                        555 	.ds 2
                                    556 ;--------------------------------------------------------
                                    557 ; overlayable items in internal ram
                                    558 ;--------------------------------------------------------
                                    559 ;--------------------------------------------------------
                                    560 ; indirectly addressable internal ram data
                                    561 ;--------------------------------------------------------
                                    562 	.area ISEG    (DATA)
                                    563 ;--------------------------------------------------------
                                    564 ; absolute internal ram data
                                    565 ;--------------------------------------------------------
                                    566 	.area IABS    (ABS,DATA)
                                    567 	.area IABS    (ABS,DATA)
                                    568 ;--------------------------------------------------------
                                    569 ; bit data
                                    570 ;--------------------------------------------------------
                                    571 	.area BSEG    (BIT)
                                    572 ;--------------------------------------------------------
                                    573 ; paged external ram data
                                    574 ;--------------------------------------------------------
                                    575 	.area PSEG    (PAG,XDATA)
                                    576 ;--------------------------------------------------------
                                    577 ; uninitialized external ram data
                                    578 ;--------------------------------------------------------
                                    579 	.area XSEG    (XDATA)
      000C73                        580 _vial_unlock_timer:
      000C73                        581 	.ds 4
      000C77                        582 _vial_unlock_holding:
      000C77                        583 	.ds 1
      000C78                        584 _vial_keycode_firewall_in_10000_633:
      000C78                        585 	.ds 2
      000C7A                        586 _vial_fill_packet_PARM_2:
      000C7A                        587 	.ds 1
      000C7B                        588 _vial_fill_packet_msg_10000_636:
      000C7B                        589 	.ds 2
      000C7D                        590 _vial_handle_cmd_PARM_2:
      000C7D                        591 	.ds 1
      000C7E                        592 _vial_handle_cmd_data_10000_641:
      000C7E                        593 	.ds 3
      000C81                        594 _vial_handle_cmd_entry_70000_672:
      000C81                        595 	.ds 10
      000C8B                        596 _vial_handle_cmd_entry_70000_673:
      000C8B                        597 	.ds 10
      000C95                        598 _g_vial_magic_keycode_override::
      000C95                        599 	.ds 2
      000C97                        600 _vial_keycode_down_keycode_10000_675:
      000C97                        601 	.ds 2
      000C99                        602 _vial_keycode_down_dummy_event_30000_682:
      000C99                        603 	.ds 6
      000C9F                        604 _vial_keycode_up_keycode_10000_683:
      000C9F                        605 	.ds 2
      000CA1                        606 _vial_keycode_up_dummy_event_30000_690:
      000CA1                        607 	.ds 6
      000CA7                        608 _vial_keycode_tap_keycode_10000_691:
      000CA7                        609 	.ds 2
                                    610 ;--------------------------------------------------------
                                    611 ; absolute external ram data
                                    612 ;--------------------------------------------------------
                                    613 	.area XABS    (ABS,XDATA)
                                    614 ;--------------------------------------------------------
                                    615 ; initialized external ram data
                                    616 ;--------------------------------------------------------
                                    617 	.area XISEG   (XDATA)
      000E45                        618 _vial_unlocked::
      000E45                        619 	.ds 1
      000E46                        620 _vial_unlock_in_progress::
      000E46                        621 	.ds 1
      000E47                        622 _vial_unlock_counter:
      000E47                        623 	.ds 1
      000E48                        624 _vial_unlock_combo_rows:
      000E48                        625 	.ds 2
      000E4A                        626 _vial_unlock_combo_cols:
      000E4A                        627 	.ds 2
                                    628 	.area HOME    (CODE)
                                    629 	.area GSINIT0 (CODE)
                                    630 	.area GSINIT1 (CODE)
                                    631 	.area GSINIT2 (CODE)
                                    632 	.area GSINIT3 (CODE)
                                    633 	.area GSINIT4 (CODE)
                                    634 	.area GSINIT5 (CODE)
                                    635 	.area GSINIT  (CODE)
                                    636 	.area GSFINAL (CODE)
                                    637 	.area CSEG    (CODE)
                                    638 ;--------------------------------------------------------
                                    639 ; global & static initialisations
                                    640 ;--------------------------------------------------------
                                    641 	.area HOME    (CODE)
                                    642 	.area GSINIT  (CODE)
                                    643 	.area GSFINAL (CODE)
                                    644 	.area GSINIT  (CODE)
                                    645 ;--------------------------------------------------------
                                    646 ; Home
                                    647 ;--------------------------------------------------------
                                    648 	.area HOME    (CODE)
                                    649 	.area HOME    (CODE)
                                    650 ;--------------------------------------------------------
                                    651 ; code
                                    652 ;--------------------------------------------------------
                                    653 	.area CSEG    (CODE)
                                    654 ;------------------------------------------------------------
                                    655 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    656 ;------------------------------------------------------------
                                    657 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_176'
                                    658 ;------------------------------------------------------------
                                    659 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    660 ;	-----------------------------------------
                           000007   661 	ar7 = 0x07
                           000006   662 	ar6 = 0x06
                           000005   663 	ar5 = 0x05
                           000004   664 	ar4 = 0x04
                           000003   665 	ar3 = 0x03
                           000002   666 	ar2 = 0x02
                           000001   667 	ar1 = 0x01
                           000000   668 	ar0 = 0x00
                                    669 ;	 function vial_unlock_task
                                    670 ;	-----------------------------------------
      00AED6                        671 _vial_unlock_task:
                                    672 ;	quantum/vial.c:64: if (!vial_unlock_in_progress) return;
      00AED6 90 0E 46         [24]  673 	mov	dptr,#_vial_unlock_in_progress
      00AED9 E0               [24]  674 	movx	a,@dptr
      00AEDA 70 01            [24]  675 	jnz	00131$
      00AEDC 22               [24]  676 	ret
                                    677 ;	quantum/vial.c:65: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00AEDD                        678 00131$:
      00AEDD 7F 00            [12]  679 	mov	r7,#0x00
      00AEDF                        680 00115$:
      00AEDF BF 02 00         [24]  681 	cjne	r7,#0x02,00184$
      00AEE2                        682 00184$:
      00AEE2 50 29            [24]  683 	jnc	00105$
                                    684 ;	quantum/vial.c:66: if (!matrix_is_on(vial_unlock_combo_rows[i], vial_unlock_combo_cols[i])) {
      00AEE4 EF               [12]  685 	mov	a,r7
      00AEE5 12 B5 77         [24]  686 	lcall	_ak820_outline_0130
      00AEE8 FE               [12]  687 	mov	r6,a
      00AEE9 EF               [12]  688 	mov	a,r7
      00AEEA 12 B5 6C         [24]  689 	lcall	_ak820_outline_0129
      00AEED 90 07 A7         [24]  690 	mov	dptr,#_matrix_is_on_PARM_2
      00AEF0 F0               [24]  691 	movx	@dptr,a
      00AEF1 8E 82            [24]  692 	mov	dpl, r6
      00AEF3 C0 07            [24]  693 	push	ar7
      00AEF5 12 5D 6A         [24]  694 	lcall	_matrix_is_on
      00AEF8 E5 82            [12]  695 	mov	a, dpl
      00AEFA D0 07            [24]  696 	pop	ar7
      00AEFC 70 0C            [24]  697 	jnz	00116$
                                    698 ;	quantum/vial.c:67: vial_unlock_holding = false;
      00AEFE 90 0C 77         [24]  699 	mov	dptr,#_vial_unlock_holding
      00AF01 E4               [12]  700 	clr	a
      00AF02 F0               [24]  701 	movx	@dptr,a
                                    702 ;	quantum/vial.c:68: vial_unlock_counter = VIAL_UNLOCK_COUNTER_MAX;
      00AF03 90 0E 47         [24]  703 	mov	dptr,#_vial_unlock_counter
      00AF06 74 1E            [12]  704 	mov	a,#0x1e
      00AF08 F0               [24]  705 	movx	@dptr,a
                                    706 ;	quantum/vial.c:69: return;
      00AF09 22               [24]  707 	ret
      00AF0A                        708 00116$:
                                    709 ;	quantum/vial.c:65: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00AF0A 0F               [12]  710 	inc	r7
      00AF0B 80 D2            [24]  711 	sjmp	00115$
      00AF0D                        712 00105$:
                                    713 ;	quantum/vial.c:72: if (!vial_unlock_holding) {
      00AF0D 90 0C 77         [24]  714 	mov	dptr,#_vial_unlock_holding
      00AF10 E0               [24]  715 	movx	a,@dptr
      00AF11 70 12            [24]  716 	jnz	00107$
                                    717 ;	quantum/vial.c:73: vial_unlock_holding = true;
      00AF13 90 0C 77         [24]  718 	mov	dptr,#_vial_unlock_holding
      00AF16 74 01            [12]  719 	mov	a,#0x01
      00AF18 F0               [24]  720 	movx	@dptr,a
                                    721 ;	quantum/vial.c:74: vial_unlock_timer = timer_read32();
      00AF19 12 4D 6C         [24]  722 	lcall	_timer_read32
      00AF1C 12 53 7E         [24]  723 	lcall	_ak820_outline_0057
      00AF1F 90 0C 73         [24]  724 	mov	dptr,#_vial_unlock_timer
      00AF22 12 93 6C         [24]  725 	lcall	_ak820_outline_0007
      00AF25                        726 00107$:
                                    727 ;	quantum/vial.c:76: uint32_t elapsed = timer_elapsed32(vial_unlock_timer);
      00AF25 90 0C 73         [24]  728 	mov	dptr,#_vial_unlock_timer
      00AF28 12 53 6D         [24]  729 	lcall	_ak820_outline_0054
      00AF2B 12 4D C5         [24]  730 	lcall	_timer_elapsed32
      00AF2E 12 53 7E         [24]  731 	lcall	_ak820_outline_0057
                                    732 ;	quantum/vial.c:80: while (counter && elapsed >= VIAL_UNLOCK_COUNTER_TICK_MS) {
      00AF31 7B 1E            [12]  733 	mov	r3,#0x1e
      00AF33                        734 00109$:
      00AF33 EB               [12]  735 	mov	a,r3
      00AF34 60 22            [24]  736 	jz	00111$
      00AF36 C3               [12]  737 	clr	c
      00AF37 EC               [12]  738 	mov	a,r4
      00AF38 94 64            [12]  739 	subb	a,#0x64
      00AF3A ED               [12]  740 	mov	a,r5
      00AF3B 94 00            [12]  741 	subb	a,#0x00
      00AF3D EE               [12]  742 	mov	a,r6
      00AF3E 94 00            [12]  743 	subb	a,#0x00
      00AF40 EF               [12]  744 	mov	a,r7
      00AF41 94 00            [12]  745 	subb	a,#0x00
      00AF43 40 13            [24]  746 	jc	00111$
                                    747 ;	quantum/vial.c:81: elapsed -= VIAL_UNLOCK_COUNTER_TICK_MS;
      00AF45 EC               [12]  748 	mov	a,r4
      00AF46 24 9C            [12]  749 	add	a,#0x9c
      00AF48 FC               [12]  750 	mov	r4,a
      00AF49 ED               [12]  751 	mov	a,r5
      00AF4A 34 FF            [12]  752 	addc	a,#0xff
      00AF4C FD               [12]  753 	mov	r5,a
      00AF4D EE               [12]  754 	mov	a,r6
      00AF4E 34 FF            [12]  755 	addc	a,#0xff
      00AF50 FE               [12]  756 	mov	r6,a
      00AF51 EF               [12]  757 	mov	a,r7
      00AF52 34 FF            [12]  758 	addc	a,#0xff
      00AF54 FF               [12]  759 	mov	r7,a
                                    760 ;	quantum/vial.c:82: --counter;
      00AF55 1B               [12]  761 	dec	r3
      00AF56 80 DB            [24]  762 	sjmp	00109$
      00AF58                        763 00111$:
                                    764 ;	quantum/vial.c:84: vial_unlock_counter = counter;
      00AF58 90 0E 47         [24]  765 	mov	dptr,#_vial_unlock_counter
      00AF5B EB               [12]  766 	mov	a,r3
      00AF5C F0               [24]  767 	movx	@dptr,a
                                    768 ;	quantum/vial.c:85: if (!counter) {
      00AF5D EB               [12]  769 	mov	a,r3
      00AF5E 70 0A            [24]  770 	jnz	00117$
                                    771 ;	quantum/vial.c:86: vial_unlock_in_progress = 0;
      00AF60 90 0E 46         [24]  772 	mov	dptr,#_vial_unlock_in_progress
      00AF63 E4               [12]  773 	clr	a
      00AF64 F0               [24]  774 	movx	@dptr,a
                                    775 ;	quantum/vial.c:87: vial_unlocked = 1;
      00AF65 90 0E 45         [24]  776 	mov	dptr,#_vial_unlocked
      00AF68 04               [12]  777 	inc	a
      00AF69 F0               [24]  778 	movx	@dptr,a
      00AF6A                        779 00117$:
                                    780 ;	quantum/vial.c:90: }
      00AF6A 22               [24]  781 	ret
                                    782 ;------------------------------------------------------------
                                    783 ;Allocation info for local variables in function 'vial_init'
                                    784 ;------------------------------------------------------------
                                    785 ;	quantum/vial.c:117: void vial_init(void) {
                                    786 ;	-----------------------------------------
                                    787 ;	 function vial_init
                                    788 ;	-----------------------------------------
      00AF6B                        789 _vial_init:
                                    790 ;	quantum/vial.c:119: ak820_settings_init();
      00AF6B 12 45 4C         [24]  791 	lcall	_ak820_settings_init
                                    792 ;	quantum/vial.c:125: reload_combo();
                                    793 ;	quantum/vial.c:130: }
      00AF6E 02 35 38         [24]  794 	ljmp	_ak820_combo_reload
                                    795 ;------------------------------------------------------------
                                    796 ;Allocation info for local variables in function 'vial_keycode_firewall'
                                    797 ;------------------------------------------------------------
                                    798 ;in            Allocated with name '_vial_keycode_firewall_in_10000_633'
                                    799 ;------------------------------------------------------------
                                    800 ;	quantum/vial.c:132: __attribute__((unused)) static uint16_t vial_keycode_firewall(uint16_t in) {
                                    801 ;	-----------------------------------------
                                    802 ;	 function vial_keycode_firewall
                                    803 ;	-----------------------------------------
      00AF71                        804 _vial_keycode_firewall:
      00AF71 12 38 52         [24]  805 	lcall	_ak820_outline_0106
      00AF74 90 0C 78         [24]  806 	mov	dptr,#_vial_keycode_firewall_in_10000_633
      00AF77 12 38 57         [24]  807 	lcall	_ak820_outline_0107
                                    808 ;	quantum/vial.c:133: if (in == QK_BOOT && !vial_unlocked)
      00AF7A 90 0C 78         [24]  809 	mov	dptr,#_vial_keycode_firewall_in_10000_633
      00AF7D 12 37 D0         [24]  810 	lcall	_ak820_outline_0010
      00AF80 BC 00 0D         [24]  811 	cjne	r4,#0x00,00102$
      00AF83 BD 7C 0A         [24]  812 	cjne	r5,#0x7c,00102$
      00AF86 90 0E 45         [24]  813 	mov	dptr,#_vial_unlocked
      00AF89 E0               [24]  814 	movx	a,@dptr
      00AF8A 70 04            [24]  815 	jnz	00102$
                                    816 ;	quantum/vial.c:134: return 0;
      00AF8C 90 00 00         [24]  817 	mov	dptr,#0x0000
      00AF8F 22               [24]  818 	ret
      00AF90                        819 00102$:
                                    820 ;	quantum/vial.c:135: return in;
      00AF90 12 43 2B         [24]  821 	lcall	_ak820_outline_0121
                                    822 ;	quantum/vial.c:136: }
      00AF93 22               [24]  823 	ret
                                    824 ;------------------------------------------------------------
                                    825 ;Allocation info for local variables in function 'vial_fill_packet'
                                    826 ;------------------------------------------------------------
                                    827 ;value         Allocated with name '_vial_fill_packet_PARM_2'
                                    828 ;msg           Allocated with name '_vial_fill_packet_msg_10000_636'
                                    829 ;i             Allocated with name '_vial_fill_packet_i_20000_638'
                                    830 ;------------------------------------------------------------
                                    831 ;	quantum/vial.c:139: static void vial_fill_packet(uint8_t __xdata *msg, uint8_t value) {
                                    832 ;	-----------------------------------------
                                    833 ;	 function vial_fill_packet
                                    834 ;	-----------------------------------------
      00AF94                        835 _vial_fill_packet:
      00AF94 12 38 52         [24]  836 	lcall	_ak820_outline_0106
      00AF97 90 0C 7B         [24]  837 	mov	dptr,#_vial_fill_packet_msg_10000_636
      00AF9A 12 38 57         [24]  838 	lcall	_ak820_outline_0107
                                    839 ;	quantum/vial.c:140: for (uint8_t i = 0; i < VIAL_RAW_EPSIZE; ++i) msg[i] = value;
      00AF9D 90 0C 7B         [24]  840 	mov	dptr,#_vial_fill_packet_msg_10000_636
      00AFA0 12 37 FC         [24]  841 	lcall	_ak820_outline_0051
      00AFA3 90 0C 7A         [24]  842 	mov	dptr,#_vial_fill_packet_PARM_2
      00AFA6 E0               [24]  843 	movx	a,@dptr
      00AFA7 FD               [12]  844 	mov	r5,a
      00AFA8 7C 00            [12]  845 	mov	r4,#0x00
      00AFAA                        846 00103$:
      00AFAA BC 20 00         [24]  847 	cjne	r4,#0x20,00122$
      00AFAD                        848 00122$:
      00AFAD 50 09            [24]  849 	jnc	00105$
      00AFAF EC               [12]  850 	mov	a,r4
      00AFB0 12 37 EC         [24]  851 	lcall	_ak820_outline_0017
      00AFB3 ED               [12]  852 	mov	a,r5
      00AFB4 F0               [24]  853 	movx	@dptr,a
      00AFB5 0C               [12]  854 	inc	r4
      00AFB6 80 F2            [24]  855 	sjmp	00103$
      00AFB8                        856 00105$:
                                    857 ;	quantum/vial.c:141: }
      00AFB8 22               [24]  858 	ret
                                    859 ;------------------------------------------------------------
                                    860 ;Allocation info for local variables in function 'vial_release_held_state'
                                    861 ;------------------------------------------------------------
                                    862 ;	quantum/vial.c:152: static void vial_release_held_state(void) {
                                    863 ;	-----------------------------------------
                                    864 ;	 function vial_release_held_state
                                    865 ;	-----------------------------------------
      00AFB9                        866 _vial_release_held_state:
                                    867 ;	quantum/vial.c:174: repeat_key_cancel();
      00AFB9 12 A3 F9         [24]  868 	lcall	_repeat_key_cancel
                                    869 ;	quantum/vial.c:176: clear_keyboard();
                                    870 ;	quantum/vial.c:177: }
      00AFBC 02 7A 45         [24]  871 	ljmp	_clear_keyboard
                                    872 ;------------------------------------------------------------
                                    873 ;Allocation info for local variables in function 'vial_handle_cmd'
                                    874 ;------------------------------------------------------------
                                    875 ;sloc0         Allocated with name '_vial_handle_cmd_sloc0_1_0'
                                    876 ;sloc1         Allocated with name '_vial_handle_cmd_sloc1_1_0'
                                    877 ;sloc2         Allocated with name '_vial_handle_cmd_sloc2_1_0'
                                    878 ;sloc3         Allocated with name '_vial_handle_cmd_sloc3_1_0'
                                    879 ;length        Allocated with name '_vial_handle_cmd_PARM_2'
                                    880 ;data          Allocated with name '_vial_handle_cmd_data_10000_641'
                                    881 ;msg           Allocated with name '_vial_handle_cmd_msg_10000_642'
                                    882 ;i             Allocated with name '_vial_handle_cmd_i_50000_647'
                                    883 ;sz            Allocated with name '_vial_handle_cmd_sz_40000_648'
                                    884 ;page          Allocated with name '_vial_handle_cmd_page_40001_651'
                                    885 ;start         Allocated with name '_vial_handle_cmd_start_40002_653'
                                    886 ;remaining     Allocated with name '_vial_handle_cmd_remaining_40002_653'
                                    887 ;count         Allocated with name '_vial_handle_cmd_count_40002_653'
                                    888 ;i             Allocated with name '_vial_handle_cmd_i_50002_654'
                                    889 ;layer         Allocated with name '_vial_handle_cmd_layer_40000_655'
                                    890 ;idx           Allocated with name '_vial_handle_cmd_idx_40000_655'
                                    891 ;keycode       Allocated with name '_vial_handle_cmd_keycode_40000_655'
                                    892 ;i             Allocated with name '_vial_handle_cmd_i_50000_658'
                                    893 ;qsid_greater_than Allocated with name '_vial_handle_cmd_qsid_greater_than_40000_664'
                                    894 ;qsid          Allocated with name '_vial_handle_cmd_qsid_40000_665'
                                    895 ;qsid          Allocated with name '_vial_handle_cmd_qsid_40000_666'
                                    896 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_672'
                                    897 ;entry         Allocated with name '_vial_handle_cmd_entry_70000_672'
                                    898 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_673'
                                    899 ;entry         Allocated with name '_vial_handle_cmd_entry_70000_673'
                                    900 ;------------------------------------------------------------
                                    901 ;	quantum/vial.c:180: void vial_handle_cmd(uint8_t *data, uint8_t length) {
                                    902 ;	-----------------------------------------
                                    903 ;	 function vial_handle_cmd
                                    904 ;	-----------------------------------------
      00AFBF                        905 _vial_handle_cmd:
      00AFBF 12 42 D5         [24]  906 	lcall	_ak820_outline_0037
      00AFC2 90 0C 7E         [24]  907 	mov	dptr,#_vial_handle_cmd_data_10000_641
      00AFC5 12 37 E4         [24]  908 	lcall	_ak820_outline_0016
                                    909 ;	quantum/vial.c:184: uint8_t __xdata *msg = (uint8_t __xdata *)data;
      00AFC8 90 0C 7E         [24]  910 	mov	dptr,#_vial_handle_cmd_data_10000_641
      00AFCB 12 37 FC         [24]  911 	lcall	_ak820_outline_0051
                                    912 ;	quantum/vial.c:189: if (length != VIAL_RAW_EPSIZE)
      00AFCE 90 0C 7D         [24]  913 	mov	dptr,#_vial_handle_cmd_PARM_2
      00AFD1 E0               [24]  914 	movx	a,@dptr
      00AFD2 FD               [12]  915 	mov	r5,a
      00AFD3 BD 20 02         [24]  916 	cjne	r5,#0x20,00261$
      00AFD6 80 01            [24]  917 	sjmp	00102$
      00AFD8                        918 00261$:
                                    919 ;	quantum/vial.c:190: return;
      00AFD8 22               [24]  920 	ret
      00AFD9                        921 00102$:
                                    922 ;	quantum/vial.c:193: switch (msg[1]) {
      00AFD9 74 01            [12]  923 	mov	a,#0x01
      00AFDB 12 4C AB         [24]  924 	lcall	_ak820_outline_0012
      00AFDE FA               [12]  925 	mov  r2,a
      00AFDF 24 F2            [12]  926 	add	a,#0xff - 0x0d
      00AFE1 50 01            [24]  927 	jnc	00262$
      00AFE3 22               [24]  928 	ret
      00AFE4                        929 00262$:
                                    930 ;	free result
      00AFE4 EA               [12]  931 	mov	a,r2
      00AFE5 24 0A            [12]  932 	add	a,#(00263$-3-.)
      00AFE7 83               [24]  933 	movc	a,@a+pc
      00AFE8 F5 82            [12]  934 	mov	dpl,a
      00AFEA EA               [12]  935 	mov	a,r2
      00AFEB 24 12            [12]  936 	add	a,#(00264$-3-.)
      00AFED 83               [24]  937 	movc	a,@a+pc
      00AFEE F5 83            [12]  938 	mov	dph,a
      00AFF0 E4               [12]  939 	clr	a
      00AFF1 73               [24]  940 	jmp	@a+dptr
      00AFF2                        941 00263$:
      00AFF2 0E                     942 	.db	00103$
      00AFF3 57                     943 	.db	00105$
      00AFF4 6B                     944 	.db	00106$
      00AFF5 22                     945 	.db	00112$
      00AFF6 9B                     946 	.db	00113$
      00AFF7 E9                     947 	.db	00114$
      00AFF8 5A                     948 	.db	00116$
      00AFF9 75                     949 	.db	00119$
      00AFFA 92                     950 	.db	00120$
      00AFFB A0                     951 	.db	00121$
      00AFFC BF                     952 	.db	00122$
      00AFFD F1                     953 	.db	00123$
      00AFFE 27                     954 	.db	00124$
      00AFFF 3A                     955 	.db	00125$
      00B000                        956 00264$:
      00B000 B0                     957 	.db	00103$>>8
      00B001 B0                     958 	.db	00105$>>8
      00B002 B0                     959 	.db	00106$>>8
      00B003 B1                     960 	.db	00112$>>8
      00B004 B1                     961 	.db	00113$>>8
      00B005 B1                     962 	.db	00114$>>8
      00B006 B2                     963 	.db	00116$>>8
      00B007 B2                     964 	.db	00119$>>8
      00B008 B2                     965 	.db	00120$>>8
      00B009 B2                     966 	.db	00121$>>8
      00B00A B2                     967 	.db	00122$>>8
      00B00B B2                     968 	.db	00123$>>8
      00B00C B3                     969 	.db	00124$>>8
      00B00D B3                     970 	.db	00125$>>8
                                    971 ;	quantum/vial.c:195: case vial_get_keyboard_id: {
      00B00E                        972 00103$:
                                    973 ;	quantum/vial.c:198: VIAL_FILL_PACKET(msg, 0, length);
      00B00E 90 0C 7A         [24]  974 	mov	dptr,#_vial_fill_packet_PARM_2
      00B011 E4               [12]  975 	clr	a
      00B012 12 42 F9         [24]  976 	lcall	_ak820_outline_0061
      00B015 C0 07            [24]  977 	push	ar7
      00B017 C0 06            [24]  978 	push	ar6
      00B019 12 AF 94         [24]  979 	lcall	_vial_fill_packet
      00B01C D0 06            [24]  980 	pop	ar6
      00B01E D0 07            [24]  981 	pop	ar7
                                    982 ;	quantum/vial.c:199: msg[0] = VIAL_PROTOCOL_VERSION & 0xFF;
      00B020 12 43 2B         [24]  983 	lcall	_ak820_outline_0121
      00B023 74 06            [12]  984 	mov	a,#0x06
      00B025 12 42 F9         [24]  985 	lcall	_ak820_outline_0061
                                    986 ;	quantum/vial.c:200: msg[1] = (VIAL_PROTOCOL_VERSION >> 8) & 0xFF;
      00B028 A3               [24]  987 	inc	dptr
      00B029 E4               [12]  988 	clr	a
      00B02A 12 42 CD         [24]  989 	lcall	_ak820_outline_0031
                                    990 ;	quantum/vial.c:201: msg[2] = (VIAL_PROTOCOL_VERSION >> 16) & 0xFF;
      00B02D 12 42 CD         [24]  991 	lcall	_ak820_outline_0031
                                    992 ;	quantum/vial.c:202: msg[3] = (VIAL_PROTOCOL_VERSION >> 24) & 0xFF;
      00B030 A3               [24]  993 	inc	dptr
      00B031 F0               [24]  994 	movx	@dptr,a
                                    995 ;	quantum/vial.c:203: for (uint8_t i = 0; i < 8; ++i) msg[4 + i] = pgm_read_byte(&keyboard_uid[i]);
      00B032 FA               [12]  996 	mov	r2,a
      00B033                        997 00134$:
      00B033 BA 08 00         [24]  998 	cjne	r2,#0x08,00265$
      00B036                        999 00265$:
      00B036 50 16            [24] 1000 	jnc	00104$
      00B038 8A 01            [24] 1001 	mov	ar1,r2
      00B03A 74 04            [12] 1002 	mov	a,#0x04
      00B03C 29               [12] 1003 	add	a, r1
      00B03D 2E               [12] 1004 	add	a, r6
      00B03E F8               [12] 1005 	mov	r0,a
      00B03F E4               [12] 1006 	clr	a
      00B040 3F               [12] 1007 	addc	a,r7
      00B041 F9               [12] 1008 	mov	r1,a
      00B042 EA               [12] 1009 	mov	a,r2
      00B043 90 C3 26         [24] 1010 	mov	dptr,#_vial_handle_cmd_keyboard_uid_40000_646
      00B046 93               [24] 1011 	movc	a,@a+dptr
      00B047 12 38 76         [24] 1012 	lcall	_ak820_outline_0154
      00B04A F0               [24] 1013 	movx	@dptr,a
      00B04B 0A               [12] 1014 	inc	r2
      00B04C 80 E5            [24] 1015 	sjmp	00134$
      00B04E                       1016 00104$:
                                   1017 ;	quantum/vial.c:205: msg[12] = 1; /* bit flag to indicate vialrgb is supported - so third-party apps don't have to query json */
      00B04E 74 0C            [12] 1018 	mov	a,#0x0c
      00B050 12 37 EC         [24] 1019 	lcall	_ak820_outline_0017
      00B053 74 01            [12] 1020 	mov	a,#0x01
      00B055 F0               [24] 1021 	movx	@dptr,a
                                   1022 ;	quantum/vial.c:207: break;
      00B056 22               [24] 1023 	ret
                                   1024 ;	quantum/vial.c:210: case vial_get_size: {
      00B057                       1025 00105$:
                                   1026 ;	quantum/vial.c:212: msg[0] = sz & 0xFF;
      00B057 12 43 2B         [24] 1027 	lcall	_ak820_outline_0121
      00B05A 74 7C            [12] 1028 	mov	a,#0x7c
      00B05C 12 A0 B6         [24] 1029 	lcall	_ak820_outline_0124
                                   1030 ;	quantum/vial.c:213: msg[1] = (sz >> 8) & 0xFF;
      00B05F 74 01            [12] 1031 	mov	a,#0x01
      00B061 12 42 CD         [24] 1032 	lcall	_ak820_outline_0031
                                   1033 ;	quantum/vial.c:214: msg[2] = (sz >> 16) & 0xFF;
      00B064 E4               [12] 1034 	clr	a
      00B065 12 42 CD         [24] 1035 	lcall	_ak820_outline_0031
                                   1036 ;	quantum/vial.c:215: msg[3] = (sz >> 24) & 0xFF;
      00B068 A3               [24] 1037 	inc	dptr
      00B069 F0               [24] 1038 	movx	@dptr,a
                                   1039 ;	quantum/vial.c:216: break;
      00B06A 22               [24] 1040 	ret
                                   1041 ;	quantum/vial.c:219: case vial_get_def: {
      00B06B                       1042 00106$:
                                   1043 ;	quantum/vial.c:226: if (msg[4] | msg[5]) return;
      00B06B 12 AE 9A         [24] 1044 	lcall	_ak820_outline_0022
      00B06E E0               [24] 1045 	movx	a,@dptr
      00B06F FA               [12] 1046 	mov	r2,a
      00B070 12 42 C3         [24] 1047 	lcall	_ak820_outline_0011
      00B073 E0               [24] 1048 	movx	a,@dptr
      00B074 4A               [12] 1049 	orl	a,r2
      00B075 60 01            [24] 1050 	jz	00108$
      00B077 22               [24] 1051 	ret
      00B078                       1052 00108$:
                                   1053 ;	quantum/vial.c:227: uint16_t page = (uint16_t)msg[2] | ((uint16_t)msg[3] << 8);
      00B078 12 37 F4         [24] 1054 	lcall	_ak820_outline_0034
      00B07B F9               [12] 1055 	mov	r1,a
      00B07C 7A 00            [12] 1056 	mov	r2,#0x00
      00B07E 12 AE 91         [24] 1057 	lcall	_ak820_outline_0015
      00B081 F8               [12] 1058 	mov	r0,a
      00B082 C0 06            [24] 1059 	push	ar6
      00B084 C0 07            [24] 1060 	push	ar7
      00B086 88 07            [24] 1061 	mov	ar7,r0
      00B088 E4               [12] 1062 	clr	a
      00B089 49               [12] 1063 	orl	a,r1
      00B08A F5 42            [12] 1064 	mov	_vial_handle_cmd_sloc0_1_0,a
      00B08C EF               [12] 1065 	mov	a,r7
      00B08D 4A               [12] 1066 	orl	a,r2
      00B08E F5 43            [12] 1067 	mov	(_vial_handle_cmd_sloc0_1_0 + 1),a
                                   1068 ;	quantum/vial.c:228: if (page >= (sizeof(keyboard_definition) + VIAL_RAW_EPSIZE - 1) / VIAL_RAW_EPSIZE) return;
      00B090 C3               [12] 1069 	clr	c
      00B091 E5 42            [12] 1070 	mov	a,_vial_handle_cmd_sloc0_1_0
      00B093 94 0C            [12] 1071 	subb	a,#0x0c
      00B095 E5 43            [12] 1072 	mov	a,(_vial_handle_cmd_sloc0_1_0 + 1)
      00B097 94 00            [12] 1073 	subb	a,#0x00
      00B099 D0 07            [24] 1074 	pop	ar7
      00B09B D0 06            [24] 1075 	pop	ar6
      00B09D 40 01            [24] 1076 	jc	00110$
      00B09F 22               [24] 1077 	ret
      00B0A0                       1078 00110$:
                                   1079 ;	quantum/vial.c:229: uint16_t start = page * VIAL_RAW_EPSIZE;
      00B0A0 C0 06            [24] 1080 	push	ar6
      00B0A2 C0 07            [24] 1081 	push	ar7
      00B0A4 A9 42            [24] 1082 	mov	r1,_vial_handle_cmd_sloc0_1_0
      00B0A6 E5 43            [12] 1083 	mov	a,(_vial_handle_cmd_sloc0_1_0 + 1)
      00B0A8 C4               [12] 1084 	swap	a
      00B0A9 23               [12] 1085 	rl	a
      00B0AA 54 E0            [12] 1086 	anl	a,#0xe0
      00B0AC C9               [12] 1087 	xch	a,r1
      00B0AD C4               [12] 1088 	swap	a
      00B0AE 23               [12] 1089 	rl	a
      00B0AF C9               [12] 1090 	xch	a,r1
      00B0B0 69               [12] 1091 	xrl	a,r1
      00B0B1 C9               [12] 1092 	xch	a,r1
      00B0B2 54 E0            [12] 1093 	anl	a,#0xe0
      00B0B4 C9               [12] 1094 	xch	a,r1
      00B0B5 69               [12] 1095 	xrl	a,r1
      00B0B6 FA               [12] 1096 	mov	r2,a
      00B0B7 89 44            [24] 1097 	mov	_vial_handle_cmd_sloc1_1_0,r1
      00B0B9 8A 45            [24] 1098 	mov	(_vial_handle_cmd_sloc1_1_0 + 1),r2
                                   1099 ;	quantum/vial.c:230: uint16_t remaining = sizeof(keyboard_definition) - start;
      00B0BB 74 7C            [12] 1100 	mov	a,#0x7c
      00B0BD C3               [12] 1101 	clr	c
      00B0BE 95 44            [12] 1102 	subb	a,_vial_handle_cmd_sloc1_1_0
      00B0C0 F8               [12] 1103 	mov	r0,a
      00B0C1 74 01            [12] 1104 	mov	a,#0x01
      00B0C3 95 45            [12] 1105 	subb	a,(_vial_handle_cmd_sloc1_1_0 + 1)
      00B0C5 FF               [12] 1106 	mov	r7,a
                                   1107 ;	quantum/vial.c:231: uint8_t count = remaining < VIAL_RAW_EPSIZE ? remaining : VIAL_RAW_EPSIZE;
      00B0C6 88 42            [24] 1108 	mov	_vial_handle_cmd_sloc0_1_0,r0
      00B0C8 8F 43            [24] 1109 	mov	(_vial_handle_cmd_sloc0_1_0 + 1),r7
      00B0CA C3               [12] 1110 	clr	c
      00B0CB E5 42            [12] 1111 	mov	a,_vial_handle_cmd_sloc0_1_0
      00B0CD 94 20            [12] 1112 	subb	a,#0x20
      00B0CF E5 43            [12] 1113 	mov	a,(_vial_handle_cmd_sloc0_1_0 + 1)
      00B0D1 94 00            [12] 1114 	subb	a,#0x00
      00B0D3 D0 07            [24] 1115 	pop	ar7
      00B0D5 D0 06            [24] 1116 	pop	ar6
      00B0D7 50 04            [24] 1117 	jnc	00144$
      00B0D9 A8 42            [24] 1118 	mov	r0,_vial_handle_cmd_sloc0_1_0
      00B0DB 80 02            [24] 1119 	sjmp	00145$
      00B0DD                       1120 00144$:
      00B0DD 78 20            [12] 1121 	mov	r0,#0x20
      00B0DF                       1122 00145$:
                                   1123 ;	quantum/vial.c:232: for (uint8_t i = 0; i < count; ++i) msg[i] = pgm_read_byte(&keyboard_definition[start + i]);
      00B0DF 75 42 00         [24] 1124 	mov	_vial_handle_cmd_sloc0_1_0,#0x00
      00B0E2                       1125 00137$:
      00B0E2 C3               [12] 1126 	clr	c
      00B0E3 E5 42            [12] 1127 	mov	a,_vial_handle_cmd_sloc0_1_0
      00B0E5 98               [12] 1128 	subb	a,r0
      00B0E6 40 01            [24] 1129 	jc	00270$
      00B0E8 22               [24] 1130 	ret
      00B0E9                       1131 00270$:
      00B0E9 C0 00            [24] 1132 	push	ar0
      00B0EB E5 42            [12] 1133 	mov	a,_vial_handle_cmd_sloc0_1_0
      00B0ED 2E               [12] 1134 	add	a, r6
      00B0EE F5 46            [12] 1135 	mov	_vial_handle_cmd_sloc2_1_0,a
      00B0F0 E4               [12] 1136 	clr	a
      00B0F1 3F               [12] 1137 	addc	a, r7
      00B0F2 F5 47            [12] 1138 	mov	(_vial_handle_cmd_sloc2_1_0 + 1),a
      00B0F4 85 42 48         [24] 1139 	mov	_vial_handle_cmd_sloc3_1_0,_vial_handle_cmd_sloc0_1_0
      00B0F7 75 49 00         [24] 1140 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),#0x00
      00B0FA A8 44            [24] 1141 	mov	r0,_vial_handle_cmd_sloc1_1_0
      00B0FC AA 45            [24] 1142 	mov	r2,(_vial_handle_cmd_sloc1_1_0 + 1)
      00B0FE E5 48            [12] 1143 	mov	a,_vial_handle_cmd_sloc3_1_0
      00B100 28               [12] 1144 	add	a, r0
      00B101 F8               [12] 1145 	mov	r0,a
      00B102 E5 49            [12] 1146 	mov	a,(_vial_handle_cmd_sloc3_1_0 + 1)
      00B104 3A               [12] 1147 	addc	a, r2
      00B105 FA               [12] 1148 	mov	r2,a
      00B106 E8               [12] 1149 	mov	a,r0
      00B107 24 AA            [12] 1150 	add	a, #_keyboard_definition
      00B109 F5 82            [12] 1151 	mov	dpl,a
      00B10B EA               [12] 1152 	mov	a,r2
      00B10C 34 C1            [12] 1153 	addc	a, #(_keyboard_definition >> 8)
      00B10E F5 83            [12] 1154 	mov	dph,a
      00B110 E4               [12] 1155 	clr	a
      00B111 93               [24] 1156 	movc	a,@a+dptr
      00B112 85 46 82         [24] 1157 	mov	dpl,_vial_handle_cmd_sloc2_1_0
      00B115 85 47 83         [24] 1158 	mov	dph,(_vial_handle_cmd_sloc2_1_0 + 1)
      00B118 F0               [24] 1159 	movx	@dptr,a
      00B119 E5 42            [12] 1160 	mov	a,_vial_handle_cmd_sloc0_1_0
      00B11B 04               [12] 1161 	inc	a
      00B11C F5 42            [12] 1162 	mov	_vial_handle_cmd_sloc0_1_0,a
      00B11E D0 00            [24] 1163 	pop	ar0
                                   1164 ;	quantum/vial.c:246: case vial_get_encoder: {
      00B120 80 C0            [24] 1165 	sjmp	00137$
      00B122                       1166 00112$:
                                   1167 ;	quantum/vial.c:247: uint8_t layer = msg[2];
      00B122 74 02            [12] 1168 	mov	a,#0x02
      00B124 2E               [12] 1169 	add	a, r6
      00B125 F5 46            [12] 1170 	mov	_vial_handle_cmd_sloc2_1_0,a
      00B127 E4               [12] 1171 	clr	a
      00B128 3F               [12] 1172 	addc	a, r7
      00B129 F5 47            [12] 1173 	mov	(_vial_handle_cmd_sloc2_1_0 + 1),a
      00B12B 85 46 82         [24] 1174 	mov	dpl,_vial_handle_cmd_sloc2_1_0
      00B12E 85 47 83         [24] 1175 	mov	dph,(_vial_handle_cmd_sloc2_1_0 + 1)
      00B131 E0               [24] 1176 	movx	a,@dptr
      00B132 F5 48            [12] 1177 	mov	_vial_handle_cmd_sloc3_1_0,a
                                   1178 ;	quantum/vial.c:248: uint8_t idx = msg[3];
      00B134 74 03            [12] 1179 	mov	a,#0x03
      00B136 2E               [12] 1180 	add	a, r6
      00B137 F5 42            [12] 1181 	mov	_vial_handle_cmd_sloc0_1_0,a
      00B139 E4               [12] 1182 	clr	a
      00B13A 3F               [12] 1183 	addc	a, r7
      00B13B F5 43            [12] 1184 	mov	(_vial_handle_cmd_sloc0_1_0 + 1),a
      00B13D 85 42 82         [24] 1185 	mov	dpl,_vial_handle_cmd_sloc0_1_0
      00B140 85 43 83         [24] 1186 	mov	dph,(_vial_handle_cmd_sloc0_1_0 + 1)
      00B143 E0               [24] 1187 	movx	a,@dptr
                                   1188 ;	quantum/vial.c:249: uint16_t keycode = dynamic_keymap_get_encoder(layer, idx, 0);
      00B144 F5 44            [12] 1189 	mov	_vial_handle_cmd_sloc1_1_0,a
      00B146 90 0B 27         [24] 1190 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      00B149 F0               [24] 1191 	movx	@dptr,a
      00B14A 90 0B 28         [24] 1192 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      00B14D E4               [12] 1193 	clr	a
      00B14E F0               [24] 1194 	movx	@dptr,a
      00B14F 85 48 82         [24] 1195 	mov	dpl, _vial_handle_cmd_sloc3_1_0
      00B152 C0 07            [24] 1196 	push	ar7
      00B154 C0 06            [24] 1197 	push	ar6
      00B156 C0 04            [24] 1198 	push	ar4
      00B158 C0 03            [24] 1199 	push	ar3
      00B15A 12 87 EE         [24] 1200 	lcall	_dynamic_keymap_get_encoder
      00B15D 12 4D 22         [24] 1201 	lcall	_ak820_outline_0189
      00B160 D0 03            [24] 1202 	pop	ar3
      00B162 D0 04            [24] 1203 	pop	ar4
      00B164 D0 06            [24] 1204 	pop	ar6
      00B166 D0 07            [24] 1205 	pop	ar7
                                   1206 ;	quantum/vial.c:250: msg[0]  = keycode >> 8;
      00B168 8A 00            [24] 1207 	mov	ar0,r2
      00B16A 12 43 2B         [24] 1208 	lcall	_ak820_outline_0121
      00B16D E8               [12] 1209 	mov	a,r0
      00B16E 12 A0 B6         [24] 1210 	lcall	_ak820_outline_0124
                                   1211 ;	quantum/vial.c:251: msg[1]  = keycode & 0xFF;
      00B171 E9               [12] 1212 	mov	a,r1
      00B172 F0               [24] 1213 	movx	@dptr,a
                                   1214 ;	quantum/vial.c:252: keycode = dynamic_keymap_get_encoder(layer, idx, 1);
      00B173 90 0B 27         [24] 1215 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      00B176 E5 44            [12] 1216 	mov	a,_vial_handle_cmd_sloc1_1_0
      00B178 F0               [24] 1217 	movx	@dptr,a
      00B179 90 0B 28         [24] 1218 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      00B17C 74 01            [12] 1219 	mov	a,#0x01
      00B17E F0               [24] 1220 	movx	@dptr,a
      00B17F 85 48 82         [24] 1221 	mov	dpl, _vial_handle_cmd_sloc3_1_0
      00B182 12 87 EE         [24] 1222 	lcall	_dynamic_keymap_get_encoder
      00B185 12 4D 22         [24] 1223 	lcall	_ak820_outline_0189
                                   1224 ;	quantum/vial.c:253: msg[2] = keycode >> 8;
      00B188 8A 00            [24] 1225 	mov	ar0,r2
      00B18A 85 46 82         [24] 1226 	mov	dpl,_vial_handle_cmd_sloc2_1_0
      00B18D 85 47 83         [24] 1227 	mov	dph,(_vial_handle_cmd_sloc2_1_0 + 1)
      00B190 E8               [12] 1228 	mov	a,r0
      00B191 F0               [24] 1229 	movx	@dptr,a
                                   1230 ;	quantum/vial.c:254: msg[3] = keycode & 0xFF;
      00B192 85 42 82         [24] 1231 	mov	dpl,_vial_handle_cmd_sloc0_1_0
      00B195 85 43 83         [24] 1232 	mov	dph,(_vial_handle_cmd_sloc0_1_0 + 1)
      00B198 E9               [12] 1233 	mov	a,r1
      00B199 F0               [24] 1234 	movx	@dptr,a
                                   1235 ;	quantum/vial.c:255: break;
      00B19A 22               [24] 1236 	ret
                                   1237 ;	quantum/vial.c:257: case vial_set_encoder: {
      00B19B                       1238 00113$:
                                   1239 ;	quantum/vial.c:258: dynamic_keymap_set_encoder(msg[2], msg[3], msg[4], vial_keycode_firewall((msg[5] << 8) | msg[6]));
      00B19B 12 37 F4         [24] 1240 	lcall	_ak820_outline_0034
      00B19E F5 44            [12] 1241 	mov	_vial_handle_cmd_sloc1_1_0,a
      00B1A0 12 AE 91         [24] 1242 	lcall	_ak820_outline_0015
      00B1A3 F5 46            [12] 1243 	mov	_vial_handle_cmd_sloc2_1_0,a
      00B1A5 12 AE 9A         [24] 1244 	lcall	_ak820_outline_0022
      00B1A8 E0               [24] 1245 	movx	a,@dptr
                                   1246 ;	assignBit
      00B1A9 24 FF            [12] 1247 	add	a,#0xff
      00B1AB E4               [12] 1248 	clr	a
      00B1AC 33               [12] 1249 	rlc	a
      00B1AD F5 48            [12] 1250 	mov	_vial_handle_cmd_sloc3_1_0,a
      00B1AF 12 42 C3         [24] 1251 	lcall	_ak820_outline_0011
      00B1B2 E0               [24] 1252 	movx	a,@dptr
      00B1B3 F8               [12] 1253 	mov	r0,a
      00B1B4 79 00            [12] 1254 	mov	r1,#0x00
      00B1B6 88 43            [24] 1255 	mov	(_vial_handle_cmd_sloc0_1_0 + 1),r0
      00B1B8 89 42            [24] 1256 	mov	_vial_handle_cmd_sloc0_1_0,r1
      00B1BA 74 06            [12] 1257 	mov	a,#0x06
      00B1BC 12 37 EC         [24] 1258 	lcall	_ak820_outline_0017
      00B1BF E0               [24] 1259 	movx	a,@dptr
      00B1C0 F9               [12] 1260 	mov	r1,a
      00B1C1 7A 00            [12] 1261 	mov	r2,#0x00
      00B1C3 E5 43            [12] 1262 	mov	a,(_vial_handle_cmd_sloc0_1_0 + 1)
      00B1C5 42 02            [12] 1263 	orl	ar2,a
      00B1C7 89 82            [24] 1264 	mov	dpl, r1
      00B1C9 8A 83            [24] 1265 	mov	dph, r2
      00B1CB 12 AF 71         [24] 1266 	lcall	_vial_keycode_firewall
      00B1CE 12 4D 22         [24] 1267 	lcall	_ak820_outline_0189
      00B1D1 90 0B 2A         [24] 1268 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      00B1D4 E5 46            [12] 1269 	mov	a,_vial_handle_cmd_sloc2_1_0
      00B1D6 F0               [24] 1270 	movx	@dptr,a
      00B1D7 90 0B 2B         [24] 1271 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      00B1DA E5 48            [12] 1272 	mov	a,_vial_handle_cmd_sloc3_1_0
      00B1DC F0               [24] 1273 	movx	@dptr,a
      00B1DD 90 0B 2C         [24] 1274 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      00B1E0 12 4D 15         [24] 1275 	lcall	_ak820_outline_0139
      00B1E3 85 44 82         [24] 1276 	mov	dpl, _vial_handle_cmd_sloc1_1_0
                                   1277 ;	quantum/vial.c:259: break;
      00B1E6 02 88 56         [24] 1278 	ljmp	_dynamic_keymap_set_encoder
                                   1279 ;	quantum/vial.c:262: case vial_get_unlock_status: {
      00B1E9                       1280 00114$:
                                   1281 ;	quantum/vial.c:264: VIAL_FILL_PACKET(msg, 0xFF, length);
      00B1E9 90 0C 7A         [24] 1282 	mov	dptr,#_vial_fill_packet_PARM_2
      00B1EC 74 FF            [12] 1283 	mov	a,#0xff
      00B1EE 12 42 F9         [24] 1284 	lcall	_ak820_outline_0061
      00B1F1 C0 07            [24] 1285 	push	ar7
      00B1F3 C0 06            [24] 1286 	push	ar6
      00B1F5 12 AF 94         [24] 1287 	lcall	_vial_fill_packet
      00B1F8 D0 06            [24] 1288 	pop	ar6
      00B1FA D0 07            [24] 1289 	pop	ar7
                                   1290 ;	quantum/vial.c:266: msg[0] = vial_unlocked;
      00B1FC 90 0E 45         [24] 1291 	mov	dptr,#_vial_unlocked
      00B1FF 12 43 0C         [24] 1292 	lcall	_ak820_outline_0094
                                   1293 ;	quantum/vial.c:268: msg[1] = vial_unlock_in_progress;
      00B202 74 01            [12] 1294 	mov	a,#0x01
      00B204 2E               [12] 1295 	add	a, r6
      00B205 F9               [12] 1296 	mov	r1,a
      00B206 E4               [12] 1297 	clr	a
      00B207 3F               [12] 1298 	addc	a, r7
      00B208 FA               [12] 1299 	mov	r2,a
      00B209 90 0E 46         [24] 1300 	mov	dptr,#_vial_unlock_in_progress
      00B20C E0               [24] 1301 	movx	a,@dptr
      00B20D 12 70 5B         [24] 1302 	lcall	_ak820_outline_0141
                                   1303 ;	quantum/vial.c:271: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B210 7A 00            [12] 1304 	mov	r2,#0x00
      00B212                       1305 00140$:
      00B212 BA 02 00         [24] 1306 	cjne	r2,#0x02,00271$
      00B215                       1307 00271$:
      00B215 40 01            [24] 1308 	jc	00272$
      00B217 22               [24] 1309 	ret
      00B218                       1310 00272$:
                                   1311 ;	quantum/vial.c:272: msg[2 + i * 2] = vial_unlock_combo_rows[i];
      00B218 8A 00            [24] 1312 	mov	ar0,r2
      00B21A 79 00            [12] 1313 	mov	r1,#0x00
      00B21C E8               [12] 1314 	mov	a,r0
      00B21D 28               [12] 1315 	add	a,r0
      00B21E F5 48            [12] 1316 	mov	_vial_handle_cmd_sloc3_1_0,a
      00B220 E9               [12] 1317 	mov	a,r1
      00B221 33               [12] 1318 	rlc	a
      00B222 F5 49            [12] 1319 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),a
      00B224 74 02            [12] 1320 	mov	a,#0x02
      00B226 25 48            [12] 1321 	add	a, _vial_handle_cmd_sloc3_1_0
      00B228 F8               [12] 1322 	mov	r0,a
      00B229 E4               [12] 1323 	clr	a
      00B22A 35 49            [12] 1324 	addc	a, (_vial_handle_cmd_sloc3_1_0 + 1)
      00B22C F9               [12] 1325 	mov	r1,a
      00B22D E8               [12] 1326 	mov	a,r0
      00B22E 2E               [12] 1327 	add	a, r6
      00B22F F5 46            [12] 1328 	mov	_vial_handle_cmd_sloc2_1_0,a
      00B231 E9               [12] 1329 	mov	a,r1
      00B232 3F               [12] 1330 	addc	a, r7
      00B233 F5 47            [12] 1331 	mov	(_vial_handle_cmd_sloc2_1_0 + 1),a
      00B235 EA               [12] 1332 	mov	a,r2
      00B236 12 B5 77         [24] 1333 	lcall	_ak820_outline_0130
      00B239 85 46 82         [24] 1334 	mov	dpl,_vial_handle_cmd_sloc2_1_0
      00B23C 85 47 83         [24] 1335 	mov	dph,(_vial_handle_cmd_sloc2_1_0 + 1)
      00B23F F0               [24] 1336 	movx	@dptr,a
                                   1337 ;	quantum/vial.c:273: msg[2 + i * 2 + 1] = vial_unlock_combo_cols[i];
      00B240 74 03            [12] 1338 	mov	a,#0x03
      00B242 25 48            [12] 1339 	add	a, _vial_handle_cmd_sloc3_1_0
      00B244 F8               [12] 1340 	mov	r0,a
      00B245 E4               [12] 1341 	clr	a
      00B246 35 49            [12] 1342 	addc	a, (_vial_handle_cmd_sloc3_1_0 + 1)
      00B248 F9               [12] 1343 	mov	r1,a
      00B249 E8               [12] 1344 	mov	a,r0
      00B24A 2E               [12] 1345 	add	a, r6
      00B24B F8               [12] 1346 	mov	r0,a
      00B24C E9               [12] 1347 	mov	a,r1
      00B24D 3F               [12] 1348 	addc	a, r7
      00B24E F9               [12] 1349 	mov	r1,a
      00B24F EA               [12] 1350 	mov	a,r2
      00B250 12 B5 6C         [24] 1351 	lcall	_ak820_outline_0129
      00B253 12 38 76         [24] 1352 	lcall	_ak820_outline_0154
      00B256 F0               [24] 1353 	movx	@dptr,a
                                   1354 ;	quantum/vial.c:271: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B257 0A               [12] 1355 	inc	r2
                                   1356 ;	quantum/vial.c:278: case vial_unlock_start: {
      00B258 80 B8            [24] 1357 	sjmp	00140$
      00B25A                       1358 00116$:
                                   1359 ;	quantum/vial.c:280: if (!vial_unlock_in_progress) vial_release_held_state();
      00B25A 90 0E 46         [24] 1360 	mov	dptr,#_vial_unlock_in_progress
      00B25D E0               [24] 1361 	movx	a,@dptr
      00B25E 70 03            [24] 1362 	jnz	00118$
      00B260 12 AF B9         [24] 1363 	lcall	_vial_release_held_state
      00B263                       1364 00118$:
                                   1365 ;	quantum/vial.c:282: vial_unlock_in_progress = 1;
      00B263 90 0E 46         [24] 1366 	mov	dptr,#_vial_unlock_in_progress
      00B266 74 01            [12] 1367 	mov	a,#0x01
      00B268 F0               [24] 1368 	movx	@dptr,a
                                   1369 ;	quantum/vial.c:283: vial_unlock_counter = VIAL_UNLOCK_COUNTER_MAX;
      00B269 90 0E 47         [24] 1370 	mov	dptr,#_vial_unlock_counter
      00B26C 74 1E            [12] 1371 	mov	a,#0x1e
      00B26E F0               [24] 1372 	movx	@dptr,a
                                   1373 ;	quantum/vial.c:285: vial_unlock_holding = false;
      00B26F 90 0C 77         [24] 1374 	mov	dptr,#_vial_unlock_holding
      00B272 E4               [12] 1375 	clr	a
      00B273 F0               [24] 1376 	movx	@dptr,a
                                   1377 ;	quantum/vial.c:287: break;
      00B274 22               [24] 1378 	ret
                                   1379 ;	quantum/vial.c:289: case vial_unlock_poll: {
      00B275                       1380 00119$:
                                   1381 ;	quantum/vial.c:290: msg[0] = vial_unlocked;
      00B275 90 0E 45         [24] 1382 	mov	dptr,#_vial_unlocked
      00B278 12 43 0C         [24] 1383 	lcall	_ak820_outline_0094
                                   1384 ;	quantum/vial.c:291: msg[1] = vial_unlock_in_progress;
      00B27B 90 0E 46         [24] 1385 	mov	dptr,#_vial_unlock_in_progress
      00B27E E0               [24] 1386 	movx	a,@dptr
      00B27F 12 33 FC         [24] 1387 	lcall	_ak820_outline_0126
      00B282 F0               [24] 1388 	movx	@dptr,a
                                   1389 ;	quantum/vial.c:292: msg[2] = vial_unlock_counter;
      00B283 74 02            [12] 1390 	mov	a,#0x02
      00B285 2E               [12] 1391 	add	a, r6
      00B286 F9               [12] 1392 	mov	r1,a
      00B287 E4               [12] 1393 	clr	a
      00B288 3F               [12] 1394 	addc	a, r7
      00B289 FA               [12] 1395 	mov	r2,a
      00B28A 90 0E 47         [24] 1396 	mov	dptr,#_vial_unlock_counter
      00B28D E0               [24] 1397 	movx	a,@dptr
      00B28E 12 70 5B         [24] 1398 	lcall	_ak820_outline_0141
                                   1399 ;	quantum/vial.c:293: break;
      00B291 22               [24] 1400 	ret
                                   1401 ;	quantum/vial.c:295: case vial_lock: {
      00B292                       1402 00120$:
                                   1403 ;	quantum/vial.c:297: vial_unlocked = 0;
      00B292 90 0E 45         [24] 1404 	mov	dptr,#_vial_unlocked
      00B295 E4               [12] 1405 	clr	a
      00B296 F0               [24] 1406 	movx	@dptr,a
                                   1407 ;	quantum/vial.c:298: vial_unlock_in_progress = 0;
      00B297 90 0E 46         [24] 1408 	mov	dptr,#_vial_unlock_in_progress
      00B29A F0               [24] 1409 	movx	@dptr,a
                                   1410 ;	quantum/vial.c:299: vial_unlock_holding = false;
      00B29B 90 0C 77         [24] 1411 	mov	dptr,#_vial_unlock_holding
      00B29E F0               [24] 1412 	movx	@dptr,a
                                   1413 ;	quantum/vial.c:301: break;
      00B29F 22               [24] 1414 	ret
                                   1415 ;	quantum/vial.c:303: case vial_qmk_settings_query: {
      00B2A0                       1416 00121$:
                                   1417 ;	quantum/vial.c:305: uint16_t qsid_greater_than = msg[2] | (msg[3] << 8);
      00B2A0 12 B5 30         [24] 1418 	lcall	_ak820_outline_0008
      00B2A3 88 49            [24] 1419 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),r0
      00B2A5 89 48            [24] 1420 	mov	_vial_handle_cmd_sloc3_1_0,r1
      00B2A7 8A 01            [24] 1421 	mov	ar1,r2
      00B2A9 7A 00            [12] 1422 	mov	r2,#0x00
      00B2AB E5 49            [12] 1423 	mov	a,(_vial_handle_cmd_sloc3_1_0 + 1)
      00B2AD 42 02            [12] 1424 	orl	ar2,a
                                   1425 ;	quantum/vial.c:307: ak820_settings_query(qsid_greater_than, msg, length);
      00B2AF 90 05 D6         [24] 1426 	mov	dptr,#_ak820_settings_query_PARM_2
      00B2B2 12 4C FA         [24] 1427 	lcall	_ak820_outline_0060
      00B2B5 90 05 D8         [24] 1428 	mov	dptr,#_ak820_settings_query_PARM_3
      00B2B8 ED               [12] 1429 	mov	a,r5
      00B2B9 12 91 C7         [24] 1430 	lcall	_ak820_outline_0144
                                   1431 ;	quantum/vial.c:314: break;
      00B2BC 02 45 D3         [24] 1432 	ljmp	_ak820_settings_query
                                   1433 ;	quantum/vial.c:317: case vial_qmk_settings_get: {
      00B2BF                       1434 00122$:
                                   1435 ;	quantum/vial.c:318: uint16_t qsid = msg[2] | (msg[3] << 8);
      00B2BF 12 B5 30         [24] 1436 	lcall	_ak820_outline_0008
      00B2C2 88 49            [24] 1437 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),r0
      00B2C4 89 48            [24] 1438 	mov	_vial_handle_cmd_sloc3_1_0,r1
      00B2C6 8A 01            [24] 1439 	mov	ar1,r2
      00B2C8 7A 00            [12] 1440 	mov	r2,#0x00
      00B2CA E5 49            [12] 1441 	mov	a,(_vial_handle_cmd_sloc3_1_0 + 1)
      00B2CC 42 02            [12] 1442 	orl	ar2,a
                                   1443 ;	quantum/vial.c:320: msg[0] = ak820_settings_get(qsid, &msg[1], length - 1);
      00B2CE 8D 00            [24] 1444 	mov	ar0,r5
      00B2D0 18               [12] 1445 	dec	r0
      00B2D1 90 05 DC         [24] 1446 	mov	dptr,#_ak820_settings_get_PARM_2
      00B2D4 12 38 34         [24] 1447 	lcall	_ak820_outline_0085
      00B2D7 90 05 DE         [24] 1448 	mov	dptr,#_ak820_settings_get_PARM_3
      00B2DA E8               [12] 1449 	mov	a,r0
      00B2DB 12 91 C7         [24] 1450 	lcall	_ak820_outline_0144
      00B2DE C0 07            [24] 1451 	push	ar7
      00B2E0 C0 06            [24] 1452 	push	ar6
      00B2E2 12 46 69         [24] 1453 	lcall	_ak820_settings_get
      00B2E5 A9 82            [24] 1454 	mov	r1, dpl
      00B2E7 D0 06            [24] 1455 	pop	ar6
      00B2E9 D0 07            [24] 1456 	pop	ar7
      00B2EB 12 43 2B         [24] 1457 	lcall	_ak820_outline_0121
      00B2EE E9               [12] 1458 	mov	a,r1
      00B2EF F0               [24] 1459 	movx	@dptr,a
                                   1460 ;	quantum/vial.c:325: break;
      00B2F0 22               [24] 1461 	ret
                                   1462 ;	quantum/vial.c:327: case vial_qmk_settings_set: {
      00B2F1                       1463 00123$:
                                   1464 ;	quantum/vial.c:328: uint16_t qsid = msg[2] | (msg[3] << 8);
      00B2F1 12 B5 30         [24] 1465 	lcall	_ak820_outline_0008
      00B2F4 88 49            [24] 1466 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),r0
      00B2F6 89 48            [24] 1467 	mov	_vial_handle_cmd_sloc3_1_0,r1
      00B2F8 8A 01            [24] 1468 	mov	ar1,r2
      00B2FA 7A 00            [12] 1469 	mov	r2,#0x00
      00B2FC E5 49            [12] 1470 	mov	a,(_vial_handle_cmd_sloc3_1_0 + 1)
      00B2FE 42 02            [12] 1471 	orl	ar2,a
                                   1472 ;	quantum/vial.c:330: msg[0] = ak820_settings_set(qsid, &msg[4], length - 4);
      00B300 90 05 E1         [24] 1473 	mov	dptr,#_ak820_settings_set_PARM_2
      00B303 74 04            [12] 1474 	mov	a,#0x04
      00B305 2E               [12] 1475 	add	a, r6
      00B306 F0               [24] 1476 	movx	@dptr,a
      00B307 E4               [12] 1477 	clr	a
      00B308 3F               [12] 1478 	addc	a, r7
      00B309 A3               [24] 1479 	inc	dptr
      00B30A F0               [24] 1480 	movx	@dptr,a
      00B30B ED               [12] 1481 	mov	a,r5
      00B30C 24 FC            [12] 1482 	add	a,#0xfc
      00B30E 90 05 E3         [24] 1483 	mov	dptr,#_ak820_settings_set_PARM_3
      00B311 12 91 C7         [24] 1484 	lcall	_ak820_outline_0144
      00B314 C0 07            [24] 1485 	push	ar7
      00B316 C0 06            [24] 1486 	push	ar6
      00B318 12 46 E5         [24] 1487 	lcall	_ak820_settings_set
      00B31B AA 82            [24] 1488 	mov	r2, dpl
      00B31D D0 06            [24] 1489 	pop	ar6
      00B31F D0 07            [24] 1490 	pop	ar7
      00B321 12 43 2B         [24] 1491 	lcall	_ak820_outline_0121
      00B324 EA               [12] 1492 	mov	a,r2
      00B325 F0               [24] 1493 	movx	@dptr,a
                                   1494 ;	quantum/vial.c:335: break;
      00B326 22               [24] 1495 	ret
                                   1496 ;	quantum/vial.c:337: case vial_qmk_settings_reset: {
      00B327                       1497 00124$:
                                   1498 ;	quantum/vial.c:339: msg[0] = ak820_settings_reset();
      00B327 C0 07            [24] 1499 	push	ar7
      00B329 C0 06            [24] 1500 	push	ar6
      00B32B 12 47 9E         [24] 1501 	lcall	_ak820_settings_reset
      00B32E AA 82            [24] 1502 	mov	r2, dpl
      00B330 D0 06            [24] 1503 	pop	ar6
      00B332 D0 07            [24] 1504 	pop	ar7
      00B334 12 43 2B         [24] 1505 	lcall	_ak820_outline_0121
      00B337 EA               [12] 1506 	mov	a,r2
      00B338 F0               [24] 1507 	movx	@dptr,a
                                   1508 ;	quantum/vial.c:343: break;
      00B339 22               [24] 1509 	ret
                                   1510 ;	quantum/vial.c:346: case vial_dynamic_entry_op: {
      00B33A                       1511 00125$:
                                   1512 ;	quantum/vial.c:347: switch (msg[2]) {
      00B33A 12 37 F4         [24] 1513 	lcall	_ak820_outline_0034
      00B33D FD               [12] 1514 	mov	r5,a
      00B33E 60 0C            [24] 1515 	jz	00126$
      00B340 BD 03 02         [24] 1516 	cjne	r5,#0x03,00275$
      00B343 80 31            [24] 1517 	sjmp	00127$
      00B345                       1518 00275$:
      00B345 BD 04 03         [24] 1519 	cjne	r5,#0x04,00276$
      00B348 02 B3 D4         [24] 1520 	ljmp	00128$
      00B34B                       1521 00276$:
      00B34B 22               [24] 1522 	ret
                                   1523 ;	quantum/vial.c:348: case dynamic_vial_get_number_of_entries: {
      00B34C                       1524 00126$:
                                   1525 ;	quantum/vial.c:349: VIAL_FILL_PACKET(msg, 0, length);
      00B34C 90 0C 7A         [24] 1526 	mov	dptr,#_vial_fill_packet_PARM_2
      00B34F E4               [12] 1527 	clr	a
      00B350 12 42 F9         [24] 1528 	lcall	_ak820_outline_0061
      00B353 C0 07            [24] 1529 	push	ar7
      00B355 C0 06            [24] 1530 	push	ar6
      00B357 12 AF 94         [24] 1531 	lcall	_vial_fill_packet
      00B35A D0 06            [24] 1532 	pop	ar6
      00B35C D0 07            [24] 1533 	pop	ar7
                                   1534 ;	quantum/vial.c:350: msg[0] = VIAL_TAP_DANCE_ENTRIES;
      00B35E 12 43 2B         [24] 1535 	lcall	_ak820_outline_0121
      00B361 E4               [12] 1536 	clr	a
      00B362 12 42 F9         [24] 1537 	lcall	_ak820_outline_0061
                                   1538 ;	quantum/vial.c:351: msg[1] = VIAL_COMBO_ENTRIES;
      00B365 A3               [24] 1539 	inc	dptr
      00B366 74 08            [12] 1540 	mov	a,#0x08
      00B368 12 42 CD         [24] 1541 	lcall	_ak820_outline_0031
                                   1542 ;	quantum/vial.c:352: msg[2] = VIAL_KEY_OVERRIDE_ENTRIES;
      00B36B E4               [12] 1543 	clr	a
      00B36C F0               [24] 1544 	movx	@dptr,a
                                   1545 ;	quantum/vial.c:354: msg[VIAL_RAW_EPSIZE - 1] = 1; /* Standard Vial feature bit 0. */
      00B36D 74 1F            [12] 1546 	mov	a,#0x1f
      00B36F 12 37 EC         [24] 1547 	lcall	_ak820_outline_0017
      00B372 74 01            [12] 1548 	mov	a,#0x01
      00B374 F0               [24] 1549 	movx	@dptr,a
                                   1550 ;	quantum/vial.c:356: break;
      00B375 22               [24] 1551 	ret
                                   1552 ;	quantum/vial.c:382: case dynamic_vial_combo_get: {
      00B376                       1553 00127$:
                                   1554 ;	quantum/vial.c:383: uint8_t idx = msg[3];
      00B376 12 AE 91         [24] 1555 	lcall	_ak820_outline_0015
      00B379 FD               [12] 1556 	mov	r5,a
                                   1557 ;	quantum/vial.c:384: vial_combo_entry_t entry = { { 0 }, 0 };
      00B37A 90 0C 81         [24] 1558 	mov	dptr,#_vial_handle_cmd_entry_70000_672
      00B37D 12 53 9C         [24] 1559 	lcall	_ak820_outline_0173
      00B380 90 0C 83         [24] 1560 	mov	dptr,#(_vial_handle_cmd_entry_70000_672 + 0x0002)
      00B383 F0               [24] 1561 	movx	@dptr,a
      00B384 A3               [24] 1562 	inc	dptr
      00B385 F0               [24] 1563 	movx	@dptr,a
      00B386 90 0C 85         [24] 1564 	mov	dptr,#(_vial_handle_cmd_entry_70000_672 + 0x0004)
      00B389 F0               [24] 1565 	movx	@dptr,a
      00B38A A3               [24] 1566 	inc	dptr
      00B38B F0               [24] 1567 	movx	@dptr,a
      00B38C 90 0C 87         [24] 1568 	mov	dptr,#(_vial_handle_cmd_entry_70000_672 + 0x0006)
      00B38F F0               [24] 1569 	movx	@dptr,a
      00B390 A3               [24] 1570 	inc	dptr
      00B391 F0               [24] 1571 	movx	@dptr,a
      00B392 90 0C 89         [24] 1572 	mov	dptr,#(_vial_handle_cmd_entry_70000_672 + 0x0008)
      00B395 F0               [24] 1573 	movx	@dptr,a
      00B396 A3               [24] 1574 	inc	dptr
      00B397 F0               [24] 1575 	movx	@dptr,a
                                   1576 ;	quantum/vial.c:385: msg[0] = dynamic_keymap_get_combo(idx, &entry);
      00B398 90 0B 2F         [24] 1577 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      00B39B 74 81            [12] 1578 	mov	a,#_vial_handle_cmd_entry_70000_672
      00B39D F0               [24] 1579 	movx	@dptr,a
      00B39E 74 0C            [12] 1580 	mov	a,#(_vial_handle_cmd_entry_70000_672 >> 8)
      00B3A0 12 38 2E         [24] 1581 	lcall	_ak820_outline_0084
      00B3A3 8D 82            [24] 1582 	mov	dpl, r5
      00B3A5 C0 07            [24] 1583 	push	ar7
      00B3A7 C0 06            [24] 1584 	push	ar6
      00B3A9 C0 04            [24] 1585 	push	ar4
      00B3AB C0 03            [24] 1586 	push	ar3
      00B3AD 12 88 C2         [24] 1587 	lcall	_dynamic_keymap_get_combo
      00B3B0 AA 82            [24] 1588 	mov	r2, dpl
      00B3B2 D0 03            [24] 1589 	pop	ar3
      00B3B4 D0 04            [24] 1590 	pop	ar4
      00B3B6 D0 06            [24] 1591 	pop	ar6
      00B3B8 D0 07            [24] 1592 	pop	ar7
      00B3BA 12 43 2B         [24] 1593 	lcall	_ak820_outline_0121
      00B3BD EA               [12] 1594 	mov	a,r2
      00B3BE F0               [24] 1595 	movx	@dptr,a
                                   1596 ;	quantum/vial.c:386: memcpy(&msg[1], &entry, sizeof(entry));
      00B3BF 7D 00            [12] 1597 	mov	r5,#0x00
      00B3C1 90 0D BD         [24] 1598 	mov	dptr,#___memcpy_PARM_2
      00B3C4 74 81            [12] 1599 	mov	a,#_vial_handle_cmd_entry_70000_672
      00B3C6 F0               [24] 1600 	movx	@dptr,a
      00B3C7 74 0C            [12] 1601 	mov	a,#(_vial_handle_cmd_entry_70000_672 >> 8)
      00B3C9 12 B5 5D         [24] 1602 	lcall	_ak820_outline_0074
      00B3CC 12 33 FC         [24] 1603 	lcall	_ak820_outline_0126
      00B3CF 8D F0            [24] 1604 	mov	b, r5
                                   1605 ;	quantum/vial.c:387: break;
      00B3D1 02 BB 20         [24] 1606 	ljmp	___memcpy
                                   1607 ;	quantum/vial.c:389: case dynamic_vial_combo_set: {
      00B3D4                       1608 00128$:
                                   1609 ;	quantum/vial.c:390: uint8_t idx = msg[3];
      00B3D4 12 AE 91         [24] 1610 	lcall	_ak820_outline_0015
      00B3D7 FD               [12] 1611 	mov	r5,a
                                   1612 ;	quantum/vial.c:392: memcpy(&entry, &msg[4], sizeof(entry));
      00B3D8 74 04            [12] 1613 	mov	a,#0x04
      00B3DA 2E               [12] 1614 	add	a, r6
      00B3DB FB               [12] 1615 	mov	r3,a
      00B3DC E4               [12] 1616 	clr	a
      00B3DD 3F               [12] 1617 	addc	a, r7
      00B3DE FC               [12] 1618 	mov	r4,a
      00B3DF 90 0D BD         [24] 1619 	mov	dptr,#___memcpy_PARM_2
      00B3E2 EB               [12] 1620 	mov	a,r3
      00B3E3 F0               [24] 1621 	movx	@dptr,a
      00B3E4 EC               [12] 1622 	mov	a,r4
      00B3E5 12 B5 5D         [24] 1623 	lcall	_ak820_outline_0074
      00B3E8 90 0C 8B         [24] 1624 	mov	dptr,#_vial_handle_cmd_entry_70000_673
      00B3EB F5 F0            [12] 1625 	mov	b,a
      00B3ED C0 07            [24] 1626 	push	ar7
      00B3EF C0 06            [24] 1627 	push	ar6
      00B3F1 C0 05            [24] 1628 	push	ar5
      00B3F3 12 BB 20         [24] 1629 	lcall	___memcpy
                                   1630 ;	quantum/vial.c:393: entry.output = vial_keycode_firewall(entry.output);
      00B3F6 90 0C 93         [24] 1631 	mov	dptr,#(_vial_handle_cmd_entry_70000_673 + 0x0008)
      00B3F9 12 38 4C         [24] 1632 	lcall	_ak820_outline_0105
      00B3FC 12 33 FC         [24] 1633 	lcall	_ak820_outline_0126
      00B3FF 12 AF 71         [24] 1634 	lcall	_vial_keycode_firewall
      00B402 AB 82            [24] 1635 	mov	r3, dpl
      00B404 AC 83            [24] 1636 	mov	r4, dph
      00B406 D0 05            [24] 1637 	pop	ar5
      00B408 90 0C 93         [24] 1638 	mov	dptr,#(_vial_handle_cmd_entry_70000_673 + 0x0008)
      00B40B 12 38 34         [24] 1639 	lcall	_ak820_outline_0085
                                   1640 ;	quantum/vial.c:394: msg[0] = dynamic_keymap_set_combo(idx, &entry);
      00B40E 90 0B 33         [24] 1641 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      00B411 74 8B            [12] 1642 	mov	a,#_vial_handle_cmd_entry_70000_673
      00B413 F0               [24] 1643 	movx	@dptr,a
      00B414 74 0C            [12] 1644 	mov	a,#(_vial_handle_cmd_entry_70000_673 >> 8)
      00B416 12 38 2E         [24] 1645 	lcall	_ak820_outline_0084
      00B419 8D 82            [24] 1646 	mov	dpl, r5
      00B41B 12 89 68         [24] 1647 	lcall	_dynamic_keymap_set_combo
      00B41E AC 82            [24] 1648 	mov	r4, dpl
      00B420 D0 06            [24] 1649 	pop	ar6
      00B422 D0 07            [24] 1650 	pop	ar7
      00B424 12 43 2B         [24] 1651 	lcall	_ak820_outline_0121
      00B427 EC               [12] 1652 	mov	a,r4
      00B428 F0               [24] 1653 	movx	@dptr,a
                                   1654 ;	quantum/vial.c:395: if (!msg[0]) reload_combo();
      00B429 EC               [12] 1655 	mov	a,r4
      00B42A 70 03            [24] 1656 	jnz	00142$
                                   1657 ;	quantum/vial.c:423: }
                                   1658 ;	quantum/vial.c:424: }
      00B42C 02 35 38         [24] 1659 	ljmp	_ak820_combo_reload
      00B42F                       1660 00142$:
      00B42F 22               [24] 1661 	ret
                                   1662 ;------------------------------------------------------------
                                   1663 ;Allocation info for local variables in function 'vial_keycode_down'
                                   1664 ;------------------------------------------------------------
                                   1665 ;keycode       Allocated with name '_vial_keycode_down_keycode_10000_675'
                                   1666 ;dummy_event   Allocated with name '_vial_keycode_down_dummy_event_30000_682'
                                   1667 ;------------------------------------------------------------
                                   1668 ;	quantum/vial.c:428: void vial_keycode_down(uint16_t keycode) {
                                   1669 ;	-----------------------------------------
                                   1670 ;	 function vial_keycode_down
                                   1671 ;	-----------------------------------------
      00B430                       1672 _vial_keycode_down:
      00B430 12 38 52         [24] 1673 	lcall	_ak820_outline_0106
      00B433 90 0C 97         [24] 1674 	mov	dptr,#_vial_keycode_down_keycode_10000_675
      00B436 12 38 57         [24] 1675 	lcall	_ak820_outline_0107
                                   1676 ;	quantum/vial.c:432: if (keycode >= QK_MOD_TAP && keycode <= QK_LAYER_TAP_MAX) {
      00B439 90 0C 97         [24] 1677 	mov	dptr,#_vial_keycode_down_keycode_10000_675
      00B43C 12 37 D0         [24] 1678 	lcall	_ak820_outline_0010
      00B43F 74 E0            [12] 1679 	mov	a,#0x100 - 0x20
      00B441 2D               [12] 1680 	add	a,r5
      00B442 50 19            [24] 1681 	jnc	00104$
      00B444 C3               [12] 1682 	clr	c
      00B445 74 FF            [12] 1683 	mov	a,#0xff
      00B447 9C               [12] 1684 	subb	a,r4
      00B448 74 4F            [12] 1685 	mov	a,#0x4f
      00B44A 9D               [12] 1686 	subb	a,r5
      00B44B 40 10            [24] 1687 	jc	00104$
                                   1688 ;	free result
                                   1689 ;	quantum/vial.c:433: keycode = (uint8_t)keycode;
      00B44D 90 0C 97         [24] 1690 	mov	dptr,#_vial_keycode_down_keycode_10000_675
      00B450 EE               [12] 1691 	mov	a,r6
      00B451 12 38 61         [24] 1692 	lcall	_ak820_outline_0127
                                   1693 ;	quantum/vial.c:434: if (keycode <= KC_TRANSPARENT) return;
      00B454 90 0C 97         [24] 1694 	mov	dptr,#_vial_keycode_down_keycode_10000_675
      00B457 E0               [24] 1695 	movx	a,@dptr
      00B458 24 FE            [12] 1696 	add	a,#0xff - 0x01
      00B45A 40 01            [24] 1697 	jc	00104$
                                   1698 ;	free result
      00B45C 22               [24] 1699 	ret
      00B45D                       1700 00104$:
                                   1701 ;	quantum/vial.c:437: g_vial_magic_keycode_override = keycode;
      00B45D 90 0C 97         [24] 1702 	mov	dptr,#_vial_keycode_down_keycode_10000_675
      00B460 12 B5 44         [24] 1703 	lcall	_ak820_outline_0025
                                   1704 ;	quantum/vial.c:439: if (keycode <= QK_MODS_MAX) {
      00B463 40 06            [24] 1705 	jc	00107$
                                   1706 ;	free result
                                   1707 ;	quantum/vial.c:440: register_code16(keycode);
      00B465 12 43 2B         [24] 1708 	lcall	_ak820_outline_0121
      00B468 02 A0 E7         [24] 1709 	ljmp	_register_code16
      00B46B                       1710 00107$:
                                   1711 ;	quantum/vial.c:442: keyevent_t dummy_event = {
      00B46B 90 0C 9D         [24] 1712 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_682 + 0x0004)
      00B46E 74 01            [12] 1713 	mov	a,#0x01
      00B470 F0               [24] 1714 	movx	@dptr,a
      00B471 90 0C 9A         [24] 1715 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_682 + 0x0001)
      00B474 74 F0            [12] 1716 	mov	a,#0xf0
      00B476 F0               [24] 1717 	movx	@dptr,a
      00B477 90 0C 99         [24] 1718 	mov	dptr,#_vial_keycode_down_dummy_event_30000_682
      00B47A F0               [24] 1719 	movx	@dptr,a
      00B47B 90 0C 9E         [24] 1720 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_682 + 0x0005)
      00B47E 74 01            [12] 1721 	mov	a,#0x01
      00B480 F0               [24] 1722 	movx	@dptr,a
      00B481 12 4D 9D         [24] 1723 	lcall	_timer_read
      00B484 12 43 30         [24] 1724 	lcall	_ak820_outline_0135
      00B487 43 06 01         [24] 1725 	orl	ar6,#0x01
      00B48A 90 0C 9B         [24] 1726 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_682 + 0x0002)
      00B48D 12 4C FA         [24] 1727 	lcall	_ak820_outline_0060
                                   1728 ;	quantum/vial.c:446: AK820_ACTION_EXEC(dummy_event);
      00B490 90 0C 99         [24] 1729 	mov	dptr,#_vial_keycode_down_dummy_event_30000_682
                                   1730 ;	quantum/vial.c:448: }
      00B493 02 74 7F         [24] 1731 	ljmp	_ak820_action_exec
                                   1732 ;------------------------------------------------------------
                                   1733 ;Allocation info for local variables in function 'vial_keycode_up'
                                   1734 ;------------------------------------------------------------
                                   1735 ;keycode       Allocated with name '_vial_keycode_up_keycode_10000_683'
                                   1736 ;dummy_event   Allocated with name '_vial_keycode_up_dummy_event_30000_690'
                                   1737 ;------------------------------------------------------------
                                   1738 ;	quantum/vial.c:450: void vial_keycode_up(uint16_t keycode) {
                                   1739 ;	-----------------------------------------
                                   1740 ;	 function vial_keycode_up
                                   1741 ;	-----------------------------------------
      00B496                       1742 _vial_keycode_up:
      00B496 12 38 52         [24] 1743 	lcall	_ak820_outline_0106
      00B499 90 0C 9F         [24] 1744 	mov	dptr,#_vial_keycode_up_keycode_10000_683
      00B49C 12 38 57         [24] 1745 	lcall	_ak820_outline_0107
                                   1746 ;	quantum/vial.c:454: if (keycode >= QK_MOD_TAP && keycode <= QK_LAYER_TAP_MAX) {
      00B49F 90 0C 9F         [24] 1747 	mov	dptr,#_vial_keycode_up_keycode_10000_683
      00B4A2 12 37 D0         [24] 1748 	lcall	_ak820_outline_0010
      00B4A5 74 E0            [12] 1749 	mov	a,#0x100 - 0x20
      00B4A7 2D               [12] 1750 	add	a,r5
      00B4A8 50 19            [24] 1751 	jnc	00104$
      00B4AA C3               [12] 1752 	clr	c
      00B4AB 74 FF            [12] 1753 	mov	a,#0xff
      00B4AD 9C               [12] 1754 	subb	a,r4
      00B4AE 74 4F            [12] 1755 	mov	a,#0x4f
      00B4B0 9D               [12] 1756 	subb	a,r5
      00B4B1 40 10            [24] 1757 	jc	00104$
                                   1758 ;	free result
                                   1759 ;	quantum/vial.c:455: keycode = (uint8_t)keycode;
      00B4B3 90 0C 9F         [24] 1760 	mov	dptr,#_vial_keycode_up_keycode_10000_683
      00B4B6 EE               [12] 1761 	mov	a,r6
      00B4B7 12 38 61         [24] 1762 	lcall	_ak820_outline_0127
                                   1763 ;	quantum/vial.c:456: if (keycode <= KC_TRANSPARENT) return;
      00B4BA 90 0C 9F         [24] 1764 	mov	dptr,#_vial_keycode_up_keycode_10000_683
      00B4BD E0               [24] 1765 	movx	a,@dptr
      00B4BE 24 FE            [12] 1766 	add	a,#0xff - 0x01
      00B4C0 40 01            [24] 1767 	jc	00104$
                                   1768 ;	free result
      00B4C2 22               [24] 1769 	ret
      00B4C3                       1770 00104$:
                                   1771 ;	quantum/vial.c:459: g_vial_magic_keycode_override = keycode;
      00B4C3 90 0C 9F         [24] 1772 	mov	dptr,#_vial_keycode_up_keycode_10000_683
      00B4C6 12 B5 44         [24] 1773 	lcall	_ak820_outline_0025
                                   1774 ;	quantum/vial.c:461: if (keycode <= QK_MODS_MAX) {
      00B4C9 40 06            [24] 1775 	jc	00107$
                                   1776 ;	free result
                                   1777 ;	quantum/vial.c:462: unregister_code16(keycode);
      00B4CB 12 43 2B         [24] 1778 	lcall	_ak820_outline_0121
      00B4CE 02 A1 2B         [24] 1779 	ljmp	_unregister_code16
      00B4D1                       1780 00107$:
                                   1781 ;	quantum/vial.c:464: keyevent_t dummy_event = {
      00B4D1 90 0C A5         [24] 1782 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_690 + 0x0004)
      00B4D4 74 01            [12] 1783 	mov	a,#0x01
      00B4D6 F0               [24] 1784 	movx	@dptr,a
      00B4D7 90 0C A2         [24] 1785 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_690 + 0x0001)
      00B4DA 74 F0            [12] 1786 	mov	a,#0xf0
      00B4DC F0               [24] 1787 	movx	@dptr,a
      00B4DD 90 0C A1         [24] 1788 	mov	dptr,#_vial_keycode_up_dummy_event_30000_690
      00B4E0 F0               [24] 1789 	movx	@dptr,a
      00B4E1 90 0C A6         [24] 1790 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_690 + 0x0005)
      00B4E4 E4               [12] 1791 	clr	a
      00B4E5 F0               [24] 1792 	movx	@dptr,a
      00B4E6 12 4D 9D         [24] 1793 	lcall	_timer_read
      00B4E9 12 43 30         [24] 1794 	lcall	_ak820_outline_0135
      00B4EC 43 06 01         [24] 1795 	orl	ar6,#0x01
      00B4EF 90 0C A3         [24] 1796 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_690 + 0x0002)
      00B4F2 12 4C FA         [24] 1797 	lcall	_ak820_outline_0060
                                   1798 ;	quantum/vial.c:468: AK820_ACTION_EXEC(dummy_event);
      00B4F5 90 0C A1         [24] 1799 	mov	dptr,#_vial_keycode_up_dummy_event_30000_690
                                   1800 ;	quantum/vial.c:470: }
      00B4F8 02 74 7F         [24] 1801 	ljmp	_ak820_action_exec
                                   1802 ;------------------------------------------------------------
                                   1803 ;Allocation info for local variables in function 'vial_keycode_tap'
                                   1804 ;------------------------------------------------------------
                                   1805 ;keycode       Allocated with name '_vial_keycode_tap_keycode_10000_691'
                                   1806 ;i             Allocated with name '_vial_keycode_tap_i_30000_694'
                                   1807 ;------------------------------------------------------------
                                   1808 ;	quantum/vial.c:472: void vial_keycode_tap(uint16_t keycode) {
                                   1809 ;	-----------------------------------------
                                   1810 ;	 function vial_keycode_tap
                                   1811 ;	-----------------------------------------
      00B4FB                       1812 _vial_keycode_tap:
      00B4FB 12 38 52         [24] 1813 	lcall	_ak820_outline_0106
      00B4FE 90 0C A7         [24] 1814 	mov	dptr,#_vial_keycode_tap_keycode_10000_691
      00B501 12 38 57         [24] 1815 	lcall	_ak820_outline_0107
                                   1816 ;	quantum/vial.c:473: vial_keycode_down(keycode);
      00B504 90 0C A7         [24] 1817 	mov	dptr,#_vial_keycode_tap_keycode_10000_691
      00B507 12 37 A5         [24] 1818 	lcall	_ak820_outline_0004
      00B50A C0 07            [24] 1819 	push	ar7
      00B50C C0 06            [24] 1820 	push	ar6
      00B50E 91 30            [12] 1821 	acall	_vial_keycode_down
                                   1822 ;	quantum/vial.c:474: qs_wait_ms(QS_tap_code_delay);
      00B510 12 47 B7         [24] 1823 	lcall	_ak820_settings_tap_code_delay
      00B513 12 38 71         [24] 1824 	lcall	_ak820_outline_0149
      00B516 D0 06            [24] 1825 	pop	ar6
      00B518 D0 07            [24] 1826 	pop	ar7
      00B51A                       1827 00106$:
      00B51A EC               [12] 1828 	mov	a,r4
      00B51B 4D               [12] 1829 	orl	a,r5
      00B51C 60 0D            [24] 1830 	jz	00103$
      00B51E 90 00 01         [24] 1831 	mov	dptr,#0x0001
      00B521 12 5C F8         [24] 1832 	lcall	_mDelaymS
      00B524 1C               [12] 1833 	dec	r4
      00B525 BC FF 01         [24] 1834 	cjne	r4,#0xff,00128$
      00B528 1D               [12] 1835 	dec	r5
      00B529                       1836 00128$:
      00B529 80 EF            [24] 1837 	sjmp	00106$
      00B52B                       1838 00103$:
                                   1839 ;	quantum/vial.c:475: vial_keycode_up(keycode);
      00B52B 12 43 2B         [24] 1840 	lcall	_ak820_outline_0121
                                   1841 ;	quantum/vial.c:476: }
      00B52E 81 96            [12] 1842 	ajmp	_vial_keycode_up
                                   1843 ;------------------------------------------------------------
                                   1844 ;Allocation info for local variables in function 'process_record_vial'
                                   1845 ;------------------------------------------------------------
                                   1846 ;record        Allocated with name '_process_record_vial_PARM_2'
                                   1847 ;keycode       Allocated with name '_process_record_vial_keycode_10000_696'
                                   1848 ;------------------------------------------------------------
                                   1849 ;	quantum/vial.c:686: bool process_record_vial(uint16_t keycode, keyrecord_t *record) {
                                   1850 ;	-----------------------------------------
                                   1851 	.area CSEG    (CODE)
                                   1852 	.area CONST   (CODE)
                                   1853 	.area CONST   (CODE)
      00C1AA                       1854 _keyboard_definition:
      00C1AA FD                    1855 	.db #0xfd	; 253
      00C1AB 37                    1856 	.db #0x37	; 55	'7'
      00C1AC 7A                    1857 	.db #0x7a	; 122	'z'
      00C1AD 58                    1858 	.db #0x58	; 88	'X'
      00C1AE 5A                    1859 	.db #0x5a	; 90	'Z'
      00C1AF 00                    1860 	.db #0x00	; 0
      00C1B0 00                    1861 	.db #0x00	; 0
      00C1B1 04                    1862 	.db #0x04	; 4
      00C1B2 E6                    1863 	.db #0xe6	; 230
      00C1B3 D6                    1864 	.db #0xd6	; 214
      00C1B4 B4                    1865 	.db #0xb4	; 180
      00C1B5 46                    1866 	.db #0x46	; 70	'F'
      00C1B6 02                    1867 	.db #0x02	; 2
      00C1B7 00                    1868 	.db #0x00	; 0
      00C1B8 21                    1869 	.db #0x21	; 33
      00C1B9 01                    1870 	.db #0x01	; 1
      00C1BA 00                    1871 	.db #0x00	; 0
      00C1BB 00                    1872 	.db #0x00	; 0
      00C1BC 00                    1873 	.db #0x00	; 0
      00C1BD 00                    1874 	.db #0x00	; 0
      00C1BE 37                    1875 	.db #0x37	; 55	'7'
      00C1BF 27                    1876 	.db #0x27	; 39
      00C1C0 97                    1877 	.db #0x97	; 151
      00C1C1 D6                    1878 	.db #0xd6	; 214
      00C1C2 E0                    1879 	.db #0xe0	; 224
      00C1C3 03                    1880 	.db #0x03	; 3
      00C1C4 CB                    1881 	.db #0xcb	; 203
      00C1C5 01                    1882 	.db #0x01	; 1
      00C1C6 3C                    1883 	.db #0x3c	; 60
      00C1C7 00                    1884 	.db #0x00	; 0
      00C1C8 00                    1885 	.db #0x00	; 0
      00C1C9 3D                    1886 	.db #0x3d	; 61
      00C1CA 88                    1887 	.db #0x88	; 136
      00C1CB CD                    1888 	.db #0xcd	; 205
      00C1CC A5                    1889 	.db #0xa5	; 165
      00C1CD AA                    1890 	.db #0xaa	; 170
      00C1CE E5                    1891 	.db #0xe5	; 229
      00C1CF A8                    1892 	.db #0xa8	; 168
      00C1D0 76                    1893 	.db #0x76	; 118	'v'
      00C1D1 F6                    1894 	.db #0xf6	; 246
      00C1D2 43                    1895 	.db #0x43	; 67	'C'
      00C1D3 0E                    1896 	.db #0x0e	; 14
      00C1D4 D2                    1897 	.db #0xd2	; 210
      00C1D5 90                    1898 	.db #0x90	; 144
      00C1D6 7D                    1899 	.db #0x7d	; 125
      00C1D7 94                    1900 	.db #0x94	; 148
      00C1D8 79                    1901 	.db #0x79	; 121	'y'
      00C1D9 78                    1902 	.db #0x78	; 120	'x'
      00C1DA EF                    1903 	.db #0xef	; 239
      00C1DB 49                    1904 	.db #0x49	; 73	'I'
      00C1DC 3E                    1905 	.db #0x3e	; 62
      00C1DD EF                    1906 	.db #0xef	; 239
      00C1DE FD                    1907 	.db #0xfd	; 253
      00C1DF 8F                    1908 	.db #0x8f	; 143
      00C1E0 EF                    1909 	.db #0xef	; 239
      00C1E1 00                    1910 	.db #0x00	; 0
      00C1E2 C6                    1911 	.db #0xc6	; 198
      00C1E3 D1                    1912 	.db #0xd1	; 209
      00C1E4 DB                    1913 	.db #0xdb	; 219
      00C1E5 FB                    1914 	.db #0xfb	; 251
      00C1E6 EB                    1915 	.db #0xeb	; 235
      00C1E7 DE                    1916 	.db #0xde	; 222
      00C1E8 66                    1917 	.db #0x66	; 102	'f'
      00C1E9 63                    1918 	.db #0x63	; 99	'c'
      00C1EA 0C                    1919 	.db #0x0c	; 12
      00C1EB 92                    1920 	.db #0x92	; 146
      00C1EC 7B                    1921 	.db #0x7b	; 123
      00C1ED F9                    1922 	.db #0xf9	; 249
      00C1EE D4                    1923 	.db #0xd4	; 212
      00C1EF 7A                    1924 	.db #0x7a	; 122	'z'
      00C1F0 4F                    1925 	.db #0x4f	; 79	'O'
      00C1F1 83                    1926 	.db #0x83	; 131
      00C1F2 4B                    1927 	.db #0x4b	; 75	'K'
      00C1F3 86                    1928 	.db #0x86	; 134
      00C1F4 0E                    1929 	.db #0x0e	; 14
      00C1F5 6A                    1930 	.db #0x6a	; 106	'j'
      00C1F6 F2                    1931 	.db #0xf2	; 242
      00C1F7 22                    1932 	.db #0x22	; 34
      00C1F8 22                    1933 	.db #0x22	; 34
      00C1F9 0B                    1934 	.db #0x0b	; 11
      00C1FA 03                    1935 	.db #0x03	; 3
      00C1FB BA                    1936 	.db #0xba	; 186
      00C1FC 67                    1937 	.db #0x67	; 103	'g'
      00C1FD 9B                    1938 	.db #0x9b	; 155
      00C1FE 7A                    1939 	.db #0x7a	; 122	'z'
      00C1FF E1                    1940 	.db #0xe1	; 225
      00C200 BC                    1941 	.db #0xbc	; 188
      00C201 37                    1942 	.db #0x37	; 55	'7'
      00C202 26                    1943 	.db #0x26	; 38
      00C203 46                    1944 	.db #0x46	; 70	'F'
      00C204 78                    1945 	.db #0x78	; 120	'x'
      00C205 05                    1946 	.db #0x05	; 5
      00C206 0D                    1947 	.db #0x0d	; 13
      00C207 95                    1948 	.db #0x95	; 149
      00C208 02                    1949 	.db #0x02	; 2
      00C209 E4                    1950 	.db #0xe4	; 228
      00C20A 18                    1951 	.db #0x18	; 24
      00C20B CA                    1952 	.db #0xca	; 202
      00C20C 33                    1953 	.db #0x33	; 51	'3'
      00C20D EA                    1954 	.db #0xea	; 234
      00C20E 24                    1955 	.db #0x24	; 36
      00C20F C8                    1956 	.db #0xc8	; 200
      00C210 81                    1957 	.db #0x81	; 129
      00C211 4E                    1958 	.db #0x4e	; 78	'N'
      00C212 47                    1959 	.db #0x47	; 71	'G'
      00C213 A8                    1960 	.db #0xa8	; 168
      00C214 44                    1961 	.db #0x44	; 68	'D'
      00C215 DD                    1962 	.db #0xdd	; 221
      00C216 91                    1963 	.db #0x91	; 145
      00C217 6D                    1964 	.db #0x6d	; 109	'm'
      00C218 69                    1965 	.db #0x69	; 105	'i'
      00C219 DB                    1966 	.db #0xdb	; 219
      00C21A 4F                    1967 	.db #0x4f	; 79	'O'
      00C21B 3A                    1968 	.db #0x3a	; 58
      00C21C 43                    1969 	.db #0x43	; 67	'C'
      00C21D 9D                    1970 	.db #0x9d	; 157
      00C21E 26                    1971 	.db #0x26	; 38
      00C21F 49                    1972 	.db #0x49	; 73	'I'
      00C220 4C                    1973 	.db #0x4c	; 76	'L'
      00C221 EF                    1974 	.db #0xef	; 239
      00C222 2B                    1975 	.db #0x2b	; 43
      00C223 D8                    1976 	.db #0xd8	; 216
      00C224 55                    1977 	.db #0x55	; 85	'U'
      00C225 95                    1978 	.db #0x95	; 149
      00C226 70                    1979 	.db #0x70	; 112	'p'
      00C227 B1                    1980 	.db #0xb1	; 177
      00C228 CC                    1981 	.db #0xcc	; 204
      00C229 CF                    1982 	.db #0xcf	; 207
      00C22A 13                    1983 	.db #0x13	; 19
      00C22B 32                    1984 	.db #0x32	; 50	'2'
      00C22C 6A                    1985 	.db #0x6a	; 106	'j'
      00C22D A1                    1986 	.db #0xa1	; 161
      00C22E FF                    1987 	.db #0xff	; 255
      00C22F 99                    1988 	.db #0x99	; 153
      00C230 61                    1989 	.db #0x61	; 97	'a'
      00C231 95                    1990 	.db #0x95	; 149
      00C232 B1                    1991 	.db #0xb1	; 177
      00C233 89                    1992 	.db #0x89	; 137
      00C234 9B                    1993 	.db #0x9b	; 155
      00C235 11                    1994 	.db #0x11	; 17
      00C236 D9                    1995 	.db #0xd9	; 217
      00C237 35                    1996 	.db #0x35	; 53	'5'
      00C238 78                    1997 	.db #0x78	; 120	'x'
      00C239 ED                    1998 	.db #0xed	; 237
      00C23A CD                    1999 	.db #0xcd	; 205
      00C23B 94                    2000 	.db #0x94	; 148
      00C23C 6E                    2001 	.db #0x6e	; 110	'n'
      00C23D 60                    2002 	.db #0x60	; 96
      00C23E 8E                    2003 	.db #0x8e	; 142
      00C23F 63                    2004 	.db #0x63	; 99	'c'
      00C240 8B                    2005 	.db #0x8b	; 139
      00C241 FF                    2006 	.db #0xff	; 255
      00C242 4E                    2007 	.db #0x4e	; 78	'N'
      00C243 20                    2008 	.db #0x20	; 32
      00C244 7A                    2009 	.db #0x7a	; 122	'z'
      00C245 B5                    2010 	.db #0xb5	; 181
      00C246 87                    2011 	.db #0x87	; 135
      00C247 C2                    2012 	.db #0xc2	; 194
      00C248 35                    2013 	.db #0x35	; 53	'5'
      00C249 A4                    2014 	.db #0xa4	; 164
      00C24A 6D                    2015 	.db #0x6d	; 109	'm'
      00C24B 18                    2016 	.db #0x18	; 24
      00C24C C1                    2017 	.db #0xc1	; 193
      00C24D A3                    2018 	.db #0xa3	; 163
      00C24E DB                    2019 	.db #0xdb	; 219
      00C24F 53                    2020 	.db #0x53	; 83	'S'
      00C250 1D                    2021 	.db #0x1d	; 29
      00C251 EC                    2022 	.db #0xec	; 236
      00C252 F0                    2023 	.db #0xf0	; 240
      00C253 BF                    2024 	.db #0xbf	; 191
      00C254 4A                    2025 	.db #0x4a	; 74	'J'
      00C255 4C                    2026 	.db #0x4c	; 76	'L'
      00C256 4A                    2027 	.db #0x4a	; 74	'J'
      00C257 C4                    2028 	.db #0xc4	; 196
      00C258 AA                    2029 	.db #0xaa	; 170
      00C259 37                    2030 	.db #0x37	; 55	'7'
      00C25A 19                    2031 	.db #0x19	; 25
      00C25B 34                    2032 	.db #0x34	; 52	'4'
      00C25C 3F                    2033 	.db #0x3f	; 63
      00C25D A1                    2034 	.db #0xa1	; 161
      00C25E D3                    2035 	.db #0xd3	; 211
      00C25F 1A                    2036 	.db #0x1a	; 26
      00C260 5C                    2037 	.db #0x5c	; 92
      00C261 03                    2038 	.db #0x03	; 3
      00C262 4D                    2039 	.db #0x4d	; 77	'M'
      00C263 BC                    2040 	.db #0xbc	; 188
      00C264 10                    2041 	.db #0x10	; 16
      00C265 2E                    2042 	.db #0x2e	; 46
      00C266 80                    2043 	.db #0x80	; 128
      00C267 F7                    2044 	.db #0xf7	; 247
      00C268 D6                    2045 	.db #0xd6	; 214
      00C269 82                    2046 	.db #0x82	; 130
      00C26A 24                    2047 	.db #0x24	; 36
      00C26B 4C                    2048 	.db #0x4c	; 76	'L'
      00C26C 87                    2049 	.db #0x87	; 135
      00C26D B9                    2050 	.db #0xb9	; 185
      00C26E F8                    2051 	.db #0xf8	; 248
      00C26F BE                    2052 	.db #0xbe	; 190
      00C270 67                    2053 	.db #0x67	; 103	'g'
      00C271 96                    2054 	.db #0x96	; 150
      00C272 89                    2055 	.db #0x89	; 137
      00C273 30                    2056 	.db #0x30	; 48	'0'
      00C274 C8                    2057 	.db #0xc8	; 200
      00C275 8D                    2058 	.db #0x8d	; 141
      00C276 2C                    2059 	.db #0x2c	; 44
      00C277 F5                    2060 	.db #0xf5	; 245
      00C278 06                    2061 	.db #0x06	; 6
      00C279 05                    2062 	.db #0x05	; 5
      00C27A 7C                    2063 	.db #0x7c	; 124
      00C27B 48                    2064 	.db #0x48	; 72	'H'
      00C27C 1B                    2065 	.db #0x1b	; 27
      00C27D 76                    2066 	.db #0x76	; 118	'v'
      00C27E AA                    2067 	.db #0xaa	; 170
      00C27F 3D                    2068 	.db #0x3d	; 61
      00C280 28                    2069 	.db #0x28	; 40
      00C281 FC                    2070 	.db #0xfc	; 252
      00C282 80                    2071 	.db #0x80	; 128
      00C283 75                    2072 	.db #0x75	; 117	'u'
      00C284 EB                    2073 	.db #0xeb	; 235
      00C285 78                    2074 	.db #0x78	; 120	'x'
      00C286 D0                    2075 	.db #0xd0	; 208
      00C287 8A                    2076 	.db #0x8a	; 138
      00C288 8F                    2077 	.db #0x8f	; 143
      00C289 27                    2078 	.db #0x27	; 39
      00C28A F7                    2079 	.db #0xf7	; 247
      00C28B F2                    2080 	.db #0xf2	; 242
      00C28C EB                    2081 	.db #0xeb	; 235
      00C28D 58                    2082 	.db #0x58	; 88	'X'
      00C28E 37                    2083 	.db #0x37	; 55	'7'
      00C28F 3C                    2084 	.db #0x3c	; 60
      00C290 2B                    2085 	.db #0x2b	; 43
      00C291 6F                    2086 	.db #0x6f	; 111	'o'
      00C292 0E                    2087 	.db #0x0e	; 14
      00C293 C7                    2088 	.db #0xc7	; 199
      00C294 E2                    2089 	.db #0xe2	; 226
      00C295 A0                    2090 	.db #0xa0	; 160
      00C296 97                    2091 	.db #0x97	; 151
      00C297 EE                    2092 	.db #0xee	; 238
      00C298 FD                    2093 	.db #0xfd	; 253
      00C299 9F                    2094 	.db #0x9f	; 159
      00C29A 45                    2095 	.db #0x45	; 69	'E'
      00C29B 17                    2096 	.db #0x17	; 23
      00C29C 94                    2097 	.db #0x94	; 148
      00C29D E6                    2098 	.db #0xe6	; 230
      00C29E E7                    2099 	.db #0xe7	; 231
      00C29F FA                    2100 	.db #0xfa	; 250
      00C2A0 4C                    2101 	.db #0x4c	; 76	'L'
      00C2A1 7A                    2102 	.db #0x7a	; 122	'z'
      00C2A2 D6                    2103 	.db #0xd6	; 214
      00C2A3 7A                    2104 	.db #0x7a	; 122	'z'
      00C2A4 7B                    2105 	.db #0x7b	; 123
      00C2A5 ED                    2106 	.db #0xed	; 237
      00C2A6 10                    2107 	.db #0x10	; 16
      00C2A7 C5                    2108 	.db #0xc5	; 197
      00C2A8 BC                    2109 	.db #0xbc	; 188
      00C2A9 E3                    2110 	.db #0xe3	; 227
      00C2AA A9                    2111 	.db #0xa9	; 169
      00C2AB 1F                    2112 	.db #0x1f	; 31
      00C2AC CF                    2113 	.db #0xcf	; 207
      00C2AD C4                    2114 	.db #0xc4	; 196
      00C2AE 9D                    2115 	.db #0x9d	; 157
      00C2AF DC                    2116 	.db #0xdc	; 220
      00C2B0 45                    2117 	.db #0x45	; 69	'E'
      00C2B1 2A                    2118 	.db #0x2a	; 42
      00C2B2 69                    2119 	.db #0x69	; 105	'i'
      00C2B3 57                    2120 	.db #0x57	; 87	'W'
      00C2B4 8F                    2121 	.db #0x8f	; 143
      00C2B5 EC                    2122 	.db #0xec	; 236
      00C2B6 85                    2123 	.db #0x85	; 133
      00C2B7 6C                    2124 	.db #0x6c	; 108	'l'
      00C2B8 43                    2125 	.db #0x43	; 67	'C'
      00C2B9 1C                    2126 	.db #0x1c	; 28
      00C2BA BA                    2127 	.db #0xba	; 186
      00C2BB 89                    2128 	.db #0x89	; 137
      00C2BC 68                    2129 	.db #0x68	; 104	'h'
      00C2BD 4A                    2130 	.db #0x4a	; 74	'J'
      00C2BE 1C                    2131 	.db #0x1c	; 28
      00C2BF 91                    2132 	.db #0x91	; 145
      00C2C0 3F                    2133 	.db #0x3f	; 63
      00C2C1 D1                    2134 	.db #0xd1	; 209
      00C2C2 B3                    2135 	.db #0xb3	; 179
      00C2C3 96                    2136 	.db #0x96	; 150
      00C2C4 1D                    2137 	.db #0x1d	; 29
      00C2C5 7C                    2138 	.db #0x7c	; 124
      00C2C6 14                    2139 	.db #0x14	; 20
      00C2C7 77                    2140 	.db #0x77	; 119	'w'
      00C2C8 9C                    2141 	.db #0x9c	; 156
      00C2C9 74                    2142 	.db #0x74	; 116	't'
      00C2CA 36                    2143 	.db #0x36	; 54	'6'
      00C2CB FF                    2144 	.db #0xff	; 255
      00C2CC 2C                    2145 	.db #0x2c	; 44
      00C2CD 66                    2146 	.db #0x66	; 102	'f'
      00C2CE AF                    2147 	.db #0xaf	; 175
      00C2CF 0F                    2148 	.db #0x0f	; 15
      00C2D0 3C                    2149 	.db #0x3c	; 60
      00C2D1 A2                    2150 	.db #0xa2	; 162
      00C2D2 23                    2151 	.db #0x23	; 35
      00C2D3 85                    2152 	.db #0x85	; 133
      00C2D4 05                    2153 	.db #0x05	; 5
      00C2D5 87                    2154 	.db #0x87	; 135
      00C2D6 DA                    2155 	.db #0xda	; 218
      00C2D7 61                    2156 	.db #0x61	; 97	'a'
      00C2D8 5E                    2157 	.db #0x5e	; 94
      00C2D9 42                    2158 	.db #0x42	; 66	'B'
      00C2DA 54                    2159 	.db #0x54	; 84	'T'
      00C2DB 60                    2160 	.db #0x60	; 96
      00C2DC 23                    2161 	.db #0x23	; 35
      00C2DD CA                    2162 	.db #0xca	; 202
      00C2DE BC                    2163 	.db #0xbc	; 188
      00C2DF B3                    2164 	.db #0xb3	; 179
      00C2E0 18                    2165 	.db #0x18	; 24
      00C2E1 1D                    2166 	.db #0x1d	; 29
      00C2E2 F8                    2167 	.db #0xf8	; 248
      00C2E3 0A                    2168 	.db #0x0a	; 10
      00C2E4 55                    2169 	.db #0x55	; 85	'U'
      00C2E5 CD                    2170 	.db #0xcd	; 205
      00C2E6 A3                    2171 	.db #0xa3	; 163
      00C2E7 DE                    2172 	.db #0xde	; 222
      00C2E8 FF                    2173 	.db #0xff	; 255
      00C2E9 B2                    2174 	.db #0xb2	; 178
      00C2EA 2A                    2175 	.db #0x2a	; 42
      00C2EB 35                    2176 	.db #0x35	; 53	'5'
      00C2EC 00                    2177 	.db #0x00	; 0
      00C2ED D6                    2178 	.db #0xd6	; 214
      00C2EE 7B                    2179 	.db #0x7b	; 123
      00C2EF E8                    2180 	.db #0xe8	; 232
      00C2F0 F2                    2181 	.db #0xf2	; 242
      00C2F1 1A                    2182 	.db #0x1a	; 26
      00C2F2 BC                    2183 	.db #0xbc	; 188
      00C2F3 F5                    2184 	.db #0xf5	; 245
      00C2F4 7E                    2185 	.db #0x7e	; 126
      00C2F5 48                    2186 	.db #0x48	; 72	'H'
      00C2F6 72                    2187 	.db #0x72	; 114	'r'
      00C2F7 E0                    2188 	.db #0xe0	; 224
      00C2F8 E4                    2189 	.db #0xe4	; 228
      00C2F9 E0                    2190 	.db #0xe0	; 224
      00C2FA 27                    2191 	.db #0x27	; 39
      00C2FB 87                    2192 	.db #0x87	; 135
      00C2FC 9A                    2193 	.db #0x9a	; 154
      00C2FD 51                    2194 	.db #0x51	; 81	'Q'
      00C2FE D4                    2195 	.db #0xd4	; 212
      00C2FF DD                    2196 	.db #0xdd	; 221
      00C300 C3                    2197 	.db #0xc3	; 195
      00C301 AA                    2198 	.db #0xaa	; 170
      00C302 49                    2199 	.db #0x49	; 73	'I'
      00C303 5A                    2200 	.db #0x5a	; 90	'Z'
      00C304 2A                    2201 	.db #0x2a	; 42
      00C305 00                    2202 	.db #0x00	; 0
      00C306 A0                    2203 	.db #0xa0	; 160
      00C307 8C                    2204 	.db #0x8c	; 140
      00C308 FF                    2205 	.db #0xff	; 255
      00C309 74                    2206 	.db #0x74	; 116	't'
      00C30A BF                    2207 	.db #0xbf	; 191
      00C30B EC                    2208 	.db #0xec	; 236
      00C30C 1D                    2209 	.db #0x1d	; 29
      00C30D F1                    2210 	.db #0xf1	; 241
      00C30E 00                    2211 	.db #0x00	; 0
      00C30F 01                    2212 	.db #0x01	; 1
      00C310 D8                    2213 	.db #0xd8	; 216
      00C311 02                    2214 	.db #0x02	; 2
      00C312 CC                    2215 	.db #0xcc	; 204
      00C313 07                    2216 	.db #0x07	; 7
      00C314 00                    2217 	.db #0x00	; 0
      00C315 00                    2218 	.db #0x00	; 0
      00C316 C4                    2219 	.db #0xc4	; 196
      00C317 5E                    2220 	.db #0x5e	; 94
      00C318 2C                    2221 	.db #0x2c	; 44
      00C319 7E                    2222 	.db #0x7e	; 126
      00C31A B1                    2223 	.db #0xb1	; 177
      00C31B C4                    2224 	.db #0xc4	; 196
      00C31C 67                    2225 	.db #0x67	; 103	'g'
      00C31D FB                    2226 	.db #0xfb	; 251
      00C31E 02                    2227 	.db #0x02	; 2
      00C31F 00                    2228 	.db #0x00	; 0
      00C320 00                    2229 	.db #0x00	; 0
      00C321 00                    2230 	.db #0x00	; 0
      00C322 00                    2231 	.db #0x00	; 0
      00C323 04                    2232 	.db #0x04	; 4
      00C324 59                    2233 	.db #0x59	; 89	'Y'
      00C325 5A                    2234 	.db #0x5a	; 90	'Z'
                                   2235 	.area CSEG    (CODE)
                                   2236 	.area CONST   (CODE)
      00C326                       2237 _vial_handle_cmd_keyboard_uid_40000_646:
      00C326 04                    2238 	.db #0x04	; 4
      00C327 70                    2239 	.db #0x70	; 112	'p'
      00C328 FF                    2240 	.db #0xff	; 255
      00C329 90                    2241 	.db #0x90	; 144
      00C32A 01                    2242 	.db #0x01	; 1
      00C32B B9                    2243 	.db #0xb9	; 185
      00C32C 15                    2244 	.db #0x15	; 21
      00C32D D3                    2245 	.db #0xd3	; 211
                                   2246 	.area CSEG    (CODE)
                                   2247 	.area XINIT   (CODE)
      00C55C                       2248 __xinit__vial_unlocked:
      00C55C 00                    2249 	.db #0x00	;  0
      00C55D                       2250 __xinit__vial_unlock_in_progress:
      00C55D 00                    2251 	.db #0x00	;  0
      00C55E                       2252 __xinit__vial_unlock_counter:
      00C55E 00                    2253 	.db #0x00	; 0
      00C55F                       2254 __xinit__vial_unlock_combo_rows:
      00C55F 00                    2255 	.db #0x00	; 0
      00C560 00                    2256 	.db #0x00	; 0
      00C561                       2257 __xinit__vial_unlock_combo_cols:
      00C561 00                    2258 	.db #0x00	; 0
      00C562 05                    2259 	.db #0x05	; 5
                                   2260 	.area CABS    (ABS,CODE)
                                   2261 
                                   2262 ; Experimental exact instruction outlining.
                                   2263 	.globl _ak820_outline_0004
                                   2264 	.globl _ak820_outline_0007
                                   2265 	.globl _ak820_outline_0008
                                   2266 	.globl _ak820_outline_0010
                                   2267 	.globl _ak820_outline_0011
                                   2268 	.globl _ak820_outline_0012
                                   2269 	.globl _ak820_outline_0015
                                   2270 	.globl _ak820_outline_0016
                                   2271 	.globl _ak820_outline_0017
                                   2272 	.globl _ak820_outline_0022
                                   2273 	.globl _ak820_outline_0025
                                   2274 	.globl _ak820_outline_0031
                                   2275 	.globl _ak820_outline_0034
                                   2276 	.globl _ak820_outline_0037
                                   2277 	.globl _ak820_outline_0051
                                   2278 	.globl _ak820_outline_0054
                                   2279 	.globl _ak820_outline_0057
                                   2280 	.globl _ak820_outline_0060
                                   2281 	.globl _ak820_outline_0061
                                   2282 	.globl _ak820_outline_0074
                                   2283 	.globl _ak820_outline_0084
                                   2284 	.globl _ak820_outline_0085
                                   2285 	.globl _ak820_outline_0094
                                   2286 	.globl _ak820_outline_0105
                                   2287 	.globl _ak820_outline_0106
                                   2288 	.globl _ak820_outline_0107
                                   2289 	.globl _ak820_outline_0121
                                   2290 	.globl _ak820_outline_0124
                                   2291 	.globl _ak820_outline_0126
                                   2292 	.globl _ak820_outline_0127
                                   2293 	.globl _ak820_outline_0129
                                   2294 	.globl _ak820_outline_0130
                                   2295 	.globl _ak820_outline_0135
                                   2296 	.globl _ak820_outline_0139
                                   2297 	.globl _ak820_outline_0141
                                   2298 	.globl _ak820_outline_0144
                                   2299 	.globl _ak820_outline_0149
                                   2300 	.globl _ak820_outline_0154
                                   2301 	.globl _ak820_outline_0173
                                   2302 	.globl _ak820_outline_0189
                                   2303 
                                   2304 	.area CSEG (CODE)
                                   2305 ; function ak820_outline_0008
      00B530                       2306 _ak820_outline_0008:
      00B530 8E 82            [24] 2307 	mov	dpl,r6
      00B532 8F 83            [24] 2308 	mov	dph,r7
      00B534 A3               [24] 2309 	inc	dptr
      00B535 A3               [24] 2310 	inc	dptr
      00B536 E0               [24] 2311 	movx	a,@dptr
      00B537 FA               [12] 2312 	mov	r2,a
      00B538 8E 82            [24] 2313 	mov	dpl,r6
      00B53A 8F 83            [24] 2314 	mov	dph,r7
      00B53C A3               [24] 2315 	inc	dptr
      00B53D A3               [24] 2316 	inc	dptr
      00B53E A3               [24] 2317 	inc	dptr
      00B53F E0               [24] 2318 	movx	a,@dptr
      00B540 F8               [12] 2319 	mov	r0,a
      00B541 79 00            [12] 2320 	mov	r1,#0x00
      00B543 22               [24] 2321 	ret
                                   2322 
                                   2323 	.area CSEG (CODE)
                                   2324 ; function ak820_outline_0025
      00B544                       2325 _ak820_outline_0025:
      00B544 E0               [24] 2326 	movx	a,@dptr
      00B545 FE               [12] 2327 	mov	r6,a
      00B546 A3               [24] 2328 	inc	dptr
      00B547 E0               [24] 2329 	movx	a,@dptr
      00B548 FF               [12] 2330 	mov	r7,a
      00B549 90 0C 95         [24] 2331 	mov	dptr,#_g_vial_magic_keycode_override
      00B54C EE               [12] 2332 	mov	a,r6
      00B54D F0               [24] 2333 	movx	@dptr,a
      00B54E EF               [12] 2334 	mov	a,r7
      00B54F A3               [24] 2335 	inc	dptr
      00B550 F0               [24] 2336 	movx	@dptr,a
      00B551 8E 04            [24] 2337 	mov	ar4,r6
      00B553 8F 05            [24] 2338 	mov	ar5,r7
      00B555 C3               [12] 2339 	clr	c
      00B556 74 FF            [12] 2340 	mov	a,#0xff
      00B558 9C               [12] 2341 	subb	a,r4
      00B559 74 1F            [12] 2342 	mov	a,#0x1f
      00B55B 9D               [12] 2343 	subb	a,r5
      00B55C 22               [24] 2344 	ret
                                   2345 
                                   2346 	.area CSEG (CODE)
                                   2347 ; function ak820_outline_0074
      00B55D                       2348 _ak820_outline_0074:
      00B55D A3               [24] 2349 	inc	dptr
      00B55E F0               [24] 2350 	movx	@dptr,a
      00B55F E4               [12] 2351 	clr	a
      00B560 A3               [24] 2352 	inc	dptr
      00B561 F0               [24] 2353 	movx	@dptr,a
      00B562 90 0D C0         [24] 2354 	mov	dptr,#___memcpy_PARM_3
      00B565 74 0A            [12] 2355 	mov	a,#0x0a
      00B567 F0               [24] 2356 	movx	@dptr,a
      00B568 E4               [12] 2357 	clr	a
      00B569 A3               [24] 2358 	inc	dptr
      00B56A F0               [24] 2359 	movx	@dptr,a
      00B56B 22               [24] 2360 	ret
                                   2361 
                                   2362 	.area CSEG (CODE)
                                   2363 ; function ak820_outline_0129
      00B56C                       2364 _ak820_outline_0129:
      00B56C 24 4A            [12] 2365 	add	a,#_vial_unlock_combo_cols
      00B56E F5 82            [12] 2366 	mov	dpl,a
      00B570 E4               [12] 2367 	clr	a
      00B571 34 0E            [12] 2368 	addc	a,#(_vial_unlock_combo_cols>>8)
      00B573 F5 83            [12] 2369 	mov	dph,a
      00B575 E0               [24] 2370 	movx	a,@dptr
      00B576 22               [24] 2371 	ret
                                   2372 
                                   2373 	.area CSEG (CODE)
                                   2374 ; function ak820_outline_0130
      00B577                       2375 _ak820_outline_0130:
      00B577 24 48            [12] 2376 	add	a,#_vial_unlock_combo_rows
      00B579 F5 82            [12] 2377 	mov	dpl,a
      00B57B E4               [12] 2378 	clr	a
      00B57C 34 0E            [12] 2379 	addc	a,#(_vial_unlock_combo_rows>>8)
      00B57E F5 83            [12] 2380 	mov	dph,a
      00B580 E0               [24] 2381 	movx	a,@dptr
      00B581 22               [24] 2382 	ret
