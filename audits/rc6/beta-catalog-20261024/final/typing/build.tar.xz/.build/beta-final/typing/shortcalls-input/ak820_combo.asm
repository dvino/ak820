;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (Linux)
;--------------------------------------------------------
	.module ak820_combo
	
	.optsdcc -mmcs51 --model-large
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _dynamic_keymap_get_combo
	.globl _process_record
	.globl _ADC_START
	.globl _S0_R_FIFO
	.globl _S0_T_FIFO
	.globl _S0_FREE
	.globl _S0_IF_BYTE
	.globl _S0_IF_FIRST
	.globl _S0_IF_OV
	.globl _S0_FST_ACT
	.globl _CP_RL2
	.globl _C_T2
	.globl _TR2
	.globl _EXEN2
	.globl _TCLK
	.globl _RCLK
	.globl _EXF2
	.globl _CAP1F
	.globl _TF2
	.globl _RI
	.globl _TI
	.globl _RB8
	.globl _TB8
	.globl _REN
	.globl _SM2
	.globl _SM1
	.globl _SM0
	.globl _IT0
	.globl _IE0
	.globl _IT1
	.globl _IE1
	.globl _TR0
	.globl _TF0
	.globl _TR1
	.globl _TF1
	.globl _P4_0
	.globl _P4_1
	.globl _P4_2
	.globl _P4_3
	.globl _P4_4
	.globl _P4_5
	.globl _P4_6
	.globl _RXD
	.globl _TXD
	.globl _INT0
	.globl _INT1
	.globl _T0
	.globl _T1
	.globl _MOSI1
	.globl _MISO1
	.globl _SCK1
	.globl _P3_0
	.globl _P3_1
	.globl _P3_2
	.globl _P3_3
	.globl _P3_4
	.globl _P3_5
	.globl _P3_6
	.globl _P3_7
	.globl _CAP1_
	.globl _T2_
	.globl _CAP2_
	.globl _T2EX_
	.globl _RXD1
	.globl _TXD1
	.globl _P2_0
	.globl _P2_1
	.globl _P2_2
	.globl _P2_3
	.globl _P2_4
	.globl _P2_5
	.globl _P2_6
	.globl _P2_7
	.globl _AIN0
	.globl _AIN1
	.globl _AIN2
	.globl _AIN3
	.globl _AIN4
	.globl _AIN5
	.globl _AIN6
	.globl _AIN7
	.globl _CAP1
	.globl _T2
	.globl _CAP2
	.globl _T2EX
	.globl _INT0_
	.globl _SCS
	.globl _MOSI
	.globl _MISO
	.globl _SCK
	.globl _RXD1_
	.globl _TXD1_
	.globl _P1_0
	.globl _P1_1
	.globl _P1_2
	.globl _P1_3
	.globl _P1_4
	.globl _P1_5
	.globl _P1_6
	.globl _P1_7
	.globl _AIN8
	.globl _AIN9
	.globl _AIN10
	.globl _AIN11
	.globl _AIN12
	.globl _AIN13
	.globl _RXD_
	.globl _TXD_
	.globl _SCL0
	.globl _SDA0
	.globl _P0_0
	.globl _P0_1
	.globl _P0_2
	.globl _P0_3
	.globl _P0_4
	.globl _P0_5
	.globl _P0_6
	.globl _P0_7
	.globl _IE_SPI0
	.globl _IE_USB
	.globl _IE_ADC
	.globl _IE_UART1
	.globl _IE_PWM_I2C
	.globl _IE_GPIO
	.globl _IE_WDOG
	.globl _PX0
	.globl _PT0
	.globl _PX1
	.globl _PT1
	.globl _PS
	.globl _PT2
	.globl _PL_FLAG
	.globl _PH_FLAG
	.globl _EX0
	.globl _ET0
	.globl _EX1
	.globl _ET1
	.globl _ES
	.globl _ET2
	.globl _E_DIS
	.globl _EA
	.globl _P
	.globl _F1
	.globl _OV
	.globl _RS0
	.globl _RS1
	.globl _F0
	.globl _AC
	.globl _CY
	.globl _I2CS_INT_ST
	.globl _I2CX_INT
	.globl _LED_STATUS
	.globl _LED_DMA_H
	.globl _LED_DMA_L
	.globl _LED_DMA
	.globl _LED_PWM_OE
	.globl _LED_COMMON
	.globl _ADC_CHAN
	.globl _ADC_DAT_H
	.globl _ADC_DAT_L
	.globl _ADC_DAT
	.globl _ADC_CTRL
	.globl _SPI1_CK_SE
	.globl _SPI1_CTRL
	.globl _SPI1_DATA
	.globl _SPI1_STAT
	.globl _SIF1
	.globl _SBAUD1
	.globl _SBUF1
	.globl _SCON1
	.globl _SPI0_SETUP
	.globl _SPI0_CK_SE
	.globl _SPI0_CTRL
	.globl _SPI0_DATA
	.globl _SPI0_STAT
	.globl _T2CAP1H
	.globl _T2CAP1L
	.globl _T2CAP1
	.globl _TH2
	.globl _TL2
	.globl _T2COUNT
	.globl _RCAP2H
	.globl _RCAP2L
	.globl _RCAP2
	.globl _T2MOD
	.globl _T2CON
	.globl _SBUF
	.globl _SCON
	.globl _TH1
	.globl _TH0
	.globl _TL1
	.globl _TL0
	.globl _TMOD
	.globl _TCON
	.globl _XBUS_AUX
	.globl _P7
	.globl _P6_DIR
	.globl _P6_OUT_PU
	.globl _P6_IN
	.globl _P5_DIR
	.globl _P5_OUT_PU
	.globl _P5_IN
	.globl _P4_LED_KEY
	.globl _P4_DIR_PU
	.globl _P4_MOD_OC
	.globl _P4
	.globl _P3_DIR_PU
	.globl _P3_MOD_OC
	.globl _P3
	.globl _P2_DIR_PU
	.globl _P2_MOD_OC
	.globl _P2
	.globl _P1_DIR_PU
	.globl _P1_MOD_OC
	.globl _P1
	.globl _P0_DIR_PU
	.globl _P0_MOD_OC
	.globl _P0
	.globl _ROM_CTRL
	.globl _ROM_DATA_HH
	.globl _ROM_DATA_HL
	.globl _ROM_DATA_HI
	.globl _ROM_ADDR_H
	.globl _ROM_ADDR_L
	.globl _ROM_ADDR
	.globl _GPIO_IE
	.globl _IP_EX
	.globl _IE_EX
	.globl _IP
	.globl _IE
	.globl _WDOG_COUNT
	.globl _RESET_KEEP
	.globl _WAKE_CTRL
	.globl _CLOCK_CFG
	.globl _POWER_CFG
	.globl _PCON
	.globl _GLOBAL_CFG
	.globl _SAFE_MOD
	.globl _DPH
	.globl _DPL
	.globl _SP
	.globl _A_INV
	.globl _B
	.globl _ACC
	.globl _PSW
	.globl _ak820_combo_valid
	.globl _ak820_combo_cancel
	.globl _ak820_combo_reload
	.globl _ak820_combo_tick
	.globl _ak820_combo_process
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
_PSW	=	0x00d0
_ACC	=	0x00e0
_B	=	0x00f0
_A_INV	=	0x00fd
_SP	=	0x0081
_DPL	=	0x0082
_DPH	=	0x0083
_SAFE_MOD	=	0x00a1
_GLOBAL_CFG	=	0x00b1
_PCON	=	0x0087
_POWER_CFG	=	0x00ba
_CLOCK_CFG	=	0x00b9
_WAKE_CTRL	=	0x00a9
_RESET_KEEP	=	0x00fe
_WDOG_COUNT	=	0x00ff
_IE	=	0x00a8
_IP	=	0x00b8
_IE_EX	=	0x00e8
_IP_EX	=	0x00e9
_GPIO_IE	=	0x00b2
_ROM_ADDR	=	0x8584
_ROM_ADDR_L	=	0x0084
_ROM_ADDR_H	=	0x0085
_ROM_DATA_HI	=	0x8f8e
_ROM_DATA_HL	=	0x008e
_ROM_DATA_HH	=	0x008f
_ROM_CTRL	=	0x0086
_P0	=	0x0080
_P0_MOD_OC	=	0x00c4
_P0_DIR_PU	=	0x00c5
_P1	=	0x0090
_P1_MOD_OC	=	0x0092
_P1_DIR_PU	=	0x0093
_P2	=	0x00a0
_P2_MOD_OC	=	0x0094
_P2_DIR_PU	=	0x0095
_P3	=	0x00b0
_P3_MOD_OC	=	0x0096
_P3_DIR_PU	=	0x0097
_P4	=	0x00c0
_P4_MOD_OC	=	0x00c2
_P4_DIR_PU	=	0x00c3
_P4_LED_KEY	=	0x00c1
_P5_IN	=	0x00aa
_P5_OUT_PU	=	0x00ab
_P5_DIR	=	0x00ac
_P6_IN	=	0x00ad
_P6_OUT_PU	=	0x00ae
_P6_DIR	=	0x00af
_P7	=	0x00f1
_XBUS_AUX	=	0x00a2
_TCON	=	0x0088
_TMOD	=	0x0089
_TL0	=	0x008a
_TL1	=	0x008b
_TH0	=	0x008c
_TH1	=	0x008d
_SCON	=	0x0098
_SBUF	=	0x0099
_T2CON	=	0x00c8
_T2MOD	=	0x00c9
_RCAP2	=	0xcbca
_RCAP2L	=	0x00ca
_RCAP2H	=	0x00cb
_T2COUNT	=	0xcdcc
_TL2	=	0x00cc
_TH2	=	0x00cd
_T2CAP1	=	0xcfce
_T2CAP1L	=	0x00ce
_T2CAP1H	=	0x00cf
_SPI0_STAT	=	0x00f8
_SPI0_DATA	=	0x00f9
_SPI0_CTRL	=	0x00fa
_SPI0_CK_SE	=	0x00fb
_SPI0_SETUP	=	0x00fc
_SCON1	=	0x00bc
_SBUF1	=	0x00bd
_SBAUD1	=	0x00be
_SIF1	=	0x00bf
_SPI1_STAT	=	0x00b4
_SPI1_DATA	=	0x00b5
_SPI1_CTRL	=	0x00b6
_SPI1_CK_SE	=	0x00b7
_ADC_CTRL	=	0x00f3
_ADC_DAT	=	0xf5f4
_ADC_DAT_L	=	0x00f4
_ADC_DAT_H	=	0x00f5
_ADC_CHAN	=	0x00f6
_LED_COMMON	=	0x00a6
_LED_PWM_OE	=	0x00a7
_LED_DMA	=	0xc7c6
_LED_DMA_L	=	0x00c6
_LED_DMA_H	=	0x00c7
_LED_STATUS	=	0x00f7
_I2CX_INT	=	0x00b3
_I2CS_INT_ST	=	0x00bb
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
_CY	=	0x00d7
_AC	=	0x00d6
_F0	=	0x00d5
_RS1	=	0x00d4
_RS0	=	0x00d3
_OV	=	0x00d2
_F1	=	0x00d1
_P	=	0x00d0
_EA	=	0x00af
_E_DIS	=	0x00ae
_ET2	=	0x00ad
_ES	=	0x00ac
_ET1	=	0x00ab
_EX1	=	0x00aa
_ET0	=	0x00a9
_EX0	=	0x00a8
_PH_FLAG	=	0x00bf
_PL_FLAG	=	0x00be
_PT2	=	0x00bd
_PS	=	0x00bc
_PT1	=	0x00bb
_PX1	=	0x00ba
_PT0	=	0x00b9
_PX0	=	0x00b8
_IE_WDOG	=	0x00ef
_IE_GPIO	=	0x00ee
_IE_PWM_I2C	=	0x00ed
_IE_UART1	=	0x00ec
_IE_ADC	=	0x00eb
_IE_USB	=	0x00e9
_IE_SPI0	=	0x00e8
_P0_7	=	0x0087
_P0_6	=	0x0086
_P0_5	=	0x0085
_P0_4	=	0x0084
_P0_3	=	0x0083
_P0_2	=	0x0082
_P0_1	=	0x0081
_P0_0	=	0x0080
_SDA0	=	0x0081
_SCL0	=	0x0080
_TXD_	=	0x0083
_RXD_	=	0x0082
_AIN13	=	0x0085
_AIN12	=	0x0084
_AIN11	=	0x0083
_AIN10	=	0x0082
_AIN9	=	0x0081
_AIN8	=	0x0080
_P1_7	=	0x0097
_P1_6	=	0x0096
_P1_5	=	0x0095
_P1_4	=	0x0094
_P1_3	=	0x0093
_P1_2	=	0x0092
_P1_1	=	0x0091
_P1_0	=	0x0090
_TXD1_	=	0x0097
_RXD1_	=	0x0096
_SCK	=	0x0097
_MISO	=	0x0096
_MOSI	=	0x0095
_SCS	=	0x0094
_INT0_	=	0x0092
_T2EX	=	0x0091
_CAP2	=	0x0091
_T2	=	0x0090
_CAP1	=	0x0090
_AIN7	=	0x0097
_AIN6	=	0x0096
_AIN5	=	0x0095
_AIN4	=	0x0094
_AIN3	=	0x0093
_AIN2	=	0x0092
_AIN1	=	0x0091
_AIN0	=	0x0090
_P2_7	=	0x00a7
_P2_6	=	0x00a6
_P2_5	=	0x00a5
_P2_4	=	0x00a4
_P2_3	=	0x00a3
_P2_2	=	0x00a2
_P2_1	=	0x00a1
_P2_0	=	0x00a0
_TXD1	=	0x00a7
_RXD1	=	0x00a6
_T2EX_	=	0x00a5
_CAP2_	=	0x00a5
_T2_	=	0x00a4
_CAP1_	=	0x00a4
_P3_7	=	0x00b7
_P3_6	=	0x00b6
_P3_5	=	0x00b5
_P3_4	=	0x00b4
_P3_3	=	0x00b3
_P3_2	=	0x00b2
_P3_1	=	0x00b1
_P3_0	=	0x00b0
_SCK1	=	0x00b7
_MISO1	=	0x00b6
_MOSI1	=	0x00b5
_T1	=	0x00b5
_T0	=	0x00b4
_INT1	=	0x00b3
_INT0	=	0x00b2
_TXD	=	0x00b1
_RXD	=	0x00b0
_P4_6	=	0x00c6
_P4_5	=	0x00c5
_P4_4	=	0x00c4
_P4_3	=	0x00c3
_P4_2	=	0x00c2
_P4_1	=	0x00c1
_P4_0	=	0x00c0
_TF1	=	0x008f
_TR1	=	0x008e
_TF0	=	0x008d
_TR0	=	0x008c
_IE1	=	0x008b
_IT1	=	0x008a
_IE0	=	0x0089
_IT0	=	0x0088
_SM0	=	0x009f
_SM1	=	0x009e
_SM2	=	0x009d
_REN	=	0x009c
_TB8	=	0x009b
_RB8	=	0x009a
_TI	=	0x0099
_RI	=	0x0098
_TF2	=	0x00cf
_CAP1F	=	0x00cf
_EXF2	=	0x00ce
_RCLK	=	0x00cd
_TCLK	=	0x00cc
_EXEN2	=	0x00cb
_TR2	=	0x00ca
_C_T2	=	0x00c9
_CP_RL2	=	0x00c8
_S0_FST_ACT	=	0x00ff
_S0_IF_OV	=	0x00fe
_S0_IF_FIRST	=	0x00fd
_S0_IF_BYTE	=	0x00fc
_S0_FREE	=	0x00fb
_S0_T_FIFO	=	0x00fa
_S0_R_FIFO	=	0x00f8
_ADC_START	=	0x00f7
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram
;--------------------------------------------------------
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; absolute internal ram data
;--------------------------------------------------------
	.area IABS    (ABS,DATA)
	.area IABS    (ABS,DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
_ak820_combo_valid_sloc0_1_0:
	.ds 1
_ak820_combo_process_sloc0_1_0:
	.ds 1
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; uninitialized external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
_combos:
	.ds 32
_saved:
	.ds 9
_active:
	.ds 1
_ak820_combo_valid_entry_10000_592:
	.ds 2
_ak820_combo_reload_entry_30000_604:
	.ds 10
_ak820_combo_tick_now_10000_609:
	.ds 2
_ak820_combo_process_record_10000_612:
	.ds 2
_ak820_combo_process_eligible_10001_627:
	.ds 1
_ak820_combo_process_i_40001_630:
	.ds 1
_ak820_combo_process_a_50001_631:
	.ds 1
_ak820_combo_process_b_50001_631:
	.ds 1
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area XABS    (ABS,XDATA)
;--------------------------------------------------------
; initialized external ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
_first:
	.ds 1
_second:
	.ds 1
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area HOME    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
;------------------------------------------------------------
;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
;------------------------------------------------------------
;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
;	-----------------------------------------
	ar7 = 0x07
	ar6 = 0x06
	ar5 = 0x05
	ar4 = 0x04
	ar3 = 0x03
	ar2 = 0x02
	ar1 = 0x01
	ar0 = 0x00
;	 function ak820_combo_valid
;	-----------------------------------------
_ak820_combo_valid:
	lcall	_ak820_outline_0103
	mov	dptr,#_ak820_combo_valid_entry_10000_592
	lcall	_ak820_outline_0104
;	keyboards/ajazz/ak820/ak820_combo.c:24: if (entry->input[2] || entry->input[3]) return false;
	mov	dptr,#_ak820_combo_valid_entry_10000_592
	lcall	_ak820_outline_0004
	inc	dptr
	inc	dptr
	inc	dptr
	inc	dptr
	lcall	_ak820_outline_0165
	jnz	00101$
	mov	a,#0x06
	lcall	_ak820_outline_0017
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	orl	a,r4
	jz	00102$
00101$:
	mov	dpl, #0x00
	ret
00102$:
;	keyboards/ajazz/ak820/ak820_combo.c:25: if (!(entry->input[0] | entry->input[1])) return !entry->output;
	mov	ar4,r6
	mov	ar5,r7
	lcall	_ak820_outline_0034
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	lcall	_ak820_outline_0117
	lcall	_ak820_outline_0060
	mov	a,r2
	orl	a,r4
	mov	r0,a
	mov	a,r3
	orl	a,r5
	orl	a,r0
	jnz	00105$
	mov	a,#0x08
	lcall	_ak820_outline_0017
	mov	r0,a
	inc	dptr
	movx	a,@dptr
	orl	a,r0
	cjne	a,#0x01,00187$
00187$:
	mov  _ak820_combo_valid_sloc0_1_0,c
	lcall	_ak820_outline_0167
	ret
00105$:
;	keyboards/ajazz/ak820/ak820_combo.c:26: if (entry->input[0] == entry->input[1]) return false;
	mov	a,r4
	cjne	a,ar2,00107$
	mov	a,r5
	cjne	a,ar3,00107$
	mov	dpl, #0x00
	ret
00107$:
;	keyboards/ajazz/ak820/ak820_combo.c:27: if (!COMBO_INPUT(entry->input[0])) return false;
	clr	c
	mov	a,r4
	subb	a,#0x04
	mov	a,r5
	subb	a,#0x00
	jc	00108$
	mov	a,#0xa4
	subb	a,r4
	clr	a
	subb	a,r5
	jnc	00109$
;	free result
00108$:
	mov	dpl, #0x00
	ret
00109$:
;	keyboards/ajazz/ak820/ak820_combo.c:28: if (!COMBO_INPUT(entry->input[1])) return false;
	clr	c
	mov	a,r2
	subb	a,#0x04
	mov	a,r3
	subb	a,#0x00
	jc	00111$
	mov	a,#0xa4
	subb	a,r2
	clr	a
	subb	a,r3
	jnc	00112$
;	free result
00111$:
	mov	dpl, #0x00
	ret
00112$:
;	keyboards/ajazz/ak820/ak820_combo.c:29: return COMBO_OUTPUT(entry->output);
	mov	a,#0x08
	lcall	_ak820_outline_0031
	lcall	_ak820_outline_0010
	mov	a,#0x100 - 0x20
	add	a,r5
	jc	00116$
	cjne	r6,#0x04,00195$
00195$:
	jc	00124$
	mov	a,r6
	add	a,#0xff - 0xa4
	jnc	00117$
;	free result
00124$:
	mov	dptr,#_ak820_combo_valid_entry_10000_592
	lcall	_ak820_outline_0051
	mov	a,#0x08
	lcall	_ak820_outline_0017
	mov	r7,a
	cjne	r7,#0xe0,00198$
00198$:
	jc	00116$
	mov	a,r7
	add	a,#0xff - 0xe7
	jnc	00117$
;	free result
00116$:
;	assignBit
	clr	_ak820_combo_valid_sloc0_1_0
	sjmp	00118$
00117$:
;	assignBit
	setb	_ak820_combo_valid_sloc0_1_0
00118$:
	mov	c,_ak820_combo_valid_sloc0_1_0
	lcall	_ak820_outline_0167
;	keyboards/ajazz/ak820/ak820_combo.c:30: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_combo_cancel'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_combo.c:33: void ak820_combo_cancel(void) { first = second = NONE; active = false; }
;	-----------------------------------------
;	 function ak820_combo_cancel
;	-----------------------------------------
_ak820_combo_cancel:
	mov	dptr,#_second
	mov	a,#0xff
	movx	@dptr,a
	mov	dptr,#_first
	movx	@dptr,a
	mov	dptr,#_active
	clr	a
	movx	@dptr,a
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_combo_reload'
;------------------------------------------------------------
;i             Allocated with name '_ak820_combo_reload_i_20000_603'
;entry         Allocated with name '_ak820_combo_reload_entry_30000_604'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_combo.c:34: void ak820_combo_reload(void) {
;	-----------------------------------------
;	 function ak820_combo_reload
;	-----------------------------------------
_ak820_combo_reload:
;	keyboards/ajazz/ak820/ak820_combo.c:35: for (uint8_t i = 0; i < VIAL_COMBO_ENTRIES; ++i) {
	mov	r7,#0x00
00105$:
	cjne	r7,#0x08,00131$
00131$:
	jc	00132$
	ret
00132$:
;	keyboards/ajazz/ak820/ak820_combo.c:37: combos[i].a = 0;
	mov	a,r7
	mov	b,#0x04
	mul	ab
	add	a, #_combos
	mov	r5,a
	mov	a,#(_combos >> 8)
	addc	a, b
	mov	r6,a
	mov	ar3,r5
	mov	ar4,r6
	lcall	_ak820_outline_0122
	clr	a
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_combo.c:38: if (!dynamic_keymap_get_combo(i, &entry)) {
	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
	mov	a,#_ak820_combo_reload_entry_30000_604
	movx	@dptr,a
	mov	a,#(_ak820_combo_reload_entry_30000_604 >> 8)
	lcall	_ak820_outline_0097
	mov	dpl, r7
	push	ar7
	push	ar6
	push	ar5
	push	ar4
	push	ar3
	lcall	_dynamic_keymap_get_combo
	lcall	_ak820_outline_0135
	pop	ar3
	pop	ar4
	pop	ar5
	pop	ar6
	pop	ar7
	orl	a,b
	jnz	00106$
;	keyboards/ajazz/ak820/ak820_combo.c:39: combos[i].a = entry.input[0];
	mov	dptr,#_ak820_combo_reload_entry_30000_604
	movx	a,@dptr
	lcall	_ak820_outline_0122
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_combo.c:40: combos[i].b = entry.input[1];
	mov	a,#0x01
	add	a, r5
	mov	r3,a
	clr	a
	addc	a, r6
	mov	r4,a
	mov	dptr,#(_ak820_combo_reload_entry_30000_604 + 0x0002)
	movx	a,@dptr
	lcall	_ak820_outline_0122
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_combo.c:41: combos[i].output = entry.output;
	mov	a,#0x02
	lcall	_ak820_outline_0155
	mov	dptr,#(_ak820_combo_reload_entry_30000_604 + 0x0008)
	lcall	_ak820_outline_0121
	lcall	_ak820_outline_0132
	lcall	_ak820_outline_0077
00106$:
;	keyboards/ajazz/ak820/ak820_combo.c:35: for (uint8_t i = 0; i < VIAL_COMBO_ENTRIES; ++i) {
	inc	r7
;	keyboards/ajazz/ak820/ak820_combo.c:44: }
	ljmp	00105$
;------------------------------------------------------------
;Allocation info for local variables in function 'flush'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_combo.c:45: static void flush(void) {
;	-----------------------------------------
;	 function flush
;	-----------------------------------------
_flush:
;	keyboards/ajazz/ak820/ak820_combo.c:46: first = NONE;
	mov	dptr,#_first
	mov	a,#0xff
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_combo.c:47: process_record(&saved);
	mov	dptr,#_saved
;	keyboards/ajazz/ak820/ak820_combo.c:48: }
	ljmp	_process_record
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_combo_tick'
;------------------------------------------------------------
;now           Allocated with name '_ak820_combo_tick_now_10000_609'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_combo.c:49: void ak820_combo_tick(uint16_t now) {
;	-----------------------------------------
;	 function ak820_combo_tick
;	-----------------------------------------
_ak820_combo_tick:
	lcall	_ak820_outline_0103
	mov	dptr,#_ak820_combo_tick_now_10000_609
	lcall	_ak820_outline_0104
;	keyboards/ajazz/ak820/ak820_combo.c:50: if (first != NONE && !active && (uint16_t)(now - saved.event.time) >= AK820_COMBO_TERM) flush();
	lcall	_ak820_outline_0181
	mov	r7,a
	cjne	r7,#0xff,00128$
	ret
00128$:
	mov	dptr,#_active
	movx	a,@dptr
	jnz	00105$
	mov	dptr,#(_saved + 0x0002)
	lcall	_ak820_outline_0051
	mov	dptr,#_ak820_combo_tick_now_10000_609
	lcall	_ak820_outline_0060
	mov	a,r4
	clr	c
	subb	a,r6
	mov	r6,a
	mov	a,r5
	subb	a,r7
	mov	r7,a
	clr	c
	mov	a,r6
	subb	a,#0x28
	mov	a,r7
	subb	a,#0x00
	jc	00105$
;	keyboards/ajazz/ak820/ak820_combo.c:51: }
	ljmp	_flush
00105$:
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ak820_combo_process'
;------------------------------------------------------------
;record        Allocated with name '_ak820_combo_process_record_10000_612'
;id            Allocated with name '_ak820_combo_process_id_10000_613'
;code          Allocated with name '_ak820_combo_process_code_10000_613'
;eligible      Allocated with name '_ak820_combo_process_eligible_10001_627'
;previous      Allocated with name '_ak820_combo_process_previous_30001_629'
;i             Allocated with name '_ak820_combo_process_i_40001_630'
;a             Allocated with name '_ak820_combo_process_a_50001_631'
;b             Allocated with name '_ak820_combo_process_b_50001_631'
;------------------------------------------------------------
;	keyboards/ajazz/ak820/ak820_combo.c:52: bool ak820_combo_process(keyrecord_t AK820_STATE_MEM *record) {
;	-----------------------------------------
;	 function ak820_combo_process
;	-----------------------------------------
_ak820_combo_process:
	lcall	_ak820_outline_0103
	mov	dptr,#_ak820_combo_process_record_10000_612
	lcall	_ak820_outline_0104
;	keyboards/ajazz/ak820/ak820_combo.c:53: uint8_t id, code = record->keycode;
	mov	dptr,#_ak820_combo_process_record_10000_612
	lcall	_ak820_outline_0009
	mov	ar3,r4
;	keyboards/ajazz/ak820/ak820_combo.c:54: if (IS_NOEVENT(record->event)) return true;
	mov	a,#0x04
	add	a, r6
	lcall	_ak820_outline_0014
	jnz	00102$
	mov	dpl, #0x01
	ret
00102$:
;	keyboards/ajazz/ak820/ak820_combo.c:56: if (record->event.key.row >= MATRIX_ROWS || record->event.key.col >= MATRIX_COLS) {
	lcall	_ak820_outline_0108
	mov	r2,a
	cjne	r2,#0x10,00308$
00308$:
	jnc	00106$
	lcall	_ak820_outline_0098
	mov	r1,a
	cjne	r1,#0x08,00310$
00310$:
	jc	00107$
00106$:
;	keyboards/ajazz/ak820/ak820_combo.c:57: if (first != NONE && !active) flush();
	lcall	_ak820_outline_0181
	mov	r0,a
	cjne	r0,#0xff,00312$
	sjmp	00104$
00312$:
	mov	dptr,#_active
	movx	a,@dptr
	jnz	00104$
	lcall	_flush
00104$:
;	keyboards/ajazz/ak820/ak820_combo.c:58: return true;
	mov	dpl, #0x01
	ret
00107$:
;	keyboards/ajazz/ak820/ak820_combo.c:60: id = record->event.key.row * MATRIX_COLS + record->event.key.col;
	mov	a,r2
	lcall	_ak820_outline_0186
	add	a,r1
	mov	r2,a
;	keyboards/ajazz/ak820/ak820_combo.c:61: if (active) {
	mov	dptr,#_active
	movx	a,@dptr
	jz	00123$
;	keyboards/ajazz/ak820/ak820_combo.c:62: if (id != first && id != second) return true;
	lcall	_ak820_outline_0181
	mov	r1,a
	mov	a,r2
	cjne	a,ar1,00315$
	sjmp	00110$
00315$:
	mov	dptr,#_second
	movx	a,@dptr
	mov	r1,a
	mov	a,r2
	cjne	a,ar1,00316$
	sjmp	00110$
00316$:
	mov	dpl, #0x01
	ret
00110$:
;	keyboards/ajazz/ak820/ak820_combo.c:63: if (!record->event.pressed) {
	mov	dptr,#_ak820_combo_process_record_10000_612
	lcall	_ak820_outline_0100
	mov	a,#0x05
	add	a, r0
	mov	r0,a
	clr	a
	addc	a, r1
	mov	r1,a
	lcall	_ak820_outline_0152
	movx	a,@dptr
	jnz	00121$
;	keyboards/ajazz/ak820/ak820_combo.c:64: if (saved.event.pressed) {
	mov	dptr,#(_saved + 0x0005)
	movx	a,@dptr
	jz	00113$
;	keyboards/ajazz/ak820/ak820_combo.c:65: saved.event.pressed = false;
	mov	dptr,#(_saved + 0x0005)
	clr	a
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_combo.c:66: process_record(&saved);
	mov	dptr,#_saved
	push	ar2
	lcall	_process_record
	pop	ar2
00113$:
;	keyboards/ajazz/ak820/ak820_combo.c:68: if (id == first) first = NONE;
	lcall	_ak820_outline_0181
	mov	r1,a
	mov	a,r2
	cjne	a,ar1,00115$
	mov	dptr,#_first
	mov	a,#0xff
	movx	@dptr,a
	sjmp	00116$
00115$:
;	keyboards/ajazz/ak820/ak820_combo.c:69: else second = NONE;
	mov	dptr,#_second
	mov	a,#0xff
	movx	@dptr,a
00116$:
;	keyboards/ajazz/ak820/ak820_combo.c:70: if (first == NONE && second == NONE) active = false;
	lcall	_ak820_outline_0181
	mov	r1,a
	cjne	r1,#0xff,00121$
	mov	dptr,#_second
	movx	a,@dptr
	mov	r1,a
	cjne	r1,#0xff,00121$
	mov	dptr,#_active
	clr	a
	movx	@dptr,a
00121$:
;	keyboards/ajazz/ak820/ak820_combo.c:72: return false;
	mov	dpl, #0x00
	ret
00123$:
;	keyboards/ajazz/ak820/ak820_combo.c:74: bool eligible = false;
	mov	dptr,#_ak820_combo_process_eligible_10001_627
	clr	a
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_combo.c:75: if (record->event.pressed && COMBO_INPUT(record->keycode)) {
	lcall	_ak820_outline_0005
	jnz	00325$
	ljmp	00134$
00325$:
	clr	c
	mov	a,r4
	subb	a,#0x04
	mov	a,r5
	subb	a,#0x00
	jnc	00326$
	ljmp	00134$
00326$:
	clr	c
	mov	a,#0xa4
	subb	a,r4
	clr	a
	subb	a,r5
	jnc	00327$
	ljmp	00134$
00327$:
;	free result
;	keyboards/ajazz/ak820/ak820_combo.c:76: uint8_t previous = saved.keycode;
	mov	dptr,#(_saved + 0x0007)
	movx	a,@dptr
	mov	r7,a
;	keyboards/ajazz/ak820/ak820_combo.c:77: for (uint8_t i = 0; i < VIAL_COMBO_ENTRIES; ++i) {
	mov	dptr,#_ak820_combo_process_i_40001_630
	clr	a
	movx	@dptr,a
	mov	a,r3
	cjne	a,ar7,00328$
	setb	c
	sjmp	00329$
00328$:
	clr	c
00329$:
	mov	_ak820_combo_process_sloc0_1_0,c
	mov	r6,#0x00
00142$:
	cjne	r6,#0x08,00330$
00330$:
	jc	00331$
	ljmp	00134$
00331$:
;	keyboards/ajazz/ak820/ak820_combo.c:78: uint8_t a = combos[i].a, b = combos[i].b;
	mov	a,r6
	lcall	_ak820_outline_0053
	movx	a,@dptr
	mov	r1,a
	mov	dptr,#_ak820_combo_process_a_50001_631
	movx	@dptr,a
	lcall	_ak820_outline_0117
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	mov	dptr,#_ak820_combo_process_b_50001_631
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_combo.c:79: if (a == code || b == code) {
	mov	a,r1
	cjne	a,ar3,00332$
	sjmp	00129$
00332$:
	mov	a,r5
	cjne	a,ar3,00143$
00129$:
;	keyboards/ajazz/ak820/ak820_combo.c:80: eligible = true;
	mov	dptr,#_ak820_combo_process_eligible_10001_627
	mov	a,#0x01
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_combo.c:81: if (first != NONE && code != previous && (a == previous || b == previous)) {
	lcall	_ak820_outline_0181
	mov	r5,a
	cjne	r5,#0xff,00335$
	sjmp	00143$
00335$:
	jb	_ak820_combo_process_sloc0_1_0,00143$
	mov	dptr,#_ak820_combo_process_a_50001_631
	movx	a,@dptr
	cjne	a,ar7,00337$
	sjmp	00124$
00337$:
	mov	dptr,#_ak820_combo_process_b_50001_631
	movx	a,@dptr
	cjne	a,ar7,00143$
00124$:
;	keyboards/ajazz/ak820/ak820_combo.c:82: second = id;
	mov	dptr,#_second
	mov	a,r2
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_combo.c:83: active = true;
	mov	dptr,#_active
	mov	a,#0x01
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_combo.c:84: saved.keycode = combos[i].output;
	mov	dptr,#_ak820_combo_process_i_40001_630
	movx	a,@dptr
	lcall	_ak820_outline_0053
	inc	dptr
	inc	dptr
	lcall	_ak820_outline_0060
	mov	dptr,#(_saved + 0x0007)
	lcall	_ak820_outline_0071
;	keyboards/ajazz/ak820/ak820_combo.c:85: process_record(&saved);
	mov	dptr,#_saved
	lcall	_process_record
;	keyboards/ajazz/ak820/ak820_combo.c:86: return false;
	mov	dpl, #0x00
	ret
00143$:
;	keyboards/ajazz/ak820/ak820_combo.c:77: for (uint8_t i = 0; i < VIAL_COMBO_ENTRIES; ++i) {
	inc	r6
	mov	dptr,#_ak820_combo_process_i_40001_630
	mov	a,r6
	movx	@dptr,a
	ljmp	00142$
00134$:
;	keyboards/ajazz/ak820/ak820_combo.c:91: if (first != NONE) flush();
	lcall	_ak820_outline_0181
	mov	r7,a
	cjne	r7,#0xff,00340$
	sjmp	00138$
00340$:
	push	ar2
	lcall	_flush
	pop	ar2
00138$:
;	keyboards/ajazz/ak820/ak820_combo.c:92: if (eligible) {
	mov	dptr,#_ak820_combo_process_eligible_10001_627
	movx	a,@dptr
	jz	00140$
;	keyboards/ajazz/ak820/ak820_combo.c:93: first = id;
	mov	dptr,#_first
	mov	a,r2
	movx	@dptr,a
;	keyboards/ajazz/ak820/ak820_combo.c:94: saved = *record;
	mov	dptr,#_ak820_combo_process_record_10000_612
	lcall	_ak820_outline_0058
	mov	dptr,#___memcpy_PARM_2
	mov	a,r5
	lcall	_ak820_outline_0016
	mov	dptr,#___memcpy_PARM_3
	mov	a,#0x09
	lcall	_ak820_outline_0123
	mov	dptr,#_saved
	mov	b,a
	lcall	___memcpy
;	keyboards/ajazz/ak820/ak820_combo.c:95: return false;
	mov	dpl, #0x00
	ret
00140$:
;	keyboards/ajazz/ak820/ak820_combo.c:97: return true;
	mov	dpl, #0x01
;	keyboards/ajazz/ak820/ak820_combo.c:98: }
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
__xinit__first:
	.db #0xff	; 255
__xinit__second:
	.db #0xff	; 255
	.area CABS    (ABS,CODE)

; Experimental exact instruction outlining.
	.globl _ak820_outline_0004
	.globl _ak820_outline_0005
	.globl _ak820_outline_0009
	.globl _ak820_outline_0010
	.globl _ak820_outline_0014
	.globl _ak820_outline_0016
	.globl _ak820_outline_0017
	.globl _ak820_outline_0031
	.globl _ak820_outline_0034
	.globl _ak820_outline_0051
	.globl _ak820_outline_0053
	.globl _ak820_outline_0058
	.globl _ak820_outline_0060
	.globl _ak820_outline_0071
	.globl _ak820_outline_0077
	.globl _ak820_outline_0097
	.globl _ak820_outline_0098
	.globl _ak820_outline_0100
	.globl _ak820_outline_0103
	.globl _ak820_outline_0104
	.globl _ak820_outline_0108
	.globl _ak820_outline_0117
	.globl _ak820_outline_0121
	.globl _ak820_outline_0122
	.globl _ak820_outline_0123
	.globl _ak820_outline_0132
	.globl _ak820_outline_0135
	.globl _ak820_outline_0152
	.globl _ak820_outline_0155
	.globl _ak820_outline_0165
	.globl _ak820_outline_0167
	.globl _ak820_outline_0181
	.globl _ak820_outline_0186

	.area CSEG (CODE)
; function ak820_outline_0004
_ak820_outline_0004:
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dpl,r6
	mov	dph,r7
	ret

	.area CSEG (CODE)
; function ak820_outline_0005
_ak820_outline_0005:
	mov	a,#0x05
	add	a,r6
	mov	r6,a
	clr	a
	addc	a,r7
	mov	r7,a
	mov	dpl,r6
	mov	dph,r7
	movx	a,@dptr
	ret

	.area CSEG (CODE)
; function ak820_outline_0009
_ak820_outline_0009:
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	a,#0x07
	add	a,r6
	mov	dpl,a
	clr	a
	addc	a,r7
	mov	dph,a
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0010
_ak820_outline_0010:
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	ar4,r6
	mov	ar5,r7
	ret

	.area CSEG (CODE)
; function ak820_outline_0014
_ak820_outline_0014:
	mov	r1,a
	clr	a
	addc	a,r7
	mov	r2,a
	mov	dpl,r1
	mov	dph,r2
	movx	a,@dptr
	ret

	.area CSEG (CODE)
; function ak820_outline_0016
_ak820_outline_0016:
	movx	@dptr,a
	mov	a,r6
	inc	dptr
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0017
_ak820_outline_0017:
	add	a,r6
	mov	dpl,a
	clr	a
	addc	a,r7
	mov	dph,a
	movx	a,@dptr
	ret

	.area CSEG (CODE)
; function ak820_outline_0031
_ak820_outline_0031:
	add	a,r6
	mov	dpl,a
	clr	a
	addc	a,r7
	mov	dph,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0034
_ak820_outline_0034:
	mov	dpl,r6
	mov	dph,r7
	inc	dptr
	inc	dptr
	movx	a,@dptr
	ret

	.area CSEG (CODE)
; function ak820_outline_0051
_ak820_outline_0051:
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0053
_ak820_outline_0053:
	mov	b,#0x04
	mul	ab
	add	a,#_combos
	mov	r4,a
	mov	a,#(_combos>>8)
	addc	a,b
	mov	r5,a
	mov	dpl,r4
	mov	dph,r5
	ret

	.area CSEG (CODE)
; function ak820_outline_0058
_ak820_outline_0058:
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	mov	r7,#0x00
	ret

	.area CSEG (CODE)
; function ak820_outline_0060
_ak820_outline_0060:
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0071
_ak820_outline_0071:
	mov	a,r4
	movx	@dptr,a
	mov	a,r5
	inc	dptr
	movx	@dptr,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0077
_ak820_outline_0077:
	mov	a,r3
	movx	@dptr,a
	mov	a,r4
	inc	dptr
	movx	@dptr,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0097
_ak820_outline_0097:
	inc	dptr
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0098
_ak820_outline_0098:
	mov	dpl,r6
	mov	dph,r7
	movx	a,@dptr
	ret

	.area CSEG (CODE)
; function ak820_outline_0100
_ak820_outline_0100:
	movx	a,@dptr
	mov	r0,a
	inc	dptr
	movx	a,@dptr
	mov	r1,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0103
_ak820_outline_0103:
	mov	r7,dph
	mov	a,dpl
	ret

	.area CSEG (CODE)
; function ak820_outline_0104
_ak820_outline_0104:
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0108
_ak820_outline_0108:
	mov	dpl,r6
	mov	dph,r7
	inc	dptr
	movx	a,@dptr
	ret

	.area CSEG (CODE)
; function ak820_outline_0117
_ak820_outline_0117:
	mov	dpl,r4
	mov	dph,r5
	ret

	.area CSEG (CODE)
; function ak820_outline_0121
_ak820_outline_0121:
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0123
_ak820_outline_0123:
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0132
_ak820_outline_0132:
	mov	dpl,r5
	mov	dph,r6
	ret

	.area CSEG (CODE)
; function ak820_outline_0135
_ak820_outline_0135:
	mov	a,dpl
	mov	b,dph
	ret

	.area CSEG (CODE)
; function ak820_outline_0152
_ak820_outline_0152:
	mov	dpl,r0
	mov	dph,r1
	ret

	.area CSEG (CODE)
; function ak820_outline_0155
_ak820_outline_0155:
	add	a,r5
	mov	r5,a
	clr	a
	addc	a,r6
	mov	r6,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0165
_ak820_outline_0165:
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	orl	a,r4
	ret

	.area CSEG (CODE)
; function ak820_outline_0167
_ak820_outline_0167:
	clr	a
	rlc	a
	mov	dpl,a
	ret

	.area CSEG (CODE)
; function ak820_outline_0181
_ak820_outline_0181:
	mov	dptr,#_first
	movx	a,@dptr
	ret

	.area CSEG (CODE)
; function ak820_outline_0186
_ak820_outline_0186:
	swap	a
	rr	a
	anl	a,#0xf8
	ret
