                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_tapping
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _get_repeat_key_count
                                     12 	.globl _del_owned_mods
                                     13 	.globl _add_owned_mods
                                     14 	.globl _send_keyboard_report
                                     15 	.globl _layer_hold_off
                                     16 	.globl _layer_hold_on
                                     17 	.globl _unregister_mods
                                     18 	.globl _register_mods
                                     19 	.globl _process_record
                                     20 	.globl _ADC_START
                                     21 	.globl _S0_R_FIFO
                                     22 	.globl _S0_T_FIFO
                                     23 	.globl _S0_FREE
                                     24 	.globl _S0_IF_BYTE
                                     25 	.globl _S0_IF_FIRST
                                     26 	.globl _S0_IF_OV
                                     27 	.globl _S0_FST_ACT
                                     28 	.globl _CP_RL2
                                     29 	.globl _C_T2
                                     30 	.globl _TR2
                                     31 	.globl _EXEN2
                                     32 	.globl _TCLK
                                     33 	.globl _RCLK
                                     34 	.globl _EXF2
                                     35 	.globl _CAP1F
                                     36 	.globl _TF2
                                     37 	.globl _RI
                                     38 	.globl _TI
                                     39 	.globl _RB8
                                     40 	.globl _TB8
                                     41 	.globl _REN
                                     42 	.globl _SM2
                                     43 	.globl _SM1
                                     44 	.globl _SM0
                                     45 	.globl _IT0
                                     46 	.globl _IE0
                                     47 	.globl _IT1
                                     48 	.globl _IE1
                                     49 	.globl _TR0
                                     50 	.globl _TF0
                                     51 	.globl _TR1
                                     52 	.globl _TF1
                                     53 	.globl _P4_0
                                     54 	.globl _P4_1
                                     55 	.globl _P4_2
                                     56 	.globl _P4_3
                                     57 	.globl _P4_4
                                     58 	.globl _P4_5
                                     59 	.globl _P4_6
                                     60 	.globl _RXD
                                     61 	.globl _TXD
                                     62 	.globl _INT0
                                     63 	.globl _INT1
                                     64 	.globl _T0
                                     65 	.globl _T1
                                     66 	.globl _MOSI1
                                     67 	.globl _MISO1
                                     68 	.globl _SCK1
                                     69 	.globl _P3_0
                                     70 	.globl _P3_1
                                     71 	.globl _P3_2
                                     72 	.globl _P3_3
                                     73 	.globl _P3_4
                                     74 	.globl _P3_5
                                     75 	.globl _P3_6
                                     76 	.globl _P3_7
                                     77 	.globl _CAP1_
                                     78 	.globl _T2_
                                     79 	.globl _CAP2_
                                     80 	.globl _T2EX_
                                     81 	.globl _RXD1
                                     82 	.globl _TXD1
                                     83 	.globl _P2_0
                                     84 	.globl _P2_1
                                     85 	.globl _P2_2
                                     86 	.globl _P2_3
                                     87 	.globl _P2_4
                                     88 	.globl _P2_5
                                     89 	.globl _P2_6
                                     90 	.globl _P2_7
                                     91 	.globl _AIN0
                                     92 	.globl _AIN1
                                     93 	.globl _AIN2
                                     94 	.globl _AIN3
                                     95 	.globl _AIN4
                                     96 	.globl _AIN5
                                     97 	.globl _AIN6
                                     98 	.globl _AIN7
                                     99 	.globl _CAP1
                                    100 	.globl _T2
                                    101 	.globl _CAP2
                                    102 	.globl _T2EX
                                    103 	.globl _INT0_
                                    104 	.globl _SCS
                                    105 	.globl _MOSI
                                    106 	.globl _MISO
                                    107 	.globl _SCK
                                    108 	.globl _RXD1_
                                    109 	.globl _TXD1_
                                    110 	.globl _P1_0
                                    111 	.globl _P1_1
                                    112 	.globl _P1_2
                                    113 	.globl _P1_3
                                    114 	.globl _P1_4
                                    115 	.globl _P1_5
                                    116 	.globl _P1_6
                                    117 	.globl _P1_7
                                    118 	.globl _AIN8
                                    119 	.globl _AIN9
                                    120 	.globl _AIN10
                                    121 	.globl _AIN11
                                    122 	.globl _AIN12
                                    123 	.globl _AIN13
                                    124 	.globl _RXD_
                                    125 	.globl _TXD_
                                    126 	.globl _SCL0
                                    127 	.globl _SDA0
                                    128 	.globl _P0_0
                                    129 	.globl _P0_1
                                    130 	.globl _P0_2
                                    131 	.globl _P0_3
                                    132 	.globl _P0_4
                                    133 	.globl _P0_5
                                    134 	.globl _P0_6
                                    135 	.globl _P0_7
                                    136 	.globl _IE_SPI0
                                    137 	.globl _IE_USB
                                    138 	.globl _IE_ADC
                                    139 	.globl _IE_UART1
                                    140 	.globl _IE_PWM_I2C
                                    141 	.globl _IE_GPIO
                                    142 	.globl _IE_WDOG
                                    143 	.globl _PX0
                                    144 	.globl _PT0
                                    145 	.globl _PX1
                                    146 	.globl _PT1
                                    147 	.globl _PS
                                    148 	.globl _PT2
                                    149 	.globl _PL_FLAG
                                    150 	.globl _PH_FLAG
                                    151 	.globl _EX0
                                    152 	.globl _ET0
                                    153 	.globl _EX1
                                    154 	.globl _ET1
                                    155 	.globl _ES
                                    156 	.globl _ET2
                                    157 	.globl _E_DIS
                                    158 	.globl _EA
                                    159 	.globl _P
                                    160 	.globl _F1
                                    161 	.globl _OV
                                    162 	.globl _RS0
                                    163 	.globl _RS1
                                    164 	.globl _F0
                                    165 	.globl _AC
                                    166 	.globl _CY
                                    167 	.globl _I2CS_INT_ST
                                    168 	.globl _I2CX_INT
                                    169 	.globl _LED_STATUS
                                    170 	.globl _LED_DMA_H
                                    171 	.globl _LED_DMA_L
                                    172 	.globl _LED_DMA
                                    173 	.globl _LED_PWM_OE
                                    174 	.globl _LED_COMMON
                                    175 	.globl _ADC_CHAN
                                    176 	.globl _ADC_DAT_H
                                    177 	.globl _ADC_DAT_L
                                    178 	.globl _ADC_DAT
                                    179 	.globl _ADC_CTRL
                                    180 	.globl _SPI1_CK_SE
                                    181 	.globl _SPI1_CTRL
                                    182 	.globl _SPI1_DATA
                                    183 	.globl _SPI1_STAT
                                    184 	.globl _SIF1
                                    185 	.globl _SBAUD1
                                    186 	.globl _SBUF1
                                    187 	.globl _SCON1
                                    188 	.globl _SPI0_SETUP
                                    189 	.globl _SPI0_CK_SE
                                    190 	.globl _SPI0_CTRL
                                    191 	.globl _SPI0_DATA
                                    192 	.globl _SPI0_STAT
                                    193 	.globl _T2CAP1H
                                    194 	.globl _T2CAP1L
                                    195 	.globl _T2CAP1
                                    196 	.globl _TH2
                                    197 	.globl _TL2
                                    198 	.globl _T2COUNT
                                    199 	.globl _RCAP2H
                                    200 	.globl _RCAP2L
                                    201 	.globl _RCAP2
                                    202 	.globl _T2MOD
                                    203 	.globl _T2CON
                                    204 	.globl _SBUF
                                    205 	.globl _SCON
                                    206 	.globl _TH1
                                    207 	.globl _TH0
                                    208 	.globl _TL1
                                    209 	.globl _TL0
                                    210 	.globl _TMOD
                                    211 	.globl _TCON
                                    212 	.globl _XBUS_AUX
                                    213 	.globl _P7
                                    214 	.globl _P6_DIR
                                    215 	.globl _P6_OUT_PU
                                    216 	.globl _P6_IN
                                    217 	.globl _P5_DIR
                                    218 	.globl _P5_OUT_PU
                                    219 	.globl _P5_IN
                                    220 	.globl _P4_LED_KEY
                                    221 	.globl _P4_DIR_PU
                                    222 	.globl _P4_MOD_OC
                                    223 	.globl _P4
                                    224 	.globl _P3_DIR_PU
                                    225 	.globl _P3_MOD_OC
                                    226 	.globl _P3
                                    227 	.globl _P2_DIR_PU
                                    228 	.globl _P2_MOD_OC
                                    229 	.globl _P2
                                    230 	.globl _P1_DIR_PU
                                    231 	.globl _P1_MOD_OC
                                    232 	.globl _P1
                                    233 	.globl _P0_DIR_PU
                                    234 	.globl _P0_MOD_OC
                                    235 	.globl _P0
                                    236 	.globl _ROM_CTRL
                                    237 	.globl _ROM_DATA_HH
                                    238 	.globl _ROM_DATA_HL
                                    239 	.globl _ROM_DATA_HI
                                    240 	.globl _ROM_ADDR_H
                                    241 	.globl _ROM_ADDR_L
                                    242 	.globl _ROM_ADDR
                                    243 	.globl _GPIO_IE
                                    244 	.globl _IP_EX
                                    245 	.globl _IE_EX
                                    246 	.globl _IP
                                    247 	.globl _IE
                                    248 	.globl _WDOG_COUNT
                                    249 	.globl _RESET_KEEP
                                    250 	.globl _WAKE_CTRL
                                    251 	.globl _CLOCK_CFG
                                    252 	.globl _POWER_CFG
                                    253 	.globl _PCON
                                    254 	.globl _GLOBAL_CFG
                                    255 	.globl _SAFE_MOD
                                    256 	.globl _DPH
                                    257 	.globl _DPL
                                    258 	.globl _SP
                                    259 	.globl _A_INV
                                    260 	.globl _B
                                    261 	.globl _ACC
                                    262 	.globl _PSW
                                    263 	.globl _ak820_oneshot_target
                                    264 	.globl _ak820_oneshot_process_PARM_3
                                    265 	.globl _ak820_oneshot_process_PARM_2
                                    266 	.globl _ak820_oneshot_consumed
                                    267 	.globl _ak820_oneshot_mods
                                    268 	.globl _ak820_tapping_source_PARM_1
                                    269 	.globl _ak820_tapping_source
                                    270 	.globl _ak820_tapping_before
                                    271 	.globl _ak820_tapping_process
                                    272 	.globl _ak820_tapping_cancel
                                    273 	.globl _ak820_oneshot_process
                                    274 ;--------------------------------------------------------
                                    275 ; special function registers
                                    276 ;--------------------------------------------------------
                                    277 	.area RSEG    (ABS,DATA)
      000000                        278 	.org 0x0000
                           0000D0   279 _PSW	=	0x00d0
                           0000E0   280 _ACC	=	0x00e0
                           0000F0   281 _B	=	0x00f0
                           0000FD   282 _A_INV	=	0x00fd
                           000081   283 _SP	=	0x0081
                           000082   284 _DPL	=	0x0082
                           000083   285 _DPH	=	0x0083
                           0000A1   286 _SAFE_MOD	=	0x00a1
                           0000B1   287 _GLOBAL_CFG	=	0x00b1
                           000087   288 _PCON	=	0x0087
                           0000BA   289 _POWER_CFG	=	0x00ba
                           0000B9   290 _CLOCK_CFG	=	0x00b9
                           0000A9   291 _WAKE_CTRL	=	0x00a9
                           0000FE   292 _RESET_KEEP	=	0x00fe
                           0000FF   293 _WDOG_COUNT	=	0x00ff
                           0000A8   294 _IE	=	0x00a8
                           0000B8   295 _IP	=	0x00b8
                           0000E8   296 _IE_EX	=	0x00e8
                           0000E9   297 _IP_EX	=	0x00e9
                           0000B2   298 _GPIO_IE	=	0x00b2
                           008584   299 _ROM_ADDR	=	0x8584
                           000084   300 _ROM_ADDR_L	=	0x0084
                           000085   301 _ROM_ADDR_H	=	0x0085
                           008F8E   302 _ROM_DATA_HI	=	0x8f8e
                           00008E   303 _ROM_DATA_HL	=	0x008e
                           00008F   304 _ROM_DATA_HH	=	0x008f
                           000086   305 _ROM_CTRL	=	0x0086
                           000080   306 _P0	=	0x0080
                           0000C4   307 _P0_MOD_OC	=	0x00c4
                           0000C5   308 _P0_DIR_PU	=	0x00c5
                           000090   309 _P1	=	0x0090
                           000092   310 _P1_MOD_OC	=	0x0092
                           000093   311 _P1_DIR_PU	=	0x0093
                           0000A0   312 _P2	=	0x00a0
                           000094   313 _P2_MOD_OC	=	0x0094
                           000095   314 _P2_DIR_PU	=	0x0095
                           0000B0   315 _P3	=	0x00b0
                           000096   316 _P3_MOD_OC	=	0x0096
                           000097   317 _P3_DIR_PU	=	0x0097
                           0000C0   318 _P4	=	0x00c0
                           0000C2   319 _P4_MOD_OC	=	0x00c2
                           0000C3   320 _P4_DIR_PU	=	0x00c3
                           0000C1   321 _P4_LED_KEY	=	0x00c1
                           0000AA   322 _P5_IN	=	0x00aa
                           0000AB   323 _P5_OUT_PU	=	0x00ab
                           0000AC   324 _P5_DIR	=	0x00ac
                           0000AD   325 _P6_IN	=	0x00ad
                           0000AE   326 _P6_OUT_PU	=	0x00ae
                           0000AF   327 _P6_DIR	=	0x00af
                           0000F1   328 _P7	=	0x00f1
                           0000A2   329 _XBUS_AUX	=	0x00a2
                           000088   330 _TCON	=	0x0088
                           000089   331 _TMOD	=	0x0089
                           00008A   332 _TL0	=	0x008a
                           00008B   333 _TL1	=	0x008b
                           00008C   334 _TH0	=	0x008c
                           00008D   335 _TH1	=	0x008d
                           000098   336 _SCON	=	0x0098
                           000099   337 _SBUF	=	0x0099
                           0000C8   338 _T2CON	=	0x00c8
                           0000C9   339 _T2MOD	=	0x00c9
                           00CBCA   340 _RCAP2	=	0xcbca
                           0000CA   341 _RCAP2L	=	0x00ca
                           0000CB   342 _RCAP2H	=	0x00cb
                           00CDCC   343 _T2COUNT	=	0xcdcc
                           0000CC   344 _TL2	=	0x00cc
                           0000CD   345 _TH2	=	0x00cd
                           00CFCE   346 _T2CAP1	=	0xcfce
                           0000CE   347 _T2CAP1L	=	0x00ce
                           0000CF   348 _T2CAP1H	=	0x00cf
                           0000F8   349 _SPI0_STAT	=	0x00f8
                           0000F9   350 _SPI0_DATA	=	0x00f9
                           0000FA   351 _SPI0_CTRL	=	0x00fa
                           0000FB   352 _SPI0_CK_SE	=	0x00fb
                           0000FC   353 _SPI0_SETUP	=	0x00fc
                           0000BC   354 _SCON1	=	0x00bc
                           0000BD   355 _SBUF1	=	0x00bd
                           0000BE   356 _SBAUD1	=	0x00be
                           0000BF   357 _SIF1	=	0x00bf
                           0000B4   358 _SPI1_STAT	=	0x00b4
                           0000B5   359 _SPI1_DATA	=	0x00b5
                           0000B6   360 _SPI1_CTRL	=	0x00b6
                           0000B7   361 _SPI1_CK_SE	=	0x00b7
                           0000F3   362 _ADC_CTRL	=	0x00f3
                           00F5F4   363 _ADC_DAT	=	0xf5f4
                           0000F4   364 _ADC_DAT_L	=	0x00f4
                           0000F5   365 _ADC_DAT_H	=	0x00f5
                           0000F6   366 _ADC_CHAN	=	0x00f6
                           0000A6   367 _LED_COMMON	=	0x00a6
                           0000A7   368 _LED_PWM_OE	=	0x00a7
                           00C7C6   369 _LED_DMA	=	0xc7c6
                           0000C6   370 _LED_DMA_L	=	0x00c6
                           0000C7   371 _LED_DMA_H	=	0x00c7
                           0000F7   372 _LED_STATUS	=	0x00f7
                           0000B3   373 _I2CX_INT	=	0x00b3
                           0000BB   374 _I2CS_INT_ST	=	0x00bb
                                    375 ;--------------------------------------------------------
                                    376 ; special function bits
                                    377 ;--------------------------------------------------------
                                    378 	.area RSEG    (ABS,DATA)
      000000                        379 	.org 0x0000
                           0000D7   380 _CY	=	0x00d7
                           0000D6   381 _AC	=	0x00d6
                           0000D5   382 _F0	=	0x00d5
                           0000D4   383 _RS1	=	0x00d4
                           0000D3   384 _RS0	=	0x00d3
                           0000D2   385 _OV	=	0x00d2
                           0000D1   386 _F1	=	0x00d1
                           0000D0   387 _P	=	0x00d0
                           0000AF   388 _EA	=	0x00af
                           0000AE   389 _E_DIS	=	0x00ae
                           0000AD   390 _ET2	=	0x00ad
                           0000AC   391 _ES	=	0x00ac
                           0000AB   392 _ET1	=	0x00ab
                           0000AA   393 _EX1	=	0x00aa
                           0000A9   394 _ET0	=	0x00a9
                           0000A8   395 _EX0	=	0x00a8
                           0000BF   396 _PH_FLAG	=	0x00bf
                           0000BE   397 _PL_FLAG	=	0x00be
                           0000BD   398 _PT2	=	0x00bd
                           0000BC   399 _PS	=	0x00bc
                           0000BB   400 _PT1	=	0x00bb
                           0000BA   401 _PX1	=	0x00ba
                           0000B9   402 _PT0	=	0x00b9
                           0000B8   403 _PX0	=	0x00b8
                           0000EF   404 _IE_WDOG	=	0x00ef
                           0000EE   405 _IE_GPIO	=	0x00ee
                           0000ED   406 _IE_PWM_I2C	=	0x00ed
                           0000EC   407 _IE_UART1	=	0x00ec
                           0000EB   408 _IE_ADC	=	0x00eb
                           0000E9   409 _IE_USB	=	0x00e9
                           0000E8   410 _IE_SPI0	=	0x00e8
                           000087   411 _P0_7	=	0x0087
                           000086   412 _P0_6	=	0x0086
                           000085   413 _P0_5	=	0x0085
                           000084   414 _P0_4	=	0x0084
                           000083   415 _P0_3	=	0x0083
                           000082   416 _P0_2	=	0x0082
                           000081   417 _P0_1	=	0x0081
                           000080   418 _P0_0	=	0x0080
                           000081   419 _SDA0	=	0x0081
                           000080   420 _SCL0	=	0x0080
                           000083   421 _TXD_	=	0x0083
                           000082   422 _RXD_	=	0x0082
                           000085   423 _AIN13	=	0x0085
                           000084   424 _AIN12	=	0x0084
                           000083   425 _AIN11	=	0x0083
                           000082   426 _AIN10	=	0x0082
                           000081   427 _AIN9	=	0x0081
                           000080   428 _AIN8	=	0x0080
                           000097   429 _P1_7	=	0x0097
                           000096   430 _P1_6	=	0x0096
                           000095   431 _P1_5	=	0x0095
                           000094   432 _P1_4	=	0x0094
                           000093   433 _P1_3	=	0x0093
                           000092   434 _P1_2	=	0x0092
                           000091   435 _P1_1	=	0x0091
                           000090   436 _P1_0	=	0x0090
                           000097   437 _TXD1_	=	0x0097
                           000096   438 _RXD1_	=	0x0096
                           000097   439 _SCK	=	0x0097
                           000096   440 _MISO	=	0x0096
                           000095   441 _MOSI	=	0x0095
                           000094   442 _SCS	=	0x0094
                           000092   443 _INT0_	=	0x0092
                           000091   444 _T2EX	=	0x0091
                           000091   445 _CAP2	=	0x0091
                           000090   446 _T2	=	0x0090
                           000090   447 _CAP1	=	0x0090
                           000097   448 _AIN7	=	0x0097
                           000096   449 _AIN6	=	0x0096
                           000095   450 _AIN5	=	0x0095
                           000094   451 _AIN4	=	0x0094
                           000093   452 _AIN3	=	0x0093
                           000092   453 _AIN2	=	0x0092
                           000091   454 _AIN1	=	0x0091
                           000090   455 _AIN0	=	0x0090
                           0000A7   456 _P2_7	=	0x00a7
                           0000A6   457 _P2_6	=	0x00a6
                           0000A5   458 _P2_5	=	0x00a5
                           0000A4   459 _P2_4	=	0x00a4
                           0000A3   460 _P2_3	=	0x00a3
                           0000A2   461 _P2_2	=	0x00a2
                           0000A1   462 _P2_1	=	0x00a1
                           0000A0   463 _P2_0	=	0x00a0
                           0000A7   464 _TXD1	=	0x00a7
                           0000A6   465 _RXD1	=	0x00a6
                           0000A5   466 _T2EX_	=	0x00a5
                           0000A5   467 _CAP2_	=	0x00a5
                           0000A4   468 _T2_	=	0x00a4
                           0000A4   469 _CAP1_	=	0x00a4
                           0000B7   470 _P3_7	=	0x00b7
                           0000B6   471 _P3_6	=	0x00b6
                           0000B5   472 _P3_5	=	0x00b5
                           0000B4   473 _P3_4	=	0x00b4
                           0000B3   474 _P3_3	=	0x00b3
                           0000B2   475 _P3_2	=	0x00b2
                           0000B1   476 _P3_1	=	0x00b1
                           0000B0   477 _P3_0	=	0x00b0
                           0000B7   478 _SCK1	=	0x00b7
                           0000B6   479 _MISO1	=	0x00b6
                           0000B5   480 _MOSI1	=	0x00b5
                           0000B5   481 _T1	=	0x00b5
                           0000B4   482 _T0	=	0x00b4
                           0000B3   483 _INT1	=	0x00b3
                           0000B2   484 _INT0	=	0x00b2
                           0000B1   485 _TXD	=	0x00b1
                           0000B0   486 _RXD	=	0x00b0
                           0000C6   487 _P4_6	=	0x00c6
                           0000C5   488 _P4_5	=	0x00c5
                           0000C4   489 _P4_4	=	0x00c4
                           0000C3   490 _P4_3	=	0x00c3
                           0000C2   491 _P4_2	=	0x00c2
                           0000C1   492 _P4_1	=	0x00c1
                           0000C0   493 _P4_0	=	0x00c0
                           00008F   494 _TF1	=	0x008f
                           00008E   495 _TR1	=	0x008e
                           00008D   496 _TF0	=	0x008d
                           00008C   497 _TR0	=	0x008c
                           00008B   498 _IE1	=	0x008b
                           00008A   499 _IT1	=	0x008a
                           000089   500 _IE0	=	0x0089
                           000088   501 _IT0	=	0x0088
                           00009F   502 _SM0	=	0x009f
                           00009E   503 _SM1	=	0x009e
                           00009D   504 _SM2	=	0x009d
                           00009C   505 _REN	=	0x009c
                           00009B   506 _TB8	=	0x009b
                           00009A   507 _RB8	=	0x009a
                           000099   508 _TI	=	0x0099
                           000098   509 _RI	=	0x0098
                           0000CF   510 _TF2	=	0x00cf
                           0000CF   511 _CAP1F	=	0x00cf
                           0000CE   512 _EXF2	=	0x00ce
                           0000CD   513 _RCLK	=	0x00cd
                           0000CC   514 _TCLK	=	0x00cc
                           0000CB   515 _EXEN2	=	0x00cb
                           0000CA   516 _TR2	=	0x00ca
                           0000C9   517 _C_T2	=	0x00c9
                           0000C8   518 _CP_RL2	=	0x00c8
                           0000FF   519 _S0_FST_ACT	=	0x00ff
                           0000FE   520 _S0_IF_OV	=	0x00fe
                           0000FD   521 _S0_IF_FIRST	=	0x00fd
                           0000FC   522 _S0_IF_BYTE	=	0x00fc
                           0000FB   523 _S0_FREE	=	0x00fb
                           0000FA   524 _S0_T_FIFO	=	0x00fa
                           0000F8   525 _S0_R_FIFO	=	0x00f8
                           0000F7   526 _ADC_START	=	0x00f7
                                    527 ;--------------------------------------------------------
                                    528 ; overlayable register banks
                                    529 ;--------------------------------------------------------
                                    530 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        531 	.ds 8
                                    532 ;--------------------------------------------------------
                                    533 ; internal ram data
                                    534 ;--------------------------------------------------------
                                    535 	.area DSEG    (DATA)
                                    536 ;--------------------------------------------------------
                                    537 ; overlayable items in internal ram
                                    538 ;--------------------------------------------------------
                                    539 ;--------------------------------------------------------
                                    540 ; indirectly addressable internal ram data
                                    541 ;--------------------------------------------------------
                                    542 	.area ISEG    (DATA)
                                    543 ;--------------------------------------------------------
                                    544 ; absolute internal ram data
                                    545 ;--------------------------------------------------------
                                    546 	.area IABS    (ABS,DATA)
                                    547 	.area IABS    (ABS,DATA)
                                    548 ;--------------------------------------------------------
                                    549 ; bit data
                                    550 ;--------------------------------------------------------
                                    551 	.area BSEG    (BIT)
      00000D                        552 _ak820_tapping_before_sloc0_1_0:
      00000D                        553 	.ds 1
                                    554 ;--------------------------------------------------------
                                    555 ; paged external ram data
                                    556 ;--------------------------------------------------------
                                    557 	.area PSEG    (PAG,XDATA)
                                    558 ;--------------------------------------------------------
                                    559 ; uninitialized external ram data
                                    560 ;--------------------------------------------------------
                                    561 	.area XSEG    (XDATA)
      0005B2                        562 _source_state:
      0005B2                        563 	.ds 130
      000634                        564 _pending_time:
      000634                        565 	.ds 2
      000636                        566 _pending_code:
      000636                        567 	.ds 2
      000638                        568 _ak820_tapping_source_PARM_1:
      000638                        569 	.ds 2
      00063A                        570 _hold_PARM_2:
      00063A                        571 	.ds 1
      00063B                        572 _hold_code_10000_601:
      00063B                        573 	.ds 2
      00063D                        574 _hold_mods_30000_604:
      00063D                        575 	.ds 1
      00063E                        576 _commit_pending_id_10000_610:
      00063E                        577 	.ds 1
      00063F                        578 _ak820_tapping_before_event_10000_611:
      00063F                        579 	.ds 2
      000641                        580 _ak820_tapping_process_record_10000_622:
      000641                        581 	.ds 2
      000643                        582 _ak820_tapping_process_code_10000_623:
      000643                        583 	.ds 2
      000645                        584 _ak820_tapping_process_sc_mods_10000_623:
      000645                        585 	.ds 1
      000646                        586 _ak820_oneshot_mods::
      000646                        587 	.ds 1
      000647                        588 _ak820_oneshot_consumed::
      000647                        589 	.ds 1
      000648                        590 _ak820_oneshot_process_PARM_2:
      000648                        591 	.ds 1
      000649                        592 _ak820_oneshot_process_PARM_3:
      000649                        593 	.ds 1
      00064A                        594 _ak820_oneshot_process_code_10000_648:
      00064A                        595 	.ds 2
      00064C                        596 _ak820_oneshot_process_mods_10000_649:
      00064C                        597 	.ds 1
                                    598 ;--------------------------------------------------------
                                    599 ; absolute external ram data
                                    600 ;--------------------------------------------------------
                                    601 	.area XABS    (ABS,XDATA)
                                    602 ;--------------------------------------------------------
                                    603 ; initialized external ram data
                                    604 ;--------------------------------------------------------
                                    605 	.area XISEG   (XDATA)
      000D9A                        606 _pending:
      000D9A                        607 	.ds 1
      000D9B                        608 _ak820_oneshot_target::
      000D9B                        609 	.ds 1
                                    610 	.area HOME    (CODE)
                                    611 	.area GSINIT0 (CODE)
                                    612 	.area GSINIT1 (CODE)
                                    613 	.area GSINIT2 (CODE)
                                    614 	.area GSINIT3 (CODE)
                                    615 	.area GSINIT4 (CODE)
                                    616 	.area GSINIT5 (CODE)
                                    617 	.area GSINIT  (CODE)
                                    618 	.area GSFINAL (CODE)
                                    619 	.area CSEG    (CODE)
                                    620 ;--------------------------------------------------------
                                    621 ; global & static initialisations
                                    622 ;--------------------------------------------------------
                                    623 	.area HOME    (CODE)
                                    624 	.area GSINIT  (CODE)
                                    625 	.area GSFINAL (CODE)
                                    626 	.area GSINIT  (CODE)
                                    627 ;--------------------------------------------------------
                                    628 ; Home
                                    629 ;--------------------------------------------------------
                                    630 	.area HOME    (CODE)
                                    631 	.area HOME    (CODE)
                                    632 ;--------------------------------------------------------
                                    633 ; code
                                    634 ;--------------------------------------------------------
                                    635 	.area CSEG    (CODE)
                                    636 ;------------------------------------------------------------
                                    637 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    638 ;------------------------------------------------------------
                                    639 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    640 ;------------------------------------------------------------
                                    641 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    642 ;	-----------------------------------------
                           000007   643 	ar7 = 0x07
                           000006   644 	ar6 = 0x06
                           000005   645 	ar5 = 0x05
                           000004   646 	ar4 = 0x04
                           000003   647 	ar3 = 0x03
                           000002   648 	ar2 = 0x02
                           000001   649 	ar1 = 0x01
                           000000   650 	ar0 = 0x00
                                    651 ;	 function ak820_tapping_source
                                    652 ;	-----------------------------------------
      0046CF                        653 _ak820_tapping_source:
                                    654 ;	keyboards/ajazz/ak820/ak820_tapping.c:40: if (key.row < MATRIX_ROWS && key.col < MATRIX_COLS) return key.row * MATRIX_COLS + key.col;
      0046CF 90 06 39         [24]  655 	mov	dptr,#(_ak820_tapping_source_PARM_1 + 0x0001)
      0046D2 E0               [24]  656 	movx	a,@dptr
      0046D3 FF               [12]  657 	mov	r7,a
      0046D4 BF 10 00         [24]  658 	cjne	r7,#0x10,00147$
      0046D7                        659 00147$:
      0046D7 50 14            [24]  660 	jnc	00102$
      0046D9 90 06 38         [24]  661 	mov	dptr,#_ak820_tapping_source_PARM_1
      0046DC E0               [24]  662 	movx	a,@dptr
      0046DD FE               [12]  663 	mov	r6,a
      0046DE BE 08 00         [24]  664 	cjne	r6,#0x08,00149$
      0046E1                        665 00149$:
      0046E1 50 0A            [24]  666 	jnc	00102$
      0046E3 8F 05            [24]  667 	mov	ar5,r7
      0046E5 ED               [12]  668 	mov	a,r5
      0046E6 12 3A CB         [24]  669 	lcall	_ak820_outline_0186
      0046E9 2E               [12]  670 	add	a,r6
      0046EA F5 82            [12]  671 	mov	dpl,a
      0046EC 22               [24]  672 	ret
      0046ED                        673 00102$:
                                    674 ;	keyboards/ajazz/ak820/ak820_tapping.c:41: if (key.col < NUM_ENCODERS) {
      0046ED 90 06 38         [24]  675 	mov	dptr,#_ak820_tapping_source_PARM_1
      0046F0 E0               [24]  676 	movx	a,@dptr
      0046F1 FE               [12]  677 	mov	r6,a
      0046F2 BE 01 00         [24]  678 	cjne	r6,#0x01,00151$
      0046F5                        679 00151$:
      0046F5 50 0E            [24]  680 	jnc	00109$
                                    681 ;	keyboards/ajazz/ak820/ak820_tapping.c:42: if (key.row == KEYLOC_ENCODER_CW) return MATRIX_ROWS * MATRIX_COLS + key.col;
      0046F7 BF FD 04         [24]  682 	cjne	r7,#0xfd,00105$
      0046FA 75 82 80         [24]  683 	mov	dpl, #0x80
      0046FD 22               [24]  684 	ret
      0046FE                        685 00105$:
                                    686 ;	keyboards/ajazz/ak820/ak820_tapping.c:43: if (key.row == KEYLOC_ENCODER_CCW) return MATRIX_ROWS * MATRIX_COLS + NUM_ENCODERS + key.col;
      0046FE BF FC 04         [24]  687 	cjne	r7,#0xfc,00109$
      004701 75 82 81         [24]  688 	mov	dpl, #0x81
      004704 22               [24]  689 	ret
      004705                        690 00109$:
                                    691 ;	keyboards/ajazz/ak820/ak820_tapping.c:45: return NONE;
      004705 75 82 FF         [24]  692 	mov	dpl, #0xff
                                    693 ;	keyboards/ajazz/ak820/ak820_tapping.c:46: }
      004708 22               [24]  694 	ret
                                    695 ;------------------------------------------------------------
                                    696 ;Allocation info for local variables in function 'hold'
                                    697 ;------------------------------------------------------------
                                    698 ;pressed       Allocated with name '_hold_PARM_2'
                                    699 ;code          Allocated with name '_hold_code_10000_601'
                                    700 ;mods          Allocated with name '_hold_mods_30000_604'
                                    701 ;layer         Allocated with name '_hold_layer_30000_607'
                                    702 ;------------------------------------------------------------
                                    703 ;	keyboards/ajazz/ak820/ak820_tapping.c:47: static void hold(uint16_t code, bool pressed) {
                                    704 ;	-----------------------------------------
                                    705 ;	 function hold
                                    706 ;	-----------------------------------------
      004709                        707 _hold:
      004709 12 3A 84         [24]  708 	lcall	_ak820_outline_0103
      00470C 90 06 3B         [24]  709 	mov	dptr,#_hold_code_10000_601
      00470F 12 3A 89         [24]  710 	lcall	_ak820_outline_0104
                                    711 ;	keyboards/ajazz/ak820/ak820_tapping.c:48: if (code < QK_LAYER_TAP) {
      004712 90 06 3B         [24]  712 	mov	dptr,#_hold_code_10000_601
      004715 12 3A 0C         [24]  713 	lcall	_ak820_outline_0010
      004718 74 C0            [12]  714 	mov	a,#0x100 - 0x40
      00471A 2D               [12]  715 	add	a,r5
      00471B 40 2E            [24]  716 	jc	00110$
                                    717 ;	keyboards/ajazz/ak820/ak820_tapping.c:49: uint8_t mods = (code >> 8) & 31;
      00471D 8F 05            [24]  718 	mov	ar5,r7
      00471F 53 05 1F         [24]  719 	anl	ar5,#0x1f
      004722 90 06 3D         [24]  720 	mov	dptr,#_hold_mods_30000_604
      004725 ED               [12]  721 	mov	a,r5
      004726 F0               [24]  722 	movx	@dptr,a
                                    723 ;	keyboards/ajazz/ak820/ak820_tapping.c:50: if (mods & 16) mods <<= 4;
      004727 ED               [12]  724 	mov	a,r5
      004728 30 E4 08         [24]  725 	jnb	acc.4,00102$
      00472B ED               [12]  726 	mov	a,r5
      00472C C4               [12]  727 	swap	a
      00472D 54 F0            [12]  728 	anl	a,#0xf0
      00472F 90 06 3D         [24]  729 	mov	dptr,#_hold_mods_30000_604
      004732 F0               [24]  730 	movx	@dptr,a
      004733                        731 00102$:
                                    732 ;	keyboards/ajazz/ak820/ak820_tapping.c:51: if (pressed) register_mods(mods);
      004733 90 06 3A         [24]  733 	mov	dptr,#_hold_PARM_2
      004736 E0               [24]  734 	movx	a,@dptr
      004737 60 09            [24]  735 	jz	00104$
      004739 90 06 3D         [24]  736 	mov	dptr,#_hold_mods_30000_604
      00473C E0               [24]  737 	movx	a,@dptr
      00473D F5 82            [12]  738 	mov	dpl,a
      00473F 02 79 9A         [24]  739 	ljmp	_register_mods
      004742                        740 00104$:
                                    741 ;	keyboards/ajazz/ak820/ak820_tapping.c:52: else unregister_mods(mods);
      004742 90 06 3D         [24]  742 	mov	dptr,#_hold_mods_30000_604
      004745 E0               [24]  743 	movx	a,@dptr
      004746 F5 82            [12]  744 	mov	dpl,a
      004748 02 79 AE         [24]  745 	ljmp	_unregister_mods
      00474B                        746 00110$:
                                    747 ;	keyboards/ajazz/ak820/ak820_tapping.c:54: uint8_t layer = (code >> 8) & 15;
      00474B 8F 06            [24]  748 	mov	ar6,r7
      00474D 74 0F            [12]  749 	mov	a,#0x0f
      00474F 5E               [12]  750 	anl	a,r6
      004750 FF               [12]  751 	mov	r7,a
                                    752 ;	keyboards/ajazz/ak820/ak820_tapping.c:55: if (pressed) layer_hold_on(layer);
      004751 90 06 3A         [24]  753 	mov	dptr,#_hold_PARM_2
      004754 E0               [24]  754 	movx	a,@dptr
      004755 60 05            [24]  755 	jz	00107$
      004757 8F 82            [24]  756 	mov	dpl, r7
      004759 02 7B 56         [24]  757 	ljmp	_layer_hold_on
      00475C                        758 00107$:
                                    759 ;	keyboards/ajazz/ak820/ak820_tapping.c:56: else layer_hold_off(layer);
      00475C 8F 82            [24]  760 	mov	dpl, r7
                                    761 ;	keyboards/ajazz/ak820/ak820_tapping.c:58: }
      00475E 02 7B 8C         [24]  762 	ljmp	_layer_hold_off
                                    763 ;------------------------------------------------------------
                                    764 ;Allocation info for local variables in function 'commit_pending'
                                    765 ;------------------------------------------------------------
                                    766 ;id            Allocated with name '_commit_pending_id_10000_610'
                                    767 ;------------------------------------------------------------
                                    768 ;	keyboards/ajazz/ak820/ak820_tapping.c:59: static void commit_pending(void) {
                                    769 ;	-----------------------------------------
                                    770 ;	 function commit_pending
                                    771 ;	-----------------------------------------
      004761                        772 _commit_pending:
                                    773 ;	keyboards/ajazz/ak820/ak820_tapping.c:60: uint8_t id = pending;
      004761 90 0D 9A         [24]  774 	mov	dptr,#_pending
      004764 E0               [24]  775 	movx	a,@dptr
      004765 90 06 3E         [24]  776 	mov	dptr,#_commit_pending_id_10000_610
      004768 F0               [24]  777 	movx	@dptr,a
                                    778 ;	keyboards/ajazz/ak820/ak820_tapping.c:61: pending = NONE; /* A report callback cannot resurrect the decision. */
      004769 12 4B C4         [24]  779 	lcall	_ak820_outline_0150
                                    780 ;	keyboards/ajazz/ak820/ak820_tapping.c:62: source_state[id] |= SOURCE_HELD;
      00476C 90 06 3E         [24]  781 	mov	dptr,#_commit_pending_id_10000_610
      00476F E0               [24]  782 	movx	a,@dptr
      004770 24 B2            [12]  783 	add	a,#_source_state
      004772 FF               [12]  784 	mov	r7,a
      004773 E4               [12]  785 	clr	a
      004774 34 05            [12]  786 	addc	a, #(_source_state >> 8)
      004776 FE               [12]  787 	mov	r6,a
      004777 12 45 EF         [24]  788 	lcall	_ak820_outline_0153
      00477A E0               [24]  789 	movx	a,@dptr
      00477B FD               [12]  790 	mov	r5,a
      00477C 43 05 04         [24]  791 	orl	ar5,#0x04
      00477F 12 45 EF         [24]  792 	lcall	_ak820_outline_0153
      004782 ED               [12]  793 	mov	a,r5
      004783 F0               [24]  794 	movx	@dptr,a
                                    795 ;	keyboards/ajazz/ak820/ak820_tapping.c:63: hold(pending_code, true);
      004784 90 06 36         [24]  796 	mov	dptr,#_pending_code
      004787 12 3A 41         [24]  797 	lcall	_ak820_outline_0051
      00478A 90 06 3A         [24]  798 	mov	dptr,#_hold_PARM_2
      00478D 12 4B 99         [24]  799 	lcall	_ak820_outline_0055
                                    800 ;	keyboards/ajazz/ak820/ak820_tapping.c:64: }
      004790 E1 09            [12]  801 	ajmp	_hold
                                    802 ;------------------------------------------------------------
                                    803 ;Allocation info for local variables in function 'ak820_tapping_before'
                                    804 ;------------------------------------------------------------
                                    805 ;event         Allocated with name '_ak820_tapping_before_event_10000_611'
                                    806 ;id            Allocated with name '_ak820_tapping_before_id_10000_612'
                                    807 ;------------------------------------------------------------
                                    808 ;	keyboards/ajazz/ak820/ak820_tapping.c:65: bool ak820_tapping_before(const keyevent_t AK820_STATE_MEM *event) {
                                    809 ;	-----------------------------------------
                                    810 ;	 function ak820_tapping_before
                                    811 ;	-----------------------------------------
      004792                        812 _ak820_tapping_before:
      004792 12 3A 84         [24]  813 	lcall	_ak820_outline_0103
      004795 90 06 3F         [24]  814 	mov	dptr,#_ak820_tapping_before_event_10000_611
      004798 12 3A 89         [24]  815 	lcall	_ak820_outline_0104
                                    816 ;	keyboards/ajazz/ak820/ak820_tapping.c:66: uint8_t id = ak820_tapping_source(event->key);
      00479B 90 06 3F         [24]  817 	mov	dptr,#_ak820_tapping_before_event_10000_611
      00479E 12 3A 0C         [24]  818 	lcall	_ak820_outline_0010
      0047A1 12 4B 74         [24]  819 	lcall	_ak820_outline_0023
      0047A4 C0 07            [24]  820 	push	ar7
      0047A6 C0 06            [24]  821 	push	ar6
      0047A8 12 B9 5D         [24]  822 	lcall	___memcpy
      0047AB D1 CF            [12]  823 	acall	_ak820_tapping_source
      0047AD AD 82            [24]  824 	mov	r5, dpl
      0047AF D0 06            [24]  825 	pop	ar6
      0047B1 D0 07            [24]  826 	pop	ar7
                                    827 ;	keyboards/ajazz/ak820/ak820_tapping.c:68: if (vial_unlock_in_progress) {
      0047B3 90 0E 0B         [24]  828 	mov	dptr,#_vial_unlock_in_progress
      0047B6 E0               [24]  829 	movx	a,@dptr
      0047B7 60 29            [24]  830 	jz	00106$
                                    831 ;	keyboards/ajazz/ak820/ak820_tapping.c:69: if (IS_EVENT(*event) && id != NONE && !event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      0047B9 74 04            [12]  832 	mov	a,#0x04
      0047BB 12 4B 5A         [24]  833 	lcall	_ak820_outline_0013
      0047BE 60 1E            [24]  834 	jz	00102$
      0047C0 BD FF 02         [24]  835 	cjne	r5,#0xff,00218$
      0047C3 80 19            [24]  836 	sjmp	00102$
      0047C5                        837 00218$:
      0047C5 74 05            [12]  838 	mov	a,#0x05
      0047C7 12 4B 5A         [24]  839 	lcall	_ak820_outline_0013
      0047CA 70 12            [24]  840 	jnz	00102$
      0047CC ED               [12]  841 	mov	a,r5
      0047CD 24 B2            [12]  842 	add	a, #_source_state
      0047CF FB               [12]  843 	mov	r3,a
      0047D0 E4               [12]  844 	clr	a
      0047D1 34 05            [12]  845 	addc	a, #(_source_state >> 8)
      0047D3 12 4B A1         [24]  846 	lcall	_ak820_outline_0056
      0047D6 53 02 FD         [24]  847 	anl	ar2,#0xfd
      0047D9 12 36 42         [24]  848 	lcall	_ak820_outline_0122
      0047DC EA               [12]  849 	mov	a,r2
      0047DD F0               [24]  850 	movx	@dptr,a
      0047DE                        851 00102$:
                                    852 ;	keyboards/ajazz/ak820/ak820_tapping.c:70: return false;
      0047DE 75 82 00         [24]  853 	mov	dpl, #0x00
      0047E1 22               [24]  854 	ret
      0047E2                        855 00106$:
                                    856 ;	keyboards/ajazz/ak820/ak820_tapping.c:73: if (pending != NONE && ((uint16_t)(event->time - pending_time) >= AK820_TAPPING_TERM ||
      0047E2 90 0D 9A         [24]  857 	mov	dptr,#_pending
      0047E5 E0               [24]  858 	movx	a,@dptr
      0047E6 FC               [12]  859 	mov	r4,a
      0047E7 BC FF 02         [24]  860 	cjne	r4,#0xff,00220$
      0047EA 80 3B            [24]  861 	sjmp	00108$
      0047EC                        862 00220$:
      0047EC 12 3A 39         [24]  863 	lcall	_ak820_outline_0034
      0047EF FA               [12]  864 	mov	r2,a
      0047F0 A3               [24]  865 	inc	dptr
      0047F1 E0               [24]  866 	movx	a,@dptr
      0047F2 FB               [12]  867 	mov	r3,a
      0047F3 90 06 34         [24]  868 	mov	dptr,#_pending_time
      0047F6 12 3A 7E         [24]  869 	lcall	_ak820_outline_0100
      0047F9 EA               [12]  870 	mov	a,r2
      0047FA C3               [12]  871 	clr	c
      0047FB 98               [12]  872 	subb	a,r0
      0047FC FA               [12]  873 	mov	r2,a
      0047FD EB               [12]  874 	mov	a,r3
      0047FE 99               [12]  875 	subb	a,r1
      0047FF FB               [12]  876 	mov	r3,a
      004800 C3               [12]  877 	clr	c
      004801 EA               [12]  878 	mov	a,r2
      004802 94 C8            [12]  879 	subb	a,#0xc8
      004804 EB               [12]  880 	mov	a,r3
      004805 94 00            [12]  881 	subb	a,#0x00
      004807 50 17            [24]  882 	jnc	00107$
                                    883 ;	keyboards/ajazz/ak820/ak820_tapping.c:74: (IS_EVENT(*event) && event->pressed && (id == NONE || id != pending)))) commit_pending();
      004809 74 04            [12]  884 	mov	a,#0x04
      00480B 12 4B 8E         [24]  885 	lcall	_ak820_outline_0046
      00480E 60 17            [24]  886 	jz	00108$
      004810 12 39 EB         [24]  887 	lcall	_ak820_outline_0005
      004813 60 12            [24]  888 	jz	00108$
      004815 BD FF 02         [24]  889 	cjne	r5,#0xff,00224$
      004818 80 06            [24]  890 	sjmp	00107$
      00481A                        891 00224$:
      00481A ED               [12]  892 	mov	a,r5
      00481B B5 04 02         [24]  893 	cjne	a,ar4,00225$
      00481E 80 07            [24]  894 	sjmp	00108$
      004820                        895 00225$:
      004820                        896 00107$:
      004820 C0 05            [24]  897 	push	ar5
      004822 12 47 61         [24]  898 	lcall	_commit_pending
      004825 D0 05            [24]  899 	pop	ar5
      004827                        900 00108$:
                                    901 ;	keyboards/ajazz/ak820/ak820_tapping.c:75: if (IS_NOEVENT(*event) || id == NONE) return true;
      004827 90 06 3F         [24]  902 	mov	dptr,#_ak820_tapping_before_event_10000_611
      00482A 12 3A 41         [24]  903 	lcall	_ak820_outline_0051
      00482D 74 04            [12]  904 	mov	a,#0x04
      00482F 12 4B 5A         [24]  905 	lcall	_ak820_outline_0013
      004832 60 03            [24]  906 	jz	00114$
      004834 BD FF 04         [24]  907 	cjne	r5,#0xff,00115$
      004837                        908 00114$:
      004837 75 82 01         [24]  909 	mov	dpl, #0x01
      00483A 22               [24]  910 	ret
      00483B                        911 00115$:
                                    912 ;	keyboards/ajazz/ak820/ak820_tapping.c:76: if ((source_state[id] & SOURCE_BLOCKED)) {
      00483B ED               [12]  913 	mov	a,r5
      00483C 12 4B B6         [24]  914 	lcall	_ak820_outline_0078
      00483F 30 E1 13         [24]  915 	jnb	acc.1,00120$
                                    916 ;	keyboards/ajazz/ak820/ak820_tapping.c:77: if (!event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      004842 74 05            [12]  917 	mov	a,#0x05
      004844 2E               [12]  918 	add	a, r6
      004845 12 3A 16         [24]  919 	lcall	_ak820_outline_0014
      004848 70 07            [24]  920 	jnz	00118$
      00484A 74 FD            [12]  921 	mov	a,#0xfd
      00484C 5B               [12]  922 	anl	a,r3
      00484D 12 3A 95         [24]  923 	lcall	_ak820_outline_0117
      004850 F0               [24]  924 	movx	@dptr,a
      004851                        925 00118$:
                                    926 ;	keyboards/ajazz/ak820/ak820_tapping.c:78: return false;
      004851 75 82 00         [24]  927 	mov	dpl, #0x00
      004854 22               [24]  928 	ret
      004855                        929 00120$:
                                    930 ;	keyboards/ajazz/ak820/ak820_tapping.c:81: if (event->pressed == ((source_state[id] & SOURCE_ACTIVE) != 0)) return false;
      004855 12 45 6E         [24]  931 	lcall	_ak820_outline_0011
      004858 E0               [24]  932 	movx	a,@dptr
      004859 FF               [12]  933 	mov	r7,a
      00485A 8B 06            [24]  934 	mov	ar6,r3
      00485C 53 06 01         [24]  935 	anl	ar6,#0x01
      00485F EE               [12]  936 	mov	a,r6
      004860 B4 01 00         [24]  937 	cjne	a,#0x01,00231$
      004863                        938 00231$:
      004863 B3               [12]  939 	cpl	c
      004864 92 0D            [24]  940 	mov	_ak820_tapping_before_sloc0_1_0,c
      004866 8F F0            [24]  941 	mov	b,r7
      004868 E4               [12]  942 	clr	a
      004869 33               [12]  943 	rlc	a
      00486A B5 F0 04         [24]  944 	cjne	a,b,00122$
      00486D 75 82 00         [24]  945 	mov	dpl, #0x00
      004870 22               [24]  946 	ret
      004871                        947 00122$:
                                    948 ;	keyboards/ajazz/ak820/ak820_tapping.c:82: source_state[id] ^= SOURCE_ACTIVE;
      004871 63 03 01         [24]  949 	xrl	ar3,#0x01
      004874 12 3A 95         [24]  950 	lcall	_ak820_outline_0117
      004877 EB               [12]  951 	mov	a,r3
      004878 F0               [24]  952 	movx	@dptr,a
                                    953 ;	keyboards/ajazz/ak820/ak820_tapping.c:83: return true;
      004879 75 82 01         [24]  954 	mov	dpl, #0x01
                                    955 ;	keyboards/ajazz/ak820/ak820_tapping.c:84: }
      00487C 22               [24]  956 	ret
                                    957 ;------------------------------------------------------------
                                    958 ;Allocation info for local variables in function 'ak820_tapping_process'
                                    959 ;------------------------------------------------------------
                                    960 ;record        Allocated with name '_ak820_tapping_process_record_10000_622'
                                    961 ;id            Allocated with name '_ak820_tapping_process_id_10000_623'
                                    962 ;kind          Allocated with name '_ak820_tapping_process_kind_10000_623'
                                    963 ;code          Allocated with name '_ak820_tapping_process_code_10000_623'
                                    964 ;sc_mods       Allocated with name '_ak820_tapping_process_sc_mods_10000_623'
                                    965 ;------------------------------------------------------------
                                    966 ;	keyboards/ajazz/ak820/ak820_tapping.c:85: bool ak820_tapping_process(keyrecord_t AK820_STATE_MEM *record) {
                                    967 ;	-----------------------------------------
                                    968 ;	 function ak820_tapping_process
                                    969 ;	-----------------------------------------
      00487D                        970 _ak820_tapping_process:
      00487D 12 3A 84         [24]  971 	lcall	_ak820_outline_0103
      004880 90 06 41         [24]  972 	mov	dptr,#_ak820_tapping_process_record_10000_622
      004883 12 3A 89         [24]  973 	lcall	_ak820_outline_0104
                                    974 ;	keyboards/ajazz/ak820/ak820_tapping.c:89: uint8_t sc_mods = 0;
      004886 90 06 45         [24]  975 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_623
      004889 E4               [12]  976 	clr	a
      00488A F0               [24]  977 	movx	@dptr,a
                                    978 ;	keyboards/ajazz/ak820/ak820_tapping.c:91: if (IS_NOEVENT(record->event)) return true;
      00488B 90 06 41         [24]  979 	mov	dptr,#_ak820_tapping_process_record_10000_622
      00488E 12 3A 41         [24]  980 	lcall	_ak820_outline_0051
      004891 74 04            [12]  981 	mov	a,#0x04
      004893 12 4B 4F         [24]  982 	lcall	_ak820_outline_0012
      004896 70 04            [24]  983 	jnz	00102$
      004898 75 82 01         [24]  984 	mov	dpl, #0x01
      00489B 22               [24]  985 	ret
      00489C                        986 00102$:
                                    987 ;	keyboards/ajazz/ak820/ak820_tapping.c:92: id = ak820_tapping_source(record->event.key);
      00489C 8E 04            [24]  988 	mov	ar4,r6
      00489E 8F 05            [24]  989 	mov	ar5,r7
      0048A0 12 4B 74         [24]  990 	lcall	_ak820_outline_0023
      0048A3 C0 07            [24]  991 	push	ar7
      0048A5 C0 06            [24]  992 	push	ar6
      0048A7 12 B9 5D         [24]  993 	lcall	___memcpy
      0048AA 12 46 CF         [24]  994 	lcall	_ak820_tapping_source
      0048AD AD 82            [24]  995 	mov	r5, dpl
      0048AF D0 06            [24]  996 	pop	ar6
      0048B1 D0 07            [24]  997 	pop	ar7
                                    998 ;	keyboards/ajazz/ak820/ak820_tapping.c:93: if (id == NONE) return true;
      0048B3 BD FF 04         [24]  999 	cjne	r5,#0xff,00104$
      0048B6 75 82 01         [24] 1000 	mov	dpl, #0x01
      0048B9 22               [24] 1001 	ret
      0048BA                       1002 00104$:
                                   1003 ;	keyboards/ajazz/ak820/ak820_tapping.c:94: code = record->keycode;
      0048BA 74 07            [12] 1004 	mov	a,#0x07
      0048BC 12 3A 28         [24] 1005 	lcall	_ak820_outline_0017
      0048BF FE               [12] 1006 	mov	r6,a
      0048C0 A3               [24] 1007 	inc	dptr
      0048C1 E0               [24] 1008 	movx	a,@dptr
      0048C2 FF               [12] 1009 	mov	r7,a
      0048C3 90 06 43         [24] 1010 	mov	dptr,#_ak820_tapping_process_code_10000_623
      0048C6 12 4B A9         [24] 1011 	lcall	_ak820_outline_0059
                                   1012 ;	keyboards/ajazz/ak820/ak820_tapping.c:96: if (code == SC_LSPO) { code = MT(MOD_LSFT, KC_9); sc_mods = MOD_BIT(KC_LEFT_SHIFT); }
      0048C9 BE 1A 15         [24] 1013 	cjne	r6,#0x1a,00111$
      0048CC BF 7C 12         [24] 1014 	cjne	r7,#0x7c,00111$
      0048CF 90 06 43         [24] 1015 	mov	dptr,#_ak820_tapping_process_code_10000_623
      0048D2 74 26            [12] 1016 	mov	a,#0x26
      0048D4 F0               [24] 1017 	movx	@dptr,a
      0048D5 74 22            [12] 1018 	mov	a,#0x22
      0048D7 A3               [24] 1019 	inc	dptr
      0048D8 F0               [24] 1020 	movx	@dptr,a
      0048D9 90 06 45         [24] 1021 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_623
      0048DC 74 02            [12] 1022 	mov	a,#0x02
      0048DE F0               [24] 1023 	movx	@dptr,a
      0048DF 80 28            [24] 1024 	sjmp	00112$
      0048E1                       1025 00111$:
                                   1026 ;	keyboards/ajazz/ak820/ak820_tapping.c:97: else if (code == SC_RSPC) { code = MT(MOD_RSFT, KC_0); sc_mods = MOD_BIT(KC_RIGHT_SHIFT); }
      0048E1 BE 1B 15         [24] 1027 	cjne	r6,#0x1b,00108$
      0048E4 BF 7C 12         [24] 1028 	cjne	r7,#0x7c,00108$
      0048E7 90 06 43         [24] 1029 	mov	dptr,#_ak820_tapping_process_code_10000_623
      0048EA 74 27            [12] 1030 	mov	a,#0x27
      0048EC F0               [24] 1031 	movx	@dptr,a
      0048ED 74 32            [12] 1032 	mov	a,#0x32
      0048EF A3               [24] 1033 	inc	dptr
      0048F0 F0               [24] 1034 	movx	@dptr,a
      0048F1 90 06 45         [24] 1035 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_623
      0048F4 74 20            [12] 1036 	mov	a,#0x20
      0048F6 F0               [24] 1037 	movx	@dptr,a
      0048F7 80 10            [24] 1038 	sjmp	00112$
      0048F9                       1039 00108$:
                                   1040 ;	keyboards/ajazz/ak820/ak820_tapping.c:98: else if (code == SC_SENT) code = MT(MOD_RSFT, KC_ENTER);
      0048F9 BE 1E 0D         [24] 1041 	cjne	r6,#0x1e,00112$
      0048FC BF 7C 0A         [24] 1042 	cjne	r7,#0x7c,00112$
      0048FF 90 06 43         [24] 1043 	mov	dptr,#_ak820_tapping_process_code_10000_623
      004902 74 28            [12] 1044 	mov	a,#0x28
      004904 F0               [24] 1045 	movx	@dptr,a
      004905 74 32            [12] 1046 	mov	a,#0x32
      004907 A3               [24] 1047 	inc	dptr
      004908 F0               [24] 1048 	movx	@dptr,a
      004909                       1049 00112$:
                                   1050 ;	keyboards/ajazz/ak820/ak820_tapping.c:100: kind = code >> 8;
      004909 90 06 43         [24] 1051 	mov	dptr,#_ak820_tapping_process_code_10000_623
      00490C E0               [24] 1052 	movx	a,@dptr
      00490D A3               [24] 1053 	inc	dptr
      00490E E0               [24] 1054 	movx	a,@dptr
      00490F FF               [12] 1055 	mov	r7,a
                                   1056 ;	keyboards/ajazz/ak820/ak820_tapping.c:101: if (kind < 0x20 || kind >= 0x50) return true;
      004910 BF 20 00         [24] 1057 	cjne	r7,#0x20,00242$
      004913                       1058 00242$:
      004913 40 05            [24] 1059 	jc	00113$
      004915 BF 50 00         [24] 1060 	cjne	r7,#0x50,00244$
      004918                       1061 00244$:
      004918 40 04            [24] 1062 	jc	00114$
      00491A                       1063 00113$:
      00491A 75 82 01         [24] 1064 	mov	dpl, #0x01
      00491D 22               [24] 1065 	ret
      00491E                       1066 00114$:
                                   1067 ;	keyboards/ajazz/ak820/ak820_tapping.c:102: if (kind >= 0x40 && (kind & 15) >= MAX_LAYER) return false;
      00491E BF 40 00         [24] 1068 	cjne	r7,#0x40,00246$
      004921                       1069 00246$:
      004921 40 0C            [24] 1070 	jc	00117$
      004923 53 07 0F         [24] 1071 	anl	ar7,#0x0f
      004926 BF 06 00         [24] 1072 	cjne	r7,#0x06,00248$
      004929                       1073 00248$:
      004929 40 04            [24] 1074 	jc	00117$
      00492B 75 82 00         [24] 1075 	mov	dpl, #0x00
      00492E 22               [24] 1076 	ret
      00492F                       1077 00117$:
                                   1078 ;	keyboards/ajazz/ak820/ak820_tapping.c:103: if (record->event.pressed) {
      00492F 90 06 41         [24] 1079 	mov	dptr,#_ak820_tapping_process_record_10000_622
      004932 12 3A 41         [24] 1080 	lcall	_ak820_outline_0051
      004935 74 05            [12] 1081 	mov	a,#0x05
      004937 12 4B 5A         [24] 1082 	lcall	_ak820_outline_0013
      00493A 60 1E            [24] 1083 	jz	00131$
                                   1084 ;	keyboards/ajazz/ak820/ak820_tapping.c:104: pending = id;
      00493C 90 0D 9A         [24] 1085 	mov	dptr,#_pending
      00493F ED               [12] 1086 	mov	a,r5
      004940 12 45 78         [24] 1087 	lcall	_ak820_outline_0030
                                   1088 ;	keyboards/ajazz/ak820/ak820_tapping.c:105: pending_time = record->event.time;
      004943 12 3A 41         [24] 1089 	lcall	_ak820_outline_0051
      004946 90 06 34         [24] 1090 	mov	dptr,#_pending_time
      004949 12 4B A9         [24] 1091 	lcall	_ak820_outline_0059
                                   1092 ;	keyboards/ajazz/ak820/ak820_tapping.c:106: pending_code = code;
      00494C 90 06 43         [24] 1093 	mov	dptr,#_ak820_tapping_process_code_10000_623
      00494F 12 3A 41         [24] 1094 	lcall	_ak820_outline_0051
      004952 90 06 36         [24] 1095 	mov	dptr,#_pending_code
      004955 12 4B A9         [24] 1096 	lcall	_ak820_outline_0059
      004958 21 F6            [12] 1097 	ajmp	00132$
      00495A                       1098 00131$:
                                   1099 ;	keyboards/ajazz/ak820/ak820_tapping.c:107: } else if (id == pending) {
      00495A 90 0D 9A         [24] 1100 	mov	dptr,#_pending
      00495D E0               [24] 1101 	movx	a,@dptr
      00495E FF               [12] 1102 	mov	r7,a
      00495F ED               [12] 1103 	mov	a,r5
      004960 B5 07 02         [24] 1104 	cjne	a,ar7,00251$
      004963 80 02            [24] 1105 	sjmp	00252$
      004965                       1106 00251$:
      004965 21 CF            [12] 1107 	ajmp	00128$
      004967                       1108 00252$:
                                   1109 ;	keyboards/ajazz/ak820/ak820_tapping.c:108: pending = NONE;
      004967 12 4B C4         [24] 1110 	lcall	_ak820_outline_0150
                                   1111 ;	keyboards/ajazz/ak820/ak820_tapping.c:110: if (sc_mods) add_owned_mods(sc_mods);
      00496A 90 06 45         [24] 1112 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_623
      00496D E0               [24] 1113 	movx	a,@dptr
      00496E FF               [12] 1114 	mov	r7,a
      00496F E0               [24] 1115 	movx	a,@dptr
      004970 60 05            [24] 1116 	jz	00120$
      004972 8F 82            [24] 1117 	mov	dpl, r7
      004974 12 7F C6         [24] 1118 	lcall	_add_owned_mods
      004977                       1119 00120$:
                                   1120 ;	keyboards/ajazz/ak820/ak820_tapping.c:114: record->keycode = (uint8_t)code;
      004977 90 06 41         [24] 1121 	mov	dptr,#_ak820_tapping_process_record_10000_622
      00497A 12 3A 41         [24] 1122 	lcall	_ak820_outline_0051
      00497D 74 07            [12] 1123 	mov	a,#0x07
      00497F 2E               [12] 1124 	add	a, r6
      004980 FB               [12] 1125 	mov	r3,a
      004981 E4               [12] 1126 	clr	a
      004982 3F               [12] 1127 	addc	a, r7
      004983 FC               [12] 1128 	mov	r4,a
      004984 90 06 43         [24] 1129 	mov	dptr,#_ak820_tapping_process_code_10000_623
      004987 E0               [24] 1130 	movx	a,@dptr
      004988 F9               [12] 1131 	mov	r1,a
      004989 7A 00            [12] 1132 	mov	r2,#0x00
      00498B 12 36 42         [24] 1133 	lcall	_ak820_outline_0122
      00498E E9               [12] 1134 	mov	a,r1
      00498F F0               [24] 1135 	movx	@dptr,a
      004990 EA               [12] 1136 	mov	a,r2
      004991 A3               [24] 1137 	inc	dptr
      004992 F0               [24] 1138 	movx	@dptr,a
                                   1139 ;	keyboards/ajazz/ak820/ak820_tapping.c:115: if (record->keycode > KC_TRANSPARENT) {
      004993 C3               [12] 1140 	clr	c
      004994 04               [12] 1141 	inc	a
      004995 99               [12] 1142 	subb	a,r1
      004996 50 25            [24] 1143 	jnc	00122$
                                   1144 ;	free result
                                   1145 ;	keyboards/ajazz/ak820/ak820_tapping.c:116: record->tap.count = 1;
      004998 74 06            [12] 1146 	mov	a,#0x06
      00499A 12 3A 28         [24] 1147 	lcall	_ak820_outline_0017
      00499D 54 0F            [12] 1148 	anl	a,#0x0f
      00499F 44 10            [12] 1149 	orl	a,#0x10
      0049A1 F0               [24] 1150 	movx	@dptr,a
                                   1151 ;	keyboards/ajazz/ak820/ak820_tapping.c:117: record->event.pressed = true;
      0049A2 12 45 6E         [24] 1152 	lcall	_ak820_outline_0011
      0049A5 12 4B 99         [24] 1153 	lcall	_ak820_outline_0055
                                   1154 ;	keyboards/ajazz/ak820/ak820_tapping.c:118: process_record(record);
      0049A8 12 74 6E         [24] 1155 	lcall	_process_record
                                   1156 ;	keyboards/ajazz/ak820/ak820_tapping.c:119: record->event.pressed = false;
      0049AB 90 06 41         [24] 1157 	mov	dptr,#_ak820_tapping_process_record_10000_622
      0049AE 12 39 E1         [24] 1158 	lcall	_ak820_outline_0004
      0049B1 A3               [24] 1159 	inc	dptr
      0049B2 A3               [24] 1160 	inc	dptr
      0049B3 A3               [24] 1161 	inc	dptr
      0049B4 A3               [24] 1162 	inc	dptr
      0049B5 A3               [24] 1163 	inc	dptr
      0049B6 E4               [12] 1164 	clr	a
      0049B7 12 45 A4         [24] 1165 	lcall	_ak820_outline_0061
                                   1166 ;	keyboards/ajazz/ak820/ak820_tapping.c:120: process_record(record);
      0049BA 12 74 6E         [24] 1167 	lcall	_process_record
      0049BD                       1168 00122$:
                                   1169 ;	keyboards/ajazz/ak820/ak820_tapping.c:123: if (sc_mods) {
      0049BD 90 06 45         [24] 1170 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_623
      0049C0 E0               [24] 1171 	movx	a,@dptr
      0049C1 FF               [12] 1172 	mov	r7,a
      0049C2 E0               [24] 1173 	movx	a,@dptr
      0049C3 60 31            [24] 1174 	jz	00132$
                                   1175 ;	keyboards/ajazz/ak820/ak820_tapping.c:124: del_owned_mods(sc_mods);
      0049C5 8F 82            [24] 1176 	mov	dpl, r7
      0049C7 12 7F D6         [24] 1177 	lcall	_del_owned_mods
                                   1178 ;	keyboards/ajazz/ak820/ak820_tapping.c:125: send_keyboard_report();
      0049CA 12 82 FF         [24] 1179 	lcall	_send_keyboard_report
      0049CD 80 27            [24] 1180 	sjmp	00132$
      0049CF                       1181 00128$:
                                   1182 ;	keyboards/ajazz/ak820/ak820_tapping.c:128: } else if ((source_state[id] & SOURCE_HELD)) {
      0049CF ED               [12] 1183 	mov	a,r5
      0049D0 24 B2            [12] 1184 	add	a, #_source_state
      0049D2 FE               [12] 1185 	mov	r6,a
      0049D3 E4               [12] 1186 	clr	a
      0049D4 34 05            [12] 1187 	addc	a, #(_source_state >> 8)
      0049D6 FF               [12] 1188 	mov	r7,a
      0049D7 12 3A 78         [24] 1189 	lcall	_ak820_outline_0098
      0049DA FD               [12] 1190 	mov	r5,a
      0049DB 30 E2 18         [24] 1191 	jnb	acc.2,00132$
                                   1192 ;	keyboards/ajazz/ak820/ak820_tapping.c:129: source_state[id] &= ~SOURCE_HELD;
      0049DE 53 05 FB         [24] 1193 	anl	ar5,#0xfb
      0049E1 12 45 C9         [24] 1194 	lcall	_ak820_outline_0116
      0049E4 ED               [12] 1195 	mov	a,r5
      0049E5 F0               [24] 1196 	movx	@dptr,a
                                   1197 ;	keyboards/ajazz/ak820/ak820_tapping.c:130: hold(code, false);
      0049E6 90 06 43         [24] 1198 	mov	dptr,#_ak820_tapping_process_code_10000_623
      0049E9 12 3A 41         [24] 1199 	lcall	_ak820_outline_0051
      0049EC 90 06 3A         [24] 1200 	mov	dptr,#_hold_PARM_2
      0049EF E4               [12] 1201 	clr	a
      0049F0 12 45 A4         [24] 1202 	lcall	_ak820_outline_0061
      0049F3 12 47 09         [24] 1203 	lcall	_hold
      0049F6                       1204 00132$:
                                   1205 ;	keyboards/ajazz/ak820/ak820_tapping.c:132: return false;
      0049F6 75 82 00         [24] 1206 	mov	dpl, #0x00
                                   1207 ;	keyboards/ajazz/ak820/ak820_tapping.c:133: }
      0049F9 22               [24] 1208 	ret
                                   1209 ;------------------------------------------------------------
                                   1210 ;Allocation info for local variables in function 'ak820_tapping_cancel'
                                   1211 ;------------------------------------------------------------
                                   1212 ;i             Allocated with name '_ak820_tapping_cancel_i_20000_646'
                                   1213 ;state         Allocated with name '_ak820_tapping_cancel_state_30000_647'
                                   1214 ;------------------------------------------------------------
                                   1215 ;	keyboards/ajazz/ak820/ak820_tapping.c:134: void ak820_tapping_cancel(void) {
                                   1216 ;	-----------------------------------------
                                   1217 ;	 function ak820_tapping_cancel
                                   1218 ;	-----------------------------------------
      0049FA                       1219 _ak820_tapping_cancel:
                                   1220 ;	keyboards/ajazz/ak820/ak820_tapping.c:135: pending = NONE;
      0049FA 12 4B C4         [24] 1221 	lcall	_ak820_outline_0150
                                   1222 ;	keyboards/ajazz/ak820/ak820_tapping.c:136: for (uint8_t i = 0; i < SOURCES; ++i) {
      0049FD 7F 00            [12] 1223 	mov	r7,#0x00
      0049FF                       1224 00103$:
      0049FF BF 82 00         [24] 1225 	cjne	r7,#0x82,00122$
      004A02                       1226 00122$:
      004A02 50 16            [24] 1227 	jnc	00105$
                                   1228 ;	keyboards/ajazz/ak820/ak820_tapping.c:137: uint8_t state = source_state[i];
      004A04 12 4B 65         [24] 1229 	lcall	_ak820_outline_0019
                                   1230 ;	keyboards/ajazz/ak820/ak820_tapping.c:138: source_state[i] = (state & SOURCE_BLOCKED) | ((state & SOURCE_ACTIVE) << 1);
      004A07 74 02            [12] 1231 	mov	a,#0x02
      004A09 5C               [12] 1232 	anl	a,r4
      004A0A FB               [12] 1233 	mov	r3,a
      004A0B 53 04 01         [24] 1234 	anl	ar4,#0x01
      004A0E EC               [12] 1235 	mov	a,r4
      004A0F 2C               [12] 1236 	add	a,r4
      004A10 42 03            [12] 1237 	orl	ar3,a
      004A12 12 3A A5         [24] 1238 	lcall	_ak820_outline_0132
      004A15 EB               [12] 1239 	mov	a,r3
      004A16 F0               [24] 1240 	movx	@dptr,a
                                   1241 ;	keyboards/ajazz/ak820/ak820_tapping.c:136: for (uint8_t i = 0; i < SOURCES; ++i) {
      004A17 0F               [12] 1242 	inc	r7
      004A18 80 E5            [24] 1243 	sjmp	00103$
      004A1A                       1244 00105$:
                                   1245 ;	keyboards/ajazz/ak820/ak820_tapping.c:140: }
      004A1A 22               [24] 1246 	ret
                                   1247 ;------------------------------------------------------------
                                   1248 ;Allocation info for local variables in function 'ak820_oneshot_process'
                                   1249 ;------------------------------------------------------------
                                   1250 ;id            Allocated with name '_ak820_oneshot_process_PARM_2'
                                   1251 ;pressed       Allocated with name '_ak820_oneshot_process_PARM_3'
                                   1252 ;code          Allocated with name '_ak820_oneshot_process_code_10000_648'
                                   1253 ;mods          Allocated with name '_ak820_oneshot_process_mods_10000_649'
                                   1254 ;i             Allocated with name '_ak820_oneshot_process_i_40000_663'
                                   1255 ;------------------------------------------------------------
                                   1256 ;	keyboards/ajazz/ak820/ak820_tapping.c:149: bool ak820_oneshot_process(uint16_t code, uint8_t id, bool pressed) {
                                   1257 ;	-----------------------------------------
                                   1258 ;	 function ak820_oneshot_process
                                   1259 ;	-----------------------------------------
      004A1B                       1260 _ak820_oneshot_process:
      004A1B 12 3A 84         [24] 1261 	lcall	_ak820_outline_0103
      004A1E 90 06 4A         [24] 1262 	mov	dptr,#_ak820_oneshot_process_code_10000_648
      004A21 12 3A 89         [24] 1263 	lcall	_ak820_outline_0104
                                   1264 ;	keyboards/ajazz/ak820/ak820_tapping.c:151: if (id == NONE || get_repeat_key_count()) return true;
      004A24 90 06 48         [24] 1265 	mov	dptr,#_ak820_oneshot_process_PARM_2
      004A27 E0               [24] 1266 	movx	a,@dptr
      004A28 FF               [12] 1267 	mov	r7,a
      004A29 BF FF 02         [24] 1268 	cjne	r7,#0xff,00248$
      004A2C 80 07            [24] 1269 	sjmp	00101$
      004A2E                       1270 00248$:
      004A2E 12 A3 9A         [24] 1271 	lcall	_get_repeat_key_count
      004A31 E5 82            [12] 1272 	mov	a, dpl
      004A33 60 04            [24] 1273 	jz	00102$
      004A35                       1274 00101$:
      004A35 75 82 01         [24] 1275 	mov	dpl, #0x01
      004A38 22               [24] 1276 	ret
      004A39                       1277 00102$:
                                   1278 ;	keyboards/ajazz/ak820/ak820_tapping.c:164: if ((code >> 8) == 0x52 && ((uint8_t)code & 0xe0) == 0xa0) {
      004A39 90 06 4A         [24] 1279 	mov	dptr,#_ak820_oneshot_process_code_10000_648
      004A3C E0               [24] 1280 	movx	a,@dptr
      004A3D FD               [12] 1281 	mov	r5,a
      004A3E A3               [24] 1282 	inc	dptr
      004A3F E0               [24] 1283 	movx	a,@dptr
      004A40 FB               [12] 1284 	mov	r3,a
      004A41 BB 52 02         [24] 1285 	cjne	r3,#0x52,00250$
      004A44 80 02            [24] 1286 	sjmp	00251$
      004A46                       1287 00250$:
      004A46 41 E9            [12] 1288 	ajmp	00116$
      004A48                       1289 00251$:
      004A48 8D 04            [24] 1290 	mov	ar4,r5
      004A4A 53 04 E0         [24] 1291 	anl	ar4,#0xe0
      004A4D BC A0 02         [24] 1292 	cjne	r4,#0xa0,00252$
      004A50 80 02            [24] 1293 	sjmp	00253$
      004A52                       1294 00252$:
      004A52 41 E9            [12] 1295 	ajmp	00116$
      004A54                       1296 00253$:
                                   1297 ;	keyboards/ajazz/ak820/ak820_tapping.c:165: mods = code & 15;
      004A54 8D 04            [24] 1298 	mov	ar4,r5
      004A56 53 04 0F         [24] 1299 	anl	ar4,#0x0f
      004A59 90 06 4C         [24] 1300 	mov	dptr,#_ak820_oneshot_process_mods_10000_649
      004A5C EC               [12] 1301 	mov	a,r4
      004A5D F0               [24] 1302 	movx	@dptr,a
                                   1303 ;	keyboards/ajazz/ak820/ak820_tapping.c:166: if (code & 16) mods <<= 4;
      004A5E ED               [12] 1304 	mov	a,r5
      004A5F 30 E4 08         [24] 1305 	jnb	acc.4,00105$
      004A62 EC               [12] 1306 	mov	a,r4
      004A63 C4               [12] 1307 	swap	a
      004A64 54 F0            [12] 1308 	anl	a,#0xf0
      004A66 90 06 4C         [24] 1309 	mov	dptr,#_ak820_oneshot_process_mods_10000_649
      004A69 F0               [24] 1310 	movx	@dptr,a
      004A6A                       1311 00105$:
                                   1312 ;	keyboards/ajazz/ak820/ak820_tapping.c:167: if (pressed) {
      004A6A 90 06 49         [24] 1313 	mov	dptr,#_ak820_oneshot_process_PARM_3
      004A6D E0               [24] 1314 	movx	a,@dptr
      004A6E 60 2D            [24] 1315 	jz	00113$
                                   1316 ;	keyboards/ajazz/ak820/ak820_tapping.c:168: source_state[id] |= SOURCE_ONESHOT;
      004A70 12 4B 65         [24] 1317 	lcall	_ak820_outline_0019
      004A73 43 04 08         [24] 1318 	orl	ar4,#0x08
      004A76 12 45 AA         [24] 1319 	lcall	_ak820_outline_0065
                                   1320 ;	keyboards/ajazz/ak820/ak820_tapping.c:169: source_state[id] &= ~SOURCE_ONESHOT_USED;
      004A79 53 04 EF         [24] 1321 	anl	ar4,#0xef
      004A7C 12 45 AA         [24] 1322 	lcall	_ak820_outline_0065
                                   1323 ;	keyboards/ajazz/ak820/ak820_tapping.c:170: if (ak820_oneshot_target != NONE) source_state[id] |= SOURCE_ONESHOT_USED;
      004A7F 90 0D 9B         [24] 1324 	mov	dptr,#_ak820_oneshot_target
      004A82 E0               [24] 1325 	movx	a,@dptr
      004A83 FC               [12] 1326 	mov	r4,a
      004A84 BC FF 02         [24] 1327 	cjne	r4,#0xff,00256$
      004A87 80 09            [24] 1328 	sjmp	00107$
      004A89                       1329 00256$:
      004A89 12 4B AF         [24] 1330 	lcall	_ak820_outline_0075
      004A8C 43 04 10         [24] 1331 	orl	ar4,#0x10
      004A8F 12 45 AA         [24] 1332 	lcall	_ak820_outline_0065
      004A92                       1333 00107$:
                                   1334 ;	keyboards/ajazz/ak820/ak820_tapping.c:171: register_mods(mods);
      004A92 90 06 4C         [24] 1335 	mov	dptr,#_ak820_oneshot_process_mods_10000_649
      004A95 E0               [24] 1336 	movx	a,@dptr
      004A96 F5 82            [12] 1337 	mov	dpl,a
      004A98 12 79 9A         [24] 1338 	lcall	_register_mods
      004A9B 80 48            [24] 1339 	sjmp	00114$
      004A9D                       1340 00113$:
                                   1341 ;	keyboards/ajazz/ak820/ak820_tapping.c:172: } else if (source_state[id] & SOURCE_ONESHOT) {
      004A9D 12 4B 65         [24] 1342 	lcall	_ak820_outline_0019
      004AA0 30 E3 42         [24] 1343 	jnb	acc.3,00114$
                                   1344 ;	keyboards/ajazz/ak820/ak820_tapping.c:173: if (!(source_state[id] & SOURCE_ONESHOT_USED)) {
      004AA3 EC               [12] 1345 	mov	a,r4
      004AA4 20 E4 24         [24] 1346 	jb	acc.4,00109$
                                   1347 ;	keyboards/ajazz/ak820/ak820_tapping.c:174: add_owned_mods(mods & ~ak820_oneshot_mods);
      004AA7 90 06 46         [24] 1348 	mov	dptr,#_ak820_oneshot_mods
      004AAA E0               [24] 1349 	movx	a,@dptr
      004AAB F4               [12] 1350 	cpl	a
      004AAC FC               [12] 1351 	mov	r4,a
      004AAD 90 06 4C         [24] 1352 	mov	dptr,#_ak820_oneshot_process_mods_10000_649
      004AB0 E0               [24] 1353 	movx	a,@dptr
      004AB1 FB               [12] 1354 	mov	r3,a
      004AB2 52 04            [12] 1355 	anl	ar4,a
      004AB4 8C 82            [24] 1356 	mov	dpl, r4
      004AB6 C0 06            [24] 1357 	push	ar6
      004AB8 C0 05            [24] 1358 	push	ar5
      004ABA C0 03            [24] 1359 	push	ar3
      004ABC 12 7F C6         [24] 1360 	lcall	_add_owned_mods
      004ABF D0 03            [24] 1361 	pop	ar3
      004AC1 D0 05            [24] 1362 	pop	ar5
      004AC3 D0 06            [24] 1363 	pop	ar6
                                   1364 ;	keyboards/ajazz/ak820/ak820_tapping.c:175: ak820_oneshot_mods |= mods;
      004AC5 90 06 46         [24] 1365 	mov	dptr,#_ak820_oneshot_mods
      004AC8 E0               [24] 1366 	movx	a,@dptr
      004AC9 4B               [12] 1367 	orl	a,r3
      004ACA F0               [24] 1368 	movx	@dptr,a
      004ACB                       1369 00109$:
                                   1370 ;	keyboards/ajazz/ak820/ak820_tapping.c:177: unregister_mods(mods);
      004ACB 90 06 4C         [24] 1371 	mov	dptr,#_ak820_oneshot_process_mods_10000_649
      004ACE E0               [24] 1372 	movx	a,@dptr
      004ACF F5 82            [12] 1373 	mov	dpl,a
      004AD1 C0 06            [24] 1374 	push	ar6
      004AD3 C0 05            [24] 1375 	push	ar5
      004AD5 12 79 AE         [24] 1376 	lcall	_unregister_mods
      004AD8 D0 05            [24] 1377 	pop	ar5
      004ADA D0 06            [24] 1378 	pop	ar6
                                   1379 ;	keyboards/ajazz/ak820/ak820_tapping.c:178: source_state[id] &= ~(SOURCE_ONESHOT | SOURCE_ONESHOT_USED);
      004ADC 12 4B AF         [24] 1380 	lcall	_ak820_outline_0075
      004ADF 53 04 E7         [24] 1381 	anl	ar4,#0xe7
      004AE2 12 45 AA         [24] 1382 	lcall	_ak820_outline_0065
      004AE5                       1383 00114$:
                                   1384 ;	keyboards/ajazz/ak820/ak820_tapping.c:180: return false;
      004AE5 75 82 00         [24] 1385 	mov	dpl, #0x00
      004AE8 22               [24] 1386 	ret
      004AE9                       1387 00116$:
                                   1388 ;	keyboards/ajazz/ak820/ak820_tapping.c:182: if (pressed && code > KC_TRANSPARENT &&
      004AE9 90 06 49         [24] 1389 	mov	dptr,#_ak820_oneshot_process_PARM_3
      004AEC E0               [24] 1390 	movx	a,@dptr
      004AED 60 5C            [24] 1391 	jz	00124$
      004AEF 90 06 4A         [24] 1392 	mov	dptr,#_ak820_oneshot_process_code_10000_648
      004AF2 12 45 B7         [24] 1393 	lcall	_ak820_outline_0093
      004AF5 C3               [12] 1394 	clr	c
      004AF6 74 01            [12] 1395 	mov	a,#0x01
      004AF8 9D               [12] 1396 	subb	a,r5
      004AF9 E4               [12] 1397 	clr	a
      004AFA 9E               [12] 1398 	subb	a,r6
      004AFB 50 4E            [24] 1399 	jnc	00124$
                                   1400 ;	free result
                                   1401 ;	keyboards/ajazz/ak820/ak820_tapping.c:183: !(code >= KC_LCTL && code <= KC_RGUI) &&
      004AFD C3               [12] 1402 	clr	c
      004AFE ED               [12] 1403 	mov	a,r5
      004AFF 94 E0            [12] 1404 	subb	a,#0xe0
      004B01 EE               [12] 1405 	mov	a,r6
      004B02 94 00            [12] 1406 	subb	a,#0x00
      004B04 40 07            [24] 1407 	jc	00129$
      004B06 74 E7            [12] 1408 	mov	a,#0xe7
      004B08 9D               [12] 1409 	subb	a,r5
      004B09 E4               [12] 1410 	clr	a
      004B0A 9E               [12] 1411 	subb	a,r6
      004B0B 50 3E            [24] 1412 	jnc	00124$
                                   1413 ;	free result
      004B0D                       1414 00129$:
                                   1415 ;	keyboards/ajazz/ak820/ak820_tapping.c:184: !(code >= QK_TO && code <= QK_LAYER_TAP_TOGGLE_MAX)) {
      004B0D 74 AE            [12] 1416 	mov	a,#0x100 - 0x52
      004B0F 2E               [12] 1417 	add	a,r6
      004B10 50 09            [24] 1418 	jnc	00165$
      004B12 C3               [12] 1419 	clr	c
      004B13 74 DF            [12] 1420 	mov	a,#0xdf
      004B15 9D               [12] 1421 	subb	a,r5
      004B16 74 52            [12] 1422 	mov	a,#0x52
      004B18 9E               [12] 1423 	subb	a,r6
      004B19 50 30            [24] 1424 	jnc	00124$
                                   1425 ;	free result
                                   1426 ;	keyboards/ajazz/ak820/ak820_tapping.c:185: for (uint8_t i = 0; i < SOURCES; ++i)
      004B1B                       1427 00165$:
      004B1B 7E 00            [12] 1428 	mov	r6,#0x00
      004B1D                       1429 00131$:
      004B1D BE 82 00         [24] 1430 	cjne	r6,#0x82,00265$
      004B20                       1431 00265$:
      004B20 50 12            [24] 1432 	jnc	00120$
                                   1433 ;	keyboards/ajazz/ak820/ak820_tapping.c:186: if (source_state[i] & SOURCE_ONESHOT) source_state[i] |= SOURCE_ONESHOT_USED;
      004B22 EE               [12] 1434 	mov	a,r6
      004B23 12 4B B6         [24] 1435 	lcall	_ak820_outline_0078
      004B26 30 E3 08         [24] 1436 	jnb	acc.3,00132$
      004B29 43 03 10         [24] 1437 	orl	ar3,#0x10
      004B2C 12 3A 95         [24] 1438 	lcall	_ak820_outline_0117
      004B2F EB               [12] 1439 	mov	a,r3
      004B30 F0               [24] 1440 	movx	@dptr,a
      004B31                       1441 00132$:
                                   1442 ;	keyboards/ajazz/ak820/ak820_tapping.c:185: for (uint8_t i = 0; i < SOURCES; ++i)
      004B31 0E               [12] 1443 	inc	r6
      004B32 80 E9            [24] 1444 	sjmp	00131$
      004B34                       1445 00120$:
                                   1446 ;	keyboards/ajazz/ak820/ak820_tapping.c:187: if (ak820_oneshot_mods) {
      004B34 90 06 46         [24] 1447 	mov	dptr,#_ak820_oneshot_mods
      004B37 E0               [24] 1448 	movx	a,@dptr
      004B38 FE               [12] 1449 	mov	r6,a
      004B39 E0               [24] 1450 	movx	a,@dptr
      004B3A 60 0F            [24] 1451 	jz	00124$
                                   1452 ;	keyboards/ajazz/ak820/ak820_tapping.c:188: ak820_oneshot_consumed = ak820_oneshot_mods;
      004B3C 90 06 47         [24] 1453 	mov	dptr,#_ak820_oneshot_consumed
      004B3F EE               [12] 1454 	mov	a,r6
      004B40 F0               [24] 1455 	movx	@dptr,a
                                   1456 ;	keyboards/ajazz/ak820/ak820_tapping.c:189: ak820_oneshot_target = id;
      004B41 90 0D 9B         [24] 1457 	mov	dptr,#_ak820_oneshot_target
      004B44 EF               [12] 1458 	mov	a,r7
      004B45 F0               [24] 1459 	movx	@dptr,a
                                   1460 ;	keyboards/ajazz/ak820/ak820_tapping.c:190: ak820_oneshot_mods = 0;
      004B46 90 06 46         [24] 1461 	mov	dptr,#_ak820_oneshot_mods
      004B49 E4               [12] 1462 	clr	a
      004B4A F0               [24] 1463 	movx	@dptr,a
      004B4B                       1464 00124$:
                                   1465 ;	keyboards/ajazz/ak820/ak820_tapping.c:193: return true;
      004B4B 75 82 01         [24] 1466 	mov	dpl, #0x01
                                   1467 ;	keyboards/ajazz/ak820/ak820_tapping.c:194: }
      004B4E 22               [24] 1468 	ret
                                   1469 	.area CSEG    (CODE)
                                   1470 	.area CONST   (CODE)
                                   1471 	.area XINIT   (CODE)
      00C21E                       1472 __xinit__pending:
      00C21E FF                    1473 	.db #0xff	; 255
      00C21F                       1474 __xinit__ak820_oneshot_target:
      00C21F FF                    1475 	.db #0xff	; 255
                                   1476 	.area CABS    (ABS,CODE)
                                   1477 
                                   1478 ; Experimental exact instruction outlining.
                                   1479 	.globl _ak820_outline_0004
                                   1480 	.globl _ak820_outline_0005
                                   1481 	.globl _ak820_outline_0010
                                   1482 	.globl _ak820_outline_0011
                                   1483 	.globl _ak820_outline_0012
                                   1484 	.globl _ak820_outline_0013
                                   1485 	.globl _ak820_outline_0014
                                   1486 	.globl _ak820_outline_0017
                                   1487 	.globl _ak820_outline_0019
                                   1488 	.globl _ak820_outline_0023
                                   1489 	.globl _ak820_outline_0030
                                   1490 	.globl _ak820_outline_0034
                                   1491 	.globl _ak820_outline_0046
                                   1492 	.globl _ak820_outline_0051
                                   1493 	.globl _ak820_outline_0055
                                   1494 	.globl _ak820_outline_0056
                                   1495 	.globl _ak820_outline_0059
                                   1496 	.globl _ak820_outline_0061
                                   1497 	.globl _ak820_outline_0065
                                   1498 	.globl _ak820_outline_0075
                                   1499 	.globl _ak820_outline_0078
                                   1500 	.globl _ak820_outline_0093
                                   1501 	.globl _ak820_outline_0098
                                   1502 	.globl _ak820_outline_0100
                                   1503 	.globl _ak820_outline_0103
                                   1504 	.globl _ak820_outline_0104
                                   1505 	.globl _ak820_outline_0116
                                   1506 	.globl _ak820_outline_0117
                                   1507 	.globl _ak820_outline_0122
                                   1508 	.globl _ak820_outline_0132
                                   1509 	.globl _ak820_outline_0150
                                   1510 	.globl _ak820_outline_0153
                                   1511 	.globl _ak820_outline_0186
                                   1512 
                                   1513 	.area CSEG (CODE)
                                   1514 ; function ak820_outline_0012
      004B4F                       1515 _ak820_outline_0012:
      004B4F 2E               [12] 1516 	add	a,r6
      004B50 FC               [12] 1517 	mov	r4,a
      004B51 E4               [12] 1518 	clr	a
      004B52 3F               [12] 1519 	addc	a,r7
      004B53 FD               [12] 1520 	mov	r5,a
      004B54 8C 82            [24] 1521 	mov	dpl,r4
      004B56 8D 83            [24] 1522 	mov	dph,r5
      004B58 E0               [24] 1523 	movx	a,@dptr
      004B59 22               [24] 1524 	ret
                                   1525 
                                   1526 	.area CSEG (CODE)
                                   1527 ; function ak820_outline_0013
      004B5A                       1528 _ak820_outline_0013:
      004B5A 2E               [12] 1529 	add	a,r6
      004B5B FB               [12] 1530 	mov	r3,a
      004B5C E4               [12] 1531 	clr	a
      004B5D 3F               [12] 1532 	addc	a,r7
      004B5E FC               [12] 1533 	mov	r4,a
      004B5F 8B 82            [24] 1534 	mov	dpl,r3
      004B61 8C 83            [24] 1535 	mov	dph,r4
      004B63 E0               [24] 1536 	movx	a,@dptr
      004B64 22               [24] 1537 	ret
                                   1538 
                                   1539 	.area CSEG (CODE)
                                   1540 ; function ak820_outline_0019
      004B65                       1541 _ak820_outline_0019:
      004B65 EF               [12] 1542 	mov	a,r7
      004B66 24 B2            [12] 1543 	add	a,#_source_state
      004B68 FD               [12] 1544 	mov	r5,a
      004B69 E4               [12] 1545 	clr	a
      004B6A 34 05            [12] 1546 	addc	a,#(_source_state>>8)
      004B6C FE               [12] 1547 	mov	r6,a
      004B6D 8D 82            [24] 1548 	mov	dpl,r5
      004B6F 8E 83            [24] 1549 	mov	dph,r6
      004B71 E0               [24] 1550 	movx	a,@dptr
      004B72 FC               [12] 1551 	mov	r4,a
      004B73 22               [24] 1552 	ret
                                   1553 
                                   1554 	.area CSEG (CODE)
                                   1555 ; function ak820_outline_0023
      004B74                       1556 _ak820_outline_0023:
      004B74 90 0D 89         [24] 1557 	mov	dptr,#___memcpy_PARM_2
      004B77 EC               [12] 1558 	mov	a,r4
      004B78 F0               [24] 1559 	movx	@dptr,a
      004B79 ED               [12] 1560 	mov	a,r5
      004B7A A3               [24] 1561 	inc	dptr
      004B7B F0               [24] 1562 	movx	@dptr,a
      004B7C E4               [12] 1563 	clr	a
      004B7D A3               [24] 1564 	inc	dptr
      004B7E F0               [24] 1565 	movx	@dptr,a
      004B7F 90 0D 8C         [24] 1566 	mov	dptr,#___memcpy_PARM_3
      004B82 74 02            [12] 1567 	mov	a,#0x02
      004B84 F0               [24] 1568 	movx	@dptr,a
      004B85 E4               [12] 1569 	clr	a
      004B86 A3               [24] 1570 	inc	dptr
      004B87 F0               [24] 1571 	movx	@dptr,a
      004B88 90 06 38         [24] 1572 	mov	dptr,#_ak820_tapping_source_PARM_1
      004B8B F5 F0            [12] 1573 	mov	b,a
      004B8D 22               [24] 1574 	ret
                                   1575 
                                   1576 	.area CSEG (CODE)
                                   1577 ; function ak820_outline_0046
      004B8E                       1578 _ak820_outline_0046:
      004B8E 2E               [12] 1579 	add	a,r6
      004B8F FA               [12] 1580 	mov	r2,a
      004B90 E4               [12] 1581 	clr	a
      004B91 3F               [12] 1582 	addc	a,r7
      004B92 FB               [12] 1583 	mov	r3,a
      004B93 8A 82            [24] 1584 	mov	dpl,r2
      004B95 8B 83            [24] 1585 	mov	dph,r3
      004B97 E0               [24] 1586 	movx	a,@dptr
      004B98 22               [24] 1587 	ret
                                   1588 
                                   1589 	.area CSEG (CODE)
                                   1590 ; function ak820_outline_0055
      004B99                       1591 _ak820_outline_0055:
      004B99 74 01            [12] 1592 	mov	a,#0x01
      004B9B F0               [24] 1593 	movx	@dptr,a
      004B9C 8E 82            [24] 1594 	mov	dpl,r6
      004B9E 8F 83            [24] 1595 	mov	dph,r7
      004BA0 22               [24] 1596 	ret
                                   1597 
                                   1598 	.area CSEG (CODE)
                                   1599 ; function ak820_outline_0056
      004BA1                       1600 _ak820_outline_0056:
      004BA1 FC               [12] 1601 	mov	r4,a
      004BA2 8B 82            [24] 1602 	mov	dpl,r3
      004BA4 8C 83            [24] 1603 	mov	dph,r4
      004BA6 E0               [24] 1604 	movx	a,@dptr
      004BA7 FA               [12] 1605 	mov	r2,a
      004BA8 22               [24] 1606 	ret
                                   1607 
                                   1608 	.area CSEG (CODE)
                                   1609 ; function ak820_outline_0059
      004BA9                       1610 _ak820_outline_0059:
      004BA9 EE               [12] 1611 	mov	a,r6
      004BAA F0               [24] 1612 	movx	@dptr,a
      004BAB EF               [12] 1613 	mov	a,r7
      004BAC A3               [24] 1614 	inc	dptr
      004BAD F0               [24] 1615 	movx	@dptr,a
      004BAE 22               [24] 1616 	ret
                                   1617 
                                   1618 	.area CSEG (CODE)
                                   1619 ; function ak820_outline_0075
      004BAF                       1620 _ak820_outline_0075:
      004BAF 8D 82            [24] 1621 	mov	dpl,r5
      004BB1 8E 83            [24] 1622 	mov	dph,r6
      004BB3 E0               [24] 1623 	movx	a,@dptr
      004BB4 FC               [12] 1624 	mov	r4,a
      004BB5 22               [24] 1625 	ret
                                   1626 
                                   1627 	.area CSEG (CODE)
                                   1628 ; function ak820_outline_0078
      004BB6                       1629 _ak820_outline_0078:
      004BB6 24 B2            [12] 1630 	add	a,#_source_state
      004BB8 FC               [12] 1631 	mov	r4,a
      004BB9 E4               [12] 1632 	clr	a
      004BBA 34 05            [12] 1633 	addc	a,#(_source_state>>8)
      004BBC FD               [12] 1634 	mov	r5,a
      004BBD 8C 82            [24] 1635 	mov	dpl,r4
      004BBF 8D 83            [24] 1636 	mov	dph,r5
      004BC1 E0               [24] 1637 	movx	a,@dptr
      004BC2 FB               [12] 1638 	mov	r3,a
      004BC3 22               [24] 1639 	ret
                                   1640 
                                   1641 	.area CSEG (CODE)
                                   1642 ; function ak820_outline_0150
      004BC4                       1643 _ak820_outline_0150:
      004BC4 90 0D 9A         [24] 1644 	mov	dptr,#_pending
      004BC7 74 FF            [12] 1645 	mov	a,#0xff
      004BC9 F0               [24] 1646 	movx	@dptr,a
      004BCA 22               [24] 1647 	ret
