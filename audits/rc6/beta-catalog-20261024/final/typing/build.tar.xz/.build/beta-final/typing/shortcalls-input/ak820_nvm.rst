                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_nvm
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _eeprom_driver_erase
                                     12 	.globl _eeprom_read_byte
                                     13 	.globl _eeprom_driver_init
                                     14 	.globl _ak820_macro_init
                                     15 	.globl _ak820_flash_program_page
                                     16 	.globl _ak820_flash_program
                                     17 	.globl _ak820_flash_erase
                                     18 	.globl _ak820_flash_read
                                     19 	.globl _ak820_eeprom_update_block_xdata_PARM_3
                                     20 	.globl _ak820_eeprom_update_block_xdata_PARM_2
                                     21 	.globl _ak820_eeprom_write_block_xdata_PARM_3
                                     22 	.globl _ak820_eeprom_write_block_xdata_PARM_2
                                     23 	.globl _ak820_eeprom_read_block_xdata_PARM_3
                                     24 	.globl _ak820_eeprom_read_block_xdata_PARM_2
                                     25 	.globl _ak820_nvm_diagnostic
                                     26 	.globl _ak820_nvm_ok
                                     27 	.globl _ak820_nvm_schema_fault
                                     28 	.globl _ak820_nvm_flush
                                     29 	.globl _ak820_nvm_begin
                                     30 	.globl _ak820_nvm_end
                                     31 	.globl _ak820_eeprom_read_block_xdata
                                     32 	.globl _ak820_eeprom_write_block_xdata
                                     33 	.globl _ak820_eeprom_update_block_xdata
                                     34 ;--------------------------------------------------------
                                     35 ; special function registers
                                     36 ;--------------------------------------------------------
                                     37 	.area RSEG    (ABS,DATA)
      000000                         38 	.org 0x0000
                                     39 ;--------------------------------------------------------
                                     40 ; special function bits
                                     41 ;--------------------------------------------------------
                                     42 	.area RSEG    (ABS,DATA)
      000000                         43 	.org 0x0000
                                     44 ;--------------------------------------------------------
                                     45 ; overlayable register banks
                                     46 ;--------------------------------------------------------
                                     47 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         48 	.ds 8
                                     49 ;--------------------------------------------------------
                                     50 ; overlayable bit register bank
                                     51 ;--------------------------------------------------------
                                     52 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         53 bits:
      000026                         54 	.ds 1
                           008000    55 	b0 = bits[0]
                           008100    56 	b1 = bits[1]
                           008200    57 	b2 = bits[2]
                           008300    58 	b3 = bits[3]
                           008400    59 	b4 = bits[4]
                           008500    60 	b5 = bits[5]
                           008600    61 	b6 = bits[6]
                           008700    62 	b7 = bits[7]
                                     63 ;--------------------------------------------------------
                                     64 ; internal ram data
                                     65 ;--------------------------------------------------------
                                     66 	.area DSEG    (DATA)
      00000C                         67 _ak820_eeprom_write_block_xdata_sloc0_1_0:
      00000C                         68 	.ds 2
      00000E                         69 _ak820_eeprom_update_block_xdata_sloc0_1_0:
      00000E                         70 	.ds 2
      000010                         71 _ak820_eeprom_update_block_xdata_sloc1_1_0:
      000010                         72 	.ds 2
      000012                         73 _ak820_eeprom_update_block_xdata_sloc2_1_0:
      000012                         74 	.ds 3
                                     75 ;--------------------------------------------------------
                                     76 ; overlayable items in internal ram
                                     77 ;--------------------------------------------------------
                                     78 ;--------------------------------------------------------
                                     79 ; indirectly addressable internal ram data
                                     80 ;--------------------------------------------------------
                                     81 	.area ISEG    (DATA)
                                     82 ;--------------------------------------------------------
                                     83 ; absolute internal ram data
                                     84 ;--------------------------------------------------------
                                     85 	.area IABS    (ABS,DATA)
                                     86 	.area IABS    (ABS,DATA)
                                     87 ;--------------------------------------------------------
                                     88 ; bit data
                                     89 ;--------------------------------------------------------
                                     90 	.area BSEG    (BIT)
      000008                         91 _page_valid:
      000008                         92 	.ds 1
      000009                         93 _page_dirty:
      000009                         94 	.ds 1
      00000A                         95 _storage_failed:
      00000A                         96 	.ds 1
      00000B                         97 _ak820_nvm_ok_sloc0_1_0:
      00000B                         98 	.ds 1
      00000C                         99 _load_page_sloc0_1_0:
      00000C                        100 	.ds 1
                                    101 ;--------------------------------------------------------
                                    102 ; paged external ram data
                                    103 ;--------------------------------------------------------
                                    104 	.area PSEG    (PAG,XDATA)
                                    105 ;--------------------------------------------------------
                                    106 ; uninitialized external ram data
                                    107 ;--------------------------------------------------------
                                    108 	.area XSEG    (XDATA)
      000529                        109 _page_data:
      000529                        110 	.ds 64
      000569                        111 _cached_page:
      000569                        112 	.ds 1
      00056A                        113 _batch_depth:
      00056A                        114 	.ds 1
      00056B                        115 _first_failure_stage:
      00056B                        116 	.ds 1
      00056C                        117 _nvm_fail_stage_10000_20:
      00056C                        118 	.ds 1
      00056D                        119 _ak820_nvm_diagnostic_out_10000_23:
      00056D                        120 	.ds 2
      00056F                        121 _crc_byte_PARM_2:
      00056F                        122 	.ds 1
      000570                        123 _crc_byte_crc_10000_25:
      000570                        124 	.ds 2
      000572                        125 _page_crc_crc_10000_30:
      000572                        126 	.ds 2
      000574                        127 _write_page_address_10000_32:
      000574                        128 	.ds 2
      000576                        129 _journal_header_valid_header_10000_39:
      000576                        130 	.ds 2
      000578                        131 _recover_journal_header_10000_46:
      000578                        132 	.ds 9
      000581                        133 _ak820_nvm_flush_header_10000_62:
      000581                        134 	.ds 9
      00058A                        135 _ak820_nvm_flush_stage_10000_62:
      00058A                        136 	.ds 1
      00058B                        137 _load_page_page_10000_87:
      00058B                        138 	.ds 1
      00058C                        139 _read_offset_offset_10000_93:
      00058C                        140 	.ds 2
      00058E                        141 _eeprom_read_byte_addr_10000_97:
      00058E                        142 	.ds 3
      000591                        143 _ak820_eeprom_read_block_xdata_PARM_2:
      000591                        144 	.ds 3
      000594                        145 _ak820_eeprom_read_block_xdata_PARM_3:
      000594                        146 	.ds 2
      000596                        147 _ak820_eeprom_read_block_xdata_buf_10000_113:
      000596                        148 	.ds 2
      000598                        149 _ak820_eeprom_read_block_xdata_out_10000_114:
      000598                        150 	.ds 2
      00059A                        151 _ak820_eeprom_write_block_xdata_PARM_2:
      00059A                        152 	.ds 3
      00059D                        153 _ak820_eeprom_write_block_xdata_PARM_3:
      00059D                        154 	.ds 2
      00059F                        155 _ak820_eeprom_write_block_xdata_buf_10000_118:
      00059F                        156 	.ds 2
      0005A1                        157 _ak820_eeprom_update_block_xdata_PARM_2:
      0005A1                        158 	.ds 3
      0005A4                        159 _ak820_eeprom_update_block_xdata_PARM_3:
      0005A4                        160 	.ds 2
      0005A6                        161 _ak820_eeprom_update_block_xdata_buf_10000_127:
      0005A6                        162 	.ds 2
                                    163 ;--------------------------------------------------------
                                    164 ; absolute external ram data
                                    165 ;--------------------------------------------------------
                                    166 	.area XABS    (ABS,XDATA)
                                    167 ;--------------------------------------------------------
                                    168 ; initialized external ram data
                                    169 ;--------------------------------------------------------
                                    170 	.area XISEG   (XDATA)
                                    171 	.area HOME    (CODE)
                                    172 	.area GSINIT0 (CODE)
                                    173 	.area GSINIT1 (CODE)
                                    174 	.area GSINIT2 (CODE)
                                    175 	.area GSINIT3 (CODE)
                                    176 	.area GSINIT4 (CODE)
                                    177 	.area GSINIT5 (CODE)
                                    178 	.area GSINIT  (CODE)
                                    179 	.area GSFINAL (CODE)
                                    180 	.area CSEG    (CODE)
                                    181 ;--------------------------------------------------------
                                    182 ; global & static initialisations
                                    183 ;--------------------------------------------------------
                                    184 	.area HOME    (CODE)
                                    185 	.area GSINIT  (CODE)
                                    186 	.area GSFINAL (CODE)
                                    187 	.area GSINIT  (CODE)
                                    188 ;--------------------------------------------------------
                                    189 ; Home
                                    190 ;--------------------------------------------------------
                                    191 	.area HOME    (CODE)
                                    192 	.area HOME    (CODE)
                                    193 ;--------------------------------------------------------
                                    194 ; code
                                    195 ;--------------------------------------------------------
                                    196 	.area CSEG    (CODE)
                                    197 ;------------------------------------------------------------
                                    198 ;Allocation info for local variables in function 'nvm_fail'
                                    199 ;------------------------------------------------------------
                                    200 ;stage         Allocated with name '_nvm_fail_stage_10000_20'
                                    201 ;------------------------------------------------------------
                                    202 ;	keyboards/ajazz/ak820/ak820_nvm.c:31: static void nvm_fail(uint8_t stage) {
                                    203 ;	-----------------------------------------
                                    204 ;	 function nvm_fail
                                    205 ;	-----------------------------------------
      003DF8                        206 _nvm_fail:
                           000007   207 	ar7 = 0x07
                           000006   208 	ar6 = 0x06
                           000005   209 	ar5 = 0x05
                           000004   210 	ar4 = 0x04
                           000003   211 	ar3 = 0x03
                           000002   212 	ar2 = 0x02
                           000001   213 	ar1 = 0x01
                           000000   214 	ar0 = 0x00
      003DF8 E5 82            [12]  215 	mov	a,dpl
      003DFA 90 05 6C         [24]  216 	mov	dptr,#_nvm_fail_stage_10000_20
      003DFD F0               [24]  217 	movx	@dptr,a
                                    218 ;	keyboards/ajazz/ak820/ak820_nvm.c:32: if (!storage_failed) first_failure_stage = stage;
      003DFE 20 0A 08         [24]  219 	jb	_storage_failed,00102$
      003E01 90 05 6C         [24]  220 	mov	dptr,#_nvm_fail_stage_10000_20
      003E04 E0               [24]  221 	movx	a,@dptr
      003E05 90 05 6B         [24]  222 	mov	dptr,#_first_failure_stage
      003E08 F0               [24]  223 	movx	@dptr,a
      003E09                        224 00102$:
                                    225 ;	keyboards/ajazz/ak820/ak820_nvm.c:33: storage_failed = true;
                                    226 ;	assignBit
      003E09 D2 0A            [12]  227 	setb	_storage_failed
                                    228 ;	keyboards/ajazz/ak820/ak820_nvm.c:34: }
      003E0B 22               [24]  229 	ret
                                    230 ;------------------------------------------------------------
                                    231 ;Allocation info for local variables in function 'ak820_nvm_diagnostic'
                                    232 ;------------------------------------------------------------
                                    233 ;out           Allocated with name '_ak820_nvm_diagnostic_out_10000_23'
                                    234 ;------------------------------------------------------------
                                    235 ;	keyboards/ajazz/ak820/ak820_nvm.c:36: void ak820_nvm_diagnostic(uint8_t AK820_XDATA *out) {
                                    236 ;	-----------------------------------------
                                    237 ;	 function ak820_nvm_diagnostic
                                    238 ;	-----------------------------------------
      003E0C                        239 _ak820_nvm_diagnostic:
      003E0C 12 3A 8A         [24]  240 	lcall	_ak820_outline_0103
      003E0F 90 05 6D         [24]  241 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003E12 12 3A 8F         [24]  242 	lcall	_ak820_outline_0104
                                    243 ;	keyboards/ajazz/ak820/ak820_nvm.c:37: out[0] = storage_failed;
      003E15 90 05 6D         [24]  244 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003E18 12 3A 47         [24]  245 	lcall	_ak820_outline_0051
      003E1B A2 0A            [12]  246 	mov	c,_storage_failed
      003E1D E4               [12]  247 	clr	a
      003E1E 33               [12]  248 	rlc	a
      003E1F 12 45 CF         [24]  249 	lcall	_ak820_outline_0116
      003E22 12 45 AA         [24]  250 	lcall	_ak820_outline_0061
                                    251 ;	keyboards/ajazz/ak820/ak820_nvm.c:38: out[1] = page_valid;
      003E25 A3               [24]  252 	inc	dptr
      003E26 A2 08            [12]  253 	mov	c,_page_valid
      003E28 E4               [12]  254 	clr	a
      003E29 33               [12]  255 	rlc	a
      003E2A 12 45 7E         [24]  256 	lcall	_ak820_outline_0030
                                    257 ;	keyboards/ajazz/ak820/ak820_nvm.c:39: out[2] = page_dirty;
      003E2D A2 09            [12]  258 	mov	c,_page_dirty
      003E2F E4               [12]  259 	clr	a
      003E30 33               [12]  260 	rlc	a
      003E31 F0               [24]  261 	movx	@dptr,a
                                    262 ;	keyboards/ajazz/ak820/ak820_nvm.c:40: out[3] = batch_depth;
      003E32 74 03            [12]  263 	mov	a,#0x03
      003E34 12 45 FA         [24]  264 	lcall	_ak820_outline_0156
      003E37 90 05 6A         [24]  265 	mov	dptr,#_batch_depth
      003E3A E0               [24]  266 	movx	a,@dptr
      003E3B 12 3A 9B         [24]  267 	lcall	_ak820_outline_0117
      003E3E F0               [24]  268 	movx	@dptr,a
                                    269 ;	keyboards/ajazz/ak820/ak820_nvm.c:41: out[4] = (uint8_t)cached_page;
      003E3F 74 04            [12]  270 	mov	a,#0x04
      003E41 12 45 FA         [24]  271 	lcall	_ak820_outline_0156
      003E44 90 05 69         [24]  272 	mov	dptr,#_cached_page
      003E47 E0               [24]  273 	movx	a,@dptr
      003E48 12 3A 9B         [24]  274 	lcall	_ak820_outline_0117
      003E4B F0               [24]  275 	movx	@dptr,a
                                    276 ;	keyboards/ajazz/ak820/ak820_nvm.c:42: out[5] = (uint8_t)(cached_page >> 8);
      003E4C 12 45 74         [24]  277 	lcall	_ak820_outline_0011
      003E4F E4               [12]  278 	clr	a
      003E50 F0               [24]  279 	movx	@dptr,a
                                    280 ;	keyboards/ajazz/ak820/ak820_nvm.c:43: out[6] = first_failure_stage;
      003E51 74 06            [12]  281 	mov	a,#0x06
      003E53 12 45 DF         [24]  282 	lcall	_ak820_outline_0134
      003E56 90 05 6B         [24]  283 	mov	dptr,#_first_failure_stage
      003E59 E0               [24]  284 	movx	a,@dptr
      003E5A 12 45 CF         [24]  285 	lcall	_ak820_outline_0116
      003E5D F0               [24]  286 	movx	@dptr,a
                                    287 ;	keyboards/ajazz/ak820/ak820_nvm.c:44: }
      003E5E 22               [24]  288 	ret
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'crc_byte'
                                    291 ;------------------------------------------------------------
                                    292 ;value         Allocated with name '_crc_byte_PARM_2'
                                    293 ;crc           Allocated with name '_crc_byte_crc_10000_25'
                                    294 ;bit           Allocated with name '_crc_byte_bit_10000_26'
                                    295 ;------------------------------------------------------------
                                    296 ;	keyboards/ajazz/ak820/ak820_nvm.c:46: static uint16_t crc_byte(uint16_t crc, uint8_t value) {
                                    297 ;	-----------------------------------------
                                    298 ;	 function crc_byte
                                    299 ;	-----------------------------------------
      003E5F                        300 _crc_byte:
      003E5F 12 3A 8A         [24]  301 	lcall	_ak820_outline_0103
      003E62 90 05 70         [24]  302 	mov	dptr,#_crc_byte_crc_10000_25
      003E65 12 3A 8F         [24]  303 	lcall	_ak820_outline_0104
                                    304 ;	keyboards/ajazz/ak820/ak820_nvm.c:48: crc ^= (uint16_t)value << 8;
      003E68 90 05 6F         [24]  305 	mov	dptr,#_crc_byte_PARM_2
      003E6B E0               [24]  306 	movx	a,@dptr
      003E6C FF               [12]  307 	mov	r7,a
      003E6D 7E 00            [12]  308 	mov	r6,#0x00
      003E6F 90 05 70         [24]  309 	mov	dptr,#_crc_byte_crc_10000_25
      003E72 E0               [24]  310 	movx	a,@dptr
      003E73 6E               [12]  311 	xrl	a,r6
      003E74 F0               [24]  312 	movx	@dptr,a
      003E75 A3               [24]  313 	inc	dptr
      003E76 E0               [24]  314 	movx	a,@dptr
      003E77 6F               [12]  315 	xrl	a,r7
      003E78 F0               [24]  316 	movx	@dptr,a
                                    317 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003E79 7F 00            [12]  318 	mov	r7,#0x00
      003E7B                        319 00102$:
                                    320 ;	keyboards/ajazz/ak820/ak820_nvm.c:50: crc = (crc & 0x8000u) ? (uint16_t)((crc << 1) ^ 0x1021u) : (uint16_t)(crc << 1);
      003E7B 90 05 70         [24]  321 	mov	dptr,#_crc_byte_crc_10000_25
      003E7E 12 45 BD         [24]  322 	lcall	_ak820_outline_0093
      003E81 30 E7 0E         [24]  323 	jnb	acc.7,00106$
      003E84 ED               [12]  324 	mov	a,r5
      003E85 2D               [12]  325 	add	a,r5
      003E86 FB               [12]  326 	mov	r3,a
      003E87 EE               [12]  327 	mov	a,r6
      003E88 33               [12]  328 	rlc	a
      003E89 FC               [12]  329 	mov	r4,a
      003E8A 63 03 21         [24]  330 	xrl	ar3,#0x21
      003E8D 63 04 10         [24]  331 	xrl	ar4,#0x10
      003E90 80 06            [24]  332 	sjmp	00107$
      003E92                        333 00106$:
      003E92 ED               [12]  334 	mov	a,r5
      003E93 2D               [12]  335 	add	a,r5
      003E94 FB               [12]  336 	mov	r3,a
      003E95 EE               [12]  337 	mov	a,r6
      003E96 33               [12]  338 	rlc	a
      003E97 FC               [12]  339 	mov	r4,a
      003E98                        340 00107$:
      003E98 90 05 70         [24]  341 	mov	dptr,#_crc_byte_crc_10000_25
      003E9B 12 3A 72         [24]  342 	lcall	_ak820_outline_0077
                                    343 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003E9E 0F               [12]  344 	inc	r7
      003E9F BF 08 D9         [24]  345 	cjne	r7,#0x08,00102$
                                    346 ;	keyboards/ajazz/ak820/ak820_nvm.c:52: return crc;
      003EA2 12 36 42         [24]  347 	lcall	_ak820_outline_0122
                                    348 ;	keyboards/ajazz/ak820/ak820_nvm.c:53: }
      003EA5 22               [24]  349 	ret
                                    350 ;------------------------------------------------------------
                                    351 ;Allocation info for local variables in function 'page_crc'
                                    352 ;------------------------------------------------------------
                                    353 ;crc           Allocated with name '_page_crc_crc_10000_30'
                                    354 ;i             Allocated with name '_page_crc_i_10000_30'
                                    355 ;------------------------------------------------------------
                                    356 ;	keyboards/ajazz/ak820/ak820_nvm.c:55: static uint16_t page_crc(void) {
                                    357 ;	-----------------------------------------
                                    358 ;	 function page_crc
                                    359 ;	-----------------------------------------
      003EA6                        360 _page_crc:
                                    361 ;	keyboards/ajazz/ak820/ak820_nvm.c:56: uint16_t crc = 0xFFFFu;
      003EA6 90 05 72         [24]  362 	mov	dptr,#_page_crc_crc_10000_30
      003EA9 74 FF            [12]  363 	mov	a,#0xff
      003EAB F0               [24]  364 	movx	@dptr,a
      003EAC A3               [24]  365 	inc	dptr
      003EAD F0               [24]  366 	movx	@dptr,a
                                    367 ;	keyboards/ajazz/ak820/ak820_nvm.c:58: for (i = 0; i != AK820_FLASH_PAGE; ++i) crc = crc_byte(crc, page_data[i]);
      003EAE 7F 00            [12]  368 	mov	r7,#0x00
      003EB0                        369 00102$:
      003EB0 90 05 72         [24]  370 	mov	dptr,#_page_crc_crc_10000_30
      003EB3 12 45 BD         [24]  371 	lcall	_ak820_outline_0093
      003EB6 12 45 C3         [24]  372 	lcall	_ak820_outline_0101
      003EB9 90 05 6F         [24]  373 	mov	dptr,#_crc_byte_PARM_2
      003EBC F0               [24]  374 	movx	@dptr,a
      003EBD 12 3A AB         [24]  375 	lcall	_ak820_outline_0132
      003EC0 C0 07            [24]  376 	push	ar7
      003EC2 12 3E 5F         [24]  377 	lcall	_crc_byte
      003EC5 AD 82            [24]  378 	mov	r5, dpl
      003EC7 AE 83            [24]  379 	mov	r6, dph
      003EC9 D0 07            [24]  380 	pop	ar7
      003ECB 90 05 72         [24]  381 	mov	dptr,#_page_crc_crc_10000_30
      003ECE 12 46 00         [24]  382 	lcall	_ak820_outline_0157
      003ED1 0F               [12]  383 	inc	r7
      003ED2 BF 40 DB         [24]  384 	cjne	r7,#0x40,00102$
                                    385 ;	keyboards/ajazz/ak820/ak820_nvm.c:59: return crc;
      003ED5 12 3A AB         [24]  386 	lcall	_ak820_outline_0132
                                    387 ;	keyboards/ajazz/ak820/ak820_nvm.c:60: }
      003ED8 22               [24]  388 	ret
                                    389 ;------------------------------------------------------------
                                    390 ;Allocation info for local variables in function 'write_page'
                                    391 ;------------------------------------------------------------
                                    392 ;address       Allocated with name '_write_page_address_10000_32'
                                    393 ;i             Allocated with name '_write_page_i_10000_33'
                                    394 ;------------------------------------------------------------
                                    395 ;	keyboards/ajazz/ak820/ak820_nvm.c:62: static bool write_page(uint16_t address) {
                                    396 ;	-----------------------------------------
                                    397 ;	 function write_page
                                    398 ;	-----------------------------------------
      003ED9                        399 _write_page:
      003ED9 12 3A 8A         [24]  400 	lcall	_ak820_outline_0103
      003EDC 90 05 74         [24]  401 	mov	dptr,#_write_page_address_10000_32
      003EDF 12 3A 8F         [24]  402 	lcall	_ak820_outline_0104
                                    403 ;	keyboards/ajazz/ak820/ak820_nvm.c:64: if (!ak820_flash_erase(address)) return false;
      003EE2 90 05 74         [24]  404 	mov	dptr,#_write_page_address_10000_32
      003EE5 12 39 E7         [24]  405 	lcall	_ak820_outline_0004
      003EE8 C0 07            [24]  406 	push	ar7
      003EEA C0 06            [24]  407 	push	ar6
      003EEC 12 3C 07         [24]  408 	lcall	_ak820_flash_erase
      003EEF E5 82            [12]  409 	mov	a, dpl
      003EF1 D0 06            [24]  410 	pop	ar6
      003EF3 D0 07            [24]  411 	pop	ar7
      003EF5 70 03            [24]  412 	jnz	00102$
      003EF7 F5 82            [12]  413 	mov	dpl,a
      003EF9 22               [24]  414 	ret
      003EFA                        415 00102$:
                                    416 ;	keyboards/ajazz/ak820/ak820_nvm.c:65: if (!ak820_flash_program_page(address, page_data)) return false;
      003EFA 90 05 05         [24]  417 	mov	dptr,#_ak820_flash_program_page_PARM_2
      003EFD 74 29            [12]  418 	mov	a,#_page_data
      003EFF F0               [24]  419 	movx	@dptr,a
      003F00 74 05            [12]  420 	mov	a,#(_page_data >> 8)
      003F02 A3               [24]  421 	inc	dptr
      003F03 12 45 AA         [24]  422 	lcall	_ak820_outline_0061
      003F06 12 3D 1B         [24]  423 	lcall	_ak820_flash_program_page
      003F09 E5 82            [12]  424 	mov	a, dpl
      003F0B 70 03            [24]  425 	jnz	00120$
      003F0D F5 82            [12]  426 	mov	dpl,a
                                    427 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003F0F 22               [24]  428 	ret
      003F10                        429 00120$:
      003F10 7F 00            [12]  430 	mov	r7,#0x00
      003F12                        431 00108$:
                                    432 ;	keyboards/ajazz/ak820/ak820_nvm.c:67: if (ak820_flash_read(address + i) != page_data[i]) return false;
      003F12 8F 05            [24]  433 	mov	ar5,r7
      003F14 7E 00            [12]  434 	mov	r6,#0x00
      003F16 90 05 74         [24]  435 	mov	dptr,#_write_page_address_10000_32
      003F19 12 3A A0         [24]  436 	lcall	_ak820_outline_0121
      003F1C ED               [12]  437 	mov	a,r5
      003F1D 2B               [12]  438 	add	a, r3
      003F1E FB               [12]  439 	mov	r3,a
      003F1F EE               [12]  440 	mov	a,r6
      003F20 3C               [12]  441 	addc	a, r4
      003F21 FC               [12]  442 	mov	r4,a
      003F22 12 36 42         [24]  443 	lcall	_ak820_outline_0122
      003F25 12 3A FA         [24]  444 	lcall	_ak820_flash_read
      003F28 AE 82            [24]  445 	mov	r6, dpl
      003F2A 12 45 C3         [24]  446 	lcall	_ak820_outline_0101
      003F2D FD               [12]  447 	mov	r5,a
      003F2E EE               [12]  448 	mov	a,r6
      003F2F B5 05 02         [24]  449 	cjne	a,ar5,00149$
      003F32 80 04            [24]  450 	sjmp	00109$
      003F34                        451 00149$:
      003F34 75 82 00         [24]  452 	mov	dpl, #0x00
      003F37 22               [24]  453 	ret
      003F38                        454 00109$:
                                    455 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003F38 0F               [12]  456 	inc	r7
      003F39 BF 40 D6         [24]  457 	cjne	r7,#0x40,00108$
                                    458 ;	keyboards/ajazz/ak820/ak820_nvm.c:69: return true;
      003F3C 75 82 01         [24]  459 	mov	dpl, #0x01
                                    460 ;	keyboards/ajazz/ak820/ak820_nvm.c:70: }
      003F3F 22               [24]  461 	ret
                                    462 ;------------------------------------------------------------
                                    463 ;Allocation info for local variables in function 'journal_header_valid'
                                    464 ;------------------------------------------------------------
                                    465 ;header        Allocated with name '_journal_header_valid_header_10000_39'
                                    466 ;i             Allocated with name '_journal_header_valid_i_10000_40'
                                    467 ;------------------------------------------------------------
                                    468 ;	keyboards/ajazz/ak820/ak820_nvm.c:72: static bool journal_header_valid(uint8_t AK820_XDATA *header) {
                                    469 ;	-----------------------------------------
                                    470 ;	 function journal_header_valid
                                    471 ;	-----------------------------------------
      003F40                        472 _journal_header_valid:
      003F40 12 3A 8A         [24]  473 	lcall	_ak820_outline_0103
      003F43 90 05 76         [24]  474 	mov	dptr,#_journal_header_valid_header_10000_39
      003F46 12 3A 8F         [24]  475 	lcall	_ak820_outline_0104
                                    476 ;	keyboards/ajazz/ak820/ak820_nvm.c:74: if (header[0] != 0xA5u) return false;
      003F49 90 05 76         [24]  477 	mov	dptr,#_journal_header_valid_header_10000_39
      003F4C 12 39 E7         [24]  478 	lcall	_ak820_outline_0004
      003F4F E0               [24]  479 	movx	a,@dptr
      003F50 FD               [12]  480 	mov	r5,a
      003F51 BD A5 02         [24]  481 	cjne	r5,#0xa5,00138$
      003F54 80 04            [24]  482 	sjmp	00116$
      003F56                        483 00138$:
      003F56 75 82 00         [24]  484 	mov	dpl, #0x00
                                    485 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      003F59 22               [24]  486 	ret
      003F5A                        487 00116$:
      003F5A 7D 01            [12]  488 	mov	r5,#0x01
      003F5C                        489 00106$:
                                    490 ;	keyboards/ajazz/ak820/ak820_nvm.c:76: if ((uint8_t)(header[i] ^ header[i + 4]) != 0xFFu) return false;
      003F5C ED               [12]  491 	mov	a,r5
      003F5D 12 3A 2E         [24]  492 	lcall	_ak820_outline_0017
      003F60 FC               [12]  493 	mov	r4,a
      003F61 8D 02            [24]  494 	mov	ar2,r5
      003F63 7B 00            [12]  495 	mov	r3,#0x00
      003F65 74 04            [12]  496 	mov	a,#0x04
      003F67 2A               [12]  497 	add	a, r2
      003F68 FA               [12]  498 	mov	r2,a
      003F69 E4               [12]  499 	clr	a
      003F6A 3B               [12]  500 	addc	a, r3
      003F6B FB               [12]  501 	mov	r3,a
      003F6C EA               [12]  502 	mov	a,r2
      003F6D 2E               [12]  503 	add	a, r6
      003F6E F5 82            [12]  504 	mov	dpl,a
      003F70 EB               [12]  505 	mov	a,r3
      003F71 3F               [12]  506 	addc	a, r7
      003F72 F5 83            [12]  507 	mov	dph,a
      003F74 E0               [24]  508 	movx	a,@dptr
      003F75 62 04            [12]  509 	xrl	ar4,a
      003F77 BC FF 02         [24]  510 	cjne	r4,#0xff,00139$
      003F7A 80 04            [24]  511 	sjmp	00107$
      003F7C                        512 00139$:
      003F7C 75 82 00         [24]  513 	mov	dpl, #0x00
      003F7F 22               [24]  514 	ret
      003F80                        515 00107$:
                                    516 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      003F80 0D               [12]  517 	inc	r5
      003F81 BD 05 D8         [24]  518 	cjne	r5,#0x05,00106$
                                    519 ;	keyboards/ajazz/ak820/ak820_nvm.c:78: return true;
      003F84 75 82 01         [24]  520 	mov	dpl, #0x01
                                    521 ;	keyboards/ajazz/ak820/ak820_nvm.c:79: }
      003F87 22               [24]  522 	ret
                                    523 ;------------------------------------------------------------
                                    524 ;Allocation info for local variables in function 'recover_journal'
                                    525 ;------------------------------------------------------------
                                    526 ;header        Allocated with name '_recover_journal_header_10000_46'
                                    527 ;i             Allocated with name '_recover_journal_i_10000_46'
                                    528 ;page          Allocated with name '_recover_journal_page_10000_46'
                                    529 ;crc           Allocated with name '_recover_journal_crc_10000_46'
                                    530 ;------------------------------------------------------------
                                    531 ;	keyboards/ajazz/ak820/ak820_nvm.c:81: static void recover_journal(void) {
                                    532 ;	-----------------------------------------
                                    533 ;	 function recover_journal
                                    534 ;	-----------------------------------------
      003F88                        535 _recover_journal:
                                    536 ;	keyboards/ajazz/ak820/ak820_nvm.c:85: for (i = 0; i != sizeof(header); ++i) header[i] = ak820_flash_read(AK820_JOURNAL_HEADER + i);
      003F88 7F 00            [12]  537 	mov	r7,#0x00
      003F8A                        538 00115$:
      003F8A EF               [12]  539 	mov	a,r7
      003F8B 24 78            [12]  540 	add	a, #_recover_journal_header_10000_46
      003F8D FD               [12]  541 	mov	r5,a
      003F8E E4               [12]  542 	clr	a
      003F8F 34 05            [12]  543 	addc	a, #(_recover_journal_header_10000_46 >> 8)
      003F91 FE               [12]  544 	mov	r6,a
      003F92 8F 04            [24]  545 	mov	ar4,r7
      003F94 7B 00            [12]  546 	mov	r3,#0x00
      003F96 74 40            [12]  547 	mov	a,#0x40
      003F98 2C               [12]  548 	add	a, r4
      003F99 FC               [12]  549 	mov	r4,a
      003F9A 74 EF            [12]  550 	mov	a,#0xef
      003F9C 3B               [12]  551 	addc	a, r3
      003F9D FB               [12]  552 	mov	r3,a
      003F9E 12 46 0B         [24]  553 	lcall	_ak820_outline_0180
      003FA1 12 3A FA         [24]  554 	lcall	_ak820_flash_read
      003FA4 AC 82            [24]  555 	mov	r4, dpl
      003FA6 12 45 B0         [24]  556 	lcall	_ak820_outline_0065
      003FA9 0F               [12]  557 	inc	r7
      003FAA BF 09 DD         [24]  558 	cjne	r7,#0x09,00115$
                                    559 ;	keyboards/ajazz/ak820/ak820_nvm.c:88: if (!journal_header_valid(header)) return;
      003FAD 90 05 78         [24]  560 	mov	dptr,#_recover_journal_header_10000_46
      003FB0 12 3F 40         [24]  561 	lcall	_journal_header_valid
      003FB3 E5 82            [12]  562 	mov	a, dpl
      003FB5 70 01            [24]  563 	jnz	00103$
      003FB7 22               [24]  564 	ret
      003FB8                        565 00103$:
                                    566 ;	keyboards/ajazz/ak820/ak820_nvm.c:89: page = (uint16_t)header[1] | ((uint16_t)header[2] << 8);
      003FB8 90 05 79         [24]  567 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0001)
      003FBB E0               [24]  568 	movx	a,@dptr
      003FBC FF               [12]  569 	mov	r7,a
      003FBD 7E 00            [12]  570 	mov	r6,#0x00
      003FBF 90 05 7A         [24]  571 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0002)
      003FC2 E0               [24]  572 	movx	a,@dptr
      003FC3 FC               [12]  573 	mov	r4,a
      003FC4 E4               [12]  574 	clr	a
      003FC5 42 07            [12]  575 	orl	ar7,a
      003FC7 EC               [12]  576 	mov	a,r4
      003FC8 42 06            [12]  577 	orl	ar6,a
                                    578 ;	keyboards/ajazz/ak820/ak820_nvm.c:90: crc = (uint16_t)header[3] | ((uint16_t)header[4] << 8);
      003FCA 90 05 7B         [24]  579 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0003)
      003FCD E0               [24]  580 	movx	a,@dptr
      003FCE FD               [12]  581 	mov	r5,a
      003FCF 7C 00            [12]  582 	mov	r4,#0x00
      003FD1 90 05 7C         [24]  583 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0004)
      003FD4 E0               [24]  584 	movx	a,@dptr
      003FD5 FA               [12]  585 	mov	r2,a
      003FD6 E4               [12]  586 	clr	a
      003FD7 12 45 E5         [24]  587 	lcall	_ak820_outline_0139
                                    588 ;	keyboards/ajazz/ak820/ak820_nvm.c:91: if (page >= AK820_NVM_SIZE / AK820_FLASH_PAGE) {
      003FDA C3               [12]  589 	clr	c
      003FDB EF               [12]  590 	mov	a,r7
      003FDC 94 A0            [12]  591 	subb	a,#0xa0
      003FDE EE               [12]  592 	mov	a,r6
      003FDF 94 00            [12]  593 	subb	a,#0x00
      003FE1 40 06            [24]  594 	jc	00134$
                                    595 ;	keyboards/ajazz/ak820/ak820_nvm.c:92: nvm_fail(AK820_NVM_FAULT_RECOVERY_PAGE);
      003FE3 75 82 01         [24]  596 	mov	dpl, #0x01
                                    597 ;	keyboards/ajazz/ak820/ak820_nvm.c:93: return;
      003FE6 02 3D F8         [24]  598 	ljmp	_nvm_fail
                                    599 ;	keyboards/ajazz/ak820/ak820_nvm.c:95: for (i = 0; i != AK820_FLASH_PAGE; ++i) page_data[i] = ak820_flash_read(AK820_JOURNAL_DATA + i);
      003FE9                        600 00134$:
      003FE9 7B 00            [12]  601 	mov	r3,#0x00
      003FEB                        602 00117$:
      003FEB C0 05            [24]  603 	push	ar5
      003FED C0 04            [24]  604 	push	ar4
      003FEF EB               [12]  605 	mov	a,r3
      003FF0 24 29            [12]  606 	add	a, #_page_data
      003FF2 F9               [12]  607 	mov	r1,a
      003FF3 E4               [12]  608 	clr	a
      003FF4 34 05            [12]  609 	addc	a, #(_page_data >> 8)
      003FF6 FA               [12]  610 	mov	r2,a
      003FF7 8B 00            [24]  611 	mov	ar0,r3
      003FF9 7D 00            [12]  612 	mov	r5,#0x00
      003FFB 74 EF            [12]  613 	mov	a,#0xef
      003FFD 2D               [12]  614 	add	a, r5
      003FFE FD               [12]  615 	mov	r5,a
      003FFF 88 82            [24]  616 	mov	dpl, r0
      004001 8D 83            [24]  617 	mov	dph, r5
      004003 12 3A FA         [24]  618 	lcall	_ak820_flash_read
      004006 AD 82            [24]  619 	mov	r5, dpl
      004008 12 46 06         [24]  620 	lcall	_ak820_outline_0179
      00400B ED               [12]  621 	mov	a,r5
      00400C F0               [24]  622 	movx	@dptr,a
      00400D 0B               [12]  623 	inc	r3
      00400E BB 40 02         [24]  624 	cjne	r3,#0x40,00190$
      004011 80 06            [24]  625 	sjmp	00191$
      004013                        626 00190$:
      004013 D0 04            [24]  627 	pop	ar4
      004015 D0 05            [24]  628 	pop	ar5
      004017 80 D2            [24]  629 	sjmp	00117$
      004019                        630 00191$:
      004019 D0 04            [24]  631 	pop	ar4
      00401B D0 05            [24]  632 	pop	ar5
                                    633 ;	keyboards/ajazz/ak820/ak820_nvm.c:96: if (page_crc() != crc) nvm_fail(AK820_NVM_FAULT_RECOVERY_CRC);
      00401D C0 07            [24]  634 	push	ar7
      00401F C0 06            [24]  635 	push	ar6
      004021 C0 05            [24]  636 	push	ar5
      004023 C0 04            [24]  637 	push	ar4
      004025 12 3E A6         [24]  638 	lcall	_page_crc
      004028 AA 82            [24]  639 	mov	r2, dpl
      00402A AB 83            [24]  640 	mov	r3, dph
      00402C D0 04            [24]  641 	pop	ar4
      00402E D0 05            [24]  642 	pop	ar5
      004030 D0 06            [24]  643 	pop	ar6
      004032 D0 07            [24]  644 	pop	ar7
      004034 EA               [12]  645 	mov	a,r2
      004035 B5 05 06         [24]  646 	cjne	a,ar5,00192$
      004038 EB               [12]  647 	mov	a,r3
      004039 B5 04 02         [24]  648 	cjne	a,ar4,00192$
      00403C 80 06            [24]  649 	sjmp	00113$
      00403E                        650 00192$:
      00403E 75 82 02         [24]  651 	mov	dpl, #0x02
      004041 02 3D F8         [24]  652 	ljmp	_nvm_fail
      004044                        653 00113$:
                                    654 ;	keyboards/ajazz/ak820/ak820_nvm.c:97: else if (!write_page(AK820_NVM_BASE + page * AK820_FLASH_PAGE)) nvm_fail(AK820_NVM_FAULT_RECOVERY_WRITE);
      004044 EE               [12]  655 	mov	a,r6
      004045 54 03            [12]  656 	anl	a,#0x03
      004047 A2 E0            [12]  657 	mov	c,acc.0
      004049 CF               [12]  658 	xch	a,r7
      00404A 13               [12]  659 	rrc	a
      00404B CF               [12]  660 	xch	a,r7
      00404C 13               [12]  661 	rrc	a
      00404D A2 E0            [12]  662 	mov	c,acc.0
      00404F CF               [12]  663 	xch	a,r7
      004050 13               [12]  664 	rrc	a
      004051 CF               [12]  665 	xch	a,r7
      004052 13               [12]  666 	rrc	a
      004053 CF               [12]  667 	xch	a,r7
      004054 24 C7            [12]  668 	add	a,#0xc7
      004056 FE               [12]  669 	mov	r6,a
      004057 12 45 F5         [24]  670 	lcall	_ak820_outline_0153
      00405A 12 3E D9         [24]  671 	lcall	_write_page
      00405D E5 82            [12]  672 	mov	a, dpl
      00405F 70 06            [24]  673 	jnz	00110$
      004061 75 82 03         [24]  674 	mov	dpl, #0x03
      004064 02 3D F8         [24]  675 	ljmp	_nvm_fail
      004067                        676 00110$:
                                    677 ;	keyboards/ajazz/ak820/ak820_nvm.c:98: else if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) nvm_fail(AK820_NVM_FAULT_RECOVERY_CLEANUP);
      004067 90 EF 40         [24]  678 	mov	dptr,#0xef40
      00406A 12 3C 07         [24]  679 	lcall	_ak820_flash_erase
      00406D E5 82            [12]  680 	mov	a, dpl
      00406F 70 06            [24]  681 	jnz	00119$
      004071 75 82 04         [24]  682 	mov	dpl, #0x04
                                    683 ;	keyboards/ajazz/ak820/ak820_nvm.c:99: }
      004074 02 3D F8         [24]  684 	ljmp	_nvm_fail
      004077                        685 00119$:
      004077 22               [24]  686 	ret
                                    687 ;------------------------------------------------------------
                                    688 ;Allocation info for local variables in function 'eeprom_driver_init'
                                    689 ;------------------------------------------------------------
                                    690 ;	keyboards/ajazz/ak820/ak820_nvm.c:101: void eeprom_driver_init(void) {
                                    691 ;	-----------------------------------------
                                    692 ;	 function eeprom_driver_init
                                    693 ;	-----------------------------------------
      004078                        694 _eeprom_driver_init:
                                    695 ;	keyboards/ajazz/ak820/ak820_nvm.c:102: storage_failed = false;
                                    696 ;	assignBit
      004078 C2 0A            [12]  697 	clr	_storage_failed
                                    698 ;	keyboards/ajazz/ak820/ak820_nvm.c:103: first_failure_stage = AK820_NVM_FAULT_NONE;
      00407A 90 05 6B         [24]  699 	mov	dptr,#_first_failure_stage
      00407D E4               [12]  700 	clr	a
      00407E F0               [24]  701 	movx	@dptr,a
                                    702 ;	keyboards/ajazz/ak820/ak820_nvm.c:104: page_valid = page_dirty = false;
                                    703 ;	assignBit
      00407F C2 09            [12]  704 	clr	_page_dirty
                                    705 ;	assignBit
      004081 C2 08            [12]  706 	clr	_page_valid
                                    707 ;	keyboards/ajazz/ak820/ak820_nvm.c:105: batch_depth = 0;
      004083 90 05 6A         [24]  708 	mov	dptr,#_batch_depth
      004086 E4               [12]  709 	clr	a
      004087 F0               [24]  710 	movx	@dptr,a
                                    711 ;	keyboards/ajazz/ak820/ak820_nvm.c:106: recover_journal();
      004088 12 3F 88         [24]  712 	lcall	_recover_journal
                                    713 ;	keyboards/ajazz/ak820/ak820_nvm.c:108: ak820_macro_init();
                                    714 ;	keyboards/ajazz/ak820/ak820_nvm.c:110: }
      00408B 02 2A 6B         [24]  715 	ljmp	_ak820_macro_init
                                    716 ;------------------------------------------------------------
                                    717 ;Allocation info for local variables in function 'ak820_nvm_ok'
                                    718 ;------------------------------------------------------------
                                    719 ;	keyboards/ajazz/ak820/ak820_nvm.c:112: bool ak820_nvm_ok(void) { return !storage_failed; }
                                    720 ;	-----------------------------------------
                                    721 ;	 function ak820_nvm_ok
                                    722 ;	-----------------------------------------
      00408E                        723 _ak820_nvm_ok:
      00408E A2 0A            [12]  724 	mov	c,_storage_failed
      004090 B3               [12]  725 	cpl	c
      004091 92 0B            [24]  726 	mov  _ak820_nvm_ok_sloc0_1_0,c
      004093 12 3A C7         [24]  727 	lcall	_ak820_outline_0167
      004096 22               [24]  728 	ret
                                    729 ;------------------------------------------------------------
                                    730 ;Allocation info for local variables in function 'ak820_nvm_schema_fault'
                                    731 ;------------------------------------------------------------
                                    732 ;	keyboards/ajazz/ak820/ak820_nvm.c:114: void ak820_nvm_schema_fault(void) { nvm_fail(AK820_NVM_FAULT_SCHEMA); }
                                    733 ;	-----------------------------------------
                                    734 ;	 function ak820_nvm_schema_fault
                                    735 ;	-----------------------------------------
      004097                        736 _ak820_nvm_schema_fault:
      004097 75 82 10         [24]  737 	mov	dpl, #0x10
      00409A 02 3D F8         [24]  738 	ljmp	_nvm_fail
                                    739 ;------------------------------------------------------------
                                    740 ;Allocation info for local variables in function 'ak820_nvm_flush'
                                    741 ;------------------------------------------------------------
                                    742 ;header        Allocated with name '_ak820_nvm_flush_header_10000_62'
                                    743 ;crc           Allocated with name '_ak820_nvm_flush_crc_10000_62'
                                    744 ;i             Allocated with name '_ak820_nvm_flush_i_10000_62'
                                    745 ;stage         Allocated with name '_ak820_nvm_flush_stage_10000_62'
                                    746 ;------------------------------------------------------------
                                    747 ;	keyboards/ajazz/ak820/ak820_nvm.c:116: void ak820_nvm_flush(void) {
                                    748 ;	-----------------------------------------
                                    749 ;	 function ak820_nvm_flush
                                    750 ;	-----------------------------------------
      00409D                        751 _ak820_nvm_flush:
                                    752 ;	keyboards/ajazz/ak820/ak820_nvm.c:121: if (!page_dirty || storage_failed) return;
      00409D 30 09 03         [24]  753 	jnb	_page_dirty,00101$
      0040A0 30 0A 01         [24]  754 	jnb	_storage_failed,00102$
      0040A3                        755 00101$:
      0040A3 22               [24]  756 	ret
      0040A4                        757 00102$:
                                    758 ;	keyboards/ajazz/ak820/ak820_nvm.c:122: crc = page_crc();
      0040A4 12 3E A6         [24]  759 	lcall	_page_crc
      0040A7 12 45 DA         [24]  760 	lcall	_ak820_outline_0131
                                    761 ;	keyboards/ajazz/ak820/ak820_nvm.c:123: header[0] = 0xA5u;
      0040AA 90 05 81         [24]  762 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      0040AD 74 A5            [12]  763 	mov	a,#0xa5
      0040AF F0               [24]  764 	movx	@dptr,a
                                    765 ;	keyboards/ajazz/ak820/ak820_nvm.c:124: header[1] = (uint8_t)cached_page;
      0040B0 90 05 69         [24]  766 	mov	dptr,#_cached_page
      0040B3 E0               [24]  767 	movx	a,@dptr
      0040B4 90 05 82         [24]  768 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0001)
      0040B7 F0               [24]  769 	movx	@dptr,a
                                    770 ;	keyboards/ajazz/ak820/ak820_nvm.c:125: header[2] = (uint8_t)(cached_page >> 8);
      0040B8 90 05 83         [24]  771 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0002)
      0040BB E4               [12]  772 	clr	a
      0040BC F0               [24]  773 	movx	@dptr,a
                                    774 ;	keyboards/ajazz/ak820/ak820_nvm.c:126: header[3] = (uint8_t)crc;
      0040BD 8E 05            [24]  775 	mov	ar5,r6
      0040BF 90 05 84         [24]  776 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0003)
      0040C2 ED               [12]  777 	mov	a,r5
      0040C3 F0               [24]  778 	movx	@dptr,a
                                    779 ;	keyboards/ajazz/ak820/ak820_nvm.c:127: header[4] = (uint8_t)(crc >> 8);
      0040C4 8F 06            [24]  780 	mov	ar6,r7
      0040C6 90 05 85         [24]  781 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0004)
      0040C9 EE               [12]  782 	mov	a,r6
      0040CA F0               [24]  783 	movx	@dptr,a
                                    784 ;	keyboards/ajazz/ak820/ak820_nvm.c:128: for (i = 1; i != 5; ++i) header[i + 4] = (uint8_t)~header[i];
      0040CB 7F 01            [12]  785 	mov	r7,#0x01
      0040CD                        786 00128$:
      0040CD 8F 06            [24]  787 	mov	ar6,r7
      0040CF EE               [12]  788 	mov	a,r6
      0040D0 24 04            [12]  789 	add	a,#0x04
      0040D2 FE               [12]  790 	mov	r6,a
      0040D3 33               [12]  791 	rlc	a
      0040D4 95 E0            [12]  792 	subb	a,acc
      0040D6 FD               [12]  793 	mov	r5,a
      0040D7 EE               [12]  794 	mov	a,r6
      0040D8 24 81            [12]  795 	add	a, #_ak820_nvm_flush_header_10000_62
      0040DA FE               [12]  796 	mov	r6,a
      0040DB ED               [12]  797 	mov	a,r5
      0040DC 34 05            [12]  798 	addc	a, #(_ak820_nvm_flush_header_10000_62 >> 8)
      0040DE FD               [12]  799 	mov	r5,a
      0040DF 12 45 8D         [24]  800 	lcall	_ak820_outline_0041
      0040E2 FC               [12]  801 	mov	r4,a
      0040E3 63 04 FF         [24]  802 	xrl	ar4,#0xff
      0040E6 8E 82            [24]  803 	mov	dpl,r6
      0040E8 8D 83            [24]  804 	mov	dph,r5
      0040EA EC               [12]  805 	mov	a,r4
      0040EB F0               [24]  806 	movx	@dptr,a
      0040EC 0F               [12]  807 	inc	r7
      0040ED BF 05 DD         [24]  808 	cjne	r7,#0x05,00128$
                                    809 ;	keyboards/ajazz/ak820/ak820_nvm.c:131: stage = AK820_NVM_FAULT_HEADER_ERASE;
      0040F0 90 05 8A         [24]  810 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0040F3 74 05            [12]  811 	mov	a,#0x05
      0040F5 F0               [24]  812 	movx	@dptr,a
                                    813 ;	keyboards/ajazz/ak820/ak820_nvm.c:132: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      0040F6 90 EF 40         [24]  814 	mov	dptr,#0xef40
      0040F9 12 3C 07         [24]  815 	lcall	_ak820_flash_erase
      0040FC E5 82            [12]  816 	mov	a, dpl
      0040FE 70 03            [24]  817 	jnz	00269$
      004100 02 41 E6         [24]  818 	ljmp	00127$
      004103                        819 00269$:
                                    820 ;	keyboards/ajazz/ak820/ak820_nvm.c:133: stage = AK820_NVM_FAULT_HEADER_ZERO;
      004103 90 05 8A         [24]  821 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004106 74 06            [12]  822 	mov	a,#0x06
      004108 F0               [24]  823 	movx	@dptr,a
                                    824 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004109 7F 00            [12]  825 	mov	r7,#0x00
      00410B                        826 00130$:
                                    827 ;	keyboards/ajazz/ak820/ak820_nvm.c:135: if (ak820_flash_read(AK820_JOURNAL_HEADER + i)) goto failed;
      00410B 12 45 99         [24]  828 	lcall	_ak820_outline_0052
      00410E 12 3A FA         [24]  829 	lcall	_ak820_flash_read
      004111 E5 82            [12]  830 	mov	a, dpl
      004113 60 03            [24]  831 	jz	00270$
      004115 02 41 E6         [24]  832 	ljmp	00127$
      004118                        833 00270$:
                                    834 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004118 0F               [12]  835 	inc	r7
      004119 BF 40 EF         [24]  836 	cjne	r7,#0x40,00130$
                                    837 ;	keyboards/ajazz/ak820/ak820_nvm.c:137: stage = AK820_NVM_FAULT_JOURNAL_WRITE;
      00411C 90 05 8A         [24]  838 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      00411F 74 07            [12]  839 	mov	a,#0x07
      004121 F0               [24]  840 	movx	@dptr,a
                                    841 ;	keyboards/ajazz/ak820/ak820_nvm.c:138: if (!write_page(AK820_JOURNAL_DATA)) goto failed;
      004122 90 EF 00         [24]  842 	mov	dptr,#0xef00
      004125 12 3E D9         [24]  843 	lcall	_write_page
      004128 E5 82            [12]  844 	mov	a, dpl
      00412A 70 03            [24]  845 	jnz	00273$
      00412C 02 41 E6         [24]  846 	ljmp	00127$
      00412F                        847 00273$:
                                    848 ;	keyboards/ajazz/ak820/ak820_nvm.c:139: stage = AK820_NVM_FAULT_METADATA_PROGRAM;
      00412F 90 05 8A         [24]  849 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004132 74 08            [12]  850 	mov	a,#0x08
      004134 F0               [24]  851 	movx	@dptr,a
                                    852 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      004135 7F 01            [12]  853 	mov	r7,#0x01
      004137                        854 00132$:
                                    855 ;	keyboards/ajazz/ak820/ak820_nvm.c:141: if (header[i] && !ak820_flash_program(AK820_JOURNAL_HEADER + i, header[i])) goto failed;
      004137 12 45 8D         [24]  856 	lcall	_ak820_outline_0041
      00413A FE               [12]  857 	mov	r6,a
      00413B 60 22            [24]  858 	jz	00133$
      00413D 8F 05            [24]  859 	mov	ar5,r7
      00413F 7C 00            [12]  860 	mov	r4,#0x00
      004141 74 40            [12]  861 	mov	a,#0x40
      004143 2D               [12]  862 	add	a, r5
      004144 FD               [12]  863 	mov	r5,a
      004145 74 EF            [12]  864 	mov	a,#0xef
      004147 3C               [12]  865 	addc	a, r4
      004148 FC               [12]  866 	mov	r4,a
      004149 90 05 02         [24]  867 	mov	dptr,#_ak820_flash_program_PARM_2
      00414C EE               [12]  868 	mov	a,r6
      00414D F0               [24]  869 	movx	@dptr,a
      00414E 12 46 10         [24]  870 	lcall	_ak820_outline_0184
      004151 C0 07            [24]  871 	push	ar7
      004153 12 3C 67         [24]  872 	lcall	_ak820_flash_program
      004156 E5 82            [12]  873 	mov	a, dpl
      004158 D0 07            [24]  874 	pop	ar7
      00415A 70 03            [24]  875 	jnz	00275$
      00415C 02 41 E6         [24]  876 	ljmp	00127$
      00415F                        877 00275$:
      00415F                        878 00133$:
                                    879 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      00415F 0F               [12]  880 	inc	r7
      004160 BF 09 D4         [24]  881 	cjne	r7,#0x09,00132$
                                    882 ;	keyboards/ajazz/ak820/ak820_nvm.c:143: stage = AK820_NVM_FAULT_METADATA_READBACK;
      004163 90 05 8A         [24]  883 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004166 74 09            [12]  884 	mov	a,#0x09
      004168 F0               [24]  885 	movx	@dptr,a
                                    886 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      004169 7F 01            [12]  887 	mov	r7,#0x01
      00416B                        888 00134$:
                                    889 ;	keyboards/ajazz/ak820/ak820_nvm.c:145: if (ak820_flash_read(AK820_JOURNAL_HEADER + i) != header[i]) goto failed;
      00416B 12 45 99         [24]  890 	lcall	_ak820_outline_0052
      00416E 12 3A FA         [24]  891 	lcall	_ak820_flash_read
      004171 AE 82            [24]  892 	mov	r6, dpl
      004173 12 45 8D         [24]  893 	lcall	_ak820_outline_0041
      004176 FD               [12]  894 	mov	r5,a
      004177 EE               [12]  895 	mov	a,r6
      004178 B5 05 6B         [24]  896 	cjne	a,ar5,00127$
                                    897 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      00417B 0F               [12]  898 	inc	r7
      00417C BF 09 EC         [24]  899 	cjne	r7,#0x09,00134$
                                    900 ;	keyboards/ajazz/ak820/ak820_nvm.c:148: stage = AK820_NVM_FAULT_COMMIT_PROGRAM;
      00417F 90 05 8A         [24]  901 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      004182 74 0A            [12]  902 	mov	a,#0x0a
      004184 F0               [24]  903 	movx	@dptr,a
                                    904 ;	keyboards/ajazz/ak820/ak820_nvm.c:149: if (!ak820_flash_program(AK820_JOURNAL_HEADER, header[0])) goto failed;
      004185 90 05 81         [24]  905 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      004188 E0               [24]  906 	movx	a,@dptr
      004189 90 05 02         [24]  907 	mov	dptr,#_ak820_flash_program_PARM_2
      00418C F0               [24]  908 	movx	@dptr,a
      00418D 90 EF 40         [24]  909 	mov	dptr,#0xef40
      004190 12 3C 67         [24]  910 	lcall	_ak820_flash_program
      004193 E5 82            [12]  911 	mov	a, dpl
      004195 60 4F            [24]  912 	jz	00127$
                                    913 ;	keyboards/ajazz/ak820/ak820_nvm.c:150: stage = AK820_NVM_FAULT_COMMIT_READBACK;
      004197 90 05 8A         [24]  914 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      00419A 74 0B            [12]  915 	mov	a,#0x0b
      00419C F0               [24]  916 	movx	@dptr,a
                                    917 ;	keyboards/ajazz/ak820/ak820_nvm.c:151: if (ak820_flash_read(AK820_JOURNAL_HEADER) != header[0]) goto failed;
      00419D 90 EF 40         [24]  918 	mov	dptr,#0xef40
      0041A0 12 3A FA         [24]  919 	lcall	_ak820_flash_read
      0041A3 AF 82            [24]  920 	mov	r7, dpl
      0041A5 90 05 81         [24]  921 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      0041A8 E0               [24]  922 	movx	a,@dptr
      0041A9 FE               [12]  923 	mov	r6,a
      0041AA EF               [12]  924 	mov	a,r7
      0041AB B5 06 38         [24]  925 	cjne	a,ar6,00127$
                                    926 ;	keyboards/ajazz/ak820/ak820_nvm.c:152: stage = AK820_NVM_FAULT_TARGET_WRITE;
      0041AE 90 05 8A         [24]  927 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0041B1 74 0C            [12]  928 	mov	a,#0x0c
      0041B3 F0               [24]  929 	movx	@dptr,a
                                    930 ;	keyboards/ajazz/ak820/ak820_nvm.c:153: if (!write_page(AK820_NVM_BASE + cached_page * AK820_FLASH_PAGE)) goto failed;
      0041B4 90 05 69         [24]  931 	mov	dptr,#_cached_page
      0041B7 E0               [24]  932 	movx	a,@dptr
      0041B8 FE               [12]  933 	mov	r6,a
      0041B9 E4               [12]  934 	clr	a
      0041BA C3               [12]  935 	clr	c
      0041BB CE               [12]  936 	xch	a,r6
      0041BC 13               [12]  937 	rrc	a
      0041BD CE               [12]  938 	xch	a,r6
      0041BE 13               [12]  939 	rrc	a
      0041BF A2 E0            [12]  940 	mov	c,acc.0
      0041C1 CE               [12]  941 	xch	a,r6
      0041C2 13               [12]  942 	rrc	a
      0041C3 CE               [12]  943 	xch	a,r6
      0041C4 13               [12]  944 	rrc	a
      0041C5 CE               [12]  945 	xch	a,r6
      0041C6 24 C7            [12]  946 	add	a,#0xc7
      0041C8 FF               [12]  947 	mov	r7,a
      0041C9 12 45 CF         [24]  948 	lcall	_ak820_outline_0116
      0041CC 12 3E D9         [24]  949 	lcall	_write_page
      0041CF E5 82            [12]  950 	mov	a, dpl
      0041D1 60 13            [24]  951 	jz	00127$
                                    952 ;	keyboards/ajazz/ak820/ak820_nvm.c:154: stage = AK820_NVM_FAULT_CLEANUP;
      0041D3 90 05 8A         [24]  953 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0041D6 74 0D            [12]  954 	mov	a,#0x0d
      0041D8 F0               [24]  955 	movx	@dptr,a
                                    956 ;	keyboards/ajazz/ak820/ak820_nvm.c:155: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      0041D9 90 EF 40         [24]  957 	mov	dptr,#0xef40
      0041DC 12 3C 07         [24]  958 	lcall	_ak820_flash_erase
      0041DF E5 82            [12]  959 	mov	a, dpl
      0041E1 60 03            [24]  960 	jz	00127$
                                    961 ;	keyboards/ajazz/ak820/ak820_nvm.c:156: page_dirty = false;
                                    962 ;	assignBit
      0041E3 C2 09            [12]  963 	clr	_page_dirty
                                    964 ;	keyboards/ajazz/ak820/ak820_nvm.c:157: return;
                                    965 ;	keyboards/ajazz/ak820/ak820_nvm.c:158: failed:
      0041E5 22               [24]  966 	ret
      0041E6                        967 00127$:
                                    968 ;	keyboards/ajazz/ak820/ak820_nvm.c:159: nvm_fail(stage);
      0041E6 90 05 8A         [24]  969 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      0041E9 E0               [24]  970 	movx	a,@dptr
      0041EA F5 82            [12]  971 	mov	dpl,a
                                    972 ;	keyboards/ajazz/ak820/ak820_nvm.c:160: }
      0041EC 02 3D F8         [24]  973 	ljmp	_nvm_fail
                                    974 ;------------------------------------------------------------
                                    975 ;Allocation info for local variables in function 'ak820_nvm_begin'
                                    976 ;------------------------------------------------------------
                                    977 ;	keyboards/ajazz/ak820/ak820_nvm.c:162: void ak820_nvm_begin(void) {
                                    978 ;	-----------------------------------------
                                    979 ;	 function ak820_nvm_begin
                                    980 ;	-----------------------------------------
      0041EF                        981 _ak820_nvm_begin:
                                    982 ;	keyboards/ajazz/ak820/ak820_nvm.c:163: if (batch_depth == 255u) nvm_fail(AK820_NVM_FAULT_BATCH_OVERFLOW);
      0041EF 90 05 6A         [24]  983 	mov	dptr,#_batch_depth
      0041F2 E0               [24]  984 	movx	a,@dptr
      0041F3 FF               [12]  985 	mov	r7,a
      0041F4 BF FF 06         [24]  986 	cjne	r7,#0xff,00102$
      0041F7 75 82 0F         [24]  987 	mov	dpl, #0x0f
      0041FA 02 3D F8         [24]  988 	ljmp	_nvm_fail
      0041FD                        989 00102$:
                                    990 ;	keyboards/ajazz/ak820/ak820_nvm.c:164: else ++batch_depth;
      0041FD 90 05 6A         [24]  991 	mov	dptr,#_batch_depth
      004200 EF               [12]  992 	mov	a,r7
      004201 04               [12]  993 	inc	a
      004202 F0               [24]  994 	movx	@dptr,a
                                    995 ;	keyboards/ajazz/ak820/ak820_nvm.c:165: }
      004203 22               [24]  996 	ret
                                    997 ;------------------------------------------------------------
                                    998 ;Allocation info for local variables in function 'ak820_nvm_end'
                                    999 ;------------------------------------------------------------
                                   1000 ;	keyboards/ajazz/ak820/ak820_nvm.c:167: void ak820_nvm_end(void) {
                                   1001 ;	-----------------------------------------
                                   1002 ;	 function ak820_nvm_end
                                   1003 ;	-----------------------------------------
      004204                       1004 _ak820_nvm_end:
                                   1005 ;	keyboards/ajazz/ak820/ak820_nvm.c:168: if (batch_depth) --batch_depth;
      004204 90 05 6A         [24] 1006 	mov	dptr,#_batch_depth
      004207 E0               [24] 1007 	movx	a,@dptr
      004208 FF               [12] 1008 	mov	r7,a
      004209 E0               [24] 1009 	movx	a,@dptr
      00420A 60 06            [24] 1010 	jz	00102$
      00420C EF               [12] 1011 	mov	a,r7
      00420D 14               [12] 1012 	dec	a
      00420E 90 05 6A         [24] 1013 	mov	dptr,#_batch_depth
      004211 F0               [24] 1014 	movx	@dptr,a
      004212                       1015 00102$:
                                   1016 ;	keyboards/ajazz/ak820/ak820_nvm.c:169: if (!batch_depth) ak820_nvm_flush();
      004212 90 05 6A         [24] 1017 	mov	dptr,#_batch_depth
      004215 E0               [24] 1018 	movx	a,@dptr
      004216 70 03            [24] 1019 	jnz	00105$
                                   1020 ;	keyboards/ajazz/ak820/ak820_nvm.c:170: }
      004218 02 40 9D         [24] 1021 	ljmp	_ak820_nvm_flush
      00421B                       1022 00105$:
      00421B 22               [24] 1023 	ret
                                   1024 ;------------------------------------------------------------
                                   1025 ;Allocation info for local variables in function 'load_page'
                                   1026 ;------------------------------------------------------------
                                   1027 ;page          Allocated with name '_load_page_page_10000_87'
                                   1028 ;i             Allocated with name '_load_page_i_10000_88'
                                   1029 ;------------------------------------------------------------
                                   1030 ;	keyboards/ajazz/ak820/ak820_nvm.c:172: static bool load_page(uint8_t page) {
                                   1031 ;	-----------------------------------------
                                   1032 ;	 function load_page
                                   1033 ;	-----------------------------------------
      00421C                       1034 _load_page:
      00421C E5 82            [12] 1035 	mov	a,dpl
      00421E 90 05 8B         [24] 1036 	mov	dptr,#_load_page_page_10000_87
      004221 F0               [24] 1037 	movx	@dptr,a
                                   1038 ;	keyboards/ajazz/ak820/ak820_nvm.c:174: if (page_valid && cached_page == page) return !storage_failed;
      004222 30 08 17         [24] 1039 	jnb	_page_valid,00102$
      004225 90 05 69         [24] 1040 	mov	dptr,#_cached_page
      004228 E0               [24] 1041 	movx	a,@dptr
      004229 FF               [12] 1042 	mov	r7,a
      00422A 90 05 8B         [24] 1043 	mov	dptr,#_load_page_page_10000_87
      00422D E0               [24] 1044 	movx	a,@dptr
      00422E FE               [12] 1045 	mov	r6,a
      00422F EF               [12] 1046 	mov	a,r7
      004230 B5 06 09         [24] 1047 	cjne	a,ar6,00102$
      004233 A2 0A            [12] 1048 	mov	c,_storage_failed
      004235 B3               [12] 1049 	cpl	c
      004236 92 0C            [24] 1050 	mov  _load_page_sloc0_1_0,c
      004238 12 3A C7         [24] 1051 	lcall	_ak820_outline_0167
      00423B 22               [24] 1052 	ret
      00423C                       1053 00102$:
                                   1054 ;	keyboards/ajazz/ak820/ak820_nvm.c:175: ak820_nvm_flush();
      00423C 12 40 9D         [24] 1055 	lcall	_ak820_nvm_flush
                                   1056 ;	keyboards/ajazz/ak820/ak820_nvm.c:176: if (storage_failed) return false;
      00423F 30 0A 04         [24] 1057 	jnb	_storage_failed,00119$
      004242 75 82 00         [24] 1058 	mov	dpl, #0x00
                                   1059 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004245 22               [24] 1060 	ret
      004246                       1061 00119$:
      004246 7F 00            [12] 1062 	mov	r7,#0x00
      004248                       1063 00107$:
                                   1064 ;	keyboards/ajazz/ak820/ak820_nvm.c:178: page_data[i] = ak820_flash_read(AK820_NVM_BASE + page * AK820_FLASH_PAGE + i);
      004248 EF               [12] 1065 	mov	a,r7
      004249 24 29            [12] 1066 	add	a, #_page_data
      00424B FD               [12] 1067 	mov	r5,a
      00424C E4               [12] 1068 	clr	a
      00424D 34 05            [12] 1069 	addc	a, #(_page_data >> 8)
      00424F FE               [12] 1070 	mov	r6,a
      004250 90 05 8B         [24] 1071 	mov	dptr,#_load_page_page_10000_87
      004253 E0               [24] 1072 	movx	a,@dptr
      004254 FC               [12] 1073 	mov	r4,a
      004255 FA               [12] 1074 	mov	r2,a
      004256 E4               [12] 1075 	clr	a
      004257 C3               [12] 1076 	clr	c
      004258 CA               [12] 1077 	xch	a,r2
      004259 13               [12] 1078 	rrc	a
      00425A CA               [12] 1079 	xch	a,r2
      00425B 13               [12] 1080 	rrc	a
      00425C A2 E0            [12] 1081 	mov	c,acc.0
      00425E CA               [12] 1082 	xch	a,r2
      00425F 13               [12] 1083 	rrc	a
      004260 CA               [12] 1084 	xch	a,r2
      004261 13               [12] 1085 	rrc	a
      004262 CA               [12] 1086 	xch	a,r2
      004263 24 C7            [12] 1087 	add	a,#0xc7
      004265 FB               [12] 1088 	mov	r3,a
      004266 8F 01            [24] 1089 	mov	ar1,r7
      004268 89 00            [24] 1090 	mov	ar0,r1
      00426A 79 00            [12] 1091 	mov	r1,#0x00
      00426C E8               [12] 1092 	mov	a,r0
      00426D 2A               [12] 1093 	add	a, r2
      00426E FA               [12] 1094 	mov	r2,a
      00426F E9               [12] 1095 	mov	a,r1
      004270 3B               [12] 1096 	addc	a, r3
      004271 FB               [12] 1097 	mov	r3,a
      004272 12 45 EB         [24] 1098 	lcall	_ak820_outline_0140
      004275 12 3A FA         [24] 1099 	lcall	_ak820_flash_read
      004278 AB 82            [24] 1100 	mov	r3, dpl
      00427A 12 3A AB         [24] 1101 	lcall	_ak820_outline_0132
      00427D EB               [12] 1102 	mov	a,r3
      00427E F0               [24] 1103 	movx	@dptr,a
                                   1104 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      00427F 0F               [12] 1105 	inc	r7
      004280 BF 40 C5         [24] 1106 	cjne	r7,#0x40,00107$
                                   1107 ;	keyboards/ajazz/ak820/ak820_nvm.c:180: cached_page = page;
      004283 90 05 69         [24] 1108 	mov	dptr,#_cached_page
      004286 EC               [12] 1109 	mov	a,r4
      004287 F0               [24] 1110 	movx	@dptr,a
                                   1111 ;	keyboards/ajazz/ak820/ak820_nvm.c:181: page_valid = true;
                                   1112 ;	assignBit
      004288 D2 08            [12] 1113 	setb	_page_valid
                                   1114 ;	keyboards/ajazz/ak820/ak820_nvm.c:182: return true;
      00428A 75 82 01         [24] 1115 	mov	dpl, #0x01
                                   1116 ;	keyboards/ajazz/ak820/ak820_nvm.c:183: }
      00428D 22               [24] 1117 	ret
                                   1118 ;------------------------------------------------------------
                                   1119 ;Allocation info for local variables in function 'read_offset'
                                   1120 ;------------------------------------------------------------
                                   1121 ;offset        Allocated with name '_read_offset_offset_10000_93'
                                   1122 ;------------------------------------------------------------
                                   1123 ;	keyboards/ajazz/ak820/ak820_nvm.c:185: static uint8_t read_offset(uint16_t offset) {
                                   1124 ;	-----------------------------------------
                                   1125 ;	 function read_offset
                                   1126 ;	-----------------------------------------
      00428E                       1127 _read_offset:
      00428E 12 3A 8A         [24] 1128 	lcall	_ak820_outline_0103
      004291 90 05 8C         [24] 1129 	mov	dptr,#_read_offset_offset_10000_93
      004294 12 3A 8F         [24] 1130 	lcall	_ak820_outline_0104
                                   1131 ;	keyboards/ajazz/ak820/ak820_nvm.c:186: if (offset >= AK820_NVM_SIZE) return 0;
      004297 90 05 8C         [24] 1132 	mov	dptr,#_read_offset_offset_10000_93
      00429A 12 3A 47         [24] 1133 	lcall	_ak820_outline_0051
      00429D C3               [12] 1134 	clr	c
      00429E 94 28            [12] 1135 	subb	a,#0x28
      0042A0 40 04            [24] 1136 	jc	00102$
      0042A2 75 82 00         [24] 1137 	mov	dpl, #0x00
      0042A5 22               [24] 1138 	ret
      0042A6                       1139 00102$:
                                   1140 ;	keyboards/ajazz/ak820/ak820_nvm.c:187: if (page_valid && (offset / AK820_FLASH_PAGE) == cached_page)
      0042A6 30 08 34         [24] 1141 	jnb	_page_valid,00104$
      0042A9 8E 04            [24] 1142 	mov	ar4,r6
      0042AB EF               [12] 1143 	mov	a,r7
      0042AC A2 E7            [12] 1144 	mov	c,acc.7
      0042AE CC               [12] 1145 	xch	a,r4
      0042AF 33               [12] 1146 	rlc	a
      0042B0 CC               [12] 1147 	xch	a,r4
      0042B1 33               [12] 1148 	rlc	a
      0042B2 A2 E7            [12] 1149 	mov	c,acc.7
      0042B4 CC               [12] 1150 	xch	a,r4
      0042B5 33               [12] 1151 	rlc	a
      0042B6 CC               [12] 1152 	xch	a,r4
      0042B7 33               [12] 1153 	rlc	a
      0042B8 CC               [12] 1154 	xch	a,r4
      0042B9 54 03            [12] 1155 	anl	a,#0x03
      0042BB FD               [12] 1156 	mov	r5,a
      0042BC 90 05 69         [24] 1157 	mov	dptr,#_cached_page
      0042BF E0               [24] 1158 	movx	a,@dptr
      0042C0 FA               [12] 1159 	mov	r2,a
      0042C1 7B 00            [12] 1160 	mov	r3,#0x00
      0042C3 EC               [12] 1161 	mov	a,r4
      0042C4 B5 02 16         [24] 1162 	cjne	a,ar2,00104$
      0042C7 ED               [12] 1163 	mov	a,r5
      0042C8 B5 03 12         [24] 1164 	cjne	a,ar3,00104$
                                   1165 ;	keyboards/ajazz/ak820/ak820_nvm.c:188: return page_data[offset % AK820_FLASH_PAGE];
      0042CB 74 3F            [12] 1166 	mov	a,#0x3f
      0042CD 5E               [12] 1167 	anl	a,r6
      0042CE 7D 00            [12] 1168 	mov	r5,#0x00
      0042D0 24 29            [12] 1169 	add	a, #_page_data
      0042D2 F5 82            [12] 1170 	mov	dpl,a
      0042D4 ED               [12] 1171 	mov	a,r5
      0042D5 34 05            [12] 1172 	addc	a, #(_page_data >> 8)
      0042D7 F5 83            [12] 1173 	mov	dph,a
      0042D9 E0               [24] 1174 	movx	a,@dptr
      0042DA F5 82            [12] 1175 	mov	dpl,a
      0042DC 22               [24] 1176 	ret
      0042DD                       1177 00104$:
                                   1178 ;	keyboards/ajazz/ak820/ak820_nvm.c:189: return ak820_flash_read(AK820_NVM_BASE + offset);
      0042DD 74 C7            [12] 1179 	mov	a,#0xc7
      0042DF 2F               [12] 1180 	add	a, r7
      0042E0 FF               [12] 1181 	mov	r7,a
      0042E1 12 45 CF         [24] 1182 	lcall	_ak820_outline_0116
                                   1183 ;	keyboards/ajazz/ak820/ak820_nvm.c:190: }
      0042E4 02 3A FA         [24] 1184 	ljmp	_ak820_flash_read
                                   1185 ;------------------------------------------------------------
                                   1186 ;Allocation info for local variables in function 'eeprom_read_byte'
                                   1187 ;------------------------------------------------------------
                                   1188 ;addr          Allocated with name '_eeprom_read_byte_addr_10000_97'
                                   1189 ;------------------------------------------------------------
                                   1190 ;	keyboards/ajazz/ak820/ak820_nvm.c:193: uint8_t eeprom_read_byte(const uint8_t *addr) {
                                   1191 ;	-----------------------------------------
                                   1192 ;	 function eeprom_read_byte
                                   1193 ;	-----------------------------------------
      0042E7                       1194 _eeprom_read_byte:
      0042E7 C0 07            [24] 1195 	push	ar7
      0042E9 C0 06            [24] 1196 	push	ar6
      0042EB 12 45 86         [24] 1197 	lcall	_ak820_outline_0037
      0042EE 90 05 8E         [24] 1198 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      0042F1 12 3A 26         [24] 1199 	lcall	_ak820_outline_0016
                                   1200 ;	keyboards/ajazz/ak820/ak820_nvm.c:194: return read_offset((uint16_t)(uintptr_t)addr);
      0042F4 90 05 8E         [24] 1201 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      0042F7 12 39 E7         [24] 1202 	lcall	_ak820_outline_0004
      0042FA C0 06            [24] 1203 	push	ar6
      0042FC C0 05            [24] 1204 	push	ar5
      0042FE C0 04            [24] 1205 	push	ar4
      004300 C0 03            [24] 1206 	push	ar3
      004302 C0 02            [24] 1207 	push	ar2
      004304 C0 01            [24] 1208 	push	ar1
      004306 C0 00            [24] 1209 	push	ar0
      004308 12 42 8E         [24] 1210 	lcall	_read_offset
      00430B AF 82            [24] 1211 	mov	r7, dpl
      00430D D0 00            [24] 1212 	pop	ar0
      00430F D0 01            [24] 1213 	pop	ar1
      004311 D0 02            [24] 1214 	pop	ar2
      004313 D0 03            [24] 1215 	pop	ar3
      004315 D0 04            [24] 1216 	pop	ar4
      004317 D0 05            [24] 1217 	pop	ar5
      004319 D0 06            [24] 1218 	pop	ar6
      00431B 8F 82            [24] 1219 	mov	dpl, r7
                                   1220 ;	keyboards/ajazz/ak820/ak820_nvm.c:195: }
      00431D D0 06            [24] 1221 	pop	ar6
      00431F D0 07            [24] 1222 	pop	ar7
      004321 22               [24] 1223 	ret
                                   1224 ;------------------------------------------------------------
                                   1225 ;Allocation info for local variables in function 'eeprom_read_block'
                                   1226 ;------------------------------------------------------------
                                   1227 ;addr          Allocated with name '_eeprom_read_block_PARM_2'
                                   1228 ;len           Allocated with name '_eeprom_read_block_PARM_3'
                                   1229 ;buf           Allocated with name '_eeprom_read_block_buf_10000_99'
                                   1230 ;offset        Allocated with name '_eeprom_read_block_offset_10000_100'
                                   1231 ;out           Allocated with name '_eeprom_read_block_out_10000_100'
                                   1232 ;------------------------------------------------------------
                                   1233 ;	keyboards/ajazz/ak820/ak820_nvm.c:199: void eeprom_read_block(void *buf, const void *addr, size_t len) {
                                   1234 ;	-----------------------------------------
                                   1235 ;	 function ak820_eeprom_read_block_xdata
                                   1236 ;	-----------------------------------------
      004322                       1237 _ak820_eeprom_read_block_xdata:
      004322 12 3A 8A         [24] 1238 	lcall	_ak820_outline_0103
      004325 90 05 96         [24] 1239 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      004328 12 3A 8F         [24] 1240 	lcall	_ak820_outline_0104
                                   1241 ;	keyboards/ajazz/ak820/ak820_nvm.c:230: uint16_t offset = (uint16_t)(uintptr_t)addr;
      00432B 90 05 91         [24] 1242 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      00432E 12 3A 47         [24] 1243 	lcall	_ak820_outline_0051
                                   1244 ;	keyboards/ajazz/ak820/ak820_nvm.c:231: uint8_t AK820_XDATA *out = (uint8_t AK820_XDATA *)buf;
      004331 90 05 96         [24] 1245 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      004334 12 3A 66         [24] 1246 	lcall	_ak820_outline_0060
      004337 90 05 98         [24] 1247 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      00433A 12 3A 6C         [24] 1248 	lcall	_ak820_outline_0071
                                   1249 ;	keyboards/ajazz/ak820/ak820_nvm.c:232: while (len--) {
      00433D 90 05 94         [24] 1250 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      004340 12 3A 66         [24] 1251 	lcall	_ak820_outline_0060
      004343                       1252 00103$:
      004343 8C 02            [24] 1253 	mov	ar2,r4
      004345 8D 03            [24] 1254 	mov	ar3,r5
      004347 1C               [12] 1255 	dec	r4
      004348 BC FF 01         [24] 1256 	cjne	r4,#0xff,00130$
      00434B 1D               [12] 1257 	dec	r5
      00434C                       1258 00130$:
      00434C EA               [12] 1259 	mov	a,r2
      00434D 4B               [12] 1260 	orl	a,r3
      00434E 60 5D            [24] 1261 	jz	00106$
                                   1262 ;	keyboards/ajazz/ak820/ak820_nvm.c:233: if (offset >= AK820_NVM_SIZE) { *out++ = 0; continue; }
      004350 8E 02            [24] 1263 	mov	ar2,r6
      004352 8F 03            [24] 1264 	mov	ar3,r7
      004354 74 D8            [12] 1265 	mov	a,#0x100 - 0x28
      004356 2B               [12] 1266 	add	a,r3
      004357 50 17            [24] 1267 	jnc	00102$
      004359 90 05 98         [24] 1268 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      00435C 12 45 D4         [24] 1269 	lcall	_ak820_outline_0120
      00435F 12 45 EB         [24] 1270 	lcall	_ak820_outline_0140
      004362 E4               [12] 1271 	clr	a
      004363 F0               [24] 1272 	movx	@dptr,a
      004364 90 05 98         [24] 1273 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004367 04               [12] 1274 	inc	a
      004368 2A               [12] 1275 	add	a, r2
      004369 F0               [24] 1276 	movx	@dptr,a
      00436A E4               [12] 1277 	clr	a
      00436B 3B               [12] 1278 	addc	a, r3
      00436C A3               [24] 1279 	inc	dptr
      00436D F0               [24] 1280 	movx	@dptr,a
      00436E 80 D3            [24] 1281 	sjmp	00103$
      004370                       1282 00102$:
                                   1283 ;	keyboards/ajazz/ak820/ak820_nvm.c:234: *out++ = read_offset(offset);
      004370 90 05 98         [24] 1284 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004373 12 45 D4         [24] 1285 	lcall	_ak820_outline_0120
      004376 12 45 CF         [24] 1286 	lcall	_ak820_outline_0116
      004379 C0 07            [24] 1287 	push	ar7
      00437B C0 06            [24] 1288 	push	ar6
      00437D C0 05            [24] 1289 	push	ar5
      00437F C0 04            [24] 1290 	push	ar4
      004381 C0 03            [24] 1291 	push	ar3
      004383 C0 02            [24] 1292 	push	ar2
      004385 12 42 8E         [24] 1293 	lcall	_read_offset
      004388 A9 82            [24] 1294 	mov	r1, dpl
      00438A D0 02            [24] 1295 	pop	ar2
      00438C D0 03            [24] 1296 	pop	ar3
      00438E D0 04            [24] 1297 	pop	ar4
      004390 D0 05            [24] 1298 	pop	ar5
      004392 D0 06            [24] 1299 	pop	ar6
      004394 D0 07            [24] 1300 	pop	ar7
      004396 12 45 EB         [24] 1301 	lcall	_ak820_outline_0140
      004399 E9               [12] 1302 	mov	a,r1
      00439A F0               [24] 1303 	movx	@dptr,a
      00439B 90 05 98         [24] 1304 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      00439E 74 01            [12] 1305 	mov	a,#0x01
      0043A0 2A               [12] 1306 	add	a, r2
      0043A1 F0               [24] 1307 	movx	@dptr,a
      0043A2 E4               [12] 1308 	clr	a
      0043A3 3B               [12] 1309 	addc	a, r3
      0043A4 A3               [24] 1310 	inc	dptr
      0043A5 F0               [24] 1311 	movx	@dptr,a
                                   1312 ;	keyboards/ajazz/ak820/ak820_nvm.c:235: ++offset;
      0043A6 0E               [12] 1313 	inc	r6
      0043A7 BE 00 99         [24] 1314 	cjne	r6,#0x00,00103$
      0043AA 0F               [12] 1315 	inc	r7
      0043AB 80 96            [24] 1316 	sjmp	00103$
      0043AD                       1317 00106$:
                                   1318 ;	keyboards/ajazz/ak820/ak820_nvm.c:237: }
      0043AD 22               [24] 1319 	ret
                                   1320 ;------------------------------------------------------------
                                   1321 ;Allocation info for local variables in function 'ak820_eeprom_write_block_xdata'
                                   1322 ;------------------------------------------------------------
                                   1323 ;sloc0         Allocated with name '_ak820_eeprom_write_block_xdata_sloc0_1_0'
                                   1324 ;addr          Allocated with name '_ak820_eeprom_write_block_xdata_PARM_2'
                                   1325 ;len           Allocated with name '_ak820_eeprom_write_block_xdata_PARM_3'
                                   1326 ;buf           Allocated with name '_ak820_eeprom_write_block_xdata_buf_10000_118'
                                   1327 ;offset        Allocated with name '_ak820_eeprom_write_block_xdata_offset_10000_119'
                                   1328 ;in            Allocated with name '_ak820_eeprom_write_block_xdata_in_10000_119'
                                   1329 ;value         Allocated with name '_ak820_eeprom_write_block_xdata_value_20000_122'
                                   1330 ;------------------------------------------------------------
                                   1331 ;	keyboards/ajazz/ak820/ak820_nvm.c:239: void ak820_eeprom_write_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1332 ;	-----------------------------------------
                                   1333 ;	 function ak820_eeprom_write_block_xdata
                                   1334 ;	-----------------------------------------
      0043AE                       1335 _ak820_eeprom_write_block_xdata:
      0043AE 12 3A 8A         [24] 1336 	lcall	_ak820_outline_0103
      0043B1 90 05 9F         [24] 1337 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      0043B4 12 3A 8F         [24] 1338 	lcall	_ak820_outline_0104
                                   1339 ;	keyboards/ajazz/ak820/ak820_nvm.c:240: uint16_t offset = (uint16_t)(uintptr_t)addr;
      0043B7 90 05 9A         [24] 1340 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      0043BA 12 3A 47         [24] 1341 	lcall	_ak820_outline_0051
                                   1342 ;	keyboards/ajazz/ak820/ak820_nvm.c:241: const uint8_t AK820_XDATA *in = (const uint8_t AK820_XDATA *)buf;
      0043BD 90 05 9F         [24] 1343 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      0043C0 12 3A 66         [24] 1344 	lcall	_ak820_outline_0060
                                   1345 ;	keyboards/ajazz/ak820/ak820_nvm.c:243: if (offset > AK820_NVM_SIZE || len > AK820_NVM_SIZE - offset) {
      0043C3 8E 02            [24] 1346 	mov	ar2,r6
      0043C5 8F 03            [24] 1347 	mov	ar3,r7
      0043C7 C3               [12] 1348 	clr	c
      0043C8 E4               [12] 1349 	clr	a
      0043C9 9A               [12] 1350 	subb	a,r2
      0043CA 74 28            [12] 1351 	mov	a,#0x28
      0043CC 9B               [12] 1352 	subb	a,r3
      0043CD 40 15            [24] 1353 	jc	00101$
                                   1354 ;	free result
      0043CF E4               [12] 1355 	clr	a
      0043D0 C3               [12] 1356 	clr	c
      0043D1 9E               [12] 1357 	subb	a,r6
      0043D2 FA               [12] 1358 	mov	r2,a
      0043D3 74 28            [12] 1359 	mov	a,#0x28
      0043D5 9F               [12] 1360 	subb	a,r7
      0043D6 FB               [12] 1361 	mov	r3,a
      0043D7 90 05 9D         [24] 1362 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0043DA 12 3A 84         [24] 1363 	lcall	_ak820_outline_0100
      0043DD C3               [12] 1364 	clr	c
      0043DE EA               [12] 1365 	mov	a,r2
      0043DF 98               [12] 1366 	subb	a,r0
      0043E0 EB               [12] 1367 	mov	a,r3
      0043E1 99               [12] 1368 	subb	a,r1
      0043E2 50 06            [24] 1369 	jnc	00125$
                                   1370 ;	free result
      0043E4                       1371 00101$:
                                   1372 ;	keyboards/ajazz/ak820/ak820_nvm.c:244: nvm_fail(AK820_NVM_FAULT_WRITE_RANGE);
      0043E4 75 82 0E         [24] 1373 	mov	dpl, #0x0e
                                   1374 ;	keyboards/ajazz/ak820/ak820_nvm.c:245: return;
      0043E7 02 3D F8         [24] 1375 	ljmp	_nvm_fail
                                   1376 ;	keyboards/ajazz/ak820/ak820_nvm.c:247: while (len--) {
      0043EA                       1377 00125$:
      0043EA 90 05 9D         [24] 1378 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0043ED 12 45 D4         [24] 1379 	lcall	_ak820_outline_0120
      0043F0                       1380 00108$:
      0043F0 8A 00            [24] 1381 	mov	ar0,r2
      0043F2 8B 01            [24] 1382 	mov	ar1,r3
      0043F4 1A               [12] 1383 	dec	r2
      0043F5 BA FF 01         [24] 1384 	cjne	r2,#0xff,00159$
      0043F8 1B               [12] 1385 	dec	r3
      0043F9                       1386 00159$:
      0043F9 E8               [12] 1387 	mov	a,r0
      0043FA 49               [12] 1388 	orl	a,r1
      0043FB 70 03            [24] 1389 	jnz	00160$
      0043FD 02 44 87         [24] 1390 	ljmp	00110$
      004400                       1391 00160$:
                                   1392 ;	keyboards/ajazz/ak820/ak820_nvm.c:248: uint8_t value = *in++;
      004400 C0 02            [24] 1393 	push	ar2
      004402 C0 03            [24] 1394 	push	ar3
      004404 12 45 B7         [24] 1395 	lcall	_ak820_outline_0092
      004407 F9               [12] 1396 	mov	r1,a
      004408 A3               [24] 1397 	inc	dptr
      004409 12 45 F0         [24] 1398 	lcall	_ak820_outline_0145
                                   1399 ;	keyboards/ajazz/ak820/ak820_nvm.c:249: if (!load_page(offset / AK820_FLASH_PAGE)) return;
      00440C 8E 0C            [24] 1400 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,r6
      00440E 8F 0D            [24] 1401 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),r7
      004410 A8 0C            [24] 1402 	mov	r0,_ak820_eeprom_write_block_xdata_sloc0_1_0
      004412 E5 0D            [12] 1403 	mov	a,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      004414 A2 E7            [12] 1404 	mov	c,acc.7
      004416 C8               [12] 1405 	xch	a,r0
      004417 33               [12] 1406 	rlc	a
      004418 C8               [12] 1407 	xch	a,r0
      004419 33               [12] 1408 	rlc	a
      00441A A2 E7            [12] 1409 	mov	c,acc.7
      00441C C8               [12] 1410 	xch	a,r0
      00441D 33               [12] 1411 	rlc	a
      00441E C8               [12] 1412 	xch	a,r0
      00441F 33               [12] 1413 	rlc	a
      004420 C8               [12] 1414 	xch	a,r0
      004421 54 03            [12] 1415 	anl	a,#0x03
      004423 FB               [12] 1416 	mov	r3,a
      004424 88 82            [24] 1417 	mov	dpl, r0
      004426 C0 07            [24] 1418 	push	ar7
      004428 C0 06            [24] 1419 	push	ar6
      00442A C0 05            [24] 1420 	push	ar5
      00442C C0 04            [24] 1421 	push	ar4
      00442E C0 03            [24] 1422 	push	ar3
      004430 C0 02            [24] 1423 	push	ar2
      004432 C0 01            [24] 1424 	push	ar1
      004434 12 42 1C         [24] 1425 	lcall	_load_page
      004437 E5 82            [12] 1426 	mov	a, dpl
      004439 D0 01            [24] 1427 	pop	ar1
      00443B D0 02            [24] 1428 	pop	ar2
      00443D D0 03            [24] 1429 	pop	ar3
      00443F D0 04            [24] 1430 	pop	ar4
      004441 D0 05            [24] 1431 	pop	ar5
      004443 D0 06            [24] 1432 	pop	ar6
      004445 D0 07            [24] 1433 	pop	ar7
      004447 D0 03            [24] 1434 	pop	ar3
      004449 D0 02            [24] 1435 	pop	ar2
      00444B 70 01            [24] 1436 	jnz	00105$
      00444D 22               [24] 1437 	ret
      00444E                       1438 00105$:
                                   1439 ;	keyboards/ajazz/ak820/ak820_nvm.c:250: if (page_data[offset % AK820_FLASH_PAGE] != value) {
      00444E C0 06            [24] 1440 	push	ar6
      004450 C0 07            [24] 1441 	push	ar7
      004452 74 3F            [12] 1442 	mov	a,#0x3f
      004454 55 0C            [12] 1443 	anl	a,_ak820_eeprom_write_block_xdata_sloc0_1_0
      004456 7F 00            [12] 1444 	mov	r7,#0x00
      004458 24 29            [12] 1445 	add	a, #_page_data
      00445A F5 0C            [12] 1446 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,a
      00445C EF               [12] 1447 	mov	a,r7
      00445D 34 05            [12] 1448 	addc	a, #(_page_data >> 8)
      00445F F5 0D            [12] 1449 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),a
      004461 85 0C 82         [24] 1450 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      004464 85 0D 83         [24] 1451 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      004467 E0               [24] 1452 	movx	a,@dptr
      004468 B5 01 06         [24] 1453 	cjne	a,ar1,00162$
      00446B D0 07            [24] 1454 	pop	ar7
      00446D D0 06            [24] 1455 	pop	ar6
      00446F 80 0E            [24] 1456 	sjmp	00107$
      004471                       1457 00162$:
      004471 D0 07            [24] 1458 	pop	ar7
      004473 D0 06            [24] 1459 	pop	ar6
                                   1460 ;	keyboards/ajazz/ak820/ak820_nvm.c:251: page_data[offset % AK820_FLASH_PAGE] = value;
      004475 85 0C 82         [24] 1461 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      004478 85 0D 83         [24] 1462 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      00447B E9               [12] 1463 	mov	a,r1
      00447C F0               [24] 1464 	movx	@dptr,a
                                   1465 ;	keyboards/ajazz/ak820/ak820_nvm.c:252: page_dirty = true;
                                   1466 ;	assignBit
      00447D D2 09            [12] 1467 	setb	_page_dirty
      00447F                       1468 00107$:
                                   1469 ;	keyboards/ajazz/ak820/ak820_nvm.c:254: ++offset;
      00447F 0E               [12] 1470 	inc	r6
      004480 BE 00 01         [24] 1471 	cjne	r6,#0x00,00163$
      004483 0F               [12] 1472 	inc	r7
      004484                       1473 00163$:
      004484 02 43 F0         [24] 1474 	ljmp	00108$
      004487                       1475 00110$:
                                   1476 ;	keyboards/ajazz/ak820/ak820_nvm.c:256: if (!batch_depth) ak820_nvm_flush();
      004487 90 05 6A         [24] 1477 	mov	dptr,#_batch_depth
      00448A E0               [24] 1478 	movx	a,@dptr
      00448B 70 03            [24] 1479 	jnz	00113$
                                   1480 ;	keyboards/ajazz/ak820/ak820_nvm.c:257: }
      00448D 02 40 9D         [24] 1481 	ljmp	_ak820_nvm_flush
      004490                       1482 00113$:
      004490 22               [24] 1483 	ret
                                   1484 ;------------------------------------------------------------
                                   1485 ;Allocation info for local variables in function 'ak820_eeprom_update_block_xdata'
                                   1486 ;------------------------------------------------------------
                                   1487 ;sloc0         Allocated with name '_ak820_eeprom_update_block_xdata_sloc0_1_0'
                                   1488 ;sloc1         Allocated with name '_ak820_eeprom_update_block_xdata_sloc1_1_0'
                                   1489 ;sloc2         Allocated with name '_ak820_eeprom_update_block_xdata_sloc2_1_0'
                                   1490 ;addr          Allocated with name '_ak820_eeprom_update_block_xdata_PARM_2'
                                   1491 ;len           Allocated with name '_ak820_eeprom_update_block_xdata_PARM_3'
                                   1492 ;buf           Allocated with name '_ak820_eeprom_update_block_xdata_buf_10000_127'
                                   1493 ;source        Allocated with name '_ak820_eeprom_update_block_xdata_source_10000_128'
                                   1494 ;offset        Allocated with name '_ak820_eeprom_update_block_xdata_offset_10000_128'
                                   1495 ;i             Allocated with name '_ak820_eeprom_update_block_xdata_i_10000_128'
                                   1496 ;------------------------------------------------------------
                                   1497 ;	keyboards/ajazz/ak820/ak820_nvm.c:259: void ak820_eeprom_update_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1498 ;	-----------------------------------------
                                   1499 ;	 function ak820_eeprom_update_block_xdata
                                   1500 ;	-----------------------------------------
      004491                       1501 _ak820_eeprom_update_block_xdata:
      004491 12 3A 8A         [24] 1502 	lcall	_ak820_outline_0103
      004494 90 05 A6         [24] 1503 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      004497 12 3A 8F         [24] 1504 	lcall	_ak820_outline_0104
                                   1505 ;	keyboards/ajazz/ak820/ak820_nvm.c:260: const uint8_t AK820_XDATA *source = (const uint8_t AK820_XDATA *)buf;
      00449A 90 05 A6         [24] 1506 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      00449D 12 3A 47         [24] 1507 	lcall	_ak820_outline_0051
                                   1508 ;	keyboards/ajazz/ak820/ak820_nvm.c:261: uint16_t offset = (uint16_t)(uintptr_t)addr;
      0044A0 90 05 A1         [24] 1509 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      0044A3 E0               [24] 1510 	movx	a,@dptr
      0044A4 F5 12            [12] 1511 	mov	_ak820_eeprom_update_block_xdata_sloc2_1_0,a
      0044A6 A3               [24] 1512 	inc	dptr
      0044A7 E0               [24] 1513 	movx	a,@dptr
      0044A8 F5 13            [12] 1514 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1),a
      0044AA A3               [24] 1515 	inc	dptr
      0044AB E0               [24] 1516 	movx	a,@dptr
      0044AC F5 14            [12] 1517 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2),a
      0044AE A9 12            [24] 1518 	mov	r1,_ak820_eeprom_update_block_xdata_sloc2_1_0
      0044B0 AA 13            [24] 1519 	mov	r2,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
                                   1520 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      0044B2 E4               [12] 1521 	clr	a
      0044B3 F5 0E            [12] 1522 	mov	_ak820_eeprom_update_block_xdata_sloc0_1_0,a
      0044B5 F5 0F            [12] 1523 	mov	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1),a
      0044B7                       1524 00105$:
      0044B7 90 05 A4         [24] 1525 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      0044BA E0               [24] 1526 	movx	a,@dptr
      0044BB F5 10            [12] 1527 	mov	_ak820_eeprom_update_block_xdata_sloc1_1_0,a
      0044BD A3               [24] 1528 	inc	dptr
      0044BE E0               [24] 1529 	movx	a,@dptr
      0044BF F5 11            [12] 1530 	mov	(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1),a
      0044C1 C3               [12] 1531 	clr	c
      0044C2 E5 0E            [12] 1532 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      0044C4 95 10            [12] 1533 	subb	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      0044C6 E5 0F            [12] 1534 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      0044C8 95 11            [12] 1535 	subb	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      0044CA 50 68            [24] 1536 	jnc	00107$
                                   1537 ;	keyboards/ajazz/ak820/ak820_nvm.c:264: if (read_offset(offset + i) != source[i]) {
      0044CC 89 00            [24] 1538 	mov	ar0,r1
      0044CE 8A 05            [24] 1539 	mov	ar5,r2
      0044D0 E5 0E            [12] 1540 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      0044D2 28               [12] 1541 	add	a, r0
      0044D3 F8               [12] 1542 	mov	r0,a
      0044D4 E5 0F            [12] 1543 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      0044D6 3D               [12] 1544 	addc	a, r5
      0044D7 FD               [12] 1545 	mov	r5,a
      0044D8 88 82            [24] 1546 	mov	dpl, r0
      0044DA 8D 83            [24] 1547 	mov	dph, r5
      0044DC C0 07            [24] 1548 	push	ar7
      0044DE C0 06            [24] 1549 	push	ar6
      0044E0 C0 02            [24] 1550 	push	ar2
      0044E2 C0 01            [24] 1551 	push	ar1
      0044E4 12 42 8E         [24] 1552 	lcall	_read_offset
      0044E7 AD 82            [24] 1553 	mov	r5, dpl
      0044E9 D0 01            [24] 1554 	pop	ar1
      0044EB D0 02            [24] 1555 	pop	ar2
      0044ED D0 06            [24] 1556 	pop	ar6
      0044EF D0 07            [24] 1557 	pop	ar7
      0044F1 E5 0E            [12] 1558 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      0044F3 2E               [12] 1559 	add	a, r6
      0044F4 F5 82            [12] 1560 	mov	dpl,a
      0044F6 E5 0F            [12] 1561 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      0044F8 3F               [12] 1562 	addc	a, r7
      0044F9 F5 83            [12] 1563 	mov	dph,a
      0044FB E0               [24] 1564 	movx	a,@dptr
      0044FC FC               [12] 1565 	mov	r4,a
      0044FD ED               [12] 1566 	mov	a,r5
      0044FE B5 04 02         [24] 1567 	cjne	a,ar4,00131$
      004501 80 27            [24] 1568 	sjmp	00106$
      004503                       1569 00131$:
                                   1570 ;	keyboards/ajazz/ak820/ak820_nvm.c:265: ak820_eeprom_write_block_xdata(buf, addr, len);
      004503 90 05 A6         [24] 1571 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      004506 E0               [24] 1572 	movx	a,@dptr
      004507 F8               [12] 1573 	mov	r0,a
      004508 A3               [24] 1574 	inc	dptr
      004509 E0               [24] 1575 	movx	a,@dptr
      00450A FD               [12] 1576 	mov	r5,a
      00450B 90 05 9A         [24] 1577 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      00450E E5 12            [12] 1578 	mov	a,_ak820_eeprom_update_block_xdata_sloc2_1_0
      004510 F0               [24] 1579 	movx	@dptr,a
      004511 E5 13            [12] 1580 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
      004513 A3               [24] 1581 	inc	dptr
      004514 F0               [24] 1582 	movx	@dptr,a
      004515 E5 14            [12] 1583 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2)
      004517 A3               [24] 1584 	inc	dptr
      004518 F0               [24] 1585 	movx	@dptr,a
      004519 90 05 9D         [24] 1586 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      00451C E5 10            [12] 1587 	mov	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      00451E F0               [24] 1588 	movx	@dptr,a
      00451F E5 11            [12] 1589 	mov	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      004521 A3               [24] 1590 	inc	dptr
      004522 F0               [24] 1591 	movx	@dptr,a
      004523 88 82            [24] 1592 	mov	dpl, r0
      004525 8D 83            [24] 1593 	mov	dph, r5
                                   1594 ;	keyboards/ajazz/ak820/ak820_nvm.c:266: return;
      004527 02 43 AE         [24] 1595 	ljmp	_ak820_eeprom_write_block_xdata
      00452A                       1596 00106$:
                                   1597 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      00452A 05 0E            [12] 1598 	inc	_ak820_eeprom_update_block_xdata_sloc0_1_0
      00452C E4               [12] 1599 	clr	a
      00452D B5 0E 87         [24] 1600 	cjne	a,_ak820_eeprom_update_block_xdata_sloc0_1_0,00105$
      004530 05 0F            [12] 1601 	inc	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      004532 80 83            [24] 1602 	sjmp	00105$
      004534                       1603 00107$:
                                   1604 ;	keyboards/ajazz/ak820/ak820_nvm.c:269: }
      004534 22               [24] 1605 	ret
                                   1606 ;------------------------------------------------------------
                                   1607 ;Allocation info for local variables in function 'eeprom_driver_erase'
                                   1608 ;------------------------------------------------------------
                                   1609 ;page          Allocated with name '_eeprom_driver_erase_page_10000_134'
                                   1610 ;i             Allocated with name '_eeprom_driver_erase_i_10000_134'
                                   1611 ;------------------------------------------------------------
                                   1612 ;	keyboards/ajazz/ak820/ak820_nvm.c:271: void eeprom_driver_erase(void) {
                                   1613 ;	-----------------------------------------
                                   1614 ;	 function eeprom_driver_erase
                                   1615 ;	-----------------------------------------
      004535                       1616 _eeprom_driver_erase:
                                   1617 ;	keyboards/ajazz/ak820/ak820_nvm.c:274: ak820_nvm_flush();
      004535 12 40 9D         [24] 1618 	lcall	_ak820_nvm_flush
                                   1619 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      004538 7F 00            [12] 1620 	mov	r7,#0x00
      00453A                       1621 00111$:
      00453A BF A0 01         [24] 1622 	cjne	r7,#0xa0,00165$
      00453D 22               [24] 1623 	ret
      00453E                       1624 00165$:
      00453E 20 0A 32         [24] 1625 	jb	_storage_failed,00113$
                                   1626 ;	keyboards/ajazz/ak820/ak820_nvm.c:276: if (!load_page(page)) return;
      004541 8F 82            [24] 1627 	mov	dpl, r7
      004543 C0 07            [24] 1628 	push	ar7
      004545 12 42 1C         [24] 1629 	lcall	_load_page
      004548 E5 82            [12] 1630 	mov	a, dpl
      00454A D0 07            [24] 1631 	pop	ar7
      00454C 70 01            [24] 1632 	jnz	00126$
                                   1633 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      00454E 22               [24] 1634 	ret
      00454F                       1635 00126$:
      00454F 7E 00            [12] 1636 	mov	r6,#0x00
      004551                       1637 00107$:
                                   1638 ;	keyboards/ajazz/ak820/ak820_nvm.c:278: if (page_data[i]) { page_data[i] = 0; page_dirty = true; }
      004551 EE               [12] 1639 	mov	a,r6
      004552 24 29            [12] 1640 	add	a, #_page_data
      004554 FC               [12] 1641 	mov	r4,a
      004555 E4               [12] 1642 	clr	a
      004556 34 05            [12] 1643 	addc	a, #(_page_data >> 8)
      004558 FD               [12] 1644 	mov	r5,a
      004559 12 45 B7         [24] 1645 	lcall	_ak820_outline_0092
      00455C 60 07            [24] 1646 	jz	00108$
      00455E 12 3A 9B         [24] 1647 	lcall	_ak820_outline_0117
      004561 E4               [12] 1648 	clr	a
      004562 F0               [24] 1649 	movx	@dptr,a
                                   1650 ;	assignBit
      004563 D2 09            [12] 1651 	setb	_page_dirty
      004565                       1652 00108$:
                                   1653 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004565 0E               [12] 1654 	inc	r6
      004566 BE 40 E8         [24] 1655 	cjne	r6,#0x40,00107$
                                   1656 ;	keyboards/ajazz/ak820/ak820_nvm.c:280: ak820_nvm_flush();
      004569 C0 07            [24] 1657 	push	ar7
      00456B 12 40 9D         [24] 1658 	lcall	_ak820_nvm_flush
      00456E D0 07            [24] 1659 	pop	ar7
                                   1660 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      004570 0F               [12] 1661 	inc	r7
      004571 80 C7            [24] 1662 	sjmp	00111$
      004573                       1663 00113$:
                                   1664 ;	keyboards/ajazz/ak820/ak820_nvm.c:282: }
      004573 22               [24] 1665 	ret
                                   1666 	.area CSEG    (CODE)
                                   1667 	.area CONST   (CODE)
                                   1668 	.area XINIT   (CODE)
                                   1669 	.area CABS    (ABS,CODE)
                                   1670 
                                   1671 ; Experimental exact instruction outlining.
                                   1672 	.globl _ak820_outline_0004
                                   1673 	.globl _ak820_outline_0011
                                   1674 	.globl _ak820_outline_0016
                                   1675 	.globl _ak820_outline_0017
                                   1676 	.globl _ak820_outline_0030
                                   1677 	.globl _ak820_outline_0037
                                   1678 	.globl _ak820_outline_0041
                                   1679 	.globl _ak820_outline_0051
                                   1680 	.globl _ak820_outline_0052
                                   1681 	.globl _ak820_outline_0060
                                   1682 	.globl _ak820_outline_0061
                                   1683 	.globl _ak820_outline_0065
                                   1684 	.globl _ak820_outline_0071
                                   1685 	.globl _ak820_outline_0077
                                   1686 	.globl _ak820_outline_0092
                                   1687 	.globl _ak820_outline_0093
                                   1688 	.globl _ak820_outline_0100
                                   1689 	.globl _ak820_outline_0101
                                   1690 	.globl _ak820_outline_0103
                                   1691 	.globl _ak820_outline_0104
                                   1692 	.globl _ak820_outline_0116
                                   1693 	.globl _ak820_outline_0117
                                   1694 	.globl _ak820_outline_0120
                                   1695 	.globl _ak820_outline_0121
                                   1696 	.globl _ak820_outline_0122
                                   1697 	.globl _ak820_outline_0131
                                   1698 	.globl _ak820_outline_0132
                                   1699 	.globl _ak820_outline_0134
                                   1700 	.globl _ak820_outline_0139
                                   1701 	.globl _ak820_outline_0140
                                   1702 	.globl _ak820_outline_0145
                                   1703 	.globl _ak820_outline_0153
                                   1704 	.globl _ak820_outline_0156
                                   1705 	.globl _ak820_outline_0157
                                   1706 	.globl _ak820_outline_0167
                                   1707 	.globl _ak820_outline_0179
                                   1708 	.globl _ak820_outline_0180
                                   1709 	.globl _ak820_outline_0184
                                   1710 
                                   1711 	.area CSEG (CODE)
                                   1712 ; function ak820_outline_0011
      004574                       1713 _ak820_outline_0011:
      004574 8E 82            [24] 1714 	mov	dpl,r6
      004576 8F 83            [24] 1715 	mov	dph,r7
      004578 A3               [24] 1716 	inc	dptr
      004579 A3               [24] 1717 	inc	dptr
      00457A A3               [24] 1718 	inc	dptr
      00457B A3               [24] 1719 	inc	dptr
      00457C A3               [24] 1720 	inc	dptr
      00457D 22               [24] 1721 	ret
                                   1722 
                                   1723 	.area CSEG (CODE)
                                   1724 ; function ak820_outline_0030
      00457E                       1725 _ak820_outline_0030:
      00457E F0               [24] 1726 	movx	@dptr,a
      00457F 8E 82            [24] 1727 	mov	dpl,r6
      004581 8F 83            [24] 1728 	mov	dph,r7
      004583 A3               [24] 1729 	inc	dptr
      004584 A3               [24] 1730 	inc	dptr
      004585 22               [24] 1731 	ret
                                   1732 
                                   1733 	.area CSEG (CODE)
                                   1734 ; function ak820_outline_0037
      004586                       1735 _ak820_outline_0037:
      004586 AF F0            [24] 1736 	mov	r7,b
      004588 AE 83            [24] 1737 	mov	r6,dph
      00458A E5 82            [12] 1738 	mov	a,dpl
      00458C 22               [24] 1739 	ret
                                   1740 
                                   1741 	.area CSEG (CODE)
                                   1742 ; function ak820_outline_0041
      00458D                       1743 _ak820_outline_0041:
      00458D EF               [12] 1744 	mov	a,r7
      00458E 24 81            [12] 1745 	add	a,#_ak820_nvm_flush_header_10000_62
      004590 F5 82            [12] 1746 	mov	dpl,a
      004592 E4               [12] 1747 	clr	a
      004593 34 05            [12] 1748 	addc	a,#(_ak820_nvm_flush_header_10000_62>>8)
      004595 F5 83            [12] 1749 	mov	dph,a
      004597 E0               [24] 1750 	movx	a,@dptr
      004598 22               [24] 1751 	ret
                                   1752 
                                   1753 	.area CSEG (CODE)
                                   1754 ; function ak820_outline_0052
      004599                       1755 _ak820_outline_0052:
      004599 8F 06            [24] 1756 	mov	ar6,r7
      00459B 7D 00            [12] 1757 	mov	r5,#0x00
      00459D 74 40            [12] 1758 	mov	a,#0x40
      00459F 2E               [12] 1759 	add	a,r6
      0045A0 FE               [12] 1760 	mov	r6,a
      0045A1 74 EF            [12] 1761 	mov	a,#0xef
      0045A3 3D               [12] 1762 	addc	a,r5
      0045A4 FD               [12] 1763 	mov	r5,a
      0045A5 8E 82            [24] 1764 	mov	dpl,r6
      0045A7 8D 83            [24] 1765 	mov	dph,r5
      0045A9 22               [24] 1766 	ret
                                   1767 
                                   1768 	.area CSEG (CODE)
                                   1769 ; function ak820_outline_0061
      0045AA                       1770 _ak820_outline_0061:
      0045AA F0               [24] 1771 	movx	@dptr,a
      0045AB 8E 82            [24] 1772 	mov	dpl,r6
      0045AD 8F 83            [24] 1773 	mov	dph,r7
      0045AF 22               [24] 1774 	ret
                                   1775 
                                   1776 	.area CSEG (CODE)
                                   1777 ; function ak820_outline_0065
      0045B0                       1778 _ak820_outline_0065:
      0045B0 8D 82            [24] 1779 	mov	dpl,r5
      0045B2 8E 83            [24] 1780 	mov	dph,r6
      0045B4 EC               [12] 1781 	mov	a,r4
      0045B5 F0               [24] 1782 	movx	@dptr,a
      0045B6 22               [24] 1783 	ret
                                   1784 
                                   1785 	.area CSEG (CODE)
                                   1786 ; function ak820_outline_0092
      0045B7                       1787 _ak820_outline_0092:
      0045B7 8C 82            [24] 1788 	mov	dpl,r4
      0045B9 8D 83            [24] 1789 	mov	dph,r5
      0045BB E0               [24] 1790 	movx	a,@dptr
      0045BC 22               [24] 1791 	ret
                                   1792 
                                   1793 	.area CSEG (CODE)
                                   1794 ; function ak820_outline_0093
      0045BD                       1795 _ak820_outline_0093:
      0045BD E0               [24] 1796 	movx	a,@dptr
      0045BE FD               [12] 1797 	mov	r5,a
      0045BF A3               [24] 1798 	inc	dptr
      0045C0 E0               [24] 1799 	movx	a,@dptr
      0045C1 FE               [12] 1800 	mov	r6,a
      0045C2 22               [24] 1801 	ret
                                   1802 
                                   1803 	.area CSEG (CODE)
                                   1804 ; function ak820_outline_0101
      0045C3                       1805 _ak820_outline_0101:
      0045C3 EF               [12] 1806 	mov	a,r7
      0045C4 24 29            [12] 1807 	add	a,#_page_data
      0045C6 F5 82            [12] 1808 	mov	dpl,a
      0045C8 E4               [12] 1809 	clr	a
      0045C9 34 05            [12] 1810 	addc	a,#(_page_data>>8)
      0045CB F5 83            [12] 1811 	mov	dph,a
      0045CD E0               [24] 1812 	movx	a,@dptr
      0045CE 22               [24] 1813 	ret
                                   1814 
                                   1815 	.area CSEG (CODE)
                                   1816 ; function ak820_outline_0116
      0045CF                       1817 _ak820_outline_0116:
      0045CF 8E 82            [24] 1818 	mov	dpl,r6
      0045D1 8F 83            [24] 1819 	mov	dph,r7
      0045D3 22               [24] 1820 	ret
                                   1821 
                                   1822 	.area CSEG (CODE)
                                   1823 ; function ak820_outline_0120
      0045D4                       1824 _ak820_outline_0120:
      0045D4 E0               [24] 1825 	movx	a,@dptr
      0045D5 FA               [12] 1826 	mov	r2,a
      0045D6 A3               [24] 1827 	inc	dptr
      0045D7 E0               [24] 1828 	movx	a,@dptr
      0045D8 FB               [12] 1829 	mov	r3,a
      0045D9 22               [24] 1830 	ret
                                   1831 
                                   1832 	.area CSEG (CODE)
                                   1833 ; function ak820_outline_0131
      0045DA                       1834 _ak820_outline_0131:
      0045DA AE 82            [24] 1835 	mov	r6,dpl
      0045DC AF 83            [24] 1836 	mov	r7,dph
      0045DE 22               [24] 1837 	ret
                                   1838 
                                   1839 	.area CSEG (CODE)
                                   1840 ; function ak820_outline_0134
      0045DF                       1841 _ak820_outline_0134:
      0045DF 2E               [12] 1842 	add	a,r6
      0045E0 FE               [12] 1843 	mov	r6,a
      0045E1 E4               [12] 1844 	clr	a
      0045E2 3F               [12] 1845 	addc	a,r7
      0045E3 FF               [12] 1846 	mov	r7,a
      0045E4 22               [24] 1847 	ret
                                   1848 
                                   1849 	.area CSEG (CODE)
                                   1850 ; function ak820_outline_0139
      0045E5                       1851 _ak820_outline_0139:
      0045E5 42 05            [12] 1852 	orl	ar5,a
      0045E7 EA               [12] 1853 	mov	a,r2
      0045E8 42 04            [12] 1854 	orl	ar4,a
      0045EA 22               [24] 1855 	ret
                                   1856 
                                   1857 	.area CSEG (CODE)
                                   1858 ; function ak820_outline_0140
      0045EB                       1859 _ak820_outline_0140:
      0045EB 8A 82            [24] 1860 	mov	dpl,r2
      0045ED 8B 83            [24] 1861 	mov	dph,r3
      0045EF 22               [24] 1862 	ret
                                   1863 
                                   1864 	.area CSEG (CODE)
                                   1865 ; function ak820_outline_0145
      0045F0                       1866 _ak820_outline_0145:
      0045F0 AC 82            [24] 1867 	mov	r4,dpl
      0045F2 AD 83            [24] 1868 	mov	r5,dph
      0045F4 22               [24] 1869 	ret
                                   1870 
                                   1871 	.area CSEG (CODE)
                                   1872 ; function ak820_outline_0153
      0045F5                       1873 _ak820_outline_0153:
      0045F5 8F 82            [24] 1874 	mov	dpl,r7
      0045F7 8E 83            [24] 1875 	mov	dph,r6
      0045F9 22               [24] 1876 	ret
                                   1877 
                                   1878 	.area CSEG (CODE)
                                   1879 ; function ak820_outline_0156
      0045FA                       1880 _ak820_outline_0156:
      0045FA 2E               [12] 1881 	add	a,r6
      0045FB FC               [12] 1882 	mov	r4,a
      0045FC E4               [12] 1883 	clr	a
      0045FD 3F               [12] 1884 	addc	a,r7
      0045FE FD               [12] 1885 	mov	r5,a
      0045FF 22               [24] 1886 	ret
                                   1887 
                                   1888 	.area CSEG (CODE)
                                   1889 ; function ak820_outline_0157
      004600                       1890 _ak820_outline_0157:
      004600 ED               [12] 1891 	mov	a,r5
      004601 F0               [24] 1892 	movx	@dptr,a
      004602 EE               [12] 1893 	mov	a,r6
      004603 A3               [24] 1894 	inc	dptr
      004604 F0               [24] 1895 	movx	@dptr,a
      004605 22               [24] 1896 	ret
                                   1897 
                                   1898 	.area CSEG (CODE)
                                   1899 ; function ak820_outline_0179
      004606                       1900 _ak820_outline_0179:
      004606 89 82            [24] 1901 	mov	dpl,r1
      004608 8A 83            [24] 1902 	mov	dph,r2
      00460A 22               [24] 1903 	ret
                                   1904 
                                   1905 	.area CSEG (CODE)
                                   1906 ; function ak820_outline_0180
      00460B                       1907 _ak820_outline_0180:
      00460B 8C 82            [24] 1908 	mov	dpl,r4
      00460D 8B 83            [24] 1909 	mov	dph,r3
      00460F 22               [24] 1910 	ret
                                   1911 
                                   1912 	.area CSEG (CODE)
                                   1913 ; function ak820_outline_0184
      004610                       1914 _ak820_outline_0184:
      004610 8D 82            [24] 1915 	mov	dpl,r5
      004612 8C 83            [24] 1916 	mov	dph,r4
      004614 22               [24] 1917 	ret
