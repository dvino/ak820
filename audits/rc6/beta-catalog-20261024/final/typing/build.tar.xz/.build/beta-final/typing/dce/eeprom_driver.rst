                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module eeprom_driver
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_eeprom_write_block_xdata
                                     12 	.globl _ak820_eeprom_read_block_xdata
                                     13 	.globl _eeprom_read_byte
                                     14 	.globl _eeprom_update_dword_PARM_2
                                     15 	.globl _eeprom_update_word_PARM_2
                                     16 	.globl _eeprom_update_byte_PARM_2
                                     17 	.globl _eeprom_write_dword_PARM_2
                                     18 	.globl _eeprom_write_word_PARM_2
                                     19 	.globl _eeprom_write_byte_PARM_2
                                     20 	.globl _eeprom_read_word
                                     21 	.globl _eeprom_read_dword
                                     22 	.globl _eeprom_write_byte
                                     23 	.globl _eeprom_write_word
                                     24 	.globl _eeprom_write_dword
                                     25 	.globl _eeprom_update_byte
                                     26 	.globl _eeprom_update_word
                                     27 	.globl _eeprom_update_dword
                                     28 ;--------------------------------------------------------
                                     29 ; special function registers
                                     30 ;--------------------------------------------------------
                                     31 	.area RSEG    (ABS,DATA)
      000000                         32 	.org 0x0000
                                     33 ;--------------------------------------------------------
                                     34 ; special function bits
                                     35 ;--------------------------------------------------------
                                     36 	.area RSEG    (ABS,DATA)
      000000                         37 	.org 0x0000
                                     38 ;--------------------------------------------------------
                                     39 ; overlayable register banks
                                     40 ;--------------------------------------------------------
                                     41 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         42 	.ds 8
                                     43 ;--------------------------------------------------------
                                     44 ; overlayable bit register bank
                                     45 ;--------------------------------------------------------
                                     46 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         47 bits:
      000026                         48 	.ds 1
                           008000    49 	b0 = bits[0]
                           008100    50 	b1 = bits[1]
                           008200    51 	b2 = bits[2]
                           008300    52 	b3 = bits[3]
                           008400    53 	b4 = bits[4]
                           008500    54 	b5 = bits[5]
                           008600    55 	b6 = bits[6]
                           008700    56 	b7 = bits[7]
                                     57 ;--------------------------------------------------------
                                     58 ; internal ram data
                                     59 ;--------------------------------------------------------
                                     60 	.area DSEG    (DATA)
                                     61 ;--------------------------------------------------------
                                     62 ; overlayable items in internal ram
                                     63 ;--------------------------------------------------------
                                     64 ;--------------------------------------------------------
                                     65 ; indirectly addressable internal ram data
                                     66 ;--------------------------------------------------------
                                     67 	.area ISEG    (DATA)
                                     68 ;--------------------------------------------------------
                                     69 ; absolute internal ram data
                                     70 ;--------------------------------------------------------
                                     71 	.area IABS    (ABS,DATA)
                                     72 	.area IABS    (ABS,DATA)
                                     73 ;--------------------------------------------------------
                                     74 ; bit data
                                     75 ;--------------------------------------------------------
                                     76 	.area BSEG    (BIT)
                                     77 ;--------------------------------------------------------
                                     78 ; paged external ram data
                                     79 ;--------------------------------------------------------
                                     80 	.area PSEG    (PAG,XDATA)
                                     81 ;--------------------------------------------------------
                                     82 ; uninitialized external ram data
                                     83 ;--------------------------------------------------------
                                     84 	.area XSEG    (XDATA)
      000693                         85 _eeprom_read_word_addr_10000_91:
      000693                         86 	.ds 3
      000696                         87 _eeprom_read_word_ret_10000_92:
      000696                         88 	.ds 2
      000698                         89 _eeprom_read_dword_addr_10000_93:
      000698                         90 	.ds 3
      00069B                         91 _eeprom_read_dword_ret_10000_94:
      00069B                         92 	.ds 4
      00069F                         93 _eeprom_write_byte_PARM_2:
      00069F                         94 	.ds 1
      0006A0                         95 _eeprom_write_byte_addr_10000_95:
      0006A0                         96 	.ds 3
      0006A3                         97 _eeprom_write_word_PARM_2:
      0006A3                         98 	.ds 2
      0006A5                         99 _eeprom_write_word_addr_10000_97:
      0006A5                        100 	.ds 3
      0006A8                        101 _eeprom_write_dword_PARM_2:
      0006A8                        102 	.ds 4
      0006AC                        103 _eeprom_write_dword_addr_10000_99:
      0006AC                        104 	.ds 3
      0006AF                        105 _eeprom_update_byte_PARM_2:
      0006AF                        106 	.ds 1
      0006B0                        107 _eeprom_update_byte_addr_10000_107:
      0006B0                        108 	.ds 3
      0006B3                        109 _eeprom_update_word_PARM_2:
      0006B3                        110 	.ds 2
      0006B5                        111 _eeprom_update_word_addr_10000_111:
      0006B5                        112 	.ds 3
      0006B8                        113 _eeprom_update_dword_PARM_2:
      0006B8                        114 	.ds 4
      0006BC                        115 _eeprom_update_dword_addr_10000_115:
      0006BC                        116 	.ds 3
                                    117 ;--------------------------------------------------------
                                    118 ; absolute external ram data
                                    119 ;--------------------------------------------------------
                                    120 	.area XABS    (ABS,XDATA)
                                    121 ;--------------------------------------------------------
                                    122 ; initialized external ram data
                                    123 ;--------------------------------------------------------
                                    124 	.area XISEG   (XDATA)
                                    125 	.area HOME    (CODE)
                                    126 	.area GSINIT0 (CODE)
                                    127 	.area GSINIT1 (CODE)
                                    128 	.area GSINIT2 (CODE)
                                    129 	.area GSINIT3 (CODE)
                                    130 	.area GSINIT4 (CODE)
                                    131 	.area GSINIT5 (CODE)
                                    132 	.area GSINIT  (CODE)
                                    133 	.area GSFINAL (CODE)
                                    134 	.area CSEG    (CODE)
                                    135 ;--------------------------------------------------------
                                    136 ; global & static initialisations
                                    137 ;--------------------------------------------------------
                                    138 	.area HOME    (CODE)
                                    139 	.area GSINIT  (CODE)
                                    140 	.area GSFINAL (CODE)
                                    141 	.area GSINIT  (CODE)
                                    142 ;--------------------------------------------------------
                                    143 ; Home
                                    144 ;--------------------------------------------------------
                                    145 	.area HOME    (CODE)
                                    146 	.area HOME    (CODE)
                                    147 ;--------------------------------------------------------
                                    148 ; code
                                    149 ;--------------------------------------------------------
                                    150 	.area CSEG    (CODE)
                                    151 ;------------------------------------------------------------
                                    152 ;Allocation info for local variables in function 'eeprom_read_word'
                                    153 ;------------------------------------------------------------
                                    154 ;addr          Allocated with name '_eeprom_read_word_addr_10000_91'
                                    155 ;ret           Allocated with name '_eeprom_read_word_ret_10000_92'
                                    156 ;------------------------------------------------------------
                                    157 ;	drivers/eeprom/eeprom_driver.c:44: uint16_t eeprom_read_word(const uint16_t *addr) {
                                    158 ;	-----------------------------------------
                                    159 ;	 function eeprom_read_word
                                    160 ;	-----------------------------------------
      00503C                        161 _eeprom_read_word:
                           000007   162 	ar7 = 0x07
                           000006   163 	ar6 = 0x06
                           000005   164 	ar5 = 0x05
                           000004   165 	ar4 = 0x04
                           000003   166 	ar3 = 0x03
                           000002   167 	ar2 = 0x02
                           000001   168 	ar1 = 0x01
                           000000   169 	ar0 = 0x00
      00503C 12 45 80         [24]  170 	lcall	_ak820_outline_0037
      00503F 90 06 93         [24]  171 	mov	dptr,#_eeprom_read_word_addr_10000_91
      005042 12 3A 20         [24]  172 	lcall	_ak820_outline_0016
                                    173 ;	drivers/eeprom/eeprom_driver.c:45: uint16_t ret = 0;
      005045 90 06 96         [24]  174 	mov	dptr,#_eeprom_read_word_ret_10000_92
      005048 12 52 48         [24]  175 	lcall	_ak820_outline_0166
                                    176 ;	drivers/eeprom/eeprom_driver.c:46: EEPROM_LOCAL_READ(&ret, addr, 2);
      00504B 90 06 93         [24]  177 	mov	dptr,#_eeprom_read_word_addr_10000_91
      00504E 12 51 F6         [24]  178 	lcall	_ak820_outline_0022
      005051 90 05 91         [24]  179 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      005054 ED               [12]  180 	mov	a,r5
      005055 12 3A 20         [24]  181 	lcall	_ak820_outline_0016
      005058 90 05 94         [24]  182 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      00505B 12 52 3A         [24]  183 	lcall	_ak820_outline_0106
      00505E 90 06 96         [24]  184 	mov	dptr,#_eeprom_read_word_ret_10000_92
      005061 12 43 1C         [24]  185 	lcall	_ak820_eeprom_read_block_xdata
                                    186 ;	drivers/eeprom/eeprom_driver.c:47: return ret;
      005064 90 06 96         [24]  187 	mov	dptr,#_eeprom_read_word_ret_10000_92
      005067 12 52 31         [24]  188 	lcall	_ak820_outline_0089
                                    189 ;	drivers/eeprom/eeprom_driver.c:48: }
      00506A 22               [24]  190 	ret
                                    191 ;------------------------------------------------------------
                                    192 ;Allocation info for local variables in function 'eeprom_read_dword'
                                    193 ;------------------------------------------------------------
                                    194 ;addr          Allocated with name '_eeprom_read_dword_addr_10000_93'
                                    195 ;ret           Allocated with name '_eeprom_read_dword_ret_10000_94'
                                    196 ;------------------------------------------------------------
                                    197 ;	drivers/eeprom/eeprom_driver.c:50: uint32_t eeprom_read_dword(const uint32_t *addr) {
                                    198 ;	-----------------------------------------
                                    199 ;	 function eeprom_read_dword
                                    200 ;	-----------------------------------------
      00506B                        201 _eeprom_read_dword:
      00506B 12 45 80         [24]  202 	lcall	_ak820_outline_0037
      00506E 90 06 98         [24]  203 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      005071 12 3A 20         [24]  204 	lcall	_ak820_outline_0016
                                    205 ;	drivers/eeprom/eeprom_driver.c:51: uint32_t ret = 0;
      005074 90 06 9B         [24]  206 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      005077 12 52 06         [24]  207 	lcall	_ak820_outline_0049
                                    208 ;	drivers/eeprom/eeprom_driver.c:52: EEPROM_LOCAL_READ(&ret, addr, 4);
      00507A 90 06 98         [24]  209 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      00507D 12 51 F6         [24]  210 	lcall	_ak820_outline_0022
      005080 90 05 91         [24]  211 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      005083 ED               [12]  212 	mov	a,r5
      005084 12 3A 20         [24]  213 	lcall	_ak820_outline_0016
      005087 90 05 94         [24]  214 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      00508A 74 04            [12]  215 	mov	a,#0x04
      00508C 12 3A A0         [24]  216 	lcall	_ak820_outline_0123
      00508F 90 06 9B         [24]  217 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      005092 12 43 1C         [24]  218 	lcall	_ak820_eeprom_read_block_xdata
                                    219 ;	drivers/eeprom/eeprom_driver.c:53: return ret;
      005095 90 06 9B         [24]  220 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      005098 12 52 0F         [24]  221 	lcall	_ak820_outline_0054
                                    222 ;	drivers/eeprom/eeprom_driver.c:54: }
      00509B 22               [24]  223 	ret
                                    224 ;------------------------------------------------------------
                                    225 ;Allocation info for local variables in function 'eeprom_write_byte'
                                    226 ;------------------------------------------------------------
                                    227 ;value         Allocated with name '_eeprom_write_byte_PARM_2'
                                    228 ;addr          Allocated with name '_eeprom_write_byte_addr_10000_95'
                                    229 ;------------------------------------------------------------
                                    230 ;	drivers/eeprom/eeprom_driver.c:56: void eeprom_write_byte(uint8_t *addr, uint8_t value) {
                                    231 ;	-----------------------------------------
                                    232 ;	 function eeprom_write_byte
                                    233 ;	-----------------------------------------
      00509C                        234 _eeprom_write_byte:
      00509C 12 45 80         [24]  235 	lcall	_ak820_outline_0037
      00509F 90 06 A0         [24]  236 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      0050A2 12 3A 20         [24]  237 	lcall	_ak820_outline_0016
                                    238 ;	drivers/eeprom/eeprom_driver.c:57: EEPROM_LOCAL_WRITE(&value, addr, 1);
      0050A5 90 06 A0         [24]  239 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      0050A8 12 51 D0         [24]  240 	lcall	_ak820_outline_0002
      0050AB 74 01            [12]  241 	mov	a,#0x01
      0050AD 12 3A A0         [24]  242 	lcall	_ak820_outline_0123
      0050B0 90 06 9F         [24]  243 	mov	dptr,#_eeprom_write_byte_PARM_2
                                    244 ;	drivers/eeprom/eeprom_driver.c:58: }
      0050B3 02 43 A8         [24]  245 	ljmp	_ak820_eeprom_write_block_xdata
                                    246 ;------------------------------------------------------------
                                    247 ;Allocation info for local variables in function 'eeprom_write_word'
                                    248 ;------------------------------------------------------------
                                    249 ;value         Allocated with name '_eeprom_write_word_PARM_2'
                                    250 ;addr          Allocated with name '_eeprom_write_word_addr_10000_97'
                                    251 ;------------------------------------------------------------
                                    252 ;	drivers/eeprom/eeprom_driver.c:60: void eeprom_write_word(uint16_t *addr, uint16_t value) {
                                    253 ;	-----------------------------------------
                                    254 ;	 function eeprom_write_word
                                    255 ;	-----------------------------------------
      0050B6                        256 _eeprom_write_word:
      0050B6 12 45 80         [24]  257 	lcall	_ak820_outline_0037
      0050B9 90 06 A5         [24]  258 	mov	dptr,#_eeprom_write_word_addr_10000_97
      0050BC 12 3A 20         [24]  259 	lcall	_ak820_outline_0016
                                    260 ;	drivers/eeprom/eeprom_driver.c:61: EEPROM_LOCAL_WRITE(&value, addr, 2);
      0050BF 90 06 A5         [24]  261 	mov	dptr,#_eeprom_write_word_addr_10000_97
      0050C2 12 51 D0         [24]  262 	lcall	_ak820_outline_0002
      0050C5 12 52 3A         [24]  263 	lcall	_ak820_outline_0106
      0050C8 90 06 A3         [24]  264 	mov	dptr,#_eeprom_write_word_PARM_2
                                    265 ;	drivers/eeprom/eeprom_driver.c:62: }
      0050CB 02 43 A8         [24]  266 	ljmp	_ak820_eeprom_write_block_xdata
                                    267 ;------------------------------------------------------------
                                    268 ;Allocation info for local variables in function 'eeprom_write_dword'
                                    269 ;------------------------------------------------------------
                                    270 ;value         Allocated with name '_eeprom_write_dword_PARM_2'
                                    271 ;addr          Allocated with name '_eeprom_write_dword_addr_10000_99'
                                    272 ;------------------------------------------------------------
                                    273 ;	drivers/eeprom/eeprom_driver.c:64: void eeprom_write_dword(uint32_t *addr, uint32_t value) {
                                    274 ;	-----------------------------------------
                                    275 ;	 function eeprom_write_dword
                                    276 ;	-----------------------------------------
      0050CE                        277 _eeprom_write_dword:
      0050CE 12 45 80         [24]  278 	lcall	_ak820_outline_0037
      0050D1 90 06 AC         [24]  279 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      0050D4 12 3A 20         [24]  280 	lcall	_ak820_outline_0016
                                    281 ;	drivers/eeprom/eeprom_driver.c:65: EEPROM_LOCAL_WRITE(&value, addr, 4);
      0050D7 90 06 AC         [24]  282 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      0050DA 12 51 D0         [24]  283 	lcall	_ak820_outline_0002
      0050DD 74 04            [12]  284 	mov	a,#0x04
      0050DF 12 3A A0         [24]  285 	lcall	_ak820_outline_0123
      0050E2 90 06 A8         [24]  286 	mov	dptr,#_eeprom_write_dword_PARM_2
                                    287 ;	drivers/eeprom/eeprom_driver.c:66: }
      0050E5 02 43 A8         [24]  288 	ljmp	_ak820_eeprom_write_block_xdata
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'eeprom_update_block'
                                    291 ;------------------------------------------------------------
                                    292 ;sloc0         Allocated with name '_eeprom_update_block_sloc0_1_0'
                                    293 ;sloc1         Allocated with name '_eeprom_update_block_sloc1_1_0'
                                    294 ;sloc2         Allocated with name '_eeprom_update_block_sloc2_1_0'
                                    295 ;sloc3         Allocated with name '_eeprom_update_block_sloc3_1_0'
                                    296 ;addr          Allocated with name '_eeprom_update_block_PARM_2'
                                    297 ;len           Allocated with name '_eeprom_update_block_PARM_3'
                                    298 ;buf           Allocated with name '_eeprom_update_block_buf_10000_101'
                                    299 ;source        Allocated with name '_eeprom_update_block_source_10000_102'
                                    300 ;target        Allocated with name '_eeprom_update_block_target_10000_102'
                                    301 ;i             Allocated with name '_eeprom_update_block_i_10000_102'
                                    302 ;------------------------------------------------------------
                                    303 ;	drivers/eeprom/eeprom_driver.c:68: void eeprom_update_block(const void *buf, void *addr, size_t len) {
                                    304 ;	-----------------------------------------
                                    305 ;	 function eeprom_update_byte
                                    306 ;	-----------------------------------------
      0050E8                        307 _eeprom_update_byte:
      0050E8 C0 07            [24]  308 	push	ar7
      0050EA C0 06            [24]  309 	push	ar6
      0050EC C0 05            [24]  310 	push	ar5
      0050EE C0 04            [24]  311 	push	ar4
      0050F0 12 45 80         [24]  312 	lcall	_ak820_outline_0037
      0050F3 90 06 B0         [24]  313 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      0050F6 12 3A 20         [24]  314 	lcall	_ak820_outline_0016
                                    315 ;	drivers/eeprom/eeprom_driver.c:83: uint8_t orig = eeprom_read_byte(addr);
      0050F9 90 06 B0         [24]  316 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      0050FC 12 51 E7         [24]  317 	lcall	_ak820_outline_0003
      0050FF 12 42 E1         [24]  318 	lcall	_eeprom_read_byte
      005102 AF 82            [24]  319 	mov	r7, dpl
                                    320 ;	drivers/eeprom/eeprom_driver.c:84: if (orig != value) {
      005104 90 06 AF         [24]  321 	mov	dptr,#_eeprom_update_byte_PARM_2
      005107 E0               [24]  322 	movx	a,@dptr
      005108 FE               [12]  323 	mov	r6,a
      005109 EF               [12]  324 	mov	a,r7
      00510A B5 06 02         [24]  325 	cjne	a,ar6,00112$
      00510D 80 36            [24]  326 	sjmp	00103$
      00510F                        327 00112$:
                                    328 ;	drivers/eeprom/eeprom_driver.c:85: eeprom_write_byte(addr, value);
      00510F 90 06 B0         [24]  329 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      005112 12 3A 60         [24]  330 	lcall	_ak820_outline_0060
      005115 A3               [24]  331 	inc	dptr
      005116 E0               [24]  332 	movx	a,@dptr
      005117 FF               [12]  333 	mov	r7,a
      005118 90 06 9F         [24]  334 	mov	dptr,#_eeprom_write_byte_PARM_2
      00511B EE               [12]  335 	mov	a,r6
      00511C F0               [24]  336 	movx	@dptr,a
      00511D 12 3A 95         [24]  337 	lcall	_ak820_outline_0117
      005120 8F F0            [24]  338 	mov	b, r7
      005122 C0 07            [24]  339 	push	ar7
      005124 C0 06            [24]  340 	push	ar6
      005126 C0 05            [24]  341 	push	ar5
      005128 C0 04            [24]  342 	push	ar4
      00512A C0 03            [24]  343 	push	ar3
      00512C C0 02            [24]  344 	push	ar2
      00512E C0 01            [24]  345 	push	ar1
      005130 C0 00            [24]  346 	push	ar0
      005132 12 50 9C         [24]  347 	lcall	_eeprom_write_byte
      005135 D0 00            [24]  348 	pop	ar0
      005137 D0 01            [24]  349 	pop	ar1
      005139 D0 02            [24]  350 	pop	ar2
      00513B D0 03            [24]  351 	pop	ar3
      00513D D0 04            [24]  352 	pop	ar4
      00513F D0 05            [24]  353 	pop	ar5
      005141 D0 06            [24]  354 	pop	ar6
      005143 D0 07            [24]  355 	pop	ar7
      005145                        356 00103$:
                                    357 ;	drivers/eeprom/eeprom_driver.c:87: }
      005145 D0 04            [24]  358 	pop	ar4
      005147 D0 05            [24]  359 	pop	ar5
      005149 D0 06            [24]  360 	pop	ar6
      00514B D0 07            [24]  361 	pop	ar7
      00514D 22               [24]  362 	ret
                                    363 ;------------------------------------------------------------
                                    364 ;Allocation info for local variables in function 'eeprom_update_word'
                                    365 ;------------------------------------------------------------
                                    366 ;value         Allocated with name '_eeprom_update_word_PARM_2'
                                    367 ;addr          Allocated with name '_eeprom_update_word_addr_10000_111'
                                    368 ;orig          Allocated with name '_eeprom_update_word_orig_10000_112'
                                    369 ;------------------------------------------------------------
                                    370 ;	drivers/eeprom/eeprom_driver.c:89: void eeprom_update_word(uint16_t *addr, uint16_t value) {
                                    371 ;	-----------------------------------------
                                    372 ;	 function eeprom_update_word
                                    373 ;	-----------------------------------------
      00514E                        374 _eeprom_update_word:
      00514E 12 45 80         [24]  375 	lcall	_ak820_outline_0037
      005151 90 06 B5         [24]  376 	mov	dptr,#_eeprom_update_word_addr_10000_111
      005154 12 3A 20         [24]  377 	lcall	_ak820_outline_0016
                                    378 ;	drivers/eeprom/eeprom_driver.c:90: uint16_t orig = eeprom_read_word(addr);
      005157 90 06 B5         [24]  379 	mov	dptr,#_eeprom_update_word_addr_10000_111
      00515A 12 51 E7         [24]  380 	lcall	_ak820_outline_0003
      00515D 12 50 3C         [24]  381 	lcall	_eeprom_read_word
      005160 12 45 D4         [24]  382 	lcall	_ak820_outline_0131
                                    383 ;	drivers/eeprom/eeprom_driver.c:91: if (orig != value) {
      005163 90 06 B3         [24]  384 	mov	dptr,#_eeprom_update_word_PARM_2
      005166 12 3A 60         [24]  385 	lcall	_ak820_outline_0060
      005169 EE               [12]  386 	mov	a,r6
      00516A B5 04 05         [24]  387 	cjne	a,ar4,00112$
      00516D EF               [12]  388 	mov	a,r7
      00516E B5 05 01         [24]  389 	cjne	a,ar5,00112$
      005171 22               [24]  390 	ret
      005172                        391 00112$:
                                    392 ;	drivers/eeprom/eeprom_driver.c:92: eeprom_write_word(addr, value);
      005172 90 06 B5         [24]  393 	mov	dptr,#_eeprom_update_word_addr_10000_111
      005175 E0               [24]  394 	movx	a,@dptr
      005176 FB               [12]  395 	mov	r3,a
      005177 A3               [24]  396 	inc	dptr
      005178 12 3A 41         [24]  397 	lcall	_ak820_outline_0051
      00517B 90 06 A3         [24]  398 	mov	dptr,#_eeprom_write_word_PARM_2
      00517E 12 3A 66         [24]  399 	lcall	_ak820_outline_0071
      005181 8B 82            [24]  400 	mov	dpl, r3
      005183 8E 83            [24]  401 	mov	dph, r6
      005185 8F F0            [24]  402 	mov	b, r7
                                    403 ;	drivers/eeprom/eeprom_driver.c:94: }
      005187 02 50 B6         [24]  404 	ljmp	_eeprom_write_word
                                    405 ;------------------------------------------------------------
                                    406 ;Allocation info for local variables in function 'eeprom_update_dword'
                                    407 ;------------------------------------------------------------
                                    408 ;value         Allocated with name '_eeprom_update_dword_PARM_2'
                                    409 ;addr          Allocated with name '_eeprom_update_dword_addr_10000_115'
                                    410 ;orig          Allocated with name '_eeprom_update_dword_orig_10000_116'
                                    411 ;------------------------------------------------------------
                                    412 ;	drivers/eeprom/eeprom_driver.c:96: void eeprom_update_dword(uint32_t *addr, uint32_t value) {
                                    413 ;	-----------------------------------------
                                    414 ;	 function eeprom_update_dword
                                    415 ;	-----------------------------------------
      00518A                        416 _eeprom_update_dword:
      00518A 12 45 80         [24]  417 	lcall	_ak820_outline_0037
      00518D 90 06 BC         [24]  418 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      005190 12 3A 20         [24]  419 	lcall	_ak820_outline_0016
                                    420 ;	drivers/eeprom/eeprom_driver.c:97: uint32_t orig = eeprom_read_dword(addr);
      005193 90 06 BC         [24]  421 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      005196 12 51 E7         [24]  422 	lcall	_ak820_outline_0003
      005199 12 50 6B         [24]  423 	lcall	_eeprom_read_dword
      00519C 12 52 20         [24]  424 	lcall	_ak820_outline_0057
                                    425 ;	drivers/eeprom/eeprom_driver.c:98: if (orig != value) {
      00519F 90 06 B8         [24]  426 	mov	dptr,#_eeprom_update_dword_PARM_2
      0051A2 E0               [24]  427 	movx	a,@dptr
      0051A3 F8               [12]  428 	mov	r0,a
      0051A4 A3               [24]  429 	inc	dptr
      0051A5 12 52 28         [24]  430 	lcall	_ak820_outline_0088
      0051A8 EC               [12]  431 	mov	a,r4
      0051A9 B5 00 0D         [24]  432 	cjne	a,ar0,00112$
      0051AC ED               [12]  433 	mov	a,r5
      0051AD B5 01 09         [24]  434 	cjne	a,ar1,00112$
      0051B0 EE               [12]  435 	mov	a,r6
      0051B1 B5 02 05         [24]  436 	cjne	a,ar2,00112$
      0051B4 EF               [12]  437 	mov	a,r7
      0051B5 B5 03 01         [24]  438 	cjne	a,ar3,00112$
      0051B8 22               [24]  439 	ret
      0051B9                        440 00112$:
                                    441 ;	drivers/eeprom/eeprom_driver.c:99: eeprom_write_dword(addr, value);
      0051B9 90 06 BC         [24]  442 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      0051BC 12 51 F6         [24]  443 	lcall	_ak820_outline_0022
      0051BF 90 06 A8         [24]  444 	mov	dptr,#_eeprom_write_dword_PARM_2
      0051C2 E8               [12]  445 	mov	a,r0
      0051C3 F0               [24]  446 	movx	@dptr,a
      0051C4 E9               [12]  447 	mov	a,r1
      0051C5 A3               [24]  448 	inc	dptr
      0051C6 12 52 41         [24]  449 	lcall	_ak820_outline_0151
      0051C9 F0               [24]  450 	movx	@dptr,a
      0051CA 12 51 FF         [24]  451 	lcall	_ak820_outline_0044
                                    452 ;	drivers/eeprom/eeprom_driver.c:101: }
      0051CD 02 50 CE         [24]  453 	ljmp	_eeprom_write_dword
                                    454 	.area CSEG    (CODE)
                                    455 	.area CONST   (CODE)
                                    456 	.area XINIT   (CODE)
                                    457 	.area CABS    (ABS,CODE)
                                    458 
                                    459 ; Experimental exact instruction outlining.
                                    460 	.globl _ak820_outline_0002
                                    461 	.globl _ak820_outline_0003
                                    462 	.globl _ak820_outline_0016
                                    463 	.globl _ak820_outline_0022
                                    464 	.globl _ak820_outline_0037
                                    465 	.globl _ak820_outline_0044
                                    466 	.globl _ak820_outline_0049
                                    467 	.globl _ak820_outline_0051
                                    468 	.globl _ak820_outline_0054
                                    469 	.globl _ak820_outline_0057
                                    470 	.globl _ak820_outline_0060
                                    471 	.globl _ak820_outline_0071
                                    472 	.globl _ak820_outline_0088
                                    473 	.globl _ak820_outline_0089
                                    474 	.globl _ak820_outline_0106
                                    475 	.globl _ak820_outline_0117
                                    476 	.globl _ak820_outline_0123
                                    477 	.globl _ak820_outline_0131
                                    478 	.globl _ak820_outline_0151
                                    479 	.globl _ak820_outline_0166
                                    480 
                                    481 	.area CSEG (CODE)
                                    482 ; function ak820_outline_0002
      0051D0                        483 _ak820_outline_0002:
      0051D0 E0               [24]  484 	movx	a,@dptr
      0051D1 FD               [12]  485 	mov	r5,a
      0051D2 A3               [24]  486 	inc	dptr
      0051D3 E0               [24]  487 	movx	a,@dptr
      0051D4 FE               [12]  488 	mov	r6,a
      0051D5 A3               [24]  489 	inc	dptr
      0051D6 E0               [24]  490 	movx	a,@dptr
      0051D7 FF               [12]  491 	mov	r7,a
      0051D8 90 05 9A         [24]  492 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      0051DB ED               [12]  493 	mov	a,r5
      0051DC F0               [24]  494 	movx	@dptr,a
      0051DD EE               [12]  495 	mov	a,r6
      0051DE A3               [24]  496 	inc	dptr
      0051DF F0               [24]  497 	movx	@dptr,a
      0051E0 EF               [12]  498 	mov	a,r7
      0051E1 A3               [24]  499 	inc	dptr
      0051E2 F0               [24]  500 	movx	@dptr,a
      0051E3 90 05 9D         [24]  501 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0051E6 22               [24]  502 	ret
                                    503 
                                    504 	.area CSEG (CODE)
                                    505 ; function ak820_outline_0003
      0051E7                        506 _ak820_outline_0003:
      0051E7 E0               [24]  507 	movx	a,@dptr
      0051E8 FD               [12]  508 	mov	r5,a
      0051E9 A3               [24]  509 	inc	dptr
      0051EA E0               [24]  510 	movx	a,@dptr
      0051EB FE               [12]  511 	mov	r6,a
      0051EC A3               [24]  512 	inc	dptr
      0051ED E0               [24]  513 	movx	a,@dptr
      0051EE FF               [12]  514 	mov	r7,a
      0051EF 8D 82            [24]  515 	mov	dpl,r5
      0051F1 8E 83            [24]  516 	mov	dph,r6
      0051F3 8F F0            [24]  517 	mov	b,r7
      0051F5 22               [24]  518 	ret
                                    519 
                                    520 	.area CSEG (CODE)
                                    521 ; function ak820_outline_0022
      0051F6                        522 _ak820_outline_0022:
      0051F6 E0               [24]  523 	movx	a,@dptr
      0051F7 FD               [12]  524 	mov	r5,a
      0051F8 A3               [24]  525 	inc	dptr
      0051F9 E0               [24]  526 	movx	a,@dptr
      0051FA FE               [12]  527 	mov	r6,a
      0051FB A3               [24]  528 	inc	dptr
      0051FC E0               [24]  529 	movx	a,@dptr
      0051FD FF               [12]  530 	mov	r7,a
      0051FE 22               [24]  531 	ret
                                    532 
                                    533 	.area CSEG (CODE)
                                    534 ; function ak820_outline_0044
      0051FF                        535 _ak820_outline_0044:
      0051FF 8D 82            [24]  536 	mov	dpl,r5
      005201 8E 83            [24]  537 	mov	dph,r6
      005203 8F F0            [24]  538 	mov	b,r7
      005205 22               [24]  539 	ret
                                    540 
                                    541 	.area CSEG (CODE)
                                    542 ; function ak820_outline_0049
      005206                        543 _ak820_outline_0049:
      005206 E4               [12]  544 	clr	a
      005207 F0               [24]  545 	movx	@dptr,a
      005208 A3               [24]  546 	inc	dptr
      005209 F0               [24]  547 	movx	@dptr,a
      00520A A3               [24]  548 	inc	dptr
      00520B F0               [24]  549 	movx	@dptr,a
      00520C A3               [24]  550 	inc	dptr
      00520D F0               [24]  551 	movx	@dptr,a
      00520E 22               [24]  552 	ret
                                    553 
                                    554 	.area CSEG (CODE)
                                    555 ; function ak820_outline_0054
      00520F                        556 _ak820_outline_0054:
      00520F E0               [24]  557 	movx	a,@dptr
      005210 FC               [12]  558 	mov	r4,a
      005211 A3               [24]  559 	inc	dptr
      005212 E0               [24]  560 	movx	a,@dptr
      005213 FD               [12]  561 	mov	r5,a
      005214 A3               [24]  562 	inc	dptr
      005215 E0               [24]  563 	movx	a,@dptr
      005216 FE               [12]  564 	mov	r6,a
      005217 A3               [24]  565 	inc	dptr
      005218 E0               [24]  566 	movx	a,@dptr
      005219 8C 82            [24]  567 	mov	dpl,r4
      00521B 8D 83            [24]  568 	mov	dph,r5
      00521D 8E F0            [24]  569 	mov	b,r6
      00521F 22               [24]  570 	ret
                                    571 
                                    572 	.area CSEG (CODE)
                                    573 ; function ak820_outline_0057
      005220                        574 _ak820_outline_0057:
      005220 AC 82            [24]  575 	mov	r4,dpl
      005222 AD 83            [24]  576 	mov	r5,dph
      005224 AE F0            [24]  577 	mov	r6,b
      005226 FF               [12]  578 	mov	r7,a
      005227 22               [24]  579 	ret
                                    580 
                                    581 	.area CSEG (CODE)
                                    582 ; function ak820_outline_0088
      005228                        583 _ak820_outline_0088:
      005228 E0               [24]  584 	movx	a,@dptr
      005229 F9               [12]  585 	mov	r1,a
      00522A A3               [24]  586 	inc	dptr
      00522B E0               [24]  587 	movx	a,@dptr
      00522C FA               [12]  588 	mov	r2,a
      00522D A3               [24]  589 	inc	dptr
      00522E E0               [24]  590 	movx	a,@dptr
      00522F FB               [12]  591 	mov	r3,a
      005230 22               [24]  592 	ret
                                    593 
                                    594 	.area CSEG (CODE)
                                    595 ; function ak820_outline_0089
      005231                        596 _ak820_outline_0089:
      005231 E0               [24]  597 	movx	a,@dptr
      005232 FE               [12]  598 	mov	r6,a
      005233 A3               [24]  599 	inc	dptr
      005234 E0               [24]  600 	movx	a,@dptr
      005235 8E 82            [24]  601 	mov	dpl,r6
      005237 F5 83            [12]  602 	mov	dph,a
      005239 22               [24]  603 	ret
                                    604 
                                    605 	.area CSEG (CODE)
                                    606 ; function ak820_outline_0106
      00523A                        607 _ak820_outline_0106:
      00523A 74 02            [12]  608 	mov	a,#0x02
      00523C F0               [24]  609 	movx	@dptr,a
      00523D E4               [12]  610 	clr	a
      00523E A3               [24]  611 	inc	dptr
      00523F F0               [24]  612 	movx	@dptr,a
      005240 22               [24]  613 	ret
                                    614 
                                    615 	.area CSEG (CODE)
                                    616 ; function ak820_outline_0151
      005241                        617 _ak820_outline_0151:
      005241 F0               [24]  618 	movx	@dptr,a
      005242 EA               [12]  619 	mov	a,r2
      005243 A3               [24]  620 	inc	dptr
      005244 F0               [24]  621 	movx	@dptr,a
      005245 EB               [12]  622 	mov	a,r3
      005246 A3               [24]  623 	inc	dptr
      005247 22               [24]  624 	ret
                                    625 
                                    626 	.area CSEG (CODE)
                                    627 ; function ak820_outline_0166
      005248                        628 _ak820_outline_0166:
      005248 E4               [12]  629 	clr	a
      005249 F0               [24]  630 	movx	@dptr,a
      00524A A3               [24]  631 	inc	dptr
      00524B F0               [24]  632 	movx	@dptr,a
      00524C 22               [24]  633 	ret
