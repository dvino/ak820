                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module eeprom_driver
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_eeprom_write_block_xdata
                                     12 	.globl _ak820_eeprom_read_block_xdata
                                     13 	.globl _eeprom_read_byte
                                     14 	.globl _eeprom_update_dword_PARM_2
                                     15 	.globl _eeprom_update_word_PARM_2
                                     16 	.globl _eeprom_update_byte_PARM_2
                                     17 	.globl _eeprom_write_dword_PARM_2
                                     18 	.globl _eeprom_write_word_PARM_2
                                     19 	.globl _eeprom_write_byte_PARM_2
                                     20 	.globl _eeprom_read_word
                                     21 	.globl _eeprom_read_dword
                                     22 	.globl _eeprom_write_byte
                                     23 	.globl _eeprom_write_word
                                     24 	.globl _eeprom_write_dword
                                     25 	.globl _eeprom_update_byte
                                     26 	.globl _eeprom_update_word
                                     27 	.globl _eeprom_update_dword
                                     28 ;--------------------------------------------------------
                                     29 ; special function registers
                                     30 ;--------------------------------------------------------
                                     31 	.area RSEG    (ABS,DATA)
      000000                         32 	.org 0x0000
                                     33 ;--------------------------------------------------------
                                     34 ; special function bits
                                     35 ;--------------------------------------------------------
                                     36 	.area RSEG    (ABS,DATA)
      000000                         37 	.org 0x0000
                                     38 ;--------------------------------------------------------
                                     39 ; overlayable register banks
                                     40 ;--------------------------------------------------------
                                     41 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         42 	.ds 8
                                     43 ;--------------------------------------------------------
                                     44 ; overlayable bit register bank
                                     45 ;--------------------------------------------------------
                                     46 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         47 bits:
      000026                         48 	.ds 1
                           008000    49 	b0 = bits[0]
                           008100    50 	b1 = bits[1]
                           008200    51 	b2 = bits[2]
                           008300    52 	b3 = bits[3]
                           008400    53 	b4 = bits[4]
                           008500    54 	b5 = bits[5]
                           008600    55 	b6 = bits[6]
                           008700    56 	b7 = bits[7]
                                     57 ;--------------------------------------------------------
                                     58 ; internal ram data
                                     59 ;--------------------------------------------------------
                                     60 	.area DSEG    (DATA)
                                     61 ;--------------------------------------------------------
                                     62 ; overlayable items in internal ram
                                     63 ;--------------------------------------------------------
                                     64 ;--------------------------------------------------------
                                     65 ; indirectly addressable internal ram data
                                     66 ;--------------------------------------------------------
                                     67 	.area ISEG    (DATA)
                                     68 ;--------------------------------------------------------
                                     69 ; absolute internal ram data
                                     70 ;--------------------------------------------------------
                                     71 	.area IABS    (ABS,DATA)
                                     72 	.area IABS    (ABS,DATA)
                                     73 ;--------------------------------------------------------
                                     74 ; bit data
                                     75 ;--------------------------------------------------------
                                     76 	.area BSEG    (BIT)
                                     77 ;--------------------------------------------------------
                                     78 ; paged external ram data
                                     79 ;--------------------------------------------------------
                                     80 	.area PSEG    (PAG,XDATA)
                                     81 ;--------------------------------------------------------
                                     82 ; uninitialized external ram data
                                     83 ;--------------------------------------------------------
                                     84 	.area XSEG    (XDATA)
      000693                         85 _eeprom_read_word_addr_10000_91:
      000693                         86 	.ds 3
      000696                         87 _eeprom_read_word_ret_10000_92:
      000696                         88 	.ds 2
      000698                         89 _eeprom_read_dword_addr_10000_93:
      000698                         90 	.ds 3
      00069B                         91 _eeprom_read_dword_ret_10000_94:
      00069B                         92 	.ds 4
      00069F                         93 _eeprom_write_byte_PARM_2:
      00069F                         94 	.ds 1
      0006A0                         95 _eeprom_write_byte_addr_10000_95:
      0006A0                         96 	.ds 3
      0006A3                         97 _eeprom_write_word_PARM_2:
      0006A3                         98 	.ds 2
      0006A5                         99 _eeprom_write_word_addr_10000_97:
      0006A5                        100 	.ds 3
      0006A8                        101 _eeprom_write_dword_PARM_2:
      0006A8                        102 	.ds 4
      0006AC                        103 _eeprom_write_dword_addr_10000_99:
      0006AC                        104 	.ds 3
      0006AF                        105 _eeprom_update_byte_PARM_2:
      0006AF                        106 	.ds 1
      0006B0                        107 _eeprom_update_byte_addr_10000_107:
      0006B0                        108 	.ds 3
      0006B3                        109 _eeprom_update_word_PARM_2:
      0006B3                        110 	.ds 2
      0006B5                        111 _eeprom_update_word_addr_10000_111:
      0006B5                        112 	.ds 3
      0006B8                        113 _eeprom_update_dword_PARM_2:
      0006B8                        114 	.ds 4
      0006BC                        115 _eeprom_update_dword_addr_10000_115:
      0006BC                        116 	.ds 3
                                    117 ;--------------------------------------------------------
                                    118 ; absolute external ram data
                                    119 ;--------------------------------------------------------
                                    120 	.area XABS    (ABS,XDATA)
                                    121 ;--------------------------------------------------------
                                    122 ; initialized external ram data
                                    123 ;--------------------------------------------------------
                                    124 	.area XISEG   (XDATA)
                                    125 	.area HOME    (CODE)
                                    126 	.area GSINIT0 (CODE)
                                    127 	.area GSINIT1 (CODE)
                                    128 	.area GSINIT2 (CODE)
                                    129 	.area GSINIT3 (CODE)
                                    130 	.area GSINIT4 (CODE)
                                    131 	.area GSINIT5 (CODE)
                                    132 	.area GSINIT  (CODE)
                                    133 	.area GSFINAL (CODE)
                                    134 	.area CSEG    (CODE)
                                    135 ;--------------------------------------------------------
                                    136 ; global & static initialisations
                                    137 ;--------------------------------------------------------
                                    138 	.area HOME    (CODE)
                                    139 	.area GSINIT  (CODE)
                                    140 	.area GSFINAL (CODE)
                                    141 	.area GSINIT  (CODE)
                                    142 ;--------------------------------------------------------
                                    143 ; Home
                                    144 ;--------------------------------------------------------
                                    145 	.area HOME    (CODE)
                                    146 	.area HOME    (CODE)
                                    147 ;--------------------------------------------------------
                                    148 ; code
                                    149 ;--------------------------------------------------------
                                    150 	.area CSEG    (CODE)
                                    151 ;------------------------------------------------------------
                                    152 ;Allocation info for local variables in function 'eeprom_read_word'
                                    153 ;------------------------------------------------------------
                                    154 ;addr          Allocated with name '_eeprom_read_word_addr_10000_91'
                                    155 ;ret           Allocated with name '_eeprom_read_word_ret_10000_92'
                                    156 ;------------------------------------------------------------
                                    157 ;	drivers/eeprom/eeprom_driver.c:44: uint16_t eeprom_read_word(const uint16_t *addr) {
                                    158 ;	-----------------------------------------
                                    159 ;	 function eeprom_read_word
                                    160 ;	-----------------------------------------
      005048                        161 _eeprom_read_word:
                           000007   162 	ar7 = 0x07
                           000006   163 	ar6 = 0x06
                           000005   164 	ar5 = 0x05
                           000004   165 	ar4 = 0x04
                           000003   166 	ar3 = 0x03
                           000002   167 	ar2 = 0x02
                           000001   168 	ar1 = 0x01
                           000000   169 	ar0 = 0x00
      005048 12 45 86         [24]  170 	lcall	_ak820_outline_0037
      00504B 90 06 93         [24]  171 	mov	dptr,#_eeprom_read_word_addr_10000_91
      00504E 12 3A 26         [24]  172 	lcall	_ak820_outline_0016
                                    173 ;	drivers/eeprom/eeprom_driver.c:45: uint16_t ret = 0;
      005051 90 06 96         [24]  174 	mov	dptr,#_eeprom_read_word_ret_10000_92
      005054 12 52 54         [24]  175 	lcall	_ak820_outline_0166
                                    176 ;	drivers/eeprom/eeprom_driver.c:46: EEPROM_LOCAL_READ(&ret, addr, 2);
      005057 90 06 93         [24]  177 	mov	dptr,#_eeprom_read_word_addr_10000_91
      00505A 12 52 02         [24]  178 	lcall	_ak820_outline_0022
      00505D 90 05 91         [24]  179 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      005060 ED               [12]  180 	mov	a,r5
      005061 12 3A 26         [24]  181 	lcall	_ak820_outline_0016
      005064 90 05 94         [24]  182 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      005067 12 52 46         [24]  183 	lcall	_ak820_outline_0106
      00506A 90 06 96         [24]  184 	mov	dptr,#_eeprom_read_word_ret_10000_92
      00506D 12 43 22         [24]  185 	lcall	_ak820_eeprom_read_block_xdata
                                    186 ;	drivers/eeprom/eeprom_driver.c:47: return ret;
      005070 90 06 96         [24]  187 	mov	dptr,#_eeprom_read_word_ret_10000_92
      005073 12 52 3D         [24]  188 	lcall	_ak820_outline_0089
                                    189 ;	drivers/eeprom/eeprom_driver.c:48: }
      005076 22               [24]  190 	ret
                                    191 ;------------------------------------------------------------
                                    192 ;Allocation info for local variables in function 'eeprom_read_dword'
                                    193 ;------------------------------------------------------------
                                    194 ;addr          Allocated with name '_eeprom_read_dword_addr_10000_93'
                                    195 ;ret           Allocated with name '_eeprom_read_dword_ret_10000_94'
                                    196 ;------------------------------------------------------------
                                    197 ;	drivers/eeprom/eeprom_driver.c:50: uint32_t eeprom_read_dword(const uint32_t *addr) {
                                    198 ;	-----------------------------------------
                                    199 ;	 function eeprom_read_dword
                                    200 ;	-----------------------------------------
      005077                        201 _eeprom_read_dword:
      005077 12 45 86         [24]  202 	lcall	_ak820_outline_0037
      00507A 90 06 98         [24]  203 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      00507D 12 3A 26         [24]  204 	lcall	_ak820_outline_0016
                                    205 ;	drivers/eeprom/eeprom_driver.c:51: uint32_t ret = 0;
      005080 90 06 9B         [24]  206 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      005083 12 52 12         [24]  207 	lcall	_ak820_outline_0049
                                    208 ;	drivers/eeprom/eeprom_driver.c:52: EEPROM_LOCAL_READ(&ret, addr, 4);
      005086 90 06 98         [24]  209 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      005089 12 52 02         [24]  210 	lcall	_ak820_outline_0022
      00508C 90 05 91         [24]  211 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      00508F ED               [12]  212 	mov	a,r5
      005090 12 3A 26         [24]  213 	lcall	_ak820_outline_0016
      005093 90 05 94         [24]  214 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      005096 74 04            [12]  215 	mov	a,#0x04
      005098 12 3A A6         [24]  216 	lcall	_ak820_outline_0123
      00509B 90 06 9B         [24]  217 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      00509E 12 43 22         [24]  218 	lcall	_ak820_eeprom_read_block_xdata
                                    219 ;	drivers/eeprom/eeprom_driver.c:53: return ret;
      0050A1 90 06 9B         [24]  220 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      0050A4 12 52 1B         [24]  221 	lcall	_ak820_outline_0054
                                    222 ;	drivers/eeprom/eeprom_driver.c:54: }
      0050A7 22               [24]  223 	ret
                                    224 ;------------------------------------------------------------
                                    225 ;Allocation info for local variables in function 'eeprom_write_byte'
                                    226 ;------------------------------------------------------------
                                    227 ;value         Allocated with name '_eeprom_write_byte_PARM_2'
                                    228 ;addr          Allocated with name '_eeprom_write_byte_addr_10000_95'
                                    229 ;------------------------------------------------------------
                                    230 ;	drivers/eeprom/eeprom_driver.c:56: void eeprom_write_byte(uint8_t *addr, uint8_t value) {
                                    231 ;	-----------------------------------------
                                    232 ;	 function eeprom_write_byte
                                    233 ;	-----------------------------------------
      0050A8                        234 _eeprom_write_byte:
      0050A8 12 45 86         [24]  235 	lcall	_ak820_outline_0037
      0050AB 90 06 A0         [24]  236 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      0050AE 12 3A 26         [24]  237 	lcall	_ak820_outline_0016
                                    238 ;	drivers/eeprom/eeprom_driver.c:57: EEPROM_LOCAL_WRITE(&value, addr, 1);
      0050B1 90 06 A0         [24]  239 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      0050B4 12 51 DC         [24]  240 	lcall	_ak820_outline_0002
      0050B7 74 01            [12]  241 	mov	a,#0x01
      0050B9 12 3A A6         [24]  242 	lcall	_ak820_outline_0123
      0050BC 90 06 9F         [24]  243 	mov	dptr,#_eeprom_write_byte_PARM_2
                                    244 ;	drivers/eeprom/eeprom_driver.c:58: }
      0050BF 02 43 AE         [24]  245 	ljmp	_ak820_eeprom_write_block_xdata
                                    246 ;------------------------------------------------------------
                                    247 ;Allocation info for local variables in function 'eeprom_write_word'
                                    248 ;------------------------------------------------------------
                                    249 ;value         Allocated with name '_eeprom_write_word_PARM_2'
                                    250 ;addr          Allocated with name '_eeprom_write_word_addr_10000_97'
                                    251 ;------------------------------------------------------------
                                    252 ;	drivers/eeprom/eeprom_driver.c:60: void eeprom_write_word(uint16_t *addr, uint16_t value) {
                                    253 ;	-----------------------------------------
                                    254 ;	 function eeprom_write_word
                                    255 ;	-----------------------------------------
      0050C2                        256 _eeprom_write_word:
      0050C2 12 45 86         [24]  257 	lcall	_ak820_outline_0037
      0050C5 90 06 A5         [24]  258 	mov	dptr,#_eeprom_write_word_addr_10000_97
      0050C8 12 3A 26         [24]  259 	lcall	_ak820_outline_0016
                                    260 ;	drivers/eeprom/eeprom_driver.c:61: EEPROM_LOCAL_WRITE(&value, addr, 2);
      0050CB 90 06 A5         [24]  261 	mov	dptr,#_eeprom_write_word_addr_10000_97
      0050CE 12 51 DC         [24]  262 	lcall	_ak820_outline_0002
      0050D1 12 52 46         [24]  263 	lcall	_ak820_outline_0106
      0050D4 90 06 A3         [24]  264 	mov	dptr,#_eeprom_write_word_PARM_2
                                    265 ;	drivers/eeprom/eeprom_driver.c:62: }
      0050D7 02 43 AE         [24]  266 	ljmp	_ak820_eeprom_write_block_xdata
                                    267 ;------------------------------------------------------------
                                    268 ;Allocation info for local variables in function 'eeprom_write_dword'
                                    269 ;------------------------------------------------------------
                                    270 ;value         Allocated with name '_eeprom_write_dword_PARM_2'
                                    271 ;addr          Allocated with name '_eeprom_write_dword_addr_10000_99'
                                    272 ;------------------------------------------------------------
                                    273 ;	drivers/eeprom/eeprom_driver.c:64: void eeprom_write_dword(uint32_t *addr, uint32_t value) {
                                    274 ;	-----------------------------------------
                                    275 ;	 function eeprom_write_dword
                                    276 ;	-----------------------------------------
      0050DA                        277 _eeprom_write_dword:
      0050DA 12 45 86         [24]  278 	lcall	_ak820_outline_0037
      0050DD 90 06 AC         [24]  279 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      0050E0 12 3A 26         [24]  280 	lcall	_ak820_outline_0016
                                    281 ;	drivers/eeprom/eeprom_driver.c:65: EEPROM_LOCAL_WRITE(&value, addr, 4);
      0050E3 90 06 AC         [24]  282 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      0050E6 12 51 DC         [24]  283 	lcall	_ak820_outline_0002
      0050E9 74 04            [12]  284 	mov	a,#0x04
      0050EB 12 3A A6         [24]  285 	lcall	_ak820_outline_0123
      0050EE 90 06 A8         [24]  286 	mov	dptr,#_eeprom_write_dword_PARM_2
                                    287 ;	drivers/eeprom/eeprom_driver.c:66: }
      0050F1 02 43 AE         [24]  288 	ljmp	_ak820_eeprom_write_block_xdata
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'eeprom_update_block'
                                    291 ;------------------------------------------------------------
                                    292 ;sloc0         Allocated with name '_eeprom_update_block_sloc0_1_0'
                                    293 ;sloc1         Allocated with name '_eeprom_update_block_sloc1_1_0'
                                    294 ;sloc2         Allocated with name '_eeprom_update_block_sloc2_1_0'
                                    295 ;sloc3         Allocated with name '_eeprom_update_block_sloc3_1_0'
                                    296 ;addr          Allocated with name '_eeprom_update_block_PARM_2'
                                    297 ;len           Allocated with name '_eeprom_update_block_PARM_3'
                                    298 ;buf           Allocated with name '_eeprom_update_block_buf_10000_101'
                                    299 ;source        Allocated with name '_eeprom_update_block_source_10000_102'
                                    300 ;target        Allocated with name '_eeprom_update_block_target_10000_102'
                                    301 ;i             Allocated with name '_eeprom_update_block_i_10000_102'
                                    302 ;------------------------------------------------------------
                                    303 ;	drivers/eeprom/eeprom_driver.c:68: void eeprom_update_block(const void *buf, void *addr, size_t len) {
                                    304 ;	-----------------------------------------
                                    305 ;	 function eeprom_update_byte
                                    306 ;	-----------------------------------------
      0050F4                        307 _eeprom_update_byte:
      0050F4 C0 07            [24]  308 	push	ar7
      0050F6 C0 06            [24]  309 	push	ar6
      0050F8 C0 05            [24]  310 	push	ar5
      0050FA C0 04            [24]  311 	push	ar4
      0050FC 12 45 86         [24]  312 	lcall	_ak820_outline_0037
      0050FF 90 06 B0         [24]  313 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      005102 12 3A 26         [24]  314 	lcall	_ak820_outline_0016
                                    315 ;	drivers/eeprom/eeprom_driver.c:83: uint8_t orig = eeprom_read_byte(addr);
      005105 90 06 B0         [24]  316 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      005108 12 51 F3         [24]  317 	lcall	_ak820_outline_0003
      00510B 12 42 E7         [24]  318 	lcall	_eeprom_read_byte
      00510E AF 82            [24]  319 	mov	r7, dpl
                                    320 ;	drivers/eeprom/eeprom_driver.c:84: if (orig != value) {
      005110 90 06 AF         [24]  321 	mov	dptr,#_eeprom_update_byte_PARM_2
      005113 E0               [24]  322 	movx	a,@dptr
      005114 FE               [12]  323 	mov	r6,a
      005115 EF               [12]  324 	mov	a,r7
      005116 B5 06 02         [24]  325 	cjne	a,ar6,00112$
      005119 80 36            [24]  326 	sjmp	00103$
      00511B                        327 00112$:
                                    328 ;	drivers/eeprom/eeprom_driver.c:85: eeprom_write_byte(addr, value);
      00511B 90 06 B0         [24]  329 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      00511E 12 3A 66         [24]  330 	lcall	_ak820_outline_0060
      005121 A3               [24]  331 	inc	dptr
      005122 E0               [24]  332 	movx	a,@dptr
      005123 FF               [12]  333 	mov	r7,a
      005124 90 06 9F         [24]  334 	mov	dptr,#_eeprom_write_byte_PARM_2
      005127 EE               [12]  335 	mov	a,r6
      005128 F0               [24]  336 	movx	@dptr,a
      005129 12 3A 9B         [24]  337 	lcall	_ak820_outline_0117
      00512C 8F F0            [24]  338 	mov	b, r7
      00512E C0 07            [24]  339 	push	ar7
      005130 C0 06            [24]  340 	push	ar6
      005132 C0 05            [24]  341 	push	ar5
      005134 C0 04            [24]  342 	push	ar4
      005136 C0 03            [24]  343 	push	ar3
      005138 C0 02            [24]  344 	push	ar2
      00513A C0 01            [24]  345 	push	ar1
      00513C C0 00            [24]  346 	push	ar0
      00513E 12 50 A8         [24]  347 	lcall	_eeprom_write_byte
      005141 D0 00            [24]  348 	pop	ar0
      005143 D0 01            [24]  349 	pop	ar1
      005145 D0 02            [24]  350 	pop	ar2
      005147 D0 03            [24]  351 	pop	ar3
      005149 D0 04            [24]  352 	pop	ar4
      00514B D0 05            [24]  353 	pop	ar5
      00514D D0 06            [24]  354 	pop	ar6
      00514F D0 07            [24]  355 	pop	ar7
      005151                        356 00103$:
                                    357 ;	drivers/eeprom/eeprom_driver.c:87: }
      005151 D0 04            [24]  358 	pop	ar4
      005153 D0 05            [24]  359 	pop	ar5
      005155 D0 06            [24]  360 	pop	ar6
      005157 D0 07            [24]  361 	pop	ar7
      005159 22               [24]  362 	ret
                                    363 ;------------------------------------------------------------
                                    364 ;Allocation info for local variables in function 'eeprom_update_word'
                                    365 ;------------------------------------------------------------
                                    366 ;value         Allocated with name '_eeprom_update_word_PARM_2'
                                    367 ;addr          Allocated with name '_eeprom_update_word_addr_10000_111'
                                    368 ;orig          Allocated with name '_eeprom_update_word_orig_10000_112'
                                    369 ;------------------------------------------------------------
                                    370 ;	drivers/eeprom/eeprom_driver.c:89: void eeprom_update_word(uint16_t *addr, uint16_t value) {
                                    371 ;	-----------------------------------------
                                    372 ;	 function eeprom_update_word
                                    373 ;	-----------------------------------------
      00515A                        374 _eeprom_update_word:
      00515A 12 45 86         [24]  375 	lcall	_ak820_outline_0037
      00515D 90 06 B5         [24]  376 	mov	dptr,#_eeprom_update_word_addr_10000_111
      005160 12 3A 26         [24]  377 	lcall	_ak820_outline_0016
                                    378 ;	drivers/eeprom/eeprom_driver.c:90: uint16_t orig = eeprom_read_word(addr);
      005163 90 06 B5         [24]  379 	mov	dptr,#_eeprom_update_word_addr_10000_111
      005166 12 51 F3         [24]  380 	lcall	_ak820_outline_0003
      005169 12 50 48         [24]  381 	lcall	_eeprom_read_word
      00516C 12 45 DA         [24]  382 	lcall	_ak820_outline_0131
                                    383 ;	drivers/eeprom/eeprom_driver.c:91: if (orig != value) {
      00516F 90 06 B3         [24]  384 	mov	dptr,#_eeprom_update_word_PARM_2
      005172 12 3A 66         [24]  385 	lcall	_ak820_outline_0060
      005175 EE               [12]  386 	mov	a,r6
      005176 B5 04 05         [24]  387 	cjne	a,ar4,00112$
      005179 EF               [12]  388 	mov	a,r7
      00517A B5 05 01         [24]  389 	cjne	a,ar5,00112$
      00517D 22               [24]  390 	ret
      00517E                        391 00112$:
                                    392 ;	drivers/eeprom/eeprom_driver.c:92: eeprom_write_word(addr, value);
      00517E 90 06 B5         [24]  393 	mov	dptr,#_eeprom_update_word_addr_10000_111
      005181 E0               [24]  394 	movx	a,@dptr
      005182 FB               [12]  395 	mov	r3,a
      005183 A3               [24]  396 	inc	dptr
      005184 12 3A 47         [24]  397 	lcall	_ak820_outline_0051
      005187 90 06 A3         [24]  398 	mov	dptr,#_eeprom_write_word_PARM_2
      00518A 12 3A 6C         [24]  399 	lcall	_ak820_outline_0071
      00518D 8B 82            [24]  400 	mov	dpl, r3
      00518F 8E 83            [24]  401 	mov	dph, r6
      005191 8F F0            [24]  402 	mov	b, r7
                                    403 ;	drivers/eeprom/eeprom_driver.c:94: }
      005193 02 50 C2         [24]  404 	ljmp	_eeprom_write_word
                                    405 ;------------------------------------------------------------
                                    406 ;Allocation info for local variables in function 'eeprom_update_dword'
                                    407 ;------------------------------------------------------------
                                    408 ;value         Allocated with name '_eeprom_update_dword_PARM_2'
                                    409 ;addr          Allocated with name '_eeprom_update_dword_addr_10000_115'
                                    410 ;orig          Allocated with name '_eeprom_update_dword_orig_10000_116'
                                    411 ;------------------------------------------------------------
                                    412 ;	drivers/eeprom/eeprom_driver.c:96: void eeprom_update_dword(uint32_t *addr, uint32_t value) {
                                    413 ;	-----------------------------------------
                                    414 ;	 function eeprom_update_dword
                                    415 ;	-----------------------------------------
      005196                        416 _eeprom_update_dword:
      005196 12 45 86         [24]  417 	lcall	_ak820_outline_0037
      005199 90 06 BC         [24]  418 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      00519C 12 3A 26         [24]  419 	lcall	_ak820_outline_0016
                                    420 ;	drivers/eeprom/eeprom_driver.c:97: uint32_t orig = eeprom_read_dword(addr);
      00519F 90 06 BC         [24]  421 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      0051A2 12 51 F3         [24]  422 	lcall	_ak820_outline_0003
      0051A5 12 50 77         [24]  423 	lcall	_eeprom_read_dword
      0051A8 12 52 2C         [24]  424 	lcall	_ak820_outline_0057
                                    425 ;	drivers/eeprom/eeprom_driver.c:98: if (orig != value) {
      0051AB 90 06 B8         [24]  426 	mov	dptr,#_eeprom_update_dword_PARM_2
      0051AE E0               [24]  427 	movx	a,@dptr
      0051AF F8               [12]  428 	mov	r0,a
      0051B0 A3               [24]  429 	inc	dptr
      0051B1 12 52 34         [24]  430 	lcall	_ak820_outline_0088
      0051B4 EC               [12]  431 	mov	a,r4
      0051B5 B5 00 0D         [24]  432 	cjne	a,ar0,00112$
      0051B8 ED               [12]  433 	mov	a,r5
      0051B9 B5 01 09         [24]  434 	cjne	a,ar1,00112$
      0051BC EE               [12]  435 	mov	a,r6
      0051BD B5 02 05         [24]  436 	cjne	a,ar2,00112$
      0051C0 EF               [12]  437 	mov	a,r7
      0051C1 B5 03 01         [24]  438 	cjne	a,ar3,00112$
      0051C4 22               [24]  439 	ret
      0051C5                        440 00112$:
                                    441 ;	drivers/eeprom/eeprom_driver.c:99: eeprom_write_dword(addr, value);
      0051C5 90 06 BC         [24]  442 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      0051C8 12 52 02         [24]  443 	lcall	_ak820_outline_0022
      0051CB 90 06 A8         [24]  444 	mov	dptr,#_eeprom_write_dword_PARM_2
      0051CE E8               [12]  445 	mov	a,r0
      0051CF F0               [24]  446 	movx	@dptr,a
      0051D0 E9               [12]  447 	mov	a,r1
      0051D1 A3               [24]  448 	inc	dptr
      0051D2 12 52 4D         [24]  449 	lcall	_ak820_outline_0151
      0051D5 F0               [24]  450 	movx	@dptr,a
      0051D6 12 52 0B         [24]  451 	lcall	_ak820_outline_0044
                                    452 ;	drivers/eeprom/eeprom_driver.c:101: }
      0051D9 02 50 DA         [24]  453 	ljmp	_eeprom_write_dword
                                    454 	.area CSEG    (CODE)
                                    455 	.area CONST   (CODE)
                                    456 	.area XINIT   (CODE)
                                    457 	.area CABS    (ABS,CODE)
                                    458 
                                    459 ; Experimental exact instruction outlining.
                                    460 	.globl _ak820_outline_0002
                                    461 	.globl _ak820_outline_0003
                                    462 	.globl _ak820_outline_0016
                                    463 	.globl _ak820_outline_0022
                                    464 	.globl _ak820_outline_0037
                                    465 	.globl _ak820_outline_0044
                                    466 	.globl _ak820_outline_0049
                                    467 	.globl _ak820_outline_0051
                                    468 	.globl _ak820_outline_0054
                                    469 	.globl _ak820_outline_0057
                                    470 	.globl _ak820_outline_0060
                                    471 	.globl _ak820_outline_0071
                                    472 	.globl _ak820_outline_0088
                                    473 	.globl _ak820_outline_0089
                                    474 	.globl _ak820_outline_0106
                                    475 	.globl _ak820_outline_0117
                                    476 	.globl _ak820_outline_0123
                                    477 	.globl _ak820_outline_0131
                                    478 	.globl _ak820_outline_0151
                                    479 	.globl _ak820_outline_0166
                                    480 
                                    481 	.area CSEG (CODE)
                                    482 ; function ak820_outline_0002
      0051DC                        483 _ak820_outline_0002:
      0051DC E0               [24]  484 	movx	a,@dptr
      0051DD FD               [12]  485 	mov	r5,a
      0051DE A3               [24]  486 	inc	dptr
      0051DF E0               [24]  487 	movx	a,@dptr
      0051E0 FE               [12]  488 	mov	r6,a
      0051E1 A3               [24]  489 	inc	dptr
      0051E2 E0               [24]  490 	movx	a,@dptr
      0051E3 FF               [12]  491 	mov	r7,a
      0051E4 90 05 9A         [24]  492 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      0051E7 ED               [12]  493 	mov	a,r5
      0051E8 F0               [24]  494 	movx	@dptr,a
      0051E9 EE               [12]  495 	mov	a,r6
      0051EA A3               [24]  496 	inc	dptr
      0051EB F0               [24]  497 	movx	@dptr,a
      0051EC EF               [12]  498 	mov	a,r7
      0051ED A3               [24]  499 	inc	dptr
      0051EE F0               [24]  500 	movx	@dptr,a
      0051EF 90 05 9D         [24]  501 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0051F2 22               [24]  502 	ret
                                    503 
                                    504 	.area CSEG (CODE)
                                    505 ; function ak820_outline_0003
      0051F3                        506 _ak820_outline_0003:
      0051F3 E0               [24]  507 	movx	a,@dptr
      0051F4 FD               [12]  508 	mov	r5,a
      0051F5 A3               [24]  509 	inc	dptr
      0051F6 E0               [24]  510 	movx	a,@dptr
      0051F7 FE               [12]  511 	mov	r6,a
      0051F8 A3               [24]  512 	inc	dptr
      0051F9 E0               [24]  513 	movx	a,@dptr
      0051FA FF               [12]  514 	mov	r7,a
      0051FB 8D 82            [24]  515 	mov	dpl,r5
      0051FD 8E 83            [24]  516 	mov	dph,r6
      0051FF 8F F0            [24]  517 	mov	b,r7
      005201 22               [24]  518 	ret
                                    519 
                                    520 	.area CSEG (CODE)
                                    521 ; function ak820_outline_0022
      005202                        522 _ak820_outline_0022:
      005202 E0               [24]  523 	movx	a,@dptr
      005203 FD               [12]  524 	mov	r5,a
      005204 A3               [24]  525 	inc	dptr
      005205 E0               [24]  526 	movx	a,@dptr
      005206 FE               [12]  527 	mov	r6,a
      005207 A3               [24]  528 	inc	dptr
      005208 E0               [24]  529 	movx	a,@dptr
      005209 FF               [12]  530 	mov	r7,a
      00520A 22               [24]  531 	ret
                                    532 
                                    533 	.area CSEG (CODE)
                                    534 ; function ak820_outline_0044
      00520B                        535 _ak820_outline_0044:
      00520B 8D 82            [24]  536 	mov	dpl,r5
      00520D 8E 83            [24]  537 	mov	dph,r6
      00520F 8F F0            [24]  538 	mov	b,r7
      005211 22               [24]  539 	ret
                                    540 
                                    541 	.area CSEG (CODE)
                                    542 ; function ak820_outline_0049
      005212                        543 _ak820_outline_0049:
      005212 E4               [12]  544 	clr	a
      005213 F0               [24]  545 	movx	@dptr,a
      005214 A3               [24]  546 	inc	dptr
      005215 F0               [24]  547 	movx	@dptr,a
      005216 A3               [24]  548 	inc	dptr
      005217 F0               [24]  549 	movx	@dptr,a
      005218 A3               [24]  550 	inc	dptr
      005219 F0               [24]  551 	movx	@dptr,a
      00521A 22               [24]  552 	ret
                                    553 
                                    554 	.area CSEG (CODE)
                                    555 ; function ak820_outline_0054
      00521B                        556 _ak820_outline_0054:
      00521B E0               [24]  557 	movx	a,@dptr
      00521C FC               [12]  558 	mov	r4,a
      00521D A3               [24]  559 	inc	dptr
      00521E E0               [24]  560 	movx	a,@dptr
      00521F FD               [12]  561 	mov	r5,a
      005220 A3               [24]  562 	inc	dptr
      005221 E0               [24]  563 	movx	a,@dptr
      005222 FE               [12]  564 	mov	r6,a
      005223 A3               [24]  565 	inc	dptr
      005224 E0               [24]  566 	movx	a,@dptr
      005225 8C 82            [24]  567 	mov	dpl,r4
      005227 8D 83            [24]  568 	mov	dph,r5
      005229 8E F0            [24]  569 	mov	b,r6
      00522B 22               [24]  570 	ret
                                    571 
                                    572 	.area CSEG (CODE)
                                    573 ; function ak820_outline_0057
      00522C                        574 _ak820_outline_0057:
      00522C AC 82            [24]  575 	mov	r4,dpl
      00522E AD 83            [24]  576 	mov	r5,dph
      005230 AE F0            [24]  577 	mov	r6,b
      005232 FF               [12]  578 	mov	r7,a
      005233 22               [24]  579 	ret
                                    580 
                                    581 	.area CSEG (CODE)
                                    582 ; function ak820_outline_0088
      005234                        583 _ak820_outline_0088:
      005234 E0               [24]  584 	movx	a,@dptr
      005235 F9               [12]  585 	mov	r1,a
      005236 A3               [24]  586 	inc	dptr
      005237 E0               [24]  587 	movx	a,@dptr
      005238 FA               [12]  588 	mov	r2,a
      005239 A3               [24]  589 	inc	dptr
      00523A E0               [24]  590 	movx	a,@dptr
      00523B FB               [12]  591 	mov	r3,a
      00523C 22               [24]  592 	ret
                                    593 
                                    594 	.area CSEG (CODE)
                                    595 ; function ak820_outline_0089
      00523D                        596 _ak820_outline_0089:
      00523D E0               [24]  597 	movx	a,@dptr
      00523E FE               [12]  598 	mov	r6,a
      00523F A3               [24]  599 	inc	dptr
      005240 E0               [24]  600 	movx	a,@dptr
      005241 8E 82            [24]  601 	mov	dpl,r6
      005243 F5 83            [12]  602 	mov	dph,a
      005245 22               [24]  603 	ret
                                    604 
                                    605 	.area CSEG (CODE)
                                    606 ; function ak820_outline_0106
      005246                        607 _ak820_outline_0106:
      005246 74 02            [12]  608 	mov	a,#0x02
      005248 F0               [24]  609 	movx	@dptr,a
      005249 E4               [12]  610 	clr	a
      00524A A3               [24]  611 	inc	dptr
      00524B F0               [24]  612 	movx	@dptr,a
      00524C 22               [24]  613 	ret
                                    614 
                                    615 	.area CSEG (CODE)
                                    616 ; function ak820_outline_0151
      00524D                        617 _ak820_outline_0151:
      00524D F0               [24]  618 	movx	@dptr,a
      00524E EA               [12]  619 	mov	a,r2
      00524F A3               [24]  620 	inc	dptr
      005250 F0               [24]  621 	movx	@dptr,a
      005251 EB               [12]  622 	mov	a,r3
      005252 A3               [24]  623 	inc	dptr
      005253 22               [24]  624 	ret
                                    625 
                                    626 	.area CSEG (CODE)
                                    627 ; function ak820_outline_0166
      005254                        628 _ak820_outline_0166:
      005254 E4               [12]  629 	clr	a
      005255 F0               [24]  630 	movx	@dptr,a
      005256 A3               [24]  631 	inc	dptr
      005257 F0               [24]  632 	movx	@dptr,a
      005258 22               [24]  633 	ret
