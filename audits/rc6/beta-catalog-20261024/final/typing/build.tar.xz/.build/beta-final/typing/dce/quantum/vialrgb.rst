                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module vialrgb
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _rgb_matrix_get_speed
                                     12 	.globl _rgb_matrix_set_speed_noeeprom
                                     13 	.globl _rgb_matrix_get_val
                                     14 	.globl _rgb_matrix_get_sat
                                     15 	.globl _rgb_matrix_get_hue
                                     16 	.globl _rgb_matrix_sethsv_noeeprom
                                     17 	.globl _rgb_matrix_get_mode
                                     18 	.globl _rgb_matrix_mode_noeeprom
                                     19 	.globl _rgb_matrix_is_enabled
                                     20 	.globl _rgb_matrix_disable_noeeprom
                                     21 	.globl _rgb_matrix_enable_noeeprom
                                     22 	.globl _eeconfig_update_rgb_matrix
                                     23 	.globl _ADC_START
                                     24 	.globl _S0_R_FIFO
                                     25 	.globl _S0_T_FIFO
                                     26 	.globl _S0_FREE
                                     27 	.globl _S0_IF_BYTE
                                     28 	.globl _S0_IF_FIRST
                                     29 	.globl _S0_IF_OV
                                     30 	.globl _S0_FST_ACT
                                     31 	.globl _CP_RL2
                                     32 	.globl _C_T2
                                     33 	.globl _TR2
                                     34 	.globl _EXEN2
                                     35 	.globl _TCLK
                                     36 	.globl _RCLK
                                     37 	.globl _EXF2
                                     38 	.globl _CAP1F
                                     39 	.globl _TF2
                                     40 	.globl _RI
                                     41 	.globl _TI
                                     42 	.globl _RB8
                                     43 	.globl _TB8
                                     44 	.globl _REN
                                     45 	.globl _SM2
                                     46 	.globl _SM1
                                     47 	.globl _SM0
                                     48 	.globl _IT0
                                     49 	.globl _IE0
                                     50 	.globl _IT1
                                     51 	.globl _IE1
                                     52 	.globl _TR0
                                     53 	.globl _TF0
                                     54 	.globl _TR1
                                     55 	.globl _TF1
                                     56 	.globl _P4_0
                                     57 	.globl _P4_1
                                     58 	.globl _P4_2
                                     59 	.globl _P4_3
                                     60 	.globl _P4_4
                                     61 	.globl _P4_5
                                     62 	.globl _P4_6
                                     63 	.globl _RXD
                                     64 	.globl _TXD
                                     65 	.globl _INT0
                                     66 	.globl _INT1
                                     67 	.globl _T0
                                     68 	.globl _T1
                                     69 	.globl _MOSI1
                                     70 	.globl _MISO1
                                     71 	.globl _SCK1
                                     72 	.globl _P3_0
                                     73 	.globl _P3_1
                                     74 	.globl _P3_2
                                     75 	.globl _P3_3
                                     76 	.globl _P3_4
                                     77 	.globl _P3_5
                                     78 	.globl _P3_6
                                     79 	.globl _P3_7
                                     80 	.globl _CAP1_
                                     81 	.globl _T2_
                                     82 	.globl _CAP2_
                                     83 	.globl _T2EX_
                                     84 	.globl _RXD1
                                     85 	.globl _TXD1
                                     86 	.globl _P2_0
                                     87 	.globl _P2_1
                                     88 	.globl _P2_2
                                     89 	.globl _P2_3
                                     90 	.globl _P2_4
                                     91 	.globl _P2_5
                                     92 	.globl _P2_6
                                     93 	.globl _P2_7
                                     94 	.globl _AIN0
                                     95 	.globl _AIN1
                                     96 	.globl _AIN2
                                     97 	.globl _AIN3
                                     98 	.globl _AIN4
                                     99 	.globl _AIN5
                                    100 	.globl _AIN6
                                    101 	.globl _AIN7
                                    102 	.globl _CAP1
                                    103 	.globl _T2
                                    104 	.globl _CAP2
                                    105 	.globl _T2EX
                                    106 	.globl _INT0_
                                    107 	.globl _SCS
                                    108 	.globl _MOSI
                                    109 	.globl _MISO
                                    110 	.globl _SCK
                                    111 	.globl _RXD1_
                                    112 	.globl _TXD1_
                                    113 	.globl _P1_0
                                    114 	.globl _P1_1
                                    115 	.globl _P1_2
                                    116 	.globl _P1_3
                                    117 	.globl _P1_4
                                    118 	.globl _P1_5
                                    119 	.globl _P1_6
                                    120 	.globl _P1_7
                                    121 	.globl _AIN8
                                    122 	.globl _AIN9
                                    123 	.globl _AIN10
                                    124 	.globl _AIN11
                                    125 	.globl _AIN12
                                    126 	.globl _AIN13
                                    127 	.globl _RXD_
                                    128 	.globl _TXD_
                                    129 	.globl _SCL0
                                    130 	.globl _SDA0
                                    131 	.globl _P0_0
                                    132 	.globl _P0_1
                                    133 	.globl _P0_2
                                    134 	.globl _P0_3
                                    135 	.globl _P0_4
                                    136 	.globl _P0_5
                                    137 	.globl _P0_6
                                    138 	.globl _P0_7
                                    139 	.globl _IE_SPI0
                                    140 	.globl _IE_USB
                                    141 	.globl _IE_ADC
                                    142 	.globl _IE_UART1
                                    143 	.globl _IE_PWM_I2C
                                    144 	.globl _IE_GPIO
                                    145 	.globl _IE_WDOG
                                    146 	.globl _PX0
                                    147 	.globl _PT0
                                    148 	.globl _PX1
                                    149 	.globl _PT1
                                    150 	.globl _PS
                                    151 	.globl _PT2
                                    152 	.globl _PL_FLAG
                                    153 	.globl _PH_FLAG
                                    154 	.globl _EX0
                                    155 	.globl _ET0
                                    156 	.globl _EX1
                                    157 	.globl _ET1
                                    158 	.globl _ES
                                    159 	.globl _ET2
                                    160 	.globl _E_DIS
                                    161 	.globl _EA
                                    162 	.globl _P
                                    163 	.globl _F1
                                    164 	.globl _OV
                                    165 	.globl _RS0
                                    166 	.globl _RS1
                                    167 	.globl _F0
                                    168 	.globl _AC
                                    169 	.globl _CY
                                    170 	.globl _I2CS_INT_ST
                                    171 	.globl _I2CX_INT
                                    172 	.globl _LED_STATUS
                                    173 	.globl _LED_DMA_H
                                    174 	.globl _LED_DMA_L
                                    175 	.globl _LED_DMA
                                    176 	.globl _LED_PWM_OE
                                    177 	.globl _LED_COMMON
                                    178 	.globl _ADC_CHAN
                                    179 	.globl _ADC_DAT_H
                                    180 	.globl _ADC_DAT_L
                                    181 	.globl _ADC_DAT
                                    182 	.globl _ADC_CTRL
                                    183 	.globl _SPI1_CK_SE
                                    184 	.globl _SPI1_CTRL
                                    185 	.globl _SPI1_DATA
                                    186 	.globl _SPI1_STAT
                                    187 	.globl _SIF1
                                    188 	.globl _SBAUD1
                                    189 	.globl _SBUF1
                                    190 	.globl _SCON1
                                    191 	.globl _SPI0_SETUP
                                    192 	.globl _SPI0_CK_SE
                                    193 	.globl _SPI0_CTRL
                                    194 	.globl _SPI0_DATA
                                    195 	.globl _SPI0_STAT
                                    196 	.globl _T2CAP1H
                                    197 	.globl _T2CAP1L
                                    198 	.globl _T2CAP1
                                    199 	.globl _TH2
                                    200 	.globl _TL2
                                    201 	.globl _T2COUNT
                                    202 	.globl _RCAP2H
                                    203 	.globl _RCAP2L
                                    204 	.globl _RCAP2
                                    205 	.globl _T2MOD
                                    206 	.globl _T2CON
                                    207 	.globl _SBUF
                                    208 	.globl _SCON
                                    209 	.globl _TH1
                                    210 	.globl _TH0
                                    211 	.globl _TL1
                                    212 	.globl _TL0
                                    213 	.globl _TMOD
                                    214 	.globl _TCON
                                    215 	.globl _XBUS_AUX
                                    216 	.globl _P7
                                    217 	.globl _P6_DIR
                                    218 	.globl _P6_OUT_PU
                                    219 	.globl _P6_IN
                                    220 	.globl _P5_DIR
                                    221 	.globl _P5_OUT_PU
                                    222 	.globl _P5_IN
                                    223 	.globl _P4_LED_KEY
                                    224 	.globl _P4_DIR_PU
                                    225 	.globl _P4_MOD_OC
                                    226 	.globl _P4
                                    227 	.globl _P3_DIR_PU
                                    228 	.globl _P3_MOD_OC
                                    229 	.globl _P3
                                    230 	.globl _P2_DIR_PU
                                    231 	.globl _P2_MOD_OC
                                    232 	.globl _P2
                                    233 	.globl _P1_DIR_PU
                                    234 	.globl _P1_MOD_OC
                                    235 	.globl _P1
                                    236 	.globl _P0_DIR_PU
                                    237 	.globl _P0_MOD_OC
                                    238 	.globl _P0
                                    239 	.globl _ROM_CTRL
                                    240 	.globl _ROM_DATA_HH
                                    241 	.globl _ROM_DATA_HL
                                    242 	.globl _ROM_DATA_HI
                                    243 	.globl _ROM_ADDR_H
                                    244 	.globl _ROM_ADDR_L
                                    245 	.globl _ROM_ADDR
                                    246 	.globl _GPIO_IE
                                    247 	.globl _IP_EX
                                    248 	.globl _IE_EX
                                    249 	.globl _IP
                                    250 	.globl _IE
                                    251 	.globl _WDOG_COUNT
                                    252 	.globl _RESET_KEEP
                                    253 	.globl _WAKE_CTRL
                                    254 	.globl _CLOCK_CFG
                                    255 	.globl _POWER_CFG
                                    256 	.globl _PCON
                                    257 	.globl _GLOBAL_CFG
                                    258 	.globl _SAFE_MOD
                                    259 	.globl _DPH
                                    260 	.globl _DPL
                                    261 	.globl _SP
                                    262 	.globl _A_INV
                                    263 	.globl _B
                                    264 	.globl _ACC
                                    265 	.globl _PSW
                                    266 	.globl _vialrgb_save_PARM_2
                                    267 	.globl _vialrgb_set_value_PARM_2
                                    268 	.globl _vialrgb_get_value_PARM_2
                                    269 	.globl _g_direct_mode_colors
                                    270 	.globl _vialrgb_get_value
                                    271 	.globl _vialrgb_set_value
                                    272 	.globl _vialrgb_save
                                    273 ;--------------------------------------------------------
                                    274 ; special function registers
                                    275 ;--------------------------------------------------------
                                    276 	.area RSEG    (ABS,DATA)
      000000                        277 	.org 0x0000
                           0000D0   278 _PSW	=	0x00d0
                           0000E0   279 _ACC	=	0x00e0
                           0000F0   280 _B	=	0x00f0
                           0000FD   281 _A_INV	=	0x00fd
                           000081   282 _SP	=	0x0081
                           000082   283 _DPL	=	0x0082
                           000083   284 _DPH	=	0x0083
                           0000A1   285 _SAFE_MOD	=	0x00a1
                           0000B1   286 _GLOBAL_CFG	=	0x00b1
                           000087   287 _PCON	=	0x0087
                           0000BA   288 _POWER_CFG	=	0x00ba
                           0000B9   289 _CLOCK_CFG	=	0x00b9
                           0000A9   290 _WAKE_CTRL	=	0x00a9
                           0000FE   291 _RESET_KEEP	=	0x00fe
                           0000FF   292 _WDOG_COUNT	=	0x00ff
                           0000A8   293 _IE	=	0x00a8
                           0000B8   294 _IP	=	0x00b8
                           0000E8   295 _IE_EX	=	0x00e8
                           0000E9   296 _IP_EX	=	0x00e9
                           0000B2   297 _GPIO_IE	=	0x00b2
                           008584   298 _ROM_ADDR	=	0x8584
                           000084   299 _ROM_ADDR_L	=	0x0084
                           000085   300 _ROM_ADDR_H	=	0x0085
                           008F8E   301 _ROM_DATA_HI	=	0x8f8e
                           00008E   302 _ROM_DATA_HL	=	0x008e
                           00008F   303 _ROM_DATA_HH	=	0x008f
                           000086   304 _ROM_CTRL	=	0x0086
                           000080   305 _P0	=	0x0080
                           0000C4   306 _P0_MOD_OC	=	0x00c4
                           0000C5   307 _P0_DIR_PU	=	0x00c5
                           000090   308 _P1	=	0x0090
                           000092   309 _P1_MOD_OC	=	0x0092
                           000093   310 _P1_DIR_PU	=	0x0093
                           0000A0   311 _P2	=	0x00a0
                           000094   312 _P2_MOD_OC	=	0x0094
                           000095   313 _P2_DIR_PU	=	0x0095
                           0000B0   314 _P3	=	0x00b0
                           000096   315 _P3_MOD_OC	=	0x0096
                           000097   316 _P3_DIR_PU	=	0x0097
                           0000C0   317 _P4	=	0x00c0
                           0000C2   318 _P4_MOD_OC	=	0x00c2
                           0000C3   319 _P4_DIR_PU	=	0x00c3
                           0000C1   320 _P4_LED_KEY	=	0x00c1
                           0000AA   321 _P5_IN	=	0x00aa
                           0000AB   322 _P5_OUT_PU	=	0x00ab
                           0000AC   323 _P5_DIR	=	0x00ac
                           0000AD   324 _P6_IN	=	0x00ad
                           0000AE   325 _P6_OUT_PU	=	0x00ae
                           0000AF   326 _P6_DIR	=	0x00af
                           0000F1   327 _P7	=	0x00f1
                           0000A2   328 _XBUS_AUX	=	0x00a2
                           000088   329 _TCON	=	0x0088
                           000089   330 _TMOD	=	0x0089
                           00008A   331 _TL0	=	0x008a
                           00008B   332 _TL1	=	0x008b
                           00008C   333 _TH0	=	0x008c
                           00008D   334 _TH1	=	0x008d
                           000098   335 _SCON	=	0x0098
                           000099   336 _SBUF	=	0x0099
                           0000C8   337 _T2CON	=	0x00c8
                           0000C9   338 _T2MOD	=	0x00c9
                           00CBCA   339 _RCAP2	=	0xcbca
                           0000CA   340 _RCAP2L	=	0x00ca
                           0000CB   341 _RCAP2H	=	0x00cb
                           00CDCC   342 _T2COUNT	=	0xcdcc
                           0000CC   343 _TL2	=	0x00cc
                           0000CD   344 _TH2	=	0x00cd
                           00CFCE   345 _T2CAP1	=	0xcfce
                           0000CE   346 _T2CAP1L	=	0x00ce
                           0000CF   347 _T2CAP1H	=	0x00cf
                           0000F8   348 _SPI0_STAT	=	0x00f8
                           0000F9   349 _SPI0_DATA	=	0x00f9
                           0000FA   350 _SPI0_CTRL	=	0x00fa
                           0000FB   351 _SPI0_CK_SE	=	0x00fb
                           0000FC   352 _SPI0_SETUP	=	0x00fc
                           0000BC   353 _SCON1	=	0x00bc
                           0000BD   354 _SBUF1	=	0x00bd
                           0000BE   355 _SBAUD1	=	0x00be
                           0000BF   356 _SIF1	=	0x00bf
                           0000B4   357 _SPI1_STAT	=	0x00b4
                           0000B5   358 _SPI1_DATA	=	0x00b5
                           0000B6   359 _SPI1_CTRL	=	0x00b6
                           0000B7   360 _SPI1_CK_SE	=	0x00b7
                           0000F3   361 _ADC_CTRL	=	0x00f3
                           00F5F4   362 _ADC_DAT	=	0xf5f4
                           0000F4   363 _ADC_DAT_L	=	0x00f4
                           0000F5   364 _ADC_DAT_H	=	0x00f5
                           0000F6   365 _ADC_CHAN	=	0x00f6
                           0000A6   366 _LED_COMMON	=	0x00a6
                           0000A7   367 _LED_PWM_OE	=	0x00a7
                           00C7C6   368 _LED_DMA	=	0xc7c6
                           0000C6   369 _LED_DMA_L	=	0x00c6
                           0000C7   370 _LED_DMA_H	=	0x00c7
                           0000F7   371 _LED_STATUS	=	0x00f7
                           0000B3   372 _I2CX_INT	=	0x00b3
                           0000BB   373 _I2CS_INT_ST	=	0x00bb
                                    374 ;--------------------------------------------------------
                                    375 ; special function bits
                                    376 ;--------------------------------------------------------
                                    377 	.area RSEG    (ABS,DATA)
      000000                        378 	.org 0x0000
                           0000D7   379 _CY	=	0x00d7
                           0000D6   380 _AC	=	0x00d6
                           0000D5   381 _F0	=	0x00d5
                           0000D4   382 _RS1	=	0x00d4
                           0000D3   383 _RS0	=	0x00d3
                           0000D2   384 _OV	=	0x00d2
                           0000D1   385 _F1	=	0x00d1
                           0000D0   386 _P	=	0x00d0
                           0000AF   387 _EA	=	0x00af
                           0000AE   388 _E_DIS	=	0x00ae
                           0000AD   389 _ET2	=	0x00ad
                           0000AC   390 _ES	=	0x00ac
                           0000AB   391 _ET1	=	0x00ab
                           0000AA   392 _EX1	=	0x00aa
                           0000A9   393 _ET0	=	0x00a9
                           0000A8   394 _EX0	=	0x00a8
                           0000BF   395 _PH_FLAG	=	0x00bf
                           0000BE   396 _PL_FLAG	=	0x00be
                           0000BD   397 _PT2	=	0x00bd
                           0000BC   398 _PS	=	0x00bc
                           0000BB   399 _PT1	=	0x00bb
                           0000BA   400 _PX1	=	0x00ba
                           0000B9   401 _PT0	=	0x00b9
                           0000B8   402 _PX0	=	0x00b8
                           0000EF   403 _IE_WDOG	=	0x00ef
                           0000EE   404 _IE_GPIO	=	0x00ee
                           0000ED   405 _IE_PWM_I2C	=	0x00ed
                           0000EC   406 _IE_UART1	=	0x00ec
                           0000EB   407 _IE_ADC	=	0x00eb
                           0000E9   408 _IE_USB	=	0x00e9
                           0000E8   409 _IE_SPI0	=	0x00e8
                           000087   410 _P0_7	=	0x0087
                           000086   411 _P0_6	=	0x0086
                           000085   412 _P0_5	=	0x0085
                           000084   413 _P0_4	=	0x0084
                           000083   414 _P0_3	=	0x0083
                           000082   415 _P0_2	=	0x0082
                           000081   416 _P0_1	=	0x0081
                           000080   417 _P0_0	=	0x0080
                           000081   418 _SDA0	=	0x0081
                           000080   419 _SCL0	=	0x0080
                           000083   420 _TXD_	=	0x0083
                           000082   421 _RXD_	=	0x0082
                           000085   422 _AIN13	=	0x0085
                           000084   423 _AIN12	=	0x0084
                           000083   424 _AIN11	=	0x0083
                           000082   425 _AIN10	=	0x0082
                           000081   426 _AIN9	=	0x0081
                           000080   427 _AIN8	=	0x0080
                           000097   428 _P1_7	=	0x0097
                           000096   429 _P1_6	=	0x0096
                           000095   430 _P1_5	=	0x0095
                           000094   431 _P1_4	=	0x0094
                           000093   432 _P1_3	=	0x0093
                           000092   433 _P1_2	=	0x0092
                           000091   434 _P1_1	=	0x0091
                           000090   435 _P1_0	=	0x0090
                           000097   436 _TXD1_	=	0x0097
                           000096   437 _RXD1_	=	0x0096
                           000097   438 _SCK	=	0x0097
                           000096   439 _MISO	=	0x0096
                           000095   440 _MOSI	=	0x0095
                           000094   441 _SCS	=	0x0094
                           000092   442 _INT0_	=	0x0092
                           000091   443 _T2EX	=	0x0091
                           000091   444 _CAP2	=	0x0091
                           000090   445 _T2	=	0x0090
                           000090   446 _CAP1	=	0x0090
                           000097   447 _AIN7	=	0x0097
                           000096   448 _AIN6	=	0x0096
                           000095   449 _AIN5	=	0x0095
                           000094   450 _AIN4	=	0x0094
                           000093   451 _AIN3	=	0x0093
                           000092   452 _AIN2	=	0x0092
                           000091   453 _AIN1	=	0x0091
                           000090   454 _AIN0	=	0x0090
                           0000A7   455 _P2_7	=	0x00a7
                           0000A6   456 _P2_6	=	0x00a6
                           0000A5   457 _P2_5	=	0x00a5
                           0000A4   458 _P2_4	=	0x00a4
                           0000A3   459 _P2_3	=	0x00a3
                           0000A2   460 _P2_2	=	0x00a2
                           0000A1   461 _P2_1	=	0x00a1
                           0000A0   462 _P2_0	=	0x00a0
                           0000A7   463 _TXD1	=	0x00a7
                           0000A6   464 _RXD1	=	0x00a6
                           0000A5   465 _T2EX_	=	0x00a5
                           0000A5   466 _CAP2_	=	0x00a5
                           0000A4   467 _T2_	=	0x00a4
                           0000A4   468 _CAP1_	=	0x00a4
                           0000B7   469 _P3_7	=	0x00b7
                           0000B6   470 _P3_6	=	0x00b6
                           0000B5   471 _P3_5	=	0x00b5
                           0000B4   472 _P3_4	=	0x00b4
                           0000B3   473 _P3_3	=	0x00b3
                           0000B2   474 _P3_2	=	0x00b2
                           0000B1   475 _P3_1	=	0x00b1
                           0000B0   476 _P3_0	=	0x00b0
                           0000B7   477 _SCK1	=	0x00b7
                           0000B6   478 _MISO1	=	0x00b6
                           0000B5   479 _MOSI1	=	0x00b5
                           0000B5   480 _T1	=	0x00b5
                           0000B4   481 _T0	=	0x00b4
                           0000B3   482 _INT1	=	0x00b3
                           0000B2   483 _INT0	=	0x00b2
                           0000B1   484 _TXD	=	0x00b1
                           0000B0   485 _RXD	=	0x00b0
                           0000C6   486 _P4_6	=	0x00c6
                           0000C5   487 _P4_5	=	0x00c5
                           0000C4   488 _P4_4	=	0x00c4
                           0000C3   489 _P4_3	=	0x00c3
                           0000C2   490 _P4_2	=	0x00c2
                           0000C1   491 _P4_1	=	0x00c1
                           0000C0   492 _P4_0	=	0x00c0
                           00008F   493 _TF1	=	0x008f
                           00008E   494 _TR1	=	0x008e
                           00008D   495 _TF0	=	0x008d
                           00008C   496 _TR0	=	0x008c
                           00008B   497 _IE1	=	0x008b
                           00008A   498 _IT1	=	0x008a
                           000089   499 _IE0	=	0x0089
                           000088   500 _IT0	=	0x0088
                           00009F   501 _SM0	=	0x009f
                           00009E   502 _SM1	=	0x009e
                           00009D   503 _SM2	=	0x009d
                           00009C   504 _REN	=	0x009c
                           00009B   505 _TB8	=	0x009b
                           00009A   506 _RB8	=	0x009a
                           000099   507 _TI	=	0x0099
                           000098   508 _RI	=	0x0098
                           0000CF   509 _TF2	=	0x00cf
                           0000CF   510 _CAP1F	=	0x00cf
                           0000CE   511 _EXF2	=	0x00ce
                           0000CD   512 _RCLK	=	0x00cd
                           0000CC   513 _TCLK	=	0x00cc
                           0000CB   514 _EXEN2	=	0x00cb
                           0000CA   515 _TR2	=	0x00ca
                           0000C9   516 _C_T2	=	0x00c9
                           0000C8   517 _CP_RL2	=	0x00c8
                           0000FF   518 _S0_FST_ACT	=	0x00ff
                           0000FE   519 _S0_IF_OV	=	0x00fe
                           0000FD   520 _S0_IF_FIRST	=	0x00fd
                           0000FC   521 _S0_IF_BYTE	=	0x00fc
                           0000FB   522 _S0_FREE	=	0x00fb
                           0000FA   523 _S0_T_FIFO	=	0x00fa
                           0000F8   524 _S0_R_FIFO	=	0x00f8
                           0000F7   525 _ADC_START	=	0x00f7
                                    526 ;--------------------------------------------------------
                                    527 ; overlayable register banks
                                    528 ;--------------------------------------------------------
                                    529 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        530 	.ds 8
                                    531 ;--------------------------------------------------------
                                    532 ; internal ram data
                                    533 ;--------------------------------------------------------
                                    534 	.area DSEG    (DATA)
      00004A                        535 _fast_set_leds_sloc0_1_0:
      00004A                        536 	.ds 2
      00004C                        537 _fast_set_leds_sloc1_1_0:
      00004C                        538 	.ds 2
      00004E                        539 _vialrgb_get_value_sloc0_1_0:
      00004E                        540 	.ds 2
      000050                        541 _vialrgb_get_value_sloc1_1_0:
      000050                        542 	.ds 2
      000052                        543 _vialrgb_set_value_sloc0_1_0:
      000052                        544 	.ds 2
                                    545 ;--------------------------------------------------------
                                    546 ; overlayable items in internal ram
                                    547 ;--------------------------------------------------------
                                    548 ;--------------------------------------------------------
                                    549 ; indirectly addressable internal ram data
                                    550 ;--------------------------------------------------------
                                    551 	.area ISEG    (DATA)
                                    552 ;--------------------------------------------------------
                                    553 ; absolute internal ram data
                                    554 ;--------------------------------------------------------
                                    555 	.area IABS    (ABS,DATA)
                                    556 	.area IABS    (ABS,DATA)
                                    557 ;--------------------------------------------------------
                                    558 ; bit data
                                    559 ;--------------------------------------------------------
                                    560 	.area BSEG    (BIT)
                                    561 ;--------------------------------------------------------
                                    562 ; paged external ram data
                                    563 ;--------------------------------------------------------
                                    564 	.area PSEG    (PAG,XDATA)
                                    565 ;--------------------------------------------------------
                                    566 ; uninitialized external ram data
                                    567 ;--------------------------------------------------------
                                    568 	.area XSEG    (XDATA)
      000C75                        569 _g_direct_mode_colors::
      000C75                        570 	.ds 246
      000D6B                        571 _get_supported_PARM_2:
      000D6B                        572 	.ds 1
      000D6C                        573 _get_supported_args_10000_255:
      000D6C                        574 	.ds 2
      000D6E                        575 _qmk_id_to_vialrgb_id_id_10000_262:
      000D6E                        576 	.ds 2
      000D70                        577 _vialrgb_id_to_qmk_id_id_10000_267:
      000D70                        578 	.ds 2
      000D72                        579 _set_mode_mode_10000_275:
      000D72                        580 	.ds 2
      000D74                        581 _get_matrix_pos_for_led_PARM_2:
      000D74                        582 	.ds 2
      000D76                        583 _get_matrix_pos_for_led_led_10000_280:
      000D76                        584 	.ds 2
      000D78                        585 _fast_set_leds_PARM_2:
      000D78                        586 	.ds 1
      000D79                        587 _fast_set_leds_args_10000_282:
      000D79                        588 	.ds 2
      000D7B                        589 _fast_set_leds_first_index_10001_285:
      000D7B                        590 	.ds 2
      000D7D                        591 _fast_set_leds_num_leds_10001_285:
      000D7D                        592 	.ds 1
      000D7E                        593 _vialrgb_get_value_PARM_2:
      000D7E                        594 	.ds 1
      000D7F                        595 _vialrgb_get_value_data_10000_291:
      000D7F                        596 	.ds 3
      000D82                        597 _vialrgb_set_value_PARM_2:
      000D82                        598 	.ds 1
      000D83                        599 _vialrgb_set_value_data_10000_302:
      000D83                        600 	.ds 3
      000D86                        601 _vialrgb_save_PARM_2:
      000D86                        602 	.ds 1
                                    603 ;--------------------------------------------------------
                                    604 ; absolute external ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area XABS    (ABS,XDATA)
                                    607 ;--------------------------------------------------------
                                    608 ; initialized external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area XISEG   (XDATA)
                                    611 	.area HOME    (CODE)
                                    612 	.area GSINIT0 (CODE)
                                    613 	.area GSINIT1 (CODE)
                                    614 	.area GSINIT2 (CODE)
                                    615 	.area GSINIT3 (CODE)
                                    616 	.area GSINIT4 (CODE)
                                    617 	.area GSINIT5 (CODE)
                                    618 	.area GSINIT  (CODE)
                                    619 	.area GSFINAL (CODE)
                                    620 	.area CSEG    (CODE)
                                    621 ;--------------------------------------------------------
                                    622 ; global & static initialisations
                                    623 ;--------------------------------------------------------
                                    624 	.area HOME    (CODE)
                                    625 	.area GSINIT  (CODE)
                                    626 	.area GSFINAL (CODE)
                                    627 	.area GSINIT  (CODE)
                                    628 ;--------------------------------------------------------
                                    629 ; Home
                                    630 ;--------------------------------------------------------
                                    631 	.area HOME    (CODE)
                                    632 	.area HOME    (CODE)
                                    633 ;--------------------------------------------------------
                                    634 ; code
                                    635 ;--------------------------------------------------------
                                    636 	.area CSEG    (CODE)
                                    637 ;------------------------------------------------------------
                                    638 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    639 ;------------------------------------------------------------
                                    640 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_167'
                                    641 ;------------------------------------------------------------
                                    642 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    643 ;	-----------------------------------------
                           000007   644 	ar7 = 0x07
                           000006   645 	ar6 = 0x06
                           000005   646 	ar5 = 0x05
                           000004   647 	ar4 = 0x04
                           000003   648 	ar3 = 0x03
                           000002   649 	ar2 = 0x02
                           000001   650 	ar1 = 0x01
                           000000   651 	ar0 = 0x00
                                    652 ;	 function get_supported
                                    653 ;	-----------------------------------------
      00B3BC                        654 _get_supported:
      00B3BC 12 3A 84         [24]  655 	lcall	_ak820_outline_0103
      00B3BF 90 0D 6C         [24]  656 	mov	dptr,#_get_supported_args_10000_255
      00B3C2 12 3A 89         [24]  657 	lcall	_ak820_outline_0104
                                    658 ;	quantum/vialrgb.c:44: uint16_t gt = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00B3C5 90 0D 6C         [24]  659 	mov	dptr,#_get_supported_args_10000_255
      00B3C8 12 39 E1         [24]  660 	lcall	_ak820_outline_0004
      00B3CB E0               [24]  661 	movx	a,@dptr
      00B3CC FD               [12]  662 	mov	r5,a
      00B3CD 7C 00            [12]  663 	mov	r4,#0x00
      00B3CF 12 3A 8E         [24]  664 	lcall	_ak820_outline_0108
      00B3D2 FA               [12]  665 	mov	r2,a
      00B3D3 E4               [12]  666 	clr	a
      00B3D4 12 45 DF         [24]  667 	lcall	_ak820_outline_0139
                                    668 ;	quantum/vialrgb.c:45: for (uint8_t i = 0; i < length; ++i) args[i] = 0xff;
      00B3D7 90 0D 6B         [24]  669 	mov	dptr,#_get_supported_PARM_2
      00B3DA E0               [24]  670 	movx	a,@dptr
      00B3DB FB               [12]  671 	mov	r3,a
      00B3DC 7A 00            [12]  672 	mov	r2,#0x00
      00B3DE                        673 00107$:
      00B3DE C3               [12]  674 	clr	c
      00B3DF EA               [12]  675 	mov	a,r2
      00B3E0 9B               [12]  676 	subb	a,r3
      00B3E1 50 0A            [24]  677 	jnc	00101$
      00B3E3 EA               [12]  678 	mov	a,r2
      00B3E4 12 3A 31         [24]  679 	lcall	_ak820_outline_0031
      00B3E7 74 FF            [12]  680 	mov	a,#0xff
      00B3E9 F0               [24]  681 	movx	@dptr,a
      00B3EA 0A               [12]  682 	inc	r2
      00B3EB 80 F1            [24]  683 	sjmp	00107$
      00B3ED                        684 00101$:
                                    685 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B3ED 8D 06            [24]  686 	mov	ar6,r5
      00B3EF 8C 07            [24]  687 	mov	ar7,r4
      00B3F1 8B 05            [24]  688 	mov	ar5,r3
      00B3F3 90 0D 6C         [24]  689 	mov	dptr,#_get_supported_args_10000_255
      00B3F6 12 3A 9A         [24]  690 	lcall	_ak820_outline_0121
      00B3F9 7A 00            [12]  691 	mov	r2,#0x00
      00B3FB                        692 00110$:
      00B3FB BA 07 00         [24]  693 	cjne	r2,#0x07,00159$
      00B3FE                        694 00159$:
      00B3FE 50 46            [24]  695 	jnc	00127$
                                    696 ;	quantum/vialrgb.c:47: uint16_t id = READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00B400 EA               [12]  697 	mov	a,r2
      00B401 75 F0 02         [24]  698 	mov	b,#0x02
      00B404 A4               [48]  699 	mul	ab
      00B405 24 5F            [12]  700 	add	a, #_supported_modes
      00B407 F5 82            [12]  701 	mov	dpl,a
      00B409 74 C0            [12]  702 	mov	a,#(_supported_modes >> 8)
      00B40B 12 59 ED         [24]  703 	lcall	_ak820_outline_0105
      00B40E F8               [12]  704 	mov	r0,a
      00B40F 79 00            [12]  705 	mov	r1,#0x00
                                    706 ;	quantum/vialrgb.c:48: if (id > gt && length >= sizeof(id)) {
      00B411 C3               [12]  707 	clr	c
      00B412 EE               [12]  708 	mov	a,r6
      00B413 98               [12]  709 	subb	a,r0
      00B414 EF               [12]  710 	mov	a,r7
      00B415 99               [12]  711 	subb	a,r1
      00B416 50 2B            [24]  712 	jnc	00111$
                                    713 ;	free result
      00B418 BD 02 00         [24]  714 	cjne	r5,#0x02,00162$
      00B41B                        715 00162$:
      00B41B 40 26            [24]  716 	jc	00111$
                                    717 ;	quantum/vialrgb.c:49: args[0] = id;
      00B41D C0 06            [24]  718 	push	ar6
      00B41F C0 07            [24]  719 	push	ar7
      00B421 88 07            [24]  720 	mov	ar7,r0
      00B423 12 36 42         [24]  721 	lcall	_ak820_outline_0122
      00B426 EF               [12]  722 	mov	a,r7
      00B427 F0               [24]  723 	movx	@dptr,a
                                    724 ;	quantum/vialrgb.c:50: args[1] = id >> 8;
      00B428 12 36 42         [24]  725 	lcall	_ak820_outline_0122
      00B42B A3               [24]  726 	inc	dptr
      00B42C 89 00            [24]  727 	mov	ar0,r1
      00B42E E8               [12]  728 	mov	a,r0
      00B42F F0               [24]  729 	movx	@dptr,a
                                    730 ;	quantum/vialrgb.c:51: length -= sizeof(id);
      00B430 1D               [12]  731 	dec	r5
      00B431 1D               [12]  732 	dec	r5
                                    733 ;	quantum/vialrgb.c:52: args += sizeof(id);
      00B432 74 02            [12]  734 	mov	a,#0x02
      00B434 2B               [12]  735 	add	a, r3
      00B435 FB               [12]  736 	mov	r3,a
      00B436 E4               [12]  737 	clr	a
      00B437 3C               [12]  738 	addc	a, r4
      00B438 FC               [12]  739 	mov	r4,a
      00B439 90 0D 6C         [24]  740 	mov	dptr,#_get_supported_args_10000_255
      00B43C 12 3A 6C         [24]  741 	lcall	_ak820_outline_0077
                                    742 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B43F D0 07            [24]  743 	pop	ar7
      00B441 D0 06            [24]  744 	pop	ar6
                                    745 ;	quantum/vialrgb.c:52: args += sizeof(id);
      00B443                        746 00111$:
                                    747 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B443 0A               [12]  748 	inc	r2
      00B444 80 B5            [24]  749 	sjmp	00110$
      00B446                        750 00127$:
      00B446 90 0D 6C         [24]  751 	mov	dptr,#_get_supported_args_10000_255
      00B449 12 3A 6C         [24]  752 	lcall	_ak820_outline_0077
                                    753 ;	quantum/vialrgb.c:55: }
      00B44C 22               [24]  754 	ret
                                    755 ;------------------------------------------------------------
                                    756 ;Allocation info for local variables in function 'qmk_id_to_vialrgb_id'
                                    757 ;------------------------------------------------------------
                                    758 ;id            Allocated with name '_qmk_id_to_vialrgb_id_id_10000_262'
                                    759 ;i             Allocated with name '_qmk_id_to_vialrgb_id_i_20000_264'
                                    760 ;qmk_id        Allocated with name '_qmk_id_to_vialrgb_id_qmk_id_30000_265'
                                    761 ;------------------------------------------------------------
                                    762 ;	quantum/vialrgb.c:57: static uint16_t qmk_id_to_vialrgb_id(uint16_t id) {
                                    763 ;	-----------------------------------------
                                    764 ;	 function qmk_id_to_vialrgb_id
                                    765 ;	-----------------------------------------
      00B44D                        766 _qmk_id_to_vialrgb_id:
      00B44D 12 3A 84         [24]  767 	lcall	_ak820_outline_0103
      00B450 90 0D 6E         [24]  768 	mov	dptr,#_qmk_id_to_vialrgb_id_id_10000_262
      00B453 12 3A 89         [24]  769 	lcall	_ak820_outline_0104
                                    770 ;	quantum/vialrgb.c:58: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B456 90 0D 6E         [24]  771 	mov	dptr,#_qmk_id_to_vialrgb_id_id_10000_262
      00B459 12 3A 41         [24]  772 	lcall	_ak820_outline_0051
      00B45C 7D 00            [12]  773 	mov	r5,#0x00
      00B45E                        774 00105$:
      00B45E BD 07 00         [24]  775 	cjne	r5,#0x07,00130$
      00B461                        776 00130$:
      00B461 50 19            [24]  777 	jnc	00103$
                                    778 ;	quantum/vialrgb.c:59: uint16_t qmk_id = READ_MODE_ID(&supported_modes[i].qmk_id);
      00B463 12 B8 7E         [24]  779 	lcall	_ak820_outline_0045
      00B466 A3               [24]  780 	inc	dptr
      00B467 E4               [12]  781 	clr	a
      00B468 93               [24]  782 	movc	a,@a+dptr
                                    783 ;	quantum/vialrgb.c:60: if (qmk_id == id)
      00B469 7A 00            [12]  784 	mov	r2,#0x00
      00B46B B5 06 0B         [24]  785 	cjne	a,ar6,00106$
      00B46E EA               [12]  786 	mov	a,r2
      00B46F B5 07 07         [24]  787 	cjne	a,ar7,00106$
                                    788 ;	quantum/vialrgb.c:61: return READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00B472 12 36 42         [24]  789 	lcall	_ak820_outline_0122
      00B475 12 B8 AA         [24]  790 	lcall	_ak820_outline_0141
      00B478 22               [24]  791 	ret
      00B479                        792 00106$:
                                    793 ;	quantum/vialrgb.c:58: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B479 0D               [12]  794 	inc	r5
      00B47A 80 E2            [24]  795 	sjmp	00105$
      00B47C                        796 00103$:
                                    797 ;	quantum/vialrgb.c:63: return 0;
      00B47C 90 00 00         [24]  798 	mov	dptr,#0x0000
                                    799 ;	quantum/vialrgb.c:64: }
      00B47F 22               [24]  800 	ret
                                    801 ;------------------------------------------------------------
                                    802 ;Allocation info for local variables in function 'vialrgb_id_to_qmk_id'
                                    803 ;------------------------------------------------------------
                                    804 ;id            Allocated with name '_vialrgb_id_to_qmk_id_id_10000_267'
                                    805 ;i             Allocated with name '_vialrgb_id_to_qmk_id_i_20000_269'
                                    806 ;vialrgb_id    Allocated with name '_vialrgb_id_to_qmk_id_vialrgb_id_30000_270'
                                    807 ;------------------------------------------------------------
                                    808 ;	quantum/vialrgb.c:66: static uint16_t vialrgb_id_to_qmk_id(uint16_t id) {
                                    809 ;	-----------------------------------------
                                    810 ;	 function vialrgb_id_to_qmk_id
                                    811 ;	-----------------------------------------
      00B480                        812 _vialrgb_id_to_qmk_id:
      00B480 12 3A 84         [24]  813 	lcall	_ak820_outline_0103
      00B483 90 0D 70         [24]  814 	mov	dptr,#_vialrgb_id_to_qmk_id_id_10000_267
      00B486 12 3A 89         [24]  815 	lcall	_ak820_outline_0104
                                    816 ;	quantum/vialrgb.c:67: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B489 90 0D 70         [24]  817 	mov	dptr,#_vialrgb_id_to_qmk_id_id_10000_267
      00B48C 12 3A 41         [24]  818 	lcall	_ak820_outline_0051
      00B48F 7D 00            [12]  819 	mov	r5,#0x00
      00B491                        820 00105$:
      00B491 BD 07 00         [24]  821 	cjne	r5,#0x07,00130$
      00B494                        822 00130$:
      00B494 50 19            [24]  823 	jnc	00103$
                                    824 ;	quantum/vialrgb.c:68: uint16_t vialrgb_id = READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00B496 12 B8 7E         [24]  825 	lcall	_ak820_outline_0045
      00B499 E4               [12]  826 	clr	a
      00B49A 93               [24]  827 	movc	a,@a+dptr
                                    828 ;	quantum/vialrgb.c:69: if (vialrgb_id == id)
      00B49B 7A 00            [12]  829 	mov	r2,#0x00
      00B49D B5 06 0C         [24]  830 	cjne	a,ar6,00106$
      00B4A0 EA               [12]  831 	mov	a,r2
      00B4A1 B5 07 08         [24]  832 	cjne	a,ar7,00106$
                                    833 ;	quantum/vialrgb.c:70: return READ_MODE_ID(&supported_modes[i].qmk_id);
      00B4A4 12 36 42         [24]  834 	lcall	_ak820_outline_0122
      00B4A7 A3               [24]  835 	inc	dptr
      00B4A8 12 B8 AA         [24]  836 	lcall	_ak820_outline_0141
      00B4AB 22               [24]  837 	ret
      00B4AC                        838 00106$:
                                    839 ;	quantum/vialrgb.c:67: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B4AC 0D               [12]  840 	inc	r5
      00B4AD 80 E2            [24]  841 	sjmp	00105$
      00B4AF                        842 00103$:
                                    843 ;	quantum/vialrgb.c:72: return 0;
      00B4AF 90 00 00         [24]  844 	mov	dptr,#0x0000
                                    845 ;	quantum/vialrgb.c:73: }
      00B4B2 22               [24]  846 	ret
                                    847 ;------------------------------------------------------------
                                    848 ;Allocation info for local variables in function 'get_mode'
                                    849 ;------------------------------------------------------------
                                    850 ;	quantum/vialrgb.c:75: static uint16_t get_mode(void) {
                                    851 ;	-----------------------------------------
                                    852 ;	 function get_mode
                                    853 ;	-----------------------------------------
      00B4B3                        854 _get_mode:
                                    855 ;	quantum/vialrgb.c:77: if (!rgb_matrix_is_enabled())
      00B4B3 12 57 E1         [24]  856 	lcall	_rgb_matrix_is_enabled
      00B4B6 E5 82            [12]  857 	mov	a, dpl
      00B4B8 70 04            [24]  858 	jnz	00102$
                                    859 ;	quantum/vialrgb.c:78: return VIALRGB_EFFECT_OFF;
      00B4BA 90 00 00         [24]  860 	mov	dptr,#0x0000
      00B4BD 22               [24]  861 	ret
      00B4BE                        862 00102$:
                                    863 ;	quantum/vialrgb.c:79: return qmk_id_to_vialrgb_id(rgb_matrix_get_mode());
      00B4BE 12 57 E7         [24]  864 	lcall	_rgb_matrix_get_mode
      00B4C1 7E 00            [12]  865 	mov	r6,#0x00
      00B4C3 8E 83            [24]  866 	mov	dph, r6
                                    867 ;	quantum/vialrgb.c:80: }
      00B4C5 81 4D            [12]  868 	ajmp	_qmk_id_to_vialrgb_id
                                    869 ;------------------------------------------------------------
                                    870 ;Allocation info for local variables in function 'set_mode'
                                    871 ;------------------------------------------------------------
                                    872 ;mode          Allocated with name '_set_mode_mode_10000_275'
                                    873 ;------------------------------------------------------------
                                    874 ;	quantum/vialrgb.c:82: static void set_mode(uint16_t mode) {
                                    875 ;	-----------------------------------------
                                    876 ;	 function set_mode
                                    877 ;	-----------------------------------------
      00B4C7                        878 _set_mode:
      00B4C7 12 3A 84         [24]  879 	lcall	_ak820_outline_0103
      00B4CA 90 0D 72         [24]  880 	mov	dptr,#_set_mode_mode_10000_275
      00B4CD 12 3A 89         [24]  881 	lcall	_ak820_outline_0104
                                    882 ;	quantum/vialrgb.c:84: if (mode == VIALRGB_EFFECT_OFF) {
      00B4D0 90 0D 72         [24]  883 	mov	dptr,#_set_mode_mode_10000_275
      00B4D3 12 3A 41         [24]  884 	lcall	_ak820_outline_0051
      00B4D6 90 0D 72         [24]  885 	mov	dptr,#_set_mode_mode_10000_275
      00B4D9 12 71 27         [24]  886 	lcall	_ak820_outline_0036
      00B4DC 70 03            [24]  887 	jnz	00102$
                                    888 ;	quantum/vialrgb.c:85: rgb_matrix_disable_noeeprom();
      00B4DE 02 58 34         [24]  889 	ljmp	_rgb_matrix_disable_noeeprom
      00B4E1                        890 00102$:
                                    891 ;	quantum/vialrgb.c:87: rgb_matrix_enable_noeeprom();
      00B4E1 C0 07            [24]  892 	push	ar7
      00B4E3 C0 06            [24]  893 	push	ar6
      00B4E5 12 58 23         [24]  894 	lcall	_rgb_matrix_enable_noeeprom
      00B4E8 D0 06            [24]  895 	pop	ar6
      00B4EA D0 07            [24]  896 	pop	ar7
                                    897 ;	quantum/vialrgb.c:88: rgb_matrix_mode_noeeprom(vialrgb_id_to_qmk_id(mode));
      00B4EC 12 45 C9         [24]  898 	lcall	_ak820_outline_0116
      00B4EF 91 80            [12]  899 	acall	_vialrgb_id_to_qmk_id
                                    900 ;	quantum/vialrgb.c:90: }
      00B4F1 02 58 3D         [24]  901 	ljmp	_rgb_matrix_mode_noeeprom
                                    902 ;------------------------------------------------------------
                                    903 ;Allocation info for local variables in function 'get_matrix_pos_for_led'
                                    904 ;------------------------------------------------------------
                                    905 ;output        Allocated with name '_get_matrix_pos_for_led_PARM_2'
                                    906 ;led           Allocated with name '_get_matrix_pos_for_led_led_10000_280'
                                    907 ;slot          Allocated with name '_get_matrix_pos_for_led_slot_10000_281'
                                    908 ;------------------------------------------------------------
                                    909 ;	quantum/vialrgb.c:93: static void get_matrix_pos_for_led(uint16_t led, uint8_t VIALRGB_BUFFER *output) {
                                    910 ;	-----------------------------------------
                                    911 ;	 function get_matrix_pos_for_led
                                    912 ;	-----------------------------------------
      00B4F4                        913 _get_matrix_pos_for_led:
      00B4F4 12 3A 84         [24]  914 	lcall	_ak820_outline_0103
      00B4F7 90 0D 76         [24]  915 	mov	dptr,#_get_matrix_pos_for_led_led_10000_280
      00B4FA 12 3A 89         [24]  916 	lcall	_ak820_outline_0104
                                    917 ;	quantum/vialrgb.c:95: uint8_t slot = ak820_rgb_slots[led];
      00B4FD 90 0D 76         [24]  918 	mov	dptr,#_get_matrix_pos_for_led_led_10000_280
      00B500 12 3A 41         [24]  919 	lcall	_ak820_outline_0051
      00B503 EE               [12]  920 	mov	a,r6
      00B504 24 66            [12]  921 	add	a, #_ak820_rgb_slots
      00B506 F5 82            [12]  922 	mov	dpl,a
      00B508 EF               [12]  923 	mov	a,r7
      00B509 34 BA            [12]  924 	addc	a, #(_ak820_rgb_slots >> 8)
      00B50B F5 83            [12]  925 	mov	dph,a
      00B50D E4               [12]  926 	clr	a
      00B50E 93               [24]  927 	movc	a,@a+dptr
      00B50F FF               [12]  928 	mov	r7,a
                                    929 ;	quantum/vialrgb.c:96: output[0] = slot >> 3;
      00B510 90 0D 74         [24]  930 	mov	dptr,#_get_matrix_pos_for_led_PARM_2
      00B513 12 45 B7         [24]  931 	lcall	_ak820_outline_0093
      00B516 EF               [12]  932 	mov	a,r7
      00B517 12 5A 23         [24]  933 	lcall	_ak820_outline_0183
      00B51A 12 83 EA         [24]  934 	lcall	_ak820_outline_0119
                                    935 ;	quantum/vialrgb.c:97: output[1] = slot & 7;
      00B51D 12 3A A5         [24]  936 	lcall	_ak820_outline_0132
      00B520 A3               [24]  937 	inc	dptr
      00B521 53 07 07         [24]  938 	anl	ar7,#0x07
      00B524 EF               [12]  939 	mov	a,r7
      00B525 F0               [24]  940 	movx	@dptr,a
                                    941 ;	quantum/vialrgb.c:110: }
      00B526 22               [24]  942 	ret
                                    943 ;------------------------------------------------------------
                                    944 ;Allocation info for local variables in function 'fast_set_leds'
                                    945 ;------------------------------------------------------------
                                    946 ;sloc0         Allocated with name '_fast_set_leds_sloc0_1_0'
                                    947 ;sloc1         Allocated with name '_fast_set_leds_sloc1_1_0'
                                    948 ;length        Allocated with name '_fast_set_leds_PARM_2'
                                    949 ;args          Allocated with name '_fast_set_leds_args_10000_282'
                                    950 ;first_index   Allocated with name '_fast_set_leds_first_index_10001_285'
                                    951 ;num_leds      Allocated with name '_fast_set_leds_num_leds_10001_285'
                                    952 ;i             Allocated with name '_fast_set_leds_i_20001_288'
                                    953 ;color         Allocated with name '_fast_set_leds_color_30001_289'
                                    954 ;val           Allocated with name '_fast_set_leds_val_30002_290'
                                    955 ;------------------------------------------------------------
                                    956 ;	quantum/vialrgb.c:112: static void fast_set_leds(uint8_t VIALRGB_BUFFER *args, uint8_t length) {
                                    957 ;	-----------------------------------------
                                    958 ;	 function fast_set_leds
                                    959 ;	-----------------------------------------
      00B527                        960 _fast_set_leds:
      00B527 12 3A 84         [24]  961 	lcall	_ak820_outline_0103
      00B52A 90 0D 79         [24]  962 	mov	dptr,#_fast_set_leds_args_10000_282
      00B52D 12 3A 89         [24]  963 	lcall	_ak820_outline_0104
                                    964 ;	quantum/vialrgb.c:115: if (length < 3) return;
      00B530 90 0D 78         [24]  965 	mov	dptr,#_fast_set_leds_PARM_2
      00B533 E0               [24]  966 	movx	a,@dptr
      00B534 FF               [12]  967 	mov	r7,a
      00B535 BF 03 00         [24]  968 	cjne	r7,#0x03,00159$
      00B538                        969 00159$:
      00B538 50 01            [24]  970 	jnc	00102$
      00B53A 22               [24]  971 	ret
      00B53B                        972 00102$:
                                    973 ;	quantum/vialrgb.c:117: uint16_t first_index = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00B53B 90 0D 79         [24]  974 	mov	dptr,#_fast_set_leds_args_10000_282
      00B53E 12 45 B7         [24]  975 	lcall	_ak820_outline_0093
      00B541 12 4B AF         [24]  976 	lcall	_ak820_outline_0075
      00B544 7B 00            [12]  977 	mov	r3,#0x00
      00B546 12 3A A5         [24]  978 	lcall	_ak820_outline_0132
      00B549 A3               [24]  979 	inc	dptr
      00B54A E0               [24]  980 	movx	a,@dptr
      00B54B FA               [12]  981 	mov	r2,a
      00B54C 79 00            [12]  982 	mov	r1,#0x00
      00B54E 90 0D 7B         [24]  983 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00B551 E9               [12]  984 	mov	a,r1
      00B552 4C               [12]  985 	orl	a,r4
      00B553 F0               [24]  986 	movx	@dptr,a
      00B554 EA               [12]  987 	mov	a,r2
      00B555 4B               [12]  988 	orl	a,r3
      00B556 A3               [24]  989 	inc	dptr
      00B557 F0               [24]  990 	movx	@dptr,a
                                    991 ;	quantum/vialrgb.c:118: uint8_t num_leds = args[2];
      00B558 12 3A A5         [24]  992 	lcall	_ak820_outline_0132
      00B55B A3               [24]  993 	inc	dptr
      00B55C A3               [24]  994 	inc	dptr
      00B55D E0               [24]  995 	movx	a,@dptr
      00B55E 90 0D 7D         [24]  996 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B561 F0               [24]  997 	movx	@dptr,a
                                    998 ;	quantum/vialrgb.c:119: length -= 3;
      00B562 EF               [12]  999 	mov	a,r7
      00B563 24 FD            [12] 1000 	add	a,#0xfd
      00B565 90 0D 78         [24] 1001 	mov	dptr,#_fast_set_leds_PARM_2
      00B568 F0               [24] 1002 	movx	@dptr,a
                                   1003 ;	quantum/vialrgb.c:120: args += 3;
      00B569 90 0D 79         [24] 1004 	mov	dptr,#_fast_set_leds_args_10000_282
      00B56C 74 03            [12] 1005 	mov	a,#0x03
      00B56E 2D               [12] 1006 	add	a, r5
      00B56F F0               [24] 1007 	movx	@dptr,a
      00B570 E4               [12] 1008 	clr	a
      00B571 3E               [12] 1009 	addc	a, r6
      00B572 A3               [24] 1010 	inc	dptr
      00B573 F0               [24] 1011 	movx	@dptr,a
                                   1012 ;	quantum/vialrgb.c:123: if ((uint16_t)num_leds * 3u > length || first_index >= RGB_MATRIX_LED_COUNT) return;
      00B574 90 0D 7D         [24] 1013 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B577 E0               [24] 1014 	movx	a,@dptr
      00B578 FF               [12] 1015 	mov	r7,a
      00B579 75 F0 03         [24] 1016 	mov	b,#0x03
      00B57C A4               [48] 1017 	mul	ab
      00B57D FE               [12] 1018 	mov	r6,a
      00B57E AD F0            [24] 1019 	mov	r5,b
      00B580 90 0D 78         [24] 1020 	mov	dptr,#_fast_set_leds_PARM_2
      00B583 E0               [24] 1021 	movx	a,@dptr
      00B584 FB               [12] 1022 	mov	r3,a
      00B585 7C 00            [12] 1023 	mov	r4,#0x00
      00B587 C3               [12] 1024 	clr	c
      00B588 EB               [12] 1025 	mov	a,r3
      00B589 9E               [12] 1026 	subb	a,r6
      00B58A EC               [12] 1027 	mov	a,r4
      00B58B 9D               [12] 1028 	subb	a,r5
      00B58C 40 13            [24] 1029 	jc	00103$
                                   1030 ;	free result
      00B58E 90 0D 7B         [24] 1031 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00B591 12 45 B7         [24] 1032 	lcall	_ak820_outline_0093
      00B594 8D 03            [24] 1033 	mov	ar3,r5
      00B596 8E 04            [24] 1034 	mov	ar4,r6
      00B598 C3               [12] 1035 	clr	c
      00B599 EB               [12] 1036 	mov	a,r3
      00B59A 94 52            [12] 1037 	subb	a,#0x52
      00B59C EC               [12] 1038 	mov	a,r4
      00B59D 94 00            [12] 1039 	subb	a,#0x00
      00B59F 40 01            [24] 1040 	jc	00104$
      00B5A1                       1041 00103$:
      00B5A1 22               [24] 1042 	ret
      00B5A2                       1043 00104$:
                                   1044 ;	quantum/vialrgb.c:124: if (num_leds > RGB_MATRIX_LED_COUNT - first_index) num_leds = RGB_MATRIX_LED_COUNT - first_index;
      00B5A2 74 52            [12] 1045 	mov	a,#0x52
      00B5A4 C3               [12] 1046 	clr	c
      00B5A5 9D               [12] 1047 	subb	a,r5
      00B5A6 FB               [12] 1048 	mov	r3,a
      00B5A7 E4               [12] 1049 	clr	a
      00B5A8 9E               [12] 1050 	subb	a,r6
      00B5A9 FC               [12] 1051 	mov	r4,a
      00B5AA 7A 00            [12] 1052 	mov	r2,#0x00
      00B5AC C3               [12] 1053 	clr	c
      00B5AD EB               [12] 1054 	mov	a,r3
      00B5AE 9F               [12] 1055 	subb	a,r7
      00B5AF EC               [12] 1056 	mov	a,r4
      00B5B0 9A               [12] 1057 	subb	a,r2
      00B5B1 50 08            [24] 1058 	jnc	00127$
                                   1059 ;	free result
      00B5B3 90 0D 7D         [24] 1060 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B5B6 74 52            [12] 1061 	mov	a,#0x52
      00B5B8 C3               [12] 1062 	clr	c
      00B5B9 9D               [12] 1063 	subb	a,r5
      00B5BA F0               [24] 1064 	movx	@dptr,a
                                   1065 ;	quantum/vialrgb.c:126: for (uint8_t i = 0; i < num_leds; ++i) {
      00B5BB                       1066 00127$:
      00B5BB 90 0D 7D         [24] 1067 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B5BE E0               [24] 1068 	movx	a,@dptr
      00B5BF FF               [12] 1069 	mov	r7,a
      00B5C0 90 0D 7B         [24] 1070 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00B5C3 12 45 B7         [24] 1071 	lcall	_ak820_outline_0093
      00B5C6 7C 00            [12] 1072 	mov	r4,#0x00
      00B5C8                       1073 00110$:
      00B5C8 C3               [12] 1074 	clr	c
      00B5C9 EC               [12] 1075 	mov	a,r4
      00B5CA 9F               [12] 1076 	subb	a,r7
      00B5CB 40 01            [24] 1077 	jc	00164$
      00B5CD 22               [24] 1078 	ret
      00B5CE                       1079 00164$:
                                   1080 ;	quantum/vialrgb.c:127: HSV VIALRGB_BUFFER *color = &g_direct_mode_colors[first_index++];
      00B5CE C0 07            [24] 1081 	push	ar7
      00B5D0 90 0D 95         [24] 1082 	mov	dptr,#__mulint_PARM_2
      00B5D3 12 45 FA         [24] 1083 	lcall	_ak820_outline_0157
      00B5D6 90 00 03         [24] 1084 	mov	dptr,#0x0003
      00B5D9 C0 07            [24] 1085 	push	ar7
      00B5DB C0 06            [24] 1086 	push	ar6
      00B5DD C0 05            [24] 1087 	push	ar5
      00B5DF C0 04            [24] 1088 	push	ar4
      00B5E1 12 BA 16         [24] 1089 	lcall	__mulint
      00B5E4 AA 82            [24] 1090 	mov	r2, dpl
      00B5E6 AB 83            [24] 1091 	mov	r3, dph
      00B5E8 D0 04            [24] 1092 	pop	ar4
      00B5EA D0 05            [24] 1093 	pop	ar5
      00B5EC D0 06            [24] 1094 	pop	ar6
      00B5EE D0 07            [24] 1095 	pop	ar7
      00B5F0 0D               [12] 1096 	inc	r5
      00B5F1 BD 00 01         [24] 1097 	cjne	r5,#0x00,00165$
      00B5F4 0E               [12] 1098 	inc	r6
      00B5F5                       1099 00165$:
      00B5F5 EA               [12] 1100 	mov	a,r2
      00B5F6 24 75            [12] 1101 	add	a, #_g_direct_mode_colors
      00B5F8 FA               [12] 1102 	mov	r2,a
      00B5F9 EB               [12] 1103 	mov	a,r3
      00B5FA 34 0C            [12] 1104 	addc	a, #(_g_direct_mode_colors >> 8)
      00B5FC FB               [12] 1105 	mov	r3,a
                                   1106 ;	quantum/vialrgb.c:128: color->h = *args++;
      00B5FD 8A 4A            [24] 1107 	mov	_fast_set_leds_sloc0_1_0,r2
      00B5FF 8B 4B            [24] 1108 	mov	(_fast_set_leds_sloc0_1_0 + 1),r3
      00B601 12 B8 90         [24] 1109 	lcall	_ak820_outline_0082
      00B604 F8               [12] 1110 	mov	r0,a
      00B605 12 B8 9E         [24] 1111 	lcall	_ak820_outline_0102
      00B608 85 4A 82         [24] 1112 	mov	dpl,_fast_set_leds_sloc0_1_0
      00B60B 85 4B 83         [24] 1113 	mov	dph,(_fast_set_leds_sloc0_1_0 + 1)
      00B60E E8               [12] 1114 	mov	a,r0
      00B60F F0               [24] 1115 	movx	@dptr,a
                                   1116 ;	quantum/vialrgb.c:129: color->s = *args++;
      00B610 74 01            [12] 1117 	mov	a,#0x01
      00B612 2A               [12] 1118 	add	a, r2
      00B613 F5 4A            [12] 1119 	mov	_fast_set_leds_sloc0_1_0,a
      00B615 E4               [12] 1120 	clr	a
      00B616 3B               [12] 1121 	addc	a, r3
      00B617 F5 4B            [12] 1122 	mov	(_fast_set_leds_sloc0_1_0 + 1),a
      00B619 90 0D 79         [24] 1123 	mov	dptr,#_fast_set_leds_args_10000_282
      00B61C E0               [24] 1124 	movx	a,@dptr
      00B61D F8               [12] 1125 	mov	r0,a
      00B61E A3               [24] 1126 	inc	dptr
      00B61F E0               [24] 1127 	movx	a,@dptr
      00B620 FF               [12] 1128 	mov	r7,a
      00B621 88 82            [24] 1129 	mov	dpl,r0
      00B623 8F 83            [24] 1130 	mov	dph,r7
      00B625 E0               [24] 1131 	movx	a,@dptr
      00B626 F9               [12] 1132 	mov	r1,a
      00B627 90 0D 79         [24] 1133 	mov	dptr,#_fast_set_leds_args_10000_282
      00B62A 74 01            [12] 1134 	mov	a,#0x01
      00B62C 28               [12] 1135 	add	a, r0
      00B62D F0               [24] 1136 	movx	@dptr,a
      00B62E E4               [12] 1137 	clr	a
      00B62F 3F               [12] 1138 	addc	a, r7
      00B630 A3               [24] 1139 	inc	dptr
      00B631 F0               [24] 1140 	movx	@dptr,a
      00B632 85 4A 82         [24] 1141 	mov	dpl,_fast_set_leds_sloc0_1_0
      00B635 85 4B 83         [24] 1142 	mov	dph,(_fast_set_leds_sloc0_1_0 + 1)
      00B638 E9               [12] 1143 	mov	a,r1
      00B639 F0               [24] 1144 	movx	@dptr,a
                                   1145 ;	quantum/vialrgb.c:130: uint8_t val = *args++;
      00B63A 12 B8 90         [24] 1146 	lcall	_ak820_outline_0082
      00B63D F5 4A            [12] 1147 	mov	_fast_set_leds_sloc0_1_0,a
      00B63F 12 B8 9E         [24] 1148 	lcall	_ak820_outline_0102
                                   1149 ;	quantum/vialrgb.c:131: color->v = (val > RGB_MATRIX_MAXIMUM_BRIGHTNESS) ? RGB_MATRIX_MAXIMUM_BRIGHTNESS : val;
      00B642 74 02            [12] 1150 	mov	a,#0x02
      00B644 2A               [12] 1151 	add	a, r2
      00B645 F5 4C            [12] 1152 	mov	_fast_set_leds_sloc1_1_0,a
      00B647 E4               [12] 1153 	clr	a
      00B648 3B               [12] 1154 	addc	a, r3
      00B649 F5 4D            [12] 1155 	mov	(_fast_set_leds_sloc1_1_0 + 1),a
      00B64B C3               [12] 1156 	clr	c
      00B64C 74 A0            [12] 1157 	mov	a,#0xa0
      00B64E 95 4A            [12] 1158 	subb	a,_fast_set_leds_sloc0_1_0
      00B650 D0 07            [24] 1159 	pop	ar7
      00B652 50 04            [24] 1160 	jnc	00114$
                                   1161 ;	free result
      00B654 7B A0            [12] 1162 	mov	r3,#0xa0
      00B656 80 04            [24] 1163 	sjmp	00115$
      00B658                       1164 00114$:
      00B658 AA 4A            [24] 1165 	mov	r2,_fast_set_leds_sloc0_1_0
      00B65A 8A 03            [24] 1166 	mov	ar3,r2
      00B65C                       1167 00115$:
      00B65C 85 4C 82         [24] 1168 	mov	dpl,_fast_set_leds_sloc1_1_0
      00B65F 85 4D 83         [24] 1169 	mov	dph,(_fast_set_leds_sloc1_1_0 + 1)
      00B662 EB               [12] 1170 	mov	a,r3
      00B663 F0               [24] 1171 	movx	@dptr,a
                                   1172 ;	quantum/vialrgb.c:126: for (uint8_t i = 0; i < num_leds; ++i) {
      00B664 0C               [12] 1173 	inc	r4
                                   1174 ;	quantum/vialrgb.c:133: }
      00B665 A1 C8            [24] 1175 	ajmp	00110$
                                   1176 ;------------------------------------------------------------
                                   1177 ;Allocation info for local variables in function 'vialrgb_get_value'
                                   1178 ;------------------------------------------------------------
                                   1179 ;sloc0         Allocated with name '_vialrgb_get_value_sloc0_1_0'
                                   1180 ;sloc1         Allocated with name '_vialrgb_get_value_sloc1_1_0'
                                   1181 ;length        Allocated with name '_vialrgb_get_value_PARM_2'
                                   1182 ;data          Allocated with name '_vialrgb_get_value_data_10000_291'
                                   1183 ;args          Allocated with name '_vialrgb_get_value_args_10001_294'
                                   1184 ;cmd           Allocated with name '_vialrgb_get_value_cmd_10001_294'
                                   1185 ;vialrgb_id    Allocated with name '_vialrgb_get_value_vialrgb_id_40001_297'
                                   1186 ;led           Allocated with name '_vialrgb_get_value_led_40001_300'
                                   1187 ;------------------------------------------------------------
                                   1188 ;	quantum/vialrgb.c:136: void vialrgb_get_value(uint8_t *data, uint8_t length) {
                                   1189 ;	-----------------------------------------
                                   1190 ;	 function vialrgb_get_value
                                   1191 ;	-----------------------------------------
      00B667                       1192 _vialrgb_get_value:
      00B667 12 45 80         [24] 1193 	lcall	_ak820_outline_0037
      00B66A 90 0D 7F         [24] 1194 	mov	dptr,#_vialrgb_get_value_data_10000_291
      00B66D 12 3A 20         [24] 1195 	lcall	_ak820_outline_0016
                                   1196 ;	quantum/vialrgb.c:137: if (length != VIAL_RAW_EPSIZE) return;
      00B670 90 0D 7E         [24] 1197 	mov	dptr,#_vialrgb_get_value_PARM_2
      00B673 E0               [24] 1198 	movx	a,@dptr
      00B674 FF               [12] 1199 	mov	r7,a
      00B675 BF 20 02         [24] 1200 	cjne	r7,#0x20,00162$
      00B678 80 01            [24] 1201 	sjmp	00102$
      00B67A                       1202 00162$:
      00B67A 22               [24] 1203 	ret
      00B67B                       1204 00102$:
                                   1205 ;	quantum/vialrgb.c:140: uint8_t VIALRGB_BUFFER *args = (uint8_t VIALRGB_BUFFER *)data + 2;
      00B67B 90 0D 7F         [24] 1206 	mov	dptr,#_vialrgb_get_value_data_10000_291
      00B67E 12 B8 6A         [24] 1207 	lcall	_ak820_outline_0043
                                   1208 ;	quantum/vialrgb.c:141: uint8_t cmd = args[-1];
                                   1209 ;	quantum/vialrgb.c:142: switch (cmd) {
      00B681 BA 40 02         [24] 1210 	cjne	r2,#0x40,00163$
      00B684 80 18            [24] 1211 	sjmp	00103$
      00B686                       1212 00163$:
      00B686 BA 41 02         [24] 1213 	cjne	r2,#0x41,00164$
      00B689 80 26            [24] 1214 	sjmp	00104$
      00B68B                       1215 00164$:
      00B68B BA 42 03         [24] 1216 	cjne	r2,#0x42,00165$
      00B68E 02 B7 42         [24] 1217 	ljmp	00105$
      00B691                       1218 00165$:
      00B691 BA 43 03         [24] 1219 	cjne	r2,#0x43,00166$
      00B694 02 B7 4F         [24] 1220 	ljmp	00106$
      00B697                       1221 00166$:
      00B697 BA 44 03         [24] 1222 	cjne	r2,#0x44,00167$
      00B69A 02 B7 5B         [24] 1223 	ljmp	00107$
      00B69D                       1224 00167$:
      00B69D 22               [24] 1225 	ret
                                   1226 ;	quantum/vialrgb.c:143: case vialrgb_get_info:
      00B69E                       1227 00103$:
                                   1228 ;	quantum/vialrgb.c:144: args[0] = VIALRGB_PROTOCOL_VERSION & 0xFF;
      00B69E 12 36 42         [24] 1229 	lcall	_ak820_outline_0122
      00B6A1 74 01            [12] 1230 	mov	a,#0x01
      00B6A3 F0               [24] 1231 	movx	@dptr,a
                                   1232 ;	quantum/vialrgb.c:145: args[1] = VIALRGB_PROTOCOL_VERSION >> 8;
      00B6A4 12 B8 62         [24] 1233 	lcall	_ak820_outline_0035
      00B6A7 E4               [12] 1234 	clr	a
      00B6A8 F0               [24] 1235 	movx	@dptr,a
                                   1236 ;	quantum/vialrgb.c:146: args[2] = RGB_MATRIX_MAXIMUM_BRIGHTNESS;
      00B6A9 12 B8 62         [24] 1237 	lcall	_ak820_outline_0035
      00B6AC A3               [24] 1238 	inc	dptr
      00B6AD 74 A0            [12] 1239 	mov	a,#0xa0
      00B6AF F0               [24] 1240 	movx	@dptr,a
                                   1241 ;	quantum/vialrgb.c:147: break;
      00B6B0 22               [24] 1242 	ret
                                   1243 ;	quantum/vialrgb.c:148: case vialrgb_get_mode: {
      00B6B1                       1244 00104$:
                                   1245 ;	quantum/vialrgb.c:149: uint16_t vialrgb_id = get_mode();
      00B6B1 C0 06            [24] 1246 	push	ar6
      00B6B3 C0 05            [24] 1247 	push	ar5
      00B6B5 C0 04            [24] 1248 	push	ar4
      00B6B7 C0 03            [24] 1249 	push	ar3
      00B6B9 91 B3            [12] 1250 	acall	_get_mode
      00B6BB A9 82            [24] 1251 	mov	r1, dpl
      00B6BD AA 83            [24] 1252 	mov	r2, dph
      00B6BF D0 03            [24] 1253 	pop	ar3
      00B6C1 D0 04            [24] 1254 	pop	ar4
      00B6C3 D0 05            [24] 1255 	pop	ar5
      00B6C5 D0 06            [24] 1256 	pop	ar6
                                   1257 ;	quantum/vialrgb.c:150: args[0] = vialrgb_id & 0xFF;
      00B6C7 89 00            [24] 1258 	mov	ar0,r1
      00B6C9 12 36 42         [24] 1259 	lcall	_ak820_outline_0122
      00B6CC E8               [12] 1260 	mov	a,r0
      00B6CD F0               [24] 1261 	movx	@dptr,a
                                   1262 ;	quantum/vialrgb.c:151: args[1] = vialrgb_id >> 8;
      00B6CE 12 B8 62         [24] 1263 	lcall	_ak820_outline_0035
      00B6D1 8A 01            [24] 1264 	mov	ar1,r2
      00B6D3 E9               [12] 1265 	mov	a,r1
      00B6D4 F0               [24] 1266 	movx	@dptr,a
                                   1267 ;	quantum/vialrgb.c:152: args[2] = rgb_matrix_get_speed();
      00B6D5 74 04            [12] 1268 	mov	a,#0x04
      00B6D7 12 91 68         [24] 1269 	lcall	_ak820_outline_0133
      00B6DA C0 06            [24] 1270 	push	ar6
      00B6DC C0 05            [24] 1271 	push	ar5
      00B6DE C0 02            [24] 1272 	push	ar2
      00B6E0 C0 01            [24] 1273 	push	ar1
      00B6E2 12 58 02         [24] 1274 	lcall	_rgb_matrix_get_speed
      00B6E5 A8 82            [24] 1275 	mov	r0, dpl
      00B6E7 D0 01            [24] 1276 	pop	ar1
      00B6E9 D0 02            [24] 1277 	pop	ar2
      00B6EB D0 05            [24] 1278 	pop	ar5
      00B6ED D0 06            [24] 1279 	pop	ar6
      00B6EF 12 83 C3         [24] 1280 	lcall	_ak820_outline_0064
                                   1281 ;	quantum/vialrgb.c:153: args[3] = rgb_matrix_get_hue();
      00B6F2 74 05            [12] 1282 	mov	a,#0x05
      00B6F4 12 91 68         [24] 1283 	lcall	_ak820_outline_0133
      00B6F7 C0 06            [24] 1284 	push	ar6
      00B6F9 C0 05            [24] 1285 	push	ar5
      00B6FB C0 02            [24] 1286 	push	ar2
      00B6FD C0 01            [24] 1287 	push	ar1
      00B6FF 12 57 ED         [24] 1288 	lcall	_rgb_matrix_get_hue
      00B702 A8 82            [24] 1289 	mov	r0, dpl
      00B704 D0 01            [24] 1290 	pop	ar1
      00B706 D0 02            [24] 1291 	pop	ar2
      00B708 D0 05            [24] 1292 	pop	ar5
      00B70A D0 06            [24] 1293 	pop	ar6
      00B70C 12 83 C3         [24] 1294 	lcall	_ak820_outline_0064
                                   1295 ;	quantum/vialrgb.c:154: args[4] = rgb_matrix_get_sat();
      00B70F 74 06            [12] 1296 	mov	a,#0x06
      00B711 12 91 68         [24] 1297 	lcall	_ak820_outline_0133
      00B714 C0 06            [24] 1298 	push	ar6
      00B716 C0 05            [24] 1299 	push	ar5
      00B718 C0 02            [24] 1300 	push	ar2
      00B71A C0 01            [24] 1301 	push	ar1
      00B71C 12 57 F4         [24] 1302 	lcall	_rgb_matrix_get_sat
      00B71F A8 82            [24] 1303 	mov	r0, dpl
      00B721 D0 01            [24] 1304 	pop	ar1
      00B723 D0 02            [24] 1305 	pop	ar2
      00B725 D0 05            [24] 1306 	pop	ar5
      00B727 D0 06            [24] 1307 	pop	ar6
      00B729 12 83 C3         [24] 1308 	lcall	_ak820_outline_0064
                                   1309 ;	quantum/vialrgb.c:155: args[5] = rgb_matrix_get_val();
      00B72C 74 07            [12] 1310 	mov	a,#0x07
      00B72E 12 91 68         [24] 1311 	lcall	_ak820_outline_0133
      00B731 C0 02            [24] 1312 	push	ar2
      00B733 C0 01            [24] 1313 	push	ar1
      00B735 12 57 FB         [24] 1314 	lcall	_rgb_matrix_get_val
      00B738 A8 82            [24] 1315 	mov	r0, dpl
      00B73A D0 01            [24] 1316 	pop	ar1
      00B73C D0 02            [24] 1317 	pop	ar2
      00B73E 12 83 C3         [24] 1318 	lcall	_ak820_outline_0064
                                   1319 ;	quantum/vialrgb.c:156: break;
      00B741 22               [24] 1320 	ret
                                   1321 ;	quantum/vialrgb.c:158: case vialrgb_get_supported: {
      00B742                       1322 00105$:
                                   1323 ;	quantum/vialrgb.c:159: get_supported(args, length - 2);
      00B742 EF               [12] 1324 	mov	a,r7
      00B743 24 FE            [12] 1325 	add	a,#0xfe
      00B745 90 0D 6B         [24] 1326 	mov	dptr,#_get_supported_PARM_2
      00B748 F0               [24] 1327 	movx	@dptr,a
      00B749 12 36 42         [24] 1328 	lcall	_ak820_outline_0122
                                   1329 ;	quantum/vialrgb.c:160: break;
      00B74C 02 B3 BC         [24] 1330 	ljmp	_get_supported
                                   1331 ;	quantum/vialrgb.c:163: case vialrgb_get_number_leds: {
      00B74F                       1332 00106$:
                                   1333 ;	quantum/vialrgb.c:164: args[0] = RGB_MATRIX_LED_COUNT & 0xFF;
      00B74F 12 36 42         [24] 1334 	lcall	_ak820_outline_0122
      00B752 74 52            [12] 1335 	mov	a,#0x52
      00B754 F0               [24] 1336 	movx	@dptr,a
                                   1337 ;	quantum/vialrgb.c:165: args[1] = RGB_MATRIX_LED_COUNT >> 8;
      00B755 12 B8 62         [24] 1338 	lcall	_ak820_outline_0035
      00B758 E4               [12] 1339 	clr	a
      00B759 F0               [24] 1340 	movx	@dptr,a
                                   1341 ;	quantum/vialrgb.c:166: break;
      00B75A 22               [24] 1342 	ret
                                   1343 ;	quantum/vialrgb.c:168: case vialrgb_get_led_info: {
      00B75B                       1344 00107$:
                                   1345 ;	quantum/vialrgb.c:169: uint16_t led = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00B75B 12 6F F2         [24] 1346 	lcall	_ak820_outline_0118
      00B75E FF               [12] 1347 	mov	r7,a
      00B75F 7A 00            [12] 1348 	mov	r2,#0x00
      00B761 74 03            [12] 1349 	mov	a,#0x03
      00B763 2D               [12] 1350 	add	a, r5
      00B764 F8               [12] 1351 	mov	r0,a
      00B765 E4               [12] 1352 	clr	a
      00B766 3E               [12] 1353 	addc	a, r6
      00B767 F9               [12] 1354 	mov	r1,a
      00B768 C0 03            [24] 1355 	push	ar3
      00B76A C0 04            [24] 1356 	push	ar4
      00B76C 12 3A B0         [24] 1357 	lcall	_ak820_outline_0152
      00B76F E0               [24] 1358 	movx	a,@dptr
      00B770 FB               [12] 1359 	mov	r3,a
      00B771 E4               [12] 1360 	clr	a
      00B772 4F               [12] 1361 	orl	a,r7
      00B773 F5 4E            [12] 1362 	mov	_vialrgb_get_value_sloc0_1_0,a
      00B775 EB               [12] 1363 	mov	a,r3
      00B776 4A               [12] 1364 	orl	a,r2
      00B777 F5 4F            [12] 1365 	mov	(_vialrgb_get_value_sloc0_1_0 + 1),a
                                   1366 ;	quantum/vialrgb.c:170: if (led >= RGB_MATRIX_LED_COUNT) return;
      00B779 AC 4E            [24] 1367 	mov	r4,_vialrgb_get_value_sloc0_1_0
      00B77B AF 4F            [24] 1368 	mov	r7,(_vialrgb_get_value_sloc0_1_0 + 1)
      00B77D C3               [12] 1369 	clr	c
      00B77E EC               [12] 1370 	mov	a,r4
      00B77F 94 52            [12] 1371 	subb	a,#0x52
      00B781 EF               [12] 1372 	mov	a,r7
      00B782 94 00            [12] 1373 	subb	a,#0x00
      00B784 D0 04            [24] 1374 	pop	ar4
      00B786 D0 03            [24] 1375 	pop	ar3
      00B788 40 01            [24] 1376 	jc	00109$
      00B78A 22               [24] 1377 	ret
      00B78B                       1378 00109$:
                                   1379 ;	quantum/vialrgb.c:172: args[0] = ak820_led_points[led].x;
      00B78B E5 4E            [12] 1380 	mov	a,_vialrgb_get_value_sloc0_1_0
      00B78D 25 4E            [12] 1381 	add	a,_vialrgb_get_value_sloc0_1_0
      00B78F FA               [12] 1382 	mov	r2,a
      00B790 E5 4F            [12] 1383 	mov	a,(_vialrgb_get_value_sloc0_1_0 + 1)
      00B792 33               [12] 1384 	rlc	a
      00B793 FF               [12] 1385 	mov	r7,a
      00B794 EA               [12] 1386 	mov	a,r2
      00B795 24 20            [12] 1387 	add	a, #_ak820_led_points
      00B797 F5 50            [12] 1388 	mov	_vialrgb_get_value_sloc1_1_0,a
      00B799 EF               [12] 1389 	mov	a,r7
      00B79A 34 BD            [12] 1390 	addc	a, #(_ak820_led_points >> 8)
      00B79C F5 51            [12] 1391 	mov	(_vialrgb_get_value_sloc1_1_0 + 1),a
      00B79E 85 50 82         [24] 1392 	mov	dpl,_vialrgb_get_value_sloc1_1_0
      00B7A1 85 51 83         [24] 1393 	mov	dph,(_vialrgb_get_value_sloc1_1_0 + 1)
      00B7A4 E4               [12] 1394 	clr	a
      00B7A5 93               [24] 1395 	movc	a,@a+dptr
      00B7A6 12 36 42         [24] 1396 	lcall	_ak820_outline_0122
      00B7A9 F0               [24] 1397 	movx	@dptr,a
                                   1398 ;	quantum/vialrgb.c:173: args[1] = ak820_led_points[led].y;
      00B7AA 85 50 82         [24] 1399 	mov	dpl,_vialrgb_get_value_sloc1_1_0
      00B7AD 85 51 83         [24] 1400 	mov	dph,(_vialrgb_get_value_sloc1_1_0 + 1)
      00B7B0 A3               [24] 1401 	inc	dptr
      00B7B1 E4               [12] 1402 	clr	a
      00B7B2 93               [24] 1403 	movc	a,@a+dptr
      00B7B3 12 3A B0         [24] 1404 	lcall	_ak820_outline_0152
      00B7B6 F0               [24] 1405 	movx	@dptr,a
                                   1406 ;	quantum/vialrgb.c:174: args[2] = LED_FLAG_KEYLIGHT;
      00B7B7 12 B8 62         [24] 1407 	lcall	_ak820_outline_0035
      00B7BA A3               [24] 1408 	inc	dptr
      00B7BB 74 04            [12] 1409 	mov	a,#0x04
      00B7BD F0               [24] 1410 	movx	@dptr,a
                                   1411 ;	quantum/vialrgb.c:183: get_matrix_pos_for_led(led, &args[3]);
      00B7BE 90 0D 74         [24] 1412 	mov	dptr,#_get_matrix_pos_for_led_PARM_2
      00B7C1 04               [12] 1413 	inc	a
      00B7C2 2D               [12] 1414 	add	a, r5
      00B7C3 F0               [24] 1415 	movx	@dptr,a
      00B7C4 E4               [12] 1416 	clr	a
      00B7C5 3E               [12] 1417 	addc	a, r6
      00B7C6 A3               [24] 1418 	inc	dptr
      00B7C7 F0               [24] 1419 	movx	@dptr,a
      00B7C8 85 4E 82         [24] 1420 	mov	dpl, _vialrgb_get_value_sloc0_1_0
      00B7CB 85 4F 83         [24] 1421 	mov	dph, (_vialrgb_get_value_sloc0_1_0 + 1)
                                   1422 ;	quantum/vialrgb.c:187: }
                                   1423 ;	quantum/vialrgb.c:188: }
      00B7CE 02 B4 F4         [24] 1424 	ljmp	_get_matrix_pos_for_led
                                   1425 ;------------------------------------------------------------
                                   1426 ;Allocation info for local variables in function 'vialrgb_set_value'
                                   1427 ;------------------------------------------------------------
                                   1428 ;sloc0         Allocated with name '_vialrgb_set_value_sloc0_1_0'
                                   1429 ;length        Allocated with name '_vialrgb_set_value_PARM_2'
                                   1430 ;data          Allocated with name '_vialrgb_set_value_data_10000_302'
                                   1431 ;args          Allocated with name '_vialrgb_set_value_args_10001_305'
                                   1432 ;cmd           Allocated with name '_vialrgb_set_value_cmd_10001_305'
                                   1433 ;vialrgb_id    Allocated with name '_vialrgb_set_value_vialrgb_id_40001_308'
                                   1434 ;------------------------------------------------------------
                                   1435 ;	quantum/vialrgb.c:190: void vialrgb_set_value(uint8_t *data, uint8_t length) {
                                   1436 ;	-----------------------------------------
                                   1437 ;	 function vialrgb_set_value
                                   1438 ;	-----------------------------------------
      00B7D1                       1439 _vialrgb_set_value:
      00B7D1 12 45 80         [24] 1440 	lcall	_ak820_outline_0037
      00B7D4 90 0D 83         [24] 1441 	mov	dptr,#_vialrgb_set_value_data_10000_302
      00B7D7 12 3A 20         [24] 1442 	lcall	_ak820_outline_0016
                                   1443 ;	quantum/vialrgb.c:191: if (length != VIAL_RAW_EPSIZE) return;
      00B7DA 90 0D 82         [24] 1444 	mov	dptr,#_vialrgb_set_value_PARM_2
      00B7DD E0               [24] 1445 	movx	a,@dptr
      00B7DE FF               [12] 1446 	mov	r7,a
      00B7DF BF 20 02         [24] 1447 	cjne	r7,#0x20,00129$
      00B7E2 80 01            [24] 1448 	sjmp	00102$
      00B7E4                       1449 00129$:
      00B7E4 22               [24] 1450 	ret
      00B7E5                       1451 00102$:
                                   1452 ;	quantum/vialrgb.c:194: uint8_t VIALRGB_BUFFER *args = (uint8_t VIALRGB_BUFFER *)data + 2;
      00B7E5 90 0D 83         [24] 1453 	mov	dptr,#_vialrgb_set_value_data_10000_302
      00B7E8 12 B8 6A         [24] 1454 	lcall	_ak820_outline_0043
                                   1455 ;	quantum/vialrgb.c:195: uint8_t cmd = args[-1];
                                   1456 ;	quantum/vialrgb.c:196: switch (cmd) {
      00B7EB BA 41 02         [24] 1457 	cjne	r2,#0x41,00130$
      00B7EE 80 06            [24] 1458 	sjmp	00103$
      00B7F0                       1459 00130$:
      00B7F0 BA 42 02         [24] 1460 	cjne	r2,#0x42,00131$
      00B7F3 80 5D            [24] 1461 	sjmp	00104$
      00B7F5                       1462 00131$:
      00B7F5 22               [24] 1463 	ret
                                   1464 ;	quantum/vialrgb.c:197: case vialrgb_set_mode: {
      00B7F6                       1465 00103$:
                                   1466 ;	quantum/vialrgb.c:198: uint16_t vialrgb_id = args[0] | (args[1] << 8);
      00B7F6 12 6F F2         [24] 1467 	lcall	_ak820_outline_0118
      00B7F9 FA               [12] 1468 	mov	r2,a
      00B7FA 12 B8 62         [24] 1469 	lcall	_ak820_outline_0035
      00B7FD E0               [24] 1470 	movx	a,@dptr
      00B7FE F8               [12] 1471 	mov	r0,a
      00B7FF 79 00            [12] 1472 	mov	r1,#0x00
      00B801 88 53            [24] 1473 	mov	(_vialrgb_set_value_sloc0_1_0 + 1),r0
      00B803 89 52            [24] 1474 	mov	_vialrgb_set_value_sloc0_1_0,r1
      00B805 8A 01            [24] 1475 	mov	ar1,r2
      00B807 7A 00            [12] 1476 	mov	r2,#0x00
      00B809 E5 53            [12] 1477 	mov	a,(_vialrgb_set_value_sloc0_1_0 + 1)
      00B80B 42 02            [12] 1478 	orl	ar2,a
                                   1479 ;	quantum/vialrgb.c:199: set_mode(vialrgb_id);
      00B80D 12 46 00         [24] 1480 	lcall	_ak820_outline_0179
      00B810 C0 06            [24] 1481 	push	ar6
      00B812 C0 05            [24] 1482 	push	ar5
      00B814 12 B4 C7         [24] 1483 	lcall	_set_mode
      00B817 D0 05            [24] 1484 	pop	ar5
      00B819 D0 06            [24] 1485 	pop	ar6
                                   1486 ;	quantum/vialrgb.c:200: rgb_matrix_set_speed_noeeprom(args[2]);
      00B81B 12 B8 62         [24] 1487 	lcall	_ak820_outline_0035
      00B81E A3               [24] 1488 	inc	dptr
      00B81F E0               [24] 1489 	movx	a,@dptr
      00B820 F5 82            [12] 1490 	mov	dpl,a
      00B822 C0 06            [24] 1491 	push	ar6
      00B824 C0 05            [24] 1492 	push	ar5
      00B826 12 58 CE         [24] 1493 	lcall	_rgb_matrix_set_speed_noeeprom
      00B829 D0 05            [24] 1494 	pop	ar5
      00B82B D0 06            [24] 1495 	pop	ar6
                                   1496 ;	quantum/vialrgb.c:201: rgb_matrix_sethsv_noeeprom(args[3], args[4], args[5]);
      00B82D 12 B8 62         [24] 1497 	lcall	_ak820_outline_0035
      00B830 A3               [24] 1498 	inc	dptr
      00B831 A3               [24] 1499 	inc	dptr
      00B832 E0               [24] 1500 	movx	a,@dptr
      00B833 F9               [12] 1501 	mov	r1,a
      00B834 7A 00            [12] 1502 	mov	r2,#0x00
      00B836 74 06            [12] 1503 	mov	a,#0x06
      00B838 12 B8 B4         [24] 1504 	lcall	_ak820_outline_0169
      00B83B F8               [12] 1505 	mov	r0,a
      00B83C 74 07            [12] 1506 	mov	a,#0x07
      00B83E 12 B8 B4         [24] 1507 	lcall	_ak820_outline_0169
      00B841 FE               [12] 1508 	mov	r6,a
      00B842 90 07 44         [24] 1509 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_2
      00B845 E8               [12] 1510 	mov	a,r0
      00B846 F0               [24] 1511 	movx	@dptr,a
      00B847 90 07 45         [24] 1512 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_3
      00B84A EE               [12] 1513 	mov	a,r6
      00B84B F0               [24] 1514 	movx	@dptr,a
      00B84C 12 46 00         [24] 1515 	lcall	_ak820_outline_0179
                                   1516 ;	quantum/vialrgb.c:202: break;
                                   1517 ;	quantum/vialrgb.c:205: case vialrgb_direct_fastset: {
      00B84F 02 58 9F         [24] 1518 	ljmp	_rgb_matrix_sethsv_noeeprom
      00B852                       1519 00104$:
                                   1520 ;	quantum/vialrgb.c:206: fast_set_leds(args, length - 2);
      00B852 EF               [12] 1521 	mov	a,r7
      00B853 24 FE            [12] 1522 	add	a,#0xfe
      00B855 90 0D 78         [24] 1523 	mov	dptr,#_fast_set_leds_PARM_2
      00B858 F0               [24] 1524 	movx	@dptr,a
      00B859 12 36 42         [24] 1525 	lcall	_ak820_outline_0122
                                   1526 ;	quantum/vialrgb.c:210: }
                                   1527 ;	quantum/vialrgb.c:211: }
      00B85C 02 B5 27         [24] 1528 	ljmp	_fast_set_leds
                                   1529 ;------------------------------------------------------------
                                   1530 ;Allocation info for local variables in function 'vialrgb_save'
                                   1531 ;------------------------------------------------------------
                                   1532 ;length        Allocated with name '_vialrgb_save_PARM_2'
                                   1533 ;data          Allocated with name '_vialrgb_save_data_10000_310'
                                   1534 ;------------------------------------------------------------
                                   1535 ;	quantum/vialrgb.c:213: void vialrgb_save(uint8_t *data, uint8_t length) {
                                   1536 ;	-----------------------------------------
                                   1537 ;	 function vialrgb_save
                                   1538 ;	-----------------------------------------
      00B85F                       1539 _vialrgb_save:
                                   1540 ;	quantum/vialrgb.c:217: eeconfig_update_rgb_matrix();
                                   1541 ;	quantum/vialrgb.c:218: }
      00B85F 02 53 39         [24] 1542 	ljmp	_eeconfig_update_rgb_matrix
                                   1543 	.area CSEG    (CODE)
                                   1544 	.area CONST   (CODE)
                                   1545 	.area CONST   (CODE)
      00C05F                       1546 _supported_modes:
      00C05F 00                    1547 	.db #0x00	; 0
      00C060 00                    1548 	.db #0x00	; 0
      00C061 01                    1549 	.db #0x01	; 1
      00C062 05                    1550 	.db #0x05	; 5
      00C063 02                    1551 	.db #0x02	; 2
      00C064 01                    1552 	.db #0x01	; 1
      00C065 06                    1553 	.db #0x06	; 6
      00C066 02                    1554 	.db #0x02	; 2
      00C067 0D                    1555 	.db #0x0d	; 13
      00C068 03                    1556 	.db #0x03	; 3
      00C069 0E                    1557 	.db #0x0e	; 14
      00C06A 04                    1558 	.db #0x04	; 4
      00C06B 1F                    1559 	.db #0x1f	; 31
      00C06C 06                    1560 	.db #0x06	; 6
                                   1561 	.area CSEG    (CODE)
                                   1562 	.area XINIT   (CODE)
                                   1563 	.area CABS    (ABS,CODE)
                                   1564 
                                   1565 ; Experimental exact instruction outlining.
                                   1566 	.globl _ak820_outline_0004
                                   1567 	.globl _ak820_outline_0016
                                   1568 	.globl _ak820_outline_0031
                                   1569 	.globl _ak820_outline_0035
                                   1570 	.globl _ak820_outline_0036
                                   1571 	.globl _ak820_outline_0037
                                   1572 	.globl _ak820_outline_0043
                                   1573 	.globl _ak820_outline_0045
                                   1574 	.globl _ak820_outline_0051
                                   1575 	.globl _ak820_outline_0064
                                   1576 	.globl _ak820_outline_0075
                                   1577 	.globl _ak820_outline_0077
                                   1578 	.globl _ak820_outline_0082
                                   1579 	.globl _ak820_outline_0093
                                   1580 	.globl _ak820_outline_0102
                                   1581 	.globl _ak820_outline_0103
                                   1582 	.globl _ak820_outline_0104
                                   1583 	.globl _ak820_outline_0105
                                   1584 	.globl _ak820_outline_0108
                                   1585 	.globl _ak820_outline_0116
                                   1586 	.globl _ak820_outline_0118
                                   1587 	.globl _ak820_outline_0119
                                   1588 	.globl _ak820_outline_0121
                                   1589 	.globl _ak820_outline_0122
                                   1590 	.globl _ak820_outline_0132
                                   1591 	.globl _ak820_outline_0133
                                   1592 	.globl _ak820_outline_0139
                                   1593 	.globl _ak820_outline_0141
                                   1594 	.globl _ak820_outline_0152
                                   1595 	.globl _ak820_outline_0157
                                   1596 	.globl _ak820_outline_0169
                                   1597 	.globl _ak820_outline_0179
                                   1598 	.globl _ak820_outline_0183
                                   1599 
                                   1600 	.area CSEG (CODE)
                                   1601 ; function ak820_outline_0035
      00B862                       1602 _ak820_outline_0035:
      00B862 8D 82            [24] 1603 	mov	dpl,r5
      00B864 8E 83            [24] 1604 	mov	dph,r6
      00B866 A3               [24] 1605 	inc	dptr
      00B867 A3               [24] 1606 	inc	dptr
      00B868 A3               [24] 1607 	inc	dptr
      00B869 22               [24] 1608 	ret
                                   1609 
                                   1610 	.area CSEG (CODE)
                                   1611 ; function ak820_outline_0043
      00B86A                       1612 _ak820_outline_0043:
      00B86A E0               [24] 1613 	movx	a,@dptr
      00B86B FD               [12] 1614 	mov	r5,a
      00B86C A3               [24] 1615 	inc	dptr
      00B86D E0               [24] 1616 	movx	a,@dptr
      00B86E FE               [12] 1617 	mov	r6,a
      00B86F 74 02            [12] 1618 	mov	a,#0x02
      00B871 2D               [12] 1619 	add	a,r5
      00B872 FB               [12] 1620 	mov	r3,a
      00B873 E4               [12] 1621 	clr	a
      00B874 3E               [12] 1622 	addc	a,r6
      00B875 FC               [12] 1623 	mov	r4,a
      00B876 8D 82            [24] 1624 	mov	dpl,r5
      00B878 8E 83            [24] 1625 	mov	dph,r6
      00B87A A3               [24] 1626 	inc	dptr
      00B87B E0               [24] 1627 	movx	a,@dptr
      00B87C FA               [12] 1628 	mov	r2,a
      00B87D 22               [24] 1629 	ret
                                   1630 
                                   1631 	.area CSEG (CODE)
                                   1632 ; function ak820_outline_0045
      00B87E                       1633 _ak820_outline_0045:
      00B87E ED               [12] 1634 	mov	a,r5
      00B87F 75 F0 02         [24] 1635 	mov	b,#0x02
      00B882 A4               [48] 1636 	mul	ab
      00B883 24 5F            [12] 1637 	add	a,#_supported_modes
      00B885 FB               [12] 1638 	mov	r3,a
      00B886 74 C0            [12] 1639 	mov	a,#(_supported_modes>>8)
      00B888 35 F0            [12] 1640 	addc	a,b
      00B88A FC               [12] 1641 	mov	r4,a
      00B88B 8B 82            [24] 1642 	mov	dpl,r3
      00B88D 8C 83            [24] 1643 	mov	dph,r4
      00B88F 22               [24] 1644 	ret
                                   1645 
                                   1646 	.area CSEG (CODE)
                                   1647 ; function ak820_outline_0082
      00B890                       1648 _ak820_outline_0082:
      00B890 90 0D 79         [24] 1649 	mov	dptr,#_fast_set_leds_args_10000_282
      00B893 E0               [24] 1650 	movx	a,@dptr
      00B894 F9               [12] 1651 	mov	r1,a
      00B895 A3               [24] 1652 	inc	dptr
      00B896 E0               [24] 1653 	movx	a,@dptr
      00B897 FF               [12] 1654 	mov	r7,a
      00B898 89 82            [24] 1655 	mov	dpl,r1
      00B89A 8F 83            [24] 1656 	mov	dph,r7
      00B89C E0               [24] 1657 	movx	a,@dptr
      00B89D 22               [24] 1658 	ret
                                   1659 
                                   1660 	.area CSEG (CODE)
                                   1661 ; function ak820_outline_0102
      00B89E                       1662 _ak820_outline_0102:
      00B89E 90 0D 79         [24] 1663 	mov	dptr,#_fast_set_leds_args_10000_282
      00B8A1 74 01            [12] 1664 	mov	a,#0x01
      00B8A3 29               [12] 1665 	add	a,r1
      00B8A4 F0               [24] 1666 	movx	@dptr,a
      00B8A5 E4               [12] 1667 	clr	a
      00B8A6 3F               [12] 1668 	addc	a,r7
      00B8A7 A3               [24] 1669 	inc	dptr
      00B8A8 F0               [24] 1670 	movx	@dptr,a
      00B8A9 22               [24] 1671 	ret
                                   1672 
                                   1673 	.area CSEG (CODE)
                                   1674 ; function ak820_outline_0141
      00B8AA                       1675 _ak820_outline_0141:
      00B8AA E4               [12] 1676 	clr	a
      00B8AB 93               [24] 1677 	movc	a,@a+dptr
      00B8AC FC               [12] 1678 	mov	r4,a
      00B8AD 7B 00            [12] 1679 	mov	r3,#0x00
      00B8AF 8C 82            [24] 1680 	mov	dpl,r4
      00B8B1 8B 83            [24] 1681 	mov	dph,r3
      00B8B3 22               [24] 1682 	ret
                                   1683 
                                   1684 	.area CSEG (CODE)
                                   1685 ; function ak820_outline_0169
      00B8B4                       1686 _ak820_outline_0169:
      00B8B4 2D               [12] 1687 	add	a,r5
      00B8B5 F5 82            [12] 1688 	mov	dpl,a
      00B8B7 E4               [12] 1689 	clr	a
      00B8B8 3E               [12] 1690 	addc	a,r6
      00B8B9 F5 83            [12] 1691 	mov	dph,a
      00B8BB E0               [24] 1692 	movx	a,@dptr
      00B8BC 22               [24] 1693 	ret
