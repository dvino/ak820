                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_combo_cancel
                                     12 	.globl _ak820_combo_tick
                                     13 	.globl _ak820_autoshift_cancel
                                     14 	.globl _ak820_autoshift_process
                                     15 	.globl _ak820_autoshift_before
                                     16 	.globl _ak820_oneshot_cancel
                                     17 	.globl _ak820_oneshot_post
                                     18 	.globl _ak820_oneshot_process
                                     19 	.globl _ak820_tapping_source
                                     20 	.globl _ak820_tapping_cancel
                                     21 	.globl _ak820_tapping_process
                                     22 	.globl _ak820_tapping_before
                                     23 	.globl _pre_process_record_quantum
                                     24 	.globl _get_record_keycode
                                     25 	.globl _repeat_key_cancel
                                     26 	.globl _clear_owned_usages
                                     27 	.globl _owned_usage_key
                                     28 	.globl _clear_owned_keys
                                     29 	.globl _del_owned_key
                                     30 	.globl _add_owned_key
                                     31 	.globl _clear_owned_mods
                                     32 	.globl _del_owned_weak_mods
                                     33 	.globl _add_owned_weak_mods
                                     34 	.globl _del_owned_mods
                                     35 	.globl _add_owned_mods
                                     36 	.globl _clear_weak_mods
                                     37 	.globl _clear_mods
                                     38 	.globl _send_keyboard_report
                                     39 	.globl _layer_hold_clear
                                     40 	.globl _layer_hold_off
                                     41 	.globl _layer_hold_on
                                     42 	.globl _ak820_resolve_key
                                     43 	.globl _layer_xor
                                     44 	.globl _layer_and
                                     45 	.globl _layer_or
                                     46 	.globl _layer_off
                                     47 	.globl _layer_on
                                     48 	.globl _layer_move
                                     49 	.globl _layer_clear
                                     50 	.globl _layer_state_set
                                     51 	.globl _default_layer_xor
                                     52 	.globl _default_layer_and
                                     53 	.globl _default_layer_or
                                     54 	.globl _default_layer_set
                                     55 	.globl _process_record_quantum
                                     56 	.globl _action_for_keycode
                                     57 	.globl _mDelaymS
                                     58 	.globl _host_consumer_send
                                     59 	.globl _host_system_send
                                     60 	.globl _host_keyboard_leds
                                     61 	.globl _led_set
                                     62 	.globl _clear_keys_from_report
                                     63 	.globl ___memcpy
                                     64 	.globl _ADC_START
                                     65 	.globl _S0_R_FIFO
                                     66 	.globl _S0_T_FIFO
                                     67 	.globl _S0_FREE
                                     68 	.globl _S0_IF_BYTE
                                     69 	.globl _S0_IF_FIRST
                                     70 	.globl _S0_IF_OV
                                     71 	.globl _S0_FST_ACT
                                     72 	.globl _CP_RL2
                                     73 	.globl _C_T2
                                     74 	.globl _TR2
                                     75 	.globl _EXEN2
                                     76 	.globl _TCLK
                                     77 	.globl _RCLK
                                     78 	.globl _EXF2
                                     79 	.globl _CAP1F
                                     80 	.globl _TF2
                                     81 	.globl _RI
                                     82 	.globl _TI
                                     83 	.globl _RB8
                                     84 	.globl _TB8
                                     85 	.globl _REN
                                     86 	.globl _SM2
                                     87 	.globl _SM1
                                     88 	.globl _SM0
                                     89 	.globl _IT0
                                     90 	.globl _IE0
                                     91 	.globl _IT1
                                     92 	.globl _IE1
                                     93 	.globl _TR0
                                     94 	.globl _TF0
                                     95 	.globl _TR1
                                     96 	.globl _TF1
                                     97 	.globl _P4_0
                                     98 	.globl _P4_1
                                     99 	.globl _P4_2
                                    100 	.globl _P4_3
                                    101 	.globl _P4_4
                                    102 	.globl _P4_5
                                    103 	.globl _P4_6
                                    104 	.globl _RXD
                                    105 	.globl _TXD
                                    106 	.globl _INT0
                                    107 	.globl _INT1
                                    108 	.globl _T0
                                    109 	.globl _T1
                                    110 	.globl _MOSI1
                                    111 	.globl _MISO1
                                    112 	.globl _SCK1
                                    113 	.globl _P3_0
                                    114 	.globl _P3_1
                                    115 	.globl _P3_2
                                    116 	.globl _P3_3
                                    117 	.globl _P3_4
                                    118 	.globl _P3_5
                                    119 	.globl _P3_6
                                    120 	.globl _P3_7
                                    121 	.globl _CAP1_
                                    122 	.globl _T2_
                                    123 	.globl _CAP2_
                                    124 	.globl _T2EX_
                                    125 	.globl _RXD1
                                    126 	.globl _TXD1
                                    127 	.globl _P2_0
                                    128 	.globl _P2_1
                                    129 	.globl _P2_2
                                    130 	.globl _P2_3
                                    131 	.globl _P2_4
                                    132 	.globl _P2_5
                                    133 	.globl _P2_6
                                    134 	.globl _P2_7
                                    135 	.globl _AIN0
                                    136 	.globl _AIN1
                                    137 	.globl _AIN2
                                    138 	.globl _AIN3
                                    139 	.globl _AIN4
                                    140 	.globl _AIN5
                                    141 	.globl _AIN6
                                    142 	.globl _AIN7
                                    143 	.globl _CAP1
                                    144 	.globl _T2
                                    145 	.globl _CAP2
                                    146 	.globl _T2EX
                                    147 	.globl _INT0_
                                    148 	.globl _SCS
                                    149 	.globl _MOSI
                                    150 	.globl _MISO
                                    151 	.globl _SCK
                                    152 	.globl _RXD1_
                                    153 	.globl _TXD1_
                                    154 	.globl _P1_0
                                    155 	.globl _P1_1
                                    156 	.globl _P1_2
                                    157 	.globl _P1_3
                                    158 	.globl _P1_4
                                    159 	.globl _P1_5
                                    160 	.globl _P1_6
                                    161 	.globl _P1_7
                                    162 	.globl _AIN8
                                    163 	.globl _AIN9
                                    164 	.globl _AIN10
                                    165 	.globl _AIN11
                                    166 	.globl _AIN12
                                    167 	.globl _AIN13
                                    168 	.globl _RXD_
                                    169 	.globl _TXD_
                                    170 	.globl _SCL0
                                    171 	.globl _SDA0
                                    172 	.globl _P0_0
                                    173 	.globl _P0_1
                                    174 	.globl _P0_2
                                    175 	.globl _P0_3
                                    176 	.globl _P0_4
                                    177 	.globl _P0_5
                                    178 	.globl _P0_6
                                    179 	.globl _P0_7
                                    180 	.globl _IE_SPI0
                                    181 	.globl _IE_USB
                                    182 	.globl _IE_ADC
                                    183 	.globl _IE_UART1
                                    184 	.globl _IE_PWM_I2C
                                    185 	.globl _IE_GPIO
                                    186 	.globl _IE_WDOG
                                    187 	.globl _PX0
                                    188 	.globl _PT0
                                    189 	.globl _PX1
                                    190 	.globl _PT1
                                    191 	.globl _PS
                                    192 	.globl _PT2
                                    193 	.globl _PL_FLAG
                                    194 	.globl _PH_FLAG
                                    195 	.globl _EX0
                                    196 	.globl _ET0
                                    197 	.globl _EX1
                                    198 	.globl _ET1
                                    199 	.globl _ES
                                    200 	.globl _ET2
                                    201 	.globl _E_DIS
                                    202 	.globl _EA
                                    203 	.globl _P
                                    204 	.globl _F1
                                    205 	.globl _OV
                                    206 	.globl _RS0
                                    207 	.globl _RS1
                                    208 	.globl _F0
                                    209 	.globl _AC
                                    210 	.globl _CY
                                    211 	.globl _I2CS_INT_ST
                                    212 	.globl _I2CX_INT
                                    213 	.globl _LED_STATUS
                                    214 	.globl _LED_DMA_H
                                    215 	.globl _LED_DMA_L
                                    216 	.globl _LED_DMA
                                    217 	.globl _LED_PWM_OE
                                    218 	.globl _LED_COMMON
                                    219 	.globl _ADC_CHAN
                                    220 	.globl _ADC_DAT_H
                                    221 	.globl _ADC_DAT_L
                                    222 	.globl _ADC_DAT
                                    223 	.globl _ADC_CTRL
                                    224 	.globl _SPI1_CK_SE
                                    225 	.globl _SPI1_CTRL
                                    226 	.globl _SPI1_DATA
                                    227 	.globl _SPI1_STAT
                                    228 	.globl _SIF1
                                    229 	.globl _SBAUD1
                                    230 	.globl _SBUF1
                                    231 	.globl _SCON1
                                    232 	.globl _SPI0_SETUP
                                    233 	.globl _SPI0_CK_SE
                                    234 	.globl _SPI0_CTRL
                                    235 	.globl _SPI0_DATA
                                    236 	.globl _SPI0_STAT
                                    237 	.globl _T2CAP1H
                                    238 	.globl _T2CAP1L
                                    239 	.globl _T2CAP1
                                    240 	.globl _TH2
                                    241 	.globl _TL2
                                    242 	.globl _T2COUNT
                                    243 	.globl _RCAP2H
                                    244 	.globl _RCAP2L
                                    245 	.globl _RCAP2
                                    246 	.globl _T2MOD
                                    247 	.globl _T2CON
                                    248 	.globl _SBUF
                                    249 	.globl _SCON
                                    250 	.globl _TH1
                                    251 	.globl _TH0
                                    252 	.globl _TL1
                                    253 	.globl _TL0
                                    254 	.globl _TMOD
                                    255 	.globl _TCON
                                    256 	.globl _XBUS_AUX
                                    257 	.globl _P7
                                    258 	.globl _P6_DIR
                                    259 	.globl _P6_OUT_PU
                                    260 	.globl _P6_IN
                                    261 	.globl _P5_DIR
                                    262 	.globl _P5_OUT_PU
                                    263 	.globl _P5_IN
                                    264 	.globl _P4_LED_KEY
                                    265 	.globl _P4_DIR_PU
                                    266 	.globl _P4_MOD_OC
                                    267 	.globl _P4
                                    268 	.globl _P3_DIR_PU
                                    269 	.globl _P3_MOD_OC
                                    270 	.globl _P3
                                    271 	.globl _P2_DIR_PU
                                    272 	.globl _P2_MOD_OC
                                    273 	.globl _P2
                                    274 	.globl _P1_DIR_PU
                                    275 	.globl _P1_MOD_OC
                                    276 	.globl _P1
                                    277 	.globl _P0_DIR_PU
                                    278 	.globl _P0_MOD_OC
                                    279 	.globl _P0
                                    280 	.globl _ROM_CTRL
                                    281 	.globl _ROM_DATA_HH
                                    282 	.globl _ROM_DATA_HL
                                    283 	.globl _ROM_DATA_HI
                                    284 	.globl _ROM_ADDR_H
                                    285 	.globl _ROM_ADDR_L
                                    286 	.globl _ROM_ADDR
                                    287 	.globl _GPIO_IE
                                    288 	.globl _IP_EX
                                    289 	.globl _IE_EX
                                    290 	.globl _IP
                                    291 	.globl _IE
                                    292 	.globl _WDOG_COUNT
                                    293 	.globl _RESET_KEEP
                                    294 	.globl _WAKE_CTRL
                                    295 	.globl _CLOCK_CFG
                                    296 	.globl _POWER_CFG
                                    297 	.globl _PCON
                                    298 	.globl _GLOBAL_CFG
                                    299 	.globl _SAFE_MOD
                                    300 	.globl _DPH
                                    301 	.globl _DPL
                                    302 	.globl _SP
                                    303 	.globl _A_INV
                                    304 	.globl _B
                                    305 	.globl _ACC
                                    306 	.globl _PSW
                                    307 	.globl _disable_action_cache
                                    308 	.globl _tap_code_delay_PARM_2
                                    309 	.globl _process_action_PARM_2
                                    310 	.globl _action_exec_PARM_1
                                    311 	.globl _tp_buttons
                                    312 	.globl _action_exec
                                    313 	.globl _ak820_action_exec
                                    314 	.globl _process_record
                                    315 	.globl _process_record_handler
                                    316 	.globl _process_action
                                    317 	.globl _register_code
                                    318 	.globl _unregister_code
                                    319 	.globl _tap_code_delay
                                    320 	.globl _tap_code
                                    321 	.globl _register_mods
                                    322 	.globl _unregister_mods
                                    323 	.globl _register_weak_mods
                                    324 	.globl _unregister_weak_mods
                                    325 	.globl _clear_keyboard
                                    326 	.globl _clear_keyboard_but_mods
                                    327 	.globl _clear_keyboard_but_mods_and_keys
                                    328 ;--------------------------------------------------------
                                    329 ; special function registers
                                    330 ;--------------------------------------------------------
                                    331 	.area RSEG    (ABS,DATA)
      000000                        332 	.org 0x0000
                           0000D0   333 _PSW	=	0x00d0
                           0000E0   334 _ACC	=	0x00e0
                           0000F0   335 _B	=	0x00f0
                           0000FD   336 _A_INV	=	0x00fd
                           000081   337 _SP	=	0x0081
                           000082   338 _DPL	=	0x0082
                           000083   339 _DPH	=	0x0083
                           0000A1   340 _SAFE_MOD	=	0x00a1
                           0000B1   341 _GLOBAL_CFG	=	0x00b1
                           000087   342 _PCON	=	0x0087
                           0000BA   343 _POWER_CFG	=	0x00ba
                           0000B9   344 _CLOCK_CFG	=	0x00b9
                           0000A9   345 _WAKE_CTRL	=	0x00a9
                           0000FE   346 _RESET_KEEP	=	0x00fe
                           0000FF   347 _WDOG_COUNT	=	0x00ff
                           0000A8   348 _IE	=	0x00a8
                           0000B8   349 _IP	=	0x00b8
                           0000E8   350 _IE_EX	=	0x00e8
                           0000E9   351 _IP_EX	=	0x00e9
                           0000B2   352 _GPIO_IE	=	0x00b2
                           008584   353 _ROM_ADDR	=	0x8584
                           000084   354 _ROM_ADDR_L	=	0x0084
                           000085   355 _ROM_ADDR_H	=	0x0085
                           008F8E   356 _ROM_DATA_HI	=	0x8f8e
                           00008E   357 _ROM_DATA_HL	=	0x008e
                           00008F   358 _ROM_DATA_HH	=	0x008f
                           000086   359 _ROM_CTRL	=	0x0086
                           000080   360 _P0	=	0x0080
                           0000C4   361 _P0_MOD_OC	=	0x00c4
                           0000C5   362 _P0_DIR_PU	=	0x00c5
                           000090   363 _P1	=	0x0090
                           000092   364 _P1_MOD_OC	=	0x0092
                           000093   365 _P1_DIR_PU	=	0x0093
                           0000A0   366 _P2	=	0x00a0
                           000094   367 _P2_MOD_OC	=	0x0094
                           000095   368 _P2_DIR_PU	=	0x0095
                           0000B0   369 _P3	=	0x00b0
                           000096   370 _P3_MOD_OC	=	0x0096
                           000097   371 _P3_DIR_PU	=	0x0097
                           0000C0   372 _P4	=	0x00c0
                           0000C2   373 _P4_MOD_OC	=	0x00c2
                           0000C3   374 _P4_DIR_PU	=	0x00c3
                           0000C1   375 _P4_LED_KEY	=	0x00c1
                           0000AA   376 _P5_IN	=	0x00aa
                           0000AB   377 _P5_OUT_PU	=	0x00ab
                           0000AC   378 _P5_DIR	=	0x00ac
                           0000AD   379 _P6_IN	=	0x00ad
                           0000AE   380 _P6_OUT_PU	=	0x00ae
                           0000AF   381 _P6_DIR	=	0x00af
                           0000F1   382 _P7	=	0x00f1
                           0000A2   383 _XBUS_AUX	=	0x00a2
                           000088   384 _TCON	=	0x0088
                           000089   385 _TMOD	=	0x0089
                           00008A   386 _TL0	=	0x008a
                           00008B   387 _TL1	=	0x008b
                           00008C   388 _TH0	=	0x008c
                           00008D   389 _TH1	=	0x008d
                           000098   390 _SCON	=	0x0098
                           000099   391 _SBUF	=	0x0099
                           0000C8   392 _T2CON	=	0x00c8
                           0000C9   393 _T2MOD	=	0x00c9
                           00CBCA   394 _RCAP2	=	0xcbca
                           0000CA   395 _RCAP2L	=	0x00ca
                           0000CB   396 _RCAP2H	=	0x00cb
                           00CDCC   397 _T2COUNT	=	0xcdcc
                           0000CC   398 _TL2	=	0x00cc
                           0000CD   399 _TH2	=	0x00cd
                           00CFCE   400 _T2CAP1	=	0xcfce
                           0000CE   401 _T2CAP1L	=	0x00ce
                           0000CF   402 _T2CAP1H	=	0x00cf
                           0000F8   403 _SPI0_STAT	=	0x00f8
                           0000F9   404 _SPI0_DATA	=	0x00f9
                           0000FA   405 _SPI0_CTRL	=	0x00fa
                           0000FB   406 _SPI0_CK_SE	=	0x00fb
                           0000FC   407 _SPI0_SETUP	=	0x00fc
                           0000BC   408 _SCON1	=	0x00bc
                           0000BD   409 _SBUF1	=	0x00bd
                           0000BE   410 _SBAUD1	=	0x00be
                           0000BF   411 _SIF1	=	0x00bf
                           0000B4   412 _SPI1_STAT	=	0x00b4
                           0000B5   413 _SPI1_DATA	=	0x00b5
                           0000B6   414 _SPI1_CTRL	=	0x00b6
                           0000B7   415 _SPI1_CK_SE	=	0x00b7
                           0000F3   416 _ADC_CTRL	=	0x00f3
                           00F5F4   417 _ADC_DAT	=	0xf5f4
                           0000F4   418 _ADC_DAT_L	=	0x00f4
                           0000F5   419 _ADC_DAT_H	=	0x00f5
                           0000F6   420 _ADC_CHAN	=	0x00f6
                           0000A6   421 _LED_COMMON	=	0x00a6
                           0000A7   422 _LED_PWM_OE	=	0x00a7
                           00C7C6   423 _LED_DMA	=	0xc7c6
                           0000C6   424 _LED_DMA_L	=	0x00c6
                           0000C7   425 _LED_DMA_H	=	0x00c7
                           0000F7   426 _LED_STATUS	=	0x00f7
                           0000B3   427 _I2CX_INT	=	0x00b3
                           0000BB   428 _I2CS_INT_ST	=	0x00bb
                                    429 ;--------------------------------------------------------
                                    430 ; special function bits
                                    431 ;--------------------------------------------------------
                                    432 	.area RSEG    (ABS,DATA)
      000000                        433 	.org 0x0000
                           0000D7   434 _CY	=	0x00d7
                           0000D6   435 _AC	=	0x00d6
                           0000D5   436 _F0	=	0x00d5
                           0000D4   437 _RS1	=	0x00d4
                           0000D3   438 _RS0	=	0x00d3
                           0000D2   439 _OV	=	0x00d2
                           0000D1   440 _F1	=	0x00d1
                           0000D0   441 _P	=	0x00d0
                           0000AF   442 _EA	=	0x00af
                           0000AE   443 _E_DIS	=	0x00ae
                           0000AD   444 _ET2	=	0x00ad
                           0000AC   445 _ES	=	0x00ac
                           0000AB   446 _ET1	=	0x00ab
                           0000AA   447 _EX1	=	0x00aa
                           0000A9   448 _ET0	=	0x00a9
                           0000A8   449 _EX0	=	0x00a8
                           0000BF   450 _PH_FLAG	=	0x00bf
                           0000BE   451 _PL_FLAG	=	0x00be
                           0000BD   452 _PT2	=	0x00bd
                           0000BC   453 _PS	=	0x00bc
                           0000BB   454 _PT1	=	0x00bb
                           0000BA   455 _PX1	=	0x00ba
                           0000B9   456 _PT0	=	0x00b9
                           0000B8   457 _PX0	=	0x00b8
                           0000EF   458 _IE_WDOG	=	0x00ef
                           0000EE   459 _IE_GPIO	=	0x00ee
                           0000ED   460 _IE_PWM_I2C	=	0x00ed
                           0000EC   461 _IE_UART1	=	0x00ec
                           0000EB   462 _IE_ADC	=	0x00eb
                           0000E9   463 _IE_USB	=	0x00e9
                           0000E8   464 _IE_SPI0	=	0x00e8
                           000087   465 _P0_7	=	0x0087
                           000086   466 _P0_6	=	0x0086
                           000085   467 _P0_5	=	0x0085
                           000084   468 _P0_4	=	0x0084
                           000083   469 _P0_3	=	0x0083
                           000082   470 _P0_2	=	0x0082
                           000081   471 _P0_1	=	0x0081
                           000080   472 _P0_0	=	0x0080
                           000081   473 _SDA0	=	0x0081
                           000080   474 _SCL0	=	0x0080
                           000083   475 _TXD_	=	0x0083
                           000082   476 _RXD_	=	0x0082
                           000085   477 _AIN13	=	0x0085
                           000084   478 _AIN12	=	0x0084
                           000083   479 _AIN11	=	0x0083
                           000082   480 _AIN10	=	0x0082
                           000081   481 _AIN9	=	0x0081
                           000080   482 _AIN8	=	0x0080
                           000097   483 _P1_7	=	0x0097
                           000096   484 _P1_6	=	0x0096
                           000095   485 _P1_5	=	0x0095
                           000094   486 _P1_4	=	0x0094
                           000093   487 _P1_3	=	0x0093
                           000092   488 _P1_2	=	0x0092
                           000091   489 _P1_1	=	0x0091
                           000090   490 _P1_0	=	0x0090
                           000097   491 _TXD1_	=	0x0097
                           000096   492 _RXD1_	=	0x0096
                           000097   493 _SCK	=	0x0097
                           000096   494 _MISO	=	0x0096
                           000095   495 _MOSI	=	0x0095
                           000094   496 _SCS	=	0x0094
                           000092   497 _INT0_	=	0x0092
                           000091   498 _T2EX	=	0x0091
                           000091   499 _CAP2	=	0x0091
                           000090   500 _T2	=	0x0090
                           000090   501 _CAP1	=	0x0090
                           000097   502 _AIN7	=	0x0097
                           000096   503 _AIN6	=	0x0096
                           000095   504 _AIN5	=	0x0095
                           000094   505 _AIN4	=	0x0094
                           000093   506 _AIN3	=	0x0093
                           000092   507 _AIN2	=	0x0092
                           000091   508 _AIN1	=	0x0091
                           000090   509 _AIN0	=	0x0090
                           0000A7   510 _P2_7	=	0x00a7
                           0000A6   511 _P2_6	=	0x00a6
                           0000A5   512 _P2_5	=	0x00a5
                           0000A4   513 _P2_4	=	0x00a4
                           0000A3   514 _P2_3	=	0x00a3
                           0000A2   515 _P2_2	=	0x00a2
                           0000A1   516 _P2_1	=	0x00a1
                           0000A0   517 _P2_0	=	0x00a0
                           0000A7   518 _TXD1	=	0x00a7
                           0000A6   519 _RXD1	=	0x00a6
                           0000A5   520 _T2EX_	=	0x00a5
                           0000A5   521 _CAP2_	=	0x00a5
                           0000A4   522 _T2_	=	0x00a4
                           0000A4   523 _CAP1_	=	0x00a4
                           0000B7   524 _P3_7	=	0x00b7
                           0000B6   525 _P3_6	=	0x00b6
                           0000B5   526 _P3_5	=	0x00b5
                           0000B4   527 _P3_4	=	0x00b4
                           0000B3   528 _P3_3	=	0x00b3
                           0000B2   529 _P3_2	=	0x00b2
                           0000B1   530 _P3_1	=	0x00b1
                           0000B0   531 _P3_0	=	0x00b0
                           0000B7   532 _SCK1	=	0x00b7
                           0000B6   533 _MISO1	=	0x00b6
                           0000B5   534 _MOSI1	=	0x00b5
                           0000B5   535 _T1	=	0x00b5
                           0000B4   536 _T0	=	0x00b4
                           0000B3   537 _INT1	=	0x00b3
                           0000B2   538 _INT0	=	0x00b2
                           0000B1   539 _TXD	=	0x00b1
                           0000B0   540 _RXD	=	0x00b0
                           0000C6   541 _P4_6	=	0x00c6
                           0000C5   542 _P4_5	=	0x00c5
                           0000C4   543 _P4_4	=	0x00c4
                           0000C3   544 _P4_3	=	0x00c3
                           0000C2   545 _P4_2	=	0x00c2
                           0000C1   546 _P4_1	=	0x00c1
                           0000C0   547 _P4_0	=	0x00c0
                           00008F   548 _TF1	=	0x008f
                           00008E   549 _TR1	=	0x008e
                           00008D   550 _TF0	=	0x008d
                           00008C   551 _TR0	=	0x008c
                           00008B   552 _IE1	=	0x008b
                           00008A   553 _IT1	=	0x008a
                           000089   554 _IE0	=	0x0089
                           000088   555 _IT0	=	0x0088
                           00009F   556 _SM0	=	0x009f
                           00009E   557 _SM1	=	0x009e
                           00009D   558 _SM2	=	0x009d
                           00009C   559 _REN	=	0x009c
                           00009B   560 _TB8	=	0x009b
                           00009A   561 _RB8	=	0x009a
                           000099   562 _TI	=	0x0099
                           000098   563 _RI	=	0x0098
                           0000CF   564 _TF2	=	0x00cf
                           0000CF   565 _CAP1F	=	0x00cf
                           0000CE   566 _EXF2	=	0x00ce
                           0000CD   567 _RCLK	=	0x00cd
                           0000CC   568 _TCLK	=	0x00cc
                           0000CB   569 _EXEN2	=	0x00cb
                           0000CA   570 _TR2	=	0x00ca
                           0000C9   571 _C_T2	=	0x00c9
                           0000C8   572 _CP_RL2	=	0x00c8
                           0000FF   573 _S0_FST_ACT	=	0x00ff
                           0000FE   574 _S0_IF_OV	=	0x00fe
                           0000FD   575 _S0_IF_FIRST	=	0x00fd
                           0000FC   576 _S0_IF_BYTE	=	0x00fc
                           0000FB   577 _S0_FREE	=	0x00fb
                           0000FA   578 _S0_T_FIFO	=	0x00fa
                           0000F8   579 _S0_R_FIFO	=	0x00f8
                           0000F7   580 _ADC_START	=	0x00f7
                                    581 ;--------------------------------------------------------
                                    582 ; overlayable register banks
                                    583 ;--------------------------------------------------------
                                    584 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        585 	.ds 8
                                    586 ;--------------------------------------------------------
                                    587 ; internal ram data
                                    588 ;--------------------------------------------------------
                                    589 	.area DSEG    (DATA)
      000027                        590 _process_action_sloc0_1_0:
      000027                        591 	.ds 1
                                    592 ;--------------------------------------------------------
                                    593 ; overlayable items in internal ram
                                    594 ;--------------------------------------------------------
                                    595 ;--------------------------------------------------------
                                    596 ; indirectly addressable internal ram data
                                    597 ;--------------------------------------------------------
                                    598 	.area ISEG    (DATA)
                                    599 ;--------------------------------------------------------
                                    600 ; absolute internal ram data
                                    601 ;--------------------------------------------------------
                                    602 	.area IABS    (ABS,DATA)
                                    603 	.area IABS    (ABS,DATA)
                                    604 ;--------------------------------------------------------
                                    605 ; bit data
                                    606 ;--------------------------------------------------------
                                    607 	.area BSEG    (BIT)
      00001E                        608 _process_action_sloc1_1_0:
      00001E                        609 	.ds 1
                                    610 ;--------------------------------------------------------
                                    611 ; paged external ram data
                                    612 ;--------------------------------------------------------
                                    613 	.area PSEG    (PAG,XDATA)
                                    614 ;--------------------------------------------------------
                                    615 ; uninitialized external ram data
                                    616 ;--------------------------------------------------------
                                    617 	.area XSEG    (XDATA)
      000823                        618 _tp_buttons::
      000823                        619 	.ds 2
      000825                        620 _action_exec_PARM_1:
      000825                        621 	.ds 6
      00082B                        622 _action_exec_record_10001_628:
      00082B                        623 	.ds 9
      000834                        624 _ak820_action_exec_event_10000_633:
      000834                        625 	.ds 2
      000836                        626 _ak820_action_exec_snapshot_10000_634:
      000836                        627 	.ds 6
      00083C                        628 _process_record_record_argument_10000_637:
      00083C                        629 	.ds 2
      00083E                        630 _process_record_handler_record_argument_10000_645:
      00083E                        631 	.ds 2
      000840                        632 _process_record_handler_action_10000_646:
      000840                        633 	.ds 2
      000842                        634 _process_action_PARM_2:
      000842                        635 	.ds 2
      000844                        636 _process_action_record_argument_10000_657:
      000844                        637 	.ds 2
      000846                        638 _process_action_on_40000_680:
      000846                        639 	.ds 1
      000847                        640 _register_code_code_10000_714:
      000847                        641 	.ds 1
      000848                        642 _unregister_code_code_10000_728:
      000848                        643 	.ds 1
      000849                        644 _tap_code_delay_PARM_2:
      000849                        645 	.ds 2
      00084B                        646 _tap_code_delay_code_10000_741:
      00084B                        647 	.ds 1
      00084C                        648 _tap_code_code_10000_748:
      00084C                        649 	.ds 1
      00084D                        650 _register_mods_mods_10000_750:
      00084D                        651 	.ds 1
      00084E                        652 _unregister_mods_mods_10000_754:
      00084E                        653 	.ds 1
      00084F                        654 _register_weak_mods_mods_10000_758:
      00084F                        655 	.ds 1
      000850                        656 _unregister_weak_mods_mods_10000_762:
      000850                        657 	.ds 1
                                    658 ;--------------------------------------------------------
                                    659 ; absolute external ram data
                                    660 ;--------------------------------------------------------
                                    661 	.area XABS    (ABS,XDATA)
                                    662 ;--------------------------------------------------------
                                    663 ; initialized external ram data
                                    664 ;--------------------------------------------------------
                                    665 	.area XISEG   (XDATA)
      000DAA                        666 _disable_action_cache::
      000DAA                        667 	.ds 1
                                    668 	.area HOME    (CODE)
                                    669 	.area GSINIT0 (CODE)
                                    670 	.area GSINIT1 (CODE)
                                    671 	.area GSINIT2 (CODE)
                                    672 	.area GSINIT3 (CODE)
                                    673 	.area GSINIT4 (CODE)
                                    674 	.area GSINIT5 (CODE)
                                    675 	.area GSINIT  (CODE)
                                    676 	.area GSFINAL (CODE)
                                    677 	.area CSEG    (CODE)
                                    678 ;--------------------------------------------------------
                                    679 ; global & static initialisations
                                    680 ;--------------------------------------------------------
                                    681 	.area HOME    (CODE)
                                    682 	.area GSINIT  (CODE)
                                    683 	.area GSFINAL (CODE)
                                    684 	.area GSINIT  (CODE)
                                    685 ;--------------------------------------------------------
                                    686 ; Home
                                    687 ;--------------------------------------------------------
                                    688 	.area HOME    (CODE)
                                    689 	.area HOME    (CODE)
                                    690 ;--------------------------------------------------------
                                    691 ; code
                                    692 ;--------------------------------------------------------
                                    693 	.area CSEG    (CODE)
                                    694 ;------------------------------------------------------------
                                    695 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    696 ;------------------------------------------------------------
                                    697 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    698 ;------------------------------------------------------------
                                    699 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    700 ;	-----------------------------------------
                           000007   701 	ar7 = 0x07
                           000006   702 	ar6 = 0x06
                           000005   703 	ar5 = 0x05
                           000004   704 	ar4 = 0x04
                           000003   705 	ar3 = 0x03
                           000002   706 	ar2 = 0x02
                           000001   707 	ar1 = 0x01
                           000000   708 	ar0 = 0x00
                                    709 ;	 function action_exec
                                    710 ;	-----------------------------------------
      0073ED                        711 _action_exec:
                                    712 ;	quantum/action.c:101: ak820_combo_tick(event.time);
      0073ED 90 08 27         [24]  713 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      0073F0 12 39 E7         [24]  714 	lcall	_ak820_outline_0004
      0073F3 12 37 FE         [24]  715 	lcall	_ak820_combo_tick
                                    716 ;	quantum/action.c:104: if (!ak820_tapping_before(&event)) return;
      0073F6 90 08 25         [24]  717 	mov	dptr,#_action_exec_PARM_1
      0073F9 12 47 99         [24]  718 	lcall	_ak820_tapping_before
      0073FC E5 82            [12]  719 	mov	a, dpl
      0073FE 70 01            [24]  720 	jnz	00102$
      007400 22               [24]  721 	ret
      007401                        722 00102$:
                                    723 ;	quantum/action.c:110: if (!ak820_autoshift_before(&event)) return;
      007401 90 08 25         [24]  724 	mov	dptr,#_action_exec_PARM_1
      007404 12 31 2A         [24]  725 	lcall	_ak820_autoshift_before
      007407 E5 82            [12]  726 	mov	a, dpl
      007409 70 01            [24]  727 	jnz	00104$
      00740B 22               [24]  728 	ret
      00740C                        729 00104$:
                                    730 ;	quantum/action.c:126: if (event.pressed) {
      00740C 90 08 2A         [24]  731 	mov	dptr,#(_action_exec_PARM_1 + 0x0005)
      00740F E0               [24]  732 	movx	a,@dptr
      007410 60 03            [24]  733 	jz	00106$
                                    734 ;	quantum/action.c:128: clear_weak_mods();
      007412 12 84 09         [24]  735 	lcall	_clear_weak_mods
      007415                        736 00106$:
                                    737 ;	quantum/action.c:140: record.event = event;
      007415 90 0D 89         [24]  738 	mov	dptr,#___memcpy_PARM_2
      007418 74 25            [12]  739 	mov	a,#_action_exec_PARM_1
      00741A F0               [24]  740 	movx	@dptr,a
      00741B 74 08            [12]  741 	mov	a,#(_action_exec_PARM_1 >> 8)
      00741D 12 7A 80         [24]  742 	lcall	_ak820_outline_0050
      007420 12 7A A0         [24]  743 	lcall	_ak820_outline_0107
      007423 90 08 2B         [24]  744 	mov	dptr,#_action_exec_record_10001_628
      007426 F5 F0            [12]  745 	mov	b,a
      007428 12 BA 3F         [24]  746 	lcall	___memcpy
                                    747 ;	quantum/action.c:142: record.tap.count = 0;
      00742B 90 08 31         [24]  748 	mov	dptr,#(_action_exec_record_10001_628 + 0x0006)
      00742E E0               [24]  749 	movx	a,@dptr
      00742F 54 0F            [12]  750 	anl	a,#0x0f
      007431 F0               [24]  751 	movx	@dptr,a
                                    752 ;	quantum/action.c:147: record.keycode = 0;
      007432 90 08 32         [24]  753 	mov	dptr,#(_action_exec_record_10001_628 + 0x0007)
      007435 12 52 54         [24]  754 	lcall	_ak820_outline_0166
                                    755 ;	quantum/action.c:178: if (IS_NOEVENT(record.event) || pre_process_record_quantum(&record)) {
      007438 90 08 2F         [24]  756 	mov	dptr,#(_action_exec_record_10001_628 + 0x0004)
      00743B E0               [24]  757 	movx	a,@dptr
      00743C 60 0A            [24]  758 	jz	00111$
      00743E 90 08 2B         [24]  759 	mov	dptr,#_action_exec_record_10001_628
      007441 12 A1 6A         [24]  760 	lcall	_pre_process_record_quantum
      007444 E5 82            [12]  761 	mov	a, dpl
      007446 60 1C            [24]  762 	jz	00114$
      007448                        763 00111$:
                                    764 ;	quantum/action.c:180: if (!ak820_tapping_process(&record)) return;
      007448 90 08 2B         [24]  765 	mov	dptr,#_action_exec_record_10001_628
      00744B 12 48 85         [24]  766 	lcall	_ak820_tapping_process
      00744E E5 82            [12]  767 	mov	a, dpl
      007450 70 01            [24]  768 	jnz	00108$
      007452 22               [24]  769 	ret
      007453                        770 00108$:
                                    771 ;	quantum/action.c:182: if (!ak820_autoshift_process(&record)) return;
      007453 90 08 2B         [24]  772 	mov	dptr,#_action_exec_record_10001_628
      007456 12 32 30         [24]  773 	lcall	_ak820_autoshift_process
      007459 E5 82            [12]  774 	mov	a, dpl
      00745B 70 01            [24]  775 	jnz	00110$
      00745D 22               [24]  776 	ret
      00745E                        777 00110$:
                                    778 ;	quantum/action.c:185: process_record(&record);
      00745E 90 08 2B         [24]  779 	mov	dptr,#_action_exec_record_10001_628
                                    780 ;	quantum/action.c:200: }
      007461 02 74 A2         [24]  781 	ljmp	_process_record
      007464                        782 00114$:
      007464 22               [24]  783 	ret
                                    784 ;------------------------------------------------------------
                                    785 ;Allocation info for local variables in function 'ak820_action_exec'
                                    786 ;------------------------------------------------------------
                                    787 ;event         Allocated with name '_ak820_action_exec_event_10000_633'
                                    788 ;snapshot      Allocated with name '_ak820_action_exec_snapshot_10000_634'
                                    789 ;------------------------------------------------------------
                                    790 ;	quantum/action.c:203: void ak820_action_exec(const keyevent_t __xdata *event) {
                                    791 ;	-----------------------------------------
                                    792 ;	 function ak820_action_exec
                                    793 ;	-----------------------------------------
      007465                        794 _ak820_action_exec:
      007465 12 3A 8A         [24]  795 	lcall	_ak820_outline_0103
      007468 90 08 34         [24]  796 	mov	dptr,#_ak820_action_exec_event_10000_633
      00746B 12 3A 8F         [24]  797 	lcall	_ak820_outline_0104
                                    798 ;	quantum/action.c:206: keyevent_t snapshot = *event;
      00746E 90 08 34         [24]  799 	mov	dptr,#_ak820_action_exec_event_10000_633
      007471 12 3A 5E         [24]  800 	lcall	_ak820_outline_0058
      007474 90 0D 89         [24]  801 	mov	dptr,#___memcpy_PARM_2
      007477 ED               [12]  802 	mov	a,r5
      007478 12 3A 26         [24]  803 	lcall	_ak820_outline_0016
      00747B 90 0D 8C         [24]  804 	mov	dptr,#___memcpy_PARM_3
      00747E 12 7A A0         [24]  805 	lcall	_ak820_outline_0107
      007481 90 08 36         [24]  806 	mov	dptr,#_ak820_action_exec_snapshot_10000_634
      007484 F5 F0            [12]  807 	mov	b,a
      007486 12 BA 3F         [24]  808 	lcall	___memcpy
                                    809 ;	quantum/action.c:207: action_exec(snapshot);
      007489 90 0D 89         [24]  810 	mov	dptr,#___memcpy_PARM_2
      00748C 74 36            [12]  811 	mov	a,#_ak820_action_exec_snapshot_10000_634
      00748E F0               [24]  812 	movx	@dptr,a
      00748F 74 08            [12]  813 	mov	a,#(_ak820_action_exec_snapshot_10000_634 >> 8)
      007491 12 7A 80         [24]  814 	lcall	_ak820_outline_0050
      007494 12 7A A0         [24]  815 	lcall	_ak820_outline_0107
      007497 90 08 25         [24]  816 	mov	dptr,#_action_exec_PARM_1
      00749A F5 F0            [12]  817 	mov	b,a
      00749C 12 BA 3F         [24]  818 	lcall	___memcpy
                                    819 ;	quantum/action.c:208: }
      00749F 02 73 ED         [24]  820 	ljmp	_action_exec
                                    821 ;------------------------------------------------------------
                                    822 ;Allocation info for local variables in function 'process_record_nocache'
                                    823 ;------------------------------------------------------------
                                    824 ;record        Allocated with name '_process_record_nocache_record_10000_635'
                                    825 ;------------------------------------------------------------
                                    826 ;	quantum/action.c:293: void process_record_nocache(keyrecord_t AK820_RECORD_MEM *record) {
                                    827 ;	-----------------------------------------
                                    828 ;	 function process_record
                                    829 ;	-----------------------------------------
      0074A2                        830 _process_record:
      0074A2 12 3A 8A         [24]  831 	lcall	_ak820_outline_0103
      0074A5 90 08 3C         [24]  832 	mov	dptr,#_process_record_record_argument_10000_637
      0074A8 12 3A 8F         [24]  833 	lcall	_ak820_outline_0104
                                    834 ;	quantum/action.c:349: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      0074AB 90 08 3C         [24]  835 	mov	dptr,#_process_record_record_argument_10000_637
      0074AE 12 3A 47         [24]  836 	lcall	_ak820_outline_0051
                                    837 ;	quantum/action.c:353: if (IS_NOEVENT(record->event)) {
      0074B1 74 04            [12]  838 	mov	a,#0x04
      0074B3 12 4B 5B         [24]  839 	lcall	_ak820_outline_0012
      0074B6 70 01            [24]  840 	jnz	00102$
                                    841 ;	quantum/action.c:354: return;
      0074B8 22               [24]  842 	ret
      0074B9                        843 00102$:
                                    844 ;	quantum/action.c:362: uint8_t oneshot_source = ak820_tapping_source(record->event.key);
      0074B9 8E 04            [24]  845 	mov	ar4,r6
      0074BB 8F 05            [24]  846 	mov	ar5,r7
      0074BD 90 0D 89         [24]  847 	mov	dptr,#___memcpy_PARM_2
      0074C0 EC               [12]  848 	mov	a,r4
      0074C1 F0               [24]  849 	movx	@dptr,a
      0074C2 ED               [12]  850 	mov	a,r5
      0074C3 12 7A 80         [24]  851 	lcall	_ak820_outline_0050
      0074C6 12 52 46         [24]  852 	lcall	_ak820_outline_0106
      0074C9 90 06 38         [24]  853 	mov	dptr,#_ak820_tapping_source_PARM_1
      0074CC F5 F0            [12]  854 	mov	b,a
      0074CE C0 07            [24]  855 	push	ar7
      0074D0 C0 06            [24]  856 	push	ar6
      0074D2 12 BA 3F         [24]  857 	lcall	___memcpy
      0074D5 12 46 D5         [24]  858 	lcall	_ak820_tapping_source
      0074D8 AD 82            [24]  859 	mov	r5, dpl
      0074DA D0 06            [24]  860 	pop	ar6
      0074DC D0 07            [24]  861 	pop	ar7
                                    862 ;	quantum/action.c:363: bool oneshot_pressed = record->event.pressed;
      0074DE 12 45 74         [24]  863 	lcall	_ak820_outline_0011
      0074E1 E0               [24]  864 	movx	a,@dptr
      0074E2 FC               [12]  865 	mov	r4,a
                                    866 ;	quantum/action.c:364: record->keycode = get_record_keycode(record, true);
      0074E3 74 07            [12]  867 	mov	a,#0x07
      0074E5 2E               [12]  868 	add	a, r6
      0074E6 FA               [12]  869 	mov	r2,a
      0074E7 E4               [12]  870 	clr	a
      0074E8 3F               [12]  871 	addc	a, r7
      0074E9 FB               [12]  872 	mov	r3,a
      0074EA 90 0B EB         [24]  873 	mov	dptr,#_get_record_keycode_PARM_2
      0074ED 12 4B A5         [24]  874 	lcall	_ak820_outline_0055
      0074F0 C0 07            [24]  875 	push	ar7
      0074F2 C0 06            [24]  876 	push	ar6
      0074F4 C0 05            [24]  877 	push	ar5
      0074F6 C0 04            [24]  878 	push	ar4
      0074F8 C0 03            [24]  879 	push	ar3
      0074FA C0 02            [24]  880 	push	ar2
      0074FC 12 A1 2D         [24]  881 	lcall	_get_record_keycode
      0074FF A8 82            [24]  882 	mov	r0, dpl
      007501 A9 83            [24]  883 	mov	r1, dph
      007503 D0 02            [24]  884 	pop	ar2
      007505 D0 03            [24]  885 	pop	ar3
      007507 D0 04            [24]  886 	pop	ar4
      007509 D0 05            [24]  887 	pop	ar5
      00750B D0 06            [24]  888 	pop	ar6
      00750D D0 07            [24]  889 	pop	ar7
      00750F 12 45 EB         [24]  890 	lcall	_ak820_outline_0140
      007512 E8               [12]  891 	mov	a,r0
      007513 F0               [24]  892 	movx	@dptr,a
      007514 E9               [12]  893 	mov	a,r1
      007515 A3               [24]  894 	inc	dptr
      007516 F0               [24]  895 	movx	@dptr,a
                                    896 ;	quantum/action.c:365: if (!ak820_oneshot_process(record->keycode, oneshot_source, oneshot_pressed)) return;
      007517 74 07            [12]  897 	mov	a,#0x07
      007519 12 3A 2E         [24]  898 	lcall	_ak820_outline_0017
      00751C FA               [12]  899 	mov	r2,a
      00751D A3               [24]  900 	inc	dptr
      00751E E0               [24]  901 	movx	a,@dptr
      00751F FB               [12]  902 	mov	r3,a
      007520 90 06 48         [24]  903 	mov	dptr,#_ak820_oneshot_process_PARM_2
      007523 ED               [12]  904 	mov	a,r5
      007524 F0               [24]  905 	movx	@dptr,a
      007525 90 06 49         [24]  906 	mov	dptr,#_ak820_oneshot_process_PARM_3
      007528 EC               [12]  907 	mov	a,r4
      007529 F0               [24]  908 	movx	@dptr,a
      00752A 12 45 EB         [24]  909 	lcall	_ak820_outline_0140
      00752D C0 07            [24]  910 	push	ar7
      00752F C0 06            [24]  911 	push	ar6
      007531 C0 05            [24]  912 	push	ar5
      007533 C0 04            [24]  913 	push	ar4
      007535 12 4A 25         [24]  914 	lcall	_ak820_oneshot_process
      007538 E5 82            [12]  915 	mov	a, dpl
      00753A D0 04            [24]  916 	pop	ar4
      00753C D0 05            [24]  917 	pop	ar5
      00753E D0 06            [24]  918 	pop	ar6
      007540 D0 07            [24]  919 	pop	ar7
      007542 70 01            [24]  920 	jnz	00104$
      007544 22               [24]  921 	ret
      007545                        922 00104$:
                                    923 ;	quantum/action.c:367: if (!process_record_quantum(record)) {
      007545 12 45 CF         [24]  924 	lcall	_ak820_outline_0116
      007548 C0 07            [24]  925 	push	ar7
      00754A C0 06            [24]  926 	push	ar6
      00754C C0 05            [24]  927 	push	ar5
      00754E C0 04            [24]  928 	push	ar4
      007550 12 A1 AC         [24]  929 	lcall	_process_record_quantum
      007553 E5 82            [12]  930 	mov	a, dpl
      007555 D0 04            [24]  931 	pop	ar4
      007557 D0 05            [24]  932 	pop	ar5
      007559 D0 06            [24]  933 	pop	ar6
      00755B D0 07            [24]  934 	pop	ar7
      00755D 70 0A            [24]  935 	jnz	00106$
                                    936 ;	quantum/action.c:369: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      00755F 90 05 A8         [24]  937 	mov	dptr,#_ak820_oneshot_post_PARM_2
      007562 EC               [12]  938 	mov	a,r4
      007563 F0               [24]  939 	movx	@dptr,a
      007564 8D 82            [24]  940 	mov	dpl, r5
                                    941 ;	quantum/action.c:376: return;
      007566 02 2E 6F         [24]  942 	ljmp	_ak820_oneshot_post
      007569                        943 00106$:
                                    944 ;	quantum/action.c:382: process_record_handler(record);
      007569 12 45 CF         [24]  945 	lcall	_ak820_outline_0116
      00756C C0 05            [24]  946 	push	ar5
      00756E C0 04            [24]  947 	push	ar4
      007570 12 75 81         [24]  948 	lcall	_process_record_handler
      007573 D0 04            [24]  949 	pop	ar4
      007575 D0 05            [24]  950 	pop	ar5
                                    951 ;	quantum/action.c:390: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      007577 90 05 A8         [24]  952 	mov	dptr,#_ak820_oneshot_post_PARM_2
      00757A EC               [12]  953 	mov	a,r4
      00757B F0               [24]  954 	movx	@dptr,a
      00757C 8D 82            [24]  955 	mov	dpl, r5
                                    956 ;	quantum/action.c:392: }
      00757E 02 2E 6F         [24]  957 	ljmp	_ak820_oneshot_post
                                    958 ;------------------------------------------------------------
                                    959 ;Allocation info for local variables in function 'process_record_handler'
                                    960 ;------------------------------------------------------------
                                    961 ;record_argument Allocated with name '_process_record_handler_record_argument_10000_645'
                                    962 ;record        Allocated with name '_process_record_handler_record_10000_646'
                                    963 ;action        Allocated with name '_process_record_handler_action_10000_646'
                                    964 ;------------------------------------------------------------
                                    965 ;	quantum/action.c:394: void process_record_handler(keyrecord_t AK820_RECORD_MEM *record_argument) {
                                    966 ;	-----------------------------------------
                                    967 ;	 function process_record_handler
                                    968 ;	-----------------------------------------
      007581                        969 _process_record_handler:
      007581 12 3A 8A         [24]  970 	lcall	_ak820_outline_0103
      007584 90 08 3E         [24]  971 	mov	dptr,#_process_record_handler_record_argument_10000_645
      007587 12 3A 8F         [24]  972 	lcall	_ak820_outline_0104
                                    973 ;	quantum/action.c:398: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00758A 90 08 3E         [24]  974 	mov	dptr,#_process_record_handler_record_argument_10000_645
      00758D 12 39 FE         [24]  975 	lcall	_ak820_outline_0009
                                    976 ;	quantum/action.c:405: if (record->keycode) {
      007590 4C               [12]  977 	orl	a,r4
      007591 60 19            [24]  978 	jz	00102$
                                    979 ;	quantum/action.c:406: action.code = action_for_keycode(record->keycode);
      007593 12 3A 9B         [24]  980 	lcall	_ak820_outline_0117
      007596 C0 07            [24]  981 	push	ar7
      007598 C0 06            [24]  982 	push	ar6
      00759A 12 98 00         [24]  983 	lcall	_action_for_keycode
      00759D 12 45 F0         [24]  984 	lcall	_ak820_outline_0145
      0075A0 D0 06            [24]  985 	pop	ar6
      0075A2 D0 07            [24]  986 	pop	ar7
      0075A4 90 08 40         [24]  987 	mov	dptr,#_process_record_handler_action_10000_646
      0075A7 12 3A 6C         [24]  988 	lcall	_ak820_outline_0071
      0075AA 80 2A            [24]  989 	sjmp	00104$
      0075AC                        990 00102$:
                                    991 ;	quantum/action.c:409: action.code = action_for_keycode(ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed));
      0075AC 12 7A 68         [24]  992 	lcall	_ak820_outline_0020
      0075AF 7A 00            [12]  993 	mov	r2,#0x00
      0075B1 12 45 E5         [24]  994 	lcall	_ak820_outline_0139
      0075B4 12 45 74         [24]  995 	lcall	_ak820_outline_0011
      0075B7 E0               [24]  996 	movx	a,@dptr
      0075B8 90 09 7B         [24]  997 	mov	dptr,#_ak820_resolve_key_PARM_2
      0075BB F0               [24]  998 	movx	@dptr,a
      0075BC 12 46 10         [24]  999 	lcall	_ak820_outline_0184
      0075BF C0 07            [24] 1000 	push	ar7
      0075C1 C0 06            [24] 1001 	push	ar6
      0075C3 12 7E 05         [24] 1002 	lcall	_ak820_resolve_key
      0075C6 12 98 00         [24] 1003 	lcall	_action_for_keycode
      0075C9 12 45 F0         [24] 1004 	lcall	_ak820_outline_0145
      0075CC D0 06            [24] 1005 	pop	ar6
      0075CE D0 07            [24] 1006 	pop	ar7
      0075D0 90 08 40         [24] 1007 	mov	dptr,#_process_record_handler_action_10000_646
      0075D3 12 3A 6C         [24] 1008 	lcall	_ak820_outline_0071
                                   1009 ;	quantum/action.c:418: ac_dprintf("ACTION: ");
      0075D6                       1010 00104$:
                                   1011 ;	quantum/action.c:429: process_action(record, action);
      0075D6 90 0D 89         [24] 1012 	mov	dptr,#___memcpy_PARM_2
      0075D9 74 40            [12] 1013 	mov	a,#_process_record_handler_action_10000_646
      0075DB F0               [24] 1014 	movx	@dptr,a
      0075DC 74 08            [12] 1015 	mov	a,#(_process_record_handler_action_10000_646 >> 8)
      0075DE 12 7A 80         [24] 1016 	lcall	_ak820_outline_0050
      0075E1 12 52 46         [24] 1017 	lcall	_ak820_outline_0106
      0075E4 90 08 42         [24] 1018 	mov	dptr,#_process_action_PARM_2
      0075E7 F5 F0            [12] 1019 	mov	b,a
      0075E9 C0 07            [24] 1020 	push	ar7
      0075EB C0 06            [24] 1021 	push	ar6
      0075ED 12 BA 3F         [24] 1022 	lcall	___memcpy
      0075F0 D0 06            [24] 1023 	pop	ar6
      0075F2 D0 07            [24] 1024 	pop	ar7
      0075F4 12 45 CF         [24] 1025 	lcall	_ak820_outline_0116
                                   1026 ;	quantum/action.c:430: }
      0075F7 02 75 FA         [24] 1027 	ljmp	_process_action
                                   1028 ;------------------------------------------------------------
                                   1029 ;Allocation info for local variables in function 'register_mouse'
                                   1030 ;------------------------------------------------------------
                                   1031 ;pressed       Allocated with name '_register_mouse_PARM_2'
                                   1032 ;mouse_keycode Allocated with name '_register_mouse_mouse_keycode_10000_654'
                                   1033 ;------------------------------------------------------------
                                   1034 ;	quantum/action.c:442: void register_mouse(uint8_t mouse_keycode, bool pressed) {
                                   1035 ;	-----------------------------------------
                                   1036 ;	 function process_action
                                   1037 ;	-----------------------------------------
      0075FA                       1038 _process_action:
      0075FA 12 3A 8A         [24] 1039 	lcall	_ak820_outline_0103
      0075FD 90 08 44         [24] 1040 	mov	dptr,#_process_action_record_argument_10000_657
      007600 12 3A 8F         [24] 1041 	lcall	_ak820_outline_0104
                                   1042 ;	quantum/action.c:495: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      007603 90 08 44         [24] 1043 	mov	dptr,#_process_action_record_argument_10000_657
      007606 12 39 E7         [24] 1044 	lcall	_ak820_outline_0004
                                   1045 ;	quantum/action.c:501: pressed = record->event.pressed;
      007609 A3               [24] 1046 	inc	dptr
      00760A A3               [24] 1047 	inc	dptr
      00760B A3               [24] 1048 	inc	dptr
      00760C A3               [24] 1049 	inc	dptr
      00760D A3               [24] 1050 	inc	dptr
      00760E E0               [24] 1051 	movx	a,@dptr
      00760F F5 27            [12] 1052 	mov	_process_action_sloc0_1_0,a
                                   1053 ;	quantum/action.c:525: switch (action.kind.id) {
      007611 90 08 43         [24] 1054 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007614 E0               [24] 1055 	movx	a,@dptr
      007615 C4               [12] 1056 	swap	a
      007616 54 0F            [12] 1057 	anl	a,#0x0f
      007618 FD               [12] 1058 	mov  r5,a
      007619 24 F4            [12] 1059 	add	a,#0xff - 0x0b
      00761B 50 03            [24] 1060 	jnc	00434$
      00761D 02 78 99         [24] 1061 	ljmp	00181$
      007620                       1062 00434$:
                                   1063 ;	free result
      007620 ED               [12] 1064 	mov	a,r5
      007621 24 0A            [12] 1065 	add	a,#(00435$-3-.)
      007623 83               [24] 1066 	movc	a,@a+pc
      007624 F5 82            [12] 1067 	mov	dpl,a
      007626 ED               [12] 1068 	mov	a,r5
      007627 24 10            [12] 1069 	add	a,#(00436$-3-.)
      007629 83               [24] 1070 	movc	a,@a+pc
      00762A F5 83            [12] 1071 	mov	dph,a
      00762C E4               [12] 1072 	clr	a
      00762D 73               [24] 1073 	jmp	@a+dptr
      00762E                       1074 00435$:
      00762E 46                    1075 	.db	00102$
      00762F 46                    1076 	.db	00102$
      007630 99                    1077 	.db	00181$
      007631 99                    1078 	.db	00181$
      007632 CE                    1079 	.db	00123$
      007633 99                    1080 	.db	00181$
      007634 99                    1081 	.db	00181$
      007635 99                    1082 	.db	00181$
      007636 2E                    1083 	.db	00131$
      007637 00                    1084 	.db	00147$
      007638 26                    1085 	.db	00152$
      007639 26                    1086 	.db	00152$
      00763A                       1087 00436$:
      00763A 76                    1088 	.db	00102$>>8
      00763B 76                    1089 	.db	00102$>>8
      00763C 78                    1090 	.db	00181$>>8
      00763D 78                    1091 	.db	00181$>>8
      00763E 76                    1092 	.db	00123$>>8
      00763F 78                    1093 	.db	00181$>>8
      007640 78                    1094 	.db	00181$>>8
      007641 78                    1095 	.db	00181$>>8
      007642 77                    1096 	.db	00131$>>8
      007643 78                    1097 	.db	00147$>>8
      007644 78                    1098 	.db	00152$>>8
      007645 78                    1099 	.db	00152$>>8
                                   1100 ;	quantum/action.c:528: case ACT_RMODS: {
      007646                       1101 00102$:
                                   1102 ;	quantum/action.c:529: mods = (action.kind.id == ACT_LMODS) ? action.key.mods : action.key.mods << 4;
      007646 90 08 43         [24] 1103 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007649 E0               [24] 1104 	movx	a,@dptr
      00764A 54 F0            [12] 1105 	anl	a,#0xf0
      00764C 70 06            [24] 1106 	jnz	00194$
      00764E 12 7A A7         [24] 1107 	lcall	_ak820_outline_0109
      007651 FD               [12] 1108 	mov	r5,a
      007652 80 07            [24] 1109 	sjmp	00195$
      007654                       1110 00194$:
      007654 12 7A A7         [24] 1111 	lcall	_ak820_outline_0109
      007657 C4               [12] 1112 	swap	a
      007658 54 F0            [12] 1113 	anl	a,#0xf0
      00765A FD               [12] 1114 	mov	r5,a
      00765B                       1115 00195$:
                                   1116 ;	quantum/action.c:531: if (pressed) {
      00765B E5 27            [12] 1117 	mov	a,_process_action_sloc0_1_0
      00765D 60 34            [24] 1118 	jz	00119$
                                   1119 ;	quantum/action.c:532: if (mods) {
      00765F ED               [12] 1120 	mov	a,r5
      007660 60 28            [24] 1121 	jz	00110$
                                   1122 ;	quantum/action.c:533: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      007662 12 7A B9         [24] 1123 	lcall	_ak820_outline_0154
      007665 FC               [12] 1124 	mov	r4,a
      007666 BC E0 00         [24] 1125 	cjne	r4,#0xe0,00440$
      007669                       1126 00440$:
      007669 40 07            [24] 1127 	jc	00108$
      00766B 12 7A B9         [24] 1128 	lcall	_ak820_outline_0154
      00766E 24 18            [12] 1129 	add	a,#0xff - 0xe7
      007670 50 09            [24] 1130 	jnc	00104$
                                   1131 ;	free result
      007672                       1132 00108$:
      007672 7B 42            [12] 1133 	mov	r3,#_process_action_PARM_2
      007674 7C 08            [12] 1134 	mov	r4,#(_process_action_PARM_2 >> 8)
      007676 12 70 1E         [24] 1135 	lcall	_ak820_outline_0118
      007679 70 07            [24] 1136 	jnz	00105$
      00767B                       1137 00104$:
                                   1138 ;	quantum/action.c:537: add_owned_mods(mods);
      00767B 8D 82            [24] 1139 	mov	dpl, r5
      00767D 12 80 1F         [24] 1140 	lcall	_add_owned_mods
      007680 80 05            [24] 1141 	sjmp	00106$
      007682                       1142 00105$:
                                   1143 ;	quantum/action.c:539: add_owned_weak_mods(mods);
      007682 8D 82            [24] 1144 	mov	dpl, r5
      007684 12 80 3E         [24] 1145 	lcall	_add_owned_weak_mods
      007687                       1146 00106$:
                                   1147 ;	quantum/action.c:541: send_keyboard_report();
      007687 12 83 59         [24] 1148 	lcall	_send_keyboard_report
      00768A                       1149 00110$:
                                   1150 ;	quantum/action.c:543: register_code(action.key.code);
      00768A 12 7A 90         [24] 1151 	lcall	_ak820_outline_0076
      00768D 12 78 B0         [24] 1152 	lcall	_register_code
      007690 02 78 99         [24] 1153 	ljmp	00181$
      007693                       1154 00119$:
                                   1155 ;	quantum/action.c:545: unregister_code(action.key.code);
      007693 12 7A 90         [24] 1156 	lcall	_ak820_outline_0076
      007696 C0 05            [24] 1157 	push	ar5
      007698 12 79 1D         [24] 1158 	lcall	_unregister_code
      00769B D0 05            [24] 1159 	pop	ar5
                                   1160 ;	quantum/action.c:546: if (mods) {
      00769D ED               [12] 1161 	mov	a,r5
      00769E 70 03            [24] 1162 	jnz	00444$
      0076A0 02 78 99         [24] 1163 	ljmp	00181$
      0076A3                       1164 00444$:
                                   1165 ;	quantum/action.c:547: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      0076A3 12 7A B9         [24] 1166 	lcall	_ak820_outline_0154
      0076A6 FC               [12] 1167 	mov	r4,a
      0076A7 BC E0 00         [24] 1168 	cjne	r4,#0xe0,00445$
      0076AA                       1169 00445$:
      0076AA 40 07            [24] 1170 	jc	00115$
      0076AC 12 7A B9         [24] 1171 	lcall	_ak820_outline_0154
      0076AF 24 18            [12] 1172 	add	a,#0xff - 0xe7
      0076B1 50 09            [24] 1173 	jnc	00111$
                                   1174 ;	free result
      0076B3                       1175 00115$:
      0076B3 7B 42            [12] 1176 	mov	r3,#_process_action_PARM_2
      0076B5 7C 08            [12] 1177 	mov	r4,#(_process_action_PARM_2 >> 8)
      0076B7 12 70 1E         [24] 1178 	lcall	_ak820_outline_0118
      0076BA 70 07            [24] 1179 	jnz	00112$
      0076BC                       1180 00111$:
                                   1181 ;	quantum/action.c:548: del_owned_mods(mods);
      0076BC 8D 82            [24] 1182 	mov	dpl, r5
      0076BE 12 80 2F         [24] 1183 	lcall	_del_owned_mods
      0076C1 80 05            [24] 1184 	sjmp	00113$
      0076C3                       1185 00112$:
                                   1186 ;	quantum/action.c:550: del_owned_weak_mods(mods);
      0076C3 8D 82            [24] 1187 	mov	dpl, r5
      0076C5 12 80 4E         [24] 1188 	lcall	_del_owned_weak_mods
      0076C8                       1189 00113$:
                                   1190 ;	quantum/action.c:552: send_keyboard_report();
      0076C8 12 83 59         [24] 1191 	lcall	_send_keyboard_report
                                   1192 ;	quantum/action.c:555: } break;
      0076CB 02 78 99         [24] 1193 	ljmp	00181$
                                   1194 ;	quantum/action.c:632: case ACT_USAGE:
      0076CE                       1195 00123$:
                                   1196 ;	quantum/action.c:638: if (record->keycode >= KC_SYSTEM_POWER && record->keycode <= KC_LAUNCHPAD) {
      0076CE 74 07            [12] 1197 	mov	a,#0x07
      0076D0 12 3A 37         [24] 1198 	lcall	_ak820_outline_0031
      0076D3 12 3A 12         [24] 1199 	lcall	_ak820_outline_0010
      0076D6 C3               [12] 1200 	clr	c
      0076D7 EC               [12] 1201 	mov	a,r4
      0076D8 94 A5            [12] 1202 	subb	a,#0xa5
      0076DA ED               [12] 1203 	mov	a,r5
      0076DB 94 00            [12] 1204 	subb	a,#0x00
      0076DD 40 15            [24] 1205 	jc	00125$
      0076DF 74 C2            [12] 1206 	mov	a,#0xc2
      0076E1 9C               [12] 1207 	subb	a,r4
      0076E2 E4               [12] 1208 	clr	a
      0076E3 9D               [12] 1209 	subb	a,r5
      0076E4 40 0E            [24] 1210 	jc	00125$
                                   1211 ;	free result
                                   1212 ;	quantum/action.c:639: owned_usage_key((uint8_t)record->keycode, pressed);
      0076E6 90 0A A2         [24] 1213 	mov	dptr,#_owned_usage_key_PARM_2
      0076E9 E5 27            [12] 1214 	mov	a,_process_action_sloc0_1_0
      0076EB F0               [24] 1215 	movx	@dptr,a
      0076EC 8E 82            [24] 1216 	mov	dpl, r6
      0076EE 12 82 04         [24] 1217 	lcall	_owned_usage_key
                                   1218 ;	quantum/action.c:640: break;
      0076F1 02 78 99         [24] 1219 	ljmp	00181$
      0076F4                       1220 00125$:
                                   1221 ;	quantum/action.c:643: switch (action.usage.page) {
      0076F4 12 7A 97         [24] 1222 	lcall	_ak820_outline_0086
      0076F7 FF               [12] 1223 	mov	r7,a
      0076F8 60 08            [24] 1224 	jz	00127$
      0076FA BF 01 02         [24] 1225 	cjne	r7,#0x01,00452$
      0076FD 80 19            [24] 1226 	sjmp	00128$
      0076FF                       1227 00452$:
      0076FF 02 78 99         [24] 1228 	ljmp	00181$
                                   1229 ;	quantum/action.c:644: case PAGE_SYSTEM:
      007702                       1230 00127$:
                                   1231 ;	quantum/action.c:645: host_system_send(pressed ? action.usage.code : 0);
      007702 E5 27            [12] 1232 	mov	a,_process_action_sloc0_1_0
      007704 60 05            [24] 1233 	jz	00196$
      007706 12 7A AE         [24] 1234 	lcall	_ak820_outline_0129
      007709 80 04            [24] 1235 	sjmp	00197$
      00770B                       1236 00196$:
      00770B 7E 00            [12] 1237 	mov	r6,#0x00
      00770D 7F 00            [12] 1238 	mov	r7,#0x00
      00770F                       1239 00197$:
      00770F 12 45 CF         [24] 1240 	lcall	_ak820_outline_0116
      007712 12 70 E7         [24] 1241 	lcall	_host_system_send
                                   1242 ;	quantum/action.c:646: break;
      007715 02 78 99         [24] 1243 	ljmp	00181$
                                   1244 ;	quantum/action.c:647: case PAGE_CONSUMER:
      007718                       1245 00128$:
                                   1246 ;	quantum/action.c:648: host_consumer_send(pressed ? action.usage.code : 0);
      007718 E5 27            [12] 1247 	mov	a,_process_action_sloc0_1_0
      00771A 60 05            [24] 1248 	jz	00198$
      00771C 12 7A AE         [24] 1249 	lcall	_ak820_outline_0129
      00771F 80 04            [24] 1250 	sjmp	00199$
      007721                       1251 00198$:
      007721 7E 00            [12] 1252 	mov	r6,#0x00
      007723 7F 00            [12] 1253 	mov	r7,#0x00
      007725                       1254 00199$:
      007725 12 45 CF         [24] 1255 	lcall	_ak820_outline_0116
      007728 12 71 17         [24] 1256 	lcall	_host_consumer_send
                                   1257 ;	quantum/action.c:651: break;
      00772B 02 78 99         [24] 1258 	ljmp	00181$
                                   1259 ;	quantum/action.c:658: case ACT_LAYER: {
      00772E                       1260 00131$:
                                   1261 ;	quantum/action.c:659: uint8_t on = action.layer_bitop.on;
      00772E 90 08 43         [24] 1262 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007731 E0               [24] 1263 	movx	a,@dptr
      007732 54 03            [12] 1264 	anl	a,#0x03
      007734 90 08 46         [24] 1265 	mov	dptr,#_process_action_on_40000_680
      007737 F0               [24] 1266 	movx	@dptr,a
                                   1267 ;	quantum/action.c:662: if (on ? (pressed ? (on & ON_PRESS) : (on & ON_RELEASE)) : !pressed) {
      007738 E0               [24] 1268 	movx	a,@dptr
      007739 FF               [12] 1269 	mov	r7,a
      00773A 60 11            [24] 1270 	jz	00200$
      00773C E5 27            [12] 1271 	mov	a,_process_action_sloc0_1_0
      00773E 60 07            [24] 1272 	jz	00202$
      007740 8F 06            [24] 1273 	mov	ar6,r7
      007742 53 06 01         [24] 1274 	anl	ar6,#0x01
      007745 80 10            [24] 1275 	sjmp	00201$
      007747                       1276 00202$:
      007747 74 02            [12] 1277 	mov	a,#0x02
      007749 5F               [12] 1278 	anl	a,r7
      00774A FE               [12] 1279 	mov	r6,a
      00774B 80 0A            [24] 1280 	sjmp	00201$
      00774D                       1281 00200$:
      00774D E5 27            [12] 1282 	mov	a,_process_action_sloc0_1_0
      00774F B4 01 00         [24] 1283 	cjne	a,#0x01,00457$
      007752                       1284 00457$:
      007752 92 1E            [24] 1285 	mov  _process_action_sloc1_1_0,c
      007754 E4               [12] 1286 	clr	a
      007755 33               [12] 1287 	rlc	a
      007756 FE               [12] 1288 	mov	r6,a
      007757                       1289 00201$:
      007757 EE               [12] 1290 	mov	a,r6
      007758 70 03            [24] 1291 	jnz	00458$
      00775A 02 78 99         [24] 1292 	ljmp	00181$
      00775D                       1293 00458$:
                                   1294 ;	quantum/action.c:663: uint8_t shift = action.layer_bitop.part * 4;
      00775D 12 7A B9         [24] 1295 	lcall	_ak820_outline_0154
      007760 C4               [12] 1296 	swap	a
      007761 03               [12] 1297 	rr	a
      007762 54 07            [12] 1298 	anl	a,#0x07
      007764 25 E0            [12] 1299 	add	a,acc
      007766 25 E0            [12] 1300 	add	a,acc
      007768 FF               [12] 1301 	mov	r7,a
                                   1302 ;	quantum/action.c:664: layer_state_t bits = ((layer_state_t)action.layer_bitop.bits) << shift;
      007769 12 7A B9         [24] 1303 	lcall	_ak820_outline_0154
      00776C 54 0F            [12] 1304 	anl	a,#0x0f
      00776E FE               [12] 1305 	mov	r6,a
      00776F 8F F0            [24] 1306 	mov	b,r7
      007771 05 F0            [12] 1307 	inc	b
      007773 EE               [12] 1308 	mov	a,r6
      007774 80 02            [24] 1309 	sjmp	00460$
      007776                       1310 00459$:
      007776 25 E0            [12] 1311 	add	a,acc
      007778                       1312 00460$:
      007778 D5 F0 FB         [24] 1313 	djnz	b,00459$
      00777B FE               [12] 1314 	mov	r6,a
                                   1315 ;	quantum/action.c:665: layer_state_t mask = action.layer_bitop.xbit ? ~(((layer_state_t)0xf) << shift) : 0;
      00777C 12 7A B9         [24] 1316 	lcall	_ak820_outline_0154
      00777F 30 E4 11         [24] 1317 	jnb	acc.4,00204$
      007782 8F F0            [24] 1318 	mov	b,r7
      007784 05 F0            [12] 1319 	inc	b
      007786 74 0F            [12] 1320 	mov	a,#0x0f
      007788 80 02            [24] 1321 	sjmp	00463$
      00778A                       1322 00462$:
      00778A 25 E0            [12] 1323 	add	a,acc
      00778C                       1324 00463$:
      00778C D5 F0 FB         [24] 1325 	djnz	b,00462$
      00778F F4               [12] 1326 	cpl	a
      007790 FF               [12] 1327 	mov	r7,a
      007791 80 02            [24] 1328 	sjmp	00205$
      007793                       1329 00204$:
      007793 7F 00            [12] 1330 	mov	r7,#0x00
      007795                       1331 00205$:
                                   1332 ;	quantum/action.c:666: bits |= mask;
      007795 EE               [12] 1333 	mov	a,r6
      007796 42 07            [12] 1334 	orl	ar7,a
                                   1335 ;	quantum/action.c:667: if (!on) {
      007798 90 08 46         [24] 1336 	mov	dptr,#_process_action_on_40000_680
      00779B E0               [24] 1337 	movx	a,@dptr
      00779C 70 31            [24] 1338 	jnz	00143$
                                   1339 ;	quantum/action.c:668: switch (action.layer_bitop.op) {
      00779E 12 7A 97         [24] 1340 	lcall	_ak820_outline_0086
      0077A1 FE               [12] 1341 	mov	r6,a
      0077A2 2E               [12] 1342 	add	a,r6
                                   1343 ;	quantum/action.c:669: case OP_BIT_AND: default_layer_and(bits); break;
      0077A3 90 77 A7         [24] 1344 	mov	dptr,#00465$
      0077A6 73               [24] 1345 	jmp	@a+dptr
      0077A7                       1346 00465$:
      0077A7 80 06            [24] 1347 	sjmp	00132$
      0077A9 80 0C            [24] 1348 	sjmp	00133$
      0077AB 80 12            [24] 1349 	sjmp	00134$
      0077AD 80 18            [24] 1350 	sjmp	00135$
      0077AF                       1351 00132$:
      0077AF 8F 82            [24] 1352 	mov	dpl, r7
      0077B1 12 7B 14         [24] 1353 	lcall	_default_layer_and
      0077B4 02 78 99         [24] 1354 	ljmp	00181$
                                   1355 ;	quantum/action.c:670: case OP_BIT_OR: default_layer_or(bits); break;
      0077B7                       1356 00133$:
      0077B7 8F 82            [24] 1357 	mov	dpl, r7
      0077B9 12 7B 03         [24] 1358 	lcall	_default_layer_or
      0077BC 02 78 99         [24] 1359 	ljmp	00181$
                                   1360 ;	quantum/action.c:671: case OP_BIT_XOR: default_layer_xor(bits); break;
      0077BF                       1361 00134$:
      0077BF 8F 82            [24] 1362 	mov	dpl, r7
      0077C1 12 7B 2A         [24] 1363 	lcall	_default_layer_xor
      0077C4 02 78 99         [24] 1364 	ljmp	00181$
                                   1365 ;	quantum/action.c:672: case OP_BIT_SET: default_layer_set(bits); break;
      0077C7                       1366 00135$:
      0077C7 8F 82            [24] 1367 	mov	dpl, r7
      0077C9 12 7A F8         [24] 1368 	lcall	_default_layer_set
                                   1369 ;	quantum/action.c:673: }
      0077CC 02 78 99         [24] 1370 	ljmp	00181$
      0077CF                       1371 00143$:
                                   1372 ;	quantum/action.c:675: switch (action.layer_bitop.op) {
      0077CF 12 7A 97         [24] 1373 	lcall	_ak820_outline_0086
      0077D2 FE               [12] 1374 	mov	r6,a
      0077D3 2E               [12] 1375 	add	a,r6
                                   1376 ;	quantum/action.c:676: case OP_BIT_AND: layer_and(bits); break;
      0077D4 90 77 D8         [24] 1377 	mov	dptr,#00466$
      0077D7 73               [24] 1378 	jmp	@a+dptr
      0077D8                       1379 00466$:
      0077D8 80 06            [24] 1380 	sjmp	00137$
      0077DA 80 0C            [24] 1381 	sjmp	00138$
      0077DC 80 12            [24] 1382 	sjmp	00139$
      0077DE 80 18            [24] 1383 	sjmp	00140$
      0077E0                       1384 00137$:
      0077E0 8F 82            [24] 1385 	mov	dpl, r7
      0077E2 12 7C AD         [24] 1386 	lcall	_layer_and
      0077E5 02 78 99         [24] 1387 	ljmp	00181$
                                   1388 ;	quantum/action.c:677: case OP_BIT_OR: layer_or(bits); break;
      0077E8                       1389 00138$:
      0077E8 8F 82            [24] 1390 	mov	dpl, r7
      0077EA 12 7C 9C         [24] 1391 	lcall	_layer_or
      0077ED 02 78 99         [24] 1392 	ljmp	00181$
                                   1393 ;	quantum/action.c:678: case OP_BIT_XOR: layer_xor(bits); break;
      0077F0                       1394 00139$:
      0077F0 8F 82            [24] 1395 	mov	dpl, r7
      0077F2 12 7C C3         [24] 1396 	lcall	_layer_xor
      0077F5 02 78 99         [24] 1397 	ljmp	00181$
                                   1398 ;	quantum/action.c:679: case OP_BIT_SET: layer_state_set(bits); break;
      0077F8                       1399 00140$:
      0077F8 8F 82            [24] 1400 	mov	dpl, r7
      0077FA 12 7C 39         [24] 1401 	lcall	_layer_state_set
                                   1402 ;	quantum/action.c:683: break;
      0077FD 02 78 99         [24] 1403 	ljmp	00181$
                                   1404 ;	quantum/action.c:685: case ACT_LAYER_MODS:
      007800                       1405 00147$:
                                   1406 ;	quantum/action.c:686: if (pressed) {
      007800 E5 27            [12] 1407 	mov	a,_process_action_sloc0_1_0
      007802 60 11            [24] 1408 	jz	00149$
                                   1409 ;	quantum/action.c:687: layer_hold_on(action.layer_mods.layer);
      007804 12 7A A7         [24] 1410 	lcall	_ak820_outline_0109
      007807 F5 82            [12] 1411 	mov	dpl,a
      007809 12 7B 9A         [24] 1412 	lcall	_layer_hold_on
                                   1413 ;	quantum/action.c:688: register_mods(action.layer_mods.mods);
      00780C 12 7A 90         [24] 1414 	lcall	_ak820_outline_0076
      00780F 12 79 D3         [24] 1415 	lcall	_register_mods
      007812 02 78 99         [24] 1416 	ljmp	00181$
      007815                       1417 00149$:
                                   1418 ;	quantum/action.c:690: unregister_mods(action.layer_mods.mods);
      007815 12 7A 90         [24] 1419 	lcall	_ak820_outline_0076
      007818 12 79 E7         [24] 1420 	lcall	_unregister_mods
                                   1421 ;	quantum/action.c:691: layer_hold_off(action.layer_mods.layer);
      00781B 12 7A A7         [24] 1422 	lcall	_ak820_outline_0109
      00781E F5 82            [12] 1423 	mov	dpl,a
      007820 12 7B D2         [24] 1424 	lcall	_layer_hold_off
                                   1425 ;	quantum/action.c:693: break;
      007823 02 78 99         [24] 1426 	ljmp	00181$
                                   1427 ;	quantum/action.c:695: case ACT_LAYER_TAP_EXT:
      007826                       1428 00152$:
                                   1429 ;	quantum/action.c:696: switch (action.layer_tap.code) {
      007826 12 7A B9         [24] 1430 	lcall	_ak820_outline_0154
      007829 FF               [12] 1431 	mov	r7,a
      00782A BF F1 02         [24] 1432 	cjne	r7,#0xf1,00468$
      00782D 80 0A            [24] 1433 	sjmp	00154$
      00782F                       1434 00468$:
      00782F BF F2 02         [24] 1435 	cjne	r7,#0xf2,00469$
      007832 80 19            [24] 1436 	sjmp	00155$
      007834                       1437 00469$:
                                   1438 ;	quantum/action.c:712: momentary_layer_action:
      007834 BF F3 3B         [24] 1439 	cjne	r7,#0xf3,00160$
      007837 80 28            [24] 1440 	sjmp	00156$
      007839                       1441 00154$:
                                   1442 ;	quantum/action.c:713: pressed ? layer_hold_on(action.layer_tap.val) : layer_hold_off(action.layer_tap.val);
      007839 E5 27            [12] 1443 	mov	a,_process_action_sloc0_1_0
      00783B 60 08            [24] 1444 	jz	00206$
      00783D 12 7A 77         [24] 1445 	lcall	_ak820_outline_0039
      007840 12 7B 9A         [24] 1446 	lcall	_layer_hold_on
      007843 80 54            [24] 1447 	sjmp	00181$
      007845                       1448 00206$:
      007845 12 7A 77         [24] 1449 	lcall	_ak820_outline_0039
      007848 12 7B D2         [24] 1450 	lcall	_layer_hold_off
                                   1451 ;	quantum/action.c:714: break;
                                   1452 ;	quantum/action.c:715: case OP_OFF_ON:
      00784B 80 4C            [24] 1453 	sjmp	00181$
      00784D                       1454 00155$:
                                   1455 ;	quantum/action.c:716: pressed ? layer_off(action.layer_tap.val) : layer_on(action.layer_tap.val);
      00784D E5 27            [12] 1456 	mov	a,_process_action_sloc0_1_0
      00784F 60 08            [24] 1457 	jz	00208$
      007851 12 7A 77         [24] 1458 	lcall	_ak820_outline_0039
      007854 12 7C 7E         [24] 1459 	lcall	_layer_off
      007857 80 40            [24] 1460 	sjmp	00181$
      007859                       1461 00208$:
      007859 12 7A 77         [24] 1462 	lcall	_ak820_outline_0039
      00785C 12 7C 63         [24] 1463 	lcall	_layer_on
                                   1464 ;	quantum/action.c:717: break;
                                   1465 ;	quantum/action.c:718: case OP_SET_CLEAR:
      00785F 80 38            [24] 1466 	sjmp	00181$
      007861                       1467 00156$:
                                   1468 ;	quantum/action.c:719: pressed ? layer_move(action.layer_tap.val) : layer_clear();
      007861 E5 27            [12] 1469 	mov	a,_process_action_sloc0_1_0
      007863 60 08            [24] 1470 	jz	00210$
      007865 12 7A 77         [24] 1471 	lcall	_ak820_outline_0039
      007868 12 7C 4D         [24] 1472 	lcall	_layer_move
      00786B 80 2C            [24] 1473 	sjmp	00181$
      00786D                       1474 00210$:
      00786D 12 7C 47         [24] 1475 	lcall	_layer_clear
                                   1476 ;	quantum/action.c:720: break;
                                   1477 ;	quantum/action.c:766: default:
      007870 80 27            [24] 1478 	sjmp	00181$
      007872                       1479 00160$:
                                   1480 ;	quantum/action.c:773: if (pressed) {
      007872 E5 27            [12] 1481 	mov	a,_process_action_sloc0_1_0
      007874 60 08            [24] 1482 	jz	00163$
                                   1483 ;	quantum/action.c:775: register_code(action.layer_tap.code);
      007876 12 7A 90         [24] 1484 	lcall	_ak820_outline_0076
      007879 12 78 B0         [24] 1485 	lcall	_register_code
                                   1486 ;	quantum/action.c:777: ac_dprintf("KEYMAP_TAP_KEY: Tap: unregister_code\n");
      00787C 80 1B            [24] 1487 	sjmp	00181$
      00787E                       1488 00163$:
                                   1489 ;	quantum/action.c:778: if (action.layer_tap.code == KC_CAPS) {
      00787E 12 7A B9         [24] 1490 	lcall	_ak820_outline_0154
      007881 FF               [12] 1491 	mov	r7,a
      007882 BF 39 0E         [24] 1492 	cjne	r7,#0x39,00175$
                                   1493 ;	quantum/action.c:779: wait_ms(TAP_HOLD_CAPS_DELAY);
      007885 7F 50            [12] 1494 	mov	r7,#0x50
      007887                       1495 00187$:
      007887 EF               [12] 1496 	mov	a,r7
      007888 60 09            [24] 1497 	jz	00175$
      00788A 90 00 01         [24] 1498 	mov	dptr,#0x0001
      00788D 12 5B D6         [24] 1499 	lcall	_mDelaymS
      007890 1F               [12] 1500 	dec	r7
                                   1501 ;	quantum/action.c:781: wait_ms(TAP_CODE_DELAY);
      007891 80 F4            [24] 1502 	sjmp	00187$
      007893                       1503 00175$:
                                   1504 ;	quantum/action.c:783: unregister_code(action.layer_tap.code);
      007893 12 7A 90         [24] 1505 	lcall	_ak820_outline_0076
      007896 12 79 1D         [24] 1506 	lcall	_unregister_code
                                   1507 ;	quantum/action.c:866: }
      007899                       1508 00181$:
                                   1509 ;	quantum/action.c:887: switch (action.kind.id) {
      007899 90 08 43         [24] 1510 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      00789C E0               [24] 1511 	movx	a,@dptr
      00789D C4               [12] 1512 	swap	a
      00789E 54 0F            [12] 1513 	anl	a,#0x0f
      0078A0 FF               [12] 1514 	mov	r7,a
      0078A1 BF 08 02         [24] 1515 	cjne	r7,#0x08,00478$
      0078A4 80 03            [24] 1516 	sjmp	00183$
      0078A6                       1517 00478$:
      0078A6 BF 09 06         [24] 1518 	cjne	r7,#0x09,00192$
                                   1519 ;	quantum/action.c:889: case ACT_LAYER_MODS:
      0078A9                       1520 00183$:
                                   1521 ;	quantum/action.c:894: led_set(host_keyboard_leds());
      0078A9 12 70 4C         [24] 1522 	lcall	_host_keyboard_leds
                                   1523 ;	quantum/action.c:898: }
                                   1524 ;	quantum/action.c:951: }
      0078AC 02 9A B5         [24] 1525 	ljmp	_led_set
      0078AF                       1526 00192$:
      0078AF 22               [24] 1527 	ret
                                   1528 ;------------------------------------------------------------
                                   1529 ;Allocation info for local variables in function 'register_code'
                                   1530 ;------------------------------------------------------------
                                   1531 ;code          Allocated with name '_register_code_code_10000_714'
                                   1532 ;------------------------------------------------------------
                                   1533 ;	quantum/action.c:957: __attribute__((weak)) void register_code(uint8_t code) {
                                   1534 ;	-----------------------------------------
                                   1535 ;	 function register_code
                                   1536 ;	-----------------------------------------
      0078B0                       1537 _register_code:
      0078B0 E5 82            [12] 1538 	mov	a,dpl
      0078B2 90 08 47         [24] 1539 	mov	dptr,#_register_code_code_10000_714
      0078B5 F0               [24] 1540 	movx	@dptr,a
                                   1541 ;	quantum/action.c:958: if (code == KC_NO) {
      0078B6 E0               [24] 1542 	movx	a,@dptr
      0078B7 FF               [12] 1543 	mov	r7,a
      0078B8 70 01            [24] 1544 	jnz	00123$
                                   1545 ;	quantum/action.c:959: return;
      0078BA 22               [24] 1546 	ret
      0078BB                       1547 00123$:
                                   1548 ;	quantum/action.c:994: } else if (IS_BASIC_KEYCODE(code)) {
      0078BB BF 04 00         [24] 1549 	cjne	r7,#0x04,00186$
      0078BE                       1550 00186$:
      0078BE 40 12            [24] 1551 	jc	00119$
      0078C0 EF               [12] 1552 	mov	a,r7
      0078C1 24 5B            [12] 1553 	add	a,#0xff - 0xa4
      0078C3 40 0D            [24] 1554 	jc	00119$
                                   1555 ;	free result
                                   1556 ;	quantum/action.c:999: if (!add_owned_key(code)) return;
      0078C5 8F 82            [24] 1557 	mov	dpl, r7
      0078C7 12 80 C3         [24] 1558 	lcall	_add_owned_key
      0078CA E5 82            [12] 1559 	mov	a, dpl
      0078CC 70 01            [24] 1560 	jnz	00104$
      0078CE 22               [24] 1561 	ret
      0078CF                       1562 00104$:
                                   1563 ;	quantum/action.c:1013: send_keyboard_report();
      0078CF 02 83 59         [24] 1564 	ljmp	_send_keyboard_report
      0078D2                       1565 00119$:
                                   1566 ;	quantum/action.c:1014: } else if (IS_MODIFIER_KEYCODE(code)) {
      0078D2 12 7A BE         [24] 1567 	lcall	_ak820_outline_0162
      0078D5 BF E0 00         [24] 1568 	cjne	r7,#0xe0,00190$
      0078D8                       1569 00190$:
      0078D8 40 1A            [24] 1570 	jc	00115$
      0078DA EF               [12] 1571 	mov	a,r7
      0078DB 24 18            [12] 1572 	add	a,#0xff - 0xe7
      0078DD 40 15            [24] 1573 	jc	00115$
                                   1574 ;	free result
                                   1575 ;	quantum/action.c:1015: add_owned_mods(MOD_BIT(code));
      0078DF 74 07            [12] 1576 	mov	a,#0x07
      0078E1 5F               [12] 1577 	anl	a,r7
      0078E2 12 7A 89         [24] 1578 	lcall	_ak820_outline_0063
      0078E5 80 02            [24] 1579 	sjmp	00194$
      0078E7                       1580 00193$:
      0078E7 25 E0            [12] 1581 	add	a,acc
      0078E9                       1582 00194$:
      0078E9 D5 F0 FB         [24] 1583 	djnz	b,00193$
      0078EC F5 82            [12] 1584 	mov	dpl,a
      0078EE 12 80 1F         [24] 1585 	lcall	_add_owned_mods
                                   1586 ;	quantum/action.c:1016: send_keyboard_report();
      0078F1 02 83 59         [24] 1587 	ljmp	_send_keyboard_report
      0078F4                       1588 00115$:
                                   1589 ;	quantum/action.c:1019: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      0078F4 12 7A BE         [24] 1590 	lcall	_ak820_outline_0162
      0078F7 BF A5 00         [24] 1591 	cjne	r7,#0xa5,00195$
      0078FA                       1592 00195$:
      0078FA 40 05            [24] 1593 	jc	00113$
      0078FC EF               [12] 1594 	mov	a,r7
      0078FD 24 58            [12] 1595 	add	a,#0xff - 0xa7
      0078FF 50 0D            [24] 1596 	jnc	00108$
                                   1597 ;	free result
      007901                       1598 00113$:
      007901 12 7A BE         [24] 1599 	lcall	_ak820_outline_0162
      007904 BF A8 00         [24] 1600 	cjne	r7,#0xa8,00198$
      007907                       1601 00198$:
      007907 40 13            [24] 1602 	jc	00125$
      007909 EF               [12] 1603 	mov	a,r7
      00790A 24 3D            [12] 1604 	add	a,#0xff - 0xc2
      00790C 40 0E            [24] 1605 	jc	00125$
                                   1606 ;	free result
      00790E                       1607 00108$:
                                   1608 ;	quantum/action.c:1021: owned_usage_key(code, true);
      00790E 12 7A BE         [24] 1609 	lcall	_ak820_outline_0162
      007911 90 0A A2         [24] 1610 	mov	dptr,#_owned_usage_key_PARM_2
      007914 74 01            [12] 1611 	mov	a,#0x01
      007916 F0               [24] 1612 	movx	@dptr,a
      007917 8F 82            [24] 1613 	mov	dpl, r7
                                   1614 ;	quantum/action.c:1029: register_mouse(code, true);
                                   1615 ;	quantum/action.c:1031: }
      007919 02 82 04         [24] 1616 	ljmp	_owned_usage_key
      00791C                       1617 00125$:
      00791C 22               [24] 1618 	ret
                                   1619 ;------------------------------------------------------------
                                   1620 ;Allocation info for local variables in function 'unregister_code'
                                   1621 ;------------------------------------------------------------
                                   1622 ;code          Allocated with name '_unregister_code_code_10000_728'
                                   1623 ;------------------------------------------------------------
                                   1624 ;	quantum/action.c:1037: __attribute__((weak)) void unregister_code(uint8_t code) {
                                   1625 ;	-----------------------------------------
                                   1626 ;	 function unregister_code
                                   1627 ;	-----------------------------------------
      00791D                       1628 _unregister_code:
      00791D E5 82            [12] 1629 	mov	a,dpl
      00791F 90 08 48         [24] 1630 	mov	dptr,#_unregister_code_code_10000_728
      007922 F0               [24] 1631 	movx	@dptr,a
                                   1632 ;	quantum/action.c:1038: if (code == KC_NO) {
      007923 E0               [24] 1633 	movx	a,@dptr
      007924 FF               [12] 1634 	mov	r7,a
      007925 70 01            [24] 1635 	jnz	00121$
                                   1636 ;	quantum/action.c:1039: return;
      007927 22               [24] 1637 	ret
      007928                       1638 00121$:
                                   1639 ;	quantum/action.c:1071: } else if (IS_BASIC_KEYCODE(code)) {
      007928 BF 04 00         [24] 1640 	cjne	r7,#0x04,00184$
      00792B                       1641 00184$:
      00792B 40 12            [24] 1642 	jc	00117$
      00792D EF               [12] 1643 	mov	a,r7
      00792E 24 5B            [12] 1644 	add	a,#0xff - 0xa4
      007930 40 0D            [24] 1645 	jc	00117$
                                   1646 ;	free result
                                   1647 ;	quantum/action.c:1073: if (!del_owned_key(code)) return;
      007932 8F 82            [24] 1648 	mov	dpl, r7
      007934 12 81 3D         [24] 1649 	lcall	_del_owned_key
      007937 E5 82            [12] 1650 	mov	a, dpl
      007939 70 01            [24] 1651 	jnz	00102$
      00793B 22               [24] 1652 	ret
      00793C                       1653 00102$:
                                   1654 ;	quantum/action.c:1080: send_keyboard_report();
      00793C 02 83 59         [24] 1655 	ljmp	_send_keyboard_report
      00793F                       1656 00117$:
                                   1657 ;	quantum/action.c:1081: } else if (IS_MODIFIER_KEYCODE(code)) {
      00793F 12 7A C4         [24] 1658 	lcall	_ak820_outline_0163
      007942 BF E0 00         [24] 1659 	cjne	r7,#0xe0,00188$
      007945                       1660 00188$:
      007945 40 1A            [24] 1661 	jc	00113$
      007947 EF               [12] 1662 	mov	a,r7
      007948 24 18            [12] 1663 	add	a,#0xff - 0xe7
      00794A 40 15            [24] 1664 	jc	00113$
                                   1665 ;	free result
                                   1666 ;	quantum/action.c:1082: del_owned_mods(MOD_BIT(code));
      00794C 74 07            [12] 1667 	mov	a,#0x07
      00794E 5F               [12] 1668 	anl	a,r7
      00794F 12 7A 89         [24] 1669 	lcall	_ak820_outline_0063
      007952 80 02            [24] 1670 	sjmp	00192$
      007954                       1671 00191$:
      007954 25 E0            [12] 1672 	add	a,acc
      007956                       1673 00192$:
      007956 D5 F0 FB         [24] 1674 	djnz	b,00191$
      007959 F5 82            [12] 1675 	mov	dpl,a
      00795B 12 80 2F         [24] 1676 	lcall	_del_owned_mods
                                   1677 ;	quantum/action.c:1083: send_keyboard_report();
      00795E 02 83 59         [24] 1678 	ljmp	_send_keyboard_report
      007961                       1679 00113$:
                                   1680 ;	quantum/action.c:1086: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      007961 12 7A C4         [24] 1681 	lcall	_ak820_outline_0163
      007964 BF A5 00         [24] 1682 	cjne	r7,#0xa5,00193$
      007967                       1683 00193$:
      007967 40 05            [24] 1684 	jc	00111$
      007969 EF               [12] 1685 	mov	a,r7
      00796A 24 58            [12] 1686 	add	a,#0xff - 0xa7
      00796C 50 0D            [24] 1687 	jnc	00106$
                                   1688 ;	free result
      00796E                       1689 00111$:
      00796E 12 7A C4         [24] 1690 	lcall	_ak820_outline_0163
      007971 BF A8 00         [24] 1691 	cjne	r7,#0xa8,00196$
      007974                       1692 00196$:
      007974 40 12            [24] 1693 	jc	00123$
      007976 EF               [12] 1694 	mov	a,r7
      007977 24 3D            [12] 1695 	add	a,#0xff - 0xc2
      007979 40 0D            [24] 1696 	jc	00123$
                                   1697 ;	free result
      00797B                       1698 00106$:
                                   1699 ;	quantum/action.c:1088: owned_usage_key(code, false);
      00797B 12 7A C4         [24] 1700 	lcall	_ak820_outline_0163
      00797E 90 0A A2         [24] 1701 	mov	dptr,#_owned_usage_key_PARM_2
      007981 E4               [12] 1702 	clr	a
      007982 F0               [24] 1703 	movx	@dptr,a
      007983 8F 82            [24] 1704 	mov	dpl, r7
                                   1705 ;	quantum/action.c:1096: register_mouse(code, false);
                                   1706 ;	quantum/action.c:1098: }
      007985 02 82 04         [24] 1707 	ljmp	_owned_usage_key
      007988                       1708 00123$:
      007988 22               [24] 1709 	ret
                                   1710 ;------------------------------------------------------------
                                   1711 ;Allocation info for local variables in function 'tap_code_delay'
                                   1712 ;------------------------------------------------------------
                                   1713 ;delay         Allocated with name '_tap_code_delay_PARM_2'
                                   1714 ;code          Allocated with name '_tap_code_delay_code_10000_741'
                                   1715 ;i             Allocated with name '_tap_code_delay_i_20000_743'
                                   1716 ;i             Allocated with name '_tap_code_delay_i_50000_746'
                                   1717 ;------------------------------------------------------------
                                   1718 ;	quantum/action.c:1105: __attribute__((weak)) void tap_code_delay(uint8_t code, uint16_t delay) {
                                   1719 ;	-----------------------------------------
                                   1720 ;	 function tap_code_delay
                                   1721 ;	-----------------------------------------
      007989                       1722 _tap_code_delay:
      007989 E5 82            [12] 1723 	mov	a,dpl
      00798B 90 08 4B         [24] 1724 	mov	dptr,#_tap_code_delay_code_10000_741
      00798E F0               [24] 1725 	movx	@dptr,a
                                   1726 ;	quantum/action.c:1106: register_code(code);
      00798F E0               [24] 1727 	movx	a,@dptr
      007990 FF               [12] 1728 	mov	r7,a
      007991 F5 82            [12] 1729 	mov	dpl,a
      007993 C0 07            [24] 1730 	push	ar7
      007995 12 78 B0         [24] 1731 	lcall	_register_code
      007998 D0 07            [24] 1732 	pop	ar7
                                   1733 ;	quantum/action.c:1107: for (uint16_t i = delay; i > 0; i--) {
      00799A 90 08 49         [24] 1734 	mov	dptr,#_tap_code_delay_PARM_2
      00799D 12 45 BD         [24] 1735 	lcall	_ak820_outline_0093
      0079A0                       1736 00110$:
      0079A0 ED               [12] 1737 	mov	a,r5
      0079A1 4E               [12] 1738 	orl	a,r6
      0079A2 60 0D            [24] 1739 	jz	00105$
                                   1740 ;	quantum/action.c:1108: wait_ms(1);
      0079A4 90 00 01         [24] 1741 	mov	dptr,#0x0001
      0079A7 12 5B D6         [24] 1742 	lcall	_mDelaymS
                                   1743 ;	quantum/action.c:1107: for (uint16_t i = delay; i > 0; i--) {
      0079AA 1D               [12] 1744 	dec	r5
      0079AB BD FF 01         [24] 1745 	cjne	r5,#0xff,00141$
      0079AE 1E               [12] 1746 	dec	r6
      0079AF                       1747 00141$:
      0079AF 80 EF            [24] 1748 	sjmp	00110$
      0079B1                       1749 00105$:
                                   1750 ;	quantum/action.c:1110: unregister_code(code);
      0079B1 8F 82            [24] 1751 	mov	dpl, r7
                                   1752 ;	quantum/action.c:1111: }
      0079B3 02 79 1D         [24] 1753 	ljmp	_unregister_code
                                   1754 ;------------------------------------------------------------
                                   1755 ;Allocation info for local variables in function 'tap_code'
                                   1756 ;------------------------------------------------------------
                                   1757 ;code          Allocated with name '_tap_code_code_10000_748'
                                   1758 ;------------------------------------------------------------
                                   1759 ;	quantum/action.c:1117: __attribute__((weak)) void tap_code(uint8_t code) {
                                   1760 ;	-----------------------------------------
                                   1761 ;	 function tap_code
                                   1762 ;	-----------------------------------------
      0079B6                       1763 _tap_code:
      0079B6 E5 82            [12] 1764 	mov	a,dpl
      0079B8 90 08 4C         [24] 1765 	mov	dptr,#_tap_code_code_10000_748
      0079BB F0               [24] 1766 	movx	@dptr,a
                                   1767 ;	quantum/action.c:1118: tap_code_delay(code, code == KC_CAPS ? QS_tap_hold_caps_delay : QS_tap_code_delay);
      0079BC E0               [24] 1768 	movx	a,@dptr
      0079BD FF               [12] 1769 	mov	r7,a
      0079BE BF 39 04         [24] 1770 	cjne	r7,#0x39,00103$
      0079C1 7E 50            [12] 1771 	mov	r6,#0x50
      0079C3 80 02            [24] 1772 	sjmp	00104$
      0079C5                       1773 00103$:
      0079C5 7E 00            [12] 1774 	mov	r6,#0x00
      0079C7                       1775 00104$:
      0079C7 90 08 49         [24] 1776 	mov	dptr,#_tap_code_delay_PARM_2
      0079CA EE               [12] 1777 	mov	a,r6
      0079CB 12 3A A6         [24] 1778 	lcall	_ak820_outline_0123
      0079CE 8F 82            [24] 1779 	mov	dpl, r7
                                   1780 ;	quantum/action.c:1119: }
      0079D0 02 79 89         [24] 1781 	ljmp	_tap_code_delay
                                   1782 ;------------------------------------------------------------
                                   1783 ;Allocation info for local variables in function 'register_mods'
                                   1784 ;------------------------------------------------------------
                                   1785 ;mods          Allocated with name '_register_mods_mods_10000_750'
                                   1786 ;------------------------------------------------------------
                                   1787 ;	quantum/action.c:1125: __attribute__((weak)) void register_mods(uint8_t mods) {
                                   1788 ;	-----------------------------------------
                                   1789 ;	 function register_mods
                                   1790 ;	-----------------------------------------
      0079D3                       1791 _register_mods:
      0079D3 E5 82            [12] 1792 	mov	a,dpl
      0079D5 90 08 4D         [24] 1793 	mov	dptr,#_register_mods_mods_10000_750
      0079D8 F0               [24] 1794 	movx	@dptr,a
                                   1795 ;	quantum/action.c:1126: if (mods) {
      0079D9 E0               [24] 1796 	movx	a,@dptr
      0079DA FF               [12] 1797 	mov	r7,a
      0079DB E0               [24] 1798 	movx	a,@dptr
      0079DC 60 08            [24] 1799 	jz	00103$
                                   1800 ;	quantum/action.c:1127: add_owned_mods(mods);
      0079DE 8F 82            [24] 1801 	mov	dpl, r7
      0079E0 12 80 1F         [24] 1802 	lcall	_add_owned_mods
                                   1803 ;	quantum/action.c:1128: send_keyboard_report();
                                   1804 ;	quantum/action.c:1130: }
      0079E3 02 83 59         [24] 1805 	ljmp	_send_keyboard_report
      0079E6                       1806 00103$:
      0079E6 22               [24] 1807 	ret
                                   1808 ;------------------------------------------------------------
                                   1809 ;Allocation info for local variables in function 'unregister_mods'
                                   1810 ;------------------------------------------------------------
                                   1811 ;mods          Allocated with name '_unregister_mods_mods_10000_754'
                                   1812 ;------------------------------------------------------------
                                   1813 ;	quantum/action.c:1136: __attribute__((weak)) void unregister_mods(uint8_t mods) {
                                   1814 ;	-----------------------------------------
                                   1815 ;	 function unregister_mods
                                   1816 ;	-----------------------------------------
      0079E7                       1817 _unregister_mods:
      0079E7 E5 82            [12] 1818 	mov	a,dpl
      0079E9 90 08 4E         [24] 1819 	mov	dptr,#_unregister_mods_mods_10000_754
      0079EC F0               [24] 1820 	movx	@dptr,a
                                   1821 ;	quantum/action.c:1137: if (mods) {
      0079ED E0               [24] 1822 	movx	a,@dptr
      0079EE FF               [12] 1823 	mov	r7,a
      0079EF E0               [24] 1824 	movx	a,@dptr
      0079F0 60 08            [24] 1825 	jz	00103$
                                   1826 ;	quantum/action.c:1138: del_owned_mods(mods);
      0079F2 8F 82            [24] 1827 	mov	dpl, r7
      0079F4 12 80 2F         [24] 1828 	lcall	_del_owned_mods
                                   1829 ;	quantum/action.c:1139: send_keyboard_report();
                                   1830 ;	quantum/action.c:1141: }
      0079F7 02 83 59         [24] 1831 	ljmp	_send_keyboard_report
      0079FA                       1832 00103$:
      0079FA 22               [24] 1833 	ret
                                   1834 ;------------------------------------------------------------
                                   1835 ;Allocation info for local variables in function 'register_weak_mods'
                                   1836 ;------------------------------------------------------------
                                   1837 ;mods          Allocated with name '_register_weak_mods_mods_10000_758'
                                   1838 ;------------------------------------------------------------
                                   1839 ;	quantum/action.c:1147: __attribute__((weak)) void register_weak_mods(uint8_t mods) {
                                   1840 ;	-----------------------------------------
                                   1841 ;	 function register_weak_mods
                                   1842 ;	-----------------------------------------
      0079FB                       1843 _register_weak_mods:
      0079FB E5 82            [12] 1844 	mov	a,dpl
      0079FD 90 08 4F         [24] 1845 	mov	dptr,#_register_weak_mods_mods_10000_758
      007A00 F0               [24] 1846 	movx	@dptr,a
                                   1847 ;	quantum/action.c:1148: if (mods) {
      007A01 E0               [24] 1848 	movx	a,@dptr
      007A02 FF               [12] 1849 	mov	r7,a
      007A03 E0               [24] 1850 	movx	a,@dptr
      007A04 60 08            [24] 1851 	jz	00103$
                                   1852 ;	quantum/action.c:1149: add_owned_weak_mods(mods);
      007A06 8F 82            [24] 1853 	mov	dpl, r7
      007A08 12 80 3E         [24] 1854 	lcall	_add_owned_weak_mods
                                   1855 ;	quantum/action.c:1150: send_keyboard_report();
                                   1856 ;	quantum/action.c:1152: }
      007A0B 02 83 59         [24] 1857 	ljmp	_send_keyboard_report
      007A0E                       1858 00103$:
      007A0E 22               [24] 1859 	ret
                                   1860 ;------------------------------------------------------------
                                   1861 ;Allocation info for local variables in function 'unregister_weak_mods'
                                   1862 ;------------------------------------------------------------
                                   1863 ;mods          Allocated with name '_unregister_weak_mods_mods_10000_762'
                                   1864 ;------------------------------------------------------------
                                   1865 ;	quantum/action.c:1158: __attribute__((weak)) void unregister_weak_mods(uint8_t mods) {
                                   1866 ;	-----------------------------------------
                                   1867 ;	 function unregister_weak_mods
                                   1868 ;	-----------------------------------------
      007A0F                       1869 _unregister_weak_mods:
      007A0F E5 82            [12] 1870 	mov	a,dpl
      007A11 90 08 50         [24] 1871 	mov	dptr,#_unregister_weak_mods_mods_10000_762
      007A14 F0               [24] 1872 	movx	@dptr,a
                                   1873 ;	quantum/action.c:1159: if (mods) {
      007A15 E0               [24] 1874 	movx	a,@dptr
      007A16 FF               [12] 1875 	mov	r7,a
      007A17 E0               [24] 1876 	movx	a,@dptr
      007A18 60 08            [24] 1877 	jz	00103$
                                   1878 ;	quantum/action.c:1160: del_owned_weak_mods(mods);
      007A1A 8F 82            [24] 1879 	mov	dpl, r7
      007A1C 12 80 4E         [24] 1880 	lcall	_del_owned_weak_mods
                                   1881 ;	quantum/action.c:1161: send_keyboard_report();
                                   1882 ;	quantum/action.c:1163: }
      007A1F 02 83 59         [24] 1883 	ljmp	_send_keyboard_report
      007A22                       1884 00103$:
      007A22 22               [24] 1885 	ret
                                   1886 ;------------------------------------------------------------
                                   1887 ;Allocation info for local variables in function 'clear_keyboard'
                                   1888 ;------------------------------------------------------------
                                   1889 ;	quantum/action.c:1169: void clear_keyboard(void) {
                                   1890 ;	-----------------------------------------
                                   1891 ;	 function clear_keyboard
                                   1892 ;	-----------------------------------------
      007A23                       1893 _clear_keyboard:
                                   1894 ;	quantum/action.c:1170: clear_mods();
      007A23 12 83 D4         [24] 1895 	lcall	_clear_mods
                                   1896 ;	quantum/action.c:1171: clear_keyboard_but_mods();
                                   1897 ;	quantum/action.c:1172: }
      007A26 02 7A 29         [24] 1898 	ljmp	_clear_keyboard_but_mods
                                   1899 ;------------------------------------------------------------
                                   1900 ;Allocation info for local variables in function 'clear_keyboard_but_mods'
                                   1901 ;------------------------------------------------------------
                                   1902 ;	quantum/action.c:1178: void clear_keyboard_but_mods(void) {
                                   1903 ;	-----------------------------------------
                                   1904 ;	 function clear_keyboard_but_mods
                                   1905 ;	-----------------------------------------
      007A29                       1906 _clear_keyboard_but_mods:
                                   1907 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007A29 90 0D AF         [24] 1908 	mov	dptr,#_actual_keyboard_report
      007A2C 12 73 0B         [24] 1909 	lcall	_clear_keys_from_report
                                   1910 ;	quantum/action.c:1180: clear_keyboard_but_mods_and_keys();
                                   1911 ;	quantum/action.c:1181: }
      007A2F 02 7A 32         [24] 1912 	ljmp	_clear_keyboard_but_mods_and_keys
                                   1913 ;------------------------------------------------------------
                                   1914 ;Allocation info for local variables in function 'clear_keyboard_but_mods_and_keys'
                                   1915 ;------------------------------------------------------------
                                   1916 ;	quantum/action.c:1187: void clear_keyboard_but_mods_and_keys(void) {
                                   1917 ;	-----------------------------------------
                                   1918 ;	 function clear_keyboard_but_mods_and_keys
                                   1919 ;	-----------------------------------------
      007A32                       1920 _clear_keyboard_but_mods_and_keys:
                                   1921 ;	quantum/action.c:1189: ak820_tapping_cancel();
      007A32 12 4A 04         [24] 1922 	lcall	_ak820_tapping_cancel
                                   1923 ;	quantum/action.c:1203: ak820_autoshift_cancel();
      007A35 12 33 45         [24] 1924 	lcall	_ak820_autoshift_cancel
                                   1925 ;	quantum/action.c:1206: ak820_oneshot_cancel();
      007A38 12 2E A4         [24] 1926 	lcall	_ak820_oneshot_cancel
                                   1927 ;	quantum/action.c:1209: ak820_combo_cancel();
      007A3B 12 37 6D         [24] 1928 	lcall	_ak820_combo_cancel
                                   1929 ;	quantum/action.c:1212: repeat_key_cancel();
      007A3E 12 A3 A0         [24] 1930 	lcall	_repeat_key_cancel
                                   1931 ;	quantum/action.c:1214: clear_owned_mods();
      007A41 12 80 5E         [24] 1932 	lcall	_clear_owned_mods
                                   1933 ;	quantum/action.c:1215: clear_owned_keys();
      007A44 12 80 96         [24] 1934 	lcall	_clear_owned_keys
                                   1935 ;	quantum/action.c:1216: clear_owned_usages();
      007A47 12 81 CC         [24] 1936 	lcall	_clear_owned_usages
                                   1937 ;	quantum/action.c:1217: layer_hold_clear();
      007A4A 12 7C 0A         [24] 1938 	lcall	_layer_hold_clear
                                   1939 ;	quantum/action.c:1219: clear_macro_tri_layer();
      007A4D 12 9F 43         [24] 1940 	lcall	_clear_macro_tri_layer
                                   1941 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007A50 90 0D AF         [24] 1942 	mov	dptr,#_actual_keyboard_report
      007A53 12 73 0B         [24] 1943 	lcall	_clear_keys_from_report
                                   1944 ;	quantum/action.c:1224: host_system_send(0);
      007A56 90 00 00         [24] 1945 	mov	dptr,#0x0000
      007A59 12 70 E7         [24] 1946 	lcall	_host_system_send
                                   1947 ;	quantum/action.c:1225: host_consumer_send(0);
      007A5C 90 00 00         [24] 1948 	mov	dptr,#0x0000
      007A5F 12 71 17         [24] 1949 	lcall	_host_consumer_send
                                   1950 ;	quantum/action.c:1227: clear_weak_mods();
      007A62 12 84 09         [24] 1951 	lcall	_clear_weak_mods
                                   1952 ;	quantum/action.c:1228: send_keyboard_report();
                                   1953 ;	quantum/action.c:1236: }
      007A65 02 83 59         [24] 1954 	ljmp	_send_keyboard_report
                                   1955 ;------------------------------------------------------------
                                   1956 ;Allocation info for local variables in function 'is_tap_record'
                                   1957 ;------------------------------------------------------------
                                   1958 ;record        Allocated with name '_is_tap_record_record_10000_778'
                                   1959 ;action        Allocated with name '_is_tap_record_action_10001_782'
                                   1960 ;------------------------------------------------------------
                                   1961 ;	quantum/action.c:1242: bool is_tap_record(keyrecord_t *record) {
                                   1962 ;	-----------------------------------------
                                   1963 	.area CSEG    (CODE)
                                   1964 	.area CONST   (CODE)
                                   1965 	.area XINIT   (CODE)
      00C310                       1966 __xinit__disable_action_cache:
      00C310 00                    1967 	.db #0x00	;  0
                                   1968 	.area CABS    (ABS,CODE)
                                   1969 
                                   1970 ; Experimental exact instruction outlining.
                                   1971 	.globl _ak820_outline_0004
                                   1972 	.globl _ak820_outline_0009
                                   1973 	.globl _ak820_outline_0010
                                   1974 	.globl _ak820_outline_0011
                                   1975 	.globl _ak820_outline_0012
                                   1976 	.globl _ak820_outline_0016
                                   1977 	.globl _ak820_outline_0017
                                   1978 	.globl _ak820_outline_0020
                                   1979 	.globl _ak820_outline_0031
                                   1980 	.globl _ak820_outline_0039
                                   1981 	.globl _ak820_outline_0050
                                   1982 	.globl _ak820_outline_0051
                                   1983 	.globl _ak820_outline_0055
                                   1984 	.globl _ak820_outline_0058
                                   1985 	.globl _ak820_outline_0063
                                   1986 	.globl _ak820_outline_0071
                                   1987 	.globl _ak820_outline_0076
                                   1988 	.globl _ak820_outline_0086
                                   1989 	.globl _ak820_outline_0093
                                   1990 	.globl _ak820_outline_0103
                                   1991 	.globl _ak820_outline_0104
                                   1992 	.globl _ak820_outline_0106
                                   1993 	.globl _ak820_outline_0107
                                   1994 	.globl _ak820_outline_0109
                                   1995 	.globl _ak820_outline_0116
                                   1996 	.globl _ak820_outline_0117
                                   1997 	.globl _ak820_outline_0118
                                   1998 	.globl _ak820_outline_0123
                                   1999 	.globl _ak820_outline_0129
                                   2000 	.globl _ak820_outline_0139
                                   2001 	.globl _ak820_outline_0140
                                   2002 	.globl _ak820_outline_0145
                                   2003 	.globl _ak820_outline_0154
                                   2004 	.globl _ak820_outline_0162
                                   2005 	.globl _ak820_outline_0163
                                   2006 	.globl _ak820_outline_0166
                                   2007 	.globl _ak820_outline_0184
                                   2008 
                                   2009 	.area CSEG (CODE)
                                   2010 ; function ak820_outline_0020
      007A68                       2011 _ak820_outline_0020:
      007A68 8E 82            [24] 2012 	mov	dpl,r6
      007A6A 8F 83            [24] 2013 	mov	dph,r7
      007A6C A3               [24] 2014 	inc	dptr
      007A6D E0               [24] 2015 	movx	a,@dptr
      007A6E FC               [12] 2016 	mov	r4,a
      007A6F 7D 00            [12] 2017 	mov	r5,#0x00
      007A71 8E 82            [24] 2018 	mov	dpl,r6
      007A73 8F 83            [24] 2019 	mov	dph,r7
      007A75 E0               [24] 2020 	movx	a,@dptr
      007A76 22               [24] 2021 	ret
                                   2022 
                                   2023 	.area CSEG (CODE)
                                   2024 ; function ak820_outline_0039
      007A77                       2025 _ak820_outline_0039:
      007A77 90 08 43         [24] 2026 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007A7A E0               [24] 2027 	movx	a,@dptr
      007A7B 54 1F            [12] 2028 	anl	a,#0x1f
      007A7D F5 82            [12] 2029 	mov	dpl,a
      007A7F 22               [24] 2030 	ret
                                   2031 
                                   2032 	.area CSEG (CODE)
                                   2033 ; function ak820_outline_0050
      007A80                       2034 _ak820_outline_0050:
      007A80 A3               [24] 2035 	inc	dptr
      007A81 F0               [24] 2036 	movx	@dptr,a
      007A82 E4               [12] 2037 	clr	a
      007A83 A3               [24] 2038 	inc	dptr
      007A84 F0               [24] 2039 	movx	@dptr,a
      007A85 90 0D 8C         [24] 2040 	mov	dptr,#___memcpy_PARM_3
      007A88 22               [24] 2041 	ret
                                   2042 
                                   2043 	.area CSEG (CODE)
                                   2044 ; function ak820_outline_0063
      007A89                       2045 _ak820_outline_0063:
      007A89 F5 F0            [12] 2046 	mov	b,a
      007A8B 05 F0            [12] 2047 	inc	b
      007A8D 74 01            [12] 2048 	mov	a,#0x01
      007A8F 22               [24] 2049 	ret
                                   2050 
                                   2051 	.area CSEG (CODE)
                                   2052 ; function ak820_outline_0076
      007A90                       2053 _ak820_outline_0076:
      007A90 90 08 42         [24] 2054 	mov	dptr,#_process_action_PARM_2
      007A93 E0               [24] 2055 	movx	a,@dptr
      007A94 F5 82            [12] 2056 	mov	dpl,a
      007A96 22               [24] 2057 	ret
                                   2058 
                                   2059 	.area CSEG (CODE)
                                   2060 ; function ak820_outline_0086
      007A97                       2061 _ak820_outline_0086:
      007A97 90 08 43         [24] 2062 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007A9A E0               [24] 2063 	movx	a,@dptr
      007A9B 03               [12] 2064 	rr	a
      007A9C 03               [12] 2065 	rr	a
      007A9D 54 03            [12] 2066 	anl	a,#0x03
      007A9F 22               [24] 2067 	ret
                                   2068 
                                   2069 	.area CSEG (CODE)
                                   2070 ; function ak820_outline_0107
      007AA0                       2071 _ak820_outline_0107:
      007AA0 74 06            [12] 2072 	mov	a,#0x06
      007AA2 F0               [24] 2073 	movx	@dptr,a
      007AA3 E4               [12] 2074 	clr	a
      007AA4 A3               [24] 2075 	inc	dptr
      007AA5 F0               [24] 2076 	movx	@dptr,a
      007AA6 22               [24] 2077 	ret
                                   2078 
                                   2079 	.area CSEG (CODE)
                                   2080 ; function ak820_outline_0109
      007AA7                       2081 _ak820_outline_0109:
      007AA7 90 08 43         [24] 2082 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007AAA E0               [24] 2083 	movx	a,@dptr
      007AAB 54 0F            [12] 2084 	anl	a,#0x0f
      007AAD 22               [24] 2085 	ret
                                   2086 
                                   2087 	.area CSEG (CODE)
                                   2088 ; function ak820_outline_0129
      007AAE                       2089 _ak820_outline_0129:
      007AAE 90 08 42         [24] 2090 	mov	dptr,#_process_action_PARM_2
      007AB1 E0               [24] 2091 	movx	a,@dptr
      007AB2 FE               [12] 2092 	mov	r6,a
      007AB3 A3               [24] 2093 	inc	dptr
      007AB4 E0               [24] 2094 	movx	a,@dptr
      007AB5 54 03            [12] 2095 	anl	a,#0x03
      007AB7 FF               [12] 2096 	mov	r7,a
      007AB8 22               [24] 2097 	ret
                                   2098 
                                   2099 	.area CSEG (CODE)
                                   2100 ; function ak820_outline_0154
      007AB9                       2101 _ak820_outline_0154:
      007AB9 90 08 42         [24] 2102 	mov	dptr,#_process_action_PARM_2
      007ABC E0               [24] 2103 	movx	a,@dptr
      007ABD 22               [24] 2104 	ret
                                   2105 
                                   2106 	.area CSEG (CODE)
                                   2107 ; function ak820_outline_0162
      007ABE                       2108 _ak820_outline_0162:
      007ABE 90 08 47         [24] 2109 	mov	dptr,#_register_code_code_10000_714
      007AC1 E0               [24] 2110 	movx	a,@dptr
      007AC2 FF               [12] 2111 	mov	r7,a
      007AC3 22               [24] 2112 	ret
                                   2113 
                                   2114 	.area CSEG (CODE)
                                   2115 ; function ak820_outline_0163
      007AC4                       2116 _ak820_outline_0163:
      007AC4 90 08 48         [24] 2117 	mov	dptr,#_unregister_code_code_10000_728
      007AC7 E0               [24] 2118 	movx	a,@dptr
      007AC8 FF               [12] 2119 	mov	r7,a
      007AC9 22               [24] 2120 	ret
