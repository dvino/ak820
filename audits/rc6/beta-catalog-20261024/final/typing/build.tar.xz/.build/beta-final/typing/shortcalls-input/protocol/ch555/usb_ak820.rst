                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module usb_ak820
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_nvm_end
                                     12 	.globl _ak820_nvm_flush
                                     13 	.globl _ak820_nvm_begin
                                     14 	.globl _ak820_nvm_ok
                                     15 	.globl _ak820_os_indicator_get
                                     16 	.globl _ak820_os_indicator_set
                                     17 	.globl _ak820_nvm_diagnostic
                                     18 	.globl _mDelaymS
                                     19 	.globl _mDelayuS
                                     20 	.globl _raw_hid_receive
                                     21 	.globl _ADC_START
                                     22 	.globl _S0_R_FIFO
                                     23 	.globl _S0_T_FIFO
                                     24 	.globl _S0_FREE
                                     25 	.globl _S0_IF_BYTE
                                     26 	.globl _S0_IF_FIRST
                                     27 	.globl _S0_IF_OV
                                     28 	.globl _S0_FST_ACT
                                     29 	.globl _CP_RL2
                                     30 	.globl _C_T2
                                     31 	.globl _TR2
                                     32 	.globl _EXEN2
                                     33 	.globl _TCLK
                                     34 	.globl _RCLK
                                     35 	.globl _EXF2
                                     36 	.globl _CAP1F
                                     37 	.globl _TF2
                                     38 	.globl _RI
                                     39 	.globl _TI
                                     40 	.globl _RB8
                                     41 	.globl _TB8
                                     42 	.globl _REN
                                     43 	.globl _SM2
                                     44 	.globl _SM1
                                     45 	.globl _SM0
                                     46 	.globl _IT0
                                     47 	.globl _IE0
                                     48 	.globl _IT1
                                     49 	.globl _IE1
                                     50 	.globl _TR0
                                     51 	.globl _TF0
                                     52 	.globl _TR1
                                     53 	.globl _TF1
                                     54 	.globl _P4_0
                                     55 	.globl _P4_1
                                     56 	.globl _P4_2
                                     57 	.globl _P4_3
                                     58 	.globl _P4_4
                                     59 	.globl _P4_5
                                     60 	.globl _P4_6
                                     61 	.globl _RXD
                                     62 	.globl _TXD
                                     63 	.globl _INT0
                                     64 	.globl _INT1
                                     65 	.globl _T0
                                     66 	.globl _T1
                                     67 	.globl _MOSI1
                                     68 	.globl _MISO1
                                     69 	.globl _SCK1
                                     70 	.globl _P3_0
                                     71 	.globl _P3_1
                                     72 	.globl _P3_2
                                     73 	.globl _P3_3
                                     74 	.globl _P3_4
                                     75 	.globl _P3_5
                                     76 	.globl _P3_6
                                     77 	.globl _P3_7
                                     78 	.globl _CAP1_
                                     79 	.globl _T2_
                                     80 	.globl _CAP2_
                                     81 	.globl _T2EX_
                                     82 	.globl _RXD1
                                     83 	.globl _TXD1
                                     84 	.globl _P2_0
                                     85 	.globl _P2_1
                                     86 	.globl _P2_2
                                     87 	.globl _P2_3
                                     88 	.globl _P2_4
                                     89 	.globl _P2_5
                                     90 	.globl _P2_6
                                     91 	.globl _P2_7
                                     92 	.globl _AIN0
                                     93 	.globl _AIN1
                                     94 	.globl _AIN2
                                     95 	.globl _AIN3
                                     96 	.globl _AIN4
                                     97 	.globl _AIN5
                                     98 	.globl _AIN6
                                     99 	.globl _AIN7
                                    100 	.globl _CAP1
                                    101 	.globl _T2
                                    102 	.globl _CAP2
                                    103 	.globl _T2EX
                                    104 	.globl _INT0_
                                    105 	.globl _SCS
                                    106 	.globl _MOSI
                                    107 	.globl _MISO
                                    108 	.globl _SCK
                                    109 	.globl _RXD1_
                                    110 	.globl _TXD1_
                                    111 	.globl _P1_0
                                    112 	.globl _P1_1
                                    113 	.globl _P1_2
                                    114 	.globl _P1_3
                                    115 	.globl _P1_4
                                    116 	.globl _P1_5
                                    117 	.globl _P1_6
                                    118 	.globl _P1_7
                                    119 	.globl _AIN8
                                    120 	.globl _AIN9
                                    121 	.globl _AIN10
                                    122 	.globl _AIN11
                                    123 	.globl _AIN12
                                    124 	.globl _AIN13
                                    125 	.globl _RXD_
                                    126 	.globl _TXD_
                                    127 	.globl _SCL0
                                    128 	.globl _SDA0
                                    129 	.globl _P0_0
                                    130 	.globl _P0_1
                                    131 	.globl _P0_2
                                    132 	.globl _P0_3
                                    133 	.globl _P0_4
                                    134 	.globl _P0_5
                                    135 	.globl _P0_6
                                    136 	.globl _P0_7
                                    137 	.globl _IE_SPI0
                                    138 	.globl _IE_USB
                                    139 	.globl _IE_ADC
                                    140 	.globl _IE_UART1
                                    141 	.globl _IE_PWM_I2C
                                    142 	.globl _IE_GPIO
                                    143 	.globl _IE_WDOG
                                    144 	.globl _PX0
                                    145 	.globl _PT0
                                    146 	.globl _PX1
                                    147 	.globl _PT1
                                    148 	.globl _PS
                                    149 	.globl _PT2
                                    150 	.globl _PL_FLAG
                                    151 	.globl _PH_FLAG
                                    152 	.globl _EX0
                                    153 	.globl _ET0
                                    154 	.globl _EX1
                                    155 	.globl _ET1
                                    156 	.globl _ES
                                    157 	.globl _ET2
                                    158 	.globl _E_DIS
                                    159 	.globl _EA
                                    160 	.globl _P
                                    161 	.globl _F1
                                    162 	.globl _OV
                                    163 	.globl _RS0
                                    164 	.globl _RS1
                                    165 	.globl _F0
                                    166 	.globl _AC
                                    167 	.globl _CY
                                    168 	.globl _I2CS_INT_ST
                                    169 	.globl _I2CX_INT
                                    170 	.globl _LED_STATUS
                                    171 	.globl _LED_DMA_H
                                    172 	.globl _LED_DMA_L
                                    173 	.globl _LED_DMA
                                    174 	.globl _LED_PWM_OE
                                    175 	.globl _LED_COMMON
                                    176 	.globl _ADC_CHAN
                                    177 	.globl _ADC_DAT_H
                                    178 	.globl _ADC_DAT_L
                                    179 	.globl _ADC_DAT
                                    180 	.globl _ADC_CTRL
                                    181 	.globl _SPI1_CK_SE
                                    182 	.globl _SPI1_CTRL
                                    183 	.globl _SPI1_DATA
                                    184 	.globl _SPI1_STAT
                                    185 	.globl _SIF1
                                    186 	.globl _SBAUD1
                                    187 	.globl _SBUF1
                                    188 	.globl _SCON1
                                    189 	.globl _SPI0_SETUP
                                    190 	.globl _SPI0_CK_SE
                                    191 	.globl _SPI0_CTRL
                                    192 	.globl _SPI0_DATA
                                    193 	.globl _SPI0_STAT
                                    194 	.globl _T2CAP1H
                                    195 	.globl _T2CAP1L
                                    196 	.globl _T2CAP1
                                    197 	.globl _TH2
                                    198 	.globl _TL2
                                    199 	.globl _T2COUNT
                                    200 	.globl _RCAP2H
                                    201 	.globl _RCAP2L
                                    202 	.globl _RCAP2
                                    203 	.globl _T2MOD
                                    204 	.globl _T2CON
                                    205 	.globl _SBUF
                                    206 	.globl _SCON
                                    207 	.globl _TH1
                                    208 	.globl _TH0
                                    209 	.globl _TL1
                                    210 	.globl _TL0
                                    211 	.globl _TMOD
                                    212 	.globl _TCON
                                    213 	.globl _XBUS_AUX
                                    214 	.globl _P7
                                    215 	.globl _P6_DIR
                                    216 	.globl _P6_OUT_PU
                                    217 	.globl _P6_IN
                                    218 	.globl _P5_DIR
                                    219 	.globl _P5_OUT_PU
                                    220 	.globl _P5_IN
                                    221 	.globl _P4_LED_KEY
                                    222 	.globl _P4_DIR_PU
                                    223 	.globl _P4_MOD_OC
                                    224 	.globl _P4
                                    225 	.globl _P3_DIR_PU
                                    226 	.globl _P3_MOD_OC
                                    227 	.globl _P3
                                    228 	.globl _P2_DIR_PU
                                    229 	.globl _P2_MOD_OC
                                    230 	.globl _P2
                                    231 	.globl _P1_DIR_PU
                                    232 	.globl _P1_MOD_OC
                                    233 	.globl _P1
                                    234 	.globl _P0_DIR_PU
                                    235 	.globl _P0_MOD_OC
                                    236 	.globl _P0
                                    237 	.globl _ROM_CTRL
                                    238 	.globl _ROM_DATA_HH
                                    239 	.globl _ROM_DATA_HL
                                    240 	.globl _ROM_DATA_HI
                                    241 	.globl _ROM_ADDR_H
                                    242 	.globl _ROM_ADDR_L
                                    243 	.globl _ROM_ADDR
                                    244 	.globl _GPIO_IE
                                    245 	.globl _IP_EX
                                    246 	.globl _IE_EX
                                    247 	.globl _IP
                                    248 	.globl _IE
                                    249 	.globl _WDOG_COUNT
                                    250 	.globl _RESET_KEEP
                                    251 	.globl _WAKE_CTRL
                                    252 	.globl _CLOCK_CFG
                                    253 	.globl _POWER_CFG
                                    254 	.globl _PCON
                                    255 	.globl _GLOBAL_CFG
                                    256 	.globl _SAFE_MOD
                                    257 	.globl _DPH
                                    258 	.globl _DPL
                                    259 	.globl _SP
                                    260 	.globl _A_INV
                                    261 	.globl _B
                                    262 	.globl _ACC
                                    263 	.globl _PSW
                                    264 	.globl _ak820_usb_raw_send_PARM_2
                                    265 	.globl _ak820_usb_try_send_PARM_3
                                    266 	.globl _ak820_usb_try_send_PARM_2
                                    267 	.globl _ak820_usb_send_PARM_3
                                    268 	.globl _ak820_usb_send_PARM_2
                                    269 	.globl _ak820_main_heartbeat
                                    270 	.globl _ak820_boot_stage
                                    271 	.globl _KB_USB_SetReport
                                    272 	.globl _KB_USB_UpStatus
                                    273 	.globl _MCU_Sleep_Operate
                                    274 	.globl _USB_SleepStatus
                                    275 	.globl _USB_EnumStatus
                                    276 	.globl _D0UsbConfig
                                    277 	.globl _pD0Descr
                                    278 	.globl _D0SetupLen
                                    279 	.globl _D0SetupReqCode
                                    280 	.globl _USB_DeviceInterrupt
                                    281 	.globl _USB_Device_Init
                                    282 	.globl _USB_WakeUp_PC
                                    283 	.globl _ak820_usb_send
                                    284 	.globl _ak820_usb_try_send
                                    285 	.globl _ak820_usb_raw_send
                                    286 	.globl _ak820_usb_raw_task
                                    287 	.globl _ak820_usb_take_keyboard_reset
                                    288 ;--------------------------------------------------------
                                    289 ; special function registers
                                    290 ;--------------------------------------------------------
                                    291 	.area RSEG    (ABS,DATA)
      000000                        292 	.org 0x0000
                           0000D0   293 _PSW	=	0x00d0
                           0000E0   294 _ACC	=	0x00e0
                           0000F0   295 _B	=	0x00f0
                           0000FD   296 _A_INV	=	0x00fd
                           000081   297 _SP	=	0x0081
                           000082   298 _DPL	=	0x0082
                           000083   299 _DPH	=	0x0083
                           0000A1   300 _SAFE_MOD	=	0x00a1
                           0000B1   301 _GLOBAL_CFG	=	0x00b1
                           000087   302 _PCON	=	0x0087
                           0000BA   303 _POWER_CFG	=	0x00ba
                           0000B9   304 _CLOCK_CFG	=	0x00b9
                           0000A9   305 _WAKE_CTRL	=	0x00a9
                           0000FE   306 _RESET_KEEP	=	0x00fe
                           0000FF   307 _WDOG_COUNT	=	0x00ff
                           0000A8   308 _IE	=	0x00a8
                           0000B8   309 _IP	=	0x00b8
                           0000E8   310 _IE_EX	=	0x00e8
                           0000E9   311 _IP_EX	=	0x00e9
                           0000B2   312 _GPIO_IE	=	0x00b2
                           008584   313 _ROM_ADDR	=	0x8584
                           000084   314 _ROM_ADDR_L	=	0x0084
                           000085   315 _ROM_ADDR_H	=	0x0085
                           008F8E   316 _ROM_DATA_HI	=	0x8f8e
                           00008E   317 _ROM_DATA_HL	=	0x008e
                           00008F   318 _ROM_DATA_HH	=	0x008f
                           000086   319 _ROM_CTRL	=	0x0086
                           000080   320 _P0	=	0x0080
                           0000C4   321 _P0_MOD_OC	=	0x00c4
                           0000C5   322 _P0_DIR_PU	=	0x00c5
                           000090   323 _P1	=	0x0090
                           000092   324 _P1_MOD_OC	=	0x0092
                           000093   325 _P1_DIR_PU	=	0x0093
                           0000A0   326 _P2	=	0x00a0
                           000094   327 _P2_MOD_OC	=	0x0094
                           000095   328 _P2_DIR_PU	=	0x0095
                           0000B0   329 _P3	=	0x00b0
                           000096   330 _P3_MOD_OC	=	0x0096
                           000097   331 _P3_DIR_PU	=	0x0097
                           0000C0   332 _P4	=	0x00c0
                           0000C2   333 _P4_MOD_OC	=	0x00c2
                           0000C3   334 _P4_DIR_PU	=	0x00c3
                           0000C1   335 _P4_LED_KEY	=	0x00c1
                           0000AA   336 _P5_IN	=	0x00aa
                           0000AB   337 _P5_OUT_PU	=	0x00ab
                           0000AC   338 _P5_DIR	=	0x00ac
                           0000AD   339 _P6_IN	=	0x00ad
                           0000AE   340 _P6_OUT_PU	=	0x00ae
                           0000AF   341 _P6_DIR	=	0x00af
                           0000F1   342 _P7	=	0x00f1
                           0000A2   343 _XBUS_AUX	=	0x00a2
                           000088   344 _TCON	=	0x0088
                           000089   345 _TMOD	=	0x0089
                           00008A   346 _TL0	=	0x008a
                           00008B   347 _TL1	=	0x008b
                           00008C   348 _TH0	=	0x008c
                           00008D   349 _TH1	=	0x008d
                           000098   350 _SCON	=	0x0098
                           000099   351 _SBUF	=	0x0099
                           0000C8   352 _T2CON	=	0x00c8
                           0000C9   353 _T2MOD	=	0x00c9
                           00CBCA   354 _RCAP2	=	0xcbca
                           0000CA   355 _RCAP2L	=	0x00ca
                           0000CB   356 _RCAP2H	=	0x00cb
                           00CDCC   357 _T2COUNT	=	0xcdcc
                           0000CC   358 _TL2	=	0x00cc
                           0000CD   359 _TH2	=	0x00cd
                           00CFCE   360 _T2CAP1	=	0xcfce
                           0000CE   361 _T2CAP1L	=	0x00ce
                           0000CF   362 _T2CAP1H	=	0x00cf
                           0000F8   363 _SPI0_STAT	=	0x00f8
                           0000F9   364 _SPI0_DATA	=	0x00f9
                           0000FA   365 _SPI0_CTRL	=	0x00fa
                           0000FB   366 _SPI0_CK_SE	=	0x00fb
                           0000FC   367 _SPI0_SETUP	=	0x00fc
                           0000BC   368 _SCON1	=	0x00bc
                           0000BD   369 _SBUF1	=	0x00bd
                           0000BE   370 _SBAUD1	=	0x00be
                           0000BF   371 _SIF1	=	0x00bf
                           0000B4   372 _SPI1_STAT	=	0x00b4
                           0000B5   373 _SPI1_DATA	=	0x00b5
                           0000B6   374 _SPI1_CTRL	=	0x00b6
                           0000B7   375 _SPI1_CK_SE	=	0x00b7
                           0000F3   376 _ADC_CTRL	=	0x00f3
                           00F5F4   377 _ADC_DAT	=	0xf5f4
                           0000F4   378 _ADC_DAT_L	=	0x00f4
                           0000F5   379 _ADC_DAT_H	=	0x00f5
                           0000F6   380 _ADC_CHAN	=	0x00f6
                           0000A6   381 _LED_COMMON	=	0x00a6
                           0000A7   382 _LED_PWM_OE	=	0x00a7
                           00C7C6   383 _LED_DMA	=	0xc7c6
                           0000C6   384 _LED_DMA_L	=	0x00c6
                           0000C7   385 _LED_DMA_H	=	0x00c7
                           0000F7   386 _LED_STATUS	=	0x00f7
                           0000B3   387 _I2CX_INT	=	0x00b3
                           0000BB   388 _I2CS_INT_ST	=	0x00bb
                                    389 ;--------------------------------------------------------
                                    390 ; special function bits
                                    391 ;--------------------------------------------------------
                                    392 	.area RSEG    (ABS,DATA)
      000000                        393 	.org 0x0000
                           0000D7   394 _CY	=	0x00d7
                           0000D6   395 _AC	=	0x00d6
                           0000D5   396 _F0	=	0x00d5
                           0000D4   397 _RS1	=	0x00d4
                           0000D3   398 _RS0	=	0x00d3
                           0000D2   399 _OV	=	0x00d2
                           0000D1   400 _F1	=	0x00d1
                           0000D0   401 _P	=	0x00d0
                           0000AF   402 _EA	=	0x00af
                           0000AE   403 _E_DIS	=	0x00ae
                           0000AD   404 _ET2	=	0x00ad
                           0000AC   405 _ES	=	0x00ac
                           0000AB   406 _ET1	=	0x00ab
                           0000AA   407 _EX1	=	0x00aa
                           0000A9   408 _ET0	=	0x00a9
                           0000A8   409 _EX0	=	0x00a8
                           0000BF   410 _PH_FLAG	=	0x00bf
                           0000BE   411 _PL_FLAG	=	0x00be
                           0000BD   412 _PT2	=	0x00bd
                           0000BC   413 _PS	=	0x00bc
                           0000BB   414 _PT1	=	0x00bb
                           0000BA   415 _PX1	=	0x00ba
                           0000B9   416 _PT0	=	0x00b9
                           0000B8   417 _PX0	=	0x00b8
                           0000EF   418 _IE_WDOG	=	0x00ef
                           0000EE   419 _IE_GPIO	=	0x00ee
                           0000ED   420 _IE_PWM_I2C	=	0x00ed
                           0000EC   421 _IE_UART1	=	0x00ec
                           0000EB   422 _IE_ADC	=	0x00eb
                           0000E9   423 _IE_USB	=	0x00e9
                           0000E8   424 _IE_SPI0	=	0x00e8
                           000087   425 _P0_7	=	0x0087
                           000086   426 _P0_6	=	0x0086
                           000085   427 _P0_5	=	0x0085
                           000084   428 _P0_4	=	0x0084
                           000083   429 _P0_3	=	0x0083
                           000082   430 _P0_2	=	0x0082
                           000081   431 _P0_1	=	0x0081
                           000080   432 _P0_0	=	0x0080
                           000081   433 _SDA0	=	0x0081
                           000080   434 _SCL0	=	0x0080
                           000083   435 _TXD_	=	0x0083
                           000082   436 _RXD_	=	0x0082
                           000085   437 _AIN13	=	0x0085
                           000084   438 _AIN12	=	0x0084
                           000083   439 _AIN11	=	0x0083
                           000082   440 _AIN10	=	0x0082
                           000081   441 _AIN9	=	0x0081
                           000080   442 _AIN8	=	0x0080
                           000097   443 _P1_7	=	0x0097
                           000096   444 _P1_6	=	0x0096
                           000095   445 _P1_5	=	0x0095
                           000094   446 _P1_4	=	0x0094
                           000093   447 _P1_3	=	0x0093
                           000092   448 _P1_2	=	0x0092
                           000091   449 _P1_1	=	0x0091
                           000090   450 _P1_0	=	0x0090
                           000097   451 _TXD1_	=	0x0097
                           000096   452 _RXD1_	=	0x0096
                           000097   453 _SCK	=	0x0097
                           000096   454 _MISO	=	0x0096
                           000095   455 _MOSI	=	0x0095
                           000094   456 _SCS	=	0x0094
                           000092   457 _INT0_	=	0x0092
                           000091   458 _T2EX	=	0x0091
                           000091   459 _CAP2	=	0x0091
                           000090   460 _T2	=	0x0090
                           000090   461 _CAP1	=	0x0090
                           000097   462 _AIN7	=	0x0097
                           000096   463 _AIN6	=	0x0096
                           000095   464 _AIN5	=	0x0095
                           000094   465 _AIN4	=	0x0094
                           000093   466 _AIN3	=	0x0093
                           000092   467 _AIN2	=	0x0092
                           000091   468 _AIN1	=	0x0091
                           000090   469 _AIN0	=	0x0090
                           0000A7   470 _P2_7	=	0x00a7
                           0000A6   471 _P2_6	=	0x00a6
                           0000A5   472 _P2_5	=	0x00a5
                           0000A4   473 _P2_4	=	0x00a4
                           0000A3   474 _P2_3	=	0x00a3
                           0000A2   475 _P2_2	=	0x00a2
                           0000A1   476 _P2_1	=	0x00a1
                           0000A0   477 _P2_0	=	0x00a0
                           0000A7   478 _TXD1	=	0x00a7
                           0000A6   479 _RXD1	=	0x00a6
                           0000A5   480 _T2EX_	=	0x00a5
                           0000A5   481 _CAP2_	=	0x00a5
                           0000A4   482 _T2_	=	0x00a4
                           0000A4   483 _CAP1_	=	0x00a4
                           0000B7   484 _P3_7	=	0x00b7
                           0000B6   485 _P3_6	=	0x00b6
                           0000B5   486 _P3_5	=	0x00b5
                           0000B4   487 _P3_4	=	0x00b4
                           0000B3   488 _P3_3	=	0x00b3
                           0000B2   489 _P3_2	=	0x00b2
                           0000B1   490 _P3_1	=	0x00b1
                           0000B0   491 _P3_0	=	0x00b0
                           0000B7   492 _SCK1	=	0x00b7
                           0000B6   493 _MISO1	=	0x00b6
                           0000B5   494 _MOSI1	=	0x00b5
                           0000B5   495 _T1	=	0x00b5
                           0000B4   496 _T0	=	0x00b4
                           0000B3   497 _INT1	=	0x00b3
                           0000B2   498 _INT0	=	0x00b2
                           0000B1   499 _TXD	=	0x00b1
                           0000B0   500 _RXD	=	0x00b0
                           0000C6   501 _P4_6	=	0x00c6
                           0000C5   502 _P4_5	=	0x00c5
                           0000C4   503 _P4_4	=	0x00c4
                           0000C3   504 _P4_3	=	0x00c3
                           0000C2   505 _P4_2	=	0x00c2
                           0000C1   506 _P4_1	=	0x00c1
                           0000C0   507 _P4_0	=	0x00c0
                           00008F   508 _TF1	=	0x008f
                           00008E   509 _TR1	=	0x008e
                           00008D   510 _TF0	=	0x008d
                           00008C   511 _TR0	=	0x008c
                           00008B   512 _IE1	=	0x008b
                           00008A   513 _IT1	=	0x008a
                           000089   514 _IE0	=	0x0089
                           000088   515 _IT0	=	0x0088
                           00009F   516 _SM0	=	0x009f
                           00009E   517 _SM1	=	0x009e
                           00009D   518 _SM2	=	0x009d
                           00009C   519 _REN	=	0x009c
                           00009B   520 _TB8	=	0x009b
                           00009A   521 _RB8	=	0x009a
                           000099   522 _TI	=	0x0099
                           000098   523 _RI	=	0x0098
                           0000CF   524 _TF2	=	0x00cf
                           0000CF   525 _CAP1F	=	0x00cf
                           0000CE   526 _EXF2	=	0x00ce
                           0000CD   527 _RCLK	=	0x00cd
                           0000CC   528 _TCLK	=	0x00cc
                           0000CB   529 _EXEN2	=	0x00cb
                           0000CA   530 _TR2	=	0x00ca
                           0000C9   531 _C_T2	=	0x00c9
                           0000C8   532 _CP_RL2	=	0x00c8
                           0000FF   533 _S0_FST_ACT	=	0x00ff
                           0000FE   534 _S0_IF_OV	=	0x00fe
                           0000FD   535 _S0_IF_FIRST	=	0x00fd
                           0000FC   536 _S0_IF_BYTE	=	0x00fc
                           0000FB   537 _S0_FREE	=	0x00fb
                           0000FA   538 _S0_T_FIFO	=	0x00fa
                           0000F8   539 _S0_R_FIFO	=	0x00f8
                           0000F7   540 _ADC_START	=	0x00f7
                                    541 ;--------------------------------------------------------
                                    542 ; overlayable register banks
                                    543 ;--------------------------------------------------------
                                    544 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        545 	.ds 8
                                    546 ;--------------------------------------------------------
                                    547 ; internal ram data
                                    548 ;--------------------------------------------------------
                                    549 	.area DSEG    (DATA)
      000016                        550 _control_setup_sloc1_1_0:
      000016                        551 	.ds 1
      000017                        552 _control_setup_sloc3_1_0:
      000017                        553 	.ds 2
      000019                        554 _control_setup_sloc4_1_0:
      000019                        555 	.ds 2
      00001B                        556 _ak820_usb_send_sloc0_1_0:
      00001B                        557 	.ds 2
      00001D                        558 _ak820_usb_send_sloc1_1_0:
      00001D                        559 	.ds 1
      00001E                        560 _ak820_usb_raw_task_sloc0_1_0:
      00001E                        561 	.ds 2
                                    562 ;--------------------------------------------------------
                                    563 ; overlayable items in internal ram
                                    564 ;--------------------------------------------------------
                                    565 ;--------------------------------------------------------
                                    566 ; indirectly addressable internal ram data
                                    567 ;--------------------------------------------------------
                                    568 	.area ISEG    (DATA)
                                    569 ;--------------------------------------------------------
                                    570 ; absolute internal ram data
                                    571 ;--------------------------------------------------------
                                    572 	.area IABS    (ABS,DATA)
                                    573 	.area IABS    (ABS,DATA)
                                    574 ;--------------------------------------------------------
                                    575 ; bit data
                                    576 ;--------------------------------------------------------
                                    577 	.area BSEG    (BIT)
      000015                        578 _control_setup_valid_interface_10000_289:
      000015                        579 	.ds 1
      000016                        580 _control_setup_zero_index_10000_289:
      000016                        581 	.ds 1
      000017                        582 _control_setup_zero_value_10000_289:
      000017                        583 	.ds 1
      000018                        584 _control_setup_zero_length_10000_289:
      000018                        585 	.ds 1
      000019                        586 _control_setup_sloc0_1_0:
      000019                        587 	.ds 1
      00001A                        588 _control_setup_sloc2_1_0:
      00001A                        589 	.ds 1
      00001B                        590 _ak820_usb_try_send_sloc0_1_0:
      00001B                        591 	.ds 1
      00001C                        592 _ak820_usb_raw_task_sloc1_1_0:
      00001C                        593 	.ds 1
      00001D                        594 _ak820_usb_take_keyboard_reset_sloc0_1_0:
      00001D                        595 	.ds 1
                                    596 ;--------------------------------------------------------
                                    597 ; paged external ram data
                                    598 ;--------------------------------------------------------
                                    599 	.area PSEG    (PAG,XDATA)
                                    600 ;--------------------------------------------------------
                                    601 ; uninitialized external ram data
                                    602 ;--------------------------------------------------------
                                    603 	.area XSEG    (XDATA)
      000779                        604 _D0SetupReqCode::
      000779                        605 	.ds 1
      00077A                        606 _D0SetupLen::
      00077A                        607 	.ds 2
      00077C                        608 _pD0Descr::
      00077C                        609 	.ds 3
      00077F                        610 _D0UsbConfig::
      00077F                        611 	.ds 1
      000780                        612 _USB_EnumStatus::
      000780                        613 	.ds 1
      000781                        614 _USB_SleepStatus::
      000781                        615 	.ds 1
      000782                        616 _MCU_Sleep_Operate::
      000782                        617 	.ds 1
      000783                        618 _KB_USB_UpStatus::
      000783                        619 	.ds 1
      000784                        620 _KB_USB_SetReport::
      000784                        621 	.ds 1
      000785                        622 _ak820_boot_stage::
      000785                        623 	.ds 1
      000786                        624 _ak820_main_heartbeat::
      000786                        625 	.ds 1
      000787                        626 _raw_state:
      000787                        627 	.ds 1
      000788                        628 _raw_buffer:
      000788                        629 	.ds 32
      0007A8                        630 _raw_reply_without_nvm:
      0007A8                        631 	.ds 1
      0007A9                        632 _keyboard_reset:
      0007A9                        633 	.ds 1
      0007AA                        634 _input_snapshot:
      0007AA                        635 	.ds 46
      0007D8                        636 _control_phase:
      0007D8                        637 	.ds 1
      0007D9                        638 _output_kind:
      0007D9                        639 	.ds 1
      0007DA                        640 _output_report_id:
      0007DA                        641 	.ds 1
      0007DB                        642 _control_zlp:
      0007DB                        643 	.ds 1
      0007DC                        644 _control_pointer:
      0007DC                        645 	.ds 2
      0007DE                        646 _descriptor_select_PARM_2:
      0007DE                        647 	.ds 1
      0007DF                        648 _descriptor_select_PARM_3:
      0007DF                        649 	.ds 2
      0007E1                        650 _descriptor_select_type_10000_271:
      0007E1                        651 	.ds 1
      0007E2                        652 _control_setup_length_10000_289:
      0007E2                        653 	.ds 2
      0007E4                        654 _control_setup_offset_10000_289:
      0007E4                        655 	.ds 1
      0007E5                        656 _ak820_usb_send_PARM_2:
      0007E5                        657 	.ds 2
      0007E7                        658 _ak820_usb_send_PARM_3:
      0007E7                        659 	.ds 1
      0007E8                        660 _ak820_usb_send_endpoint_10000_425:
      0007E8                        661 	.ds 1
      0007E9                        662 _ak820_usb_send_offset_10000_426:
      0007E9                        663 	.ds 1
      0007EA                        664 _ak820_usb_try_send_PARM_2:
      0007EA                        665 	.ds 2
      0007EC                        666 _ak820_usb_try_send_PARM_3:
      0007EC                        667 	.ds 1
      0007ED                        668 _ak820_usb_try_send_endpoint_10000_446:
      0007ED                        669 	.ds 1
      0007EE                        670 _ak820_usb_try_send_sent_10000_447:
      0007EE                        671 	.ds 1
      0007EF                        672 _ak820_usb_raw_send_PARM_2:
      0007EF                        673 	.ds 1
      0007F0                        674 _ak820_usb_raw_send_report_10000_462:
      0007F0                        675 	.ds 3
      0007F3                        676 _ak820_usb_raw_task_length_10000_467:
      0007F3                        677 	.ds 1
                                    678 ;--------------------------------------------------------
                                    679 ; absolute external ram data
                                    680 ;--------------------------------------------------------
                                    681 	.area XABS    (ABS,XDATA)
                                    682 ;--------------------------------------------------------
                                    683 ; initialized external ram data
                                    684 ;--------------------------------------------------------
                                    685 	.area XISEG   (XDATA)
                                    686 	.area HOME    (CODE)
                                    687 	.area GSINIT0 (CODE)
                                    688 	.area GSINIT1 (CODE)
                                    689 	.area GSINIT2 (CODE)
                                    690 	.area GSINIT3 (CODE)
                                    691 	.area GSINIT4 (CODE)
                                    692 	.area GSINIT5 (CODE)
                                    693 	.area GSINIT  (CODE)
                                    694 	.area GSFINAL (CODE)
                                    695 	.area CSEG    (CODE)
                                    696 ;--------------------------------------------------------
                                    697 ; global & static initialisations
                                    698 ;--------------------------------------------------------
                                    699 	.area HOME    (CODE)
                                    700 	.area GSINIT  (CODE)
                                    701 	.area GSFINAL (CODE)
                                    702 	.area GSINIT  (CODE)
                                    703 ;--------------------------------------------------------
                                    704 ; Home
                                    705 ;--------------------------------------------------------
                                    706 	.area HOME    (CODE)
                                    707 	.area HOME    (CODE)
                                    708 ;--------------------------------------------------------
                                    709 ; code
                                    710 ;--------------------------------------------------------
                                    711 	.area CSEG    (CODE)
                                    712 ;------------------------------------------------------------
                                    713 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    714 ;------------------------------------------------------------
                                    715 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_45'
                                    716 ;------------------------------------------------------------
                                    717 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    718 ;	-----------------------------------------
                           000007   719 	ar7 = 0x07
                           000006   720 	ar6 = 0x06
                           000005   721 	ar5 = 0x05
                           000004   722 	ar4 = 0x04
                           000003   723 	ar3 = 0x03
                           000002   724 	ar2 = 0x02
                           000001   725 	ar1 = 0x01
                           000000   726 	ar0 = 0x00
                                    727 ;	 function raw_abort
                                    728 ;	-----------------------------------------
      005D39                        729 _raw_abort:
                                    730 ;	tmk_core/protocol/ch555/usb_ak820.c:97: if (raw_state == RAW_WORK || raw_state == RAW_TX_ACTIVE ||
      005D39 90 07 87         [24]  731 	mov	dptr,#_raw_state
      005D3C E0               [24]  732 	movx	a,@dptr
      005D3D FF               [12]  733 	mov	r7,a
      005D3E BF 03 02         [24]  734 	cjne	r7,#0x03,00130$
      005D41 80 1C            [24]  735 	sjmp	00101$
      005D43                        736 00130$:
      005D43 90 07 87         [24]  737 	mov	dptr,#_raw_state
      005D46 E0               [24]  738 	movx	a,@dptr
      005D47 FF               [12]  739 	mov	r7,a
      005D48 BF 04 02         [24]  740 	cjne	r7,#0x04,00131$
      005D4B 80 12            [24]  741 	sjmp	00101$
      005D4D                        742 00131$:
                                    743 ;	tmk_core/protocol/ch555/usb_ak820.c:98: raw_state == RAW_DRAINED || raw_state == RAW_CANCELLED)
      005D4D 90 07 87         [24]  744 	mov	dptr,#_raw_state
      005D50 E0               [24]  745 	movx	a,@dptr
      005D51 FF               [12]  746 	mov	r7,a
      005D52 BF 06 02         [24]  747 	cjne	r7,#0x06,00132$
      005D55 80 08            [24]  748 	sjmp	00101$
      005D57                        749 00132$:
      005D57 90 07 87         [24]  750 	mov	dptr,#_raw_state
      005D5A E0               [24]  751 	movx	a,@dptr
      005D5B FF               [12]  752 	mov	r7,a
      005D5C BF 07 08         [24]  753 	cjne	r7,#0x07,00102$
      005D5F                        754 00101$:
                                    755 ;	tmk_core/protocol/ch555/usb_ak820.c:99: raw_state = RAW_CANCELLED;
      005D5F 90 07 87         [24]  756 	mov	dptr,#_raw_state
      005D62 74 07            [12]  757 	mov	a,#0x07
      005D64 F0               [24]  758 	movx	@dptr,a
      005D65 80 05            [24]  759 	sjmp	00103$
      005D67                        760 00102$:
                                    761 ;	tmk_core/protocol/ch555/usb_ak820.c:101: raw_state = RAW_IDLE;
      005D67 90 07 87         [24]  762 	mov	dptr,#_raw_state
      005D6A E4               [12]  763 	clr	a
      005D6B F0               [24]  764 	movx	@dptr,a
      005D6C                        765 00103$:
                                    766 ;	tmk_core/protocol/ch555/usb_ak820.c:102: output_kind = OUTPUT_NONE;
      005D6C 90 07 D9         [24]  767 	mov	dptr,#_output_kind
      005D6F E4               [12]  768 	clr	a
      005D70 F0               [24]  769 	movx	@dptr,a
                                    770 ;	tmk_core/protocol/ch555/usb_ak820.c:103: }
      005D71 22               [24]  771 	ret
                                    772 ;------------------------------------------------------------
                                    773 ;Allocation info for local variables in function 'raw_complete'
                                    774 ;------------------------------------------------------------
                                    775 ;	tmk_core/protocol/ch555/usb_ak820.c:105: static void raw_complete(void) {
                                    776 ;	-----------------------------------------
                                    777 ;	 function raw_complete
                                    778 ;	-----------------------------------------
      005D72                        779 _raw_complete:
                                    780 ;	tmk_core/protocol/ch555/usb_ak820.c:106: if (raw_state == RAW_TX_ACTIVE) raw_state = RAW_DRAINED;
      005D72 90 07 87         [24]  781 	mov	dptr,#_raw_state
      005D75 E0               [24]  782 	movx	a,@dptr
      005D76 FF               [12]  783 	mov	r7,a
      005D77 BF 04 07         [24]  784 	cjne	r7,#0x04,00104$
      005D7A 90 07 87         [24]  785 	mov	dptr,#_raw_state
      005D7D 74 06            [12]  786 	mov	a,#0x06
      005D7F F0               [24]  787 	movx	@dptr,a
      005D80 22               [24]  788 	ret
      005D81                        789 00104$:
                                    790 ;	tmk_core/protocol/ch555/usb_ak820.c:107: else if (raw_state == RAW_TX_WAIT) raw_state = RAW_IDLE;
      005D81 90 07 87         [24]  791 	mov	dptr,#_raw_state
      005D84 E0               [24]  792 	movx	a,@dptr
      005D85 FF               [12]  793 	mov	r7,a
      005D86 BF 05 05         [24]  794 	cjne	r7,#0x05,00106$
      005D89 90 07 87         [24]  795 	mov	dptr,#_raw_state
      005D8C E4               [12]  796 	clr	a
      005D8D F0               [24]  797 	movx	@dptr,a
      005D8E                        798 00106$:
                                    799 ;	tmk_core/protocol/ch555/usb_ak820.c:108: }
      005D8E 22               [24]  800 	ret
                                    801 ;------------------------------------------------------------
                                    802 ;Allocation info for local variables in function 'endpoints_reset'
                                    803 ;------------------------------------------------------------
                                    804 ;i             Allocated with name '_endpoints_reset_i_10000_261'
                                    805 ;------------------------------------------------------------
                                    806 ;	tmk_core/protocol/ch555/usb_ak820.c:110: static void endpoints_reset(void) {
                                    807 ;	-----------------------------------------
                                    808 ;	 function endpoints_reset
                                    809 ;	-----------------------------------------
      005D8F                        810 _endpoints_reset:
                                    811 ;	tmk_core/protocol/ch555/usb_ak820.c:113: ak820_os_indicator_mode = AK820_OS_NORMAL;
      005D8F 90 05 AA         [24]  812 	mov	dptr,#_ak820_os_indicator_mode
      005D92 E4               [12]  813 	clr	a
      005D93 F0               [24]  814 	movx	@dptr,a
                                    815 ;	tmk_core/protocol/ch555/usb_ak820.c:116: D0_EP_MOD = bUX_DEV_EN;
      005D94 90 22 0C         [24]  816 	mov	dptr,#0x220c
      005D97 04               [12]  817 	inc	a
      005D98 F0               [24]  818 	movx	@dptr,a
                                    819 ;	tmk_core/protocol/ch555/usb_ak820.c:117: D0_EP1RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      005D99 F5 82            [12]  820 	mov	dpl,a
      005D9B 74 12            [12]  821 	mov	a,#0x12
      005D9D F0               [24]  822 	movx	@dptr,a
                                    823 ;	tmk_core/protocol/ch555/usb_ak820.c:118: D0_EP2RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      005D9E A3               [24]  824 	inc	dptr
      005D9F F0               [24]  825 	movx	@dptr,a
                                    826 ;	tmk_core/protocol/ch555/usb_ak820.c:119: D0_EP3RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      005DA0 A3               [24]  827 	inc	dptr
      005DA1 F0               [24]  828 	movx	@dptr,a
                                    829 ;	tmk_core/protocol/ch555/usb_ak820.c:120: D0_EP1T_L = D0_EP2T_L = D0_EP3T_L = 0;
      005DA2 90 22 0B         [24]  830 	mov	dptr,#0x220b
      005DA5 E4               [12]  831 	clr	a
      005DA6 F0               [24]  832 	movx	@dptr,a
      005DA7 15 82            [12]  833 	dec	dpl
      005DA9 F0               [24]  834 	movx	@dptr,a
      005DAA 15 82            [12]  835 	dec	dpl
      005DAC F0               [24]  836 	movx	@dptr,a
                                    837 ;	tmk_core/protocol/ch555/usb_ak820.c:121: for (i = 0; i < SNAPSHOT_SIZE; ++i) input_snapshot[i] = 0;
      005DAD FF               [12]  838 	mov	r7,a
      005DAE                        839 00103$:
      005DAE EF               [12]  840 	mov	a,r7
      005DAF 24 AA            [12]  841 	add	a, #_input_snapshot
      005DB1 F5 82            [12]  842 	mov	dpl,a
      005DB3 E4               [12]  843 	clr	a
      005DB4 34 07            [12]  844 	addc	a, #(_input_snapshot >> 8)
      005DB6 F5 83            [12]  845 	mov	dph,a
      005DB8 E4               [12]  846 	clr	a
      005DB9 F0               [24]  847 	movx	@dptr,a
      005DBA 0F               [12]  848 	inc	r7
      005DBB BF 2E 00         [24]  849 	cjne	r7,#0x2e,00139$
      005DBE                        850 00139$:
      005DBE 40 EE            [24]  851 	jc	00103$
                                    852 ;	tmk_core/protocol/ch555/usb_ak820.c:122: input_snapshot[SNAPSHOT_NKRO] = REPORT_ID_NKRO;
      005DC0 90 07 B2         [24]  853 	mov	dptr,#(_input_snapshot + 0x0008)
      005DC3 74 06            [12]  854 	mov	a,#0x06
      005DC5 F0               [24]  855 	movx	@dptr,a
                                    856 ;	tmk_core/protocol/ch555/usb_ak820.c:126: input_snapshot[SNAPSHOT_SYSTEM] = REPORT_ID_SYSTEM;
      005DC6 90 07 D2         [24]  857 	mov	dptr,#(_input_snapshot + 0x0028)
      005DC9 03               [12]  858 	rr	a
      005DCA F0               [24]  859 	movx	@dptr,a
                                    860 ;	tmk_core/protocol/ch555/usb_ak820.c:127: input_snapshot[SNAPSHOT_CONSUMER] = REPORT_ID_CONSUMER;
      005DCB 90 07 D5         [24]  861 	mov	dptr,#(_input_snapshot + 0x002b)
      005DCE 04               [12]  862 	inc	a
      005DCF F0               [24]  863 	movx	@dptr,a
                                    864 ;	tmk_core/protocol/ch555/usb_ak820.c:128: for (i = 0; i < RAW_EPSIZE; ++i) pUSB_BUF_DEV0[UX_EP3_ADDR + i] = 0;
      005DD0 7F 00            [12]  865 	mov	r7,#0x00
      005DD2                        866 00105$:
      005DD2 8F 06            [24]  867 	mov	ar6,r7
      005DD4 74 C0            [12]  868 	mov	a,#0xc0
      005DD6 2E               [12]  869 	add	a, r6
      005DD7 F5 82            [12]  870 	mov	dpl,a
      005DD9 74 10            [12]  871 	mov	a,#0x10
      005DDB 24 00            [12]  872 	add	a, #0x00
      005DDD F5 83            [12]  873 	mov	dph,a
      005DDF E4               [12]  874 	clr	a
      005DE0 F0               [24]  875 	movx	@dptr,a
      005DE1 0F               [12]  876 	inc	r7
      005DE2 BF 20 00         [24]  877 	cjne	r7,#0x20,00141$
      005DE5                        878 00141$:
      005DE5 40 EB            [24]  879 	jc	00105$
                                    880 ;	tmk_core/protocol/ch555/usb_ak820.c:129: raw_abort();
                                    881 ;	tmk_core/protocol/ch555/usb_ak820.c:130: }
      005DE7 02 5D 39         [24]  882 	ljmp	_raw_abort
                                    883 ;------------------------------------------------------------
                                    884 ;Allocation info for local variables in function 'control_stall'
                                    885 ;------------------------------------------------------------
                                    886 ;	tmk_core/protocol/ch555/usb_ak820.c:132: static void control_stall(void) {
                                    887 ;	-----------------------------------------
                                    888 ;	 function control_stall
                                    889 ;	-----------------------------------------
      005DEA                        890 _control_stall:
                                    891 ;	tmk_core/protocol/ch555/usb_ak820.c:133: if (raw_state == RAW_RX) raw_state = RAW_IDLE;
      005DEA 90 07 87         [24]  892 	mov	dptr,#_raw_state
      005DED E0               [24]  893 	movx	a,@dptr
      005DEE FF               [12]  894 	mov	r7,a
      005DEF BF 01 05         [24]  895 	cjne	r7,#0x01,00102$
      005DF2 90 07 87         [24]  896 	mov	dptr,#_raw_state
      005DF5 E4               [12]  897 	clr	a
      005DF6 F0               [24]  898 	movx	@dptr,a
      005DF7                        899 00102$:
                                    900 ;	tmk_core/protocol/ch555/usb_ak820.c:134: output_kind = OUTPUT_NONE;
      005DF7 90 07 D9         [24]  901 	mov	dptr,#_output_kind
      005DFA E4               [12]  902 	clr	a
      005DFB F0               [24]  903 	movx	@dptr,a
                                    904 ;	tmk_core/protocol/ch555/usb_ak820.c:135: control_phase = CTRL_IDLE;
      005DFC 90 07 D8         [24]  905 	mov	dptr,#_control_phase
      005DFF F0               [24]  906 	movx	@dptr,a
                                    907 ;	tmk_core/protocol/ch555/usb_ak820.c:136: D0SetupReqCode = 0xff;
      005E00 90 07 79         [24]  908 	mov	dptr,#_D0SetupReqCode
      005E03 14               [12]  909 	dec	a
      005E04 F0               [24]  910 	movx	@dptr,a
                                    911 ;	tmk_core/protocol/ch555/usb_ak820.c:138: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_STALL | UEP_T_RES_STALL;
      005E05 90 22 00         [24]  912 	mov	dptr,#0x2200
      005E08 74 CF            [12]  913 	mov	a,#0xcf
      005E0A F0               [24]  914 	movx	@dptr,a
                                    915 ;	tmk_core/protocol/ch555/usb_ak820.c:139: }
      005E0B 22               [24]  916 	ret
                                    917 ;------------------------------------------------------------
                                    918 ;Allocation info for local variables in function 'control_next'
                                    919 ;------------------------------------------------------------
                                    920 ;i             Allocated with name '_control_next_i_10000_268'
                                    921 ;length        Allocated with name '_control_next_length_10000_268'
                                    922 ;------------------------------------------------------------
                                    923 ;	tmk_core/protocol/ch555/usb_ak820.c:141: static void control_next(void) {
                                    924 ;	-----------------------------------------
                                    925 ;	 function control_next
                                    926 ;	-----------------------------------------
      005E0C                        927 _control_next:
                                    928 ;	tmk_core/protocol/ch555/usb_ak820.c:143: uint8_t length = D0SetupLen > DEF_ENDP0_SIZE ? DEF_ENDP0_SIZE : D0SetupLen;
      005E0C 90 07 7A         [24]  929 	mov	dptr,#_D0SetupLen
      005E0F E0               [24]  930 	movx	a,@dptr
      005E10 FE               [12]  931 	mov	r6,a
      005E11 A3               [24]  932 	inc	dptr
      005E12 E0               [24]  933 	movx	a,@dptr
      005E13 FF               [12]  934 	mov	r7,a
      005E14 C3               [12]  935 	clr	c
      005E15 74 40            [12]  936 	mov	a,#0x40
      005E17 9E               [12]  937 	subb	a,r6
      005E18 E4               [12]  938 	clr	a
      005E19 9F               [12]  939 	subb	a,r7
      005E1A 50 04            [24]  940 	jnc	00109$
                                    941 ;	free result
      005E1C 7E 40            [12]  942 	mov	r6,#0x40
      005E1E 80 07            [24]  943 	sjmp	00110$
      005E20                        944 00109$:
      005E20 90 07 7A         [24]  945 	mov	dptr,#_D0SetupLen
      005E23 E0               [24]  946 	movx	a,@dptr
      005E24 FE               [12]  947 	mov	r6,a
      005E25 A3               [24]  948 	inc	dptr
      005E26 E0               [24]  949 	movx	a,@dptr
      005E27                        950 00110$:
                                    951 ;	tmk_core/protocol/ch555/usb_ak820.c:144: for (i = 0; i < length; ++i) pD0_EP0_BUF[i] = *control_pointer++;
      005E27 7F 00            [12]  952 	mov	r7,#0x00
      005E29                        953 00105$:
      005E29 C3               [12]  954 	clr	c
      005E2A EF               [12]  955 	mov	a,r7
      005E2B 9E               [12]  956 	subb	a,r6
      005E2C 50 2A            [24]  957 	jnc	00101$
      005E2E 8F 04            [24]  958 	mov	ar4,r7
      005E30 74 10            [12]  959 	mov	a,#0x10
      005E32 24 00            [12]  960 	add	a, #0x00
      005E34 FD               [12]  961 	mov	r5,a
      005E35 90 07 DC         [24]  962 	mov	dptr,#_control_pointer
      005E38 E0               [24]  963 	movx	a,@dptr
      005E39 FA               [12]  964 	mov	r2,a
      005E3A A3               [24]  965 	inc	dptr
      005E3B E0               [24]  966 	movx	a,@dptr
      005E3C FB               [12]  967 	mov	r3,a
      005E3D 8A 82            [24]  968 	mov	dpl,r2
      005E3F 8B 83            [24]  969 	mov	dph,r3
      005E41 E4               [12]  970 	clr	a
      005E42 93               [24]  971 	movc	a,@a+dptr
      005E43 F9               [12]  972 	mov	r1,a
      005E44 90 07 DC         [24]  973 	mov	dptr,#_control_pointer
      005E47 74 01            [12]  974 	mov	a,#0x01
      005E49 2A               [12]  975 	add	a, r2
      005E4A F0               [24]  976 	movx	@dptr,a
      005E4B E4               [12]  977 	clr	a
      005E4C 3B               [12]  978 	addc	a, r3
      005E4D A3               [24]  979 	inc	dptr
      005E4E F0               [24]  980 	movx	@dptr,a
      005E4F 8C 82            [24]  981 	mov	dpl,r4
      005E51 8D 83            [24]  982 	mov	dph,r5
      005E53 E9               [12]  983 	mov	a,r1
      005E54 F0               [24]  984 	movx	@dptr,a
      005E55 0F               [12]  985 	inc	r7
      005E56 80 D1            [24]  986 	sjmp	00105$
      005E58                        987 00101$:
                                    988 ;	tmk_core/protocol/ch555/usb_ak820.c:145: D0SetupLen -= length;
      005E58 8E 05            [24]  989 	mov	ar5,r6
      005E5A 7F 00            [12]  990 	mov	r7,#0x00
      005E5C 90 07 7A         [24]  991 	mov	dptr,#_D0SetupLen
      005E5F E0               [24]  992 	movx	a,@dptr
      005E60 FB               [12]  993 	mov	r3,a
      005E61 A3               [24]  994 	inc	dptr
      005E62 E0               [24]  995 	movx	a,@dptr
      005E63 FC               [12]  996 	mov	r4,a
      005E64 EB               [12]  997 	mov	a,r3
      005E65 C3               [12]  998 	clr	c
      005E66 9D               [12]  999 	subb	a,r5
      005E67 FB               [12] 1000 	mov	r3,a
      005E68 EC               [12] 1001 	mov	a,r4
      005E69 9F               [12] 1002 	subb	a,r7
      005E6A FC               [12] 1003 	mov	r4,a
      005E6B 90 07 7A         [24] 1004 	mov	dptr,#_D0SetupLen
      005E6E EB               [12] 1005 	mov	a,r3
      005E6F F0               [24] 1006 	movx	@dptr,a
      005E70 EC               [12] 1007 	mov	a,r4
      005E71 A3               [24] 1008 	inc	dptr
      005E72 F0               [24] 1009 	movx	@dptr,a
                                   1010 ;	tmk_core/protocol/ch555/usb_ak820.c:146: if (!length) control_zlp = 0;
      005E73 EE               [12] 1011 	mov	a,r6
      005E74 70 05            [24] 1012 	jnz	00103$
      005E76 90 07 DB         [24] 1013 	mov	dptr,#_control_zlp
      005E79 E4               [12] 1014 	clr	a
      005E7A F0               [24] 1015 	movx	@dptr,a
      005E7B                       1016 00103$:
                                   1017 ;	tmk_core/protocol/ch555/usb_ak820.c:147: D0_EP0T_L = length;
      005E7B 90 22 08         [24] 1018 	mov	dptr,#0x2208
      005E7E EE               [12] 1019 	mov	a,r6
      005E7F F0               [24] 1020 	movx	@dptr,a
                                   1021 ;	tmk_core/protocol/ch555/usb_ak820.c:148: D0_EP0RES = (D0_EP0RES & (bUEP_T_TOG | bUEP_R_TOG)) | UEP_T_RES_ACK | UEP_R_RES_ACK;
      005E80 90 22 00         [24] 1022 	mov	dptr,#0x2200
      005E83 E0               [24] 1023 	movx	a,@dptr
      005E84 54 C0            [12] 1024 	anl	a,#0xc0
      005E86 F0               [24] 1025 	movx	@dptr,a
                                   1026 ;	tmk_core/protocol/ch555/usb_ak820.c:149: }
      005E87 22               [24] 1027 	ret
                                   1028 ;------------------------------------------------------------
                                   1029 ;Allocation info for local variables in function 'descriptor_select'
                                   1030 ;------------------------------------------------------------
                                   1031 ;index         Allocated with name '_descriptor_select_PARM_2'
                                   1032 ;interface     Allocated with name '_descriptor_select_PARM_3'
                                   1033 ;type          Allocated with name '_descriptor_select_type_10000_271'
                                   1034 ;hid           Allocated with name '_descriptor_select_hid_30000_284'
                                   1035 ;------------------------------------------------------------
                                   1036 ;	tmk_core/protocol/ch555/usb_ak820.c:166: static uint16_t descriptor_select(uint8_t type, uint8_t index, uint16_t interface) {
                                   1037 ;	-----------------------------------------
                                   1038 ;	 function descriptor_select
                                   1039 ;	-----------------------------------------
      005E88                       1040 _descriptor_select:
      005E88 E5 82            [12] 1041 	mov	a,dpl
      005E8A 90 07 E1         [24] 1042 	mov	dptr,#_descriptor_select_type_10000_271
      005E8D F0               [24] 1043 	movx	@dptr,a
                                   1044 ;	tmk_core/protocol/ch555/usb_ak820.c:167: if (type == USB_DESCR_TYP_DEVICE && !index && !interface) {
      005E8E E0               [24] 1045 	movx	a,@dptr
      005E8F FF               [12] 1046 	mov	r7,a
      005E90 BF 01 20         [24] 1047 	cjne	r7,#0x01,00102$
      005E93 90 07 DE         [24] 1048 	mov	dptr,#_descriptor_select_PARM_2
      005E96 E0               [24] 1049 	movx	a,@dptr
      005E97 70 1A            [24] 1050 	jnz	00102$
      005E99 90 07 DF         [24] 1051 	mov	dptr,#_descriptor_select_PARM_3
      005E9C E0               [24] 1052 	movx	a,@dptr
      005E9D F5 F0            [12] 1053 	mov	b,a
      005E9F A3               [24] 1054 	inc	dptr
      005EA0 E0               [24] 1055 	movx	a,@dptr
      005EA1 45 F0            [12] 1056 	orl	a,b
      005EA3 70 0E            [24] 1057 	jnz	00102$
                                   1058 ;	tmk_core/protocol/ch555/usb_ak820.c:168: control_pointer = (const uint8_t __code *)&DeviceDescriptor;
      005EA5 90 07 DC         [24] 1059 	mov	dptr,#_control_pointer
      005EA8 74 2F            [12] 1060 	mov	a,#_DeviceDescriptor
      005EAA F0               [24] 1061 	movx	@dptr,a
      005EAB 74 C2            [12] 1062 	mov	a,#(_DeviceDescriptor >> 8)
      005EAD A3               [24] 1063 	inc	dptr
      005EAE F0               [24] 1064 	movx	@dptr,a
                                   1065 ;	tmk_core/protocol/ch555/usb_ak820.c:169: return sizeof(DeviceDescriptor);
      005EAF 90 00 12         [24] 1066 	mov	dptr,#0x0012
      005EB2 22               [24] 1067 	ret
      005EB3                       1068 00102$:
                                   1069 ;	tmk_core/protocol/ch555/usb_ak820.c:171: if (type == USB_DESCR_TYP_CONFIG && !index && !interface) {
      005EB3 90 07 E1         [24] 1070 	mov	dptr,#_descriptor_select_type_10000_271
      005EB6 E0               [24] 1071 	movx	a,@dptr
      005EB7 FF               [12] 1072 	mov	r7,a
      005EB8 BF 02 20         [24] 1073 	cjne	r7,#0x02,00106$
      005EBB 90 07 DE         [24] 1074 	mov	dptr,#_descriptor_select_PARM_2
      005EBE E0               [24] 1075 	movx	a,@dptr
      005EBF 70 1A            [24] 1076 	jnz	00106$
      005EC1 90 07 DF         [24] 1077 	mov	dptr,#_descriptor_select_PARM_3
      005EC4 E0               [24] 1078 	movx	a,@dptr
      005EC5 F5 F0            [12] 1079 	mov	b,a
      005EC7 A3               [24] 1080 	inc	dptr
      005EC8 E0               [24] 1081 	movx	a,@dptr
      005EC9 45 F0            [12] 1082 	orl	a,b
      005ECB 70 0E            [24] 1083 	jnz	00106$
                                   1084 ;	tmk_core/protocol/ch555/usb_ak820.c:172: control_pointer = (const uint8_t __code *)&ConfigurationDescriptor;
      005ECD 90 07 DC         [24] 1085 	mov	dptr,#_control_pointer
      005ED0 74 41            [12] 1086 	mov	a,#_ConfigurationDescriptor
      005ED2 F0               [24] 1087 	movx	@dptr,a
      005ED3 74 C2            [12] 1088 	mov	a,#(_ConfigurationDescriptor >> 8)
      005ED5 A3               [24] 1089 	inc	dptr
      005ED6 F0               [24] 1090 	movx	@dptr,a
                                   1091 ;	tmk_core/protocol/ch555/usb_ak820.c:173: return sizeof(ConfigurationDescriptor);
      005ED7 90 00 54         [24] 1092 	mov	dptr,#0x0054
      005EDA 22               [24] 1093 	ret
      005EDB                       1094 00106$:
                                   1095 ;	tmk_core/protocol/ch555/usb_ak820.c:175: if (type == USB_DESCR_TYP_STRING) {
      005EDB 90 07 E1         [24] 1096 	mov	dptr,#_descriptor_select_type_10000_271
      005EDE E0               [24] 1097 	movx	a,@dptr
      005EDF FF               [12] 1098 	mov	r7,a
      005EE0 BF 03 02         [24] 1099 	cjne	r7,#0x03,00238$
      005EE3 80 03            [24] 1100 	sjmp	00239$
      005EE5                       1101 00238$:
      005EE5 02 5F 7F         [24] 1102 	ljmp	00119$
      005EE8                       1103 00239$:
                                   1104 ;	tmk_core/protocol/ch555/usb_ak820.c:176: if (interface != 0 && interface != 0x0409) return 0;
      005EE8 90 07 DF         [24] 1105 	mov	dptr,#_descriptor_select_PARM_3
      005EEB E0               [24] 1106 	movx	a,@dptr
      005EEC FD               [12] 1107 	mov	r5,a
      005EED A3               [24] 1108 	inc	dptr
      005EEE E0               [24] 1109 	movx	a,@dptr
      005EEF FE               [12] 1110 	mov	r6,a
      005EF0 90 07 DF         [24] 1111 	mov	dptr,#_descriptor_select_PARM_3
      005EF3 E0               [24] 1112 	movx	a,@dptr
      005EF4 F5 F0            [12] 1113 	mov	b,a
      005EF6 A3               [24] 1114 	inc	dptr
      005EF7 E0               [24] 1115 	movx	a,@dptr
      005EF8 45 F0            [12] 1116 	orl	a,b
      005EFA 60 0C            [24] 1117 	jz	00110$
      005EFC BD 09 05         [24] 1118 	cjne	r5,#0x09,00241$
      005EFF BE 04 02         [24] 1119 	cjne	r6,#0x04,00241$
      005F02 80 04            [24] 1120 	sjmp	00110$
      005F04                       1121 00241$:
      005F04 90 00 00         [24] 1122 	mov	dptr,#0x0000
      005F07 22               [24] 1123 	ret
      005F08                       1124 00110$:
                                   1125 ;	tmk_core/protocol/ch555/usb_ak820.c:177: switch (index) {
      005F08 90 07 DE         [24] 1126 	mov	dptr,#_descriptor_select_PARM_2
      005F0B E0               [24] 1127 	movx	a,@dptr
      005F0C FE               [12] 1128 	mov  r6,a
      005F0D 24 FC            [12] 1129 	add	a,#0xff - 0x03
      005F0F 40 6A            [24] 1130 	jc	00116$
                                   1131 ;	free result
      005F11 EE               [12] 1132 	mov	a,r6
      005F12 2E               [12] 1133 	add	a,r6
                                   1134 ;	tmk_core/protocol/ch555/usb_ak820.c:178: case 0: control_pointer = (const uint8_t __code *)&LanguageString; return LanguageString.Header.Size;
      005F13 90 5F 17         [24] 1135 	mov	dptr,#00243$
      005F16 73               [24] 1136 	jmp	@a+dptr
      005F17                       1137 00243$:
      005F17 80 06            [24] 1138 	sjmp	00112$
      005F19 80 1B            [24] 1139 	sjmp	00113$
      005F1B 80 30            [24] 1140 	sjmp	00114$
      005F1D 80 45            [24] 1141 	sjmp	00115$
      005F1F                       1142 00112$:
      005F1F 90 07 DC         [24] 1143 	mov	dptr,#_control_pointer
      005F22 74 95            [12] 1144 	mov	a,#_LanguageString
      005F24 F0               [24] 1145 	movx	@dptr,a
      005F25 74 C2            [12] 1146 	mov	a,#(_LanguageString >> 8)
      005F27 A3               [24] 1147 	inc	dptr
      005F28 F0               [24] 1148 	movx	@dptr,a
      005F29 90 C2 95         [24] 1149 	mov	dptr,#_LanguageString
      005F2C E4               [12] 1150 	clr	a
      005F2D 93               [24] 1151 	movc	a,@a+dptr
      005F2E FE               [12] 1152 	mov	r6,a
      005F2F 7D 00            [12] 1153 	mov	r5,#0x00
      005F31 8E 82            [24] 1154 	mov	dpl, r6
      005F33 8D 83            [24] 1155 	mov	dph, r5
      005F35 22               [24] 1156 	ret
                                   1157 ;	tmk_core/protocol/ch555/usb_ak820.c:179: case 1: control_pointer = (const uint8_t __code *)&ManufacturerString; return ManufacturerString.Header.Size;
      005F36                       1158 00113$:
      005F36 90 07 DC         [24] 1159 	mov	dptr,#_control_pointer
      005F39 74 99            [12] 1160 	mov	a,#_ManufacturerString
      005F3B F0               [24] 1161 	movx	@dptr,a
      005F3C 74 C2            [12] 1162 	mov	a,#(_ManufacturerString >> 8)
      005F3E A3               [24] 1163 	inc	dptr
      005F3F F0               [24] 1164 	movx	@dptr,a
      005F40 90 C2 99         [24] 1165 	mov	dptr,#_ManufacturerString
      005F43 E4               [12] 1166 	clr	a
      005F44 93               [24] 1167 	movc	a,@a+dptr
      005F45 FE               [12] 1168 	mov	r6,a
      005F46 7D 00            [12] 1169 	mov	r5,#0x00
      005F48 8E 82            [24] 1170 	mov	dpl, r6
      005F4A 8D 83            [24] 1171 	mov	dph, r5
      005F4C 22               [24] 1172 	ret
                                   1173 ;	tmk_core/protocol/ch555/usb_ak820.c:180: case 2: control_pointer = (const uint8_t __code *)&ProductString; return ProductString.Header.Size;
      005F4D                       1174 00114$:
      005F4D 90 07 DC         [24] 1175 	mov	dptr,#_control_pointer
      005F50 74 A7            [12] 1176 	mov	a,#_ProductString
      005F52 F0               [24] 1177 	movx	@dptr,a
      005F53 74 C2            [12] 1178 	mov	a,#(_ProductString >> 8)
      005F55 A3               [24] 1179 	inc	dptr
      005F56 F0               [24] 1180 	movx	@dptr,a
      005F57 90 C2 A7         [24] 1181 	mov	dptr,#_ProductString
      005F5A E4               [12] 1182 	clr	a
      005F5B 93               [24] 1183 	movc	a,@a+dptr
      005F5C FE               [12] 1184 	mov	r6,a
      005F5D 7D 00            [12] 1185 	mov	r5,#0x00
      005F5F 8E 82            [24] 1186 	mov	dpl, r6
      005F61 8D 83            [24] 1187 	mov	dph, r5
      005F63 22               [24] 1188 	ret
                                   1189 ;	tmk_core/protocol/ch555/usb_ak820.c:182: case 3: control_pointer = (const uint8_t __code *)&SerialNumberString; return SerialNumberString.Header.Size;
      005F64                       1190 00115$:
      005F64 90 07 DC         [24] 1191 	mov	dptr,#_control_pointer
      005F67 74 DF            [12] 1192 	mov	a,#_SerialNumberString
      005F69 F0               [24] 1193 	movx	@dptr,a
      005F6A 74 C2            [12] 1194 	mov	a,#(_SerialNumberString >> 8)
      005F6C A3               [24] 1195 	inc	dptr
      005F6D F0               [24] 1196 	movx	@dptr,a
      005F6E 90 C2 DF         [24] 1197 	mov	dptr,#_SerialNumberString
      005F71 E4               [12] 1198 	clr	a
      005F72 93               [24] 1199 	movc	a,@a+dptr
      005F73 FE               [12] 1200 	mov	r6,a
      005F74 7D 00            [12] 1201 	mov	r5,#0x00
      005F76 8E 82            [24] 1202 	mov	dpl, r6
      005F78 8D 83            [24] 1203 	mov	dph, r5
      005F7A 22               [24] 1204 	ret
                                   1205 ;	tmk_core/protocol/ch555/usb_ak820.c:184: default: return 0;
      005F7B                       1206 00116$:
      005F7B 90 00 00         [24] 1207 	mov	dptr,#0x0000
      005F7E 22               [24] 1208 	ret
                                   1209 ;	tmk_core/protocol/ch555/usb_ak820.c:185: }
      005F7F                       1210 00119$:
                                   1211 ;	tmk_core/protocol/ch555/usb_ak820.c:187: if (index || interface >= TOTAL_INTERFACES) return 0;
      005F7F 90 07 DE         [24] 1212 	mov	dptr,#_descriptor_select_PARM_2
      005F82 E0               [24] 1213 	movx	a,@dptr
      005F83 70 11            [24] 1214 	jnz	00120$
      005F85 90 07 DF         [24] 1215 	mov	dptr,#_descriptor_select_PARM_3
      005F88 E0               [24] 1216 	movx	a,@dptr
      005F89 FD               [12] 1217 	mov	r5,a
      005F8A A3               [24] 1218 	inc	dptr
      005F8B E0               [24] 1219 	movx	a,@dptr
      005F8C FE               [12] 1220 	mov	r6,a
      005F8D C3               [12] 1221 	clr	c
      005F8E ED               [12] 1222 	mov	a,r5
      005F8F 94 03            [12] 1223 	subb	a,#0x03
      005F91 EE               [12] 1224 	mov	a,r6
      005F92 94 00            [12] 1225 	subb	a,#0x00
      005F94 40 04            [24] 1226 	jc	00121$
      005F96                       1227 00120$:
      005F96 90 00 00         [24] 1228 	mov	dptr,#0x0000
      005F99 22               [24] 1229 	ret
      005F9A                       1230 00121$:
                                   1231 ;	tmk_core/protocol/ch555/usb_ak820.c:188: if (type == USB_DESCR_TYP_REPORT || type == USB_DESCR_TYP_HID) {
      005F9A BF 22 02         [24] 1232 	cjne	r7,#0x22,00246$
      005F9D 80 03            [24] 1233 	sjmp	00127$
      005F9F                       1234 00246$:
      005F9F BF 21 5D         [24] 1235 	cjne	r7,#0x21,00128$
      005FA2                       1236 00127$:
                                   1237 ;	tmk_core/protocol/ch555/usb_ak820.c:189: const USB_HID_Descriptor_HID_t __code *hid = interface_descriptors[(uint8_t)interface].hid;
      005FA2 ED               [12] 1238 	mov	a,r5
      005FA3 75 F0 04         [24] 1239 	mov	b,#0x04
      005FA6 A4               [48] 1240 	mul	ab
      005FA7 24 B8            [12] 1241 	add	a, #_interface_descriptors
      005FA9 FE               [12] 1242 	mov	r6,a
      005FAA 74 BB            [12] 1243 	mov	a,#(_interface_descriptors >> 8)
      005FAC 35 F0            [12] 1244 	addc	a, b
      005FAE FF               [12] 1245 	mov	r7,a
      005FAF 8E 82            [24] 1246 	mov	dpl,r6
      005FB1 8F 83            [24] 1247 	mov	dph,r7
      005FB3 A3               [24] 1248 	inc	dptr
      005FB4 A3               [24] 1249 	inc	dptr
      005FB5 E4               [12] 1250 	clr	a
      005FB6 93               [24] 1251 	movc	a,@a+dptr
      005FB7 FC               [12] 1252 	mov	r4,a
      005FB8 A3               [24] 1253 	inc	dptr
      005FB9 E4               [12] 1254 	clr	a
      005FBA 93               [24] 1255 	movc	a,@a+dptr
                                   1256 ;	tmk_core/protocol/ch555/usb_ak820.c:190: if (!hid) return 0;
      005FBB FD               [12] 1257 	mov	r5,a
      005FBC 4C               [12] 1258 	orl	a,r4
      005FBD 70 04            [24] 1259 	jnz	00124$
      005FBF 90 00 00         [24] 1260 	mov	dptr,#0x0000
      005FC2 22               [24] 1261 	ret
      005FC3                       1262 00124$:
                                   1263 ;	tmk_core/protocol/ch555/usb_ak820.c:191: if (type == USB_DESCR_TYP_REPORT) {
      005FC3 90 07 E1         [24] 1264 	mov	dptr,#_descriptor_select_type_10000_271
      005FC6 E0               [24] 1265 	movx	a,@dptr
      005FC7 FB               [12] 1266 	mov	r3,a
      005FC8 BB 22 28         [24] 1267 	cjne	r3,#0x22,00126$
                                   1268 ;	tmk_core/protocol/ch555/usb_ak820.c:192: control_pointer = interface_descriptors[(uint8_t)interface].report;
      005FCB 8E 82            [24] 1269 	mov	dpl,r6
      005FCD 8F 83            [24] 1270 	mov	dph,r7
      005FCF E4               [12] 1271 	clr	a
      005FD0 93               [24] 1272 	movc	a,@a+dptr
      005FD1 FE               [12] 1273 	mov	r6,a
      005FD2 A3               [24] 1274 	inc	dptr
      005FD3 E4               [12] 1275 	clr	a
      005FD4 93               [24] 1276 	movc	a,@a+dptr
      005FD5 FF               [12] 1277 	mov	r7,a
      005FD6 90 07 DC         [24] 1278 	mov	dptr,#_control_pointer
      005FD9 EE               [12] 1279 	mov	a,r6
      005FDA F0               [24] 1280 	movx	@dptr,a
      005FDB EF               [12] 1281 	mov	a,r7
      005FDC A3               [24] 1282 	inc	dptr
      005FDD F0               [24] 1283 	movx	@dptr,a
                                   1284 ;	tmk_core/protocol/ch555/usb_ak820.c:193: return hid->HIDReportLength;
      005FDE 74 07            [12] 1285 	mov	a,#0x07
      005FE0 2C               [12] 1286 	add	a, r4
      005FE1 F5 82            [12] 1287 	mov	dpl,a
      005FE3 E4               [12] 1288 	clr	a
      005FE4 3D               [12] 1289 	addc	a, r5
      005FE5 F5 83            [12] 1290 	mov	dph,a
      005FE7 E4               [12] 1291 	clr	a
      005FE8 93               [24] 1292 	movc	a,@a+dptr
      005FE9 FE               [12] 1293 	mov	r6,a
      005FEA A3               [24] 1294 	inc	dptr
      005FEB E4               [12] 1295 	clr	a
      005FEC 93               [24] 1296 	movc	a,@a+dptr
      005FED FF               [12] 1297 	mov	r7,a
      005FEE 8E 82            [24] 1298 	mov	dpl, r6
      005FF0 8F 83            [24] 1299 	mov	dph, r7
      005FF2 22               [24] 1300 	ret
      005FF3                       1301 00126$:
                                   1302 ;	tmk_core/protocol/ch555/usb_ak820.c:195: control_pointer = (const uint8_t __code *)hid;
      005FF3 90 07 DC         [24] 1303 	mov	dptr,#_control_pointer
      005FF6 EC               [12] 1304 	mov	a,r4
      005FF7 F0               [24] 1305 	movx	@dptr,a
      005FF8 ED               [12] 1306 	mov	a,r5
      005FF9 A3               [24] 1307 	inc	dptr
      005FFA F0               [24] 1308 	movx	@dptr,a
                                   1309 ;	tmk_core/protocol/ch555/usb_ak820.c:196: return 9;
      005FFB 90 00 09         [24] 1310 	mov	dptr,#0x0009
      005FFE 22               [24] 1311 	ret
      005FFF                       1312 00128$:
                                   1313 ;	tmk_core/protocol/ch555/usb_ak820.c:198: return 0;
      005FFF 90 00 00         [24] 1314 	mov	dptr,#0x0000
                                   1315 ;	tmk_core/protocol/ch555/usb_ak820.c:199: }
      006002 22               [24] 1316 	ret
                                   1317 ;------------------------------------------------------------
                                   1318 ;Allocation info for local variables in function 'control_setup'
                                   1319 ;------------------------------------------------------------
                                   1320 ;sloc1         Allocated with name '_control_setup_sloc1_1_0'
                                   1321 ;sloc3         Allocated with name '_control_setup_sloc3_1_0'
                                   1322 ;sloc4         Allocated with name '_control_setup_sloc4_1_0'
                                   1323 ;type          Allocated with name '_control_setup_type_10000_289'
                                   1324 ;value         Allocated with name '_control_setup_value_10000_289'
                                   1325 ;index         Allocated with name '_control_setup_index_10000_289'
                                   1326 ;length        Allocated with name '_control_setup_length_10000_289'
                                   1327 ;endpoint      Allocated with name '_control_setup_endpoint_10000_289'
                                   1328 ;i             Allocated with name '_control_setup_i_10000_289'
                                   1329 ;offset        Allocated with name '_control_setup_offset_10000_289'
                                   1330 ;report_id     Allocated with name '_control_setup_report_id_10000_289'
                                   1331 ;------------------------------------------------------------
                                   1332 ;	tmk_core/protocol/ch555/usb_ak820.c:201: static void control_setup(void) {
                                   1333 ;	-----------------------------------------
                                   1334 ;	 function control_setup
                                   1335 ;	-----------------------------------------
      006003                       1336 _control_setup:
                                   1337 ;	tmk_core/protocol/ch555/usb_ak820.c:202: uint8_t type = pD0_SETUP_REQ->bRequestType;
      006003 90 10 00         [24] 1338 	mov	dptr,#0x1000
      006006 E0               [24] 1339 	movx	a,@dptr
      006007 FF               [12] 1340 	mov	r7,a
                                   1341 ;	tmk_core/protocol/ch555/usb_ak820.c:203: uint16_t value = pD0_SETUP_REQ->wValueL | ((uint16_t)pD0_SETUP_REQ->wValueH << 8);
      006008 A3               [24] 1342 	inc	dptr
      006009 A3               [24] 1343 	inc	dptr
      00600A E0               [24] 1344 	movx	a,@dptr
      00600B FE               [12] 1345 	mov	r6,a
      00600C A3               [24] 1346 	inc	dptr
      00600D E0               [24] 1347 	movx	a,@dptr
      00600E FC               [12] 1348 	mov	r4,a
      00600F 7D 00            [12] 1349 	mov	r5,#0x00
      006011 8E 03            [24] 1350 	mov	ar3,r6
      006013 7E 00            [12] 1351 	mov	r6,#0x00
      006015 ED               [12] 1352 	mov	a,r5
      006016 4B               [12] 1353 	orl	a,r3
      006017 FD               [12] 1354 	mov	r5,a
      006018 EC               [12] 1355 	mov	a,r4
      006019 4E               [12] 1356 	orl	a,r6
      00601A FE               [12] 1357 	mov	r6,a
                                   1358 ;	tmk_core/protocol/ch555/usb_ak820.c:204: uint16_t index = pD0_SETUP_REQ->wIndexL | ((uint16_t)pD0_SETUP_REQ->wIndexH << 8);
      00601B A3               [24] 1359 	inc	dptr
      00601C E0               [24] 1360 	movx	a,@dptr
      00601D FC               [12] 1361 	mov	r4,a
      00601E A3               [24] 1362 	inc	dptr
      00601F E0               [24] 1363 	movx	a,@dptr
      006020 FA               [12] 1364 	mov	r2,a
      006021 7B 00            [12] 1365 	mov	r3,#0x00
      006023 8C 01            [24] 1366 	mov	ar1,r4
      006025 7C 00            [12] 1367 	mov	r4,#0x00
      006027 EB               [12] 1368 	mov	a,r3
      006028 49               [12] 1369 	orl	a,r1
      006029 FB               [12] 1370 	mov	r3,a
      00602A EA               [12] 1371 	mov	a,r2
      00602B 4C               [12] 1372 	orl	a,r4
      00602C FC               [12] 1373 	mov	r4,a
                                   1374 ;	tmk_core/protocol/ch555/usb_ak820.c:208: __bit valid_interface = index < TOTAL_INTERFACES;
      00602D C3               [12] 1375 	clr	c
      00602E EB               [12] 1376 	mov	a,r3
      00602F 94 03            [12] 1377 	subb	a,#0x03
      006031 EC               [12] 1378 	mov	a,r4
      006032 94 00            [12] 1379 	subb	a,#0x00
      006034 92 15            [24] 1380 	mov	_control_setup_valid_interface_10000_289,c
                                   1381 ;	tmk_core/protocol/ch555/usb_ak820.c:209: __bit zero_index = !index;
      006036 EB               [12] 1382 	mov	a,r3
      006037 4C               [12] 1383 	orl	a,r4
      006038 B4 01 00         [24] 1384 	cjne	a,#0x01,01201$
      00603B                       1385 01201$:
      00603B 92 16            [24] 1386 	mov	_control_setup_zero_index_10000_289,c
                                   1387 ;	tmk_core/protocol/ch555/usb_ak820.c:210: __bit zero_value = !value;
      00603D ED               [12] 1388 	mov	a,r5
      00603E 4E               [12] 1389 	orl	a,r6
      00603F B4 01 00         [24] 1390 	cjne	a,#0x01,01202$
      006042                       1391 01202$:
                                   1392 ;	assignBit
      006042 92 19            [24] 1393 	mov  _control_setup_sloc0_1_0,c
      006044 92 17            [24] 1394 	mov	_control_setup_zero_value_10000_289,c
                                   1395 ;	tmk_core/protocol/ch555/usb_ak820.c:214: uint8_t offset = 0;
      006046 90 07 E4         [24] 1396 	mov	dptr,#_control_setup_offset_10000_289
      006049 E4               [12] 1397 	clr	a
      00604A F0               [24] 1398 	movx	@dptr,a
                                   1399 ;	tmk_core/protocol/ch555/usb_ak820.c:216: if (raw_state == RAW_RX) raw_state = RAW_IDLE; /* abort only unfinished OUT */
      00604B 90 07 87         [24] 1400 	mov	dptr,#_raw_state
      00604E E0               [24] 1401 	movx	a,@dptr
      00604F FA               [12] 1402 	mov	r2,a
      006050 BA 01 05         [24] 1403 	cjne	r2,#0x01,00102$
      006053 90 07 87         [24] 1404 	mov	dptr,#_raw_state
      006056 E4               [12] 1405 	clr	a
      006057 F0               [24] 1406 	movx	@dptr,a
      006058                       1407 00102$:
                                   1408 ;	tmk_core/protocol/ch555/usb_ak820.c:217: output_kind = OUTPUT_NONE;
      006058 C0 07            [24] 1409 	push	ar7
      00605A 90 07 D9         [24] 1410 	mov	dptr,#_output_kind
      00605D E4               [12] 1411 	clr	a
      00605E F0               [24] 1412 	movx	@dptr,a
                                   1413 ;	tmk_core/protocol/ch555/usb_ak820.c:218: control_phase = CTRL_IDLE;
      00605F 90 07 D8         [24] 1414 	mov	dptr,#_control_phase
      006062 F0               [24] 1415 	movx	@dptr,a
                                   1416 ;	tmk_core/protocol/ch555/usb_ak820.c:219: control_zlp = 0;
      006063 90 07 DB         [24] 1417 	mov	dptr,#_control_zlp
      006066 F0               [24] 1418 	movx	@dptr,a
                                   1419 ;	tmk_core/protocol/ch555/usb_ak820.c:220: D0SetupReqCode = pD0_SETUP_REQ->bRequest;
      006067 90 10 01         [24] 1420 	mov	dptr,#0x1001
      00606A E0               [24] 1421 	movx	a,@dptr
      00606B 90 07 79         [24] 1422 	mov	dptr,#_D0SetupReqCode
      00606E F0               [24] 1423 	movx	@dptr,a
                                   1424 ;	tmk_core/protocol/ch555/usb_ak820.c:221: D0SetupLen = pD0_SETUP_REQ->wLengthL | ((uint16_t)pD0_SETUP_REQ->wLengthH << 8);
      00606F 90 10 06         [24] 1425 	mov	dptr,#0x1006
      006072 E0               [24] 1426 	movx	a,@dptr
      006073 FA               [12] 1427 	mov	r2,a
      006074 A3               [24] 1428 	inc	dptr
      006075 E0               [24] 1429 	movx	a,@dptr
      006076 F9               [12] 1430 	mov	r1,a
      006077 78 00            [12] 1431 	mov	r0,#0x00
      006079 7F 00            [12] 1432 	mov	r7,#0x00
      00607B 90 07 7A         [24] 1433 	mov	dptr,#_D0SetupLen
      00607E E8               [12] 1434 	mov	a,r0
      00607F 4A               [12] 1435 	orl	a,r2
      006080 F0               [24] 1436 	movx	@dptr,a
      006081 E9               [12] 1437 	mov	a,r1
      006082 4F               [12] 1438 	orl	a,r7
      006083 A3               [24] 1439 	inc	dptr
      006084 F0               [24] 1440 	movx	@dptr,a
                                   1441 ;	tmk_core/protocol/ch555/usb_ak820.c:222: zero_length = !D0SetupLen;
      006085 90 07 7A         [24] 1442 	mov	dptr,#_D0SetupLen
      006088 E0               [24] 1443 	movx	a,@dptr
      006089 FA               [12] 1444 	mov	r2,a
      00608A A3               [24] 1445 	inc	dptr
      00608B E0               [24] 1446 	movx	a,@dptr
      00608C 4A               [12] 1447 	orl	a,r2
      00608D B4 01 00         [24] 1448 	cjne	a,#0x01,01205$
      006090                       1449 01205$:
      006090 92 18            [24] 1450 	mov	_control_setup_zero_length_10000_289,c
                                   1451 ;	tmk_core/protocol/ch555/usb_ak820.c:223: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_ACK | UEP_T_RES_NAK;
      006092 90 22 00         [24] 1452 	mov	dptr,#0x2200
      006095 74 C2            [12] 1453 	mov	a,#0xc2
      006097 F0               [24] 1454 	movx	@dptr,a
                                   1455 ;	tmk_core/protocol/ch555/usb_ak820.c:224: D0_EP0T_L = 0;
      006098 90 22 08         [24] 1456 	mov	dptr,#0x2208
      00609B E4               [12] 1457 	clr	a
      00609C F0               [24] 1458 	movx	@dptr,a
                                   1459 ;	tmk_core/protocol/ch555/usb_ak820.c:228: switch (D0SetupReqCode) {
      00609D 90 07 79         [24] 1460 	mov	dptr,#_D0SetupReqCode
      0060A0 E0               [24] 1461 	movx	a,@dptr
      0060A1 F5 16            [12] 1462 	mov	_control_setup_sloc1_1_0,a
      0060A3 C3               [12] 1463 	clr	c
      0060A4 74 0B            [12] 1464 	mov	a,#0x0b
      0060A6 95 16            [12] 1465 	subb	a,_control_setup_sloc1_1_0
      0060A8 D0 07            [24] 1466 	pop	ar7
      0060AA 50 03            [24] 1467 	jnc	01206$
      0060AC 02 5D EA         [24] 1468 	ljmp	_control_stall
      0060AF                       1469 01206$:
                                   1470 ;	free result
      0060AF E5 16            [12] 1471 	mov	a,_control_setup_sloc1_1_0
      0060B1 F5 F0            [12] 1472 	mov	b,a
      0060B3 24 0B            [12] 1473 	add	a,#(01207$-3-.)
      0060B5 83               [24] 1474 	movc	a,@a+pc
      0060B6 F5 82            [12] 1475 	mov	dpl,a
      0060B8 E5 F0            [12] 1476 	mov	a,b
      0060BA 24 10            [12] 1477 	add	a,#(01208$-3-.)
      0060BC 83               [24] 1478 	movc	a,@a+pc
      0060BD F5 83            [12] 1479 	mov	dph,a
      0060BF E4               [12] 1480 	clr	a
      0060C0 73               [24] 1481 	jmp	@a+dptr
      0060C1                       1482 01207$:
      0060C1 69                    1483 	.db	00188$
      0060C2 0F                    1484 	.db	00205$
      0060C3 52                    1485 	.db	00282$
      0060C4 0F                    1486 	.db	00205$
      0060C5 96                    1487 	.db	00290$
      0060C6 93                    1488 	.db	00116$
      0060C7 D9                    1489 	.db	00103$
      0060C8 96                    1490 	.db	00290$
      0060C9 98                    1491 	.db	00150$
      0060CA BC                    1492 	.db	00123$
      0060CB C8                    1493 	.db	00157$
      0060CC 1B                    1494 	.db	00173$
      0060CD                       1495 01208$:
      0060CD 63                    1496 	.db	00188$>>8
      0060CE 64                    1497 	.db	00205$>>8
      0060CF 67                    1498 	.db	00282$>>8
      0060D0 64                    1499 	.db	00205$>>8
      0060D1 67                    1500 	.db	00290$>>8
      0060D2 61                    1501 	.db	00116$>>8
      0060D3 60                    1502 	.db	00103$>>8
      0060D4 67                    1503 	.db	00290$>>8
      0060D5 62                    1504 	.db	00150$>>8
      0060D6 61                    1505 	.db	00123$>>8
      0060D7 62                    1506 	.db	00157$>>8
      0060D8 63                    1507 	.db	00173$>>8
                                   1508 ;	tmk_core/protocol/ch555/usb_ak820.c:229: case USB_GET_DESCRIPTOR:
      0060D9                       1509 00103$:
                                   1510 ;	tmk_core/protocol/ch555/usb_ak820.c:230: if (type == 0x80 || type == 0x81) {
      0060D9 BF 80 02         [24] 1511 	cjne	r7,#0x80,01209$
      0060DC 80 08            [24] 1512 	sjmp	00112$
      0060DE                       1513 01209$:
      0060DE BF 81 02         [24] 1514 	cjne	r7,#0x81,01210$
      0060E1 80 03            [24] 1515 	sjmp	01211$
      0060E3                       1516 01210$:
      0060E3 02 5D EA         [24] 1517 	ljmp	_control_stall
      0060E6                       1518 01211$:
      0060E6                       1519 00112$:
                                   1520 ;	tmk_core/protocol/ch555/usb_ak820.c:231: if (((value >> 8) == USB_DESCR_TYP_HID || (value >> 8) == USB_DESCR_TYP_REPORT) != (type == 0x81)) {
      0060E6 8E 01            [24] 1521 	mov	ar1,r6
      0060E8 B9 21 02         [24] 1522 	cjne	r1,#0x21,01212$
      0060EB 80 09            [24] 1523 	sjmp	00301$
      0060ED                       1524 01212$:
      0060ED B9 22 02         [24] 1525 	cjne	r1,#0x22,01213$
      0060F0 80 04            [24] 1526 	sjmp	00301$
      0060F2                       1527 01213$:
                                   1528 ;	assignBit
      0060F2 C2 1A            [12] 1529 	clr	_control_setup_sloc2_1_0
      0060F4 80 02            [24] 1530 	sjmp	00302$
      0060F6                       1531 00301$:
                                   1532 ;	assignBit
      0060F6 D2 1A            [12] 1533 	setb	_control_setup_sloc2_1_0
      0060F8                       1534 00302$:
      0060F8 E4               [12] 1535 	clr	a
      0060F9 BF 81 01         [24] 1536 	cjne	r7,#0x81,01214$
      0060FC 04               [12] 1537 	inc	a
      0060FD                       1538 01214$:
      0060FD FA               [12] 1539 	mov	r2,a
      0060FE A2 1A            [12] 1540 	mov	c,_control_setup_sloc2_1_0
      006100 E4               [12] 1541 	clr	a
      006101 33               [12] 1542 	rlc	a
      006102 B5 02 02         [24] 1543 	cjne	a,ar2,01216$
      006105 80 03            [24] 1544 	sjmp	00105$
      006107                       1545 01216$:
                                   1546 ;	tmk_core/protocol/ch555/usb_ak820.c:232: control_stall(); return;
      006107 02 5D EA         [24] 1547 	ljmp	_control_stall
      00610A                       1548 00105$:
                                   1549 ;	tmk_core/protocol/ch555/usb_ak820.c:234: length = descriptor_select(value >> 8, value, index);
      00610A 8E 02            [24] 1550 	mov	ar2,r6
      00610C 90 07 DE         [24] 1551 	mov	dptr,#_descriptor_select_PARM_2
      00610F ED               [12] 1552 	mov	a,r5
      006110 F0               [24] 1553 	movx	@dptr,a
      006111 90 07 DF         [24] 1554 	mov	dptr,#_descriptor_select_PARM_3
      006114 EB               [12] 1555 	mov	a,r3
      006115 F0               [24] 1556 	movx	@dptr,a
      006116 EC               [12] 1557 	mov	a,r4
      006117 A3               [24] 1558 	inc	dptr
      006118 F0               [24] 1559 	movx	@dptr,a
      006119 8A 82            [24] 1560 	mov	dpl, r2
      00611B 12 5E 88         [24] 1561 	lcall	_descriptor_select
      00611E 85 82 17         [24] 1562 	mov	_control_setup_sloc3_1_0,dpl
      006121 85 83 18         [24] 1563 	mov	(_control_setup_sloc3_1_0 + 1),dph
                                   1564 ;	tmk_core/protocol/ch555/usb_ak820.c:235: if (!length) { control_stall(); return; }
      006124 E5 17            [12] 1565 	mov	a,_control_setup_sloc3_1_0
      006126 45 18            [12] 1566 	orl	a,(_control_setup_sloc3_1_0 + 1)
      006128 70 03            [24] 1567 	jnz	00107$
      00612A 02 5D EA         [24] 1568 	ljmp	_control_stall
      00612D                       1569 00107$:
                                   1570 ;	tmk_core/protocol/ch555/usb_ak820.c:236: control_zlp = length < D0SetupLen && !(length & (DEF_ENDP0_SIZE - 1));
      00612D 90 07 7A         [24] 1571 	mov	dptr,#_D0SetupLen
      006130 E0               [24] 1572 	movx	a,@dptr
      006131 F8               [12] 1573 	mov	r0,a
      006132 A3               [24] 1574 	inc	dptr
      006133 E0               [24] 1575 	movx	a,@dptr
      006134 FA               [12] 1576 	mov	r2,a
      006135 C3               [12] 1577 	clr	c
      006136 E5 17            [12] 1578 	mov	a,_control_setup_sloc3_1_0
      006138 98               [12] 1579 	subb	a,r0
      006139 E5 18            [12] 1580 	mov	a,(_control_setup_sloc3_1_0 + 1)
      00613B 9A               [12] 1581 	subb	a,r2
      00613C 50 06            [24] 1582 	jnc	00303$
      00613E E5 17            [12] 1583 	mov	a,_control_setup_sloc3_1_0
      006140 54 3F            [12] 1584 	anl	a,#0x3f
      006142 60 04            [24] 1585 	jz	00304$
      006144                       1586 00303$:
                                   1587 ;	assignBit
      006144 C2 1A            [12] 1588 	clr	_control_setup_sloc2_1_0
      006146 80 02            [24] 1589 	sjmp	00305$
      006148                       1590 00304$:
                                   1591 ;	assignBit
      006148 D2 1A            [12] 1592 	setb	_control_setup_sloc2_1_0
      00614A                       1593 00305$:
      00614A 90 07 DB         [24] 1594 	mov	dptr,#_control_zlp
      00614D A2 1A            [12] 1595 	mov	c,_control_setup_sloc2_1_0
      00614F E4               [12] 1596 	clr	a
      006150 33               [12] 1597 	rlc	a
      006151 F0               [24] 1598 	movx	@dptr,a
                                   1599 ;	tmk_core/protocol/ch555/usb_ak820.c:237: if (D0SetupLen > length) D0SetupLen = length;
      006152 90 07 7A         [24] 1600 	mov	dptr,#_D0SetupLen
      006155 E0               [24] 1601 	movx	a,@dptr
      006156 F9               [12] 1602 	mov	r1,a
      006157 A3               [24] 1603 	inc	dptr
      006158 E0               [24] 1604 	movx	a,@dptr
      006159 FA               [12] 1605 	mov	r2,a
      00615A C3               [12] 1606 	clr	c
      00615B E5 17            [12] 1607 	mov	a,_control_setup_sloc3_1_0
      00615D 99               [12] 1608 	subb	a,r1
      00615E E5 18            [12] 1609 	mov	a,(_control_setup_sloc3_1_0 + 1)
      006160 9A               [12] 1610 	subb	a,r2
      006161 50 0A            [24] 1611 	jnc	00109$
                                   1612 ;	free result
      006163 90 07 7A         [24] 1613 	mov	dptr,#_D0SetupLen
      006166 E5 17            [12] 1614 	mov	a,_control_setup_sloc3_1_0
      006168 F0               [24] 1615 	movx	@dptr,a
      006169 E5 18            [12] 1616 	mov	a,(_control_setup_sloc3_1_0 + 1)
      00616B A3               [24] 1617 	inc	dptr
      00616C F0               [24] 1618 	movx	@dptr,a
      00616D                       1619 00109$:
                                   1620 ;	tmk_core/protocol/ch555/usb_ak820.c:238: control_phase = D0SetupLen ? CTRL_DATA_IN : CTRL_STATUS_OUT;
      00616D 90 07 7A         [24] 1621 	mov	dptr,#_D0SetupLen
      006170 E0               [24] 1622 	movx	a,@dptr
      006171 F9               [12] 1623 	mov	r1,a
      006172 A3               [24] 1624 	inc	dptr
      006173 E0               [24] 1625 	movx	a,@dptr
      006174 49               [12] 1626 	orl	a,r1
      006175 60 04            [24] 1627 	jz	00306$
      006177 7A 01            [12] 1628 	mov	r2,#0x01
      006179 80 02            [24] 1629 	sjmp	00307$
      00617B                       1630 00306$:
      00617B 7A 02            [12] 1631 	mov	r2,#0x02
      00617D                       1632 00307$:
      00617D 90 07 D8         [24] 1633 	mov	dptr,#_control_phase
      006180 EA               [12] 1634 	mov	a,r2
      006181 F0               [24] 1635 	movx	@dptr,a
                                   1636 ;	tmk_core/protocol/ch555/usb_ak820.c:239: if (D0SetupLen) control_next();
      006182 90 07 7A         [24] 1637 	mov	dptr,#_D0SetupLen
      006185 E0               [24] 1638 	movx	a,@dptr
      006186 F9               [12] 1639 	mov	r1,a
      006187 A3               [24] 1640 	inc	dptr
      006188 E0               [24] 1641 	movx	a,@dptr
      006189 49               [12] 1642 	orl	a,r1
      00618A 60 03            [24] 1643 	jz	00111$
                                   1644 ;	tmk_core/protocol/ch555/usb_ak820.c:240: return;
      00618C 02 5E 0C         [24] 1645 	ljmp	_control_next
      00618F                       1646 00111$:
      00618F 22               [24] 1647 	ret
                                   1648 ;	tmk_core/protocol/ch555/usb_ak820.c:241: } else { control_stall(); return; }
      006190 02 5D EA         [24] 1649 	ljmp	_control_stall
                                   1650 ;	tmk_core/protocol/ch555/usb_ak820.c:242: case USB_SET_ADDRESS:
      006193                       1651 00116$:
                                   1652 ;	tmk_core/protocol/ch555/usb_ak820.c:243: if (type == 0x00 && zero_index && zero_length && value <= 127) {
      006193 EF               [12] 1653 	mov	a,r7
      006194 70 23            [24] 1654 	jnz	00118$
      006196 30 16 20         [24] 1655 	jnb	_control_setup_zero_index_10000_289,00118$
      006199 30 18 1D         [24] 1656 	jnb	_control_setup_zero_length_10000_289,00118$
      00619C 8D 01            [24] 1657 	mov	ar1,r5
      00619E 8E 02            [24] 1658 	mov	ar2,r6
      0061A0 C3               [12] 1659 	clr	c
      0061A1 74 7F            [12] 1660 	mov	a,#0x7f
      0061A3 99               [12] 1661 	subb	a,r1
      0061A4 E4               [12] 1662 	clr	a
      0061A5 9A               [12] 1663 	subb	a,r2
      0061A6 40 11            [24] 1664 	jc	00118$
                                   1665 ;	free result
                                   1666 ;	tmk_core/protocol/ch555/usb_ak820.c:244: D0SetupLen = value; /* applied after status-IN ACK */
      0061A8 90 07 7A         [24] 1667 	mov	dptr,#_D0SetupLen
      0061AB ED               [12] 1668 	mov	a,r5
      0061AC F0               [24] 1669 	movx	@dptr,a
      0061AD EE               [12] 1670 	mov	a,r6
      0061AE A3               [24] 1671 	inc	dptr
      0061AF F0               [24] 1672 	movx	@dptr,a
                                   1673 ;	tmk_core/protocol/ch555/usb_ak820.c:245: control_phase = CTRL_STATUS_IN;
      0061B0 90 07 D8         [24] 1674 	mov	dptr,#_control_phase
      0061B3 74 03            [12] 1675 	mov	a,#0x03
      0061B5 F0               [24] 1676 	movx	@dptr,a
      0061B6 02 67 99         [24] 1677 	ljmp	00291$
      0061B9                       1678 00118$:
                                   1679 ;	tmk_core/protocol/ch555/usb_ak820.c:246: } else { control_stall(); return; }
      0061B9 02 5D EA         [24] 1680 	ljmp	_control_stall
                                   1681 ;	tmk_core/protocol/ch555/usb_ak820.c:248: case USB_SET_CONFIGURATION: /* HID_SET_REPORT has the same request byte. */
      0061BC                       1682 00123$:
                                   1683 ;	tmk_core/protocol/ch555/usb_ak820.c:249: if (type == 0x00 && zero_index && zero_length && value <= 1) {
      0061BC EF               [12] 1684 	mov	a,r7
      0061BD 70 3C            [24] 1685 	jnz	00145$
      0061BF 30 16 39         [24] 1686 	jnb	_control_setup_zero_index_10000_289,00145$
      0061C2 30 18 36         [24] 1687 	jnb	_control_setup_zero_length_10000_289,00145$
      0061C5 8D 01            [24] 1688 	mov	ar1,r5
      0061C7 8E 02            [24] 1689 	mov	ar2,r6
      0061C9 C3               [12] 1690 	clr	c
      0061CA 74 01            [12] 1691 	mov	a,#0x01
      0061CC 99               [12] 1692 	subb	a,r1
      0061CD E4               [12] 1693 	clr	a
      0061CE 9A               [12] 1694 	subb	a,r2
      0061CF 40 2A            [24] 1695 	jc	00145$
                                   1696 ;	free result
                                   1697 ;	tmk_core/protocol/ch555/usb_ak820.c:250: endpoints_reset();
      0061D1 C0 06            [24] 1698 	push	ar6
      0061D3 C0 05            [24] 1699 	push	ar5
      0061D5 12 5D 8F         [24] 1700 	lcall	_endpoints_reset
      0061D8 D0 05            [24] 1701 	pop	ar5
      0061DA D0 06            [24] 1702 	pop	ar6
                                   1703 ;	tmk_core/protocol/ch555/usb_ak820.c:251: D0UsbConfig = value;
      0061DC 90 07 7F         [24] 1704 	mov	dptr,#_D0UsbConfig
      0061DF ED               [12] 1705 	mov	a,r5
      0061E0 F0               [24] 1706 	movx	@dptr,a
                                   1707 ;	tmk_core/protocol/ch555/usb_ak820.c:252: USB_EnumStatus = value != 0;
      0061E1 A2 19            [12] 1708 	mov	c,_control_setup_sloc0_1_0
      0061E3 B3               [12] 1709 	cpl	c
      0061E4 92 1A            [24] 1710 	mov	_control_setup_sloc2_1_0,c
      0061E6 90 07 80         [24] 1711 	mov	dptr,#_USB_EnumStatus
      0061E9 E4               [12] 1712 	clr	a
      0061EA 33               [12] 1713 	rlc	a
      0061EB F0               [24] 1714 	movx	@dptr,a
                                   1715 ;	tmk_core/protocol/ch555/usb_ak820.c:253: keyboard_reset = 1;
      0061EC 90 07 A9         [24] 1716 	mov	dptr,#_keyboard_reset
      0061EF 74 01            [12] 1717 	mov	a,#0x01
      0061F1 F0               [24] 1718 	movx	@dptr,a
                                   1719 ;	tmk_core/protocol/ch555/usb_ak820.c:254: control_phase = CTRL_STATUS_IN;
      0061F2 90 07 D8         [24] 1720 	mov	dptr,#_control_phase
      0061F5 74 03            [12] 1721 	mov	a,#0x03
      0061F7 F0               [24] 1722 	movx	@dptr,a
      0061F8 02 67 99         [24] 1723 	ljmp	00291$
      0061FB                       1724 00145$:
                                   1725 ;	tmk_core/protocol/ch555/usb_ak820.c:255: } else if (type == 0x21 && D0UsbConfig) {
      0061FB BF 21 02         [24] 1726 	cjne	r7,#0x21,01231$
      0061FE 80 03            [24] 1727 	sjmp	01232$
      006200                       1728 01231$:
      006200 02 5D EA         [24] 1729 	ljmp	_control_stall
      006203                       1730 01232$:
      006203 90 07 7F         [24] 1731 	mov	dptr,#_D0UsbConfig
      006206 E0               [24] 1732 	movx	a,@dptr
      006207 70 03            [24] 1733 	jnz	01233$
      006209 02 5D EA         [24] 1734 	ljmp	_control_stall
      00620C                       1735 01233$:
                                   1736 ;	tmk_core/protocol/ch555/usb_ak820.c:256: if (index == RAW_INTERFACE && value == 0x0200 && D0SetupLen == RAW_EPSIZE && raw_state == RAW_IDLE) {
      00620C BB 01 2D         [24] 1737 	cjne	r3,#0x01,00135$
      00620F BC 00 2A         [24] 1738 	cjne	r4,#0x00,00135$
      006212 8D 01            [24] 1739 	mov	ar1,r5
      006214 8E 02            [24] 1740 	mov	ar2,r6
      006216 B9 00 23         [24] 1741 	cjne	r1,#0x00,00135$
      006219 BA 02 20         [24] 1742 	cjne	r2,#0x02,00135$
      00621C 90 07 7A         [24] 1743 	mov	dptr,#_D0SetupLen
      00621F E0               [24] 1744 	movx	a,@dptr
      006220 F9               [12] 1745 	mov	r1,a
      006221 A3               [24] 1746 	inc	dptr
      006222 E0               [24] 1747 	movx	a,@dptr
      006223 FA               [12] 1748 	mov	r2,a
      006224 B9 20 15         [24] 1749 	cjne	r1,#0x20,00135$
      006227 BA 00 12         [24] 1750 	cjne	r2,#0x00,00135$
      00622A 90 07 87         [24] 1751 	mov	dptr,#_raw_state
      00622D E0               [24] 1752 	movx	a,@dptr
      00622E 70 0C            [24] 1753 	jnz	00135$
                                   1754 ;	tmk_core/protocol/ch555/usb_ak820.c:257: raw_state = RAW_RX;
      006230 90 07 87         [24] 1755 	mov	dptr,#_raw_state
      006233 74 01            [12] 1756 	mov	a,#0x01
      006235 F0               [24] 1757 	movx	@dptr,a
                                   1758 ;	tmk_core/protocol/ch555/usb_ak820.c:258: output_kind = OUTPUT_RAW;
      006236 90 07 D9         [24] 1759 	mov	dptr,#_output_kind
      006239 F0               [24] 1760 	movx	@dptr,a
      00623A 80 52            [24] 1761 	sjmp	00136$
      00623C                       1762 00135$:
                                   1763 ;	tmk_core/protocol/ch555/usb_ak820.c:259: } else if (index == KEYBOARD_INTERFACE && value == 0x0200 && D0SetupLen == 1) {
      00623C EB               [12] 1764 	mov	a,r3
      00623D 4C               [12] 1765 	orl	a,r4
      00623E 70 20            [24] 1766 	jnz	00130$
      006240 8D 01            [24] 1767 	mov	ar1,r5
      006242 8E 02            [24] 1768 	mov	ar2,r6
      006244 B9 00 19         [24] 1769 	cjne	r1,#0x00,00130$
      006247 BA 02 16         [24] 1770 	cjne	r2,#0x02,00130$
      00624A 90 07 7A         [24] 1771 	mov	dptr,#_D0SetupLen
      00624D E0               [24] 1772 	movx	a,@dptr
      00624E F9               [12] 1773 	mov	r1,a
      00624F A3               [24] 1774 	inc	dptr
      006250 E0               [24] 1775 	movx	a,@dptr
      006251 FA               [12] 1776 	mov	r2,a
      006252 B9 01 0B         [24] 1777 	cjne	r1,#0x01,00130$
      006255 BA 00 08         [24] 1778 	cjne	r2,#0x00,00130$
                                   1779 ;	tmk_core/protocol/ch555/usb_ak820.c:260: output_kind = OUTPUT_LED;
      006258 90 07 D9         [24] 1780 	mov	dptr,#_output_kind
      00625B 74 02            [12] 1781 	mov	a,#0x02
      00625D F0               [24] 1782 	movx	@dptr,a
      00625E 80 2E            [24] 1783 	sjmp	00136$
      006260                       1784 00130$:
                                   1785 ;	tmk_core/protocol/ch555/usb_ak820.c:262: } else if (index == SHARED_INTERFACE && value == (0x0200 | REPORT_ID_NKRO) && D0SetupLen == 2) {
      006260 BB 02 28         [24] 1786 	cjne	r3,#0x02,00125$
      006263 BC 00 25         [24] 1787 	cjne	r4,#0x00,00125$
      006266 8D 01            [24] 1788 	mov	ar1,r5
      006268 8E 02            [24] 1789 	mov	ar2,r6
      00626A B9 06 1E         [24] 1790 	cjne	r1,#0x06,00125$
      00626D BA 02 1B         [24] 1791 	cjne	r2,#0x02,00125$
      006270 90 07 7A         [24] 1792 	mov	dptr,#_D0SetupLen
      006273 E0               [24] 1793 	movx	a,@dptr
      006274 F9               [12] 1794 	mov	r1,a
      006275 A3               [24] 1795 	inc	dptr
      006276 E0               [24] 1796 	movx	a,@dptr
      006277 FA               [12] 1797 	mov	r2,a
      006278 B9 02 10         [24] 1798 	cjne	r1,#0x02,00125$
      00627B BA 00 0D         [24] 1799 	cjne	r2,#0x00,00125$
                                   1800 ;	tmk_core/protocol/ch555/usb_ak820.c:263: output_kind = OUTPUT_SHARED_LED;
      00627E 90 07 D9         [24] 1801 	mov	dptr,#_output_kind
      006281 74 03            [12] 1802 	mov	a,#0x03
      006283 F0               [24] 1803 	movx	@dptr,a
                                   1804 ;	tmk_core/protocol/ch555/usb_ak820.c:264: output_report_id = REPORT_ID_NKRO;
      006284 90 07 DA         [24] 1805 	mov	dptr,#_output_report_id
      006287 23               [12] 1806 	rl	a
      006288 F0               [24] 1807 	movx	@dptr,a
      006289 80 03            [24] 1808 	sjmp	00136$
      00628B                       1809 00125$:
                                   1810 ;	tmk_core/protocol/ch555/usb_ak820.c:266: } else { control_stall(); return; }
      00628B 02 5D EA         [24] 1811 	ljmp	_control_stall
      00628E                       1812 00136$:
                                   1813 ;	tmk_core/protocol/ch555/usb_ak820.c:267: control_phase = CTRL_DATA_OUT;
      00628E 90 07 D8         [24] 1814 	mov	dptr,#_control_phase
      006291 74 04            [12] 1815 	mov	a,#0x04
      006293 F0               [24] 1816 	movx	@dptr,a
                                   1817 ;	tmk_core/protocol/ch555/usb_ak820.c:268: return; /* OUT data must arrive before status-IN becomes ACK */
      006294 22               [24] 1818 	ret
                                   1819 ;	tmk_core/protocol/ch555/usb_ak820.c:269: } else { control_stall(); return; }
      006295 02 5D EA         [24] 1820 	ljmp	_control_stall
                                   1821 ;	tmk_core/protocol/ch555/usb_ak820.c:271: case USB_GET_CONFIGURATION:
      006298                       1822 00150$:
                                   1823 ;	tmk_core/protocol/ch555/usb_ak820.c:272: if (type == 0x80 && zero_index && zero_value && D0SetupLen == 1) {
      006298 BF 80 2A         [24] 1824 	cjne	r7,#0x80,00152$
      00629B 30 16 27         [24] 1825 	jnb	_control_setup_zero_index_10000_289,00152$
      00629E 30 17 24         [24] 1826 	jnb	_control_setup_zero_value_10000_289,00152$
      0062A1 90 07 7A         [24] 1827 	mov	dptr,#_D0SetupLen
      0062A4 E0               [24] 1828 	movx	a,@dptr
      0062A5 F9               [12] 1829 	mov	r1,a
      0062A6 A3               [24] 1830 	inc	dptr
      0062A7 E0               [24] 1831 	movx	a,@dptr
      0062A8 FA               [12] 1832 	mov	r2,a
      0062A9 B9 01 19         [24] 1833 	cjne	r1,#0x01,00152$
      0062AC BA 00 16         [24] 1834 	cjne	r2,#0x00,00152$
                                   1835 ;	tmk_core/protocol/ch555/usb_ak820.c:273: pD0_EP0_BUF[0] = D0UsbConfig;
      0062AF 90 07 7F         [24] 1836 	mov	dptr,#_D0UsbConfig
      0062B2 E0               [24] 1837 	movx	a,@dptr
      0062B3 90 10 00         [24] 1838 	mov	dptr,#0x1000
      0062B6 F0               [24] 1839 	movx	@dptr,a
                                   1840 ;	tmk_core/protocol/ch555/usb_ak820.c:274: D0_EP0T_L = 1;
      0062B7 90 22 08         [24] 1841 	mov	dptr,#0x2208
      0062BA 74 01            [12] 1842 	mov	a,#0x01
      0062BC F0               [24] 1843 	movx	@dptr,a
                                   1844 ;	tmk_core/protocol/ch555/usb_ak820.c:275: control_phase = CTRL_STATUS_OUT;
      0062BD 90 07 D8         [24] 1845 	mov	dptr,#_control_phase
      0062C0 04               [12] 1846 	inc	a
      0062C1 F0               [24] 1847 	movx	@dptr,a
      0062C2 02 67 99         [24] 1848 	ljmp	00291$
      0062C5                       1849 00152$:
                                   1850 ;	tmk_core/protocol/ch555/usb_ak820.c:276: } else { control_stall(); return; }
      0062C5 02 5D EA         [24] 1851 	ljmp	_control_stall
                                   1852 ;	tmk_core/protocol/ch555/usb_ak820.c:278: case USB_GET_INTERFACE: /* DEF_USB_SET_IDLE has the same request byte. */
      0062C8                       1853 00157$:
                                   1854 ;	tmk_core/protocol/ch555/usb_ak820.c:279: if (type == 0x81 && valid_interface && zero_value && D0SetupLen == 1 && D0UsbConfig) {
      0062C8 BF 81 2C         [24] 1855 	cjne	r7,#0x81,00167$
      0062CB 30 15 29         [24] 1856 	jnb	_control_setup_valid_interface_10000_289,00167$
      0062CE 30 17 26         [24] 1857 	jnb	_control_setup_zero_value_10000_289,00167$
      0062D1 90 07 7A         [24] 1858 	mov	dptr,#_D0SetupLen
      0062D4 E0               [24] 1859 	movx	a,@dptr
      0062D5 F9               [12] 1860 	mov	r1,a
      0062D6 A3               [24] 1861 	inc	dptr
      0062D7 E0               [24] 1862 	movx	a,@dptr
      0062D8 FA               [12] 1863 	mov	r2,a
      0062D9 B9 01 1B         [24] 1864 	cjne	r1,#0x01,00167$
      0062DC BA 00 18         [24] 1865 	cjne	r2,#0x00,00167$
      0062DF 90 07 7F         [24] 1866 	mov	dptr,#_D0UsbConfig
      0062E2 E0               [24] 1867 	movx	a,@dptr
      0062E3 60 12            [24] 1868 	jz	00167$
                                   1869 ;	tmk_core/protocol/ch555/usb_ak820.c:280: pD0_EP0_BUF[0] = 0;
      0062E5 90 10 00         [24] 1870 	mov	dptr,#0x1000
      0062E8 E4               [12] 1871 	clr	a
      0062E9 F0               [24] 1872 	movx	@dptr,a
                                   1873 ;	tmk_core/protocol/ch555/usb_ak820.c:281: D0_EP0T_L = 1;
      0062EA 90 22 08         [24] 1874 	mov	dptr,#0x2208
      0062ED 04               [12] 1875 	inc	a
      0062EE F0               [24] 1876 	movx	@dptr,a
                                   1877 ;	tmk_core/protocol/ch555/usb_ak820.c:282: control_phase = CTRL_STATUS_OUT;
      0062EF 90 07 D8         [24] 1878 	mov	dptr,#_control_phase
      0062F2 04               [12] 1879 	inc	a
      0062F3 F0               [24] 1880 	movx	@dptr,a
      0062F4 02 67 99         [24] 1881 	ljmp	00291$
      0062F7                       1882 00167$:
                                   1883 ;	tmk_core/protocol/ch555/usb_ak820.c:283: } else if (valid_interface && D0UsbConfig && type == 0x21 && zero_length) {
      0062F7 30 15 1E         [24] 1884 	jnb	_control_setup_valid_interface_10000_289,00161$
      0062FA 90 07 7F         [24] 1885 	mov	dptr,#_D0UsbConfig
      0062FD E0               [24] 1886 	movx	a,@dptr
      0062FE 60 18            [24] 1887 	jz	00161$
      006300 BF 21 15         [24] 1888 	cjne	r7,#0x21,00161$
      006303 30 18 12         [24] 1889 	jnb	_control_setup_zero_length_10000_289,00161$
                                   1890 ;	tmk_core/protocol/ch555/usb_ak820.c:284: if (index == KEYBOARD_INTERFACE) keyboard_idle = value >> 8;
      006306 EB               [12] 1891 	mov	a,r3
      006307 4C               [12] 1892 	orl	a,r4
      006308 70 05            [24] 1893 	jnz	00159$
      00630A 90 06 57         [24] 1894 	mov	dptr,#_keyboard_idle
      00630D EE               [12] 1895 	mov	a,r6
      00630E F0               [24] 1896 	movx	@dptr,a
      00630F                       1897 00159$:
                                   1898 ;	tmk_core/protocol/ch555/usb_ak820.c:285: control_phase = CTRL_STATUS_IN;
      00630F 90 07 D8         [24] 1899 	mov	dptr,#_control_phase
      006312 74 03            [12] 1900 	mov	a,#0x03
      006314 F0               [24] 1901 	movx	@dptr,a
      006315 02 67 99         [24] 1902 	ljmp	00291$
      006318                       1903 00161$:
                                   1904 ;	tmk_core/protocol/ch555/usb_ak820.c:286: } else { control_stall(); return; }
      006318 02 5D EA         [24] 1905 	ljmp	_control_stall
                                   1906 ;	tmk_core/protocol/ch555/usb_ak820.c:288: case USB_SET_INTERFACE: /* DEF_USB_SET_PROTOCOL has the same request byte. */
      00631B                       1907 00173$:
                                   1908 ;	tmk_core/protocol/ch555/usb_ak820.c:289: if (type == 0x01 && valid_interface && zero_value && zero_length && D0UsbConfig) {
      00631B BF 01 18         [24] 1909 	cjne	r7,#0x01,00182$
      00631E 30 15 15         [24] 1910 	jnb	_control_setup_valid_interface_10000_289,00182$
      006321 30 17 12         [24] 1911 	jnb	_control_setup_zero_value_10000_289,00182$
      006324 30 18 0F         [24] 1912 	jnb	_control_setup_zero_length_10000_289,00182$
      006327 90 07 7F         [24] 1913 	mov	dptr,#_D0UsbConfig
      00632A E0               [24] 1914 	movx	a,@dptr
      00632B 60 09            [24] 1915 	jz	00182$
                                   1916 ;	tmk_core/protocol/ch555/usb_ak820.c:290: control_phase = CTRL_STATUS_IN;
      00632D 90 07 D8         [24] 1917 	mov	dptr,#_control_phase
      006330 74 03            [12] 1918 	mov	a,#0x03
      006332 F0               [24] 1919 	movx	@dptr,a
      006333 02 67 99         [24] 1920 	ljmp	00291$
      006336                       1921 00182$:
                                   1922 ;	tmk_core/protocol/ch555/usb_ak820.c:291: } else if (index == KEYBOARD_INTERFACE && D0UsbConfig && type == 0x21 && zero_length && value <= 1) {
      006336 EB               [12] 1923 	mov	a,r3
      006337 4C               [12] 1924 	orl	a,r4
      006338 70 2C            [24] 1925 	jnz	00175$
      00633A 90 07 7F         [24] 1926 	mov	dptr,#_D0UsbConfig
      00633D E0               [24] 1927 	movx	a,@dptr
      00633E 60 26            [24] 1928 	jz	00175$
      006340 BF 21 23         [24] 1929 	cjne	r7,#0x21,00175$
      006343 30 18 20         [24] 1930 	jnb	_control_setup_zero_length_10000_289,00175$
      006346 8D 01            [24] 1931 	mov	ar1,r5
      006348 8E 02            [24] 1932 	mov	ar2,r6
      00634A C3               [12] 1933 	clr	c
      00634B 74 01            [12] 1934 	mov	a,#0x01
      00634D 99               [12] 1935 	subb	a,r1
      00634E E4               [12] 1936 	clr	a
      00634F 9A               [12] 1937 	subb	a,r2
      006350 40 14            [24] 1938 	jc	00175$
                                   1939 ;	free result
                                   1940 ;	tmk_core/protocol/ch555/usb_ak820.c:292: keyboard_protocol = value;
      006352 90 0D 9C         [24] 1941 	mov	dptr,#_keyboard_protocol
      006355 ED               [12] 1942 	mov	a,r5
      006356 F0               [24] 1943 	movx	@dptr,a
                                   1944 ;	tmk_core/protocol/ch555/usb_ak820.c:293: keyboard_reset = 1;
      006357 90 07 A9         [24] 1945 	mov	dptr,#_keyboard_reset
      00635A 74 01            [12] 1946 	mov	a,#0x01
      00635C F0               [24] 1947 	movx	@dptr,a
                                   1948 ;	tmk_core/protocol/ch555/usb_ak820.c:294: control_phase = CTRL_STATUS_IN;
      00635D 90 07 D8         [24] 1949 	mov	dptr,#_control_phase
      006360 74 03            [12] 1950 	mov	a,#0x03
      006362 F0               [24] 1951 	movx	@dptr,a
      006363 02 67 99         [24] 1952 	ljmp	00291$
      006366                       1953 00175$:
                                   1954 ;	tmk_core/protocol/ch555/usb_ak820.c:295: } else { control_stall(); return; }
      006366 02 5D EA         [24] 1955 	ljmp	_control_stall
                                   1956 ;	tmk_core/protocol/ch555/usb_ak820.c:297: case USB_GET_STATUS:
      006369                       1957 00188$:
                                   1958 ;	tmk_core/protocol/ch555/usb_ak820.c:298: if (zero_value && D0SetupLen == 2 &&
      006369 20 17 03         [24] 1959 	jb	_control_setup_zero_value_10000_289,01283$
      00636C 02 5D EA         [24] 1960 	ljmp	_control_stall
      00636F                       1961 01283$:
      00636F 90 07 7A         [24] 1962 	mov	dptr,#_D0SetupLen
      006372 E0               [24] 1963 	movx	a,@dptr
      006373 F9               [12] 1964 	mov	r1,a
      006374 A3               [24] 1965 	inc	dptr
      006375 E0               [24] 1966 	movx	a,@dptr
      006376 FA               [12] 1967 	mov	r2,a
      006377 B9 02 05         [24] 1968 	cjne	r1,#0x02,01284$
      00637A BA 00 02         [24] 1969 	cjne	r2,#0x00,01284$
      00637D 80 03            [24] 1970 	sjmp	01285$
      00637F                       1971 01284$:
      00637F 02 5D EA         [24] 1972 	ljmp	_control_stall
      006382                       1973 01285$:
                                   1974 ;	tmk_core/protocol/ch555/usb_ak820.c:299: ((type == 0x80 && zero_index) || (type == 0x81 && valid_interface && D0UsbConfig) ||
      006382 E4               [12] 1975 	clr	a
      006383 BF 80 01         [24] 1976 	cjne	r7,#0x80,01286$
      006386 04               [12] 1977 	inc	a
      006387                       1978 01286$:
      006387 FA               [12] 1979 	mov	r2,a
      006388 60 03            [24] 1980 	jz	00196$
      00638A 20 16 35         [24] 1981 	jb	_control_setup_zero_index_10000_289,00189$
      00638D                       1982 00196$:
      00638D BF 81 09         [24] 1983 	cjne	r7,#0x81,00202$
      006390 30 15 06         [24] 1984 	jnb	_control_setup_valid_interface_10000_289,00202$
      006393 90 07 7F         [24] 1985 	mov	dptr,#_D0UsbConfig
      006396 E0               [24] 1986 	movx	a,@dptr
      006397 70 29            [24] 1987 	jnz	00189$
      006399                       1988 00202$:
                                   1989 ;	tmk_core/protocol/ch555/usb_ak820.c:300: (type == 0x82 && D0UsbConfig && (index == 0 || index == 0x80 || (index >= 0x81 && index <= 0x83))))) {
      006399 BF 82 70         [24] 1990 	cjne	r7,#0x82,00190$
      00639C 90 07 7F         [24] 1991 	mov	dptr,#_D0UsbConfig
      00639F E0               [24] 1992 	movx	a,@dptr
      0063A0 60 6A            [24] 1993 	jz	00190$
      0063A2 EB               [12] 1994 	mov	a,r3
      0063A3 4C               [12] 1995 	orl	a,r4
      0063A4 60 1C            [24] 1996 	jz	00189$
      0063A6 8B 00            [24] 1997 	mov	ar0,r3
      0063A8 8C 01            [24] 1998 	mov	ar1,r4
      0063AA B8 80 05         [24] 1999 	cjne	r0,#0x80,01298$
      0063AD B9 00 02         [24] 2000 	cjne	r1,#0x00,01298$
      0063B0 80 10            [24] 2001 	sjmp	00189$
      0063B2                       2002 01298$:
      0063B2 C3               [12] 2003 	clr	c
      0063B3 E8               [12] 2004 	mov	a,r0
      0063B4 94 81            [12] 2005 	subb	a,#0x81
      0063B6 E9               [12] 2006 	mov	a,r1
      0063B7 94 00            [12] 2007 	subb	a,#0x00
      0063B9 40 51            [24] 2008 	jc	00190$
      0063BB 74 83            [12] 2009 	mov	a,#0x83
      0063BD 98               [12] 2010 	subb	a,r0
      0063BE E4               [12] 2011 	clr	a
      0063BF 99               [12] 2012 	subb	a,r1
      0063C0 40 4A            [24] 2013 	jc	00190$
                                   2014 ;	free result
      0063C2                       2015 00189$:
                                   2016 ;	tmk_core/protocol/ch555/usb_ak820.c:301: endpoint = index & 7;
      0063C2 8B 01            [24] 2017 	mov	ar1,r3
      0063C4 53 01 07         [24] 2018 	anl	ar1,#0x07
                                   2019 ;	tmk_core/protocol/ch555/usb_ak820.c:302: pD0_EP0_BUF[0] = type == 0x80 ? ((USB_SleepStatus & 1) << 1) :
      0063C7 EA               [12] 2020 	mov	a,r2
      0063C8 60 0B            [24] 2021 	jz	00308$
      0063CA 90 07 81         [24] 2022 	mov	dptr,#_USB_SleepStatus
      0063CD E0               [24] 2023 	movx	a,@dptr
      0063CE 54 01            [12] 2024 	anl	a,#0x01
      0063D0 25 E0            [12] 2025 	add	a,acc
      0063D2 FA               [12] 2026 	mov	r2,a
      0063D3 80 22            [24] 2027 	sjmp	00309$
      0063D5                       2028 00308$:
                                   2029 ;	tmk_core/protocol/ch555/usb_ak820.c:303: ((type == 0x82 && endpoint && (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_STALL) ? 1 : 0);
      0063D5 BF 82 1B         [24] 2030 	cjne	r7,#0x82,00310$
      0063D8 E9               [12] 2031 	mov	a,r1
      0063D9 60 18            [24] 2032 	jz	00310$
      0063DB 89 00            [24] 2033 	mov	ar0,r1
      0063DD 79 00            [12] 2034 	mov	r1,#0x00
      0063DF 74 22            [12] 2035 	mov	a,#0x22
      0063E1 29               [12] 2036 	add	a, r1
      0063E2 F9               [12] 2037 	mov	r1,a
      0063E3 88 82            [24] 2038 	mov	dpl,r0
      0063E5 89 83            [24] 2039 	mov	dph,r1
      0063E7 E0               [24] 2040 	movx	a,@dptr
      0063E8 F9               [12] 2041 	mov	r1,a
      0063E9 53 01 03         [24] 2042 	anl	ar1,#0x03
      0063EC B9 03 04         [24] 2043 	cjne	r1,#0x03,00310$
      0063EF 79 01            [12] 2044 	mov	r1,#0x01
      0063F1 80 02            [24] 2045 	sjmp	00311$
      0063F3                       2046 00310$:
      0063F3 79 00            [12] 2047 	mov	r1,#0x00
      0063F5                       2048 00311$:
      0063F5 89 02            [24] 2049 	mov	ar2,r1
      0063F7                       2050 00309$:
      0063F7 90 10 00         [24] 2051 	mov	dptr,#0x1000
      0063FA EA               [12] 2052 	mov	a,r2
      0063FB F0               [24] 2053 	movx	@dptr,a
                                   2054 ;	tmk_core/protocol/ch555/usb_ak820.c:304: pD0_EP0_BUF[1] = 0;
      0063FC A3               [24] 2055 	inc	dptr
      0063FD E4               [12] 2056 	clr	a
      0063FE F0               [24] 2057 	movx	@dptr,a
                                   2058 ;	tmk_core/protocol/ch555/usb_ak820.c:305: D0_EP0T_L = 2;
      0063FF 90 22 08         [24] 2059 	mov	dptr,#0x2208
      006402 74 02            [12] 2060 	mov	a,#0x02
      006404 F0               [24] 2061 	movx	@dptr,a
                                   2062 ;	tmk_core/protocol/ch555/usb_ak820.c:306: control_phase = CTRL_STATUS_OUT;
      006405 90 07 D8         [24] 2063 	mov	dptr,#_control_phase
      006408 F0               [24] 2064 	movx	@dptr,a
      006409 02 67 99         [24] 2065 	ljmp	00291$
      00640C                       2066 00190$:
                                   2067 ;	tmk_core/protocol/ch555/usb_ak820.c:307: } else { control_stall(); return; }
      00640C 02 5D EA         [24] 2068 	ljmp	_control_stall
                                   2069 ;	tmk_core/protocol/ch555/usb_ak820.c:310: case USB_SET_FEATURE: /* DEF_USB_GET_PROTOCOL has the same request byte. */
      00640F                       2070 00205$:
                                   2071 ;	tmk_core/protocol/ch555/usb_ak820.c:311: if (zero_length && D0UsbConfig) {
      00640F 20 18 03         [24] 2072 	jb	_control_setup_zero_length_10000_289,01307$
      006412 02 64 A2         [24] 2073 	ljmp	00279$
      006415                       2074 01307$:
      006415 90 07 7F         [24] 2075 	mov	dptr,#_D0UsbConfig
      006418 E0               [24] 2076 	movx	a,@dptr
      006419 70 03            [24] 2077 	jnz	01308$
      00641B 02 64 A2         [24] 2078 	ljmp	00279$
      00641E                       2079 01308$:
                                   2080 ;	tmk_core/protocol/ch555/usb_ak820.c:312: if (type == 0x00 && value == 1 && zero_index) {
      00641E EF               [12] 2081 	mov	a,r7
      00641F 70 29            [24] 2082 	jnz	00218$
      006421 8D 01            [24] 2083 	mov	ar1,r5
      006423 8E 02            [24] 2084 	mov	ar2,r6
      006425 B9 01 22         [24] 2085 	cjne	r1,#0x01,00218$
      006428 BA 00 1F         [24] 2086 	cjne	r2,#0x00,00218$
      00642B 30 16 1C         [24] 2087 	jnb	_control_setup_zero_index_10000_289,00218$
                                   2088 ;	tmk_core/protocol/ch555/usb_ak820.c:313: if (D0SetupReqCode == USB_SET_FEATURE) USB_SleepStatus |= 1;
      00642E 90 07 79         [24] 2089 	mov	dptr,#_D0SetupReqCode
      006431 E0               [24] 2090 	movx	a,@dptr
      006432 FA               [12] 2091 	mov	r2,a
      006433 BA 03 0A         [24] 2092 	cjne	r2,#0x03,00207$
      006436 90 07 81         [24] 2093 	mov	dptr,#_USB_SleepStatus
      006439 E0               [24] 2094 	movx	a,@dptr
      00643A 43 E0 01         [24] 2095 	orl	acc,#0x01
      00643D F0               [24] 2096 	movx	@dptr,a
      00643E 80 59            [24] 2097 	sjmp	00219$
      006440                       2098 00207$:
                                   2099 ;	tmk_core/protocol/ch555/usb_ak820.c:314: else USB_SleepStatus &= ~1;
      006440 90 07 81         [24] 2100 	mov	dptr,#_USB_SleepStatus
      006443 E0               [24] 2101 	movx	a,@dptr
      006444 53 E0 FE         [24] 2102 	anl	acc,#0xfe
      006447 F0               [24] 2103 	movx	@dptr,a
      006448 80 4F            [24] 2104 	sjmp	00219$
      00644A                       2105 00218$:
                                   2106 ;	tmk_core/protocol/ch555/usb_ak820.c:315: } else if (type == 0x02 && zero_value && index >= 0x81 && index <= 0x83) {
      00644A BF 02 49         [24] 2107 	cjne	r7,#0x02,00212$
      00644D 30 17 46         [24] 2108 	jnb	_control_setup_zero_value_10000_289,00212$
      006450 8B 01            [24] 2109 	mov	ar1,r3
      006452 8C 02            [24] 2110 	mov	ar2,r4
      006454 C3               [12] 2111 	clr	c
      006455 E9               [12] 2112 	mov	a,r1
      006456 94 81            [12] 2113 	subb	a,#0x81
      006458 EA               [12] 2114 	mov	a,r2
      006459 94 00            [12] 2115 	subb	a,#0x00
      00645B 40 39            [24] 2116 	jc	00212$
      00645D 74 83            [12] 2117 	mov	a,#0x83
      00645F 99               [12] 2118 	subb	a,r1
      006460 E4               [12] 2119 	clr	a
      006461 9A               [12] 2120 	subb	a,r2
      006462 40 32            [24] 2121 	jc	00212$
                                   2122 ;	free result
                                   2123 ;	tmk_core/protocol/ch555/usb_ak820.c:316: endpoint = index & 7;
      006464 8B 02            [24] 2124 	mov	ar2,r3
      006466 53 02 07         [24] 2125 	anl	ar2,#0x07
                                   2126 ;	tmk_core/protocol/ch555/usb_ak820.c:318: EP_RESPONSE(endpoint) = bUEP_X_AUTO_TOG | (D0SetupReqCode == USB_SET_FEATURE ? UEP_X_RES_STALL : UEP_X_RES_NAK);
      006469 8A 00            [24] 2127 	mov	ar0,r2
      00646B 79 00            [12] 2128 	mov	r1,#0x00
      00646D 74 22            [12] 2129 	mov	a,#0x22
      00646F 29               [12] 2130 	add	a, r1
      006470 F9               [12] 2131 	mov	r1,a
      006471 88 17            [24] 2132 	mov	_control_setup_sloc3_1_0,r0
      006473 89 18            [24] 2133 	mov	(_control_setup_sloc3_1_0 + 1),r1
      006475 90 07 79         [24] 2134 	mov	dptr,#_D0SetupReqCode
      006478 E0               [24] 2135 	movx	a,@dptr
      006479 F9               [12] 2136 	mov	r1,a
      00647A B9 03 04         [24] 2137 	cjne	r1,#0x03,00318$
      00647D 79 03            [12] 2138 	mov	r1,#0x03
      00647F 80 02            [24] 2139 	sjmp	00319$
      006481                       2140 00318$:
      006481 79 02            [12] 2141 	mov	r1,#0x02
      006483                       2142 00319$:
      006483 43 01 10         [24] 2143 	orl	ar1,#0x10
      006486 85 17 82         [24] 2144 	mov	dpl,_control_setup_sloc3_1_0
      006489 85 18 83         [24] 2145 	mov	dph,(_control_setup_sloc3_1_0 + 1)
      00648C E9               [12] 2146 	mov	a,r1
      00648D F0               [24] 2147 	movx	@dptr,a
                                   2148 ;	tmk_core/protocol/ch555/usb_ak820.c:319: if (endpoint == RAW_IN_EPNUM) raw_complete();
      00648E BA 03 08         [24] 2149 	cjne	r2,#0x03,00219$
      006491 12 5D 72         [24] 2150 	lcall	_raw_complete
      006494 80 03            [24] 2151 	sjmp	00219$
      006496                       2152 00212$:
                                   2153 ;	tmk_core/protocol/ch555/usb_ak820.c:320: } else { control_stall(); return; }
      006496 02 5D EA         [24] 2154 	ljmp	_control_stall
      006499                       2155 00219$:
                                   2156 ;	tmk_core/protocol/ch555/usb_ak820.c:321: control_phase = CTRL_STATUS_IN;
      006499 90 07 D8         [24] 2157 	mov	dptr,#_control_phase
      00649C 74 03            [12] 2158 	mov	a,#0x03
      00649E F0               [24] 2159 	movx	@dptr,a
      00649F 02 67 99         [24] 2160 	ljmp	00291$
      0064A2                       2161 00279$:
                                   2162 ;	tmk_core/protocol/ch555/usb_ak820.c:322: } else if (type == 0xa1 && D0SetupReqCode == HID_GET_REPORT && D0UsbConfig && D0SetupLen) {
      0064A2 E4               [12] 2163 	clr	a
      0064A3 BF A1 01         [24] 2164 	cjne	r7,#0xa1,01324$
      0064A6 04               [12] 2165 	inc	a
      0064A7                       2166 01324$:
      0064A7 FA               [12] 2167 	mov	r2,a
      0064A8 70 03            [24] 2168 	jnz	01326$
      0064AA 02 67 14         [24] 2169 	ljmp	00273$
      0064AD                       2170 01326$:
      0064AD 90 07 79         [24] 2171 	mov	dptr,#_D0SetupReqCode
      0064B0 E0               [24] 2172 	movx	a,@dptr
      0064B1 F9               [12] 2173 	mov	r1,a
      0064B2 B9 01 02         [24] 2174 	cjne	r1,#0x01,01327$
      0064B5 80 03            [24] 2175 	sjmp	01328$
      0064B7                       2176 01327$:
      0064B7 02 67 14         [24] 2177 	ljmp	00273$
      0064BA                       2178 01328$:
      0064BA 90 07 7F         [24] 2179 	mov	dptr,#_D0UsbConfig
      0064BD E0               [24] 2180 	movx	a,@dptr
      0064BE 70 03            [24] 2181 	jnz	01329$
      0064C0 02 67 14         [24] 2182 	ljmp	00273$
      0064C3                       2183 01329$:
      0064C3 90 07 7A         [24] 2184 	mov	dptr,#_D0SetupLen
      0064C6 E0               [24] 2185 	movx	a,@dptr
      0064C7 F8               [12] 2186 	mov	r0,a
      0064C8 A3               [24] 2187 	inc	dptr
      0064C9 E0               [24] 2188 	movx	a,@dptr
      0064CA 48               [12] 2189 	orl	a,r0
      0064CB 70 03            [24] 2190 	jnz	01330$
      0064CD 02 67 14         [24] 2191 	ljmp	00273$
      0064D0                       2192 01330$:
                                   2193 ;	tmk_core/protocol/ch555/usb_ak820.c:323: report_id = value;
      0064D0 C0 03            [24] 2194 	push	ar3
      0064D2 C0 04            [24] 2195 	push	ar4
      0064D4 8D 01            [24] 2196 	mov	ar1,r5
                                   2197 ;	tmk_core/protocol/ch555/usb_ak820.c:324: if ((value >> 8) == 1 && index == KEYBOARD_INTERFACE && !report_id) {
      0064D6 8E 00            [24] 2198 	mov	ar0,r6
      0064D8 B8 01 03         [24] 2199 	cjne	r0,#0x01,01331$
      0064DB E8               [12] 2200 	mov	a,r0
      0064DC 80 01            [24] 2201 	sjmp	01332$
      0064DE                       2202 01331$:
      0064DE E4               [12] 2203 	clr	a
      0064DF                       2204 01332$:
      0064DF F5 17            [12] 2205 	mov	_control_setup_sloc3_1_0,a
      0064E1 D0 04            [24] 2206 	pop	ar4
      0064E3 D0 03            [24] 2207 	pop	ar3
      0064E5 E5 17            [12] 2208 	mov	a,_control_setup_sloc3_1_0
      0064E7 60 17            [24] 2209 	jz	00251$
      0064E9 EB               [12] 2210 	mov	a,r3
      0064EA 4C               [12] 2211 	orl	a,r4
      0064EB 70 13            [24] 2212 	jnz	00251$
      0064ED E9               [12] 2213 	mov	a,r1
      0064EE 70 10            [24] 2214 	jnz	00251$
                                   2215 ;	tmk_core/protocol/ch555/usb_ak820.c:325: length = KEYBOARD_EPSIZE;
      0064F0 90 07 E2         [24] 2216 	mov	dptr,#_control_setup_length_10000_289
      0064F3 74 08            [12] 2217 	mov	a,#0x08
      0064F5 F0               [24] 2218 	movx	@dptr,a
      0064F6 E4               [12] 2219 	clr	a
      0064F7 A3               [24] 2220 	inc	dptr
      0064F8 F0               [24] 2221 	movx	@dptr,a
                                   2222 ;	tmk_core/protocol/ch555/usb_ak820.c:326: offset = SNAPSHOT_KEYBOARD;
      0064F9 90 07 E4         [24] 2223 	mov	dptr,#_control_setup_offset_10000_289
      0064FC F0               [24] 2224 	movx	@dptr,a
      0064FD 02 66 84         [24] 2225 	ljmp	00252$
      006500                       2226 00251$:
                                   2227 ;	tmk_core/protocol/ch555/usb_ak820.c:327: } else if ((value >> 8) == 1 && index == SHARED_INTERFACE &&
      006500 E5 17            [12] 2228 	mov	a,_control_setup_sloc3_1_0
      006502 60 27            [24] 2229 	jz	00245$
      006504 BB 02 24         [24] 2230 	cjne	r3,#0x02,00245$
      006507 BC 00 21         [24] 2231 	cjne	r4,#0x00,00245$
                                   2232 ;	tmk_core/protocol/ch555/usb_ak820.c:328: report_id < sizeof(shared_lengths) && shared_lengths[report_id]) {
      00650A B9 07 00         [24] 2233 	cjne	r1,#0x07,01339$
      00650D                       2234 01339$:
      00650D 50 1C            [24] 2235 	jnc	00245$
      00650F E9               [12] 2236 	mov	a,r1
      006510 90 BB B1         [24] 2237 	mov	dptr,#_shared_lengths
      006513 93               [24] 2238 	movc	a,@a+dptr
      006514 F8               [12] 2239 	mov	r0,a
      006515 60 14            [24] 2240 	jz	00245$
                                   2241 ;	tmk_core/protocol/ch555/usb_ak820.c:329: length = shared_lengths[report_id];
      006517 90 07 E2         [24] 2242 	mov	dptr,#_control_setup_length_10000_289
      00651A E8               [12] 2243 	mov	a,r0
      00651B F0               [24] 2244 	movx	@dptr,a
      00651C E4               [12] 2245 	clr	a
      00651D A3               [24] 2246 	inc	dptr
      00651E F0               [24] 2247 	movx	@dptr,a
                                   2248 ;	tmk_core/protocol/ch555/usb_ak820.c:330: offset = shared_offsets[report_id];
      00651F E9               [12] 2249 	mov	a,r1
      006520 90 BB AA         [24] 2250 	mov	dptr,#_shared_offsets
      006523 93               [24] 2251 	movc	a,@a+dptr
      006524 90 07 E4         [24] 2252 	mov	dptr,#_control_setup_offset_10000_289
      006527 F0               [24] 2253 	movx	@dptr,a
      006528 02 66 84         [24] 2254 	ljmp	00252$
      00652B                       2255 00245$:
                                   2256 ;	tmk_core/protocol/ch555/usb_ak820.c:331: } else if ((value >> 8) == 1 && index == RAW_INTERFACE && !report_id) {
      00652B E5 17            [12] 2257 	mov	a,_control_setup_sloc3_1_0
      00652D 60 7A            [24] 2258 	jz	00240$
      00652F BB 01 77         [24] 2259 	cjne	r3,#0x01,00240$
      006532 BC 00 74         [24] 2260 	cjne	r4,#0x00,00240$
      006535 E9               [12] 2261 	mov	a,r1
      006536 70 71            [24] 2262 	jnz	00240$
                                   2263 ;	tmk_core/protocol/ch555/usb_ak820.c:332: length = D0SetupLen < RAW_EPSIZE ? D0SetupLen : RAW_EPSIZE;
      006538 90 07 7A         [24] 2264 	mov	dptr,#_D0SetupLen
      00653B E0               [24] 2265 	movx	a,@dptr
      00653C F8               [12] 2266 	mov	r0,a
      00653D A3               [24] 2267 	inc	dptr
      00653E E0               [24] 2268 	movx	a,@dptr
      00653F F9               [12] 2269 	mov	r1,a
      006540 C3               [12] 2270 	clr	c
      006541 E8               [12] 2271 	mov	a,r0
      006542 94 20            [12] 2272 	subb	a,#0x20
      006544 E9               [12] 2273 	mov	a,r1
      006545 94 00            [12] 2274 	subb	a,#0x00
      006547 50 0A            [24] 2275 	jnc	00320$
      006549 90 07 7A         [24] 2276 	mov	dptr,#_D0SetupLen
      00654C E0               [24] 2277 	movx	a,@dptr
      00654D F8               [12] 2278 	mov	r0,a
      00654E A3               [24] 2279 	inc	dptr
      00654F E0               [24] 2280 	movx	a,@dptr
      006550 F9               [12] 2281 	mov	r1,a
      006551 80 04            [24] 2282 	sjmp	00321$
      006553                       2283 00320$:
      006553 78 20            [12] 2284 	mov	r0,#0x20
      006555 79 00            [12] 2285 	mov	r1,#0x00
      006557                       2286 00321$:
                                   2287 ;	tmk_core/protocol/ch555/usb_ak820.c:333: for (i = 0; i < length; ++i) pD0_EP0_BUF[i] = pUSB_BUF_DEV0[UX_EP3_ADDR + i];
      006557 75 17 00         [24] 2288 	mov	_control_setup_sloc3_1_0,#0x00
      00655A                       2289 00293$:
      00655A C0 03            [24] 2290 	push	ar3
      00655C C0 04            [24] 2291 	push	ar4
      00655E AB 17            [24] 2292 	mov	r3,_control_setup_sloc3_1_0
      006560 7C 00            [12] 2293 	mov	r4,#0x00
      006562 C3               [12] 2294 	clr	c
      006563 EB               [12] 2295 	mov	a,r3
      006564 98               [12] 2296 	subb	a,r0
      006565 EC               [12] 2297 	mov	a,r4
      006566 99               [12] 2298 	subb	a,r1
      006567 D0 04            [24] 2299 	pop	ar4
      006569 D0 03            [24] 2300 	pop	ar3
      00656B 50 32            [24] 2301 	jnc	00222$
      00656D C0 00            [24] 2302 	push	ar0
      00656F C0 01            [24] 2303 	push	ar1
      006571 85 17 19         [24] 2304 	mov	_control_setup_sloc4_1_0,_control_setup_sloc3_1_0
      006574 74 10            [12] 2305 	mov	a,#0x10
      006576 24 00            [12] 2306 	add	a, #0x00
      006578 F5 1A            [12] 2307 	mov	(_control_setup_sloc4_1_0 + 1),a
      00657A A8 17            [24] 2308 	mov	r0,_control_setup_sloc3_1_0
      00657C 79 00            [12] 2309 	mov	r1,#0x00
      00657E 74 C0            [12] 2310 	mov	a,#0xc0
      006580 28               [12] 2311 	add	a, r0
      006581 F8               [12] 2312 	mov	r0,a
      006582 E4               [12] 2313 	clr	a
      006583 39               [12] 2314 	addc	a, r1
      006584 F9               [12] 2315 	mov	r1,a
      006585 88 82            [24] 2316 	mov	dpl,r0
      006587 74 10            [12] 2317 	mov	a,#0x10
      006589 29               [12] 2318 	add	a, r1
      00658A F5 83            [12] 2319 	mov	dph,a
      00658C E0               [24] 2320 	movx	a,@dptr
      00658D 85 19 82         [24] 2321 	mov	dpl,_control_setup_sloc4_1_0
      006590 85 1A 83         [24] 2322 	mov	dph,(_control_setup_sloc4_1_0 + 1)
      006593 F0               [24] 2323 	movx	@dptr,a
      006594 E5 17            [12] 2324 	mov	a,_control_setup_sloc3_1_0
      006596 04               [12] 2325 	inc	a
      006597 F5 17            [12] 2326 	mov	_control_setup_sloc3_1_0,a
      006599 D0 01            [24] 2327 	pop	ar1
      00659B D0 00            [24] 2328 	pop	ar0
      00659D 80 BB            [24] 2329 	sjmp	00293$
      00659F                       2330 00222$:
                                   2331 ;	tmk_core/protocol/ch555/usb_ak820.c:334: length = 0; /* data already copied */
      00659F 90 07 E2         [24] 2332 	mov	dptr,#_control_setup_length_10000_289
      0065A2 E4               [12] 2333 	clr	a
      0065A3 F0               [24] 2334 	movx	@dptr,a
      0065A4 A3               [24] 2335 	inc	dptr
      0065A5 F0               [24] 2336 	movx	@dptr,a
      0065A6 02 66 84         [24] 2337 	ljmp	00252$
      0065A9                       2338 00240$:
                                   2339 ;	tmk_core/protocol/ch555/usb_ak820.c:335: } else if (value == 0x0200 && index == KEYBOARD_INTERFACE) {
      0065A9 8D 00            [24] 2340 	mov	ar0,r5
      0065AB 8E 01            [24] 2341 	mov	ar1,r6
      0065AD B8 00 21         [24] 2342 	cjne	r0,#0x00,00236$
      0065B0 B9 02 1E         [24] 2343 	cjne	r1,#0x02,00236$
      0065B3 EB               [12] 2344 	mov	a,r3
      0065B4 4C               [12] 2345 	orl	a,r4
      0065B5 70 1A            [24] 2346 	jnz	00236$
                                   2347 ;	tmk_core/protocol/ch555/usb_ak820.c:336: pD0_EP0_BUF[0] = KB_USB_SetReport;
      0065B7 90 07 84         [24] 2348 	mov	dptr,#_KB_USB_SetReport
      0065BA E0               [24] 2349 	movx	a,@dptr
      0065BB 90 10 00         [24] 2350 	mov	dptr,#0x1000
      0065BE F0               [24] 2351 	movx	@dptr,a
                                   2352 ;	tmk_core/protocol/ch555/usb_ak820.c:337: length = 0;
      0065BF 90 07 E2         [24] 2353 	mov	dptr,#_control_setup_length_10000_289
      0065C2 E4               [12] 2354 	clr	a
      0065C3 F0               [24] 2355 	movx	@dptr,a
      0065C4 A3               [24] 2356 	inc	dptr
      0065C5 F0               [24] 2357 	movx	@dptr,a
                                   2358 ;	tmk_core/protocol/ch555/usb_ak820.c:338: D0SetupLen = 1;
      0065C6 90 07 7A         [24] 2359 	mov	dptr,#_D0SetupLen
      0065C9 04               [12] 2360 	inc	a
      0065CA F0               [24] 2361 	movx	@dptr,a
      0065CB E4               [12] 2362 	clr	a
      0065CC A3               [24] 2363 	inc	dptr
      0065CD F0               [24] 2364 	movx	@dptr,a
      0065CE 02 66 84         [24] 2365 	ljmp	00252$
      0065D1                       2366 00236$:
                                   2367 ;	tmk_core/protocol/ch555/usb_ak820.c:339: } else if (value == (0x0200 | REPORT_ID_NKRO) && index == SHARED_INTERFACE) {
      0065D1 B8 06 41         [24] 2368 	cjne	r0,#0x06,00232$
      0065D4 B9 02 3E         [24] 2369 	cjne	r1,#0x02,00232$
      0065D7 BB 02 3B         [24] 2370 	cjne	r3,#0x02,00232$
      0065DA BC 00 38         [24] 2371 	cjne	r4,#0x00,00232$
                                   2372 ;	tmk_core/protocol/ch555/usb_ak820.c:340: pD0_EP0_BUF[0] = REPORT_ID_NKRO;
      0065DD C0 03            [24] 2373 	push	ar3
      0065DF C0 04            [24] 2374 	push	ar4
      0065E1 90 10 00         [24] 2375 	mov	dptr,#0x1000
      0065E4 74 06            [12] 2376 	mov	a,#0x06
      0065E6 F0               [24] 2377 	movx	@dptr,a
                                   2378 ;	tmk_core/protocol/ch555/usb_ak820.c:341: pD0_EP0_BUF[1] = KB_USB_SetReport;
      0065E7 90 07 84         [24] 2379 	mov	dptr,#_KB_USB_SetReport
      0065EA E0               [24] 2380 	movx	a,@dptr
      0065EB 90 10 01         [24] 2381 	mov	dptr,#0x1001
      0065EE F0               [24] 2382 	movx	@dptr,a
                                   2383 ;	tmk_core/protocol/ch555/usb_ak820.c:342: length = 0;
      0065EF 90 07 E2         [24] 2384 	mov	dptr,#_control_setup_length_10000_289
      0065F2 E4               [12] 2385 	clr	a
      0065F3 F0               [24] 2386 	movx	@dptr,a
      0065F4 A3               [24] 2387 	inc	dptr
      0065F5 F0               [24] 2388 	movx	@dptr,a
                                   2389 ;	tmk_core/protocol/ch555/usb_ak820.c:343: if (D0SetupLen > 2) D0SetupLen = 2;
      0065F6 90 07 7A         [24] 2390 	mov	dptr,#_D0SetupLen
      0065F9 E0               [24] 2391 	movx	a,@dptr
      0065FA FB               [12] 2392 	mov	r3,a
      0065FB A3               [24] 2393 	inc	dptr
      0065FC E0               [24] 2394 	movx	a,@dptr
      0065FD FC               [12] 2395 	mov	r4,a
      0065FE C3               [12] 2396 	clr	c
      0065FF 74 02            [12] 2397 	mov	a,#0x02
      006601 9B               [12] 2398 	subb	a,r3
      006602 E4               [12] 2399 	clr	a
      006603 9C               [12] 2400 	subb	a,r4
      006604 D0 04            [24] 2401 	pop	ar4
      006606 D0 03            [24] 2402 	pop	ar3
      006608 50 7A            [24] 2403 	jnc	00252$
                                   2404 ;	free result
      00660A 90 07 7A         [24] 2405 	mov	dptr,#_D0SetupLen
      00660D 74 02            [12] 2406 	mov	a,#0x02
      00660F F0               [24] 2407 	movx	@dptr,a
      006610 E4               [12] 2408 	clr	a
      006611 A3               [24] 2409 	inc	dptr
      006612 F0               [24] 2410 	movx	@dptr,a
      006613 80 6F            [24] 2411 	sjmp	00252$
      006615                       2412 00232$:
                                   2413 ;	tmk_core/protocol/ch555/usb_ak820.c:344: } else if (value == 0x0300 && index == RAW_INTERFACE) {
      006615 B8 00 69         [24] 2414 	cjne	r0,#0x00,00228$
      006618 B9 03 66         [24] 2415 	cjne	r1,#0x03,00228$
      00661B BB 01 63         [24] 2416 	cjne	r3,#0x01,00228$
      00661E BC 00 60         [24] 2417 	cjne	r4,#0x00,00228$
                                   2418 ;	tmk_core/protocol/ch555/usb_ak820.c:347: pD0_EP0_BUF[0] = 'A';
      006621 90 10 00         [24] 2419 	mov	dptr,#0x1000
      006624 74 41            [12] 2420 	mov	a,#0x41
      006626 F0               [24] 2421 	movx	@dptr,a
                                   2422 ;	tmk_core/protocol/ch555/usb_ak820.c:348: pD0_EP0_BUF[1] = 'K';
      006627 A3               [24] 2423 	inc	dptr
      006628 74 4B            [12] 2424 	mov	a,#0x4b
      00662A F0               [24] 2425 	movx	@dptr,a
                                   2426 ;	tmk_core/protocol/ch555/usb_ak820.c:349: pD0_EP0_BUF[2] = 'B';
      00662B A3               [24] 2427 	inc	dptr
      00662C 74 42            [12] 2428 	mov	a,#0x42
      00662E F0               [24] 2429 	movx	@dptr,a
                                   2430 ;	tmk_core/protocol/ch555/usb_ak820.c:350: pD0_EP0_BUF[3] = 'T';
      00662F A3               [24] 2431 	inc	dptr
      006630 74 54            [12] 2432 	mov	a,#0x54
      006632 F0               [24] 2433 	movx	@dptr,a
                                   2434 ;	tmk_core/protocol/ch555/usb_ak820.c:351: pD0_EP0_BUF[4] = 1;
      006633 A3               [24] 2435 	inc	dptr
      006634 74 01            [12] 2436 	mov	a,#0x01
      006636 F0               [24] 2437 	movx	@dptr,a
                                   2438 ;	tmk_core/protocol/ch555/usb_ak820.c:352: pD0_EP0_BUF[5] = ak820_boot_stage;
      006637 90 07 85         [24] 2439 	mov	dptr,#_ak820_boot_stage
      00663A E0               [24] 2440 	movx	a,@dptr
      00663B 90 10 05         [24] 2441 	mov	dptr,#0x1005
      00663E F0               [24] 2442 	movx	@dptr,a
                                   2443 ;	tmk_core/protocol/ch555/usb_ak820.c:353: pD0_EP0_BUF[6] = ak820_main_heartbeat;
      00663F 90 07 86         [24] 2444 	mov	dptr,#_ak820_main_heartbeat
      006642 E0               [24] 2445 	movx	a,@dptr
      006643 90 10 06         [24] 2446 	mov	dptr,#0x1006
      006646 F0               [24] 2447 	movx	@dptr,a
                                   2448 ;	tmk_core/protocol/ch555/usb_ak820.c:354: pD0_EP0_BUF[7] = (USB_EnumStatus ? 1 : 0) | (USB_SleepStatus & 2);
      006647 90 07 80         [24] 2449 	mov	dptr,#_USB_EnumStatus
      00664A E0               [24] 2450 	movx	a,@dptr
      00664B 60 02            [24] 2451 	jz	00322$
      00664D 74 01            [12] 2452 	mov	a,#0x01
      00664F                       2453 00322$:
      00664F F9               [12] 2454 	mov	r1,a
      006650 90 07 81         [24] 2455 	mov	dptr,#_USB_SleepStatus
      006653 E0               [24] 2456 	movx	a,@dptr
      006654 54 02            [12] 2457 	anl	a,#0x02
      006656 F8               [12] 2458 	mov	r0,a
      006657 E9               [12] 2459 	mov	a,r1
      006658 42 00            [12] 2460 	orl	ar0,a
      00665A 90 10 07         [24] 2461 	mov	dptr,#0x1007
      00665D E8               [12] 2462 	mov	a,r0
      00665E F0               [24] 2463 	movx	@dptr,a
                                   2464 ;	tmk_core/protocol/ch555/usb_ak820.c:355: length = 0;
      00665F 90 07 E2         [24] 2465 	mov	dptr,#_control_setup_length_10000_289
      006662 E4               [12] 2466 	clr	a
      006663 F0               [24] 2467 	movx	@dptr,a
      006664 A3               [24] 2468 	inc	dptr
      006665 F0               [24] 2469 	movx	@dptr,a
                                   2470 ;	tmk_core/protocol/ch555/usb_ak820.c:356: if (D0SetupLen > 8) D0SetupLen = 8;
      006666 90 07 7A         [24] 2471 	mov	dptr,#_D0SetupLen
      006669 E0               [24] 2472 	movx	a,@dptr
      00666A F8               [12] 2473 	mov	r0,a
      00666B A3               [24] 2474 	inc	dptr
      00666C E0               [24] 2475 	movx	a,@dptr
      00666D F9               [12] 2476 	mov	r1,a
      00666E C3               [12] 2477 	clr	c
      00666F 74 08            [12] 2478 	mov	a,#0x08
      006671 98               [12] 2479 	subb	a,r0
      006672 E4               [12] 2480 	clr	a
      006673 99               [12] 2481 	subb	a,r1
      006674 50 0E            [24] 2482 	jnc	00252$
                                   2483 ;	free result
      006676 90 07 7A         [24] 2484 	mov	dptr,#_D0SetupLen
      006679 74 08            [12] 2485 	mov	a,#0x08
      00667B F0               [24] 2486 	movx	@dptr,a
      00667C E4               [12] 2487 	clr	a
      00667D A3               [24] 2488 	inc	dptr
      00667E F0               [24] 2489 	movx	@dptr,a
      00667F 80 03            [24] 2490 	sjmp	00252$
      006681                       2491 00228$:
                                   2492 ;	tmk_core/protocol/ch555/usb_ak820.c:357: } else { control_stall(); return; }
      006681 02 5D EA         [24] 2493 	ljmp	_control_stall
      006684                       2494 00252$:
                                   2495 ;	tmk_core/protocol/ch555/usb_ak820.c:358: if (length) {
      006684 90 07 E2         [24] 2496 	mov	dptr,#_control_setup_length_10000_289
      006687 E0               [24] 2497 	movx	a,@dptr
      006688 F5 19            [12] 2498 	mov	_control_setup_sloc4_1_0,a
      00668A A3               [24] 2499 	inc	dptr
      00668B E0               [24] 2500 	movx	a,@dptr
      00668C F5 1A            [12] 2501 	mov	(_control_setup_sloc4_1_0 + 1),a
      00668E E5 19            [12] 2502 	mov	a,_control_setup_sloc4_1_0
      006690 45 1A            [12] 2503 	orl	a,(_control_setup_sloc4_1_0 + 1)
      006692 60 50            [24] 2504 	jz	00262$
                                   2505 ;	tmk_core/protocol/ch555/usb_ak820.c:359: if (D0SetupLen > length) D0SetupLen = length;
      006694 90 07 7A         [24] 2506 	mov	dptr,#_D0SetupLen
      006697 E0               [24] 2507 	movx	a,@dptr
      006698 F8               [12] 2508 	mov	r0,a
      006699 A3               [24] 2509 	inc	dptr
      00669A E0               [24] 2510 	movx	a,@dptr
      00669B F9               [12] 2511 	mov	r1,a
      00669C C3               [12] 2512 	clr	c
      00669D E5 19            [12] 2513 	mov	a,_control_setup_sloc4_1_0
      00669F 98               [12] 2514 	subb	a,r0
      0066A0 E5 1A            [12] 2515 	mov	a,(_control_setup_sloc4_1_0 + 1)
      0066A2 99               [12] 2516 	subb	a,r1
      0066A3 50 0A            [24] 2517 	jnc	00559$
                                   2518 ;	free result
      0066A5 90 07 7A         [24] 2519 	mov	dptr,#_D0SetupLen
      0066A8 E5 19            [12] 2520 	mov	a,_control_setup_sloc4_1_0
      0066AA F0               [24] 2521 	movx	@dptr,a
      0066AB E5 1A            [12] 2522 	mov	a,(_control_setup_sloc4_1_0 + 1)
      0066AD A3               [24] 2523 	inc	dptr
      0066AE F0               [24] 2524 	movx	@dptr,a
                                   2525 ;	tmk_core/protocol/ch555/usb_ak820.c:362: for (i = 0; i < (uint8_t)D0SetupLen; ++i) pD0_EP0_BUF[i] = input_snapshot[offset + i];
      0066AF                       2526 00559$:
      0066AF 75 19 00         [24] 2527 	mov	_control_setup_sloc4_1_0,#0x00
      0066B2                       2528 00296$:
      0066B2 90 07 7A         [24] 2529 	mov	dptr,#_D0SetupLen
      0066B5 E0               [24] 2530 	movx	a,@dptr
      0066B6 F8               [12] 2531 	mov	r0,a
      0066B7 C3               [12] 2532 	clr	c
      0066B8 E5 19            [12] 2533 	mov	a,_control_setup_sloc4_1_0
      0066BA 98               [12] 2534 	subb	a,r0
      0066BB 50 46            [24] 2535 	jnc	00263$
      0066BD 85 19 17         [24] 2536 	mov	_control_setup_sloc3_1_0,_control_setup_sloc4_1_0
      0066C0 74 10            [12] 2537 	mov	a,#0x10
      0066C2 24 00            [12] 2538 	add	a, #0x00
      0066C4 F5 18            [12] 2539 	mov	(_control_setup_sloc3_1_0 + 1),a
      0066C6 90 07 E4         [24] 2540 	mov	dptr,#_control_setup_offset_10000_289
      0066C9 E0               [24] 2541 	movx	a,@dptr
      0066CA 25 19            [12] 2542 	add	a, _control_setup_sloc4_1_0
      0066CC 24 AA            [12] 2543 	add	a, #_input_snapshot
      0066CE F5 82            [12] 2544 	mov	dpl,a
      0066D0 E4               [12] 2545 	clr	a
      0066D1 34 07            [12] 2546 	addc	a,#(_input_snapshot >> 8)
      0066D3 F5 83            [12] 2547 	mov	dph,a
      0066D5 E0               [24] 2548 	movx	a,@dptr
      0066D6 85 17 82         [24] 2549 	mov	dpl,_control_setup_sloc3_1_0
      0066D9 85 18 83         [24] 2550 	mov	dph,(_control_setup_sloc3_1_0 + 1)
      0066DC F0               [24] 2551 	movx	@dptr,a
      0066DD E5 19            [12] 2552 	mov	a,_control_setup_sloc4_1_0
      0066DF 04               [12] 2553 	inc	a
      0066E0 F5 19            [12] 2554 	mov	_control_setup_sloc4_1_0,a
      0066E2 80 CE            [24] 2555 	sjmp	00296$
      0066E4                       2556 00262$:
                                   2557 ;	tmk_core/protocol/ch555/usb_ak820.c:363: } else if (index == RAW_INTERFACE && D0SetupLen > RAW_EPSIZE) D0SetupLen = RAW_EPSIZE;
      0066E4 BB 01 1C         [24] 2558 	cjne	r3,#0x01,00263$
      0066E7 BC 00 19         [24] 2559 	cjne	r4,#0x00,00263$
      0066EA 90 07 7A         [24] 2560 	mov	dptr,#_D0SetupLen
      0066ED E0               [24] 2561 	movx	a,@dptr
      0066EE F8               [12] 2562 	mov	r0,a
      0066EF A3               [24] 2563 	inc	dptr
      0066F0 E0               [24] 2564 	movx	a,@dptr
      0066F1 F9               [12] 2565 	mov	r1,a
      0066F2 C3               [12] 2566 	clr	c
      0066F3 74 20            [12] 2567 	mov	a,#0x20
      0066F5 98               [12] 2568 	subb	a,r0
      0066F6 E4               [12] 2569 	clr	a
      0066F7 99               [12] 2570 	subb	a,r1
      0066F8 50 09            [24] 2571 	jnc	00263$
                                   2572 ;	free result
      0066FA 90 07 7A         [24] 2573 	mov	dptr,#_D0SetupLen
      0066FD 74 20            [12] 2574 	mov	a,#0x20
      0066FF F0               [24] 2575 	movx	@dptr,a
      006700 E4               [12] 2576 	clr	a
      006701 A3               [24] 2577 	inc	dptr
      006702 F0               [24] 2578 	movx	@dptr,a
      006703                       2579 00263$:
                                   2580 ;	tmk_core/protocol/ch555/usb_ak820.c:364: D0_EP0T_L = D0SetupLen;
      006703 90 07 7A         [24] 2581 	mov	dptr,#_D0SetupLen
      006706 E0               [24] 2582 	movx	a,@dptr
      006707 90 22 08         [24] 2583 	mov	dptr,#0x2208
      00670A F0               [24] 2584 	movx	@dptr,a
                                   2585 ;	tmk_core/protocol/ch555/usb_ak820.c:365: control_phase = CTRL_STATUS_OUT;
      00670B 90 07 D8         [24] 2586 	mov	dptr,#_control_phase
      00670E 74 02            [12] 2587 	mov	a,#0x02
      006710 F0               [24] 2588 	movx	@dptr,a
      006711 02 67 99         [24] 2589 	ljmp	00291$
      006714                       2590 00273$:
                                   2591 ;	tmk_core/protocol/ch555/usb_ak820.c:366: } else if (index == KEYBOARD_INTERFACE && D0UsbConfig && type == 0xa1 && D0SetupReqCode == DEF_USB_GET_PROTOCOL && zero_value && D0SetupLen == 1) {
      006714 EB               [12] 2592 	mov	a,r3
      006715 4C               [12] 2593 	orl	a,r4
      006716 70 37            [24] 2594 	jnz	00265$
      006718 90 07 7F         [24] 2595 	mov	dptr,#_D0UsbConfig
      00671B E0               [24] 2596 	movx	a,@dptr
      00671C 60 31            [24] 2597 	jz	00265$
      00671E EA               [12] 2598 	mov	a,r2
      00671F 60 2E            [24] 2599 	jz	00265$
      006721 90 07 79         [24] 2600 	mov	dptr,#_D0SetupReqCode
      006724 E0               [24] 2601 	movx	a,@dptr
      006725 FA               [12] 2602 	mov	r2,a
      006726 BA 03 26         [24] 2603 	cjne	r2,#0x03,00265$
      006729 30 17 23         [24] 2604 	jnb	_control_setup_zero_value_10000_289,00265$
      00672C 90 07 7A         [24] 2605 	mov	dptr,#_D0SetupLen
      00672F E0               [24] 2606 	movx	a,@dptr
      006730 F9               [12] 2607 	mov	r1,a
      006731 A3               [24] 2608 	inc	dptr
      006732 E0               [24] 2609 	movx	a,@dptr
      006733 FA               [12] 2610 	mov	r2,a
      006734 B9 01 18         [24] 2611 	cjne	r1,#0x01,00265$
      006737 BA 00 15         [24] 2612 	cjne	r2,#0x00,00265$
                                   2613 ;	tmk_core/protocol/ch555/usb_ak820.c:367: pD0_EP0_BUF[0] = keyboard_protocol;
      00673A 90 0D 9C         [24] 2614 	mov	dptr,#_keyboard_protocol
      00673D E0               [24] 2615 	movx	a,@dptr
      00673E 90 10 00         [24] 2616 	mov	dptr,#0x1000
      006741 F0               [24] 2617 	movx	@dptr,a
                                   2618 ;	tmk_core/protocol/ch555/usb_ak820.c:368: D0_EP0T_L = 1;
      006742 90 22 08         [24] 2619 	mov	dptr,#0x2208
      006745 74 01            [12] 2620 	mov	a,#0x01
      006747 F0               [24] 2621 	movx	@dptr,a
                                   2622 ;	tmk_core/protocol/ch555/usb_ak820.c:369: control_phase = CTRL_STATUS_OUT;
      006748 90 07 D8         [24] 2623 	mov	dptr,#_control_phase
      00674B 04               [12] 2624 	inc	a
      00674C F0               [24] 2625 	movx	@dptr,a
      00674D 80 4A            [24] 2626 	sjmp	00291$
      00674F                       2627 00265$:
                                   2628 ;	tmk_core/protocol/ch555/usb_ak820.c:370: } else { control_stall(); return; }
                                   2629 ;	tmk_core/protocol/ch555/usb_ak820.c:372: case DEF_USB_GET_IDLE:
      00674F 02 5D EA         [24] 2630 	ljmp	_control_stall
      006752                       2631 00282$:
                                   2632 ;	tmk_core/protocol/ch555/usb_ak820.c:373: if (valid_interface && D0UsbConfig && type == 0xa1 && !(value >> 8) && D0SetupLen == 1) {
      006752 30 15 3E         [24] 2633 	jnb	_control_setup_valid_interface_10000_289,00284$
      006755 90 07 7F         [24] 2634 	mov	dptr,#_D0UsbConfig
      006758 E0               [24] 2635 	movx	a,@dptr
      006759 60 38            [24] 2636 	jz	00284$
      00675B BF A1 35         [24] 2637 	cjne	r7,#0xa1,00284$
      00675E 8E 05            [24] 2638 	mov	ar5,r6
      006760 7E 00            [12] 2639 	mov	r6,#0x00
      006762 ED               [12] 2640 	mov	a,r5
      006763 4E               [12] 2641 	orl	a,r6
      006764 70 2D            [24] 2642 	jnz	00284$
      006766 90 07 7A         [24] 2643 	mov	dptr,#_D0SetupLen
      006769 E0               [24] 2644 	movx	a,@dptr
      00676A FE               [12] 2645 	mov	r6,a
      00676B A3               [24] 2646 	inc	dptr
      00676C E0               [24] 2647 	movx	a,@dptr
      00676D FF               [12] 2648 	mov	r7,a
      00676E BE 01 22         [24] 2649 	cjne	r6,#0x01,00284$
      006771 BF 00 1F         [24] 2650 	cjne	r7,#0x00,00284$
                                   2651 ;	tmk_core/protocol/ch555/usb_ak820.c:374: pD0_EP0_BUF[0] = index == KEYBOARD_INTERFACE ? keyboard_idle : 0;
      006774 EB               [12] 2652 	mov	a,r3
      006775 4C               [12] 2653 	orl	a,r4
      006776 70 07            [24] 2654 	jnz	00324$
      006778 90 06 57         [24] 2655 	mov	dptr,#_keyboard_idle
      00677B E0               [24] 2656 	movx	a,@dptr
      00677C FF               [12] 2657 	mov	r7,a
      00677D 80 02            [24] 2658 	sjmp	00325$
      00677F                       2659 00324$:
      00677F 7F 00            [12] 2660 	mov	r7,#0x00
      006781                       2661 00325$:
      006781 90 10 00         [24] 2662 	mov	dptr,#0x1000
      006784 EF               [12] 2663 	mov	a,r7
      006785 F0               [24] 2664 	movx	@dptr,a
                                   2665 ;	tmk_core/protocol/ch555/usb_ak820.c:375: D0_EP0T_L = 1;
      006786 90 22 08         [24] 2666 	mov	dptr,#0x2208
      006789 74 01            [12] 2667 	mov	a,#0x01
      00678B F0               [24] 2668 	movx	@dptr,a
                                   2669 ;	tmk_core/protocol/ch555/usb_ak820.c:376: control_phase = CTRL_STATUS_OUT;
      00678C 90 07 D8         [24] 2670 	mov	dptr,#_control_phase
      00678F 04               [12] 2671 	inc	a
      006790 F0               [24] 2672 	movx	@dptr,a
      006791 80 06            [24] 2673 	sjmp	00291$
      006793                       2674 00284$:
                                   2675 ;	tmk_core/protocol/ch555/usb_ak820.c:377: } else { control_stall(); return; }
                                   2676 ;	tmk_core/protocol/ch555/usb_ak820.c:379: default: control_stall(); return;
      006793 02 5D EA         [24] 2677 	ljmp	_control_stall
      006796                       2678 00290$:
                                   2679 ;	tmk_core/protocol/ch555/usb_ak820.c:380: }
      006796 02 5D EA         [24] 2680 	ljmp	_control_stall
      006799                       2681 00291$:
                                   2682 ;	tmk_core/protocol/ch555/usb_ak820.c:381: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_ACK | UEP_T_RES_ACK;
      006799 90 22 00         [24] 2683 	mov	dptr,#0x2200
      00679C 74 C0            [12] 2684 	mov	a,#0xc0
      00679E F0               [24] 2685 	movx	@dptr,a
                                   2686 ;	tmk_core/protocol/ch555/usb_ak820.c:382: }
      00679F 22               [24] 2687 	ret
                                   2688 ;------------------------------------------------------------
                                   2689 ;Allocation info for local variables in function 'control_out'
                                   2690 ;------------------------------------------------------------
                                   2691 ;i             Allocated with name '_control_out_i_10000_373'
                                   2692 ;------------------------------------------------------------
                                   2693 ;	tmk_core/protocol/ch555/usb_ak820.c:384: static void control_out(void) {
                                   2694 ;	-----------------------------------------
                                   2695 ;	 function control_out
                                   2696 ;	-----------------------------------------
      0067A0                       2697 _control_out:
                                   2698 ;	tmk_core/protocol/ch555/usb_ak820.c:386: if (!(D0_STATUS & bUXS_TOG_OK)) return; /* duplicate OUT is not a new request */
      0067A0 90 22 0F         [24] 2699 	mov	dptr,#0x220f
      0067A3 E0               [24] 2700 	movx	a,@dptr
      0067A4 20 E6 01         [24] 2701 	jb	acc.6,00102$
      0067A7 22               [24] 2702 	ret
      0067A8                       2703 00102$:
                                   2704 ;	tmk_core/protocol/ch555/usb_ak820.c:387: if (control_phase == CTRL_STATUS_OUT && D0_RX_LEN == 0) {
      0067A8 90 07 D8         [24] 2705 	mov	dptr,#_control_phase
      0067AB E0               [24] 2706 	movx	a,@dptr
      0067AC FF               [12] 2707 	mov	r7,a
      0067AD BF 02 12         [24] 2708 	cjne	r7,#0x02,00104$
      0067B0 90 22 0E         [24] 2709 	mov	dptr,#0x220e
      0067B3 E0               [24] 2710 	movx	a,@dptr
      0067B4 70 0C            [24] 2711 	jnz	00104$
                                   2712 ;	tmk_core/protocol/ch555/usb_ak820.c:388: control_phase = CTRL_IDLE;
      0067B6 90 07 D8         [24] 2713 	mov	dptr,#_control_phase
      0067B9 E4               [12] 2714 	clr	a
      0067BA F0               [24] 2715 	movx	@dptr,a
                                   2716 ;	tmk_core/protocol/ch555/usb_ak820.c:389: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      0067BB 90 22 00         [24] 2717 	mov	dptr,#0x2200
      0067BE 74 02            [12] 2718 	mov	a,#0x02
      0067C0 F0               [24] 2719 	movx	@dptr,a
                                   2720 ;	tmk_core/protocol/ch555/usb_ak820.c:390: return;
      0067C1 22               [24] 2721 	ret
      0067C2                       2722 00104$:
                                   2723 ;	tmk_core/protocol/ch555/usb_ak820.c:392: if (control_phase != CTRL_DATA_OUT || D0_RX_LEN != D0SetupLen) { control_stall(); return; }
      0067C2 BF 04 19         [24] 2724 	cjne	r7,#0x04,00106$
      0067C5 90 22 0E         [24] 2725 	mov	dptr,#0x220e
      0067C8 E0               [24] 2726 	movx	a,@dptr
      0067C9 FF               [12] 2727 	mov	r7,a
      0067CA 90 07 7A         [24] 2728 	mov	dptr,#_D0SetupLen
      0067CD E0               [24] 2729 	movx	a,@dptr
      0067CE FD               [12] 2730 	mov	r5,a
      0067CF A3               [24] 2731 	inc	dptr
      0067D0 E0               [24] 2732 	movx	a,@dptr
      0067D1 FE               [12] 2733 	mov	r6,a
      0067D2 7C 00            [12] 2734 	mov	r4,#0x00
      0067D4 EF               [12] 2735 	mov	a,r7
      0067D5 B5 05 06         [24] 2736 	cjne	a,ar5,00209$
      0067D8 EC               [12] 2737 	mov	a,r4
      0067D9 B5 06 02         [24] 2738 	cjne	a,ar6,00209$
      0067DC 80 03            [24] 2739 	sjmp	00107$
      0067DE                       2740 00209$:
      0067DE                       2741 00106$:
      0067DE 02 5D EA         [24] 2742 	ljmp	_control_stall
      0067E1                       2743 00107$:
                                   2744 ;	tmk_core/protocol/ch555/usb_ak820.c:393: if (output_kind == OUTPUT_RAW && raw_state == RAW_RX) {
      0067E1 90 07 D9         [24] 2745 	mov	dptr,#_output_kind
      0067E4 E0               [24] 2746 	movx	a,@dptr
      0067E5 FF               [12] 2747 	mov	r7,a
      0067E6 BF 01 2E         [24] 2748 	cjne	r7,#0x01,00118$
      0067E9 90 07 87         [24] 2749 	mov	dptr,#_raw_state
      0067EC E0               [24] 2750 	movx	a,@dptr
      0067ED FE               [12] 2751 	mov	r6,a
      0067EE BE 01 26         [24] 2752 	cjne	r6,#0x01,00118$
                                   2753 ;	tmk_core/protocol/ch555/usb_ak820.c:394: for (i = 0; i < RAW_EPSIZE; ++i) raw_buffer[i] = pD0_EP0_BUF[i];
      0067F1 7E 00            [12] 2754 	mov	r6,#0x00
      0067F3                       2755 00121$:
      0067F3 EE               [12] 2756 	mov	a,r6
      0067F4 24 88            [12] 2757 	add	a, #_raw_buffer
      0067F6 FC               [12] 2758 	mov	r4,a
      0067F7 E4               [12] 2759 	clr	a
      0067F8 34 07            [12] 2760 	addc	a, #(_raw_buffer >> 8)
      0067FA FD               [12] 2761 	mov	r5,a
      0067FB 8E 82            [24] 2762 	mov	dpl,r6
      0067FD 74 10            [12] 2763 	mov	a,#0x10
      0067FF 24 00            [12] 2764 	add	a, #0x00
      006801 F5 83            [12] 2765 	mov	dph,a
      006803 E0               [24] 2766 	movx	a,@dptr
      006804 8C 82            [24] 2767 	mov	dpl,r4
      006806 8D 83            [24] 2768 	mov	dph,r5
      006808 F0               [24] 2769 	movx	@dptr,a
      006809 0E               [12] 2770 	inc	r6
      00680A BE 20 00         [24] 2771 	cjne	r6,#0x20,00214$
      00680D                       2772 00214$:
      00680D 40 E4            [24] 2773 	jc	00121$
                                   2774 ;	tmk_core/protocol/ch555/usb_ak820.c:395: raw_state = RAW_READY; /* publish only after the entire packet is copied */
      00680F 90 07 87         [24] 2775 	mov	dptr,#_raw_state
      006812 74 02            [12] 2776 	mov	a,#0x02
      006814 F0               [24] 2777 	movx	@dptr,a
      006815 80 2B            [24] 2778 	sjmp	00119$
      006817                       2779 00118$:
                                   2780 ;	tmk_core/protocol/ch555/usb_ak820.c:396: } else if (output_kind == OUTPUT_LED) {
      006817 BF 02 0A         [24] 2781 	cjne	r7,#0x02,00115$
                                   2782 ;	tmk_core/protocol/ch555/usb_ak820.c:397: KB_USB_SetReport = pD0_EP0_BUF[0];
      00681A 90 10 00         [24] 2783 	mov	dptr,#0x1000
      00681D E0               [24] 2784 	movx	a,@dptr
      00681E 90 07 84         [24] 2785 	mov	dptr,#_KB_USB_SetReport
      006821 F0               [24] 2786 	movx	@dptr,a
      006822 80 1E            [24] 2787 	sjmp	00119$
      006824                       2788 00115$:
                                   2789 ;	tmk_core/protocol/ch555/usb_ak820.c:398: } else if (output_kind == OUTPUT_SHARED_LED && pD0_EP0_BUF[0] == output_report_id) {
      006824 BF 03 18         [24] 2790 	cjne	r7,#0x03,00111$
      006827 90 10 00         [24] 2791 	mov	dptr,#0x1000
      00682A E0               [24] 2792 	movx	a,@dptr
      00682B FF               [12] 2793 	mov	r7,a
      00682C 90 07 DA         [24] 2794 	mov	dptr,#_output_report_id
      00682F E0               [24] 2795 	movx	a,@dptr
      006830 FE               [12] 2796 	mov	r6,a
      006831 EF               [12] 2797 	mov	a,r7
      006832 B5 06 0A         [24] 2798 	cjne	a,ar6,00111$
                                   2799 ;	tmk_core/protocol/ch555/usb_ak820.c:399: KB_USB_SetReport = pD0_EP0_BUF[1];
      006835 90 10 01         [24] 2800 	mov	dptr,#0x1001
      006838 E0               [24] 2801 	movx	a,@dptr
      006839 90 07 84         [24] 2802 	mov	dptr,#_KB_USB_SetReport
      00683C F0               [24] 2803 	movx	@dptr,a
      00683D 80 03            [24] 2804 	sjmp	00119$
      00683F                       2805 00111$:
                                   2806 ;	tmk_core/protocol/ch555/usb_ak820.c:400: } else { control_stall(); return; }
      00683F 02 5D EA         [24] 2807 	ljmp	_control_stall
      006842                       2808 00119$:
                                   2809 ;	tmk_core/protocol/ch555/usb_ak820.c:401: output_kind = OUTPUT_NONE;
      006842 90 07 D9         [24] 2810 	mov	dptr,#_output_kind
      006845 E4               [12] 2811 	clr	a
      006846 F0               [24] 2812 	movx	@dptr,a
                                   2813 ;	tmk_core/protocol/ch555/usb_ak820.c:402: D0SetupLen = 0;
      006847 90 07 7A         [24] 2814 	mov	dptr,#_D0SetupLen
      00684A F0               [24] 2815 	movx	@dptr,a
      00684B A3               [24] 2816 	inc	dptr
      00684C F0               [24] 2817 	movx	@dptr,a
                                   2818 ;	tmk_core/protocol/ch555/usb_ak820.c:403: control_phase = CTRL_STATUS_IN;
      00684D 90 07 D8         [24] 2819 	mov	dptr,#_control_phase
      006850 74 03            [12] 2820 	mov	a,#0x03
      006852 F0               [24] 2821 	movx	@dptr,a
                                   2822 ;	tmk_core/protocol/ch555/usb_ak820.c:404: D0_EP0T_L = 0;
      006853 90 22 08         [24] 2823 	mov	dptr,#0x2208
      006856 E4               [12] 2824 	clr	a
      006857 F0               [24] 2825 	movx	@dptr,a
                                   2826 ;	tmk_core/protocol/ch555/usb_ak820.c:405: D0_EP0RES = bUEP_T_TOG | UEP_R_RES_NAK | UEP_T_RES_ACK;
      006858 F5 82            [12] 2827 	mov	dpl,a
      00685A 74 48            [12] 2828 	mov	a,#0x48
      00685C F0               [24] 2829 	movx	@dptr,a
                                   2830 ;	tmk_core/protocol/ch555/usb_ak820.c:406: }
      00685D 22               [24] 2831 	ret
                                   2832 ;------------------------------------------------------------
                                   2833 ;Allocation info for local variables in function 'control_in'
                                   2834 ;------------------------------------------------------------
                                   2835 ;	tmk_core/protocol/ch555/usb_ak820.c:408: static void control_in(void) {
                                   2836 ;	-----------------------------------------
                                   2837 ;	 function control_in
                                   2838 ;	-----------------------------------------
      00685E                       2839 _control_in:
                                   2840 ;	tmk_core/protocol/ch555/usb_ak820.c:409: if (control_phase == CTRL_DATA_IN) {
      00685E 90 07 D8         [24] 2841 	mov	dptr,#_control_phase
      006861 E0               [24] 2842 	movx	a,@dptr
      006862 FF               [12] 2843 	mov	r7,a
      006863 BF 01 22         [24] 2844 	cjne	r7,#0x01,00109$
                                   2845 ;	tmk_core/protocol/ch555/usb_ak820.c:410: if (D0SetupLen || control_zlp) {
      006866 90 07 7A         [24] 2846 	mov	dptr,#_D0SetupLen
      006869 E0               [24] 2847 	movx	a,@dptr
      00686A FD               [12] 2848 	mov	r5,a
      00686B A3               [24] 2849 	inc	dptr
      00686C E0               [24] 2850 	movx	a,@dptr
      00686D 4D               [12] 2851 	orl	a,r5
      00686E 70 06            [24] 2852 	jnz	00101$
      006870 90 07 DB         [24] 2853 	mov	dptr,#_control_zlp
      006873 E0               [24] 2854 	movx	a,@dptr
      006874 60 0A            [24] 2855 	jz	00102$
      006876                       2856 00101$:
                                   2857 ;	tmk_core/protocol/ch555/usb_ak820.c:411: D0_EP0RES ^= bUEP_T_TOG;
      006876 90 22 00         [24] 2858 	mov	dptr,#0x2200
      006879 E0               [24] 2859 	movx	a,@dptr
      00687A 64 40            [12] 2860 	xrl	a,#0x40
      00687C F0               [24] 2861 	movx	@dptr,a
                                   2862 ;	tmk_core/protocol/ch555/usb_ak820.c:412: control_next();
                                   2863 ;	tmk_core/protocol/ch555/usb_ak820.c:413: return;
      00687D 02 5E 0C         [24] 2864 	ljmp	_control_next
      006880                       2865 00102$:
                                   2866 ;	tmk_core/protocol/ch555/usb_ak820.c:415: control_phase = CTRL_STATUS_OUT;
      006880 90 07 D8         [24] 2867 	mov	dptr,#_control_phase
      006883 74 02            [12] 2868 	mov	a,#0x02
      006885 F0               [24] 2869 	movx	@dptr,a
      006886 80 18            [24] 2870 	sjmp	00110$
      006888                       2871 00109$:
                                   2872 ;	tmk_core/protocol/ch555/usb_ak820.c:416: } else if (control_phase == CTRL_STATUS_IN) {
      006888 BF 03 15         [24] 2873 	cjne	r7,#0x03,00110$
                                   2874 ;	tmk_core/protocol/ch555/usb_ak820.c:417: if (D0SetupReqCode == USB_SET_ADDRESS) D0_ADDR = D0SetupLen;
      00688B 90 07 79         [24] 2875 	mov	dptr,#_D0SetupReqCode
      00688E E0               [24] 2876 	movx	a,@dptr
      00688F FF               [12] 2877 	mov	r7,a
      006890 BF 05 08         [24] 2878 	cjne	r7,#0x05,00105$
      006893 90 07 7A         [24] 2879 	mov	dptr,#_D0SetupLen
      006896 E0               [24] 2880 	movx	a,@dptr
      006897 90 22 07         [24] 2881 	mov	dptr,#0x2207
      00689A F0               [24] 2882 	movx	@dptr,a
      00689B                       2883 00105$:
                                   2884 ;	tmk_core/protocol/ch555/usb_ak820.c:418: control_phase = CTRL_IDLE;
      00689B 90 07 D8         [24] 2885 	mov	dptr,#_control_phase
      00689E E4               [12] 2886 	clr	a
      00689F F0               [24] 2887 	movx	@dptr,a
      0068A0                       2888 00110$:
                                   2889 ;	tmk_core/protocol/ch555/usb_ak820.c:420: D0_EP0RES = bUEP_R_TOG | UEP_R_RES_ACK | UEP_T_RES_NAK;
      0068A0 90 22 00         [24] 2890 	mov	dptr,#0x2200
      0068A3 74 82            [12] 2891 	mov	a,#0x82
      0068A5 F0               [24] 2892 	movx	@dptr,a
                                   2893 ;	tmk_core/protocol/ch555/usb_ak820.c:421: }
      0068A6 22               [24] 2894 	ret
                                   2895 ;------------------------------------------------------------
                                   2896 ;Allocation info for local variables in function 'USB_DeviceInterrupt'
                                   2897 ;------------------------------------------------------------
                                   2898 ;status        Allocated with name '_USB_DeviceInterrupt_status_10000_397'
                                   2899 ;endpoint      Allocated with name '_USB_DeviceInterrupt_endpoint_10000_397'
                                   2900 ;------------------------------------------------------------
                                   2901 ;	tmk_core/protocol/ch555/usb_ak820.c:423: void USB_DeviceInterrupt(void) {
                                   2902 ;	-----------------------------------------
                                   2903 ;	 function USB_DeviceInterrupt
                                   2904 ;	-----------------------------------------
      0068A7                       2905 _USB_DeviceInterrupt:
                                   2906 ;	tmk_core/protocol/ch555/usb_ak820.c:426: do {
      0068A7                       2907 00129$:
                                   2908 ;	tmk_core/protocol/ch555/usb_ak820.c:428: if (USB_IF & bUX_IF_BUS_RST) {
      0068A7 90 22 3D         [24] 2909 	mov	dptr,#0x223d
      0068AA E0               [24] 2910 	movx	a,@dptr
      0068AB 30 E0 4B         [24] 2911 	jnb	acc.0,00127$
                                   2912 ;	tmk_core/protocol/ch555/usb_ak820.c:429: endpoints_reset();
      0068AE 12 5D 8F         [24] 2913 	lcall	_endpoints_reset
                                   2914 ;	tmk_core/protocol/ch555/usb_ak820.c:430: D0_ADDR = 0;
      0068B1 90 22 07         [24] 2915 	mov	dptr,#0x2207
      0068B4 E4               [12] 2916 	clr	a
      0068B5 F0               [24] 2917 	movx	@dptr,a
                                   2918 ;	tmk_core/protocol/ch555/usb_ak820.c:431: D0UsbConfig = USB_EnumStatus = USB_SleepStatus = 0;
      0068B6 90 07 81         [24] 2919 	mov	dptr,#_USB_SleepStatus
      0068B9 F0               [24] 2920 	movx	@dptr,a
      0068BA 90 07 80         [24] 2921 	mov	dptr,#_USB_EnumStatus
      0068BD F0               [24] 2922 	movx	@dptr,a
      0068BE 90 07 7F         [24] 2923 	mov	dptr,#_D0UsbConfig
      0068C1 F0               [24] 2924 	movx	@dptr,a
                                   2925 ;	tmk_core/protocol/ch555/usb_ak820.c:432: KB_USB_SetReport = 0;
      0068C2 90 07 84         [24] 2926 	mov	dptr,#_KB_USB_SetReport
      0068C5 F0               [24] 2927 	movx	@dptr,a
                                   2928 ;	tmk_core/protocol/ch555/usb_ak820.c:433: keyboard_protocol = 1;
      0068C6 90 0D 9C         [24] 2929 	mov	dptr,#_keyboard_protocol
      0068C9 04               [12] 2930 	inc	a
      0068CA F0               [24] 2931 	movx	@dptr,a
                                   2932 ;	tmk_core/protocol/ch555/usb_ak820.c:434: keyboard_idle = 0;
      0068CB 90 06 57         [24] 2933 	mov	dptr,#_keyboard_idle
      0068CE E4               [12] 2934 	clr	a
      0068CF F0               [24] 2935 	movx	@dptr,a
                                   2936 ;	tmk_core/protocol/ch555/usb_ak820.c:435: keyboard_reset = 1;
      0068D0 90 07 A9         [24] 2937 	mov	dptr,#_keyboard_reset
      0068D3 04               [12] 2938 	inc	a
      0068D4 F0               [24] 2939 	movx	@dptr,a
                                   2940 ;	tmk_core/protocol/ch555/usb_ak820.c:436: D0SetupReqCode = 0xff;
      0068D5 90 07 79         [24] 2941 	mov	dptr,#_D0SetupReqCode
      0068D8 74 FF            [12] 2942 	mov	a,#0xff
      0068DA F0               [24] 2943 	movx	@dptr,a
                                   2944 ;	tmk_core/protocol/ch555/usb_ak820.c:437: D0SetupLen = 0;
      0068DB 90 07 7A         [24] 2945 	mov	dptr,#_D0SetupLen
      0068DE E4               [12] 2946 	clr	a
      0068DF F0               [24] 2947 	movx	@dptr,a
      0068E0 A3               [24] 2948 	inc	dptr
      0068E1 F0               [24] 2949 	movx	@dptr,a
                                   2950 ;	tmk_core/protocol/ch555/usb_ak820.c:438: control_phase = CTRL_IDLE;
      0068E2 90 07 D8         [24] 2951 	mov	dptr,#_control_phase
      0068E5 F0               [24] 2952 	movx	@dptr,a
                                   2953 ;	tmk_core/protocol/ch555/usb_ak820.c:439: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      0068E6 90 22 00         [24] 2954 	mov	dptr,#0x2200
      0068E9 74 02            [12] 2955 	mov	a,#0x02
      0068EB F0               [24] 2956 	movx	@dptr,a
                                   2957 ;	tmk_core/protocol/ch555/usb_ak820.c:440: ACK_TRANSFER();
      0068EC 90 22 0F         [24] 2958 	mov	dptr,#0x220f
      0068EF E4               [12] 2959 	clr	a
      0068F0 F0               [24] 2960 	movx	@dptr,a
                                   2961 ;	tmk_core/protocol/ch555/usb_ak820.c:441: ACK_RESET();
      0068F1 90 22 3D         [24] 2962 	mov	dptr,#0x223d
      0068F4 04               [12] 2963 	inc	a
      0068F5 F0               [24] 2964 	movx	@dptr,a
      0068F6 02 69 91         [24] 2965 	ljmp	00130$
      0068F9                       2966 00127$:
                                   2967 ;	tmk_core/protocol/ch555/usb_ak820.c:442: } else if (USB_IF & bUX_IF_D0_TRANS) {
      0068F9 90 22 3D         [24] 2968 	mov	dptr,#0x223d
      0068FC E0               [24] 2969 	movx	a,@dptr
      0068FD 30 E5 60         [24] 2970 	jnb	acc.5,00124$
                                   2971 ;	tmk_core/protocol/ch555/usb_ak820.c:443: status = D0_STATUS;
      006900 90 22 0F         [24] 2972 	mov	dptr,#0x220f
      006903 E0               [24] 2973 	movx	a,@dptr
      006904 FF               [12] 2974 	mov	r7,a
                                   2975 ;	tmk_core/protocol/ch555/usb_ak820.c:444: endpoint = status & MASK_UXS_ENDP;
      006905 74 07            [12] 2976 	mov	a,#0x07
      006907 5F               [12] 2977 	anl	a,r7
      006908 FE               [12] 2978 	mov	r6,a
                                   2979 ;	tmk_core/protocol/ch555/usb_ak820.c:448: if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_OUT && !endpoint) {
      006909 EF               [12] 2980 	mov	a,r7
      00690A 54 18            [12] 2981 	anl	a,#0x18
      00690C 70 08            [24] 2982 	jnz	00115$
      00690E EE               [12] 2983 	mov	a,r6
      00690F 70 05            [24] 2984 	jnz	00115$
                                   2985 ;	tmk_core/protocol/ch555/usb_ak820.c:449: control_out();
      006911 12 67 A0         [24] 2986 	lcall	_control_out
      006914 80 43            [24] 2987 	sjmp	00116$
      006916                       2988 00115$:
                                   2989 ;	tmk_core/protocol/ch555/usb_ak820.c:450: } else if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_IN) {
      006916 8F 05            [24] 2990 	mov	ar5,r7
      006918 74 18            [12] 2991 	mov	a,#0x18
      00691A 5D               [12] 2992 	anl	a,r5
      00691B FC               [12] 2993 	mov	r4,a
      00691C BC 10 2D         [24] 2994 	cjne	r4,#0x10,00112$
                                   2995 ;	tmk_core/protocol/ch555/usb_ak820.c:451: if (!endpoint) control_in();
      00691F EE               [12] 2996 	mov	a,r6
      006920 70 05            [24] 2997 	jnz	00106$
      006922 12 68 5E         [24] 2998 	lcall	_control_in
      006925 80 32            [24] 2999 	sjmp	00116$
      006927                       3000 00106$:
                                   3001 ;	tmk_core/protocol/ch555/usb_ak820.c:452: else if (endpoint <= 3) {
      006927 EE               [12] 3002 	mov	a,r6
      006928 24 FC            [12] 3003 	add	a,#0xff - 0x03
      00692A 40 2D            [24] 3004 	jc	00116$
                                   3005 ;	free result
                                   3006 ;	tmk_core/protocol/ch555/usb_ak820.c:453: EP_RESPONSE(endpoint) = (EP_RESPONSE(endpoint) & ~MASK_UEP_X_RES) | UEP_X_RES_NAK;
      00692C 8E 04            [24] 3007 	mov	ar4,r6
      00692E 7B 00            [12] 3008 	mov	r3,#0x00
      006930 74 22            [12] 3009 	mov	a,#0x22
      006932 2B               [12] 3010 	add	a, r3
      006933 FB               [12] 3011 	mov	r3,a
      006934 8C 82            [24] 3012 	mov	dpl,r4
      006936 8B 83            [24] 3013 	mov	dph,r3
      006938 E0               [24] 3014 	movx	a,@dptr
      006939 FA               [12] 3015 	mov	r2,a
      00693A 74 FC            [12] 3016 	mov	a,#0xfc
      00693C 5A               [12] 3017 	anl	a,r2
      00693D 44 02            [12] 3018 	orl	a,#0x02
      00693F 8C 82            [24] 3019 	mov	dpl,r4
      006941 8B 83            [24] 3020 	mov	dph,r3
      006943 F0               [24] 3021 	movx	@dptr,a
                                   3022 ;	tmk_core/protocol/ch555/usb_ak820.c:454: if (endpoint == RAW_IN_EPNUM) raw_complete();
      006944 BE 03 12         [24] 3023 	cjne	r6,#0x03,00116$
      006947 12 5D 72         [24] 3024 	lcall	_raw_complete
      00694A 80 0D            [24] 3025 	sjmp	00116$
      00694C                       3026 00112$:
                                   3027 ;	tmk_core/protocol/ch555/usb_ak820.c:456: } else if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_FREE && (status & bUXS_SETUP_ACT)) {
      00694C 53 05 18         [24] 3028 	anl	ar5,#0x18
      00694F BD 18 07         [24] 3029 	cjne	r5,#0x18,00116$
      006952 EF               [12] 3030 	mov	a,r7
      006953 30 E5 03         [24] 3031 	jnb	acc.5,00116$
                                   3032 ;	tmk_core/protocol/ch555/usb_ak820.c:457: control_setup();
      006956 12 60 03         [24] 3033 	lcall	_control_setup
      006959                       3034 00116$:
                                   3035 ;	tmk_core/protocol/ch555/usb_ak820.c:459: ACK_TRANSFER();
      006959 90 22 0F         [24] 3036 	mov	dptr,#0x220f
      00695C E4               [12] 3037 	clr	a
      00695D F0               [24] 3038 	movx	@dptr,a
      00695E 80 31            [24] 3039 	sjmp	00130$
      006960                       3040 00124$:
                                   3041 ;	tmk_core/protocol/ch555/usb_ak820.c:460: } else if (USB_IF & bUX_IF_SUSPEND) {
      006960 90 22 3D         [24] 3042 	mov	dptr,#0x223d
      006963 E0               [24] 3043 	movx	a,@dptr
      006964 30 E2 2A         [24] 3044 	jnb	acc.2,00130$
                                   3045 ;	tmk_core/protocol/ch555/usb_ak820.c:462: ak820_os_indicator_mode = AK820_OS_NORMAL;
      006967 90 05 AA         [24] 3046 	mov	dptr,#_ak820_os_indicator_mode
      00696A E4               [12] 3047 	clr	a
      00696B F0               [24] 3048 	movx	@dptr,a
                                   3049 ;	tmk_core/protocol/ch555/usb_ak820.c:464: if (USB_IF & bUX_SUSPEND) USB_SleepStatus |= 2;
      00696C 90 22 3D         [24] 3050 	mov	dptr,#0x223d
      00696F E0               [24] 3051 	movx	a,@dptr
      006970 30 E3 0A         [24] 3052 	jnb	acc.3,00119$
      006973 90 07 81         [24] 3053 	mov	dptr,#_USB_SleepStatus
      006976 E0               [24] 3054 	movx	a,@dptr
      006977 43 E0 02         [24] 3055 	orl	acc,#0x02
      00697A F0               [24] 3056 	movx	@dptr,a
      00697B 80 0E            [24] 3057 	sjmp	00120$
      00697D                       3058 00119$:
                                   3059 ;	tmk_core/protocol/ch555/usb_ak820.c:466: USB_SleepStatus &= ~2;
      00697D 90 07 81         [24] 3060 	mov	dptr,#_USB_SleepStatus
      006980 E0               [24] 3061 	movx	a,@dptr
      006981 53 E0 FD         [24] 3062 	anl	acc,#0xfd
      006984 F0               [24] 3063 	movx	@dptr,a
                                   3064 ;	tmk_core/protocol/ch555/usb_ak820.c:467: keyboard_reset = 1;
      006985 90 07 A9         [24] 3065 	mov	dptr,#_keyboard_reset
      006988 74 01            [12] 3066 	mov	a,#0x01
      00698A F0               [24] 3067 	movx	@dptr,a
      00698B                       3068 00120$:
                                   3069 ;	tmk_core/protocol/ch555/usb_ak820.c:469: ACK_SUSPEND();
      00698B 90 22 3D         [24] 3070 	mov	dptr,#0x223d
      00698E 74 04            [12] 3071 	mov	a,#0x04
      006990 F0               [24] 3072 	movx	@dptr,a
      006991                       3073 00130$:
                                   3074 ;	tmk_core/protocol/ch555/usb_ak820.c:471: } while (USB_IF & (bUX_IF_BUS_RST | bUX_IF_D0_TRANS | bUX_IF_SUSPEND));
      006991 90 22 3D         [24] 3075 	mov	dptr,#0x223d
      006994 E0               [24] 3076 	movx	a,@dptr
      006995 54 25            [12] 3077 	anl	a,#0x25
      006997 60 03            [24] 3078 	jz	00242$
      006999 02 68 A7         [24] 3079 	ljmp	00129$
      00699C                       3080 00242$:
                                   3081 ;	tmk_core/protocol/ch555/usb_ak820.c:472: }
      00699C 22               [24] 3082 	ret
                                   3083 ;------------------------------------------------------------
                                   3084 ;Allocation info for local variables in function 'USB_Device_Init'
                                   3085 ;------------------------------------------------------------
                                   3086 ;	tmk_core/protocol/ch555/usb_ak820.c:475: void USB_Device_Init(void) {
                                   3087 ;	-----------------------------------------
                                   3088 ;	 function USB_Device_Init
                                   3089 ;	-----------------------------------------
      00699D                       3090 _USB_Device_Init:
                                   3091 ;	tmk_core/protocol/ch555/usb_ak820.c:476: IE_USB = 0;
                                   3092 ;	assignBit
      00699D C2 E9            [12] 3093 	clr	_IE_USB
                                   3094 ;	tmk_core/protocol/ch555/usb_ak820.c:477: USB_CTRL = 0;
      00699F 90 22 3C         [24] 3095 	mov	dptr,#0x223c
      0069A2 E4               [12] 3096 	clr	a
      0069A3 F0               [24] 3097 	movx	@dptr,a
                                   3098 ;	tmk_core/protocol/ch555/usb_ak820.c:478: raw_state = RAW_IDLE;
      0069A4 90 07 87         [24] 3099 	mov	dptr,#_raw_state
      0069A7 F0               [24] 3100 	movx	@dptr,a
                                   3101 ;	tmk_core/protocol/ch555/usb_ak820.c:479: endpoints_reset();
      0069A8 12 5D 8F         [24] 3102 	lcall	_endpoints_reset
                                   3103 ;	tmk_core/protocol/ch555/usb_ak820.c:480: D0_ADDR = D0UsbConfig = USB_EnumStatus = USB_SleepStatus = 0;
      0069AB 90 07 81         [24] 3104 	mov	dptr,#_USB_SleepStatus
      0069AE E4               [12] 3105 	clr	a
      0069AF F0               [24] 3106 	movx	@dptr,a
      0069B0 90 07 80         [24] 3107 	mov	dptr,#_USB_EnumStatus
      0069B3 F0               [24] 3108 	movx	@dptr,a
      0069B4 90 07 7F         [24] 3109 	mov	dptr,#_D0UsbConfig
      0069B7 F0               [24] 3110 	movx	@dptr,a
      0069B8 90 22 07         [24] 3111 	mov	dptr,#0x2207
      0069BB F0               [24] 3112 	movx	@dptr,a
                                   3113 ;	tmk_core/protocol/ch555/usb_ak820.c:481: KB_USB_SetReport = KB_USB_UpStatus = MCU_Sleep_Operate = 0;
      0069BC 90 07 82         [24] 3114 	mov	dptr,#_MCU_Sleep_Operate
      0069BF F0               [24] 3115 	movx	@dptr,a
      0069C0 90 07 83         [24] 3116 	mov	dptr,#_KB_USB_UpStatus
      0069C3 F0               [24] 3117 	movx	@dptr,a
      0069C4 90 07 84         [24] 3118 	mov	dptr,#_KB_USB_SetReport
      0069C7 F0               [24] 3119 	movx	@dptr,a
                                   3120 ;	tmk_core/protocol/ch555/usb_ak820.c:482: keyboard_protocol = 1;
      0069C8 90 0D 9C         [24] 3121 	mov	dptr,#_keyboard_protocol
      0069CB 04               [12] 3122 	inc	a
      0069CC F0               [24] 3123 	movx	@dptr,a
                                   3124 ;	tmk_core/protocol/ch555/usb_ak820.c:483: keyboard_idle = 0;
      0069CD 90 06 57         [24] 3125 	mov	dptr,#_keyboard_idle
      0069D0 E4               [12] 3126 	clr	a
      0069D1 F0               [24] 3127 	movx	@dptr,a
                                   3128 ;	tmk_core/protocol/ch555/usb_ak820.c:484: keyboard_reset = 0;
      0069D2 90 07 A9         [24] 3129 	mov	dptr,#_keyboard_reset
      0069D5 F0               [24] 3130 	movx	@dptr,a
                                   3131 ;	tmk_core/protocol/ch555/usb_ak820.c:485: control_phase = CTRL_IDLE;
      0069D6 90 07 D8         [24] 3132 	mov	dptr,#_control_phase
      0069D9 F0               [24] 3133 	movx	@dptr,a
                                   3134 ;	tmk_core/protocol/ch555/usb_ak820.c:486: D0SetupReqCode = 0xff;
      0069DA 90 07 79         [24] 3135 	mov	dptr,#_D0SetupReqCode
      0069DD 14               [12] 3136 	dec	a
      0069DE F0               [24] 3137 	movx	@dptr,a
                                   3138 ;	tmk_core/protocol/ch555/usb_ak820.c:487: D0SetupLen = 0;
      0069DF 90 07 7A         [24] 3139 	mov	dptr,#_D0SetupLen
      0069E2 E4               [12] 3140 	clr	a
      0069E3 F0               [24] 3141 	movx	@dptr,a
      0069E4 A3               [24] 3142 	inc	dptr
      0069E5 F0               [24] 3143 	movx	@dptr,a
                                   3144 ;	tmk_core/protocol/ch555/usb_ak820.c:488: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      0069E6 90 22 00         [24] 3145 	mov	dptr,#0x2200
      0069E9 74 02            [12] 3146 	mov	a,#0x02
      0069EB F0               [24] 3147 	movx	@dptr,a
                                   3148 ;	tmk_core/protocol/ch555/usb_ak820.c:489: HB_ADDR = 0x7f;
      0069EC 90 22 37         [24] 3149 	mov	dptr,#0x2237
      0069EF 74 7F            [12] 3150 	mov	a,#0x7f
      0069F1 F0               [24] 3151 	movx	@dptr,a
                                   3152 ;	tmk_core/protocol/ch555/usb_ak820.c:490: ACK_ALL();
      0069F2 90 22 3D         [24] 3153 	mov	dptr,#0x223d
      0069F5 74 FF            [12] 3154 	mov	a,#0xff
      0069F7 F0               [24] 3155 	movx	@dptr,a
                                   3156 ;	tmk_core/protocol/ch555/usb_ak820.c:491: USB_IE = bUX_IE_SUSPEND | bUX_IE_TRANSFER | bUX_IE_BUS_RST;
      0069F8 90 22 3B         [24] 3157 	mov	dptr,#0x223b
      0069FB 74 07            [12] 3158 	mov	a,#0x07
      0069FD F0               [24] 3159 	movx	@dptr,a
                                   3160 ;	tmk_core/protocol/ch555/usb_ak820.c:492: USB_CTRL = bUX_DP_PU_EN;
      0069FE A3               [24] 3161 	inc	dptr
      0069FF 74 80            [12] 3162 	mov	a,#0x80
      006A01 F0               [24] 3163 	movx	@dptr,a
                                   3164 ;	tmk_core/protocol/ch555/usb_ak820.c:493: IE_USB = 1;
                                   3165 ;	assignBit
      006A02 D2 E9            [12] 3166 	setb	_IE_USB
                                   3167 ;	tmk_core/protocol/ch555/usb_ak820.c:494: }
      006A04 22               [24] 3168 	ret
                                   3169 ;------------------------------------------------------------
                                   3170 ;Allocation info for local variables in function 'USB_WakeUp_PC'
                                   3171 ;------------------------------------------------------------
                                   3172 ;saved         Allocated with name '_USB_WakeUp_PC_saved_10000_420'
                                   3173 ;i             Allocated with name '_USB_WakeUp_PC_i_30000_423'
                                   3174 ;------------------------------------------------------------
                                   3175 ;	tmk_core/protocol/ch555/usb_ak820.c:496: void USB_WakeUp_PC(void) {
                                   3176 ;	-----------------------------------------
                                   3177 ;	 function USB_WakeUp_PC
                                   3178 ;	-----------------------------------------
      006A05                       3179 _USB_WakeUp_PC:
                                   3180 ;	tmk_core/protocol/ch555/usb_ak820.c:498: if (USB_SleepStatus != 3) return;
      006A05 90 07 81         [24] 3181 	mov	dptr,#_USB_SleepStatus
      006A08 E0               [24] 3182 	movx	a,@dptr
      006A09 FF               [12] 3183 	mov	r7,a
      006A0A BF 03 22         [24] 3184 	cjne	r7,#0x03,00110$
                                   3185 ;	tmk_core/protocol/ch555/usb_ak820.c:499: saved = USB_CTRL;
      006A0D 90 22 3C         [24] 3186 	mov	dptr,#0x223c
      006A10 E0               [24] 3187 	movx	a,@dptr
      006A11 FF               [12] 3188 	mov	r7,a
                                   3189 ;	tmk_core/protocol/ch555/usb_ak820.c:500: USB_CTRL ^= bUX_DP_PU_EN | bUX_DM_PU_EN;
      006A12 E0               [24] 3190 	movx	a,@dptr
      006A13 FE               [12] 3191 	mov	r6,a
      006A14 63 06 C0         [24] 3192 	xrl	ar6,#0xc0
      006A17 90 22 3C         [24] 3193 	mov	dptr,#0x223c
      006A1A EE               [12] 3194 	mov	a,r6
      006A1B F0               [24] 3195 	movx	@dptr,a
                                   3196 ;	tmk_core/protocol/ch555/usb_ak820.c:501: wait_ms(10);
      006A1C 7E 0A            [12] 3197 	mov	r6,#0x0a
      006A1E                       3198 00108$:
      006A1E EE               [12] 3199 	mov	a,r6
      006A1F 60 09            [24] 3200 	jz	00105$
      006A21 90 00 01         [24] 3201 	mov	dptr,#0x0001
      006A24 12 5B D6         [24] 3202 	lcall	_mDelaymS
      006A27 1E               [12] 3203 	dec	r6
      006A28 80 F4            [24] 3204 	sjmp	00108$
      006A2A                       3205 00105$:
                                   3206 ;	tmk_core/protocol/ch555/usb_ak820.c:502: USB_CTRL = saved;
      006A2A 90 22 3C         [24] 3207 	mov	dptr,#0x223c
      006A2D EF               [12] 3208 	mov	a,r7
      006A2E F0               [24] 3209 	movx	@dptr,a
      006A2F                       3210 00110$:
                                   3211 ;	tmk_core/protocol/ch555/usb_ak820.c:503: }
      006A2F 22               [24] 3212 	ret
                                   3213 ;------------------------------------------------------------
                                   3214 ;Allocation info for local variables in function 'ak820_usb_send'
                                   3215 ;------------------------------------------------------------
                                   3216 ;sloc0         Allocated with name '_ak820_usb_send_sloc0_1_0'
                                   3217 ;sloc1         Allocated with name '_ak820_usb_send_sloc1_1_0'
                                   3218 ;report        Allocated with name '_ak820_usb_send_PARM_2'
                                   3219 ;length        Allocated with name '_ak820_usb_send_PARM_3'
                                   3220 ;endpoint      Allocated with name '_ak820_usb_send_endpoint_10000_425'
                                   3221 ;saved_ea      Allocated with name '_ak820_usb_send_saved_ea_10000_426'
                                   3222 ;i             Allocated with name '_ak820_usb_send_i_10000_426'
                                   3223 ;timeout       Allocated with name '_ak820_usb_send_timeout_10000_426'
                                   3224 ;offset        Allocated with name '_ak820_usb_send_offset_10000_426'
                                   3225 ;report_id     Allocated with name '_ak820_usb_send_report_id_10000_426'
                                   3226 ;i             Allocated with name '_ak820_usb_send_i_30000_438'
                                   3227 ;------------------------------------------------------------
                                   3228 ;	tmk_core/protocol/ch555/usb_ak820.c:505: bool ak820_usb_send(uint8_t endpoint, const uint8_t __xdata *report, uint8_t length) {
                                   3229 ;	-----------------------------------------
                                   3230 ;	 function ak820_usb_send
                                   3231 ;	-----------------------------------------
      006A30                       3232 _ak820_usb_send:
      006A30 E5 82            [12] 3233 	mov	a,dpl
      006A32 90 07 E8         [24] 3234 	mov	dptr,#_ak820_usb_send_endpoint_10000_425
      006A35 F0               [24] 3235 	movx	@dptr,a
                                   3236 ;	tmk_core/protocol/ch555/usb_ak820.c:509: uint8_t offset = SNAPSHOT_SIZE;
      006A36 90 07 E9         [24] 3237 	mov	dptr,#_ak820_usb_send_offset_10000_426
      006A39 74 2E            [12] 3238 	mov	a,#0x2e
      006A3B F0               [24] 3239 	movx	@dptr,a
                                   3240 ;	tmk_core/protocol/ch555/usb_ak820.c:511: if (endpoint < 1 || endpoint > 3 || length > 64 || !USB_EnumStatus) return false;
      006A3C 90 07 E8         [24] 3241 	mov	dptr,#_ak820_usb_send_endpoint_10000_425
      006A3F E0               [24] 3242 	movx	a,@dptr
      006A40 FF               [12] 3243 	mov	r7,a
      006A41 BF 01 00         [24] 3244 	cjne	r7,#0x01,00306$
      006A44                       3245 00306$:
      006A44 40 14            [24] 3246 	jc	00101$
      006A46 EF               [12] 3247 	mov	a,r7
      006A47 24 FC            [12] 3248 	add	a,#0xff - 0x03
      006A49 40 0F            [24] 3249 	jc	00101$
                                   3250 ;	free result
      006A4B 90 07 E7         [24] 3251 	mov	dptr,#_ak820_usb_send_PARM_3
      006A4E E0               [24] 3252 	movx	a,@dptr
      006A4F FE               [12] 3253 	mov  r6,a
      006A50 24 BF            [12] 3254 	add	a,#0xff - 0x40
      006A52 40 06            [24] 3255 	jc	00101$
                                   3256 ;	free result
      006A54 90 07 80         [24] 3257 	mov	dptr,#_USB_EnumStatus
      006A57 E0               [24] 3258 	movx	a,@dptr
      006A58 70 04            [24] 3259 	jnz	00102$
      006A5A                       3260 00101$:
      006A5A 75 82 00         [24] 3261 	mov	dpl, #0x00
      006A5D 22               [24] 3262 	ret
      006A5E                       3263 00102$:
                                   3264 ;	tmk_core/protocol/ch555/usb_ak820.c:512: if (endpoint == KEYBOARD_IN_EPNUM) {
      006A5E BF 01 10         [24] 3265 	cjne	r7,#0x01,00118$
                                   3266 ;	tmk_core/protocol/ch555/usb_ak820.c:513: if (length != KEYBOARD_EPSIZE) return false;
      006A61 BE 08 02         [24] 3267 	cjne	r6,#0x08,00313$
      006A64 80 04            [24] 3268 	sjmp	00107$
      006A66                       3269 00313$:
      006A66 75 82 00         [24] 3270 	mov	dpl, #0x00
      006A69 22               [24] 3271 	ret
      006A6A                       3272 00107$:
                                   3273 ;	tmk_core/protocol/ch555/usb_ak820.c:514: offset = SNAPSHOT_KEYBOARD;
      006A6A 90 07 E9         [24] 3274 	mov	dptr,#_ak820_usb_send_offset_10000_426
      006A6D E4               [12] 3275 	clr	a
      006A6E F0               [24] 3276 	movx	@dptr,a
      006A6F 80 3C            [24] 3277 	sjmp	00119$
      006A71                       3278 00118$:
                                   3279 ;	tmk_core/protocol/ch555/usb_ak820.c:515: } else if (endpoint == SHARED_IN_EPNUM) {
      006A71 BF 02 30         [24] 3280 	cjne	r7,#0x02,00115$
                                   3281 ;	tmk_core/protocol/ch555/usb_ak820.c:516: report_id = report[0];
      006A74 90 07 E5         [24] 3282 	mov	dptr,#_ak820_usb_send_PARM_2
      006A77 E0               [24] 3283 	movx	a,@dptr
      006A78 FD               [12] 3284 	mov	r5,a
      006A79 A3               [24] 3285 	inc	dptr
      006A7A E0               [24] 3286 	movx	a,@dptr
      006A7B FF               [12] 3287 	mov	r7,a
      006A7C 8D 82            [24] 3288 	mov	dpl,r5
      006A7E 8F 83            [24] 3289 	mov	dph,r7
      006A80 E0               [24] 3290 	movx	a,@dptr
      006A81 FF               [12] 3291 	mov	r7,a
                                   3292 ;	tmk_core/protocol/ch555/usb_ak820.c:517: if (report_id >= sizeof(shared_lengths) || !shared_lengths[report_id] || length != shared_lengths[report_id]) return false;
      006A82 BF 07 00         [24] 3293 	cjne	r7,#0x07,00316$
      006A85                       3294 00316$:
      006A85 50 0E            [24] 3295 	jnc	00108$
      006A87 EF               [12] 3296 	mov	a,r7
      006A88 90 BB B1         [24] 3297 	mov	dptr,#_shared_lengths
      006A8B 93               [24] 3298 	movc	a,@a+dptr
      006A8C FD               [12] 3299 	mov	r5,a
      006A8D 60 06            [24] 3300 	jz	00108$
      006A8F EE               [12] 3301 	mov	a,r6
      006A90 B5 05 02         [24] 3302 	cjne	a,ar5,00319$
      006A93 80 04            [24] 3303 	sjmp	00109$
      006A95                       3304 00319$:
      006A95                       3305 00108$:
      006A95 75 82 00         [24] 3306 	mov	dpl, #0x00
      006A98 22               [24] 3307 	ret
      006A99                       3308 00109$:
                                   3309 ;	tmk_core/protocol/ch555/usb_ak820.c:518: offset = shared_offsets[report_id];
      006A99 EF               [12] 3310 	mov	a,r7
      006A9A 90 BB AA         [24] 3311 	mov	dptr,#_shared_offsets
      006A9D 93               [24] 3312 	movc	a,@a+dptr
      006A9E 90 07 E9         [24] 3313 	mov	dptr,#_ak820_usb_send_offset_10000_426
      006AA1 F0               [24] 3314 	movx	@dptr,a
      006AA2 80 09            [24] 3315 	sjmp	00119$
      006AA4                       3316 00115$:
                                   3317 ;	tmk_core/protocol/ch555/usb_ak820.c:519: } else if (length != RAW_EPSIZE) return false;
      006AA4 BE 20 02         [24] 3318 	cjne	r6,#0x20,00320$
      006AA7 80 04            [24] 3319 	sjmp	00119$
      006AA9                       3320 00320$:
      006AA9 75 82 00         [24] 3321 	mov	dpl, #0x00
      006AAC 22               [24] 3322 	ret
      006AAD                       3323 00119$:
                                   3324 ;	tmk_core/protocol/ch555/usb_ak820.c:520: if (USB_SleepStatus & 2) { USB_WakeUp_PC(); return false; }
      006AAD 90 07 81         [24] 3325 	mov	dptr,#_USB_SleepStatus
      006AB0 E0               [24] 3326 	movx	a,@dptr
      006AB1 30 E1 07         [24] 3327 	jnb	acc.1,00184$
      006AB4 12 6A 05         [24] 3328 	lcall	_USB_WakeUp_PC
      006AB7 75 82 00         [24] 3329 	mov	dpl, #0x00
      006ABA 22               [24] 3330 	ret
                                   3331 ;	tmk_core/protocol/ch555/usb_ak820.c:521: while ((EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_ACK && timeout--) wait_us(40);
      006ABB                       3332 00184$:
      006ABB 7F FA            [12] 3333 	mov	r7,#0xfa
      006ABD                       3334 00127$:
      006ABD 90 07 E8         [24] 3335 	mov	dptr,#_ak820_usb_send_endpoint_10000_425
      006AC0 E0               [24] 3336 	movx	a,@dptr
      006AC1 FC               [12] 3337 	mov	r4,a
      006AC2 7D 00            [12] 3338 	mov	r5,#0x00
      006AC4 8C 02            [24] 3339 	mov	ar2,r4
      006AC6 74 22            [12] 3340 	mov	a,#0x22
      006AC8 2D               [12] 3341 	add	a, r5
      006AC9 FB               [12] 3342 	mov	r3,a
      006ACA 8A 82            [24] 3343 	mov	dpl,r2
      006ACC 8B 83            [24] 3344 	mov	dph,r3
      006ACE E0               [24] 3345 	movx	a,@dptr
      006ACF 54 03            [12] 3346 	anl	a,#0x03
      006AD1 70 14            [24] 3347 	jnz	00129$
      006AD3 8F 03            [24] 3348 	mov	ar3,r7
      006AD5 1F               [12] 3349 	dec	r7
      006AD6 EB               [12] 3350 	mov	a,r3
      006AD7 60 0E            [24] 3351 	jz	00129$
      006AD9 7B 28            [12] 3352 	mov	r3,#0x28
      006ADB                       3353 00141$:
      006ADB EB               [12] 3354 	mov	a,r3
      006ADC 60 DF            [24] 3355 	jz	00127$
      006ADE 90 00 01         [24] 3356 	mov	dptr,#0x0001
      006AE1 12 5B 92         [24] 3357 	lcall	_mDelayuS
      006AE4 1B               [12] 3358 	dec	r3
      006AE5 80 F4            [24] 3359 	sjmp	00141$
      006AE7                       3360 00129$:
                                   3361 ;	tmk_core/protocol/ch555/usb_ak820.c:522: saved_ea = EA;
      006AE7 A2 AF            [12] 3362 	mov	c,_EA
      006AE9 E4               [12] 3363 	clr	a
      006AEA 33               [12] 3364 	rlc	a
      006AEB FF               [12] 3365 	mov	r7,a
                                   3366 ;	tmk_core/protocol/ch555/usb_ak820.c:523: EA = 0;
                                   3367 ;	assignBit
      006AEC C2 AF            [12] 3368 	clr	_EA
                                   3369 ;	tmk_core/protocol/ch555/usb_ak820.c:524: if (!USB_EnumStatus || (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) != UEP_X_RES_NAK ||
      006AEE 90 07 80         [24] 3370 	mov	dptr,#_USB_EnumStatus
      006AF1 E0               [24] 3371 	movx	a,@dptr
      006AF2 60 25            [24] 3372 	jz	00130$
      006AF4 90 07 E8         [24] 3373 	mov	dptr,#_ak820_usb_send_endpoint_10000_425
      006AF7 E0               [24] 3374 	movx	a,@dptr
      006AF8 FB               [12] 3375 	mov	r3,a
      006AF9 F9               [12] 3376 	mov	r1,a
      006AFA 7A 00            [12] 3377 	mov	r2,#0x00
      006AFC 74 22            [12] 3378 	mov	a,#0x22
      006AFE 2A               [12] 3379 	add	a, r2
      006AFF FA               [12] 3380 	mov	r2,a
      006B00 89 82            [24] 3381 	mov	dpl,r1
      006B02 8A 83            [24] 3382 	mov	dph,r2
      006B04 E0               [24] 3383 	movx	a,@dptr
      006B05 FA               [12] 3384 	mov	r2,a
      006B06 53 02 03         [24] 3385 	anl	ar2,#0x03
      006B09 BA 02 0D         [24] 3386 	cjne	r2,#0x02,00130$
                                   3387 ;	tmk_core/protocol/ch555/usb_ak820.c:525: (endpoint == RAW_IN_EPNUM && raw_state != RAW_WORK)) { EA = saved_ea; return false; }
      006B0C BB 03 13         [24] 3388 	cjne	r3,#0x03,00192$
      006B0F 90 07 87         [24] 3389 	mov	dptr,#_raw_state
      006B12 E0               [24] 3390 	movx	a,@dptr
      006B13 FB               [12] 3391 	mov	r3,a
      006B14 BB 03 02         [24] 3392 	cjne	r3,#0x03,00331$
      006B17 80 09            [24] 3393 	sjmp	00192$
      006B19                       3394 00331$:
      006B19                       3395 00130$:
                                   3396 ;	assignBit
      006B19 EF               [12] 3397 	mov	a,r7
      006B1A 24 FF            [12] 3398 	add	a,#0xff
      006B1C 92 AF            [24] 3399 	mov	_EA,c
      006B1E 75 82 00         [24] 3400 	mov	dpl, #0x00
      006B21 22               [24] 3401 	ret
                                   3402 ;	tmk_core/protocol/ch555/usb_ak820.c:526: for (i = 0; i < length; ++i) {
      006B22                       3403 00192$:
      006B22 7B 00            [12] 3404 	mov	r3,#0x00
      006B24                       3405 00144$:
      006B24 C3               [12] 3406 	clr	c
      006B25 EB               [12] 3407 	mov	a,r3
      006B26 9E               [12] 3408 	subb	a,r6
      006B27 50 67            [24] 3409 	jnc	00137$
                                   3410 ;	tmk_core/protocol/ch555/usb_ak820.c:527: pUSB_BUF_DEV0[((uint16_t)endpoint << 6) + i] = report[i];
      006B29 C0 07            [24] 3411 	push	ar7
      006B2B 90 07 E8         [24] 3412 	mov	dptr,#_ak820_usb_send_endpoint_10000_425
      006B2E E0               [24] 3413 	movx	a,@dptr
      006B2F F9               [12] 3414 	mov	r1,a
      006B30 E4               [12] 3415 	clr	a
      006B31 C3               [12] 3416 	clr	c
      006B32 C9               [12] 3417 	xch	a,r1
      006B33 13               [12] 3418 	rrc	a
      006B34 C9               [12] 3419 	xch	a,r1
      006B35 13               [12] 3420 	rrc	a
      006B36 A2 E0            [12] 3421 	mov	c,acc.0
      006B38 C9               [12] 3422 	xch	a,r1
      006B39 13               [12] 3423 	rrc	a
      006B3A C9               [12] 3424 	xch	a,r1
      006B3B 13               [12] 3425 	rrc	a
      006B3C C9               [12] 3426 	xch	a,r1
      006B3D FA               [12] 3427 	mov	r2,a
      006B3E 8B 00            [24] 3428 	mov	ar0,r3
      006B40 7F 00            [12] 3429 	mov	r7,#0x00
      006B42 E8               [12] 3430 	mov	a,r0
      006B43 29               [12] 3431 	add	a, r1
      006B44 F9               [12] 3432 	mov	r1,a
      006B45 EF               [12] 3433 	mov	a,r7
      006B46 3A               [12] 3434 	addc	a, r2
      006B47 24 10            [12] 3435 	add	a,#0x10
      006B49 FA               [12] 3436 	mov	r2,a
      006B4A 90 07 E5         [24] 3437 	mov	dptr,#_ak820_usb_send_PARM_2
      006B4D E0               [24] 3438 	movx	a,@dptr
      006B4E F8               [12] 3439 	mov	r0,a
      006B4F A3               [24] 3440 	inc	dptr
      006B50 E0               [24] 3441 	movx	a,@dptr
      006B51 FF               [12] 3442 	mov	r7,a
      006B52 EB               [12] 3443 	mov	a,r3
      006B53 28               [12] 3444 	add	a, r0
      006B54 F5 1B            [12] 3445 	mov	_ak820_usb_send_sloc0_1_0,a
      006B56 E4               [12] 3446 	clr	a
      006B57 3F               [12] 3447 	addc	a, r7
      006B58 F5 1C            [12] 3448 	mov	(_ak820_usb_send_sloc0_1_0 + 1),a
      006B5A 85 1B 82         [24] 3449 	mov	dpl,_ak820_usb_send_sloc0_1_0
      006B5D 85 1C 83         [24] 3450 	mov	dph,(_ak820_usb_send_sloc0_1_0 + 1)
      006B60 E0               [24] 3451 	movx	a,@dptr
      006B61 89 82            [24] 3452 	mov	dpl,r1
      006B63 8A 83            [24] 3453 	mov	dph,r2
      006B65 F0               [24] 3454 	movx	@dptr,a
                                   3455 ;	tmk_core/protocol/ch555/usb_ak820.c:528: if (offset != SNAPSHOT_SIZE) input_snapshot[offset + i] = report[i];
      006B66 90 07 E9         [24] 3456 	mov	dptr,#_ak820_usb_send_offset_10000_426
      006B69 E0               [24] 3457 	movx	a,@dptr
      006B6A F5 1D            [12] 3458 	mov	_ak820_usb_send_sloc1_1_0,a
      006B6C 74 2E            [12] 3459 	mov	a,#0x2e
      006B6E B5 1D 04         [24] 3460 	cjne	a,_ak820_usb_send_sloc1_1_0,00333$
      006B71 D0 07            [24] 3461 	pop	ar7
      006B73 80 18            [24] 3462 	sjmp	00145$
      006B75                       3463 00333$:
      006B75 D0 07            [24] 3464 	pop	ar7
      006B77 EB               [12] 3465 	mov	a,r3
      006B78 25 1D            [12] 3466 	add	a, _ak820_usb_send_sloc1_1_0
      006B7A 24 AA            [12] 3467 	add	a, #_input_snapshot
      006B7C F9               [12] 3468 	mov	r1,a
      006B7D E4               [12] 3469 	clr	a
      006B7E 34 07            [12] 3470 	addc	a,#(_input_snapshot >> 8)
      006B80 FA               [12] 3471 	mov	r2,a
      006B81 85 1B 82         [24] 3472 	mov	dpl,_ak820_usb_send_sloc0_1_0
      006B84 85 1C 83         [24] 3473 	mov	dph,(_ak820_usb_send_sloc0_1_0 + 1)
      006B87 E0               [24] 3474 	movx	a,@dptr
      006B88 89 82            [24] 3475 	mov	dpl,r1
      006B8A 8A 83            [24] 3476 	mov	dph,r2
      006B8C F0               [24] 3477 	movx	@dptr,a
      006B8D                       3478 00145$:
                                   3479 ;	tmk_core/protocol/ch555/usb_ak820.c:526: for (i = 0; i < length; ++i) {
      006B8D 0B               [12] 3480 	inc	r3
      006B8E 80 94            [24] 3481 	sjmp	00144$
      006B90                       3482 00137$:
                                   3483 ;	tmk_core/protocol/ch555/usb_ak820.c:530: EP_LENGTH(endpoint) = length;
      006B90 90 07 E8         [24] 3484 	mov	dptr,#_ak820_usb_send_endpoint_10000_425
      006B93 E0               [24] 3485 	movx	a,@dptr
      006B94 FB               [12] 3486 	mov	r3,a
      006B95 F9               [12] 3487 	mov	r1,a
      006B96 7A 00            [12] 3488 	mov	r2,#0x00
      006B98 74 08            [12] 3489 	mov	a,#0x08
      006B9A 29               [12] 3490 	add	a, r1
      006B9B F9               [12] 3491 	mov	r1,a
      006B9C 74 22            [12] 3492 	mov	a,#0x22
      006B9E 3A               [12] 3493 	addc	a, r2
      006B9F FA               [12] 3494 	mov	r2,a
      006BA0 89 82            [24] 3495 	mov	dpl,r1
      006BA2 8A 83            [24] 3496 	mov	dph,r2
      006BA4 EE               [12] 3497 	mov	a,r6
      006BA5 F0               [24] 3498 	movx	@dptr,a
                                   3499 ;	tmk_core/protocol/ch555/usb_ak820.c:531: if (endpoint == RAW_IN_EPNUM) raw_state = RAW_TX_ACTIVE;
      006BA6 BB 03 06         [24] 3500 	cjne	r3,#0x03,00139$
      006BA9 90 07 87         [24] 3501 	mov	dptr,#_raw_state
      006BAC 74 04            [12] 3502 	mov	a,#0x04
      006BAE F0               [24] 3503 	movx	@dptr,a
      006BAF                       3504 00139$:
                                   3505 ;	tmk_core/protocol/ch555/usb_ak820.c:532: EP_RESPONSE(endpoint) = (EP_RESPONSE(endpoint) & ~MASK_UEP_X_RES) | UEP_X_RES_ACK;
      006BAF 74 22            [12] 3506 	mov	a,#0x22
      006BB1 2D               [12] 3507 	add	a, r5
      006BB2 FD               [12] 3508 	mov	r5,a
      006BB3 8C 82            [24] 3509 	mov	dpl,r4
      006BB5 8D 83            [24] 3510 	mov	dph,r5
      006BB7 E0               [24] 3511 	movx	a,@dptr
      006BB8 FE               [12] 3512 	mov	r6,a
      006BB9 53 06 FC         [24] 3513 	anl	ar6,#0xfc
      006BBC 8C 82            [24] 3514 	mov	dpl,r4
      006BBE 8D 83            [24] 3515 	mov	dph,r5
      006BC0 EE               [12] 3516 	mov	a,r6
      006BC1 F0               [24] 3517 	movx	@dptr,a
                                   3518 ;	tmk_core/protocol/ch555/usb_ak820.c:533: EA = saved_ea;
                                   3519 ;	assignBit
      006BC2 EF               [12] 3520 	mov	a,r7
      006BC3 24 FF            [12] 3521 	add	a,#0xff
      006BC5 92 AF            [24] 3522 	mov	_EA,c
                                   3523 ;	tmk_core/protocol/ch555/usb_ak820.c:534: return true;
      006BC7 75 82 01         [24] 3524 	mov	dpl, #0x01
                                   3525 ;	tmk_core/protocol/ch555/usb_ak820.c:535: }
      006BCA 22               [24] 3526 	ret
                                   3527 ;------------------------------------------------------------
                                   3528 ;Allocation info for local variables in function 'ak820_usb_try_send'
                                   3529 ;------------------------------------------------------------
                                   3530 ;report        Allocated with name '_ak820_usb_try_send_PARM_2'
                                   3531 ;length        Allocated with name '_ak820_usb_try_send_PARM_3'
                                   3532 ;endpoint      Allocated with name '_ak820_usb_try_send_endpoint_10000_446'
                                   3533 ;saved_ea      Allocated with name '_ak820_usb_try_send_saved_ea_10000_447'
                                   3534 ;sent          Allocated with name '_ak820_usb_try_send_sent_10000_447'
                                   3535 ;------------------------------------------------------------
                                   3536 ;	tmk_core/protocol/ch555/usb_ak820.c:537: bool ak820_usb_try_send(uint8_t endpoint, const uint8_t __xdata *report, uint8_t length) {
                                   3537 ;	-----------------------------------------
                                   3538 ;	 function ak820_usb_try_send
                                   3539 ;	-----------------------------------------
      006BCB                       3540 _ak820_usb_try_send:
      006BCB E5 82            [12] 3541 	mov	a,dpl
      006BCD 90 07 ED         [24] 3542 	mov	dptr,#_ak820_usb_try_send_endpoint_10000_446
      006BD0 F0               [24] 3543 	movx	@dptr,a
                                   3544 ;	tmk_core/protocol/ch555/usb_ak820.c:538: uint8_t saved_ea = EA;
                                   3545 ;	assignBit
      006BD1 A2 AF            [12] 3546 	mov	c,_EA
      006BD3 92 1B            [24] 3547 	mov	_ak820_usb_try_send_sloc0_1_0,c
                                   3548 ;	tmk_core/protocol/ch555/usb_ak820.c:539: bool sent = false;
      006BD5 90 07 EE         [24] 3549 	mov	dptr,#_ak820_usb_try_send_sent_10000_447
      006BD8 E4               [12] 3550 	clr	a
      006BD9 F0               [24] 3551 	movx	@dptr,a
                                   3552 ;	tmk_core/protocol/ch555/usb_ak820.c:540: EA = 0;
                                   3553 ;	assignBit
      006BDA C2 AF            [12] 3554 	clr	_EA
                                   3555 ;	tmk_core/protocol/ch555/usb_ak820.c:544: if (endpoint >= 1 && endpoint <= 2 && USB_EnumStatus &&
      006BDC 90 07 ED         [24] 3556 	mov	dptr,#_ak820_usb_try_send_endpoint_10000_446
      006BDF E0               [24] 3557 	movx	a,@dptr
      006BE0 FF               [12] 3558 	mov	r7,a
      006BE1 BF 01 00         [24] 3559 	cjne	r7,#0x01,00152$
      006BE4                       3560 00152$:
      006BE4 40 4E            [24] 3561 	jc	00102$
      006BE6 EF               [12] 3562 	mov	a,r7
      006BE7 24 FD            [12] 3563 	add	a,#0xff - 0x02
      006BE9 40 49            [24] 3564 	jc	00102$
                                   3565 ;	free result
      006BEB 90 07 80         [24] 3566 	mov	dptr,#_USB_EnumStatus
      006BEE E0               [24] 3567 	movx	a,@dptr
      006BEF 60 43            [24] 3568 	jz	00102$
                                   3569 ;	tmk_core/protocol/ch555/usb_ak820.c:545: !(USB_SleepStatus & 2) && !keyboard_reset &&
      006BF1 90 07 81         [24] 3570 	mov	dptr,#_USB_SleepStatus
      006BF4 E0               [24] 3571 	movx	a,@dptr
      006BF5 20 E1 3C         [24] 3572 	jb	acc.1,00102$
      006BF8 90 07 A9         [24] 3573 	mov	dptr,#_keyboard_reset
      006BFB E0               [24] 3574 	movx	a,@dptr
                                   3575 ;	tmk_core/protocol/ch555/usb_ak820.c:546: (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_NAK) {
      006BFC 70 36            [24] 3576 	jnz	00102$
      006BFE 8F 06            [24] 3577 	mov	ar6,r7
      006C00 24 22            [12] 3578 	add	a,#0x22
      006C02 FD               [12] 3579 	mov	r5,a
      006C03 8E 82            [24] 3580 	mov	dpl,r6
      006C05 8D 83            [24] 3581 	mov	dph,r5
      006C07 E0               [24] 3582 	movx	a,@dptr
      006C08 FE               [12] 3583 	mov	r6,a
      006C09 53 06 03         [24] 3584 	anl	ar6,#0x03
      006C0C BE 02 25         [24] 3585 	cjne	r6,#0x02,00102$
                                   3586 ;	tmk_core/protocol/ch555/usb_ak820.c:547: sent = ak820_usb_send(endpoint, report, length);
      006C0F 90 07 EA         [24] 3587 	mov	dptr,#_ak820_usb_try_send_PARM_2
      006C12 E0               [24] 3588 	movx	a,@dptr
      006C13 FD               [12] 3589 	mov	r5,a
      006C14 A3               [24] 3590 	inc	dptr
      006C15 E0               [24] 3591 	movx	a,@dptr
      006C16 FE               [12] 3592 	mov	r6,a
      006C17 90 07 EC         [24] 3593 	mov	dptr,#_ak820_usb_try_send_PARM_3
      006C1A E0               [24] 3594 	movx	a,@dptr
      006C1B FC               [12] 3595 	mov	r4,a
      006C1C 90 07 E5         [24] 3596 	mov	dptr,#_ak820_usb_send_PARM_2
      006C1F ED               [12] 3597 	mov	a,r5
      006C20 F0               [24] 3598 	movx	@dptr,a
      006C21 EE               [12] 3599 	mov	a,r6
      006C22 A3               [24] 3600 	inc	dptr
      006C23 F0               [24] 3601 	movx	@dptr,a
      006C24 90 07 E7         [24] 3602 	mov	dptr,#_ak820_usb_send_PARM_3
      006C27 EC               [12] 3603 	mov	a,r4
      006C28 F0               [24] 3604 	movx	@dptr,a
      006C29 8F 82            [24] 3605 	mov	dpl, r7
      006C2B 12 6A 30         [24] 3606 	lcall	_ak820_usb_send
      006C2E E5 82            [12] 3607 	mov	a, dpl
      006C30 90 07 EE         [24] 3608 	mov	dptr,#_ak820_usb_try_send_sent_10000_447
      006C33 F0               [24] 3609 	movx	@dptr,a
      006C34                       3610 00102$:
                                   3611 ;	tmk_core/protocol/ch555/usb_ak820.c:549: EA = saved_ea;
                                   3612 ;	assignBit
      006C34 A2 1B            [12] 3613 	mov	c,_ak820_usb_try_send_sloc0_1_0
      006C36 92 AF            [24] 3614 	mov	_EA,c
                                   3615 ;	tmk_core/protocol/ch555/usb_ak820.c:550: return sent;
      006C38 90 07 EE         [24] 3616 	mov	dptr,#_ak820_usb_try_send_sent_10000_447
      006C3B E0               [24] 3617 	movx	a,@dptr
                                   3618 ;	tmk_core/protocol/ch555/usb_ak820.c:551: }
      006C3C F5 82            [12] 3619 	mov	dpl,a
      006C3E 22               [24] 3620 	ret
                                   3621 ;------------------------------------------------------------
                                   3622 ;Allocation info for local variables in function 'raw_request_is_nonpersistent'
                                   3623 ;------------------------------------------------------------
                                   3624 ;	tmk_core/protocol/ch555/usb_ak820.c:556: static bool raw_request_is_nonpersistent(void) {
                                   3625 ;	-----------------------------------------
                                   3626 ;	 function raw_request_is_nonpersistent
                                   3627 ;	-----------------------------------------
      006C3F                       3628 _raw_request_is_nonpersistent:
                                   3629 ;	tmk_core/protocol/ch555/usb_ak820.c:557: switch (raw_buffer[0]) {
      006C3F 90 07 88         [24] 3630 	mov	dptr,#_raw_buffer
      006C42 E0               [24] 3631 	movx	a,@dptr
      006C43 FF               [12] 3632 	mov	r7,a
      006C44 BF 01 02         [24] 3633 	cjne	r7,#0x01,00302$
      006C47 80 35            [24] 3634 	sjmp	00108$
      006C49                       3635 00302$:
      006C49 BF 02 02         [24] 3636 	cjne	r7,#0x02,00303$
      006C4C 80 34            [24] 3637 	sjmp	00109$
      006C4E                       3638 00303$:
      006C4E BF 04 02         [24] 3639 	cjne	r7,#0x04,00304$
      006C51 80 2B            [24] 3640 	sjmp	00108$
      006C53                       3641 00304$:
      006C53 BF 08 02         [24] 3642 	cjne	r7,#0x08,00305$
      006C56 80 47            [24] 3643 	sjmp	00116$
      006C58                       3644 00305$:
      006C58 BF 0B 02         [24] 3645 	cjne	r7,#0x0b,00306$
      006C5B 80 21            [24] 3646 	sjmp	00108$
      006C5D                       3647 00306$:
      006C5D BF 0C 02         [24] 3648 	cjne	r7,#0x0c,00307$
      006C60 80 1C            [24] 3649 	sjmp	00108$
      006C62                       3650 00307$:
      006C62 BF 0D 02         [24] 3651 	cjne	r7,#0x0d,00308$
      006C65 80 17            [24] 3652 	sjmp	00108$
      006C67                       3653 00308$:
      006C67 BF 0E 02         [24] 3654 	cjne	r7,#0x0e,00309$
      006C6A 80 12            [24] 3655 	sjmp	00108$
      006C6C                       3656 00309$:
      006C6C BF 11 02         [24] 3657 	cjne	r7,#0x11,00310$
      006C6F 80 0D            [24] 3658 	sjmp	00108$
      006C71                       3659 00310$:
      006C71 BF 12 02         [24] 3660 	cjne	r7,#0x12,00311$
      006C74 80 08            [24] 3661 	sjmp	00108$
      006C76                       3662 00311$:
      006C76 BF FE 02         [24] 3663 	cjne	r7,#0xfe,00312$
      006C79 80 46            [24] 3664 	sjmp	00124$
      006C7B                       3665 00312$:
      006C7B 02 6D 16         [24] 3666 	ljmp	00144$
                                   3667 ;	tmk_core/protocol/ch555/usb_ak820.c:565: case id_bootloader_jump:
      006C7E                       3668 00108$:
                                   3669 ;	tmk_core/protocol/ch555/usb_ak820.c:566: return true;
      006C7E 75 82 01         [24] 3670 	mov	dpl, #0x01
      006C81 22               [24] 3671 	ret
                                   3672 ;	tmk_core/protocol/ch555/usb_ak820.c:567: case id_get_keyboard_value:
      006C82                       3673 00109$:
                                   3674 ;	tmk_core/protocol/ch555/usb_ak820.c:568: switch (raw_buffer[1]) {
      006C82 12 70 2A         [24] 3675 	lcall	_ak820_outline_0159
      006C85 BF 01 02         [24] 3676 	cjne	r7,#0x01,00313$
      006C88 80 0D            [24] 3677 	sjmp	00113$
      006C8A                       3678 00313$:
      006C8A BF 02 02         [24] 3679 	cjne	r7,#0x02,00314$
      006C8D 80 08            [24] 3680 	sjmp	00113$
      006C8F                       3681 00314$:
      006C8F BF 03 02         [24] 3682 	cjne	r7,#0x03,00315$
      006C92 80 03            [24] 3683 	sjmp	00113$
      006C94                       3684 00315$:
      006C94 BF 04 04         [24] 3685 	cjne	r7,#0x04,00114$
                                   3686 ;	tmk_core/protocol/ch555/usb_ak820.c:572: case id_firmware_version:
      006C97                       3687 00113$:
                                   3688 ;	tmk_core/protocol/ch555/usb_ak820.c:573: return true;
      006C97 75 82 01         [24] 3689 	mov	dpl, #0x01
      006C9A 22               [24] 3690 	ret
                                   3691 ;	tmk_core/protocol/ch555/usb_ak820.c:574: default: return false;
      006C9B                       3692 00114$:
      006C9B 75 82 00         [24] 3693 	mov	dpl, #0x00
      006C9E 22               [24] 3694 	ret
                                   3695 ;	tmk_core/protocol/ch555/usb_ak820.c:576: case id_lighting_get_value:
      006C9F                       3696 00116$:
                                   3697 ;	tmk_core/protocol/ch555/usb_ak820.c:577: switch (raw_buffer[1]) {
      006C9F 12 70 2A         [24] 3698 	lcall	_ak820_outline_0159
      006CA2 BF 40 02         [24] 3699 	cjne	r7,#0x40,00318$
      006CA5 80 12            [24] 3700 	sjmp	00121$
      006CA7                       3701 00318$:
      006CA7 BF 41 02         [24] 3702 	cjne	r7,#0x41,00319$
      006CAA 80 0D            [24] 3703 	sjmp	00121$
      006CAC                       3704 00319$:
      006CAC BF 42 02         [24] 3705 	cjne	r7,#0x42,00320$
      006CAF 80 08            [24] 3706 	sjmp	00121$
      006CB1                       3707 00320$:
      006CB1 BF 43 02         [24] 3708 	cjne	r7,#0x43,00321$
      006CB4 80 03            [24] 3709 	sjmp	00121$
      006CB6                       3710 00321$:
      006CB6 BF 44 04         [24] 3711 	cjne	r7,#0x44,00122$
                                   3712 ;	tmk_core/protocol/ch555/usb_ak820.c:582: case vialrgb_get_led_info:
      006CB9                       3713 00121$:
                                   3714 ;	tmk_core/protocol/ch555/usb_ak820.c:583: return true;
      006CB9 75 82 01         [24] 3715 	mov	dpl, #0x01
                                   3716 ;	tmk_core/protocol/ch555/usb_ak820.c:584: default: return false;
      006CBC 22               [24] 3717 	ret
      006CBD                       3718 00122$:
      006CBD 75 82 00         [24] 3719 	mov	dpl, #0x00
                                   3720 ;	tmk_core/protocol/ch555/usb_ak820.c:586: case id_vial_prefix:
      006CC0 22               [24] 3721 	ret
      006CC1                       3722 00124$:
                                   3723 ;	tmk_core/protocol/ch555/usb_ak820.c:587: switch (raw_buffer[1]) {
      006CC1 12 70 2A         [24] 3724 	lcall	_ak820_outline_0159
      006CC4 24 F2            [12] 3725 	add	a,#0xff - 0x0d
      006CC6 40 4A            [24] 3726 	jc	00142$
                                   3727 ;	free result
      006CC8 EF               [12] 3728 	mov	a,r7
      006CC9 24 0A            [12] 3729 	add	a,#(00325$-3-.)
      006CCB 83               [24] 3730 	movc	a,@a+pc
      006CCC F5 82            [12] 3731 	mov	dpl,a
      006CCE EF               [12] 3732 	mov	a,r7
      006CCF 24 12            [12] 3733 	add	a,#(00326$-3-.)
      006CD1 83               [24] 3734 	movc	a,@a+pc
      006CD2 F5 83            [12] 3735 	mov	dph,a
      006CD4 E4               [12] 3736 	clr	a
      006CD5 73               [24] 3737 	jmp	@a+dptr
      006CD6                       3738 00325$:
      006CD6 F2                    3739 	.db	00134$
      006CD7 F2                    3740 	.db	00134$
      006CD8 F2                    3741 	.db	00134$
      006CD9 F2                    3742 	.db	00134$
      006CDA 12                    3743 	.db	00142$
      006CDB F2                    3744 	.db	00134$
      006CDC F2                    3745 	.db	00134$
      006CDD F2                    3746 	.db	00134$
      006CDE F2                    3747 	.db	00134$
      006CDF F2                    3748 	.db	00134$
      006CE0 F2                    3749 	.db	00134$
      006CE1 12                    3750 	.db	00142$
      006CE2 12                    3751 	.db	00142$
      006CE3 F6                    3752 	.db	00135$
      006CE4                       3753 00326$:
      006CE4 6C                    3754 	.db	00134$>>8
      006CE5 6C                    3755 	.db	00134$>>8
      006CE6 6C                    3756 	.db	00134$>>8
      006CE7 6C                    3757 	.db	00134$>>8
      006CE8 6D                    3758 	.db	00142$>>8
      006CE9 6C                    3759 	.db	00134$>>8
      006CEA 6C                    3760 	.db	00134$>>8
      006CEB 6C                    3761 	.db	00134$>>8
      006CEC 6C                    3762 	.db	00134$>>8
      006CED 6C                    3763 	.db	00134$>>8
      006CEE 6C                    3764 	.db	00134$>>8
      006CEF 6D                    3765 	.db	00142$>>8
      006CF0 6D                    3766 	.db	00142$>>8
      006CF1 6C                    3767 	.db	00135$>>8
                                   3768 ;	tmk_core/protocol/ch555/usb_ak820.c:597: case vial_qmk_settings_get:
      006CF2                       3769 00134$:
                                   3770 ;	tmk_core/protocol/ch555/usb_ak820.c:598: return true;
      006CF2 75 82 01         [24] 3771 	mov	dpl, #0x01
                                   3772 ;	tmk_core/protocol/ch555/usb_ak820.c:599: case vial_dynamic_entry_op:
      006CF5 22               [24] 3773 	ret
      006CF6                       3774 00135$:
                                   3775 ;	tmk_core/protocol/ch555/usb_ak820.c:600: switch (raw_buffer[2]) {
      006CF6 90 07 8A         [24] 3776 	mov	dptr,#(_raw_buffer + 0x0002)
      006CF9 E0               [24] 3777 	movx	a,@dptr
      006CFA FF               [12] 3778 	mov	r7,a
      006CFB 60 0D            [24] 3779 	jz	00139$
      006CFD BF 01 02         [24] 3780 	cjne	r7,#0x01,00328$
      006D00 80 08            [24] 3781 	sjmp	00139$
      006D02                       3782 00328$:
      006D02 BF 03 02         [24] 3783 	cjne	r7,#0x03,00329$
      006D05 80 03            [24] 3784 	sjmp	00139$
      006D07                       3785 00329$:
      006D07 BF 05 04         [24] 3786 	cjne	r7,#0x05,00140$
                                   3787 ;	tmk_core/protocol/ch555/usb_ak820.c:604: case dynamic_vial_key_override_get:
      006D0A                       3788 00139$:
                                   3789 ;	tmk_core/protocol/ch555/usb_ak820.c:605: return true;
      006D0A 75 82 01         [24] 3790 	mov	dpl, #0x01
                                   3791 ;	tmk_core/protocol/ch555/usb_ak820.c:606: default: return false;
      006D0D 22               [24] 3792 	ret
      006D0E                       3793 00140$:
      006D0E 75 82 00         [24] 3794 	mov	dpl, #0x00
                                   3795 ;	tmk_core/protocol/ch555/usb_ak820.c:608: default: return false;
      006D11 22               [24] 3796 	ret
      006D12                       3797 00142$:
      006D12 75 82 00         [24] 3798 	mov	dpl, #0x00
                                   3799 ;	tmk_core/protocol/ch555/usb_ak820.c:610: default: return false;
      006D15 22               [24] 3800 	ret
      006D16                       3801 00144$:
      006D16 75 82 00         [24] 3802 	mov	dpl, #0x00
                                   3803 ;	tmk_core/protocol/ch555/usb_ak820.c:611: }
                                   3804 ;	tmk_core/protocol/ch555/usb_ak820.c:612: }
      006D19 22               [24] 3805 	ret
                                   3806 ;------------------------------------------------------------
                                   3807 ;Allocation info for local variables in function 'ak820_usb_raw_send'
                                   3808 ;------------------------------------------------------------
                                   3809 ;length        Allocated with name '_ak820_usb_raw_send_PARM_2'
                                   3810 ;report        Allocated with name '_ak820_usb_raw_send_report_10000_462'
                                   3811 ;------------------------------------------------------------
                                   3812 ;	tmk_core/protocol/ch555/usb_ak820.c:614: void ak820_usb_raw_send(const uint8_t *report, uint8_t length) {
                                   3813 ;	-----------------------------------------
                                   3814 ;	 function ak820_usb_raw_send
                                   3815 ;	-----------------------------------------
      006D1A                       3816 _ak820_usb_raw_send:
      006D1A 12 45 86         [24] 3817 	lcall	_ak820_outline_0037
      006D1D 90 07 F0         [24] 3818 	mov	dptr,#_ak820_usb_raw_send_report_10000_462
      006D20 12 3A 26         [24] 3819 	lcall	_ak820_outline_0016
                                   3820 ;	tmk_core/protocol/ch555/usb_ak820.c:615: if (length != RAW_EPSIZE) return;
      006D23 90 07 EF         [24] 3821 	mov	dptr,#_ak820_usb_raw_send_PARM_2
      006D26 E0               [24] 3822 	movx	a,@dptr
      006D27 FF               [12] 3823 	mov	r7,a
      006D28 BF 20 2B         [24] 3824 	cjne	r7,#0x20,00106$
                                   3825 ;	tmk_core/protocol/ch555/usb_ak820.c:616: ak820_nvm_flush();
      006D2B C0 07            [24] 3826 	push	ar7
      006D2D 12 40 9D         [24] 3827 	lcall	_ak820_nvm_flush
      006D30 D0 07            [24] 3828 	pop	ar7
                                   3829 ;	tmk_core/protocol/ch555/usb_ak820.c:617: if (raw_reply_without_nvm || ak820_nvm_ok()) ak820_usb_send(RAW_IN_EPNUM, (const uint8_t __xdata *)report, length);
      006D32 90 07 A8         [24] 3830 	mov	dptr,#_raw_reply_without_nvm
      006D35 E0               [24] 3831 	movx	a,@dptr
      006D36 70 07            [24] 3832 	jnz	00103$
      006D38 12 40 8E         [24] 3833 	lcall	_ak820_nvm_ok
      006D3B E5 82            [12] 3834 	mov	a, dpl
      006D3D 60 17            [24] 3835 	jz	00106$
      006D3F                       3836 00103$:
      006D3F 90 07 F0         [24] 3837 	mov	dptr,#_ak820_usb_raw_send_report_10000_462
      006D42 12 45 BD         [24] 3838 	lcall	_ak820_outline_0093
      006D45 90 07 E5         [24] 3839 	mov	dptr,#_ak820_usb_send_PARM_2
      006D48 12 46 00         [24] 3840 	lcall	_ak820_outline_0157
      006D4B 90 07 E7         [24] 3841 	mov	dptr,#_ak820_usb_send_PARM_3
      006D4E EF               [12] 3842 	mov	a,r7
      006D4F F0               [24] 3843 	movx	@dptr,a
      006D50 75 82 03         [24] 3844 	mov	dpl, #0x03
                                   3845 ;	tmk_core/protocol/ch555/usb_ak820.c:618: }
      006D53 02 6A 30         [24] 3846 	ljmp	_ak820_usb_send
      006D56                       3847 00106$:
      006D56 22               [24] 3848 	ret
                                   3849 ;------------------------------------------------------------
                                   3850 ;Allocation info for local variables in function 'ak820_usb_raw_task'
                                   3851 ;------------------------------------------------------------
                                   3852 ;sloc0         Allocated with name '_ak820_usb_raw_task_sloc0_1_0'
                                   3853 ;i             Allocated with name '_ak820_usb_raw_task_i_10000_467'
                                   3854 ;length        Allocated with name '_ak820_usb_raw_task_length_10000_467'
                                   3855 ;address       Allocated with name '_ak820_usb_raw_task_address_10000_467'
                                   3856 ;saved_ea      Allocated with name '_ak820_usb_raw_task_saved_ea_10000_467'
                                   3857 ;------------------------------------------------------------
                                   3858 ;	tmk_core/protocol/ch555/usb_ak820.c:620: void ak820_usb_raw_task(void) {
                                   3859 ;	-----------------------------------------
                                   3860 ;	 function ak820_usb_raw_task
                                   3861 ;	-----------------------------------------
      006D57                       3862 _ak820_usb_raw_task:
                                   3863 ;	tmk_core/protocol/ch555/usb_ak820.c:624: uint8_t saved_ea = EA;
      006D57 A2 AF            [12] 3864 	mov	c,_EA
      006D59 E4               [12] 3865 	clr	a
      006D5A 33               [12] 3866 	rlc	a
      006D5B FF               [12] 3867 	mov	r7,a
                                   3868 ;	tmk_core/protocol/ch555/usb_ak820.c:625: EA = 0;
                                   3869 ;	assignBit
      006D5C C2 AF            [12] 3870 	clr	_EA
                                   3871 ;	tmk_core/protocol/ch555/usb_ak820.c:626: if (!USB_EnumStatus || raw_state != RAW_READY) { EA = saved_ea; return; }
      006D5E 90 07 80         [24] 3872 	mov	dptr,#_USB_EnumStatus
      006D61 E0               [24] 3873 	movx	a,@dptr
      006D62 60 0A            [24] 3874 	jz	00101$
      006D64 90 07 87         [24] 3875 	mov	dptr,#_raw_state
      006D67 E0               [24] 3876 	movx	a,@dptr
      006D68 FE               [12] 3877 	mov	r6,a
      006D69 BE 02 02         [24] 3878 	cjne	r6,#0x02,00427$
      006D6C 80 06            [24] 3879 	sjmp	00102$
      006D6E                       3880 00427$:
      006D6E                       3881 00101$:
                                   3882 ;	assignBit
      006D6E EF               [12] 3883 	mov	a,r7
      006D6F 24 FF            [12] 3884 	add	a,#0xff
      006D71 92 AF            [24] 3885 	mov	_EA,c
      006D73 22               [24] 3886 	ret
      006D74                       3887 00102$:
                                   3888 ;	tmk_core/protocol/ch555/usb_ak820.c:627: raw_state = RAW_WORK;
      006D74 90 07 87         [24] 3889 	mov	dptr,#_raw_state
      006D77 74 03            [12] 3890 	mov	a,#0x03
      006D79 F0               [24] 3891 	movx	@dptr,a
                                   3892 ;	tmk_core/protocol/ch555/usb_ak820.c:628: EA = saved_ea;
                                   3893 ;	assignBit
      006D7A EF               [12] 3894 	mov	a,r7
      006D7B 24 FF            [12] 3895 	add	a,#0xff
      006D7D 92 AF            [24] 3896 	mov	_EA,c
                                   3897 ;	tmk_core/protocol/ch555/usb_ak820.c:629: if (raw_buffer[0] == 0xfd && raw_buffer[1] == 0) {
      006D7F 90 07 88         [24] 3898 	mov	dptr,#_raw_buffer
      006D82 E0               [24] 3899 	movx	a,@dptr
      006D83 FF               [12] 3900 	mov	r7,a
      006D84 E4               [12] 3901 	clr	a
      006D85 BF FD 01         [24] 3902 	cjne	r7,#0xfd,00428$
      006D88 04               [12] 3903 	inc	a
      006D89                       3904 00428$:
      006D89 FF               [12] 3905 	mov	r7,a
      006D8A 70 03            [24] 3906 	jnz	00430$
      006D8C 02 6E 2C         [24] 3907 	ljmp	00141$
      006D8F                       3908 00430$:
      006D8F 90 07 89         [24] 3909 	mov	dptr,#(_raw_buffer + 0x0001)
      006D92 E0               [24] 3910 	movx	a,@dptr
      006D93 60 03            [24] 3911 	jz	00431$
      006D95 02 6E 2C         [24] 3912 	ljmp	00141$
      006D98                       3913 00431$:
                                   3914 ;	tmk_core/protocol/ch555/usb_ak820.c:632: address = ((uint16_t)raw_buffer[2] << 8) | raw_buffer[3];
      006D98 90 07 8A         [24] 3915 	mov	dptr,#(_raw_buffer + 0x0002)
      006D9B E0               [24] 3916 	movx	a,@dptr
      006D9C FD               [12] 3917 	mov	r5,a
      006D9D 7E 00            [12] 3918 	mov	r6,#0x00
      006D9F 90 07 8B         [24] 3919 	mov	dptr,#(_raw_buffer + 0x0003)
      006DA2 E0               [24] 3920 	movx	a,@dptr
      006DA3 7B 00            [12] 3921 	mov	r3,#0x00
      006DA5 42 06            [12] 3922 	orl	ar6,a
      006DA7 EB               [12] 3923 	mov	a,r3
      006DA8 42 05            [12] 3924 	orl	ar5,a
                                   3925 ;	tmk_core/protocol/ch555/usb_ak820.c:633: length = raw_buffer[4];
      006DAA 90 07 8C         [24] 3926 	mov	dptr,#(_raw_buffer + 0x0004)
      006DAD E0               [24] 3927 	movx	a,@dptr
      006DAE FC               [12] 3928 	mov	r4,a
                                   3929 ;	tmk_core/protocol/ch555/usb_ak820.c:634: for (i = 5; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
      006DAF 7B 05            [12] 3930 	mov	r3,#0x05
      006DB1                       3931 00151$:
      006DB1 EB               [12] 3932 	mov	a,r3
      006DB2 12 70 12         [24] 3933 	lcall	_ak820_outline_0040
      006DB5 0B               [12] 3934 	inc	r3
      006DB6 BB 20 00         [24] 3935 	cjne	r3,#0x20,00432$
      006DB9                       3936 00432$:
      006DB9 40 F6            [24] 3937 	jc	00151$
                                   3938 ;	tmk_core/protocol/ch555/usb_ak820.c:635: if (length > RAW_EPSIZE - 5 || (length && address > 0xffffu - (length - 1))) {
      006DBB EC               [12] 3939 	mov	a,r4
      006DBC 24 E4            [12] 3940 	add	a,#0xff - 0x1b
      006DBE 40 1C            [24] 3941 	jc	00106$
                                   3942 ;	free result
      006DC0 EC               [12] 3943 	mov	a,r4
      006DC1 60 26            [24] 3944 	jz	00212$
      006DC3 8C 03            [24] 3945 	mov	ar3,r4
      006DC5 1B               [12] 3946 	dec	r3
      006DC6 7A 00            [12] 3947 	mov	r2,#0x00
      006DC8 74 FF            [12] 3948 	mov	a,#0xff
      006DCA C3               [12] 3949 	clr	c
      006DCB 9B               [12] 3950 	subb	a,r3
      006DCC FB               [12] 3951 	mov	r3,a
      006DCD 74 FF            [12] 3952 	mov	a,#0xff
      006DCF 9A               [12] 3953 	subb	a,r2
      006DD0 FA               [12] 3954 	mov	r2,a
      006DD1 8E 00            [24] 3955 	mov	ar0,r6
      006DD3 8D 01            [24] 3956 	mov	ar1,r5
      006DD5 C3               [12] 3957 	clr	c
      006DD6 EB               [12] 3958 	mov	a,r3
      006DD7 98               [12] 3959 	subb	a,r0
      006DD8 EA               [12] 3960 	mov	a,r2
      006DD9 99               [12] 3961 	subb	a,r1
      006DDA 50 0D            [24] 3962 	jnc	00212$
                                   3963 ;	free result
      006DDC                       3964 00106$:
                                   3965 ;	tmk_core/protocol/ch555/usb_ak820.c:636: raw_buffer[1] = 0xff;
      006DDC 90 07 89         [24] 3966 	mov	dptr,#(_raw_buffer + 0x0001)
      006DDF 74 FF            [12] 3967 	mov	a,#0xff
      006DE1 F0               [24] 3968 	movx	@dptr,a
                                   3969 ;	tmk_core/protocol/ch555/usb_ak820.c:637: raw_buffer[4] = 0;
      006DE2 90 07 8C         [24] 3970 	mov	dptr,#(_raw_buffer + 0x0004)
      006DE5 E4               [12] 3971 	clr	a
      006DE6 F0               [24] 3972 	movx	@dptr,a
                                   3973 ;	tmk_core/protocol/ch555/usb_ak820.c:639: for (i = 0; i < length; ++i) raw_buffer[5 + i] = READ_CODE(address + i);
      006DE7 80 3A            [24] 3974 	sjmp	00108$
      006DE9                       3975 00212$:
      006DE9 7B 00            [12] 3976 	mov	r3,#0x00
      006DEB                       3977 00154$:
      006DEB C3               [12] 3978 	clr	c
      006DEC EB               [12] 3979 	mov	a,r3
      006DED 9C               [12] 3980 	subb	a,r4
      006DEE 50 33            [24] 3981 	jnc	00108$
      006DF0 C0 04            [24] 3982 	push	ar4
      006DF2 8B 02            [24] 3983 	mov	ar2,r3
      006DF4 74 05            [12] 3984 	mov	a,#0x05
      006DF6 2A               [12] 3985 	add	a, r2
      006DF7 F9               [12] 3986 	mov	r1,a
      006DF8 33               [12] 3987 	rlc	a
      006DF9 95 E0            [12] 3988 	subb	a,acc
      006DFB FA               [12] 3989 	mov	r2,a
      006DFC E9               [12] 3990 	mov	a,r1
      006DFD 24 88            [12] 3991 	add	a, #_raw_buffer
      006DFF F9               [12] 3992 	mov	r1,a
      006E00 EA               [12] 3993 	mov	a,r2
      006E01 34 07            [12] 3994 	addc	a, #(_raw_buffer >> 8)
      006E03 FA               [12] 3995 	mov	r2,a
      006E04 8B 1E            [24] 3996 	mov	_ak820_usb_raw_task_sloc0_1_0,r3
      006E06 75 1F 00         [24] 3997 	mov	(_ak820_usb_raw_task_sloc0_1_0 + 1),#0x00
      006E09 8E 00            [24] 3998 	mov	ar0,r6
      006E0B 8D 04            [24] 3999 	mov	ar4,r5
      006E0D E5 1E            [12] 4000 	mov	a,_ak820_usb_raw_task_sloc0_1_0
      006E0F 28               [12] 4001 	add	a, r0
      006E10 F8               [12] 4002 	mov	r0,a
      006E11 E5 1F            [12] 4003 	mov	a,(_ak820_usb_raw_task_sloc0_1_0 + 1)
      006E13 3C               [12] 4004 	addc	a, r4
      006E14 FC               [12] 4005 	mov	r4,a
      006E15 88 82            [24] 4006 	mov	dpl,r0
      006E17 8C 83            [24] 4007 	mov	dph,r4
      006E19 E4               [12] 4008 	clr	a
      006E1A 93               [24] 4009 	movc	a,@a+dptr
      006E1B 12 70 24         [24] 4010 	lcall	_ak820_outline_0136
      006E1E 0B               [12] 4011 	inc	r3
      006E1F D0 04            [24] 4012 	pop	ar4
      006E21 80 C8            [24] 4013 	sjmp	00154$
      006E23                       4014 00108$:
                                   4015 ;	tmk_core/protocol/ch555/usb_ak820.c:643: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
      006E23 12 6F FE         [24] 4016 	lcall	_ak820_outline_0008
      006E26 12 6A 30         [24] 4017 	lcall	_ak820_usb_send
      006E29 02 6F AE         [24] 4018 	ljmp	00142$
      006E2C                       4019 00141$:
                                   4020 ;	tmk_core/protocol/ch555/usb_ak820.c:644: } else if (raw_buffer[0] == 0xfd && raw_buffer[1] == 1) {
      006E2C EF               [12] 4021 	mov	a,r7
      006E2D 70 03            [24] 4022 	jnz	00438$
      006E2F 02 6E B1         [24] 4023 	ljmp	00137$
      006E32                       4024 00438$:
      006E32 90 07 89         [24] 4025 	mov	dptr,#(_raw_buffer + 0x0001)
      006E35 E0               [24] 4026 	movx	a,@dptr
      006E36 FE               [12] 4027 	mov	r6,a
      006E37 BE 01 02         [24] 4028 	cjne	r6,#0x01,00439$
      006E3A 80 03            [24] 4029 	sjmp	00440$
      006E3C                       4030 00439$:
      006E3C 02 6E B1         [24] 4031 	ljmp	00137$
      006E3F                       4032 00440$:
                                   4033 ;	tmk_core/protocol/ch555/usb_ak820.c:647: for (i = 2; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
      006E3F 7E 02            [12] 4034 	mov	r6,#0x02
      006E41                       4035 00156$:
      006E41 EE               [12] 4036 	mov	a,r6
      006E42 12 70 12         [24] 4037 	lcall	_ak820_outline_0040
      006E45 0E               [12] 4038 	inc	r6
      006E46 BE 20 00         [24] 4039 	cjne	r6,#0x20,00441$
      006E49                       4040 00441$:
      006E49 40 F6            [24] 4041 	jc	00156$
                                   4042 ;	tmk_core/protocol/ch555/usb_ak820.c:648: raw_buffer[2] = 1;
      006E4B 90 07 8A         [24] 4043 	mov	dptr,#(_raw_buffer + 0x0002)
      006E4E 74 01            [12] 4044 	mov	a,#0x01
      006E50 F0               [24] 4045 	movx	@dptr,a
                                   4046 ;	tmk_core/protocol/ch555/usb_ak820.c:649: raw_buffer[3] = 0xa8;
      006E51 90 07 8B         [24] 4047 	mov	dptr,#(_raw_buffer + 0x0003)
      006E54 74 A8            [12] 4048 	mov	a,#0xa8
      006E56 F0               [24] 4049 	movx	@dptr,a
                                   4050 ;	tmk_core/protocol/ch555/usb_ak820.c:650: ak820_nvm_diagnostic(&raw_buffer[4]);
      006E57 90 07 8C         [24] 4051 	mov	dptr,#(_raw_buffer + 0x0004)
      006E5A 12 3E 0C         [24] 4052 	lcall	_ak820_nvm_diagnostic
                                   4053 ;	tmk_core/protocol/ch555/usb_ak820.c:651: for (i = 0; i < 6; ++i) raw_buffer[11 + i] = ak820_flash_diagnostic[i];
      006E5D 7E 00            [12] 4054 	mov	r6,#0x00
      006E5F                       4055 00158$:
      006E5F 8E 05            [24] 4056 	mov	ar5,r6
      006E61 74 0B            [12] 4057 	mov	a,#0x0b
      006E63 2D               [12] 4058 	add	a, r5
      006E64 24 88            [12] 4059 	add	a,#_raw_buffer
      006E66 FD               [12] 4060 	mov	r5,a
      006E67 E4               [12] 4061 	clr	a
      006E68 34 07            [12] 4062 	addc	a, #(_raw_buffer >> 8)
      006E6A FC               [12] 4063 	mov	r4,a
      006E6B EE               [12] 4064 	mov	a,r6
      006E6C 24 70            [12] 4065 	add	a, #_ak820_flash_diagnostic
      006E6E F5 82            [12] 4066 	mov	dpl,a
      006E70 E4               [12] 4067 	clr	a
      006E71 34 04            [12] 4068 	addc	a, #(_ak820_flash_diagnostic >> 8)
      006E73 F5 83            [12] 4069 	mov	dph,a
      006E75 E0               [24] 4070 	movx	a,@dptr
      006E76 12 46 10         [24] 4071 	lcall	_ak820_outline_0184
      006E79 F0               [24] 4072 	movx	@dptr,a
      006E7A 0E               [12] 4073 	inc	r6
      006E7B BE 06 00         [24] 4074 	cjne	r6,#0x06,00443$
      006E7E                       4075 00443$:
      006E7E 40 DF            [24] 4076 	jc	00158$
                                   4077 ;	tmk_core/protocol/ch555/usb_ak820.c:652: raw_buffer[17] = vial_unlocked;
      006E80 90 0E 0A         [24] 4078 	mov	dptr,#_vial_unlocked
      006E83 E0               [24] 4079 	movx	a,@dptr
      006E84 90 07 99         [24] 4080 	mov	dptr,#(_raw_buffer + 0x0011)
      006E87 F0               [24] 4081 	movx	@dptr,a
                                   4082 ;	tmk_core/protocol/ch555/usb_ak820.c:653: raw_buffer[18] = vial_unlock_in_progress;
      006E88 90 0E 0B         [24] 4083 	mov	dptr,#_vial_unlock_in_progress
      006E8B E0               [24] 4084 	movx	a,@dptr
      006E8C 90 07 9A         [24] 4085 	mov	dptr,#(_raw_buffer + 0x0012)
      006E8F F0               [24] 4086 	movx	@dptr,a
                                   4087 ;	tmk_core/protocol/ch555/usb_ak820.c:654: raw_buffer[19] = USB_EnumStatus;
      006E90 90 07 80         [24] 4088 	mov	dptr,#_USB_EnumStatus
      006E93 E0               [24] 4089 	movx	a,@dptr
      006E94 90 07 9B         [24] 4090 	mov	dptr,#(_raw_buffer + 0x0013)
      006E97 F0               [24] 4091 	movx	@dptr,a
                                   4092 ;	tmk_core/protocol/ch555/usb_ak820.c:655: raw_buffer[20] = USB_SleepStatus;
      006E98 90 07 81         [24] 4093 	mov	dptr,#_USB_SleepStatus
      006E9B E0               [24] 4094 	movx	a,@dptr
      006E9C 90 07 9C         [24] 4095 	mov	dptr,#(_raw_buffer + 0x0014)
      006E9F F0               [24] 4096 	movx	@dptr,a
                                   4097 ;	tmk_core/protocol/ch555/usb_ak820.c:656: raw_buffer[21] = raw_state;
      006EA0 90 07 87         [24] 4098 	mov	dptr,#_raw_state
      006EA3 E0               [24] 4099 	movx	a,@dptr
      006EA4 90 07 9D         [24] 4100 	mov	dptr,#(_raw_buffer + 0x0015)
      006EA7 F0               [24] 4101 	movx	@dptr,a
                                   4102 ;	tmk_core/protocol/ch555/usb_ak820.c:657: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
      006EA8 12 6F FE         [24] 4103 	lcall	_ak820_outline_0008
      006EAB 12 6A 30         [24] 4104 	lcall	_ak820_usb_send
      006EAE 02 6F AE         [24] 4105 	ljmp	00142$
      006EB1                       4106 00137$:
                                   4107 ;	tmk_core/protocol/ch555/usb_ak820.c:659: } else if (raw_buffer[0] == 0xfd && raw_buffer[1] == 2) {
      006EB1 EF               [12] 4108 	mov	a,r7
      006EB2 70 03            [24] 4109 	jnz	00445$
      006EB4 02 6F 8B         [24] 4110 	ljmp	00133$
      006EB7                       4111 00445$:
      006EB7 12 70 2A         [24] 4112 	lcall	_ak820_outline_0159
      006EBA BF 02 02         [24] 4113 	cjne	r7,#0x02,00446$
      006EBD 80 03            [24] 4114 	sjmp	00447$
      006EBF                       4115 00446$:
      006EBF 02 6F 8B         [24] 4116 	ljmp	00133$
      006EC2                       4117 00447$:
                                   4118 ;	tmk_core/protocol/ch555/usb_ak820.c:663: length = 1;
      006EC2 90 07 F3         [24] 4119 	mov	dptr,#_ak820_usb_raw_task_length_10000_467
      006EC5 74 01            [12] 4120 	mov	a,#0x01
      006EC7 F0               [24] 4121 	movx	@dptr,a
                                   4122 ;	tmk_core/protocol/ch555/usb_ak820.c:664: if (raw_buffer[2] == 1 && raw_buffer[3] <= 1 && raw_buffer[4] <= AK820_OS_BREATHE &&
      006EC8 90 07 8A         [24] 4123 	mov	dptr,#(_raw_buffer + 0x0002)
      006ECB E0               [24] 4124 	movx	a,@dptr
      006ECC FF               [12] 4125 	mov	r7,a
      006ECD BF 01 72         [24] 4126 	cjne	r7,#0x01,00235$
      006ED0 90 07 8B         [24] 4127 	mov	dptr,#(_raw_buffer + 0x0003)
      006ED3 E0               [24] 4128 	movx	a,@dptr
      006ED4 FF               [12] 4129 	mov  r7,a
      006ED5 24 FE            [12] 4130 	add	a,#0xff - 0x01
      006ED7 40 69            [24] 4131 	jc	00235$
                                   4132 ;	free result
      006ED9 90 07 8C         [24] 4133 	mov	dptr,#(_raw_buffer + 0x0004)
      006EDC E0               [24] 4134 	movx	a,@dptr
      006EDD FE               [12] 4135 	mov  r6,a
      006EDE 24 FC            [12] 4136 	add	a,#0xff - 0x03
      006EE0 40 60            [24] 4137 	jc	00235$
                                   4138 ;	free result
                                   4139 ;	tmk_core/protocol/ch555/usb_ak820.c:665: (raw_buffer[3] || !raw_buffer[4])) {
      006EE2 EF               [12] 4140 	mov	a,r7
      006EE3 70 03            [24] 4141 	jnz	00227$
      006EE5 EE               [12] 4142 	mov	a,r6
      006EE6 70 5A            [24] 4143 	jnz	00235$
                                   4144 ;	tmk_core/protocol/ch555/usb_ak820.c:666: for (i = 5; i < RAW_EPSIZE && !raw_buffer[i]; ++i) {}
      006EE8                       4145 00227$:
      006EE8 7D 05            [12] 4146 	mov	r5,#0x05
      006EEA                       4147 00162$:
      006EEA BD 20 00         [24] 4148 	cjne	r5,#0x20,00454$
      006EED                       4149 00454$:
      006EED 50 10            [24] 4150 	jnc	00113$
      006EEF ED               [12] 4151 	mov	a,r5
      006EF0 24 88            [12] 4152 	add	a, #_raw_buffer
      006EF2 FB               [12] 4153 	mov	r3,a
      006EF3 E4               [12] 4154 	clr	a
      006EF4 34 07            [12] 4155 	addc	a, #(_raw_buffer >> 8)
      006EF6 FC               [12] 4156 	mov	r4,a
      006EF7 12 70 1E         [24] 4157 	lcall	_ak820_outline_0118
      006EFA 70 03            [24] 4158 	jnz	00113$
      006EFC 0D               [12] 4159 	inc	r5
      006EFD 80 EB            [24] 4160 	sjmp	00162$
      006EFF                       4161 00113$:
                                   4162 ;	tmk_core/protocol/ch555/usb_ak820.c:667: if (i == RAW_EPSIZE) {
      006EFF BD 20 40         [24] 4163 	cjne	r5,#0x20,00235$
                                   4164 ;	tmk_core/protocol/ch555/usb_ak820.c:668: saved_ea = EA;
                                   4165 ;	assignBit
      006F02 A2 AF            [12] 4166 	mov	c,_EA
      006F04 92 1C            [24] 4167 	mov	_ak820_usb_raw_task_sloc1_1_0,c
                                   4168 ;	tmk_core/protocol/ch555/usb_ak820.c:669: EA = 0;
                                   4169 ;	assignBit
      006F06 C2 AF            [12] 4170 	clr	_EA
                                   4171 ;	tmk_core/protocol/ch555/usb_ak820.c:672: if (raw_state == RAW_WORK && USB_EnumStatus && D0UsbConfig &&
      006F08 90 07 87         [24] 4172 	mov	dptr,#_raw_state
      006F0B E0               [24] 4173 	movx	a,@dptr
      006F0C FD               [12] 4174 	mov	r5,a
      006F0D BD 03 28         [24] 4175 	cjne	r5,#0x03,00117$
      006F10 90 07 80         [24] 4176 	mov	dptr,#_USB_EnumStatus
      006F13 E0               [24] 4177 	movx	a,@dptr
      006F14 60 22            [24] 4178 	jz	00117$
      006F16 90 07 7F         [24] 4179 	mov	dptr,#_D0UsbConfig
      006F19 E0               [24] 4180 	movx	a,@dptr
      006F1A 60 1C            [24] 4181 	jz	00117$
                                   4182 ;	tmk_core/protocol/ch555/usb_ak820.c:673: !(USB_SleepStatus & 2) && !vial_unlock_in_progress) {
      006F1C 90 07 81         [24] 4183 	mov	dptr,#_USB_SleepStatus
      006F1F E0               [24] 4184 	movx	a,@dptr
      006F20 20 E1 15         [24] 4185 	jb	acc.1,00117$
      006F23 90 0E 0B         [24] 4186 	mov	dptr,#_vial_unlock_in_progress
      006F26 E0               [24] 4187 	movx	a,@dptr
      006F27 70 0F            [24] 4188 	jnz	00117$
                                   4189 ;	tmk_core/protocol/ch555/usb_ak820.c:674: if (raw_buffer[3]) ak820_os_indicator_set(raw_buffer[4]);
      006F29 EF               [12] 4190 	mov	a,r7
      006F2A 60 05            [24] 4191 	jz	00115$
      006F2C 8E 82            [24] 4192 	mov	dpl, r6
      006F2E 12 46 15         [24] 4193 	lcall	_ak820_os_indicator_set
      006F31                       4194 00115$:
                                   4195 ;	tmk_core/protocol/ch555/usb_ak820.c:675: length = 0;
      006F31 90 07 F3         [24] 4196 	mov	dptr,#_ak820_usb_raw_task_length_10000_467
      006F34 E4               [12] 4197 	clr	a
      006F35 F0               [24] 4198 	movx	@dptr,a
      006F36 80 06            [24] 4199 	sjmp	00118$
      006F38                       4200 00117$:
                                   4201 ;	tmk_core/protocol/ch555/usb_ak820.c:676: } else length = 2;
      006F38 90 07 F3         [24] 4202 	mov	dptr,#_ak820_usb_raw_task_length_10000_467
      006F3B 74 02            [12] 4203 	mov	a,#0x02
      006F3D F0               [24] 4204 	movx	@dptr,a
      006F3E                       4205 00118$:
                                   4206 ;	tmk_core/protocol/ch555/usb_ak820.c:677: EA = saved_ea;
                                   4207 ;	assignBit
      006F3E A2 1C            [12] 4208 	mov	c,_ak820_usb_raw_task_sloc1_1_0
      006F40 92 AF            [24] 4209 	mov	_EA,c
                                   4210 ;	tmk_core/protocol/ch555/usb_ak820.c:680: for (i = 2; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
      006F42                       4211 00235$:
      006F42 7F 02            [12] 4212 	mov	r7,#0x02
      006F44                       4213 00164$:
      006F44 EF               [12] 4214 	mov	a,r7
      006F45 12 70 12         [24] 4215 	lcall	_ak820_outline_0040
      006F48 0F               [12] 4216 	inc	r7
      006F49 BF 20 00         [24] 4217 	cjne	r7,#0x20,00466$
      006F4C                       4218 00466$:
      006F4C 40 F6            [24] 4219 	jc	00164$
                                   4220 ;	tmk_core/protocol/ch555/usb_ak820.c:681: raw_buffer[2] = 1;
      006F4E 90 07 8A         [24] 4221 	mov	dptr,#(_raw_buffer + 0x0002)
      006F51 74 01            [12] 4222 	mov	a,#0x01
      006F53 F0               [24] 4223 	movx	@dptr,a
                                   4224 ;	tmk_core/protocol/ch555/usb_ak820.c:682: raw_buffer[3] = length;
      006F54 90 07 F3         [24] 4225 	mov	dptr,#_ak820_usb_raw_task_length_10000_467
      006F57 E0               [24] 4226 	movx	a,@dptr
      006F58 90 07 8B         [24] 4227 	mov	dptr,#(_raw_buffer + 0x0003)
      006F5B F0               [24] 4228 	movx	@dptr,a
                                   4229 ;	tmk_core/protocol/ch555/usb_ak820.c:683: raw_buffer[4] = ak820_os_indicator_get();
      006F5C 12 46 3C         [24] 4230 	lcall	_ak820_os_indicator_get
      006F5F AF 82            [24] 4231 	mov	r7, dpl
      006F61 90 07 8C         [24] 4232 	mov	dptr,#(_raw_buffer + 0x0004)
      006F64 EF               [12] 4233 	mov	a,r7
      006F65 F0               [24] 4234 	movx	@dptr,a
                                   4235 ;	tmk_core/protocol/ch555/usb_ak820.c:684: raw_buffer[5] = 0xa8;
      006F66 90 07 8D         [24] 4236 	mov	dptr,#(_raw_buffer + 0x0005)
      006F69 74 A8            [12] 4237 	mov	a,#0xa8
      006F6B F0               [24] 4238 	movx	@dptr,a
                                   4239 ;	tmk_core/protocol/ch555/usb_ak820.c:685: raw_buffer[6] = (uint8_t)AK820_OS_INDICATOR_LEASE_MS;
      006F6C 90 07 8E         [24] 4240 	mov	dptr,#(_raw_buffer + 0x0006)
      006F6F 74 B8            [12] 4241 	mov	a,#0xb8
      006F71 F0               [24] 4242 	movx	@dptr,a
                                   4243 ;	tmk_core/protocol/ch555/usb_ak820.c:686: raw_buffer[7] = (uint8_t)(AK820_OS_INDICATOR_LEASE_MS >> 8);
      006F72 90 07 8F         [24] 4244 	mov	dptr,#(_raw_buffer + 0x0007)
      006F75 74 0B            [12] 4245 	mov	a,#0x0b
      006F77 F0               [24] 4246 	movx	@dptr,a
                                   4247 ;	tmk_core/protocol/ch555/usb_ak820.c:687: raw_buffer[8] = (uint8_t)AK820_OS_INDICATOR_PERIOD_MS;
      006F78 90 07 90         [24] 4248 	mov	dptr,#(_raw_buffer + 0x0008)
      006F7B E4               [12] 4249 	clr	a
      006F7C F0               [24] 4250 	movx	@dptr,a
                                   4251 ;	tmk_core/protocol/ch555/usb_ak820.c:688: raw_buffer[9] = (uint8_t)(AK820_OS_INDICATOR_PERIOD_MS >> 8);
      006F7D 90 07 91         [24] 4252 	mov	dptr,#(_raw_buffer + 0x0009)
      006F80 74 10            [12] 4253 	mov	a,#0x10
      006F82 F0               [24] 4254 	movx	@dptr,a
                                   4255 ;	tmk_core/protocol/ch555/usb_ak820.c:689: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
      006F83 12 6F FE         [24] 4256 	lcall	_ak820_outline_0008
      006F86 12 6A 30         [24] 4257 	lcall	_ak820_usb_send
      006F89 80 23            [24] 4258 	sjmp	00142$
      006F8B                       4259 00133$:
                                   4260 ;	tmk_core/protocol/ch555/usb_ak820.c:692: raw_reply_without_nvm = raw_request_is_nonpersistent();
      006F8B 12 6C 3F         [24] 4261 	lcall	_raw_request_is_nonpersistent
      006F8E E5 82            [12] 4262 	mov	a, dpl
      006F90 90 07 A8         [24] 4263 	mov	dptr,#_raw_reply_without_nvm
      006F93 F0               [24] 4264 	movx	@dptr,a
                                   4265 ;	tmk_core/protocol/ch555/usb_ak820.c:693: ak820_nvm_begin();
      006F94 12 41 EF         [24] 4266 	lcall	_ak820_nvm_begin
                                   4267 ;	tmk_core/protocol/ch555/usb_ak820.c:694: raw_hid_receive(raw_buffer, RAW_EPSIZE);
      006F97 90 0C 3B         [24] 4268 	mov	dptr,#_raw_hid_receive_PARM_2
      006F9A 74 20            [12] 4269 	mov	a,#0x20
      006F9C F0               [24] 4270 	movx	@dptr,a
      006F9D 90 07 88         [24] 4271 	mov	dptr,#_raw_buffer
      006FA0 75 F0 00         [24] 4272 	mov	b, #0x00
      006FA3 12 A8 D1         [24] 4273 	lcall	_raw_hid_receive
                                   4274 ;	tmk_core/protocol/ch555/usb_ak820.c:695: ak820_nvm_end();
      006FA6 12 42 04         [24] 4275 	lcall	_ak820_nvm_end
                                   4276 ;	tmk_core/protocol/ch555/usb_ak820.c:696: raw_reply_without_nvm = false;
      006FA9 90 07 A8         [24] 4277 	mov	dptr,#_raw_reply_without_nvm
      006FAC E4               [12] 4278 	clr	a
      006FAD F0               [24] 4279 	movx	@dptr,a
      006FAE                       4280 00142$:
                                   4281 ;	tmk_core/protocol/ch555/usb_ak820.c:698: saved_ea = EA;
                                   4282 ;	assignBit
      006FAE A2 AF            [12] 4283 	mov	c,_EA
      006FB0 92 1C            [24] 4284 	mov	_ak820_usb_raw_task_sloc1_1_0,c
                                   4285 ;	tmk_core/protocol/ch555/usb_ak820.c:699: EA = 0;
                                   4286 ;	assignBit
      006FB2 C2 AF            [12] 4287 	clr	_EA
                                   4288 ;	tmk_core/protocol/ch555/usb_ak820.c:701: if (raw_state == RAW_TX_ACTIVE) raw_state = RAW_TX_WAIT;
      006FB4 12 70 30         [24] 4289 	lcall	_ak820_outline_0161
      006FB7 BF 04 08         [24] 4290 	cjne	r7,#0x04,00149$
      006FBA 90 07 87         [24] 4291 	mov	dptr,#_raw_state
      006FBD 74 05            [12] 4292 	mov	a,#0x05
      006FBF F0               [24] 4293 	movx	@dptr,a
      006FC0 80 1B            [24] 4294 	sjmp	00150$
      006FC2                       4295 00149$:
                                   4296 ;	tmk_core/protocol/ch555/usb_ak820.c:702: else if (raw_state == RAW_WORK || raw_state == RAW_DRAINED || raw_state == RAW_CANCELLED) raw_state = RAW_IDLE;
      006FC2 12 70 30         [24] 4297 	lcall	_ak820_outline_0161
      006FC5 BF 03 02         [24] 4298 	cjne	r7,#0x03,00470$
      006FC8 80 0E            [24] 4299 	sjmp	00144$
      006FCA                       4300 00470$:
      006FCA 12 70 30         [24] 4301 	lcall	_ak820_outline_0161
      006FCD BF 06 02         [24] 4302 	cjne	r7,#0x06,00471$
      006FD0 80 06            [24] 4303 	sjmp	00144$
      006FD2                       4304 00471$:
      006FD2 12 70 30         [24] 4305 	lcall	_ak820_outline_0161
      006FD5 BF 07 05         [24] 4306 	cjne	r7,#0x07,00150$
      006FD8                       4307 00144$:
      006FD8 90 07 87         [24] 4308 	mov	dptr,#_raw_state
      006FDB E4               [12] 4309 	clr	a
      006FDC F0               [24] 4310 	movx	@dptr,a
      006FDD                       4311 00150$:
                                   4312 ;	tmk_core/protocol/ch555/usb_ak820.c:703: EA = saved_ea;
                                   4313 ;	assignBit
      006FDD A2 1C            [12] 4314 	mov	c,_ak820_usb_raw_task_sloc1_1_0
      006FDF 92 AF            [24] 4315 	mov	_EA,c
                                   4316 ;	tmk_core/protocol/ch555/usb_ak820.c:704: }
      006FE1 22               [24] 4317 	ret
                                   4318 ;------------------------------------------------------------
                                   4319 ;Allocation info for local variables in function 'ak820_usb_take_keyboard_reset'
                                   4320 ;------------------------------------------------------------
                                   4321 ;result        Allocated with name '_ak820_usb_take_keyboard_reset_result_10000_497'
                                   4322 ;saved_ea      Allocated with name '_ak820_usb_take_keyboard_reset_saved_ea_10000_497'
                                   4323 ;------------------------------------------------------------
                                   4324 ;	tmk_core/protocol/ch555/usb_ak820.c:712: bool ak820_usb_take_keyboard_reset(void) {
                                   4325 ;	-----------------------------------------
                                   4326 ;	 function ak820_usb_take_keyboard_reset
                                   4327 ;	-----------------------------------------
      006FE2                       4328 _ak820_usb_take_keyboard_reset:
                                   4329 ;	tmk_core/protocol/ch555/usb_ak820.c:714: uint8_t saved_ea = EA;
                                   4330 ;	assignBit
      006FE2 A2 AF            [12] 4331 	mov	c,_EA
      006FE4 92 1D            [24] 4332 	mov	_ak820_usb_take_keyboard_reset_sloc0_1_0,c
                                   4333 ;	tmk_core/protocol/ch555/usb_ak820.c:715: EA = 0;
                                   4334 ;	assignBit
      006FE6 C2 AF            [12] 4335 	clr	_EA
                                   4336 ;	tmk_core/protocol/ch555/usb_ak820.c:716: result = keyboard_reset;
      006FE8 90 07 A9         [24] 4337 	mov	dptr,#_keyboard_reset
      006FEB E0               [24] 4338 	movx	a,@dptr
      006FEC FF               [12] 4339 	mov	r7,a
                                   4340 ;	tmk_core/protocol/ch555/usb_ak820.c:717: keyboard_reset = 0;
      006FED E4               [12] 4341 	clr	a
      006FEE F0               [24] 4342 	movx	@dptr,a
                                   4343 ;	tmk_core/protocol/ch555/usb_ak820.c:718: EA = saved_ea;
                                   4344 ;	assignBit
      006FEF A2 1D            [12] 4345 	mov	c,_ak820_usb_take_keyboard_reset_sloc0_1_0
      006FF1 92 AF            [24] 4346 	mov	_EA,c
                                   4347 ;	tmk_core/protocol/ch555/usb_ak820.c:719: return result != 0;
      006FF3 EF               [12] 4348 	mov	a,r7
      006FF4 B4 01 00         [24] 4349 	cjne	a,#0x01,00103$
      006FF7                       4350 00103$:
      006FF7 B3               [12] 4351 	cpl	c
      006FF8 92 1D            [24] 4352 	mov	_ak820_usb_take_keyboard_reset_sloc0_1_0,c
      006FFA 12 3A C7         [24] 4353 	lcall	_ak820_outline_0167
                                   4354 ;	tmk_core/protocol/ch555/usb_ak820.c:720: }
      006FFD 22               [24] 4355 	ret
                                   4356 	.area CSEG    (CODE)
                                   4357 	.area CONST   (CODE)
                                   4358 	.area CONST   (CODE)
      00BBAA                       4359 _shared_offsets:
      00BBAA 00                    4360 	.db #0x00	; 0
      00BBAB 00                    4361 	.db #0x00	; 0
      00BBAC 28                    4362 	.db #0x28	; 40
      00BBAD 28                    4363 	.db #0x28	; 40
      00BBAE 2B                    4364 	.db #0x2b	; 43
      00BBAF 00                    4365 	.db #0x00	; 0
      00BBB0 08                    4366 	.db #0x08	; 8
                                   4367 	.area CSEG    (CODE)
                                   4368 	.area CONST   (CODE)
      00BBB1                       4369 _shared_lengths:
      00BBB1 00                    4370 	.db #0x00	; 0
      00BBB2 00                    4371 	.db #0x00	; 0
      00BBB3 00                    4372 	.db #0x00	; 0
      00BBB4 03                    4373 	.db #0x03	; 3
      00BBB5 03                    4374 	.db #0x03	; 3
      00BBB6 00                    4375 	.db #0x00	; 0
      00BBB7 20                    4376 	.db #0x20	; 32
                                   4377 	.area CSEG    (CODE)
                                   4378 	.area CONST   (CODE)
      00BBB8                       4379 _interface_descriptors:
      00BBB8 53 C1                 4380 	.byte _KeyboardReport, (_KeyboardReport >> 8)
      00BBBA 53 C2                 4381 	.byte (_ConfigurationDescriptor + 18), ((_ConfigurationDescriptor + 18) >> 8)
      00BBBC 06 C2                 4382 	.byte _RawReport, (_RawReport >> 8)
      00BBBE 6C C2                 4383 	.byte (_ConfigurationDescriptor + 43), ((_ConfigurationDescriptor + 43) >> 8)
      00BBC0 98 C1                 4384 	.byte _SharedReport, (_SharedReport >> 8)
      00BBC2 85 C2                 4385 	.byte (_ConfigurationDescriptor + 68), ((_ConfigurationDescriptor + 68) >> 8)
                                   4386 	.area CSEG    (CODE)
                                   4387 	.area XINIT   (CODE)
                                   4388 	.area CABS    (ABS,CODE)
                                   4389 
                                   4390 ; Experimental exact instruction outlining.
                                   4391 	.globl _ak820_outline_0008
                                   4392 	.globl _ak820_outline_0016
                                   4393 	.globl _ak820_outline_0037
                                   4394 	.globl _ak820_outline_0040
                                   4395 	.globl _ak820_outline_0093
                                   4396 	.globl _ak820_outline_0118
                                   4397 	.globl _ak820_outline_0136
                                   4398 	.globl _ak820_outline_0157
                                   4399 	.globl _ak820_outline_0159
                                   4400 	.globl _ak820_outline_0161
                                   4401 	.globl _ak820_outline_0167
                                   4402 	.globl _ak820_outline_0184
                                   4403 
                                   4404 	.area CSEG (CODE)
                                   4405 ; function ak820_outline_0008
      006FFE                       4406 _ak820_outline_0008:
      006FFE 90 07 E5         [24] 4407 	mov	dptr,#_ak820_usb_send_PARM_2
      007001 74 88            [12] 4408 	mov	a,#_raw_buffer
      007003 F0               [24] 4409 	movx	@dptr,a
      007004 74 07            [12] 4410 	mov	a,#(_raw_buffer>>8)
      007006 A3               [24] 4411 	inc	dptr
      007007 F0               [24] 4412 	movx	@dptr,a
      007008 90 07 E7         [24] 4413 	mov	dptr,#_ak820_usb_send_PARM_3
      00700B 74 20            [12] 4414 	mov	a,#0x20
      00700D F0               [24] 4415 	movx	@dptr,a
      00700E 75 82 03         [24] 4416 	mov	dpl,#0x03
      007011 22               [24] 4417 	ret
                                   4418 
                                   4419 	.area CSEG (CODE)
                                   4420 ; function ak820_outline_0040
      007012                       4421 _ak820_outline_0040:
      007012 24 88            [12] 4422 	add	a,#_raw_buffer
      007014 F5 82            [12] 4423 	mov	dpl,a
      007016 E4               [12] 4424 	clr	a
      007017 34 07            [12] 4425 	addc	a,#(_raw_buffer>>8)
      007019 F5 83            [12] 4426 	mov	dph,a
      00701B E4               [12] 4427 	clr	a
      00701C F0               [24] 4428 	movx	@dptr,a
      00701D 22               [24] 4429 	ret
                                   4430 
                                   4431 	.area CSEG (CODE)
                                   4432 ; function ak820_outline_0118
      00701E                       4433 _ak820_outline_0118:
      00701E 8B 82            [24] 4434 	mov	dpl,r3
      007020 8C 83            [24] 4435 	mov	dph,r4
      007022 E0               [24] 4436 	movx	a,@dptr
      007023 22               [24] 4437 	ret
                                   4438 
                                   4439 	.area CSEG (CODE)
                                   4440 ; function ak820_outline_0136
      007024                       4441 _ak820_outline_0136:
      007024 89 82            [24] 4442 	mov	dpl,r1
      007026 8A 83            [24] 4443 	mov	dph,r2
      007028 F0               [24] 4444 	movx	@dptr,a
      007029 22               [24] 4445 	ret
                                   4446 
                                   4447 	.area CSEG (CODE)
                                   4448 ; function ak820_outline_0159
      00702A                       4449 _ak820_outline_0159:
      00702A 90 07 89         [24] 4450 	mov	dptr,#(_raw_buffer+0x0001)
      00702D E0               [24] 4451 	movx	a,@dptr
      00702E FF               [12] 4452 	mov	r7,a
      00702F 22               [24] 4453 	ret
                                   4454 
                                   4455 	.area CSEG (CODE)
                                   4456 ; function ak820_outline_0161
      007030                       4457 _ak820_outline_0161:
      007030 90 07 87         [24] 4458 	mov	dptr,#_raw_state
      007033 E0               [24] 4459 	movx	a,@dptr
      007034 FF               [12] 4460 	mov	r7,a
      007035 22               [24] 4461 	ret
