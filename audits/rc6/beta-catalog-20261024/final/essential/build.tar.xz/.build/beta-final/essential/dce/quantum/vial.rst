                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module vial
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _unregister_code16
                                     12 	.globl _register_code16
                                     13 	.globl _matrix_is_on
                                     14 	.globl _dynamic_keymap_set_combo
                                     15 	.globl _dynamic_keymap_get_combo
                                     16 	.globl _dynamic_keymap_set_encoder
                                     17 	.globl _dynamic_keymap_get_encoder
                                     18 	.globl _repeat_key_cancel
                                     19 	.globl _ak820_combo_reload
                                     20 	.globl _clear_keyboard
                                     21 	.globl _ak820_action_exec
                                     22 	.globl _timer_elapsed32
                                     23 	.globl _timer_read32
                                     24 	.globl _timer_read
                                     25 	.globl ___memcpy
                                     26 	.globl _ADC_START
                                     27 	.globl _S0_R_FIFO
                                     28 	.globl _S0_T_FIFO
                                     29 	.globl _S0_FREE
                                     30 	.globl _S0_IF_BYTE
                                     31 	.globl _S0_IF_FIRST
                                     32 	.globl _S0_IF_OV
                                     33 	.globl _S0_FST_ACT
                                     34 	.globl _CP_RL2
                                     35 	.globl _C_T2
                                     36 	.globl _TR2
                                     37 	.globl _EXEN2
                                     38 	.globl _TCLK
                                     39 	.globl _RCLK
                                     40 	.globl _EXF2
                                     41 	.globl _CAP1F
                                     42 	.globl _TF2
                                     43 	.globl _RI
                                     44 	.globl _TI
                                     45 	.globl _RB8
                                     46 	.globl _TB8
                                     47 	.globl _REN
                                     48 	.globl _SM2
                                     49 	.globl _SM1
                                     50 	.globl _SM0
                                     51 	.globl _IT0
                                     52 	.globl _IE0
                                     53 	.globl _IT1
                                     54 	.globl _IE1
                                     55 	.globl _TR0
                                     56 	.globl _TF0
                                     57 	.globl _TR1
                                     58 	.globl _TF1
                                     59 	.globl _P4_0
                                     60 	.globl _P4_1
                                     61 	.globl _P4_2
                                     62 	.globl _P4_3
                                     63 	.globl _P4_4
                                     64 	.globl _P4_5
                                     65 	.globl _P4_6
                                     66 	.globl _RXD
                                     67 	.globl _TXD
                                     68 	.globl _INT0
                                     69 	.globl _INT1
                                     70 	.globl _T0
                                     71 	.globl _T1
                                     72 	.globl _MOSI1
                                     73 	.globl _MISO1
                                     74 	.globl _SCK1
                                     75 	.globl _P3_0
                                     76 	.globl _P3_1
                                     77 	.globl _P3_2
                                     78 	.globl _P3_3
                                     79 	.globl _P3_4
                                     80 	.globl _P3_5
                                     81 	.globl _P3_6
                                     82 	.globl _P3_7
                                     83 	.globl _CAP1_
                                     84 	.globl _T2_
                                     85 	.globl _CAP2_
                                     86 	.globl _T2EX_
                                     87 	.globl _RXD1
                                     88 	.globl _TXD1
                                     89 	.globl _P2_0
                                     90 	.globl _P2_1
                                     91 	.globl _P2_2
                                     92 	.globl _P2_3
                                     93 	.globl _P2_4
                                     94 	.globl _P2_5
                                     95 	.globl _P2_6
                                     96 	.globl _P2_7
                                     97 	.globl _AIN0
                                     98 	.globl _AIN1
                                     99 	.globl _AIN2
                                    100 	.globl _AIN3
                                    101 	.globl _AIN4
                                    102 	.globl _AIN5
                                    103 	.globl _AIN6
                                    104 	.globl _AIN7
                                    105 	.globl _CAP1
                                    106 	.globl _T2
                                    107 	.globl _CAP2
                                    108 	.globl _T2EX
                                    109 	.globl _INT0_
                                    110 	.globl _SCS
                                    111 	.globl _MOSI
                                    112 	.globl _MISO
                                    113 	.globl _SCK
                                    114 	.globl _RXD1_
                                    115 	.globl _TXD1_
                                    116 	.globl _P1_0
                                    117 	.globl _P1_1
                                    118 	.globl _P1_2
                                    119 	.globl _P1_3
                                    120 	.globl _P1_4
                                    121 	.globl _P1_5
                                    122 	.globl _P1_6
                                    123 	.globl _P1_7
                                    124 	.globl _AIN8
                                    125 	.globl _AIN9
                                    126 	.globl _AIN10
                                    127 	.globl _AIN11
                                    128 	.globl _AIN12
                                    129 	.globl _AIN13
                                    130 	.globl _RXD_
                                    131 	.globl _TXD_
                                    132 	.globl _SCL0
                                    133 	.globl _SDA0
                                    134 	.globl _P0_0
                                    135 	.globl _P0_1
                                    136 	.globl _P0_2
                                    137 	.globl _P0_3
                                    138 	.globl _P0_4
                                    139 	.globl _P0_5
                                    140 	.globl _P0_6
                                    141 	.globl _P0_7
                                    142 	.globl _IE_SPI0
                                    143 	.globl _IE_USB
                                    144 	.globl _IE_ADC
                                    145 	.globl _IE_UART1
                                    146 	.globl _IE_PWM_I2C
                                    147 	.globl _IE_GPIO
                                    148 	.globl _IE_WDOG
                                    149 	.globl _PX0
                                    150 	.globl _PT0
                                    151 	.globl _PX1
                                    152 	.globl _PT1
                                    153 	.globl _PS
                                    154 	.globl _PT2
                                    155 	.globl _PL_FLAG
                                    156 	.globl _PH_FLAG
                                    157 	.globl _EX0
                                    158 	.globl _ET0
                                    159 	.globl _EX1
                                    160 	.globl _ET1
                                    161 	.globl _ES
                                    162 	.globl _ET2
                                    163 	.globl _E_DIS
                                    164 	.globl _EA
                                    165 	.globl _P
                                    166 	.globl _F1
                                    167 	.globl _OV
                                    168 	.globl _RS0
                                    169 	.globl _RS1
                                    170 	.globl _F0
                                    171 	.globl _AC
                                    172 	.globl _CY
                                    173 	.globl _I2CS_INT_ST
                                    174 	.globl _I2CX_INT
                                    175 	.globl _LED_STATUS
                                    176 	.globl _LED_DMA_H
                                    177 	.globl _LED_DMA_L
                                    178 	.globl _LED_DMA
                                    179 	.globl _LED_PWM_OE
                                    180 	.globl _LED_COMMON
                                    181 	.globl _ADC_CHAN
                                    182 	.globl _ADC_DAT_H
                                    183 	.globl _ADC_DAT_L
                                    184 	.globl _ADC_DAT
                                    185 	.globl _ADC_CTRL
                                    186 	.globl _SPI1_CK_SE
                                    187 	.globl _SPI1_CTRL
                                    188 	.globl _SPI1_DATA
                                    189 	.globl _SPI1_STAT
                                    190 	.globl _SIF1
                                    191 	.globl _SBAUD1
                                    192 	.globl _SBUF1
                                    193 	.globl _SCON1
                                    194 	.globl _SPI0_SETUP
                                    195 	.globl _SPI0_CK_SE
                                    196 	.globl _SPI0_CTRL
                                    197 	.globl _SPI0_DATA
                                    198 	.globl _SPI0_STAT
                                    199 	.globl _T2CAP1H
                                    200 	.globl _T2CAP1L
                                    201 	.globl _T2CAP1
                                    202 	.globl _TH2
                                    203 	.globl _TL2
                                    204 	.globl _T2COUNT
                                    205 	.globl _RCAP2H
                                    206 	.globl _RCAP2L
                                    207 	.globl _RCAP2
                                    208 	.globl _T2MOD
                                    209 	.globl _T2CON
                                    210 	.globl _SBUF
                                    211 	.globl _SCON
                                    212 	.globl _TH1
                                    213 	.globl _TH0
                                    214 	.globl _TL1
                                    215 	.globl _TL0
                                    216 	.globl _TMOD
                                    217 	.globl _TCON
                                    218 	.globl _XBUS_AUX
                                    219 	.globl _P7
                                    220 	.globl _P6_DIR
                                    221 	.globl _P6_OUT_PU
                                    222 	.globl _P6_IN
                                    223 	.globl _P5_DIR
                                    224 	.globl _P5_OUT_PU
                                    225 	.globl _P5_IN
                                    226 	.globl _P4_LED_KEY
                                    227 	.globl _P4_DIR_PU
                                    228 	.globl _P4_MOD_OC
                                    229 	.globl _P4
                                    230 	.globl _P3_DIR_PU
                                    231 	.globl _P3_MOD_OC
                                    232 	.globl _P3
                                    233 	.globl _P2_DIR_PU
                                    234 	.globl _P2_MOD_OC
                                    235 	.globl _P2
                                    236 	.globl _P1_DIR_PU
                                    237 	.globl _P1_MOD_OC
                                    238 	.globl _P1
                                    239 	.globl _P0_DIR_PU
                                    240 	.globl _P0_MOD_OC
                                    241 	.globl _P0
                                    242 	.globl _ROM_CTRL
                                    243 	.globl _ROM_DATA_HH
                                    244 	.globl _ROM_DATA_HL
                                    245 	.globl _ROM_DATA_HI
                                    246 	.globl _ROM_ADDR_H
                                    247 	.globl _ROM_ADDR_L
                                    248 	.globl _ROM_ADDR
                                    249 	.globl _GPIO_IE
                                    250 	.globl _IP_EX
                                    251 	.globl _IE_EX
                                    252 	.globl _IP
                                    253 	.globl _IE
                                    254 	.globl _WDOG_COUNT
                                    255 	.globl _RESET_KEEP
                                    256 	.globl _WAKE_CTRL
                                    257 	.globl _CLOCK_CFG
                                    258 	.globl _POWER_CFG
                                    259 	.globl _PCON
                                    260 	.globl _GLOBAL_CFG
                                    261 	.globl _SAFE_MOD
                                    262 	.globl _DPH
                                    263 	.globl _DPL
                                    264 	.globl _SP
                                    265 	.globl _A_INV
                                    266 	.globl _B
                                    267 	.globl _ACC
                                    268 	.globl _PSW
                                    269 	.globl _vial_unlock_in_progress
                                    270 	.globl _vial_unlocked
                                    271 	.globl _g_vial_magic_keycode_override
                                    272 	.globl _vial_handle_cmd_PARM_2
                                    273 	.globl _vial_unlock_task
                                    274 	.globl _vial_init
                                    275 	.globl _vial_handle_cmd
                                    276 	.globl _vial_keycode_down
                                    277 	.globl _vial_keycode_up
                                    278 	.globl _vial_keycode_tap
                                    279 ;--------------------------------------------------------
                                    280 ; special function registers
                                    281 ;--------------------------------------------------------
                                    282 	.area RSEG    (ABS,DATA)
      000000                        283 	.org 0x0000
                           0000D0   284 _PSW	=	0x00d0
                           0000E0   285 _ACC	=	0x00e0
                           0000F0   286 _B	=	0x00f0
                           0000FD   287 _A_INV	=	0x00fd
                           000081   288 _SP	=	0x0081
                           000082   289 _DPL	=	0x0082
                           000083   290 _DPH	=	0x0083
                           0000A1   291 _SAFE_MOD	=	0x00a1
                           0000B1   292 _GLOBAL_CFG	=	0x00b1
                           000087   293 _PCON	=	0x0087
                           0000BA   294 _POWER_CFG	=	0x00ba
                           0000B9   295 _CLOCK_CFG	=	0x00b9
                           0000A9   296 _WAKE_CTRL	=	0x00a9
                           0000FE   297 _RESET_KEEP	=	0x00fe
                           0000FF   298 _WDOG_COUNT	=	0x00ff
                           0000A8   299 _IE	=	0x00a8
                           0000B8   300 _IP	=	0x00b8
                           0000E8   301 _IE_EX	=	0x00e8
                           0000E9   302 _IP_EX	=	0x00e9
                           0000B2   303 _GPIO_IE	=	0x00b2
                           008584   304 _ROM_ADDR	=	0x8584
                           000084   305 _ROM_ADDR_L	=	0x0084
                           000085   306 _ROM_ADDR_H	=	0x0085
                           008F8E   307 _ROM_DATA_HI	=	0x8f8e
                           00008E   308 _ROM_DATA_HL	=	0x008e
                           00008F   309 _ROM_DATA_HH	=	0x008f
                           000086   310 _ROM_CTRL	=	0x0086
                           000080   311 _P0	=	0x0080
                           0000C4   312 _P0_MOD_OC	=	0x00c4
                           0000C5   313 _P0_DIR_PU	=	0x00c5
                           000090   314 _P1	=	0x0090
                           000092   315 _P1_MOD_OC	=	0x0092
                           000093   316 _P1_DIR_PU	=	0x0093
                           0000A0   317 _P2	=	0x00a0
                           000094   318 _P2_MOD_OC	=	0x0094
                           000095   319 _P2_DIR_PU	=	0x0095
                           0000B0   320 _P3	=	0x00b0
                           000096   321 _P3_MOD_OC	=	0x0096
                           000097   322 _P3_DIR_PU	=	0x0097
                           0000C0   323 _P4	=	0x00c0
                           0000C2   324 _P4_MOD_OC	=	0x00c2
                           0000C3   325 _P4_DIR_PU	=	0x00c3
                           0000C1   326 _P4_LED_KEY	=	0x00c1
                           0000AA   327 _P5_IN	=	0x00aa
                           0000AB   328 _P5_OUT_PU	=	0x00ab
                           0000AC   329 _P5_DIR	=	0x00ac
                           0000AD   330 _P6_IN	=	0x00ad
                           0000AE   331 _P6_OUT_PU	=	0x00ae
                           0000AF   332 _P6_DIR	=	0x00af
                           0000F1   333 _P7	=	0x00f1
                           0000A2   334 _XBUS_AUX	=	0x00a2
                           000088   335 _TCON	=	0x0088
                           000089   336 _TMOD	=	0x0089
                           00008A   337 _TL0	=	0x008a
                           00008B   338 _TL1	=	0x008b
                           00008C   339 _TH0	=	0x008c
                           00008D   340 _TH1	=	0x008d
                           000098   341 _SCON	=	0x0098
                           000099   342 _SBUF	=	0x0099
                           0000C8   343 _T2CON	=	0x00c8
                           0000C9   344 _T2MOD	=	0x00c9
                           00CBCA   345 _RCAP2	=	0xcbca
                           0000CA   346 _RCAP2L	=	0x00ca
                           0000CB   347 _RCAP2H	=	0x00cb
                           00CDCC   348 _T2COUNT	=	0xcdcc
                           0000CC   349 _TL2	=	0x00cc
                           0000CD   350 _TH2	=	0x00cd
                           00CFCE   351 _T2CAP1	=	0xcfce
                           0000CE   352 _T2CAP1L	=	0x00ce
                           0000CF   353 _T2CAP1H	=	0x00cf
                           0000F8   354 _SPI0_STAT	=	0x00f8
                           0000F9   355 _SPI0_DATA	=	0x00f9
                           0000FA   356 _SPI0_CTRL	=	0x00fa
                           0000FB   357 _SPI0_CK_SE	=	0x00fb
                           0000FC   358 _SPI0_SETUP	=	0x00fc
                           0000BC   359 _SCON1	=	0x00bc
                           0000BD   360 _SBUF1	=	0x00bd
                           0000BE   361 _SBAUD1	=	0x00be
                           0000BF   362 _SIF1	=	0x00bf
                           0000B4   363 _SPI1_STAT	=	0x00b4
                           0000B5   364 _SPI1_DATA	=	0x00b5
                           0000B6   365 _SPI1_CTRL	=	0x00b6
                           0000B7   366 _SPI1_CK_SE	=	0x00b7
                           0000F3   367 _ADC_CTRL	=	0x00f3
                           00F5F4   368 _ADC_DAT	=	0xf5f4
                           0000F4   369 _ADC_DAT_L	=	0x00f4
                           0000F5   370 _ADC_DAT_H	=	0x00f5
                           0000F6   371 _ADC_CHAN	=	0x00f6
                           0000A6   372 _LED_COMMON	=	0x00a6
                           0000A7   373 _LED_PWM_OE	=	0x00a7
                           00C7C6   374 _LED_DMA	=	0xc7c6
                           0000C6   375 _LED_DMA_L	=	0x00c6
                           0000C7   376 _LED_DMA_H	=	0x00c7
                           0000F7   377 _LED_STATUS	=	0x00f7
                           0000B3   378 _I2CX_INT	=	0x00b3
                           0000BB   379 _I2CS_INT_ST	=	0x00bb
                                    380 ;--------------------------------------------------------
                                    381 ; special function bits
                                    382 ;--------------------------------------------------------
                                    383 	.area RSEG    (ABS,DATA)
      000000                        384 	.org 0x0000
                           0000D7   385 _CY	=	0x00d7
                           0000D6   386 _AC	=	0x00d6
                           0000D5   387 _F0	=	0x00d5
                           0000D4   388 _RS1	=	0x00d4
                           0000D3   389 _RS0	=	0x00d3
                           0000D2   390 _OV	=	0x00d2
                           0000D1   391 _F1	=	0x00d1
                           0000D0   392 _P	=	0x00d0
                           0000AF   393 _EA	=	0x00af
                           0000AE   394 _E_DIS	=	0x00ae
                           0000AD   395 _ET2	=	0x00ad
                           0000AC   396 _ES	=	0x00ac
                           0000AB   397 _ET1	=	0x00ab
                           0000AA   398 _EX1	=	0x00aa
                           0000A9   399 _ET0	=	0x00a9
                           0000A8   400 _EX0	=	0x00a8
                           0000BF   401 _PH_FLAG	=	0x00bf
                           0000BE   402 _PL_FLAG	=	0x00be
                           0000BD   403 _PT2	=	0x00bd
                           0000BC   404 _PS	=	0x00bc
                           0000BB   405 _PT1	=	0x00bb
                           0000BA   406 _PX1	=	0x00ba
                           0000B9   407 _PT0	=	0x00b9
                           0000B8   408 _PX0	=	0x00b8
                           0000EF   409 _IE_WDOG	=	0x00ef
                           0000EE   410 _IE_GPIO	=	0x00ee
                           0000ED   411 _IE_PWM_I2C	=	0x00ed
                           0000EC   412 _IE_UART1	=	0x00ec
                           0000EB   413 _IE_ADC	=	0x00eb
                           0000E9   414 _IE_USB	=	0x00e9
                           0000E8   415 _IE_SPI0	=	0x00e8
                           000087   416 _P0_7	=	0x0087
                           000086   417 _P0_6	=	0x0086
                           000085   418 _P0_5	=	0x0085
                           000084   419 _P0_4	=	0x0084
                           000083   420 _P0_3	=	0x0083
                           000082   421 _P0_2	=	0x0082
                           000081   422 _P0_1	=	0x0081
                           000080   423 _P0_0	=	0x0080
                           000081   424 _SDA0	=	0x0081
                           000080   425 _SCL0	=	0x0080
                           000083   426 _TXD_	=	0x0083
                           000082   427 _RXD_	=	0x0082
                           000085   428 _AIN13	=	0x0085
                           000084   429 _AIN12	=	0x0084
                           000083   430 _AIN11	=	0x0083
                           000082   431 _AIN10	=	0x0082
                           000081   432 _AIN9	=	0x0081
                           000080   433 _AIN8	=	0x0080
                           000097   434 _P1_7	=	0x0097
                           000096   435 _P1_6	=	0x0096
                           000095   436 _P1_5	=	0x0095
                           000094   437 _P1_4	=	0x0094
                           000093   438 _P1_3	=	0x0093
                           000092   439 _P1_2	=	0x0092
                           000091   440 _P1_1	=	0x0091
                           000090   441 _P1_0	=	0x0090
                           000097   442 _TXD1_	=	0x0097
                           000096   443 _RXD1_	=	0x0096
                           000097   444 _SCK	=	0x0097
                           000096   445 _MISO	=	0x0096
                           000095   446 _MOSI	=	0x0095
                           000094   447 _SCS	=	0x0094
                           000092   448 _INT0_	=	0x0092
                           000091   449 _T2EX	=	0x0091
                           000091   450 _CAP2	=	0x0091
                           000090   451 _T2	=	0x0090
                           000090   452 _CAP1	=	0x0090
                           000097   453 _AIN7	=	0x0097
                           000096   454 _AIN6	=	0x0096
                           000095   455 _AIN5	=	0x0095
                           000094   456 _AIN4	=	0x0094
                           000093   457 _AIN3	=	0x0093
                           000092   458 _AIN2	=	0x0092
                           000091   459 _AIN1	=	0x0091
                           000090   460 _AIN0	=	0x0090
                           0000A7   461 _P2_7	=	0x00a7
                           0000A6   462 _P2_6	=	0x00a6
                           0000A5   463 _P2_5	=	0x00a5
                           0000A4   464 _P2_4	=	0x00a4
                           0000A3   465 _P2_3	=	0x00a3
                           0000A2   466 _P2_2	=	0x00a2
                           0000A1   467 _P2_1	=	0x00a1
                           0000A0   468 _P2_0	=	0x00a0
                           0000A7   469 _TXD1	=	0x00a7
                           0000A6   470 _RXD1	=	0x00a6
                           0000A5   471 _T2EX_	=	0x00a5
                           0000A5   472 _CAP2_	=	0x00a5
                           0000A4   473 _T2_	=	0x00a4
                           0000A4   474 _CAP1_	=	0x00a4
                           0000B7   475 _P3_7	=	0x00b7
                           0000B6   476 _P3_6	=	0x00b6
                           0000B5   477 _P3_5	=	0x00b5
                           0000B4   478 _P3_4	=	0x00b4
                           0000B3   479 _P3_3	=	0x00b3
                           0000B2   480 _P3_2	=	0x00b2
                           0000B1   481 _P3_1	=	0x00b1
                           0000B0   482 _P3_0	=	0x00b0
                           0000B7   483 _SCK1	=	0x00b7
                           0000B6   484 _MISO1	=	0x00b6
                           0000B5   485 _MOSI1	=	0x00b5
                           0000B5   486 _T1	=	0x00b5
                           0000B4   487 _T0	=	0x00b4
                           0000B3   488 _INT1	=	0x00b3
                           0000B2   489 _INT0	=	0x00b2
                           0000B1   490 _TXD	=	0x00b1
                           0000B0   491 _RXD	=	0x00b0
                           0000C6   492 _P4_6	=	0x00c6
                           0000C5   493 _P4_5	=	0x00c5
                           0000C4   494 _P4_4	=	0x00c4
                           0000C3   495 _P4_3	=	0x00c3
                           0000C2   496 _P4_2	=	0x00c2
                           0000C1   497 _P4_1	=	0x00c1
                           0000C0   498 _P4_0	=	0x00c0
                           00008F   499 _TF1	=	0x008f
                           00008E   500 _TR1	=	0x008e
                           00008D   501 _TF0	=	0x008d
                           00008C   502 _TR0	=	0x008c
                           00008B   503 _IE1	=	0x008b
                           00008A   504 _IT1	=	0x008a
                           000089   505 _IE0	=	0x0089
                           000088   506 _IT0	=	0x0088
                           00009F   507 _SM0	=	0x009f
                           00009E   508 _SM1	=	0x009e
                           00009D   509 _SM2	=	0x009d
                           00009C   510 _REN	=	0x009c
                           00009B   511 _TB8	=	0x009b
                           00009A   512 _RB8	=	0x009a
                           000099   513 _TI	=	0x0099
                           000098   514 _RI	=	0x0098
                           0000CF   515 _TF2	=	0x00cf
                           0000CF   516 _CAP1F	=	0x00cf
                           0000CE   517 _EXF2	=	0x00ce
                           0000CD   518 _RCLK	=	0x00cd
                           0000CC   519 _TCLK	=	0x00cc
                           0000CB   520 _EXEN2	=	0x00cb
                           0000CA   521 _TR2	=	0x00ca
                           0000C9   522 _C_T2	=	0x00c9
                           0000C8   523 _CP_RL2	=	0x00c8
                           0000FF   524 _S0_FST_ACT	=	0x00ff
                           0000FE   525 _S0_IF_OV	=	0x00fe
                           0000FD   526 _S0_IF_FIRST	=	0x00fd
                           0000FC   527 _S0_IF_BYTE	=	0x00fc
                           0000FB   528 _S0_FREE	=	0x00fb
                           0000FA   529 _S0_T_FIFO	=	0x00fa
                           0000F8   530 _S0_R_FIFO	=	0x00f8
                           0000F7   531 _ADC_START	=	0x00f7
                                    532 ;--------------------------------------------------------
                                    533 ; overlayable register banks
                                    534 ;--------------------------------------------------------
                                    535 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        536 	.ds 8
                                    537 ;--------------------------------------------------------
                                    538 ; internal ram data
                                    539 ;--------------------------------------------------------
                                    540 	.area DSEG    (DATA)
      000041                        541 _vial_handle_cmd_sloc0_1_0:
      000041                        542 	.ds 2
      000043                        543 _vial_handle_cmd_sloc1_1_0:
      000043                        544 	.ds 2
      000045                        545 _vial_handle_cmd_sloc2_1_0:
      000045                        546 	.ds 2
      000047                        547 _vial_handle_cmd_sloc3_1_0:
      000047                        548 	.ds 2
                                    549 ;--------------------------------------------------------
                                    550 ; overlayable items in internal ram
                                    551 ;--------------------------------------------------------
                                    552 ;--------------------------------------------------------
                                    553 ; indirectly addressable internal ram data
                                    554 ;--------------------------------------------------------
                                    555 	.area ISEG    (DATA)
                                    556 ;--------------------------------------------------------
                                    557 ; absolute internal ram data
                                    558 ;--------------------------------------------------------
                                    559 	.area IABS    (ABS,DATA)
                                    560 	.area IABS    (ABS,DATA)
                                    561 ;--------------------------------------------------------
                                    562 ; bit data
                                    563 ;--------------------------------------------------------
                                    564 	.area BSEG    (BIT)
                                    565 ;--------------------------------------------------------
                                    566 ; paged external ram data
                                    567 ;--------------------------------------------------------
                                    568 	.area PSEG    (PAG,XDATA)
                                    569 ;--------------------------------------------------------
                                    570 ; uninitialized external ram data
                                    571 ;--------------------------------------------------------
                                    572 	.area XSEG    (XDATA)
      000C2F                        573 _vial_unlock_timer:
      000C2F                        574 	.ds 4
      000C33                        575 _vial_unlock_holding:
      000C33                        576 	.ds 1
      000C34                        577 _vial_keycode_firewall_in_10000_609:
      000C34                        578 	.ds 2
      000C36                        579 _vial_fill_packet_PARM_2:
      000C36                        580 	.ds 1
      000C37                        581 _vial_fill_packet_msg_10000_612:
      000C37                        582 	.ds 2
      000C39                        583 _vial_handle_cmd_PARM_2:
      000C39                        584 	.ds 1
      000C3A                        585 _vial_handle_cmd_data_10000_617:
      000C3A                        586 	.ds 3
      000C3D                        587 _vial_handle_cmd_entry_70000_645:
      000C3D                        588 	.ds 10
      000C47                        589 _vial_handle_cmd_entry_70000_646:
      000C47                        590 	.ds 10
      000C51                        591 _g_vial_magic_keycode_override::
      000C51                        592 	.ds 2
      000C53                        593 _vial_keycode_down_keycode_10000_648:
      000C53                        594 	.ds 2
      000C55                        595 _vial_keycode_down_dummy_event_30000_655:
      000C55                        596 	.ds 6
      000C5B                        597 _vial_keycode_up_keycode_10000_656:
      000C5B                        598 	.ds 2
      000C5D                        599 _vial_keycode_up_dummy_event_30000_663:
      000C5D                        600 	.ds 6
      000C63                        601 _vial_keycode_tap_keycode_10000_664:
      000C63                        602 	.ds 2
                                    603 ;--------------------------------------------------------
                                    604 ; absolute external ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area XABS    (ABS,XDATA)
                                    607 ;--------------------------------------------------------
                                    608 ; initialized external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area XISEG   (XDATA)
      000DF9                        611 _vial_unlocked::
      000DF9                        612 	.ds 1
      000DFA                        613 _vial_unlock_in_progress::
      000DFA                        614 	.ds 1
      000DFB                        615 _vial_unlock_counter:
      000DFB                        616 	.ds 1
      000DFC                        617 _vial_unlock_combo_rows:
      000DFC                        618 	.ds 2
      000DFE                        619 _vial_unlock_combo_cols:
      000DFE                        620 	.ds 2
                                    621 	.area HOME    (CODE)
                                    622 	.area GSINIT0 (CODE)
                                    623 	.area GSINIT1 (CODE)
                                    624 	.area GSINIT2 (CODE)
                                    625 	.area GSINIT3 (CODE)
                                    626 	.area GSINIT4 (CODE)
                                    627 	.area GSINIT5 (CODE)
                                    628 	.area GSINIT  (CODE)
                                    629 	.area GSFINAL (CODE)
                                    630 	.area CSEG    (CODE)
                                    631 ;--------------------------------------------------------
                                    632 ; global & static initialisations
                                    633 ;--------------------------------------------------------
                                    634 	.area HOME    (CODE)
                                    635 	.area GSINIT  (CODE)
                                    636 	.area GSFINAL (CODE)
                                    637 	.area GSINIT  (CODE)
                                    638 ;--------------------------------------------------------
                                    639 ; Home
                                    640 ;--------------------------------------------------------
                                    641 	.area HOME    (CODE)
                                    642 	.area HOME    (CODE)
                                    643 ;--------------------------------------------------------
                                    644 ; code
                                    645 ;--------------------------------------------------------
                                    646 	.area CSEG    (CODE)
                                    647 ;------------------------------------------------------------
                                    648 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    649 ;------------------------------------------------------------
                                    650 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_176'
                                    651 ;------------------------------------------------------------
                                    652 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    653 ;	-----------------------------------------
                           000007   654 	ar7 = 0x07
                           000006   655 	ar6 = 0x06
                           000005   656 	ar5 = 0x05
                           000004   657 	ar4 = 0x04
                           000003   658 	ar3 = 0x03
                           000002   659 	ar2 = 0x02
                           000001   660 	ar1 = 0x01
                           000000   661 	ar0 = 0x00
                                    662 ;	 function vial_unlock_task
                                    663 ;	-----------------------------------------
      00AB88                        664 _vial_unlock_task:
                                    665 ;	quantum/vial.c:64: if (!vial_unlock_in_progress) return;
      00AB88 90 0D FA         [24]  666 	mov	dptr,#_vial_unlock_in_progress
      00AB8B E0               [24]  667 	movx	a,@dptr
      00AB8C 70 01            [24]  668 	jnz	00131$
      00AB8E 22               [24]  669 	ret
                                    670 ;	quantum/vial.c:65: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00AB8F                        671 00131$:
      00AB8F 7F 00            [12]  672 	mov	r7,#0x00
      00AB91                        673 00115$:
      00AB91 BF 02 00         [24]  674 	cjne	r7,#0x02,00184$
      00AB94                        675 00184$:
      00AB94 50 29            [24]  676 	jnc	00105$
                                    677 ;	quantum/vial.c:66: if (!matrix_is_on(vial_unlock_combo_rows[i], vial_unlock_combo_cols[i])) {
      00AB96 EF               [12]  678 	mov	a,r7
      00AB97 12 B1 4C         [24]  679 	lcall	_ak820_outline_0126
      00AB9A FE               [12]  680 	mov	r6,a
      00AB9B EF               [12]  681 	mov	a,r7
      00AB9C 12 B1 41         [24]  682 	lcall	_ak820_outline_0125
      00AB9F 90 07 63         [24]  683 	mov	dptr,#_matrix_is_on_PARM_2
      00ABA2 F0               [24]  684 	movx	@dptr,a
      00ABA3 8E 82            [24]  685 	mov	dpl, r6
      00ABA5 C0 07            [24]  686 	push	ar7
      00ABA7 12 59 BB         [24]  687 	lcall	_matrix_is_on
      00ABAA E5 82            [12]  688 	mov	a, dpl
      00ABAC D0 07            [24]  689 	pop	ar7
      00ABAE 70 0C            [24]  690 	jnz	00116$
                                    691 ;	quantum/vial.c:67: vial_unlock_holding = false;
      00ABB0 90 0C 33         [24]  692 	mov	dptr,#_vial_unlock_holding
      00ABB3 E4               [12]  693 	clr	a
      00ABB4 F0               [24]  694 	movx	@dptr,a
                                    695 ;	quantum/vial.c:68: vial_unlock_counter = VIAL_UNLOCK_COUNTER_MAX;
      00ABB5 90 0D FB         [24]  696 	mov	dptr,#_vial_unlock_counter
      00ABB8 74 1E            [12]  697 	mov	a,#0x1e
      00ABBA F0               [24]  698 	movx	@dptr,a
                                    699 ;	quantum/vial.c:69: return;
      00ABBB 22               [24]  700 	ret
      00ABBC                        701 00116$:
                                    702 ;	quantum/vial.c:65: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00ABBC 0F               [12]  703 	inc	r7
      00ABBD 80 D2            [24]  704 	sjmp	00115$
      00ABBF                        705 00105$:
                                    706 ;	quantum/vial.c:72: if (!vial_unlock_holding) {
      00ABBF 90 0C 33         [24]  707 	mov	dptr,#_vial_unlock_holding
      00ABC2 E0               [24]  708 	movx	a,@dptr
      00ABC3 70 12            [24]  709 	jnz	00107$
                                    710 ;	quantum/vial.c:73: vial_unlock_holding = true;
      00ABC5 90 0C 33         [24]  711 	mov	dptr,#_vial_unlock_holding
      00ABC8 74 01            [12]  712 	mov	a,#0x01
      00ABCA F0               [24]  713 	movx	@dptr,a
                                    714 ;	quantum/vial.c:74: vial_unlock_timer = timer_read32();
      00ABCB 12 49 C5         [24]  715 	lcall	_timer_read32
      00ABCE 12 4F D5         [24]  716 	lcall	_ak820_outline_0057
      00ABD1 90 0C 2F         [24]  717 	mov	dptr,#_vial_unlock_timer
      00ABD4 12 90 86         [24]  718 	lcall	_ak820_outline_0007
      00ABD7                        719 00107$:
                                    720 ;	quantum/vial.c:76: uint32_t elapsed = timer_elapsed32(vial_unlock_timer);
      00ABD7 90 0C 2F         [24]  721 	mov	dptr,#_vial_unlock_timer
      00ABDA 12 4F C4         [24]  722 	lcall	_ak820_outline_0054
      00ABDD 12 4A 1E         [24]  723 	lcall	_timer_elapsed32
      00ABE0 12 4F D5         [24]  724 	lcall	_ak820_outline_0057
                                    725 ;	quantum/vial.c:80: while (counter && elapsed >= VIAL_UNLOCK_COUNTER_TICK_MS) {
      00ABE3 7B 1E            [12]  726 	mov	r3,#0x1e
      00ABE5                        727 00109$:
      00ABE5 EB               [12]  728 	mov	a,r3
      00ABE6 60 22            [24]  729 	jz	00111$
      00ABE8 C3               [12]  730 	clr	c
      00ABE9 EC               [12]  731 	mov	a,r4
      00ABEA 94 64            [12]  732 	subb	a,#0x64
      00ABEC ED               [12]  733 	mov	a,r5
      00ABED 94 00            [12]  734 	subb	a,#0x00
      00ABEF EE               [12]  735 	mov	a,r6
      00ABF0 94 00            [12]  736 	subb	a,#0x00
      00ABF2 EF               [12]  737 	mov	a,r7
      00ABF3 94 00            [12]  738 	subb	a,#0x00
      00ABF5 40 13            [24]  739 	jc	00111$
                                    740 ;	quantum/vial.c:81: elapsed -= VIAL_UNLOCK_COUNTER_TICK_MS;
      00ABF7 EC               [12]  741 	mov	a,r4
      00ABF8 24 9C            [12]  742 	add	a,#0x9c
      00ABFA FC               [12]  743 	mov	r4,a
      00ABFB ED               [12]  744 	mov	a,r5
      00ABFC 34 FF            [12]  745 	addc	a,#0xff
      00ABFE FD               [12]  746 	mov	r5,a
      00ABFF EE               [12]  747 	mov	a,r6
      00AC00 34 FF            [12]  748 	addc	a,#0xff
      00AC02 FE               [12]  749 	mov	r6,a
      00AC03 EF               [12]  750 	mov	a,r7
      00AC04 34 FF            [12]  751 	addc	a,#0xff
      00AC06 FF               [12]  752 	mov	r7,a
                                    753 ;	quantum/vial.c:82: --counter;
      00AC07 1B               [12]  754 	dec	r3
      00AC08 80 DB            [24]  755 	sjmp	00109$
      00AC0A                        756 00111$:
                                    757 ;	quantum/vial.c:84: vial_unlock_counter = counter;
      00AC0A 90 0D FB         [24]  758 	mov	dptr,#_vial_unlock_counter
      00AC0D EB               [12]  759 	mov	a,r3
      00AC0E F0               [24]  760 	movx	@dptr,a
                                    761 ;	quantum/vial.c:85: if (!counter) {
      00AC0F EB               [12]  762 	mov	a,r3
      00AC10 70 0A            [24]  763 	jnz	00117$
                                    764 ;	quantum/vial.c:86: vial_unlock_in_progress = 0;
      00AC12 90 0D FA         [24]  765 	mov	dptr,#_vial_unlock_in_progress
      00AC15 E4               [12]  766 	clr	a
      00AC16 F0               [24]  767 	movx	@dptr,a
                                    768 ;	quantum/vial.c:87: vial_unlocked = 1;
      00AC17 90 0D F9         [24]  769 	mov	dptr,#_vial_unlocked
      00AC1A 04               [12]  770 	inc	a
      00AC1B F0               [24]  771 	movx	@dptr,a
      00AC1C                        772 00117$:
                                    773 ;	quantum/vial.c:90: }
      00AC1C 22               [24]  774 	ret
                                    775 ;------------------------------------------------------------
                                    776 ;Allocation info for local variables in function 'vial_init'
                                    777 ;------------------------------------------------------------
                                    778 ;	quantum/vial.c:117: void vial_init(void) {
                                    779 ;	-----------------------------------------
                                    780 ;	 function vial_init
                                    781 ;	-----------------------------------------
      00AC1D                        782 _vial_init:
                                    783 ;	quantum/vial.c:125: reload_combo();
                                    784 ;	quantum/vial.c:130: }
      00AC1D 02 35 37         [24]  785 	ljmp	_ak820_combo_reload
                                    786 ;------------------------------------------------------------
                                    787 ;Allocation info for local variables in function 'vial_keycode_firewall'
                                    788 ;------------------------------------------------------------
                                    789 ;in            Allocated with name '_vial_keycode_firewall_in_10000_609'
                                    790 ;------------------------------------------------------------
                                    791 ;	quantum/vial.c:132: __attribute__((unused)) static uint16_t vial_keycode_firewall(uint16_t in) {
                                    792 ;	-----------------------------------------
                                    793 ;	 function vial_keycode_firewall
                                    794 ;	-----------------------------------------
      00AC20                        795 _vial_keycode_firewall:
      00AC20 12 38 3B         [24]  796 	lcall	_ak820_outline_0103
      00AC23 90 0C 34         [24]  797 	mov	dptr,#_vial_keycode_firewall_in_10000_609
      00AC26 12 38 40         [24]  798 	lcall	_ak820_outline_0104
                                    799 ;	quantum/vial.c:133: if (in == QK_BOOT && !vial_unlocked)
      00AC29 90 0C 34         [24]  800 	mov	dptr,#_vial_keycode_firewall_in_10000_609
      00AC2C 12 37 C3         [24]  801 	lcall	_ak820_outline_0010
      00AC2F BC 00 0D         [24]  802 	cjne	r4,#0x00,00102$
      00AC32 BD 7C 0A         [24]  803 	cjne	r5,#0x7c,00102$
      00AC35 90 0D F9         [24]  804 	mov	dptr,#_vial_unlocked
      00AC38 E0               [24]  805 	movx	a,@dptr
      00AC39 70 04            [24]  806 	jnz	00102$
                                    807 ;	quantum/vial.c:134: return 0;
      00AC3B 90 00 00         [24]  808 	mov	dptr,#0x0000
      00AC3E 22               [24]  809 	ret
      00AC3F                        810 00102$:
                                    811 ;	quantum/vial.c:135: return in;
      00AC3F 12 43 80         [24]  812 	lcall	_ak820_outline_0116
                                    813 ;	quantum/vial.c:136: }
      00AC42 22               [24]  814 	ret
                                    815 ;------------------------------------------------------------
                                    816 ;Allocation info for local variables in function 'vial_fill_packet'
                                    817 ;------------------------------------------------------------
                                    818 ;value         Allocated with name '_vial_fill_packet_PARM_2'
                                    819 ;msg           Allocated with name '_vial_fill_packet_msg_10000_612'
                                    820 ;i             Allocated with name '_vial_fill_packet_i_20000_614'
                                    821 ;------------------------------------------------------------
                                    822 ;	quantum/vial.c:139: static void vial_fill_packet(uint8_t __xdata *msg, uint8_t value) {
                                    823 ;	-----------------------------------------
                                    824 ;	 function vial_fill_packet
                                    825 ;	-----------------------------------------
      00AC43                        826 _vial_fill_packet:
      00AC43 12 38 3B         [24]  827 	lcall	_ak820_outline_0103
      00AC46 90 0C 37         [24]  828 	mov	dptr,#_vial_fill_packet_msg_10000_612
      00AC49 12 38 40         [24]  829 	lcall	_ak820_outline_0104
                                    830 ;	quantum/vial.c:140: for (uint8_t i = 0; i < VIAL_RAW_EPSIZE; ++i) msg[i] = value;
      00AC4C 90 0C 37         [24]  831 	mov	dptr,#_vial_fill_packet_msg_10000_612
      00AC4F 12 37 F8         [24]  832 	lcall	_ak820_outline_0051
      00AC52 90 0C 36         [24]  833 	mov	dptr,#_vial_fill_packet_PARM_2
      00AC55 E0               [24]  834 	movx	a,@dptr
      00AC56 FD               [12]  835 	mov	r5,a
      00AC57 7C 00            [12]  836 	mov	r4,#0x00
      00AC59                        837 00103$:
      00AC59 BC 20 00         [24]  838 	cjne	r4,#0x20,00122$
      00AC5C                        839 00122$:
      00AC5C 50 09            [24]  840 	jnc	00105$
      00AC5E EC               [12]  841 	mov	a,r4
      00AC5F 12 37 E8         [24]  842 	lcall	_ak820_outline_0031
      00AC62 ED               [12]  843 	mov	a,r5
      00AC63 F0               [24]  844 	movx	@dptr,a
      00AC64 0C               [12]  845 	inc	r4
      00AC65 80 F2            [24]  846 	sjmp	00103$
      00AC67                        847 00105$:
                                    848 ;	quantum/vial.c:141: }
      00AC67 22               [24]  849 	ret
                                    850 ;------------------------------------------------------------
                                    851 ;Allocation info for local variables in function 'vial_release_held_state'
                                    852 ;------------------------------------------------------------
                                    853 ;	quantum/vial.c:152: static void vial_release_held_state(void) {
                                    854 ;	-----------------------------------------
                                    855 ;	 function vial_release_held_state
                                    856 ;	-----------------------------------------
      00AC68                        857 _vial_release_held_state:
                                    858 ;	quantum/vial.c:174: repeat_key_cancel();
      00AC68 12 A0 87         [24]  859 	lcall	_repeat_key_cancel
                                    860 ;	quantum/vial.c:176: clear_keyboard();
                                    861 ;	quantum/vial.c:177: }
      00AC6B 02 77 77         [24]  862 	ljmp	_clear_keyboard
                                    863 ;------------------------------------------------------------
                                    864 ;Allocation info for local variables in function 'vial_handle_cmd'
                                    865 ;------------------------------------------------------------
                                    866 ;sloc0         Allocated with name '_vial_handle_cmd_sloc0_1_0'
                                    867 ;sloc1         Allocated with name '_vial_handle_cmd_sloc1_1_0'
                                    868 ;sloc2         Allocated with name '_vial_handle_cmd_sloc2_1_0'
                                    869 ;sloc3         Allocated with name '_vial_handle_cmd_sloc3_1_0'
                                    870 ;length        Allocated with name '_vial_handle_cmd_PARM_2'
                                    871 ;data          Allocated with name '_vial_handle_cmd_data_10000_617'
                                    872 ;msg           Allocated with name '_vial_handle_cmd_msg_10000_618'
                                    873 ;i             Allocated with name '_vial_handle_cmd_i_50000_623'
                                    874 ;sz            Allocated with name '_vial_handle_cmd_sz_40000_624'
                                    875 ;page          Allocated with name '_vial_handle_cmd_page_40001_627'
                                    876 ;start         Allocated with name '_vial_handle_cmd_start_40002_629'
                                    877 ;remaining     Allocated with name '_vial_handle_cmd_remaining_40002_629'
                                    878 ;count         Allocated with name '_vial_handle_cmd_count_40002_629'
                                    879 ;i             Allocated with name '_vial_handle_cmd_i_50002_630'
                                    880 ;layer         Allocated with name '_vial_handle_cmd_layer_40000_631'
                                    881 ;idx           Allocated with name '_vial_handle_cmd_idx_40000_631'
                                    882 ;keycode       Allocated with name '_vial_handle_cmd_keycode_40000_631'
                                    883 ;i             Allocated with name '_vial_handle_cmd_i_50000_634'
                                    884 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_645'
                                    885 ;entry         Allocated with name '_vial_handle_cmd_entry_70000_645'
                                    886 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_646'
                                    887 ;entry         Allocated with name '_vial_handle_cmd_entry_70000_646'
                                    888 ;------------------------------------------------------------
                                    889 ;	quantum/vial.c:180: void vial_handle_cmd(uint8_t *data, uint8_t length) {
                                    890 ;	-----------------------------------------
                                    891 ;	 function vial_handle_cmd
                                    892 ;	-----------------------------------------
      00AC6E                        893 _vial_handle_cmd:
      00AC6E 12 43 37         [24]  894 	lcall	_ak820_outline_0037
      00AC71 90 0C 3A         [24]  895 	mov	dptr,#_vial_handle_cmd_data_10000_617
      00AC74 12 37 D7         [24]  896 	lcall	_ak820_outline_0016
                                    897 ;	quantum/vial.c:184: uint8_t __xdata *msg = (uint8_t __xdata *)data;
      00AC77 90 0C 3A         [24]  898 	mov	dptr,#_vial_handle_cmd_data_10000_617
      00AC7A 12 37 F8         [24]  899 	lcall	_ak820_outline_0051
                                    900 ;	quantum/vial.c:189: if (length != VIAL_RAW_EPSIZE)
      00AC7D 90 0C 39         [24]  901 	mov	dptr,#_vial_handle_cmd_PARM_2
      00AC80 E0               [24]  902 	movx	a,@dptr
      00AC81 FD               [12]  903 	mov	r5,a
      00AC82 BD 20 02         [24]  904 	cjne	r5,#0x20,00258$
      00AC85 80 01            [24]  905 	sjmp	00102$
      00AC87                        906 00258$:
                                    907 ;	quantum/vial.c:190: return;
      00AC87 22               [24]  908 	ret
      00AC88                        909 00102$:
                                    910 ;	quantum/vial.c:193: switch (msg[1]) {
      00AC88 74 01            [12]  911 	mov	a,#0x01
      00AC8A 12 49 04         [24]  912 	lcall	_ak820_outline_0012
      00AC8D FB               [12]  913 	mov  r3,a
      00AC8E 24 F2            [12]  914 	add	a,#0xff - 0x0d
      00AC90 50 01            [24]  915 	jnc	00259$
      00AC92 22               [24]  916 	ret
      00AC93                        917 00259$:
                                    918 ;	free result
      00AC93 EB               [12]  919 	mov	a,r3
      00AC94 24 0A            [12]  920 	add	a,#(00260$-3-.)
      00AC96 83               [24]  921 	movc	a,@a+pc
      00AC97 F5 82            [12]  922 	mov	dpl,a
      00AC99 EB               [12]  923 	mov	a,r3
      00AC9A 24 12            [12]  924 	add	a,#(00261$-3-.)
      00AC9C 83               [24]  925 	movc	a,@a+pc
      00AC9D F5 83            [12]  926 	mov	dph,a
      00AC9F E4               [12]  927 	clr	a
      00ACA0 73               [24]  928 	jmp	@a+dptr
      00ACA1                        929 00260$:
      00ACA1 BD                     930 	.db	00103$
      00ACA2 05                     931 	.db	00105$
      00ACA3 1A                     932 	.db	00106$
      00ACA4 A6                     933 	.db	00112$
      00ACA5 2C                     934 	.db	00113$
      00ACA6 77                     935 	.db	00114$
      00ACA7 E6                     936 	.db	00116$
      00ACA8 01                     937 	.db	00119$
      00ACA9 21                     938 	.db	00120$
      00ACAA 2F                     939 	.db	00121$
      00ACAB 2F                     940 	.db	00139$
      00ACAC 2F                     941 	.db	00139$
      00ACAD 2F                     942 	.db	00139$
      00ACAE 3A                     943 	.db	00122$
      00ACAF                        944 00261$:
      00ACAF AC                     945 	.db	00103$>>8
      00ACB0 AD                     946 	.db	00105$>>8
      00ACB1 AD                     947 	.db	00106$>>8
      00ACB2 AD                     948 	.db	00112$>>8
      00ACB3 AE                     949 	.db	00113$>>8
      00ACB4 AE                     950 	.db	00114$>>8
      00ACB5 AE                     951 	.db	00116$>>8
      00ACB6 AF                     952 	.db	00119$>>8
      00ACB7 AF                     953 	.db	00120$>>8
      00ACB8 AF                     954 	.db	00121$>>8
      00ACB9 B0                     955 	.db	00139$>>8
      00ACBA B0                     956 	.db	00139$>>8
      00ACBB B0                     957 	.db	00139$>>8
      00ACBC AF                     958 	.db	00122$>>8
                                    959 ;	quantum/vial.c:195: case vial_get_keyboard_id: {
      00ACBD                        960 00103$:
                                    961 ;	quantum/vial.c:198: VIAL_FILL_PACKET(msg, 0, length);
      00ACBD 90 0C 36         [24]  962 	mov	dptr,#_vial_fill_packet_PARM_2
      00ACC0 E4               [12]  963 	clr	a
      00ACC1 12 43 5B         [24]  964 	lcall	_ak820_outline_0061
      00ACC4 C0 07            [24]  965 	push	ar7
      00ACC6 C0 06            [24]  966 	push	ar6
      00ACC8 12 AC 43         [24]  967 	lcall	_vial_fill_packet
      00ACCB D0 06            [24]  968 	pop	ar6
      00ACCD D0 07            [24]  969 	pop	ar7
                                    970 ;	quantum/vial.c:199: msg[0] = VIAL_PROTOCOL_VERSION & 0xFF;
      00ACCF 12 43 80         [24]  971 	lcall	_ak820_outline_0116
      00ACD2 74 06            [12]  972 	mov	a,#0x06
      00ACD4 12 43 5B         [24]  973 	lcall	_ak820_outline_0061
                                    974 ;	quantum/vial.c:200: msg[1] = (VIAL_PROTOCOL_VERSION >> 8) & 0xFF;
      00ACD7 A3               [24]  975 	inc	dptr
      00ACD8 E4               [12]  976 	clr	a
      00ACD9 12 43 2F         [24]  977 	lcall	_ak820_outline_0030
                                    978 ;	quantum/vial.c:201: msg[2] = (VIAL_PROTOCOL_VERSION >> 16) & 0xFF;
      00ACDC 12 43 2F         [24]  979 	lcall	_ak820_outline_0030
                                    980 ;	quantum/vial.c:202: msg[3] = (VIAL_PROTOCOL_VERSION >> 24) & 0xFF;
      00ACDF A3               [24]  981 	inc	dptr
      00ACE0 F0               [24]  982 	movx	@dptr,a
                                    983 ;	quantum/vial.c:203: for (uint8_t i = 0; i < 8; ++i) msg[4 + i] = pgm_read_byte(&keyboard_uid[i]);
      00ACE1 FB               [12]  984 	mov	r3,a
      00ACE2                        985 00131$:
      00ACE2 BB 08 00         [24]  986 	cjne	r3,#0x08,00262$
      00ACE5                        987 00262$:
      00ACE5 50 15            [24]  988 	jnc	00104$
      00ACE7 8B 02            [24]  989 	mov	ar2,r3
      00ACE9 74 04            [12]  990 	mov	a,#0x04
      00ACEB 2A               [12]  991 	add	a, r2
      00ACEC 2E               [12]  992 	add	a, r6
      00ACED F9               [12]  993 	mov	r1,a
      00ACEE E4               [12]  994 	clr	a
      00ACEF 3F               [12]  995 	addc	a,r7
      00ACF0 FA               [12]  996 	mov	r2,a
      00ACF1 EB               [12]  997 	mov	a,r3
      00ACF2 90 BD EB         [24]  998 	mov	dptr,#_vial_handle_cmd_keyboard_uid_40000_622
      00ACF5 93               [24]  999 	movc	a,@a+dptr
      00ACF6 12 6D 97         [24] 1000 	lcall	_ak820_outline_0136
      00ACF9 0B               [12] 1001 	inc	r3
      00ACFA 80 E6            [24] 1002 	sjmp	00131$
      00ACFC                       1003 00104$:
                                   1004 ;	quantum/vial.c:205: msg[12] = 1; /* bit flag to indicate vialrgb is supported - so third-party apps don't have to query json */
      00ACFC 74 0C            [12] 1005 	mov	a,#0x0c
      00ACFE 12 37 E8         [24] 1006 	lcall	_ak820_outline_0031
      00AD01 74 01            [12] 1007 	mov	a,#0x01
      00AD03 F0               [24] 1008 	movx	@dptr,a
                                   1009 ;	quantum/vial.c:207: break;
      00AD04 22               [24] 1010 	ret
                                   1011 ;	quantum/vial.c:210: case vial_get_size: {
      00AD05                       1012 00105$:
                                   1013 ;	quantum/vial.c:212: msg[0] = sz & 0xFF;
      00AD05 12 43 80         [24] 1014 	lcall	_ak820_outline_0116
      00AD08 74 7C            [12] 1015 	mov	a,#0x7c
      00AD0A F0               [24] 1016 	movx	@dptr,a
                                   1017 ;	quantum/vial.c:213: msg[1] = (sz >> 8) & 0xFF;
      00AD0B 12 38 4C         [24] 1018 	lcall	_ak820_outline_0117
      00AD0E 74 01            [12] 1019 	mov	a,#0x01
      00AD10 12 43 2F         [24] 1020 	lcall	_ak820_outline_0030
                                   1021 ;	quantum/vial.c:214: msg[2] = (sz >> 16) & 0xFF;
      00AD13 E4               [12] 1022 	clr	a
      00AD14 12 43 2F         [24] 1023 	lcall	_ak820_outline_0030
                                   1024 ;	quantum/vial.c:215: msg[3] = (sz >> 24) & 0xFF;
      00AD17 A3               [24] 1025 	inc	dptr
      00AD18 F0               [24] 1026 	movx	@dptr,a
                                   1027 ;	quantum/vial.c:216: break;
      00AD19 22               [24] 1028 	ret
                                   1029 ;	quantum/vial.c:219: case vial_get_def: {
      00AD1A                       1030 00106$:
                                   1031 ;	quantum/vial.c:226: if (msg[4] | msg[5]) return;
      00AD1A 12 AB 4C         [24] 1032 	lcall	_ak820_outline_0021
      00AD1D E0               [24] 1033 	movx	a,@dptr
      00AD1E FB               [12] 1034 	mov	r3,a
      00AD1F 12 43 25         [24] 1035 	lcall	_ak820_outline_0011
      00AD22 E0               [24] 1036 	movx	a,@dptr
      00AD23 4B               [12] 1037 	orl	a,r3
      00AD24 60 01            [24] 1038 	jz	00108$
      00AD26 22               [24] 1039 	ret
      00AD27                       1040 00108$:
                                   1041 ;	quantum/vial.c:227: uint16_t page = (uint16_t)msg[2] | ((uint16_t)msg[3] << 8);
      00AD27 12 37 F0         [24] 1042 	lcall	_ak820_outline_0034
      00AD2A FB               [12] 1043 	mov	r3,a
      00AD2B 7A 00            [12] 1044 	mov	r2,#0x00
      00AD2D 12 AB 43         [24] 1045 	lcall	_ak820_outline_0015
      00AD30 F9               [12] 1046 	mov	r1,a
      00AD31 E4               [12] 1047 	clr	a
      00AD32 42 03            [12] 1048 	orl	ar3,a
      00AD34 E9               [12] 1049 	mov	a,r1
      00AD35 42 02            [12] 1050 	orl	ar2,a
                                   1051 ;	quantum/vial.c:228: if (page >= (sizeof(keyboard_definition) + VIAL_RAW_EPSIZE - 1) / VIAL_RAW_EPSIZE) return;
      00AD37 C3               [12] 1052 	clr	c
      00AD38 EB               [12] 1053 	mov	a,r3
      00AD39 94 0C            [12] 1054 	subb	a,#0x0c
      00AD3B EA               [12] 1055 	mov	a,r2
      00AD3C 94 00            [12] 1056 	subb	a,#0x00
      00AD3E 40 01            [24] 1057 	jc	00110$
      00AD40 22               [24] 1058 	ret
      00AD41                       1059 00110$:
                                   1060 ;	quantum/vial.c:229: uint16_t start = page * VIAL_RAW_EPSIZE;
      00AD41 EA               [12] 1061 	mov	a,r2
      00AD42 C4               [12] 1062 	swap	a
      00AD43 23               [12] 1063 	rl	a
      00AD44 54 E0            [12] 1064 	anl	a,#0xe0
      00AD46 CB               [12] 1065 	xch	a,r3
      00AD47 C4               [12] 1066 	swap	a
      00AD48 23               [12] 1067 	rl	a
      00AD49 CB               [12] 1068 	xch	a,r3
      00AD4A 6B               [12] 1069 	xrl	a,r3
      00AD4B CB               [12] 1070 	xch	a,r3
      00AD4C 54 E0            [12] 1071 	anl	a,#0xe0
      00AD4E CB               [12] 1072 	xch	a,r3
      00AD4F 6B               [12] 1073 	xrl	a,r3
      00AD50 FA               [12] 1074 	mov	r2,a
      00AD51 8B 41            [24] 1075 	mov	_vial_handle_cmd_sloc0_1_0,r3
      00AD53 8A 42            [24] 1076 	mov	(_vial_handle_cmd_sloc0_1_0 + 1),r2
                                   1077 ;	quantum/vial.c:230: uint16_t remaining = sizeof(keyboard_definition) - start;
      00AD55 74 7C            [12] 1078 	mov	a,#0x7c
      00AD57 C3               [12] 1079 	clr	c
      00AD58 95 41            [12] 1080 	subb	a,_vial_handle_cmd_sloc0_1_0
      00AD5A F8               [12] 1081 	mov	r0,a
      00AD5B 74 01            [12] 1082 	mov	a,#0x01
      00AD5D 95 42            [12] 1083 	subb	a,(_vial_handle_cmd_sloc0_1_0 + 1)
      00AD5F F9               [12] 1084 	mov	r1,a
                                   1085 ;	quantum/vial.c:231: uint8_t count = remaining < VIAL_RAW_EPSIZE ? remaining : VIAL_RAW_EPSIZE;
      00AD60 C3               [12] 1086 	clr	c
      00AD61 E8               [12] 1087 	mov	a,r0
      00AD62 94 20            [12] 1088 	subb	a,#0x20
      00AD64 E9               [12] 1089 	mov	a,r1
      00AD65 94 00            [12] 1090 	subb	a,#0x00
      00AD67 40 02            [24] 1091 	jc	00142$
      00AD69 78 20            [12] 1092 	mov	r0,#0x20
      00AD6B                       1093 00142$:
                                   1094 ;	quantum/vial.c:232: for (uint8_t i = 0; i < count; ++i) msg[i] = pgm_read_byte(&keyboard_definition[start + i]);
      00AD6B 79 00            [12] 1095 	mov	r1,#0x00
      00AD6D                       1096 00134$:
      00AD6D C3               [12] 1097 	clr	c
      00AD6E E9               [12] 1098 	mov	a,r1
      00AD6F 98               [12] 1099 	subb	a,r0
      00AD70 40 01            [24] 1100 	jc	00267$
      00AD72 22               [24] 1101 	ret
      00AD73                       1102 00267$:
      00AD73 C0 00            [24] 1103 	push	ar0
      00AD75 E9               [12] 1104 	mov	a,r1
      00AD76 2E               [12] 1105 	add	a, r6
      00AD77 F5 43            [12] 1106 	mov	_vial_handle_cmd_sloc1_1_0,a
      00AD79 E4               [12] 1107 	clr	a
      00AD7A 3F               [12] 1108 	addc	a, r7
      00AD7B F5 44            [12] 1109 	mov	(_vial_handle_cmd_sloc1_1_0 + 1),a
      00AD7D 89 45            [24] 1110 	mov	_vial_handle_cmd_sloc2_1_0,r1
      00AD7F 75 46 00         [24] 1111 	mov	(_vial_handle_cmd_sloc2_1_0 + 1),#0x00
      00AD82 A8 41            [24] 1112 	mov	r0,_vial_handle_cmd_sloc0_1_0
      00AD84 AB 42            [24] 1113 	mov	r3,(_vial_handle_cmd_sloc0_1_0 + 1)
      00AD86 E5 45            [12] 1114 	mov	a,_vial_handle_cmd_sloc2_1_0
      00AD88 28               [12] 1115 	add	a, r0
      00AD89 F8               [12] 1116 	mov	r0,a
      00AD8A E5 46            [12] 1117 	mov	a,(_vial_handle_cmd_sloc2_1_0 + 1)
      00AD8C 3B               [12] 1118 	addc	a, r3
      00AD8D FB               [12] 1119 	mov	r3,a
      00AD8E E8               [12] 1120 	mov	a,r0
      00AD8F 24 6F            [12] 1121 	add	a, #_keyboard_definition
      00AD91 F5 82            [12] 1122 	mov	dpl,a
      00AD93 EB               [12] 1123 	mov	a,r3
      00AD94 34 BC            [12] 1124 	addc	a, #(_keyboard_definition >> 8)
      00AD96 F5 83            [12] 1125 	mov	dph,a
      00AD98 E4               [12] 1126 	clr	a
      00AD99 93               [24] 1127 	movc	a,@a+dptr
      00AD9A 85 43 82         [24] 1128 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00AD9D 85 44 83         [24] 1129 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00ADA0 F0               [24] 1130 	movx	@dptr,a
      00ADA1 09               [12] 1131 	inc	r1
      00ADA2 D0 00            [24] 1132 	pop	ar0
                                   1133 ;	quantum/vial.c:246: case vial_get_encoder: {
      00ADA4 80 C7            [24] 1134 	sjmp	00134$
      00ADA6                       1135 00112$:
                                   1136 ;	quantum/vial.c:247: uint8_t layer = msg[2];
      00ADA6 74 02            [12] 1137 	mov	a,#0x02
      00ADA8 12 49 43         [24] 1138 	lcall	_ak820_outline_0046
      00ADAB F5 45            [12] 1139 	mov	_vial_handle_cmd_sloc2_1_0,a
                                   1140 ;	quantum/vial.c:248: uint8_t idx = msg[3];
      00ADAD 74 03            [12] 1141 	mov	a,#0x03
      00ADAF 2E               [12] 1142 	add	a, r6
      00ADB0 F5 43            [12] 1143 	mov	_vial_handle_cmd_sloc1_1_0,a
      00ADB2 E4               [12] 1144 	clr	a
      00ADB3 3F               [12] 1145 	addc	a, r7
      00ADB4 F5 44            [12] 1146 	mov	(_vial_handle_cmd_sloc1_1_0 + 1),a
      00ADB6 85 43 82         [24] 1147 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00ADB9 85 44 83         [24] 1148 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00ADBC E0               [24] 1149 	movx	a,@dptr
                                   1150 ;	quantum/vial.c:249: uint16_t keycode = dynamic_keymap_get_encoder(layer, idx, 0);
      00ADBD F5 41            [12] 1151 	mov	_vial_handle_cmd_sloc0_1_0,a
      00ADBF 90 0A E4         [24] 1152 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      00ADC2 F0               [24] 1153 	movx	@dptr,a
      00ADC3 90 0A E5         [24] 1154 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      00ADC6 E4               [12] 1155 	clr	a
      00ADC7 F0               [24] 1156 	movx	@dptr,a
      00ADC8 85 45 82         [24] 1157 	mov	dpl, _vial_handle_cmd_sloc2_1_0
      00ADCB C0 07            [24] 1158 	push	ar7
      00ADCD C0 06            [24] 1159 	push	ar6
      00ADCF C0 05            [24] 1160 	push	ar5
      00ADD1 C0 04            [24] 1161 	push	ar4
      00ADD3 C0 03            [24] 1162 	push	ar3
      00ADD5 C0 02            [24] 1163 	push	ar2
      00ADD7 12 85 1E         [24] 1164 	lcall	_dynamic_keymap_get_encoder
      00ADDA 85 82 47         [24] 1165 	mov	_vial_handle_cmd_sloc3_1_0,dpl
      00ADDD 85 83 48         [24] 1166 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),dph
      00ADE0 D0 02            [24] 1167 	pop	ar2
      00ADE2 D0 03            [24] 1168 	pop	ar3
      00ADE4 D0 04            [24] 1169 	pop	ar4
      00ADE6 D0 05            [24] 1170 	pop	ar5
      00ADE8 D0 06            [24] 1171 	pop	ar6
      00ADEA D0 07            [24] 1172 	pop	ar7
                                   1173 ;	quantum/vial.c:250: msg[0]  = keycode >> 8;
      00ADEC A9 48            [24] 1174 	mov	r1,(_vial_handle_cmd_sloc3_1_0 + 1)
      00ADEE 12 43 80         [24] 1175 	lcall	_ak820_outline_0116
      00ADF1 E9               [12] 1176 	mov	a,r1
      00ADF2 F0               [24] 1177 	movx	@dptr,a
                                   1178 ;	quantum/vial.c:251: msg[1]  = keycode & 0xFF;
      00ADF3 A8 47            [24] 1179 	mov	r0,_vial_handle_cmd_sloc3_1_0
      00ADF5 12 38 4C         [24] 1180 	lcall	_ak820_outline_0117
      00ADF8 E8               [12] 1181 	mov	a,r0
      00ADF9 F0               [24] 1182 	movx	@dptr,a
                                   1183 ;	quantum/vial.c:252: keycode = dynamic_keymap_get_encoder(layer, idx, 1);
      00ADFA 90 0A E4         [24] 1184 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      00ADFD E5 41            [12] 1185 	mov	a,_vial_handle_cmd_sloc0_1_0
      00ADFF F0               [24] 1186 	movx	@dptr,a
      00AE00 90 0A E5         [24] 1187 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      00AE03 74 01            [12] 1188 	mov	a,#0x01
      00AE05 F0               [24] 1189 	movx	@dptr,a
      00AE06 85 45 82         [24] 1190 	mov	dpl, _vial_handle_cmd_sloc2_1_0
      00AE09 C0 03            [24] 1191 	push	ar3
      00AE0B C0 02            [24] 1192 	push	ar2
      00AE0D 12 85 1E         [24] 1193 	lcall	_dynamic_keymap_get_encoder
      00AE10 85 82 47         [24] 1194 	mov	_vial_handle_cmd_sloc3_1_0,dpl
      00AE13 85 83 48         [24] 1195 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),dph
      00AE16 D0 02            [24] 1196 	pop	ar2
      00AE18 D0 03            [24] 1197 	pop	ar3
                                   1198 ;	quantum/vial.c:253: msg[2] = keycode >> 8;
      00AE1A A9 48            [24] 1199 	mov	r1,(_vial_handle_cmd_sloc3_1_0 + 1)
      00AE1C 12 43 9C         [24] 1200 	lcall	_ak820_outline_0140
      00AE1F E9               [12] 1201 	mov	a,r1
      00AE20 F0               [24] 1202 	movx	@dptr,a
                                   1203 ;	quantum/vial.c:254: msg[3] = keycode & 0xFF;
      00AE21 A8 47            [24] 1204 	mov	r0,_vial_handle_cmd_sloc3_1_0
      00AE23 85 43 82         [24] 1205 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00AE26 85 44 83         [24] 1206 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00AE29 E8               [12] 1207 	mov	a,r0
      00AE2A F0               [24] 1208 	movx	@dptr,a
                                   1209 ;	quantum/vial.c:255: break;
      00AE2B 22               [24] 1210 	ret
                                   1211 ;	quantum/vial.c:257: case vial_set_encoder: {
      00AE2C                       1212 00113$:
                                   1213 ;	quantum/vial.c:258: dynamic_keymap_set_encoder(msg[2], msg[3], msg[4], vial_keycode_firewall((msg[5] << 8) | msg[6]));
      00AE2C 12 37 F0         [24] 1214 	lcall	_ak820_outline_0034
      00AE2F F5 43            [12] 1215 	mov	_vial_handle_cmd_sloc1_1_0,a
      00AE31 12 AB 43         [24] 1216 	lcall	_ak820_outline_0015
      00AE34 F5 45            [12] 1217 	mov	_vial_handle_cmd_sloc2_1_0,a
      00AE36 12 AB 4C         [24] 1218 	lcall	_ak820_outline_0021
      00AE39 E0               [24] 1219 	movx	a,@dptr
                                   1220 ;	assignBit
      00AE3A 24 FF            [12] 1221 	add	a,#0xff
      00AE3C E4               [12] 1222 	clr	a
      00AE3D 33               [12] 1223 	rlc	a
      00AE3E F5 47            [12] 1224 	mov	_vial_handle_cmd_sloc3_1_0,a
      00AE40 12 43 25         [24] 1225 	lcall	_ak820_outline_0011
      00AE43 E0               [24] 1226 	movx	a,@dptr
      00AE44 F9               [12] 1227 	mov	r1,a
      00AE45 78 00            [12] 1228 	mov	r0,#0x00
      00AE47 74 06            [12] 1229 	mov	a,#0x06
      00AE49 12 37 DF         [24] 1230 	lcall	_ak820_outline_0017
      00AE4C 7B 00            [12] 1231 	mov	r3,#0x00
      00AE4E 42 00            [12] 1232 	orl	ar0,a
      00AE50 EB               [12] 1233 	mov	a,r3
      00AE51 42 01            [12] 1234 	orl	ar1,a
      00AE53 12 38 67         [24] 1235 	lcall	_ak820_outline_0152
      00AE56 12 AC 20         [24] 1236 	lcall	_vial_keycode_firewall
      00AE59 AA 82            [24] 1237 	mov	r2, dpl
      00AE5B AB 83            [24] 1238 	mov	r3, dph
      00AE5D 90 0A E7         [24] 1239 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      00AE60 E5 45            [12] 1240 	mov	a,_vial_handle_cmd_sloc2_1_0
      00AE62 F0               [24] 1241 	movx	@dptr,a
      00AE63 90 0A E8         [24] 1242 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      00AE66 E5 47            [12] 1243 	mov	a,_vial_handle_cmd_sloc3_1_0
      00AE68 F0               [24] 1244 	movx	@dptr,a
      00AE69 90 0A E9         [24] 1245 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      00AE6C EA               [12] 1246 	mov	a,r2
      00AE6D F0               [24] 1247 	movx	@dptr,a
      00AE6E EB               [12] 1248 	mov	a,r3
      00AE6F A3               [24] 1249 	inc	dptr
      00AE70 F0               [24] 1250 	movx	@dptr,a
      00AE71 85 43 82         [24] 1251 	mov	dpl, _vial_handle_cmd_sloc1_1_0
                                   1252 ;	quantum/vial.c:259: break;
      00AE74 02 85 85         [24] 1253 	ljmp	_dynamic_keymap_set_encoder
                                   1254 ;	quantum/vial.c:262: case vial_get_unlock_status: {
      00AE77                       1255 00114$:
                                   1256 ;	quantum/vial.c:264: VIAL_FILL_PACKET(msg, 0xFF, length);
      00AE77 90 0C 36         [24] 1257 	mov	dptr,#_vial_fill_packet_PARM_2
      00AE7A 74 FF            [12] 1258 	mov	a,#0xff
      00AE7C 12 43 5B         [24] 1259 	lcall	_ak820_outline_0061
      00AE7F C0 07            [24] 1260 	push	ar7
      00AE81 C0 06            [24] 1261 	push	ar6
      00AE83 12 AC 43         [24] 1262 	lcall	_vial_fill_packet
      00AE86 D0 06            [24] 1263 	pop	ar6
      00AE88 D0 07            [24] 1264 	pop	ar7
                                   1265 ;	quantum/vial.c:266: msg[0] = vial_unlocked;
      00AE8A 90 0D F9         [24] 1266 	mov	dptr,#_vial_unlocked
      00AE8D E0               [24] 1267 	movx	a,@dptr
      00AE8E 12 43 80         [24] 1268 	lcall	_ak820_outline_0116
      00AE91 F0               [24] 1269 	movx	@dptr,a
                                   1270 ;	quantum/vial.c:268: msg[1] = vial_unlock_in_progress;
      00AE92 74 01            [12] 1271 	mov	a,#0x01
      00AE94 2E               [12] 1272 	add	a, r6
      00AE95 FA               [12] 1273 	mov	r2,a
      00AE96 E4               [12] 1274 	clr	a
      00AE97 3F               [12] 1275 	addc	a, r7
      00AE98 FB               [12] 1276 	mov	r3,a
      00AE99 90 0D FA         [24] 1277 	mov	dptr,#_vial_unlock_in_progress
      00AE9C E0               [24] 1278 	movx	a,@dptr
      00AE9D 12 43 9C         [24] 1279 	lcall	_ak820_outline_0140
      00AEA0 F0               [24] 1280 	movx	@dptr,a
                                   1281 ;	quantum/vial.c:271: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00AEA1 7B 00            [12] 1282 	mov	r3,#0x00
      00AEA3                       1283 00137$:
      00AEA3 BB 02 00         [24] 1284 	cjne	r3,#0x02,00268$
      00AEA6                       1285 00268$:
      00AEA6 40 01            [24] 1286 	jc	00269$
      00AEA8 22               [24] 1287 	ret
      00AEA9                       1288 00269$:
                                   1289 ;	quantum/vial.c:272: msg[2 + i * 2] = vial_unlock_combo_rows[i];
      00AEA9 8B 01            [24] 1290 	mov	ar1,r3
      00AEAB 7A 00            [12] 1291 	mov	r2,#0x00
      00AEAD E9               [12] 1292 	mov	a,r1
      00AEAE 29               [12] 1293 	add	a,r1
      00AEAF F5 47            [12] 1294 	mov	_vial_handle_cmd_sloc3_1_0,a
      00AEB1 EA               [12] 1295 	mov	a,r2
      00AEB2 33               [12] 1296 	rlc	a
      00AEB3 F5 48            [12] 1297 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),a
      00AEB5 74 02            [12] 1298 	mov	a,#0x02
      00AEB7 25 47            [12] 1299 	add	a, _vial_handle_cmd_sloc3_1_0
      00AEB9 F8               [12] 1300 	mov	r0,a
      00AEBA E4               [12] 1301 	clr	a
      00AEBB 35 48            [12] 1302 	addc	a, (_vial_handle_cmd_sloc3_1_0 + 1)
      00AEBD FA               [12] 1303 	mov	r2,a
      00AEBE E8               [12] 1304 	mov	a,r0
      00AEBF 2E               [12] 1305 	add	a, r6
      00AEC0 F8               [12] 1306 	mov	r0,a
      00AEC1 EA               [12] 1307 	mov	a,r2
      00AEC2 3F               [12] 1308 	addc	a, r7
      00AEC3 FA               [12] 1309 	mov	r2,a
      00AEC4 EB               [12] 1310 	mov	a,r3
      00AEC5 12 B1 4C         [24] 1311 	lcall	_ak820_outline_0126
      00AEC8 88 82            [24] 1312 	mov	dpl,r0
      00AECA 8A 83            [24] 1313 	mov	dph,r2
      00AECC F0               [24] 1314 	movx	@dptr,a
                                   1315 ;	quantum/vial.c:273: msg[2 + i * 2 + 1] = vial_unlock_combo_cols[i];
      00AECD 74 03            [12] 1316 	mov	a,#0x03
      00AECF 25 47            [12] 1317 	add	a, _vial_handle_cmd_sloc3_1_0
      00AED1 F9               [12] 1318 	mov	r1,a
      00AED2 E4               [12] 1319 	clr	a
      00AED3 35 48            [12] 1320 	addc	a, (_vial_handle_cmd_sloc3_1_0 + 1)
      00AED5 FA               [12] 1321 	mov	r2,a
      00AED6 E9               [12] 1322 	mov	a,r1
      00AED7 2E               [12] 1323 	add	a, r6
      00AED8 F9               [12] 1324 	mov	r1,a
      00AED9 EA               [12] 1325 	mov	a,r2
      00AEDA 3F               [12] 1326 	addc	a, r7
      00AEDB FA               [12] 1327 	mov	r2,a
      00AEDC EB               [12] 1328 	mov	a,r3
      00AEDD 12 B1 41         [24] 1329 	lcall	_ak820_outline_0125
      00AEE0 12 6D 97         [24] 1330 	lcall	_ak820_outline_0136
                                   1331 ;	quantum/vial.c:271: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00AEE3 0B               [12] 1332 	inc	r3
                                   1333 ;	quantum/vial.c:278: case vial_unlock_start: {
      00AEE4 80 BD            [24] 1334 	sjmp	00137$
      00AEE6                       1335 00116$:
                                   1336 ;	quantum/vial.c:280: if (!vial_unlock_in_progress) vial_release_held_state();
      00AEE6 90 0D FA         [24] 1337 	mov	dptr,#_vial_unlock_in_progress
      00AEE9 E0               [24] 1338 	movx	a,@dptr
      00AEEA 70 03            [24] 1339 	jnz	00118$
      00AEEC 12 AC 68         [24] 1340 	lcall	_vial_release_held_state
      00AEEF                       1341 00118$:
                                   1342 ;	quantum/vial.c:282: vial_unlock_in_progress = 1;
      00AEEF 90 0D FA         [24] 1343 	mov	dptr,#_vial_unlock_in_progress
      00AEF2 74 01            [12] 1344 	mov	a,#0x01
      00AEF4 F0               [24] 1345 	movx	@dptr,a
                                   1346 ;	quantum/vial.c:283: vial_unlock_counter = VIAL_UNLOCK_COUNTER_MAX;
      00AEF5 90 0D FB         [24] 1347 	mov	dptr,#_vial_unlock_counter
      00AEF8 74 1E            [12] 1348 	mov	a,#0x1e
      00AEFA F0               [24] 1349 	movx	@dptr,a
                                   1350 ;	quantum/vial.c:285: vial_unlock_holding = false;
      00AEFB 90 0C 33         [24] 1351 	mov	dptr,#_vial_unlock_holding
      00AEFE E4               [12] 1352 	clr	a
      00AEFF F0               [24] 1353 	movx	@dptr,a
                                   1354 ;	quantum/vial.c:287: break;
      00AF00 22               [24] 1355 	ret
                                   1356 ;	quantum/vial.c:289: case vial_unlock_poll: {
      00AF01                       1357 00119$:
                                   1358 ;	quantum/vial.c:290: msg[0] = vial_unlocked;
      00AF01 90 0D F9         [24] 1359 	mov	dptr,#_vial_unlocked
      00AF04 E0               [24] 1360 	movx	a,@dptr
      00AF05 12 43 80         [24] 1361 	lcall	_ak820_outline_0116
      00AF08 F0               [24] 1362 	movx	@dptr,a
                                   1363 ;	quantum/vial.c:291: msg[1] = vial_unlock_in_progress;
      00AF09 90 0D FA         [24] 1364 	mov	dptr,#_vial_unlock_in_progress
      00AF0C E0               [24] 1365 	movx	a,@dptr
      00AF0D 12 38 4C         [24] 1366 	lcall	_ak820_outline_0117
      00AF10 F0               [24] 1367 	movx	@dptr,a
                                   1368 ;	quantum/vial.c:292: msg[2] = vial_unlock_counter;
      00AF11 74 02            [12] 1369 	mov	a,#0x02
      00AF13 2E               [12] 1370 	add	a, r6
      00AF14 FA               [12] 1371 	mov	r2,a
      00AF15 E4               [12] 1372 	clr	a
      00AF16 3F               [12] 1373 	addc	a, r7
      00AF17 FB               [12] 1374 	mov	r3,a
      00AF18 90 0D FB         [24] 1375 	mov	dptr,#_vial_unlock_counter
      00AF1B E0               [24] 1376 	movx	a,@dptr
      00AF1C 12 43 9C         [24] 1377 	lcall	_ak820_outline_0140
      00AF1F F0               [24] 1378 	movx	@dptr,a
                                   1379 ;	quantum/vial.c:293: break;
      00AF20 22               [24] 1380 	ret
                                   1381 ;	quantum/vial.c:295: case vial_lock: {
      00AF21                       1382 00120$:
                                   1383 ;	quantum/vial.c:297: vial_unlocked = 0;
      00AF21 90 0D F9         [24] 1384 	mov	dptr,#_vial_unlocked
      00AF24 E4               [12] 1385 	clr	a
      00AF25 F0               [24] 1386 	movx	@dptr,a
                                   1387 ;	quantum/vial.c:298: vial_unlock_in_progress = 0;
      00AF26 90 0D FA         [24] 1388 	mov	dptr,#_vial_unlock_in_progress
      00AF29 F0               [24] 1389 	movx	@dptr,a
                                   1390 ;	quantum/vial.c:299: vial_unlock_holding = false;
      00AF2A 90 0C 33         [24] 1391 	mov	dptr,#_vial_unlock_holding
      00AF2D F0               [24] 1392 	movx	@dptr,a
                                   1393 ;	quantum/vial.c:301: break;
      00AF2E 22               [24] 1394 	ret
                                   1395 ;	quantum/vial.c:303: case vial_qmk_settings_query: {
      00AF2F                       1396 00121$:
                                   1397 ;	quantum/vial.c:312: VIAL_FILL_PACKET(msg, 0xFF, length); /* indicate that we don't support any qsid */
      00AF2F 90 0C 36         [24] 1398 	mov	dptr,#_vial_fill_packet_PARM_2
      00AF32 74 FF            [12] 1399 	mov	a,#0xff
      00AF34 12 43 5B         [24] 1400 	lcall	_ak820_outline_0061
                                   1401 ;	quantum/vial.c:314: break;
      00AF37 02 AC 43         [24] 1402 	ljmp	_vial_fill_packet
                                   1403 ;	quantum/vial.c:346: case vial_dynamic_entry_op: {
      00AF3A                       1404 00122$:
                                   1405 ;	quantum/vial.c:347: switch (msg[2]) {
      00AF3A 12 37 F0         [24] 1406 	lcall	_ak820_outline_0034
      00AF3D FB               [12] 1407 	mov	r3,a
      00AF3E 60 0C            [24] 1408 	jz	00123$
      00AF40 BB 03 02         [24] 1409 	cjne	r3,#0x03,00272$
      00AF43 80 31            [24] 1410 	sjmp	00124$
      00AF45                       1411 00272$:
      00AF45 BB 04 03         [24] 1412 	cjne	r3,#0x04,00273$
      00AF48 02 AF D4         [24] 1413 	ljmp	00125$
      00AF4B                       1414 00273$:
      00AF4B 22               [24] 1415 	ret
                                   1416 ;	quantum/vial.c:348: case dynamic_vial_get_number_of_entries: {
      00AF4C                       1417 00123$:
                                   1418 ;	quantum/vial.c:349: VIAL_FILL_PACKET(msg, 0, length);
      00AF4C 90 0C 36         [24] 1419 	mov	dptr,#_vial_fill_packet_PARM_2
      00AF4F E4               [12] 1420 	clr	a
      00AF50 12 43 5B         [24] 1421 	lcall	_ak820_outline_0061
      00AF53 C0 07            [24] 1422 	push	ar7
      00AF55 C0 06            [24] 1423 	push	ar6
      00AF57 12 AC 43         [24] 1424 	lcall	_vial_fill_packet
      00AF5A D0 06            [24] 1425 	pop	ar6
      00AF5C D0 07            [24] 1426 	pop	ar7
                                   1427 ;	quantum/vial.c:350: msg[0] = VIAL_TAP_DANCE_ENTRIES;
      00AF5E 12 43 80         [24] 1428 	lcall	_ak820_outline_0116
      00AF61 E4               [12] 1429 	clr	a
      00AF62 12 43 5B         [24] 1430 	lcall	_ak820_outline_0061
                                   1431 ;	quantum/vial.c:351: msg[1] = VIAL_COMBO_ENTRIES;
      00AF65 A3               [24] 1432 	inc	dptr
      00AF66 74 08            [12] 1433 	mov	a,#0x08
      00AF68 12 43 2F         [24] 1434 	lcall	_ak820_outline_0030
                                   1435 ;	quantum/vial.c:352: msg[2] = VIAL_KEY_OVERRIDE_ENTRIES;
      00AF6B E4               [12] 1436 	clr	a
      00AF6C F0               [24] 1437 	movx	@dptr,a
                                   1438 ;	quantum/vial.c:354: msg[VIAL_RAW_EPSIZE - 1] = 1; /* Standard Vial feature bit 0. */
      00AF6D 74 1F            [12] 1439 	mov	a,#0x1f
      00AF6F 12 37 E8         [24] 1440 	lcall	_ak820_outline_0031
      00AF72 74 01            [12] 1441 	mov	a,#0x01
      00AF74 F0               [24] 1442 	movx	@dptr,a
                                   1443 ;	quantum/vial.c:356: break;
      00AF75 22               [24] 1444 	ret
                                   1445 ;	quantum/vial.c:382: case dynamic_vial_combo_get: {
      00AF76                       1446 00124$:
                                   1447 ;	quantum/vial.c:383: uint8_t idx = msg[3];
      00AF76 12 AB 43         [24] 1448 	lcall	_ak820_outline_0015
      00AF79 FB               [12] 1449 	mov	r3,a
                                   1450 ;	quantum/vial.c:384: vial_combo_entry_t entry = { { 0 }, 0 };
      00AF7A 90 0C 3D         [24] 1451 	mov	dptr,#_vial_handle_cmd_entry_70000_645
      00AF7D 12 4F FD         [24] 1452 	lcall	_ak820_outline_0166
      00AF80 90 0C 3F         [24] 1453 	mov	dptr,#(_vial_handle_cmd_entry_70000_645 + 0x0002)
      00AF83 F0               [24] 1454 	movx	@dptr,a
      00AF84 A3               [24] 1455 	inc	dptr
      00AF85 F0               [24] 1456 	movx	@dptr,a
      00AF86 90 0C 41         [24] 1457 	mov	dptr,#(_vial_handle_cmd_entry_70000_645 + 0x0004)
      00AF89 F0               [24] 1458 	movx	@dptr,a
      00AF8A A3               [24] 1459 	inc	dptr
      00AF8B F0               [24] 1460 	movx	@dptr,a
      00AF8C 90 0C 43         [24] 1461 	mov	dptr,#(_vial_handle_cmd_entry_70000_645 + 0x0006)
      00AF8F F0               [24] 1462 	movx	@dptr,a
      00AF90 A3               [24] 1463 	inc	dptr
      00AF91 F0               [24] 1464 	movx	@dptr,a
      00AF92 90 0C 45         [24] 1465 	mov	dptr,#(_vial_handle_cmd_entry_70000_645 + 0x0008)
      00AF95 F0               [24] 1466 	movx	@dptr,a
      00AF96 A3               [24] 1467 	inc	dptr
      00AF97 F0               [24] 1468 	movx	@dptr,a
                                   1469 ;	quantum/vial.c:385: msg[0] = dynamic_keymap_get_combo(idx, &entry);
      00AF98 90 0A EC         [24] 1470 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      00AF9B 74 3D            [12] 1471 	mov	a,#_vial_handle_cmd_entry_70000_645
      00AF9D F0               [24] 1472 	movx	@dptr,a
      00AF9E 74 0C            [12] 1473 	mov	a,#(_vial_handle_cmd_entry_70000_645 >> 8)
      00AFA0 12 38 29         [24] 1474 	lcall	_ak820_outline_0097
      00AFA3 8B 82            [24] 1475 	mov	dpl, r3
      00AFA5 C0 07            [24] 1476 	push	ar7
      00AFA7 C0 06            [24] 1477 	push	ar6
      00AFA9 C0 05            [24] 1478 	push	ar5
      00AFAB C0 04            [24] 1479 	push	ar4
      00AFAD 12 85 F1         [24] 1480 	lcall	_dynamic_keymap_get_combo
      00AFB0 AA 82            [24] 1481 	mov	r2, dpl
      00AFB2 D0 04            [24] 1482 	pop	ar4
      00AFB4 D0 05            [24] 1483 	pop	ar5
      00AFB6 D0 06            [24] 1484 	pop	ar6
      00AFB8 D0 07            [24] 1485 	pop	ar7
      00AFBA 12 43 80         [24] 1486 	lcall	_ak820_outline_0116
      00AFBD EA               [12] 1487 	mov	a,r2
      00AFBE F0               [24] 1488 	movx	@dptr,a
                                   1489 ;	quantum/vial.c:386: memcpy(&msg[1], &entry, sizeof(entry));
      00AFBF 7B 00            [12] 1490 	mov	r3,#0x00
      00AFC1 90 0D 79         [24] 1491 	mov	dptr,#___memcpy_PARM_2
      00AFC4 74 3D            [12] 1492 	mov	a,#_vial_handle_cmd_entry_70000_645
      00AFC6 F0               [24] 1493 	movx	@dptr,a
      00AFC7 74 0C            [12] 1494 	mov	a,#(_vial_handle_cmd_entry_70000_645 >> 8)
      00AFC9 12 B1 32         [24] 1495 	lcall	_ak820_outline_0073
      00AFCC 12 38 4C         [24] 1496 	lcall	_ak820_outline_0117
      00AFCF 8B F0            [24] 1497 	mov	b, r3
                                   1498 ;	quantum/vial.c:387: break;
      00AFD1 02 B6 F1         [24] 1499 	ljmp	___memcpy
                                   1500 ;	quantum/vial.c:389: case dynamic_vial_combo_set: {
      00AFD4                       1501 00125$:
                                   1502 ;	quantum/vial.c:390: uint8_t idx = msg[3];
      00AFD4 12 AB 43         [24] 1503 	lcall	_ak820_outline_0015
      00AFD7 FD               [12] 1504 	mov	r5,a
                                   1505 ;	quantum/vial.c:392: memcpy(&entry, &msg[4], sizeof(entry));
      00AFD8 74 04            [12] 1506 	mov	a,#0x04
      00AFDA 2E               [12] 1507 	add	a, r6
      00AFDB FB               [12] 1508 	mov	r3,a
      00AFDC E4               [12] 1509 	clr	a
      00AFDD 3F               [12] 1510 	addc	a, r7
      00AFDE FC               [12] 1511 	mov	r4,a
      00AFDF 90 0D 79         [24] 1512 	mov	dptr,#___memcpy_PARM_2
      00AFE2 EB               [12] 1513 	mov	a,r3
      00AFE3 F0               [24] 1514 	movx	@dptr,a
      00AFE4 EC               [12] 1515 	mov	a,r4
      00AFE5 12 B1 32         [24] 1516 	lcall	_ak820_outline_0073
      00AFE8 90 0C 47         [24] 1517 	mov	dptr,#_vial_handle_cmd_entry_70000_646
      00AFEB F5 F0            [12] 1518 	mov	b,a
      00AFED C0 07            [24] 1519 	push	ar7
      00AFEF C0 06            [24] 1520 	push	ar6
      00AFF1 C0 05            [24] 1521 	push	ar5
      00AFF3 12 B6 F1         [24] 1522 	lcall	___memcpy
                                   1523 ;	quantum/vial.c:393: entry.output = vial_keycode_firewall(entry.output);
      00AFF6 90 0C 4F         [24] 1524 	mov	dptr,#(_vial_handle_cmd_entry_70000_646 + 0x0008)
      00AFF9 12 38 51         [24] 1525 	lcall	_ak820_outline_0121
      00AFFC 12 33 FC         [24] 1526 	lcall	_ak820_outline_0122
      00AFFF 12 AC 20         [24] 1527 	lcall	_vial_keycode_firewall
      00B002 AB 82            [24] 1528 	mov	r3, dpl
      00B004 AC 83            [24] 1529 	mov	r4, dph
      00B006 D0 05            [24] 1530 	pop	ar5
      00B008 90 0C 4F         [24] 1531 	mov	dptr,#(_vial_handle_cmd_entry_70000_646 + 0x0008)
      00B00B 12 38 23         [24] 1532 	lcall	_ak820_outline_0077
                                   1533 ;	quantum/vial.c:394: msg[0] = dynamic_keymap_set_combo(idx, &entry);
      00B00E 90 0A F0         [24] 1534 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      00B011 74 47            [12] 1535 	mov	a,#_vial_handle_cmd_entry_70000_646
      00B013 F0               [24] 1536 	movx	@dptr,a
      00B014 74 0C            [12] 1537 	mov	a,#(_vial_handle_cmd_entry_70000_646 >> 8)
      00B016 12 38 29         [24] 1538 	lcall	_ak820_outline_0097
      00B019 8D 82            [24] 1539 	mov	dpl, r5
      00B01B 12 86 98         [24] 1540 	lcall	_dynamic_keymap_set_combo
      00B01E AC 82            [24] 1541 	mov	r4, dpl
      00B020 D0 06            [24] 1542 	pop	ar6
      00B022 D0 07            [24] 1543 	pop	ar7
      00B024 12 43 80         [24] 1544 	lcall	_ak820_outline_0116
      00B027 EC               [12] 1545 	mov	a,r4
      00B028 F0               [24] 1546 	movx	@dptr,a
                                   1547 ;	quantum/vial.c:395: if (!msg[0]) reload_combo();
      00B029 EC               [12] 1548 	mov	a,r4
      00B02A 70 03            [24] 1549 	jnz	00139$
                                   1550 ;	quantum/vial.c:423: }
                                   1551 ;	quantum/vial.c:424: }
      00B02C 02 35 37         [24] 1552 	ljmp	_ak820_combo_reload
      00B02F                       1553 00139$:
      00B02F 22               [24] 1554 	ret
                                   1555 ;------------------------------------------------------------
                                   1556 ;Allocation info for local variables in function 'vial_keycode_down'
                                   1557 ;------------------------------------------------------------
                                   1558 ;keycode       Allocated with name '_vial_keycode_down_keycode_10000_648'
                                   1559 ;dummy_event   Allocated with name '_vial_keycode_down_dummy_event_30000_655'
                                   1560 ;------------------------------------------------------------
                                   1561 ;	quantum/vial.c:428: void vial_keycode_down(uint16_t keycode) {
                                   1562 ;	-----------------------------------------
                                   1563 ;	 function vial_keycode_down
                                   1564 ;	-----------------------------------------
      00B030                       1565 _vial_keycode_down:
      00B030 12 38 3B         [24] 1566 	lcall	_ak820_outline_0103
      00B033 90 0C 53         [24] 1567 	mov	dptr,#_vial_keycode_down_keycode_10000_648
      00B036 12 38 40         [24] 1568 	lcall	_ak820_outline_0104
                                   1569 ;	quantum/vial.c:432: if (keycode >= QK_MOD_TAP && keycode <= QK_LAYER_TAP_MAX) {
      00B039 90 0C 53         [24] 1570 	mov	dptr,#_vial_keycode_down_keycode_10000_648
      00B03C 12 37 C3         [24] 1571 	lcall	_ak820_outline_0010
      00B03F 74 E0            [12] 1572 	mov	a,#0x100 - 0x20
      00B041 2D               [12] 1573 	add	a,r5
      00B042 50 19            [24] 1574 	jnc	00104$
      00B044 C3               [12] 1575 	clr	c
      00B045 74 FF            [12] 1576 	mov	a,#0xff
      00B047 9C               [12] 1577 	subb	a,r4
      00B048 74 4F            [12] 1578 	mov	a,#0x4f
      00B04A 9D               [12] 1579 	subb	a,r5
      00B04B 40 10            [24] 1580 	jc	00104$
                                   1581 ;	free result
                                   1582 ;	quantum/vial.c:433: keycode = (uint8_t)keycode;
      00B04D 90 0C 53         [24] 1583 	mov	dptr,#_vial_keycode_down_keycode_10000_648
      00B050 EE               [12] 1584 	mov	a,r6
      00B051 12 38 57         [24] 1585 	lcall	_ak820_outline_0123
                                   1586 ;	quantum/vial.c:434: if (keycode <= KC_TRANSPARENT) return;
      00B054 90 0C 53         [24] 1587 	mov	dptr,#_vial_keycode_down_keycode_10000_648
      00B057 E0               [24] 1588 	movx	a,@dptr
      00B058 24 FE            [12] 1589 	add	a,#0xff - 0x01
      00B05A 40 01            [24] 1590 	jc	00104$
                                   1591 ;	free result
      00B05C 22               [24] 1592 	ret
      00B05D                       1593 00104$:
                                   1594 ;	quantum/vial.c:437: g_vial_magic_keycode_override = keycode;
      00B05D 90 0C 53         [24] 1595 	mov	dptr,#_vial_keycode_down_keycode_10000_648
      00B060 12 B1 19         [24] 1596 	lcall	_ak820_outline_0024
                                   1597 ;	quantum/vial.c:439: if (keycode <= QK_MODS_MAX) {
      00B063 40 06            [24] 1598 	jc	00107$
                                   1599 ;	free result
                                   1600 ;	quantum/vial.c:440: register_code16(keycode);
      00B065 12 43 80         [24] 1601 	lcall	_ak820_outline_0116
      00B068 02 9D 6C         [24] 1602 	ljmp	_register_code16
      00B06B                       1603 00107$:
                                   1604 ;	quantum/vial.c:442: keyevent_t dummy_event = {
      00B06B 90 0C 59         [24] 1605 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_655 + 0x0004)
      00B06E 74 01            [12] 1606 	mov	a,#0x01
      00B070 F0               [24] 1607 	movx	@dptr,a
      00B071 90 0C 56         [24] 1608 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_655 + 0x0001)
      00B074 74 F0            [12] 1609 	mov	a,#0xf0
      00B076 F0               [24] 1610 	movx	@dptr,a
      00B077 90 0C 55         [24] 1611 	mov	dptr,#_vial_keycode_down_dummy_event_30000_655
      00B07A F0               [24] 1612 	movx	@dptr,a
      00B07B 90 0C 5A         [24] 1613 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_655 + 0x0005)
      00B07E 74 01            [12] 1614 	mov	a,#0x01
      00B080 F0               [24] 1615 	movx	@dptr,a
      00B081 12 49 F6         [24] 1616 	lcall	_timer_read
      00B084 12 43 8B         [24] 1617 	lcall	_ak820_outline_0131
      00B087 43 06 01         [24] 1618 	orl	ar6,#0x01
      00B08A 90 0C 57         [24] 1619 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_655 + 0x0002)
      00B08D 12 49 5E         [24] 1620 	lcall	_ak820_outline_0059
                                   1621 ;	quantum/vial.c:446: AK820_ACTION_EXEC(dummy_event);
      00B090 90 0C 55         [24] 1622 	mov	dptr,#_vial_keycode_down_dummy_event_30000_655
                                   1623 ;	quantum/vial.c:448: }
      00B093 02 71 BF         [24] 1624 	ljmp	_ak820_action_exec
                                   1625 ;------------------------------------------------------------
                                   1626 ;Allocation info for local variables in function 'vial_keycode_up'
                                   1627 ;------------------------------------------------------------
                                   1628 ;keycode       Allocated with name '_vial_keycode_up_keycode_10000_656'
                                   1629 ;dummy_event   Allocated with name '_vial_keycode_up_dummy_event_30000_663'
                                   1630 ;------------------------------------------------------------
                                   1631 ;	quantum/vial.c:450: void vial_keycode_up(uint16_t keycode) {
                                   1632 ;	-----------------------------------------
                                   1633 ;	 function vial_keycode_up
                                   1634 ;	-----------------------------------------
      00B096                       1635 _vial_keycode_up:
      00B096 12 38 3B         [24] 1636 	lcall	_ak820_outline_0103
      00B099 90 0C 5B         [24] 1637 	mov	dptr,#_vial_keycode_up_keycode_10000_656
      00B09C 12 38 40         [24] 1638 	lcall	_ak820_outline_0104
                                   1639 ;	quantum/vial.c:454: if (keycode >= QK_MOD_TAP && keycode <= QK_LAYER_TAP_MAX) {
      00B09F 90 0C 5B         [24] 1640 	mov	dptr,#_vial_keycode_up_keycode_10000_656
      00B0A2 12 37 C3         [24] 1641 	lcall	_ak820_outline_0010
      00B0A5 74 E0            [12] 1642 	mov	a,#0x100 - 0x20
      00B0A7 2D               [12] 1643 	add	a,r5
      00B0A8 50 19            [24] 1644 	jnc	00104$
      00B0AA C3               [12] 1645 	clr	c
      00B0AB 74 FF            [12] 1646 	mov	a,#0xff
      00B0AD 9C               [12] 1647 	subb	a,r4
      00B0AE 74 4F            [12] 1648 	mov	a,#0x4f
      00B0B0 9D               [12] 1649 	subb	a,r5
      00B0B1 40 10            [24] 1650 	jc	00104$
                                   1651 ;	free result
                                   1652 ;	quantum/vial.c:455: keycode = (uint8_t)keycode;
      00B0B3 90 0C 5B         [24] 1653 	mov	dptr,#_vial_keycode_up_keycode_10000_656
      00B0B6 EE               [12] 1654 	mov	a,r6
      00B0B7 12 38 57         [24] 1655 	lcall	_ak820_outline_0123
                                   1656 ;	quantum/vial.c:456: if (keycode <= KC_TRANSPARENT) return;
      00B0BA 90 0C 5B         [24] 1657 	mov	dptr,#_vial_keycode_up_keycode_10000_656
      00B0BD E0               [24] 1658 	movx	a,@dptr
      00B0BE 24 FE            [12] 1659 	add	a,#0xff - 0x01
      00B0C0 40 01            [24] 1660 	jc	00104$
                                   1661 ;	free result
      00B0C2 22               [24] 1662 	ret
      00B0C3                       1663 00104$:
                                   1664 ;	quantum/vial.c:459: g_vial_magic_keycode_override = keycode;
      00B0C3 90 0C 5B         [24] 1665 	mov	dptr,#_vial_keycode_up_keycode_10000_656
      00B0C6 12 B1 19         [24] 1666 	lcall	_ak820_outline_0024
                                   1667 ;	quantum/vial.c:461: if (keycode <= QK_MODS_MAX) {
      00B0C9 40 06            [24] 1668 	jc	00107$
                                   1669 ;	free result
                                   1670 ;	quantum/vial.c:462: unregister_code16(keycode);
      00B0CB 12 43 80         [24] 1671 	lcall	_ak820_outline_0116
      00B0CE 02 9D B0         [24] 1672 	ljmp	_unregister_code16
      00B0D1                       1673 00107$:
                                   1674 ;	quantum/vial.c:464: keyevent_t dummy_event = {
      00B0D1 90 0C 61         [24] 1675 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_663 + 0x0004)
      00B0D4 74 01            [12] 1676 	mov	a,#0x01
      00B0D6 F0               [24] 1677 	movx	@dptr,a
      00B0D7 90 0C 5E         [24] 1678 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_663 + 0x0001)
      00B0DA 74 F0            [12] 1679 	mov	a,#0xf0
      00B0DC F0               [24] 1680 	movx	@dptr,a
      00B0DD 90 0C 5D         [24] 1681 	mov	dptr,#_vial_keycode_up_dummy_event_30000_663
      00B0E0 F0               [24] 1682 	movx	@dptr,a
      00B0E1 90 0C 62         [24] 1683 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_663 + 0x0005)
      00B0E4 E4               [12] 1684 	clr	a
      00B0E5 F0               [24] 1685 	movx	@dptr,a
      00B0E6 12 49 F6         [24] 1686 	lcall	_timer_read
      00B0E9 12 43 8B         [24] 1687 	lcall	_ak820_outline_0131
      00B0EC 43 06 01         [24] 1688 	orl	ar6,#0x01
      00B0EF 90 0C 5F         [24] 1689 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_663 + 0x0002)
      00B0F2 12 49 5E         [24] 1690 	lcall	_ak820_outline_0059
                                   1691 ;	quantum/vial.c:468: AK820_ACTION_EXEC(dummy_event);
      00B0F5 90 0C 5D         [24] 1692 	mov	dptr,#_vial_keycode_up_dummy_event_30000_663
                                   1693 ;	quantum/vial.c:470: }
      00B0F8 02 71 BF         [24] 1694 	ljmp	_ak820_action_exec
                                   1695 ;------------------------------------------------------------
                                   1696 ;Allocation info for local variables in function 'vial_keycode_tap'
                                   1697 ;------------------------------------------------------------
                                   1698 ;keycode       Allocated with name '_vial_keycode_tap_keycode_10000_664'
                                   1699 ;i             Allocated with name '_vial_keycode_tap_i_30000_667'
                                   1700 ;------------------------------------------------------------
                                   1701 ;	quantum/vial.c:472: void vial_keycode_tap(uint16_t keycode) {
                                   1702 ;	-----------------------------------------
                                   1703 ;	 function vial_keycode_tap
                                   1704 ;	-----------------------------------------
      00B0FB                       1705 _vial_keycode_tap:
      00B0FB 12 38 3B         [24] 1706 	lcall	_ak820_outline_0103
      00B0FE 90 0C 63         [24] 1707 	mov	dptr,#_vial_keycode_tap_keycode_10000_664
      00B101 12 38 40         [24] 1708 	lcall	_ak820_outline_0104
                                   1709 ;	quantum/vial.c:473: vial_keycode_down(keycode);
      00B104 90 0C 63         [24] 1710 	mov	dptr,#_vial_keycode_tap_keycode_10000_664
      00B107 12 37 98         [24] 1711 	lcall	_ak820_outline_0004
      00B10A C0 07            [24] 1712 	push	ar7
      00B10C C0 06            [24] 1713 	push	ar6
      00B10E 11 30            [12] 1714 	acall	_vial_keycode_down
      00B110 D0 06            [24] 1715 	pop	ar6
      00B112 D0 07            [24] 1716 	pop	ar7
                                   1717 ;	quantum/vial.c:475: vial_keycode_up(keycode);
      00B114 12 43 80         [24] 1718 	lcall	_ak820_outline_0116
                                   1719 ;	quantum/vial.c:476: }
      00B117 01 96            [12] 1720 	ajmp	_vial_keycode_up
                                   1721 ;------------------------------------------------------------
                                   1722 ;Allocation info for local variables in function 'process_record_vial'
                                   1723 ;------------------------------------------------------------
                                   1724 ;record        Allocated with name '_process_record_vial_PARM_2'
                                   1725 ;keycode       Allocated with name '_process_record_vial_keycode_10000_669'
                                   1726 ;------------------------------------------------------------
                                   1727 ;	quantum/vial.c:686: bool process_record_vial(uint16_t keycode, keyrecord_t *record) {
                                   1728 ;	-----------------------------------------
                                   1729 	.area CSEG    (CODE)
                                   1730 	.area CONST   (CODE)
                                   1731 	.area CONST   (CODE)
      00BC6F                       1732 _keyboard_definition:
      00BC6F FD                    1733 	.db #0xfd	; 253
      00BC70 37                    1734 	.db #0x37	; 55	'7'
      00BC71 7A                    1735 	.db #0x7a	; 122	'z'
      00BC72 58                    1736 	.db #0x58	; 88	'X'
      00BC73 5A                    1737 	.db #0x5a	; 90	'Z'
      00BC74 00                    1738 	.db #0x00	; 0
      00BC75 00                    1739 	.db #0x00	; 0
      00BC76 04                    1740 	.db #0x04	; 4
      00BC77 E6                    1741 	.db #0xe6	; 230
      00BC78 D6                    1742 	.db #0xd6	; 214
      00BC79 B4                    1743 	.db #0xb4	; 180
      00BC7A 46                    1744 	.db #0x46	; 70	'F'
      00BC7B 02                    1745 	.db #0x02	; 2
      00BC7C 00                    1746 	.db #0x00	; 0
      00BC7D 21                    1747 	.db #0x21	; 33
      00BC7E 01                    1748 	.db #0x01	; 1
      00BC7F 00                    1749 	.db #0x00	; 0
      00BC80 00                    1750 	.db #0x00	; 0
      00BC81 00                    1751 	.db #0x00	; 0
      00BC82 00                    1752 	.db #0x00	; 0
      00BC83 37                    1753 	.db #0x37	; 55	'7'
      00BC84 27                    1754 	.db #0x27	; 39
      00BC85 97                    1755 	.db #0x97	; 151
      00BC86 D6                    1756 	.db #0xd6	; 214
      00BC87 E0                    1757 	.db #0xe0	; 224
      00BC88 03                    1758 	.db #0x03	; 3
      00BC89 CB                    1759 	.db #0xcb	; 203
      00BC8A 01                    1760 	.db #0x01	; 1
      00BC8B 3C                    1761 	.db #0x3c	; 60
      00BC8C 00                    1762 	.db #0x00	; 0
      00BC8D 00                    1763 	.db #0x00	; 0
      00BC8E 3D                    1764 	.db #0x3d	; 61
      00BC8F 88                    1765 	.db #0x88	; 136
      00BC90 CD                    1766 	.db #0xcd	; 205
      00BC91 A5                    1767 	.db #0xa5	; 165
      00BC92 AA                    1768 	.db #0xaa	; 170
      00BC93 E5                    1769 	.db #0xe5	; 229
      00BC94 A8                    1770 	.db #0xa8	; 168
      00BC95 76                    1771 	.db #0x76	; 118	'v'
      00BC96 F6                    1772 	.db #0xf6	; 246
      00BC97 43                    1773 	.db #0x43	; 67	'C'
      00BC98 0E                    1774 	.db #0x0e	; 14
      00BC99 D2                    1775 	.db #0xd2	; 210
      00BC9A 90                    1776 	.db #0x90	; 144
      00BC9B 7D                    1777 	.db #0x7d	; 125
      00BC9C 94                    1778 	.db #0x94	; 148
      00BC9D 79                    1779 	.db #0x79	; 121	'y'
      00BC9E 78                    1780 	.db #0x78	; 120	'x'
      00BC9F EF                    1781 	.db #0xef	; 239
      00BCA0 49                    1782 	.db #0x49	; 73	'I'
      00BCA1 3E                    1783 	.db #0x3e	; 62
      00BCA2 EF                    1784 	.db #0xef	; 239
      00BCA3 FD                    1785 	.db #0xfd	; 253
      00BCA4 8F                    1786 	.db #0x8f	; 143
      00BCA5 EF                    1787 	.db #0xef	; 239
      00BCA6 00                    1788 	.db #0x00	; 0
      00BCA7 C6                    1789 	.db #0xc6	; 198
      00BCA8 D1                    1790 	.db #0xd1	; 209
      00BCA9 DB                    1791 	.db #0xdb	; 219
      00BCAA FB                    1792 	.db #0xfb	; 251
      00BCAB EB                    1793 	.db #0xeb	; 235
      00BCAC DE                    1794 	.db #0xde	; 222
      00BCAD 66                    1795 	.db #0x66	; 102	'f'
      00BCAE 63                    1796 	.db #0x63	; 99	'c'
      00BCAF 0C                    1797 	.db #0x0c	; 12
      00BCB0 92                    1798 	.db #0x92	; 146
      00BCB1 7B                    1799 	.db #0x7b	; 123
      00BCB2 F9                    1800 	.db #0xf9	; 249
      00BCB3 D4                    1801 	.db #0xd4	; 212
      00BCB4 7A                    1802 	.db #0x7a	; 122	'z'
      00BCB5 4F                    1803 	.db #0x4f	; 79	'O'
      00BCB6 83                    1804 	.db #0x83	; 131
      00BCB7 4B                    1805 	.db #0x4b	; 75	'K'
      00BCB8 86                    1806 	.db #0x86	; 134
      00BCB9 0E                    1807 	.db #0x0e	; 14
      00BCBA 6A                    1808 	.db #0x6a	; 106	'j'
      00BCBB F2                    1809 	.db #0xf2	; 242
      00BCBC 22                    1810 	.db #0x22	; 34
      00BCBD 22                    1811 	.db #0x22	; 34
      00BCBE 0B                    1812 	.db #0x0b	; 11
      00BCBF 03                    1813 	.db #0x03	; 3
      00BCC0 BA                    1814 	.db #0xba	; 186
      00BCC1 67                    1815 	.db #0x67	; 103	'g'
      00BCC2 9B                    1816 	.db #0x9b	; 155
      00BCC3 7A                    1817 	.db #0x7a	; 122	'z'
      00BCC4 E1                    1818 	.db #0xe1	; 225
      00BCC5 BC                    1819 	.db #0xbc	; 188
      00BCC6 37                    1820 	.db #0x37	; 55	'7'
      00BCC7 26                    1821 	.db #0x26	; 38
      00BCC8 46                    1822 	.db #0x46	; 70	'F'
      00BCC9 78                    1823 	.db #0x78	; 120	'x'
      00BCCA 05                    1824 	.db #0x05	; 5
      00BCCB 0D                    1825 	.db #0x0d	; 13
      00BCCC 95                    1826 	.db #0x95	; 149
      00BCCD 02                    1827 	.db #0x02	; 2
      00BCCE E4                    1828 	.db #0xe4	; 228
      00BCCF 18                    1829 	.db #0x18	; 24
      00BCD0 CA                    1830 	.db #0xca	; 202
      00BCD1 33                    1831 	.db #0x33	; 51	'3'
      00BCD2 EA                    1832 	.db #0xea	; 234
      00BCD3 24                    1833 	.db #0x24	; 36
      00BCD4 C8                    1834 	.db #0xc8	; 200
      00BCD5 81                    1835 	.db #0x81	; 129
      00BCD6 4E                    1836 	.db #0x4e	; 78	'N'
      00BCD7 47                    1837 	.db #0x47	; 71	'G'
      00BCD8 A8                    1838 	.db #0xa8	; 168
      00BCD9 44                    1839 	.db #0x44	; 68	'D'
      00BCDA DD                    1840 	.db #0xdd	; 221
      00BCDB 91                    1841 	.db #0x91	; 145
      00BCDC 6D                    1842 	.db #0x6d	; 109	'm'
      00BCDD 69                    1843 	.db #0x69	; 105	'i'
      00BCDE DB                    1844 	.db #0xdb	; 219
      00BCDF 4F                    1845 	.db #0x4f	; 79	'O'
      00BCE0 3A                    1846 	.db #0x3a	; 58
      00BCE1 43                    1847 	.db #0x43	; 67	'C'
      00BCE2 9D                    1848 	.db #0x9d	; 157
      00BCE3 26                    1849 	.db #0x26	; 38
      00BCE4 49                    1850 	.db #0x49	; 73	'I'
      00BCE5 4C                    1851 	.db #0x4c	; 76	'L'
      00BCE6 EF                    1852 	.db #0xef	; 239
      00BCE7 2B                    1853 	.db #0x2b	; 43
      00BCE8 D8                    1854 	.db #0xd8	; 216
      00BCE9 55                    1855 	.db #0x55	; 85	'U'
      00BCEA 95                    1856 	.db #0x95	; 149
      00BCEB 70                    1857 	.db #0x70	; 112	'p'
      00BCEC B1                    1858 	.db #0xb1	; 177
      00BCED CC                    1859 	.db #0xcc	; 204
      00BCEE CF                    1860 	.db #0xcf	; 207
      00BCEF 13                    1861 	.db #0x13	; 19
      00BCF0 32                    1862 	.db #0x32	; 50	'2'
      00BCF1 6A                    1863 	.db #0x6a	; 106	'j'
      00BCF2 A1                    1864 	.db #0xa1	; 161
      00BCF3 FF                    1865 	.db #0xff	; 255
      00BCF4 99                    1866 	.db #0x99	; 153
      00BCF5 61                    1867 	.db #0x61	; 97	'a'
      00BCF6 95                    1868 	.db #0x95	; 149
      00BCF7 B1                    1869 	.db #0xb1	; 177
      00BCF8 89                    1870 	.db #0x89	; 137
      00BCF9 9B                    1871 	.db #0x9b	; 155
      00BCFA 11                    1872 	.db #0x11	; 17
      00BCFB D9                    1873 	.db #0xd9	; 217
      00BCFC 35                    1874 	.db #0x35	; 53	'5'
      00BCFD 78                    1875 	.db #0x78	; 120	'x'
      00BCFE ED                    1876 	.db #0xed	; 237
      00BCFF CD                    1877 	.db #0xcd	; 205
      00BD00 94                    1878 	.db #0x94	; 148
      00BD01 6E                    1879 	.db #0x6e	; 110	'n'
      00BD02 60                    1880 	.db #0x60	; 96
      00BD03 8E                    1881 	.db #0x8e	; 142
      00BD04 63                    1882 	.db #0x63	; 99	'c'
      00BD05 8B                    1883 	.db #0x8b	; 139
      00BD06 FF                    1884 	.db #0xff	; 255
      00BD07 4E                    1885 	.db #0x4e	; 78	'N'
      00BD08 20                    1886 	.db #0x20	; 32
      00BD09 7A                    1887 	.db #0x7a	; 122	'z'
      00BD0A B5                    1888 	.db #0xb5	; 181
      00BD0B 87                    1889 	.db #0x87	; 135
      00BD0C C2                    1890 	.db #0xc2	; 194
      00BD0D 35                    1891 	.db #0x35	; 53	'5'
      00BD0E A4                    1892 	.db #0xa4	; 164
      00BD0F 6D                    1893 	.db #0x6d	; 109	'm'
      00BD10 18                    1894 	.db #0x18	; 24
      00BD11 C1                    1895 	.db #0xc1	; 193
      00BD12 A3                    1896 	.db #0xa3	; 163
      00BD13 DB                    1897 	.db #0xdb	; 219
      00BD14 53                    1898 	.db #0x53	; 83	'S'
      00BD15 1D                    1899 	.db #0x1d	; 29
      00BD16 EC                    1900 	.db #0xec	; 236
      00BD17 F0                    1901 	.db #0xf0	; 240
      00BD18 BF                    1902 	.db #0xbf	; 191
      00BD19 4A                    1903 	.db #0x4a	; 74	'J'
      00BD1A 4C                    1904 	.db #0x4c	; 76	'L'
      00BD1B 4A                    1905 	.db #0x4a	; 74	'J'
      00BD1C C4                    1906 	.db #0xc4	; 196
      00BD1D AA                    1907 	.db #0xaa	; 170
      00BD1E 37                    1908 	.db #0x37	; 55	'7'
      00BD1F 19                    1909 	.db #0x19	; 25
      00BD20 34                    1910 	.db #0x34	; 52	'4'
      00BD21 3F                    1911 	.db #0x3f	; 63
      00BD22 A1                    1912 	.db #0xa1	; 161
      00BD23 D3                    1913 	.db #0xd3	; 211
      00BD24 1A                    1914 	.db #0x1a	; 26
      00BD25 5C                    1915 	.db #0x5c	; 92
      00BD26 03                    1916 	.db #0x03	; 3
      00BD27 4D                    1917 	.db #0x4d	; 77	'M'
      00BD28 BC                    1918 	.db #0xbc	; 188
      00BD29 10                    1919 	.db #0x10	; 16
      00BD2A 2E                    1920 	.db #0x2e	; 46
      00BD2B 80                    1921 	.db #0x80	; 128
      00BD2C F7                    1922 	.db #0xf7	; 247
      00BD2D D6                    1923 	.db #0xd6	; 214
      00BD2E 82                    1924 	.db #0x82	; 130
      00BD2F 24                    1925 	.db #0x24	; 36
      00BD30 4C                    1926 	.db #0x4c	; 76	'L'
      00BD31 87                    1927 	.db #0x87	; 135
      00BD32 B9                    1928 	.db #0xb9	; 185
      00BD33 F8                    1929 	.db #0xf8	; 248
      00BD34 BE                    1930 	.db #0xbe	; 190
      00BD35 67                    1931 	.db #0x67	; 103	'g'
      00BD36 96                    1932 	.db #0x96	; 150
      00BD37 89                    1933 	.db #0x89	; 137
      00BD38 30                    1934 	.db #0x30	; 48	'0'
      00BD39 C8                    1935 	.db #0xc8	; 200
      00BD3A 8D                    1936 	.db #0x8d	; 141
      00BD3B 2C                    1937 	.db #0x2c	; 44
      00BD3C F5                    1938 	.db #0xf5	; 245
      00BD3D 06                    1939 	.db #0x06	; 6
      00BD3E 05                    1940 	.db #0x05	; 5
      00BD3F 7C                    1941 	.db #0x7c	; 124
      00BD40 48                    1942 	.db #0x48	; 72	'H'
      00BD41 1B                    1943 	.db #0x1b	; 27
      00BD42 76                    1944 	.db #0x76	; 118	'v'
      00BD43 AA                    1945 	.db #0xaa	; 170
      00BD44 3D                    1946 	.db #0x3d	; 61
      00BD45 28                    1947 	.db #0x28	; 40
      00BD46 FC                    1948 	.db #0xfc	; 252
      00BD47 80                    1949 	.db #0x80	; 128
      00BD48 75                    1950 	.db #0x75	; 117	'u'
      00BD49 EB                    1951 	.db #0xeb	; 235
      00BD4A 78                    1952 	.db #0x78	; 120	'x'
      00BD4B D0                    1953 	.db #0xd0	; 208
      00BD4C 8A                    1954 	.db #0x8a	; 138
      00BD4D 8F                    1955 	.db #0x8f	; 143
      00BD4E 27                    1956 	.db #0x27	; 39
      00BD4F F7                    1957 	.db #0xf7	; 247
      00BD50 F2                    1958 	.db #0xf2	; 242
      00BD51 EB                    1959 	.db #0xeb	; 235
      00BD52 58                    1960 	.db #0x58	; 88	'X'
      00BD53 37                    1961 	.db #0x37	; 55	'7'
      00BD54 3C                    1962 	.db #0x3c	; 60
      00BD55 2B                    1963 	.db #0x2b	; 43
      00BD56 6F                    1964 	.db #0x6f	; 111	'o'
      00BD57 0E                    1965 	.db #0x0e	; 14
      00BD58 C7                    1966 	.db #0xc7	; 199
      00BD59 E2                    1967 	.db #0xe2	; 226
      00BD5A A0                    1968 	.db #0xa0	; 160
      00BD5B 97                    1969 	.db #0x97	; 151
      00BD5C EE                    1970 	.db #0xee	; 238
      00BD5D FD                    1971 	.db #0xfd	; 253
      00BD5E 9F                    1972 	.db #0x9f	; 159
      00BD5F 45                    1973 	.db #0x45	; 69	'E'
      00BD60 17                    1974 	.db #0x17	; 23
      00BD61 94                    1975 	.db #0x94	; 148
      00BD62 E6                    1976 	.db #0xe6	; 230
      00BD63 E7                    1977 	.db #0xe7	; 231
      00BD64 FA                    1978 	.db #0xfa	; 250
      00BD65 4C                    1979 	.db #0x4c	; 76	'L'
      00BD66 7A                    1980 	.db #0x7a	; 122	'z'
      00BD67 D6                    1981 	.db #0xd6	; 214
      00BD68 7A                    1982 	.db #0x7a	; 122	'z'
      00BD69 7B                    1983 	.db #0x7b	; 123
      00BD6A ED                    1984 	.db #0xed	; 237
      00BD6B 10                    1985 	.db #0x10	; 16
      00BD6C C5                    1986 	.db #0xc5	; 197
      00BD6D BC                    1987 	.db #0xbc	; 188
      00BD6E E3                    1988 	.db #0xe3	; 227
      00BD6F A9                    1989 	.db #0xa9	; 169
      00BD70 1F                    1990 	.db #0x1f	; 31
      00BD71 CF                    1991 	.db #0xcf	; 207
      00BD72 C4                    1992 	.db #0xc4	; 196
      00BD73 9D                    1993 	.db #0x9d	; 157
      00BD74 DC                    1994 	.db #0xdc	; 220
      00BD75 45                    1995 	.db #0x45	; 69	'E'
      00BD76 2A                    1996 	.db #0x2a	; 42
      00BD77 69                    1997 	.db #0x69	; 105	'i'
      00BD78 57                    1998 	.db #0x57	; 87	'W'
      00BD79 8F                    1999 	.db #0x8f	; 143
      00BD7A EC                    2000 	.db #0xec	; 236
      00BD7B 85                    2001 	.db #0x85	; 133
      00BD7C 6C                    2002 	.db #0x6c	; 108	'l'
      00BD7D 43                    2003 	.db #0x43	; 67	'C'
      00BD7E 1C                    2004 	.db #0x1c	; 28
      00BD7F BA                    2005 	.db #0xba	; 186
      00BD80 89                    2006 	.db #0x89	; 137
      00BD81 68                    2007 	.db #0x68	; 104	'h'
      00BD82 4A                    2008 	.db #0x4a	; 74	'J'
      00BD83 1C                    2009 	.db #0x1c	; 28
      00BD84 91                    2010 	.db #0x91	; 145
      00BD85 3F                    2011 	.db #0x3f	; 63
      00BD86 D1                    2012 	.db #0xd1	; 209
      00BD87 B3                    2013 	.db #0xb3	; 179
      00BD88 96                    2014 	.db #0x96	; 150
      00BD89 1D                    2015 	.db #0x1d	; 29
      00BD8A 7C                    2016 	.db #0x7c	; 124
      00BD8B 14                    2017 	.db #0x14	; 20
      00BD8C 77                    2018 	.db #0x77	; 119	'w'
      00BD8D 9C                    2019 	.db #0x9c	; 156
      00BD8E 74                    2020 	.db #0x74	; 116	't'
      00BD8F 36                    2021 	.db #0x36	; 54	'6'
      00BD90 FF                    2022 	.db #0xff	; 255
      00BD91 2C                    2023 	.db #0x2c	; 44
      00BD92 66                    2024 	.db #0x66	; 102	'f'
      00BD93 AF                    2025 	.db #0xaf	; 175
      00BD94 0F                    2026 	.db #0x0f	; 15
      00BD95 3C                    2027 	.db #0x3c	; 60
      00BD96 A2                    2028 	.db #0xa2	; 162
      00BD97 23                    2029 	.db #0x23	; 35
      00BD98 85                    2030 	.db #0x85	; 133
      00BD99 05                    2031 	.db #0x05	; 5
      00BD9A 87                    2032 	.db #0x87	; 135
      00BD9B DA                    2033 	.db #0xda	; 218
      00BD9C 61                    2034 	.db #0x61	; 97	'a'
      00BD9D 5E                    2035 	.db #0x5e	; 94
      00BD9E 42                    2036 	.db #0x42	; 66	'B'
      00BD9F 54                    2037 	.db #0x54	; 84	'T'
      00BDA0 60                    2038 	.db #0x60	; 96
      00BDA1 23                    2039 	.db #0x23	; 35
      00BDA2 CA                    2040 	.db #0xca	; 202
      00BDA3 BC                    2041 	.db #0xbc	; 188
      00BDA4 B3                    2042 	.db #0xb3	; 179
      00BDA5 18                    2043 	.db #0x18	; 24
      00BDA6 1D                    2044 	.db #0x1d	; 29
      00BDA7 F8                    2045 	.db #0xf8	; 248
      00BDA8 0A                    2046 	.db #0x0a	; 10
      00BDA9 55                    2047 	.db #0x55	; 85	'U'
      00BDAA CD                    2048 	.db #0xcd	; 205
      00BDAB A3                    2049 	.db #0xa3	; 163
      00BDAC DE                    2050 	.db #0xde	; 222
      00BDAD FF                    2051 	.db #0xff	; 255
      00BDAE B2                    2052 	.db #0xb2	; 178
      00BDAF 2A                    2053 	.db #0x2a	; 42
      00BDB0 35                    2054 	.db #0x35	; 53	'5'
      00BDB1 00                    2055 	.db #0x00	; 0
      00BDB2 D6                    2056 	.db #0xd6	; 214
      00BDB3 7B                    2057 	.db #0x7b	; 123
      00BDB4 E8                    2058 	.db #0xe8	; 232
      00BDB5 F2                    2059 	.db #0xf2	; 242
      00BDB6 1A                    2060 	.db #0x1a	; 26
      00BDB7 BC                    2061 	.db #0xbc	; 188
      00BDB8 F5                    2062 	.db #0xf5	; 245
      00BDB9 7E                    2063 	.db #0x7e	; 126
      00BDBA 48                    2064 	.db #0x48	; 72	'H'
      00BDBB 72                    2065 	.db #0x72	; 114	'r'
      00BDBC E0                    2066 	.db #0xe0	; 224
      00BDBD E4                    2067 	.db #0xe4	; 228
      00BDBE E0                    2068 	.db #0xe0	; 224
      00BDBF 27                    2069 	.db #0x27	; 39
      00BDC0 87                    2070 	.db #0x87	; 135
      00BDC1 9A                    2071 	.db #0x9a	; 154
      00BDC2 51                    2072 	.db #0x51	; 81	'Q'
      00BDC3 D4                    2073 	.db #0xd4	; 212
      00BDC4 DD                    2074 	.db #0xdd	; 221
      00BDC5 C3                    2075 	.db #0xc3	; 195
      00BDC6 AA                    2076 	.db #0xaa	; 170
      00BDC7 49                    2077 	.db #0x49	; 73	'I'
      00BDC8 5A                    2078 	.db #0x5a	; 90	'Z'
      00BDC9 2A                    2079 	.db #0x2a	; 42
      00BDCA 00                    2080 	.db #0x00	; 0
      00BDCB A0                    2081 	.db #0xa0	; 160
      00BDCC 8C                    2082 	.db #0x8c	; 140
      00BDCD FF                    2083 	.db #0xff	; 255
      00BDCE 74                    2084 	.db #0x74	; 116	't'
      00BDCF BF                    2085 	.db #0xbf	; 191
      00BDD0 EC                    2086 	.db #0xec	; 236
      00BDD1 1D                    2087 	.db #0x1d	; 29
      00BDD2 F1                    2088 	.db #0xf1	; 241
      00BDD3 00                    2089 	.db #0x00	; 0
      00BDD4 01                    2090 	.db #0x01	; 1
      00BDD5 D8                    2091 	.db #0xd8	; 216
      00BDD6 02                    2092 	.db #0x02	; 2
      00BDD7 CC                    2093 	.db #0xcc	; 204
      00BDD8 07                    2094 	.db #0x07	; 7
      00BDD9 00                    2095 	.db #0x00	; 0
      00BDDA 00                    2096 	.db #0x00	; 0
      00BDDB C4                    2097 	.db #0xc4	; 196
      00BDDC 5E                    2098 	.db #0x5e	; 94
      00BDDD 2C                    2099 	.db #0x2c	; 44
      00BDDE 7E                    2100 	.db #0x7e	; 126
      00BDDF B1                    2101 	.db #0xb1	; 177
      00BDE0 C4                    2102 	.db #0xc4	; 196
      00BDE1 67                    2103 	.db #0x67	; 103	'g'
      00BDE2 FB                    2104 	.db #0xfb	; 251
      00BDE3 02                    2105 	.db #0x02	; 2
      00BDE4 00                    2106 	.db #0x00	; 0
      00BDE5 00                    2107 	.db #0x00	; 0
      00BDE6 00                    2108 	.db #0x00	; 0
      00BDE7 00                    2109 	.db #0x00	; 0
      00BDE8 04                    2110 	.db #0x04	; 4
      00BDE9 59                    2111 	.db #0x59	; 89	'Y'
      00BDEA 5A                    2112 	.db #0x5a	; 90	'Z'
                                   2113 	.area CSEG    (CODE)
                                   2114 	.area CONST   (CODE)
      00BDEB                       2115 _vial_handle_cmd_keyboard_uid_40000_622:
      00BDEB 04                    2116 	.db #0x04	; 4
      00BDEC 70                    2117 	.db #0x70	; 112	'p'
      00BDED FF                    2118 	.db #0xff	; 255
      00BDEE 90                    2119 	.db #0x90	; 144
      00BDEF 01                    2120 	.db #0x01	; 1
      00BDF0 B9                    2121 	.db #0xb9	; 185
      00BDF1 15                    2122 	.db #0x15	; 21
      00BDF2 D3                    2123 	.db #0xd3	; 211
                                   2124 	.area CSEG    (CODE)
                                   2125 	.area XINIT   (CODE)
      00C021                       2126 __xinit__vial_unlocked:
      00C021 00                    2127 	.db #0x00	;  0
      00C022                       2128 __xinit__vial_unlock_in_progress:
      00C022 00                    2129 	.db #0x00	;  0
      00C023                       2130 __xinit__vial_unlock_counter:
      00C023 00                    2131 	.db #0x00	; 0
      00C024                       2132 __xinit__vial_unlock_combo_rows:
      00C024 00                    2133 	.db #0x00	; 0
      00C025 00                    2134 	.db #0x00	; 0
      00C026                       2135 __xinit__vial_unlock_combo_cols:
      00C026 00                    2136 	.db #0x00	; 0
      00C027 05                    2137 	.db #0x05	; 5
                                   2138 	.area CABS    (ABS,CODE)
                                   2139 
                                   2140 ; Experimental exact instruction outlining.
                                   2141 	.globl _ak820_outline_0004
                                   2142 	.globl _ak820_outline_0007
                                   2143 	.globl _ak820_outline_0010
                                   2144 	.globl _ak820_outline_0011
                                   2145 	.globl _ak820_outline_0012
                                   2146 	.globl _ak820_outline_0015
                                   2147 	.globl _ak820_outline_0016
                                   2148 	.globl _ak820_outline_0017
                                   2149 	.globl _ak820_outline_0021
                                   2150 	.globl _ak820_outline_0024
                                   2151 	.globl _ak820_outline_0030
                                   2152 	.globl _ak820_outline_0031
                                   2153 	.globl _ak820_outline_0034
                                   2154 	.globl _ak820_outline_0037
                                   2155 	.globl _ak820_outline_0046
                                   2156 	.globl _ak820_outline_0051
                                   2157 	.globl _ak820_outline_0054
                                   2158 	.globl _ak820_outline_0057
                                   2159 	.globl _ak820_outline_0059
                                   2160 	.globl _ak820_outline_0061
                                   2161 	.globl _ak820_outline_0073
                                   2162 	.globl _ak820_outline_0077
                                   2163 	.globl _ak820_outline_0097
                                   2164 	.globl _ak820_outline_0103
                                   2165 	.globl _ak820_outline_0104
                                   2166 	.globl _ak820_outline_0116
                                   2167 	.globl _ak820_outline_0117
                                   2168 	.globl _ak820_outline_0121
                                   2169 	.globl _ak820_outline_0122
                                   2170 	.globl _ak820_outline_0123
                                   2171 	.globl _ak820_outline_0125
                                   2172 	.globl _ak820_outline_0126
                                   2173 	.globl _ak820_outline_0131
                                   2174 	.globl _ak820_outline_0136
                                   2175 	.globl _ak820_outline_0140
                                   2176 	.globl _ak820_outline_0152
                                   2177 	.globl _ak820_outline_0166
                                   2178 
                                   2179 	.area CSEG (CODE)
                                   2180 ; function ak820_outline_0024
      00B119                       2181 _ak820_outline_0024:
      00B119 E0               [24] 2182 	movx	a,@dptr
      00B11A FE               [12] 2183 	mov	r6,a
      00B11B A3               [24] 2184 	inc	dptr
      00B11C E0               [24] 2185 	movx	a,@dptr
      00B11D FF               [12] 2186 	mov	r7,a
      00B11E 90 0C 51         [24] 2187 	mov	dptr,#_g_vial_magic_keycode_override
      00B121 EE               [12] 2188 	mov	a,r6
      00B122 F0               [24] 2189 	movx	@dptr,a
      00B123 EF               [12] 2190 	mov	a,r7
      00B124 A3               [24] 2191 	inc	dptr
      00B125 F0               [24] 2192 	movx	@dptr,a
      00B126 8E 04            [24] 2193 	mov	ar4,r6
      00B128 8F 05            [24] 2194 	mov	ar5,r7
      00B12A C3               [12] 2195 	clr	c
      00B12B 74 FF            [12] 2196 	mov	a,#0xff
      00B12D 9C               [12] 2197 	subb	a,r4
      00B12E 74 1F            [12] 2198 	mov	a,#0x1f
      00B130 9D               [12] 2199 	subb	a,r5
      00B131 22               [24] 2200 	ret
                                   2201 
                                   2202 	.area CSEG (CODE)
                                   2203 ; function ak820_outline_0073
      00B132                       2204 _ak820_outline_0073:
      00B132 A3               [24] 2205 	inc	dptr
      00B133 F0               [24] 2206 	movx	@dptr,a
      00B134 E4               [12] 2207 	clr	a
      00B135 A3               [24] 2208 	inc	dptr
      00B136 F0               [24] 2209 	movx	@dptr,a
      00B137 90 0D 7C         [24] 2210 	mov	dptr,#___memcpy_PARM_3
      00B13A 74 0A            [12] 2211 	mov	a,#0x0a
      00B13C F0               [24] 2212 	movx	@dptr,a
      00B13D E4               [12] 2213 	clr	a
      00B13E A3               [24] 2214 	inc	dptr
      00B13F F0               [24] 2215 	movx	@dptr,a
      00B140 22               [24] 2216 	ret
                                   2217 
                                   2218 	.area CSEG (CODE)
                                   2219 ; function ak820_outline_0125
      00B141                       2220 _ak820_outline_0125:
      00B141 24 FE            [12] 2221 	add	a,#_vial_unlock_combo_cols
      00B143 F5 82            [12] 2222 	mov	dpl,a
      00B145 E4               [12] 2223 	clr	a
      00B146 34 0D            [12] 2224 	addc	a,#(_vial_unlock_combo_cols>>8)
      00B148 F5 83            [12] 2225 	mov	dph,a
      00B14A E0               [24] 2226 	movx	a,@dptr
      00B14B 22               [24] 2227 	ret
                                   2228 
                                   2229 	.area CSEG (CODE)
                                   2230 ; function ak820_outline_0126
      00B14C                       2231 _ak820_outline_0126:
      00B14C 24 FC            [12] 2232 	add	a,#_vial_unlock_combo_rows
      00B14E F5 82            [12] 2233 	mov	dpl,a
      00B150 E4               [12] 2234 	clr	a
      00B151 34 0D            [12] 2235 	addc	a,#(_vial_unlock_combo_rows>>8)
      00B153 F5 83            [12] 2236 	mov	dph,a
      00B155 E0               [24] 2237 	movx	a,@dptr
      00B156 22               [24] 2238 	ret
