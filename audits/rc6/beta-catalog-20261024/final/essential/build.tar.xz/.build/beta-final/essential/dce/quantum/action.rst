                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_combo_cancel
                                     12 	.globl _ak820_combo_tick
                                     13 	.globl _ak820_oneshot_cancel
                                     14 	.globl _ak820_oneshot_post
                                     15 	.globl _ak820_oneshot_process
                                     16 	.globl _ak820_tapping_source
                                     17 	.globl _ak820_tapping_cancel
                                     18 	.globl _ak820_tapping_process
                                     19 	.globl _ak820_tapping_before
                                     20 	.globl _pre_process_record_quantum
                                     21 	.globl _get_record_keycode
                                     22 	.globl _repeat_key_cancel
                                     23 	.globl _clear_owned_usages
                                     24 	.globl _owned_usage_key
                                     25 	.globl _clear_owned_keys
                                     26 	.globl _del_owned_key
                                     27 	.globl _add_owned_key
                                     28 	.globl _clear_owned_mods
                                     29 	.globl _del_owned_weak_mods
                                     30 	.globl _add_owned_weak_mods
                                     31 	.globl _del_owned_mods
                                     32 	.globl _add_owned_mods
                                     33 	.globl _clear_weak_mods
                                     34 	.globl _clear_mods
                                     35 	.globl _send_keyboard_report
                                     36 	.globl _layer_hold_clear
                                     37 	.globl _layer_hold_off
                                     38 	.globl _layer_hold_on
                                     39 	.globl _ak820_resolve_key
                                     40 	.globl _layer_xor
                                     41 	.globl _layer_and
                                     42 	.globl _layer_or
                                     43 	.globl _layer_off
                                     44 	.globl _layer_on
                                     45 	.globl _layer_move
                                     46 	.globl _layer_clear
                                     47 	.globl _layer_state_set
                                     48 	.globl _default_layer_xor
                                     49 	.globl _default_layer_and
                                     50 	.globl _default_layer_or
                                     51 	.globl _default_layer_set
                                     52 	.globl _process_record_quantum
                                     53 	.globl _action_for_keycode
                                     54 	.globl _mDelaymS
                                     55 	.globl _host_consumer_send
                                     56 	.globl _host_system_send
                                     57 	.globl _host_keyboard_leds
                                     58 	.globl _led_set
                                     59 	.globl _clear_keys_from_report
                                     60 	.globl ___memcpy
                                     61 	.globl _ADC_START
                                     62 	.globl _S0_R_FIFO
                                     63 	.globl _S0_T_FIFO
                                     64 	.globl _S0_FREE
                                     65 	.globl _S0_IF_BYTE
                                     66 	.globl _S0_IF_FIRST
                                     67 	.globl _S0_IF_OV
                                     68 	.globl _S0_FST_ACT
                                     69 	.globl _CP_RL2
                                     70 	.globl _C_T2
                                     71 	.globl _TR2
                                     72 	.globl _EXEN2
                                     73 	.globl _TCLK
                                     74 	.globl _RCLK
                                     75 	.globl _EXF2
                                     76 	.globl _CAP1F
                                     77 	.globl _TF2
                                     78 	.globl _RI
                                     79 	.globl _TI
                                     80 	.globl _RB8
                                     81 	.globl _TB8
                                     82 	.globl _REN
                                     83 	.globl _SM2
                                     84 	.globl _SM1
                                     85 	.globl _SM0
                                     86 	.globl _IT0
                                     87 	.globl _IE0
                                     88 	.globl _IT1
                                     89 	.globl _IE1
                                     90 	.globl _TR0
                                     91 	.globl _TF0
                                     92 	.globl _TR1
                                     93 	.globl _TF1
                                     94 	.globl _P4_0
                                     95 	.globl _P4_1
                                     96 	.globl _P4_2
                                     97 	.globl _P4_3
                                     98 	.globl _P4_4
                                     99 	.globl _P4_5
                                    100 	.globl _P4_6
                                    101 	.globl _RXD
                                    102 	.globl _TXD
                                    103 	.globl _INT0
                                    104 	.globl _INT1
                                    105 	.globl _T0
                                    106 	.globl _T1
                                    107 	.globl _MOSI1
                                    108 	.globl _MISO1
                                    109 	.globl _SCK1
                                    110 	.globl _P3_0
                                    111 	.globl _P3_1
                                    112 	.globl _P3_2
                                    113 	.globl _P3_3
                                    114 	.globl _P3_4
                                    115 	.globl _P3_5
                                    116 	.globl _P3_6
                                    117 	.globl _P3_7
                                    118 	.globl _CAP1_
                                    119 	.globl _T2_
                                    120 	.globl _CAP2_
                                    121 	.globl _T2EX_
                                    122 	.globl _RXD1
                                    123 	.globl _TXD1
                                    124 	.globl _P2_0
                                    125 	.globl _P2_1
                                    126 	.globl _P2_2
                                    127 	.globl _P2_3
                                    128 	.globl _P2_4
                                    129 	.globl _P2_5
                                    130 	.globl _P2_6
                                    131 	.globl _P2_7
                                    132 	.globl _AIN0
                                    133 	.globl _AIN1
                                    134 	.globl _AIN2
                                    135 	.globl _AIN3
                                    136 	.globl _AIN4
                                    137 	.globl _AIN5
                                    138 	.globl _AIN6
                                    139 	.globl _AIN7
                                    140 	.globl _CAP1
                                    141 	.globl _T2
                                    142 	.globl _CAP2
                                    143 	.globl _T2EX
                                    144 	.globl _INT0_
                                    145 	.globl _SCS
                                    146 	.globl _MOSI
                                    147 	.globl _MISO
                                    148 	.globl _SCK
                                    149 	.globl _RXD1_
                                    150 	.globl _TXD1_
                                    151 	.globl _P1_0
                                    152 	.globl _P1_1
                                    153 	.globl _P1_2
                                    154 	.globl _P1_3
                                    155 	.globl _P1_4
                                    156 	.globl _P1_5
                                    157 	.globl _P1_6
                                    158 	.globl _P1_7
                                    159 	.globl _AIN8
                                    160 	.globl _AIN9
                                    161 	.globl _AIN10
                                    162 	.globl _AIN11
                                    163 	.globl _AIN12
                                    164 	.globl _AIN13
                                    165 	.globl _RXD_
                                    166 	.globl _TXD_
                                    167 	.globl _SCL0
                                    168 	.globl _SDA0
                                    169 	.globl _P0_0
                                    170 	.globl _P0_1
                                    171 	.globl _P0_2
                                    172 	.globl _P0_3
                                    173 	.globl _P0_4
                                    174 	.globl _P0_5
                                    175 	.globl _P0_6
                                    176 	.globl _P0_7
                                    177 	.globl _IE_SPI0
                                    178 	.globl _IE_USB
                                    179 	.globl _IE_ADC
                                    180 	.globl _IE_UART1
                                    181 	.globl _IE_PWM_I2C
                                    182 	.globl _IE_GPIO
                                    183 	.globl _IE_WDOG
                                    184 	.globl _PX0
                                    185 	.globl _PT0
                                    186 	.globl _PX1
                                    187 	.globl _PT1
                                    188 	.globl _PS
                                    189 	.globl _PT2
                                    190 	.globl _PL_FLAG
                                    191 	.globl _PH_FLAG
                                    192 	.globl _EX0
                                    193 	.globl _ET0
                                    194 	.globl _EX1
                                    195 	.globl _ET1
                                    196 	.globl _ES
                                    197 	.globl _ET2
                                    198 	.globl _E_DIS
                                    199 	.globl _EA
                                    200 	.globl _P
                                    201 	.globl _F1
                                    202 	.globl _OV
                                    203 	.globl _RS0
                                    204 	.globl _RS1
                                    205 	.globl _F0
                                    206 	.globl _AC
                                    207 	.globl _CY
                                    208 	.globl _I2CS_INT_ST
                                    209 	.globl _I2CX_INT
                                    210 	.globl _LED_STATUS
                                    211 	.globl _LED_DMA_H
                                    212 	.globl _LED_DMA_L
                                    213 	.globl _LED_DMA
                                    214 	.globl _LED_PWM_OE
                                    215 	.globl _LED_COMMON
                                    216 	.globl _ADC_CHAN
                                    217 	.globl _ADC_DAT_H
                                    218 	.globl _ADC_DAT_L
                                    219 	.globl _ADC_DAT
                                    220 	.globl _ADC_CTRL
                                    221 	.globl _SPI1_CK_SE
                                    222 	.globl _SPI1_CTRL
                                    223 	.globl _SPI1_DATA
                                    224 	.globl _SPI1_STAT
                                    225 	.globl _SIF1
                                    226 	.globl _SBAUD1
                                    227 	.globl _SBUF1
                                    228 	.globl _SCON1
                                    229 	.globl _SPI0_SETUP
                                    230 	.globl _SPI0_CK_SE
                                    231 	.globl _SPI0_CTRL
                                    232 	.globl _SPI0_DATA
                                    233 	.globl _SPI0_STAT
                                    234 	.globl _T2CAP1H
                                    235 	.globl _T2CAP1L
                                    236 	.globl _T2CAP1
                                    237 	.globl _TH2
                                    238 	.globl _TL2
                                    239 	.globl _T2COUNT
                                    240 	.globl _RCAP2H
                                    241 	.globl _RCAP2L
                                    242 	.globl _RCAP2
                                    243 	.globl _T2MOD
                                    244 	.globl _T2CON
                                    245 	.globl _SBUF
                                    246 	.globl _SCON
                                    247 	.globl _TH1
                                    248 	.globl _TH0
                                    249 	.globl _TL1
                                    250 	.globl _TL0
                                    251 	.globl _TMOD
                                    252 	.globl _TCON
                                    253 	.globl _XBUS_AUX
                                    254 	.globl _P7
                                    255 	.globl _P6_DIR
                                    256 	.globl _P6_OUT_PU
                                    257 	.globl _P6_IN
                                    258 	.globl _P5_DIR
                                    259 	.globl _P5_OUT_PU
                                    260 	.globl _P5_IN
                                    261 	.globl _P4_LED_KEY
                                    262 	.globl _P4_DIR_PU
                                    263 	.globl _P4_MOD_OC
                                    264 	.globl _P4
                                    265 	.globl _P3_DIR_PU
                                    266 	.globl _P3_MOD_OC
                                    267 	.globl _P3
                                    268 	.globl _P2_DIR_PU
                                    269 	.globl _P2_MOD_OC
                                    270 	.globl _P2
                                    271 	.globl _P1_DIR_PU
                                    272 	.globl _P1_MOD_OC
                                    273 	.globl _P1
                                    274 	.globl _P0_DIR_PU
                                    275 	.globl _P0_MOD_OC
                                    276 	.globl _P0
                                    277 	.globl _ROM_CTRL
                                    278 	.globl _ROM_DATA_HH
                                    279 	.globl _ROM_DATA_HL
                                    280 	.globl _ROM_DATA_HI
                                    281 	.globl _ROM_ADDR_H
                                    282 	.globl _ROM_ADDR_L
                                    283 	.globl _ROM_ADDR
                                    284 	.globl _GPIO_IE
                                    285 	.globl _IP_EX
                                    286 	.globl _IE_EX
                                    287 	.globl _IP
                                    288 	.globl _IE
                                    289 	.globl _WDOG_COUNT
                                    290 	.globl _RESET_KEEP
                                    291 	.globl _WAKE_CTRL
                                    292 	.globl _CLOCK_CFG
                                    293 	.globl _POWER_CFG
                                    294 	.globl _PCON
                                    295 	.globl _GLOBAL_CFG
                                    296 	.globl _SAFE_MOD
                                    297 	.globl _DPH
                                    298 	.globl _DPL
                                    299 	.globl _SP
                                    300 	.globl _A_INV
                                    301 	.globl _B
                                    302 	.globl _ACC
                                    303 	.globl _PSW
                                    304 	.globl _disable_action_cache
                                    305 	.globl _tap_code_delay_PARM_2
                                    306 	.globl _process_action_PARM_2
                                    307 	.globl _action_exec_PARM_1
                                    308 	.globl _tp_buttons
                                    309 	.globl _action_exec
                                    310 	.globl _ak820_action_exec
                                    311 	.globl _process_record
                                    312 	.globl _process_record_handler
                                    313 	.globl _process_action
                                    314 	.globl _register_code
                                    315 	.globl _unregister_code
                                    316 	.globl _tap_code_delay
                                    317 	.globl _tap_code
                                    318 	.globl _register_mods
                                    319 	.globl _unregister_mods
                                    320 	.globl _register_weak_mods
                                    321 	.globl _unregister_weak_mods
                                    322 	.globl _clear_keyboard
                                    323 	.globl _clear_keyboard_but_mods
                                    324 	.globl _clear_keyboard_but_mods_and_keys
                                    325 ;--------------------------------------------------------
                                    326 ; special function registers
                                    327 ;--------------------------------------------------------
                                    328 	.area RSEG    (ABS,DATA)
      000000                        329 	.org 0x0000
                           0000D0   330 _PSW	=	0x00d0
                           0000E0   331 _ACC	=	0x00e0
                           0000F0   332 _B	=	0x00f0
                           0000FD   333 _A_INV	=	0x00fd
                           000081   334 _SP	=	0x0081
                           000082   335 _DPL	=	0x0082
                           000083   336 _DPH	=	0x0083
                           0000A1   337 _SAFE_MOD	=	0x00a1
                           0000B1   338 _GLOBAL_CFG	=	0x00b1
                           000087   339 _PCON	=	0x0087
                           0000BA   340 _POWER_CFG	=	0x00ba
                           0000B9   341 _CLOCK_CFG	=	0x00b9
                           0000A9   342 _WAKE_CTRL	=	0x00a9
                           0000FE   343 _RESET_KEEP	=	0x00fe
                           0000FF   344 _WDOG_COUNT	=	0x00ff
                           0000A8   345 _IE	=	0x00a8
                           0000B8   346 _IP	=	0x00b8
                           0000E8   347 _IE_EX	=	0x00e8
                           0000E9   348 _IP_EX	=	0x00e9
                           0000B2   349 _GPIO_IE	=	0x00b2
                           008584   350 _ROM_ADDR	=	0x8584
                           000084   351 _ROM_ADDR_L	=	0x0084
                           000085   352 _ROM_ADDR_H	=	0x0085
                           008F8E   353 _ROM_DATA_HI	=	0x8f8e
                           00008E   354 _ROM_DATA_HL	=	0x008e
                           00008F   355 _ROM_DATA_HH	=	0x008f
                           000086   356 _ROM_CTRL	=	0x0086
                           000080   357 _P0	=	0x0080
                           0000C4   358 _P0_MOD_OC	=	0x00c4
                           0000C5   359 _P0_DIR_PU	=	0x00c5
                           000090   360 _P1	=	0x0090
                           000092   361 _P1_MOD_OC	=	0x0092
                           000093   362 _P1_DIR_PU	=	0x0093
                           0000A0   363 _P2	=	0x00a0
                           000094   364 _P2_MOD_OC	=	0x0094
                           000095   365 _P2_DIR_PU	=	0x0095
                           0000B0   366 _P3	=	0x00b0
                           000096   367 _P3_MOD_OC	=	0x0096
                           000097   368 _P3_DIR_PU	=	0x0097
                           0000C0   369 _P4	=	0x00c0
                           0000C2   370 _P4_MOD_OC	=	0x00c2
                           0000C3   371 _P4_DIR_PU	=	0x00c3
                           0000C1   372 _P4_LED_KEY	=	0x00c1
                           0000AA   373 _P5_IN	=	0x00aa
                           0000AB   374 _P5_OUT_PU	=	0x00ab
                           0000AC   375 _P5_DIR	=	0x00ac
                           0000AD   376 _P6_IN	=	0x00ad
                           0000AE   377 _P6_OUT_PU	=	0x00ae
                           0000AF   378 _P6_DIR	=	0x00af
                           0000F1   379 _P7	=	0x00f1
                           0000A2   380 _XBUS_AUX	=	0x00a2
                           000088   381 _TCON	=	0x0088
                           000089   382 _TMOD	=	0x0089
                           00008A   383 _TL0	=	0x008a
                           00008B   384 _TL1	=	0x008b
                           00008C   385 _TH0	=	0x008c
                           00008D   386 _TH1	=	0x008d
                           000098   387 _SCON	=	0x0098
                           000099   388 _SBUF	=	0x0099
                           0000C8   389 _T2CON	=	0x00c8
                           0000C9   390 _T2MOD	=	0x00c9
                           00CBCA   391 _RCAP2	=	0xcbca
                           0000CA   392 _RCAP2L	=	0x00ca
                           0000CB   393 _RCAP2H	=	0x00cb
                           00CDCC   394 _T2COUNT	=	0xcdcc
                           0000CC   395 _TL2	=	0x00cc
                           0000CD   396 _TH2	=	0x00cd
                           00CFCE   397 _T2CAP1	=	0xcfce
                           0000CE   398 _T2CAP1L	=	0x00ce
                           0000CF   399 _T2CAP1H	=	0x00cf
                           0000F8   400 _SPI0_STAT	=	0x00f8
                           0000F9   401 _SPI0_DATA	=	0x00f9
                           0000FA   402 _SPI0_CTRL	=	0x00fa
                           0000FB   403 _SPI0_CK_SE	=	0x00fb
                           0000FC   404 _SPI0_SETUP	=	0x00fc
                           0000BC   405 _SCON1	=	0x00bc
                           0000BD   406 _SBUF1	=	0x00bd
                           0000BE   407 _SBAUD1	=	0x00be
                           0000BF   408 _SIF1	=	0x00bf
                           0000B4   409 _SPI1_STAT	=	0x00b4
                           0000B5   410 _SPI1_DATA	=	0x00b5
                           0000B6   411 _SPI1_CTRL	=	0x00b6
                           0000B7   412 _SPI1_CK_SE	=	0x00b7
                           0000F3   413 _ADC_CTRL	=	0x00f3
                           00F5F4   414 _ADC_DAT	=	0xf5f4
                           0000F4   415 _ADC_DAT_L	=	0x00f4
                           0000F5   416 _ADC_DAT_H	=	0x00f5
                           0000F6   417 _ADC_CHAN	=	0x00f6
                           0000A6   418 _LED_COMMON	=	0x00a6
                           0000A7   419 _LED_PWM_OE	=	0x00a7
                           00C7C6   420 _LED_DMA	=	0xc7c6
                           0000C6   421 _LED_DMA_L	=	0x00c6
                           0000C7   422 _LED_DMA_H	=	0x00c7
                           0000F7   423 _LED_STATUS	=	0x00f7
                           0000B3   424 _I2CX_INT	=	0x00b3
                           0000BB   425 _I2CS_INT_ST	=	0x00bb
                                    426 ;--------------------------------------------------------
                                    427 ; special function bits
                                    428 ;--------------------------------------------------------
                                    429 	.area RSEG    (ABS,DATA)
      000000                        430 	.org 0x0000
                           0000D7   431 _CY	=	0x00d7
                           0000D6   432 _AC	=	0x00d6
                           0000D5   433 _F0	=	0x00d5
                           0000D4   434 _RS1	=	0x00d4
                           0000D3   435 _RS0	=	0x00d3
                           0000D2   436 _OV	=	0x00d2
                           0000D1   437 _F1	=	0x00d1
                           0000D0   438 _P	=	0x00d0
                           0000AF   439 _EA	=	0x00af
                           0000AE   440 _E_DIS	=	0x00ae
                           0000AD   441 _ET2	=	0x00ad
                           0000AC   442 _ES	=	0x00ac
                           0000AB   443 _ET1	=	0x00ab
                           0000AA   444 _EX1	=	0x00aa
                           0000A9   445 _ET0	=	0x00a9
                           0000A8   446 _EX0	=	0x00a8
                           0000BF   447 _PH_FLAG	=	0x00bf
                           0000BE   448 _PL_FLAG	=	0x00be
                           0000BD   449 _PT2	=	0x00bd
                           0000BC   450 _PS	=	0x00bc
                           0000BB   451 _PT1	=	0x00bb
                           0000BA   452 _PX1	=	0x00ba
                           0000B9   453 _PT0	=	0x00b9
                           0000B8   454 _PX0	=	0x00b8
                           0000EF   455 _IE_WDOG	=	0x00ef
                           0000EE   456 _IE_GPIO	=	0x00ee
                           0000ED   457 _IE_PWM_I2C	=	0x00ed
                           0000EC   458 _IE_UART1	=	0x00ec
                           0000EB   459 _IE_ADC	=	0x00eb
                           0000E9   460 _IE_USB	=	0x00e9
                           0000E8   461 _IE_SPI0	=	0x00e8
                           000087   462 _P0_7	=	0x0087
                           000086   463 _P0_6	=	0x0086
                           000085   464 _P0_5	=	0x0085
                           000084   465 _P0_4	=	0x0084
                           000083   466 _P0_3	=	0x0083
                           000082   467 _P0_2	=	0x0082
                           000081   468 _P0_1	=	0x0081
                           000080   469 _P0_0	=	0x0080
                           000081   470 _SDA0	=	0x0081
                           000080   471 _SCL0	=	0x0080
                           000083   472 _TXD_	=	0x0083
                           000082   473 _RXD_	=	0x0082
                           000085   474 _AIN13	=	0x0085
                           000084   475 _AIN12	=	0x0084
                           000083   476 _AIN11	=	0x0083
                           000082   477 _AIN10	=	0x0082
                           000081   478 _AIN9	=	0x0081
                           000080   479 _AIN8	=	0x0080
                           000097   480 _P1_7	=	0x0097
                           000096   481 _P1_6	=	0x0096
                           000095   482 _P1_5	=	0x0095
                           000094   483 _P1_4	=	0x0094
                           000093   484 _P1_3	=	0x0093
                           000092   485 _P1_2	=	0x0092
                           000091   486 _P1_1	=	0x0091
                           000090   487 _P1_0	=	0x0090
                           000097   488 _TXD1_	=	0x0097
                           000096   489 _RXD1_	=	0x0096
                           000097   490 _SCK	=	0x0097
                           000096   491 _MISO	=	0x0096
                           000095   492 _MOSI	=	0x0095
                           000094   493 _SCS	=	0x0094
                           000092   494 _INT0_	=	0x0092
                           000091   495 _T2EX	=	0x0091
                           000091   496 _CAP2	=	0x0091
                           000090   497 _T2	=	0x0090
                           000090   498 _CAP1	=	0x0090
                           000097   499 _AIN7	=	0x0097
                           000096   500 _AIN6	=	0x0096
                           000095   501 _AIN5	=	0x0095
                           000094   502 _AIN4	=	0x0094
                           000093   503 _AIN3	=	0x0093
                           000092   504 _AIN2	=	0x0092
                           000091   505 _AIN1	=	0x0091
                           000090   506 _AIN0	=	0x0090
                           0000A7   507 _P2_7	=	0x00a7
                           0000A6   508 _P2_6	=	0x00a6
                           0000A5   509 _P2_5	=	0x00a5
                           0000A4   510 _P2_4	=	0x00a4
                           0000A3   511 _P2_3	=	0x00a3
                           0000A2   512 _P2_2	=	0x00a2
                           0000A1   513 _P2_1	=	0x00a1
                           0000A0   514 _P2_0	=	0x00a0
                           0000A7   515 _TXD1	=	0x00a7
                           0000A6   516 _RXD1	=	0x00a6
                           0000A5   517 _T2EX_	=	0x00a5
                           0000A5   518 _CAP2_	=	0x00a5
                           0000A4   519 _T2_	=	0x00a4
                           0000A4   520 _CAP1_	=	0x00a4
                           0000B7   521 _P3_7	=	0x00b7
                           0000B6   522 _P3_6	=	0x00b6
                           0000B5   523 _P3_5	=	0x00b5
                           0000B4   524 _P3_4	=	0x00b4
                           0000B3   525 _P3_3	=	0x00b3
                           0000B2   526 _P3_2	=	0x00b2
                           0000B1   527 _P3_1	=	0x00b1
                           0000B0   528 _P3_0	=	0x00b0
                           0000B7   529 _SCK1	=	0x00b7
                           0000B6   530 _MISO1	=	0x00b6
                           0000B5   531 _MOSI1	=	0x00b5
                           0000B5   532 _T1	=	0x00b5
                           0000B4   533 _T0	=	0x00b4
                           0000B3   534 _INT1	=	0x00b3
                           0000B2   535 _INT0	=	0x00b2
                           0000B1   536 _TXD	=	0x00b1
                           0000B0   537 _RXD	=	0x00b0
                           0000C6   538 _P4_6	=	0x00c6
                           0000C5   539 _P4_5	=	0x00c5
                           0000C4   540 _P4_4	=	0x00c4
                           0000C3   541 _P4_3	=	0x00c3
                           0000C2   542 _P4_2	=	0x00c2
                           0000C1   543 _P4_1	=	0x00c1
                           0000C0   544 _P4_0	=	0x00c0
                           00008F   545 _TF1	=	0x008f
                           00008E   546 _TR1	=	0x008e
                           00008D   547 _TF0	=	0x008d
                           00008C   548 _TR0	=	0x008c
                           00008B   549 _IE1	=	0x008b
                           00008A   550 _IT1	=	0x008a
                           000089   551 _IE0	=	0x0089
                           000088   552 _IT0	=	0x0088
                           00009F   553 _SM0	=	0x009f
                           00009E   554 _SM1	=	0x009e
                           00009D   555 _SM2	=	0x009d
                           00009C   556 _REN	=	0x009c
                           00009B   557 _TB8	=	0x009b
                           00009A   558 _RB8	=	0x009a
                           000099   559 _TI	=	0x0099
                           000098   560 _RI	=	0x0098
                           0000CF   561 _TF2	=	0x00cf
                           0000CF   562 _CAP1F	=	0x00cf
                           0000CE   563 _EXF2	=	0x00ce
                           0000CD   564 _RCLK	=	0x00cd
                           0000CC   565 _TCLK	=	0x00cc
                           0000CB   566 _EXEN2	=	0x00cb
                           0000CA   567 _TR2	=	0x00ca
                           0000C9   568 _C_T2	=	0x00c9
                           0000C8   569 _CP_RL2	=	0x00c8
                           0000FF   570 _S0_FST_ACT	=	0x00ff
                           0000FE   571 _S0_IF_OV	=	0x00fe
                           0000FD   572 _S0_IF_FIRST	=	0x00fd
                           0000FC   573 _S0_IF_BYTE	=	0x00fc
                           0000FB   574 _S0_FREE	=	0x00fb
                           0000FA   575 _S0_T_FIFO	=	0x00fa
                           0000F8   576 _S0_R_FIFO	=	0x00f8
                           0000F7   577 _ADC_START	=	0x00f7
                                    578 ;--------------------------------------------------------
                                    579 ; overlayable register banks
                                    580 ;--------------------------------------------------------
                                    581 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        582 	.ds 8
                                    583 ;--------------------------------------------------------
                                    584 ; internal ram data
                                    585 ;--------------------------------------------------------
                                    586 	.area DSEG    (DATA)
      000026                        587 _process_action_sloc0_1_0:
      000026                        588 	.ds 1
                                    589 ;--------------------------------------------------------
                                    590 ; overlayable items in internal ram
                                    591 ;--------------------------------------------------------
                                    592 ;--------------------------------------------------------
                                    593 ; indirectly addressable internal ram data
                                    594 ;--------------------------------------------------------
                                    595 	.area ISEG    (DATA)
                                    596 ;--------------------------------------------------------
                                    597 ; absolute internal ram data
                                    598 ;--------------------------------------------------------
                                    599 	.area IABS    (ABS,DATA)
                                    600 	.area IABS    (ABS,DATA)
                                    601 ;--------------------------------------------------------
                                    602 ; bit data
                                    603 ;--------------------------------------------------------
                                    604 	.area BSEG    (BIT)
      00001D                        605 _process_action_sloc1_1_0:
      00001D                        606 	.ds 1
                                    607 ;--------------------------------------------------------
                                    608 ; paged external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area PSEG    (PAG,XDATA)
                                    611 ;--------------------------------------------------------
                                    612 ; uninitialized external ram data
                                    613 ;--------------------------------------------------------
                                    614 	.area XSEG    (XDATA)
      000813                        615 _tp_buttons::
      000813                        616 	.ds 2
      000815                        617 _action_exec_PARM_1:
      000815                        618 	.ds 6
      00081B                        619 _action_exec_record_10001_624:
      00081B                        620 	.ds 9
      000824                        621 _ak820_action_exec_event_10000_628:
      000824                        622 	.ds 2
      000826                        623 _ak820_action_exec_snapshot_10000_629:
      000826                        624 	.ds 6
      00082C                        625 _process_record_record_argument_10000_632:
      00082C                        626 	.ds 2
      00082E                        627 _process_record_handler_record_argument_10000_640:
      00082E                        628 	.ds 2
      000830                        629 _process_record_handler_action_10000_641:
      000830                        630 	.ds 2
      000832                        631 _process_action_PARM_2:
      000832                        632 	.ds 2
      000834                        633 _process_action_record_argument_10000_652:
      000834                        634 	.ds 2
      000836                        635 _process_action_on_40000_675:
      000836                        636 	.ds 1
      000837                        637 _register_code_code_10000_709:
      000837                        638 	.ds 1
      000838                        639 _unregister_code_code_10000_723:
      000838                        640 	.ds 1
      000839                        641 _tap_code_delay_PARM_2:
      000839                        642 	.ds 2
      00083B                        643 _tap_code_delay_code_10000_736:
      00083B                        644 	.ds 1
      00083C                        645 _tap_code_code_10000_743:
      00083C                        646 	.ds 1
      00083D                        647 _register_mods_mods_10000_745:
      00083D                        648 	.ds 1
      00083E                        649 _unregister_mods_mods_10000_749:
      00083E                        650 	.ds 1
      00083F                        651 _register_weak_mods_mods_10000_753:
      00083F                        652 	.ds 1
      000840                        653 _unregister_weak_mods_mods_10000_757:
      000840                        654 	.ds 1
                                    655 ;--------------------------------------------------------
                                    656 ; absolute external ram data
                                    657 ;--------------------------------------------------------
                                    658 	.area XABS    (ABS,XDATA)
                                    659 ;--------------------------------------------------------
                                    660 ; initialized external ram data
                                    661 ;--------------------------------------------------------
                                    662 	.area XISEG   (XDATA)
      000D99                        663 _disable_action_cache::
      000D99                        664 	.ds 1
                                    665 	.area HOME    (CODE)
                                    666 	.area GSINIT0 (CODE)
                                    667 	.area GSINIT1 (CODE)
                                    668 	.area GSINIT2 (CODE)
                                    669 	.area GSINIT3 (CODE)
                                    670 	.area GSINIT4 (CODE)
                                    671 	.area GSINIT5 (CODE)
                                    672 	.area GSINIT  (CODE)
                                    673 	.area GSFINAL (CODE)
                                    674 	.area CSEG    (CODE)
                                    675 ;--------------------------------------------------------
                                    676 ; global & static initialisations
                                    677 ;--------------------------------------------------------
                                    678 	.area HOME    (CODE)
                                    679 	.area GSINIT  (CODE)
                                    680 	.area GSFINAL (CODE)
                                    681 	.area GSINIT  (CODE)
                                    682 ;--------------------------------------------------------
                                    683 ; Home
                                    684 ;--------------------------------------------------------
                                    685 	.area HOME    (CODE)
                                    686 	.area HOME    (CODE)
                                    687 ;--------------------------------------------------------
                                    688 ; code
                                    689 ;--------------------------------------------------------
                                    690 	.area CSEG    (CODE)
                                    691 ;------------------------------------------------------------
                                    692 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    693 ;------------------------------------------------------------
                                    694 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    695 ;------------------------------------------------------------
                                    696 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    697 ;	-----------------------------------------
                           000007   698 	ar7 = 0x07
                           000006   699 	ar6 = 0x06
                           000005   700 	ar5 = 0x05
                           000004   701 	ar4 = 0x04
                           000003   702 	ar3 = 0x03
                           000002   703 	ar2 = 0x02
                           000001   704 	ar1 = 0x01
                           000000   705 	ar0 = 0x00
                                    706 ;	 function action_exec
                                    707 ;	-----------------------------------------
      00715E                        708 _action_exec:
                                    709 ;	quantum/action.c:101: ak820_combo_tick(event.time);
      00715E 90 08 17         [24]  710 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      007161 12 37 98         [24]  711 	lcall	_ak820_outline_0004
      007164 12 35 B7         [24]  712 	lcall	_ak820_combo_tick
                                    713 ;	quantum/action.c:104: if (!ak820_tapping_before(&event)) return;
      007167 90 08 15         [24]  714 	mov	dptr,#_action_exec_PARM_1
      00716A 12 45 49         [24]  715 	lcall	_ak820_tapping_before
      00716D E5 82            [12]  716 	mov	a, dpl
      00716F 70 01            [24]  717 	jnz	00102$
      007171 22               [24]  718 	ret
      007172                        719 00102$:
                                    720 ;	quantum/action.c:126: if (event.pressed) {
      007172 90 08 1A         [24]  721 	mov	dptr,#(_action_exec_PARM_1 + 0x0005)
      007175 E0               [24]  722 	movx	a,@dptr
      007176 60 03            [24]  723 	jz	00104$
                                    724 ;	quantum/action.c:128: clear_weak_mods();
      007178 12 81 32         [24]  725 	lcall	_clear_weak_mods
      00717B                        726 00104$:
                                    727 ;	quantum/action.c:140: record.event = event;
      00717B 90 0D 79         [24]  728 	mov	dptr,#___memcpy_PARM_2
      00717E 74 15            [12]  729 	mov	a,#_action_exec_PARM_1
      007180 F0               [24]  730 	movx	@dptr,a
      007181 74 08            [12]  731 	mov	a,#(_action_exec_PARM_1 >> 8)
      007183 12 77 CD         [24]  732 	lcall	_ak820_outline_0050
      007186 12 77 ED         [24]  733 	lcall	_ak820_outline_0107
      007189 90 08 1B         [24]  734 	mov	dptr,#_action_exec_record_10001_624
      00718C F5 F0            [12]  735 	mov	b,a
      00718E 12 B6 F1         [24]  736 	lcall	___memcpy
                                    737 ;	quantum/action.c:142: record.tap.count = 0;
      007191 90 08 21         [24]  738 	mov	dptr,#(_action_exec_record_10001_624 + 0x0006)
      007194 E0               [24]  739 	movx	a,@dptr
      007195 54 0F            [12]  740 	anl	a,#0x0f
      007197 F0               [24]  741 	movx	@dptr,a
                                    742 ;	quantum/action.c:147: record.keycode = 0;
      007198 90 08 22         [24]  743 	mov	dptr,#(_action_exec_record_10001_624 + 0x0007)
      00719B 12 4F FD         [24]  744 	lcall	_ak820_outline_0166
                                    745 ;	quantum/action.c:178: if (IS_NOEVENT(record.event) || pre_process_record_quantum(&record)) {
      00719E 90 08 1F         [24]  746 	mov	dptr,#(_action_exec_record_10001_624 + 0x0004)
      0071A1 E0               [24]  747 	movx	a,@dptr
      0071A2 60 0A            [24]  748 	jz	00107$
      0071A4 90 08 1B         [24]  749 	mov	dptr,#_action_exec_record_10001_624
      0071A7 12 9E 54         [24]  750 	lcall	_pre_process_record_quantum
      0071AA E5 82            [12]  751 	mov	a, dpl
      0071AC 60 10            [24]  752 	jz	00110$
      0071AE                        753 00107$:
                                    754 ;	quantum/action.c:180: if (!ak820_tapping_process(&record)) return;
      0071AE 90 08 1B         [24]  755 	mov	dptr,#_action_exec_record_10001_624
      0071B1 12 46 33         [24]  756 	lcall	_ak820_tapping_process
      0071B4 E5 82            [12]  757 	mov	a, dpl
      0071B6 70 01            [24]  758 	jnz	00106$
      0071B8 22               [24]  759 	ret
      0071B9                        760 00106$:
                                    761 ;	quantum/action.c:185: process_record(&record);
      0071B9 90 08 1B         [24]  762 	mov	dptr,#_action_exec_record_10001_624
                                    763 ;	quantum/action.c:200: }
      0071BC 21 FB            [12]  764 	ajmp	_process_record
      0071BE                        765 00110$:
      0071BE 22               [24]  766 	ret
                                    767 ;------------------------------------------------------------
                                    768 ;Allocation info for local variables in function 'ak820_action_exec'
                                    769 ;------------------------------------------------------------
                                    770 ;event         Allocated with name '_ak820_action_exec_event_10000_628'
                                    771 ;snapshot      Allocated with name '_ak820_action_exec_snapshot_10000_629'
                                    772 ;------------------------------------------------------------
                                    773 ;	quantum/action.c:203: void ak820_action_exec(const keyevent_t __xdata *event) {
                                    774 ;	-----------------------------------------
                                    775 ;	 function ak820_action_exec
                                    776 ;	-----------------------------------------
      0071BF                        777 _ak820_action_exec:
      0071BF 12 38 3B         [24]  778 	lcall	_ak820_outline_0103
      0071C2 90 08 24         [24]  779 	mov	dptr,#_ak820_action_exec_event_10000_628
      0071C5 12 38 40         [24]  780 	lcall	_ak820_outline_0104
                                    781 ;	quantum/action.c:206: keyevent_t snapshot = *event;
      0071C8 90 08 24         [24]  782 	mov	dptr,#_ak820_action_exec_event_10000_628
      0071CB 12 38 0F         [24]  783 	lcall	_ak820_outline_0058
      0071CE 90 0D 79         [24]  784 	mov	dptr,#___memcpy_PARM_2
      0071D1 ED               [12]  785 	mov	a,r5
      0071D2 12 37 D7         [24]  786 	lcall	_ak820_outline_0016
      0071D5 90 0D 7C         [24]  787 	mov	dptr,#___memcpy_PARM_3
      0071D8 12 77 ED         [24]  788 	lcall	_ak820_outline_0107
      0071DB 90 08 26         [24]  789 	mov	dptr,#_ak820_action_exec_snapshot_10000_629
      0071DE F5 F0            [12]  790 	mov	b,a
      0071E0 12 B6 F1         [24]  791 	lcall	___memcpy
                                    792 ;	quantum/action.c:207: action_exec(snapshot);
      0071E3 90 0D 79         [24]  793 	mov	dptr,#___memcpy_PARM_2
      0071E6 74 26            [12]  794 	mov	a,#_ak820_action_exec_snapshot_10000_629
      0071E8 F0               [24]  795 	movx	@dptr,a
      0071E9 74 08            [12]  796 	mov	a,#(_ak820_action_exec_snapshot_10000_629 >> 8)
      0071EB 12 77 CD         [24]  797 	lcall	_ak820_outline_0050
      0071EE 12 77 ED         [24]  798 	lcall	_ak820_outline_0107
      0071F1 90 08 15         [24]  799 	mov	dptr,#_action_exec_PARM_1
      0071F4 F5 F0            [12]  800 	mov	b,a
      0071F6 12 B6 F1         [24]  801 	lcall	___memcpy
                                    802 ;	quantum/action.c:208: }
      0071F9 21 5E            [12]  803 	ajmp	_action_exec
                                    804 ;------------------------------------------------------------
                                    805 ;Allocation info for local variables in function 'process_record_nocache'
                                    806 ;------------------------------------------------------------
                                    807 ;record        Allocated with name '_process_record_nocache_record_10000_630'
                                    808 ;------------------------------------------------------------
                                    809 ;	quantum/action.c:293: void process_record_nocache(keyrecord_t AK820_RECORD_MEM *record) {
                                    810 ;	-----------------------------------------
                                    811 ;	 function process_record
                                    812 ;	-----------------------------------------
      0071FB                        813 _process_record:
      0071FB 12 38 3B         [24]  814 	lcall	_ak820_outline_0103
      0071FE 90 08 2C         [24]  815 	mov	dptr,#_process_record_record_argument_10000_632
      007201 12 38 40         [24]  816 	lcall	_ak820_outline_0104
                                    817 ;	quantum/action.c:349: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      007204 90 08 2C         [24]  818 	mov	dptr,#_process_record_record_argument_10000_632
      007207 12 37 F8         [24]  819 	lcall	_ak820_outline_0051
                                    820 ;	quantum/action.c:353: if (IS_NOEVENT(record->event)) {
      00720A 74 04            [12]  821 	mov	a,#0x04
      00720C 12 49 04         [24]  822 	lcall	_ak820_outline_0012
      00720F 70 01            [24]  823 	jnz	00102$
                                    824 ;	quantum/action.c:354: return;
      007211 22               [24]  825 	ret
      007212                        826 00102$:
                                    827 ;	quantum/action.c:362: uint8_t oneshot_source = ak820_tapping_source(record->event.key);
      007212 8E 04            [24]  828 	mov	ar4,r6
      007214 8F 05            [24]  829 	mov	ar5,r7
      007216 90 0D 79         [24]  830 	mov	dptr,#___memcpy_PARM_2
      007219 EC               [12]  831 	mov	a,r4
      00721A F0               [24]  832 	movx	@dptr,a
      00721B ED               [12]  833 	mov	a,r5
      00721C 12 77 CD         [24]  834 	lcall	_ak820_outline_0050
      00721F 12 4F EF         [24]  835 	lcall	_ak820_outline_0106
      007222 90 06 28         [24]  836 	mov	dptr,#_ak820_tapping_source_PARM_1
      007225 F5 F0            [12]  837 	mov	b,a
      007227 C0 07            [24]  838 	push	ar7
      007229 C0 06            [24]  839 	push	ar6
      00722B 12 B6 F1         [24]  840 	lcall	___memcpy
      00722E 12 44 86         [24]  841 	lcall	_ak820_tapping_source
      007231 AD 82            [24]  842 	mov	r5, dpl
      007233 D0 06            [24]  843 	pop	ar6
      007235 D0 07            [24]  844 	pop	ar7
                                    845 ;	quantum/action.c:363: bool oneshot_pressed = record->event.pressed;
      007237 12 43 25         [24]  846 	lcall	_ak820_outline_0011
      00723A E0               [24]  847 	movx	a,@dptr
      00723B FC               [12]  848 	mov	r4,a
                                    849 ;	quantum/action.c:364: record->keycode = get_record_keycode(record, true);
      00723C 74 07            [12]  850 	mov	a,#0x07
      00723E 2E               [12]  851 	add	a, r6
      00723F FA               [12]  852 	mov	r2,a
      007240 E4               [12]  853 	clr	a
      007241 3F               [12]  854 	addc	a, r7
      007242 FB               [12]  855 	mov	r3,a
      007243 90 0B DB         [24]  856 	mov	dptr,#_get_record_keycode_PARM_2
      007246 12 49 4E         [24]  857 	lcall	_ak820_outline_0055
      007249 C0 07            [24]  858 	push	ar7
      00724B C0 06            [24]  859 	push	ar6
      00724D C0 05            [24]  860 	push	ar5
      00724F C0 04            [24]  861 	push	ar4
      007251 C0 03            [24]  862 	push	ar3
      007253 C0 02            [24]  863 	push	ar2
      007255 12 9E 17         [24]  864 	lcall	_get_record_keycode
      007258 A8 82            [24]  865 	mov	r0, dpl
      00725A A9 83            [24]  866 	mov	r1, dph
      00725C D0 02            [24]  867 	pop	ar2
      00725E D0 03            [24]  868 	pop	ar3
      007260 D0 04            [24]  869 	pop	ar4
      007262 D0 05            [24]  870 	pop	ar5
      007264 D0 06            [24]  871 	pop	ar6
      007266 D0 07            [24]  872 	pop	ar7
      007268 12 43 9C         [24]  873 	lcall	_ak820_outline_0140
      00726B E8               [12]  874 	mov	a,r0
      00726C F0               [24]  875 	movx	@dptr,a
      00726D E9               [12]  876 	mov	a,r1
      00726E A3               [24]  877 	inc	dptr
      00726F F0               [24]  878 	movx	@dptr,a
                                    879 ;	quantum/action.c:365: if (!ak820_oneshot_process(record->keycode, oneshot_source, oneshot_pressed)) return;
      007270 74 07            [12]  880 	mov	a,#0x07
      007272 12 37 DF         [24]  881 	lcall	_ak820_outline_0017
      007275 FA               [12]  882 	mov	r2,a
      007276 A3               [24]  883 	inc	dptr
      007277 E0               [24]  884 	movx	a,@dptr
      007278 FB               [12]  885 	mov	r3,a
      007279 90 06 38         [24]  886 	mov	dptr,#_ak820_oneshot_process_PARM_2
      00727C ED               [12]  887 	mov	a,r5
      00727D F0               [24]  888 	movx	@dptr,a
      00727E 90 06 39         [24]  889 	mov	dptr,#_ak820_oneshot_process_PARM_3
      007281 EC               [12]  890 	mov	a,r4
      007282 F0               [24]  891 	movx	@dptr,a
      007283 12 43 9C         [24]  892 	lcall	_ak820_outline_0140
      007286 C0 07            [24]  893 	push	ar7
      007288 C0 06            [24]  894 	push	ar6
      00728A C0 05            [24]  895 	push	ar5
      00728C C0 04            [24]  896 	push	ar4
      00728E 12 47 CF         [24]  897 	lcall	_ak820_oneshot_process
      007291 E5 82            [12]  898 	mov	a, dpl
      007293 D0 04            [24]  899 	pop	ar4
      007295 D0 05            [24]  900 	pop	ar5
      007297 D0 06            [24]  901 	pop	ar6
      007299 D0 07            [24]  902 	pop	ar7
      00729B 70 01            [24]  903 	jnz	00104$
      00729D 22               [24]  904 	ret
      00729E                        905 00104$:
                                    906 ;	quantum/action.c:367: if (!process_record_quantum(record)) {
      00729E 12 43 80         [24]  907 	lcall	_ak820_outline_0116
      0072A1 C0 07            [24]  908 	push	ar7
      0072A3 C0 06            [24]  909 	push	ar6
      0072A5 C0 05            [24]  910 	push	ar5
      0072A7 C0 04            [24]  911 	push	ar4
      0072A9 12 9E 95         [24]  912 	lcall	_process_record_quantum
      0072AC E5 82            [12]  913 	mov	a, dpl
      0072AE D0 04            [24]  914 	pop	ar4
      0072B0 D0 05            [24]  915 	pop	ar5
      0072B2 D0 06            [24]  916 	pop	ar6
      0072B4 D0 07            [24]  917 	pop	ar7
      0072B6 70 0A            [24]  918 	jnz	00106$
                                    919 ;	quantum/action.c:369: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      0072B8 90 05 98         [24]  920 	mov	dptr,#_ak820_oneshot_post_PARM_2
      0072BB EC               [12]  921 	mov	a,r4
      0072BC F0               [24]  922 	movx	@dptr,a
      0072BD 8D 82            [24]  923 	mov	dpl, r5
                                    924 ;	quantum/action.c:376: return;
      0072BF 02 2E 6F         [24]  925 	ljmp	_ak820_oneshot_post
      0072C2                        926 00106$:
                                    927 ;	quantum/action.c:382: process_record_handler(record);
      0072C2 12 43 80         [24]  928 	lcall	_ak820_outline_0116
      0072C5 C0 05            [24]  929 	push	ar5
      0072C7 C0 04            [24]  930 	push	ar4
      0072C9 51 D9            [24]  931 	acall	_process_record_handler
      0072CB D0 04            [24]  932 	pop	ar4
      0072CD D0 05            [24]  933 	pop	ar5
                                    934 ;	quantum/action.c:390: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      0072CF 90 05 98         [24]  935 	mov	dptr,#_ak820_oneshot_post_PARM_2
      0072D2 EC               [12]  936 	mov	a,r4
      0072D3 F0               [24]  937 	movx	@dptr,a
      0072D4 8D 82            [24]  938 	mov	dpl, r5
                                    939 ;	quantum/action.c:392: }
      0072D6 02 2E 6F         [24]  940 	ljmp	_ak820_oneshot_post
                                    941 ;------------------------------------------------------------
                                    942 ;Allocation info for local variables in function 'process_record_handler'
                                    943 ;------------------------------------------------------------
                                    944 ;record_argument Allocated with name '_process_record_handler_record_argument_10000_640'
                                    945 ;record        Allocated with name '_process_record_handler_record_10000_641'
                                    946 ;action        Allocated with name '_process_record_handler_action_10000_641'
                                    947 ;------------------------------------------------------------
                                    948 ;	quantum/action.c:394: void process_record_handler(keyrecord_t AK820_RECORD_MEM *record_argument) {
                                    949 ;	-----------------------------------------
                                    950 ;	 function process_record_handler
                                    951 ;	-----------------------------------------
      0072D9                        952 _process_record_handler:
      0072D9 12 38 3B         [24]  953 	lcall	_ak820_outline_0103
      0072DC 90 08 2E         [24]  954 	mov	dptr,#_process_record_handler_record_argument_10000_640
      0072DF 12 38 40         [24]  955 	lcall	_ak820_outline_0104
                                    956 ;	quantum/action.c:398: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      0072E2 90 08 2E         [24]  957 	mov	dptr,#_process_record_handler_record_argument_10000_640
      0072E5 12 37 AF         [24]  958 	lcall	_ak820_outline_0009
                                    959 ;	quantum/action.c:405: if (record->keycode) {
      0072E8 4C               [12]  960 	orl	a,r4
      0072E9 60 19            [24]  961 	jz	00102$
                                    962 ;	quantum/action.c:406: action.code = action_for_keycode(record->keycode);
      0072EB 12 38 4C         [24]  963 	lcall	_ak820_outline_0117
      0072EE C0 07            [24]  964 	push	ar7
      0072F0 C0 06            [24]  965 	push	ar6
      0072F2 12 94 F8         [24]  966 	lcall	_action_for_keycode
      0072F5 12 43 A1         [24]  967 	lcall	_ak820_outline_0145
      0072F8 D0 06            [24]  968 	pop	ar6
      0072FA D0 07            [24]  969 	pop	ar7
      0072FC 90 08 30         [24]  970 	mov	dptr,#_process_record_handler_action_10000_641
      0072FF 12 38 1D         [24]  971 	lcall	_ak820_outline_0071
      007302 80 2A            [24]  972 	sjmp	00104$
      007304                        973 00102$:
                                    974 ;	quantum/action.c:409: action.code = action_for_keycode(ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed));
      007304 12 77 B5         [24]  975 	lcall	_ak820_outline_0020
      007307 7A 00            [12]  976 	mov	r2,#0x00
      007309 12 43 96         [24]  977 	lcall	_ak820_outline_0139
      00730C 12 43 25         [24]  978 	lcall	_ak820_outline_0011
      00730F E0               [24]  979 	movx	a,@dptr
      007310 90 09 6B         [24]  980 	mov	dptr,#_ak820_resolve_key_PARM_2
      007313 F0               [24]  981 	movx	@dptr,a
      007314 12 43 C1         [24]  982 	lcall	_ak820_outline_0184
      007317 C0 07            [24]  983 	push	ar7
      007319 C0 06            [24]  984 	push	ar6
      00731B 12 7B 39         [24]  985 	lcall	_ak820_resolve_key
      00731E 12 94 F8         [24]  986 	lcall	_action_for_keycode
      007321 12 43 A1         [24]  987 	lcall	_ak820_outline_0145
      007324 D0 06            [24]  988 	pop	ar6
      007326 D0 07            [24]  989 	pop	ar7
      007328 90 08 30         [24]  990 	mov	dptr,#_process_record_handler_action_10000_641
      00732B 12 38 1D         [24]  991 	lcall	_ak820_outline_0071
                                    992 ;	quantum/action.c:418: ac_dprintf("ACTION: ");
      00732E                        993 00104$:
                                    994 ;	quantum/action.c:429: process_action(record, action);
      00732E 90 0D 79         [24]  995 	mov	dptr,#___memcpy_PARM_2
      007331 74 30            [12]  996 	mov	a,#_process_record_handler_action_10000_641
      007333 F0               [24]  997 	movx	@dptr,a
      007334 74 08            [12]  998 	mov	a,#(_process_record_handler_action_10000_641 >> 8)
      007336 12 77 CD         [24]  999 	lcall	_ak820_outline_0050
      007339 12 4F EF         [24] 1000 	lcall	_ak820_outline_0106
      00733C 90 08 32         [24] 1001 	mov	dptr,#_process_action_PARM_2
      00733F F5 F0            [12] 1002 	mov	b,a
      007341 C0 07            [24] 1003 	push	ar7
      007343 C0 06            [24] 1004 	push	ar6
      007345 12 B6 F1         [24] 1005 	lcall	___memcpy
      007348 D0 06            [24] 1006 	pop	ar6
      00734A D0 07            [24] 1007 	pop	ar7
      00734C 12 43 80         [24] 1008 	lcall	_ak820_outline_0116
                                   1009 ;	quantum/action.c:430: }
      00734F 61 51            [24] 1010 	ajmp	_process_action
                                   1011 ;------------------------------------------------------------
                                   1012 ;Allocation info for local variables in function 'register_mouse'
                                   1013 ;------------------------------------------------------------
                                   1014 ;pressed       Allocated with name '_register_mouse_PARM_2'
                                   1015 ;mouse_keycode Allocated with name '_register_mouse_mouse_keycode_10000_649'
                                   1016 ;------------------------------------------------------------
                                   1017 ;	quantum/action.c:442: void register_mouse(uint8_t mouse_keycode, bool pressed) {
                                   1018 ;	-----------------------------------------
                                   1019 ;	 function process_action
                                   1020 ;	-----------------------------------------
      007351                       1021 _process_action:
      007351 12 38 3B         [24] 1022 	lcall	_ak820_outline_0103
      007354 90 08 34         [24] 1023 	mov	dptr,#_process_action_record_argument_10000_652
      007357 12 38 40         [24] 1024 	lcall	_ak820_outline_0104
                                   1025 ;	quantum/action.c:495: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00735A 90 08 34         [24] 1026 	mov	dptr,#_process_action_record_argument_10000_652
      00735D 12 37 98         [24] 1027 	lcall	_ak820_outline_0004
                                   1028 ;	quantum/action.c:501: pressed = record->event.pressed;
      007360 A3               [24] 1029 	inc	dptr
      007361 A3               [24] 1030 	inc	dptr
      007362 A3               [24] 1031 	inc	dptr
      007363 A3               [24] 1032 	inc	dptr
      007364 A3               [24] 1033 	inc	dptr
      007365 E0               [24] 1034 	movx	a,@dptr
      007366 F5 26            [12] 1035 	mov	_process_action_sloc0_1_0,a
                                   1036 ;	quantum/action.c:525: switch (action.kind.id) {
      007368 90 08 33         [24] 1037 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      00736B E0               [24] 1038 	movx	a,@dptr
      00736C C4               [12] 1039 	swap	a
      00736D 54 0F            [12] 1040 	anl	a,#0x0f
      00736F FD               [12] 1041 	mov  r5,a
      007370 24 F4            [12] 1042 	add	a,#0xff - 0x0b
      007372 50 03            [24] 1043 	jnc	00434$
      007374 02 75 F0         [24] 1044 	ljmp	00181$
      007377                       1045 00434$:
                                   1046 ;	free result
      007377 ED               [12] 1047 	mov	a,r5
      007378 24 0A            [12] 1048 	add	a,#(00435$-3-.)
      00737A 83               [24] 1049 	movc	a,@a+pc
      00737B F5 82            [12] 1050 	mov	dpl,a
      00737D ED               [12] 1051 	mov	a,r5
      00737E 24 10            [12] 1052 	add	a,#(00436$-3-.)
      007380 83               [24] 1053 	movc	a,@a+pc
      007381 F5 83            [12] 1054 	mov	dph,a
      007383 E4               [12] 1055 	clr	a
      007384 73               [24] 1056 	jmp	@a+dptr
      007385                       1057 00435$:
      007385 9D                    1058 	.db	00102$
      007386 9D                    1059 	.db	00102$
      007387 F0                    1060 	.db	00181$
      007388 F0                    1061 	.db	00181$
      007389 25                    1062 	.db	00123$
      00738A F0                    1063 	.db	00181$
      00738B F0                    1064 	.db	00181$
      00738C F0                    1065 	.db	00181$
      00738D 85                    1066 	.db	00131$
      00738E 57                    1067 	.db	00147$
      00738F 7D                    1068 	.db	00152$
      007390 7D                    1069 	.db	00152$
      007391                       1070 00436$:
      007391 73                    1071 	.db	00102$>>8
      007392 73                    1072 	.db	00102$>>8
      007393 75                    1073 	.db	00181$>>8
      007394 75                    1074 	.db	00181$>>8
      007395 74                    1075 	.db	00123$>>8
      007396 75                    1076 	.db	00181$>>8
      007397 75                    1077 	.db	00181$>>8
      007398 75                    1078 	.db	00181$>>8
      007399 74                    1079 	.db	00131$>>8
      00739A 75                    1080 	.db	00147$>>8
      00739B 75                    1081 	.db	00152$>>8
      00739C 75                    1082 	.db	00152$>>8
                                   1083 ;	quantum/action.c:528: case ACT_RMODS: {
      00739D                       1084 00102$:
                                   1085 ;	quantum/action.c:529: mods = (action.kind.id == ACT_LMODS) ? action.key.mods : action.key.mods << 4;
      00739D 90 08 33         [24] 1086 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0073A0 E0               [24] 1087 	movx	a,@dptr
      0073A1 54 F0            [12] 1088 	anl	a,#0xf0
      0073A3 70 06            [24] 1089 	jnz	00194$
      0073A5 12 77 F4         [24] 1090 	lcall	_ak820_outline_0109
      0073A8 FD               [12] 1091 	mov	r5,a
      0073A9 80 07            [24] 1092 	sjmp	00195$
      0073AB                       1093 00194$:
      0073AB 12 77 F4         [24] 1094 	lcall	_ak820_outline_0109
      0073AE C4               [12] 1095 	swap	a
      0073AF 54 F0            [12] 1096 	anl	a,#0xf0
      0073B1 FD               [12] 1097 	mov	r5,a
      0073B2                       1098 00195$:
                                   1099 ;	quantum/action.c:531: if (pressed) {
      0073B2 E5 26            [12] 1100 	mov	a,_process_action_sloc0_1_0
      0073B4 60 34            [24] 1101 	jz	00119$
                                   1102 ;	quantum/action.c:532: if (mods) {
      0073B6 ED               [12] 1103 	mov	a,r5
      0073B7 60 28            [24] 1104 	jz	00110$
                                   1105 ;	quantum/action.c:533: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      0073B9 12 78 06         [24] 1106 	lcall	_ak820_outline_0154
      0073BC FC               [12] 1107 	mov	r4,a
      0073BD BC E0 00         [24] 1108 	cjne	r4,#0xe0,00440$
      0073C0                       1109 00440$:
      0073C0 40 07            [24] 1110 	jc	00108$
      0073C2 12 78 06         [24] 1111 	lcall	_ak820_outline_0154
      0073C5 24 18            [12] 1112 	add	a,#0xff - 0xe7
      0073C7 50 09            [24] 1113 	jnc	00104$
                                   1114 ;	free result
      0073C9                       1115 00108$:
      0073C9 7B 32            [12] 1116 	mov	r3,#_process_action_PARM_2
      0073CB 7C 08            [12] 1117 	mov	r4,#(_process_action_PARM_2 >> 8)
      0073CD 12 6D 91         [24] 1118 	lcall	_ak820_outline_0118
      0073D0 70 07            [24] 1119 	jnz	00105$
      0073D2                       1120 00104$:
                                   1121 ;	quantum/action.c:537: add_owned_mods(mods);
      0073D2 8D 82            [24] 1122 	mov	dpl, r5
      0073D4 12 7D 4F         [24] 1123 	lcall	_add_owned_mods
      0073D7 80 05            [24] 1124 	sjmp	00106$
      0073D9                       1125 00105$:
                                   1126 ;	quantum/action.c:539: add_owned_weak_mods(mods);
      0073D9 8D 82            [24] 1127 	mov	dpl, r5
      0073DB 12 7D 6C         [24] 1128 	lcall	_add_owned_weak_mods
      0073DE                       1129 00106$:
                                   1130 ;	quantum/action.c:541: send_keyboard_report();
      0073DE 12 80 82         [24] 1131 	lcall	_send_keyboard_report
      0073E1                       1132 00110$:
                                   1133 ;	quantum/action.c:543: register_code(action.key.code);
      0073E1 12 77 DD         [24] 1134 	lcall	_ak820_outline_0076
      0073E4 12 76 07         [24] 1135 	lcall	_register_code
      0073E7 02 75 F0         [24] 1136 	ljmp	00181$
      0073EA                       1137 00119$:
                                   1138 ;	quantum/action.c:545: unregister_code(action.key.code);
      0073EA 12 77 DD         [24] 1139 	lcall	_ak820_outline_0076
      0073ED C0 05            [24] 1140 	push	ar5
      0073EF 12 76 74         [24] 1141 	lcall	_unregister_code
      0073F2 D0 05            [24] 1142 	pop	ar5
                                   1143 ;	quantum/action.c:546: if (mods) {
      0073F4 ED               [12] 1144 	mov	a,r5
      0073F5 70 03            [24] 1145 	jnz	00444$
      0073F7 02 75 F0         [24] 1146 	ljmp	00181$
      0073FA                       1147 00444$:
                                   1148 ;	quantum/action.c:547: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      0073FA 12 78 06         [24] 1149 	lcall	_ak820_outline_0154
      0073FD FC               [12] 1150 	mov	r4,a
      0073FE BC E0 00         [24] 1151 	cjne	r4,#0xe0,00445$
      007401                       1152 00445$:
      007401 40 07            [24] 1153 	jc	00115$
      007403 12 78 06         [24] 1154 	lcall	_ak820_outline_0154
      007406 24 18            [12] 1155 	add	a,#0xff - 0xe7
      007408 50 09            [24] 1156 	jnc	00111$
                                   1157 ;	free result
      00740A                       1158 00115$:
      00740A 7B 32            [12] 1159 	mov	r3,#_process_action_PARM_2
      00740C 7C 08            [12] 1160 	mov	r4,#(_process_action_PARM_2 >> 8)
      00740E 12 6D 91         [24] 1161 	lcall	_ak820_outline_0118
      007411 70 07            [24] 1162 	jnz	00112$
      007413                       1163 00111$:
                                   1164 ;	quantum/action.c:548: del_owned_mods(mods);
      007413 8D 82            [24] 1165 	mov	dpl, r5
      007415 12 7D 5E         [24] 1166 	lcall	_del_owned_mods
      007418 80 05            [24] 1167 	sjmp	00113$
      00741A                       1168 00112$:
                                   1169 ;	quantum/action.c:550: del_owned_weak_mods(mods);
      00741A 8D 82            [24] 1170 	mov	dpl, r5
      00741C 12 7D 7B         [24] 1171 	lcall	_del_owned_weak_mods
      00741F                       1172 00113$:
                                   1173 ;	quantum/action.c:552: send_keyboard_report();
      00741F 12 80 82         [24] 1174 	lcall	_send_keyboard_report
                                   1175 ;	quantum/action.c:555: } break;
      007422 02 75 F0         [24] 1176 	ljmp	00181$
                                   1177 ;	quantum/action.c:632: case ACT_USAGE:
      007425                       1178 00123$:
                                   1179 ;	quantum/action.c:638: if (record->keycode >= KC_SYSTEM_POWER && record->keycode <= KC_LAUNCHPAD) {
      007425 74 07            [12] 1180 	mov	a,#0x07
      007427 12 37 E8         [24] 1181 	lcall	_ak820_outline_0031
      00742A 12 37 C3         [24] 1182 	lcall	_ak820_outline_0010
      00742D C3               [12] 1183 	clr	c
      00742E EC               [12] 1184 	mov	a,r4
      00742F 94 A5            [12] 1185 	subb	a,#0xa5
      007431 ED               [12] 1186 	mov	a,r5
      007432 94 00            [12] 1187 	subb	a,#0x00
      007434 40 15            [24] 1188 	jc	00125$
      007436 74 C2            [12] 1189 	mov	a,#0xc2
      007438 9C               [12] 1190 	subb	a,r4
      007439 E4               [12] 1191 	clr	a
      00743A 9D               [12] 1192 	subb	a,r5
      00743B 40 0E            [24] 1193 	jc	00125$
                                   1194 ;	free result
                                   1195 ;	quantum/action.c:639: owned_usage_key((uint8_t)record->keycode, pressed);
      00743D 90 0A 92         [24] 1196 	mov	dptr,#_owned_usage_key_PARM_2
      007440 E5 26            [12] 1197 	mov	a,_process_action_sloc0_1_0
      007442 F0               [24] 1198 	movx	@dptr,a
      007443 8E 82            [24] 1199 	mov	dpl, r6
      007445 12 7F 2E         [24] 1200 	lcall	_owned_usage_key
                                   1201 ;	quantum/action.c:640: break;
      007448 02 75 F0         [24] 1202 	ljmp	00181$
      00744B                       1203 00125$:
                                   1204 ;	quantum/action.c:643: switch (action.usage.page) {
      00744B 12 77 E4         [24] 1205 	lcall	_ak820_outline_0086
      00744E FF               [12] 1206 	mov	r7,a
      00744F 60 08            [24] 1207 	jz	00127$
      007451 BF 01 02         [24] 1208 	cjne	r7,#0x01,00452$
      007454 80 19            [24] 1209 	sjmp	00128$
      007456                       1210 00452$:
      007456 02 75 F0         [24] 1211 	ljmp	00181$
                                   1212 ;	quantum/action.c:644: case PAGE_SYSTEM:
      007459                       1213 00127$:
                                   1214 ;	quantum/action.c:645: host_system_send(pressed ? action.usage.code : 0);
      007459 E5 26            [12] 1215 	mov	a,_process_action_sloc0_1_0
      00745B 60 05            [24] 1216 	jz	00196$
      00745D 12 77 FB         [24] 1217 	lcall	_ak820_outline_0129
      007460 80 04            [24] 1218 	sjmp	00197$
      007462                       1219 00196$:
      007462 7E 00            [12] 1220 	mov	r6,#0x00
      007464 7F 00            [12] 1221 	mov	r7,#0x00
      007466                       1222 00197$:
      007466 12 43 80         [24] 1223 	lcall	_ak820_outline_0116
      007469 12 6E 5A         [24] 1224 	lcall	_host_system_send
                                   1225 ;	quantum/action.c:646: break;
      00746C 02 75 F0         [24] 1226 	ljmp	00181$
                                   1227 ;	quantum/action.c:647: case PAGE_CONSUMER:
      00746F                       1228 00128$:
                                   1229 ;	quantum/action.c:648: host_consumer_send(pressed ? action.usage.code : 0);
      00746F E5 26            [12] 1230 	mov	a,_process_action_sloc0_1_0
      007471 60 05            [24] 1231 	jz	00198$
      007473 12 77 FB         [24] 1232 	lcall	_ak820_outline_0129
      007476 80 04            [24] 1233 	sjmp	00199$
      007478                       1234 00198$:
      007478 7E 00            [12] 1235 	mov	r6,#0x00
      00747A 7F 00            [12] 1236 	mov	r7,#0x00
      00747C                       1237 00199$:
      00747C 12 43 80         [24] 1238 	lcall	_ak820_outline_0116
      00747F 12 6E 89         [24] 1239 	lcall	_host_consumer_send
                                   1240 ;	quantum/action.c:651: break;
      007482 02 75 F0         [24] 1241 	ljmp	00181$
                                   1242 ;	quantum/action.c:658: case ACT_LAYER: {
      007485                       1243 00131$:
                                   1244 ;	quantum/action.c:659: uint8_t on = action.layer_bitop.on;
      007485 90 08 33         [24] 1245 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007488 E0               [24] 1246 	movx	a,@dptr
      007489 54 03            [12] 1247 	anl	a,#0x03
      00748B 90 08 36         [24] 1248 	mov	dptr,#_process_action_on_40000_675
      00748E F0               [24] 1249 	movx	@dptr,a
                                   1250 ;	quantum/action.c:662: if (on ? (pressed ? (on & ON_PRESS) : (on & ON_RELEASE)) : !pressed) {
      00748F E0               [24] 1251 	movx	a,@dptr
      007490 FF               [12] 1252 	mov	r7,a
      007491 60 11            [24] 1253 	jz	00200$
      007493 E5 26            [12] 1254 	mov	a,_process_action_sloc0_1_0
      007495 60 07            [24] 1255 	jz	00202$
      007497 8F 06            [24] 1256 	mov	ar6,r7
      007499 53 06 01         [24] 1257 	anl	ar6,#0x01
      00749C 80 10            [24] 1258 	sjmp	00201$
      00749E                       1259 00202$:
      00749E 74 02            [12] 1260 	mov	a,#0x02
      0074A0 5F               [12] 1261 	anl	a,r7
      0074A1 FE               [12] 1262 	mov	r6,a
      0074A2 80 0A            [24] 1263 	sjmp	00201$
      0074A4                       1264 00200$:
      0074A4 E5 26            [12] 1265 	mov	a,_process_action_sloc0_1_0
      0074A6 B4 01 00         [24] 1266 	cjne	a,#0x01,00457$
      0074A9                       1267 00457$:
      0074A9 92 1D            [24] 1268 	mov  _process_action_sloc1_1_0,c
      0074AB E4               [12] 1269 	clr	a
      0074AC 33               [12] 1270 	rlc	a
      0074AD FE               [12] 1271 	mov	r6,a
      0074AE                       1272 00201$:
      0074AE EE               [12] 1273 	mov	a,r6
      0074AF 70 03            [24] 1274 	jnz	00458$
      0074B1 02 75 F0         [24] 1275 	ljmp	00181$
      0074B4                       1276 00458$:
                                   1277 ;	quantum/action.c:663: uint8_t shift = action.layer_bitop.part * 4;
      0074B4 12 78 06         [24] 1278 	lcall	_ak820_outline_0154
      0074B7 C4               [12] 1279 	swap	a
      0074B8 03               [12] 1280 	rr	a
      0074B9 54 07            [12] 1281 	anl	a,#0x07
      0074BB 25 E0            [12] 1282 	add	a,acc
      0074BD 25 E0            [12] 1283 	add	a,acc
      0074BF FF               [12] 1284 	mov	r7,a
                                   1285 ;	quantum/action.c:664: layer_state_t bits = ((layer_state_t)action.layer_bitop.bits) << shift;
      0074C0 12 78 06         [24] 1286 	lcall	_ak820_outline_0154
      0074C3 54 0F            [12] 1287 	anl	a,#0x0f
      0074C5 FE               [12] 1288 	mov	r6,a
      0074C6 8F F0            [24] 1289 	mov	b,r7
      0074C8 05 F0            [12] 1290 	inc	b
      0074CA EE               [12] 1291 	mov	a,r6
      0074CB 80 02            [24] 1292 	sjmp	00460$
      0074CD                       1293 00459$:
      0074CD 25 E0            [12] 1294 	add	a,acc
      0074CF                       1295 00460$:
      0074CF D5 F0 FB         [24] 1296 	djnz	b,00459$
      0074D2 FE               [12] 1297 	mov	r6,a
                                   1298 ;	quantum/action.c:665: layer_state_t mask = action.layer_bitop.xbit ? ~(((layer_state_t)0xf) << shift) : 0;
      0074D3 12 78 06         [24] 1299 	lcall	_ak820_outline_0154
      0074D6 30 E4 11         [24] 1300 	jnb	acc.4,00204$
      0074D9 8F F0            [24] 1301 	mov	b,r7
      0074DB 05 F0            [12] 1302 	inc	b
      0074DD 74 0F            [12] 1303 	mov	a,#0x0f
      0074DF 80 02            [24] 1304 	sjmp	00463$
      0074E1                       1305 00462$:
      0074E1 25 E0            [12] 1306 	add	a,acc
      0074E3                       1307 00463$:
      0074E3 D5 F0 FB         [24] 1308 	djnz	b,00462$
      0074E6 F4               [12] 1309 	cpl	a
      0074E7 FF               [12] 1310 	mov	r7,a
      0074E8 80 02            [24] 1311 	sjmp	00205$
      0074EA                       1312 00204$:
      0074EA 7F 00            [12] 1313 	mov	r7,#0x00
      0074EC                       1314 00205$:
                                   1315 ;	quantum/action.c:666: bits |= mask;
      0074EC EE               [12] 1316 	mov	a,r6
      0074ED 42 07            [12] 1317 	orl	ar7,a
                                   1318 ;	quantum/action.c:667: if (!on) {
      0074EF 90 08 36         [24] 1319 	mov	dptr,#_process_action_on_40000_675
      0074F2 E0               [24] 1320 	movx	a,@dptr
      0074F3 70 31            [24] 1321 	jnz	00143$
                                   1322 ;	quantum/action.c:668: switch (action.layer_bitop.op) {
      0074F5 12 77 E4         [24] 1323 	lcall	_ak820_outline_0086
      0074F8 FE               [12] 1324 	mov	r6,a
      0074F9 2E               [12] 1325 	add	a,r6
                                   1326 ;	quantum/action.c:669: case OP_BIT_AND: default_layer_and(bits); break;
      0074FA 90 74 FE         [24] 1327 	mov	dptr,#00465$
      0074FD 73               [24] 1328 	jmp	@a+dptr
      0074FE                       1329 00465$:
      0074FE 80 06            [24] 1330 	sjmp	00132$
      007500 80 0C            [24] 1331 	sjmp	00133$
      007502 80 12            [24] 1332 	sjmp	00134$
      007504 80 18            [24] 1333 	sjmp	00135$
      007506                       1334 00132$:
      007506 8F 82            [24] 1335 	mov	dpl, r7
      007508 12 78 5C         [24] 1336 	lcall	_default_layer_and
      00750B 02 75 F0         [24] 1337 	ljmp	00181$
                                   1338 ;	quantum/action.c:670: case OP_BIT_OR: default_layer_or(bits); break;
      00750E                       1339 00133$:
      00750E 8F 82            [24] 1340 	mov	dpl, r7
      007510 12 78 4C         [24] 1341 	lcall	_default_layer_or
      007513 02 75 F0         [24] 1342 	ljmp	00181$
                                   1343 ;	quantum/action.c:671: case OP_BIT_XOR: default_layer_xor(bits); break;
      007516                       1344 00134$:
      007516 8F 82            [24] 1345 	mov	dpl, r7
      007518 12 78 71         [24] 1346 	lcall	_default_layer_xor
      00751B 02 75 F0         [24] 1347 	ljmp	00181$
                                   1348 ;	quantum/action.c:672: case OP_BIT_SET: default_layer_set(bits); break;
      00751E                       1349 00135$:
      00751E 8F 82            [24] 1350 	mov	dpl, r7
      007520 12 78 42         [24] 1351 	lcall	_default_layer_set
                                   1352 ;	quantum/action.c:673: }
      007523 02 75 F0         [24] 1353 	ljmp	00181$
      007526                       1354 00143$:
                                   1355 ;	quantum/action.c:675: switch (action.layer_bitop.op) {
      007526 12 77 E4         [24] 1356 	lcall	_ak820_outline_0086
      007529 FE               [12] 1357 	mov	r6,a
      00752A 2E               [12] 1358 	add	a,r6
                                   1359 ;	quantum/action.c:676: case OP_BIT_AND: layer_and(bits); break;
      00752B 90 75 2F         [24] 1360 	mov	dptr,#00466$
      00752E 73               [24] 1361 	jmp	@a+dptr
      00752F                       1362 00466$:
      00752F 80 06            [24] 1363 	sjmp	00137$
      007531 80 0C            [24] 1364 	sjmp	00138$
      007533 80 12            [24] 1365 	sjmp	00139$
      007535 80 18            [24] 1366 	sjmp	00140$
      007537                       1367 00137$:
      007537 8F 82            [24] 1368 	mov	dpl, r7
      007539 12 79 E6         [24] 1369 	lcall	_layer_and
      00753C 02 75 F0         [24] 1370 	ljmp	00181$
                                   1371 ;	quantum/action.c:677: case OP_BIT_OR: layer_or(bits); break;
      00753F                       1372 00138$:
      00753F 8F 82            [24] 1373 	mov	dpl, r7
      007541 12 79 D6         [24] 1374 	lcall	_layer_or
      007544 02 75 F0         [24] 1375 	ljmp	00181$
                                   1376 ;	quantum/action.c:678: case OP_BIT_XOR: layer_xor(bits); break;
      007547                       1377 00139$:
      007547 8F 82            [24] 1378 	mov	dpl, r7
      007549 12 79 FB         [24] 1379 	lcall	_layer_xor
      00754C 02 75 F0         [24] 1380 	ljmp	00181$
                                   1381 ;	quantum/action.c:679: case OP_BIT_SET: layer_state_set(bits); break;
      00754F                       1382 00140$:
      00754F 8F 82            [24] 1383 	mov	dpl, r7
      007551 12 79 78         [24] 1384 	lcall	_layer_state_set
                                   1385 ;	quantum/action.c:683: break;
      007554 02 75 F0         [24] 1386 	ljmp	00181$
                                   1387 ;	quantum/action.c:685: case ACT_LAYER_MODS:
      007557                       1388 00147$:
                                   1389 ;	quantum/action.c:686: if (pressed) {
      007557 E5 26            [12] 1390 	mov	a,_process_action_sloc0_1_0
      007559 60 11            [24] 1391 	jz	00149$
                                   1392 ;	quantum/action.c:687: layer_hold_on(action.layer_mods.layer);
      00755B 12 77 F4         [24] 1393 	lcall	_ak820_outline_0109
      00755E F5 82            [12] 1394 	mov	dpl,a
      007560 12 78 DF         [24] 1395 	lcall	_layer_hold_on
                                   1396 ;	quantum/action.c:688: register_mods(action.layer_mods.mods);
      007563 12 77 DD         [24] 1397 	lcall	_ak820_outline_0076
      007566 12 77 27         [24] 1398 	lcall	_register_mods
      007569 02 75 F0         [24] 1399 	ljmp	00181$
      00756C                       1400 00149$:
                                   1401 ;	quantum/action.c:690: unregister_mods(action.layer_mods.mods);
      00756C 12 77 DD         [24] 1402 	lcall	_ak820_outline_0076
      00756F 12 77 3B         [24] 1403 	lcall	_unregister_mods
                                   1404 ;	quantum/action.c:691: layer_hold_off(action.layer_mods.layer);
      007572 12 77 F4         [24] 1405 	lcall	_ak820_outline_0109
      007575 F5 82            [12] 1406 	mov	dpl,a
      007577 12 79 15         [24] 1407 	lcall	_layer_hold_off
                                   1408 ;	quantum/action.c:693: break;
      00757A 02 75 F0         [24] 1409 	ljmp	00181$
                                   1410 ;	quantum/action.c:695: case ACT_LAYER_TAP_EXT:
      00757D                       1411 00152$:
                                   1412 ;	quantum/action.c:696: switch (action.layer_tap.code) {
      00757D 12 78 06         [24] 1413 	lcall	_ak820_outline_0154
      007580 FF               [12] 1414 	mov	r7,a
      007581 BF F1 02         [24] 1415 	cjne	r7,#0xf1,00468$
      007584 80 0A            [24] 1416 	sjmp	00154$
      007586                       1417 00468$:
      007586 BF F2 02         [24] 1418 	cjne	r7,#0xf2,00469$
      007589 80 19            [24] 1419 	sjmp	00155$
      00758B                       1420 00469$:
                                   1421 ;	quantum/action.c:712: momentary_layer_action:
      00758B BF F3 3B         [24] 1422 	cjne	r7,#0xf3,00160$
      00758E 80 28            [24] 1423 	sjmp	00156$
      007590                       1424 00154$:
                                   1425 ;	quantum/action.c:713: pressed ? layer_hold_on(action.layer_tap.val) : layer_hold_off(action.layer_tap.val);
      007590 E5 26            [12] 1426 	mov	a,_process_action_sloc0_1_0
      007592 60 08            [24] 1427 	jz	00206$
      007594 12 77 C4         [24] 1428 	lcall	_ak820_outline_0039
      007597 12 78 DF         [24] 1429 	lcall	_layer_hold_on
      00759A 80 54            [24] 1430 	sjmp	00181$
      00759C                       1431 00206$:
      00759C 12 77 C4         [24] 1432 	lcall	_ak820_outline_0039
      00759F 12 79 15         [24] 1433 	lcall	_layer_hold_off
                                   1434 ;	quantum/action.c:714: break;
                                   1435 ;	quantum/action.c:715: case OP_OFF_ON:
      0075A2 80 4C            [24] 1436 	sjmp	00181$
      0075A4                       1437 00155$:
                                   1438 ;	quantum/action.c:716: pressed ? layer_off(action.layer_tap.val) : layer_on(action.layer_tap.val);
      0075A4 E5 26            [12] 1439 	mov	a,_process_action_sloc0_1_0
      0075A6 60 08            [24] 1440 	jz	00208$
      0075A8 12 77 C4         [24] 1441 	lcall	_ak820_outline_0039
      0075AB 12 79 B9         [24] 1442 	lcall	_layer_off
      0075AE 80 40            [24] 1443 	sjmp	00181$
      0075B0                       1444 00208$:
      0075B0 12 77 C4         [24] 1445 	lcall	_ak820_outline_0039
      0075B3 12 79 9F         [24] 1446 	lcall	_layer_on
                                   1447 ;	quantum/action.c:717: break;
                                   1448 ;	quantum/action.c:718: case OP_SET_CLEAR:
      0075B6 80 38            [24] 1449 	sjmp	00181$
      0075B8                       1450 00156$:
                                   1451 ;	quantum/action.c:719: pressed ? layer_move(action.layer_tap.val) : layer_clear();
      0075B8 E5 26            [12] 1452 	mov	a,_process_action_sloc0_1_0
      0075BA 60 08            [24] 1453 	jz	00210$
      0075BC 12 77 C4         [24] 1454 	lcall	_ak820_outline_0039
      0075BF 12 79 8A         [24] 1455 	lcall	_layer_move
      0075C2 80 2C            [24] 1456 	sjmp	00181$
      0075C4                       1457 00210$:
      0075C4 12 79 85         [24] 1458 	lcall	_layer_clear
                                   1459 ;	quantum/action.c:720: break;
                                   1460 ;	quantum/action.c:766: default:
      0075C7 80 27            [24] 1461 	sjmp	00181$
      0075C9                       1462 00160$:
                                   1463 ;	quantum/action.c:773: if (pressed) {
      0075C9 E5 26            [12] 1464 	mov	a,_process_action_sloc0_1_0
      0075CB 60 08            [24] 1465 	jz	00163$
                                   1466 ;	quantum/action.c:775: register_code(action.layer_tap.code);
      0075CD 12 77 DD         [24] 1467 	lcall	_ak820_outline_0076
      0075D0 12 76 07         [24] 1468 	lcall	_register_code
                                   1469 ;	quantum/action.c:777: ac_dprintf("KEYMAP_TAP_KEY: Tap: unregister_code\n");
      0075D3 80 1B            [24] 1470 	sjmp	00181$
      0075D5                       1471 00163$:
                                   1472 ;	quantum/action.c:778: if (action.layer_tap.code == KC_CAPS) {
      0075D5 12 78 06         [24] 1473 	lcall	_ak820_outline_0154
      0075D8 FF               [12] 1474 	mov	r7,a
      0075D9 BF 39 0E         [24] 1475 	cjne	r7,#0x39,00175$
                                   1476 ;	quantum/action.c:779: wait_ms(TAP_HOLD_CAPS_DELAY);
      0075DC 7F 50            [12] 1477 	mov	r7,#0x50
      0075DE                       1478 00187$:
      0075DE EF               [12] 1479 	mov	a,r7
      0075DF 60 09            [24] 1480 	jz	00175$
      0075E1 90 00 01         [24] 1481 	mov	dptr,#0x0001
      0075E4 12 59 49         [24] 1482 	lcall	_mDelaymS
      0075E7 1F               [12] 1483 	dec	r7
                                   1484 ;	quantum/action.c:781: wait_ms(TAP_CODE_DELAY);
      0075E8 80 F4            [24] 1485 	sjmp	00187$
      0075EA                       1486 00175$:
                                   1487 ;	quantum/action.c:783: unregister_code(action.layer_tap.code);
      0075EA 12 77 DD         [24] 1488 	lcall	_ak820_outline_0076
      0075ED 12 76 74         [24] 1489 	lcall	_unregister_code
                                   1490 ;	quantum/action.c:866: }
      0075F0                       1491 00181$:
                                   1492 ;	quantum/action.c:887: switch (action.kind.id) {
      0075F0 90 08 33         [24] 1493 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0075F3 E0               [24] 1494 	movx	a,@dptr
      0075F4 C4               [12] 1495 	swap	a
      0075F5 54 0F            [12] 1496 	anl	a,#0x0f
      0075F7 FF               [12] 1497 	mov	r7,a
      0075F8 BF 08 02         [24] 1498 	cjne	r7,#0x08,00478$
      0075FB 80 03            [24] 1499 	sjmp	00183$
      0075FD                       1500 00478$:
      0075FD BF 09 06         [24] 1501 	cjne	r7,#0x09,00192$
                                   1502 ;	quantum/action.c:889: case ACT_LAYER_MODS:
      007600                       1503 00183$:
                                   1504 ;	quantum/action.c:894: led_set(host_keyboard_leds());
      007600 12 6D BF         [24] 1505 	lcall	_host_keyboard_leds
                                   1506 ;	quantum/action.c:898: }
                                   1507 ;	quantum/action.c:951: }
      007603 02 97 AB         [24] 1508 	ljmp	_led_set
      007606                       1509 00192$:
      007606 22               [24] 1510 	ret
                                   1511 ;------------------------------------------------------------
                                   1512 ;Allocation info for local variables in function 'register_code'
                                   1513 ;------------------------------------------------------------
                                   1514 ;code          Allocated with name '_register_code_code_10000_709'
                                   1515 ;------------------------------------------------------------
                                   1516 ;	quantum/action.c:957: __attribute__((weak)) void register_code(uint8_t code) {
                                   1517 ;	-----------------------------------------
                                   1518 ;	 function register_code
                                   1519 ;	-----------------------------------------
      007607                       1520 _register_code:
      007607 E5 82            [12] 1521 	mov	a,dpl
      007609 90 08 37         [24] 1522 	mov	dptr,#_register_code_code_10000_709
      00760C F0               [24] 1523 	movx	@dptr,a
                                   1524 ;	quantum/action.c:958: if (code == KC_NO) {
      00760D E0               [24] 1525 	movx	a,@dptr
      00760E FF               [12] 1526 	mov	r7,a
      00760F 70 01            [24] 1527 	jnz	00123$
                                   1528 ;	quantum/action.c:959: return;
      007611 22               [24] 1529 	ret
      007612                       1530 00123$:
                                   1531 ;	quantum/action.c:994: } else if (IS_BASIC_KEYCODE(code)) {
      007612 BF 04 00         [24] 1532 	cjne	r7,#0x04,00186$
      007615                       1533 00186$:
      007615 40 12            [24] 1534 	jc	00119$
      007617 EF               [12] 1535 	mov	a,r7
      007618 24 5B            [12] 1536 	add	a,#0xff - 0xa4
      00761A 40 0D            [24] 1537 	jc	00119$
                                   1538 ;	free result
                                   1539 ;	quantum/action.c:999: if (!add_owned_key(code)) return;
      00761C 8F 82            [24] 1540 	mov	dpl, r7
      00761E 12 7D EF         [24] 1541 	lcall	_add_owned_key
      007621 E5 82            [12] 1542 	mov	a, dpl
      007623 70 01            [24] 1543 	jnz	00104$
      007625 22               [24] 1544 	ret
      007626                       1545 00104$:
                                   1546 ;	quantum/action.c:1013: send_keyboard_report();
      007626 02 80 82         [24] 1547 	ljmp	_send_keyboard_report
      007629                       1548 00119$:
                                   1549 ;	quantum/action.c:1014: } else if (IS_MODIFIER_KEYCODE(code)) {
      007629 12 78 0B         [24] 1550 	lcall	_ak820_outline_0162
      00762C BF E0 00         [24] 1551 	cjne	r7,#0xe0,00190$
      00762F                       1552 00190$:
      00762F 40 1A            [24] 1553 	jc	00115$
      007631 EF               [12] 1554 	mov	a,r7
      007632 24 18            [12] 1555 	add	a,#0xff - 0xe7
      007634 40 15            [24] 1556 	jc	00115$
                                   1557 ;	free result
                                   1558 ;	quantum/action.c:1015: add_owned_mods(MOD_BIT(code));
      007636 74 07            [12] 1559 	mov	a,#0x07
      007638 5F               [12] 1560 	anl	a,r7
      007639 12 77 D6         [24] 1561 	lcall	_ak820_outline_0063
      00763C 80 02            [24] 1562 	sjmp	00194$
      00763E                       1563 00193$:
      00763E 25 E0            [12] 1564 	add	a,acc
      007640                       1565 00194$:
      007640 D5 F0 FB         [24] 1566 	djnz	b,00193$
      007643 F5 82            [12] 1567 	mov	dpl,a
      007645 12 7D 4F         [24] 1568 	lcall	_add_owned_mods
                                   1569 ;	quantum/action.c:1016: send_keyboard_report();
      007648 02 80 82         [24] 1570 	ljmp	_send_keyboard_report
      00764B                       1571 00115$:
                                   1572 ;	quantum/action.c:1019: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      00764B 12 78 0B         [24] 1573 	lcall	_ak820_outline_0162
      00764E BF A5 00         [24] 1574 	cjne	r7,#0xa5,00195$
      007651                       1575 00195$:
      007651 40 05            [24] 1576 	jc	00113$
      007653 EF               [12] 1577 	mov	a,r7
      007654 24 58            [12] 1578 	add	a,#0xff - 0xa7
      007656 50 0D            [24] 1579 	jnc	00108$
                                   1580 ;	free result
      007658                       1581 00113$:
      007658 12 78 0B         [24] 1582 	lcall	_ak820_outline_0162
      00765B BF A8 00         [24] 1583 	cjne	r7,#0xa8,00198$
      00765E                       1584 00198$:
      00765E 40 13            [24] 1585 	jc	00125$
      007660 EF               [12] 1586 	mov	a,r7
      007661 24 3D            [12] 1587 	add	a,#0xff - 0xc2
      007663 40 0E            [24] 1588 	jc	00125$
                                   1589 ;	free result
      007665                       1590 00108$:
                                   1591 ;	quantum/action.c:1021: owned_usage_key(code, true);
      007665 12 78 0B         [24] 1592 	lcall	_ak820_outline_0162
      007668 90 0A 92         [24] 1593 	mov	dptr,#_owned_usage_key_PARM_2
      00766B 74 01            [12] 1594 	mov	a,#0x01
      00766D F0               [24] 1595 	movx	@dptr,a
      00766E 8F 82            [24] 1596 	mov	dpl, r7
                                   1597 ;	quantum/action.c:1029: register_mouse(code, true);
                                   1598 ;	quantum/action.c:1031: }
      007670 02 7F 2E         [24] 1599 	ljmp	_owned_usage_key
      007673                       1600 00125$:
      007673 22               [24] 1601 	ret
                                   1602 ;------------------------------------------------------------
                                   1603 ;Allocation info for local variables in function 'unregister_code'
                                   1604 ;------------------------------------------------------------
                                   1605 ;code          Allocated with name '_unregister_code_code_10000_723'
                                   1606 ;------------------------------------------------------------
                                   1607 ;	quantum/action.c:1037: __attribute__((weak)) void unregister_code(uint8_t code) {
                                   1608 ;	-----------------------------------------
                                   1609 ;	 function unregister_code
                                   1610 ;	-----------------------------------------
      007674                       1611 _unregister_code:
      007674 E5 82            [12] 1612 	mov	a,dpl
      007676 90 08 38         [24] 1613 	mov	dptr,#_unregister_code_code_10000_723
      007679 F0               [24] 1614 	movx	@dptr,a
                                   1615 ;	quantum/action.c:1038: if (code == KC_NO) {
      00767A E0               [24] 1616 	movx	a,@dptr
      00767B FF               [12] 1617 	mov	r7,a
      00767C 70 01            [24] 1618 	jnz	00121$
                                   1619 ;	quantum/action.c:1039: return;
      00767E 22               [24] 1620 	ret
      00767F                       1621 00121$:
                                   1622 ;	quantum/action.c:1071: } else if (IS_BASIC_KEYCODE(code)) {
      00767F BF 04 00         [24] 1623 	cjne	r7,#0x04,00184$
      007682                       1624 00184$:
      007682 40 12            [24] 1625 	jc	00117$
      007684 EF               [12] 1626 	mov	a,r7
      007685 24 5B            [12] 1627 	add	a,#0xff - 0xa4
      007687 40 0D            [24] 1628 	jc	00117$
                                   1629 ;	free result
                                   1630 ;	quantum/action.c:1073: if (!del_owned_key(code)) return;
      007689 8F 82            [24] 1631 	mov	dpl, r7
      00768B 12 7E 68         [24] 1632 	lcall	_del_owned_key
      00768E E5 82            [12] 1633 	mov	a, dpl
      007690 70 01            [24] 1634 	jnz	00102$
      007692 22               [24] 1635 	ret
      007693                       1636 00102$:
                                   1637 ;	quantum/action.c:1080: send_keyboard_report();
      007693 02 80 82         [24] 1638 	ljmp	_send_keyboard_report
      007696                       1639 00117$:
                                   1640 ;	quantum/action.c:1081: } else if (IS_MODIFIER_KEYCODE(code)) {
      007696 12 78 11         [24] 1641 	lcall	_ak820_outline_0163
      007699 BF E0 00         [24] 1642 	cjne	r7,#0xe0,00188$
      00769C                       1643 00188$:
      00769C 40 1A            [24] 1644 	jc	00113$
      00769E EF               [12] 1645 	mov	a,r7
      00769F 24 18            [12] 1646 	add	a,#0xff - 0xe7
      0076A1 40 15            [24] 1647 	jc	00113$
                                   1648 ;	free result
                                   1649 ;	quantum/action.c:1082: del_owned_mods(MOD_BIT(code));
      0076A3 74 07            [12] 1650 	mov	a,#0x07
      0076A5 5F               [12] 1651 	anl	a,r7
      0076A6 12 77 D6         [24] 1652 	lcall	_ak820_outline_0063
      0076A9 80 02            [24] 1653 	sjmp	00192$
      0076AB                       1654 00191$:
      0076AB 25 E0            [12] 1655 	add	a,acc
      0076AD                       1656 00192$:
      0076AD D5 F0 FB         [24] 1657 	djnz	b,00191$
      0076B0 F5 82            [12] 1658 	mov	dpl,a
      0076B2 12 7D 5E         [24] 1659 	lcall	_del_owned_mods
                                   1660 ;	quantum/action.c:1083: send_keyboard_report();
      0076B5 02 80 82         [24] 1661 	ljmp	_send_keyboard_report
      0076B8                       1662 00113$:
                                   1663 ;	quantum/action.c:1086: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      0076B8 12 78 11         [24] 1664 	lcall	_ak820_outline_0163
      0076BB BF A5 00         [24] 1665 	cjne	r7,#0xa5,00193$
      0076BE                       1666 00193$:
      0076BE 40 05            [24] 1667 	jc	00111$
      0076C0 EF               [12] 1668 	mov	a,r7
      0076C1 24 58            [12] 1669 	add	a,#0xff - 0xa7
      0076C3 50 0D            [24] 1670 	jnc	00106$
                                   1671 ;	free result
      0076C5                       1672 00111$:
      0076C5 12 78 11         [24] 1673 	lcall	_ak820_outline_0163
      0076C8 BF A8 00         [24] 1674 	cjne	r7,#0xa8,00196$
      0076CB                       1675 00196$:
      0076CB 40 12            [24] 1676 	jc	00123$
      0076CD EF               [12] 1677 	mov	a,r7
      0076CE 24 3D            [12] 1678 	add	a,#0xff - 0xc2
      0076D0 40 0D            [24] 1679 	jc	00123$
                                   1680 ;	free result
      0076D2                       1681 00106$:
                                   1682 ;	quantum/action.c:1088: owned_usage_key(code, false);
      0076D2 12 78 11         [24] 1683 	lcall	_ak820_outline_0163
      0076D5 90 0A 92         [24] 1684 	mov	dptr,#_owned_usage_key_PARM_2
      0076D8 E4               [12] 1685 	clr	a
      0076D9 F0               [24] 1686 	movx	@dptr,a
      0076DA 8F 82            [24] 1687 	mov	dpl, r7
                                   1688 ;	quantum/action.c:1096: register_mouse(code, false);
                                   1689 ;	quantum/action.c:1098: }
      0076DC 02 7F 2E         [24] 1690 	ljmp	_owned_usage_key
      0076DF                       1691 00123$:
      0076DF 22               [24] 1692 	ret
                                   1693 ;------------------------------------------------------------
                                   1694 ;Allocation info for local variables in function 'tap_code_delay'
                                   1695 ;------------------------------------------------------------
                                   1696 ;delay         Allocated with name '_tap_code_delay_PARM_2'
                                   1697 ;code          Allocated with name '_tap_code_delay_code_10000_736'
                                   1698 ;i             Allocated with name '_tap_code_delay_i_20000_738'
                                   1699 ;i             Allocated with name '_tap_code_delay_i_50000_741'
                                   1700 ;------------------------------------------------------------
                                   1701 ;	quantum/action.c:1105: __attribute__((weak)) void tap_code_delay(uint8_t code, uint16_t delay) {
                                   1702 ;	-----------------------------------------
                                   1703 ;	 function tap_code_delay
                                   1704 ;	-----------------------------------------
      0076E0                       1705 _tap_code_delay:
      0076E0 E5 82            [12] 1706 	mov	a,dpl
      0076E2 90 08 3B         [24] 1707 	mov	dptr,#_tap_code_delay_code_10000_736
      0076E5 F0               [24] 1708 	movx	@dptr,a
                                   1709 ;	quantum/action.c:1106: register_code(code);
      0076E6 E0               [24] 1710 	movx	a,@dptr
      0076E7 FF               [12] 1711 	mov	r7,a
      0076E8 F5 82            [12] 1712 	mov	dpl,a
      0076EA C0 07            [24] 1713 	push	ar7
      0076EC D1 07            [12] 1714 	acall	_register_code
      0076EE D0 07            [24] 1715 	pop	ar7
                                   1716 ;	quantum/action.c:1107: for (uint16_t i = delay; i > 0; i--) {
      0076F0 90 08 39         [24] 1717 	mov	dptr,#_tap_code_delay_PARM_2
      0076F3 12 43 6E         [24] 1718 	lcall	_ak820_outline_0093
      0076F6                       1719 00110$:
      0076F6 ED               [12] 1720 	mov	a,r5
      0076F7 4E               [12] 1721 	orl	a,r6
      0076F8 60 0D            [24] 1722 	jz	00105$
                                   1723 ;	quantum/action.c:1108: wait_ms(1);
      0076FA 90 00 01         [24] 1724 	mov	dptr,#0x0001
      0076FD 12 59 49         [24] 1725 	lcall	_mDelaymS
                                   1726 ;	quantum/action.c:1107: for (uint16_t i = delay; i > 0; i--) {
      007700 1D               [12] 1727 	dec	r5
      007701 BD FF 01         [24] 1728 	cjne	r5,#0xff,00141$
      007704 1E               [12] 1729 	dec	r6
      007705                       1730 00141$:
      007705 80 EF            [24] 1731 	sjmp	00110$
      007707                       1732 00105$:
                                   1733 ;	quantum/action.c:1110: unregister_code(code);
      007707 8F 82            [24] 1734 	mov	dpl, r7
                                   1735 ;	quantum/action.c:1111: }
      007709 C1 74            [12] 1736 	ajmp	_unregister_code
                                   1737 ;------------------------------------------------------------
                                   1738 ;Allocation info for local variables in function 'tap_code'
                                   1739 ;------------------------------------------------------------
                                   1740 ;code          Allocated with name '_tap_code_code_10000_743'
                                   1741 ;------------------------------------------------------------
                                   1742 ;	quantum/action.c:1117: __attribute__((weak)) void tap_code(uint8_t code) {
                                   1743 ;	-----------------------------------------
                                   1744 ;	 function tap_code
                                   1745 ;	-----------------------------------------
      00770B                       1746 _tap_code:
      00770B E5 82            [12] 1747 	mov	a,dpl
      00770D 90 08 3C         [24] 1748 	mov	dptr,#_tap_code_code_10000_743
      007710 F0               [24] 1749 	movx	@dptr,a
                                   1750 ;	quantum/action.c:1118: tap_code_delay(code, code == KC_CAPS ? QS_tap_hold_caps_delay : QS_tap_code_delay);
      007711 E0               [24] 1751 	movx	a,@dptr
      007712 FF               [12] 1752 	mov	r7,a
      007713 BF 39 04         [24] 1753 	cjne	r7,#0x39,00103$
      007716 7E 50            [12] 1754 	mov	r6,#0x50
      007718 80 02            [24] 1755 	sjmp	00104$
      00771A                       1756 00103$:
      00771A 7E 00            [12] 1757 	mov	r6,#0x00
      00771C                       1758 00104$:
      00771C 90 08 39         [24] 1759 	mov	dptr,#_tap_code_delay_PARM_2
      00771F EE               [12] 1760 	mov	a,r6
      007720 12 38 57         [24] 1761 	lcall	_ak820_outline_0123
      007723 8F 82            [24] 1762 	mov	dpl, r7
                                   1763 ;	quantum/action.c:1119: }
      007725 C1 E0            [12] 1764 	ajmp	_tap_code_delay
                                   1765 ;------------------------------------------------------------
                                   1766 ;Allocation info for local variables in function 'register_mods'
                                   1767 ;------------------------------------------------------------
                                   1768 ;mods          Allocated with name '_register_mods_mods_10000_745'
                                   1769 ;------------------------------------------------------------
                                   1770 ;	quantum/action.c:1125: __attribute__((weak)) void register_mods(uint8_t mods) {
                                   1771 ;	-----------------------------------------
                                   1772 ;	 function register_mods
                                   1773 ;	-----------------------------------------
      007727                       1774 _register_mods:
      007727 E5 82            [12] 1775 	mov	a,dpl
      007729 90 08 3D         [24] 1776 	mov	dptr,#_register_mods_mods_10000_745
      00772C F0               [24] 1777 	movx	@dptr,a
                                   1778 ;	quantum/action.c:1126: if (mods) {
      00772D E0               [24] 1779 	movx	a,@dptr
      00772E FF               [12] 1780 	mov	r7,a
      00772F E0               [24] 1781 	movx	a,@dptr
      007730 60 08            [24] 1782 	jz	00103$
                                   1783 ;	quantum/action.c:1127: add_owned_mods(mods);
      007732 8F 82            [24] 1784 	mov	dpl, r7
      007734 12 7D 4F         [24] 1785 	lcall	_add_owned_mods
                                   1786 ;	quantum/action.c:1128: send_keyboard_report();
                                   1787 ;	quantum/action.c:1130: }
      007737 02 80 82         [24] 1788 	ljmp	_send_keyboard_report
      00773A                       1789 00103$:
      00773A 22               [24] 1790 	ret
                                   1791 ;------------------------------------------------------------
                                   1792 ;Allocation info for local variables in function 'unregister_mods'
                                   1793 ;------------------------------------------------------------
                                   1794 ;mods          Allocated with name '_unregister_mods_mods_10000_749'
                                   1795 ;------------------------------------------------------------
                                   1796 ;	quantum/action.c:1136: __attribute__((weak)) void unregister_mods(uint8_t mods) {
                                   1797 ;	-----------------------------------------
                                   1798 ;	 function unregister_mods
                                   1799 ;	-----------------------------------------
      00773B                       1800 _unregister_mods:
      00773B E5 82            [12] 1801 	mov	a,dpl
      00773D 90 08 3E         [24] 1802 	mov	dptr,#_unregister_mods_mods_10000_749
      007740 F0               [24] 1803 	movx	@dptr,a
                                   1804 ;	quantum/action.c:1137: if (mods) {
      007741 E0               [24] 1805 	movx	a,@dptr
      007742 FF               [12] 1806 	mov	r7,a
      007743 E0               [24] 1807 	movx	a,@dptr
      007744 60 08            [24] 1808 	jz	00103$
                                   1809 ;	quantum/action.c:1138: del_owned_mods(mods);
      007746 8F 82            [24] 1810 	mov	dpl, r7
      007748 12 7D 5E         [24] 1811 	lcall	_del_owned_mods
                                   1812 ;	quantum/action.c:1139: send_keyboard_report();
                                   1813 ;	quantum/action.c:1141: }
      00774B 02 80 82         [24] 1814 	ljmp	_send_keyboard_report
      00774E                       1815 00103$:
      00774E 22               [24] 1816 	ret
                                   1817 ;------------------------------------------------------------
                                   1818 ;Allocation info for local variables in function 'register_weak_mods'
                                   1819 ;------------------------------------------------------------
                                   1820 ;mods          Allocated with name '_register_weak_mods_mods_10000_753'
                                   1821 ;------------------------------------------------------------
                                   1822 ;	quantum/action.c:1147: __attribute__((weak)) void register_weak_mods(uint8_t mods) {
                                   1823 ;	-----------------------------------------
                                   1824 ;	 function register_weak_mods
                                   1825 ;	-----------------------------------------
      00774F                       1826 _register_weak_mods:
      00774F E5 82            [12] 1827 	mov	a,dpl
      007751 90 08 3F         [24] 1828 	mov	dptr,#_register_weak_mods_mods_10000_753
      007754 F0               [24] 1829 	movx	@dptr,a
                                   1830 ;	quantum/action.c:1148: if (mods) {
      007755 E0               [24] 1831 	movx	a,@dptr
      007756 FF               [12] 1832 	mov	r7,a
      007757 E0               [24] 1833 	movx	a,@dptr
      007758 60 08            [24] 1834 	jz	00103$
                                   1835 ;	quantum/action.c:1149: add_owned_weak_mods(mods);
      00775A 8F 82            [24] 1836 	mov	dpl, r7
      00775C 12 7D 6C         [24] 1837 	lcall	_add_owned_weak_mods
                                   1838 ;	quantum/action.c:1150: send_keyboard_report();
                                   1839 ;	quantum/action.c:1152: }
      00775F 02 80 82         [24] 1840 	ljmp	_send_keyboard_report
      007762                       1841 00103$:
      007762 22               [24] 1842 	ret
                                   1843 ;------------------------------------------------------------
                                   1844 ;Allocation info for local variables in function 'unregister_weak_mods'
                                   1845 ;------------------------------------------------------------
                                   1846 ;mods          Allocated with name '_unregister_weak_mods_mods_10000_757'
                                   1847 ;------------------------------------------------------------
                                   1848 ;	quantum/action.c:1158: __attribute__((weak)) void unregister_weak_mods(uint8_t mods) {
                                   1849 ;	-----------------------------------------
                                   1850 ;	 function unregister_weak_mods
                                   1851 ;	-----------------------------------------
      007763                       1852 _unregister_weak_mods:
      007763 E5 82            [12] 1853 	mov	a,dpl
      007765 90 08 40         [24] 1854 	mov	dptr,#_unregister_weak_mods_mods_10000_757
      007768 F0               [24] 1855 	movx	@dptr,a
                                   1856 ;	quantum/action.c:1159: if (mods) {
      007769 E0               [24] 1857 	movx	a,@dptr
      00776A FF               [12] 1858 	mov	r7,a
      00776B E0               [24] 1859 	movx	a,@dptr
      00776C 60 08            [24] 1860 	jz	00103$
                                   1861 ;	quantum/action.c:1160: del_owned_weak_mods(mods);
      00776E 8F 82            [24] 1862 	mov	dpl, r7
      007770 12 7D 7B         [24] 1863 	lcall	_del_owned_weak_mods
                                   1864 ;	quantum/action.c:1161: send_keyboard_report();
                                   1865 ;	quantum/action.c:1163: }
      007773 02 80 82         [24] 1866 	ljmp	_send_keyboard_report
      007776                       1867 00103$:
      007776 22               [24] 1868 	ret
                                   1869 ;------------------------------------------------------------
                                   1870 ;Allocation info for local variables in function 'clear_keyboard'
                                   1871 ;------------------------------------------------------------
                                   1872 ;	quantum/action.c:1169: void clear_keyboard(void) {
                                   1873 ;	-----------------------------------------
                                   1874 ;	 function clear_keyboard
                                   1875 ;	-----------------------------------------
      007777                       1876 _clear_keyboard:
                                   1877 ;	quantum/action.c:1170: clear_mods();
      007777 12 80 FD         [24] 1878 	lcall	_clear_mods
                                   1879 ;	quantum/action.c:1171: clear_keyboard_but_mods();
                                   1880 ;	quantum/action.c:1172: }
      00777A E1 7C            [12] 1881 	ajmp	_clear_keyboard_but_mods
                                   1882 ;------------------------------------------------------------
                                   1883 ;Allocation info for local variables in function 'clear_keyboard_but_mods'
                                   1884 ;------------------------------------------------------------
                                   1885 ;	quantum/action.c:1178: void clear_keyboard_but_mods(void) {
                                   1886 ;	-----------------------------------------
                                   1887 ;	 function clear_keyboard_but_mods
                                   1888 ;	-----------------------------------------
      00777C                       1889 _clear_keyboard_but_mods:
                                   1890 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      00777C 90 0D 9E         [24] 1891 	mov	dptr,#_actual_keyboard_report
      00777F 11 7C            [12] 1892 	acall	_clear_keys_from_report
                                   1893 ;	quantum/action.c:1180: clear_keyboard_but_mods_and_keys();
                                   1894 ;	quantum/action.c:1181: }
      007781 E1 83            [12] 1895 	ajmp	_clear_keyboard_but_mods_and_keys
                                   1896 ;------------------------------------------------------------
                                   1897 ;Allocation info for local variables in function 'clear_keyboard_but_mods_and_keys'
                                   1898 ;------------------------------------------------------------
                                   1899 ;	quantum/action.c:1187: void clear_keyboard_but_mods_and_keys(void) {
                                   1900 ;	-----------------------------------------
                                   1901 ;	 function clear_keyboard_but_mods_and_keys
                                   1902 ;	-----------------------------------------
      007783                       1903 _clear_keyboard_but_mods_and_keys:
                                   1904 ;	quantum/action.c:1189: ak820_tapping_cancel();
      007783 12 47 AE         [24] 1905 	lcall	_ak820_tapping_cancel
                                   1906 ;	quantum/action.c:1206: ak820_oneshot_cancel();
      007786 12 2E A4         [24] 1907 	lcall	_ak820_oneshot_cancel
                                   1908 ;	quantum/action.c:1209: ak820_combo_cancel();
      007789 12 35 27         [24] 1909 	lcall	_ak820_combo_cancel
                                   1910 ;	quantum/action.c:1212: repeat_key_cancel();
      00778C 12 A0 87         [24] 1911 	lcall	_repeat_key_cancel
                                   1912 ;	quantum/action.c:1214: clear_owned_mods();
      00778F 12 7D 8A         [24] 1913 	lcall	_clear_owned_mods
                                   1914 ;	quantum/action.c:1215: clear_owned_keys();
      007792 12 7D C2         [24] 1915 	lcall	_clear_owned_keys
                                   1916 ;	quantum/action.c:1216: clear_owned_usages();
      007795 12 7E F6         [24] 1917 	lcall	_clear_owned_usages
                                   1918 ;	quantum/action.c:1217: layer_hold_clear();
      007798 12 79 4B         [24] 1919 	lcall	_layer_hold_clear
                                   1920 ;	quantum/action.c:1219: clear_macro_tri_layer();
      00779B 12 9C 31         [24] 1921 	lcall	_clear_macro_tri_layer
                                   1922 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      00779E 90 0D 9E         [24] 1923 	mov	dptr,#_actual_keyboard_report
      0077A1 11 7C            [12] 1924 	acall	_clear_keys_from_report
                                   1925 ;	quantum/action.c:1224: host_system_send(0);
      0077A3 90 00 00         [24] 1926 	mov	dptr,#0x0000
      0077A6 12 6E 5A         [24] 1927 	lcall	_host_system_send
                                   1928 ;	quantum/action.c:1225: host_consumer_send(0);
      0077A9 90 00 00         [24] 1929 	mov	dptr,#0x0000
      0077AC 12 6E 89         [24] 1930 	lcall	_host_consumer_send
                                   1931 ;	quantum/action.c:1227: clear_weak_mods();
      0077AF 12 81 32         [24] 1932 	lcall	_clear_weak_mods
                                   1933 ;	quantum/action.c:1228: send_keyboard_report();
                                   1934 ;	quantum/action.c:1236: }
      0077B2 02 80 82         [24] 1935 	ljmp	_send_keyboard_report
                                   1936 ;------------------------------------------------------------
                                   1937 ;Allocation info for local variables in function 'is_tap_record'
                                   1938 ;------------------------------------------------------------
                                   1939 ;record        Allocated with name '_is_tap_record_record_10000_773'
                                   1940 ;action        Allocated with name '_is_tap_record_action_10001_777'
                                   1941 ;------------------------------------------------------------
                                   1942 ;	quantum/action.c:1242: bool is_tap_record(keyrecord_t *record) {
                                   1943 ;	-----------------------------------------
                                   1944 	.area CSEG    (CODE)
                                   1945 	.area CONST   (CODE)
                                   1946 	.area XINIT   (CODE)
      00BFC1                       1947 __xinit__disable_action_cache:
      00BFC1 00                    1948 	.db #0x00	;  0
                                   1949 	.area CABS    (ABS,CODE)
                                   1950 
                                   1951 ; Experimental exact instruction outlining.
                                   1952 	.globl _ak820_outline_0004
                                   1953 	.globl _ak820_outline_0009
                                   1954 	.globl _ak820_outline_0010
                                   1955 	.globl _ak820_outline_0011
                                   1956 	.globl _ak820_outline_0012
                                   1957 	.globl _ak820_outline_0016
                                   1958 	.globl _ak820_outline_0017
                                   1959 	.globl _ak820_outline_0020
                                   1960 	.globl _ak820_outline_0031
                                   1961 	.globl _ak820_outline_0039
                                   1962 	.globl _ak820_outline_0050
                                   1963 	.globl _ak820_outline_0051
                                   1964 	.globl _ak820_outline_0055
                                   1965 	.globl _ak820_outline_0058
                                   1966 	.globl _ak820_outline_0063
                                   1967 	.globl _ak820_outline_0071
                                   1968 	.globl _ak820_outline_0076
                                   1969 	.globl _ak820_outline_0086
                                   1970 	.globl _ak820_outline_0093
                                   1971 	.globl _ak820_outline_0103
                                   1972 	.globl _ak820_outline_0104
                                   1973 	.globl _ak820_outline_0106
                                   1974 	.globl _ak820_outline_0107
                                   1975 	.globl _ak820_outline_0109
                                   1976 	.globl _ak820_outline_0116
                                   1977 	.globl _ak820_outline_0117
                                   1978 	.globl _ak820_outline_0118
                                   1979 	.globl _ak820_outline_0123
                                   1980 	.globl _ak820_outline_0129
                                   1981 	.globl _ak820_outline_0139
                                   1982 	.globl _ak820_outline_0140
                                   1983 	.globl _ak820_outline_0145
                                   1984 	.globl _ak820_outline_0154
                                   1985 	.globl _ak820_outline_0162
                                   1986 	.globl _ak820_outline_0163
                                   1987 	.globl _ak820_outline_0166
                                   1988 	.globl _ak820_outline_0184
                                   1989 
                                   1990 	.area CSEG (CODE)
                                   1991 ; function ak820_outline_0020
      0077B5                       1992 _ak820_outline_0020:
      0077B5 8E 82            [24] 1993 	mov	dpl,r6
      0077B7 8F 83            [24] 1994 	mov	dph,r7
      0077B9 A3               [24] 1995 	inc	dptr
      0077BA E0               [24] 1996 	movx	a,@dptr
      0077BB FC               [12] 1997 	mov	r4,a
      0077BC 7D 00            [12] 1998 	mov	r5,#0x00
      0077BE 8E 82            [24] 1999 	mov	dpl,r6
      0077C0 8F 83            [24] 2000 	mov	dph,r7
      0077C2 E0               [24] 2001 	movx	a,@dptr
      0077C3 22               [24] 2002 	ret
                                   2003 
                                   2004 	.area CSEG (CODE)
                                   2005 ; function ak820_outline_0039
      0077C4                       2006 _ak820_outline_0039:
      0077C4 90 08 33         [24] 2007 	mov	dptr,#(_process_action_PARM_2+0x0001)
      0077C7 E0               [24] 2008 	movx	a,@dptr
      0077C8 54 1F            [12] 2009 	anl	a,#0x1f
      0077CA F5 82            [12] 2010 	mov	dpl,a
      0077CC 22               [24] 2011 	ret
                                   2012 
                                   2013 	.area CSEG (CODE)
                                   2014 ; function ak820_outline_0050
      0077CD                       2015 _ak820_outline_0050:
      0077CD A3               [24] 2016 	inc	dptr
      0077CE F0               [24] 2017 	movx	@dptr,a
      0077CF E4               [12] 2018 	clr	a
      0077D0 A3               [24] 2019 	inc	dptr
      0077D1 F0               [24] 2020 	movx	@dptr,a
      0077D2 90 0D 7C         [24] 2021 	mov	dptr,#___memcpy_PARM_3
      0077D5 22               [24] 2022 	ret
                                   2023 
                                   2024 	.area CSEG (CODE)
                                   2025 ; function ak820_outline_0063
      0077D6                       2026 _ak820_outline_0063:
      0077D6 F5 F0            [12] 2027 	mov	b,a
      0077D8 05 F0            [12] 2028 	inc	b
      0077DA 74 01            [12] 2029 	mov	a,#0x01
      0077DC 22               [24] 2030 	ret
                                   2031 
                                   2032 	.area CSEG (CODE)
                                   2033 ; function ak820_outline_0076
      0077DD                       2034 _ak820_outline_0076:
      0077DD 90 08 32         [24] 2035 	mov	dptr,#_process_action_PARM_2
      0077E0 E0               [24] 2036 	movx	a,@dptr
      0077E1 F5 82            [12] 2037 	mov	dpl,a
      0077E3 22               [24] 2038 	ret
                                   2039 
                                   2040 	.area CSEG (CODE)
                                   2041 ; function ak820_outline_0086
      0077E4                       2042 _ak820_outline_0086:
      0077E4 90 08 33         [24] 2043 	mov	dptr,#(_process_action_PARM_2+0x0001)
      0077E7 E0               [24] 2044 	movx	a,@dptr
      0077E8 03               [12] 2045 	rr	a
      0077E9 03               [12] 2046 	rr	a
      0077EA 54 03            [12] 2047 	anl	a,#0x03
      0077EC 22               [24] 2048 	ret
                                   2049 
                                   2050 	.area CSEG (CODE)
                                   2051 ; function ak820_outline_0107
      0077ED                       2052 _ak820_outline_0107:
      0077ED 74 06            [12] 2053 	mov	a,#0x06
      0077EF F0               [24] 2054 	movx	@dptr,a
      0077F0 E4               [12] 2055 	clr	a
      0077F1 A3               [24] 2056 	inc	dptr
      0077F2 F0               [24] 2057 	movx	@dptr,a
      0077F3 22               [24] 2058 	ret
                                   2059 
                                   2060 	.area CSEG (CODE)
                                   2061 ; function ak820_outline_0109
      0077F4                       2062 _ak820_outline_0109:
      0077F4 90 08 33         [24] 2063 	mov	dptr,#(_process_action_PARM_2+0x0001)
      0077F7 E0               [24] 2064 	movx	a,@dptr
      0077F8 54 0F            [12] 2065 	anl	a,#0x0f
      0077FA 22               [24] 2066 	ret
                                   2067 
                                   2068 	.area CSEG (CODE)
                                   2069 ; function ak820_outline_0129
      0077FB                       2070 _ak820_outline_0129:
      0077FB 90 08 32         [24] 2071 	mov	dptr,#_process_action_PARM_2
      0077FE E0               [24] 2072 	movx	a,@dptr
      0077FF FE               [12] 2073 	mov	r6,a
      007800 A3               [24] 2074 	inc	dptr
      007801 E0               [24] 2075 	movx	a,@dptr
      007802 54 03            [12] 2076 	anl	a,#0x03
      007804 FF               [12] 2077 	mov	r7,a
      007805 22               [24] 2078 	ret
                                   2079 
                                   2080 	.area CSEG (CODE)
                                   2081 ; function ak820_outline_0154
      007806                       2082 _ak820_outline_0154:
      007806 90 08 32         [24] 2083 	mov	dptr,#_process_action_PARM_2
      007809 E0               [24] 2084 	movx	a,@dptr
      00780A 22               [24] 2085 	ret
                                   2086 
                                   2087 	.area CSEG (CODE)
                                   2088 ; function ak820_outline_0162
      00780B                       2089 _ak820_outline_0162:
      00780B 90 08 37         [24] 2090 	mov	dptr,#_register_code_code_10000_709
      00780E E0               [24] 2091 	movx	a,@dptr
      00780F FF               [12] 2092 	mov	r7,a
      007810 22               [24] 2093 	ret
                                   2094 
                                   2095 	.area CSEG (CODE)
                                   2096 ; function ak820_outline_0163
      007811                       2097 _ak820_outline_0163:
      007811 90 08 38         [24] 2098 	mov	dptr,#_unregister_code_code_10000_723
      007814 E0               [24] 2099 	movx	a,@dptr
      007815 FF               [12] 2100 	mov	r7,a
      007816 22               [24] 2101 	ret
