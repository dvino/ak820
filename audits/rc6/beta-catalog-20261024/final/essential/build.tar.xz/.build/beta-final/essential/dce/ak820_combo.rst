                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_combo
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _dynamic_keymap_get_combo
                                     12 	.globl _process_record
                                     13 	.globl _ADC_START
                                     14 	.globl _S0_R_FIFO
                                     15 	.globl _S0_T_FIFO
                                     16 	.globl _S0_FREE
                                     17 	.globl _S0_IF_BYTE
                                     18 	.globl _S0_IF_FIRST
                                     19 	.globl _S0_IF_OV
                                     20 	.globl _S0_FST_ACT
                                     21 	.globl _CP_RL2
                                     22 	.globl _C_T2
                                     23 	.globl _TR2
                                     24 	.globl _EXEN2
                                     25 	.globl _TCLK
                                     26 	.globl _RCLK
                                     27 	.globl _EXF2
                                     28 	.globl _CAP1F
                                     29 	.globl _TF2
                                     30 	.globl _RI
                                     31 	.globl _TI
                                     32 	.globl _RB8
                                     33 	.globl _TB8
                                     34 	.globl _REN
                                     35 	.globl _SM2
                                     36 	.globl _SM1
                                     37 	.globl _SM0
                                     38 	.globl _IT0
                                     39 	.globl _IE0
                                     40 	.globl _IT1
                                     41 	.globl _IE1
                                     42 	.globl _TR0
                                     43 	.globl _TF0
                                     44 	.globl _TR1
                                     45 	.globl _TF1
                                     46 	.globl _P4_0
                                     47 	.globl _P4_1
                                     48 	.globl _P4_2
                                     49 	.globl _P4_3
                                     50 	.globl _P4_4
                                     51 	.globl _P4_5
                                     52 	.globl _P4_6
                                     53 	.globl _RXD
                                     54 	.globl _TXD
                                     55 	.globl _INT0
                                     56 	.globl _INT1
                                     57 	.globl _T0
                                     58 	.globl _T1
                                     59 	.globl _MOSI1
                                     60 	.globl _MISO1
                                     61 	.globl _SCK1
                                     62 	.globl _P3_0
                                     63 	.globl _P3_1
                                     64 	.globl _P3_2
                                     65 	.globl _P3_3
                                     66 	.globl _P3_4
                                     67 	.globl _P3_5
                                     68 	.globl _P3_6
                                     69 	.globl _P3_7
                                     70 	.globl _CAP1_
                                     71 	.globl _T2_
                                     72 	.globl _CAP2_
                                     73 	.globl _T2EX_
                                     74 	.globl _RXD1
                                     75 	.globl _TXD1
                                     76 	.globl _P2_0
                                     77 	.globl _P2_1
                                     78 	.globl _P2_2
                                     79 	.globl _P2_3
                                     80 	.globl _P2_4
                                     81 	.globl _P2_5
                                     82 	.globl _P2_6
                                     83 	.globl _P2_7
                                     84 	.globl _AIN0
                                     85 	.globl _AIN1
                                     86 	.globl _AIN2
                                     87 	.globl _AIN3
                                     88 	.globl _AIN4
                                     89 	.globl _AIN5
                                     90 	.globl _AIN6
                                     91 	.globl _AIN7
                                     92 	.globl _CAP1
                                     93 	.globl _T2
                                     94 	.globl _CAP2
                                     95 	.globl _T2EX
                                     96 	.globl _INT0_
                                     97 	.globl _SCS
                                     98 	.globl _MOSI
                                     99 	.globl _MISO
                                    100 	.globl _SCK
                                    101 	.globl _RXD1_
                                    102 	.globl _TXD1_
                                    103 	.globl _P1_0
                                    104 	.globl _P1_1
                                    105 	.globl _P1_2
                                    106 	.globl _P1_3
                                    107 	.globl _P1_4
                                    108 	.globl _P1_5
                                    109 	.globl _P1_6
                                    110 	.globl _P1_7
                                    111 	.globl _AIN8
                                    112 	.globl _AIN9
                                    113 	.globl _AIN10
                                    114 	.globl _AIN11
                                    115 	.globl _AIN12
                                    116 	.globl _AIN13
                                    117 	.globl _RXD_
                                    118 	.globl _TXD_
                                    119 	.globl _SCL0
                                    120 	.globl _SDA0
                                    121 	.globl _P0_0
                                    122 	.globl _P0_1
                                    123 	.globl _P0_2
                                    124 	.globl _P0_3
                                    125 	.globl _P0_4
                                    126 	.globl _P0_5
                                    127 	.globl _P0_6
                                    128 	.globl _P0_7
                                    129 	.globl _IE_SPI0
                                    130 	.globl _IE_USB
                                    131 	.globl _IE_ADC
                                    132 	.globl _IE_UART1
                                    133 	.globl _IE_PWM_I2C
                                    134 	.globl _IE_GPIO
                                    135 	.globl _IE_WDOG
                                    136 	.globl _PX0
                                    137 	.globl _PT0
                                    138 	.globl _PX1
                                    139 	.globl _PT1
                                    140 	.globl _PS
                                    141 	.globl _PT2
                                    142 	.globl _PL_FLAG
                                    143 	.globl _PH_FLAG
                                    144 	.globl _EX0
                                    145 	.globl _ET0
                                    146 	.globl _EX1
                                    147 	.globl _ET1
                                    148 	.globl _ES
                                    149 	.globl _ET2
                                    150 	.globl _E_DIS
                                    151 	.globl _EA
                                    152 	.globl _P
                                    153 	.globl _F1
                                    154 	.globl _OV
                                    155 	.globl _RS0
                                    156 	.globl _RS1
                                    157 	.globl _F0
                                    158 	.globl _AC
                                    159 	.globl _CY
                                    160 	.globl _I2CS_INT_ST
                                    161 	.globl _I2CX_INT
                                    162 	.globl _LED_STATUS
                                    163 	.globl _LED_DMA_H
                                    164 	.globl _LED_DMA_L
                                    165 	.globl _LED_DMA
                                    166 	.globl _LED_PWM_OE
                                    167 	.globl _LED_COMMON
                                    168 	.globl _ADC_CHAN
                                    169 	.globl _ADC_DAT_H
                                    170 	.globl _ADC_DAT_L
                                    171 	.globl _ADC_DAT
                                    172 	.globl _ADC_CTRL
                                    173 	.globl _SPI1_CK_SE
                                    174 	.globl _SPI1_CTRL
                                    175 	.globl _SPI1_DATA
                                    176 	.globl _SPI1_STAT
                                    177 	.globl _SIF1
                                    178 	.globl _SBAUD1
                                    179 	.globl _SBUF1
                                    180 	.globl _SCON1
                                    181 	.globl _SPI0_SETUP
                                    182 	.globl _SPI0_CK_SE
                                    183 	.globl _SPI0_CTRL
                                    184 	.globl _SPI0_DATA
                                    185 	.globl _SPI0_STAT
                                    186 	.globl _T2CAP1H
                                    187 	.globl _T2CAP1L
                                    188 	.globl _T2CAP1
                                    189 	.globl _TH2
                                    190 	.globl _TL2
                                    191 	.globl _T2COUNT
                                    192 	.globl _RCAP2H
                                    193 	.globl _RCAP2L
                                    194 	.globl _RCAP2
                                    195 	.globl _T2MOD
                                    196 	.globl _T2CON
                                    197 	.globl _SBUF
                                    198 	.globl _SCON
                                    199 	.globl _TH1
                                    200 	.globl _TH0
                                    201 	.globl _TL1
                                    202 	.globl _TL0
                                    203 	.globl _TMOD
                                    204 	.globl _TCON
                                    205 	.globl _XBUS_AUX
                                    206 	.globl _P7
                                    207 	.globl _P6_DIR
                                    208 	.globl _P6_OUT_PU
                                    209 	.globl _P6_IN
                                    210 	.globl _P5_DIR
                                    211 	.globl _P5_OUT_PU
                                    212 	.globl _P5_IN
                                    213 	.globl _P4_LED_KEY
                                    214 	.globl _P4_DIR_PU
                                    215 	.globl _P4_MOD_OC
                                    216 	.globl _P4
                                    217 	.globl _P3_DIR_PU
                                    218 	.globl _P3_MOD_OC
                                    219 	.globl _P3
                                    220 	.globl _P2_DIR_PU
                                    221 	.globl _P2_MOD_OC
                                    222 	.globl _P2
                                    223 	.globl _P1_DIR_PU
                                    224 	.globl _P1_MOD_OC
                                    225 	.globl _P1
                                    226 	.globl _P0_DIR_PU
                                    227 	.globl _P0_MOD_OC
                                    228 	.globl _P0
                                    229 	.globl _ROM_CTRL
                                    230 	.globl _ROM_DATA_HH
                                    231 	.globl _ROM_DATA_HL
                                    232 	.globl _ROM_DATA_HI
                                    233 	.globl _ROM_ADDR_H
                                    234 	.globl _ROM_ADDR_L
                                    235 	.globl _ROM_ADDR
                                    236 	.globl _GPIO_IE
                                    237 	.globl _IP_EX
                                    238 	.globl _IE_EX
                                    239 	.globl _IP
                                    240 	.globl _IE
                                    241 	.globl _WDOG_COUNT
                                    242 	.globl _RESET_KEEP
                                    243 	.globl _WAKE_CTRL
                                    244 	.globl _CLOCK_CFG
                                    245 	.globl _POWER_CFG
                                    246 	.globl _PCON
                                    247 	.globl _GLOBAL_CFG
                                    248 	.globl _SAFE_MOD
                                    249 	.globl _DPH
                                    250 	.globl _DPL
                                    251 	.globl _SP
                                    252 	.globl _A_INV
                                    253 	.globl _B
                                    254 	.globl _ACC
                                    255 	.globl _PSW
                                    256 	.globl _ak820_combo_valid
                                    257 	.globl _ak820_combo_cancel
                                    258 	.globl _ak820_combo_reload
                                    259 	.globl _ak820_combo_tick
                                    260 	.globl _ak820_combo_process
                                    261 ;--------------------------------------------------------
                                    262 ; special function registers
                                    263 ;--------------------------------------------------------
                                    264 	.area RSEG    (ABS,DATA)
      000000                        265 	.org 0x0000
                           0000D0   266 _PSW	=	0x00d0
                           0000E0   267 _ACC	=	0x00e0
                           0000F0   268 _B	=	0x00f0
                           0000FD   269 _A_INV	=	0x00fd
                           000081   270 _SP	=	0x0081
                           000082   271 _DPL	=	0x0082
                           000083   272 _DPH	=	0x0083
                           0000A1   273 _SAFE_MOD	=	0x00a1
                           0000B1   274 _GLOBAL_CFG	=	0x00b1
                           000087   275 _PCON	=	0x0087
                           0000BA   276 _POWER_CFG	=	0x00ba
                           0000B9   277 _CLOCK_CFG	=	0x00b9
                           0000A9   278 _WAKE_CTRL	=	0x00a9
                           0000FE   279 _RESET_KEEP	=	0x00fe
                           0000FF   280 _WDOG_COUNT	=	0x00ff
                           0000A8   281 _IE	=	0x00a8
                           0000B8   282 _IP	=	0x00b8
                           0000E8   283 _IE_EX	=	0x00e8
                           0000E9   284 _IP_EX	=	0x00e9
                           0000B2   285 _GPIO_IE	=	0x00b2
                           008584   286 _ROM_ADDR	=	0x8584
                           000084   287 _ROM_ADDR_L	=	0x0084
                           000085   288 _ROM_ADDR_H	=	0x0085
                           008F8E   289 _ROM_DATA_HI	=	0x8f8e
                           00008E   290 _ROM_DATA_HL	=	0x008e
                           00008F   291 _ROM_DATA_HH	=	0x008f
                           000086   292 _ROM_CTRL	=	0x0086
                           000080   293 _P0	=	0x0080
                           0000C4   294 _P0_MOD_OC	=	0x00c4
                           0000C5   295 _P0_DIR_PU	=	0x00c5
                           000090   296 _P1	=	0x0090
                           000092   297 _P1_MOD_OC	=	0x0092
                           000093   298 _P1_DIR_PU	=	0x0093
                           0000A0   299 _P2	=	0x00a0
                           000094   300 _P2_MOD_OC	=	0x0094
                           000095   301 _P2_DIR_PU	=	0x0095
                           0000B0   302 _P3	=	0x00b0
                           000096   303 _P3_MOD_OC	=	0x0096
                           000097   304 _P3_DIR_PU	=	0x0097
                           0000C0   305 _P4	=	0x00c0
                           0000C2   306 _P4_MOD_OC	=	0x00c2
                           0000C3   307 _P4_DIR_PU	=	0x00c3
                           0000C1   308 _P4_LED_KEY	=	0x00c1
                           0000AA   309 _P5_IN	=	0x00aa
                           0000AB   310 _P5_OUT_PU	=	0x00ab
                           0000AC   311 _P5_DIR	=	0x00ac
                           0000AD   312 _P6_IN	=	0x00ad
                           0000AE   313 _P6_OUT_PU	=	0x00ae
                           0000AF   314 _P6_DIR	=	0x00af
                           0000F1   315 _P7	=	0x00f1
                           0000A2   316 _XBUS_AUX	=	0x00a2
                           000088   317 _TCON	=	0x0088
                           000089   318 _TMOD	=	0x0089
                           00008A   319 _TL0	=	0x008a
                           00008B   320 _TL1	=	0x008b
                           00008C   321 _TH0	=	0x008c
                           00008D   322 _TH1	=	0x008d
                           000098   323 _SCON	=	0x0098
                           000099   324 _SBUF	=	0x0099
                           0000C8   325 _T2CON	=	0x00c8
                           0000C9   326 _T2MOD	=	0x00c9
                           00CBCA   327 _RCAP2	=	0xcbca
                           0000CA   328 _RCAP2L	=	0x00ca
                           0000CB   329 _RCAP2H	=	0x00cb
                           00CDCC   330 _T2COUNT	=	0xcdcc
                           0000CC   331 _TL2	=	0x00cc
                           0000CD   332 _TH2	=	0x00cd
                           00CFCE   333 _T2CAP1	=	0xcfce
                           0000CE   334 _T2CAP1L	=	0x00ce
                           0000CF   335 _T2CAP1H	=	0x00cf
                           0000F8   336 _SPI0_STAT	=	0x00f8
                           0000F9   337 _SPI0_DATA	=	0x00f9
                           0000FA   338 _SPI0_CTRL	=	0x00fa
                           0000FB   339 _SPI0_CK_SE	=	0x00fb
                           0000FC   340 _SPI0_SETUP	=	0x00fc
                           0000BC   341 _SCON1	=	0x00bc
                           0000BD   342 _SBUF1	=	0x00bd
                           0000BE   343 _SBAUD1	=	0x00be
                           0000BF   344 _SIF1	=	0x00bf
                           0000B4   345 _SPI1_STAT	=	0x00b4
                           0000B5   346 _SPI1_DATA	=	0x00b5
                           0000B6   347 _SPI1_CTRL	=	0x00b6
                           0000B7   348 _SPI1_CK_SE	=	0x00b7
                           0000F3   349 _ADC_CTRL	=	0x00f3
                           00F5F4   350 _ADC_DAT	=	0xf5f4
                           0000F4   351 _ADC_DAT_L	=	0x00f4
                           0000F5   352 _ADC_DAT_H	=	0x00f5
                           0000F6   353 _ADC_CHAN	=	0x00f6
                           0000A6   354 _LED_COMMON	=	0x00a6
                           0000A7   355 _LED_PWM_OE	=	0x00a7
                           00C7C6   356 _LED_DMA	=	0xc7c6
                           0000C6   357 _LED_DMA_L	=	0x00c6
                           0000C7   358 _LED_DMA_H	=	0x00c7
                           0000F7   359 _LED_STATUS	=	0x00f7
                           0000B3   360 _I2CX_INT	=	0x00b3
                           0000BB   361 _I2CS_INT_ST	=	0x00bb
                                    362 ;--------------------------------------------------------
                                    363 ; special function bits
                                    364 ;--------------------------------------------------------
                                    365 	.area RSEG    (ABS,DATA)
      000000                        366 	.org 0x0000
                           0000D7   367 _CY	=	0x00d7
                           0000D6   368 _AC	=	0x00d6
                           0000D5   369 _F0	=	0x00d5
                           0000D4   370 _RS1	=	0x00d4
                           0000D3   371 _RS0	=	0x00d3
                           0000D2   372 _OV	=	0x00d2
                           0000D1   373 _F1	=	0x00d1
                           0000D0   374 _P	=	0x00d0
                           0000AF   375 _EA	=	0x00af
                           0000AE   376 _E_DIS	=	0x00ae
                           0000AD   377 _ET2	=	0x00ad
                           0000AC   378 _ES	=	0x00ac
                           0000AB   379 _ET1	=	0x00ab
                           0000AA   380 _EX1	=	0x00aa
                           0000A9   381 _ET0	=	0x00a9
                           0000A8   382 _EX0	=	0x00a8
                           0000BF   383 _PH_FLAG	=	0x00bf
                           0000BE   384 _PL_FLAG	=	0x00be
                           0000BD   385 _PT2	=	0x00bd
                           0000BC   386 _PS	=	0x00bc
                           0000BB   387 _PT1	=	0x00bb
                           0000BA   388 _PX1	=	0x00ba
                           0000B9   389 _PT0	=	0x00b9
                           0000B8   390 _PX0	=	0x00b8
                           0000EF   391 _IE_WDOG	=	0x00ef
                           0000EE   392 _IE_GPIO	=	0x00ee
                           0000ED   393 _IE_PWM_I2C	=	0x00ed
                           0000EC   394 _IE_UART1	=	0x00ec
                           0000EB   395 _IE_ADC	=	0x00eb
                           0000E9   396 _IE_USB	=	0x00e9
                           0000E8   397 _IE_SPI0	=	0x00e8
                           000087   398 _P0_7	=	0x0087
                           000086   399 _P0_6	=	0x0086
                           000085   400 _P0_5	=	0x0085
                           000084   401 _P0_4	=	0x0084
                           000083   402 _P0_3	=	0x0083
                           000082   403 _P0_2	=	0x0082
                           000081   404 _P0_1	=	0x0081
                           000080   405 _P0_0	=	0x0080
                           000081   406 _SDA0	=	0x0081
                           000080   407 _SCL0	=	0x0080
                           000083   408 _TXD_	=	0x0083
                           000082   409 _RXD_	=	0x0082
                           000085   410 _AIN13	=	0x0085
                           000084   411 _AIN12	=	0x0084
                           000083   412 _AIN11	=	0x0083
                           000082   413 _AIN10	=	0x0082
                           000081   414 _AIN9	=	0x0081
                           000080   415 _AIN8	=	0x0080
                           000097   416 _P1_7	=	0x0097
                           000096   417 _P1_6	=	0x0096
                           000095   418 _P1_5	=	0x0095
                           000094   419 _P1_4	=	0x0094
                           000093   420 _P1_3	=	0x0093
                           000092   421 _P1_2	=	0x0092
                           000091   422 _P1_1	=	0x0091
                           000090   423 _P1_0	=	0x0090
                           000097   424 _TXD1_	=	0x0097
                           000096   425 _RXD1_	=	0x0096
                           000097   426 _SCK	=	0x0097
                           000096   427 _MISO	=	0x0096
                           000095   428 _MOSI	=	0x0095
                           000094   429 _SCS	=	0x0094
                           000092   430 _INT0_	=	0x0092
                           000091   431 _T2EX	=	0x0091
                           000091   432 _CAP2	=	0x0091
                           000090   433 _T2	=	0x0090
                           000090   434 _CAP1	=	0x0090
                           000097   435 _AIN7	=	0x0097
                           000096   436 _AIN6	=	0x0096
                           000095   437 _AIN5	=	0x0095
                           000094   438 _AIN4	=	0x0094
                           000093   439 _AIN3	=	0x0093
                           000092   440 _AIN2	=	0x0092
                           000091   441 _AIN1	=	0x0091
                           000090   442 _AIN0	=	0x0090
                           0000A7   443 _P2_7	=	0x00a7
                           0000A6   444 _P2_6	=	0x00a6
                           0000A5   445 _P2_5	=	0x00a5
                           0000A4   446 _P2_4	=	0x00a4
                           0000A3   447 _P2_3	=	0x00a3
                           0000A2   448 _P2_2	=	0x00a2
                           0000A1   449 _P2_1	=	0x00a1
                           0000A0   450 _P2_0	=	0x00a0
                           0000A7   451 _TXD1	=	0x00a7
                           0000A6   452 _RXD1	=	0x00a6
                           0000A5   453 _T2EX_	=	0x00a5
                           0000A5   454 _CAP2_	=	0x00a5
                           0000A4   455 _T2_	=	0x00a4
                           0000A4   456 _CAP1_	=	0x00a4
                           0000B7   457 _P3_7	=	0x00b7
                           0000B6   458 _P3_6	=	0x00b6
                           0000B5   459 _P3_5	=	0x00b5
                           0000B4   460 _P3_4	=	0x00b4
                           0000B3   461 _P3_3	=	0x00b3
                           0000B2   462 _P3_2	=	0x00b2
                           0000B1   463 _P3_1	=	0x00b1
                           0000B0   464 _P3_0	=	0x00b0
                           0000B7   465 _SCK1	=	0x00b7
                           0000B6   466 _MISO1	=	0x00b6
                           0000B5   467 _MOSI1	=	0x00b5
                           0000B5   468 _T1	=	0x00b5
                           0000B4   469 _T0	=	0x00b4
                           0000B3   470 _INT1	=	0x00b3
                           0000B2   471 _INT0	=	0x00b2
                           0000B1   472 _TXD	=	0x00b1
                           0000B0   473 _RXD	=	0x00b0
                           0000C6   474 _P4_6	=	0x00c6
                           0000C5   475 _P4_5	=	0x00c5
                           0000C4   476 _P4_4	=	0x00c4
                           0000C3   477 _P4_3	=	0x00c3
                           0000C2   478 _P4_2	=	0x00c2
                           0000C1   479 _P4_1	=	0x00c1
                           0000C0   480 _P4_0	=	0x00c0
                           00008F   481 _TF1	=	0x008f
                           00008E   482 _TR1	=	0x008e
                           00008D   483 _TF0	=	0x008d
                           00008C   484 _TR0	=	0x008c
                           00008B   485 _IE1	=	0x008b
                           00008A   486 _IT1	=	0x008a
                           000089   487 _IE0	=	0x0089
                           000088   488 _IT0	=	0x0088
                           00009F   489 _SM0	=	0x009f
                           00009E   490 _SM1	=	0x009e
                           00009D   491 _SM2	=	0x009d
                           00009C   492 _REN	=	0x009c
                           00009B   493 _TB8	=	0x009b
                           00009A   494 _RB8	=	0x009a
                           000099   495 _TI	=	0x0099
                           000098   496 _RI	=	0x0098
                           0000CF   497 _TF2	=	0x00cf
                           0000CF   498 _CAP1F	=	0x00cf
                           0000CE   499 _EXF2	=	0x00ce
                           0000CD   500 _RCLK	=	0x00cd
                           0000CC   501 _TCLK	=	0x00cc
                           0000CB   502 _EXEN2	=	0x00cb
                           0000CA   503 _TR2	=	0x00ca
                           0000C9   504 _C_T2	=	0x00c9
                           0000C8   505 _CP_RL2	=	0x00c8
                           0000FF   506 _S0_FST_ACT	=	0x00ff
                           0000FE   507 _S0_IF_OV	=	0x00fe
                           0000FD   508 _S0_IF_FIRST	=	0x00fd
                           0000FC   509 _S0_IF_BYTE	=	0x00fc
                           0000FB   510 _S0_FREE	=	0x00fb
                           0000FA   511 _S0_T_FIFO	=	0x00fa
                           0000F8   512 _S0_R_FIFO	=	0x00f8
                           0000F7   513 _ADC_START	=	0x00f7
                                    514 ;--------------------------------------------------------
                                    515 ; overlayable register banks
                                    516 ;--------------------------------------------------------
                                    517 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        518 	.ds 8
                                    519 ;--------------------------------------------------------
                                    520 ; internal ram data
                                    521 ;--------------------------------------------------------
                                    522 	.area DSEG    (DATA)
                                    523 ;--------------------------------------------------------
                                    524 ; overlayable items in internal ram
                                    525 ;--------------------------------------------------------
                                    526 ;--------------------------------------------------------
                                    527 ; indirectly addressable internal ram data
                                    528 ;--------------------------------------------------------
                                    529 	.area ISEG    (DATA)
                                    530 ;--------------------------------------------------------
                                    531 ; absolute internal ram data
                                    532 ;--------------------------------------------------------
                                    533 	.area IABS    (ABS,DATA)
                                    534 	.area IABS    (ABS,DATA)
                                    535 ;--------------------------------------------------------
                                    536 ; bit data
                                    537 ;--------------------------------------------------------
                                    538 	.area BSEG    (BIT)
      000000                        539 _ak820_combo_valid_sloc0_1_0:
      000000                        540 	.ds 1
      000001                        541 _ak820_combo_process_sloc0_1_0:
      000001                        542 	.ds 1
                                    543 ;--------------------------------------------------------
                                    544 ; paged external ram data
                                    545 ;--------------------------------------------------------
                                    546 	.area PSEG    (PAG,XDATA)
                                    547 ;--------------------------------------------------------
                                    548 ; uninitialized external ram data
                                    549 ;--------------------------------------------------------
                                    550 	.area XSEG    (XDATA)
      000422                        551 _combos:
      000422                        552 	.ds 32
      000442                        553 _saved:
      000442                        554 	.ds 9
      00044B                        555 _active:
      00044B                        556 	.ds 1
      00044C                        557 _ak820_combo_valid_entry_10000_592:
      00044C                        558 	.ds 2
      00044E                        559 _ak820_combo_reload_entry_30000_604:
      00044E                        560 	.ds 10
      000458                        561 _ak820_combo_tick_now_10000_609:
      000458                        562 	.ds 2
      00045A                        563 _ak820_combo_process_record_10000_612:
      00045A                        564 	.ds 2
      00045C                        565 _ak820_combo_process_eligible_10001_627:
      00045C                        566 	.ds 1
      00045D                        567 _ak820_combo_process_i_40001_630:
      00045D                        568 	.ds 1
      00045E                        569 _ak820_combo_process_a_50001_631:
      00045E                        570 	.ds 1
      00045F                        571 _ak820_combo_process_b_50001_631:
      00045F                        572 	.ds 1
                                    573 ;--------------------------------------------------------
                                    574 ; absolute external ram data
                                    575 ;--------------------------------------------------------
                                    576 	.area XABS    (ABS,XDATA)
                                    577 ;--------------------------------------------------------
                                    578 ; initialized external ram data
                                    579 ;--------------------------------------------------------
                                    580 	.area XISEG   (XDATA)
      000D87                        581 _first:
      000D87                        582 	.ds 1
      000D88                        583 _second:
      000D88                        584 	.ds 1
                                    585 	.area HOME    (CODE)
                                    586 	.area GSINIT0 (CODE)
                                    587 	.area GSINIT1 (CODE)
                                    588 	.area GSINIT2 (CODE)
                                    589 	.area GSINIT3 (CODE)
                                    590 	.area GSINIT4 (CODE)
                                    591 	.area GSINIT5 (CODE)
                                    592 	.area GSINIT  (CODE)
                                    593 	.area GSFINAL (CODE)
                                    594 	.area CSEG    (CODE)
                                    595 ;--------------------------------------------------------
                                    596 ; global & static initialisations
                                    597 ;--------------------------------------------------------
                                    598 	.area HOME    (CODE)
                                    599 	.area GSINIT  (CODE)
                                    600 	.area GSFINAL (CODE)
                                    601 	.area GSINIT  (CODE)
                                    602 ;--------------------------------------------------------
                                    603 ; Home
                                    604 ;--------------------------------------------------------
                                    605 	.area HOME    (CODE)
                                    606 	.area HOME    (CODE)
                                    607 ;--------------------------------------------------------
                                    608 ; code
                                    609 ;--------------------------------------------------------
                                    610 	.area CSEG    (CODE)
                                    611 ;------------------------------------------------------------
                                    612 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    613 ;------------------------------------------------------------
                                    614 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    615 ;------------------------------------------------------------
                                    616 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    617 ;	-----------------------------------------
                           000007   618 	ar7 = 0x07
                           000006   619 	ar6 = 0x06
                           000005   620 	ar5 = 0x05
                           000004   621 	ar4 = 0x04
                           000003   622 	ar3 = 0x03
                           000002   623 	ar2 = 0x02
                           000001   624 	ar1 = 0x01
                           000000   625 	ar0 = 0x00
                                    626 ;	 function ak820_combo_valid
                                    627 ;	-----------------------------------------
      003468                        628 _ak820_combo_valid:
      003468 12 38 3B         [24]  629 	lcall	_ak820_outline_0103
      00346B 90 04 4C         [24]  630 	mov	dptr,#_ak820_combo_valid_entry_10000_592
      00346E 12 38 40         [24]  631 	lcall	_ak820_outline_0104
                                    632 ;	keyboards/ajazz/ak820/ak820_combo.c:24: if (entry->input[2] || entry->input[3]) return false;
      003471 90 04 4C         [24]  633 	mov	dptr,#_ak820_combo_valid_entry_10000_592
      003474 12 37 98         [24]  634 	lcall	_ak820_outline_0004
      003477 A3               [24]  635 	inc	dptr
      003478 A3               [24]  636 	inc	dptr
      003479 A3               [24]  637 	inc	dptr
      00347A A3               [24]  638 	inc	dptr
      00347B 12 38 72         [24]  639 	lcall	_ak820_outline_0165
      00347E 70 0B            [24]  640 	jnz	00101$
      003480 74 06            [12]  641 	mov	a,#0x06
      003482 12 37 DF         [24]  642 	lcall	_ak820_outline_0017
      003485 FC               [12]  643 	mov	r4,a
      003486 A3               [24]  644 	inc	dptr
      003487 E0               [24]  645 	movx	a,@dptr
      003488 4C               [12]  646 	orl	a,r4
      003489 60 04            [24]  647 	jz	00102$
      00348B                        648 00101$:
      00348B 75 82 00         [24]  649 	mov	dpl, #0x00
      00348E 22               [24]  650 	ret
      00348F                        651 00102$:
                                    652 ;	keyboards/ajazz/ak820/ak820_combo.c:25: if (!(entry->input[0] | entry->input[1])) return !entry->output;
      00348F 8E 04            [24]  653 	mov	ar4,r6
      003491 8F 05            [24]  654 	mov	ar5,r7
      003493 12 37 F0         [24]  655 	lcall	_ak820_outline_0034
      003496 FA               [12]  656 	mov	r2,a
      003497 A3               [24]  657 	inc	dptr
      003498 E0               [24]  658 	movx	a,@dptr
      003499 FB               [12]  659 	mov	r3,a
      00349A 12 38 4C         [24]  660 	lcall	_ak820_outline_0117
      00349D 12 38 17         [24]  661 	lcall	_ak820_outline_0060
      0034A0 EA               [12]  662 	mov	a,r2
      0034A1 4C               [12]  663 	orl	a,r4
      0034A2 F8               [12]  664 	mov	r0,a
      0034A3 EB               [12]  665 	mov	a,r3
      0034A4 4D               [12]  666 	orl	a,r5
      0034A5 48               [12]  667 	orl	a,r0
      0034A6 70 12            [24]  668 	jnz	00105$
      0034A8 74 08            [12]  669 	mov	a,#0x08
      0034AA 12 37 DF         [24]  670 	lcall	_ak820_outline_0017
      0034AD F8               [12]  671 	mov	r0,a
      0034AE A3               [24]  672 	inc	dptr
      0034AF E0               [24]  673 	movx	a,@dptr
      0034B0 48               [12]  674 	orl	a,r0
      0034B1 B4 01 00         [24]  675 	cjne	a,#0x01,00187$
      0034B4                        676 00187$:
      0034B4 92 00            [24]  677 	mov  _ak820_combo_valid_sloc0_1_0,c
      0034B6 12 38 78         [24]  678 	lcall	_ak820_outline_0167
      0034B9 22               [24]  679 	ret
      0034BA                        680 00105$:
                                    681 ;	keyboards/ajazz/ak820/ak820_combo.c:26: if (entry->input[0] == entry->input[1]) return false;
      0034BA EC               [12]  682 	mov	a,r4
      0034BB B5 02 08         [24]  683 	cjne	a,ar2,00107$
      0034BE ED               [12]  684 	mov	a,r5
      0034BF B5 03 04         [24]  685 	cjne	a,ar3,00107$
      0034C2 75 82 00         [24]  686 	mov	dpl, #0x00
      0034C5 22               [24]  687 	ret
      0034C6                        688 00107$:
                                    689 ;	keyboards/ajazz/ak820/ak820_combo.c:27: if (!COMBO_INPUT(entry->input[0])) return false;
      0034C6 C3               [12]  690 	clr	c
      0034C7 EC               [12]  691 	mov	a,r4
      0034C8 94 04            [12]  692 	subb	a,#0x04
      0034CA ED               [12]  693 	mov	a,r5
      0034CB 94 00            [12]  694 	subb	a,#0x00
      0034CD 40 07            [24]  695 	jc	00108$
      0034CF 74 A4            [12]  696 	mov	a,#0xa4
      0034D1 9C               [12]  697 	subb	a,r4
      0034D2 E4               [12]  698 	clr	a
      0034D3 9D               [12]  699 	subb	a,r5
      0034D4 50 04            [24]  700 	jnc	00109$
                                    701 ;	free result
      0034D6                        702 00108$:
      0034D6 75 82 00         [24]  703 	mov	dpl, #0x00
      0034D9 22               [24]  704 	ret
      0034DA                        705 00109$:
                                    706 ;	keyboards/ajazz/ak820/ak820_combo.c:28: if (!COMBO_INPUT(entry->input[1])) return false;
      0034DA C3               [12]  707 	clr	c
      0034DB EA               [12]  708 	mov	a,r2
      0034DC 94 04            [12]  709 	subb	a,#0x04
      0034DE EB               [12]  710 	mov	a,r3
      0034DF 94 00            [12]  711 	subb	a,#0x00
      0034E1 40 07            [24]  712 	jc	00111$
      0034E3 74 A4            [12]  713 	mov	a,#0xa4
      0034E5 9A               [12]  714 	subb	a,r2
      0034E6 E4               [12]  715 	clr	a
      0034E7 9B               [12]  716 	subb	a,r3
      0034E8 50 04            [24]  717 	jnc	00112$
                                    718 ;	free result
      0034EA                        719 00111$:
      0034EA 75 82 00         [24]  720 	mov	dpl, #0x00
      0034ED 22               [24]  721 	ret
      0034EE                        722 00112$:
                                    723 ;	keyboards/ajazz/ak820/ak820_combo.c:29: return COMBO_OUTPUT(entry->output);
      0034EE 74 08            [12]  724 	mov	a,#0x08
      0034F0 12 37 E8         [24]  725 	lcall	_ak820_outline_0031
      0034F3 12 37 C3         [24]  726 	lcall	_ak820_outline_0010
      0034F6 74 E0            [12]  727 	mov	a,#0x100 - 0x20
      0034F8 2D               [12]  728 	add	a,r5
      0034F9 40 20            [24]  729 	jc	00116$
      0034FB BE 04 00         [24]  730 	cjne	r6,#0x04,00195$
      0034FE                        731 00195$:
      0034FE 40 05            [24]  732 	jc	00124$
      003500 EE               [12]  733 	mov	a,r6
      003501 24 5B            [12]  734 	add	a,#0xff - 0xa4
      003503 50 1A            [24]  735 	jnc	00117$
                                    736 ;	free result
      003505                        737 00124$:
      003505 90 04 4C         [24]  738 	mov	dptr,#_ak820_combo_valid_entry_10000_592
      003508 12 37 F8         [24]  739 	lcall	_ak820_outline_0051
      00350B 74 08            [12]  740 	mov	a,#0x08
      00350D 12 37 DF         [24]  741 	lcall	_ak820_outline_0017
      003510 FF               [12]  742 	mov	r7,a
      003511 BF E0 00         [24]  743 	cjne	r7,#0xe0,00198$
      003514                        744 00198$:
      003514 40 05            [24]  745 	jc	00116$
      003516 EF               [12]  746 	mov	a,r7
      003517 24 18            [12]  747 	add	a,#0xff - 0xe7
      003519 50 04            [24]  748 	jnc	00117$
                                    749 ;	free result
      00351B                        750 00116$:
                                    751 ;	assignBit
      00351B C2 00            [12]  752 	clr	_ak820_combo_valid_sloc0_1_0
      00351D 80 02            [24]  753 	sjmp	00118$
      00351F                        754 00117$:
                                    755 ;	assignBit
      00351F D2 00            [12]  756 	setb	_ak820_combo_valid_sloc0_1_0
      003521                        757 00118$:
      003521 A2 00            [12]  758 	mov	c,_ak820_combo_valid_sloc0_1_0
      003523 12 38 78         [24]  759 	lcall	_ak820_outline_0167
                                    760 ;	keyboards/ajazz/ak820/ak820_combo.c:30: }
      003526 22               [24]  761 	ret
                                    762 ;------------------------------------------------------------
                                    763 ;Allocation info for local variables in function 'ak820_combo_cancel'
                                    764 ;------------------------------------------------------------
                                    765 ;	keyboards/ajazz/ak820/ak820_combo.c:33: void ak820_combo_cancel(void) { first = second = NONE; active = false; }
                                    766 ;	-----------------------------------------
                                    767 ;	 function ak820_combo_cancel
                                    768 ;	-----------------------------------------
      003527                        769 _ak820_combo_cancel:
      003527 90 0D 88         [24]  770 	mov	dptr,#_second
      00352A 74 FF            [12]  771 	mov	a,#0xff
      00352C F0               [24]  772 	movx	@dptr,a
      00352D 90 0D 87         [24]  773 	mov	dptr,#_first
      003530 F0               [24]  774 	movx	@dptr,a
      003531 90 04 4B         [24]  775 	mov	dptr,#_active
      003534 E4               [12]  776 	clr	a
      003535 F0               [24]  777 	movx	@dptr,a
      003536 22               [24]  778 	ret
                                    779 ;------------------------------------------------------------
                                    780 ;Allocation info for local variables in function 'ak820_combo_reload'
                                    781 ;------------------------------------------------------------
                                    782 ;i             Allocated with name '_ak820_combo_reload_i_20000_603'
                                    783 ;entry         Allocated with name '_ak820_combo_reload_entry_30000_604'
                                    784 ;------------------------------------------------------------
                                    785 ;	keyboards/ajazz/ak820/ak820_combo.c:34: void ak820_combo_reload(void) {
                                    786 ;	-----------------------------------------
                                    787 ;	 function ak820_combo_reload
                                    788 ;	-----------------------------------------
      003537                        789 _ak820_combo_reload:
                                    790 ;	keyboards/ajazz/ak820/ak820_combo.c:35: for (uint8_t i = 0; i < VIAL_COMBO_ENTRIES; ++i) {
      003537 7F 00            [12]  791 	mov	r7,#0x00
      003539                        792 00105$:
      003539 BF 08 00         [24]  793 	cjne	r7,#0x08,00131$
      00353C                        794 00131$:
      00353C 40 01            [24]  795 	jc	00132$
      00353E 22               [24]  796 	ret
      00353F                        797 00132$:
                                    798 ;	keyboards/ajazz/ak820/ak820_combo.c:37: combos[i].a = 0;
      00353F EF               [12]  799 	mov	a,r7
      003540 75 F0 04         [24]  800 	mov	b,#0x04
      003543 A4               [48]  801 	mul	ab
      003544 24 22            [12]  802 	add	a, #_combos
      003546 FD               [12]  803 	mov	r5,a
      003547 74 04            [12]  804 	mov	a,#(_combos >> 8)
      003549 35 F0            [12]  805 	addc	a, b
      00354B FE               [12]  806 	mov	r6,a
      00354C 8D 03            [24]  807 	mov	ar3,r5
      00354E 8E 04            [24]  808 	mov	ar4,r6
      003550 12 33 FC         [24]  809 	lcall	_ak820_outline_0122
      003553 E4               [12]  810 	clr	a
      003554 F0               [24]  811 	movx	@dptr,a
                                    812 ;	keyboards/ajazz/ak820/ak820_combo.c:38: if (!dynamic_keymap_get_combo(i, &entry)) {
      003555 90 0A EC         [24]  813 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      003558 74 4E            [12]  814 	mov	a,#_ak820_combo_reload_entry_30000_604
      00355A F0               [24]  815 	movx	@dptr,a
      00355B 74 04            [12]  816 	mov	a,#(_ak820_combo_reload_entry_30000_604 >> 8)
      00355D 12 38 29         [24]  817 	lcall	_ak820_outline_0097
      003560 8F 82            [24]  818 	mov	dpl, r7
      003562 C0 07            [24]  819 	push	ar7
      003564 C0 06            [24]  820 	push	ar6
      003566 C0 05            [24]  821 	push	ar5
      003568 C0 04            [24]  822 	push	ar4
      00356A C0 03            [24]  823 	push	ar3
      00356C 12 85 F1         [24]  824 	lcall	_dynamic_keymap_get_combo
      00356F 12 38 61         [24]  825 	lcall	_ak820_outline_0135
      003572 D0 03            [24]  826 	pop	ar3
      003574 D0 04            [24]  827 	pop	ar4
      003576 D0 05            [24]  828 	pop	ar5
      003578 D0 06            [24]  829 	pop	ar6
      00357A D0 07            [24]  830 	pop	ar7
      00357C 45 F0            [12]  831 	orl	a,b
      00357E 70 28            [24]  832 	jnz	00106$
                                    833 ;	keyboards/ajazz/ak820/ak820_combo.c:39: combos[i].a = entry.input[0];
      003580 90 04 4E         [24]  834 	mov	dptr,#_ak820_combo_reload_entry_30000_604
      003583 E0               [24]  835 	movx	a,@dptr
      003584 12 33 FC         [24]  836 	lcall	_ak820_outline_0122
      003587 F0               [24]  837 	movx	@dptr,a
                                    838 ;	keyboards/ajazz/ak820/ak820_combo.c:40: combos[i].b = entry.input[1];
      003588 74 01            [12]  839 	mov	a,#0x01
      00358A 2D               [12]  840 	add	a, r5
      00358B FB               [12]  841 	mov	r3,a
      00358C E4               [12]  842 	clr	a
      00358D 3E               [12]  843 	addc	a, r6
      00358E FC               [12]  844 	mov	r4,a
      00358F 90 04 50         [24]  845 	mov	dptr,#(_ak820_combo_reload_entry_30000_604 + 0x0002)
      003592 E0               [24]  846 	movx	a,@dptr
      003593 12 33 FC         [24]  847 	lcall	_ak820_outline_0122
      003596 F0               [24]  848 	movx	@dptr,a
                                    849 ;	keyboards/ajazz/ak820/ak820_combo.c:41: combos[i].output = entry.output;
      003597 74 02            [12]  850 	mov	a,#0x02
      003599 12 38 6C         [24]  851 	lcall	_ak820_outline_0155
      00359C 90 04 56         [24]  852 	mov	dptr,#(_ak820_combo_reload_entry_30000_604 + 0x0008)
      00359F 12 38 51         [24]  853 	lcall	_ak820_outline_0121
      0035A2 12 38 5C         [24]  854 	lcall	_ak820_outline_0132
      0035A5 12 38 23         [24]  855 	lcall	_ak820_outline_0077
      0035A8                        856 00106$:
                                    857 ;	keyboards/ajazz/ak820/ak820_combo.c:35: for (uint8_t i = 0; i < VIAL_COMBO_ENTRIES; ++i) {
      0035A8 0F               [12]  858 	inc	r7
                                    859 ;	keyboards/ajazz/ak820/ak820_combo.c:44: }
      0035A9 A1 39            [12]  860 	ajmp	00105$
                                    861 ;------------------------------------------------------------
                                    862 ;Allocation info for local variables in function 'flush'
                                    863 ;------------------------------------------------------------
                                    864 ;	keyboards/ajazz/ak820/ak820_combo.c:45: static void flush(void) {
                                    865 ;	-----------------------------------------
                                    866 ;	 function flush
                                    867 ;	-----------------------------------------
      0035AB                        868 _flush:
                                    869 ;	keyboards/ajazz/ak820/ak820_combo.c:46: first = NONE;
      0035AB 90 0D 87         [24]  870 	mov	dptr,#_first
      0035AE 74 FF            [12]  871 	mov	a,#0xff
      0035B0 F0               [24]  872 	movx	@dptr,a
                                    873 ;	keyboards/ajazz/ak820/ak820_combo.c:47: process_record(&saved);
      0035B1 90 04 42         [24]  874 	mov	dptr,#_saved
                                    875 ;	keyboards/ajazz/ak820/ak820_combo.c:48: }
      0035B4 02 71 FB         [24]  876 	ljmp	_process_record
                                    877 ;------------------------------------------------------------
                                    878 ;Allocation info for local variables in function 'ak820_combo_tick'
                                    879 ;------------------------------------------------------------
                                    880 ;now           Allocated with name '_ak820_combo_tick_now_10000_609'
                                    881 ;------------------------------------------------------------
                                    882 ;	keyboards/ajazz/ak820/ak820_combo.c:49: void ak820_combo_tick(uint16_t now) {
                                    883 ;	-----------------------------------------
                                    884 ;	 function ak820_combo_tick
                                    885 ;	-----------------------------------------
      0035B7                        886 _ak820_combo_tick:
      0035B7 12 38 3B         [24]  887 	lcall	_ak820_outline_0103
      0035BA 90 04 58         [24]  888 	mov	dptr,#_ak820_combo_tick_now_10000_609
      0035BD 12 38 40         [24]  889 	lcall	_ak820_outline_0104
                                    890 ;	keyboards/ajazz/ak820/ak820_combo.c:50: if (first != NONE && !active && (uint16_t)(now - saved.event.time) >= AK820_COMBO_TERM) flush();
      0035C0 12 38 7D         [24]  891 	lcall	_ak820_outline_0181
      0035C3 FF               [12]  892 	mov	r7,a
      0035C4 BF FF 01         [24]  893 	cjne	r7,#0xff,00128$
      0035C7 22               [24]  894 	ret
      0035C8                        895 00128$:
      0035C8 90 04 4B         [24]  896 	mov	dptr,#_active
      0035CB E0               [24]  897 	movx	a,@dptr
      0035CC 70 1E            [24]  898 	jnz	00105$
      0035CE 90 04 44         [24]  899 	mov	dptr,#(_saved + 0x0002)
      0035D1 12 37 F8         [24]  900 	lcall	_ak820_outline_0051
      0035D4 90 04 58         [24]  901 	mov	dptr,#_ak820_combo_tick_now_10000_609
      0035D7 12 38 17         [24]  902 	lcall	_ak820_outline_0060
      0035DA EC               [12]  903 	mov	a,r4
      0035DB C3               [12]  904 	clr	c
      0035DC 9E               [12]  905 	subb	a,r6
      0035DD FE               [12]  906 	mov	r6,a
      0035DE ED               [12]  907 	mov	a,r5
      0035DF 9F               [12]  908 	subb	a,r7
      0035E0 FF               [12]  909 	mov	r7,a
      0035E1 C3               [12]  910 	clr	c
      0035E2 EE               [12]  911 	mov	a,r6
      0035E3 94 28            [12]  912 	subb	a,#0x28
      0035E5 EF               [12]  913 	mov	a,r7
      0035E6 94 00            [12]  914 	subb	a,#0x00
      0035E8 40 02            [24]  915 	jc	00105$
                                    916 ;	keyboards/ajazz/ak820/ak820_combo.c:51: }
      0035EA A1 AB            [24]  917 	ajmp	_flush
      0035EC                        918 00105$:
      0035EC 22               [24]  919 	ret
                                    920 ;------------------------------------------------------------
                                    921 ;Allocation info for local variables in function 'ak820_combo_process'
                                    922 ;------------------------------------------------------------
                                    923 ;record        Allocated with name '_ak820_combo_process_record_10000_612'
                                    924 ;id            Allocated with name '_ak820_combo_process_id_10000_613'
                                    925 ;code          Allocated with name '_ak820_combo_process_code_10000_613'
                                    926 ;eligible      Allocated with name '_ak820_combo_process_eligible_10001_627'
                                    927 ;previous      Allocated with name '_ak820_combo_process_previous_30001_629'
                                    928 ;i             Allocated with name '_ak820_combo_process_i_40001_630'
                                    929 ;a             Allocated with name '_ak820_combo_process_a_50001_631'
                                    930 ;b             Allocated with name '_ak820_combo_process_b_50001_631'
                                    931 ;------------------------------------------------------------
                                    932 ;	keyboards/ajazz/ak820/ak820_combo.c:52: bool ak820_combo_process(keyrecord_t AK820_STATE_MEM *record) {
                                    933 ;	-----------------------------------------
                                    934 ;	 function ak820_combo_process
                                    935 ;	-----------------------------------------
      0035ED                        936 _ak820_combo_process:
      0035ED 12 38 3B         [24]  937 	lcall	_ak820_outline_0103
      0035F0 90 04 5A         [24]  938 	mov	dptr,#_ak820_combo_process_record_10000_612
      0035F3 12 38 40         [24]  939 	lcall	_ak820_outline_0104
                                    940 ;	keyboards/ajazz/ak820/ak820_combo.c:53: uint8_t id, code = record->keycode;
      0035F6 90 04 5A         [24]  941 	mov	dptr,#_ak820_combo_process_record_10000_612
      0035F9 12 37 AF         [24]  942 	lcall	_ak820_outline_0009
      0035FC 8C 03            [24]  943 	mov	ar3,r4
                                    944 ;	keyboards/ajazz/ak820/ak820_combo.c:54: if (IS_NOEVENT(record->event)) return true;
      0035FE 74 04            [12]  945 	mov	a,#0x04
      003600 2E               [12]  946 	add	a, r6
      003601 12 37 CD         [24]  947 	lcall	_ak820_outline_0014
      003604 70 04            [24]  948 	jnz	00102$
      003606 75 82 01         [24]  949 	mov	dpl, #0x01
      003609 22               [24]  950 	ret
      00360A                        951 00102$:
                                    952 ;	keyboards/ajazz/ak820/ak820_combo.c:56: if (record->event.key.row >= MATRIX_ROWS || record->event.key.col >= MATRIX_COLS) {
      00360A 12 38 45         [24]  953 	lcall	_ak820_outline_0108
      00360D FA               [12]  954 	mov	r2,a
      00360E BA 10 00         [24]  955 	cjne	r2,#0x10,00308$
      003611                        956 00308$:
      003611 50 09            [24]  957 	jnc	00106$
      003613 12 38 2F         [24]  958 	lcall	_ak820_outline_0098
      003616 F9               [12]  959 	mov	r1,a
      003617 B9 08 00         [24]  960 	cjne	r1,#0x08,00310$
      00361A                        961 00310$:
      00361A 40 15            [24]  962 	jc	00107$
      00361C                        963 00106$:
                                    964 ;	keyboards/ajazz/ak820/ak820_combo.c:57: if (first != NONE && !active) flush();
      00361C 12 38 7D         [24]  965 	lcall	_ak820_outline_0181
      00361F F8               [12]  966 	mov	r0,a
      003620 B8 FF 02         [24]  967 	cjne	r0,#0xff,00312$
      003623 80 08            [24]  968 	sjmp	00104$
      003625                        969 00312$:
      003625 90 04 4B         [24]  970 	mov	dptr,#_active
      003628 E0               [24]  971 	movx	a,@dptr
      003629 70 02            [24]  972 	jnz	00104$
      00362B B1 AB            [24]  973 	acall	_flush
      00362D                        974 00104$:
                                    975 ;	keyboards/ajazz/ak820/ak820_combo.c:58: return true;
      00362D 75 82 01         [24]  976 	mov	dpl, #0x01
      003630 22               [24]  977 	ret
      003631                        978 00107$:
                                    979 ;	keyboards/ajazz/ak820/ak820_combo.c:60: id = record->event.key.row * MATRIX_COLS + record->event.key.col;
      003631 EA               [12]  980 	mov	a,r2
      003632 12 38 82         [24]  981 	lcall	_ak820_outline_0186
      003635 29               [12]  982 	add	a,r1
      003636 FA               [12]  983 	mov	r2,a
                                    984 ;	keyboards/ajazz/ak820/ak820_combo.c:61: if (active) {
      003637 90 04 4B         [24]  985 	mov	dptr,#_active
      00363A E0               [24]  986 	movx	a,@dptr
      00363B 60 6F            [24]  987 	jz	00123$
                                    988 ;	keyboards/ajazz/ak820/ak820_combo.c:62: if (id != first && id != second) return true;
      00363D 12 38 7D         [24]  989 	lcall	_ak820_outline_0181
      003640 F9               [12]  990 	mov	r1,a
      003641 EA               [12]  991 	mov	a,r2
      003642 B5 01 02         [24]  992 	cjne	a,ar1,00315$
      003645 80 0F            [24]  993 	sjmp	00110$
      003647                        994 00315$:
      003647 90 0D 88         [24]  995 	mov	dptr,#_second
      00364A E0               [24]  996 	movx	a,@dptr
      00364B F9               [12]  997 	mov	r1,a
      00364C EA               [12]  998 	mov	a,r2
      00364D B5 01 02         [24]  999 	cjne	a,ar1,00316$
      003650 80 04            [24] 1000 	sjmp	00110$
      003652                       1001 00316$:
      003652 75 82 01         [24] 1002 	mov	dpl, #0x01
      003655 22               [24] 1003 	ret
      003656                       1004 00110$:
                                   1005 ;	keyboards/ajazz/ak820/ak820_combo.c:63: if (!record->event.pressed) {
      003656 90 04 5A         [24] 1006 	mov	dptr,#_ak820_combo_process_record_10000_612
      003659 12 38 35         [24] 1007 	lcall	_ak820_outline_0100
      00365C 74 05            [12] 1008 	mov	a,#0x05
      00365E 28               [12] 1009 	add	a, r0
      00365F F8               [12] 1010 	mov	r0,a
      003660 E4               [12] 1011 	clr	a
      003661 39               [12] 1012 	addc	a, r1
      003662 F9               [12] 1013 	mov	r1,a
      003663 12 38 67         [24] 1014 	lcall	_ak820_outline_0152
      003666 E0               [24] 1015 	movx	a,@dptr
      003667 70 3F            [24] 1016 	jnz	00121$
                                   1017 ;	keyboards/ajazz/ak820/ak820_combo.c:64: if (saved.event.pressed) {
      003669 90 04 47         [24] 1018 	mov	dptr,#(_saved + 0x0005)
      00366C E0               [24] 1019 	movx	a,@dptr
      00366D 60 0F            [24] 1020 	jz	00113$
                                   1021 ;	keyboards/ajazz/ak820/ak820_combo.c:65: saved.event.pressed = false;
      00366F 90 04 47         [24] 1022 	mov	dptr,#(_saved + 0x0005)
      003672 E4               [12] 1023 	clr	a
      003673 F0               [24] 1024 	movx	@dptr,a
                                   1025 ;	keyboards/ajazz/ak820/ak820_combo.c:66: process_record(&saved);
      003674 90 04 42         [24] 1026 	mov	dptr,#_saved
      003677 C0 02            [24] 1027 	push	ar2
      003679 12 71 FB         [24] 1028 	lcall	_process_record
      00367C D0 02            [24] 1029 	pop	ar2
      00367E                       1030 00113$:
                                   1031 ;	keyboards/ajazz/ak820/ak820_combo.c:68: if (id == first) first = NONE;
      00367E 12 38 7D         [24] 1032 	lcall	_ak820_outline_0181
      003681 F9               [12] 1033 	mov	r1,a
      003682 EA               [12] 1034 	mov	a,r2
      003683 B5 01 08         [24] 1035 	cjne	a,ar1,00115$
      003686 90 0D 87         [24] 1036 	mov	dptr,#_first
      003689 74 FF            [12] 1037 	mov	a,#0xff
      00368B F0               [24] 1038 	movx	@dptr,a
      00368C 80 06            [24] 1039 	sjmp	00116$
      00368E                       1040 00115$:
                                   1041 ;	keyboards/ajazz/ak820/ak820_combo.c:69: else second = NONE;
      00368E 90 0D 88         [24] 1042 	mov	dptr,#_second
      003691 74 FF            [12] 1043 	mov	a,#0xff
      003693 F0               [24] 1044 	movx	@dptr,a
      003694                       1045 00116$:
                                   1046 ;	keyboards/ajazz/ak820/ak820_combo.c:70: if (first == NONE && second == NONE) active = false;
      003694 12 38 7D         [24] 1047 	lcall	_ak820_outline_0181
      003697 F9               [12] 1048 	mov	r1,a
      003698 B9 FF 0D         [24] 1049 	cjne	r1,#0xff,00121$
      00369B 90 0D 88         [24] 1050 	mov	dptr,#_second
      00369E E0               [24] 1051 	movx	a,@dptr
      00369F F9               [12] 1052 	mov	r1,a
      0036A0 B9 FF 05         [24] 1053 	cjne	r1,#0xff,00121$
      0036A3 90 04 4B         [24] 1054 	mov	dptr,#_active
      0036A6 E4               [12] 1055 	clr	a
      0036A7 F0               [24] 1056 	movx	@dptr,a
      0036A8                       1057 00121$:
                                   1058 ;	keyboards/ajazz/ak820/ak820_combo.c:72: return false;
      0036A8 75 82 00         [24] 1059 	mov	dpl, #0x00
      0036AB 22               [24] 1060 	ret
      0036AC                       1061 00123$:
                                   1062 ;	keyboards/ajazz/ak820/ak820_combo.c:74: bool eligible = false;
      0036AC 90 04 5C         [24] 1063 	mov	dptr,#_ak820_combo_process_eligible_10001_627
      0036AF E4               [12] 1064 	clr	a
      0036B0 F0               [24] 1065 	movx	@dptr,a
                                   1066 ;	keyboards/ajazz/ak820/ak820_combo.c:75: if (record->event.pressed && COMBO_INPUT(record->keycode)) {
      0036B1 12 37 A2         [24] 1067 	lcall	_ak820_outline_0005
      0036B4 70 02            [24] 1068 	jnz	00325$
      0036B6 E1 59            [24] 1069 	ajmp	00134$
      0036B8                       1070 00325$:
      0036B8 C3               [12] 1071 	clr	c
      0036B9 EC               [12] 1072 	mov	a,r4
      0036BA 94 04            [12] 1073 	subb	a,#0x04
      0036BC ED               [12] 1074 	mov	a,r5
      0036BD 94 00            [12] 1075 	subb	a,#0x00
      0036BF 50 02            [24] 1076 	jnc	00326$
      0036C1 E1 59            [24] 1077 	ajmp	00134$
      0036C3                       1078 00326$:
      0036C3 C3               [12] 1079 	clr	c
      0036C4 74 A4            [12] 1080 	mov	a,#0xa4
      0036C6 9C               [12] 1081 	subb	a,r4
      0036C7 E4               [12] 1082 	clr	a
      0036C8 9D               [12] 1083 	subb	a,r5
      0036C9 50 02            [24] 1084 	jnc	00327$
      0036CB E1 59            [24] 1085 	ajmp	00134$
      0036CD                       1086 00327$:
                                   1087 ;	free result
                                   1088 ;	keyboards/ajazz/ak820/ak820_combo.c:76: uint8_t previous = saved.keycode;
      0036CD 90 04 49         [24] 1089 	mov	dptr,#(_saved + 0x0007)
      0036D0 E0               [24] 1090 	movx	a,@dptr
      0036D1 FF               [12] 1091 	mov	r7,a
                                   1092 ;	keyboards/ajazz/ak820/ak820_combo.c:77: for (uint8_t i = 0; i < VIAL_COMBO_ENTRIES; ++i) {
      0036D2 90 04 5D         [24] 1093 	mov	dptr,#_ak820_combo_process_i_40001_630
      0036D5 E4               [12] 1094 	clr	a
      0036D6 F0               [24] 1095 	movx	@dptr,a
      0036D7 EB               [12] 1096 	mov	a,r3
      0036D8 B5 07 03         [24] 1097 	cjne	a,ar7,00328$
      0036DB D3               [12] 1098 	setb	c
      0036DC 80 01            [24] 1099 	sjmp	00329$
      0036DE                       1100 00328$:
      0036DE C3               [12] 1101 	clr	c
      0036DF                       1102 00329$:
      0036DF 92 01            [24] 1103 	mov	_ak820_combo_process_sloc0_1_0,c
      0036E1 7E 00            [12] 1104 	mov	r6,#0x00
      0036E3                       1105 00142$:
      0036E3 BE 08 00         [24] 1106 	cjne	r6,#0x08,00330$
      0036E6                       1107 00330$:
      0036E6 40 02            [24] 1108 	jc	00331$
      0036E8 E1 59            [24] 1109 	ajmp	00134$
      0036EA                       1110 00331$:
                                   1111 ;	keyboards/ajazz/ak820/ak820_combo.c:78: uint8_t a = combos[i].a, b = combos[i].b;
      0036EA EE               [12] 1112 	mov	a,r6
      0036EB 12 37 FE         [24] 1113 	lcall	_ak820_outline_0053
      0036EE E0               [24] 1114 	movx	a,@dptr
      0036EF F9               [12] 1115 	mov	r1,a
      0036F0 90 04 5E         [24] 1116 	mov	dptr,#_ak820_combo_process_a_50001_631
      0036F3 F0               [24] 1117 	movx	@dptr,a
      0036F4 12 38 4C         [24] 1118 	lcall	_ak820_outline_0117
      0036F7 A3               [24] 1119 	inc	dptr
      0036F8 E0               [24] 1120 	movx	a,@dptr
      0036F9 FD               [12] 1121 	mov	r5,a
      0036FA 90 04 5F         [24] 1122 	mov	dptr,#_ak820_combo_process_b_50001_631
      0036FD F0               [24] 1123 	movx	@dptr,a
                                   1124 ;	keyboards/ajazz/ak820/ak820_combo.c:79: if (a == code || b == code) {
      0036FE E9               [12] 1125 	mov	a,r1
      0036FF B5 03 02         [24] 1126 	cjne	a,ar3,00332$
      003702 80 04            [24] 1127 	sjmp	00129$
      003704                       1128 00332$:
      003704 ED               [12] 1129 	mov	a,r5
      003705 B5 03 49         [24] 1130 	cjne	a,ar3,00143$
      003708                       1131 00129$:
                                   1132 ;	keyboards/ajazz/ak820/ak820_combo.c:80: eligible = true;
      003708 90 04 5C         [24] 1133 	mov	dptr,#_ak820_combo_process_eligible_10001_627
      00370B 74 01            [12] 1134 	mov	a,#0x01
      00370D F0               [24] 1135 	movx	@dptr,a
                                   1136 ;	keyboards/ajazz/ak820/ak820_combo.c:81: if (first != NONE && code != previous && (a == previous || b == previous)) {
      00370E 12 38 7D         [24] 1137 	lcall	_ak820_outline_0181
      003711 FD               [12] 1138 	mov	r5,a
      003712 BD FF 02         [24] 1139 	cjne	r5,#0xff,00335$
      003715 80 3A            [24] 1140 	sjmp	00143$
      003717                       1141 00335$:
      003717 20 01 37         [24] 1142 	jb	_ak820_combo_process_sloc0_1_0,00143$
      00371A 90 04 5E         [24] 1143 	mov	dptr,#_ak820_combo_process_a_50001_631
      00371D E0               [24] 1144 	movx	a,@dptr
      00371E B5 07 02         [24] 1145 	cjne	a,ar7,00337$
      003721 80 07            [24] 1146 	sjmp	00124$
      003723                       1147 00337$:
      003723 90 04 5F         [24] 1148 	mov	dptr,#_ak820_combo_process_b_50001_631
      003726 E0               [24] 1149 	movx	a,@dptr
      003727 B5 07 27         [24] 1150 	cjne	a,ar7,00143$
      00372A                       1151 00124$:
                                   1152 ;	keyboards/ajazz/ak820/ak820_combo.c:82: second = id;
      00372A 90 0D 88         [24] 1153 	mov	dptr,#_second
      00372D EA               [12] 1154 	mov	a,r2
      00372E F0               [24] 1155 	movx	@dptr,a
                                   1156 ;	keyboards/ajazz/ak820/ak820_combo.c:83: active = true;
      00372F 90 04 4B         [24] 1157 	mov	dptr,#_active
      003732 74 01            [12] 1158 	mov	a,#0x01
      003734 F0               [24] 1159 	movx	@dptr,a
                                   1160 ;	keyboards/ajazz/ak820/ak820_combo.c:84: saved.keycode = combos[i].output;
      003735 90 04 5D         [24] 1161 	mov	dptr,#_ak820_combo_process_i_40001_630
      003738 E0               [24] 1162 	movx	a,@dptr
      003739 12 37 FE         [24] 1163 	lcall	_ak820_outline_0053
      00373C A3               [24] 1164 	inc	dptr
      00373D A3               [24] 1165 	inc	dptr
      00373E 12 38 17         [24] 1166 	lcall	_ak820_outline_0060
      003741 90 04 49         [24] 1167 	mov	dptr,#(_saved + 0x0007)
      003744 12 38 1D         [24] 1168 	lcall	_ak820_outline_0071
                                   1169 ;	keyboards/ajazz/ak820/ak820_combo.c:85: process_record(&saved);
      003747 90 04 42         [24] 1170 	mov	dptr,#_saved
      00374A 12 71 FB         [24] 1171 	lcall	_process_record
                                   1172 ;	keyboards/ajazz/ak820/ak820_combo.c:86: return false;
      00374D 75 82 00         [24] 1173 	mov	dpl, #0x00
      003750 22               [24] 1174 	ret
      003751                       1175 00143$:
                                   1176 ;	keyboards/ajazz/ak820/ak820_combo.c:77: for (uint8_t i = 0; i < VIAL_COMBO_ENTRIES; ++i) {
      003751 0E               [12] 1177 	inc	r6
      003752 90 04 5D         [24] 1178 	mov	dptr,#_ak820_combo_process_i_40001_630
      003755 EE               [12] 1179 	mov	a,r6
      003756 F0               [24] 1180 	movx	@dptr,a
      003757 C1 E3            [24] 1181 	ajmp	00142$
      003759                       1182 00134$:
                                   1183 ;	keyboards/ajazz/ak820/ak820_combo.c:91: if (first != NONE) flush();
      003759 12 38 7D         [24] 1184 	lcall	_ak820_outline_0181
      00375C FF               [12] 1185 	mov	r7,a
      00375D BF FF 02         [24] 1186 	cjne	r7,#0xff,00340$
      003760 80 06            [24] 1187 	sjmp	00138$
      003762                       1188 00340$:
      003762 C0 02            [24] 1189 	push	ar2
      003764 B1 AB            [24] 1190 	acall	_flush
      003766 D0 02            [24] 1191 	pop	ar2
      003768                       1192 00138$:
                                   1193 ;	keyboards/ajazz/ak820/ak820_combo.c:92: if (eligible) {
      003768 90 04 5C         [24] 1194 	mov	dptr,#_ak820_combo_process_eligible_10001_627
      00376B E0               [24] 1195 	movx	a,@dptr
      00376C 60 26            [24] 1196 	jz	00140$
                                   1197 ;	keyboards/ajazz/ak820/ak820_combo.c:93: first = id;
      00376E 90 0D 87         [24] 1198 	mov	dptr,#_first
      003771 EA               [12] 1199 	mov	a,r2
      003772 F0               [24] 1200 	movx	@dptr,a
                                   1201 ;	keyboards/ajazz/ak820/ak820_combo.c:94: saved = *record;
      003773 90 04 5A         [24] 1202 	mov	dptr,#_ak820_combo_process_record_10000_612
      003776 12 38 0F         [24] 1203 	lcall	_ak820_outline_0058
      003779 90 0D 79         [24] 1204 	mov	dptr,#___memcpy_PARM_2
      00377C ED               [12] 1205 	mov	a,r5
      00377D 12 37 D7         [24] 1206 	lcall	_ak820_outline_0016
      003780 90 0D 7C         [24] 1207 	mov	dptr,#___memcpy_PARM_3
      003783 74 09            [12] 1208 	mov	a,#0x09
      003785 12 38 57         [24] 1209 	lcall	_ak820_outline_0123
      003788 90 04 42         [24] 1210 	mov	dptr,#_saved
      00378B F5 F0            [12] 1211 	mov	b,a
      00378D 12 B6 F1         [24] 1212 	lcall	___memcpy
                                   1213 ;	keyboards/ajazz/ak820/ak820_combo.c:95: return false;
      003790 75 82 00         [24] 1214 	mov	dpl, #0x00
      003793 22               [24] 1215 	ret
      003794                       1216 00140$:
                                   1217 ;	keyboards/ajazz/ak820/ak820_combo.c:97: return true;
      003794 75 82 01         [24] 1218 	mov	dpl, #0x01
                                   1219 ;	keyboards/ajazz/ak820/ak820_combo.c:98: }
      003797 22               [24] 1220 	ret
                                   1221 	.area CSEG    (CODE)
                                   1222 	.area CONST   (CODE)
                                   1223 	.area XINIT   (CODE)
      00BFAF                       1224 __xinit__first:
      00BFAF FF                    1225 	.db #0xff	; 255
      00BFB0                       1226 __xinit__second:
      00BFB0 FF                    1227 	.db #0xff	; 255
                                   1228 	.area CABS    (ABS,CODE)
                                   1229 
                                   1230 ; Experimental exact instruction outlining.
                                   1231 	.globl _ak820_outline_0004
                                   1232 	.globl _ak820_outline_0005
                                   1233 	.globl _ak820_outline_0009
                                   1234 	.globl _ak820_outline_0010
                                   1235 	.globl _ak820_outline_0014
                                   1236 	.globl _ak820_outline_0016
                                   1237 	.globl _ak820_outline_0017
                                   1238 	.globl _ak820_outline_0031
                                   1239 	.globl _ak820_outline_0034
                                   1240 	.globl _ak820_outline_0051
                                   1241 	.globl _ak820_outline_0053
                                   1242 	.globl _ak820_outline_0058
                                   1243 	.globl _ak820_outline_0060
                                   1244 	.globl _ak820_outline_0071
                                   1245 	.globl _ak820_outline_0077
                                   1246 	.globl _ak820_outline_0097
                                   1247 	.globl _ak820_outline_0098
                                   1248 	.globl _ak820_outline_0100
                                   1249 	.globl _ak820_outline_0103
                                   1250 	.globl _ak820_outline_0104
                                   1251 	.globl _ak820_outline_0108
                                   1252 	.globl _ak820_outline_0117
                                   1253 	.globl _ak820_outline_0121
                                   1254 	.globl _ak820_outline_0122
                                   1255 	.globl _ak820_outline_0123
                                   1256 	.globl _ak820_outline_0132
                                   1257 	.globl _ak820_outline_0135
                                   1258 	.globl _ak820_outline_0152
                                   1259 	.globl _ak820_outline_0155
                                   1260 	.globl _ak820_outline_0165
                                   1261 	.globl _ak820_outline_0167
                                   1262 	.globl _ak820_outline_0181
                                   1263 	.globl _ak820_outline_0186
                                   1264 
                                   1265 	.area CSEG (CODE)
                                   1266 ; function ak820_outline_0004
      003798                       1267 _ak820_outline_0004:
      003798 E0               [24] 1268 	movx	a,@dptr
      003799 FE               [12] 1269 	mov	r6,a
      00379A A3               [24] 1270 	inc	dptr
      00379B E0               [24] 1271 	movx	a,@dptr
      00379C FF               [12] 1272 	mov	r7,a
      00379D 8E 82            [24] 1273 	mov	dpl,r6
      00379F 8F 83            [24] 1274 	mov	dph,r7
      0037A1 22               [24] 1275 	ret
                                   1276 
                                   1277 	.area CSEG (CODE)
                                   1278 ; function ak820_outline_0005
      0037A2                       1279 _ak820_outline_0005:
      0037A2 74 05            [12] 1280 	mov	a,#0x05
      0037A4 2E               [12] 1281 	add	a,r6
      0037A5 FE               [12] 1282 	mov	r6,a
      0037A6 E4               [12] 1283 	clr	a
      0037A7 3F               [12] 1284 	addc	a,r7
      0037A8 FF               [12] 1285 	mov	r7,a
      0037A9 8E 82            [24] 1286 	mov	dpl,r6
      0037AB 8F 83            [24] 1287 	mov	dph,r7
      0037AD E0               [24] 1288 	movx	a,@dptr
      0037AE 22               [24] 1289 	ret
                                   1290 
                                   1291 	.area CSEG (CODE)
                                   1292 ; function ak820_outline_0009
      0037AF                       1293 _ak820_outline_0009:
      0037AF E0               [24] 1294 	movx	a,@dptr
      0037B0 FE               [12] 1295 	mov	r6,a
      0037B1 A3               [24] 1296 	inc	dptr
      0037B2 E0               [24] 1297 	movx	a,@dptr
      0037B3 FF               [12] 1298 	mov	r7,a
      0037B4 74 07            [12] 1299 	mov	a,#0x07
      0037B6 2E               [12] 1300 	add	a,r6
      0037B7 F5 82            [12] 1301 	mov	dpl,a
      0037B9 E4               [12] 1302 	clr	a
      0037BA 3F               [12] 1303 	addc	a,r7
      0037BB F5 83            [12] 1304 	mov	dph,a
      0037BD E0               [24] 1305 	movx	a,@dptr
      0037BE FC               [12] 1306 	mov	r4,a
      0037BF A3               [24] 1307 	inc	dptr
      0037C0 E0               [24] 1308 	movx	a,@dptr
      0037C1 FD               [12] 1309 	mov	r5,a
      0037C2 22               [24] 1310 	ret
                                   1311 
                                   1312 	.area CSEG (CODE)
                                   1313 ; function ak820_outline_0010
      0037C3                       1314 _ak820_outline_0010:
      0037C3 E0               [24] 1315 	movx	a,@dptr
      0037C4 FE               [12] 1316 	mov	r6,a
      0037C5 A3               [24] 1317 	inc	dptr
      0037C6 E0               [24] 1318 	movx	a,@dptr
      0037C7 FF               [12] 1319 	mov	r7,a
      0037C8 8E 04            [24] 1320 	mov	ar4,r6
      0037CA 8F 05            [24] 1321 	mov	ar5,r7
      0037CC 22               [24] 1322 	ret
                                   1323 
                                   1324 	.area CSEG (CODE)
                                   1325 ; function ak820_outline_0014
      0037CD                       1326 _ak820_outline_0014:
      0037CD F9               [12] 1327 	mov	r1,a
      0037CE E4               [12] 1328 	clr	a
      0037CF 3F               [12] 1329 	addc	a,r7
      0037D0 FA               [12] 1330 	mov	r2,a
      0037D1 89 82            [24] 1331 	mov	dpl,r1
      0037D3 8A 83            [24] 1332 	mov	dph,r2
      0037D5 E0               [24] 1333 	movx	a,@dptr
      0037D6 22               [24] 1334 	ret
                                   1335 
                                   1336 	.area CSEG (CODE)
                                   1337 ; function ak820_outline_0016
      0037D7                       1338 _ak820_outline_0016:
      0037D7 F0               [24] 1339 	movx	@dptr,a
      0037D8 EE               [12] 1340 	mov	a,r6
      0037D9 A3               [24] 1341 	inc	dptr
      0037DA F0               [24] 1342 	movx	@dptr,a
      0037DB EF               [12] 1343 	mov	a,r7
      0037DC A3               [24] 1344 	inc	dptr
      0037DD F0               [24] 1345 	movx	@dptr,a
      0037DE 22               [24] 1346 	ret
                                   1347 
                                   1348 	.area CSEG (CODE)
                                   1349 ; function ak820_outline_0017
      0037DF                       1350 _ak820_outline_0017:
      0037DF 2E               [12] 1351 	add	a,r6
      0037E0 F5 82            [12] 1352 	mov	dpl,a
      0037E2 E4               [12] 1353 	clr	a
      0037E3 3F               [12] 1354 	addc	a,r7
      0037E4 F5 83            [12] 1355 	mov	dph,a
      0037E6 E0               [24] 1356 	movx	a,@dptr
      0037E7 22               [24] 1357 	ret
                                   1358 
                                   1359 	.area CSEG (CODE)
                                   1360 ; function ak820_outline_0031
      0037E8                       1361 _ak820_outline_0031:
      0037E8 2E               [12] 1362 	add	a,r6
      0037E9 F5 82            [12] 1363 	mov	dpl,a
      0037EB E4               [12] 1364 	clr	a
      0037EC 3F               [12] 1365 	addc	a,r7
      0037ED F5 83            [12] 1366 	mov	dph,a
      0037EF 22               [24] 1367 	ret
                                   1368 
                                   1369 	.area CSEG (CODE)
                                   1370 ; function ak820_outline_0034
      0037F0                       1371 _ak820_outline_0034:
      0037F0 8E 82            [24] 1372 	mov	dpl,r6
      0037F2 8F 83            [24] 1373 	mov	dph,r7
      0037F4 A3               [24] 1374 	inc	dptr
      0037F5 A3               [24] 1375 	inc	dptr
      0037F6 E0               [24] 1376 	movx	a,@dptr
      0037F7 22               [24] 1377 	ret
                                   1378 
                                   1379 	.area CSEG (CODE)
                                   1380 ; function ak820_outline_0051
      0037F8                       1381 _ak820_outline_0051:
      0037F8 E0               [24] 1382 	movx	a,@dptr
      0037F9 FE               [12] 1383 	mov	r6,a
      0037FA A3               [24] 1384 	inc	dptr
      0037FB E0               [24] 1385 	movx	a,@dptr
      0037FC FF               [12] 1386 	mov	r7,a
      0037FD 22               [24] 1387 	ret
                                   1388 
                                   1389 	.area CSEG (CODE)
                                   1390 ; function ak820_outline_0053
      0037FE                       1391 _ak820_outline_0053:
      0037FE 75 F0 04         [24] 1392 	mov	b,#0x04
      003801 A4               [48] 1393 	mul	ab
      003802 24 22            [12] 1394 	add	a,#_combos
      003804 FC               [12] 1395 	mov	r4,a
      003805 74 04            [12] 1396 	mov	a,#(_combos>>8)
      003807 35 F0            [12] 1397 	addc	a,b
      003809 FD               [12] 1398 	mov	r5,a
      00380A 8C 82            [24] 1399 	mov	dpl,r4
      00380C 8D 83            [24] 1400 	mov	dph,r5
      00380E 22               [24] 1401 	ret
                                   1402 
                                   1403 	.area CSEG (CODE)
                                   1404 ; function ak820_outline_0058
      00380F                       1405 _ak820_outline_0058:
      00380F E0               [24] 1406 	movx	a,@dptr
      003810 FD               [12] 1407 	mov	r5,a
      003811 A3               [24] 1408 	inc	dptr
      003812 E0               [24] 1409 	movx	a,@dptr
      003813 FE               [12] 1410 	mov	r6,a
      003814 7F 00            [12] 1411 	mov	r7,#0x00
      003816 22               [24] 1412 	ret
                                   1413 
                                   1414 	.area CSEG (CODE)
                                   1415 ; function ak820_outline_0060
      003817                       1416 _ak820_outline_0060:
      003817 E0               [24] 1417 	movx	a,@dptr
      003818 FC               [12] 1418 	mov	r4,a
      003819 A3               [24] 1419 	inc	dptr
      00381A E0               [24] 1420 	movx	a,@dptr
      00381B FD               [12] 1421 	mov	r5,a
      00381C 22               [24] 1422 	ret
                                   1423 
                                   1424 	.area CSEG (CODE)
                                   1425 ; function ak820_outline_0071
      00381D                       1426 _ak820_outline_0071:
      00381D EC               [12] 1427 	mov	a,r4
      00381E F0               [24] 1428 	movx	@dptr,a
      00381F ED               [12] 1429 	mov	a,r5
      003820 A3               [24] 1430 	inc	dptr
      003821 F0               [24] 1431 	movx	@dptr,a
      003822 22               [24] 1432 	ret
                                   1433 
                                   1434 	.area CSEG (CODE)
                                   1435 ; function ak820_outline_0077
      003823                       1436 _ak820_outline_0077:
      003823 EB               [12] 1437 	mov	a,r3
      003824 F0               [24] 1438 	movx	@dptr,a
      003825 EC               [12] 1439 	mov	a,r4
      003826 A3               [24] 1440 	inc	dptr
      003827 F0               [24] 1441 	movx	@dptr,a
      003828 22               [24] 1442 	ret
                                   1443 
                                   1444 	.area CSEG (CODE)
                                   1445 ; function ak820_outline_0097
      003829                       1446 _ak820_outline_0097:
      003829 A3               [24] 1447 	inc	dptr
      00382A F0               [24] 1448 	movx	@dptr,a
      00382B E4               [12] 1449 	clr	a
      00382C A3               [24] 1450 	inc	dptr
      00382D F0               [24] 1451 	movx	@dptr,a
      00382E 22               [24] 1452 	ret
                                   1453 
                                   1454 	.area CSEG (CODE)
                                   1455 ; function ak820_outline_0098
      00382F                       1456 _ak820_outline_0098:
      00382F 8E 82            [24] 1457 	mov	dpl,r6
      003831 8F 83            [24] 1458 	mov	dph,r7
      003833 E0               [24] 1459 	movx	a,@dptr
      003834 22               [24] 1460 	ret
                                   1461 
                                   1462 	.area CSEG (CODE)
                                   1463 ; function ak820_outline_0100
      003835                       1464 _ak820_outline_0100:
      003835 E0               [24] 1465 	movx	a,@dptr
      003836 F8               [12] 1466 	mov	r0,a
      003837 A3               [24] 1467 	inc	dptr
      003838 E0               [24] 1468 	movx	a,@dptr
      003839 F9               [12] 1469 	mov	r1,a
      00383A 22               [24] 1470 	ret
                                   1471 
                                   1472 	.area CSEG (CODE)
                                   1473 ; function ak820_outline_0103
      00383B                       1474 _ak820_outline_0103:
      00383B AF 83            [24] 1475 	mov	r7,dph
      00383D E5 82            [12] 1476 	mov	a,dpl
      00383F 22               [24] 1477 	ret
                                   1478 
                                   1479 	.area CSEG (CODE)
                                   1480 ; function ak820_outline_0104
      003840                       1481 _ak820_outline_0104:
      003840 F0               [24] 1482 	movx	@dptr,a
      003841 EF               [12] 1483 	mov	a,r7
      003842 A3               [24] 1484 	inc	dptr
      003843 F0               [24] 1485 	movx	@dptr,a
      003844 22               [24] 1486 	ret
                                   1487 
                                   1488 	.area CSEG (CODE)
                                   1489 ; function ak820_outline_0108
      003845                       1490 _ak820_outline_0108:
      003845 8E 82            [24] 1491 	mov	dpl,r6
      003847 8F 83            [24] 1492 	mov	dph,r7
      003849 A3               [24] 1493 	inc	dptr
      00384A E0               [24] 1494 	movx	a,@dptr
      00384B 22               [24] 1495 	ret
                                   1496 
                                   1497 	.area CSEG (CODE)
                                   1498 ; function ak820_outline_0117
      00384C                       1499 _ak820_outline_0117:
      00384C 8C 82            [24] 1500 	mov	dpl,r4
      00384E 8D 83            [24] 1501 	mov	dph,r5
      003850 22               [24] 1502 	ret
                                   1503 
                                   1504 	.area CSEG (CODE)
                                   1505 ; function ak820_outline_0121
      003851                       1506 _ak820_outline_0121:
      003851 E0               [24] 1507 	movx	a,@dptr
      003852 FB               [12] 1508 	mov	r3,a
      003853 A3               [24] 1509 	inc	dptr
      003854 E0               [24] 1510 	movx	a,@dptr
      003855 FC               [12] 1511 	mov	r4,a
      003856 22               [24] 1512 	ret
                                   1513 
                                   1514 	.area CSEG (CODE)
                                   1515 ; function ak820_outline_0123
      003857                       1516 _ak820_outline_0123:
      003857 F0               [24] 1517 	movx	@dptr,a
      003858 E4               [12] 1518 	clr	a
      003859 A3               [24] 1519 	inc	dptr
      00385A F0               [24] 1520 	movx	@dptr,a
      00385B 22               [24] 1521 	ret
                                   1522 
                                   1523 	.area CSEG (CODE)
                                   1524 ; function ak820_outline_0132
      00385C                       1525 _ak820_outline_0132:
      00385C 8D 82            [24] 1526 	mov	dpl,r5
      00385E 8E 83            [24] 1527 	mov	dph,r6
      003860 22               [24] 1528 	ret
                                   1529 
                                   1530 	.area CSEG (CODE)
                                   1531 ; function ak820_outline_0135
      003861                       1532 _ak820_outline_0135:
      003861 E5 82            [12] 1533 	mov	a,dpl
      003863 85 83 F0         [24] 1534 	mov	b,dph
      003866 22               [24] 1535 	ret
                                   1536 
                                   1537 	.area CSEG (CODE)
                                   1538 ; function ak820_outline_0152
      003867                       1539 _ak820_outline_0152:
      003867 88 82            [24] 1540 	mov	dpl,r0
      003869 89 83            [24] 1541 	mov	dph,r1
      00386B 22               [24] 1542 	ret
                                   1543 
                                   1544 	.area CSEG (CODE)
                                   1545 ; function ak820_outline_0155
      00386C                       1546 _ak820_outline_0155:
      00386C 2D               [12] 1547 	add	a,r5
      00386D FD               [12] 1548 	mov	r5,a
      00386E E4               [12] 1549 	clr	a
      00386F 3E               [12] 1550 	addc	a,r6
      003870 FE               [12] 1551 	mov	r6,a
      003871 22               [24] 1552 	ret
                                   1553 
                                   1554 	.area CSEG (CODE)
                                   1555 ; function ak820_outline_0165
      003872                       1556 _ak820_outline_0165:
      003872 E0               [24] 1557 	movx	a,@dptr
      003873 FC               [12] 1558 	mov	r4,a
      003874 A3               [24] 1559 	inc	dptr
      003875 E0               [24] 1560 	movx	a,@dptr
      003876 4C               [12] 1561 	orl	a,r4
      003877 22               [24] 1562 	ret
                                   1563 
                                   1564 	.area CSEG (CODE)
                                   1565 ; function ak820_outline_0167
      003878                       1566 _ak820_outline_0167:
      003878 E4               [12] 1567 	clr	a
      003879 33               [12] 1568 	rlc	a
      00387A F5 82            [12] 1569 	mov	dpl,a
      00387C 22               [24] 1570 	ret
                                   1571 
                                   1572 	.area CSEG (CODE)
                                   1573 ; function ak820_outline_0181
      00387D                       1574 _ak820_outline_0181:
      00387D 90 0D 87         [24] 1575 	mov	dptr,#_first
      003880 E0               [24] 1576 	movx	a,@dptr
      003881 22               [24] 1577 	ret
                                   1578 
                                   1579 	.area CSEG (CODE)
                                   1580 ; function ak820_outline_0186
      003882                       1581 _ak820_outline_0186:
      003882 C4               [12] 1582 	swap	a
      003883 03               [12] 1583 	rr	a
      003884 54 F8            [12] 1584 	anl	a,#0xf8
      003886 22               [24] 1585 	ret
