                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module report
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _memset
                                     12 	.globl _ADC_START
                                     13 	.globl _S0_R_FIFO
                                     14 	.globl _S0_T_FIFO
                                     15 	.globl _S0_FREE
                                     16 	.globl _S0_IF_BYTE
                                     17 	.globl _S0_IF_FIRST
                                     18 	.globl _S0_IF_OV
                                     19 	.globl _S0_FST_ACT
                                     20 	.globl _CP_RL2
                                     21 	.globl _C_T2
                                     22 	.globl _TR2
                                     23 	.globl _EXEN2
                                     24 	.globl _TCLK
                                     25 	.globl _RCLK
                                     26 	.globl _EXF2
                                     27 	.globl _CAP1F
                                     28 	.globl _TF2
                                     29 	.globl _RI
                                     30 	.globl _TI
                                     31 	.globl _RB8
                                     32 	.globl _TB8
                                     33 	.globl _REN
                                     34 	.globl _SM2
                                     35 	.globl _SM1
                                     36 	.globl _SM0
                                     37 	.globl _IT0
                                     38 	.globl _IE0
                                     39 	.globl _IT1
                                     40 	.globl _IE1
                                     41 	.globl _TR0
                                     42 	.globl _TF0
                                     43 	.globl _TR1
                                     44 	.globl _TF1
                                     45 	.globl _P4_0
                                     46 	.globl _P4_1
                                     47 	.globl _P4_2
                                     48 	.globl _P4_3
                                     49 	.globl _P4_4
                                     50 	.globl _P4_5
                                     51 	.globl _P4_6
                                     52 	.globl _RXD
                                     53 	.globl _TXD
                                     54 	.globl _INT0
                                     55 	.globl _INT1
                                     56 	.globl _T0
                                     57 	.globl _T1
                                     58 	.globl _MOSI1
                                     59 	.globl _MISO1
                                     60 	.globl _SCK1
                                     61 	.globl _P3_0
                                     62 	.globl _P3_1
                                     63 	.globl _P3_2
                                     64 	.globl _P3_3
                                     65 	.globl _P3_4
                                     66 	.globl _P3_5
                                     67 	.globl _P3_6
                                     68 	.globl _P3_7
                                     69 	.globl _CAP1_
                                     70 	.globl _T2_
                                     71 	.globl _CAP2_
                                     72 	.globl _T2EX_
                                     73 	.globl _RXD1
                                     74 	.globl _TXD1
                                     75 	.globl _P2_0
                                     76 	.globl _P2_1
                                     77 	.globl _P2_2
                                     78 	.globl _P2_3
                                     79 	.globl _P2_4
                                     80 	.globl _P2_5
                                     81 	.globl _P2_6
                                     82 	.globl _P2_7
                                     83 	.globl _AIN0
                                     84 	.globl _AIN1
                                     85 	.globl _AIN2
                                     86 	.globl _AIN3
                                     87 	.globl _AIN4
                                     88 	.globl _AIN5
                                     89 	.globl _AIN6
                                     90 	.globl _AIN7
                                     91 	.globl _CAP1
                                     92 	.globl _T2
                                     93 	.globl _CAP2
                                     94 	.globl _T2EX
                                     95 	.globl _INT0_
                                     96 	.globl _SCS
                                     97 	.globl _MOSI
                                     98 	.globl _MISO
                                     99 	.globl _SCK
                                    100 	.globl _RXD1_
                                    101 	.globl _TXD1_
                                    102 	.globl _P1_0
                                    103 	.globl _P1_1
                                    104 	.globl _P1_2
                                    105 	.globl _P1_3
                                    106 	.globl _P1_4
                                    107 	.globl _P1_5
                                    108 	.globl _P1_6
                                    109 	.globl _P1_7
                                    110 	.globl _AIN8
                                    111 	.globl _AIN9
                                    112 	.globl _AIN10
                                    113 	.globl _AIN11
                                    114 	.globl _AIN12
                                    115 	.globl _AIN13
                                    116 	.globl _RXD_
                                    117 	.globl _TXD_
                                    118 	.globl _SCL0
                                    119 	.globl _SDA0
                                    120 	.globl _P0_0
                                    121 	.globl _P0_1
                                    122 	.globl _P0_2
                                    123 	.globl _P0_3
                                    124 	.globl _P0_4
                                    125 	.globl _P0_5
                                    126 	.globl _P0_6
                                    127 	.globl _P0_7
                                    128 	.globl _IE_SPI0
                                    129 	.globl _IE_USB
                                    130 	.globl _IE_ADC
                                    131 	.globl _IE_UART1
                                    132 	.globl _IE_PWM_I2C
                                    133 	.globl _IE_GPIO
                                    134 	.globl _IE_WDOG
                                    135 	.globl _PX0
                                    136 	.globl _PT0
                                    137 	.globl _PX1
                                    138 	.globl _PT1
                                    139 	.globl _PS
                                    140 	.globl _PT2
                                    141 	.globl _PL_FLAG
                                    142 	.globl _PH_FLAG
                                    143 	.globl _EX0
                                    144 	.globl _ET0
                                    145 	.globl _EX1
                                    146 	.globl _ET1
                                    147 	.globl _ES
                                    148 	.globl _ET2
                                    149 	.globl _E_DIS
                                    150 	.globl _EA
                                    151 	.globl _P
                                    152 	.globl _F1
                                    153 	.globl _OV
                                    154 	.globl _RS0
                                    155 	.globl _RS1
                                    156 	.globl _F0
                                    157 	.globl _AC
                                    158 	.globl _CY
                                    159 	.globl _I2CS_INT_ST
                                    160 	.globl _I2CX_INT
                                    161 	.globl _LED_STATUS
                                    162 	.globl _LED_DMA_H
                                    163 	.globl _LED_DMA_L
                                    164 	.globl _LED_DMA
                                    165 	.globl _LED_PWM_OE
                                    166 	.globl _LED_COMMON
                                    167 	.globl _ADC_CHAN
                                    168 	.globl _ADC_DAT_H
                                    169 	.globl _ADC_DAT_L
                                    170 	.globl _ADC_DAT
                                    171 	.globl _ADC_CTRL
                                    172 	.globl _SPI1_CK_SE
                                    173 	.globl _SPI1_CTRL
                                    174 	.globl _SPI1_DATA
                                    175 	.globl _SPI1_STAT
                                    176 	.globl _SIF1
                                    177 	.globl _SBAUD1
                                    178 	.globl _SBUF1
                                    179 	.globl _SCON1
                                    180 	.globl _SPI0_SETUP
                                    181 	.globl _SPI0_CK_SE
                                    182 	.globl _SPI0_CTRL
                                    183 	.globl _SPI0_DATA
                                    184 	.globl _SPI0_STAT
                                    185 	.globl _T2CAP1H
                                    186 	.globl _T2CAP1L
                                    187 	.globl _T2CAP1
                                    188 	.globl _TH2
                                    189 	.globl _TL2
                                    190 	.globl _T2COUNT
                                    191 	.globl _RCAP2H
                                    192 	.globl _RCAP2L
                                    193 	.globl _RCAP2
                                    194 	.globl _T2MOD
                                    195 	.globl _T2CON
                                    196 	.globl _SBUF
                                    197 	.globl _SCON
                                    198 	.globl _TH1
                                    199 	.globl _TH0
                                    200 	.globl _TL1
                                    201 	.globl _TL0
                                    202 	.globl _TMOD
                                    203 	.globl _TCON
                                    204 	.globl _XBUS_AUX
                                    205 	.globl _P7
                                    206 	.globl _P6_DIR
                                    207 	.globl _P6_OUT_PU
                                    208 	.globl _P6_IN
                                    209 	.globl _P5_DIR
                                    210 	.globl _P5_OUT_PU
                                    211 	.globl _P5_IN
                                    212 	.globl _P4_LED_KEY
                                    213 	.globl _P4_DIR_PU
                                    214 	.globl _P4_MOD_OC
                                    215 	.globl _P4
                                    216 	.globl _P3_DIR_PU
                                    217 	.globl _P3_MOD_OC
                                    218 	.globl _P3
                                    219 	.globl _P2_DIR_PU
                                    220 	.globl _P2_MOD_OC
                                    221 	.globl _P2
                                    222 	.globl _P1_DIR_PU
                                    223 	.globl _P1_MOD_OC
                                    224 	.globl _P1
                                    225 	.globl _P0_DIR_PU
                                    226 	.globl _P0_MOD_OC
                                    227 	.globl _P0
                                    228 	.globl _ROM_CTRL
                                    229 	.globl _ROM_DATA_HH
                                    230 	.globl _ROM_DATA_HL
                                    231 	.globl _ROM_DATA_HI
                                    232 	.globl _ROM_ADDR_H
                                    233 	.globl _ROM_ADDR_L
                                    234 	.globl _ROM_ADDR
                                    235 	.globl _GPIO_IE
                                    236 	.globl _IP_EX
                                    237 	.globl _IE_EX
                                    238 	.globl _IP
                                    239 	.globl _IE
                                    240 	.globl _WDOG_COUNT
                                    241 	.globl _RESET_KEEP
                                    242 	.globl _WAKE_CTRL
                                    243 	.globl _CLOCK_CFG
                                    244 	.globl _POWER_CFG
                                    245 	.globl _PCON
                                    246 	.globl _GLOBAL_CFG
                                    247 	.globl _SAFE_MOD
                                    248 	.globl _DPH
                                    249 	.globl _DPL
                                    250 	.globl _SP
                                    251 	.globl _A_INV
                                    252 	.globl _B
                                    253 	.globl _ACC
                                    254 	.globl _PSW
                                    255 	.globl _del_key_from_report_PARM_2
                                    256 	.globl _add_key_to_report_PARM_2
                                    257 	.globl _del_key_bit_PARM_2
                                    258 	.globl _add_key_bit_PARM_2
                                    259 	.globl _del_key_byte_PARM_2
                                    260 	.globl _add_key_byte_PARM_2
                                    261 	.globl _KEYCODE2CONSUMER
                                    262 	.globl _add_key_byte
                                    263 	.globl _del_key_byte
                                    264 	.globl _add_key_bit
                                    265 	.globl _del_key_bit
                                    266 	.globl _add_key_to_report
                                    267 	.globl _del_key_from_report
                                    268 	.globl _clear_keys_from_report
                                    269 ;--------------------------------------------------------
                                    270 ; special function registers
                                    271 ;--------------------------------------------------------
                                    272 	.area RSEG    (ABS,DATA)
      000000                        273 	.org 0x0000
                           0000D0   274 _PSW	=	0x00d0
                           0000E0   275 _ACC	=	0x00e0
                           0000F0   276 _B	=	0x00f0
                           0000FD   277 _A_INV	=	0x00fd
                           000081   278 _SP	=	0x0081
                           000082   279 _DPL	=	0x0082
                           000083   280 _DPH	=	0x0083
                           0000A1   281 _SAFE_MOD	=	0x00a1
                           0000B1   282 _GLOBAL_CFG	=	0x00b1
                           000087   283 _PCON	=	0x0087
                           0000BA   284 _POWER_CFG	=	0x00ba
                           0000B9   285 _CLOCK_CFG	=	0x00b9
                           0000A9   286 _WAKE_CTRL	=	0x00a9
                           0000FE   287 _RESET_KEEP	=	0x00fe
                           0000FF   288 _WDOG_COUNT	=	0x00ff
                           0000A8   289 _IE	=	0x00a8
                           0000B8   290 _IP	=	0x00b8
                           0000E8   291 _IE_EX	=	0x00e8
                           0000E9   292 _IP_EX	=	0x00e9
                           0000B2   293 _GPIO_IE	=	0x00b2
                           008584   294 _ROM_ADDR	=	0x8584
                           000084   295 _ROM_ADDR_L	=	0x0084
                           000085   296 _ROM_ADDR_H	=	0x0085
                           008F8E   297 _ROM_DATA_HI	=	0x8f8e
                           00008E   298 _ROM_DATA_HL	=	0x008e
                           00008F   299 _ROM_DATA_HH	=	0x008f
                           000086   300 _ROM_CTRL	=	0x0086
                           000080   301 _P0	=	0x0080
                           0000C4   302 _P0_MOD_OC	=	0x00c4
                           0000C5   303 _P0_DIR_PU	=	0x00c5
                           000090   304 _P1	=	0x0090
                           000092   305 _P1_MOD_OC	=	0x0092
                           000093   306 _P1_DIR_PU	=	0x0093
                           0000A0   307 _P2	=	0x00a0
                           000094   308 _P2_MOD_OC	=	0x0094
                           000095   309 _P2_DIR_PU	=	0x0095
                           0000B0   310 _P3	=	0x00b0
                           000096   311 _P3_MOD_OC	=	0x0096
                           000097   312 _P3_DIR_PU	=	0x0097
                           0000C0   313 _P4	=	0x00c0
                           0000C2   314 _P4_MOD_OC	=	0x00c2
                           0000C3   315 _P4_DIR_PU	=	0x00c3
                           0000C1   316 _P4_LED_KEY	=	0x00c1
                           0000AA   317 _P5_IN	=	0x00aa
                           0000AB   318 _P5_OUT_PU	=	0x00ab
                           0000AC   319 _P5_DIR	=	0x00ac
                           0000AD   320 _P6_IN	=	0x00ad
                           0000AE   321 _P6_OUT_PU	=	0x00ae
                           0000AF   322 _P6_DIR	=	0x00af
                           0000F1   323 _P7	=	0x00f1
                           0000A2   324 _XBUS_AUX	=	0x00a2
                           000088   325 _TCON	=	0x0088
                           000089   326 _TMOD	=	0x0089
                           00008A   327 _TL0	=	0x008a
                           00008B   328 _TL1	=	0x008b
                           00008C   329 _TH0	=	0x008c
                           00008D   330 _TH1	=	0x008d
                           000098   331 _SCON	=	0x0098
                           000099   332 _SBUF	=	0x0099
                           0000C8   333 _T2CON	=	0x00c8
                           0000C9   334 _T2MOD	=	0x00c9
                           00CBCA   335 _RCAP2	=	0xcbca
                           0000CA   336 _RCAP2L	=	0x00ca
                           0000CB   337 _RCAP2H	=	0x00cb
                           00CDCC   338 _T2COUNT	=	0xcdcc
                           0000CC   339 _TL2	=	0x00cc
                           0000CD   340 _TH2	=	0x00cd
                           00CFCE   341 _T2CAP1	=	0xcfce
                           0000CE   342 _T2CAP1L	=	0x00ce
                           0000CF   343 _T2CAP1H	=	0x00cf
                           0000F8   344 _SPI0_STAT	=	0x00f8
                           0000F9   345 _SPI0_DATA	=	0x00f9
                           0000FA   346 _SPI0_CTRL	=	0x00fa
                           0000FB   347 _SPI0_CK_SE	=	0x00fb
                           0000FC   348 _SPI0_SETUP	=	0x00fc
                           0000BC   349 _SCON1	=	0x00bc
                           0000BD   350 _SBUF1	=	0x00bd
                           0000BE   351 _SBAUD1	=	0x00be
                           0000BF   352 _SIF1	=	0x00bf
                           0000B4   353 _SPI1_STAT	=	0x00b4
                           0000B5   354 _SPI1_DATA	=	0x00b5
                           0000B6   355 _SPI1_CTRL	=	0x00b6
                           0000B7   356 _SPI1_CK_SE	=	0x00b7
                           0000F3   357 _ADC_CTRL	=	0x00f3
                           00F5F4   358 _ADC_DAT	=	0xf5f4
                           0000F4   359 _ADC_DAT_L	=	0x00f4
                           0000F5   360 _ADC_DAT_H	=	0x00f5
                           0000F6   361 _ADC_CHAN	=	0x00f6
                           0000A6   362 _LED_COMMON	=	0x00a6
                           0000A7   363 _LED_PWM_OE	=	0x00a7
                           00C7C6   364 _LED_DMA	=	0xc7c6
                           0000C6   365 _LED_DMA_L	=	0x00c6
                           0000C7   366 _LED_DMA_H	=	0x00c7
                           0000F7   367 _LED_STATUS	=	0x00f7
                           0000B3   368 _I2CX_INT	=	0x00b3
                           0000BB   369 _I2CS_INT_ST	=	0x00bb
                                    370 ;--------------------------------------------------------
                                    371 ; special function bits
                                    372 ;--------------------------------------------------------
                                    373 	.area RSEG    (ABS,DATA)
      000000                        374 	.org 0x0000
                           0000D7   375 _CY	=	0x00d7
                           0000D6   376 _AC	=	0x00d6
                           0000D5   377 _F0	=	0x00d5
                           0000D4   378 _RS1	=	0x00d4
                           0000D3   379 _RS0	=	0x00d3
                           0000D2   380 _OV	=	0x00d2
                           0000D1   381 _F1	=	0x00d1
                           0000D0   382 _P	=	0x00d0
                           0000AF   383 _EA	=	0x00af
                           0000AE   384 _E_DIS	=	0x00ae
                           0000AD   385 _ET2	=	0x00ad
                           0000AC   386 _ES	=	0x00ac
                           0000AB   387 _ET1	=	0x00ab
                           0000AA   388 _EX1	=	0x00aa
                           0000A9   389 _ET0	=	0x00a9
                           0000A8   390 _EX0	=	0x00a8
                           0000BF   391 _PH_FLAG	=	0x00bf
                           0000BE   392 _PL_FLAG	=	0x00be
                           0000BD   393 _PT2	=	0x00bd
                           0000BC   394 _PS	=	0x00bc
                           0000BB   395 _PT1	=	0x00bb
                           0000BA   396 _PX1	=	0x00ba
                           0000B9   397 _PT0	=	0x00b9
                           0000B8   398 _PX0	=	0x00b8
                           0000EF   399 _IE_WDOG	=	0x00ef
                           0000EE   400 _IE_GPIO	=	0x00ee
                           0000ED   401 _IE_PWM_I2C	=	0x00ed
                           0000EC   402 _IE_UART1	=	0x00ec
                           0000EB   403 _IE_ADC	=	0x00eb
                           0000E9   404 _IE_USB	=	0x00e9
                           0000E8   405 _IE_SPI0	=	0x00e8
                           000087   406 _P0_7	=	0x0087
                           000086   407 _P0_6	=	0x0086
                           000085   408 _P0_5	=	0x0085
                           000084   409 _P0_4	=	0x0084
                           000083   410 _P0_3	=	0x0083
                           000082   411 _P0_2	=	0x0082
                           000081   412 _P0_1	=	0x0081
                           000080   413 _P0_0	=	0x0080
                           000081   414 _SDA0	=	0x0081
                           000080   415 _SCL0	=	0x0080
                           000083   416 _TXD_	=	0x0083
                           000082   417 _RXD_	=	0x0082
                           000085   418 _AIN13	=	0x0085
                           000084   419 _AIN12	=	0x0084
                           000083   420 _AIN11	=	0x0083
                           000082   421 _AIN10	=	0x0082
                           000081   422 _AIN9	=	0x0081
                           000080   423 _AIN8	=	0x0080
                           000097   424 _P1_7	=	0x0097
                           000096   425 _P1_6	=	0x0096
                           000095   426 _P1_5	=	0x0095
                           000094   427 _P1_4	=	0x0094
                           000093   428 _P1_3	=	0x0093
                           000092   429 _P1_2	=	0x0092
                           000091   430 _P1_1	=	0x0091
                           000090   431 _P1_0	=	0x0090
                           000097   432 _TXD1_	=	0x0097
                           000096   433 _RXD1_	=	0x0096
                           000097   434 _SCK	=	0x0097
                           000096   435 _MISO	=	0x0096
                           000095   436 _MOSI	=	0x0095
                           000094   437 _SCS	=	0x0094
                           000092   438 _INT0_	=	0x0092
                           000091   439 _T2EX	=	0x0091
                           000091   440 _CAP2	=	0x0091
                           000090   441 _T2	=	0x0090
                           000090   442 _CAP1	=	0x0090
                           000097   443 _AIN7	=	0x0097
                           000096   444 _AIN6	=	0x0096
                           000095   445 _AIN5	=	0x0095
                           000094   446 _AIN4	=	0x0094
                           000093   447 _AIN3	=	0x0093
                           000092   448 _AIN2	=	0x0092
                           000091   449 _AIN1	=	0x0091
                           000090   450 _AIN0	=	0x0090
                           0000A7   451 _P2_7	=	0x00a7
                           0000A6   452 _P2_6	=	0x00a6
                           0000A5   453 _P2_5	=	0x00a5
                           0000A4   454 _P2_4	=	0x00a4
                           0000A3   455 _P2_3	=	0x00a3
                           0000A2   456 _P2_2	=	0x00a2
                           0000A1   457 _P2_1	=	0x00a1
                           0000A0   458 _P2_0	=	0x00a0
                           0000A7   459 _TXD1	=	0x00a7
                           0000A6   460 _RXD1	=	0x00a6
                           0000A5   461 _T2EX_	=	0x00a5
                           0000A5   462 _CAP2_	=	0x00a5
                           0000A4   463 _T2_	=	0x00a4
                           0000A4   464 _CAP1_	=	0x00a4
                           0000B7   465 _P3_7	=	0x00b7
                           0000B6   466 _P3_6	=	0x00b6
                           0000B5   467 _P3_5	=	0x00b5
                           0000B4   468 _P3_4	=	0x00b4
                           0000B3   469 _P3_3	=	0x00b3
                           0000B2   470 _P3_2	=	0x00b2
                           0000B1   471 _P3_1	=	0x00b1
                           0000B0   472 _P3_0	=	0x00b0
                           0000B7   473 _SCK1	=	0x00b7
                           0000B6   474 _MISO1	=	0x00b6
                           0000B5   475 _MOSI1	=	0x00b5
                           0000B5   476 _T1	=	0x00b5
                           0000B4   477 _T0	=	0x00b4
                           0000B3   478 _INT1	=	0x00b3
                           0000B2   479 _INT0	=	0x00b2
                           0000B1   480 _TXD	=	0x00b1
                           0000B0   481 _RXD	=	0x00b0
                           0000C6   482 _P4_6	=	0x00c6
                           0000C5   483 _P4_5	=	0x00c5
                           0000C4   484 _P4_4	=	0x00c4
                           0000C3   485 _P4_3	=	0x00c3
                           0000C2   486 _P4_2	=	0x00c2
                           0000C1   487 _P4_1	=	0x00c1
                           0000C0   488 _P4_0	=	0x00c0
                           00008F   489 _TF1	=	0x008f
                           00008E   490 _TR1	=	0x008e
                           00008D   491 _TF0	=	0x008d
                           00008C   492 _TR0	=	0x008c
                           00008B   493 _IE1	=	0x008b
                           00008A   494 _IT1	=	0x008a
                           000089   495 _IE0	=	0x0089
                           000088   496 _IT0	=	0x0088
                           00009F   497 _SM0	=	0x009f
                           00009E   498 _SM1	=	0x009e
                           00009D   499 _SM2	=	0x009d
                           00009C   500 _REN	=	0x009c
                           00009B   501 _TB8	=	0x009b
                           00009A   502 _RB8	=	0x009a
                           000099   503 _TI	=	0x0099
                           000098   504 _RI	=	0x0098
                           0000CF   505 _TF2	=	0x00cf
                           0000CF   506 _CAP1F	=	0x00cf
                           0000CE   507 _EXF2	=	0x00ce
                           0000CD   508 _RCLK	=	0x00cd
                           0000CC   509 _TCLK	=	0x00cc
                           0000CB   510 _EXEN2	=	0x00cb
                           0000CA   511 _TR2	=	0x00ca
                           0000C9   512 _C_T2	=	0x00c9
                           0000C8   513 _CP_RL2	=	0x00c8
                           0000FF   514 _S0_FST_ACT	=	0x00ff
                           0000FE   515 _S0_IF_OV	=	0x00fe
                           0000FD   516 _S0_IF_FIRST	=	0x00fd
                           0000FC   517 _S0_IF_BYTE	=	0x00fc
                           0000FB   518 _S0_FREE	=	0x00fb
                           0000FA   519 _S0_T_FIFO	=	0x00fa
                           0000F8   520 _S0_R_FIFO	=	0x00f8
                           0000F7   521 _ADC_START	=	0x00f7
                                    522 ;--------------------------------------------------------
                                    523 ; overlayable register banks
                                    524 ;--------------------------------------------------------
                                    525 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        526 	.ds 8
                                    527 ;--------------------------------------------------------
                                    528 ; internal ram data
                                    529 ;--------------------------------------------------------
                                    530 	.area DSEG    (DATA)
                                    531 ;--------------------------------------------------------
                                    532 ; overlayable items in internal ram
                                    533 ;--------------------------------------------------------
                                    534 ;--------------------------------------------------------
                                    535 ; indirectly addressable internal ram data
                                    536 ;--------------------------------------------------------
                                    537 	.area ISEG    (DATA)
                                    538 ;--------------------------------------------------------
                                    539 ; absolute internal ram data
                                    540 ;--------------------------------------------------------
                                    541 	.area IABS    (ABS,DATA)
                                    542 	.area IABS    (ABS,DATA)
                                    543 ;--------------------------------------------------------
                                    544 ; bit data
                                    545 ;--------------------------------------------------------
                                    546 	.area BSEG    (BIT)
                                    547 ;--------------------------------------------------------
                                    548 ; paged external ram data
                                    549 ;--------------------------------------------------------
                                    550 	.area PSEG    (PAG,XDATA)
                                    551 ;--------------------------------------------------------
                                    552 ; uninitialized external ram data
                                    553 ;--------------------------------------------------------
                                    554 	.area XSEG    (XDATA)
      0007F6                        555 _KEYCODE2CONSUMER_key_10000_117:
      0007F6                        556 	.ds 1
      0007F7                        557 _add_key_byte_PARM_2:
      0007F7                        558 	.ds 1
      0007F8                        559 _add_key_byte_report_arg_10000_144:
      0007F8                        560 	.ds 2
      0007FA                        561 _add_key_byte_empty_10000_145:
      0007FA                        562 	.ds 1
      0007FB                        563 _del_key_byte_PARM_2:
      0007FB                        564 	.ds 1
      0007FC                        565 _del_key_byte_report_arg_10000_156:
      0007FC                        566 	.ds 2
      0007FE                        567 _add_key_bit_PARM_2:
      0007FE                        568 	.ds 1
      0007FF                        569 _add_key_bit_report_arg_10000_162:
      0007FF                        570 	.ds 2
      000801                        571 _del_key_bit_PARM_2:
      000801                        572 	.ds 1
      000802                        573 _del_key_bit_report_arg_10000_167:
      000802                        574 	.ds 2
      000804                        575 _add_key_to_report_PARM_2:
      000804                        576 	.ds 1
      000805                        577 _add_key_to_report_report_arg_10000_172:
      000805                        578 	.ds 2
      000807                        579 _del_key_from_report_PARM_2:
      000807                        580 	.ds 1
      000808                        581 _del_key_from_report_report_arg_10000_176:
      000808                        582 	.ds 2
      00080A                        583 _clear_keys_from_report_report_arg_10000_180:
      00080A                        584 	.ds 2
                                    585 ;--------------------------------------------------------
                                    586 ; absolute external ram data
                                    587 ;--------------------------------------------------------
                                    588 	.area XABS    (ABS,XDATA)
                                    589 ;--------------------------------------------------------
                                    590 ; initialized external ram data
                                    591 ;--------------------------------------------------------
                                    592 	.area XISEG   (XDATA)
                                    593 	.area HOME    (CODE)
                                    594 	.area GSINIT0 (CODE)
                                    595 	.area GSINIT1 (CODE)
                                    596 	.area GSINIT2 (CODE)
                                    597 	.area GSINIT3 (CODE)
                                    598 	.area GSINIT4 (CODE)
                                    599 	.area GSINIT5 (CODE)
                                    600 	.area GSINIT  (CODE)
                                    601 	.area GSFINAL (CODE)
                                    602 	.area CSEG    (CODE)
                                    603 ;--------------------------------------------------------
                                    604 ; global & static initialisations
                                    605 ;--------------------------------------------------------
                                    606 	.area HOME    (CODE)
                                    607 	.area GSINIT  (CODE)
                                    608 	.area GSFINAL (CODE)
                                    609 	.area GSINIT  (CODE)
                                    610 ;--------------------------------------------------------
                                    611 ; Home
                                    612 ;--------------------------------------------------------
                                    613 	.area HOME    (CODE)
                                    614 	.area HOME    (CODE)
                                    615 ;--------------------------------------------------------
                                    616 ; code
                                    617 ;--------------------------------------------------------
                                    618 	.area CSEG    (CODE)
                                    619 ;------------------------------------------------------------
                                    620 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    621 ;------------------------------------------------------------
                                    622 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    623 ;------------------------------------------------------------
                                    624 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    625 ;	-----------------------------------------
                           000007   626 	ar7 = 0x07
                           000006   627 	ar6 = 0x06
                           000005   628 	ar5 = 0x05
                           000004   629 	ar4 = 0x04
                           000003   630 	ar3 = 0x03
                           000002   631 	ar2 = 0x02
                           000001   632 	ar1 = 0x01
                           000000   633 	ar0 = 0x00
                                    634 ;	 function KEYCODE2CONSUMER
                                    635 ;	-----------------------------------------
      006ECE                        636 _KEYCODE2CONSUMER:
      006ECE E5 82            [12]  637 	mov	a,dpl
      006ED0 90 07 F6         [24]  638 	mov	dptr,#_KEYCODE2CONSUMER_key_10000_117
      006ED3 F0               [24]  639 	movx	@dptr,a
                                    640 ;	tmk_core/protocol/report.c:43: if (key < KC_AUDIO_MUTE || key > KC_LAUNCHPAD) return 0;
      006ED4 E0               [24]  641 	movx	a,@dptr
      006ED5 FF               [12]  642 	mov	r7,a
      006ED6 BF A8 00         [24]  643 	cjne	r7,#0xa8,00113$
      006ED9                        644 00113$:
      006ED9 40 05            [24]  645 	jc	00101$
      006EDB EF               [12]  646 	mov	a,r7
      006EDC 24 3D            [12]  647 	add	a,#0xff - 0xc2
      006EDE 50 04            [24]  648 	jnc	00102$
                                    649 ;	free result
      006EE0                        650 00101$:
      006EE0 90 00 00         [24]  651 	mov	dptr,#0x0000
      006EE3 22               [24]  652 	ret
      006EE4                        653 00102$:
                                    654 ;	tmk_core/protocol/report.c:44: return usages[key - KC_AUDIO_MUTE];
      006EE4 EF               [12]  655 	mov	a,r7
      006EE5 24 58            [12]  656 	add	a,#0x58
      006EE7 FF               [12]  657 	mov	r7,a
      006EE8 C2 D5            [12]  658 	clr	F0
      006EEA 75 F0 02         [24]  659 	mov	b,#0x02
      006EED EF               [12]  660 	mov	a,r7
      006EEE 30 E7 04         [24]  661 	jnb	acc.7,00116$
      006EF1 B2 D5            [12]  662 	cpl	F0
      006EF3 F4               [12]  663 	cpl	a
      006EF4 04               [12]  664 	inc	a
      006EF5                        665 00116$:
      006EF5 A4               [48]  666 	mul	ab
      006EF6 30 D5 03         [24]  667 	jnb	F0,00117$
      006EF9 12 70 DD         [24]  668 	lcall	_ak820_outline_0128
      006EFC                        669 00117$:
      006EFC 24 76            [12]  670 	add	a, #_KEYCODE2CONSUMER_usages_10000_118
      006EFE F5 82            [12]  671 	mov	dpl,a
      006F00 74 B8            [12]  672 	mov	a,#(_KEYCODE2CONSUMER_usages_10000_118 >> 8)
      006F02 12 57 8C         [24]  673 	lcall	_ak820_outline_0105
      006F05 FE               [12]  674 	mov	r6,a
      006F06 A3               [24]  675 	inc	dptr
      006F07 E4               [12]  676 	clr	a
      006F08 93               [24]  677 	movc	a,@a+dptr
                                    678 ;	tmk_core/protocol/report.c:45: }
      006F09 8E 82            [24]  679 	mov	dpl,r6
      006F0B F5 83            [12]  680 	mov	dph,a
      006F0D 22               [24]  681 	ret
                                    682 ;------------------------------------------------------------
                                    683 ;Allocation info for local variables in function 'has_anykey'
                                    684 ;------------------------------------------------------------
                                    685 ;report_arg    Allocated with name '_has_anykey_report_arg_10000_120'
                                    686 ;keyboard_report Allocated with name '_has_anykey_keyboard_report_10000_121'
                                    687 ;cnt           Allocated with name '_has_anykey_cnt_10000_121'
                                    688 ;p             Allocated with name '_has_anykey_p_10000_121'
                                    689 ;lp            Allocated with name '_has_anykey_lp_10000_121'
                                    690 ;------------------------------------------------------------
                                    691 ;	tmk_core/protocol/report.c:62: uint8_t has_anykey(report_keyboard_t AK820_REPORT_MEM* report_arg) {
                                    692 ;	-----------------------------------------
                                    693 ;	 function add_key_byte
                                    694 ;	-----------------------------------------
      006F0E                        695 _add_key_byte:
      006F0E 12 38 3B         [24]  696 	lcall	_ak820_outline_0103
      006F11 90 07 F8         [24]  697 	mov	dptr,#_add_key_byte_report_arg_10000_144
      006F14 12 38 40         [24]  698 	lcall	_ak820_outline_0104
                                    699 ;	tmk_core/protocol/report.c:139: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      006F17 90 07 F8         [24]  700 	mov	dptr,#_add_key_byte_report_arg_10000_144
      006F1A 12 37 F8         [24]  701 	lcall	_ak820_outline_0051
                                    702 ;	tmk_core/protocol/report.c:185: int8_t empty = -1;
      006F1D 90 07 FA         [24]  703 	mov	dptr,#_add_key_byte_empty_10000_145
      006F20 74 FF            [12]  704 	mov	a,#0xff
      006F22 F0               [24]  705 	movx	@dptr,a
                                    706 ;	tmk_core/protocol/report.c:200: }
      006F23 7D 00            [12]  707 	mov	r5,#0x00
      006F25                        708 00112$:
                                    709 ;	tmk_core/protocol/report.c:186: for (; i < KEYBOARD_REPORT_KEYS; i++) {
      006F25 C3               [12]  710 	clr	c
      006F26 ED               [12]  711 	mov	a,r5
      006F27 64 80            [12]  712 	xrl	a,#0x80
      006F29 94 86            [12]  713 	subb	a,#0x86
      006F2B 50 29            [24]  714 	jnc	00106$
                                    715 ;	tmk_core/protocol/report.c:187: if (keyboard_report->keys[i] == code) {
      006F2D 12 70 E8         [24]  716 	lcall	_ak820_outline_0142
      006F30 F5 82            [12]  717 	mov	dpl,a
      006F32 E4               [12]  718 	clr	a
      006F33 3C               [12]  719 	addc	a, r4
      006F34 F5 83            [12]  720 	mov	dph,a
      006F36 E0               [24]  721 	movx	a,@dptr
      006F37 FC               [12]  722 	mov	r4,a
      006F38 90 07 F7         [24]  723 	mov	dptr,#_add_key_byte_PARM_2
      006F3B E0               [24]  724 	movx	a,@dptr
      006F3C FB               [12]  725 	mov	r3,a
      006F3D EC               [12]  726 	mov	a,r4
      006F3E B5 03 02         [24]  727 	cjne	a,ar3,00167$
      006F41 80 13            [24]  728 	sjmp	00106$
      006F43                        729 00167$:
                                    730 ;	tmk_core/protocol/report.c:190: if (empty == -1 && keyboard_report->keys[i] == 0) {
      006F43 90 07 FA         [24]  731 	mov	dptr,#_add_key_byte_empty_10000_145
      006F46 E0               [24]  732 	movx	a,@dptr
      006F47 FB               [12]  733 	mov	r3,a
      006F48 BB FF 08         [24]  734 	cjne	r3,#0xff,00113$
      006F4B EC               [12]  735 	mov	a,r4
      006F4C 70 05            [24]  736 	jnz	00113$
                                    737 ;	tmk_core/protocol/report.c:191: empty = i;
      006F4E 90 07 FA         [24]  738 	mov	dptr,#_add_key_byte_empty_10000_145
      006F51 ED               [12]  739 	mov	a,r5
      006F52 F0               [24]  740 	movx	@dptr,a
      006F53                        741 00113$:
                                    742 ;	tmk_core/protocol/report.c:186: for (; i < KEYBOARD_REPORT_KEYS; i++) {
      006F53 0D               [12]  743 	inc	r5
      006F54 80 CF            [24]  744 	sjmp	00112$
      006F56                        745 00106$:
                                    746 ;	tmk_core/protocol/report.c:194: if (i == KEYBOARD_REPORT_KEYS) {
      006F56 BD 06 1C         [24]  747 	cjne	r5,#0x06,00114$
                                    748 ;	tmk_core/protocol/report.c:195: if (empty != -1) {
      006F59 90 07 FA         [24]  749 	mov	dptr,#_add_key_byte_empty_10000_145
      006F5C E0               [24]  750 	movx	a,@dptr
      006F5D FD               [12]  751 	mov	r5,a
      006F5E BD FF 01         [24]  752 	cjne	r5,#0xff,00173$
      006F61 22               [24]  753 	ret
      006F62                        754 00173$:
                                    755 ;	tmk_core/protocol/report.c:196: keyboard_report->keys[empty] = code;
      006F62 74 02            [12]  756 	mov	a,#0x02
      006F64 12 43 90         [24]  757 	lcall	_ak820_outline_0134
      006F67 ED               [12]  758 	mov	a,r5
      006F68 2E               [12]  759 	add	a, r6
      006F69 FD               [12]  760 	mov	r5,a
      006F6A E4               [12]  761 	clr	a
      006F6B 3F               [12]  762 	addc	a, r7
      006F6C FC               [12]  763 	mov	r4,a
      006F6D 90 07 F7         [24]  764 	mov	dptr,#_add_key_byte_PARM_2
      006F70 E0               [24]  765 	movx	a,@dptr
      006F71 12 43 C1         [24]  766 	lcall	_ak820_outline_0184
      006F74 F0               [24]  767 	movx	@dptr,a
      006F75                        768 00114$:
                                    769 ;	tmk_core/protocol/report.c:200: }
      006F75 22               [24]  770 	ret
                                    771 ;------------------------------------------------------------
                                    772 ;Allocation info for local variables in function 'del_key_byte'
                                    773 ;------------------------------------------------------------
                                    774 ;code          Allocated with name '_del_key_byte_PARM_2'
                                    775 ;report_arg    Allocated with name '_del_key_byte_report_arg_10000_156'
                                    776 ;keyboard_report Allocated with name '_del_key_byte_keyboard_report_10000_157'
                                    777 ;i             Allocated with name '_del_key_byte_i_20000_158'
                                    778 ;------------------------------------------------------------
                                    779 ;	tmk_core/protocol/report.c:206: void del_key_byte(report_keyboard_t AK820_REPORT_MEM* report_arg, uint8_t code) {
                                    780 ;	-----------------------------------------
                                    781 ;	 function del_key_byte
                                    782 ;	-----------------------------------------
      006F76                        783 _del_key_byte:
      006F76 12 38 3B         [24]  784 	lcall	_ak820_outline_0103
      006F79 90 07 FC         [24]  785 	mov	dptr,#_del_key_byte_report_arg_10000_156
      006F7C 12 38 40         [24]  786 	lcall	_ak820_outline_0104
                                    787 ;	tmk_core/protocol/report.c:207: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      006F7F 90 07 FC         [24]  788 	mov	dptr,#_del_key_byte_report_arg_10000_156
      006F82 12 37 F8         [24]  789 	lcall	_ak820_outline_0051
                                    790 ;	tmk_core/protocol/report.c:234: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; i++) {
      006F85 7D 00            [12]  791 	mov	r5,#0x00
      006F87                        792 00105$:
      006F87 BD 06 00         [24]  793 	cjne	r5,#0x06,00131$
      006F8A                        794 00131$:
      006F8A 50 1A            [24]  795 	jnc	00107$
                                    796 ;	tmk_core/protocol/report.c:235: if (keyboard_report->keys[i] == code) {
      006F8C 12 70 E8         [24]  797 	lcall	_ak820_outline_0142
      006F8F FB               [12]  798 	mov	r3,a
      006F90 E4               [12]  799 	clr	a
      006F91 3C               [12]  800 	addc	a, r4
      006F92 12 49 56         [24]  801 	lcall	_ak820_outline_0056
      006F95 90 07 FB         [24]  802 	mov	dptr,#_del_key_byte_PARM_2
      006F98 E0               [24]  803 	movx	a,@dptr
      006F99 F9               [12]  804 	mov	r1,a
      006F9A EA               [12]  805 	mov	a,r2
      006F9B B5 01 05         [24]  806 	cjne	a,ar1,00106$
                                    807 ;	tmk_core/protocol/report.c:236: keyboard_report->keys[i] = 0;
      006F9E 12 33 FC         [24]  808 	lcall	_ak820_outline_0122
      006FA1 E4               [12]  809 	clr	a
      006FA2 F0               [24]  810 	movx	@dptr,a
      006FA3                        811 00106$:
                                    812 ;	tmk_core/protocol/report.c:234: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; i++) {
      006FA3 0D               [12]  813 	inc	r5
      006FA4 80 E1            [24]  814 	sjmp	00105$
      006FA6                        815 00107$:
                                    816 ;	tmk_core/protocol/report.c:240: }
      006FA6 22               [24]  817 	ret
                                    818 ;------------------------------------------------------------
                                    819 ;Allocation info for local variables in function 'add_key_bit'
                                    820 ;------------------------------------------------------------
                                    821 ;code          Allocated with name '_add_key_bit_PARM_2'
                                    822 ;report_arg    Allocated with name '_add_key_bit_report_arg_10000_162'
                                    823 ;keyboard_report Allocated with name '_add_key_bit_keyboard_report_10000_163'
                                    824 ;------------------------------------------------------------
                                    825 ;	tmk_core/protocol/report.c:247: void add_key_bit(report_keyboard_t AK820_REPORT_MEM* report_arg, uint8_t code) {
                                    826 ;	-----------------------------------------
                                    827 ;	 function add_key_bit
                                    828 ;	-----------------------------------------
      006FA7                        829 _add_key_bit:
      006FA7 12 38 3B         [24]  830 	lcall	_ak820_outline_0103
      006FAA 90 07 FF         [24]  831 	mov	dptr,#_add_key_bit_report_arg_10000_162
      006FAD 12 38 40         [24]  832 	lcall	_ak820_outline_0104
                                    833 ;	tmk_core/protocol/report.c:248: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      006FB0 90 07 FF         [24]  834 	mov	dptr,#_add_key_bit_report_arg_10000_162
      006FB3 12 37 F8         [24]  835 	lcall	_ak820_outline_0051
                                    836 ;	tmk_core/protocol/report.c:249: if ((code >> 3) < KEYBOARD_REPORT_BITS) {
      006FB6 90 07 FE         [24]  837 	mov	dptr,#_add_key_bit_PARM_2
      006FB9 E0               [24]  838 	movx	a,@dptr
      006FBA FD               [12]  839 	mov	r5,a
      006FBB 12 57 C2         [24]  840 	lcall	_ak820_outline_0183
      006FBE FC               [12]  841 	mov	r4,a
      006FBF BC 1E 00         [24]  842 	cjne	r4,#0x1e,00112$
      006FC2                        843 00112$:
      006FC2 50 16            [24]  844 	jnc	00103$
                                    845 ;	tmk_core/protocol/report.c:250: keyboard_report->nkro.bits[code >> 3] |= 1 << (code & 7);
      006FC4 12 70 C6         [24]  846 	lcall	_ak820_outline_0032
      006FC7 80 02            [24]  847 	sjmp	00115$
      006FC9                        848 00114$:
      006FC9 25 E0            [12]  849 	add	a,acc
      006FCB                        850 00115$:
      006FCB D5 F0 FB         [24]  851 	djnz	b,00114$
      006FCE FF               [12]  852 	mov	r7,a
      006FCF 12 43 BC         [24]  853 	lcall	_ak820_outline_0180
      006FD2 E0               [24]  854 	movx	a,@dptr
      006FD3 42 07            [12]  855 	orl	ar7,a
      006FD5 12 43 BC         [24]  856 	lcall	_ak820_outline_0180
      006FD8 EF               [12]  857 	mov	a,r7
      006FD9 F0               [24]  858 	movx	@dptr,a
      006FDA                        859 00103$:
                                    860 ;	tmk_core/protocol/report.c:254: }
      006FDA 22               [24]  861 	ret
                                    862 ;------------------------------------------------------------
                                    863 ;Allocation info for local variables in function 'del_key_bit'
                                    864 ;------------------------------------------------------------
                                    865 ;code          Allocated with name '_del_key_bit_PARM_2'
                                    866 ;report_arg    Allocated with name '_del_key_bit_report_arg_10000_167'
                                    867 ;keyboard_report Allocated with name '_del_key_bit_keyboard_report_10000_168'
                                    868 ;------------------------------------------------------------
                                    869 ;	tmk_core/protocol/report.c:260: void del_key_bit(report_keyboard_t AK820_REPORT_MEM* report_arg, uint8_t code) {
                                    870 ;	-----------------------------------------
                                    871 ;	 function del_key_bit
                                    872 ;	-----------------------------------------
      006FDB                        873 _del_key_bit:
      006FDB 12 38 3B         [24]  874 	lcall	_ak820_outline_0103
      006FDE 90 08 02         [24]  875 	mov	dptr,#_del_key_bit_report_arg_10000_167
      006FE1 12 38 40         [24]  876 	lcall	_ak820_outline_0104
                                    877 ;	tmk_core/protocol/report.c:261: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      006FE4 90 08 02         [24]  878 	mov	dptr,#_del_key_bit_report_arg_10000_167
      006FE7 12 37 F8         [24]  879 	lcall	_ak820_outline_0051
                                    880 ;	tmk_core/protocol/report.c:262: if ((code >> 3) < KEYBOARD_REPORT_BITS) {
      006FEA 90 08 01         [24]  881 	mov	dptr,#_del_key_bit_PARM_2
      006FED E0               [24]  882 	movx	a,@dptr
      006FEE FD               [12]  883 	mov	r5,a
      006FEF 12 57 C2         [24]  884 	lcall	_ak820_outline_0183
      006FF2 FC               [12]  885 	mov	r4,a
      006FF3 BC 1E 00         [24]  886 	cjne	r4,#0x1e,00112$
      006FF6                        887 00112$:
      006FF6 50 17            [24]  888 	jnc	00103$
                                    889 ;	tmk_core/protocol/report.c:263: keyboard_report->nkro.bits[code >> 3] &= ~(1 << (code & 7));
      006FF8 12 70 C6         [24]  890 	lcall	_ak820_outline_0032
      006FFB 80 02            [24]  891 	sjmp	00115$
      006FFD                        892 00114$:
      006FFD 25 E0            [12]  893 	add	a,acc
      006FFF                        894 00115$:
      006FFF D5 F0 FB         [24]  895 	djnz	b,00114$
      007002 F4               [12]  896 	cpl	a
      007003 FF               [12]  897 	mov	r7,a
      007004 12 43 BC         [24]  898 	lcall	_ak820_outline_0180
      007007 E0               [24]  899 	movx	a,@dptr
      007008 52 07            [12]  900 	anl	ar7,a
      00700A 12 43 BC         [24]  901 	lcall	_ak820_outline_0180
      00700D EF               [12]  902 	mov	a,r7
      00700E F0               [24]  903 	movx	@dptr,a
      00700F                        904 00103$:
                                    905 ;	tmk_core/protocol/report.c:267: }
      00700F 22               [24]  906 	ret
                                    907 ;------------------------------------------------------------
                                    908 ;Allocation info for local variables in function 'add_key_to_report'
                                    909 ;------------------------------------------------------------
                                    910 ;key           Allocated with name '_add_key_to_report_PARM_2'
                                    911 ;report_arg    Allocated with name '_add_key_to_report_report_arg_10000_172'
                                    912 ;keyboard_report Allocated with name '_add_key_to_report_keyboard_report_10000_173'
                                    913 ;------------------------------------------------------------
                                    914 ;	tmk_core/protocol/report.c:274: void add_key_to_report(report_keyboard_t AK820_REPORT_MEM* report_arg, uint8_t key) {
                                    915 ;	-----------------------------------------
                                    916 ;	 function add_key_to_report
                                    917 ;	-----------------------------------------
      007010                        918 _add_key_to_report:
      007010 12 38 3B         [24]  919 	lcall	_ak820_outline_0103
      007013 90 08 05         [24]  920 	mov	dptr,#_add_key_to_report_report_arg_10000_172
      007016 12 38 40         [24]  921 	lcall	_ak820_outline_0104
                                    922 ;	tmk_core/protocol/report.c:275: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      007019 90 08 05         [24]  923 	mov	dptr,#_add_key_to_report_report_arg_10000_172
      00701C 12 37 F8         [24]  924 	lcall	_ak820_outline_0051
                                    925 ;	tmk_core/protocol/report.c:277: if (keyboard_protocol && keymap_config.nkro) {
      00701F 90 0D 8B         [24]  926 	mov	dptr,#_keyboard_protocol
      007022 E0               [24]  927 	movx	a,@dptr
      007023 60 14            [24]  928 	jz	00102$
      007025 90 0A BD         [24]  929 	mov	dptr,#_keymap_config
      007028 E0               [24]  930 	movx	a,@dptr
      007029 30 E7 0D         [24]  931 	jnb	acc.7,00102$
                                    932 ;	tmk_core/protocol/report.c:278: add_key_bit(keyboard_report, key);
      00702C 90 08 04         [24]  933 	mov	dptr,#_add_key_to_report_PARM_2
      00702F E0               [24]  934 	movx	a,@dptr
      007030 90 07 FE         [24]  935 	mov	dptr,#_add_key_bit_PARM_2
      007033 12 43 5B         [24]  936 	lcall	_ak820_outline_0061
                                    937 ;	tmk_core/protocol/report.c:279: return;
      007036 02 6F A7         [24]  938 	ljmp	_add_key_bit
      007039                        939 00102$:
                                    940 ;	tmk_core/protocol/report.c:282: add_key_byte(keyboard_report, key);
      007039 90 08 04         [24]  941 	mov	dptr,#_add_key_to_report_PARM_2
      00703C E0               [24]  942 	movx	a,@dptr
      00703D 90 07 F7         [24]  943 	mov	dptr,#_add_key_byte_PARM_2
      007040 12 43 5B         [24]  944 	lcall	_ak820_outline_0061
                                    945 ;	tmk_core/protocol/report.c:283: }
      007043 02 6F 0E         [24]  946 	ljmp	_add_key_byte
                                    947 ;------------------------------------------------------------
                                    948 ;Allocation info for local variables in function 'del_key_from_report'
                                    949 ;------------------------------------------------------------
                                    950 ;key           Allocated with name '_del_key_from_report_PARM_2'
                                    951 ;report_arg    Allocated with name '_del_key_from_report_report_arg_10000_176'
                                    952 ;keyboard_report Allocated with name '_del_key_from_report_keyboard_report_10000_177'
                                    953 ;------------------------------------------------------------
                                    954 ;	tmk_core/protocol/report.c:289: void del_key_from_report(report_keyboard_t AK820_REPORT_MEM* report_arg, uint8_t key) {
                                    955 ;	-----------------------------------------
                                    956 ;	 function del_key_from_report
                                    957 ;	-----------------------------------------
      007046                        958 _del_key_from_report:
      007046 12 38 3B         [24]  959 	lcall	_ak820_outline_0103
      007049 90 08 08         [24]  960 	mov	dptr,#_del_key_from_report_report_arg_10000_176
      00704C 12 38 40         [24]  961 	lcall	_ak820_outline_0104
                                    962 ;	tmk_core/protocol/report.c:290: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      00704F 90 08 08         [24]  963 	mov	dptr,#_del_key_from_report_report_arg_10000_176
      007052 12 37 F8         [24]  964 	lcall	_ak820_outline_0051
                                    965 ;	tmk_core/protocol/report.c:292: if (keyboard_protocol && keymap_config.nkro) {
      007055 90 0D 8B         [24]  966 	mov	dptr,#_keyboard_protocol
      007058 E0               [24]  967 	movx	a,@dptr
      007059 60 14            [24]  968 	jz	00102$
      00705B 90 0A BD         [24]  969 	mov	dptr,#_keymap_config
      00705E E0               [24]  970 	movx	a,@dptr
      00705F 30 E7 0D         [24]  971 	jnb	acc.7,00102$
                                    972 ;	tmk_core/protocol/report.c:293: del_key_bit(keyboard_report, key);
      007062 90 08 07         [24]  973 	mov	dptr,#_del_key_from_report_PARM_2
      007065 E0               [24]  974 	movx	a,@dptr
      007066 90 08 01         [24]  975 	mov	dptr,#_del_key_bit_PARM_2
      007069 12 43 5B         [24]  976 	lcall	_ak820_outline_0061
                                    977 ;	tmk_core/protocol/report.c:294: return;
      00706C 02 6F DB         [24]  978 	ljmp	_del_key_bit
      00706F                        979 00102$:
                                    980 ;	tmk_core/protocol/report.c:297: del_key_byte(keyboard_report, key);
      00706F 90 08 07         [24]  981 	mov	dptr,#_del_key_from_report_PARM_2
      007072 E0               [24]  982 	movx	a,@dptr
      007073 90 07 FB         [24]  983 	mov	dptr,#_del_key_byte_PARM_2
      007076 12 43 5B         [24]  984 	lcall	_ak820_outline_0061
                                    985 ;	tmk_core/protocol/report.c:298: }
      007079 02 6F 76         [24]  986 	ljmp	_del_key_byte
                                    987 ;------------------------------------------------------------
                                    988 ;Allocation info for local variables in function 'clear_keys_from_report'
                                    989 ;------------------------------------------------------------
                                    990 ;report_arg    Allocated with name '_clear_keys_from_report_report_arg_10000_180'
                                    991 ;keyboard_report Allocated with name '_clear_keys_from_report_keyboard_report_10000_181'
                                    992 ;------------------------------------------------------------
                                    993 ;	tmk_core/protocol/report.c:304: void clear_keys_from_report(report_keyboard_t AK820_REPORT_MEM* report_arg) {
                                    994 ;	-----------------------------------------
                                    995 ;	 function clear_keys_from_report
                                    996 ;	-----------------------------------------
      00707C                        997 _clear_keys_from_report:
      00707C 12 38 3B         [24]  998 	lcall	_ak820_outline_0103
      00707F 90 08 0A         [24]  999 	mov	dptr,#_clear_keys_from_report_report_arg_10000_180
      007082 12 38 40         [24] 1000 	lcall	_ak820_outline_0104
                                   1001 ;	tmk_core/protocol/report.c:305: report_keyboard_t AK820_REPORT_MEM* keyboard_report = (report_keyboard_t AK820_REPORT_MEM*)report_arg;
      007085 90 08 0A         [24] 1002 	mov	dptr,#_clear_keys_from_report_report_arg_10000_180
      007088 12 37 F8         [24] 1003 	lcall	_ak820_outline_0051
                                   1004 ;	tmk_core/protocol/report.c:308: if (keyboard_protocol && keymap_config.nkro) {
      00708B 90 0D 8B         [24] 1005 	mov	dptr,#_keyboard_protocol
      00708E E0               [24] 1006 	movx	a,@dptr
      00708F 60 1E            [24] 1007 	jz	00102$
      007091 90 0A BD         [24] 1008 	mov	dptr,#_keymap_config
      007094 E0               [24] 1009 	movx	a,@dptr
      007095 30 E7 17         [24] 1010 	jnb	acc.7,00102$
                                   1011 ;	tmk_core/protocol/report.c:309: memset(keyboard_report->nkro.bits, 0, sizeof(keyboard_report->nkro.bits));
      007098 74 02            [12] 1012 	mov	a,#0x02
      00709A 12 43 AB         [24] 1013 	lcall	_ak820_outline_0156
      00709D 7B 00            [12] 1014 	mov	r3,#0x00
      00709F 12 70 F2         [24] 1015 	lcall	_ak820_outline_0177
      0070A2 74 1E            [12] 1016 	mov	a,#0x1e
      0070A4 12 38 57         [24] 1017 	lcall	_ak820_outline_0123
      0070A7 12 38 4C         [24] 1018 	lcall	_ak820_outline_0117
      0070AA 8B F0            [24] 1019 	mov	b, r3
                                   1020 ;	tmk_core/protocol/report.c:310: return;
      0070AC 02 B7 67         [24] 1021 	ljmp	_memset
      0070AF                       1022 00102$:
                                   1023 ;	tmk_core/protocol/report.c:313: memset(keyboard_report->keys, 0, sizeof(keyboard_report->keys));
      0070AF 74 02            [12] 1024 	mov	a,#0x02
      0070B1 12 43 90         [24] 1025 	lcall	_ak820_outline_0134
      0070B4 7D 00            [12] 1026 	mov	r5,#0x00
      0070B6 12 70 F2         [24] 1027 	lcall	_ak820_outline_0177
      0070B9 74 06            [12] 1028 	mov	a,#0x06
      0070BB F0               [24] 1029 	movx	@dptr,a
      0070BC E4               [12] 1030 	clr	a
      0070BD A3               [24] 1031 	inc	dptr
      0070BE 12 43 5B         [24] 1032 	lcall	_ak820_outline_0061
      0070C1 8D F0            [24] 1033 	mov	b, r5
                                   1034 ;	tmk_core/protocol/report.c:314: }
      0070C3 02 B7 67         [24] 1035 	ljmp	_memset
                                   1036 	.area CSEG    (CODE)
                                   1037 	.area CONST   (CODE)
                                   1038 	.area CONST   (CODE)
      00B876                       1039 _KEYCODE2CONSUMER_usages_10000_118:
      00B876 E2 00                 1040 	.byte #0xe2, #0x00	; 226
      00B878 E9 00                 1041 	.byte #0xe9, #0x00	; 233
      00B87A EA 00                 1042 	.byte #0xea, #0x00	; 234
      00B87C B5 00                 1043 	.byte #0xb5, #0x00	; 181
      00B87E B6 00                 1044 	.byte #0xb6, #0x00	; 182
      00B880 B7 00                 1045 	.byte #0xb7, #0x00	; 183
      00B882 CD 00                 1046 	.byte #0xcd, #0x00	; 205
      00B884 83 01                 1047 	.byte #0x83, #0x01	; 387
      00B886 CC 00                 1048 	.byte #0xcc, #0x00	; 204
      00B888 8A 01                 1049 	.byte #0x8a, #0x01	; 394
      00B88A 92 01                 1050 	.byte #0x92, #0x01	; 402
      00B88C 94 01                 1051 	.byte #0x94, #0x01	; 404
      00B88E 21 02                 1052 	.byte #0x21, #0x02	; 545
      00B890 23 02                 1053 	.byte #0x23, #0x02	; 547
      00B892 24 02                 1054 	.byte #0x24, #0x02	; 548
      00B894 25 02                 1055 	.byte #0x25, #0x02	; 549
      00B896 26 02                 1056 	.byte #0x26, #0x02	; 550
      00B898 27 02                 1057 	.byte #0x27, #0x02	; 551
      00B89A 2A 02                 1058 	.byte #0x2a, #0x02	; 554
      00B89C B3 00                 1059 	.byte #0xb3, #0x00	; 179
      00B89E B4 00                 1060 	.byte #0xb4, #0x00	; 180
      00B8A0 6F 00                 1061 	.byte #0x6f, #0x00	; 111
      00B8A2 70 00                 1062 	.byte #0x70, #0x00	; 112
      00B8A4 9F 01                 1063 	.byte #0x9f, #0x01	; 415
      00B8A6 CB 01                 1064 	.byte #0xcb, #0x01	; 459
      00B8A8 9F 02                 1065 	.byte #0x9f, #0x02	; 671
      00B8AA A0 02                 1066 	.byte #0xa0, #0x02	; 672
                                   1067 	.area CSEG    (CODE)
                                   1068 	.area XINIT   (CODE)
                                   1069 	.area CABS    (ABS,CODE)
                                   1070 
                                   1071 ; Experimental exact instruction outlining.
                                   1072 	.globl _ak820_outline_0032
                                   1073 	.globl _ak820_outline_0051
                                   1074 	.globl _ak820_outline_0056
                                   1075 	.globl _ak820_outline_0061
                                   1076 	.globl _ak820_outline_0103
                                   1077 	.globl _ak820_outline_0104
                                   1078 	.globl _ak820_outline_0105
                                   1079 	.globl _ak820_outline_0117
                                   1080 	.globl _ak820_outline_0122
                                   1081 	.globl _ak820_outline_0123
                                   1082 	.globl _ak820_outline_0128
                                   1083 	.globl _ak820_outline_0134
                                   1084 	.globl _ak820_outline_0142
                                   1085 	.globl _ak820_outline_0156
                                   1086 	.globl _ak820_outline_0177
                                   1087 	.globl _ak820_outline_0180
                                   1088 	.globl _ak820_outline_0183
                                   1089 	.globl _ak820_outline_0184
                                   1090 
                                   1091 	.area CSEG (CODE)
                                   1092 ; function ak820_outline_0032
      0070C6                       1093 _ak820_outline_0032:
      0070C6 74 02            [12] 1094 	mov	a,#0x02
      0070C8 2E               [12] 1095 	add	a,r6
      0070C9 FE               [12] 1096 	mov	r6,a
      0070CA E4               [12] 1097 	clr	a
      0070CB 3F               [12] 1098 	addc	a,r7
      0070CC FF               [12] 1099 	mov	r7,a
      0070CD EC               [12] 1100 	mov	a,r4
      0070CE 2E               [12] 1101 	add	a,r6
      0070CF FC               [12] 1102 	mov	r4,a
      0070D0 E4               [12] 1103 	clr	a
      0070D1 3F               [12] 1104 	addc	a,r7
      0070D2 FB               [12] 1105 	mov	r3,a
      0070D3 74 07            [12] 1106 	mov	a,#0x07
      0070D5 5D               [12] 1107 	anl	a,r5
      0070D6 F5 F0            [12] 1108 	mov	b,a
      0070D8 05 F0            [12] 1109 	inc	b
      0070DA 74 01            [12] 1110 	mov	a,#0x01
      0070DC 22               [24] 1111 	ret
                                   1112 
                                   1113 	.area CSEG (CODE)
                                   1114 ; function ak820_outline_0128
      0070DD                       1115 _ak820_outline_0128:
      0070DD F4               [12] 1116 	cpl	a
      0070DE 24 01            [12] 1117 	add	a,#0x01
      0070E0 C5 F0            [12] 1118 	xch	a,b
      0070E2 F4               [12] 1119 	cpl	a
      0070E3 34 00            [12] 1120 	addc	a,#0x00
      0070E5 C5 F0            [12] 1121 	xch	a,b
      0070E7 22               [24] 1122 	ret
                                   1123 
                                   1124 	.area CSEG (CODE)
                                   1125 ; function ak820_outline_0142
      0070E8                       1126 _ak820_outline_0142:
      0070E8 74 02            [12] 1127 	mov	a,#0x02
      0070EA 2E               [12] 1128 	add	a,r6
      0070EB FB               [12] 1129 	mov	r3,a
      0070EC E4               [12] 1130 	clr	a
      0070ED 3F               [12] 1131 	addc	a,r7
      0070EE FC               [12] 1132 	mov	r4,a
      0070EF ED               [12] 1133 	mov	a,r5
      0070F0 2B               [12] 1134 	add	a,r3
      0070F1 22               [24] 1135 	ret
                                   1136 
                                   1137 	.area CSEG (CODE)
                                   1138 ; function ak820_outline_0177
      0070F2                       1139 _ak820_outline_0177:
      0070F2 90 0D 81         [24] 1140 	mov	dptr,#_memset_PARM_2
      0070F5 E4               [12] 1141 	clr	a
      0070F6 F0               [24] 1142 	movx	@dptr,a
      0070F7 90 0D 82         [24] 1143 	mov	dptr,#_memset_PARM_3
      0070FA 22               [24] 1144 	ret
