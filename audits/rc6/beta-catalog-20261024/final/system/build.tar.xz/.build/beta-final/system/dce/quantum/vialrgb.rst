                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module vialrgb
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _rgb_matrix_get_speed
                                     12 	.globl _rgb_matrix_set_speed_noeeprom
                                     13 	.globl _rgb_matrix_get_val
                                     14 	.globl _rgb_matrix_get_sat
                                     15 	.globl _rgb_matrix_get_hue
                                     16 	.globl _rgb_matrix_sethsv_noeeprom
                                     17 	.globl _rgb_matrix_get_mode
                                     18 	.globl _rgb_matrix_mode_noeeprom
                                     19 	.globl _rgb_matrix_is_enabled
                                     20 	.globl _rgb_matrix_disable_noeeprom
                                     21 	.globl _rgb_matrix_enable_noeeprom
                                     22 	.globl _eeconfig_update_rgb_matrix
                                     23 	.globl _ADC_START
                                     24 	.globl _S0_R_FIFO
                                     25 	.globl _S0_T_FIFO
                                     26 	.globl _S0_FREE
                                     27 	.globl _S0_IF_BYTE
                                     28 	.globl _S0_IF_FIRST
                                     29 	.globl _S0_IF_OV
                                     30 	.globl _S0_FST_ACT
                                     31 	.globl _CP_RL2
                                     32 	.globl _C_T2
                                     33 	.globl _TR2
                                     34 	.globl _EXEN2
                                     35 	.globl _TCLK
                                     36 	.globl _RCLK
                                     37 	.globl _EXF2
                                     38 	.globl _CAP1F
                                     39 	.globl _TF2
                                     40 	.globl _RI
                                     41 	.globl _TI
                                     42 	.globl _RB8
                                     43 	.globl _TB8
                                     44 	.globl _REN
                                     45 	.globl _SM2
                                     46 	.globl _SM1
                                     47 	.globl _SM0
                                     48 	.globl _IT0
                                     49 	.globl _IE0
                                     50 	.globl _IT1
                                     51 	.globl _IE1
                                     52 	.globl _TR0
                                     53 	.globl _TF0
                                     54 	.globl _TR1
                                     55 	.globl _TF1
                                     56 	.globl _P4_0
                                     57 	.globl _P4_1
                                     58 	.globl _P4_2
                                     59 	.globl _P4_3
                                     60 	.globl _P4_4
                                     61 	.globl _P4_5
                                     62 	.globl _P4_6
                                     63 	.globl _RXD
                                     64 	.globl _TXD
                                     65 	.globl _INT0
                                     66 	.globl _INT1
                                     67 	.globl _T0
                                     68 	.globl _T1
                                     69 	.globl _MOSI1
                                     70 	.globl _MISO1
                                     71 	.globl _SCK1
                                     72 	.globl _P3_0
                                     73 	.globl _P3_1
                                     74 	.globl _P3_2
                                     75 	.globl _P3_3
                                     76 	.globl _P3_4
                                     77 	.globl _P3_5
                                     78 	.globl _P3_6
                                     79 	.globl _P3_7
                                     80 	.globl _CAP1_
                                     81 	.globl _T2_
                                     82 	.globl _CAP2_
                                     83 	.globl _T2EX_
                                     84 	.globl _RXD1
                                     85 	.globl _TXD1
                                     86 	.globl _P2_0
                                     87 	.globl _P2_1
                                     88 	.globl _P2_2
                                     89 	.globl _P2_3
                                     90 	.globl _P2_4
                                     91 	.globl _P2_5
                                     92 	.globl _P2_6
                                     93 	.globl _P2_7
                                     94 	.globl _AIN0
                                     95 	.globl _AIN1
                                     96 	.globl _AIN2
                                     97 	.globl _AIN3
                                     98 	.globl _AIN4
                                     99 	.globl _AIN5
                                    100 	.globl _AIN6
                                    101 	.globl _AIN7
                                    102 	.globl _CAP1
                                    103 	.globl _T2
                                    104 	.globl _CAP2
                                    105 	.globl _T2EX
                                    106 	.globl _INT0_
                                    107 	.globl _SCS
                                    108 	.globl _MOSI
                                    109 	.globl _MISO
                                    110 	.globl _SCK
                                    111 	.globl _RXD1_
                                    112 	.globl _TXD1_
                                    113 	.globl _P1_0
                                    114 	.globl _P1_1
                                    115 	.globl _P1_2
                                    116 	.globl _P1_3
                                    117 	.globl _P1_4
                                    118 	.globl _P1_5
                                    119 	.globl _P1_6
                                    120 	.globl _P1_7
                                    121 	.globl _AIN8
                                    122 	.globl _AIN9
                                    123 	.globl _AIN10
                                    124 	.globl _AIN11
                                    125 	.globl _AIN12
                                    126 	.globl _AIN13
                                    127 	.globl _RXD_
                                    128 	.globl _TXD_
                                    129 	.globl _SCL0
                                    130 	.globl _SDA0
                                    131 	.globl _P0_0
                                    132 	.globl _P0_1
                                    133 	.globl _P0_2
                                    134 	.globl _P0_3
                                    135 	.globl _P0_4
                                    136 	.globl _P0_5
                                    137 	.globl _P0_6
                                    138 	.globl _P0_7
                                    139 	.globl _IE_SPI0
                                    140 	.globl _IE_USB
                                    141 	.globl _IE_ADC
                                    142 	.globl _IE_UART1
                                    143 	.globl _IE_PWM_I2C
                                    144 	.globl _IE_GPIO
                                    145 	.globl _IE_WDOG
                                    146 	.globl _PX0
                                    147 	.globl _PT0
                                    148 	.globl _PX1
                                    149 	.globl _PT1
                                    150 	.globl _PS
                                    151 	.globl _PT2
                                    152 	.globl _PL_FLAG
                                    153 	.globl _PH_FLAG
                                    154 	.globl _EX0
                                    155 	.globl _ET0
                                    156 	.globl _EX1
                                    157 	.globl _ET1
                                    158 	.globl _ES
                                    159 	.globl _ET2
                                    160 	.globl _E_DIS
                                    161 	.globl _EA
                                    162 	.globl _P
                                    163 	.globl _F1
                                    164 	.globl _OV
                                    165 	.globl _RS0
                                    166 	.globl _RS1
                                    167 	.globl _F0
                                    168 	.globl _AC
                                    169 	.globl _CY
                                    170 	.globl _I2CS_INT_ST
                                    171 	.globl _I2CX_INT
                                    172 	.globl _LED_STATUS
                                    173 	.globl _LED_DMA_H
                                    174 	.globl _LED_DMA_L
                                    175 	.globl _LED_DMA
                                    176 	.globl _LED_PWM_OE
                                    177 	.globl _LED_COMMON
                                    178 	.globl _ADC_CHAN
                                    179 	.globl _ADC_DAT_H
                                    180 	.globl _ADC_DAT_L
                                    181 	.globl _ADC_DAT
                                    182 	.globl _ADC_CTRL
                                    183 	.globl _SPI1_CK_SE
                                    184 	.globl _SPI1_CTRL
                                    185 	.globl _SPI1_DATA
                                    186 	.globl _SPI1_STAT
                                    187 	.globl _SIF1
                                    188 	.globl _SBAUD1
                                    189 	.globl _SBUF1
                                    190 	.globl _SCON1
                                    191 	.globl _SPI0_SETUP
                                    192 	.globl _SPI0_CK_SE
                                    193 	.globl _SPI0_CTRL
                                    194 	.globl _SPI0_DATA
                                    195 	.globl _SPI0_STAT
                                    196 	.globl _T2CAP1H
                                    197 	.globl _T2CAP1L
                                    198 	.globl _T2CAP1
                                    199 	.globl _TH2
                                    200 	.globl _TL2
                                    201 	.globl _T2COUNT
                                    202 	.globl _RCAP2H
                                    203 	.globl _RCAP2L
                                    204 	.globl _RCAP2
                                    205 	.globl _T2MOD
                                    206 	.globl _T2CON
                                    207 	.globl _SBUF
                                    208 	.globl _SCON
                                    209 	.globl _TH1
                                    210 	.globl _TH0
                                    211 	.globl _TL1
                                    212 	.globl _TL0
                                    213 	.globl _TMOD
                                    214 	.globl _TCON
                                    215 	.globl _XBUS_AUX
                                    216 	.globl _P7
                                    217 	.globl _P6_DIR
                                    218 	.globl _P6_OUT_PU
                                    219 	.globl _P6_IN
                                    220 	.globl _P5_DIR
                                    221 	.globl _P5_OUT_PU
                                    222 	.globl _P5_IN
                                    223 	.globl _P4_LED_KEY
                                    224 	.globl _P4_DIR_PU
                                    225 	.globl _P4_MOD_OC
                                    226 	.globl _P4
                                    227 	.globl _P3_DIR_PU
                                    228 	.globl _P3_MOD_OC
                                    229 	.globl _P3
                                    230 	.globl _P2_DIR_PU
                                    231 	.globl _P2_MOD_OC
                                    232 	.globl _P2
                                    233 	.globl _P1_DIR_PU
                                    234 	.globl _P1_MOD_OC
                                    235 	.globl _P1
                                    236 	.globl _P0_DIR_PU
                                    237 	.globl _P0_MOD_OC
                                    238 	.globl _P0
                                    239 	.globl _ROM_CTRL
                                    240 	.globl _ROM_DATA_HH
                                    241 	.globl _ROM_DATA_HL
                                    242 	.globl _ROM_DATA_HI
                                    243 	.globl _ROM_ADDR_H
                                    244 	.globl _ROM_ADDR_L
                                    245 	.globl _ROM_ADDR
                                    246 	.globl _GPIO_IE
                                    247 	.globl _IP_EX
                                    248 	.globl _IE_EX
                                    249 	.globl _IP
                                    250 	.globl _IE
                                    251 	.globl _WDOG_COUNT
                                    252 	.globl _RESET_KEEP
                                    253 	.globl _WAKE_CTRL
                                    254 	.globl _CLOCK_CFG
                                    255 	.globl _POWER_CFG
                                    256 	.globl _PCON
                                    257 	.globl _GLOBAL_CFG
                                    258 	.globl _SAFE_MOD
                                    259 	.globl _DPH
                                    260 	.globl _DPL
                                    261 	.globl _SP
                                    262 	.globl _A_INV
                                    263 	.globl _B
                                    264 	.globl _ACC
                                    265 	.globl _PSW
                                    266 	.globl _vialrgb_save_PARM_2
                                    267 	.globl _vialrgb_set_value_PARM_2
                                    268 	.globl _vialrgb_get_value_PARM_2
                                    269 	.globl _g_direct_mode_colors
                                    270 	.globl _vialrgb_get_value
                                    271 	.globl _vialrgb_set_value
                                    272 	.globl _vialrgb_save
                                    273 ;--------------------------------------------------------
                                    274 ; special function registers
                                    275 ;--------------------------------------------------------
                                    276 	.area RSEG    (ABS,DATA)
      000000                        277 	.org 0x0000
                           0000D0   278 _PSW	=	0x00d0
                           0000E0   279 _ACC	=	0x00e0
                           0000F0   280 _B	=	0x00f0
                           0000FD   281 _A_INV	=	0x00fd
                           000081   282 _SP	=	0x0081
                           000082   283 _DPL	=	0x0082
                           000083   284 _DPH	=	0x0083
                           0000A1   285 _SAFE_MOD	=	0x00a1
                           0000B1   286 _GLOBAL_CFG	=	0x00b1
                           000087   287 _PCON	=	0x0087
                           0000BA   288 _POWER_CFG	=	0x00ba
                           0000B9   289 _CLOCK_CFG	=	0x00b9
                           0000A9   290 _WAKE_CTRL	=	0x00a9
                           0000FE   291 _RESET_KEEP	=	0x00fe
                           0000FF   292 _WDOG_COUNT	=	0x00ff
                           0000A8   293 _IE	=	0x00a8
                           0000B8   294 _IP	=	0x00b8
                           0000E8   295 _IE_EX	=	0x00e8
                           0000E9   296 _IP_EX	=	0x00e9
                           0000B2   297 _GPIO_IE	=	0x00b2
                           008584   298 _ROM_ADDR	=	0x8584
                           000084   299 _ROM_ADDR_L	=	0x0084
                           000085   300 _ROM_ADDR_H	=	0x0085
                           008F8E   301 _ROM_DATA_HI	=	0x8f8e
                           00008E   302 _ROM_DATA_HL	=	0x008e
                           00008F   303 _ROM_DATA_HH	=	0x008f
                           000086   304 _ROM_CTRL	=	0x0086
                           000080   305 _P0	=	0x0080
                           0000C4   306 _P0_MOD_OC	=	0x00c4
                           0000C5   307 _P0_DIR_PU	=	0x00c5
                           000090   308 _P1	=	0x0090
                           000092   309 _P1_MOD_OC	=	0x0092
                           000093   310 _P1_DIR_PU	=	0x0093
                           0000A0   311 _P2	=	0x00a0
                           000094   312 _P2_MOD_OC	=	0x0094
                           000095   313 _P2_DIR_PU	=	0x0095
                           0000B0   314 _P3	=	0x00b0
                           000096   315 _P3_MOD_OC	=	0x0096
                           000097   316 _P3_DIR_PU	=	0x0097
                           0000C0   317 _P4	=	0x00c0
                           0000C2   318 _P4_MOD_OC	=	0x00c2
                           0000C3   319 _P4_DIR_PU	=	0x00c3
                           0000C1   320 _P4_LED_KEY	=	0x00c1
                           0000AA   321 _P5_IN	=	0x00aa
                           0000AB   322 _P5_OUT_PU	=	0x00ab
                           0000AC   323 _P5_DIR	=	0x00ac
                           0000AD   324 _P6_IN	=	0x00ad
                           0000AE   325 _P6_OUT_PU	=	0x00ae
                           0000AF   326 _P6_DIR	=	0x00af
                           0000F1   327 _P7	=	0x00f1
                           0000A2   328 _XBUS_AUX	=	0x00a2
                           000088   329 _TCON	=	0x0088
                           000089   330 _TMOD	=	0x0089
                           00008A   331 _TL0	=	0x008a
                           00008B   332 _TL1	=	0x008b
                           00008C   333 _TH0	=	0x008c
                           00008D   334 _TH1	=	0x008d
                           000098   335 _SCON	=	0x0098
                           000099   336 _SBUF	=	0x0099
                           0000C8   337 _T2CON	=	0x00c8
                           0000C9   338 _T2MOD	=	0x00c9
                           00CBCA   339 _RCAP2	=	0xcbca
                           0000CA   340 _RCAP2L	=	0x00ca
                           0000CB   341 _RCAP2H	=	0x00cb
                           00CDCC   342 _T2COUNT	=	0xcdcc
                           0000CC   343 _TL2	=	0x00cc
                           0000CD   344 _TH2	=	0x00cd
                           00CFCE   345 _T2CAP1	=	0xcfce
                           0000CE   346 _T2CAP1L	=	0x00ce
                           0000CF   347 _T2CAP1H	=	0x00cf
                           0000F8   348 _SPI0_STAT	=	0x00f8
                           0000F9   349 _SPI0_DATA	=	0x00f9
                           0000FA   350 _SPI0_CTRL	=	0x00fa
                           0000FB   351 _SPI0_CK_SE	=	0x00fb
                           0000FC   352 _SPI0_SETUP	=	0x00fc
                           0000BC   353 _SCON1	=	0x00bc
                           0000BD   354 _SBUF1	=	0x00bd
                           0000BE   355 _SBAUD1	=	0x00be
                           0000BF   356 _SIF1	=	0x00bf
                           0000B4   357 _SPI1_STAT	=	0x00b4
                           0000B5   358 _SPI1_DATA	=	0x00b5
                           0000B6   359 _SPI1_CTRL	=	0x00b6
                           0000B7   360 _SPI1_CK_SE	=	0x00b7
                           0000F3   361 _ADC_CTRL	=	0x00f3
                           00F5F4   362 _ADC_DAT	=	0xf5f4
                           0000F4   363 _ADC_DAT_L	=	0x00f4
                           0000F5   364 _ADC_DAT_H	=	0x00f5
                           0000F6   365 _ADC_CHAN	=	0x00f6
                           0000A6   366 _LED_COMMON	=	0x00a6
                           0000A7   367 _LED_PWM_OE	=	0x00a7
                           00C7C6   368 _LED_DMA	=	0xc7c6
                           0000C6   369 _LED_DMA_L	=	0x00c6
                           0000C7   370 _LED_DMA_H	=	0x00c7
                           0000F7   371 _LED_STATUS	=	0x00f7
                           0000B3   372 _I2CX_INT	=	0x00b3
                           0000BB   373 _I2CS_INT_ST	=	0x00bb
                                    374 ;--------------------------------------------------------
                                    375 ; special function bits
                                    376 ;--------------------------------------------------------
                                    377 	.area RSEG    (ABS,DATA)
      000000                        378 	.org 0x0000
                           0000D7   379 _CY	=	0x00d7
                           0000D6   380 _AC	=	0x00d6
                           0000D5   381 _F0	=	0x00d5
                           0000D4   382 _RS1	=	0x00d4
                           0000D3   383 _RS0	=	0x00d3
                           0000D2   384 _OV	=	0x00d2
                           0000D1   385 _F1	=	0x00d1
                           0000D0   386 _P	=	0x00d0
                           0000AF   387 _EA	=	0x00af
                           0000AE   388 _E_DIS	=	0x00ae
                           0000AD   389 _ET2	=	0x00ad
                           0000AC   390 _ES	=	0x00ac
                           0000AB   391 _ET1	=	0x00ab
                           0000AA   392 _EX1	=	0x00aa
                           0000A9   393 _ET0	=	0x00a9
                           0000A8   394 _EX0	=	0x00a8
                           0000BF   395 _PH_FLAG	=	0x00bf
                           0000BE   396 _PL_FLAG	=	0x00be
                           0000BD   397 _PT2	=	0x00bd
                           0000BC   398 _PS	=	0x00bc
                           0000BB   399 _PT1	=	0x00bb
                           0000BA   400 _PX1	=	0x00ba
                           0000B9   401 _PT0	=	0x00b9
                           0000B8   402 _PX0	=	0x00b8
                           0000EF   403 _IE_WDOG	=	0x00ef
                           0000EE   404 _IE_GPIO	=	0x00ee
                           0000ED   405 _IE_PWM_I2C	=	0x00ed
                           0000EC   406 _IE_UART1	=	0x00ec
                           0000EB   407 _IE_ADC	=	0x00eb
                           0000E9   408 _IE_USB	=	0x00e9
                           0000E8   409 _IE_SPI0	=	0x00e8
                           000087   410 _P0_7	=	0x0087
                           000086   411 _P0_6	=	0x0086
                           000085   412 _P0_5	=	0x0085
                           000084   413 _P0_4	=	0x0084
                           000083   414 _P0_3	=	0x0083
                           000082   415 _P0_2	=	0x0082
                           000081   416 _P0_1	=	0x0081
                           000080   417 _P0_0	=	0x0080
                           000081   418 _SDA0	=	0x0081
                           000080   419 _SCL0	=	0x0080
                           000083   420 _TXD_	=	0x0083
                           000082   421 _RXD_	=	0x0082
                           000085   422 _AIN13	=	0x0085
                           000084   423 _AIN12	=	0x0084
                           000083   424 _AIN11	=	0x0083
                           000082   425 _AIN10	=	0x0082
                           000081   426 _AIN9	=	0x0081
                           000080   427 _AIN8	=	0x0080
                           000097   428 _P1_7	=	0x0097
                           000096   429 _P1_6	=	0x0096
                           000095   430 _P1_5	=	0x0095
                           000094   431 _P1_4	=	0x0094
                           000093   432 _P1_3	=	0x0093
                           000092   433 _P1_2	=	0x0092
                           000091   434 _P1_1	=	0x0091
                           000090   435 _P1_0	=	0x0090
                           000097   436 _TXD1_	=	0x0097
                           000096   437 _RXD1_	=	0x0096
                           000097   438 _SCK	=	0x0097
                           000096   439 _MISO	=	0x0096
                           000095   440 _MOSI	=	0x0095
                           000094   441 _SCS	=	0x0094
                           000092   442 _INT0_	=	0x0092
                           000091   443 _T2EX	=	0x0091
                           000091   444 _CAP2	=	0x0091
                           000090   445 _T2	=	0x0090
                           000090   446 _CAP1	=	0x0090
                           000097   447 _AIN7	=	0x0097
                           000096   448 _AIN6	=	0x0096
                           000095   449 _AIN5	=	0x0095
                           000094   450 _AIN4	=	0x0094
                           000093   451 _AIN3	=	0x0093
                           000092   452 _AIN2	=	0x0092
                           000091   453 _AIN1	=	0x0091
                           000090   454 _AIN0	=	0x0090
                           0000A7   455 _P2_7	=	0x00a7
                           0000A6   456 _P2_6	=	0x00a6
                           0000A5   457 _P2_5	=	0x00a5
                           0000A4   458 _P2_4	=	0x00a4
                           0000A3   459 _P2_3	=	0x00a3
                           0000A2   460 _P2_2	=	0x00a2
                           0000A1   461 _P2_1	=	0x00a1
                           0000A0   462 _P2_0	=	0x00a0
                           0000A7   463 _TXD1	=	0x00a7
                           0000A6   464 _RXD1	=	0x00a6
                           0000A5   465 _T2EX_	=	0x00a5
                           0000A5   466 _CAP2_	=	0x00a5
                           0000A4   467 _T2_	=	0x00a4
                           0000A4   468 _CAP1_	=	0x00a4
                           0000B7   469 _P3_7	=	0x00b7
                           0000B6   470 _P3_6	=	0x00b6
                           0000B5   471 _P3_5	=	0x00b5
                           0000B4   472 _P3_4	=	0x00b4
                           0000B3   473 _P3_3	=	0x00b3
                           0000B2   474 _P3_2	=	0x00b2
                           0000B1   475 _P3_1	=	0x00b1
                           0000B0   476 _P3_0	=	0x00b0
                           0000B7   477 _SCK1	=	0x00b7
                           0000B6   478 _MISO1	=	0x00b6
                           0000B5   479 _MOSI1	=	0x00b5
                           0000B5   480 _T1	=	0x00b5
                           0000B4   481 _T0	=	0x00b4
                           0000B3   482 _INT1	=	0x00b3
                           0000B2   483 _INT0	=	0x00b2
                           0000B1   484 _TXD	=	0x00b1
                           0000B0   485 _RXD	=	0x00b0
                           0000C6   486 _P4_6	=	0x00c6
                           0000C5   487 _P4_5	=	0x00c5
                           0000C4   488 _P4_4	=	0x00c4
                           0000C3   489 _P4_3	=	0x00c3
                           0000C2   490 _P4_2	=	0x00c2
                           0000C1   491 _P4_1	=	0x00c1
                           0000C0   492 _P4_0	=	0x00c0
                           00008F   493 _TF1	=	0x008f
                           00008E   494 _TR1	=	0x008e
                           00008D   495 _TF0	=	0x008d
                           00008C   496 _TR0	=	0x008c
                           00008B   497 _IE1	=	0x008b
                           00008A   498 _IT1	=	0x008a
                           000089   499 _IE0	=	0x0089
                           000088   500 _IT0	=	0x0088
                           00009F   501 _SM0	=	0x009f
                           00009E   502 _SM1	=	0x009e
                           00009D   503 _SM2	=	0x009d
                           00009C   504 _REN	=	0x009c
                           00009B   505 _TB8	=	0x009b
                           00009A   506 _RB8	=	0x009a
                           000099   507 _TI	=	0x0099
                           000098   508 _RI	=	0x0098
                           0000CF   509 _TF2	=	0x00cf
                           0000CF   510 _CAP1F	=	0x00cf
                           0000CE   511 _EXF2	=	0x00ce
                           0000CD   512 _RCLK	=	0x00cd
                           0000CC   513 _TCLK	=	0x00cc
                           0000CB   514 _EXEN2	=	0x00cb
                           0000CA   515 _TR2	=	0x00ca
                           0000C9   516 _C_T2	=	0x00c9
                           0000C8   517 _CP_RL2	=	0x00c8
                           0000FF   518 _S0_FST_ACT	=	0x00ff
                           0000FE   519 _S0_IF_OV	=	0x00fe
                           0000FD   520 _S0_IF_FIRST	=	0x00fd
                           0000FC   521 _S0_IF_BYTE	=	0x00fc
                           0000FB   522 _S0_FREE	=	0x00fb
                           0000FA   523 _S0_T_FIFO	=	0x00fa
                           0000F8   524 _S0_R_FIFO	=	0x00f8
                           0000F7   525 _ADC_START	=	0x00f7
                                    526 ;--------------------------------------------------------
                                    527 ; overlayable register banks
                                    528 ;--------------------------------------------------------
                                    529 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        530 	.ds 8
                                    531 ;--------------------------------------------------------
                                    532 ; internal ram data
                                    533 ;--------------------------------------------------------
                                    534 	.area DSEG    (DATA)
      00004A                        535 _fast_set_leds_sloc0_1_0:
      00004A                        536 	.ds 2
      00004C                        537 _fast_set_leds_sloc1_1_0:
      00004C                        538 	.ds 2
      00004E                        539 _vialrgb_get_value_sloc0_1_0:
      00004E                        540 	.ds 2
      000050                        541 _vialrgb_get_value_sloc1_1_0:
      000050                        542 	.ds 2
      000052                        543 _vialrgb_set_value_sloc0_1_0:
      000052                        544 	.ds 2
                                    545 ;--------------------------------------------------------
                                    546 ; overlayable items in internal ram
                                    547 ;--------------------------------------------------------
                                    548 ;--------------------------------------------------------
                                    549 ; indirectly addressable internal ram data
                                    550 ;--------------------------------------------------------
                                    551 	.area ISEG    (DATA)
                                    552 ;--------------------------------------------------------
                                    553 ; absolute internal ram data
                                    554 ;--------------------------------------------------------
                                    555 	.area IABS    (ABS,DATA)
                                    556 	.area IABS    (ABS,DATA)
                                    557 ;--------------------------------------------------------
                                    558 ; bit data
                                    559 ;--------------------------------------------------------
                                    560 	.area BSEG    (BIT)
                                    561 ;--------------------------------------------------------
                                    562 ; paged external ram data
                                    563 ;--------------------------------------------------------
                                    564 	.area PSEG    (PAG,XDATA)
                                    565 ;--------------------------------------------------------
                                    566 ; uninitialized external ram data
                                    567 ;--------------------------------------------------------
                                    568 	.area XSEG    (XDATA)
      000C68                        569 _g_direct_mode_colors::
      000C68                        570 	.ds 246
      000D5E                        571 _get_supported_PARM_2:
      000D5E                        572 	.ds 1
      000D5F                        573 _get_supported_args_10000_255:
      000D5F                        574 	.ds 2
      000D61                        575 _qmk_id_to_vialrgb_id_id_10000_262:
      000D61                        576 	.ds 2
      000D63                        577 _vialrgb_id_to_qmk_id_id_10000_267:
      000D63                        578 	.ds 2
      000D65                        579 _set_mode_mode_10000_275:
      000D65                        580 	.ds 2
      000D67                        581 _get_matrix_pos_for_led_PARM_2:
      000D67                        582 	.ds 2
      000D69                        583 _get_matrix_pos_for_led_led_10000_280:
      000D69                        584 	.ds 2
      000D6B                        585 _fast_set_leds_PARM_2:
      000D6B                        586 	.ds 1
      000D6C                        587 _fast_set_leds_args_10000_282:
      000D6C                        588 	.ds 2
      000D6E                        589 _fast_set_leds_first_index_10001_285:
      000D6E                        590 	.ds 2
      000D70                        591 _fast_set_leds_num_leds_10001_285:
      000D70                        592 	.ds 1
      000D71                        593 _vialrgb_get_value_PARM_2:
      000D71                        594 	.ds 1
      000D72                        595 _vialrgb_get_value_data_10000_291:
      000D72                        596 	.ds 3
      000D75                        597 _vialrgb_set_value_PARM_2:
      000D75                        598 	.ds 1
      000D76                        599 _vialrgb_set_value_data_10000_302:
      000D76                        600 	.ds 3
      000D79                        601 _vialrgb_save_PARM_2:
      000D79                        602 	.ds 1
                                    603 ;--------------------------------------------------------
                                    604 ; absolute external ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area XABS    (ABS,XDATA)
                                    607 ;--------------------------------------------------------
                                    608 ; initialized external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area XISEG   (XDATA)
                                    611 	.area HOME    (CODE)
                                    612 	.area GSINIT0 (CODE)
                                    613 	.area GSINIT1 (CODE)
                                    614 	.area GSINIT2 (CODE)
                                    615 	.area GSINIT3 (CODE)
                                    616 	.area GSINIT4 (CODE)
                                    617 	.area GSINIT5 (CODE)
                                    618 	.area GSINIT  (CODE)
                                    619 	.area GSFINAL (CODE)
                                    620 	.area CSEG    (CODE)
                                    621 ;--------------------------------------------------------
                                    622 ; global & static initialisations
                                    623 ;--------------------------------------------------------
                                    624 	.area HOME    (CODE)
                                    625 	.area GSINIT  (CODE)
                                    626 	.area GSFINAL (CODE)
                                    627 	.area GSINIT  (CODE)
                                    628 ;--------------------------------------------------------
                                    629 ; Home
                                    630 ;--------------------------------------------------------
                                    631 	.area HOME    (CODE)
                                    632 	.area HOME    (CODE)
                                    633 ;--------------------------------------------------------
                                    634 ; code
                                    635 ;--------------------------------------------------------
                                    636 	.area CSEG    (CODE)
                                    637 ;------------------------------------------------------------
                                    638 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    639 ;------------------------------------------------------------
                                    640 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_167'
                                    641 ;------------------------------------------------------------
                                    642 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    643 ;	-----------------------------------------
                           000007   644 	ar7 = 0x07
                           000006   645 	ar6 = 0x06
                           000005   646 	ar5 = 0x05
                           000004   647 	ar4 = 0x04
                           000003   648 	ar3 = 0x03
                           000002   649 	ar2 = 0x02
                           000001   650 	ar1 = 0x01
                           000000   651 	ar0 = 0x00
                                    652 ;	 function get_supported
                                    653 ;	-----------------------------------------
      00B2FA                        654 _get_supported:
      00B2FA 12 38 40         [24]  655 	lcall	_ak820_outline_0104
      00B2FD 90 0D 5F         [24]  656 	mov	dptr,#_get_supported_args_10000_255
      00B300 12 38 45         [24]  657 	lcall	_ak820_outline_0105
                                    658 ;	quantum/vialrgb.c:44: uint16_t gt = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00B303 90 0D 5F         [24]  659 	mov	dptr,#_get_supported_args_10000_255
      00B306 12 37 97         [24]  660 	lcall	_ak820_outline_0004
      00B309 E0               [24]  661 	movx	a,@dptr
      00B30A FD               [12]  662 	mov	r5,a
      00B30B 7C 00            [12]  663 	mov	r4,#0x00
      00B30D 12 38 4A         [24]  664 	lcall	_ak820_outline_0109
      00B310 FA               [12]  665 	mov	r2,a
      00B311 E4               [12]  666 	clr	a
      00B312 12 43 9A         [24]  667 	lcall	_ak820_outline_0139
                                    668 ;	quantum/vialrgb.c:45: for (uint8_t i = 0; i < length; ++i) args[i] = 0xff;
      00B315 90 0D 5E         [24]  669 	mov	dptr,#_get_supported_PARM_2
      00B318 E0               [24]  670 	movx	a,@dptr
      00B319 FB               [12]  671 	mov	r3,a
      00B31A 7A 00            [12]  672 	mov	r2,#0x00
      00B31C                        673 00107$:
      00B31C C3               [12]  674 	clr	c
      00B31D EA               [12]  675 	mov	a,r2
      00B31E 9B               [12]  676 	subb	a,r3
      00B31F 50 0A            [24]  677 	jnc	00101$
      00B321 EA               [12]  678 	mov	a,r2
      00B322 12 37 E7         [24]  679 	lcall	_ak820_outline_0031
      00B325 74 FF            [12]  680 	mov	a,#0xff
      00B327 F0               [24]  681 	movx	@dptr,a
      00B328 0A               [12]  682 	inc	r2
      00B329 80 F1            [24]  683 	sjmp	00107$
      00B32B                        684 00101$:
                                    685 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B32B 8D 06            [24]  686 	mov	ar6,r5
      00B32D 8C 07            [24]  687 	mov	ar7,r4
      00B32F 8B 05            [24]  688 	mov	ar5,r3
      00B331 90 0D 5F         [24]  689 	mov	dptr,#_get_supported_args_10000_255
      00B334 12 38 3A         [24]  690 	lcall	_ak820_outline_0101
      00B337 7A 00            [12]  691 	mov	r2,#0x00
      00B339                        692 00110$:
      00B339 BA 07 00         [24]  693 	cjne	r2,#0x07,00159$
      00B33C                        694 00159$:
      00B33C 50 46            [24]  695 	jnc	00127$
                                    696 ;	quantum/vialrgb.c:47: uint16_t id = READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00B33E EA               [12]  697 	mov	a,r2
      00B33F 75 F0 02         [24]  698 	mov	b,#0x02
      00B342 A4               [48]  699 	mul	ab
      00B343 24 99            [12]  700 	add	a, #_supported_modes
      00B345 F5 82            [12]  701 	mov	dpl,a
      00B347 74 BF            [12]  702 	mov	a,#(_supported_modes >> 8)
      00B349 12 57 E1         [24]  703 	lcall	_ak820_outline_0106
      00B34C F8               [12]  704 	mov	r0,a
      00B34D 79 00            [12]  705 	mov	r1,#0x00
                                    706 ;	quantum/vialrgb.c:48: if (id > gt && length >= sizeof(id)) {
      00B34F C3               [12]  707 	clr	c
      00B350 EE               [12]  708 	mov	a,r6
      00B351 98               [12]  709 	subb	a,r0
      00B352 EF               [12]  710 	mov	a,r7
      00B353 99               [12]  711 	subb	a,r1
      00B354 50 2B            [24]  712 	jnc	00111$
                                    713 ;	free result
      00B356 BD 02 00         [24]  714 	cjne	r5,#0x02,00162$
      00B359                        715 00162$:
      00B359 40 26            [24]  716 	jc	00111$
                                    717 ;	quantum/vialrgb.c:49: args[0] = id;
      00B35B C0 06            [24]  718 	push	ar6
      00B35D C0 07            [24]  719 	push	ar7
      00B35F 88 07            [24]  720 	mov	ar7,r0
      00B361 12 33 FC         [24]  721 	lcall	_ak820_outline_0122
      00B364 EF               [12]  722 	mov	a,r7
      00B365 F0               [24]  723 	movx	@dptr,a
                                    724 ;	quantum/vialrgb.c:50: args[1] = id >> 8;
      00B366 12 33 FC         [24]  725 	lcall	_ak820_outline_0122
      00B369 A3               [24]  726 	inc	dptr
      00B36A 89 00            [24]  727 	mov	ar0,r1
      00B36C E8               [12]  728 	mov	a,r0
      00B36D F0               [24]  729 	movx	@dptr,a
                                    730 ;	quantum/vialrgb.c:51: length -= sizeof(id);
      00B36E 1D               [12]  731 	dec	r5
      00B36F 1D               [12]  732 	dec	r5
                                    733 ;	quantum/vialrgb.c:52: args += sizeof(id);
      00B370 74 02            [12]  734 	mov	a,#0x02
      00B372 2B               [12]  735 	add	a, r3
      00B373 FB               [12]  736 	mov	r3,a
      00B374 E4               [12]  737 	clr	a
      00B375 3C               [12]  738 	addc	a, r4
      00B376 FC               [12]  739 	mov	r4,a
      00B377 90 0D 5F         [24]  740 	mov	dptr,#_get_supported_args_10000_255
      00B37A 12 38 22         [24]  741 	lcall	_ak820_outline_0076
                                    742 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B37D D0 07            [24]  743 	pop	ar7
      00B37F D0 06            [24]  744 	pop	ar6
                                    745 ;	quantum/vialrgb.c:52: args += sizeof(id);
      00B381                        746 00111$:
                                    747 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B381 0A               [12]  748 	inc	r2
      00B382 80 B5            [24]  749 	sjmp	00110$
      00B384                        750 00127$:
      00B384 90 0D 5F         [24]  751 	mov	dptr,#_get_supported_args_10000_255
      00B387 12 38 22         [24]  752 	lcall	_ak820_outline_0076
                                    753 ;	quantum/vialrgb.c:55: }
      00B38A 22               [24]  754 	ret
                                    755 ;------------------------------------------------------------
                                    756 ;Allocation info for local variables in function 'qmk_id_to_vialrgb_id'
                                    757 ;------------------------------------------------------------
                                    758 ;id            Allocated with name '_qmk_id_to_vialrgb_id_id_10000_262'
                                    759 ;i             Allocated with name '_qmk_id_to_vialrgb_id_i_20000_264'
                                    760 ;qmk_id        Allocated with name '_qmk_id_to_vialrgb_id_qmk_id_30000_265'
                                    761 ;------------------------------------------------------------
                                    762 ;	quantum/vialrgb.c:57: static uint16_t qmk_id_to_vialrgb_id(uint16_t id) {
                                    763 ;	-----------------------------------------
                                    764 ;	 function qmk_id_to_vialrgb_id
                                    765 ;	-----------------------------------------
      00B38B                        766 _qmk_id_to_vialrgb_id:
      00B38B 12 38 40         [24]  767 	lcall	_ak820_outline_0104
      00B38E 90 0D 61         [24]  768 	mov	dptr,#_qmk_id_to_vialrgb_id_id_10000_262
      00B391 12 38 45         [24]  769 	lcall	_ak820_outline_0105
                                    770 ;	quantum/vialrgb.c:58: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B394 90 0D 61         [24]  771 	mov	dptr,#_qmk_id_to_vialrgb_id_id_10000_262
      00B397 12 37 F7         [24]  772 	lcall	_ak820_outline_0051
      00B39A 7D 00            [12]  773 	mov	r5,#0x00
      00B39C                        774 00105$:
      00B39C BD 07 00         [24]  775 	cjne	r5,#0x07,00130$
      00B39F                        776 00130$:
      00B39F 50 19            [24]  777 	jnc	00103$
                                    778 ;	quantum/vialrgb.c:59: uint16_t qmk_id = READ_MODE_ID(&supported_modes[i].qmk_id);
      00B3A1 12 B7 B8         [24]  779 	lcall	_ak820_outline_0045
      00B3A4 A3               [24]  780 	inc	dptr
      00B3A5 E4               [12]  781 	clr	a
      00B3A6 93               [24]  782 	movc	a,@a+dptr
                                    783 ;	quantum/vialrgb.c:60: if (qmk_id == id)
      00B3A7 7A 00            [12]  784 	mov	r2,#0x00
      00B3A9 B5 06 0B         [24]  785 	cjne	a,ar6,00106$
      00B3AC EA               [12]  786 	mov	a,r2
      00B3AD B5 07 07         [24]  787 	cjne	a,ar7,00106$
                                    788 ;	quantum/vialrgb.c:61: return READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00B3B0 12 33 FC         [24]  789 	lcall	_ak820_outline_0122
      00B3B3 12 B7 E4         [24]  790 	lcall	_ak820_outline_0141
      00B3B6 22               [24]  791 	ret
      00B3B7                        792 00106$:
                                    793 ;	quantum/vialrgb.c:58: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B3B7 0D               [12]  794 	inc	r5
      00B3B8 80 E2            [24]  795 	sjmp	00105$
      00B3BA                        796 00103$:
                                    797 ;	quantum/vialrgb.c:63: return 0;
      00B3BA 90 00 00         [24]  798 	mov	dptr,#0x0000
                                    799 ;	quantum/vialrgb.c:64: }
      00B3BD 22               [24]  800 	ret
                                    801 ;------------------------------------------------------------
                                    802 ;Allocation info for local variables in function 'vialrgb_id_to_qmk_id'
                                    803 ;------------------------------------------------------------
                                    804 ;id            Allocated with name '_vialrgb_id_to_qmk_id_id_10000_267'
                                    805 ;i             Allocated with name '_vialrgb_id_to_qmk_id_i_20000_269'
                                    806 ;vialrgb_id    Allocated with name '_vialrgb_id_to_qmk_id_vialrgb_id_30000_270'
                                    807 ;------------------------------------------------------------
                                    808 ;	quantum/vialrgb.c:66: static uint16_t vialrgb_id_to_qmk_id(uint16_t id) {
                                    809 ;	-----------------------------------------
                                    810 ;	 function vialrgb_id_to_qmk_id
                                    811 ;	-----------------------------------------
      00B3BE                        812 _vialrgb_id_to_qmk_id:
      00B3BE 12 38 40         [24]  813 	lcall	_ak820_outline_0104
      00B3C1 90 0D 63         [24]  814 	mov	dptr,#_vialrgb_id_to_qmk_id_id_10000_267
      00B3C4 12 38 45         [24]  815 	lcall	_ak820_outline_0105
                                    816 ;	quantum/vialrgb.c:67: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B3C7 90 0D 63         [24]  817 	mov	dptr,#_vialrgb_id_to_qmk_id_id_10000_267
      00B3CA 12 37 F7         [24]  818 	lcall	_ak820_outline_0051
      00B3CD 7D 00            [12]  819 	mov	r5,#0x00
      00B3CF                        820 00105$:
      00B3CF BD 07 00         [24]  821 	cjne	r5,#0x07,00130$
      00B3D2                        822 00130$:
      00B3D2 50 19            [24]  823 	jnc	00103$
                                    824 ;	quantum/vialrgb.c:68: uint16_t vialrgb_id = READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00B3D4 12 B7 B8         [24]  825 	lcall	_ak820_outline_0045
      00B3D7 E4               [12]  826 	clr	a
      00B3D8 93               [24]  827 	movc	a,@a+dptr
                                    828 ;	quantum/vialrgb.c:69: if (vialrgb_id == id)
      00B3D9 7A 00            [12]  829 	mov	r2,#0x00
      00B3DB B5 06 0C         [24]  830 	cjne	a,ar6,00106$
      00B3DE EA               [12]  831 	mov	a,r2
      00B3DF B5 07 08         [24]  832 	cjne	a,ar7,00106$
                                    833 ;	quantum/vialrgb.c:70: return READ_MODE_ID(&supported_modes[i].qmk_id);
      00B3E2 12 33 FC         [24]  834 	lcall	_ak820_outline_0122
      00B3E5 A3               [24]  835 	inc	dptr
      00B3E6 12 B7 E4         [24]  836 	lcall	_ak820_outline_0141
      00B3E9 22               [24]  837 	ret
      00B3EA                        838 00106$:
                                    839 ;	quantum/vialrgb.c:67: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B3EA 0D               [12]  840 	inc	r5
      00B3EB 80 E2            [24]  841 	sjmp	00105$
      00B3ED                        842 00103$:
                                    843 ;	quantum/vialrgb.c:72: return 0;
      00B3ED 90 00 00         [24]  844 	mov	dptr,#0x0000
                                    845 ;	quantum/vialrgb.c:73: }
      00B3F0 22               [24]  846 	ret
                                    847 ;------------------------------------------------------------
                                    848 ;Allocation info for local variables in function 'get_mode'
                                    849 ;------------------------------------------------------------
                                    850 ;	quantum/vialrgb.c:75: static uint16_t get_mode(void) {
                                    851 ;	-----------------------------------------
                                    852 ;	 function get_mode
                                    853 ;	-----------------------------------------
      00B3F1                        854 _get_mode:
                                    855 ;	quantum/vialrgb.c:77: if (!rgb_matrix_is_enabled())
      00B3F1 12 55 EB         [24]  856 	lcall	_rgb_matrix_is_enabled
      00B3F4 E5 82            [12]  857 	mov	a, dpl
      00B3F6 70 04            [24]  858 	jnz	00102$
                                    859 ;	quantum/vialrgb.c:78: return VIALRGB_EFFECT_OFF;
      00B3F8 90 00 00         [24]  860 	mov	dptr,#0x0000
      00B3FB 22               [24]  861 	ret
      00B3FC                        862 00102$:
                                    863 ;	quantum/vialrgb.c:79: return qmk_id_to_vialrgb_id(rgb_matrix_get_mode());
      00B3FC 12 55 F1         [24]  864 	lcall	_rgb_matrix_get_mode
      00B3FF 7E 00            [12]  865 	mov	r6,#0x00
      00B401 8E 83            [24]  866 	mov	dph, r6
                                    867 ;	quantum/vialrgb.c:80: }
      00B403 61 8B            [12]  868 	ajmp	_qmk_id_to_vialrgb_id
                                    869 ;------------------------------------------------------------
                                    870 ;Allocation info for local variables in function 'set_mode'
                                    871 ;------------------------------------------------------------
                                    872 ;mode          Allocated with name '_set_mode_mode_10000_275'
                                    873 ;------------------------------------------------------------
                                    874 ;	quantum/vialrgb.c:82: static void set_mode(uint16_t mode) {
                                    875 ;	-----------------------------------------
                                    876 ;	 function set_mode
                                    877 ;	-----------------------------------------
      00B405                        878 _set_mode:
      00B405 12 38 40         [24]  879 	lcall	_ak820_outline_0104
      00B408 90 0D 65         [24]  880 	mov	dptr,#_set_mode_mode_10000_275
      00B40B 12 38 45         [24]  881 	lcall	_ak820_outline_0105
                                    882 ;	quantum/vialrgb.c:84: if (mode == VIALRGB_EFFECT_OFF) {
      00B40E 90 0D 65         [24]  883 	mov	dptr,#_set_mode_mode_10000_275
      00B411 12 37 F7         [24]  884 	lcall	_ak820_outline_0051
      00B414 90 0D 65         [24]  885 	mov	dptr,#_set_mode_mode_10000_275
      00B417 12 6F 16         [24]  886 	lcall	_ak820_outline_0036
      00B41A 70 03            [24]  887 	jnz	00102$
                                    888 ;	quantum/vialrgb.c:85: rgb_matrix_disable_noeeprom();
      00B41C 02 56 3C         [24]  889 	ljmp	_rgb_matrix_disable_noeeprom
      00B41F                        890 00102$:
                                    891 ;	quantum/vialrgb.c:87: rgb_matrix_enable_noeeprom();
      00B41F C0 07            [24]  892 	push	ar7
      00B421 C0 06            [24]  893 	push	ar6
      00B423 12 56 2C         [24]  894 	lcall	_rgb_matrix_enable_noeeprom
      00B426 D0 06            [24]  895 	pop	ar6
      00B428 D0 07            [24]  896 	pop	ar7
                                    897 ;	quantum/vialrgb.c:88: rgb_matrix_mode_noeeprom(vialrgb_id_to_qmk_id(mode));
      00B42A 12 43 84         [24]  898 	lcall	_ak820_outline_0117
      00B42D 71 BE            [12]  899 	acall	_vialrgb_id_to_qmk_id
                                    900 ;	quantum/vialrgb.c:90: }
      00B42F 02 56 44         [24]  901 	ljmp	_rgb_matrix_mode_noeeprom
                                    902 ;------------------------------------------------------------
                                    903 ;Allocation info for local variables in function 'get_matrix_pos_for_led'
                                    904 ;------------------------------------------------------------
                                    905 ;output        Allocated with name '_get_matrix_pos_for_led_PARM_2'
                                    906 ;led           Allocated with name '_get_matrix_pos_for_led_led_10000_280'
                                    907 ;slot          Allocated with name '_get_matrix_pos_for_led_slot_10000_281'
                                    908 ;------------------------------------------------------------
                                    909 ;	quantum/vialrgb.c:93: static void get_matrix_pos_for_led(uint16_t led, uint8_t VIALRGB_BUFFER *output) {
                                    910 ;	-----------------------------------------
                                    911 ;	 function get_matrix_pos_for_led
                                    912 ;	-----------------------------------------
      00B432                        913 _get_matrix_pos_for_led:
      00B432 12 38 40         [24]  914 	lcall	_ak820_outline_0104
      00B435 90 0D 69         [24]  915 	mov	dptr,#_get_matrix_pos_for_led_led_10000_280
      00B438 12 38 45         [24]  916 	lcall	_ak820_outline_0105
                                    917 ;	quantum/vialrgb.c:95: uint8_t slot = ak820_rgb_slots[led];
      00B43B 90 0D 69         [24]  918 	mov	dptr,#_get_matrix_pos_for_led_led_10000_280
      00B43E 12 37 F7         [24]  919 	lcall	_ak820_outline_0051
      00B441 EE               [12]  920 	mov	a,r6
      00B442 24 A0            [12]  921 	add	a, #_ak820_rgb_slots
      00B444 F5 82            [12]  922 	mov	dpl,a
      00B446 EF               [12]  923 	mov	a,r7
      00B447 34 B9            [12]  924 	addc	a, #(_ak820_rgb_slots >> 8)
      00B449 F5 83            [12]  925 	mov	dph,a
      00B44B E4               [12]  926 	clr	a
      00B44C 93               [24]  927 	movc	a,@a+dptr
      00B44D FF               [12]  928 	mov	r7,a
                                    929 ;	quantum/vialrgb.c:96: output[0] = slot >> 3;
      00B44E 90 0D 67         [24]  930 	mov	dptr,#_get_matrix_pos_for_led_PARM_2
      00B451 12 43 72         [24]  931 	lcall	_ak820_outline_0097
      00B454 EF               [12]  932 	mov	a,r7
      00B455 12 58 00         [24]  933 	lcall	_ak820_outline_0168
      00B458 12 82 E8         [24]  934 	lcall	_ak820_outline_0119
                                    935 ;	quantum/vialrgb.c:97: output[1] = slot & 7;
      00B45B 12 38 61         [24]  936 	lcall	_ak820_outline_0131
      00B45E A3               [24]  937 	inc	dptr
      00B45F 53 07 07         [24]  938 	anl	ar7,#0x07
      00B462 EF               [12]  939 	mov	a,r7
      00B463 F0               [24]  940 	movx	@dptr,a
                                    941 ;	quantum/vialrgb.c:110: }
      00B464 22               [24]  942 	ret
                                    943 ;------------------------------------------------------------
                                    944 ;Allocation info for local variables in function 'fast_set_leds'
                                    945 ;------------------------------------------------------------
                                    946 ;sloc0         Allocated with name '_fast_set_leds_sloc0_1_0'
                                    947 ;sloc1         Allocated with name '_fast_set_leds_sloc1_1_0'
                                    948 ;length        Allocated with name '_fast_set_leds_PARM_2'
                                    949 ;args          Allocated with name '_fast_set_leds_args_10000_282'
                                    950 ;first_index   Allocated with name '_fast_set_leds_first_index_10001_285'
                                    951 ;num_leds      Allocated with name '_fast_set_leds_num_leds_10001_285'
                                    952 ;i             Allocated with name '_fast_set_leds_i_20001_288'
                                    953 ;color         Allocated with name '_fast_set_leds_color_30001_289'
                                    954 ;val           Allocated with name '_fast_set_leds_val_30002_290'
                                    955 ;------------------------------------------------------------
                                    956 ;	quantum/vialrgb.c:112: static void fast_set_leds(uint8_t VIALRGB_BUFFER *args, uint8_t length) {
                                    957 ;	-----------------------------------------
                                    958 ;	 function fast_set_leds
                                    959 ;	-----------------------------------------
      00B465                        960 _fast_set_leds:
      00B465 12 38 40         [24]  961 	lcall	_ak820_outline_0104
      00B468 90 0D 6C         [24]  962 	mov	dptr,#_fast_set_leds_args_10000_282
      00B46B 12 38 45         [24]  963 	lcall	_ak820_outline_0105
                                    964 ;	quantum/vialrgb.c:115: if (length < 3) return;
      00B46E 90 0D 6B         [24]  965 	mov	dptr,#_fast_set_leds_PARM_2
      00B471 E0               [24]  966 	movx	a,@dptr
      00B472 FF               [12]  967 	mov	r7,a
      00B473 BF 03 00         [24]  968 	cjne	r7,#0x03,00159$
      00B476                        969 00159$:
      00B476 50 01            [24]  970 	jnc	00102$
      00B478 22               [24]  971 	ret
      00B479                        972 00102$:
                                    973 ;	quantum/vialrgb.c:117: uint16_t first_index = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00B479 90 0D 6C         [24]  974 	mov	dptr,#_fast_set_leds_args_10000_282
      00B47C E0               [24]  975 	movx	a,@dptr
      00B47D FD               [12]  976 	mov	r5,a
      00B47E A3               [24]  977 	inc	dptr
      00B47F E0               [24]  978 	movx	a,@dptr
      00B480 12 49 A6         [24]  979 	lcall	_ak820_outline_0057
      00B483 7B 00            [12]  980 	mov	r3,#0x00
      00B485 12 38 61         [24]  981 	lcall	_ak820_outline_0131
      00B488 A3               [24]  982 	inc	dptr
      00B489 E0               [24]  983 	movx	a,@dptr
      00B48A FA               [12]  984 	mov	r2,a
      00B48B 79 00            [12]  985 	mov	r1,#0x00
      00B48D 90 0D 6E         [24]  986 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00B490 E9               [12]  987 	mov	a,r1
      00B491 4C               [12]  988 	orl	a,r4
      00B492 F0               [24]  989 	movx	@dptr,a
      00B493 EA               [12]  990 	mov	a,r2
      00B494 4B               [12]  991 	orl	a,r3
      00B495 A3               [24]  992 	inc	dptr
      00B496 F0               [24]  993 	movx	@dptr,a
                                    994 ;	quantum/vialrgb.c:118: uint8_t num_leds = args[2];
      00B497 12 38 61         [24]  995 	lcall	_ak820_outline_0131
      00B49A A3               [24]  996 	inc	dptr
      00B49B A3               [24]  997 	inc	dptr
      00B49C E0               [24]  998 	movx	a,@dptr
      00B49D 90 0D 70         [24]  999 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B4A0 F0               [24] 1000 	movx	@dptr,a
                                   1001 ;	quantum/vialrgb.c:119: length -= 3;
      00B4A1 EF               [12] 1002 	mov	a,r7
      00B4A2 24 FD            [12] 1003 	add	a,#0xfd
      00B4A4 90 0D 6B         [24] 1004 	mov	dptr,#_fast_set_leds_PARM_2
      00B4A7 F0               [24] 1005 	movx	@dptr,a
                                   1006 ;	quantum/vialrgb.c:120: args += 3;
      00B4A8 90 0D 6C         [24] 1007 	mov	dptr,#_fast_set_leds_args_10000_282
      00B4AB 74 03            [12] 1008 	mov	a,#0x03
      00B4AD 2D               [12] 1009 	add	a, r5
      00B4AE F0               [24] 1010 	movx	@dptr,a
      00B4AF E4               [12] 1011 	clr	a
      00B4B0 3E               [12] 1012 	addc	a, r6
      00B4B1 A3               [24] 1013 	inc	dptr
      00B4B2 F0               [24] 1014 	movx	@dptr,a
                                   1015 ;	quantum/vialrgb.c:123: if ((uint16_t)num_leds * 3u > length || first_index >= RGB_MATRIX_LED_COUNT) return;
      00B4B3 90 0D 70         [24] 1016 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B4B6 E0               [24] 1017 	movx	a,@dptr
      00B4B7 FF               [12] 1018 	mov	r7,a
      00B4B8 75 F0 03         [24] 1019 	mov	b,#0x03
      00B4BB A4               [48] 1020 	mul	ab
      00B4BC FE               [12] 1021 	mov	r6,a
      00B4BD AD F0            [24] 1022 	mov	r5,b
      00B4BF 90 0D 6B         [24] 1023 	mov	dptr,#_fast_set_leds_PARM_2
      00B4C2 E0               [24] 1024 	movx	a,@dptr
      00B4C3 FB               [12] 1025 	mov	r3,a
      00B4C4 7C 00            [12] 1026 	mov	r4,#0x00
      00B4C6 C3               [12] 1027 	clr	c
      00B4C7 EB               [12] 1028 	mov	a,r3
      00B4C8 9E               [12] 1029 	subb	a,r6
      00B4C9 EC               [12] 1030 	mov	a,r4
      00B4CA 9D               [12] 1031 	subb	a,r5
      00B4CB 40 13            [24] 1032 	jc	00103$
                                   1033 ;	free result
      00B4CD 90 0D 6E         [24] 1034 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00B4D0 12 43 72         [24] 1035 	lcall	_ak820_outline_0097
      00B4D3 8D 03            [24] 1036 	mov	ar3,r5
      00B4D5 8E 04            [24] 1037 	mov	ar4,r6
      00B4D7 C3               [12] 1038 	clr	c
      00B4D8 EB               [12] 1039 	mov	a,r3
      00B4D9 94 52            [12] 1040 	subb	a,#0x52
      00B4DB EC               [12] 1041 	mov	a,r4
      00B4DC 94 00            [12] 1042 	subb	a,#0x00
      00B4DE 40 01            [24] 1043 	jc	00104$
      00B4E0                       1044 00103$:
      00B4E0 22               [24] 1045 	ret
      00B4E1                       1046 00104$:
                                   1047 ;	quantum/vialrgb.c:124: if (num_leds > RGB_MATRIX_LED_COUNT - first_index) num_leds = RGB_MATRIX_LED_COUNT - first_index;
      00B4E1 74 52            [12] 1048 	mov	a,#0x52
      00B4E3 C3               [12] 1049 	clr	c
      00B4E4 9D               [12] 1050 	subb	a,r5
      00B4E5 FB               [12] 1051 	mov	r3,a
      00B4E6 E4               [12] 1052 	clr	a
      00B4E7 9E               [12] 1053 	subb	a,r6
      00B4E8 FC               [12] 1054 	mov	r4,a
      00B4E9 7A 00            [12] 1055 	mov	r2,#0x00
      00B4EB C3               [12] 1056 	clr	c
      00B4EC EB               [12] 1057 	mov	a,r3
      00B4ED 9F               [12] 1058 	subb	a,r7
      00B4EE EC               [12] 1059 	mov	a,r4
      00B4EF 9A               [12] 1060 	subb	a,r2
      00B4F0 50 08            [24] 1061 	jnc	00127$
                                   1062 ;	free result
      00B4F2 90 0D 70         [24] 1063 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B4F5 74 52            [12] 1064 	mov	a,#0x52
      00B4F7 C3               [12] 1065 	clr	c
      00B4F8 9D               [12] 1066 	subb	a,r5
      00B4F9 F0               [24] 1067 	movx	@dptr,a
                                   1068 ;	quantum/vialrgb.c:126: for (uint8_t i = 0; i < num_leds; ++i) {
      00B4FA                       1069 00127$:
      00B4FA 90 0D 70         [24] 1070 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B4FD E0               [24] 1071 	movx	a,@dptr
      00B4FE FF               [12] 1072 	mov	r7,a
      00B4FF 90 0D 6E         [24] 1073 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00B502 12 43 72         [24] 1074 	lcall	_ak820_outline_0097
      00B505 7C 00            [12] 1075 	mov	r4,#0x00
      00B507                       1076 00110$:
      00B507 C3               [12] 1077 	clr	c
      00B508 EC               [12] 1078 	mov	a,r4
      00B509 9F               [12] 1079 	subb	a,r7
      00B50A 40 01            [24] 1080 	jc	00164$
      00B50C 22               [24] 1081 	ret
      00B50D                       1082 00164$:
                                   1083 ;	quantum/vialrgb.c:127: HSV VIALRGB_BUFFER *color = &g_direct_mode_colors[first_index++];
      00B50D C0 07            [24] 1084 	push	ar7
      00B50F 90 0D 88         [24] 1085 	mov	dptr,#__mulint_PARM_2
      00B512 12 43 B5         [24] 1086 	lcall	_ak820_outline_0157
      00B515 90 00 03         [24] 1087 	mov	dptr,#0x0003
      00B518 C0 07            [24] 1088 	push	ar7
      00B51A C0 06            [24] 1089 	push	ar6
      00B51C C0 05            [24] 1090 	push	ar5
      00B51E C0 04            [24] 1091 	push	ar4
      00B520 12 B9 50         [24] 1092 	lcall	__mulint
      00B523 AA 82            [24] 1093 	mov	r2, dpl
      00B525 AB 83            [24] 1094 	mov	r3, dph
      00B527 D0 04            [24] 1095 	pop	ar4
      00B529 D0 05            [24] 1096 	pop	ar5
      00B52B D0 06            [24] 1097 	pop	ar6
      00B52D D0 07            [24] 1098 	pop	ar7
      00B52F 0D               [12] 1099 	inc	r5
      00B530 BD 00 01         [24] 1100 	cjne	r5,#0x00,00165$
      00B533 0E               [12] 1101 	inc	r6
      00B534                       1102 00165$:
      00B534 EA               [12] 1103 	mov	a,r2
      00B535 24 68            [12] 1104 	add	a, #_g_direct_mode_colors
      00B537 FA               [12] 1105 	mov	r2,a
      00B538 EB               [12] 1106 	mov	a,r3
      00B539 34 0C            [12] 1107 	addc	a, #(_g_direct_mode_colors >> 8)
      00B53B FB               [12] 1108 	mov	r3,a
                                   1109 ;	quantum/vialrgb.c:128: color->h = *args++;
      00B53C 8A 4A            [24] 1110 	mov	_fast_set_leds_sloc0_1_0,r2
      00B53E 8B 4B            [24] 1111 	mov	(_fast_set_leds_sloc0_1_0 + 1),r3
      00B540 12 B7 CA         [24] 1112 	lcall	_ak820_outline_0081
      00B543 F8               [12] 1113 	mov	r0,a
      00B544 12 B7 D8         [24] 1114 	lcall	_ak820_outline_0103
      00B547 85 4A 82         [24] 1115 	mov	dpl,_fast_set_leds_sloc0_1_0
      00B54A 85 4B 83         [24] 1116 	mov	dph,(_fast_set_leds_sloc0_1_0 + 1)
      00B54D E8               [12] 1117 	mov	a,r0
      00B54E F0               [24] 1118 	movx	@dptr,a
                                   1119 ;	quantum/vialrgb.c:129: color->s = *args++;
      00B54F 74 01            [12] 1120 	mov	a,#0x01
      00B551 2A               [12] 1121 	add	a, r2
      00B552 F5 4A            [12] 1122 	mov	_fast_set_leds_sloc0_1_0,a
      00B554 E4               [12] 1123 	clr	a
      00B555 3B               [12] 1124 	addc	a, r3
      00B556 F5 4B            [12] 1125 	mov	(_fast_set_leds_sloc0_1_0 + 1),a
      00B558 90 0D 6C         [24] 1126 	mov	dptr,#_fast_set_leds_args_10000_282
      00B55B E0               [24] 1127 	movx	a,@dptr
      00B55C F8               [12] 1128 	mov	r0,a
      00B55D A3               [24] 1129 	inc	dptr
      00B55E E0               [24] 1130 	movx	a,@dptr
      00B55F FF               [12] 1131 	mov	r7,a
      00B560 88 82            [24] 1132 	mov	dpl,r0
      00B562 8F 83            [24] 1133 	mov	dph,r7
      00B564 E0               [24] 1134 	movx	a,@dptr
      00B565 F9               [12] 1135 	mov	r1,a
      00B566 90 0D 6C         [24] 1136 	mov	dptr,#_fast_set_leds_args_10000_282
      00B569 74 01            [12] 1137 	mov	a,#0x01
      00B56B 28               [12] 1138 	add	a, r0
      00B56C F0               [24] 1139 	movx	@dptr,a
      00B56D E4               [12] 1140 	clr	a
      00B56E 3F               [12] 1141 	addc	a, r7
      00B56F A3               [24] 1142 	inc	dptr
      00B570 F0               [24] 1143 	movx	@dptr,a
      00B571 85 4A 82         [24] 1144 	mov	dpl,_fast_set_leds_sloc0_1_0
      00B574 85 4B 83         [24] 1145 	mov	dph,(_fast_set_leds_sloc0_1_0 + 1)
      00B577 E9               [12] 1146 	mov	a,r1
      00B578 F0               [24] 1147 	movx	@dptr,a
                                   1148 ;	quantum/vialrgb.c:130: uint8_t val = *args++;
      00B579 12 B7 CA         [24] 1149 	lcall	_ak820_outline_0081
      00B57C F5 4A            [12] 1150 	mov	_fast_set_leds_sloc0_1_0,a
      00B57E 12 B7 D8         [24] 1151 	lcall	_ak820_outline_0103
                                   1152 ;	quantum/vialrgb.c:131: color->v = (val > RGB_MATRIX_MAXIMUM_BRIGHTNESS) ? RGB_MATRIX_MAXIMUM_BRIGHTNESS : val;
      00B581 74 02            [12] 1153 	mov	a,#0x02
      00B583 2A               [12] 1154 	add	a, r2
      00B584 F5 4C            [12] 1155 	mov	_fast_set_leds_sloc1_1_0,a
      00B586 E4               [12] 1156 	clr	a
      00B587 3B               [12] 1157 	addc	a, r3
      00B588 F5 4D            [12] 1158 	mov	(_fast_set_leds_sloc1_1_0 + 1),a
      00B58A C3               [12] 1159 	clr	c
      00B58B 74 A0            [12] 1160 	mov	a,#0xa0
      00B58D 95 4A            [12] 1161 	subb	a,_fast_set_leds_sloc0_1_0
      00B58F D0 07            [24] 1162 	pop	ar7
      00B591 50 04            [24] 1163 	jnc	00114$
                                   1164 ;	free result
      00B593 7B A0            [12] 1165 	mov	r3,#0xa0
      00B595 80 04            [24] 1166 	sjmp	00115$
      00B597                       1167 00114$:
      00B597 AA 4A            [24] 1168 	mov	r2,_fast_set_leds_sloc0_1_0
      00B599 8A 03            [24] 1169 	mov	ar3,r2
      00B59B                       1170 00115$:
      00B59B 85 4C 82         [24] 1171 	mov	dpl,_fast_set_leds_sloc1_1_0
      00B59E 85 4D 83         [24] 1172 	mov	dph,(_fast_set_leds_sloc1_1_0 + 1)
      00B5A1 EB               [12] 1173 	mov	a,r3
      00B5A2 F0               [24] 1174 	movx	@dptr,a
                                   1175 ;	quantum/vialrgb.c:126: for (uint8_t i = 0; i < num_leds; ++i) {
      00B5A3 0C               [12] 1176 	inc	r4
                                   1177 ;	quantum/vialrgb.c:133: }
      00B5A4 A1 07            [24] 1178 	ajmp	00110$
                                   1179 ;------------------------------------------------------------
                                   1180 ;Allocation info for local variables in function 'vialrgb_get_value'
                                   1181 ;------------------------------------------------------------
                                   1182 ;sloc0         Allocated with name '_vialrgb_get_value_sloc0_1_0'
                                   1183 ;sloc1         Allocated with name '_vialrgb_get_value_sloc1_1_0'
                                   1184 ;length        Allocated with name '_vialrgb_get_value_PARM_2'
                                   1185 ;data          Allocated with name '_vialrgb_get_value_data_10000_291'
                                   1186 ;args          Allocated with name '_vialrgb_get_value_args_10001_294'
                                   1187 ;cmd           Allocated with name '_vialrgb_get_value_cmd_10001_294'
                                   1188 ;vialrgb_id    Allocated with name '_vialrgb_get_value_vialrgb_id_40001_297'
                                   1189 ;led           Allocated with name '_vialrgb_get_value_led_40001_300'
                                   1190 ;------------------------------------------------------------
                                   1191 ;	quantum/vialrgb.c:136: void vialrgb_get_value(uint8_t *data, uint8_t length) {
                                   1192 ;	-----------------------------------------
                                   1193 ;	 function vialrgb_get_value
                                   1194 ;	-----------------------------------------
      00B5A6                       1195 _vialrgb_get_value:
      00B5A6 12 43 42         [24] 1196 	lcall	_ak820_outline_0037
      00B5A9 90 0D 72         [24] 1197 	mov	dptr,#_vialrgb_get_value_data_10000_291
      00B5AC 12 37 D6         [24] 1198 	lcall	_ak820_outline_0016
                                   1199 ;	quantum/vialrgb.c:137: if (length != VIAL_RAW_EPSIZE) return;
      00B5AF 90 0D 71         [24] 1200 	mov	dptr,#_vialrgb_get_value_PARM_2
      00B5B2 E0               [24] 1201 	movx	a,@dptr
      00B5B3 FF               [12] 1202 	mov	r7,a
      00B5B4 BF 20 02         [24] 1203 	cjne	r7,#0x20,00162$
      00B5B7 80 01            [24] 1204 	sjmp	00102$
      00B5B9                       1205 00162$:
      00B5B9 22               [24] 1206 	ret
      00B5BA                       1207 00102$:
                                   1208 ;	quantum/vialrgb.c:140: uint8_t VIALRGB_BUFFER *args = (uint8_t VIALRGB_BUFFER *)data + 2;
      00B5BA 90 0D 72         [24] 1209 	mov	dptr,#_vialrgb_get_value_data_10000_291
      00B5BD 12 B7 A4         [24] 1210 	lcall	_ak820_outline_0043
                                   1211 ;	quantum/vialrgb.c:141: uint8_t cmd = args[-1];
                                   1212 ;	quantum/vialrgb.c:142: switch (cmd) {
      00B5C0 BA 40 02         [24] 1213 	cjne	r2,#0x40,00163$
      00B5C3 80 15            [24] 1214 	sjmp	00103$
      00B5C5                       1215 00163$:
      00B5C5 BA 41 02         [24] 1216 	cjne	r2,#0x41,00164$
      00B5C8 80 23            [24] 1217 	sjmp	00104$
      00B5CA                       1218 00164$:
      00B5CA BA 42 02         [24] 1219 	cjne	r2,#0x42,00165$
      00B5CD C1 7E            [12] 1220 	ajmp	00105$
      00B5CF                       1221 00165$:
      00B5CF BA 43 02         [24] 1222 	cjne	r2,#0x43,00166$
      00B5D2 C1 8A            [12] 1223 	ajmp	00106$
      00B5D4                       1224 00166$:
      00B5D4 BA 44 02         [24] 1225 	cjne	r2,#0x44,00167$
      00B5D7 C1 96            [12] 1226 	ajmp	00107$
      00B5D9                       1227 00167$:
      00B5D9 22               [24] 1228 	ret
                                   1229 ;	quantum/vialrgb.c:143: case vialrgb_get_info:
      00B5DA                       1230 00103$:
                                   1231 ;	quantum/vialrgb.c:144: args[0] = VIALRGB_PROTOCOL_VERSION & 0xFF;
      00B5DA 12 33 FC         [24] 1232 	lcall	_ak820_outline_0122
      00B5DD 74 01            [12] 1233 	mov	a,#0x01
      00B5DF F0               [24] 1234 	movx	@dptr,a
                                   1235 ;	quantum/vialrgb.c:145: args[1] = VIALRGB_PROTOCOL_VERSION >> 8;
      00B5E0 12 B7 9C         [24] 1236 	lcall	_ak820_outline_0035
      00B5E3 E4               [12] 1237 	clr	a
      00B5E4 F0               [24] 1238 	movx	@dptr,a
                                   1239 ;	quantum/vialrgb.c:146: args[2] = RGB_MATRIX_MAXIMUM_BRIGHTNESS;
      00B5E5 12 B7 9C         [24] 1240 	lcall	_ak820_outline_0035
      00B5E8 A3               [24] 1241 	inc	dptr
      00B5E9 74 A0            [12] 1242 	mov	a,#0xa0
      00B5EB F0               [24] 1243 	movx	@dptr,a
                                   1244 ;	quantum/vialrgb.c:147: break;
      00B5EC 22               [24] 1245 	ret
                                   1246 ;	quantum/vialrgb.c:148: case vialrgb_get_mode: {
      00B5ED                       1247 00104$:
                                   1248 ;	quantum/vialrgb.c:149: uint16_t vialrgb_id = get_mode();
      00B5ED C0 06            [24] 1249 	push	ar6
      00B5EF C0 05            [24] 1250 	push	ar5
      00B5F1 C0 04            [24] 1251 	push	ar4
      00B5F3 C0 03            [24] 1252 	push	ar3
      00B5F5 71 F1            [12] 1253 	acall	_get_mode
      00B5F7 A9 82            [24] 1254 	mov	r1, dpl
      00B5F9 AA 83            [24] 1255 	mov	r2, dph
      00B5FB D0 03            [24] 1256 	pop	ar3
      00B5FD D0 04            [24] 1257 	pop	ar4
      00B5FF D0 05            [24] 1258 	pop	ar5
      00B601 D0 06            [24] 1259 	pop	ar6
                                   1260 ;	quantum/vialrgb.c:150: args[0] = vialrgb_id & 0xFF;
      00B603 89 00            [24] 1261 	mov	ar0,r1
      00B605 12 33 FC         [24] 1262 	lcall	_ak820_outline_0122
      00B608 E8               [12] 1263 	mov	a,r0
      00B609 F0               [24] 1264 	movx	@dptr,a
                                   1265 ;	quantum/vialrgb.c:151: args[1] = vialrgb_id >> 8;
      00B60A 12 B7 9C         [24] 1266 	lcall	_ak820_outline_0035
      00B60D 8A 01            [24] 1267 	mov	ar1,r2
      00B60F E9               [12] 1268 	mov	a,r1
      00B610 F0               [24] 1269 	movx	@dptr,a
                                   1270 ;	quantum/vialrgb.c:152: args[2] = rgb_matrix_get_speed();
      00B611 74 04            [12] 1271 	mov	a,#0x04
      00B613 12 90 69         [24] 1272 	lcall	_ak820_outline_0133
      00B616 C0 06            [24] 1273 	push	ar6
      00B618 C0 05            [24] 1274 	push	ar5
      00B61A C0 02            [24] 1275 	push	ar2
      00B61C C0 01            [24] 1276 	push	ar1
      00B61E 12 56 0C         [24] 1277 	lcall	_rgb_matrix_get_speed
      00B621 A8 82            [24] 1278 	mov	r0, dpl
      00B623 D0 01            [24] 1279 	pop	ar1
      00B625 D0 02            [24] 1280 	pop	ar2
      00B627 D0 05            [24] 1281 	pop	ar5
      00B629 D0 06            [24] 1282 	pop	ar6
      00B62B 12 82 C1         [24] 1283 	lcall	_ak820_outline_0064
                                   1284 ;	quantum/vialrgb.c:153: args[3] = rgb_matrix_get_hue();
      00B62E 74 05            [12] 1285 	mov	a,#0x05
      00B630 12 90 69         [24] 1286 	lcall	_ak820_outline_0133
      00B633 C0 06            [24] 1287 	push	ar6
      00B635 C0 05            [24] 1288 	push	ar5
      00B637 C0 02            [24] 1289 	push	ar2
      00B639 C0 01            [24] 1290 	push	ar1
      00B63B 12 55 F7         [24] 1291 	lcall	_rgb_matrix_get_hue
      00B63E A8 82            [24] 1292 	mov	r0, dpl
      00B640 D0 01            [24] 1293 	pop	ar1
      00B642 D0 02            [24] 1294 	pop	ar2
      00B644 D0 05            [24] 1295 	pop	ar5
      00B646 D0 06            [24] 1296 	pop	ar6
      00B648 12 82 C1         [24] 1297 	lcall	_ak820_outline_0064
                                   1298 ;	quantum/vialrgb.c:154: args[4] = rgb_matrix_get_sat();
      00B64B 74 06            [12] 1299 	mov	a,#0x06
      00B64D 12 90 69         [24] 1300 	lcall	_ak820_outline_0133
      00B650 C0 06            [24] 1301 	push	ar6
      00B652 C0 05            [24] 1302 	push	ar5
      00B654 C0 02            [24] 1303 	push	ar2
      00B656 C0 01            [24] 1304 	push	ar1
      00B658 12 55 FE         [24] 1305 	lcall	_rgb_matrix_get_sat
      00B65B A8 82            [24] 1306 	mov	r0, dpl
      00B65D D0 01            [24] 1307 	pop	ar1
      00B65F D0 02            [24] 1308 	pop	ar2
      00B661 D0 05            [24] 1309 	pop	ar5
      00B663 D0 06            [24] 1310 	pop	ar6
      00B665 12 82 C1         [24] 1311 	lcall	_ak820_outline_0064
                                   1312 ;	quantum/vialrgb.c:155: args[5] = rgb_matrix_get_val();
      00B668 74 07            [12] 1313 	mov	a,#0x07
      00B66A 12 90 69         [24] 1314 	lcall	_ak820_outline_0133
      00B66D C0 02            [24] 1315 	push	ar2
      00B66F C0 01            [24] 1316 	push	ar1
      00B671 12 56 05         [24] 1317 	lcall	_rgb_matrix_get_val
      00B674 A8 82            [24] 1318 	mov	r0, dpl
      00B676 D0 01            [24] 1319 	pop	ar1
      00B678 D0 02            [24] 1320 	pop	ar2
      00B67A 12 82 C1         [24] 1321 	lcall	_ak820_outline_0064
                                   1322 ;	quantum/vialrgb.c:156: break;
      00B67D 22               [24] 1323 	ret
                                   1324 ;	quantum/vialrgb.c:158: case vialrgb_get_supported: {
      00B67E                       1325 00105$:
                                   1326 ;	quantum/vialrgb.c:159: get_supported(args, length - 2);
      00B67E EF               [12] 1327 	mov	a,r7
      00B67F 24 FE            [12] 1328 	add	a,#0xfe
      00B681 90 0D 5E         [24] 1329 	mov	dptr,#_get_supported_PARM_2
      00B684 F0               [24] 1330 	movx	@dptr,a
      00B685 12 33 FC         [24] 1331 	lcall	_ak820_outline_0122
                                   1332 ;	quantum/vialrgb.c:160: break;
      00B688 41 FA            [12] 1333 	ajmp	_get_supported
                                   1334 ;	quantum/vialrgb.c:163: case vialrgb_get_number_leds: {
      00B68A                       1335 00106$:
                                   1336 ;	quantum/vialrgb.c:164: args[0] = RGB_MATRIX_LED_COUNT & 0xFF;
      00B68A 12 33 FC         [24] 1337 	lcall	_ak820_outline_0122
      00B68D 74 52            [12] 1338 	mov	a,#0x52
      00B68F F0               [24] 1339 	movx	@dptr,a
                                   1340 ;	quantum/vialrgb.c:165: args[1] = RGB_MATRIX_LED_COUNT >> 8;
      00B690 12 B7 9C         [24] 1341 	lcall	_ak820_outline_0035
      00B693 E4               [12] 1342 	clr	a
      00B694 F0               [24] 1343 	movx	@dptr,a
                                   1344 ;	quantum/vialrgb.c:166: break;
      00B695 22               [24] 1345 	ret
                                   1346 ;	quantum/vialrgb.c:168: case vialrgb_get_led_info: {
      00B696                       1347 00107$:
                                   1348 ;	quantum/vialrgb.c:169: uint16_t led = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00B696 12 33 FC         [24] 1349 	lcall	_ak820_outline_0122
      00B699 E0               [24] 1350 	movx	a,@dptr
      00B69A FF               [12] 1351 	mov	r7,a
      00B69B 7A 00            [12] 1352 	mov	r2,#0x00
      00B69D 74 03            [12] 1353 	mov	a,#0x03
      00B69F 2D               [12] 1354 	add	a, r5
      00B6A0 F8               [12] 1355 	mov	r0,a
      00B6A1 E4               [12] 1356 	clr	a
      00B6A2 3E               [12] 1357 	addc	a, r6
      00B6A3 F9               [12] 1358 	mov	r1,a
      00B6A4 C0 03            [24] 1359 	push	ar3
      00B6A6 C0 04            [24] 1360 	push	ar4
      00B6A8 12 38 6C         [24] 1361 	lcall	_ak820_outline_0152
      00B6AB E0               [24] 1362 	movx	a,@dptr
      00B6AC FB               [12] 1363 	mov	r3,a
      00B6AD E4               [12] 1364 	clr	a
      00B6AE 4F               [12] 1365 	orl	a,r7
      00B6AF F5 4E            [12] 1366 	mov	_vialrgb_get_value_sloc0_1_0,a
      00B6B1 EB               [12] 1367 	mov	a,r3
      00B6B2 4A               [12] 1368 	orl	a,r2
      00B6B3 F5 4F            [12] 1369 	mov	(_vialrgb_get_value_sloc0_1_0 + 1),a
                                   1370 ;	quantum/vialrgb.c:170: if (led >= RGB_MATRIX_LED_COUNT) return;
      00B6B5 AC 4E            [24] 1371 	mov	r4,_vialrgb_get_value_sloc0_1_0
      00B6B7 AF 4F            [24] 1372 	mov	r7,(_vialrgb_get_value_sloc0_1_0 + 1)
      00B6B9 C3               [12] 1373 	clr	c
      00B6BA EC               [12] 1374 	mov	a,r4
      00B6BB 94 52            [12] 1375 	subb	a,#0x52
      00B6BD EF               [12] 1376 	mov	a,r7
      00B6BE 94 00            [12] 1377 	subb	a,#0x00
      00B6C0 D0 04            [24] 1378 	pop	ar4
      00B6C2 D0 03            [24] 1379 	pop	ar3
      00B6C4 40 01            [24] 1380 	jc	00109$
      00B6C6 22               [24] 1381 	ret
      00B6C7                       1382 00109$:
                                   1383 ;	quantum/vialrgb.c:172: args[0] = ak820_led_points[led].x;
      00B6C7 E5 4E            [12] 1384 	mov	a,_vialrgb_get_value_sloc0_1_0
      00B6C9 25 4E            [12] 1385 	add	a,_vialrgb_get_value_sloc0_1_0
      00B6CB FA               [12] 1386 	mov	r2,a
      00B6CC E5 4F            [12] 1387 	mov	a,(_vialrgb_get_value_sloc0_1_0 + 1)
      00B6CE 33               [12] 1388 	rlc	a
      00B6CF FF               [12] 1389 	mov	r7,a
      00B6D0 EA               [12] 1390 	mov	a,r2
      00B6D1 24 5A            [12] 1391 	add	a, #_ak820_led_points
      00B6D3 F5 50            [12] 1392 	mov	_vialrgb_get_value_sloc1_1_0,a
      00B6D5 EF               [12] 1393 	mov	a,r7
      00B6D6 34 BC            [12] 1394 	addc	a, #(_ak820_led_points >> 8)
      00B6D8 F5 51            [12] 1395 	mov	(_vialrgb_get_value_sloc1_1_0 + 1),a
      00B6DA 85 50 82         [24] 1396 	mov	dpl,_vialrgb_get_value_sloc1_1_0
      00B6DD 85 51 83         [24] 1397 	mov	dph,(_vialrgb_get_value_sloc1_1_0 + 1)
      00B6E0 E4               [12] 1398 	clr	a
      00B6E1 93               [24] 1399 	movc	a,@a+dptr
      00B6E2 12 33 FC         [24] 1400 	lcall	_ak820_outline_0122
      00B6E5 F0               [24] 1401 	movx	@dptr,a
                                   1402 ;	quantum/vialrgb.c:173: args[1] = ak820_led_points[led].y;
      00B6E6 85 50 82         [24] 1403 	mov	dpl,_vialrgb_get_value_sloc1_1_0
      00B6E9 85 51 83         [24] 1404 	mov	dph,(_vialrgb_get_value_sloc1_1_0 + 1)
      00B6EC A3               [24] 1405 	inc	dptr
      00B6ED E4               [12] 1406 	clr	a
      00B6EE 93               [24] 1407 	movc	a,@a+dptr
      00B6EF 12 38 6C         [24] 1408 	lcall	_ak820_outline_0152
      00B6F2 F0               [24] 1409 	movx	@dptr,a
                                   1410 ;	quantum/vialrgb.c:174: args[2] = LED_FLAG_KEYLIGHT;
      00B6F3 12 B7 9C         [24] 1411 	lcall	_ak820_outline_0035
      00B6F6 A3               [24] 1412 	inc	dptr
      00B6F7 74 04            [12] 1413 	mov	a,#0x04
      00B6F9 F0               [24] 1414 	movx	@dptr,a
                                   1415 ;	quantum/vialrgb.c:183: get_matrix_pos_for_led(led, &args[3]);
      00B6FA 90 0D 67         [24] 1416 	mov	dptr,#_get_matrix_pos_for_led_PARM_2
      00B6FD 04               [12] 1417 	inc	a
      00B6FE 2D               [12] 1418 	add	a, r5
      00B6FF F0               [24] 1419 	movx	@dptr,a
      00B700 E4               [12] 1420 	clr	a
      00B701 3E               [12] 1421 	addc	a, r6
      00B702 A3               [24] 1422 	inc	dptr
      00B703 F0               [24] 1423 	movx	@dptr,a
      00B704 85 4E 82         [24] 1424 	mov	dpl, _vialrgb_get_value_sloc0_1_0
      00B707 85 4F 83         [24] 1425 	mov	dph, (_vialrgb_get_value_sloc0_1_0 + 1)
                                   1426 ;	quantum/vialrgb.c:187: }
                                   1427 ;	quantum/vialrgb.c:188: }
      00B70A 81 32            [24] 1428 	ajmp	_get_matrix_pos_for_led
                                   1429 ;------------------------------------------------------------
                                   1430 ;Allocation info for local variables in function 'vialrgb_set_value'
                                   1431 ;------------------------------------------------------------
                                   1432 ;sloc0         Allocated with name '_vialrgb_set_value_sloc0_1_0'
                                   1433 ;length        Allocated with name '_vialrgb_set_value_PARM_2'
                                   1434 ;data          Allocated with name '_vialrgb_set_value_data_10000_302'
                                   1435 ;args          Allocated with name '_vialrgb_set_value_args_10001_305'
                                   1436 ;cmd           Allocated with name '_vialrgb_set_value_cmd_10001_305'
                                   1437 ;vialrgb_id    Allocated with name '_vialrgb_set_value_vialrgb_id_40001_308'
                                   1438 ;------------------------------------------------------------
                                   1439 ;	quantum/vialrgb.c:190: void vialrgb_set_value(uint8_t *data, uint8_t length) {
                                   1440 ;	-----------------------------------------
                                   1441 ;	 function vialrgb_set_value
                                   1442 ;	-----------------------------------------
      00B70C                       1443 _vialrgb_set_value:
      00B70C 12 43 42         [24] 1444 	lcall	_ak820_outline_0037
      00B70F 90 0D 76         [24] 1445 	mov	dptr,#_vialrgb_set_value_data_10000_302
      00B712 12 37 D6         [24] 1446 	lcall	_ak820_outline_0016
                                   1447 ;	quantum/vialrgb.c:191: if (length != VIAL_RAW_EPSIZE) return;
      00B715 90 0D 75         [24] 1448 	mov	dptr,#_vialrgb_set_value_PARM_2
      00B718 E0               [24] 1449 	movx	a,@dptr
      00B719 FF               [12] 1450 	mov	r7,a
      00B71A BF 20 02         [24] 1451 	cjne	r7,#0x20,00129$
      00B71D 80 01            [24] 1452 	sjmp	00102$
      00B71F                       1453 00129$:
      00B71F 22               [24] 1454 	ret
      00B720                       1455 00102$:
                                   1456 ;	quantum/vialrgb.c:194: uint8_t VIALRGB_BUFFER *args = (uint8_t VIALRGB_BUFFER *)data + 2;
      00B720 90 0D 76         [24] 1457 	mov	dptr,#_vialrgb_set_value_data_10000_302
      00B723 12 B7 A4         [24] 1458 	lcall	_ak820_outline_0043
                                   1459 ;	quantum/vialrgb.c:195: uint8_t cmd = args[-1];
                                   1460 ;	quantum/vialrgb.c:196: switch (cmd) {
      00B726 BA 41 02         [24] 1461 	cjne	r2,#0x41,00130$
      00B729 80 06            [24] 1462 	sjmp	00103$
      00B72B                       1463 00130$:
      00B72B BA 42 02         [24] 1464 	cjne	r2,#0x42,00131$
      00B72E 80 5C            [24] 1465 	sjmp	00104$
      00B730                       1466 00131$:
      00B730 22               [24] 1467 	ret
                                   1468 ;	quantum/vialrgb.c:197: case vialrgb_set_mode: {
      00B731                       1469 00103$:
                                   1470 ;	quantum/vialrgb.c:198: uint16_t vialrgb_id = args[0] | (args[1] << 8);
      00B731 12 49 B4         [24] 1471 	lcall	_ak820_outline_0065
      00B734 12 B7 9C         [24] 1472 	lcall	_ak820_outline_0035
      00B737 E0               [24] 1473 	movx	a,@dptr
      00B738 F8               [12] 1474 	mov	r0,a
      00B739 79 00            [12] 1475 	mov	r1,#0x00
      00B73B 88 53            [24] 1476 	mov	(_vialrgb_set_value_sloc0_1_0 + 1),r0
      00B73D 89 52            [24] 1477 	mov	_vialrgb_set_value_sloc0_1_0,r1
      00B73F 8A 01            [24] 1478 	mov	ar1,r2
      00B741 7A 00            [12] 1479 	mov	r2,#0x00
      00B743 E5 53            [12] 1480 	mov	a,(_vialrgb_set_value_sloc0_1_0 + 1)
      00B745 42 02            [12] 1481 	orl	ar2,a
                                   1482 ;	quantum/vialrgb.c:199: set_mode(vialrgb_id);
      00B747 12 43 BB         [24] 1483 	lcall	_ak820_outline_0181
      00B74A C0 06            [24] 1484 	push	ar6
      00B74C C0 05            [24] 1485 	push	ar5
      00B74E 12 B4 05         [24] 1486 	lcall	_set_mode
      00B751 D0 05            [24] 1487 	pop	ar5
      00B753 D0 06            [24] 1488 	pop	ar6
                                   1489 ;	quantum/vialrgb.c:200: rgb_matrix_set_speed_noeeprom(args[2]);
      00B755 12 B7 9C         [24] 1490 	lcall	_ak820_outline_0035
      00B758 A3               [24] 1491 	inc	dptr
      00B759 E0               [24] 1492 	movx	a,@dptr
      00B75A F5 82            [12] 1493 	mov	dpl,a
      00B75C C0 06            [24] 1494 	push	ar6
      00B75E C0 05            [24] 1495 	push	ar5
      00B760 12 56 D4         [24] 1496 	lcall	_rgb_matrix_set_speed_noeeprom
      00B763 D0 05            [24] 1497 	pop	ar5
      00B765 D0 06            [24] 1498 	pop	ar6
                                   1499 ;	quantum/vialrgb.c:201: rgb_matrix_sethsv_noeeprom(args[3], args[4], args[5]);
      00B767 12 B7 9C         [24] 1500 	lcall	_ak820_outline_0035
      00B76A A3               [24] 1501 	inc	dptr
      00B76B A3               [24] 1502 	inc	dptr
      00B76C E0               [24] 1503 	movx	a,@dptr
      00B76D F9               [12] 1504 	mov	r1,a
      00B76E 7A 00            [12] 1505 	mov	r2,#0x00
      00B770 74 06            [12] 1506 	mov	a,#0x06
      00B772 12 B7 EE         [24] 1507 	lcall	_ak820_outline_0169
      00B775 F8               [12] 1508 	mov	r0,a
      00B776 74 07            [12] 1509 	mov	a,#0x07
      00B778 12 B7 EE         [24] 1510 	lcall	_ak820_outline_0169
      00B77B FE               [12] 1511 	mov	r6,a
      00B77C 90 07 34         [24] 1512 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_2
      00B77F E8               [12] 1513 	mov	a,r0
      00B780 F0               [24] 1514 	movx	@dptr,a
      00B781 90 07 35         [24] 1515 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_3
      00B784 EE               [12] 1516 	mov	a,r6
      00B785 F0               [24] 1517 	movx	@dptr,a
      00B786 12 43 BB         [24] 1518 	lcall	_ak820_outline_0181
                                   1519 ;	quantum/vialrgb.c:202: break;
                                   1520 ;	quantum/vialrgb.c:205: case vialrgb_direct_fastset: {
      00B789 02 56 A5         [24] 1521 	ljmp	_rgb_matrix_sethsv_noeeprom
      00B78C                       1522 00104$:
                                   1523 ;	quantum/vialrgb.c:206: fast_set_leds(args, length - 2);
      00B78C EF               [12] 1524 	mov	a,r7
      00B78D 24 FE            [12] 1525 	add	a,#0xfe
      00B78F 90 0D 6B         [24] 1526 	mov	dptr,#_fast_set_leds_PARM_2
      00B792 F0               [24] 1527 	movx	@dptr,a
      00B793 12 33 FC         [24] 1528 	lcall	_ak820_outline_0122
                                   1529 ;	quantum/vialrgb.c:210: }
                                   1530 ;	quantum/vialrgb.c:211: }
      00B796 02 B4 65         [24] 1531 	ljmp	_fast_set_leds
                                   1532 ;------------------------------------------------------------
                                   1533 ;Allocation info for local variables in function 'vialrgb_save'
                                   1534 ;------------------------------------------------------------
                                   1535 ;length        Allocated with name '_vialrgb_save_PARM_2'
                                   1536 ;data          Allocated with name '_vialrgb_save_data_10000_310'
                                   1537 ;------------------------------------------------------------
                                   1538 ;	quantum/vialrgb.c:213: void vialrgb_save(uint8_t *data, uint8_t length) {
                                   1539 ;	-----------------------------------------
                                   1540 ;	 function vialrgb_save
                                   1541 ;	-----------------------------------------
      00B799                       1542 _vialrgb_save:
                                   1543 ;	quantum/vialrgb.c:217: eeconfig_update_rgb_matrix();
                                   1544 ;	quantum/vialrgb.c:218: }
      00B799 02 51 44         [24] 1545 	ljmp	_eeconfig_update_rgb_matrix
                                   1546 	.area CSEG    (CODE)
                                   1547 	.area CONST   (CODE)
                                   1548 	.area CONST   (CODE)
      00BF99                       1549 _supported_modes:
      00BF99 00                    1550 	.db #0x00	; 0
      00BF9A 00                    1551 	.db #0x00	; 0
      00BF9B 01                    1552 	.db #0x01	; 1
      00BF9C 05                    1553 	.db #0x05	; 5
      00BF9D 02                    1554 	.db #0x02	; 2
      00BF9E 01                    1555 	.db #0x01	; 1
      00BF9F 06                    1556 	.db #0x06	; 6
      00BFA0 02                    1557 	.db #0x02	; 2
      00BFA1 0D                    1558 	.db #0x0d	; 13
      00BFA2 03                    1559 	.db #0x03	; 3
      00BFA3 0E                    1560 	.db #0x0e	; 14
      00BFA4 04                    1561 	.db #0x04	; 4
      00BFA5 1F                    1562 	.db #0x1f	; 31
      00BFA6 06                    1563 	.db #0x06	; 6
                                   1564 	.area CSEG    (CODE)
                                   1565 	.area XINIT   (CODE)
                                   1566 	.area CABS    (ABS,CODE)
                                   1567 
                                   1568 ; Experimental exact instruction outlining.
                                   1569 	.globl _ak820_outline_0004
                                   1570 	.globl _ak820_outline_0016
                                   1571 	.globl _ak820_outline_0031
                                   1572 	.globl _ak820_outline_0035
                                   1573 	.globl _ak820_outline_0036
                                   1574 	.globl _ak820_outline_0037
                                   1575 	.globl _ak820_outline_0043
                                   1576 	.globl _ak820_outline_0045
                                   1577 	.globl _ak820_outline_0051
                                   1578 	.globl _ak820_outline_0057
                                   1579 	.globl _ak820_outline_0064
                                   1580 	.globl _ak820_outline_0065
                                   1581 	.globl _ak820_outline_0076
                                   1582 	.globl _ak820_outline_0081
                                   1583 	.globl _ak820_outline_0097
                                   1584 	.globl _ak820_outline_0101
                                   1585 	.globl _ak820_outline_0103
                                   1586 	.globl _ak820_outline_0104
                                   1587 	.globl _ak820_outline_0105
                                   1588 	.globl _ak820_outline_0106
                                   1589 	.globl _ak820_outline_0109
                                   1590 	.globl _ak820_outline_0117
                                   1591 	.globl _ak820_outline_0119
                                   1592 	.globl _ak820_outline_0122
                                   1593 	.globl _ak820_outline_0131
                                   1594 	.globl _ak820_outline_0133
                                   1595 	.globl _ak820_outline_0139
                                   1596 	.globl _ak820_outline_0141
                                   1597 	.globl _ak820_outline_0152
                                   1598 	.globl _ak820_outline_0157
                                   1599 	.globl _ak820_outline_0168
                                   1600 	.globl _ak820_outline_0169
                                   1601 	.globl _ak820_outline_0181
                                   1602 
                                   1603 	.area CSEG (CODE)
                                   1604 ; function ak820_outline_0035
      00B79C                       1605 _ak820_outline_0035:
      00B79C 8D 82            [24] 1606 	mov	dpl,r5
      00B79E 8E 83            [24] 1607 	mov	dph,r6
      00B7A0 A3               [24] 1608 	inc	dptr
      00B7A1 A3               [24] 1609 	inc	dptr
      00B7A2 A3               [24] 1610 	inc	dptr
      00B7A3 22               [24] 1611 	ret
                                   1612 
                                   1613 	.area CSEG (CODE)
                                   1614 ; function ak820_outline_0043
      00B7A4                       1615 _ak820_outline_0043:
      00B7A4 E0               [24] 1616 	movx	a,@dptr
      00B7A5 FD               [12] 1617 	mov	r5,a
      00B7A6 A3               [24] 1618 	inc	dptr
      00B7A7 E0               [24] 1619 	movx	a,@dptr
      00B7A8 FE               [12] 1620 	mov	r6,a
      00B7A9 74 02            [12] 1621 	mov	a,#0x02
      00B7AB 2D               [12] 1622 	add	a,r5
      00B7AC FB               [12] 1623 	mov	r3,a
      00B7AD E4               [12] 1624 	clr	a
      00B7AE 3E               [12] 1625 	addc	a,r6
      00B7AF FC               [12] 1626 	mov	r4,a
      00B7B0 8D 82            [24] 1627 	mov	dpl,r5
      00B7B2 8E 83            [24] 1628 	mov	dph,r6
      00B7B4 A3               [24] 1629 	inc	dptr
      00B7B5 E0               [24] 1630 	movx	a,@dptr
      00B7B6 FA               [12] 1631 	mov	r2,a
      00B7B7 22               [24] 1632 	ret
                                   1633 
                                   1634 	.area CSEG (CODE)
                                   1635 ; function ak820_outline_0045
      00B7B8                       1636 _ak820_outline_0045:
      00B7B8 ED               [12] 1637 	mov	a,r5
      00B7B9 75 F0 02         [24] 1638 	mov	b,#0x02
      00B7BC A4               [48] 1639 	mul	ab
      00B7BD 24 99            [12] 1640 	add	a,#_supported_modes
      00B7BF FB               [12] 1641 	mov	r3,a
      00B7C0 74 BF            [12] 1642 	mov	a,#(_supported_modes>>8)
      00B7C2 35 F0            [12] 1643 	addc	a,b
      00B7C4 FC               [12] 1644 	mov	r4,a
      00B7C5 8B 82            [24] 1645 	mov	dpl,r3
      00B7C7 8C 83            [24] 1646 	mov	dph,r4
      00B7C9 22               [24] 1647 	ret
                                   1648 
                                   1649 	.area CSEG (CODE)
                                   1650 ; function ak820_outline_0081
      00B7CA                       1651 _ak820_outline_0081:
      00B7CA 90 0D 6C         [24] 1652 	mov	dptr,#_fast_set_leds_args_10000_282
      00B7CD E0               [24] 1653 	movx	a,@dptr
      00B7CE F9               [12] 1654 	mov	r1,a
      00B7CF A3               [24] 1655 	inc	dptr
      00B7D0 E0               [24] 1656 	movx	a,@dptr
      00B7D1 FF               [12] 1657 	mov	r7,a
      00B7D2 89 82            [24] 1658 	mov	dpl,r1
      00B7D4 8F 83            [24] 1659 	mov	dph,r7
      00B7D6 E0               [24] 1660 	movx	a,@dptr
      00B7D7 22               [24] 1661 	ret
                                   1662 
                                   1663 	.area CSEG (CODE)
                                   1664 ; function ak820_outline_0103
      00B7D8                       1665 _ak820_outline_0103:
      00B7D8 90 0D 6C         [24] 1666 	mov	dptr,#_fast_set_leds_args_10000_282
      00B7DB 74 01            [12] 1667 	mov	a,#0x01
      00B7DD 29               [12] 1668 	add	a,r1
      00B7DE F0               [24] 1669 	movx	@dptr,a
      00B7DF E4               [12] 1670 	clr	a
      00B7E0 3F               [12] 1671 	addc	a,r7
      00B7E1 A3               [24] 1672 	inc	dptr
      00B7E2 F0               [24] 1673 	movx	@dptr,a
      00B7E3 22               [24] 1674 	ret
                                   1675 
                                   1676 	.area CSEG (CODE)
                                   1677 ; function ak820_outline_0141
      00B7E4                       1678 _ak820_outline_0141:
      00B7E4 E4               [12] 1679 	clr	a
      00B7E5 93               [24] 1680 	movc	a,@a+dptr
      00B7E6 FC               [12] 1681 	mov	r4,a
      00B7E7 7B 00            [12] 1682 	mov	r3,#0x00
      00B7E9 8C 82            [24] 1683 	mov	dpl,r4
      00B7EB 8B 83            [24] 1684 	mov	dph,r3
      00B7ED 22               [24] 1685 	ret
                                   1686 
                                   1687 	.area CSEG (CODE)
                                   1688 ; function ak820_outline_0169
      00B7EE                       1689 _ak820_outline_0169:
      00B7EE 2D               [12] 1690 	add	a,r5
      00B7EF F5 82            [12] 1691 	mov	dpl,a
      00B7F1 E4               [12] 1692 	clr	a
      00B7F2 3E               [12] 1693 	addc	a,r6
      00B7F3 F5 83            [12] 1694 	mov	dph,a
      00B7F5 E0               [24] 1695 	movx	a,@dptr
      00B7F6 22               [24] 1696 	ret
